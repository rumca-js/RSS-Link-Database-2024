# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## Transformers One - Claws (2024)
 - [https://www.youtube.com/watch?v=Sk0NJ0oR5Mg](https://www.youtube.com/watch?v=Sk0NJ0oR5Mg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-07-26T22:15:17+00:00

Check out the new trailer for Transformers One starring Chris Hemsworth and Brian Tyree Henry! 

► Buy Tickets to Transformers One: https://www.fandango.com/transformers-one-2024-234524/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the best indie trailers: http://bit.ly/2Ewwuuf  

US Release Date: September 20, 2024
Starring: Brian Tyree Henry, Chris Hemsworth, Keegan-Michael Key, Scarlett Johansson, Steve Buscemi
Director: Josh Cooley
Synopsis: Optimus Prime and Megatron go from brothers-in-arms to sworn enemies on their home planet of Cybertron. 
► Learn more: https://www.rottentomatoes.com/m/transformers_one?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV  
► What to Watch: https://bit.ly/3x6Q01d  
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot

## 'Deadpool & Wolverine' EPIC Drone Show at SDCC
 - [https://www.youtube.com/watch?v=Wh7HEynJ0Pg](https://www.youtube.com/watch?v=Wh7HEynJ0Pg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-07-26T18:00:18+00:00

'Deadpool & Wolverine' EPIC Drone Show at SDCC! #shorts

## Galactus and Fantastic Four Logo Shown at SDCC Marvel Drone Show
 - [https://www.youtube.com/watch?v=T9DWvUBvcgg](https://www.youtube.com/watch?v=T9DWvUBvcgg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-07-26T17:30:41+00:00

Galactus and Fantastic Four Logo Shown at SDCC Marvel Drone Show! #shorts

## Pretty Guardian Sailor Moon Cosmos The Movie Trailer #1 (2024)
 - [https://www.youtube.com/watch?v=U2N3xsfzLmU](https://www.youtube.com/watch?v=U2N3xsfzLmU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-07-26T13:00:36+00:00

Check out the official trailer for Pretty Guardian Sailor Moon Cosmos The Movie starring Hisako Kanemoto! 
► Visit Fandango: https://www.fandango.com/?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: August 22, 2024
Starring: Hisako Kanemoto, Kenji Nojima, Kotono Mitsuishi
Director: Tomoya Takahashi
Synopsis: One by one, Sailor Moon’s friends and loved ones are targeted by a formidable new enemy who threatens to destroy everything and rule over the cosmos. Sailor Moon battles Shadow Galactica, an enemy threatening her friends in order to rule the universe. Can she protect her loved ones and persevere? This anime's final chapter begins August 22, only on Netflix!

► Learn more: https://www.rottentomatoes.com/m/sailor_moon_cosmos_part_1?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV  


