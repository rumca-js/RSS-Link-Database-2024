# Source:Lateral with Tom Scott, URL:https://audioboom.com/channels/5097784.rss, language:en-US

## 94: The empty pizza box
 - [https://www.lateralcast.com/episodes/94](https://www.lateralcast.com/episodes/94)
 - RSS feed: https://audioboom.com/channels/5097784.rss
 - date published: 2024-07-26T04:00:00+00:00

Hank Green, Ceri Riley and Daniel Peake face questions about practical pencils, pyromaniac profiteers and prodigious protoplasm.
LATERAL is a comedy panel game podcast about weird questions with wonderful answers, hosted by Tom Scott. For business enquiries, contestant appearances or question submissions, visit https://lateralcast.com.
HOST: Tom Scott. QUESTION PRODUCER: David Bodycombe. EDITED BY: Julie Hassett at The Podcast Studios, Dublin. MUSIC: Karl-Ola Kjellholm ('Private Detective'/'Agrumes'), ELFL ('Neon Raceway') courtesy of epidemicsound.com. ADDITIONAL QUESTIONS: Harry, Alex Rinehart, Tom & Gemma, Lembit, Shiloh. FORMAT: Pad 26 Limited/Labyrinth Games Ltd. EXECUTIVE PRODUCERS: David Bodycombe and Tom Scott. © Pad 26 Limited (https://www.pad26.com) / Labyrinth Games Ltd. 2024.
Learn more about your ad choices. Visit megaphone.fm/adchoices

