# Source:GameLinked, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHDxYLv8iovIbhrfl16CNyg, language:en

## The Humble ‘Shutdown’ Is Weird
 - [https://www.youtube.com/watch?v=HVd9oYnCvIk](https://www.youtube.com/watch?v=HVd9oYnCvIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHDxYLv8iovIbhrfl16CNyg
 - date published: 2024-07-26T02:19:52+00:00

https://ifix.gd/gamelinked724

Save $10 on orders of $50 or more at iFixit! with code GLFIX at the link above, but act quick because the sale is only on for 48 hours after this video goes live! (US & Canada only)

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► LISTEN TO THE GAMING NEWS: https://lmg.gg/GameLinkedPodcast
► GET A VPN: https://lmg.gg/piagamelinked
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► WHERE WE BUY GAMES: https://lmg.gg/shopgames

NEWS SOURCES: https://lmg.gg/41nbq
-------------------------------------------------------------------
Timestamps:
0:00 side effects include 'being based'
0:08 Humble Games 'restructuring'
1:44 Roblox report from Bloomberg
3:11 World of Warcraft 'The War Within'
5:20 QUICK BITS INTRO
5:29 WoW Gamemakers Guild
6:08 Wired report on AI in gaming
6:49 Fallout: London launch
7:30 International Olympic Esports Games
8:13 Warframe '99

