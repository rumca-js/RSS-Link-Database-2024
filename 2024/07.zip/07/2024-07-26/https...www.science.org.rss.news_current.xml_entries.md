# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## U.S. Senate spending bill sets up congressional clash over research spending
 - [https://www.science.org/content/article/u-s-senate-spending-bill-sets-congressional-clash-over-research-spending](https://www.science.org/content/article/u-s-senate-spending-bill-sets-congressional-clash-over-research-spending)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-26T23:31:48.938304+00:00

Panel backs modest increases for National Science Foundation, NASA, and other agencies

## NASA says it found possible signs of life on Mars. There are a lot of maybes
 - [https://www.science.org/content/article/nasa-says-it-found-possible-signs-life-mars-there-are-lot-maybes](https://www.science.org/content/article/nasa-says-it-found-possible-signs-life-mars-there-are-lot-maybes)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-26T21:15:14.994788+00:00

Some see hype over intriguing rock as plea for troubled multibillion-dollar Mars Sample Return mission

## Argentine scientists scrimp and save their way through funding crisis
 - [https://www.science.org/content/article/argentine-scientists-scrimp-and-save-their-way-through-funding-crisis](https://www.science.org/content/article/argentine-scientists-scrimp-and-save-their-way-through-funding-crisis)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-26T21:15:13.316789+00:00

Deep budget cuts are sowing chaos—and creativity

## Giant clams, iconic and imperiled, may get U.S. endangered species protection
 - [https://www.science.org/content/article/giant-clams-iconic-and-imperiled-may-get-u-s-endangered-species-protection](https://www.science.org/content/article/giant-clams-iconic-and-imperiled-may-get-u-s-endangered-species-protection)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-26T20:11:33.728124+00:00

Marine biologists support federal proposal, but the aquarium industry worries it may be counterproductive

## Colorado tries a new tactic against ‘cow flu’: widespread milk testing
 - [https://www.science.org/content/article/colorado-tries-new-tactic-against-cow-flu-widespread-milk-testing](https://www.science.org/content/article/colorado-tries-new-tactic-against-cow-flu-widespread-milk-testing)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-26T20:11:31.752036+00:00

The state hit hardest by the H5N1 outbreak orders weekly tests of milk tanks at all dairy farms

## U.S. invests $67 million in national research security centers
 - [https://www.science.org/content/article/u-s-invests-67-million-national-research-security-centers](https://www.science.org/content/article/u-s-invests-67-million-national-research-security-centers)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-26T16:35:50.483813+00:00

Washington, Texas universities to lead National Science Foundation effort to address foreign influence issues and share best practices

