# Source:Tabletop Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ, language:en-US

## The Fastest & Easiest Ghosts You've EVER Painted!
 - [https://www.youtube.com/watch?v=4eFfY4tO2EU](https://www.youtube.com/watch?v=4eFfY4tO2EU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ
 - date published: 2024-07-26T07:00:02+00:00

My friend Phil @TheGlacialGeek painted a ghost for Deth Wizards and I liked it so much - I painted a DOZEN ghosts in no time at all. Learn the secret of the GHOST JUICE.

Vince Venturella and I made another game! Check out Deth Wizards - Necromantic Skirmish Combat at http://www.dethwizardsgame.com

I'm now a partner on Twitch! I paint minis every Friday morning and Monday night, and sometimes take paint breaks (play video games poorly). Follow me: http://www.twitch.tv/tabletopminions

Official Tabletop Minions t-shirts: http://bit.ly/merchbunker

Help support the channel on Patreon, and get access to the Discord: http://www.patreon.com/tabletopminions

Twitter: http://www.twitter.com/tabletopminions
Instagram: http://www.instagram.com/tabletopminions

