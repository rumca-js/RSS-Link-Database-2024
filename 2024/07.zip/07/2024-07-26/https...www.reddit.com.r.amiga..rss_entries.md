# Source:Amiga, URL:https://www.reddit.com/r/amiga/.rss, language:en

## Best printer for an A500?
 - [https://www.reddit.com/r/amiga/comments/1eczgt4/best_printer_for_an_a500](https://www.reddit.com/r/amiga/comments/1eczgt4/best_printer_for_an_a500)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T21:28:09+00:00

<!-- SC_OFF --><div class="md"><p>Hey everyone - after years of wanting one I finally got my hands on a fully functional A500;<br /> I'm trying to fill out some accessories for it and I'm wondering if anyone knows what the best/most compatible printers are for it.</p> <p>I'd like something semi-period appropriate. If I could find something with color that would be ideal, but I'd be just as happy with a dot-matrix that I know 100% will work out of the box.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/notquiteright2"> /u/notquiteright2 </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1eczgt4/best_printer_for_an_a500/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1eczgt4/best_printer_for_an_a500/">[comments]</a></span>

## Gotta love this crazy title screen. Is that a pooping dog on the left side?
 - [https://www.reddit.com/r/amiga/comments/1ecyrhq/gotta_love_this_crazy_title_screen_is_that_a](https://www.reddit.com/r/amiga/comments/1ecyrhq/gotta_love_this_crazy_title_screen_is_that_a)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T20:58:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ecyrhq/gotta_love_this_crazy_title_screen_is_that_a/"> <img alt="Gotta love this crazy title screen. Is that a pooping dog on the left side?" src="https://preview.redd.it/to17p5nufxed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=96eb04639326124e37adc72fd7a1a05340c022ce" title="Gotta love this crazy title screen. Is that a pooping dog on the left side?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Toincossross"> /u/Toincossross </a> <br /> <span><a href="https://i.redd.it/to17p5nufxed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ecyrhq/gotta_love_this_crazy_title_screen_is_that_a/">[comments]</a></span> </td></tr></table>

## UK Recapping recommendations
 - [https://www.reddit.com/r/amiga/comments/1ecxja9/uk_recapping_recommendations](https://www.reddit.com/r/amiga/comments/1ecxja9/uk_recapping_recommendations)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T20:04:51+00:00

<!-- SC_OFF --><div class="md"><p>Does anyone have any recommendations for recapping Amigas in the UK?</p> <p>I have A600 A1200 CD32</p> <p>that need doing.</p> <p>I want a fast reliable service (if possible!)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/binglybinglybeep99"> /u/binglybinglybeep99 </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1ecxja9/uk_recapping_recommendations/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ecxja9/uk_recapping_recommendations/">[comments]</a></span>

## Amiga items
 - [https://www.reddit.com/r/amiga/comments/1ecx0fu/amiga_items](https://www.reddit.com/r/amiga/comments/1ecx0fu/amiga_items)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T19:42:35+00:00

<!-- SC_OFF --><div class="md"><p>I was about to throw out all my Amiga games, and decided to see if there was anyone out there who might be interested. Found your group. Very interesting. All free does anyone want them? Should I not throw them out? I even have some C64 games as well.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Fun_Crab_2844"> /u/Fun_Crab_2844 </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1ecx0fu/amiga_items/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ecx0fu/amiga_items/">[comments]</a></span>

## Some mess at the Mexico Grand Prix
 - [https://www.reddit.com/r/amiga/comments/1ecvrts/some_mess_at_the_mexico_grand_prix](https://www.reddit.com/r/amiga/comments/1ecvrts/some_mess_at_the_mexico_grand_prix)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T18:49:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ecvrts/some_mess_at_the_mexico_grand_prix/"> <img alt="Some mess at the Mexico Grand Prix" src="https://external-preview.redd.it/PP7kcYY6NI-zTSqgE-DVxl9an4Iye77awug95ZL3Xt4.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=97ceac9bac5efdb36d2d151fb3b459a59940876b" title="Some mess at the Mexico Grand Prix" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DocMnemonic"> /u/DocMnemonic </a> <br /> <span><a href="https://youtu.be/OrjzF91Llgs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ecvrts/some_mess_at_the_mexico_grand_prix/">[comments]</a></span> </td></tr></table>

## CD32 RGB to HDMI help
 - [https://www.reddit.com/r/amiga/comments/1ecqeq1/cd32_rgb_to_hdmi_help](https://www.reddit.com/r/amiga/comments/1ecqeq1/cd32_rgb_to_hdmi_help)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T15:06:52+00:00

<!-- SC_OFF --><div class="md"><p>I have bought a CD32 with TF330 and riser. I thought my TV had RGB input but found I was thinking of my old tv, my current one only has HDMI. I need an RGB to HDMI converter but don’t know which to get. I have found an OSSC at €145 or a a setup with the converter and Amiga RGB cable in one package for £78. Has anybody any idea which would be better? I don’t mind spending out If the picture and lag is better with the more expensive option. Is there a better option that I haven’t found, out there?</p> <p>I’ll post links to what I’m considering in a comment as I can’t post both here.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NeilDeWheel"> /u/NeilDeWheel </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1ecqeq1/cd32_rgb_to_hdmi_help/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ecqeq1/cd32_rgb_to_hdmi_help/">[comments]</a></span>

## REAL Amiga OCS games use more than 50 colors (based on a totally unscientific method)
 - [https://www.reddit.com/r/amiga/comments/1ecmxbh/real_amiga_ocs_games_use_more_than_50_colors](https://www.reddit.com/r/amiga/comments/1ecmxbh/real_amiga_ocs_games_use_more_than_50_colors)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T12:31:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ecmxbh/real_amiga_ocs_games_use_more_than_50_colors/"> <img alt="REAL Amiga OCS games use more than 50 colors (based on a totally unscientific method)" src="https://preview.redd.it/pstgtkodxued1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=e51914462c16e8bf65552d9b208bb81469c0226f" title="REAL Amiga OCS games use more than 50 colors (based on a totally unscientific method)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/joeB3000"> /u/joeB3000 </a> <br /> <span><a href="https://i.redd.it/pstgtkodxued1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ecmxbh/real_amiga_ocs_games_use_more_than_50_colors/">[comments]</a></span> </td></tr></table>

## MorphOS Amiga like OS Powermac Gets A CPU Upgrade
 - [https://www.reddit.com/r/amiga/comments/1eclf62/morphos_amiga_like_os_powermac_gets_a_cpu_upgrade](https://www.reddit.com/r/amiga/comments/1eclf62/morphos_amiga_like_os_powermac_gets_a_cpu_upgrade)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T11:10:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1eclf62/morphos_amiga_like_os_powermac_gets_a_cpu_upgrade/"> <img alt="MorphOS Amiga like OS Powermac Gets A CPU Upgrade" src="https://external-preview.redd.it/Mh_z9Pz5AhOcIYRKTwrMkBFX5UYhWilsRrcBcUVwhoI.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=69339d3f6003ca51cbd9ddcdedb09cc89d41d03f" title="MorphOS Amiga like OS Powermac Gets A CPU Upgrade" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Macphreak4evr"> /u/Macphreak4evr </a> <br /> <span><a href="https://youtu.be/8cwLaeZpSqQ">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1eclf62/morphos_amiga_like_os_powermac_gets_a_cpu_upgrade/">[comments]</a></span> </td></tr></table>

## Ep. 71 Unboxing & playing Badlands Amiga game [Ελληνικά]
 - [https://www.reddit.com/r/amiga/comments/1ech8fh/ep_71_unboxing_playing_badlands_amiga_game](https://www.reddit.com/r/amiga/comments/1ech8fh/ep_71_unboxing_playing_badlands_amiga_game)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T06:29:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1ech8fh/ep_71_unboxing_playing_badlands_amiga_game/"> <img alt="Ep. 71 Unboxing &amp; playing Badlands Amiga game [Ελληνικά]" src="https://external-preview.redd.it/fcEb2MumeFoPLiF9FgRgu4FwL_pf3TFu2uN3HpscH3A.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=6809011cba3dffa5de257bf9c2549a3579f0f4a7" title="Ep. 71 Unboxing &amp; playing Badlands Amiga game [Ελληνικά]" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Badlands is a 1989 arcade video game published by Atari Games. It was ported by Domark under the Tengen label to the Amiga, Amstrad CPC, Atari ST, Commodore 64, and ZX Spectrum. The game is a re-themed version of Atari's previous racing games Super Sprint and Championship Sprint with the addition of vehicular combat. Badlands is set in the aftermath of a nuclear war and races around abandoned wastelands with many hazards. Three gun-equipped cars race around a track to win prizes.</p> </div><!-- SC_ON --> &#3

## What is your favourite Amiga game?
 - [https://www.reddit.com/r/amiga/comments/1ech336/what_is_your_favourite_amiga_game](https://www.reddit.com/r/amiga/comments/1ech336/what_is_your_favourite_amiga_game)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T06:20:14+00:00

<!-- SC_OFF --><div class="md"><p>Mine is Powermonger.</p> <p>Close second, speedball 2, and Populous 2.</p> <p>Yours?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LettishLad"> /u/LettishLad </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1ech336/what_is_your_favourite_amiga_game/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ech336/what_is_your_favourite_amiga_game/">[comments]</a></span>

## Best controller for Amiga 500 mini?
 - [https://www.reddit.com/r/amiga/comments/1ecgukn/best_controller_for_amiga_500_mini](https://www.reddit.com/r/amiga/comments/1ecgukn/best_controller_for_amiga_500_mini)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-26T06:05:11+00:00

<!-- SC_OFF --><div class="md"><p>Looking for something wireless and easy to connect. </p> <p>Might also use it for my windows PC.</p> <p>I'm not a console guy really, so I have really no idea on general, especially when it comes to the Amiga 500 mini...</p> <p>I know I'm late to the party, I've had my Amiga 500 mini for about a year, but I want to open it and relive my youth soon :) </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LettishLad"> /u/LettishLad </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1ecgukn/best_controller_for_amiga_500_mini/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1ecgukn/best_controller_for_amiga_500_mini/">[comments]</a></span>

