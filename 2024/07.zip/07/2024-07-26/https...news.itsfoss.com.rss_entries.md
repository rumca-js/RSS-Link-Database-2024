# Source:It's FOSS News, URL:https://news.itsfoss.com/rss, language:en-US

## This Open-Source AI Image Generator Plans to Take on Stable Diffusion 3
 - [https://news.itsfoss.com/open-source-image-generator-auraflow](https://news.itsfoss.com/open-source-image-generator-auraflow)
 - RSS feed: https://news.itsfoss.com/rss
 - date published: 2024-07-26T10:41:20+00:00

Finally, a truly open-source Stable Diffusion contender!

## This Open-Source Android Weather App Looks Pretty!
 - [https://news.itsfoss.com/breezy-weather](https://news.itsfoss.com/breezy-weather)
 - RSS feed: https://news.itsfoss.com/rss
 - date published: 2024-07-26T04:00:59+00:00

A visually pleasing FOSS weather app. What more do you need!

