# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Animality Finishers Are Coming Back to Mortal Kombat 1!!
 - [https://www.youtube.com/watch?v=EcdVVN2pqaQ](https://www.youtube.com/watch?v=EcdVVN2pqaQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-07-26T22:41:43+00:00

During the Mortal Kombat 1 panel today at SDCC 2024 we got to see the upcoming Khaos Reigns DLC pack and with it we will be getting Animalities back! Check out a handful here from the trailer today!

## Mortal Kombat 1 - Ghostface, T-1000, Conan, Noob Saibot, Sektor and Cyrax Official Reveal Trailer
 - [https://www.youtube.com/watch?v=kjNe82ngN-8](https://www.youtube.com/watch?v=kjNe82ngN-8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-07-26T21:54:16+00:00

We got our reveal of the upcoming characters coming to Mortal Kombat 1 as part of Khaos Reigns DLC Pack. Ghostface from Scream, Noob Saibot, Cyrax, Sektor, Conan the Barbarian, and T-1000 from Terminator 2 Judgement Day. All these characters were announced at the San Diego Comic Con panel today. 

Animalities make their way back to the game too check out various finishers in this latest trailers. Including a fun one for Rain which features a pufferfish.

#mortalkombat1 #sdcc #gaming

## FATAL FURY: City of the Wolves｜Official Billy Kane Character Gameplay Reveal Trailer
 - [https://www.youtube.com/watch?v=OIuGwbJZ2Yw](https://www.youtube.com/watch?v=OIuGwbJZ2Yw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-07-26T04:00:15+00:00

Take a look at the gameplay reveal trailer for one of the latest additions to the character roster for Fatal Fury COTW!

