# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## The 2024 Olympic Games Opening Ceremony Goes Full Assassin's Creed Parkour On Paris' Rooftops
 - [https://kotaku.com/assassins-creed-2024-summer-olympic-games-paris-1851606886](https://kotaku.com/assassins-creed-2024-summer-olympic-games-paris-1851606886)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T21:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e310b5eed64218d7c81cbd61524d38da.jpg" /><p>I didn’t know the 2024 Olympic Games were starting today. Or that they were in France. So I was extra surprised when the opening ceremony looked like a scene out of a classic Assassin’s Creed game. </p><p><a href="https://kotaku.com/assassins-creed-2024-summer-olympic-games-paris-1851606886">Read more...</a></p>

## Capcom Made A Game That Doesn't Belong In 2024 And It's Fantastic
 - [https://kotaku.com/kunitsu-gami-path-goddess-game-pass-capcom-1851606852](https://kotaku.com/kunitsu-gami-path-goddess-game-pass-capcom-1851606852)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T20:43:23+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/219fec6e7d1ecaa3cccbe41724dd4840.jpg" /><p>The world of Kunitsu-Gami: Path of the Goddess is meant to feel fantastical and from another time, but the game itself also feels like an anachronism. Something that shouldn’t exist in 2024. It’s not a sequel in a hit franchise. It’s not working in a popular genre. And it’s not pandering to an international audience. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/kunitsu-gami-path-goddess-review-game-pass-1851600358">I…</a></p><p><a href="https://kotaku.com/kunitsu-gami-path-goddess-game-pass-capcom-1851606852">Read more...</a></p>

## X-Men Comics Fans At War Over Bonus Pages Hidden Behind QR Codes
 - [https://kotaku.com/x-men-1-comic-fans-bonus-pages-qr-codes-hidden-locked-1851606688](https://kotaku.com/x-men-1-comic-fans-bonus-pages-qr-codes-hidden-locked-1851606688)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/bf47bb77f65abdddf91a420f1337bede.jpg" /><p>Some <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/x-men-97-season-one-recommended-reading-comics-list-1851491472">X-Men comics</a> now feature a QR code in the back of the book that hides a “bonus page.” These new hidden pages have set off a large debate online among comic readers and fans over what counts as bonus content and comic preservation.<br /></p><p><a href="https://kotaku.com/x-men-1-comic-fans-bonus-pages-qr-codes-hidden-locked-1851606688">Read more...</a></p>

## MrBeast Has Hired An Investigator To Look Into Grooming Allegations Against Ex-Co-Host Ava Kris Tyson
 - [https://kotaku.com/ava-kris-tyson-mr-beast-grooming-allegations-1851606782](https://kotaku.com/ava-kris-tyson-mr-beast-grooming-allegations-1851606782)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T19:51:10+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/7fbc36d662b0db74db44184fa67ddc61.jpg" /><p>Following allegations that MrBeast’s one-time co-host Ava Kris Tyson groomed a minor years ago, the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/mrbeast-running-for-president-tweet-biden-trump-2024-1851584876">popular YouTube personality</a> has cut ties with her and reprimanded her for her “unacceptable acts.” MrBeast, whose real name is Jimmy Donaldson, has since hired a third-party investigator in the hopes that they’ll…</p><p><a href="https://kotaku.com/ava-kris-tyson-mr-beast-grooming-allegations-1851606782">Read more...</a></p>

## Five Years Later, Fire Emblem: Three Houses’ Best Character Is Still Edelgard
 - [https://kotaku.com/fire-emblem-three-houses-five-years-edelgard-switch-1851606712](https://kotaku.com/fire-emblem-three-houses-five-years-edelgard-switch-1851606712)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T19:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/b4ac7411446e36bafde38a18993f98b8.jpg" /><p>Amongst an impressive library of games like <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/the-legend-of-zelda-breath-of-the-wild-the-kotaku-rev-1792885174">Breath of the Wild</a>, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/super-mario-odyssey-the-kotaku-review-1819856086">Super Mario Odyssey</a>, and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/metroid-dread-the-kotaku-review-1847823602">Metroid Dread</a>, 2019’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/overpowering-my-way-through-fire-emblem-three-houses-i-1843288327">Fire Emblem: Three Houses</a> will still go down in my books as the best Nintendo Switch game ever made. It’s a grand fantasy story and an excellent tactical RPG that feels unmatch

## Another Game Just Got Review-Bombed Into Dropping Controversial Login Requirement
 - [https://kotaku.com/epic-account-edf6-earth-defense-force-steam-helldivers-1851606486](https://kotaku.com/epic-account-edf6-earth-defense-force-steam-helldivers-1851606486)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T17:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/81e19766b9f640b1e6791938b72e5e22.jpg" /><p>Good news! There’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/games/earth-defense-force-6">a new Earth Defense Force game</a> and it’s out now! Bad news, if you want to play the game online on Steam you’ll have to create an Epic Games account. This fact was revealed on launch day and went over so poorly with players that the devs behind the new giant bug-killin’ game are already announcing…</p><p><a href="https://kotaku.com/epic-account-edf6-earth-defense-force-steam-helldivers-1851606486">Read more...</a></p>

## Castle Crashers' First DLC In 12 Years Lets You Make Your Own Characters
 - [https://kotaku.com/castle-crashers-first-dlc-in-12-years-lets-you-make-you-1851606535](https://kotaku.com/castle-crashers-first-dlc-in-12-years-lets-you-make-you-1851606535)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T17:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/30f35a652e86589244375565b72f5c65.jpg" /><p>Castle Crashers was one of the first breakout indie darlings on Xbox 360 to show players the console’s Live Arcade wasn’t just a backwater for low-effort shovelware. The Behemoth’s Flash-animation-inspired arcade brawler became an instant classic, and over a decade later its getting its biggest DLC yet on PC.</p><p><a href="https://kotaku.com/castle-crashers-first-dlc-in-12-years-lets-you-make-you-1851606535">Read more...</a></p>

## Fallout 76: Minerva’s Location And Inventory: Late July, 2024
 - [https://kotaku.com/fallout-76-where-is-minerva-july-2024-inventory-1851606470](https://kotaku.com/fallout-76-where-is-minerva-july-2024-inventory-1851606470)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T17:20:39+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/794cdbbb76c6f283d20e9d8a3754477d.jpg" /><p>After the main story wraps up and you you reach Fallout 76's end-game, , you’ll have to find new ways to spend your time in Appalachia. Farming gold bullion is one such activity and it’s easily of the most common methods to eke out a few more hours in the post-apocalypse. It’s a valuable end-game currency that unlocks…</p><p><a href="https://kotaku.com/fallout-76-where-is-minerva-july-2024-inventory-1851606470">Read more...</a></p>

## House Of The Dragon Season 2 Episode 6 Recap: How To Ride Your Dragon
 - [https://kotaku.com/house-dragon-recap-season-2-episode-6-1851606523](https://kotaku.com/house-dragon-recap-season-2-episode-6-1851606523)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T17:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/3b7dad29d66bf33870c24c5b4868a1a6.jpg" /><p>Season two’s sixth episode in HBO’s chronicle of House Targaryen opens with the Lannister Army arriving at Golden Tooth and meeting with the surrendering Lord Lefford. But Jason Lannister isn’t progressing towards Harrenhal without Aemond joining the battle on Vhagar.<br /></p><p><a href="https://kotaku.com/house-dragon-recap-season-2-episode-6-1851606523">Read more...</a></p>

## Kotaku’s Weekend Guide: Six Games We Can't Wait To Get Back To
 - [https://kotaku.com/kotaku-games-to-play-yakuza-no-man-s-sky-cataclismo-1851606497](https://kotaku.com/kotaku-games-to-play-yakuza-no-man-s-sky-cataclismo-1851606497)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T17:07:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/f60080c74f88313f90489cfa57abc15a.jpg" /><p>July 2024 may be coming to a close, but it’s still summer weather out there for many of us. Which means you still have a great excuse to stay indoors where it’s cool and dark, and where electricity abundantly flows for us to power our gaming machines. </p><p><a href="https://kotaku.com/kotaku-games-to-play-yakuza-no-man-s-sky-cataclismo-1851606497">Read more...</a></p>

## How And Why You Should Farm Automatic Parts In Once Human
 - [https://kotaku.com/once-human-automatic-parts-farm-find-craft-1851606335](https://kotaku.com/once-human-automatic-parts-farm-find-craft-1851606335)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e05bcc9fe991c3a3ca03356d98b00953.jpg" /><p>At first glance, it feels like Once Human gift wraps every resource for you. They’re abundantly available across most zones, allowing you to craft to your heart’s content and construct the base of your dreams. But that’s not the case the deeper you move into the game. As you reach mid-game and end-game content, you’ll…</p><p><a href="https://kotaku.com/once-human-automatic-parts-farm-find-craft-1851606335">Read more...</a></p>

## Gran Turismo 7 Update Breaks Cars, Turns Them Into Wacky Missiles
 - [https://kotaku.com/gt7-gran-turismo-7-flying-cars-patch-1-49-fix-ps5-ps4-1851606294](https://kotaku.com/gt7-gran-turismo-7-flying-cars-patch-1-49-fix-ps5-ps4-1851606294)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T16:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/89abcb3ef19536475bd0b1173b5d2158.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/games/gran-turismo-7">Gran Turismo 7</a>'s most recent update was meant to improve and tweak the racing sim’s car physics. But something went wrong (or right, depending on how wacky you like your racing games), leading to flying cars and an apology from the devs. </p><p><a href="https://kotaku.com/gt7-gran-turismo-7-flying-cars-patch-1-49-fix-ps5-ps4-1851606294">Read more...</a></p>

## Elden Ring Streamer Beats Final Erdtree Boss On Dance Pad And Controller At The Same Time
 - [https://kotaku.com/elden-ring-missmikkaa-erdtree-boss-fight-dance-pad-1851606332](https://kotaku.com/elden-ring-missmikkaa-erdtree-boss-fight-dance-pad-1851606332)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T15:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/71c7cf9f68084e16a8fba3921282f283.jpg" /><p>I literally <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/elden-ring-weird-alternate-controllers-challenge-runs-1851605466">just cataloged a bunch of cool ways</a> that <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/games/elden-ring">Elden Ring</a> players have managed to beat several of the game’s tough boss fights, and now we’ve got a new one to add to the pile. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/elden-ring-twitch-ps5-pc-dancepad-missmikkaa-malenia-1850032182">MissMikkaa</a>, a streamer who’s made a name for herself completing Elden Ring challenge runs—especially on a dance pad—has repeated a…</p><p><a href="https://kotaku.com/elden-ring-missmikkaa-erdtree-boss-fight-dance-pad-1851606332">Read more...</a></p>

## The Top 10 Worst Pokémon Of All Time
 - [https://kotaku.com/pokemon-top-10-worst-bruxish-mr-rime-1851606325](https://kotaku.com/pokemon-top-10-worst-bruxish-mr-rime-1851606325)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T15:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/386aaad9053ebc5c5d5a2e1ba34df620.jpg" /><p>We love Pokémon. We think they’re gorgeous. But not all Pokémon are equal. Some are absolutely, unequivocally, awful. Here are the top ten Pokémon that make me want to shiver off my own skin.</p><p><a href="https://kotaku.com/pokemon-top-10-worst-bruxish-mr-rime-1851606325">Read more...</a></p>

## How To Get Fallout 76’s Best Shotgun
 - [https://kotaku.com/fallout-76-gauss-shotgun-find-craft-vendor-1851606238](https://kotaku.com/fallout-76-gauss-shotgun-find-craft-vendor-1851606238)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/cd607f3c217a1b400372160ac7452e5b.jpg" /><p>As you become more powerful with every passing level in Fallout 76, you’ll find that more than the average weaponry is needed. You’ll come to want more. You’ll want more potent shotguns and rifles capable of delivering one-hit critical shots to take down the game’s most formidable enemies. Well, few guns compare to…</p><p><a href="https://kotaku.com/fallout-76-gauss-shotgun-find-craft-vendor-1851606238">Read more...</a></p>

## The BioShock Movie Is Still In The Works, But Will Be ‘Much Smaller’ Than Originally Planned
 - [https://kotaku.com/netflix-bioshock-movie-adaptation-budget-lowered-1851606225](https://kotaku.com/netflix-bioshock-movie-adaptation-budget-lowered-1851606225)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T14:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/b217b25f792cd2f155ae86b9fe8974fe.jpg" /><p>It’s been a while since we got news of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/bioshock-movie-netflix-2k-take-two-infinite-irrational-1848544010">Netflix’s BioShock adaptation</a>, but we finally have an update thanks to <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/san-diego-comic-con-2023-cosplay-best-star-wars-games-1850670819">San Diego Comic-Con</a>. During a panel at the convection, producer Roy Lee revealed that, yes the movie is still happening, but it won’t be exactly as it was originally intended due to recent budget cuts at…</p><p><a href="https://kotaku.com/netflix-bioshock-movie-adaptation-budget-lowered-1851606225">Read more...</a></p>

## Grand Theft Auto 6 Is Exempt From The Game Actors Strike
 - [https://kotaku.com/grand-theft-auto-vi-gta6-voice-actor-strike-saf-aftra-1851606082](https://kotaku.com/grand-theft-auto-vi-gta6-voice-actor-strike-saf-aftra-1851606082)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-26T13:56:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/716551b7f5cd97716f58bd8d9ca42550.jpg" /><p>SAG-AFTRA game actors are <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/voice-actor-strike-sag-aftra-troy-baker-ai-cod-mw-3-1851604153?rev=1721999744031">currently on strike</a> against some of the biggest companies in the industry over AI, but that won’t impact the most anticipated games of 2025: Grand Theft Auto VI. It’s one of several in-development projects that is exempt from the labor action. </p><p><a href="https://kotaku.com/grand-theft-auto-vi-gta6-voice-actor-strike-saf-aftra-1851606082">Read more...</a></p>

