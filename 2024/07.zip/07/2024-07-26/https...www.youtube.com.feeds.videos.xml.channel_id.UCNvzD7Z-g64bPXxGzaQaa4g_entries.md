# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## XBOX RESPONDS TO PS5'S SUCCESS, HUGE GAME DELAYED & MORE
 - [https://www.youtube.com/watch?v=rXwRUaVZB6Q](https://www.youtube.com/watch?v=rXwRUaVZB6Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-07-26T17:17:20+00:00

Thank you Incogni for sponsoring this video. Use code gameranx at https://incogni.com/gameranx to get an exclusive 60% off an annual Incogni plan.

Another PS5 Pro leak, Fallout London releases, video game voice actors go on strike, and more in a week chock full of gaming news.




~~SOURCES~~


XBOX RESPONDS TO PS5'S SUCCESS
https://www.marketingweek.com/xboxs-marketing-boss-fight-funds/

PS5 PRO GRAPHICS LEAK
https://www.reddit.com/r/PS5/comments/1e8qhgf/rumor_suggests_that_the_ps5_pro_while_primarily/
https://press-start.com.au/news/playstation/2024/07/23/no-mans-skys-ps5-pro-enhancements-have-seemingly-been-discovered/

Voice actor strike
https://www.washingtonpost.com/entertainment/video-games/2024/07/25/sag-aftra-video-game-strike/

Stalker 2 delayed once more
https://x.com/stalker_thegame/status/1816435698007699568


Soul Reaver 1&2 remastered?
https://resetera.com/threads/legacy-of-kain-soul-reaver-i-ii-remastered-branding-seen-at-sdcc.937002/…

Rise of the Ronin demo (PS5)
ht

