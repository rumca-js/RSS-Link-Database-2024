# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Open Source AI Has Founders—and the FTC—Buzzing
 - [https://www.wired.com/story/open-source-ai-y-combinator](https://www.wired.com/story/open-source-ai-y-combinator)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2024-07-26T21:56:06+00:00

DC went to YC to talk OS.

