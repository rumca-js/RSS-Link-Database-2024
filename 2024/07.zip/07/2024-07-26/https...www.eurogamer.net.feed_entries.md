# Source:Eurogamer.net Latest Articles Feed, URL:https://www.eurogamer.net/feed, language:en-gb

## PSA: This weekend is your last chance to buy from the Xbox 360 online marketplace
 - [https://www.eurogamer.net/psa-this-weekend-is-your-last-chance-to-buy-from-the-xbox-360-online-marketplace](https://www.eurogamer.net/psa-this-weekend-is-your-last-chance-to-buy-from-the-xbox-360-online-marketplace)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T14:25:38+00:00

<img src="https://assetsio.gnwcdn.com/Armored-Core-Verdict-Day-36-2150650.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>This is your friendly reminder that Microsoft is set to <a href="https://www.eurogamer.net/xbox-360-digital-store-will-close-next-july">close its Xbox 360 digital store on 29th July</a> &ndash; that's next Monday &ndash; so you have just a few days left to make the most of those last discounts on some of the best Xbox 360 games of the generation.</p><p><a href="https://www.eurogamer.net/xbox-360-digital-store-gets-swathe-of-discounts-ahead-of-closure">Microsoft announced a raft of discounts on Xbox 360 digital games</a> back in May. Whilst some games will live on via other platforms and services &ndash; including Microsoft's comprehensive backwards compatibility system &ndash; there are a handful of games that will disappear from sale forever. So, if you've ever fancied one, now's the time to pick it up.</p><p>X user

## PlayStation live-service Concord won't sell you a battle pass - but would it be more successful if it did?
 - [https://www.eurogamer.net/eurogamer-newscast-playstation-live-service-concord-wont-sell-battle-pass-but-better-if-it-did](https://www.eurogamer.net/eurogamer-newscast-playstation-live-service-concord-wont-sell-battle-pass-but-better-if-it-did)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T13:56:28+00:00

<img src="https://assetsio.gnwcdn.com/CONCORD-SITE.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
This week on the <a href="https://www.eurogamer.net/topics/newscast">Eurogamer Newscast</a>, we discuss the downsides and upsides of the video game battle pass.
</p><p>In a week where PlayStation live-service hopeful <a href="https://www.eurogamer.net/sonys-next-live-service-sci-fi-shooter-concord-wont-have-a-battle-pass">Concord trumpeted the fact it won't sell you a battle pass as a marketing beat</a>, and <a href="https://www.eurogamer.net/apex-legends-studio-u-turns-on-controversial-real-money-battle-pass-changes">Apex Legends dialled back (some of) its battle pass changes</a> following fan fury, we consider the options available to video game makers hoping to ensure their latest releases keep being played - and paid for - well after release.</p><p>Would more people play Concord if it was a free-to-play title with a battle pass? Or is

## GTA 6 unaffected by video game acting strike, contract terms appear to state
 - [https://www.eurogamer.net/gta-6-unaffected-by-video-game-acting-strike-contract-terms-appear-to-state](https://www.eurogamer.net/gta-6-unaffected-by-video-game-acting-strike-contract-terms-appear-to-state)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T12:31:50+00:00

<img src="https://assetsio.gnwcdn.com/Grand-Theft-Auto-VI-Trailer-1-1-18-screenshot.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Yesterday's dramatic announcement of <a href="https://www.eurogamer.net/us-video-game-performers-are-striking-over-ongoing-ai-concerns">strike action by video game actors over AI concerns</a> may have less of an immediate impact on upcoming titles than first thought. 
</p><p>
While the SAG-AFTRA union has indeed voted for voice artists and performance capture personnel to strike from today, a large swathe of projects now appear unaffected. 
</p><p>
This includes any video game in development as of a year ago, including (for now) live service games, according to statements from both SAG-AFTRA and the companies the strike will hit, obtained by Kotaku reporter <a href="https://x.com/ethangach/status/1816797825444753673">Ethan Gach</a>.
</p> <p><a href="https://www.eurogamer.net/gta-6-unaffected-by-video-game-

## Paradox CEO admits it "made the wrong calls in several projects", following cancellation of Life By You
 - [https://www.eurogamer.net/paradox-ceo-admits-it-made-the-wrong-calls-in-several-projects-following-cancellation-of-life-by-you](https://www.eurogamer.net/paradox-ceo-admits-it-made-the-wrong-calls-in-several-projects-following-cancellation-of-life-by-you)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T12:30:34+00:00

<img src="https://assetsio.gnwcdn.com/life-by-you_pMBSdBh.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
CEO of Paradox Fredrik Wester has admitted the publisher "made the wrong calls in several projects", following the cancellation of its The Sims competitor Life By You.
</p><p>
The <a href="https://www.eurogamer.net/paradox-shuts-down-life-by-you-studio-following-sims-likes-sudden-cancellation">game was cancelled back in June</a>, and the internal studio behind the project, Paradox Tectonic, was closed.

</p><p>
Wester commented on Life By You as part of Paradox's <a href="https://www.paradoxinteractive.com/investors/financial-reports/interim-report-january-june-2024-correction">latest financial earnings report</a>, stating the cancellation was a "difficult decision... as the game would not be able to meet our expectations."
</p> <p><a href="https://www.eurogamer.net/paradox-ceo-admits-it-made-the-wrong-calls-in-several-projects-fol

## No Rest for the Wicked update revamps its Crucible roguelite endgame mode
 - [https://www.eurogamer.net/no-rest-for-the-wicked-update-revamps-its-crucible-roguelite-endgame-mode](https://www.eurogamer.net/no-rest-for-the-wicked-update-revamps-its-crucible-roguelite-endgame-mode)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T12:01:45+00:00

<img src="https://assetsio.gnwcdn.com/No-rest-for-the-wicked-header-image.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>No Rest for the Wicked developer Moon Studios has released its first new content update for the early access release.</p><p>Known as The Crucible update, it brings a "whole new Crucible" (seems fitting), as well as a new fungal enemy faction known as the Gloam, a new Exalted item status, the promise of "more visceral" combat and more.</p><p>You can check out a little teaser for the update in the video below.</p> <p><a href="https://www.eurogamer.net/no-rest-for-the-wicked-update-revamps-its-crucible-roguelite-endgame-mode">Read more</a></p>

## Netflix's BioShock adaptation will be a "more personal" film "as opposed to a grander, big project"
 - [https://www.eurogamer.net/netflixs-bioshock-adaptation-will-be-a-more-personal-film-as-opposed-to-a-grander-big-project](https://www.eurogamer.net/netflixs-bioshock-adaptation-will-be-a-more-personal-film-as-opposed-to-a-grander-big-project)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T11:25:36+00:00

<img src="https://assetsio.gnwcdn.com/best-twists-pc-games-1-bioshock.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p><a href="https://www.eurogamer.net/companies/netflix">Netflix</a>'s BioShock adaptation has been "reconfigured" to be a "more personal" film with a tighter budget.</p><p>That's according to producer Roy Lee, who told fans at a panel at San Diego Comic-Con that changes at the top of Netflix's movie department have seen the budget streamlined.</p><p>"The new regime has lowered the budgets," Lee added, as reported by <a href="https://variety.com/2024/film/news/bioshock-movie-scaled-down-netflix-more-personal-1236085711/">Variety</a>.</p> <p><a href="https://www.eurogamer.net/netflixs-bioshock-adaptation-will-be-a-more-personal-film-as-opposed-to-a-grander-big-project">Read more</a></p>

## UK actors' union Equity stands "in solidarity" with SAG-AFTRA but won't authorise its own strike
 - [https://www.eurogamer.net/uk-actors-union-equity-stands-in-solidarity-with-sag-aftra-but-wont-authorise-its-own-strike](https://www.eurogamer.net/uk-actors-union-equity-stands-in-solidarity-with-sag-aftra-but-wont-authorise-its-own-strike)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T11:11:48+00:00

<img src="https://assetsio.gnwcdn.com/equity-strike-image.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
UK actors' union Equity stands "in solidarity" with SAG-AFTRA following news of a strike, though won't be authorising a strike itself.
</p><p>
Yesterday, the <a href="https://www.eurogamer.net/us-video-game-performers-are-striking-over-ongoing-ai-concerns">US actors' union announced a strike after failing to reach a deal with major video game companies over the use of AI</a> following "more than a year and a half of negotiations".

</p><p>
"Equity stands in total solidarity with SAG-AFTRA who have taken the brave decision to authorise a strike against US video games companies," reads a <a href="https://www.equity.org.uk/campaigns-policy/international-work/solidarity-statement-advice-regarding-sag-aftra-interactive-media-industrial-action-2024">statement from Equity</a> assistant general secretary John Barclay. 
</p> <p><a href="htt

## The Garden Path offers a purposefully slow escape
 - [https://www.eurogamer.net/the-garden-path-offers-a-purposefully-slow-escape](https://www.eurogamer.net/the-garden-path-offers-a-purposefully-slow-escape)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T11:00:00+00:00

<img src="https://assetsio.gnwcdn.com/The-Garden-Path-Header.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>The Garden Path begins with a message asking you to be careful when foraging plants in the real world and, as someone who spent their teenage years living in the middle of nowhere, trust me when I say this is good advice. (Sometimes you have to make your own fun, but eating too much marsh samphire can churn your stomach.) It's also fitting advice from a game where foraging plays a major role in cultivating your garden. You'll venture out into the storybook-styled wildness, snipping plant cuttings or collecting flower buds, before finding the right place to plant your seedlings and watch them grow.</p><p>Though, even with this knowledge in mind, the first hours of The Garden Path do feel a little directionless. Sure a tutorial will pop up occasionally and there's a hint about a mysterious note, but neither provide much overall gui

## Coral Island developer blames Humble Games layoffs for leaving Switch port "in a place of uncertainty"
 - [https://www.eurogamer.net/coral-island-developer-blames-humble-games-layoffs-for-leaving-switch-port-in-a-place-of-uncertainty](https://www.eurogamer.net/coral-island-developer-blames-humble-games-layoffs-for-leaving-switch-port-in-a-place-of-uncertainty)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T10:24:45+00:00

<img src="https://assetsio.gnwcdn.com/Coral-Island---Early-Access-Launch-Trailer-_-4K-1-44-screenshot.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Coral Island developer Stairway Games has responded to the lack of Switch port, blaming the <a href="https://www.eurogamer.net/humble-games-confirms-restructuring-amid-reports-all-staff-have-been-laid-off">recent layoffs at Humble Games</a> for leaving console versions "in a place of uncertainty".

</p><p>
The cosy life-sim game received over $1.6m in <a href="https://www.kickstarter.com/projects/coralisland/coral-island-reimagining-the-farm-sim-game/faqs">Kickstarter funding</a>. However, some backers who specifically backed the game for a Switch version are angry at the lack of news for a port. Other backers have claimed requests for PS4 keys have been automatically upgraded to PS5 without consent.
</p><p>
At present, the game is available on PC via Steam, PlayStation 5 and Xbox Series 

## Gaming's most serious racing sim Gran Turismo 7 has a seriously funny bug
 - [https://www.eurogamer.net/gamings-most-serious-racing-sim-gran-turismo-7-has-a-seriously-funny-bug](https://www.eurogamer.net/gamings-most-serious-racing-sim-gran-turismo-7-has-a-seriously-funny-bug)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T10:14:08+00:00

<img src="https://assetsio.gnwcdn.com/Screenshot-2024-07-26-at-11.07.11.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Is it a bird? Is it a plane? No! It's a car in Gran Turismo 7.</p><p>Gran Turismo 7 players have flocked to social media to share examples of, uh, unusual driving physics after the racer's 1.49 update added a new setting that seemingly fills vehicles with helium.</p><p>Where developer Polyphony Digital had hoped to introduce <a href="https://blog.playstation.com/2024/07/24/gran-turismo-7-update-1-49-brings-six-new-cars-updated-physics-simulation-model-and-more-on-july-24/">"more natural weight"</a> for players, cars are instead launching themselves into the air, making for some extraordinarily amusing clips:</p> <p><a href="https://www.eurogamer.net/gamings-most-serious-racing-sim-gran-turismo-7-has-a-seriously-funny-bug">Read more</a></p>

## Dragon Age: The Veilguard will be Steam native, so you don't need the dreaded EA App
 - [https://www.eurogamer.net/dragon-age-the-veilguard-will-be-steam-native-so-you-dont-need-the-dreaded-ea-app](https://www.eurogamer.net/dragon-age-the-veilguard-will-be-steam-native-so-you-dont-need-the-dreaded-ea-app)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T10:04:50+00:00

<img src="https://assetsio.gnwcdn.com/Untitled-1_JC1NdU3.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
In a pleasantly surprising move, BioWare will launch <a href="https://www.eurogamer.net/whisper-it-but-dragon-age-the-veilguard-has-me-thinking-the-unthinkable-it-looks-like-bioware-is-back">Dragon Age: The Veilguard</a> natively via Steam on PC, meaning there's no need to download and install the fussy EA App. 
</p><p>
What's more, the game will arrive verified for Steam Deck, so you can continue your quest to defend Thedas while on the bus, train or toilet. 
</p><p>
"There's a few more surprises in store for later this summer," BioWare's Michael Gamble <a href="https://x.com/GambleMike/status/1816514374670168113">teased</a> via social media platform X, sharing the news. "Here's the first from the DAV team."
</p> <p><a href="https://www.eurogamer.net/dragon-age-the-veilguard-will-be-steam-native-so-you-dont-need-the-dreaded-ea-app"

## What we've been playing - oil rigs, court cases, and great adaptations
 - [https://www.eurogamer.net/what-weve-been-playing-oil-rigs-court-cases-and-great-adaptations](https://www.eurogamer.net/what-weve-been-playing-oil-rigs-court-cases-and-great-adaptations)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T10:00:00+00:00

<img src="https://assetsio.gnwcdn.com/Amazon-Fallout-Lucy-Maximus.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Hello! Welcome back to our regular feature where we write a little bit about some of the games we've been playing over the past few days. This week we enjoy poking around spooky oil rigs, we object in dramatic court cases, and we discover what we love about a game series through a TV adaptation of it.</p><p>What have you been playing?</p><p>Catch up with the older editions of this column in our <a href="https://www.eurogamer.net/topics/what-weve-been-playing">What We've Been Playing archive</a>.</p> <p><a href="https://www.eurogamer.net/what-weve-been-playing-oil-rigs-court-cases-and-great-adaptations">Read more</a></p>

## Nobody Wants to Die review - a noiry cyberpunk tale told beautifully
 - [https://www.eurogamer.net/nobody-wants-to-die-review](https://www.eurogamer.net/nobody-wants-to-die-review)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-07-26T09:09:23+00:00

<img src="https://assetsio.gnwcdn.com/nobody-wants-to-die-review-header.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Sometimes a game comes along and sucker punches you right in the gut. You can be completely aware of the premise going in, but some element of the setting or the mechanics takes a broader theme or commentary and makes it deeply, intensely personal. Papers, Please got me like that. My job at the time involved identity verification and, while it was nowhere near as life or death as the game, it still made it all too real, too visceral. Dragon Age: Inquisition completely caught me off guard, with NPC reactions to my Qunari Inquisitor feeling way too close to my experiences as a very visible trans woman.</p><p>Nobody Wants to Die is a work of dystopian science fiction, so I was expecting some hard hitting moments. I'm hardly the first person to point out that the last few years have felt increasingly like living in a cyber

