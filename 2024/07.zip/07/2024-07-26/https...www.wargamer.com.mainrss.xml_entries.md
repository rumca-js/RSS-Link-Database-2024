# Source:Wargamer, URL:https://www.wargamer.com/mainrss.xml, language:en-US

## Best free strategy games 2024
 - [https://www.wargamer.com/free-strategy-games](https://www.wargamer.com/free-strategy-games)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-07-26T16:25:19+00:00

<img alt="Best free strategy games 2024" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2022/05/best-free-strategy-games.jpg" title="Best free strategy games 2024" width="1920" />
								<p>What are the <strong>best free strategy games</strong> to play? Well, you know what, playing only <a href="https://www.wargamer.com/free-card-games-online">free card games</a> or <a href="https://www.wargamer.com/free-war-games">free war games</a> is a good strategy for saving money, so your mind is obviously well-built for these kinds of challenges. We’ve got a bunch of awesome game suggestions for you,  so buckle yourself up, and prepare to discover your new favorite.</p>
<p>The best free strategy games can often stand as tall as the games you pay for these days. Just because a game is free-to-play, doesn’t mean that it is also free from quality. Indeed, this list has entries from really well-known and respected strategy IPs in it, such as <a

## Get this bestselling, dark fantasy Warhammer RPG at 70% off
 - [https://www.wargamer.com/warhammer-fantasy-roleplay/rpg-deal-core-rulebook-starter-set](https://www.wargamer.com/warhammer-fantasy-roleplay/rpg-deal-core-rulebook-starter-set)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-07-26T16:09:26+00:00

<img alt="Get this bestselling, dark fantasy Warhammer RPG at 70% off" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/07/warhammer-fantasy-roleplay-deal-core-book-starter-set.jpg" title="Get this bestselling, dark fantasy Warhammer RPG at 70% off" width="1920" />
								<p>If you love tabletop RPGs and old-school Games Workshop grunge, but haven't played <strong>Warhammer Fantasy Roleplay</strong>, now is an excellent time to change that - as the 4th edition core rulebook and starter set are both available at heavy discounts in the current DriveThruRPG sale.</p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/warhammer-fantasy-roleplay/rpg-deal-core-rulebook-starter-set">Get this bestselling, dark fantasy Warhammer RPG at 70% off</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com/warhammer-the-old-world/release-date">Warhammer: The Old World latest news</a>, <a href="https://www.wargame

## Wizards spills on how DnD 2024’s new Origin Feats work
 - [https://www.wargamer.com/dnd/2024-origin-feats](https://www.wargamer.com/dnd/2024-origin-feats)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-07-26T14:05:11+00:00

<img alt="Wizards spills on how DnD 2024’s new Origin Feats work" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/07/dnd-2024-origin-feats-characters.jpg" title="Wizards spills on how DnD 2024’s new Origin Feats work" width="1920" />
								<p>We already knew that <strong>DnD 2024</strong> was making characters’ backgrounds just as mechanically important as their choice of Species (a.k.a. race). But, thanks to a new design explainer published by Wizards on Thursday, we now have a lot more details, including all ten ‘<strong>Origin Feats</strong>’ you can get from your background when rolling a new character.</p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/dnd/2024-origin-feats">Wizards spills on how DnD 2024’s new Origin Feats work</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com/dnd/classes">DnD classes guide</a>, <a href="https://www.wargamer.com/dnd/races">DnD races guide</a>, <

## MTG rules change won’t break infinite combo, decrees designer
 - [https://www.wargamer.com/magic-the-gathering/mtg-rules-change-neheb-infinite-combo](https://www.wargamer.com/magic-the-gathering/mtg-rules-change-neheb-infinite-combo)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-07-26T14:03:09+00:00

<img alt="MTG rules change won’t break infinite combo, decrees designer" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/07/mtg-neheb-art.jpg" title="MTG rules change won’t break infinite combo, decrees designer" width="1920" />
								<p>A minor rules change coming in with the next Magic: The Gathering set Bloomburrow was all set to have disastrous consequences for a classic commander. But now Wizards of the Coast has made a change to preserve the status quo. There&rsquo;s some really&nbsp;dry rules discussion required to explain this, so let&rsquo;s try and breeze through &hellip; <a href="https://www.wargamer.com/magic-the-gathering/mtg-rules-change-neheb-infinite-combo">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/magic-the-gathering/mtg-rules-change-neheb-infinite-combo">MTG rules change won’t break infinite combo, decrees designer</a>
				</div>
				MORE FROM WARGAMER: <a href="http

## Arcane MTG card sees 200% price spike after tanking hard
 - [https://www.wargamer.com/magic-the-gathering/goryos-vengeance-spikes](https://www.wargamer.com/magic-the-gathering/goryos-vengeance-spikes)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-07-26T11:25:45+00:00

<img alt="Arcane MTG card sees 200% price spike after tanking hard" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/07/goryos-vengeance-background.jpg" title="Arcane MTG card sees 200% price spike after tanking hard" width="1920" />
								<p>The MTG card Goryo&rsquo;s Vengeance has shot back up in price after taking a significant hit to its value in the months before and after Modern Horizons 3&rsquo;s release. The card was down to $9 by the end of June, but over the last three weeks, has steadily clambered back up to its previous heights, &hellip; <a href="https://www.wargamer.com/magic-the-gathering/goryos-vengeance-spikes">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/magic-the-gathering/goryos-vengeance-spikes">Arcane MTG card sees 200% price spike after tanking hard</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com/magic-the-gathering/mtg-sets-in-order">All MTG

