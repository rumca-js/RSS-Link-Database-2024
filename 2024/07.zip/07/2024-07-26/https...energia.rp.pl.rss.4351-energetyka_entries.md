# Source:Energetyka, URL:https://energia.rp.pl/rss/4351-energetyka, language:pl-PL

## Eksplozja na największym złożu Rosneftu. Jedna osoba nie żyje, szaleje pożar
 - [https://energia.rp.pl/gaz/art40873441-eksplozja-na-najwiekszym-zlozu-rosneftu-jedna-osoba-nie-zyje-szaleje-pozar](https://energia.rp.pl/gaz/art40873441-eksplozja-na-najwiekszym-zlozu-rosneftu-jedna-osoba-nie-zyje-szaleje-pozar)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-07-26T17:01:29+00:00

Do nieoczekiwanego wybuchu doszło na największym polu gazowym koncernu Rosnieft na Półwyspie Jamalskim. Na miejscu zginął jeden pracownik, siedmiu zostało rannych. Złoże płonie.

## Węgry twierdzą, że Ukraina je „szantażuje”. Proszą Unię Europejską o pomoc
 - [https://energia.rp.pl/ropa/art40872041-wegry-twierdza-ze-ukraina-je-szantazuje-prosza-unie-europejska-o-pomoc](https://energia.rp.pl/ropa/art40872041-wegry-twierdza-ze-ukraina-je-szantazuje-prosza-unie-europejska-o-pomoc)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-07-26T12:58:08+00:00

Blisko współpracownik premiera Węgier oskarżył Ukrainę o szantażowanie Węgier i Słowacji poprzez wstrzymanie dostaw ropy po tym, jak kraje te przestały otrzymywać ropę od rosyjskiej grupy Łukoil.

## Masowe zwolnienia w kopalniach? Były wiceminister publikuje okrojone pismo
 - [https://energia.rp.pl/wegiel/art40870961-masowe-zwolnienia-w-kopalniach-byly-wiceminister-publikuje-okrojone-pismo](https://energia.rp.pl/wegiel/art40870961-masowe-zwolnienia-w-kopalniach-byly-wiceminister-publikuje-okrojone-pismo)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-07-26T11:14:52+00:00

W Polskiej Grupie Górniczej w ramach zwolnień grupowych ma odejść z pracy 435 pracowników. Były wiceminister w rządzie PiS Michał Woś pisze o fali zwolnień. Okazuje się jednak, że chodzi o pracowników, którzy nabyli prawo do emerytury.

## W Polsce jest miejsce na cztery elektrownie jądrowe. Pewna jest tylko jedna
 - [https://energia.rp.pl/atom/art40870751-w-polsce-jest-miejsce-na-cztery-elektrownie-jadrowe-pewna-jest-tylko-jedna](https://energia.rp.pl/atom/art40870751-w-polsce-jest-miejsce-na-cztery-elektrownie-jadrowe-pewna-jest-tylko-jedna)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-07-26T10:50:33+00:00

Pełnomocnik rządu ds. strategicznej infrastruktury energetycznej Maciej Bando poinformował, że do 2040 r. w polskim systemie elektroenergetycznym jest miejsce na 12 GW mocy z elektrowni jądrowych. Jednak nadal rząd zakłada budowę od 6-9 GW.

## Chiński sen Gazpromu. Rosja przyparta do muru
 - [https://energia.rp.pl/surowce-i-paliwa/art40870731-chinski-sen-gazpromu-rosja-przyparta-do-muru](https://energia.rp.pl/surowce-i-paliwa/art40870731-chinski-sen-gazpromu-rosja-przyparta-do-muru)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-07-26T09:11:11+00:00

W 2025 r. Rosja planuje zwiększyć dostawy gazu do Chin rurociągiem Siła Syberii do 38 mld m sześc. – poinformował rosyjski wiceminister energetyki Siergiej Moczalnikow. To oznaczałoby pełne wykorzystanie mocy gazociągu. Wciąż nie wiadomo jednak, czy powstanie druga nitka. Chińczycy stawiają Rosjanom trudne warunki, wygląda na to, że niespecjalnie zależy im na projekcie. Tymczasem Gazprom boryka się z dużymi problemami finansowymi.

