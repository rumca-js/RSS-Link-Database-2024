# Source:Raspberry Pi - More than just magic mirrors and kodi!, URL:https://www.reddit.com/r/raspberry_pi/.rss, language:en

## Fun, portable and learning.
 - [https://www.reddit.com/r/raspberry_pi/comments/1eculrd/fun_portable_and_learning](https://www.reddit.com/r/raspberry_pi/comments/1eculrd/fun_portable_and_learning)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-07-26T17:59:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/raspberry_pi/comments/1eculrd/fun_portable_and_learning/"> <img alt="Fun, portable and learning." src="https://preview.redd.it/mbitm3x1kwed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e25db39281a27c4c91d3a604c15ba9b7b008c8d6" title="Fun, portable and learning." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hopefully this doesn't break rule one as there is a show and tell flair. GPi case 2 with a CM4(WiFi,lite,2GB ram) used for mostly Gameboy advance and SNES games. Clockwork with a CM4(WiFi, lite, 4GB ram) used for debugging environmental sensors I work with. CM4(lite, 2GB ram) used for ssh practice and will get influxdb server set up on it for sensor data upload maybe a sense hat as well. Pi5(8GB ram) in a argon case booting off a NVMe drive used for intellij idea which is used in the Python course I'm doing. </p> <p>I can see myself getting a lot of daughter boards to try different data gathering and upload methods. </p

## Help: RPI 5 need working virtual keyboard for touchscreen
 - [https://www.reddit.com/r/raspberry_pi/comments/1ecpkk4/help_rpi_5_need_working_virtual_keyboard_for](https://www.reddit.com/r/raspberry_pi/comments/1ecpkk4/help_rpi_5_need_working_virtual_keyboard_for)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-07-26T14:32:34+00:00

<!-- SC_OFF --><div class="md"><p>I have a Raspberry PI 5. I have tried Raspian and KDE Plasma and I cannot get a virtual keyboard to work with the touchscreen. I can load Onboard, but it takes focus so I can never enter text into the target app, text box, etc. I also tried Ubuntu but it refuses to fully load properly. Which virtual keyboard can I use? Is one recognized by KDE system as a virtual keyboard in the settings? Any help would really be appreciated. Thank you so much in advance for constructive help and suggestions.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jackboxer"> /u/jackboxer </a> <br /> <span><a href="https://www.reddit.com/r/raspberry_pi/comments/1ecpkk4/help_rpi_5_need_working_virtual_keyboard_for/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/raspberry_pi/comments/1ecpkk4/help_rpi_5_need_working_virtual_keyboard_for/">[comments]</a></span>

## xfce4 not working (help...)
 - [https://www.reddit.com/r/raspberry_pi/comments/1eco68l/xfce4_not_working_help](https://www.reddit.com/r/raspberry_pi/comments/1eco68l/xfce4_not_working_help)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-07-26T13:31:58+00:00

<!-- SC_OFF --><div class="md"><p>so i used the pi imager and installed pi os lite on mi pi 5 and then i used sudo tasksel to install xfce desktop, it installed successfully then when i rebooted nothing happend, i was just back in pi os lite.</p> <p>then i tried installing xfce4 with commands, had the same problem nothing just happend when i rebooted.</p> <p>the commands:</p> <p>sudo apt update<br /> sudo apt upgrade<br /> sudo apt install xserver-xorg<br /> sudo apt install xfce4 xfce4-terminal<br /> sudo apt install lightdm</p> <p>so i would be very happy if someone could help me</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mediocre-Rent-6719"> /u/Mediocre-Rent-6719 </a> <br /> <span><a href="https://www.reddit.com/r/raspberry_pi/comments/1eco68l/xfce4_not_working_help/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/raspberry_pi/comments/1eco68l/xfce4_not_working_help/">[comments]</a></span>

## My pi build!( made from 3d printed case and my old laptop fan)
 - [https://www.reddit.com/r/raspberry_pi/comments/1eckzja/my_pi_build_made_from_3d_printed_case_and_my_old](https://www.reddit.com/r/raspberry_pi/comments/1eckzja/my_pi_build_made_from_3d_printed_case_and_my_old)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-07-26T10:44:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/raspberry_pi/comments/1eckzja/my_pi_build_made_from_3d_printed_case_and_my_old/"> <img alt="My pi build!( made from 3d printed case and my old laptop fan)" src="https://b.thumbs.redditmedia.com/UQRyxOnp0BY7G7nu6IzGq-j7WwOgyfjW9c_6sBT3SVI.jpg" title="My pi build!( made from 3d printed case and my old laptop fan)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CreativeBuilds23"> /u/CreativeBuilds23 </a> <br /> <span><a href="https://www.reddit.com/gallery/1eckzja">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/raspberry_pi/comments/1eckzja/my_pi_build_made_from_3d_printed_case_and_my_old/">[comments]</a></span> </td></tr></table>

## How do I configure an OLED on Bookworm to list hardware stats?
 - [https://www.reddit.com/r/raspberry_pi/comments/1ecjyjo/how_do_i_configure_an_oled_on_bookworm_to_list](https://www.reddit.com/r/raspberry_pi/comments/1ecjyjo/how_do_i_configure_an_oled_on_bookworm_to_list)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-07-26T09:37:13+00:00

<!-- SC_OFF --><div class="md"><p>I need help as I just upgraded from Bullseye to Bookworm, but I broke my OLED display screen on one of those geekpi tower cases that come with the screens. It was all working fine on Raspbian 64bit Bullseye, it would list the CPU usage, how much disk space I had and how much I had free, the CPU temp and IP address. </p> <p>Now on bookworm it does not work and I cannot find any guides or info if anyone has gotten them to work on bookworm. Before I used a combination of youtube vids and how to guides such as the below for example. Anyone had luck or can provide me with commands I can run to get it working again please?</p> <p><a href="https://www.youtube.com/watch?v=G-WA-V_yzTg">https://www.youtube.com/watch?v=G-WA-V_yzTg</a></p> <p><a href="https://www.instructables.com/Raspberry-Pi-Monitoring-System-Via-OLED-Display-Mo/">https://www.instructables.com/Raspberry-Pi-Monitoring-System-Via-OLED-Display-Mo/</a></p> <p><a href="https://www.the-diy-life.com/a

## Weather Display With An e-Paper Screen
 - [https://www.reddit.com/r/raspberry_pi/comments/1ecckrj/weather_display_with_an_epaper_screen](https://www.reddit.com/r/raspberry_pi/comments/1ecckrj/weather_display_with_an_epaper_screen)
 - RSS feed: https://www.reddit.com/r/raspberry_pi/.rss
 - date published: 2024-07-26T02:05:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/raspberry_pi/comments/1ecckrj/weather_display_with_an_epaper_screen/"> <img alt="Weather Display With An e-Paper Screen" src="https://external-preview.redd.it/VY8JQ0yi834IYcawIS--s3YqEGI51bLP2aVs5XyHtrE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2d4b05281cdc4ca807241cc78a39cc4d39bd9b73" title="Weather Display With An e-Paper Screen" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JayTongue"> /u/JayTongue </a> <br /> <span><a href="https://imgur.com/a/cs8lSbr">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/raspberry_pi/comments/1ecckrj/weather_display_with_an_epaper_screen/">[comments]</a></span> </td></tr></table>

