# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Deadpool & Wolverine & Walking4Hope
 - [https://www.youtube.com/watch?v=XfD4F9E3yX0](https://www.youtube.com/watch?v=XfD4F9E3yX0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2024-07-26T18:59:58+00:00

In Vancouver to watch @WxmAFCofficial play tomorrow. Incredibly proud #DeadpoolAndWolverine seems to be bringing millions of people to the theater. Sports and movies bring us together so posting a gentle reminder that none of us are alone. #MaximumEffort #Walking4Hope @BathMan.Dadpool 

Learn more & how you can support #Walking4Hope here: https://www.walking4hope.org/

