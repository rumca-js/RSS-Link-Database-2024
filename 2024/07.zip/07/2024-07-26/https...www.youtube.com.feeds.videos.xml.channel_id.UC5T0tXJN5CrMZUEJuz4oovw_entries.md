# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## Deadpool & Wolvierine REVIEW, M-She-U OVER? Gina v Disney | Friday Night Tights 312 w Raz0rfist
 - [https://www.youtube.com/watch?v=woFel-wkYFo](https://www.youtube.com/watch?v=woFel-wkYFo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2024-07-26T19:26:04+00:00

With Special Guest:  Raz0rfist @TheRageaholic 

Nerdrotic Art Contest!
We are looking for talented artists to draw 2-3 pages of comic panels in the Nerdrotic biography. To enter, we want to see 3 examples of Gary happy, angry, and confused. All entries should be sent to nerdroticart@gmail.com. Contest closes Friday August 16 at 11:59 PM Central.

Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Streamlab Donations: https://streamlabs.com/sutrowatchtower/tip

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsor:
Order your Med Kit today at http://twc.health/wonder - code NERDROTIC saves you 10% + FREE SHIPPING at checkout

Sponsored by Gamer Supps
https://gamersupps.gg/Nerdrotic

Sponsored by MetaPCs!
https://www.metapcs.com/creator-nerdrotic/

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/collections

