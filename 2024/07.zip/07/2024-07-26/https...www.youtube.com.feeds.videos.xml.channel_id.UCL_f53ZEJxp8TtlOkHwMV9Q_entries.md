# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## How to Obtain Meaning In Your Life
 - [https://www.youtube.com/watch?v=Dn0TIJpcqjc](https://www.youtube.com/watch?v=Dn0TIJpcqjc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-07-26T23:00:08+00:00



## Limited pre-enrollment to Peterson Academy is available now at petersonacademy.com
 - [https://www.youtube.com/watch?v=dWQ4f5IQFRQ](https://www.youtube.com/watch?v=dWQ4f5IQFRQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-07-26T22:53:04+00:00



## You Need to Grow Up
 - [https://www.youtube.com/watch?v=7Wogm9R4GYM](https://www.youtube.com/watch?v=7Wogm9R4GYM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-07-26T21:00:03+00:00



## The Liberalization of Contraception | Mary Harrington
 - [https://www.youtube.com/watch?v=iTHuvyHpMNs](https://www.youtube.com/watch?v=iTHuvyHpMNs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-07-26T17:00:28+00:00

This is a clip from yesterday's podcast episode with Mary Harrington. In it, she and Dr. Peterson discuss the advent of commercial birth control, it's benefits and potential net negatives.

Dr. Peterson's extensive catalog is available now on DailyWire+: https://bit.ly/3KrWbS8

ALL LINKS: https://linktr.ee/drjordanbpeterson


// COURSES //
Discovering Personality: https://jordanbpeterson.com/personality
Self Authoring Suite: https://selfauthoring.com
Understand Myself (personality test): https://understandmyself.com

// BOOKS //
Beyond Order: 12 More Rules for Life: https://jordanbpeterson.com/Beyond-Order
12 Rules for Life: An Antidote to Chaos: https://jordanbpeterson.com/12-rules-for-life
Maps of Meaning: The Architecture of Belief: https://jordanbpeterson.com/maps-of-meaning

#JordanPeterson #JordanBPeterson #DrJordanPeterson #DrJordanBPeterson #DailyWirePlus

