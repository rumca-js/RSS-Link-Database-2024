# Source:TIME - tech, URL:https://time.com/tech/feed, language:en-UK

## Kamala Harris Debuts Her New TikTok Account
 - [https://time.com/7003817/kamala-harris-tiktok-personal-account-youth-voters-china-ban](https://time.com/7003817/kamala-harris-tiktok-personal-account-youth-voters-china-ban)
 - RSS feed: https://time.com/tech/feed
 - date published: 2024-07-26T05:30:00+00:00

The Vice President, who is already a viral topic on TikTok, launched her own personal account, despite the looming threat of a U.S. ban on the platform over security concerns.

