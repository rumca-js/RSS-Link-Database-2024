# Source:DAILYSABAH - Turkey News, URL:https://www.dailysabah.com/rssFeed/10, language:en-US

## Caravan boom brings parking, environmental problems to Turkish cities
 - [https://www.dailysabah.com/turkiye/caravan-boom-brings-parking-environmental-problems-to-turkish-cities/news](https://www.dailysabah.com/turkiye/caravan-boom-brings-parking-environmental-problems-to-turkish-cities/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-26T09:32:00+00:00

The surge in caravan use during the COVID-19 pandemic has led to increased parking issues in some areas, with local residents expressing concerns over caravans occupying public spa...

## Türkiye's new clinical facility starts lymphoma smart drug trials
 - [https://www.dailysabah.com/turkiye/turkiyes-new-clinical-facility-starts-lymphoma-smart-drug-trials/news](https://www.dailysabah.com/turkiye/turkiyes-new-clinical-facility-starts-lymphoma-smart-drug-trials/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-26T09:25:00+00:00

Ankara University's Phase 1 Clinical Research Center, recently opened in July, has become one of the first centers to start screening for an international 'smart drug' study t...

## Red light reveals loggerhead nesting boom in Türkiye's Antalya
 - [https://www.dailysabah.com/turkiye/red-light-reveals-loggerhead-nesting-boom-in-turkiyes-antalya/news](https://www.dailysabah.com/turkiye/red-light-reveals-loggerhead-nesting-boom-in-turkiyes-antalya/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-26T08:52:00+00:00

In the Kızılot region of Antalya in western Türkiye, endangered loggerhead sea turtles (Caretta caretta) have been recorded laying eggs on the beach. The recordings were made using...

## Manavgat's wildlife rebounds three years post-fire in S Türkiye
 - [https://www.dailysabah.com/turkiye/manavgats-wildlife-rebounds-three-years-post-fire-in-s-turkiye/news](https://www.dailysabah.com/turkiye/manavgats-wildlife-rebounds-three-years-post-fire-in-s-turkiye/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-26T08:44:00+00:00

Three years after the catastrophic fire that ravaged Manavgat in Antalya's district in southern Türkiye, wildlife in the affected areas is showing signs of recovery, as reveal...

