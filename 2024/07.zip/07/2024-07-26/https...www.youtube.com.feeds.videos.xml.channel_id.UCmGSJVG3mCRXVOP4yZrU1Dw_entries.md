# Source:John Harris, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw, language:en-US

## $25,000 vs. $25,000,000
 - [https://www.youtube.com/watch?v=NfMdvee5HoY](https://www.youtube.com/watch?v=NfMdvee5HoY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw
 - date published: 2024-07-26T12:00:25+00:00

Earning $25,000 vs. $25,000,000 Lifestyles, Compared
Click https://headspace-web.app.link/e/JHS to try Headspace for free using my code JOHNNY60.

What does it looks like to earn $25,000 a year vs. $25,000,000 a year? Let me show you.

Check out all my sources for this video here: https://docs.google.com/document/d/10OwOsB6X7eBn5nUq8iRq6vrEy_8yGRix_mDtGQZVFK0/edit?usp=drive_link

Check out my new channel with Sam Ellis - Search Party: https://youtube.com/@Search-Party

Get access to behind-the-scenes vlogs, my scripts, and extended interviews over at https://www.patreon.com/johnnyharris

Do you have an insider tip or unique information on a story? Do you have a suggestion for a story you want us to cover? Submit to the Tip Line: https://docs.google.com/forms/d/e/1FAIpQLSdpNs1ykIwd7KNkwntN897X_SX9hJ8WiTH_erlLU_bQp2GGLg/viewform?usp=sharing

I made a poster about maps - check it out: https://store.dftba.com/products/all-maps-are-wrong-poster

Custom Presets & LUTs [what we use]: https:/

