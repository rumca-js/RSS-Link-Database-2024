# Source:Home Repair Tutor, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA, language:en

## Cutting Holes in Porcelain Tile - #shorts #homerepairtutor
 - [https://www.youtube.com/watch?v=3W2mSQPbSt4](https://www.youtube.com/watch?v=3W2mSQPbSt4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA
 - date published: 2024-07-26T11:00:07+00:00



