# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## THE DOWNFALL OF LINKEDIN - PROFESSIONAL NETWORK TO CLOWNSHOW
 - [https://www.youtube.com/watch?v=n39A4928-Os](https://www.youtube.com/watch?v=n39A4928-Os)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2024-07-26T12:00:51+00:00

Go to https://invideo.io/i/JoshuaFluke and use my code JOSHUAFLUKE50 to get twice the number of video generation credits in your first month!

❤️ Support my content! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://joshuafluke.store/

👊 Join the community! 
https://discord.gg/Joshuafluke

Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke


Discover LinkedIn's transformation from a professional network to a clown show. We'll explore cringe-worthy posts, underpaid job offers, and the absurdity now defining the platform. If you're looking for real insights amidst the chaos, this video is for you.

