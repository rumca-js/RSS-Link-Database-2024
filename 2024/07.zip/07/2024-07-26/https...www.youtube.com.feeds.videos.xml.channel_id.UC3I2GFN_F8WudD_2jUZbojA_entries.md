# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## OUT NOW: The UK's Squid Live on KEXP
 - [https://www.youtube.com/watch?v=xWBKV_Mtylk](https://www.youtube.com/watch?v=xWBKV_Mtylk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-07-26T16:30:21+00:00



## Squid - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=5FtmMGy8KxI](https://www.youtube.com/watch?v=5FtmMGy8KxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-07-26T15:00:08+00:00

http://KEXP.ORG presents Squid performing live in the KEXP studio. February 26, 2024

Songs:
Swing (In A Dream) 00:26
Undergrowth 05:37
The Blades 14:39

Oliver Judge - Vocals, Drums
Louis Borlase - Guitar, Vocals
Arthur Leadbetter - Percussion, Keys
Laurie Nankivell - Cornet, Electronics
Anton Pearson - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs & Jon Roberts
Guest Audio Engineer: Alessandra Urso
Mastering Engineer: Matt Ogaz

Cameras: Jim Beckmann,Carlos Cruz,  Scott Holpainen, Jonathan Jacobson & Kendall Rock
Editor: Jim Beckmann

https://www.squidband.uk
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Squid - Undergrowth (Live on KEXP)
 - [https://www.youtube.com/watch?v=umF7XPT_bso](https://www.youtube.com/watch?v=umF7XPT_bso)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-07-26T11:00:53+00:00

http://KEXP.ORG presents Squid performing "Undergrowth" live in the KEXP studio. February 26, 2024

Oliver Judge - Vocals, Drums
Louis Borlase - Guitar, Vocals
Arthur Leadbetter - Percussion, Keys
Laurie Nankivell - Cornet, Electronics
Anton Pearson - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs & Jon Roberts
Guest Audio Engineer: Alessandra Urso
Mastering Engineer: Matt Ogaz

Cameras: Jim Beckmann,Carlos Cruz,  Scott Holpainen, Jonathan Jacobson & Kendall Rock
Editor: Jim Beckmann

https://www.squidband.uk
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Squid - The Blades (Live on KEXP)
 - [https://www.youtube.com/watch?v=f8ryfnO-Y-s](https://www.youtube.com/watch?v=f8ryfnO-Y-s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-07-26T11:00:45+00:00

http://KEXP.ORG presents Squid performing "The Blades" live in the KEXP studio. February 26, 2024

Oliver Judge - Vocals, Drums
Louis Borlase - Guitar, Vocals
Arthur Leadbetter - Percussion, Keys
Laurie Nankivell - Cornet, Electronics
Anton Pearson - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs & Jon Roberts
Guest Audio Engineer: Alessandra Urso
Mastering Engineer: Matt Ogaz

Cameras: Jim Beckmann,Carlos Cruz,  Scott Holpainen, Jonathan Jacobson & Kendall Rock
Editor: Jim Beckmann

https://www.squidband.uk
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Squid - Swing In A Dream (Live on KEXP)
 - [https://www.youtube.com/watch?v=-VPP-YeNLD4](https://www.youtube.com/watch?v=-VPP-YeNLD4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-07-26T11:00:00+00:00

http://KEXP.ORG presents Squid performing "Swing In A Dream" live in the KEXP studio. February 26, 2024

Oliver Judge - Vocals, Drums
Louis Borlase - Guitar, Vocals
Arthur Leadbetter - Percussion, Keys
Laurie Nankivell - Cornet, Electronics
Anton Pearson - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs & Jon Roberts
Guest Audio Engineer: Alessandra Urso
Mastering Engineer: Matt Ogaz

Cameras: Jim Beckmann,Carlos Cruz,  Scott Holpainen, Jonathan Jacobson & Kendall Rock
Editor: Jim Beckmann

https://www.squidband.uk
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

