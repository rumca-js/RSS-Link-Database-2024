# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Mercedes profits plunge amid waning electric car sales
 - [https://www.telegraph.co.uk/business/2024/07/26/ftse-100-markets-latest-mercedes-electric-car-pce-inflation](https://www.telegraph.co.uk/business/2024/07/26/ftse-100-markets-latest-mercedes-electric-car-pce-inflation)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2024-07-26T06:23:47+00:00



