# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## ‘Behemoth’: Mega-plane to end stopovers
 - [https://www.news.com.au/travel/travel-advice/flights/qantas-give-sneak-peak-into-game-changing-mega-plane-a350-set-to-shake-up-australian-travel/news-story/b4ce2570f1253289497344a40666249d?from=rss-basic](https://www.news.com.au/travel/travel-advice/flights/qantas-give-sneak-peak-into-game-changing-mega-plane-a350-set-to-shake-up-australian-travel/news-story/b4ce2570f1253289497344a40666249d?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-07-26T03:20:23.659881+00:00

It’s the ultra-long haul route that’s set to change the game for Aussie travellers. Now, a bold feature has been unveiled.

