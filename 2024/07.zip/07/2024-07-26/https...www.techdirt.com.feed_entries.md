# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## The Kids Online Safety Act And The Tyranny Of Laziness
 - [https://www.techdirt.com/2024/07/26/the-kids-online-safety-act-and-the-tyranny-of-laziness](https://www.techdirt.com/2024/07/26/the-kids-online-safety-act-and-the-tyranny-of-laziness)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-07-26T20:38:55+00:00

There is some confusion about whether the Kids Online Safety Act (KOSA) regulates content or design on digital platforms like Instagram or TikTok. It’s easy to see why that is, because the bill’s authors claim they are attempting to make the bill about design. This is a good move on their part, as regulations on [&#8230;]

## Ctrl-Alt-Speech: Live At TrustCon 2024
 - [https://www.techdirt.com/2024/07/26/ctrl-alt-speech-live-at-trustcon-2024](https://www.techdirt.com/2024/07/26/ctrl-alt-speech-live-at-trustcon-2024)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-07-26T19:10:10+00:00

Ctrl-Alt-Speech is a weekly podcast about the latest news in online speech, from Mike Masnick and Everything in Moderation&#8216;s Ben Whitelaw. Subscribe now on Apple Podcasts, Overcast, Spotify, Pocket Casts, YouTube, or your podcast app of choice — or go straight to the RSS feed. In the first ever live recording of Ctrl-Alt-Speech, Mike and [&#8230;]

## Spain Is Using AI For Domestic Violence Risk Assessment And It’s Going As Well As You’d Expect
 - [https://www.techdirt.com/2024/07/26/spain-is-using-ai-for-domestic-violence-risk-assessment-and-its-going-as-well-as-youd-expect](https://www.techdirt.com/2024/07/26/spain-is-using-ai-for-domestic-violence-risk-assessment-and-its-going-as-well-as-youd-expect)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-07-26T17:44:24+00:00

There are some decent uses of AI. And then there&#8217;s everything else. While those with horses in the AI race continue to proclaim the miracles their horses will soon be performing at some indefinite point in the future, a whole lot of entities just see AI as a way to shed human capital and replace [&#8230;]

## Daily Deal: The Raspberry Pi And Arduino Bootcamp Bundle
 - [https://www.techdirt.com/2024/07/26/daily-deal-the-raspberry-pi-and-arduino-bootcamp-bundle-3](https://www.techdirt.com/2024/07/26/daily-deal-the-raspberry-pi-and-arduino-bootcamp-bundle-3)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-07-26T17:41:04+00:00

The Raspberry Pi and Arduino Bootcamp Bundle has 5 courses to help you dive into the world of hands-on programming. Courses cover Arduino, Raspberry Pi, and ROS2. It&#8217;s on sale for $30. Note: The Techdirt Deals Store is powered and curated by StackCommerce. A portion of all sales from Techdirt Deals helps support Techdirt. The [&#8230;]

## KOSA Will Come To The Senate Floor On Tuesday, Senators Paul & Wyden Explain Why It’s Still Bad
 - [https://www.techdirt.com/2024/07/26/kosa-will-come-to-the-senate-floor-on-tuesday-senators-paul-wyden-explain-why-its-still-bad](https://www.techdirt.com/2024/07/26/kosa-will-come-to-the-senate-floor-on-tuesday-senators-paul-wyden-explain-why-its-still-bad)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-07-26T16:32:00+00:00

On Thursday, as expected, the Senate voted for “cloture” on the extremely problematic Kids Online Safety Act (KOSA). The cloture vote is a procedural vote necessary to bring a full vote to the floor. Previously, attempts to move KOSA forward “by unanimous consent” could be (and were) blocked by objections from at least one Senator [&#8230;]

## FCC Votes To Make Phone Unlocking Easier
 - [https://www.techdirt.com/2024/07/26/fcc-votes-to-make-phone-unlocking-easier](https://www.techdirt.com/2024/07/26/fcc-votes-to-make-phone-unlocking-easier)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-07-26T12:30:00+00:00

With a unanimous 5-0 vote, the FCC says it is moving forward with plans that should make unlocking your mobile phone easier than ever. According to a new FCC announcement, the agency say it will begin crafting new rules that will require that wireless carriers unlock customers’ mobile phones within 60days of activation. At various [&#8230;]

## Lamar Jackson, Troy Aikman Fight Over ‘EIGHT’ Trademark, Showing The Absurdity Of Modern Trademark
 - [https://www.techdirt.com/2024/07/25/lamar-jackson-troy-aikman-fight-over-eight-trademark-showing-the-absurdity-of-modern-trademark](https://www.techdirt.com/2024/07/25/lamar-jackson-troy-aikman-fight-over-eight-trademark-showing-the-absurdity-of-modern-trademark)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-07-26T03:00:54+00:00

For the non-sports loving crowd out there, here is something of a necessary primer. Lamar Jackson is the reigning MVP of the National Football League. He plays for the Baltimore Ravens and wears number eight. Troy Aikman is a hall of fame former NFL quarterback that played for the Dallas Cowboys and wore, you guessed [&#8230;]

