# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Ryan Leslie: Tiny Desk Concert
 - [https://www.youtube.com/watch?v=K8VetbXWbFM](https://www.youtube.com/watch?v=K8VetbXWbFM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2024-07-26T09:00:29+00:00

Bobby Carter | July 26, 2024
Ryan Leslie was in go mode as he arrived at NPR headquarters after an early morning road trip from New York. He bounced all over the space even when the cameras weren’t rolling. I was curious to hear how he would take his big, synth-heavy sound and adapt it to the Tiny Desk, but then was quickly reminded that at his core, he’s a creator. Leslie made songs like “Diamond Girl,” “How It Was Supposed To Be” and Cassie’s “Long Way 2 Go,” so to watch him recreate them here with ease shouldn’t have been a surprise.

After writing and producing Cassie’s debut album and hits for others, the singer-songwriter and entrepreneur decided to focus on being a solo artist. It’s not easy to go into a studio by yourself and walk out with a complete album, but R. Les is that artist. The viral video of him creating “Addiction” is remarkable proof. In 2013, he walked away from the traditional music industry, removing his music from streaming services and created a new platform 

