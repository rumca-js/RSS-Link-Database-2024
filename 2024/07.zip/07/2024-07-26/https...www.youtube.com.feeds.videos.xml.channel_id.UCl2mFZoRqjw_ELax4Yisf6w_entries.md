# Source:Louis Rossmann, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Splice DMCA strikes @TopMusicAttorneyfor reading terms of service to censor LEGITIMATE criticism 🤦
 - [https://www.youtube.com/watch?v=IToSiBBz_38](https://www.youtube.com/watch?v=IToSiBBz_38)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2024-07-26T00:01:11+00:00

https://splice.com/sounds
https://splice.com/blog/generate-certified-license/
https://splice.com/terms
https://privacy.com/
https://www.youtube.com/@TopMusicAttorney/videos
https://www.youtube.com/watch?v=W7ble2EeGCs
https://www.youtube.com/watch?v=U1iDB05vNYY
https://www.youtube.com/watch?v=ocF_hrr83Oc
https://www.youtube.com/watch?v=_QNMVMlx48E
https://x.com/jakepalumbo
https://www.youtube.com/watch?v=XP8EFgq_ETU
https://www.youtube.com/watch?v=BVKhW9pzmYQ
https://www.youtube.com/watch?v=uVB7pLXxcdE
https://www.youtube.com/watch?v=uSW0Wg32QNI&amp;t=85s

👉 Merchandise: https://store.rossmanngroup.com/memes-dreams.html
🔵 Cheesy mugs & t-shirts: https://bit.ly/rossmannstore

👉 Rossmann chat: https://matrix.to/#/#rossmannrepair:matrix.org

👉 Recording equipment used upstairs:
🔵 HDMI capture: https://amzn.to/4bcXEFL
🔵 Camera: https://amzn.to/3VVkSLW
🔵 Black AT4050 Microphone: https://amzn.to/4cAdkUi
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Bad mic stand for AT4050 mic: https://amzn.t

