# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Elon Musk said his trans child was ‘dead.’ She’s calling him out.
 - [https://www.washingtonpost.com/business/2024/07/26/musk-transgender-vivian-grimes](https://www.washingtonpost.com/business/2024/07/26/musk-transgender-vivian-grimes)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-07-26T21:17:23+00:00

Vivian Jenna Wilson, Elon Musk’s estranged daughter, disputes his characterization of her childhood.

## Not everything Big Tech touches turns to gold
 - [https://www.washingtonpost.com/technology/2024/07/26/apple-google-amazon-unpopular-unprofitable-products](https://www.washingtonpost.com/technology/2024/07/26/apple-google-amazon-unpopular-unprofitable-products)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-07-26T16:30:00+00:00

Apple TV Plus has fewer viewers than PBS and Vudu. Google’s smartphones sell poorly. And yet they persist.

## False rumors about Vance, Musk’s X show misinfo cuts both ways
 - [https://www.washingtonpost.com/technology/2024/07/26/jd-vance-couch-twitter-whitelist-fake](https://www.washingtonpost.com/technology/2024/07/26/jd-vance-couch-twitter-whitelist-fake)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-07-26T10:05:55+00:00

Elon Musk has pulled back on policing falsehoods. That doesn’t only hurt liberals.

