# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Mapa zamkniętych kąpielisk. Nad Bałtykiem tylko jedna czerwona flaga
 - [https://wydarzenia.interia.pl/kraj/news-mapa-zamknietych-kapielisk-nad-baltykiem-tylko-jedna-czerwon,nId,7719000](https://wydarzenia.interia.pl/kraj/news-mapa-zamknietych-kapielisk-nad-baltykiem-tylko-jedna-czerwon,nId,7719000)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-07-26T13:31:22+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mapa-zamknietych-kapielisk-nad-baltykiem-tylko-jedna-czerwon,nId,7719000"><img align="left" alt="Mapa zamkniętych kąpielisk. Nad Bałtykiem tylko jedna czerwona flaga" src="https://i.iplsc.com/mapa-zamknietych-kapielisk-nad-baltykiem-tylko-jedna-czerwon/000JIZV514JD7X3O-C321.jpg" /></a>Wybierając się na wakacje, warto sprawdzić, czy kąpieliska, w których mamy zamiar się kąpać, nie są akurat zamknięte. Dzieje się tak z różnych powodów: zakwit sinic, bakterie, czy prace remontowe. Obecnie w Polsce zamkniętych jest około 20 kąpielisk, ale ta liczba wciąż się zmienia. Szczegółowe informacje znajdują się na wirtualnej mapie GIS.  </p><br clear="all" />

## Co z legalizacją związków partnerskich? Najnowszy sondaż
 - [https://wydarzenia.interia.pl/kraj/news-co-z-legalizacja-zwiazkow-partnerskich-najnowszy-sondaz,nId,7723287](https://wydarzenia.interia.pl/kraj/news-co-z-legalizacja-zwiazkow-partnerskich-najnowszy-sondaz,nId,7723287)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-07-26T12:21:04+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-co-z-legalizacja-zwiazkow-partnerskich-najnowszy-sondaz,nId,7723287"><img align="left" alt="Co z legalizacją związków partnerskich? Najnowszy sondaż" src="https://i.iplsc.com/co-z-legalizacja-zwiazkow-partnerskich-najnowszy-sondaz/000JIZI5P0UD82KQ-C321.jpg" /></a>90 proc. ankietowanych jest za legalizacją związków partnerskich, jeśli parę tworzy kobieta i mężczyzna. W przypadku osób tej samej płci, &quot;za&quot; jest 52 proc. badanych. Ankietowani byli względnie zgodni co do praw, jakie powinna dawać partnerom taka regulacja. Jak wynika z badania CBOS, stosunek Polaków do związków partnerskich zmienił się diametralnie w ciągu ostatnich lat. </p><br clear="all" />

## Ukraińskie dzieci mogą stracić 800 plus. Zmiany od nowego roku szkolnego
 - [https://wydarzenia.interia.pl/kraj/news-ukrainskie-dzieci-moga-stracic-800-plus-zmiany-od-nowego-rok,nId,7722951](https://wydarzenia.interia.pl/kraj/news-ukrainskie-dzieci-moga-stracic-800-plus-zmiany-od-nowego-rok,nId,7722951)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-07-26T05:30:25+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ukrainskie-dzieci-moga-stracic-800-plus-zmiany-od-nowego-rok,nId,7722951"><img align="left" alt="Ukraińskie dzieci mogą stracić 800 plus. Zmiany od nowego roku szkolnego" src="https://i.iplsc.com/ukrainskie-dzieci-moga-stracic-800-plus-zmiany-od-nowego-rok/000JIXGRRLNJQ3A4-C321.jpg" /></a>Ukraińskie dzieci w Polsce zostały objęte obowiązkiem szkolnym. Od września trzeba znaleźć miejsce dla dodatkowych 80 tys. osób, co spędza sen z powiek dyrektorom szkół. Rząd reaguje, zwiększając limity osób w klasach. Zmiany dotyczą również przedszkoli. </p><br clear="all" />

