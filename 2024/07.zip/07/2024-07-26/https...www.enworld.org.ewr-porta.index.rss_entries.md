# Source:EN World Tabletop RPG News & Reviews, URL:https://www.enworld.org/ewr-porta/index.rss, language:en

## 19 New Feats For Elemental Adventurers
 - [https://www.enworld.org/threads/19-new-feats-for-elemental-adventurers.705713](https://www.enworld.org/threads/19-new-feats-for-elemental-adventurers.705713)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-07-26T16:25:00+00:00

<div class="bbWrapper">Get an elemental familiar, resist the elements, clear the air, or become the mountain.</div>

## WotC Removes Digital Content Team Credits From D&D Beyond
 - [https://www.enworld.org/threads/wotc-removes-digital-content-team-credits-from-d-d-beyond.705711](https://www.enworld.org/threads/wotc-removes-digital-content-team-credits-from-d-d-beyond.705711)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-07-26T13:23:00+00:00

<div class="bbWrapper">The team was responsible for content feedback and the implementation of book content on the online platform.</div>

## Dragon Reflections #77
 - [https://www.enworld.org/threads/dragon-reflections-77.703642](https://www.enworld.org/threads/dragon-reflections-77.703642)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-07-26T12:30:00+00:00

<div class="bbWrapper">Dragon Publishing released Dragon #77 in September 1983. It is 84 pages long and has a cover price of $3.00.</div>

## Dark Horse Comics Signs Deal with Wizards of the Coast
 - [https://www.enworld.org/threads/dark-horse-comics-signs-deal-with-wizards-of-the-coast.705704](https://www.enworld.org/threads/dark-horse-comics-signs-deal-with-wizards-of-the-coast.705704)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-07-26T04:59:00+00:00

<div class="bbWrapper">New Dungeons &amp; Dragons and Magic: The Gathering comics coming in 2025</div>

