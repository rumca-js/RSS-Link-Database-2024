# Source:Magia Natury, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCfDX69pxC4q6yKSaugs196g, language:pl

## Gadożer Pożera Żmiję (DRASTYCZNE)
 - [https://www.youtube.com/watch?v=s4v23USsPrE](https://www.youtube.com/watch?v=s4v23USsPrE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCfDX69pxC4q6yKSaugs196g
 - date published: 2024-07-26T16:00:50+00:00

Scenę tę zarejestrował turysta w afrykańskim parku Krugera. Jadowita żmija sykliwa pełznąc po jezdni została zaatakowana przez gadożera brunatnego. Ptak przygwoździł ją szponami, a następnie rozpoczął konsumpcję wciąż jeszcze żywego gada.

👉 Patronite ► https://patronite.pl/magia_natury
__________
Autor kanału nie rości sobie praw do materiałów wykorzystanych w filmie. Materiały wykorzystane są w ramach prawa dozwolonego użytku w celu zobrazowania, edukowania i lepszego zrozumienia zagadnienia lub pochodzą z serwisów udostępniających darmowe materiały.

The author of the channel does not claim any rights to the material used in the video. The materials are used under fair use law to illustrate, educate and better understand the issue, or they come from websites that provide free materials.

