# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## A Day in Old Paris in 1910s in color [60fps,Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=zdRBUBVuz_0](https://www.youtube.com/watch?v=zdRBUBVuz_0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2024-07-26T22:47:25+00:00

I colorized , restored and created a sound design for this rare video of View of the city of Paris in the summer of 1918, as well as in January 1919. Shows various districts and monuments of the city, including arrondissement I, arrondissement VI, arrondissement VIII, arrondissement IX, arrondissement XVI, Saint-Denis, the Latin Quarter Saint-Martin and others.

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔added sound design only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 
✔ Face Restoration


B&amp;W Video Source: Musée départemental Albert-Kahn dans le département des Hauts-de-Seine (Le Saint, Lucien)

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

- - - - - - - - - - - - - - - - - - - -
📨 Con

