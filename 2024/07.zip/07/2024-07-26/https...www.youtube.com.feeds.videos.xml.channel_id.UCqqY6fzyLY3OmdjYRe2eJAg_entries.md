# Source:Roosevelt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg, language:en-US

## 'IN THE DARK' - out July 30th 🔮 #counterrecords #newsong
 - [https://www.youtube.com/watch?v=470vZ_vRh44](https://www.youtube.com/watch?v=470vZ_vRh44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqqY6fzyLY3OmdjYRe2eJAg
 - date published: 2024-07-26T19:05:01+00:00

Subscribe: https://found.ee/rv-ys

Follow Roosevelt -
Spotify: https://found.ee/rv-sp
Apple Music: https://found.ee/rv-am
YouTube: https://found.ee/rv-yt
Bandcamp: https://found.ee/rv-bc
Soundcloud: https://found.ee/rv-sc
Instagram: https://found.ee/rv-ig
TikTok: https://found.ee/rv-tt
Facebook: https://found.ee/rv-fb
Twitter: https://found.ee/rv-tw

#Roosevelt #CounterRecords

