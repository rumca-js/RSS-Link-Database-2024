# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## Why Are GPUs So Big?
 - [https://www.youtube.com/watch?v=etGKFWZuKMY](https://www.youtube.com/watch?v=etGKFWZuKMY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2024-07-26T16:00:40+00:00

https://lmg.gg/secretlablmgclips
Thanks to Secretlab for being the title sponsor of LMG Clips this year! Check out their ergonomic gaming chairs at the link above. Your back will thank you!

Why are GPUs so big and why aren’t there more DIY GPUs? 

Watch the full WAN Show: https://www.youtube.com/watch?v=a-eAVVtkxDA

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## I was Right About the PS Portal
 - [https://www.youtube.com/watch?v=QyX3u4KQBE0](https://www.youtube.com/watch?v=QyX3u4KQBE0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2024-07-26T16:00:32+00:00

https://lmg.gg/secretlablmgclips
Thanks to Secretlab for being the title sponsor of LMG Clips this year! Check out their ergonomic gaming chairs at the link above. Your back will thank you!

The PS Portal still shows strong sales numbers eight months after launch. 

Watch the full WAN Show: https://www.youtube.com/watch?v=a-eAVVtkxDA

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

