# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Justin Timberlake 'was not intoxicated when arrested for drink-driving'
 - [https://news.sky.com/story/justin-timberlake-was-not-intoxicated-when-arrested-for-drink-driving-and-charge-should-be-dismissed-lawyer-says-13185607](https://news.sky.com/story/justin-timberlake-was-not-intoxicated-when-arrested-for-drink-driving-and-charge-should-be-dismissed-lawyer-says-13185607)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T21:18:00+00:00

Justin Timberlake was not intoxicated when he was arrested for drink-driving, his lawyer has said as he seeks to have the charge dismissed.

## El Chapo's son 'duped alleged cartel boss into flying to US before their arrests'
 - [https://news.sky.com/story/el-chapos-son-duped-alleged-cartel-boss-into-flying-to-us-before-their-arrests-13185580](https://news.sky.com/story/el-chapos-son-duped-alleged-cartel-boss-into-flying-to-us-before-their-arrests-13185580)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T20:00:00+00:00

An alleged Mexican drug cartel leader arrested in Texas was duped into flying to the US, officials have said.

## Trump attacks Kamala Harris's 'disrespectful' Gaza remarks as he hosts Netanyahu at Mar-a-Lago
 - [https://news.sky.com/story/trump-attacks-kamala-harriss-disrespectful-gaza-remarks-as-he-hosts-netanyahu-at-mar-a-lago-13185562](https://news.sky.com/story/trump-attacks-kamala-harriss-disrespectful-gaza-remarks-as-he-hosts-netanyahu-at-mar-a-lago-13185562)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T18:57:00+00:00

Donald Trump hosted Benjamin Netanyahu at his Florida resort as he dismissed reports of tensions between the pair and attacked Kamala Harris's "disrespectful" comments about the Gaza war.

## Olympics opening ceremony gets under way with starring roles for Lady Gaga and Zinedine Zidane
 - [https://news.sky.com/story/paris-2024-olympics-opening-ceremony-gets-under-way-with-starring-roles-for-lady-gaga-and-zinedine-zidane-13185552](https://news.sky.com/story/paris-2024-olympics-opening-ceremony-gets-under-way-with-starring-roles-for-lady-gaga-and-zinedine-zidane-13185552)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T18:01:00+00:00

Lady Gaga sang in French and played the piano as she performed at the Olympics opening ceremony on the banks of the River Seine.

## Star-studded Olympic Games opening ceremony gets under way - in pictures
 - [https://news.sky.com/story/star-studded-olympic-games-opening-ceremony-gets-underway-in-pictures-13185528](https://news.sky.com/story/star-studded-olympic-games-opening-ceremony-gets-underway-in-pictures-13185528)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T17:06:00+00:00

Celebrities and world leaders watched on as the opening ceremony of the Olympic Games got under way.

## Who would cause such chaos on France's rail network before the Olympics, and avoid claiming publicity?
 - [https://news.sky.com/story/paris-2024-who-would-cause-such-chaos-on-frances-train-networks-before-the-olympics-and-avoid-claiming-publicity-13185504](https://news.sky.com/story/paris-2024-who-would-cause-such-chaos-on-frances-train-networks-before-the-olympics-and-avoid-claiming-publicity-13185504)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T16:32:00+00:00

The shock caused by the arson attacks on France's railways came quickly and intensely.

## Are the Paris Olympics safe?
 - [https://news.sky.com/story/are-the-paris-olympics-safe-13185484](https://news.sky.com/story/are-the-paris-olympics-safe-13185484)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T15:56:00+00:00

As Paris prepares for the opening ceremony of the 2024 Olympic Games, arsonists have targeted France's high-speed rail network causing travel chaos.

## Athlete has part of finger amputated after wife warned against 'rash decision'
 - [https://news.sky.com/story/hockey-player-opts-to-have-part-of-finger-amputated-to-compete-at-paris-olympics-13185473](https://news.sky.com/story/hockey-player-opts-to-have-part-of-finger-amputated-to-compete-at-paris-olympics-13185473)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T15:39:00+00:00

A hockey player chose to have part of his finger amputated so he could compete at the Paris Olympics.

## 'Hideous' wax replica of Sinead O'Connor withdrawn by museum
 - [https://news.sky.com/story/wax-replica-of-sinead-oconnor-withdrawn-by-dublin-museum-after-criticism-of-hideous-likeness-13185394](https://news.sky.com/story/wax-replica-of-sinead-oconnor-withdrawn-by-dublin-museum-after-criticism-of-hideous-likeness-13185394)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T14:39:00+00:00

Sometimes nothing compares to the real thing - as Dublin's wax museum discovered after it unveiled a figure of Irish singer Sinead O'Connor.

## Spy-drone scandals to smoking violations: The Paris 2024 athletes and coaches facing controversies
 - [https://news.sky.com/story/spy-drone-scandals-to-smoking-violations-the-paris-2024-athletes-and-coaches-facing-controversies-13185383](https://news.sky.com/story/spy-drone-scandals-to-smoking-violations-the-paris-2024-athletes-and-coaches-facing-controversies-13185383)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T12:59:00+00:00

Before the starting pistol has officially been fired, the Paris 2024 Olympics has faced a number of controversies.

## Crocodiles take bodies of victims after gang massacre
 - [https://news.sky.com/story/papua-new-guinea-gang-massacre-homes-torched-victims-beheaded-and-bodies-taken-by-crocodiles-13185316](https://news.sky.com/story/papua-new-guinea-gang-massacre-homes-torched-victims-beheaded-and-bodies-taken-by-crocodiles-13185316)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T11:32:00+00:00

At least 26 people - most of them children - have been killed in a massacre in Papua New Guinea that saw three villages burnt to the ground, the heads of victims hacked off and some bodies taken by crocodiles.

## What your rights are if you can't travel to Paris Olympics
 - [https://news.sky.com/story/what-your-rights-are-if-you-cant-travel-to-paris-olympics-13185270](https://news.sky.com/story/what-your-rights-are-if-you-cant-travel-to-paris-olympics-13185270)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T10:19:00+00:00

Arson attacks on multiple French train lines have thrown people's trips to the Paris Olympics into doubt.

## 'Proud' Obama endorses Harris to take on Trump in race for the White House
 - [https://news.sky.com/story/proud-barack-obama-endorses-kamala-harris-to-take-on-donald-trump-in-white-house-race-13185179](https://news.sky.com/story/proud-barack-obama-endorses-kamala-harris-to-take-on-donald-trump-in-white-house-race-13185179)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T08:15:00+00:00

Former president Barack Obama told Kamala Harris he "couldn't be prouder" as he endorsed her to replace Joe Biden as the Democratic candidate for the US election.

## UK will not oppose right of ICC to issue arrest warrant for Netanyahu
 - [https://news.sky.com/story/uk-will-not-oppose-right-of-icc-to-issue-arrest-warrant-for-israeli-pm-netanyahu-says-no-10-13185164](https://news.sky.com/story/uk-will-not-oppose-right-of-icc-to-issue-arrest-warrant-for-israeli-pm-netanyahu-says-no-10-13185164)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T07:05:00+00:00

Sir Keir Starmer's Labour government will not pursue an objection to the International Criminal Court (ICC) issuing an arrest warrant for Israel's Prime Minister Benjamin Netanyahu.

## Fires hit rail lines across France - as minister says 'coordinated sabotage' timed for start of Olympics
 - [https://news.sky.com/story/vandals-target-paris-olympics-by-setting-fires-to-damage-high-speed-train-routes-13184855](https://news.sky.com/story/vandals-target-paris-olympics-by-setting-fires-to-damage-high-speed-train-routes-13184855)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T05:00:00+00:00

Vandals have carried out arson attacks on France's high-speed train network causing major travel disruption ahead of the Paris Olympics opening ceremony.

## 'Wall of fire': Wildfires rage across parts of US and Canada as thousands evacuated
 - [https://news.sky.com/story/wildfires-rage-across-parts-of-us-and-canada-as-one-town-ravaged-by-wall-of-fire-forcing-thousands-to-evacuate-13185125](https://news.sky.com/story/wildfires-rage-across-parts-of-us-and-canada-as-one-town-ravaged-by-wall-of-fire-forcing-thousands-to-evacuate-13185125)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T04:49:00+00:00

Wildfires have spread across parts of Canada and the US, forcing thousands of people to evacuate their homes.

## El Chapo's son and his former partner arrested for 'leading drug cartel'
 - [https://news.sky.com/story/mexican-drug-lord-el-chapos-son-and-his-former-partner-arrested-for-leading-drug-cartel-13185102](https://news.sky.com/story/mexican-drug-lord-el-chapos-son-and-his-former-partner-arrested-for-leading-drug-cartel-13185102)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-07-26T00:42:00+00:00

The son of the notorious Mexican drug lord Joaquin "El Chapo" Guzman has been arrested.

