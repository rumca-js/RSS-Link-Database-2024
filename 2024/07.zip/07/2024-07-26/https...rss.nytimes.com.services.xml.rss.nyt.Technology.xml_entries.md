# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## When A.I. Fails the Language Test, Who Is Left Out of the Conversation?
 - [https://www.nytimes.com/2024/07/26/technology/ai-language-gap.html](https://www.nytimes.com/2024/07/26/technology/ai-language-gap.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2024-07-26T09:40:11+00:00

The use of artificial intelligence is exploding around the world, but the technology’s language models are primarily trained in English, leaving many speakers of other languages behind.

## Kamala Harris’s Bratty Coconut Memescape + What Does $1,000 a Month Do? + The Empire CrowdStrikes Back
 - [https://www.nytimes.com/2024/07/26/podcasts/kamala-harriss-bratty-coconut-memescape-what-does-1000-a-month-do-the-empire-crowdstrikes-back.html](https://www.nytimes.com/2024/07/26/podcasts/kamala-harriss-bratty-coconut-memescape-what-does-1000-a-month-do-the-empire-crowdstrikes-back.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2024-07-26T09:06:23+00:00

An episode unburdened by what has been.

