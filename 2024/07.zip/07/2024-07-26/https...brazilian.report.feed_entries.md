# Source:The Brazilian Report, URL:https://brazilian.report/feed, language:en-US

## As Paris 2024 begins, a look at the legacy of Rio 2016 in Brazil
 - [https://brazilian.report/liveblog/olympics-2024/2024/07/26/paris-2024-olympics-rio-2016-legacy](https://brazilian.report/liveblog/olympics-2024/2024/07/26/paris-2024-olympics-rio-2016-legacy)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-07-26T17:17:11+00:00

<p>The most notable legacy of the 2016 Olympics might be the revitalization of parts of the city</p>
<p>The post <a href="https://brazilian.report/liveblog/olympics-2024/2024/07/26/paris-2024-olympics-rio-2016-legacy/">As Paris 2024 begins, a look at the legacy of Rio 2016 in Brazil</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## Congressman probed over Bolsonaro election fraud documents
 - [https://brazilian.report/liveblog/politics-insider/2024/07/26/congressman-ramagem-bolsonaro-election-documents](https://brazilian.report/liveblog/politics-insider/2024/07/26/congressman-ramagem-bolsonaro-election-documents)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-07-26T15:51:46+00:00

<p>Federal Police questioned Congressman Alexandre Ramagem, a former head of Brazil’s intelligence agency Abin, about documents found in his emails instructing former President Jair Bolsonaro to cast doubts about Brazil’s voting system. The information was revealed early on Friday by O Globo newspaper. The documents and Mr. Ramagem’s testimony to the Federal Police have not [&#8230;]</p>
<p>The post <a href="https://brazilian.report/liveblog/politics-insider/2024/07/26/congressman-ramagem-bolsonaro-election-documents/">Congressman probed over Bolsonaro election fraud documents</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## Is Nicolás Maduro ready to give up power in Venezuela?
 - [https://brazilian.report/latin-america/2024/07/26/nicolas-maduro-power-elections-venezuela](https://brazilian.report/latin-america/2024/07/26/nicolas-maduro-power-elections-venezuela)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-07-26T15:44:30+00:00

<p>The post <a href="https://brazilian.report/latin-america/2024/07/26/nicolas-maduro-power-elections-venezuela/">Is Nicolás Maduro ready to give up power in Venezuela?</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## A fintech is taking Brazil’s PIX to European markets
 - [https://brazilian.report/tech/2024/07/26/fintech-pix-european-markets](https://brazilian.report/tech/2024/07/26/fintech-pix-european-markets)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-07-26T14:02:14+00:00

<p>The post <a href="https://brazilian.report/tech/2024/07/26/fintech-pix-european-markets/">A fintech is taking Brazil&#8217;s PIX to European markets</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

