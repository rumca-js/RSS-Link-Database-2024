# Source:DistroTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCVls1GmFKf6WlTraIb_IaJg, language:en-US

## Chat With Patrons (Jul 28, 2024)
 - [https://www.youtube.com/watch?v=TfsNe7GWa-M](https://www.youtube.com/watch?v=TfsNe7GWa-M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCVls1GmFKf6WlTraIb_IaJg
 - date published: 2024-07-26T17:16:21+00:00

This Video Chat will be for my Patrons!  Patrons can join the video call via Zoom which is available on Linux, Mac and Windows.  For those wishing to join the chat but are not a Patron, consider joining my Patreon ( https://www.patreon.com/distrotube ).  I will post a link to the Zoom chat on my Patreon page a few minutes prior to the stream.  Hope to see you guys there!

WANT TO SUPPORT THE CHANNEL? 
💰 Patreon: https://www.patreon.com/distrotube 
💳 Paypal: https://www.youtube.com/redirect?event=channel_banner&amp;redir_token=QUFFLUhqbFF3eGpGSzM5Vk1PMGlENllqckpHeERYWWRld3xBQ3Jtc0tuUVNSYno2bjFGSG1MTGdfYkJnanhhU1o3ODdxejVWZzNTeHhLX0p4VUIwR01PMmF1MEtpdWVYMnppVXBuTmluSU16OFhHUmIyQ2Qyc3Z5MElJSkdMTExSRlRUUm9zZUhoLVVwcmxFdDlhZFhKNnpNZw&amp;q=https%3A%2F%2Fwww.paypal.com%2Fcgi-bin%2Fwebscr%3Fcmd%3D_donations%26business%3Dderek%2540distrotube%252ecom%26lc%3DUS%26item_name%3DDistroTube%26no_note%3D0%26currency_code%3DUSD%26bn%3DPP%252dDonationsBF%253abtn_donateCC_LG%252egif%253aNonHostedGuest
🛍

