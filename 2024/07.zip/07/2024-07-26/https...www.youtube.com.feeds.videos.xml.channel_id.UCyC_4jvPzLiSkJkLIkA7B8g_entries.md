# Source:Lindsey Stirling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g, language:en-US

## When in #dallas #tx #thunderstruck #cheerleading #dallascowboys #DCC
 - [https://www.youtube.com/watch?v=IvlhgmDIack](https://www.youtube.com/watch?v=IvlhgmDIack)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g
 - date published: 2024-07-26T20:13:06+00:00



## Violin but with #splits #liveshow
 - [https://www.youtube.com/watch?v=uXuuW55GBm0](https://www.youtube.com/watch?v=uXuuW55GBm0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g
 - date published: 2024-07-26T20:12:03+00:00



