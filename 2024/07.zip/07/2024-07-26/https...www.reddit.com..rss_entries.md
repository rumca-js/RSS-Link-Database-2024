# Source:Reddit - Front Page, URL:https://www.reddit.com/.rss, language:en-US

## British PM Keir Starmer sitting next to the Greek PM Kyriakos Mitsotakis during the Opening Ceremony of the Olympic Games
 - [https://www.reddit.com/r/europe/comments/1ecy0on/british_pm_keir_starmer_sitting_next_to_the_greek](https://www.reddit.com/r/europe/comments/1ecy0on/british_pm_keir_starmer_sitting_next_to_the_greek)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T20:25:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1ecy0on/british_pm_keir_starmer_sitting_next_to_the_greek/"> <img alt="British PM Keir Starmer sitting next to the Greek PM Kyriakos Mitsotakis during the Opening Ceremony of the Olympic Games" src="https://preview.redd.it/v6l348ks9xed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b16652583261d89423c6999d614381030ee9ae63" title="British PM Keir Starmer sitting next to the Greek PM Kyriakos Mitsotakis during the Opening Ceremony of the Olympic Games" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mike4992"> /u/Mike4992 </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br /> <span><a href="https://i.redd.it/v6l348ks9xed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1ecy0on/british_pm_keir_starmer_sitting_next_to_the_greek/">[comments]</a></span> </td></tr></table>

## Olympics Opening Ceremony Part Deux
 - [https://www.reddit.com/r/olympics/comments/1ecxsmt/olympics_opening_ceremony_part_deux](https://www.reddit.com/r/olympics/comments/1ecxsmt/olympics_opening_ceremony_part_deux)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T20:16:05+00:00

<!-- SC_OFF --><div class="md"><p>The original got so full that it's experiencing technical issues. </p> <p>FwF are you around?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IvyGold"> /u/IvyGold </a> &#32; to &#32; <a href="https://www.reddit.com/r/olympics/"> r/olympics </a> <br /> <span><a href="https://www.reddit.com/r/olympics/comments/1ecxsmt/olympics_opening_ceremony_part_deux/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/olympics/comments/1ecxsmt/olympics_opening_ceremony_part_deux/">[comments]</a></span>

## Thank the heavens for AMD
 - [https://www.reddit.com/r/pcmasterrace/comments/1ecxiw2/thank_the_heavens_for_amd](https://www.reddit.com/r/pcmasterrace/comments/1ecxiw2/thank_the_heavens_for_amd)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T20:04:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/pcmasterrace/comments/1ecxiw2/thank_the_heavens_for_amd/"> <img alt="Thank the heavens for AMD" src="https://external-preview.redd.it/U0RLRN9gBDxVjSpK_Q3DW1TnGvswLcnYFsneFPVcTao.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=24c77f8f5984f80da25c81967dd931b4bb97900a" title="Thank the heavens for AMD" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IcePopsicleDragon"> /u/IcePopsicleDragon </a> &#32; to &#32; <a href="https://www.reddit.com/r/pcmasterrace/"> r/pcmasterrace </a> <br /> <span><a href="https://i.imgur.com/4HRYVVo.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pcmasterrace/comments/1ecxiw2/thank_the_heavens_for_amd/">[comments]</a></span> </td></tr></table>

## United in Krecik 🐀
 - [https://www.reddit.com/r/2visegrad4you/comments/1ecx74j/united_in_krecik](https://www.reddit.com/r/2visegrad4you/comments/1ecx74j/united_in_krecik)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T19:50:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/2visegrad4you/comments/1ecx74j/united_in_krecik/"> <img alt="United in Krecik 🐀" src="https://preview.redd.it/mdujk32r3xed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c664db38eab3b6dcbd6614586224e763b7fd52a7" title="United in Krecik 🐀" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Very nice</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sekwan2000"> /u/Sekwan2000 </a> &#32; to &#32; <a href="https://www.reddit.com/r/2visegrad4you/"> r/2visegrad4you </a> <br /> <span><a href="https://i.redd.it/mdujk32r3xed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/2visegrad4you/comments/1ecx74j/united_in_krecik/">[comments]</a></span> </td></tr></table>

## Team BDS vs. Karmine Corp / LEC 2024 Summer Playoffs - Lower Bracket Round 3 / Post-Match Discussion
 - [https://www.reddit.com/r/leagueoflegends/comments/1ecwjds/team_bds_vs_karmine_corp_lec_2024_summer_playoffs](https://www.reddit.com/r/leagueoflegends/comments/1ecwjds/team_bds_vs_karmine_corp_lec_2024_summer_playoffs)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T19:22:02+00:00

<!-- SC_OFF --><div class="md"><h3>LEC 2024 SUMMER PLAYOFFS</h3> <p><a href="https://watch.lolesports.com/">Official page</a> | <a href="https://lol.fandom.com/wiki/LEC/2024_Season/Summer_Playoffs">Leaguepedia</a> | <a href="https://liquipedia.net/leagueoflegends/LEC/2024/Summer/Playoffs">Liquipedia</a> | <a href="https://eventvods.com/featured/lol?utm_source=reddit&amp;utm_medium=subreddit&amp;utm_campaign=post_match_threads">Eventvods.com</a> | <a href="http://lol.gamepedia.com/New_To_League/Welcome">New to LoL</a> </p> <hr /> <h3>Team BDS 3-2 Karmine Corp</h3> <p><strong>With this win by Team BDS, GIANTX qualify as the final team for the season finals.</strong> </p> <p><strong>BDS</strong> | <a href="https://lol.fandom.com/wiki/Team_BDS">Leaguepedia</a> | <a href="https://liquipedia.net/leagueoflegends/Team_BDS">Liquipedia</a> | <a href="https://www.bdsesport.com/">Website</a> | <a href="https://www.twitter.com/TeamBDS">Twitter</a> | <a href="https://www.facebook.com/BdsEsportsTeam

## Kolegowie, powinienem dać да или нет?
 - [https://www.reddit.com/r/okkolegauposledzony/comments/1ecwa5z/kolegowie_powinienem_dać_да_или_нет](https://www.reddit.com/r/okkolegauposledzony/comments/1ecwa5z/kolegowie_powinienem_dać_да_или_нет)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T19:10:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/okkolegauposledzony/comments/1ecwa5z/kolegowie_powinienem_dać_да_или_нет/"> <img alt="Kolegowie, powinienem dać да или нет?" src="https://preview.redd.it/cqyidafowwed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a82cdecfaece4bfb010801bf8f152ac44d1ebb96" title="Kolegowie, powinienem dać да или нет?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/realester453"> /u/realester453 </a> &#32; to &#32; <a href="https://www.reddit.com/r/okkolegauposledzony/"> r/okkolegauposledzony </a> <br /> <span><a href="https://i.redd.it/cqyidafowwed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/okkolegauposledzony/comments/1ecwa5z/kolegowie_powinienem_dać_да_или_нет/">[comments]</a></span> </td></tr></table>

## TIL Ogórki are from India
 - [https://www.reddit.com/r/poland/comments/1ecw7pg/til_ogórki_are_from_india](https://www.reddit.com/r/poland/comments/1ecw7pg/til_ogórki_are_from_india)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T19:07:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/poland/comments/1ecw7pg/til_ogórki_are_from_india/"> <img alt="TIL Ogórki are from India" src="https://preview.redd.it/u0grm105wwed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c4191ae7e085a78365100969764587218cf9ac60" title="TIL Ogórki are from India" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sausagespolish"> /u/sausagespolish </a> &#32; to &#32; <a href="https://www.reddit.com/r/poland/"> r/poland </a> <br /> <span><a href="https://i.redd.it/u0grm105wwed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/poland/comments/1ecw7pg/til_ogórki_are_from_india/">[comments]</a></span> </td></tr></table>

## You fuckers lied to me!
 - [https://www.reddit.com/r/whenthe/comments/1ecvvii/you_fuckers_lied_to_me](https://www.reddit.com/r/whenthe/comments/1ecvvii/you_fuckers_lied_to_me)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T18:53:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1ecvvii/you_fuckers_lied_to_me/"> <img alt="You fuckers lied to me!" src="https://external-preview.redd.it/Zm8wZnJpdWx0d2VkMWEwK8dFTplLrAy70vmHKk-zc-9qNDXhDYxr5HWwQlm9.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=773203ce4c47fd4b633db9ce803a2e8184437556" title="You fuckers lied to me!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WrongVeteranMaybe"> /u/WrongVeteranMaybe </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br /> <span><a href="https://v.redd.it/g17vwowktwed1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1ecvvii/you_fuckers_lied_to_me/">[comments]</a></span> </td></tr></table>

## Sir Another spin-off has been announced
 - [https://www.reddit.com/r/OkBuddyFresca/comments/1ecvg7k/sir_another_spinoff_has_been_announced](https://www.reddit.com/r/OkBuddyFresca/comments/1ecvg7k/sir_another_spinoff_has_been_announced)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T18:35:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/OkBuddyFresca/comments/1ecvg7k/sir_another_spinoff_has_been_announced/"> <img alt="Sir Another spin-off has been announced " src="https://preview.redd.it/r93yr87dqwed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0e8ada6cfe5ca44f0230ba538a46402755bfa9c0" title="Sir Another spin-off has been announced " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>At least it's more Soulja Boy</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Belphegorkingofsloth"> /u/Belphegorkingofsloth </a> &#32; to &#32; <a href="https://www.reddit.com/r/OkBuddyFresca/"> r/OkBuddyFresca </a> <br /> <span><a href="https://i.redd.it/r93yr87dqwed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/OkBuddyFresca/comments/1ecvg7k/sir_another_spinoff_has_been_announced/">[comments]</a></span> </td></tr></table>

## ‘The Boys’ Prequel Series ‘Vought Rising’ Starring Jensen Ackles & Aya Cash Ordered By Prime Video
 - [https://www.reddit.com/r/TheBoys/comments/1ecukzw/the_boys_prequel_series_vought_rising_starring](https://www.reddit.com/r/TheBoys/comments/1ecukzw/the_boys_prequel_series_vought_rising_starring)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T17:59:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/TheBoys/comments/1ecukzw/the_boys_prequel_series_vought_rising_starring/"> <img alt="‘The Boys’ Prequel Series ‘Vought Rising’ Starring Jensen Ackles &amp; Aya Cash Ordered By Prime Video" src="https://external-preview.redd.it/F1fynUpagiWLsKUj3_gYVAyb2cFeH0kodo-5XxdS-e4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1f1770756df3c20e1e2e87916554b6ee75771f5d" title="‘The Boys’ Prequel Series ‘Vought Rising’ Starring Jensen Ackles &amp; Aya Cash Ordered By Prime Video" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LoretiTV"> /u/LoretiTV </a> &#32; to &#32; <a href="https://www.reddit.com/r/TheBoys/"> r/TheBoys </a> <br /> <span><a href="https://deadline.com/2024/07/the-boys-prequel-series-jensen-ackles-aya-cash-prime-video-1236022514/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/TheBoys/comments/1ecukzw/the_boys_prequel_series_vought_rising_starring/">[comments]</a></span> </td></tr

## kids casually playing witg a high voltage train thingie
 - [https://www.reddit.com/r/KidsAreFuckingStupid/comments/1ecu7gp/kids_casually_playing_witg_a_high_voltage_train](https://www.reddit.com/r/KidsAreFuckingStupid/comments/1ecu7gp/kids_casually_playing_witg_a_high_voltage_train)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T17:43:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/KidsAreFuckingStupid/comments/1ecu7gp/kids_casually_playing_witg_a_high_voltage_train/"> <img alt="kids casually playing witg a high voltage train thingie" src="https://external-preview.redd.it/OHl5ejRvZTFod2VkMaOBo8dc7NbK0T8Rlr-J57mG1etrlXbM8RrabEuor2yr.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=3658affadc70f14a1c60a1bf2ca9f75e11fab2dd" title="kids casually playing witg a high voltage train thingie" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/dndDAAKU23"> /u/dndDAAKU23 </a> &#32; to &#32; <a href="https://www.reddit.com/r/KidsAreFuckingStupid/"> r/KidsAreFuckingStupid </a> <br /> <span><a href="https://v.redd.it/h8bcbwn1hwed1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/KidsAreFuckingStupid/comments/1ecu7gp/kids_casually_playing_witg_a_high_voltage_train/">[comments]</a></span> </td></tr></table>

## Sejm zadecydował w sprawie renty wdowiej
 - [https://www.reddit.com/r/Polska/comments/1ectvtw/sejm_zadecydował_w_sprawie_renty_wdowiej](https://www.reddit.com/r/Polska/comments/1ectvtw/sejm_zadecydował_w_sprawie_renty_wdowiej)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T17:29:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ectvtw/sejm_zadecydował_w_sprawie_renty_wdowiej/"> <img alt="Sejm zadecydował w sprawie renty wdowiej" src="https://external-preview.redd.it/e6PFixDQdtydtIDsFmCumwoMWuSnvV80ZTIG1pn_clQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=fca9e11c64874784680a87f93ed07f728ade737c" title="Sejm zadecydował w sprawie renty wdowiej" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Eravier"> /u/Eravier </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.tvp.info/79493382/owdowiali-moga-liczyc-na-dodatkowe-pieniadze">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ectvtw/sejm_zadecydował_w_sprawie_renty_wdowiej/">[comments]</a></span> </td></tr></table>

## They will reply as soon as they can guys
 - [https://www.reddit.com/r/shitposting/comments/1ectpos/they_will_reply_as_soon_as_they_can_guys](https://www.reddit.com/r/shitposting/comments/1ectpos/they_will_reply_as_soon_as_they_can_guys)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T17:22:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/shitposting/comments/1ectpos/they_will_reply_as_soon_as_they_can_guys/"> <img alt="They will reply as soon as they can guys" src="https://preview.redd.it/yz28b06edwed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bfde93f8194b7e3bf19c91f3ebf4d4dedc18fdc4" title="They will reply as soon as they can guys" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AdCool1233"> /u/AdCool1233 </a> &#32; to &#32; <a href="https://www.reddit.com/r/shitposting/"> r/shitposting </a> <br /> <span><a href="https://i.redd.it/yz28b06edwed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/shitposting/comments/1ectpos/they_will_reply_as_soon_as_they_can_guys/">[comments]</a></span> </td></tr></table>

## Genuine kid
 - [https://www.reddit.com/r/wholesomememes/comments/1ecte0x/genuine_kid](https://www.reddit.com/r/wholesomememes/comments/1ecte0x/genuine_kid)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T17:09:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/wholesomememes/comments/1ecte0x/genuine_kid/"> <img alt="Genuine kid" src="https://preview.redd.it/fygrz6y1bwed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c3f6a59b6de6f46de6ac63445c7d3a2a51fee0f7" title="Genuine kid" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Renvarsity"> /u/Renvarsity </a> &#32; to &#32; <a href="https://www.reddit.com/r/wholesomememes/"> r/wholesomememes </a> <br /> <span><a href="https://i.redd.it/fygrz6y1bwed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/wholesomememes/comments/1ecte0x/genuine_kid/">[comments]</a></span> </td></tr></table>

## Whoops.
 - [https://www.reddit.com/r/pcmasterrace/comments/1ect1wr/whoops](https://www.reddit.com/r/pcmasterrace/comments/1ect1wr/whoops)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T16:55:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/pcmasterrace/comments/1ect1wr/whoops/"> <img alt="Whoops." src="https://preview.redd.it/bhs477cm8wed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a16e43a1a903609e26fa9280158cbbd497661273" title="Whoops." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ReconJesus"> /u/ReconJesus </a> &#32; to &#32; <a href="https://www.reddit.com/r/pcmasterrace/"> r/pcmasterrace </a> <br /> <span><a href="https://i.redd.it/bhs477cm8wed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pcmasterrace/comments/1ect1wr/whoops/">[comments]</a></span> </td></tr></table>

## Don't you forget about me Elf [OC]
 - [https://www.reddit.com/r/comics/comments/1ecsq6c/dont_you_forget_about_me_elf_oc](https://www.reddit.com/r/comics/comments/1ecsq6c/dont_you_forget_about_me_elf_oc)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T16:42:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1ecsq6c/dont_you_forget_about_me_elf_oc/"> <img alt="Don't you forget about me Elf [OC]" src="https://preview.redd.it/n6mfwqk36wed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a0edae57811074e21b726436b4a0fe5021ab4d57" title="Don't you forget about me Elf [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/merrivius"> /u/merrivius </a> &#32; to &#32; <a href="https://www.reddit.com/r/comics/"> r/comics </a> <br /> <span><a href="https://i.redd.it/n6mfwqk36wed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1ecsq6c/dont_you_forget_about_me_elf_oc/">[comments]</a></span> </td></tr></table>

## Why is it was and not ciebie?
 - [https://www.reddit.com/r/learnpolish/comments/1ecspzd/why_is_it_was_and_not_ciebie](https://www.reddit.com/r/learnpolish/comments/1ecspzd/why_is_it_was_and_not_ciebie)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T16:41:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/learnpolish/comments/1ecspzd/why_is_it_was_and_not_ciebie/"> <img alt="Why is it was and not ciebie?" src="https://preview.redd.it/hpwcvww46wed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=45437e64ed742291e39bc127f8e52395c8576a7e" title="Why is it was and not ciebie?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FlounderMammoth9848"> /u/FlounderMammoth9848 </a> &#32; to &#32; <a href="https://www.reddit.com/r/learnpolish/"> r/learnpolish </a> <br /> <span><a href="https://i.redd.it/hpwcvww46wed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/learnpolish/comments/1ecspzd/why_is_it_was_and_not_ciebie/">[comments]</a></span> </td></tr></table>

## what a fucking week man
 - [https://www.reddit.com/r/whenthe/comments/1ecsoou/what_a_fucking_week_man](https://www.reddit.com/r/whenthe/comments/1ecsoou/what_a_fucking_week_man)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T16:40:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1ecsoou/what_a_fucking_week_man/"> <img alt="what a fucking week man" src="https://external-preview.redd.it/cXRubTlrb3Q1d2VkMWHddiMbgpkVi7x3DwnyG2eyEgRSSJO9rSUGMqAI-2sF.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=42515d4e60b109f63628b54810fa91547772bf26" title="what a fucking week man" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/oeti2"> /u/oeti2 </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br /> <span><a href="https://v.redd.it/4f8gjrot5wed1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1ecsoou/what_a_fucking_week_man/">[comments]</a></span> </td></tr></table>

## Olympics Opening Ceremony Megathread
 - [https://www.reddit.com/r/olympics/comments/1ecs0uk/olympics_opening_ceremony_megathread](https://www.reddit.com/r/olympics/comments/1ecs0uk/olympics_opening_ceremony_megathread)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T16:12:49+00:00

<!-- SC_OFF --><div class="md"><p>The Paris 2024 Olympic Opening Ceremonies will take place along the Seine River and at the Jardins du Trocadéro starting at <strong>19:30 local time</strong>. It will feature performances highlighting the culture of Paris and France, the Parade of Nations, and the lighting of the Olympic cauldron. French President Emmanuel Macron will be expected to formally open the Games. </p> <h3>Details</h3> <p>The Opening Ceremony will notably be the first one not to take place inside a stadium. Instead of a traditional Parade of Nations, athletes will be transported by over 90 boats along 6km of the Seine River, starting at the Pont d'Austerlitz and ending at the Jardins du Trocadéro across from the Eiffel Tower. Along the way, they will pass by various landmarks including the Notre Dame and the Louvre, as well as many venues for the Games. The rest of the Ceremony and official protocols will take place at the Jardins du Trocadéro, including a laser show.</p> <p

## Wildlife photographer captured a very unusual lion behavior
 - [https://www.reddit.com/r/interestingasfuck/comments/1ecrwp1/wildlife_photographer_captured_a_very_unusual](https://www.reddit.com/r/interestingasfuck/comments/1ecrwp1/wildlife_photographer_captured_a_very_unusual)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T16:08:01+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/RealRock_n_Rolla"> /u/RealRock_n_Rolla </a> &#32; to &#32; <a href="https://www.reddit.com/r/interestingasfuck/"> r/interestingasfuck </a> <br /> <span><a href="https://v.redd.it/f6zszc4xzved1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/interestingasfuck/comments/1ecrwp1/wildlife_photographer_captured_a_very_unusual/">[comments]</a></span>

## My neighbors regularly throw away brand new suitcases
 - [https://www.reddit.com/r/mildlyinteresting/comments/1ecrifs/my_neighbors_regularly_throw_away_brand_new](https://www.reddit.com/r/mildlyinteresting/comments/1ecrifs/my_neighbors_regularly_throw_away_brand_new)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T15:51:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinteresting/comments/1ecrifs/my_neighbors_regularly_throw_away_brand_new/"> <img alt="My neighbors regularly throw away brand new suitcases" src="https://preview.redd.it/otke7sw6xved1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=94eebd63ccbaa8ce3f68b7d472f267dc43675983" title="My neighbors regularly throw away brand new suitcases" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Reality_Concentrate"> /u/Reality_Concentrate </a> &#32; to &#32; <a href="https://www.reddit.com/r/mildlyinteresting/"> r/mildlyinteresting </a> <br /> <span><a href="https://i.redd.it/otke7sw6xved1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/mildlyinteresting/comments/1ecrifs/my_neighbors_regularly_throw_away_brand_new/">[comments]</a></span> </td></tr></table>

## I don't wanna know
 - [https://www.reddit.com/r/HolUp/comments/1ecr18t/i_dont_wanna_know](https://www.reddit.com/r/HolUp/comments/1ecr18t/i_dont_wanna_know)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T15:31:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/HolUp/comments/1ecr18t/i_dont_wanna_know/"> <img alt="I don't wanna know" src="https://preview.redd.it/nd7c1vxmtved1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=461ab6f3c1466e9e6f60d793ab799ced9ba77f6a" title="I don't wanna know" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DrMabuseKafe"> /u/DrMabuseKafe </a> &#32; to &#32; <a href="https://www.reddit.com/r/HolUp/"> r/HolUp </a> <br /> <span><a href="https://i.redd.it/nd7c1vxmtved1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HolUp/comments/1ecr18t/i_dont_wanna_know/">[comments]</a></span> </td></tr></table>

## Tego za wiele, jestem gruby jak wieprz.
 - [https://www.reddit.com/r/Polska/comments/1ecqj21/tego_za_wiele_jestem_gruby_jak_wieprz](https://www.reddit.com/r/Polska/comments/1ecqj21/tego_za_wiele_jestem_gruby_jak_wieprz)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T15:11:41+00:00

<!-- SC_OFF --><div class="md"><p>Od Października zeszłego roku z pracownika fizycznego rozpocząłem pracę biurową. Nigdy nie byłem szczupły, raczej coś około 90kg przy wzroście +180, nie wygladalem źle miałem kondycję, siłę jak dzik (brałem 80kg koło szlifierskie z przysiadu na wysokość klatki piersiowej). Teraz jak mam pracę siedzącą + wypłatę praktycznie X2 co poprzednio żre jak świnia. Nie odmawiałem sobie nic. McDonald's, pizza, steki w Steakhouse + hektolitry piwa i napojów gazowanych. Roztyłem się do 130kg. Tracę oddech jak wchodzę po schodach, jak ostatnio musiałem podbiec na autobus że 100 metrów to myślałem że stracę przytomność. Znajomi zaczęli się śmiać że jestem gruby. To nie jest najgorsze, najgorsze jest to że kiedyś dla funu z buta potrafiłem zrobić 10h spacer (np. Z Katowic do Pszczyny przez Bieruń Bojszowy Jankowice etc) teraz nie mam siły iść dalej niż do drugiej dzielnicy. Tracę oddech, i siłę. Na razie nic mnie nie boli, jak pisałem plusem tego że składałem konstru

## Czy istnieją miejsca, gdzie legalnie mógłbym nauczyć brata jeździć?
 - [https://www.reddit.com/r/Polska/comments/1ecqcuf/czy_istnieją_miejsca_gdzie_legalnie_mógłbym](https://www.reddit.com/r/Polska/comments/1ecqcuf/czy_istnieją_miejsca_gdzie_legalnie_mógłbym)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T15:04:57+00:00

<!-- SC_OFF --><div class="md"><p>Brat nie ma prawa jazdy (skończył 17 lat dopieto), a chciałem go lekko podszkolić. Czy są do tego jakieś specjalne place? Bo z tego co wiem to parkingi chyba odpadają.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/devilishlyhandsome33"> /u/devilishlyhandsome33 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1ecqcuf/czy_istnieją_miejsca_gdzie_legalnie_mógłbym/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ecqcuf/czy_istnieją_miejsca_gdzie_legalnie_mógłbym/">[comments]</a></span>

## Kontrola pracodawcy co robi pracownik na komputerze
 - [https://www.reddit.com/r/Polska/comments/1ecq49j/kontrola_pracodawcy_co_robi_pracownik_na](https://www.reddit.com/r/Polska/comments/1ecq49j/kontrola_pracodawcy_co_robi_pracownik_na)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T14:55:18+00:00

<!-- SC_OFF --><div class="md"><p>Dziś będąc u fryzjera słyszałem, jak klientka siedząca obok opowiadała o swojej pracy zdalnej - w zasadzie z tej rozmowy wynikało, że 80% czasu nie robi nic i stosuje różne sztuczki żeby świecić się na zielono na różnych komunikatorach.</p> <p>Jak jest w Waszych firmach? Czy pracodawcy mają jakieś narzędzia żeby kontrolować prace ludzi w firmie? Temat wydaje się być ciekawy szczególnie, że z jednej strony po COVID praca zdalna jest wszędzie, a z drugiej mówi się o wielkim powrocie do biur</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ekstazaa"> /u/Ekstazaa </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1ecq49j/kontrola_pracodawcy_co_robi_pracownik_na/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ecq49j/kontrola_pracodawcy_co_robi_pracownik_na/">[comments]</a></span>

## 😐
 - [https://www.reddit.com/r/whenthe/comments/1ecpuwg/_](https://www.reddit.com/r/whenthe/comments/1ecpuwg/_)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T14:44:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1ecpuwg/_/"> <img alt="😐" src="https://preview.redd.it/phh2mr67lved1.gif?width=640&amp;crop=smart&amp;s=a609db9617c8cf9c84bea339ca68e9eaa977d52e" title="😐" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WarCrimesAreBased"> /u/WarCrimesAreBased </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br /> <span><a href="https://i.redd.it/phh2mr67lved1.gif">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1ecpuwg/_/">[comments]</a></span> </td></tr></table>

## Bro lost all his aura💀
 - [https://www.reddit.com/r/Unexpected/comments/1ecpt9f/bro_lost_all_his_aura](https://www.reddit.com/r/Unexpected/comments/1ecpt9f/bro_lost_all_his_aura)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T14:42:45+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Empty-Carpenter-5461"> /u/Empty-Carpenter-5461 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Unexpected/"> r/Unexpected </a> <br /> <span><a href="https://v.redd.it/3kybtn3tkved1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Unexpected/comments/1ecpt9f/bro_lost_all_his_aura/">[comments]</a></span>

## Pozwoliłem sobie popełnić kompas kawoszy.
 - [https://www.reddit.com/r/Polska/comments/1ecp5w8/pozwoliłem_sobie_popełnić_kompas_kawoszy](https://www.reddit.com/r/Polska/comments/1ecp5w8/pozwoliłem_sobie_popełnić_kompas_kawoszy)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T14:15:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ecp5w8/pozwoliłem_sobie_popełnić_kompas_kawoszy/"> <img alt="Pozwoliłem sobie popełnić kompas kawoszy." src="https://preview.redd.it/wh1xf7vqfved1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=741409b9bdedf207fbf2e65f46b5a0a29cffb04b" title="Pozwoliłem sobie popełnić kompas kawoszy." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ScaryCherry_"> /u/ScaryCherry_ </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://i.redd.it/wh1xf7vqfved1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ecp5w8/pozwoliłem_sobie_popełnić_kompas_kawoszy/">[comments]</a></span> </td></tr></table>

## My wife and cat have been prescribed the same meds
 - [https://www.reddit.com/r/mildlyinteresting/comments/1ecp1ft/my_wife_and_cat_have_been_prescribed_the_same_meds](https://www.reddit.com/r/mildlyinteresting/comments/1ecp1ft/my_wife_and_cat_have_been_prescribed_the_same_meds)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T14:09:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinteresting/comments/1ecp1ft/my_wife_and_cat_have_been_prescribed_the_same_meds/"> <img alt="My wife and cat have been prescribed the same meds" src="https://preview.redd.it/9lxb1de0fved1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=fee30db8f1d010ee54735cba4ad2203756b40cd4" title="My wife and cat have been prescribed the same meds" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ArcusArtifex"> /u/ArcusArtifex </a> &#32; to &#32; <a href="https://www.reddit.com/r/mildlyinteresting/"> r/mildlyinteresting </a> <br /> <span><a href="https://i.redd.it/9lxb1de0fved1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/mildlyinteresting/comments/1ecp1ft/my_wife_and_cat_have_been_prescribed_the_same_meds/">[comments]</a></span> </td></tr></table>

## Snoop Dogg carried the Olympic torch in Saint-Denis
 - [https://www.reddit.com/r/pics/comments/1ecorje/snoop_dogg_carried_the_olympic_torch_in_saintdenis](https://www.reddit.com/r/pics/comments/1ecorje/snoop_dogg_carried_the_olympic_torch_in_saintdenis)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T13:58:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/pics/comments/1ecorje/snoop_dogg_carried_the_olympic_torch_in_saintdenis/"> <img alt="Snoop Dogg carried the Olympic torch in Saint-Denis" src="https://preview.redd.it/fu42jekwcved1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=380f637d4757324e28416a6d48f99c02c0215f2a" title="Snoop Dogg carried the Olympic torch in Saint-Denis" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LonelyWolf_93"> /u/LonelyWolf_93 </a> &#32; to &#32; <a href="https://www.reddit.com/r/pics/"> r/pics </a> <br /> <span><a href="https://i.redd.it/fu42jekwcved1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pics/comments/1ecorje/snoop_dogg_carried_the_olympic_torch_in_saintdenis/">[comments]</a></span> </td></tr></table>

## What is the worst death you have ever heard of or seen?
 - [https://www.reddit.com/r/AskReddit/comments/1ecnryk/what_is_the_worst_death_you_have_ever_heard_of_or](https://www.reddit.com/r/AskReddit/comments/1ecnryk/what_is_the_worst_death_you_have_ever_heard_of_or)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T13:13:30+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Tyler-Durden03"> /u/Tyler-Durden03 </a> &#32; to &#32; <a href="https://www.reddit.com/r/AskReddit/"> r/AskReddit </a> <br /> <span><a href="https://www.reddit.com/r/AskReddit/comments/1ecnryk/what_is_the_worst_death_you_have_ever_heard_of_or/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/AskReddit/comments/1ecnryk/what_is_the_worst_death_you_have_ever_heard_of_or/">[comments]</a></span>

## Kolegowie, mam dla was rebus:
 - [https://www.reddit.com/r/okkolegauposledzony/comments/1ecnnp7/kolegowie_mam_dla_was_rebus](https://www.reddit.com/r/okkolegauposledzony/comments/1ecnnp7/kolegowie_mam_dla_was_rebus)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T13:07:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/okkolegauposledzony/comments/1ecnnp7/kolegowie_mam_dla_was_rebus/"> <img alt="Kolegowie, mam dla was rebus:" src="https://preview.redd.it/warb6xqw3ved1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d242bc71c253dbdc19f9bcf6e706576d69b9d609" title="Kolegowie, mam dla was rebus:" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/renzhexiangjiao"> /u/renzhexiangjiao </a> &#32; to &#32; <a href="https://www.reddit.com/r/okkolegauposledzony/"> r/okkolegauposledzony </a> <br /> <span><a href="https://i.redd.it/warb6xqw3ved1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/okkolegauposledzony/comments/1ecnnp7/kolegowie_mam_dla_was_rebus/">[comments]</a></span> </td></tr></table>

## STWARDNIENIE ROZSIANE - ASK ME ANYTHING
 - [https://www.reddit.com/r/Polska/comments/1ecmpd4/stwardnienie_rozsiane_ask_me_anything](https://www.reddit.com/r/Polska/comments/1ecmpd4/stwardnienie_rozsiane_ask_me_anything)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T12:20:28+00:00

<!-- SC_OFF --><div class="md"><p>Siema, z początkiem tego roku zostałem zdiagnozowany na stwardnienie rozsiane i jestem w ciężkim szoku jak odmienna jest to choroba od tego, co jest głęboko zakorzenione w świadomości publicznej. Pierwsze objawy zaczęły mi się w listopadzie ubiegłego roku, więc niedługo będę obchodził rocznicę z tą suką. Chętnie odpowiem na Wasze pytania, mogą być też takie nie na miejscu, nie hamujcie się i nie gryźcie w język. Gadajmy bez taboo.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JumpyEntrepreneur899"> /u/JumpyEntrepreneur899 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1ecmpd4/stwardnienie_rozsiane_ask_me_anything/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ecmpd4/stwardnienie_rozsiane_ask_me_anything/">[comments]</a></span>

## I brought muffins to work because of my birthday, 5 minutes later they told me i am fired because of budget cuts..
 - [https://www.reddit.com/r/mildlyinfuriating/comments/1ecmkvw/i_brought_muffins_to_work_because_of_my_birthday](https://www.reddit.com/r/mildlyinfuriating/comments/1ecmkvw/i_brought_muffins_to_work_because_of_my_birthday)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T12:14:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinfuriating/comments/1ecmkvw/i_brought_muffins_to_work_because_of_my_birthday/"> <img alt="I brought muffins to work because of my birthday, 5 minutes later they told me i am fired because of budget cuts.." src="https://preview.redd.it/khdwxfjauued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7ad092b7fc778f1b60ed7a9e76f28b595dd87bb2" title="I brought muffins to work because of my birthday, 5 minutes later they told me i am fired because of budget cuts.." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I feel like an idiot, i’m already poor and this job was a bit of light in a dark cave.</p> <p>still let them keep the muffins though :/</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SadEggYolk"> /u/SadEggYolk </a> &#32; to &#32; <a href="https://www.reddit.com/r/mildlyinfuriating/"> r/mildlyinfuriating </a> <br /> <span><a href="https://i.redd.it/khdwxfjauued1.jpeg">[link]</a></spa

## Jak wytłumaczyć 5-cio latce czym jest kościół, religia?
 - [https://www.reddit.com/r/Polska/comments/1ecltta/jak_wytłumaczyć_5cio_latce_czym_jest_kościół](https://www.reddit.com/r/Polska/comments/1ecltta/jak_wytłumaczyć_5cio_latce_czym_jest_kościół)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T11:34:05+00:00

<!-- SC_OFF --><div class="md"><p>Jesteśmy rodziną ateuszy. Temat jeszcze nie podejmowany. Gdy widzi kościół mówi &quot;o! zamek!&quot;. Do tej pory były śmihy-hihy, ale młoda jest coraz bardziej kumata i myślę że to już czas powiedzieć jej o co cho. Zaczyna zadawać konkretne pytania &quot;po co te dzwony biją?&quot;, &quot;czemu tam nie wejdziemy&quot;(możemy w sumie wejść, jak już z nią pogadam), &quot;co to?&quot;(pokazując na kapliczkę lub krzyż). Żeby wytłumaczyć czym jest kościół, trzeba wytłumaczyć czym jest religią... i jeszcze wytłumaczyć że niektórzy (np. Babcia) w to wierzą, a my nie (oraz pytania: czemu oni w to wierzą/czemu my nie wierzymy? Kto ma rację??).</p> <p>Nie wiem jak to ugryźć, może są tu jacyś rodzice co mają to za sobą. Pytam tutaj, a nie na parentingowych czy ateistycznych subach, bo ten nasz polski klimat jest specyficzny i chciałabym poznać polską perspektywę.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Maniushka">

## Jakie wydarzenie w waszym życiu uświadomiło wam iż wasze dzieciństwo dobiegło końca ?
 - [https://www.reddit.com/r/Polska/comments/1eclqx0/jakie_wydarzenie_w_waszym_życiu_uświadomiło_wam](https://www.reddit.com/r/Polska/comments/1eclqx0/jakie_wydarzenie_w_waszym_życiu_uświadomiło_wam)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T11:29:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1eclqx0/jakie_wydarzenie_w_waszym_życiu_uświadomiło_wam/"> <img alt="Jakie wydarzenie w waszym życiu uświadomiło wam iż wasze dzieciństwo dobiegło końca ?" src="https://b.thumbs.redditmedia.com/hKMks2bsssNN7XRSsta_m0eT9ycQFv3PyKGk80ZKZ1s.jpg" title="Jakie wydarzenie w waszym życiu uświadomiło wam iż wasze dzieciństwo dobiegło końca ?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><a href="https://preview.redd.it/e1vy4mi3mued1.jpg?width=1280&amp;format=pjpg&amp;auto=webp&amp;s=55e6c91c2fd97932e0c3eb220a12fc6bd366f556">https://preview.redd.it/e1vy4mi3mued1.jpg?width=1280&amp;format=pjpg&amp;auto=webp&amp;s=55e6c91c2fd97932e0c3eb220a12fc6bd366f556</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Optimal_Area_7152"> /u/Optimal_Area_7152 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/

## Pure genius
 - [https://www.reddit.com/r/madlads/comments/1eclq8x/pure_genius](https://www.reddit.com/r/madlads/comments/1eclq8x/pure_genius)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T11:28:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/madlads/comments/1eclq8x/pure_genius/"> <img alt="Pure genius " src="https://preview.redd.it/xvgpkmo7mued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bdfe2488cb5be5754a3d14d20a2d134043d12bcb" title="Pure genius " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Literally_black1984"> /u/Literally_black1984 </a> &#32; to &#32; <a href="https://www.reddit.com/r/madlads/"> r/madlads </a> <br /> <span><a href="https://i.redd.it/xvgpkmo7mued1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/madlads/comments/1eclq8x/pure_genius/">[comments]</a></span> </td></tr></table>

## Based on a true story
 - [https://www.reddit.com/r/memes/comments/1eclpx8/based_on_a_true_story](https://www.reddit.com/r/memes/comments/1eclpx8/based_on_a_true_story)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T11:28:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/memes/comments/1eclpx8/based_on_a_true_story/"> <img alt="Based on a true story" src="https://preview.redd.it/e2ezmwh1mued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bc224e62c0c56f0b0e0d7d62ea6643be840c9714" title="Based on a true story" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Neat-Restaurant-8218"> /u/Neat-Restaurant-8218 </a> &#32; to &#32; <a href="https://www.reddit.com/r/memes/"> r/memes </a> <br /> <span><a href="https://i.redd.it/e2ezmwh1mued1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/memes/comments/1eclpx8/based_on_a_true_story/">[comments]</a></span> </td></tr></table>

## Me_irl
 - [https://www.reddit.com/r/me_irl/comments/1eclgnx/me_irl](https://www.reddit.com/r/me_irl/comments/1eclgnx/me_irl)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T11:13:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/me_irl/comments/1eclgnx/me_irl/"> <img alt="Me_irl" src="https://preview.redd.it/3pnbvohijued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8ce1ab932dbcf47acf5802858e58012b737979d9" title="Me_irl" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Literally_black1984"> /u/Literally_black1984 </a> &#32; to &#32; <a href="https://www.reddit.com/r/me_irl/"> r/me_irl </a> <br /> <span><a href="https://i.redd.it/3pnbvohijued1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/me_irl/comments/1eclgnx/me_irl/">[comments]</a></span> </td></tr></table>

## I don't see what's weird
 - [https://www.reddit.com/r/Unexpected/comments/1eclgdz/i_dont_see_whats_weird](https://www.reddit.com/r/Unexpected/comments/1eclgdz/i_dont_see_whats_weird)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T11:12:56+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Mindless_Tap8598"> /u/Mindless_Tap8598 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Unexpected/"> r/Unexpected </a> <br /> <span><a href="https://v.redd.it/hl2oibrcjued1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Unexpected/comments/1eclgdz/i_dont_see_whats_weird/">[comments]</a></span>

## The news is made possible by...
 - [https://www.reddit.com/r/memes/comments/1eclge0/the_news_is_made_possible_by](https://www.reddit.com/r/memes/comments/1eclge0/the_news_is_made_possible_by)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T11:12:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/memes/comments/1eclge0/the_news_is_made_possible_by/"> <img alt="The news is made possible by..." src="https://preview.redd.it/sveuy5rdjued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d6bf9c8bf5d1fb398d3102ac4c76508e1dfdeb6d" title="The news is made possible by..." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BdR76"> /u/BdR76 </a> &#32; to &#32; <a href="https://www.reddit.com/r/memes/"> r/memes </a> <br /> <span><a href="https://i.redd.it/sveuy5rdjued1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/memes/comments/1eclge0/the_news_is_made_possible_by/">[comments]</a></span> </td></tr></table>

## What is the most NSFW thing you’ve actually done at work?
 - [https://www.reddit.com/r/AskReddit/comments/1ecl5vs/what_is_the_most_nsfw_thing_youve_actually_done](https://www.reddit.com/r/AskReddit/comments/1ecl5vs/what_is_the_most_nsfw_thing_youve_actually_done)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T10:55:47+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/The__Scotsman__"> /u/The__Scotsman__ </a> &#32; to &#32; <a href="https://www.reddit.com/r/AskReddit/"> r/AskReddit </a> <br /> <span><a href="https://www.reddit.com/r/AskReddit/comments/1ecl5vs/what_is_the_most_nsfw_thing_youve_actually_done/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/AskReddit/comments/1ecl5vs/what_is_the_most_nsfw_thing_youve_actually_done/">[comments]</a></span>

## Czy Giertych kłamie, czy Tusk jest wyrachowany? Pokłosie dzisiejszej rozmowy w RMF
 - [https://www.reddit.com/r/Polska/comments/1ecl3du/czy_giertych_kłamie_czy_tusk_jest_wyrachowany](https://www.reddit.com/r/Polska/comments/1ecl3du/czy_giertych_kłamie_czy_tusk_jest_wyrachowany)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T10:51:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ecl3du/czy_giertych_kłamie_czy_tusk_jest_wyrachowany/"> <img alt="Czy Giertych kłamie, czy Tusk jest wyrachowany? Pokłosie dzisiejszej rozmowy w RMF" src="https://preview.redd.it/zo0r18xhfued1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=9b6a80746f21859082fcc183b97dc3dbdbbc378b" title="Czy Giertych kłamie, czy Tusk jest wyrachowany? Pokłosie dzisiejszej rozmowy w RMF" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Zacny_Los"> /u/Zacny_Los </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://i.redd.it/zo0r18xhfued1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ecl3du/czy_giertych_kłamie_czy_tusk_jest_wyrachowany/">[comments]</a></span> </td></tr></table>

## I think about this scene at least once a week.
 - [https://www.reddit.com/r/TheBoys/comments/1eckrsr/i_think_about_this_scene_at_least_once_a_week](https://www.reddit.com/r/TheBoys/comments/1eckrsr/i_think_about_this_scene_at_least_once_a_week)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T10:30:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/TheBoys/comments/1eckrsr/i_think_about_this_scene_at_least_once_a_week/"> <img alt="I think about this scene at least once a week. " src="https://preview.redd.it/okoxp7vxbued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=596e71795da318c8224f114a5cdc42deef535eed" title="I think about this scene at least once a week. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BadWriter85"> /u/BadWriter85 </a> &#32; to &#32; <a href="https://www.reddit.com/r/TheBoys/"> r/TheBoys </a> <br /> <span><a href="https://i.redd.it/okoxp7vxbued1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/TheBoys/comments/1eckrsr/i_think_about_this_scene_at_least_once_a_week/">[comments]</a></span> </td></tr></table>

## “They have different standards now in Europe, a different way of thinking. We’re gradually splitting away.” Russians react to the news that Europe Square has been renamed Eurasia Square. @BBCNews
 - [https://www.reddit.com/r/europe/comments/1eckm5h/they_have_different_standards_now_in_europe_a](https://www.reddit.com/r/europe/comments/1eckm5h/they_have_different_standards_now_in_europe_a)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T10:20:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1eckm5h/they_have_different_standards_now_in_europe_a/"> <img alt="“They have different standards now in Europe, a different way of thinking. We’re gradually splitting away.” Russians react to the news that Europe Square has been renamed Eurasia Square. @BBCNews" src="https://external-preview.redd.it/bWYwb2ZtYTJhdWVkMVFq2C34CGdc5Fp9bLD21YqABGLV1bH8K7mdl_iEbQCE.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=38830a6d5975f85264d808bae45975d452bc4d4d" title="“They have different standards now in Europe, a different way of thinking. We’re gradually splitting away.” Russians react to the news that Europe Square has been renamed Eurasia Square. @BBCNews" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BkkGrl"> /u/BkkGrl </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br /> <span><a href="https://v.redd.it/63c8b8os9ued1">[link]</a></span> &#32; <span><a href="htt

## Aishah
 - [https://www.reddit.com/r/comics/comments/1eckk3a/aishah](https://www.reddit.com/r/comics/comments/1eckk3a/aishah)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T10:16:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1eckk3a/aishah/"> <img alt="Aishah" src="https://b.thumbs.redditmedia.com/4rv_MB9mRxQEBxWRSp5QYwNEdTQJ9h44w1M2kvya9ro.jpg" title="Aishah" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rachelwan-art"> /u/rachelwan-art </a> &#32; to &#32; <a href="https://www.reddit.com/r/comics/"> r/comics </a> <br /> <span><a href="https://www.reddit.com/gallery/1eckk3a">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1eckk3a/aishah/">[comments]</a></span> </td></tr></table>

## Shattered the Elden Ring this morning :/
 - [https://www.reddit.com/r/Eldenring/comments/1eckgd3/shattered_the_elden_ring_this_morning](https://www.reddit.com/r/Eldenring/comments/1eckgd3/shattered_the_elden_ring_this_morning)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T10:10:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Eldenring/comments/1eckgd3/shattered_the_elden_ring_this_morning/"> <img alt="Shattered the Elden Ring this morning :/" src="https://preview.redd.it/n1my1u498ued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9ac3d50b563763af374ed8c142a5add8fd1290a6" title="Shattered the Elden Ring this morning :/" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Product_of_division"> /u/Product_of_division </a> &#32; to &#32; <a href="https://www.reddit.com/r/Eldenring/"> r/Eldenring </a> <br /> <span><a href="https://i.redd.it/n1my1u498ued1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Eldenring/comments/1eckgd3/shattered_the_elden_ring_this_morning/">[comments]</a></span> </td></tr></table>

## Evil company political chart
 - [https://www.reddit.com/r/DeepRockGalactic/comments/1eckbac/evil_company_political_chart](https://www.reddit.com/r/DeepRockGalactic/comments/1eckbac/evil_company_political_chart)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T10:01:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepRockGalactic/comments/1eckbac/evil_company_political_chart/"> <img alt="Evil company political chart" src="https://preview.redd.it/kbmxw4hn6ued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b1bc6d1e26e51cc978efdc3ed8248ceb38b49d73" title="Evil company political chart" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ParraleledInnocence"> /u/ParraleledInnocence </a> &#32; to &#32; <a href="https://www.reddit.com/r/DeepRockGalactic/"> r/DeepRockGalactic </a> <br /> <span><a href="https://i.redd.it/kbmxw4hn6ued1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepRockGalactic/comments/1eckbac/evil_company_political_chart/">[comments]</a></span> </td></tr></table>

## Higienizacja zębów
 - [https://www.reddit.com/r/Polska/comments/1eck70r/higienizacja_zębów](https://www.reddit.com/r/Polska/comments/1eck70r/higienizacja_zębów)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T09:53:29+00:00

<!-- SC_OFF --><div class="md"><p>Ej ile płacicie w Warszawie za kompleksowa higienizacje zębów? Bo dzisiaj poszłam i babka sobie policzyła 450 zł. Z czego nie było u mnie tyle roboty do wykonania, wyrobiła się w mniej niż 30 min. Czuje się trochę oskamowana xd </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/itsyourmombabe"> /u/itsyourmombabe </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1eck70r/higienizacja_zębów/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1eck70r/higienizacja_zębów/">[comments]</a></span>

## Countries where leaving your religion (apostasy) is punished
 - [https://www.reddit.com/r/MapPorn/comments/1eck1r1/countries_where_leaving_your_religion_apostasy_is](https://www.reddit.com/r/MapPorn/comments/1eck1r1/countries_where_leaving_your_religion_apostasy_is)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T09:43:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/MapPorn/comments/1eck1r1/countries_where_leaving_your_religion_apostasy_is/"> <img alt="Countries where leaving your religion (apostasy) is punished" src="https://preview.redd.it/wv5unggg3ued1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=e47e0a448f44a50c299572ce97c38f7b8d3b5b57" title="Countries where leaving your religion (apostasy) is punished" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/coronaredditor"> /u/coronaredditor </a> &#32; to &#32; <a href="https://www.reddit.com/r/MapPorn/"> r/MapPorn </a> <br /> <span><a href="https://i.redd.it/wv5unggg3ued1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/MapPorn/comments/1eck1r1/countries_where_leaving_your_religion_apostasy_is/">[comments]</a></span> </td></tr></table>

## Tato, jeszcze nie
 - [https://www.reddit.com/r/Polska_wpz/comments/1ecjs9y/tato_jeszcze_nie](https://www.reddit.com/r/Polska_wpz/comments/1ecjs9y/tato_jeszcze_nie)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T09:25:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska_wpz/comments/1ecjs9y/tato_jeszcze_nie/"> <img alt="Tato, jeszcze nie" src="https://preview.redd.it/rlr12b650ued1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=c2654cf80b7a42c6707b168ad940653eef246cd6" title="Tato, jeszcze nie" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/_Fos"> /u/_Fos </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska_wpz/"> r/Polska_wpz </a> <br /> <span><a href="https://i.redd.it/rlr12b650ued1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska_wpz/comments/1ecjs9y/tato_jeszcze_nie/">[comments]</a></span> </td></tr></table>

## Rare self insult, lol.
 - [https://www.reddit.com/r/rareinsults/comments/1ecjo1j/rare_self_insult_lol](https://www.reddit.com/r/rareinsults/comments/1ecjo1j/rare_self_insult_lol)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T09:16:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/rareinsults/comments/1ecjo1j/rare_self_insult_lol/"> <img alt="Rare self insult, lol." src="https://preview.redd.it/t1w60ztkyted1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=0234f237b08f810dfbacf653bc3d512f65b8efb5" title="Rare self insult, lol." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SingleStick3"> /u/SingleStick3 </a> &#32; to &#32; <a href="https://www.reddit.com/r/rareinsults/"> r/rareinsults </a> <br /> <span><a href="https://i.redd.it/t1w60ztkyted1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/rareinsults/comments/1ecjo1j/rare_self_insult_lol/">[comments]</a></span> </td></tr></table>

## IT'S REAL
 - [https://www.reddit.com/r/limbuscompany/comments/1ecjnzu/its_real](https://www.reddit.com/r/limbuscompany/comments/1ecjnzu/its_real)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T09:16:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/limbuscompany/comments/1ecjnzu/its_real/"> <img alt="IT'S REAL" src="https://preview.redd.it/9iaq7nqmyted1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=304c552c7373c7a3af0c84665e9b4ce3e3b5e1f1" title="IT'S REAL" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ShockSword"> /u/ShockSword </a> &#32; to &#32; <a href="https://www.reddit.com/r/limbuscompany/"> r/limbuscompany </a> <br /> <span><a href="https://i.redd.it/9iaq7nqmyted1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/limbuscompany/comments/1ecjnzu/its_real/">[comments]</a></span> </td></tr></table>

## Live Scuffed Stream Reaction
 - [https://www.reddit.com/r/limbuscompany/comments/1ecjjgy/live_scuffed_stream_reaction](https://www.reddit.com/r/limbuscompany/comments/1ecjjgy/live_scuffed_stream_reaction)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T09:07:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/limbuscompany/comments/1ecjjgy/live_scuffed_stream_reaction/"> <img alt="Live Scuffed Stream Reaction" src="https://preview.redd.it/p9rm89b1xted1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=c35d69429b6bded2dc213be967f584c904171889" title="Live Scuffed Stream Reaction" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SexWithSenti"> /u/SexWithSenti </a> &#32; to &#32; <a href="https://www.reddit.com/r/limbuscompany/"> r/limbuscompany </a> <br /> <span><a href="https://i.redd.it/p9rm89b1xted1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/limbuscompany/comments/1ecjjgy/live_scuffed_stream_reaction/">[comments]</a></span> </td></tr></table>

## My wife of 12 years just came out as trans and it ruined my life
 - [https://www.reddit.com/r/TrueOffMyChest/comments/1ecj3qo/my_wife_of_12_years_just_came_out_as_trans_and_it](https://www.reddit.com/r/TrueOffMyChest/comments/1ecj3qo/my_wife_of_12_years_just_came_out_as_trans_and_it)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T08:36:40+00:00

<!-- SC_OFF --><div class="md"><p>Using a throwaway because my wifes family follows my main account</p> <p>A few days ago my wife said we needed to talk about something serious during our night out. She then came out as trans and told me she wants to start her transition process in the coming months. My heart dropped and I was extremely shocked and upset. I feel heartbroken and that our marriage and relationship was a waste of time. She became a bit frustrated at my reaction and told me she expected me to show some sort of support for her decision. I angrily told her that this is a big change in our relationship and is going to be a big change in our kids lives. Since then Ive just been drinking a lot, calling out of work, and feel to fucking depressed. I married what I thought was the love of my life, the most beautiful woman of my life, not married to a fucking man. </p> <p>Im not against transgender people and they deserve recognition and their support but I cant help but feel so f

## No way this works
 - [https://www.reddit.com/r/shitposting/comments/1ecj36q/no_way_this_works](https://www.reddit.com/r/shitposting/comments/1ecj36q/no_way_this_works)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T08:35:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/shitposting/comments/1ecj36q/no_way_this_works/"> <img alt="No way this works" src="https://preview.redd.it/z5k0r1ncrted1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=d83f8e6a8cc782286161c3c588f86fb137d9cec6" title="No way this works" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Salty-Sheepherder-18"> /u/Salty-Sheepherder-18 </a> &#32; to &#32; <a href="https://www.reddit.com/r/shitposting/"> r/shitposting </a> <br /> <span><a href="https://i.redd.it/z5k0r1ncrted1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/shitposting/comments/1ecj36q/no_way_this_works/">[comments]</a></span> </td></tr></table>

## Well translated version of the mysterious 5-star Character Level-Up Material post
 - [https://www.reddit.com/r/Genshin_Impact_Leaks/comments/1eciyzo/well_translated_version_of_the_mysterious_5star](https://www.reddit.com/r/Genshin_Impact_Leaks/comments/1eciyzo/well_translated_version_of_the_mysterious_5star)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T08:27:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Genshin_Impact_Leaks/comments/1eciyzo/well_translated_version_of_the_mysterious_5star/"> <img alt="Well translated version of the mysterious 5-star Character Level-Up Material post" src="https://a.thumbs.redditmedia.com/8xSCGRYPM4txhfQUN8rBO0W-Qr71TtJfxISoANXDDu0.jpg" title="Well translated version of the mysterious 5-star Character Level-Up Material post" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/homdgcat3"> /u/homdgcat3 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Genshin_Impact_Leaks/"> r/Genshin_Impact_Leaks </a> <br /> <span><a href="https://www.reddit.com/gallery/1eciyzo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Genshin_Impact_Leaks/comments/1eciyzo/well_translated_version_of_the_mysterious_5star/">[comments]</a></span> </td></tr></table>

## I’ve got over 1000 gems, is this deal worth it?
 - [https://www.reddit.com/r/Brawlstars/comments/1eciqtj/ive_got_over_1000_gems_is_this_deal_worth_it](https://www.reddit.com/r/Brawlstars/comments/1eciqtj/ive_got_over_1000_gems_is_this_deal_worth_it)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T08:11:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Brawlstars/comments/1eciqtj/ive_got_over_1000_gems_is_this_deal_worth_it/"> <img alt="I’ve got over 1000 gems, is this deal worth it? " src="https://preview.redd.it/pm64ihw2nted1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=496f6f092104b23d3dafc3fa71aacf7b947becf4" title="I’ve got over 1000 gems, is this deal worth it? " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>The absolute gambler in me really wants to chance it but I feel like I could just focus them somewhere and really just get something I need…</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rekrah"> /u/Rekrah </a> &#32; to &#32; <a href="https://www.reddit.com/r/Brawlstars/"> r/Brawlstars </a> <br /> <span><a href="https://i.redd.it/pm64ihw2nted1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Brawlstars/comments/1eciqtj/ive_got_over_1000_gems_is_this_deal_worth_it/">[comments]</a></span> </td></tr></ta

## Docenili nas za granico :V
 - [https://www.reddit.com/r/Polska/comments/1eciozl/docenili_nas_za_granico_v](https://www.reddit.com/r/Polska/comments/1eciozl/docenili_nas_za_granico_v)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T08:08:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1eciozl/docenili_nas_za_granico_v/"> <img alt="Docenili nas za granico :V" src="https://preview.redd.it/e4kiddcgmted1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=edcaa57e72797067a702736a5813312443114a47" title="Docenili nas za granico :V" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/dargemir"> /u/dargemir </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://i.redd.it/e4kiddcgmted1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1eciozl/docenili_nas_za_granico_v/">[comments]</a></span> </td></tr></table>

## Nie zamykanie drzwi od klatki bloku
 - [https://www.reddit.com/r/Polska/comments/1ecilws/nie_zamykanie_drzwi_od_klatki_bloku](https://www.reddit.com/r/Polska/comments/1ecilws/nie_zamykanie_drzwi_od_klatki_bloku)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T08:02:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1ecilws/nie_zamykanie_drzwi_od_klatki_bloku/"> <img alt="Nie zamykanie drzwi od klatki bloku " src="https://b.thumbs.redditmedia.com/ePPshRf5bhcd2w7HuxslBSrxU1dX0PQ_12uX9aFv0cw.jpg" title="Nie zamykanie drzwi od klatki bloku " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Czy was też denerwuje gdy ktoś blokuje (stopką, lub kneblem gdy stopki brak) drzwi od klatki żeby nie musieć drugi raz wpisywać kodu? </p> <p>Nie podoba mi się to, nigdy nie wiadomo kto wchodzi do klatki. Wiadomo że mieszkańcy i tak jak usłyszą sygnał domofonu to najpierw otwierają klatkę a potem się zastanawiają kogo właśnie wpuścili, ale wtedy chociaż zostaje jakiś ślad kto i kiedy otworzył te drzwi. </p> <p>Złodzieje wchodzą do bloków i szarpią za klamki, chodzą tak od drzwi do drzwi. Liczą, że ktoś zostawił otwarte mieszkanie.</p> <p><a href="https://preview.redd.it/oux77uh8lted1.png?width=745&amp;format=png&amp;auto=webp&amp;s=df587734b2106

## we have peaked once again
 - [https://www.reddit.com/r/okbuddybaka/comments/1eci926/we_have_peaked_once_again](https://www.reddit.com/r/okbuddybaka/comments/1eci926/we_have_peaked_once_again)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T07:37:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/okbuddybaka/comments/1eci926/we_have_peaked_once_again/"> <img alt="we have peaked once again " src="https://external-preview.redd.it/Y2xoMGpvNzBodGVkMeZAyTVuT2FUucMAEfebk5KV6lGr5l18QHEZ_Uuv8SuA.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=076c160cc01aef6b9f5ead411be365a17e36260c" title="we have peaked once again " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/crushedmoose"> /u/crushedmoose </a> &#32; to &#32; <a href="https://www.reddit.com/r/okbuddybaka/"> r/okbuddybaka </a> <br /> <span><a href="https://v.redd.it/7jggh7e0hted1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/okbuddybaka/comments/1eci926/we_have_peaked_once_again/">[comments]</a></span> </td></tr></table>

## SNCF: "Massive attack" on express train network in France - delays and train cancellations before the Olympics
 - [https://www.reddit.com/r/europe/comments/1echm5w/sncf_massive_attack_on_express_train_network_in](https://www.reddit.com/r/europe/comments/1echm5w/sncf_massive_attack_on_express_train_network_in)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T06:55:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1echm5w/sncf_massive_attack_on_express_train_network_in/"> <img alt="SNCF: &quot;Massive attack&quot; on express train network in France - delays and train cancellations before the Olympics" src="https://external-preview.redd.it/5g8y7SLkE-nnji7SwN9q_vKvpKUg6GzmYJQatZ8NzkY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=dd9606f6eba269ff4a471bbbc26903737f751a55" title="SNCF: &quot;Massive attack&quot; on express train network in France - delays and train cancellations before the Olympics" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Stabile_Feldmaus"> /u/Stabile_Feldmaus </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br /> <span><a href="https://www.faz.net/aktuell/frankreich-massiver-angriff-auf-schnellzugnetz-verzoegerungen-und-zugausfaelle-vor-olympia-19880491.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1echm5

## Fr though
 - [https://www.reddit.com/r/Eldenring/comments/1echiqf/fr_though](https://www.reddit.com/r/Eldenring/comments/1echiqf/fr_though)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T06:48:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Eldenring/comments/1echiqf/fr_though/"> <img alt="Fr though" src="https://preview.redd.it/qyfuljy98ted1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=c1a97f0749c313bb2ba0664e4a3ecb74e1008076" title="Fr though" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Thatgreeenplant"> /u/Thatgreeenplant </a> &#32; to &#32; <a href="https://www.reddit.com/r/Eldenring/"> r/Eldenring </a> <br /> <span><a href="https://i.redd.it/qyfuljy98ted1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Eldenring/comments/1echiqf/fr_though/">[comments]</a></span> </td></tr></table>

## Gdzie zabrac dziewczynę na randkę w dniu jej urodzin?
 - [https://www.reddit.com/r/Polska/comments/1ech592/gdzie_zabrac_dziewczynę_na_randkę_w_dniu_jej](https://www.reddit.com/r/Polska/comments/1ech592/gdzie_zabrac_dziewczynę_na_randkę_w_dniu_jej)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T06:24:01+00:00

<!-- SC_OFF --><div class="md"><p>Macie jakieś pomysły? Może ciekawe miejsca w Polsce? Chciałbym żeby ten dzień był dla niej wyjątkowy, chciałbym się zamknąć do 5 stówek, nie dłużej niż 1 dzień :) </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/kvccpxr"> /u/kvccpxr </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1ech592/gdzie_zabrac_dziewczynę_na_randkę_w_dniu_jej/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ech592/gdzie_zabrac_dziewczynę_na_randkę_w_dniu_jej/">[comments]</a></span>

## Hamilton tells Verstappen to 'act like a champion'
 - [https://www.reddit.com/r/formula1/comments/1ech4ed/hamilton_tells_verstappen_to_act_like_a_champion](https://www.reddit.com/r/formula1/comments/1ech4ed/hamilton_tells_verstappen_to_act_like_a_champion)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T06:22:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/formula1/comments/1ech4ed/hamilton_tells_verstappen_to_act_like_a_champion/"> <img alt="Hamilton tells Verstappen to 'act like a champion'" src="https://external-preview.redd.it/236kExe_I3J8KsYxpU-pw63zgi8qblGrzoA_Qgd2PM8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d9572872a4e8953597a38463c402756b6eb9c087" title="Hamilton tells Verstappen to 'act like a champion'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Elite_lucifer"> /u/Elite_lucifer </a> &#32; to &#32; <a href="https://www.reddit.com/r/formula1/"> r/formula1 </a> <br /> <span><a href="https://www.espn.in/f1/story/_/id/40639309/lewis-hamilton-tells-max-verstappen-act-champion">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/formula1/comments/1ech4ed/hamilton_tells_verstappen_to_act_like_a_champion/">[comments]</a></span> </td></tr></table>

## Why not put the "actual" reason for selection lol
 - [https://www.reddit.com/r/Genshin_Impact/comments/1ech069/why_not_put_the_actual_reason_for_selection_lol](https://www.reddit.com/r/Genshin_Impact/comments/1ech069/why_not_put_the_actual_reason_for_selection_lol)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T06:15:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Genshin_Impact/comments/1ech069/why_not_put_the_actual_reason_for_selection_lol/"> <img alt="Why not put the &quot;actual&quot; reason for selection lol" src="https://preview.redd.it/clrarjia2ted1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=596f8b71e3e06d54c4eafd44c2f83593812886c8" title="Why not put the &quot;actual&quot; reason for selection lol" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Source - Current character survey (No idea if everyone got it or not) </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ig_flariax"> /u/ig_flariax </a> &#32; to &#32; <a href="https://www.reddit.com/r/Genshin_Impact/"> r/Genshin_Impact </a> <br /> <span><a href="https://i.redd.it/clrarjia2ted1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Genshin_Impact/comments/1ech069/why_not_put_the_actual_reason_for_selection_lol/">[comments]</a></span> </td></tr></table>

## Is there a canon reason for Rhaenyra being so ripped?
 - [https://www.reddit.com/r/HouseOfTheDragon/comments/1ecguux/is_there_a_canon_reason_for_rhaenyra_being_so](https://www.reddit.com/r/HouseOfTheDragon/comments/1ecguux/is_there_a_canon_reason_for_rhaenyra_being_so)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T06:05:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/HouseOfTheDragon/comments/1ecguux/is_there_a_canon_reason_for_rhaenyra_being_so/"> <img alt="Is there a canon reason for Rhaenyra being so ripped?" src="https://preview.redd.it/47oz96sl0ted1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=38a8f562261807dfd29726217e096db80030cacf" title="Is there a canon reason for Rhaenyra being so ripped?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Plus_Claim_8938"> /u/Plus_Claim_8938 </a> &#32; to &#32; <a href="https://www.reddit.com/r/HouseOfTheDragon/"> r/HouseOfTheDragon </a> <br /> <span><a href="https://i.redd.it/47oz96sl0ted1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HouseOfTheDragon/comments/1ecguux/is_there_a_canon_reason_for_rhaenyra_being_so/">[comments]</a></span> </td></tr></table>

## Kitesurfer survives pitbull attack on Argentinian beach
 - [https://www.reddit.com/r/Damnthatsinteresting/comments/1ecgmuf/kitesurfer_survives_pitbull_attack_on_argentinian](https://www.reddit.com/r/Damnthatsinteresting/comments/1ecgmuf/kitesurfer_survives_pitbull_attack_on_argentinian)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T05:52:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Damnthatsinteresting/comments/1ecgmuf/kitesurfer_survives_pitbull_attack_on_argentinian/"> <img alt="Kitesurfer survives pitbull attack on Argentinian beach" src="https://external-preview.redd.it/bHpiNHI4eTV5c2VkMUZ12j1LqgClVfL5LQ5ioLQqeBPbOaH0Ml69vSgEurMG.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=a1f06ffe9916feddb053dd563745a8519efe8343" title="Kitesurfer survives pitbull attack on Argentinian beach" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sans010394"> /u/Sans010394 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Damnthatsinteresting/"> r/Damnthatsinteresting </a> <br /> <span><a href="https://v.redd.it/daeum466ysed1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Damnthatsinteresting/comments/1ecgmuf/kitesurfer_survives_pitbull_attack_on_argentinian/">[comments]</a></span> </td></tr></table>

## I share a desk with my coworker, this is the space he uses everyday leaving me only the corner in the left.
 - [https://www.reddit.com/r/mildlyinfuriating/comments/1ecgmee/i_share_a_desk_with_my_coworker_this_is_the_space](https://www.reddit.com/r/mildlyinfuriating/comments/1ecgmee/i_share_a_desk_with_my_coworker_this_is_the_space)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T05:51:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinfuriating/comments/1ecgmee/i_share_a_desk_with_my_coworker_this_is_the_space/"> <img alt="I share a desk with my coworker, this is the space he uses everyday leaving me only the corner in the left. " src="https://preview.redd.it/t6r4qx81ysed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c87eacb8ff29411f2d3b836e214275a562f00443" title="I share a desk with my coworker, this is the space he uses everyday leaving me only the corner in the left. " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Any suggestions? He’s a kind person but I don’t like when people are too close to me, let alone 8 hours a day </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/calumgirl96"> /u/calumgirl96 </a> &#32; to &#32; <a href="https://www.reddit.com/r/mildlyinfuriating/"> r/mildlyinfuriating </a> <br /> <span><a href="https://i.redd.it/t6r4qx81ysed1.jpeg">[link]</a></span> &#32; <span><a href="https://ww

## Sąsiad palący marichuanę
 - [https://www.reddit.com/r/Polska/comments/1ecg6zt/sąsiad_palący_marichuanę](https://www.reddit.com/r/Polska/comments/1ecg6zt/sąsiad_palący_marichuanę)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T05:24:27+00:00

<!-- SC_OFF --><div class="md"><p>Jak w tytule. Praktycznie co wieczór z dworu niesie się smród zielska i jest to nie do zniesienia. Na 100% jest to ktoś z mojej kamienicy, gdyż mieszkam na 5 piętrze, a obok nie ma żadnej innej. Niestety nie wiem który to sąsiad. Ciężko jest mi sobie wyobrazić chodzenie od drzwi do drzwi i pytanie &quot;czy to Pan/Pani palił wczoraj weed?&quot;. Myślałem nad rozwieszeniem kartki na klatce schodowej z prośbą o zamykanie okna w czasie konsumpcji. Macie może jakieś inne pomysły?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/OstrzeWatykanu"> /u/OstrzeWatykanu </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1ecg6zt/sąsiad_palący_marichuanę/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ecg6zt/sąsiad_palący_marichuanę/">[comments]</a></span>

## Which characters orientation reveal surprised you the most?
 - [https://www.reddit.com/r/HelluvaBoss/comments/1ecg0qf/which_characters_orientation_reveal_surprised_you](https://www.reddit.com/r/HelluvaBoss/comments/1ecg0qf/which_characters_orientation_reveal_surprised_you)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T05:13:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/HelluvaBoss/comments/1ecg0qf/which_characters_orientation_reveal_surprised_you/"> <img alt="Which characters orientation reveal surprised you the most?" src="https://preview.redd.it/dp1pqlvbrsed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0f0cedef3971faa5e97a6b695e3452f0469817ef" title="Which characters orientation reveal surprised you the most?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I was not expecting Mammon and Octavia to be ace, Sallie being a transbian, or Vassago being gay (given that we haven’t even met him yet).</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/OCGamerboy"> /u/OCGamerboy </a> &#32; to &#32; <a href="https://www.reddit.com/r/HelluvaBoss/"> r/HelluvaBoss </a> <br /> <span><a href="https://i.redd.it/dp1pqlvbrsed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HelluvaBoss/comments/1ecg0qf/which_characters_orientation_reveal_surprised_

## And somehow, it just KNOWS IT ALL
 - [https://www.reddit.com/r/memes/comments/1ecg08x/and_somehow_it_just_knows_it_all](https://www.reddit.com/r/memes/comments/1ecg08x/and_somehow_it_just_knows_it_all)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T05:12:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/memes/comments/1ecg08x/and_somehow_it_just_knows_it_all/"> <img alt="And somehow, it just KNOWS IT ALL" src="https://preview.redd.it/euxh9st6rsed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7680dc6be19aa6220f9c661128ae7373ad6008ab" title="And somehow, it just KNOWS IT ALL" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mindnessss"> /u/Mindnessss </a> &#32; to &#32; <a href="https://www.reddit.com/r/memes/"> r/memes </a> <br /> <span><a href="https://i.redd.it/euxh9st6rsed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/memes/comments/1ecg08x/and_somehow_it_just_knows_it_all/">[comments]</a></span> </td></tr></table>

## Path of Building and how it works with PoB Archives
 - [https://www.reddit.com/r/pathofexile/comments/1ecfmhs/path_of_building_and_how_it_works_with_pob](https://www.reddit.com/r/pathofexile/comments/1ecfmhs/path_of_building_and_how_it_works_with_pob)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T04:49:59+00:00

<!-- SC_OFF --><div class="md"><p>Hey everyone,</p> <p>Today we released a new feature in Path of Building showing the latest and trending builds from various websites that want to integrate with PoB. PoB Archives was the first site to integrate with this feature, as the owner of that site coded and integrated the feature with PoB, but it was designed so other sites can be featured there too. This was initially brought up 5 months ago with some concerns, most of those concerns were addressed, so we wanted to release it to get broader feedback.</p> <p>As we've seen, a part of the community is not a fan of a feature like this, and even though it can be turned off, we've decided to remove the trending and latest builds from the build list page until we can find a better way to integrate something similar. The API will stay disabled until we release an update to remove the boxes from view. We've decided to keep the &quot;Similar Builds&quot; button at the top of the window (with a config 

## I lost my house and my cat to a fire yesterday. 90% of my board are done. My setup is cooked. Pc may be OK, but got water and smoke damage.
 - [https://www.reddit.com/r/pcmasterrace/comments/1ecfin0/i_lost_my_house_and_my_cat_to_a_fire_yesterday_90](https://www.reddit.com/r/pcmasterrace/comments/1ecfin0/i_lost_my_house_and_my_cat_to_a_fire_yesterday_90)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T04:43:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/pcmasterrace/comments/1ecfin0/i_lost_my_house_and_my_cat_to_a_fire_yesterday_90/"> <img alt="I lost my house and my cat to a fire yesterday. 90% of my board are done. My setup is cooked. Pc may be OK, but got water and smoke damage. " src="https://b.thumbs.redditmedia.com/o6F85jzhmIj0nK_LyrzVyubzLlDfJg0ySVYsJW-nmag.jpg" title="I lost my house and my cat to a fire yesterday. 90% of my board are done. My setup is cooked. Pc may be OK, but got water and smoke damage. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/RandyAutoTechSystem"> /u/RandyAutoTechSystem </a> &#32; to &#32; <a href="https://www.reddit.com/r/pcmasterrace/"> r/pcmasterrace </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecfin0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pcmasterrace/comments/1ecfin0/i_lost_my_house_and_my_cat_to_a_fire_yesterday_90/">[comments]</a></span> </td></tr></table>

## Can dicks literally be to big for someone?
 - [https://www.reddit.com/r/NoStupidQuestions/comments/1ecfczi/can_dicks_literally_be_to_big_for_someone](https://www.reddit.com/r/NoStupidQuestions/comments/1ecfczi/can_dicks_literally_be_to_big_for_someone)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T04:34:09+00:00

<!-- SC_OFF --><div class="md"><p>My boyfriend (20m) is pretty big, it's def above 6.5 inches. the problem is, in certain positions and it's all the way in, it causes this awful pain. Does anyone know what this? is this common? thank you!</p> <p>(should be too*, typed too fast lol)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CompleteMode6902"> /u/CompleteMode6902 </a> &#32; to &#32; <a href="https://www.reddit.com/r/NoStupidQuestions/"> r/NoStupidQuestions </a> <br /> <span><a href="https://www.reddit.com/r/NoStupidQuestions/comments/1ecfczi/can_dicks_literally_be_to_big_for_someone/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/NoStupidQuestions/comments/1ecfczi/can_dicks_literally_be_to_big_for_someone/">[comments]</a></span>

## My wife found a frog today.
 - [https://www.reddit.com/r/mildyinteresting/comments/1ecfai4/my_wife_found_a_frog_today](https://www.reddit.com/r/mildyinteresting/comments/1ecfai4/my_wife_found_a_frog_today)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T04:30:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildyinteresting/comments/1ecfai4/my_wife_found_a_frog_today/"> <img alt="My wife found a frog today. " src="https://preview.redd.it/lz764g1ijsed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=458b1d07fbbecf7f4f9e09baf44d1199e27ee441" title="My wife found a frog today. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AppendixF"> /u/AppendixF </a> &#32; to &#32; <a href="https://www.reddit.com/r/mildyinteresting/"> r/mildyinteresting </a> <br /> <span><a href="https://i.redd.it/lz764g1ijsed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/mildyinteresting/comments/1ecfai4/my_wife_found_a_frog_today/">[comments]</a></span> </td></tr></table>

## this has happened to a good amount of yall
 - [https://www.reddit.com/r/whenthe/comments/1ecer5q/this_has_happened_to_a_good_amount_of_yall](https://www.reddit.com/r/whenthe/comments/1ecer5q/this_has_happened_to_a_good_amount_of_yall)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T03:59:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1ecer5q/this_has_happened_to_a_good_amount_of_yall/"> <img alt="this has happened to a good amount of yall" src="https://preview.redd.it/ll12j1k0esed1.gif?width=320&amp;crop=smart&amp;s=70abe33c2e5407cdf0f9cd44649a3e4022057624" title="this has happened to a good amount of yall" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sire_Satire"> /u/Sire_Satire </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br /> <span><a href="https://i.redd.it/ll12j1k0esed1.gif">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1ecer5q/this_has_happened_to_a_good_amount_of_yall/">[comments]</a></span> </td></tr></table>

## r/Grimdank, what is your profession?
 - [https://www.reddit.com/r/Grimdank/comments/1eceazp/rgrimdank_what_is_your_profession](https://www.reddit.com/r/Grimdank/comments/1eceazp/rgrimdank_what_is_your_profession)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T03:34:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Grimdank/comments/1eceazp/rgrimdank_what_is_your_profession/"> <img alt="r/Grimdank, what is your profession?" src="https://preview.redd.it/65gpmbhm9sed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=036112cefda50b1894d9f343e43c68469ab5d3ca" title="r/Grimdank, what is your profession?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/1stLegionBestLegion"> /u/1stLegionBestLegion </a> &#32; to &#32; <a href="https://www.reddit.com/r/Grimdank/"> r/Grimdank </a> <br /> <span><a href="https://i.redd.it/65gpmbhm9sed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Grimdank/comments/1eceazp/rgrimdank_what_is_your_profession/">[comments]</a></span> </td></tr></table>

## My friend works in film and is convinced that Tom Cruise wants to die on camera. Balls of steel
 - [https://www.reddit.com/r/nextfuckinglevel/comments/1ecdqz5/my_friend_works_in_film_and_is_convinced_that_tom](https://www.reddit.com/r/nextfuckinglevel/comments/1ecdqz5/my_friend_works_in_film_and_is_convinced_that_tom)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T03:05:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/nextfuckinglevel/comments/1ecdqz5/my_friend_works_in_film_and_is_convinced_that_tom/"> <img alt="My friend works in film and is convinced that Tom Cruise wants to die on camera. Balls of steel" src="https://external-preview.redd.it/Z2FsNm8xMzQ0c2VkMQHom5kiUQ_vCEvJVkOvpUojtpj4xQ-A94a1JhfN_RTV.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=903cd8332d35b989ef9acd99a2376617a8786a34" title="My friend works in film and is convinced that Tom Cruise wants to die on camera. Balls of steel" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JoyfulHaven"> /u/JoyfulHaven </a> &#32; to &#32; <a href="https://www.reddit.com/r/nextfuckinglevel/"> r/nextfuckinglevel </a> <br /> <span><a href="https://v.redd.it/49kh32344sed1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/nextfuckinglevel/comments/1ecdqz5/my_friend_works_in_film_and_is_convinced_that_tom/">[comments]</a></span> </td></tr></table>

## me_irl
 - [https://www.reddit.com/r/me_irl/comments/1eccpr7/me_irl](https://www.reddit.com/r/me_irl/comments/1eccpr7/me_irl)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T02:12:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/me_irl/comments/1eccpr7/me_irl/"> <img alt="me_irl" src="https://preview.redd.it/cdprks80vred1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8bd1b776928f03d349fb0d8bdbe1e8aeeeee16d2" title="me_irl" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Morning1980"> /u/Morning1980 </a> &#32; to &#32; <a href="https://www.reddit.com/r/me_irl/"> r/me_irl </a> <br /> <span><a href="https://i.redd.it/cdprks80vred1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/me_irl/comments/1eccpr7/me_irl/">[comments]</a></span> </td></tr></table>

## Wouldn’t a cat girl champ be free lp for Riot?
 - [https://www.reddit.com/r/leagueoflegends/comments/1eccosx/wouldnt_a_cat_girl_champ_be_free_lp_for_riot](https://www.reddit.com/r/leagueoflegends/comments/1eccosx/wouldnt_a_cat_girl_champ_be_free_lp_for_riot)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T02:11:14+00:00

<!-- SC_OFF --><div class="md"><p>Like they really made a rabbit girl champ, a fox girl champ and a lizard girl champ before a cat girl champ? Why?</p> <p>Cat girls are insanely popular among degenerates (Which is a big portion of Leagues player base) so why hasn’t Riot created a cat girl champ yet? </p> <p>I feel like if Riot did just make a young and cutesy uwu cat girl champ she would have a 100% pick/ban rate even if she’s weak… Am I wrong?</p> <p>Is this not just free lp for Riot from a business stand point?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rose_main"> /u/rose_main </a> &#32; to &#32; <a href="https://www.reddit.com/r/leagueoflegends/"> r/leagueoflegends </a> <br /> <span><a href="https://www.reddit.com/r/leagueoflegends/comments/1eccosx/wouldnt_a_cat_girl_champ_be_free_lp_for_riot/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/leagueoflegends/comments/1eccosx/wouldnt_a_cat_girl_champ_be_free_lp_for_riot/">[

## We don't deserve them. I hope the dog's owner is okay.
 - [https://www.reddit.com/r/Satisfyingasfuck/comments/1eccokw/we_dont_deserve_them_i_hope_the_dogs_owner_is_okay](https://www.reddit.com/r/Satisfyingasfuck/comments/1eccokw/we_dont_deserve_them_i_hope_the_dogs_owner_is_okay)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T02:10:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Satisfyingasfuck/comments/1eccokw/we_dont_deserve_them_i_hope_the_dogs_owner_is_okay/"> <img alt="We don't deserve them. I hope the dog's owner is okay." src="https://external-preview.redd.it/d3Mxb2t0Z2p1cmVkMeSHoUSbhfvZQeaHsSW3Sr4ySAIN_JQVvnvQ1gdmoPQp.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=b90b007fbd79e92bc6aed9f8289c18581c0ae05f" title="We don't deserve them. I hope the dog's owner is okay." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SereneStyle2"> /u/SereneStyle2 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Satisfyingasfuck/"> r/Satisfyingasfuck </a> <br /> <span><a href="https://v.redd.it/ezei3ogjured1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Satisfyingasfuck/comments/1eccokw/we_dont_deserve_them_i_hope_the_dogs_owner_is_okay/">[comments]</a></span> </td></tr></table>

## Jaka jest najdziwniejsza plotka, która krążyła po waszej szkole?
 - [https://www.reddit.com/r/Polska/comments/1ecbssg/jaka_jest_najdziwniejsza_plotka_która_krążyła_po](https://www.reddit.com/r/Polska/comments/1ecbssg/jaka_jest_najdziwniejsza_plotka_która_krążyła_po)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T01:25:18+00:00

<!-- SC_OFF --><div class="md"><p>Może być coś co okazało się prawdą.</p> <p>U mnie klasycznie zaciążyła uczennica z nauczycielem, szczur w słoiku w czyjejś szafce itd</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mahboilucas"> /u/mahboilucas </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://www.reddit.com/r/Polska/comments/1ecbssg/jaka_jest_najdziwniejsza_plotka_która_krążyła_po/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1ecbssg/jaka_jest_najdziwniejsza_plotka_która_krążyła_po/">[comments]</a></span>

## A chia seed sprouted from my toothbrush
 - [https://www.reddit.com/r/mildlyinteresting/comments/1ecbpt8/a_chia_seed_sprouted_from_my_toothbrush](https://www.reddit.com/r/mildlyinteresting/comments/1ecbpt8/a_chia_seed_sprouted_from_my_toothbrush)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T01:21:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinteresting/comments/1ecbpt8/a_chia_seed_sprouted_from_my_toothbrush/"> <img alt="A chia seed sprouted from my toothbrush" src="https://preview.redd.it/5job54nulred1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1f98decc36b645a0d753dc76431355074d5a57bd" title="A chia seed sprouted from my toothbrush" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Cheez-it_king"> /u/Cheez-it_king </a> &#32; to &#32; <a href="https://www.reddit.com/r/mildlyinteresting/"> r/mildlyinteresting </a> <br /> <span><a href="https://i.redd.it/5job54nulred1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/mildlyinteresting/comments/1ecbpt8/a_chia_seed_sprouted_from_my_toothbrush/">[comments]</a></span> </td></tr></table>

## Average teenager experience
 - [https://www.reddit.com/r/memes/comments/1ecb19o/average_teenager_experience](https://www.reddit.com/r/memes/comments/1ecb19o/average_teenager_experience)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T00:48:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/memes/comments/1ecb19o/average_teenager_experience/"> <img alt="Average teenager experience " src="https://preview.redd.it/tpg2xqmyfred1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f17ecac633a8ec82a5db8d945f5192893d883786" title="Average teenager experience " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/weezer-_-"> /u/weezer-_- </a> &#32; to &#32; <a href="https://www.reddit.com/r/memes/"> r/memes </a> <br /> <span><a href="https://i.redd.it/tpg2xqmyfred1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/memes/comments/1ecb19o/average_teenager_experience/">[comments]</a></span> </td></tr></table>

## Projekt Ordo Iuris trafił do sejmowych komisji. Uderza w osoby transpłciowe
 - [https://www.reddit.com/r/Polska/comments/1eca1gq/projekt_ordo_iuris_trafił_do_sejmowych_komisji](https://www.reddit.com/r/Polska/comments/1eca1gq/projekt_ordo_iuris_trafił_do_sejmowych_komisji)
 - RSS feed: https://www.reddit.com/.rss
 - date published: 2024-07-26T00:01:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1eca1gq/projekt_ordo_iuris_trafił_do_sejmowych_komisji/"> <img alt="Projekt Ordo Iuris trafił do sejmowych komisji. Uderza w osoby transpłciowe" src="https://external-preview.redd.it/jISFmml_3oiNFGBuVOd_w5tlSZl8xI_bFcHBWquXANY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2e61c03a43bcb002d26b8f55836ca2f7f184e747" title="Projekt Ordo Iuris trafił do sejmowych komisji. Uderza w osoby transpłciowe" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/RectangularLynx"> /u/RectangularLynx </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br /> <span><a href="https://wiadomosci.onet.pl/kraj/projekt-ordo-iuris-trafil-do-sejmowych-komisji-uderza-w-osoby-transplciowe/9rwge2w">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1eca1gq/projekt_ordo_iuris_trafił_do_sejmowych_komisji/">[comments]</a></span> </td></tr></table>

