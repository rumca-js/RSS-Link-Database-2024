# Source:Nautilus, URL:https://nautil.us/feed, language:en-US

## Jupiter’s Incredible Shrinking Spot
 - [https://nautil.us/jupiters-incredible-shrinking-spot-738409](https://nautil.us/jupiters-incredible-shrinking-spot-738409)
 - RSS feed: https://nautil.us/feed
 - date published: 2024-07-26T21:02:33+00:00

<p>Earth’s meteorology could explain what’s behind the great red whorl’s waning. </p>
<p>The post <a href="https://nautil.us/jupiters-incredible-shrinking-spot-738409/">Jupiter’s Incredible Shrinking Spot</a> appeared first on <a href="https://nautil.us">Nautilus</a>.</p>

## When the Composer Is a Geneticist
 - [https://nautil.us/when-the-composer-is-a-geneticist-731309](https://nautil.us/when-the-composer-is-a-geneticist-731309)
 - RSS feed: https://nautil.us/feed
 - date published: 2024-07-26T20:32:25+00:00

<p>Jenny Graves tired of singing about Adam and Eve. So she wrote a creation oratorio based on science.</p>
<p>The post <a href="https://nautil.us/when-the-composer-is-a-geneticist-731309/">When the Composer Is a Geneticist</a> appeared first on <a href="https://nautil.us">Nautilus</a>.</p>

