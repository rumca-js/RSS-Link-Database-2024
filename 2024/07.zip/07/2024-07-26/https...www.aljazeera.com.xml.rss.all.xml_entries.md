# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Maduro’s greatest test? All you need to know about Venezuela’s election
 - [https://www.aljazeera.com/news/2024/7/26/maduros-greatest-test-all-you-need-to-know-about-venezuelas-election?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/maduros-greatest-test-all-you-need-to-know-about-venezuelas-election?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T22:48:19+00:00

Dire economic conditions and a galvanised opposition could spell the end of President Nicolas Maduro&#039;s time in power.

## More than 180,000 displaced from Gaza’s Khan Younis in four days, UN says
 - [https://www.aljazeera.com/news/2024/7/26/more-than-180000-displaced-from-gazas-khan-younis-in-four-days-un-says?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/more-than-180000-displaced-from-gazas-khan-younis-in-four-days-un-says?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T21:09:07+00:00

&#039;About 182,000 people&#039; displaced from central and eastern Khan Younis from Monday - Thursday, UN OCHA says.

## Could China’s diplomatic initiatives on the Ukraine war succeed?
 - [https://www.aljazeera.com/program/inside-story/2024/7/26/could-chinas-diplomatic-initiatives-on-the-ukraine-war-succeed?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/7/26/could-chinas-diplomatic-initiatives-on-the-ukraine-war-succeed?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T19:00:02+00:00

Bejing&#039;s diplomacy intensifies as the US and the West help Ukraine fight Russia&#039;s invasion.

## As Maduro faces Gonzalez in Venezuela, sanctions remain a key hurdle
 - [https://www.aljazeera.com/economy/2024/7/26/as-maduro-faces-gonzalez-in-venezuela-sanctions-remain-a-key-hurdle?traffic_source=rss](https://www.aljazeera.com/economy/2024/7/26/as-maduro-faces-gonzalez-in-venezuela-sanctions-remain-a-key-hurdle?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T18:07:15+00:00

US sanctions and years of mismanagement have crippled Venezuela&#039;s oil-based economy and poses challenges for new leader.

## What to watch for at Paris 2024 Olympics: Reusable cups
 - [https://www.aljazeera.com/opinions/2024/7/26/what-to-watch-for-at-paris-2024-olympics-reusable-cups?traffic_source=rss](https://www.aljazeera.com/opinions/2024/7/26/what-to-watch-for-at-paris-2024-olympics-reusable-cups?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T17:45:25+00:00

In the spirit of the Olympics, it’s time for all of us to come together and ditch single-use plastic in favour of reuse.

## UK police officer under criminal investigation over airport incident
 - [https://www.aljazeera.com/news/2024/7/26/uk-police-officer-under-criminal-investigation-over-airport-incident?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/uk-police-officer-under-criminal-investigation-over-airport-incident?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T16:30:24+00:00

Police watchdog confirms officer is due to be interviewed after video shared online of suspect being kicked.

## Bangladesh minister on government’s response to deadly anti-quota protests
 - [https://www.aljazeera.com/program/talk-to-al-jazeera/2024/7/26/bangladesh-minister-on-governments-response-to-deadly-anti-quota-protests?traffic_source=rss](https://www.aljazeera.com/program/talk-to-al-jazeera/2024/7/26/bangladesh-minister-on-governments-response-to-deadly-anti-quota-protests?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T14:54:43+00:00

Bangladesh Information Minister Mohammad Arafat talks to Al Jazeera about deadly anti-quota protests and unrest.

## Is traditional marriage doomed for millennials and Gen Z?
 - [https://www.aljazeera.com/program/the-stream/2024/7/26/is-traditional-marriage-doomed-for-millennials-and-gen-z?traffic_source=rss](https://www.aljazeera.com/program/the-stream/2024/7/26/is-traditional-marriage-doomed-for-millennials-and-gen-z?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T14:15:00+00:00

We delve into the declining marriage rates, focusing on Asia, and analyse the contributing factors to this trend.

## Should Israel be banned from the Olympics?
 - [https://www.aljazeera.com/program/newsfeed/2024/7/26/should-israel-be-banned-from-the-olympics?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/7/26/should-israel-be-banned-from-the-olympics?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T13:12:32+00:00

Pro-Palestine activists are calling for Israel to be banned from the Olympics.

## Sri Lanka presidential election set for September 21 amid ailing economy
 - [https://www.aljazeera.com/news/2024/7/26/sri-lanka-presidential-election-set-for-september-21-amid-ailing?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/sri-lanka-presidential-election-set-for-september-21-amid-ailing?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T13:08:55+00:00

President Wickremesinghe is first candidate to register at the Election Commission as he seeks mandate from voters.

## Obamas endorse VP Harris in US presidential election
 - [https://www.aljazeera.com/program/newsfeed/2024/7/26/obamas-endorse-vp-harris-in-us-presidential-election?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/7/26/obamas-endorse-vp-harris-in-us-presidential-election?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T13:08:47+00:00

US Vice President Kamala Harris has released video of her receiving an endorsement from Barack and Michelle Obama.

## US intercepts Russian, Chinese bombers near Alaska: What we know
 - [https://www.aljazeera.com/news/2024/7/26/us-intercepts-russian-chinese-bombers-near-alaska-what-we-know?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/us-intercepts-russian-chinese-bombers-near-alaska-what-we-know?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T12:53:57+00:00

The joint flight highlights growing military cooperation between the two countries, sparking concerns in the US.

## For a fair world, stand with Palestine
 - [https://www.aljazeera.com/opinions/2024/7/26/for-a-fair-world-stand-with-palestine?traffic_source=rss](https://www.aljazeera.com/opinions/2024/7/26/for-a-fair-world-stand-with-palestine?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T12:37:18+00:00

We all have a duty, through organised events or individual efforts, to contribute to the broader struggle for justice.

## Huge crowds at Venezuela opposition’s final election rally
 - [https://www.aljazeera.com/program/newsfeed/2024/7/26/huge-crowds-at-venezuela-oppositions-final-election-rally?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/7/26/huge-crowds-at-venezuela-oppositions-final-election-rally?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T12:25:23+00:00

Huge crowds came out for the final election rally by Venezuela’s opposition ahead of the vote on Sunday.

## UK won’t challenge ICC arrest warrant request for Netanyahu, Gallant
 - [https://www.aljazeera.com/news/2024/7/26/uk-wont-challenge-icc-arrest-warrant-request-for-netanyahu-gallant?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/uk-wont-challenge-icc-arrest-warrant-request-for-netanyahu-gallant?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T11:52:44+00:00

The new Labour government of Keir Starmer has decided against seeking a block on arrest warrants for Israel&#039;s leaders.

## Search for hundreds missing after deadly landslides in Ethiopia
 - [https://www.aljazeera.com/gallery/2024/7/26/search-for-hundreds-missing-after-deadly-landslides-in-ethiopia?traffic_source=rss](https://www.aljazeera.com/gallery/2024/7/26/search-for-hundreds-missing-after-deadly-landslides-in-ethiopia?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T11:50:57+00:00

The UN said more than 250 people were killed in twin landslides in a remote, mountainous area of southern Ethiopia.

## Thousands in Vietnam mourn at funeral of Communist Party chief Trong
 - [https://www.aljazeera.com/news/2024/7/26/thousands-in-vietnam-mourn-at-funeral-of-communist-party-chief-trong?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/thousands-in-vietnam-mourn-at-funeral-of-communist-party-chief-trong?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T11:12:10+00:00

The 80-year-old leader&#039;s death sets the stage for a leadership race during the National Party Congress in 2026.

## Gang killed 26 villagers in northern Papua New Guinea: Police
 - [https://www.aljazeera.com/news/2024/7/26/gang-killed-26-villagers-in-northern-papua-new-guinea-police?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/gang-killed-26-villagers-in-northern-papua-new-guinea-police?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T09:53:19+00:00

Tribal violence escalating with influx of mercenaries and automatic weapons into the strained island nation.

## Why have Brazilian sharks tested positive for cocaine?
 - [https://www.aljazeera.com/news/2024/7/26/why-have-brazilian-sharks-tested-positive-for-cocaine?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/why-have-brazilian-sharks-tested-positive-for-cocaine?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T09:46:46+00:00

Study finds rise in numbers of people using the drug is causing large quantities to leak into the sea.

## Barack Obama endorses Kamala Harris for US president
 - [https://www.aljazeera.com/news/2024/7/26/barack-obama-endorses-kamala-harris-for-us-president?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/barack-obama-endorses-kamala-harris-for-us-president?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T09:45:53+00:00

Nod from former US president and wife Michelle means Harris has won backing of all key Democrats.

## French rail hit by ‘massive attack’ as Olympics begin
 - [https://www.aljazeera.com/program/newsfeed/2024/7/26/french-rail-hit-by-massive-attack-as-olympics-begin?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/7/26/french-rail-hit-by-massive-attack-as-olympics-begin?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T09:16:26+00:00

France’s high-speed rail network has been hit by a series of arson attacks.

## A year after Niger’s coup, split political loyalties test family ties
 - [https://www.aljazeera.com/features/2024/7/26/a-year-after-nigers-coup-split-political-loyalties-test-family-ties?traffic_source=rss](https://www.aljazeera.com/features/2024/7/26/a-year-after-nigers-coup-split-political-loyalties-test-family-ties?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T08:14:14+00:00

While many Nigeriens have welcomed the military rulers, others question their rhetoric and approach towards governance.

## Premier of Canada’s Alberta gets tearful during wildfire news update
 - [https://www.aljazeera.com/program/newsfeed/2024/7/26/premier-of-canadas-alberta-gets-tearful-during-wildfire-news-update?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/7/26/premier-of-canadas-alberta-gets-tearful-during-wildfire-news-update?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T08:05:11+00:00

The premier of Alberta in Canada fought back tears on Thursday while giving an update on a raging wildfire in Jasper.

## French rail network hit by ‘malicious acts’ ahead of Paris Olympics
 - [https://www.aljazeera.com/news/2024/7/26/french-rail-network-hit-by-malicious-acts-ahead-of-olympic-ceremony?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/french-rail-network-hit-by-malicious-acts-ahead-of-olympic-ceremony?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T07:42:33+00:00

Network disrupted by multiple arson attacks that could paralyse busy routes &#039;at least all weekend&#039;.

## Russia-Ukraine war: List of key events, day 882
 - [https://www.aljazeera.com/news/2024/7/26/russia-ukraine-war-list-of-key-events-day-882?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/russia-ukraine-war-list-of-key-events-day-882?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T07:34:20+00:00

As the war enters its 882nd day, these are the main developments.

## Venezuela presidential candidates hold final rallies ahead of election
 - [https://www.aljazeera.com/news/2024/7/26/venezuela-presidential-candidates-hold-final-rallies-ahead-of-election?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/venezuela-presidential-candidates-hold-final-rallies-ahead-of-election?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T07:16:24+00:00

The incumbent President Nicolas Maduro and main contender Edmundo Gonzalez Urrutia have wrapped up their campaigns.

## Why BJP’s election upset failed to halt the persecution of Muslims in India
 - [https://www.aljazeera.com/opinions/2024/7/26/why-bjps-election-upset-failed-to-halt-the-persecution-of-muslims-in-india?traffic_source=rss](https://www.aljazeera.com/opinions/2024/7/26/why-bjps-election-upset-failed-to-halt-the-persecution-of-muslims-in-india?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T07:03:54+00:00

Authorities in BJP-governed states responded to the electoral setback by inventing novel methods to attack Muslims.

## Harris says she won’t be ‘silent’ on Gaza after Netanyahu meeting
 - [https://www.aljazeera.com/program/newsfeed/2024/7/26/harris-says-she-wont-be-silent-on-gaza-after-netanyahu-meeting?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/7/26/harris-says-she-wont-be-silent-on-gaza-after-netanyahu-meeting?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T07:02:43+00:00

Vice President Kamala Harris insisted she would not be ‘silent’ on the suffering in Gaza.

## Which countries have been banned from participating in the Olympics?
 - [https://www.aljazeera.com/news/2024/7/26/which-countries-have-been-banned-from-participating-in-the-olympics?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/which-countries-have-been-banned-from-participating-in-the-olympics?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T06:52:02+00:00

Thirteen countries have been banned from the Olympics in the past. Which are they, and why were they barred?

## Mexican drug lord ‘El Mayo’ Zambada and son of ‘El Chapo’ arrested in Texas
 - [https://www.aljazeera.com/news/2024/7/26/mexican-drug-lord-el-mayo-zambada-and-son-of-el-chapo-arrested-in-texas?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/mexican-drug-lord-el-mayo-zambada-and-son-of-el-chapo-arrested-in-texas?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T05:55:44+00:00

In a major blow to the Sinaloa cartel, Ismael Zambada Garcia and Joaquin Guzman were detained after landing in El Paso.

## Journalists at Australian newspapers go on strike on eve of Olympics
 - [https://www.aljazeera.com/economy/2024/7/26/journalists-at-australian-newspapers-go-on-strike-on-eve-of-olympics?traffic_source=rss](https://www.aljazeera.com/economy/2024/7/26/journalists-at-australian-newspapers-go-on-strike-on-eve-of-olympics?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T04:24:30+00:00

Editorial staff vote to walk off the job after rejecting annual pay increase of between 3 and 4 percent.

## Harris says she won’t be ‘silent’ on Gaza suffering after Netanyahu meeting
 - [https://www.aljazeera.com/news/2024/7/26/harris-says-she-wont-be-silent-on-gaza-suffering-after-netanyahu-meeting?traffic_source=rss](https://www.aljazeera.com/news/2024/7/26/harris-says-she-wont-be-silent-on-gaza-suffering-after-netanyahu-meeting?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-07-26T02:49:23+00:00

De facto presidential nominee draws attention to Palestinians&#039; plight as she walks fine line on divisive conflict.

