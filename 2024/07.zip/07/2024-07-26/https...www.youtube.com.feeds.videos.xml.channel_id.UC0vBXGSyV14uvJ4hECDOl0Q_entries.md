# Source:Techquickie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q, language:en-US

## AMD Almost Went Bankrupt…but were saved by Sony and Microsoft?
 - [https://www.youtube.com/watch?v=4c17zAW6Q54](https://www.youtube.com/watch?v=4c17zAW6Q54)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q
 - date published: 2024-07-26T18:35:03+00:00

Check out DeleteMe here: http://joindeleteme.com/techquickie

AMD was in big trouble years ago - did Sony and Microsoft's decision to have AMD design the chips for the PlayStation 4 and Xbox One save Team Red?

Leave a reply with your requests for future episodes.

► GET MERCH: https://lttstore.com
► GET A VPN: https://www.piavpn.com/TechQuickie
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

