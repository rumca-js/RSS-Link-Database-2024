# Source:Pluralistic: Daily links from Cory Doctorow, URL:https://pluralistic.net/feed, language:en-US

## Pluralistic: Fintech bullies stole your kid's lunch money (26 Jul 2024)
 - [https://pluralistic.net/2024/07/26/taanstafl](https://pluralistic.net/2024/07/26/taanstafl)
 - RSS feed: https://pluralistic.net/feed
 - date published: 2024-07-26T18:33:58+00:00

Today's links Fintech bullies stole your kid's lunch money: Taking 60 cents out of every reduced-lunch public school dollar. Hey look at this: Delights to delectate. This day in history: 2004, 2009, 2019, 2023 Upcoming appearances: Where to find me. Recent appearances: Where I've been. Latest books: You keep readin' em, I'll keep writin' 'em. Upcoming books: Like I said, I'll keep writin' 'em. Colophon: All the rest. Fintech bullies stole your kid's lunch money (permalink) Three companies control the market for school lunch payments. They take as much as 60 cents out of every dollar poor kids' parents put into the system to the tune of $100m/year. They're literally stealing poor kids' lunch money. In its latest report, the Consumer Finance Protection Bureau describes this scam in eye-watering, blood-boiling detail: https://files.consumerfinance.gov/f/documents/cfpb_costs-of-electronic-payment-in-k-12-schools-issue-spotlight_2024-07.pdf The report samples 16.7m K-12 students in 25k sch

