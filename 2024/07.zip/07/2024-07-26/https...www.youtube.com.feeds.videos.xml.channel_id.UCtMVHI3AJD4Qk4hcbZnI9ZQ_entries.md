# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## This Company ALLEGEDLY Stole Marques Brownlee's and LTT's Videos...
 - [https://www.youtube.com/watch?v=zBTs2Yth_Ac](https://www.youtube.com/watch?v=zBTs2Yth_Ac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2024-07-26T21:27:04+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at AI companies once again,  in this case Runway. Training data is the lifeblood to standing out amongst the crown and it appears that allegedly this company was using YouTubers content without permission all while raising millions of dollars. Thanks for watching!
Like, Comment and Subscribe for more videos!

