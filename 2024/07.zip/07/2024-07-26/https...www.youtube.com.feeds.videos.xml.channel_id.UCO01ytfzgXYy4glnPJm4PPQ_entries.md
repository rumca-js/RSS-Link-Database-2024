# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Newsom Pretends to Tackle Homelessness In Election Season Stunt
 - [https://www.youtube.com/watch?v=BLwhGuIJWzY](https://www.youtube.com/watch?v=BLwhGuIJWzY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-26T22:30:01+00:00

California begins to clean out the homeless encampments just in time for the election. It's about that time when guys like Gavin Newsom temporarily pretend to care about the well-being of American families.

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep. 1410 - https://bit.ly/3zWbf7b

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## This is NOT healthy coping
 - [https://www.youtube.com/watch?v=A24Ix7T--_k](https://www.youtube.com/watch?v=A24Ix7T--_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-26T20:00:08+00:00



## Cleaning Out The Homeless Encampments Just In Time For The Election | Ep. 1410
 - [https://www.youtube.com/watch?v=fT1p3SJjvk8](https://www.youtube.com/watch?v=fT1p3SJjvk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-26T18:26:21+00:00

Today on the Matt Walsh Show, California begins to clean out the homeless encampments just in time for the election. It's about that time when guys like Gavin Newsom temporarily pretend to care about the well-being of American families. Also, the media and Hollywood continue to dogpile JD Vance for his (completely true) comments about "childless cat ladies." And, Kamala Harris makes a play for the drag queen vote.

TIMESTAMPS:

00:00 - 00:31 Opening
01:49 - 16:04 Cleaning Out The Homeless Encampments Just In Time For The Election 
16:50 - 28:45 In Order To Win Female Voters, We Apparently Need To Stop Telling The Truth
28:46 - 33:48 Kamala Harris Goes On RuPaul's Drag Race
33:49 - 37:13 Southwest Does Away With Its Open Seating Policy
37:14 - 45:03 Politico Claims Kamala Needs More Protection Than Trump
46:57 - 1:00:00 Head To DailyWire.Com To Hear Today's Cancelation

Ep.1410

- - - 

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new

## Men, get out your comfort zone
 - [https://www.youtube.com/watch?v=Py1qHEB3jkE](https://www.youtube.com/watch?v=Py1qHEB3jkE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-26T17:00:17+00:00



## The Best Nicknames Trump Should Use for Kamala
 - [https://www.youtube.com/watch?v=pRkvebkaiSQ](https://www.youtube.com/watch?v=pRkvebkaiSQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-26T00:00:23+00:00

Trump used "Lyin' Kamala" as his nickname for the new Democratic nominee at his most recent rally, but I think he could do better. 

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep. 1409 - https://bit.ly/3Yl6Ipi

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

