# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Trump i Netanjahu spotkali się twarzą w twarz. Padło ostrzeżenie
 - [https://wydarzenia.interia.pl/zagranica/news-trump-i-netanjahu-spotkali-sie-twarza-w-twarz-padlo-ostrzeze,nId,7723894](https://wydarzenia.interia.pl/zagranica/news-trump-i-netanjahu-spotkali-sie-twarza-w-twarz-padlo-ostrzeze,nId,7723894)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T20:29:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-trump-i-netanjahu-spotkali-sie-twarza-w-twarz-padlo-ostrzeze,nId,7723894"><img align="left" alt="Trump i Netanjahu spotkali się twarzą w twarz. Padło ostrzeżenie" src="https://i.iplsc.com/trump-i-netanjahu-spotkali-sie-twarza-w-twarz-padlo-ostrzeze/000JJ1VWKTGRJGNX-C321.jpg" /></a>Donald Trump spotkał się z premierem Izraela Benjaminem Netanjahu. Kandydat republikanów oświadczył, że jeśli ponownie zostanie prezydentem USA, konflikty na Bliskim Wschodzie zostaną szybko rozwiązane. Przy okazji Trump skrytykował swoją prawdopodobną rywalkę w wyścigu o Biały Dom, Kamlę Harris.  </p><br clear="all" />

## Nowe fakty o skazanym Niemcu na Białorusi. "Pewnego dnia po prostu zniknął"
 - [https://wydarzenia.interia.pl/zagranica/news-nowe-fakty-o-skazanym-niemcu-na-bialorusi-pewnego-dnia-po-pr,nId,7723846](https://wydarzenia.interia.pl/zagranica/news-nowe-fakty-o-skazanym-niemcu-na-bialorusi-pewnego-dnia-po-pr,nId,7723846)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T18:04:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowe-fakty-o-skazanym-niemcu-na-bialorusi-pewnego-dnia-po-pr,nId,7723846"><img align="left" alt="Nowe fakty o skazanym Niemcu na Białorusi. &quot;Pewnego dnia po prostu zniknął&quot;" src="https://i.iplsc.com/nowe-fakty-o-skazanym-niemcu-na-bialorusi-pewnego-dnia-po-pr/000JJ1NL29768Q0Q-C321.jpg" /></a>Obywatel Niemiec, Rico Krieger, został skazany na Białorusi na karę śmierci. Sprawą zainteresowały się niemieckie media, które dotarły do znajomych mężczyzny. Okazuje się, że 30-latek pracował dla Niemieckiego Czerwonego Krzyża i chciał wyemigrować do USA. Zamiast do Stanów Zjednoczonych pojechał jednak na Ukrainę. Kilka dni później pojawiła się informacja, że został zatrzymany na Białorusi.</p><br clear="all" />

## Jaką strategię powinna obrać Harris? Media wskazują na istotny szczegół
 - [https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-jaka-strategie-powinna-obrac-harris-media-wskazuja-na-istotn,nId,7723832](https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-jaka-strategie-powinna-obrac-harris-media-wskazuja-na-istotn,nId,7723832)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T17:07:42+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-jaka-strategie-powinna-obrac-harris-media-wskazuja-na-istotn,nId,7723832"><img align="left" alt="Jaką strategię powinna obrać Harris? Media wskazują na istotny szczegół" src="https://i.iplsc.com/jaka-strategie-powinna-obrac-harris-media-wskazuja-na-istotn/000JJ1EUKMHH2T0I-C321.jpg" /></a>&quot;Amerykanie mają nareszcie do czynienia z prawdziwym wyścigiem, i to dobra zmiana&quot; - ocenił &quot;The Economist&quot; niemal tydzień po tym, jak Joe Biden zrezygnował z reelekcji a do gry na jego miejsce stara się wejść Kamala Harris. Brytyjski tygodnik uważa, że demokratka może wygrać polityczne starcie z Donaldem Trumpem. W publikacji wyliczono, na co była prokurator generalna Kalifornii powinna zwrócić uwagę i jaką strategię obrać.</p><br clear="all" />

## Niemiecki poseł apeluje do Scholza. Chodzi o pieniądze dla Polaków
 - [https://wydarzenia.interia.pl/zagranica/news-niemiecki-posel-apeluje-do-scholza-chodzi-o-pieniadze-dla-po,nId,7723814](https://wydarzenia.interia.pl/zagranica/news-niemiecki-posel-apeluje-do-scholza-chodzi-o-pieniadze-dla-po,nId,7723814)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T17:02:57+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemiecki-posel-apeluje-do-scholza-chodzi-o-pieniadze-dla-po,nId,7723814"><img align="left" alt="Niemiecki poseł apeluje do Scholza. Chodzi o pieniądze dla Polaków" src="https://i.iplsc.com/niemiecki-posel-apeluje-do-scholza-chodzi-o-pieniadze-dla-po/000JJ1CVV4YHJ9NI-C321.jpg" /></a>Wzywam kanclerza (Olafa - red.) Scholza, aby wreszcie zamienił pięknie brzmiące niedzielne przemówienia w czyny - zaapelował Soeren Pellmann, zwracając się do niemieckiego rządu, aby ten &quot;natychmiast wypłacił miliard euro&quot; osobom, które ocalały niemiecką okupację Polski podczas II wojny światowej. &quot;Przynajmniej tyle moglibyśmy zrobić&quot; - dodał Pellmann w oświadczeniu.</p><br clear="all" />

## Rosyjski statek na terytorium Finlandii. Nie odpowiadał na wezwania
 - [https://wydarzenia.interia.pl/zagranica/news-rosyjski-statek-na-terytorium-finlandii-nie-odpowiadal-na-we,nId,7723647](https://wydarzenia.interia.pl/zagranica/news-rosyjski-statek-na-terytorium-finlandii-nie-odpowiadal-na-we,nId,7723647)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T16:11:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosyjski-statek-na-terytorium-finlandii-nie-odpowiadal-na-we,nId,7723647"><img align="left" alt="Rosyjski statek na terytorium Finlandii. Nie odpowiadał na wezwania" src="https://i.iplsc.com/rosyjski-statek-na-terytorium-finlandii-nie-odpowiadal-na-we/000JJ1CKPCJPWGJD-C321.jpg" /></a>Rosyjski statek został zauważony na wodach fińskich, we wschodniej części Zatoki Fińskiej. Straż Graniczna wszczęła postępowanie i poinformowała, że był to statek badawczy Michaił Kazanskij z Floty Bałtyckiej. Załoga nie odpowiadała na radiowe wezwania ze strony fińskich patroli.</p><br clear="all" />

## Nowa taktyka Rosji. Tania broń ze specjalną misją na Ukrainie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowa-taktyka-rosji-tania-bron-ze-specjalna-misja-na-ukrainie,nId,7723385](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowa-taktyka-rosji-tania-bron-ze-specjalna-misja-na-ukrainie,nId,7723385)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T14:14:38+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowa-taktyka-rosji-tania-bron-ze-specjalna-misja-na-ukrainie,nId,7723385"><img align="left" alt="Nowa taktyka Rosji. Tania broń ze specjalną misją na Ukrainie" src="https://i.iplsc.com/nowa-taktyka-rosji-tania-bron-ze-specjalna-misja-na-ukrainie/000JJ0Q44TSLK1F4-C321.jpg" /></a>Rosjanie wprowadzają na front nowe i znacznie tańsze drony. Statki bezzałogowe wyposażone są w kamery i karty SIM, dzięki czemu niemal natychmiast mogą wysyłać zdjęcia terenu do rosyjskiego wojska. Drony wykonane z pianki i sklejki mają być wabikami - ukraińskie systemy obrony nie są w stanie ich odróżnić od Shahedów, przez co muszą je neutralizować. Tym samym ujawniają swoje pozycje.</p><br clear="all" />

## Afera na Kremlu. "Bohater Rosji" zatrzymany
 - [https://wydarzenia.interia.pl/zagranica/news-afera-na-kremlu-bohater-rosji-zatrzymany,nId,7723380](https://wydarzenia.interia.pl/zagranica/news-afera-na-kremlu-bohater-rosji-zatrzymany,nId,7723380)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T13:59:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-afera-na-kremlu-bohater-rosji-zatrzymany,nId,7723380"><img align="left" alt="Afera na Kremlu. &quot;Bohater Rosji&quot; zatrzymany" src="https://i.iplsc.com/afera-na-kremlu-bohater-rosji-zatrzymany/000JJ0MIEIDADXPO-C321.jpg" /></a>Rosyjska Federalna Służba Bezpieczeństwa (FSB) zatrzymała generała Dmitrija Bułhakowa - byłego wiceministra obrony narodowej. Postawiono mu zarzuty korupcji. W trakcie sprawowania swoich obowiązków w ministerstwie miał odpowiadać za zaopatrywanie żołnierzy w żywność niskiej jakości po zawyżonych kosztach.
</p><br clear="all" />

## Rada UE wszczęła procedurę nadmiernego deficytu m.in. wobec Polski
 - [https://wydarzenia.interia.pl/kraj/news-rada-ue-wszczela-procedure-nadmiernego-deficytu-m-in-wobec-p,nId,7723326](https://wydarzenia.interia.pl/kraj/news-rada-ue-wszczela-procedure-nadmiernego-deficytu-m-in-wobec-p,nId,7723326)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T12:33:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rada-ue-wszczela-procedure-nadmiernego-deficytu-m-in-wobec-p,nId,7723326"><img align="left" alt="Rada UE wszczęła procedurę nadmiernego deficytu m.in. wobec Polski" src="https://i.iplsc.com/rada-ue-wszczela-procedure-nadmiernego-deficytu-m-in-wobec-p/000JIZTGCVEEQIDB-C321.jpg" /></a>Rada Unii Europejskiej wszczęła procedurę nadmiernego deficytu wobec Polski i sześciu innych krajów. W ostatnich dniach trwało pisemne głosowanie ambasadorów państw członkowskich. Objęte postępowaniem państwa będą miały od czterech do siedmiu lat na podjęcie działań naprawczych.</p><br clear="all" />

## Białoruś alarmuje w sprawie Puszczy Białowieskiej. Oskarża Polskę
 - [https://wydarzenia.interia.pl/zagranica/news-bialorus-alarmuje-w-sprawie-puszczy-bialowieskiej-oskarza-po,nId,7723193](https://wydarzenia.interia.pl/zagranica/news-bialorus-alarmuje-w-sprawie-puszczy-bialowieskiej-oskarza-po,nId,7723193)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T11:06:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialorus-alarmuje-w-sprawie-puszczy-bialowieskiej-oskarza-po,nId,7723193"><img align="left" alt="Białoruś alarmuje w sprawie Puszczy Białowieskiej. Oskarża Polskę" src="https://i.iplsc.com/bialorus-alarmuje-w-sprawie-puszczy-bialowieskiej-oskarza-po/000JIZ4JUJ7B183Q-C321.jpg" /></a>Białoruś poskarżyła się na Polskę podczas szczytu UNESCO. Mińsk wskazał na postawiony przez Warszawę mur na granicy. Ten - ich zdaniem - ma mieć fatalne konsekwencje dla Puszczy Białowieskiej. Reżim Łukaszenki zaapelował do międzynarodowej organizacji o przeprowadzenie mediacji między oboma państwami. </p><br clear="all" />

## Pierwszy taki początek igrzysk olimpijskich. Google zaskoczyło grafiką
 - [https://wydarzenia.interia.pl/zagranica/news-pierwszy-taki-poczatek-igrzysk-olimpijskich-google-zaskoczyl,nId,7723087](https://wydarzenia.interia.pl/zagranica/news-pierwszy-taki-poczatek-igrzysk-olimpijskich-google-zaskoczyl,nId,7723087)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T10:08:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pierwszy-taki-poczatek-igrzysk-olimpijskich-google-zaskoczyl,nId,7723087"><img align="left" alt="Pierwszy taki początek igrzysk olimpijskich. Google zaskoczyło grafiką" src="https://i.iplsc.com/pierwszy-taki-poczatek-igrzysk-olimpijskich-google-zaskoczyl/000JIYX8G8UJ6BY0-C321.jpg" /></a>Nie kółka olimpijskie, a pływające po rzece kaczki - tak Google postanowiło przedstawić rozpoczynające się w Paryżu igrzyska olimpijskie. Grafika pojawiła się na stronie głównej wyszukiwarki i przypomina o piątkowej ceremonii otwarcia. Ta, po raz pierwszy w historii, odbędzie się poza stadionem. Francuzi otworzą igrzyska na Sekwanie. </p><br clear="all" />

## Węgry wściekłe na decyzję Kijowa. "Ukraina nas szantażuje"
 - [https://wydarzenia.interia.pl/zagranica/news-wegry-wsciekle-na-decyzje-kijowa-ukraina-nas-szantazuje,nId,7723143](https://wydarzenia.interia.pl/zagranica/news-wegry-wsciekle-na-decyzje-kijowa-ukraina-nas-szantazuje,nId,7723143)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T09:39:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wegry-wsciekle-na-decyzje-kijowa-ukraina-nas-szantazuje,nId,7723143"><img align="left" alt="Węgry wściekłe na decyzję Kijowa. &quot;Ukraina nas szantażuje&quot;" src="https://i.iplsc.com/wegry-wsciekle-na-decyzje-kijowa-ukraina-nas-szantazuje/000JIYTU6JAR0NDV-C321.jpg" /></a>- Ukraina szantażuje Węgry i Słowację odcięciem dostaw rosyjskiej ropy - stwierdził Gergely Gulyas, szef kancelarii premiera Viktora Orbana. Jak stwierdził, Kijów tak działa, ponieważ Budapeszt &quot;popiera zawieszenie broni i rozmowy pokojowe w wojnie rosyjsko-ukraińskiej&quot;, jak Budapeszt nazywa rosyjską inwazję. To niejedyny krytyczny głos płynący z Węgier. Szef MSZ Peter Szijjarto zapowiedział działania odwetowe.</p><br clear="all" />

## Barack i Michelle Obama zdecydowali. Poinformowali przez telefon
 - [https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-barack-i-michelle-obama-zdecydowali-poinformowali-przez-tele,nId,7723144](https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-barack-i-michelle-obama-zdecydowali-poinformowali-przez-tele,nId,7723144)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T09:27:44+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-barack-i-michelle-obama-zdecydowali-poinformowali-przez-tele,nId,7723144"><img align="left" alt="Barack i Michelle Obama zdecydowali. Poinformowali przez telefon " src="https://i.iplsc.com/barack-i-michelle-obama-zdecydowali-poinformowali-przez-tele/000JIYS2Y3H5DDQL-C321.jpg" /></a>Barack i Michelle Obama poparli Kamalę Harris jako kandydatkę demokratów w wyborach prezydenckich. Poinformowali o tym w rozmowie telefonicznej z wiceprezydent USA. Nagranie opublikowano w mediach społecznościowych.</p><br clear="all" />

## Chaos we Francji w pierwszy dzień igrzysk. Ewakuowano lotnisko
 - [https://wydarzenia.interia.pl/zagranica/news-chaos-we-francji-w-pierwszy-dzien-igrzysk-ewakuowano-lotnisk,nId,7723137](https://wydarzenia.interia.pl/zagranica/news-chaos-we-francji-w-pierwszy-dzien-igrzysk-ewakuowano-lotnisk,nId,7723137)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T09:15:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chaos-we-francji-w-pierwszy-dzien-igrzysk-ewakuowano-lotnisk,nId,7723137"><img align="left" alt="Chaos we Francji w pierwszy dzień igrzysk. Ewakuowano lotnisko" src="https://i.iplsc.com/chaos-we-francji-w-pierwszy-dzien-igrzysk-ewakuowano-lotnisk/000JIYTT1VFH320U-C321.jpg" /></a>&quot;Ze względów bezpieczeństwa ewakuowany musiał zostać terminal i jest obecnie zamknięty&quot; - informował port lotniczy EuroAirport. Operacje lotnicze były zawieszone na blisko dwie godziny. Nie podano przyczyny zakłóceń. To niejedyne problemy, jakie wystąpiły w transporcie w dniu otwarcia igrzysk olimpijskich.</p><br clear="all" />

## Ewakuacja na francuskim lotnisku. Zamknięty terminal
 - [https://wydarzenia.interia.pl/zagranica/news-ewakuacja-na-francuskim-lotnisku-zamkniety-terminal,nId,7723137](https://wydarzenia.interia.pl/zagranica/news-ewakuacja-na-francuskim-lotnisku-zamkniety-terminal,nId,7723137)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T09:15:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ewakuacja-na-francuskim-lotnisku-zamkniety-terminal,nId,7723137"><img align="left" alt="Ewakuacja na francuskim lotnisku. Zamknięty terminal" src="https://i.iplsc.com/ewakuacja-na-francuskim-lotnisku-zamkniety-terminal/000JIYTT1VFH320U-C321.jpg" /></a>&quot;Ze względów bezpieczeństwa ewakuowany musiał zostać terminal i jest obecnie zamknięty&quot; - informuje port lotniczy EuroAirport. Operacje lotnicze zostały tymczasowo zawieszone. Pasażerowie proszeni są o kontakt ze swoimi liniami lotniczymi w celu uzyskania informacji na temat ich lotu.</p><br clear="all" />

## Pentagon mocno się pomylił. W Ukrainie wstrzymali oddech
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-pentagon-mocno-sie-pomylil-w-ukrainie-wstrzymali-oddech,nId,7723099](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-pentagon-mocno-sie-pomylil-w-ukrainie-wstrzymali-oddech,nId,7723099)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T08:38:11+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-pentagon-mocno-sie-pomylil-w-ukrainie-wstrzymali-oddech,nId,7723099"><img align="left" alt="Pentagon mocno się pomylił. W Ukrainie wstrzymali oddech" src="https://i.iplsc.com/pentagon-mocno-sie-pomylil-w-ukrainie-wstrzymali-oddech/000JIYB0V4W7D80E-C321.jpg" /></a>Nie zgadzają się wyliczenia dotyczące wsparcia jakiego USA udzieliły Ukrainie. Pentagon wykrył kolejne 2 mld dol., które zostały nieprawidłowo zaksięgowane w związku z przekazywanym Kijowowi sprzętem. Teraz łączna suma błędów sięga kwoty ponad 8 mln dol. Wiadomo, co to oznacza dla Ukrainy. </p><br clear="all" />

## Najnowszy sondaż z USA: Minimalna różnica. Padło zaskakujące pytanie
 - [https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-najnowszy-sondaz-z-usa-minimalna-roznica-padlo-zaskakujace-p,nId,7723037](https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-najnowszy-sondaz-z-usa-minimalna-roznica-padlo-zaskakujace-p,nId,7723037)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T07:47:45+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-najnowszy-sondaz-z-usa-minimalna-roznica-padlo-zaskakujace-p,nId,7723037"><img align="left" alt="Najnowszy sondaż z USA: Minimalna różnica. Padło zaskakujące pytanie" src="https://i.iplsc.com/najnowszy-sondaz-z-usa-minimalna-roznica-padlo-zaskakujace-p/000JIY4ATW2LTEIE-C321.jpg" /></a>Różnica w poparciu między Kamalą Harris a Donaldem Trumpem wynosi w najnowszym sondażu zaledwie jeden punkt procentowy. Ankietowanym nie zadano jednak tylko pytania, na kogo zagłosują, lecz również o to, kto z tej dwójki jest inteligentniejszy. Okazuje się, iż więcej osób wskazało na aktualną wiceprezydent Stanów Zjednoczonych.</p><br clear="all" />

## Zmasowany atak w dniu rozpoczęcia igrzysk. Podpalenia, problemy z koleją
 - [https://wydarzenia.interia.pl/zagranica/news-zmasowany-atak-w-dniu-rozpoczecia-igrzysk-podpalenia-problem,nId,7723023](https://wydarzenia.interia.pl/zagranica/news-zmasowany-atak-w-dniu-rozpoczecia-igrzysk-podpalenia-problem,nId,7723023)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T07:35:58+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zmasowany-atak-w-dniu-rozpoczecia-igrzysk-podpalenia-problem,nId,7723023"><img align="left" alt="Zmasowany atak w dniu rozpoczęcia igrzysk. Podpalenia, problemy z koleją" src="https://i.iplsc.com/zmasowany-atak-w-dniu-rozpoczecia-igrzysk-podpalenia-problem/000JIXV6BTAWPTYH-C321.jpg" /></a>Zmasowany atak na infrastrukturę kolejową w Paryżu. Do incydentów doszło w piątkowy poranek, kilkanaście godzin przed ceremonią otwarcia letnich igrzysk olimpijskich. Sprawcy wzięli na cel połączenia dużych prędkości. Usuwanie awarii potrwa cały weekend - podał francuski państwowy przewoźnik SNCF. </p><br clear="all" />

## "El Mayo" w rękach służb. Był poszukiwany przez dziesięciolecia
 - [https://wydarzenia.interia.pl/zagranica/news-el-mayo-w-rekach-sluzb-byl-poszukiwany-przez-dziesieciolecia,nId,7722979](https://wydarzenia.interia.pl/zagranica/news-el-mayo-w-rekach-sluzb-byl-poszukiwany-przez-dziesieciolecia,nId,7722979)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T06:53:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-el-mayo-w-rekach-sluzb-byl-poszukiwany-przez-dziesieciolecia,nId,7722979"><img align="left" alt="&quot;El Mayo&quot; w rękach służb. Był poszukiwany przez dziesięciolecia" src="https://i.iplsc.com/el-mayo-w-rekach-sluzb-byl-poszukiwany-przez-dziesieciolecia/000JIXLOL2H8R7NP-C321.jpg" /></a>Agenci federalni z Teksasu zatrzymali barona narkotykowego Ismaela Zambadę, przywódcę kartelu Sinaloa. Razem z 76-latkiem wpadł syn jego współpracownika, &quot;El Chapo&quot;. Amerykanie oskarżali Meksykanina o produkcję oraz dystrybucję fentanylu, który doprowadził do poważnego kryzysu opoidowego w kraju. </p><br clear="all" />

## Zaatakowała go niedźwiedzica. Zdecydował się na radykalny krok
 - [https://wydarzenia.interia.pl/zagranica/news-zaatakowala-go-niedzwiedzica-zdecydowal-sie-na-radykalny-kro,nId,7722992](https://wydarzenia.interia.pl/zagranica/news-zaatakowala-go-niedzwiedzica-zdecydowal-sie-na-radykalny-kro,nId,7722992)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T06:42:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zaatakowala-go-niedzwiedzica-zdecydowal-sie-na-radykalny-kro,nId,7722992"><img align="left" alt="Zaatakowała go niedźwiedzica. Zdecydował się na radykalny krok" src="https://i.iplsc.com/zaatakowala-go-niedzwiedzica-zdecydowal-sie-na-radykalny-kro/000JIXP1G7MJVR8U-C321.jpg" /></a>Jechał rowerem przez las, gdy nagle napotkał niedźwiedzicę z małymi. Mężczyzna z Kanady obronił się jednak przed atakiem, używając swojego jednośladu, a następnie uderzając samicę w pysk. Ocalił zdrowie i życie, ale sporo zaryzykował, bo napotykając tak dużego zwierza trzeba przede wszystkim zachowywać spokój.</p><br clear="all" />

## Seria nocnych eksplozji na Krymie. Ucierpiała kluczowa infrastruktura
 - [https://wydarzenia.interia.pl/zagranica/news-seria-nocnych-eksplozji-na-krymie-ucierpiala-kluczowa-infras,nId,7722985](https://wydarzenia.interia.pl/zagranica/news-seria-nocnych-eksplozji-na-krymie-ucierpiala-kluczowa-infras,nId,7722985)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T06:08:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-seria-nocnych-eksplozji-na-krymie-ucierpiala-kluczowa-infras,nId,7722985"><img align="left" alt="Seria nocnych eksplozji na Krymie. Ucierpiała kluczowa infrastruktura " src="https://i.iplsc.com/seria-nocnych-eksplozji-na-krymie-ucierpiala-kluczowa-infras/000JIXJZFXHI6DBH-C321.jpg" /></a>W nocy w czwartku na piątek doszło do eksplozji w Symferopolu, Jewpatorii i Nowofedoriwce, gdzie znajduje się rosyjskie lotnisko - podała agencja Ukrinform. Mieszkańcy mieli odnotować ponad 10 silnych wybuchów. </p><br clear="all" />

## "The Washington Post": Kamala Harris już raz spróbowała. I to była katastrofa
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-kamala-harris-juz-raz-sprobowala-i-to-by,nId,7719108](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-kamala-harris-juz-raz-sprobowala-i-to-by,nId,7719108)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T05:57:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-kamala-harris-juz-raz-sprobowala-i-to-by,nId,7719108"><img align="left" alt="&quot;The Washington Post&quot;: Kamala Harris już raz spróbowała. I to była katastrofa" src="https://i.iplsc.com/the-washington-post-kamala-harris-juz-raz-sprobowala-i-to-by/000JIMCS6P4GW9K3-C321.jpg" /></a>Kamala Harris staje przed wielką szansą na zostanie prezydentem USA. Ale musi uporać się z echami nie tak dawnej przeszłości. W 2020 r. wycofała się prawyborów w Partii Demokratycznej w kluczowym momencie. A lista wpadek była zawstydzająco długa. - Prowadziła okropną kampanię - wspomina jeden z partyjnych strategów. </p><br clear="all" />

## "The Washington Post" z wizytą u zwykłych Rosjan. Powiedzieli, co myślą o wojnie
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-z-wizyta-u-zwyklych-rosjan-powiedzieli-c,nId,7701504](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-z-wizyta-u-zwyklych-rosjan-powiedzieli-c,nId,7701504)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T05:56:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-z-wizyta-u-zwyklych-rosjan-powiedzieli-c,nId,7701504"><img align="left" alt="&quot;The Washington Post&quot; z wizytą u zwykłych Rosjan. Powiedzieli, co myślą o wojnie" src="https://i.iplsc.com/the-washington-post-z-wizyta-u-zwyklych-rosjan-powiedzieli-c/000JIMRVC5O15LMD-C321.jpg" /></a>- Nie mamy wyboru. Zachód uzna nas za słabych - twierdzą mieszkańcy Kirowa w zachodniej Rosji. Amerykańska dziennikarka Francesca Ebel odwiedziła miejscowość, by przekonać się o prawdziwych nastrojach w Rosji. Pojechała na zaproszenie... byłej rosyjskiej agentki w USA Marii Butiny. </p><br clear="all" />

## "The Economist": Wyrwa w sercu Europy ma kształt Niemiec
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-economist-wyrwa-w-sercu-europy-ma-ksztalt-niemiec,nId,7703389](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-economist-wyrwa-w-sercu-europy-ma-ksztalt-niemiec,nId,7703389)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T05:55:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-economist-wyrwa-w-sercu-europy-ma-ksztalt-niemiec,nId,7703389"><img align="left" alt="&quot;The Economist&quot;: Wyrwa w sercu Europy ma kształt Niemiec" src="https://i.iplsc.com/the-economist-wyrwa-w-sercu-europy-ma-ksztalt-niemiec/000JIRC6WORQG30T-C321.jpg" /></a>W krajach UE narasta irytacja zachowaniem kanclerza Niemiec Olafa Niemiec. - Negocjuje jak drobny księgowy - zarzucają unijni przywódcy. Czarę goryczy przelała próba zmiany ustaleń w ostatniej chwili. - Angela Merkel nigdy by tak nie zrobiła - komentują rozdrażnieni dyplomaci.</p><br clear="all" />

## Eksplozja na polu naftowym w Rosji. Jedna osoba nie żyje
 - [https://wydarzenia.interia.pl/zagranica/news-eksplozja-na-polu-naftowym-w-rosji-jedna-osoba-nie-zyje,nId,7722966](https://wydarzenia.interia.pl/zagranica/news-eksplozja-na-polu-naftowym-w-rosji-jedna-osoba-nie-zyje,nId,7722966)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T05:47:18+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-eksplozja-na-polu-naftowym-w-rosji-jedna-osoba-nie-zyje,nId,7722966"><img align="left" alt="Eksplozja na polu naftowym w Rosji. Jedna osoba nie żyje" src="https://i.iplsc.com/eksplozja-na-polu-naftowym-w-rosji-jedna-osoba-nie-zyje/000JIXHN2JIW1EWF-C321.jpg" /></a>Wybuch zakłócił pracę pola naftowego na północy Rosji - podają tamtejsze media. Na razie nie wiadomo, co było jej przyczyną, lecz Komitet Śledczy wstępnie informuje o możliwym nieprzestrzeganiu zasad bezpieczeństwa. Jak dodano, zginęła jedna osoba, a siedem kolejnych jest poszkodowanych. Inne eksplozje odczuli też mieszkańcy okupowanego Krymu.</p><br clear="all" />

## Tak rysuje się przyszłość Rosji. Eksperci kreślą scenariusze
 - [https://wydarzenia.interia.pl/zagranica/news-tak-rysuje-sie-przyszlosc-rosji-eksperci-kresla-scenariusze,nId,7722957](https://wydarzenia.interia.pl/zagranica/news-tak-rysuje-sie-przyszlosc-rosji-eksperci-kresla-scenariusze,nId,7722957)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T05:20:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tak-rysuje-sie-przyszlosc-rosji-eksperci-kresla-scenariusze,nId,7722957"><img align="left" alt="Tak rysuje się przyszłość Rosji. Eksperci kreślą scenariusze" src="https://i.iplsc.com/tak-rysuje-sie-przyszlosc-rosji-eksperci-kresla-scenariusze/000JIXGWSUX5TSKE-C321.jpg" /></a>Śmierć Władimira Putina, pałacowy przewrót, a nawet ogólnokrajowa katastrofa - takie scenariusze na zmianę władzy w Rosji widzi 42 ekspertów z różnych stron świata. Różni ich wizja upadku dyktatury na Kremlu i opinie co do potencjalnego następcy Putina, lecz w jednym są zgodni - rosyjski dowódca nie odda władzy dobrowolnie. </p><br clear="all" />

## Kamala Harris krytycznie o polityce sojusznika. "Nie możemy odwracać oczu"
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kamala-harris-krytycznie-o-polityce-sojusznika-nie-mozemy-od,nId,7722941](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kamala-harris-krytycznie-o-polityce-sojusznika-nie-mozemy-od,nId,7722941)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T04:37:53+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kamala-harris-krytycznie-o-polityce-sojusznika-nie-mozemy-od,nId,7722941"><img align="left" alt="Kamala Harris krytycznie o polityce sojusznika. &quot;Nie możemy odwracać oczu&quot;" src="https://i.iplsc.com/kamala-harris-krytycznie-o-polityce-sojusznika-nie-mozemy-od/000JIXEMCQSO4JC3-C321.jpg" /></a>- Nie możemy odwracać oczu od tragedii - powiedziała Kamala Harris po spotkaniu z premierem Izraela o sytuacji w Strefie Gazy. Prawdopodobna kandydatka demokratów w wyborach prezydenckich jest bardziej krytyczna wobec działań sojusznika od Joe Bidena. Harris wskazała m.in. na fatalną sytuację humanitarną po stronie palestyńskiej. </p><br clear="all" />

## Człowiek prezydenta z międzynarodowym stanowiskiem. "Wyraz uznania"
 - [https://wydarzenia.interia.pl/zagranica/news-czlowiek-prezydenta-z-miedzynarodowym-stanowiskiem-wyraz-uzn,nId,7722937](https://wydarzenia.interia.pl/zagranica/news-czlowiek-prezydenta-z-miedzynarodowym-stanowiskiem-wyraz-uzn,nId,7722937)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-07-26T03:58:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czlowiek-prezydenta-z-miedzynarodowym-stanowiskiem-wyraz-uzn,nId,7722937"><img align="left" alt="Człowiek prezydenta z międzynarodowym stanowiskiem. &quot;Wyraz uznania&quot;" src="https://i.iplsc.com/czlowiek-prezydenta-z-miedzynarodowym-stanowiskiem-wyraz-uzn/000JIXDXNL1FYNE1-C321.jpg" /></a>Krzysztof Szczerski został wybrany wiceprzewodniczącym Rady Gospodarczej i Społecznej ONZ (ECOSOC). To &quot;wyraz uznania dla roli i ambicji Polski w polityce rozwojowej ONZ&quot; - przekazał polski ambasador. Szczerski był wcześniej aktywnym politykiem Prawa i Sprawiedliwości oraz ministrem w Kancelarii Prezydenta Andrzeja Dudy.</p><br clear="all" />

