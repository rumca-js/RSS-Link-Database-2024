# Source:The Rubin Report, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng, language:en

## How Kamala’s VP Pick Could Derail Trump’s Path to the White House
 - [https://www.youtube.com/watch?v=YSd9Z6ixNPc](https://www.youtube.com/watch?v=YSd9Z6ixNPc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-07-26T21:15:01+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of his talk with David Sacks about possible VP pick Josh Shapiro’s conversation with “The Breakfast Club’s” Charlamagne tha God, in which he shows why he could be a threat to Trump winning Pennsylvania.
Watch Dave Rubin's FULL ROUNDTABLE: https://www.youtube.com/watch?v=oTN_kb4VkQU&amp;list=PLEbhOtC9klbDuslX72KMcTDipzyDwaAYL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #breakfastClub #TheBreakfastClub #charlamagnethagod  #JoshShapiro #Kamala #KamalaHarris #DavidSacks #DaveRubin

The Rubin Report Roundtable is a place where you can hear sane discussions on controversial topics. Is the state of US news driving you crazy? Does the coverage of political news rarely seem “fair and balanced”? Serious discussions on US politics is vital to having a healthy democracy. No matter what

## Kamala Decides to Start Her Campaign with This Obvious Lie
 - [https://www.youtube.com/watch?v=h7PlgqZjLNw](https://www.youtube.com/watch?v=h7PlgqZjLNw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-07-26T19:15:01+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of his talk with David Sacks about Kamala Harris lying to a crowd of supporters about her “grassroots” campaign.
Watch Dave Rubin's FULL ROUNDTABLE: https://www.youtube.com/watch?v=oTN_kb4VkQU&amp;list=PLEbhOtC9klbDuslX72KMcTDipzyDwaAYL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #Kamala #KamalaHarris #Liar #Lies #grassroots #DavidSacks #DaveRubin

The Rubin Report Roundtable is a place where you can hear sane discussions on controversial topics. Is the state of US news driving you crazy? Does the coverage of political news rarely seem “fair and balanced”? Serious discussions on US politics is vital to having a healthy democracy. No matter what political party you belong to, we need to be able to hear a variety of political perspectives. Whether you majored in political sci

## Host Notices Something Dangerous About Biden’s Speech That No One Noticed
 - [https://www.youtube.com/watch?v=G4slx3DszuE](https://www.youtube.com/watch?v=G4slx3DszuE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-07-26T17:15:00+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of his talk with David Sacks about MSNBC’s Jen Psaki noticing Joe Biden making it clear that he is ready to launch radical reforms of the Supreme Court with his remaining time in office.
Watch Dave Rubin's FULL ROUNDTABLE: https://www.youtube.com/watch?v=oTN_kb4VkQU&amp;list=PLEbhOtC9klbDuslX72KMcTDipzyDwaAYL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #MSNBC #SupremeCourt #JenPsaki #Biden #DaveRubin

The Rubin Report Roundtable is a place where you can hear sane discussions on controversial topics. Is the state of US news driving you crazy? Does the coverage of political news rarely seem “fair and balanced”? Serious discussions on US politics is vital to having a healthy democracy. No matter what political party you belong to, we need to be able to hear a variety of politi

## Dirty Behind-the-Scenes Details About Obama-Led Coup Exposed with Co-Host David Sacks
 - [https://www.youtube.com/watch?v=oTN_kb4VkQU](https://www.youtube.com/watch?v=oTN_kb4VkQU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-07-26T15:00:07+00:00

Dave Rubin of “The Rubin Report” talks to David Sacks about the New York Post’s explosive new reporting on the behind-the-scenes details of Barack Obama’s coup and how Joe Biden enraged him and sabotaged his plans by endorsing Kamala Harris; how MSNBC’s Jen Psaki is pushing for Joe Biden to stack the Supreme Court; Kamala Harris lying to a crowd of supporters about her “grassroots” campaign; possible VP pick Josh Shapiro’s conversation with “The Breakfast Club’s” Charlamagne tha God, in which he shows why he could be a threat to Trump winning Pennsylvania; Donald Trump sharing some frightening stats on immigrant crime; and much more.

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #Obama #BarackObama #coup #KamalaHarris #Kamala #JoeBiden #DemocraticParty #DavidSacks #DaveRubin

The Rubin Report Roundtable is a place where you can hear sane discussions on

## Media's Project 2025 Lies Debunked | Michael Knowles
 - [https://www.youtube.com/watch?v=H4hpeNBSXKk](https://www.youtube.com/watch?v=H4hpeNBSXKk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-07-26T01:15:01+00:00

Dave Rubin of “The Rubin Report” reacts to Michael Knowles debunking the mainstream media's lies about Project 2025

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

#RubinReport #MichaelKnowles #DailyWire #2025 #Project2025 #Trump #mainstreammedia #DaveRubin

Is the state of US news driving you crazy? Does the coverage of political news rarely seem “fair and balanced”? Serious discussions on US politics is vital to having a healthy democracy. No matter what political party you belong to, we need to be able to hear a variety of political perspectives. Whether you majored in political science or just want to have a deeper understanding of the issues you’ll want to check out this playlist:
https://www.youtube.com/playlist?list=PLEbhOtC9klbCr0iN2ANJbaV477B0eSpc6

To make sure you never miss a single Rubin Report video, click here to subscribe:
https://www.youtube.com/channel/UCJdKr0Bgd_5saZYqLCa9mng?sub_confirmation=1

Looking for smart and honest conversations about 

