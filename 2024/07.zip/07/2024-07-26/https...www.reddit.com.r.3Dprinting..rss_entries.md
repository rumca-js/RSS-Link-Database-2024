# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## Ready for tonight!!!!!
 - [https://www.reddit.com/r/3Dprinting/comments/1ed1pfo/ready_for_tonight](https://www.reddit.com/r/3Dprinting/comments/1ed1pfo/ready_for_tonight)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T23:07:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ed1pfo/ready_for_tonight/"> <img alt="Ready for tonight!!!!!" src="https://preview.redd.it/46nyxx3x2yed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=83955835ff9aef0185d2ed5ac4a7e7e28416d5b6" title="Ready for tonight!!!!!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Actual_Evidence_925"> /u/Actual_Evidence_925 </a> <br /> <span><a href="https://i.redd.it/46nyxx3x2yed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ed1pfo/ready_for_tonight/">[comments]</a></span> </td></tr></table>

## everything is fine
 - [https://www.reddit.com/r/3Dprinting/comments/1eczjz1/everything_is_fine](https://www.reddit.com/r/3Dprinting/comments/1eczjz1/everything_is_fine)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T21:31:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eczjz1/everything_is_fine/"> <img alt="everything is fine " src="https://external-preview.redd.it/cHY1c3FnZndreGVkMZgV6qzRoQ4E7N2p7lxVbXEMmKy1tARUpqxCXk_wp3rX.png?width=140&amp;height=78&amp;crop=140:78,smart&amp;format=jpg&amp;v=enabled&amp;lthumb=true&amp;s=ba80c549d66a0fd17eb8ba094a13126fbeac28f3" title="everything is fine " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/darkmoon2310"> /u/darkmoon2310 </a> <br /> <span><a href="https://v.redd.it/h8ajogfwkxed1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eczjz1/everything_is_fine/">[comments]</a></span> </td></tr></table>

## Does anyone regret getting a 3D Printer?
 - [https://www.reddit.com/r/3Dprinting/comments/1ecydob/does_anyone_regret_getting_a_3d_printer](https://www.reddit.com/r/3Dprinting/comments/1ecydob/does_anyone_regret_getting_a_3d_printer)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T20:41:36+00:00

<!-- SC_OFF --><div class="md"><p>This is probably a bad place to ask that question since there will be a bias toward having one.</p> <p>The reason I ask such a strange question is I'm on the fence. On the one hand, I would like to build serious parts for maker projects. I'm not going to be printing Pokemon or some object from a video game.</p> <p>On the other hand, I see postings all the time asking for advice about why a print didn't stick to the build plate or stuck too much, or turned into a bird's nest, or didn't have good layer adhesion, and worries about support.</p> <p>In the early days of 2D ink and laser printers (and unfortunately too often now), something that went haywire simply meant throwing a piece of paper away that took seconds to maybe 2 minutes to print. For 3D printing you waste a lot of time and filament.</p> <p>It seems 3D printing has a lot more situations where there can be problems. I realize there is confirmation bias since nobody posts to say their print jo

## How to remove these lines
 - [https://www.reddit.com/r/3Dprinting/comments/1ecxeta/how_to_remove_these_lines](https://www.reddit.com/r/3Dprinting/comments/1ecxeta/how_to_remove_these_lines)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T19:59:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecxeta/how_to_remove_these_lines/"> <img alt="How to remove these lines" src="https://preview.redd.it/pl1v3t8e5xed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d5a9a678542816fbf5d9b7cc4900be2121eb3fb5" title="How to remove these lines" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hi what are these horizontal lines that seem to be in a pattern? How do I remove these?was printed vertical with 0.12 layers</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Natural-Union4730"> /u/Natural-Union4730 </a> <br /> <span><a href="https://i.redd.it/pl1v3t8e5xed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecxeta/how_to_remove_these_lines/">[comments]</a></span> </td></tr></table>

## I just dont get it
 - [https://www.reddit.com/r/3Dprinting/comments/1ecvvn9/i_just_dont_get_it](https://www.reddit.com/r/3Dprinting/comments/1ecvvn9/i_just_dont_get_it)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T18:53:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecvvn9/i_just_dont_get_it/"> <img alt="I just dont get it" src="https://external-preview.redd.it/NHEwNDBvaG10d2VkMdPWcCKJP-7v5vN3MJFGJ-2Q39nnZUZbyoQa3geET-R7.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=696183b2e18701ecda0d782a3aaed444f46cedcc" title="I just dont get it" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I have the following problem and i cant find the source of error here. Short explanation. I printed this large object on my anycubic kobra 2 pro. I used elegoo PLA. 205°C with 0.3mm layer height. 10% infill. First with gyroid then another try with grid infill. 200mm/s</p> <p>As you can see in the video the left side of the part looks flawless. But the more i pan to the right the worse it gets. Its not stringing. It looks like the whole material coming out of the nozzle hanging away. </p> <p>My assumptions so far:</p> <ul> <li>Filament is not the problem. If the filament is faulty the whole pa

## Starts of great then this happens.
 - [https://www.reddit.com/r/3Dprinting/comments/1ecuql4/starts_of_great_then_this_happens](https://www.reddit.com/r/3Dprinting/comments/1ecuql4/starts_of_great_then_this_happens)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T18:05:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecuql4/starts_of_great_then_this_happens/"> <img alt="Starts of great then this happens." src="https://preview.redd.it/1fzgz6ezkwed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=53b641e1d3709951ea5b65c10f7ac1bc023e6e01" title="Starts of great then this happens." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Started of great then this always happens. I replaced the hot end. But nothing else. What would cause this any ideas.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Lordtux"> /u/Lordtux </a> <br /> <span><a href="https://i.redd.it/1fzgz6ezkwed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecuql4/starts_of_great_then_this_happens/">[comments]</a></span> </td></tr></table>

## Help, why is my first layer/brim so bad.
 - [https://www.reddit.com/r/3Dprinting/comments/1ecui7d/help_why_is_my_first_layerbrim_so_bad](https://www.reddit.com/r/3Dprinting/comments/1ecui7d/help_why_is_my_first_layerbrim_so_bad)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T17:55:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecui7d/help_why_is_my_first_layerbrim_so_bad/"> <img alt="Help, why is my first layer/brim so bad. " src="https://b.thumbs.redditmedia.com/1qBhoJA0aLAX6hM4T33elGwCFGge8B1Cy-A-UGLMgLk.jpg" title="Help, why is my first layer/brim so bad. " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I don’t think I’ve changed any setting that directly affects this. But it has been an issue with my petg prints and I just ran some pla though and it had the same issue. Due to this I think it’s a print setting issue. Why could be the cause of this?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DrSPYNE"> /u/DrSPYNE </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecui7d">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecui7d/help_why_is_my_first_layerbrim_so_bad/">[comments]</a></span> </td></tr></table>

## We all know that feeling when that ONE piece fails 😭
 - [https://www.reddit.com/r/3Dprinting/comments/1ecto43/we_all_know_that_feeling_when_that_one_piece_fails](https://www.reddit.com/r/3Dprinting/comments/1ecto43/we_all_know_that_feeling_when_that_one_piece_fails)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T17:20:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecto43/we_all_know_that_feeling_when_that_one_piece_fails/"> <img alt="We all know that feeling when that ONE piece fails 😭" src="https://preview.redd.it/q06v8yh2dwed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a28fd459d7eee5add6096d7ce1a73d1488959652" title="We all know that feeling when that ONE piece fails 😭" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Fickle-Bag-2921"> /u/Fickle-Bag-2921 </a> <br /> <span><a href="https://i.redd.it/q06v8yh2dwed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecto43/we_all_know_that_feeling_when_that_one_piece_fails/">[comments]</a></span> </td></tr></table>

## I designed and printed a night vision (working with electronics)
 - [https://www.reddit.com/r/3Dprinting/comments/1ect6hu/i_designed_and_printed_a_night_vision_working](https://www.reddit.com/r/3Dprinting/comments/1ect6hu/i_designed_and_printed_a_night_vision_working)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T17:00:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ect6hu/i_designed_and_printed_a_night_vision_working/"> <img alt="I designed and printed a night vision (working with electronics)" src="https://b.thumbs.redditmedia.com/SReZmoXxg2Kqj5Z99O2VYlPwhsysz8wbbNlVu-wyYzQ.jpg" title="I designed and printed a night vision (working with electronics)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ikeaidk"> /u/ikeaidk </a> <br /> <span><a href="https://www.reddit.com/gallery/1ect6hu">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ect6hu/i_designed_and_printed_a_night_vision_working/">[comments]</a></span> </td></tr></table>

## Can anyone name this printer
 - [https://www.reddit.com/r/3Dprinting/comments/1ecszax/can_anyone_name_this_printer](https://www.reddit.com/r/3Dprinting/comments/1ecszax/can_anyone_name_this_printer)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T16:52:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecszax/can_anyone_name_this_printer/"> <img alt="Can anyone name this printer" src="https://preview.redd.it/i9qgdru28wed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=926d24be4f1c0ed8fc4d577f12f2a9b1beb98adc" title="Can anyone name this printer" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I wonder if anyone can recognize this frame. This is my project printer based of once kinda popular model. Now I have skr pico and klipper, switched to 24v😁</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TurboBarti5000"> /u/TurboBarti5000 </a> <br /> <span><a href="https://i.redd.it/i9qgdru28wed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecszax/can_anyone_name_this_printer/">[comments]</a></span> </td></tr></table>

## Finished the Black Noir print!
 - [https://www.reddit.com/r/3Dprinting/comments/1ecrywg/finished_the_black_noir_print](https://www.reddit.com/r/3Dprinting/comments/1ecrywg/finished_the_black_noir_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T16:10:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecrywg/finished_the_black_noir_print/"> <img alt="Finished the Black Noir print!" src="https://b.thumbs.redditmedia.com/4C8O-w_pO_acRqMC0MAJvfAUHggiOkh23dC1mw2vtVg.jpg" title="Finished the Black Noir print!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Printed on Bambu labs A1 mini in a few pieces. Fabric used for lower mask. Painted in acrylics, I was going for a worn/damaged look.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SandComprehensive594"> /u/SandComprehensive594 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecrywg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecrywg/finished_the_black_noir_print/">[comments]</a></span> </td></tr></table>

## Clippy!
 - [https://www.reddit.com/r/3Dprinting/comments/1ecr175/clippy](https://www.reddit.com/r/3Dprinting/comments/1ecr175/clippy)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T15:31:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecr175/clippy/"> <img alt="Clippy! " src="https://preview.redd.it/7fo9zk6mtved1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9f3a036bc06af0512cbda496a85c852f7d5787c5" title="Clippy! " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>So I came across the STL file for this! Gotta love Clippy back in the days of Office '97.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Hopeful-Ad8964"> /u/Hopeful-Ad8964 </a> <br /> <span><a href="https://i.redd.it/7fo9zk6mtved1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecr175/clippy/">[comments]</a></span> </td></tr></table>

## Not the worst place in the world to be working
 - [https://www.reddit.com/r/3Dprinting/comments/1ecq2ef/not_the_worst_place_in_the_world_to_be_working](https://www.reddit.com/r/3Dprinting/comments/1ecq2ef/not_the_worst_place_in_the_world_to_be_working)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T14:53:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecq2ef/not_the_worst_place_in_the_world_to_be_working/"> <img alt="Not the worst place in the world to be working " src="https://preview.redd.it/18lqf7gomved1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=100303d896640ed0ecd9cea1787d2390b3a54d01" title="Not the worst place in the world to be working " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ubernero"> /u/Ubernero </a> <br /> <span><a href="https://i.redd.it/18lqf7gomved1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecq2ef/not_the_worst_place_in_the_world_to_be_working/">[comments]</a></span> </td></tr></table>

## 3D software recommendations
 - [https://www.reddit.com/r/3Dprinting/comments/1ecptyh/3d_software_recommendations](https://www.reddit.com/r/3Dprinting/comments/1ecptyh/3d_software_recommendations)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T14:43:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecptyh/3d_software_recommendations/"> <img alt="3D software recommendations " src="https://preview.redd.it/k4aciqa0lved1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=23aad07844e3dd5946dcf2dab5d39f627031b8a7" title="3D software recommendations " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I recently purchased a Bambu Lab P1S and have been having loads of fun printing files I’ve found online but I’d really like to start modelling my own designs.</p> <p>I’m a bit houseplant mad and would really like to get into making funky planters like pictured. </p> <p>I have watched a bunch of CG Cookie tutorials for Blender and whilst I managed to botch something reasonably cool together, I then ran into non-manifold edges (I’m also on a Mac, so can’t take advantage of Bambu Studios ‘fix model’ feature!) </p> <p>On the whole I’m not finding Blender particularly easy to pick up. Can anyone please recommend software t

## WTF Do I Do?
 - [https://www.reddit.com/r/3Dprinting/comments/1ecpn7z/wtf_do_i_do](https://www.reddit.com/r/3Dprinting/comments/1ecpn7z/wtf_do_i_do)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T14:35:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecpn7z/wtf_do_i_do/"> <img alt="WTF Do I Do? " src="https://b.thumbs.redditmedia.com/ilJMZ8g3cFkwvGrTwP_-LQdQfISvThbI6XvdI0oojfY.jpg" title="WTF Do I Do? " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Comfortinpain"> /u/Comfortinpain </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecpn7z">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecpn7z/wtf_do_i_do/">[comments]</a></span> </td></tr></table>

## What went wrong with this print? Creality Halot Lite resin printer.
 - [https://www.reddit.com/r/3Dprinting/comments/1ecpktb/what_went_wrong_with_this_print_creality_halot](https://www.reddit.com/r/3Dprinting/comments/1ecpktb/what_went_wrong_with_this_print_creality_halot)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T14:32:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecpktb/what_went_wrong_with_this_print_creality_halot/"> <img alt="What went wrong with this print? Creality Halot Lite resin printer." src="https://b.thumbs.redditmedia.com/8xIDY21m8zdfepbfrT3bM4_H6qsy2cQjr2xCFq2cTpQ.jpg" title="What went wrong with this print? Creality Halot Lite resin printer." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I’m very new to 3D printing. I’m not sure what adjustments I can make. Was the bed not leveled right? Can I change something in the settings for this to stick to the plate? Thanks for reading!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/logic_resistant"> /u/logic_resistant </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecpktb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecpktb/what_went_wrong_with_this_print_creality_halot/">[comments]</a></span> </td></tr></table>

## The great Calibrator v2
 - [https://www.reddit.com/r/3Dprinting/comments/1ecp7j1/the_great_calibrator_v2](https://www.reddit.com/r/3Dprinting/comments/1ecp7j1/the_great_calibrator_v2)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T14:17:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecp7j1/the_great_calibrator_v2/"> <img alt="The great Calibrator v2" src="https://b.thumbs.redditmedia.com/K_wByoKWev3vnoBYcTB9m9XsR8ztxs8WFrz-GLeDbeg.jpg" title="The great Calibrator v2" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PermissionParking868"> /u/PermissionParking868 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecp7j1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecp7j1/the_great_calibrator_v2/">[comments]</a></span> </td></tr></table>

## Ultimate Strength test with 3D printed Axe heads! Carbon Fiber, Super PLA+, PC and PLA Pro
 - [https://www.reddit.com/r/3Dprinting/comments/1ecoe4v/ultimate_strength_test_with_3d_printed_axe_heads](https://www.reddit.com/r/3Dprinting/comments/1ecoe4v/ultimate_strength_test_with_3d_printed_axe_heads)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T13:41:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecoe4v/ultimate_strength_test_with_3d_printed_axe_heads/"> <img alt="Ultimate Strength test with 3D printed Axe heads! Carbon Fiber, Super PLA+, PC and PLA Pro" src="https://external-preview.redd.it/Nzd5ajd3c3I5dmVkMSOfq4xa2LK0oRVeRHLxVfVvWP9NCzL83050Oeot5Z71.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=f3208e2b3cd1f5d37ff348f63eeea4521c88fe3b" title="Ultimate Strength test with 3D printed Axe heads! Carbon Fiber, Super PLA+, PC and PLA Pro" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JeffDoesWork"> /u/JeffDoesWork </a> <br /> <span><a href="https://v.redd.it/bxo94xsr9ved1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecoe4v/ultimate_strength_test_with_3d_printed_axe_heads/">[comments]</a></span> </td></tr></table>

## strange discoloration on print
 - [https://www.reddit.com/r/3Dprinting/comments/1ecoagm/strange_discoloration_on_print](https://www.reddit.com/r/3Dprinting/comments/1ecoagm/strange_discoloration_on_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T13:37:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecoagm/strange_discoloration_on_print/"> <img alt=" strange discoloration on print " src="https://b.thumbs.redditmedia.com/PjP2xzuOH3xLNYY2cb7UqtzBqMTYCwHTagD3g2u8e2U.jpg" title=" strange discoloration on print " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>im very new to 3d printing and i have this new roll (opened today) of yellow PLA PRO.<br /> it printed fine but has this weird discoloration.</p> <p>i did lower the speeds before printing.</p> <p>i already did a temp tower and flow rate to calibrate before printing.</p> <p>what could this be? am i missing something? did something wrong?</p> <p>im using orca slicer.</p> <p>printer is a Ender 3 v3 SE</p> <p><a href="https://preview.redd.it/zhxlnoo59ved1.png?width=559&amp;format=png&amp;auto=webp&amp;s=44f7c445769ab61f098a737417c862dfe3298c21">https://preview.redd.it/zhxlnoo59ved1.png?width=559&amp;format=png&amp;auto=webp&amp;s=44f7c445769ab61f098a737417c8

## Mirror fell and corner broke, no problem 💪
 - [https://www.reddit.com/r/3Dprinting/comments/1ecnub0/mirror_fell_and_corner_broke_no_problem](https://www.reddit.com/r/3Dprinting/comments/1ecnub0/mirror_fell_and_corner_broke_no_problem)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T13:16:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecnub0/mirror_fell_and_corner_broke_no_problem/"> <img alt="Mirror fell and corner broke, no problem 💪" src="https://a.thumbs.redditmedia.com/-TVO7cv_R4tdWR5bGVhEjBEhY57tX5B-VSWW341wQ40.jpg" title="Mirror fell and corner broke, no problem 💪" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Yes this mirror is for my home gym, and this is one of 12 panels, not one giant mirror.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SandboxSimulator"> /u/SandboxSimulator </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecnub0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecnub0/mirror_fell_and_corner_broke_no_problem/">[comments]</a></span> </td></tr></table>

## The Heart artifact from Dishonored. Because I'm 3d artist and love 3d print, Dishonored, home decor, beautiful and functional things. There is a metal wire in the photo #1, but I used a filament instead and paiinted with metallic paint. The glass cabochon was bought in DIY store.
 - [https://www.reddit.com/r/3Dprinting/comments/1ecls9s/the_heart_artifact_from_dishonored_because_im_3d](https://www.reddit.com/r/3Dprinting/comments/1ecls9s/the_heart_artifact_from_dishonored_because_im_3d)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T11:31:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecls9s/the_heart_artifact_from_dishonored_because_im_3d/"> <img alt="The Heart artifact from Dishonored. Because I'm 3d artist and love 3d print, Dishonored, home decor, beautiful and functional things. There is a metal wire in the photo #1, but I used a filament instead and paiinted with metallic paint. The glass cabochon was bought in DIY store." src="https://preview.redd.it/sd1olsztkued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=56debad4ed11d625fd9cd9532c47d112a81a353e" title="The Heart artifact from Dishonored. Because I'm 3d artist and love 3d print, Dishonored, home decor, beautiful and functional things. There is a metal wire in the photo #1, but I used a filament instead and paiinted with metallic paint. The glass cabochon was bought in DIY store." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Astra_Borealis"> /u/Astra_Borealis </a> <br /> <span><a href="https://i.

## I modeled printed and painted this little house to express my frustration with the housing market
 - [https://www.reddit.com/r/3Dprinting/comments/1eclhmz/i_modeled_printed_and_painted_this_little_house](https://www.reddit.com/r/3Dprinting/comments/1eclhmz/i_modeled_printed_and_painted_this_little_house)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T11:15:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eclhmz/i_modeled_printed_and_painted_this_little_house/"> <img alt="I modeled printed and painted this little house to express my frustration with the housing market" src="https://preview.redd.it/dmp3ilgcl1wa1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=6ec42bd190e117d5549eda6bc9e4cc8b87d4c224" title="I modeled printed and painted this little house to express my frustration with the housing market" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/greelingdeaky"> /u/greelingdeaky </a> <br /> <span><a href="https://i.redd.it/dmp3ilgcl1wa1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eclhmz/i_modeled_printed_and_painted_this_little_house/">[comments]</a></span> </td></tr></table>

## A fun and useful Woodworking + 3D-Printing + Plexiglass project utilizing a PC fan, to allow printing VOC-emitting materials like ABS/ASA. I can't measure VOCs, but the awful smell when printing ABS is totally gone, even if I search for it.
 - [https://www.reddit.com/r/3Dprinting/comments/1ecl4go/a_fun_and_useful_woodworking_3dprinting](https://www.reddit.com/r/3Dprinting/comments/1ecl4go/a_fun_and_useful_woodworking_3dprinting)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T10:53:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecl4go/a_fun_and_useful_woodworking_3dprinting/"> <img alt="A fun and useful Woodworking + 3D-Printing + Plexiglass project utilizing a PC fan, to allow printing VOC-emitting materials like ABS/ASA. I can't measure VOCs, but the awful smell when printing ABS is totally gone, even if I search for it." src="https://b.thumbs.redditmedia.com/_3ZttxeLBob6BMem4ex8ucnM0NaR-73QTZ_GPEbRdlc.jpg" title="A fun and useful Woodworking + 3D-Printing + Plexiglass project utilizing a PC fan, to allow printing VOC-emitting materials like ABS/ASA. I can't measure VOCs, but the awful smell when printing ABS is totally gone, even if I search for it." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yan-shay"> /u/yan-shay </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecl4go">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecl4go/a_fun_and_useful_woodworkin

## Last minute Flower-Power Earrings i produced for my gf and added some more to make a pack
 - [https://www.reddit.com/r/3Dprinting/comments/1eckq60/last_minute_flowerpower_earrings_i_produced_for](https://www.reddit.com/r/3Dprinting/comments/1eckq60/last_minute_flowerpower_earrings_i_produced_for)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T10:28:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eckq60/last_minute_flowerpower_earrings_i_produced_for/"> <img alt="Last minute Flower-Power Earrings i produced for my gf and added some more to make a pack" src="https://preview.redd.it/owvbdl15bued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d0579d048556b52da20b8234b6d03cdbb86d9d2a" title="Last minute Flower-Power Earrings i produced for my gf and added some more to make a pack" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SmackMax"> /u/SmackMax </a> <br /> <span><a href="https://i.redd.it/owvbdl15bued1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eckq60/last_minute_flowerpower_earrings_i_produced_for/">[comments]</a></span> </td></tr></table>

## When it's a beautiful day but need to 3D print
 - [https://www.reddit.com/r/3Dprinting/comments/1eckm8h/when_its_a_beautiful_day_but_need_to_3d_print](https://www.reddit.com/r/3Dprinting/comments/1eckm8h/when_its_a_beautiful_day_but_need_to_3d_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T10:20:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1eckm8h/when_its_a_beautiful_day_but_need_to_3d_print/"> <img alt="When it's a beautiful day but need to 3D print" src="https://preview.redd.it/97g886c2aued1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=568466c8d397f4d8d4f5a3943f2837ac5810d536" title="When it's a beautiful day but need to 3D print" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LazyLondoner"> /u/LazyLondoner </a> <br /> <span><a href="https://i.redd.it/97g886c2aued1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1eckm8h/when_its_a_beautiful_day_but_need_to_3d_print/">[comments]</a></span> </td></tr></table>

## A Xbox controller butt mount - just like the Deadpool controller!
 - [https://www.reddit.com/r/3Dprinting/comments/1ecj4bd/a_xbox_controller_butt_mount_just_like_the](https://www.reddit.com/r/3Dprinting/comments/1ecj4bd/a_xbox_controller_butt_mount_just_like_the)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T08:37:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecj4bd/a_xbox_controller_butt_mount_just_like_the/"> <img alt="A Xbox controller butt mount - just like the Deadpool controller!" src="https://preview.redd.it/jt07gv9arted1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=beae482409b12645dcae09b852e3832ee4a2d2ed" title="A Xbox controller butt mount - just like the Deadpool controller!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Latter-Pepper-7175"> /u/Latter-Pepper-7175 </a> <br /> <span><a href="https://i.redd.it/jt07gv9arted1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecj4bd/a_xbox_controller_butt_mount_just_like_the/">[comments]</a></span> </td></tr></table>

## By limiting the height to 2 layers (0.4mm) and adding some Z-hop I was able to print a 4 color light box by just swapping the colors and printing black last.
 - [https://www.reddit.com/r/3Dprinting/comments/1ecijdb/by_limiting_the_height_to_2_layers_04mm_and](https://www.reddit.com/r/3Dprinting/comments/1ecijdb/by_limiting_the_height_to_2_layers_04mm_and)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T07:57:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecijdb/by_limiting_the_height_to_2_layers_04mm_and/"> <img alt="By limiting the height to 2 layers (0.4mm) and adding some Z-hop I was able to print a 4 color light box by just swapping the colors and printing black last." src="https://b.thumbs.redditmedia.com/G460Ur3WkdjbWsM87f2CwzLjCE-CYNDeEpxkFYfpjEg.jpg" title="By limiting the height to 2 layers (0.4mm) and adding some Z-hop I was able to print a 4 color light box by just swapping the colors and printing black last." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>It’s not perfect, but not bad for a first attempt. </p> <p>Anyways if you have a regular single color printer without AMS or multicolor capability, it looks like these light boxes are pretty doable. </p> <p>I just printed all of the white, red, yellow, and black in one go, and I limited the first 3 colors to only 0.4mm total thickness. It seems plenty thick enough at this size.</p> </div><!-- SC_

## Plastic hinge Keyboard
 - [https://www.reddit.com/r/3Dprinting/comments/1ecibjl/plastic_hinge_keyboard](https://www.reddit.com/r/3Dprinting/comments/1ecibjl/plastic_hinge_keyboard)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T07:42:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecibjl/plastic_hinge_keyboard/"> <img alt="Plastic hinge Keyboard" src="https://preview.redd.it/gdrm68jvhted1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a487a07404f0ff4513ae310f8fa18eaae9cfd61b" title="Plastic hinge Keyboard" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hello,</p> <p>I am quite new to the 3D Game but finally I might have a usecase. </p> <p>The plastic hinge from my CTRL Button of my Cherry JK-85 Keyboard broke. Therefore the Button is loose. </p> <p>Since it’s not that easy to describe what I mean with plastic hinge I added a picture. </p> <p>Do you guys know where I can find a 3D printing file of such a thing that I can give my friend who has a 3D Printer?</p> <p>Thanks for your help!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/kessler259"> /u/kessler259 </a> <br /> <span><a href="https://i.redd.it/gdrm68jvhted1.jpeg">[link]</a></span> &#32

## Too fast speed while printing lithophane ?
 - [https://www.reddit.com/r/3Dprinting/comments/1ech2j0/too_fast_speed_while_printing_lithophane](https://www.reddit.com/r/3Dprinting/comments/1ech2j0/too_fast_speed_while_printing_lithophane)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T06:19:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ech2j0/too_fast_speed_while_printing_lithophane/"> <img alt="Too fast speed while printing lithophane ?" src="https://b.thumbs.redditmedia.com/Qu8oJ8Th6pcDMJSTT4KkhNrjA8BL265Z8F-O4966vls.jpg" title="Too fast speed while printing lithophane ?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I used lithophanemaker desktop version, i added my settings in the picture. Im very sure that the problem was the speed, but i would like an opinion from someone else. The lithophane came out amazing though! My first one.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BambuLabA1Mini"> /u/BambuLabA1Mini </a> <br /> <span><a href="https://www.reddit.com/gallery/1ech2j0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ech2j0/too_fast_speed_while_printing_lithophane/">[comments]</a></span> </td></tr></table>

## I painted a 3d print
 - [https://www.reddit.com/r/3Dprinting/comments/1ecgkv6/i_painted_a_3d_print](https://www.reddit.com/r/3Dprinting/comments/1ecgkv6/i_painted_a_3d_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T05:48:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecgkv6/i_painted_a_3d_print/"> <img alt="I painted a 3d print" src="https://a.thumbs.redditmedia.com/4JITveixdJ66CjuI3eRzMBBFTvad7BqME7a24cQGV60.jpg" title="I painted a 3d print" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>hi guys I recently hand painted a 3D print of shadowheart(videogame character from bg3), it was very difficult and very long work, what do you think? If you are curious to see my other works my name is MythForge3D on tiktok</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Timely_Nail_7041"> /u/Timely_Nail_7041 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecgkv6">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecgkv6/i_painted_a_3d_print/">[comments]</a></span> </td></tr></table>

## The best thing I’ve ever printed
 - [https://www.reddit.com/r/3Dprinting/comments/1ecdahe/the_best_thing_ive_ever_printed](https://www.reddit.com/r/3Dprinting/comments/1ecdahe/the_best_thing_ive_ever_printed)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T02:41:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecdahe/the_best_thing_ive_ever_printed/"> <img alt="The best thing I’ve ever printed" src="https://preview.redd.it/eilgt1870sed1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d4e2c2825142da75d67f9ee4a6195d1a6c34f89a" title="The best thing I’ve ever printed" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I have not lost this thing since I printed the holder for it.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Puzzleheaded_Dish562"> /u/Puzzleheaded_Dish562 </a> <br /> <span><a href="https://i.redd.it/eilgt1870sed1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecdahe/the_best_thing_ive_ever_printed/">[comments]</a></span> </td></tr></table>

## Vader helmet
 - [https://www.reddit.com/r/3Dprinting/comments/1ecbkri/vader_helmet](https://www.reddit.com/r/3Dprinting/comments/1ecbkri/vader_helmet)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T01:14:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecbkri/vader_helmet/"> <img alt="Vader helmet" src="https://preview.redd.it/hp7x8gllkred1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=adffce5b2fad56d6cf8e92f6527f47d1e12fa804" title="Vader helmet" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Printed, prepped and painted by me. Lined the dome with some fiber glass and the face with just fiberglass resin. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Tmama187"> /u/Tmama187 </a> <br /> <span><a href="https://i.redd.it/hp7x8gllkred1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecbkri/vader_helmet/">[comments]</a></span> </td></tr></table>

## Multicolor Splice Night Light
 - [https://www.reddit.com/r/3Dprinting/comments/1ecb6nd/multicolor_splice_night_light](https://www.reddit.com/r/3Dprinting/comments/1ecb6nd/multicolor_splice_night_light)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T00:55:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecb6nd/multicolor_splice_night_light/"> <img alt="Multicolor Splice Night Light" src="https://b.thumbs.redditmedia.com/5Qb9pwF0K07XyNC0cUG_BiX-68ZKyYJ6HwnHtliZpDg.jpg" title="Multicolor Splice Night Light" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AllenJeager"> /u/AllenJeager </a> <br /> <span><a href="https://www.reddit.com/gallery/1ecb6nd">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecb6nd/multicolor_splice_night_light/">[comments]</a></span> </td></tr></table>

## Newbie
 - [https://www.reddit.com/r/3Dprinting/comments/1ecapqe/newbie](https://www.reddit.com/r/3Dprinting/comments/1ecapqe/newbie)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-26T00:32:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ecapqe/newbie/"> <img alt="Newbie" src="https://preview.redd.it/ez5x75m6dred1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8660cc8ec7dc56a98ec6a8dd264902723032c51c" title="Newbie" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I know nothing. Zero things about printing stuff but super interested I just purchased a Bambu P1S combo. What are the best websites to get stencils? Like the files? I have reptiles so looking for hides and reptile stuff. My machine shipped today so I’ll be researching how it works today. TIA some frog butts for tax </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IntelligentBadger380"> /u/IntelligentBadger380 </a> <br /> <span><a href="https://i.redd.it/ez5x75m6dred1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ecapqe/newbie/">[comments]</a></span> </td></tr></table>

