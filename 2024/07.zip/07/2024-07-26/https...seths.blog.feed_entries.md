# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Important change is systems change
 - [https://seths.blog/2024/07/important-change-is-systems-change](https://seths.blog/2024/07/important-change-is-systems-change)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-07-26T08:28:00+00:00

Willpower is overrated. If you want to eat healthier, don&#8217;t work hard to avoid stopping at the cookie jar when you walk into the kitchen. Get rid of the cookie jar. Systems are long-lasting, widespread and resilient. We can push back on them with effort, but over time, the system usually comes out ahead. Once [&#8230;]

