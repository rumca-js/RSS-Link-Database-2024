# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Honduras, 15 Years After the Coup: An Interview With Ousted President Manuel Zelaya
 - [https://theintercept.com/2024/07/26/deconstructed-honduras-coup-manuel-zelaya-interview](https://theintercept.com/2024/07/26/deconstructed-honduras-coup-manuel-zelaya-interview)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-07-26T10:00:00+00:00

<p>Fifteen years after the 2009 Honduran coup, Zelaya sits down for an exclusive interview with Deconstructed.</p>
<p>The post <a href="https://theintercept.com/2024/07/26/deconstructed-honduras-coup-manuel-zelaya-interview/">Honduras, 15 Years After the Coup: An Interview With Ousted President Manuel Zelaya</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

