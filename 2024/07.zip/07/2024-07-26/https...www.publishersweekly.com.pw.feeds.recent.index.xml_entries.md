# Source:Publisher weekly, URL:https://www.publishersweekly.com/pw/feeds/recent/index.xml, language:en-US

## 6 Major Post-Roe Books on Abortion and American History
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/95549-6-post-roe-books-on-abortion-and-american-history.html](http://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/95549-6-post-roe-books-on-abortion-and-american-history.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-07-26T04:00:00+00:00



## 8 New Books On the Lives of America's Working Class
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/95574-8-new-books-on-the-lives-of-america-s-working-class.html](http://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/95574-8-new-books-on-the-lives-of-america-s-working-class.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-07-26T04:00:00+00:00



## Sam Helmick Named ALA President for 2025-2026
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/libraries/article/95577-sam-helmick-named-ala-president-for-2025-2026.html](http://www.publishersweekly.com/pw/by-topic/industry-news/libraries/article/95577-sam-helmick-named-ala-president-for-2025-2026.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-07-26T04:00:00+00:00



## Spotify Adds 1,000 Audiobooks from 100 Publishers Distributed by Ingram
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/audio-books/article/95575-spotify-adds-1-000-audiobooks-from-100-publishers-distributed-by-ingram.html](http://www.publishersweekly.com/pw/by-topic/industry-news/audio-books/article/95575-spotify-adds-1-000-audiobooks-from-100-publishers-distributed-by-ingram.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-07-26T04:00:00+00:00



## The Week in Libraries: July 26, 2024
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/libraries/article/95586-the-week-in-libraries-july-26-2024.html](http://www.publishersweekly.com/pw/by-topic/industry-news/libraries/article/95586-the-week-in-libraries-july-26-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-07-26T04:00:00+00:00

Among the week's headlines: Kamala Harris addresses book banning at a campaign event; a community in Michigan seeks to remove its library board over their refusal to ban books; and NBC News has a chilling look at an officer's bid to charge three Texas school librarians for sharing inappropriate books.

