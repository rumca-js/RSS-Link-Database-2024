# Source:Vsauce, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA, language:en-US

## I Made A Solenoid Engine!
 - [https://www.youtube.com/watch?v=S85VFXRKptk](https://www.youtube.com/watch?v=S85VFXRKptk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA
 - date published: 2024-07-26T15:28:45+00:00

http://www.curiositybox.com/solenoid

