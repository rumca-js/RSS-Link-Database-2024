# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #2181 - Alan Graham
 - [https://www.youtube.com/watch?v=aHyNE_13V9w](https://www.youtube.com/watch?v=aHyNE_13V9w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2024-07-26T17:00:01+00:00

Alan is the founder and CEO of Mobile Loaves & Fishes, a Christian social outreach ministry that provides food and clothing, cultivates community and promotes dignity to homeless men and women in need. He's also the host of the "Gospel Con Carne" podcast and author of "Welcome Homeless: One Man’s Journey of Discovering the Meaning of Home."

www.mlf.org

