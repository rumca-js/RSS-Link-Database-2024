# Source:BBC, URL:https://feeds.bbci.co.uk/news/rss.xml, language:en-US

## ‘My day in a Liverpool alley with 35 drag queens’
 - [https://www.bbc.com/news/articles/c7207lgw7k7o](https://www.bbc.com/news/articles/c7207lgw7k7o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T23:41:18+00:00

Queen by Magnus Hastings is a "one of a kind" drag photography exhibition.

## Are you feeling grotty all the time?
 - [https://www.bbc.com/news/articles/cjm9gez8e8mo](https://www.bbc.com/news/articles/cjm9gez8e8mo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T23:36:33+00:00

Why some people are saying they've been ill all year.

## Are the UK's finances really worse than expected?
 - [https://www.bbc.com/news/articles/c9r329y9pqxo](https://www.bbc.com/news/articles/c9r329y9pqxo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T23:09:10+00:00

Rachel Reeves is set to reveal a public finances shortfall of billions on pounds after a snap audit.

## The Papers: 'Olympics sabotaged' and 'La Farce!'
 - [https://www.bbc.com/news/articles/crgkvlx6gmro](https://www.bbc.com/news/articles/crgkvlx6gmro)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T22:54:56+00:00

Many of Saturday's papers lead with sabotage attacks on France's high-speed rail network.

## Celine Dion makes stirring comeback at Olympics
 - [https://www.bbc.com/news/articles/cgerkx08dw0o](https://www.bbc.com/news/articles/cgerkx08dw0o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T22:45:51+00:00

It's the superstar singer's first performance since revealing a serious health condition two years ago.

## Olympics opening ceremony wows rain-soaked Paris crowds
 - [https://www.bbc.com/sport/olympics/articles/cw4yepmknkpo](https://www.bbc.com/sport/olympics/articles/cw4yepmknkpo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T22:07:36+00:00

The 2024 Olympics opens with teams parading along the River Seine in boats and performances from Celine Dion and Lady Gaga.

## Billy Connolly inspired £1,750 designer banana boots
 - [https://www.bbc.com/news/articles/c2x0ygpzd6jo](https://www.bbc.com/news/articles/c2x0ygpzd6jo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T21:57:52+00:00

A Scottish fashion designer has sold out of his take on Billy Connolly's iconic banana boots in just 24 hours.

## Shop stops selling luxury items as thefts rise
 - [https://www.bbc.com/news/articles/c1rw21j42q4o](https://www.bbc.com/news/articles/c1rw21j42q4o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T21:51:14+00:00

Julie Ruscitto says she has taken security measures and stopped selling high-end products.

## JD Vance defends 'childless cat ladies' comment after backlash
 - [https://www.bbc.com/news/articles/c147yn4xxx4o](https://www.bbc.com/news/articles/c147yn4xxx4o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T21:27:44+00:00

Donald Trump's vice-presidential candidate says his 2021 comments about Democrats were "sarcastic".

## Spectacular photos from the Paris 2024 opening ceremony
 - [https://www.bbc.com/news/articles/c9x827dnxpgo](https://www.bbc.com/news/articles/c9x827dnxpgo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T21:16:26+00:00

A selection of eye-catching moments from the opening ceremony for the 2024 Olympic Games in Paris.

## Green's 'wonderful cameo' - The Hundred's plays of the day
 - [https://www.bbc.com/sport/cricket/videos/c3gvyn3r43ko](https://www.bbc.com/sport/cricket/videos/c3gvyn3r43ko)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T21:15:36+00:00

Watch the best plays from day four of the 2024 Hundred as Northern Superchargers hosted Trent Rockets at Headingly, Leeds.

## Doctor Who spin-off to star Tovey and Mbatha-Raw
 - [https://www.bbc.com/news/articles/c9r32xg2y0lo](https://www.bbc.com/news/articles/c9r32xg2y0lo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T21:05:01+00:00

The War Between The Land And The Sea "will shake The Whoniverse to its foundations", says showrunner Russell T Davies.

## Families pay tribute to four friends killed in crash
 - [https://www.bbc.com/news/articles/cjk3gznk5vmo](https://www.bbc.com/news/articles/cjk3gznk5vmo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T21:05:01+00:00

Andrei Tudorov, Lyuben Gogov, Narcis Titianu, and Ioan Toma died when their car hit a tree.

## Warrington thrash Wigan to go top of Super League
 - [https://www.bbc.com/sport/rugby-league/articles/crg4px1rvdlo](https://www.bbc.com/sport/rugby-league/articles/crg4px1rvdlo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T21:03:09+00:00

Warrington atone for their Wembley Challenge Cup final defeat by crushing title rivals Wigan to go top of Super League.

## Scotland triumph in World Schools Debating Championships
 - [https://www.bbc.com/news/articles/crgm0e8kzj2o](https://www.bbc.com/news/articles/crgm0e8kzj2o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T20:44:04+00:00

The team defeated Bulgaria to lift the trophy in Belgrade on the motion: "This house regrets the glorification of champions".

## Three ways Trump is trying to end the Harris honeymoon
 - [https://www.bbc.com/news/articles/crg4p4ndkr0o](https://www.bbc.com/news/articles/crg4p4ndkr0o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T20:38:23+00:00

Kamala Harris is riding a wave of momentum, but Republicans sense vulnerabilities they can exploit.

## Timberlake 'not intoxicated' during arrest, lawyer says
 - [https://www.bbc.com/news/articles/cgxqjly724po](https://www.bbc.com/news/articles/cgxqjly724po)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T20:34:28+00:00

Police made several errors and should not have arrested the popstar, his lawyer Edward Burke said.

## Children who died in fire named as parents pay tribute
 - [https://www.bbc.com/news/articles/cq5j1wzq8ndo](https://www.bbc.com/news/articles/cq5j1wzq8ndo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T20:29:09+00:00

Nakash, 13, Aayat, 11, and seven-year-old Muhammad Malik died in the blaze in East Ham on 13 July.

## Doctor urged ME patient to stay on ward - inquest
 - [https://www.bbc.com/news/articles/c51yz0pq1ypo](https://www.bbc.com/news/articles/c51yz0pq1ypo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T19:54:06+00:00

Dr Kashyap Patel told inquest he was prepared to keep Maeve Boothby-O’Neill in hospital "as long as was needed."

## Minions make Olympics cameo
 - [https://www.bbc.com/sport/olympics/videos/clly79pmljmo](https://www.bbc.com/sport/olympics/videos/clly79pmljmo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T19:42:26+00:00

The Minions make a cameo appearance at the opening ceremony of the 2024 Paris Olympics.

## 'Forget what he says' - Edwards fired up at final face-off
 - [https://www.bbc.com/sport/mixed-martial-arts/articles/cyx5vez6n4no](https://www.bbc.com/sport/mixed-martial-arts/articles/cyx5vez6n4no)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T19:30:15+00:00

British champion Leon Edwards and American Belal Muhammad weigh in before their welterweight title fight at UFC 304 in Manchester on Saturday.

## England target 'big runs' after 'special' Atkinson delivers
 - [https://www.bbc.com/sport/cricket/articles/ce58j6yyen6o](https://www.bbc.com/sport/cricket/articles/ce58j6yyen6o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T19:30:09+00:00

Despite losing three wickets late on day one of the third Test, England can still pile on "big runs" against West Indies at Edgbaston, says Chris Woakes.

## Team GB arrive at Paris 2024 opening ceremony
 - [https://www.bbc.com/sport/olympics/videos/cv2gdrvvn0po](https://www.bbc.com/sport/olympics/videos/cv2gdrvvn0po)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T19:09:30+00:00

Team GB make their entrance at the Paris 2024 Olympics opening ceremony, led by flagbearers Tom Daley and Helen Glover.

## Who could have attacked France's high-speed rail?
 - [https://www.bbc.com/news/articles/cd16en19gd3o](https://www.bbc.com/news/articles/cd16en19gd3o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T18:53:21+00:00

France's interior minister vows the attackers will be arrested fast, but does not say who was to blame.

## Couple's surprise after baby born early on holiday
 - [https://www.bbc.com/news/videos/crgr8jwl20lo](https://www.bbc.com/news/videos/crgr8jwl20lo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T18:46:20+00:00

Cai Daniels and Ali Lloyd were on holiday in Tenerife when Ms Lloyd unexpectedly went into labour.

## Lady Gaga performs at Olympics opening ceremony
 - [https://www.bbc.com/sport/olympics/videos/crgel57gj7no](https://www.bbc.com/sport/olympics/videos/crgel57gj7no)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T18:46:02+00:00

Watch American singer Lady Gaga's stunning performance at the opening ceremony of the Paris 2024 Olympics.

## BBC Verify analyses attacks on the French railway system
 - [https://www.bbc.com/news/videos/cy68w5900jlo](https://www.bbc.com/news/videos/cy68w5900jlo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T18:41:28+00:00

French rail company SNCF said its high-speed network had been targeted by "malicious acts" aimed at paralysing the rail network

## Holder stars as late wickets leave third Test finely poised
 - [https://www.bbc.com/sport/cricket/videos/crgelvg54xro](https://www.bbc.com/sport/cricket/videos/crgelvg54xro)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T18:18:50+00:00

Watch highlights as Jason Holder hits 59 and takes two catches as England surrender the initiative to reach 38-3 at stumps on day one of the third Test against West Indies.

## John Lewis allowed to build homes for first time
 - [https://www.bbc.com/news/articles/c0dmyl1kvrpo](https://www.bbc.com/news/articles/c0dmyl1kvrpo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T18:16:42+00:00

The department store is pushing to build rental flats as it looks for new ways to bring in money.

## Couple's surprise after baby born early on holiday
 - [https://www.bbc.com/news/articles/cd1xdllv6y1o](https://www.bbc.com/news/articles/cd1xdllv6y1o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T18:06:41+00:00

George arrives three months ahead of his due date while his parents are on their "babymoon".

## Late wickets leave third Test finely poised
 - [https://www.bbc.com/sport/cricket/articles/c9782e0813do](https://www.bbc.com/sport/cricket/articles/c9782e0813do)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T17:52:37+00:00

England lose openers Zak Crawley and Ben Duckett late in the evening session to surrender the initiative on day one of the third Test against West Indies.

## Holder takes 'really good catch' to dismiss Crawley
 - [https://www.bbc.com/sport/cricket/videos/c1rwy8l2dnzo](https://www.bbc.com/sport/cricket/videos/c1rwy8l2dnzo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T17:39:02+00:00

West Indies' Jason Holder takes a "really good catch" to dismiss England opener Zak Crawley on day one of the third Test at Edgbaston.

## Zoo announces death of 58-year-old chimpanzee
 - [https://www.bbc.com/news/articles/c035y602remo](https://www.bbc.com/news/articles/c035y602remo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T17:16:39+00:00

Boris had been at the zoo since 1969, having been rescued from a pet shop window in New York.

## Councillor blames INLA for homeless centre attack
 - [https://www.bbc.com/news/articles/cv2gq9zw8d1o](https://www.bbc.com/news/articles/cv2gq9zw8d1o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T17:02:29+00:00

Ron McDowell condemns the "gross hypocrisy" of republican paramilitaries due to their drugs record.

## EU regulator rejects Alzheimer's drug lecanemab
 - [https://www.bbc.com/news/articles/crgm0v1ne08o](https://www.bbc.com/news/articles/crgm0v1ne08o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T17:01:49+00:00

It said the benefits of the treatment did not outweigh the risk of serious side effects.

## Root takes 'brilliant catch' to remove Motie
 - [https://www.bbc.com/sport/cricket/videos/crg47er4312o](https://www.bbc.com/sport/cricket/videos/crg47er4312o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T16:58:05+00:00

Joe Root takes a "brilliant" one-handed catch behind wicketkeeper Jamie Smith to remove Gudakesh Motie on day one of the third Test at Edgbaston.

## Mass killer dies as victims still demand justice
 - [https://www.bbc.com/news/articles/cd1r45kme45o](https://www.bbc.com/news/articles/cd1r45kme45o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T16:56:01+00:00

The 72-year-old South African was convicted for seven apartheid-era murders but was behind many more deaths.

## Tom Hiddleston opens BBC’s Paris 2024 coverage
 - [https://www.bbc.com/sport/olympics/videos/cjerp2yg29qo](https://www.bbc.com/sport/olympics/videos/cjerp2yg29qo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T16:47:40+00:00

Actor Tom Hiddleston opens up the BBC's coverage of the Paris 2024 Olympics by paying homage to the French capital's 100-year connection to the Games.

## Woman not told about mum's XL bully death inquest
 - [https://www.bbc.com/news/articles/cv2g41vejdjo](https://www.bbc.com/news/articles/cv2g41vejdjo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T16:38:17+00:00

Gail Jones’s mum, Shirley Patrick, was repeatedly bitten by an XL bully cross in 2022.

## 'El Mayo' Zambada and El Chapo's son: Who are the drug lords held in US?
 - [https://www.bbc.com/news/articles/c0jqyggxgkjo](https://www.bbc.com/news/articles/c0jqyggxgkjo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T16:36:20+00:00

Ismael Zambada and Joaquín Guzmán López are two of the most wanted drug traffickers in the world.

## Bangladesh police detain protest leaders at hospital
 - [https://www.bbc.com/news/articles/c6p21g8863no](https://www.bbc.com/news/articles/c6p21g8863no)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T16:24:13+00:00

They were being treated for injuries they say were sustained after police tortured them in detention.

## Canada used drones before and Tokyo gold could be 'tarnished'
 - [https://www.bbc.com/sport/olympics/articles/c1vdye9yv20o](https://www.bbc.com/sport/olympics/articles/c1vdye9yv20o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T16:07:35+00:00

Canada Soccer's chief executive confirms drone use prior to Paris 2024, including at the recent Copa America.

## 'Boneless' chicken wings can have bones, US court rules
 - [https://www.bbc.com/news/articles/c4ngyely232o](https://www.bbc.com/news/articles/c4ngyely232o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T16:04:03+00:00

The ruling ends a lawsuit filed by a man who fell ill after swallowing a piece of bone from his boneless order.

## Slapping therapist guilty of manslaughter
 - [https://www.bbc.com/news/articles/c51yvxxd3n8o](https://www.bbc.com/news/articles/c51yvxxd3n8o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T15:41:48+00:00

Danielle Car-Gomm, 71, died four days into a slapping therapy workshop in Wiltshire.

## UK drops planned Israel arrest warrant challenge
 - [https://www.bbc.com/news/articles/ckkg525l93lo](https://www.bbc.com/news/articles/ckkg525l93lo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T15:30:18+00:00

Keir Starmer's spokesperson said the issue was a matter for the International Criminal Court.

## Rain and cooler weather bring relief from Jasper fire
 - [https://www.bbc.com/news/articles/cqe61986pnpo](https://www.bbc.com/news/articles/cqe61986pnpo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T15:27:11+00:00

Fire crews are taking advantage of the pause from hot and dry conditions to battle the still out-of-control blaze.

## PC to face criminal investigation over airport kick video
 - [https://www.bbc.com/news/articles/c19ky4z8kjmo](https://www.bbc.com/news/articles/c19ky4z8kjmo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T14:36:22+00:00

A PC is to be investigated over an alleged assault on a man at Manchester Aiport, the police watchdog says.

## Wax museum removes Sinead O'Connor figure
 - [https://www.bbc.com/news/articles/cz9xqy6ggz1o](https://www.bbc.com/news/articles/cz9xqy6ggz1o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T14:04:27+00:00

The National Wax Museum say it will remake a waxwork of the late Irish singer after an unveiling.

## Boy was aggressive, says accused ex-rugby player
 - [https://www.bbc.com/news/articles/cm520e5g22po](https://www.bbc.com/news/articles/cm520e5g22po)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T13:49:58+00:00

Mathew Back wanted to stop the boy, who had a history of grabbing female staff, the court hears.

## 'He's played no shot' - Hodge bowled by Woakes
 - [https://www.bbc.com/sport/cricket/videos/c6p219k63v9o](https://www.bbc.com/sport/cricket/videos/c6p219k63v9o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T13:36:36+00:00

West Indies' Kavem Hodge is bowled by Chris Woakes after the batter plays no shot on day one of the third Test against England at Edgbaston.

## Verstappen fastest in first practice but takes grid penalty
 - [https://www.bbc.com/sport/articles/cevwqk0vv0go](https://www.bbc.com/sport/articles/cevwqk0vv0go)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T12:46:08+00:00

Max Verstappen tops first practice at the Belgian Grand Prix but will drop 10 places for Sunday's race after receiving an engine penalty.

## 'Bowled him!' Wood removes McKenzie's middle stump
 - [https://www.bbc.com/sport/cricket/videos/c3gvy91wz4eo](https://www.bbc.com/sport/cricket/videos/c3gvy91wz4eo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T12:10:22+00:00

England's Mark Wood uproots the middle stump to take the wicket of West Indies' Kirk McKenzie on day one of the third Test at Edgbaston.

## Met Police officer admits stealing from dying man
 - [https://www.bbc.com/news/articles/crglwd8nx62o](https://www.bbc.com/news/articles/crglwd8nx62o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T12:06:48+00:00

Craig Carter, 51, took cash from a man who died in the street in Hornsey in September 2022.

## Man jailed for murdering lodger and cutting up body
 - [https://www.bbc.com/news/articles/c4ngyxgwr4yo](https://www.bbc.com/news/articles/c4ngyxgwr4yo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T11:58:15+00:00

The severed remains of Simon Shotton were discovered at various locations in Bournemouth.

## One in four Eurostar trains cancelled after arson attacks
 - [https://www.bbc.com/news/articles/cn059xxp03ko](https://www.bbc.com/news/articles/cn059xxp03ko)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T11:56:21+00:00

France's transport minister blames disruptions on "co-ordinated malicious acts" on high-speed rail lines.

## Murder arrest after man shot dead in field
 - [https://www.bbc.com/news/articles/c0xjyz8v51wo](https://www.bbc.com/news/articles/c0xjyz8v51wo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T11:56:06+00:00

A 29-year-old man from Scarisbrick remains in custody after police recovered a shotgun from the scene.

## Bach has 'full confidence' in French authorities after rail arson attacks
 - [https://www.bbc.com/sport/articles/c4ngy04py32o](https://www.bbc.com/sport/articles/c4ngy04py32o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T11:40:58+00:00

IOC president Thomas Bach says he has "full confidence" in the French authorities after Paris' train network was hit by arson attacks just hours before the Games' opening ceremony.

## 'The ick' and 'boop' newest entries in dictionary
 - [https://www.bbc.com/news/articles/c19k2rdzxyko](https://www.bbc.com/news/articles/c19k2rdzxyko)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T11:26:24+00:00

The new additions are among more than 3,200 words and phrases introduced this year.

## Rapper Snoop Dogg carries Olympic torch through Paris
 - [https://www.bbc.com/sport/videos/cd195l8052no](https://www.bbc.com/sport/videos/cd195l8052no)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T11:18:20+00:00

American rapper Snoop Dogg carries the Olympic torch through the streets of Paris, before the Games' opening ceremony.

## Badenoch accuses rival campaign of dirty tricks
 - [https://www.bbc.com/news/articles/czrj832e973o](https://www.bbc.com/news/articles/czrj832e973o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T11:12:52+00:00

The potential Tory leadership contender says "dishonest" and damaging claims are being spread about her.

## Rapist who threw victim's brother off cliff jailed
 - [https://www.bbc.com/news/articles/c903lddlpe3o](https://www.bbc.com/news/articles/c903lddlpe3o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T10:56:40+00:00

Anthony Stocks was trying to silence the brother of a girl he had been sexually abusing.

## Assisted dying bill introduced in Parliament
 - [https://www.bbc.com/news/articles/c3g9yvdrxzzo](https://www.bbc.com/news/articles/c3g9yvdrxzzo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T10:56:37+00:00

Former Justice Secretary Lord Falconer's bill would allow terminally ill adults to end their lives.

## Scottish bog gets world heritage status
 - [https://www.bbc.com/news/articles/cv2gz1p2v12o](https://www.bbc.com/news/articles/cv2gz1p2v12o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T10:48:37+00:00

After an almost 40-year campaign, a little-known UK landscape has been awarded world heritage status.

## Rural sabotage plays havoc with opening of Paris Olympics
 - [https://www.bbc.com/news/articles/c28eyr3y18yo](https://www.bbc.com/news/articles/c28eyr3y18yo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T10:28:40+00:00

There is tight security for the opening ceremony, but saboteurs struck rail lines miles outside the city.

## Government delays university free-speech fines
 - [https://www.bbc.com/news/articles/cv2gj1x11nmo](https://www.bbc.com/news/articles/cv2gj1x11nmo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T09:58:18+00:00

Powers for universities to be fined for failing to uphold freedom of speech have been put on hold.

## Obamas endorse Kamala Harris for president
 - [https://www.bbc.com/news/articles/c3g32y8j772o](https://www.bbc.com/news/articles/c3g32y8j772o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T09:50:10+00:00

Barack and Michelle Obama say Ms Harris has the "strength that this critical moment demands".

## Attempted murder arrests after stabbing near park
 - [https://www.bbc.com/news/articles/cqv51g5dq46o](https://www.bbc.com/news/articles/cqv51g5dq46o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T09:49:03+00:00

Police are appealing for anyone with information or footage of the incident to come forward.

## Crew 'held each other and jumped' as typhoon sank ship
 - [https://www.bbc.com/news/articles/cd1x79718vgo](https://www.bbc.com/news/articles/cd1x79718vgo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T09:26:49+00:00

Survivors of the Tanzania-flagged Fu Shun said they swam "with all their lives" to shore.

## Are temperatures set to rise next week?
 - [https://www.bbc.com/weather/articles/cjqep4lx4ejo](https://www.bbc.com/weather/articles/cjqep4lx4ejo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T08:59:34+00:00

The month looks set to end on a warm note for many, though it's not all dry and sunny.

## Family of man kicked by police appeal for calm
 - [https://www.bbc.com/news/articles/cy68wn8d7l1o](https://www.bbc.com/news/articles/cy68wn8d7l1o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T07:41:24+00:00

The man's family want to make it clear they have "no political agenda whatsoever", an MP says.

## Olympics: Is Paris poised for success?
 - [https://www.bbc.co.uk/sounds/play/w3ct6dwh](https://www.bbc.co.uk/sounds/play/w3ct6dwh)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T07:00:00+00:00

France grapples with politics, climate and security as the Games begin

## Will the sun shine on the Olympic opening ceremony? Here’s our forecast
 - [https://www.bbc.com/news/videos/cprqp3yy5jlo](https://www.bbc.com/news/videos/cprqp3yy5jlo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T06:57:46+00:00

Alexandra Humphreys brings you the weather forecast for the first week of the Olympic Games

## Priestman removed as Olympic boss over drone incident
 - [https://www.bbc.com/sport/articles/c2x0y786rv0o](https://www.bbc.com/sport/articles/c2x0y786rv0o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T06:49:37+00:00

Canada women's football manager Beverly Priestman has been removed as Olympic head coach after the New Zealand Olympic Committee reported that a drone had been flown over their training session on Monday.

## Gracehill wins Unesco World Heritage site status
 - [https://www.bbc.com/news/articles/c8809jgn9d8o](https://www.bbc.com/news/articles/c8809jgn9d8o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T06:46:31+00:00

A historical village in County Antrim has joined the likes of the Tower of London and the Taj Mahal.

## Drivers still pay too much for fuel, warns watchdog
 - [https://www.bbc.com/news/articles/c0kr2kdv181o](https://www.bbc.com/news/articles/c0kr2kdv181o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T06:27:18+00:00

The Competition and Markets Authority says poor competition cost British motorists £1.6bn last year.

## Philippines 'prepares for worst' after oil spill
 - [https://www.bbc.com/news/articles/cd1ejnz420xo](https://www.bbc.com/news/articles/cd1ejnz420xo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T06:12:35+00:00

Authorities are racing to contain the oil spill and prevent it from reaching the capital, Manila.

## Major feared Churchill archive would be broken up
 - [https://www.bbc.com/news/articles/c7207g6pd2xo](https://www.bbc.com/news/articles/c7207g6pd2xo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T06:01:06+00:00

Newly-released papers show John Major was told Churchill's private archive could be broken up.

## Farmer champions safety after life-changing injury
 - [https://www.bbc.com/news/articles/cz9x2yz3qpno](https://www.bbc.com/news/articles/cz9x2yz3qpno)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T05:36:30+00:00

Ryan Taggart, 21, from Kilrea, lost sight in one eye after a farm accident in Shropshire in 2022.

## Quiz: How well do you know Team GB's athletes?
 - [https://www.bbc.com/sport/articles/cg33m937002o](https://www.bbc.com/sport/articles/cg33m937002o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T05:33:00+00:00

The Paris Olympics are getting under way, but how well do you remember Team GB successes from Games gone by? Try our quiz.

## Peaty's 'no pressure' interview with chef Ramsay
 - [https://www.bbc.com/sport/swimming/videos/cn086xpp15zo](https://www.bbc.com/sport/swimming/videos/cn086xpp15zo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T05:10:00+00:00

Gordon Ramsay and Adam Peaty get together before the Paris Olympics to chat about everything from food to fame.

## Liz Kendall: Being a mum helps me switch off
 - [https://www.bbc.com/news/videos/cv2gzqg47wlo](https://www.bbc.com/news/videos/cv2gzqg47wlo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T05:09:29+00:00

Work and pensions secretary says "being a mum" helps her "switch off" from politics.

## 'Menopause must be treated fairly for women at work'
 - [https://www.bbc.com/news/articles/crglpn7pjjzo](https://www.bbc.com/news/articles/crglpn7pjjzo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T05:05:42+00:00

A mother who says the menopause is "harrowing" backs a study to help employers treat women better.

## Australian hockey star amputates finger to play at Olympics
 - [https://www.bbc.com/news/articles/ckmg7ngkgjeo](https://www.bbc.com/news/articles/ckmg7ngkgjeo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T04:37:10+00:00

Matt Dawson broke his finger only two weeks ago but will join the Kookaburras in their medal campaign.

## Seven things to look out for during the Olympic opening ceremony
 - [https://www.bbc.com/news/articles/cljy547p871o](https://www.bbc.com/news/articles/cljy547p871o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T03:52:20+00:00

Paris is opening the games with an spectacular ceremony. Here's all you need to know.

## NHS and care regulator 'not fit for purpose'
 - [https://www.bbc.com/news/articles/cjk3p4jnnl6o](https://www.bbc.com/news/articles/cjk3p4jnnl6o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T03:43:02+00:00

The health secretary is 'stunned' by failings in inspecting hospitals, GPs and care homes in England.

## TikTok midwife: ‘Jealous colleagues bullied me out’
 - [https://www.bbc.com/news/articles/c9x8pp10951o](https://www.bbc.com/news/articles/c9x8pp10951o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T03:28:36+00:00

The former midwife at Bristol's Southmead Hospital is suing for constructive unfair dismissal.

## Reeves expected to reveal shortfall of billions
 - [https://www.bbc.com/news/articles/cydv2v3170eo](https://www.bbc.com/news/articles/cydv2v3170eo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T03:12:18+00:00

The chancellor confirms she will make a statement to Parliament next week on the state of public finances.

## BBC Verify analyses Manchester Airport incident footage
 - [https://www.bbc.com/news/videos/cn05p53qw9zo](https://www.bbc.com/news/videos/cn05p53qw9zo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T01:14:51+00:00

BBC Verify's Richard Irvine-Brown analyses the footage from Manchester Airport's Terminal 2.

## 'Monster' fires may have destroyed half of historic Canadian town
 - [https://www.bbc.com/news/articles/cyj423n2jdgo](https://www.bbc.com/news/articles/cyj423n2jdgo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T01:06:03+00:00

The blazes are still out of control as firefighters try to save as many buildings as possible, officials say.

## From Olympic braids to sunsets: Africa's top shots
 - [https://www.bbc.com/news/articles/cg64pew2n0vo](https://www.bbc.com/news/articles/cg64pew2n0vo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T00:51:35+00:00

A selection of the week's best photos from across the African continent.

## Griff has toured with Taylor Swift, but still gets stage fright
 - [https://www.bbc.com/news/articles/c897wy5p1qlo](https://www.bbc.com/news/articles/c897wy5p1qlo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T00:49:03+00:00

The singer talks about supporting Swift in stadiums and recording with Coldplay's Chris Martin.

## Leader of Mexico's Sinaloa drug cartel held in US
 - [https://www.bbc.com/news/articles/c4ng4g31x1wo](https://www.bbc.com/news/articles/c4ng4g31x1wo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T00:48:46+00:00

Ismael "El Mayo" Zambada co-founded the group with El Chapo, who is currently jailed in America.

## Venezuela election: Five things you need to know
 - [https://www.bbc.com/news/articles/c720dr48g1po](https://www.bbc.com/news/articles/c720dr48g1po)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T00:37:54+00:00

Venezuelans vote in a presidential election which could see the country change course after 25 years.

## Trump shooting: the plan and the botched response
 - [https://www.bbc.com/news/articles/cn38px7lyy0o](https://www.bbc.com/news/articles/cn38px7lyy0o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T00:31:40+00:00

New evidence tells us how the gunman's plan came together but not why.

## Stuck in hospital for months - but not ill
 - [https://www.bbc.com/news/articles/c51yvr5gg48o](https://www.bbc.com/news/articles/c51yvr5gg48o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T00:01:04+00:00

No suitable home has been found in the community for the 36-year-old, who is disabled.

## Ukraine's hopes and challenges after long wait for F-16s
 - [https://www.bbc.com/news/articles/c0kr240gd18o](https://www.bbc.com/news/articles/c0kr240gd18o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-07-26T00:00:03+00:00

Russia intends to destroy dozens of US-built warplanes as soon as they arrive in Ukraine.

