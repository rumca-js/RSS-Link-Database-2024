# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Nowy regulamin Sejmu. "Epokowa zmiana dla obywateli"
 - [https://wydarzenia.interia.pl/kraj/news-nowy-regulamin-sejmu-epokowa-zmiana-dla-obywateli,nId,7723901](https://wydarzenia.interia.pl/kraj/news-nowy-regulamin-sejmu-epokowa-zmiana-dla-obywateli,nId,7723901)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T21:21:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-regulamin-sejmu-epokowa-zmiana-dla-obywateli,nId,7723901"><img align="left" alt="Nowy regulamin Sejmu. &quot;Epokowa zmiana dla obywateli&quot;" src="https://i.iplsc.com/nowy-regulamin-sejmu-epokowa-zmiana-dla-obywateli/000JJ231CKR5FSO0-C321.jpg" /></a>Sejm zmienił swój regulamin. Szymon Hołownia ocenił, że jest to &quot;epokowa zmiana dla obywateli, którzy już od jesieni będą mogli aktywnie uczestniczyć w procesie legislacyjnym&quot;. Ponieważ piątkowe posiedzenie Sejmu było ostatnim przed wakacjami, marszałek podsumował też prace izby z całego roku. </p><br clear="all" />

## Pękła tama w Rosji. Woda zalewa wioski, rozpoczęto ewakuację
 - [https://wydarzenia.interia.pl/zagranica/news-pekla-tama-w-rosji-woda-zalewa-wioski-rozpoczeto-ewakuacje,nId,7723881](https://wydarzenia.interia.pl/zagranica/news-pekla-tama-w-rosji-woda-zalewa-wioski-rozpoczeto-ewakuacje,nId,7723881)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T20:13:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pekla-tama-w-rosji-woda-zalewa-wioski-rozpoczeto-ewakuacje,nId,7723881"><img align="left" alt="Pękła tama w Rosji. Woda zalewa wioski, rozpoczęto ewakuację" src="https://i.iplsc.com/pekla-tama-w-rosji-woda-zalewa-wioski-rozpoczeto-ewakuacje/000JJ1VYFH59ULD4-C321.jpg" /></a>Pękła tama na zbiorniku Kialimskoje, położonym w obwodzie czelabińskim w Rosji. Wielka woda zalewa okoliczne miejscowości, w związku z czym ewakuowanych zostało kilkadziesiąt osób. Niektórzy, ratując się przed wodą, szukają schronienia na dachach domów. Mieszkańcy zgłaszali wcześniej lokalnym władzom, że z tamą coś się dzieje, jednak ich nie wysłuchano.</p><br clear="all" />

## Skontrolowali wydatki poprzedników. Minister wprost o wydanych milionach
 - [https://wydarzenia.interia.pl/kraj/news-skontrolowali-wydatki-poprzednikow-minister-wprost-o-wydanyc,nId,7723869](https://wydarzenia.interia.pl/kraj/news-skontrolowali-wydatki-poprzednikow-minister-wprost-o-wydanyc,nId,7723869)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T19:27:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-skontrolowali-wydatki-poprzednikow-minister-wprost-o-wydanyc,nId,7723869"><img align="left" alt="Skontrolowali wydatki poprzedników. Minister wprost o wydanych milionach" src="https://i.iplsc.com/skontrolowali-wydatki-poprzednikow-minister-wprost-o-wydanyc/000JJ1S5Y05P5LMA-C321.jpg" /></a>&quot;Prawie sześć milionów złotych w roku wyborczym poprzednia władza wydała na promowanie samych tylko programów mieszkaniowych&quot; - przekazał minister rozwoju i technologii Krzysztof Paszyk. Rzecznik ministerstwa Jakub Stefaniak ocenił w rozmowie z Interią, że &quot;ta kwota jest przynajmniej kilkukrotnie wyższa niż w latach poprzednich&quot;. Jak dodał, nad sprawą pracują już prawnicy.</p><br clear="all" />

## Masowe zatrucie na basenie w Warszawie. Wielu poszkodowanych
 - [https://wydarzenia.interia.pl/mazowieckie/news-masowe-zatrucie-na-basenie-w-warszawie-wielu-poszkodowanych,nId,7723885](https://wydarzenia.interia.pl/mazowieckie/news-masowe-zatrucie-na-basenie-w-warszawie-wielu-poszkodowanych,nId,7723885)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T19:08:49+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-masowe-zatrucie-na-basenie-w-warszawie-wielu-poszkodowanych,nId,7723885"><img align="left" alt="Masowe zatrucie na basenie w Warszawie. Wielu poszkodowanych" src="https://i.iplsc.com/masowe-zatrucie-na-basenie-w-warszawie-wielu-poszkodowanych/000FZ899M2IC99HN-C321.jpg" /></a>Na pływalni Polonez OSiR Targówek przy ulicy Łabiszyńskiej 20 na Targówku korzystający z basenu dorośli i dzieci prawdopodobnie zatruli się chlorem. Poszkodowane są 23 osoby - przekazała w komunikacie - Wojewódzka Stacja Pogotowia Ratunkowego &quot;Meditrans&quot; w Warszawie</p><br clear="all" />

## Ponad 46 lat była zmuszana do pracy. W końcu nadszedł ratunek
 - [https://wydarzenia.interia.pl/zagranica/news-ponad-46-lat-byla-zmuszana-do-pracy-w-koncu-nadszedl-ratunek,nId,7723862](https://wydarzenia.interia.pl/zagranica/news-ponad-46-lat-byla-zmuszana-do-pracy-w-koncu-nadszedl-ratunek,nId,7723862)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T19:03:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ponad-46-lat-byla-zmuszana-do-pracy-w-koncu-nadszedl-ratunek,nId,7723862"><img align="left" alt="Ponad 46 lat była zmuszana do pracy. W końcu nadszedł ratunek" src="https://i.iplsc.com/ponad-46-lat-byla-zmuszana-do-pracy-w-koncu-nadszedl-ratunek/000JJ1M76KARYKY5-C321.jpg" /></a>Po 46 latach kobieta zmuszana do pracy dla jednej z rodzin w Rio de Janeiro, została uwolniona przez policję. 59-latka nie otrzymywała wynagrodzenia, nie brała wolnego, nie mogła również utrzymywać kontaktów z nikim spoza osób, z którymi mieszkała. Inspektor pracy podkreślił, że kobieta &quot;całkowicie utraciła wolność, w tym swobodę kierowania własnym życiem&quot;. Po tym, jak została uwolniona, Brazylijka spełniła swoje marzenie.</p><br clear="all" />

## Coraz więcej niewiadomych w sprawie zamachu na Trumpa. Kula czy odłamek?
 - [https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-coraz-wiecej-niewiadomych-w-sprawie-zamachu-na-trumpa-kula-c,nId,7723861](https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-coraz-wiecej-niewiadomych-w-sprawie-zamachu-na-trumpa-kula-c,nId,7723861)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T19:02:39+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-prezydenckie-usa-2024/news-coraz-wiecej-niewiadomych-w-sprawie-zamachu-na-trumpa-kula-c,nId,7723861"><img align="left" alt="Coraz więcej niewiadomych w sprawie zamachu na Trumpa. Kula czy odłamek?" src="https://i.iplsc.com/coraz-wiecej-niewiadomych-w-sprawie-zamachu-na-trumpa-kula-c/000JJ1OXYF8TJ7GL-C321.jpg" /></a>Szef FBI nie ma pewności, czy podczas zamachu na życie Donalda Trumpa byłego prezydenta trafiła kula, czy odłamek. Sam kandydat twierdzi, że &quot;przyjął kulę za demokrację&quot;. Media amerykańskie podkreślają z kolei, że ustalenie tego, co raniło Donalda Trumpa staje się &quot;sprawą polityczną&quot;.</p><br clear="all" />

## Niemiec skazany na karę śmierci. "Pewnego dnia po prostu zniknął"
 - [https://wydarzenia.interia.pl/zagranica/news-niemiec-skazany-na-kare-smierci-pewnego-dnia-po-prostu-znikn,nId,7723846](https://wydarzenia.interia.pl/zagranica/news-niemiec-skazany-na-kare-smierci-pewnego-dnia-po-prostu-znikn,nId,7723846)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T18:04:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemiec-skazany-na-kare-smierci-pewnego-dnia-po-prostu-znikn,nId,7723846"><img align="left" alt="Niemiec skazany na karę śmierci. &quot;Pewnego dnia po prostu zniknął&quot;" src="https://i.iplsc.com/niemiec-skazany-na-kare-smierci-pewnego-dnia-po-prostu-znikn/000JJ1LGH434DG6I-C321.jpg" /></a>Obywatel Niemiec, Rico Krieger, został skazany na Białorusi na karę śmierci. Sprawą zainteresowały się niemieckie media, które dotarły do znajomych mężczyzny. Okazuje się, że 30-latek pracował dla Niemieckiego Czerwonego Krzyża i chciał wyemigrować do USA. Zamiast do Stanów Zjednoczonych pojechał jednak na Ukrainę. Kilka dni później pojawiła się informacja, że został zatrzymany na Białorusi.</p><br clear="all" />

## Ukraina schodzi pod ziemię. Nie wszyscy są zadowoleni
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-schodzi-pod-ziemie-nie-wszyscy-sa-zadowoleni,nId,7723840](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-schodzi-pod-ziemie-nie-wszyscy-sa-zadowoleni,nId,7723840)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T17:57:50+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-schodzi-pod-ziemie-nie-wszyscy-sa-zadowoleni,nId,7723840"><img align="left" alt="Ukraina schodzi pod ziemię. Nie wszyscy są zadowoleni" src="https://i.iplsc.com/ukraina-schodzi-pod-ziemie-nie-wszyscy-sa-zadowoleni/000JJ1GL3EQG5B4Q-C321.jpg" /></a>W Ukrainie są dzieci, które nie były w szkole od czterech lat. Najpierw nauczanie zdalne wymusiła pandemia, a potem nastały czasy pełnoskalowej wojny. Wedle prawa, zajęcia stacjonarne mogą prowadzić placówki wyposażone w schron. Wiele placówek nie jest w stanie go wypełnić choćby z braku piwnic. A konieczność zejścia pod ziemię nie dotyczy tylko instytucji edukacyjnych. Szpitale również należą do grona potencjalnych celów rosyjskich ataków.</p><br clear="all" />

## Niecodzienne sceny w Sejmie. Posłowie wstali i zaczęli śpiewać
 - [https://wydarzenia.interia.pl/kraj/news-niecodzienne-sceny-w-sejmie-poslowie-wstali-i-zaczeli-spiewa,nId,7723815](https://wydarzenia.interia.pl/kraj/news-niecodzienne-sceny-w-sejmie-poslowie-wstali-i-zaczeli-spiewa,nId,7723815)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T17:12:08+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niecodzienne-sceny-w-sejmie-poslowie-wstali-i-zaczeli-spiewa,nId,7723815"><img align="left" alt="Niecodzienne sceny w Sejmie. Posłowie wstali i zaczęli śpiewać" src="https://i.iplsc.com/niecodzienne-sceny-w-sejmie-poslowie-wstali-i-zaczeli-spiewa/000JJ1HW3SQBE38X-C321.jpg" /></a>Piątkowe obrady Sejmu zbiegły się z rozpoczęciem igrzysk olimpijskich w Paryżu. W pewnym momencie na mównicę wszedł poseł Polski 2050-Trzeciej Drogi Tomasz Zimoch, który złożył niespodziewany wniosek, &quot;by najbliższe 16 dni było bez polityki&quot;. Później parlamentarzyści zaskoczyli jeszcze bardziej i na stojąco odśpiewali znaną z aren sportowych przyśpiewkę.</p><br clear="all" />

## Użycie broni na granicy. Jest ostateczna decyzja Sejmu
 - [https://wydarzenia.interia.pl/kraj/news-uzycie-broni-na-granicy-jest-ostateczna-decyzja-sejmu,nId,7723627](https://wydarzenia.interia.pl/kraj/news-uzycie-broni-na-granicy-jest-ostateczna-decyzja-sejmu,nId,7723627)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T15:43:09+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-uzycie-broni-na-granicy-jest-ostateczna-decyzja-sejmu,nId,7723627"><img align="left" alt="Użycie broni na granicy. Jest ostateczna decyzja Sejmu" src="https://i.iplsc.com/uzycie-broni-na-granicy-jest-ostateczna-decyzja-sejmu/000GDJY4YCVFG1QO-C321.jpg" /></a>Sejm zdecydował o przyjęciu niektórych poprawek Senatu do ustawy o wsparciu działań żołnierzy i funkcjonariuszy. Nowe regulacje dotyczą m.in. prawa do użycia broni. </p><br clear="all" />

## "Nie spotkałem się z takim przypadkiem". Ekspert o śmierci Jacka Jaworka
 - [https://wydarzenia.interia.pl/slaskie/news-nie-spotkalem-sie-z-takim-przypadkiem-ekspert-o-smierci-jack,nId,7723632](https://wydarzenia.interia.pl/slaskie/news-nie-spotkalem-sie-z-takim-przypadkiem-ekspert-o-smierci-jack,nId,7723632)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T15:21:37+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-nie-spotkalem-sie-z-takim-przypadkiem-ekspert-o-smierci-jack,nId,7723632"><img align="left" alt="&quot;Nie spotkałem się z takim przypadkiem&quot;. Ekspert o śmierci Jacka Jaworka" src="https://i.iplsc.com/nie-spotkalem-sie-z-takim-przypadkiem-ekspert-o-smierci-jack/000JJ0WDFSQCHEIE-C321.jpg" /></a>- Przez 30 lat pracy w policji nie spotkałem się z takim przypadkiem - przyznał inspektor Marek Dyjasz, odnosząc się do śmierci Jacka Jaworka. Były dyrektor Biura Kryminalnego Komendy Głównej Policji podkreślił, że odebranie sobie życia poprzez strzał w głowę jest &quot;bardzo rzadkie&quot;. Ponadto inspektor wymienił kilka czynników, które - jego zdaniem - pozwoliły Jaworkowi pozostać nieuchwytnym przez trzy lata.</p><br clear="all" />

## Mniej niż połowa Polaków poszłaby na wybory. Najnowszy sondaż
 - [https://wydarzenia.interia.pl/kraj/news-mniej-niz-polowa-polakow-poszlaby-na-wybory-najnowszy-sondaz,nId,7723620](https://wydarzenia.interia.pl/kraj/news-mniej-niz-polowa-polakow-poszlaby-na-wybory-najnowszy-sondaz,nId,7723620)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T14:58:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mniej-niz-polowa-polakow-poszlaby-na-wybory-najnowszy-sondaz,nId,7723620"><img align="left" alt="Mniej niż połowa Polaków poszłaby na wybory. Najnowszy sondaż" src="https://i.iplsc.com/mniej-niz-polowa-polakow-poszlaby-na-wybory-najnowszy-sondaz/000JJ0USVSFRLNHJ-C321.jpg" /></a>Z najnowszego sondażu IBRiS wynika, że wiodące w Polsce partie, czyli KO i PiS otrzymałyby znacząco mniej poparcia niż w ostatnich miesiącach. Mocny wzrost odnotowała z kolei Konfederacja, która już utrzymuje się na podium. Niepokojąco maleje zainteresowanie udziałem w wyborach. Do urn - według badania - poszłoby mniej niż 50 proc. Polaków.</p><br clear="all" />

## Niezwykłe zdjęcia z Powstania Warszawskiego. "Zaskakująca selekcja"
 - [https://wydarzenia.interia.pl/kraj/news-niezwykle-zdjecia-z-powstania-warszawskiego-zaskakujaca-sele,nId,7723612](https://wydarzenia.interia.pl/kraj/news-niezwykle-zdjecia-z-powstania-warszawskiego-zaskakujaca-sele,nId,7723612)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T14:54:25+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niezwykle-zdjecia-z-powstania-warszawskiego-zaskakujaca-sele,nId,7723612"><img align="left" alt="Niezwykłe zdjęcia z Powstania Warszawskiego. &quot;Zaskakująca selekcja&quot;" src="https://i.iplsc.com/niezwykle-zdjecia-z-powstania-warszawskiego-zaskakujaca-sele/000JJ0UWWUGTRCE1-C321.jpg" /></a>100 pokolorowanych fotografii z Powstania Warszawskiego, cytaty Powstańców, przejmujące historie, rozpoznane budynki i adresy - to wszystko czeka na odbiorców w najnowszej publikacji Muzeum Powstania Warszawskiego - albumie  &quot;Kolor Powstania 1944. Zdjęcia walczącej Warszawy&quot;. Dzień przed 80. rocznicą wybuchu Powstania Warszawskiego w Łazienkach Królewskich premierę będzie miała wystawa plenerowa &quot;Kolor Powstania 1944&quot;.</p><br clear="all" />

## Bulwersujące hasła wobec Tuska i Bodnara. Zatrzymano podejrzanego
 - [https://wydarzenia.interia.pl/wielkopolskie/news-bulwersujace-hasla-wobec-tuska-i-bodnara-zatrzymano-podejrza,nId,7723603](https://wydarzenia.interia.pl/wielkopolskie/news-bulwersujace-hasla-wobec-tuska-i-bodnara-zatrzymano-podejrza,nId,7723603)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T14:40:30+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-bulwersujace-hasla-wobec-tuska-i-bodnara-zatrzymano-podejrza,nId,7723603"><img align="left" alt="Bulwersujące hasła wobec Tuska i Bodnara. Zatrzymano podejrzanego" src="https://i.iplsc.com/bulwersujace-hasla-wobec-tuska-i-bodnara-zatrzymano-podejrza/000JJ0SO0HGSMT9T-C321.jpg" /></a>Policja zatrzymała 61-latka podejrzanego o namalowanie bulwersujących haseł - odnoszących się do Donalda Tuska i Adama Bodnara - na ścieżce pieszo-rowerowej w Kaliszu. Mężczyzna usłyszał zarzut nawoływania do popełnienia zbrodni. Podejrzany, któremu grozi do trzech lat pozbawienia wolności, nie przyznał się do zarzutu. Wobec 61-latka zastosowano środek zapobiegawczy.</p><br clear="all" />

## Dramatyczny finał kłótni w parku. Bracia trafili do szpitala
 - [https://wydarzenia.interia.pl/lubuskie/news-dramatyczny-final-klotni-w-parku-bracia-trafili-do-szpitala,nId,7723339](https://wydarzenia.interia.pl/lubuskie/news-dramatyczny-final-klotni-w-parku-bracia-trafili-do-szpitala,nId,7723339)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T13:06:38+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-dramatyczny-final-klotni-w-parku-bracia-trafili-do-szpitala,nId,7723339"><img align="left" alt="Dramatyczny finał kłótni w parku. Bracia trafili do szpitala" src="https://i.iplsc.com/dramatyczny-final-klotni-w-parku-bracia-trafili-do-szpitala/000JIZV3ULFEQH7M-C321.jpg" /></a>Najpierw rozpętała się awantura, później w ruch poszły młotek i nóż. Hospitalizacją dwóch osób zakończyła się czwartkowa bójka w parku w Zielonej Górze. Policja informuje, że uczestniczyły w niej młode osoby, wśród których trzy - po krótkiej obławie - zostały zatrzymane.</p><br clear="all" />

## Dramatyczny finał kłótni w parku. Dwie osoby ugodzone nożem
 - [https://wydarzenia.interia.pl/lubuskie/news-dramatyczny-final-klotni-w-parku-dwie-osoby-ugodzone-nozem,nId,7723339](https://wydarzenia.interia.pl/lubuskie/news-dramatyczny-final-klotni-w-parku-dwie-osoby-ugodzone-nozem,nId,7723339)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T13:06:38+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-dramatyczny-final-klotni-w-parku-dwie-osoby-ugodzone-nozem,nId,7723339"><img align="left" alt="Dramatyczny finał kłótni w parku. Dwie osoby ugodzone nożem" src="https://i.iplsc.com/dramatyczny-final-klotni-w-parku-dwie-osoby-ugodzone-nozem/000JIZV3ULFEQH7M-C321.jpg" /></a>Najpierw rozpętała się awantura, później w ruch poszły młotek i nóż. Hospitalizacją dwóch osób zakończyła się czwartkowa bójka w parku w Zielonej Górze. Policja informuje, że uczestniczyły w niej młode osoby, wśród których trzy - po krótkiej obławie - zostały zatrzymane.</p><br clear="all" />

## Lewica się nie poddaje. Jest kolejny projekt ws. aborcji
 - [https://wydarzenia.interia.pl/kraj/news-lewica-sie-nie-poddaje-jest-kolejny-projekt-ws-aborcji,nId,7723278](https://wydarzenia.interia.pl/kraj/news-lewica-sie-nie-poddaje-jest-kolejny-projekt-ws-aborcji,nId,7723278)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T12:11:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-lewica-sie-nie-poddaje-jest-kolejny-projekt-ws-aborcji,nId,7723278"><img align="left" alt="Lewica się nie poddaje. Jest kolejny projekt ws. aborcji" src="https://i.iplsc.com/lewica-sie-nie-poddaje-jest-kolejny-projekt-ws-aborcji/000JIZHM6W3N4KIV-C321.jpg" /></a>Do Sejmu wpłynął kolejny projekt nowelizacji dotyczący aborcji. Zakłada on m.in. częściową dekryminalizację przerywania ciąży, jeśli kobieta wyraziła na to zgodę. Pod projektem podpisy złożyli posłowie Lewicy, KO, a także kilku z Trzeciej Drogi. &quot;Czas wdrożyć nasze wspólne ustalenia kolacyjne w życie&quot; - ocenia minister ds. równości Katarzyna Kotula.</p><br clear="all" />

## PiS czeka na kluczowy dzień. "Otworzą się bramy piekła"
 - [https://wydarzenia.interia.pl/kraj/news-pkw-odbierze-dotacje-pis-wyglada-to-jak-szukanie-hakow,nId,7723268](https://wydarzenia.interia.pl/kraj/news-pkw-odbierze-dotacje-pis-wyglada-to-jak-szukanie-hakow,nId,7723268)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T12:05:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pkw-odbierze-dotacje-pis-wyglada-to-jak-szukanie-hakow,nId,7723268"><img align="left" alt="PiS czeka na kluczowy dzień. &quot;Otworzą się bramy piekła&quot;" src="https://i.iplsc.com/pis-czeka-na-kluczowy-dzien-otworza-sie-bramy-piekla/000JIZG7S5CBINQS-C321.jpg" /></a>Już nie Fundusz Sprawiedliwości, a tzw. pikniki 800 plus mają znajdować się pod lupą Państwowej Komisji Wyborczej, która ciągle przygląda się sprawozdaniu finansowemu Prawa i Sprawiedliwości oraz innych formacji. Decyzja dotycząca dotacji ma zapaść do końca miesiąca. Partia Jarosława Kaczyńskiego patrzy na sprawę z drżeniem serca. </p><br clear="all" />

## Weekend w Polsce z niebezpieczną aurą. W pogodzie znów zrobi się groźnie
 - [https://wydarzenia.interia.pl/kraj/news-weekend-w-polsce-z-niebezpieczna-aura-w-pogodzie-znow-zrobi-,nId,7723245](https://wydarzenia.interia.pl/kraj/news-weekend-w-polsce-z-niebezpieczna-aura-w-pogodzie-znow-zrobi-,nId,7723245)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T11:37:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-weekend-w-polsce-z-niebezpieczna-aura-w-pogodzie-znow-zrobi-,nId,7723245"><img align="left" alt="Weekend w Polsce z niebezpieczną aurą. W pogodzie znów zrobi się groźnie" src="https://i.iplsc.com/weekend-w-polsce-z-niebezpieczna-aura-w-pogodzie-znow-zrobi/000JIZF7GA072O9A-C321.jpg" /></a>Po chwili oddechu od upałów do kraju wracają nie tylko wysokie temperatury, ale i burze niosące ze sobą gwałtowne zjawiska atmosferyczne. IMGW wystosowało przed weekendem alert, który z czasem może objąć kolejne województwa. W najbliższych dobach wyż Gustaw ustąpi miejsca problematycznym frontom. </p><br clear="all" />

## Jarosław Kaczyński o wyborach prezydenckich. Ma więcej niż sześciu kandydatów
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-o-wyborach-prezydenckich-ma-wiecej-niz-sz,nId,7723249](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-o-wyborach-prezydenckich-ma-wiecej-niz-sz,nId,7723249)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T11:21:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-o-wyborach-prezydenckich-ma-wiecej-niz-sz,nId,7723249"><img align="left" alt="Jarosław Kaczyński o wyborach prezydenckich. Ma więcej niż sześciu kandydatów" src="https://i.iplsc.com/jaroslaw-kaczynski-o-wyborach-prezydenckich-ma-wiecej-niz-sz/000JIZ8R92F34A3K-C321.jpg" /></a>Jarosław Kaczyński przekazał dziennikarzom, że lista potencjalnych kandydatów PiS w przyszłorocznych wyborach prezydenckich liczy więcej niż sześć nazwisk. - Nie jest jeszcze taka krótka - podkreślił były premier. Kaczyński zaznaczył, że decyzja nie będzie podejmowana jednoosobowo.</p><br clear="all" />

## Urlop może zakończyć się poważnym problemem. Policja ostrzega
 - [https://wydarzenia.interia.pl/kraj/news-urlop-moze-zakonczyc-sie-powaznym-problemem-policja-ostrzega,nId,7701341](https://wydarzenia.interia.pl/kraj/news-urlop-moze-zakonczyc-sie-powaznym-problemem-policja-ostrzega,nId,7701341)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T10:53:22+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-urlop-moze-zakonczyc-sie-powaznym-problemem-policja-ostrzega,nId,7701341"><img align="left" alt="Urlop może zakończyć się poważnym problemem. Policja ostrzega " src="https://i.iplsc.com/urlop-moze-zakonczyc-sie-powaznym-problemem-policja-ostrzega/000JIZ1UWE8X2F0P-C321.jpg" /></a>Potrafią miesiącami obserwować tryb życia domowników i doskonale ocenić, kiedy nikogo nie ma w domu. Jak przed wyjazdem na urlop zabezpieczyć mieszkanie, by nie stało się łatwym łupem dla włamywaczy? Policja ma kilka praktycznych porad.  </p><br clear="all" />

## Wypadek podczas pościgu w Szczecinie. Radiowóz zderzył się z autobusem
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-wypadek-podczas-poscigu-w-szczecinie-radiowoz-zderzyl-sie-z-,nId,7723229](https://wydarzenia.interia.pl/zachodniopomorskie/news-wypadek-podczas-poscigu-w-szczecinie-radiowoz-zderzyl-sie-z-,nId,7723229)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T10:50:24+00:00

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-wypadek-podczas-poscigu-w-szczecinie-radiowoz-zderzyl-sie-z-,nId,7723229"><img align="left" alt="Wypadek podczas pościgu w Szczecinie. Radiowóz zderzył się z autobusem" src="https://i.iplsc.com/wypadek-podczas-poscigu-w-szczecinie-radiowoz-zderzyl-sie-z/000G336ZOXNE4CEX-C321.jpg" /></a>W Szczecinie doszło do zderzenia radiowozu policji z autobusem komunikacji miejskiej. Rannych zostało dziewięć osób, w tym dwóch mundurowych. Jak ustaliła Interia, funkcjonariusze uczestniczyli w pościgu za kierowcą osobowego auta, który wcześniej nie zatrzymał się do kontroli.</p><br clear="all" />

## Wielka awantura na pokładzie. Samolot musiał lądować w Modlinie
 - [https://wydarzenia.interia.pl/kraj/news-wielka-awantura-na-pokladzie-samolot-musial-ladowac-w-modlin,nId,7723190](https://wydarzenia.interia.pl/kraj/news-wielka-awantura-na-pokladzie-samolot-musial-ladowac-w-modlin,nId,7723190)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T10:36:53+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wielka-awantura-na-pokladzie-samolot-musial-ladowac-w-modlin,nId,7723190"><img align="left" alt="Wielka awantura na pokładzie. Samolot musiał lądować w Modlinie" src="https://i.iplsc.com/wielka-awantura-na-pokladzie-samolot-musial-ladowac-w-modlin/000JIZ2AAM8C28X3-C321.jpg" /></a>Był nietrzeźwy, wulgarny i nie słuchał się załogi. Zachowanie 45-latka z Litwy sprawiło, że samolot lecący z Londynu do Kowna musiał nieplanowo lądować w porcie Warszawa-Modlin. Agresja u pasażera nie zmalała nawet, gdy do maszyny wkroczyli strażnicy graniczni.</p><br clear="all" />

## Komunikat wojska dotyczy całej Polski. "Będzie nas słychać"
 - [https://wydarzenia.interia.pl/kraj/news-komunikat-wojska-dotyczy-calej-polski-bedzie-nas-slychac,nId,7723095](https://wydarzenia.interia.pl/kraj/news-komunikat-wojska-dotyczy-calej-polski-bedzie-nas-slychac,nId,7723095)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T08:29:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-komunikat-wojska-dotyczy-calej-polski-bedzie-nas-slychac,nId,7723095"><img align="left" alt="Komunikat wojska dotyczy całej Polski. &quot;Będzie nas słychać&quot;" src="https://i.iplsc.com/komunikat-wojska-dotyczy-calej-polski-bedzie-nas-slychac/000JIYATP7TJAT8Q-C321.jpg" /></a>Rozpoczęła się kolejna edycja polsko-amerykańskich ćwiczeń Aviation Detachment Rotation. Wojskowi z obu państw będą m.in. doskonalić procedury powiązane z wykorzystaniem myśliwców F-16. W związku z tym polska armia przestrzegła mieszkańców wszystkich województw, że powietrzne manewry będą dość głośne.</p><br clear="all" />

## Szczepan Twardoch: Zmieni się prezydent, zmieni się sytuacja
 - [https://wydarzenia.interia.pl/kultura/news-szczepan-twardoch-zmieni-sie-prezydent-zmieni-sie-sytuacja,nId,7711542](https://wydarzenia.interia.pl/kultura/news-szczepan-twardoch-zmieni-sie-prezydent-zmieni-sie-sytuacja,nId,7711542)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T08:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kultura/news-szczepan-twardoch-zmieni-sie-prezydent-zmieni-sie-sytuacja,nId,7711542"><img align="left" alt="Szczepan Twardoch: Zmieni się prezydent, zmieni się sytuacja" src="https://i.iplsc.com/szczepan-twardoch-zmieni-sie-prezydent-zmieni-sie-sytuacja/000JIQPKQLVJ4YHK-C321.jpg" /></a>- Kwestia śląskiej tożsamości została wciągnięta w wojnę koalicji z PiS-em - stwierdził Szczepan Twardoch, gość Piotra Witwickiego w podcaście video &quot;Bez uników&quot;. Skomentował w ten sposób weto prezydenta Andrzeja Dudy do ustawy o języku śląskim. Pisarz mówił też o swoich twórczych mękach. - Pisanie przychodzi mi z wielkim trudem. I jest to czynność bardzo żmudna i męcząca. Nie lubię tego - przyznał.</p><br clear="all" />

## Roman Giertych chce "skończyć KRS". Wskazał na powiązania z Rosją
 - [https://wydarzenia.interia.pl/kraj/news-roman-giertych-chce-skonczyc-krs-wskazal-na-powiazania-z-ros,nId,7723025](https://wydarzenia.interia.pl/kraj/news-roman-giertych-chce-skonczyc-krs-wskazal-na-powiazania-z-ros,nId,7723025)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T07:08:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-roman-giertych-chce-skonczyc-krs-wskazal-na-powiazania-z-ros,nId,7723025"><img align="left" alt="Roman Giertych chce &quot;skończyć KRS&quot;. Wskazał na powiązania z Rosją" src="https://i.iplsc.com/roman-giertych-chce-skonczyc-krs-wskazal-na-powiazania-z-ros/000JIXVLKHSLJ0BM-C321.jpg" /></a>Roman Giertych zamierza &quot;skończyć sprawę KRS&quot;. - Mamy podejrzenia, że te osoby świadomie lub nie współpracowały ze szpiegiem rosyjskim - stwierdził o zasiadających tam sędziach. Szef zespołu ds. rozliczeń PiS odniósł się też do przyszłorocznych wyborów prezydenckich. Giertych nie krył, że ma już swojego potencjalnego faworyta w wyścigu o to stanowisko. </p><br clear="all" />

## Sąsiad Polski ma dość. "Staliśmy się zakładnikiem Ukrainy i KE"
 - [https://wydarzenia.interia.pl/zagranica/news-sasiad-polski-ma-dosc-stalismy-sie-zakladnikiem-ukrainy-i-ke,nId,7721613](https://wydarzenia.interia.pl/zagranica/news-sasiad-polski-ma-dosc-stalismy-sie-zakladnikiem-ukrainy-i-ke,nId,7721613)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-26T04:20:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sasiad-polski-ma-dosc-stalismy-sie-zakladnikiem-ukrainy-i-ke,nId,7721613"><img align="left" alt="Sąsiad Polski ma dość. &quot;Staliśmy się zakładnikiem Ukrainy i KE&quot;" src="https://i.iplsc.com/sasiad-polski-ma-dosc-stalismy-sie-zakladnikiem-ukrainy-i-ke/000JIWOZAYY198E8-C321.jpg" /></a>Słowacja wezwała Komisję Europejską, aby nie opóźniała decyzji w sprawie złożonego wspólnie z Węgrami wniosku o mediacje z Ukrainą. Chodzi o zakłócenia w przepływie ropy naftowej z Rosji. Za sprawą sankcji nałożonych przez Ukrainę na koncern Łukoil wstrzymane zostały dostawy rosyjskiej ropy do słowackich i węgierskich rafinerii.</p><br clear="all" />

