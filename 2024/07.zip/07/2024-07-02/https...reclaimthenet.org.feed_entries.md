# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed, language:en-US

## X Re-Joins Pro-Censorship Advertisers’ Alliance
 - [https://reclaimthenet.org/x-re-joins-pro-censorship-advertisers-alliance](https://reclaimthenet.org/x-re-joins-pro-censorship-advertisers-alliance)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-07-02T19:45:17+00:00

<a href="https://reclaimthenet.org/x-re-joins-pro-censorship-advertisers-alliance" rel="nofollow" title="X Re-Joins Pro-Censorship Advertisers&#8217; Alliance"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/07/x-garm-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Despite Twitter Files' revelations on censorship, X rejoins the pro-censorship GARM.</p>
<p>The post <a href="https://reclaimthenet.org/x-re-joins-pro-censorship-advertisers-alliance">X Re-Joins Pro-Censorship Advertisers&#8217; Alliance</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## The Dark Side of Wi-Fi Positioning: How Our Gadgets Became Silent Stalkers
 - [https://reclaimthenet.org/the-dark-side-of-wi-fi-positioning-how-our-gadgets-became-silent-stalkers](https://reclaimthenet.org/the-dark-side-of-wi-fi-positioning-how-our-gadgets-became-silent-stalkers)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-07-02T19:43:06+00:00

<a href="https://reclaimthenet.org/the-dark-side-of-wi-fi-positioning-how-our-gadgets-became-silent-stalkers" rel="nofollow" title="The Dark Side of Wi-Fi Positioning: How Our Gadgets Became Silent Stalkers"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/07/wif-w-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>While enhancing navigation accuracy, WiFi Positioning Systems' extensive data collection poses significant risks for user privacy and potential misuse by unauthorized entities.</p>
<p>The post <a href="https://reclaimthenet.org/the-dark-side-of-wi-fi-positioning-how-our-gadgets-became-silent-stalkers">The Dark Side of Wi-Fi Positioning: How Our Gadgets Became Silent Stalkers</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Meta’s Oversight Board Is Helping Big Tech Companies Comply With the EU’s Censorship Law
 - [https://reclaimthenet.org/metas-oversight-board-is-helping-big-tech-companies-comply-with-the-eus-censorship-law](https://reclaimthenet.org/metas-oversight-board-is-helping-big-tech-companies-comply-with-the-eus-censorship-law)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-07-02T19:39:53+00:00

<a href="https://reclaimthenet.org/metas-oversight-board-is-helping-big-tech-companies-comply-with-the-eus-censorship-law" rel="nofollow" title="Meta’s Oversight Board Is Helping Big Tech Companies Comply With the EU’s Censorship Law"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/07/meta3-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Meta's Oversight Board eyes the EU's Digital Services Act as a potential funding source to continue its contentious content moderation efforts.</p>
<p>The post <a href="https://reclaimthenet.org/metas-oversight-board-is-helping-big-tech-companies-comply-with-the-eus-censorship-law">Meta’s Oversight Board Is Helping Big Tech Companies Comply With the EU’s Censorship Law</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## European Council Makes Countering “Disinformation and Hate Speech” Part of Its Strategic Agenda
 - [https://reclaimthenet.org/european-council-makes-countering-disinformation-and-hate-speech-part-of-its-strategic-agenda](https://reclaimthenet.org/european-council-makes-countering-disinformation-and-hate-speech-part-of-its-strategic-agenda)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-07-02T17:37:21+00:00

<a href="https://reclaimthenet.org/european-council-makes-countering-disinformation-and-hate-speech-part-of-its-strategic-agenda" rel="nofollow" title="European Council Makes Countering “Disinformation and Hate Speech” Part of Its Strategic Agenda"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/07/eu-cs-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>New agenda. New censorship concerns.</p>
<p>The post <a href="https://reclaimthenet.org/european-council-makes-countering-disinformation-and-hate-speech-part-of-its-strategic-agenda">European Council Makes Countering “Disinformation and Hate Speech” Part of Its Strategic Agenda</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Supreme Court To Hear Challenge To Texas’ Online Digital ID Mandate
 - [https://reclaimthenet.org/supreme-court-to-hear-challenge-to-texas-online-digital-id-mandate](https://reclaimthenet.org/supreme-court-to-hear-challenge-to-texas-online-digital-id-mandate)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-07-02T16:29:33+00:00

<a href="https://reclaimthenet.org/supreme-court-to-hear-challenge-to-texas-online-digital-id-mandate" rel="nofollow" title="Supreme Court To Hear Challenge To Texas&#8217; Online Digital ID Mandate"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/07/sup-c-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Legal challenge argues First Amendment infringement and raises privacy concerns over mandatory personal data disclosure.</p>
<p>The post <a href="https://reclaimthenet.org/supreme-court-to-hear-challenge-to-texas-online-digital-id-mandate">Supreme Court To Hear Challenge To Texas&#8217; Online Digital ID Mandate</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

