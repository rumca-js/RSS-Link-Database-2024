# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## Democrats begin attacking Biden’s performance and campaign
 - [https://www.politico.com/news/2024/07/02/democrats-biden-debate-fallout-00166208?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/07/02/democrats-biden-debate-fallout-00166208?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T21:40:35+00:00

Rep. Lloyd Doggett (D-Texas) said the president needs to step aside and usher in a “new generation of leaders.”

## Hungary’s Orbán plays peacemaker in Ukraine
 - [https://www.politico.eu/article/hungary-viktor-orban-ukraine-volodymyr-zelenskyy-war-in-ukraine-peace-talks-ceasefire-negotiations-diplomacy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/hungary-viktor-orban-ukraine-volodymyr-zelenskyy-war-in-ukraine-peace-talks-ceasefire-negotiations-diplomacy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T18:19:00+00:00

The Hungarian premier visited Kyiv on the second day of Budapest's turn at the helm of the Council of the EU.

## French election: Rivals unite against Le Pen’s far right
 - [https://www.politico.eu/article/french-election-marine-le-pen-far-right-national-rally/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/french-election-marine-le-pen-far-right-national-rally/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T17:31:17+00:00

Hundreds of candidates from Macron's camp and the left-wing alliance withdraw in an effort to keep the National Rally out.

## The Netherlands has a new government. Here are 3 things to know.
 - [https://www.politico.eu/article/netherlands-right-wing-government-dick-schoof-mark-rutte-party-for-freedom/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/netherlands-right-wing-government-dick-schoof-mark-rutte-party-for-freedom/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T17:08:48+00:00

After the far right won the most votes, it's now also a powerful force in the Dutch government.

## No more Kanye East? Russian orthodox group wants US rapper banned
 - [https://www.politico.eu/article/no-more-kanye-east-russian-orthodox-group-wants-the-us-rapper-banned-2/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/no-more-kanye-east-russian-orthodox-group-wants-the-us-rapper-banned-2/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T17:00:54+00:00

Far-right activists say Hitler-endorsing rapper should be permanently barred from Russia for "supporting Ukraine."

## Poland’s Tusk rails at fractured defense planning in jibe at Germany’s Scholz
 - [https://www.politico.eu/article/poland-donald-tusk-germany-olaf-scholz-defense-spending-planning-cooperation/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/poland-donald-tusk-germany-olaf-scholz-defense-spending-planning-cooperation/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T14:52:35+00:00

Germany is skeptical of common borrowing for defense; Poland wants it.

## ‘We’ve all enabled the situation’: Democrats turn on Biden’s inner sanctum post debate
 - [https://www.politico.com/news/2024/07/02/biden-campaign-debate-inner-circle-00166160?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/07/02/biden-campaign-debate-inner-circle-00166160?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T13:54:24+00:00

The senior team’s management of Biden has grown more strictly controlled as his term has gone on.

## Nigel Farage suffers new blow as bigotry storm engulfs his party just before UK election
 - [https://www.politico.eu/article/nigel-farages-party-accused-racism-misogyny-by-former-election-candidate/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/nigel-farages-party-accused-racism-misogyny-by-former-election-candidate/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T13:53:37+00:00

Candidate defects to the Tories saying "vast majority" of people standing for Reform UK are "racist, misogynistic, and bigoted."

## Germany’s Scholz fails to announce compensation plan for Polish survivors of Nazi crimes
 - [https://www.politico.eu/article/germany-poland-fail-agree-compensation-for-survivor-of-nazi-crimes-olof-scholz-donald-tusk/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/germany-poland-fail-agree-compensation-for-survivor-of-nazi-crimes-olof-scholz-donald-tusk/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T13:01:24+00:00

The failure to reach an agreement is a major setback for the German and Polish leaders as they try to mend relations.

## Le Pen accuses Macron of ‘administrative coup’
 - [https://www.politico.eu/article/far-right-marine-le-pen-accuses-emmanuel-macron-of-administrative-coup-detat-job-appointments/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/far-right-marine-le-pen-accuses-emmanuel-macron-of-administrative-coup-detat-job-appointments/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T10:52:53+00:00

As French president pushes through key high-ranking government appointments.

## ‘Build a wall’ in the English Channel to deal with migrants, says Conservative darling
 - [https://www.politico.eu/article/build-a-wall-in-the-english-channel-to-deal-with-migrants-says-tory-darling-jacob-rees-mogg/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/build-a-wall-in-the-english-channel-to-deal-with-migrants-says-tory-darling-jacob-rees-mogg/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T10:29:59+00:00

Uber-Tory Jacob Rees-Mogg takes page from Donald Trump's playbook.

## French far-right candidate withdraws from race after Nazi costume controversy
 - [https://www.politico.eu/article/french-far-right-candidate-withdraws-from-race-after-nazi-costume-controversy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/french-far-right-candidate-withdraws-from-race-after-nazi-costume-controversy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T10:06:56+00:00

The National Rally candidate "does not deny" wearing a cap emblazoned with a swastika.

## Labour and Conservatives look to the future
 - [https://www.politico.eu/podcast/politics-at-jack-and-sams/labour-and-conservatives-look-to-the-future/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/podcast/politics-at-jack-and-sams/labour-and-conservatives-look-to-the-future/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T08:06:55+00:00

This is day 41 of the campaign. Jack and Sam look at Labour’s preparation for government, the Conservative Party preparing for the election fallout, and the problem with some postal votes. 👉 Tap here to follow Politics at Jack and Sam’s wherever you get your podcasts 👈 Email Jack and Sam: jackandsam@sky.uk

## Viktor Orbán arrives in Ukraine to meet Zelenskyy
 - [https://www.politico.eu/article/hungary-viktor-orban-arrive-ukraine-meet-volodymyr-zelenskyy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/hungary-viktor-orban-arrive-ukraine-meet-volodymyr-zelenskyy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T07:18:31+00:00

It's the first visit by the Hungarian PM to the war-struck country since Russia invaded in February 2022.

## Wie Deutschland das Verhältnis mit Polen kitten will
 - [https://www.politico.eu/podcast/berlin-playbook-podcast/wie-deutschland-das-verhaltnis-mit-polen-kitten-will/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/podcast/berlin-playbook-podcast/wie-deutschland-das-verhaltnis-mit-polen-kitten-will/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T03:00:00+00:00

Der Kanzler und seine Minister wollen in Warschau ein Comeback der deutsch-polnischen Beziehungen besiegeln. Unter anderem mit Außenministerin Annalena Baerbock, Wirtschaftsminister Robert Habeck und Finanzminister Christian Lindner ist er zu gemeinsamen Regierungskonsultationen gereist. Es sind die ersten seit mehreren Jahren. Mit welchen Angeboten Scholz und die Ampel die Beziehungen wiederbeleben wollen und was das auch […]

## Now what? Here are the next moves for all the key players after the Trump immunity ruling
 - [https://www.politico.com/news/2024/07/01/trump-federal-election-subversion-case-future-00166156?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/07/01/trump-federal-election-subversion-case-future-00166156?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T02:40:49+00:00

Judge Tanya Chutkan, special counsel Jack Smith, and Donald Trump’s lawyers have big decisions to make after the immunity ruling.

## Five simple steps to deceiving your way to Downing Street
 - [https://www.politico.eu/article/rishi-sunak-keir-starmer-labour-tory-downing-street-campaign-uk-election/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/rishi-sunak-keir-starmer-labour-tory-downing-street-campaign-uk-election/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T02:02:00+00:00

From dodgy data to flagrant fibs, POLITICO has the inside track on how politicians are scheming to win votes at the U.K. general election.

## Calais’ Jungle is gone, but the migrants keep coming
 - [https://www.politico.eu/article/calais-jungle-gone-migrants-far-right-english-channel-cross-united-kingdom-france/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/calais-jungle-gone-migrants-far-right-english-channel-cross-united-kingdom-france/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T02:01:00+00:00

French and British efforts to stop small boats have done little to prevent migrants from crossing the Channel.

## Nigel Farage battles the hard right’s fatal flaw
 - [https://www.politico.eu/article/what-the-nationalist-right-gets-wrong/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/what-the-nationalist-right-gets-wrong/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T02:01:00+00:00

Europe's nationalists have often struggled to field a clean sheet of respectable candidates.

## Starmer will have to walk a US-China tightrope
 - [https://www.politico.eu/article/keir-starmer-labour-party-united-states-china-donald-trump-trade-economy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/keir-starmer-labour-party-united-states-china-donald-trump-trade-economy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-07-02T02:00:00+00:00

There's already some discord between the two countries when it comes to China, but there are areas where they could work on similar approaches.

