# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Austria vs Turkey: Score and latest updates from Euro 2024
 - [https://www.telegraph.co.uk/football/2024/07/02/austria-vs-turkey-live-score-latest-updates-euro-2024](https://www.telegraph.co.uk/football/2024/07/02/austria-vs-turkey-live-score-latest-updates-euro-2024)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T17:44:23+00:00



## Tuesday evening news briefing: Sir Geoffrey Boycott reveals cancer diagnosis
 - [https://www.telegraph.co.uk/news/2024/07/02/tuesday-evening-news-briefing-sir-geoffrey-boycott-cancer](https://www.telegraph.co.uk/news/2024/07/02/tuesday-evening-news-briefing-sir-geoffrey-boycott-cancer)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T16:51:09+00:00



## Jack Draper vs Elias Ymer: Score and latest updates from Wimbledon
 - [https://www.telegraph.co.uk/tennis/2024/07/02/jack-draper-vs-elias-ymer-live-score-wimbledon-2024-latest](https://www.telegraph.co.uk/tennis/2024/07/02/jack-draper-vs-elias-ymer-live-score-wimbledon-2024-latest)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T15:59:58+00:00



## What does resistance in occupied Ukraine look like? - Ukraine: The Latest, Podcast
 - [https://www.telegraph.co.uk/world-news/2024/07/02/russia-ukraine-occupation-resistance](https://www.telegraph.co.uk/world-news/2024/07/02/russia-ukraine-occupation-resistance)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T15:36:12+00:00



## Romania vs Netherlands live: Score and latest updates from Euro 2024
 - [https://www.telegraph.co.uk/football/2024/07/02/romania-vs-netherlands-live-score-euro-2024-latest-last-16](https://www.telegraph.co.uk/football/2024/07/02/romania-vs-netherlands-live-score-euro-2024-latest-last-16)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T15:02:06+00:00



## Tour de France 2023 route, teams and results after Jonas Vingegaard wins title
 - [https://www.telegraph.co.uk/cycling/2023/07/23/tour-de-france-2023-route-teams-and-how-to-watch-on-tv](https://www.telegraph.co.uk/cycling/2023/07/23/tour-de-france-2023-route-teams-and-how-to-watch-on-tv)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T14:53:29+00:00



## Could rodents help in the fight against tuberculosis?
 - [https://www.telegraph.co.uk/global-health/science-and-disease/tb-rats-could-rodents-help-in-fight-against-tuberculosis](https://www.telegraph.co.uk/global-health/science-and-disease/tb-rats-could-rodents-help-in-fight-against-tuberculosis)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T12:49:35+00:00



## Tour de France 2024: Latest updates from stage four as the riders take on the Galibier
 - [https://www.telegraph.co.uk/cycling/2024/07/02/tour-de-france-live-latest-updates-stage-four](https://www.telegraph.co.uk/cycling/2024/07/02/tour-de-france-live-latest-updates-stage-four)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T11:19:44+00:00



## Broccoli and goat’s curd pizzas recipe
 - [https://www.telegraph.co.uk/recipes/0/broccoli-and-goats-curd-pizzas-recipe](https://www.telegraph.co.uk/recipes/0/broccoli-and-goats-curd-pizzas-recipe)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T10:45:57+00:00



## Gorgonzola and caper frying-pan pizzas recipe
 - [https://www.telegraph.co.uk/recipes/0/gorgonzola-and-caper-frying-pan-pizzas-recipe](https://www.telegraph.co.uk/recipes/0/gorgonzola-and-caper-frying-pan-pizzas-recipe)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T10:40:32+00:00



## Chorizo, ’nduja and honey Detroit-style pizza recipe
 - [https://www.telegraph.co.uk/recipes/0/chorizo-nduja-and-honey-detroit-style-pizza-recipe](https://www.telegraph.co.uk/recipes/0/chorizo-nduja-and-honey-detroit-style-pizza-recipe)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T10:36:23+00:00



## Gardening jobs in July: what to plant and tidy in your garden this month
 - [https://www.telegraph.co.uk/gardening/how-to-grow/gardening-jobs-july-plant-tidy-garden-month](https://www.telegraph.co.uk/gardening/how-to-grow/gardening-jobs-july-plant-tidy-garden-month)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T09:35:10+00:00



## Andy Murray withdraws from Wimbledon singles – latest updates
 - [https://www.telegraph.co.uk/tennis/2024/07/02/wimbledon-2024-live-murray-updates-boulter-latest-score](https://www.telegraph.co.uk/tennis/2024/07/02/wimbledon-2024-live-murray-updates-boulter-latest-score)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T09:15:02+00:00



## Euro 2024 today: Including Romania vs Netherlands, TV channels, times and odds
 - [https://www.telegraph.co.uk/football/2024/07/02/euro-2024-guide-today-matches](https://www.telegraph.co.uk/football/2024/07/02/euro-2024-guide-today-matches)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T08:39:19+00:00



## Ukrainians return to shattered villages, to eke out lives in the shells of homes
 - [https://www.telegraph.co.uk/global-health/terror-and-security/bohorodychne-ukraine-russia-war-villages](https://www.telegraph.co.uk/global-health/terror-and-security/bohorodychne-ukraine-russia-war-villages)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T07:00:00+00:00



## 5,000 Ukrainian villagers urged to flee advancing Russian troops
 - [https://www.telegraph.co.uk/world-news/2024/07/02/ukraine-russia-war-latest-news10](https://www.telegraph.co.uk/world-news/2024/07/02/ukraine-russia-war-latest-news10)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T06:44:53+00:00



## The photo ID you need to vote in UK elections
 - [https://www.telegraph.co.uk/politics/2024/07/02/voter-id-need-vote-uk-local-general-elections](https://www.telegraph.co.uk/politics/2024/07/02/voter-id-need-vote-uk-local-general-elections)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T06:02:47+00:00



## General election latest: July 4 was ‘big gamble’ for Sunak and it hasn’t paid off, suggests ex-minister
 - [https://www.telegraph.co.uk/politics/2024/07/02/general-election-live-sunak-starmer-farage](https://www.telegraph.co.uk/politics/2024/07/02/general-election-live-sunak-starmer-farage)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-07-02T06:01:35+00:00



