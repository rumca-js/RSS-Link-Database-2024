# Source:Developer Tech News, URL:https://www.developer-tech.com/feed, language:en-GB

## CocoaPods flaws highlight growing supply chain risks
 - [https://www.developer-tech.com/news/2024/jul/02/cocoapods-flaws-highlight-growing-supply-chain-risks](https://www.developer-tech.com/news/2024/jul/02/cocoapods-flaws-highlight-growing-supply-chain-risks)
 - RSS feed: https://www.developer-tech.com/feed
 - date published: 2024-07-02T15:02:36+00:00

<p>Security researchers at E.V.A Information Security have uncovered several critical vulnerabilities in CocoaPods, a popular dependency manager for Swift and Objective-C projects. These vulnerabilities potentially expose millions of Apple devices to supply chain attacks, highlighting the growing risks associated with open-source software dependencies. CocoaPods, used in over three million mobile apps, plays a crucial role<a class="excerpt-read-more" href="https://www.developer-tech.com/news/2024/jul/02/cocoapods-flaws-highlight-growing-supply-chain-risks/" title="ReadCocoaPods flaws highlight growing supply chain risks">... Read more &#187;</a></p>
<p>The post <a href="https://www.developer-tech.com/news/2024/jul/02/cocoapods-flaws-highlight-growing-supply-chain-risks/">CocoaPods flaws highlight growing supply chain risks</a> appeared first on <a href="https://www.developer-tech.com">Developer Tech News</a>.</p>

