# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Sam Altman's Startup Names Former X Executive As First Head of Privacy
 - [https://www.wsj.com/articles/sam-altmans-startup-names-former-x-executive-as-first-head-of-privacy-1d2dbfd8?mod=rss_Technology](https://www.wsj.com/articles/sam-altmans-startup-names-former-x-executive-as-first-head-of-privacy-1d2dbfd8?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-07-02T13:03:00+00:00

Tools for Humanity named a former X executive as its first head of privacy as the tech startup founded by OpenAI Chief Executive Sam Altman faces growing regulatory scrutiny over its Worldcoin venture that scans people’s eyes in exchange for cryptocurrency tokens.

