# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Shop prices fall in boost to hopes of interest rate cuts
 - [https://www.telegraph.co.uk/business/2024/07/02/ftse-100-markets-latest-news-uk-shop-prices-fall-inflation](https://www.telegraph.co.uk/business/2024/07/02/ftse-100-markets-latest-news-uk-shop-prices-fall-inflation)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2024-07-02T05:49:18+00:00



