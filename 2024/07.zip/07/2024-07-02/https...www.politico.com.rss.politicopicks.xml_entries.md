# Source:Politico News Top Stories, URL:https://www.politico.com/rss/politicopicks.xml, language:en-us

## 5 simple steps to deceiving your way to Downing Street
 - [https://www.politico.eu/article/rishi-sunak-keir-starmer-labour-tory-downing-street-campaign-uk-election](https://www.politico.eu/article/rishi-sunak-keir-starmer-labour-tory-downing-street-campaign-uk-election)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-07-02T20:07:24.683622+00:00

From dodgy data to flagrant fibs, POLITICO has the inside track on how politicians are scheming to win votes at the U.K. general election.

## Nigel Farage battles the hard right's fatal flaw
 - [https://www.politico.eu/article/what-the-nationalist-right-gets-wrong](https://www.politico.eu/article/what-the-nationalist-right-gets-wrong)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-07-02T20:07:23.070491+00:00

Europe's nationalists have often struggled to field a clean sheet of respectable candidates.

## Trump’s sentencing in New York delayed until Sept. 18
 - [https://www.politico.com/news/2024/07/02/trump-sentencing-delayed-new-york-00166303](https://www.politico.com/news/2024/07/02/trump-sentencing-delayed-new-york-00166303)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-07-02T14:29:39+00:00

The sentencing, which had been set for July 11, will now take place less than two months before Election Day.

## Democratic governors seek meeting with Biden on path forward after dismal debate
 - [https://www.politico.com/news/2024/07/02/democratic-governors-meeting-biden-debate-00166276](https://www.politico.com/news/2024/07/02/democratic-governors-meeting-biden-debate-00166276)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-07-02T13:47:41+00:00

The meeting, which could come as soon as Wednesday, follows a call on which dozens of governors gathered to discuss Biden’s disastrous debate performance.

## Rudy Giuliani disbarred in New York
 - [https://www.politico.com/news/2024/07/02/rudy-giuliani-disbarred-in-new-york-00166232](https://www.politico.com/news/2024/07/02/rudy-giuliani-disbarred-in-new-york-00166232)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-07-02T10:31:20+00:00

Giuliani “flagrantly misused his prominent position as the personal attorney for former President Trump and his campaign,” a state appeals court found.

## Democrats begin attacking Biden’s performance and campaign
 - [https://www.politico.com/news/2024/07/02/democrats-biden-debate-fallout-00166208](https://www.politico.com/news/2024/07/02/democrats-biden-debate-fallout-00166208)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-07-02T08:10:20+00:00

Rep. Lloyd Doggett (D-Texas) said the president needs to step aside and usher in a “new generation of leaders.”

## The Supreme Court Gave Trump a Stunning Gift — and Rewrote the Constitution
 - [https://www.politico.com/news/magazine/2024/07/02/jan-6-trump-supreme-court-00166130](https://www.politico.com/news/magazine/2024/07/02/jan-6-trump-supreme-court-00166130)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-07-02T04:00:00+00:00

Special counsel Jack Smith and Judge Tanya Chutkan have a narrow path to move forward with a trial.

## Trump’s Plan for NATO Is Emerging.
 - [https://www.politico.com/news/magazine/2024/07/02/nato-second-trump-term-00164517](https://www.politico.com/news/magazine/2024/07/02/nato-second-trump-term-00164517)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-07-02T04:00:00+00:00

Trump advisers envision a ‘radical reorientation’ in which Washington takes a back seat to Europe — and cuts a deal with Putin over Ukraine.

## ‘We’ve all enabled the situation’: Dems turn on Biden’s inner sanctum post debate
 - [https://www.politico.com/news/2024/07/02/biden-campaign-debate-inner-circle-00166160](https://www.politico.com/news/2024/07/02/biden-campaign-debate-inner-circle-00166160)
 - RSS feed: https://www.politico.com/rss/politicopicks.xml
 - date published: 2024-07-02T04:00:00+00:00

The senior team’s management of Biden has grown more strictly controlled as his term has gone on.

