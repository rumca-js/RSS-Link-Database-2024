# Source:Board Game Quest, URL:https://www.boardgamequest.com/feed, language:en-US

## It’s a Wonderful Kingdom Review
 - [https://www.boardgamequest.com/its-a-wonderful-kingdom-review](https://www.boardgamequest.com/its-a-wonderful-kingdom-review)
 - RSS feed: https://www.boardgamequest.com/feed
 - date published: 2024-07-02T12:02:30+00:00

<img alt="It&#039;s a Wonderful Kingdom" class="webfeedsFeaturedVisual wp-post-image" height="640" src="https://www.boardgamequest.com/wp-content/uploads/2024/05/Its-a-Wonderful-Kingdom-1024x1024.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="640" />The original implementation of this game, It’s a Wonderful World, was popular with our gaming group a few years ago, so I was pleased to try out the new 2-player game. The game group loved the original because it was a quick yet satisfying play, with light strategy and a bit of interaction during the [&#8230;]
<p><a href="https://www.boardgamequest.com/its-a-wonderful-kingdom-review/" rel="nofollow">Source</a></p>

