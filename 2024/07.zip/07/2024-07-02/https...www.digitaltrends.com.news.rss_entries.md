# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Here’s why Windows 11 is finally inching along
 - [https://www.digitaltrends.com/computing/watch-out-windows-10-windows-11-is-slowly-catching-up](https://www.digitaltrends.com/computing/watch-out-windows-10-windows-11-is-slowly-catching-up)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-07-02T22:19:04.068850+00:00

Despite the resistance to upgrade to Windows 11, users are slow opening up to the idea of upgrading to the latest OS from Microsoft as seen in a new report.

## AAA game downloads in 2 milliseconds? It’s possible
 - [https://www.digitaltrends.com/computing/new-internet-speed-record-hits-402-tbps](https://www.digitaltrends.com/computing/new-internet-speed-record-hits-402-tbps)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-07-02T21:15:32.321118+00:00

A team of engineers has just achieved an incredible feat: 402Tbps internet data transmission rate. Yes, that's terabytes per second.

## Why Nvidia is about to get a huge edge over AMD
 - [https://www.digitaltrends.com/computing/micron-gddr7-memory-performance-improvements](https://www.digitaltrends.com/computing/micron-gddr7-memory-performance-improvements)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-07-02T00:41:09.890546+00:00

Micron shared some performance figured on its next-gen GDDR7 memory, and it's great news for Nvidia's RTX 50-series.

