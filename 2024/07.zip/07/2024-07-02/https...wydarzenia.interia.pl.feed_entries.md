# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Impas w Małopolsce trwa. Zaskakujące wyniki głosowania
 - [https://wydarzenia.interia.pl/malopolskie/news-impas-w-malopolsce-trwa-zaskakujace-wyniki-glosowania,nId,7620031](https://wydarzenia.interia.pl/malopolskie/news-impas-w-malopolsce-trwa-zaskakujace-wyniki-glosowania,nId,7620031)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T20:01:34+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-impas-w-malopolsce-trwa-zaskakujace-wyniki-glosowania,nId,7620031"><img align="left" alt="Impas w Małopolsce trwa. Zaskakujące wyniki głosowania" src="https://i.iplsc.com/impas-w-malopolsce-trwa-zaskakujace-wyniki-glosowania/000JEL7SFCII3TYE-C321.jpg" /></a>Łukasz Kmita ponownie nie został wybrany na marszałka województwa małopolskiego. W głosowaniu przepadł też minister w Kancelarii Prezydenta RP Piotr Ćwik. Była to piąta próba wyboru na wspomniane stanowisko. Na podjęcie decyzji radni mają czas do 9 lipca, w przeciwnym razie dojdzie do nowych wyborów.</p><br clear="all" />

## Konflikt w Małopolsce. Radny z PiS zgłasza nowego kandydata
 - [https://wydarzenia.interia.pl/malopolskie/news-konflikt-w-malopolsce-radny-z-pis-zglasza-nowego-kandydata,nId,7620345](https://wydarzenia.interia.pl/malopolskie/news-konflikt-w-malopolsce-radny-z-pis-zglasza-nowego-kandydata,nId,7620345)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T19:23:23+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-konflikt-w-malopolsce-radny-z-pis-zglasza-nowego-kandydata,nId,7620345"><img align="left" alt="Konflikt w Małopolsce. Radny z PiS zgłasza nowego kandydata" src="https://i.iplsc.com/konflikt-w-malopolsce-radny-z-pis-zglasza-nowego-kandydata/000G7T34N71KQ24D-C321.jpg" /></a>Radny z PiS Józef Gawron zgłosił Piotra Ćwika na kandydata na marszałka województwa małopolskiego. Jego kontrkandydatem, zgłoszonym przez KO, został Łukasz Kmita.</p><br clear="all" />

## Rosną wątpliwości wokół Bidena. Wśród demokratów tracą cierpliwość
 - [https://wydarzenia.interia.pl/zagranica/news-rosna-watpliwosci-wokol-bidena-wsrod-demokratow-traca-cierpl,nId,7620324](https://wydarzenia.interia.pl/zagranica/news-rosna-watpliwosci-wokol-bidena-wsrod-demokratow-traca-cierpl,nId,7620324)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T19:14:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosna-watpliwosci-wokol-bidena-wsrod-demokratow-traca-cierpl,nId,7620324"><img align="left" alt="Rosną wątpliwości wokół Bidena. Wśród demokratów tracą cierpliwość" src="https://i.iplsc.com/rosna-watpliwosci-wokol-bidena-wsrod-demokratow-traca-cierpl/000JEL2W4TVW07YD-C321.jpg" /></a>Pierwszy z kongresmenów Partii Demokratycznej publicznie domaga się rezygnacji Joe Bidena z wyścigu o Biały Dom. Lloyd Doggett w oświadczeniu podkreślił, że prezydent ma wiele zasług dla kraju, ale jego start w wyborach może grozić wygraną Donalda Trumpa. Wątpliwości ma także była spikerka Izby Reprezentantów Nancy Pelosi. Biden na razie nie chce jednak słyszeć o wycofaniu się.</p><br clear="all" />

## Kolejne przerwy, zawieszeni radni. Awantura w Małopolsce
 - [https://wydarzenia.interia.pl/malopolskie/news-kolejne-przerwy-zawieszeni-radni-awantura-w-malopolsce,nId,7620323](https://wydarzenia.interia.pl/malopolskie/news-kolejne-przerwy-zawieszeni-radni-awantura-w-malopolsce,nId,7620323)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T18:28:21+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-kolejne-przerwy-zawieszeni-radni-awantura-w-malopolsce,nId,7620323"><img align="left" alt="Kolejne przerwy, zawieszeni radni. Awantura w Małopolsce" src="https://i.iplsc.com/kolejne-przerwy-zawieszeni-radni-awantura-w-malopolsce/000JEKY6P0UAWNN8-C321.jpg" /></a>Małopolscy radni PiS Witold Kozłowski oraz Piotr Ćwik mieli we wtorek otrzymać informacje o zawieszeniu w prawach członka partii - dowiedziała się Interia. Podobna decyzja ma także zostać podjęta wobec Józefa Gawrona. To pokłosie buntu samorządowców z partii Jarosława Kaczyńskiego w sprawie wyboru marszałka województwa.</p><br clear="all" />

## Rosyjskie kuriozum. Sąd "aresztował" byłego premiera Ukrainy
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosyjskie-kuriozum-sad-aresztowal-bylego-premiera-ukrainy,nId,7620272](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosyjskie-kuriozum-sad-aresztowal-bylego-premiera-ukrainy,nId,7620272)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T17:05:07+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosyjskie-kuriozum-sad-aresztowal-bylego-premiera-ukrainy,nId,7620272"><img align="left" alt="Rosyjskie kuriozum. Sąd &quot;aresztował&quot; byłego premiera Ukrainy" src="https://i.iplsc.com/rosyjskie-kuriozum-sad-aresztowal-bylego-premiera-ukrainy/000JEKPLK3N2DM1A-C321.jpg" /></a>Sąd w Moskwie &quot;aresztował&quot; zaocznie ukraińskich polityków: byłego premiera Wołodymyra Hrojsmana i szefa MSZ Pawła Klimkina. W oświadczeniu zaznaczono, że okres aresztu liczy się &quot;od momentu ekstradycji do Rosji lub od momentu zatrzymania&quot; na terytorium tego kraju. Rzekome zarzuty dotyczą &quot;stosowania zakazanych środków i metod prowadzenia wojny&quot;.</p><br clear="all" />

## Zdjęcie z Bieszczad wstrząsnęło Polską. Może być jeszcze gorzej
 - [https://wydarzenia.interia.pl/podkarpackie/news-zdjecie-z-bieszczad-wstrzasnelo-polska-moze-byc-jeszcze-gorz,nId,7620078](https://wydarzenia.interia.pl/podkarpackie/news-zdjecie-z-bieszczad-wstrzasnelo-polska-moze-byc-jeszcze-gorz,nId,7620078)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T16:55:43+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-zdjecie-z-bieszczad-wstrzasnelo-polska-moze-byc-jeszcze-gorz,nId,7620078"><img align="left" alt="Zdjęcie z Bieszczad wstrząsnęło Polską. Może być jeszcze gorzej" src="https://i.iplsc.com/zdjecie-z-bieszczad-wstrzasnelo-polska-moze-byc-jeszcze-gorz/000JEK9DC293QEST-C321.jpg" /></a>Ostatnie kilkanaście godzin to niemal ciągłe, intensywne opady deszczu w okolicach Ustrzyk Dolnych w Bieszczadach. W Hoszowie wezbrany potok zabrał za sobą auto z kierowcą na pokładzie. 71-latek nie przeżył. W miejscowości Nasiczne w kierunku Brzegów Górnych zeszła lawina błotna, która zablokowała drogę na wiele godzin. Kilkuset mieszkańców okolicy było odciętych od świata.</p><br clear="all" />

## Aresztowanie ks. Olszewskiego. Stanowczy apel służby więziennej
 - [https://wydarzenia.interia.pl/kraj/news-aresztowanie-ks-olszewskiego-stanowczy-apel-sluzby-wiezienne,nId,7620107](https://wydarzenia.interia.pl/kraj/news-aresztowanie-ks-olszewskiego-stanowczy-apel-sluzby-wiezienne,nId,7620107)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T16:49:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-aresztowanie-ks-olszewskiego-stanowczy-apel-sluzby-wiezienne,nId,7620107"><img align="left" alt="Aresztowanie ks. Olszewskiego. Stanowczy apel służby więziennej" src="https://i.iplsc.com/aresztowanie-ks-olszewskiego-stanowczy-apel-sluzby-wiezienne/000JEKI7OWK63XGJ-C321.jpg" /></a>Służba więzienna odcina się od spekulacji o &quot;torturach&quot; wobec zatrzymanego Michała Olszewskiego. Jak podkreśla formacja, aresztowanie księdza, a następnie fala plotek o jego traktowaniu, spowodowały nagonkę na pracowników aresztu śledczego Warszawa-Służewiec. Do placówki wpłynęło ponad 100 maili, często niecenzuralnych. &quot;PiS uruchomił lawinę hejtu&quot; - ocenił wiceminister Arkadiusz Myrcha.</p><br clear="all" />

## Rosja reaguje na wizytę Orbana. "Musi spełniać swoje funkcje"
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-reaguje-na-wizyte-orbana-musi-spelniac-swoje-funkcje,nId,7620069](https://wydarzenia.interia.pl/zagranica/news-rosja-reaguje-na-wizyte-orbana-musi-spelniac-swoje-funkcje,nId,7620069)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T14:52:11+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-reaguje-na-wizyte-orbana-musi-spelniac-swoje-funkcje,nId,7620069"><img align="left" alt="Rosja reaguje na wizytę Orbana. &quot;Musi spełniać swoje funkcje&quot;" src="https://i.iplsc.com/rosja-reaguje-na-wizyte-orbana-musi-spelniac-swoje-funkcje/000JEK8EAR1S0L09-C321.jpg" /></a>- Kreml nie ma żadnych oczekiwań w związku z wizytą premiera Węgier Viktora Orbana w Kijowie - powiedział Dmitrij Pieskow. Rzecznik Władimira Putina stwierdził jednocześnie, że Budapeszt &quot;musi spełniać swoją funkcję&quot; w ramach rozpoczętej w poniedziałek prezydencji w UE. Jak dodał, strona węgierska nie kontaktowała się z Moskwą przed wizytą w Kijowie.</p><br clear="all" />

## Sanepid ostrzega klientów. Groźne metale w popularnym produkcie
 - [https://wydarzenia.interia.pl/kraj/news-sanepid-ostrzega-klientow-grozne-metale-w-popularnym-produkc,nId,7620014](https://wydarzenia.interia.pl/kraj/news-sanepid-ostrzega-klientow-grozne-metale-w-popularnym-produkc,nId,7620014)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T14:47:47+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sanepid-ostrzega-klientow-grozne-metale-w-popularnym-produkc,nId,7620014"><img align="left" alt="Sanepid ostrzega klientów. Groźne metale w popularnym produkcie" src="https://i.iplsc.com/sanepid-ostrzega-klientow-grozne-metale-w-popularnym-produkc/000JEK6UMVGQAAHO-C321.jpg" /></a>Inspektorzy sanitarni ostrzegają przed korzystaniem ze szklanych kubków termicznych marki Allesken. W partii tego produktu wykryto duże ilości toksycznych, niebezpiecznych dla zdrowia metali: ołowiu oraz kadmu. Artykuł jest wycofywany ze sprzedaży, lecz jeśli ktoś zdążył kupić taki kubek, będzie mógł go zwrócić. </p><br clear="all" />

## PiS straci Małopolskę? "Było o włos"
 - [https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-pis-straci-malopolske-bylo-o-wlos,nId,7619996](https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-pis-straci-malopolske-bylo-o-wlos,nId,7619996)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T14:05:14+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-pis-straci-malopolske-bylo-o-wlos,nId,7619996"><img align="left" alt="PiS straci Małopolskę? &quot;Było o włos&quot;" src="https://i.iplsc.com/pis-straci-malopolske-bylo-o-wlos/000JEJC1XOL06TNV-C321.jpg" /></a>Koalicja Obywatelska i PSL były pewne, że wskutek porozumienia z kilkorgiem radnych PiS, wybiorą w poniedziałek własnego marszałka i przejmą władzę w Małopolsce. Do zwycięstwa nad kandydatem PiS zabrakło im jednego głosu. Rozmowy nadal trwają, kolejne głosowanie we wtorek o godzinie 18. PiS liczy na opamiętanie swoich radnych. Jarosław Kaczyński przekonuje ich, że wymaga tego &quot;racja stanu&quot;. </p><br clear="all" />

## "Wytrzymamy kilka tygodni". Estoński wojskowy o ewentualnym scenariuszu wojny
 - [https://wydarzenia.interia.pl/zagranica/news-wytrzymamy-kilka-tygodni-estonski-wojskowy-o-ewentualnym-sce,nId,7620008](https://wydarzenia.interia.pl/zagranica/news-wytrzymamy-kilka-tygodni-estonski-wojskowy-o-ewentualnym-sce,nId,7620008)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T13:57:17+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wytrzymamy-kilka-tygodni-estonski-wojskowy-o-ewentualnym-sce,nId,7620008"><img align="left" alt="&quot;Wytrzymamy kilka tygodni&quot;. Estoński wojskowy o ewentualnym scenariuszu wojny" src="https://i.iplsc.com/wytrzymamy-kilka-tygodni-estonski-wojskowy-o-ewentualnym-sce/000JEJBY45GSNVFK-C321.jpg" /></a>- Kraj NATO (Estonia - red.), który graniczy lądowo z Rosją, byłby w stanie stawić opór inwazji przez kilka tygodni - twierdzi Mati Tikerpuu. Wysoki rangą dowódca wojskowy estońskich Sił Zbrojnych jest przekonany, że jego kraj mógłby skutecznie obronić się w pierwszych dniach inwazji, jeszcze przed uzyskaniem wsparcia pozostałych krajów NATO.</p><br clear="all" />

## Prezes PiS o liście do Ziobry. "Może mnie pamięć zawodzi"
 - [https://wydarzenia.interia.pl/kraj/news-prezes-pis-o-liscie-do-ziobry-moze-mnie-pamiec-zawodzi,nId,7619963](https://wydarzenia.interia.pl/kraj/news-prezes-pis-o-liscie-do-ziobry-moze-mnie-pamiec-zawodzi,nId,7619963)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T13:51:34+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezes-pis-o-liscie-do-ziobry-moze-mnie-pamiec-zawodzi,nId,7619963"><img align="left" alt="Prezes PiS o liście do Ziobry. &quot;Może mnie pamięć zawodzi&quot;" src="https://i.iplsc.com/prezes-pis-o-liscie-do-ziobry-moze-mnie-pamiec-zawodzi/000JEK2ZX9GJEDM2-C321.jpg" /></a>Wynikiem &quot;specyficznego stanu&quot; podczas kampanii wyborczej mógł być list Jarosława Kaczyńskiego do Zbigniewa Ziobry z 2019 roku - stwierdził prezes PiS. Zastrzegł, że ani on, ani jego koalicjant, nie pamiętają takiej korespondencji, mającej dotyczyć wykorzystywania środków z Funduszu Sprawiedliwości. Zdaniem Kaczyńskiego oskarżenia o złamanie przez niego prawa są motywowane nienawiścią &quot;odbierającą rozum&quot;.</p><br clear="all" />

## Prezes PiS o "tajnym liście": Może po prostu pamięć mnie zawodzi
 - [https://wydarzenia.interia.pl/kraj/news-prezes-pis-o-tajnym-liscie-moze-po-prostu-pamiec-mnie-zawodz,nId,7619963](https://wydarzenia.interia.pl/kraj/news-prezes-pis-o-tajnym-liscie-moze-po-prostu-pamiec-mnie-zawodz,nId,7619963)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T13:51:34+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezes-pis-o-tajnym-liscie-moze-po-prostu-pamiec-mnie-zawodz,nId,7619963"><img align="left" alt="Prezes PiS o &quot;tajnym liście&quot;: Może po prostu pamięć mnie zawodzi" src="https://i.iplsc.com/prezes-pis-o-tajnym-liscie-moze-po-prostu-pamiec-mnie-zawodz/000JEK2ZX9GJEDM2-C321.jpg" /></a>Wynikiem &quot;specyficznego stanu psychicznego&quot; podczas kampanii wyborczej mógł być list Jarosława Kaczyńskiego do Zbigniewa Ziobry z 2019 roku - stwierdził prezes PiS. Zastrzegł, że ani on, ani jego koalicjant, nie pamiętają takiej korespondencji, mającej dotyczyć wykorzystywania środków z Funduszu Sprawiedliwości. Zdaniem Kaczyńskiego oskarżenia o złamanie przez niego prawa są motywowane nienawiścią &quot;odbierającą rozum&quot;.</p><br clear="all" />

## Burze krążą po Polsce. Pogoda mało przyjazna
 - [https://wydarzenia.interia.pl/kraj/news-burze-kraza-po-polsce-pogoda-malo-przyjazna,nId,7620016](https://wydarzenia.interia.pl/kraj/news-burze-kraza-po-polsce-pogoda-malo-przyjazna,nId,7620016)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T13:51:14+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burze-kraza-po-polsce-pogoda-malo-przyjazna,nId,7620016"><img align="left" alt="Burze krążą po Polsce. Pogoda mało przyjazna" src="https://i.iplsc.com/burze-kraza-po-polsce-pogoda-malo-przyjazna/000JEJWLWUJ40QMX-C321.jpg" /></a>Burze są słabe, ale wciąż pojawiają się w Polsce. Pogoda we wtorek nie zachęca do spacerów, zwłaszcza na północy kraju. Dowiedz się, gdzie jest burza oraz jakiej pogody można się spodziewać w kolejnych godzinach.</p><br clear="all" />

## Zbigniew Ziobro zabrał głos ws. choroby. "To może być rozstrzygająca diagnoza"
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-zbigniew-ziobro-zabral-glos-ws-choroby-to-moze-byc-rozstrzyg,nId,7619956](https://wydarzenia.interia.pl/tylko-w-interii/news-zbigniew-ziobro-zabral-glos-ws-choroby-to-moze-byc-rozstrzyg,nId,7619956)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T13:34:32+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-zbigniew-ziobro-zabral-glos-ws-choroby-to-moze-byc-rozstrzyg,nId,7619956"><img align="left" alt="Zbigniew Ziobro zabrał głos ws. choroby. &quot;To może być rozstrzygająca diagnoza&quot;" src="https://i.iplsc.com/zbigniew-ziobro-zabral-glos-ws-choroby-to-moze-byc-rozstrzyg/000JEJ0RJK7D95XC-C321.jpg" /></a>- Czekam na zaplanowane na październik badanie PET. To może być rozstrzygająca diagnoza, czy się udało, czy są nawroty. Choć niektórzy mówią mi, że z nowotworu nigdy nie da się wyjść - mówi Interii były minister sprawiedliwości Zbigniew Ziobro. W rozmowie z Jakubem Szczepańskim lider Suwerennej Polski opisuje szczegóły swojego stanu zdrowia i odnosi się do aktualnych wydarzeń politycznych, m.in. zarzutów o złe wydatkowanie środków z Funduszu Sprawiedliwości. Pierwszą część rozmowy publikujemy dziś. Druga część ukaże się w Interii w środę. </p><br clear="all" />

## Nietrzeźwy kierownik obozu harcerzy. Zaskakująco się tłumaczył
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-nietrzezwy-kierownik-obozu-harcerzy-zaskakujaco-sie-tlumaczy,nId,7619980](https://wydarzenia.interia.pl/warminsko-mazurskie/news-nietrzezwy-kierownik-obozu-harcerzy-zaskakujaco-sie-tlumaczy,nId,7619980)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T13:06:52+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-nietrzezwy-kierownik-obozu-harcerzy-zaskakujaco-sie-tlumaczy,nId,7619980"><img align="left" alt="Nietrzeźwy kierownik obozu harcerzy. Zaskakująco się tłumaczył" src="https://i.iplsc.com/nietrzezwy-kierownik-obozu-harcerzy-zaskakujaco-sie-tlumaczy/000JEJ2RXFCGA06V-C321.jpg" /></a>Miał opiekować się niemal 60 nieletnimi harcerzami, lecz nad ranem sięgnął po alkohol. Mężczyznę przyłapano podczas policyjnej kontroli. Potwierdził wtedy, że wypił nad ranem kilka piw, bo w życiu prywatnym na problemy rodzinne. Teraz lista jego kłopotów się wydłużyła.</p><br clear="all" />

## Orban z propozycją dla Ukrainy. Tak zamierza skończyć wojnę
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-orban-z-propozycja-dla-ukrainy-tak-zamierza-skonczyc-wojne,nId,7619879](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-orban-z-propozycja-dla-ukrainy-tak-zamierza-skonczyc-wojne,nId,7619879)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T12:39:09+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-orban-z-propozycja-dla-ukrainy-tak-zamierza-skonczyc-wojne,nId,7619879"><img align="left" alt="Orban z propozycją dla Ukrainy. Tak zamierza skończyć wojnę" src="https://i.iplsc.com/orban-z-propozycja-dla-ukrainy-tak-zamierza-skonczyc-wojne/000JEIZ95UUQ5JC0-C321.jpg" /></a>Węgierski premier Viktor Orban nie wyklucza, że jego kraj weźmie udział w &quot;modernizacji&quot; gospodarki Ukrainy, co ogłosił podczas wtorkowej wizyty w Kijowie. Ma jednak propozycję dla Wołodymyra Zełenskiego, która dotyczy zawieszenia broni w relacjach z Rosją. To - zdaniem polityka - miałoby przybliżyć oba walczące ze sobą kraje do pokoju.</p><br clear="all" />

## Echa listu ks. Olszewskiego. Sercanie wydali specjalne oświadczenie
 - [https://wydarzenia.interia.pl/kraj/news-echa-listu-ks-olszewskiego-sercanie-wydali-specjalne-oswiadc,nId,7619918](https://wydarzenia.interia.pl/kraj/news-echa-listu-ks-olszewskiego-sercanie-wydali-specjalne-oswiadc,nId,7619918)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T12:03:25+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-echa-listu-ks-olszewskiego-sercanie-wydali-specjalne-oswiadc,nId,7619918"><img align="left" alt="Echa listu ks. Olszewskiego. Sercanie wydali specjalne oświadczenie" src="https://i.iplsc.com/echa-listu-ks-olszewskiego-sercanie-wydali-specjalne-oswiadc/000JEIILR8UNNF39-C321.jpg" /></a>&quot;Wiemy, że wielu z was chce zrobić coś więcej, zorganizować manifestacje, zbierać podpisy czy nagłaśniać sprawę w mediach. Choć my jak Profeto nie możemy angażować się w takie działania ze względu na naszą rolę w postępowaniu, doceniamy każdy gest&quot; - czytamy w oświadczeniu opublikowanym przez Zgromadzenie Księży Najświętszego Serca Jezusowego. Do sytuacji ks. Olszewskiego odniósł się również jego adwokat, ujawniając nowe informacje o stanie zdrowia duchownego. Sprawa zatrzymanego księdza od kilku dni budzi spore emocje. </p><br clear="all" />

## Rekordowy huragan uderzył w tropikach. Dziennikarze uciekli ze studia
 - [https://wydarzenia.interia.pl/zagranica/news-rekordowy-huragan-uderzyl-w-tropikach-dziennikarze-uciekli-z,nId,7619876](https://wydarzenia.interia.pl/zagranica/news-rekordowy-huragan-uderzyl-w-tropikach-dziennikarze-uciekli-z,nId,7619876)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T11:50:22+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rekordowy-huragan-uderzyl-w-tropikach-dziennikarze-uciekli-z,nId,7619876"><img align="left" alt="Rekordowy huragan uderzył w tropikach. Dziennikarze uciekli ze studia" src="https://i.iplsc.com/rekordowy-huragan-uderzyl-w-tropikach-dziennikarze-uciekli-z/000JEIIFBAIR9Y6W-C321.jpg" /></a>Huragan Beryl, który zbliża się do Karaibów, przybrał na sile jeszcze bardziej i obecnie jest już huraganem piątej, najwyższej kategorii. Żywioł dotarł do niektórych wysp archipelagu, niosąc niszczycielski wiatr i ulewne deszcze. W jednym z krajów zmusił prowadzących audycję na żywo dziennikarzy do ucieczki ze studia.</p><br clear="all" />

## ZUS ogłosił kolejną odsłonę programu 300 plus. Ruszył nabór wniosków
 - [https://wydarzenia.interia.pl/kraj/news-zus-oglosil-kolejna-odslone-programu-300-plus-ruszyl-nabor-w,nId,7617701](https://wydarzenia.interia.pl/kraj/news-zus-oglosil-kolejna-odslone-programu-300-plus-ruszyl-nabor-w,nId,7617701)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T11:32:52+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zus-oglosil-kolejna-odslone-programu-300-plus-ruszyl-nabor-w,nId,7617701"><img align="left" alt="ZUS ogłosił kolejną odsłonę programu 300 plus. Ruszył nabór wniosków " src="https://i.iplsc.com/zus-oglosil-kolejna-odslone-programu-300-plus-ruszyl-nabor-w/000JEI4PWQYL3O6S-C321.jpg" /></a>&quot;Dobry Start&quot;, znany również jako &quot;300 plus&quot;, to program umożliwiający otrzymanie jednorazowego wsparcia na wyprawkę szkolną. Wysokość świadczenia to 300 zł. Zakład Ubezpieczeń Społecznych rozpoczął zbieranie wniosków 1 lipca. Komu należy się 300 plus i jak o nie zawnioskować?</p><br clear="all" />

## Zwrot w sprawie arcybiskupa Jędraszewskiego. Wszystko w rękach papieża
 - [https://wydarzenia.interia.pl/malopolskie/news-zwrot-w-sprawie-arcybiskupa-jedraszewskiego-wszystko-w-rekac,nId,7619846](https://wydarzenia.interia.pl/malopolskie/news-zwrot-w-sprawie-arcybiskupa-jedraszewskiego-wszystko-w-rekac,nId,7619846)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T11:21:13+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-zwrot-w-sprawie-arcybiskupa-jedraszewskiego-wszystko-w-rekac,nId,7619846"><img align="left" alt="Zwrot w sprawie arcybiskupa Jędraszewskiego. Wszystko w rękach papieża" src="https://i.iplsc.com/zwrot-w-sprawie-arcybiskupa-jedraszewskiego-wszystko-w-rekac/000JEI1AWC14G2U3-C321.jpg" /></a>Arcybiskup Marek Jędraszewski nadal będzie stać na czele krakowskiej kurii, mimo że w połowie lipca osiągnie wiek emerytalny - dowiedziała się Interia. Duchowny złożył rezygnację na ręce papieża, ale Watykan jeszcze nie wskazał następcy. Procedura wyboru jest długa i tajemnicza. Nuncjatura Apostolska nie chce nawet zdradzić, czy proces wyłaniania następcy w ogóle się rozpoczął. </p><br clear="all" />

## Brak konkretów po wizycie kanclerza Niemiec? Andrzej Duda zabrał głos
 - [https://wydarzenia.interia.pl/zagranica/news-brak-konkretow-po-wizycie-kanclerza-niemiec-andrzej-duda-zab,nId,7619861](https://wydarzenia.interia.pl/zagranica/news-brak-konkretow-po-wizycie-kanclerza-niemiec-andrzej-duda-zab,nId,7619861)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T11:17:18+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brak-konkretow-po-wizycie-kanclerza-niemiec-andrzej-duda-zab,nId,7619861"><img align="left" alt="Brak konkretów po wizycie kanclerza Niemiec? Andrzej Duda zabrał głos" src="https://i.iplsc.com/brak-konkretow-po-wizycie-kanclerza-niemiec-andrzej-duda-zab/000GDJY75Q92KQ0P-C321.jpg" /></a>- Nie podzielam stanowiska, że jakiekolwiek polskie władze skutecznie zrzekły się roszczeń do zadośćuczynienia, za krzywdy które stały się udziałem Polaków, polskiego narodu w czasie II wojny światowej - powiedział prezydent Andrzej Duda po spotkaniu premiera Donalda Tuska z kanclerzem Niemiec. Wbrew oczekiwaniom i medialnym doniesieniom, wizytujący Polskę Olaf Scholz nie ogłosił szczegółów dot. rekompensat dla polskich ofiar niemieckich zbrodni wojennych.</p><br clear="all" />

## Wybory na burmistrza do powtórki. Sąd poprzednie unieważnił
 - [https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-wybory-na-burmistrza-do-powtorki-sad-poprzednie-uniewaznil,nId,7619809](https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-wybory-na-burmistrza-do-powtorki-sad-poprzednie-uniewaznil,nId,7619809)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T10:51:28+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-wybory-na-burmistrza-do-powtorki-sad-poprzednie-uniewaznil,nId,7619809"><img align="left" alt="Wybory na burmistrza do powtórki. Sąd poprzednie unieważnił" src="https://i.iplsc.com/wybory-na-burmistrza-do-powtorki-sad-poprzednie-uniewaznil/000JEI2URTVWX06T-C321.jpg" /></a>Nakaz przeprowadzenia ponownego głosowania w II turze wyborów burmistrza Brzezin przekazał Sąd Okręgowy w Łodzi. Jak się okazało, wybory są nieważne, ze względu na uznanie sprzeciwu kandydata Daniela Szymczaka. Stwierdził on, że jego głosy zostały omyłkowo przepisane jego konkurentowi. </p><br clear="all" />

## Potężna broń w chińskiej armii. Eksperci: Zestrzelenie prawie niemożliwe
 - [https://wydarzenia.interia.pl/zagranica/news-potezna-bron-w-chinskiej-armii-eksperci-zestrzelenie-prawie-,nId,7619807](https://wydarzenia.interia.pl/zagranica/news-potezna-bron-w-chinskiej-armii-eksperci-zestrzelenie-prawie-,nId,7619807)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T10:47:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-potezna-bron-w-chinskiej-armii-eksperci-zestrzelenie-prawie-,nId,7619807"><img align="left" alt="Potężna broń w chińskiej armii. Eksperci: Zestrzelenie prawie niemożliwe" src="https://i.iplsc.com/potezna-bron-w-chinskiej-armii-eksperci-zestrzelenie-prawie/000JEHZVF0QO6TP3-C321.jpg" /></a>Chińska Armia Ludowo-Wyzwoleńcza zaprezentowała zdjęcie, na którym widoczna jest najnowsza modyfikacja bombowca H-6K. Szczególną uwagę zwraca jedna z możliwości - uniesienia w powietrze czterech rakiet balistycznych, które zdaniem ekspertów są obecnie praktycznie niemożliwe do zestrzelenia.</p><br clear="all" />

## Wykładowca odpowiedział byłemu rzecznikowi MSZ. Skandaliczny komentarz
 - [https://wydarzenia.interia.pl/kraj/news-wykladowca-odpowiedzial-bylemu-rzecznikowi-msz-skandaliczny-,nId,7619713](https://wydarzenia.interia.pl/kraj/news-wykladowca-odpowiedzial-bylemu-rzecznikowi-msz-skandaliczny-,nId,7619713)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T09:12:48+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wykladowca-odpowiedzial-bylemu-rzecznikowi-msz-skandaliczny-,nId,7619713"><img align="left" alt="Wykładowca odpowiedział byłemu rzecznikowi MSZ. Skandaliczny komentarz " src="https://i.iplsc.com/wykladowca-odpowiedzial-bylemu-rzecznikowi-msz-skandaliczny/000JEH564NYYXQXI-C321.jpg" /></a>Były rzecznik MSZ Łukasz Jasina napisał w mediach społecznościowych, że szuka pracy. W odpowiedzi wykładowca Uniwersytetu Łódzkiego podpowiedział mu, by zaczął zarabiać na portalu, gdzie publikowane są treści dla dorosłych. Uczelnia podejmie odpowiednie kroki. </p><br clear="all" />

## Nadużycia w Polskiej Fundacji Narodowej. Prokuratura wszczyna śledztwo
 - [https://wydarzenia.interia.pl/kraj/news-naduzycia-w-polskiej-fundacji-narodowej-prokuratura-wszczyna,nId,7619726](https://wydarzenia.interia.pl/kraj/news-naduzycia-w-polskiej-fundacji-narodowej-prokuratura-wszczyna,nId,7619726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T08:57:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-naduzycia-w-polskiej-fundacji-narodowej-prokuratura-wszczyna,nId,7619726"><img align="left" alt="Nadużycia w Polskiej Fundacji Narodowej. Prokuratura wszczyna śledztwo" src="https://i.iplsc.com/naduzycia-w-polskiej-fundacji-narodowej-prokuratura-wszczyna/000JEHBDTEKORPBG-C321.jpg" /></a>Prokuratura Okręgowa w Warszawie wszczęła śledztwo w sprawie nadużycia uprawnień i niedopełnienia obowiązków przez członków zarządu Polskiej Fundacji Narodowej (PFN). Chodzi o kampanię medialną &quot;Sprawiedliwe Sądy&quot; z 2017 roku.
</p><br clear="all" />

## Stan zdrowia Zbigniewa Ziobry. Mowa o "kluczowym badaniu"
 - [https://wydarzenia.interia.pl/kraj/news-stan-zdrowia-zbigniewa-ziobry-mowa-o-kluczowym-badaniu,nId,7619671](https://wydarzenia.interia.pl/kraj/news-stan-zdrowia-zbigniewa-ziobry-mowa-o-kluczowym-badaniu,nId,7619671)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T08:40:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-stan-zdrowia-zbigniewa-ziobry-mowa-o-kluczowym-badaniu,nId,7619671"><img align="left" alt="Stan zdrowia Zbigniewa Ziobry. Mowa o &quot;kluczowym badaniu&quot;" src="https://i.iplsc.com/stan-zdrowia-zbigniewa-ziobry-mowa-o-kluczowym-badaniu/000JEH5AACT59SB4-C321.jpg" /></a>Michał Wójcik z Suwerennej Polski ujawnił nowe informacje na temat stanu zdrowia Zbigniewa Ziobry. - To człowiek, który ma wyciętą krtań, wycięte węzły chłonne, ma wyciętą część żołądka, żołądek ma na płucu - powiedział w poniedziałek na antenie TVN24. Jak poinformował, jego stan jest bardzo ciężki i czeka go &quot;kluczowe badanie&quot;. </p><br clear="all" />

## Potężne burze w Chorwacji. Ucierpiał Zagrzeb
 - [https://wydarzenia.interia.pl/zagranica/news-potezne-burze-w-chorwacji-ucierpial-zagrzeb,nId,7619676](https://wydarzenia.interia.pl/zagranica/news-potezne-burze-w-chorwacji-ucierpial-zagrzeb,nId,7619676)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T08:31:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-potezne-burze-w-chorwacji-ucierpial-zagrzeb,nId,7619676"><img align="left" alt="Potężne burze w Chorwacji. Ucierpiał Zagrzeb" src="https://i.iplsc.com/potezne-burze-w-chorwacji-ucierpial-zagrzeb/000JEGXLVGN0XQXH-C321.jpg" /></a>Wyjątkowo silne burze, niosące wichury, ulewy i grad uderzyły w poniedziałek po południu w wiele chorwackich miast. Duże zniszczenia odnotowano w Zagrzebiu, gdzie doszło do zalania wielu ulic, a powalone drzewa wstrzymały funkcjonowanie miejskiego transportu. Tylko w tym mieście zanotowano około 200 interwencji. Uszkodzonych zostało wiele budynków i samochodów.</p><br clear="all" />

## Włamali się na plebanię. Ich łupem padło wino mszalne
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-wlamali-sie-na-plebanie-ich-lupem-padlo-wino-mszalne,nId,7618218](https://wydarzenia.interia.pl/dolnoslaskie/news-wlamali-sie-na-plebanie-ich-lupem-padlo-wino-mszalne,nId,7618218)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T07:27:38+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-wlamali-sie-na-plebanie-ich-lupem-padlo-wino-mszalne,nId,7618218"><img align="left" alt="Włamali się na plebanię. Ich łupem padło wino mszalne " src="https://i.iplsc.com/wlamali-sie-na-plebanie-ich-lupem-padlo-wino-mszalne/000ICGED2QJGMUEG-C321.jpg" /></a>Policjanci z Lwówka Śląskiego podjęli interwencję na plebanii. Okazało się, że w budynku doszło do włamania. Sprawcy ukradli m.in. wino mszalne oraz bombki i lampki choinkowe. Za akcją stali dwaj nastolatkowie. Teraz może ich czekać surowa kara. </p><br clear="all" />

## Przywiozła z wakacji ekskluzywny kosmetyk. Grożą jej poważne konsekwencje
 - [https://wydarzenia.interia.pl/kraj/news-przywiozla-z-wakacji-ekskluzywny-kosmetyk-groza-jej-powazne-,nId,7619627](https://wydarzenia.interia.pl/kraj/news-przywiozla-z-wakacji-ekskluzywny-kosmetyk-groza-jej-powazne-,nId,7619627)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T07:13:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-przywiozla-z-wakacji-ekskluzywny-kosmetyk-groza-jej-powazne-,nId,7619627"><img align="left" alt="Przywiozła z wakacji ekskluzywny kosmetyk. Grożą jej poważne konsekwencje" src="https://i.iplsc.com/przywiozla-z-wakacji-ekskluzywny-kosmetyk-groza-jej-powazne/000JEGOB1XMDXOKR-C321.jpg" /></a>Podczas kontroli na lotnisku w Pyrzowicach funkcjonariusze zatrzymali u podróżującej cztery opakowania kremu z jadem kobry. Turystce grożą konsekwencje prawne, ponieważ gatunek objęty jest konwencją CITES. Kobieta wracała z Wietnamu i nie zgłosiła celnikom, że przywiozła krem z tym składnikiem. Nie przedstawiła też wymaganego zezwolenia. </p><br clear="all" />

## Zgrzyt w koalicji rządzącej. Kością niezgody nadzór nad kluczową formacją
 - [https://wydarzenia.interia.pl/kraj/news-zgrzyt-w-koalicji-rzadzacej-koscia-niezgody-nadzor-nad-klucz,nId,7619556](https://wydarzenia.interia.pl/kraj/news-zgrzyt-w-koalicji-rzadzacej-koscia-niezgody-nadzor-nad-klucz,nId,7619556)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T05:26:06+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zgrzyt-w-koalicji-rzadzacej-koscia-niezgody-nadzor-nad-klucz,nId,7619556"><img align="left" alt="Zgrzyt w koalicji rządzącej. Kością niezgody nadzór nad kluczową formacją" src="https://i.iplsc.com/zgrzyt-w-koalicji-rzadzacej-koscia-niezgody-nadzor-nad-klucz/000JEG5G7P10XQV8-C321.jpg" /></a>Obecny rząd nie widzi potrzeby, by tworzyć cywilne Centralne Biuro Monitorowania Policji do badania skarg na funkcjonariuszy. Zdaniem jednego z wiceministrów obecne regulacje są wystarczające. Problem w tym, że zmian domagają się będące w koalicji Nowa Lewica i partia Razem. Postulat ten prezentowały jeszcze w 2020 roku. Jak mówi jeden z liderów Adrian Zandberg, zdania nie zmienili.</p><br clear="all" />

## Przełomowa decyzja Orbana. Pierwszy raz od wybuchu wojny w Ukrainie
 - [https://wydarzenia.interia.pl/zagranica/news-przelomowa-decyzja-orbana-pierwszy-raz-od-wybuchu-wojny-w-uk,nId,7619546](https://wydarzenia.interia.pl/zagranica/news-przelomowa-decyzja-orbana-pierwszy-raz-od-wybuchu-wojny-w-uk,nId,7619546)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-07-02T03:49:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-przelomowa-decyzja-orbana-pierwszy-raz-od-wybuchu-wojny-w-uk,nId,7619546"><img align="left" alt="Przełomowa decyzja Orbana. Pierwszy raz od wybuchu wojny w Ukrainie" src="https://i.iplsc.com/przelomowa-decyzja-orbana-pierwszy-raz-od-wybuchu-wojny-w-uk/000JEG3DQN4KK3RM-C321.jpg" /></a>Premier Węgier ma udać się we wtorek do Kijowa, gdzie spotka się z prezydentem Ukrainy Wołodymyrem Zełenskim - donosi brytyjski &quot;Financial Times&quot;. Gdyby informacje te się potwierdziły, oznaczałoby to pierwszą wizytę Viktora Orbana w Ukrainie od początku pełnoskalowej agresji Rosji. Biura Zełenskiego i Orbana nie skomentowały tych doniesień.</p><br clear="all" />

