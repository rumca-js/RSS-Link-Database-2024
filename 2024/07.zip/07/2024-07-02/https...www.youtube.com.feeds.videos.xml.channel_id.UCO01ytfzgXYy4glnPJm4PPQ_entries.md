# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## You will die and that shouldn't be surprising
 - [https://www.youtube.com/watch?v=XaVP5YTGpuU](https://www.youtube.com/watch?v=XaVP5YTGpuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-02T20:00:08+00:00



## Higher Education Is Failing America | Ep. 1399
 - [https://www.youtube.com/watch?v=JcEeMdpnzBI](https://www.youtube.com/watch?v=JcEeMdpnzBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-02T18:14:56+00:00

Today on the Matt Walsh show, hosted yet again by me, David Cone, young men are opting out of college in record numbers. Higher education continues to dilute curriculum, reducing the benefit of diplomas. The Supreme Court rules that Donald Trump has immunity for "official acts." I apply for a job on Dr. Jill Biden's team live, during the show, and climate activists are getting canceled.

Ep.1399

- - - 

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

- - -

DailyWire+:

Buy one year of DailyWire+ and get a second year FREE! Join here: https://bit.ly/3L1kc1o

Get 10% off your tickets to Sound of Hope: The Story of Possum Trot at http://angel.com/MATT

Shop my merch collection here: https://bit.ly/3EbNwyj

- - - 

Today’s Sponsor:

Birch Gold - Make a qualifying purchase by July 31st and get a GOLDEN Truth Bomb! Text “WALSH” to 989898, or go to https://birchgol

## Men don't like to be manipulated
 - [https://www.youtube.com/watch?v=QoVnq_N4Dew](https://www.youtube.com/watch?v=QoVnq_N4Dew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-02T17:00:19+00:00



## This is a terrible idea from Trump
 - [https://www.youtube.com/watch?v=etOFJcne9k0](https://www.youtube.com/watch?v=etOFJcne9k0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-02T03:00:32+00:00



## Think of your spouse like this
 - [https://www.youtube.com/watch?v=ZI1LhkmsoPY](https://www.youtube.com/watch?v=ZI1LhkmsoPY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-07-02T00:32:49+00:00



