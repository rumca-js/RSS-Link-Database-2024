# Source:Nature Materials, URL:https://www.nature.com/nmat/current_issue/rss, language:en

## Structural dynamics LEEDS the way
 - [https://www.nature.com/articles/s41563-024-01905-0](https://www.nature.com/articles/s41563-024-01905-0)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-07-02T17:09:30.527007+00:00

<p>Nature Materials, Published online: 02 July 2024; <a href="https://www.nature.com/articles/s41563-024-01905-0">doi:10.1038/s41563-024-01905-0</a></p>Tracking the momentum of scattered electrons reveals the temporal evolution of phonon populations on ultrafast timescales, helping to quantify the contributions of the cooperative electronic–lattice order responsible for phase transitions in quantum materials.

## Unfolding a death signal to treat rheumatoid arthritis
 - [https://www.nature.com/articles/s41563-024-01936-7](https://www.nature.com/articles/s41563-024-01936-7)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-07-02T16:04:56.950619+00:00

<p>Nature Materials, Published online: 02 July 2024; <a href="https://www.nature.com/articles/s41563-024-01936-7">doi:10.1038/s41563-024-01936-7</a></p>A pH-activatable DNA origami nanostructure with geometrically patterned CD95 ligands reverses symptoms in a mouse model of rheumatoid arthritis without apparent side effects.

## The need for standardizing fatigue data reporting
 - [https://www.nature.com/articles/s41563-024-01929-6](https://www.nature.com/articles/s41563-024-01929-6)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-07-02T16:04:54.730570+00:00

<p>Nature Materials, Published online: 02 July 2024; <a href="https://www.nature.com/articles/s41563-024-01929-6">doi:10.1038/s41563-024-01929-6</a></p>The need for standardizing fatigue data reporting

## Writing a magnetic whirl on multiferroics
 - [https://www.nature.com/articles/s41563-024-01923-y](https://www.nature.com/articles/s41563-024-01923-y)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-07-02T16:04:53.077490+00:00

<p>Nature Materials, Published online: 02 July 2024; <a href="https://www.nature.com/articles/s41563-024-01923-y">doi:10.1038/s41563-024-01923-y</a></p>Researchers have demonstrated that skyrmion-like topological spin textures can be created in a controlled manner via the local application of an electric field with a tip electrode on a multiferroic BiFeO3 thin film.

## A new slant on colour changes
 - [https://www.nature.com/articles/s41563-024-01944-7](https://www.nature.com/articles/s41563-024-01944-7)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-07-02T16:04:51.242328+00:00

<p>Nature Materials, Published online: 02 July 2024; <a href="https://www.nature.com/articles/s41563-024-01944-7">doi:10.1038/s41563-024-01944-7</a></p>A new slant on colour changes

## Programming topological photonics
 - [https://www.nature.com/articles/s41563-024-01932-x](https://www.nature.com/articles/s41563-024-01932-x)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-07-02T16:04:49.301620+00:00

<p>Nature Materials, Published online: 02 July 2024; <a href="https://www.nature.com/articles/s41563-024-01932-x">doi:10.1038/s41563-024-01932-x</a></p>Harnessing the large-scale integration and individual control of artificial atoms on silicon photonic circuits enables the realization of a rapidly programmable topological photonic chip that can be dynamically reconfigured to explore diverse topological phenomena.

## Lipid discovery for mRNA delivery guided by machine learning
 - [https://www.nature.com/articles/s41563-024-01934-9](https://www.nature.com/articles/s41563-024-01934-9)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-07-02T16:04:47.472290+00:00

<p>Nature Materials, Published online: 02 July 2024; <a href="https://www.nature.com/articles/s41563-024-01934-9">doi:10.1038/s41563-024-01934-9</a></p>Combining machine learning with high-throughput synthesis expedites ionizable cationic lipid development for nanoparticle-based messenger RNA delivery.

## Boosting electromechanical response via clamping
 - [https://www.nature.com/articles/s41563-024-01920-1](https://www.nature.com/articles/s41563-024-01920-1)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-07-02T16:04:45.509223+00:00

<p>Nature Materials, Published online: 02 July 2024; <a href="https://www.nature.com/articles/s41563-024-01920-1">doi:10.1038/s41563-024-01920-1</a></p>The synergy between the field-induced antiferroelectric to ferroelectric phase transition and substrate constraints results in enhanced electromechanical responses.

## Quantifying short-range order using atom probe tomography
 - [https://www.nature.com/articles/s41563-024-01912-1](https://www.nature.com/articles/s41563-024-01912-1)
 - RSS feed: https://www.nature.com/nmat/current_issue/rss
 - date published: 2024-07-02T09:33:55.085437+00:00

<p>Nature Materials, Published online: 02 July 2024; <a href="https://www.nature.com/articles/s41563-024-01912-1">doi:10.1038/s41563-024-01912-1</a></p>A method is introduced to quantify short-range order in multicomponent alloys using atom probe tomography, which enables further understanding and materials design related to atomic-scale solute engineering.

