# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## How Microsoft and Nvidia bet correctly to leapfrog Apple
 - [https://www.bbc.com/news/articles/c4nglq80w7eo](https://www.bbc.com/news/articles/c4nglq80w7eo)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-07-02T23:05:03+00:00

The two tech firms were among the first to see the commercial potential of AI.

## Murdoch Netflix rival to launch in UK
 - [https://www.bbc.com/news/articles/cn385lgk0vjo](https://www.bbc.com/news/articles/cn385lgk0vjo)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-07-02T03:42:10+00:00

Tubi will offer more than 20,000 films and TV series, including Hollywood titles and British content.

