# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## "To jest kpina". Służby reagują na zarzuty Jarosława Kaczyńskiego
 - [https://wydarzenia.interia.pl/kraj/news-to-jest-kpina-sluzby-reaguja-na-zarzuty-jaroslawa-kaczynskie,nId,7620088](https://wydarzenia.interia.pl/kraj/news-to-jest-kpina-sluzby-reaguja-na-zarzuty-jaroslawa-kaczynskie,nId,7620088)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-07-02T17:22:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-to-jest-kpina-sluzby-reaguja-na-zarzuty-jaroslawa-kaczynskie,nId,7620088"><img align="left" alt="&quot;To jest kpina&quot;. Służby reagują na zarzuty Jarosława Kaczyńskiego" src="https://i.iplsc.com/to-jest-kpina-sluzby-reaguja-na-zarzuty-jaroslawa-kaczynskie/000JEKEHEU544A5V-C321.jpg" /></a>- To jest akt bandytyzmu, który powinien zostać ukarany najsurowiej jak można - tak na twierdzenia zatrzymanego ks. Michała Olszewskiego zareagował Jarosław Kaczyński. Winą obarczył funkcjonariuszy ABW oraz ministra spraw wewnętrznych. - Wszystko odbyło się zgodnie z prawem, zgodnie z procedurami - odpowiada rzecznik MSWiA Jacek Dobrzyński, w którego ocenie cała sprawa to &quot;burza w szklance wody&quot;.</p><br clear="all" />

## Prezes PiS reaguje na list księdza Olszewskiego. Wyliczył zarzuty
 - [https://wydarzenia.interia.pl/kraj/news-prezes-pis-reaguje-na-list-ksiedza-olszewskiego-wyliczyl-zar,nId,7619921](https://wydarzenia.interia.pl/kraj/news-prezes-pis-reaguje-na-list-ksiedza-olszewskiego-wyliczyl-zar,nId,7619921)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-07-02T11:50:52+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezes-pis-reaguje-na-list-ksiedza-olszewskiego-wyliczyl-zar,nId,7619921"><img align="left" alt="Prezes PiS reaguje na list księdza Olszewskiego. Wyliczył zarzuty" src="https://i.iplsc.com/prezes-pis-reaguje-na-list-ksiedza-olszewskiego-wyliczyl-zar/000G7T34N71KQ24D-C321.jpg" /></a>- To nie służba więzienna była odpowiedzialna za te zachowania, była odpowiedzialna ABW. W każdym normalnym kraju, skończyłoby się to dymisją szefa MSW - powiedział Jarosław Kaczyński o rzekomej sytuacji ks. Olszewskiego. - My tę sprawę będziemy prowadzić wszelkimi możliwymi sposobami - zapowiedział prezes PiS, odnosząc się do listu przebywającego w areszcie duchownego. Ks. Olszewski skarży się na złe traktowanie. </p><br clear="all" />

## Premier powitał Scholza w Warszawie. Politycy PiS burzą się w sieci
 - [https://wydarzenia.interia.pl/zagranica/news-premier-powital-scholza-w-warszawie-politycy-pis-burza-sie-w,nId,7619626](https://wydarzenia.interia.pl/zagranica/news-premier-powital-scholza-w-warszawie-politycy-pis-burza-sie-w,nId,7619626)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-07-02T07:30:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-premier-powital-scholza-w-warszawie-politycy-pis-burza-sie-w,nId,7619626"><img align="left" alt="Premier powitał Scholza w Warszawie. Politycy PiS burzą się w sieci" src="https://i.iplsc.com/premier-powital-scholza-w-warszawie-politycy-pis-burza-sie-w/000JEGP447OSXE6O-C321.jpg" /></a>Kanclerz Niemiec Olaf Scholz przybył we wtorek do Warszawy i został powitany przez premiera Donalda Tuska. &quot;Że akurat przy okazji tej wizyty jest mowa o przywództwie w Europie... O co tu może chodzić?&quot; - komentują wizytę politycy PiS. Spotkanie obu przywódców oceniają przez pryzmat wpisu, który zamieścił w sieci szef rządu. Napisał w nim o silnym przywództwie i wspólnym stanowisku w kwestiach bezpieczeństwa. Wizyta Scholza w Polsce ma związek z pierwszymi od 2018 roku międzyrządowymi konsultacjami.</p><br clear="all" />

