# Source:BleepingComputer, URL:https://www.bleepingcomputer.com/feed/, language:en-US

## Xbox is down worldwide with users unable to login, play games
 - [https://www.bleepingcomputer.com/news/technology/xbox-is-down-worldwide-with-users-unable-to-login-play-games](https://www.bleepingcomputer.com/news/technology/xbox-is-down-worldwide-with-users-unable-to-login-play-games)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2024-07-02T20:02:32+00:00

The Xbox gaming service is currently down due to a major outage, impacting customers worldwide and preventing them from signing into their accounts and playing games. [...]

## Google now pays $250,000 for KVM zero-day vulnerabilities
 - [https://www.bleepingcomputer.com/news/security/google-now-pays-250-000-for-kvm-zero-day-vulnerabilities](https://www.bleepingcomputer.com/news/security/google-now-pays-250-000-for-kvm-zero-day-vulnerabilities)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2024-07-02T18:06:17+00:00

Google has launched kvmCTF, a new vulnerability reward program (VRP) first announced in October 2023 to improve the security of the Kernel-based Virtual Machine (KVM) hypervisor that comes with $250,000 bounties for full VM escape exploits. [...]

## Patelco shuts down banking systems following ransomware attack
 - [https://www.bleepingcomputer.com/news/security/patelco-shuts-down-banking-systems-following-ransomware-attack](https://www.bleepingcomputer.com/news/security/patelco-shuts-down-banking-systems-following-ransomware-attack)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2024-07-02T17:47:03+00:00

Patelco Credit Union has disclosed it experienced a ransomware attack that led to the proactive shutdown of several of its customer-facing banking systems to contain the incident's impact. [...]

## Affirm says cardholders impacted by Evolve Bank data breach
 - [https://www.bleepingcomputer.com/news/security/affirm-says-cardholders-impacted-by-evolve-bank-data-breach](https://www.bleepingcomputer.com/news/security/affirm-says-cardholders-impacted-by-evolve-bank-data-breach)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2024-07-02T15:57:39+00:00

Buy now, pay later loan company Affirm is warning that holders of its payment cards had their personal information exposed due to a data breach at its third-party issuer, Evolve Bank & Trust (Evolve). [...]

## Google Pixel 6 series phones bricked after factory reset
 - [https://www.bleepingcomputer.com/news/google/google-pixel-6-series-phones-bricked-after-factory-reset](https://www.bleepingcomputer.com/news/google/google-pixel-6-series-phones-bricked-after-factory-reset)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2024-07-02T13:42:01+00:00

Multiple owners of Google Pixel 6 series phones (6, 6a, 6 Pro) have been reporting in the past week that their devices were "bricked" after they performed a factory reset. [...]

