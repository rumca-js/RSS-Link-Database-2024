# Source:NASS, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw, language:en-US

## Vancouver, Canada 1920s in color [60fps,Remastered] w/sound design added
 - [https://www.youtube.com/watch?v=SeSg7_UB0Pg](https://www.youtube.com/watch?v=SeSg7_UB0Pg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC1W8ShdwtfgjRHdbl1Lctcw
 - date published: 2024-07-02T21:32:44+00:00

I colorized , restored and I added a sky visual effect and created a sound design for this video of Vancouver, Canada 1920s, shows the city before the Second World War, with public transport and cars on streets full of pedestrians and cyclists. Other views of Vancouver's nature And these forests and the other And these forests and the lake, Then we have magnificent scenes at the beach,

Video Restoration Process:
✔ FPS boosted to 60 frames per second 
✔ Image resolution boosted up to HD 
✔ Improved video sharpness and brightness 
✔ Colorized only for the ambiance (not historically accurate)
✔sound design added only for the ambiance
✔restoration:(stabilisation,denoise,cleand,deblur) 

Please, be aware that colorization colors are not real and fake, colorization was made only for the ambiance and do not represent real historical data.

B&amp;W Video Source: Library and Archives Canada, Jean-Jacques Joly fonds, 2006-0135 IDC 377634

- - - - - - - - - - - - - - - - - - - -
📨 Contact me at

