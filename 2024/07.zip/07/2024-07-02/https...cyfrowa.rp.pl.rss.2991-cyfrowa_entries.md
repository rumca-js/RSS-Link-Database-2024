# Source:RP - Cyfrowa, URL:https://cyfrowa.rp.pl/rss/2991-cyfrowa, language:pl-PL

## Prawo do darmowej naprawy telefonu i komputera. To ma być rewolucja w elektronice
 - [https://cyfrowa.rp.pl/globalne-interesy/art40756701-prawo-do-darmowej-naprawy-telefonu-i-komputera-to-ma-byc-rewolucja-w-elektronice](https://cyfrowa.rp.pl/globalne-interesy/art40756701-prawo-do-darmowej-naprawy-telefonu-i-komputera-to-ma-byc-rewolucja-w-elektronice)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-07-02T18:45:00+00:00

Bruksela mocno wzięła się za walkę elektrośmieciami – stąd np. unifikacja ładowarek czy uchwalone niedawno tzw. prawo do naprawy, zakazujące producentom blokowania możliwości serwisowania urządzeń. Teraz UE może pójść o krok dalej. Ale jest haczyk.

## Sztuczna inteligencja wsadza do więzienia. Niestety, także niewinnych. Afera w USA
 - [https://cyfrowa.rp.pl/technologie/art40753531-sztuczna-inteligencja-wsadza-do-wiezienia-niestety-takze-niewinnych-afera-w-usa](https://cyfrowa.rp.pl/technologie/art40753531-sztuczna-inteligencja-wsadza-do-wiezienia-niestety-takze-niewinnych-afera-w-usa)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-07-02T13:12:00+00:00

Detroit po kolejnym aresztowaniu wskazanego przez systemy rozpoznawania twarzy, który okazał się niewinny, wycofuje się z tego rodzaju rozwiązań opartych o algorytmy i przestanie ich używać policja.

## Robot otrzymał biologiczny mózg. Zaskakujący efekt
 - [https://cyfrowa.rp.pl/technologie/art40751981-robot-otrzymal-biologiczny-mozg-zaskakujacy-efekt](https://cyfrowa.rp.pl/technologie/art40751981-robot-otrzymal-biologiczny-mozg-zaskakujacy-efekt)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-07-02T08:47:00+00:00

Naukowcy z Chin wyhodowali w laboratorium strukturę komórkową przypominającą mózg, a następnie połączyli ją z systemem neuronowym maszyny. Czy przyszłość należy do takich „żywych robotów”?

