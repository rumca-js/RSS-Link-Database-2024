# Source:In Deep Geek, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCVg2AVe6eTCTVoWQ9AwrIHg, language:en

## The history of Harrenhal
 - [https://www.youtube.com/watch?v=1Cd8bYe5yTI](https://www.youtube.com/watch?v=1Cd8bYe5yTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCVg2AVe6eTCTVoWQ9AwrIHg
 - date published: 2024-07-02T20:00:00+00:00

Explore the best of fantasy and sci-fi in depth, with analysis of the worlds of Lord of the Rings, Game of Thrones, The Witcher and more.

For more A Song of Ice and Fire content: https://www.youtube.com/watch?v=z7DfXK6W-hM&amp;list=PLVTclEEyY1SJdHYUM03vbCmWatFhGDEhz

Join me on Patreon - http://patreon.com/indeepgeek 
My channel for live content, including interviews and weekly livestreams – youtube.com/@IDGlive
My audiobook channel: The Well Told Tale - youtube.com/thewelltoldtale 

Follow me on:
Twitter - @indeepgeek 
Instagram – indeepgeekofficial
Facebook - https://facebook.com/indeepgeek 
TikTok - @indeepgeek
For merch, audiobooks, and all things In Deep Geek, explore my website - www.indeepgeek.com

Thank you to the talented artists who allowed their work to be featured in this video. You can find them and buy your own prints by following the links below:
Amok - https://www.instagram.com/amokrus/
Jota Saraiva - https://www.instagram.com/jota.saraiva.art/
Ruben de Vela - https:/

