# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed, language:en-US

## Watch: Venezuelan illegals establish gang presence in US, film recruitment ads in Times Square
 - [https://www.louderwithcrowder.com/venezuelan-tda-gang-recruitment-ads](https://www.louderwithcrowder.com/venezuelan-tda-gang-recruitment-ads)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-07-02T15:56:10+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52535003&amp;width=1245&amp;height=700&amp;coordinates=93%2C0%2C0%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>According to the left, there is absolutely no way that people from the <a href="https://www.nbcchicago.com/news/local/suspected-members-of-venezuelan-gang-tren-de-aragua-believed-to-be-connected-to-criminal-cases-in-illinois-and-indiana/3462494/#:~:text=Tren%20de%20Aragua%20is%20the,with%20more%20than%205%2C000%20members." target="_blank">largest criminal organization </a>in Venezuela would enter through the southern border if no human is made illegal. The only ones entering this country are those concerned with this country’s <a href="https://www.foxnews.c

## Watch: Trans TikToker about America's DEI military paying for his botox, laser hair removal
 - [https://www.louderwithcrowder.com/chrisays-trans-military-botox](https://www.louderwithcrowder.com/chrisays-trans-military-botox)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-07-02T13:45:49+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52534780&amp;width=2000&amp;height=1500&amp;coordinates=0%2C0%2C77%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Not even 10 years ago, if you said the military would be paying for Botox, laser hair removal, and lip injections people would look at you like you're insane. But here we are in 2024, where if you object to your tax dollars being spent on this then you are considered a bigot. </p><p>A TikTok video is circulating social media after a man made a video talking about how happy he is to be “serving” in the military in a time where his medically unnecessary medical procedures are covered. This includes all the things mentioned above along with the lowering of hi

## CNN host looks on in HORROR over Biden's post-debate polling: "Never seen numbers this bad... "
 - [https://www.louderwithcrowder.com/cnn-latest-joe-biden-polls](https://www.louderwithcrowder.com/cnn-latest-joe-biden-polls)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-07-02T12:52:55+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52534611&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Let me be clear. I maintain that you should ignore all polls put out by the corrupt, fake news, deep state media. You should ONLY be listening to the poll we put through Brodigan Statisticalizationizing Associates. Here are the top lines:</p><ul><li>Donald Trump is two points down, both nationally as well as in all of the United States of the Americas </li><li>There are only five points up for grabs</li><li>This poll will not change until November 6th, so act accordingly until then</li></ul><p>However, for the sake of content, and because bad news for Democr

## Orange man... good? Joe Biden (and his new cheap spray tan) attacks SCOTUS before he pulls this move
 - [https://www.louderwithcrowder.com/joe-biden-spray-tan](https://www.louderwithcrowder.com/joe-biden-spray-tan)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-07-02T11:44:41+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52533318&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C2" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>The Supreme Court finally ruled on the Trump immunity case on Monday, in favor of Trump having some immunity from prosecution over things he did as president. That also means Joe Biden has immunity, so he can't be prosecuted for the things he does as president. I'm sure there are intricacies I'm missing, but LWC Senior Legal Correspondent George the Greek is on vacation and not here to explain it to me like I'm five.</p><p>That's fine. You didn't come here for in-depth legal analysis. You came here to defecate on Joe Biden, who read off of a teleprompter for

