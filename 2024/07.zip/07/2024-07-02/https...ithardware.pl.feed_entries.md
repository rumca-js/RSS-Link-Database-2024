# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Cooler Master prezentuje MasterLiquid 360 Ion - chłodzenie AIO z wyświetlaczem LCD
 - [https://ithardware.pl/aktualnosci/cooler_master_prezentuje_masterliquid_360_ion_chlodzenie_aio_z_wyswietlaczem_lcd-33844.html](https://ithardware.pl/aktualnosci/cooler_master_prezentuje_masterliquid_360_ion_chlodzenie_aio_z_wyswietlaczem_lcd-33844.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T19:21:50+00:00

<img src="https://ithardware.pl/artykuly/min/33844_1.jpg" />            Cooler Master prezentuje chłodzenie&nbsp;cieczą typu all-in-one - MasterLiquid 360 Ion. To AIO zostało wyposażone&nbsp;w wyświetlacz&nbsp;LCD, a także dwukomorową pompę Gen X oraz wentylatory Mobius 120P ARGB.

Sercem MasterLiquid 360 Ion jest...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cooler_master_prezentuje_masterliquid_360_ion_chlodzenie_aio_z_wyswietlaczem_lcd-33844.html">https://ithardware.pl/aktualnosci/cooler_master_prezentuje_masterliquid_360_ion_chlodzenie_aio_z_wyswietlaczem_lcd-33844.html</a></p>

## Team Fortress 2 notuje wzrost graczy po fali banów
 - [https://ithardware.pl/aktualnosci/team_fortress_2_notuje_wzrost_graczy_po_fali_banow-33843.html](https://ithardware.pl/aktualnosci/team_fortress_2_notuje_wzrost_graczy_po_fali_banow-33843.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T18:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/33843_1.jpg" />            Team Fortress 2&nbsp;był krytykowany przez graczy z powodu uporczywych bot&oacute;w. Powstała nawet akcja&nbsp;#SaveTF2, kt&oacute;ra przyniosła zamierzony efekt w postaci ban&oacute;w, kt&oacute;re rozdano w grze. Po tych wydarzeniach gra zn&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/team_fortress_2_notuje_wzrost_graczy_po_fali_banow-33843.html">https://ithardware.pl/aktualnosci/team_fortress_2_notuje_wzrost_graczy_po_fali_banow-33843.html</a></p>

## Microsoft wcisnął więcej reklam do nowej wersji jednej z aplikacji Windowsa 11
 - [https://ithardware.pl/aktualnosci/microsoft_wcisnal_wiecej_reklam_do_nowej_wersji_jednej_z_aplikacji_windowsa_11-33842.html](https://ithardware.pl/aktualnosci/microsoft_wcisnal_wiecej_reklam_do_nowej_wersji_jednej_z_aplikacji_windowsa_11-33842.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T17:53:50+00:00

<img src="https://ithardware.pl/artykuly/min/33842_1.jpg" />            System Windows 11 otrzymał&nbsp;nową wersję aplikacji Pogoda. Wśr&oacute;d zmian znalazła się niestety także większa liczba pojawiających się reklam.

Aplikacja Pogoda w systemie Windows 11 została zaktualizowana. Niestety wygląda na to,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_wcisnal_wiecej_reklam_do_nowej_wersji_jednej_z_aplikacji_windowsa_11-33842.html">https://ithardware.pl/aktualnosci/microsoft_wcisnal_wiecej_reklam_do_nowej_wersji_jednej_z_aplikacji_windowsa_11-33842.html</a></p>

## Apple Intelligence nie będzie darmowe? Część opcji ma być płatna
 - [https://ithardware.pl/aktualnosci/apple_intelligence_nie_bedzie_darmowe_czesc_opcji_ma_byc_platna-33841.html](https://ithardware.pl/aktualnosci/apple_intelligence_nie_bedzie_darmowe_czesc_opcji_ma_byc_platna-33841.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T17:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/33841_1.jpg" />            Apple Intelligence to rozwiązania bazujące na sztucznej inteligencji, kt&oacute;re zmierzają na sprzęt Apple. Chociaż usługa będzie dostępna za darmo, to niewykluczone, że w przyszłości firma z Cupertino będzie pobierać za nią...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_intelligence_nie_bedzie_darmowe_czesc_opcji_ma_byc_platna-33841.html">https://ithardware.pl/aktualnosci/apple_intelligence_nie_bedzie_darmowe_czesc_opcji_ma_byc_platna-33841.html</a></p>

## Noctua NH-D15 G2 oficjalnie. Jakie poprawki oferuje następca legendy?
 - [https://ithardware.pl/aktualnosci/noctua_nh_d15_g2_oficjalnie_jakie_poprawki_oferuje_nastepca_legendy-33840.html](https://ithardware.pl/aktualnosci/noctua_nh_d15_g2_oficjalnie_jakie_poprawki_oferuje_nastepca_legendy-33840.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T16:36:10+00:00

<img src="https://ithardware.pl/artykuly/min/33840_1.jpg" />            Firma Noctua zaprezentowała kolejną generację chłodzenia NH-D15. Wersja G2 posiada nowe wentylatory oraz system montażu SecuFirm2+. Producent przygotował 3 r&oacute;żne wersje w zależności od kształtu procesora.

Kultowe chłodzenie NH-D15...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/noctua_nh_d15_g2_oficjalnie_jakie_poprawki_oferuje_nastepca_legendy-33840.html">https://ithardware.pl/aktualnosci/noctua_nh_d15_g2_oficjalnie_jakie_poprawki_oferuje_nastepca_legendy-33840.html</a></p>

## Assassin's Creed: Shadows obraża Japonię? Gracze chcą anulowania premiery gry
 - [https://ithardware.pl/aktualnosci/assassin_s_creed_shadows_obraza_japonie_gracze_chca_anulowania_premiery_gry-33838.html](https://ithardware.pl/aktualnosci/assassin_s_creed_shadows_obraza_japonie_gracze_chca_anulowania_premiery_gry-33838.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T15:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/33838_1.jpg" />            Assassin's Creed: Shadows po prezentacji spotkał się ze sporą krytyką części graczy, zwłaszcza tych pochodzących z Japonii. Powstała nawet petycja nawołująca do anulowania projektu.

Wiele os&oacute;b wyraziło frustrację związaną z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/assassin_s_creed_shadows_obraza_japonie_gracze_chca_anulowania_premiery_gry-33838.html">https://ithardware.pl/aktualnosci/assassin_s_creed_shadows_obraza_japonie_gracze_chca_anulowania_premiery_gry-33838.html</a></p>

## Resident Evil 9 oficjalnie. Capcom zdradza, kto odpowiada za projekt
 - [https://ithardware.pl/aktualnosci/resident_evil_9_oficjalnie_capcom_zdradza_kto_odpowiada_za_projekt-33837.html](https://ithardware.pl/aktualnosci/resident_evil_9_oficjalnie_capcom_zdradza_kto_odpowiada_za_projekt-33837.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T14:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/33837_1.jpg" />            Capcom zapowiedział w końcu Resident Evil 9. Reżyserem gry został&nbsp;Koshi Nakanishi, kt&oacute;ry odpowiada za Resident Evil 7, czyli jedną z lepszych odsłon kultowej serii. Kiedy nastąpi premiera nowej części?

Resident Evil 9 przewija...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/resident_evil_9_oficjalnie_capcom_zdradza_kto_odpowiada_za_projekt-33837.html">https://ithardware.pl/aktualnosci/resident_evil_9_oficjalnie_capcom_zdradza_kto_odpowiada_za_projekt-33837.html</a></p>

## Jaka kamera do monitoringu domowego? Oto polecane modele!
 - [https://ithardware.pl/poradniki/jaka_kamera_do_monitoringu_domowego_oto_polecane_modele-33834.html](https://ithardware.pl/poradniki/jaka_kamera_do_monitoringu_domowego_oto_polecane_modele-33834.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T12:38:50+00:00

<img src="https://ithardware.pl/artykuly/min/33834_1.jpg" />            Kamery do monitoringu domowego odgrywają kluczową rolę w zapewnieniu bezpieczeństwa i ochrony zar&oacute;wno os&oacute;b, jak i mienia. Widoczność kamer może odstraszać potencjalnych intruz&oacute;w, zmniejszając ryzyko włamań i wandalizmu....
            <p>Pełna wersja strony <a href="https://ithardware.pl/poradniki/jaka_kamera_do_monitoringu_domowego_oto_polecane_modele-33834.html">https://ithardware.pl/poradniki/jaka_kamera_do_monitoringu_domowego_oto_polecane_modele-33834.html</a></p>

## Laptop gamingowy z RTX 3050 i Windowsem w promocji! Trzeba się spieszyć!
 - [https://ithardware.pl/aktualnosci/laptop_gamingowy_z_rtx_4050_i_windowsem_w_promocji_trzeba_sie_spieszyc-33759.html](https://ithardware.pl/aktualnosci/laptop_gamingowy_z_rtx_4050_i_windowsem_w_promocji_trzeba_sie_spieszyc-33759.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T12:30:30+00:00

<img src="https://ithardware.pl/artykuly/min/33759_1.jpg" />            Czy dobry laptop gamingowy z dedykowaną kartą graficzną może kosztować mniej niż 4000 zł? Okazuje się, że tak, bo oto jest, cały na biało HP Victus 15 w świetnej promocji za 3899 zł! Oto, co potrafi.

HP znane jest z tworzenia znakomitych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/laptop_gamingowy_z_rtx_4050_i_windowsem_w_promocji_trzeba_sie_spieszyc-33759.html">https://ithardware.pl/aktualnosci/laptop_gamingowy_z_rtx_4050_i_windowsem_w_promocji_trzeba_sie_spieszyc-33759.html</a></p>

## Francja szykuje oskarżenie przeciw Nvidii. Firma odpowie za działania monopolistyczne
 - [https://ithardware.pl/aktualnosci/francja_szykuje_oskarzenie_przeciw_nvidii_firma_odpowie_za_dzialania_monopolistyczne-33836.html](https://ithardware.pl/aktualnosci/francja_szykuje_oskarzenie_przeciw_nvidii_firma_odpowie_za_dzialania_monopolistyczne-33836.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T12:04:40+00:00

<img src="https://ithardware.pl/artykuly/min/33836_1.jpg" />            Francuski Autorit&eacute; de la concurrence (Urząd ds. Konkurencji) prawdopodobnie wkr&oacute;tce oskarży firmę Nvidia o antykonkurencyjne praktyki biznesowe. Oskarżenia mają się pojawić dziewięć miesięcy po przeprowadzeniu rewizji w biurach...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/francja_szykuje_oskarzenie_przeciw_nvidii_firma_odpowie_za_dzialania_monopolistyczne-33836.html">https://ithardware.pl/aktualnosci/francja_szykuje_oskarzenie_przeciw_nvidii_firma_odpowie_za_dzialania_monopolistyczne-33836.html</a></p>

## Chiński rząd przejął wszystkie lokalne zasoby metali ziem rzadkich
 - [https://ithardware.pl/aktualnosci/chinski_rzad_przejal_wszystkie_lokalne_zasoby_metali_ziem_rzadkich-33835.html](https://ithardware.pl/aktualnosci/chinski_rzad_przejal_wszystkie_lokalne_zasoby_metali_ziem_rzadkich-33835.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T11:29:30+00:00

<img src="https://ithardware.pl/artykuly/min/33835_1.jpg" />            Chiny wprowadziły nowe rozporządzenie, obowiązujące od 1 października, kt&oacute;re potwierdza państwową własność nad materiałami ziem rzadkich niezbędnymi do produkcji p&oacute;łprzewodnik&oacute;w. Ten krok ma na celu zabezpieczenie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chinski_rzad_przejal_wszystkie_lokalne_zasoby_metali_ziem_rzadkich-33835.html">https://ithardware.pl/aktualnosci/chinski_rzad_przejal_wszystkie_lokalne_zasoby_metali_ziem_rzadkich-33835.html</a></p>

## Intel Arrow Lake-S z dużą zmianą w układzie rdzeni. To przyniesie wymierne korzyści
 - [https://ithardware.pl/aktualnosci/intel_arrow_lake_s_z_duza_zmiana_w_ukladzie_rdzeni_to_przyniesie_wymierne_korzysci-33831.html](https://ithardware.pl/aktualnosci/intel_arrow_lake_s_z_duza_zmiana_w_ukladzie_rdzeni_to_przyniesie_wymierne_korzysci-33831.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T11:11:40+00:00

<img src="https://ithardware.pl/artykuly/min/33831_1.jpg" />            Ujawniono możliwy układ kości procesora Intel Arrow Lake-S do komputer&oacute;w stacjonarnych, co daje nam pierwszy rzut oka na nowe rozmieszczenie rdzeni w tych CPU.

Pierwsze trzy generacje procesor&oacute;w klienckich Intela wdrażające...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_arrow_lake_s_z_duza_zmiana_w_ukladzie_rdzeni_to_przyniesie_wymierne_korzysci-33831.html">https://ithardware.pl/aktualnosci/intel_arrow_lake_s_z_duza_zmiana_w_ukladzie_rdzeni_to_przyniesie_wymierne_korzysci-33831.html</a></p>

## Akumulator w elektryku naładujemy w 6 minut od 0 do 100%. Brytyjczycy zapowiadają rewolucję
 - [https://ithardware.pl/aktualnosci/akumulator_w_elektryku_naladujemy_w_6_minut_od_0_do_100_brytyjczycy_zapowiadaja_rewolucje-33833.html](https://ithardware.pl/aktualnosci/akumulator_w_elektryku_naladujemy_w_6_minut_od_0_do_100_brytyjczycy_zapowiadaja_rewolucje-33833.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T10:28:00+00:00

<img src="https://ithardware.pl/artykuly/min/33833_1.jpg" />            Brytyjski start-up Nyobolt, kt&oacute;ry opiera się na 10 latach badań nad akumulatorami prowadzonych na Uniwersytecie w Cambridge, zaprezentował nowy, rewolucyjny typ akumulatora litowego. Innowacyjna bateria, zaprezentowana w sportowym samochodzie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/akumulator_w_elektryku_naladujemy_w_6_minut_od_0_do_100_brytyjczycy_zapowiadaja_rewolucje-33833.html">https://ithardware.pl/aktualnosci/akumulator_w_elektryku_naladujemy_w_6_minut_od_0_do_100_brytyjczycy_zapowiadaja_rewolucje-33833.html</a></p>

## Włamanie do Microsoftu poważniejsze, niż się wydawało. Nowe informacje
 - [https://ithardware.pl/aktualnosci/wlamanie_do_microsoftu_powazniejsze_niz_sie_wydawalo_nowe_informacje-33830.html](https://ithardware.pl/aktualnosci/wlamanie_do_microsoftu_powazniejsze_niz_sie_wydawalo_nowe_informacje-33830.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T10:25:30+00:00

<img src="https://ithardware.pl/artykuly/min/33830_1.jpg" />            Microsoft potwierdził, że 12 stycznia 2024 r. ​​został zhakowany przez cyberprzestępc&oacute;w, kt&oacute;rzy uzyskali dostęp do firmowych kont e-mail firmy, co doprowadziło do kradzieży kont e-mail &bdquo;wyższego kierownictwa&rdquo;...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wlamanie_do_microsoftu_powazniejsze_niz_sie_wydawalo_nowe_informacje-33830.html">https://ithardware.pl/aktualnosci/wlamanie_do_microsoftu_powazniejsze_niz_sie_wydawalo_nowe_informacje-33830.html</a></p>

## Jak działają bottlenecki, czy warto testować CPU w 4K i nie tylko: felieton pomocniczy do testów CPU
 - [https://ithardware.pl/artykuly/czy_warto_testowac_cpu_w_4k_felieton-33663.html](https://ithardware.pl/artykuly/czy_warto_testowac_cpu_w_4k_felieton-33663.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T09:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/33663_1.jpg" />            W dzisiejszym tekście będziemy omawiać m.in. kwestię tego, jak działają tzw. wąskie gardła (ang. bottleneck) ze strony procesora bądź karty graficznej, a także, czy warto badać wydajność CPU w wysokich rozdzielczościach jak 1440p czy 4K....
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/czy_warto_testowac_cpu_w_4k_felieton-33663.html">https://ithardware.pl/artykuly/czy_warto_testowac_cpu_w_4k_felieton-33663.html</a></p>

## Pierwszy kabel Thunderbolt 5 już jest. Przepustowość 120 Gb/s i ładowanie z mocą 240 W
 - [https://ithardware.pl/aktualnosci/pierwszy_kabel_thunderbolt_5_juz_jest_przepustowosc_120_gb_s_i_ladowanie_z_moca_240_w-33829.html](https://ithardware.pl/aktualnosci/pierwszy_kabel_thunderbolt_5_juz_jest_przepustowosc_120_gb_s_i_ladowanie_z_moca_240_w-33829.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T09:36:10+00:00

<img src="https://ithardware.pl/artykuly/min/33829_1.jpg" />            Właśnie wprowadzono na rynek pierwszy na świecie kabel Thunderbolt 5. Takowy zaprezentowała firma Cable Matters i oferuje on pełną przepustowość 120 Gb/s i moc ładowania 240 W, choć jego cena sięga ok. 130 zł. Chociaż Apple potrafi kasować...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pierwszy_kabel_thunderbolt_5_juz_jest_przepustowosc_120_gb_s_i_ladowanie_z_moca_240_w-33829.html">https://ithardware.pl/aktualnosci/pierwszy_kabel_thunderbolt_5_juz_jest_przepustowosc_120_gb_s_i_ladowanie_z_moca_240_w-33829.html</a></p>

## Jeff Bezos żąda ograniczenia Elona Muska i SpaceX. Rzekomo ze względów środowiskowych
 - [https://ithardware.pl/aktualnosci/jeff_bezos_zada_ograniczenia_elona_muska_i_spacex_rzekomo_ze_wzgledow_srodowiskowych-33832.html](https://ithardware.pl/aktualnosci/jeff_bezos_zada_ograniczenia_elona_muska_i_spacex_rzekomo_ze_wzgledow_srodowiskowych-33832.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T09:27:20+00:00

<img src="https://ithardware.pl/artykuly/min/33832_1.jpg" />            Konflikt między miliarderami Elonem Muskiem a Jeffem Bezosem zn&oacute;w się zaostrza. Bezos, właściciel firmy kosmicznej Blue Origin, złożył kolejną skargę na SpaceX, firmę Muska. Tym razem Bezos domaga się wprowadzenia limitu lot&oacute;w,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/jeff_bezos_zada_ograniczenia_elona_muska_i_spacex_rzekomo_ze_wzgledow_srodowiskowych-33832.html">https://ithardware.pl/aktualnosci/jeff_bezos_zada_ograniczenia_elona_muska_i_spacex_rzekomo_ze_wzgledow_srodowiskowych-33832.html</a></p>

## Ryzen 9000 - wiemy, jakie RAM-y będą złotym środkiem dla nowej generacji AMD
 - [https://ithardware.pl/aktualnosci/ryzen_9000_wiemy_jakie_ram_y_beda_zlotym_srodkiem_dla_nowej_generacji_amd-33827.html](https://ithardware.pl/aktualnosci/ryzen_9000_wiemy_jakie_ram_y_beda_zlotym_srodkiem_dla_nowej_generacji_amd-33827.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T08:10:40+00:00

<img src="https://ithardware.pl/artykuly/min/33827_1.jpg" />            Nadchodzące procesory AMD Ryzen 9000 (&bdquo;Granite Ridge&rdquo;) do komputer&oacute;w stacjonarnych &bdquo;Granite Ridge&rdquo; oparte na mikroarchitekturze Zen 5 odnotują niewielką poprawę w zakresie możliwości podkręcania...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ryzen_9000_wiemy_jakie_ram_y_beda_zlotym_srodkiem_dla_nowej_generacji_amd-33827.html">https://ithardware.pl/aktualnosci/ryzen_9000_wiemy_jakie_ram_y_beda_zlotym_srodkiem_dla_nowej_generacji_amd-33827.html</a></p>

## Nowy przeciek wskazuje na duży generacyjny skok procesorów Intel Arrow Lake
 - [https://ithardware.pl/aktualnosci/nowy_przeciek_wskazuje_na_duzy_generacyjny_skok_procesorow_intel_arrow_lake-33828.html](https://ithardware.pl/aktualnosci/nowy_przeciek_wskazuje_na_duzy_generacyjny_skok_procesorow_intel_arrow_lake-33828.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T07:27:00+00:00

<img src="https://ithardware.pl/artykuly/min/33828_1.png" />            Do sieci wyciekł właśnie rzekomy test wydajności desktopowego procesora Arrow Lake, kt&oacute;ry sugeruje, że nowa generacja CPU Intela jest do 20% szybsza w benchmarku jednowątkowym niż Core i9-14900KS.

Test został opublikowany przez...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowy_przeciek_wskazuje_na_duzy_generacyjny_skok_procesorow_intel_arrow_lake-33828.html">https://ithardware.pl/aktualnosci/nowy_przeciek_wskazuje_na_duzy_generacyjny_skok_procesorow_intel_arrow_lake-33828.html</a></p>

## Oto dlaczego PS5 często wypada lepiej od Xbox Series X, choć na papierze jest słabsze
 - [https://ithardware.pl/aktualnosci/oto_dlaczego_ps5_czesto_wypada_lepiej_od_xbox_series_x_choc_na_papierze_jest_slabsze-33826.html](https://ithardware.pl/aktualnosci/oto_dlaczego_ps5_czesto_wypada_lepiej_od_xbox_series_x_choc_na_papierze_jest_slabsze-33826.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T06:42:57+00:00

<img src="https://ithardware.pl/artykuly/min/33826_1.jpg" />            Obecna generacja konsol zbliża się do czwartego roku obecności na rynku, ale jedno pytanie do teraz pozostawało bez odpowiedzi: w jaki spos&oacute;b konsola PS5 od Sony często zapewnia lepszą wydajność niż Xbox Series X, skoro na papierze...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/oto_dlaczego_ps5_czesto_wypada_lepiej_od_xbox_series_x_choc_na_papierze_jest_slabsze-33826.html">https://ithardware.pl/aktualnosci/oto_dlaczego_ps5_czesto_wypada_lepiej_od_xbox_series_x_choc_na_papierze_jest_slabsze-33826.html</a></p>

## Nie tylko Apple. Komisja Europejska grozi ogromną karą także Meta
 - [https://ithardware.pl/aktualnosci/nie_tylko_apple_komisja_europejska_grozi_ogromna_kara_takze_meta-33825.html](https://ithardware.pl/aktualnosci/nie_tylko_apple_komisja_europejska_grozi_ogromna_kara_takze_meta-33825.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-07-02T06:10:23+00:00

<img src="https://ithardware.pl/artykuly/min/33825_1.jpg" />            Pod koniec czerwca Unia Europejska podzieliła się swoimi wstępnymi ustaleniami w związku z postępowaniem przeciwko Apple, twierdząc, że gigant z Cupertino naruszył ustawę o rynkach cyfrowych (DMA), co było pierwszym działaniem regulacyjnym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nie_tylko_apple_komisja_europejska_grozi_ogromna_kara_takze_meta-33825.html">https://ithardware.pl/aktualnosci/nie_tylko_apple_komisja_europejska_grozi_ogromna_kara_takze_meta-33825.html</a></p>

