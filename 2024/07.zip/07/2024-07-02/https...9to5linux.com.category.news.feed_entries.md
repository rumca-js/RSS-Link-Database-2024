# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## KDE Plasma 6.1.2 Is Out to Improve the Overview Effect and Fix More Issues
 - [https://9to5linux.com/kde-plasma-6-1-2-is-out-to-improve-the-overview-effect-and-fix-more-issues](https://9to5linux.com/kde-plasma-6-1-2-is-out-to-improve-the-overview-effect-and-fix-more-issues)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-07-02T19:19:56+00:00

<p>KDE Plasma 6.1.2 is now available as the second maintenance update to the latest KDE Plasma 6.1 desktop environment series with more bug fixes. Here are the details!</p>
<p>The post <a href="https://9to5linux.com/kde-plasma-6-1-2-is-out-to-improve-the-overview-effect-and-fix-more-issues">KDE Plasma 6.1.2 Is Out to Improve the Overview Effect and Fix More Issues</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Nitrux 3.5.1 Released with Linux Kernel 6.9 and NVIDIA 555 Graphics Driver
 - [https://9to5linux.com/nitrux-3-5-1-released-with-linux-kernel-6-9-and-nvidia-555-graphics-driver](https://9to5linux.com/nitrux-3-5-1-released-with-linux-kernel-6-9-and-nvidia-555-graphics-driver)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-07-02T09:11:29+00:00

<p>Nitrux 3.5.1 immutable and systemd-free distribution is now available for download with Linux kernel 6.9, NVIDIA 555.58, and Mesa 24.1. Here's what else is new!</p>
<p>The post <a href="https://9to5linux.com/nitrux-3-5-1-released-with-linux-kernel-6-9-and-nvidia-555-graphics-driver">Nitrux 3.5.1 Released with Linux Kernel 6.9 and NVIDIA 555 Graphics Driver</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

