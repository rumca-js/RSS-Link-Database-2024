# Source:IGN All, URL:https://feeds.feedburner.com/ign/all, language:en

## Xbox Live Suffers Widespread Outage, Xbox Support 'Investigating'
 - [https://www.ign.com/articles/xbox-live-suffers-widespread-outage-xbox-support-investigating](https://www.ign.com/articles/xbox-live-suffers-widespread-outage-xbox-support-investigating)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T20:25:00+00:00



## Tales of Kenzera: Zau Developer Surgent Studios Hit With Layoffs
 - [https://www.ign.com/articles/tales-of-kenzera-zau-developer-surgent-studios-hit-with-layoffs](https://www.ign.com/articles/tales-of-kenzera-zau-developer-surgent-studios-hit-with-layoffs)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T20:09:35+00:00

Tales of Kenzera: Zau developer Surgent Studios has been hit with a round of layoffs affecting about a dozen employees, the studio confirmed today.

## Save 40% Off the Seagate Starfield Edition 8TB Game Hub Hard Drive
 - [https://www.ign.com/articles/save-40-off-the-seagate-starfield-edition-8tb-game-hub-hard-drive](https://www.ign.com/articles/save-40-off-the-seagate-starfield-edition-8tb-game-hub-hard-drive)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T19:55:00+00:00

Decked out in Starfield livery and RGB lighting

## Elden Ring Community Heroes Like Let Me Solo Her Helped Inspire The Acolyte's Hit Villain
 - [https://www.ign.com/articles/elden-ring-community-heroes-like-let-me-solo-her-helped-inspire-the-acolytes-hit-villain](https://www.ign.com/articles/elden-ring-community-heroes-like-let-me-solo-her-helped-inspire-the-acolytes-hit-villain)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T19:39:28+00:00

The Acolyte showrunner Leslye Headland recently revealed that The Master's flowy armor (and exposed muscles) were inspired by scantily clad Elden Ring badasses like Let Me Solo Her.

## Neva Is a Stunning New Puzzle Platformer From the Makers of GRIS
 - [https://www.ign.com/articles/neva-is-a-stunning-new-puzzle-platformer-from-the-makers-of-gris](https://www.ign.com/articles/neva-is-a-stunning-new-puzzle-platformer-from-the-makers-of-gris)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T19:29:06+00:00

Neva, a new puzzle-platformer from the makers of GRIS, was one of many games we played during June’s various summer gaming preview events, and it’s one of the few we're still thinking about weeks later. It looks like it has the potential to be very, very special.

## Save Over 20% Off Nintendo Switch Joy-Con Controllers
 - [https://www.ign.com/articles/save-over-20-off-nintendo-switch-joy-con-controllers](https://www.ign.com/articles/save-over-20-off-nintendo-switch-joy-con-controllers)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T18:20:00+00:00

Probably cheaper than on Amazon Prime Day

## Zack Snyder Teases That Justice League Could Be Coming to Theaters
 - [https://www.ign.com/articles/zack-snyder-teases-that-justice-league-could-be-coming-to-theaters](https://www.ign.com/articles/zack-snyder-teases-that-justice-league-could-be-coming-to-theaters)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T17:44:40+00:00

Two years after Zack Snyder's Justice League premiered on HBO Max, Snyder has taken to social media to tease the possibility that his DC crossover film will finally get a theatrical release.

## Save $700 Off the Most Powerful Alienware m18 Gaming Laptop During the Dell 4th of July Sale
 - [https://www.ign.com/articles/save-700-off-the-most-powerful-alienware-m18-gaming-laptop-during-the-dell-4th-of-july-sale](https://www.ign.com/articles/save-700-off-the-most-powerful-alienware-m18-gaming-laptop-during-the-dell-4th-of-july-sale)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T17:40:00+00:00



## Dragon Age: The Veilguard Reveals a Host of Customizable Difficulty Options, Including the Ability to Turn Death Off Entirely
 - [https://www.ign.com/articles/dragon-age-the-veilguard-reveals-a-host-of-customizable-difficulty-options-including-the-ability-to-turn-death-off-entirely](https://www.ign.com/articles/dragon-age-the-veilguard-reveals-a-host-of-customizable-difficulty-options-including-the-ability-to-turn-death-off-entirely)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T17:20:02+00:00

Dragon Age: The Veilguard will have a number of difficulty options that allow players to tweak the experience to their liking, including turning off death entirely.

## Nintendo's Latest Piracy Lawsuit Hits Switch Modding Company After It Refused to Shut Down
 - [https://www.ign.com/articles/nintendos-latest-piracy-lawsuit-hits-switch-modding-company-after-it-refused-to-shut-down](https://www.ign.com/articles/nintendos-latest-piracy-lawsuit-hits-switch-modding-company-after-it-refused-to-shut-down)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T17:03:02+00:00

Nintendo's stream of lawsuits targeting alleged Nintendo Switch pirates has continued, but the latest defendant doesn't seem too concerned about the colossal company's threats.

## Call of Duty Warzone Patch Nerfs the Kar98k and Superi 46
 - [https://www.ign.com/articles/call-of-duty-warzone-patch-nerfs-the-kar98k-and-superi-46](https://www.ign.com/articles/call-of-duty-warzone-patch-nerfs-the-kar98k-and-superi-46)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T16:39:38+00:00

An update for Call of Duty Warzone and Modern Warfare 3 has made a number of significant weapon balance changes. Check out the patch notes.

## Move Over Barbenheimer, Wicked and Gladiator 2 Are 2024's Unexpected Double Bill
 - [https://www.ign.com/articles/barbenheimer-wicked-gladiator-2-this-years-unexpected-double-bill](https://www.ign.com/articles/barbenheimer-wicked-gladiator-2-this-years-unexpected-double-bill)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T16:17:58+00:00

Wicked and Gladiator 2 have become the internet's new Barbenheimer, as the two movies now share the same release date.

## Batman: Caped Crusader: Here’s Who Is Voicing Allies Like Gordon and Alfred
 - [https://www.ign.com/articles/batman-caped-crusader-voice-cast-allies-gordon-alfred-lucius-montoya](https://www.ign.com/articles/batman-caped-crusader-voice-cast-allies-gordon-alfred-lucius-montoya)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T16:00:00+00:00

On the heels of our exclusive trailer debut and cover story for Batman: Caped Crusader, IGN can also reveal the voice actors portraying Batman’s closest allies like Alfred and Commissioner Gordon in the new Prime Video animated series.

## Eagle-Eyed GTA Fan Spots a Single Piece of Jewelry From the GTA 6 Trailer in the New GTA Online Update
 - [https://www.ign.com/articles/eagle-eyed-gta-fan-spots-a-single-piece-of-jewelry-from-the-gta-6-trailer-in-the-new-gta-online-update](https://www.ign.com/articles/eagle-eyed-gta-fan-spots-a-single-piece-of-jewelry-from-the-gta-6-trailer-in-the-new-gta-online-update)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T15:07:05+00:00

GTA fans have spotted a nod to GTA 6 in the latest GTA Online update.

## Best Nintendo Switch Battery Case 2024
 - [https://www.ign.com/articles/best-nintendo-switch-battery-case](https://www.ign.com/articles/best-nintendo-switch-battery-case)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T15:00:55+00:00

Don't let a dead battery torpedo a Switch marathon. Here's our picks for the best battery cases for the Nintendo Switch.

## College Football 25: EA Sports Shares New Details on Dynasty Mode
 - [https://www.ign.com/articles/college-football-25-ea-sports-shares-new-details-on-dynasty-mode](https://www.ign.com/articles/college-football-25-ea-sports-shares-new-details-on-dynasty-mode)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T15:00:00+00:00

EA Sports has shared new details on fan-favorite Dynasty Mode, revealing the many creative tools players will have access to on their quest to build a dynasty in college football.

## Assassin's Creed Shadows Seemingly Features a Takedown Animation Cut From Assassin's Creed 3
 - [https://www.ign.com/articles/assassins-creed-shadows-seemingly-features-a-takedown-animation-cut-from-assassins-creed-3](https://www.ign.com/articles/assassins-creed-shadows-seemingly-features-a-takedown-animation-cut-from-assassins-creed-3)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T14:55:48+00:00

Ubisoft appears to have revived a takedown animation spotted in a 2012 Assassin's Creed 3 demo for upcoming Japan-set Assassin's Creed Shadows.

## The Acolyte Showrunner Confirms Kylo Ren Easter Egg Was Included 'On Purpose'
 - [https://www.ign.com/articles/the-acolyte-showrunner-kylo-ren-easter-egg-on-purpose](https://www.ign.com/articles/the-acolyte-showrunner-kylo-ren-easter-egg-on-purpose)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T14:38:56+00:00

The Acolyte showrunner Leslye Headland has confirmed Episode 5 includes an intentional nod to Kylo Ren but says fans will have to wait and see to find out what it means.

## James Gunn Says Don't Worry, Set Leaks Won't Spoil the DCU's Superman
 - [https://www.ign.com/articles/james-gunn-says-dont-worry-set-leaks-wont-spoil-the-dcus-superman](https://www.ign.com/articles/james-gunn-says-dont-worry-set-leaks-wont-spoil-the-dcus-superman)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T14:04:47+00:00

Despite a handful of Superman set photo leaks appearing online, DC Studios co-CEO James Gunn has reassured fans they won't spoil a thing.

## McDonald Has Made a Jujutsu Kaisen-Themed Special Grade Garlic Sauce
 - [https://www.ign.com/articles/mcdonald-has-made-a-jujutsu-kaisen-themed-special-grade-garlic-sauce](https://www.ign.com/articles/mcdonald-has-made-a-jujutsu-kaisen-themed-special-grade-garlic-sauce)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T14:03:48+00:00

McDonald’s is launching a new sauce inspired by hit anime Jujutsu Kaisen.

## Transformers Is Getting a Racing Adventure Game With Rogue-Lite Elements
 - [https://www.ign.com/articles/transformers-is-getting-a-racing-adventure-game-with-rogue-lite-elements](https://www.ign.com/articles/transformers-is-getting-a-racing-adventure-game-with-rogue-lite-elements)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T13:54:25+00:00

Transformers is getting a racing adventure rogue-lite called Transformers: Galactic Trials, due out in October on PC and consoles.

## Microsoft Confirms Xbox Game Pass July 2024 Wave 1 Lineup
 - [https://www.ign.com/articles/microsoft-confirms-xbox-game-pass-july-2024-wave-1-lineup](https://www.ign.com/articles/microsoft-confirms-xbox-game-pass-july-2024-wave-1-lineup)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T13:17:37+00:00

Microsoft has confirmed the Xbox Game Pass July 2024 Wave 1 lineup. Here's what's coming.

## Amazon Is Giving Away 3 Months of Kindle Unlimited For Free Before Prime Day
 - [https://www.ign.com/articles/amazon-3-months-of-kindle-unlimited-prime-day-free-2024](https://www.ign.com/articles/amazon-3-months-of-kindle-unlimited-prime-day-free-2024)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T12:31:48+00:00

As part of early Prime Day deals, you can score three months of Kindle Unlimited for free right now. Read comics like All-Star Superman for free!

## Star Trek: Prodigy Season 2’s Janeway Could’ve Captained the Enterprise (But Kate Mulgrew Said No)
 - [https://www.ign.com/articles/star-trek-prodigy-season-2-janeway-couldve-captain-enterprise-kate-mulgrew-said-no](https://www.ign.com/articles/star-trek-prodigy-season-2-janeway-couldve-captain-enterprise-kate-mulgrew-said-no)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T12:30:00+00:00

Showrunners Kevin and Dan Hageman on the miracle resurrection of Star Trek: Prodigy, including what’s happening for the kids in Season 2, how Kate Mulgrew (rightfully) nixed the idea of Admiral Janeway taking command of the USS Enterprise, and the realities of a potential Season 3.

## Looks Like Scorpion From Mortal Kombat Is Coming to MultiVersus
 - [https://www.ign.com/articles/looks-like-scorpion-from-mortal-kombat-is-coming-to-multiversus](https://www.ign.com/articles/looks-like-scorpion-from-mortal-kombat-is-coming-to-multiversus)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T12:29:41+00:00

A developer on MultiVersus has hinted that Scorpion from Mortal Kombat is set to hit the brawler.

## We've Found Some Incredible New Deals at Dell This Week, Including Big Discounts on Alienware
 - [https://www.ign.com/articles/dell-pc-incredible-new-deals-big-discounts-on-alienware-uk](https://www.ign.com/articles/dell-pc-incredible-new-deals-big-discounts-on-alienware-uk)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T12:23:50+00:00

Dell UK has just launched some amazing offers on their range of Notebook, Alienware, PCs, Accessories and AI-powered PCs, here's the best deals.

## Ridley Scott Says He 'Should Have' Directed Original Alien Sequels, but He Was 'Never Asked'
 - [https://www.ign.com/articles/ridley-scott-should-have-directed-original-alien-sequels-never-asked](https://www.ign.com/articles/ridley-scott-should-have-directed-original-alien-sequels-never-asked)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T12:00:06+00:00

Director Ridley Scott has revealed he "was never told or asked" about the original sequels to Alien but feels he "should have" returned for them.

## Original Frank West Voice Actor Says Capcom Didn't Ask Him to Return for Dead Rising Deluxe Remaster
 - [https://www.ign.com/articles/original-frank-west-voice-actor-says-capcom-didnt-ask-him-to-return-for-dead-rising-deluxe-remaster](https://www.ign.com/articles/original-frank-west-voice-actor-says-capcom-didnt-ask-him-to-return-for-dead-rising-deluxe-remaster)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T11:54:29+00:00

Dead Rising Deluxe Remaster brings back the classic zombie game without its original voice actor, who has said publisher Capcom didn't ask him to return.

## Call of Duty’s New ‘Extra Crispy’ Gun Lets You Cook, Eat, and Turn Your Enemies Into Fried Chicken and People Are Blaming It All on Fortnite Once Again
 - [https://www.ign.com/articles/call-of-dutys-new-extra-crispy-gun-lets-you-cook-eat-and-turn-your-enemies-into-fried-chicken-and-people-are-blaming-it-all-on-fortnite-once-again](https://www.ign.com/articles/call-of-dutys-new-extra-crispy-gun-lets-you-cook-eat-and-turn-your-enemies-into-fried-chicken-and-people-are-blaming-it-all-on-fortnite-once-again)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T11:31:48+00:00

Call of Duty’s new ‘Extra Crispy’ gun is being roasted online, but Activision is leaning into the backlash.

## The Fantastic Four's Joseph Quinn Has Practiced Johnny Storm's Catchphrase a Lot
 - [https://www.ign.com/articles/the-fantastic-fours-joseph-quinn-has-practiced-johnny-storms-catchphrase-a-lot](https://www.ign.com/articles/the-fantastic-fours-joseph-quinn-has-practiced-johnny-storms-catchphrase-a-lot)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T11:30:18+00:00

The iconic catchphrase "Flame on" is perhaps one of the most famous Marvel lines, and The Fantastic Four's Johnny Storm actor Joseph Quinn has practiced it a lot.

## Why the Internet Is Comparing Cristiano Ronaldo to Homelander
 - [https://www.ign.com/articles/why-the-internet-is-comparing-cristiano-ronaldo-to-homelander](https://www.ign.com/articles/why-the-internet-is-comparing-cristiano-ronaldo-to-homelander)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T11:06:03+00:00

Here's why the internet is comparing Portugal star Cristiano Ronaldo to Homelander from The Boys.

## The Sandman Season 2 Adds a Slew of New Cast Members, Including Multiple Game of Thrones Alums
 - [https://www.ign.com/articles/the-sandman-season-2-adds-a-slew-of-new-cast-members-including-multiple-game-of-thrones-alums](https://www.ign.com/articles/the-sandman-season-2-adds-a-slew-of-new-cast-members-including-multiple-game-of-thrones-alums)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T11:00:00+00:00

Netflix has announced nine new cast members for The Sandman Season 2, including three actors with Game of Thrones on their resumes.

## Tech Experts Reveal Why Some Games Run Better on PS5 Despite Xbox Series X Being More Powerful
 - [https://www.ign.com/articles/tech-experts-reveal-why-some-games-run-better-on-ps5-despite-xbox-series-x-being-more-powerful](https://www.ign.com/articles/tech-experts-reveal-why-some-games-run-better-on-ps5-despite-xbox-series-x-being-more-powerful)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T09:23:36+00:00

It is widely accepted that Microsoft’s Xbox Series X console is the most powerful ever made, so why do some games run better on Sony’s PlayStation 5? That’s a question finally answered by the tech experts at Digital Foundry.

## The Latest Final Fantasies Go 40% off, Smashing Steam Sales Continue to Amaze, and More!
 - [https://www.ign.com/articles/the-latest-final-fantasies-go-40-off-smashing-steam-sales-continue-to-amaze-and-more-au-deals](https://www.ign.com/articles/the-latest-final-fantasies-go-40-off-smashing-steam-sales-continue-to-amaze-and-more-au-deals)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T01:55:46+00:00



## The Best SD Cards for Nintendo Switch in 2024
 - [https://www.ign.com/articles/best-sd-cards-for-nintendo-switch](https://www.ign.com/articles/best-sd-cards-for-nintendo-switch)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-07-02T01:20:00+00:00

Time for a storage upgrade?

