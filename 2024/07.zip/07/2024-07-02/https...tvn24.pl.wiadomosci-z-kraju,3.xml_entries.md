# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Sąd odroczył ogłoszenie wyroku w sprawie karnej Trumpa
 - [https://tvn24.pl/swiat/usa-sad-w-nowym-jorku-odroczyl-ogloszenie-wyroku-w-sprawie-karnej-donalda-trumpa-st7988514?source=rss](https://tvn24.pl/swiat/usa-sad-w-nowym-jorku-odroczyl-ogloszenie-wyroku-w-sprawie-karnej-donalda-trumpa-st7988514?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T20:39:54+00:00

<img alt="Sąd odroczył ogłoszenie wyroku w sprawie karnej Trumpa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1511540-sad-odroczyl-ogloszenie-wyroku-w-sprawie-karnej-trumpa-ph7988511/alternates/LANDSCAPE_1280" />
    Nowojorski sąd odroczył do 18 września ogłoszenie wyroku w sprawie Donalda Trumpa dotyczącego skazania za zatajenie wypłacenia pieniędzy gwieździe porno. Decyzja ta ma związek z wnioskiem prawników Trumpa o uznanie, że były prezydent USA zachował immunitet.

## Prześwietlili ceny mieszkań w ponad 50 krajach. Polska na podium
 - [https://tvn24.pl/biznes/nieruchomosci/ceny-mieszkan-w-polsce-wzrosly-nominalnie-o-13-proc-w-ciagu-ostatnich-12-miesiecy-st7987977?source=rss](https://tvn24.pl/biznes/nieruchomosci/ceny-mieszkan-w-polsce-wzrosly-nominalnie-o-13-proc-w-ciagu-ostatnich-12-miesiecy-st7987977?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T19:27:51+00:00

<img alt="Prześwietlili ceny mieszkań w ponad 50 krajach. Polska na podium" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b4n2df-mieszkanie-mieszkania-dom-shutterstock1535109122-4553010/alternates/LANDSCAPE_1280" />
    Ceny mieszkań w Polsce wzrosły nominalnie o 13 procent w ciągu ostatnich 12 miesięcy - wynika z raportu Knight Frank. Jest to trzeci wynik wśród 56 rynków mieszkaniowych na świecie analizowanych przez firmę.

## Co z subwencją dla PiS? Odpowiada Krajowe Biuro Wyborcze
 - [https://tvn24.pl/polska/co-z-subwencja-dla-pis-odpowiada-krajowe-biuro-wyborcze-st7988041?source=rss](https://tvn24.pl/polska/co-z-subwencja-dla-pis-odpowiada-krajowe-biuro-wyborcze-st7988041?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T14:07:21+00:00

<img alt="Co z subwencją dla PiS? Odpowiada Krajowe Biuro Wyborcze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8678758-pap2024060907k-ph7988075/alternates/LANDSCAPE_1280" />
    Przepisy "nie przewidują możliwości wznowienia postępowania w zakończonych już sprawach, w których zapadła prawomocna uchwała PKW" - przekazało we wtorek Krajowe Biuro Wyborcze. Chodzi o sprawozdanie finansowe PiS za wybory parlamentarne z 2019 roku i wiedzę Jarosława Kaczyńskiego o wątpliwościach związanych z wydatkowaniem Funduszu Sprawiedliwości. PKW cały czas ocenia sprawozdanie finansowe PiS z wyborów w 2023 roku.

## Beczkowóz stanął między drzewami, osobówka ma rozbity przód. Dwie osoby w szpitalu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/niegow-zderzenie-beczkowozu-i-osobowki-dwie-osoby-w-szpitalu-st7987743?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/niegow-zderzenie-beczkowozu-i-osobowki-dwie-osoby-w-szpitalu-st7987743?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T11:55:31+00:00

<img alt="Beczkowóz stanął między drzewami, osobówka ma rozbity przód. Dwie osoby w szpitalu " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2438406-wypadek-w-niegowie-ph7987804/alternates/LANDSCAPE_1280" />
    Pod Wyszkowem zderzył się beczkowóz oraz samochód osobowy. Dwie osoby trafiły do szpitala. Policjanci ustalili, że przyczyną wypadku było nieustąpienie pierwszeństwa.

## Wystarczy pół promila, by stracić auto. Projekt ostrzejszych kar dla pijanych kierowców
 - [https://tvn24.pl/biznes/moto/konfiskata-samochodu-po-05-promila-ministerstwo-sprawiedliwosci-pracuje-nad-zaostrzeniem-przepisow-dla-pijanych-kierowcow-st7987557?source=rss](https://tvn24.pl/biznes/moto/konfiskata-samochodu-po-05-promila-ministerstwo-sprawiedliwosci-pracuje-nad-zaostrzeniem-przepisow-dla-pijanych-kierowcow-st7987557?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T10:53:27+00:00

<img alt="Wystarczy pół promila, by stracić auto. Projekt ostrzejszych kar dla pijanych kierowców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3594864-shutterstock2213211583-ph7987595/alternates/LANDSCAPE_1280" />
    Wkrótce wystarczy jedno piwo lub lampka wina, by sąd mógł zadecydować o konfiskacie pojazdu. Jak podaje "Dziennik Gazeta Prawna", z projektu nowelizacji przepisów wynika, że już powyżej 0,5, a nie od 1,5 promila sąd będzie mógł orzec konfiskatę pojazdu. To odpowiedź na rekomendacje prawników, którzy podkreślali, że wartości progowe są niesprawiedliwe i utrudniają dostosowanie kary do specyfiki danej sprawy.

## Policjanci zastrzeleni w radiowozie. Maksymilian F. trafi na obserwację
 - [https://tvn24.pl/wroclaw/wroclaw-zastrzeleni-policjanci-w-radiowozie-maksymilian-f-trafi-na-obserwacje-psychiatryczna-st7987477?source=rss](https://tvn24.pl/wroclaw/wroclaw-zastrzeleni-policjanci-w-radiowozie-maksymilian-f-trafi-na-obserwacje-psychiatryczna-st7987477?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T10:53:17+00:00

<img alt="Policjanci zastrzeleni w radiowozie. Maksymilian F. trafi na obserwację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rs6duh-doprowadzenie-do-prokuratury-mezczyzny-ktory-zaatakowal-z-bronia-w-reku-dwoch-policjantow-7476468/alternates/LANDSCAPE_1280" />
    Sąd Okręgowy we Wrocławiu skierował podejrzanego o zabójstwo policjantów na czterotygodniową obserwację psychiatryczną. Do zdarzenia doszło na początku grudnia w 2023 roku. Dwóch policjantów zostało postrzelonych w czasie konwojowania mężczyzny. Funkcjonariusze zmarli w szpitalu.

## Pudełko z kopertami i kartkami z wesela zostawili w domku. Gdy wrócili z zabawy, już go nie było
 - [https://tvn24.pl/tvnwarszawa/najnowsze/szumin-zostali-okradzeni-podczas-wlasnego-wesela-zniknelo-pudelko-z-kopertami-i-kartkami-chca-odzyskac-chociaz-kartki-st7987159?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/szumin-zostali-okradzeni-podczas-wlasnego-wesela-zniknelo-pudelko-z-kopertami-i-kartkami-chca-odzyskac-chociaz-kartki-st7987159?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T10:52:58+00:00

<img alt="Pudełko z kopertami i kartkami z wesela zostawili w domku. Gdy wrócili z zabawy, już go nie było " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2600581-mlodej-parze-skradziono-koperte-z-pieniedzmi-zdjecie-ilustracyjne-ph7987167/alternates/LANDSCAPE_1280" />
    Nieznany sprawca zniszczył młodej parze najpiękniejszy dzień w ich życiu. Z domku, sąsiadującego z miejscem przyjęcia, zniknęło pudełko z kopertami, otrzymanymi od gości weselnych. Państwo młodzi stracili pokaźną sumę pieniędzy oraz kartki, będące pamiątką ślubu. - Zabrali nam najfajniejsze wspomnienia z tego dnia - mówi panna młoda.

## Spadł w nocy z półki skalnej. Rano ktoś usłyszał wołanie o pomoc
 - [https://tvn24.pl/kielce/kielce-mezczyzna-spadl-z-polki-skalnej-w-rezerwacie-wietrznia-akcja-ratunkowa-w-dawnym-kamieniolomie-st7987547?source=rss](https://tvn24.pl/kielce/kielce-mezczyzna-spadl-z-polki-skalnej-w-rezerwacie-wietrznia-akcja-ratunkowa-w-dawnym-kamieniolomie-st7987547?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T10:51:28+00:00

<img alt="Spadł w nocy z półki skalnej. Rano ktoś usłyszał wołanie o pomoc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4960593-rezerwat-przyrody-wietrznia-w-kielcach-ph7987536/alternates/LANDSCAPE_1280" />
    45-latek przez całą noc czekał na pomoc po tym, jak w rezerwacie przyrody w Kielcach spadł z półki skalnej. Krzyki rannego, wychłodzonego mężczyzny usłyszał rano przypadkowy przechodzień.

## Bon energetyczny od 1 lipca. Dla kogo i od kiedy wnioski?
 - [https://tvn24.pl/biznes/z-kraju/bon-energetyczny-od-1-lipca-2024-dla-kogo-i-od-kiedy-wnioski-st7987488?source=rss](https://tvn24.pl/biznes/z-kraju/bon-energetyczny-od-1-lipca-2024-dla-kogo-i-od-kiedy-wnioski-st7987488?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T09:42:55+00:00

<img alt="Bon energetyczny od 1 lipca. Dla kogo i od kiedy wnioski?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-li3u9e-prad-shutterstock_2037808247-7882855/alternates/LANDSCAPE_1280" />
    Około 3,5 miliona gospodarstw domowych o niższych dochodach będzie mogło skorzystać z bonu energetycznego. Dopłaty do rachunków za prąd i gaz będą za okres od 1 lipca do 31 grudnia. W programie wskazano progi dochodowe.

## Ogień blisko greckich kurortów. Ewakuacje, chaos, "ludzie leżeli obok siebie jak śledzie"
 - [https://tvn24.pl/tvnmeteo/swiat/grecja-ogien-blisko-kurortow-ewakuacje-chaos-ludzie-lezeli-obok-siebie-jak-sledzie-st7987334?source=rss](https://tvn24.pl/tvnmeteo/swiat/grecja-ogien-blisko-kurortow-ewakuacje-chaos-ludzie-lezeli-obok-siebie-jak-sledzie-st7987334?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T08:44:52+00:00

<img alt="Ogień blisko greckich kurortów. Ewakuacje, chaos, " src="https://kontakt24.tvn24.pl/najnowsze/cdn-zdjecie-9981802-kos-ph7987137/alternates/LANDSCAPE_1280" />
    Trwa walka z pożarami, które trawią greckie wyspy. We wtorek strażacy walczyli z żywiołem m. in. na wyspie Kos, w okresie letnim niezwykle popularnej wśród plażowiczów. Na Kontakt 24 otrzymaliśmy relacje polskich turystów, którzy byli na urlopie, gdy doszło do pożaru.

## Kot utknął w odpływie. Pomogli mu strażacy
 - [https://tvn24.pl/wroclaw/jelenia-gora-kotek-utknal-w-odplywie-na-deszczowke-akcja-strazakow-st7987287?source=rss](https://tvn24.pl/wroclaw/jelenia-gora-kotek-utknal-w-odplywie-na-deszczowke-akcja-strazakow-st7987287?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T07:42:10+00:00

<img alt="Kot utknął w odpływie. Pomogli mu strażacy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5984255-strazacy-uratowali-kotka-ktory-utknal-w-odplywie-na-deszczowke-ph7987282/alternates/LANDSCAPE_1280" />
    Nietypowe zgłoszenie trafiło do straży pożarnej w Jeleniej Górze. Tam mały kotek został uwięziony w odpływie wody deszczowej. Zwierzaka udało się uratować dzięki użyciu kamery wziernikowej oraz specjalistycznego sprzętu.

## Ostatnie Pokolenie zablokowało aleję "Solidarności". "Atmosfera jest napięta"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ostatnie-pokolenie-zablokowana-aleja-solidarnosci-przepychanki-i-utarczki-slowne-st7987184?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ostatnie-pokolenie-zablokowana-aleja-solidarnosci-przepychanki-i-utarczki-slowne-st7987184?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T06:30:38+00:00

<img alt="Ostatnie Pokolenie zablokowało aleję " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-7975064-aktywisci-zablokowali-aleje-solidarnosci-ph7987207/alternates/LANDSCAPE_1280" />
    Ostatnie Pokolenie zablokowało aleję "Solidarności", przy metrze Dworzec Wileński. Nieprzejezdna jest jezdnia w kierunku Targówka. Aktywiści przykleili się do asfaltu. Doszło do kilku incydentów. - Atmosfera jest napięta - relacjonuje reporter tvnwarszawa.pl. Na miejscu pracują policjanci.

## Zmarła włoska aktorka Maria Rosaria Omaggio. Zagrała u Wajdy słynną dziennikarkę
 - [https://tvn24.pl/kultura-i-styl/maria-rosaria-omaggio-nie-zyje-grala-slynna-dziennikarke-u-wajdy-st7987185?source=rss](https://tvn24.pl/kultura-i-styl/maria-rosaria-omaggio-nie-zyje-grala-slynna-dziennikarke-u-wajdy-st7987185?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T06:26:47+00:00

<img alt="Zmarła włoska aktorka Maria Rosaria Omaggio. Zagrała u Wajdy słynną dziennikarkę " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8855638-maria-rosaria-omaggio-ph7987193/alternates/LANDSCAPE_1280" />
    W wieku 67 lat zmarła znana włoska aktorka Maria Rosaria Omaggio. Zasłynęła rolą dziennikarki i pisarki Oriany Fallaci w filmie Andrzeja Wajdy "Wałęsa. Człowiek z nadziei" z 2013 roku, za którą dostała nagrodę na festiwalu w Wenecji.

## Nawalna szefową amerykańskiej Fundacji Praw Człowieka, zapowiada walkę z reżimem Putina
 - [https://tvn24.pl/swiat/julia-nawalna-zostala-szefowa-amerykanskiej-fundacji-praw-czlowieka-zapowiada-walke-z-rezimem-wladimira-putina-st7987116?source=rss](https://tvn24.pl/swiat/julia-nawalna-zostala-szefowa-amerykanskiej-fundacji-praw-czlowieka-zapowiada-walke-z-rezimem-wladimira-putina-st7987116?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T06:26:44+00:00

<img alt="Nawalna szefową amerykańskiej Fundacji Praw Człowieka, zapowiada walkę z reżimem Putina" src="https://tvn24.pl/najnowsze/cdn-zdjecie-910blk-nawalna-7795458/alternates/LANDSCAPE_1280" />
    Julia Nawalna, wdowa po zmarłym rosyjskim opozycjoniście Aleksieju Nawalnym, powiedziała w poniedziałek, że wykorzysta nową rolę przewodniczącej amerykańskiej Fundacji Praw Człowieka (HRF), aby intensywnie kontynuować walkę męża z prezydentem Rosji Władimirem Putinem.

## Gospodarka w trybie wojennym. Władze tego kraju chcą "ratować socjalizm"
 - [https://tvn24.pl/biznes/najnowsze/gospodarka-wojenna-na-kubie-rzad-walczy-z-inflacja-i-deficytem-budzetowym-st7987148?source=rss](https://tvn24.pl/biznes/najnowsze/gospodarka-wojenna-na-kubie-rzad-walczy-z-inflacja-i-deficytem-budzetowym-st7987148?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T05:24:54+00:00

<img alt="Gospodarka w trybie wojennym. Władze tego kraju chcą " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bbhph8-kuba-hawana-port-shutterstock_2456205899-ph7951119/alternates/LANDSCAPE_1280" />
    Rząd Kuby ogłosił zwiększenie kontroli cen oraz walkę z próbami uchylania się od podatków - przekazała agencja Reutera. To próba opanowania wysokiej inflacji oraz deficytu budżetowego w ramach działań określanych przez tamtejsze włade mianem "gospodarki wojennej".

## Klęska Macrona przestrogą po drugiej stronie kanału. Prawica może "wyczuć szansę"
 - [https://tvn24.pl/swiat/wielka-brytania-kleska-emmanuela-macrona-we-francji-to-przestroga-dla-keira-starmera-komentarz-st7987110?source=rss](https://tvn24.pl/swiat/wielka-brytania-kleska-emmanuela-macrona-we-francji-to-przestroga-dla-keira-starmera-komentarz-st7987110?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-07-02T05:22:12+00:00

<img alt="Klęska Macrona przestrogą po drugiej stronie kanału. Prawica może " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vamxca-nigel-farage-ph7946159/alternates/LANDSCAPE_1280" />
    Spektakularna klęska francuskiego prezydenta Emmanuela Macrona powinna być przestrogą dla lidera brytyjskiej Partii Pracy Keira Starmera - napisał w poniedziałek "Daily Telegraph", komentując wynik niedzielnych wyborów do parlamentu Francji w kontekście czwartkowych wyborów do Izby Gmin.

