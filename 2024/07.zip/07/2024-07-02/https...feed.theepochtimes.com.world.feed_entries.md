# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## 3 in 4 Canadians Support Disclosing Names of MPs, Senators Accused of Foreign Collusion: Survey
 - [https://www.theepochtimes.com/world/3-in-4-canadians-support-disclosing-names-of-mps-senators-accused-of-foreign-collusion-survey-5678951](https://www.theepochtimes.com/world/3-in-4-canadians-support-disclosing-names-of-mps-senators-accused-of-foreign-collusion-survey-5678951)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T23:18:30+00:00

Voters head to cast their ballots at the Fairbanks Interpretation Centre in Dartmouth, N.S., during Canada's federal election on Oct. 21, 2019. (The Canadian Press/Andrew Vaughan)

## Online Platforms Get New Protections From Defamation Under Reforms in NSW
 - [https://www.theepochtimes.com/world/online-platforms-not-responsible-for-defamation-under-reforms-in-nsw-5678685](https://www.theepochtimes.com/world/online-platforms-not-responsible-for-defamation-under-reforms-in-nsw-5678685)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T22:48:05+00:00

SYDNEY, AUSTRALIA - FEBRUARY 18: In this photo illustration reports on Facebook's news ban on Australian and International content on February 18, 2021 in Sydney, Australia. Facebook has banned publishers an users in Australia from posting it sharing news content as the Australian government prepares to pass laws that will require social media companies to pay news publishers for sharing using content on their platforms. (Photo by Brendon Thorne/Getty Images)

## ANALYSIS: Why Doug Ford May Risk Calling an Early Election in Ontario
 - [https://www.theepochtimes.com/world/analysis-why-doug-ford-may-risk-calling-an-early-election-in-ontario-5676360](https://www.theepochtimes.com/world/analysis-why-doug-ford-may-risk-calling-an-early-election-in-ontario-5676360)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T22:42:21+00:00

Ontario Premier Doug Ford speaks at Association of Municipalities of Ontario Conference at RBC Place in London, Ont., on Aug. 21, 2023. (The Canadian Press/Nicole Osborne)

## Jewish Teachers File Antisemitism Complaint Against BC Teachers’ Federation: Lawyer
 - [https://www.theepochtimes.com/world/jewish-teachers-file-antisemitism-complaint-against-bc-teachers-federation-lawyer-5679134](https://www.theepochtimes.com/world/jewish-teachers-file-antisemitism-complaint-against-bc-teachers-federation-lawyer-5679134)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T22:25:28+00:00

The office that houses the B.C. Human Rights Tribunal is seen in Vancouver on March 28, 2023. (The Canadian Press/Nono Shen)

## Helicopter Pilot Dies Fighting Wildfire in Northwest Territories
 - [https://www.theepochtimes.com/world/helicopter-pilot-dies-fighting-wildfire-in-northwest-territories-5679119](https://www.theepochtimes.com/world/helicopter-pilot-dies-fighting-wildfire-in-northwest-territories-5679119)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T21:54:59+00:00

The Northwest Territories provincial flag flies on a flag pole in Ottawa on July 6, 2020. (The Canadian Press/Adrian Wyld)

## Sunscreen Foundation Recalled Over Mould Contamination Concerns
 - [https://www.theepochtimes.com/world/sunscreen-foundation-recalled-over-mould-contamination-concerns-5679030](https://www.theepochtimes.com/world/sunscreen-foundation-recalled-over-mould-contamination-concerns-5679030)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T21:54:22+00:00

A sign is displayed in front of Health Canada headquarters in Ottawa on Jan. 3, 2014. (The Canadian Press/Sean Kilpatrick

## Trudeau Missing Calgary Stampede This Summer, His Only Absence Outside COVID-19 Years
 - [https://www.theepochtimes.com/world/trudeau-missing-calgary-stampede-this-summer-his-only-absence-outside-covid-19-years-5679115](https://www.theepochtimes.com/world/trudeau-missing-calgary-stampede-this-summer-his-only-absence-outside-covid-19-years-5679115)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T21:45:52+00:00

Prime Minister Justin Trudeau attends a Stampede pancake breakfast in Calgary, on July 8, 2023. (The Canadian Press/Jeff McIntosh)

## Court Orders Protesters to Take Down UofT Encampment
 - [https://www.theepochtimes.com/world/court-orders-protesters-to-take-down-uoft-encampment-5679093](https://www.theepochtimes.com/world/court-orders-protesters-to-take-down-uoft-encampment-5679093)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T21:25:48+00:00

Pro-Palestinian protesters at an encampment set up on the University of Toronto campus on May 2, 2024. (The Canadian Press/Chris Young)

## Canada Pension Board Invests $600M in China EV as Ottawa Weighs Tariffs to Protect Domestic Industry
 - [https://www.theepochtimes.com/world/canada-pension-board-invests-600m-in-china-ev-as-ottawa-weighs-tariffs-to-protect-domestic-industry-5678784](https://www.theepochtimes.com/world/canada-pension-board-invests-600m-in-china-ev-as-ottawa-weighs-tariffs-to-protect-domestic-industry-5678784)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T21:03:47+00:00

A BYD Seal U model car is seen at the stand of the Chinese carmaker at the Geneva International Motor Show in Geneva, on Feb. 27, 2024. (Fabrice Coferini/ AFP via Getty Images)

## Health Canada Recalls Inflatable Child Booster Seats, Citing Injury Risk
 - [https://www.theepochtimes.com/world/health-canada-recalls-inflatable-child-booster-seats-citing-injury-hazard-5678999](https://www.theepochtimes.com/world/health-canada-recalls-inflatable-child-booster-seats-citing-injury-hazard-5678999)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T20:54:02+00:00

The UberBoost Inflatable Booster Car Seat was the subject of a recall issued June 28, 2024. (Health Canada/Handout)

## Anthony Furey: The Need to Reignite the Canadian Identity
 - [https://www.theepochtimes.com/opinion/anthony-furey-the-need-to-reignite-the-canadian-identity-5678803](https://www.theepochtimes.com/opinion/anthony-furey-the-need-to-reignite-the-canadian-identity-5678803)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T20:48:20+00:00

A member of the Skyhawks Parachute Team floats above the Canada Day noon hour show during a flypast celebrating the RCAF centennial, at LeBreton Flats in Ottawa on July 1, 2024. (The Canadian Press/Justin Tang)

## Battery Maker Northvolt Conducts Review of Expansion, Says Quebec Plant Going Ahead as Planned
 - [https://www.theepochtimes.com/world/battery-maker-northvolt-could-pull-plug-on-canada-expansion-amid-strategic-review-5678987](https://www.theepochtimes.com/world/battery-maker-northvolt-could-pull-plug-on-canada-expansion-amid-strategic-review-5678987)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T20:36:41+00:00

The entrance to Northvolt, the new EV battery plant being built by the Swedish manufacturer in Saint-Basile-le-Grand, east of Montreal, Que., May 16, 2024. (Christinne Muschi/The Canadian Press)

## South Korean Government Gives Export Boost to Companies Trading in Africa
 - [https://www.theepochtimes.com/world/south-korean-government-gives-export-boost-to-companies-trading-in-africa-5678868](https://www.theepochtimes.com/world/south-korean-government-gives-export-boost-to-companies-trading-in-africa-5678868)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T19:54:27+00:00

South Korea's President Yoon Suk Yeol (C) cheers during a ceremony marking the 105th anniversary of the Independence Movement Day in Seoul on March 1, 2024. (Kim Hong-Ji/AFP via Getty Images)

## Kyiv Claims to Have Foiled Planned Coup Attempt Against Zelenskyy Government
 - [https://www.theepochtimes.com/world/kyiv-claims-to-have-foiled-planned-coup-attempt-against-zelenskyy-government-5678224](https://www.theepochtimes.com/world/kyiv-claims-to-have-foiled-planned-coup-attempt-against-zelenskyy-government-5678224)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T19:34:14+00:00

Ukrainian President Volodymyr Zelenskyy attends a news conference in Kyiv, Ukraine, on Feb. 25, 2024. (Sergei Supinsky/AFP via Getty Images)

## Bloc Québécois Wants Investigation Into Military Rescue Mission of Afghan Sikhs
 - [https://www.theepochtimes.com/world/bloc-quebecois-wants-investigation-into-military-rescue-mission-of-afghan-sikhs-5678899](https://www.theepochtimes.com/world/bloc-quebecois-wants-investigation-into-military-rescue-mission-of-afghan-sikhs-5678899)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T19:23:41+00:00

Harjit Sajjan, President of the King’s Privy Council for Canada, Minister of Emergency Preparedness and Minister responsible for the Pacific Economic Development Agency of Canada, speaks in Ottawa, on June 3, 2024. (The Canadian Press/Spencer Colby)

## Canada Records More Than 8,000 Opioid-Related Deaths in 2023
 - [https://www.theepochtimes.com/world/canada-records-more-than-8000-opioid-related-deaths-in-2023-post-5678863](https://www.theepochtimes.com/world/canada-records-more-than-8000-opioid-related-deaths-in-2023-post-5678863)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T19:04:28+00:00

Ambulances are parked at the entrance to the emergency department at Richmond General Hospital in Richmond, B.C., on Nov. 27, 2022. (The Canadian Press/Darryl Dyck)

## Indoor Water Use Restrictions Lifted in Calgary
 - [https://www.theepochtimes.com/world/indoor-water-use-restrictions-lifted-in-calgary-5678896](https://www.theepochtimes.com/world/indoor-water-use-restrictions-lifted-in-calgary-5678896)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T18:39:08+00:00

People are being urged to reduce their water use as work to repair a major water main continues in Calgary June 7, 2024. (The Canadian Press/Jeff McIntosh)

## Hurricane Beryl Reaches Category 5, Expected to Hit Jamaica Soon
 - [https://www.theepochtimes.com/us/hurricane-beryl-reaches-category-5-expected-to-hit-jamaica-soon-5678873](https://www.theepochtimes.com/us/hurricane-beryl-reaches-category-5-expected-to-hit-jamaica-soon-5678873)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T17:33:28+00:00

A National Oceanic and Atmospheric Administration satellite image shows Hurricane Beryl as of Sunday, June 30, 2024. (NOAA)

## Liberal MP Suggests Party Needed Stronger Ground Game in Toronto—St. Paul’s Vote
 - [https://www.theepochtimes.com/world/liberal-mp-suggests-party-needed-stronger-ground-game-in-toronto-st-pauls-vote-5678886](https://www.theepochtimes.com/world/liberal-mp-suggests-party-needed-stronger-ground-game-in-toronto-st-pauls-vote-5678886)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T17:24:02+00:00

Karina Gould, Leader of the Government in the House of Commons rises during Question Period in Ottawa on Dec. 15, 2023. (The Canadian Press/Adrian Wyld)

## John Robson: Today’s Realities Warrant an Increased Level of Military Preparedness
 - [https://www.theepochtimes.com/opinion/john-robson-todays-realities-warrant-an-increased-level-of-military-preparedness-5677397](https://www.theepochtimes.com/opinion/john-robson-todays-realities-warrant-an-increased-level-of-military-preparedness-5677397)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T17:09:53+00:00

A worker handles 155 mm calibre shells after the manufacturing process at the Scranton Army Ammunition Plant in Scranton, Pennsylvania, on April 16, 2024. (Charly Triballeau/AFP via Getty Images)

## Hollywood Stars’ Donation to Nonprofit Helps Create 500 Water Wells and Counting
 - [https://www.theepochtimes.com/us/hollywood-stars-donation-to-nonprofit-helps-create-500-water-wells-and-counting-5677938](https://www.theepochtimes.com/us/hollywood-stars-donation-to-nonprofit-helps-create-500-water-wells-and-counting-5677938)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T17:06:22+00:00

Villiagers enjoy clean water from a well built by Water Wells for Africa on July 6, 2018. (John Fredricks/The Epoch Times)

## Prime Minister Justin Trudeau to Attend NATO Leaders’ Summit in Washington Next Week
 - [https://www.theepochtimes.com/world/prime-minister-justin-trudeau-to-attend-nato-leaders-summit-in-washington-next-week-5678884](https://www.theepochtimes.com/world/prime-minister-justin-trudeau-to-attend-nato-leaders-summit-in-washington-next-week-5678884)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T17:00:25+00:00

The Swedish flag is tied to a flagpole and surrounded by the flags of other NATO nations, as protocol prepare for a flag raising ceremony to mark the accession of Sweden at NATO headquarters in Brussels, on March 11, 2024. (The Associated Press/Geert Vanden Wijngaert)

## United States Looking at All Tools to Respond to Canada’s Digital Services Tax
 - [https://www.theepochtimes.com/world/united-states-looking-at-all-tools-to-respond-to-canadas-digital-services-tax-5678877](https://www.theepochtimes.com/world/united-states-looking-at-all-tools-to-respond-to-canadas-digital-services-tax-5678877)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T16:47:50+00:00

A man uses a computer keyboard in Toronto on Oct. 9, 2023. (The Canadian Press/Graeme Roy)

## Water Companies Open to Flood of Legal Challenges After Supreme Court Ruling
 - [https://www.theepochtimes.com/world/water-companies-open-to-flood-of-legal-challenges-after-supreme-court-ruling-5678860](https://www.theepochtimes.com/world/water-companies-open-to-flood-of-legal-challenges-after-supreme-court-ruling-5678860)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T16:40:49+00:00

A police officer stands in front of the Supreme Court in London on Dec. 5, 2016. (Leon Neal/Getty Images)

## Christian Social Worker to Appeal Tribunal Ruling in Discrimination Case
 - [https://www.theepochtimes.com/world/christian-social-worker-to-appeal-tribunal-ruling-in-discrimination-case-5678704](https://www.theepochtimes.com/world/christian-social-worker-to-appeal-tribunal-ruling-in-discrimination-case-5678704)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T16:32:10+00:00

Christian social worker Felix Ngole outside Leeds Employment Tribunal in West Yorkshire, England, on April 4, 2024. (Danny Lawson/PA)

## Immigration Department Implements New Rules Targeting ‘Unethical Behaviour’ in Foreign Student Programs
 - [https://www.theepochtimes.com/world/immigration-department-implements-new-rules-targeting-unethical-behaviour-in-foreign-student-programs-5678755](https://www.theepochtimes.com/world/immigration-department-implements-new-rules-targeting-unethical-behaviour-in-foreign-student-programs-5678755)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T16:15:38+00:00

Immigration, Refugees and Citizenship Minister Marc Miller speaks in the Foyer of the House of Commons before Question Period on Parliament Hill in Ottawa on June 12, 2024. (The Canadian Press/ Patrick Doyle)

## Russia Ally Belarus Vows to Respond to ‘Provocations’ by Neighbor Ukraine
 - [https://www.theepochtimes.com/world/russia-ally-belarus-vows-to-respond-to-provocations-by-neighbor-ukraine-5678745](https://www.theepochtimes.com/world/russia-ally-belarus-vows-to-respond-to-provocations-by-neighbor-ukraine-5678745)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T16:12:29+00:00

A satellite image shows assembled vehicles at V D Bolshoy Bokov airfield, near Mazyr, Belarus, on Feb. 22, 2022. (Courtesy of Satellite image ©2022 Maxar Technologies/Handout via Reuters)

## Where Policy and Public Opinion Differ on Immigration: Mike Jones
 - [https://www.theepochtimes.com/epochtv/mike-jones-british-thought-leaders-5678362](https://www.theepochtimes.com/epochtv/mike-jones-british-thought-leaders-5678362)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T15:57:20+00:00

Mike Jones

## Defense Secretary Announces New US Military Aid Package to Ukraine
 - [https://www.theepochtimes.com/world/defense-secretary-announces-new-us-military-aid-package-to-ukraine-5678806](https://www.theepochtimes.com/world/defense-secretary-announces-new-us-military-aid-package-to-ukraine-5678806)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T15:47:32+00:00

U.S. Secretary of Defense Lloyd Austin attends the 21st Shangri-La defense dialogue summit in Singapore on June 1, 2024. (NHAC NGUYEN/AFP via Getty Images)

## EV Drivers Will Have to Pay London Congestion Charge
 - [https://www.theepochtimes.com/world/ev-drivers-will-have-to-pay-london-congestion-charge-5678689](https://www.theepochtimes.com/world/ev-drivers-will-have-to-pay-london-congestion-charge-5678689)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T15:30:37+00:00

A Go Ultra Low Nissan LEAF on charge on a London street in an undated file photo. (Miles Willis/Stringer/Getty Images)

## Lucy Letby Convicted of Baby’s Attempted Murder
 - [https://www.theepochtimes.com/world/lucy-letby-convicted-of-babys-attempted-murder-5678788](https://www.theepochtimes.com/world/lucy-letby-convicted-of-babys-attempted-murder-5678788)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T15:27:35+00:00

Lucy Letby is led away in handcuffs by police after being arrested at her home in Chester, England, on July 3, 2018. (Cheshire Police)

## Powerful Summer Storm Sweeps Through Balkans With Hail, Rain, and Winds, Killing 2
 - [https://www.theepochtimes.com/world/powerful-summer-storm-sweeps-through-balkans-with-hail-rain-and-winds-killing-2-post-5678773](https://www.theepochtimes.com/world/powerful-summer-storm-sweeps-through-balkans-with-hail-rain-and-winds-killing-2-post-5678773)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T14:51:59+00:00

A municipal worker holds owlets rescued from a fallen tree after a powerful storm in Montenegro's capital Podgorica on July 2, 2024. (Risto Bozovic/AP Photo)

## US Completes Hypersonic Missile Flight Test in Bid to Keep Up With China
 - [https://www.theepochtimes.com/us/us-completes-hypersonic-missile-flight-test-in-bid-to-keep-up-with-china-5678089](https://www.theepochtimes.com/us/us-completes-hypersonic-missile-flight-test-in-bid-to-keep-up-with-china-5678089)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T14:35:59+00:00

The United States Navy and Army launch a hypersonic missile in this undated photograph. (Courtesy of the US Navy)

## Impact of Junior Doctor Strikes Will Be ‘Felt for Some Time to Come’, Warns NHS Body
 - [https://www.theepochtimes.com/world/impact-of-junior-doctor-strikes-will-be-felt-for-some-time-to-come-warns-nhs-body-5678731](https://www.theepochtimes.com/world/impact-of-junior-doctor-strikes-will-be-felt-for-some-time-to-come-warns-nhs-body-5678731)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T14:26:57+00:00

Junior doctor and members of the British Medical Association (BMA) on the picket line outside Leeds General Infirmary on July 13, 2023. (Danny Lawson/PA)

## WestJet Works to Get Planes Back in the Air in Wake of 3-Day Strike
 - [https://www.theepochtimes.com/world/westjet-works-to-get-planes-back-in-the-air-in-wake-of-3-day-strike-5678682](https://www.theepochtimes.com/world/westjet-works-to-get-planes-back-in-the-air-in-wake-of-3-day-strike-5678682)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T14:22:38+00:00

Passengers make their way past WestJet airplane mechanics as they stand in a the picket line at Calgary International Airport in Calgary, on June 29, 2024. (The Canadian Press/Jeff McIntosh)

## UK Postal Voting System Facing ‘Pressures,’ Electoral Watchdog Warns
 - [https://www.theepochtimes.com/world/uk-postal-voting-system-facing-pressures-electoral-watchdog-warns-5678687](https://www.theepochtimes.com/world/uk-postal-voting-system-facing-pressures-electoral-watchdog-warns-5678687)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T14:16:41+00:00

A general view of a Royal Mail postbox in Essex, England, on Dec. 6, 2020. (Gareth Cattermole/Getty Images)

## Five Years After Historic Tobacco Ruling, ‘Nothing Has Changed’
 - [https://www.theepochtimes.com/world/five-years-after-historic-tobacco-ruling-nothing-has-changed-5678758](https://www.theepochtimes.com/world/five-years-after-historic-tobacco-ruling-nothing-has-changed-5678758)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T13:47:21+00:00

Jean-Luc Duval holds a picture of his late wife, Monique,  in his home in Repentigny, Que., on June 14, 2024. (The Canadian Press/Ryan Remiorz)

## Stunning Photos Capture Bubble Magic in Antarctica
 - [https://www.theepochtimes.com/bright/stunning-photos-capture-bubble-magic-in-antarctica-5678534](https://www.theepochtimes.com/bright/stunning-photos-capture-bubble-magic-in-antarctica-5678534)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T13:02:05+00:00

A beautiful bubble reminiscent of a fine artwork. Patterns on a frozen bubble look like a winter wonderland inside a snow globe. Photo: © Justin Chambers/Australian Antarctic Division

## Hurricane Beryl Rips Through Open Waters After Devastating Southeast Caribbean
 - [https://www.theepochtimes.com/world/hurricane-beryl-rips-through-open-waters-after-devastating-southeast-caribbean-5678727](https://www.theepochtimes.com/world/hurricane-beryl-rips-through-open-waters-after-devastating-southeast-caribbean-5678727)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T12:59:33+00:00

Fishermen pull a boat damaged by Hurricane Beryl back to the dock at the Bridgetown Fisheries in Barbados, on July 1, 2024. (Ricardo Mazalan/AP Photo)

## Andy Murray Withdraws From Wimbledon Singles Tournament
 - [https://www.theepochtimes.com/sports/andy-murray-withdraws-from-wimbledon-singles-tournament-5678705](https://www.theepochtimes.com/sports/andy-murray-withdraws-from-wimbledon-singles-tournament-5678705)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T11:32:31+00:00

Britain's Andy Murray celebrates winning a point from Britain's Ryan Peniston during the first round men's singles match on day two of the Wimbledon tennis championships in London on July 4, 2023. (Alberto Pezzali/AP Photo)

## Food Inflation Drops to Lowest Rate Since December 2021: BRC
 - [https://www.theepochtimes.com/world/food-inflation-drops-to-lowest-rate-since-december-2021-brc-5678698](https://www.theepochtimes.com/world/food-inflation-drops-to-lowest-rate-since-december-2021-brc-5678698)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T11:21:01+00:00

A woman holds a bunch of bananas inside a supermarket in east London on May 9, 2024. (Justin Tallis/AFP via Getty Images)

## Russia Plans to Create Core of New Space Station by 2030
 - [https://www.theepochtimes.com/science/russia-plans-to-create-core-of-new-space-station-by-2030-post-5678706](https://www.theepochtimes.com/science/russia-plans-to-create-core-of-new-space-station-by-2030-post-5678706)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T11:06:22+00:00

Head of the Roscosmos space corporation Yuri Borisov attends a State Committee meeting at the Russian leased Baikonur cosmodrome in Kazakhstan, on Sept. 14, 2023. (Maxim Shipenkov/Pool via Reuters)

## Russia Says It Destroys 5 Ukrainian SU-27 Jet Fighters as Moscow Aims at F-16 Arrivals
 - [https://www.theepochtimes.com/world/russia-says-it-destroys-5-ukrainian-su-27-jet-fighters-at-airfield-5678691](https://www.theepochtimes.com/world/russia-says-it-destroys-5-ukrainian-su-27-jet-fighters-at-airfield-5678691)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T10:41:53+00:00

Polish Air Force F-16 fighter jets fly in formation during the Clear Sky 2018 multinational military drills at Starokostiantyniv Air Base in Khmelnytskyi Region, Ukraine, on Oct. 12, 2018. (Gleb Garanich/Reuters)

## Isle of Man Referendum on Assisted Suicide Blocked
 - [https://www.theepochtimes.com/world/isle-of-man-referendum-on-assisted-suicide-blocked-5678232](https://www.theepochtimes.com/world/isle-of-man-referendum-on-assisted-suicide-blocked-5678232)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T10:28:24+00:00

The Tynwald building, housing the Manx Parliament, in Douglas, Isle of Man, on Nov. 8 2017. (Matt Cardy/Getty Images)

## Nurses Call for Law to Regulate Staffing Levels
 - [https://www.theepochtimes.com/world/nurses-call-for-law-to-regulate-staffing-levels-5678237](https://www.theepochtimes.com/world/nurses-call-for-law-to-regulate-staffing-levels-5678237)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T09:58:13+00:00

NHS workers take part in a march from St. Thomas's Hospital to Trafalgar Square, as members of the Royal College of Nursing and the Unite union continue their strike action in a dispute over pay, in London, on May 1, 2023. (Jordan Pettitt/PA Media)

## UK House Prices up Slightly in June Despite High Interest Rates
 - [https://www.theepochtimes.com/world/uk-house-prices-up-slightly-in-june-despite-high-interest-rates-5678253](https://www.theepochtimes.com/world/uk-house-prices-up-slightly-in-june-despite-high-interest-rates-5678253)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T09:37:56+00:00

A for sale signs stands outside residential housing in London, on Aug. 10, 2017. (Dan Kitwood/Getty Images)

## Opposition Backs Power to ‘Break Up’ Major Supermarket Companies
 - [https://www.theepochtimes.com/world/opposition-backs-power-to-break-up-major-supermarket-companies-5678651](https://www.theepochtimes.com/world/opposition-backs-power-to-break-up-major-supermarket-companies-5678651)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T09:09:51+00:00

Australian Opposition Leader Peter Dutton during post Budget media interviews at Parliament House in Canberra, Australia on May 15, 2024. (Tracey Nearmy/Getty Images)

## National Databases in Election Pledges Need Robust Safeguards, Says Expert
 - [https://www.theepochtimes.com/world/national-databases-in-election-pledges-need-robust-safeguards-says-expert-5676889](https://www.theepochtimes.com/world/national-databases-in-election-pledges-need-robust-safeguards-says-expert-5676889)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T09:04:14+00:00

A computer keyboard lit by a displayed cyber code is seen in this illustration picture taken on March 1, 2017. (Kacper Pempel/Reuters)

## 17-Year-Old Chinese Player Dies After Collapsing During Badminton Match in Indonesia
 - [https://www.theepochtimes.com/world/17-year-old-chinese-player-dies-after-collapsing-during-badminton-match-in-indonesia-5678111](https://www.theepochtimes.com/world/17-year-old-chinese-player-dies-after-collapsing-during-badminton-match-in-indonesia-5678111)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T07:24:39+00:00

Chinese badminton players continue to watch and support their teammates from the stands during the 2024 Asia Junior Championship in Yogyakarta in Indonesia, on July 1, 2024, despite being dejected by the death of the late Chinese player Zhang Zhijie, who collapsed during a match against Japan in the preliminary round. (Devi Rahman/AFP via Getty Images)

## Chinese Woman Facing Charge of Trying to Smuggle Turtles Across Vermont Lake to Canada
 - [https://www.theepochtimes.com/world/chinese-woman-facing-charge-of-trying-to-smuggle-turtles-across-vermont-lake-to-canada-5678344](https://www.theepochtimes.com/world/chinese-woman-facing-charge-of-trying-to-smuggle-turtles-across-vermont-lake-to-canada-5678344)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T06:50:41+00:00

A male Eastern Box Turtle moves across a path at Wildwood Lake Sanctuary in Harrisburg, Pa., on May, 2, 2009. (Carolyn Kaster/AP Photo)

## Car Hits Pedestrians in Central Seoul, Killing 9 and Injuring 4
 - [https://www.theepochtimes.com/world/car-hits-pedestrians-in-central-seoul-killing-9-and-injuring-4-post-5678301](https://www.theepochtimes.com/world/car-hits-pedestrians-in-central-seoul-killing-9-and-injuring-4-post-5678301)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T06:41:58+00:00

Police officers control a car accident scene near Seoul City Hall in downtown Seoul, South Korea, on July 1, 2024. (Seo Dae-yeon/Yonhap via AP)

## Dignity Over Trade: Sebastian Lai Urges Australia to Fight for Father’s Release
 - [https://www.theepochtimes.com/world/dignity-over-trade-sebastian-lai-urges-australia-to-fight-for-fathers-release-5678644](https://www.theepochtimes.com/world/dignity-over-trade-sebastian-lai-urges-australia-to-fight-for-fathers-release-5678644)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T06:30:35+00:00

Sebastien Lai, son of Hong Kong pro-democracy media tycoon Jimmy Lai, at a park in Taipei, Taiwan, on Nov. 27, 2023. (I-Hwa Cheng/AFP via Getty Images)

## Teenager Arrested After a Stabbing at the University of Sydney
 - [https://www.theepochtimes.com/world/teenager-arrested-after-a-stabbing-at-the-university-of-sydney-5678540](https://www.theepochtimes.com/world/teenager-arrested-after-a-stabbing-at-the-university-of-sydney-5678540)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T01:51:10+00:00

A general view of Sydney University campus in Sydney, Australia, on April 6, 2016. (Brendon Thorne/Getty Images)

## Labor Senator Was ‘Not Intimidated’ for Supporting Palestine Statehood: Shorten
 - [https://www.theepochtimes.com/world/labor-senator-was-not-intimidated-for-supporting-palestine-statehood-shorten-5678535](https://www.theepochtimes.com/world/labor-senator-was-not-intimidated-for-supporting-palestine-statehood-shorten-5678535)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T01:28:20+00:00

Labor Senator Fatima Payman during Question Time in the Senate chamber at Parliament House in Canberra, Australia, on July 1, 2024. (AAP Image/Mick Tsikas)

## Legislation Passes to End Live Sheep Shipments by 2028
 - [https://www.theepochtimes.com/world/legislation-passes-to-end-live-sheep-shipments-by-2028-post-5678080](https://www.theepochtimes.com/world/legislation-passes-to-end-live-sheep-shipments-by-2028-post-5678080)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-07-02T00:52:32+00:00

Sheep graze in a farm paddock behind signs protesting the live sheep ban in the south of Western Australia on June 20, 2024. (Susan Mortimer/The Epoch Times)

