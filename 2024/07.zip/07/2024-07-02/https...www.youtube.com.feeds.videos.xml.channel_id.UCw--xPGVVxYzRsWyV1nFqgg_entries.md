# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## The Best Fantasy News You'll Ever Watch!!!!!
 - [https://www.youtube.com/watch?v=WFSg6QCFwg4](https://www.youtube.com/watch?v=WFSg6QCFwg4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2024-07-02T13:00:34+00:00

Let's jump into the  @merphynapier42  NEWS!!!! 
Thanks to Keeps for sponsoring this video & for the free product! Head to http://keeps.com/danielgreene to get a special offer. Individual results may vary. 

New second channel: https://www.youtube.com/channel/UCC-EqiFg67s2Nd0imgRXg5w  

Gear:
Sony a7 iii: https://amzn.to/3yyVa6Q 
Lens: https://amzn.to/3wOwman 
Microphone: https://amzn.to/4byjDHW 
Sound Board: https://amzn.to/4aybOkn 
Light diffuser: https://amzn.to/3KhcIXM 

My books
Neon Ghosts: https://shop.wraithmarked.com/collections/standard-editions-1/products/neon-ghosts-a-witchs-sin-hardcover
Breach of Peace: https://tinyurl.com/BoPTLT  
Rebels Creed: https://tinyurl.com/RCTLTDG 
merch: https://www.danielbgreene.com

Patreon: https://www.patreon.com/DanielBGreene 
Join the Discord here: https://discord.gg/xUrPj6EP3f
All the Me Social Links: https://linktr.ee/DanielGreene
The News:
New Releases:
https://x.com/UKTor/status/1806267483537420778
https://x.com/TheFantasyHive/status/1

