# Source:Reddit - Politics, URL:https://www.reddit.com/r/politics/.rss, language:en-US

## 'Screaming the Quiet Part': Trump Advisers Say He's Ready to Embrace King-Like Powers
 - [https://www.reddit.com/r/politics/comments/1dtvge9/screaming_the_quiet_part_trump_advisers_say_hes](https://www.reddit.com/r/politics/comments/1dtvge9/screaming_the_quiet_part_trump_advisers_say_hes)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T20:11:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtvge9/screaming_the_quiet_part_trump_advisers_say_hes/"> <img alt="'Screaming the Quiet Part': Trump Advisers Say He's Ready to Embrace King-Like Powers" src="https://external-preview.redd.it/sqIglnXQ9jydz1gBKLLD6Eg7qhGxBCYiOZNcg8hzAS4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=52232dacc1e9a7a8ef4dd89744dfd2d0e7b20357" title="'Screaming the Quiet Part': Trump Advisers Say He's Ready to Embrace King-Like Powers" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ZettabyteEra"> /u/ZettabyteEra </a> <br /> <span><a href="https://www.commondreams.org/news/supreme-court-donald-trump-immunity">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtvge9/screaming_the_quiet_part_trump_advisers_say_hes/">[comments]</a></span> </td></tr></table>

## New Jersey refuses to renew Trump golf club liquor licenses because of hush-money convictions
 - [https://www.reddit.com/r/politics/comments/1dtve9z/new_jersey_refuses_to_renew_trump_golf_club](https://www.reddit.com/r/politics/comments/1dtve9z/new_jersey_refuses_to_renew_trump_golf_club)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T20:09:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtve9z/new_jersey_refuses_to_renew_trump_golf_club/"> <img alt="New Jersey refuses to renew Trump golf club liquor licenses because of hush-money convictions" src="https://external-preview.redd.it/GkcznmTGRQiMJsG5KUjvCsgyxPt3HSrAsYEbbdln0S8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=75cc42b6f634b033fab515a4c3353bc046c937ac" title="New Jersey refuses to renew Trump golf club liquor licenses because of hush-money convictions" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Nvnv_man"> /u/Nvnv_man </a> <br /> <span><a href="https://lawandcrime.com/high-profile/new-jersey-refuses-to-renew-trump-golf-club-liquor-licenses-because-of-hush-money-convictions/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtve9z/new_jersey_refuses_to_renew_trump_golf_club/">[comments]</a></span> </td></tr></table>

## Trump immunity decision shows that conservative ‘originalism’ is a farce
 - [https://www.reddit.com/r/politics/comments/1dtukn2/trump_immunity_decision_shows_that_conservative](https://www.reddit.com/r/politics/comments/1dtukn2/trump_immunity_decision_shows_that_conservative)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T19:34:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtukn2/trump_immunity_decision_shows_that_conservative/"> <img alt="Trump immunity decision shows that conservative ‘originalism’ is a farce" src="https://external-preview.redd.it/XJN7xHeeBOkakiXa1HCktJPgVgPhC1_OAYHaK5y5e-k.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5666ee7815ad7b24f642422894e03632a7ae080e" title="Trump immunity decision shows that conservative ‘originalism’ is a farce" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bin10pac"> /u/bin10pac </a> <br /> <span><a href="https://thehill.com/opinion/judiciary/4751056-trump-immunity-decision-shows-that-conservative-originalism-is-a-farce/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtukn2/trump_immunity_decision_shows_that_conservative/">[comments]</a></span> </td></tr></table>

## High court ruling on presidential immunity threatens the rule of law, Berkeley scholars warn
 - [https://www.reddit.com/r/politics/comments/1dtu0mo/high_court_ruling_on_presidential_immunity](https://www.reddit.com/r/politics/comments/1dtu0mo/high_court_ruling_on_presidential_immunity)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T19:11:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtu0mo/high_court_ruling_on_presidential_immunity/"> <img alt="High court ruling on presidential immunity threatens the rule of law, Berkeley scholars warn" src="https://external-preview.redd.it/WWnygaHL8b5BmPD5ExU0V0DC0PGUBupjvC1NkqWMp-w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9b885034e4a8f46be08863cd2483f08e8171dc6d" title="High court ruling on presidential immunity threatens the rule of law, Berkeley scholars warn" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/UCBerkeley"> /u/UCBerkeley </a> <br /> <span><a href="https://news.berkeley.edu/2024/07/02/high-court-ruling-on-presidential-immunity-threatens-the-rule-of-law-scholars-warn/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtu0mo/high_court_ruling_on_presidential_immunity/">[comments]</a></span> </td></tr></table>

## Bernie Sanders: Right-Wing Supreme Court 'Out of Control' and Must Be Stopped | "At a time of massive income and wealth inequality, billionaire control of our political system, and major threats to the foundations of American democracy, it is clear to me that we need real Supreme Court reform."
 - [https://www.reddit.com/r/politics/comments/1dttjfx/bernie_sanders_rightwing_supreme_court_out_of](https://www.reddit.com/r/politics/comments/1dttjfx/bernie_sanders_rightwing_supreme_court_out_of)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T18:51:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dttjfx/bernie_sanders_rightwing_supreme_court_out_of/"> <img alt="Bernie Sanders: Right-Wing Supreme Court 'Out of Control' and Must Be Stopped | &quot;At a time of massive income and wealth inequality, billionaire control of our political system, and major threats to the foundations of American democracy, it is clear to me that we need real Supreme Court reform.&quot;" src="https://external-preview.redd.it/6uUvlshT_ThFvByoai1fYivQMlZ1TfwAo3YzIzBpWAY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=06042d54dc933fbfbff0d7caa6ec41c5550e2a2d" title="Bernie Sanders: Right-Wing Supreme Court 'Out of Control' and Must Be Stopped | &quot;At a time of massive income and wealth inequality, billionaire control of our political system, and major threats to the foundations of American democracy, it is clear to me that we need real Supreme Court reform.&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddi

## In wake of Supreme Court ruling, Biden administration tells doctors to provide emergency abortions
 - [https://www.reddit.com/r/politics/comments/1dtsmi2/in_wake_of_supreme_court_ruling_biden](https://www.reddit.com/r/politics/comments/1dtsmi2/in_wake_of_supreme_court_ruling_biden)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T18:13:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtsmi2/in_wake_of_supreme_court_ruling_biden/"> <img alt="In wake of Supreme Court ruling, Biden administration tells doctors to provide emergency abortions" src="https://external-preview.redd.it/mNQOLLtmp7JyxpVUa8XUINmrqSqB40MlWF4Lo-Zh0k4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0c3c687cded4763fc1ff99c035703386aaaa6b09" title="In wake of Supreme Court ruling, Biden administration tells doctors to provide emergency abortions" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zsreport"> /u/zsreport </a> <br /> <span><a href="https://apnews.com/article/abortion-emergency-room-law-biden-supreme-court-1564fa3f72268114e65f78848c47402b">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtsmi2/in_wake_of_supreme_court_ruling_biden/">[comments]</a></span> </td></tr></table>

## MAGA pastor says Ten Commandments in schools will stop teachers from “raping” kids. "It's obviously worked in churches!" one person responded.
 - [https://www.reddit.com/r/politics/comments/1dtrf9t/maga_pastor_says_ten_commandments_in_schools_will](https://www.reddit.com/r/politics/comments/1dtrf9t/maga_pastor_says_ten_commandments_in_schools_will)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T17:24:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtrf9t/maga_pastor_says_ten_commandments_in_schools_will/"> <img alt="MAGA pastor says Ten Commandments in schools will stop teachers from “raping” kids. &quot;It's obviously worked in churches!&quot; one person responded." src="https://external-preview.redd.it/R40EUQk0mU2Pl_fiLR23t_8G5XLNO3w-G1FkfYsu1pA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f4a043964388a143b810a3856f1864c4ab739df1" title="MAGA pastor says Ten Commandments in schools will stop teachers from “raping” kids. &quot;It's obviously worked in churches!&quot; one person responded." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/southpawFA"> /u/southpawFA </a> <br /> <span><a href="https://www.lgbtqnation.com/2024/07/maga-pastor-says-ten-commandments-in-schools-will-stop-teachers-from-raping-kids/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtrf9t/maga_pastor_says_ten_command

## House Democrat pledges amendment to reverse Trump immunity ruling
 - [https://www.reddit.com/r/politics/comments/1dtp77j/house_democrat_pledges_amendment_to_reverse_trump](https://www.reddit.com/r/politics/comments/1dtp77j/house_democrat_pledges_amendment_to_reverse_trump)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T15:52:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtp77j/house_democrat_pledges_amendment_to_reverse_trump/"> <img alt="House Democrat pledges amendment to reverse Trump immunity ruling" src="https://external-preview.redd.it/ZkbX6UxNsyhkqrPfgiTlprFSAwNY1xA9HBXLIwquOhg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3314604da70c28e7c55030ccbf3e25245af325cc" title="House Democrat pledges amendment to reverse Trump immunity ruling" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/drtolmn69"> /u/drtolmn69 </a> <br /> <span><a href="https://www.theguardian.com/us-news/article/2024/jul/02/joe-morelle-constitution-amendment-trump-immunity">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtp77j/house_democrat_pledges_amendment_to_reverse_trump/">[comments]</a></span> </td></tr></table>

## The Supreme Court Gave Trump a Stunning Gift — and Rewrote the Constitution
 - [https://www.reddit.com/r/politics/comments/1dtougs/the_supreme_court_gave_trump_a_stunning_gift_and](https://www.reddit.com/r/politics/comments/1dtougs/the_supreme_court_gave_trump_a_stunning_gift_and)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T15:38:23+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Kevombat"> /u/Kevombat </a> <br /> <span><a href="https://www.politico.com/news/magazine/2024/07/02/jan-6-trump-supreme-court-00166130">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtougs/the_supreme_court_gave_trump_a_stunning_gift_and/">[comments]</a></span>

## Giuliani disbarred in NY as court finds he repeatedly lied about Trump's 2020 election loss
 - [https://www.reddit.com/r/politics/comments/1dtoi62/giuliani_disbarred_in_ny_as_court_finds_he](https://www.reddit.com/r/politics/comments/1dtoi62/giuliani_disbarred_in_ny_as_court_finds_he)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T15:24:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtoi62/giuliani_disbarred_in_ny_as_court_finds_he/"> <img alt="Giuliani disbarred in NY as court finds he repeatedly lied about Trump's 2020 election loss" src="https://external-preview.redd.it/aY6_lvNAO1jfEzCvI5mdlKS3S4AkMNV0RBlkUm0ZQsc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4aafa2f02684df1d5add0e24f5c04dad7c1637ba" title="Giuliani disbarred in NY as court finds he repeatedly lied about Trump's 2020 election loss" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/coasterghost"> /u/coasterghost </a> <br /> <span><a href="https://apnews.com/article/81b327f9ab1f98548cb888f8e652c9a8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtoi62/giuliani_disbarred_in_ny_as_court_finds_he/">[comments]</a></span> </td></tr></table>

## Can the President Send SEAL Team Six to Assassinate His Rival? After Monday, Yes.
 - [https://www.reddit.com/r/politics/comments/1dto71v/can_the_president_send_seal_team_six_to](https://www.reddit.com/r/politics/comments/1dto71v/can_the_president_send_seal_team_six_to)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T15:10:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dto71v/can_the_president_send_seal_team_six_to/"> <img alt="Can the President Send SEAL Team Six to Assassinate His Rival? After Monday, Yes." src="https://external-preview.redd.it/HvPxWCIIR1OXqg0vHIzmXo6e2URAjRs1kwJutnEuHU4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b1f188b67d2185cfe8fffa1405ea799ec6cd704d" title="Can the President Send SEAL Team Six to Assassinate His Rival? After Monday, Yes." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/OkayButFoRealz"> /u/OkayButFoRealz </a> <br /> <span><a href="https://slate.com/news-and-politics/2024/07/supreme-court-trump-immunity-president-seal-team-six-assassinate-rival.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dto71v/can_the_president_send_seal_team_six_to/">[comments]</a></span> </td></tr></table>

## RFK Jr. Reportedly Shared Photos of Nude Women, BBQ’d Dog
 - [https://www.reddit.com/r/politics/comments/1dtnz28/rfk_jr_reportedly_shared_photos_of_nude_women](https://www.reddit.com/r/politics/comments/1dtnz28/rfk_jr_reportedly_shared_photos_of_nude_women)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T15:01:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtnz28/rfk_jr_reportedly_shared_photos_of_nude_women/"> <img alt="RFK Jr. Reportedly Shared Photos of Nude Women, BBQ’d Dog" src="https://external-preview.redd.it/CL67wsqrNGtnLI28cNNOt62B7IKk-tFxfJ7lgw2adi8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=34e00e868f7e248a12ba89be86861af81ab1278b" title="RFK Jr. Reportedly Shared Photos of Nude Women, BBQ’d Dog" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/UGMadness"> /u/UGMadness </a> <br /> <span><a href="https://www.thedailybeast.com/rfk-jr-reportedly-shared-photos-of-nude-women-bbqd-dog">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtnz28/rfk_jr_reportedly_shared_photos_of_nude_women/">[comments]</a></span> </td></tr></table>

## Biden dropping out is a fantasy. Democrats can win — if they fight.
 - [https://www.reddit.com/r/politics/comments/1dtnvxc/biden_dropping_out_is_a_fantasy_democrats_can_win](https://www.reddit.com/r/politics/comments/1dtnvxc/biden_dropping_out_is_a_fantasy_democrats_can_win)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T14:58:19+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/bostonglobe"> /u/bostonglobe </a> <br /> <span><a href="https://www.bostonglobe.com/2024/07/01/opinion/biden-democrats-drop-out-race/?s_campaign=audience:reddit">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtnvxc/biden_dropping_out_is_a_fantasy_democrats_can_win/">[comments]</a></span>

## The Supreme Court rules that Donald Trump can be a dictator | If you're a (Republican) president, they let you do it
 - [https://www.reddit.com/r/politics/comments/1dtnpct/the_supreme_court_rules_that_donald_trump_can_be](https://www.reddit.com/r/politics/comments/1dtnpct/the_supreme_court_rules_that_donald_trump_can_be)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T14:50:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtnpct/the_supreme_court_rules_that_donald_trump_can_be/"> <img alt="The Supreme Court rules that Donald Trump can be a dictator | If you're a (Republican) president, they let you do it" src="https://external-preview.redd.it/7PNALpzpw9fOu4YoEo5JZZjMtmDVixnZxtv5ljJbM9g.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ccd1620bf5de2f8a65a4461a3eb3ae5a9a05fd9b" title="The Supreme Court rules that Donald Trump can be a dictator | If you're a (Republican) president, they let you do it" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WhileFalseRepeat"> /u/WhileFalseRepeat </a> <br /> <span><a href="https://www.salon.com/2024/07/02/the-rules-that-donald-can-be-a-dictator/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtnpct/the_supreme_court_rules_that_donald_trump_can_be/">[comments]</a></span> </td></tr></table>

## AOC Vows to File Articles of Impeachment After Supreme Court Trump Ruling
 - [https://www.reddit.com/r/politics/comments/1dtndil/aoc_vows_to_file_articles_of_impeachment_after](https://www.reddit.com/r/politics/comments/1dtndil/aoc_vows_to_file_articles_of_impeachment_after)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T14:36:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtndil/aoc_vows_to_file_articles_of_impeachment_after/"> <img alt="AOC Vows to File Articles of Impeachment After Supreme Court Trump Ruling" src="https://external-preview.redd.it/OXLyzjKvmyZr1YqbWtn3Ga1ny8RipJl3fki6NhBnzkI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=885efd8ff34ea45cdc49e2e511d9e3ffa1af7cc9" title="AOC Vows to File Articles of Impeachment After Supreme Court Trump Ruling" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Murky-Site7468"> /u/Murky-Site7468 </a> <br /> <span><a href="https://www.commondreams.org/news/supreme-court-justice-impeachment">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtndil/aoc_vows_to_file_articles_of_impeachment_after/">[comments]</a></span> </td></tr></table>

## Column: With its 'Chevron' ruling, the Supreme Court shows that it thinks it's smarter than scientific experts
 - [https://www.reddit.com/r/politics/comments/1dtnak9/column_with_its_chevron_ruling_the_supreme_court](https://www.reddit.com/r/politics/comments/1dtnak9/column_with_its_chevron_ruling_the_supreme_court)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T14:32:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtnak9/column_with_its_chevron_ruling_the_supreme_court/"> <img alt="Column: With its 'Chevron' ruling, the Supreme Court shows that it thinks it's smarter than scientific experts" src="https://external-preview.redd.it/CAVyV7iKHyNfzu-2YZwvNVpB8P-gYhx--D-O2XYorb8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8106b34c7906f6bcc7ad8ed58a6b770a7cd403df" title="Column: With its 'Chevron' ruling, the Supreme Court shows that it thinks it's smarter than scientific experts" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/That49er"> /u/That49er </a> <br /> <span><a href="https://www.latimes.com/business/story/2024-07-02/with-its-chevron-ruling-the-supreme-court-shows-that-it-thinks-its-smarter-than-scientific-experts">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtnak9/column_with_its_chevron_ruling_the_supreme_court/">[comments]</a></span> </td></tr></t

## Democrats move to expand Supreme Court after Trump immunity ruling
 - [https://www.reddit.com/r/politics/comments/1dtn3qa/democrats_move_to_expand_supreme_court_after](https://www.reddit.com/r/politics/comments/1dtn3qa/democrats_move_to_expand_supreme_court_after)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T14:24:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtn3qa/democrats_move_to_expand_supreme_court_after/"> <img alt="Democrats move to expand Supreme Court after Trump immunity ruling" src="https://external-preview.redd.it/qUZ84ilXwM7yp1Q7A6jhb_fBNr4YjkAUfipA7GHOunA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1f79c690dcb25293c24dd3df3a9517cf0dac60a1" title="Democrats move to expand Supreme Court after Trump immunity ruling" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/willywalloo"> /u/willywalloo </a> <br /> <span><a href="https://www.newsweek.com/democrats-move-expand-supreme-court-trump-ruling-1919976">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtn3qa/democrats_move_to_expand_supreme_court_after/">[comments]</a></span> </td></tr></table>

## AOC, fellow Dems explore recourses following Supreme Court ruling
 - [https://www.reddit.com/r/politics/comments/1dtmh81/aoc_fellow_dems_explore_recourses_following](https://www.reddit.com/r/politics/comments/1dtmh81/aoc_fellow_dems_explore_recourses_following)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T13:57:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtmh81/aoc_fellow_dems_explore_recourses_following/"> <img alt="AOC, fellow Dems explore recourses following Supreme Court ruling" src="https://external-preview.redd.it/LHO4neFdzECIK2q7sNI_sib-GOZWURUodJWxpxbwHe8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=319fb7545436c7e195ab4875058512fe747407f7" title="AOC, fellow Dems explore recourses following Supreme Court ruling" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/willywalloo"> /u/willywalloo </a> <br /> <span><a href="https://www.msnbc.com/rachel-maddow-show/maddowblog/aoc-fellow-dems-explore-recourses-supreme-court-ruling-rcna159919">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtmh81/aoc_fellow_dems_explore_recourses_following/">[comments]</a></span> </td></tr></table>

## The John Roberts Guide to Doing a Coup and Not Getting Caught
 - [https://www.reddit.com/r/politics/comments/1dtm46r/the_john_roberts_guide_to_doing_a_coup_and_not](https://www.reddit.com/r/politics/comments/1dtm46r/the_john_roberts_guide_to_doing_a_coup_and_not)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T13:40:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtm46r/the_john_roberts_guide_to_doing_a_coup_and_not/"> <img alt="The John Roberts Guide to Doing a Coup and Not Getting Caught" src="https://external-preview.redd.it/De9XMVEgg0D2XFGeAJx7K2WYhnOk-YWCmKiirgINd-8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4b2aa7e3d2e141c68c574dac8ee3d8800deed397" title="The John Roberts Guide to Doing a Coup and Not Getting Caught" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Vegetable_Ear_8440"> /u/Vegetable_Ear_8440 </a> <br /> <span><a href="https://talkingpointsmemo.com/news/john-roberts-january-6-trump-immunity">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtm46r/the_john_roberts_guide_to_doing_a_coup_and_not/">[comments]</a></span> </td></tr></table>

## Trump amplifies posts calling for televised military tribunal for Liz Cheney
 - [https://www.reddit.com/r/politics/comments/1dtlyna/trump_amplifies_posts_calling_for_televised](https://www.reddit.com/r/politics/comments/1dtlyna/trump_amplifies_posts_calling_for_televised)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T13:33:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtlyna/trump_amplifies_posts_calling_for_televised/"> <img alt="Trump amplifies posts calling for televised military tribunal for Liz Cheney" src="https://external-preview.redd.it/EHQcM7W1AU5ATpPUKb51zJtb49-2eK1-CUYf4m3msc4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9335ee999f74e0acb1d2f2c8247eca9e6421e34e" title="Trump amplifies posts calling for televised military tribunal for Liz Cheney" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/willywalloo"> /u/willywalloo </a> <br /> <span><a href="https://www.cnn.com/2024/07/02/politics/trump-liz-cheney-military-tribunal/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtlyna/trump_amplifies_posts_calling_for_televised/">[comments]</a></span> </td></tr></table>

## 'Absurd and Nakedly Partisan': Trump-Appointed Judge Blocks Biden LNG Pause | "Trump judges are hellbent on torching environmental safeguards, the climate, and our democracy," said an attorney for the Center for Biological Diversity.
 - [https://www.reddit.com/r/politics/comments/1dtleyf/absurd_and_nakedly_partisan_trumpappointed_judge](https://www.reddit.com/r/politics/comments/1dtleyf/absurd_and_nakedly_partisan_trumpappointed_judge)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T13:07:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtleyf/absurd_and_nakedly_partisan_trumpappointed_judge/"> <img alt="'Absurd and Nakedly Partisan': Trump-Appointed Judge Blocks Biden LNG Pause | &quot;Trump judges are hellbent on torching environmental safeguards, the climate, and our democracy,&quot; said an attorney for the Center for Biological Diversity." src="https://external-preview.redd.it/NDhD-wjSMeVN95qzORfQV-gGCS2eLWH4XfbIeYlHPGI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6a5ebfa698c3ded7681de78a3b72673fdfbb7337" title="'Absurd and Nakedly Partisan': Trump-Appointed Judge Blocks Biden LNG Pause | &quot;Trump judges are hellbent on torching environmental safeguards, the climate, and our democracy,&quot; said an attorney for the Center for Biological Diversity." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Murky-Site7468"> /u/Murky-Site7468 </a> <br /> <span><a href="https://www.commondreams.org/news/biden-lng-paus

## New York Dem will introduce amendment to reverse Supreme Court immunity ruling
 - [https://www.reddit.com/r/politics/comments/1dtlakr/new_york_dem_will_introduce_amendment_to_reverse](https://www.reddit.com/r/politics/comments/1dtlakr/new_york_dem_will_introduce_amendment_to_reverse)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T13:01:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtlakr/new_york_dem_will_introduce_amendment_to_reverse/"> <img alt="New York Dem will introduce amendment to reverse Supreme Court immunity ruling" src="https://external-preview.redd.it/ipQy1XwUOxTrOmyZ0c9SqnUl5BNOA9JgLhEEp-WQRDA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=856a512026b68a1838bb76c50ef923c436e2f38c" title="New York Dem will introduce amendment to reverse Supreme Court immunity ruling" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheAnswerWithinUs"> /u/TheAnswerWithinUs </a> <br /> <span><a href="https://thehill.com/homenews/house/4750735-joe-morelle-amendment-supreme-court-immunity-ruling/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtlakr/new_york_dem_will_introduce_amendment_to_reverse/">[comments]</a></span> </td></tr></table>

## Roberts’ Supreme Court opens world of dangerous possibilities
 - [https://www.reddit.com/r/politics/comments/1dtl6zw/roberts_supreme_court_opens_world_of_dangerous](https://www.reddit.com/r/politics/comments/1dtl6zw/roberts_supreme_court_opens_world_of_dangerous)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T12:57:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtl6zw/roberts_supreme_court_opens_world_of_dangerous/"> <img alt="Roberts’ Supreme Court opens world of dangerous possibilities" src="https://external-preview.redd.it/NgioLX5qcZW2YnTFc3hI4LCBb5P797pLxyaRkCx9aH0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=632b70f62763867f2a7c2ad8c7bb059721250cad" title="Roberts’ Supreme Court opens world of dangerous possibilities" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/That49er"> /u/That49er </a> <br /> <span><a href="https://lasvegassun.com/news/2024/jul/02/roberts-supreme-court-opens-world-of-dangerous-pos//">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtl6zw/roberts_supreme_court_opens_world_of_dangerous/">[comments]</a></span> </td></tr></table>

## Biden campaign tells donors president can recover from subpar debate performance
 - [https://www.reddit.com/r/politics/comments/1dtkz9i/biden_campaign_tells_donors_president_can_recover](https://www.reddit.com/r/politics/comments/1dtkz9i/biden_campaign_tells_donors_president_can_recover)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T12:46:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtkz9i/biden_campaign_tells_donors_president_can_recover/"> <img alt="Biden campaign tells donors president can recover from subpar debate performance" src="https://external-preview.redd.it/nSaYU6rlufChydv2ufgyAs-nW_ZyU6okR_h6TfJX-Bs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=abda5c3ed262adf669fa3987152d0aa8b4fbdf61" title="Biden campaign tells donors president can recover from subpar debate performance" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ishtar_the_move"> /u/ishtar_the_move </a> <br /> <span><a href="https://www.nbcnews.com/politics/joe-biden/biden-campaign-tells-donors-president-can-recover-subpar-debate-perfor-rcna159893">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtkz9i/biden_campaign_tells_donors_president_can_recover/">[comments]</a></span> </td></tr></table>

## Trump claims Biden will pay 'price' for 'weaponization' of justice after Bannon's sentence
 - [https://www.reddit.com/r/politics/comments/1dtkpp5/trump_claims_biden_will_pay_price_for](https://www.reddit.com/r/politics/comments/1dtkpp5/trump_claims_biden_will_pay_price_for)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T12:33:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtkpp5/trump_claims_biden_will_pay_price_for/"> <img alt="Trump claims Biden will pay 'price' for 'weaponization' of justice after Bannon's sentence" src="https://external-preview.redd.it/qT9gbvSIaz1Cm-dm7qAfxk_owBU0YOtf5Hmgtx98n6k.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=24b1aaabcfa9b7ea536134e6bab6511872be4d13" title="Trump claims Biden will pay 'price' for 'weaponization' of justice after Bannon's sentence" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PrintOk8045"> /u/PrintOk8045 </a> <br /> <span><a href="https://www.usatoday.com/story/news/politics/elections/2024/07/02/trump-claims-biden-price-for-weaponization/74277406007/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtkpp5/trump_claims_biden_will_pay_price_for/">[comments]</a></span> </td></tr></table>

## Donald Trump Says Fake Electors Scheme Was 'Official Act'
 - [https://www.reddit.com/r/politics/comments/1dtkod6/donald_trump_says_fake_electors_scheme_was](https://www.reddit.com/r/politics/comments/1dtkod6/donald_trump_says_fake_electors_scheme_was)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T12:31:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtkod6/donald_trump_says_fake_electors_scheme_was/"> <img alt="Donald Trump Says Fake Electors Scheme Was 'Official Act'" src="https://external-preview.redd.it/bKD9NXX-OIrYb6I3ien4vlvMh9v2Vb4URRljahlv7Rg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d3781eb9fd50f68eb925a3aae639cf512e23fcea" title="Donald Trump Says Fake Electors Scheme Was 'Official Act'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SicilyMalta"> /u/SicilyMalta </a> <br /> <span><a href="https://www.newsweek.com/donald-trump-fake-electors-scheme-supreme-court-1919928">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtkod6/donald_trump_says_fake_electors_scheme_was/">[comments]</a></span> </td></tr></table>

## Day two of Donald Trump's dictatorship | Plotting out the demise of the American presidency
 - [https://www.reddit.com/r/politics/comments/1dtixkq/day_two_of_donald_trumps_dictatorship_plotting](https://www.reddit.com/r/politics/comments/1dtixkq/day_two_of_donald_trumps_dictatorship_plotting)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T10:53:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtixkq/day_two_of_donald_trumps_dictatorship_plotting/"> <img alt="Day two of Donald Trump's dictatorship | Plotting out the demise of the American presidency" src="https://external-preview.redd.it/uytIQzC5L-Hebe5gI6CwH6gN47lB13Ag8LVBKjeHdg4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7aa5e2a3664f4f2c75994d1efe0177fa601266e9" title="Day two of Donald Trump's dictatorship | Plotting out the demise of the American presidency" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/the-wave"> /u/the-wave </a> <br /> <span><a href="https://www.salon.com/2024/07/02/day-two-of-donald-dictatorship/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtixkq/day_two_of_donald_trumps_dictatorship_plotting/">[comments]</a></span> </td></tr></table>

## Biden campaign gets a bit of good news as it announces it hauled in $127 million in June
 - [https://www.reddit.com/r/politics/comments/1dti8gp/biden_campaign_gets_a_bit_of_good_news_as_it](https://www.reddit.com/r/politics/comments/1dti8gp/biden_campaign_gets_a_bit_of_good_news_as_it)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T10:07:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dti8gp/biden_campaign_gets_a_bit_of_good_news_as_it/"> <img alt="Biden campaign gets a bit of good news as it announces it hauled in $127 million in June " src="https://external-preview.redd.it/VzJrB2nhysNy5z35sVTzXwuVcn5YUhamlHlcqGIjTAc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=300371e0a4060c9faf121791eaeeb7a0a0818cc0" title="Biden campaign gets a bit of good news as it announces it hauled in $127 million in June " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Scarlet-Ivy"> /u/Scarlet-Ivy </a> <br /> <span><a href="https://www.cnn.com/2024/07/02/politics/joe-biden-campaign-fundraising-june/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dti8gp/biden_campaign_gets_a_bit_of_good_news_as_it/">[comments]</a></span> </td></tr></table>

## Supreme Court 'Wreaks Havoc' With Ruling, Ketanji Brown Jackson Warns
 - [https://www.reddit.com/r/politics/comments/1dtelva/supreme_court_wreaks_havoc_with_ruling_ketanji](https://www.reddit.com/r/politics/comments/1dtelva/supreme_court_wreaks_havoc_with_ruling_ketanji)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T05:55:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtelva/supreme_court_wreaks_havoc_with_ruling_ketanji/"> <img alt="Supreme Court 'Wreaks Havoc' With Ruling, Ketanji Brown Jackson Warns" src="https://external-preview.redd.it/SQu3kBXoMcm3812osuThKPIj5KsJBgmkRMWQgWGh1VA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d331876f9e03bdca4366ac1c9a0e34bc1aec1dd2" title="Supreme Court 'Wreaks Havoc' With Ruling, Ketanji Brown Jackson Warns" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/relievedtyrant"> /u/relievedtyrant </a> <br /> <span><a href="https://www.newsweek.com/supreme-court-wreaks-havoc-ruling-ketanji-brown-jackson-warns-1919907">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtelva/supreme_court_wreaks_havoc_with_ruling_ketanji/">[comments]</a></span> </td></tr></table>

## The Supreme Court Turns the President Into a King - The conservative justices have ignored history altogether and created a shocking new precedent: The president is above the law.
 - [https://www.reddit.com/r/politics/comments/1dtel0h/the_supreme_court_turns_the_president_into_a_king](https://www.reddit.com/r/politics/comments/1dtel0h/the_supreme_court_turns_the_president_into_a_king)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T05:54:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtel0h/the_supreme_court_turns_the_president_into_a_king/"> <img alt="The Supreme Court Turns the President Into a King - The conservative justices have ignored history altogether and created a shocking new precedent: The president is above the law." src="https://external-preview.redd.it/Qzxvtj4RGB21VtHMSoSY13i1LnQA4Sm1AwVdfGUNKk0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=65d83360996687df919041614332f501fe5d88f6" title="The Supreme Court Turns the President Into a King - The conservative justices have ignored history altogether and created a shocking new precedent: The president is above the law." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br /> <span><a href="https://newrepublic.com/article/183357/supreme-court-turns-president-king">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtel0h/the_supreme_court_turns_

## God save us from this dishonorable court | An egregious, unconscionable ruling on presidential immunity from the Supreme Court
 - [https://www.reddit.com/r/politics/comments/1dtdg9o/god_save_us_from_this_dishonorable_court_an](https://www.reddit.com/r/politics/comments/1dtdg9o/god_save_us_from_this_dishonorable_court_an)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T04:41:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dtdg9o/god_save_us_from_this_dishonorable_court_an/"> <img alt="God save us from this dishonorable court | An egregious, unconscionable ruling on presidential immunity from the Supreme Court" src="https://external-preview.redd.it/Z6T23N6w_uQDBIsoIAnNtlE51r2lCtrX13hhZzQc-1M.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=73a8ed2b95cbbebb7dc7d6c733219b45cf9d9ec5" title="God save us from this dishonorable court | An egregious, unconscionable ruling on presidential immunity from the Supreme Court" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Hrmbee"> /u/Hrmbee </a> <br /> <span><a href="https://www.washingtonpost.com/opinions/2024/07/01/immunity-trump-justices-2024/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dtdg9o/god_save_us_from_this_dishonorable_court_an/">[comments]</a></span> </td></tr></table>

## Supreme Court Immunity Ruling Destroys Independent Justice Department
 - [https://www.reddit.com/r/politics/comments/1dt9vi4/supreme_court_immunity_ruling_destroys](https://www.reddit.com/r/politics/comments/1dt9vi4/supreme_court_immunity_ruling_destroys)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T01:30:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dt9vi4/supreme_court_immunity_ruling_destroys/"> <img alt="Supreme Court Immunity Ruling Destroys Independent Justice Department" src="https://external-preview.redd.it/TcS44CkAWdatDrets9DqpcvAh10zcSECbJK36GPnlkQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a08108e1b5d280ebae3e5eb0c74f0013a5a61e2c" title="Supreme Court Immunity Ruling Destroys Independent Justice Department" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Infidel8"> /u/Infidel8 </a> <br /> <span><a href="https://newrepublic.com/post/183331/john-roberts-supreme-court-obliterates-independent-justice-department">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dt9vi4/supreme_court_immunity_ruling_destroys/">[comments]</a></span> </td></tr></table>

## Clarence Thomas Goes After Jack Smith in Supreme Court Ruling
 - [https://www.reddit.com/r/politics/comments/1dt9t2b/clarence_thomas_goes_after_jack_smith_in_supreme](https://www.reddit.com/r/politics/comments/1dt9t2b/clarence_thomas_goes_after_jack_smith_in_supreme)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T01:27:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dt9t2b/clarence_thomas_goes_after_jack_smith_in_supreme/"> <img alt="Clarence Thomas Goes After Jack Smith in Supreme Court Ruling " src="https://external-preview.redd.it/HNkS9hXgz3veBS_-RelRPn8XyuQhDepiRez8N6fd1nk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=197c57d620123cf4362107241e5343245cb39e21" title="Clarence Thomas Goes After Jack Smith in Supreme Court Ruling " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/tmaddog91"> /u/tmaddog91 </a> <br /> <span><a href="https://www.newsweek.com/clarence-thomas-jack-smith-supreme-court-ruling-donald-trump-immunity-1919643">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dt9t2b/clarence_thomas_goes_after_jack_smith_in_supreme/">[comments]</a></span> </td></tr></table>

## ‘A terrible disservice’: Biden slams Supreme Court immunity ruling, says it lets presidents ignore the law
 - [https://www.reddit.com/r/politics/comments/1dt8bpb/a_terrible_disservice_biden_slams_supreme_court](https://www.reddit.com/r/politics/comments/1dt8bpb/a_terrible_disservice_biden_slams_supreme_court)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T00:13:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dt8bpb/a_terrible_disservice_biden_slams_supreme_court/"> <img alt="‘A terrible disservice’: Biden slams Supreme Court immunity ruling, says it lets presidents ignore the law" src="https://external-preview.redd.it/oJ1oA5L0JLY8fwkGGKL_IL_KLovRSXFt6k7kA3YhceE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=46976420811a3b0b7c8cee66c5b9f2294e75c082" title="‘A terrible disservice’: Biden slams Supreme Court immunity ruling, says it lets presidents ignore the law" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sabedo"> /u/sabedo </a> <br /> <span><a href="https://www.independent.co.uk/news/world/americas/us-politics/trump-supreme-court-immunity-ruling-biden-b2572243.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dt8bpb/a_terrible_disservice_biden_slams_supreme_court/">[comments]</a></span> </td></tr></table>

## Biden says he will 'respect the limits of power,' after Supreme Court immunity ruling
 - [https://www.reddit.com/r/politics/comments/1dt889a/biden_says_he_will_respect_the_limits_of_power](https://www.reddit.com/r/politics/comments/1dt889a/biden_says_he_will_respect_the_limits_of_power)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-07-02T00:09:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dt889a/biden_says_he_will_respect_the_limits_of_power/"> <img alt="Biden says he will 'respect the limits of power,' after Supreme Court immunity ruling" src="https://external-preview.redd.it/pMZwAJkEzFmDiOxCEv-Y_k5ILJTssijiTXi4srhmef4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c86fd7eb1d5e7a927167ba16f6fd7df711c3fcbd" title="Biden says he will 'respect the limits of power,' after Supreme Court immunity ruling" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/coasterghost"> /u/coasterghost </a> <br /> <span><a href="https://apnews.com/article/c47243b3cedb88ce6ea7905a1975e164">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dt889a/biden_says_he_will_respect_the_limits_of_power/">[comments]</a></span> </td></tr></table>

