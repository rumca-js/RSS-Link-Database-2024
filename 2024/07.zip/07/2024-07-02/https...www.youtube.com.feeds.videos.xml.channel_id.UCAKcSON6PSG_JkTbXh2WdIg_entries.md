# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Secret Sisters – If the World Was a House (live for The Current)
 - [https://www.youtube.com/watch?v=Ib_ZxEb-5AQ](https://www.youtube.com/watch?v=Ib_ZxEb-5AQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2024-07-02T02:00:07+00:00

The Secret Sisters – If the World Was a House live in The Current studio
Support The Current: https://support.mpr.org/youtube  

The Secret Sisters’ fifth studio album, "Mind, Man, Medicine," released on March 29, 2024, on New West Records. As part of the record release, The Secret Sisters — Laura Rogers and Lydia Slagle — visited the Twin Cities in May for two sold-out shows at the Parkway Theater in Minneapolis. Between shows, The Secret Sisters visited The Current for a session hosted by Bill DeVille. Watch The Secret Sisters' perform "If the World Was a House" above.

Musicians
Laura Rogers – vocals
Lydia Slagle – guitar, vocals

Credits
Guests – @thesecretsistersband 
Host – Bill DeVille
Producer – Derrick Stevens
Video – Eric Xu Romani
Audio – Evan Clark
Camera Operators – Eric Xu Romani, Megan Lundberg
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.faceb

