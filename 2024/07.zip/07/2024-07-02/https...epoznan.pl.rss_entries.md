# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## 43-latek najpierw zwabił kobietę do mieszkania, potem próbował ją zgwałcić
 - [https://epoznan.pl/news-news-152474-43_latek_najpierw_zwabil_kobiete_do_mieszkania_potem_probowal_ja_zgwalcic?rss=1](https://epoznan.pl/news-news-152474-43_latek_najpierw_zwabil_kobiete_do_mieszkania_potem_probowal_ja_zgwalcic?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T20:12:00+00:00

Do zdarzenia doszło w Ostrowie Wielkopolskim.

## Grupa Stonewall podziękowała Jackowi Jaśkowiakowi za to, że miasto współfinansowało &quot;Pride&quot;
 - [https://epoznan.pl/news-news-152473-grupa_stonewall_podziekowala_jackowi_jaskowiakowi_za_to_ze_miasto_wspolfinansowalo_pride?rss=1](https://epoznan.pl/news-news-152473-grupa_stonewall_podziekowala_jackowi_jaskowiakowi_za_to_ze_miasto_wspolfinansowalo_pride?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T19:33:00+00:00

W miniony weekend przez ulice Poznania przeszedł marsz równości.

## Mama niepełnosprawnej dziewczynki podziękowała uczciwemu znalazcy. &quot;Dzięki takim zachowaniom wraca wiara w człowieka&quot;
 - [https://epoznan.pl/news-news-152472-mama_niepelnosprawnej_dziewczynki_podziekowala_uczciwemu_znalazcy_dzieki_takim_zachowaniom_wraca_wiara_w_czlowieka?rss=1](https://epoznan.pl/news-news-152472-mama_niepelnosprawnej_dziewczynki_podziekowala_uczciwemu_znalazcy_dzieki_takim_zachowaniom_wraca_wiara_w_czlowieka?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T19:12:00+00:00

Kobieta jechała we wtorek z córką pociągiem relacji Śorda-Poznań Główny.

## Zebrali się pod biurem poselskim PO w obronie ks. Olszewskiego. &quot;Ten ksiądz jest egzorcystą&quot;
 - [https://epoznan.pl/news-news-152471-zebrali_sie_pod_biurem_poselskim_po_w_obronie_ks_olszewskiego_ten_ksiadz_jest_egzorcysta?rss=1](https://epoznan.pl/news-news-152471-zebrali_sie_pod_biurem_poselskim_po_w_obronie_ks_olszewskiego_ten_ksiadz_jest_egzorcysta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T18:53:00+00:00

Chodzi o księdza Michała Olszewskiego, który od marca przebywa w areszcie za zarzut defraudacji pieniędzy pochodzących z Funduszu Sprawiedliwości.

## Podopieczna DPS-u po latach wróciła do matki. Siostry Serafitki są zawiedzione, dziewczyna zamiast podziękować oskarżyła je o kradzież
 - [https://epoznan.pl/news-news-152470-podopieczna_dps_u_po_latach_wrocila_do_matki_siostry_serafitki_sa_zawiedzione_dziewczyna_zamiast_podziekowac_oskarzyla_je_o_kradziez?rss=1](https://epoznan.pl/news-news-152470-podopieczna_dps_u_po_latach_wrocila_do_matki_siostry_serafitki_sa_zawiedzione_dziewczyna_zamiast_podziekowac_oskarzyla_je_o_kradziez?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T17:39:00+00:00

Chodzi o Dom Pomocy Społecznej przy ul. Świętego Rocha w Poznaniu prowadzony przez Siostry Serafitki.

## Wciąż są mieszkańcy, u których po burzy wstrzymano dostawę energii elektrycznej
 - [https://epoznan.pl/news-news-152469-wciaz_sa_mieszkancy_u_ktorych_po_burzy_wstrzymano_dostawe_energii_elektrycznej?rss=1](https://epoznan.pl/news-news-152469-wciaz_sa_mieszkancy_u_ktorych_po_burzy_wstrzymano_dostawe_energii_elektrycznej?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T16:34:00+00:00

Czytelnicy zgłaszają redakcji epoznan.pl brak prądu.

## Administracja osiedla wprowadza nowy system parkingowy. Szlaban otworzy się tylko dla tablic rejestracyjnych, które będą w bazie danych
 - [https://epoznan.pl/news-news-152468-administracja_osiedla_wprowadza_nowy_system_parkingowy_szlaban_otworzy_sie_tylko_dla_tablic_rejestracyjnych_ktore_beda_w_bazie_danych?rss=1](https://epoznan.pl/news-news-152468-administracja_osiedla_wprowadza_nowy_system_parkingowy_szlaban_otworzy_sie_tylko_dla_tablic_rejestracyjnych_ktore_beda_w_bazie_danych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T16:18:00+00:00

Chodzi o os. Jana III Sobieskiego w Poznaniu.

## Kierowcy wstrzymali ruch dla kaczej rodziny. Potem była wojna o to, gdzie kaczki mają trafić. &quot;W pobliżu grasuje lis&quot;
 - [https://epoznan.pl/news-news-152467-kierowcy_wstrzymali_ruch_dla_kaczej_rodziny_potem_byla_wojna_o_to_gdzie_kaczki_maja_trafic_w_poblizu_grasuje_lis?rss=1](https://epoznan.pl/news-news-152467-kierowcy_wstrzymali_ruch_dla_kaczej_rodziny_potem_byla_wojna_o_to_gdzie_kaczki_maja_trafic_w_poblizu_grasuje_lis?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T16:04:00+00:00

Niecodzienna scena rozegrała się we wtorek około 9:30 na ul. Hlonda w Poznaniu.

## Radna miejska z ramienia PiS namawia do protestu w obronie księdza Olszewskiego pod biurem poselskim PO
 - [https://epoznan.pl/news-news-152466-radna_miejska_z_ramienia_pis_namawia_do_protestu_w_obronie_ksiedza_olszewskiego_pod_biurem_poselskim_po?rss=1](https://epoznan.pl/news-news-152466-radna_miejska_z_ramienia_pis_namawia_do_protestu_w_obronie_ksiedza_olszewskiego_pod_biurem_poselskim_po?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T15:40:00+00:00

Chodzi o księdza Michała Olszewskiego, który jest jednym z dziesięciu podejrzanych w sprawie wydatkowania środków z Funduszu Sprawiedliwości.

## Znaleźli reklamówki z pszczołami. Część z nich została rozjechana. Kobieta miała silne uczulenie na pszczeli jad
 - [https://epoznan.pl/news-news-152465-znalezli_reklamowki_z_pszczolami_czesc_z_nich_zostala_rozjechana_kobieta_miala_silne_uczulenie_na_pszczeli_jad?rss=1](https://epoznan.pl/news-news-152465-znalezli_reklamowki_z_pszczolami_czesc_z_nich_zostala_rozjechana_kobieta_miala_silne_uczulenie_na_pszczeli_jad?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T14:57:00+00:00

Strażnicy miejscy w sobotę zostali wezwani do nietypowej interwencji.

## Strażacy kolejną dobę walczą ze skutkami nawałnicy. Najwięcej interwencji w Wielkopolsce
 - [https://epoznan.pl/news-news-152464-strazacy_kolejna_dobe_walcza_ze_skutkami_nawalnicy_najwiecej_interwencji_w_wielkopolsce?rss=1](https://epoznan.pl/news-news-152464-strazacy_kolejna_dobe_walcza_ze_skutkami_nawalnicy_najwiecej_interwencji_w_wielkopolsce?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T14:23:00+00:00

Wciąż trwają działania strażaków na terenie Wielkopolski.

## Ruszył nowy miejski program za miliony. Już można się zgłaszać
 - [https://epoznan.pl/news-news-152459-ruszyl_nowy_miejski_program_za_miliony_juz_mozna_sie_zglaszac?rss=1](https://epoznan.pl/news-news-152459-ruszyl_nowy_miejski_program_za_miliony_juz_mozna_sie_zglaszac?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T12:55:00+00:00

Chodzi o &quot;Pomoc po sąsiedzku&quot;.

## Tysiące uczestników i chrzest w basenie na MTP
 - [https://epoznan.pl/news-news-152463-tysiace_uczestnikow_i_chrzest_w_basenie_na_mtp?rss=1](https://epoznan.pl/news-news-152463-tysiace_uczestnikow_i_chrzest_w_basenie_na_mtp?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T12:50:00+00:00

W weekend w Poznaniu odbył się kongres Świadków Jehowy.

## Orłosęp, który zatrzymał się w Poznaniu podczas burzy, wciąż w poznańskim ZOO
 - [https://epoznan.pl/news-news-152461-orlosep_ktory_zatrzymal_sie_w_poznaniu_podczas_burzy_wciaz_w_poznanskim_zoo?rss=1](https://epoznan.pl/news-news-152461-orlosep_ktory_zatrzymal_sie_w_poznaniu_podczas_burzy_wciaz_w_poznanskim_zoo?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T12:47:00+00:00

Dziki ptak czeka na decyzję, która pozwoli mu wrócić do Francji, skąd przyleciał.

## Zostawiła psa w aucie przy markecie w upale. Wezwano Policję
 - [https://epoznan.pl/news-news-152462-zostawila_psa_w_aucie_przy_markecie_w_upale_wezwano_policje?rss=1](https://epoznan.pl/news-news-152462-zostawila_psa_w_aucie_przy_markecie_w_upale_wezwano_policje?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T12:40:00+00:00

Do zdarzenia doszło w czwartek w Obornikach.

## W końcu! Podpiszą umowę na budowę S11 Poznań - Oborniki
 - [https://epoznan.pl/news-news-152458-w_koncu_podpisza_umowe_na_budowe_s11_poznan_oborniki?rss=1](https://epoznan.pl/news-news-152458-w_koncu_podpisza_umowe_na_budowe_s11_poznan_oborniki?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T12:30:00+00:00

Uroczyste podpisanie zaplanowano na środę.

## Wkrótce remont ważnej poznańskiej trasy. To kolejny etap prac
 - [https://epoznan.pl/news-news-152457-wkrotce_remont_waznej_poznanskiej_trasy_to_kolejny_etap_prac?rss=1](https://epoznan.pl/news-news-152457-wkrotce_remont_waznej_poznanskiej_trasy_to_kolejny_etap_prac?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T12:10:00+00:00

Będą utrudnienia.

## Właściciele aut elektrycznych w Poznaniu dostają mandaty za parkowanie na legalnych miejscach. Powód? Są za ciężkie
 - [https://epoznan.pl/news-news-152460-wlasciciele_aut_elektrycznych_w_poznaniu_dostaja_mandaty_za_parkowanie_na_legalnych_miejscach_powod_sa_za_ciezkie?rss=1](https://epoznan.pl/news-news-152460-wlasciciele_aut_elektrycznych_w_poznaniu_dostaja_mandaty_za_parkowanie_na_legalnych_miejscach_powod_sa_za_ciezkie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T11:55:00+00:00

Problem jest spory.

## Kierowca prowadził peugeota ze śmiertelną dawką alkoholu w organizmie. Na siedzeniu pasażera butelka po piwie. Będą kontrole!
 - [https://epoznan.pl/news-news-152456-kierowca_prowadzil_peugeota_ze_smiertelna_dawka_alkoholu_w_organizmie_na_siedzeniu_pasazera_butelka_po_piwie_beda_kontrole?rss=1](https://epoznan.pl/news-news-152456-kierowca_prowadzil_peugeota_ze_smiertelna_dawka_alkoholu_w_organizmie_na_siedzeniu_pasazera_butelka_po_piwie_beda_kontrole?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T11:40:00+00:00

49-latek na szczęście nikogo nie zabił.

## Wiadomo, kto będzie nadzorować modernizację kolejowej Towarowej Obwodnicy Poznania. Ma być terminowo
 - [https://epoznan.pl/news-news-152455-wiadomo_kto_bedzie_nadzorowac_modernizacje_kolejowej_towarowej_obwodnicy_poznania_ma_byc_terminowo?rss=1](https://epoznan.pl/news-news-152455-wiadomo_kto_bedzie_nadzorowac_modernizacje_kolejowej_towarowej_obwodnicy_poznania_ma_byc_terminowo?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T11:10:00+00:00

PKP PLK podpisały umowę na ponad 10 mln złotych netto.

## Będą opłaty za parkowanie w SPP w centrum i na Jeżycach w niedzielę?
 - [https://epoznan.pl/news-news-152454-beda_oplaty_za_parkowanie_w_spp_w_centrum_i_na_jezycach_w_niedziele?rss=1](https://epoznan.pl/news-news-152454-beda_oplaty_za_parkowanie_w_spp_w_centrum_i_na_jezycach_w_niedziele?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T10:30:00+00:00

Zdaniem Piotra Libickiego z ZDM, właśnie w niedzielę, gdy opłaty nie są pobierane, strefa bardzo się wypełnia.

## Kolejne bloki przy Posnanii gotowe. W środku 370 mieszkań na wynajem
 - [https://epoznan.pl/news-news-152452-kolejne_bloki_przy_posnanii_gotowe_w_srodku_370_mieszkan_na_wynajem?rss=1](https://epoznan.pl/news-news-152452-kolejne_bloki_przy_posnanii_gotowe_w_srodku_370_mieszkan_na_wynajem?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T09:45:00+00:00

Wybudowano je przy ulicach Skowrońskiego i Niemena, po sąsiedzku.

## Koszmarna sytuacja w lasach po nawałnicach. Trąba powietrzna &quot;wycięła&quot; drzewa
 - [https://epoznan.pl/news-news-152450-koszmarna_sytuacja_w_lasach_po_nawalnicach_traba_powietrzna_wyciela_drzewa?rss=1](https://epoznan.pl/news-news-152450-koszmarna_sytuacja_w_lasach_po_nawalnicach_traba_powietrzna_wyciela_drzewa?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T09:05:00+00:00

Do zdarzenia doszło pod Piłą.

## Znana wizażystka z regionu zmarła w tajemniczych okolicznościach
 - [https://epoznan.pl/news-news-152449-znana_wizazystka_z_regionu_zmarla_w_tajemniczych_okolicznosciach?rss=1](https://epoznan.pl/news-news-152449-znana_wizazystka_z_regionu_zmarla_w_tajemniczych_okolicznosciach?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T08:25:00+00:00

Rodzina zapowiada, że nie ustanie w drodze do odkrycia prawdy.

## Dachowanie auta w Poznaniu. Korek
 - [https://epoznan.pl/news-news-152451-dachowanie_auta_w_poznaniu_korek?rss=1](https://epoznan.pl/news-news-152451-dachowanie_auta_w_poznaniu_korek?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T07:55:00+00:00

Do zdarzenia doszło na Lechickiej.

## Mateusz Morawiecki nagrodzony w Poznaniu statuetką im. Lecha Kaczyńskiego
 - [https://epoznan.pl/news-news-152447-mateusz_morawiecki_nagrodzony_w_poznaniu_statuetka_im_lecha_kaczynskiego?rss=1](https://epoznan.pl/news-news-152447-mateusz_morawiecki_nagrodzony_w_poznaniu_statuetka_im_lecha_kaczynskiego?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T07:20:00+00:00

Otrzymał ją od Akademickiego Klubu Obywatelskiego im. Lecha Kaczyńskiego.

## Powstały nowe bloki, auta parkujące na ulicy prowadzą do niebezpiecznych sytuacji. Pyskówki i rękoczyny kierowców, pourywane lusterka
 - [https://epoznan.pl/news-news-152446-powstaly_nowe_bloki_auta_parkujace_na_ulicy_prowadza_do_niebezpiecznych_sytuacji_pyskowki_i_rekoczyny_kierowcow_pourywane_lusterka?rss=1](https://epoznan.pl/news-news-152446-powstaly_nowe_bloki_auta_parkujace_na_ulicy_prowadza_do_niebezpiecznych_sytuacji_pyskowki_i_rekoczyny_kierowcow_pourywane_lusterka?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T06:45:00+00:00

Na Namysłowskiej.

## Jechał trasą S5 pod prąd, spowodował kolizję z innym autem. Tłumaczył, że tak prowadziła go nawigacja
 - [https://epoznan.pl/news-news-152445-jechal_trasa_s5_pod_prad_spowodowal_kolizje_z_innym_autem_tlumaczyl_ze_tak_prowadzila_go_nawigacja?rss=1](https://epoznan.pl/news-news-152445-jechal_trasa_s5_pod_prad_spowodowal_kolizje_z_innym_autem_tlumaczyl_ze_tak_prowadzila_go_nawigacja?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T06:10:00+00:00

69-latek stracił prawo jazdy.

## Nocne przeloty F-16 nad miastem. &quot;Generują przy tym hałas 100 dB&quot;
 - [https://epoznan.pl/news-news-152443-nocne_przeloty_f_16_nad_miastem_generuja_przy_tym_halas_100_db?rss=1](https://epoznan.pl/news-news-152443-nocne_przeloty_f_16_nad_miastem_generuja_przy_tym_halas_100_db?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T05:35:00+00:00

W tej sprawie napisały do nas dwie osoby.

## Nietypowe przeszkody na poznańskiej ulicy. Na jezdni leżą skrzynki i owoce
 - [https://epoznan.pl/news-news-152444-nietypowe_przeszkody_na_poznanskiej_ulicy_na_jezdni_leza_skrzynki_i_owoce?rss=1](https://epoznan.pl/news-news-152444-nietypowe_przeszkody_na_poznanskiej_ulicy_na_jezdni_leza_skrzynki_i_owoce?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-07-02T05:08:00+00:00

Na Szwajcarskiej od rana niebezpiecznie.

