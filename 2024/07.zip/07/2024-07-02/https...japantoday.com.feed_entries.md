# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## Taiwan says China seizes fishing boat near Chinese coast
 - [https://japantoday.com/category/world/taiwan-says-china-seizes-fishing-boat-near-chinese-coast](https://japantoday.com/category/world/taiwan-says-china-seizes-fishing-boat-near-chinese-coast)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T23:00:23+00:00

Chinese officials boarded and then seized a Taiwanese fishing boat operating near China's coast close to a Taiwan-controlled island and took it to a Chinese port, the Taiwan…

## Canadian court allows police to clear pro-Palestinian campus encampment
 - [https://japantoday.com/category/world/canadian-court-allows-police-to-clear-pro-palestinian-campus-encampment](https://japantoday.com/category/world/canadian-court-allows-police-to-clear-pro-palestinian-campus-encampment)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:58:53+00:00

An Ontario judge ordered pro-Palestinian protesters to leave their two-month-old encampment at Canada's largest university by Wednesday evening, granting the University of Toronto's injunction request in a ruling…

## U.S. Air Force resumes Osprey flights in Japan after Nov. fatal crash
 - [https://japantoday.com/category/national/u.s.-air-force-resumes-osprey-flights-in-japan-after-nov.-fatal-crash](https://japantoday.com/category/national/u.s.-air-force-resumes-osprey-flights-in-japan-after-nov.-fatal-crash)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:56:48+00:00

The U.S. Air Force on Tuesday resumed flights of its Ospreys in Japan after suspending them following a fatal crash of one of its tilt-rotor aircraft off a…

## Austin keeping close eye on U.S. troops' sex crime cases in Okinawa
 - [https://japantoday.com/category/politics/austin-keeping-close-eye-on-u.s.-troops%27-sex-crime-cases-in-okinawa](https://japantoday.com/category/politics/austin-keeping-close-eye-on-u.s.-troops%27-sex-crime-cases-in-okinawa)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:42:53+00:00

U.S. Defense Secretary Lloyd Austin is closely tracking the cases of U.S. military personnel accused of committing sexual crimes in the southern Japan island prefecture of Okinawa, a…

## Return service
 - [https://japantoday.com/category/picture-of-the-day/return-service](https://japantoday.com/category/picture-of-the-day/return-service)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:35:36+00:00

Kei Nishikori plays a forehand return to Arthur Rinderknech of France during their first round match at the Wimbledon tennis championships in London, on Tuesday.

## Murray out of Wimbledon singles as Djokovic makes bow
 - [https://japantoday.com/category/sports/murray-out-of-wimbledon-singles-as-djokovic-makes-bow](https://japantoday.com/category/sports/murray-out-of-wimbledon-singles-as-djokovic-makes-bow)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:17:35+00:00

Andy Murray lost his race to be fit for the Wimbledon singles on Tuesday as Novak Djokovic prepared to launch his bid for a record-equalling eighth Wimbledon men's…

## Baseball: Tigers take down Carp in 10 innings
 - [https://japantoday.com/category/sports/baseball-tigers-take-down-carp-in-10-innings](https://japantoday.com/category/sports/baseball-tigers-take-down-carp-in-10-innings)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:17:05+00:00

Five pitchers combined on a five-hit 10-inning shutout as the Hanshin Tigers knocked off the Central League-leading Hiroshima Carp 3-0 on Tuesday.
The Tigers' Hiroto Saiki allowed a…

## Japan footballer Ito referred to prosecutors over sex assault claims
 - [https://japantoday.com/category/crime/japan-footballer-ito-referred-to-prosecutors-over-sex-assault-claims](https://japantoday.com/category/crime/japan-footballer-ito-referred-to-prosecutors-over-sex-assault-claims)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:13:40+00:00

Japan football player Junya Ito was referred to prosecutors Tuesday on suspicion of injuring two women through quasi-forcible sexual intercourse, sources close to the matter said, but it…

## Woman arrested for letting newborn baby die at home says she was pessimistic about future
 - [https://japantoday.com/category/crime/woman-arrested-for-letting-newborn-baby-die-at-home-says-she-was-pessimistic-about-future](https://japantoday.com/category/crime/woman-arrested-for-letting-newborn-baby-die-at-home-says-she-was-pessimistic-about-future)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:12:45+00:00

A 22-year-old unemployed woman who was arrested last month on suspicion of abandoning the body of her newborn baby daughter at her home in Ichikawa City, Chiba Prefecture,…

## Chinese woman honored for sacrificing life to save Japanese family
 - [https://japantoday.com/category/national/chinese-woman-honored-for-sacrificing-life-to-save-japanese-family](https://japantoday.com/category/national/chinese-woman-honored-for-sacrificing-life-to-save-japanese-family)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:10:48+00:00

The Chinese city of Suzhou near Shanghai honored Hu Youping with a &quot;righteous and courageous role model&quot; certificate Tuesday after she died saving a Japanese mother and her…

## Man sentenced to death over murder-robbery in southwestern Japan
 - [https://japantoday.com/category/crime/update2-man-sentenced-to-death-over-murder-robbery-in-southwestern-japan](https://japantoday.com/category/crime/update2-man-sentenced-to-death-over-murder-robbery-in-southwestern-japan)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:10:21+00:00

A 39-year-old man was sentenced to death Tuesday for murdering an elderly woman and her son and robbing them at her residence in Oita Prefecture, southwestern Japan, in…

## Japan welcomes Sri Lanka's debt restructuring efforts
 - [https://japantoday.com/category/politics/japan-welcomes-sri-lanka%27s-debt-restructuring-efforts](https://japantoday.com/category/politics/japan-welcomes-sri-lanka%27s-debt-restructuring-efforts)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T22:03:50+00:00

Foreign Minister Yoko Kamikawa on Tuesday praised Sri Lanka's recent efforts to address its economic crisis and debt restructuring, following the South Asian country's agreement with creditor nations,…

## England recalls Marler, Stuart for 1st rugby test against the All Blacks in New Zealand
 - [https://japantoday.com/category/sports/england-recalls-marler-stuart-for-1st-rugby-test-against-the-all-blacks-in-new-zealand](https://japantoday.com/category/sports/england-recalls-marler-stuart-for-1st-rugby-test-against-the-all-blacks-in-new-zealand)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T21:08:45+00:00

England has recalled props Joe Marler and Will Stuart in the only changes to its starting lineup for the first rugby test against New Zealand at Dunedin on…

## Olympic men's soccer offers underdogs hope of medals in Paris. US team back after 16-year absence
 - [https://japantoday.com/category/paris-2024-olympics/olympic-mens-soccer-offers-underdogs-hope-of-medals-in-paris.-us-team-back-after-16-year-absence](https://japantoday.com/category/paris-2024-olympics/olympic-mens-soccer-offers-underdogs-hope-of-medals-in-paris.-us-team-back-after-16-year-absence)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T21:05:24+00:00

Sure, it was fun to dream about a Paris Olympics in which Lionel Messi and Kylian Mbappé renew their rivalries after that epic World Cup final.
But men’s…

## Tear gas, stones and flames as Kenya protesters say 'Ruto must go!'
 - [https://japantoday.com/category/world/tear-gas-stones-and-flames-as-kenya-protesters-say-%27ruto-must-go%21%27](https://japantoday.com/category/world/tear-gas-stones-and-flames-as-kenya-protesters-say-%27ruto-must-go%21%27)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T12:51:37+00:00

Riot police fired tear gas grenades and charged at stone-throwing protesters in downtown Nairobi and across Kenya on Tuesday in the most widespread unrest since at least two…

## Hungary's Orban, in Kyiv, proposes ceasefire to speed up peace talks
 - [https://japantoday.com/category/world/hungary%27s-orban-in-kyiv-proposes-ceasefire-to-speed-up-peace-talks](https://japantoday.com/category/world/hungary%27s-orban-in-kyiv-proposes-ceasefire-to-speed-up-peace-talks)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T12:50:11+00:00

Hungarian Prime Minister Viktor Orban urged Ukrainian President Volodymyr Zelenskiy on Tuesday to consider a ceasefire to accelerate an end to the war with Russia and also said…

## France's moderate voters face extreme choices in run-off vote
 - [https://japantoday.com/category/world/france%27s-moderate-voters-face-extreme-choices-in-run-off-vote](https://japantoday.com/category/world/france%27s-moderate-voters-face-extreme-choices-in-run-off-vote)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T12:48:21+00:00

Denise Rollet says she faces no good options in France's run-off legislative vote in the coming days.
The 80-year-old former teacher from Crepy-en-Valois, a small, middle-class town northeast…

## 38-year-old man arrested over committing indecent acts on young boy
 - [https://japantoday.com/category/crime/38-year-old-man-arrested-on-suspicion-of-indecent-acts-on-young-boy](https://japantoday.com/category/crime/38-year-old-man-arrested-on-suspicion-of-indecent-acts-on-young-boy)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T06:46:41+00:00

Police in Muroran, Hokkaido, said Monday they have arrested a 38-year-old man on suspicion of committing indecent acts on a young boy without his consent at a child…

## Defense Ministry rolls out 1st policy to promote AI use
 - [https://japantoday.com/category/tech/japan-defense-ministry-rolls-out-1st-policy-to-promote-ai-use](https://japantoday.com/category/tech/japan-defense-ministry-rolls-out-1st-policy-to-promote-ai-use)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T06:45:00+00:00

The Japanese Defense Ministry rolled out Tuesday its first-ever basic policy to promote the use of artificial intelligence as it seeks to respond to changes in defense operations…

## Nikkei ends above 40,000 as yen falls to new 37-year low against dollar
 - [https://japantoday.com/category/business/nikkei-ends-above-40-000-as-yen-falls-to-new-37-yr-low-vs.-dollar](https://japantoday.com/category/business/nikkei-ends-above-40-000-as-yen-falls-to-new-37-yr-low-vs.-dollar)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T06:44:45+00:00

The Nikkei stock index closed above the 40,000 threshold for the first time in three months, as exporters were boosted by the weaker yen hitting a fresh 37-year…

## Japan's skateboarding youth turn street culture into Olympic gold
 - [https://japantoday.com/category/paris-2024-olympics/japan%27s-skateboarding-youth-turn-street-culture-into-olympic-gold](https://japantoday.com/category/paris-2024-olympics/japan%27s-skateboarding-youth-turn-street-culture-into-olympic-gold)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T06:44:18+00:00

Japan used to think skateboarding was a pastime for delinquents but the country has grown into a global powerhouse in the sport and is expected to dominate at…

## Authorities find 19 bodies piled in dump truck in cartel-dominated area of southern Mexico
 - [https://japantoday.com/category/world/authorities-find-19-bodies-piled-in-a-dump-truck-in-a-cartel-dominated-area-of-southern-mexico](https://japantoday.com/category/world/authorities-find-19-bodies-piled-in-a-dump-truck-in-a-cartel-dominated-area-of-southern-mexico)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T04:46:33+00:00

Authorities said Monday they have found 19 bodies piled in and around a dump truck in a cartel-dominated area of southern Mexico, near the border with Guatemala.
The…

## Australia gives internet firms 6 months to draft online child-safety rules
 - [https://japantoday.com/category/world/australia-gives-internet-firms-6-months-to-draft-online-child-safety-rules](https://japantoday.com/category/world/australia-gives-internet-firms-6-months-to-draft-online-child-safety-rules)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T03:04:20+00:00

Australia is giving the internet industry six months to come up with an enforceable code detailing how it will stop children seeing pornography and other inappropriate material online…

## New Zealand to press ahead with media content pay law
 - [https://japantoday.com/category/world/new-zealand-to-press-ahead-with-media-content-pay-law2](https://japantoday.com/category/world/new-zealand-to-press-ahead-with-media-content-pay-law2)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-07-02T03:03:29+00:00

New Zealand's conservative coalition government will proceed with a bill that would make it compulsory for digital technology platforms to pay media companies for news, it said on…

