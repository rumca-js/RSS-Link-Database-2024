# Source:Python Software Foundation News, URL:https://pyfound.blogspot.com/feeds/posts/default?alt=rss, language:en

## The 2024 PSF Board Election is Open!
 - [https://pyfound.blogspot.com/2024/07/the-2024-psf-board-election-is-open.html](https://pyfound.blogspot.com/2024/07/the-2024-psf-board-election-is-open.html)
 - RSS feed: https://pyfound.blogspot.com/feeds/posts/default?alt=rss
 - date published: 2024-07-02T14:05:00+00:00

<p>It’s time to cast your vote! Voting is open starting today Tuesday, July 2nd, through Friday, July 16th, 2024 2:00 pm UTC. Check the <a href="https://www.python.org/nominations/elections/">Elections page</a> to see how much time you have left to vote. <br /></p><h4 style="text-align: left;">How to Vote</h4><p>If you are a voting member of the PSF that affirmed your intention to participate in this year’s election, you will receive an email from “OpaVote Voting Link &lt;noreply@opavote.com&gt;” with a link to your ballot. The subject line will read “Python Software Foundation Board of Directors Election 2024”. If you haven’t seen your ballot by Wednesday, please check your spam folder for a message from “noreply@opavote.com”. If you don’t see anything get in touch by emailing psf-elections@python.org so we can look into your account and make sure we have the most up-to-date email for you.</p><p><br />Three seats on the board are open, but you can approve as many of the 19 candidates

