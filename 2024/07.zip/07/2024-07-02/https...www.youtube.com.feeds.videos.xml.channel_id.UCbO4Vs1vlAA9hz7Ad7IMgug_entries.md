# Source:Guerrilla Miniature Games, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug, language:en

## DEAD BY LEAD  by Alex C. Van Allen - Jailbreak!
 - [https://www.youtube.com/watch?v=kY8-9bt_Dr4](https://www.youtube.com/watch?v=kY8-9bt_Dr4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug
 - date published: 2024-07-02T12:00:48+00:00

I'm back to the Old West with Andrew Russ and some Dead by Lead! Grab your poncho, six shooter and your best horse and let's ride into the dusty town of Bloodstone for some classic shoot-em-up action. 

You can grab a copy digitally, in print or as a bundle HERE: https://www.drivethrurpg.com/product/442404/BLASTER-Vol-05-Dead-by-Lead?affiliate_id=210041

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.gg/CCmeRy3

Want to challenge Ash to a game? Email him at GuerrillaMiniatureGames@gmail.com or message him through his Facebook Page!

Follow Ash on Facebook: https://www.facebook.com/outofthebasementintothestreets

GMG Measuring Gauges and Tokens available HERE: http://deathraydesigns.com/product-category/accessories/guerrilla-miniature-games/

GMG T-Shirts and Hoodies HERE: https://shop.spreadshirt.ca/guerrillaminiaturegames/

Intro and Out

