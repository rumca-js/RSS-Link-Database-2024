# Source:DAILYSABAH - Turkey News, URL:https://www.dailysabah.com/rssFeed/10, language:en-US

## Türkiye and UAE collaborate on social services, child welfare
 - [https://www.dailysabah.com/turkiye/turkiye-and-uae-collaborate-on-social-services-child-welfare/news](https://www.dailysabah.com/turkiye/turkiye-and-uae-collaborate-on-social-services-child-welfare/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-02T13:24:00+00:00

Under the leadership of Türkiye's first lady Emine Erdoğan a memorandum of understanding (MoU) on cooperation in social services was signed between the Republic of Türkiye Min...

## Türkiye's summer Quran courses start with various activities
 - [https://www.dailysabah.com/turkiye/turkiyes-summer-quran-courses-start-with-various-activities/news](https://www.dailysabah.com/turkiye/turkiyes-summer-quran-courses-start-with-various-activities/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-02T11:56:00+00:00

Summer Quran courses have started across Türkiye, marking the beginning of religious education coupled with enriching activities for children during the school holidays. This year,...

## Escalator malfunction causes injuries in western Türkiye’s Izmir
 - [https://www.dailysabah.com/turkiye/escalator-malfunction-causes-injuries-in-western-turkiyes-izmir/news](https://www.dailysabah.com/turkiye/escalator-malfunction-causes-injuries-in-western-turkiyes-izmir/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-02T11:55:00+00:00

A malfunction caused an escalator at Uçyol Metro Station in Konak district, located in western Anatolia, Izmir, Türkiye, to suddenly cascade downward, leading to 11 people losing t...

## Warming waters jeopardize Black Sea's survival
 - [https://www.dailysabah.com/turkiye/warming-waters-jeopardize-black-seas-survival/news](https://www.dailysabah.com/turkiye/warming-waters-jeopardize-black-seas-survival/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-02T09:51:47+00:00

Geological engineer Osman Bektaş has issued a stark warning about the impact of global climate change on the Black Sea.

'The continuous warming of the Black Sea is due to the impa...

## Türkiye registers nearly 2.4M pets under microchip program
 - [https://www.dailysabah.com/turkiye/turkiye-registers-nearly-24m-pets-under-microchip-program/news](https://www.dailysabah.com/turkiye/turkiye-registers-nearly-24m-pets-under-microchip-program/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-02T09:28:59+00:00

According to the Ministry of Agriculture and Forestry, the number of registered pets in Türkiye, as part of the pet identification program conducted since 2021, has reached 2,371,7...

## Generation Z drives Türkiye’s coffee consumption growth
 - [https://www.dailysabah.com/turkiye/generation-z-drives-turkiyes-coffee-consumption-growth/news](https://www.dailysabah.com/turkiye/generation-z-drives-turkiyes-coffee-consumption-growth/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-07-02T08:26:52+00:00

Coffee consumption has been on the rise in Türkiye, becoming increasingly integral to daily rituals and social interactions. For the older generation, Turkish coffee remains popula...

