# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## This "From Scratch" Browser Will Take On The World
 - [https://www.youtube.com/watch?v=4vm_6mDEgL4](https://www.youtube.com/watch?v=4vm_6mDEgL4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2024-07-02T21:00:03+00:00

People have bugged me to talk about the Ladybird browser and the work of Andreas Kling for a very long time and this is as good a time as any, just a few days ago the Ladybird Browser Initiative with plans to develop this browser into something amazing. 

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Ladybird Website: https://ladybird.org/lets-go/index.html
Ladybird Browser Initiative Announcement: https://ladybird.org/lets-go/announcement.html
Shopify Sponsor: https://awesomekling.substack.com/p/welcoming-shopify-as-a-ladybird-sponsor

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson

