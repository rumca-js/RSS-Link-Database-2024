# Source:Grimdark Magazine, URL:https://www.grimdarkmagazine.com/feed, language:en-AU

## REVIEW: The Night Ends with Fire by K. X. Song
 - [https://www.grimdarkmagazine.com/review-the-night-ends-with-fire-by-k-x-song](https://www.grimdarkmagazine.com/review-the-night-ends-with-fire-by-k-x-song)
 - RSS feed: https://www.grimdarkmagazine.com/feed
 - date published: 2024-07-02T04:25:15+00:00

<p>In The Night Ends with Fire, K. X. Song’s dark adult fantasy debut, inspired by the legend of Mulan, Hai Meilin takes control of her destiny. In an attempt to escape her opium-ridden and abusive father, as well as the arranged marriage forced upon her with an equally abusive nobleman, she takes matters into her own hands and enlists for the war under the guise of her father’s ‘bastard son’. Upon enlisting, Meilin finds her stride. While keeping her secret is a source of constant anxiety, she flourishes without the restrictions previously forced upon her. She develops friendships and camaraderie amongst her platoon, a budding infatuation with her commander and training partner Prince Sky and later, a complicated bond with an enemy Prince. As the war of the Three Kingdoms edges closer, so do the voices in her head. Meilin is confronted by Qinglong, a sea dragon spirit connected to the jade necklace her late mother had left for her. Through dreams, visions and hallucinations, Qinglong

