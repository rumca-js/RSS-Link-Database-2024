# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## Is ‘cow flu’ here to stay? Three months after it emerged, fears are growing
 - [https://www.science.org/content/article/cow-flu-here-stay-three-months-after-it-emerged-fears-are-growing](https://www.science.org/content/article/cow-flu-here-stay-three-months-after-it-emerged-fears-are-growing)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-02T22:23:07.914252+00:00

Feeble U.S. government response and limited cooperation from the dairy industry have complicated elimination

## NSF’s bid to help more scientists in have-not states stirs controversy
 - [https://www.science.org/content/article/nsf-s-bid-help-more-scientists-have-not-states-stirs-controversy](https://www.science.org/content/article/nsf-s-bid-help-more-scientists-have-not-states-stirs-controversy)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-02T18:02:58.986601+00:00

Agency replaces large EPSCoR grants to statewide consortia with smaller awards to more institutions

## Chinese AI stirs panic at European geoscience society
 - [https://www.science.org/content/article/chinese-ai-stirs-panic-european-geoscience-society](https://www.science.org/content/article/chinese-ai-stirs-panic-european-geoscience-society)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-02T16:57:46.394871+00:00

Geology chatbot prompts complaint, firing of top European geoscientist

## Ants may be the only animal that performs surgical amputations
 - [https://www.science.org/content/article/ants-may-be-only-animal-performs-surgical-amputations](https://www.science.org/content/article/ants-may-be-only-animal-performs-surgical-amputations)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-07-02T16:57:42.872120+00:00

Surprising tactic may be way to prevent entire colony from being infected by bacteria

