# Source:G F Darwin, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCkPjHTuNd_ycm__29dXM3Nw, language:en-US

## Podziękowania Rafała za Ostatni Taniec Darwinów na YouTube!
 - [https://www.youtube.com/watch?v=YuaT-x8zJe8](https://www.youtube.com/watch?v=YuaT-x8zJe8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCkPjHTuNd_ycm__29dXM3Nw
 - date published: 2024-07-02T11:02:58+00:00



