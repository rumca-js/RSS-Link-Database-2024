# Source:New Zealand Herald, URL:https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp, language:en

## Prime Minister Christopher Luxon, Erica Stanford announce standardised testing for primary schools
 - [https://www.nzherald.co.nz/nz/politics/prime-minister-christopher-luxon-erica-stanford-set-to-make-education-announcement/EB6UG3HY25GIDGLXP7W2ADER5I](https://www.nzherald.co.nz/nz/politics/prime-minister-christopher-luxon-erica-stanford-set-to-make-education-announcement/EB6UG3HY25GIDGLXP7W2ADER5I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T23:30:00+00:00

The 'progress monitoring' checks will focus on reading, writing and maths.

## Massey murder: West Auckland man pleads not guilty to murder, keeps identity secret for now
 - [https://www.nzherald.co.nz/nz/crime/massey-murder-west-auckland-man-pleads-not-guilty-to-murder-keeps-identity-secret-for-now/IYYMHTZ6GFGK7EV26WWTCFRYFU](https://www.nzherald.co.nz/nz/crime/massey-murder-west-auckland-man-pleads-not-guilty-to-murder-keeps-identity-secret-for-now/IYYMHTZ6GFGK7EV26WWTCFRYFU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T22:37:16+00:00

The woman was found dead in a Chorley Ave home last month.

## June new vehicle sales the worst in a decade, possible relief on the way from Transport Minister Simeon Brown
 - [https://www.nzherald.co.nz/business/june-new-vehicle-sales-the-worst-in-a-decade-possible-relief-on-the-way-from-transport-minister-simeon-brown/O3DLWT24YJCL5LDCFRBQIX5QUI](https://www.nzherald.co.nz/business/june-new-vehicle-sales-the-worst-in-a-decade-possible-relief-on-the-way-from-transport-minister-simeon-brown/O3DLWT24YJCL5LDCFRBQIX5QUI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T22:11:41+00:00

Utes a rare strong point in sixth straight month of falling sales.

## Donald Trump’s sentencing in New York hush money case postponed until September
 - [https://www.nzherald.co.nz/world/donald-trumps-sentencing-in-new-york-hush-money-case-postponed-until-september/S2GJWDBIP5HT5GPAGTCZSDBALA](https://www.nzherald.co.nz/world/donald-trumps-sentencing-in-new-york-hush-money-case-postponed-until-september/S2GJWDBIP5HT5GPAGTCZSDBALA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T22:07:35+00:00

A divided Supreme Court ruled Donald Trump is immune from prosecution for official acts.

## Name supression lapses for Elizabeth Smith, accused of murdering Dean Fifield in West Auckland
 - [https://www.nzherald.co.nz/nz/crime/name-supression-lapses-for-elizabeth-smith-accused-of-murdering-dean-fifield-in-west-auckland/EYYXLM5AFBGO5GYUI6MUXHZ3QM](https://www.nzherald.co.nz/nz/crime/name-supression-lapses-for-elizabeth-smith-accused-of-murdering-dean-fifield-in-west-auckland/EYYXLM5AFBGO5GYUI6MUXHZ3QM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T21:48:58+00:00

She is accused of having used a car as a deadly weapon.

## Inside Economics: Could synthetic milk sink the dairy industry? Could Chinese economic woes get there it first?...and making the case for more optimism
 - [https://www.nzherald.co.nz/business/inside-economics-could-synthetic-milk-sink-the-dairy-industry-could-chinese-economic-woes-get-there-it-firstand-making-the-case-for-more-optmism/ZNEIDRU3GREH7BOFYEMIMUPWDY](https://www.nzherald.co.nz/business/inside-economics-could-synthetic-milk-sink-the-dairy-industry-could-chinese-economic-woes-get-there-it-firstand-making-the-case-for-more-optmism/ZNEIDRU3GREH7BOFYEMIMUPWDY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T21:00:00+00:00

Could fake milk ruin our economy, and what should we make of the latest tech 'hype cycle'?

## Auckland house sellers giving up rather than taking lower prices
 - [https://www.nzherald.co.nz/nz/auckland-house-sellers-giving-up-rather-than-taking-lower-prices/DZTUFOAOFBHSLHZLV5GFGRZO6Y](https://www.nzherald.co.nz/nz/auckland-house-sellers-giving-up-rather-than-taking-lower-prices/DZTUFOAOFBHSLHZLV5GFGRZO6Y)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T20:52:30+00:00

Homes are being withdrawn from sale after prices plummet.

## Students found after going missing in West Auckland bush
 - [https://www.nzherald.co.nz/nz/students-found-after-going-missing-in-west-auckland-bush/LOSXTGZOPBHXLAS3FTWGC3D3KA](https://www.nzherald.co.nz/nz/students-found-after-going-missing-in-west-auckland-bush/LOSXTGZOPBHXLAS3FTWGC3D3KA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T20:24:19+00:00

The teenagers were on a school tramping trip in heavy rain.

## Married At First Sight NZ: Mike Wilson’s new girlfriend slams show wife Kara Lester
 - [https://www.nzherald.co.nz/entertainment/married-at-first-sight-nz-mike-wilsons-new-girlfriend-slams-show-wife/F2MVVNUNHRH7ZLGJ4MS6J42SVA](https://www.nzherald.co.nz/entertainment/married-at-first-sight-nz-mike-wilsons-new-girlfriend-slams-show-wife/F2MVVNUNHRH7ZLGJ4MS6J42SVA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T20:23:39+00:00

MAFS NZ has wrapped, but the fallout is just beginning.

## Media Insider: Newshub closure – former MediaWorks chief executive Mark Weldon breaks silence; 6pm TV advertising battle heats up
 - [https://www.nzherald.co.nz/business/media-insider-newshub-closure-former-mediaworks-chief-executive-mark-weldon-breaks-silence-three-slashes-ad-rates/FDZ7ZSKT2RE5DKUXUAUJAYZCWQ](https://www.nzherald.co.nz/business/media-insider-newshub-closure-former-mediaworks-chief-executive-mark-weldon-breaks-silence-three-slashes-ad-rates/FDZ7ZSKT2RE5DKUXUAUJAYZCWQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:02:00+00:00

6pm ad battle heats up in Newshub's final days; Meta AI says Meta should pay for news.

## Plans for 100+ new Rotorua Kāinga Ora homes reassessed after review, 300+ still promised
 - [https://www.nzherald.co.nz/rotorua-daily-post/news/plans-for-100-new-rotorua-kainga-ora-homes-reassessed-after-review-300-still-promised/SJJYFGZZZVEX7ISL3ONGWXXRC4](https://www.nzherald.co.nz/rotorua-daily-post/news/plans-for-100-new-rotorua-kainga-ora-homes-reassessed-after-review-300-still-promised/SJJYFGZZZVEX7ISL3ONGWXXRC4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:02:00+00:00

'It had to slow up really, they couldn’t keep building at the same pace,' says a builder.

## All Blacks v England: Jordie Barrett on how Dunedin could suit ‘exciting’ England side
 - [https://www.nzherald.co.nz/sport/rugby/all-blacks/all-blacks-v-england-jordie-barrett-on-how-dunedin-could-suit-exciting-england-side/FAIZT43PRRGUPMUYWZSXZEB2GA](https://www.nzherald.co.nz/sport/rugby/all-blacks/all-blacks-v-england-jordie-barrett-on-how-dunedin-could-suit-exciting-england-side/FAIZT43PRRGUPMUYWZSXZEB2GA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:01:55+00:00

Jordie Barrett is wary the covered stadium could suit England’s style.

## An overall failure of care: Coroner slams child welfare agency after violent death of toddler
 - [https://www.nzherald.co.nz/nz/an-overall-failure-of-care-coroner-slams-child-welfare-agency-after-violent-death-of-toddler/H3VAHXYES5FCBMESZSAGG4WXWA](https://www.nzherald.co.nz/nz/an-overall-failure-of-care-coroner-slams-child-welfare-agency-after-violent-death-of-toddler/H3VAHXYES5FCBMESZSAGG4WXWA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:00:00+00:00

Coroner criticises child welfare agency for 'flawed' abuse response.

## Banking Ombudsman releases recordings of complainant’s ‘private’ phone conversations to Westpac
 - [https://www.nzherald.co.nz/nz/banking-ombudsman-releases-recordings-of-complainants-private-phone-conversations-to-westpac/ZESR3SKI7ZEH3EEOWFNV43ZRHE](https://www.nzherald.co.nz/nz/banking-ombudsman-releases-recordings-of-complainants-private-phone-conversations-to-westpac/ZESR3SKI7ZEH3EEOWFNV43ZRHE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:00:00+00:00

Westpac says it hasn't listened to the recordings and will hand them back in 'good faith'.

## Government ministers raise concerns about financial outlook and safety record at KiwiRail
 - [https://www.nzherald.co.nz/nz/ministers-raise-concerns-about-financial-outlook-and-safety-record-at-kiwirail/P423DFWV2RDDDHAHXHXJPMUXMY](https://www.nzherald.co.nz/nz/ministers-raise-concerns-about-financial-outlook-and-safety-record-at-kiwirail/P423DFWV2RDDDHAHXHXJPMUXMY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:00:00+00:00

Meanwhile, two more board members have resigned after chairman's early retirement.

## Netsafe welcomes ‘funding changes reversal’
 - [https://www.nzherald.co.nz/business/netsafe-welcomes-funding-changes-reversal/TZPYI3D6WNDM3C5ANC6QJ3KLCA](https://www.nzherald.co.nz/business/netsafe-welcomes-funding-changes-reversal/TZPYI3D6WNDM3C5ANC6QJ3KLCA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:00:00+00:00

Perceived DIA powergrab thwarted.

## Paula Ryan clothing manufacturer, outlet store in liquidation owing $1m-plus
 - [https://www.nzherald.co.nz/business/paula-ryan-clothing-manufacturer-outlet-store-in-liquidation-owing-1m/X3UJ4S342NGWBAVN3PAYU43A2Y](https://www.nzherald.co.nz/business/paula-ryan-clothing-manufacturer-outlet-store-in-liquidation-owing-1m/X3UJ4S342NGWBAVN3PAYU43A2Y)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:00:00+00:00

The company, which made the clothes and sold them at NorthWest, has gone under.

## The lessons NZ should take from the US and UK elections - Richard Prebble
 - [https://www.nzherald.co.nz/business/the-lessons-nz-should-take-from-the-us-and-uk-elections-richard-prebble/PCP4ZTIL2ZEWHKTRBNRSAXUXJM](https://www.nzherald.co.nz/business/the-lessons-nz-should-take-from-the-us-and-uk-elections-richard-prebble/PCP4ZTIL2ZEWHKTRBNRSAXUXJM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:00:00+00:00

OPINION: Recent TV debates held by the major parties in both countries have been decisive.

## Why Niwa was nervous about buying ‘large American ute’
 - [https://www.nzherald.co.nz/nz/politics/why-niwa-was-nervous-about-buying-large-american-ute/5ATDOEB6JVENHBCU4IUQZ52G7M](https://www.nzherald.co.nz/nz/politics/why-niwa-was-nervous-about-buying-large-american-ute/5ATDOEB6JVENHBCU4IUQZ52G7M)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T17:00:00+00:00

Officials considered having no branding on the controversial $170k utes.

## Green Party co-leader Marama Davidson to undergo surgery tomorrow after breast cancer diagnosis
 - [https://www.nzherald.co.nz/nz/green-party-co-leader-marama-davidson-to-undergo-surgery-tomorrow-after-breast-cancer-diagnosis/OSLG45KLBVH2ZEV2SQFO7ZTKCU](https://www.nzherald.co.nz/nz/green-party-co-leader-marama-davidson-to-undergo-surgery-tomorrow-after-breast-cancer-diagnosis/OSLG45KLBVH2ZEV2SQFO7ZTKCU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T11:02:32+00:00

“I’m trying my darndest to turn my focus completely to my whānau and whakapapa now."

## Ruapehu mountain climber Wednesday Davis’ death a freak accident, ski field chairman says
 - [https://www.nzherald.co.nz/nz/ruapehu-mountain-climber-wednesday-davis-death-a-freak-accident-ski-field-chairman-says/ZYVQ4P2ISJFADM4SEDAP6W6JI4](https://www.nzherald.co.nz/nz/ruapehu-mountain-climber-wednesday-davis-death-a-freak-accident-ski-field-chairman-says/ZYVQ4P2ISJFADM4SEDAP6W6JI4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T07:57:41+00:00

Wednesday Davis died on Saturday after falling while climbing Mt Ruapehu.

## Waves up to six metres possible as heavy swells strike Wairarapa Coast, Cook Strait ferries cancelled
 - [https://www.nzherald.co.nz/nz/waves-up-to-six-metres-possible-as-heavy-swells-strike-wairarapa-coast-cook-strait-ferries-cancelled/3VDAE2GK6BHJLFX3KDF4H7FKAA](https://www.nzherald.co.nz/nz/waves-up-to-six-metres-possible-as-heavy-swells-strike-wairarapa-coast-cook-strait-ferries-cancelled/3VDAE2GK6BHJLFX3KDF4H7FKAA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T07:10:55+00:00

Cook Strait ferries have been cancelled from tonight due to the swells.

## Elderly first-time traveller injured at airport after wheelchair no show, Air New Zealand apologises
 - [https://www.nzherald.co.nz/travel/elderly-first-time-traveller-injured-at-airport-after-wheelchair-no-show-air-new-zealand-apologises/KDBMMGFO4BG6BFSICUSQL77PDI](https://www.nzherald.co.nz/travel/elderly-first-time-traveller-injured-at-airport-after-wheelchair-no-show-air-new-zealand-apologises/KDBMMGFO4BG6BFSICUSQL77PDI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T06:00:00+00:00

'She arrived exhausted, in tears and pain from her injuries.'

## Ex-All Blacks assistant Andrew Strawbridge is the inside oil England could call on
 - [https://www.nzherald.co.nz/sport/rugby/all-blacks/ex-all-blacks-assistant-andrew-strawbridge-is-the-inside-oil-england-could-call-on/HNE7KWXTZJDWLOPLYQIQT77GZY](https://www.nzherald.co.nz/sport/rugby/all-blacks/ex-all-blacks-assistant-andrew-strawbridge-is-the-inside-oil-england-could-call-on/HNE7KWXTZJDWLOPLYQIQT77GZY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T05:54:22+00:00

England have snaffled a former All Blacks assistant with potential inside information.

## Taupō double fatal: Kim Blakeney-Williams’ medication ‘quadrupled’ two weeks before head-on smash
 - [https://www.nzherald.co.nz/nz/taupo-double-fatal-kim-blakeney-williams-medication-quadrupled-two-weeks-before-head-on-smash/Q5BSGH4K3JATBLK7KVGATSVGVM](https://www.nzherald.co.nz/nz/taupo-double-fatal-kim-blakeney-williams-medication-quadrupled-two-weeks-before-head-on-smash/Q5BSGH4K3JATBLK7KVGATSVGVM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T05:24:34+00:00

'I feel so robbed and heartbroken' victim's son tells the court.

## Foodstuffs South Island posts a loss: New software, higher wage bill and merger costs cited
 - [https://www.nzherald.co.nz/business/foodstuffs-south-island-posts-a-loss-new-software-higher-wage-bill-and-merger-costs-cited/SPOOABLVGVDYDG67GCGPRHJ5IE](https://www.nzherald.co.nz/business/foodstuffs-south-island-posts-a-loss-new-software-higher-wage-bill-and-merger-costs-cited/SPOOABLVGVDYDG67GCGPRHJ5IE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T04:51:39+00:00

Inflation bites grocery co-op Foodstuffs South Island.

## KiwiRail board directors Rachel Pinn and Ed Sims resign after chairman David McLean retires early
 - [https://www.nzherald.co.nz/nz/kiwirail-board-directors-rachel-pinn-and-ed-sims-resign-after-chairman-david-mclean-retires-early/J7CHZZAVNZFJDFQNEOTJO65C3U](https://www.nzherald.co.nz/nz/kiwirail-board-directors-rachel-pinn-and-ed-sims-resign-after-chairman-david-mclean-retires-early/J7CHZZAVNZFJDFQNEOTJO65C3U)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T04:43:12+00:00

Finance Minister Nicola Willis warned last week more board members could lose their jobs.

## Onepoto skipper James Thomson fined for Bay of Islands collision that destroyed historic ferry and injured captain
 - [https://www.nzherald.co.nz/northland-age/news/onepoto-skipper-james-thomson-fined-for-bay-of-islands-collision-that-destroyed-historic-ferry-and-injured-captain/7JD2KJEK4ZHPPFDPEBKKKDAWYQ](https://www.nzherald.co.nz/northland-age/news/onepoto-skipper-james-thomson-fined-for-bay-of-islands-collision-that-destroyed-historic-ferry-and-injured-captain/7JD2KJEK4ZHPPFDPEBKKKDAWYQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T04:01:17+00:00

'The message for other skippers is, it is your responsibility to stay alert.'

## Retailers protest against crime in Papatoetoe, want tougher punishment for young offenders
 - [https://www.nzherald.co.nz/nz/retailers-protest-against-crime-in-papatoetoe-want-tougher-punishment-for-young-offenders/3DG6HRCFGVCMFDI4KGUWIYIRWY](https://www.nzherald.co.nz/nz/retailers-protest-against-crime-in-papatoetoe-want-tougher-punishment-for-young-offenders/3DG6HRCFGVCMFDI4KGUWIYIRWY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T03:59:09+00:00

Protesters gather in Papatoetoe calling for tougher punishments for youth offenders.

## Auckland drive-by shootings: Councillors Filipaina and Newman say community is scared but becoming numb
 - [https://www.nzherald.co.nz/nz/auckland-drive-by-shootings-councillors-filipaina-and-newman-say-community-is-scared-but-becoming-numb/7J3KQNI7KRED3CAVFWHTVKR6UI](https://www.nzherald.co.nz/nz/auckland-drive-by-shootings-councillors-filipaina-and-newman-say-community-is-scared-but-becoming-numb/7J3KQNI7KRED3CAVFWHTVKR6UI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T03:56:14+00:00

The most recent incident happened last night when an Ōtara home was sprayed with bullets.

## NRL Vegas: Warriors confirmed to open 2025 season at Allegiant Stadium in Las Vegas
 - [https://www.nzherald.co.nz/sport/nrl-vegas-warriors-confirmed-to-open-2025-season-at-allegiant-stadium/NICCPAMDJVC4LN4TOOSO4LKM7Y](https://www.nzherald.co.nz/sport/nrl-vegas-warriors-confirmed-to-open-2025-season-at-allegiant-stadium/NICCPAMDJVC4LN4TOOSO4LKM7Y)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T02:27:27+00:00

The Auckland team will be part of the league extravaganza in the Nevada city next March.

## The best All Blacks XV since rugby went professional in 1996, according to Phil Gifford
 - [https://www.nzherald.co.nz/sport/rugby/all-blacks/the-best-all-blacks-xv-since-rugby-went-professional-in-1996-according-to-phil-gifford/7NM5E46T3ZEP7IMD2WIFXLCLRM](https://www.nzherald.co.nz/sport/rugby/all-blacks/the-best-all-blacks-xv-since-rugby-went-professional-in-1996-according-to-phil-gifford/7NM5E46T3ZEP7IMD2WIFXLCLRM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T01:02:19+00:00

These are the greatest All Blacks of the professional era, from the rugby field to fame.

## Thousands of Wellington buildings ‘at risk’ from rise in sea levels, including hospitals and schools
 - [https://www.nzherald.co.nz/nz/thousands-of-wellington-buildings-at-risk-from-rise-in-sea-levels-including-hospitals-and-schools/XF47AT7LSZHMFDNS5FQ7P6UVQQ](https://www.nzherald.co.nz/nz/thousands-of-wellington-buildings-at-risk-from-rise-in-sea-levels-including-hospitals-and-schools/XF47AT7LSZHMFDNS5FQ7P6UVQQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T00:56:49+00:00

Petone will feel the greatest impact with a stormwater system already under pressure.

## Sydney stabbing: Police have arrested a 14-year-old after University of Sydney stabbing, one in hospital
 - [https://www.nzherald.co.nz/world/sydney-stabbing-major-police-operation-at-university-of-sydney-one-in-hospital/SN7XCKQPW5FRVFLXS2Q2F5H53U](https://www.nzherald.co.nz/world/sydney-stabbing-major-police-operation-at-university-of-sydney-one-in-hospital/SN7XCKQPW5FRVFLXS2Q2F5H53U)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T00:34:49+00:00

NSW Police are yet to confirm the nature of the incident.

## Fatal Gordonton road rage crash: Innocent motorist killed was a much-loved family man
 - [https://www.nzherald.co.nz/waikato-news/news/fatal-gordonton-road-rage-crash-innocent-motorist-killed-was-a-much-loved-family-man/BKF7IY2XVVCB5G2HKCON5YKBYU](https://www.nzherald.co.nz/waikato-news/news/fatal-gordonton-road-rage-crash-innocent-motorist-killed-was-a-much-loved-family-man/BKF7IY2XVVCB5G2HKCON5YKBYU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T00:15:54+00:00

Jonathan 'Jono' Baker, 49, was a much-loved husband, father and stepdad.

## Newshub closure: As Three’s AM wraps up, breakfast TV veterans share words of wisdom
 - [https://www.nzherald.co.nz/entertainment/newshub-closure-as-threes-am-wraps-up-breakfast-tv-veterans-share-words-of-wisdom/C5SVYKC4KBE3TDKFEKEXOIN42A](https://www.nzherald.co.nz/entertainment/newshub-closure-as-threes-am-wraps-up-breakfast-tv-veterans-share-words-of-wisdom/C5SVYKC4KBE3TDKFEKEXOIN42A)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T00:09:11+00:00

'Did we expect everything to remain the same?'

## Waikato mum’s ‘appalling’ seven-year wait for answers from authorities about death of baby
 - [https://www.nzherald.co.nz/nz/waikato-mums-appalling-seven-year-wait-for-answers-from-authorities-about-death-of-baby/ID3URDVLUNBJTKUFOFGU7GM3EE](https://www.nzherald.co.nz/nz/waikato-mums-appalling-seven-year-wait-for-answers-from-authorities-about-death-of-baby/ID3URDVLUNBJTKUFOFGU7GM3EE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-07-02T00:00:00+00:00

Mum still waiting for authorities to make formal ruling on what caused Isabella’s death.

