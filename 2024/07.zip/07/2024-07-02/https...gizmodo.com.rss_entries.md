# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Boeing Would Like Everyone to Please Stop Saying the Starliner ISS Test Is a Bust
 - [https://gizmodo.com/boeing-would-like-everyone-to-please-stop-saying-the-st-1851572824](https://gizmodo.com/boeing-would-like-everyone-to-please-stop-saying-the-st-1851572824)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-07-02T20:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a9805264ca872852d232ff50247446ad.png" /><p>Boeing’s Starliner spacecraft has been docked to the International Space Station (ISS) for nearly a month, with NASA and its commercial partner repeatedly delaying the departure of the crew on board the capsule. Despite indefinitely postponing Starliner’s return flight, NASA and Boeing insist that the spacecraft is…</p><p><a href="https://gizmodo.com/boeing-would-like-everyone-to-please-stop-saying-the-st-1851572824">Read more...</a></p>

## One of Ryan Reynolds' Many Rejected Deadpool 3 Ideas Was an Indie Road Trip
 - [https://gizmodo.com/deadpool-and-wolverine-rejected-ideas-dopinder-mcu-fox-1851573255](https://gizmodo.com/deadpool-and-wolverine-rejected-ideas-dopinder-mcu-fox-1851573255)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-07-02T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/3323575fc9a054aaff7c097d4307960b.jpg" /><p>Before Deadpool 3 became <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/deadpool-and-wolverine-sabretooth-tyler-mane-marvel-mcu-1851566084">Deadpool & Wolverine</a>, we know that there were a lot of ideas rattling around Ryan Reynolds’ head <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/deadpool-wolverine-ryan-reynolds-18-story-ideas-mcu-1851455220">that got shot down</a>. Now we know at least a couple of them, we can start painting a picture of just how <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/deadpool-wolverine-pizza-digiorno-marvel-studios-film-1851570790">varied and wild</a> some of Reynolds’ pitches were.</p><p><a href="https://gizmodo.com/deadpool-and-wolverine-rejected-ideas-dopinder-mcu-fox-1851573255">Read more...</a></p>

## People in San Francisco Are Mad That a New App Lets You Spy on Bars to See How Busy They Are
 - [https://gizmodo.com/2nite-app-lets-you-spy-on-bars-to-see-how-busy-they-are-1851571595](https://gizmodo.com/2nite-app-lets-you-spy-on-bars-to-see-how-busy-they-are-1851571595)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-07-02T12:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/da9be211f1680b84035f5ff0fd8a4524.jpg" /><p>A weird new app lets San Francisco residents monitor local bars via live video feed to see what’s happening there and to check how busy the venues are. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.2nite.app/" rel="noopener noreferrer" target="_blank">2Nite</a>, which launched earlier this year, uses a network of cameras at various Bay Area establishments to provide remote insights into what’s happening at those…</p><p><a href="https://gizmodo.com/2nite-app-lets-you-spy-on-bars-to-see-how-busy-they-are-1851571595">Read more...</a></p>

