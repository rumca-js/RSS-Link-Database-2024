# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Kongresmen chce rezygnacji Bidena. Pierwszy przypadek u demokratów
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/kongresmen-chce-rezygnacji-bidena-pierwszy-przypadek-u-demokratow](https://www.polsatnews.pl/wiadomosc/2024-07-02/kongresmen-chce-rezygnacji-bidena-pierwszy-przypadek-u-demokratow)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T19:55:00+00:00

Lloyd Doggett to pierwszy kongresmen z obozu demokratów, który publicznie wezwał Joe Bidena do rezygnacji ze startu w wyborach. To pokłosie debaty prezydenckiej - w ocenie wielu komentatorów urzędujący prezydent przegrał starcie z Donaldem Trumpem.

## Dramatyczny finał uroczystości religijnej. Ponad 100 osób nie przeżyło
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/dramatyczny-final-uroczystosci-religijnej-ponad-100-osob-nie-przezylo](https://www.polsatnews.pl/wiadomosc/2024-07-02/dramatyczny-final-uroczystosci-religijnej-ponad-100-osob-nie-przezylo)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T19:30:00+00:00

Ponad 100 osób nie przeżyło po wybuchu paniki podczas uroczystości religijnej w stanie Uttar Pradesh w północnych Indiach. Świadkowie twierdzą, że z niewiadomych przyczyn ludzie zaczęli tratować się nawzajem. Sprawą zajmuje się lokalna policja.

## Kamala Harris może zastąpić Joe Bidena w wyścigu prezydenckim? "Jest gotowa"
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/kamala-harris-moze-zastapic-joe-bidena-w-wyscigu-prezydenckim-jest-gotowa](https://www.polsatnews.pl/wiadomosc/2024-07-02/kamala-harris-moze-zastapic-joe-bidena-w-wyscigu-prezydenckim-jest-gotowa)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T18:40:00+00:00

- Ona jest gotowa, by być prezydentem - powiedział o Kamali Harris Keith Williams, szef afroamerykańskich działaczy Demokratów w Michigan. Amerykańskie media podają, że to właśnie zastępczyni Joe Bidena może zostać kandydatką Demokratów, jeśli prezydent USA zdecyduje się ustąpić z wyścigu o Biały Dom.

## Orban złożył Zełenskiemu propozycję. Ukraińskie media oburzone
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/orban-zlozyl-zelenskiemu-propozycje-ukrainskie-media-oburzone](https://www.polsatnews.pl/wiadomosc/2024-07-02/orban-zlozyl-zelenskiemu-propozycje-ukrainskie-media-oburzone)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T16:51:00+00:00

Podczas negocjacji z Wołodymyrem Zełenskim Viktor Orban promował ideę natychmiastowego zawieszenia broni - wskazuje Ukraińska Prawda. Premier Węgier nie nalegał, ale media w Ukrainie podkreślają, że propozycja jest zgodna z koncepcjami pokojowymi Rosji.

## Igrzyska Olimpijskie 2024 w Paryżu. Ile medali mogą zdobyć Polacy?
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/zblizaja-sie-letnie-igrzyska-olimpijskie-2024-w-paryzu-pojawia-sie-zmiany-wzgledem-poprzednich](https://www.polsatnews.pl/wiadomosc/2024-07-02/zblizaja-sie-letnie-igrzyska-olimpijskie-2024-w-paryzu-pojawia-sie-zmiany-wzgledem-poprzednich)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T11:30:00+00:00

Wielkimi krokami zbliża się olimpiada we Francji - największe wydarzenie sportowe świata. Kiedy rozpoczną się Igrzyska Olimpijskie 2024 w Paryżu? Ile medali mogą zdobyć Polacy i jak impreza zmieni się w porównaniu do tej w Tokio?

## Donald Trump wysłał list do sędziego. Żąda uchylenia wyroku
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/donald-trump-wyslal-list-do-sedziego-zada-uchylenia-wyroku](https://www.polsatnews.pl/wiadomosc/2024-07-02/donald-trump-wyslal-list-do-sedziego-zada-uchylenia-wyroku)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T10:21:00+00:00

Prawnicy Donalda Trumpa zwrócili się o uchylenie wyroku skazującego w sprawie fałszowania oficjalnej dokumentacji. Jest to odpowiedź na decyzję Sądu Najwyższego, który orzekł, że byłemu prezydentowi przysługuje immunitet.

## Ronaldo zalany łzami. Na dramat patrzyła wzruszona matka
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/ronaldo-zalany-lzami-na-dramat-patrzyla-wzruszona-matka](https://www.polsatnews.pl/wiadomosc/2024-07-02/ronaldo-zalany-lzami-na-dramat-patrzyla-wzruszona-matka)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T08:28:00+00:00

Cristiano Ronaldo nie krył emocji po niewykorzystanym rzucie karnym w 105 minucie meczu Euro 2024 pomiędzy Portugalią a Słowenią. W trakcie przerwy w dogrywce portugalski napastnik rozpłakał się. Przez kilka chwil nie mógł zapanować nad swoimi emocjami, mimo pocieszeń ze strony kolegów z drużyny. Na wszystko patrzyła wzruszona matka Ronaldo.

## Viktor Orban z niespodziewaną wizytą w Kijowie. Spotka się z W. Zełenskim
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/victor-orban-z-niespodziewana-wizyta-w-kijowie-spotka-sie-z-w-zelenskim](https://www.polsatnews.pl/wiadomosc/2024-07-02/victor-orban-z-niespodziewana-wizyta-w-kijowie-spotka-sie-z-w-zelenskim)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T08:27:00+00:00

Viktor Orban niezapowiedzianie przybył do Kijowa, aby spotkać się z prezydentem Ukrainy Wołodymyrem Zełenskim. Jest to pierwsza wizyta premiera Węgier w Ukrainie od czasu ataku Rosji w 2022 roku. Spotkanie może wiązać się z emocjonującą wymianą zdań pomiędzy przywódcami, jaką zarejestrowały kamery podczas szczytu Rady Europejskiej.

## Pożary trawią Grecję. Dramat polskich turystów
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/pozary-trawia-grecje-dramat-polskich-turystow](https://www.polsatnews.pl/wiadomosc/2024-07-02/pozary-trawia-grecje-dramat-polskich-turystow)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T07:03:00+00:00

Grecję trawią pożary, które coraz trudniej opanować ze względu na wysoką temperaturę i silny wiatr. Tylko z wyspy Kos ewakuowano 14 tys. osób. Wśród nich są turyści z Polski. Media obiegają dramatyczne zdjęcia i nagrania.

## Silne turbulencje w trakcie lotu z Madrytu do Montevideo. Są ranni
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/silne-turbulencje-w-trakcie-lotu-do-montevideo-sa-ranni](https://www.polsatnews.pl/wiadomosc/2024-07-02/silne-turbulencje-w-trakcie-lotu-do-montevideo-sa-ranni)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T05:33:00+00:00

Siedem osób zostało rannych w wyniku silnych turbulencji do których doszło na pokładzie samolotu linii Air Europa. Piloci maszyny lecącej z Madrytu do Montevideo zdecydowali o awaryjnym lądowaniu w brazylijskim mieście Natal, gdzie poszkodowanym udzielono pomocy.

## Korea Północna testuje nowy pocisk. Może przenosić ogromne głowice
 - [https://www.polsatnews.pl/wiadomosc/2024-07-02/korea-polnocna-testuje-nowy-pocisk-moze-przenosic-ogromne-glowice](https://www.polsatnews.pl/wiadomosc/2024-07-02/korea-polnocna-testuje-nowy-pocisk-moze-przenosic-ogromne-glowice)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-07-02T05:23:00+00:00

Korea Północna przeprowadziła test nowego taktycznego pocisku balistycznego. Państwowa agencja informacyjna KCNA przekazała, że może on przenosić ogromne głowice bojowe. Wcześniej informacje na ten temat przekazało wojsko, nie podało jednak szczegółów. Według doniesień AP jedna z rakiet eksplodowała nad terytorium Korei Północnej.

