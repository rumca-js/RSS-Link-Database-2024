# Source:Reddit - News, URL:https://www.reddit.com/r/news/.rss, language:en-US

## FDA approves a second Alzheimer's drug that can modestly slow disease
 - [https://www.reddit.com/r/news/comments/1dtwyhi/fda_approves_a_second_alzheimers_drug_that_can](https://www.reddit.com/r/news/comments/1dtwyhi/fda_approves_a_second_alzheimers_drug_that_can)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T21:15:59+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/CrispyMiner"> /u/CrispyMiner </a> <br /> <span><a href="https://abcnews.go.com/Health/wireStory/fda-approves-alzheimers-drug-modestly-slow-disease-111619103">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtwyhi/fda_approves_a_second_alzheimers_drug_that_can/">[comments]</a></span>

## Grindr Fined $6 Million for Sharing Sensitive User Data
 - [https://www.reddit.com/r/news/comments/1dtvtok/grindr_fined_6_million_for_sharing_sensitive_user](https://www.reddit.com/r/news/comments/1dtvtok/grindr_fined_6_million_for_sharing_sensitive_user)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T20:26:53+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/josh252"> /u/josh252 </a> <br /> <span><a href="https://cyberinsider.com/grindr-fined-6-million-for-sharing-sensitive-user-data/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtvtok/grindr_fined_6_million_for_sharing_sensitive_user/">[comments]</a></span>

## Gov. Reynolds objects to U.S. Dept. of Labor investigations on Iowa businesses
 - [https://www.reddit.com/r/news/comments/1dtvd1w/gov_reynolds_objects_to_us_dept_of_labor](https://www.reddit.com/r/news/comments/1dtvd1w/gov_reynolds_objects_to_us_dept_of_labor)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T20:07:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/xmaddoggx"> /u/xmaddoggx </a> <br /> <span><a href="https://www.kcrg.com/2024/07/01/gov-reynolds-objects-us-dept-labor-investigations-iowa-businesses/?outputType=amp#amp_tf=From%20%251%24s&amp;aoh=17199449210541&amp;csi=0&amp;referrer=https%3A%2F%2Fwww.google.com">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtvd1w/gov_reynolds_objects_to_us_dept_of_labor/">[comments]</a></span>

## Venezuela will resume talks with US, President Maduro says
 - [https://www.reddit.com/r/news/comments/1dtu91k/venezuela_will_resume_talks_with_us_president](https://www.reddit.com/r/news/comments/1dtu91k/venezuela_will_resume_talks_with_us_president)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T19:21:16+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Alien_P3rsp3ktiv"> /u/Alien_P3rsp3ktiv </a> <br /> <span><a href="https://www.france24.com/en/americas/20240702-venezuela-will-resume-talks-with-us-president-maduro-says">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtu91k/venezuela_will_resume_talks_with_us_president/">[comments]</a></span>

## Judge delays Trump’s sentencing in hush money case to eye high court ruling on presidential immunity
 - [https://www.reddit.com/r/news/comments/1dtu3pp/judge_delays_trumps_sentencing_in_hush_money_case](https://www.reddit.com/r/news/comments/1dtu3pp/judge_delays_trumps_sentencing_in_hush_money_case)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T19:15:01+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/parachute_collection"> /u/parachute_collection </a> <br /> <span><a href="https://apnews.com/article/4d5f8ce399656abff72d7c114a04060d">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtu3pp/judge_delays_trumps_sentencing_in_hush_money_case/">[comments]</a></span>

## Court orders white nationalists to pay $2M more for Charlottesville Unite the Right violence
 - [https://www.reddit.com/r/news/comments/1dttg6t/court_orders_white_nationalists_to_pay_2m_more](https://www.reddit.com/r/news/comments/1dttg6t/court_orders_white_nationalists_to_pay_2m_more)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T18:47:55+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Miss-Figgy"> /u/Miss-Figgy </a> <br /> <span><a href="https://abcnews.go.com/US/wireStory/court-orders-white-nationalists-pay-2m-charlottesville-unite-111598851">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dttg6t/court_orders_white_nationalists_to_pay_2m_more/">[comments]</a></span>

## US pays Moderna $176m to develop bird-flu jab
 - [https://www.reddit.com/r/news/comments/1dtssh6/us_pays_moderna_176m_to_develop_birdflu_jab](https://www.reddit.com/r/news/comments/1dtssh6/us_pays_moderna_176m_to_develop_birdflu_jab)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T18:20:28+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AudibleNod"> /u/AudibleNod </a> <br /> <span><a href="https://www.bbc.com/news/articles/c51ywpxp43lo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtssh6/us_pays_moderna_176m_to_develop_birdflu_jab/">[comments]</a></span>

## Virginia school board member sentenced for role in Jan. 6 Capitol riot
 - [https://www.reddit.com/r/news/comments/1dts47f/virginia_school_board_member_sentenced_for_role](https://www.reddit.com/r/news/comments/1dts47f/virginia_school_board_member_sentenced_for_role)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T17:52:51+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/TeteDeMerde"> /u/TeteDeMerde </a> <br /> <span><a href="https://wtop.com/virginia/2024/07/va-school-board-member-sentenced-for-role-in-jan-6-capitol-riot/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dts47f/virginia_school_board_member_sentenced_for_role/">[comments]</a></span>

## The US will pay Moderna $176 million to develop an mRNA pandemic flu vaccine
 - [https://www.reddit.com/r/news/comments/1dtrbnk/the_us_will_pay_moderna_176_million_to_develop_an](https://www.reddit.com/r/news/comments/1dtrbnk/the_us_will_pay_moderna_176_million_to_develop_an)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T17:19:50+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/JRockPSU"> /u/JRockPSU </a> <br /> <span><a href="https://apnews.com/article/bird-flu-moderna-vaccine-mrna-pandemic-7f15d8d274a24d89fa86e2f57e13cbff">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtrbnk/the_us_will_pay_moderna_176_million_to_develop_an/">[comments]</a></span>

## American woman detained after stabbing death in Kaiserslautern
 - [https://www.reddit.com/r/news/comments/1dtpr7p/american_woman_detained_after_stabbing_death_in](https://www.reddit.com/r/news/comments/1dtpr7p/american_woman_detained_after_stabbing_death_in)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T16:15:46+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/jeetah"> /u/jeetah </a> <br /> <span><a href="https://www.stripes.com/theaters/europe/2024-07-02/kaiserslautern-train-station-stabbing-14365263.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtpr7p/american_woman_detained_after_stabbing_death_in/">[comments]</a></span>

## Giuliani disbarred in NY as court finds he repeatedly lied about Trump's 2020 election loss
 - [https://www.reddit.com/r/news/comments/1dtopxz/giuliani_disbarred_in_ny_as_court_finds_he](https://www.reddit.com/r/news/comments/1dtopxz/giuliani_disbarred_in_ny_as_court_finds_he)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T15:33:06+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/N8CCRG"> /u/N8CCRG </a> <br /> <span><a href="https://apnews.com/article/giuliani-new-york-disbarred-81b327f9ab1f98548cb888f8e652c9a8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtopxz/giuliani_disbarred_in_ny_as_court_finds_he/">[comments]</a></span>

## Severe turbulence injures over 30, diverts Air Europa flight to Brazil
 - [https://www.reddit.com/r/news/comments/1dtnax7/severe_turbulence_injures_over_30_diverts_air](https://www.reddit.com/r/news/comments/1dtnax7/severe_turbulence_injures_over_30_diverts_air)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T14:33:05+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/nature_half-marathon"> /u/nature_half-marathon </a> <br /> <span><a href="https://www.washingtonpost.com/world/2024/07/02/air-europa-turbulence-brazil/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtnax7/severe_turbulence_injures_over_30_diverts_air/">[comments]</a></span>

## Judge orders surprise release of Epstein transcripts
 - [https://www.reddit.com/r/news/comments/1dtn9d4/judge_orders_surprise_release_of_epstein](https://www.reddit.com/r/news/comments/1dtn9d4/judge_orders_surprise_release_of_epstein)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T14:31:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AudibleNod"> /u/AudibleNod </a> <br /> <span><a href="https://www.bbc.com/news/articles/cpwdvw8xqyvo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtn9d4/judge_orders_surprise_release_of_epstein/">[comments]</a></span>

## Groom shot in the head by masked gunman during backyard St. Louis wedding
 - [https://www.reddit.com/r/news/comments/1dtln5k/groom_shot_in_the_head_by_masked_gunman_during](https://www.reddit.com/r/news/comments/1dtln5k/groom_shot_in_the_head_by_masked_gunman_during)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T13:18:29+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/boxofstuff"> /u/boxofstuff </a> <br /> <span><a href="https://apnews.com/article/wedding-groom-shot-robbery-st-louis-251e7a53181a2a40d79844d22f2a3e74">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtln5k/groom_shot_in_the_head_by_masked_gunman_during/">[comments]</a></span>

## Sydney: Boy, 14, dressed in military clothing stabs university student in the neck
 - [https://www.reddit.com/r/news/comments/1dtjyfl/sydney_boy_14_dressed_in_military_clothing_stabs](https://www.reddit.com/r/news/comments/1dtjyfl/sydney_boy_14_dressed_in_military_clothing_stabs)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T11:53:05+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/PotatoMaster42p"> /u/PotatoMaster42p </a> <br /> <span><a href="https://news.sky.com/story/sydney-boy-14-dressed-in-military-clothing-stabs-university-student-in-the-neck-13162254">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtjyfl/sydney_boy_14_dressed_in_military_clothing_stabs/">[comments]</a></span>

## At least 27 dead in stampede during religious gathering in northern India
 - [https://www.reddit.com/r/news/comments/1dtjioq/at_least_27_dead_in_stampede_during_religious](https://www.reddit.com/r/news/comments/1dtjioq/at_least_27_dead_in_stampede_during_religious)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T11:28:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/PotatoMaster42p"> /u/PotatoMaster42p </a> <br /> <span><a href="https://www.aljazeera.com/news/2024/7/2/at-least-27-dead-in-stampede-during-religious-gathering-in-northern-india">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtjioq/at_least_27_dead_in_stampede_during_religious/">[comments]</a></span>

## Beryl is Barreling into Barbados
 - [https://www.reddit.com/r/news/comments/1dtbu55/beryl_is_barreling_into_barbados](https://www.reddit.com/r/news/comments/1dtbu55/beryl_is_barreling_into_barbados)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T03:11:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/delmsi"> /u/delmsi </a> <br /> <span><a href="https://www.cnn.com/2024/07/01/weather/hurricane-beryl-caribbean-landfall-monday?cid=ios_app">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtbu55/beryl_is_barreling_into_barbados/">[comments]</a></span>

## Hurricane Beryl strengthens into a category 5 storm, earliest on record
 - [https://www.reddit.com/r/news/comments/1dtbn8j/hurricane_beryl_strengthens_into_a_category_5](https://www.reddit.com/r/news/comments/1dtbn8j/hurricane_beryl_strengthens_into_a_category_5)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T03:01:09+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/thelastlib"> /u/thelastlib </a> <br /> <span><a href="https://www.clickorlando.com/weather/2024/07/02/hurricane-beryl-strengthens-into-a-category-5-storm-earliest-on-record/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtbn8j/hurricane_beryl_strengthens_into_a_category_5/">[comments]</a></span>

## Melbourne airport staff accused of smuggling drugs for organised crime cartels
 - [https://www.reddit.com/r/news/comments/1dtavmt/melbourne_airport_staff_accused_of_smuggling](https://www.reddit.com/r/news/comments/1dtavmt/melbourne_airport_staff_accused_of_smuggling)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T02:20:59+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/PotatoMaster42p"> /u/PotatoMaster42p </a> <br /> <span><a href="https://www.theguardian.com/australia-news/article/2024/jul/01/melbourne-airport-staff-accused-drug-smuggling-cartels-ntwnfb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtavmt/melbourne_airport_staff_accused_of_smuggling/">[comments]</a></span>

## Federal judge halts Mississippi law requiring age verification for websites
 - [https://www.reddit.com/r/news/comments/1dtaev3/federal_judge_halts_mississippi_law_requiring_age](https://www.reddit.com/r/news/comments/1dtaev3/federal_judge_halts_mississippi_law_requiring_age)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T01:57:57+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Stank_Dukem"> /u/Stank_Dukem </a> <br /> <span><a href="https://apnews.com/article/mississippi-social-media-lawsuit-age-verification-6332003bf2431bb848166ba2b9b290cd">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dtaev3/federal_judge_halts_mississippi_law_requiring_age/">[comments]</a></span>

## Stingray that got pregnant despite no male companion has died, aquarium says
 - [https://www.reddit.com/r/news/comments/1dta2hp/stingray_that_got_pregnant_despite_no_male](https://www.reddit.com/r/news/comments/1dta2hp/stingray_that_got_pregnant_despite_no_male)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-07-02T01:40:46+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/WhileFalseRepeat"> /u/WhileFalseRepeat </a> <br /> <span><a href="https://apnews.com/article/stingray-pregnant-dead-charlotte-aquarium-a1f937173c816eb25ad98e04037148ca">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1dta2hp/stingray_that_got_pregnant_despite_no_male/">[comments]</a></span>

