# Source:Prime Video, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQJWtTnAHhEG5w4uN0udnUQ, language:en

## Add an eye roll as a treat. | My Lady Jane
 - [https://www.youtube.com/watch?v=k5LWOkBtXYQ](https://www.youtube.com/watch?v=k5LWOkBtXYQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQJWtTnAHhEG5w4uN0udnUQ
 - date published: 2024-07-02T22:00:33+00:00

My Lady Jane is streaming now.
 
About My Lady Jane: Are you ready for an epic tale of true love, high adventure, regicidal maniacs, deadpan heroism, devious intrigues, swashbuckling swordfights, a soupçon of magical realism and oodles of yearning, banter and undeniable chemistry? Of course you are. Welcome to My Lady Jane.
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.
 
#MyLadyJane #PrimeVideo #Shorts

## No better place for a grand finale. | Federer: Twelve Final Days
 - [https://www.youtube.com/watch?v=4OJ4iDvlxqI](https://www.youtube.com/watch?v=4OJ4iDvlxqI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQJWtTnAHhEG5w4uN0udnUQ
 - date published: 2024-07-02T20:00:01+00:00

Federer: Twelve Final Days is out now.

About Federer: Twelve Final Days: Originally a home video never intended for public viewing, this film captures the final chapter in Roger Federer's legendary tennis career, featuring Roger, his family, and his three main rivals: Rafael Nadal, Novak Djokovic, and Andy Murray.
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.
 
#PrimeVideo #Tennis #Federer

## A little taste of history | My Lady Jane
 - [https://www.youtube.com/watch?v=T-bTUOeFUNw](https://www.youtube.com/watch?v=T-bTUOeFUNw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQJWtTnAHhEG5w4uN0udnUQ
 - date published: 2024-07-02T19:00:13+00:00

Emily Bader, Edward Bluemel and more star in My Lady Jane. 
My Lady Jane hits Prime Video June 27.

About My Lady Jane: Are you ready for an epic tale of true love, high adventure, regicidal maniacs, deadpan heroism, devious intrigues, swashbuckling swordfights, a soupçon of magical realism and oodles of yearning, banter and undeniable chemistry? Of course you are. Welcome to My Lady Jane.
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.
 
#PrimeVideo #Shorts #MyLadyJane

## The Cast Blind Taste Tests British vs. American Food | My Lady Jane | Prime Video
 - [https://www.youtube.com/watch?v=JOSI0jQctBE](https://www.youtube.com/watch?v=JOSI0jQctBE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQJWtTnAHhEG5w4uN0udnUQ
 - date published: 2024-07-02T18:00:12+00:00

The cast of My Lady Jane gets blindfolded and tastes some Tudor period food and some American treats in a little game we like to call "Tudor Tastings".

Emily Bader, Edward Bluemel, and more star in My Lady Jane. 
My Lady Jane hits Prime Video June 27.
 
» Watch My Lady Jane on Prime Video: https://amzn.to/3XJvtuG
» SUBSCRIBE: http://bit.ly/PrimeVideoSubscribe
 
About My Lady Jane: Are you ready for an epic tale of true love, high adventure, regicidal maniacs, deadpan heroism, devious intrigues, swashbuckling swordfights, a soupçon of magical realism and oodles of yearning, banter and undeniable chemistry? Of course you are. Welcome to My Lady Jane.
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invinci

## New to Prime Video July 2024 | Prime Video
 - [https://www.youtube.com/watch?v=6EytVNe4-xs](https://www.youtube.com/watch?v=6EytVNe4-xs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQJWtTnAHhEG5w4uN0udnUQ
 - date published: 2024-07-02T17:00:04+00:00

Check out all the new releases hitting Prime Video this July!

» SUBSCRIBE: http://bit.ly/PrimeVideoSubscribe
 
00:00 Intro
0:10 Sausage Party: Foodtopia
0:35 The Beekeeper
1:04 Space Cadet
1:34 Sam Morril: You've Changed
2:01 Tyler Perry's Divorce In The Black
2:40 My Spy The Eternal City
3:18 Betty La Fea: The Story Continues
4:07 Perfect Addiction
4:43 Lisa Frankenstein

About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.
 
Get More Prime Video: 
Stream Now: http://bit.ly/WatchMorePrimeVideo
Facebook: http://bit.ly/PrimeVideoFB
X: http://bit.ly/PrimeVideoTW
Instagram: http://bit.ly/primevideoIG
 
New to Prime Video July 2024 | Prime Video


## Sam Morril: You've Changed - Official Trailer | Prime Video
 - [https://www.youtube.com/watch?v=Ee1At3XMKUk](https://www.youtube.com/watch?v=Ee1At3XMKUk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQJWtTnAHhEG5w4uN0udnUQ
 - date published: 2024-07-02T16:00:20+00:00

You won’t regret this. Sam Morril: You’ve Changed premieres July 9.
 
» SUBSCRIBE: http://bit.ly/PrimeVideoSubscribe

About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.
 
Get More Prime Video: 
Stream Now: http://bit.ly/WatchMorePrimeVideo
Facebook: http://bit.ly/PrimeVideoFB
X: http://bit.ly/PrimeVideoTW
Instagram: http://bit.ly/primevideoIG
 
Sam Morril: You've Changed - Official Trailer | Prime Video
https://youtu.be/Ee1At3XMKUk
 
Prime Video
https://www.youtube.com/PrimeVideo

#OfficialTrailer #PrimeVideo

## Jackpot! - Official Trailer | Prime Video
 - [https://www.youtube.com/watch?v=IW7pIYtpp50](https://www.youtube.com/watch?v=IW7pIYtpp50)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQJWtTnAHhEG5w4uN0udnUQ
 - date published: 2024-07-02T14:00:05+00:00

You can’t win if you don’t play. Starring Awkwafina, John Cena and directed by Paul Feig, Jackpot! arrives August 15.

In the near future, a ‘Grand Lottery’ has been newly established in California - the catch: kill the winner before sundown to legally claim their multi-billion dollar jackpot. When Katie Kim (Awkwafina) moves to Los Angeles, she mistakenly finds herself with the winning ticket. Desperate to survive the hordes of jackpot hunters, she reluctantly joins forces with amateur lottery protection agent Noel Cassidy (John Cena) who will do everything in his power to get her to sundown in exchange for a piece of her prize. However, Noel must face off with his slick rival Louis Lewis (Simu Liu), who also seeks to collect Katie’s commission at all costs. JACKPOT! is directed by Paul Feig and written by Rob Yescombe.

https://www.exploregeorgia.org/

» SUBSCRIBE: http://bit.ly/PrimeVideoSubscribe
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, l

