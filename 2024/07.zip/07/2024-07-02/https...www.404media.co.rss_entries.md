# Source:404 Media, URL:https://www.404media.co/rss, language:en

## Figma Disables AI App Design Tool After It Copied Apple’s Weather App
 - [https://www.404media.co/figma-disables-ai-app-design-tool-after-it-copied-apples-weather-app](https://www.404media.co/figma-disables-ai-app-design-tool-after-it-copied-apples-weather-app)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-07-02T14:06:40+00:00

<!--kg-card-begin: html-->
<div class="outpost-pub-container"></div>
<!--kg-card-end: html-->
<p>The design tool Figma has disabled a newly launched AI-powered app design tool after a user showed that it was clearly copying Apple&#x2019;s weather app.&#xa0;</p><p>Figma disabled the feature, named Make Design, after CEO and cofounder of Not Boring Software Andy Allen tweeted images showing that asking</p>

## Fiverr Freelancers Offer to Dox Anyone With Powerful U.S. Data Tool
 - [https://www.404media.co/fiverr-freelancers-offer-to-dox-anyone-with-powerful-u-s-data-tool-tloxp](https://www.404media.co/fiverr-freelancers-offer-to-dox-anyone-with-powerful-u-s-data-tool-tloxp)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-07-02T13:00:22+00:00

Dozens of Fiverr sellers are advertising access to TLOxp, a potent data surveillance tool sold by credit bureau TransUnion.

