# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Polacy im starsi, tym bardziej skorzy do pracy? Nowe badanie
 - [https://www.wirtualnemedia.pl/artykul/polacy-im-starsi-tym-bardziej-skorzy-do-pracy-nowe-badanie](https://www.wirtualnemedia.pl/artykul/polacy-im-starsi-tym-bardziej-skorzy-do-pracy-nowe-badanie)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-07-02T18:18:14.437075+00:00

Z wiekiem spada poparcie Polaków dla 4-dniowego tygodnia pracy, chociaż to Zetki najbardziej obawiają się, że spowoduje on spadek wynagrodzeń – wynika z badania ClickMeeting. Polacy, niezależnie od wieku, woleliby pracować 4 dni w tygodniu po 8 godzin niż przez 5 dni po 6,4 godziny.

## Giełdowy sukces lidera Konfederacji. Akcje mocno drożeją w debiucie
 - [https://www.wirtualnemedia.pl/artykul/slawomir-mentzen-ile-zarabia-spolka-kanaelaria-prawna-cena-akcji-kurs](https://www.wirtualnemedia.pl/artykul/slawomir-mentzen-ile-zarabia-spolka-kanaelaria-prawna-cena-akcji-kurs)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-07-02T11:47:55.696782+00:00

We wtorek kancelaria prawna Mentzen, należąca do fundacji rodzinnej Sławomira Mentzena - jednego z liderów Konfederacji, zadebiutowała na warszawskiej giełdzie. Akcje spółki drożały nawet o ponad 25 proc.

