# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Sebastian Junger's Near Death Experience After an Aneurysm
 - [https://www.youtube.com/watch?v=Jpsr1uAQ3iA](https://www.youtube.com/watch?v=Jpsr1uAQ3iA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2024-07-02T17:00:11+00:00

JRE #2172 w/Sebastian Junger
YouTube: https://youtu.be/nrOaFxNex7U
JRE on Spotify: https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk

