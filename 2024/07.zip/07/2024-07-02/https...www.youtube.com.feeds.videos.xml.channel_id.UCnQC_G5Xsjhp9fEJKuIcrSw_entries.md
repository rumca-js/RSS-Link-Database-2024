# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Taraji P. Henson LOSES IT at BET Awards
 - [https://www.youtube.com/watch?v=NqQjWubK9b0](https://www.youtube.com/watch?v=NqQjWubK9b0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-07-02T21:00:12+00:00

Birch Gold - Make a qualifying purchase by July 31st and get a GOLDEN Truth Bomb! Text "BEN" to 989898, or go to https://birchgold.com/BEN

Taraji P. Henson went on some tirade about homelessness being illegal during the BET Awards. The people in the background look like they're not even paying attention.

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1996 - https://youtu.be/OJYsGFV7eB4

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #Taraji #TarajiPHenson #TarajiHenson #KamalaHarris #BlackEntertainers #BET #BETAwards #BETAwards2024 #React #Reaction

## There are nine jump cuts in 38 seconds!
 - [https://www.youtube.com/watch?v=dYDq7sRGmJ8](https://www.youtube.com/watch?v=dYDq7sRGmJ8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-07-02T19:00:19+00:00



## Wait, Can Donald Trump DRONE His Political Enemies Now?!
 - [https://www.youtube.com/watch?v=OJYsGFV7eB4](https://www.youtube.com/watch?v=OJYsGFV7eB4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-07-02T17:00:06+00:00

The Supreme Court makes a decision about presidential immunity–and the Left goes predictably insane; Democrats continue to suffer from heartburn over Joe Biden’s dementia; and the French decide whether to go right or left.

Ep.1996

- - -

1️⃣ Click here to join the member-exclusive portion of my show: https://bit.ly/3WDjgHE

2️⃣ Buy one year of DailyWire+ and get a second year FREE! Join here: https://bit.ly/3L1kc1o

3️⃣ Get 10% off your tickets to Sound of Hope: The Story of Possum Trot at http://angel.com/BEN

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴 Today's Sponsors 🔴

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/BEN

Birch Gold - Make a qualifying purchase by July 31st and get a GOLDEN Truth Bomb! Text "BEN" to 989898, or go to https://birchgold.com/BEN

Byrna - Get 10% off your purchase at https://byrna.com/BEN

Grand Canyon University - Find your purpose at Grand Canyon University: https://www.gcu.edu/

ZipRecruiter - Try ZipRecruiter

## These are all going to wind up in the garbage can
 - [https://www.youtube.com/watch?v=Lo4DpvqDtIc](https://www.youtube.com/watch?v=Lo4DpvqDtIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-07-02T15:00:17+00:00



## This is line is going down in presidential debate history
 - [https://www.youtube.com/watch?v=nwWouMwmaek](https://www.youtube.com/watch?v=nwWouMwmaek)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-07-02T01:00:18+00:00



