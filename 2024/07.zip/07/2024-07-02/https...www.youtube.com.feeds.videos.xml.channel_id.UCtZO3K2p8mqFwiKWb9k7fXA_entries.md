# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## Apple's secret weapon for making Siri smart
 - [https://www.youtube.com/watch?v=Rc41Y2oHZgo](https://www.youtube.com/watch?v=Rc41Y2oHZgo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2024-07-02T11:48:08+00:00

Get 60% off an annual Incogni plan here (sponsored): https://incogni.com/techaltar

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► This video ◄◄◄  

Siri today is pretty dumb. Apple Intelligence and generative AI is supposed to change that, but even more important is Apple's plan to supercharge it using App Intents. This is a framework for exposing 3rd party apps to Siri. Will it work?

This video on Nebula: https://nebula.tv/videos/techaltar-apples-secret-weapon-for-making-siri-smart

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► TechAltar links ◄◄◄  

Patreon:  
https://patreon.com/TechAltar

Social media:  
https://mas.to/@techaltar
https://bsky.app/profile/techaltar.bsky.social
https://instagram.com/TechAltar 
https://discord.gg/npKQebe  

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Attributions & Sources ◄◄◄  

Channel Music by Edemski: https://soundcloud.com/edemski
Other music by Epidemic Sound: http://nebula.tv/epidemic
Stock images from Getty & AP Archive

