# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #2172 - Sebastian Junger
 - [https://www.youtube.com/watch?v=LmRrJUHvk-M](https://www.youtube.com/watch?v=LmRrJUHvk-M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2024-07-02T17:00:10+00:00

Sebastian Junger is a bestselling author, journalist, and an Academy Award-nominated documentary filmmaker. His latest book, "In My Time of Dying", is available now.

www.sebastianjunger.com

