# Source:Techlore, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg, language:en-US

## Privacy-Friendly Security Cameras...Synology Did It!
 - [https://www.youtube.com/watch?v=a05my9OegME](https://www.youtube.com/watch?v=a05my9OegME)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg
 - date published: 2024-07-02T22:24:02+00:00

Synology just held their event in Taiwan for 2024 releasing E2EE security cameras without a required subscription, Active Protect for enterprise customers, AI features, and more! Thanks to Synology for flying us out, and thanks you all for watching—leave thoughts below!

Full Interview: Coming Soon
Techlore Talks on Event: Coming Soon

00:00 Introduction
01:02 Synology Security Cameras!
04:18 Active Protect Backup for Enterprise
06:54 Synology AI features
10:10 Summary, Opinions, and Final Words!

🔐 Techlore Homepage: https://techlore.tech
🕵 Go Incognito Course: https://techlore.tech/goincognito
💻 Techlore Community: https://discuss.techlore.tech
🏫 Techlore Coaching: https://techlore.tech/coaching
💬 Signal Group: https://discuss.techlore.tech/t/signal-usernames-are-here-join-our-signal-group-techlore/7640

We cannot provide our content without our Patrons, huge thanks to:
BRIGHTSIDE, Clark, Ente, Larry, Afonso, Boori, Brad, Casper, Cookie, Floyd, JohnnyO, kevin, love your content, Not

