# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## Do Yourself A Favor And Go Watch The Best Speedrunning Event Of The Year
 - [https://kotaku.com/sgdq-2024-summer-games-done-quick-schedule-1851573798](https://kotaku.com/sgdq-2024-summer-games-done-quick-schedule-1851573798)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T20:50:00+00:00

<video loop="" poster="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e466ac24ff48d144b074da66b169c1a8.jpg"><source src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e466ac24ff48d144b074da66b169c1a8.mp4" type="video/mp4" /></video><p>It’s the first week of July, a liminal period between the not-E3 marketing machine festivities and a surprisingly stacked summer release schedule. As Americans prepare to celebrate another glorious Independence Day in the wake of unhinged Supreme Court decisions and a sunsetting president, I can’t imagine a better…</p><p><a href="https://kotaku.com/sgdq-2024-summer-games-done-quick-schedule-1851573798">Read more...</a></p>

## I’m Begging Final Fantasy 14 Players To Just Read The Dialogue In Dawntrail
 - [https://kotaku.com/final-fantasy-14-dawntrail-players-need-to-read-a-book-1851573545](https://kotaku.com/final-fantasy-14-dawntrail-players-need-to-read-a-book-1851573545)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/2535f786fb4aea9c51067a4d845be727.jpg" /><p>According to some players, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/final-fantasy-14-ff14-free-trial-starter-edition-best-1851570741">Final Fantasy 14</a>’s new <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/final-fantasy-14-dawntrail-steam-reviews-1851570344">Dawntrail</a> expansion has a story problem. It’s boring, plot points aren’t explained properly, and it is by and large unimportant, or so go the criticisms. Of course, what those complaints don’t tell you is that a lot of the people behind them are also skipping through…</p><p><a href="https://kotaku.com/final-fantasy-14-dawntrail-players-need-to-read-a-book-1851573545">Read more...</a></p>

## Popular YouTube Rapper And Famous TikTok Wizard Get Into Viral Barking Match
 - [https://kotaku.com/ishowspeed-crawley-tiktok-wizard-bark-off-twitch-clip-1851573475](https://kotaku.com/ishowspeed-crawley-tiktok-wizard-bark-off-twitch-clip-1851573475)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T19:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/c0a38cfb4e306bfe6090803e2963f3dd.jpg" /><p>YouTuber and rapper Darren Jason Watkins Jr, better known online as IShowSpeed or simply “Speed,” encountered Crawley, a viral TikTok wizard, and promptly fell to the ground and got into <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://x.com/Dexerto/status/1808166511439155572" rel="noopener noreferrer" target="_blank">an extended barking match</a> with him in a clip that is going viral online.<br /></p><p><a href="https://kotaku.com/ishowspeed-crawley-tiktok-wizard-bark-off-twitch-clip-1851573475">Read more...</a></p>

## My Elden Ring: Shadow Of The Erdtree Player Summons, Ranked
 - [https://kotaku.com/elden-ring-shadow-of-the-erdtree-summons-multiplayer-1851573539](https://kotaku.com/elden-ring-shadow-of-the-erdtree-summons-multiplayer-1851573539)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T19:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/db87ee9e48c037f6c3ad1d56029dd1ef.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/elden-ring-shadow-of-the-erdtree-s-story-explained-1851566799">Elden Ring: Shadow of the Erdtree</a> is <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/elden-ring-shadow-erdtree-difficulty-vigor-dying-1851553144">really hard</a>, guys. Famed boss beater Let Me Solo Her (who <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/elden-ring-let-me-solo-her-him-messmer-shadow-erdtree-1851563743">recently rebranded as Let Me Solo Him</a> to fight the expansion’s tough boss, Messmer) struggled with FromSoftware’s DLC, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/elden-ring-shadow-of-the-erdtree-steam-reviews-1851557175">frustrated players review-bombed the game on Steam</a> 

## Some Mortal Kombat Fans Worry The Latest Game Is Already Dead, But It Might Be More Complicated
 - [https://kotaku.com/mortal-kombat-1-mk1-evo-registration-fgc-netherrealm-1851573294](https://kotaku.com/mortal-kombat-1-mk1-evo-registration-fgc-netherrealm-1851573294)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T18:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/cd34f8f25e772d849290273e73f06e14.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/mortal-kombat-1-mk1-review-is-it-good-ps5-xbox-pc-1850863299">Mortal Kombat 1</a> is the latest entry in one of the most iconic fighting game franchises. But compared to other major players like <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/street-fighter-6-review-world-tour-story-mode-roster-1850481281">Street Fighter 6</a> and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/tekken-8-review-roundup-1851189539">Tekken 8</a>, its <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.evo.gg/news/evo-2024-competitors-by-the-numbers" rel="noopener noreferrer" target="_blank">registration numbers for EVO</a>, the biggest fighting game tournament in the world, are minuscule, coming 

## Cate Blanchett Explains Why She's In The Borderlands Movie
 - [https://kotaku.com/cate-blanchett-borderlands-why-is-she-in-it-pandemic-1851573135](https://kotaku.com/cate-blanchett-borderlands-why-is-she-in-it-pandemic-1851573135)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T17:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/52679d64edfaf923a8b5d0b618a0deb6.jpg" /><p>It always seemed a bit weird that famed, Oscar-winning actress Cate Blanchett decided to be a part of the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/borderlands-live-action-movie-trailer-cate-blanchett-1851274665">Borderlands live-action movie</a>. Now we know the story of how this odd casting happened and it seems we can blame covid-19. </p><p><a href="https://kotaku.com/cate-blanchett-borderlands-why-is-she-in-it-pandemic-1851573135">Read more...</a></p>

## How To Unlock The New Viper And Pictomancer Jobs In Final Fantasy XIV: Dawntrail
 - [https://kotaku.com/final-fantasy-14-dawntrail-viper-pictomancer-location-1851572920](https://kotaku.com/final-fantasy-14-dawntrail-viper-pictomancer-location-1851572920)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/0778d6e16cb1e40ce3f121165b5a3bcd.jpg" /><p>Following <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/final-fantasy-14-dawntrail-two-day-maintenance-1851557920">an unusually long period of maintenance</a>, Final Fantasy XIV: Dawntrail is finally here! While many will eagerly embark upon their adventure in the New World the second they log in, others may wish to make a beeline towards unlocking the new DPS jobs: Viper and Pictomancer. If you’re in the latter category,…</p><p><a href="https://kotaku.com/final-fantasy-14-dawntrail-viper-pictomancer-location-1851572920">Read more...</a></p>

## Xbox Game Pass Gets Some Must-Play Games In July
 - [https://kotaku.com/xbox-game-pass-july-2024-neon-white-savage-planet-list-1851572734](https://kotaku.com/xbox-game-pass-july-2024-neon-white-savage-planet-list-1851572734)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e68bd620bc9f0747c1a6ec19ae363479.jpg" /><p>Welcome to July 2024! You made it. We are past the halfway point of the year and to celebrate, Xbox has announced a nice list of new and old games coming to its ever-growing <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/xbox-game-pass-call-duty-black-ops-release-date-1851484337">Game Pass</a> service. And it’s also revealed five games are leaving, too. It can’t all be good news. </p><p><a href="https://kotaku.com/xbox-game-pass-july-2024-neon-white-savage-planet-list-1851572734">Read more...</a></p>

## Elden Ring Helped Inspire The Acolyte's Hot Sith Baddie
 - [https://kotaku.com/the-acolyte-elden-ring-the-stranger-manny-jacinto-1851572749](https://kotaku.com/the-acolyte-elden-ring-the-stranger-manny-jacinto-1851572749)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/184c7aeba769235dd4a40381296abbf5.jpg" /><p>Have you also been gnawing on the bars of your enclosure since the most recent episode of The Acolyte? If so, it might surprise you to discover that part of the inspiration for the show’s great mystery is the game that everybody’s playing right now.</p><p><a href="https://kotaku.com/the-acolyte-elden-ring-the-stranger-manny-jacinto-1851572749">Read more...</a></p>

## House Of The Dragon Season 2 Episode 3 Recap: Sister Act
 - [https://kotaku.com/house-dragon-recap-season-2-episode-3-1851572717](https://kotaku.com/house-dragon-recap-season-2-episode-3-1851572717)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T15:40:27+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/6af76cebdc785e4c25f8b9a1dc6ab175.jpg" /><p>After two high-velocity episodes of death and mourning, the third episode of House of the Dragon’s second season slows down the energy, though not before giving a taste of the famed Bracken and Blackwood feud. The opposing families find themselves on opposite sides of the civil war and go to blows over it.<br /></p><p><a href="https://kotaku.com/house-dragon-recap-season-2-episode-3-1851572717">Read more...</a></p>

## This Shadow Of The Erdtree Talisman Is Perfect For Tank Builds
 - [https://kotaku.com/elden-ring-shadow-erdtree-verdigris-discus-talisman-1851572597](https://kotaku.com/elden-ring-shadow-erdtree-verdigris-discus-talisman-1851572597)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/8c90fab5ee38c81d4a6e3422853e108d.jpg" /><p>The Verdigris Discus is a Talisman found exclusively in Elden Ring’s Shadow of the Erdtree expansion. If you’re the type who favors defense over offense, this Talisman may be just the answer for you. It increases your protection when you have a higher equip load. So pack on that armor and get to tanking!</p><p><a href="https://kotaku.com/elden-ring-shadow-erdtree-verdigris-discus-talisman-1851572597">Read more...</a></p>

## Overwatch 2 Fans Are Sick And Tired Of Pharah
 - [https://kotaku.com/overwatch-2-pharah-meta-season-11-patch-notes-nerf-buff-1851572626](https://kotaku.com/overwatch-2-pharah-meta-season-11-patch-notes-nerf-buff-1851572626)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T15:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/8bcf8c2aac9b8685b40cb6c829b1f90e.jpg" /><p>Like any other competitive game, the meta for Blizzard’s hero shooter <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/overwatch-2-skins-characters-reddit-steam-2023-1851119014">Overwatch 2</a> is constantly in flux. Sometimes a new hero like <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/overwatch-2-new-patch-notes-season-8-mauga-1851075158">Mauga</a> dominates when they debut and has to be reined in with some debuffs and tweaks. Other times a series of changes send characters skyrocketing to the top of tier lists. That’s what’s…</p><p><a href="https://kotaku.com/overwatch-2-pharah-meta-season-11-patch-notes-nerf-buff-1851572626">Read more...</a></p>

## MultiVersus: The Kotaku Review
 - [https://kotaku.com/multiversus-review-smash-bros-batman-1851572599](https://kotaku.com/multiversus-review-smash-bros-batman-1851572599)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T15:13:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/570016cf0e1bc282572f4375a2e985de.jpg" /><p>Sometimes when I sit down to play <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/games/multiversus">MultiVersus</a>, it kinda feels like I’m a child reaching into a cookie jar. Part of me knows, if I want to be a good boy, I shouldn’t be doing it. But cookies taste good as hell. That rush of mind-melting bliss when biting into a gooey, sugary treat easily overtakes the ethical…</p><p><a href="https://kotaku.com/multiversus-review-smash-bros-batman-1851572599">Read more...</a></p>

## Hideo Kojima Really Loves The Chainsaw Man Creator’s New Movie
 - [https://kotaku.com/hideo-kojima-look-back-movie-chainsaw-man-1851572521](https://kotaku.com/hideo-kojima-look-back-movie-chainsaw-man-1851572521)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T15:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/d6ad6436fbfaa137f6847002d1f95d51.jpg" /><p>Look Back, the adaptation of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/chainsaw-man-asa-female-incel-shonen-jump-manga-1850208738">Chainsaw Man</a> creator Tastsuki Fujimoto’s 2021 manga of the same name, is a hit in Japan after a <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://x.com/Nakayasee/status/1806686246799847842" rel="noopener noreferrer" target="_blank">strong opening weekend</a>. One person who is particularly in love with the film is none other than everyone’s favorite full-time cinephile and part-time game developer, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/hideo-kojima-connecting-worlds-review-death-stranding-1850570684">Hideo Kojima</a>. In the five…</p><p><a href="https://kotaku.com/hideo-kojima-look-back-movie-chainsaw-man-1851572

## Fire Off Flurries Of Deadly Bolts With This Speedy Shadow Of The Erdtree Crossbow
 - [https://kotaku.com/elden-ring-shadow-erdtree-repeating-crossbow-1851572336](https://kotaku.com/elden-ring-shadow-erdtree-repeating-crossbow-1851572336)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T14:06:26+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/c1e341b74c320ebb7964f3c2c4710c9b.jpg" /><p>The Repeating Crossbow is only available in Elden Ring’s Shadow of the Erdtree expansion. While it can function fine as a standard crossbow, its Ash of War—which allows it to fire back-to-back bolts at a staggering speed—makes it stand out among other weapons in its class. Thanks to its fairly reasonable stat…</p><p><a href="https://kotaku.com/elden-ring-shadow-erdtree-repeating-crossbow-1851572336">Read more...</a></p>

## Shadow Of The Erdtree's Minor Erdtree Incantation Is The Cutest Little Healer
 - [https://kotaku.com/elden-ring-shadow-erdtree-minor-erdtree-incantation-1851570252](https://kotaku.com/elden-ring-shadow-erdtree-minor-erdtree-incantation-1851570252)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T13:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/85cd8126426ef8096be52d7ffd1ab8f7.jpg" /><p>The Minor Erdtree Incantation can only be found in Elden Ring’s Shadow of the Erdtree expansion. Casting it will allow you to continuously heal yourself and allies standing nearby, although there are better ways to heal a group. Even so, completionists and fans of tiny trees will no doubt still want to add this one to…</p><p><a href="https://kotaku.com/elden-ring-shadow-erdtree-minor-erdtree-incantation-1851570252">Read more...</a></p>

## Frostpunk 2, Flintlock, and 22 Other Games Worth Checking Out In July
 - [https://kotaku.com/july-2024-games-final-fantasy-flintlock-frostpunk-edf-1851571285](https://kotaku.com/july-2024-games-final-fantasy-flintlock-frostpunk-edf-1851571285)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T13:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/8fe48abbb70b9c8840ee64315f44d9cb.jpg" /><p>With the passage of the summer solstice last month, we are firmly in the hottest season. And this July, we’ve got a generous collection of compelling titles worth checking out. From some intriguing indie titles to Final Fantasy XIV’s latest expansion and beyond, this month is packed with games that look well worth…</p><p><a href="https://kotaku.com/july-2024-games-final-fantasy-flintlock-frostpunk-edf-1851571285">Read more...</a></p>

## Capcom Nonchalantly Announces Resident Evil 9
 - [https://kotaku.com/resident-evil-9-capcom-biohazard-village-1851572109](https://kotaku.com/resident-evil-9-capcom-biohazard-village-1851572109)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-07-02T12:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/76a01b3ddb0b3d379b6ed81e2559f7ef.jpg" /><p>With the remakes of the remasters of the reissues of the remakes, it does feel like there are always approximately <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/ready-for-more-resident-evil-remakes-capcom-sure-is-1851066026">372 different Resident Evil games in development at any one time</a>. However, brand new ones are a more rare treat, and that’s what was nonchalantly confirmed by Capcom last night. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/resident-evil-9-capcom-release-window-leak-rumor-1851457948">Resident Evil 9</a>, although…</p><p><a href="https://kotaku.com/resident-evil-9-capcom-biohazard-village-1851572109">Read more...</a></p>

