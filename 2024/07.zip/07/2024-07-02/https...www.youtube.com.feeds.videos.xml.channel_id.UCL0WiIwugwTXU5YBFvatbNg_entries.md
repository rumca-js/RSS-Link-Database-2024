# Source:Ku Bogu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0WiIwugwTXU5YBFvatbNg, language:pl

## Uwolnijcie Nas Stąd! (część 15) PIEKŁO I SZATAN
 - [https://www.youtube.com/watch?v=ubbvuFoeQxM](https://www.youtube.com/watch?v=ubbvuFoeQxM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0WiIwugwTXU5YBFvatbNg
 - date published: 2024-07-02T10:54:48+00:00

☑️ "Uwolnijcie nas stąd!" z Wydawnictwa M jest opracowane dzięki wielkiej uprzejmości tego wydawnictwa. Książka jest dostępna pod tym linkiem:
https://tiny.pl/d5rwd

Od roku 2017 kiedy pojawiła się pierwsza wersja tej książki odnotowaliśmy już ponad milion wyświetleń. Również druga wersja audiobooka przygotowana przez Roberta i Ludwikę cieszyła się dużą popularnością. Za zgodą Wydawnictwa M publikujemy książkę po raz trzeci - odnowioną wizualnie i dźwiękowo. 
Tym razem w rolę Marii wciela się:
Magdalena Woźniak
@magda_wozniak_17
a Nickiego Eltz'a odtwarza Igor Nadolski.
Książka-wywiad z Marią Simmą mistyczką, która przez wiele lat rozmawiała z duszami czyśćcowymi to jej relacja z kilkudziesięciu lat obcowania z duszami czyśćcowymi. Z książki dowiemy się czego potrzebują dusze w czyśćcu cierpiące, dlaczego ważna jest msza za zmarłych i jak możemy się za nich modlić. Książka została opatrzona pozytywną opinią przedstawicieli Kościoła i choć nie ma imprimatur z pewnością przyczynia się d

