# Source:Colombia News | Colombia Reports, URL:https://colombiareports.com/feed, language:en-US

## Medellin’s extradited crime boss wants to be peace promoter in Colombia
 - [https://colombiareports.com/medellins-extradited-crime-boss-wants-to-be-peace-promoter-in-colombia](https://colombiareports.com/medellins-extradited-crime-boss-wants-to-be-peace-promoter-in-colombia)
 - RSS feed: https://colombiareports.com/feed
 - date published: 2024-07-02T17:34:05+00:00

<p>Extradited Medellin crime lord Diego Fernando Murillo, a.k.a. &#8220;Don Berna,&#8221; asked President Gustavo Petro to allow him to take part in peacebuilding efforts in Colombia. In a letter to the&#8230;</p>
<p>The post <a href="https://colombiareports.com/medellins-extradited-crime-boss-wants-to-be-peace-promoter-in-colombia/">Medellin&#8217;s extradited crime boss wants to be peace promoter in Colombia</a> appeared first on <a href="https://colombiareports.com">Colombia News | Colombia Reports</a>.</p>

## Colombia arrests two Tren de Aragua bosses
 - [https://colombiareports.com/colombia-arrests-two-tren-de-aragua-bosses](https://colombiareports.com/colombia-arrests-two-tren-de-aragua-bosses)
 - RSS feed: https://colombiareports.com/feed
 - date published: 2024-07-02T14:10:59+00:00

<p>Colombia&#8217;s police said they have arrested a founder and a regional chief of organized crime group Tren de Aragua over the past week. Last week, police arrested Salomon Fernandez, the&#8230;</p>
<p>The post <a href="https://colombiareports.com/colombia-arrests-two-tren-de-aragua-bosses/">Colombia arrests two Tren de Aragua bosses</a> appeared first on <a href="https://colombiareports.com">Colombia News | Colombia Reports</a>.</p>

