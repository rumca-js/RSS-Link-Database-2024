# Source:EN World Tabletop RPG News & Reviews, URL:https://www.enworld.org/ewr-porta/index.rss, language:en

## RPG Print News – Cubicle 7, Arc Dream Publishing, and More
 - [https://www.enworld.org/threads/rpg-print-news-%E2%80%93-cubicle-7-arc-dream-publishing-and-more.705020](https://www.enworld.org/threads/rpg-print-news-%E2%80%93-cubicle-7-arc-dream-publishing-and-more.705020)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-07-02T12:30:00+00:00

<div class="bbWrapper">Delta Green, The Labyrinth,  Mothership, Warhammer FRP, and weird town and corporate horror print products out this week.</div>

## There Will Be No More Hydro74 Alternate D&D Covers
 - [https://www.enworld.org/threads/there-will-be-no-more-hydro74-alternate-d-d-covers.705079](https://www.enworld.org/threads/there-will-be-no-more-hydro74-alternate-d-d-covers.705079)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-07-02T09:06:00+00:00

<div class="bbWrapper">Hydro74 has confirmed that Vecna: Even of Ruin was their final alternate cover for D&amp;D.</div>

