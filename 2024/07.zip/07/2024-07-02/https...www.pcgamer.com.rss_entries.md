# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## Just 3 months after launching Tales of Kenzera: Zau, developer Surgent Studios lays off 'just over a dozen' employees
 - [https://www.pcgamer.com/games/action/just-3-months-after-launching-tales-of-kenzera-zau-developer-surgent-studios-lays-off-just-over-a-dozen-employees](https://www.pcgamer.com/games/action/just-3-months-after-launching-tales-of-kenzera-zau-developer-surgent-studios-lays-off-just-over-a-dozen-employees)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T23:18:58+00:00

"This hurts deeply. This isn't the news I wanted to share."

## Xbox Live suffers a 'major outage' that's keeping people from logging in, Microsoft says fixing it is 'taking longer than expected'
 - [https://www.pcgamer.com/software/platforms/xbox-live-suffers-a-major-outage-thats-keeping-people-from-logging-in-microsoft-says-fixing-it-is-taking-longer-than-expected](https://www.pcgamer.com/software/platforms/xbox-live-suffers-a-major-outage-thats-keeping-people-from-logging-in-microsoft-says-fixing-it-is-taking-longer-than-expected)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T21:23:05+00:00

Login services were knocked out earlier this afternoon.

## Stardew Valley players on Steam Deck can test out the new Nexus Mods app
 - [https://www.pcgamer.com/games/life-sim/stardew-valley-players-on-steam-deck-can-test-out-the-new-nexus-mods-app](https://www.pcgamer.com/games/life-sim/stardew-valley-players-on-steam-deck-can-test-out-the-new-nexus-mods-app)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T21:16:59+00:00

Calling all farmers!

## Expansions are the best
 - [https://www.pcgamer.com/gaming-industry/expansions-are-the-best](https://www.pcgamer.com/gaming-industry/expansions-are-the-best)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T20:37:12+00:00

In this era of bite-sized DLC and season passes, we appreciate giant, game-changing expansions more than ever.

## Academy Award-winner Cate Blanchett explains why she signed up for the Borderlands film: 'A touch of Covid madness'
 - [https://www.pcgamer.com/movies-tv/academy-award-winner-cate-blanchett-explains-why-she-signed-up-for-the-borderlands-film-a-touch-of-covid-madness](https://www.pcgamer.com/movies-tv/academy-award-winner-cate-blanchett-explains-why-she-signed-up-for-the-borderlands-film-a-touch-of-covid-madness)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T20:31:18+00:00

Boredom can make us do strange things.

## Elden Ring: Shadow of the Erdtree players are sleepwalking through bossfights with the DLC's silly, pointy shields
 - [https://www.pcgamer.com/games/rpg/elden-ring-shadow-of-the-erdtree-players-are-sleepwalking-through-bossfights-with-the-dlcs-silly-pointy-shields](https://www.pcgamer.com/games/rpg/elden-ring-shadow-of-the-erdtree-players-are-sleepwalking-through-bossfights-with-the-dlcs-silly-pointy-shields)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T20:15:39+00:00

Simply always be blocking.

## Pope recognises second miracle by 'God's influencer' as the Catholic Church prepares to canonise its first gamer saint—and yep, one of his favourites was Halo
 - [https://www.pcgamer.com/gaming-industry/pope-recognises-second-miracle-by-gods-influencer-as-the-catholic-church-prepares-to-canonise-its-first-gamer-saint](https://www.pcgamer.com/gaming-industry/pope-recognises-second-miracle-by-gods-influencer-as-the-catholic-church-prepares-to-canonise-its-first-gamer-saint)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T17:09:43+00:00

Carlo Acutis died in 2006 and has been credited with multiple posthumous miracles.

## The BBC dons its game dev cap to combine 2 things I fear and don't understand: The UK General Election and Roblox
 - [https://www.pcgamer.com/software/platforms/the-bbc-dons-its-game-dev-cap-to-combine-2-things-i-fear-and-dont-understand-the-uk-general-election-and-roblox](https://www.pcgamer.com/software/platforms/the-bbc-dons-its-game-dev-cap-to-combine-2-things-i-fear-and-dont-understand-the-uk-general-election-and-roblox)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T16:57:21+00:00

Politics? In videogames?

## Lethal Company's next update introduces monsters that'll kidnap you and cut you up as well as its first and only vehicle
 - [https://www.pcgamer.com/games/horror/lethal-companys-next-update-introduces-monsters-thatll-kidnap-you-and-cut-you-up-as-well-as-its-first-and-only-vehicle](https://www.pcgamer.com/games/horror/lethal-companys-next-update-introduces-monsters-thatll-kidnap-you-and-cut-you-up-as-well-as-its-first-and-only-vehicle)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T16:32:51+00:00

Get in employees we're going scraping.

## The most popular RTX 40-series GPU on Steam is in a gaming laptop, not a graphics card
 - [https://www.pcgamer.com/hardware/graphics-cards/the-most-popular-rtx-40-series-gpu-on-steam-is-in-a-gaming-laptop-not-a-graphics-card](https://www.pcgamer.com/hardware/graphics-cards/the-most-popular-rtx-40-series-gpu-on-steam-is-in-a-gaming-laptop-not-a-graphics-card)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T16:22:59+00:00

June's Steam hardware survey shows ever more RTX 4060 laptop gamers.

## Don't sweat it—Zenless Zone Zero's system requirements demand nothing more than a ten-year old GPU and 8 GB of RAM
 - [https://www.pcgamer.com/hardware/dont-sweat-itzenless-zone-zeros-system-requirements-demand-nothing-more-than-a-ten-year-old-gpu-and-8-gb-of-ram](https://www.pcgamer.com/hardware/dont-sweat-itzenless-zone-zeros-system-requirements-demand-nothing-more-than-a-ten-year-old-gpu-and-8-gb-of-ram)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T16:21:13+00:00

Budget gamers, you're good to go.

## Palia developer Singularity 6 is now part of the Daybreak Game Company
 - [https://www.pcgamer.com/gaming-industry/palia-developer-singularity-6-is-now-part-of-the-daybreak-game-company](https://www.pcgamer.com/gaming-industry/palia-developer-singularity-6-is-now-part-of-the-daybreak-game-company)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T16:12:55+00:00

Daybreak's acquisition of Singularity 6 comes less than two months after major layoffs at the studio.

## Mortal Kombat player wins $565, celebrates by breaking a light worth $3000
 - [https://www.pcgamer.com/games/fighting/mortal-kombat-player-wins-dollar565-celebrates-by-breaking-a-light-worth-dollar3000](https://www.pcgamer.com/games/fighting/mortal-kombat-player-wins-dollar565-celebrates-by-breaking-a-light-worth-dollar3000)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T16:12:39+00:00

Dyloch's bone-headed "pop-off" may have cost him dearly.

## Capcom's somehow come up with the *deep breath* Dead Rising Deluxe Remaster Digital Deluxe edition
 - [https://www.pcgamer.com/games/action/capcoms-somehow-come-up-with-the-dead-rising-deluxe-remaster-digital-deluxe-edition](https://www.pcgamer.com/games/action/capcoms-somehow-come-up-with-the-dead-rising-deluxe-remaster-digital-deluxe-edition)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T15:52:31+00:00

Let me be Frank: GOTY.

## I pitied Shadow of the Erdtree's future 'Let Me Solo Her' champion, but seeing how the Elden Ring community's handled business, I'm not so worried anymore
 - [https://www.pcgamer.com/games/rpg/i-pitied-shadow-of-the-erdtree-s-future-let-me-solo-her-champion-but-seeing-how-the-elden-ring-community-s-handled-business-i-m-not-worried-anymore](https://www.pcgamer.com/games/rpg/i-pitied-shadow-of-the-erdtree-s-future-let-me-solo-her-champion-but-seeing-how-the-elden-ring-community-s-handled-business-i-m-not-worried-anymore)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T14:17:13+00:00

The kids are alright.

## Capcom announces the next mainline Resident Evil is in development, and the great news is it's being helmed by Resident Evil 7's director
 - [https://www.pcgamer.com/games/resident-evil/capcom-announces-the-next-mainline-resident-evil-is-in-development-and-the-great-news-is-its-being-helmed-by-resident-evil-7s-director](https://www.pcgamer.com/games/resident-evil/capcom-announces-the-next-mainline-resident-evil-is-in-development-and-the-great-news-is-its-being-helmed-by-resident-evil-7s-director)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T13:52:15+00:00

Welcome to the family.

## Nvidia could face antitrust charges in France as 'the risk of abuse by chip providers' scrutinised by competition authority
 - [https://www.pcgamer.com/hardware/graphics-cards/nvidia-could-face-antitrust-charges-in-france-as-the-risk-of-abuse-by-chip-providers-scrutinised-by-competition-authority](https://www.pcgamer.com/hardware/graphics-cards/nvidia-could-face-antitrust-charges-in-france-as-the-risk-of-abuse-by-chip-providers-scrutinised-by-competition-authority)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T13:25:41+00:00

Follow-up to raids at Nvidia's offices in September.

## Elden Ring maestro plays a saxophone to style on Shadow of the Erdtree's final boss, wins battle of the bands in 'a dozen attempts'
 - [https://www.pcgamer.com/games/rpg/elden-ring-maestro-plays-a-saxophone-to-style-on-shadow-of-the-erdtree-s-final-boss-wins-battle-of-the-bands-in-a-dozen-attempts](https://www.pcgamer.com/games/rpg/elden-ring-maestro-plays-a-saxophone-to-style-on-shadow-of-the-erdtree-s-final-boss-wins-battle-of-the-bands-in-a-dozen-attempts)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T11:22:06+00:00

Let me (jazz) solo her.

## Samsung was either feeling generous or someone messed up big time when it temporarily slashed £1,400 off a 49-inch 240 Hz OLED gaming monitor
 - [https://www.pcgamer.com/hardware/gaming-monitors/samsung-was-either-feeling-generous-or-someone-messed-up-big-time-when-it-temporarily-slashed-pound1400-off-a-49-inch-240-hz-oled-gaming-monitor](https://www.pcgamer.com/hardware/gaming-monitors/samsung-was-either-feeling-generous-or-someone-messed-up-big-time-when-it-temporarily-slashed-pound1400-off-a-49-inch-240-hz-oled-gaming-monitor)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T09:56:52+00:00

I missed it!

## Today's Wordle answer for Tuesday, July 2
 - [https://www.pcgamer.com/games/puzzle/wordle-answer-today-July-2-2024](https://www.pcgamer.com/games/puzzle/wordle-answer-today-July-2-2024)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T03:00:44+00:00

Trouble solving today's Wordle? Here's the help you need.

## After years of coasting on Dr Disrespect's fame, it's hard to imagine a happy ending for Midnight Society
 - [https://www.pcgamer.com/games/fps/after-years-of-coasting-on-dr-disrespects-fame-its-hard-to-envision-a-happy-ending-for-midnight-society](https://www.pcgamer.com/games/fps/after-years-of-coasting-on-dr-disrespects-fame-its-hard-to-envision-a-happy-ending-for-midnight-society)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T00:24:07+00:00

What even is Deadrop without Dr Disrespect?

## It took me 7 hours to beat Elden Ring: Shadow of the Erdtree's final boss, and people are already demolishing it without getting hit⁠ a single time
 - [https://www.pcgamer.com/games/rpg/it-took-me-7-hours-to-beat-elden-ring-shadow-of-the-erdtrees-final-boss-and-people-are-already-demolishing-it-without-getting-hit-a-single-time](https://www.pcgamer.com/games/rpg/it-took-me-7-hours-to-beat-elden-ring-shadow-of-the-erdtrees-final-boss-and-people-are-already-demolishing-it-without-getting-hit-a-single-time)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-07-02T00:03:43+00:00

Didn't expect weak foe.

