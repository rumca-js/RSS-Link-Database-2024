# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Sauron's wink in the piranha world
 - [https://www.lemonde.fr/en/science/article/2024/07/02/sauron-s-wink-in-the-piranha-world_6676469_10.html](https://www.lemonde.fr/en/science/article/2024/07/02/sauron-s-wink-in-the-piranha-world_6676469_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2024-07-02T17:38:24+00:00

A new species of herbivore piranha has been identified in Brazil's Xingu River, a tributary of the Amazon. Researchers have named this little fish 'Myloplus sauron.'

