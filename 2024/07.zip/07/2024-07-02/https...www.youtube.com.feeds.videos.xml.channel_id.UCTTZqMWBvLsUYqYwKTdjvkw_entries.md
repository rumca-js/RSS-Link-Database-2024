# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 🐞 Krytyczna luka w OpenSSH. RCE!
 - [https://www.youtube.com/watch?v=gB53fQjGfLs](https://www.youtube.com/watch?v=gB53fQjGfLs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2024-07-02T04:30:16+00:00

Odkryto bardzo poważną lukę w OpenSSH
 
Źródła:
https://tinyurl.com/3ke9h2v5
https://tinyurl.com/wf2xvde4
 
#Linux #SSH #podatność #RCE

