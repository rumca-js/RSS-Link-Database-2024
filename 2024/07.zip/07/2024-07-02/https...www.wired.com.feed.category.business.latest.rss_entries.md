# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## YouTube’s Rulings on Gaza War Videos Spark Internal Backlash
 - [https://www.wired.com/story/youtube-israel-gaza-moderation](https://www.wired.com/story/youtube-israel-gaza-moderation)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2024-07-02T10:00:00+00:00

Insiders have shared YouTube’s playbook for handling the Gaza crisis. They argue that it shows inconsistent enforcement.

