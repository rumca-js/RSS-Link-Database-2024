# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## Thought people would find this cool. Metal 3D printed aerospace part my company machines. Under a microscope.
 - [https://www.reddit.com/r/3Dprinting/comments/1dtzbq4/thought_people_would_find_this_cool_metal_3d](https://www.reddit.com/r/3Dprinting/comments/1dtzbq4/thought_people_would_find_this_cool_metal_3d)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T23:01:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtzbq4/thought_people_would_find_this_cool_metal_3d/"> <img alt="Thought people would find this cool. Metal 3D printed aerospace part my company machines. Under a microscope." src="https://b.thumbs.redditmedia.com/JB0yV2ewiccFxFeIyn2w4yajEQS70Bqk8TG1q678eaA.jpg" title="Thought people would find this cool. Metal 3D printed aerospace part my company machines. Under a microscope." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/EpicGamerStyle104"> /u/EpicGamerStyle104 </a> <br /> <span><a href="https://www.reddit.com/gallery/1dtzbq4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtzbq4/thought_people_would_find_this_cool_metal_3d/">[comments]</a></span> </td></tr></table>

## Trophies I made for a local Softball Game
 - [https://www.reddit.com/r/3Dprinting/comments/1dtvzsd/trophies_i_made_for_a_local_softball_game](https://www.reddit.com/r/3Dprinting/comments/1dtvzsd/trophies_i_made_for_a_local_softball_game)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T20:34:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtvzsd/trophies_i_made_for_a_local_softball_game/"> <img alt="Trophies I made for a local Softball Game " src="https://b.thumbs.redditmedia.com/XpQ08TvN-k0Mv9OmOXhWOtDhClo0PUxG_6DKvAcdYDc.jpg" title="Trophies I made for a local Softball Game " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/criscodesigns"> /u/criscodesigns </a> <br /> <span><a href="https://www.reddit.com/gallery/1dtvzsd">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtvzsd/trophies_i_made_for_a_local_softball_game/">[comments]</a></span> </td></tr></table>

## Printing wet ABS seems to make my printer happy
 - [https://www.reddit.com/r/3Dprinting/comments/1dtvj74/printing_wet_abs_seems_to_make_my_printer_happy](https://www.reddit.com/r/3Dprinting/comments/1dtvj74/printing_wet_abs_seems_to_make_my_printer_happy)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T20:14:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtvj74/printing_wet_abs_seems_to_make_my_printer_happy/"> <img alt="Printing wet ABS seems to make my printer happy " src="https://preview.redd.it/1ns68nn7y5ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a21251fcdc0f790e26b7383b2a5e3f5bfd633a1b" title="Printing wet ABS seems to make my printer happy " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Thegoury"> /u/Thegoury </a> <br /> <span><a href="https://i.redd.it/1ns68nn7y5ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtvj74/printing_wet_abs_seems_to_make_my_printer_happy/">[comments]</a></span> </td></tr></table>

## Who said that you can’t get nice quality prints with an Ender? I mean, it’s no Bambu, but I still think it’s kinda sexy 😏
 - [https://www.reddit.com/r/3Dprinting/comments/1dtvcfa/who_said_that_you_cant_get_nice_quality_prints](https://www.reddit.com/r/3Dprinting/comments/1dtvcfa/who_said_that_you_cant_get_nice_quality_prints)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T20:07:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtvcfa/who_said_that_you_cant_get_nice_quality_prints/"> <img alt="Who said that you can’t get nice quality prints with an Ender? I mean, it’s no Bambu, but I still think it’s kinda sexy 😏" src="https://external-preview.redd.it/bnNoenBwdnV3NWFkMba9i_AAhoLG1VDSSo62MJANYr7q16pSo--INGdY1AuK.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=90acac4ccfcd10513357ea470e720a816f45b55c" title="Who said that you can’t get nice quality prints with an Ender? I mean, it’s no Bambu, but I still think it’s kinda sexy 😏" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Itz_Evolv"> /u/Itz_Evolv </a> <br /> <span><a href="https://v.redd.it/5f07fy0vw5ad1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtvcfa/who_said_that_you_cant_get_nice_quality_prints/">[comments]</a></span> </td></tr></table>

## Stanley shaped lip balm holder for all my hydro homies
 - [https://www.reddit.com/r/3Dprinting/comments/1dtuql7/stanley_shaped_lip_balm_holder_for_all_my_hydro](https://www.reddit.com/r/3Dprinting/comments/1dtuql7/stanley_shaped_lip_balm_holder_for_all_my_hydro)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T19:41:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtuql7/stanley_shaped_lip_balm_holder_for_all_my_hydro/"> <img alt="Stanley shaped lip balm holder for all my hydro homies" src="https://preview.redd.it/ugsmee1xr5ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=79c2d02ff35383d3c786622e57e4177fa9f9e0b5" title="Stanley shaped lip balm holder for all my hydro homies" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/dev0urer"> /u/dev0urer </a> <br /> <span><a href="https://i.redd.it/ugsmee1xr5ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtuql7/stanley_shaped_lip_balm_holder_for_all_my_hydro/">[comments]</a></span> </td></tr></table>

## Designed and printed this for my racing sim
 - [https://www.reddit.com/r/3Dprinting/comments/1dtugks/designed_and_printed_this_for_my_racing_sim](https://www.reddit.com/r/3Dprinting/comments/1dtugks/designed_and_printed_this_for_my_racing_sim)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T19:30:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtugks/designed_and_printed_this_for_my_racing_sim/"> <img alt="Designed and printed this for my racing sim" src="https://preview.redd.it/zr2fhfg8q5ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=714aac265b300b7cb7744b6de3d8f59b36d46245" title="Designed and printed this for my racing sim" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Finally a print i can use</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheCarDudeOnTop"> /u/TheCarDudeOnTop </a> <br /> <span><a href="https://i.redd.it/zr2fhfg8q5ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtugks/designed_and_printed_this_for_my_racing_sim/">[comments]</a></span> </td></tr></table>

## My First Ever Custom Design
 - [https://www.reddit.com/r/3Dprinting/comments/1dtsjzr/my_first_ever_custom_design](https://www.reddit.com/r/3Dprinting/comments/1dtsjzr/my_first_ever_custom_design)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T18:10:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtsjzr/my_first_ever_custom_design/"> <img alt="My First Ever Custom Design" src="https://b.thumbs.redditmedia.com/3Nji2WEfqnF3I-J38PsF91MmjWJFBt0oGRC5eD8HHRA.jpg" title="My First Ever Custom Design" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>A little bit of a flop, but can easily be fixed by adjusting the scale of it. If anyone is interested in the STL file let me know, I put it on my Patreon (free to download after signing up as a free member). Not sure If I can link it here, so if anyone cares for it, send me a dm?</p> <p>The second picture is what prompted me to make a &quot;container&quot; like this, got tired of dealing with the mess.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/3DPrintedAndEpoxy"> /u/3DPrintedAndEpoxy </a> <br /> <span><a href="https://www.reddit.com/gallery/1dtsjzr">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting

## Can we stop posting models with "FREE FOR LIMITED TIME" bullcraps?
 - [https://www.reddit.com/r/3Dprinting/comments/1dtrxz2/can_we_stop_posting_models_with_free_for_limited](https://www.reddit.com/r/3Dprinting/comments/1dtrxz2/can_we_stop_posting_models_with_free_for_limited)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T17:45:49+00:00

<!-- SC_OFF --><div class="md"><p>Tired of seeing that on Thangs and TV. FREE FOR A WEEK!!! A month later, still free. It's not cool. It shouldn't be a trend. Get over yourself.</p> <p>Just upload the model, and let it be.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CarbonGod"> /u/CarbonGod </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtrxz2/can_we_stop_posting_models_with_free_for_limited/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtrxz2/can_we_stop_posting_models_with_free_for_limited/">[comments]</a></span>

## Made with 3D pen. Don't hate me
 - [https://www.reddit.com/r/3Dprinting/comments/1dtreqy/made_with_3d_pen_dont_hate_me](https://www.reddit.com/r/3Dprinting/comments/1dtreqy/made_with_3d_pen_dont_hate_me)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T17:23:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtreqy/made_with_3d_pen_dont_hate_me/"> <img alt="Made with 3D pen. Don't hate me" src="https://external-preview.redd.it/ZWllOXpseWwzNWFkMV97oxcqj-YieMrEjYstIndDtUeb5haZTHpHvZoNT6sj.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=859a3e7479b86e08a688f1191f01d63a20350df9" title="Made with 3D pen. Don't hate me" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DareDracula"> /u/DareDracula </a> <br /> <span><a href="https://v.redd.it/mpah5l5m35ad1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtreqy/made_with_3d_pen_dont_hate_me/">[comments]</a></span> </td></tr></table>

## been printing shoes
 - [https://www.reddit.com/r/3Dprinting/comments/1dtraq0/been_printing_shoes](https://www.reddit.com/r/3Dprinting/comments/1dtraq0/been_printing_shoes)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T17:18:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtraq0/been_printing_shoes/"> <img alt="been printing shoes" src="https://external-preview.redd.it/YmhwdW50aW8yNWFkMQ4eIzRCIEubWwC4Qnf68Ig1_WUcBYPx6AoLxkNpqvWB.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=533493b0679509b373974aa24d587716e4837c1c" title="been printing shoes" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Assentesegnale"> /u/Assentesegnale </a> <br /> <span><a href="https://v.redd.it/mpgn3euo25ad1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtraq0/been_printing_shoes/">[comments]</a></span> </td></tr></table>

## Bambu Labs A1 mini DOA- terrible support. Any tips?
 - [https://www.reddit.com/r/3Dprinting/comments/1dtqh4u/bambu_labs_a1_mini_doa_terrible_support_any_tips](https://www.reddit.com/r/3Dprinting/comments/1dtqh4u/bambu_labs_a1_mini_doa_terrible_support_any_tips)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T16:45:45+00:00

<!-- SC_OFF --><div class="md"><p>I bought an A1 mini that was DOA due to a z-axis homing issue. I opened a ticket, received one message with the troubleshooting suggestion that was ineffective. I've had no further responses. </p> <p>I want to issue a warranty return, but as far as I can tell the only way to complete One is through their support portal, and I'm not getting any responses. Does anybody have any other suggestions or pathways that I can go through to return this defective machine?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Zippityzeebop"> /u/Zippityzeebop </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtqh4u/bambu_labs_a1_mini_doa_terrible_support_any_tips/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtqh4u/bambu_labs_a1_mini_doa_terrible_support_any_tips/">[comments]</a></span>

## Castle for gba
 - [https://www.reddit.com/r/3Dprinting/comments/1dtqej0/castle_for_gba](https://www.reddit.com/r/3Dprinting/comments/1dtqej0/castle_for_gba)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T16:42:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtqej0/castle_for_gba/"> <img alt="Castle for gba" src="https://external-preview.redd.it/aXYwM3VvbmN3NGFkMbcLeLGQEJ8zZC9LHe4QIl2IZuE1H3t8sW2zElfTEaRZ.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=1884842f67a330a6c480678d2447b2b41188727e" title="Castle for gba" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/alexcwo"> /u/alexcwo </a> <br /> <span><a href="https://v.redd.it/5iylhmvcw4ad1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtqej0/castle_for_gba/">[comments]</a></span> </td></tr></table>

## How hard is it to 3D print fishing lures
 - [https://www.reddit.com/r/3Dprinting/comments/1dtppdf/how_hard_is_it_to_3d_print_fishing_lures](https://www.reddit.com/r/3Dprinting/comments/1dtppdf/how_hard_is_it_to_3d_print_fishing_lures)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T16:13:38+00:00

<!-- SC_OFF --><div class="md"><p>Hey all. Very new to 3D printing but I’m curious how difficult it would’ve be to 3D print fishing lures? </p> <p>Specifically spinfish and cut plug designs for salmon. Ive put a few examples below. I have no experiences designing but would like to try it. </p> <p><a href="https://www.amazon.com/Brads-Killer-Fishing-Gear-KOKANEE/dp/B08K1G4TTF/ref=asc_df_B08K1G4TTF/?tag=hyprod-20&amp;linkCode=df0&amp;hvadid=693769151219&amp;hvpos=&amp;hvnetw=g&amp;hvrand=17102696830458555488&amp;hvpone=&amp;hvptwo=&amp;hvqmt=&amp;hvdev=c&amp;hvdvcmdl=&amp;hvlocint=&amp;hvlocphy=9032846&amp;hvtargid=pla-1181746342053&amp;psc=1&amp;mcid=194717beac6536dcbcef17ebe59d06eb&amp;gad_source=1">https://www.amazon.com/Brads-Killer-Fishing-Gear-KOKANEE/dp/B08K1G4TTF/ref=asc_df_B08K1G4TTF/?tag=hyprod-20&amp;linkCode=df0&amp;hvadid=693769151219&amp;hvpos=&amp;hvnetw=g&amp;hvrand=17102696830458555488&amp;hvpone=&amp;hvptwo=&amp;hvqmt=&amp;hvdev=c&amp;hvdvcmdl=&amp;hvlocint=&amp;hvlocp

## My Friend Asked For A House Warming Gift but His Fiancé Thinks They’re Just Weird Fake Fruit
 - [https://www.reddit.com/r/3Dprinting/comments/1dtpmny/my_friend_asked_for_a_house_warming_gift_but_his](https://www.reddit.com/r/3Dprinting/comments/1dtpmny/my_friend_asked_for_a_house_warming_gift_but_his)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T16:10:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtpmny/my_friend_asked_for_a_house_warming_gift_but_his/"> <img alt="My Friend Asked For A House Warming Gift but His Fiancé Thinks They’re Just Weird Fake Fruit" src="https://preview.redd.it/y3ntd2cmq4ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bead875b044fac437d6e11592e70c9d9da68c6dd" title="My Friend Asked For A House Warming Gift but His Fiancé Thinks They’re Just Weird Fake Fruit" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I guess he’s just not going to tell her and I’m going to add a new fruit every holiday until she tells him/me to stop</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/wheresthecheat"> /u/wheresthecheat </a> <br /> <span><a href="https://i.redd.it/y3ntd2cmq4ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtpmny/my_friend_asked_for_a_house_warming_gift_but_his/">[comments]</a></span> </td><

## My first printer and first print!!
 - [https://www.reddit.com/r/3Dprinting/comments/1dtouiz/my_first_printer_and_first_print](https://www.reddit.com/r/3Dprinting/comments/1dtouiz/my_first_printer_and_first_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T15:38:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtouiz/my_first_printer_and_first_print/"> <img alt="My first printer and first print!!" src="https://b.thumbs.redditmedia.com/DJTa0tmXghgdNic6lAF-s4GLkJjkcT0X9uSPyJPCpno.jpg" title="My first printer and first print!!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>After month of contemplating YouTube and this sub, my A1 is finally here!! Summer is really humid here in South Korea so I wasn't taking any chances and also got a Sovol dryer 😅 Looking at the prints on the SD card I almost started with the Benchy but getting the scraper first seemed like a good idea. How would you rate my first print?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/captainmaumau"> /u/captainmaumau </a> <br /> <span><a href="https://www.reddit.com/gallery/1dtouiz">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtouiz/my_first_printer_and_first_print/">[com

## 3d printed Lego bricks made from moon dust
 - [https://www.reddit.com/r/3Dprinting/comments/1dtoabv/3d_printed_lego_bricks_made_from_moon_dust](https://www.reddit.com/r/3Dprinting/comments/1dtoabv/3d_printed_lego_bricks_made_from_moon_dust)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T15:14:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtoabv/3d_printed_lego_bricks_made_from_moon_dust/"> <img alt="3d printed Lego bricks made from moon dust " src="https://external-preview.redd.it/IYV6SpokQn5k73K_weIyQ6MbM_g38WseSBavNO54BR0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1e9573a86a1abb8ac7182c27ca3916d9651e0a51" title="3d printed Lego bricks made from moon dust " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/kimondo"> /u/kimondo </a> <br /> <span><a href="https://www.lego.com/en-us/space/article/lego-space-bricks-moon">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtoabv/3d_printed_lego_bricks_made_from_moon_dust/">[comments]</a></span> </td></tr></table>

## I'm in heaven
 - [https://www.reddit.com/r/3Dprinting/comments/1dtoa8w/im_in_heaven](https://www.reddit.com/r/3Dprinting/comments/1dtoa8w/im_in_heaven)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T15:14:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtoa8w/im_in_heaven/"> <img alt="I'm in heaven" src="https://preview.redd.it/fxf0g8mog4ad1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=1d4e44cd40a35e84043095518a41bb09f1215de1" title="I'm in heaven" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/txanpi"> /u/txanpi </a> <br /> <span><a href="https://i.redd.it/fxf0g8mog4ad1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtoa8w/im_in_heaven/">[comments]</a></span> </td></tr></table>

## Qui-Gon Jinn lightsaber hilt (painted)
 - [https://www.reddit.com/r/3Dprinting/comments/1dtn56b/quigon_jinn_lightsaber_hilt_painted](https://www.reddit.com/r/3Dprinting/comments/1dtn56b/quigon_jinn_lightsaber_hilt_painted)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T14:26:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtn56b/quigon_jinn_lightsaber_hilt_painted/"> <img alt="Qui-Gon Jinn lightsaber hilt (painted)" src="https://b.thumbs.redditmedia.com/5Gu6DWux5dVIfiQAaXXeAZ2XvDAr9cTNeoid26tNpao.jpg" title="Qui-Gon Jinn lightsaber hilt (painted)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I usually print functional stuff, but I've been wanting a static lightsaber for a while and decided to take advantage of some idle time on my Voron thinking some quick sanding and painting would be enough for a good result (I don't have access to a resin printer). Needles to say I was very, VERY wrong. Sanding everything to my satisfaction took ages and a couple of redesigns to break down everything in parts I could reach and sand with relative ease. The airbrushing was actually the quickest part of my project, contrary to my expectations. Despite this, I am very pleased with the end result. The design itself is heavily based on the grea

## What do the ridges mean
 - [https://www.reddit.com/r/3Dprinting/comments/1dtmo4h/what_do_the_ridges_mean](https://www.reddit.com/r/3Dprinting/comments/1dtmo4h/what_do_the_ridges_mean)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T14:05:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtmo4h/what_do_the_ridges_mean/"> <img alt="What do the ridges mean " src="https://b.thumbs.redditmedia.com/22Iq1Hzx-FYU2dlDhoB9hB8Q6XJf9PLWO_m9YQoDHXE.jpg" title="What do the ridges mean " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>The supports have some pretty mad ridges but so far the print itself seems okay but will this be a problem later? Printer is a Neptune 4 pro, printing PLA+ at 100mms, 210 degrees at a .12 layer height </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ok_Impact13"> /u/Ok_Impact13 </a> <br /> <span><a href="https://www.reddit.com/gallery/1dtmo4h">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtmo4h/what_do_the_ridges_mean/">[comments]</a></span> </td></tr></table>

## Tungsten cube display
 - [https://www.reddit.com/r/3Dprinting/comments/1dtltjd/tungsten_cube_display](https://www.reddit.com/r/3Dprinting/comments/1dtltjd/tungsten_cube_display)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T13:26:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtltjd/tungsten_cube_display/"> <img alt="Tungsten cube display" src="https://preview.redd.it/w6rgillgx3ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bd43b289f20235c1a9f4be93e46b7506e4f5418c" title="Tungsten cube display" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Kakashi_aint_uchiha"> /u/Kakashi_aint_uchiha </a> <br /> <span><a href="https://i.redd.it/w6rgillgx3ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtltjd/tungsten_cube_display/">[comments]</a></span> </td></tr></table>

## What's left of a "well" used print surface
 - [https://www.reddit.com/r/3Dprinting/comments/1dtjjg3/whats_left_of_a_well_used_print_surface](https://www.reddit.com/r/3Dprinting/comments/1dtjjg3/whats_left_of_a_well_used_print_surface)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T11:29:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtjjg3/whats_left_of_a_well_used_print_surface/"> <img alt="What's left of a &quot;well&quot; used print surface " src="https://preview.redd.it/tc42bw6hc3ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=eb5ddd105f77e1ef18a00cb1a9bd6d3a044003e3" title="What's left of a &quot;well&quot; used print surface " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Context: My Ender gets used regularly by my college's FSAE team , we have members with various levels of exposure to 3d printing, so in the learning process have casualties 🤣</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/that_desiguy"> /u/that_desiguy </a> <br /> <span><a href="https://i.redd.it/tc42bw6hc3ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtjjg3/whats_left_of_a_well_used_print_surface/">[comments]</a></span> </td></tr></table>

## Help, hotend broken
 - [https://www.reddit.com/r/3Dprinting/comments/1dtjgzd/help_hotend_broken](https://www.reddit.com/r/3Dprinting/comments/1dtjgzd/help_hotend_broken)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T11:25:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtjgzd/help_hotend_broken/"> <img alt="Help, hotend broken" src="https://preview.redd.it/szxch3jrb3ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=87c39ff4c19ffca92e8b6befb00489d821d302e4" title="Help, hotend broken" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Every 2-3 days it breaks Anykubic kobra 2 max</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Le0m1m"> /u/Le0m1m </a> <br /> <span><a href="https://i.redd.it/szxch3jrb3ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtjgzd/help_hotend_broken/">[comments]</a></span> </td></tr></table>

## My gothic fantasy
 - [https://www.reddit.com/r/3Dprinting/comments/1dtj6sc/my_gothic_fantasy](https://www.reddit.com/r/3Dprinting/comments/1dtj6sc/my_gothic_fantasy)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T11:08:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtj6sc/my_gothic_fantasy/"> <img alt="My gothic fantasy" src="https://external-preview.redd.it/emhjcmQ3M204M2FkMceKBcJIfOzIr6DGSKpoaMYKc98PnTX2IP257_EnJRDw.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=bb498de1bd3fba02494a54f15a04a0a53e416c5f" title="My gothic fantasy" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Efficient_Shopping32"> /u/Efficient_Shopping32 </a> <br /> <span><a href="https://v.redd.it/o6jnk73m83ad1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtj6sc/my_gothic_fantasy/">[comments]</a></span> </td></tr></table>

## 3D Printed Tortoise-inspired Car Monocoque (Prototype)
 - [https://www.reddit.com/r/3Dprinting/comments/1dtip50/3d_printed_tortoiseinspired_car_monocoque](https://www.reddit.com/r/3Dprinting/comments/1dtip50/3d_printed_tortoiseinspired_car_monocoque)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T10:38:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtip50/3d_printed_tortoiseinspired_car_monocoque/"> <img alt="3D Printed Tortoise-inspired Car Monocoque (Prototype)" src="https://external-preview.redd.it/eTFuMmRnMWoyM2FkMaxfxJ4o87FppGA6AnBQ2azbSstCac8JQYCBkObm-41k.png?width=140&amp;height=78&amp;crop=140:78,smart&amp;format=jpg&amp;v=enabled&amp;lthumb=true&amp;s=51df420221ab08ae5d2d72c00278d34a6c1cc060" title="3D Printed Tortoise-inspired Car Monocoque (Prototype)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/3DPrintingBootcamp"> /u/3DPrintingBootcamp </a> <br /> <span><a href="https://v.redd.it/pda6rd1j23ad1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtip50/3d_printed_tortoiseinspired_car_monocoque/">[comments]</a></span> </td></tr></table>

## Both PLAs from Different Brands
 - [https://www.reddit.com/r/3Dprinting/comments/1dthf7t/both_plas_from_different_brands](https://www.reddit.com/r/3Dprinting/comments/1dthf7t/both_plas_from_different_brands)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T09:11:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dthf7t/both_plas_from_different_brands/"> <img alt="Both PLAs from Different Brands " src="https://external-preview.redd.it/dTE4bWY5bHFuMmFkMdDOp0cmt7bME8p4RQF5Rlz6zE2-Ibb6cMMz0TAlc91E.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=1a926b70cca6f76a64b3183ed5224b72221fd785" title="Both PLAs from Different Brands " /> </a> </td><td> <!-- SC_OFF --><div class="md"><pre><code>1. PLA - Hatchbox - White - Printed in Mk3s 2. PLA - Bambu Lab Basic - Green - Printed in A1 Mini factory profile </code></pre> <p>I have tested this white PLA from Hatchbox for over eight months on its AC vent clips, and it’s still serving well. There are no issues under the sun, just a bit of looseness after 3-4 months. However, I conducted an experiment yesterday; the new green part fell apart after just one day, which is a normal thing for PLA. You might ask, “Why are you printing in PLA?” I’m aware that ASA would be preferable here, but I 

## Even though it’s such an easy shape with no details what so ever, I (as a beginner) feel proud for achieving this print quality after having quite some adhesion, offset and other small issues before. Makes me happy and gives some positivity to keep on going with the hobby 😊
 - [https://www.reddit.com/r/3Dprinting/comments/1dthai0/even_though_its_such_an_easy_shape_with_no](https://www.reddit.com/r/3Dprinting/comments/1dthai0/even_though_its_such_an_easy_shape_with_no)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T09:02:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dthai0/even_though_its_such_an_easy_shape_with_no/"> <img alt="Even though it’s such an easy shape with no details what so ever, I (as a beginner) feel proud for achieving this print quality after having quite some adhesion, offset and other small issues before. Makes me happy and gives some positivity to keep on going with the hobby 😊" src="https://external-preview.redd.it/cjFuaXpwYjdtMmFkMUikZGkW-y2srewdji4jUrCf50XRsDKvUp8MOMxEpJml.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c86813e22ba5891cfe761d72c719ec1d5a404fd8" title="Even though it’s such an easy shape with no details what so ever, I (as a beginner) feel proud for achieving this print quality after having quite some adhesion, offset and other small issues before. Makes me happy and gives some positivity to keep on going with the hobby 😊" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Itz_Evolv"> /u/Itz_Evolv </a> <br /

## What could be causing these ugly lines?
 - [https://www.reddit.com/r/3Dprinting/comments/1dtgcmh/what_could_be_causing_these_ugly_lines](https://www.reddit.com/r/3Dprinting/comments/1dtgcmh/what_could_be_causing_these_ugly_lines)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T07:54:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtgcmh/what_could_be_causing_these_ugly_lines/"> <img alt="What could be causing these ugly lines?" src="https://b.thumbs.redditmedia.com/aVvMd0Qp5S7uGxD4hJAJXEiLnC66SPezznp4ATDQW1I.jpg" title="What could be causing these ugly lines?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Defiant_Chain_4043"> /u/Defiant_Chain_4043 </a> <br /> <span><a href="https://www.reddit.com/gallery/1dtgcmh">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtgcmh/what_could_be_causing_these_ugly_lines/">[comments]</a></span> </td></tr></table>

## Demon Blood Sword For Girlfriend
 - [https://www.reddit.com/r/3Dprinting/comments/1dtfrfj/demon_blood_sword_for_girlfriend](https://www.reddit.com/r/3Dprinting/comments/1dtfrfj/demon_blood_sword_for_girlfriend)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T07:12:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtfrfj/demon_blood_sword_for_girlfriend/"> <img alt="Demon Blood Sword For Girlfriend" src="https://preview.redd.it/lzma0zhp22ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0e1a029efa9844e050bfa86499b99967e5ed7272" title="Demon Blood Sword For Girlfriend" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Made this multi piece demon blood sword for my girlfriend. That weird layer in between is from me slowing it down at night because it was too loud.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BigFish565"> /u/BigFish565 </a> <br /> <span><a href="https://i.redd.it/lzma0zhp22ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtfrfj/demon_blood_sword_for_girlfriend/">[comments]</a></span> </td></tr></table>

## Refill shutter box
 - [https://www.reddit.com/r/3Dprinting/comments/1dtfnw6/refill_shutter_box](https://www.reddit.com/r/3Dprinting/comments/1dtfnw6/refill_shutter_box)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T07:06:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtfnw6/refill_shutter_box/"> <img alt="Refill shutter box" src="https://external-preview.redd.it/a21idGJ3MGcxMmFkMSFM6UVsd2Bgi6jZ4U7_sthyNfSxqH6Q5gwKuuh-RNwd.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=5d74c50b3b3386c976f6af458b49ab8ec1cf0ddc" title="Refill shutter box" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/throwaway21316"> /u/throwaway21316 </a> <br /> <span><a href="https://v.redd.it/nz2j9v0g12ad1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtfnw6/refill_shutter_box/">[comments]</a></span> </td></tr></table>

## Designed and printed a light hanger for my 20-gallon aquarium
 - [https://www.reddit.com/r/3Dprinting/comments/1dtds3j/designed_and_printed_a_light_hanger_for_my](https://www.reddit.com/r/3Dprinting/comments/1dtds3j/designed_and_printed_a_light_hanger_for_my)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T05:02:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtds3j/designed_and_printed_a_light_hanger_for_my/"> <img alt="Designed and printed a light hanger for my 20-gallon aquarium" src="https://b.thumbs.redditmedia.com/L2Hut6Y1xkBuDDbWhjjazH2tqQVEgUkFNmBeBsho6Ng.jpg" title="Designed and printed a light hanger for my 20-gallon aquarium" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I'm planning to set up a 20-gallon planted aquarium. I really wanted this particular brand of LED lights, but they didn't make legs that extended far enough to sit on the rim of the aquarium, so I came up with my own solution using Autodesk Fusion.</p> <p><a href="https://preview.redd.it/vl1mb3hce1ad1.jpg?width=1200&amp;format=pjpg&amp;auto=webp&amp;s=a77bb05a9f8116f58cb6b614c7fbd7118e95ff68">https://preview.redd.it/vl1mb3hce1ad1.jpg?width=1200&amp;format=pjpg&amp;auto=webp&amp;s=a77bb05a9f8116f58cb6b614c7fbd7118e95ff68</a></p> <p>I utilized 1/2-inch aluminum tubing for the frame compo

## Finally finished
 - [https://www.reddit.com/r/3Dprinting/comments/1dtdqg0/finally_finished](https://www.reddit.com/r/3Dprinting/comments/1dtdqg0/finally_finished)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T04:59:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtdqg0/finally_finished/"> <img alt="Finally finished" src="https://b.thumbs.redditmedia.com/RN4eUK4NbF-lh_-VgwuM3oU8xvQHHGUvG9LcsTJT41s.jpg" title="Finally finished" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>First figurine print and paint. Not bad for ender 3 pro</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Much_Net1713"> /u/Much_Net1713 </a> <br /> <span><a href="https://www.reddit.com/gallery/1dtdqg0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtdqg0/finally_finished/">[comments]</a></span> </td></tr></table>

## To count my bathroom visits
 - [https://www.reddit.com/r/3Dprinting/comments/1dtdkvz/to_count_my_bathroom_visits](https://www.reddit.com/r/3Dprinting/comments/1dtdkvz/to_count_my_bathroom_visits)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T04:49:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtdkvz/to_count_my_bathroom_visits/"> <img alt="To count my bathroom visits" src="https://external-preview.redd.it/YWN4cDZiazJkMWFkMSIu9HLL8AjYKFANb5f-pnjr_4I4swqI9XkLsdA6cRUP.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=7f1dfd82bd0afd0af5ae741d31058608089c6378" title="To count my bathroom visits" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Cube004"> /u/Cube004 </a> <br /> <span><a href="https://v.redd.it/i42x6fk2d1ad1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtdkvz/to_count_my_bathroom_visits/">[comments]</a></span> </td></tr></table>

## Mecha Kong
 - [https://www.reddit.com/r/3Dprinting/comments/1dtbvdj/mecha_kong](https://www.reddit.com/r/3Dprinting/comments/1dtbvdj/mecha_kong)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T03:13:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtbvdj/mecha_kong/"> <img alt="Mecha Kong" src="https://b.thumbs.redditmedia.com/jvW_UCR0JJcv6hU6UeVgRzEND-ZmfsKV__WdrCtjrZI.jpg" title="Mecha Kong" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>175% 3.2kg Approx. 430 hours print time Printer - Ender 3 Elegoo(black), Polymaker(Grey), Esun(Sprayed gold) Model by: <a href="https://www.toymakr3d.com/">https://www.toymakr3d.com/</a></p> <p>Still need to print the axe and the stand and will probably detail it + clear coat for protection 🤓</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Beneficial-Emu3764"> /u/Beneficial-Emu3764 </a> <br /> <span><a href="https://www.reddit.com/gallery/1dtbvdj">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtbvdj/mecha_kong/">[comments]</a></span> </td></tr></table>

## Working prototype of inner ear vestibular canals illuminating based on plane of rotation
 - [https://www.reddit.com/r/3Dprinting/comments/1dtb6p0/working_prototype_of_inner_ear_vestibular_canals](https://www.reddit.com/r/3Dprinting/comments/1dtb6p0/working_prototype_of_inner_ear_vestibular_canals)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T02:37:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtb6p0/working_prototype_of_inner_ear_vestibular_canals/"> <img alt="Working prototype of inner ear vestibular canals illuminating based on plane of rotation" src="https://external-preview.redd.it/bnY2azBhcWpwMGFkMRvB9sqSjvsf72cWXLUbF_pwX-9KBO1TTsz8BHFQVe89.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=a0794ac64f94c7006dfa83eb6782f6b1e6f7e3b6" title="Working prototype of inner ear vestibular canals illuminating based on plane of rotation" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This is the calibration routine to assign each LED string to a specific plane of rotation. This simulates how the cupulas of the inner ear work to detect angular rotations of the head on an X, Y, Z plane. The end product will be for clinician and patient education. Inside the model is an Arduino Nano BLE and the lights are the Adafruit Noods. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/u

## Got a new 3D printer, so I turned the old one into a plotter!
 - [https://www.reddit.com/r/3Dprinting/comments/1dtanwp/got_a_new_3d_printer_so_i_turned_the_old_one_into](https://www.reddit.com/r/3Dprinting/comments/1dtanwp/got_a_new_3d_printer_so_i_turned_the_old_one_into)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T02:09:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dtanwp/got_a_new_3d_printer_so_i_turned_the_old_one_into/"> <img alt="Got a new 3D printer, so I turned the old one into a plotter!" src="https://preview.redd.it/0tvwb9jok0ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=25cd13c8dd3e472679cccea6169a325de443c3ea" title="Got a new 3D printer, so I turned the old one into a plotter!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/8v9"> /u/8v9 </a> <br /> <span><a href="https://i.redd.it/0tvwb9jok0ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dtanwp/got_a_new_3d_printer_so_i_turned_the_old_one_into/">[comments]</a></span> </td></tr></table>

## Alright, took me a bit but I made some more custom leveling cards
 - [https://www.reddit.com/r/3Dprinting/comments/1dt9peo/alright_took_me_a_bit_but_i_made_some_more_custom](https://www.reddit.com/r/3Dprinting/comments/1dt9peo/alright_took_me_a_bit_but_i_made_some_more_custom)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T01:22:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dt9peo/alright_took_me_a_bit_but_i_made_some_more_custom/"> <img alt="Alright, took me a bit but I made some more custom leveling cards" src="https://b.thumbs.redditmedia.com/wSqg3SfiyO1mvlbM6GyrMfHFJEvxSBHQClzTjraDNsg.jpg" title="Alright, took me a bit but I made some more custom leveling cards" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BruceCambell"> /u/BruceCambell </a> <br /> <span><a href="https://www.reddit.com/gallery/1dt9peo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dt9peo/alright_took_me_a_bit_but_i_made_some_more_custom/">[comments]</a></span> </td></tr></table>

## It's a CaliperClock...
 - [https://www.reddit.com/r/3Dprinting/comments/1dt91te/its_a_caliperclock](https://www.reddit.com/r/3Dprinting/comments/1dt91te/its_a_caliperclock)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T00:49:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dt91te/its_a_caliperclock/"> <img alt="It's a CaliperClock..." src="https://b.thumbs.redditmedia.com/RrfCchucOgcRDjEi4Lpfh3wVZjwZB3MPQyuK0vXalAo.jpg" title="It's a CaliperClock..." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HeptaRich"> /u/HeptaRich </a> <br /> <span><a href="https://www.reddit.com/gallery/1dt91te">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dt91te/its_a_caliperclock/">[comments]</a></span> </td></tr></table>

## My first multiple piece project!!
 - [https://www.reddit.com/r/3Dprinting/comments/1dt8vs9/my_first_multiple_piece_project](https://www.reddit.com/r/3Dprinting/comments/1dt8vs9/my_first_multiple_piece_project)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T00:41:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dt8vs9/my_first_multiple_piece_project/"> <img alt="My first multiple piece project!!" src="https://preview.redd.it/femzf1du40ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8e0be9ce37782c85c8205619a12a1ac10690c464" title="My first multiple piece project!!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MCSteve_wHorse"> /u/MCSteve_wHorse </a> <br /> <span><a href="https://i.redd.it/femzf1du40ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dt8vs9/my_first_multiple_piece_project/">[comments]</a></span> </td></tr></table>

## Welp, here goes nothin
 - [https://www.reddit.com/r/3Dprinting/comments/1dt8cg2/welp_here_goes_nothin](https://www.reddit.com/r/3Dprinting/comments/1dt8cg2/welp_here_goes_nothin)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T00:14:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dt8cg2/welp_here_goes_nothin/"> <img alt="Welp, here goes nothin" src="https://a.thumbs.redditmedia.com/ENASLiSV1RGa-_7oSCdVz9ysIW2wc9Vwl2WV-bDviU8.jpg" title="Welp, here goes nothin" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>0.1mm layer lines with normals supports on a 310x310mm build plate. I'll probably crank up the speed after the first layer or two.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ProdigalSun92"> /u/ProdigalSun92 </a> <br /> <span><a href="https://www.reddit.com/gallery/1dt8cg2">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dt8cg2/welp_here_goes_nothin/">[comments]</a></span> </td></tr></table>

## Isn't HueForge just regular printing but with extra steps?
 - [https://www.reddit.com/r/3Dprinting/comments/1dt84r1/isnt_hueforge_just_regular_printing_but_with](https://www.reddit.com/r/3Dprinting/comments/1dt84r1/isnt_hueforge_just_regular_printing_but_with)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-07-02T00:04:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1dt84r1/isnt_hueforge_just_regular_printing_but_with/"> <img alt="Isn't HueForge just regular printing but with extra steps?" src="https://preview.redd.it/qxmnmbwayz9d1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=3d03a07c5eafa9d8cd25a5772ca05df2b0ca851a" title="Isn't HueForge just regular printing but with extra steps?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/OceanGlider_"> /u/OceanGlider_ </a> <br /> <span><a href="https://i.redd.it/qxmnmbwayz9d1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1dt84r1/isnt_hueforge_just_regular_printing_but_with/">[comments]</a></span> </td></tr></table>

