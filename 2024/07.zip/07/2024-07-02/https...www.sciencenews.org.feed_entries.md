# Source:Science News, URL:https://www.sciencenews.org/feed, language:en-US

## Why this year’s climate conditions helped Hurricane Beryl smash records
 - [https://www.sciencenews.org/article/hurricane-beryl-climate-records](https://www.sciencenews.org/article/hurricane-beryl-climate-records)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-07-02T21:47:23+00:00

Though scientists predicted an active hurricane season, the swiftness of Beryl’s intensification is surprising.

## A bizarre video of eyeballs confirms our pupils shrink with age
 - [https://www.sciencenews.org/article/bizarre-video-eyeballs-age-pupils-size](https://www.sciencenews.org/article/bizarre-video-eyeballs-age-pupils-size)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-07-02T15:15:00+00:00

Pupil size can decrease up to 0.4 millimeters per decade, hinting at why it can be increasingly harder for people to see in dim light as they age.

## This 3-D printer can fit in the palm of your hand
 - [https://www.sciencenews.org/article/3-d-printer-palm-hand](https://www.sciencenews.org/article/3-d-printer-palm-hand)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-07-02T13:15:00+00:00

Researchers developed a chip-based device for 3-D printing objects on the go.

