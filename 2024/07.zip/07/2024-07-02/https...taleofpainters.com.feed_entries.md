# Source:Tale of Painters, URL:https://taleofpainters.com/feed, language:en-GB

## Showcase: Sisters of Battle Tariana Palos (inc. tutorial)
 - [https://taleofpainters.com/2024/07/showcase-sisters-of-battle-tariana-palos-inc-tutorial](https://taleofpainters.com/2024/07/showcase-sisters-of-battle-tariana-palos-inc-tutorial)
 - RSS feed: https://taleofpainters.com/feed
 - date published: 2024-07-02T16:00:00+00:00

<p>n my showcase post today, I&#8217;m presenting my version of Sister Tariana Palos. Painted in the golden armour of The Order of the Golden Light, she is one of my favourite models from the Adepta Sororitas range. Click here for more pictures, a 360-degree view,...</p>
<p>The post <a href="https://taleofpainters.com/2024/07/showcase-sisters-of-battle-tariana-palos-inc-tutorial/">Showcase: Sisters of Battle Tariana Palos (inc. tutorial)</a> appeared first on <a href="https://taleofpainters.com">Tale of Painters</a>.</p>

