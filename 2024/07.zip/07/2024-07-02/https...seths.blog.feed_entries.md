# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Plasticity
 - [https://seths.blog/2024/07/plasticity-3](https://seths.blog/2024/07/plasticity-3)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-07-02T08:25:00+00:00

It&#8217;s pretty easy for some kids to switch gears. They can go from sad to ebullient in seconds, and switch contexts without much fuss. Others have more trouble. As we get older, our natural ability to thrive in a new situation can decrease. But, like a muscle or a skill, it responds to practice. The [&#8230;]

