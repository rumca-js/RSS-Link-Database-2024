# Source:Home RenoVision DIY, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnorhjQR4zJkT7AVNhu395Q, language:en

## Chimney Demolition LIVESTREAM
 - [https://www.youtube.com/watch?v=0zsQKYAB3yQ](https://www.youtube.com/watch?v=0zsQKYAB3yQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnorhjQR4zJkT7AVNhu395Q
 - date published: 2024-07-02T18:09:39+00:00

I bought a new house! And I’m tearing it apart. That’s right, I’m bringing this 1974 home back to the studs and completely reconfiguring the space. I’ve missed renovating this way. 

This series will be a comprehensive guide for homeowners and DIYers, offering a rare, behind-the-scenes real life look at every step of the renovation processes from the initial demolition to the final reveal. 

I’m doing something different this time around. I want you all to be part of the action so for this project not only will I be filming tutorials for our channel but we will be live streaming it too. 

Do you need help with your renovation project? 👆🏼Hit the JOIN button to access the members only Discord
🔨Consult directly with Jeff about your project 
🔨Crowdsource information on the best products and materials
🔨Post your incredible before and after’s
🔨Meet other DIYers

Once you've hit JOIN, go to the members tab to find the link to join the members only Discord 👇🏼
https://www.youtube.com/@HomeReno

