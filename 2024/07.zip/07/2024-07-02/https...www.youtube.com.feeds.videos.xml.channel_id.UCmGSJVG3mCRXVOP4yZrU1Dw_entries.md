# Source:John Harris, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw, language:en-US

## Searching for bones in Okinawa's caves
 - [https://www.youtube.com/watch?v=QnYD3dTbqXY](https://www.youtube.com/watch?v=QnYD3dTbqXY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmGSJVG3mCRXVOP4yZrU1Dw
 - date published: 2024-07-02T13:00:25+00:00

This man is hunting for the bones of those lost in WWII.

Check out my new channel with Sam Ellis - Search Party: https://youtube.com/@Search-Party

Get access to behind-the-scenes vlogs, my scripts, and extended interviews over at https://www.patreon.com/johnnyharris

Do you have an insider tip or unique information on a story? Do you have a suggestion for a story you want us to cover? Submit to the Tip Line: https://docs.google.com/forms/d/e/1FAIpQLSdpNs1ykIwd7KNkwntN897X_SX9hJ8WiTH_erlLU_bQp2GGLg/viewform?usp=sharing

I made a poster about maps - check it out: https://store.dftba.com/products/all-maps-are-wrong-poster

Custom Presets & LUTs [what we use]: https://store.dftba.com/products/johnny-iz-luts-and-presets

Watch my videos ad-free on Nebula: https://nebula.tv/johnnyharris

About: 
Johnny Harris is an Emmy-winning independent journalist and contributor to the New York Times. Based in Washington, DC, Harris reports on interesting trends and stories domestically and around the

