# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Turcja oszalała ze szczęścia. Obrońca bohaterem
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/austria-turcja-wynik-i-relacja-z-meczu-1-8-finalu_sto10219352/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/austria-turcja-wynik-i-relacja-z-meczu-1-8-finalu_sto10219352/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T20:54:15+00:00

<img alt="Turcja oszalała ze szczęścia. Obrońca bohaterem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8727323-demiral-bohaterem-turcji/alternates/LANDSCAPE_1280" />
    Jest ostatni ćwierćfinalista mistrzostw Europy.

## Mecze Polek w Wimbledonie przełożone
 - [https://eurosport.tvn24.pl/tenis/magda-linette-i-magdalena-frech-zagraja-w-srode-na-wimbledonie_sto10219357/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/magda-linette-i-magdalena-frech-zagraja-w-srode-na-wimbledonie_sto10219357/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T20:31:19+00:00

<img alt="Mecze Polek w Wimbledonie przełożone" src="https://tvn24.pl/najnowsze/cdn-zdjecie-382596-magda-linette-ph7977120/alternates/LANDSCAPE_1280" />
    Kiedy zagrają Linette i Fręch?

## Kompletne zaskoczenie. Błyskawiczny gol w meczu Euro
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-szybki-gol-w-meczu-austria-turcja_sto10219377/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-szybki-gol-w-meczu-austria-turcja_sto10219377/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T19:49:00+00:00

<img alt="Kompletne zaskoczenie. Błyskawiczny gol w meczu Euro" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1896534-merih-demiral-trafil-w-meczu-austria-turcja-na-euro-2024/alternates/LANDSCAPE_1280" />
    Takiego początku nikt się nie spodziewał.

## Wysoka wygrana w Eurojackpot w Polsce
 - [https://tvn24.pl/biznes/z-kraju/wyniki-eurojackpot-z2-lipca-2024-jakie-liczby-padly-podczas-ostatniego-losowania-duza-wygrana-w-polsce-st7988473?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-eurojackpot-z2-lipca-2024-jakie-liczby-padly-podczas-ostatniego-losowania-duza-wygrana-w-polsce-st7988473?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T19:37:36+00:00

<img alt="Wysoka wygrana w Eurojackpot w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b7a3hv-eurojackpot-shutterstock1603798027-5772919/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## Piąta próba sił w Małopolsce. Kmita z PiS i kontrkandydat z PiS
 - [https://tvn24.pl/polska/malopolska-klincz-przy-wyborze-marszalka-wojewodztwa-piata-proba-st7988230?source=rss](https://tvn24.pl/polska/malopolska-klincz-przy-wyborze-marszalka-wojewodztwa-piata-proba-st7988230?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T18:41:24+00:00

<img alt="Piąta próba sił w Małopolsce. Kmita z PiS i kontrkandydat z PiS" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2101538-kmita-malopolska-sejmik-ph7988256/alternates/LANDSCAPE_1280" />
    W grze pozostaje dwóch kandydatów PiS.

## Przerwa za przerwą i trzy zawieszenia w PiS-ie. Piąta próba sił w Małopolsce
 - [https://tvn24.pl/polska/malopolska-klincz-przy-wyborze-marszalka-wojewodztwa-we-wtorek-piata-proba-st7988230?source=rss](https://tvn24.pl/polska/malopolska-klincz-przy-wyborze-marszalka-wojewodztwa-we-wtorek-piata-proba-st7988230?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T18:41:24+00:00

<img alt="Przerwa za przerwą i trzy zawieszenia w PiS-ie. Piąta próba sił w Małopolsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2101538-kmita-malopolska-sejmik-ph7988256/alternates/LANDSCAPE_1280" />
    Niebawem głosowanie. Czy uda się przerwać klincz?

## Cztery leje kondensacyjne na niebie
 - [https://tvn24.pl/tvnmeteo/polska/cztery-leje-kondensacyjne-na-niebie-st7988364?source=rss](https://tvn24.pl/tvnmeteo/polska/cztery-leje-kondensacyjne-na-niebie-st7988364?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T18:36:55+00:00

<img alt="Cztery leje kondensacyjne na niebie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-7348551-cztery-leje-kondensacyjne-ph7988361/alternates/LANDSCAPE_1280" />
    Uchwycone w Krynicy Morskiej.

## Turcja chce wyrównać rachunki z Austrią
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/live-austria-turcja_mtc1427039/live-commentary.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/live-austria-turcja_mtc1427039/live-commentary.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T18:35:14+00:00

<img alt="Turcja chce wyrównać rachunki z Austrią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7696855-marcel-sabitzer-austria-ph7988400/alternates/LANDSCAPE_1280" />
    Walka o ostatnie miejsce w ćwierćfinale Euro 2024.

## "Tu nie ma miejsca, by wolno wchodzić w turniej"
 - [https://eurosport.tvn24.pl/tenis/wimbledon/2024/iga-swiatek-sofia-kenin-swiatek-po-meczu-1.-rundy-wimbledonu_sto10219270/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon/2024/iga-swiatek-sofia-kenin-swiatek-po-meczu-1.-rundy-wimbledonu_sto10219270/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T18:15:42+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8259812-iga-swiatek-juz-w-drugiej-rundzie-wimbledonu/alternates/LANDSCAPE_1280" />
    Iga Świątek po meczu Wimbledonu.

## Wygrana Świątek w Wimbledonie
 - [https://eurosport.tvn24.pl/tenis/wimbledon/2024/iga-swiatek-sofia-kenin-wynik-i-relacja-z-meczu-1.-rundy-wimbledonu-2024_sto10219009/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon/2024/iga-swiatek-sofia-kenin-wynik-i-relacja-z-meczu-1.-rundy-wimbledonu-2024_sto10219009/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T17:29:54+00:00

<img alt="Wygrana Świątek w Wimbledonie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6066808-iga-swiatek-wimbledon-ph7988325/alternates/LANDSCAPE_1280" />
    Pierwszy mecz Wimbledonu za nią.

## Pasażerowie odlatują bez walizek. Potężne utrudnienia na lotnisku
 - [https://tvn24.pl/biznes/ze-swiata/czechy-problemy-z-odprawa-bagazu-na-praskim-lotnisku-im-vaclava-havla-st7988290?source=rss](https://tvn24.pl/biznes/ze-swiata/czechy-problemy-z-odprawa-bagazu-na-praskim-lotnisku-im-vaclava-havla-st7988290?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T17:27:03+00:00

<img alt="Pasażerowie odlatują bez walizek. Potężne utrudnienia na lotnisku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6405077-shutterstock2440277555-ph7988335/alternates/LANDSCAPE_1280" />
    W Pradze.

## Holandia dominuje w meczu o ćwierćfinał Euro
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/live-rumunia-holandia_mtc1427037/live-commentary.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/live-rumunia-holandia_mtc1427037/live-commentary.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T16:46:00+00:00

<img alt="Holandia dominuje w meczu o ćwierćfinał Euro" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8496261-rumunia-holandia-na-euro-ph7988283/alternates/LANDSCAPE_1280" />
    Relacja na żywo i wynik meczu.

## Świątek bliżej awansu do kolejnej rundy Wimbledonu
 - [https://eurosport.tvn24.pl/tenis/wimbledon-gra-pojedyncza-kobiet/2024/live-iga-swiatek-sofia-kenin_mtc1497062/live-commentary.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon-gra-pojedyncza-kobiet/2024/live-iga-swiatek-sofia-kenin_mtc1497062/live-commentary.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T16:45:00+00:00

<img alt="Świątek bliżej awansu do kolejnej rundy Wimbledonu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1900987-iga-swiatek-gra-pierwszy-mecz-w-wimbledonie-ph7988279/alternates/LANDSCAPE_1280" />
    Relacja na żywo z meczu Polki w Wimbledonie.

## Kto mógłby zastąpić Bidena? "Ona jest gotowa"
 - [https://tvn24.pl/swiat/wybory-prezydenckie-w-usa-kto-moglby-zastapic-bidena-st7988262?source=rss](https://tvn24.pl/swiat/wybory-prezydenckie-w-usa-kto-moglby-zastapic-bidena-st7988262?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T16:41:14+00:00

<img alt="Kto mógłby zastąpić Bidena? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2209763-pap20240616270-ph7988254/alternates/LANDSCAPE_1280" />
    Ocenia "Wall Street Journal".

## Były mistrz świata nie żyje. Dwa tygodnie temu zgłoszono jego zaginięcie
 - [https://eurosport.tvn24.pl/lekkoatletyka/nie-zyje-jacques-freitag.-byly-mistrz-swiata-w-skoku-wzwyz-mial-42-lata_sto10218995/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/nie-zyje-jacques-freitag.-byly-mistrz-swiata-w-skoku-wzwyz-mial-42-lata_sto10218995/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T16:14:00+00:00

<img alt="Były mistrz świata nie żyje. Dwa tygodnie temu zgłoszono jego zaginięcie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2068950-jacques-freitag/alternates/LANDSCAPE_1280" />
    Został znaleziony martwy.

## Mark Brzezinski: chcemy, żeby Polska rozwijała się, kwitła, była pełna dobrobytu
 - [https://tvn24.pl/polska/mark-brzezinski-chcemy-zeby-polska-rozwijala-sie-kwitla-byla-pelna-dobrobytu-st7988157?source=rss](https://tvn24.pl/polska/mark-brzezinski-chcemy-zeby-polska-rozwijala-sie-kwitla-byla-pelna-dobrobytu-st7988157?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T15:21:01+00:00

<img alt="Mark Brzezinski: chcemy, żeby Polska rozwijała się, kwitła, była pełna dobrobytu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9997332-mark-brzezinski-ph7988154/alternates/LANDSCAPE_1280" />
    Ambasador USA w Polsce Mark Brzezinski w rozmowie z TVN24 BiS.

## Obrończyni tytułu wyrzucona z Wimbledonu. Pierwsza taka sytuacja od 30 lat
 - [https://eurosport.tvn24.pl/tenis/wimbledon/2024/jessica-bouzas-maneiro-marketa-vondrousova-wynik-i-relacja-z-meczu-1.-rundy_sto10218743/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon/2024/jessica-bouzas-maneiro-marketa-vondrousova-wynik-i-relacja-z-meczu-1.-rundy_sto10218743/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T14:28:18+00:00

<img alt="Obrończyni tytułu wyrzucona z Wimbledonu. Pierwsza taka sytuacja od 30 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4001320-marketa-vondrousova-odpadla-z-wimbledonu/alternates/LANDSCAPE_1280" />
    Błyskawiczny koniec.

## "Beetlejuice Beetlejuice" Tima Burtona otworzy festiwal w Wenecji
 - [https://tvn24.pl/kultura-i-styl/mff-w-wenecji-2024-beetlejuice-beetlejuice-tima-burtona-otworzy-81-edycje-festiwalu-zwiastun-zdjecia-st7987868?source=rss](https://tvn24.pl/kultura-i-styl/mff-w-wenecji-2024-beetlejuice-beetlejuice-tima-burtona-otworzy-81-edycje-festiwalu-zwiastun-zdjecia-st7987868?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T13:20:52+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7180611-catherine-ohara-jenna-ortega-winona-ryder-i-justin-theroux-w-beetlejuice-beetlejuice-tima-burtona-ph7987912/alternates/LANDSCAPE_1280" />
    Światowa premiera 28 sierpnia.

## Kula ognia rozświetliła nocne niebo. Co przeleciało nad Polską
 - [https://tvn24.pl/tvnmeteo/polska/kula-ognia-rozswietlila-nocne-niebo-co-przelecialo-nad-polska-wideo-st7987885?source=rss](https://tvn24.pl/tvnmeteo/polska/kula-ognia-rozswietlila-nocne-niebo-co-przelecialo-nad-polska-wideo-st7987885?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T13:16:44+00:00

<img alt="Kula ognia rozświetliła nocne niebo. Co przeleciało nad Polską" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6131756-bolid-ph7988034/alternates/LANDSCAPE_1280" />
    Nagranie.

## Wimbledon kłopotliwy dla Świątek. "Najpierw będzie musiała się nasycić"
 - [https://eurosport.tvn24.pl/tenis/wimbledon/2024/wimbledon-klopotliwy-dla-igi-swiatek.-najpierw-bedzie-musiala-sie-nasycic_sto10218615/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon/2024/wimbledon-klopotliwy-dla-igi-swiatek.-najpierw-bedzie-musiala-sie-nasycic_sto10218615/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T12:55:00+00:00

<img alt="Wimbledon kłopotliwy dla Świątek. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7900907-iga-swiatek-a-wimbledon-2023-ph7959908/alternates/LANDSCAPE_1280" />
    Iga Świątek zaczyna specyficzny turniej.

## Ojciec byłego premiera: to prawda, że lot odwołano przeze mnie
 - [https://tvn24.pl/swiat/wielka-brytania-klopoty-stanleya-johnsona-na-lotnisku-w-londynie-odwolany-lot-st7987530?source=rss](https://tvn24.pl/swiat/wielka-brytania-klopoty-stanleya-johnsona-na-lotnisku-w-londynie-odwolany-lot-st7987530?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T12:11:26+00:00

<img alt="Ojciec byłego premiera: to prawda, że lot odwołano przeze mnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3039045-stanley-johnson-ph7987726/alternates/LANDSCAPE_1280" />
    Kłopoty na lotnisku w Londynie.

## Kontrola wykazała, że kierownik obozu harcerskiego był nietrzeźwy
 - [https://tvn24.pl/olsztyn/pisz-nietrzezwy-kierownik-obozu-opiekowal-sie-58-dziecmi-st7987866?source=rss](https://tvn24.pl/olsztyn/pisz-nietrzezwy-kierownik-obozu-opiekowal-sie-58-dziecmi-st7987866?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T12:06:00+00:00

<img alt="Kontrola wykazała, że kierownik obozu harcerskiego był nietrzeźwy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-531023-kontrola-obozu-w-piszu-ph7987822/alternates/LANDSCAPE_1280" />
    Służby sprawdzą, czy nie doszło do zagrożenia życia i zdrowia dzieci.

## Gest Anglika pod lupą. Grozi mu surowa kara
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/dochodzenie-uefa-w-sprawie-jude-a-bellinghama-po-meczu-anglia-slowacja.-euro-2024_sto10218053/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/dochodzenie-uefa-w-sprawie-jude-a-bellinghama-po-meczu-anglia-slowacja.-euro-2024_sto10218053/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T11:45:06+00:00

<img alt="Gest Anglika pod lupą. Grozi mu surowa kara" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3269091-jude-bellingham-z-lewej-i-harry-kane-w-meczu-anglia-slowacja/alternates/LANDSCAPE_1280" />
    Anglicy mają powody do niepokoju przed ćwierćfinałem Euro 2024.

## Hurkacz zawodzi. Przegrał pierwszego seta
 - [https://eurosport.tvn24.pl/tenis/wimbledon/2024/wimbledon-2024.-hubert-hurkacz-radu-albot-wynik-na-zywo-i-relacja-live-tenis_sto10218455/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon/2024/wimbledon-2024.-hubert-hurkacz-radu-albot-wynik-na-zywo-i-relacja-live-tenis_sto10218455/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T11:14:00+00:00

<img alt="Hurkacz zawodzi. Przegrał pierwszego seta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1143229-hubert-hurkacz/alternates/LANDSCAPE_1280" />
    Hubert Hurkacz - Radu Albot w pierwszej rundzie Wimbledonu. Relacja i wynik na żywo w eurosport.pl.

## Godziny meczów polskich siatkarzy na igrzyskach
 - [https://eurosport.tvn24.pl/siatkowka/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-kiedy-mecze-polskich-siatkarzy-terminarz_sto20014817/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-kiedy-mecze-polskich-siatkarzy-terminarz_sto20014817/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T11:08:42+00:00

<img alt="Godziny meczów polskich siatkarzy na igrzyskach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-733524-leon-w-akcji-w-meczu-z-brazylia/alternates/LANDSCAPE_1280" />
    Reprezentacje Egiptu, Brazylii i Włoch będą grupowymi rywalami Polaków w Paryżu.

## Seria utonięć na popularnej wyspie. Dwóch Polaków nie żyje
 - [https://tvn24.pl/swiat/grecja-seria-utoniec-na-krecie-dwoch-polakow-nie-zyje-st7987397?source=rss](https://tvn24.pl/swiat/grecja-seria-utoniec-na-krecie-dwoch-polakow-nie-zyje-st7987397?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T10:00:18+00:00

<img alt="Seria utonięć na popularnej wyspie. Dwóch Polaków nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-407935-ratownik-na-plazy-na-krecie-grecja-shutterstock1160436787-ph7987405/alternates/LANDSCAPE_1280" />
    Informują lokalne media.

## Ronaldo dostało się za łzy. "Żenujące"
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-dietmar-hamann-skrytykowal-postawe-cristiano-ronaldo-podczas-meczu-portugalia-slowenia_sto10218439/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-dietmar-hamann-skrytykowal-postawe-cristiano-ronaldo-podczas-meczu-portugalia-slowenia_sto10218439/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T09:24:23+00:00

<img alt="Ronaldo dostało się za łzy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2312607-smutny-cristiano-ronaldo-pocieszali-go-koledzy-z-druzyny/alternates/LANDSCAPE_1280" />
    Portugalczyk nie wytrzymał po zmarnowanym rzucie karnym przeciwko Słowenii na Euro 2024.

## "Chcą nam odebrać wolność"
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-jules-kounde-obronca-kadry-francji-skomentowal-wyniki-pierwszej-tury-wyborow-parlamentarn_sto10218374/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-jules-kounde-obronca-kadry-francji-skomentowal-wyniki-pierwszej-tury-wyborow-parlamentarn_sto10218374/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T08:58:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9137125-jules-kounde-w-barwach-reprezentacji-francji-podczas-euro-2024/alternates/LANDSCAPE_1280" />
    Kolejny polityczny apel piłkarza.

## Tych krajów nie wybieraj na wakacje. MSZ ostrzega turystów
 - [https://tvn24.pl/biznes/najnowsze/wakacje-2024-msz-opublikowalo-liste-niebezpiecznych-krajow-st7986763?source=rss](https://tvn24.pl/biznes/najnowsze/wakacje-2024-msz-opublikowalo-liste-niebezpiecznych-krajow-st7986763?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T08:55:25+00:00

<img alt="Tych krajów nie wybieraj na wakacje. MSZ ostrzega turystów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6fltl2-samolot-pasazerski-shutterstock_2449126031-ph7928008/alternates/LANDSCAPE_1280" />
    Lista niebezpiecznych państw.

## Odór chemikaliów był trudny do zniesienia
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ursynow-prawie-4-tysiace-porcji-mefedronu-w-wynajmowanym-domu-dwie-osoby-zatrzymane-st7987376?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ursynow-prawie-4-tysiace-porcji-mefedronu-w-wynajmowanym-domu-dwie-osoby-zatrzymane-st7987376?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T08:49:50+00:00

<img alt="Odór chemikaliów był trudny do zniesienia" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-7247759-policjanci-zlikwidowali-wytwornie-mefedronu-ph7987439/alternates/LANDSCAPE_1280" />
    Prawie cztery tysiące porcji mefedronu w wynajmowanym domu.

## Rozłam wśród Rosjan w sprawie igrzysk
 - [https://eurosport.tvn24.pl/tenis/igrzyska-olimpijskie-paryz-2024/2024/rozlam-wsrod-rosjan-w-sprawie-igrzysk-olimpijskich-w-paryzu_sto20014752/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/igrzyska-olimpijskie-paryz-2024/2024/rozlam-wsrod-rosjan-w-sprawie-igrzysk-olimpijskich-w-paryzu_sto20014752/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T08:41:22+00:00

<img alt="Rozłam wśród Rosjan w sprawie igrzysk" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7459919-daniil-medvedev/alternates/LANDSCAPE_1280" />
    Wystąpi Daniił Miedwiediew, ale zabraknie Andrieja Rublowa.

## Odpadli z Euro 2024, są bohaterami. "Głowa do góry!"
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-slowenskie-media-o-odpadnieciu-reprezentacji-w-1-8-finalu_sto10218410/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-slowenskie-media-o-odpadnieciu-reprezentacji-w-1-8-finalu_sto10218410/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T07:58:37+00:00

<img alt="Odpadli z Euro 2024, są bohaterami. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7367719-slowenscy-pilkarze-odpadli-z-euro-2024/alternates/LANDSCAPE_1280" />
    Słoweńscy piłkarze dzielnie walczyli, ale pożegnali się z turniejem po porażce w rzutach karnych z Portugalią.

## Były wybuchy i płomienie, są ciężko ranni. Pierwsze ustalenia prokuratury
 - [https://tvn24.pl/lodz/wola-laska-pozar-zaklad-skladowiska-odpadow-sa-ciezko-ranni-prokuratura-o-przyczynach-st7987332?source=rss](https://tvn24.pl/lodz/wola-laska-pozar-zaklad-skladowiska-odpadow-sa-ciezko-ranni-prokuratura-o-przyczynach-st7987332?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T07:46:48+00:00

<img alt="Były wybuchy i płomienie, są ciężko ranni. Pierwsze ustalenia prokuratury" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7774507-pozar-skladowiska-w-woli-laskiej-ph7986834/alternates/LANDSCAPE_1280" />
    Bardzo ciężki stan nieznanej kobiety rannej w pożarze składowiska.

## Kupić czy wynająć? Eksperci nie mają wątpliwości, co się bardziej opłaca
 - [https://tvn24.pl/biznes/nieruchomosci/kupic-czy-wynajac-mieszkanie-eksperci-nie-maja-watpliwosci-co-sie-bardziej-oplaca-st7987303?source=rss](https://tvn24.pl/biznes/nieruchomosci/kupic-czy-wynajac-mieszkanie-eksperci-nie-maja-watpliwosci-co-sie-bardziej-oplaca-st7987303?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T07:42:47+00:00

<img alt="Kupić czy wynająć? Eksperci nie mają wątpliwości, co się bardziej opłaca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f149sv-mieszkanie-4771491/alternates/LANDSCAPE_1280" />
    Analiza "Rzeczpospolitej".

## Zdobył mistrzostwo, dostał najwyższy kontrakt w historii
 - [https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/jayson-tatum-z-boston-celtics-z-rekordowym-kontraktem-w-historii-nba_sto10218397/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/jayson-tatum-z-boston-celtics-z-rekordowym-kontraktem-w-historii-nba_sto10218397/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T07:37:02+00:00

<img alt="Zdobył mistrzostwo, dostał najwyższy kontrakt w historii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2468882-jayson-tatum-poprowadzil-celtics-do-mistrzostwa/alternates/LANDSCAPE_1280" />
    Jayson Tatum z Bostonu Celtics z rekordową umową w NBA.

## Skazany za gwałty na dziewczynce wystartuje w igrzyskach
 - [https://eurosport.tvn24.pl/siatkowka-plazowa/igrzyska-olimpijskie-paryz-2024/2024/steven-van-de-velde-holenderski-siatkarz-plazowy-skazany-za-gwalty-wystartuje-w-igrzyskach_sto20014750/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka-plazowa/igrzyska-olimpijskie-paryz-2024/2024/steven-van-de-velde-holenderski-siatkarz-plazowy-skazany-za-gwalty-wystartuje-w-igrzyskach_sto20014750/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T07:09:22+00:00

<img alt="Skazany za gwałty na dziewczynce wystartuje w igrzyskach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7600824-steven-van-de-velde-zdobyl-olimpijska-nominacje/alternates/LANDSCAPE_1280" />
    Steven van de Velde, za którym ciągnie się mroczna przeszłość, będzie reprezentował kraj w najważniejszej sportowej imprezie.

## Legenda kończy karierę. "Trudno uwierzyć"
 - [https://eurosport.tvn24.pl/kolarstwo/peter-sagan-zakonczyl-kariere-kolarska_sto10218109/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/peter-sagan-zakonczyl-kariere-kolarska_sto10218109/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T06:17:27+00:00

<img alt="Legenda kończy karierę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3222349-peter-sagan-ph7789411/alternates/LANDSCAPE_1280" />
    Trzykrotny mistrz świata w kolarstwie Peter Sagan szuka nowego zajęcia.

## Portugalia zmartwiona. "Ogromne cierpienia"
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-portugalskie-media-o-meczu-portugalia-slowenia-w-1-8-finalu_sto10218369/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-portugalskie-media-o-meczu-portugalia-slowenia-w-1-8-finalu_sto10218369/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T05:33:55+00:00

<img alt="Portugalia zmartwiona. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5434822-portugalia-gra-dalej-na-euro-2024-slowenie-wyeliminowala-po-rzutach-karnych/alternates/LANDSCAPE_1280" />
    Portugalskie media z ogromną ulgą przyjęły zwycięstwo swojego zespołu w rzutach karnych w 1/8 finału Euro 2024.

## Ronaldo nagle przerwał wywiad. Później złożył ważną deklarację
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/cristiano-ronaldo-przerwal-wywiad-po-meczu-portugalia-slowenia_sto10218367/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/cristiano-ronaldo-przerwal-wywiad-po-meczu-portugalia-slowenia_sto10218367/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T05:07:23+00:00

<img alt="Ronaldo nagle przerwał wywiad. Później złożył ważną deklarację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6723979-ronaldo-dlugo-nie-mogl-zapanowac-nad-emocjami/alternates/LANDSCAPE_1280" />
    Po bardzo szczęśliwie wygranym meczu ze Słowenią.

## Ostrzeżenia IMGW. W części kraju od rana leje deszcz
 - [https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-przed-burzami-i-ulewami-silny-deszcz-w-czesci-kraju-st7987126?source=rss](https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-przed-burzami-i-ulewami-silny-deszcz-w-czesci-kraju-st7987126?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T04:37:31+00:00

<img alt="Ostrzeżenia IMGW. W części kraju od rana leje deszcz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1gxxnn-deszcz-popada-deszcz-7883941/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie obowiązują alarmy.

## Podwyżka dla trzech milionów Polaków
 - [https://tvn24.pl/biznes/z-kraju/najnizsza-krajowa-2024-wzrost-wynagrodzen-od-1-lipca-st7986815?source=rss](https://tvn24.pl/biznes/z-kraju/najnizsza-krajowa-2024-wzrost-wynagrodzen-od-1-lipca-st7986815?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T04:27:04+00:00

<img alt="Podwyżka dla trzech milionów Polaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7c122o-warszawa-ludzie-ulica-lato-7907832/alternates/LANDSCAPE_1280" />
    Druga w tym roku.

## Rosyjski system rakietowy tuż przy plaży. "Po raz kolejny zagrażają miejscowej ludności"
 - [https://tvn24.pl/swiat/co-sie-wydarzylo-w-ukrainie-st7987121?source=rss](https://tvn24.pl/swiat/co-sie-wydarzylo-w-ukrainie-st7987121?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T04:25:01+00:00

<img alt="Rosyjski system rakietowy tuż przy plaży. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8166506-rosyjski-system-rakietowy-ph7987059/alternates/LANDSCAPE_1280" />
    860 dni temu rozpoczęła się inwazja Rosji na Ukrainę.

## Cztery mecze z udziałem Polaków we wtorek
 - [https://eurosport.tvn24.pl/tenis/wimbledon/2024/hubert-hurkacz-radu-albot.-kiedy-i-o-ktorej-mecz-1.-rundy-wimbledonu-kiedy-graja-swiatek-linette-i-f_sto10217953/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wimbledon/2024/hubert-hurkacz-radu-albot.-kiedy-i-o-ktorej-mecz-1.-rundy-wimbledonu-kiedy-graja-swiatek-linette-i-f_sto10217953/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T04:22:00+00:00

<img alt="Cztery mecze z udziałem Polaków we wtorek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-212836-hubert-hurkacz-zaczyna-gre-na-wimbledonie/alternates/LANDSCAPE_1280" />
    W Wimbledonie.

## Odprawili Polaków i chcą więcej. Dzisiejsze mecze Euro 2024
 - [https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-jakie-mecze-dzisiaj-kto-gra-we-wtorek-2-lipca-2.07-terminarz-i-godziny-meczow_sto10217830/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/euro-2024/2024/euro-2024.-jakie-mecze-dzisiaj-kto-gra-we-wtorek-2-lipca-2.07-terminarz-i-godziny-meczow_sto10217830/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T04:16:10+00:00

<img alt="Odprawili Polaków i chcą więcej. Dzisiejsze mecze Euro 2024" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7997076-euro-2024-jakie-dzisiaj-mecze-kto-gra-we-wtorek-207/alternates/LANDSCAPE_1280" />
    We wtorek kolejne i ostatnie już mecze 1/8 finału.

## Przetestowali nowy pocisk. Może przenieść "ogromną głowicę bojową"
 - [https://tvn24.pl/swiat/korea-polnocna-przeprowadzila-test-nowego-pocisku-balistycznego-pjongjang-przeniosl-ogromna-glowice-bojowa-st7987123?source=rss](https://tvn24.pl/swiat/korea-polnocna-przeprowadzila-test-nowego-pocisku-balistycznego-pjongjang-przeniosl-ogromna-glowice-bojowa-st7987123?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T03:36:22+00:00

<img alt="Przetestowali nowy pocisk. Może przenieść " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3246604-korea-polnocna-przeprowadzila-test-nowego-pocisku-balistycznego-ph7987122/alternates/LANDSCAPE_1280" />
    Test się powiodły - informują państwowe media.

## Ratował ukraińskich żołnierzy, "zginął jak bohater"
 - [https://tvn24.pl/swiat/ukraina-brytyjski-zalozyciel-organizacji-charytatywnej-zginal-na-polu-bitwy-st7987118?source=rss](https://tvn24.pl/swiat/ukraina-brytyjski-zalozyciel-organizacji-charytatywnej-zginal-na-polu-bitwy-st7987118?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T03:31:13+00:00

<img alt="Ratował ukraińskich żołnierzy, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7271920-peter-fouche-zginal-w-ukrainie-ph7987117/alternates/LANDSCAPE_1280" />
    Brytyjczyk pracował jako sanitariusz na linii frontu.

## W Małopolsce bez rozstrzygnięcia, list do Ziobry, Węgry na czele Unii
 - [https://tvn24.pl/swiat/szesc-rzeczy-ktore-warto-wiedziec-we-wtorek-2-lipca-st7987120?source=rss](https://tvn24.pl/swiat/szesc-rzeczy-ktore-warto-wiedziec-we-wtorek-2-lipca-st7987120?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-07-02T03:23:20+00:00

<img alt="W Małopolsce bez rozstrzygnięcia, list do Ziobry, Węgry na czele Unii " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2070269-zbigniew-ziobro-ph7932896/alternates/LANDSCAPE_1280" />
    Podsumowujemy.

