# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## "Nie podzielam". Prezydent ostro reaguje na słowa Donalda Tuska
 - [https://businessinsider.com.pl/wiadomosci/duda-vs-tusk-spor-o-reparacje-wojenne-prezydent-ostro-reaguje-na-slowa-tuska/h0wh8sh](https://businessinsider.com.pl/wiadomosci/duda-vs-tusk-spor-o-reparacje-wojenne-prezydent-ostro-reaguje-na-slowa-tuska/h0wh8sh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T21:30:44+00:00

Prezydent Andrzej Duda oświadczył, że nie zgadza się ze stanowiskiem premiera Donalda Tuska, jakoby polskie władze kiedykolwiek skutecznie zrzekły się prawa do roszczeń i zadośćuczynienia za straty wojenne. Podkreślił również, że Polska od dawna oczekuje na godne upamiętnienie ofiar II wojny światowej w Berlinie.

## Roszady we władzach BGK
 - [https://businessinsider.com.pl/gospodarka/roszady-we-wladzach-bgk/v12ejpy](https://businessinsider.com.pl/gospodarka/roszady-we-wladzach-bgk/v12ejpy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T19:09:07+00:00

Bank Gospodarstwa Krajowego poinformował, że premier Donald Tusk powołał w poniedziałek Michała Świtalskiego w skład Rady Nadzorczej BGK, a we wtorek odwołał Tomasza Robaczyńskiego ze stanowiska członka zarządu BGK.

## "Szkoda, że nie podał kwot". Niemcy krytykują Olafa Scholza
 - [https://businessinsider.com.pl/wiadomosci/szkoda-ze-nie-podal-kwot-niemcy-krytykuja-olafa-scholza/44377ev](https://businessinsider.com.pl/wiadomosci/szkoda-ze-nie-podal-kwot-niemcy-krytykuja-olafa-scholza/44377ev)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T18:30:55+00:00

Niemieccy komentatorzy popierają pomysł finansowej pomocy dla żyjących jeszcze ofiar wojny i okupacji, jednocześnie krytykując kanclerza Scholza za unikanie podania konkretnej sumy. Premier Donald Tusk będzie trudnym partnerem, a Berlin będzie się musiał liczyć ze stanowiskiem Warszawy bardziej niż za czasów PiS — podkreślają.

## Tak Polska chce uderzyć w białoruski reżim
 - [https://businessinsider.com.pl/gospodarka/tak-polska-chce-uderzyc-w-bialoruski-rezim/t5jl6pg](https://businessinsider.com.pl/gospodarka/tak-polska-chce-uderzyc-w-bialoruski-rezim/t5jl6pg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T18:15:16+00:00

Jest decyzja o wprowadzeniu "bardzo szczegółowych kontroli" w kluczowym terminalu celnym przy granicy z Białorusią — podaje RMF. Ma to być "wyjątkowo dotkliwy ruch wobec reżimu Łukaszenki".

## Łotysz płacił w niemieckim pubie kartą. Wreszcie właściciel wezwał policję
 - [https://businessinsider.com.pl/wiadomosci/lotysz-placil-w-niemieckim-pubie-karta-wreszcie-wlasciciel-wezwal-policje/hgmz3ef](https://businessinsider.com.pl/wiadomosci/lotysz-placil-w-niemieckim-pubie-karta-wreszcie-wlasciciel-wezwal-policje/hgmz3ef)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T18:05:37+00:00

21-latek z Łotwy zamawiał kolejne piwa w barze w miejscowości Mamming w Bawarii. Właściciel lokalu się jednak zezłościł faktem, iż mężczyzna dokonywał płatności... kartą. Interweniować musiała policja.

## Polskie miasto pustostanów. Urzędnicy winę zrzucają na stan techniczny mieszkań
 - [https://businessinsider.com.pl/gospodarka/polskie-miasto-pustostanow-urzednicy-wine-zrzucaja-na-stan-techniczny-mieszkan/gv2yhfb](https://businessinsider.com.pl/gospodarka/polskie-miasto-pustostanow-urzednicy-wine-zrzucaja-na-stan-techniczny-mieszkan/gv2yhfb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T17:19:29+00:00

Jest jedno duże miasto w Polsce, które uchodzi za "miasto pustostanów". Chodzi o Wrocław, w którym w puli lokali komunalnych jest prawie 500 nieruchomości. Większość z nich jest przeznaczona na wynajem, jednak oczekiwanie na możliwość wprowadzenia trwa ponad dwa lata. Powody takiej sytuacji są i prozaiczne, i dość osobliwe.

## "NYT": to Benjamin Netanjahu nie chce zawieszenia broni
 - [https://businessinsider.com.pl/wiadomosci/nyt-to-benjamin-netanjahu-nie-chce-zawieszenia-broni/jc2njkg](https://businessinsider.com.pl/wiadomosci/nyt-to-benjamin-netanjahu-nie-chce-zawieszenia-broni/jc2njkg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T16:59:05+00:00

Dowodzący izraelską armią generałowie popierają zawieszenie broni w Strefie Gazy, nawet jeżeli oznaczałoby to, że Hamas utrzyma władzę — podaje dziennik "New York Times". Temu ma się jednak sprzeciwiać szef izraelskiego rządu.

## Niemcy nie radzą sobie z gigantyczną falą kradzieży
 - [https://businessinsider.com.pl/gospodarka/niemcy-nie-radza-sobie-z-gigantyczna-fala-kradziezy/e6qwsnk](https://businessinsider.com.pl/gospodarka/niemcy-nie-radza-sobie-z-gigantyczna-fala-kradziezy/e6qwsnk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T16:40:44+00:00

Kradzieże są coraz większym problemem u naszych zachodnich sąsiadów. Jak wynika z raportu instytut badań handlu detalicznego EHI, najgorzej jest w supermarketach i dyskontach.

## Wzrost cen mieszkań w Polsce trzeci najwyższy na świecie. Nie ma się z czego cieszyć
 - [https://businessinsider.com.pl/gospodarka/wzrost-cen-mieszkan-w-polsce-trzeci-najwyzszy-na-swiecie-nie-ma-sie-z-czego-cieszyc/ydhjxhg](https://businessinsider.com.pl/gospodarka/wzrost-cen-mieszkan-w-polsce-trzeci-najwyzszy-na-swiecie-nie-ma-sie-z-czego-cieszyc/ydhjxhg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T16:39:41+00:00

Ceny mieszkań wzrosły w Polsce 13 proc. w ciągu ostatniego roku wobec 3,6 proc. średnio na 56 rynkach śledzonych przez Knight Frank — podała firma badawcza. Daje to naszemu krajowi wysokie 3. miejsce w tym gronie, po Turcji (52 proc.) i Bułgarii (16 proc.). Chodzi tu o procentowe zmiany bez uwzględnienia inflacji. Jeśli wziąć ją pod uwagę, sytuacja wygląda inaczej.

## Open’er na drugim miejscu. Polacy wybrali najciekawsze letnie festiwale muzyczne
 - [https://businessinsider.com.pl/poradnik-finansowy/polacy-wybrali-najciekawsze-letnie-festiwale-muzyczne/zk69yy4](https://businessinsider.com.pl/poradnik-finansowy/polacy-wybrali-najciekawsze-letnie-festiwale-muzyczne/zk69yy4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T16:03:46+00:00

46 proc. Polek i Polaków przynajmniej raz w życiu uczestniczyła w letnim festiwalu muzycznym w naszym kraju — wynika z najnowszego raportu serwisu Biletyna.pl. Wybrano najciekawsze takie wydarzenia w kraju.

## Komisja Europejska przyjęła polskie zmiany do KPO. Co z podatkiem od aut spalinowych
 - [https://businessinsider.com.pl/prawo/komisja-europejska-przyjela-polskie-zmiany-do-kpo-co-z-podatkiem-od-aut-spalinowych/z67t397](https://businessinsider.com.pl/prawo/komisja-europejska-przyjela-polskie-zmiany-do-kpo-co-z-podatkiem-od-aut-spalinowych/z67t397)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T15:48:43+00:00

Komisja Europejska zgodziła się na zmiany w Polskim Krajowym Planie Odbudowy. Zamiast podatku od aut spalinowych przy rejestracji będą dopłaty do kupna pojazdów elektrycznych używanych i nowych.

## VW i Mercedes w opałach. Chińczycy podbijają rynek
 - [https://businessinsider.com.pl/gospodarka/juz-za-chwile-chinczycy-podbija-rynek-motoryzacji-jest-badanie/6h5vys2](https://businessinsider.com.pl/gospodarka/juz-za-chwile-chinczycy-podbija-rynek-motoryzacji-jest-badanie/6h5vys2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T15:31:30+00:00

Chińskie firmy coraz lepiej radzą sobie na światowym rynku — wynika z analizy firmy Alix Partners. Na ich korzyść działają niższe marże, ale i szybsza produkcja aut.

## Sztuczna inteligencja nie zabierze ci pracy. "Jest jak kosiarka do trawy"
 - [https://businessinsider.com.pl/technologie/nowe-technologie/sztuczna-inteligencja-nie-zabierze-ci-pracy-jest-jak-kosiarka-do-trawy/8yjfsht](https://businessinsider.com.pl/technologie/nowe-technologie/sztuczna-inteligencja-nie-zabierze-ci-pracy-jest-jak-kosiarka-do-trawy/8yjfsht)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T15:26:41+00:00

"AI nie zabierze Ci pracy, zrobi to ktoś, kto z niej korzysta". To zdanie może i brzmi mądrze, ale czy jest prawdziwe?

## Masz te kubki w domu? GIS ostrzega: zagrożenie dla zdrowia
 - [https://businessinsider.com.pl/wiadomosci/masz-te-kubki-w-domu-mozna-sie-zatruc-olowiem/jwcl2bk](https://businessinsider.com.pl/wiadomosci/masz-te-kubki-w-domu-mozna-sie-zatruc-olowiem/jwcl2bk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T15:12:24+00:00

Główny Inspektorat Sanitarny wydał we wtorek ostrzeżenie dotyczące wysokich poziomów migracji ołowiu i kadmu z obrzeża partii szklanych kubków. Jak informuje, taka ilość stwarza zagrożenie dla zdrowia.

## Bramki są dwie, ale kamer coraz więcej. Euro 2024 to wielki monitoring piłki i zawodników
 - [https://businessinsider.com.pl/technologie/nowe-technologie/bramki-ciagle-sa-dwie-ale-kamer-coraz-wiecej-euro-2024-to-wielki-monitoring-pilki-i/fz8pj7c](https://businessinsider.com.pl/technologie/nowe-technologie/bramki-ciagle-sa-dwie-ale-kamer-coraz-wiecej-euro-2024-to-wielki-monitoring-pilki-i/fz8pj7c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T15:05:06+00:00

Postępy w rozwoju sprzętu i nauki są bardzo widoczne na mistrzostwach Euro 2024 zarówno na boisku, jak i poza nim. Wszystko po to, aby poprawić grę, doświadczenia kibiców i dobrostan zawodników. Całość wspiera też sztuczna inteligencja.

## FlixBus uśmiecha się do rowerzystów. Rezerwacja za 1 zł
 - [https://businessinsider.com.pl/poradnik-finansowy/flixbus-usmiecha-sie-do-rowerzystow-rezerwacja-za-1-zl/lsj4k61](https://businessinsider.com.pl/poradnik-finansowy/flixbus-usmiecha-sie-do-rowerzystow-rezerwacja-za-1-zl/lsj4k61)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T15:01:19+00:00

Znany przewoźnik ogłasza w swojej ofercie "rowerowy lipiec". "Rezerwacja przewozu roweru kosztuje jedynie 1 zł" - czytamy w komunikacie.

## Chińczycy sprzedają więcej samochodów elektrycznych niż kiedykolwiek. Tesla powinna się martwić
 - [https://businessinsider.com.pl/gospodarka/chinczycy-sprzedaja-wiecej-samochodow-elektrycznych-niz-kiedykolwiek-tesla-powinna/wpj0bfl](https://businessinsider.com.pl/gospodarka/chinczycy-sprzedaja-wiecej-samochodow-elektrycznych-niz-kiedykolwiek-tesla-powinna/wpj0bfl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T14:44:09+00:00

Pod koniec czerwca trzech chińskich producentów pojazdów elektrycznych osiągnęło rekordowe wyniki sprzedaży. Dla Tesli może to oznaczać kłopoty.

## Francuzi zmieniają podejście do małego atomu. Stawiają na "sprawdzone technologie"
 - [https://businessinsider.com.pl/biznes/francuzi-zmieniaja-podejscie-do-malego-atomu-stawiaja-na-sprawdzone-technologie/gb4f3pb](https://businessinsider.com.pl/biznes/francuzi-zmieniaja-podejscie-do-malego-atomu-stawiaja-na-sprawdzone-technologie/gb4f3pb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T14:39:37+00:00

Francuski koncern EDF zmienia strategię rozwoju małych reaktorów jądrowych (SMR). Zapewnia, że kontynuuje prace nad swoim pierwszym SMR-em, ale stawia na "sprawdzone technologie w miejsce zaawansowanych innowacji". Wcześniej francuskie media podały, że EDF zawiesza dotychczasowy projekt, bo był "zbyt skomplikowany technicznie".

## Niemcy mają problem z polskimi jabłkami. Za ładne i za tanie
 - [https://businessinsider.com.pl/wiadomosci/niemcy-maja-problem-z-polskimi-jablkami-za-ladne-i-za-tanie/98j8e6f](https://businessinsider.com.pl/wiadomosci/niemcy-maja-problem-z-polskimi-jablkami-za-ladne-i-za-tanie/98j8e6f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T14:38:23+00:00

Niemieccy sadownicy borykają się z serią problemów, które zagrażają ich sezonowi zbiorów. Niekorzystne warunki pogodowe, brak wykwalifikowanej siły roboczej oraz rosnąca konkurencja ze strony Polski to najważniejsze wyzwania, z jakimi muszą się mierzyć.

## Dom jednorodzinny nadal marzeniem większości Polaków
 - [https://businessinsider.com.pl/nieruchomosci/polacy-nadal-marza-o-domu-jednorodzinnym/5ym39s7](https://businessinsider.com.pl/nieruchomosci/polacy-nadal-marza-o-domu-jednorodzinnym/5ym39s7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T14:30:15+00:00

71 proc. Polaków marzy o domu jednorodzinnym, jak wskazuje najnowszy raport Otodom. Serwis badał dobrostan mieszkańców Polski w miejscu ich zamieszkania. Raport pokazuje, że jesteśmy zadowoleni ze swojej sytuacji mieszkaniowej. Średnia ocena szczęścia mieszkańców Polski w 10-stopniowej skali wyniosła aż 6,92!

## Telewizja Republika z rekordowym wynikiem finansowym. Dzięki wpłatom od widzów
 - [https://businessinsider.com.pl/gospodarka/telewizja-republika-z-rekordowym-wynikiem-finansowym-dzieki-wplatom-od-widzow/mb8c0jc](https://businessinsider.com.pl/gospodarka/telewizja-republika-z-rekordowym-wynikiem-finansowym-dzieki-wplatom-od-widzow/mb8c0jc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T14:17:23+00:00

Telewizja Republika odnotowała rekordowy wzrost przychodów. Jednym z ważniejszych czynników, który zadecydował o tym wyniku, były wpłaty od widzów.

## Będzie pierwszy święty milenials. Watykan zdecydował o kanonizacji "influencera Boga"
 - [https://businessinsider.com.pl/wiadomosci/watykan-podjal-decyzje-bedzie-pierwszy-swiety-milenials/zvzvqr6](https://businessinsider.com.pl/wiadomosci/watykan-podjal-decyzje-bedzie-pierwszy-swiety-milenials/zvzvqr6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T13:59:32+00:00

Włoski nastolatek, znany ze swojej pasji do gier wideo, stanie się pierwszym świętym z pokolenia millenialsów w Kościele katolickim. Jego proces kanonizacyjny został właśnie zatwierdzony przez papieża Franciszka i kardynałów.

## Będzie podatek zdrowotny? Wiceminister: założenia gotowe
 - [https://businessinsider.com.pl/gospodarka/bedzie-podatek-zdrowotny-wiceminister-zalozenia-gotowe/1dpt9th](https://businessinsider.com.pl/gospodarka/bedzie-podatek-zdrowotny-wiceminister-zalozenia-gotowe/1dpt9th)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T13:57:45+00:00

Wiceminister zdrowia Wojciech Konieczny poinformował, że założenia projektu ustawy o tzw. podatku zdrowotnym są gotowe do przekazania szefowi finansów Andrzejowi Domańskiemu. Wyjaśnił, że pomysł zakłada "zmianę systemową", dlatego Lewica czeka na zielone światło, by móc dalej pracować nad projektem.

## Dzień jagodzianki. Dlaczego są takie drogie?
 - [https://businessinsider.com.pl/lifestyle/jedzenie/dzien-jagodzianki-dlaczego-sa-takie-drogie/7fxctjg](https://businessinsider.com.pl/lifestyle/jedzenie/dzien-jagodzianki-dlaczego-sa-takie-drogie/7fxctjg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T13:47:36+00:00

Dzień Jagodzianki to nieformalne święto obchodzone 2 lipca. Skąd ta data? Dzień ten naznaczony jest "jagodową symboliką". Ponadto jagodzianki to symbol końca roku szkolnego i początku wakacji. W tym roku jest jednak znacznie podrożały. Cena wypieku w jednym ze znanych lokali sięga... 31 zł. Na szczęście nie wszędzie jest tak drogo.

## Wybrano marki, które najbardziej cenią Polacy
 - [https://businessinsider.com.pl/gospodarka/te-marki-polacy-cenia-najbardziej/r9tqtlf](https://businessinsider.com.pl/gospodarka/te-marki-polacy-cenia-najbardziej/r9tqtlf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T13:40:59+00:00

Firma badawcza Inquiry przedstawiła ranking marek, które cenią Polacy. Wybrano te brandy, które oferują najlepszą jakość do ceny oraz te, które dają konsumentom najwięcej satysfakcji.

## Prognozy gospodarcze dla Polski.  Jak RPP zareaguje na inflacyjny garb?
 - [https://businessinsider.com.pl/gospodarka/prognozy-gospodarcze-dla-polski-jak-rpp-zareaguje-na-inflacyjny-garb/hmlmjeq](https://businessinsider.com.pl/gospodarka/prognozy-gospodarcze-dla-polski-jak-rpp-zareaguje-na-inflacyjny-garb/hmlmjeq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T13:34:05+00:00

Dane z polskiej gospodarki od dłuższego czasu mają mieszany wydźwięk, a struktura jest nietypowa. Konsumpcja jest całkiem mocna, przemysł słaby, a budownictwo bardzo słabe. Drugie półrocze powinno być jednak lepsze, przynosząc postępujące ożywienie aktywności gospodarczej – ocenia główny ekonomista mBanku, Marcin Mazurek.

## Viktor Orban jednak chce współpracować z Ukrainą
 - [https://businessinsider.com.pl/wiadomosci/viktor-orban-jednak-chce-wspolpracowac-z-ukraina/rvjserv](https://businessinsider.com.pl/wiadomosci/viktor-orban-jednak-chce-wspolpracowac-z-ukraina/rvjserv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T13:20:41+00:00

Węgry chcą podpisać z Ukrainą szerokie porozumienie o współpracy — oświadczył w Kijowie węgierski premier Viktor Orban. Mówił też o potrzebie "zawieszenia broni".

## UEFA nałożyła kary na PZPN. Chodzi o zachowanie kibiców po każdym meczu
 - [https://businessinsider.com.pl/biznes/uefa-nalozyla-kary-na-pzpn-chodzi-o-zachowanie-kibicow-po-kazdym-meczu/elbsptw](https://businessinsider.com.pl/biznes/uefa-nalozyla-kary-na-pzpn-chodzi-o-zachowanie-kibicow-po-kazdym-meczu/elbsptw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T13:17:32+00:00

Polski Związek Piłki Nożnej musi zapłacić kary nałożone przez UEFA za naruszenia zasad podczas Euro 2024. Znalazł się w gronie ośmiu federacji, które otrzymały karę po każdym swoim meczu fazy grupowej.

## Odrywasz nakrętki od butelek? Od 1 lipca 2024 nowe przepisy
 - [https://businessinsider.com.pl/wiadomosci/odrywasz-nakretki-od-butelek-od-1-lipca-2024-nowe-przepisy-resort-wyjasnia/ypyqexb](https://businessinsider.com.pl/wiadomosci/odrywasz-nakretki-od-butelek-od-1-lipca-2024-nowe-przepisy-resort-wyjasnia/ypyqexb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T12:57:13+00:00

Od 1 lipca 2024 r. plastikowe nakrętki są fabrycznie przytwierdzone do butelki czy kartonu. Zmiana, już na długo przed jej wprowadzeniem, budziła sporo kontrowersji. Co zrobić, jeśli oderwiemy nakrętkę? Resort klimatu wyjaśnia.

## Scholz: cieszę się, że Polska przystąpi do Klubu Klimatycznego. Co to dla nas oznacza?
 - [https://businessinsider.com.pl/gospodarka/scholz-ciesze-sie-ze-polska-przystapi-do-klubu-klimatycznego-co-to-dla-nas-oznacza/q1mp473](https://businessinsider.com.pl/gospodarka/scholz-ciesze-sie-ze-polska-przystapi-do-klubu-klimatycznego-co-to-dla-nas-oznacza/q1mp473)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T12:32:34+00:00

Podczas konferencji prasowej podsumowującej dzień wspólnych obrad polsko-niemieckich, kanclerz Olaf Scholz podkreślił swoją radość z przystąpienia Polski do Klubu Klimatycznego. Polska jest na stronach internetowych Klubu już wyświetlana w gronie 39 państw członkowskich. Co właściwie oznacza uczestnictwo w tej organizacji?

## Górale nie chcą już handlować oscypkami na Krupówkach
 - [https://businessinsider.com.pl/wiadomosci/gorale-nie-chca-juz-handlowac-oscypkami-na-krupowkach-pustki/4fr4hg9](https://businessinsider.com.pl/wiadomosci/gorale-nie-chca-juz-handlowac-oscypkami-na-krupowkach-pustki/4fr4hg9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T12:20:31+00:00

Kilka lat temu górale płacili za stoisko do sprzedaży oscypków na Krupówkach nawet 25 tys. zł miesięcznie, a chętnych nie brakowało. Dziś sytuacja wygląda zupełnie inaczej — prawie 30 proc. stoisk nie znalazło chętnych, a cena wywoławcza stoiska spadła do 2,5 tys. zł. Skąd ta zmiana?

## Od 7 lipca nowy wymóg w autach
 - [https://businessinsider.com.pl/wiadomosci/od-7-lipca-nowy-wymog-w-autach/ejrd4t6](https://businessinsider.com.pl/wiadomosci/od-7-lipca-nowy-wymog-w-autach/ejrd4t6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T12:19:44+00:00

7 lipca nowe samochody w Unii będą musiały być wyposażone w specjalny system, który będzie informować o stanie zmęczenia kierowcy. Ta inicjatywa Brukseli ma poprawić bezpieczeństwo na unijnych drogach.

## Jarosław Kaczyński odetchnie z ulgą. Chodzi o finanse PiS
 - [https://businessinsider.com.pl/wiadomosci/jaroslaw-kaczynski-odetchnie-z-ulga-chodzi-o-finanse-pis/pk1zrdd](https://businessinsider.com.pl/wiadomosci/jaroslaw-kaczynski-odetchnie-z-ulga-chodzi-o-finanse-pis/pk1zrdd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T12:03:31+00:00

Zarówno przepisy ustawy o partiach politycznych, jak i Kodeksu wyborczego nie przewidują możliwości wznowienia postępowania w zakończonych już sprawach, w których zapadła prawomocna uchwała Państwowej Komisji Wyborczej — tak Krajowe Biuro Wyborcze odpowiedziało na pytanie o możliwe ponowne zbadanie sprawozdania finansowego PiS z 2019 r.

## "Nie podzielam". Prezydent ostro reaguje na słowa Donalda Tuska
 - [https://businessinsider.com.pl/wiadomosci/nie-podzielam-prezydent-ostro-reaguje-na-slowa-donalda-tuska/h0wh8sh](https://businessinsider.com.pl/wiadomosci/nie-podzielam-prezydent-ostro-reaguje-na-slowa-donalda-tuska/h0wh8sh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T11:49:44+00:00

Prezydent Andrzej Duda oświadczył, że nie podziela stanowiska premiera Donalda Tuska, że kiedykolwiek polskie władze zrzekły się w sposób skuteczny prawa do roszczeń i zadośćuczynienia za straty wojenne. Podkreślił, że Polska od dawna czeka na godne upamiętnienie ofiar II wojny światowej w Berlinie.

## Najpopularniejszy samochód w USA trafia do sprzedaży w Polsce
 - [https://businessinsider.com.pl/gospodarka/najpopularniejszy-samochod-w-usa-trafia-do-sprzedazy-w-polsce/eg3bwns](https://businessinsider.com.pl/gospodarka/najpopularniejszy-samochod-w-usa-trafia-do-sprzedazy-w-polsce/eg3bwns)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T11:46:47+00:00

Polska Grupa Dealerska wprowadza model Ford F-150 do oficjalnej sprzedaży w Polsce. To auto jest u nas obecnie mało popularne, ale np. w USA to od wielu dekad wielki hit sprzedażowy.

## PiS chce, byśmy więcej inwestowali na giełdzie. Jest projekt
 - [https://businessinsider.com.pl/gospodarka/pis-chce-bysmy-wiecej-inwestowali-na-gieldzie/90y3kh4](https://businessinsider.com.pl/gospodarka/pis-chce-bysmy-wiecej-inwestowali-na-gieldzie/90y3kh4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T11:30:08+00:00

Politycy PiS przedstawili projekt ustawy, który ma zwiększyć atrakcyjność inwestowania na giełdzie. Przewiduje on m.in. że dochody z odpłatnego zbycia papierów wartościowych i dochody z dywidend byłyby podatkowo traktowane tak samo.

## Wojsko Polskie wysyła żołnierzy do Francji
 - [https://businessinsider.com.pl/wiadomosci/wojsko-polskie-wysyla-zolnierzy-do-francji/qbkf13d](https://businessinsider.com.pl/wiadomosci/wojsko-polskie-wysyla-zolnierzy-do-francji/qbkf13d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T11:22:10+00:00

Polski Kontyngent Wojskowy wydzielony do wzmocnienia Sił Zbrojnych Republiki Francuskiej w zabezpieczeniu XXXIII Letnich Igrzysk Olimpijskich oraz XVII Letnich Igrzysk Paraolimpijskich jest już na terenie Francji — mówi rzeczniczka płk Joanna Klejszmit.

## Tak zarabia kancelaria Mentzena. Polityk-biznesmen zdradza plany
 - [https://businessinsider.com.pl/gielda/wiadomosci/tak-zarabia-kancelaria-mentzena-polityk-biznesmen-zdradza-plany/3mkpgqy](https://businessinsider.com.pl/gielda/wiadomosci/tak-zarabia-kancelaria-mentzena-polityk-biznesmen-zdradza-plany/3mkpgqy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T11:19:47+00:00

Kancelaria Mentzen, prowadzona przez polityka Konfederacji i posła Sławomira Mentzena, zdradza plany. Chce wprowadzać dodatkowe usługi i zamierza rozwijać się głównie organicznie. Choć niewykluczone są też przejęcia. Rozpoznawalność prezesa napędza biznes.

## Donald Trump twierdzi, że może zakończyć wojnę w Ukrainie w jeden dzień. Rosja odpowiada
 - [https://businessinsider.com.pl/wiadomosci/trump-twierdzi-ze-moze-zakonczyc-wojne-w-ukrainie-w-24-h-rosja-nie-moze/f01lz36](https://businessinsider.com.pl/wiadomosci/trump-twierdzi-ze-moze-zakonczyc-wojne-w-ukrainie-w-24-h-rosja-nie-moze/f01lz36)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T11:19:23+00:00

Donald Trump wielokrotnie powtarzał, że może "zakończyć wojnę między Rosją a Ukrainą w jeden dzień", jeśli ponownie zostanie wybrany na prezydenta USA. Ambasador Rosji przy ONZ ma na ten temat inne zdanie.

## Żabka jak food truck. Sklepy ruszają
 - [https://businessinsider.com.pl/gospodarka/zabka-jak-food-truck-sklepy-ruszaja/1v4nthz](https://businessinsider.com.pl/gospodarka/zabka-jak-food-truck-sklepy-ruszaja/1v4nthz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T11:19:09+00:00

Popularna sieć sklepów znów uruchamia sklepy "mobilna Żabka", które przypominają nieco food trucki. Takie sklepy pojawią się na festiwalach muzycznych, ale i na znanym wydarzeniu politycznym.

## Nie wszyscy zwalniają. Ciastkowo-waflowy gigant zatrudni 260 osób
 - [https://businessinsider.com.pl/gospodarka/nie-wszyscy-zwalniaja-ciastkowo-waflowy-gigant-zatrudni-260-osob/98g0fpk](https://businessinsider.com.pl/gospodarka/nie-wszyscy-zwalniaja-ciastkowo-waflowy-gigant-zatrudni-260-osob/98g0fpk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T11:05:20+00:00

Wiele dużych koncernów ogłosiło ostatnio w Polsce bolesne zwolnienia grupowe. Ciągle jednak są też duże firmy, które ogłaszają wielkie rekrutacje. Na przykład dr Gerard, jeden z największych producentów ciastek i wafli w Polsce oraz w Europie Środkowo-Wschodniej.

## Polskie biuro podróży prewencyjnie ewakuowała 360 turystów z Grecji
 - [https://businessinsider.com.pl/wiadomosci/polskie-biuro-podrozy-ewakuuje-360-turystow-z-grecji/604bk7h](https://businessinsider.com.pl/wiadomosci/polskie-biuro-podrozy-ewakuuje-360-turystow-z-grecji/604bk7h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T11:00:11+00:00

W poniedziałek miała miejsca prewencyjna ewakuacja 362 naszych klientów przebywających w rejonie Kardameny — poinformowała wtorek Ewa Maruszak z biura podróży ITAKA. Rejon Kardameny znajduje się w południowej części greckiej wyspy Kos, na której w poniedziałek wybuchł pożar.

## Co zostało z reparacji? Donald Tusk: nie jestem rozczarowany tą propozycją
 - [https://businessinsider.com.pl/gospodarka/co-zostalo-z-reparacji-donald-tusk-nie-jestem-rozczarowany-ta-propozycja/hhznndd](https://businessinsider.com.pl/gospodarka/co-zostalo-z-reparacji-donald-tusk-nie-jestem-rozczarowany-ta-propozycja/hhznndd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T10:55:30+00:00

Na pytanie niemieckiego dziennikarza kanclerz Scholz wyjaśnił, co rząd niemiecki planuje w kwestii wysuwanych przez poprzedni polski rząd oczekiwań reparacyjnych. Premier Donald Tusk odpowiedział, że nie jest rozczarowany propozycjami, a jednocześnie zasugerował, że będzie negocjować coś więcej. W kontrze do poprzedniego rządu powiedział, że będą to realne do uzyskania rzeczy.

## Polski rynek pracy błyszczy na tle unijnego. Ale bezrobotnych przybyło
 - [https://businessinsider.com.pl/gospodarka/polski-rynek-pracy-blyszczy-na-tle-unijnego-ale-bezrobotnych-przybylo/15b0v9e](https://businessinsider.com.pl/gospodarka/polski-rynek-pracy-blyszczy-na-tle-unijnego-ale-bezrobotnych-przybylo/15b0v9e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T10:11:54+00:00

Sytuacja na europejskim rynku pracy — z perspektywy szukających zatrudnienia — poprawia się. Polska wciąż bryluje pod względem rekordowo niskiej stopy bezrobocia. Ustępujemy pod tym względem tylko Czechom, choć liczba osób pozostających bez pracy jest wyższa niż rok temu.

## Woda w Żabce za 15 groszy. Jest jeden warunek
 - [https://businessinsider.com.pl/finanse/handel/woda-w-zabce-za-15-groszy-jest-jeden-warunek/97mm0yc](https://businessinsider.com.pl/finanse/handel/woda-w-zabce-za-15-groszy-jest-jeden-warunek/97mm0yc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T10:09:50+00:00

Żabka wprowadza nową usługę. Wodę z refillomatu można kupić za jedyne 15 gr w wybranych sklepach sieci. Jest jednak jeden warunek.

## Długa historia reparacji od Niemiec. PiS chciało 13-cyfrowej kwoty, na razie będzie miejsce pamięci
 - [https://businessinsider.com.pl/gospodarka/reparacje-od-niemiec-pis-chcialo-13-cyfrowej-kwoty-bedzie-miejsce-pamieci/brn53nm](https://businessinsider.com.pl/gospodarka/reparacje-od-niemiec-pis-chcialo-13-cyfrowej-kwoty-bedzie-miejsce-pamieci/brn53nm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T10:01:28+00:00

Kanclerz Niemiec Olaf Scholz zapowiedział we wtorek, że w Berlinie powstanie miejsce pamięci polskich ofiar III Rzeszy. Nie padła jednak spodziewana deklaracja o pieniądzach dla ocalałych. Kwestia reparacji wciąż pozostaje sprawą niezamkniętą.

## Tusk spotkał się z Scholzem. W Niemczech powstanie miejsce pamięci polskich ofiar III Rzeszy
 - [https://businessinsider.com.pl/wiadomosci/tusk-spotkal-sie-z-schulzem-w-niemczech-powstanie-miejsce-pamieci-polskich-ofiar-iii/17t5e2y](https://businessinsider.com.pl/wiadomosci/tusk-spotkal-sie-z-schulzem-w-niemczech-powstanie-miejsce-pamieci-polskich-ofiar-iii/17t5e2y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T09:54:13+00:00

We wtorek — w ramach konsultacji międzyrządowych — odbyło się spotkanie Donalda Tuska i Olafa Scholza. Po jego zakończeniu kanclerz Niemiec zapowiedział, że w jego kraju powstanie miejsce pamięci polskich ofiar III Rzeszy w Berlinie.

## Inflacja w strefie euro mozolnie się obniża. EBC potrzebuje więcej dowodów
 - [https://businessinsider.com.pl/gospodarka/inflacja-w-strefie-euro-mozolnie-sie-obniza-ebc-potrzebuje-wiecej-dowodow/qf2cld1](https://businessinsider.com.pl/gospodarka/inflacja-w-strefie-euro-mozolnie-sie-obniza-ebc-potrzebuje-wiecej-dowodow/qf2cld1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T09:37:21+00:00

Dezinflacja w strefie euro postępuje, choć dzieje się to powoli. Główny wskaźnik dynamiki cen konsumpcyjnych jest już blisko celu, ale ten bazowy — kluczowy dla decydentów w zakresie stóp procentowych — wciąż jest wyraźnie podwyższony. Europejski Bank Centralny wypatruje sygnałów wskazujących, czy pojawia się przestrzeń do dalszych obniżek kosztu pieniądza.

## Gigantyczne pieniądze pójdą do NFZ. "PiS wydrenowało fundusz zapasowy"
 - [https://businessinsider.com.pl/wiadomosci/gigantyczne-pieniadze-pojda-do-nfz-pis-wydrenowalo-fundusz-zapasowy/hg5gj2g](https://businessinsider.com.pl/wiadomosci/gigantyczne-pieniadze-pojda-do-nfz-pis-wydrenowalo-fundusz-zapasowy/hg5gj2g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T09:11:37+00:00

Dotacja z budżetu państwa do Narodowego Funduszu Zdrowia (NFZ) wyniesie w 2025 r. 18,3 mld zł, poinformowała minister zdrowia Izabela Leszczyna. To... o ponad 18 mld więcej niż w 2023 r.

## Mocny debiut Mentzena na warszawskiej giełdzie. Inwestorzy i poseł mogą liczyć zyski
 - [https://businessinsider.com.pl/gielda/wiadomosci/debiut-mentzena-na-warszawskiej-gieldzie-inwestorzy-i-posel-moga-liczyc-zyski/lcxfpsy](https://businessinsider.com.pl/gielda/wiadomosci/debiut-mentzena-na-warszawskiej-gieldzie-inwestorzy-i-posel-moga-liczyc-zyski/lcxfpsy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T08:58:31+00:00

Sławomir Mentzen, lider Konfederacji i jeden z najbogatszych posłów obecnej kadencji, wprowadził na NewConnect swoją spółkę Mentzen S.A. We wtorek przed południem jej akcje zadebiutowały na rynku. Kurs mocno ruszył w górę.

## Młodzi Polacy wciąż często mieszkają z rodzicami. Ale liczba i odsetek gniazdowników maleje
 - [https://businessinsider.com.pl/gospodarka/mlodzi-polacy-wciaz-czesto-mieszkaja-z-rodzicami-ale-liczba-i-odsetek-gniazdownikow/qlntmns](https://businessinsider.com.pl/gospodarka/mlodzi-polacy-wciaz-czesto-mieszkaja-z-rodzicami-ale-liczba-i-odsetek-gniazdownikow/qlntmns)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T08:44:49+00:00

Problemy z kupnem własnego mieszkania, kwestie zdrowotne ale czasem wolny wybór — to różne powody, dla których całkiem spora część młodych Polaków wciąż mieszka z rodzicami. Główny Urząd Statystyczny przedstawił najnowsze dane sprawie tzw. gniazdowników. Wynika z nich, że sytuacja przez kilka lat poprawiła się.

## Tak chcą pracować Polacy. Sondaż
 - [https://businessinsider.com.pl/praca/tak-chca-pracowac-polacy-sondaz/e80j84f](https://businessinsider.com.pl/praca/tak-chca-pracowac-polacy-sondaz/e80j84f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T08:40:38+00:00

49 proc. Polaków preferuje pracę w trybie hybrydowym. W pełni stacjonarnie chce pracować 35 proc. badanych, a zdalnie — 16 proc. wynika z badania firmy Pracuj.pl. Jeden na pięciu badanych wskazuje, że odpowiedni tryb pracy jest dla nich najważniejszym czynnikiem wpływającym na wybór miejsca pracy.

## Nowe zasady rozliczania fotowoltaiki. Ekspert ostrzega
 - [https://businessinsider.com.pl/wiadomosci/net-billing-po-nowemu-kiedy-oplaca-sie-fotowoltaika/jmsv7mb](https://businessinsider.com.pl/wiadomosci/net-billing-po-nowemu-kiedy-oplaca-sie-fotowoltaika/jmsv7mb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T08:26:13+00:00

Od 1 lipca 2024 r. system net-billing w Polsce opiera się na dynamicznych godzinowych cenach rynkowych energii elektrycznej. Zmiana ta ma istotny wpływ na rentowność inwestycji w fotowoltaikę — podkreśla w rozmowie z Portalem Samorządowym Bartłomiej Jaworski, senior product manager w firmie Eaton.

## Euro w Polsce — wady i zalety
 - [https://businessinsider.com.pl/poradnik-finansowy/euro-w-polsce-wady-i-zalety/h92xkjt](https://businessinsider.com.pl/poradnik-finansowy/euro-w-polsce-wady-i-zalety/h92xkjt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T07:58:00+00:00

Temat wprowadzenia euro w Polsce budzi skrajne emocje. Polacy obawiają się przede wszystkim wzrostu cen, jednak wielu z nich dostrzega również korzyści, takie jak niższe koszty transakcyjne, tańsze kredyty i większa liczba inwestycji. Przeprowadzone w 2021 roku badanie Eurobarometr wskazywało, że połowa Polaków jest pozytywnie nastawiona do tego pomysłu.

## Padł rekord internetu w szybkości transferu. "100 mln razy szybciej niż wymaga Netflix"
 - [https://businessinsider.com.pl/technologie/nowe-technologie/padl-rekord-internetu-w-szybkosci-transferu-100-mln-razy-szybciej-niz-wymaga-netflix/033wvhz](https://businessinsider.com.pl/technologie/nowe-technologie/padl-rekord-internetu-w-szybkosci-transferu-100-mln-razy-szybciej-niz-wymaga-netflix/033wvhz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T07:54:55+00:00

Międzynarodowy zespół naukowców pod kierownictwem ekspertów z japońskiego Narodowego Instytutu Technologii Informacyjnych i Komunikacyjnych ustanowił nowy rekord w prędkości przesyłu danych przez internet. Wyniki badań pokazują, że prędkość przesyłu danych osiągnęła 402 terabity na sekundę. To o ponad 100 terabitów więcej niż poprzedni rekord ustanowiony przez ten sam zespół na początku tego roku.

## Autostrady na Słowacji — opłaty i przepisy
 - [https://businessinsider.com.pl/poradnik-finansowy/autostrady-na-slowacji-oplaty-i-przepisy/qxderk7](https://businessinsider.com.pl/poradnik-finansowy/autostrady-na-slowacji-oplaty-i-przepisy/qxderk7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T07:54:23+00:00

W 2023 roku Polacy stanowili 13,5 proc. wszystkich zagranicznych turystów odwiedzających Słowację. Polska znajduje się na drugim miejscu pod względem liczby odwiedzających ten kraj. W ubiegłym roku na Słowację przyjechało ponad 282 tys. Polaków, co stanowiło wzrost o 49 proc. w porównaniu do 2022 roku oraz o 18 proc. więcej niż w 2019 roku. Wielu Polaków podróżuje tam swoim własnym samochodem. Z czym jednak trzeba się liczyć, podróżując po tym kraju samochodem?

## Górale przeszarżowali z cenami nieruchomości. Teraz muszą je spektakularnie obniżać
 - [https://businessinsider.com.pl/wiadomosci/gorale-przeszarzowali-z-cenami-nieruchomosci-teraz-musza-je-spektakularnie-obnizac/50qvwwt](https://businessinsider.com.pl/wiadomosci/gorale-przeszarzowali-z-cenami-nieruchomosci-teraz-musza-je-spektakularnie-obnizac/50qvwwt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T07:41:30+00:00

Klienci wolą Hiszpanię, a nawet Meksyk od Zakopanego — mówi portalowi zakopane.wyborcza.pl agentka nieruchomości. Jak czytamy, na Podhalu najem turystom przestał się opłacać, brakuje więc też klientów na same nieruchomości, a ceny lecą w dół nawet o 40 proc.

## Popularne sklepy z zarzutami UOKiK
 - [https://businessinsider.com.pl/wiadomosci/popularne-sklepy-z-zarzutami-uokik/s6jj29l](https://businessinsider.com.pl/wiadomosci/popularne-sklepy-z-zarzutami-uokik/s6jj29l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T07:34:59+00:00

Prezes UOKiK wszczął postępowanie przeciwko AzaGroup – właścicielowi sklepów internetowych Renee.pl i Born2Be.pl. Chodzi o prezentowanie tych sklepach promocji — m.in. brakowało informacji o najniższej cenie z 30 dni przed obniżką. Kara, jaką może otrzymać firma, może być bolesna.

## Nowe przepisy uderzą w miliony Polaków. Chodzi o węgiel
 - [https://businessinsider.com.pl/wiadomosci/nowe-przepisy-uderza-w-miliony-polakow-chodzi-o-wegiel/8qm7jrs](https://businessinsider.com.pl/wiadomosci/nowe-przepisy-uderza-w-miliony-polakow-chodzi-o-wegiel/8qm7jrs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T07:07:14+00:00

Nowe wymagania jakościowe dla paliw stałych mogą spowodować znaczące podniesienie się w krótkim czasie cen węgla — podaje portalsamorządowy.pl.

## Rewolucja w Polsacie. Po latach będzie mieć śniadaniówkę
 - [https://businessinsider.com.pl/biznes/media/rewolucja-w-polsacie-po-latach-bedzie-miec-sniadaniowke/7g7pq5q](https://businessinsider.com.pl/biznes/media/rewolucja-w-polsacie-po-latach-bedzie-miec-sniadaniowke/7g7pq5q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T06:38:40+00:00

"Halo, tu Polsat" — pod taką nazwą emitowany ma być program śniadaniowy Telewizji Polsat. Na antenie ma pojawić się pod koniec sierpnia.

## Zapowiedzi stały się faktem. Pracownicy fabryki pod Łodzią dostają wypowiedzenia
 - [https://businessinsider.com.pl/wiadomosci/zapowiedzi-staly-sie-faktem-pracownicy-fabryki-pod-lodzia-dostaja-wypowiedzenia/6lctdgp](https://businessinsider.com.pl/wiadomosci/zapowiedzi-staly-sie-faktem-pracownicy-fabryki-pod-lodzia-dostaja-wypowiedzenia/6lctdgp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T06:24:48+00:00

Od maja wiadomo było, że szwajcarski koncern ABB będzie wygaszał produkcję w Aleksandrowie Łódzkim. Jak informuje lodz.wyborcza.pl, proces zwolnień właśnie się rozpoczął. Pracę ma stracić w sumie 400 osób.

## Od 2 lipca kupowanie mieszkań od deweloperów jest bezpieczniejsze. Weszły nowe przepisy
 - [https://businessinsider.com.pl/wiadomosci/od-2-lipca-kupowanie-mieszkan-od-deweloperow-jest-bezpieczniejsze/9pqcg77](https://businessinsider.com.pl/wiadomosci/od-2-lipca-kupowanie-mieszkan-od-deweloperow-jest-bezpieczniejsze/9pqcg77)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:57:15+00:00

Od 2 lipca 2024 r. każda osoba fizyczna kupująca dom lub mieszkanie na podstawie umowy deweloperskiej będzie objęta ochroną Deweloperskiego Funduszu Gwarancyjnego (DFG). To oznacza, że nabywcy mają gwarantowany zwrot wszystkich środków wpłaconych na poczet zakupu, co znacznie zwiększa bezpieczeństwo takich transakcji.

## Niemcy ogłoszą w Warszawie odszkodowania dla ofiar nazizmu
 - [https://businessinsider.com.pl/wiadomosci/niemcy-oglosza-w-warszawie-odszkodowania-dla-ofiar-nazizmu/6n4pfbb](https://businessinsider.com.pl/wiadomosci/niemcy-oglosza-w-warszawie-odszkodowania-dla-ofiar-nazizmu/6n4pfbb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:18:53+00:00

We wtorek w Warszawie odbędą się pierwsze konsultacje międzyrządowe między Polską a Niemcami. Kanclerz Niemiec Olaf Scholz ogłosić ma odszkodowania dla ofiar nazizmu.

## Marnowane miliony złotych w IPN. Dosadny raport po kontroli
 - [https://businessinsider.com.pl/wiadomosci/marnowane-miliony-zlotych-w-ipn-dosadny-raport-po-kontroli/h91v76f](https://businessinsider.com.pl/wiadomosci/marnowane-miliony-zlotych-w-ipn-dosadny-raport-po-kontroli/h91v76f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:17:47+00:00

Instytut Pamięci Narodowej (IPN) przez osiem miesięcy płacił prawie milion złotych miesięcznie za wynajem niewykorzystywanych pomieszczeń, które miały stanowić nową siedzibę Centralnego Przystanku Historia (CPH). Te i inne kontrowersyjne wydatki ujawniła Najwyższa Izba Kontroli (NIK) w swoim wystąpieniu pokontrolnym.

## Kurs JPY/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-jena-japonskiego-dzisiaj-po-ile-jest-jen-japonski-2-lipca-2024-r/zc3742p](https://businessinsider.com.pl/gielda/kursy-walut/kurs-jena-japonskiego-dzisiaj-po-ile-jest-jen-japonski-2-lipca-2024-r/zc3742p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:02:56+00:00

Jadąc do Japonii czy to w celach turystycznych, czy też biznesowych, warto znać aktualny kurs jena (JPY). Z tego artykułu dowiesz się, jaki jest aktualny kurs japońskiej waluty na dzień 2 lipca 2024, a także jak kurs zmienia się w ujęciu tygodniowym. Ułatwi to podjąć decyzję, kiedy kupić jeny.

## Kurs EUR/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-dzisiaj-po-ile-jest-euro-2-lipca-2024-r/thgwkd5](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-dzisiaj-po-ile-jest-euro-2-lipca-2024-r/thgwkd5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:02:45+00:00

Oto bieżący kurs waluty euro na dzień 2 lipca 2024. Euro to obecnie najważniejsza waluta w Unii Europejskiej, a od kursu euro uzależniona jest cena wielu importowanych i eksportowanych towarów i produktów. Jak wyglądają jej aktualne notowania oraz ile wynosi wartość względem złotówki? Wczoraj kurs euro wynosił: 4,3264 zł.

## Kurs USD/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-amerykanskiego-dzisiaj-po-ile-jest-dolar-amerykanski-2-lipca-2024-r/0hz2jt4](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-amerykanskiego-dzisiaj-po-ile-jest-dolar-amerykanski-2-lipca-2024-r/0hz2jt4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:02:35+00:00

Zobacz zmiany kursu USD/PLN dla dnia 2 lipca 2024. Jak dziś wygląda siła amerykańskiej waluty względem złotego? Jaką wartość ma jedna z głównych walut, w której przeprowadzane są międzynarodowe transakcje? Czy dziś opłaca się wymieniać USD na polskie złotówki? Wczoraj wartość dolara wyniosła: 4,0323 zł.

## Kurs CHF/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-szwajcarskiego-dzisiaj-po-ile-jest-frank-szwajcarski-2-lipca-2024-r/dwh2pme](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-szwajcarskiego-dzisiaj-po-ile-jest-frank-szwajcarski-2-lipca-2024-r/dwh2pme)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:02:24+00:00

Oto bieżące notowania kursu franka szwajcarskiego (CHF). Poznaj, jak zmienia się kurs franka w stosunku do polskiej waluty (PLN). Czy polska waluta umacnia się, czy osłabia? Wczoraj kurs franka wynosił: 4,4633 zł. O dzisiejszych zmianach dowiesz się z tego artykułu.

## Kurs GBP/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-funtow-brytyjskich-dzisiaj-po-ile-jest-funt-brytyjski-2-lipca-2024-r/p73hbvb](https://businessinsider.com.pl/gielda/kursy-walut/kurs-funtow-brytyjskich-dzisiaj-po-ile-jest-funt-brytyjski-2-lipca-2024-r/p73hbvb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:02:14+00:00

Chcesz sprawdzić, jaki jest kurs GBP na dziś 2 lipca 2024? Interesują cię bieżące notowania waluty? Jesteś w odpowiednim miejscu. Poniżej sprawdzisz, czy złotówka umacnia się, czy słabnie względem funta brytyjskiego. Wczorajszy kurs wynosił 5,0945 zł. Warto wiedzieć jak kurs wymiany prezentuje się dziś.

## Kurs CZK/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-korony-czeskiej-dzisiaj-po-ile-jest-korona-czeska-2-lipca-2024-r/r6pj6tm](https://businessinsider.com.pl/gielda/kursy-walut/kurs-korony-czeskiej-dzisiaj-po-ile-jest-korona-czeska-2-lipca-2024-r/r6pj6tm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:02:03+00:00

Poznaj kurs korony czeskiej na dzień 2 lipca 2024r. Jak wyglądają jej aktualne notowania oraz ile wynosi wartość korony względem złotego? Wczoraj kurs korony czeskiej wynosił: 0,1724 zł.

## Kurs NOK/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-korony-norweskiej-dzisiaj-po-ile-jest-korona-norweska-2-lipca-2024-r/zydkxj2](https://businessinsider.com.pl/gielda/kursy-walut/kurs-korony-norweskiej-dzisiaj-po-ile-jest-korona-norweska-2-lipca-2024-r/zydkxj2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:01:53+00:00

Jak zmienił się kurs korony norweskiej od wczoraj? Czy złoty słabnie, czy może umacnia się względem waluty Norwegów? To ważna informacja dla wszystkich, którzy aktualnie pracują lub wybierają się do Skandynawii. Sprawdź, jak dziś prezentuje się kurs NOK.

## Kurs SEK/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-korony-szwedzkiej-dzisiaj-po-ile-jest-korona-szwedzka-2-lipca-2024-r/syncv34](https://businessinsider.com.pl/gielda/kursy-walut/kurs-korony-szwedzkiej-dzisiaj-po-ile-jest-korona-szwedzka-2-lipca-2024-r/syncv34)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:01:42+00:00

Prezentujemy aktualne notowania kursu korony szwedzkiej  do złotego oraz zmiany w ujęciu tygodniowym i dziennym na dzień 2 lipca 2024. Wczoraj kurs SEK wynosił 0,3798 zł. Więcej informacji o kursie znajdziesz w tym artykule.

## Kurs DKK/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-korony-dunskiej-dzisiaj-po-ile-jest-korona-dunska-2-lipca-2024-r/hy3stwb](https://businessinsider.com.pl/gielda/kursy-walut/kurs-korony-dunskiej-dzisiaj-po-ile-jest-korona-dunska-2-lipca-2024-r/hy3stwb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:01:32+00:00

Jeśli potrzebujesz informacji o kursie korony duńskiej, warto śledzić nasze bieżące notowania. Aby dokonać korzystnych transakcji wymiany walut sprawdź, jak kurs DKK wygląda dnia 2 lipca 2024.

## Kurs HUF/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-forinta-wegierskiego-dzisiaj-po-ile-jest-forint-wegierski-2-lipca-2024-r/netd9m7](https://businessinsider.com.pl/gielda/kursy-walut/kurs-forinta-wegierskiego-dzisiaj-po-ile-jest-forint-wegierski-2-lipca-2024-r/netd9m7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:01:20+00:00

Zobacz kurs węgierskiego forinta 2 lipca 2024 w odniesieniu do polskiej waluty. W tym artkule sprawdzisz, czy HUF umacnia się, czy traci do PLN nie tylko dzień do dnia, ale także w perspektywie tygodniowej. Wczoraj kurs węgierskiej waluty wynosił 1,0945 zł.

## Kurs TRY/PLN 2 lipca 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-liry-turckiej-dzisiaj-po-ile-jest-lira-turecka-2-lipca-2024-r/6r9bk34](https://businessinsider.com.pl/gielda/kursy-walut/kurs-liry-turckiej-dzisiaj-po-ile-jest-lira-turecka-2-lipca-2024-r/6r9bk34)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:01:09+00:00

Oto bieżący kurs liry tureckiej. Poznaj wahania waluty Turcji w ujęciu dziennym, a także tygodniowym. Aktualny kurs liry warto poznać m.in. przed wyjazdem na wakacje do jednego z tureckich kurortów.

## Zawrotne pensje dla specjalistów od ChatGPT. Kto i na ile może liczyć?
 - [https://businessinsider.com.pl/wiadomosci/zawrotne-pensje-dla-specjalistow-od-chatgpt-kto-i-na-ile-moze-liczyc/7yet9jx](https://businessinsider.com.pl/wiadomosci/zawrotne-pensje-dla-specjalistow-od-chatgpt-kto-i-na-ile-moze-liczyc/7yet9jx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T05:00:00+00:00

Zanim sztuczna inteligencja zabierze nam pracę, najpierw pozwoli dobrze zarobić, ale tylko tym, którzy naprawdę wiedzą, jak z niej korzystać. Pensje? Sześciocyfrowe stawki to nie jest szczyt możliwości. I nie chodzi tylko o programistów.

## Pieniądze szczęścia nie dają, ale bywają warunkiem przetrwania. Czy Senat to zrozumie? [OPINIA]
 - [https://businessinsider.com.pl/prawo/opinie/kluczowa-decyzja-senatu-w-sprawie-mediow-w-polsce-opinia/87x31wn](https://businessinsider.com.pl/prawo/opinie/kluczowa-decyzja-senatu-w-sprawie-mediow-w-polsce-opinia/87x31wn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T04:56:00+00:00

W demokracji kluczowe są media, czyli dziennikarze. Dlatego zdaniem prof. Michała Romanowskiego większość parlamentarna Koalicji 15 października ma moralny i konstytucyjny obowiązek wesprzeć media w negocjacjach z Big Techami. Zgodnie bowiem z art. 14 Konstytucji Rzeczpospolita Polska zapewnia wolność prasy i innych środków społecznego przekazu. — Mam nadzieję, że Senat RP to zrozumie — podkreśla prof. Michał Romanowski

## ZUS wydaje coraz więcej na cudzoziemców
 - [https://businessinsider.com.pl/wiadomosci/zus-wydaje-coraz-wiecej-na-cudzoziemcow/nr50zhn](https://businessinsider.com.pl/wiadomosci/zus-wydaje-coraz-wiecej-na-cudzoziemcow/nr50zhn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T04:55:36+00:00

Same wydatki na zasiłki chorobowe wzrosły z 41,8 mln zł w 2015 r. do 374,6 mln zł na koniec 2023 r. Nasz system wciąż jednak na tym korzysta, a nie traci – pisze wtorkowa "Rzeczpospolita".

## Drewno do palenia ograniczone. Rząd wprowadza zmiany
 - [https://businessinsider.com.pl/wiadomosci/drewno-do-palenia-ograniczone-rzad-wprowadza-zmiany/y297bw5](https://businessinsider.com.pl/wiadomosci/drewno-do-palenia-ograniczone-rzad-wprowadza-zmiany/y297bw5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T04:35:16+00:00

"Dziennik Gazeta Prawna" dotarł do projektu zmiany przepisów, które mają ograniczyć spalanie drewna w energetyce. Ma temu służyć zdefiniowanie kategorii tzw. drewna energetycznego.

## Jak uzyskać licencję na wynajem apartamentu w Hiszpanii? Czytelnik pyta, ekspertka odpowiada
 - [https://businessinsider.com.pl/nieruchomosci/jak-uzyskac-licencje-na-wynajem-turystyczny-w-hiszpanii/wb8rqbf](https://businessinsider.com.pl/nieruchomosci/jak-uzyskac-licencje-na-wynajem-turystyczny-w-hiszpanii/wb8rqbf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T04:35:00+00:00

Interesuje mnie czy licencja na wynajmowanie apartamentu w Hiszpanii jest przywiązana do nieruchomości, czy do właściciela? Na jakich zasadach wyrabia się takie licencje? — pyta pan Wojciech, czytelnik Business Insidera. Prawniczka i agentka nieruchomości z Alicante odpowiada, w jaki sposób przenieść taką licencję na siebie lub jak wyrobić nową i na co trzeba uważać.

## Zabraknie nam zielonej energii do produkcji wodoru. Orlen policzył
 - [https://businessinsider.com.pl/gospodarka/zabraknie-nam-zielonej-energii-do-produkcji-wodoru-orlen-policzyl/l0tkv97](https://businessinsider.com.pl/gospodarka/zabraknie-nam-zielonej-energii-do-produkcji-wodoru-orlen-policzyl/l0tkv97)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T04:24:52+00:00

W najbliższej dekadzie popyt na bezemisyjny wodór, produkowany z wykorzystaniem zielonej energii, gwałtownie wzrośnie. Polska nie będzie jednak w stanie zaspokoić tego zapotrzebowania z powodu niewystarczającej ilości instalacji OZE — wynika z raportu przygotowanego przez Orlen i S&amp;P Global. Paliwowy koncern apeluje o rozbudowę mocy OZE i infrastruktury wodorowej, a ponadto już prowadzi rozmowy w sprawie importu wodoru z innych regionów świata.

## Wiceministra Niemiec o zielonej transformacji: w Europie czasami sami siebie nie doceniamy [WYWIAD]
 - [https://businessinsider.com.pl/gospodarka/wiceministra-niemiec-o-zielonej-transformacji-w-europie-czasami-sami-siebie-nie/9gz8jdz](https://businessinsider.com.pl/gospodarka/wiceministra-niemiec-o-zielonej-transformacji-w-europie-czasami-sami-siebie-nie/9gz8jdz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T04:21:39+00:00

Zielony Ład zapewnił Europie wyjątkowo dobrą pozycję na świecie, umożliwił rozwój gospodarczy, przy jednoczesnej dekarbonizacji. Musimy też oczywiście patrzeć na nasze działania przez pryzmat społeczny. Przyznam jednak, że gdy rozmawiam z firmami niemieckimi, ale też z polskimi, to tak naprawdę mają jeden postulat — utrzymać kurs, ponieważ już zainwestowały w dekarbonizację — mówi Jennifer Morgan, pełnomocniczka Federalnego Ministerstwa Spraw Zagranicznych ds. międzynarodowej polityki klimatycznej Niemiec. W rozmowie z Business Insider Polska mówi o odchodzeniu od węgla, przyszłości unijnego przemysłu i podejściu Niemiec do budowy elektrowni jądrowej w Polsce.

## Problem Putina wewnątrz Rosji. Kreml zajął się wojną, nie radzi sobie z zamachami
 - [https://businessinsider.com.pl/wiadomosci/nowy-problem-putina-kreml-zajal-sie-wojna-nie-radzi-sobie-z-zamachami/4xfjtpn](https://businessinsider.com.pl/wiadomosci/nowy-problem-putina-kreml-zajal-sie-wojna-nie-radzi-sobie-z-zamachami/4xfjtpn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T04:12:21+00:00

Po atakach na prawosławne kościoły i synagogi w Dagestanie, w których zginęło ok. 20 osób, pojawiły się głosy wątpliwości co do bezpieczeństwa wewnętrznego Rosji, która kontynuuje wojnę w Ukrainie. Eksperci powiedzieli Business Insiderowi, że rosyjskie służby prawdopodobnie były "rozproszone" przez inwazję.

## Czy Polska płonie? Straż pożarna przedstawia nam dane
 - [https://businessinsider.com.pl/wiadomosci/czy-polska-plonie-straz-pozarna-przedstawia-nam-dane/k4sfc3j](https://businessinsider.com.pl/wiadomosci/czy-polska-plonie-straz-pozarna-przedstawia-nam-dane/k4sfc3j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T04:10:01+00:00

Marywilska 44, kluczowe zakłady spółek Skarbu Państwa, wielkie hale magazynowe... Ostatnio w Polsce mamy prawdziwą falę tajemniczych pożarów. Rzecznik prasowy komendanta głównego PSP zapewnia jednak Business Insider Polska, że sama liczba pożarów niepokoju nie budzi. W niektórych kategoriach pożarów jest wręcz wyraźnie mniej niż w ostatnich latach.

## Żłobki drożeją, a to dopiero początek. "Prywaciarze czekają na babciowe"
 - [https://businessinsider.com.pl/biznes/zlobki-drozeja-a-to-dopiero-poczatek-czekaja-na-babciowe/ktdk2g4](https://businessinsider.com.pl/biznes/zlobki-drozeja-a-to-dopiero-poczatek-czekaja-na-babciowe/ktdk2g4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-07-02T04:05:26+00:00

Od lipca publiczne żłobki są minimalnie droższe. To jednak nic w porównaniu z prywatnymi placówkami, które jesienią planują znacznie bardziej dotkliwe podwyżki. — Kierowniczka wprost powiedziała, że jak wejdzie babciowe, to ona podniesie czesne. To dla nich będą żniwa — słyszymy od pani Joanny, która posyła syna do prywatnej placówki.

