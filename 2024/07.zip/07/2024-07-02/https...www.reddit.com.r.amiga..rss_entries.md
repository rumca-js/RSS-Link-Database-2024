# Source:Amiga, URL:https://www.reddit.com/r/amiga/.rss, language:en

## i forgot i even still own these games, so glad i still have them, took them out of storage to clean...sadly the box of the amigacd32 had mold on it, so had to throw it, but everything else is fine, it works well.
 - [https://www.reddit.com/r/amiga/comments/1dtt01n/i_forgot_i_even_still_own_these_games_so_glad_i](https://www.reddit.com/r/amiga/comments/1dtt01n/i_forgot_i_even_still_own_these_games_so_glad_i)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-02T18:29:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1dtt01n/i_forgot_i_even_still_own_these_games_so_glad_i/"> <img alt="i forgot i even still own these games, so glad i still have them, took them out of storage to clean...sadly the box of the amigacd32 had mold on it, so had to throw it, but everything else is fine, it works well." src="https://preview.redd.it/5uzmf2o7f5ad1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bc4039f2820dc4a3693e867da8f10b72854aa1c1" title="i forgot i even still own these games, so glad i still have them, took them out of storage to clean...sadly the box of the amigacd32 had mold on it, so had to throw it, but everything else is fine, it works well." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/2old4ZisShit"> /u/2old4ZisShit </a> <br /> <span><a href="https://i.redd.it/5uzmf2o7f5ad1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1dtt01n/i_forgot_i_even_still_own_these

## Unboxing and Reviewing the A600GS: A New Amiga Classic 68k Computer from AmigaKit
 - [https://www.reddit.com/r/amiga/comments/1dtrivq/unboxing_and_reviewing_the_a600gs_a_new_amiga](https://www.reddit.com/r/amiga/comments/1dtrivq/unboxing_and_reviewing_the_a600gs_a_new_amiga)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-02T17:28:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1dtrivq/unboxing_and_reviewing_the_a600gs_a_new_amiga/"> <img alt="Unboxing and Reviewing the A600GS: A New Amiga Classic 68k Computer from AmigaKit" src="https://external-preview.redd.it/kjWVBJFSNpIFXnpv01XpdoUpfiiQhaziQp1etugOOuE.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=fc213fffa3ae590d97c95ee17744d4d7558af84b" title="Unboxing and Reviewing the A600GS: A New Amiga Classic 68k Computer from AmigaKit" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Marcio_D"> /u/Marcio_D </a> <br /> <span><a href="https://www.youtube.com/watch?v=lOU3gSKnAfY">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1dtrivq/unboxing_and_reviewing_the_a600gs_a_new_amiga/">[comments]</a></span> </td></tr></table>

## Ep. 47 Unboxing & playing Leaderboard Birdie Amiga game [Ελληνικά]
 - [https://www.reddit.com/r/amiga/comments/1dtdmlr/ep_47_unboxing_playing_leaderboard_birdie_amiga](https://www.reddit.com/r/amiga/comments/1dtdmlr/ep_47_unboxing_playing_leaderboard_birdie_amiga)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-07-02T04:52:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1dtdmlr/ep_47_unboxing_playing_leaderboard_birdie_amiga/"> <img alt="Ep. 47 Unboxing &amp; playing Leaderboard Birdie Amiga game [Ελληνικά]" src="https://external-preview.redd.it/H1-3oGQzCvSuRClLH6gPFxDinVg2UWqHEMFtG4VUUuY.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=4d414f7ab41c6d07634923b6586f1e9b4b556d15" title="Ep. 47 Unboxing &amp; playing Leaderboard Birdie Amiga game [Ελληνικά]" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Leader Board is an Amiga golf sports game released in 1986 by Access Software.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GreekRetroMan"> /u/GreekRetroMan </a> <br /> <span><a href="https://youtu.be/xXaT8hr9eSA">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1dtdmlr/ep_47_unboxing_playing_leaderboard_birdie_amiga/">[comments]</a></span> </td></tr></table>

