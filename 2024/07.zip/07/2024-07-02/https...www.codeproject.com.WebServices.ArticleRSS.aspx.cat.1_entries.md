# Source:CodeProject Latest Articles, URL:https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1, language:en-us

## ARC4 Encryption Library
 - [https://www.codeproject.com/Articles/5319044/ARC4-Encryption-Library](https://www.codeproject.com/Articles/5319044/ARC4-Encryption-Library)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-07-02T16:32:00+00:00

ARC4 (Alleged RC4) Cryptography Provider Class Library

## A Rational .NET Class
 - [https://www.codeproject.com/Tips/5359855/A-Rational-NET-Class](https://www.codeproject.com/Tips/5359855/A-Rational-NET-Class)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-07-02T15:58:00+00:00

A rational class to extend numeric functionality

## A Simple Continued Fraction Calculator
 - [https://www.codeproject.com/Tips/5384624/A-Simple-Continued-Fraction-Calculator](https://www.codeproject.com/Tips/5384624/A-Simple-Continued-Fraction-Calculator)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-07-02T14:06:00+00:00

Basic operations (-, +, *, /) of two finite simple continued fractions

