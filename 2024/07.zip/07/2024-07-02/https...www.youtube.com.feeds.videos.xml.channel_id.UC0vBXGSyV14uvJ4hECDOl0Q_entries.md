# Source:Techquickie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q, language:en-US

## FIVE Cool Things To Do With Old PC Parts
 - [https://www.youtube.com/watch?v=iQxHEkbwqzY](https://www.youtube.com/watch?v=iQxHEkbwqzY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q
 - date published: 2024-07-02T18:38:07+00:00

https://ifix.gd/techquickie724

Save $10 on orders of $50 or more at iFixit! with code TQFIX at the link above, but act quick because the sale is only on for 48 hours after this video goes live! (US & Canada only)

So, you upgraded your PC, and now you have a bunch of old PC hardware sitting around. Here are some ideas for what to do with that old system!

Leave a reply with your requests for future episodes.

► GET MERCH: https://lttstore.com
► GET A VPN: https://www.piavpn.com/TechQuickie
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

