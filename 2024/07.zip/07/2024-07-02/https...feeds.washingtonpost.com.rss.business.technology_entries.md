# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## A TikToker made sunscreen from scratch. We tried her recipe.
 - [https://www.washingtonpost.com/wellness/2024/07/02/nara-smith-sunscreen](https://www.washingtonpost.com/wellness/2024/07/02/nara-smith-sunscreen)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-07-02T19:50:15+00:00

Nara Smith has repeatedly gone viral for her homemade creations, but dermatologists say you should stick with FDA-approved sunscreen.

## This is the most pointless website on the planet. It’s fantastic.
 - [https://www.washingtonpost.com/technology/2024/07/02/one-million-checkboxes-pointless-fun](https://www.washingtonpost.com/technology/2024/07/02/one-million-checkboxes-pointless-fun)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-07-02T16:30:00+00:00

We all deserve uncomplicated joy.

