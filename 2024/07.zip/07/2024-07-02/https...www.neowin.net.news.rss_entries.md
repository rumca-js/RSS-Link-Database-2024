# Source:Neowin, URL:https://www.neowin.net/news/rss, language:en-us

## Early Amazon Prime Day deal offers three months of Audible Premium Plus for free
 - [https://www.neowin.net/deals/early-amazon-prime-day-deal-offers-three-months-of-audible-premium-plus-for-free](https://www.neowin.net/deals/early-amazon-prime-day-deal-offers-three-months-of-audible-premium-plus-for-free)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T22:12:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719956976_audible-logo_medium.jpg" /></div>If you are an Amazon Prime member and have never subscribed to an Audible audiobook subscription, you can currently get three months of Audible Premium Plus for free for a limited time. <a href="https://www.neowin.net/deals/early-amazon-prime-day-deal-offers-three-months-of-audible-premium-plus-for-free/">Read more...</a>

## A major Xbox Live outage is currently happening; there's no word on when it might be fixed
 - [https://www.neowin.net/news/a-major-xbox-live-outage-is-currently-happening-theres-no-word-on-when-it-might-be-fixed](https://www.neowin.net/news/a-major-xbox-live-outage-is-currently-happening-theres-no-word-on-when-it-might-be-fixed)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T21:17:22+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2018/01/1515111697_xboxlive_medium.jpg" /></div>If you cannot sign into your Xbox Live account, it&#039;s not just you. Microsoft is currently experiencing a major issue that is preventing many users from accessing the online gaming service. <a href="https://www.neowin.net/news/a-major-xbox-live-outage-is-currently-happening-theres-no-word-on-when-it-might-be-fixed/">Read more...</a>

## Netflix begins to get rid of its cheapest ad-free plan in some markets
 - [https://www.neowin.net/news/netflix-begins-to-get-rid-of-its-cheapest-ad-free-plan-in-some-markets](https://www.neowin.net/news/netflix-begins-to-get-rid-of-its-cheapest-ad-free-plan-in-some-markets)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T21:08:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/12/1671122989_nflx_medium.jpg" /></div>Online reports from Netflix users in Canada and the UK claim that the streaming service is making people who subscribe to its cheapest ad-free plan switch to another plan to remain on the service. <a href="https://www.neowin.net/news/netflix-begins-to-get-rid-of-its-cheapest-ad-free-plan-in-some-markets/">Read more...</a>

## KB5039448: Microsoft released 1st Windows 11 24H2 (2024 update) setup upgrade
 - [https://www.neowin.net/news/kb5039448-microsoft-released-1st-windows-11-24h2-2024-update-setup-upgrade](https://www.neowin.net/news/kb5039448-microsoft-released-1st-windows-11-24h2-2024-update-setup-upgrade)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T20:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701448091_windows_11_24h2_medium.jpg" /></div>Microsoft took many by surprise when it released Windows 11 24H2 early this past month. Following that, the company has also released a new WinRE update and Setup improvements update for it. <a href="https://www.neowin.net/news/kb5039448-microsoft-released-1st-windows-11-24h2-2024-update-setup-upgrade/">Read more...</a>

## Microsoft updates Excel on the web with a revamped user interface
 - [https://www.neowin.net/news/microsoft-updates-excel-on-the-web-with-a-revamped-user-interface](https://www.neowin.net/news/microsoft-updates-excel-on-the-web-with-a-revamped-user-interface)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T19:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/03/1553427262_excel1_medium.jpg" /></div>Microsoft is rolling out a new user interface for Excel on the web. It allows users of the spreadsheet web app to quickly add or resize columns and rows in the app, along with other improvements. <a href="https://www.neowin.net/news/microsoft-updates-excel-on-the-web-with-a-revamped-user-interface/">Read more...</a>

## Suno AI music and song generator app now available for iOS devices
 - [https://www.neowin.net/news/suno-ai-music-and-song-generator-app-now-available-for-ios-devices](https://www.neowin.net/news/suno-ai-music-and-song-generator-app-now-available-for-ios-devices)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T19:04:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719944808_suno_for_ios_medium.jpg" /></div>Suno, a popular AI music and song generator service used by over 12 million people, has launched its first mobile app for iOS devices. Users can generate songs up to 4 minutes long. <a href="https://www.neowin.net/news/suno-ai-music-and-song-generator-app-now-available-for-ios-devices/">Read more...</a>

## The new Meta 3D Gen can generate high-quality 3D assets from text in less than a minute
 - [https://www.neowin.net/news/the-new-meta-3d-gen-can-generate-high-quality-3d-assets-from-text-in-less-than-a-minute](https://www.neowin.net/news/the-new-meta-3d-gen-can-generate-high-quality-3d-assets-from-text-in-less-than-a-minute)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T17:50:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719938731_meta_3d_gen_medium.jpg" /></div>Meta introduced a groundbreaking system called Meta 3D Gen (3DGen) that revolutionizes 3D asset creation. This innovative technology utilizes text prompts to generate high-quality 3D assets. <a href="https://www.neowin.net/news/the-new-meta-3d-gen-can-generate-high-quality-3d-assets-from-text-in-less-than-a-minute/">Read more...</a>

## Apple is expecting over 100 million iPhone 16 sales, raises chip orders
 - [https://www.neowin.net/news/apple-is-expecting-over-100-million-iphone-16-sales-raises-chip-orders](https://www.neowin.net/news/apple-is-expecting-over-100-million-iphone-16-sales-raises-chip-orders)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T17:34:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/04/1714478386_iphone-16-hero_medium.jpg" /></div>The latest report from China suggests that Apple is expecting very strong sales and has ordered chip producer TSMC to produce 90 to 100 million A18 processors for the iPhone 16 series this year. <a href="https://www.neowin.net/news/apple-is-expecting-over-100-million-iphone-16-sales-raises-chip-orders/">Read more...</a>

## Save up to 61% on Windscribe VPN Pro Plan subscriptions
 - [https://www.neowin.net/deals/save-up-to-61-off-windscribe-vpn-pro-subscriptions](https://www.neowin.net/deals/save-up-to-61-off-windscribe-vpn-pro-subscriptions)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T17:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2018/04/1523446954_snag-0002_medium.jpg" /></div>With today&#039;s highlighted deal, you can pick up a 1, 2, or 3-year subscription to Windscribe VPN Pro on the cheap. Hello, private browsing! Protect your browser and desktop with this complete Pro VPN! <a href="https://www.neowin.net/deals/save-up-to-61-off-windscribe-vpn-pro-subscriptions/">Read more...</a>

## PowerToys 0.82 brings new features and improvements for existing modules
 - [https://www.neowin.net/news/powertoys-082-brings-new-features-and-improvements-for-existing-modules](https://www.neowin.net/news/powertoys-082-brings-new-features-and-improvements-for-existing-modules)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T16:44:18+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/06/1685715551_2_medium.jpg" /></div>Microsoft is rolling out a new update for PowerToys. Version 0.82 is now available, and it brings improvements and new features for existing modules, such as PowerRename, Advanced Paste, and more. <a href="https://www.neowin.net/news/powertoys-082-brings-new-features-and-improvements-for-existing-modules/">Read more...</a>

## Microsoft Flight Simulator targets Northeastern United States for latest City Update
 - [https://www.neowin.net/news/microsoft-flight-simulator-targets-northeastern-united-states-for-latest-city-update](https://www.neowin.net/news/microsoft-flight-simulator-targets-northeastern-united-states-for-latest-city-update)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T15:48:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719934358_msfs_cu09_nosnipe_nologo_notext_medium.jpg" /></div>Microsoft has released a brand-new Microsoft Flight Simulator update, and this one is upgrading the visuals Washington, DC region; Buffalo, New York; Allentown, Pennsylvania, and more. <a href="https://www.neowin.net/news/microsoft-flight-simulator-targets-northeastern-united-states-for-latest-city-update/">Read more...</a>

## Snapdragon 8 Gen 4 could support DLSS-like upscaling for games on Samsung Galaxy S25 series
 - [https://www.neowin.net/news/snapdragon-8-gen-4-could-support-dlss-like-upscaling-for-games-on-samsung-galaxy-s25-series](https://www.neowin.net/news/snapdragon-8-gen-4-could-support-dlss-like-upscaling-for-games-on-samsung-galaxy-s25-series)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T15:32:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718290345_galaxy-s24-hero_medium.jpg" /></div>If the latest rumor is to be believed then the upcoming Samsung Galaxy S25 series powered by the Snapdragon 8 Gen 4 processor could unlock DLSS-like AI upscaling, to sharpen the graphics of games. <a href="https://www.neowin.net/news/snapdragon-8-gen-4-could-support-dlss-like-upscaling-for-games-on-samsung-galaxy-s25-series/">Read more...</a>

## Apple announces several India-specific features for iOS 18
 - [https://www.neowin.net/news/apple-announces-several-india-specific-features-for-ios-18](https://www.neowin.net/news/apple-announces-several-india-specific-features-for-ios-18)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T15:16:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719925947_apple_ios_18_india_specific_features_medium.jpg" /></div>Apple revealed an array of India-centric features in the upcoming iOS 18 update, set to launch this fall. These include personalized lockscreens with numerals from 12 Indian languages. <a href="https://www.neowin.net/news/apple-announces-several-india-specific-features-for-ios-18/">Read more...</a>

## Samsung's new Galaxy A35 5G is 13% off on Amazon and at its lowest price
 - [https://www.neowin.net/deals/samsungs-new-galaxy-a35-5g-is-13-off-on-amazon-and-at-its-lowest-price](https://www.neowin.net/deals/samsungs-new-galaxy-a35-5g-is-13-off-on-amazon-and-at-its-lowest-price)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T14:16:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719925132_71oznggxhcl._ac_sl1500__medium.jpg" /></div>You can now get the Samsung Galaxy A35 5G, which is only a few months old, for just $349.99. It&#039;s down 13% from its list price of $399.99. It has a focus on improved cameras and security. <a href="https://www.neowin.net/deals/samsungs-new-galaxy-a35-5g-is-13-off-on-amazon-and-at-its-lowest-price/">Read more...</a>

## Neon White, Tchia, Nickelodeon All-Star Brawl 2, and more head to Xbox Game Pass
 - [https://www.neowin.net/news/neon-white-tchia-nickelodeon-all-star-brawl-2-and-more-head-to-xbox-game-pass](https://www.neowin.net/news/neon-white-tchia-nickelodeon-all-star-brawl-2-and-more-head-to-xbox-game-pass)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T13:46:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719927060_coming-soon_7.2.2024-ba299b402050c6b8131c_medium.jpg" /></div>The first half of July for Xbox Game Pass members will be filled with well-received hits like Neon White, Journey to the Savage Planet, and Tchia, plus day one titles like Flock and Magical Delicacy. <a href="https://www.neowin.net/news/neon-white-tchia-nickelodeon-all-star-brawl-2-and-more-head-to-xbox-game-pass/">Read more...</a>

## The TCL 50C641K 50-inch QLED 4K TV is just £289 after 24% discount
 - [https://www.neowin.net/deals/the-tcl-50c641k-50-inch-qled-4k-tv-is-just-289-after-24-discount](https://www.neowin.net/deals/the-tcl-50c641k-50-inch-qled-4k-tv-is-just-289-after-24-discount)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T12:24:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719921404_71tykbirvbl._ac_sl1500__medium.jpg" /></div>If you&#039;re after a new TV, then have a look at the TCL 50C641K, a 50-inch QLED 4K TV. RIght now it&#039;s discounted down by 24% meaning you pay just £289 instead of the original RRP of £379. <a href="https://www.neowin.net/deals/the-tcl-50c641k-50-inch-qled-4k-tv-is-just-289-after-24-discount/">Read more...</a>

## Microsoft and IBM announce improved cybersecurity partnership
 - [https://www.neowin.net/news/microsoft-and-ibm-announce-improved-cybersecurity-partnership](https://www.neowin.net/news/microsoft-and-ibm-announce-improved-cybersecurity-partnership)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T09:24:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719906689_microsoft_ibm_security_medium.jpg" /></div>IBM Consulting will help clients optimize their security operations to maximize the value of Microsoft&#039;s end-to-end security solutions. The partnership has a new solution for cloud identity protection <a href="https://www.neowin.net/news/microsoft-and-ibm-announce-improved-cybersecurity-partnership/">Read more...</a>

## KB5041137: Microsoft released 1st recovery update for Windows 11 24H2 (2024 update)
 - [https://www.neowin.net/news/kb5041137-microsoft-released-1st-recovery-update-for-windows-11-24h2-2024-update](https://www.neowin.net/news/kb5041137-microsoft-released-1st-recovery-update-for-windows-11-24h2-2024-update)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T09:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1715260473_1_medium.jpg" /></div>Microsoft took many by surprise when it released Windows 11 24H2 early this past month. Following that, the company has also released a new recovery environment (WinRE) update for it. <a href="https://www.neowin.net/news/kb5041137-microsoft-released-1st-recovery-update-for-windows-11-24h2-2024-update/">Read more...</a>

## 8TB Seagate Starfield Special Edition External HDD drops to its lowest price once again
 - [https://www.neowin.net/deals/8tb-seagate-starfield-special-edition-external-hdd-drops-to-its-lowest-price-once-again](https://www.neowin.net/deals/8tb-seagate-starfield-special-edition-external-hdd-drops-to-its-lowest-price-once-again)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T08:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719905346_1-1-large-640x640_medium.jpg" /></div>The 8TB Seagate Starfield Special Edition External HDD is back to its lowest price on Amazon US so, get it while its still in stock and upgrade your external storage solution today. <a href="https://www.neowin.net/deals/8tb-seagate-starfield-special-edition-external-hdd-drops-to-its-lowest-price-once-again/">Read more...</a>

## Windows 11 is close to becoming most popular OS on Steam
 - [https://www.neowin.net/news/windows-11-is-close-to-becoming-most-popular-os-on-steam](https://www.neowin.net/news/windows-11-is-close-to-becoming-most-popular-os-on-steam)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T07:16:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1714631433_steam_medium.jpg" /></div>While Windows 11 has an overall much smaller market share than Windows 10, on the gaming side, things are going better. Valve reports that Windows 11 is very close to overtaking Windows 10 on Steam. <a href="https://www.neowin.net/news/windows-11-is-close-to-becoming-most-popular-os-on-steam/">Read more...</a>

## Limited Time Deal: Samsung 990 EVO SSD drops to its new all-time low price on Amazon
 - [https://www.neowin.net/deals/limited-time-deal-samsung-990-evo-ssd-drops-to-its-new-all-time-low-price-on-amazon](https://www.neowin.net/deals/limited-time-deal-samsung-990-evo-ssd-drops-to-its-new-all-time-low-price-on-amazon)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T07:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1706028060_samsung_990_evo_medium.jpg" /></div>Today, you can get your hands on the Samsung 990 EVO NVMe Internal Solid-state Drive, which is currently selling at its lowest price to date, with a limited time deal on Amazon US. So, grab one now! <a href="https://www.neowin.net/deals/limited-time-deal-samsung-990-evo-ssd-drops-to-its-new-all-time-low-price-on-amazon/">Read more...</a>

## Google Pixel 9 may come with a better OLED display than the Galaxy S24 series
 - [https://www.neowin.net/news/google-pixel-9-may-come-with-a-better-oled-display-than-the-galaxy-s24-series](https://www.neowin.net/news/google-pixel-9-may-come-with-a-better-oled-display-than-the-galaxy-s24-series)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T06:44:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1719381728_pixel-9-series-teaser_medium.jpg" /></div>It is believed that the upcoming Google Pixel 9 series phones will be equipped with the M14 OLED display produced by Samsung Display, which is better than the display found in the Galaxy S24 series. <a href="https://www.neowin.net/news/google-pixel-9-may-come-with-a-better-oled-display-than-the-galaxy-s24-series/">Read more...</a>

## Microsoft confirms OneDrive shared folders are indeed turning into internet shortcuts
 - [https://www.neowin.net/news/microsoft-confirms-onedrive-shared-folders-are-indeed-turning-into-internet-shortcuts](https://www.neowin.net/news/microsoft-confirms-onedrive-shared-folders-are-indeed-turning-into-internet-shortcuts)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T06:28:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/11/1668763767_onedrive_alert_medium.jpg" /></div>OneDrive users recently began complaining that their shared folders were converting to internet shortcuts. Now, Microsoft has published details about the bug and confirmed it is looking into it. <a href="https://www.neowin.net/news/microsoft-confirms-onedrive-shared-folders-are-indeed-turning-into-internet-shortcuts/">Read more...</a>

## Former Microsoft CEO Steve Ballmer is now richer than Bill Gates
 - [https://www.neowin.net/news/former-microsoft-ceo-steve-ballmer-is-now-richer-than-bill-gates](https://www.neowin.net/news/former-microsoft-ceo-steve-ballmer-is-now-richer-than-bill-gates)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T06:12:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719898452_steve_ballmer_medium.jpg" /></div>Steve Ballmer, former Microsoft CEO, has surpassed Bill Gates to become the sixth richest person globally, with a net worth of $157.2 billion. This milestone is attributed to two main factors. <a href="https://www.neowin.net/news/former-microsoft-ceo-steve-ballmer-is-now-richer-than-bill-gates/">Read more...</a>

## Samsung Galaxy S24 FE could be available in multiple colors including black and yellow
 - [https://www.neowin.net/news/samsung-galaxy-s24-fe-could-be-available-in-multiple-colors-including-black-and-yellow](https://www.neowin.net/news/samsung-galaxy-s24-fe-could-be-available-in-multiple-colors-including-black-and-yellow)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T05:56:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718468216_samsung-galaxy-s24-fe-design-render-sides-scaled_medium.jpg" /></div>The Samsung Galaxy S24 FE, which is expected to launch later this year, has been reportedly leaked to arrive in multiple color options, including black, the most preferred color among buyers. <a href="https://www.neowin.net/news/samsung-galaxy-s24-fe-could-be-available-in-multiple-colors-including-black-and-yellow/">Read more...</a>

## Get this Kasa EC71 smart indoor pan and tilt security camera for an all new low price
 - [https://www.neowin.net/deals/get-this-kasa-ec71-smart-indoor-pan-and-tilt-security-camera-for-an-all-new-low-price](https://www.neowin.net/deals/get-this-kasa-ec71-smart-indoor-pan-and-tilt-security-camera-for-an-all-new-low-price)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T05:40:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719897940_kasa-smart-camera-1_medium.jpg" /></div>The Kasa EC71 smart indoor pan and tilt security camera has a 1080 resolution, sound and motion detection and night vision. You can get this camera for your home at a new low price of $22.99. <a href="https://www.neowin.net/deals/get-this-kasa-ec71-smart-indoor-pan-and-tilt-security-camera-for-an-all-new-low-price/">Read more...</a>

## Paramount+ could once again attempt to merge with another streaming service
 - [https://www.neowin.net/news/paramount-could-once-again-attempt-to-merge-with-another-streaming-service](https://www.neowin.net/news/paramount-could-once-again-attempt-to-merge-with-another-streaming-service)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T05:24:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/06/1655897186_paramount_logo_medium.jpg" /></div>Paramount Global is reportedly in talks to merge its Paramount+ streaming service with another similar service. Warner Bros Discovery is rumored to be interested in a merger with its own Max service. <a href="https://www.neowin.net/news/paramount-could-once-again-attempt-to-merge-with-another-streaming-service/">Read more...</a>

## Going incognito on the Google app may become easier in the future
 - [https://www.neowin.net/news/going-incognito-on-the-google-app-may-become-easier-in-the-future](https://www.neowin.net/news/going-incognito-on-the-google-app-may-become-easier-in-the-future)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T05:08:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/05/1589921267_google_app_for_android_2_medium.jpg" /></div>In the latest beta, Google has reportedly added a new button that would make going incognito on the Google app easier, negating the need to go through multiple taps to browse privately. <a href="https://www.neowin.net/news/going-incognito-on-the-google-app-may-become-easier-in-the-future/">Read more...</a>

## Capcom confirms that a new Resident Evil game is in development
 - [https://www.neowin.net/news/capcom-confirms-that-a-new-resident-evil-game-is-in-development](https://www.neowin.net/news/capcom-confirms-that-a-new-resident-evil-game-is-in-development)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T04:52:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695635100_capcom-1_medium.jpg" /></div>Capcom confirmed during its Capcom Next streaming event that a new Resident Evil game is in the works. Resident Evil 7: Biohazard director Koshi Nakanishi will be in charge of its development. <a href="https://www.neowin.net/news/capcom-confirms-that-a-new-resident-evil-game-is-in-development/">Read more...</a>

## The Google Pixel 9 may already be on sale unofficially in Algeria
 - [https://www.neowin.net/news/the-google-pixel-9-may-already-be-on-sale-unofficially-in-algeria](https://www.neowin.net/news/the-google-pixel-9-may-already-be-on-sale-unofficially-in-algeria)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T04:36:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1719381728_pixel-9-series-teaser_medium.jpg" /></div>It seems like ahead of Google&#039;s launch of the Pixel 9 series in August, the forthcoming flagship has been allegedly spotted in pink and might already be on sale unofficially in Algeria. <a href="https://www.neowin.net/news/the-google-pixel-9-may-already-be-on-sale-unofficially-in-algeria/">Read more...</a>

## Free streaming service Tubi coming to the UK on TV, iOS, Android, and web
 - [https://www.neowin.net/news/free-streaming-service-tubi-coming-to-the-uk-on-tv-ios-android-and-web](https://www.neowin.net/news/free-streaming-service-tubi-coming-to-the-uk-on-tv-ios-android-and-web)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T04:14:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/07/1719892980_tubi_medium.jpg" /></div>Tubi is coming to the UK, the company has said. It will be available over the next few weeks on TV platforms, iOS, Android, and the Web. It said it has more than 20,000 films and TV episodes. <a href="https://www.neowin.net/news/free-streaming-service-tubi-coming-to-the-uk-on-tv-ios-android-and-web/">Read more...</a>

## Linux Mint 22 Beta has Linux 6.8, Cinnamon 6.2, new wallpapers, and better Software Manager
 - [https://www.neowin.net/news/linux-mint-22-beta-has-linux-68-cinnamon-62-new-wallpapers-and-better-software-manager](https://www.neowin.net/news/linux-mint-22-beta-has-linux-68-cinnamon-62-new-wallpapers-and-better-software-manager)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-07-02T01:30:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/03/1647812943_linux-mint_medium.jpg" /></div>The Beta version of Linux Mint 22 &quot;Wilma&quot; has been released. It comes with lots of changes but end users won&#039;t see too much that&#039;s new. A lack of radical changes makes it a good choice for some. <a href="https://www.neowin.net/news/linux-mint-22-beta-has-linux-68-cinnamon-62-new-wallpapers-and-better-software-manager/">Read more...</a>

