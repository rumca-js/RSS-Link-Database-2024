# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Rozwinął się najszybciej historii, sieje spustoszenie na swojej drodze. "Totalna dewastacja"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/huragan-beryl-rozwinal-sie-najszybciej-historii-sieje-spustoszenie-na-swojej-drodze-st7988465?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/huragan-beryl-rozwinal-sie-najszybciej-historii-sieje-spustoszenie-na-swojej-drodze-st7988465?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T19:29:20+00:00

<img alt="Rozwinął się najszybciej historii, sieje spustoszenie na swojej drodze. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-1385046-zuber-ph7988469/alternates/LANDSCAPE_1280" />
    Huragan Beryl przetacza się nad Karaibami i niszczy wszystko na swojej drodze. Wiatr wieje z prędkością nawet 290 kilometrów na godzinę i niemal wymyka się skali. Meteorolodzy już kwalifikują go do huraganu 5. kategorii, choć wcześniej prognozowano, że będzie to tylko burza tropikalna.

## Prześwietlili ceny mieszkań w ponad 50 krajach. Polska na podium
 - [https://tvn24.pl/biznes/nieruchomosci/ceny-mieszkan-w-polsce-wzrosly-nominalnie-o-13-proc-w-ciagu-ostatnich-12-miesiecy-polska-przoduje-we-wzroscie-cen-mieszkan-na-swiecie-st7987977?source=rss](https://tvn24.pl/biznes/nieruchomosci/ceny-mieszkan-w-polsce-wzrosly-nominalnie-o-13-proc-w-ciagu-ostatnich-12-miesiecy-polska-przoduje-we-wzroscie-cen-mieszkan-na-swiecie-st7987977?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T19:27:51+00:00

<img alt="Prześwietlili ceny mieszkań w ponad 50 krajach. Polska na podium" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b4n2df-mieszkanie-mieszkania-dom-shutterstock1535109122-4553010/alternates/LANDSCAPE_1280" />
    Ceny mieszkań w Polsce wzrosły nominalnie o 13 procent w ciągu ostatnich 12 miesięcy - wynika z raportu Knight Frank. Jest to trzeci wynik wśród 56 rynków mieszkaniowych na świecie analizowanych przez firmę.

## Polki coraz częściej wybierają cesarskie cięcie. Główny powód to zła wycena znieczulenia przy porodzie
 - [https://fakty.tvn24.pl/zobacz-fakty/polki-coraz-czesciej-wybieraja-cesarskie-ciecie-glowny-powod-to-zla-wycena-znieczulenia-przy-porodzie-st7988414?source=rss](https://fakty.tvn24.pl/zobacz-fakty/polki-coraz-czesciej-wybieraja-cesarskie-ciecie-glowny-powod-to-zla-wycena-znieczulenia-przy-porodzie-st7988414?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T19:12:56+00:00

<img alt="Polki coraz częściej wybierają cesarskie cięcie. Główny powód to zła wycena znieczulenia przy porodzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3dw254-noworodek-dlon-raczka-matka-szpital-shutterstock1968250909-5511112/alternates/LANDSCAPE_1280" />
    Światowa Organizacja Zdrowia zaleca, by cesarek było średnio 15 procent. W Polsce jest to 50 procent. Dlaczego tak się dzieje? Lekarze wskazują, że kobiety nie chcą cierpieć w trakcie porodu, bo wciąż jest problem ze znieczuleniem zewnątrzoponowym. Jak informuje Ministerstwo Zdrowia, w 2023 roku zaledwie 17 procent porodów naturalnych było w Polsce znieczulanych.

## Pogoda na juro - środa, 3.07. W nocy i za dnia przydadzą się parasole
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-juro-sroda-307-w-nocy-i-za-dnia-przydadza-sie-parasole-st7988397?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-juro-sroda-307-w-nocy-i-za-dnia-przydadza-sie-parasole-st7988397?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T19:11:22+00:00

<img alt="Pogoda na juro - środa, 3.07. W nocy i za dnia przydadzą się parasole" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x0amdv-deszcz-7020018/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na środę 3.07. W nocy termometry pokażą miejscami zaledwie 10 stopni Celsjusza. W dzień wystąpią przelotne opady deszczu. Warunki biometeorologiczne będą przeważnie niekorzystne.

## Pogoda na jutro - środa, 3.07. W nocy i za dnia przydadzą się parasole
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sroda-307-w-nocy-i-za-dnia-przydadza-sie-parasole-st7988397?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sroda-307-w-nocy-i-za-dnia-przydadza-sie-parasole-st7988397?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T19:11:22+00:00

<img alt="Pogoda na jutro - środa, 3.07. W nocy i za dnia przydadzą się parasole" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x0amdv-deszcz-7020018/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na środę 3.07. W nocy termometry pokażą miejscami zaledwie 10 stopni Celsjusza. W dzień wystąpią przelotne opady deszczu. Warunki biometeorologiczne będą przeważnie niekorzystne.

## Setki gróźb i obelg wobec Służby Więziennej. "To jakaś obłędna historia"
 - [https://tvn24.pl/polska/setki-grozb-i-obelg-wobec-sluzby-wieziennej-to-jakas-obledna-historia-st7988368?source=rss](https://tvn24.pl/polska/setki-grozb-i-obelg-wobec-sluzby-wieziennej-to-jakas-obledna-historia-st7988368?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T19:07:19+00:00

<img alt="Setki gróźb i obelg wobec Służby Więziennej. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2134521-02-2000-kropka-gosc-0027-ph7988380/alternates/LANDSCAPE_1280" />
    Służba Więzienna poinformowała, że otrzymała kilkaset gróźb i obelg w związku z rzekomym znieważaniem zatrzymanego księdza Michała O. - Służba Więzienna traktuje go ze szczególną ochroną, a w wyniku państwa ataków, histerii, grożą im ludzie - mówił w "Kropce nad i" Arkadiusz Myrcha (KO), zwracając się do Kazimierza Smolińskiego z PiS. Ten stwierdził, że w liście dotyczącym rzekomego traktowania Michała O. przez służby "jest informacja, że były działania bardzo złe i były działania dobre".

## "Chyba taką perłą w koronie była właśnie Fundacja Profeto"
 - [https://tvn24.pl/polska/chyba-taka-perla-w-koronie-byla-wlasnie-fundacja-profeto-st7988373?source=rss](https://tvn24.pl/polska/chyba-taka-perla-w-koronie-byla-wlasnie-fundacja-profeto-st7988373?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T19:00:24+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9400122-fpf-2-ph7988356/alternates/LANDSCAPE_1280" />
    Piotr W., czyli generalny wykonawca ośrodka, który budowała Fundacja Profeto, opowiedział nam o ustawionym konkursie z Funduszu Sprawiedliwości - relacjonowała "Faktach po Faktach" Maria Pankowska z OKO.press, dodając, że wcześniej można było to podejrzewać. Według Sebastiana Klauzińskiego z nowych ustaleń wyłania się obraz Funduszu, który służył "do tego, żeby wspierać swoich". - A chyba taką perłą w koronie tego była właśnie Fundacja Profeto - podkreślił.

## "Duda na szczęście nie będzie mógł tego blokować"
 - [https://tvn24.pl/biznes/z-kraju/reparacje-wojenne-dariusz-rosati-na-antenie-tvn24-st7988318?source=rss](https://tvn24.pl/biznes/z-kraju/reparacje-wojenne-dariusz-rosati-na-antenie-tvn24-st7988318?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T18:25:58+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-322147-fpf-1-ph7988351/alternates/LANDSCAPE_1280" />
    Rozumiem, że jest przestrzeń do zadośćuczynienia na gruncie etycznym, moralnym i politycznym. - powiedział w programie "Fakty po Faktach" na antenie TVN24 były minister spraw zagranicznych Dariusz Rosati, pytany o kwestię reparacji wojennych od Niemiec. Jak dodał "podejście PiS i Jarosława Kaczyńskiego gwarantowało, że niczego się nie załatwi".

## Gigantyczne pensje w Orlenie pod lupą prokuratury. "Każdy, kto złamał prawo, zostanie postawiony przed sądem"
 - [https://fakty.tvn24.pl/zobacz-fakty/gigantyczne-pensje-w-orlenie-pod-lupa-prokuratury-kazdy-kto-zlamal-prawo-zostanie-postawiony-przed-sadem-st7988363?source=rss](https://fakty.tvn24.pl/zobacz-fakty/gigantyczne-pensje-w-orlenie-pod-lupa-prokuratury-kazdy-kto-zlamal-prawo-zostanie-postawiony-przed-sadem-st7988363?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T18:22:34+00:00

<img alt="Gigantyczne pensje w Orlenie pod lupą prokuratury. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1156358-pap202305310dz-ph7978171/alternates/LANDSCAPE_1280" />
    Prokuratura nadzorowana przez Zbigniewa Ziobrę umorzyła śledztwo - nie chciała zbadać gigantycznych zarobków w Orlenie, także Daniela Obajtka. Chodzi o ponad osiem milionów złotych wydane z pominięciem tak zwanej ustawy kominowej. Teraz jednak prokuratura wraca do sprawy i zainteresowała się też Jackiem Sasinem, który nadzorował Orlen.

## Powalone drzewo i zablokowane torowisko tramwajowe
 - [https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-powalone-drzewo-i-zablokowane-torowisko-tramwajowe-na-pradze-st7988352?source=rss](https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-powalone-drzewo-i-zablokowane-torowisko-tramwajowe-na-pradze-st7988352?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T18:06:07+00:00

<img alt="Powalone drzewo i zablokowane torowisko tramwajowe " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-803554-strazacy-usuwaja-powalone-drzewo-na-pradze-ph7988341/alternates/LANDSCAPE_1280" />
    Zarząd Transportu Miejskiego poinformował o wieczornych utrudnieniach w kursowaniu tramwajów w rejonie skrzyżowania Kawęczyńskiej z Wojnicką. Na miejscu strażacy usuwają powalone drzewo.

## Wicepremier o możliwych atakach w Polsce. Amerykanie "mają taką samą diagnozę"
 - [https://tvn24.pl/polska/wicepremier-o-mozliwych-atakach-w-polsce-amerykanie-maja-taka-sama-diagnoze-st7988292?source=rss](https://tvn24.pl/polska/wicepremier-o-mozliwych-atakach-w-polsce-amerykanie-maja-taka-sama-diagnoze-st7988292?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T17:54:19+00:00

<img alt="Wicepremier o możliwych atakach w Polsce. Amerykanie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9923508-zrzut-ekranu-2024-07-2-o-19-ph7988321/alternates/LANDSCAPE_1280" />
    Polska jest dziś najbardziej atakowanym państwem Unii Europejskiej - powiedział we wtorek wicepremier i minister cyfryzacji Krzysztof Gawkowski po spotkaniu z przedstawicielami Białego Domu. Ogłosił, że USA i Polska zacieśnią współpracę w zakresie cyberbezpieczeństwa.

## Wjechał w ludzi na chodniku. Lądował śmigłowiec LPR
 - [https://tvn24.pl/trojmiasto/gdynia-wjechal-w-ludzi-na-chodniku-ladowal-smiglowiec-lpr-st7988275?source=rss](https://tvn24.pl/trojmiasto/gdynia-wjechal-w-ludzi-na-chodniku-ladowal-smiglowiec-lpr-st7988275?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T16:58:28+00:00

<img alt="Wjechał w ludzi na chodniku. Lądował śmigłowiec LPR" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5032463-skrzyzowanie-ulic-zofii-nalkowskiej-i-wielkopolskiej-w-gdyni-ph7988280/alternates/LANDSCAPE_1280" />
    Z nieustalonych przyczyn 70-letni kierowca wjechał lexusem na chodnik i potrącił trzy osoby w Gdyni. Na miejscu lądował śmigłowiec Lotniczego Pogotowia Ratunkowego. Policja wyjaśnia, dlaczego doszło do wypadku.

## Wjechał na przejazd kolejowy mimo czerwonego światła. Nie wiedział, że ominął nieoznakowany radiowóz
 - [https://tvn24.pl/tvnwarszawa/ulice/chrominie-na-oczach-policjantow-wjechal-na-tory-mimo-czerwonego-swiatla-st7988222?source=rss](https://tvn24.pl/tvnwarszawa/ulice/chrominie-na-oczach-policjantow-wjechal-na-tory-mimo-czerwonego-swiatla-st7988222?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T16:48:43+00:00

<img alt="Wjechał na przejazd kolejowy mimo czerwonego światła. Nie wiedział, że ominął nieoznakowany radiowóz " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8268677-wjechal-na-przejazd-kolejowy-mimo-czerwonego-swiatla-ph7988212/alternates/LANDSCAPE_1280" />
    Kamera nieoznakowanego policyjnego radiowozu grupy speed nagrała niebezpieczny manewr kierowcy toyoty. 57-latek ominął nieoznakowany radiowóz, który zatrzymał się przed przejazdem kolejowym, gdy sygnalizator nadawał pulsujące czerwone światło.

## Bank niesłusznie pobierał opłaty od klientów. "Błąd systemu"
 - [https://tvn24.pl/biznes/pieniadze/alior-bank-pobieral-z-konta-nieuzasadnione-oplaty-teraz-wyjasnia-st7988229?source=rss](https://tvn24.pl/biznes/pieniadze/alior-bank-pobieral-z-konta-nieuzasadnione-oplaty-teraz-wyjasnia-st7988229?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T16:47:27+00:00

<img alt="Bank niesłusznie pobierał opłaty od klientów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jh8da1-komputer-klawiatura-kobieta-shutterstock178115075-3960052/alternates/LANDSCAPE_1280" />
    Alior Bank niesłusznie pobierał od niektórych klientów dodatkowe opłaty. Sygnał o nieprawidłowościach otrzymaliśmy na Kontakt 24. Bank potwierdził tę informację i podkreślił, że pracuje nad zwrotem pieniędzy.

## Drzwi się otworzyły, windy nie było. Młoda kobieta zginęła na miejscu
 - [https://tvn24.pl/swiat/drzwi-sie-otworzyly-windy-nie-bylo-mloda-wloszka-zginela-na-miejscu-st7987999?source=rss](https://tvn24.pl/swiat/drzwi-sie-otworzyly-windy-nie-bylo-mloda-wloszka-zginela-na-miejscu-st7987999?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T16:00:57+00:00

<img alt="Drzwi się otworzyły, windy nie było. Młoda kobieta zginęła na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2565556-winda-fasano-ph7988198/alternates/LANDSCAPE_1280" />
    25-letnia Włoszka zginęła, gdy chcąc wsiąść do windy nie zauważyła, że za otwartymi drzwiami znajduje się pustka - informują włoskie media. Do tragedii doszło w mieście Fasano na południu kraju, Clelia Ditano spadła z wysokości 15 metrów. Policja ustala teraz, dlaczego drzwi się otworzyły, choć windy nie było na jej piętrze.

## Weszły wyższe cła na produkty z Rosji i Białorusi
 - [https://tvn24.pl/biznes/z-kraju/wyzsze-cla-na-produkty-z-rosji-i-bialorusi-od-1-lipca-st7988147?source=rss](https://tvn24.pl/biznes/z-kraju/wyzsze-cla-na-produkty-z-rosji-i-bialorusi-od-1-lipca-st7988147?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T15:42:37+00:00

<img alt="Weszły wyższe cła na produkty z Rosji i Białorusi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fcrtsk-droga-korek-ciezarowka-ciezarowki-tir-shutterstock_1677084745-7861735/alternates/LANDSCAPE_1280" />
    Od 1 lipca obowiązuje rozporządzenie Rady Unii Europejskiej podwyższające cła na rosyjskie i białoruskie zboża, nasiona oleiste i produkty pochodne, a także inne produkty - przekazało Ministerstwo Rolnictwa i Rozwoju Wsi (MRiRW).

## Pół miliona Polaków wróciło za Morawieckiego, "do dwóch milionów" wyjechało za PO? Sprawdzamy
 - [https://konkret24.tvn24.pl/polityka/pol-miliona-polakow-wrocilo-za-morawieckiego-do-dwoch-milionow-wyjechalo-za-po-sprawdzamy-st7986602?source=rss](https://konkret24.tvn24.pl/polityka/pol-miliona-polakow-wrocilo-za-morawieckiego-do-dwoch-milionow-wyjechalo-za-po-sprawdzamy-st7986602?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T15:40:10+00:00

<img alt="Pół miliona Polaków wróciło za Morawieckiego, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1142953-mateusz-morawiecki-ph7985737/alternates/LANDSCAPE_1280" />
    Mateusz Morawiecki uważa, że za jego rządów do Polski wróciło "pół miliona Polaków, którzy wyjechali za Tuska". Jak dodał, za rządów Platformy Obywatelskiej z kraju miało wyjechać od miliona do dwóch milionów Polaków. Sprawdziliśmy dane GUS o migracji. Po raz kolejny nie potwierdzają słów byłego premiera.

## Coraz więcej Polaków żyje w skrajnym ubóstwie. Tak źle nie było od 2015 roku
 - [https://fakty.tvn24.pl/fakty-po-poludniu/coraz-wiecej-polakow-zyje-w-skrajnym-ubostwie-tak-zle-nie-bylo-od-2015-roku-st7988181?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/coraz-wiecej-polakow-zyje-w-skrajnym-ubostwie-tak-zle-nie-bylo-od-2015-roku-st7988181?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T15:39:53+00:00

<img alt="Coraz więcej Polaków żyje w skrajnym ubóstwie. Tak źle nie było od 2015 roku" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-3285044-czepita-ph7988214/alternates/LANDSCAPE_1280" />
    Najnowszy raport Głównego Urzędu Statystycznego pokazuje, że wskaźnik skrajnego ubóstwa w Polsce wzrósł o 2 punkty procentowe, osiągając poziom 6,6 procent. Tak źle nie było od 2015 roku, czyli przed wprowadzeniem świadczenia 500 plus, kiedy wskaźnik ten wynosił 6,5 procent. Eksperci winą obarczają poprzedni rząd, wskazując, że zaniedbał politykę społeczną.

## Zniszczyła 70 szydełkowych czapeczek na przydrożnych słupkach. 53-latkę nagrały kamery
 - [https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-niszczyla-slupkowe-czapeczki-bo-jej-sie-nie-podobaly-nagranie-st7988197?source=rss](https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-niszczyla-slupkowe-czapeczki-bo-jej-sie-nie-podobaly-nagranie-st7988197?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T15:37:39+00:00

<img alt="Zniszczyła 70 szydełkowych czapeczek na przydrożnych słupkach. 53-latkę nagrały kamery" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8856809-kobieta-wycinala-slupkowe-czapeczki-i-wyrzucala-do-koszy-ph7988192/alternates/LANDSCAPE_1280" />
    Policjanci z Żoliborza zatrzymali kobietę, która pod koniec maja uszkodziła 70 ozdób szydełkowych zamontowanych na słupkach oddzielających jezdnię od chodnika. Jak tłumaczyła policji, odcinała je nożyczkami i wyrzucała, bo jej się nie podobały. Straty oszacowano na blisko pięć tysięcy złotych. Kobieta odpowie za uszkodzenie mienia.

## Kłęby dymu nad rosyjskim składem amunicji
 - [https://tvn24.pl/swiat/krym-zniszczony-sklad-amunicji-sil-rosyjskich-st7988177?source=rss](https://tvn24.pl/swiat/krym-zniszczony-sklad-amunicji-sil-rosyjskich-st7988177?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T15:36:04+00:00

<img alt="Kłęby dymu nad rosyjskim składem amunicji " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8359805-dym-telegram-ph7988179/alternates/LANDSCAPE_1280" />
    Siły ukraińskie zaatakowały skład amunicji na zaanektowanym przez Rosję Krymie. Według kanałów na Telegramie celem była jednostka wojskowa w pobliżu Sewastopola.

## Prezydent pytany o słowa Tuska: nie zgodzę się
 - [https://tvn24.pl/polska/reparacje-od-niemiec-prezydent-pytany-o-slowa-tuska-nie-zgodze-sie-st7988185?source=rss](https://tvn24.pl/polska/reparacje-od-niemiec-prezydent-pytany-o-slowa-tuska-nie-zgodze-sie-st7988185?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T15:32:04+00:00

<img alt="Prezydent pytany o słowa Tuska: nie zgodzę się" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3980493-andrzej-duda-ph7988199/alternates/LANDSCAPE_1280" />
    Nie podzielam stanowiska, że kiedykolwiek polskie władze w sposób skuteczny zrzekły się prawa do roszczeń i zadośćuczynienia za krzywdy, jakie ponieśliśmy w trakcie II wojny światowej - oznajmił prezydent Andrzej Duda. - Jeśli premier zgadza się z niemieckim stanowiskiem, że doszło do jakiegoś zrzeczenia się, to powiem tak: ja się nie zgodzę - podkreślił. We wtorek w Warszawie odbyły się pierwsze od kilku lat konsultacje międzyrządowe Polski i Niemiec.

## Spora część Warszawy wyjęta spod inwestycji przez prawo lotnicze
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-duza-czesc-wyjeta-spod-inwestycji-przez-prawo-lotnicze-st7987452?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-duza-czesc-wyjeta-spod-inwestycji-przez-prawo-lotnicze-st7987452?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T15:02:01+00:00

<img alt="Spora część Warszawy wyjęta spod inwestycji przez prawo lotnicze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5535773-warszawa-panorama-blok-bloki-blokowisko-osiedle-shutterstock1841989894-ph7986266/alternates/LANDSCAPE_1280" />
    Stołeczny ratusz i Unia Metropolii Polskich apelują o zmianę prawa lotniczego w Polsce. Jego obecny kształt powoduje, że na sporym obszarze stolicy nie można stawiać nowych budynków. Poprawka do nowelizacji tego prawa wypadła ostatnio z porządku sejmowych obrad.

## Pijany kierowca i trzeźwy pasażer z prawem jazdy. Ich auto wylądowało w rowie
 - [https://tvn24.pl/tvnwarszawa/ulice/glinojeck-pijany-kierowca-wjechal-do-rowu-st7988148?source=rss](https://tvn24.pl/tvnwarszawa/ulice/glinojeck-pijany-kierowca-wjechal-do-rowu-st7988148?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T15:00:39+00:00

<img alt="Pijany kierowca i trzeźwy pasażer z prawem jazdy. Ich auto wylądowało w rowie " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8709583-kierowca-wjechal-do-rowu-mial-ponad-dwa-promile-zdjecie-ilustracyjne-ph7988161/alternates/LANDSCAPE_1280" />
    W Glinojecku kierowca opla wjechał do rowu. Policjanci po przyjeździe zastali na miejscu nietrzeźwego 48-latka kierującego autem i jego 34-letniego pasażera. Ten drugi był trzeźwy i miał prawo jazdy. Mimo tego pozwolił prowadzić swojemu koledze, który miał ponad dwa promile. Policjantom tłumaczył, że o niczym nie wiedział.

## Nie żyje ponad sto osób. "Zaczęło się zamieszanie, nie wiedzieliśmy, co robić"
 - [https://tvn24.pl/swiat/indie-zaczeli-sie-tratowac-w-czasie-swieta-nie-zyje-ponad-sto-osob-st7987975?source=rss](https://tvn24.pl/swiat/indie-zaczeli-sie-tratowac-w-czasie-swieta-nie-zyje-ponad-sto-osob-st7987975?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T14:49:52+00:00

<img alt="Nie żyje ponad sto osób. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8211202-indie-ph7987959/alternates/LANDSCAPE_1280" />
    Co najmniej 107 osób zginęło w czasie religijnego wydarzenia w indyjskim stanie Uttar Pradesz. Tłum wiernych zaczął tratować się. Według ostatnich informacji zginęło po sto osób. Służby zastrzegają jednak, że ta liczba może wzrosnąć.

## Napięcie na morzu rośnie, Chiny wysłały dumę swojej floty
 - [https://tvn24.pl/swiat/lotniskowiec-shandong-widziany-w-poblizu-filipin-duma-chinskiej-floty-wyslana-po-serii-groznych-incydentow-st7987683?source=rss](https://tvn24.pl/swiat/lotniskowiec-shandong-widziany-w-poblizu-filipin-duma-chinskiej-floty-wyslana-po-serii-groznych-incydentow-st7987683?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T14:37:19+00:00

<img alt="Napięcie na morzu rośnie, Chiny wysłały dumę swojej floty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3596300-chinski-lotniskowiec-shandong-ph7987721/alternates/LANDSCAPE_1280" />
    Chiński lotniskowiec Shandong został wysłany na sporne wody i przepłynął w pobliżu Filipin - informują media, powołując się na zdjęcia satelitarne. Okręt, będący dumą chińskiej floty, odbył rejs w czasie szczególnego wzrostu napięcia w relacjach Chin z Filipinami, które toczą spór terytorialny na Morzu Południowochińskim. Shandong wrócił już na chińskie wody.

## Monika nie żyje. "Ktoś mi zrobił krzywdę"
 - [https://tvn24.pl/poznan/konin-turek-monika-nie-zyje-bala-sie-bylego-partnera-ktory-od-dawna-powinien-siedziec-za-narkotyki-st7987942?source=rss](https://tvn24.pl/poznan/konin-turek-monika-nie-zyje-bala-sie-bylego-partnera-ktory-od-dawna-powinien-siedziec-za-narkotyki-st7987942?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T14:26:38+00:00

<img alt="Monika nie żyje. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4527615-monika-nie-zyje-jej-byly-partner-powinien-byc-w-wiezieniu-ph7987653/alternates/LANDSCAPE_1280" />
    Kiedy umarła Monika, jej były partner miał już sprawę w prokuraturze o jej pobicie, a poza tym od dawna powinien siedzieć w więzieniu za przestępstwa narkotykowe. Mimo sprzeciwu prokuratury rejonowej i sądu rejonowego, sąd okręgowy odroczył karę z powodu złego stanu zdrowia skazanego - aktywnego boksera. Policja stwierdziła, że Monika sama sobie odebrała życie. O okolicznościach tragedii i swoich wątpliwościach rodzina zmarłej opowiedziała w reportażu programu "Uwaga!" TVN.

## Pogoda na 5 dni. Niedługo znów będzie ponad 30 stopni
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-5-dni-niedlugo-znow-bedzie-ponad-30-stopni-kiedy-wroci-upal-st7988067?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-5-dni-niedlugo-znow-bedzie-ponad-30-stopni-kiedy-wroci-upal-st7988067?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T14:21:30+00:00

<img alt="Pogoda na 5 dni. Niedługo znów będzie ponad 30 stopni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2527946-adobestock761517170-ph7988116/alternates/LANDSCAPE_1280" />
    Najbliższe dni przyniosą przelotne opady deszczu. Ale w weekend nastąpi zmiana aury. Napłynie cieplejsze powietrze, które sprawi, że miejscami termometry znów pokażą ponad 30 stopni. Wraz z upałem pojawią się też burze.

## Większy ruch w autosalonach. Te marki wybierano najczęściej
 - [https://tvn24.pl/biznes/moto/rejestracja-aut-osobowych-czerwiec-2024-duza-zmiana-st7988076?source=rss](https://tvn24.pl/biznes/moto/rejestracja-aut-osobowych-czerwiec-2024-duza-zmiana-st7988076?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T14:17:57+00:00

<img alt="Większy ruch w autosalonach. Te marki wybierano najczęściej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ui2qdc-samochody-salon-parking-shutterstock_1859448355-7913432/alternates/LANDSCAPE_1280" />
    Ponad 50 tysięcy aut osobowych zarejestrowano w czerwcu, co oznacza wzrost o 20,7 procent rok do roku - podał Samar w oparciu o dane z Centralnej Ewidencji Pojazdów i Kierowców. W raporcie wskazano, że wzrosła również liczba zarejestrowanych samochodów dostawczych.

## Pasażerowie lotu Air Europe: myśleliśmy, że tam umrzemy
 - [https://tvn24.pl/swiat/pasazerowie-lotu-air-europe-myslelismy-ze-tam-umrzemy-st7987889?source=rss](https://tvn24.pl/swiat/pasazerowie-lotu-air-europe-myslelismy-ze-tam-umrzemy-st7987889?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T14:16:08+00:00

<img alt="Pasażerowie lotu Air Europe: myśleliśmy, że tam umrzemy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-772081-skutki-turbulencji-w-samolocie-linii-air-europa-lecacego-do-urugwaju-ph7987929/alternates/LANDSCAPE_1280" />
    Połamane fotele, ślady krwi na siedzeniach, uszkodzone schowki i zniszczony sufit - taki obraz widać na nagraniu pokazującym skalę zniszczeń po turbulencjach samolotu linii Air Europa. Kilkadziesiąt osób zostało rannych, a maszyna musiała awaryjnie lądować.

## Sędzia związany z Kościołem będzie orzekał w sprawie pedofilii? Pokrzywdzeni chcą go wymienić
 - [https://tvn24.pl/krakow/tarnow-sedzia-zwiazany-z-kosciolem-bedzie-orzekal-w-sprawie-pedofilii-pokrzywdzeni-chca-go-wymienic-st7988058?source=rss](https://tvn24.pl/krakow/tarnow-sedzia-zwiazany-z-kosciolem-bedzie-orzekal-w-sprawie-pedofilii-pokrzywdzeni-chca-go-wymienic-st7988058?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T14:04:41+00:00

<img alt="Sędzia związany z Kościołem będzie orzekał w sprawie pedofilii? Pokrzywdzeni chcą go wymienić" src="https://tvn24.pl/najnowsze/cdn-zdjecie-suqx9m-ksiadz-sebastian-m-zostal-skazany-na-piec-lat-wiezienia-zdjecie-ilustracyjne-6894321/alternates/LANDSCAPE_1280" />
    Wiceszef katolickiej fundacji i znajomy wysoko postawionego duchownego, a zarazem tarnowski sędzia ma orzekać w sprawie zadośćuczynienia, którego byli ministranci żądają od tamtejszej diecezji. Chodzi o 12 milionów złotych - najwyższe w historii polskiego Kościoła odszkodowanie, którego domagają się pokrzywdzeni od kurii. Sprawa dotyczy oskarżonego o molestowanie księdza Mariana W., którego drugi już proces ruszył wiosną.

## Aktywiści klimatyczni: liczymy, że radni odważą się poszerzyć Strefę Czystego Transportu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-aktywisci-klimatyczni-chca-poszerzenia-strefy-czystego-transportu-st7987992?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-aktywisci-klimatyczni-chca-poszerzenia-strefy-czystego-transportu-st7987992?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T14:02:13+00:00

<img alt="Aktywiści klimatyczni: liczymy, że radni odważą się poszerzyć Strefę Czystego Transportu " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-139633-strefa-czystego-transportu-w-warszawie-ph7988081/alternates/LANDSCAPE_1280" />
    Od 1 lipca na siedmiu procentach powierzchni Warszawy obowiązuje Strefa Czystego Transportu. - Pierwszą poprawę jakości powietrza w kanionach ulicznych, miejscach o największym ruchu samochodowym, dostrzeżemy już w najbliższych miesiącach - uważa rzecznik prasowy Polskiego Alarmu Smogowego Piotr Siergiej.

## Salmonella w przedszkolach. 59 dzieci z pozytywnym wynikiem
 - [https://tvn24.pl/katowice/czestochowa-salmonella-w-przedszkolu-61-wynikow-jest-pozytywnych-st7987926?source=rss](https://tvn24.pl/katowice/czestochowa-salmonella-w-przedszkolu-61-wynikow-jest-pozytywnych-st7987926?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T14:01:35+00:00

<img alt="Salmonella w przedszkolach. 59 dzieci z pozytywnym wynikiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5061893-zatrucie-salmonella-w-czestochowskich-przedszkolach-ph7988090/alternates/LANDSCAPE_1280" />
    Zakażenie salmonellą wykryto w dwóch częstochowskich przedszkolach. Jak podaje sanepid, potwierdzono 59 pozytywnych wyników u dzieci i dwa wyniki pozytywne u pracowników. Czwórka dzieci trafiła do szpitala.

## Rosjanie "gubią" bomby nad własnym krajem. Ukraiński wywiad przekazał dowody
 - [https://tvn24.pl/swiat/rosja-samoloty-gubia-bomby-nad-wlasnym-krajem-ukrainski-wywiad-przekazal-dowody-st7987706?source=rss](https://tvn24.pl/swiat/rosja-samoloty-gubia-bomby-nad-wlasnym-krajem-ukrainski-wywiad-przekazal-dowody-st7987706?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T13:53:00+00:00

<img alt="Rosjanie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-29069k-su-24-dwa-rosyjskie-shutterstock_307536143-ph7964105/alternates/LANDSCAPE_1280" />
    Niszczycielskie rosyjskie bomby szybujące wciąż spadają na terytorium Rosji - napisał amerykański dziennik "The Washington Post", powołując się na rosyjski dokument, przechwycony przez ukraiński wywiad. Wynika z niego, że w graniczącym z Ukrainą obwodzie biełgorodzkim w ciągu ostatniego roku spadło co najmniej 38 bomb lotniczych.

## Uciekał przed policją. Wiózł dwójkę dzieci. Nagranie
 - [https://tvn24.pl/bialystok/bialystok-uciekal-przed-policja-juz-drugi-raz-od-kwietnia-teraz-tez-wiozl-dwojke-dzieci-st7988071?source=rss](https://tvn24.pl/bialystok/bialystok-uciekal-przed-policja-juz-drugi-raz-od-kwietnia-teraz-tez-wiozl-dwojke-dzieci-st7988071?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T13:50:27+00:00

<img alt="Uciekał przed policją. Wiózł dwójkę dzieci. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2407971-policja-ruszyla-w-poscig-za-29-latkiem-ph7988023/alternates/LANDSCAPE_1280" />
    29-latek przekroczył dozwoloną prędkość. Gdy zauważył to patrol policji, rozpoczął się pościg ulicami Białegostoku. Kierowca zatrzymał się dopiero, gdy wjechał na osiedle i wbiegł do sklepu. Wiózł dwuletnią dziewczynkę i czteroletniego chłopca. Podobny scenariusz miał też pościg z jego udziałem, do którego doszło w kwietniu. Wtedy też w aucie były małe dzieci.

## Właściciel sklepów internetowych pod lupą UOKiK
 - [https://tvn24.pl/biznes/z-kraju/uokik-wszczal-postepowanie-przeciw-azagroup-wlascicielowi-dwoch-sklepow-internetowych-st7988056?source=rss](https://tvn24.pl/biznes/z-kraju/uokik-wszczal-postepowanie-przeciw-azagroup-wlascicielowi-dwoch-sklepow-internetowych-st7988056?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T13:45:53+00:00

<img alt="Właściciel sklepów internetowych pod lupą UOKiK" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zaxew3-laptop-zakupy-online-7194786/alternates/LANDSCAPE_1280" />
    Prezes Urzędu Ochrony Konkurencji i Konsumenta wszczął postępowanie przeciwko AzaGroup – właścicielowi sklepów internetowych Renee.pl i Born2Be.pl. Wątpliwości dotyczą prezentowania promocji w tych sklepach - podał we wtorek UOKiK w komunikacie. Spółka poinformowała, że deklaruje gotowość do wyjaśnienia wszelkich wątpliwości.

## Internauta pozwany za wpisy po tragedii na A1. Żona Sebastiana M. żąda 200 tys. złotych
 - [https://tvn24.pl/lodz/wypadek-na-a1-pod-piotrkowem-trybunalskim-zona-sebastiana-m-pozywa-internaute-za-ujawnienie-wizerunku-i-nazwanie-jej-morderczynia-st7988050?source=rss](https://tvn24.pl/lodz/wypadek-na-a1-pod-piotrkowem-trybunalskim-zona-sebastiana-m-pozywa-internaute-za-ujawnienie-wizerunku-i-nazwanie-jej-morderczynia-st7988050?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T13:34:11+00:00

<img alt="Internauta pozwany za wpisy po tragedii na A1. Żona Sebastiana M. żąda 200 tys. złotych " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3oee4v-tragiczny-wypadek-na-autostradzie-a1-kolo-piotrkowa-trybunalskiego-7352239/alternates/LANDSCAPE_1280" />
    Żona Sebastiana M., podejrzanego o spowodowanie tragedii, w której zginęło małżeństwo z pięcioletnim dzieckiem, pozwała do sądu internautę, który opublikował w sieci jej wizerunek i nazwał "morderczynią". Pozew - jak poinformowała we wtorek "Gazeta Wyborcza" - trafił do Sądu Okręgowego w Katowicach. W imieniu kobiety złożyła go fundacja Freedom 24.

## Zderzenie dwóch cystern pod Wołominem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/rasztow-zderzenie-dwoch-cystern-st7988047?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/rasztow-zderzenie-dwoch-cystern-st7988047?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T13:25:44+00:00

<img alt="Zderzenie dwóch cystern pod Wołominem" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6847019-zderzenie-dwoch-cystern-pod-wolominem-ph7988038/alternates/LANDSCAPE_1280" />
    W miejscowości Rasztów niedaleko Wołomina doszło do zderzenia dwóch cystern. Nie ma osób poszkodowanych. Są jednak utrudnienia, droga jest zablokowana.

## Akt oskarżenia w sprawie znęcania się nad małymi pacjentami. 11 osób stanie przed sądem
 - [https://tvn24.pl/katowice/kamieniec-akt-oskarzenia-w-sprawie-znecania-sie-nad-malymi-pacjentami-11-osob-stanie-przed-sadem-st7988087?source=rss](https://tvn24.pl/katowice/kamieniec-akt-oskarzenia-w-sprawie-znecania-sie-nad-malymi-pacjentami-11-osob-stanie-przed-sadem-st7988087?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T13:09:00+00:00

<img alt="Akt oskarżenia w sprawie znęcania się nad małymi pacjentami. 11 osób stanie przed sądem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cf1kme-wyrok-dla-stanislawa-k-za-wykorzystywanie-seksualne-dzieci-zdjecie-ilustracyjne-7866034/alternates/LANDSCAPE_1280" />
    11 osób odpowie przed sądem m.in. za fizyczne i psychiczne znęcanie się nad małymi pacjentami Ośrodka Leczniczo-Rehabilitacyjnego "Pałac Kamieniec" w Kamieńcu (Śląskie). Wśród nich jest były dyrektor działającego przy tym ośrodku Zespołu Szkół Specjalnych, wychowawcy i personel medyczny.

## Media: 20-letni Brytyjczyk zaginął w Krakowie. Rodzina prosi o pomoc
 - [https://tvn24.pl/krakow/20-letni-brytyjczyk-zaginal-w-krakowie-rodzina-prosi-o-pomoc-brytyjskie-media-st7987779?source=rss](https://tvn24.pl/krakow/20-letni-brytyjczyk-zaginal-w-krakowie-rodzina-prosi-o-pomoc-brytyjskie-media-st7987779?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T13:00:23+00:00

<img alt="Media: 20-letni Brytyjczyk zaginął w Krakowie. Rodzina prosi o pomoc " src="https://tvn24.pl/najnowsze/cdn-zdjecie-275292-sam-kennedy-zaginal-w-krakowie-ph7987887/alternates/LANDSCAPE_1280" />
    Brytyjskie media informują o zaginięciu 20-letniego Sama Kennedy'ego, który przebywał na wakacjach w Polsce. Mężczyzna miał wrócić z Krakowa do domu w czwartek, ale od tamtej pory nie nawiązał kontaktu z rodziną - twierdzi jego siostra, która prosi o pomoc. Krakowska policja informuje, że zaginięcie 20-latka nie było jej dotąd zgłaszane.

## Alerty o żołnierzach, którzy mogą użyć broni. "Migrantów nie odstraszą, turystów – owszem"
 - [https://tvn24.pl/bialystok/kryzys-na-granicy-z-bialorusia-alerty-o-zolnierzach-ktorzy-moga-uzyc-broni-dostaja-je-rowniez-zagraniczni-turysci-st7987781?source=rss](https://tvn24.pl/bialystok/kryzys-na-granicy-z-bialorusia-alerty-o-zolnierzach-ktorzy-moga-uzyc-broni-dostaja-je-rowniez-zagraniczni-turysci-st7987781?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T12:50:00+00:00

<img alt="Alerty o żołnierzach, którzy mogą użyć broni. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1260061-taka-wiadomosc-otrzymali-zagraniczni-turysci-ph7987990/alternates/LANDSCAPE_1280" />
    Rządowe Centrum Bezpieczeństwa wysyła do osób znajdujących się na terenie powiatów sąsiadujących z granicą z Białorusią smsy z informacją o strefie buforowej. O ile te w języku polskim mówią m.in. o potrzebie stosowania się do poleceń służb, to te w języku angielskim informują, że żołnierze mogą użyć broni. Chodzi o odstraszenie migrantów, ale branża hotelarska alarmuje, że trafiają one również do zagranicznych turystów. Straż Graniczna obiecuje przeanalizować treść smsów.

## Międzynarodowy Festiwal Filmowy Nowe Horyzonty we Wrocławiu coraz bliżej. Znamy program
 - [https://tvn24.pl/kultura-i-styl/miedzynarodowy-festiwal-filmowy-nowe-horyzonty-we-wroclawiu-coraz-blizej-znamy-program-st7987532?source=rss](https://tvn24.pl/kultura-i-styl/miedzynarodowy-festiwal-filmowy-nowe-horyzonty-we-wroclawiu-coraz-blizej-znamy-program-st7987532?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T12:49:48+00:00

<img alt="Międzynarodowy Festiwal Filmowy Nowe Horyzonty we Wrocławiu coraz bliżej. Znamy program" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6141823-love-lies-bleeding-rez-rose-glass-ph7987691/alternates/LANDSCAPE_1280" />
    Międzynarodowy Festiwal Filmowy mBank Nowe Horyzonty we Wrocławiu coraz bliżej. Organizatorzy najbardziej zróżnicowanego przeglądu kina artystycznego oraz odważnego kina środka ogłosili program tegorocznej edycji. To tu po raz pierwszy w Polsce pokazane zostaną głośne tytuły, nagradzane na festiwalach Sundance, Berlinale czy w Cannes. Wśród najciekawiej zapowiadających się premier znalazły się: "Dahomej", "Armand", "Love Lies Bleeding", "Rodzaje życzliwości" czy "Dziewczyna z igłą". Łącznie we Wrocławiu będzie można zobaczyć 285 filmów.

## Produkt wycofany z obrotu. "Zagrożenie dla zdrowia"
 - [https://tvn24.pl/biznes/z-kraju/szklany-kubek-wycofany-z-obrotu-przez-dystrybutora-firme-mondex-st7987824?source=rss](https://tvn24.pl/biznes/z-kraju/szklany-kubek-wycofany-z-obrotu-przez-dystrybutora-firme-mondex-st7987824?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T12:49:24+00:00

<img alt="Produkt wycofany z obrotu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-63k7a1-wozek-sklepowy-6743090/alternates/LANDSCAPE_1280" />
    Stwierdzono wysoki poziomów migracji ołowiu i kadmu z obrzeża partii kubków. Ostrzeżenie o wycofanym produkcie wydał Główny Inspektorat Sanitarny (GIS). W opinii Narodowego Instytutu Zdrowia Publicznego PZH - Państwowego Instytutu Badawczego taka ilość stwarza zagrożenie dla zdrowia.

## Przez korki nie dojechał na przyjęcie do Karola III. Teraz 9-latek odebrał ważne odznaczenie
 - [https://tvn24.pl/swiat/wielka-brytania-przez-korki-nie-odwiedzil-karola-iii-teraz-9-latek-odebral-wazne-odznaczenie-st7987876?source=rss](https://tvn24.pl/swiat/wielka-brytania-przez-korki-nie-odwiedzil-karola-iii-teraz-9-latek-odebral-wazne-odznaczenie-st7987876?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T12:48:40+00:00

<img alt="Przez korki nie dojechał na przyjęcie do Karola III. Teraz 9-latek odebrał ważne odznaczenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5974188-tony-hudgell-i-lyla-odonovan-na-przyjeciu-u-krolowej-kamili-ph7987964/alternates/LANDSCAPE_1280" />
    Dziewięcioletni działacz społeczny Tony Hudgell odebrał z rąk królowej Kamili Medal Imperium Brytyjskiego. Chłopiec otrzymał ponowne zaproszenie do Pałacu Buckingham po tym, jak korki przeszkodziły mu w pojawieniu się na przyjęciu w królewskiej rezydencji w maju.

## Zaczęli się tratować w czasie święta. Nie żyją dziesiątki osób
 - [https://tvn24.pl/swiat/indie-zaczeli-sie-tratowac-w-czasie-swieta-nie-zyja-dziesiatki-osob-st7987975?source=rss](https://tvn24.pl/swiat/indie-zaczeli-sie-tratowac-w-czasie-swieta-nie-zyja-dziesiatki-osob-st7987975?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T12:44:13+00:00

<img alt="Zaczęli się tratować w czasie święta. Nie żyją dziesiątki osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9113825-indie-ph7987956/alternates/LANDSCAPE_1280" />
    Około 60 osób zginęło, gdy tłum wiernych z nieustalonego na razie powodu zaczął tratować się w czasie obchodów religijnych na północy Indii - poinformował rzecznik lokalnej policji, cytowany przez agencję Reutera. Bilans ofiar może wzrosnąć.

## Samochód wjechał w matkę z córką, kobieta zginęła. Nowe informacje o stanie pięciolatki
 - [https://tvn24.pl/krakow/bilczyce-pieciolatka-wybudzona-ze-spiaczki-po-tym-jak-w-rower-prowadzony-przez-jej-matke-wjechal-samochod-st7987858?source=rss](https://tvn24.pl/krakow/bilczyce-pieciolatka-wybudzona-ze-spiaczki-po-tym-jak-w-rower-prowadzony-przez-jej-matke-wjechal-samochod-st7987858?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T12:29:15+00:00

<img alt="Samochód wjechał w matkę z córką, kobieta zginęła. Nowe informacje o stanie pięciolatki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6767543-tragiczny-wypadek-w-bilczycach-ph7987845/alternates/LANDSCAPE_1280" />
    Pięciolatka - pasażerka roweru - potrącona przez samochód w Bilczycach pod Wieliczką wybudziła się ze śpiączki. Jej stan w drugiej dobie po wypadku powoli się poprawia, ale wciąż przebywa ona na oddziale intensywnej terapii. Kierująca rowerem matka dziewczynki zginęła na miejscu. Samochodem jechali pijani mężczyźni. Policja sprawdza, który z nich kierował.

## Kaczyński pytany o swój list do Ziobry. "Specyficzny stan psychiczny"
 - [https://tvn24.pl/polska/kaczynski-pytany-o-swoj-list-do-ziobry-specyficzny-stan-psychiczny-st7987904?source=rss](https://tvn24.pl/polska/kaczynski-pytany-o-swoj-list-do-ziobry-specyficzny-stan-psychiczny-st7987904?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T12:28:27+00:00

<img alt="Kaczyński pytany o swój list do Ziobry. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2448996-jaroslaw-kaczynski-ph7987940/alternates/LANDSCAPE_1280" />
    Jarosław Kaczyński był pytany o list, który miał wysłać do ówczesnego ministra sprawiedliwości Zbigniewa Ziobry w sprawie Funduszu Sprawiedliwości. - Jeżeli list został rzeczywiście wysłany (...), to był wynikiem czegoś, co się zdarza w każdej kampanii wyborczej. Mianowicie tego, że posłowie przeżywają pewien specyficzny stan psychiczny, który powoduje, że strasznie się denerwują tym, co robią inni posłowie - ocenił. Następnie wskazał, co "pisał w tym liście" co "doprowadziło" do jego wysłania.

## Seria pytań do Piebiaka. "Nudny pan jest"
 - [https://tvn24.pl/polska/seria-pytan-do-piebiaka-nudny-pan-jest-st7987792?source=rss](https://tvn24.pl/polska/seria-pytan-do-piebiaka-nudny-pan-jest-st7987792?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T12:22:11+00:00

<img alt="Seria pytań do Piebiaka. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7196457-02-1300-s1cl-0030-ph7987811/alternates/LANDSCAPE_1280" />
    Reporter TVN24 Radomir Wit próbował pytać sędziego Łukasza Piebiaka o aferę hejterską i zarzuty, jakie w tej sprawie chce mu postawić prokuratura. Dziennikarz zadawał byłemu wiceministrowi sprawiedliwości serię pytań w marszu, bo Piebiak nie zatrzymał się do rozmowy. Na pytania nie odpowiadała, mówił jedynie, że reporter jest "nudny" i "nie jest dziennikarzem".

## Pożar w kamienicy, są ranni
 - [https://tvn24.pl/lodz/lodz-pozar-w-kamienicy-przy-ulicy-miedzianej-sa-ranni-st7987867?source=rss](https://tvn24.pl/lodz/lodz-pozar-w-kamienicy-przy-ulicy-miedzianej-sa-ranni-st7987867?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T11:46:20+00:00

<img alt="Pożar w kamienicy, są ranni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5468152-pozar-w-lodzi-ph7987878/alternates/LANDSCAPE_1280" />
    W mieszkaniu na drugim piętrze jednej z kamienic w Łodzi wybuchł pożar. Ewakuowano dziewięć osób, w tym dzieci. Są osoby ranne.

## Pożar w kamienicy, trzylatek w szpitalu
 - [https://tvn24.pl/lodz/lodz-pozar-w-kamienicy-przy-ulicy-miedzianej-dziecko-w-szpitalu-st7987867?source=rss](https://tvn24.pl/lodz/lodz-pozar-w-kamienicy-przy-ulicy-miedzianej-dziecko-w-szpitalu-st7987867?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T11:46:20+00:00

<img alt="Pożar w kamienicy, trzylatek w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5468152-pozar-w-lodzi-ph7987878/alternates/LANDSCAPE_1280" />
    W mieszkaniu na drugim piętrze jednej z kamienic w Łodzi wybuchł pożar. Ewakuowano dziewięć osób. Do szpitala trafiło trzyletnie dziecko.

## Gembicka o rosnącym bezrobociu: jesteśmy na pierwszym miejscu w Unii Europejskiej. Dane nie potwierdzają
 - [https://konkret24.tvn24.pl/polska/bezrobocie-poslanka-pis-jestesmy-na-pierwszym-miejscu-w-unii-europejskiej-dane-nie-potwierdzaja-st7986380?source=rss](https://konkret24.tvn24.pl/polska/bezrobocie-poslanka-pis-jestesmy-na-pierwszym-miejscu-w-unii-europejskiej-dane-nie-potwierdzaja-st7986380?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T11:45:00+00:00

<img alt="Gembicka o rosnącym bezrobociu: jesteśmy na pierwszym miejscu w Unii Europejskiej. Dane nie potwierdzają" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5422834-anna-gembicka-ph7987771/alternates/LANDSCAPE_1280" />
    Według posłanki PiS Anny Gembickiej "za pierwszy kwartał tego roku jesteśmy na pierwszym miejscu w Unii Europejskiej jeśli chodzi o rosnące bezrobocie". Tyle że dane dotyczące bezrobocia pokazują co innego.

## Rycerz Jana Pawła II, zarabiał na umowach z resortem Ziobry. Jest obrońcą księdza Michała O.
 - [https://tvn24.pl/polska/kim-jest-krzysztof-wasowski-obronca-ksiedza-michala-o-st7987427?source=rss](https://tvn24.pl/polska/kim-jest-krzysztof-wasowski-obronca-ksiedza-michala-o-st7987427?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T11:41:15+00:00

<img alt="Rycerz Jana Pawła II, zarabiał na umowach z resortem Ziobry. Jest obrońcą księdza Michała O." src="https://tvn24.pl/najnowsze/cdn-zdjecie-8445556-krzysztof-wasowski-ph7987459/alternates/LANDSCAPE_1280" />
    Mecenas Krzysztof Wąsowski jest obrońcą księdza Michała O., szefa fundacji Profeto, jednego z podejrzanych w aferze Funduszu Sprawiedliwości. W minionych latach bronił między innymi "Starucha" i Przemysława Wiplera. Związany jest z ultrakatolickimi środowiskami, a jego kancelaria świadczyła usługi prawne Ministerstwu Sprawiedliwości, kiedy kierował nim Zbigniew Ziobro.

## Minął ważny termin dotyczący 800 plus. Co zrobić, jeśli się go przegapiło?
 - [https://tvn24.pl/biznes/z-kraju/minal-wazny-termin-dotyczacy-800-plus-co-zrobic-jesli-sie-go-przegapilo-st7987669?source=rss](https://tvn24.pl/biznes/z-kraju/minal-wazny-termin-dotyczacy-800-plus-co-zrobic-jesli-sie-go-przegapilo-st7987669?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T11:35:45+00:00

<img alt="Minął ważny termin dotyczący 800 plus. Co zrobić, jeśli się go przegapiło?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2s3mfm-dzieci-dziecko-shutterstock_378882082-7409385/alternates/LANDSCAPE_1280" />
    Do końca czerwca można było składać wnioski o 800 plus za cały okres rozliczeniowy, który rozpoczął się w czerwcu. Wnioski złożone w lipcu dadzą prawo do świadczenia, ale tylko od tego miesiąca.

## Trzymał się parapetu i spadł. "Nie zdawał sobie sprawy, że znajduje się na trzecim piętrze"
 - [https://tvn24.pl/kujawsko-pomorskie/torun-wypadl-z-trzeciego-pietra-akademika-st7987696?source=rss](https://tvn24.pl/kujawsko-pomorskie/torun-wypadl-z-trzeciego-pietra-akademika-st7987696?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T11:24:44+00:00

<img alt="Trzymał się parapetu i spadł. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1062609-probowal-wrocic-do-pokoju-nie-udalo-sie-spadl-na-trawnik-ph7987704/alternates/LANDSCAPE_1280" />
    23-latek spadł z trzeciego piętra akademika w Toruniu. Wyszedł na parapet, po czym zawisł nogami w dół i nie dał rady wrócić do pokoju. Okazało się, że był pod wpływem alkoholu. Jak podają media, stojąca w oknie kobieta krzyczała, że to jej kochanek, z którym zamknęła się w pokoju i nie mogła znaleźć klucza.

## Rowerzystka miała atak padaczki i zawał serca. Uratowało ją dwoje nastolatków
 - [https://tvn24.pl/poznan/turek-gdyby-nie-pomoc-tych-dzieci-to-bym-juz-nie-zyla-st7987720?source=rss](https://tvn24.pl/poznan/turek-gdyby-nie-pomoc-tych-dzieci-to-bym-juz-nie-zyla-st7987720?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T11:19:51+00:00

<img alt="Rowerzystka miała atak padaczki i zawał serca. Uratowało ją dwoje nastolatków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6537696-turek-rodzenstwo-ktore-uratowalo-kobiete-ph7987589/alternates/LANDSCAPE_1280" />
    14-letnia Michalina i 17-letni Kuba pomogli kobiecie, która dostała ataku padaczki, zawału serca i wjechała rowerem w barierki w Turku (woj. wielkopolskie). Rodzeństwo zatrzymało kierowcę przejeżdżającego auta i wezwało pogotowie ratunkowe. Zachowanie nastolatków uratowało życie kobiecie.

## Prezydent oskarżany o zorganizowanie zamachu stanu
 - [https://tvn24.pl/swiat/boliwia-prezydent-luis-arce-oskarzany-o-sfingowanie-zamachu-stanu-przeciw-samemu-sobie-st7987115?source=rss](https://tvn24.pl/swiat/boliwia-prezydent-luis-arce-oskarzany-o-sfingowanie-zamachu-stanu-przeciw-samemu-sobie-st7987115?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T11:15:08+00:00

<img alt="Prezydent oskarżany o zorganizowanie zamachu stanu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8078725-w-boliwii-doszlo-do-nieudanej-proby-zamachu-stanu-ph7980724/alternates/LANDSCAPE_1280" />
    Prezydent Boliwii Luis Arce oskarżany jest o to, że kazał wysłać wojska do pałacu prezydenckiego, by sfingować w ten sposób zamach stanu. Zarzuty te, sformułowane po raz pierwszy przez dowodzącego zamachem generała, stawiane są już także przez boliwijską opozycję, a nawet kancelarię prezydenta Argentyny.

## Komisja Europejska zatwierdziła zmiany w KPO
 - [https://tvn24.pl/biznes/najnowsze/komisja-europejska-zatwierdzila-zmiany-w-polskim-krajowym-planie-odbudowy-st7987727?source=rss](https://tvn24.pl/biznes/najnowsze/komisja-europejska-zatwierdzila-zmiany-w-polskim-krajowym-planie-odbudowy-st7987727?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:57:54+00:00

<img alt="Komisja Europejska zatwierdziła zmiany w KPO" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xrhksw-flagi-ue-5191102/alternates/LANDSCAPE_1280" />
    We wtorek Komisja Europejska zatwierdziła zmiany w Krajowym Planie Odbudowy zaproponowane przez polski rząd pod koniec kwietnia. W dokumencie, który trafił  do Brukseli wnioskowano między innymi o rezygnację z opłat za rejestrację pojazdów spalinowych w zamian za dopłaty do aut elektrycznych.

## Western "Horyzont. Rozdział 1" ma być "dziełem życia" Kevina Costnera
 - [https://tvn24.pl/kultura-i-styl/horyzont-rozdzial-1-kevina-costnera-recenzja-st7985825?source=rss](https://tvn24.pl/kultura-i-styl/horyzont-rozdzial-1-kevina-costnera-recenzja-st7985825?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:45:39+00:00

<img alt="Western " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5382637-horyzont-rozdzial-1-ph7985902/alternates/LANDSCAPE_1280" />
    Kevin Costner, po dwóch dekadach przerwy w reżyserowaniu, powraca z "dziełem swojego życia" westernem "Horyzont". W monumentalnej, wielowątkowej opowieści z niebywałą starannością opowiada o świecie, w którym - jak nas przekonuje - królowała przemoc, a nie ideały rodem z bajek o Dzikim Zachodzie.

## Zaatakował nożem przechodnia. "Zadał mu kilka ciosów"
 - [https://tvn24.pl/wroclaw/zaatakowal-nozem-przechodnia-zadal-mu-kilka-ciosow-st7987578?source=rss](https://tvn24.pl/wroclaw/zaatakowal-nozem-przechodnia-zadal-mu-kilka-ciosow-st7987578?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:40:04+00:00

<img alt="Zaatakował nożem przechodnia. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7907912-areszt-sledczy-w-jeleniej-gorze-ph7987597/alternates/LANDSCAPE_1280" />
    Zatrzymano 29-latka podejrzanego o usiłowanie zabójstwa w Jeleniej Górze. Do zdarzenia doszło 8 czerwca na jednej z ulic. Mężczyzna zaatakował nożem przypadkowego przechodnia, zadając mu kilka ran.

## Masowe zatrucia we włoskim kurorcie. Setki osób trafiły do szpitala
 - [https://tvn24.pl/swiat/wlochy-zatrucia-w-miasteczku-torri-del-benaco-nad-jeziorem-garda-st7987707?source=rss](https://tvn24.pl/swiat/wlochy-zatrucia-w-miasteczku-torri-del-benaco-nad-jeziorem-garda-st7987707?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:36:56+00:00

<img alt="Masowe zatrucia we włoskim kurorcie. Setki osób trafiły do szpitala" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2705628-torri-del-benaco-wlochy-ph7987681/alternates/LANDSCAPE_1280" />
    Włoskie media informują o kryzysie sanitarnym w znanej miejscowości turystycznej Torri del Benàco na północy Włoch. Do miejscowych szpitali miało się zgłosić kilkaset osób z poważnymi objawami.

## Zażyła tabletkę poronną, w szpitalu otoczyli ją policjanci. Ruszył proces
 - [https://tvn24.pl/krakow/krakow-pani-joanna-zazyla-tabletke-poronna-kazali-jej-kucac-i-kaszlec-ruszyl-proces-w-sprawie-policyjnej-interwencji-st7987602?source=rss](https://tvn24.pl/krakow/krakow-pani-joanna-zazyla-tabletke-poronna-kazali-jej-kucac-i-kaszlec-ruszyl-proces-w-sprawie-policyjnej-interwencji-st7987602?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:35:28+00:00

<img alt="Zażyła tabletkę poronną, w szpitalu otoczyli ją policjanci. Ruszył proces" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1663806-poczatek-procesu-pani-joanny-w-krakowie-ph7987642/alternates/LANDSCAPE_1280" />
    Rozpoczął się proces w sprawie pani Joanny, która żąda od krakowskiej policji zadośćuczynienia za kontrowersyjną interwencję w szpitalu. Kobieta miała na polecenie funkcjonariuszy rozebrać się, kucać i kaszleć, zabrano jej też telefon i laptop. Wcześniej zażyła tabletkę poronną.

## Zderzenie ciężarówki i skutera. Nie żyje jedna osoba
 - [https://tvn24.pl/lubuskie/gorzow-wielkopolski-tragiczny-wypadek-nie-zyje-motocyklista-st7987429?source=rss](https://tvn24.pl/lubuskie/gorzow-wielkopolski-tragiczny-wypadek-nie-zyje-motocyklista-st7987429?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:32:00+00:00

<img alt="Zderzenie ciężarówki i skutera. Nie żyje jedna osoba" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9802493-policja-interweniowala-na-chomiczowce-zdjecie-ilustracyjne-ph7984892/alternates/LANDSCAPE_1280" />
    Na ulicy Poznańskiej w Gorzowie Wielkopolskim doszło do zderzenia motocyklisty z samochodem ciężarowym. Nie żyje jeden z kierowców, 71-letni mężczyzna. Na miejscu pracuje straż pożarna, policja i pogotowie ratunkowe. Przyczyny wypadku będą wyjaśniane przez policję pod nadzorem prokuratury.

## Jeździł z maczetą w samochodzie, był poszukiwany
 - [https://tvn24.pl/opole/opole-jezdzil-z-maczeta-w-samochodzie-byl-poszukiwany-st7987417?source=rss](https://tvn24.pl/opole/opole-jezdzil-z-maczeta-w-samochodzie-byl-poszukiwany-st7987417?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:25:30+00:00

<img alt="Jeździł z maczetą w samochodzie, był poszukiwany " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1340108-jezdzil-z-maczeta-ph7987449/alternates/LANDSCAPE_1280" />
    Opolscy łowcy głów zatrzymali poszukiwanego 44-latka z wyrokiem za uprawę konopi indyjskich i nielegalne posiadanie broni palnej. Mężczyzna był poszukiwany listem gończym i ukrywał się za granicą. Gdy wrócił do Polski, zatrzymano go podczas kolejnej podróży. W samochodzie miał maczetę z ostrzem o długości kilkudziesięciu centymetrów oraz pałkę z metalowym rdzeniem.

## Modernizacja zabytkowego gmachu NBP. "Budynek praktycznie przestał istnieć"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-modernizacja-zabytkowego-gmachu-nbp-st7982692?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-modernizacja-zabytkowego-gmachu-nbp-st7982692?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:22:45+00:00

<img alt="Modernizacja zabytkowego gmachu NBP. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9297714-przebudowa-gmachu-nbp-przy-placu-powstancow-warszawy-ph7982955/alternates/LANDSCAPE_1280" />
    Trwa przebudowa znajdującego się w ewidencji zabytków gmachu głównego Narodowego Banku Polskiego na placu Powstańców Warszawy. W marcu biuro prasowe instytucji zapowiadało, że "prace zaprojektowano z poszanowaniem istniejącego gabarytu i formy architektonicznej". Tymczasem gołym okiem widać poważną ingerencję w bryłę. Stołeczny konserwator zabytków ocenił z kolei, że "budynek praktycznie przestał istnieć" i prawdopodobnie przestanie być obiektem zabytkowym.

## Pijany kierowca potrącił pieszych i wjechał w mur. Nagranie z monitoringu
 - [https://tvn24.pl/szczecin/sarbinowo-potracil-trzy-osoby-i-wjechal-w-murek-kosciola-nagranie-z-monitoringu-st7987395?source=rss](https://tvn24.pl/szczecin/sarbinowo-potracil-trzy-osoby-i-wjechal-w-murek-kosciola-nagranie-z-monitoringu-st7987395?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:17:55+00:00

<img alt="Pijany kierowca potrącił pieszych i wjechał w mur. Nagranie z monitoringu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-306122-zdjecie-monitoring-ph7987624/alternates/LANDSCAPE_1280" />
    Wjechał w przechodniów idących chodnikiem, po czym uderzył w mur pobliskiego kościoła w Sarbinowie (woj. zachodniopomorskie). Mężczyzna chciał uciec z miejsca zdarzenia, ale został zatrzymany przez świadków. 28-latek miał 1,8 promila alkoholu i dwa aktywne zakazy prowadzenia. Dotarliśmy do nagrania z monitoringu.

## Padł rekord w internetowym transferze
 - [https://tvn24.pl/biznes/tech/nowy-rekord-w-internetowym-transferze-wyniosl-402-terabity-na-sekunde-st7987367?source=rss](https://tvn24.pl/biznes/tech/nowy-rekord-w-internetowym-transferze-wyniosl-402-terabity-na-sekunde-st7987367?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:11:57+00:00

<img alt="Padł rekord w internetowym transferze" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie292f6bce6387ce677e05f5ee0952b714-komputer-dane-data-internet-4034819/alternates/LANDSCAPE_1280" />
    402 terabity na sekundę - to nowy rekord przesyłu danych przez internet, który udało się osiągnąć międzynarodowemu zespołowi naukowców. Badacze pobili swoje wcześniejsze osiągnięcie.

## Zaatakował psa nożem, a potem powiesił
 - [https://tvn24.pl/kujawsko-pomorskie/chelmce-zaatakowal-psa-nozem-a-potem-powiesil-policja-zatrzymala-41-latka-st7987333?source=rss](https://tvn24.pl/kujawsko-pomorskie/chelmce-zaatakowal-psa-nozem-a-potem-powiesil-policja-zatrzymala-41-latka-st7987333?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T10:11:07+00:00

<img alt="Zaatakował psa nożem, a potem powiesił " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1528500-mezczyzna-przyznal-sie-do-zabicia-psa-ph7987509/alternates/LANDSCAPE_1280" />
    Mężczyzna najpierw zaatakował psa nożem, potem powiesił na linie przed domem. Do tego makabrycznego zdarzenia doszło na terenie jednej z posesji w miejscowości Chełmce pod Kruszwicą (woj. kujawsko-pomorskie). Policja zatrzymała 41-letniego podejrzanego. Mężczyzna przyznał się do winy. Powiedział, że adoptował psa, a gdy chciał go zwrócić schronisko miało odmówić.

## Skrzywdzeni w Kościele katolickim przyjęli zaproszenie biskupów, pytają o komisję ekspertów
 - [https://tvn24.pl/polska/skrzywdzeni-w-kosciele-katolickimprzyjeli-zaproszenie-biskupow-pytaja-o-komisje-ekspertow-st7987091?source=rss](https://tvn24.pl/polska/skrzywdzeni-w-kosciele-katolickimprzyjeli-zaproszenie-biskupow-pytaja-o-komisje-ekspertow-st7987091?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:57:28+00:00

<img alt="Skrzywdzeni w Kościele katolickim przyjęli zaproszenie biskupów, pytają o komisję ekspertów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1854646-kosciol-krzyz-symbol-ph7977725/alternates/LANDSCAPE_1280" />
    Skrzywdzeni w Kościele katolickim w Polsce odpowiedzieli na list Rady Stałej Konferencji Episkopatu Polski z 11 czerwca. Podkreślili, że przyjmują słowa biskupów "z nadzieją na szczery i owocny dialog" oraz ich zaproszenie na listopadowe spotkanie. Zaznaczyli jednak, że komisja niezależnych ekspertów powinna być zewnętrzna w stosunku do Episkopatu.

## Wiozła z Wietnamu krem na ból z jadem kobry królewskiej
 - [https://tvn24.pl/katowice/katowice-wiozla-z-wietnamu-krem-na-bol-z-jadem-kobry-krolewskiej-znalezli-go-w-bagazu-celnicy-na-lotnisku-w-pyrzowicach-st7987304?source=rss](https://tvn24.pl/katowice/katowice-wiozla-z-wietnamu-krem-na-bol-z-jadem-kobry-krolewskiej-znalezli-go-w-bagazu-celnicy-na-lotnisku-w-pyrzowicach-st7987304?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:52:32+00:00

<img alt="Wiozła z Wietnamu krem na ból z jadem kobry królewskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2268593-krem-z-jadem-kobry-krolewskiej-ph7987363/alternates/LANDSCAPE_1280" />
    Kobra królewska jest zagrożona wyginięciem. W Azji wierzą, że jad tego węża zmniejsza bóle zapalne i robią z niego kremy. W bagażu turystki, która wracała z Wietnamu, celnicy na lotnisku w Pyrzowicach znaleźli cztery opakowania takiego medykamentu. Kobieta nie miała wymaganych zezwoleń.

## Wjechali do Strefy Czystego Transportu starymi autami. Są już pierwsze pouczenia
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wjechali-do-strefy-czystego-transportu-starymi-autami-sa-juz-pierwsze-pouczenia-st7987471?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wjechali-do-strefy-czystego-transportu-starymi-autami-sa-juz-pierwsze-pouczenia-st7987471?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:51:53+00:00

<img alt="Wjechali do Strefy Czystego Transportu starymi autami. Są już pierwsze pouczenia" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8933140-strefa-czystego-transportu-w-warszawie-ph7987527/alternates/LANDSCAPE_1280" />
    Od poniedziałku w Warszawie obowiązuje Strefa Czystego Transportu. Jak informuje stołeczna straż miejska, już pierwszego dnia funkcjonariusze pouczyli 10 kierowców, którzy nie powinni wjeżdżać do strefy.

## Osuwiska zmiotły drogi, woda zalała domy. Cztery osoby nie żyją
 - [https://tvn24.pl/tvnmeteo/swiat/szwajcaria-osuwiska-zmiotly-drogi-woda-zalala-domy-cztery-osoby-nie-zyja-st7987307?source=rss](https://tvn24.pl/tvnmeteo/swiat/szwajcaria-osuwiska-zmiotly-drogi-woda-zalala-domy-cztery-osoby-nie-zyja-st7987307?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:49:02+00:00

<img alt="Osuwiska zmiotły drogi, woda zalała domy. Cztery osoby nie żyją" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-304542-zniszczenia-w-alpach-szwajcarskich-ph7987301/alternates/LANDSCAPE_1280" />
    Do czterech wzrosła liczba ofiar śmiertelnych ulew i burz, które w weekend przetoczyły się nad Szwajcarią. W alpejskich kantonach wciąż trwają poszukiwania kilku zaginionych osób. Region został dotknięty licznymi podtopieniami i osuwiskami.

## Bocheński o drogach budowanych przez PiS: 50, 46, 41 procent z wszystkich autostrad i dróg ekspresowych. Ile ich jest naprawdę?
 - [https://konkret24.tvn24.pl/polityka/tobiasz-bochenski-pis-o-drogach-wybudowanych-przez-pis-50-46-41-procent-z-wszystkich-uzytkowanych-sprawdzamy-dane-st7986442?source=rss](https://konkret24.tvn24.pl/polityka/tobiasz-bochenski-pis-o-drogach-wybudowanych-przez-pis-50-46-41-procent-z-wszystkich-uzytkowanych-sprawdzamy-dane-st7986442?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:40:42+00:00

<img alt="Bocheński o drogach budowanych przez PiS: 50, 46, 41 procent z wszystkich autostrad i dróg ekspresowych. Ile ich jest naprawdę?" src="https://konkret24.tvn24.pl/najnowsze/cdn-zdjecie-9402048-50-46-41-procent-autostrad-i-drog-ekspresowych-wybudowano-za-pis-a-ile-naprawde-ph7987535/alternates/LANDSCAPE_1280" />
    Polityk PiS Tobiasz Bocheński w TVN24 przekonywał, że "46 procent obecnie użytkowanych przez Polaków dróg szybkiego ruchu i autostrad zostało oddanych do użytku w ciągu ostatnich ośmiu lat, a nie w czasach rządów Platformy Obywatelskiej". Wcześniej twierdził, że jest to "niemalże 50 procent", a ostatecznie kolejny raz zmienił tę liczbę. Sprawdziliśmy dane.

## Atak na ukraińskie Su-27 w obwodzie połtawskim
 - [https://tvn24.pl/swiat/rosjanie-zaatakowali-lotnisko-w-obwodzie-poltawskim-mowia-ile-samolotow-zniszczyli-st7987460?source=rss](https://tvn24.pl/swiat/rosjanie-zaatakowali-lotnisko-w-obwodzie-poltawskim-mowia-ile-samolotow-zniszczyli-st7987460?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:40:22+00:00

<img alt="Atak na ukraińskie Su-27 w obwodzie połtawskim  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1996742-2024-07-02t075844z1lwd542402072024rp1rtrwnevc5424-ukraine-crisis-russia-fighter-jets-0001-ph7987464/alternates/LANDSCAPE_1280" />
    Resort obrony w Moskwie raportuje, że podczas poniedziałkowego ataku na lotnisko w obwodzie połtawskim w środkowej części Ukrainy zostało zniszczonych pięć Su-27. Władze w Kijowie w tej sprawie na razie milczą. Były rzecznik sił powietrznych Jurij Ihnat oznajmił, że "atak był, ale straty wcale nie są takie, jakie wróg sobie przypisuje".

## Cudem przetrwała pod warstwami bazgrołów. Wróci we flagowym salonie Empiku
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-cepelia-odnowione-plytki-ceramiczne-bylo-na-nich-grafitti-st7985094?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-cepelia-odnowione-plytki-ceramiczne-bylo-na-nich-grafitti-st7985094?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:37:05+00:00

<img alt="Cudem przetrwała pod warstwami bazgrołów. Wróci we flagowym salonie Empiku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8095268-oczyszczona-okladzina-ceramiczna-cepelii-ph7985109/alternates/LANDSCAPE_1280" />
    Piękna, kilkudziesięcioletnia okładzina ceramiczna Cepelii cudem przetrwała pod... warstwami bazgrołów. Po pracy konserwatorów znowu widać detale niebieskich płytek. Po remoncie w budynku będzie mieścił się flagowy, trzypiętrowy salon sieci Empik.

## Dzieci rozpaliły ognisko w lesie. Pożar gasiły trzy samoloty
 - [https://tvn24.pl/kujawsko-pomorskie/grupa-swiecie-dzieci-rozpalily-ognisko-w-lesie-pozar-gasily-trzy-samoloty-st7987402?source=rss](https://tvn24.pl/kujawsko-pomorskie/grupa-swiecie-dzieci-rozpalily-ognisko-w-lesie-pozar-gasily-trzy-samoloty-st7987402?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:35:44+00:00

<img alt="Dzieci rozpaliły ognisko w lesie. Pożar gasiły trzy samoloty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2704985-pozar-lasu-w-grupie-woj-kujawsko-pomorskie-ph7987388/alternates/LANDSCAPE_1280" />
    Ognisko rozpalone przez trzech chłopców w wieku od 8 do 10 lat okazało się przyczyną pożaru lasu, do którego doszło w Grupie niedaleko Świecia (woj. kujawsko-pomorskie). Z ogniem walczyło 13 zastępów strażaków i trzy samoloty gaśnicze. Chłopcy odpowiedzą przed sądem rodzinnym.

## Komisja pomyliła Danielów, wybory na burmistrza będą powtórzone
 - [https://tvn24.pl/lodz/wybory-burmistrza-brzezin-pod-lodzia-uniewaznione-jest-decyzja-sadu-okregowego-st7987380?source=rss](https://tvn24.pl/lodz/wybory-burmistrza-brzezin-pod-lodzia-uniewaznione-jest-decyzja-sadu-okregowego-st7987380?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:28:25+00:00

<img alt="Komisja pomyliła Danielów, wybory na burmistrza będą powtórzone" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j6a09q-wybory-do-powtorki-ph7968491/alternates/LANDSCAPE_1280" />
    Sąd Okręgowy w Łodzi unieważnił we wtorek wyniki drugiej tury wyborów na burmistrza Brzezin pod Łodzią. A to dlatego, że - jak okazało się w czasie procesu wszczętego na wniosek jednego z kandydatów - jedna z miejskich komisji źle policzyła głosy. Decyzja sądu oznacza, że mandat wybranego w kwietniu burmistrza został wygaszony, a w mieście powtórzona zostanie druga tura.

## Tomasz Szatkowski doradcą społecznym prezydenta
 - [https://tvn24.pl/polska/tomasz-szatkowski-doradca-spolecznym-prezydenta-st7987103?source=rss](https://tvn24.pl/polska/tomasz-szatkowski-doradca-spolecznym-prezydenta-st7987103?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:25:46+00:00

<img alt="Tomasz Szatkowski doradcą społecznym prezydenta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5173438-tomasz-szatkowski-doradca-spolecznym-prezydenta-ph7987098/alternates/LANDSCAPE_1280" />
    Tomasz Szatkowski został powołany przez prezydenta Andrzeja Dudę na stanowisko doradcy społecznego. Szatkowski od 2019 roku pełnił funkcję ambasadora RP przy NATO. W maju MSZ poinformował o zakończeniu jego misji, jednak prezydent nie uznał nowej kandydatury. Szef prezydenckiego Biura Polityki Międzynarodowej przekazał, że to Szatkowski prawdopodobnie będzie towarzyszył Dudzie podczas lipcowego szczytu NATO.

## Jest śledztwo w sprawie nadużycia uprawnień przez zarząd Polskiej Fundacji Narodowej
 - [https://tvn24.pl/polska/jest-sledztwo-w-sprawie-naduzycia-uprawnien-przez-zarzad-polskiej-fundacji-narodowej-st7987491?source=rss](https://tvn24.pl/polska/jest-sledztwo-w-sprawie-naduzycia-uprawnien-przez-zarzad-polskiej-fundacji-narodowej-st7987491?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:22:12+00:00

<img alt="Jest śledztwo w sprawie nadużycia uprawnień przez zarząd Polskiej Fundacji Narodowej  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-y7euoy-polska-fundacja-narodowa01-5480278/alternates/LANDSCAPE_1280" />
    Prokuratura Okręgowa w Warszawie wszczęła śledztwo w sprawie nadużycia uprawnień i niedopełnienia obowiązków przez członków zarządu Polskiej Fundacji Narodowej (PFN). Chodzi o kampanię medialną "Sprawiedliwe Sądy" z 2017 roku.

## Polityka "cięcia piłą łańcuchową" dotknęła państwową agencję informacyjną
 - [https://tvn24.pl/swiat/argentyna-panstwowa-agencja-prasowa-telam-stanie-sie-agencja-promocyjna-st7987112?source=rss](https://tvn24.pl/swiat/argentyna-panstwowa-agencja-prasowa-telam-stanie-sie-agencja-promocyjna-st7987112?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:18:10+00:00

<img alt="Polityka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-917627-protesty-w-argentynie-ph7987111/alternates/LANDSCAPE_1280" />
    Libertariański prezydent Argentyny Javier Milei zarządził przekształcenie Telam, jednej z największych państwowych agencji prasowych w Ameryce Łacińskiej, w Agencję Promocji i Propagandy Państwa (APE) – przekazały w poniedziałek miejscowe media.

## Miała przejechać partnera i zostawić go "na pewną śmierć". Unieważnienie procesu Karen Read
 - [https://tvn24.pl/swiat/miala-przejechac-partnera-i-zostawic-go-na-pewna-smierc-uniewaznienie-procesu-karen-read-st7987298?source=rss](https://tvn24.pl/swiat/miala-przejechac-partnera-i-zostawic-go-na-pewna-smierc-uniewaznienie-procesu-karen-read-st7987298?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:15:42+00:00

<img alt="Miała przejechać partnera i zostawić go " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1414470-karen-read-ph7987297/alternates/LANDSCAPE_1280" />
    Czterdziestopięcioletnia Karen Read została oskarżona o zamordowanie swojego chłopaka po kłótni, wczesnym rankiem w styczniu 2022 r. Miała go przejechać samochodem i ciężko rannego zostawić w zaspie "na pewną śmierć". Obrońcy kobiety twierdzą jednak, że została "wrobiona w przestępstwo". W poniedziałek sędzia ogłosiła unieważnienie procesu.

## Gdzie jest burza? Pierwsze wyładowania nad Polską
 - [https://tvn24.pl/tvnmeteo/prognoza/gdzie-jest-burza-burze-w-polsce-we-wtorek-0207-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-st7987483?source=rss](https://tvn24.pl/tvnmeteo/prognoza/gdzie-jest-burza-burze-w-polsce-we-wtorek-0207-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-st7987483?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:14:16+00:00

<img alt="Gdzie jest burza? Pierwsze wyładowania nad Polską" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-h6vo0p-piorun-5194204/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? We wtorek 02.07 nad Polską pojawiają się wyładowania atmosferyczne. Zjawiskom towarzyszą opady deszczu oraz porywisty wiatr. Śledź aktualną sytuację pogodową na tvnmeteo.pl.

## Media: francuscy Żydzi porzuceni i zagubieni między skrajną prawicą i skrajną lewicą
 - [https://tvn24.pl/swiat/izrael-media-francuscy-zydzi-porzuceni-i-zagubieni-miedzy-skrajna-prawica-i-skrajna-lewica-st7987114?source=rss](https://tvn24.pl/swiat/izrael-media-francuscy-zydzi-porzuceni-i-zagubieni-miedzy-skrajna-prawica-i-skrajna-lewica-st7987114?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:13:25+00:00

<img alt="Media: francuscy Żydzi porzuceni i zagubieni między skrajną prawicą i skrajną lewicą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1540914-francja-wkracza-w-okres-potencjalnej-niestabilnosci-ph7987113/alternates/LANDSCAPE_1280" />
    Izraelski dziennik "Haarec", komentując wybory we Francji, stwierdził, że francuscy Żydzi czują się porzuceni i zagubieni między skrajną lewicą i skrajną prawicą. To głosowanie jest kluczowe dla przyszłości francuskich Żydów i relacji z Izraelem - dodał "The Jerusalem Post".

## Dwie kobiety zginęły na pasach. 81-latek stanie przed sądem
 - [https://tvn24.pl/katowice/czestochowa-dwie-ukrainki-zginely-na-pasach-akt-oskarzenia-przeciwko-kierowcy-st7987249?source=rss](https://tvn24.pl/katowice/czestochowa-dwie-ukrainki-zginely-na-pasach-akt-oskarzenia-przeciwko-kierowcy-st7987249?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T09:00:36+00:00

<img alt="Dwie kobiety zginęły na pasach. 81-latek stanie przed sądem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3961861-potracenie-w-czestochowie-ph7688369/alternates/LANDSCAPE_1280" />
    Kierowca audi stanie przed sądem za śmiertelne potrącenie dwóch kobiet w Częstochowie. Prokuratura zarzuca mu, że wyprzedzał przed pasami i znacznie przekroczył dozwoloną prędkość. Mężczyzna do niczego się nie przyznał.

## Skok na główkę do fontanny. Nagranie
 - [https://tvn24.pl/lubuskie/gorzow-wielkopolski-kapiel-w-fontannie-i-skok-na-glowke-nagranie-st7987309?source=rss](https://tvn24.pl/lubuskie/gorzow-wielkopolski-kapiel-w-fontannie-i-skok-na-glowke-nagranie-st7987309?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T08:33:58+00:00

<img alt="Skok na główkę do fontanny. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7316852-skoczyl-w-bokserkach-do-fontanny-gorzow-wlkp-ph7987231/alternates/LANDSCAPE_1280" />
    Gorzowscy policjanci ukarali mandatem mężczyznę, który kąpał się w bokserkach w fontannie. Tę nietypową sytuację zauważył operator miejskiego monitoringu. Nie jest to pierwsza dziwna sytuacja, z miejską fontanną w roli głównej. W poprzednich latach pijany 23-latek wniósł do niej elektryczną hulajnogę, a nastolatka chciała sobie zrobić z nią zdjęcie, przy okazji ją uszkadzając.

## "Jestem dumny, że idę do więzienia". Były "główny strateg" Trumpa rozpoczął odsiadkę
 - [https://tvn24.pl/swiat/usa-steve-bannon-byly-doradca-donalda-trumpa-w-wiezieniu-st7987283?source=rss](https://tvn24.pl/swiat/usa-steve-bannon-byly-doradca-donalda-trumpa-w-wiezieniu-st7987283?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T08:26:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6660100-steve-bannon-ph7987284/alternates/LANDSCAPE_1280" />
    Steve Bannon, były strateg Białego Domu i szef kampanii Donalda Trumpa stawił się w poniedziałek w więzieniu federalnym w Connecticut. Rozpoczął odsiadywanie wyroku za odmowę złożenia zeznań przed komisją śledczą Kongresu badającą wydarzenia wokół szturmu na Kapitol. Polityk spędzi za kratkami cztery miesiące.

## Przechodził po pasach, potrącił go samochód
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-praga-polnoc-potracenie-pieszego-przez-samochod-st7987350?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-praga-polnoc-potracenie-pieszego-przez-samochod-st7987350?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T08:18:59+00:00

<img alt="Przechodził po pasach, potrącił go samochód " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4785965-potracenie-pieszego-na-jagiellonskiej-ph7987345/alternates/LANDSCAPE_1280" />
    We wtorek na Pradze Północ mężczyzna przechodzący przez przejście dla pieszych został potrącony przez samochód. 38-latek z obrażeniami trafił do szpitala. Policjanci wyjaśniają okoliczności zdarzenia.

## Miliony złotych na wynajem niewykorzystywanych pomieszczeń. NIK o nieprawidłowościach w IPN
 - [https://tvn24.pl/polska/nik-o-nieprawidlowosciach-w-ipn-miliony-zlotych-na-wynajem-niewykorzystywanych-pomieszczen-st7987335?source=rss](https://tvn24.pl/polska/nik-o-nieprawidlowosciach-w-ipn-miliony-zlotych-na-wynajem-niewykorzystywanych-pomieszczen-st7987335?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T08:08:28+00:00

<img alt="Miliony złotych na wynajem niewykorzystywanych pomieszczeń. NIK o nieprawidłowościach w IPN" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6321162-ipn-ph7987353/alternates/LANDSCAPE_1280" />
    Instytut Pamięci Narodowej płacił prawie milion złotych miesięcznie przez osiem miesięcy za wynajem niewykorzystywanych pomieszczeń w budynku, gdzie miała być nowa siedziba Centralnego Przystanku Historia – wynika z wystąpienia pokontrolnego Najwyższej Izby Kontroli. Niemal 18 milionów złotych IPN miał wydać z naruszeniem prawa, nierzetelnie lub niegospodarnie.

## Szczegóły sterowania Funduszem, obawy o niszczenie dowodów. Co jest we wniosku w sprawie Romanowskiego
 - [https://tvn24.pl/polska/marcin-romanowski-wniosek-o-uchylenie-immunitetu-gazeta-wyborcza-o-szczegolach-pisma-st7987276?source=rss](https://tvn24.pl/polska/marcin-romanowski-wniosek-o-uchylenie-immunitetu-gazeta-wyborcza-o-szczegolach-pisma-st7987276?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T07:46:16+00:00

<img alt="Szczegóły sterowania Funduszem, obawy o niszczenie dowodów. Co jest we wniosku w sprawie Romanowskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2059773-marcin-romanowski-posel-ph7937817/alternates/LANDSCAPE_1280" />
    "Gazeta Wyborcza" dotarła do wniosku prokuratury o uchylenie immunitetu Marcinowi Romanowskiemu, politykowi Suwerennej Polski, posłowi PiS i opisała kilka szczegółów, które się w nim znajdują.

## "Czy to w ogóle jest miasto?". Antyreklama wabikiem na turystów
 - [https://tvn24.pl/biznes/turystyka/czy-to-w-ogole-jest-miasto-antyreklama-wabikiem-na-turystow-st7986748?source=rss](https://tvn24.pl/biznes/turystyka/czy-to-w-ogole-jest-miasto-antyreklama-wabikiem-na-turystow-st7986748?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T07:25:39+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5ldvan-oslo-shutterstock1879262575-5142094/alternates/LANDSCAPE_1280" />
    "Jeśli mam być szczery, to nie przyjechałbym tu" - stwierdza bohater reklamy, która w przewrotny sposób zachęca turystów do odwiedzenia Oslo. Dzięki ironicznemu charakterowi spot stał się szybko popularny. Niespełna dwuminutowy klip okazał się świetnym wabikiem - niemal każdy kto go obejrzał, zadeklarował chęć odwiedzenia stolicy Norwegii.

## Palenie drewnem zostanie ograniczone. Wkrótce rewolucja w przepisach
 - [https://tvn24.pl/biznes/najnowsze/spalanie-drewna-zostanie-ograniczone-ministerstwo-klimatu-i-srodowiska-szykuje-zmiany-w-przepisach-st7987265?source=rss](https://tvn24.pl/biznes/najnowsze/spalanie-drewna-zostanie-ograniczone-ministerstwo-klimatu-i-srodowiska-szykuje-zmiany-w-przepisach-st7987265?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T06:58:33+00:00

<img alt="Palenie drewnem zostanie ograniczone. Wkrótce rewolucja w przepisach" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-dpk0eq-drewno-4207218/alternates/LANDSCAPE_1280" />
    Ministerstwo Klimatu i Środowiska pracuje nad przepisami ograniczającymi spalanie drewna w sektorze energetycznym - donosi "Dziennik Gazeta Prawna". Nowe rozwiązania budzą kontrowersje, szczególnie wśród branży meblarskiej, która uważa, że regulacje są zbyt mało restrykcyjne.

## Wakacje w Polsce. Gdzie najchętniej rezerwujemy noclegi? Jakie ceny nad Bałtykiem
 - [https://tvn24.pl/biznes/turystyka/wakacje-2024-tu-wolnych-miejsc-jest-coraz-mniej-gdzie-najchetniej-rezerwujemy-noclegi-jakie-ceny-st7987251?source=rss](https://tvn24.pl/biznes/turystyka/wakacje-2024-tu-wolnych-miejsc-jest-coraz-mniej-gdzie-najchetniej-rezerwujemy-noclegi-jakie-ceny-st7987251?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T06:49:06+00:00

<img alt="Wakacje w Polsce. Gdzie najchętniej rezerwujemy noclegi? Jakie ceny nad Bałtykiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6342197-morze-baltyckie-upal-ph7983155/alternates/LANDSCAPE_1280" />
    Tego lata większość Polaków zamierza spędzić urlop w kraju. Z danych wynika, że rezerwujemy więcej noclegów niż w 2023 roku, decydując się przy tym na dłuższe pobyty. Które miejscowości cieszą się największą popularnością? Na jakie ceny trzeba się przygotować?

## Sędzia Cezariusz Baćkowski rzecznikiem dyscyplinarnym, zajmie się sędziami z neo-KRS
 - [https://tvn24.pl/polska/sedzia-cezariusz-backowski-rzecznikiem-dyscyplinarnym-zajmie-sie-sedziami-z-neo-krs-st7987109?source=rss](https://tvn24.pl/polska/sedzia-cezariusz-backowski-rzecznikiem-dyscyplinarnym-zajmie-sie-sedziami-z-neo-krs-st7987109?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T06:37:46+00:00

<img alt="Sędzia Cezariusz Baćkowski rzecznikiem dyscyplinarnym, zajmie się sędziami z neo-KRS" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9897366-cezariusz-backowski-ph7987060/alternates/LANDSCAPE_1280" />
    Ministerstwo Sprawiedliwości poinformowało, że szef resortu Adam Bodnar powołał sędziego Sądu Apelacyjnego we Wrocławiu Cezariusza Baćkowskiego na Rzecznika Dyscyplinarnego Ministra Sprawiedliwości. Nowy rzecznik "ad hoc" poprowadzi sprawy dyscyplinarne dotyczące członków neo-KRS. Resort sprawiedliwości poinformował też o odwołaniu sędziego Rafała Puchalskiego z funkcji prezesa Sądu Apelacyjnego w Rzeszowie i jego wiceprezesa Józefa Pawłowskiego.

## Schował skradziony rower na cmentarzu za grobem babci
 - [https://tvn24.pl/wroclaw/zlotoryja-schowal-skradziony-rower-na-cmentarzu-za-grobem-babci-st7986360?source=rss](https://tvn24.pl/wroclaw/zlotoryja-schowal-skradziony-rower-na-cmentarzu-za-grobem-babci-st7986360?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T06:27:00+00:00

<img alt="Schował skradziony rower na cmentarzu za grobem babci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7594492-ukryl-rower-za-grobem-babci-ph7986403/alternates/LANDSCAPE_1280" />
    Najpierw 33-latek ukradł rower w centrum Złotoryi. Po chwili postanowił schować swój łup, dlatego udał się na cmentarz i ukrył jednoślad za grobem swojej babci. Mężczyzna został zatrzymany i usłyszał zarzut.

## Kanclerz Niemiec w Polsce. Pierwszy raz od sześciu lat przyjechał na międzyrządowe konsultacje
 - [https://tvn24.pl/polska/kanclerz-niemiec-olaf-scholz-w-polsce-pierwszy-raz-od-szesciu-lat-przyjechal-na-miedzyrzadowe-konsultacje-st7987199?source=rss](https://tvn24.pl/polska/kanclerz-niemiec-olaf-scholz-w-polsce-pierwszy-raz-od-szesciu-lat-przyjechal-na-miedzyrzadowe-konsultacje-st7987199?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T06:24:11+00:00

<img alt="Kanclerz Niemiec w Polsce. Pierwszy raz od sześciu lat przyjechał na międzyrządowe konsultacje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1746206-02-0745-tusk-0004-ph7987198/alternates/LANDSCAPE_1280" />
    W Kancelarii Prezesa Rady Ministrów odbyło się oficjalne powitanie kanclerza Niemiec Olafa Scholza. Kanclerz przyjechał na spotkanie z premierem Donaldem Tuskiem. Międzyrządowe konsultacje - najpierw w cztery oczy, a później razem z delegacjami - mają dotyczyć między innymi reparacji.

## Co dalej z pogodą w wakacje. Modele z Europy, USA i Rosji są raczej zgodne
 - [https://tvn24.pl/tvnmeteo/prognoza/co-dalej-z-pogoda-w-wakacje-modele-z-europy-usa-i-rosji-sa-raczej-zgodne-st7985799?source=rss](https://tvn24.pl/tvnmeteo/prognoza/co-dalej-z-pogoda-w-wakacje-modele-z-europy-usa-i-rosji-sa-raczej-zgodne-st7985799?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T06:22:25+00:00

<img alt="Co dalej z pogodą w wakacje. Modele z Europy, USA i Rosji są raczej zgodne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9332835-meteo-czapa-i-zatoka-16-drv-pwa-ph7986333/alternates/LANDSCAPE_1280" />
    Za nami zarówno upalne, jak i burzowe chwile. Pierwszego lipca aura w Polsce znacząco się ochłodziła i uspokoiła. Co dalej z pogodą w wakacje? Synoptyk tvnmeteo.pl Arleta Unton-Pyziołek sprawdziła modele prognostyczne największych ośrodków, żeby sprawdzić, jaka pogoda czeka nas w lipcu i sierpniu.

## Sztuczna inteligencja zabierze pracę? "To nie żywioł, decyzja zależy od ludzi"
 - [https://tvn24.pl/biznes/tech/sztuczna-inteligencja-zabierze-prace-to-nie-zywiol-decyzja-zalezy-od-ludzi-st7986690?source=rss](https://tvn24.pl/biznes/tech/sztuczna-inteligencja-zabierze-prace-to-nie-zywiol-decyzja-zalezy-od-ludzi-st7986690?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T06:13:42+00:00

<img alt="Sztuczna inteligencja zabierze pracę? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lmkx2y-sztuczna-inteligencja-w-pracy-7346444/alternates/LANDSCAPE_1280" />
    - Zawsze tam, gdzie pojawiał się rozwój technologiczny, słychać było kasandryczne głosy, które wieszczyły zagładę. Do masowego technologicznego bezrobocia jednak nigdy nie doszło - mówi Jacek Mańko z Akademii Leona Koźmińskiego

## Szłapka: PKW powinna dokładnie przyjrzeć się finansowaniu Prawa i Sprawiedliwości
 - [https://tvn24.pl/polska/list-jaroslawa-kaczynskiego-do-zbigniewa-ziobry-adam-szlapka-pkw-powinna-dokladnie-przyjrzec-sie-finansowaniu-pis-st7987173?source=rss](https://tvn24.pl/polska/list-jaroslawa-kaczynskiego-do-zbigniewa-ziobry-adam-szlapka-pkw-powinna-dokladnie-przyjrzec-sie-finansowaniu-pis-st7987173?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T06:05:04+00:00

<img alt="Szłapka: PKW powinna dokładnie przyjrzeć się finansowaniu Prawa i Sprawiedliwości" src="https://tvn24.pl/najnowsze/cdn-zdjecie-193261-adam-szlapka-ph7987179/alternates/LANDSCAPE_1280" />
    PiS w oczywisty sposób naruszył ustawę o finansowaniu partii politycznej i wiedział o tym Jarosław Kaczyński już pięć lat temu - mówił w "Rozmowie Piaseckiego" w TVN24 minister do spraw Unii Europejskiej Adam Szłapka. Odniósł się do ujawnionego listu prezesa PiS do byłego ministra sprawiedliwości Zbigniewa Ziobry.

## Woda porwała auto w Bieszczadach. Kierowca nie żyje
 - [https://tvn24.pl/tvnmeteo/polska/woda-porwala-auto-w-bieszczadach-kierowca-nie-zyje-st7987177?source=rss](https://tvn24.pl/tvnmeteo/polska/woda-porwala-auto-w-bieszczadach-kierowca-nie-zyje-st7987177?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T06:00:20+00:00

<img alt="Woda porwała auto w Bieszczadach. Kierowca nie żyje" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3595722-woda-porwala-auto-w-bieszczadach-ph7987182/alternates/LANDSCAPE_1280" />
    Wezbrany potok porwał samochód w Bieszczadach. Na pomoc ruszyli strażacy i policja, ale kierowcy nie udało się uratować. Od poniedziałku nad regionem przechodzą burze z ulewnymi opadami deszczu, a w wielu miejscach jest niebezpiecznie.

## "Financial Times": Orban jedzie do Kijowa. Po raz pierwszy od czasu rosyjskiej inwazji
 - [https://tvn24.pl/swiat/viktor-orban-w-kijowie-premier-wegier-po-raz-pierwszy-na-ukrainie-od-czasu-rosyjskiej-inwazji-st7987147?source=rss](https://tvn24.pl/swiat/viktor-orban-w-kijowie-premier-wegier-po-raz-pierwszy-na-ukrainie-od-czasu-rosyjskiej-inwazji-st7987147?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T05:15:23+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3817748-viktor-orban-ph7987155/alternates/LANDSCAPE_1280" />
    Premier Węgier Viktor Orban pojedzie we wtorek do Kijowa, gdzie spotka się z prezydentem Ukrainy Wołodymyrem Zełenskim - podał brytyjski dziennik "Financial Times", powołując się na osoby zaznajomione ze sprawą. Będzie to pierwsza wizyta szefa węgierskiego rządu na Ukrainie od czasu rosyjskiej inwazji na ten kraj.

## 14 metrów od starego mostu wybudują nowy. Mieszkańcy chcą kładki pieszo-rowerowej
 - [https://tvn24.pl/tvnwarszawa/najnowsze/gora-kalwaria-chca-kladki-dla-pieszych-i-rowerzystow-na-moscie-kolejowym-st7987016?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/gora-kalwaria-chca-kladki-dla-pieszych-i-rowerzystow-na-moscie-kolejowym-st7987016?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T05:13:26+00:00

<img alt="14 metrów od starego mostu wybudują nowy. Mieszkańcy chcą kładki pieszo-rowerowej" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5087153-stary-most-w-gorze-kalwarii-ph7971988/alternates/LANDSCAPE_1280" />
    Kolejarze przymierzają się do budowy nowego mostu w Górze Kalwarii. - Dołóżmy do niego kładkę dla pieszych i rowerzystów - proponuje sołtys Glinek, które znajdują się po drugiej stronie Wisły. A dlaczego nie oddać im starego mostu?

## "To miały być pieniądze przekazane pod stołem". Ujawniamy nowe kulisy dotacji dla Fundacji Profeto
 - [https://tvn24.pl/premium/afera-funduszu-sprawiedliwosci-ujawniamy-nowe-kulisy-dotacji-dla-fundacji-profeto-st7986767?source=rss](https://tvn24.pl/premium/afera-funduszu-sprawiedliwosci-ujawniamy-nowe-kulisy-dotacji-dla-fundacji-profeto-st7986767?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T05:00:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3590806-osrodek-fundacji-profeto-ph7986754/alternates/LANDSCAPE_1280" />
    - Kiedy pojawiły się już pieniądze z funduszu, Jan przyszedł do mnie i powiedział, że ksiądz Michał musi zapłacić odpowiednim osobom od funduszu, co przy tym chodzą. Mieliśmy wymyślić, jak to zrobić, bo to miały być pieniądze przekazane pod stołem - mówi w rozmowie z tvn24.pl i OKO.press główny wykonawca ośrodka Fundacji Profeto budowanego za 100 milionów złotych z Funduszu Sprawiedliwości.

## Sytuacja na rynku nieruchomości sprzyja potencjalnym nabywcom
 - [https://tvn24.pl/biznes/nieruchomosci/sytuacja-na-rynku-nieruchomosci-sprzyja-potencjalnym-nabywcom-st7986986?source=rss](https://tvn24.pl/biznes/nieruchomosci/sytuacja-na-rynku-nieruchomosci-sprzyja-potencjalnym-nabywcom-st7986986?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T04:48:01+00:00

<img alt="Sytuacja na rynku nieruchomości sprzyja potencjalnym nabywcom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vxfzmp-liczba-transakcji-na-rynku-mieszkaniowym-wyhamowala-4564185/alternates/LANDSCAPE_1280" />
    W drugim kwartale deweloperzy wprowadzili o ponad jedną czwartą mniej mieszkań w porównaniu z początkiem roku - dowiadujemy się z raportu portalu rynekpierwotny.pl. Wskazano, że obecna sytuacja na rynku nieruchomości sprzyja kupującym.

## Amerykański Sąd Najwyższy zdecydował ws. immunitetu prezydenta. Biden: niech Bóg ocali naszą demokrację
 - [https://tvn24.pl/swiat/usa-sad-najwyzszy-zdecydowal-ws-immunitetu-prezydenta-joe-biden-komentuje-st7987124?source=rss](https://tvn24.pl/swiat/usa-sad-najwyzszy-zdecydowal-ws-immunitetu-prezydenta-joe-biden-komentuje-st7987124?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T04:06:57+00:00

<img alt="Amerykański Sąd Najwyższy zdecydował ws. immunitetu prezydenta. Biden: niech Bóg ocali naszą demokrację" src="https://tvn24.pl/najnowsze/cdn-zdjecie-984135-protest-przed-sadem-najwyzszym-usa-ph7987125/alternates/LANDSCAPE_1280" />
    Amerykański Sąd Najwyższy, głosami sędziów powołanych przez republikanów, zdecydował w sprawie immunitetu prezydenta, dzieląc go na "absolutny" i "domniemany". Joe Biden sprzeciwił się wyrokowi. - Dzisiejsza decyzja niemal z pewnością oznacza, że nie ma praktycznie żadnych ograniczeń co do tego, co prezydent może zrobić - powiedział.

## Pogoda na dziś - wtorek, 2.07. Wiele deszczowych miejsc, może się błyskać
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-wtorek-207-wiele-deszczowych-miejsc-moze-sie-blyskac-st7987038?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-wtorek-207-wiele-deszczowych-miejsc-moze-sie-blyskac-st7987038?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-07-02T00:00:00+00:00

<img alt="Pogoda na dziś - wtorek, 2.07. Wiele deszczowych miejsc, może się błyskać" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2m0gjz-deszczowo-6075525/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Wtorek 2.07 przyniesie wielu regionom Polski przelotne opady deszczu. Miejscami może zagrzmieć. Termometry pokażą od 17 do 23 stopni Celsjusza.

