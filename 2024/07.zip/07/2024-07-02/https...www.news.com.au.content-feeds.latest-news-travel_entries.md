# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## Grandma killed in horror crash pictured
 - [https://www.news.com.au/technology/motoring/on-the-road/townsville-woman-killed-in-horror-bus-crash-pictured/news-story/cab15a10131d151cf9ba8291b95327aa?from=rss-basic](https://www.news.com.au/technology/motoring/on-the-road/townsville-woman-killed-in-horror-bus-crash-pictured/news-story/cab15a10131d151cf9ba8291b95327aa?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-07-02T11:32:23.207422+00:00

A beloved grandmother who was killed in a horror bus crash alongside two others has been pictured for the first time.

## Country could charge Aussie tourists ‘six times more’
 - [https://www.news.com.au/travel/travel-advice/money/japan-could-charge-aussie-tourists-six-times-more-to-visit-world-heritage-site/news-story/0a61a433fb21525a14a29fca692ac381?from=rss-basic](https://www.news.com.au/travel/travel-advice/money/japan-could-charge-aussie-tourists-six-times-more-to-visit-world-heritage-site/news-story/0a61a433fb21525a14a29fca692ac381?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-07-02T03:57:02.983079+00:00

Japan is considering charging tourists six times more to visit a popular world heritage site amid a surge in visitors.

## KFC opens epic world-first lodge in Australia
 - [https://www.news.com.au/travel/travel-advice/accommodation/kfc-opens-epic-worldfirst-lodge-in-australia/news-story/3046205c3f21063412e344d56010bbec?from=rss-basic](https://www.news.com.au/travel/travel-advice/accommodation/kfc-opens-epic-worldfirst-lodge-in-australia/news-story/3046205c3f21063412e344d56010bbec?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-07-02T01:46:59.780679+00:00

KFC fans are in for a treat as the fast-food outlet has just opened a pop-up lodge complete with all the fried chicken you could imagine.

