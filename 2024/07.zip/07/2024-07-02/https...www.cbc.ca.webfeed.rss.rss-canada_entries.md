# Source:CBC | Canada News, URL:https://www.cbc.ca/webfeed/rss/rss-canada, language:en

## Ontario government won't say if it will take offers to fix Science Centre
 - [https://www.cbc.ca/news/canada/toronto/science-centre-repairs-board-trustees-1.7251940?cmp=rss](https://www.cbc.ca/news/canada/toronto/science-centre-repairs-board-trustees-1.7251940?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-07-02T15:21:20+00:00

<img alt="An aerial view of the science centre building and property." height="349" src="https://i.cbc.ca/1.7247206.1719534086!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/ontario-science-centre-and-eglinton-lrt.jpg" title="Toronto council has asked city staff to report back next month on the feasibility of the taking over operations of the Ontario Science Centre. " width="620" /><p>The province won't say whether it will take private citizens up on their offers to foot the bill to rehab the science centre.</p>

## Ontario doctor acquitted of murder, criminal negligence charges in deaths of 4 patients
 - [https://www.cbc.ca/news/canada/ottawa/doctor-brian-nadler-charge-hawkesbury-ontario-acquittal-1.7251884?cmp=rss](https://www.cbc.ca/news/canada/ottawa/doctor-brian-nadler-charge-hawkesbury-ontario-acquittal-1.7251884?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-07-02T10:36:16+00:00

<img alt="A photo of a man with glasses." height="349" src="https://i.cbc.ca/1.5966660.1683907681!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/brian-nadler.jpg" title="Nadler faced two unprofessional conduct charges during his time at the University of Saskatchewan. " width="620" /><p>Dr. Brian Nadler, who formerly practised at a hospital in Hawkesbury, Ont., and was facing eight charges in connection to the deaths of four patients, was officially acquitted Tuesday.</p>

## Some daycares closed as boil-water advisory continues in Halifax area
 - [https://www.cbc.ca/news/canada/nova-scotia/daycares-closed-as-boil-water-advisory-continues-in-halifax-area-1.7251547?cmp=rss](https://www.cbc.ca/news/canada/nova-scotia/daycares-closed-as-boil-water-advisory-continues-in-halifax-area-1.7251547?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-07-02T07:07:09+00:00

<img alt="Clear water comes from a silver tap" height="349" src="https://i.cbc.ca/1.3665183.1718305253!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/water-tap.jpg" title="Moncton is promoting its tap water by creating filling stations throughout the city. " width="620" /><p>Some daycares in the Halifax area are closed today due to a boil-water advisory affecting a large swath of the municipality. The advisory followed a power outage at a water treatment facility.</p>

