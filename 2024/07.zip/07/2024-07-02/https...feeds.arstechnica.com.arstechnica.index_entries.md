# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## Two of the German military’s new spy satellites appear to have failed in orbit
 - [https://arstechnica.com/?p=2035061](https://arstechnica.com/?p=2035061)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T21:48:42+00:00

Did OHB really not test the satellite antennas on the ground?

## Apple Vision Pro, new cameras fail user-repairability analysis
 - [https://arstechnica.com/?p=2034998](https://arstechnica.com/?p=2034998)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T21:32:31+00:00

Meta Quest 3, PS5 Slim also received failing grades despite new right-to-repair laws.

## AI trains on kids’ photos even when parents use strict privacy settings
 - [https://arstechnica.com/?p=2035015](https://arstechnica.com/?p=2035015)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T19:37:25+00:00

Even unlisted YouTube videos are used to train AI, watchdog warns.

## US prepares for bird flu pandemic with $176M Moderna vaccine deal
 - [https://arstechnica.com/?p=2035014](https://arstechnica.com/?p=2035014)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T19:14:50+00:00

Phase 3 trial is expected to begin next year.

## “RegreSSHion” vulnerability in OpenSSH gives attackers root on Linux
 - [https://arstechnica.com/?p=2035011](https://arstechnica.com/?p=2035011)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T19:03:17+00:00

Full system compromise possible by peppering servers with thousands of connection requests.

## Google’s greenhouse gas emissions jump 48% in five years
 - [https://arstechnica.com/?p=2035001](https://arstechnica.com/?p=2035001)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T17:25:45+00:00

Google's 2030 "Net zero" target looks increasingly doubtful as AI use soars.

## Here’s how Michelin plans to make its tires more renewable
 - [https://arstechnica.com/?p=2034974](https://arstechnica.com/?p=2034974)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T16:35:02+00:00

The tire company wants a completely sustainable tire by 2050.

## Call the ant doctor: Amputation gives injured ants a leg up on infections
 - [https://arstechnica.com/?p=2034534](https://arstechnica.com/?p=2034534)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T15:00:58+00:00

"Ants are able to diagnose a wound, see if it's infected... and treat it accordingly."

## Tesla posts disappointing production and sales numbers for Q2 2024
 - [https://arstechnica.com/?p=2034933](https://arstechnica.com/?p=2034933)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T14:25:28+00:00

Sales fell by 5 percent, with production cut by more.

## Surface Pro 11 and Laptop 7 review: An Apple Silicon moment for Windows
 - [https://arstechnica.com/?p=2032066](https://arstechnica.com/?p=2032066)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T14:04:09+00:00

Superfluous AI features and compatibility issues don't detract from good PCs.

## Yes, you should be a little freaked out about Hurricane Beryl
 - [https://arstechnica.com/?p=2034854](https://arstechnica.com/?p=2034854)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T13:12:28+00:00

"It's hard to communicate how unbelievable this is."

## Ars Live: Join us July 9 for a lively discussion on time travel in the movies
 - [https://arstechnica.com/?p=2034631](https://arstechnica.com/?p=2034631)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T11:00:21+00:00

<em>Bill and Ted</em> co-creator Ed Solomon joins physicists Sean Carroll and Jim Kakalios

## Firefly is building fast and breaking things on path to a reusable rocket
 - [https://arstechnica.com/?p=2034632](https://arstechnica.com/?p=2034632)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-07-02T00:29:55+00:00

"For our base design, we're designing around return to launch site propulsive landing."

