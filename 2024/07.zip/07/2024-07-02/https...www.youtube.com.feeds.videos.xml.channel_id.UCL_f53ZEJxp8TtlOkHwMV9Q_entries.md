# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## What Makes Companies Successful?
 - [https://www.youtube.com/watch?v=Wn3JwR2odnU](https://www.youtube.com/watch?v=Wn3JwR2odnU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-07-02T21:00:29+00:00



## The Parasite Problem | Chris Olson
 - [https://www.youtube.com/watch?v=tcw8tQhQLd4](https://www.youtube.com/watch?v=tcw8tQhQLd4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-07-02T17:00:29+00:00

This is a clip from yesterday's podcast release with cyber security expert Chris Olson. In it, he and Dr. Peterson discuss the origins of biological sex as a means to survive against parasites, the advent of parasitic programs on the internet, and the lack of an equal safeguard there on. 

Dr. Peterson's extensive catalog is available now on DailyWire+: https://bit.ly/3KrWbS8

ALL LINKS: https://linktr.ee/drjordanbpeterson


// COURSES //
Discovering Personality: https://jordanbpeterson.com/personality
Self Authoring Suite: https://selfauthoring.com
Understand Myself (personality test): https://understandmyself.com

// BOOKS //
Beyond Order: 12 More Rules for Life: https://jordanbpeterson.com/Beyond-Order
12 Rules for Life: An Antidote to Chaos: https://jordanbpeterson.com/12-rules-for-life
Maps of Meaning: The Architecture of Belief: https://jordanbpeterson.com/maps-of-meaning

#JordanPeterson #JordanBPeterson #DrJordanPeterson #DrJordanBPeterson #DailyWirePlus

## Internet Scams Are Taking Over
 - [https://www.youtube.com/watch?v=fu0TFNgkAVI](https://www.youtube.com/watch?v=fu0TFNgkAVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-07-02T16:00:29+00:00



