# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Kiasmos performed a magnificent set at Citadel of Sisteron  #cercle #cerclemusic #electronicmusic
 - [https://www.youtube.com/watch?v=_4G81xNDkKE](https://www.youtube.com/watch?v=_4G81xNDkKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2024-07-02T17:00:32+00:00

Full set available soon on our channel

## Kiasmos @ Citadel of Sisteron, France #cercle #electronicmusic #kiasmos
 - [https://www.youtube.com/watch?v=0kZDXbca9gs](https://www.youtube.com/watch?v=0kZDXbca9gs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2024-07-02T13:00:53+00:00

@Kiasmos performed a dreamlike live set at Citadelle de Sisteron, France.
Full set soon on our channel. 
#cercle #electronicmusic #kiasmos

