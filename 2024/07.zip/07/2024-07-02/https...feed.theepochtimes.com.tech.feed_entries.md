# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## EU Commission Alleges Meta’s Subscription Model Breaches Digital Markets Act
 - [https://www.theepochtimes.com/business/eu-commission-alleges-metas-subscription-model-breaches-digital-markets-act-5678724](https://www.theepochtimes.com/business/eu-commission-alleges-metas-subscription-model-breaches-digital-markets-act-5678724)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-07-02T14:07:16+00:00

A smartphone and a computer screen displaying the logos of the social media platform Facebook and its parent company Meta are seen in Toulouse, southwestern France, on Jan. 12, 2023. (Lionel Bonaventure/AFP via Getty Images)

## Biden Administration Invests $504 Million in 12 Tech Hubs Nationwide
 - [https://www.theepochtimes.com/us/biden-administration-invests-504-million-in-12-tech-hubs-nationwide-5678695](https://www.theepochtimes.com/us/biden-administration-invests-504-million-in-12-tech-hubs-nationwide-5678695)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-07-02T12:22:25+00:00

Commerce Secretary Gina Raimondo on Capitol Hill, on Oct. 4, 2023. (Saul Loeb/AFP via Getty Images)

