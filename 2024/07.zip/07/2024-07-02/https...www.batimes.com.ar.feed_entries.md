# Source:Argentina - Buenos Aires Times, URL:https://www.batimes.com.ar/feed, language:en

## Argentina poised for first China corn cargoes in 15 years
 - [https://www.batimes.com.ar/news/economy/argentina-poised-for-first-china-corn-cargoes-in-15-years.phtml](https://www.batimes.com.ar/news/economy/argentina-poised-for-first-china-corn-cargoes-in-15-years.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-07-02T18:50:21+00:00

<p><img alt="brazil corn maize" src="https://fotos.perfil.com/2023/04/21/trim/540/304/brazil-corn-maize-1551494.jpg" /></p>Argentina is preparing corn shipments to China that will be the first in 15 years, the latest move by the two countries to expand agricultural trade.
 <a href="https://www.batimes.com.ar/news/economy/argentina-poised-for-first-china-corn-cargoes-in-15-years.phtml">Leer más</a>

## Milei calls Lula an ‘idiot dinosaur’ ahead of Brazil visit
 - [https://www.batimes.com.ar/news/latin-america/milei-calls-lula-an-idiot-dinosaur-ahead-of-brazil-visit.phtml](https://www.batimes.com.ar/news/latin-america/milei-calls-lula-an-idiot-dinosaur-ahead-of-brazil-visit.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-07-02T18:35:15+00:00

<p><img alt="President Javier Milei at the G7 Leaders Summit in Italy, 2024." src="https://fotos.perfil.com/2024/07/02/trim/540/304/president-javier-milei-at-the-g7-leaders-summit-in-italy-2024-1829018.jpg" /></p>President Milei brands Luiz Inácio Lula da Silva “an idiot dinosaur” and a Communist, escalating long-running feud on eve of his visit to Brazil. <a href="https://www.batimes.com.ar/news/latin-america/milei-calls-lula-an-idiot-dinosaur-ahead-of-brazil-visit.phtml">Leer más</a>

## Milei doubles down on criticism of Bolivia’s government, Lula
 - [https://www.batimes.com.ar/news/latin-america/milei-again-casts-doubt-on-coup-claim-by-bolivias-government.phtml](https://www.batimes.com.ar/news/latin-america/milei-again-casts-doubt-on-coup-claim-by-bolivias-government.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-07-02T15:10:48+00:00

<p><img alt="Luis Arce, Javier Milei," src="https://fotos.perfil.com/2024/07/02/trim/540/304/luis-arce-javier-milei-1828871.jpg" /></p>Javier Milei doubles down on his criticism of Bolivian government's "staged fraud" and Brazilian President Lula, calling the veteran leftist "the perfect idiot."
 <a href="https://www.batimes.com.ar/news/latin-america/milei-again-casts-doubt-on-coup-claim-by-bolivias-government.phtml">Leer más</a>

## President Milei proves boon and curse for Argentine bank stocks
 - [https://www.batimes.com.ar/news/economy/president-milei-proves-boon-and-curse-for-argentine-bank-stocks.phtml](https://www.batimes.com.ar/news/economy/president-milei-proves-boon-and-curse-for-argentine-bank-stocks.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-07-02T14:30:53+00:00

<p><img alt="President Javier Milei." src="https://fotos.perfil.com/2024/06/26/trim/540/304/president-javier-milei-1825519.jpg" /></p>Argentine banking stocks in New York are tumbling as the government slashes interest rates and crimps new borrowing. <a href="https://www.batimes.com.ar/news/economy/president-milei-proves-boon-and-curse-for-argentine-bank-stocks.phtml">Leer más</a>

## Venezuela's Maduro says talks to resume with United States
 - [https://www.batimes.com.ar/news/latin-america/venezuelas-maduro-says-talks-to-resume-with-united-states.phtml](https://www.batimes.com.ar/news/latin-america/venezuelas-maduro-says-talks-to-resume-with-united-states.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-07-02T14:09:02+00:00

<p><img alt="Nicolás Maduro" src="https://fotos.perfil.com/2024/07/02/trim/540/304/nicolas-maduro-1828842.jpg" /></p>Nicolás Maduro on Monday announced the resumption of dialogue with the United States. <a href="https://www.batimes.com.ar/news/latin-america/venezuelas-maduro-says-talks-to-resume-with-united-states.phtml">Leer más</a>

