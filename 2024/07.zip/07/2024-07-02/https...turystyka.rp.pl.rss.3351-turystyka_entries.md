# Source:Turystyka, URL:https://turystyka.rp.pl/rss/3351-turystyka, language:pl-PL

## Fala pożarów w Grecji. Itaka: Na wszelki wypadek ewakuowaliśmy klientów na Kos
 - [https://turystyka.rp.pl/biura-podrozy/art40754821-fala-pozarow-w-grecji-itaka-na-wszelki-wypadek-ewakuowalismy-klientow-na-kos](https://turystyka.rp.pl/biura-podrozy/art40754821-fala-pozarow-w-grecji-itaka-na-wszelki-wypadek-ewakuowalismy-klientow-na-kos)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-07-02T16:16:33+00:00

W Grecji – wokół Aten, na Krecie i na Kos – szaleją pożary. Biuro podróży Itaka poinformowało, że prewencyjnie ewakuowało 362 klientów wypoczywających w rejonie miasta Kardamena na Kos. Wszyscy już wrócili do hoteli.

## Ewa Rożnowicz w zespole Eximu Tours. Cel - więcej klientów, mniej reklamacji
 - [https://turystyka.rp.pl/biura-podrozy/art40752201-ewa-roznowicz-w-zespole-eximu-tours-cel-wiecej-klientow-mniej-reklamacji](https://turystyka.rp.pl/biura-podrozy/art40752201-ewa-roznowicz-w-zespole-eximu-tours-cel-wiecej-klientow-mniej-reklamacji)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-07-02T09:36:06+00:00

Do działu jakości biura podróży Exim Tours dołączyła Ewa Rożnowicz, wcześniej kierownik działu helpdesk w Join UP! Polska.

## Booking nie wyklucza opuszczenia Europy. „Unijne regulacje są głupie”
 - [https://turystyka.rp.pl/hotele/art40747211-booking-nie-wyklucza-opuszczenia-europy-unijne-regulacje-sa-glupie](https://turystyka.rp.pl/hotele/art40747211-booking-nie-wyklucza-opuszczenia-europy-unijne-regulacje-sa-glupie)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-07-02T04:06:00+00:00

Prezes Booking Holdings ostro krytykuje Unię Europejską, która nie chce się zgodzić na stosowanie przez portale rezerwacyjne w umowach z hotelami klauzuli najniższej ceny. Nie wyklucza wyjścia z Unii Europejskiej z powodu „głupich regulacji”.

