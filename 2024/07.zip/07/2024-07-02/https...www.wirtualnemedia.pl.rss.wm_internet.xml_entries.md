# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Minister cyfryzacji spotkał się w USA z przedstawicielami Google i Mety
 - [https://www.wirtualnemedia.pl/artykul/minister-cyfryzacji-krzysztof-gawkowski-usa-spotkanie-z-przedstawicielami-google-i-mety](https://www.wirtualnemedia.pl/artykul/minister-cyfryzacji-krzysztof-gawkowski-usa-spotkanie-z-przedstawicielami-google-i-mety)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-07-02T09:53:16.302015+00:00

Wicepremier i minister cyfryzacji Krzysztof Gawkowski przybył z wizytą do USA. W San Francisco, mieście znanym z Doliny Krzemowej, spotkał się z przedstawicielami firm Palo Alto Networks – Nvidia Intel, Visa, Google i Meta.

## Niższe ceny tylko dla klubowiczów. E-sklepy odzieżowe z zarzutami
 - [https://www.wirtualnemedia.pl/artykul/renee-pl-born2be-pl-odziez-sklepy-promocje-opinie-uokik](https://www.wirtualnemedia.pl/artykul/renee-pl-born2be-pl-odziez-sklepy-promocje-opinie-uokik)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-07-02T08:49:37.325713+00:00

Prezes Urzędu Ochrony Konkurencji i Konsumentów postawił trzy zarzuty spółce AzaGroup dotyczące jej sklepów internetowych z odzieżą Renee.pl i Born2Be.pl. Według regulatora platformy nie dostosowały się do wymogów dyrektywy Omnibus i mogły wprowadzać klientów w błąd co do promocji cenowych.

## Audioteka w nowej odsłonie
 - [https://www.wirtualnemedia.pl/artykul/audioteka-nowa-wersja-jak-korzystac](https://www.wirtualnemedia.pl/artykul/audioteka-nowa-wersja-jak-korzystac)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-07-02T05:29:44.632256+00:00

Od początku lipca br. dostępna jest nowa odsłona strony internetowej Audioteki z odświeżonym intererfejsem. Serwis mocniej stawia również na swoje superprodukcje i audioseriale.

## Grupa naTemat zarobiła mniej. Przez wzrost kosztów i niższe dywidendy
 - [https://www.wirtualnemedia.pl/artykul/natemat-wlasciciel-ile-zarabia-tomasz-lis-w-2023-r](https://www.wirtualnemedia.pl/artykul/natemat-wlasciciel-ile-zarabia-tomasz-lis-w-2023-r)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-07-02T04:24:09.120317+00:00

W ub.r. spółka Glob360, zarządzająca m.in. portalem naTemat.pl, przy spadku wpływów o 4 proc. i wzroście kosztów operacyjnych o 8,3 proc. zarobiła na czysto 1,1 mln zł, o ponad połowę mniej niż przed rokiem.

