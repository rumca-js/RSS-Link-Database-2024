# Source:ScreenGeek, URL:https://www.screengeek.net/feed, language:en-US

## ‘The Umbrella Academy’ Showrunner Faces Allegations for “Sexist, Homophobic & Transphobic” Comments
 - [https://www.screengeek.net/2024/07/02/the-umbrella-academy-showrunner-sexist-homophobic-transphobic-allegations](https://www.screengeek.net/2024/07/02/the-umbrella-academy-showrunner-sexist-homophobic-transphobic-allegations)
 - RSS feed: https://www.screengeek.net/feed
 - date published: 2024-07-02T22:55:40+00:00

<p>Netflix is preparing to conclude their hit series The Umbrella Academy with a fourth season. As such, fans are both upset and excited to see the series come to an end. However, some drama has surfaced prior to the final season&#8217;s release, with allegations being made against Steve Blackman, showrunner of The Umbrella Academy. It&#8217;s [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/07/02/the-umbrella-academy-showrunner-sexist-homophobic-transphobic-allegations/">&#8216;The Umbrella Academy&#8217; Showrunner Faces Allegations for &#8220;Sexist, Homophobic &#038; Transphobic&#8221; Comments</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## Surprise Sequel Reportedly On The Way For Hit 2017 Movie
 - [https://www.screengeek.net/2024/07/02/2017-hit-movie-suprise-sequel](https://www.screengeek.net/2024/07/02/2017-hit-movie-suprise-sequel)
 - RSS feed: https://www.screengeek.net/feed
 - date published: 2024-07-02T18:00:04+00:00

<p>It&#8217;s always interesting to see which Hollywood movies will have the opportunity to receive sequels and which will not. Especially when it comes to newer films, it seems more often than not that if it&#8217;s going to get a sequel &#8211; it will happen right away. As such, it&#8217;s quite a surprise to see a [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/07/02/2017-hit-movie-suprise-sequel/">Surprise Sequel Reportedly On The Way For Hit 2017 Movie</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

