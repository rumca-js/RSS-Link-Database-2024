# Source:Eli the Computer Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ, language:en-US

## Eli the Computer Guy's livestream
 - [https://www.youtube.com/watch?v=WCwI-X60ECM](https://www.youtube.com/watch?v=WCwI-X60ECM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ
 - date published: 2024-07-02T19:13:57+00:00



## Eli the Computer Guy's livestream
 - [https://www.youtube.com/watch?v=ihoAXPmvKTs](https://www.youtube.com/watch?v=ihoAXPmvKTs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ
 - date published: 2024-07-02T17:11:43+00:00

Test

