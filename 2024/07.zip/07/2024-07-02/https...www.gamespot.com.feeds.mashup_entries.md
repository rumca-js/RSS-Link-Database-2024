# Source:GameSpot, URL:https://www.gamespot.com/feeds/mashup, language:en-US

## Destiny 2 Claws Of The Wolf God Roll Guide
 - [https://www.gamespot.com/articles/destiny-2-claws-of-the-wolf-god-roll-guide/1100-6524666/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/destiny-2-claws-of-the-wolf-god-roll-guide/1100-6524666/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T22:32:00+00:00

<p dir="ltr">Like everything else in <a href="https://www.gamespot.com/games/destiny-2/">Destiny 2</a> in the aftermath of <a href="https://www.gamespot.com/articles/destiny-2-the-final-shape-guides-hub/1100-6523936/">The Final Shape</a>, the <a href="https://www.gamespot.com/articles/destiny-2-iron-banner-guide/1100-6524661/">Iron Banner</a> has been altered. The PvP event now sports a two-week duration instead of one and is adding two weapons to its current pool of rewards--both of which are former Iron Banner weapons that now have new perks and rolls. The first of those, Claws of the Wolf, is an extremely deadly pulse rifle with a lot of aim assist that might help you snap some headshots over the next two weeks of competition.</p><p dir="ltr">You can get Claws of the Wolf easily enough from Iron Banner, but there are a lot of combinations you probably won't want, especially with its mixed-up perk pool. Here's how you can nab Claws of the Wolf and what perks are worth chasing on it.

## Super Pocket Technos And Atari Editions - Check Out These $60, Cartridge-Based Gaming Handhelds
 - [https://www.gamespot.com/articles/super-pocket-technos-and-atari-editions-check-out-these-60-cartridge-based-gaming-handhelds/1100-6524660/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/super-pocket-technos-and-atari-editions-check-out-these-60-cartridge-based-gaming-handhelds/1100-6524660/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T21:31:00+00:00

<p>Blaze Entertainment has kept busy this year, with <a href="https://www.gamespot.com/articles/preorder-evercade-alpha-street-fighter-and-mega-man-arcade-cabinets-at-amazon-before-they-sell-out/1100-6523783/">Street Fighter and Mega Man countertop cabinets</a> arriving on November 28 and the <a href="https://www.gamespot.com/articles/evercade-retro-handheld-console-tomb-raider-bundle-preorder-guide/1100-6522681/">Evercade EXP-R and VS-R</a> dropping later this month. As if the team wasn't busy enough, two new Super Pocket handhelds from Hyper Mega Tech, an Evercade spin-off, are arriving this October--the <a href="https://www.amazon.com/s?k=super pocket&amp;ref=nb_sb_noss&amp;tag=gamespot-preorders-20">Super Pocket Atari Edition</a> and <a href="https://www.amazon.com/s?k=super pocket&amp;ref=nb_sb_noss&amp;tag=gamespot-preorders-20">Super Pocket Technos Edition</a>. They'll be available to preorder on <strong>July 31</strong>, and like the <a href="https://www.gamespot.com/articles/

## Raspberry Pi Founder Is Releasing Two Books About Retro Game Development
 - [https://www.gamespot.com/articles/raspberry-pi-founder-is-releasing-two-books-about-retro-game-development/1100-6524652/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/raspberry-pi-founder-is-releasing-two-books-about-retro-game-development/1100-6524652/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T21:04:00+00:00

<p><a href="https://www.amazon.com/Code-Classics-I-David-Crookes/dp/1916868193?tag=gamespot-preorders-20">Code the Classics</a> aims to teach new programmers and nostalgic fans alike how to create retro games inspired by classics from the '70s and '80s. Published by Raspberry Pi Press, and featuring games coded by Raspberry Pi founder Eben Upton, Code the Classics will be published across two volumes in the coming months. <a href="https://www.amazon.com/Code-Classics-I-David-Crookes/dp/1916868193?tag=gamespot-preorders-20">Volume 1</a> is set to release on August 27, while <a href="https://www.amazon.com/Code-Classics-II-David-Crookes/dp/1916868045?tag=gamespot-preorders-20">Volume 2</a> will be available starting November 12. Both books are available to preorder now for $30 at Amazon.</p><ul><li><a href="https://www.amazon.com/Code-Classics-I-David-Crookes/dp/1916868193?tag=gamespot-preorders-20">Code the Classics Volume 1 (2nd Edition)</a> -- $30</li><li><a href="https://www.amazon.

## The Best Third-Party PS5 Controller Is On Sale At Amazon For A Great Price
 - [https://www.gamespot.com/articles/the-best-third-party-ps5-controller-is-on-sale-at-amazon-for-a-great-price/1100-6518213/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/the-best-third-party-ps5-controller-is-on-sale-at-amazon-for-a-great-price/1100-6518213/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T20:08:00+00:00

<p dir="ltr">If you're in the market for a new PS5, PS4, or even PC controller, one of the best premium options available now is the <a href="https://www.amazon.com/Wireless-Controller-Midnight-Triggers-PlayStation-5/dp/B0CKH24NK4?tag=gamespot-primeday-20">Victrix Pro BFG</a>. This high-end modular controller offers a wealth of versatility, superb ergonomics, and ample customization features that make it an ideal choice for those who want a more feature-rich controller than the standard DualSense (or most PC controllers). For a limited time, you can save on two different models of the Victrix Pro BFG's PlayStation edition at Amazon.</p><div><div><div class="norewrite" title="">           <a href="https://www.amazon.com/Wireless-Controller-Midnight-Triggers-PlayStation-5/dp/B0CKH24NK4?tag=gamespot-primeday-20">See at Amazon</a> </div></div></div><p dir="ltr"> </p><p dir="ltr"> </p><a href="https://www.gamespot.com/articles/the-best-third-party-ps5-controller-is-on-sale-at-amazon-for-a-

## Is Stardew Valley Cross-Platform?
 - [https://www.gamespot.com/articles/is-stardew-valley-cross-platform/1100-6524663/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/is-stardew-valley-cross-platform/1100-6524663/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T19:57:00+00:00

<p><a href="https://www.gamespot.com/games/stardew-valley/">Stardew Valley</a>, the massive indie farming simulator, lets you and up to three friends run a farm together, via online play or couch co-op. However, since multiplayer was added post-launch and the majority of development is done by one person, there are a few modern features missing from the multiplayer. One of those features is cross-platform play, which isn't in Stardew Valley.</p><h2 dir="ltr">Stardew Valley cross-platform details</h2><p dir="ltr">Stardew Valley currently does not have cross-platform multiplayer, and it seems likely that it never will. That means if you want to play multiplayer, everyone will need to be in the same family of platforms, like Xbox or PlayStation. If one person is on Nintendo Switch and the other is on PC, you cannot play together.</p><p dir="ltr">Stardew Valley developer Eric Barone--also known as ConcernedApe--has not commented on cross-platform multiplayer in recent years, but did menti

## Dragon Age: The Veilguard Has A "No Death" Setting
 - [https://www.gamespot.com/articles/dragon-age-the-veilguard-has-a-no-death-setting/1100-6524662/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/dragon-age-the-veilguard-has-a-no-death-setting/1100-6524662/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T19:30:00+00:00

<p>BioWare's upcoming fantasy RPG, <a href="https://www.gamespot.com/articles/dragon-age-dreadwolf-everything-we-know-about-biowares-upcoming-fantasy-rpg/1100-6503858/">Dragon Age: The Veilguard</a>, has a lot of changes to the way combat works, and one of them is a "no death" setting that allows players to avoid having their character die mid-combat.</p><p dir="ltr">"[None of the difficulty settings] are a cheat," game director Corrine Busche recently explained (via <a href="https://www.gameinformer.com/exclusive/2024/07/01/a-look-at-dragon-age-the-veilguards-difficulty-options-and-gameplay">Game Informer</a>). "It's an option to make sure players of all abilities can show up."</p><p dir="ltr">The game includes four difficulty settings: Storyteller, Adventurer, Nightmare, and Unbound. Nightmare offers an intense challenge, and once you select that mode, it's permanent, unlike the other difficulty options. Meanwhile, Unbound exists as a customizable mode where players can tweak specif

## Iron Banner Returns In Destiny 2: The Final Shape--Here's Everything You Need To Know
 - [https://www.gamespot.com/articles/destiny-2-iron-banner-guide/1100-6524661/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/destiny-2-iron-banner-guide/1100-6524661/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T19:28:00+00:00

<p dir="ltr">The first <a href="https://www.gamespot.com/articles/destiny-2s-iron-banner-extends-to-two-weeks-with-more-changes/1100-6524577/">Iron Banner</a> of the post-<a href="https://www.gamespot.com/articles/destiny-2-the-final-shape-guides-hub/1100-6523936/">Final Shape</a> era has arrived in <a href="https://www.gamespot.com/games/destiny-2/">Destiny 2</a>, bringing a fairly significant change to the formula for a PvP event Bungie has included in the game for the last 10 years. For the first time, the usually week-long event will now span <em>two</em> weeks. It also brings some reprised guns back for you to chase, complete with new perks.</p><p dir="ltr">While the Iron Banner is pretty straightforward--it's a 6-on-6 multiplayer event with its own set of rewards, reputation track, and Triumph seal--there are a few idiosyncrasies to keep in mind, particularly if you're new to Destiny 2 or haven't played in a while. Wearing and using Iron Banner gear offers some significant benef

## Baldur's Gate 3 Helped Inspire These New D&D Rules
 - [https://www.gamespot.com/articles/baldurs-gate-3-helped-inspire-these-new-dd-rules/1100-6524659/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/baldurs-gate-3-helped-inspire-these-new-dd-rules/1100-6524659/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T18:54:00+00:00

<p>GMs (Game Masters) are always taking inspiration from other media to implement new ideas into their world, and it looks like Wizards of the Coast is no different, because Larian Studios<a href="https://www.gamespot.com/games/baldurs-gate-3/"> Baldur's Gate 3</a> has directly influenced how certain mechanics now work in Dungeons &amp; Dragons.</p><p dir="ltr">The news comes from the<a href="https://www.youtube.com/watch?v=P0rXo-Wp_II&amp;t=7s"> official Dungeons &amp; Dragons YouTube channel</a> (via<a href="https://www.eurogamer.net/dungeons-dragons-rules-update-includes-changes-prompted-by-games-lead-designer-playing-baldurs-gate-3"> Eurogamer</a>), where D&amp;D developers explain the 2024 Player's Handbook. Lead designer Jeremy Crawford says his time with Baldur's Gate 3 played a huge part in changing the rules for a few spells, including Cloud of Daggers and Produce Flame.</p><div>          </div><p dir="ltr">Now, whenever a spell caster uses Cloud of Daggers, they can move it 

## Xbox Servers Are Down, Some People Unable To Log In Or Play Games
 - [https://www.gamespot.com/articles/xbox-live-servers-down/1100-6524658/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/xbox-live-servers-down/1100-6524658/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T18:44:00+00:00

<p>Xbox's online servers are down today, July 2, with some people reporting that they are having difficulty connecting to games and services on the platform.</p><p>For what it's worth, <a href="https://support.xbox.com/en-US/xbox-live-status">the official Xbox server status website</a> says all services and up and running normally. However, with a server network as large as Xbox's, your mileage may vary. Some people are unable to log in at all. <a href="https://x.com/MSFS_Support/status/1808210169873981645">Microsoft's own game accounts</a> have acknowledged the server troubles. "We apologize for the inconvenience," Microsoft said.</p><p>The Xbox Support account said Microsoft is "aware that some users have been disconnected from Xbox Live." The company said it is "investigating" the matter. </p><a href="https://www.gamespot.com/articles/xbox-live-servers-down/1100-6524658/?ftag=CAD-01-10abi2f/">Continue Reading at GameSpot</a>

## Ryan Reynolds Pitched Deadpool 3 As An Indie Comedy And Other Things We Just Learned About Deadpool & Wolverine
 - [https://www.gamespot.com/gallery/ryan-reynolds-pitches-deadpool-3-as-an-indie-comedy-and-other-things-we-just-learned-about-deadpool-wolverine/2900-5563](https://www.gamespot.com/gallery/ryan-reynolds-pitches-deadpool-3-as-an-indie-comedy-and-other-things-we-just-learned-about-deadpool-wolverine/2900-5563)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T18:18:00+00:00

<p><h2>Deadpool &amp; Wolverine is coming soon</h2><img src="https://www.gamespot.com/a/uploads/scale_large/1179/11799911/4328081-screenshot2024-07-02at12.46.01pm.png" /><br /><h3><p> The next Deadpool movie is not Deadpool 3 but instead a team-up called Deadpool &amp; Wolverine starring both Ryan Reynolds as Deadpool and Hugh Jackman as Wolverine. The film releases on July 26, and it's expected to be a box office smash given how much build-up and hype there is surrounding it. </p><p><a href="https://ew.com/deadpool-and-wolverine-cover-story-cameos-future-marvel-mutants-ryan-reynolds-hugh-jackman-8672079?taid=668424b66190110001ee2f33&amp;utm_campaign=entertainmentweekly_entertainmentweekly&amp;utm_content=new&amp;utm_medium=social&amp;utm_source=twitter.com">Entertainment Weekly</a> recently spoke to Reynolds, Jackman, director Shawn Levy, and others involved in the movie. It's a great read and you should go check it out. </p><p>In this gallery, we're rounding up five things we learne

## Zenless Zone Zero Everything To Know
 - [https://www.gamespot.com/videos/zenless-zone-zero-everything-to-know/2300-6464532](https://www.gamespot.com/videos/zenless-zone-zero-everything-to-know/2300-6464532)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T18:14:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4328187-4182526-zzz_site.jpg" width="480" /> Everyone loves free stuff and Hoyoverse’s latest free-to-play adventure is finally here! Here is everything you need to know about Zenless Zone Zero.

## Walking Dead Star Says The Show Overdid It When This Happened
 - [https://www.gamespot.com/articles/walking-dead-star-says-the-show-overdid-it-when-this-happened/1100-6524655/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/walking-dead-star-says-the-show-overdid-it-when-this-happened/1100-6524655/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T18:02:00+00:00

<p>The Walking Dead actor Andrew Lincoln, who played Rick Grimes on the zombie series, has commented on how he believes the AMC show "over-egged the omelette" at one point. Speaking to <a href="https://www.empireonline.com/tv/news/the-walking-dead-andrew-lincoln-glenn-death-over-egged/">Empire</a>, Lincoln said the infamous and gory death of Steven Yeun's Glenn was when the show might have gone too far.</p><p>On the show (and in the comics) Glenn is brutally murdered by Jeffrey Dean Morgan's Negan, with Negan ferociously bludgeoning Glenn to death with a barb-wire-wrapped baseball bat.</p><p>"I do still think [Glenn's death] might have been when we over-egged the omelette," he said. "Maybe it was lingering too much."</p><a href="https://www.gamespot.com/articles/walking-dead-star-says-the-show-overdid-it-when-this-happened/1100-6524655/?ftag=CAD-01-10abi2f/">Continue Reading at GameSpot</a>

## Kingdom Of The Planet Of The Apes Blu-Ray Release Includes Raw Cut Without Special Effects
 - [https://www.gamespot.com/articles/kingdom-of-the-planet-of-the-apes-blu-ray-preorder/1100-6524647/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/kingdom-of-the-planet-of-the-apes-blu-ray-preorder/1100-6524647/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T17:25:00+00:00

<p>Kingdom of the Planet of the Apes is swinging onto Blu-ray on <strong>August 27</strong>, and in case you missed its theatrical run, this home release will show you just how apes have adjusted after becoming the dominant species of the planet. Multiple editions of the film are up for preorder now, including a <a href="https://clicks.trx-hub.com/xid/fandom_32094_gamespot?q=https://goto.walmart.com/c/1804712/565706/9383?veh=aff&amp;sourceid=imp_000011112222333344&amp;u=https://www.walmart.com/ip/Kingdom-Of-The-Planet-Of-The-Apes-Steelbook-4K-Ultra-HD-Blu-ray-Digital-Copy/7096918758&amp;subId1=subid_value&amp;p=http://www.gamespot.com/feeds/news/&amp;event_type=click">fancy 4K Blu-ray paired with a steelbook case for $35 at Walmart</a>. Amazon currently has the steelbook edition for $66, but this will change soon--Walmart previously had it listed for $66, too. If your grandparents are interested in watching, a <a href="https://www.amazon.com/Kingdom-Planet-Apes-Owen-Teague/dp/B0D8JCM9

## Disney Lorcana TCG Booster Box Gets Massive Discount At Amazon
 - [https://www.gamespot.com/articles/disney-lorcana-tcg-booster-box-gets-massive-discount-at-amazon/1100-6524646/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/disney-lorcana-tcg-booster-box-gets-massive-discount-at-amazon/1100-6524646/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T16:51:00+00:00

<p>Disney Lorcana TCG is gearing up for the <a href="https://www.gamespot.com/articles/disney-lorcana-shimmering-skies-expansion-available-for-preorder-at-best-buy/1100-6524230/">Shimmering Skies</a> expansion in August, but ahead of its arrival, you'll find a handful of impressive discounts on other booster sets and booster boxes. One of the best deals slashes prices by nearly $50, giving you a more affordable way to add hundreds of trading cards to your collection.</p><div><div class="norewrite" title="">           <a href="https://www.amazon.com/Ravensburger-Disney-Lorcana-TCG-Enthusiasts/dp/B0CFRDMPWZ?tag=gamespot-promos-20">Get Disney Lorcana Booster Box</a> </div></div><p> </p><p>The best deal available right now is for the <strong><a href="https://www.amazon.com/Ravensburger-Disney-Lorcana-TCG-Enthusiasts/dp/B0CFRDMPWZ?tag=gamespot-promos-20">Into the Inklands 24-Pack Booster Set</a>, which is $98 (down from $144) at Amazon</strong>. This is the lowest price ever for the set--a

## CoD: Warzone And MW3 Patch Notes Detail Playlist Fixes And Nerfs For Popular Weapons
 - [https://www.gamespot.com/articles/cod-warzone-and-mw3-patch-notes-detail-playlist-fixes-and-nerfs-for-popular-weapons/1100-6524653/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/cod-warzone-and-mw3-patch-notes-detail-playlist-fixes-and-nerfs-for-popular-weapons/1100-6524653/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T16:42:00+00:00

<p dir="ltr">A new update has arrived to <a href="https://www.gamespot.com/games/call-of-duty-modern-warfare-iii/">Call of Duty: Modern Warfare 3</a> and <a href="https://www.gamespot.com/games/call-of-duty-warzone/">Warzone</a> on July 2. This is a small update for both games, but the patch notes include some fixes for multiplayer modes, adjustments to conversion kits, and weapon balancing for Warzone.</p><p dir="ltr">There are some changes made to improve Season 4 Reloaded's new Bit Party and Mutations playlists for multiplayer. The update includes a fix to provide more consistent scoring upon tag collection in the Kill Confirmed mode for Bit Party. For the Mutations playlist, the changes include a fix for an issue that previously caused the HUD to not match the selected Mutant's abilities, mutant perks are no longer inactive during the first life after the halftime team switch, and the Radioactive Beast will now drown if submerged in water for too long.</p><p dir="ltr">Some adjustm

## New GTA Online Update Features Tiny, Shiny Nod To GTA 6 Trailer
 - [https://www.gamespot.com/articles/new-gta-online-update-features-tiny-shiny-nod-to-gta-6-trailer/1100-6524654/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/new-gta-online-update-features-tiny-shiny-nod-to-gta-6-trailer/1100-6524654/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T16:24:00+00:00

<p><a href="https://www.gamespot.com/games/grand-theft-auto-online/">Grand Theft Auto Online</a>'s new <a href="https://www.gamespot.com/articles/gta-online-bounty-hunting-update-gets-release-date-trailer-and-more/1100-6524390/">Bottom Dollar Bounties update</a> includes loads of new content to sate one's inner bounty hunter, but it also appears to feature something a bit more unexpected: a reference to the long-awaited <a href="https://www.gamespot.com/games/grand-theft-auto-vi/">Grand Theft Auto 6</a>.</p><p dir="ltr">It seems that a necklace featured in <a href="https://www.gamespot.com/gallery/grand-theft-auto-6-trailer-breakdown-easter-eggs-references-and-teases/2900-4973/">the GTA 6 trailer</a> is now available for purchase in GTA Online, and was added as a part of the Bottom Dollar Bounties update. First <a href="https://www.reddit.com/r/GTA6/comments/1dsoqum/noticed_a_small_detail/">spotted by a user on the GTA 6 subreddit</a>, the necklace (which can be seen around the neck o

## Amazon's Blade Runner Sequel Series Begins Filming
 - [https://www.gamespot.com/articles/amazons-blade-runner-sequel-series-begins-filming/1100-6524650/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/amazons-blade-runner-sequel-series-begins-filming/1100-6524650/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T16:05:00+00:00

<p>Earlier this year, <a href="https://www.gamespot.com/articles/michelle-yeoh-will-star-in-prime-videos-blade-runner-sequel-tv-show/1100-6523239/">Michelle Yeoh landed a leading role</a> on <a href="https://www.gamespot.com/articles/blade-runner-2099-sequel-series-firms-up-for-prime-video/1100-6500609/">Blade Runner 2099</a>, Amazon Prime Video's sequel series to the two Blade Runner feature films that came before it. Now, cameras are rolling in Prague as Blade Runner 2099 has officially begun production.</p><p>Via <a href="https://www.praguereporter.com/home/2024/7/1/blade-runner-2099-with-hunter-schafer-and-michelle-yeoh-kicks-off-lengthy-prague-shoot/">The Prague Reporter</a>, Blade Runner 2099 started filming on June 30, and it will be booked in Barrandov Studio for the next six months. Yeoh is playing a replicant named Olwen who is nearing the end of her artificial life. <a href="https://www.gamespot.com/articles/hunter-schafer-joins-michelle-yeoh-in-prime-videos-blade-runner-20

## The Justice League Snyder Cut May Come To Theaters
 - [https://www.gamespot.com/articles/the-justice-league-snyder-cut-may-come-to-theaters/1100-6524649/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/the-justice-league-snyder-cut-may-come-to-theaters/1100-6524649/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T15:34:00+00:00

<p>Zack Snyder himself has teased that the so-called Snyder Cut of Justice League may get a theatrical release. <a href="https://vero.co/zacksnyder/GMV-VtsdLzPMrfH1gcz8n9dt">Posting on Vero</a>, Snyder said fans should keep their eyes peeled for an announcement.</p><p>"Want to see ZSJL on the big screen….stay tuned for a date," he said.</p><p>2017's Justice League earned more than $660 million at the global box office, but it was not received very positively by critics. In 2021, the Snyder Cut was released on HBO Max (now known as Max), delivering a version of the film that Snyder said was <a href="https://www.gamespot.com/articles/the-justice-league-zack-snyder-cut-will-release-on/1100-6477520/">more in line with his vision</a>. The critic and fan review scores for the Snyder Cut were comparatively stronger.</p><a href="https://www.gamespot.com/articles/the-justice-league-snyder-cut-may-come-to-theaters/1100-6524649/?ftag=CAD-01-10abi2f/">Continue Reading at GameSpot</a>

## New Looter-Shooter The First Descendant Is Off To A Big Start
 - [https://www.gamespot.com/articles/new-looter-shooter-the-first-descendant-is-off-to-a-big-start/1100-6524651/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/new-looter-shooter-the-first-descendant-is-off-to-a-big-start/1100-6524651/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T15:33:00+00:00

<p>Nexon Games' new free-to-play looter shooter, <a href="https://www.gamespot.com/games/the-first-descendant/">The First Descendant</a>, is having quite the successful launch. Under 24 hours after releasing to the public, it's already sitting at #6 on <a href="https://store.steampowered.com/charts/mostplayed">Steam's 100 most-played games</a> list, with over 225,000 players currently online at the time of writing.</p><p dir="ltr">The third-person co-op game sees players take on the role of Descendants, which are special fighters who inherit unique powers that aid them in their battles against The Vulgus. The Vulgus are a race of hostile alien enemies working to destroy Ingris, the fictional world in which the game is set.</p><p dir="ltr">"Descendants, from everyone on our development team we thank you sincerely for choosing to join us in the fight against The Vulgus," creative director Minseok Joo said in a recent press release. "Back when we first developed this concept in 2019, we 

## Atari 50 Expanded Edition Preorders - Get Over 140 Games, Steelbook Case, Collectibles, And More
 - [https://www.gamespot.com/articles/atari-50-expanded-edition-preorders-get-over-140-games-steelbook-case-collectibles-and-more/1100-6524487/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/atari-50-expanded-edition-preorders-get-over-140-games-steelbook-case-collectibles-and-more/1100-6524487/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T15:18:00+00:00

<p>The <a href="https://www.gamespot.com/articles/atari-50-the-anniversary-celebration-is-a-virtual-museum-for-50-years-of-gaming-history/1100-6509093/">Atari 50: Anniversary Celebration</a> released in 2022, offering an easy way to access over 100 games from the iconic developer. Atari is now preparing to launch <a href="https://clicks.trx-hub.com/xid/fandom_32094_gamespot?q=https://shop-links.co/1846764167731913507?u1=subid_value&amp;p=http://www.gamespot.com/feeds/news/&amp;event_type=click">Atari 50: The Anniversary Celebration Expanded Edition</a>, which includes a bunch more games, new in-game content. and a nice assortment of physical collectibles. It releases on <strong>October 25</strong>, and preorders are live now for two different editions, including a <a href="https://clicks.trx-hub.com/xid/fandom_32094_gamespot?q=https://shop-links.co/1846764014871262103?u1=subid_value&amp;p=http://www.gamespot.com/feeds/news/&amp;event_type=click">limited-edition steelbook</a> release t

## Cate Blanchett Explains Why She Is In The Borderlands Movie, And It Has To Do With COVID
 - [https://www.gamespot.com/articles/cate-blanchett-explains-why-she-is-in-the-borderlands-movie-and-it-has-to-do-with-covid/1100-6524648/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/cate-blanchett-explains-why-she-is-in-the-borderlands-movie-and-it-has-to-do-with-covid/1100-6524648/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T15:10:00+00:00

<p>Cate Blanchett's next big movie role is playing the space-outlaw Lilith in the Borderlands movie, which is based on the Gearbox video game. When Blanchett was announced for the film, many people had a lot to say about the two-time Oscar-winner joining the cast, and now the actress herself has revealed why she was drawn to the project. Speaking to <a href="https://www.empireonline.com/movies/news/borderlands-movie-cate-blanchett-gunslinger-eli-roth/">Empire</a>, Blanchett said she enjoys taking on roles that no one expects. Beyond that, she was eager to get out of the house due to COVID.</p><p>"The crazy asks are usually the things I gravitate towards; the things I could never conceive of," she said. "I think there also may have been a little Covid madness--I was spending a lot of time in the garden, using the chainsaw a little too freely. My husband said, 'This film could save your life.'"</p><div>          </div><p>Blanchett also revealed that she bought a PS5 to play the Borderla

## Redbox Owner Files For Bankruptcy
 - [https://www.gamespot.com/articles/redbox-owner-files-for-bankruptcy/1100-6524644/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/redbox-owner-files-for-bankruptcy/1100-6524644/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T14:34:00+00:00

<p>Nearly two decades ago, Redbox's ubiquitous movie rental kiosks helped put video rental stores out of business. Now, Redbox's parent company, Chicken Soup for the Soul Entertainment, is facing bankruptcy and serious questions about its future.</p><p>Via <a href="https://deadline.com/2024/06/redbox-chicken-soup-for-the-soul-entertainment-files-chapter-11-bankruptcy-1235997730/">Deadline</a>, Chicken Soup for the Soul Entertainment filed Chapter 11 bankruptcy last week after the company was reportedly late paying its employees while also slashing medical benefits. According to a message sent to employees, Chicken Soup applied for a debtor in possession loan that will allow it to make payroll and reinstate the lost medical benefits.</p><p>The bankruptcy filing has been made public, and it reveals that Chicken Soup owes $970 million to its unsecured creditors including Sony Pictures, Warner Bros. Pictures, Paramount, Universal Studios, Lionsgate, and Walmart. That's not counting the co

## Netflix Is Dumping Its Cheapest Ad-Free Plan For Existing Subscribers
 - [https://www.gamespot.com/articles/netflix-is-dumping-its-cheapest-ad-free-plan-for-existing-subscribers/1100-6524645/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/netflix-is-dumping-its-cheapest-ad-free-plan-for-existing-subscribers/1100-6524645/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T14:31:00+00:00

<p><a href="https://www.gamespot.com/gallery/biggest-movies-and-tv-shows-on-netflix-in-july-2024-that-you-need-to-watch/2900-5523/">Netflix</a> is implementing further changes to its subscription options, and this includes the phasing out of the least-expensive ad-free tier. People on social media are reporting that, at least in the UK and Canada, Netflix has begun to ask existing subscribers to the change plans to keep their subscription. Netflix originally dumped the plan for new and returning members in 2023, and now existing subscribers are affected as well.</p><p>On Reddit, someone reported receiving a message stating that the last day to watch Netflix on their existing plan is July 13. "Choose a new plan to keep watching," the message said (<a href="https://www.theverge.com/2024/7/2/24190632/netflix-ad-free-basic-plan-discontinued">via The Verge</a>).</p><p>Members on the existing $10/month basic plan are being directed to choose from the $7/month ad-based tier, the $15.50 ad-fr

## Xbox Game Pass July 2024 Removals Include A Charming Photo Adventure
 - [https://www.gamespot.com/gallery/xbox-game-pass-july-2024-removals-include-a-charming-photo-adventure/2900-5562](https://www.gamespot.com/gallery/xbox-game-pass-july-2024-removals-include-a-charming-photo-adventure/2900-5562)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T14:00:00+00:00

<p><h2>Buh-Bye</h2><img src="https://www.gamespot.com/a/uploads/scale_large/1813/18138562/4327991-3843134-x019_xboxgamepass_gamesmontage_thumbnail.0.jpg" /><br /><h3><p>Like clockwork, <a href="https://news.xbox.com/en-us/2024/07/02/xbox-game-pass-july-2024-wave-1/?ocid=XGP_soc_omc_xbo_tw_Photo_lrn_7.2.1">Microsoft has announced</a> what titles will soon be leaving Xbox Game Pass. On July 15, five games will exit the subscription service, headlined by Toem and Sins of a Solar Empire: Rebellion.</p><p dir="ltr">While they're vastly different experiences, both games garnered positive reviews from GameSpot. The <a href="https://www.gamespot.com/reviews/toem-review-look-at-this-photograph/1900-6417733/">Toem review</a> noted that it's a "charming little photo adventure," while the <a href="https://www.gamespot.com/reviews/sins-of-a-solar-empire-rebellion-review/1900-6384904/">Sins of a Solar Empire: Rebellion review</a> describes it as "an excellent game."</p><p dir="ltr">The other three 

## Ridley Scott Still Regrets Not Directing The Alien Sequels
 - [https://www.gamespot.com/articles/ridley-scott-still-regrets-not-directing-the-alien-sequels/1100-6524643/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/ridley-scott-still-regrets-not-directing-the-alien-sequels/1100-6524643/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T13:43:00+00:00

<p>When Ridley Scott's Alien hit theaters in 1979, it was only his second theatrical film and he had no idea it would become franchise. But as Alien celebrates its 45th anniversary this year, Scott regrets that he wasn't asked to direct Aliens or Alien 3, which were respectively helmed by James Cameron and David Fincher.</p><p>"I was slow out the starting gate," Scott told <a href="https://www.vanityfair.com/hollywood/story/paul-mescal-pedro-pascal-gladiator-ii-first-look">Vanity Fair</a>. "I mean, I should have done the sequels to Alien and to Blade Runner. You change over the years. At that time, I didn't want to go through it again. So Jim Cameron came in--and then David Fincher--on [Alien 3]."</p><p>Scott eventually returned to the Alien franchise for the prequel film Prometheus in 2012, before helming its direct sequel, Alien: Covenant, in 2017. Regardless, Scott still seems a bit upset that 20th Century Fox didn't bring him back sooner.</p><a href="https://www.gamespot.com/artic

## WWE Money In The Bank 2024: How To Watch, Start Times, Match Card, Everything To Know
 - [https://www.gamespot.com/gallery/wwe-money-in-the-bank-2024-how-to-watch-start-time-match-card/2900-5557](https://www.gamespot.com/gallery/wwe-money-in-the-bank-2024-how-to-watch-start-time-match-card/2900-5557)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T13:39:00+00:00

<p><img src="https://www.gamespot.com/a/uploads/scale_large/1562/15626911/4327614-dek.png" /><br /><h3><p dir="ltr">On July 6, the next WWE PLE arrives on Peacock: Money in the Bank. This year's event will take place at the Scotiabank Arena in Toronto, Ontario, Canada. The last time WWE held a PLE in Canada was 2023's Elimination Chamber in Quebec, and for Toronto, the last PLE was 2019's Summerslam. Needless to say, WWE fans in Toronto will be pumped for this event.</p><p dir="ltr">The majority of the matches will continue or wrap up storylines featured on Raw and Smackdown. However, the highlight of the evening will be the men's and women's Money in the Bank ladder matches. In each match, six wrestlers will have the opportunity to climb a ladder to grab a briefcase, which contains a World Championship match contract.</p><p dir="ltr">Aside from those two MITB matches, there is even more to be excited about. The new incarnation of The Bloodline, which we're calling The Bloodline V.2, 

## The Best PC Games To Play In 2024
 - [https://www.gamespot.com/gallery/best-pc-games/2900-4143](https://www.gamespot.com/gallery/best-pc-games/2900-4143)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T13:38:00+00:00

<p><img src="https://www.gamespot.com/a/uploads/scale_large/1585/15855271/4327967-best-pc-games-2.jpg" /><br /><h3><p dir="ltr">Without a generational divide, the PC gaming library just keeps growing. With such an ever-expanding list to choose from, we focused on the best PC games to play right now. Some of these games, like Balatro and Helldivers 2, are recently released gems. Others are live-service games or multiplayer favorites that have stood the test of time, like Destiny 2. Our list of the best PC games spans across a wide variety of genres, so at least a few of these games will pique your interest.</p><p dir="ltr">PC gaming is quite different from consoles, as your mileage with each game on this list will vary based on your rig. That said, many of the games on this list don't require the latest and greatest graphic cards--they merely help these great games look even better. And if you happen to have a Steam Deck, a lot of these games are playable on Valve's impressive handheld

## Call Of Duty's New Deep-Fried Weapon Is Clucking Weird
 - [https://www.gamespot.com/articles/call-of-dutys-new-deep-fried-weapon-is-clucking-weird/1100-6524642/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/call-of-dutys-new-deep-fried-weapon-is-clucking-weird/1100-6524642/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T13:22:00+00:00

<p>There's no shortage of exotic weapons in modern Call of Duty games, but a new "Extra Crispy" gun uncovered by dataminer <a href="https://x.com/realityuk_">RealityUK</a> is easily the most absurd one yet for the franchise. <a href="https://clicks.trx-hub.com/xid/fandom_32094_gamespot?q=https://x.com/realityuk_/status/1807501354086060472?&amp;p=http://www.gamespot.com/feeds/news&amp;event_type=click">The wonderfully silly trailer for the weapon</a> shows off an operator dressed to kill in a chicken costume, unleashing extra-crispy rounds on opponents and transforming them into pieces of fried chicken.</p><p>Things get even sillier <a href="https://clicks.trx-hub.com/xid/fandom_32094_gamespot?q=https://x.com/ModernWarzone/status/1807166495618720183&amp;p=http://www.gamespot.com/feeds/news&amp;event_type=click">when the weapon is inspected</a>, as it involves shoving a raw chicken on the barrel and cooking it up for a quick meal. For now, the gun is exclusive to <a href="https://www.ga

## Game Pass Adds These 8 Games In July
 - [https://www.gamespot.com/gallery/game-pass-adds-these-8-games-in-july/2900-5561](https://www.gamespot.com/gallery/game-pass-adds-these-8-games-in-july/2900-5561)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T13:10:00+00:00

<p><h2>Stocked up</h2><img src="https://www.gamespot.com/a/uploads/scale_large/1179/11799911/4327964-xboxsphere.jpeg" /><br /><h3><p>With every flip of the month, Microsoft adds more titles to the Xbox <a href="https://www.gamespot.com/gallery/best-xbox-game-pass-games/2900-4001/">Game Pass</a> catalog, and that's no different for July.</p><p>Microsoft has announced the first set of additions to Game Pass in July, and there are eight games coming to the catalog soon. Some of the new additions for July include Journey to the Savage Planet, Nickelodeon All-Star Brawl 2, Cricket 24, and Neon White.</p><p>Microsoft typically releases titles in two waves, so fans can likely expect a second batch of additions for the second half of the month as well.</p><p>And as usual, Microsoft giveth and Microsoft taketh away, and there are five titles leaving the Game Pass library on July 15. These include Coffee Talk Episode 2, Figment 2: Creed Valley, Sins of a Solar Empire: Rebellion, Toem, and The W

## Elden Ring Graceborne Mod Brings Bloodborne To The Lands Between
 - [https://www.gamespot.com/articles/elden-ring-graceborne-mod-brings-bloodborne-to-the-lands-between/1100-6524641/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/elden-ring-graceborne-mod-brings-bloodborne-to-the-lands-between/1100-6524641/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T13:01:00+00:00

<p><a href="https://www.gamespot.com/reviews/elden-ring-review-death-of-the-wild/1900-6417832/">Elden Ring</a>'s Lands Between isn't exactly a lighthearted fantasy realm, but the fan-created Graceborne mod makes things even darker by giving the game a <a href="https://www.gamespot.com/reviews/bloodborne-review/1900-6416078/">Bloodborne</a>-themed makeover. And since <a href="https://www.gamespot.com/articles/from-software-wants-bloodborne-on-pc-too/1100-6524292/">Bloodborne still isn't on PC</a> nearly a decade after its release, Graceborne may be the closest thing to it that we're going to get.</p><p>Via <a href="https://www.gamesradar.com/games/action-rpg/elden-ring-now-has-a-bloodborne-style-overhaul-mod-so-we-can-pretend-that-we-finally-have-the-pc-port-weve-been-begging-for/">GamesRadar</a>, the Elden Ring Graceborne mod was created by a user going by corvianNoctis on <a href="https://clicks.trx-hub.com/xid/fandom_32094_gamespot?q=https://www.nexusmods.com/eldenring/mods/5207&amp

## Star Wars TV Show Boss Has Advice For Tough Elden Ring Bosses: "You Have To Be Aggressive"
 - [https://www.gamespot.com/articles/star-wars-tv-show-boss-has-advice-for-tough-elden-ring-bosses-you-have-to-be-aggressive/1100-6524640/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/star-wars-tv-show-boss-has-advice-for-tough-elden-ring-bosses-you-have-to-be-aggressive/1100-6524640/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-07-02T12:27:00+00:00

<p>If you're struggling to defeat the tough bosses in Elden Ring, the creator and showrunner of the Star Wars TV series The Acolyte has some advice: be aggressive.</p><p>Speaking to <a href="https://www.inverse.com/entertainment/leslye-headland-acolyte-episode-5-interview-star-wars-qimir-cortosis">Inverse</a>, Leslye Headland brought up Elden Ring in a conversation about Manny Jacinto's character on The Acolyte. <strong>This story contains spoilers about The Acolyte. </strong></p><p>Headland said Jacinto's character, Qimir AKA The Stranger, is so skilled at fighting that he doesn't wear armor. People pushed back on Headland's decision to do this, but she stood her ground and said, "Why would you wear armor if you're not going to get hit?" She said it's similar to how immensely skilled some people are at Elden Ring.</p><a href="https://www.gamespot.com/articles/star-wars-tv-show-boss-has-advice-for-tough-elden-ring-bosses-you-have-to-be-aggressive/1100-6524640/?ftag=CAD-01-10abi2f/">Co

