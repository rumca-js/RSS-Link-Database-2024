# Source:RP - Cyfrowa, URL:https://cyfrowa.rp.pl/rss/2991-cyfrowa, language:pl-PL

## AI staje się nieodzowna w cyberbezpieczeństwie
 - [https://cyfrowa.rp.pl/cyfryzacja/art40546941-ai-staje-sie-nieodzowna-w-cyberbezpieczenstwie](https://cyfrowa.rp.pl/cyfryzacja/art40546941-ai-staje-sie-nieodzowna-w-cyberbezpieczenstwie)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-06-04T08:00:00+00:00

Wraz z rozwojem technologii i boomem na sztuczną inteligencję jest ona używana także przy atakach hakerskich. Dobra wiadomość jest taka, że jej możliwości można wykorzystać również w cyberobronie.

