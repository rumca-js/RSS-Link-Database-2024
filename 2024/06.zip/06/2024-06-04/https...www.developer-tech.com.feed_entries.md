# Source:Developer Tech News, URL:https://www.developer-tech.com/feed, language:en-GB

## Apple updates Developer app ahead of WWDC 2024
 - [https://www.developer-tech.com/news/2024/jun/04/apple-updates-developer-app-ahead-wwdc-2024](https://www.developer-tech.com/news/2024/jun/04/apple-updates-developer-app-ahead-wwdc-2024)
 - RSS feed: https://www.developer-tech.com/feed
 - date published: 2024-06-04T12:21:14+00:00

<p>Apple has released an update to its Apple Developer app in preparation for WWDC 2024, scheduled to commence next Monday. The revamped Developer app will serve as the hub for 2024 session videos, 1-on-1 labs with Apple engineers and designers, and additional resources. Apple will stream the WWDC keynote event, the Platforms State of the<a class="excerpt-read-more" href="https://www.developer-tech.com/news/2024/jun/04/apple-updates-developer-app-ahead-wwdc-2024/" title="ReadApple updates Developer app ahead of WWDC 2024">... Read more &#187;</a></p>
<p>The post <a href="https://www.developer-tech.com/news/2024/jun/04/apple-updates-developer-app-ahead-wwdc-2024/">Apple updates Developer app ahead of WWDC 2024</a> appeared first on <a href="https://www.developer-tech.com">Developer Tech News</a>.</p>

