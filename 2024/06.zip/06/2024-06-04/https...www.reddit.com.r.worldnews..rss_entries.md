# Source:Reddit - World News, URL:https://www.reddit.com/r/worldnews/.rss, language:en

## Moscow ready to strike French military trainers in Ukraine
 - [https://www.reddit.com/r/worldnews/comments/1d88kmv/moscow_ready_to_strike_french_military_trainers](https://www.reddit.com/r/worldnews/comments/1d88kmv/moscow_ready_to_strike_french_military_trainers)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T21:22:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d88kmv/moscow_ready_to_strike_french_military_trainers/"> <img alt="Moscow ready to strike French military trainers in Ukraine" src="https://external-preview.redd.it/npIESSCdPoUw8R4Yo0udC1bfqpUWL9Z72PcTPWqT_aA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=baf139161bc95185c68fe0c13e17da10345e34f1" title="Moscow ready to strike French military trainers in Ukraine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/457655676"> /u/457655676 </a> <br /> <span><a href="https://www.politico.eu/article/moscow-ready-to-strike-french-military-trainers-in-ukraine/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d88kmv/moscow_ready_to_strike_french_military_trainers/">[comments]</a></span> </td></tr></table>

## Hamas cannot agree to any deal unless Israel makes a "clear" commitment to a permanent ceasefire and a complete withdrawal from the Gaza Strip, a senior official from the Palestinian militant group said on Tuesday
 - [https://www.reddit.com/r/worldnews/comments/1d87jb6/hamas_cannot_agree_to_any_deal_unless_israel](https://www.reddit.com/r/worldnews/comments/1d87jb6/hamas_cannot_agree_to_any_deal_unless_israel)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T20:39:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d87jb6/hamas_cannot_agree_to_any_deal_unless_israel/"> <img alt="Hamas cannot agree to any deal unless Israel makes a &quot;clear&quot; commitment to a permanent ceasefire and a complete withdrawal from the Gaza Strip, a senior official from the Palestinian militant group said on Tuesday" src="https://external-preview.redd.it/jR0vXns6soDi-3523cF4EKUgxbjyUC-nI8Wn0WWKUv8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ed2aba0c5051ee2f0867f5879495edd8f904945c" title="Hamas cannot agree to any deal unless Israel makes a &quot;clear&quot; commitment to a permanent ceasefire and a complete withdrawal from the Gaza Strip, a senior official from the Palestinian militant group said on Tuesday" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/green_flash"> /u/green_flash </a> <br /> <span><a href="https://www.reuters.com/world/middle-east/hamas-wants-israel-commit-permanent-ceasefire-full-with

## Israeli amputee soccer team jeered, cursed during match with Turkey
 - [https://www.reddit.com/r/worldnews/comments/1d87hao/israeli_amputee_soccer_team_jeered_cursed_during](https://www.reddit.com/r/worldnews/comments/1d87hao/israeli_amputee_soccer_team_jeered_cursed_during)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T20:37:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d87hao/israeli_amputee_soccer_team_jeered_cursed_during/"> <img alt="Israeli amputee soccer team jeered, cursed during match with Turkey" src="https://external-preview.redd.it/KRV5EWwZ1UImHw5Vl48seuqkofA6-kJmqU-begsMewg.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=9055df9dbd568bba3b2a9e6c55c825c6e7ab6536" title="Israeli amputee soccer team jeered, cursed during match with Turkey" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FYoCouchEddie"> /u/FYoCouchEddie </a> <br /> <span><a href="https://www.ynetnews.com/culture/article/hyudhvjvr">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d87hao/israeli_amputee_soccer_team_jeered_cursed_during/">[comments]</a></span> </td></tr></table>

## IDF chief: Israel nearing decision on whether to launch war against Hezbollah
 - [https://www.reddit.com/r/worldnews/comments/1d86ww6/idf_chief_israel_nearing_decision_on_whether_to](https://www.reddit.com/r/worldnews/comments/1d86ww6/idf_chief_israel_nearing_decision_on_whether_to)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T20:14:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d86ww6/idf_chief_israel_nearing_decision_on_whether_to/"> <img alt="IDF chief: Israel nearing decision on whether to launch war against Hezbollah" src="https://external-preview.redd.it/dYWZ3sryenkyC3ywsK9yakkzsyGSVaTsIg5XBaBz700.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=776bb8a7bdc2da2f2fd1213a62c785bc02422703" title="IDF chief: Israel nearing decision on whether to launch war against Hezbollah" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ahad_Haam"> /u/Ahad_Haam </a> <br /> <span><a href="https://www.timesofisrael.com/war-cabinet-set-to-huddle-as-blazes-sparked-by-hezbollah-attacks-scorch-north/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d86ww6/idf_chief_israel_nearing_decision_on_whether_to/">[comments]</a></span> </td></tr></table>

## Ukraine Strikes Into Russia With Western Weapons, Official Says
 - [https://www.reddit.com/r/worldnews/comments/1d86cks/ukraine_strikes_into_russia_with_western_weapons](https://www.reddit.com/r/worldnews/comments/1d86cks/ukraine_strikes_into_russia_with_western_weapons)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T19:52:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d86cks/ukraine_strikes_into_russia_with_western_weapons/"> <img alt="Ukraine Strikes Into Russia With Western Weapons, Official Says" src="https://external-preview.redd.it/HD6Rzk-JyOz9CBUHacLZZpia8bjmP_gozc4S5xPXnHY.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=e7570071a04b4d101eae41995e4096460d256027" title="Ukraine Strikes Into Russia With Western Weapons, Official Says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HenzShuyi"> /u/HenzShuyi </a> <br /> <span><a href="https://www.nytimes.com/2024/06/04/world/europe/ukraine-strikes-russia-western-weapons.html?smid=url-share">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d86cks/ukraine_strikes_into_russia_with_western_weapons/">[comments]</a></span> </td></tr></table>

## Philippines says China coast guard seized food dropped by plane for Filipino forces
 - [https://www.reddit.com/r/worldnews/comments/1d83x2z/philippines_says_china_coast_guard_seized_food](https://www.reddit.com/r/worldnews/comments/1d83x2z/philippines_says_china_coast_guard_seized_food)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T18:12:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d83x2z/philippines_says_china_coast_guard_seized_food/"> <img alt="Philippines says China coast guard seized food dropped by plane for Filipino forces" src="https://external-preview.redd.it/Ur4psNoc1GFKofARLfy0lk80OvcfoHUT1YDLv7YCSl4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b186b027ae3eb06c0be65bd737cbd232b4313105" title="Philippines says China coast guard seized food dropped by plane for Filipino forces" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/lurker_bee"> /u/lurker_bee </a> <br /> <span><a href="https://abcnews.go.com/International/wireStory/philippines-china-coast-guard-seized-food-dropped-plane-110816147">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d83x2z/philippines_says_china_coast_guard_seized_food/">[comments]</a></span> </td></tr></table>

## Canadian government won't commit to releasing names of MPs who allegedly conspired with foreign actors - Deputy Prime Minister Chrystia Freeland says Liberals will conduct an 'internal followup' on meddling claims
 - [https://www.reddit.com/r/worldnews/comments/1d83nn7/canadian_government_wont_commit_to_releasing](https://www.reddit.com/r/worldnews/comments/1d83nn7/canadian_government_wont_commit_to_releasing)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T18:01:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d83nn7/canadian_government_wont_commit_to_releasing/"> <img alt="Canadian government won't commit to releasing names of MPs who allegedly conspired with foreign actors - Deputy Prime Minister Chrystia Freeland says Liberals will conduct an 'internal followup' on meddling claims" src="https://external-preview.redd.it/1GPaHrG0q9Lgy_fv5Jfs4Kp6YEp8-qD6PsBm52r5M8c.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=a4d93e5073357276c0db928b504f447f03d463b6" title="Canadian government won't commit to releasing names of MPs who allegedly conspired with foreign actors - Deputy Prime Minister Chrystia Freeland says Liberals will conduct an 'internal followup' on meddling claims" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CaliperLee62"> /u/CaliperLee62 </a> <br /> <span><a href="https://www.cbc.ca/news/politics/mps-foreign-interference-nsicop-1.7224132">[link]</a></span> &#32; <span><a href="

## Mexico election: Mayor killed after first woman elected leader
 - [https://www.reddit.com/r/worldnews/comments/1d82cnp/mexico_election_mayor_killed_after_first_woman](https://www.reddit.com/r/worldnews/comments/1d82cnp/mexico_election_mayor_killed_after_first_woman)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T17:06:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d82cnp/mexico_election_mayor_killed_after_first_woman/"> <img alt="Mexico election: Mayor killed after first woman elected leader" src="https://external-preview.redd.it/kMlAShiQnA-AGLNT29NyzDdPi-KzK8lm6BkoTe9iOJs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=60db73983a7b5715b1126b3b777d2ec175b49fba" title="Mexico election: Mayor killed after first woman elected leader" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Accomplished_Wheel83"> /u/Accomplished_Wheel83 </a> <br /> <span><a href="https://www.bbc.com/news/articles/c166n3p6r49o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d82cnp/mexico_election_mayor_killed_after_first_woman/">[comments]</a></span> </td></tr></table>

## “As an ex-refugee I sympathise with migrants” but Poland must defend border from “attack”, says foreign minister
 - [https://www.reddit.com/r/worldnews/comments/1d82akj/as_an_exrefugee_i_sympathise_with_migrants_but](https://www.reddit.com/r/worldnews/comments/1d82akj/as_an_exrefugee_i_sympathise_with_migrants_but)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T17:04:36+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/BubsyFanboy"> /u/BubsyFanboy </a> <br /> <span><a href="https://notesfrompoland.com/2024/06/04/as-an-ex-refugee-i-sympathise-with-migrants-but-poland-must-defend-border-from-attack-says-foreign-minister/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d82akj/as_an_exrefugee_i_sympathise_with_migrants_but/">[comments]</a></span>

## Georgia's Ruling Party Initiates Bill Cracking Down On LGBT Rights
 - [https://www.reddit.com/r/worldnews/comments/1d8178j/georgias_ruling_party_initiates_bill_cracking](https://www.reddit.com/r/worldnews/comments/1d8178j/georgias_ruling_party_initiates_bill_cracking)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T16:18:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d8178j/georgias_ruling_party_initiates_bill_cracking/"> <img alt="Georgia's Ruling Party Initiates Bill Cracking Down On LGBT Rights" src="https://external-preview.redd.it/yVdSmab0GxBK9nOxvorUS0Yv9pmpUnWWRVyXYWSXLuY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b2f1e13a3ce1c6e49bf8de5914d9f6466595ec8a" title="Georgia's Ruling Party Initiates Bill Cracking Down On LGBT Rights" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Red_Franklin"> /u/Red_Franklin </a> <br /> <span><a href="https://www.rferl.org/a/georgia-ruling-party-bill-lgbt-rights-crackdown/32978909.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d8178j/georgias_ruling_party_initiates_bill_cracking/">[comments]</a></span> </td></tr></table>

## [NY Times] 46 Children Were Taken From Ukraine. Many Are Up for Adoption in Russia. (Gift Article)
 - [https://www.reddit.com/r/worldnews/comments/1d80gnx/ny_times_46_children_were_taken_from_ukraine_many](https://www.reddit.com/r/worldnews/comments/1d80gnx/ny_times_46_children_were_taken_from_ukraine_many)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T15:48:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d80gnx/ny_times_46_children_were_taken_from_ukraine_many/"> <img alt="[NY Times] 46 Children Were Taken From Ukraine. Many Are Up for Adoption in Russia. (Gift Article)" src="https://external-preview.redd.it/CMQG4jabORT4qQCNiUxK2uKb0gNhvInL_kVx1ZGcg9A.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d35f0e195ad8c8b02a6b456a5234e996e711019b" title="[NY Times] 46 Children Were Taken From Ukraine. Many Are Up for Adoption in Russia. (Gift Article)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mongster03_"> /u/mongster03_ </a> <br /> <span><a href="https://www.nytimes.com/2024/06/02/world/europe/ukraine-children-russia-war.html?unlocked_article_code=1.xE0.ZiYx.5JZ7pWQ2nNiC&amp;smid=nytcore-ios-share&amp;referringSource=articleShare&amp;u2g=i&amp;sgrp=c-cb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d80gnx/ny_times_46_children_were_taken_from_uk

## Duolingo removes all LGBT content from its app in Russia
 - [https://www.reddit.com/r/worldnews/comments/1d7zyyb/duolingo_removes_all_lgbt_content_from_its_app_in](https://www.reddit.com/r/worldnews/comments/1d7zyyb/duolingo_removes_all_lgbt_content_from_its_app_in)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T15:27:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7zyyb/duolingo_removes_all_lgbt_content_from_its_app_in/"> <img alt="Duolingo removes all LGBT content from its app in Russia" src="https://external-preview.redd.it/vrwL0u2CVLJqBlZ7cLWo7iRjSqGbSA3n80v-DAvUkvY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8c93d0af059ff9cc4ac3b3e49c417db282e634fa" title="Duolingo removes all LGBT content from its app in Russia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/duckanroll"> /u/duckanroll </a> <br /> <span><a href="https://novayagazeta.eu/articles/2024/06/04/duolingo-removes-all-lgbt-content-from-its-app-in-russia-en-news">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7zyyb/duolingo_removes_all_lgbt_content_from_its_app_in/">[comments]</a></span> </td></tr></table>

## Saudi Arabia largely removes negative portrayal of Israel from its school curriculum
 - [https://www.reddit.com/r/worldnews/comments/1d7zaa4/saudi_arabia_largely_removes_negative_portrayal](https://www.reddit.com/r/worldnews/comments/1d7zaa4/saudi_arabia_largely_removes_negative_portrayal)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T15:00:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7zaa4/saudi_arabia_largely_removes_negative_portrayal/"> <img alt="Saudi Arabia largely removes negative portrayal of Israel from its school curriculum" src="https://external-preview.redd.it/69GJnpCrze89MBULNwm4lqp9pmCafsNuMszTgnjFfF0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c684eab8bffa4763ed902c67362ce79c1c3af0b1" title="Saudi Arabia largely removes negative portrayal of Israel from its school curriculum" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Silly-avocatoe"> /u/Silly-avocatoe </a> <br /> <span><a href="https://www.timesofisrael.com/saudi-arabia-largely-removes-negative-portrayal-of-israel-from-its-school-curriculum/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7zaa4/saudi_arabia_largely_removes_negative_portrayal/">[comments]</a></span> </td></tr></table>

## Russia co-opts far-right politicians in Europe with cash, officials say
 - [https://www.reddit.com/r/worldnews/comments/1d7z4t0/russia_coopts_farright_politicians_in_europe_with](https://www.reddit.com/r/worldnews/comments/1d7z4t0/russia_coopts_farright_politicians_in_europe_with)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T14:53:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7z4t0/russia_coopts_farright_politicians_in_europe_with/"> <img alt="Russia co-opts far-right politicians in Europe with cash, officials say" src="https://external-preview.redd.it/xQSPXgTSk-aSJtvL7n9bGkdCIrX44uB9MmR8D91FiSU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bbc9a9e643166daf565ff142c5da20ca3f451b6d" title="Russia co-opts far-right politicians in Europe with cash, officials say" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AgentBlue62"> /u/AgentBlue62 </a> <br /> <span><a href="https://www.washingtonpost.com/world/2024/06/03/russia-europe-far-right-espionage/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7z4t0/russia_coopts_farright_politicians_in_europe_with/">[comments]</a></span> </td></tr></table>

## Biden says 'every reason' to believe Netanyahu is prolonging war for political gain
 - [https://www.reddit.com/r/worldnews/comments/1d7z3hk/biden_says_every_reason_to_believe_netanyahu_is](https://www.reddit.com/r/worldnews/comments/1d7z3hk/biden_says_every_reason_to_believe_netanyahu_is)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T14:52:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7z3hk/biden_says_every_reason_to_believe_netanyahu_is/"> <img alt="Biden says 'every reason' to believe Netanyahu is prolonging war for political gain" src="https://external-preview.redd.it/axBX4jXbE4h3rkOm71sQNm3VZozDi1gZXSGkF_fq1gw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=11cb4034f1a78c417733f386950d35fefe53edb7" title="Biden says 'every reason' to believe Netanyahu is prolonging war for political gain" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nbcnews"> /u/nbcnews </a> <br /> <span><a href="https://www.nbcnews.com/politics/white-house/biden-netanyahu-israel-hamas-war-rcna155386">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7z3hk/biden_says_every_reason_to_believe_netanyahu_is/">[comments]</a></span> </td></tr></table>

## IRGC general killed in reported Israeli strike near Syria's Aleppo - I24NEWS
 - [https://www.reddit.com/r/worldnews/comments/1d7yu5m/irgc_general_killed_in_reported_israeli_strike](https://www.reddit.com/r/worldnews/comments/1d7yu5m/irgc_general_killed_in_reported_israeli_strike)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T14:41:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7yu5m/irgc_general_killed_in_reported_israeli_strike/"> <img alt="IRGC general killed in reported Israeli strike near Syria's Aleppo - I24NEWS" src="https://external-preview.redd.it/27UCRKbQ1Oh7-clk4DrZCQrbxKqS60zorAXsQPRPezk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=97ab0ec7ec42a34493a7e351cf6940d20c7a7138" title="IRGC general killed in reported Israeli strike near Syria's Aleppo - I24NEWS" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yuri_2022"> /u/yuri_2022 </a> <br /> <span><a href="https://www.i24news.tv/en/news/israel-at-war/artc-irgc-general-killed-in-reported-israeli-strike-near-syria-s-aleppo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7yu5m/irgc_general_killed_in_reported_israeli_strike/">[comments]</a></span> </td></tr></table>

## Modi’s BJP set to lose its majority in shock India election result
 - [https://www.reddit.com/r/worldnews/comments/1d7yk13/modis_bjp_set_to_lose_its_majority_in_shock_india](https://www.reddit.com/r/worldnews/comments/1d7yk13/modis_bjp_set_to_lose_its_majority_in_shock_india)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T14:29:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7yk13/modis_bjp_set_to_lose_its_majority_in_shock_india/"> <img alt="Modi’s BJP set to lose its majority in shock India election result" src="https://external-preview.redd.it/aa6q7tQTjGSRW4f_NI5V-1M6m1K-kdo5UjARl9w8wEc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=18c9694fe7f7b4ba390e54b2298ab63170984f6e" title="Modi’s BJP set to lose its majority in shock India election result" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/alabasterheart"> /u/alabasterheart </a> <br /> <span><a href="https://www.cnbc.com/2024/06/04/india-elections-modis-bjp-led-alliance-set-for-narrower-than-expected-win.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7yk13/modis_bjp_set_to_lose_its_majority_in_shock_india/">[comments]</a></span> </td></tr></table>

## German army to boost Rheinmetall artillery shell order by 200,000, document shows
 - [https://www.reddit.com/r/worldnews/comments/1d7wz8t/german_army_to_boost_rheinmetall_artillery_shell](https://www.reddit.com/r/worldnews/comments/1d7wz8t/german_army_to_boost_rheinmetall_artillery_shell)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T13:20:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7wz8t/german_army_to_boost_rheinmetall_artillery_shell/"> <img alt="German army to boost Rheinmetall artillery shell order by 200,000, document shows" src="https://external-preview.redd.it/sfs5PGsH19sWDN8KYVrKt15GNjb21ky03yo4sOHOgLk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4ba6a76e1e7b0e6c0578d08f5effef658b800d92" title="German army to boost Rheinmetall artillery shell order by 200,000, document shows" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/donutloop"> /u/donutloop </a> <br /> <span><a href="https://www.reuters.com/business/aerospace-defense/german-army-increase-rheinmetall-artillery-shell-order-by-200000-spiegel-reports-2024-06-04/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7wz8t/german_army_to_boost_rheinmetall_artillery_shell/">[comments]</a></span> </td></tr></table>

## India hands PM Modi a surprising setback, with his majority set to shrink in the world’s largest election and the opposition performing better than expected
 - [https://www.reddit.com/r/worldnews/comments/1d7wbgz/india_hands_pm_modi_a_surprising_setback_with_his](https://www.reddit.com/r/worldnews/comments/1d7wbgz/india_hands_pm_modi_a_surprising_setback_with_his)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T12:48:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7wbgz/india_hands_pm_modi_a_surprising_setback_with_his/"> <img alt="India hands PM Modi a surprising setback, with his majority set to shrink in the world’s largest election and the opposition performing better than expected" src="https://external-preview.redd.it/6duvB4r1IbjWUhDGm78dI_lAstersaVxcxdxhRJ-k08.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d2edd5dcf7e2377cd76a6ae70e473ebc7a32f26d" title="India hands PM Modi a surprising setback, with his majority set to shrink in the world’s largest election and the opposition performing better than expected" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/unital_subalgebra"> /u/unital_subalgebra </a> <br /> <span><a href="https://www.nbcnews.com/news/world/india-election-results-narendra-modi-rcna154839/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7wbgz/india_hands_pm_modi_a_surprising_setba

## Modi Poised to Lose India Majority, Need Allies to Keep Power
 - [https://www.reddit.com/r/worldnews/comments/1d7vz2f/modi_poised_to_lose_india_majority_need_allies_to](https://www.reddit.com/r/worldnews/comments/1d7vz2f/modi_poised_to_lose_india_majority_need_allies_to)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T12:31:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7vz2f/modi_poised_to_lose_india_majority_need_allies_to/"> <img alt="Modi Poised to Lose India Majority, Need Allies to Keep Power" src="https://external-preview.redd.it/ZCeMHKdWtCVaGJokIMDuVtl9KFEOWnK-tfxu4LVe1NY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bea58b847895a46812aa61d00fb757d927b2d8f7" title="Modi Poised to Lose India Majority, Need Allies to Keep Power" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bloomberg"> /u/bloomberg </a> <br /> <span><a href="https://www.bloomberg.com/news/articles/2024-06-04/modi-poised-to-lose-india-majority-need-allies-to-keep-power">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7vz2f/modi_poised_to_lose_india_majority_need_allies_to/">[comments]</a></span> </td></tr></table>

## Western governments seek response to Russian acts of sabotage in Europe
 - [https://www.reddit.com/r/worldnews/comments/1d7vun9/western_governments_seek_response_to_russian_acts](https://www.reddit.com/r/worldnews/comments/1d7vun9/western_governments_seek_response_to_russian_acts)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T12:25:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7vun9/western_governments_seek_response_to_russian_acts/"> <img alt="Western governments seek response to Russian acts of sabotage in Europe" src="https://external-preview.redd.it/u2rIGM1RKHYUgrIW_4_lmy5FlHC1DP_z5gLuZBXStts.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=71c73cb94b4ad12249098fdfd6b53d3b4ded4eeb" title="Western governments seek response to Russian acts of sabotage in Europe" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/duckanroll"> /u/duckanroll </a> <br /> <span><a href="https://novayagazeta.eu/articles/2024/06/04/western-governments-seek-response-to-russian-acts-of-sabotage-in-europe-en-news">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7vun9/western_governments_seek_response_to_russian_acts/">[comments]</a></span> </td></tr></table>

## Ukraine sent special forces to Syria to attack Russians there, revealing a new front to the war: report
 - [https://www.reddit.com/r/worldnews/comments/1d7vl95/ukraine_sent_special_forces_to_syria_to_attack](https://www.reddit.com/r/worldnews/comments/1d7vl95/ukraine_sent_special_forces_to_syria_to_attack)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T12:11:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7vl95/ukraine_sent_special_forces_to_syria_to_attack/"> <img alt="Ukraine sent special forces to Syria to attack Russians there, revealing a new front to the war: report" src="https://external-preview.redd.it/Gd_azNt7PqEOQN6m-GVkz1my_976Plq5kezkcG39IDc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c1bf70f2376903722ce4112f2c43d07f8014300f" title="Ukraine sent special forces to Syria to attack Russians there, revealing a new front to the war: report" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DevineDoja"> /u/DevineDoja </a> <br /> <span><a href="https://www.businessinsider.com/ukraine-special-forces-syria-attack-russians-new-war-front-report-2024-6">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7vl95/ukraine_sent_special_forces_to_syria_to_attack/">[comments]</a></span> </td></tr></table>

## Belgian EU presidency urges governments to move toward expelling Hungary
 - [https://www.reddit.com/r/worldnews/comments/1d7vjsc/belgian_eu_presidency_urges_governments_to_move](https://www.reddit.com/r/worldnews/comments/1d7vjsc/belgian_eu_presidency_urges_governments_to_move)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T12:09:04+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Shock_The_Monkey_"> /u/Shock_The_Monkey_ </a> <br /> <span><a href="https://www.politico.eu/article/hadja-lahbib-hungary-belgium-eu-governments-nuclear-option-article-7-sanction-budapest/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7vjsc/belgian_eu_presidency_urges_governments_to_move/">[comments]</a></span>

## Taiwan president says Tiananmen crackdown will never be forgotten
 - [https://www.reddit.com/r/worldnews/comments/1d7uydo/taiwan_president_says_tiananmen_crackdown_will](https://www.reddit.com/r/worldnews/comments/1d7uydo/taiwan_president_says_tiananmen_crackdown_will)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T11:36:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7uydo/taiwan_president_says_tiananmen_crackdown_will/"> <img alt="Taiwan president says Tiananmen crackdown will never be forgotten" src="https://external-preview.redd.it/j15n8ddiU8MIEzSqtN_2PfX8x2z1xu0trWHELxgIczo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c9d41c03f19de448c0999e8bc9f46c1d83ea08ea" title="Taiwan president says Tiananmen crackdown will never be forgotten" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/benh999"> /u/benh999 </a> <br /> <span><a href="https://www.reuters.com/world/asia-pacific/taiwan-president-says-tiananmen-crackdown-will-never-be-forgotten-2024-06-04/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7uydo/taiwan_president_says_tiananmen_crackdown_will/">[comments]</a></span> </td></tr></table>

## Israel says about 80 hostages left alive in Gaza
 - [https://www.reddit.com/r/worldnews/comments/1d7uwuz/israel_says_about_80_hostages_left_alive_in_gaza](https://www.reddit.com/r/worldnews/comments/1d7uwuz/israel_says_about_80_hostages_left_alive_in_gaza)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T11:34:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7uwuz/israel_says_about_80_hostages_left_alive_in_gaza/"> <img alt="Israel says about 80 hostages left alive in Gaza" src="https://external-preview.redd.it/r99-aZ7CGJrO8Md-7SES5Orfaa9WJOMl65tFDFH4i2c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a634e96a7d0efaf8b585708ede07f13272ef8fc1" title="Israel says about 80 hostages left alive in Gaza" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ChocoholicCravings"> /u/ChocoholicCravings </a> <br /> <span><a href="https://www.politico.eu/article/israel-says-80-hostages-alive-gaza/?utm_source=RSS_Feed&amp;utm_medium=RSS&amp;utm_campaign=RSS_Syndication">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7uwuz/israel_says_about_80_hostages_left_alive_in_gaza/">[comments]</a></span> </td></tr></table>

## Three men suspected of ‘psychological violence’ at Eiffel Tower
 - [https://www.reddit.com/r/worldnews/comments/1d7tm6k/three_men_suspected_of_psychological_violence_at](https://www.reddit.com/r/worldnews/comments/1d7tm6k/three_men_suspected_of_psychological_violence_at)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T10:11:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7tm6k/three_men_suspected_of_psychological_violence_at/"> <img alt="Three men suspected of ‘psychological violence’ at Eiffel Tower" src="https://external-preview.redd.it/SOW2EAaBtB-3hwM1UvxddPJ4rcdkjaQ9yA_b2G_aklA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=50500c2c07144f8800c70d49a3fae902f725787b" title="Three men suspected of ‘psychological violence’ at Eiffel Tower" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nbcnews"> /u/nbcnews </a> <br /> <span><a href="https://www.nbcnews.com/news/world/three-men-suspected-psychological-violence-eiffel-tower-rcna155342">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7tm6k/three_men_suspected_of_psychological_violence_at/">[comments]</a></span> </td></tr></table>

## India election 2024: Modi heading for reduced majority, early results show
 - [https://www.reddit.com/r/worldnews/comments/1d7t4rd/india_election_2024_modi_heading_for_reduced](https://www.reddit.com/r/worldnews/comments/1d7t4rd/india_election_2024_modi_heading_for_reduced)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T09:38:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7t4rd/india_election_2024_modi_heading_for_reduced/"> <img alt="India election 2024: Modi heading for reduced majority, early results show" src="https://external-preview.redd.it/r6njqPaeZlNPmoTTCeyxPTmze9BzAHUtRvJjevYOuYE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c29a346eb0d918ce48c9f9418555014544279878" title="India election 2024: Modi heading for reduced majority, early results show" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Commercial-Fee5308"> /u/Commercial-Fee5308 </a> <br /> <span><a href="https://www.bbc.com/news/articles/c0vv93pz14zo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7t4rd/india_election_2024_modi_heading_for_reduced/">[comments]</a></span> </td></tr></table>

## Iran Executes 67 in May, Targeting Ethnic Minorities and Juveniles
 - [https://www.reddit.com/r/worldnews/comments/1d7skvc/iran_executes_67_in_may_targeting_ethnic](https://www.reddit.com/r/worldnews/comments/1d7skvc/iran_executes_67_in_may_targeting_ethnic)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T08:57:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7skvc/iran_executes_67_in_may_targeting_ethnic/"> <img alt="Iran Executes 67 in May, Targeting Ethnic Minorities and Juveniles" src="https://external-preview.redd.it/nYp9wzWUgeS0Sev4-FXQtdDL2T51YFJVs99lWrZl4_k.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3b5a6f09b9fba7822826aa48395bb3686caee308" title="Iran Executes 67 in May, Targeting Ethnic Minorities and Juveniles" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/danmghm"> /u/danmghm </a> <br /> <span><a href="https://www.iranintl.com/en/202406034451">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7skvc/iran_executes_67_in_may_targeting_ethnic/">[comments]</a></span> </td></tr></table>

## Moscow warns of escalation after Ukraine told it can hit Russia
 - [https://www.reddit.com/r/worldnews/comments/1d7sf17/moscow_warns_of_escalation_after_ukraine_told_it](https://www.reddit.com/r/worldnews/comments/1d7sf17/moscow_warns_of_escalation_after_ukraine_told_it)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T08:44:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7sf17/moscow_warns_of_escalation_after_ukraine_told_it/"> <img alt="Moscow warns of escalation after Ukraine told it can hit Russia" src="https://external-preview.redd.it/j0Vzyx_S0322Mozc-vc24cNqsvPkF7DHu4hMB-MNt9c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1b90ba873ac3d1dbd41b0280acc356e3d3703f9b" title="Moscow warns of escalation after Ukraine told it can hit Russia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/throwawayforeurope"> /u/throwawayforeurope </a> <br /> <span><a href="https://www.bbc.com/news/articles/ceqq2zn3zw6o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7sf17/moscow_warns_of_escalation_after_ukraine_told_it/">[comments]</a></span> </td></tr></table>

## ABC and Australian news outlets are in the crosshairs of a pro-Russian influence operation
 - [https://www.reddit.com/r/worldnews/comments/1d7s6lc/abc_and_australian_news_outlets_are_in_the](https://www.reddit.com/r/worldnews/comments/1d7s6lc/abc_and_australian_news_outlets_are_in_the)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T08:26:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7s6lc/abc_and_australian_news_outlets_are_in_the/"> <img alt="ABC and Australian news outlets are in the crosshairs of a pro-Russian influence operation" src="https://external-preview.redd.it/E-LaTyUREGl9kMfY9igOhG73Gu6SZWBWq4kBJLCQjGM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2d14c23f23a3b0575f32b2e3fe3e3302882e6259" title="ABC and Australian news outlets are in the crosshairs of a pro-Russian influence operation" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/StopTheGregSign"> /u/StopTheGregSign </a> <br /> <span><a href="https://www.abc.net.au/news/2024-06-04/russia-war-ukraine-propaganda-disinformation-australian-media/103927386?utm_source=abc_news_app&amp;utm_medium=content_shared&amp;utm_campaign=abc_news_app&amp;utm_content=other">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7s6lc/abc_and_australian_news_outlets_are_in_the/">[co

## France's far right may win big in the EU elections. That's worrying for migrants, Macron and Ukraine
 - [https://www.reddit.com/r/worldnews/comments/1d7s6ho/frances_far_right_may_win_big_in_the_eu_elections](https://www.reddit.com/r/worldnews/comments/1d7s6ho/frances_far_right_may_win_big_in_the_eu_elections)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T08:26:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7s6ho/frances_far_right_may_win_big_in_the_eu_elections/"> <img alt="France's far right may win big in the EU elections. That's worrying for migrants, Macron and Ukraine" src="https://external-preview.redd.it/FP1rlOMIjLSTXZa-7MyZzefJreluQVpW-miSZAXybXc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=35b6f49e7b109f4c5115a63dd1041803e1875aaf" title="France's far right may win big in the EU elections. That's worrying for migrants, Macron and Ukraine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JarKachYn"> /u/JarKachYn </a> <br /> <span><a href="https://apnews.com/article/france-eu-election-far-right-1c9bba84aa8ace2619c307b933385473">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7s6ho/frances_far_right_may_win_big_in_the_eu_elections/">[comments]</a></span> </td></tr></table>

## Israel says more than a third of Gaza hostages are dead
 - [https://www.reddit.com/r/worldnews/comments/1d7s1n7/israel_says_more_than_a_third_of_gaza_hostages](https://www.reddit.com/r/worldnews/comments/1d7s1n7/israel_says_more_than_a_third_of_gaza_hostages)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T08:16:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7s1n7/israel_says_more_than_a_third_of_gaza_hostages/"> <img alt="Israel says more than a third of Gaza hostages are dead" src="https://external-preview.redd.it/69L83I0nLKWUY1M5o8KthOYQxeQPxcoPgFV7vY6AqSA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e5bbab34c70d761749b9b71cee6a9cea588b4139" title="Israel says more than a third of Gaza hostages are dead" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Detrivatte"> /u/Detrivatte </a> <br /> <span><a href="https://www.reuters.com/world/middle-east/israel-says-more-than-third-gaza-hostages-are-dead-2024-06-04/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7s1n7/israel_says_more_than_a_third_of_gaza_hostages/">[comments]</a></span> </td></tr></table>

## Nato land corridors could rush US troops to front line in event of European war
 - [https://www.reddit.com/r/worldnews/comments/1d7rng7/nato_land_corridors_could_rush_us_troops_to_front](https://www.reddit.com/r/worldnews/comments/1d7rng7/nato_land_corridors_could_rush_us_troops_to_front)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T07:48:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7rng7/nato_land_corridors_could_rush_us_troops_to_front/"> <img alt="Nato land corridors could rush US troops to front line in event of European war" src="https://external-preview.redd.it/aTsgbG_4bnePNqb_tdkzRaEF0xJACEN3VJAsvRjy6hk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=313d8ffe5b79f631d2c31b8100132e01323fa294" title="Nato land corridors could rush US troops to front line in event of European war" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheTelegraph"> /u/TheTelegraph </a> <br /> <span><a href="https://www.telegraph.co.uk/world-news/2024/06/04/nato-land-corridors-us-troops-european-war/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7rng7/nato_land_corridors_could_rush_us_troops_to_front/">[comments]</a></span> </td></tr></table>

## IDF confirms the deaths of 4 hostages taken by Hamas on October 7
 - [https://www.reddit.com/r/worldnews/comments/1d7qwyt/idf_confirms_the_deaths_of_4_hostages_taken_by](https://www.reddit.com/r/worldnews/comments/1d7qwyt/idf_confirms_the_deaths_of_4_hostages_taken_by)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T06:54:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7qwyt/idf_confirms_the_deaths_of_4_hostages_taken_by/"> <img alt="IDF confirms the deaths of 4 hostages taken by Hamas on October 7" src="https://external-preview.redd.it/N2CMJh7Yh2gQV5T85qAuLuXGxQm5y1RpfWHxQI_hzL8.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=26e59d4320aad6a048083d007c1a084e2b66ea85" title="IDF confirms the deaths of 4 hostages taken by Hamas on October 7" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CredibleNews2024"> /u/CredibleNews2024 </a> <br /> <span><a href="https://allisrael.com/idf-confirms-the-deaths-of-4-hostages-taken-by-hamas-on-october-7">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7qwyt/idf_confirms_the_deaths_of_4_hostages_taken_by/">[comments]</a></span> </td></tr></table>

## Lithuanian FM says Hungary has gone too far with vetoes on EU foreign affairs decisions
 - [https://www.reddit.com/r/worldnews/comments/1d7qhxn/lithuanian_fm_says_hungary_has_gone_too_far_with](https://www.reddit.com/r/worldnews/comments/1d7qhxn/lithuanian_fm_says_hungary_has_gone_too_far_with)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T06:26:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7qhxn/lithuanian_fm_says_hungary_has_gone_too_far_with/"> <img alt="Lithuanian FM says Hungary has gone too far with vetoes on EU foreign affairs decisions" src="https://external-preview.redd.it/qSDYr-UOhBQVle8RGDvYT-QwoKmb_5c69da-fWYRjc0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=41f4381be0eaf3f651f09ab6ae00674a5f517367" title="Lithuanian FM says Hungary has gone too far with vetoes on EU foreign affairs decisions" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AlertTangerine"> /u/AlertTangerine </a> <br /> <span><a href="https://telex.hu/english/2024/05/27/lithuanian-fm-says-hungary-has-gone-too-far-with-vetoes-on-eu-decisions-on-foreign-affairs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7qhxn/lithuanian_fm_says_hungary_has_gone_too_far_with/">[comments]</a></span> </td></tr></table>

## US: Roadblock to Gaza ceasefire is Hamas, not Israel
 - [https://www.reddit.com/r/worldnews/comments/1d7pvyi/us_roadblock_to_gaza_ceasefire_is_hamas_not_israel](https://www.reddit.com/r/worldnews/comments/1d7pvyi/us_roadblock_to_gaza_ceasefire_is_hamas_not_israel)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T05:47:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7pvyi/us_roadblock_to_gaza_ceasefire_is_hamas_not_israel/"> <img alt="US: Roadblock to Gaza ceasefire is Hamas, not Israel" src="https://external-preview.redd.it/ED6jymQFvFYvLhzcXC3OybvL6yQLS5brnCN937N1I_4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2913efe682d77f8bdd5b24c3e7339ef245e977c5" title="US: Roadblock to Gaza ceasefire is Hamas, not Israel" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yuri_2022"> /u/yuri_2022 </a> <br /> <span><a href="https://www.jpost.com/israel-hamas-war/article-804866">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7pvyi/us_roadblock_to_gaza_ceasefire_is_hamas_not_israel/">[comments]</a></span> </td></tr></table>

## /r/WorldNews Live Thread: Russian Invasion of Ukraine Day 832, Part 1 (Thread #978)
 - [https://www.reddit.com/r/worldnews/comments/1d7o6ff/rworldnews_live_thread_russian_invasion_of](https://www.reddit.com/r/worldnews/comments/1d7o6ff/rworldnews_live_thread_russian_invasion_of)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T04:02:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7o6ff/rworldnews_live_thread_russian_invasion_of/"> <img alt="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 832, Part 1 (Thread #978)" src="https://a.thumbs.redditmedia.com/jWqSTFxxKuo9aDK8JeM4yZL4Nb_RTA85H45u1-h63L8.jpg" title="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 832, Part 1 (Thread #978)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WorldNewsMods"> /u/WorldNewsMods </a> <br /> <span><a href="https://www.reddit.com/live/18hnzysb1elcs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7o6ff/rworldnews_live_thread_russian_invasion_of/">[comments]</a></span> </td></tr></table>

## Russia knows Putin's Crimea bridge is 'doomed,' Ukrainian official says
 - [https://www.reddit.com/r/worldnews/comments/1d7nsxr/russia_knows_putins_crimea_bridge_is_doomed](https://www.reddit.com/r/worldnews/comments/1d7nsxr/russia_knows_putins_crimea_bridge_is_doomed)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T03:42:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7nsxr/russia_knows_putins_crimea_bridge_is_doomed/"> <img alt="Russia knows Putin's Crimea bridge is 'doomed,' Ukrainian official says" src="https://external-preview.redd.it/gwbvg0fsGIuV6O42-MG6LCcVP2eOQm5linx7Rq7p5e4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f57ceeb2ddf8eb5323d41cad2dac4e3fce9593e4" title="Russia knows Putin's Crimea bridge is 'doomed,' Ukrainian official says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/new974517"> /u/new974517 </a> <br /> <span><a href="https://www.businessinsider.com/russia-knows-putin-crimea-kerch-bridge-doomed-atacms-ukraine-official-2024-6">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7nsxr/russia_knows_putins_crimea_bridge_is_doomed/">[comments]</a></span> </td></tr></table>

## TikTok fails 'disinformation test' before EU vote, study shows
 - [https://www.reddit.com/r/worldnews/comments/1d7mx6m/tiktok_fails_disinformation_test_before_eu_vote](https://www.reddit.com/r/worldnews/comments/1d7mx6m/tiktok_fails_disinformation_test_before_eu_vote)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T02:54:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7mx6m/tiktok_fails_disinformation_test_before_eu_vote/"> <img alt="TikTok fails 'disinformation test' before EU vote, study shows" src="https://external-preview.redd.it/hgRwY-2sfmXm5WvwM-ROKqvy5SMYbbniALKaswEpPrw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=45930fd227feea2c3c466def5d64c82ad53ca692" title="TikTok fails 'disinformation test' before EU vote, study shows" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DoremusJessup"> /u/DoremusJessup </a> <br /> <span><a href="https://www.france24.com/en/live-news/20240604-tiktok-fails-disinformation-test-before-eu-vote-study-shows">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7mx6m/tiktok_fails_disinformation_test_before_eu_vote/">[comments]</a></span> </td></tr></table>

## Epoch Times CFO Bill Guan is charged in alleged $67 million global money laundering scheme
 - [https://www.reddit.com/r/worldnews/comments/1d7m52x/epoch_times_cfo_bill_guan_is_charged_in_alleged](https://www.reddit.com/r/worldnews/comments/1d7m52x/epoch_times_cfo_bill_guan_is_charged_in_alleged)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-06-04T02:13:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1d7m52x/epoch_times_cfo_bill_guan_is_charged_in_alleged/"> <img alt="Epoch Times CFO Bill Guan is charged in alleged $67 million global money laundering scheme" src="https://external-preview.redd.it/8-521O8xkK8tVGUeAVzc91kBL86qn4ZdKoIXyntAskk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a13380ffbea9d35e3d23e9ecf9a9473c5f296c2a" title="Epoch Times CFO Bill Guan is charged in alleged $67 million global money laundering scheme" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/reflibman"> /u/reflibman </a> <br /> <span><a href="https://www.cnbc.com/2024/06/03/money-laundering-epoch-times-cfo-charged-with-alleged-67-million-scheme-.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1d7m52x/epoch_times_cfo_bill_guan_is_charged_in_alleged/">[comments]</a></span> </td></tr></table>

