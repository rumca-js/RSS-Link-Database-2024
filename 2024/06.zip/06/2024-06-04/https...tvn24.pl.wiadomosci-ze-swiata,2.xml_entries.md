# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Pożar w Elektrowni Jaworzno. Zapalił się olej układu hydraulicznego
 - [https://tvn24.pl/polska/pozar-w-elektrowni-jaworzno-bloku-energetyczny-tymczasowo-wylaczony-st7948025?source=rss](https://tvn24.pl/polska/pozar-w-elektrowni-jaworzno-bloku-energetyczny-tymczasowo-wylaczony-st7948025?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T20:43:09+00:00

<img alt="Pożar w Elektrowni Jaworzno. Zapalił się olej układu hydraulicznego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s8r2tm-pozar-w-elektrowni-jaworzno-ogien-udalo-sie-juz-ugasic-ph7948032/alternates/LANDSCAPE_1280" />
    W Elektrowni Jaworzno wybuchł pożar. Jak przekazał rzecznik miejskiej straży pożarnej kapitan Michał Dyl, "zapalił się olej układu hydraulicznego wentylatora spalin". Ogień udało się szybko opanować.

## Kolejna ofiara śmiertelna powodzi w Niemczech
 - [https://tvn24.pl/tvnmeteo/najnowsze/kolejna-ofiara-smiertelna-powodzi-w-niemczech-st7948007?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/kolejna-ofiara-smiertelna-powodzi-w-niemczech-st7948007?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T20:13:25+00:00

<img alt="Kolejna ofiara śmiertelna powodzi w Niemczech" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-a1w8cx-powodz-na-poludniu-niemiec-ph7948013/alternates/LANDSCAPE_1280" />
    Do pięciu wzrosła liczba ofiar śmiertelnych powodzi w południowych Niemczech. Pasawa jest kolejnym miastem w Bawarii, w którym ogłoszono stan klęski żywiołowej. Poziom wody w Dunaju wynosił tam 10 metrów.

## Kolejna ofiara śmiertelna powodzi w Niemczech
 - [https://tvn24.pl/tvnmeteo/swiat/kolejna-ofiara-smiertelna-powodzi-w-niemczech-st7948007?source=rss](https://tvn24.pl/tvnmeteo/swiat/kolejna-ofiara-smiertelna-powodzi-w-niemczech-st7948007?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T19:53:00+00:00

<img alt="Kolejna ofiara śmiertelna powodzi w Niemczech" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-a1w8cx-powodz-na-poludniu-niemiec-ph7948013/alternates/LANDSCAPE_1280" />
    Do pięciu wzrosła liczba ofiar śmiertelnych powodzi w południowych Niemczech. Pasawa jest kolejnym miastem w Bawarii, w którym ogłoszono stan klęski żywiołowej. We wtorek poziom wody w Dunaju wynosił tam 10 metrów.

## Wypadek pod Mińskiem Mazowieckim. Lądował helikopter Lotniczego Pogotowia Ratunkowego
 - [https://tvn24.pl/tvnwarszawa/najnowsze/minsk-mazowiecki-wypadek-drogowy-ladowal-helikopter-lotniczego-pogotowia-ratunkowego-jedna-osoba-w-szpitalu-st7947988?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/minsk-mazowiecki-wypadek-drogowy-ladowal-helikopter-lotniczego-pogotowia-ratunkowego-jedna-osoba-w-szpitalu-st7947988?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T19:49:58+00:00

<img alt="Wypadek pod Mińskiem Mazowieckim. Lądował helikopter Lotniczego Pogotowia Ratunkowego" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-prs49u-wypadek-pod-minskim-mazowieckim-ph7947996/alternates/LANDSCAPE_1280" />
    Do wypadku drogowego doszło pod Mińskiem Mazowieckim. Cztery osoby trafiły do szpitala, jedna z nich została przewieziona helikopterem Lotniczego Pogotowia Ratunkowego. Na miejscu pracują służby. Są utrudnienia.

## Wiceministra o Funduszu Sprawiedliwości i sytuacji, jaką zastała w resorcie: nic nie mogło mnie na to przygotować
 - [https://tvn24.pl/polska/afera-funduszu-sprawiedliwosci-wiceministra-weszla-do-resortu-i-poczula-groze-st7947950?source=rss](https://tvn24.pl/polska/afera-funduszu-sprawiedliwosci-wiceministra-weszla-do-resortu-i-poczula-groze-st7947950?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T19:44:35+00:00

<img alt="Wiceministra o Funduszu Sprawiedliwości i sytuacji, jaką zastała w resorcie: nic nie mogło mnie na to przygotować" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5frpf6-wiceminister-sprawiedliwosci-zuzanna-rudzinska-bluszcz-podczas-wiecu-4-czerwca-na-placu-zamkowym-w-warszawie-ph7947955/alternates/LANDSCAPE_1280" />
    Nic, co wcześniej słyszałam, czytałam, nie mogło mnie przygotować na to, co zastałam w Departamencie Funduszu Sprawiedliwości - powiedziała wiceministra sprawiedliwości Zuzanna Rudzińska-Bluszcz. Przyznała, że poznając kulisy jego działania, poczuła "grozę". Mówiła o brakujących dokumentach, rezygnacji z pracy dyrektorki Departamentu i odejściach innych pracowników. Jej zdaniem ten Fundusz "to antyteza państwa dobrego i sprawiedliwego".

## Pokolenie Z nie potrzebuje studiów by odnieść sukces
 - [https://tvn24.pl/biznes/z-kraju/pokolenie-z-czy-studia-sa-wazne-dla-zetek-wyniki-badan-dla-politechniki-wroclawskiej-st7947940?source=rss](https://tvn24.pl/biznes/z-kraju/pokolenie-z-czy-studia-sa-wazne-dla-zetek-wyniki-badan-dla-politechniki-wroclawskiej-st7947940?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T19:36:30+00:00

<img alt="Pokolenie Z nie potrzebuje studiów by odnieść sukces" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8fpke9-shutterstock_2282856415-7913307/alternates/LANDSCAPE_1280" />
    Zaledwie 30 procent osób z pokolenia Z uważa, że wykształcenie wyższe jest kluczowe w osiągnięciu sukcesu zawodowego - wynika z badania Instytutu Badawczego IPC na zlecenie Politechniki Wrocławskiej. Największą wartością jest dla nich rodzina, a największe wsparcie dają im rodzice. Do pokolenia Z należą ludzie urodzeni w latach od 1995 do 2012.

## Rosja przymusowo kieruje na front odmawiających walki. "Są bici i siłą wysyłani"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/rosja-przymusowo-kieruje-na-front-odmawiajacych-walki-sa-bici-i-sila-wysylani-st7947968?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/rosja-przymusowo-kieruje-na-front-odmawiajacych-walki-sa-bici-i-sila-wysylani-st7947968?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T19:31:42+00:00

<img alt="Rosja przymusowo kieruje na front odmawiających walki. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-iv2pai-rosyjska-armia-wysyla-na-front-odmawiajacych-walki-ph7947983/alternates/LANDSCAPE_1280" />
    Rosyjskie media donoszą o złym traktowaniu osób zmobilizowanych do wojska, które odmawiają walki w Ukrainie. Świadkowie informują, że komisarze wojskowi nie zwracają uwagi na choroby, odniesione wcześniej rany i inne powody, które zgodnie z prawem zwalniają z obowiązku służby wojskowej. Jak pisze portal Wiorstka, powodem działań rosyjskiej armii może być brak żołnierzy do oblężenia Charkowa.

## Gigantyczna kumulacja w Eurojackpot rozbita
 - [https://tvn24.pl/biznes/pieniadze/eurojackpot-wyniki-04062024-gigantyczna-kumulacja-rozbita-st7947718?source=rss](https://tvn24.pl/biznes/pieniadze/eurojackpot-wyniki-04062024-gigantyczna-kumulacja-rozbita-st7947718?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T19:14:26+00:00

<img alt="Gigantyczna kumulacja w Eurojackpot rozbita" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ejtp1a-en_01612916_2361-1-ph7947746/alternates/LANDSCAPE_1280" />
    We wtorkowym losowaniu Eurojackpot główna wygrana padła w Danii. Do zgarnięcia było 120 milionów euro, czyli ponad pół miliarda złotych. W Polsce padła wygrana IV stopnia. Oto liczby, jakie wylosowano 4 czerwca.

## "Dramatyczna" fala upałów w Grecji
 - [https://tvn24.pl/tvnmeteo/swiat/uderzenie-goraca-w-grecji-dramatyczna-fala-upalow-st7947954?source=rss](https://tvn24.pl/tvnmeteo/swiat/uderzenie-goraca-w-grecji-dramatyczna-fala-upalow-st7947954?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T19:06:37+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-cxet8o-upalna-pogoda-w-grecji-ph7947973/alternates/LANDSCAPE_1280" />
    Po gorącym weekendzie, w czasie którego temperatura sięgała około 30 stopni Celsjusza, Grecy doznają w tym tygodniu o wiele większego uderzenia gorąca.

## "Ważny sygnał" z Warszawy. "Może zmobilizował kilkadziesiąt tysięcy, może sto kilkadziesiąt tysięcy"
 - [https://tvn24.pl/polska/wazny-sygnal-z-warszawy-moze-zmobilizowal-kilkadziesiat-tysiecy-moze-sto-kilkadziesiat-tysiecy-st7947886?source=rss](https://tvn24.pl/polska/wazny-sygnal-z-warszawy-moze-zmobilizowal-kilkadziesiat-tysiecy-moze-sto-kilkadziesiat-tysiecy-st7947886?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T18:57:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o4q8a4-donald-tusk-na-wiecu-w-warszawie-4062024-ph7947977/alternates/LANDSCAPE_1280" />
    - Widzimy sondaże. Te dwie główne formacje idą łeb w łeb, więc warto było tę małą cegiełkę dołożyć - mówił profesor Antoni Dudek o przemówieniu premiera Donalda Tuska na wiecu w Warszawie, komentując szanse KO i PiS w wyborach do europarlamentu. Profesor Andrzej Rychard stwierdził, że przesłanie Tuska do obywateli było jasne: "Europa wiąże się z naszym bezpieczeństwem".

## Od 5 czerwca badania prenatalne będą dostępne bezpłatnie. "Pacjentce się to zwyczajnie należy"
 - [https://fakty.tvn24.pl/zobacz-fakty/od-5-czerwca-badania-prenatalne-beda-dostepne-bezplatnie-pacjentce-sie-to-zwyczajnie-nalezy-st7947761?source=rss](https://fakty.tvn24.pl/zobacz-fakty/od-5-czerwca-badania-prenatalne-beda-dostepne-bezplatnie-pacjentce-sie-to-zwyczajnie-nalezy-st7947761?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T18:54:19+00:00

<img alt="Od 5 czerwca badania prenatalne będą dostępne bezpłatnie. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-76abqr-gorniak-ph7947853/alternates/LANDSCAPE_1280" />
    Już nie będzie ograniczenia wiekowego 35 lat, wystarczy skierowanie od lekarza prowadzącego ciążę - od 5 czerwca badania prenatalne będą dostępne dla wszystkich kobiet. I co najważniejsze, bezpłatnie. Tych badań jest wiele i nie są tylko po to, by w razie ciężkiej wady płodu usunąć ciążę.

## Zgorzelski: Europa musi usłyszeć głos tych, którzy obudzili się 15 października
 - [https://tvn24.pl/polska/wybory-do-parlamentu-europejskiego-2024-piotr-zgorzelski-europa-musi-uslyszec-glos-tych-ktorzy-obudzili-sie-15-pazdziernika-st7947913?source=rss](https://tvn24.pl/polska/wybory-do-parlamentu-europejskiego-2024-piotr-zgorzelski-europa-musi-uslyszec-glos-tych-ktorzy-obudzili-sie-15-pazdziernika-st7947913?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T18:47:50+00:00

<img alt="Zgorzelski: Europa musi usłyszeć głos tych, którzy obudzili się 15 października" src="https://tvn24.pl/najnowsze/cdn-zdjecie-klvuf-monika-rosa-piotr-zgorzelski-ph7947858/alternates/LANDSCAPE_1280" />
    - Zgadzam się ze słowami Donalda Tuska, że wybory do Parlamentu Europejskiego są tak samo ważne jak te 4 czerwca 1989 roku. Jesteśmy na najlepszej drodze, żeby wrócić do rodziny państw demokratycznych - mówił w "Faktach po Faktach" w TVN24 wicemarszałek Sejmu Piotr Zgorzelski (PSL-Trzecia Droga). - Najbliższe wybory pokażą nasze miejsce w Unii Europejskiej - powiedziała posłanka Koalicji Obywatelskiej Monika Rosa.

## Koniec z rosyjską ropą w Czechach. Padła data
 - [https://tvn24.pl/biznes/ze-swiata/ropa-z-rosji-nie-bedzie-dostarczana-do-czech-od-polowy-2025-roku-st7947887?source=rss](https://tvn24.pl/biznes/ze-swiata/ropa-z-rosji-nie-bedzie-dostarczana-do-czech-od-polowy-2025-roku-st7947887?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T18:33:41+00:00

<img alt="Koniec z rosyjską ropą w Czechach. Padła data" src="https://tvn24.pl/biznes/najnowsze/ekspert-o-wznowieniu-dostaw-ropy-do-polski-9991851333/alternates/LANDSCAPE_1280" />
    W przyszłym roku Czechy dołączą do państw niezależnych od dostaw ropy z Rosji - zapowiedział Petr Fiala premier tego kraju. Obecnie Czechy są wyłączone z unijnego embarga na rosyjską ropę.

## Urzędy w całej Polsce przygotowują się do wyborów do Parlamentu Europejskiego
 - [https://fakty.tvn24.pl/zobacz-fakty/urzedy-w-calej-polsce-przygotowuja-sie-do-wyborow-do-parlamentu-europejskiego-st7947742?source=rss](https://fakty.tvn24.pl/zobacz-fakty/urzedy-w-calej-polsce-przygotowuja-sie-do-wyborow-do-parlamentu-europejskiego-st7947742?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T18:28:57+00:00

<img alt="Urzędy w całej Polsce przygotowują się do wyborów do Parlamentu Europejskiego" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-p3duzx-wybory2-ph7947933/alternates/LANDSCAPE_1280" />
    Tony wyborczych kart trafiają do urzędów, czas przygotować lokale wyborcze. Wybory do europarlamentu już w niedzielę. We wtorek mija termin dopisania się do spisu wyborców, jeśli ktoś chce głosować zagranicą. Wszyscy musimy powalczyć o frekwencję.

## Interpol odmówił ścigania czerwoną notą byłego sędziego Tomasza Szmydta
 - [https://tvn24.pl/najnowsze/interpol-odmowil-scigania-czerwona-nota-bylego-sedziego-tomasza-szmydta%20-st7947844?source=rss](https://tvn24.pl/najnowsze/interpol-odmowil-scigania-czerwona-nota-bylego-sedziego-tomasza-szmydta%20-st7947844?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T17:52:38+00:00

<img alt="Interpol odmówił ścigania czerwoną notą byłego sędziego Tomasza Szmydta " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vbd6xt-tomasz-szmydt-7906601/alternates/LANDSCAPE_1280" />
    Były sędzia Tomasz Szmydt podejrzany o szpiegostwo nie będzie ścigany na podstawie czerwonej noty Interpolu, o co wnioskowała prokuratura. - Interpol nie zezwala na przetwarzanie danych za pośrednictwem swoich kanałów za działania przeciwko bezpieczeństwu państwa określane jako przestępstwa polityczne - poinformowała rzeczniczka komendanta głównego policji mł. insp. Katarzyna Nowak.

## Mimo zapowiedzi Jarosław Kaczyński nie wystąpił na proteście rolników w Brukseli
 - [https://tvn24.pl/polska/mimo-zapowiedzi-jaroslaw-kaczynski-nie-wystapil-na-protescie-rolnikow-w-brukseli-st7947738?source=rss](https://tvn24.pl/polska/mimo-zapowiedzi-jaroslaw-kaczynski-nie-wystapil-na-protescie-rolnikow-w-brukseli-st7947738?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T17:41:22+00:00

<img alt="Mimo zapowiedzi Jarosław Kaczyński nie wystąpił na proteście rolników w Brukseli" src="https://tvn24.pl/najnowsze/cdn-zdjecie-77s1t6-jaroslaw-kaczynski-bruksela-ph7947634/alternates/LANDSCAPE_1280" />
    Prezes PiS Jarosław Kaczyński mimo zapowiedzi nie wystąpił na proteście rolników w Brukseli. - Po prostu odbyliśmy spotkania w takiej formule, która była z jednej strony naprawdę efektywna, a z drugiej strony nie łączyła się z różnego rodzaju możliwościami różnych incydentów - powiedział. - My jesteśmy na przykład jak najdalsi od pomysłu polexitu - dodał. Jak relacjonował korespondent TVN24 w Brukseli Maciej Sokołowski, demonstracja nie była tak duża, jak zapowiadano.

## Niższa emerytura uznana za niekonstytucyjną. Ważny wyrok dla części emerytów
 - [https://tvn24.pl/biznes/pieniadze/pomniejszenie-emerytury-przy-wczesniejszej-emeryturze-niezgodne-z-konstytucja-wyrok-tk-st7947801?source=rss](https://tvn24.pl/biznes/pieniadze/pomniejszenie-emerytury-przy-wczesniejszej-emeryturze-niezgodne-z-konstytucja-wyrok-tk-st7947801?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T17:38:05+00:00

<img alt="Niższa emerytura uznana za niekonstytucyjną. Ważny wyrok dla części emerytów" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjeciec09f9e64aac0fa9201f774283ed962c7-w-2020-roku-najnizsza-emerytura-ma-wyniesc-1200-zl-4986115/alternates/LANDSCAPE_1280" />
    Pomniejszenie emerytury osobie, która przeszła na wcześniejszą emeryturę jest niezgodne z konstytucją - orzekł Trybunał Konstytucyjny. Skutkiem wyroku jest możliwość wznowienia postępowania dotyczącego osoby, która złożyła skargę konstytucyjną.

## Ponad 300 chętnych na kupno 37 aut. Drogowcy sprzedają odholowane samochody
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-sprzedaz-odholowanych-samochodow-siodmy-przetarg-40-samochodow-i-ponad-300-chetnych-st7947477?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-sprzedaz-odholowanych-samochodow-siodmy-przetarg-40-samochodow-i-ponad-300-chetnych-st7947477?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T17:36:43+00:00

<img alt="Ponad 300 chętnych na kupno 37 aut. Drogowcy sprzedają odholowane samochody" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-oxy9l9-zdm-sprzedaje-odholowane-samochody-ph7947657/alternates/LANDSCAPE_1280" />
    W miejskiej kasie może przybyć 200 tysięcy złotych. To środki ze sprzedaży odholowanych aut. Właśnie zakończył się siódmy przetarg, prowadzony przez Zarząd Dróg Miejskich. Pod młotek trafiło prawie 40 samochodów, na które wpłynęło ponad 300 ofert.

## Pożar dawnego pensjonatu, obok stacja paliw. Nagranie
 - [https://tvn24.pl/trojmiasto/gdansk-pozar-dawnego-pensjonatu-srebrny-mlyn-nagranie-st7947816?source=rss](https://tvn24.pl/trojmiasto/gdansk-pozar-dawnego-pensjonatu-srebrny-mlyn-nagranie-st7947816?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T17:27:51+00:00

<img alt="Pożar dawnego pensjonatu, obok stacja paliw. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p2ufi2-pozar-dawnego-pensjonatu-i-restauracji-srebrny-mlyn-w-gdansku-ph7947814/alternates/LANDSCAPE_1280" />
    Pożar pustostanu w Gdańsku. Tuż obok płonącego budynku - dawnego pensjonatu i restauracji - znajduje się stacja paliw. Z ogniem walczą osiem zastępów straży pożarnej. Nie wiadomo, czy w środku znajdowali się ludzie.

## Pogoda na jutro - środa 05.06. W wielu miejscach spadnie deszcz, w górach może zagrzmieć
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sroda-0506-w-wielu-miejscach-spadnie-deszcz-w-gorach-moze-zagrzmiec-st7947796?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sroda-0506-w-wielu-miejscach-spadnie-deszcz-w-gorach-moze-zagrzmiec-st7947796?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T17:18:05+00:00

<img alt="Pogoda na jutro - środa 05.06. W wielu miejscach spadnie deszcz, w górach może zagrzmieć" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1oprfw-moze-padac-deszcz-7321664/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. W środę 05.06 opady deszczu wystąpią w większości kraju, jednak nie powinny być obfite. W górach należy spodziewać się burz. Termometry wskażą od 19 do 25 stopni Celsjusza.

## "Groził dziewczynce nożem, żądał pieniędzy, ukradł jej telefon"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/plock-napad-na-16-latke-grozil-dziewczynce-nozem-zadal-pieniedzy-ukradl-telefon-st7947728?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/plock-napad-na-16-latke-grozil-dziewczynce-nozem-zadal-pieniedzy-ukradl-telefon-st7947728?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T16:55:33+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-66t1md-11-latek-zmarl-po-tym-jak-spadl-na-niego-drewniany-domek-zdj-ilustracyjne-7944019/alternates/LANDSCAPE_1280" />
    Do napadu na 16-latkę doszło w Płocku. Z ustaleń policji wynika, że napastnik groził jej nożem, żądał pieniędzy, a następnie ukradł telefon komórkowy. Zatrzymany został 35-latek, okazało się, że wcześniej był już karany.

## Pięć pojazdów zderzyło się przy autostradzie. Jedna osoba zginęła
 - [https://tvn24.pl/krakow/brzesko-karambol-przy-wezle-autostrady-a4-w-wypadku-zginela-jedna-osoba-st7947723?source=rss](https://tvn24.pl/krakow/brzesko-karambol-przy-wezle-autostrady-a4-w-wypadku-zginela-jedna-osoba-st7947723?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T16:33:02+00:00

<img alt="Pięć pojazdów zderzyło się przy autostradzie. Jedna osoba zginęła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2s95sr-karambol-na-dk75-w-brzesku-ph7947775/alternates/LANDSCAPE_1280" />
    Pięć samochodów - trzy osobowe i dwa ciężarowe - zderzyło się we wtorek przy zjeździe z autostrady A4 w Brzesku (woj. małopolskie). Zginął 26-latek, który najprawdopodobniej nie zatrzymał się przed znakiem "stop", wjeżdżając wprost przed nadjeżdżającą ciężarówkę.

## Makłowicz, Torbicka, Raczek, Waglewski i Linette z ważnym apelem do Polaków
 - [https://tvn24.pl/wybory-do-europarlamentu-2024/wybory-do-parlamentu-europejskiego-2024-maklowicz-torbicka-raczek-waglewski-i-linette-z-waznym-apelem-do-polakow-st7947606?source=rss](https://tvn24.pl/wybory-do-europarlamentu-2024/wybory-do-parlamentu-europejskiego-2024-maklowicz-torbicka-raczek-waglewski-i-linette-z-waznym-apelem-do-polakow-st7947606?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T15:56:19+00:00

<img alt="Makłowicz, Torbicka, Raczek, Waglewski i Linette z ważnym apelem do Polaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hvcoun-12-ph7947655/alternates/LANDSCAPE_1280" />
    Znani Polacy zachęcają do głosowania w wyborach do Parlamentu Europejskiego, które w Polsce odbędą się już w najbliższą niedzielę. Grażyna Torbicka przekonuje, że "Europa jest naszym wspólnym domem", a Robert Makłowicz, że należy głosować, by kształtować Europę "wedle naszego uznania". "Bycie poza Unią w dzisiejszych czasach to jest w zasadzie skazanie się na niebyt - podkreśla z kolei Wojciech Waglewski.

## Pozostaniemy w zasięgu cyklonów. Pogoda będzie dynamiczna
 - [https://tvn24.pl/tvnmeteo/prognoza/pozostaniemy-w-zasiegu-cyklonow-pogoda-bedzie-dynamiczna-st7947611?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pozostaniemy-w-zasiegu-cyklonow-pogoda-bedzie-dynamiczna-st7947611?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T15:40:11+00:00

<img alt="Pozostaniemy w zasięgu cyklonów. Pogoda będzie dynamiczna" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-4i692s-deszcz-w-lublinie-ph7947623/alternates/LANDSCAPE_1280" />
    Do końca tygodnia w wielu miejscach Polski spodziewamy się opadów deszczu, choć nie powinny być one tak intensywne, jak te występujące w nocy z poniedziałku na wtorek w południowej i południowo-wschodniej Polsce. Nie zabraknie także burz.

## Europarlament "skręci w prawo" po wyborach? Oto co mówią ostatnie sondaże
 - [https://tvn24.pl/wybory-do-europarlamentu-2024/wybory-do-parlamentu-europejskiego-2024-prawica-rosnie-w-sile-oto-co-mowia-sondaze-st7947254?source=rss](https://tvn24.pl/wybory-do-europarlamentu-2024/wybory-do-parlamentu-europejskiego-2024-prawica-rosnie-w-sile-oto-co-mowia-sondaze-st7947254?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T15:34:16+00:00

<img alt="Europarlament " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rs5ugl-zmiany-sojuszy-wsrod-europejskiej-skrajnej-prawicy-marine-le-pen-spotkala-sie-z-matteo-salvinim-7928563/alternates/LANDSCAPE_1280" />
    Przedwyborcze sondaże wskazują, że prawica może się umocnić po nadchodzących wyborach do Parlamentu Europejskiego, jednak prognozowany układ sił nie zmieni się znacząco. Na ile prawica rośnie w siłę i jakich zmian spodziewać się po eurowyborach 2024?

## Donald Tusk na wiecu w Warszawie: niedzielne wybory są bojem o to, by wojna nie wkroczyła do Polski
 - [https://tvn24.pl/polska/tusk-9-czerwca-boj-o-to-by-wojna-nie-wkroczyla-do-polski-st7947587?source=rss](https://tvn24.pl/polska/tusk-9-czerwca-boj-o-to-by-wojna-nie-wkroczyla-do-polski-st7947587?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T15:32:09+00:00

<img alt="Donald Tusk na wiecu w Warszawie: niedzielne wybory są bojem o to, by wojna nie wkroczyła do Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fpdr0e-wiec-w-warszawie-ph7947748/alternates/LANDSCAPE_1280" />
    Premier Donald Tusk podczas wiecu w Warszawie podkreślał, że obecnie toczy się walka o to, kto będzie rządził w Europie. - Uwierzcie mi, tam na Kremlu, dla nich ewentualne polityczne zdobycie Brukseli byłoby ważniejsze niż zdobycie Charkowa - przekonywał. Jak mówił, walka, która trwa, to także "bój o to, aby wojna nie wkroczyła w nasze granice". Na placu Zamkowym przemawiał także były prezydent Lech Wałęsa czy wiceszef PO, prezydent stolicy Rafał Trzaskowski.

## "Polska nie zmęczyła się wolnością". Tusk na wiecu PO 4 czerwca
 - [https://tvn24.pl/polska/wiec-platformy-obywatelskiej-w-warszawie-relacja-na-zywo-st7947587?source=rss](https://tvn24.pl/polska/wiec-platformy-obywatelskiej-w-warszawie-relacja-na-zywo-st7947587?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T15:32:09+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ktvdcm-wiec-plac-zamkowy-ph7947694/alternates/LANDSCAPE_1280" />
    Na placu Zamkowym w Warszawie trwa wiec Platformy Obywatelskiej. Przemawia lider partii, premier Donald Tusk. - Tylu malkontentów i naszych oponentów mówiło: nie przyjdą, zmęczyli się. A wy jesteście. Bo Polska się nie zmęczyła wolnością - powiedział premier.

## Suwerenna Polska: dotacje szły do gmin, gdzie nie rządziliśmy. Lecz nie tego dotyczy afera
 - [https://konkret24.tvn24.pl/polityka/fundusz-sprawiedliwosci-suwerenna-polska-dotacje-szly-do-gmin-gdzie-nie-rzadzilismy-lecz-nie-tego-dotyczy-afera-st7945593?source=rss](https://konkret24.tvn24.pl/polityka/fundusz-sprawiedliwosci-suwerenna-polska-dotacje-szly-do-gmin-gdzie-nie-rzadzilismy-lecz-nie-tego-dotyczy-afera-st7945593?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T15:21:40+00:00

<img alt="Suwerenna Polska: dotacje szły do gmin, gdzie nie rządziliśmy. Lecz nie tego dotyczy afera " src="https://tvn24.pl/najnowsze/cdn-zdjecie-x6xtjk-suwerenna-polska-o-funduszu-sprawiedliwosci-ph7947204/alternates/LANDSCAPE_1280" />
    Na głosy o wykorzystywanie Funduszu Sprawiedliwości do celów politycznych Suwerenna Polska odpowiada, że przecież środki trafiły głównie do gmin, gdzie rządzili "bezpartyjni". To próba zmanipulowania opinii publicznej: odwrócenia uwagi od faktu, że publiczne pieniądze służyły do prowadzenia kampanii wyborczej.

## Mieszkańcy usuwają skutki ulew. IMGW ostrzega przed kolejnymi opadami
 - [https://fakty.tvn24.pl/fakty-po-poludniu/mieszkancy-usuwaja-skutki-ulew-imgw-ostrzega-przed-kolejnymi-opadami-st7947550?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/mieszkancy-usuwaja-skutki-ulew-imgw-ostrzega-przed-kolejnymi-opadami-st7947550?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T15:08:20+00:00

<img alt="Mieszkańcy usuwają skutki ulew. IMGW ostrzega przed kolejnymi opadami" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-4wvny4-jarecki-ph7947559/alternates/LANDSCAPE_1280" />
    Nie tylko Bielsko-Białą dotknęły ulewy i podtopienia. W innych miejscach województwa śląskiego i w Małopolsce służby i mieszkańcy również usuwają skutki ulew. Wiele rzek przekracza stany alarmowe, IMGW ostrzega, że to jeszcze nie koniec deszczów - będą kolejne.

## Wakacje kredytowe. Odpowiedzi na najważniejsze pytania
 - [https://tvn24.pl/biznes/pieniadze/wakacje-kredytowe-2024-odpowiedzi-na-najwazniejsze-pytania-st7946847?source=rss](https://tvn24.pl/biznes/pieniadze/wakacje-kredytowe-2024-odpowiedzi-na-najwazniejsze-pytania-st7946847?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T14:59:01+00:00

<img alt="Wakacje kredytowe. Odpowiedzi na najważniejsze pytania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bm7dmf-shutterstock_1716917581-ph7947607/alternates/LANDSCAPE_1280" />
    Od 1 czerwca kredytobiorcy mogą korzystać z rządowych wakacji kredytowych. Spłatę kredytu można zawiesić w tym roku na cztery miesiące. Rozwiązanie dostępne jest dla klientów, którzy zaciągnęli kredyt w złotych przed 1 lipca 2022 roku. W związku z wprowadzeniem wakacji kredytowych Rzecznik Finansowy odpowiedział na najważniejsze pytania.

## Kot został postrzelony z wiatrówki. "Umierał w męczarniach". Policja szuka sprawcy
 - [https://tvn24.pl/krakow/tarnow-kot-postrzelony-z-wiatrowki-umieral-w-meczarniach-policja-szuka-sprawcy-st7947557?source=rss](https://tvn24.pl/krakow/tarnow-kot-postrzelony-z-wiatrowki-umieral-w-meczarniach-policja-szuka-sprawcy-st7947557?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T14:51:52+00:00

<img alt="Kot został postrzelony z wiatrówki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nqi02w-oprawcy-przecieli-kota-na-pol-zdjecie-ilustracyjne-1904033/alternates/LANDSCAPE_1280" />
    Policja szuka osoby, która w Tarnowie (woj. małopolskie) postrzeliła kota, doprowadzając do jego śmierci. Zwierzę miało ranę postrzałową i śrut w ciele. Nie udało się go uratować mimo kilku dni leczenia.

## 10-latka wyskoczyła przez balkon. Chciała tak skrócić sobie drogę na podwórko
 - [https://tvn24.pl/wroclaw/wroclaw-10-latka-wyskoczyla-przez-balkon-st7947556?source=rss](https://tvn24.pl/wroclaw/wroclaw-10-latka-wyskoczyla-przez-balkon-st7947556?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T14:45:03+00:00

<img alt="10-latka wyskoczyła przez balkon. Chciała tak skrócić sobie drogę na podwórko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k52pjx-dziecko-trafilo-do-szpitala-na-badania-ph7397309/alternates/LANDSCAPE_1280" />
    We Wrocławiu 10-latka spadła z balkonu na pierwszym piętrze. Dziewczynka z lekkimi obrażeniami ciała trafiła do szpitala, z którego została już wypisana do domu. Policja przekazała, że nie doszło do zaniedbania ze strony opiekunów.

## Młodo, młodziej, wybory. Plakat kontra rzeczywistość
 - [https://tvn24.pl/wybory-do-europarlamentu-2024/mlodo-mlodziej-wybory-fotografie-politykow-kontra-rzeczywistosc-st7946234?source=rss](https://tvn24.pl/wybory-do-europarlamentu-2024/mlodo-mlodziej-wybory-fotografie-politykow-kontra-rzeczywistosc-st7946234?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T14:40:24+00:00

<img alt="Młodo, młodziej, wybory. Plakat kontra rzeczywistość" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8fa962-plakaty-wyborcze-ph7947514/alternates/LANDSCAPE_1280" />
    Czoła - wygładzone. Zęby - jak perełki. Podkrążone oczy dzięki magii retuszu odzyskują blask, włosy opadają miękkimi falami na skronie i ramiona. Ale podkręcanie wyborczych zdjęć to broń obosieczna. Przesady wyborcy mogą nie wybaczyć. Choć mogą ją też całkowicie zignorować lub wykorzystać, by poniżyć osobę na plakacie. Czyli polityka, a najczęściej - polityczkę.

## Czym zajmują się eurodeputowani i jakie mają uprawnienia
 - [https://tvn24.pl/polska/czym-zajmuja-sie-eurodeputowani-i-jakie-maja-uprawnienia-st7947464?source=rss](https://tvn24.pl/polska/czym-zajmuja-sie-eurodeputowani-i-jakie-maja-uprawnienia-st7947464?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T14:38:32+00:00

<img alt="Czym zajmują się eurodeputowani i jakie mają uprawnienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fwvb40-parlament-europejski-europoslowie-pe-ph7947518/alternates/LANDSCAPE_1280" />
    Jakie będzie pierwsze ważne zadanie dla nowego Parlamentu Europejskiego po wyborach? Co leży w zakresie kompetencji europosłów? I czy deputowani chcieliby posiadać więcej uprawnień? O tym wszystkim opowiada reporter TVN24 Maciej Sokołowski.

## Najczęściej upadają te z największym stażem. "Sytuacja budownictwa nadal jest dość trudna"
 - [https://tvn24.pl/biznes/najnowsze/upadlosc-w-budowlance-w-2023-rogu-oglosilo-mniej-firm-niz-przed-rokiem-wzrosla-liczba-postepowan-restrukturyzacyjnych-budowlanka-probuje-przetrwac-st7947461?source=rss](https://tvn24.pl/biznes/najnowsze/upadlosc-w-budowlance-w-2023-rogu-oglosilo-mniej-firm-niz-przed-rokiem-wzrosla-liczba-postepowan-restrukturyzacyjnych-budowlanka-probuje-przetrwac-st7947461?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T14:13:20+00:00

<img alt="Najczęściej upadają te z największym stażem. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie44299f98d721c27336666abfa8f61a68-deloitte-budowlanka-powoli-wychodzi-z-kryzysu-3903678/alternates/LANDSCAPE_1280" />
    Budownictwo zakończyło miniony rok ze wzrostem liczby postępowań restrukturyzacyjnych aż o 170 proc. Zmalała za to liczba ogłoszonych upadłości. Największą część firm, które zakończyły swoją działalność w 2023 roku stanowiły te z najdłuższym rynkowym stażem, przekraczającym 20 lat.

## Nowe zasady rozliczania prosumentów. Opublikowano projekt
 - [https://tvn24.pl/biznes/z-kraju/fotowoltaika-rzad-zmienia-zasady-rozliczania-prosumentow-st7947517?source=rss](https://tvn24.pl/biznes/z-kraju/fotowoltaika-rzad-zmienia-zasady-rozliczania-prosumentow-st7947517?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T14:02:47+00:00

<img alt="Nowe zasady rozliczania prosumentów. Opublikowano projekt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ej8le-panele-sloneczne-pv-fotowoltaika-5118864/alternates/LANDSCAPE_1280" />
    Od lipca prosumenci, którzy rozliczają się w net-billingu, zyskają możliwość wybrania korzystniejszego dla nich systemu rozliczania wytwarzanej energii elektrycznej - wynika z projektu nowelizacji ustawy o OZE. Zapowiadane zmiany mają poprawić rentowność inwestycji w instalacje fotowoltaiczne.

## Samochód stanął w poprzek drogi. Duży korek na S8
 - [https://tvn24.pl/tvnwarszawa/najnowsze/s8-puchaly-zderzenie-korek-utrudnienia-na-s8-st7947484?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/s8-puchaly-zderzenie-korek-utrudnienia-na-s8-st7947484?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:56:02+00:00

<img alt="Samochód stanął w poprzek drogi. Duży korek na S8" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-xjxsrk-zderzenie-na-s8-ph7947504/alternates/LANDSCAPE_1280" />
    Na trasie S8 na wysokości miejscowości Puchały zderzyły się trzy samochody osobowe. Jeden stanął w poprzek drogi. Jedna osoba jest badana w karetce. Wyjeżdżający ze stolicy muszą liczyć się z utrudnieniami.

## Drzewo spadło na autobus. Są ranni
 - [https://tvn24.pl/katowice/zywiec-drzewo-spadlo-na-miejski-autobus-sa-ranni-st7947515?source=rss](https://tvn24.pl/katowice/zywiec-drzewo-spadlo-na-miejski-autobus-sa-ranni-st7947515?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:53:32+00:00

<img alt="Drzewo spadło na autobus. Są ranni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rl0lbp-drzewo-spadlo-na-autobus-w-zywcu-ph7947472/alternates/LANDSCAPE_1280" />
    Drzewo spadło we wtorek na autobus komunikacji miejskiej w Żywcu. Rannych zostało troje pasażerów.

## "Zaczęli dzwonić rano, że idzie woda, ale nie myślałam, że aż taka"
 - [https://tvn24.pl/tvnmeteo/polska/zaczeli-dzwonic-rano-ze-idzie-woda-ale-nie-myslalam-ze-az-taka-relacje-mieszkancow-zalanych-terenow-st7947443?source=rss](https://tvn24.pl/tvnmeteo/polska/zaczeli-dzwonic-rano-ze-idzie-woda-ale-nie-myslalam-ze-az-taka-relacje-mieszkancow-zalanych-terenow-st7947443?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:51:08+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6685mo-zalana-posesja-przy-ul-konwaliowej-w-bielsku-bialej-ph7947492/alternates/LANDSCAPE_1280" />
    Nieprzejezdne drogi i zalane posesje czy piwnice to rzeczywistość, w jakiej znaleźli się we wtorek rano mieszkańcy miejscowości w południowej Polsce po potężnych ulewach. - O trzeciej się obudziłem, popatrzyłem, leje mocno, ale rzeka nisko. Wstałem o wpół do piątej i już była woda - mówił mieszkaniec Bielska-Białej.

## Z kim konkuruje Daniel Obajtek? Pojedynek "jedynek" na Podkarpaciu
 - [https://tvn24.pl/wybory-do-europarlamentu-2024/wybory-do-europarlamentu-2024-kto-kandyduje-z-podkarpacia-oto-jedynki-z-okregu-nr-9-st7947091?source=rss](https://tvn24.pl/wybory-do-europarlamentu-2024/wybory-do-europarlamentu-2024-kto-kandyduje-z-podkarpacia-oto-jedynki-z-okregu-nr-9-st7947091?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:42:39+00:00

<img alt="Z kim konkuruje Daniel Obajtek? Pojedynek " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3g56d5-wybory-do-europarlamentu-2024-kto-kandyduje-z-podkarpacia-ph7947142/alternates/LANDSCAPE_1280" />
    W wyborach do Parlamentu Europejskiego o mandat z okręgu numer 9 walczy 69 kandydatów. Siedmiu zajmuje pierwsze miejsca na listach komitetów. "Jedynkami" są tu m.in. doświadczona europarlamentarzystka Elżbieta Łukacijewska i Daniel Obajtek, były prezes Orlenu, którego osoba jest związana z trzema toczącymi się obecnie śledztwami. Co warto wiedzieć o liderach list na Podkarpaciu?

## Jest wniosek o uchylenie immunitetu Jakubowi Iwańcowi. To sędzia kojarzony z aferą hejterską
 - [https://tvn24.pl/polska/jest-wniosek-o-uchylenie-immunitetu-jakubowi-iwancowi-to-sedzia-kojarzony-z-afera-hejterska%20-st7947482?source=rss](https://tvn24.pl/polska/jest-wniosek-o-uchylenie-immunitetu-jakubowi-iwancowi-to-sedzia-kojarzony-z-afera-hejterska%20-st7947482?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:42:22+00:00

<img alt="Jest wniosek o uchylenie immunitetu Jakubowi Iwańcowi. To sędzia kojarzony z aferą hejterską " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3wo39f-prokuratura-krajowa-w-warszawie-7902333/alternates/LANDSCAPE_1280" />
    Kielecka prokuratura skierowała wniosek do Izby Odpowiedzialności Zawodowej Sądu Najwyższego o uchylenie immunitetu sędziego Jakuba Iwańca z Sądu Rejonowego dla Warszawy-Mokotowa - poinformowała prokuratura. Podstawą wniosku jest materiał dowodowy wyłączony ze sprawy tzw. afery hejterskiej.

## "Polscy kibice 130 złotych za bilet, Ukraińcy za darmo"? Nieprawda
 - [https://konkret24.tvn24.pl/polska/polscy-kibice-130-zlotych-za-bilet-ukraincy-za-darmo-nieprawda-st7946855?source=rss](https://konkret24.tvn24.pl/polska/polscy-kibice-130-zlotych-za-bilet-ukraincy-za-darmo-nieprawda-st7946855?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:31:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7nxofc-polscy-kibice-130-zlotych-za-bilet-ukraincy-za-darmo-nieprawda-ph7947174/alternates/LANDSCAPE_1280" />
    Po meczu siatkarskim w Suwałkach pojawiły się informacje o rzekomym wpuszczaniu za darmo ukraińskich kibiców. Te doniesienia nie są prawdziwe, a ich celem jest antagonizowanie obu narodów.

## "Musimy 9 czerwca dokonać jeszcze raz tego wyboru, którego dokonaliśmy 35 lat temu"
 - [https://tvn24.pl/trojmiasto/gdansk-uroczystosc-35-rocznicy-wyborow-4-czerwca-1989-roku-st7947422?source=rss](https://tvn24.pl/trojmiasto/gdansk-uroczystosc-35-rocznicy-wyborow-4-czerwca-1989-roku-st7947422?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:17:41+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-env15c-uroczystosc-upamietnienia-35-rocznicy-wyborow-4-czerwca-1989-roku-w-gdansku-ph7947420/alternates/LANDSCAPE_1280" />
    - Musimy się zmobilizować i 9 czerwca dokonać jeszcze raz tego wyboru, którego dokonaliśmy 35 lat temu. Powtórzyć wybór za wolnością, samostanowieniem, wybór za mądrą, wolną, solidarną, lepszą, otwartą na innych Polską - mówił we wtorek w Gdańsku marszałek Sejmu Szymon Hołownia.

## Co zrobić ze skoszoną trawą? Za błąd grozi grzywna
 - [https://tvn24.pl/ciekawostki/co-zrobic-ze-skoszona-trawa-jak-mozna-ja-ponownie-wykorzystac-st7947351?source=rss](https://tvn24.pl/ciekawostki/co-zrobic-ze-skoszona-trawa-jak-mozna-ja-ponownie-wykorzystac-st7947351?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:04:22+00:00

<img alt="Co zrobić ze skoszoną trawą? Za błąd grozi grzywna" src="https://tvn24.pl/najnowsze/cdn-zdjecie-faa2t2-co-zrobic-ze-skoszona-trawa-jak-wykorzystac-ja-w-ogrodzie-ph7947356/alternates/LANDSCAPE_1280" />
    Sezon na koszenie trawników jest już w pełni i potrwa do jesieni. Co zrobić ze skoszoną trawą? Do czego można wykorzystać ją w ogrodzie? Wyjaśniamy.

## Bez pozwolenia trzymał węże, żółwie i jaszczurki
 - [https://tvn24.pl/krakow/krakow-chronione-gady-na-targach-zwierzat-egzotycznych-wystawca-zatrzymany-st7947367?source=rss](https://tvn24.pl/krakow/krakow-chronione-gady-na-targach-zwierzat-egzotycznych-wystawca-zatrzymany-st7947367?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:04:02+00:00

<img alt="Bez pozwolenia trzymał węże, żółwie i jaszczurki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-trwhix-egzotyczne-zwierzeta-znaleziono-na-stoisku-i-w-mieszkaniu-54-latka-ph7947360/alternates/LANDSCAPE_1280" />
    Dziesiątki zwierząt egzotycznych trzymał na stoisku i w mieszkaniu 54-latek, który ma wkrótce usłyszeć zarzuty nielegalnego posiadania gatunków zwierząt niebezpiecznych i podrabiania dokumentów. Mężczyzna został zatrzymany podczas targów branżowych, wystawiając żółwie i warany. W jego miejscu zamieszkania znaleziono między innymi martwego węża.

## Podczas prac uszkodzili koparką pojemnik z nieznaną substancją. "Z ziemi zaczął wydobywać się jasny dym"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/legionowo-stanislawow-pierwszy-tajemniczy-pojemnik-znalziony-podczas-prac-dym-akcja-strazy-i-grupy-chemicznej-st7947339?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/legionowo-stanislawow-pierwszy-tajemniczy-pojemnik-znalziony-podczas-prac-dym-akcja-strazy-i-grupy-chemicznej-st7947339?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T13:00:11+00:00

<img alt="Podczas prac uszkodzili koparką pojemnik z nieznaną substancją. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vhr1x3-akcja-strazy-pozarnej-w-miejscowosci-stanislawow-pierwszy-ph7947371/alternates/LANDSCAPE_1280" />
    Pod Legionowem podczas prac operator koparki uszkodził zakopany w ziemi pojemnik, który zaczął dymić. Pojemnik zasypano i przyjechała straż pożarna. Na miejsce jedzie grupa ratownictwa ekologiczno-chemicznego.

## Magda Łucyan Dziennikarką Roku Polskiego Stowarzyszenia Energetyki Wiatrowej
 - [https://tvn24.pl/polska/magda-lucyan-dziennikarka-roku-polskiego-stowarzyszenia-energetyki-wiatrowej-st7947253?source=rss](https://tvn24.pl/polska/magda-lucyan-dziennikarka-roku-polskiego-stowarzyszenia-energetyki-wiatrowej-st7947253?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:57:44+00:00

<img alt="Magda Łucyan Dziennikarką Roku Polskiego Stowarzyszenia Energetyki Wiatrowej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ckwi9g-magda-lucyan-ph7947272/alternates/LANDSCAPE_1280" />
    Dziennikarka "Faktów" TVN i TVN24 Magda Łucyan otrzymała we wtorek nagrodę Dziennikarki Roku Polskiego Stowarzyszenia Energetyki Wiatrowej.

## Zginęły babcia, córka i wnuczka. 22-letni kierowca z zarzutem
 - [https://tvn24.pl/lubuskie/kargowa-potracil-trzy-kobiety-uslyszal-zarzut-zginela-babcia-corka-i-wnuczka-st7946831?source=rss](https://tvn24.pl/lubuskie/kargowa-potracil-trzy-kobiety-uslyszal-zarzut-zginela-babcia-corka-i-wnuczka-st7946831?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:56:29+00:00

<img alt="Zginęły babcia, córka i wnuczka. 22-letni kierowca z zarzutem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j2mflz-w-poblizu-miejsca-zdarzenia-odbywac-sie-festyn-ph7944233/alternates/LANDSCAPE_1280" />
    Nawet osiem lat więzienia grozi kierowcy, który śmiertelnie potrącił trzy kobiety w Kargowej koło Zielonej Góry. Prokurator przesłuchał już 22-latka i przedstawił mu zarzut. Będzie też wniosek o areszt tymczasowy.

## Kolejne problemy rosyjskiego giganta gazowego
 - [https://tvn24.pl/biznes/najnowsze/rosyjski-gazprom-z-problemami-finansowymi-umowa-z-chinami-utknela-z-powodu-cen-st7947309?source=rss](https://tvn24.pl/biznes/najnowsze/rosyjski-gazprom-z-problemami-finansowymi-umowa-z-chinami-utknela-z-powodu-cen-st7947309?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:53:34+00:00

<img alt="Kolejne problemy rosyjskiego giganta gazowego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1rkuil-nord-stream-2-elena-krivorotova-shutterstock_1830876902-6858821/alternates/LANDSCAPE_1280" />
    Zawarcie umowy na zaopatrywanie Chin gazem z Rosji utknęło w impasie - donosi "Financial Times". Po jej zawarciu na chiński rynek docierałby gaz z pól gazowych na zachodzie Rosji, które przed wojną zaopatrywały stary kontynent. W związku z sankcjami nałożonymi na Rosję Gazprom poniósł w zeszłym roku stratę w wysokości 629 mld rubli (6,9 mld USD), największą od co najmniej ćwierć wieku.

## Uderzenie pioruna przyczyną paraliżu kolejowego
 - [https://tvn24.pl/poznan/uderzenie-pioruna-przyczyna-paralizu-kolejowego-st7947228?source=rss](https://tvn24.pl/poznan/uderzenie-pioruna-przyczyna-paralizu-kolejowego-st7947228?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:49:41+00:00

<img alt="Uderzenie pioruna przyczyną paraliżu kolejowego" src="https://tvn24.pl/poznan/cdn-zdjecie-h6xx4r-peron-na-poznaniu-glownym-6079607/alternates/LANDSCAPE_1280" />
    Koniec utrudnień na stacji kolejowej Poznań Główny. Polskie Koleje Państwowe zapewniają, że pociągi kursują zgodnie z rozkładem. - Wstępne ustalenia wskazują, że usterka urządzeń sterowania ruchem kolejowym wystąpiła po uderzeniu pioruna w element infrastruktury - tłumaczy Radosław Śledziński z biura prasowego PKP PLK.

## Głosy wciąż liczone, giełda już tonie. Zaskakujące wyniki wyborów w Indiach
 - [https://tvn24.pl/biznes/ze-swiata/wybory-w-indiach-zaskakujace-wyniki-indyjska-gielda-tonie-st7947304?source=rss](https://tvn24.pl/biznes/ze-swiata/wybory-w-indiach-zaskakujace-wyniki-indyjska-gielda-tonie-st7947304?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:49:13+00:00

<img alt="Głosy wciąż liczone, giełda już tonie. Zaskakujące wyniki wyborów w Indiach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jfv7cu-wyniki-wyborow-w-indiach-inne-od-exit-polls-ph7947241/alternates/LANDSCAPE_1280" />
    Koalicja indyjskiego premiera Narendry Modiego wygrywa w wyborach parlamentarnych, ale jej wynik jest znacznie słabszy od przewidywanego przez sondaże exit polls - informują lokalne media. Informacja, że partia Modiego może stracić samodzielną większość w parlamencie, wywołała ogromne spadki na indyjskiej giełdzie, choć liczenie głosów wciąż trwa.

## Stan żołnierza ranionego na granicy ciężki, ale stabilny. Wojsko apeluje o oddawanie krwi
 - [https://tvn24.pl/bialystok/granica-polsko-bialoruska-stan-zolnierza-ranionego-na-granicy-ciezki-ale-stabilny-wojsko-apeluje-o-oddawanie-krwi-st7947394?source=rss](https://tvn24.pl/bialystok/granica-polsko-bialoruska-stan-zolnierza-ranionego-na-granicy-ciezki-ale-stabilny-wojsko-apeluje-o-oddawanie-krwi-st7947394?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:45:19+00:00

<img alt="Stan żołnierza ranionego na granicy ciężki, ale stabilny. Wojsko apeluje o oddawanie krwi" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-ysj37o-incydenty-na-granicy-cyberataki-i-proby-dezinformacji-kreml-intensyfikuje-swoje-dzialania-7943500/alternates/LANDSCAPE_1280" />
    Stan przebywającego w szpitalu żołnierza, który przed tygodniem został raniony nożem przez migranta na granicy z Białorusią, jest ciężki ale stabilny. W związku z tym zdarzeniem, wojsko zaapelowało o udział w akcjach oddawania krwi.

## Luka VAT w Polsce. Ministerstwo podało najnowsze dane
 - [https://tvn24.pl/biznes/z-kraju/luka-vat-w-polsce-ministerstwo-podalo-najnowsze-dane-st7947101?source=rss](https://tvn24.pl/biznes/z-kraju/luka-vat-w-polsce-ministerstwo-podalo-najnowsze-dane-st7947101?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:39:44+00:00

<img alt="Luka VAT w Polsce. Ministerstwo podało najnowsze dane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tcsdd8-zaproponowal-policjantom-pieniadze-zdjecie-ilustracyjne-6896329/alternates/LANDSCAPE_1280" />
    Luka VAT w 2023 roku wzrosła do 15,8 procent - podał resort finansów w sprawozdaniu z wykonania budżetu państwa za poprzedni rok. W 2022 roku było to 7,3 procent.

## Ławrow w Afryce. Ma wzmocnić wpływy Moskwy na kontynencie
 - [https://tvn24.pl/swiat/gwinea-siergiej-lawrow-rozpoczal-podroz-po-afryce-chce-wzmocnic-wplywy-moskwy-na-kontynencie-st7946274?source=rss](https://tvn24.pl/swiat/gwinea-siergiej-lawrow-rozpoczal-podroz-po-afryce-chce-wzmocnic-wplywy-moskwy-na-kontynencie-st7946274?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:10:25+00:00

<img alt="Ławrow w Afryce. Ma wzmocnić wpływy Moskwy na kontynencie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5pmdlh-siergiej-lawrow-w-gwinei-ph7946273/alternates/LANDSCAPE_1280" />
    Szef rosyjskiej dyplomacji rozpoczął w poniedziałek afrykańską podróż. Na trasie Siergieja Ławrowa są wyłącznie kraje rządzone przez junty wojskowe.

## Puścił psa bez smyczy, ten spadł z wieży widokowej
 - [https://tvn24.pl/wroclaw/pieszyce-puscil-psa-bez-smyczy-ten-spadl-z-wiezy-widokowej-st7945807?source=rss](https://tvn24.pl/wroclaw/pieszyce-puscil-psa-bez-smyczy-ten-spadl-z-wiezy-widokowej-st7945807?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:08:55+00:00

<img alt="Puścił psa bez smyczy, ten spadł z wieży widokowej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-djeh4w-pies-spadl-z-wiezy-widokowej-w-sudetach-7945855/alternates/LANDSCAPE_1280" />
    Pies puszczony bez smyczy wbiegł po schodach wieży Wielka Sowa w Sudetach, po czym przeskoczył przez murek i spadł z dużej wysokości. Nie przeżył upadku. Opiekunowie atrakcji turystycznej zwrócili się z apelem do turystów o lepszą opiekę nad swoimi pupilami.

## Dalajlama uda się do USA. Chiny "zdecydowanie się sprzeciwiają"
 - [https://tvn24.pl/swiat/dalajlama-uda-sie-do-usa-chiny-zdecydowanie-sie-sprzeciwiaja-st7946279?source=rss](https://tvn24.pl/swiat/dalajlama-uda-sie-do-usa-chiny-zdecydowanie-sie-sprzeciwiaja-st7946279?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T12:03:04+00:00

<img alt="Dalajlama uda się do USA. Chiny " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tacae6-dalajlama-xiv-5430273/alternates/LANDSCAPE_1280" />
    Duchowy przywódca Tybetańczyków uda się w tym miesiącu do Stanów Zjednoczonych – poinformowało jego biuro. Dalajlama ma się tam poddać leczeniu kolan, a od 20 czerwca nie będzie odbywał publicznych wystąpień.

## Malował po zabytkowym budynku i sam się chwalił. Jest akt oskarżenia przeciwko Robertowi Bąkiewiczowi
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-malowal-po-zabytkowym-budynku-jest-akt-oskarzenia-przeciwko-robertowi-bakiewiczowi-st7947197?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-malowal-po-zabytkowym-budynku-jest-akt-oskarzenia-przeciwko-robertowi-bakiewiczowi-st7947197?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T11:49:18+00:00

<img alt="Malował po zabytkowym budynku i sam się chwalił. Jest akt oskarżenia przeciwko Robertowi Bąkiewiczowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l2gpet-robert-bakiewicz-pod-budynkiem-ministerstwa-klimatu-i-srodowiska-7741349/alternates/LANDSCAPE_1280" />
    Prokuratura Okręgowa w Warszawie poinformowała o skierowaniu do sądu aktu oskarżenia przeciwko Robertowi Bąkiewiczowi. Chodzi o sprawę z 26 stycznia, kiedy to polityk opublikował film, na którym maluje na zabytkowym budynku siedziby Ministerstwa Klimatu i Środowiska symbol Polski Walczącej.

## Dwie osoby poparzone podczas rozbierania auta
 - [https://tvn24.pl/poznan/poznan-dwie-osoby-poparzone-podczas-rozbierania-auta-st7947192?source=rss](https://tvn24.pl/poznan/poznan-dwie-osoby-poparzone-podczas-rozbierania-auta-st7947192?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T11:46:01+00:00

<img alt="Dwie osoby poparzone podczas rozbierania auta" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-jm7di3-mezczyzna-stracil-przytomnosc-trafil-do-szpitala-zdjecie-ilustracyjne-7770731/alternates/LANDSCAPE_1280" />
    Podczas rozbiórki auta z instalacją gazową doszło do wybuchu - przekazuje poznańska straż pożarna. Poszkodowane są dwie osoby. Przewieziono je do szpitala.

## Ciało noworodka zakopane na łące
 - [https://tvn24.pl/katowice/bielsko-biala-zwloki-noworodka-zakopane-na-lace-sledztwo-st7947169?source=rss](https://tvn24.pl/katowice/bielsko-biala-zwloki-noworodka-zakopane-na-lace-sledztwo-st7947169?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T11:28:03+00:00

<img alt="Ciało noworodka zakopane na łące" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m5qls1-cialo-noworodka-znalezione-w-sortowni-smieci-jedna-osoba-zatrzymana-zdjecie-ilustracyjne-7859309/alternates/LANDSCAPE_1280" />
    W Bielsku-Białej (Śląskie) odnaleziono zakopane na łące ciało noworodka. Śledztwo prowadzi policja pod nadzorem prokuratury. Śledczy nie informują na razie czy ktoś został w tej sprawie zatrzymany.

## Pół tysiąca mieszkań na Kabatach. W środku rynek. Deweloper zdradza plany
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-pol-tysiaca-mieszkan-rynek-kabacki-otoczony-gastronomia-deweloper-zdradza-plany-st7946563?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-pol-tysiaca-mieszkan-rynek-kabacki-otoczony-gastronomia-deweloper-zdradza-plany-st7946563?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T11:27:01+00:00

<img alt="Pół tysiąca mieszkań na Kabatach. W środku rynek. Deweloper zdradza plany" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ttr3ew-wizualizacja-osiedla-u-zbiegu-alei-ken-i-ul-wawozowej-ph7946821/alternates/LANDSCAPE_1280" />
    Właściciel działki po hipermarkecie na Kabatach poinformował, że chce w tym miejscu wybudować 500 mieszkań. Osiedle zaprojektowane przez pracownię WWAA ma być niegrodzone. Deweloper obiecuje też przestrzeń publiczną - nowy rynek.

## Park narodowy pod wodą, zamknięte atrakcje i szlaki
 - [https://tvn24.pl/krakow/ojcowski-park-narodowy-zamknal-szlaki-z-powodu-ulew-podtopienia-w-krakowie-i-malopolsce-st7947102?source=rss](https://tvn24.pl/krakow/ojcowski-park-narodowy-zamknal-szlaki-z-powodu-ulew-podtopienia-w-krakowie-i-malopolsce-st7947102?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T11:20:13+00:00

<img alt="Park narodowy pod wodą, zamknięte atrakcje i szlaki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c3xtlg-zalany-ojcowski-park-narodowy-ph7947084/alternates/LANDSCAPE_1280" />
    Władze Ojcowskiego Parku Narodowego zamknęły szlaki i atrakcje w związku z ulewą, która przechodzi przez Małopolskę. Okoliczne wioski zostały zalane - podobnie jak niektóre ulice w Krakowie i innych miejscowościach województwa.

## Bat na kierowców. 128 nowych urządzeń
 - [https://tvn24.pl/biznes/moto/nowe-kamery-i-fotoradary-na-drogach-krajowych-gitd-zapowiada-wielkie-zakupy-st7947109?source=rss](https://tvn24.pl/biznes/moto/nowe-kamery-i-fotoradary-na-drogach-krajowych-gitd-zapowiada-wielkie-zakupy-st7947109?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T11:20:10+00:00

<img alt="Bat na kierowców. 128 nowych urządzeń" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-x0296o-droga-ekspresowa-s12-7320127/alternates/LANDSCAPE_1280" />
    Główny Inspektorat Transportu Drogowego zapowiedział zakup około 128 urządzeń do namierzania wykroczeń drogowych. Na polskich drogach pojawią się nowe fotoradary, odcinkowe pomiary prędkości, a także kamery monitorujące przejazd na czerwonym świetle.

## Nowa platforma Max szykuje polski hit na debiut
 - [https://tvn24.pl/kultura-i-styl/wiemy-co-max-szykuje-na-debiut-w-polsce-st7945879?source=rss](https://tvn24.pl/kultura-i-styl/wiemy-co-max-szykuje-na-debiut-w-polsce-st7945879?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T11:18:50+00:00

<img alt="Nowa platforma Max szykuje polski hit na debiut " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1uwc9y-skazana-sezon-4-7945874/alternates/LANDSCAPE_1280" />
    Już 11 czerwca zadebiutuje w Polsce nowa platforma streamingowa Max. Na tę okazję przygotowana została wyjątkowa premiera. Tego samego dnia w serwisie pojawi się ostatni sezon hitowego polskiego serialu - czwarta odsłona "Skazanej" z Agatą Kuleszą w roli głównej.

## Zabójca pięcioletniego chłopca trafi do szpitala psychiatrycznego
 - [https://tvn24.pl/poznan/poznan-71-latek-dzgnal-nozem-5-latka%20sad-wydal-postanowienie-o-umorzeniu-st7947042?source=rss](https://tvn24.pl/poznan/poznan-71-latek-dzgnal-nozem-5-latka%20sad-wydal-postanowienie-o-umorzeniu-st7947042?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T11:16:12+00:00

<img alt="Zabójca pięcioletniego chłopca trafi do szpitala psychiatrycznego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y02d4c-zbyslaw-c-decyzja-sadu-trafi-do-aresztu-7400941/alternates/LANDSCAPE_1280" />
    Sąd zdecydował o przyszłości 71-latka, który śmiertelnie ranił nożem pięcioletniego Maurycego w Poznaniu. W opinii biegłych mężczyzna był niepoczytalny w chwili popełniania zabójstwa. Trafi do szpitala psychiatrycznego.

## Premier Francji przerwał wypowiedź polityczce swojej partii. "Telefon do przyjaciela"
 - [https://tvn24.pl/swiat/premier-francji-przerwal-wypowiedz-polityczce-swojej-partii-telefon-do-przyjaciela-st7946282?source=rss](https://tvn24.pl/swiat/premier-francji-przerwal-wypowiedz-polityczce-swojej-partii-telefon-do-przyjaciela-st7946282?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T11:15:00+00:00

<img alt="Premier Francji przerwał wypowiedź polityczce swojej partii. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tqlko1-gabriel-attal-i-valerie-hayer-ph7946281/alternates/LANDSCAPE_1280" />
    Premier Francji Gabriel Attal został oskarżony o próbę celowego przerwania wypowiedzi czołowej kandydatki swojej partii w wyborach do Parlamentu Europejskiego – nieoczekiwanie pojawił się na scenie, gdzie Valerie Hayer brała udział w debacie.

## Nie żyje czterech zakładników uprowadzonych przez Hamas. MSZ: dwóch z nich to polscy obywatele
 - [https://tvn24.pl/swiat/nie-zyje-czterech-zakladnikow-uprowadzonych-przez-hamas-msz-dwoch-z-nich-to-polscy-obywatele-st7946731?source=rss](https://tvn24.pl/swiat/nie-zyje-czterech-zakladnikow-uprowadzonych-przez-hamas-msz-dwoch-z-nich-to-polscy-obywatele-st7946731?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T10:50:50+00:00

<img alt="Nie żyje czterech zakładników uprowadzonych przez Hamas. MSZ: dwóch z nich to polscy obywatele " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jz0i6b-msz-ministerstwo-spraw-zagranicznych-7771733/alternates/LANDSCAPE_1280" />
    Dwóch z czterech kolejnych zabitych zakładników uprowadzonych przez Hamas to obywatele RP - wynika z informacji MSZ.

## Zbigniew Rau przed komisją śledczą. "Nie było żadnej afery wizowej"
 - [https://tvn24.pl/polska/byly-szef-msz-zbigniew-rau-przed-komisja-sledcza-nie-bylo-zadnej-afery-wizowej-st7946735?source=rss](https://tvn24.pl/polska/byly-szef-msz-zbigniew-rau-przed-komisja-sledcza-nie-bylo-zadnej-afery-wizowej-st7946735?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T10:27:26+00:00

<img alt="Zbigniew Rau przed komisją śledczą. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-oi05a-zbigniew-rau-ph7946787/alternates/LANDSCAPE_1280" />
    Były minister spraw zagranicznych Zbigniew Rau pojawił się we wtorek przed sejmową komisją śledczą do spraw afery wizowej. Oświadczył, że jego zdaniem nie było żadnej afery wizowej, a jedynie "kaskada kłamstw, fake newsów i pomówień". - Ja nie wiedziałem o aferze wizowej i nie uznaję takich sformułowań - stwierdził. Dodał, że był to "szereg nieprawidłowości kontrolowanych i zlikwidowanych zarówno przez służby, jak i ograny ścigania w sposób ostateczny".

## Tanie linie lotnicze zapłacą 150 milionów euro za nieuczciwe praktyki
 - [https://tvn24.pl/biznes/ze-swiata/hiszpania-150-mln-euro-kary-dla-linii-lotniczych-za-nieuczciwe-praktyki-zaplaca-min-ryanair-i-easyjet-st7946636?source=rss](https://tvn24.pl/biznes/ze-swiata/hiszpania-150-mln-euro-kary-dla-linii-lotniczych-za-nieuczciwe-praktyki-zaplaca-min-ryanair-i-easyjet-st7946636?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T10:20:56+00:00

<img alt="Tanie linie lotnicze zapłacą 150 milionów euro za nieuczciwe praktyki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-emxw90-samolot-pasazerski-shutterstock_2449126031-7928008/alternates/LANDSCAPE_1280" />
    Władze Hiszpanii nałożyły grzywnę na czterech przewoźników lotniczych za stosowanie nieuczciwych praktyk wobec pasażerów. Ukarane spółki, wśród których znalazły się między innymi linie Easyjet i Ryanair, zapłacą karę o łącznej wysokości ponad 150 milionów euro.

## Bez kasku i po alkoholu jechał z kolegą skradzionym quadem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/sokolow-podlaski-bez-kasku-i-po-alkoholu-jechal-z-kolega-skradzionym-quadem-st7946918?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/sokolow-podlaski-bez-kasku-i-po-alkoholu-jechal-z-kolega-skradzionym-quadem-st7946918?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T10:08:25+00:00

<img alt="Bez kasku i po alkoholu jechał z kolegą skradzionym quadem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-h7sa20-bez-kasku-i-po-alkoholu-jechal-z-kolega-skradzionym-quadem-zdjecie-ilustracyjne-ph7946933/alternates/LANDSCAPE_1280" />
    Policja z Sokołowa Podlaskiego zatrzymała dwóch 17-latków, którzy uderzyli quadem w znak drogowy. Kierujący nie miał założonego kasku i był po spożyciu alkoholu. Jak się okazało pojazd nie należał do nich.

## Dwie bójki i podpalenie aut. Policja szuka świadków
 - [https://tvn24.pl/wroclaw/siechnice-dwie-bojki-odwet-i-podpalenie-samochodow-policja-szuka-swiadkow-st7946511?source=rss](https://tvn24.pl/wroclaw/siechnice-dwie-bojki-odwet-i-podpalenie-samochodow-policja-szuka-swiadkow-st7946511?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T10:02:45+00:00

<img alt="Dwie bójki i podpalenie aut. Policja szuka świadków " src="https://tvn24.pl/najnowsze/cdn-zdjecie-it6vna-bojka-i-podpalenie-samochodow-w-centrum-siechnic-ph7946852/alternates/LANDSCAPE_1280" />
    Najpierw Gruzini pobili Polaków, później Polacy napadli na Gruzinów. Doszło też do podpalenia samochodów na jednym z parkingów w Siechnicach. Jak ustaliła policja, te spawy mogą być powiązane.

## Aktor skazany na więzienie
 - [https://tvn24.pl/olsztyn/olecko-sad-skazal-aktora-na-kare-bezwzglednego-wiezienia-st7946782?source=rss](https://tvn24.pl/olsztyn/olecko-sad-skazal-aktora-na-kare-bezwzglednego-wiezienia-st7946782?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T09:58:35+00:00

<img alt="Aktor skazany na więzienie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r5qwkv-rafal-i-podczas-procesu-w-2023-roku-ph7946765/alternates/LANDSCAPE_1280" />
    Sąd Rejonowy w Olecku (województwo warmińsko-mazurskie) skazał aktora Rafała I. na karę bezwzględnego pozbawienia wolności. Jeśli wyrok by się uprawomocnił, mężczyzna spędzi półtora roku w zakładzie karnym.

## Zderzenie z łosiem na trasie ekspresowej. Kierowca ciężko ranny
 - [https://tvn24.pl/tvnwarszawa/ulice/niegow-s8-zderzenie-auta-z-losiem-kierowca-ranny-st7946783?source=rss](https://tvn24.pl/tvnwarszawa/ulice/niegow-s8-zderzenie-auta-z-losiem-kierowca-ranny-st7946783?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T09:46:27+00:00

<img alt="Zderzenie z łosiem na trasie ekspresowej. Kierowca ciężko ranny" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-tjoxri-zderzenie-samochodu-z-losiem-na-trasie-ekspresowej-ph7946786/alternates/LANDSCAPE_1280" />
    W nocy z poniedziałku na wtorek kierowca audi wjechał w łosia na trasie S8 w Niegowie (Mazowieckie). Rannego mężczyznę uwalniali z wraku strażacy. W stanie ciężkim został przetransportowany śmigłowcem do szpitala.

## Poszukiwany pasażer i "żwirek dla kota"
 - [https://tvn24.pl/lodz/pabianice-policjantom-tlumaczyl-ze-narkotyki-to-zwirek-dla-jego-kota-st7946839?source=rss](https://tvn24.pl/lodz/pabianice-policjantom-tlumaczyl-ze-narkotyki-to-zwirek-dla-jego-kota-st7946839?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T09:40:11+00:00

<img alt="Poszukiwany pasażer i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6z1l0k-do-zdarzenia-doszlo-w-pabianicach-ph7946401/alternates/LANDSCAPE_1280" />
    Policjanci z Pabianic (Łódzkie) zatrzymali 24-latka i 33-latka, którzy urządzili sobie nocną przejażdżkę skuterem ulicami miasta, będąc pod wpływem alkoholu. Jeden z mężczyzn miał też przy sobie metamfetaminę. Twierdził, że to żwirek dla kota.

## Wizerunek Toma Cruise'a w rosyjskiej propagandzie. "Ma wzbudzić strach"
 - [https://tvn24.pl/swiat/igrzyska-olimpijskie-tom-cruise-wykorzystany-w-propagandzie-rosjan-st7946611?source=rss](https://tvn24.pl/swiat/igrzyska-olimpijskie-tom-cruise-wykorzystany-w-propagandzie-rosjan-st7946611?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T09:32:48+00:00

<img alt="Wizerunek Toma Cruise'a w rosyjskiej propagandzie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ky7nxg-tom-cruise-ph7946406/alternates/LANDSCAPE_1280" />
    Rosja nasila kampanię dezinformacyjną przeciwko Międzynarodowemu Komitetowi Olimpijskiemu i tegorocznym igrzyskom olimpijskim w Paryżu - przestrzega najnowszy raport Microsoft. W tym celu powstał m.in. zawierający fałszerstwa film dokumentalny, wykorzystujący wizerunek Toma Cruise'a.

## Kamiński, Wcisło, Piotrowski. Kim są "jedynki" na listach w województwie lubelskim
 - [https://tvn24.pl/wybory-do-europarlamentu-2024/wybory-do-europarlamentu-2024-kto-kandyduje-w-wojewodztwie-lubelskim-kim-sa-jedynki-w-okregu-nr-8-st7939658?source=rss](https://tvn24.pl/wybory-do-europarlamentu-2024/wybory-do-europarlamentu-2024-kto-kandyduje-w-wojewodztwie-lubelskim-kim-sa-jedynki-w-okregu-nr-8-st7939658?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T09:32:06+00:00

<img alt="Kamiński, Wcisło, Piotrowski. Kim są " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kc4r5o-eurowybory-2024-okreg-lodzki-kaminski-wcislo-piotrowski-7945664/alternates/LANDSCAPE_1280" />
    Wybory do europarlamentu już w niedzielę. W okręgu numer osiem "jedynkami" są zarówno politycy znani w całej Polsce, jak i lokalni samorządowcy. Główny pojedynek ma się rozegrać między Martą Wcisło z KO a Mariuszem Kamińskim z PiS. Ale łódzkie może prawdopodobnie liczyć na trzy mandaty. Kogo jeszcze znajdziemy na szczytach list do czerwcowych wyborów europejskich?

## Dodatkowa, płatna opieka pielęgnacyjna w szpitalu. Interweniował rzecznik praw pacjenta
 - [https://tvn24.pl/kujawsko-pomorskie/torun-szpital-wywiesil-ogloszenie-o-platnej-opiece-pielegnacyjnej-jest-kontrola-st7946626?source=rss](https://tvn24.pl/kujawsko-pomorskie/torun-szpital-wywiesil-ogloszenie-o-platnej-opiece-pielegnacyjnej-jest-kontrola-st7946626?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T09:09:29+00:00

<img alt="Dodatkowa, płatna opieka pielęgnacyjna w szpitalu. Interweniował rzecznik praw pacjenta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-afb1eh-szpital-miejski-w-toruniu-4753965/alternates/LANDSCAPE_1280" />
    Na korytarzach szpitala miejskiego w Toruniu pojawiły się ogłoszenie dotyczące świadczenia dodatkowej, odpłatnej opieki pielęgniarskiej. Interweniowali prezydent miasta oraz rzecznik praw pacjenta.

## Nie żyje Janusz Rewiński. "Buenas noches, Senior Siarra!"
 - [https://tvn24.pl/kultura-i-styl/janusz-rewinski-nie-zyje-aktor-mial-74-lata-st7946770?source=rss](https://tvn24.pl/kultura-i-styl/janusz-rewinski-nie-zyje-aktor-mial-74-lata-st7946770?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T09:06:36+00:00

<img alt="Nie żyje Janusz Rewiński. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-csv8gi-janusz-rewinski-ph7946750/alternates/LANDSCAPE_1280" />
    Nie żyje Janusz Rewiński. Ceniony aktor, satyryk i były poseł na Sejm miał 74 lata. "Teraz świat jest jakby taki sam, ale uśmiechu nagle zabrakło" - napisali jego synowie.

## Alert RCB wysłany do odbiorców w części województwa mazowieckiego
 - [https://tvn24.pl/tvnmeteo/polska/alert-rcb-wyslany-do-odbiorcow-w-czesci-wojewodztwa-mazowieckiego-st7946676?source=rss](https://tvn24.pl/tvnmeteo/polska/alert-rcb-wyslany-do-odbiorcow-w-czesci-wojewodztwa-mazowieckiego-st7946676?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T09:05:53+00:00

<img alt="Alert RCB wysłany do odbiorców w części województwa mazowieckiego" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dc1q7v-rcb-ph7946711/alternates/LANDSCAPE_1280" />
    Alert RCB otrzymały we wtorek osoby przebywające na terenie kilku powiatów województwa mazowieckiego. Służby ostrzegają przed burzami, ulewnym deszczem i silnym wiatrem. Alert RCB wciąż obowiązuje też w pięciu innych województwach.

## To najdroższa krowa na świecie. Cena zwala z nóg
 - [https://tvn24.pl/biznes/ze-swiata/brazylia-najdrozsza-krowa-swiata-sprzedana-za-42-miliony-dolarow-st7946700?source=rss](https://tvn24.pl/biznes/ze-swiata/brazylia-najdrozsza-krowa-swiata-sprzedana-za-42-miliony-dolarow-st7946700?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T09:05:09+00:00

<img alt="To najdroższa krowa na świecie. Cena zwala z nóg" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ske33t-en_01622218_0983-1-ph7946759/alternates/LANDSCAPE_1280" />
    Śnieżnobiała krowa Viatina-19 została sprzedana na aukcji za 4,2 miliony dolarów. Ważąca ponad 1100 kilogramów, czyli dwa razy tyle co przeciętny osobnik tej rasy, jest najdroższą krową na świecie - poinformowała we wtorek agencja Associated Press.

## "Warto było zacisnąć zęby". Marcin Dorociński u boku światowych sław
 - [https://tvn24.pl/kultura-i-styl/mayday-marcin-dorocinski-w-filmie-u-boku-swiatowych-slaw-opublikowal-nagranie-st7946565?source=rss](https://tvn24.pl/kultura-i-styl/mayday-marcin-dorocinski-w-filmie-u-boku-swiatowych-slaw-opublikowal-nagranie-st7946565?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:51:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ra0per-marcin-dorocinski-ph7946590/alternates/LANDSCAPE_1280" />
    Marcin Dorociński zakończył pracę na planie filmu "Mayday", w którym występuje obok takich gwiazd jak Ryan Reynolds, czy Kenneth Branagh. - Możecie w to uwierzyć? - pyta aktor w nagraniu w mediach społecznościowych. Co wiemy o nowej produkcji z udziałem Dorocińskiego?

## Płomienie buchały na kilka metrów. Strażnicy zadziałali jak strażacy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-straznicy-jak-strazacy-ugasili-pozar-na-dzialkach-st7946575?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-straznicy-jak-strazacy-ugasili-pozar-na-dzialkach-st7946575?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:50:18+00:00

<img alt="Płomienie buchały na kilka metrów. Strażnicy zadziałali jak strażacy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-rjwgti-straznicy-miejscy-i-policjanci-gasili-pozar-na-dzialkach-ph7946578/alternates/LANDSCAPE_1280" />
    Do nietypowej akcji gaśniczej doszło w ogródkach działkowych przy stacji Reduta Ordona. Pożar, który mógł rozprzestrzenić się w stronę węzła kolejowego, gasili strażnicy miejscy i policjanci.

## Pod pozorem pracy lub zaproszeń sprowadzili ponad dwa tysiące osób z Ukrainy i Białorusi
 - [https://tvn24.pl/lodz/lodz-warszawa-bialystok-granice-moglo-nielegalnie-przekroczyc-co-najmniej-dwa-tysiace-osob-zarzuty-dla-obywatela-bialorusi-st7946697?source=rss](https://tvn24.pl/lodz/lodz-warszawa-bialystok-granice-moglo-nielegalnie-przekroczyc-co-najmniej-dwa-tysiace-osob-zarzuty-dla-obywatela-bialorusi-st7946697?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:49:13+00:00

<img alt="Pod pozorem pracy lub zaproszeń sprowadzili ponad dwa tysiące osób z Ukrainy i Białorusi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hhjy8r-26-letni-obywatel-bialorusi-uslyszal-zarzuty-ph7946684/alternates/LANDSCAPE_1280" />
    26-letni obywatel Białorusi odpowie za kierowanie grupą przestępczą, organizującą cudzoziemcom - głównie obywatelom Białorusi i Ukrainy - możliwość nielegalnego przekroczenia granicy Polski. Mężczyznę zatrzymali w Warszawie funkcjonariusze Straży Granicznej na polecenie łódzkiej prokuratury.

## Dwa śledztwa w sprawie nieprawidłowości w podkomisji smoleńskiej
 - [https://tvn24.pl/polska/podkomisja-smolenska-dwa-sledztwa-czego-dotycza-st7946681?source=rss](https://tvn24.pl/polska/podkomisja-smolenska-dwa-sledztwa-czego-dotycza-st7946681?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:46:10+00:00

<img alt="Dwa śledztwa w sprawie nieprawidłowości w podkomisji smoleńskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5k13po-antoni-macierewicz-ph7928490/alternates/LANDSCAPE_1280" />
    Prokuratura poinformowała o wszczęciu dwóch śledztw w związku z nieprawidłowościami w funkcjonowaniu byłej Podkomisji do Ponownego Zbadania Wypadku Lotniczego w Smoleńsku.

## "Dostawca wszystkiego" za PiS i fundacja. "Weź, załatw ją w końcu"
 - [https://tvn24.pl/biznes/najnowsze/fundacja-red-is-bad-sledztwo-cba-w-sprawie-lapowki-za-jej-zamkniecie-st7946444?source=rss](https://tvn24.pl/biznes/najnowsze/fundacja-red-is-bad-sledztwo-cba-w-sprawie-lapowki-za-jej-zamkniecie-st7946444?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:43:27+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l8fe1k-pap_20240603_11c-ph7946680/alternates/LANDSCAPE_1280" />
    Środki pozyskane przez fundację Red is Bad, mającą wspierać powstańców warszawskich, Paweł Szopa wykorzystywał do prywatnych celów - wynika z ustaleń Centralnego Biura Antykorupcyjnego, na które powołuje się Onet. Według służb, aby przed wyborami parlamentarnymi fundację wyrejestrować z Krajowego Rejestru Sądowego bez konieczności składania sprawozdań finansowych, Szopa gotów był zapłacić nawet 2,5 miliona złotych łapówki.

## "Gazeta Wyborcza": tak Fundusz Sprawiedliwości kupował głosy dla wiceministra
 - [https://tvn24.pl/polska/fundusz-sprawiedliwosci-nowe-doniesienia-gazeta-wyborcza-tak-kupowano-glosy-dla-wiceministra-marcina-romanowskiego-st7946530?source=rss](https://tvn24.pl/polska/fundusz-sprawiedliwosci-nowe-doniesienia-gazeta-wyborcza-tak-kupowano-glosy-dla-wiceministra-marcina-romanowskiego-st7946530?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:39:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m7psmq-marcin-romanowski-posel-7937817/alternates/LANDSCAPE_1280" />
    "Efekt Funduszu Sprawiedliwości nie zadziałał" - brzmi wniosek z wewnętrznej analizy ekspertów Funduszu, którego fragmenty opublikowała we wtorek "Gazeta Wyborcza". Wynika z nich, że celowo wydano z niego ponad osiem milionów złotych w gminach, gdzie podczas wyborów parlamentarnych w 2019 roku nieskutecznie startował odpowiedzialny za Fundusz wiceminister sprawiedliwości Marcin Romanowski.

## Chroniony koralowiec w bagażniku auta
 - [https://tvn24.pl/rzeszow/korczowa-chroniony-koralowiec-w-bagazniku-ukrainki-st7946612?source=rss](https://tvn24.pl/rzeszow/korczowa-chroniony-koralowiec-w-bagazniku-ukrainki-st7946612?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:30:46+00:00

<img alt="Chroniony koralowiec w bagażniku auta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xi1jcd-celnicy-udaremnili-przemyt-koralowca-ph7946456/alternates/LANDSCAPE_1280" />
    W samochodzie przekraczającej ukraińsko-polską granicę kobiety celnicy znaleźli okaz chronionego koralowca. Nielegalny przewóz przez granicę gatunków zagrożonych wyginięciem jest przestępstwem zagrożonym karą od trzech miesięcy do pięciu lat pozbawienia wolności.

## PiS zmieni nazwę? Tusk: przy wypowiadaniu starej nawet liderzy krztuszą się ponoć od śmiechu
 - [https://tvn24.pl/polska/pis-zmieni-nazwe-donald-tusk-komentuje-doniesienia-medialne-st7946657?source=rss](https://tvn24.pl/polska/pis-zmieni-nazwe-donald-tusk-komentuje-doniesienia-medialne-st7946657?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:22:10+00:00

<img alt="PiS zmieni nazwę? Tusk: przy wypowiadaniu starej nawet liderzy krztuszą się ponoć od śmiechu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-exqonx-prezes-pis-jaroslaw-kaczynski-podczas-spotkania-z-mieszkancami-w-siedzibie-szkoly-podstawowej-w-klwatce-krolewskiej-ph7946674/alternates/LANDSCAPE_1280" />
    Premier Donald Tusk skomentował we wtorek doniesienia medialne o tym, że kierownictwo Prawa i Sprawiedliwości rozważa zmianę nazwy ugrupowania. "Przy wypowiadaniu starej nawet liderzy krztuszą się ponoć od śmiechu" - napisał szef rządu.

## Uderzył w drzewo, czworo dzieci w szpitalu
 - [https://tvn24.pl/kujawsko-pomorskie/brzesc-kierowca-uderzyl-w-drzewo-czworo-dzieci-w-szpitalu-strazacy-musieli-rozcinac-pojazd-st7946583?source=rss](https://tvn24.pl/kujawsko-pomorskie/brzesc-kierowca-uderzyl-w-drzewo-czworo-dzieci-w-szpitalu-strazacy-musieli-rozcinac-pojazd-st7946583?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:11:24+00:00

<img alt="Uderzył w drzewo, czworo dzieci w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2vh5h7-kierowca-busa-uderzyl-w-drzewo-ph7946582/alternates/LANDSCAPE_1280" />
    Kierowca samochodu osobowego z niewyjaśnionych przyczyn uderzył w drzewo. W pojeździe znajdowało się pięć osób, w tym czworo dzieci. Wszyscy trafili do szpitala.

## Pensjonariuszka domu opieki uznana za zmarłą. W domu pogrzebowym okazało się, że oddycha
 - [https://tvn24.pl/swiat/usa-74-latke-uznano-za-zmarla-pracownik-domu-pogrzebowego-zauwazyl-ze-oddycha-st7946391?source=rss](https://tvn24.pl/swiat/usa-74-latke-uznano-za-zmarla-pracownik-domu-pogrzebowego-zauwazyl-ze-oddycha-st7946391?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:04:44+00:00

<img alt="Pensjonariuszka domu opieki uznana za zmarłą. W domu pogrzebowym okazało się, że oddycha" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eg9q1c-trumna-zdjecie-ilustracyjne-6276481/alternates/LANDSCAPE_1280" />
    Kobieta uznana za zmarłą trafiła do domu pogrzebowego, gdzie okazało się, że żyje. 74-letnia Amerykanka została przewieziona do szpitala. - To bardzo nietypowy przypadek - powiedział przedstawiciel służb, informując o dochodzeniu w sprawie.

## Włamał się do hostelu. Zabrał łupy, zostawił swoje dokumenty
 - [https://tvn24.pl/trojmiasto/gdansk-wlamal-sie-do-hostelu-i-zostawil-swoje-dokumenty-st7946557?source=rss](https://tvn24.pl/trojmiasto/gdansk-wlamal-sie-do-hostelu-i-zostawil-swoje-dokumenty-st7946557?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:03:00+00:00

<img alt="Włamał się do hostelu. Zabrał łupy, zostawił swoje dokumenty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9mh4dy-wlamywacz-zlodziej-zdj-ilustracyjne-ph7946574/alternates/LANDSCAPE_1280" />
    Gdańscy policjanci zatrzymali mężczyznę, który włamał się do jednego z hosteli. 42-latek ukradł 19 butelek alkoholu i elektronarzędzia. Podczas sprzątania właściciel hostelu znalazł dokumenty włamywacza.

## Izraelska armia potwierdziła śmierć czterech kolejnych zakładników
 - [https://tvn24.pl/swiat/izrael-armia-potwierdzila-smierc-czterech-kolejnych-zakladnikow-st7946268?source=rss](https://tvn24.pl/swiat/izrael-armia-potwierdzila-smierc-czterech-kolejnych-zakladnikow-st7946268?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T08:00:36+00:00

<img alt="Izraelska armia potwierdziła śmierć czterech kolejnych zakładników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-56c3u9-izraelska-armia-potwierdzila-smierc-czterech-kolejnych-zakladnikow-ph7946265/alternates/LANDSCAPE_1280" />
    Izraelskie wojsko poinformowało, że kolejnych czterech izraelskich zakładników uprowadzonych przez Hamas 7 października 2023 roku zmarło w niewoli, a ich ciała są przetrzymywane przez palestyńską grupę.

## Australijska armia przyjmie rekrutów z innych krajów. Muszą jednak spełnić kilka warunków
 - [https://tvn24.pl/swiat/australia-armia-przyjmie-mieszkajacych-w-australii-rekrutow-z-innych-krajow-st7946591?source=rss](https://tvn24.pl/swiat/australia-armia-przyjmie-mieszkajacych-w-australii-rekrutow-z-innych-krajow-st7946591?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T07:50:05+00:00

<img alt="Australijska armia przyjmie rekrutów z innych krajów. Muszą jednak spełnić kilka warunków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kry41r-armia-australijska-ph7946659/alternates/LANDSCAPE_1280" />
    Zmagająca się z niedoborami rekrutów australijska armia zamierza przyjmować w swoje szeregi kandydatów do służby z innych krajów - informuje BBC. Według planu, ogłoszonego 4 lipca przez australijski rząd, ma to dotyczyć obywateli czterech państw.

## Sonda Chang'e-6 wraca z "ciemnej strony" Księżyca
 - [https://tvn24.pl/tvnmeteo/nauka/sonda-change-6-wraca-z-ciemnej-strony-ksiezyca-st7946301?source=rss](https://tvn24.pl/tvnmeteo/nauka/sonda-change-6-wraca-z-ciemnej-strony-ksiezyca-st7946301?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T07:44:29+00:00

<img alt="Sonda Chang'e-6 wraca z " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-4kpasp-sonda-ph7946322/alternates/LANDSCAPE_1280" />
    Chińska sonda Chang'e-6 wystartowała z niewidocznej strony Księżyca i rozpoczęła podróż powrotną na Ziemię - poinformowała we wtorek Chińska Narodowa Agencja Kosmiczna.

## Młody daniel wszedł do bunkra i tam utknął
 - [https://tvn24.pl/lubuskie/swiebodzin-uwieziony-w-bunkrze-daniel-pomogli-policjanci-st7946485?source=rss](https://tvn24.pl/lubuskie/swiebodzin-uwieziony-w-bunkrze-daniel-pomogli-policjanci-st7946485?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T07:40:00+00:00

<img alt="Młody daniel wszedł do bunkra i tam utknął" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yqpdlb-zwierze-bylo-wycienczone-ph7946497/alternates/LANDSCAPE_1280" />
    Nietypowa akcja ratunkowa w bunkrze w Świebodzinie (Lubuskie). Turyści, którzy zwiedzali w Świebodzinie bunkry usłyszeli dziwne piski dobiegające z dołu. Podejrzewali, że dwa piętra niżej może być uwięzione jakieś zwierzę. O pomoc poprosili policję.

## Odnaleźli neony z pawilonu Cepelii. "Nikt się nie spodziewał, że przetrwały"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-odnalezli-neony-z-pawilonu-cepelii-trafily-do-muzeum-neonow-st7946259?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-odnalezli-neony-z-pawilonu-cepelii-trafily-do-muzeum-neonow-st7946259?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T07:28:53+00:00

<img alt="Odnaleźli neony z pawilonu Cepelii. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qclmx1-neony-odnalezione-podczas-remontu-pawilonu-cepelii-ph7942283/alternates/LANDSCAPE_1280" />
    Podczas prac porządkowych, które poprzedzały odbudowę pawilonu Cepelii, odnaleziono neony. Charakterystyczny kogucik oraz dwa napisy "Cepelia" trafiły już pod opiekę praskiego Muzeum Neonów. Jeszcze w czerwcu mają trafić na ekspozycję.

## Politolog: te wybory to "być albo nie być" dla Roberta Biedronia jako jednego z liderów Lewicy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wybory-do-parlamentu-europejskiego-okregi-4-i-5-ocena-politologa-st7946534?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wybory-do-parlamentu-europejskiego-okregi-4-i-5-ocena-politologa-st7946534?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T07:28:32+00:00

<img alt="Politolog: te wybory to " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-lhlec5-robert-biedron-ph7946551/alternates/LANDSCAPE_1280" />
    Wybory do Parlamentu Europejskiego, także na Mazowszu, mają większe znaczenie dla formacji średniej wielkości: Trzeciej Drogi, Lewicy i Konfederacji niż dla PiS i PO - uważa politolog prof. Rafał Chwedoruk. Jak zaznacza, ponowne uzyskanie mandatu eurodeputowanego to "być albo nie być" dla Roberta Biedronia jako jednego z liderów Lewicy.

## "Sytuacja jest bardzo poważna, brakuje kilku centymetrów do stanu alarmowego"
 - [https://tvn24.pl/katowice/bielsko-biala-prezydent-miasta-o-sytuacji-po-przejsciu-ulewy-brakuje-kilku-centymetrow-do-przekroczenia-stanu-alarmowego-st7946540?source=rss](https://tvn24.pl/katowice/bielsko-biala-prezydent-miasta-o-sytuacji-po-przejsciu-ulewy-brakuje-kilku-centymetrow-do-przekroczenia-stanu-alarmowego-st7946540?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T07:15:20+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-4efejj-ulica-pck-ph7946472/alternates/LANDSCAPE_1280" />
    W Bielsku-Białej (Śląskie) trwa sztab kryzysowy po tym jak przez miasto we wtorek rano przeszły gwałtowne ulewy. W ciągu sześciu godzin spadły tam 92 litry wody na metr kwadratowy. W wielu miejscach nieprzejezdne są ulice, zalane posesje, piwnice i samochody. - Sytuacja jest bardzo poważna, w tej chwili brakuje kilku centymetrów do stanu alarmowego na rzece Białej - mówił na antenie TVN24 prezydent miasta Jarosław Klimaszewski. Zaapelował też do mieszkańców o nieopuszczanie domów bez potrzeby.

## Prezydent: O sprawie firmy Red is Bad dowiedziałem się wczoraj z mediów. Zdarza mi się nosić ich ubrania
 - [https://tvn24.pl/polska/sprawa-red-is-bad-prezydent-andrzej-duda-zdarza-mi-sie-nosic-ubrania-tej-firmy-st7946484?source=rss](https://tvn24.pl/polska/sprawa-red-is-bad-prezydent-andrzej-duda-zdarza-mi-sie-nosic-ubrania-tej-firmy-st7946484?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T07:04:04+00:00

<img alt="Prezydent: O sprawie firmy Red is Bad dowiedziałem się wczoraj z mediów. Zdarza mi się nosić ich ubrania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-az1uf4-andrzej-duda-w-salonie-red-is-bad-lipiec-2021-r-ph7946523/alternates/LANDSCAPE_1280" />
    Mój jedyny kontakt z firmą Red is Bad to było noszenie ich odzieży, którą mam w swojej szafie. Tak, nie ukrywam tego - oświadczył prezydent Andrzej Duda. Dopytywany w RMF FM o doniesienia w sprawie firmy, przyznał, że dowiedział się "o tej sytuacji wczoraj z mediów".

## Chłopiec ze śladami poparzeń trafił do szpitala. Rodzice zatrzymani
 - [https://tvn24.pl/szczecin/karlino-chlopiec-ze-sladami-poparzen-trafil-do-szpitala-st7946487?source=rss](https://tvn24.pl/szczecin/karlino-chlopiec-ze-sladami-poparzen-trafil-do-szpitala-st7946487?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T07:00:28+00:00

<img alt="Chłopiec ze śladami poparzeń trafił do szpitala. Rodzice zatrzymani" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t2pqjn-czteromiesieczna-nadia-ze-sladami-znecania-trafila-do-szpitala-w-rzeszowie-7734772/alternates/LANDSCAPE_1280" />
    Policjanci z Białogardu zostali wezwani do awantury domowej w Karlinie (Zachodniopomorskie). Na miejscu zauważyli, że półtoraroczny chłopiec ma ślady poparzeń. Wezwali pogotowie ratunkowe. Rodzice dziecka zostali zatrzymani, sprawą zajmuje się prokuratura.

## "Obajtek gra na nosie samemu sobie". Szczerba: jeśli się nie stawi, będzie wniosek o zatrzymanie
 - [https://tvn24.pl/polska/daniel-obajtek-wezwany-przed-komisje-michal-szczerba-jesli-sie-nie-stawi-bedzie-wniosek-o-zatrzymanie-i-doprowadzenie-st7946387?source=rss](https://tvn24.pl/polska/daniel-obajtek-wezwany-przed-komisje-michal-szczerba-jesli-sie-nie-stawi-bedzie-wniosek-o-zatrzymanie-i-doprowadzenie-st7946387?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T06:56:45+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9g8ncl-daniel-obajtek-7939565/alternates/LANDSCAPE_1280" />
    Jeżeli jutro Daniel Obajtek nie pojawi się o godzinie 15.00 na posiedzeniu komisji, będzie wniosek nie tylko o ukaranie finansowe, ale przede wszystkim o zatrzymanie go i doprowadzenie - zapowiedział we wtorek szef sejmowej komisji śledczej do spraw afery wizowej Michał Szczerba. Jak dodał, "Obajtek gra na nosie samemu sobie, a przede wszystkim ostentacyjnie lekceważy instytucje państwa".

## Po "żarcie" na lotnisku nie poleciał na wakacje do Turcji
 - [https://tvn24.pl/wroclaw/wroclaw-zazartowal-na-lotnisku-ze-ma-granat-nie-polecial-na-wakacje-st7946378?source=rss](https://tvn24.pl/wroclaw/wroclaw-zazartowal-na-lotnisku-ze-ma-granat-nie-polecial-na-wakacje-st7946378?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T06:55:52+00:00

<img alt="Po " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zatk6a-lotnisko-wroclaw-5009594/alternates/LANDSCAPE_1280" />
    "Żart" 42-latka podczas oddawania bagażu na wrocławskim lotnisku skończył się zakazem wstępu na pokład samolotu i mandatem.

## Zauważyli, że starsza kobieta wrzuciła do kosza pieniądze
 - [https://tvn24.pl/katowice/katowice-zauwazyli-ze-starsza-kobieta-wrzucila-do-kosza-pieniadze-st7946488?source=rss](https://tvn24.pl/katowice/katowice-zauwazyli-ze-starsza-kobieta-wrzucila-do-kosza-pieniadze-st7946488?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T06:55:04+00:00

<img alt="Zauważyli, że starsza kobieta wrzuciła do kosza pieniądze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uz025u-zmanipulowana-przez-oszustow-wrzucila-pieniadze-do-kosza-ph7946522/alternates/LANDSCAPE_1280" />
    Zmanipulowana przez oszustów wyrzuciła gruby plik banknotów do kosza. Gdy zauważyła policjantów zapytała, czy to oni przyszli odebrać pieniądze. Dzięki temu, że pojawili się we właściwym miejscu i czasie, nie straciła oszczędności życia.

## Ceny ropy lecą w dół
 - [https://tvn24.pl/biznes/rynki/ceny-ropy-leca-w-dol-st7946483?source=rss](https://tvn24.pl/biznes/rynki/ceny-ropy-leca-w-dol-st7946483?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T06:50:22+00:00

<img alt="Ceny ropy lecą w dół" src="https://tvn24.pl/najnowsze/cdn-zdjecie-on9jlw-ropa-naftowa-barylka-paliwo-5656806/alternates/LANDSCAPE_1280" />
    Ceny ropy na giełdzie paliw w Nowym Jorku lecą tanieją kolejny dzień po tym, jak w weekend kraje sojuszu OPEC+ przedstawiły plany produkcyjne na najbliższe miesiące.

## Wbił się w latarnię, strażacy musieli z wraku wycinać kierowcę
 - [https://tvn24.pl/krakow/krakow-wypadek-przy-mocie-kotlarskim-st7946405?source=rss](https://tvn24.pl/krakow/krakow-wypadek-przy-mocie-kotlarskim-st7946405?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T06:14:27+00:00

<img alt="Wbił się w latarnię, strażacy musieli z wraku wycinać kierowcę" src="https://kontakt24.tvn24.pl/najnowsze/cdn-zdjecie-95yaob-wypadek-w-krakowie-ph7946305/alternates/LANDSCAPE_1280" />
    Strażacy musieli użyć urządzenia hydraulicznego, by wydostać kierowcę samochodu, który wbił się w latarnię w okolicy Mostu Kotlarskiego w Krakowie. Mężczyzna ma obrażenia nóg.

## Zmarł Brother Marquis, raper i członek hip-hopowej grupy 2 Live Crew
 - [https://tvn24.pl/kultura-i-styl/brother-marquis-nie-zyje-raper-i-czlonek-hip-hopowej-grupy-2-live-crew-mial-58-lat-st7946298?source=rss](https://tvn24.pl/kultura-i-styl/brother-marquis-nie-zyje-raper-i-czlonek-hip-hopowej-grupy-2-live-crew-mial-58-lat-st7946298?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T06:14:23+00:00

<img alt="Zmarł Brother Marquis, raper i członek hip-hopowej grupy 2 Live Crew" src="https://tvn24.pl/najnowsze/cdn-zdjecie-26kh1e-brother-marquis-ph7946299/alternates/LANDSCAPE_1280" />
    Zmarł Brother Marquis, raper i członek hip-hopowej grupy 2 Live Crew. Miał 58 lat.

## Podwyżka dla ponad trzech milionów Polaków
 - [https://tvn24.pl/biznes/pieniadze/pensja-minimalna-najnizsza-krajowa-podwyzka-dla-ponad-trzech-milionow-polakow-st7946304?source=rss](https://tvn24.pl/biznes/pieniadze/pensja-minimalna-najnizsza-krajowa-podwyzka-dla-ponad-trzech-milionow-polakow-st7946304?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T06:09:45+00:00

<img alt="Podwyżka dla ponad trzech milionów Polaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oegf96-warszawa-mnstudio-shutterstock_2180610111-ph7946403/alternates/LANDSCAPE_1280" />
    Płaca minimalna ponownie wzrośnie od 1 lipca. To efekt rozporządzenia przyjętego przez rząd jeszcze w ubiegłym roku. Najniższa krajowa jest podwyższana dwukrotnie w sytuacji podwyższonej inflacji.

## "To był atak, żeby zabić". Tomczyk o sytuacji na granicy
 - [https://tvn24.pl/polska/wiceszef-mon-cezary-tomczyk-o-sytuacji-na-granicy-to-byl-atak-zeby-zabic-st7946307?source=rss](https://tvn24.pl/polska/wiceszef-mon-cezary-tomczyk-o-sytuacji-na-granicy-to-byl-atak-zeby-zabic-st7946307?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T06:06:32+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6yhttz-cezary-tomczyk-ph7946397/alternates/LANDSCAPE_1280" />
    Jesteśmy w momencie szczytowym. Mamy około 300 prób dziennie nielegalnego przekroczenia granicy, czyli zniszczenia zapory i wejścia na teren Polski - powiedział w "Rozmowie Piaseckiego" w TVN24 wiceszef MON Cezary Tomczyk. Jak dodał, "mówimy tutaj o dwukrotnym wzroście versus rok ubiegły".

## Trzy auta zderzyły się na Południowej Obwodnicy Warszawy
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-na-pow-korek-4062024-st7946368?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-na-pow-korek-4062024-st7946368?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T06:06:32+00:00

<img alt="Trzy auta zderzyły się na Południowej Obwodnicy Warszawy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4rrmnh-zderzenie-na-s2-ph7946425/alternates/LANDSCAPE_1280" />
    Duży korek utworzył się w porannym szczycie na Południowej Obwodnicy Warszawy. To efekt zderzenia trzech aut.

## Rocznica wyborów 4 czerwca. Co nas dziś czeka?
 - [https://tvn24.pl/polska/rocznica-wyborow-4-czerwca-co-nas-dzis-czeka-st7946317?source=rss](https://tvn24.pl/polska/rocznica-wyborow-4-czerwca-co-nas-dzis-czeka-st7946317?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:57:25+00:00

<img alt="Rocznica wyborów 4 czerwca. Co nas dziś czeka? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-q47keg-polska-unia-europejska-flagi-adam-wasilewski-shutterstock_476861272-ph7946364/alternates/LANDSCAPE_1280" />
    Uroczystości w Gdańsku, wiec w Warszawie, obchody w Sejmie i Senacie. Oto co czeka nas z okazji 35. rocznicy wyborów 4 czerwca.

## Niemal dwa tysiące interwencji po nawałnicach i ulewach
 - [https://tvn24.pl/tvnmeteo/polska/niemal-dwa-tysiace-interwencji-po-nawalnicach-i-ulewach-st7946320?source=rss](https://tvn24.pl/tvnmeteo/polska/niemal-dwa-tysiace-interwencji-po-nawalnicach-i-ulewach-st7946320?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:54:41+00:00

<img alt="Niemal dwa tysiące interwencji po nawałnicach i ulewach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jdwpfm-podtopienia-w-zielonkach-w-malopolsce-ph7947997/alternates/LANDSCAPE_1280" />
    Prawie dwa tysiące razy, w tym najwięcej na Śląsku, interweniowali strażacy we wtorek w związku z podtopieniami i silnym wiatrem - poinformował rzecznik prasowy PSP st. bryg. Karol Kierzkowski. W wyniku ulewnych opadów deszczu zalanych zostało wiele dróg i posesji. Prezydent Bielska-Białej ogłosił alarm przeciwpowodziowy. Nie ma osób poszkodowanych.

## Nieprzejezdne drogi, zalane piwnice i posesje. Ulewy w Polsce
 - [https://tvn24.pl/tvnmeteo/polska/bielsko-biala-pod-woda-nieprzejezdne-drogi-zalane-piwnice-i-posesje-zdjecia-st7946320?source=rss](https://tvn24.pl/tvnmeteo/polska/bielsko-biala-pod-woda-nieprzejezdne-drogi-zalane-piwnice-i-posesje-zdjecia-st7946320?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:54:41+00:00

<img alt="Nieprzejezdne drogi, zalane piwnice i posesje. Ulewy w Polsce" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ql2de2-woda-zalala-ulice-bielska-bialej-ph7946381/alternates/LANDSCAPE_1280" />
    Intensywne opady deszczu występują w południowej części Polski. Szczególnie trudna sytuacja jest w powiecie bielskim i w Bielsku-Białej. Tam doszło do zalań i podtopień.

## Nieprzejezdne drogi, zalane piwnice i posesje. Ulewy w Polsce
 - [https://tvn24.pl/tvnmeteo/polska/nieprzejezdne-drogi-zalane-piwnice-i-posesje-ulewy-w-polsce-st7946320?source=rss](https://tvn24.pl/tvnmeteo/polska/nieprzejezdne-drogi-zalane-piwnice-i-posesje-ulewy-w-polsce-st7946320?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:54:41+00:00

<img alt="Nieprzejezdne drogi, zalane piwnice i posesje. Ulewy w Polsce" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ql2de2-woda-zalala-ulice-bielska-bialej-ph7946381/alternates/LANDSCAPE_1280" />
    Intensywne opady deszczu występują w południowej części Polski. Szczególnie trudna sytuacja jest w powiecie bielskim i w Bielsku-Białej. Tam doszło do zalań i podtopień.

## Wody wszędzie pełno, a rzeki szybko wzbierają. Już ponad 1300 interwencji po nawałnicach
 - [https://tvn24.pl/tvnmeteo/polska/bielsko-biala-pod-woda-nieprzejezdne-drogi-zalane-piwnice-i-posesje-ponad-1300-interwencji-po-nawalnicach-zdjecia-st7946320?source=rss](https://tvn24.pl/tvnmeteo/polska/bielsko-biala-pod-woda-nieprzejezdne-drogi-zalane-piwnice-i-posesje-ponad-1300-interwencji-po-nawalnicach-zdjecia-st7946320?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:54:41+00:00

<img alt="Wody wszędzie pełno, a rzeki szybko wzbierają. Już ponad 1300 interwencji po nawałnicach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2c27zt-ulewy-w-centrum-bielska-bialej-ph7946827/alternates/LANDSCAPE_1280" />
    Burze i obfite opady deszczu spowodowały, że na południu kraju doszło do zalań i podtopień. Strażacy w związku z gwałtowną aurą przeprowadzili 1303 interwencji. Będzie ich więcej, ponieważ w kilku miejscach kraju poziom wód w rzekach się podnosi.

## Nielegalne farmaceutyki o wartości 35 milionów złotych w kontenerze z Singapuru
 - [https://tvn24.pl/trojmiasto/gdynia-nielegalne-farmaceutyki-o-wartosci-35-milionow-zlotych-w-kontenerze-z-singapuru-st7946382?source=rss](https://tvn24.pl/trojmiasto/gdynia-nielegalne-farmaceutyki-o-wartosci-35-milionow-zlotych-w-kontenerze-z-singapuru-st7946382?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:48:25+00:00

<img alt="Nielegalne farmaceutyki o wartości 35 milionów złotych w kontenerze z Singapuru" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tqbypz-proba-przemytu-nielegalnych-srodkow-farmaceutycznych-o-wartosci-35-milionow-zlotych-ph7946360/alternates/LANDSCAPE_1280" />
    Kontener przypłynął do Gdyni z Singapuru. Zgodnie z dokumentami, wewnątrz miała znajdować się karma dla zwierząt. Były nielegalne farmaceutyki o wartości blisko 35 milionów złotych.

## Kolejne spektakularne odkrycie na terenie wykopalisk w Pompejach
 - [https://tvn24.pl/swiat/wlochy-kolejne-spektakularne-odkrycie-na-terenie-wykopalisk-w-pompejach-st7946278?source=rss](https://tvn24.pl/swiat/wlochy-kolejne-spektakularne-odkrycie-na-terenie-wykopalisk-w-pompejach-st7946278?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:47:13+00:00

<img alt="Kolejne spektakularne odkrycie na terenie wykopalisk w Pompejach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-276upf-wykopalisko-w-pompejach-ph7946277/alternates/LANDSCAPE_1280" />
    W Pompejach archeolodzy znaleźli pomieszczenie wykorzystywane do obrzędów rytualnych. Na niebieskich ścianach widnieją malowidła. Znaleziono też dzbany i amfory.

## Na trasie S8 spłonęło auto
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-na-trasie-s8-splonelo-auto-st7946297?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-na-trasie-s8-splonelo-auto-st7946297?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:28:36+00:00

<img alt="Na trasie S8 spłonęło auto" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-tvrldr-pozar-auta-na-s8-ph7946300/alternates/LANDSCAPE_1280" />
    W poniedziałek wieczorem na trasie S8 w samochodzie osobowym wybuchł pożar. Auto doszczętnie spłonęło.

## Ważna decyzja dla kredytobiorców. "Ryzyka wcale nie wygasły"
 - [https://tvn24.pl/biznes/z-kraju/stopy-procentowe-w-polsce-jaka-decyzja-rpp-w-maju-prognoza-st7946308?source=rss](https://tvn24.pl/biznes/z-kraju/stopy-procentowe-w-polsce-jaka-decyzja-rpp-w-maju-prognoza-st7946308?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:24:04+00:00

<img alt="Ważna decyzja dla kredytobiorców. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pq2kks-pap_20221006_14a-7929087/alternates/LANDSCAPE_1280" />
    Rada Polityki Pieniężnej nie obniży stóp procentowych na rozpoczynającym się we wtorek, czerwcowym posiedzeniu – ocenił ekonomista Banku Pekao Kamil Łuczkowski. Jego zdaniem stopy pozostaną bez zmian w tym i w przyszłym roku.

## Joe Biden po raz pierwszy nazwał Donalda Trumpa "skazanym przestępcą"
 - [https://tvn24.pl/swiat/joe-biden-zabral-glos-w-sprawie-donalda-trumpa-byly-prezydent-skazany-przestepca-st7946286?source=rss](https://tvn24.pl/swiat/joe-biden-zabral-glos-w-sprawie-donalda-trumpa-byly-prezydent-skazany-przestepca-st7946286?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:18:25+00:00

<img alt="Joe Biden po raz pierwszy nazwał Donalda Trumpa " src="https://tvn24.pl/najnowsze/cdn-zdjecie-e8jbn5-joe-biden-ph7941071/alternates/LANDSCAPE_1280" />
    Po raz pierwszy w amerykańskiej historii były prezydent, to znaczy skazany przestępca, ubiega się o urząd prezydenta - powiedział w poniedziałek Joe Biden, nawiązując do Donalda Trumpa. Agencja Reutera zauważyła, że to pierwsze takie stwierdzenie amerykańskiego prezydenta, co może wskazywać na kierunek jego kampanii.

## Zderzenie w centrum miasta. Zachowanie świadków wzbudziło dużo emocji
 - [https://tvn24.pl/lodz/lodz-zderzenie-w-centrum-miasta-zachowanie-swiadkow-wzbudzilo-duzo-emocji-st7945544?source=rss](https://tvn24.pl/lodz/lodz-zderzenie-w-centrum-miasta-zachowanie-swiadkow-wzbudzilo-duzo-emocji-st7945544?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:05:00+00:00

<img alt="Zderzenie w centrum miasta. Zachowanie świadków wzbudziło dużo emocji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9qa1bz-reakcja-swiadkow-po-zderzeniu-aut-ph7946315/alternates/LANDSCAPE_1280" />
    "Reakcja ludzi powala na kolana", "ależ znieczulica" - to komentarze pod zamieszczonym w sieci filmem, na którym widać zderzenie w centrum Łodzi. Jadąca samochodem osobowym 30-latka wjechała na skrzyżowanie al. Kościuszki i Struga na czerwonym świetle i uderzyła w bok taksówki. Do rozbitych aut - jak widać na nagraniu - początkowo nikt nie podchodził.

## Europa i świat "na progu fazy schyłkowej". O co toczy się gra?
 - [https://tvn24.pl/premium/wybory-do-parlamentu-europejskiego-2024-najwazniejsze-wyzwania-przez-unia-i-jaka-jest-stawka-wyborow-st7932845?source=rss](https://tvn24.pl/premium/wybory-do-parlamentu-europejskiego-2024-najwazniejsze-wyzwania-przez-unia-i-jaka-jest-stawka-wyborow-st7932845?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T05:00:06+00:00

<img alt="Europa i świat " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c93vnd-wojna-w-ukrainie-maj-2024-7946071/alternates/LANDSCAPE_1280" />
    Europa stoi w obliczu największych wyzwań w swojej współczesnej historii. Trzeba działać szybko i zdecydowanie. Ale - jak słyszymy od ekspertek - przede wszystkim wspólnie. Kształt Parlamentu Europejskiego po czerwcowych wyborach będzie miał kluczowe znaczenie dla podejmowanych i wdrażanych decyzji. A co jest stawką tych wyborów?

## Uciekał przed policją, wjechał w rogatki kolejowe. Twierdził, że "jest osobą wysiadającą z pojazdu, a nie kierowcą"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/jazgarzewszczyzna-uciekal-przed-policja-wjechal-w-rogatki-kolejowe-st7945715?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/jazgarzewszczyzna-uciekal-przed-policja-wjechal-w-rogatki-kolejowe-st7945715?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T04:56:44+00:00

<img alt="Uciekał przed policją, wjechał w rogatki kolejowe. Twierdził, że " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-e0gcx6-uciekal-przed-policja-i-wjechal-w-rogatki-kolejowe-ph7945760/alternates/LANDSCAPE_1280" />
    Policjanci z Piaseczna zatrzymali 38-latka, który uciekając przed patrolem policji, wjechał w rogatki kolejowe. Mężczyzna był pijany, miał dwa zakazy prowadzenia, a także był poszukiwany listem gończym.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-st7946284?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-st7946284?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T04:53:06+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u6ddph-funkcjonariusze-ukrainskiej-sluzby-bezpieczenstwa-5494485/alternates/LANDSCAPE_1280" />
    832 dni temu rozpoczęła się inwazja Rosji na Ukrainę. Służba Bezpieczeństwa Ukrainy (SBU) ściga szefa rosyjskiej młodzieżowej organizacji paramilitarnej Junarmia na okupowanym Krymie, który w miejscowych szkołach werbuje uczniów do udziału w wojnie przeciwko Ukrainie. Oto co wydarzyło się w Ukrainie i wokół niej w ciągu ostatniej doby.

## Bodnar rozmawiał z ambasadorem ZEA o postępowaniu ekstradycyjnym Sebastiana M.
 - [https://tvn24.pl/polska/rzeczniczka-prokuratora-generalnego-adam-bodnar-rozmawial-z-ambasadorem-zea-o-postepowaniu-ekstradycyjnym-sebastiana-m-st7946261?source=rss](https://tvn24.pl/polska/rzeczniczka-prokuratora-generalnego-adam-bodnar-rozmawial-z-ambasadorem-zea-o-postepowaniu-ekstradycyjnym-sebastiana-m-st7946261?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T04:46:12+00:00

<img alt="Bodnar rozmawiał z ambasadorem ZEA o postępowaniu ekstradycyjnym Sebastiana M." src="https://tvn24.pl/najnowsze/cdn-zdjecie-9f7frp-adam-bodnar-podczas-spotkania-z-ambasadorem-zea-mohamedem-al-harbi-ph7946260/alternates/LANDSCAPE_1280" />
    Adam Bodnar spotkał się z ambasadorem Zjednoczonych Emiratów Arabskich Mohamedem al Harbim. Rozmawiał między innymi o postępowaniu ekstradycyjnym wobec podejrzanego o spowodowanie śmiertelnego wypadku Sebastiana M.

## Gigant zatrudnia w Polsce. "Naturalny krok"
 - [https://tvn24.pl/biznes/z-kraju/boeing-gigant-zatrudnia-w-polsce-naturalny-krok-st7946212?source=rss](https://tvn24.pl/biznes/z-kraju/boeing-gigant-zatrudnia-w-polsce-naturalny-krok-st7946212?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T04:35:56+00:00

<img alt="Gigant zatrudnia w Polsce. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-y5xc9f-boeing-737-max-9-samolot-coby-wayne-shutterstock_2409321735-ph7946293/alternates/LANDSCAPE_1280" />
    Firma Boeing w związku z otwarciem nowego kompleksu inżynieryjnego w Polsce zapowiedziała zatrudnienie kolejnych kilkuset specjalistów, którzy będą pracować zarówno przy projektach cywilnych, jak i obronnych. Nowe miejsca pracy powstaną w Rzeszowie, Gdańsku oraz Poznaniu.

## Najwyższy stopień ostrzeżeń w części kraju. W czasie burz będzie ulewnie padać
 - [https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-najwyzszego-stopnia-burze-i-ulewy-niebezpieczna-pogoda-we-wtorek-406-st7946285?source=rss](https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-najwyzszego-stopnia-burze-i-ulewy-niebezpieczna-pogoda-we-wtorek-406-st7946285?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T04:23:43+00:00

<img alt="Najwyższy stopień ostrzeżeń w części kraju. W czasie burz będzie ulewnie padać" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3atcjd-ulewy-i-burze-6142469/alternates/LANDSCAPE_1280" />
    IMGW ostrzega przed intensywnymi opadami deszczu i burzami. Obowiązują ostrzeżenia pierwszego, drugiego, a nawet i trzeciego stopnia. Sprawdź, gdzie będzie niebezpiecznie.

## Ostrzeżenia najwyższego stopnia w części Polski
 - [https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-najwyzszego-stopnia-ulewy-w-polsce-st7946285?source=rss](https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-imgw-najwyzszego-stopnia-ulewy-w-polsce-st7946285?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T04:23:43+00:00

<img alt="Ostrzeżenia najwyższego stopnia w części Polski" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-4z3sre-intensywne-opady-deszczu-ph6116656/alternates/LANDSCAPE_1280" />
    W niektórych miejscach na południu i południowym wschodzie Polski w nocy z wtorku na środę nadal możliwe są intensywne opady deszczu - ostrzega Instytut Meteorologii i Gospodarki Wodnej. W jednym województwie obowiązują ostrzeżenia trzeciego stopnia.

## Platforma Max ogłasza ceny pakietów w Polsce
 - [https://tvn24.pl/polska/platforma-max-oglasza-ceny-pakietow-w-polsce-st7946256?source=rss](https://tvn24.pl/polska/platforma-max-oglasza-ceny-pakietow-w-polsce-st7946256?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T04:16:35+00:00

<img alt="Platforma Max ogłasza ceny pakietów w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xrw5ra-max-ph7946255/alternates/LANDSCAPE_1280" />
    Platforma Max zadebiutuje w Polsce już w 11 czerwca 2024 roku. Użytkownicy serwisu będą mogli wybrać spośród trzech korzystnych cenowo pakietów subskrypcji, dopasowanych do ich potrzeb i preferencji. Każdy z trzech pakietów będzie można rozszerzyć o dodatkowy pakiet "Kanały TV i Sport", aby zyskać dostęp do biblioteki nawet 29 kanałów telewizyjnych i relacji z najważniejszych wydarzeń sportowych na żywo. W ramach platformy Max użytkownicy znajdą najbardziej jakościowe treści globalnych marek takich jak HBO, DC czy Warner Bros., kontent dla dzieci, programy informacyjne i publicystyczne oraz sportowe, w tym relacje z Igrzysk Olimpijskich Paris 2024 w ramach każdego pakietu, a także bogatą ofertę produkcji lokalnych i najlepszą rozrywkę z TVN.

## "Prośba szefa". Najważniejsze wątki reportażu "Czarno na białym"
 - [https://tvn24.pl/polska/reportaz-czarno-na-bialym-nowe-ustalenia-w-sprawie-afery-hejterskiej-st7946244?source=rss](https://tvn24.pl/polska/reportaz-czarno-na-bialym-nowe-ustalenia-w-sprawie-afery-hejterskiej-st7946244?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T03:52:08+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ux347r-ziobro-i-piebiak-repo-cnb-prosba-szefa-ph7946024/alternates/LANDSCAPE_1280" />
    Dziennikarze "Czarno na białym" TVN24 i portalu OKO.press ujawniają nowe fakty w sprawie afery hejterskiej w Ministerstwie Sprawiedliwości. Marta Gordziewicz pokazuje, ile wspólnego z prawdą miały zapewnienia Zbigniewa Ziobry, że nie wiedział o organizowaniu szczucia na niezależnych sędziów. Ujawnia też, gdzie powstało jedno z hejterskich kont społecznościowych. Oto najważniejsze wątki reportażu "Prośba szefa".

## Wnuk Oppenheimera apeluje do państw nuklearnych
 - [https://tvn24.pl/swiat/japonia-wnuk-roberta-oppenheimera-zaapelowal-o-dialog-panstw-nuklearnych-st7946272?source=rss](https://tvn24.pl/swiat/japonia-wnuk-roberta-oppenheimera-zaapelowal-o-dialog-panstw-nuklearnych-st7946272?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T03:48:05+00:00

<img alt="Wnuk Oppenheimera apeluje do państw nuklearnych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c9h167-park-pokoju-w-hiroszimie-japonia-shutterstock_430810120-7197182/alternates/LANDSCAPE_1280" />
    Wnuk fizyka Roberta Oppenheimera po raz pierwszy odwiedził Hiroszimę, gdzie spotkał się z osobami, które ocalały po atakach atomowych. Charles Oppenheimer podczas konferencji w Tokio apelował do przywódców państw nuklearnych o dialog.

## Pięć rzeczy, które warto wiedzieć we wtorek 4 czerwca
 - [https://tvn24.pl/polska/piec-rzeczy-ktore-warto-wiedziec-we-wtorek-4-czerwca-st7946283?source=rss](https://tvn24.pl/polska/piec-rzeczy-ktore-warto-wiedziec-we-wtorek-4-czerwca-st7946283?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T03:25:53+00:00

<img alt="Pięć rzeczy, które warto wiedzieć we wtorek 4 czerwca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5mv0iw-zbigniew-ziobro-i-michal-wos-7838872/alternates/LANDSCAPE_1280" />
    Dziennikarze "Czarno na białym" TVN24 i serwisu OKO.press ujawniają nowe fakty w sprawie afery hejterskiej w Ministerstwie Sprawiedliwości. Pojawiają się nowe wątpliwości wokół zamówień Rządowej Agencji Rezerw Strategicznych za rządów PiS. Z kolei architekt brexitu Nigel Farage zapowiedział, że wystartuje w wyborach do Izby Gmin. Oto pięć rzeczy, które warto wiedzieć we wtorek 4 czerwca.

## Pogoda na dziś - wtorek 04.06. Opady, grzmoty i błyski w kilku regionach
 - [https://tvn24.pl/tvnmeteo/prognoza/article7946229.ece?source=rss](https://tvn24.pl/tvnmeteo/prognoza/article7946229.ece?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-04T00:00:00+00:00

<img alt="Pogoda na dziś - wtorek 04.06. Opady, grzmoty i błyski w kilku regionach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-eo0bek-intensywne-opady-deszczu-6000577/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. We wtorek 04.06 w części kraju będzie deszczowo i pojawią się burze. Najbardziej obficie ma padać w rejonach górskich. Termometry wskażą od 19 do 23 stopni Celsjusza.

