# Source:3DPrinting.com, URL:https://3dprinting.com/feed, language:en-US

## 3D Printed Eco Bracket Lightens Aircraft and Lowers Costs - 3DPrinting.com
 - [https://3dprinting.com/news/3d-printed-eco-bracket-lightens-aircraft-and-lowers-costs](https://3dprinting.com/news/3d-printed-eco-bracket-lightens-aircraft-and-lowers-costs)
 - RSS feed: https://3dprinting.com/feed
 - date published: 2024-06-04T20:31:26+00:00

<div style="display: flex;"><div><h2><a href="https://3dprinting.com/news/3d-printed-eco-bracket-lightens-aircraft-and-lowers-costs/" target="_blank">3D Printed Eco Bracket Lightens Aircraft and Lowers Costs</a></h2><span style="color: #777; font-size: 14px; margin-top: auto;">June 4</span></div><div><img alt="3D Printed Eco Bracket Lightens Aircraft and Lowers Costs" class="attachment-singular-featured-thumb size-singular-featured-thumb wp-post-image" height="481" src="https://3dprinting.com/wp-content/uploads/image3-176-500x481.png" style="border-radius: 10px; overflow: hidden;" width="500" /></div></div>

## 3D Printed Vascular Grafts to Combat Post-Surgical Complications - 3DPrinting.com
 - [https://3dprinting.com/news/3d-printed-vascular-grafts-to-combat-post-surgical-complications](https://3dprinting.com/news/3d-printed-vascular-grafts-to-combat-post-surgical-complications)
 - RSS feed: https://3dprinting.com/feed
 - date published: 2024-06-04T09:00:28+00:00

<div style="display: flex;"><div><h2><a href="https://3dprinting.com/news/3d-printed-vascular-grafts-to-combat-post-surgical-complications/" target="_blank">3D Printed Vascular Grafts to Combat Post-Surgical Complications</a></h2><span style="color: #777; font-size: 14px; margin-top: auto;">June 4</span></div><div><img alt="3D Printed Vascular Grafts to Combat Post-Surgical Complications" class="attachment-singular-featured-thumb size-singular-featured-thumb wp-post-image" height="500" src="https://3dprinting.com/wp-content/uploads/image1-129-500x500.jpg" style="border-radius: 10px; overflow: hidden;" width="500" /></div></div>

## DOCOMO Employs 3D Printing for Hydropower Base Stations - 3DPrinting.com
 - [https://3dprinting.com/news/docomo-employs-3d-printing-for-hydropower-base-stations](https://3dprinting.com/news/docomo-employs-3d-printing-for-hydropower-base-stations)
 - RSS feed: https://3dprinting.com/feed
 - date published: 2024-06-04T08:00:21+00:00

<div style="display: flex;"><div><h2><a href="https://3dprinting.com/news/docomo-employs-3d-printing-for-hydropower-base-stations/" target="_blank">DOCOMO Employs 3D Printing for Hydropower Base Stations</a></h2><span style="color: #777; font-size: 14px; margin-top: auto;">June 4</span></div><div><img alt="DOCOMO Employs 3D Printing for Hydropower Base Stations" class="attachment-singular-featured-thumb size-singular-featured-thumb wp-post-image" height="500" src="https://3dprinting.com/wp-content/uploads/image2-213-500x500.png" style="border-radius: 10px; overflow: hidden;" width="500" /></div></div>

