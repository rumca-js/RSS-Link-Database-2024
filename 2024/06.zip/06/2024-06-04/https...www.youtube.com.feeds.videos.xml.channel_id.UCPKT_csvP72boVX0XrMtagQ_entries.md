# Source:Cercle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ, language:en-US

## Cercle Odyssey: First dates and locations will be announced June 6th, 2024 #cercle #cercleodyssey
 - [https://www.youtube.com/watch?v=ISekT7fRZ_4](https://www.youtube.com/watch?v=ISekT7fRZ_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2024-06-04T18:09:01+00:00



## Cercle Odyssey: the world’s first large-scale 360 immersive nomad concert installation of its kind.
 - [https://www.youtube.com/watch?v=KLMptzIx_tI](https://www.youtube.com/watch?v=KLMptzIx_tI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCPKT_csvP72boVX0XrMtagQ
 - date published: 2024-06-04T08:32:02+00:00



