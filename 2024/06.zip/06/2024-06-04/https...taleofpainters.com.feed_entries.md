# Source:Tale of Painters, URL:https://taleofpainters.com/feed, language:en-GB

## Showcase: Stormcast Eternals Knight Vexillor with Banner of Apotheosis
 - [https://taleofpainters.com/2024/06/showcase-stormcast-eternals-knight-vexillor-with-banner-of-apotheosis](https://taleofpainters.com/2024/06/showcase-stormcast-eternals-knight-vexillor-with-banner-of-apotheosis)
 - RSS feed: https://taleofpainters.com/feed
 - date published: 2024-06-04T16:00:00+00:00

<p>Today's post should be me rage quitting the hobby and setting fire to my existing Stormcast Eternals models but I'm not doing that. Instead out of the hypothetical fires are born a new Stormiest, ready to march forth into a different Realm and a new edition of Age of Sigmar.  </p>
<p>The post <a href="https://taleofpainters.com/2024/06/showcase-stormcast-eternals-knight-vexillor-with-banner-of-apotheosis/">Showcase: Stormcast Eternals Knight Vexillor with Banner of Apotheosis</a> appeared first on <a href="https://taleofpainters.com">Tale of Painters</a>.</p>

## ToP Tip: The best gold & copper paints
 - [https://taleofpainters.com/2024/06/top-tip-the-best-gold-copper-paints](https://taleofpainters.com/2024/06/top-tip-the-best-gold-copper-paints)
 - RSS feed: https://taleofpainters.com/feed
 - date published: 2024-06-04T16:00:00+00:00

<p>In this edition of Stahly's Paint Picks, we're going chocolaty. I'll show you a colour palette of 8 paints, starting with a light latte macchiato, going through mocha, and ending with a warm, dark chocolate brown. Perfect for painting leather, dark skin, horses, and much more.</p>
<p>The post <a href="https://taleofpainters.com/2024/06/top-tip-the-best-gold-copper-paints/">ToP Tip: The best gold &amp; copper paints</a> appeared first on <a href="https://taleofpainters.com">Tale of Painters</a>.</p>

