# Source:Turystyka, URL:https://turystyka.rp.pl/rss/3351-turystyka, language:pl-PL

## Linie lotnicze ukarane za doliczanie opłat za bagaż podręczny. "Historyczna decyzja"
 - [https://turystyka.rp.pl/linie-lotnicze/art40548221-linie-lotnicze-ukarane-za-doliczanie-oplat-za-bagaz-podreczny-historyczna-decyzja](https://turystyka.rp.pl/linie-lotnicze/art40548221-linie-lotnicze-ukarane-za-doliczanie-oplat-za-bagaz-podreczny-historyczna-decyzja)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-06-04T10:45:11+00:00

Rząd Hiszpanii ukarał cztery niskokoszotowe linie lotnicze za pobieranie od pasażerów pieniędzy za możliwość zabrania na pokład samolotu bagażu podręcznego. - Ryanair, Easyjet, Vueling i Volotea-w sumie muszą zapłacić 150 milionów euro.

## Co z klientami upadającego niemieckiego biura podróży? Niektórzy jeszcze wyjadą
 - [https://turystyka.rp.pl/biura-podrozy/art40546051-co-z-klientami-upadajacego-niemieckiego-biura-podrozy-niektorzy-jeszcze-wyjada](https://turystyka.rp.pl/biura-podrozy/art40546051-co-z-klientami-upadajacego-niemieckiego-biura-podrozy-niektorzy-jeszcze-wyjada)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-06-04T06:24:12+00:00

Klienci bankrutującego biura podróży FTI, którzy są teraz na wyjazdach, mają dokończyć wypoczynek zgodnie z planem. Firma odwołała wycieczki rozpoczynające się między 3 a 5 czerwca, ale być może będzie realizowała te, które przewidują wyjazd po 6 czerwca.

## Brytyjczycy jadą na zagraniczne wakacje. Rosnące koszty im nie straszne
 - [https://turystyka.rp.pl/popularne-trendy/art40539831-brytyjczycy-jada-na-zagraniczne-wakacje-rosnace-koszty-im-nie-straszne](https://turystyka.rp.pl/popularne-trendy/art40539831-brytyjczycy-jada-na-zagraniczne-wakacje-rosnace-koszty-im-nie-straszne)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-06-04T04:07:00+00:00

Niemal dziewięciu na dziesięciu Brytyjczyków deklaruje, że w tym roku wyjedzie na wakacje, mimo wyzwań związanych z wysokimi kosztami życia. Część z nich zamierza podróżować za granicę, a część po kraju. Ale są również i tacy, którzy będą wypoczywać i w Wielkiej Brytanii i poza nią.

