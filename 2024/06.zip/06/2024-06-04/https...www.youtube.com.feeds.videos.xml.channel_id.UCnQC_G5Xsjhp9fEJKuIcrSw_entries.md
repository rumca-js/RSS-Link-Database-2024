# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## This is the justice system under Joe Biden
 - [https://www.youtube.com/watch?v=oiG8Rn5NA6U](https://www.youtube.com/watch?v=oiG8Rn5NA6U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-06-04T21:30:09+00:00



## Here's What You Missed From Dr. Fauci's Testimony
 - [https://www.youtube.com/watch?v=yL5oEiHZJrc](https://www.youtube.com/watch?v=yL5oEiHZJrc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-06-04T21:00:37+00:00

Birch Gold - Text "BEN" to 989898 for your no-cost, no-obligation, FREE information kit.

Dr. Anthony Fauci testified in front of Congress yesterday. Here's what you may have missed.

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1978 - https://youtu.be/THvWAIYoluk

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #DrFauci #LabLeak #EcoHealthAlliance #WHO #CDC #AnthonyFauci #TonyFauci #Congress #CongressionalHearing #GainOfFunction

## I don't think this is going to go the way they think it is
 - [https://www.youtube.com/watch?v=UGIqDTB6FLI](https://www.youtube.com/watch?v=UGIqDTB6FLI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-06-04T19:00:12+00:00



## The Hunter Biden Trial BEGINS
 - [https://www.youtube.com/watch?v=THvWAIYoluk](https://www.youtube.com/watch?v=THvWAIYoluk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-06-04T17:00:06+00:00

The Hunter Biden trial begins; Anthony Fauci gets smacked around by Congress; and Joe Biden tries to flip on illegal immigration.

Ep.1978

- - -

1️⃣ Click here to join the member exclusive portion of my show: https://bit.ly/3WDjgHE

2️⃣ Father’s Day Deal: Get 15% off your Jeremy’s Razor: https://bit.ly/49kXXgI

3️⃣ Get 25% off your DailyWire+ Membership here: https://bit.ly/4akO7wC

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴 Today's Sponsors 🔴

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/BEN

Birch Gold - Text "BEN" to 989898 for your no-cost, no-obligation, FREE information kit.

Policygenius - Get your free life insurance quote & see how much you could save: http://policygenius.com/SHAPIRO

Black Rifle Coffee - Give back by drinking America's coffee! https://www.blackriflecoffee.com/

Tax Network USA - Seize control of your financial future! Call 1-800-245-6000 or visit http://www.TNUSA.com/SHAPIRO

This video includes information, descri

## Graduations in 2024 are CRAZY
 - [https://www.youtube.com/watch?v=lfRE7Hu4EDE](https://www.youtube.com/watch?v=lfRE7Hu4EDE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-06-04T15:00:44+00:00



## Donald Trump Is Now on TikTok
 - [https://www.youtube.com/watch?v=AzQekA5JBTg](https://www.youtube.com/watch?v=AzQekA5JBTg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-06-04T02:00:04+00:00



## Hillary Clinton came out a-grinning
 - [https://www.youtube.com/watch?v=uE6okKWQnY0](https://www.youtube.com/watch?v=uE6okKWQnY0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-06-04T00:00:31+00:00



