# Source:Board Game Quest, URL:https://www.boardgamequest.com/feed, language:en-US

## The Binding of Isaac: Four Souls Requiem Review
 - [https://www.boardgamequest.com/the-binding-of-isaac-four-souls-requiem-review](https://www.boardgamequest.com/the-binding-of-isaac-four-souls-requiem-review)
 - RSS feed: https://www.boardgamequest.com/feed
 - date published: 2024-06-04T13:02:15+00:00

<img alt="The Binding of Isaac" class="webfeedsFeaturedVisual wp-post-image" height="910" src="https://www.boardgamequest.com/wp-content/uploads/2024/05/Binding-of-Isaac-720x1024.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="640" />The world of video-game-to-board-game adaptations seems to grow every day. What used to be a market of cheap, tired designs aimed at grabbing a known audience has turned into a unique design space. Trendsetters like Frostpunk, Slay the Spire, and Bloodborne have really shown how the video games of inspiration can be translated to the [&#8230;]
<p><a href="https://www.boardgamequest.com/the-binding-of-isaac-four-souls-requiem-review/" rel="nofollow">Source</a></p>

