# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Microsoft Recall Is Worse Than We Thought
 - [https://www.youtube.com/watch?v=Bvt186qt-ew](https://www.youtube.com/watch?v=Bvt186qt-ew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2024-06-04T21:00:06+00:00

A few weeks back we first heard about Microsoft's new Copilot+ PCs but more importantly the addition of Recall a feature which screenshots everything you do and parses it a local AI model that allows you to search back through everything and it turns out this is worse than we thought.

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Albacore Post: https://x.com/thebookisclosed/status/1793779204871553128
Tom's Hardware Post: https://www.tomshardware.com/software/windows/how-to-try-windows-11-recall-ai-feature-right-now-even-on-unsupported-hardware
Azure VM: https://hachyderm.io/@dfeldman/112545000510184489
Kevin Beaumont Post: https://doublepulsar.com/recall-stealing-everything-youve-ever-typed-or-viewed-on-your-own-windows-pc-is-now-possible-da3e12e9465e
Hidden Content: 

