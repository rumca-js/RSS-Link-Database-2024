# Source:Tabletop Gaming News – TGN, URL:https://www.tabletopgamingnews.com/feed, language:en-US

## 9th Level Games Announces “City of Skull” Campaign Launch on BackerKit
 - [https://www.tabletopgamingnews.com/9th-level-games-announces-city-of-skull-campaign-launch-on-backerkit](https://www.tabletopgamingnews.com/9th-level-games-announces-city-of-skull-campaign-launch-on-backerkit)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-06-04T21:38:19+00:00

9th Level Games has shared its latest endeavor, &#8220;City of Skull,&#8221; a comprehensive campaign setting for Mazes Fantasy Roleplaying, now seeking funding on BackerKit. The new campaign, set to be published as a hardcover book, introduces a unique West Marches hex crawler adventure path to the Mazes game series. &#8220;City of Skull&#8221; offers a vivid...

## Mantic Games Acquires River Horse in Strategic Partnership
 - [https://www.tabletopgamingnews.com/mantic-games-acquires-river-horse-in-strategic-partnership](https://www.tabletopgamingnews.com/mantic-games-acquires-river-horse-in-strategic-partnership)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-06-04T21:16:02+00:00

Mantic Games has announced its acquisition of River Horse, a move that consolidates a longstanding collaboration between the two tabletop game developers. This partnership is set to enhance Mantic&#8217;s game portfolio by incorporating River Horse&#8217;s licensed games and universes. As part of the acquisition, game designer Alessio Cavatore will join Mantic Games. Cavatore has previously...

## DV Games Announces Three New Board Games for Release Later This Year
 - [https://www.tabletopgamingnews.com/dv-games-announces-three-new-board-games-for-release-later-this-year](https://www.tabletopgamingnews.com/dv-games-announces-three-new-board-games-for-release-later-this-year)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-06-04T20:06:18+00:00

DV Games has announced its upcoming lineup of board games set for release in the fourth quarter of 2024. The new titles include &#8220;Until Proven Guilty,&#8221; &#8220;BANG! Dice Explosion,&#8221; and &#8220;Lost In Adventure &#8211; The Labyrinth,&#8221; each offering unique gameplay experiences. Until Proven Guilty: A Narrative Legal Game Developed by Enrico Procacci with artwork by...

## Free League Publishing Releases “Mutant Year Zero: Zone Wars”
 - [https://www.tabletopgamingnews.com/free-league-publishing-releases-mutant-year-zero-zone-wars](https://www.tabletopgamingnews.com/free-league-publishing-releases-mutant-year-zero-zone-wars)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-06-04T19:43:48+00:00

Free League Publishing announced the release of &#8220;Mutant Year Zero: Zone Wars,&#8221; a new miniature skirmish game set in the Mutant Year Zero universe. The game invites players to engage in battles for survival and dominance in a post-apocalyptic setting. &#8220;Mutant Year Zero: Zone Wars&#8221; aims to offer a fast-paced gameplay experience, emphasizing tactical battles...

## EN Publishing Launches “Voidrunner’s Codex” on Kickstarter
 - [https://www.tabletopgamingnews.com/en-publishing-launches-voidrunners-codex-on-kickstarter](https://www.tabletopgamingnews.com/en-publishing-launches-voidrunners-codex-on-kickstarter)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-06-04T19:32:36+00:00

EN Publishing has recently introduced a Kickstarter campaign for &#8220;Voidrunner’s Codex,&#8221; an expansion designed to propel Dungeons &#38; Dragons 5E and Level Up: Advanced 5E players into interstellar adventures. The campaign aims to enrich the tabletop RPG experience with an array of new content. The expansion is anchored by the &#8220;Voidrunner’s Codex,&#8221; a hardcover volume...

