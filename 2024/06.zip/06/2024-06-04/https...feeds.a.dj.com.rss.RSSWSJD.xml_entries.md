# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## AI Employees Fear They Aren't Free to Voice Their Concerns
 - [https://www.wsj.com/articles/ai-employees-fear-they-arent-free-to-voice-their-concerns-abd38606?mod=rss_Technology](https://www.wsj.com/articles/ai-employees-fear-they-arent-free-to-voice-their-concerns-abd38606?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-06-04T15:35:00+00:00

A group of current and former OpenAI and DeepMind employees said they want more whistleblower protections and fear retaliation.

## Hitachi, Microsoft Plan for Multibillion-Dollar AI Partnership
 - [https://www.wsj.com/articles/hitachi-microsoft-plan-for-multibillion-dollar-ai-partnership-3a040cf9?mod=rss_Technology](https://www.wsj.com/articles/hitachi-microsoft-plan-for-multibillion-dollar-ai-partnership-3a040cf9?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-06-04T04:29:00+00:00

Hitachi and Microsoft announced a multibillion-dollar collaboration to accelerate the adoption of generative artificial intelligence, the latest in a series of partnerships and investments the two companies are undertaking.

## The Goal forChina's Chip Giant: Cut Out the U.S.
 - [https://www.wsj.com/articles/chinese-semiconductor-industry-smic-self-sufficient-5210abf8?mod=rss_Technology](https://www.wsj.com/articles/chinese-semiconductor-industry-smic-self-sufficient-5210abf8?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-06-04T01:00:00+00:00

Hit by Washington’s export controls, China’s domestic chip industry strives for self-sufficiency.

