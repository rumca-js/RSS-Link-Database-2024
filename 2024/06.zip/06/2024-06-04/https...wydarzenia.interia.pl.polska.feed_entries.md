# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## "Przecież to będzie rechot". Prezydent grzmi ws. nominacji na ambasadora
 - [https://wydarzenia.interia.pl/kraj/news-przeciez-to-bedzie-rechot-prezydent-grzmi-ws-nominacji-na-am,nId,7554238](https://wydarzenia.interia.pl/kraj/news-przeciez-to-bedzie-rechot-prezydent-grzmi-ws-nominacji-na-am,nId,7554238)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-04T20:21:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-przeciez-to-bedzie-rechot-prezydent-grzmi-ws-nominacji-na-am,nId,7554238"><img align="left" alt="&quot;Przecież to będzie rechot&quot;. Prezydent grzmi ws. nominacji na ambasadora" src="https://i.iplsc.com/przeciez-to-bedzie-rechot-prezydent-grzmi-ws-nominacji-na-am/000J992LUHV2LS8R-C321.jpg" /></a>- Faceta, który był ministrem obrony narodowej, gdy zginął polski prezydent i odpowiadał za polskie wojsko, oni chcą wysłać na ambasadora Stanów Zjednoczonych. Przecież to będzie jeden wielki rechot - tak Andrzej Duda na antenie Telewizji Republika skomentował doniesienia o nominacji Bogdana Klicha. Prezydent krytykował Radosława Sikorskiego, a jego działania w resorcie spraw zagranicznych nazwał &quot;rekomunizacją polskiej dyplomacji&quot;. Oberwało się również Donaldowi Tuskowi za &quot;obrażanie i poniżanie&quot; Donalda Trumpa. </p><br clear="all" />

## Wypłynął sensacyjny sondaż PO. Kłopoty lidera listy
 - [https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-wyplynal-sensacyjny-sondaz-po-klopoty-lidera-listy,nId,7553913](https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-wyplynal-sensacyjny-sondaz-po-klopoty-lidera-listy,nId,7553913)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-04T14:04:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-wyplynal-sensacyjny-sondaz-po-klopoty-lidera-listy,nId,7553913"><img align="left" alt="Wypłynął sensacyjny sondaż PO. Kłopoty lidera listy" src="https://i.iplsc.com/wyplynal-sensacyjny-sondaz-po-klopoty-lidera-listy/000J96FYNNAJWVPW-C321.jpg" /></a>Marcin Kierwiński miał być lokomotywą KO na warszawskiej liście, ale media donoszą o sensacyjnym wewnętrznym sondażu. Były już szef MSWiA może nie objąć mandatu europosła, bo w partyjnym wyścigu wyższe notowania mają mieć dwie osoby - Hanna Gronkiewicz-Waltz i Michał Szczerba.  </p><br clear="all" />

## Robert Bąkiewicz usłyszał zarzuty. Grozi mu do kilku lat więzienia
 - [https://wydarzenia.interia.pl/kraj/news-robert-bakiewicz-uslyszal-zarzuty-grozi-mu-do-kilku-lat-wiez,nId,7553725](https://wydarzenia.interia.pl/kraj/news-robert-bakiewicz-uslyszal-zarzuty-grozi-mu-do-kilku-lat-wiez,nId,7553725)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-04T11:54:46+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-robert-bakiewicz-uslyszal-zarzuty-grozi-mu-do-kilku-lat-wiez,nId,7553725"><img align="left" alt="Robert Bąkiewicz usłyszał zarzuty. Grozi mu do kilku lat więzienia" src="https://i.iplsc.com/robert-bakiewicz-uslyszal-zarzuty-grozi-mu-do-kilku-lat-wiez/000IKARWC4G1RQG0-C321.jpg" /></a>Od sześciu miesięcy do ośmiu lat pozbawienia wolności grozi Robertowi Bąkiewiczowi za uszkodzenia zabytkowego budynku Ministerstwa Klimatu i Środowiska. Chodzi o sprawę ze stycznia, kiedy były lider Marszu Niepodległości opublikował w mediach społecznościowych film, na którym maluje symbol Polski Walczącej na gmachu. Do sądu wpłynął akt oskarżenia skierowany przez Prokuraturę Rejonową Warszawa Ochota.</p><br clear="all" />

## Wybory do PE 2024. Komu przysługuje bezpłatny transport?
 - [https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-wybory-do-pe-2024-komu-przysluguje-bezplatny-transport,nId,7454891](https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-wybory-do-pe-2024-komu-przysluguje-bezplatny-transport,nId,7454891)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-04T11:29:18+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-wybory-do-pe-2024-komu-przysluguje-bezplatny-transport,nId,7454891"><img align="left" alt="Wybory do PE 2024. Komu przysługuje bezpłatny transport?" src="https://i.iplsc.com/wybory-do-pe-2024-komu-przysluguje-bezplatny-transport/000J955SBXS48R6L-C321.jpg" /></a>Osoby niepełnosprawne i starsze mają prawo do bezpłatnego transportu do lokalu wyborczego. Dzięki temu, pomimo problemów zdrowotnych, będą mogły wziąć udział w wyborach do Parlamentu Europejskiego 2024. Każda osoba, która chce skorzystać z takiego transportu, musi złożyć wniosek w odpowiednim terminie. W przypadku zbliżającego się głosowania termin już minął. </p><br clear="all" />

## Akta w domu Ziobry. Prokuratura wszczyna śledztwo
 - [https://wydarzenia.interia.pl/kraj/news-akta-w-domu-ziobry-prokuratura-wszczyna-sledztwo,nId,7553652](https://wydarzenia.interia.pl/kraj/news-akta-w-domu-ziobry-prokuratura-wszczyna-sledztwo,nId,7553652)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-04T10:52:14+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-akta-w-domu-ziobry-prokuratura-wszczyna-sledztwo,nId,7553652"><img align="left" alt="Akta w domu Ziobry. Prokuratura wszczyna śledztwo" src="https://i.iplsc.com/akta-w-domu-ziobry-prokuratura-wszczyna-sledztwo/000GDJY75Q92KQ0P-C321.jpg" /></a>Prokuratura wszczęła śledztwo dotyczące ukrywania akt znalezionych w domu Zbigniewa Ziobry w Jeruzalu (woj. łódzkie). Dotyczyły one choroby oraz leczenia ojca lidera Suwerennej Polski.</p><br clear="all" />

## Rewolucja w PiS? Donald Tusk: Nawet liderzy się krztuszą
 - [https://wydarzenia.interia.pl/kraj/news-rewolucja-w-pis-donald-tusk-nawet-liderzy-sie-krztusza,nId,7553477](https://wydarzenia.interia.pl/kraj/news-rewolucja-w-pis-donald-tusk-nawet-liderzy-sie-krztusza,nId,7553477)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-04T08:24:42+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rewolucja-w-pis-donald-tusk-nawet-liderzy-sie-krztusza,nId,7553477"><img align="left" alt="Rewolucja w PiS? Donald Tusk: Nawet liderzy się krztuszą" src="https://i.iplsc.com/rewolucja-w-pis-donald-tusk-nawet-liderzy-sie-krztusza/000J92TSX1DT0KSC-C321.jpg" /></a>Spekulacje na temat zmiany nazwy partii Prawo i Sprawiedliwość wracają. Formacja miała poważnie zastanawiać się nad rebrandingiem jeszcze przed wyborami samorządowymi, a prawdopodobna decyzja o nowym szyldzie będzie uzależniona od wyniku w wyborach europejskich. Teraz do sprawy odniósł się Donald Tusk. </p><br clear="all" />

## Prawie tysiąc zgłoszeń w Polsce. Najtrudniejsza sytuacja panuje na Śląsku
 - [https://wydarzenia.interia.pl/kraj/news-prawie-tysiac-zgloszen-w-polsce-najtrudniejsza-sytuacja-panu,nId,7553449](https://wydarzenia.interia.pl/kraj/news-prawie-tysiac-zgloszen-w-polsce-najtrudniejsza-sytuacja-panu,nId,7553449)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-04T07:46:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prawie-tysiac-zgloszen-w-polsce-najtrudniejsza-sytuacja-panu,nId,7553449"><img align="left" alt="Prawie tysiąc zgłoszeń w Polsce. Najtrudniejsza sytuacja panuje na Śląsku" src="https://i.iplsc.com/prawie-tysiac-zgloszen-w-polsce-najtrudniejsza-sytuacja-panu/000J926MWORTSKHR-C321.jpg" /></a>Potężne ulewy i burze nie pozwalają strażakom na odpoczynek. W całej Polsce interweniowali prawie tysiąc razy. Najgorsza sytuacja panuje na Śląsku. Tylko w tym rejonie zanotowano ponad 800 zgłoszeń. W części kraju w związku z fatalną pogodą obowiązują alerty IMGW trzeciego - najwyższego stopnia.</p><br clear="all" />

