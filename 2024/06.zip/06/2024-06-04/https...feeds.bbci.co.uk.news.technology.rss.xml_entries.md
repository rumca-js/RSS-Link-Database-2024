# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Australia wants to become a renewable energy superpower. Can it?
 - [https://www.bbc.com/news/articles/cp00vyl6l6mo](https://www.bbc.com/news/articles/cp00vyl6l6mo)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-06-04T23:10:23+00:00

The country has come up with an ambitious plan to become the engine room of the new green economy.

## Instagram tests forcing users to watch adverts
 - [https://www.bbc.com/news/articles/c877y6mxdp7o](https://www.bbc.com/news/articles/c877y6mxdp7o)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-06-04T12:30:41+00:00

The "ad break" feature it is trialling means users cannot scroll or swipe past adverts as usual.

## Epoch Times CFO charged in $67m money laundering plot
 - [https://www.bbc.com/news/articles/cg66xe59zyeo](https://www.bbc.com/news/articles/cg66xe59zyeo)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-06-04T00:31:06+00:00

CFO Bill Guan allegedly led a team at the news outlet that was behind a global money laundering scheme.

