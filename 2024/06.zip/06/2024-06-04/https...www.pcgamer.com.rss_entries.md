# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## Hades 2's latest patch drops the nerf hammer on everyone's favorite overpowered build, but players are surprisingly cool with it
 - [https://www.pcgamer.com/games/roguelike/hades-2s-latest-patch-drops-the-nerf-hammer-on-everyones-favorite-overpowered-build-but-players-are-surprisingly-cool-with-it](https://www.pcgamer.com/games/roguelike/hades-2s-latest-patch-drops-the-nerf-hammer-on-everyones-favorite-overpowered-build-but-players-are-surprisingly-cool-with-it)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T22:08:55+00:00

The second Hades 2 patch brings a lot of changes.

## Ultrakill dev says it's fine to pirate his game if you don't have money to spare: 'Culture shouldn't exist only for those who can afford it'
 - [https://www.pcgamer.com/gaming-industry/ultrakill-dev-says-its-fine-to-pirate-his-game-if-you-dont-have-money-to-spare-culture-shouldnt-exist-only-for-those-who-can-afford-it](https://www.pcgamer.com/gaming-industry/ultrakill-dev-says-its-fine-to-pirate-his-game-if-you-dont-have-money-to-spare-culture-shouldnt-exist-only-for-those-who-can-afford-it)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T21:01:42+00:00

Spreading the word about a game you pirated and enjoyed is "at worst an equal trade," Hakita says.

## Wild Bastards takes every ingredient that made up BioShock's Irrational Games and blends it with cowboy beans
 - [https://www.pcgamer.com/games/fps/wild-bastards-takes-every-ingredient-that-made-up-bioshocks-irrational-games-and-blends-it-with-cowboy-beans](https://www.pcgamer.com/games/fps/wild-bastards-takes-every-ingredient-that-made-up-bioshocks-irrational-games-and-blends-it-with-cowboy-beans)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T21:00:38+00:00

This upcoming roguelike FPS shares the off-kilter character that made Void Bastards memorable.

## After two years of silence, Metal Slug Tactics returns with a new trailer and a promise that it's coming this fall
 - [https://www.pcgamer.com/movies-tv/after-two-years-of-silence-metal-slug-tactics-returns-with-a-new-trailer-and-a-promise-that-its-coming-this-fall](https://www.pcgamer.com/movies-tv/after-two-years-of-silence-metal-slug-tactics-returns-with-a-new-trailer-and-a-promise-that-its-coming-this-fall)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T20:40:31+00:00

Metal Slug Tactics announced a 2023 release in mid-2022, but instead of launching it fell off the map.

## Hot on the heels of its hit Fallout show, Amazon is releasing a 'gritty' series based on the Yakuza games later this year
 - [https://www.pcgamer.com/games/action/hot-on-the-heels-of-its-hit-fallout-show-amazon-is-releasing-a-gritty-series-based-on-the-yakuza-games-later-this-year](https://www.pcgamer.com/games/action/hot-on-the-heels-of-its-hit-fallout-show-amazon-is-releasing-a-gritty-series-based-on-the-yakuza-games-later-this-year)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T20:03:55+00:00

The tale of hardened gangster Kazuma Kiryu is coming to Prime in October.

## The future of gaming belongs to weird, little games
 - [https://www.pcgamer.com/gaming-industry/the-future-of-gaming-belongs-to-weird-little-games](https://www.pcgamer.com/gaming-industry/the-future-of-gaming-belongs-to-weird-little-games)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T19:43:06+00:00

After Manor Lords, Balatro, Animal Well, Content Warning, Abiotic Factor, it's clear that the future belongs to strange, funny.

## Team Fortress 2 plummets to Mostly Negative on Steam as its biggest fans stoke the righteous flames of anti-bot outrage
 - [https://www.pcgamer.com/games/fps/team-fortress-2-plummets-to-mostly-negative-on-steam-as-its-biggest-fans-stoke-the-righteous-flames-of-anti-bot-outrage](https://www.pcgamer.com/games/fps/team-fortress-2-plummets-to-mostly-negative-on-steam-as-its-biggest-fans-stoke-the-righteous-flames-of-anti-bot-outrage)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T19:33:51+00:00

You hate to see it.

## Less than 6 months after laying off 40 employees, Dead by Daylight studio Behaviour Interactive drops another 95
 - [https://www.pcgamer.com/gaming-industry/less-than-6-months-after-laying-off-40-employees-dead-by-daylight-studio-behaviour-interactive-drops-another-95](https://www.pcgamer.com/gaming-industry/less-than-6-months-after-laying-off-40-employees-dead-by-daylight-studio-behaviour-interactive-drops-another-95)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T18:48:08+00:00

It's all about "strategic changes for future growth."

## I tried to recreate Marvel's Iron Man in this movie studio sim, and my version was so bad my own father stormed out of the theater
 - [https://www.pcgamer.com/games/sim/i-tried-to-recreate-marvels-iron-man-in-this-movie-studio-sim-and-my-version-was-so-bad-my-own-father-stormed-out-of-the-theater](https://www.pcgamer.com/games/sim/i-tried-to-recreate-marvels-iron-man-in-this-movie-studio-sim-and-my-version-was-so-bad-my-own-father-stormed-out-of-the-theater)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T17:53:32+00:00

Create and edit your own films while managing a movie studio in Blockbuster Inc.

## The reason Framework laptops just keep getting better: 'We're blind to none of the feedback and we absorb it all'
 - [https://www.pcgamer.com/hardware/gaming-laptops/the-reason-framework-laptops-just-keep-getting-better-were-blind-to-none-of-the-feedback-and-we-absorb-it-all](https://www.pcgamer.com/hardware/gaming-laptops/the-reason-framework-laptops-just-keep-getting-better-were-blind-to-none-of-the-feedback-and-we-absorb-it-all)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T17:42:04+00:00

And when it comes to the AI PC trend, Framework wants to "make sure that there are as many options as possible and we will continue to scope out new partnerships."

## I was feeling a little needy so I sought reassurance from Jen-Hsun Huang and he told me it's all okay: 'I love PC gamers'
 - [https://www.pcgamer.com/hardware/graphics-cards/i-was-feeling-a-little-needy-so-i-sought-reassurance-from-jen-hsun-huang-and-he-told-me-its-all-okay-i-love-pc-gamers](https://www.pcgamer.com/hardware/graphics-cards/i-was-feeling-a-little-needy-so-i-sought-reassurance-from-jen-hsun-huang-and-he-told-me-its-all-okay-i-love-pc-gamers)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T16:58:14+00:00

After a Computex keynote that missed any of the big Nvidia gaming announcements from the show, I was worried he might not love us anymore.

## This is not a drill: Noctua's best fan yet is actually coming out this June
 - [https://www.pcgamer.com/hardware/cooling/this-is-not-a-drill-noctuas-best-fan-yet-is-actually-coming-out-this-june](https://www.pcgamer.com/hardware/cooling/this-is-not-a-drill-noctuas-best-fan-yet-is-actually-coming-out-this-june)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T16:42:57+00:00

It's happening! It's (probably) happening!

## Nvidia's CEO reckons that millions of AI GPUs will reduce power consumption, not increase it
 - [https://www.pcgamer.com/hardware/nvidias-ceo-reckons-that-millions-of-ai-gpus-will-reduce-power-consumption-not-increase-it](https://www.pcgamer.com/hardware/nvidias-ceo-reckons-that-millions-of-ai-gpus-will-reduce-power-consumption-not-increase-it)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T16:32:21+00:00

The more you AI, the less power you use!

## Qualcomm's CEO on AI performance in laptops: 'People talk about TOPS but they should be talking watts'
 - [https://www.pcgamer.com/hardware/processors/qualcomms-ceo-on-ai-performance-in-laptops-people-talk-about-tops-but-they-should-be-talking-watts](https://www.pcgamer.com/hardware/processors/qualcomms-ceo-on-ai-performance-in-laptops-people-talk-about-tops-but-they-should-be-talking-watts)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T16:03:56+00:00

NPUs in processors are all well and good, but not if they make them power-hungry.

## 'It's our way of making a statement in the face of targeted harassment': Tales of Kenzera: Zau director lowers the price of the game on Switch
 - [https://www.pcgamer.com/games/action/its-our-way-of-making-a-statement-in-the-face-of-targeted-harassment-tales-of-kenzera-zau-director-lowers-the-price-of-the-game-on-switch](https://www.pcgamer.com/games/action/its-our-way-of-making-a-statement-in-the-face-of-targeted-harassment-tales-of-kenzera-zau-director-lowers-the-price-of-the-game-on-switch)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T16:01:16+00:00

Abubakar Salim speaks out against the harassment that he and his team have faced.

## Guild Wars 2's next expansion will add its first new raid in five years, as well as 'the most player-friendly housing system in an MMORPG'
 - [https://www.pcgamer.com/games/mmo/guild-wars-2s-next-expansion-will-add-its-first-new-raid-in-five-years-as-well-as-the-most-player-friendly-housing-system-in-an-mmorpg](https://www.pcgamer.com/games/mmo/guild-wars-2s-next-expansion-will-add-its-first-new-raid-in-five-years-as-well-as-the-most-player-friendly-housing-system-in-an-mmorpg)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T16:00:00+00:00

Janthir Wilds will release on August 20.

## World of Warcraft's latest The War Within trailer has players simping hard for big baddie Xal'atath—and I'm not exactly surprised
 - [https://www.pcgamer.com/games/world-of-warcraft/world-of-warcraft-s-latest-the-war-within-trailer-has-players-simping-hard-for-big-baddie-xal-atath-and-i-m-not-exactly-surprised](https://www.pcgamer.com/games/world-of-warcraft/world-of-warcraft-s-latest-the-war-within-trailer-has-players-simping-hard-for-big-baddie-xal-atath-and-i-m-not-exactly-surprised)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T15:44:14+00:00

New word unlocked: "motherplane".

## A flood of reported privacy incidents from Google confirms, incidentally, that a Nintendo game leak from 2017 happened thanks to a YouTube contractor
 - [https://www.pcgamer.com/gaming-industry/a-flood-of-reported-privacy-incidents-from-google-confirms-incidentally-that-a-nintendo-game-leak-from-2017-happened-thanks-to-a-youtube-contractor](https://www.pcgamer.com/gaming-industry/a-flood-of-reported-privacy-incidents-from-google-confirms-incidentally-that-a-nintendo-game-leak-from-2017-happened-thanks-to-a-youtube-contractor)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T15:10:40+00:00

Yoshi? Oh no-shi.

## A liquid cooler with no pump: Noctua is working on a prototype targeting 'AIO level performance'
 - [https://www.pcgamer.com/hardware/cooling/a-liquid-cooler-with-no-pump-noctua-is-working-on-a-prototype-targeting-aio-level-performance](https://www.pcgamer.com/hardware/cooling/a-liquid-cooler-with-no-pump-noctua-is-working-on-a-prototype-targeting-aio-level-performance)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:59:57+00:00

The almighty thermosiphon.

## Nvidia's Jen-Hsun Huang reflects on how AI already creates pixels and entire frames, before saying that 'games will be generated with AI'
 - [https://www.pcgamer.com/software/ai/nvidias-jen-hsun-huang-reflects-on-how-ai-already-creates-pixels-and-entire-frames-before-saying-that-games-will-be-generated-with-ai](https://www.pcgamer.com/software/ai/nvidias-jen-hsun-huang-reflects-on-how-ai-already-creates-pixels-and-entire-frames-before-saying-that-games-will-be-generated-with-ai)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:47:37+00:00

Meshes, textures, and even complete NPCs could soon be AI-generated on gaming PCs.

## Genshin Impact Clorinde build—The best artifacts and weapons
 - [https://www.pcgamer.com/games/rpg/genshin-impact-clorinde-build](https://www.pcgamer.com/games/rpg/genshin-impact-clorinde-build)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:30:00+00:00

Ensure this duelist is a true champion.

## Genshin Impact Sethos build—The best artifacts and weapons
 - [https://www.pcgamer.com/games/rpg/genshin-impact-sethos-build](https://www.pcgamer.com/games/rpg/genshin-impact-sethos-build)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:30:00+00:00

How to make the most out of this railgun DPS unit.

## Ikea is hiring workers for its online Roblox store for £13.15 per hour, and you can even serve virtual meatballs
 - [https://www.pcgamer.com/software/platforms/ikea-is-hiring-workers-for-its-online-roblox-store-for-pound1315-per-hour-and-you-can-even-serve-virtual-meatballs](https://www.pcgamer.com/software/platforms/ikea-is-hiring-workers-for-its-online-roblox-store-for-pound1315-per-hour-and-you-can-even-serve-virtual-meatballs)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:03:23+00:00

Limited edition job.

## Hidetaka Miyazaki says Shadow of the Erdtree had to be big, because he wanted Elden Ring players 'to experience that sense of discovery and that sense of wonder' all over again
 - [https://www.pcgamer.com/games/rpg/hidetaka-miyazaki-erdtree-size-sense-of-discovery](https://www.pcgamer.com/games/rpg/hidetaka-miyazaki-erdtree-size-sense-of-discovery)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:00:52+00:00

In an interview with PC Gamer, Miyazaki hints at how massive Elden Ring's expansion truly is.

## Here's how Shadow of the Erdtree's new leveling system works
 - [https://www.pcgamer.com/games/rpg/elden-ring-shadow-of-the-erdtree-scadutree-fragments-revered-spirit-ash-blessings](https://www.pcgamer.com/games/rpg/elden-ring-shadow-of-the-erdtree-scadutree-fragments-revered-spirit-ash-blessings)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:00:40+00:00

Get ready to hunt down as many "Scadutree Fragments" as you can find.

## After 3 hours with Shadow of the Erdtree, I can already tell it's going to deliver on my favorite thing about FromSoftware's games: Exploration
 - [https://www.pcgamer.com/games/rpg/shadow-of-the-erdtree-preview-exploration](https://www.pcgamer.com/games/rpg/shadow-of-the-erdtree-preview-exploration)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:00:31+00:00

Elden Ring's DLC adopts the sense of scale and discovery so important to the base game.

## Elden Ring: Shadow of the Erdtree's new martial arts moveset let me spin kick a boss so fast it felt like I was in Sekiro
 - [https://www.pcgamer.com/games/rpg/elden-ring-shadow-of-the-erdtree-weapons-preview](https://www.pcgamer.com/games/rpg/elden-ring-shadow-of-the-erdtree-weapons-preview)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:00:18+00:00

The new martial arts weapon and throwing dagger push the pace of combat closer to Sekiro.

## Elden Ring: Shadow of the Erdtree is PC Gamer's next cover story: Here's a sneak peek
 - [https://www.pcgamer.com/games/rpg/shadow-of-the-erdtree-exclusive-pc-gamer-cover-story](https://www.pcgamer.com/games/rpg/shadow-of-the-erdtree-exclusive-pc-gamer-cover-story)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T14:00:00+00:00

Sitting down with Miyazaki to talk about capping off Elden Ring, his "ideal fantasy game," and more.

## MrBeast is now Mr Has The Most YouTube Subscribers
 - [https://www.pcgamer.com/hardware/streaming/mrbeast-is-now-mr-has-the-most-youtube-subscribers](https://www.pcgamer.com/hardware/streaming/mrbeast-is-now-mr-has-the-most-youtube-subscribers)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T13:53:43+00:00

You'll see this face over and over and over again until you die.

## Hyte is claiming its new AIO CPU cooler to be the quietest and coolest ever made
 - [https://www.pcgamer.com/hardware/cooling/hyte-is-claiming-its-new-aio-cpu-cooler-to-be-the-quietest-and-coolest-ever-made](https://www.pcgamer.com/hardware/cooling/hyte-is-claiming-its-new-aio-cpu-cooler-to-be-the-quietest-and-coolest-ever-made)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T13:40:27+00:00

"The raid boss of liquid coolers."

## Pax Dei, the new MMO from EVE alumni, is attempting a magic system that makes you feel special, where 'you might be the only one' who's discovered a new spell
 - [https://www.pcgamer.com/games/mmo/pax-dei-the-new-mmo-from-eve-alumni-is-attempting-a-magic-system-that-makes-you-feel-special-where-you-might-be-the-only-one-whos-discovered-a-new-spell](https://www.pcgamer.com/games/mmo/pax-dei-the-new-mmo-from-eve-alumni-is-attempting-a-magic-system-that-makes-you-feel-special-where-you-might-be-the-only-one-whos-discovered-a-new-spell)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T13:27:43+00:00

World first.

## Hyte's updated Y70 PC case range, with more colours and a better touchscreen, looks pretty darn lovely
 - [https://www.pcgamer.com/hardware/pc-cases/hytes-updated-y70-pc-case-range-with-more-colours-and-a-better-touchscreen-looks-pretty-darn-lovely](https://www.pcgamer.com/hardware/pc-cases/hytes-updated-y70-pc-case-range-with-more-colours-and-a-better-touchscreen-looks-pretty-darn-lovely)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T13:21:55+00:00

It's about time we had more options, other than the ubiquitous black or white.

## Pax Dei is an exciting 'social sandbox' from EVE alumni where you can be a medieval monarch, pope, or just make trousers all day—and it's out soon
 - [https://www.pcgamer.com/games/mmo/pax-dei-is-an-exciting-social-sandbox-from-eve-alumni-where-you-can-be-a-medieval-monarch-pope-or-just-make-trousers-all-dayand-its-out-soon](https://www.pcgamer.com/games/mmo/pax-dei-is-an-exciting-social-sandbox-from-eve-alumni-where-you-can-be-a-medieval-monarch-pope-or-just-make-trousers-all-dayand-its-out-soon)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T13:01:14+00:00

Find your place in a new civilisation from June 18.

## Tactical Breach Wizards, a turn-based strategy game about spec-ops casters with a habit of throwing people out of windows, has a free demo after years in the cauldron
 - [https://www.pcgamer.com/games/strategy/tactical-breach-wizards-a-turn-based-strategy-game-about-spec-ops-casters-with-a-habit-of-throwing-people-out-of-windows-has-a-free-demo-after-years-in-the-cauldron](https://www.pcgamer.com/games/strategy/tactical-breach-wizards-a-turn-based-strategy-game-about-spec-ops-casters-with-a-habit-of-throwing-people-out-of-windows-has-a-free-demo-after-years-in-the-cauldron)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T12:08:15+00:00

I cast Power Word: Gun at 9th level.

## Developer of the latest anime gacha hit apologises 5 times for launch issues in a single letter and doles out in-game treats like candy
 - [https://www.pcgamer.com/games/rpg/developer-of-the-latest-anime-gacha-hit-apologises-5-times-for-launch-issues-in-a-single-letter-and-doles-out-in-game-treats-like-candy](https://www.pcgamer.com/games/rpg/developer-of-the-latest-anime-gacha-hit-apologises-5-times-for-launch-issues-in-a-single-letter-and-doles-out-in-game-treats-like-candy)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T12:00:50+00:00

You get some crystal solvents, and you get some crystal solvents too!

## 'The Flame is lit': Dark Souls is getting a new manga and all I'm hoping for is something more horrifying than Elden Ring's one
 - [https://www.pcgamer.com/games/rpg/the-flame-is-lit-dark-souls-is-getting-a-new-manga-and-all-im-hoping-for-is-something-more-horrifying-than-elden-rings-one](https://www.pcgamer.com/games/rpg/the-flame-is-lit-dark-souls-is-getting-a-new-manga-and-all-im-hoping-for-is-something-more-horrifying-than-elden-rings-one)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T11:41:50+00:00

Time for something horrifying.

## Intel says it's happy to make the very Arm chips that threaten its x86 hegemony
 - [https://www.pcgamer.com/hardware/processors/intel-says-its-happy-to-make-the-very-arm-chips-that-threaten-its-x86-hegemony](https://www.pcgamer.com/hardware/processors/intel-says-its-happy-to-make-the-very-arm-chips-that-threaten-its-x86-hegemony)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T11:27:50+00:00

CEO Pat Gelsinger keeping his options open.

## Sony's PSVR 2 virtual reality headset will get an adaptor for PCs this summer but its best features will remain exclusive to PlayStation
 - [https://www.pcgamer.com/hardware/vr-hardware/sonys-psvr-2-virtual-reality-headset-will-get-an-adaptor-for-pcs-this-summer-but-its-best-features-will-remain-exclusive-to-playstation](https://www.pcgamer.com/hardware/vr-hardware/sonys-psvr-2-virtual-reality-headset-will-get-an-adaptor-for-pcs-this-summer-but-its-best-features-will-remain-exclusive-to-playstation)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T11:27:14+00:00

Sony just doing Sony things in the Sony way, I guess.

## Qualcomm CEO says 'you should expect to see Qualcomm in every PC form factor: From desktop to mini PCs, to tablets'
 - [https://www.pcgamer.com/hardware/processors/qualcomm-ceo-says-you-should-expect-to-see-qualcomm-in-every-pc-form-factor-from-desktop-to-mini-pcs-to-tablets](https://www.pcgamer.com/hardware/processors/qualcomm-ceo-says-you-should-expect-to-see-qualcomm-in-every-pc-form-factor-from-desktop-to-mini-pcs-to-tablets)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T11:18:15+00:00

Are we getting closer to a Snapdragon-based gaming PC? Maybe, just maybe.

## Test Drive Unlimited Solar Crown is the next open-world racer that seems destined for live service Hell
 - [https://www.pcgamer.com/games/racing/test-drive-unlimited-solar-crown-is-the-next-open-world-racer-that-seems-destined-for-live-service-hell](https://www.pcgamer.com/games/racing/test-drive-unlimited-solar-crown-is-the-next-open-world-racer-that-seems-destined-for-live-service-hell)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T11:07:31+00:00

Testing out Test Drive before it drives into testing territory.

## This irritating robot yelled at me repeatedly at Computex, forcing me to resist the urge to kick it over
 - [https://www.pcgamer.com/hardware/this-irritating-robot-yelled-at-me-repeatedly-at-computex-forcing-me-to-resist-the-urge-to-kick-it-over](https://www.pcgamer.com/hardware/this-irritating-robot-yelled-at-me-repeatedly-at-computex-forcing-me-to-resist-the-urge-to-kick-it-over)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T10:53:01+00:00

Johnny No. 5, this is not.

## Team Group showed me some blazingly fast Gen 5 SSDs, pink DDR5, and a host of wacky cooling solutions to keep it all in check
 - [https://www.pcgamer.com/hardware/ssds/team-group-showed-me-some-blazingly-fast-gen-5-ssds-pink-ddr5-and-a-host-of-wacky-cooling-solutions-to-keep-it-all-in-check](https://www.pcgamer.com/hardware/ssds/team-group-showed-me-some-blazingly-fast-gen-5-ssds-pink-ddr5-and-a-host-of-wacky-cooling-solutions-to-keep-it-all-in-check)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T10:23:10+00:00

Fast, furious, and flippin' hot, apparently.

## D&D's Wizards of the Coast come under fire for AI (again) after advertising for a 'principal AI engineer', but insists 'our stance on AI hasn't changed' since videogames don't count
 - [https://www.pcgamer.com/games/rpg/d-d-s-wizards-of-the-coast-come-under-fire-for-ai-again-after-advertising-for-a-principal-ai-engineer-but-insists-our-stance-on-ai-hasn-t-changed-since-videogames-don-t-count](https://www.pcgamer.com/games/rpg/d-d-s-wizards-of-the-coast-come-under-fire-for-ai-again-after-advertising-for-a-principal-ai-engineer-but-insists-our-stance-on-ai-hasn-t-changed-since-videogames-don-t-count)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T09:55:50+00:00

The ol' loophole.

## Witness the mighty Noctua power supply
 - [https://www.pcgamer.com/hardware/power-supplies/witness-the-mighty-noctua-power-supply](https://www.pcgamer.com/hardware/power-supplies/witness-the-mighty-noctua-power-supply)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T08:59:34+00:00

Made by Seasonic, improved by Noctua.

## Intel's latest processor is mostly made by its biggest manufacturing rival because it had 'a better process technology at that point in time'
 - [https://www.pcgamer.com/hardware/processors/intels-latest-processor-is-made-by-its-biggest-manufacturing-rival-because-it-had-a-better-process-technology-at-that-point-in-time](https://www.pcgamer.com/hardware/processors/intels-latest-processor-is-made-by-its-biggest-manufacturing-rival-because-it-had-a-better-process-technology-at-that-point-in-time)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T07:31:31+00:00

Though for its successor, Panther Lake, "almost all of the tiles are on Intel."

## Kingston gave me my first glimpse of CAMM2 DDR5 desktop RAM at Computex 2024, along with some AI-gen race drivers and a very heavy F1 theme
 - [https://www.pcgamer.com/hardware/memory/kingston-gave-me-my-first-glimpse-of-camm2-ddr5-ram-at-computex-2024-along-with-some-ai-gen-race-drivers-and-a-very-heavy-f1-theme](https://www.pcgamer.com/hardware/memory/kingston-gave-me-my-first-glimpse-of-camm2-ddr5-ram-at-computex-2024-along-with-some-ai-gen-race-drivers-and-a-very-heavy-f1-theme)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T04:48:34+00:00

Let's go racing towards flatter desktop memory, etc, etc.

## Today's Wordle answer for Tuesday, June 4
 - [https://www.pcgamer.com/games/puzzle/wordle-answer-today-june-4-2024](https://www.pcgamer.com/games/puzzle/wordle-answer-today-june-4-2024)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T03:00:44+00:00

Trouble solving today's Wordle? Here's the help you need.

## It's on: our first look at Intel Battlemage comes from Lunar Lake's new graphics silicon with its redesigned Xe2 architecture
 - [https://www.pcgamer.com/hardware/graphics-cards/embargo-no-pubits-on-our-first-look-at-intel-battlemage-comes-from-lunar-lakes-new-graphics-silicon-with-its-redesigned-xe2-architecture](https://www.pcgamer.com/hardware/graphics-cards/embargo-no-pubits-on-our-first-look-at-intel-battlemage-comes-from-lunar-lakes-new-graphics-silicon-with-its-redesigned-xe2-architecture)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T03:00:38+00:00

The Xe2 GPU architecture will power everything from low-power mobile chips to desktop graphics cards.

## One thread per core: 'we can deliver better than Hyper-Threading performance without Hyper-Threading' claims Intel for Lunar Lake
 - [https://www.pcgamer.com/hardware/processors/one-thread-per-core-we-can-deliver-better-than-hyper-threading-performance-without-hyper-threading-claims-intel-for-lunar-lake](https://www.pcgamer.com/hardware/processors/one-thread-per-core-we-can-deliver-better-than-hyper-threading-performance-without-hyper-threading-claims-intel-for-lunar-lake)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T03:00:27+00:00

New E-cores reportedly make up for the multithreaded performance lost.

## Intel talks shop about next-gen Lunar Lake processors: 'We will win in performance, we will win in graphics, we will win in AI'
 - [https://www.pcgamer.com/hardware/processors/intel-talks-shop-about-next-gen-lunar-lake-processors-we-will-win-in-performance-we-will-win-in-graphics-we-will-win-in-ai](https://www.pcgamer.com/hardware/processors/intel-talks-shop-about-next-gen-lunar-lake-processors-we-will-win-in-performance-we-will-win-in-graphics-we-will-win-in-ai)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T03:00:06+00:00

Lunar Lake comes with better graphics, cores, and memory. And more mentions of AI.

## Intel has made 'a tremendous amount of fixes for compatibility' in its Battlemage GPU architecture to ensure games run as they should
 - [https://www.pcgamer.com/hardware/graphics-cards/intel-has-made-a-tremendous-amount-of-fixes-for-compatibility-with-its-next-gpu-architecture-for-battlemage-to-ensure-games-run-as-they-should](https://www.pcgamer.com/hardware/graphics-cards/intel-has-made-a-tremendous-amount-of-fixes-for-compatibility-with-its-next-gpu-architecture-for-battlemage-to-ensure-games-run-as-they-should)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-06-04T03:00:05+00:00

There's more to a good graphics card than DirectX compatibility, says Intel's Tom Petersen.

