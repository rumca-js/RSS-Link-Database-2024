# Source:All3DP, URL:https://all3dp.com/feed/newsfeed, language:en

## Creality K2 Plus-CFS Combo Unit Preorders Open Tomorrow
 - [https://all3dp.com/4/creality-k2-plus-cfs-combo-unit-preorders-open-tomorrow](https://all3dp.com/4/creality-k2-plus-cfs-combo-unit-preorders-open-tomorrow)
 - RSS feed: https://all3dp.com/feed/newsfeed
 - date published: 2024-06-04T09:04:32+00:00

The K2 Plus is the latest in Creality’s K-series, with a 350 x 350 x 350 mm build volume, claimed speeds of 600 mm/s, while the CFS enables prints in up to 16 materials.

## Do 3D Printer Makers Have a Customer Service Problem?
 - [https://all3dp.com/1/do-3d-printer-makers-have-a-customer-service-problem](https://all3dp.com/1/do-3d-printer-makers-have-a-customer-service-problem)
 - RSS feed: https://all3dp.com/feed/newsfeed
 - date published: 2024-06-04T07:31:01+00:00

Which companies offer the better options for pre- and post-purchase customer support, refunds, and repairs?

