# Source:Climate Town, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA, language:en-US

## Natural Gas Will Ruin Your Day
 - [https://www.youtube.com/watch?v=cQ3UWS1HekM](https://www.youtube.com/watch?v=cQ3UWS1HekM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA
 - date published: 2024-06-04T21:27:24+00:00

Just a couple of quick natural gas facts in case you were wondering. See full vid (The Secret Life of Natural Gas) on the channel. And of course, don’t forget to take a look at our friends over at @HotAndToxic  -  for even more fun facts including how natural gas is full to the brim with all sorts of other compounds that will absolutely ruin your day. See hotandtoxic.com/#facts for more

