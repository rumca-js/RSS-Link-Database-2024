# Source:Tomasz Samołyk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg, language:pl-PL

## Jak zagłosować w eurowyborach #shorts
 - [https://www.youtube.com/watch?v=uywSv19HB4M](https://www.youtube.com/watch?v=uywSv19HB4M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg
 - date published: 2024-06-04T12:56:14+00:00



