# Source:Screen Junkies, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A, language:en-US

## Honest Trailers | Civil War
 - [https://www.youtube.com/watch?v=TN0pDnUtSDY](https://www.youtube.com/watch?v=TN0pDnUtSDY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A
 - date published: 2024-06-04T17:00:19+00:00

Honest Trailers | Civil War
Voice Narration: Jon Bailey aka Epic Voice Guy
Title Design: Robert Holtby
Written by: Spencer Gilbert, Lon Harris
Produced by: Spencer Gilbert
Edited by: Kevin Williamsen
Post-Production Manager: Emin Bassavand
Content Manager: Mikołaj Kossakowski
Post-Production Specialist: Rebecca Castaneda
VP Content: Max Dionne

#honesttrailers #civilwar #entertainment #trailer

