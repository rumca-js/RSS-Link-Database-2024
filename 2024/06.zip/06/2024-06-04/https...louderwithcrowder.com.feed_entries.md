# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed, language:en-US

## Residents Are Flabbergasted As To Why Thieves Are Stealing Fire Hydrants
 - [https://www.louderwithcrowder.com/los-angeles-fire-hydrants](https://www.louderwithcrowder.com/los-angeles-fire-hydrants)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-04T21:12:44+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=52378289&amp;width=600&amp;height=600&amp;coordinates=504%2C0%2C504%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>When your state is overrun with a <a href="https://ktla.com/news/local-news/flesh-eating-zombie-drug-saturating-los-angeles-streets/" rel="noopener noreferrer" target="_blank"><u>zombie </u></a>apocalypse and a shoplifting <a href="https://americafirstpolicy.com/issues/protecting-californias-retailers-from-theft#:~:text=An%20analysis%20of%20crime%20data,as%20it%20did%20pre%2Dpandemic." rel="noopener noreferrer" target="_blank"><u>epidemic</u></a>, criminals start to get bored. Thus, we give you the city’s newest problem, fire hydrant thefts.</p><div class

## The American Flag Is A "Hate Symbol" According To This (Shocker) DEI Trainer
 - [https://www.louderwithcrowder.com/dome-american-flag](https://www.louderwithcrowder.com/dome-american-flag)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-04T21:11:56+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=52378311&amp;width=600&amp;height=600&amp;coordinates=544%2C0%2C544%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>If you ask anyone with half a brain, they would tell you that the American flag represents freedom. However, if you ask someone who is mentally incompetent, they will tell you that it’s a symbol of hate. </p><p>A DEI trainer claimed that the flag was becoming a symbol of "hate" and "extremism." </p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">School district DEI trainer says American flag becoming 'hate' symbol, employees resisting CRT should be fired <a href="https://t.co/YcmZRdjrIr">https://t.co/YcmZRdjrIr</a><br />— Fox News (@Fo

## Watch: Father Punches Left-Wing "Comedian" Who Made Disgusting, Creepy Comments About His Baby
 - [https://www.louderwithcrowder.com/caravaca-punched-father](https://www.louderwithcrowder.com/caravaca-punched-father)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-04T21:10:12+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52377931&amp;width=600&amp;height=600&amp;coordinates=280%2C0%2C280%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>A deranged leftist comedian made comments about a Spanish man’s baby after he claimed: “he will become sick of sucking black d**k.” And because that is such a reprehensible and evil thing to say, the father punched him in the face, as any sane person should and would do. </p><p>Here is the moment comedian Jaime Caravaca realized that Twitter does not protect you in real life.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">🇪🇸 Leftist comedian Jaime Caravaca made creepy remarks about a 3-month-old boy.<br /><br />Today, the dad showe

## Mexico elects mucho woke first female president in what was also the deadliest election in the country's history
 - [https://www.louderwithcrowder.com/mexico-female-president](https://www.louderwithcrowder.com/mexico-female-president)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-04T18:02:31+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=52377668&amp;width=1200&amp;height=800&amp;coordinates=172%2C0%2C128%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Mexico made several historical victories in this presidential election. Not only was it the deadliest election with 37 candidates assassinated, but they also elected the first female president.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Gracias, gracias, gracias; no les voy a fallar. Vamos a avanzar con el Segundo Piso de la Cuarta Transformación. <a href="https://t.co/vwXlA7w54X">pic.twitter.com/vwXlA7w54X</a><br />— Dra. Claudia Sheinbaum (@Claudiashein) <a href="https://twitter.com/Claudiashein/status/1797562031173947588?re

## Watch: The Dictator Dic-Off Sadistic 16 (Part 1)
 - [https://www.louderwithcrowder.com/dictator-dic-off-worst](https://www.louderwithcrowder.com/dictator-dic-off-worst)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-04T16:03:51+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.webp?id=52377202&amp;width=1200&amp;height=800&amp;coordinates=97%2C0%2C98%2C0" /><br /><br /><p>Today’s show takes a look at the list of history's 16 biggest dictators to determine who is the biggest dic of all time. </p><p>"I promise you no matter what we go through today that Hitler is still the worst dictator no matter what," Crowder said.</p><div class="rm-embed embed-media"></div><p>Everyone knows Hitler’s bad. However, not everyone knows about the other bad state leaders, including Joseph Stalin, the Former Premier of the Soviet Union. But because Hitler is so widely known and he is very, very bad, he won’t be included in this dic-off because everyone already knows he is still the worst dictator of all time. However, Hitler will be the “yardstick” and other dictators will be measured by a Hitler rating system.<br /></p><p>The competition included the following dictators: Ayatollah Khomeini, Mao Zedong, Idi Amin, Jo

## Dictator Dic-Off Sadistic 16: The Most Out of Pocket Bracket You've EVER Seen
 - [https://www.louderwithcrowder.com/dictator-dic-off-sadistic](https://www.louderwithcrowder.com/dictator-dic-off-sadistic)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-04T14:04:38+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52376394&amp;width=1200&amp;height=800&amp;coordinates=300%2C0%2C0%2C0" /><br /><br /><p>The Great Dictator Dic-Off: Round of 16! Join us as we whittle down the list from our starting competitors, comparing the means and ends of history's biggest Dics to determine who in fact is the biggest Dic of all time!  A historical high-stakes showdown!</p><div class="rm-embed embed-media"></div>

## Watch: Mr. Rogers' song about "boys being boys" resurfaces, he sounds like he was trying to warn us
 - [https://www.louderwithcrowder.com/mr-rogers-boys-are-boys-song](https://www.louderwithcrowder.com/mr-rogers-boys-are-boys-song)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-04T13:49:22+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=32979340&amp;width=1200&amp;height=800&amp;coordinates=159%2C0%2C40%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Mr. Rogers tried to warn us. Sometime in the 60s, in between kicking it with Mr. McFeely and hanging out in the Land of Make-Believe, Fred Rogers knew what was up. He knew there were shadowy forces lurking, waiting to confuse children on sex and gender. So Mr. Rogers wrote a song about it ... in 1967.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">It’s like he tried to warn us… <a href="https://t.co/vXrXzqAJUO">pic.twitter.com/vXrXzqAJUO</a><br />— Louder with Crowder Dot Com (@LWCnewswire) <a href="https://twitter.com/LWCnewswire/

## Watch: Plates and hands start flying when dingbat makes the mistake of stepping to a Waffle House employee
 - [https://www.louderwithcrowder.com/best-waffle-house-brawls](https://www.louderwithcrowder.com/best-waffle-house-brawls)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-04T13:05:49+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52376143&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>We interrupt your regularly scheduled coverage of the <a href="https://www.louderwithcrowder.com/patricia-heaton-trump-conviction" target="_blank">lawfare waged against Donald Trump</a> and <a href="https://www.louderwithcrowder.com/drag-queen-kids-join-us" target="_blank">"family" "friendly" drag shows</a> to bring you another installment in our favorite genre of content: Waffle House Beatdowns! It's been a minute since we've seen a good video of it going down after hours at Waffle House.</p><div class="rm-embed embed-media"><blockquote class="twitter-twe

## Watch: Drag queen gives off Darth Vader vibes, declares "your children will love us" and "your children will JOIN US"
 - [https://www.louderwithcrowder.com/drag-queen-kids-join-us](https://www.louderwithcrowder.com/drag-queen-kids-join-us)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-04T11:37:00+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52374351&amp;width=1200&amp;height=800&amp;coordinates=155%2C0%2C45%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Who said it better? Darth Vader?</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="e8b50" src="https://www.louderwithcrowder.com/media-library/image.gif?id=52374361&amp;width=980" />
</p>
<p>Or whatever the hell this is?</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Liberals:<br /><br />“Conservatives are crazy, no one is going after your children.”<br /><br />Also Liberals: <br /><br />"Your children will see us. Your children will love us. And you children will JOIN US!" <a href

