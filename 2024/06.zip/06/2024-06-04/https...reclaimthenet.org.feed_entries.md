# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed, language:en-US

## Fauci Blames Free Speech for Pandemic Challenges in Contentious Testimony
 - [https://reclaimthenet.org/fauci-blames-free-speech-for-pandemic-challenges-in-contentious-testimony](https://reclaimthenet.org/fauci-blames-free-speech-for-pandemic-challenges-in-contentious-testimony)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-06-04T21:24:40+00:00

<a href="https://reclaimthenet.org/fauci-blames-free-speech-for-pandemic-challenges-in-contentious-testimony" rel="nofollow" title="Fauci Blames Free Speech for Pandemic Challenges in Contentious Testimony"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/06/fauci2-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Fauci hasn't changed.</p>
<p>The post <a href="https://reclaimthenet.org/fauci-blames-free-speech-for-pandemic-challenges-in-contentious-testimony">Fauci Blames Free Speech for Pandemic Challenges in Contentious Testimony</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Google’s Privacy Blunder: Sensitive Data and Kids’ Voices Scooped Up
 - [https://reclaimthenet.org/googles-privacy-blunder-sensitive-data-and-kids-voices-scooped-up](https://reclaimthenet.org/googles-privacy-blunder-sensitive-data-and-kids-voices-scooped-up)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-06-04T20:33:35+00:00

<a href="https://reclaimthenet.org/googles-privacy-blunder-sensitive-data-and-kids-voices-scooped-up" rel="nofollow" title="Google&#8217;s Privacy Blunder: Sensitive Data and Kids&#8217; Voices Scooped Up"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/06/goog-surv-e-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Thousands of internal reports reveal mishandling of sensitive data, including audio recordings of children on YouTube Kids and exposed addresses on Waze.</p>
<p>The post <a href="https://reclaimthenet.org/googles-privacy-blunder-sensitive-data-and-kids-voices-scooped-up">Google&#8217;s Privacy Blunder: Sensitive Data and Kids&#8217; Voices Scooped Up</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Justice Department Bizarrely Cites AI Threats to Deny Biden Audio Release
 - [https://reclaimthenet.org/justice-department-bizarrely-cites-ai-threats-to-deny-biden-audio-release](https://reclaimthenet.org/justice-department-bizarrely-cites-ai-threats-to-deny-biden-audio-release)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-06-04T19:09:02+00:00

<a href="https://reclaimthenet.org/justice-department-bizarrely-cites-ai-threats-to-deny-biden-audio-release" rel="nofollow" title="Justice Department Bizarrely Cites AI Threats to Deny Biden Audio Release"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/06/biden-a-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Concerns over AI deepfakes are cited as reason to withhold Biden-Hur audio recording from public release.</p>
<p>The post <a href="https://reclaimthenet.org/justice-department-bizarrely-cites-ai-threats-to-deny-biden-audio-release">Justice Department Bizarrely Cites AI Threats to Deny Biden Audio Release</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Hypocritical Move: E*Trade Reportedly Considers Shutting Down Roaring Kitty
 - [https://reclaimthenet.org/etrade-reportedly-considers-shutting-down-roaring-kitty](https://reclaimthenet.org/etrade-reportedly-considers-shutting-down-roaring-kitty)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-06-04T01:19:26+00:00

<a href="https://reclaimthenet.org/etrade-reportedly-considers-shutting-down-roaring-kitty" rel="nofollow" title="Hypocritical Move: E*Trade Reportedly Considers Shutting Down Roaring Kitty"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/06/roaring-kitty-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Retail investor Keith Gill's GameStop success story threatens Wall Street's dominance, exposing the hypocrisy of institutional market manipulation.</p>
<p>The post <a href="https://reclaimthenet.org/etrade-reportedly-considers-shutting-down-roaring-kitty">Hypocritical Move: E*Trade Reportedly Considers Shutting Down Roaring Kitty</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

