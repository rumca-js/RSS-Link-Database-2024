# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## Qualcomm wants 50% of the PC market by 2029
 - [https://www.pcworld.com/article/2356320/qualcomm-wants-50-of-the-pc-market-by-2029.html](https://www.pcworld.com/article/2356320/qualcomm-wants-50-of-the-pc-market-by-2029.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2024-06-04T15:37:45+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>The biggest news at Computex is how <a href="https://www.pcworld.com/article/2354660/qualcomm-says-snapdragon-is-coming-to-desktops.html">Snapdragon chips are storming the beaches</a> of the Windows-based PC market, spearheading <a href="https://www.pcworld.com/article/2337930/meet-the-future-of-windows-copilot-pcs-feature-practical-ai-tools.html">Microsoft&rsquo;s huge Copilot+ laptop push</a>. We&rsquo;ve seen Arm-based PC hardware before, but the designs have improved so much that they&rsquo;re meeting and sometimes beating the Intel and AMD competition. Qualcomm&rsquo;s CEO thinks they might be good enough to dominate, and do it very quickly. </p>



<p>Speaking to <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.tomshardware.com/pc-components/cpus/qualcomm-ceo-says-arm-taking-50-of-the-windows-pc-market-in-five-years-is-realistic-

## Qualcomm ‘won’t ever be done’ optimizing PC games for Snapdragon
 - [https://www.pcworld.com/article/2356255/qualcomm-wont-ever-be-done-optimizing-pc-games-for-snapdragon.html](https://www.pcworld.com/article/2356255/qualcomm-wont-ever-be-done-optimizing-pc-games-for-snapdragon.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2024-06-04T15:30:30+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>One of the outstanding questions that remain for PCs built upon the Qualcomm Snapdragon X Elite is just how well they&rsquo;ll run, especially games. Qualcomm executives said recently that they&rsquo;ve made great strides, but that you probably shouldn&rsquo;t expect every game will run perfectly.</p>



<p>Put another way: It sounds like Qualcomm will do its best&hellip;but.</p>



<p>In a call with reporters last Friday, Eric Demers, senior vice president of engineering at Qualcomm, said that Qualcomm will never be done optimizing games.</p>



<p>The Adreno X1 GPU inside the Qualcomm Snapdragon X Elite runs at about 1.5GHz, about 50 percent higher than any other mobile GPU that Qualcomm produces. We knew last year that Qualcomm had <a href="https://www.pcworld.com/article/2116395/qualcomms-latest-snapdragon-attracts-huge-pc-partnerships.html">attracted unprece

## How to protect your website from Open AI’s ChatGPT web crawlers
 - [https://www.pcworld.com/article/2347831/how-to-protect-your-website-from-ai-crawlers-from-open-ai-and-chatgpt.html](https://www.pcworld.com/article/2347831/how-to-protect-your-website-from-ai-crawlers-from-open-ai-and-chatgpt.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2024-06-04T14:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Since summer 2023, you can prevent the crawlers from the AI company Open AI from reading your website and making it part of the artificial intelligence ChatGPT, which can be found at <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://chat.openai.com&amp;xcust=2-1-2347831-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">https://chat.openai.com</a> and via Microsoft at <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=http://www.chat.bing.com&amp;xcust=2-1-2347831-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">www.chat.bing.com</a> as well as in a variety of Microsoft products. </p>



<p>Advantages of the crawler ban: With protection from AI crawlers, the text and images on your website will no longer be used to train the ChatGPT artificial intelligence in future. </p>





## Acer’s new 480Hz OLED gaming monitor is luscious 1440p speedster
 - [https://www.pcworld.com/article/2355390/acers-new-480hz-oled-gaming-monitor-is-luscious-1440p-speedster.html](https://www.pcworld.com/article/2355390/acers-new-480hz-oled-gaming-monitor-is-luscious-1440p-speedster.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2024-06-04T14:24:09+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Super-fast 480Hz gaming monitors have been more the domain of hyper twitchy esports players than casual gamers or streamers up until now, but that&rsquo;s quickly changing thanks to an influx of luscious, lightning-fast OLED displays this year. </p>



<p>CES 2024 was proof of that with 480Hz OLED displays from both Asus and LG; now Acer joins the super-quick monitor club unveiling a new 480Hz gaming monitor of its own &mdash; and at a more affordable starting price of $1199.99 than some rivals, I might add.</p>



<p>Acer&rsquo;s newest speed demon, the <a href="https://www.jdoqocy.com/click-8200811-15180503?sid=2-1-2355390-1-0-0&amp;url=https://www.acer.com/us-en/predator/monitors/x27u" rel="nofollow">Predator X27U F3</a>, fronts up with a 26.5-inch, 2560 x 1440p resolution that should render graphics in games like <em>Cyberpunk 2077</em> crisp enough for me to

## Get this mighty, RTX 4060-powered Asus gaming laptop for $300 off
 - [https://www.pcworld.com/article/2356201/get-this-mighty-rtx-4060-powered-asus-gaming-laptop-for-300-off.html](https://www.pcworld.com/article/2356201/get-this-mighty-rtx-4060-powered-asus-gaming-laptop-for-300-off.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2024-06-04T14:21:12+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>If you want an excellent laptop with a fantastic configuration, then the <a href="https://shop-links.co/link/?url=https%3A%2F%2Fwww.bestbuy.com%2Fsite%2Fasus-rog-zephyrus-g14-2024-14-oled-3k-120hz-gaming-laptop-amd-ryzen-9-8945hs-16gb-lpddr5x-geforce-rtx-4060-1tb-ssd-platinum-white%2F6570270.p%3FskuId%3D6570270&amp;publisher_slug=pcworld&amp;exclusive=1&amp;article_name=pcworld&amp;article_url=https%3A%2F%2Fwww.pcworld.com%2Ffeed&amp;u1=2-1-2356201-1-0-0" rel="nofollow">Asus ROG Zephyrus G14 is just the one for you as it&rsquo;s down to $1,300</a> over at Best Buy. This is an RTX 4060 laptop that will breeze through any task you throw its way.</p>



<p>This gaming laptop is equipped with an AMD Ryzen 9 8945HS processor, so you can expect speedy performance. There&rsquo;s even AI accelerators integrated into this processor, which promises to enhance your computin

## Asus’ new gaming headset lets you frag noobs and call mom at the same time
 - [https://www.pcworld.com/article/2355256/asus-new-gaming-headset-lets-you-frag-noobs-and-call-mom-at-the-same-time.html](https://www.pcworld.com/article/2355256/asus-new-gaming-headset-lets-you-frag-noobs-and-call-mom-at-the-same-time.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2024-06-04T13:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>This year&rsquo;s Computex might have you dreaming big of <a href="https://www.pcworld.com/article/2354673/arm-ceo-apple-woke-up-the-industry-on-the-art-of-the-possible.html">AI</a> and <a href="https://www.pcworld.com/article/2353326/amd-ryzen-9000-cpus-aim-to-defeat-intel-chips-in-high-end-desktop-pcs.html">high-end CPUs</a>, but there are a ton of great new gadget and peripheral announcements hidden under all of it as well. One of the coolest is the Asus ROG Delta II gaming headset.</p>



<p>A new gaming headset iteration might not seem that exciting, especially since it sports a similar design to other <a href="https://www.pcworld.com/article/2245342/rog-delta-s-wireless-review.html">ROG Delta headsets</a>. But don&rsquo;t let the exterior fool you &mdash; this bad boy will offer up some remarkable tech.&nbsp;</p>



<p>The most notable is Asus&rsquo; DualFl

## Now’s the time to get a PS5 as price drops to $399
 - [https://www.pcworld.com/article/2355637/nows-the-time-to-get-a-ps5-as-price-drops-to-399.html](https://www.pcworld.com/article/2355637/nows-the-time-to-get-a-ps5-as-price-drops-to-399.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2024-06-04T13:21:31+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>The PlayStation 5 is the console everybody wants and for good reason &mdash; there are tons of games to play, the experience is seamless and there are loads of features to upgrade your gaming experience. The best part is that the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.walmart.com/ip/Sony-PlayStation-5-PS5-Digital-Console-Slim/5113183757&amp;xcust=2-1-2355637-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">digital version is only $399</a> right now, which is the best price we&rsquo;ve seen for this model.</p>



<p>The PS5 with a disc is also on sale right now for $449, down from $500, so if you&rsquo;re often buying physical copies of your games, this is the best option for you.</p>



<p>Otherwise, going for the digital version means you&rsquo;re spending less money while getting the same quality experience and y

## This beginner-friendly 4K drone is $40 off now
 - [https://www.pcworld.com/article/2354958/this-beginner-friendly-4k-drone-is-40-off-now.html](https://www.pcworld.com/article/2354958/this-beginner-friendly-4k-drone-is-40-off-now.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2024-06-04T08:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Looking to start a new hobby this summer? With the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://shop.pcworld.com/sales/4k-dual-camera-obstacle-avoidance-drone-for-beginners-black?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=4k-dual-camera-obstacle-avoidance-drone-for-beginners-black&amp;utm_term=scsf-598059&amp;utm_content=a0xRn000001MyszIAC&amp;scsonar=1&amp;xcust=2-1-2354958-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">4K Dual-Camera Drone for Beginners with Intelligent Obstacle Avoidance</a>, you&rsquo;re in for hours of fun, and it&rsquo;s currently on sale through 6/9.</p>



<p>This beginner-friendly drone has a 4K front camera with a 90&ordm; control angle and a bottom camera with a 120&ordm; wide angle, allowing you to capture complete vistas while you&rsquo;re flying up high. O

## Intel’s Lunar Lake is actually made at TSMC
 - [https://www.pcworld.com/article/2355435/intels-lunar-lake-is-actually-made-at-tsmc.html](https://www.pcworld.com/article/2355435/intels-lunar-lake-is-actually-made-at-tsmc.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2024-06-04T06:26:57+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Lunar Lake marks perhaps the first time that an Intel PC processor wasn&rsquo;t manufactured at Intel.</p>



<p><a href="https://www.pcworld.com/article/2350967/intels-lunar-lake-debuts-combining-low-power-performance-and-ai.html">Intel&rsquo;s Lunar Lake has four tiles</a>, of which the key tiles &mdash; the compute tile and the controller tiles &mdash; are built at TSMC, not Intel. Intel&rsquo;s Meteor Lake also used TSMC for manufacturing, but the key compute tile was built at Intel.</p>



<p>Meanwhile, Intel has launched its own foundry program, talked up a program to achieve five process nodes in four years, and has <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.intel.com/content/www/us/en/newsroom/resources/us-chips-act-funding-intel.html&amp;xcust=2-1-2355435-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">accept

