# Source:DEON.pl, URL:https://deon.pl/rss, language:pl

## Wielu z nas przypomina biblijnych saduceuszy. Często myślimy nie tak, jak uczył Jezus
 - [https://deon.pl/wiara/komentarze-do-ewangelii/wielu-z-nas-przypomina-biblijnych-saduceuszy-czesto-myslimy-nie-tak-jak-uczyl-jezus,2835032](https://deon.pl/wiara/komentarze-do-ewangelii/wielu-z-nas-przypomina-biblijnych-saduceuszy-czesto-myslimy-nie-tak-jak-uczyl-jezus,2835032)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T22:00:01+00:00



## Morze, góry, a może remont? Najnowszy sondaż pokazuje, gdzie Polacy chcą spędzić wakacyjny urlop
 - [https://deon.pl/swiat/morze-gory-a-moze-remont-najnowszy-sondaz-pokazuje-gdzie-polacy-chca-spedzic-wakacyjny-urlop,2835671](https://deon.pl/swiat/morze-gory-a-moze-remont-najnowszy-sondaz-pokazuje-gdzie-polacy-chca-spedzic-wakacyjny-urlop,2835671)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T14:31:15+00:00



## Zamiast kościoła - restauracja, zamiast ołtarza - bar? Biskup przestrzega wiernych
 - [https://deon.pl/kosciol/zamiast-kosciola---restauracja-zamiast-oltarza---bar-biskup-przestrzega-wiernych,2835608](https://deon.pl/kosciol/zamiast-kosciola---restauracja-zamiast-oltarza---bar-biskup-przestrzega-wiernych,2835608)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T14:15:34+00:00



## Zajmij wygodną pozycje i wybierz święte słowo. Następny krok należy do Boga
 - [https://deon.pl/wiara/zajmij-wygodna-pozycje-i-wybierz-swiete-slowo-nastepny-krok-nalezy-do-boga,2828558](https://deon.pl/wiara/zajmij-wygodna-pozycje-i-wybierz-swiete-slowo-nastepny-krok-nalezy-do-boga,2828558)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T12:54:23+00:00



## Wśród zabitych zakładników Hamasu dwóch obywateli RP. Wroński: mogli nie wiedzieć, że mają polskie obywatelstwo
 - [https://deon.pl/swiat/wsrod-zabitych-zakladnikow-hamasu-dwoch-obywateli-rp-wronski-mogli-nie-wiedziec-ze-maja-polskie-obywatelstwo,2835404](https://deon.pl/swiat/wsrod-zabitych-zakladnikow-hamasu-dwoch-obywateli-rp-wronski-mogli-nie-wiedziec-ze-maja-polskie-obywatelstwo,2835404)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T12:37:35+00:00



## Przekonałam się, że Jezus uzdrawia cicho i powoli, ucząc nas cierpliwości [ŚWIADECTWO]
 - [https://deon.pl/wiara/przekonalam-sie-ze-jezus-uzdrawia-cicho-i-powoli-uczac-nas-cierpliwosci-swiadectwo,2835071](https://deon.pl/wiara/przekonalam-sie-ze-jezus-uzdrawia-cicho-i-powoli-uczac-nas-cierpliwosci-swiadectwo,2835071)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T11:52:52+00:00



## Uczy matematyki w Łodzi i właśnie została dziewicą konsekrowaną. To decyzja życia
 - [https://deon.pl/kosciol/uczy-matematyki-w-lodzi-i-wlasnie-zostala-dziewica-konsekrowana-to-decyzja-zycia,2835062](https://deon.pl/kosciol/uczy-matematyki-w-lodzi-i-wlasnie-zostala-dziewica-konsekrowana-to-decyzja-zycia,2835062)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T11:49:41+00:00



## Zmarła jedna ze wschodzących gwiazd "Mam talent!". Jej chrześcijańskie utwory zachwycały publiczność i jurorów
 - [https://deon.pl/po-godzinach/zmarla-jedna-ze-wschodzacych-gwiazd-mam-talent-jej-chrzescijanskie-utwory-zachwycaly-publicznosc-i-jurorow,2834939](https://deon.pl/po-godzinach/zmarla-jedna-ze-wschodzacych-gwiazd-mam-talent-jej-chrzescijanskie-utwory-zachwycaly-publicznosc-i-jurorow,2834939)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T10:54:31+00:00



## Z dziećmi na mszę, jeśli nie przeszkadzają? Ksiądz wyjaśnia, kiedy zabierać dzieci na Eucharystię
 - [https://deon.pl/wiara/duchowosc/z-dziecmi-na-msze-jesli-nie-przeszkadzaja-ksiadz-wyjasnia-kiedy-zabierac-dzieci-na-eucharystie,2834807](https://deon.pl/wiara/duchowosc/z-dziecmi-na-msze-jesli-nie-przeszkadzaja-ksiadz-wyjasnia-kiedy-zabierac-dzieci-na-eucharystie,2834807)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T10:37:46+00:00



## Starcia przy sanktuarium w Fatimie. Burmistrz zabrał głos
 - [https://deon.pl/kosciol/starcia-przy-sanktuarium-w-fatimie-burmistrz-zabral-glos,2835026](https://deon.pl/kosciol/starcia-przy-sanktuarium-w-fatimie-burmistrz-zabral-glos,2835026)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T10:33:31+00:00



## Nie żyje aktor, satyryk i poseł Janusz Rewiński. "Buenas noches, Senior Siarra!"
 - [https://deon.pl/swiat/nie-zyje-aktor-satyryk-i-posel-januszrewinski-buenas-noches-senior-siarra,2834765](https://deon.pl/swiat/nie-zyje-aktor-satyryk-i-posel-januszrewinski-buenas-noches-senior-siarra,2834765)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T10:15:24+00:00



## Położony jest na stromej skale nad brzegiem Dunajca. Poznaj jeden z najbardziej malowniczych kościołów w Polsce [WIDEO]
 - [https://deon.pl/po-godzinach/polozony-jest-na-stromej-skale-nad-brzegiem-dunajca-poznaj-jeden-z-najbardziej-malowniczych-kosciolow-w-polsce-wideo,2834726](https://deon.pl/po-godzinach/polozony-jest-na-stromej-skale-nad-brzegiem-dunajca-poznaj-jeden-z-najbardziej-malowniczych-kosciolow-w-polsce-wideo,2834726)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T08:59:29+00:00



## Gdynia: Do portu wpłynął kontener z nielegalnymi farmaceutykami. Służby udaremniły przemyt
 - [https://deon.pl/swiat/gdynia-do-portu-wplynal-kontener-z-nielegalnymi-farmaceutykami-sluzby-udaremnily-przemyt,2834663](https://deon.pl/swiat/gdynia-do-portu-wplynal-kontener-z-nielegalnymi-farmaceutykami-sluzby-udaremnily-przemyt,2834663)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T08:11:28+00:00



## W piątek 7 czerwca ważna uroczystość. Katolików nie obowiązuje post od pokarmów mięsnych
 - [https://deon.pl/kosciol/w-piatek-7-czerwca-wazna-uroczystosc-katolikow-nie-obowiazuje-post-od-pokarmow-miesnych,2834567](https://deon.pl/kosciol/w-piatek-7-czerwca-wazna-uroczystosc-katolikow-nie-obowiazuje-post-od-pokarmow-miesnych,2834567)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T08:03:36+00:00



## "Cud w Pompejach". Naukowcy znaleźli w zniszczonym mieście niezwykłe pomieszczenie
 - [https://deon.pl/swiat/cud-w-pompejach-naukowcy-znalezli-w-zniszczonym-miescie-niezwykle-pomieszczenie,2834666](https://deon.pl/swiat/cud-w-pompejach-naukowcy-znalezli-w-zniszczonym-miescie-niezwykle-pomieszczenie,2834666)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T07:57:59+00:00



## Uczestniczka Szkoły Biblijnej Diecezji Bydgoskiej: Przestałam się bać Biblii
 - [https://deon.pl/kosciol/uczestniczka-szkoly-biblijnej-diecezji-bydgoskiej-przestalam-sie-bac-biblii,2834585](https://deon.pl/kosciol/uczestniczka-szkoly-biblijnej-diecezji-bydgoskiej-przestalam-sie-bac-biblii,2834585)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T07:50:51+00:00



## Najpiękniejsze słowo świata…
 - [https://deon.pl/wiara/duchowosc/najpiekniejsze-slowo-swiata,2834318](https://deon.pl/wiara/duchowosc/najpiekniejsze-slowo-swiata,2834318)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T07:15:00+00:00



## Najpiękniejsze słowo świata. Ono odpowiada na najgłębszą potrzebę człowieka
 - [https://deon.pl/wiara/duchowosc/najpiekniejsze-slowo-swiata-ono-odpowiada-na-najglebsza-potrzebe-czlowieka,2834318](https://deon.pl/wiara/duchowosc/najpiekniejsze-slowo-swiata-ono-odpowiada-na-najglebsza-potrzebe-czlowieka,2834318)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T07:15:00+00:00



## Tragedia w Fatimie. 25-latek zasztyletowany w pobliżu sanktuarium maryjnego
 - [https://deon.pl/swiat/tragedia-w-fatimie-25-latek-zasztyletowany-w-poblizu-sanktuarium-maryjnego,2834549](https://deon.pl/swiat/tragedia-w-fatimie-25-latek-zasztyletowany-w-poblizu-sanktuarium-maryjnego,2834549)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T07:07:25+00:00



## Nie żyje ks. Maciej Chmielewski. Był egzorcystą, przed śmiercią wypowiedział piękne słowa
 - [https://deon.pl/kosciol/nie-zyje-ks-maciej-chmielewski-byl-egzorcysta-przed-smiercia-wypowiedzial-piekne-slowa,2834450](https://deon.pl/kosciol/nie-zyje-ks-maciej-chmielewski-byl-egzorcysta-przed-smiercia-wypowiedzial-piekne-slowa,2834450)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T06:28:32+00:00



## Najpiękniejsze słowo świata… | Podcast Dialogi w połowie drogi - odc. II/40 (58)
 - [https://deon.pl/podcast-dialogi-w-polowie-drogi/najpiekniejsze-slowo-swiata--podcast-dialogi-w-polowie-drogi---odc-ii40-58,2834294](https://deon.pl/podcast-dialogi-w-polowie-drogi/najpiekniejsze-slowo-swiata--podcast-dialogi-w-polowie-drogi---odc-ii40-58,2834294)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T06:00:00+00:00



## Modlitwa oddania się Jezusowi. Odmawiaj ją, by ogarniać swoje życie
 - [https://deon.pl/wiara/duchowosc/modlitwa-oddania-sie-jezusowi-odmawiaj-ja-by-ogarniac-swoje-zycie,2834408](https://deon.pl/wiara/duchowosc/modlitwa-oddania-sie-jezusowi-odmawiaj-ja-by-ogarniac-swoje-zycie,2834408)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T05:19:39+00:00



## Jezus zna nas do głębi. Zna nasze starania, udawanie, błędy i nie traci do nas cierpliwości
 - [https://deon.pl/wiara/jezus-zna-nas-do-glebi-zna-nasze-starania-udawanie-bledy-i-nie-traci-do-nas-cierpliwosci-,2834357](https://deon.pl/wiara/jezus-zna-nas-do-glebi-zna-nasze-starania-udawanie-bledy-i-nie-traci-do-nas-cierpliwosci-,2834357)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-06-04T04:05:45+00:00



