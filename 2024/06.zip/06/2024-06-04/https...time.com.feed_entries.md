# Source:TIME, URL:https://time.com/feed, language:en-UK

## Last WWII Vets Converge on Normandy for D-Day and Fallen Friends
 - [https://time.com/6985650/wwii-vets-converge-normandy-d-day](https://time.com/6985650/wwii-vets-converge-normandy-d-day)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T21:55:03+00:00

As decades pass, D-Day anniversaries in Normandy have become increasingly fun-fair like.

## The-Dream, Famed Music Producer for Beyoncé, Accused of Rape in New Lawsuit
 - [https://time.com/6985520/the-dream-producer-accused-rape](https://time.com/6985520/the-dream-producer-accused-rape)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T20:19:08+00:00

A former protégée of music producer The-Dream says she was lured into an abusive relationship with him in a new lawsuit

## Halsey Says She’s ‘Lucky to Be Alive’ After Battling Illness
 - [https://time.com/6985582/halsey-reveals-illness-the-end-song](https://time.com/6985582/halsey-reveals-illness-the-end-song)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T20:10:22+00:00

Halsey has released a new song, "The End," and revealed that she has been fighting an illness.

## Southwest U.S. to Bake in First Heat Wave of Season, With Highs Topping Record Breaking 110 Degrees
 - [https://time.com/6985559/southwest-u-s-heat-wave-record-breaking](https://time.com/6985559/southwest-u-s-heat-wave-record-breaking)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T19:26:51+00:00

The first heat wave of the season is bringing triple-digit temperatures earlier than usual to much of the Southwest.

## Debunking 12 Myths About Trump’s Conviction
 - [https://time.com/6985532/trump-conviction-myths-debunked-essay](https://time.com/6985532/trump-conviction-myths-debunked-essay)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T19:17:45+00:00

American legal expert Barbara McQuade breaks down several false claims about Trump's conviction being rigged.

## In Indonesia, Women Rangers Go on Patrol to Slow Deforestation
 - [https://time.com/6985546/indonesia-women-rangers-deforestation](https://time.com/6985546/indonesia-women-rangers-deforestation)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T19:05:24+00:00

A vast tropical archipelago stretching across the equator, Indonesia is home to the world’s third-largest rainforest.

## Watch Live: Biden to Sign Executive Order That Would Severely Limit Asylum at U.S.-Mexico Border
 - [https://time.com/6985518/watch-biden-executive-order-asylum-border](https://time.com/6985518/watch-biden-executive-order-asylum-border)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T18:03:14+00:00

President Joe Biden is set to sign an executive order that would allow his Administration to halt asylum claims at the U.S.-Mexico border.

## MLB Bans Tucupita Marcano for Life for Betting on Baseball
 - [https://time.com/6985479/mlb-bans-tucupita-marcano-betting-baseball](https://time.com/6985479/mlb-bans-tucupita-marcano-betting-baseball)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T17:13:51+00:00

Tucupita Marcano was banned from baseball for life for betting on the sport and four others were suspended by Major League Baseball.

## Narendra Modi Secured a Third Term as India’s Prime Minister—But With Less Power Than Expected
 - [https://time.com/6985447/india-election-results-modi-bjp](https://time.com/6985447/india-election-results-modi-bjp)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T17:05:53+00:00

India's ruling party fell short of winning a single-party majority, marking a stark departure from the last two elections.

## What Nigel Farage Means for the U.K. Election
 - [https://time.com/6985435/nigel-farage-uk-election-campaign](https://time.com/6985435/nigel-farage-uk-election-campaign)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T16:14:54+00:00

Brexit champion Nigel Farage is launching his eighth attempt at a seat in the House of Commons in July's general election.

## Biden to Sign Executive Order That Would Severely Limit Asylum at U.S.-Mexico Border
 - [https://time.com/6985347/biden-executive-order-border-immigration-asylum](https://time.com/6985347/biden-executive-order-border-immigration-asylum)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T16:00:00+00:00

The measure allows President Joe Biden to halt asylum claims when they reach 2,500 per day. They now average 3,800.

## ‘We Had to Meet.’ How Two Israeli-Palestinian Peace Groups Are Grieving Together
 - [https://time.com/6985173/israeli-palestinian-peace-groups-grieving-essay](https://time.com/6985173/israeli-palestinian-peace-groups-grieving-essay)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T15:07:31+00:00

Eetta Prince-Gibson explores how Combatants for Peace and the Parents’ Circle are mourning for Israelis and Palestinians amid the war.

## How to Navigate Dating When You Have IBD
 - [https://time.com/6985349/dating-with-ibd](https://time.com/6985349/dating-with-ibd)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T14:06:33+00:00

Plenty of people with IBD have vibrant, loving, and intimate relationships.

## Instead of Calling in Law Enforcement to Deal With Protesters, College Presidents Could Have Followed This Example
 - [https://time.com/6984701/college-presidents-protest-history](https://time.com/6984701/college-presidents-protest-history)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T13:00:00+00:00

Successes that came when presidents protected student protesters from outside meddling are worth remembering when students return to campus.

## Modi May Fall Short of Landslide Indian Election Win, Early Results Indicate
 - [https://time.com/6985324/india-election-results-2](https://time.com/6985324/india-election-results-2)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T11:11:42+00:00

Prime Minister Narenda's Modi Bharatiya Janata Party leads the vote, but early results suggest it may not win a coveted supermajority.

## 15 LGBTQ+ Books to Read for Pride
 - [https://time.com/6983238/best-lgbtq-books-pride](https://time.com/6983238/best-lgbtq-books-pride)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T11:00:00+00:00

Suggestions from author Kristen Arnett

## Fact-Checking What President Joe Biden Said in His 2024 Interview With TIME
 - [https://time.com/6985020/joe-biden-fact-check-2024-interview](https://time.com/6985020/joe-biden-fact-check-2024-interview)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T11:00:00+00:00

President Joe Biden sat down with TIME for an exclusive interview. Here's a fact-check of what he said.

## Read the Full Transcript of President Joe Biden’s Interview With TIME
 - [https://time.com/6984968/joe-biden-transcript-2024-interview](https://time.com/6984968/joe-biden-transcript-2024-interview)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T11:00:00+00:00

The President spoke with TIME about his foreign policy agenda.

## The Story Behind TIME’s ‘If He Wins’ President Biden Cover
 - [https://time.com/6985018/joe-biden-interview-story-behind-2024](https://time.com/6985018/joe-biden-interview-story-behind-2024)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T11:00:00+00:00

This is the third interview Joe Biden has given to TIME since he announced his candidacy for President in 2019

## This Psychologist Just Won $1.3 Million for Her Work on Trauma and Repair
 - [https://time.com/6985071/pumla-gobodo-madikizela-templeton-prize](https://time.com/6985071/pumla-gobodo-madikizela-templeton-prize)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T11:00:00+00:00

Every year since 1972, the Templeton Foundation has given a Nobel Prize-sized amount of money to a researcher who is exploring in a rigorous, scientific way &#8220;the deepest questions of the universe and humankind&#8217;s place and purpose within it.&#8221; This year the $1.3 million prize is going to Pumla Gobodo-Madikizela, a psychologist and professor at&#8230;

## ‘We Are the World Power.’ How Joe Biden Leads
 - [https://time.com/6984970/joe-biden-2024-interview](https://time.com/6984970/joe-biden-2024-interview)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T11:00:00+00:00

During his 40 months in office, events have tested Biden’s vision of American world leadership

## Major K-Pop Agency SM Entertainment Holds First-Ever Global Auditions to Form Girl Group
 - [https://time.com/6985315/k-pop-sm-entertainment-global-audition-girl-group](https://time.com/6985315/k-pop-sm-entertainment-global-audition-girl-group)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T09:35:00+00:00

SM Entertainment announced its first-ever global audition to assemble a new girl group as K-pop looks worldwide for its next generation of idols.

## 83-Year-Old Woman Seriously Injured After Goring by Bison at Yellowstone National Park
 - [https://time.com/6985305/yellowstone-national-park-bison-attack-woman-injured](https://time.com/6985305/yellowstone-national-park-bison-attack-woman-injured)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T07:00:00+00:00

Officials said the bison was defending its space when it lifted a woman about a foot off the ground with its horns, causing serious injury.

## U.S. Urges U.N. Security Council to Support Biden’s Gaza Ceasefire Plan
 - [https://time.com/6985300/us-united-nations-support-biden-ceasefire-proposal-israel-gaza](https://time.com/6985300/us-united-nations-support-biden-ceasefire-proposal-israel-gaza)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T06:45:00+00:00

The three-phase plan is aimed at ending the war in Gaza, freeing all hostages, and sending massive aid into the devastated territory. Israeli Prime Minister Benjamin Netanyahu also reportedly said it would meet Israel’s goal of destroying Hamas.

## Beijing and Hong Kong Tighten Security on Tiananmen Square Massacre’s 35th Anniversary
 - [https://time.com/6985297/tiananmen-square-massacre-35th-anniversary-beijing-hong-kong-police-censorship](https://time.com/6985297/tiananmen-square-massacre-35th-anniversary-beijing-hong-kong-police-censorship)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T06:30:00+00:00

Thirty-five years after a bloody crackdown on pro-democracy protests, policing and censorship have ramped up in Beijing and Hong Kong to prevent public gathering and grieving.

## Facing Personnel Shortfall, Australia’s Military to Recruit Foreigners Amid Defense Upgrades
 - [https://time.com/6985285/australia-military-recruit-foreigners-defense-china](https://time.com/6985285/australia-military-recruit-foreigners-defense-china)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T02:55:00+00:00

The move comes as Australia upgrades its defense forces to try to counter China’s expanding military footprint in the Asia-Pacific region.

## With Independent Bid, Corruption-Charged Sen. Menendez Puts Safe Democratic Seat at Risk
 - [https://time.com/6985279/bob-menendez-independent-campaign-senate-new-jersey-democratic-seat-risk](https://time.com/6985279/bob-menendez-independent-campaign-senate-new-jersey-democratic-seat-risk)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T02:30:00+00:00

The move could be costly for Democrats trying to hold on to what has been seen as a safe Senate seat: Menendez could play the role of spoiler if a significant chunk of voters stick with him.

## Drinking On Planes Could Be Bad For You, New Study Finds
 - [https://time.com/6985273/alcohol-planes-health-heart-study](https://time.com/6985273/alcohol-planes-health-heart-study)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T01:30:54+00:00

The next time you board a long flight and decide to enjoy an alcoholic drink before taking a nap, you might want to avoid the temptation.

## Janis Paige, Hollywood and Broadway Star, Dies at 101
 - [https://time.com/6985264/janis-paige-hollywood-and-broadway-star-dies-at-101](https://time.com/6985264/janis-paige-hollywood-and-broadway-star-dies-at-101)
 - RSS feed: https://time.com/feed
 - date published: 2024-06-04T00:28:27+00:00

Janis Paige died Sunday of natural causes at her Los Angeles home, longtime friend Stuart Lampert said Monday.

