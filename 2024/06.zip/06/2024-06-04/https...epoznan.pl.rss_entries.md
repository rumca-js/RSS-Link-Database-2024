# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Każdy może dostać taką wiadomość. &quot;Adresat jest zobowiązany do udzielenia odpowiedzi&quot;
 - [https://epoznan.pl/news-news-151511-kazdy_moze_dostac_taka_wiadomosc_adresat_jest_zobowiazany_do_udzielenia_odpowiedzi?rss=1](https://epoznan.pl/news-news-151511-kazdy_moze_dostac_taka_wiadomosc_adresat_jest_zobowiazany_do_udzielenia_odpowiedzi?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T20:30:00+00:00

Ostrzega Centralne Biuro Zwalczania Cyberprzestępczości.

## Z jednego z wielkopolskich szpitali zniknie Odział Neurologiczny?
 - [https://epoznan.pl/news-news-151510-z_jednego_z_wielkopolskich_szpitali_zniknie_odzial_neurologiczny?rss=1](https://epoznan.pl/news-news-151510-z_jednego_z_wielkopolskich_szpitali_zniknie_odzial_neurologiczny?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T20:22:00+00:00

Powodem ma być brak lekarzy.

## Przed nami kilka głośnych nocy w centrum miasta!
 - [https://epoznan.pl/news-news-151506-przed_nami_kilka_glosnych_nocy_w_centrum_miasta?rss=1](https://epoznan.pl/news-news-151506-przed_nami_kilka_glosnych_nocy_w_centrum_miasta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T20:12:00+00:00

To przez korekty na torowiskach.

## Przed nami kilka głośnych nocy w centrum miasta! &quot;Przepraszamy&quot;
 - [https://epoznan.pl/news-news-151506-przed_nami_kilka_glosnych_nocy_w_centrum_miasta_przepraszamy?rss=1](https://epoznan.pl/news-news-151506-przed_nami_kilka_glosnych_nocy_w_centrum_miasta_przepraszamy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T20:12:00+00:00

To przez korekty na torowiskach.

## Duża impreza z gwiazdami szykuje się w Poznaniu. Wstęp wolny!
 - [https://epoznan.pl/news-news-151493-duza_impreza_z_gwiazdami_szykuje_sie_w_poznaniu_wstep_wolny?rss=1](https://epoznan.pl/news-news-151493-duza_impreza_z_gwiazdami_szykuje_sie_w_poznaniu_wstep_wolny?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T20:00:00+00:00

Na Cytadeli.

## Ukraiński gigant przejął firmę i zwolnił całą załogę. Dyrekcja zabrała głos
 - [https://epoznan.pl/news-news-151508-ukrainski_gigant_przejal_firme_i_zwolnil_cala_zaloge_dyrekcja_zabrala_glos?rss=1](https://epoznan.pl/news-news-151508-ukrainski_gigant_przejal_firme_i_zwolnil_cala_zaloge_dyrekcja_zabrala_glos?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T19:55:00+00:00

Stwierdzono, że działalność zakładu była nieopłacalna.

## Będą budować sieć kanalizacyjną pod Poznaniem. Do września utrudnienia. Są szczegóły
 - [https://epoznan.pl/news-news-151509-beda_budowac_siec_kanalizacyjna_pod_poznaniem_do_wrzesnia_utrudnienia_sa_szczegoly?rss=1](https://epoznan.pl/news-news-151509-beda_budowac_siec_kanalizacyjna_pod_poznaniem_do_wrzesnia_utrudnienia_sa_szczegoly?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T19:45:00+00:00

W Luboniu.

## 40-latek ugryzł policjanta na miejskiej imprezie
 - [https://epoznan.pl/news-news-151505-40_latek_ugryzl_policjanta_na_miejskiej_imprezie?rss=1](https://epoznan.pl/news-news-151505-40_latek_ugryzl_policjanta_na_miejskiej_imprezie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T19:30:00+00:00

Ma więcej na sumieniu.

## Interwencja podczas miejskiej imprezy. 40-latek... ugryzł policjanta
 - [https://epoznan.pl/news-news-151505-interwencja_podczas_miejskiej_imprezy_40_latek_ugryzl_policjanta?rss=1](https://epoznan.pl/news-news-151505-interwencja_podczas_miejskiej_imprezy_40_latek_ugryzl_policjanta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T19:30:00+00:00

Ma więcej na sumieniu.

## W ciągu miesiąca pokonuje 4-5 tys. km na trasie ze Swarzędza do Antoninka. Volkswagen zainwestuje w kolejne takie pojazdy.
 - [https://epoznan.pl/news-news-151507-w_ciagu_miesiaca_pokonuje_4_5_tys_km_na_trasie_ze_swarzedza_do_antoninka_volkswagen_zainwestuje_w_kolejne_takie_pojazdy?rss=1](https://epoznan.pl/news-news-151507-w_ciagu_miesiaca_pokonuje_4_5_tys_km_na_trasie_ze_swarzedza_do_antoninka_volkswagen_zainwestuje_w_kolejne_takie_pojazdy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T19:15:00+00:00

Kolejne ciężarówki elektryczne zasilą flotę Volkswagena Poznań.

## Remont ważnej ulicy wkracza w kolejny etap. Autobusy zmieniają trasy!
 - [https://epoznan.pl/news-news-151504-remont_waznej_ulicy_wkracza_w_kolejny_etap_autobusy_zmieniaja_trasy?rss=1](https://epoznan.pl/news-news-151504-remont_waznej_ulicy_wkracza_w_kolejny_etap_autobusy_zmieniaja_trasy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T19:00:00+00:00

Od najbliższego piątku.

## Wyczekiwany przez kierowców remont ważnej ulicy w Poznaniu wkracza w kolejny etap. Autobusy zmieniają trasy!
 - [https://epoznan.pl/news-news-151504-wyczekiwany_przez_kierowcow_remont_waznej_ulicy_w_poznaniu_wkracza_w_kolejny_etap_autobusy_zmieniaja_trasy?rss=1](https://epoznan.pl/news-news-151504-wyczekiwany_przez_kierowcow_remont_waznej_ulicy_w_poznaniu_wkracza_w_kolejny_etap_autobusy_zmieniaja_trasy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T19:00:00+00:00

Od najbliższego piątku.

## Wybrano nowy zarząd Metropolii Poznań. Jacek Jaśkowiak prezesem
 - [https://epoznan.pl/news-news-151503-wybrano_nowy_zarzad_metropolii_poznan_jacek_jaskowiak_prezesem?rss=1](https://epoznan.pl/news-news-151503-wybrano_nowy_zarzad_metropolii_poznan_jacek_jaskowiak_prezesem?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T18:30:00+00:00

Prezes i wiceprezesi pozostali bez zmian.

## Mężczyzna został pobity na klatce schodowej, bo zwrócił uwagę. &quot;Dwóch oprawców zasypało go gradem ciosów oraz kopnięć&quot;
 - [https://epoznan.pl/news-news-151502-mezczyzna_zostal_pobity_na_klatce_schodowej_bo_zwrocil_uwage_dwoch_oprawcow_zasypalo_go_gradem_ciosow_oraz_kopniec?rss=1](https://epoznan.pl/news-news-151502-mezczyzna_zostal_pobity_na_klatce_schodowej_bo_zwrocil_uwage_dwoch_oprawcow_zasypalo_go_gradem_ciosow_oraz_kopniec?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T18:00:00+00:00

Zareagował sąsiad.

## Protest w Poznaniu: &quot;35 lat wolności, aby dostać kredyt na 35 lat&quot;
 - [https://epoznan.pl/news-news-151501-protest_w_poznaniu_35_lat_wolnosci_aby_dostac_kredyt_na_35_lat?rss=1](https://epoznan.pl/news-news-151501-protest_w_poznaniu_35_lat_wolnosci_aby_dostac_kredyt_na_35_lat?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T17:30:00+00:00

Zwrócono uwagę na problemy mieszkaniowe.

## Wezwał policję na dworzec. 48-latek zgłosił, że znalazł portfel wypełniony sporą gotówką
 - [https://epoznan.pl/news-news-151500-wezwal_policje_na_dworzec_48_latek_zglosil_ze_znalazl_portfel_wypelniony_spora_gotowka?rss=1](https://epoznan.pl/news-news-151500-wezwal_policje_na_dworzec_48_latek_zglosil_ze_znalazl_portfel_wypelniony_spora_gotowka?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T17:00:00+00:00

Było w nim ponad 14 tysięcy złotych.

## Charaktyczna postać zniknie z al. Marcinkowskiego. ZZM tłumaczy
 - [https://epoznan.pl/news-news-151499-charaktyczna_postac_zniknie_z_al_marcinkowskiego_zzm_tlumaczy?rss=1](https://epoznan.pl/news-news-151499-charaktyczna_postac_zniknie_z_al_marcinkowskiego_zzm_tlumaczy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T16:30:00+00:00

Golem musi przejść remont.

## &quot;Pewien brak&quot; na al. Marcinkowskiego. ZZM tłumaczy
 - [https://epoznan.pl/news-news-151499-pewien_brak_na_al_marcinkowskiego_zzm_tlumaczy?rss=1](https://epoznan.pl/news-news-151499-pewien_brak_na_al_marcinkowskiego_zzm_tlumaczy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T16:30:00+00:00

Zniknęła charakterystyczna figura.

## PKP Intercity zapowiada dużo zmian. Bezpośrednio z Poznania dojedziemy do popularnych miejscowości wypoczynkowych
 - [https://epoznan.pl/news-news-151492-pkp_intercity_zapowiada_duzo_zmian_bezposrednio_z_poznania_dojedziemy_do_popularnych_miejscowosci_wypoczynkowych?rss=1](https://epoznan.pl/news-news-151492-pkp_intercity_zapowiada_duzo_zmian_bezposrednio_z_poznania_dojedziemy_do_popularnych_miejscowosci_wypoczynkowych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T15:30:00+00:00

Wakacyjny rozkład jazdy PKP Intercity wejdzie w życie 9 czerwca.

## Mężczyzna, który opiekował się dwojgiem małych dzieci dostał udaru. &quot;Nie zapomnę im tego do końca życia&quot;
 - [https://epoznan.pl/news-news-151497-mezczyzna_ktory_opiekowal_sie_dwojgiem_malych_dzieci_dostal_udaru_nie_zapomne_im_tego_do_konca_zycia?rss=1](https://epoznan.pl/news-news-151497-mezczyzna_ktory_opiekowal_sie_dwojgiem_malych_dzieci_dostal_udaru_nie_zapomne_im_tego_do_konca_zycia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T15:00:00+00:00

Pomogli policjanci.

## Strażackie zastępy przed Avenidą
 - [https://epoznan.pl/news-news-151498-strazackie_zastepy_przed_avenida?rss=1](https://epoznan.pl/news-news-151498-strazackie_zastepy_przed_avenida?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T14:45:00+00:00

Sytuacja jest już opanowana.

## Tramwaje po południu nagle zmieniły trasy. &quot;Kolejny remont?&quot;
 - [https://epoznan.pl/news-news-151496-tramwaje_po_poludniu_nagle_zmienily_trasy_kolejny_remont?rss=1](https://epoznan.pl/news-news-151496-tramwaje_po_poludniu_nagle_zmienily_trasy_kolejny_remont?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T14:20:00+00:00

Już wszystko wiadomo.

## Przed nami kolejna studencka impreza. ZTM na dwa dni wzmacnia komunikację
 - [https://epoznan.pl/news-news-151489-przed_nami_kolejna_studencka_impreza_ztm_na_dwa_dni_wzmacnia_komunikacje?rss=1](https://epoznan.pl/news-news-151489-przed_nami_kolejna_studencka_impreza_ztm_na_dwa_dni_wzmacnia_komunikacje?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T14:00:00+00:00

Już w czwartek i piątek.

## Wypadek z udziałem dwóch aut. Jedno leży na boku
 - [https://epoznan.pl/news-news-151494-wypadek_z_udzialem_dwoch_aut_jedno_lezy_na_boku?rss=1](https://epoznan.pl/news-news-151494-wypadek_z_udzialem_dwoch_aut_jedno_lezy_na_boku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T13:45:00+00:00

Poszkodowana została jedna osoba.

## Awaria urządzeń sterowania ruchem na dworcu Poznań Główny. Wiadomo, co mogło być przyczyną
 - [https://epoznan.pl/news-news-151490-awaria_urzadzen_sterowania_ruchem_na_dworcu_poznan_glowny_wiadomo_co_moglo_byc_przyczyna?rss=1](https://epoznan.pl/news-news-151490-awaria_urzadzen_sterowania_ruchem_na_dworcu_poznan_glowny_wiadomo_co_moglo_byc_przyczyna?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T13:30:00+00:00

Wstępne ustalenia wskazują na uderzenie pioruna.

## Poznań najlepszy w Polsce w prestiżowym rankingu
 - [https://epoznan.pl/news-news-151483-poznan_najlepszy_w_polsce_w_prestizowym_rankingu?rss=1](https://epoznan.pl/news-news-151483-poznan_najlepszy_w_polsce_w_prestizowym_rankingu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T12:55:00+00:00

W czym się wyróżnia?

## Fundacja przebadała truskawki z Biedronki i z Lidla. Nie jest dobrze
 - [https://epoznan.pl/news-news-151487-fundacja_przebadala_truskawki_z_biedronki_i_z_lidla_nie_jest_dobrze?rss=1](https://epoznan.pl/news-news-151487-fundacja_przebadala_truskawki_z_biedronki_i_z_lidla_nie_jest_dobrze?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T12:45:00+00:00

Znaleziono pestycydy.

## Nie mogła dodzwonić się do teściowej, o pomoc poprosiła służby. Ratunek nadszedł na czas
 - [https://epoznan.pl/news-news-151488-nie_mogla_dodzwonic_sie_do_tesciowej_o_pomoc_poprosila_sluzby_ratunek_nadszedl_na_czas?rss=1](https://epoznan.pl/news-news-151488-nie_mogla_dodzwonic_sie_do_tesciowej_o_pomoc_poprosila_sluzby_ratunek_nadszedl_na_czas?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T12:40:00+00:00

75-latkę udało się uratować.

## Wilk pojawił się na Chartowie? Straż Miejska odebrała zgłoszenie
 - [https://epoznan.pl/news-news-151475-wilk_pojawil_sie_na_chartowie_straz_miejska_odebrala_zgloszenie?rss=1](https://epoznan.pl/news-news-151475-wilk_pojawil_sie_na_chartowie_straz_miejska_odebrala_zgloszenie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T12:35:00+00:00

Miał się pojawić w rejonie osiedla Lecha.

## Ciecz lała się z sufitu poznańskiego autobusu
 - [https://epoznan.pl/news-news-151486-ciecz_lala_sie_z_sufitu_poznanskiego_autobusu?rss=1](https://epoznan.pl/news-news-151486-ciecz_lala_sie_z_sufitu_poznanskiego_autobusu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T12:25:00+00:00

Do awarii doszło w maju.

## Nastolatek utknął między balotami na polu. Na ratunek wezwano strażaków
 - [https://epoznan.pl/news-news-151479-nastolatek_utknal_miedzy_balotami_na_polu_na_ratunek_wezwano_strazakow?rss=1](https://epoznan.pl/news-news-151479-nastolatek_utknal_miedzy_balotami_na_polu_na_ratunek_wezwano_strazakow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T12:15:00+00:00

Do niebezpiecznej sytuacji doszło w Granowie.

## Rusza poszerzanie autostradowej obwodnicy Poznania na kolejnym odcinku! 1,5 roku utrudnień!
 - [https://epoznan.pl/news-news-151485-rusza_poszerzanie_autostradowej_obwodnicy_poznania_na_kolejnym_odcinku_15_roku_utrudnien?rss=1](https://epoznan.pl/news-news-151485-rusza_poszerzanie_autostradowej_obwodnicy_poznania_na_kolejnym_odcinku_15_roku_utrudnien?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T12:00:00+00:00

Prace zaczną się w poniedziałek, 10 czerwca.

## Ponad 200 strażaków i policjantów szkoliło się w rozbieranej galerii handlowej
 - [https://epoznan.pl/news-news-151478-ponad_200_strazakow_i_policjantow_szkolilo_sie_w_rozbieranej_galerii_handlowej?rss=1](https://epoznan.pl/news-news-151478-ponad_200_strazakow_i_policjantow_szkolilo_sie_w_rozbieranej_galerii_handlowej?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T11:50:00+00:00

Teren zamkniętej galerii służył służbom jako plac treningowy.

## Mieszkańcy osiedla zdecydują czy chcą płacić za parkowanie. Wcześniej wybrano wariant Spółdzielczej Strefy Parkowania
 - [https://epoznan.pl/news-news-151476-mieszkancy_osiedla_zdecyduja_czy_chca_placic_za_parkowanie_wczesniej_wybrano_wariant_spoldzielczej_strefy_parkowania?rss=1](https://epoznan.pl/news-news-151476-mieszkancy_osiedla_zdecyduja_czy_chca_placic_za_parkowanie_wczesniej_wybrano_wariant_spoldzielczej_strefy_parkowania?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T11:20:00+00:00

Decyzję podejmą mieszkańcy osiedla Piastowskiego.

## Zabójstwo 5-letniego Maurycego na Łazarzu. Właśnie umorzono sprawę. Co ze sprawcą?
 - [https://epoznan.pl/news-news-151482-zabojstwo_5_letniego_maurycego_na_lazarzu_wlasnie_umorzono_sprawe_co_ze_sprawca?rss=1](https://epoznan.pl/news-news-151482-zabojstwo_5_letniego_maurycego_na_lazarzu_wlasnie_umorzono_sprawe_co_ze_sprawca?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T10:40:00+00:00

Trafi do zakładu psychiatrycznego.

## Nie żyje Janusz Rewiński. Grał m.in. na deskach poznańskiego teatru
 - [https://epoznan.pl/news-news-151480-nie_zyje_janusz_rewinski_gral_min_na_deskach_poznanskiego_teatru?rss=1](https://epoznan.pl/news-news-151480-nie_zyje_janusz_rewinski_gral_min_na_deskach_poznanskiego_teatru?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T10:16:00+00:00

Aktor miał 74 lata.

## Stary Rynek wciąż bez trykających się koziołków. Nie mamy dobrych wieści
 - [https://epoznan.pl/news-news-151471-stary_rynek_wciaz_bez_trykajacych_sie_koziolkow_nie_mamy_dobrych_wiesci?rss=1](https://epoznan.pl/news-news-151471-stary_rynek_wciaz_bez_trykajacych_sie_koziolkow_nie_mamy_dobrych_wiesci?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T10:00:00+00:00

Prace trwają, ale nikt nie wie, kiedy się zakończą.

## Wybuch zbiornika z gazem w rozbieranym aucie. Dwie osoby poparzone
 - [https://epoznan.pl/news-news-151477-wybuch_zbiornika_z_gazem_w_rozbieranym_aucie_dwie_osoby_poparzone?rss=1](https://epoznan.pl/news-news-151477-wybuch_zbiornika_z_gazem_w_rozbieranym_aucie_dwie_osoby_poparzone?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T09:33:00+00:00

Do zdarzenia doszło na poznańskiej Starołęce.

## 35. rocznica Wolnych Wyborów. Jaśkowiak do Wałęsy: &quot;Dziękujemy!&quot;
 - [https://epoznan.pl/news-news-151470-35_rocznica_wolnych_wyborow_jaskowiak_do_walesy_dziekujemy?rss=1](https://epoznan.pl/news-news-151470-35_rocznica_wolnych_wyborow_jaskowiak_do_walesy_dziekujemy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T09:20:00+00:00

Były prezydent w poniedziałek odebrał w Poznaniu Nagrodę za Odwagę.

## Niezrozumiała selekcja na wejściu do popularnej miejscówki. Zgłaszają się do nas kolejne osoby. Powody? Sportowy ubiór, logo Lecha Poznań na koszulce
 - [https://epoznan.pl/news-news-151469-niezrozumiala_selekcja_na_wejsciu_do_popularnej_miejscowki_zglaszaja_sie_do_nas_kolejne_osoby_powody_sportowy_ubior_logo_lecha_poznan_na_koszulce?rss=1](https://epoznan.pl/news-news-151469-niezrozumiala_selekcja_na_wejsciu_do_popularnej_miejscowki_zglaszaja_sie_do_nas_kolejne_osoby_powody_sportowy_ubior_logo_lecha_poznan_na_koszulce?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T08:40:00+00:00

Chodzi o Nocny Targ Towarzyski.

## Brutalne pobicie w ogródku restauracyjnym na Starym Rynku. Ofiara zwróciła uwagę pracownikom klubu go-go
 - [https://epoznan.pl/news-news-151473-brutalne_pobicie_w_ogrodku_restauracyjnym_na_starym_rynku_ofiara_zwrocila_uwage_pracownikom_klubu_go_go?rss=1](https://epoznan.pl/news-news-151473-brutalne_pobicie_w_ogrodku_restauracyjnym_na_starym_rynku_ofiara_zwrocila_uwage_pracownikom_klubu_go_go?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T08:00:00+00:00

Do zdarzenia doszło w sobotę wieczorem.

## Rolnicy w ciągnikach na poznańskich ulicach. Trwa kolejny protest!
 - [https://epoznan.pl/news-news-151474-rolnicy_w_ciagnikach_na_poznanskich_ulicach_trwa_kolejny_protest?rss=1](https://epoznan.pl/news-news-151474-rolnicy_w_ciagnikach_na_poznanskich_ulicach_trwa_kolejny_protest?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T07:21:00+00:00

Będą protestować m.in. przed Urzędem Wojewódzkim.

## Rolnicy w ciągnikach ruszyli do Poznania!
 - [https://epoznan.pl/news-news-151474-rolnicy_w_ciagnikach_ruszyli_do_poznania?rss=1](https://epoznan.pl/news-news-151474-rolnicy_w_ciagnikach_ruszyli_do_poznania?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T07:21:00+00:00

Będą protestować m.in. przed Urzędem Wojewódzkim.

## Komunikacyjny Armagedon w regionie po zamknięciu mostu na Warcie. Całe miasto stoi
 - [https://epoznan.pl/news-news-151472-komunikacyjny_armagedon_w_regionie_po_zamknieciu_mostu_na_warcie_cale_miasto_stoi?rss=1](https://epoznan.pl/news-news-151472-komunikacyjny_armagedon_w_regionie_po_zamknieciu_mostu_na_warcie_cale_miasto_stoi?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T06:45:00+00:00

Koszmarny wtorek w Obornikach.

## Jest zgoda na kolejną obwodnicę w regionie. &quot;Ruszy wypłata odszkodowań&quot;
 - [https://epoznan.pl/news-news-151468-jest_zgoda_na_kolejna_obwodnice_w_regionie_ruszy_wyplata_odszkodowan?rss=1](https://epoznan.pl/news-news-151468-jest_zgoda_na_kolejna_obwodnice_w_regionie_ruszy_wyplata_odszkodowan?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T06:10:00+00:00

Powstanie w ramach Programu budowy 100 obwodnic.

## Andrzej Duda znowu pojawił się w Wielkopolsce
 - [https://epoznan.pl/news-news-151467-andrzej_duda_znowu_pojawil_sie_w_wielkopolsce?rss=1](https://epoznan.pl/news-news-151467-andrzej_duda_znowu_pojawil_sie_w_wielkopolsce?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-06-04T05:35:00+00:00

Zachęcał do udziału w niedzielnych wyborach.

