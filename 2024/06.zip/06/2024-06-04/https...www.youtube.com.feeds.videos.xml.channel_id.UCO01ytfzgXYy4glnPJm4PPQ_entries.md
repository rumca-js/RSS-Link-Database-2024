# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## There is just a small problem with her theory.
 - [https://www.youtube.com/watch?v=HwRtvzH0olw](https://www.youtube.com/watch?v=HwRtvzH0olw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-04T19:00:08+00:00



## White Player Diversifies The WNBA. Champions Of Diversity Are Somehow Not Happy. | Ep. 1380
 - [https://www.youtube.com/watch?v=zcAnn50BkFQ](https://www.youtube.com/watch?v=zcAnn50BkFQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-04T18:07:43+00:00

Today on the Matt Walsh Show, the biggest star -- and only star -- in the WNBA is a white woman. This should be considered a win for diversity, yet Caitlin Clark has provoked a lot of rage and resentment from the supposed champions of diversity. Also, a bar owner in Idaho offers free beer to straight people as part of Heterosexual Awesomeness month, as he has dubbed it. Scientists are close to inventing a birth control gel that men can rub on their bodies to make themselves impotent. And, a psychologist takes to TikTok to brag about her refusal to return her shopping carts. You know I have no choice but to cancel her. We'll talk about all of that and more today on the Matt Walsh Show.

TIMESTAMPS:

00:00 - 00:33 Opening
02:01 - 18:00 White Player Diversifies The WNBA. Champions Of Diversity Are Somehow Not Happy. 
19:11 - 26:38 Fauci Admits COVID Vaccines Were Not 100% Effective
26:39 - 32:28 Heterosexual Bar In Idaho Gives Free Beer To Straight People
32:29 - 37:51 Male Birth Control

## No, Your Male Friendships Shouldn’t Have More “Emotional Intelligence”
 - [https://www.youtube.com/watch?v=rUu2voX5hjo](https://www.youtube.com/watch?v=rUu2voX5hjo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-04T17:00:38+00:00

Tax Network USA - Seize control of your financial future! Call 1(800)245-6000 or visit http://www.TNUSA.com/Walsh 

A viral post on social media laments the lack of "emotional intelligence" in men and male friendships.

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1379 - https://bit.ly/3V6CiDO

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Don't threaten us with a good time Robert
 - [https://www.youtube.com/watch?v=F-QrWHr4FY0](https://www.youtube.com/watch?v=F-QrWHr4FY0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-04T17:00:08+00:00



## Canada Is Trying to Lower The Voting Age in The Cringiest Way Possible
 - [https://www.youtube.com/watch?v=MXGfe3Xw-r8](https://www.youtube.com/watch?v=MXGfe3Xw-r8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-04T15:15:02+00:00

A politician in Canada uses the cringiest method possible to voice her support for a law that will lower the voting age to 16.

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1379 - https://bit.ly/3V6CiDO

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

