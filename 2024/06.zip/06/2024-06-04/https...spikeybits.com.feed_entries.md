# Source:Spikey Bits, URL:https://spikeybits.com/feed, language:en-US

## The Meta Strikes Back This Week!
 - [https://spikeybits.com/warhammer-40k/meta-army-lists-june42024](https://spikeybits.com/warhammer-40k/meta-army-lists-june42024)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-06-04T19:30:48+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/06/Tau-warhamer-40k-meta-changers-army-lists-tournaments-hor-wal.png"><img alt="Tau warhamer 40k meta changers army lists tournaments hor wal" class="aligncenter size-full wp-image-462911" height="720" src="https://spikeybits.com/wp-content/uploads/2024/06/Tau-warhamer-40k-meta-changers-army-lists-tournaments-hor-wal.png" width="1280" /></a>What is old is new again as the constantly evolving Warhammer 40k meta grinds through another weekend with no clear</p>
<p><a href="https://spikeybits.com/warhammer-40k/meta-army-lists-june42024/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/meta-army-lists-june42024/">The Meta Strikes Back This Week!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Games Workshop Says No More Shopping Bags For Customers
 - [https://spikeybits.com/warhammer-40k/no-more-shopping-bags](https://spikeybits.com/warhammer-40k/no-more-shopping-bags)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-06-04T15:30:58+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/02/warhammer-40k-gw-hq-conference-hor-wal.png"><img alt="warhammer 40k gw hq conference hor wal" class="aligncenter size-full wp-image-456369" height="720" src="https://spikeybits.com/wp-content/uploads/2024/02/warhammer-40k-gw-hq-conference-hor-wal.png" width="1280" /></a>In a bid for sustainability, Games Workshop announced they are eliminating shopping bags for customers from its stores across England.</p>
<p><span id="more-462870"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch"></p>
<p><a href="https://spikeybits.com/warhammer-40k/no-more-shopping-bags/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/no-more-shopping-bags/">Games Workshop Says No More Shopping Bags For Customers</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Upgrade Your Baneblade With New Alternative Sponsons!
 - [https://spikeybits.com/warhammer-40k/baneblade-sponson-bits](https://spikeybits.com/warhammer-40k/baneblade-sponson-bits)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-06-04T14:30:44+00:00

<p><p><a href="https://spikeybits.com/?p=462304&amp;preview=true"><img alt="Elrik's Hobbies Sponson" class="aligncenter wp-image-462317 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/05/elriks.png" width="1280" /></a>Deck out your Baneblade to the fullest with this new alternative sponsons options from the minds at Elrik&#8217;s Hobbies.<span id="more-462304"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p>Elrik&#8217;s</p>
<p><a href="https://spikeybits.com/warhammer-40k/baneblade-sponson-bits/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/baneblade-sponson-bits/">Upgrade Your Baneblade With New Alternative Sponsons!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## GW’s Latest Caper Is Tough Nut To Crack
 - [https://spikeybits.com/gw-rumor-engine/gws-latest-caper-is-tough-nut-to-crack](https://spikeybits.com/gw-rumor-engine/gws-latest-caper-is-tough-nut-to-crack)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-06-04T13:30:29+00:00

<p><p><a href="https://spikeybits.com/?p=460579&amp;preview=true"><img alt="Rumor Engine new GW header wal hor" class="aligncenter wp-image-330587 size-full" height="493" src="https://spikeybits.com/wp-content/uploads/2020/08/402380a6-rumor-engine-new-gw-header-wal-hor.jpg" width="740" /></a>The latest GW rumor engine preview includes a cape or cloth, which we think is part of a new undead miniature for</p>
<p><a href="https://spikeybits.com/gw-rumor-engine/gws-latest-caper-is-tough-nut-to-crack/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/gw-rumor-engine/gws-latest-caper-is-tough-nut-to-crack/">GW&#8217;s Latest Caper Is Tough Nut To Crack</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## GW Competitor Privateer Press Sells Out, Warmachine Has New Owners
 - [https://spikeybits.com/rumors/privateer-press-sells-steamforged-games](https://spikeybits.com/rumors/privateer-press-sells-steamforged-games)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-06-04T12:30:39+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/06/steamforged-games-acquires-privateer-press-1.png"><img alt="steamforged games acquires privateer press 1" class="aligncenter size-full wp-image-462869" height="720" src="https://spikeybits.com/wp-content/uploads/2024/06/steamforged-games-acquires-privateer-press-1.png" width="1280" /></a>Hold onto your dice; Steamforged Games has acquired Warhammer 40k competitor Warmachine and the Iron Kingdoms from Privateer Press!</p>
<p><span id="more-462865"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p>
<p><a href="https://spikeybits.com/rumors/privateer-press-sells-steamforged-games/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/rumors/privateer-press-sells-steamforged-games/">GW Competitor Privateer Press Sells Out, Warmachine Has New Owners</a> from <a href="https://spikeybits.com">Spi

## New Adepta Sororitas, GSC & Pariah Nexus Pricing CONFIRMED!
 - [https://spikeybits.com/warhammer-40k/adepta-sororitas-genstealer-cults-pariah-nexus-pricing-pre-order](https://spikeybits.com/warhammer-40k/adepta-sororitas-genstealer-cults-pariah-nexus-pricing-pre-order)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-06-04T10:30:48+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2024/05/new-next-week-genestealer-cults-sisters-of-battle-adepta-sororitas-new-releases.png"><img alt="new next week genestealer cults sisters of battle adepta sororitas new releases" class="aligncenter size-full wp-image-462780" height="720" src="https://spikeybits.com/wp-content/uploads/2024/05/new-next-week-genestealer-cults-sisters-of-battle-adepta-sororitas-new-releases.png" width="1280" /></a></p>
<p>Here is the confirmed pre-order pricing for the new 40k mission deck, Adepta Sororitas and GSC codex books,</p>
<p><a href="https://spikeybits.com/warhammer-40k/adepta-sororitas-genstealer-cults-pariah-nexus-pricing-pre-order/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/adepta-sororitas-genstealer-cults-pariah-nexus-pricing-pre-order/">New Adepta Sororitas, GSC &#038; Pariah Nexus Pricing CONFIRMED!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

