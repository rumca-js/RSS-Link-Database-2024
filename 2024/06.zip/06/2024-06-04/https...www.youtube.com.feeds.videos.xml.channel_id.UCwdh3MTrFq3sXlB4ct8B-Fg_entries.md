# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## Learn to Paint: Infernus Space Marine | Beginner | Warhammer 40,000
 - [https://www.youtube.com/watch?v=rKumrvcfKLA](https://www.youtube.com/watch?v=rKumrvcfKLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2024-06-04T09:00:45+00:00

Welcome to the grim, dark future of Warhammer 40,000! In this video, Ollie will show you how to build and paint your very first model – an awesome Infernus Marine. This flame-spouting Space Marine may seem like a daunting project, but painting models is honestly super easy, and really fun too! Just follow along, step by step, and you'll be ready in no time.

Base: 
Abaddon Black
Balthasar Gold
Corax White
Macragge Blue

Shade: 
Agrax Earthshade

Technical: 
Armageddon Dust 

If you're new to painting, our Citadel Colour Painting Essentials playlist hosts an array of beginner-friendly videos to help you get started.

Follow for more Warhammer, more often:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/

