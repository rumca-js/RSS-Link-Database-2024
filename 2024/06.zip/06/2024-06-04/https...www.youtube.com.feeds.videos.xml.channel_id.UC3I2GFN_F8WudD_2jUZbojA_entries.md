# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## OUT NOW: Marnie Stern Live on KEXP
 - [https://www.youtube.com/watch?v=ffLh25YH-OQ](https://www.youtube.com/watch?v=ffLh25YH-OQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-06-04T18:15:03+00:00



## Marnie Stern - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=3vxh8xKaWqQ](https://www.youtube.com/watch?v=3vxh8xKaWqQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-06-04T15:00:03+00:00

http://KEXP.ORG presents Marnie Stern performing live in the KEXP studio. Recorded March 19, 2024.

Songs:
Plain Speak 00:38
Believing Is Seeing 03:53
Transformer 06:04
Sixteen 08:38
The Crippled Jazzer 12:11

Marnie Stern - Vocal, Guitar
Nick Ferrante - Drums
Andy Pitcher - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz

Cameras:Jim Beckmann, Carlos Cruz, Scott Holpainen, Luke Knecht
Editor: Carlos Cruz

https://marniestern.bandcamp.com/album/the-comeback-kid
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Marnie Stern - Transformer (Live on KEXP)
 - [https://www.youtube.com/watch?v=qGGlf4vZ-ZI](https://www.youtube.com/watch?v=qGGlf4vZ-ZI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-06-04T11:00:48+00:00

http://KEXP.ORG presents Marnie Stern performing “Transformer” live in the KEXP studio. Recorded March 19, 2024.

Marnie Stern - Vocal, Guitar
Nick Ferrante - Drums
Andy Pitcher - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz

Cameras:Jim Beckmann, Carlos Cruz, Scott Holpainen, Luke Knecht
Editor: Carlos Cruz

https://marniestern.bandcamp.com/album/the-comeback-kid
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Marnie Stern - Believing Is Seeing (Live on KEXP)
 - [https://www.youtube.com/watch?v=fKcu9guKbms](https://www.youtube.com/watch?v=fKcu9guKbms)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-06-04T11:00:41+00:00

http://KEXP.ORG presents Marnie Stern performing “Believing Is Seeing” live in the KEXP studio. Recorded March 19, 2024.

Marnie Stern - Vocal, Guitar
Nick Ferrante - Drums
Andy Pitcher - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz

Cameras:Jim Beckmann, Carlos Cruz, Scott Holpainen, Luke Knecht
Editor: Carlos Cruz

https://marniestern.bandcamp.com/album/the-comeback-kid
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Marnie Stern - Sixteen (Live on KEXP)
 - [https://www.youtube.com/watch?v=d9Bc8Jo--PA](https://www.youtube.com/watch?v=d9Bc8Jo--PA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-06-04T11:00:36+00:00

http://KEXP.ORG presents Marnie Stern performing “Sixteen” live in the KEXP studio. Recorded March 19, 2024.

Marnie Stern - Vocal, Guitar
Nick Ferrante - Drums
Andy Pitcher - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz

Cameras:Jim Beckmann, Carlos Cruz, Scott Holpainen, Luke Knecht
Editor: Carlos Cruz

https://marniestern.bandcamp.com/album/the-comeback-kid
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Marnie Stern - Plain Speak (Live on KEXP)
 - [https://www.youtube.com/watch?v=Nt8TvR_Oksw](https://www.youtube.com/watch?v=Nt8TvR_Oksw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-06-04T11:00:31+00:00

http://KEXP.ORG presents Marnie Stern performing “Plain Speak” live in the KEXP studio. Recorded March 19, 2024.

Marnie Stern - Vocal, Guitar
Nick Ferrante - Drums
Andy Pitcher - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz

Cameras:Jim Beckmann, Carlos Cruz, Scott Holpainen, Luke Knecht
Editor: Carlos Cruz

https://marniestern.bandcamp.com/album/the-comeback-kid
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Marnie Stern - The Crippled Jazzer (Live on KEXP)
 - [https://www.youtube.com/watch?v=Q5Ba2soFhHA](https://www.youtube.com/watch?v=Q5Ba2soFhHA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-06-04T11:00:20+00:00

http://KEXP.ORG presents Marnie Stern performing “The Crippled Jazzer ” live in the KEXP studio. Recorded March 19, 2024.

Marnie Stern - Vocal, Guitar
Nick Ferrante - Drums
Andy Pitcher - Guitar

Host: Cheryl Waters
Audio Engineer: Kevin Suggs
Mastering Engineer: Matt Ogaz

Cameras:Jim Beckmann, Carlos Cruz, Scott Holpainen, Luke Knecht
Editor: Carlos Cruz

https://marniestern.bandcamp.com/album/the-comeback-kid
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

