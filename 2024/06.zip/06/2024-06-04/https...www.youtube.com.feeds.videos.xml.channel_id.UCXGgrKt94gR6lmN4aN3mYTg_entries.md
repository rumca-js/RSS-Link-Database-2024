# Source:Austin Evans, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg, language:en-US

## There's NOTHING Else Like It.
 - [https://www.youtube.com/watch?v=-nJM98QRKlc](https://www.youtube.com/watch?v=-nJM98QRKlc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg
 - date published: 2024-06-04T14:01:17+00:00

Check out the new ProArt line: https://asus.click/proart_austin

Subscribe for more! https://www.youtube.com/austinevans
TikTok: https://www.tiktok.com/@austintechtips
Instagram: https://instagram.com/austinnotduncan
Twitter: https://twitter.com/austinnotduncan
Threads: https://www.threads.net/@austinnotduncan

## The NEW Snapdragon X is Here
 - [https://www.youtube.com/watch?v=vK-NU0xwrX0](https://www.youtube.com/watch?v=vK-NU0xwrX0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg
 - date published: 2024-06-04T01:43:51+00:00

The #SnapdragonXSeries is about to launch and should be a BIG deal for Windows.

