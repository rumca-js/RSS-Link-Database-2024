# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en

## Biden brings Hochul to DC, and Adams is left behind
 - [https://www.politico.com/newsletters/new-york-playbook-pm/2024/06/04/biden-brings-hochul-to-dc-and-adams-is-left-behind-00161519](https://www.politico.com/newsletters/new-york-playbook-pm/2024/06/04/biden-brings-hochul-to-dc-and-adams-is-left-behind-00161519)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-06-04T15:32:30+00:00



