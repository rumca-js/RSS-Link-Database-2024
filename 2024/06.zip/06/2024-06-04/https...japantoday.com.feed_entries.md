# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## 3-year-old dies in what police say was random stabbing in Ohio grocery parking lot
 - [https://japantoday.com/category/world/3-year-old-dies-in-what-police-say-was-random-stabbing-in-ohio-grocery-parking-lot](https://japantoday.com/category/world/3-year-old-dies-in-what-police-say-was-random-stabbing-in-ohio-grocery-parking-lot)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T22:52:50+00:00

A 3-year-old boy was fatally stabbed by a woman as he sat in a grocery cart in a supermarket parking lot. Investigators said Tuesday that they believe it…

## Italy held to goalless draw in Euro warm-up with Turkey
 - [https://japantoday.com/category/sports/italy-held-to-goalless-draw-in-euros-warm-up-with-turkey](https://japantoday.com/category/sports/italy-held-to-goalless-draw-in-euros-warm-up-with-turkey)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T22:13:03+00:00

Italy were held to a goalless draw by Turkey on Tuesday as the Azzurri gear up for their European Championship title defence later this month.
Luciano Spalletti's side…

## Former protege sues The-Dream, accusing the hitmaking music producer of sexual assault
 - [https://japantoday.com/category/entertainment/former-protege-sues-the-dream-accusing-the-hitmaking-music-producer-of-sexual-assault](https://japantoday.com/category/entertainment/former-protege-sues-the-dream-accusing-the-hitmaking-music-producer-of-sexual-assault)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T22:11:54+00:00

A former protege of The-Dream, a Grammy-winning writer and producer on some of biggest hits by Beyoncé and Rihanna, among others, filed a lawsuit Tuesday accusing him of…

## Worries for France's Le Coq Sportif ahead of Paris Olympics
 - [https://japantoday.com/category/paris-2024-olympics/worries-for-france%27s-le-coq-sportif-ahead-of-paris-olympics](https://japantoday.com/category/paris-2024-olympics/worries-for-france%27s-le-coq-sportif-ahead-of-paris-olympics)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T22:02:00+00:00

Loss-making French sportswear brand Le Coq Sportif faces fresh doubts about its finances and operations just as it should be delivering around 370,000 items of clothing and equipment…

## French apathy and cost concerns dampen mayors' bid to stoke Games fervor
 - [https://japantoday.com/category/paris-2024-olympics/olympics-french-apathy-and-cost-concerns-dampen-mayors%27-bid-to-stoke-games-fervour](https://japantoday.com/category/paris-2024-olympics/olympics-french-apathy-and-cost-concerns-dampen-mayors%27-bid-to-stoke-games-fervour)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T22:01:53+00:00

When a group of mayors paid tens of thousands of euros each to bring the Olympic torch to their towns along France's Atlantic coast, a row erupted over…

## Hunter Biden gun trial opens in earnest with focus on drug use
 - [https://japantoday.com/category/world/opening-arguments-set-in-trial-of-biden%27s-son-hunter-on-gun-charges](https://japantoday.com/category/world/opening-arguments-set-in-trial-of-biden%27s-son-hunter-on-gun-charges)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:55:41+00:00

Jurors heard unsparing accounts of Hunter Biden's drug use in his own words on Tuesday as his trial on gun charges, the first ever prosecution of a child…

## Spanish court summons prime minister's wife for questioning in a corruption probe
 - [https://japantoday.com/category/world/spanish-court-summons-the-prime-minister%27s-wife-for-questioning-in-a-corruption-probe](https://japantoday.com/category/world/spanish-court-summons-the-prime-minister%27s-wife-for-questioning-in-a-corruption-probe)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:55:27+00:00

A Spanish investigative judge has summoned the wife of Spain’s prime minister to give testimony as part of a probe into allegations that she used her position to…

## Garland slams attacks on Justice Department, telling lawmakers: 'I will not be intimidated'
 - [https://japantoday.com/category/world/garland-slams-attacks-on-the-justice-department-telling-lawmakers-%27i-will-not-be-intimidated%27](https://japantoday.com/category/world/garland-slams-attacks-on-the-justice-department-telling-lawmakers-%27i-will-not-be-intimidated%27)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:55:15+00:00

Attorney General Merrick Garland rebuked Republicans Tuesday for what he described as unprecedented attacks on the Justice Department, telling lawmakers who have sought to hold him in contempt…

## U.S. House passes Republican bill to sanction International Criminal Court over Israel
 - [https://japantoday.com/category/world/us-house-passes-republican-bill-to-sanction-international-criminal-court-over-israel](https://japantoday.com/category/world/us-house-passes-republican-bill-to-sanction-international-criminal-court-over-israel)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:55:03+00:00

The Republican-led U.S. House of Representatives passed legislation that would impose sanctions on the International Criminal Court over its prosecutor's decision to seek arrest warrants for Israeli officials…

## Poland's Tusk says EU vote crucial for keeping war outside the bloc
 - [https://japantoday.com/category/world/poland%27s-tusk-says-eu-vote-crucial-for-keeping-war-outside-the-bloc](https://japantoday.com/category/world/poland%27s-tusk-says-eu-vote-crucial-for-keeping-war-outside-the-bloc)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:54:56+00:00

Thousands of supporters of Polish Prime Minister Donald Tusk gathered in the capital Warsaw on Tuesday ahead of European elections that the head of government says are crucial…

## U.S., partners making progress on ways to use frozen Russian assets, Treasury official says
 - [https://japantoday.com/category/world/us-partners-making-progress-on-ways-to-use-frozen-russian-assets-treasury-official-says2](https://japantoday.com/category/world/us-partners-making-progress-on-ways-to-use-frozen-russian-assets-treasury-official-says2)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:54:47+00:00

The United States and its G7 partners are making progress on finding ways to provide larger amounts of urgently needed funds to Ukraine by tapping the value of…

## In testy debate, Britain's Sunak, Starmer go head to head on the economy
 - [https://japantoday.com/category/world/in-testy-debate-britain%27s-sunak-starmer-go-head-to-head-on-the-economy](https://japantoday.com/category/world/in-testy-debate-britain%27s-sunak-starmer-go-head-to-head-on-the-economy)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:54:39+00:00

Britain's Rishi Sunak and Labour's Keir Starmer went head-to-head on Tuesday over how to boost the country's economy, with the prime minister accusing the opposition party of wanting…

## U.S. launches lobbying blitz to sell Gaza cease-fire plan to Hamas through Arab and Muslim nations
 - [https://japantoday.com/category/world/us-launches-lobbying-blitz-to-sell-gaza-cease-fire-plan-to-hamas-through-arab-and-muslim-nations](https://japantoday.com/category/world/us-launches-lobbying-blitz-to-sell-gaza-cease-fire-plan-to-hamas-through-arab-and-muslim-nations)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:54:31+00:00

The Biden administration has launched an intense drive to persuade Hamas and Israel to accept a new cease-fire proposal in the nearly eight-month-old war in Gaza while it…

## Biden rolls out migration order that aims to shut down asylum requests, after months of anticipation
 - [https://japantoday.com/category/world/biden-rolls-out-migration-order-that-aims-to-shut-down-asylum-requests-after-months-of-anticipation](https://japantoday.com/category/world/biden-rolls-out-migration-order-that-aims-to-shut-down-asylum-requests-after-months-of-anticipation)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:54:25+00:00

President Joe Biden on Tuesday unveiled plans to enact immediate significant restrictions on migrants seeking asylum at the U.S.-Mexico border as the White House tries to neutralize immigration…

## Defending T20 champions England washed out after Scotland scare
 - [https://japantoday.com/category/sports/defending-t20-champions-england-washed-out-after-scotland-scare1](https://japantoday.com/category/sports/defending-t20-champions-england-washed-out-after-scotland-scare1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:54:12+00:00

Scotland openers George Munsey and Michael Jones gave England a fright in their T20 World Cup opener in Barbados on Tuesday before rain spared the defending champions a…

## Mbappe arrival ignites Madrid fans and press
 - [https://japantoday.com/category/sports/mbappe-arrival-ignites-madrid-fans-and-press1](https://japantoday.com/category/sports/mbappe-arrival-ignites-madrid-fans-and-press1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:54:05+00:00

Kylian Mbappe's long-awaited arrival at Real Madrid sparked joyous reactions in the Spanish press and among the club's fans on Tuesday, though the French superstar will know he…

## Djokovic out of French Open with knee injury
 - [https://japantoday.com/category/sports/%27really-sad%27-djokovic-out-of-french-open-with-knee-injury](https://japantoday.com/category/sports/%27really-sad%27-djokovic-out-of-french-open-with-knee-injury)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:53:57+00:00

Novak Djokovic pulled out of the French Open on Tuesday ahead of his quarterfinal against Casper Ruud because of a knee injury suffered in the previous round.
&quot;I…

## OpenAI insiders blast lack of AI transparency
 - [https://japantoday.com/category/tech/openai-insiders-blast-lack-of-ai-transparency](https://japantoday.com/category/tech/openai-insiders-blast-lack-of-ai-transparency)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:53:34+00:00

A group of current and former employees from OpenAI on Tuesday issued an open letter warning that the world's leading artificial intelligence companies were falling short of necessary…

## Intel unveils new chip tech in AI battle with Nvidia, AMD
 - [https://japantoday.com/category/tech/intel-unveils-new-chip-tech-in-ai-battle-with-nvidia-amd](https://japantoday.com/category/tech/intel-unveils-new-chip-tech-in-ai-battle-with-nvidia-amd)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:53:17+00:00

U.S. chip titan Intel on Tuesday struck a defiant tone in the face of strong challenges from rivals Nvidia, AMD and Qualcomm, unveiling technologies it said would lead…

## U.S. job openings fall to 8.1 million, lowest since 2021, but remain at historically high levels
 - [https://japantoday.com/category/business/us-job-openings-fall-to-8.1-million-lowest-since-2021-but-remain-at-historically-high-levels](https://japantoday.com/category/business/us-job-openings-fall-to-8.1-million-lowest-since-2021-but-remain-at-historically-high-levels)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:52:48+00:00

U.S. job openings fell in April to the lowest level since 2021. But they remained at historically strong levels despite high interest rates and signs the economy is…

## Frustration in the air: Boeing delays hang over aviation meeting
 - [https://japantoday.com/category/business/frustration-in-the-air-boeing-delays-hang-over-aviation-meet](https://japantoday.com/category/business/frustration-in-the-air-boeing-delays-hang-over-aviation-meet)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:52:41+00:00

Back-slapping over record passenger figures is tinged with frustration at the airline trade body's annual meeting as carriers lament years-long delays to deliveries of new Boeing aircraft.
Headline…

## Alec and Hilaria Baldwin announce family reality series
 - [https://japantoday.com/category/entertainment/alec-and-hilaria-baldwin-announce-tlc-family-reality-series](https://japantoday.com/category/entertainment/alec-and-hilaria-baldwin-announce-tlc-family-reality-series)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:50:17+00:00

Alec Baldwin and his wife Hilaria are the next family set to star in their own reality series.
The actor and producer, who has seven kids under age…

## Japan completes 6th round of Fukushima treated water discharge
 - [https://japantoday.com/category/national/japan-completes-6th-round-of-fukushima-treated-water-discharge](https://japantoday.com/category/national/japan-completes-6th-round-of-fukushima-treated-water-discharge)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:49:55+00:00

The operator of the crippled Fukushima Daiichi nuclear power plant finished releasing its sixth batch of treated radioactive water from the facility into the sea on Tuesday, with…

## Doctor convicted over girl's death in high-speed driving crash
 - [https://japantoday.com/category/crime/japan-doctor-convicted-over-girl%27s-death-in-high-speed-driving-crash](https://japantoday.com/category/crime/japan-doctor-convicted-over-girl%27s-death-in-high-speed-driving-crash)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:49:21+00:00

A Japanese court on Tuesday convicted a doctor of driving a sports car at speeds upward of 120 kilometers per hour and crashing into a minicar, leaving a…

## Ohtani's ex-interpreter pleads guilty in sports betting case
 - [https://japantoday.com/category/crime/Ohtani%27s-ex-interpreter-pleads-guilty-in-sports-betting-case](https://japantoday.com/category/crime/Ohtani%27s-ex-interpreter-pleads-guilty-in-sports-betting-case)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:49:08+00:00

The former interpreter for Los Angeles Dodgers star Shohei Ohtani pleaded guilty to bank and tax fraud on Tuesday and admitted to stealing nearly $17 million from the…

## Japan to replace cedars with low-pollen trees to tackle hay fever
 - [https://japantoday.com/category/national/japan-to-replace-cedars-with-low-pollen-trees-to-tackle-hay-fever](https://japantoday.com/category/national/japan-to-replace-cedars-with-low-pollen-trees-to-tackle-hay-fever)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:48:13+00:00

Japan on Tuesday decided to speed up replacing cedar forests with trees that produce less pollen as a measure to tackle hay fever, an allergy believed to affect…

## Nagasaki holds off inviting Israel to peace ceremony
 - [https://japantoday.com/category/politics/japan%27s-nagasaki-holds-off-inviting-israel-to-peace-ceremony](https://japantoday.com/category/politics/japan%27s-nagasaki-holds-off-inviting-israel-to-peace-ceremony)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:47:53+00:00

The Israeli ambassador to Japan has not yet been invited to Nagasaki's annual peace ceremony, said city officials who instead sent the embassy a letter calling for a…

## In Japan, energy security fears put nuclear power back in favor
 - [https://japantoday.com/category/national/in-japan-energy-security-fears-put-nuclear-back-in-favour-for-2040-plan](https://japantoday.com/category/national/in-japan-energy-security-fears-put-nuclear-back-in-favour-for-2040-plan)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T21:47:36+00:00

Japan is set to push for more nuclear power in an energy policy update due next year, seeking stable electricity supply in face of growing demand and heightening…

## Australian military to recruit some noncitzens in a bid to boost troop numbers
 - [https://japantoday.com/category/world/australian-military-will-recruit-some-noncitzens-in-a-bid-to-boost-troop-numbers](https://japantoday.com/category/world/australian-military-will-recruit-some-noncitzens-in-a-bid-to-boost-troop-numbers)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T07:46:45+00:00

The Australian military will begin recruiting some noncitizens in a bid to boost troop numbers, the government said Tuesday.
Only people from other members of the Five Eyes…

## From non-league to top of J.League for upstarts Machida
 - [https://japantoday.com/category/sports/from-non-league-to-top-of-the-league-for-japan-upstarts-machida](https://japantoday.com/category/sports/from-non-league-to-top-of-the-league-for-japan-upstarts-machida)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T07:34:25+00:00

Led by a former high-school coach and playing in a picturesque stadium surrounded by trees, Machida Zelvia are taking the J.League by storm in their debut season in…

## American arrested for stalking estranged wife in Gifu Prefecture
 - [https://japantoday.com/category/crime/american-arrested-for-stalking-estranged-wife-in-gifu-prefecture](https://japantoday.com/category/crime/american-arrested-for-stalking-estranged-wife-in-gifu-prefecture)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T07:34:06+00:00

Gifu Prefectural Police have arrested a 49-year-old American man in Yamagata City, Yamagata Prefecture, on suspicion of stalking his estranged wife.
According to police reports, he allegedly stalked…

## Emperor and empress to make three-day state visit to UK June 25-27
 - [https://japantoday.com/category/national/japan%27s-emperor-and-empress-to-pay-three-day-state-visit-to-uk](https://japantoday.com/category/national/japan%27s-emperor-and-empress-to-pay-three-day-state-visit-to-uk)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T07:33:24+00:00

Japan's Emperor Naruhito and Empress Masako will visit Britain at the end of June, spending three days as guests of King Charles III, Buckingham Palace confirmed on Tuesday.…

## Kishida says he won't dissolve Diet during ongoing session
 - [https://japantoday.com/category/politics/update3-japan-pm-kishida-says-he-won%27t-dissolve-diet-during-ongoing-session](https://japantoday.com/category/politics/update3-japan-pm-kishida-says-he-won%27t-dissolve-diet-during-ongoing-session)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T07:33:06+00:00

Japanese Prime Minister Fumio Kishida said Tuesday that he has no intention of dissolving the House of Representatives during the ongoing parliamentary session through June 23, with his…

## Asian shares decline after report shows U.S. manufacturing contracted in May
 - [https://japantoday.com/category/business/stock-market-today-asian-shares-decline-after-report-shows-us-manufacturing-contracted-in-may](https://japantoday.com/category/business/stock-market-today-asian-shares-decline-after-report-shows-us-manufacturing-contracted-in-may)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T06:42:50+00:00

Asian shares retreated on Tuesday after a report showed that U.S. manufacturing contracted in May, in the latest sign the economy is slowing.
Oil prices fell and U.S.…

## Olympic champion Axelsen out of Indonesia Open with ankle injury
 - [https://japantoday.com/category/sports/olympic-champion-axelsen-out-of-indonesia-open-with-ankle-injury](https://japantoday.com/category/sports/olympic-champion-axelsen-out-of-indonesia-open-with-ankle-injury)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T06:02:41+00:00

Olympic men's badminton champion Viktor Axelsen pulled out of this week's Indonesia Open with an ankle injury, weeks before he defends his title at the Paris Games.
The…

## Security tight in China and Hong Kong on Tiananmen crackdown anniversary
 - [https://japantoday.com/category/world/security-tight-in-china-and-hong-kong-on-tiananmen-crackdown-anniversary2](https://japantoday.com/category/world/security-tight-in-china-and-hong-kong-on-tiananmen-crackdown-anniversary2)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T03:27:52+00:00

Security was tight and access restricted to Beijing's Tiananmen Square on Tuesday, the 35th anniversary of the June 4 crackdown, while Hong Kong also increased policing as activists…

## Janis Paige, star of Hollywood and Broadway, dies at 101
 - [https://japantoday.com/category/entertainment/janis-paige-star-of-hollywood-and-broadway-dies-at-101](https://japantoday.com/category/entertainment/janis-paige-star-of-hollywood-and-broadway-dies-at-101)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-06-04T00:02:05+00:00

Janis Paige, a popular actor in Hollywood and in Broadway musicals and comedies who danced with Fred Astaire, toured with Bob Hope and continued to perform into her…

