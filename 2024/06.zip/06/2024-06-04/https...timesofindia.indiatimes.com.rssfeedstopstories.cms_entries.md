# Source:Times of India, URL:https://timesofindia.indiatimes.com/rssfeedstopstories.cms, language:en-gb

## Bloodbath on D-Street on result day: A record 4,390-pt crash in sensex
 - [https://timesofindia.indiatimes.com/business/india-business/bloodbath-on-d-street-on-result-day-a-record-4390-pt-crash-in-sensex/articleshow/110715630.cms](https://timesofindia.indiatimes.com/business/india-business/bloodbath-on-d-street-on-result-day-a-record-4390-pt-crash-in-sensex/articleshow/110715630.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T22:59:13+00:00



## Naidu’s back with a bang in Andhra, new disha in Odisha
 - [https://timesofindia.indiatimes.com/india/naidus-back-with-a-bang-in-andhra-new-disha-in-odisha/articleshow/110715095.cms](https://timesofindia.indiatimes.com/india/naidus-back-with-a-bang-in-andhra-new-disha-in-odisha/articleshow/110715095.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T22:42:04+00:00



## Saffron sweeps all 7 Delhi seats for 3rd time in row, takes Gurgaon, Noida, Ghaziabad too
 - [https://timesofindia.indiatimes.com/india/saffron-sweeps-all-7-delhi-seats-for-3rd-time-in-row-takes-gurgaon-noida-ghaziabad-too/articleshow/110714441.cms](https://timesofindia.indiatimes.com/india/saffron-sweeps-all-7-delhi-seats-for-3rd-time-in-row-takes-gurgaon-noida-ghaziabad-too/articleshow/110714441.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T22:27:54+00:00



## Big message is people don’t want Modi, Shah running country: Rahul
 - [https://timesofindia.indiatimes.com/india/big-message-is-people-dont-want-modi-shah-running-country-rahul-gandhi/articleshow/110714057.cms](https://timesofindia.indiatimes.com/india/big-message-is-people-dont-want-modi-shah-running-country-rahul-gandhi/articleshow/110714057.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T22:17:09+00:00



## Hat-Tricky: NDA 272 Paar, INDIA Raises Bar
 - [https://timesofindia.indiatimes.com/india/hat-tricky-nda-272-paar-india-raises-bar/articleshow/110713868.cms](https://timesofindia.indiatimes.com/india/hat-tricky-nda-272-paar-india-raises-bar/articleshow/110713868.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T21:27:01+00:00



## ‘Bold decisions’ to define third term, says PM Modi
 - [https://timesofindia.indiatimes.com/india/bold-decisions-to-define-third-term-says-modi-vows-war-against-graft/articleshow/110713825.cms](https://timesofindia.indiatimes.com/india/bold-decisions-to-define-third-term-says-modi-vows-war-against-graft/articleshow/110713825.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T21:18:47+00:00



## Chirag lights up NDA with 100% strike rate
 - [https://timesofindia.indiatimes.com/india/with-100-strike-rate-chirag-proves-he-is-real-political-heir-of-ram-vilas/articleshow/110713548.cms](https://timesofindia.indiatimes.com/india/with-100-strike-rate-chirag-proves-he-is-real-political-heir-of-ram-vilas/articleshow/110713548.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T20:17:03+00:00



## Cong secures 4 of 6 Himachal seats in bypolls, BJP all 5 in Gujarat
 - [https://timesofindia.indiatimes.com/india/congress-secures-4-of-6-himachal-seats-in-bypolls-bjp-bags-all-5-in-gujarat/articleshow/110713503.cms](https://timesofindia.indiatimes.com/india/congress-secures-4-of-6-himachal-seats-in-bypolls-bjp-bags-all-5-in-gujarat/articleshow/110713503.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T20:12:14+00:00



## India’s poorest and backward stood up to save Constitution: Rahul
 - [https://timesofindia.indiatimes.com/india/indias-poorest-and-backward-stood-up-to-save-constitution-says-rahul-gandhi/articleshow/110713453.cms](https://timesofindia.indiatimes.com/india/indias-poorest-and-backward-stood-up-to-save-constitution-says-rahul-gandhi/articleshow/110713453.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T20:06:49+00:00



## Prajwal Revanna fails, but Gowdas retain their Vokkaliga base
 - [https://timesofindia.indiatimes.com/india/prajwal-revanna-fails-but-gowdas-retain-their-vokkaliga-base/articleshow/110713377.cms](https://timesofindia.indiatimes.com/india/prajwal-revanna-fails-but-gowdas-retain-their-vokkaliga-base/articleshow/110713377.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T19:57:13+00:00



## Amit Shah stamps his supremacy in Gandhinagar with 7.4 lakh win
 - [https://timesofindia.indiatimes.com/india/amit-shah-stamps-his-supremacy-in-gandhinagar-with-7-4-lakh-win/articleshow/110713261.cms](https://timesofindia.indiatimes.com/india/amit-shah-stamps-his-supremacy-in-gandhinagar-with-7-4-lakh-win/articleshow/110713261.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T19:41:29+00:00



## Why is it a win-win for BJP, Congress and their allies
 - [https://timesofindia.indiatimes.com/india/lok-sabha-election-results-why-is-it-a-win-win-for-bjp-congress-and-their-allies/articleshow/110712069.cms](https://timesofindia.indiatimes.com/india/lok-sabha-election-results-why-is-it-a-win-win-for-bjp-congress-and-their-allies/articleshow/110712069.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T17:24:05+00:00



## BJP, Cong hang on to vote share but seat share swings wildly
 - [https://timesofindia.indiatimes.com/india/2024-lok-sabha-election-results-bjp-cong-hang-on-to-vote-share-but-seat-share-swings-wildly/articleshow/110711661.cms](https://timesofindia.indiatimes.com/india/2024-lok-sabha-election-results-bjp-cong-hang-on-to-vote-share-but-seat-share-swings-wildly/articleshow/110711661.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T16:53:04+00:00



## Indore set two unique records; don't miss the runner-up
 - [https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-in-indore-bjp-mp-lalwani-wins-by-record-margin-on-over-10-lakhs-second-spot-goes-to-nota/articleshow/110711708.cms](https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-in-indore-bjp-mp-lalwani-wins-by-record-margin-on-over-10-lakhs-second-spot-goes-to-nota/articleshow/110711708.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T16:43:11+00:00

The Indore Lok Sabha seat in Madhya Pradesh has set two unique record this Lok Sabha election. As results pour in, the Bharatiya Janata Party candidate Shankar Lalwani secured a victory with a record margin of 10,08,077. BJP's sitting MP from Indore Shankar Lalwani won and managed to get 12,26,751 seats. He defeated Bahujan Samaj Party's Sanjay Solanki who got 51,659 seats.

## Explained: Why NDA's victory feels like a defeat
 - [https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-explained-why-ndas-victory-feels-like-a-defeat/articleshow/110711216.cms](https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-explained-why-ndas-victory-feels-like-a-defeat/articleshow/110711216.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T15:55:26+00:00



## 'NDA's third term will see big decisions': PM Modi
 - [https://timesofindia.indiatimes.com/india/ndas-third-term-will-see-big-decisions-pm-modi-tells-party-workers-after-poll-verdict/articleshow/110709972.cms](https://timesofindia.indiatimes.com/india/ndas-third-term-will-see-big-decisions-pm-modi-tells-party-workers-after-poll-verdict/articleshow/110709972.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T15:41:51+00:00



## PM Modi 'broke' many parties, people broke his morale: Mamata
 - [https://timesofindia.indiatimes.com/india/pm-modi-broke-many-parties-people-broke-his-morale-mamata-banerjee-on-lok-sabha-results/articleshow/110708284.cms](https://timesofindia.indiatimes.com/india/pm-modi-broke-many-parties-people-broke-his-morale-mamata-banerjee-on-lok-sabha-results/articleshow/110708284.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T15:00:39+00:00



## Andhra polls: What Jagan Reddy said after big defeat by Naidu
 - [https://timesofindia.indiatimes.com/india/andhra-pradesh-assembly-election-results-2024-what-jagan-mohan-reddy-said-after-big-defeat/articleshow/110710273.cms](https://timesofindia.indiatimes.com/india/andhra-pradesh-assembly-election-results-2024-what-jagan-mohan-reddy-said-after-big-defeat/articleshow/110710273.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T14:52:57+00:00



## What PM Modi said on Lok Sabha results
 - [https://timesofindia.indiatimes.com/india/historical-feat-pm-modi-thanks-janata-in-his-first-reaction-post-ndas-win/articleshow/110710014.cms](https://timesofindia.indiatimes.com/india/historical-feat-pm-modi-thanks-janata-in-his-first-reaction-post-ndas-win/articleshow/110710014.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T14:40:31+00:00



## Kangana Ranaut's film emergency: All you need to know
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/kangana-ranauts-film-emergency-plot-release-date-cast-all-you-need-to-know-about-kanganas-directorial/articleshow/110709681.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/kangana-ranauts-film-emergency-plot-release-date-cast-all-you-need-to-know-about-kanganas-directorial/articleshow/110709681.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T14:21:12+00:00

Kangana Ranaut emerged victorious in the Lok Sabha Elections of 2024 and is transitioning to a successful political career, hinting at reducing her focus on acting due to the perceived insincerity of the film industry. Here's all you need to know about her next movie.

## Amethi's new giant killer: KL Sharma defeats Smriti Irani
 - [https://timesofindia.indiatimes.com/india/amethi-result-smriti-irani-kishori-lal-sharma-bjp-priyanka-lok-sabha-election-results-lok-sabha-results-rahul-gandhi/articleshow/110705402.cms](https://timesofindia.indiatimes.com/india/amethi-result-smriti-irani-kishori-lal-sharma-bjp-priyanka-lok-sabha-election-results-lok-sabha-results-rahul-gandhi/articleshow/110705402.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T12:53:04+00:00



## From Smriti to Adhir: Biggest upsets in Lok Sabha elections
 - [https://timesofindia.indiatimes.com/india/from-smriti-irani-to-adhir-ranjan-chowdhury-biggest-upsets-in-2024-lok-sabha-elections-rajeev-chandrasekhar-omar-abdullah/articleshow/110706600.cms](https://timesofindia.indiatimes.com/india/from-smriti-irani-to-adhir-ranjan-chowdhury-biggest-upsets-in-2024-lok-sabha-elections-rajeev-chandrasekhar-omar-abdullah/articleshow/110706600.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T12:23:37+00:00

The 2024 Lok Sabha elections have witnessed a number of startling outcomes, with certain well-known politicians encountering unforeseen losses in their bastions. One of the most significant upsets involves Union minister Smriti Irani, who seems to be on the brink of being defeated by Congress candidate Kishori Lal Sharma in the Amethi constituency. BJP candidate Rajeev Chandrasekhar admitted defeat to Congress' Shashi Tharoor in Thiruvananthapuram, while also recognizing the increasing backing for the BJP in Kerala.

## PM Modi wins Varanasi but sees big dip in vote share
 - [https://timesofindia.indiatimes.com/india/pm-modi-wins-varanasi-but-sees-big-dip-in-vote-share/articleshow/110706005.cms](https://timesofindia.indiatimes.com/india/pm-modi-wins-varanasi-but-sees-big-dip-in-vote-share/articleshow/110706005.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T12:09:30+00:00



## In INDIA bloc's UP upset, Priyanka Gandhi is the real winner
 - [https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-in-india-blocs-uttar-pradesh-upset-priyanka-gandhi-is-the-real-winner/articleshow/110705831.cms](https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-in-india-blocs-uttar-pradesh-upset-priyanka-gandhi-is-the-real-winner/articleshow/110705831.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T11:48:30+00:00

Uttar Pradesh has proved to be one of the best political thrillers on the result day of the Lok Sabha elections 2024. The 'UP ke ladke' Rahul Gandhi and Akhilesh Yadav gave a tough challenge to the Bharatiya Janata Party (BJP), as the INDIA bloc took away from BJP's seat share. But the one leader who has emerged as the real winner of Uttar Pradesh as her efforts finally paid off in this Lok Sabha election.

## Cong accuses candidates in UP of pressurising officials to ensure victory
 - [https://timesofindia.indiatimes.com/india/remember-that-govt-is-changing-jairam-ramesh-accuses-candidates-in-up-of-pressurising-officials-to-ensure-victory/articleshow/110704972.cms](https://timesofindia.indiatimes.com/india/remember-that-govt-is-changing-jairam-ramesh-accuses-candidates-in-up-of-pressurising-officials-to-ensure-victory/articleshow/110704972.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T11:18:54+00:00



## Investors lose Rs 30 lakh crore as BSE Sensex bleeds 4,390 points
 - [https://timesofindia.indiatimes.com/business/india-business/stock-market-crash-today-investors-lose-rs-30-lakh-crore-as-bse-sensex-bleeds-4390-points/articleshow/110704534.cms](https://timesofindia.indiatimes.com/business/india-business/stock-market-crash-today-investors-lose-rs-30-lakh-crore-as-bse-sensex-bleeds-4390-points/articleshow/110704534.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T11:14:35+00:00

Stock market crash today: At one point during the day, indices fell as much as 8.5%, reminiscent of the market turmoil witnessed during the onset of the Covid-19 pandemic.

## Biggest winners including Naidu, Akhilesh, Rahul and more..
 - [https://timesofindia.indiatimes.com/india/lok-sabha-elections-2024-winner-and-losers-list-smriti-irani-rahul-gandhi-ys-jagan-mohan-reddy-prajwal-revanna-akhilesh-yadav-nitish-kumar/articleshow/110702055.cms](https://timesofindia.indiatimes.com/india/lok-sabha-elections-2024-winner-and-losers-list-smriti-irani-rahul-gandhi-ys-jagan-mohan-reddy-prajwal-revanna-akhilesh-yadav-nitish-kumar/articleshow/110702055.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T10:16:12+00:00

Here are some of the biggest winners and losers of the 2024 Lok Sabha General Election and the Assembly Elections that were simultaneously held:

## 2024 Lok Sabha election results: 10 key takeaways
 - [https://timesofindia.indiatimes.com/india/2024-lok-sabha-election-results-10-key-takeaways-bjp-congress-nda-india-pm-modi-rahul-gandhi-seats-vote-share-hindi-heartland-odisha-ram-temple-assembly/articleshow/110697325.cms](https://timesofindia.indiatimes.com/india/2024-lok-sabha-election-results-10-key-takeaways-bjp-congress-nda-india-pm-modi-rahul-gandhi-seats-vote-share-hindi-heartland-odisha-ram-temple-assembly/articleshow/110697325.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T10:03:04+00:00



## Big setback for BJP, set to lose Ram temple constituency Faizabad
 - [https://timesofindia.indiatimes.com/india/faizabad-lok-sabha-election-results-2024-big-setback-for-bjp-set-to-lose-ram-temple-constituency-faizabad/articleshow/110701571.cms](https://timesofindia.indiatimes.com/india/faizabad-lok-sabha-election-results-2024-big-setback-for-bjp-set-to-lose-ram-temple-constituency-faizabad/articleshow/110701571.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T10:02:06+00:00



## IAF's Sukhoi aircraft crashes in Nashik; pilots eject safely
 - [https://timesofindia.indiatimes.com/india/iafs-sukhoi-aircraft-crashes-in-nashik-pilots-eject-safely/articleshow/110700161.cms](https://timesofindia.indiatimes.com/india/iafs-sukhoi-aircraft-crashes-in-nashik-pilots-eject-safely/articleshow/110700161.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T09:25:09+00:00



## Lok Sabha election results: 'No 400-paar, abki baar NDA sarkaar'
 - [https://timesofindia.indiatimes.com/india/nda-pm-modi-lok-sabha-election-results-lok-sabha-results-nda-chandrababu-naidu-nitish-kumar-bjp-congress/articleshow/110696917.cms](https://timesofindia.indiatimes.com/india/nda-pm-modi-lok-sabha-election-results-lok-sabha-results-nda-chandrababu-naidu-nitish-kumar-bjp-congress/articleshow/110696917.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T08:07:38+00:00



## Boost for Akhilesh as 'UP ke ladke' surprise BJP with tough fight
 - [https://timesofindia.indiatimes.com/india/uttar-pradesh-lok-sabha-election-results-2024-up-ke-ladke-surprise-with-nda-with-tough-fight-no-taker-for-bjps-ram-temple-pitch/articleshow/110697228.cms](https://timesofindia.indiatimes.com/india/uttar-pradesh-lok-sabha-election-results-2024-up-ke-ladke-surprise-with-nda-with-tough-fight-no-taker-for-bjps-ram-temple-pitch/articleshow/110697228.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T07:52:18+00:00



## Lok Sabha election results 2024: Return of regional parties
 - [https://timesofindia.indiatimes.com/india/lok-sabha-election-results-narendra-modi-akhilesh-yadav-uddhav-thackeray-rahul-gandhi-sharad-pawar-nitish-kumar-mamata-banerjee-chandrababu-naidu/articleshow/110695653.cms](https://timesofindia.indiatimes.com/india/lok-sabha-election-results-narendra-modi-akhilesh-yadav-uddhav-thackeray-rahul-gandhi-sharad-pawar-nitish-kumar-mamata-banerjee-chandrababu-naidu/articleshow/110695653.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T07:20:23+00:00



## T20 World Cup: Afghanistan hammer debutants Uganda
 - [https://timesofindia.indiatimes.com/sports/cricket/icc-mens-t20-world-cup/fazalhaq-farooqis-fifer-and-rahmanullah-gurbaz-ibrahim-zadran-power-afghanistan-to-125-run-win-over-uganda/articleshow/110690156.cms](https://timesofindia.indiatimes.com/sports/cricket/icc-mens-t20-world-cup/fazalhaq-farooqis-fifer-and-rahmanullah-gurbaz-ibrahim-zadran-power-afghanistan-to-125-run-win-over-uganda/articleshow/110690156.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T04:48:27+00:00

Afghanistan secured a dominant 125-run victory against Uganda in the T20 World Cup, thanks to stellar performances from Rahmanullah Gurbaz (76 off 45) and Ibrahim Zadran (70 off 46), who led to a total of 183/5. Fazalhaq Farooqi’s five-wicket haul for just nine runs dismantled Uganda, limiting them to 58 runs.

## LS polls: Who is leading in UP, Maha and other key states
 - [https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-vote-counting-begins-know-who-is-leading-in-up-maharashtra-delhi-and-other-key-states-across-india/articleshow/110689239.cms](https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-vote-counting-begins-know-who-is-leading-in-up-maharashtra-delhi-and-other-key-states-across-india/articleshow/110689239.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T04:35:35+00:00

Counting of votes for the Lok Sabha 2024 elections has begun, revealing early trends of NDA and the INDIA bloc. The NDA secured 353 seats in 2019, while the INDIA bloc comprises major opposition parties united against the BJP.

## Lok Sabha: Early trends in favour of NDA
 - [https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-highlights-hourly-updates-all-need-to-know-so-far/articleshow/110684111.cms](https://timesofindia.indiatimes.com/india/lok-sabha-election-results-2024-highlights-hourly-updates-all-need-to-know-so-far/articleshow/110684111.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T03:04:47+00:00



## Lok Sabha 2024 results: Key candidates in fray
 - [https://timesofindia.indiatimes.com/india/lok-sabha-2024-results-key-candidates-in-fray/articleshow/110684722.cms](https://timesofindia.indiatimes.com/india/lok-sabha-2024-results-key-candidates-in-fray/articleshow/110684722.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T01:46:58+00:00



## Giant-killer Praggnanandhaa stuns world champion Ding Liren
 - [https://timesofindia.indiatimes.com/sports/chess/r-praggnanandhaa-stuns-world-champion-ding-liren-at-norway-chess-tournament/articleshow/110683308.cms](https://timesofindia.indiatimes.com/sports/chess/r-praggnanandhaa-stuns-world-champion-ding-liren-at-norway-chess-tournament/articleshow/110683308.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-06-04T00:11:12+00:00

R Praggnanandhaa continued his streak of upsets by defeating World Champion Ding Liren in the armageddon game at the Norway Chess tournament on Monday. This victory followed Praggnanandhaa’s impressive wins against higher-ranked players like Magnus Carlsen and Fabiano Caruana, solidifying his reputation as a formidable young talent in the chess world.

