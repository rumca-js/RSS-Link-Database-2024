# Source:Y Combinator, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcefcZRL2oaA_uBNeo5UOWg, language:en

## The internet weirdo to new industries pipeline
 - [https://www.youtube.com/watch?v=oXHOqwLpfCo](https://www.youtube.com/watch?v=oXHOqwLpfCo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcefcZRL2oaA_uBNeo5UOWg
 - date published: 2024-06-04T17:20:44+00:00



