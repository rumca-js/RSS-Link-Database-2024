# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Nigel Farage wrócił do polityki. Na powitanie oblano go koktajlem
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/nigel-farage-wrocil-do-polityki-chlodne-powitanie-malo-powiedziane](https://www.polsatnews.pl/wiadomosc/2024-06-04/nigel-farage-wrocil-do-polityki-chlodne-powitanie-malo-powiedziane)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T19:40:00+00:00

Nigel Farage został oblany milkshakem. Podobna sytuacja miała miejsce pięć lat temu, także podczas kampanii wyborczej. Teraz sprawczyni nie wyjaśniła swoich pobudek, ale świadkowie twierdzą, że kobieta miała podobne intencje, co napastnik sprzed lat. Tym razem polityk zareagował inaczej i wykorzystał swoją popularność.

## Putin zadecydował w sprawie Szojgu. Były kremlowski szef MON z nową funkcją
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/putin-zadecydowal-w-sprawie-szojgu-byly-kremlowski-szef-mon-z-nowa-funkcja](https://www.polsatnews.pl/wiadomosc/2024-06-04/putin-zadecydowal-w-sprawie-szojgu-byly-kremlowski-szef-mon-z-nowa-funkcja)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T19:22:00+00:00

Władimir Putin powierzył nowe funkcje byłemu ministrowi obrony Rosji Siergiejowi Szojgu. Pełniący rolę sekretarza Rady Bezpieczeństwa generał odpowiadać będzie za koordynację prac z przemyśle zbrojeniowym.

## Dyskusja o Polsce w rosyjskiej telewizji. "10 minut i przestanie istnieć"
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/dyskusja-o-polsce-w-rosyjskiej-telewizji-10-minut-i-przestanie-istniec](https://www.polsatnews.pl/wiadomosc/2024-06-04/dyskusja-o-polsce-w-rosyjskiej-telewizji-10-minut-i-przestanie-istniec)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T14:50:00+00:00

O wybuchu poważnej wojny w Polsce mówił w rosyjskiej telewizji gość Władimira Sołowjowa. Mężczyzna, który przedstawił się jako politolog, stwierdził, że nasz kraj - za sprawą Kremla - może zniknąć w około kwadrans, a Europejczycy nie zdają sobie sprawy z zagrożenia.

## Media: NATO przygotowuje drogę przerzutu amerykańskich wojsk do Europy
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/media-nato-przygotowuje-droge-przerzutu-amerykanskich-wojsk-do-europy](https://www.polsatnews.pl/wiadomosc/2024-06-04/media-nato-przygotowuje-droge-przerzutu-amerykanskich-wojsk-do-europy)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T11:18:00+00:00

NATO ma przygotowywać plan przerzutu wojsk w przypadku wojny lądowej z Rosją - wynika z doniesień The telegraph. Opracowywanych ma być wiele korytarzy lądowych, którymi armie sojusznicze miałby dotrzeć na linię frontu. W pierwotnej wersji transporty mają zostać kierowane do Polski.

## Śmierć Polaków z rąk Hamasu. Jest komunikat MSZ
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/smierc-polakow-z-rak-hamasu-jest-komunikat-msz](https://www.polsatnews.pl/wiadomosc/2024-06-04/smierc-polakow-z-rak-hamasu-jest-komunikat-msz)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T10:39:00+00:00

Jesteśmy głęboko zasmuceni śmiercią kolejnych czterech zakładników uprowadzonych przez Hamas. Byli wśród nich dwaj obywatele RP - poinformowało Ministerstwo Spraw Zagranicznych. Wcześniej komunikat w tej sprawie przekazały Siły Obronne Izraela, nie podając jednak dokładnych okoliczności. Do tej pory z rąk Hamasu zginęło 41 zakładników.

## Brazylia: Najdroższa krowa świata sprzedana. Jest warta miliony
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/brazylia-najdrozsza-krowa-swiata-sprzedana-jest-warta-miliony](https://www.polsatnews.pl/wiadomosc/2024-06-04/brazylia-najdrozsza-krowa-swiata-sprzedana-jest-warta-miliony)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T10:29:00+00:00

Śnieżnobiała Viatina-19 to najdroższa krowa, jaką kiedykolwiek sprzedano na aukcji. Jej cena wyniosła 4,2 mln dolarów, czyli trzy razy więcej niż w przypadku poprzedniej rekordzistki. Zwierzę jest wyjątkowe, zwłaszcza ze względu na swoją masę. Krowa waży ponad 1100 kg, czyli dwa razy tyle co przeciętny osobnik tej rasy.

## Popularna dzielnica turystyczna wprowadza zakaz. Chodzi o napoje
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/popularna-dzielnica-turystyczna-wprowadza-prohibicje-to-przez-podroznych](https://www.polsatnews.pl/wiadomosc/2024-06-04/popularna-dzielnica-turystyczna-wprowadza-prohibicje-to-przez-podroznych)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T10:13:00+00:00

Dzielnica Shibuya w Tokio postanowiła wprowadzić ograniczenia w spożywaniu alkoholu. Zakaz picia w miejscach publicznych będzie obowiązywać w konkretnych godzinach, co ma wpłynąć na bezpieczeństwo mieszkańców i turystów. Co ciekawe, to nie pierwsze ograniczenia w tej dzielnicy. Wcześniej zakazano tu imprez związanych z Halloween.

## Niesamowite odkrycie we Włoszech. Na miejscu niebieskie ściany
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/pompeje](https://www.polsatnews.pl/wiadomosc/2024-06-04/pompeje)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T05:20:00+00:00

W Pompejach dokonano nowego odkrycia. Archeolodzy odnaleźli dobrze zachowane sanktuarium. Niewielkie pomieszczenie skrywało w sobie piękne malowidła i cenne przedmioty. Eksperci są zgodni, że niebieski kolor ścian sprawia, iż pokój jest niezwykle wyjątkowy.

## Ukraińskie służby ścigają Hawryłczuka. Werbuje uczniów
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/ukrainskie-sluzby-scigaja-hawrylczuka-werbuje-uczniow-do-udzialu-w-wojnie](https://www.polsatnews.pl/wiadomosc/2024-06-04/ukrainskie-sluzby-scigaja-hawrylczuka-werbuje-uczniow-do-udzialu-w-wojnie)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T05:18:00+00:00

Służba Bezpieczeństwa Ukrainy ściga szefa rosyjskiej organizacji paramilitarnej Junarmia. Mężczyzna ma werbować uczniów do udziału w wojnie przeciwko Ukrainie poprzez roszyłanie odpowiednich komunikatów do placówek. Tym samym służby nadały mu status podejrzanego ws. naruszenia praw i zwyczajów wojny.

## Rosja. Kreml przestrzega USA: Lekceważą powagę odwetu
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/rosyjski-minister-przestrzega-usa-lekcewaza-powage-odwetu-z-jakim-moga-sie-spotkac](https://www.polsatnews.pl/wiadomosc/2024-06-04/rosyjski-minister-przestrzega-usa-lekcewaza-powage-odwetu-z-jakim-moga-sie-spotkac)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T05:17:00+00:00

- Z nieznanych powodów lekceważą powagę odwetu, z jakim mogą się spotkać - stwierdził wiceminister spraw zagranicznych Rosji Siergiej Riabkow, w kontekście udzielenia zgody przez Stany Zjednoczone do wykorzystania amerykańskiej broni na terytorium Rosji. Kreml grozi śmiertelnymi konsekwencjami.

## Rosja. Mieszkańcy Biełgorodu skarżą się na sytuację. "Nie spałam całą noc"
 - [https://www.polsatnews.pl/wiadomosc/2024-06-04/rosja-mieszkancy-bielgorodu-skarza-sie-na-sytuacje-nie-spalam-cala-noc](https://www.polsatnews.pl/wiadomosc/2024-06-04/rosja-mieszkancy-bielgorodu-skarza-sie-na-sytuacje-nie-spalam-cala-noc)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-06-04T04:11:00+00:00

Ukraiński wywiad przechwycił rozmowę mieszkańców Szebiekina w obwodzie biełgorodzkim. Z nagrania wynika, że Rosjanie są rozczarowani niskim morale i pomysłem utworzenia w regionie strefy sanitarnej. Decyzja ma mieć związek z częstszymi atakami ze strony Ukrainy. - Nie spałam ostatniej nocy. Bombardowali tak mocno. Jest coraz gorzej - skarżyła się Rosjanka.

