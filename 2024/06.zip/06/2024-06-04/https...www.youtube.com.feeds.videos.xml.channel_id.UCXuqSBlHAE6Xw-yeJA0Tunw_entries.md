# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## This is NVIDIA’s new GPU
 - [https://www.youtube.com/watch?v=7a0UGHvxrLw](https://www.youtube.com/watch?v=7a0UGHvxrLw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2024-06-04T18:24:57+00:00

Get a 15-day free trial for unlimited backup at https://www.backblaze.com/landing/podcast-ltt.html

Check out Ridge’s Father’s Day sale at https://www.ridge.com/LINUS

Linus explores the NVIDIA booth at Computex 2024 looking at one of the LARGEST GPUs we have ever seen, well since its the size of a Server Rack. They also look at Network switches, and use cases for AI in Video Gamers!

Discuss on the forum: https://linustechtips.com/topic/1572555-this-is-nvidia%E2%80%99s-new-gpu/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► GET A VPN: http://www.piavpn.com/linus
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► EQUIPMENT WE USE TO FILM LTT: https://lmg.gg/LTTEquipment
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Faceb

