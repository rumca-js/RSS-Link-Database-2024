# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Proof
 - [https://www.youtube.com/watch?v=DMYZg8_22y8](https://www.youtube.com/watch?v=DMYZg8_22y8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-06-04T21:19:20+00:00

By definition, these serious adverse events lead to either death, 

are life-threatening, 

require inpatient (prolongation of) hospitalisation, 

cause persistent/significant disability/incapacity, 

concern a congenital anomaly/birth defect

or include a medically important event according to medical judgement

Covid vaccines may have helped fuel rise in excess deaths

Experts call for more research into side effects and possible links to mortality rates

https://www.telegraph.co.uk/news/2024/06/04/covid-vaccines-may-have-helped-fuel-rise-in-excess-deaths/

https://medicalxpress.com/news/2024-06-high-excess-death-west-years.html

Competing interests: None declared.

https://bmjpublichealth.bmj.com/content/2/1/e000282

Excess mortality has remained high in the Western World for three consecutive years, despite the implementation of containment measures and COVID-19 vaccines. 

This raises serious concerns. 

Government leaders and policymakers need to thoroughly investigate the under

## Vitamin D and Global change
 - [https://www.youtube.com/watch?v=gM2CIbzWmUQ](https://www.youtube.com/watch?v=gM2CIbzWmUQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-06-04T15:49:16+00:00

Download a free copy of VITAMIN D3 and the Great Biology Reset, by Professor David Anderson and Dr David Grimes. https://dgreatbiologyreset.com/#download

Dr Grime’s book to introduce the importance of vitamin D
https://yorkbookshop.com/health-and-personal-development/307-vitamin-d-deficiency-and-covid-19-its-central-role-in-a-world-pandemic.html

Welcome to Professor David Coussmaker Anderson, who has had a lifetime in medicine, consultant physician, professor of endocrinology, medical researcher, medical author, medical teacher and lecturer. Member of the royal society of medicine, member of the American endocrine society … we could go on.

