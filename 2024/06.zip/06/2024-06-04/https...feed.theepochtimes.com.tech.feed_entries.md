# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## US Suffers Most Data Breaches of All the World’s Countries, Report Says
 - [https://www.theepochtimes.com/us/us-suffers-most-data-breaches-of-all-the-worlds-countries-report-says-5662602](https://www.theepochtimes.com/us/us-suffers-most-data-breaches-of-all-the-worlds-countries-report-says-5662602)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-06-04T21:38:41+00:00

(Color4260/Shutterstock)

## ANALYSIS: Elon Musk Officially Joins the AI Battle, Predicts Human Job Losses
 - [https://www.theepochtimes.com/tech/analysis-elon-musk-officially-joins-the-ai-battle-predicts-human-job-losses-5662259](https://www.theepochtimes.com/tech/analysis-elon-musk-officially-joins-the-ai-battle-predicts-human-job-losses-5662259)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-06-04T10:17:53+00:00

Elon Musk, co-founder of Tesla and SpaceX and owner of X Holdings Corp., speaks at the Milken Institute's Global Conference at the Beverly Hilton Hotel, in Calif., on May 6, 2024. (Apu Gomes/Getty Images)

## One Pill Solution? 3D Printing Aims to Create Custom Medication
 - [https://www.theepochtimes.com/health/one-pill-solution-3d-printing-aims-to-create-custom-medication-5655063](https://www.theepochtimes.com/health/one-pill-solution-3d-printing-aims-to-create-custom-medication-5655063)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-06-04T10:00:29+00:00

(Gumpanat/Shutterstock)

## Uber Introduces ‘CO2 Emission Savings’ Tracker for Passengers
 - [https://www.theepochtimes.com/world/uber-introduces-emission-savings-tracker-for-passengers-5662150](https://www.theepochtimes.com/world/uber-introduces-emission-savings-tracker-for-passengers-5662150)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-06-04T04:51:40+00:00

The Uber logo in London on March 17, 2021. (Hollie Adams/Getty Images)

