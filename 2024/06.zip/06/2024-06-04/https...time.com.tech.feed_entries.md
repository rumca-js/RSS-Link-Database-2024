# Source:TIME - tech, URL:https://time.com/tech/feed, language:en-UK

## Ikea is Hiring 10 Roblox Players to Work at In-Game Store
 - [https://time.com/6985642/ikea-hiring-workers-roblox-game](https://time.com/6985642/ikea-hiring-workers-roblox-game)
 - RSS feed: https://time.com/tech/feed
 - date published: 2024-06-04T22:01:23+00:00

Ikea is assembling a team of Roblox players to work at its virtual store—and you can even get paid for the job.

## Employees Say OpenAI and Google DeepMind Are Hiding Dangers from the Public
 - [https://time.com/6985504/openai-google-deepmind-employees-letter](https://time.com/6985504/openai-google-deepmind-employees-letter)
 - RSS feed: https://time.com/tech/feed
 - date published: 2024-06-04T17:29:42+00:00

A group of current and former employees at OpenAI and Google DeepMind published a letter warning against the dangers of advanced AI.

