# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Facebook’s Ad Algorithm Pushes Black Users to For-Profit Colleges
 - [https://theintercept.com/2024/06/04/facebook-ads-algorithm-for-profit-colleges](https://theintercept.com/2024/06/04/facebook-ads-algorithm-for-profit-colleges)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-06-04T16:48:24+00:00

<p>Researchers tested for bias in Facebook’s algorithm by purchasing ads promoting for-profit colleges and studying who saw them.</p>
<p>The post <a href="https://theintercept.com/2024/06/04/facebook-ads-algorithm-for-profit-colleges/">Facebook’s Ad Algorithm Pushes Black Users to For-Profit Colleges</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## Imran Khan Remains Imprisoned Over His Wife’s Menstrual Cycles. State Department Says That’s “Something For the Pakistani Courts to Decide.”
 - [https://theintercept.com/2024/06/04/pakistan-imran-khan-wife-prison-marriage](https://theintercept.com/2024/06/04/pakistan-imran-khan-wife-prison-marriage)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-06-04T15:34:13+00:00

<p>The charge of an illegitimate marriage is all that’s left after a court acquitted Khan over his handling of a classified cypher.</p>
<p>The post <a href="https://theintercept.com/2024/06/04/pakistan-imran-khan-wife-prison-marriage/">Imran Khan Remains Imprisoned Over His Wife’s Menstrual Cycles. State Department Says That’s “Something For the Pakistani Courts to Decide.”</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## For Decades, Officials Knew a School Sat on a Former Dump — and Did Little to Clean Up the Toxins
 - [https://theintercept.com/2024/06/04/gainesville-florida-alachua-school-toxic-contaminated](https://theintercept.com/2024/06/04/gainesville-florida-alachua-school-toxic-contaminated)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-06-04T10:00:00+00:00

<p>In Gainesville, Florida, children are on the front lines of the hazards long ignored by local and state government officials.</p>
<p>The post <a href="https://theintercept.com/2024/06/04/gainesville-florida-alachua-school-toxic-contaminated/">For Decades, Officials Knew a School Sat on a Former Dump — and Did Little to Clean Up the Toxins</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## Columbia Law Review Refused to Take Down Article on Palestine, So Its Board of Directors Nuked the Whole Website
 - [https://theintercept.com/2024/06/03/columbia-law-review-palestine-board-website](https://theintercept.com/2024/06/03/columbia-law-review-palestine-board-website)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-06-04T02:37:29+00:00

<p>The students who edit the journal sought out the article by a Palestinian scholar who was censored by Harvard Law Review last year.</p>
<p>The post <a href="https://theintercept.com/2024/06/03/columbia-law-review-palestine-board-website/">Columbia Law Review Refused to Take Down Article on Palestine, So Its Board of Directors Nuked the Whole Website</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

