# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Why are some Taylor Swift fans reporting post-concert amnesia?
 - [https://www.lemonde.fr/en/science/article/2024/06/04/why-are-some-taylor-swift-fans-reporting-post-concert-amnesia_6673740_10.html](https://www.lemonde.fr/en/science/article/2024/06/04/why-are-some-taylor-swift-fans-reporting-post-concert-amnesia_6673740_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2024-06-04T12:19:16+00:00

Known as 'transient global amnesia,' this not-so-rare phenomenon has been described in connection with emotionally-charged events.

## China's spacecraft carrying rocks from the far side of the moon back to Earth
 - [https://www.lemonde.fr/en/science/article/2024/06/04/china-s-spacecraft-carrying-rocks-from-the-far-side-of-the-moon-back-to-earth_6673699_10.html](https://www.lemonde.fr/en/science/article/2024/06/04/china-s-spacecraft-carrying-rocks-from-the-far-side-of-the-moon-back-to-earth_6673699_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2024-06-04T03:40:18+00:00

The moon program is part of a growing rivalry with the US – still the leader in space exploration – and others, including Japan and India.

