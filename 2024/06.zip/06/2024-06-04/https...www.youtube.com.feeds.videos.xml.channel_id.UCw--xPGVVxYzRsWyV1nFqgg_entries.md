# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Stormlight 5 Finished!🎉 George R.R. Martin Shades Hollywood😎 Tom Bombadil First Look🧙~FN~
 - [https://www.youtube.com/watch?v=PdZtJeP_MjY](https://www.youtube.com/watch?v=PdZtJeP_MjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2024-06-04T13:00:31+00:00

Huge thank you to  @NerdoftheRings  for hosting this week's fantasy news! Be sure to check them out for some of the best LOTR content in town! 
New second channel: https://www.youtube.com/channel/UCC-EqiFg67s2Nd0imgRXg5w 

Gear:
Sony a7 iii: https://amzn.to/3yyVa6Q 
Lens: https://amzn.to/3wOwman 
Microphone: https://amzn.to/4byjDHW 
Sound Board: https://amzn.to/4aybOkn 
Light diffuser: https://amzn.to/3KhcIXM 

My books
Neon Ghosts: https://shop.wraithmarked.com/collections/standard-editions-1/products/neon-ghosts-a-witchs-sin-hardcover
Breach of Peace: https://tinyurl.com/BoPTLT  
Rebels Creed: https://tinyurl.com/RCTLTDG 
merch: https://www.danielbgreene.com

Patreon: https://www.patreon.com/DanielBGreene 
Join the Discord here: https://discord.gg/xUrPj6EP3f
All the Me Social Links: https://linktr.ee/DanielGreene

