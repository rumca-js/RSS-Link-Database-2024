# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## We All Owe Him An Apology
 - [https://www.youtube.com/watch?v=KiJ56t9O4xA](https://www.youtube.com/watch?v=KiJ56t9O4xA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-06-04T18:30:11+00:00

My waifu cup is here https://gamersupps.gg/products/moistcr1tikal
This is the greatest zoom court twist of All Time

## Coke vs Pepsi
 - [https://www.youtube.com/watch?v=W2iFptJCeRM](https://www.youtube.com/watch?v=W2iFptJCeRM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-06-04T00:00:21+00:00

My waifu cup is here https://gamersupps.gg/products/moistcr1tikal
This is the greatest big brand showdown of All Time

