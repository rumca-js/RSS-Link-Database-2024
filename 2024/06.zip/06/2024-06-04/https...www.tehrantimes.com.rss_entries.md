# Source:Tehran Times, URL:https://www.tehrantimes.com/rss, language:en-US

## 14788
 - [https://www.tehrantimes.com/news/499438/14788](https://www.tehrantimes.com/news/499438/14788)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T21:31:00+00:00



## Meet the 15 possible contenders for Iran's 2024 presidential snap elections
 - [https://www.tehrantimes.com/news/499437/Meet-the-15-possible-contenders-for-Iran-s-2024-presidential](https://www.tehrantimes.com/news/499437/Meet-the-15-possible-contenders-for-Iran-s-2024-presidential)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T20:46:29+00:00

TEHRAN – Iran’s Guardian Council has been given five days to vet the candidates running for presidency after candidate registration for snap elections came to an end on Monday.

## Meet the 15 possible contenders for the snap presidential elections in Iran
 - [https://www.tehrantimes.com/news/499437/Meet-the-15-possible-contenders-for-the-snap-presidential-elections](https://www.tehrantimes.com/news/499437/Meet-the-15-possible-contenders-for-the-snap-presidential-elections)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T20:46:29+00:00

TEHRAN – Iran’s Guardian Council has been given five days to vet the candidates running for presidency after candidate registration for snap elections came to an end on Monday.

## Iran laments international inaction amid devastation in Gaza
 - [https://www.tehrantimes.com/news/499431/Iran-laments-international-inaction-amid-devastation-in-Gaza](https://www.tehrantimes.com/news/499431/Iran-laments-international-inaction-amid-devastation-in-Gaza)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T19:16:02+00:00

TEHRAN — Iran's Foreign Ministry spokesman has lamented the inaction by international organizations in response to the Israeli onslaught in the Gaza Strip, attributing this passivity to the destruction of 55% of buildings in Gaza since October 7 last year.

## Vetting of presidential candidates commences
 - [https://www.tehrantimes.com/news/499432/Vetting-of-presidential-candidates-commences](https://www.tehrantimes.com/news/499432/Vetting-of-presidential-candidates-commences)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T19:15:26+00:00

TEHRAN – The Constitutional Council on Tuesday started its vetting of candidates for the June 28 presidential election.

## 'Palestinian cause' is a monumental legacy of Imam Khomeini: ambassador
 - [https://www.tehrantimes.com/news/499433/Palestinian-cause-is-a-monumental-legacy-of-Imam-Khomeini](https://www.tehrantimes.com/news/499433/Palestinian-cause-is-a-monumental-legacy-of-Imam-Khomeini)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T19:14:53+00:00

TEHRAN — The Iranian ambassador to Berlin has said the issue of Palestine and al-Quds stand as among the most significant legacies of the late Imam Khomeini, founder of the Islamic Revolution, IRNA reported on Tuesday.

## Interim president praises late Amir Abdollahian’s dedication to resistance front
 - [https://www.tehrantimes.com/news/499435/Interim-president-praises-late-Amir-Abdollahian-s-dedication](https://www.tehrantimes.com/news/499435/Interim-president-praises-late-Amir-Abdollahian-s-dedication)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T19:09:21+00:00

TEHRAN – Interim President Mohammad Mokhber has hailed the late Foreign Minister Hossein Amir Abdollahian as a revolutionary diplomat who dedicated his efforts to the Axis of Resistance, expressing hope that his efforts would ultimately lead to the liberation of Al-Quds.

## Iran’s acting FM meets Assad, says resistance is vital to prevent tensions
 - [https://www.tehrantimes.com/news/499434/Iran-s-acting-FM-meets-Assad-says-resistance-is-vital-to-prevent](https://www.tehrantimes.com/news/499434/Iran-s-acting-FM-meets-Assad-says-resistance-is-vital-to-prevent)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T19:00:24+00:00

TEHRAN – The acting Foreign Minister of Iran has delved into talks with Syrian President Bashar al-Assad, emphasizing resistance as the fundamental way to successfully prevent regional tensions.

## Tehran threatens response to potential anti-Iran resolution at IAEA
 - [https://www.tehrantimes.com/news/499436/Tehran-threatens-response-to-potential-anti-Iran-resolution-at](https://www.tehrantimes.com/news/499436/Tehran-threatens-response-to-potential-anti-Iran-resolution-at)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T18:52:02+00:00

TEHRAN – The head of the Atomic Energy Organization of Iran (AEOI), Mohammad Eslami, warned on Tuesday that Iran would firmly respond if an anti-Iran draft resolution submitted by European states to the UN nuclear watchdog's Board of Governors is approved.

## Oxfam: Two-thirds of population crammed into one-fifth of Gaza
 - [https://www.tehrantimes.com/news/499430/Oxfam-Two-thirds-of-population-crammed-into-one-fifth-of-Gaza](https://www.tehrantimes.com/news/499430/Oxfam-Two-thirds-of-population-crammed-into-one-fifth-of-Gaza)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:22:13+00:00

About 1.7 million Palestinians are estimated to be crammed into just one-fifth of the Gaza Strip, after more than one million people fled Rafah, according to the aid group Oxfam.

## Israel: More than a third of Gaza captives are dead
 - [https://www.tehrantimes.com/news/499429/Israel-More-than-a-third-of-Gaza-captives-are-dead](https://www.tehrantimes.com/news/499429/Israel-More-than-a-third-of-Gaza-captives-are-dead)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:21:27+00:00

Israel believes that more than a third of the remaining Gaza captives are dead, a cabinet tally showed on Tuesday.

## Education Ministry: Over 15,000 children killed in Gaza
 - [https://www.tehrantimes.com/news/499428/Education-Ministry-Over-15-000-children-killed-in-Gaza](https://www.tehrantimes.com/news/499428/Education-Ministry-Over-15-000-children-killed-in-Gaza)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:21:04+00:00

The Ministry of Education said that more than 15,000 Palestinian children have been killed since the start of Israel’s war against the Gaza Strip, the majority of them school and kindergarten students, in addition to 64 students from schools in the West Bank, including Jerusalem (al-Quds).

## Japan's Nagasaki holds off inviting Israel to peace ceremony
 - [https://www.tehrantimes.com/news/499427/Japan-s-Nagasaki-holds-off-inviting-Israel-to-peace-ceremony](https://www.tehrantimes.com/news/499427/Japan-s-Nagasaki-holds-off-inviting-Israel-to-peace-ceremony)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:20:44+00:00

The Israeli ambassador to Japan has not yet been invited to Nagasaki's annual peace ceremony, said city officials who instead sent the embassy a letter calling for a Gaza ceasefire.

## Biden suggests Netanyahu prolonging war for political benefits
 - [https://www.tehrantimes.com/news/499426/Biden-suggests-Netanyahu-prolonging-war-for-political-benefits](https://www.tehrantimes.com/news/499426/Biden-suggests-Netanyahu-prolonging-war-for-political-benefits)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:20:21+00:00

US President Joe Biden in a new interview said it was reasonable for people to conclude that Israeli Prime Minister Benjamin Netanyahu is prolonging the war in Gaza for his own political benefit.

## Israel drops over 70,000 tons of bombs on Gaza
 - [https://www.tehrantimes.com/news/499425/Israel-drops-over-70-000-tons-of-bombs-on-Gaza](https://www.tehrantimes.com/news/499425/Israel-drops-over-70-000-tons-of-bombs-on-Gaza)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:20:01+00:00

Israel has dropped more than 70,000 tons of bombs on the Gaza Strip since last October, far surpassing those dropped on Dresden, Hamburg, and London combined during World War II.

## UN accuses Israel of ‘wanton’ killing in West Bank
 - [https://www.tehrantimes.com/news/499424/UN-accuses-Israel-of-wanton-killing-in-West-Bank](https://www.tehrantimes.com/news/499424/UN-accuses-Israel-of-wanton-killing-in-West-Bank)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:19:37+00:00

UN Human Rights Chief Volker Türk issued a renewed call for an end to the sharp rise in deadly violence in the occupied West Bank since October 7, and urged accountability for the killing of over 500 Palestinians by Israeli forces and settlers.

## Biden's declaration: A planned ceasefire or declared hidden defeat?
 - [https://www.tehrantimes.com/news/499423/Biden-s-declaration-A-planned-ceasefire-or-declared-hidden-defeat](https://www.tehrantimes.com/news/499423/Biden-s-declaration-A-planned-ceasefire-or-declared-hidden-defeat)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:19:11+00:00

BEIRUT - US President Joe Biden’s speech on Friday, May 31, which sought to cover up the Israeli occupation entity’s failure to weaken the Gazan resistance, came after strong fighting by the resistance front.

## Palestinians awaiting explicit Israeli approval of ceasefire
 - [https://www.tehrantimes.com/news/499422/Palestinians-awaiting-explicit-Israeli-approval-of-ceasefire](https://www.tehrantimes.com/news/499422/Palestinians-awaiting-explicit-Israeli-approval-of-ceasefire)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:18:30+00:00

TEHRAN- A leading source in the Palestinian resistance movement has told regional media that Tel Aviv has reluctantly complied with what Hamas insisted on in its conditions during negotiations to end the American-backed Israeli war on the Gaza Strip.

## Abu Mazen appeasing apartheid
 - [https://www.tehrantimes.com/news/499421/Abu-Mazen-appeasing-apartheid](https://www.tehrantimes.com/news/499421/Abu-Mazen-appeasing-apartheid)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T16:15:05+00:00

TEHRAN - President Mahmoud Abbas, who has led the Palestinian Authority (PA) for nearly two decades, has faced widespread criticism over his inaction toward Israeli atrocities against Palestinians both in the West Bank and in the Gaza Strip.

## Songlines Magazine picks 2 Iranian music albums among world’s best
 - [https://www.tehrantimes.com/news/499420/Songlines-Magazine-picks-2-Iranian-music-albums-among-world-s](https://www.tehrantimes.com/news/499420/Songlines-Magazine-picks-2-Iranian-music-albums-among-world-s)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T15:34:23+00:00

TEHRAN-Two music albums by Iranian musicians are among the best albums selected by Songlines in its May issue. This British magazine covers music from traditional and popular to contemporary and fusion, featuring artists from around the globe.

## 5 Iranian movies win awards at Bulgaria’s Golden FEMI Film Festival
 - [https://www.tehrantimes.com/news/499419/5-Iranian-movies-win-awards-at-Bulgaria-s-Golden-FEMI-Film-Festival](https://www.tehrantimes.com/news/499419/5-Iranian-movies-win-awards-at-Bulgaria-s-Golden-FEMI-Film-Festival)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T15:33:49+00:00

TEHRAN-Five Iranian films won awards at the 3rd annual Golden FEMI Film Festival held in Sofia, Bulgaria, on June 1.

## “The Teacher”: dramatic tale of life in occupied Palestine
 - [https://www.tehrantimes.com/news/499418/The-Teacher-dramatic-tale-of-life-in-occupied-Palestine](https://www.tehrantimes.com/news/499418/The-Teacher-dramatic-tale-of-life-in-occupied-Palestine)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T15:32:54+00:00

TEHRAN- “The Teacher” is feature debut of Palestinian-British writer-director Farah Nabulsi, which was shot in 2022. The film highlights not just the countless ways the Israeli occupying forces and settlers dehumanize and abuse Palestinians in the West Bank, but the traumatic toll it continues to take.

## Meybod’s Narin Qaleh undergoes emergency restoration
 - [https://www.tehrantimes.com/news/499417/Meybod-s-Narin-Qaleh-undergoes-emergency-restoration](https://www.tehrantimes.com/news/499417/Meybod-s-Narin-Qaleh-undergoes-emergency-restoration)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T15:21:12+00:00

TEHRAN - Emergency restoration has been underway to preserve the historical Narin Qaleh, in Meybod, Yazd, central Iran, addressing recent structural and weather-related damage.

## Harireh ancient city on the brink of ICESCO recognition
 - [https://www.tehrantimes.com/news/499416/Harireh-ancient-city-on-the-brink-of-ICESCO-recognition](https://www.tehrantimes.com/news/499416/Harireh-ancient-city-on-the-brink-of-ICESCO-recognition)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T15:20:38+00:00

TEHRAN – Harireh ancient city, situated on Kish Island, is set to secure its place on the Islamic World Educational, Scientific and Cultural Organization’s list, before this year is out.

## Iran fall to Japan at 2024 VNL
 - [https://www.tehrantimes.com/news/499415/Iran-fall-to-Japan-at-2024-VNL](https://www.tehrantimes.com/news/499415/Iran-fall-to-Japan-at-2024-VNL)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T12:40:40+00:00

TEHRAN – Iran lost to Japan in straight sets (25-23, 25-22, 25-17) in their opening match in Week 2 of 2024 Volleyball Nations League (VNL) on Tuesday.

## Iran, UNICEF conduct training session on child rights
 - [https://www.tehrantimes.com/news/499414/Iran-UNICEF-conduct-training-session-on-child-rights](https://www.tehrantimes.com/news/499414/Iran-UNICEF-conduct-training-session-on-child-rights)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:39:32+00:00

TEHRAN – The Vice Presidency (VP) for Science, Technology and Knowledge-based Economy and the United Nations Children’s Fund (UNICEF) have organized a training session for VP directors on child rights.

## Mangrove, the wonder of marine habitats
 - [https://www.tehrantimes.com/news/499412/Mangrove-the-wonder-of-marine-habitats](https://www.tehrantimes.com/news/499412/Mangrove-the-wonder-of-marine-habitats)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:36:07+00:00

TEHRAN – The mangrove tree, as a wonder of the marine environment, offers many benefits to various species including birds, fish, crustaceans, and even some terrestrial animals, and stabilizes the soil, as well.

## Muscat to host Iran’s sci-tech days conference
 - [https://www.tehrantimes.com/news/499410/Muscat-to-host-Iran-s-sci-tech-days-conference](https://www.tehrantimes.com/news/499410/Muscat-to-host-Iran-s-sci-tech-days-conference)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:33:56+00:00

TEHRAN – Iran’s scientific and technology days conference is scheduled to be held in Muscat, Oman, from September 16 to 17.

## Asia-Pacific must do better to address poor food safety standards
 - [https://www.tehrantimes.com/news/499407/Asia-Pacific-must-do-better-to-address-poor-food-safety-standards](https://www.tehrantimes.com/news/499407/Asia-Pacific-must-do-better-to-address-poor-food-safety-standards)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:22:13+00:00

Each year, hundreds of millions of people are sickened by eating unsafe food. Here, in the Asia-Pacific region, the situation can also be deadly. According to the latest figures, gathered just prior to the global pandemic, some 225,000 people die each year from foodborne illnesses in Asia and the Pacific. That’s more than half of the global fatalities. Sadly, nearly a third of those who perish, 30 percent, are children.

## ‘Iran pivotal for transit of goods between China, Europe’
 - [https://www.tehrantimes.com/news/499400/Iran-pivotal-for-transit-of-goods-between-China-Europe](https://www.tehrantimes.com/news/499400/Iran-pivotal-for-transit-of-goods-between-China-Europe)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:11:31+00:00

TEHRAN - Iran’s Deputy Minister of Transport and Urban Development has explained the advantages of Iran for the transit of goods between China and Europe at the international summit “Road to Tian Shan” held in Tajikistan.

## Water inflow to dam reserves rises 6%
 - [https://www.tehrantimes.com/news/499404/Water-inflow-to-dam-reserves-rises-6](https://www.tehrantimes.com/news/499404/Water-inflow-to-dam-reserves-rises-6)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:11:24+00:00

TEHRAN - Water inflow to Iran’s dams has increased by six percent since the beginning of the current water year (September 23, 2023) up to June 1, 2024, compared to the same period last year, the new report released by the Water Resources Management Company shows.

## Iran makes jet engine blades, revives dozens of airliners
 - [https://www.tehrantimes.com/news/499401/Iran-makes-jet-engine-blades-revives-dozens-of-airliners](https://www.tehrantimes.com/news/499401/Iran-makes-jet-engine-blades-revives-dozens-of-airliners)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:11:14+00:00

TEHRAN - An Iranian knowledge-based company has acquired the technical know-how to manufacture jet engine turbine blades, allowing for 28 McDonnell Douglas passenger planes to return to service after being grounded because of the sanctions.

## Financing through stock market rises 100% in a year
 - [https://www.tehrantimes.com/news/499405/Financing-through-stock-market-rises-100-in-a-year](https://www.tehrantimes.com/news/499405/Financing-through-stock-market-rises-100-in-a-year)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:11:06+00:00

TEHRAN – Iranian Finance and Economic Affairs Minister Ehsan Khandouzi said financing through the stock market in Iran increased by 100 percent in the previous Iranian calendar year (ended on March 19), ISNA reported.

## Iran, Tajikistan emphasize expanding ties in water, soil fields
 - [https://www.tehrantimes.com/news/499402/Iran-Tajikistan-emphasize-expanding-ties-in-water-soil-fields](https://www.tehrantimes.com/news/499402/Iran-Tajikistan-emphasize-expanding-ties-in-water-soil-fields)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:10:18+00:00

TEHRAN - Officials from Iran and Tajikistan stressed the need to expand bilateral cooperation in the water and soil fields.

## Trade with neighbors rises 15% in 2 months
 - [https://www.tehrantimes.com/news/499399/Trade-with-neighbors-rises-15-in-2-months](https://www.tehrantimes.com/news/499399/Trade-with-neighbors-rises-15-in-2-months)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:10:06+00:00

TEHRAN – Official statistics for Iran’s trade exchanges show that the export of non-oil products to the neighboring countries has risen by 15 percent in the first two months of the current Persian year alone.

## OPEC+ to resume voluntary production cuts from October 2024
 - [https://www.tehrantimes.com/news/499398/OPEC-to-resume-voluntary-production-cuts-from-October-2024](https://www.tehrantimes.com/news/499398/OPEC-to-resume-voluntary-production-cuts-from-October-2024)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T11:09:57+00:00

TEHRAN - OPEC+ countries have decided to gradually resume voluntary production cuts as of October 2024, Iranian Oil Minister Javad Oji said after the OPEC+ ministerial meeting.

## Uzbekistan conference highlights sustainable growth and digital shift in Islamic tourism
 - [https://www.tehrantimes.com/news/499395/Uzbekistan-conference-highlights-sustainable-growth-and-digital](https://www.tehrantimes.com/news/499395/Uzbekistan-conference-highlights-sustainable-growth-and-digital)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-06-04T05:37:07+00:00

UZBEKISTAN, Khiva - The historical city of Khiva welcomed delegates from across the Islamic world for the 12th Islamic Conference of Tourism Ministers (ICTM) from May 31 to June 2. Organized in close collaboration with the Organization of Islamic Cooperation (OIC), the conference focused on the theme "Development of the Tourism Industry in a Sustainable and Resilient Way."

