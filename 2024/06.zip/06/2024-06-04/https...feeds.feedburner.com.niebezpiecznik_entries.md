# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik, language:pl-PL

## Dziura w TikToku!
 - [https://niebezpiecznik.pl/post/dziura-w-tiktoku](https://niebezpiecznik.pl/post/dziura-w-tiktoku)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik
 - date published: 2024-06-04T16:39:35+00:00

<a href="https://niebezpiecznik.pl/post/dziura-w-tiktoku/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2020/07/tiktok-150x150.jpg" width="100" /></a>Wystarczy otworzyć wiadomość na &#8220;privie&#8221; aby stracić konto. Przejęte zostały profile CNN i Paris Hilton. Poszkodowany jest też profil Sony. Szczegóły podatności, którą do przejęcia kont wykorzystali atakujący nie są znane, ale atak dotyczy osób korzystających z aplikacji mobilnej TikToka. Przejęcie kilku kont w wypowiedzi dla Forbes potwierdził Alex Haurek z TikToka, informując że TikTok [&#8230;]

