# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## Trust Is More Important Than You Realize
 - [https://www.youtube.com/watch?v=gukCACpBoxY](https://www.youtube.com/watch?v=gukCACpBoxY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-06-04T21:00:32+00:00



## How Great Comics Arm Their Audience
 - [https://www.youtube.com/watch?v=PqFBslf0lkY](https://www.youtube.com/watch?v=PqFBslf0lkY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-06-04T17:00:29+00:00

This is a clip from yesterday's podcast episode with Roseanne Barr. In it, she and Dr. Peterson discuss the great comics and their profound relationship with the audience.

Dr. Peterson's extensive catalog is available now on DailyWire+: https://bit.ly/3KrWbS8

ALL LINKS: https://linktr.ee/drjordanbpeterson


// COURSES //
Discovering Personality: https://jordanbpeterson.com/personality
Self Authoring Suite: https://selfauthoring.com
Understand Myself (personality test): https://understandmyself.com

// BOOKS //
Beyond Order: 12 More Rules for Life: https://jordanbpeterson.com/Beyond-Order
12 Rules for Life: An Antidote to Chaos: https://jordanbpeterson.com/12-rules-for-life
Maps of Meaning: The Architecture of Belief: https://jordanbpeterson.com/maps-of-meaning

#JordanPeterson #JordanBPeterson #DrJordanPeterson #DrJordanBPeterson #DailyWirePlus

