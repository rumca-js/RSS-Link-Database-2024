# Source:TechHut, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCjSEJkpGbcZhvo0lr-44X_w, language:en

## i can GAME outside now! Sylvox QLED Waterproof TV
 - [https://www.youtube.com/watch?v=wMUZu1l1BhQ](https://www.youtube.com/watch?v=wMUZu1l1BhQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCjSEJkpGbcZhvo0lr-44X_w
 - date published: 2024-06-04T19:03:24+00:00

With a little AMD Mini PC and this outdoor TV I might just have a decent outdoor gaming setup.

Sylvoxtv: https://sylvoxtv.com/collections/partial-sun-outdoor-tv/products/43-qled-outdoor-google-tv-2024
Amazon: https://amzn.to/3Kr02hd
HoloISO: https://github.com/HoloISO/releases

👏SUPPORT TECHHUT
BUY ME A COFFEE: https://buymeacoffee.com/techhut
HOSTINGER: https://bit.ly/techhut-hostinger
YOUTUBE MEMBER: https://bit.ly/members-techhut

🏆FOLOW TECHHUT
TWITTER: https://bit.ly/twitter-techhut
MASTODON: https://bit.ly/mastodon-techhut
INSTAGRAM: https://bit.ly/personal-insta

📷MY GEAR (PAID LINKS)
ASUS ROG M16: https://amzn.to/3t8Xgpo
DeepCool MATREXX 40: https://amzn.to/3q3K8Qn
AMD 3700x: https://amzn.to/31AKX9N
ASRock B550M: https://amzn.to/3qeymTv
G.Skill Trident Z Neo: https://amzn.to/3JRbeSF
Radeon RX 580: https://amzn.to/3n7Ax9g
Cannon M50: https://amzn.to/3xLfhuA

00:00 - Intro
00:55 - Sylvox TV Overview
02:55 - Sylvox TV I/O
04:00 - Unbox and Assemble
04:40 - Google TV
05:02 - IT A

