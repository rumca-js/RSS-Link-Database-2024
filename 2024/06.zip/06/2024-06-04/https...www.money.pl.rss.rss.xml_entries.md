# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Gdzie są sprawozdania finansowe fundacji "Red is Bad"? Nie ma dokumentów z kilku lat
 - [https://www.money.pl/pieniadze/gdzie-sa-sprawozdania-finansowe-fundacji-red-is-bad-nie-ma-dokumentow-z-kilku-lat-7034988509289216a.html](https://www.money.pl/pieniadze/gdzie-sa-sprawozdania-finansowe-fundacji-red-is-bad-nie-ma-dokumentow-z-kilku-lat-7034988509289216a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T19:24:08+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/40a0324a-a31f-4121-bd84-bc477c744ace" width="308" /> Fundacja "Red is Bad" została prawomocnie wykreślona z KRS 14 października 2023 r. Doszło do tego, choć w publicznie dostępnych dokumentach nie ma sprawozdań finansowych fundacji za lata 2020, 2021 i 2022 - podaje Business Insider Polska. Według ekspertów sprawą powinna zainteresować się prokuratura.

## Nowy, miliardowy problem Tuska. "Wypadł z szafy kolejny trup"
 - [https://www.money.pl/emerytury/nowy-miliardowy-problem-tuska-wypadl-z-szafy-kolejny-trup-7034895369317120a.html](https://www.money.pl/emerytury/nowy-miliardowy-problem-tuska-wypadl-z-szafy-kolejny-trup-7034895369317120a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T17:02:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/629c2258-de21-4af9-97cb-8fe4eaaa6535" width="308" /> Trybunał Konstytucyjny wydał wyrok ws. 149 tys. emerytów. Decyzja wiąże się z ok. 14 mld zł dodatkowych wydatków. Dla rządu, już stojącego pod ścianą ws. budżetu, to nie jest dobra wiadomość. Koalicja kluczy, a ekspert przestrzega. - Wypadł z szafy kolejny trup - słyszymy.

## "Runął mit Morawieckiego". Skąd dwukrotny wzrost luki VAT?
 - [https://www.money.pl/podatki/runal-mit-morawieckiego-skad-dwukrotny-wzrost-luki-vat-7034930207836928a.html](https://www.money.pl/podatki/runal-mit-morawieckiego-skad-dwukrotny-wzrost-luki-vat-7034930207836928a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T15:10:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b507f42a-70ab-4af4-8885-ad0911c57e17" width="308" /> Luka VAT rośnie od dwóch lat. Jej skok zanotowano już w 2022 roku. W końcówce rządów premiera Morawieckiego wzrosła o ponad 40 mld zł - tak Sławomir Dudek, szef Instytutu Finansów Publicznych, komentuje dane opublikowane przez resort finansów. Wynika z nich, że w 2023 r. dziura podatkowa podwoiła się.

## Wybory 4 czerwca. Ekonomista pokazał wykres. Robi wrażenie
 - [https://www.money.pl/gospodarka/wybory-4-czerwca-ekonomista-pokazal-wykres-robi-wrazenie-7034854162586304a.html](https://www.money.pl/gospodarka/wybory-4-czerwca-ekonomista-pokazal-wykres-robi-wrazenie-7034854162586304a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T09:41:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3d895748-6c0b-4856-ba11-41f25857a79b" width="308" /> Od początku transformacji w 1989 roku, PKB per capita Polski wzrósł o 209 proc., a polski eksport zwiększył się prawie 30-krotnie, jak wynika z analizy Polskiego Instytutu Ekonomicznego. Instytut podkreśla, że minione 35 lat to dla polskiej gospodarki najlepszy okres w historii.

## Zapadł wyrok ważny dla 150 tys. emerytów
 - [https://www.money.pl/emerytury/zapadl-wyrok-wazny-dla-150-tys-emerytow-7034837183609600a.html](https://www.money.pl/emerytury/zapadl-wyrok-wazny-dla-150-tys-emerytow-7034837183609600a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T08:43:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/aab2a8e1-4202-4c7c-9a49-3b4e752841cb" width="308" /> Trybunał Konstytucyjny orzekł w sprawie skargi emeryta. Chodzi o kwestię pomniejszenia wysokości emerytury, gdy świadczeniobiorca skorzystał z przejścia na wcześniejszą emeryturę. Decyzja TK dotyczy niemal 150 tys. emerytów.

## 150 tys. emerytów czeka na wyrok. TK zdecyduje ws. wysokości świadczenia
 - [https://www.money.pl/emerytury/150-tys-emerytow-czeka-na-wyrok-tk-zdecyduje-ws-wysokosci-swiadczenia-7034790928087808a.html](https://www.money.pl/emerytury/150-tys-emerytow-czeka-na-wyrok-tk-zdecyduje-ws-wysokosci-swiadczenia-7034790928087808a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T05:42:42+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/82aef776-f9f2-4d07-bd24-84a2d45dda5a" width="308" /> We wtorek Trybunał Konstytucyjny wyda wyrok w sprawie skargi emeryta. Chodzi o pomniejszenie świadczenia w przypadku, w którym skorzystano z przejścia na wcześniejszą emeryturę. Decyzja TK dotyczy blisko 150 tys. emerytów.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 04.06.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-04-06-2024-7034786687326976a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-04-06-2024-7034786687326976a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T05:00:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 04.06.2024. We wtorek za jednego dolara (USD) trzeba zapłacić 3.9178 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 04.06.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-04-06-2024-7034786692164288a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-04-06-2024-7034786692164288a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T05:00:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 04.06.2024. We wtorek za jedno euro (EUR) trzeba zapłacić 4.2741 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 04.06.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-04-06-2024-7034786690988800a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-04-06-2024-7034786690988800a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T05:00:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 04.06.2024. We wtorek za jednego franka (CHF) trzeba zapłacić 4.3751 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 04.06.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-04-06-2024-7034786684668672a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-04-06-2024-7034786684668672a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-06-04T05:00:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 04.06.2024. We wtorek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.0193 zł.

