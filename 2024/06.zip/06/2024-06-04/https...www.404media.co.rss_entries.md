# Source:404 Media, URL:https://www.404media.co/rss, language:en

## Laws About Deepfakes Can’t Leave Sex Workers Behind
 - [https://www.404media.co/laws-about-deepfakes-cant-leave-sex-workers-behind](https://www.404media.co/laws-about-deepfakes-cant-leave-sex-workers-behind)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-06-04T13:31:00+00:00

As lawmakers propose federal laws about preventing or regulating nonconsensual AI generated images, they can't forget that there are at least two people in every deepfake.

## Why Do These Instagram Electricians Want to 'Deep Throat' You?
 - [https://www.404media.co/why-do-these-instagram-electricians-want-to-deep-throat-you](https://www.404media.co/why-do-these-instagram-electricians-want-to-deep-throat-you)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-06-04T13:20:46+00:00

A convoluted web of referral schemes results in Instagram ads for roofers who want to have sex with you.

