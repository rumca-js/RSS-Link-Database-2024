# Source:C++ Weekly With Jason Turner, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw, language:en

## Travel Vancouver, BC, Canada: C++ Training Travelog
 - [https://www.youtube.com/watch?v=8BEIU2JCoCI](https://www.youtube.com/watch?v=8BEIU2JCoCI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw
 - date published: 2024-06-04T18:43:41+00:00

☟☟ Awesome T-Shirts! Sponsors! Books! ☟☟

Upcoming Workshop: Understanding Object Lifetime, C++ On Sea, July 2, 2024
► https://cpponsea.uk/2024/sessions/understanding-object-lifetime-for-efficient-and-safer-cpp.html
Upcoming Workshop: C++ Best Practices, NDC TechTown, Sept 9-10, 2024
► https://ndctechtown.com/workshops/c-best-practices/4ceb8f7cf86c

Links:
► https://museumofvancouver.ca/
► https://granvilleisland.com/
► https://vancouver.ca/parks-recreation-culture/totems-and-first-nations-art.aspx
► https://www.translink.ca/schedules-and-maps
► https://www.metropolisatmetrotown.com/
► http://www.thecrystalmall.ca/en/index.htm
► http://www.ayoubs.ca/pages/contact


T-SHIRTS AVAILABLE!

► The best C++ T-Shirts anywhere! https://my-store-d16a2f.creator-spring.com/


WANT MORE JASON?

► My Training Classes: http://emptycrate.com/training.html
► Follow me on twitter: https://twitter.com/lefticus


SUPPORT THE CHANNEL

► Patreon: https://www.patreon.com/lefticus 
► Github Sponsors: https:/

