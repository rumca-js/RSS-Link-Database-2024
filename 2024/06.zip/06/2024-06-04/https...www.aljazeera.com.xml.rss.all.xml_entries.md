# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## At least 15 killed in Israeli attack on central Gaza refugee camps
 - [https://www.aljazeera.com/news/2024/6/4/at-least-15-killed-in-israeli-attack-on-central-gaza-refugee-camps?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/at-least-15-killed-in-israeli-attack-on-central-gaza-refugee-camps?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T21:12:20+00:00

Dozens wounded in attacks on Bureij, Maghazi as only remaining working hospital in area &#039;overflowing&#039; with patients.

## Biden imposes strict restrictions on asylum at southern US border
 - [https://www.aljazeera.com/news/2024/6/4/biden-imposes-strict-restrictions-on-asylum-at-southern-us-border?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/biden-imposes-strict-restrictions-on-asylum-at-southern-us-border?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T20:57:46+00:00

New measures all but deny the right to claim asylum for people who cross the US southern border without authorisation.

## What’s the root cause of Nigeria’s economic crisis?
 - [https://www.aljazeera.com/program/inside-story/2024/6/4/whats-the-root-cause-of-nigerias-economic-crisis?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/6/4/whats-the-root-cause-of-nigerias-economic-crisis?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T20:38:05+00:00

A general strike demanding higher wages brings Nigeria to a standstill.

## India’s Modi wins election, but BJP suffers setback
 - [https://www.aljazeera.com/program/newsfeed/2024/6/4/indias-modi-wins-election-but-bjp-suffers-setback?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/4/indias-modi-wins-election-but-bjp-suffers-setback?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T20:11:16+00:00

Indian Prime Minister Narendra Modi has won a historic third term in office, but the BJP&#039;s majority is reduced.

## T20 World Cup brings cricket ‘home’ for New York’s South Asian community
 - [https://www.aljazeera.com/sports/2024/6/4/cricket-in-new-york-icc-t20-world-cup-2024-long-island-india-vs-pakistan-match?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/4/cricket-in-new-york-icc-t20-world-cup-2024-long-island-india-vs-pakistan-match?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T19:50:18+00:00

New York&#039;s semi-professional cricketers hope the T20 World Cup will inspire the next generation to play the game.

## UK’s Sunak and Starmer to clash in debate as Farage enters election fray
 - [https://www.aljazeera.com/news/2024/6/4/uks-sunak-and-starmer-to-clash-in-debate-as-farage-enters-election-fray?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/uks-sunak-and-starmer-to-clash-in-debate-as-farage-enters-election-fray?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T17:49:05+00:00

Conservative leader Rishi Sunak and Labour leader Sir Keir Starmer will go head-to-head in a televised debate.

## Ohtani’s former interpreter Mizuhara pleads guilty in sport betting case
 - [https://www.aljazeera.com/sports/2024/6/4/ohtanis-former-interpreter-mizuhara-pleads-guilty-in-sports-betting-case?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/4/ohtanis-former-interpreter-mizuhara-pleads-guilty-in-sports-betting-case?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T17:47:01+00:00

Mizuhara pleaded guilty to stealing nearly $17m from the Los Angeles Dodgers player to pay off illegal gambling debts.

## What did experts learn from an ‘unusual’ US presidential primary season?
 - [https://www.aljazeera.com/news/2024/6/4/what-did-experts-learn-from-an-unusual-us-presidential-primary-season?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/what-did-experts-learn-from-an-unusual-us-presidential-primary-season?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T17:37:18+00:00

As the primary season comes to a close, analysts weigh in on what the results can tell us about the Biden-Trump rematch.

## Novak Djokovic pulls out of French Open with knee injury
 - [https://www.aljazeera.com/sports/2024/6/4/novak-djokovic-pulls-out-of-french-open-with-knee-injury?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/4/novak-djokovic-pulls-out-of-french-open-with-knee-injury?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T17:34:18+00:00

The world number one suffered an injury in his right knee in the third round at Roland-Garros.

## Is Israel going to back the Biden-announced Gaza peace plan?
 - [https://www.aljazeera.com/news/2024/6/4/is-israel-going-to-back-the-biden-announced-gaza-peace-plan?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/is-israel-going-to-back-the-biden-announced-gaza-peace-plan?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T17:25:26+00:00

The US president says that the plan came from Israel itself, but comments from Israeli leaders are far from supportive.

## Have Republican busing schemes made immigration a priority for voters?
 - [https://www.aljazeera.com/news/2024/6/4/have-republican-busing-schemes-made-immigration-a-priority-for-voters?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/have-republican-busing-schemes-made-immigration-a-priority-for-voters?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T17:16:09+00:00

Experts say Republican initiatives to bus migrants north have contributed to voter concerns about immigration in the US.

## India shares plunge on concerns of a narrower win for India’s Modi
 - [https://www.aljazeera.com/economy/2024/6/4/india-shares-plunge-on-concerns-of-a-narrower-win-for-indias-modi?traffic_source=rss](https://www.aljazeera.com/economy/2024/6/4/india-shares-plunge-on-concerns-of-a-narrower-win-for-indias-modi?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T16:48:53+00:00

At day&#039;s low, indexes saw biggest intraday fall since March 2020, when stocks were battered by first COVID-19 lockdown.

## Biden suggests Netanyahu prolonging Israel’s Gaza war for political gains
 - [https://www.aljazeera.com/news/2024/6/4/biden-suggests-netanyahu-prolonging-israels-gaza-war-for-political-gains?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/biden-suggests-netanyahu-prolonging-israels-gaza-war-for-political-gains?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T16:33:15+00:00

US president&#039;s remarks come as Washington pursues a truce and captives deal between Israel and Hamas to end conflict.

## Photos: BJP and opposition supporters celebrate India election results
 - [https://www.aljazeera.com/gallery/2024/6/4/photos-bjp-and-opposition-supporters-celebrate-india-election-results?traffic_source=rss](https://www.aljazeera.com/gallery/2024/6/4/photos-bjp-and-opposition-supporters-celebrate-india-election-results?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T16:06:45+00:00

Indian Prime Minister Narendra Modi appears set to retain power at the head of a governing coalition.

## Hezbollah ‘ready’ for an all-out war with Israel, deputy head says
 - [https://www.aljazeera.com/news/2024/6/4/hezbollah-ready-for-an-all-out-war-with-israel-deputy-head-says?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/hezbollah-ready-for-an-all-out-war-with-israel-deputy-head-says?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T15:53:05+00:00

Sheikh Naim Qassem tells Al Jazeera that Hezbollah is not seeking to widen its conflict with Israel.

## ‘Political and moral defeat’ for Modi says India’s Congress party
 - [https://www.aljazeera.com/program/newsfeed/2024/6/4/political-and-moral-defeat-for-modi-says-indias-congress-party?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/4/political-and-moral-defeat-for-modi-says-indias-congress-party?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T15:41:56+00:00

&quot;Now it is clear that this mandate has gone against Modi&quot;, says the president of India&#039;s Congress Party.

## Spanish government decries ‘mudslinging campaign’ as PM’s wife summoned
 - [https://www.aljazeera.com/news/2024/6/4/spanish-government-decries-mudslinging-campaign-as-pms-wife-summoned?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/spanish-government-decries-mudslinging-campaign-as-pms-wife-summoned?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T15:16:50+00:00

Government spokesman slams right and far-right parties for going after Begona Gomez.

## There is a measure of desperation in Biden’s ceasefire plan
 - [https://www.aljazeera.com/opinions/2024/6/4/there-is-a-measure-of-desperation-in-bidens-ceasefire-plan?traffic_source=rss](https://www.aljazeera.com/opinions/2024/6/4/there-is-a-measure-of-desperation-in-bidens-ceasefire-plan?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T14:48:10+00:00

The US president and Israeli prime minister are anxious to get out of a war destroying their political prospects.

## Modi’s BJP to lose majority in India election shock, needs allies for gov’t
 - [https://www.aljazeera.com/news/2024/6/4/modis-bjp-loses-majority-in-india-election-shock-needs-allies-for?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/modis-bjp-loses-majority-in-india-election-shock-needs-allies-for?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T14:11:43+00:00

Defying exit polls, opposition parties stun the BJP in vital states, resetting India&#039;s political landscape.

## Preview: Belgium will be tricky opponents at Euro 2024, De Bruyne says
 - [https://www.aljazeera.com/sports/2024/6/4/preview-belgium-will-be-tricky-opponents-at-euro-2024-says-de-bruyne?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/4/preview-belgium-will-be-tricky-opponents-at-euro-2024-says-de-bruyne?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T13:35:31+00:00

Belgium were quarterfinalists at past two editions, and captain Kevin De Bruyne says his team are ready for Euro 2024.

## War on Gaza, the view from Israel
 - [https://www.aljazeera.com/news/2024/6/4/war-on-gaza-the-view-from-israel?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/war-on-gaza-the-view-from-israel?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T13:10:50+00:00

Public support for Israel&#039;s war aims may be faltering, but not necessarily for the reasons many might expect.

## Singer Kehlani’s stand for Palestine in new music video
 - [https://www.aljazeera.com/program/newsfeed/2024/6/4/singer-kehlanis-stand-for-palestine-in-new-music-video?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/4/singer-kehlanis-stand-for-palestine-in-new-music-video?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T13:03:44+00:00

American singer Kehlani expressed support for Palestine in their new music video.

## How do activists sustain momentum while advocating online?
 - [https://www.aljazeera.com/program/the-stream/2024/6/4/how-do-activists-sustain-momentum-while-advocating-online?traffic_source=rss](https://www.aljazeera.com/program/the-stream/2024/6/4/how-do-activists-sustain-momentum-while-advocating-online?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T13:00:52+00:00

We’ll explore how organisers find new ways to ‘beat the algorithm’ and keep their audiences - and themselves - engaged.

## Video: Woman detained by French police over Palestinian scarf
 - [https://www.aljazeera.com/program/newsfeed/2024/6/4/video-woman-detained-by-french-police-over-palestinian-scarf?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/4/video-woman-detained-by-french-police-over-palestinian-scarf?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T12:49:09+00:00

Watch the moment police detained and fined a woman wearing a traditional Palestinian scarf known as a keffiyeh.

## Russia denies Eiffel Tower coffin stunt an anti-Ukraine undertaking
 - [https://www.aljazeera.com/news/2024/6/4/russia-denies-eiffel-tower-coffin-stunt-an-anti-ukraine-undertaking?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/russia-denies-eiffel-tower-coffin-stunt-an-anti-ukraine-undertaking?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T12:38:05+00:00

The mysterious prank comes as Moscow warns the West against expanding support for Ukrainian forces.

## India election results: Big wins, losses and surprises
 - [https://www.aljazeera.com/news/2024/6/4/india-election-results-big-wins-losses-and-surprises?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/india-election-results-big-wins-losses-and-surprises?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T11:49:26+00:00

A tight Varanasi race and BJP&#039;s Maharashtra downfall - here&#039;s how India&#039;s 2024 Lok Sabha polls defied expectations.

## Why did North Korea launch rubbish-laden balloons into South Korea?
 - [https://www.aljazeera.com/news/2024/6/4/why-did-north-korea-launch-rubbish-laden-balloons-into-south-korea?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/why-did-north-korea-launch-rubbish-laden-balloons-into-south-korea?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T11:30:47+00:00

S Korea suspends inter-Korean military agreement as tensions rise over N Korea&#039;s launch of garbage-carrying balloons.

## UN rights chief condemns ‘unprecedented bloodshed’ in occupied West Bank
 - [https://www.aljazeera.com/news/2024/6/4/un-rights-chief-condemns-unprecedented-bloodshed-in-occupied-west-bank?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/un-rights-chief-condemns-unprecedented-bloodshed-in-occupied-west-bank?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T11:03:43+00:00

Israeli forces kill and arrest dozens in the occupied territory as Volker Turk condemns impunity.

## Euro 2024: past winners of the UEFA European Football Championship
 - [https://www.aljazeera.com/sports/2024/6/4/euro-2024-winners-history-facts-how-long-has-the-euros-been-around?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/4/euro-2024-winners-history-facts-how-long-has-the-euros-been-around?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T10:39:42+00:00

As the Euro 2024 tournament kicks off in Germany, Al Jazeera takes a look at the competition&#039;s eventful 64-year history.

## Tripling clean electricity by 2030 achievable: International Energy Agency
 - [https://www.aljazeera.com/news/2024/6/4/tripling-clean-electricity-by-2030-achievable-says-leading-energy-report?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/tripling-clean-electricity-by-2030-achievable-says-leading-energy-report?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T09:38:45+00:00

The IEA says countries’ domestic ambitions achieve 70 percent of the goal, but experts warn goals are hard to achieve.

## Preview: England at the ICC T20 World Cup 2024
 - [https://www.aljazeera.com/sports/2024/6/4/icc-mens-t20-world-cup-2024-england-team-preview?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/4/icc-mens-t20-world-cup-2024-england-team-preview?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T09:27:34+00:00

Holders England must guard against complacency as they seek to win a record third T20 World Cup title.

## Fires burn in northern Israel after Hezbollah rocket attacks
 - [https://www.aljazeera.com/program/newsfeed/2024/6/4/fires-burn-in-northern-israel-after-hezbollah-rocket-attacks?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/4/fires-burn-in-northern-israel-after-hezbollah-rocket-attacks?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T08:41:57+00:00

Forests in northern Israel have been engulfed by wildfires started by Hezbollah rockets from south Lebanon.

## Four dead as floods sweep southern Germany
 - [https://www.aljazeera.com/gallery/2024/6/4/four-dead-as-floods-sweep-southern-germany?traffic_source=rss](https://www.aljazeera.com/gallery/2024/6/4/four-dead-as-floods-sweep-southern-germany?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T08:39:22+00:00

Thousands of people in Bavaria and Baden-Wuerttemberg were evacuated as torrential rain causes deadly flooding.

## Palestinian teen’s devastating journey through the Gaza war
 - [https://www.aljazeera.com/program/newsfeed/2024/6/4/palestinian-teens-devastating-journey-through-the-gaza-war?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/4/palestinian-teens-devastating-journey-through-the-gaza-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T08:37:31+00:00

19-year-old displaced Palestinian Helmi Hirez has lost his mother and 14 other relatives, as well as his home.

## Preview: Netherlands vs Nepal – ICC T20 World Cup 2024 Group D match
 - [https://www.aljazeera.com/sports/2024/6/4/preview-netherlands-vs-nepal-icc-t20-world-cup-2024-group-d-match?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/4/preview-netherlands-vs-nepal-icc-t20-world-cup-2024-group-d-match?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T08:22:15+00:00

Nepal return to the T20 World Cup after 10 years and will look to make the most of their clash against familiar foes.

## Pressure for truce deal rises as Israel reports four Gaza captives killed
 - [https://www.aljazeera.com/news/2024/6/4/pressure-for-truce-deal-rises-as-israel-reports-four-gaza-captives-killed?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/pressure-for-truce-deal-rises-as-israel-reports-four-gaza-captives-killed?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T08:21:26+00:00

The US says the onus is on Hamas to accept the deal, and is pursuing a UNSC resolution to back it.

## Israelis react to deaths of Gaza captives during ‘military operation’
 - [https://www.aljazeera.com/program/newsfeed/2024/6/4/israelis-react-to-deaths-of-gaza-captives-during-military?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/4/israelis-react-to-deaths-of-gaza-captives-during-military?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T08:14:04+00:00

Israeli protesters have been reacting to news that four more captives held in Gaza have been confirmed dead.

## Vote counting under way in India’s biggest-ever election
 - [https://www.aljazeera.com/program/newsfeed/2024/6/4/vote-counting-underway-in-indias-biggest-ever-election?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/4/vote-counting-underway-in-indias-biggest-ever-election?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T08:03:53+00:00

India is counting its over 640 million votes to decide who will win the nation’s biggest-ever election.

## Strong evidence that Ethiopia committed genocide in Tigray war: Report
 - [https://www.aljazeera.com/news/2024/6/4/strong-evidence-that-ethiopia-committed-genocide-in-tigray-war-report?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/strong-evidence-that-ethiopia-committed-genocide-in-tigray-war-report?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T07:50:45+00:00

Report says Ethiopia and allies had &#039;intent to destroy Tigrayans as an ethnic group&#039; and calls for prosecution at ICJ.

## Afghanistan beat Uganda by 125 runs to open T20 World Cup campaign in style
 - [https://www.aljazeera.com/sports/2024/6/4/afghanistan-beat-uganda-by-125-runs-to-open-t20-world-cup-campaign-in-style?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/4/afghanistan-beat-uganda-by-125-runs-to-open-t20-world-cup-campaign-in-style?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T06:10:21+00:00

Afghanistan set debutants Uganda a target of 184 and then dismissed them for 58 for an emphatic win in Guyana.

## India’s stock market dips as expectations of Modi landslide recede
 - [https://www.aljazeera.com/economy/2024/6/4/indias-stock-market-dips-as-modi-seen-headed-for-slimmer-majority?traffic_source=rss](https://www.aljazeera.com/economy/2024/6/4/indias-stock-market-dips-as-modi-seen-headed-for-slimmer-majority?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T05:49:59+00:00

Selloff comes after polls predicting large majority for National Democratic Alliance sent stocks to all-time highs.

## China denies fuelling Russia-Ukraine war tensions, says it supports peace
 - [https://www.aljazeera.com/news/2024/6/4/china-denies-fuelling-russia-ukraine-war-tensions-says-it-supports-peace?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/china-denies-fuelling-russia-ukraine-war-tensions-says-it-supports-peace?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T05:32:34+00:00

Comments come after Ukraine accused Beijing of attempting to undermine planned global peace summit in Switzerland.

## Epoch Times executive arrested over alleged $67m money laundering scheme
 - [https://www.aljazeera.com/economy/2024/6/4/epoch-times-executive-arrested-over-alleged-67m-money-laundering-scheme?traffic_source=rss](https://www.aljazeera.com/economy/2024/6/4/epoch-times-executive-arrested-over-alleged-67m-money-laundering-scheme?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T04:37:00+00:00

Weidong Guan accused of involvement in &#039;sprawling&#039; scheme to launder money to benefit himself and the right-wing outlet.

## Taiwan’s Lai says Tiananmen ‘will not disappear in torrent of history’
 - [https://www.aljazeera.com/news/2024/6/4/taiwans-lai-says-tiananmen-will-not-disappear-in-torrent-of-history?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/taiwans-lai-says-tiananmen-will-not-disappear-in-torrent-of-history?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T04:29:47+00:00

Tuesday marks 35 years since Chinese soldiers stormed the square and opening fire on peaceful protesters.

## China’s Chang’e-6 lifts off from far side of Moon with rock samples
 - [https://www.aljazeera.com/news/2024/6/4/chinas-change-6-lifts-off-from-far-side-of-moon-with-rock-samples?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/chinas-change-6-lifts-off-from-far-side-of-moon-with-rock-samples?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T04:01:50+00:00

Probe&#039;s successful departure brings China closer to becoming the first country to return samples from far side of Moon.

## India election live results 2024: By the numbers
 - [https://www.aljazeera.com/news/2024/6/4/india-election-live-results-by-the-numbers?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/india-election-live-results-by-the-numbers?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T03:08:44+00:00

Al Jazeera breaks down the results of the Lok Sabha after a seven-week voting process.

## Elon Musk’s X updates policies to formally allow adult content
 - [https://www.aljazeera.com/economy/2024/6/4/elon-musks-x-updates-policies-to-formally-allow-adult-content?traffic_source=rss](https://www.aljazeera.com/economy/2024/6/4/elon-musks-x-updates-policies-to-formally-allow-adult-content?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T02:41:11+00:00

Social media platform says sexualised content can be &#039;legitimate form of artistic expression.&#039;

## Trump campaign says its raised $141m in May, boosted by guilty verdict
 - [https://www.aljazeera.com/economy/2024/6/4/donald-trump-raises-141m-in-may-boosted-by-hush-money-conviction?traffic_source=rss](https://www.aljazeera.com/economy/2024/6/4/donald-trump-raises-141m-in-may-boosted-by-hush-money-conviction?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T01:33:00+00:00

Trump camp says $53m contributed in 24 hours after he was found guilty of 34 counts of falsifying business records.

## Russia-Ukraine war: List of key events, day 830
 - [https://www.aljazeera.com/news/2024/6/4/russia-ukraine-war-list-of-key-events-day-830?traffic_source=rss](https://www.aljazeera.com/news/2024/6/4/russia-ukraine-war-list-of-key-events-day-830?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-04T00:53:55+00:00

As the war enters its 830th day. these are the main developments.

