# Source:Call Me Chato, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg, language:en-US

## We've shipped our great stories to China and Mexico.
 - [https://www.youtube.com/watch?v=_J0byKcqdb0](https://www.youtube.com/watch?v=_J0byKcqdb0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg
 - date published: 2024-06-04T20:06:51+00:00

#FormerNetworkExec #CallMeChato 
Thanks for watching my channel. Please subscribe, SHARE and touch yourselves.

Call Me Chato T-shirt
https://my-store-6121db.creator-spring.com/listing/ppc-cartoon-t-colour

https://twitter.com/PaulChato
http://www.paulchato.com

