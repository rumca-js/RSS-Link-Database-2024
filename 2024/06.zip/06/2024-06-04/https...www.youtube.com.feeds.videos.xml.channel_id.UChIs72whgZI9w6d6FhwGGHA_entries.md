# Source:Gamers Nexus, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChIs72whgZI9w6d6FhwGGHA, language:en

## Noctua Finally Did It | NH-D15 G2 Launching, Thermosiphon, & Fans
 - [https://www.youtube.com/watch?v=nDDxYlkp-_A](https://www.youtube.com/watch?v=nDDxYlkp-_A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChIs72whgZI9w6d6FhwGGHA
 - date published: 2024-06-04T14:34:49+00:00

Sponsor: Thermal Grizzly Aeronaut on Amazon https://geni.us/e8Oq & Hydronaut (Amazon) https://geni.us/hOQrBAb
Noctua is finally launching its Noctua NH-D15 G2 that we've been talking about for years now. The cooler is shipping right now and launching sometime in June or July this year, with new fans coming up in September or October. The Noctua NH-D15 G2's price will be $150 and there will be 3 variations to choose from for that price, named LBC, HBC, and then the general convexity coldplate solution. Noctua has been working on tuning the NF-A14x25 G2 and the cooler coldplate alike, trying to dial against Intel's curvature problems we talked about previously. The company is also working on a thermosiphon which we're told will very likely become a product, but with no current release target or roadmap, and on a Seasonic collaboration PSU.

Watch our coldplate design problems video: https://www.youtube.com/watch?v=7BMYsMGpyFY
Watch our interview with Jakob about fans last year: https://

## Intel Fights Back | Arc Battlemage, Xe2 GPUs, & Changing Hyper-Threading
 - [https://www.youtube.com/watch?v=MGD41i5QCyk](https://www.youtube.com/watch?v=MGD41i5QCyk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChIs72whgZI9w6d6FhwGGHA
 - date published: 2024-06-04T03:01:19+00:00

Sponsor: Fractal Torrent case on Amazon https://geni.us/VVBjoIntel's Xe2 GPU architecture has arrived in Lunar Lake, prompting a mini-information dump of the future Battlemage desktop GPU architecture. Lunar Lake mobile and desktop Battlemage will share several core components of design for the GPU side, despite being different product implementations. We're going over the (brief) architectural information that Intel has provided thus far for its Arc GPU successor (from the original Alchemist A750 & A770 lineup). We'll also cover the P-core and E-core architectural basics, such as ditching hyperthreading in some situations.There's a lot more to cover with Intel, but as we are on the other side of the world in Taiwan for Computex 2024, we'll save the rest of the coverage for when we have more capacity for technical detailing. This gets us started on Intel's announcements for 2024 though, lining-up with rumors of Arrow Lake desktop CPUs in the Fall (maybe).

The best way to support our 

