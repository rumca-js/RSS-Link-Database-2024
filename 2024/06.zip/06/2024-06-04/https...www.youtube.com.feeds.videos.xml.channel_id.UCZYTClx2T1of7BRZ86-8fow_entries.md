# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The Rock That's Helping Us Find the Origin of Life
 - [https://www.youtube.com/watch?v=oxEBm1voIOM](https://www.youtube.com/watch?v=oxEBm1voIOM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2024-06-04T17:00:28+00:00

Epidote might just look like a pretty little crystal, but it has a secret. thanks to the high-pressure circumstances where it forms, we can use it to help us uncover the origins of life on our planet, and maybe even find signs of life on Mars.

Hosted by: Hank Green (he/him)
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Adam Brainard, Alex Hackman, Ash, Benjamin Carleski, Bryan Cloer, charles george, Chris Mackey, Chris Peters, Christoph Schwanke, Christopher R Boucher, DrakoEsper, Eric Jensen, Friso, Garrett Galloway, Harrison Mills, J. Copen, Jaap Westera, Jason A Saslow, Jeffrey Mckishen, Jeremy Mattern, Kenny Wilson, Kevin Bealer, Kevin Knupp, Lyndsay Brown, Matt Curls, Michelle Dove, Piya Shedden, Rizwan Kassim, Sam Lutfi
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow

