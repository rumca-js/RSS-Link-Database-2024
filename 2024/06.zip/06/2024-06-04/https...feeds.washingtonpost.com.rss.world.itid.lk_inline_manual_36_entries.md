# Source:The Washington Post - World, URL:https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36, language:en-US

## Keir Starmer and Rishi Sunak clash in first U.K. election debate
 - [https://www.washingtonpost.com/world/2024/06/04/keir-starmer-rishi-sunak-debate-uk-election](https://www.washingtonpost.com/world/2024/06/04/keir-starmer-rishi-sunak-debate-uk-election)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-06-04T21:34:54+00:00

Sunak accused his challenger of not having big ideas. Starmer accused the prime minister of wanting to distance himself from the Conservative Party’s record.

## Who is Modi and what happened in the Indian election?
 - [https://www.washingtonpost.com/world/2024/06/04/narendra-modi-india-election-results-](https://www.washingtonpost.com/world/2024/06/04/narendra-modi-india-election-results-)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-06-04T17:49:32+00:00

Election results in India have not given Prime Minister Narendra Modi a predicted landslide majority. Here’s what to know about Modi and the election results so far.

## Biden to announce new asylum cap in bid to deter illegal crossings
 - [https://www.washingtonpost.com/immigration/2024/06/04/biden-announce-new-asylum-cap-bid-deter-illegal-crossings](https://www.washingtonpost.com/immigration/2024/06/04/biden-announce-new-asylum-cap-bid-deter-illegal-crossings)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-06-04T16:14:22+00:00

President Biden is expected to sign an executive order to shut off access to the U.S. asylum system when illegal border crossings exceed a daily threshold

## Israel faces renewed pressure to negotiate amid news of more hostage deaths
 - [https://www.washingtonpost.com/world/2024/06/04/israel-hamas-war-news-gaza-palestine](https://www.washingtonpost.com/world/2024/06/04/israel-hamas-war-news-gaza-palestine)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-06-04T11:24:20+00:00

More than a third of the hostages still being held in Gaza — 43 of 124 — are confirmed dead, as Netanyahu’s hard-line allies push for continuing military operations.

## Why Mexico City’s thirst is causing it to sink
 - [https://www.washingtonpost.com/climate-environment/2024/06/04/mexico-city-sinking-water-crisis](https://www.washingtonpost.com/climate-environment/2024/06/04/mexico-city-sinking-water-crisis)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-06-04T10:30:38+00:00

The demand for water in Mexico’s capital is draining its underground aquifers -- and fueling some of the fastest subsidence rates in the world.

## India’s early election results point to rebuke for Modi and his party
 - [https://www.washingtonpost.com/world/2024/06/04/india-election-results-modi-bjp](https://www.washingtonpost.com/world/2024/06/04/india-election-results-modi-bjp)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-06-04T10:26:23+00:00

The results appear to mark a rare setback for a politician who has never failed to secure a majority in state or national elections over a 23-year political career.

## Netanyahu strains to keep government together amid spreading rebellions
 - [https://www.washingtonpost.com/world/2024/06/04/israel-government-war-cabinet-netanyahu](https://www.washingtonpost.com/world/2024/06/04/israel-government-war-cabinet-netanyahu)
 - RSS feed: https://feeds.washingtonpost.com/rss/world?itid=lk_inline_manual_36
 - date published: 2024-06-04T05:00:34+00:00

A string of standoffs, schisms and ultimatums have brought Prime Minister Benjamin Netanyahu’s emergency war cabinet to the brink of collapse.

