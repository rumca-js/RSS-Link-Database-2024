# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Computex 2024: Cooler Master prezentuje nową generację chłodzeń, zasilania, obudów, ale nie tylko…
 - [https://ithardware.pl/aktualnosci/computex_2024_cooler_master_prezentuje_nowa_generacje_chlodzen_zasilania_obudow_ale_nie_tylko-33374.html](https://ithardware.pl/aktualnosci/computex_2024_cooler_master_prezentuje_nowa_generacje_chlodzen_zasilania_obudow_ale_nie_tylko-33374.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T22:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/33374_1.jpg" />            Cooler Master&nbsp;zaprezentował dziś szeroką gamę nowości na targach Computex 2024. Oferta obejmuje r&oacute;wnież aktualizacje produkt&oacute;w w wielu kategoriach, w tym: monitor&oacute;w, foteli gamingowych, stołk&oacute;w muzycznych,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/computex_2024_cooler_master_prezentuje_nowa_generacje_chlodzen_zasilania_obudow_ale_nie_tylko-33374.html">https://ithardware.pl/aktualnosci/computex_2024_cooler_master_prezentuje_nowa_generacje_chlodzen_zasilania_obudow_ale_nie_tylko-33374.html</a></p>

## Windows 11. Microsoft utrudnia tworzenie konta lokalnego
 - [https://ithardware.pl/aktualnosci/windows_11_microsoft_utrudnia_tworzenie_konta_lokalnego-33371.html](https://ithardware.pl/aktualnosci/windows_11_microsoft_utrudnia_tworzenie_konta_lokalnego-33371.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T21:05:30+00:00

<img src="https://ithardware.pl/artykuly/min/33371_1.jpg" />            Microsoft promuje łączenie Windowsa 11 z kontem Microsoft. Nie brak jednak os&oacute;b, kt&oacute;re wolą korzystać z profilu offline stworzonego na konkretnym komputerze. Firmie z Redmond się to nie podobna i utrudniła stworzenie lokalnego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/windows_11_microsoft_utrudnia_tworzenie_konta_lokalnego-33371.html">https://ithardware.pl/aktualnosci/windows_11_microsoft_utrudnia_tworzenie_konta_lokalnego-33371.html</a></p>

## Nowy sterownik GeForce Game Ready 555.99 dodaje wsparcie dla kolejnych gier
 - [https://ithardware.pl/aktualnosci/nowy_sterownik_geforce_game_ready_555_99_dodaje_wsparcie_dla_kolejnych_gier-33375.html](https://ithardware.pl/aktualnosci/nowy_sterownik_geforce_game_ready_555_99_dodaje_wsparcie_dla_kolejnych_gier-33375.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T20:48:40+00:00

<img src="https://ithardware.pl/artykuly/min/33375_1.jpg" />            Karty GeForce otrzymały nową wersję sterownika. Dzięki niej gracze nie będą musieli już chociażby martwić się o wsparcie dla Elden Ring: Shadow of the Edftree. Uaktualnienia doczekała się także aplikacja NVIDIA App, kt&oacute;ra posiada...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowy_sterownik_geforce_game_ready_555_99_dodaje_wsparcie_dla_kolejnych_gier-33375.html">https://ithardware.pl/aktualnosci/nowy_sterownik_geforce_game_ready_555_99_dodaje_wsparcie_dla_kolejnych_gier-33375.html</a></p>

## CORSAIR wchodzi do branży Sim Racing
 - [https://ithardware.pl/aktualnosci/corsair_wchodzi_do_branzy_sim_racing-33372.html](https://ithardware.pl/aktualnosci/corsair_wchodzi_do_branzy_sim_racing-33372.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T20:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/33372_1.jpg" />            CORSAIR kojarzony z produkcją sprzętu komputerowego postanowił&nbsp;wkroczyć do branży&nbsp;Sim Racing. Firma zaprezentowała specjalny kokpit do gier wyścigowych.

Osoby, kt&oacute;re odwiedziły stanowisko CORSAIR na targach Computex, mogły...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/corsair_wchodzi_do_branzy_sim_racing-33372.html">https://ithardware.pl/aktualnosci/corsair_wchodzi_do_branzy_sim_racing-33372.html</a></p>

## Kingston prezentuje pamięci DDR5 i DDR5 CAMM2 oraz rozwiązania AI
 - [https://ithardware.pl/aktualnosci/kingston_prezentuje_pamieci_ddr5_i_ddr5_camm2_oraz_rozwiazania_ai-33373.html](https://ithardware.pl/aktualnosci/kingston_prezentuje_pamieci_ddr5_i_ddr5_camm2_oraz_rozwiazania_ai-33373.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T19:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/33373_1.jpg" />            Kingston wykorzystał targi Computex 2024 do przygotowania&nbsp;wydarzenia&nbsp;Kingston: Racing Beyond Limits, w ramach kt&oacute;rego zapowiedziano&nbsp;nowości, w tym limitowaną edycję pamięci RAM DDR5 Kingston FURY Renegade, nowy standard...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kingston_prezentuje_pamieci_ddr5_i_ddr5_camm2_oraz_rozwiazania_ai-33373.html">https://ithardware.pl/aktualnosci/kingston_prezentuje_pamieci_ddr5_i_ddr5_camm2_oraz_rozwiazania_ai-33373.html</a></p>

## W wymaganiach co najmniej iPhone 15 Pro? Z AI skorzystają w pełni tylko użytkownicy nowego sprzętu
 - [https://ithardware.pl/aktualnosci/w_wymaganiach_co_najmniej_iphone_15_pro_z_ai_skorzystaja_w_pelni_tylko_uzytkownicy_nowego_sprzetu-33370.html](https://ithardware.pl/aktualnosci/w_wymaganiach_co_najmniej_iphone_15_pro_z_ai_skorzystaja_w_pelni_tylko_uzytkownicy_nowego_sprzetu-33370.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T18:21:30+00:00

<img src="https://ithardware.pl/artykuly/min/33370_1.jpg" />            System iOS 18 ma przynieść nowe funkcje, za działanie kt&oacute;rych odpowiedzialna będzie sztuczna inteligencja. Apple podobno zdecyduje się na hybrydowe rozwiązanie, gdzie część funkcji AI może działać na urządzeniu, a część dzięki...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/w_wymaganiach_co_najmniej_iphone_15_pro_z_ai_skorzystaja_w_pelni_tylko_uzytkownicy_nowego_sprzetu-33370.html">https://ithardware.pl/aktualnosci/w_wymaganiach_co_najmniej_iphone_15_pro_z_ai_skorzystaja_w_pelni_tylko_uzytkownicy_nowego_sprzetu-33370.html</a></p>

## ZOTAC ZONE pokazany. Znamy specyfikację i możliwą cenę
 - [https://ithardware.pl/aktualnosci/zotac_zone_pokazany_znamy_specyfikacje_i_mozliwa_cene-33369.html](https://ithardware.pl/aktualnosci/zotac_zone_pokazany_znamy_specyfikacje_i_mozliwa_cene-33369.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T17:21:40+00:00

<img src="https://ithardware.pl/artykuly/min/33369_1.jpg" />            ZOTAC r&oacute;wnież postanowił wejść na rynek przenośnych konsol dla graczy. W ich ofercie pojawi się sprzęt nazwany ZONE. Jego sercem będzie 8-rdzeniowy i 16-wątkowy procesor Ryzen ze zintegrowaną grafią Radeon. Opr&oacute;cz specyfikacji...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/zotac_zone_pokazany_znamy_specyfikacje_i_mozliwa_cene-33369.html">https://ithardware.pl/aktualnosci/zotac_zone_pokazany_znamy_specyfikacje_i_mozliwa_cene-33369.html</a></p>

## KIOXIA przedstawia dyski SSD z radiatorem dla graczy
 - [https://ithardware.pl/aktualnosci/kioxia_przedstawia_dyski_ssd_z_radiatorem_dla_graczy-33368.html](https://ithardware.pl/aktualnosci/kioxia_przedstawia_dyski_ssd_z_radiatorem_dla_graczy-33368.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T17:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/33368_1.jpg" />            KIOXIA prezentuje dyski SSD z serii EXCERIA wyposażone w radiator poprawiający rozpraszanie ciepła. Zaprojektowane zostały z myślą nie tylko o&nbsp;komputerach, ale&nbsp;i konsoli PlayStation 5.

Dyski z serii EXCERIA&nbsp;dostępne są w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kioxia_przedstawia_dyski_ssd_z_radiatorem_dla_graczy-33368.html">https://ithardware.pl/aktualnosci/kioxia_przedstawia_dyski_ssd_z_radiatorem_dla_graczy-33368.html</a></p>

## Snapdragon 8 Gen 4 lepszy niż Apple A17 Pro? Nowe przecieki o wydajności i taktowaniu
 - [https://ithardware.pl/aktualnosci/snapdragon_8_gen_4_lepszy_niz_apple_a17_pro_nowe_przecieki_o_wydajnosci_i_taktowaniu-33367.html](https://ithardware.pl/aktualnosci/snapdragon_8_gen_4_lepszy_niz_apple_a17_pro_nowe_przecieki_o_wydajnosci_i_taktowaniu-33367.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T16:57:30+00:00

<img src="https://ithardware.pl/artykuly/min/33367_1.jpg" />            Snapdragon 8 Gen 4 podobno jest w stanie osiągać taktowanie 4,2 GHz na rdzeniach wydajnościowych. Pojawiły się też informacje na temat jego wydajności, kt&oacute;ra może być lepsza niż w przypadku Apple A17 Pro.

Z ostatnich doniesień...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/snapdragon_8_gen_4_lepszy_niz_apple_a17_pro_nowe_przecieki_o_wydajnosci_i_taktowaniu-33367.html">https://ithardware.pl/aktualnosci/snapdragon_8_gen_4_lepszy_niz_apple_a17_pro_nowe_przecieki_o_wydajnosci_i_taktowaniu-33367.html</a></p>

## Od chłodzenia po obudowy - CORSAIR prezentuje nowe produkty na Computex 2024
 - [https://ithardware.pl/aktualnosci/od_chlodzenia_po_obudowy_corsair_prezentuje_nowe_produkty_na_computex_2024-33366.html](https://ithardware.pl/aktualnosci/od_chlodzenia_po_obudowy_corsair_prezentuje_nowe_produkty_na_computex_2024-33366.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T15:25:00+00:00

<img src="https://ithardware.pl/artykuly/min/33366_1.jpg" />            Computex 2024 to doskonała okazja, by producenci sprzętu komputerowego zaprezentowali nowe produkty&nbsp;tak jak CORSAIR. Firma z okazji targ&oacute;w&nbsp;przedstawiła szereg nowych urządzeń: komputer, chłodzenie wodne, monitor czy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/od_chlodzenia_po_obudowy_corsair_prezentuje_nowe_produkty_na_computex_2024-33366.html">https://ithardware.pl/aktualnosci/od_chlodzenia_po_obudowy_corsair_prezentuje_nowe_produkty_na_computex_2024-33366.html</a></p>

## CORSAIR ogłasza nawiązanie współpracy między iCUE i Gigabyte
 - [https://ithardware.pl/aktualnosci/corsair_oglasza_nawiazanie_wspolpracy_miedzy_icue_i_gigabyte-33364.html](https://ithardware.pl/aktualnosci/corsair_oglasza_nawiazanie_wspolpracy_miedzy_icue_i_gigabyte-33364.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T14:42:40+00:00

<img src="https://ithardware.pl/artykuly/min/33364_1.jpg" />            CORSAIR ogłosił&nbsp;nowe partnerstwo z Gigabyte, dzięki kt&oacute;remu ten producent płyt gł&oacute;wnych będzie wspierał oprogramowanie do sterowania podświetleniem CORSAIR iCUE. Wsp&oacute;łpraca ta umożliwia zgodnym produktom CORSAIR...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/corsair_oglasza_nawiazanie_wspolpracy_miedzy_icue_i_gigabyte-33364.html">https://ithardware.pl/aktualnosci/corsair_oglasza_nawiazanie_wspolpracy_miedzy_icue_i_gigabyte-33364.html</a></p>

## Aresztowano twórcę największego botnetu w historii. Infekował przez darmowe usługi VPN
 - [https://ithardware.pl/aktualnosci/aresztowano_tworce_najwiekszego_botnetu_w_historii_infekowal_przez_darmowe_uslugi_vpn-33363.html](https://ithardware.pl/aktualnosci/aresztowano_tworce_najwiekszego_botnetu_w_historii_infekowal_przez_darmowe_uslugi_vpn-33363.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T12:23:30+00:00

<img src="https://ithardware.pl/artykuly/min/33363_1.jpg" />            Stany Zjednoczone aresztowały obywatela Chin za oferowanie bezpłatnych program&oacute;w VPN, kt&oacute;re potajemnie instalowały złośliwe oprogramowanie na milionach komputer&oacute;w z systemem Windows.

Departament Sprawiedliwości twierdzi, że...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/aresztowano_tworce_najwiekszego_botnetu_w_historii_infekowal_przez_darmowe_uslugi_vpn-33363.html">https://ithardware.pl/aktualnosci/aresztowano_tworce_najwiekszego_botnetu_w_historii_infekowal_przez_darmowe_uslugi_vpn-33363.html</a></p>

## Nowe monitory LG OLED już w Polsce. Są modele z funkcją Dual-Hz
 - [https://ithardware.pl/aktualnosci/nowe_monitory_lg_oled_juz_w_polsce_sa_modele_z_funkcja_dual_hz-33361.html](https://ithardware.pl/aktualnosci/nowe_monitory_lg_oled_juz_w_polsce_sa_modele_z_funkcja_dual_hz-33361.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T11:21:30+00:00

<img src="https://ithardware.pl/artykuly/min/33361_1.jpg" />            Nowa funkcja Dual-Hz w monitorach gamingowy zdaje się być przełomowa i takie konstrukcje zostały właśnie wypuszczone przez LG. Oto, czym się charakteryzują!

Rozszerzona linia nowych monitor&oacute;w obejmuje modele 32GS95UE oraz 34GS95QE i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowe_monitory_lg_oled_juz_w_polsce_sa_modele_z_funkcja_dual_hz-33361.html">https://ithardware.pl/aktualnosci/nowe_monitory_lg_oled_juz_w_polsce_sa_modele_z_funkcja_dual_hz-33361.html</a></p>

## Sieć łączności komórkowej Elona Muska, to śmierć dla radioteleskopów. Astronomowie protestują
 - [https://ithardware.pl/aktualnosci/astronomowie_protestuja_przeciw_lacznosci_komorkowej_elona_muska_to_smierc_dla_radioteleskopow-33362.html](https://ithardware.pl/aktualnosci/astronomowie_protestuja_przeciw_lacznosci_komorkowej_elona_muska_to_smierc_dla_radioteleskopow-33362.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T11:15:50+00:00

<img src="https://ithardware.pl/artykuly/min/33362_1.jpg" />            SpaceX i AST SpaceMobile pracują nad zapewnieniem&nbsp;łączności satelitarnej&nbsp;smartfonom, ale naukowcy twierdzą, że technologia może oznaczać nawet śmierć radioastronomii.

&bdquo;Proponowane satelity umożliwiające łączność...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/astronomowie_protestuja_przeciw_lacznosci_komorkowej_elona_muska_to_smierc_dla_radioteleskopow-33362.html">https://ithardware.pl/aktualnosci/astronomowie_protestuja_przeciw_lacznosci_komorkowej_elona_muska_to_smierc_dla_radioteleskopow-33362.html</a></p>

## ARM prognozuje, że jego architektura przejmie 50% rynku PC w ciągu 5 lat
 - [https://ithardware.pl/aktualnosci/arm_prognozuje_ze_ich_architektura_przejmie_50_rynku_pc_w_ciagu_5_lat-33356.html](https://ithardware.pl/aktualnosci/arm_prognozuje_ze_ich_architektura_przejmie_50_rynku_pc_w_ciagu_5_lat-33356.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T10:56:10+00:00

<img src="https://ithardware.pl/artykuly/min/33356_1.jpg" />            Ponieważ architektura ARM coraz śmielej poczyna sobie na rynku PC (dzięki Qualcomm i Microsoftowi), dyrektor generalny ARM Holdings, Rene Haas, podzielił się swoimi predykcjami dotyczącymi przyszłego udziału w rynku ich technologii. Spodziewa...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/arm_prognozuje_ze_ich_architektura_przejmie_50_rynku_pc_w_ciagu_5_lat-33356.html">https://ithardware.pl/aktualnosci/arm_prognozuje_ze_ich_architektura_przejmie_50_rynku_pc_w_ciagu_5_lat-33356.html</a></p>

## Donald Trump dołączył do TikToka. Już nie walczy z chińską platformą?
 - [https://ithardware.pl/aktualnosci/donald_trump_dolaczyl_do_tiktoka_juz_nie_walczy_z_chinska_platforma-33359.html](https://ithardware.pl/aktualnosci/donald_trump_dolaczyl_do_tiktoka_juz_nie_walczy_z_chinska_platforma-33359.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T10:06:30+00:00

<img src="https://ithardware.pl/artykuly/min/33359_1.jpg" />            Kilka dni po zapowiedziach, że Donald Trump planuje pojawić się na platformie X &ndash; na kt&oacute;rej nie był aktywny od 2021 roku &ndash; były prezydent zaskoczył wszystkich, dołączając do TikToka, platformy, kt&oacute;rą wcześniej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/donald_trump_dolaczyl_do_tiktoka_juz_nie_walczy_z_chinska_platforma-33359.html">https://ithardware.pl/aktualnosci/donald_trump_dolaczyl_do_tiktoka_juz_nie_walczy_z_chinska_platforma-33359.html</a></p>

## Elon Musk chce kupić nowe GPU NVIDIA B200 AI o wartości ponad 10 miliardów dolarów
 - [https://ithardware.pl/aktualnosci/elon_musk_chce_kupic_nowe_gpu_nvidia_b200_ai_o_wartosci_ponad_10_miliardow_dolarow-33354.html](https://ithardware.pl/aktualnosci/elon_musk_chce_kupic_nowe_gpu_nvidia_b200_ai_o_wartosci_ponad_10_miliardow_dolarow-33354.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T09:33:00+00:00

<img src="https://ithardware.pl/artykuly/min/33354_1.jpg" />            Rozw&oacute;j w zakresie AI przebiega z zawrotną szybkością, a Elon Musk chce być na czele tej rewolucyjnej przemiany. W poście na X dyrektor generalny SpaceX i Tesli ujawnił, że do lata przyszłego roku chce kupić najnowsze karty graficzne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elon_musk_chce_kupic_nowe_gpu_nvidia_b200_ai_o_wartosci_ponad_10_miliardow_dolarow-33354.html">https://ithardware.pl/aktualnosci/elon_musk_chce_kupic_nowe_gpu_nvidia_b200_ai_o_wartosci_ponad_10_miliardow_dolarow-33354.html</a></p>

## LG chwali się pierwszym monitorem z certyfikatem DisplayHDR 1.2. Ciekawa propozycja dla graczy
 - [https://ithardware.pl/aktualnosci/lg_chwali_sie_pierwszym_monitorem_z_certyfikatem_displayhdr_1_2_ciekawa_propozycja_dla_graczy-33352.html](https://ithardware.pl/aktualnosci/lg_chwali_sie_pierwszym_monitorem_z_certyfikatem_displayhdr_1_2_ciekawa_propozycja_dla_graczy-33352.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T08:48:50+00:00

<img src="https://ithardware.pl/artykuly/min/33352_1.jpg" />            VESA wprowadziła niedawno specyfikację DisplayHDR 1.2, aby lepiej identyfikować i sprzedawać monitory obsługujące HDR. Teraz LG twierdzi, że jest pierwszą firmą, kt&oacute;ra oferuje monitor z certyfikatem DisplayHDR 1.2 dla graczy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/lg_chwali_sie_pierwszym_monitorem_z_certyfikatem_displayhdr_1_2_ciekawa_propozycja_dla_graczy-33352.html">https://ithardware.pl/aktualnosci/lg_chwali_sie_pierwszym_monitorem_z_certyfikatem_displayhdr_1_2_ciekawa_propozycja_dla_graczy-33352.html</a></p>

## Endorfy LIV Plus Wireless to spora zmiana na lepsze, ale czy nadąża za duchem czasów? (Test)
 - [https://ithardware.pl/testyirecenzje/endorfy_liv_plus_wireless_to_spora_zmiana_na_lepsze_ale_czy_nadaza_za_duchem_czasow_test-33348.html](https://ithardware.pl/testyirecenzje/endorfy_liv_plus_wireless_to_spora_zmiana_na_lepsze_ale_czy_nadaza_za_duchem_czasow_test-33348.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T08:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/33348_1.png" />            Endorfy raczej przedstawiać wam nie muszę, gdyż ten polski producent jest jedną z najlepiej sprzedających się marek na naszym rodzimym rynku. Firma po dłuższej przerwie, wr&oacute;ciła do nas ze świeżutką premierą swojej pierwszej w historii...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/endorfy_liv_plus_wireless_to_spora_zmiana_na_lepsze_ale_czy_nadaza_za_duchem_czasow_test-33348.html">https://ithardware.pl/testyirecenzje/endorfy_liv_plus_wireless_to_spora_zmiana_na_lepsze_ale_czy_nadaza_za_duchem_czasow_test-33348.html</a></p>

## GeForce RTX 5080 może okazać się rozczarowujący - nowe przecieki
 - [https://ithardware.pl/aktualnosci/geforce_rtx_5080_moze_okazac_sie_rozczarowujacy_nowe_przecieki-33355.html](https://ithardware.pl/aktualnosci/geforce_rtx_5080_moze_okazac_sie_rozczarowujacy_nowe_przecieki-33355.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T07:45:30+00:00

<img src="https://ithardware.pl/artykuly/min/33355_1.jpg" />            Gamingowe karty graficzne Blackwell od NVIDII są wyczekiwane z niecierpliwością przez graczy i choć targi Computex 2024 nie przyniosły oficjalnej zapowiedzi serii GeForce RTX 5000, to nie powstrzymało to informator&oacute;w przed ujawnianiem...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_5080_moze_okazac_sie_rozczarowujacy_nowe_przecieki-33355.html">https://ithardware.pl/aktualnosci/geforce_rtx_5080_moze_okazac_sie_rozczarowujacy_nowe_przecieki-33355.html</a></p>

## Intel oficjalnie zapowiada nową architekturę GPU. Xe2 zwiastuje duży skok wydajności
 - [https://ithardware.pl/aktualnosci/intel_oficjalnie_zapowiada_nowa_architekture_gpu_xe2_zwiastuje_duzy_skok_wydajnosci-33353.html](https://ithardware.pl/aktualnosci/intel_oficjalnie_zapowiada_nowa_architekture_gpu_xe2_zwiastuje_duzy_skok_wydajnosci-33353.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T07:14:29+00:00

<img src="https://ithardware.pl/artykuly/min/33353_1.jpg" />            Wiele os&oacute;b spekulowało ostatnio na temat przyszłości GPU Intela. Po słabej premierze Arc Alchemist niekt&oacute;rzy sugerowali, że Intel anuluje karty graficzne Battlemage. Jednak tak się nie stało, a producent postanowił właśnie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_oficjalnie_zapowiada_nowa_architekture_gpu_xe2_zwiastuje_duzy_skok_wydajnosci-33353.html">https://ithardware.pl/aktualnosci/intel_oficjalnie_zapowiada_nowa_architekture_gpu_xe2_zwiastuje_duzy_skok_wydajnosci-33353.html</a></p>

## Dell spodziewa się, że dyski SSD i pamięci RAM jeszcze podrożeją. I to mocno
 - [https://ithardware.pl/aktualnosci/dell_spodziewa_sie_ze_dyski_ssd_i_pamieci_ram_jeszcze_podrozeja_i_to_mocno-33351.html](https://ithardware.pl/aktualnosci/dell_spodziewa_sie_ze_dyski_ssd_i_pamieci_ram_jeszcze_podrozeja_i_to_mocno-33351.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T07:06:14+00:00

<img src="https://ithardware.pl/artykuly/min/33351_1.jpg" />            Producenci chip&oacute;w NAND i DRAM są najwyraźniej o krok od przejścia z jednej skrajności w drugą. W zeszłym roku borykali się z nadmiernymi zapasami, co skutkowało rekordowo niskimi cenami. Teraz, za sprawą szybkiego rozwoju sztucznej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dell_spodziewa_sie_ze_dyski_ssd_i_pamieci_ram_jeszcze_podrozeja_i_to_mocno-33351.html">https://ithardware.pl/aktualnosci/dell_spodziewa_sie_ze_dyski_ssd_i_pamieci_ram_jeszcze_podrozeja_i_to_mocno-33351.html</a></p>

## Intel zapowiada proceosry Lunar Lake. Firma idzie w stronę Apple
 - [https://ithardware.pl/aktualnosci/intel_zapowiada_proceosry_lunar_lake_firma_idzie_w_strone_apple-33350.html](https://ithardware.pl/aktualnosci/intel_zapowiada_proceosry_lunar_lake_firma_idzie_w_strone_apple-33350.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-06-04T06:10:10+00:00

<img src="https://ithardware.pl/artykuly/min/33350_1.png" />            Intel ujawnił niedawno, że nadchodzące procesory Lunar Lake będą dostępne tej jesieni dla komputer&oacute;w PC Copilot+ AI, ale dopiero teraz, na targach Computex, otrzymaliśmy więcej szczeg&oacute;ł&oacute;w technicznych na ich...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_zapowiada_proceosry_lunar_lake_firma_idzie_w_strone_apple-33350.html">https://ithardware.pl/aktualnosci/intel_zapowiada_proceosry_lunar_lake_firma_idzie_w_strone_apple-33350.html</a></p>

