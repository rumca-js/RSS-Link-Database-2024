# Source:Pluralistic: Daily links from Cory Doctorow, URL:https://pluralistic.net/feed, language:en-US

## Pluralistic: Joseph Cox's "Dark Wire" (04 June 2024)
 - [https://pluralistic.net/2024/06/04/anom-nom-nom](https://pluralistic.net/2024/06/04/anom-nom-nom)
 - RSS feed: https://pluralistic.net/feed
 - date published: 2024-06-04T13:27:42+00:00

Today's links Joseph Cox's "Dark Wire": A true-crime technothriller about the biggest sting operation in world history. Hey look at this: Delights to delectate. This day in history: 2009, 2014, 2019, 2023 Upcoming appearances: Where to find me. Recent appearances: Where I've been. Latest books: You keep readin' em, I'll keep writin' 'em. Upcoming books: Like I said, I'll keep writin' 'em. Colophon: All the rest. Joseph Cox's "Dark Wire" (permalink) No one was better positioned to tell the tale of the largest sting operation in world history than veteran tech reporter Joseph Cox, and tell it he did, in Dark Wire, released today: https://www.hachettebookgroup.com/titles/joseph-cox/dark-wire/9781541702691/ Cox &#8211; who was one of Motherboard's star cybersecurity reporters before leaving to co-found 404 Media &#8211; has spent years on the crimephone beat, tracking vendors who sold modded phones (first Blackberries, then Android phones) to criminal syndicates with the promise that they

