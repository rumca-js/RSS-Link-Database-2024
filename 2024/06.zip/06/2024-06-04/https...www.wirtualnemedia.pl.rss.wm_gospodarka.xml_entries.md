# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Neonet chce upadłości. Sąd odrzucił wniosek
 - [https://www.wirtualnemedia.pl/artykul/neonet-sklepy-zamkniete-upadlosc-zwolnienia-pracownikow](https://www.wirtualnemedia.pl/artykul/neonet-sklepy-zamkniete-upadlosc-zwolnienia-pracownikow)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-06-04T13:37:06.745147+00:00

Sieć elektromarketów Neonet złożyła wniosek o upadłość, który został odrzucony przez sąd. Pod koniec ub.r. firma rozpoczęła postępowanie sanacyjne.

## Nowy wiceprezes Polskiej Agencji Żeglugi Powietrznej. Przeszedł z Siemens Mobility
 - [https://www.wirtualnemedia.pl/artykul/polska-agencja-zeglugi-powietrznej-zarzad-nowy-wiceprezes-hubert-meronk](https://www.wirtualnemedia.pl/artykul/polska-agencja-zeglugi-powietrznej-zarzad-nowy-wiceprezes-hubert-meronk)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-06-04T09:17:00.074193+00:00

Hubert Meronk został nowym wiceprezesem Polskiej Agencji Żeglugi Powietrznej (PAŻP); będzie odpowiadał za obszar finansowy i administracyjny - poinformowała w poniedziałek Agencja.

## Intercity wprowadza opłatę za rezerwację miejsc nie zawsze obowiązkowa
 - [https://www.wirtualnemedia.pl/artykul/pkp-intercity-rezerwacja-miejsc-oplata-bez-obowiazku](https://www.wirtualnemedia.pl/artykul/pkp-intercity-rezerwacja-miejsc-oplata-bez-obowiazku)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-06-04T07:06:30.438305+00:00

Od 9 czerwca br. zostanie zniesiony obowiązek rezerwacji miejsc w części pociągów - poinformowało w poniedziałek PKP Intercity. Jak dodano, zmiany oznaczają, że zapełnienie w pojazdach będzie mogło przekroczyć 100 proc., natomiast pasażerowie będą mogli odbyć podróż bez wskazania miejsca na bilecie.

## Banki w Polsce z rekordowymi zyskami. Kredyty bez WIBOR
 - [https://www.wirtualnemedia.pl/artykul/zyski-bankow-ile-zarabiaja-wskaznik-wibor-umowa-kredyt-konsumencki](https://www.wirtualnemedia.pl/artykul/zyski-bankow-ile-zarabiaja-wskaznik-wibor-umowa-kredyt-konsumencki)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-06-04T07:06:30.383724+00:00

Na koniec kwietnia 2024 r. zysk sektora bankowego wyniósł ponad 14,4 mld zł – podał we wtorek NBP. Rok wcześniej zysk banków przekroczył 12,9 mld zł. Wskaźnik WIBOR praktycznie znikł z nowych umów kredytów konsumenckich; zastąpiła go stopa referencyjna Narodowego Banku Polskiego.

## LOT będzie latał do Arabii Saudyjskiej
 - [https://www.wirtualnemedia.pl/artykul/lot-lot-warszwa-rijad-arabia-saudyjska](https://www.wirtualnemedia.pl/artykul/lot-lot-warszwa-rijad-arabia-saudyjska)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-06-04T06:01:21.230683+00:00

PLL LOT od wtorku zaczną bezpośrednio latać na trasie Warszawa-Rijad w Arabii Saudyjskiej. Rejsy będą wykonywane samolotami typu Boeing 737 MAX 8 trzy razy w tygodniu, a lot potrwa ponad 6 godz. Rijad to kolejny uruchomiony kierunek przewidziany w strategii LOT na lata 2024-2028.

## Decathlon chce sprzedawać używane rzeczy
 - [https://www.wirtualnemedia.pl/artykul/decathlon-sklep-internetowy-uzywane-rzeczy](https://www.wirtualnemedia.pl/artykul/decathlon-sklep-internetowy-uzywane-rzeczy)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-06-04T06:01:21.175656+00:00

Sieć sklepów ze sprzętem sportowym Decathlon uruchomiła platformę internetową, na której sprzedaje używane rzeczy. Na razie testuje to rozwiązanie w Belgii.

