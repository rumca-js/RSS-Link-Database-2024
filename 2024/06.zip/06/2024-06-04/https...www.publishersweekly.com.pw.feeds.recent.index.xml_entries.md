# Source:Publisher weekly, URL:https://www.publishersweekly.com/pw/feeds/recent/index.xml, language:en-US

## 2024 Gaithersburg Book Festival in Photos
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/95198-2024-gaithersburg-book-festival-in-photos.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/95198-2024-gaithersburg-book-festival-in-photos.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-06-04T04:00:00+00:00



## Authors, Publishers Sign PEN America Letter Protesting New South Carolina School Book Rules
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/95192-authors-publishers-sign-pen-america-letter-protesting-new-south-carolina-school-book-rules.html](http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/95192-authors-publishers-sign-pen-america-letter-protesting-new-south-carolina-school-book-rules.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-06-04T04:00:00+00:00



## Blue Star Press Buys Sasquatch Books from PRH
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/industry-deals/article/95193-blue-star-press-buys-sasquatch-books-from-prh.html](http://www.publishersweekly.com/pw/by-topic/industry-news/industry-deals/article/95193-blue-star-press-buys-sasquatch-books-from-prh.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-06-04T04:00:00+00:00



## Children's Job Moves: May 2024
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/95200-children-s-job-moves-may-2024.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/95200-children-s-job-moves-may-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-06-04T04:00:00+00:00



## Maria Shriver’s Open Field Imprint Broadens Its Horizons
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/95184-maria-shriver-s-open-field-imprint-broadens-its-horizons.html](http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/95184-maria-shriver-s-open-field-imprint-broadens-its-horizons.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-06-04T04:00:00+00:00

Penguin Life imprint the Open Field, founded by journalist Maria Shriver with a focus on wellness and inspiration, will now publish 10 books per year

## Obituary: Katey Howes
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/95201-obituary-katey-howes.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/95201-obituary-katey-howes.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-06-04T04:00:00+00:00



## Publishers Celebrate James Baldwin Centennial with Reissues
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/95185-publishers-celebrate-james-baldwin-centennial-with-reissues.html](http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/95185-publishers-celebrate-james-baldwin-centennial-with-reissues.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-06-04T04:00:00+00:00



## Rights Report: Week of June 3, 2024
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/95199-rights-report-week-of-june-3-2024.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/95199-rights-report-week-of-june-3-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-06-04T04:00:00+00:00



## YA Author and Aviatrix Elizabeth Wein Takes to the Skies
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/95197-ya-author-and-aviatrix-elizabeth-wein-takes-to-the-skies.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/95197-ya-author-and-aviatrix-elizabeth-wein-takes-to-the-skies.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-06-04T04:00:00+00:00



