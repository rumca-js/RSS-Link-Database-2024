# Source:CodeProject Latest Articles, URL:https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1, language:en-us

## char, sbyte, byte and uint with arrays and pointers
 - [https://www.codeproject.com/Tips/5375957/char-sbyte-byte-and-uint-with-arrays-and-pointers](https://www.codeproject.com/Tips/5375957/char-sbyte-byte-and-uint-with-arrays-and-pointers)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-06-04T19:07:00+00:00

There are new convertions for C#

## Polynomials over ℂ Root Finder using Bisection method
 - [https://www.codeproject.com/Tips/5383297/Polynomials-over-Root-Finder-using-Bisection-metho](https://www.codeproject.com/Tips/5383297/Polynomials-over-Root-Finder-using-Bisection-metho)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-06-04T16:02:00+00:00

Finds Roots of a Polynomial with complex coefficients using a "extended" Bisection method

