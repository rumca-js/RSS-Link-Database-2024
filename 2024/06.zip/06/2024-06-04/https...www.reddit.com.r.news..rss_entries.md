# Source:Reddit - News, URL:https://www.reddit.com/r/news/.rss, language:en-US

## AT&T customers facing 'nationwide issue' impacting their ability to call non-AT&T users
 - [https://www.reddit.com/r/news/comments/1d89vuc/att_customers_facing_nationwide_issue_impacting](https://www.reddit.com/r/news/comments/1d89vuc/att_customers_facing_nationwide_issue_impacting)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T22:17:17+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/FindingMoi"> /u/FindingMoi </a> <br /> <span><a href="https://abcnews.go.com/US/att-customers-facing-nationwide-issue-impacting-ability-call/story?id=110829533">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d89vuc/att_customers_facing_nationwide_issue_impacting/">[comments]</a></span>

## Panel rejects psychedelic drug MDMA as a PTSD treatment in possible setback for advocates
 - [https://www.reddit.com/r/news/comments/1d89q8j/panel_rejects_psychedelic_drug_mdma_as_a_ptsd](https://www.reddit.com/r/news/comments/1d89q8j/panel_rejects_psychedelic_drug_mdma_as_a_ptsd)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T22:10:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/antichain"> /u/antichain </a> <br /> <span><a href="https://apnews.com/article/mdma-psychedelics-fda-ptsd-ecstasy-molly-1f3753324fa7f91821c9ee6246fa18e1?taid=665f8bd17fa75e000132ab4c&amp;utm_campaign=TrueAnthem&amp;utm_medium=AP&amp;utm_source=Twitter">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d89q8j/panel_rejects_psychedelic_drug_mdma_as_a_ptsd/">[comments]</a></span>

## Three of the horses that bolted across London expected to troop the colour
 - [https://www.reddit.com/r/news/comments/1d86n45/three_of_the_horses_that_bolted_across_london](https://www.reddit.com/r/news/comments/1d86n45/three_of_the_horses_that_bolted_across_london)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T20:03:49+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/StairheidCritic"> /u/StairheidCritic </a> <br /> <span><a href="https://www.theguardian.com/lifeandstyle/article/2024/jun/04/three-of-the-horses-that-bolted-across-london-expected-to-troop-the-colour">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d86n45/three_of_the_horses_that_bolted_across_london/">[comments]</a></span>

## Juror says someone left her bag with $120,000 cash and promise of more if she’ll acquit
 - [https://www.reddit.com/r/news/comments/1d84f3a/juror_says_someone_left_her_bag_with_120000_cash](https://www.reddit.com/r/news/comments/1d84f3a/juror_says_someone_left_her_bag_with_120000_cash)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T18:32:35+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/NBCspec"> /u/NBCspec </a> <br /> <span><a href="https://www.nbcnews.com/news/us-news/juror-says-someone-left-bag-120000-cash-promise-ll-acquit-rcna155332">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d84f3a/juror_says_someone_left_her_bag_with_120000_cash/">[comments]</a></span>

## Elon Musk ordered Nvidia to ship thousands of AI chips reserved for Tesla to X and xAI
 - [https://www.reddit.com/r/news/comments/1d84bhr/elon_musk_ordered_nvidia_to_ship_thousands_of_ai](https://www.reddit.com/r/news/comments/1d84bhr/elon_musk_ordered_nvidia_to_ship_thousands_of_ai)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T18:28:41+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/scientianaut"> /u/scientianaut </a> <br /> <span><a href="https://www.cnbc.com/2024/06/04/elon-musk-told-nvidia-to-ship-ai-chips-reserved-for-tesla-to-x-xai.html#:~:text=Emails%20circulated%20inside%20Nvidia%20and,heavily%20on%20Nvidia%27s%20AI%20processors">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d84bhr/elon_musk_ordered_nvidia_to_ship_thousands_of_ai/">[comments]</a></span>

## London hospital services impacted by ransomware incident
 - [https://www.reddit.com/r/news/comments/1d846q1/london_hospital_services_impacted_by_ransomware](https://www.reddit.com/r/news/comments/1d846q1/london_hospital_services_impacted_by_ransomware)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T18:23:12+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/porcelaincabbage"> /u/porcelaincabbage </a> <br /> <span><a href="https://www.reuters.com/technology/cybersecurity/london-hospital-cyber-attack-causing-significant-impact-services-2024-06-04/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d846q1/london_hospital_services_impacted_by_ransomware/">[comments]</a></span>

## Woman found still alive at funeral home dies hours later
 - [https://www.reddit.com/r/news/comments/1d825f9/woman_found_still_alive_at_funeral_home_dies](https://www.reddit.com/r/news/comments/1d825f9/woman_found_still_alive_at_funeral_home_dies)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T16:58:50+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/appalachianartist"> /u/appalachianartist </a> <br /> <span><a href="https://www.wvva.com/2024/06/04/woman-found-still-alive-funeral-home-dies-hours-later/?fbclid=IwZXh0bgNhZW0CMTEAAR35K21rwnvzvz0K7LEC3TBVTnkSO5pg0RF95mtkNtQVTHFwXhUKUzRthTo_aem_ATKRrZT4L80gA4yA4cXx1djAhdkkwurJsBYz43yvRhPKrjxsDJLFyoACCJLw7vD_2lGDIcEHXDL5IEwcJEqCwPIl">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d825f9/woman_found_still_alive_at_funeral_home_dies/">[comments]</a></span>

## Election board member in Georgia's Fulton County abstains from certifying primary election
 - [https://www.reddit.com/r/news/comments/1d7zcnl/election_board_member_in_georgias_fulton_county](https://www.reddit.com/r/news/comments/1d7zcnl/election_board_member_in_georgias_fulton_county)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T15:02:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/theluckyfrog"> /u/theluckyfrog </a> <br /> <span><a href="https://apnews.com/article/georgia-elections-fulton-county-julie-adams-79c93a5820eb8a9ecf6856171db72c10">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7zcnl/election_board_member_in_georgias_fulton_county/">[comments]</a></span>

## Grant program for Black women business owners is discriminatory, appeals court rules
 - [https://www.reddit.com/r/news/comments/1d7yyol/grant_program_for_black_women_business_owners_is](https://www.reddit.com/r/news/comments/1d7yyol/grant_program_for_black_women_business_owners_is)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T14:46:30+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Semper-Fido"> /u/Semper-Fido </a> <br /> <span><a href="https://www.npr.org/2024/06/03/g-s1-2649/fearless-fund-grant-program-appeal-ruling">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7yyol/grant_program_for_black_women_business_owners_is/">[comments]</a></span>

## Ex-Trump campaign attorney Kenneth Chesebro charged in Wisconsin
 - [https://www.reddit.com/r/news/comments/1d7yqmx/extrump_campaign_attorney_kenneth_chesebro](https://www.reddit.com/r/news/comments/1d7yqmx/extrump_campaign_attorney_kenneth_chesebro)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T14:37:08+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/untamedlazyeye"> /u/untamedlazyeye </a> <br /> <span><a href="https://www.axios.com/2024/06/04/kenneth-chesebro-wisconsin-2020-election-trump">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7yqmx/extrump_campaign_attorney_kenneth_chesebro/">[comments]</a></span>

## 83-year-old woman seriously injured after being gored by bison at Yellowstone National Park: Officials
 - [https://www.reddit.com/r/news/comments/1d7yfvt/83yearold_woman_seriously_injured_after_being](https://www.reddit.com/r/news/comments/1d7yfvt/83yearold_woman_seriously_injured_after_being)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T14:24:27+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/No-Blueberry1749"> /u/No-Blueberry1749 </a> <br /> <span><a href="https://abcnews.go.com/US/83-year-woman-injured-after-gored-bison-yellowstone/story?id=110797209">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7yfvt/83yearold_woman_seriously_injured_after_being/">[comments]</a></span>

## [Reuters] Gaza’s doctors were building a health system. Then came war: Health workers killed in the Gaza war have included more than 50 highly qualified specialists who were seeking to create a healthcare system for a Palestinian state, Reuters found.
 - [https://www.reddit.com/r/news/comments/1d7y810/reuters_gazas_doctors_were_building_a_health](https://www.reddit.com/r/news/comments/1d7y810/reuters_gazas_doctors_were_building_a_health)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T14:15:04+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/FlyEagles35"> /u/FlyEagles35 </a> <br /> <span><a href="https://www.reuters.com/investigates/special-report/israel-palestinians-gaza-health/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7y810/reuters_gazas_doctors_were_building_a_health/">[comments]</a></span>

## Pro-Palestine protesters interrupt Philadelphia Pride March: 'No pride in genocide'
 - [https://www.reddit.com/r/news/comments/1d7w8cv/propalestine_protesters_interrupt_philadelphia](https://www.reddit.com/r/news/comments/1d7w8cv/propalestine_protesters_interrupt_philadelphia)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T12:44:06+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/hyperlao"> /u/hyperlao </a> <br /> <span><a href="https://abc3340.com/news/nation-world/pro-palestine-protesters-interrupt-philadelphia-pride-march-no-pride-in-genocide-philly-pennsylvania-pride-month-june-israel-hamas-activism-lgbt-protest-nyc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7w8cv/propalestine_protesters_interrupt_philadelphia/">[comments]</a></span>

## Spotify raises prices on premium plans to boost profits.
 - [https://www.reddit.com/r/news/comments/1d7vj0r/spotify_raises_prices_on_premium_plans_to_boost](https://www.reddit.com/r/news/comments/1d7vj0r/spotify_raises_prices_on_premium_plans_to_boost)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T12:07:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Hazay-HD"> /u/Hazay-HD </a> <br /> <span><a href="https://www.latimes.com/entertainment-arts/business/story/2024-06-03/spotify-raises-prices-on-premium-us-plans">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7vj0r/spotify_raises_prices_on_premium_plans_to_boost/">[comments]</a></span>

## Abandoned baby Elsa is third newborn deserted by same parents
 - [https://www.reddit.com/r/news/comments/1d7tgs4/abandoned_baby_elsa_is_third_newborn_deserted_by](https://www.reddit.com/r/news/comments/1d7tgs4/abandoned_baby_elsa_is_third_newborn_deserted_by)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T10:01:43+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Similar_Rutabaga_593"> /u/Similar_Rutabaga_593 </a> <br /> <span><a href="https://www.bbc.com/news/articles/c5115e7k2eno">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7tgs4/abandoned_baby_elsa_is_third_newborn_deserted_by/">[comments]</a></span>

## Kanye West sued for sexual harassment by ex-assistant
 - [https://www.reddit.com/r/news/comments/1d7t7b6/kanye_west_sued_for_sexual_harassment_by](https://www.reddit.com/r/news/comments/1d7t7b6/kanye_west_sued_for_sexual_harassment_by)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T09:43:02+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/nahbruh27"> /u/nahbruh27 </a> <br /> <span><a href="https://bbc.com/news/articles/c3gg60g82meo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7t7b6/kanye_west_sued_for_sexual_harassment_by/">[comments]</a></span>

## FBI Raids Cortland Management Over Algorithmic Price-Fixing
 - [https://www.reddit.com/r/news/comments/1d7rr3z/fbi_raids_cortland_management_over_algorithmic](https://www.reddit.com/r/news/comments/1d7rr3z/fbi_raids_cortland_management_over_algorithmic)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T07:55:36+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Clownineat"> /u/Clownineat </a> <br /> <span><a href="https://www.coogfans.com/t/rent-an-apartment-you-probably-got-screwed/56344">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7rr3z/fbi_raids_cortland_management_over_algorithmic/">[comments]</a></span>

## Couple finds safe containing $100,000 while magnet fishing in Queens
 - [https://www.reddit.com/r/news/comments/1d7q6zy/couple_finds_safe_containing_100000_while_magnet](https://www.reddit.com/r/news/comments/1d7q6zy/couple_finds_safe_containing_100000_while_magnet)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T06:06:53+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Similar_Rutabaga_593"> /u/Similar_Rutabaga_593 </a> <br /> <span><a href="https://abcnews.go.com/US/couple-finds-safe-100000-magnet-fishing-queens/story?id=110771629">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7q6zy/couple_finds_safe_containing_100000_while_magnet/">[comments]</a></span>

## Rare skull of an extinct, massive ‘thunder bird’ discovered in Australia
 - [https://www.reddit.com/r/news/comments/1d7pvom/rare_skull_of_an_extinct_massive_thunder_bird](https://www.reddit.com/r/news/comments/1d7pvom/rare_skull_of_an_extinct_massive_thunder_bird)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T05:47:13+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Plainchant"> /u/Plainchant </a> <br /> <span><a href="https://www.cnn.com/2024/06/03/science/genyornis-newtoni-skull-thunder-bird-scn/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7pvom/rare_skull_of_an_extinct_massive_thunder_bird/">[comments]</a></span>

## Mother of airman killed by Florida deputy says his firing, alone, won't cut it
 - [https://www.reddit.com/r/news/comments/1d7n0z0/mother_of_airman_killed_by_florida_deputy_says](https://www.reddit.com/r/news/comments/1d7n0z0/mother_of_airman_killed_by_florida_deputy_says)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T03:00:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/storyspace1234"> /u/storyspace1234 </a> <br /> <span><a href="https://apnews.com/article/roger-fortson-florida-deputy-fired-charges-89c843dba31845df1c82415238179615">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7n0z0/mother_of_airman_killed_by_florida_deputy_says/">[comments]</a></span>

## 74-year-old woman pronounced dead in hospice care found breathing at funeral home
 - [https://www.reddit.com/r/news/comments/1d7lyr8/74yearold_woman_pronounced_dead_in_hospice_care](https://www.reddit.com/r/news/comments/1d7lyr8/74yearold_woman_pronounced_dead_in_hospice_care)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T02:04:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/halxp01"> /u/halxp01 </a> <br /> <span><a href="https://abcnews.go.com/US/woman-believed-dead-hospice-care-found-alive/story?id=110792361">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7lyr8/74yearold_woman_pronounced_dead_in_hospice_care/">[comments]</a></span>

## Epoch Times CFO Bill Guan is charged in alleged $67 million global money laundering scheme
 - [https://www.reddit.com/r/news/comments/1d7lewy/epoch_times_cfo_bill_guan_is_charged_in_alleged](https://www.reddit.com/r/news/comments/1d7lewy/epoch_times_cfo_bill_guan_is_charged_in_alleged)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T01:36:33+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/windowhihi"> /u/windowhihi </a> <br /> <span><a href="https://www.cnbc.com/2024/06/03/money-laundering-epoch-times-cfo-charged-with-alleged-67-million-scheme-.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7lewy/epoch_times_cfo_bill_guan_is_charged_in_alleged/">[comments]</a></span>

## FBI Raids Corporate Landlord in Major Rent Price-Fixing Probe: What It Means for You - Uprise RI
 - [https://www.reddit.com/r/news/comments/1d7kffx/fbi_raids_corporate_landlord_in_major_rent](https://www.reddit.com/r/news/comments/1d7kffx/fbi_raids_corporate_landlord_in_major_rent)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T00:46:41+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Clownineat"> /u/Clownineat </a> <br /> <span><a href="https://upriseri.com/fbi-raids-corporate-landlord-in-major-rent-price-fixing-probe-what-it-means-for-you/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7kffx/fbi_raids_corporate_landlord_in_major_rent/">[comments]</a></span>

## Jeffrey Epstein accuser sues prominent psychiatrist for making her 'sex slave'
 - [https://www.reddit.com/r/news/comments/1d7k7hb/jeffrey_epstein_accuser_sues_prominent](https://www.reddit.com/r/news/comments/1d7k7hb/jeffrey_epstein_accuser_sues_prominent)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-06-04T00:35:34+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/StabbyMcSwordfish"> /u/StabbyMcSwordfish </a> <br /> <span><a href="https://www.reuters.com/legal/jeffrey-epstein-accuser-sues-prominent-psychiatrist-making-her-sex-slave-2024-06-03/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1d7k7hb/jeffrey_epstein_accuser_sues_prominent/">[comments]</a></span>

