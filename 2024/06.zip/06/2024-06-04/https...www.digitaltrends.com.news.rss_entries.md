# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Intel goes to war with Nvidia and Qualcomm
 - [https://www.digitaltrends.com/computing/intel-goes-to-war-with-nvidia-and-qualcomm](https://www.digitaltrends.com/computing/intel-goes-to-war-with-nvidia-and-qualcomm)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-06-04T18:46:23.948751+00:00

During Intel's Computex 2024 keynote, CEO Pat Gelsinger didn't mince words when he insisted that Moore's Law is not dead at all.

## The RTX 5080 may be a disappointing upgrade after all
 - [https://www.digitaltrends.com/computing/nvidia-rtx-5080-5090-spec-rumors](https://www.digitaltrends.com/computing/nvidia-rtx-5080-5090-spec-rumors)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-06-04T00:53:01.571936+00:00

A new rumor regarding the specs of the upcoming RTX 5080 and RTX 5090 gives us more insight into Nvidia's plans, and it's not all good news.

## An unexpected phone brand is about to make its gaming laptop debut
 - [https://www.digitaltrends.com/computing/redmagic-steps-into-the-gaming-ring-powerful-laptop](https://www.digitaltrends.com/computing/redmagic-steps-into-the-gaming-ring-powerful-laptop)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-06-04T00:52:59.904089+00:00

The smartphone brand RedMagic is teasing its first attempt at a new product category.

