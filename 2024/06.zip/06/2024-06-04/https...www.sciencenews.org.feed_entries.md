# Source:Science News, URL:https://www.sciencenews.org/feed, language:en-US

## The sun is entering solar maximum. Expect auroras, and more
 - [https://www.sciencenews.org/article/sun-auroras-solar-maximum-2024](https://www.sciencenews.org/article/sun-auroras-solar-maximum-2024)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-06-04T16:00:00+00:00

May saw the strongest auroras in recent memory. As the sun gets more active, those light shows may be a preview of what’s to come until at least 2026.

## Thomas Cech’s ‘The Catalyst’ spotlights RNA and its superpowers
 - [https://www.sciencenews.org/article/thomas-cech-the-catalyst-rna-review](https://www.sciencenews.org/article/thomas-cech-the-catalyst-rna-review)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-06-04T13:15:00+00:00

Nobel Prize-winning biochemist Thomas Cech’s new book is part ode to RNA and part detailed history of the scientists who’ve studied it.

