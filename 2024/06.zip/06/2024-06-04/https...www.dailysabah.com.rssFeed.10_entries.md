# Source:DAILYSABAH - Turkey News, URL:https://www.dailysabah.com/rssFeed/10, language:en-US

## First lady Emine Erdoğan to chair Zero Waste meeting
 - [https://www.dailysabah.com/turkiye/first-lady-emine-erdogan-to-chair-zero-waste-meeting/news](https://www.dailysabah.com/turkiye/first-lady-emine-erdogan-to-chair-zero-waste-meeting/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-06-04T20:01:00+00:00

First Lady Emine Erdoğan will chair the second meeting of the Advisory Board of Eminent Persons on Zero Waste to spread the Zero Waste project on a global scale on World Environmen...

## Sidewalk hazards frustrate, endanger pedestrians in Istanbul
 - [https://www.dailysabah.com/turkiye/sidewalk-hazards-frustrate-endanger-pedestrians-in-istanbul/news](https://www.dailysabah.com/turkiye/sidewalk-hazards-frustrate-endanger-pedestrians-in-istanbul/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-06-04T11:22:00+00:00

The people of Istanbul find it frustrating to walk on the city's sidewalks that have been taken over by shop displays and illegally parked vehicles.

According to the Turkish...

## Mother, daughter graduate together from Türkiye's Bolu University
 - [https://www.dailysabah.com/turkiye/mother-daughter-graduate-together-from-turkiyes-bolu-university/news](https://www.dailysabah.com/turkiye/mother-daughter-graduate-together-from-turkiyes-bolu-university/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-06-04T09:54:00+00:00

A mother and her daughter who were accepted into the same faculty at Bolu Abant Izzet Baysal University (BAİBÜ) four years ago recently celebrated their graduation in Bolu, northwe...

## 115 mountaineers hike Phrygian Way in Türkiye's Afyonkarahisar
 - [https://www.dailysabah.com/turkiye/115-mountaineers-hike-phrygian-way-in-turkiyes-afyonkarahisar/news](https://www.dailysabah.com/turkiye/115-mountaineers-hike-phrygian-way-in-turkiyes-afyonkarahisar/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-06-04T08:47:12+00:00

Some 115 climbers made an unforgettable trek on the Phrygian Trails in Afyonkarahisar, located in the Aegean region of Türkiye.

The 'Phrygian Trails Trekking' event, organized wit...

## Over 1,500 buildings in Istanbul found at risk of collapse
 - [https://www.dailysabah.com/turkiye/over-1500-buildings-in-istanbul-found-at-risk-of-collapse/news](https://www.dailysabah.com/turkiye/over-1500-buildings-in-istanbul-found-at-risk-of-collapse/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-06-04T08:46:57+00:00

Some 1,556 buildings were detected at risk of collapse by the quick scanning tests of Istanbul Metropolitan Municipality (IBB). A press release made by the IBB stated that rapid sc...

## SF-260D-type training aircraft crashes in Türkiye's Kayseri
 - [https://www.dailysabah.com/turkiye/sf-260d-type-training-aircraft-crashes-in-turkiyes-kayseri/news](https://www.dailysabah.com/turkiye/sf-260d-type-training-aircraft-crashes-in-turkiyes-kayseri/news)
 - RSS feed: https://www.dailysabah.com/rssFeed/10
 - date published: 2024-06-04T07:40:00+00:00

The Ministry of National Defense reported that an SF-260D-type training aircraft had crashed in the central province of Kayseri on Tuesday morning.

In a statement from the ministr...

