# Source:Amiga, URL:https://www.reddit.com/r/amiga/.rss, language:en

## Help me find drivers for the PP&S DoubleTalk card
 - [https://www.reddit.com/r/amiga/comments/1d89yvu/help_me_find_drivers_for_the_pps_doubletalk_card](https://www.reddit.com/r/amiga/comments/1d89yvu/help_me_find_drivers_for_the_pps_doubletalk_card)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T22:20:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1d89yvu/help_me_find_drivers_for_the_pps_doubletalk_card/"> <img alt="Help me find drivers for the PP&amp;S DoubleTalk card" src="https://external-preview.redd.it/oCik46pHnavkwpiwacol6_YLg9sWz7lif7UtqxTyst0.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=cb0d09b335938e8de7e2e6e6724725b9351a744a" title="Help me find drivers for the PP&amp;S DoubleTalk card" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/deadvax"> /u/deadvax </a> <br /> <span><a href="https://www.youtube.com/watch?v=8z2q_xDxBZw">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1d89yvu/help_me_find_drivers_for_the_pps_doubletalk_card/">[comments]</a></span> </td></tr></table>

## Last post for tonigt... What chip should change here? I mean, it's possible to understand to don't go on tryes
 - [https://www.reddit.com/r/amiga/comments/1d89pka/last_post_for_tonigt_what_chip_should_change_here](https://www.reddit.com/r/amiga/comments/1d89pka/last_post_for_tonigt_what_chip_should_change_here)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T22:09:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1d89pka/last_post_for_tonigt_what_chip_should_change_here/"> <img alt="Last post for tonigt... What chip should change here? I mean, it's possible to understand to don't go on tryes" src="https://preview.redd.it/c65d8i57pm4d1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a61bebb0c86dedb540444e043cb788c4356e0b6c" title="Last post for tonigt... What chip should change here? I mean, it's possible to understand to don't go on tryes" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Accomplished_Head704"> /u/Accomplished_Head704 </a> <br /> <span><a href="https://i.redd.it/c65d8i57pm4d1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1d89pka/last_post_for_tonigt_what_chip_should_change_here/">[comments]</a></span> </td></tr></table>

## Remember guys. Always check if the G in "fat anGus" is present before hit enter on Google
 - [https://www.reddit.com/r/amiga/comments/1d87s6a/remember_guys_always_check_if_the_g_in_fat_angus](https://www.reddit.com/r/amiga/comments/1d87s6a/remember_guys_always_check_if_the_g_in_fat_angus)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T20:50:02+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Accomplished_Head704"> /u/Accomplished_Head704 </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1d87s6a/remember_guys_always_check_if_the_g_in_fat_angus/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1d87s6a/remember_guys_always_check_if_the_g_in_fat_angus/">[comments]</a></span>

## Finally got them.... Now? How to find the juice?
 - [https://www.reddit.com/r/amiga/comments/1d87qqn/finally_got_them_now_how_to_find_the_juice](https://www.reddit.com/r/amiga/comments/1d87qqn/finally_got_them_now_how_to_find_the_juice)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T20:48:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1d87qqn/finally_got_them_now_how_to_find_the_juice/"> <img alt="Finally got them.... Now? How to find the juice?" src="https://preview.redd.it/1mi6yfkpam4d1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ddaa7731ca574c3197e9f865896e97ca9511502c" title="Finally got them.... Now? How to find the juice?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I need to find the chip responsabile of this problem...</p> <p>.....EEEEEEEEEEE</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Accomplished_Head704"> /u/Accomplished_Head704 </a> <br /> <span><a href="https://i.redd.it/1mi6yfkpam4d1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1d87qqn/finally_got_them_now_how_to_find_the_juice/">[comments]</a></span> </td></tr></table>

## Fiddlesticks: Another World Death Compilation
 - [https://www.reddit.com/r/amiga/comments/1d85ryt/fiddlesticks_another_world_death_compilation](https://www.reddit.com/r/amiga/comments/1d85ryt/fiddlesticks_another_world_death_compilation)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T19:27:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1d85ryt/fiddlesticks_another_world_death_compilation/"> <img alt="Fiddlesticks: Another World Death Compilation" src="https://external-preview.redd.it/nddiP5oXOTkOAsaN0NQVs_8Ox9WSgc7bGVrNEcZOXOE.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=f7cd8b76044aa07ddf21e12ec02c7101855b9b20" title="Fiddlesticks: Another World Death Compilation" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Slow_Cheetah47"> /u/Slow_Cheetah47 </a> <br /> <span><a href="https://youtu.be/0KWW9LSyDko?si=UrIQgkORqutN9GiB">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1d85ryt/fiddlesticks_another_world_death_compilation/">[comments]</a></span> </td></tr></table>

## Andd... What is this? No label in there
 - [https://www.reddit.com/r/amiga/comments/1d845bp/andd_what_is_this_no_label_in_there](https://www.reddit.com/r/amiga/comments/1d845bp/andd_what_is_this_no_label_in_there)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T18:21:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1d845bp/andd_what_is_this_no_label_in_there/"> <img alt="Andd... What is this? No label in there" src="https://preview.redd.it/qvxqf7iikl4d1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c52171e2bf3ece52aa1aca81f32cd53e50609b6f" title="Andd... What is this? No label in there" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Accomplished_Head704"> /u/Accomplished_Head704 </a> <br /> <span><a href="https://i.redd.it/qvxqf7iikl4d1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1d845bp/andd_what_is_this_no_label_in_there/">[comments]</a></span> </td></tr></table>

## 3...2...1... Go! New issue now available
 - [https://www.reddit.com/r/amiga/comments/1d800b4/321_go_new_issue_now_available](https://www.reddit.com/r/amiga/comments/1d800b4/321_go_new_issue_now_available)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T15:29:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1d800b4/321_go_new_issue_now_available/"> <img alt="3...2...1... Go! New issue now available " src="https://preview.redd.it/re0tko1spk4d1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=857849e66cdacf25db776480187d59fd4274076e" title="3...2...1... Go! New issue now available " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>The main topic of the latest issue is racing games. Apart from that you will find many interesting articles about Commodore and Amiga. We invite you to read 🙂 </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Komoda_Amiga_plus"> /u/Komoda_Amiga_plus </a> <br /> <span><a href="https://i.redd.it/re0tko1spk4d1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1d800b4/321_go_new_issue_now_available/">[comments]</a></span> </td></tr></table>

## All Cinemaware Amiga games intros in one video
 - [https://www.reddit.com/r/amiga/comments/1d7xqlt/all_cinemaware_amiga_games_intros_in_one_video](https://www.reddit.com/r/amiga/comments/1d7xqlt/all_cinemaware_amiga_games_intros_in_one_video)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T13:54:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1d7xqlt/all_cinemaware_amiga_games_intros_in_one_video/"> <img alt="All Cinemaware Amiga games intros in one video" src="https://external-preview.redd.it/X8e3Ly3KL5-oo0IbgZU6IhJW9Ng1S2ri2VkE4CmiP5o.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=4e4b989af80c2d07ff53582cec80349e0a66f5ac" title="All Cinemaware Amiga games intros in one video" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>All Cinemaware Amiga games intros in one video Enjoy!!!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GreekRetroMan"> /u/GreekRetroMan </a> <br /> <span><a href="https://youtu.be/wndlyi1IQng">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1d7xqlt/all_cinemaware_amiga_games_intros_in_one_video/">[comments]</a></span> </td></tr></table>

## Ep. 11 Unboxing & playing Turbo Trax Amiga game [Ελληνικά]
 - [https://www.reddit.com/r/amiga/comments/1d7oxyq/ep_11_unboxing_playing_turbo_trax_amiga_game](https://www.reddit.com/r/amiga/comments/1d7oxyq/ep_11_unboxing_playing_turbo_trax_amiga_game)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T04:49:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1d7oxyq/ep_11_unboxing_playing_turbo_trax_amiga_game/"> <img alt="Ep. 11 Unboxing &amp; playing Turbo Trax Amiga game [Ελληνικά]" src="https://external-preview.redd.it/XuGNRR-oXoEM6KlamiZ_CpsYDqxQa_JHfWPbu8Ih8Wk.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=46c5f3fa27853de9971b36632c0947da04f68cf0" title="Ep. 11 Unboxing &amp; playing Turbo Trax Amiga game [Ελληνικά]" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Turbo Trax is a racing game which tries to bring the feeling of electric car races to the computer. The courses feature elements from the toys like crossovers or chicanes, along with a pit stop which can be used to repair damage or refuel. However, the gameplay is action oriented with the main challenge to avoid going too fast into curves.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GreekRetroMan"> /u/GreekRetroMan </a> <br /> <span><a href="https://youtu.be/d

## WinUAE 5.3.0
 - [https://www.reddit.com/r/amiga/comments/1d7k8om/winuae_530](https://www.reddit.com/r/amiga/comments/1d7k8om/winuae_530)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-04T00:37:15+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Doener23"> /u/Doener23 </a> <br /> <span><a href="https://www.winuae.net/2024/06/02/winuae-5-3-0/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1d7k8om/winuae_530/">[comments]</a></span>

