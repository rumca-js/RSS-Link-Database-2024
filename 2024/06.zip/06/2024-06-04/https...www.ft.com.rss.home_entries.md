# Source:FT - International homepage, URL:https://www.ft.com/rss/home, language:en

## Panel advising US regulator rejects psychedelic MDMA as treatment for PTSD
 - [https://www.ft.com/content/70ea9c45-ef00-48f9-a85a-0761314449d9](https://www.ft.com/content/70ea9c45-ef00-48f9-a85a-0761314449d9)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T22:49:19+00:00

Vote on psychedelic drug is non-binding but carries influence with FDA in blow to pharmaceutical developers

## Short-term Treasuries notch longest win streak in 3 months on soft jobs data
 - [https://www.ft.com/content/5359f2a1-8f01-416d-b4dd-916df2c7947a](https://www.ft.com/content/5359f2a1-8f01-416d-b4dd-916df2c7947a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T22:45:02+00:00



## Sunak and Starmer clash on tax and immigration in testy TV debate
 - [https://www.ft.com/content/32ffd10b-564d-404c-8744-2d4b869137d3](https://www.ft.com/content/32ffd10b-564d-404c-8744-2d4b869137d3)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T22:34:35+00:00

Party leaders repeatedly interrupt each other but snap poll gives PM a much-needed win

## What elections mean for markets this year
 - [https://www.ft.com/content/9ce3545b-a53c-41bd-920c-f5ffcac3677b](https://www.ft.com/content/9ce3545b-a53c-41bd-920c-f5ffcac3677b)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T20:00:00+00:00

Elections in Mexico and India moved markets this week. What will UK and US elections mean for markets later this year?

## Hunter Biden’s drug abuse in focus as prosecutors open firearm trial
 - [https://www.ft.com/content/36ccbed8-1cf7-4dcd-b362-e118f7df1948](https://www.ft.com/content/36ccbed8-1cf7-4dcd-b362-e118f7df1948)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T19:55:54+00:00

Federal lawyers will introduce lurid photos and messages as they build case against president’s son

## Pedro Sánchez defiant as wife is placed under formal investigation
 - [https://www.ft.com/content/fb4a3118-be38-4fdc-a928-24fb8b62ba41](https://www.ft.com/content/fb4a3118-be38-4fdc-a928-24fb8b62ba41)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T19:49:59+00:00

Spain’s Socialist prime minister defends Begoña Gómez in open letter and says case politically motivated

## Mexico’s finance minister tries to reassure jittery investors
 - [https://www.ft.com/content/e143a9f7-3ac6-497e-b4a7-ea73fa676f2e](https://www.ft.com/content/e143a9f7-3ac6-497e-b4a7-ea73fa676f2e)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T18:57:25+00:00

Hasty conference call fails to calm markets after election landslide

## Erdoğan’s firing of Turkey’s central bank heads ruled unconstitutional
 - [https://www.ft.com/content/f290bbaf-0d12-4480-bef0-4baca576e6b7](https://www.ft.com/content/f290bbaf-0d12-4480-bef0-4baca576e6b7)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T18:53:10+00:00

Top court strikes down leader’s right to curtail tenures of bank governors

## Biden accuses Netanyahu of prolonging Gaza conflict
 - [https://www.ft.com/content/1831cfdc-4e96-42ae-ad0f-ebba6592f6f7](https://www.ft.com/content/1831cfdc-4e96-42ae-ad0f-ebba6592f6f7)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T17:47:39+00:00

US president’s comments increase pressure on Israel’s prime minister to defy coalition critics and support peace plan

## Nationalism threatens the world order
 - [https://www.ft.com/content/17344ba0-563a-4796-a2b7-7e8095e6dc78](https://www.ft.com/content/17344ba0-563a-4796-a2b7-7e8095e6dc78)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T15:40:21+00:00

If America retreats from its security guarantee of Europe, the consequences for global stability will be dire

## Redstone leaves investors guessing as Paramount and Skydance agree terms
 - [https://www.ft.com/content/ed6dba62-769e-4e5d-8f06-98fb7acd0eee](https://www.ft.com/content/ed6dba62-769e-4e5d-8f06-98fb7acd0eee)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T15:38:00+00:00

Controlling shareholder of Hollywood group states ‘confidence’ in co-chiefs pitching to keep company private

## Modi’s wobble in India leaves the status quo in question
 - [https://www.ft.com/content/c4f7b023-90b2-4a0d-8a4c-05afd32335c9](https://www.ft.com/content/c4f7b023-90b2-4a0d-8a4c-05afd32335c9)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T15:07:25+00:00

Good news for most investors is that country’s broader economic growth story looks intact

## Oil extends losses as Opec+ and weak US data unnerve traders
 - [https://www.ft.com/content/c2bc1958-eb3f-4ffc-8f66-ee78a4ab7350](https://www.ft.com/content/c2bc1958-eb3f-4ffc-8f66-ee78a4ab7350)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T15:04:52+00:00

Brent’s 1.4% drop after 4% fall the previous day follows cartel decision to unwind some production cuts

## BBVA raises fresh capital after prosecutor pushes for spying trial
 - [https://www.ft.com/content/ed3406e3-395a-43c8-a5bc-55ca1ddf8396](https://www.ft.com/content/ed3406e3-395a-43c8-a5bc-55ca1ddf8396)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T14:54:44+00:00

Judge must rule whether bank should face criminal trial on historic corporate espionage allegations

## ANC internal document advises coalition deal with centrist Democratic Alliance
 - [https://www.ft.com/content/ec2de91c-fba7-493b-9ee9-8840bb8413da](https://www.ft.com/content/ec2de91c-fba7-493b-9ee9-8840bb8413da)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T13:32:59+00:00

Discussion follows shock South African election in which the ruling party was stripped of its majority

## Don’t write off BBVA’s chances in its Sabadell takeover
 - [https://www.ft.com/content/4b94032a-161f-4567-b90e-282fe2c9d5ac](https://www.ft.com/content/4b94032a-161f-4567-b90e-282fe2c9d5ac)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T11:44:29+00:00

Investors have taken umbrage but the pursuit has sound industrial logic

## Inflation ain’t behaving
 - [https://www.ft.com/content/cd48d8a1-59b0-47be-a2b4-50ec4e80cd29](https://www.ft.com/content/cd48d8a1-59b0-47be-a2b4-50ec4e80cd29)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T11:30:13+00:00

The US, Eurozone, UK and Japan each have reasons to be unhappy

## South Africa’s MultiChoice supports $2.9bn offer from France’s Canal+
 - [https://www.ft.com/content/62071de0-e323-4672-8821-eae4f9b9c06e](https://www.ft.com/content/62071de0-e323-4672-8821-eae4f9b9c06e)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T11:06:14+00:00

Takeover of Africa’s largest pay-TV operator must overcome regulatory hurdles

## What do novelists have to say about election fever?
 - [https://www.ft.com/content/356150d3-2626-40fe-b34d-a26efa050fb2](https://www.ft.com/content/356150d3-2626-40fe-b34d-a26efa050fb2)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T11:00:13+00:00

With more than 80 countries going to the polls this year, it’s time to revisit the best fictional accounts of political high drama

## Biden has put his credibility on the line with the Gaza plan
 - [https://www.ft.com/content/a2a2d119-4fe0-4619-9626-9d1ab4d647b3](https://www.ft.com/content/a2a2d119-4fe0-4619-9626-9d1ab4d647b3)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T10:37:00+00:00

Now Netanyahu will have to choose between rebuffing the US president or accepting a deal in Israel’s long-term interest

## Italy to send second air defence system to Ukraine
 - [https://www.ft.com/content/bfeb2702-10b6-438d-9435-6a6d10e3585e](https://www.ft.com/content/bfeb2702-10b6-438d-9435-6a6d10e3585e)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T10:00:31+00:00

Move follows renewed Russian aerial bombardments leading to nationwide blackouts

## Germany leads rebellion against EU foreign influence law
 - [https://www.ft.com/content/2a1e35b6-54b7-4601-a62d-78e16af88838](https://www.ft.com/content/2a1e35b6-54b7-4601-a62d-78e16af88838)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T09:23:51+00:00

Opposing countries argue bill mirrors Russia-inspired crackdown on civil rights groups

## Maersk sees turnaround amid Red Sea disruption and freight rate surge
 - [https://www.ft.com/content/68713d24-09bf-409a-8a69-43e74f10c8b9](https://www.ft.com/content/68713d24-09bf-409a-8a69-43e74f10c8b9)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T09:20:45+00:00

Container shipping group raises financial guidance for the second time in just over a month

## BuzzFeed faces dual buzz saw of Ramaswamy and debt
 - [https://www.ft.com/content/c780ccf9-57e4-43bd-bee7-7e4891e7be49](https://www.ft.com/content/c780ccf9-57e4-43bd-bee7-7e4891e7be49)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T08:34:27+00:00

Former presidential candidate has taken stake in company with over $100mn of convertible bonds due in December

## India’s Narendra Modi on course for election win
 - [https://www.ft.com/content/1de49cb9-db2c-446f-8ee4-9bdbb4a7625b](https://www.ft.com/content/1de49cb9-db2c-446f-8ee4-9bdbb4a7625b)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T06:25:35+00:00

Prime minister has reshaped politics, economy and society in world’s most populous country

## World falling short on renewable energy goal for 2030, IEA warns
 - [https://www.ft.com/content/5b2770aa-b42d-4fba-8944-30431a365101](https://www.ft.com/content/5b2770aa-b42d-4fba-8944-30431a365101)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T05:00:13+00:00

UN talks kick off as countries fall behind the curve on targets and global warming heads for 2.7C since pre-industrial times

## Elephant invasion pits Zambian villagers against conservationists
 - [https://www.ft.com/content/c5947f73-6e3a-46a7-8ac1-18a64e7b8888](https://www.ft.com/content/c5947f73-6e3a-46a7-8ac1-18a64e7b8888)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Devastation caused by animals highlights tension between global environmentalists and locals that live alongside wildlife

## Europe’s steelmakers risk missing climate targets despite billions in subsidies
 - [https://www.ft.com/content/a3c4862e-6f32-4eb5-a316-2d8ef13096d6](https://www.ft.com/content/a3c4862e-6f32-4eb5-a316-2d8ef13096d6)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Environmental campaigners warn that the industry must speed up plans to decarbonise

## Five challenges facing Mexico’s Claudia Sheinbaum
 - [https://www.ft.com/content/44b92bed-9bbc-4a6e-9a32-b2ed37fb81f0](https://www.ft.com/content/44b92bed-9bbc-4a6e-9a32-b2ed37fb81f0)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Big budget deficit and record number of murders top the president-elect’s worries

## Hedge fund short sellers burnt by flurry of UK takeover bids
 - [https://www.ft.com/content/e4d32fb6-4f42-41bc-adf1-9a10edec4928](https://www.ft.com/content/e4d32fb6-4f42-41bc-adf1-9a10edec4928)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Managers scale back or ditch bets against London-listed stocks after M&amp;A activity drives sharp share price rises

## How the ANC can save South Africa
 - [https://www.ft.com/content/a6724135-37f2-40aa-bbd1-574d34a79eed](https://www.ft.com/content/a6724135-37f2-40aa-bbd1-574d34a79eed)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

The party may ultimately be doomed — but it could yet stave off disaster for the country

## Meloni and Le Pen: the relationship at the heart of European politics
 - [https://www.ft.com/content/21d1e0a4-ba03-4080-b9d7-8f12435cbdde](https://www.ft.com/content/21d1e0a4-ba03-4080-b9d7-8f12435cbdde)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

How Italy’s prime minister and France’s opposition leader work together — or not — will help determine the EU’s future direction

## Opec+ is running out of road
 - [https://www.ft.com/content/862a4d03-0428-4034-96ee-ab0d4fbf87fe](https://www.ft.com/content/862a4d03-0428-4034-96ee-ab0d4fbf87fe)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Both shale producers and offshore fields have become more efficient, which leaves the cartel in a tough spot

## Peter Orszag wants to reimagine Lazard. Will his bankers let him?
 - [https://www.ft.com/content/cc892654-6d14-4036-8474-a1cbbfba532a](https://www.ft.com/content/cc892654-6d14-4036-8474-a1cbbfba532a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Barack Obama’s economist has brought star power to a faded investment bank, but rank and file have doubts about his plan

## The laws of electoral gravity still don’t apply to Trump
 - [https://www.ft.com/content/27aaf007-a1ae-4aa9-80d0-21f7acf25032](https://www.ft.com/content/27aaf007-a1ae-4aa9-80d0-21f7acf25032)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Even the verdict in his hush money trial has had no material impact

## Trio of Tory donors decide against funding election campaign
 - [https://www.ft.com/content/86ea7334-0860-4dde-86a6-373061fba2e4](https://www.ft.com/content/86ea7334-0860-4dde-86a6-373061fba2e4)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Private poll by pro-Tory firms shows Labour party on track for landslide victory

## UAE seeks ‘marriage’ with US over artificial intelligence deals
 - [https://www.ft.com/content/b72ba623-8e3c-4d29-837b-33f6b8407fb8](https://www.ft.com/content/b72ba623-8e3c-4d29-837b-33f6b8407fb8)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Gulf state’s AI minister says recent investment deal between Microsoft and G42 is part of strategy to reshape its economy

## UK politics must stop fixating on the grey vote
 - [https://www.ft.com/content/7b3f25c4-5f07-4430-bc24-458b8677af62](https://www.ft.com/content/7b3f25c4-5f07-4430-bc24-458b8677af62)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Singling out those who are past retirement age leads to campaigns that are largely about spending public money

## West grapples with response to Russian sabotage attempts
 - [https://www.ft.com/content/bf128ebf-2e3f-40a3-b7ec-bcd1b477ab9a](https://www.ft.com/content/bf128ebf-2e3f-40a3-b7ec-bcd1b477ab9a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-06-04T04:00:13+00:00

Moscow has mastered hybrid warfare, covering its tracks when planning arson and other ‘grey zone’ attacks in Europe

