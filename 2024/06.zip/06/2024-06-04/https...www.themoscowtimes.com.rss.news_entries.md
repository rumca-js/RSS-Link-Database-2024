# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## ‘The Kremlin Wants Us to Forget His Name’: Supporters Pay Tribute to Navalny on His 48th Birthday
 - [https://www.themoscowtimes.com/2024/06/04/the-kremlin-wants-us-to-forget-his-name-supporters-pay-tribute-to-navalny-on-his-48th-birthday-a85315](https://www.themoscowtimes.com/2024/06/04/the-kremlin-wants-us-to-forget-his-name-supporters-pay-tribute-to-navalny-on-his-48th-birthday-a85315)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-06-04T19:23:00+00:00

Supporters of the late Kremlin foe said they aim to keep his memory alive no matter what.

## Russian Duolingo Removes LGBTQ+ References in Censorship Compliance
 - [https://www.themoscowtimes.com/2024/06/04/russian-duolingo-removes-lgbtq-references-in-censorship-compliance-a85314](https://www.themoscowtimes.com/2024/06/04/russian-duolingo-removes-lgbtq-references-in-censorship-compliance-a85314)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-06-04T14:13:25+00:00

The order came after conservative activists spotted phrases like “Ben and Peter love each other” and “Clara met Maria at a lesbian bar."

## Starbucks Applies for Russian Patents After Leaving Country
 - [https://www.themoscowtimes.com/2024/06/04/starbucks-applies-for-russian-patents-after-leaving-country-a85313](https://www.themoscowtimes.com/2024/06/04/starbucks-applies-for-russian-patents-after-leaving-country-a85313)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-06-04T13:24:00+00:00

Experts speculate it could signal either Starbucks’ potential return to the Russian market or an effort to extend patent protections before they expire.

## Moscow Claims West Planning Regime Change in Georgia
 - [https://www.themoscowtimes.com/2024/06/04/moscow-claims-west-planning-regime-change-in-georgia-a85311](https://www.themoscowtimes.com/2024/06/04/moscow-claims-west-planning-regime-change-in-georgia-a85311)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-06-04T12:29:56+00:00

“We don’t rule out that the goal is to try to put in action the ‘Maidan’ scenario of regime change,” the Russian deputy foreign minister said.

## Western Army Trainers in Ukraine Not Immune From Strikes, Kremlin Says
 - [https://www.themoscowtimes.com/2024/06/04/western-army-trainers-in-ukraine-not-immune-from-strikes-kremlin-says-a85312](https://www.themoscowtimes.com/2024/06/04/western-army-trainers-in-ukraine-not-immune-from-strikes-kremlin-says-a85312)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-06-04T11:41:15+00:00

France officially does not currently have military personnel assisting or training Ukrainian forces in Ukraine.

## Bulletproof Vests on Red Square: Kremlin Secretly Beefs Up Putin’s Personal Security
 - [https://www.themoscowtimes.com/2024/06/04/bulletproof-vests-on-red-square-kremlin-secretly-beefs-up-putins-personal-security-a85303](https://www.themoscowtimes.com/2024/06/04/bulletproof-vests-on-red-square-kremlin-secretly-beefs-up-putins-personal-security-a85303)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-06-04T10:58:00+00:00

The special services control practically every aspect of Putin’s life, down to testing his meals for poison, a source close to the Kremlin said.

## Russia Ramps up Disinformation War Ahead of Paris Games – Microsoft
 - [https://www.themoscowtimes.com/2024/06/04/russia-ramps-up-disinformation-war-ahead-of-paris-games-microsoft-a85309](https://www.themoscowtimes.com/2024/06/04/russia-ramps-up-disinformation-war-ahead-of-paris-games-microsoft-a85309)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-06-04T10:14:30+00:00

The Kremlin condemned the report from Microsoft as “absolute slander."

## Sanctioned VTB Bank to Open Branches in Occupied Ukraine
 - [https://www.themoscowtimes.com/2024/06/04/sanctioned-vtb-bank-to-open-branches-in-occupied-ukraine-a85308](https://www.themoscowtimes.com/2024/06/04/sanctioned-vtb-bank-to-open-branches-in-occupied-ukraine-a85308)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-06-04T09:25:00+00:00

The sanctioned banks will serve customers in the occupied cities of Mariupol, Donetsk and Luhansk.

## Governor of Russia’s Altai Republic Resigns
 - [https://www.themoscowtimes.com/2024/06/04/governor-of-russias-altai-republic-resigns-a85307](https://www.themoscowtimes.com/2024/06/04/governor-of-russias-altai-republic-resigns-a85307)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-06-04T08:27:24+00:00

Oleg Khorokhordin had been reported to be next in line following the back-to-back resignations of two other regional governors last week.

