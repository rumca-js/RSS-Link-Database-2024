# Source:CD-Action - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g, language:pl

## feat. @NRGeek00 i @tvgrypl @ CD-Action Expo | CD-Action Air #60 (cz. 1)
 - [https://www.youtube.com/watch?v=wFYt5Rmffi4](https://www.youtube.com/watch?v=wFYt5Rmffi4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g
 - date published: 2024-06-04T14:19:12+00:00

Pierwsza część podcastu nagranego ze sceny głównej CD-Action Expo 2024 w Atlas Arena w Łodzi. Serdecznie dziękujemy naszym gościom:

@NRGeek00– Krzysztof „NRGeek” Micielski 
@tvgrypl– Michał „Elessar” Mańka oraz Szymon „Rusnar” Rusnarczyk

Koniecznie zobacz nas w innych miejscach:

Strona :: https://cdaction.pl/
Sklep :: https://sklep.cdaction.pl/
Instagram :: https://instagram.com/cdaction
Facebook :: http://fb.me/CDAction/
Twitter :: https://twitter.com/cdaction
Discord CD-Action :: https://discord.gg/9Aqf3Cjcxx
Kontakt :: youtube@cdaction.pl

To my:

Krzysztof „Bastian” Freudenberger (http://twitter.com/BastianCDA)
Dawid „spikain" Bojarski (http://twitter.com/spikain)

Montaż: Krzysztof „Bastian” Freudenberger

