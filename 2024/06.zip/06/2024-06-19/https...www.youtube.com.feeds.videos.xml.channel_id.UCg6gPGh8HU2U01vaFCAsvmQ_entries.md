# Source:Chris Titus Tech, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCg6gPGh8HU2U01vaFCAsvmQ, language:en

## You NEED to Contribute to Open Source
 - [https://www.youtube.com/watch?v=JF8F7uaGfV8](https://www.youtube.com/watch?v=JF8F7uaGfV8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCg6gPGh8HU2U01vaFCAsvmQ
 - date published: 2024-06-19T11:15:01+00:00

This video explains how to contribute to open source and what normal users should do or new developers should do when contributing.

The @t3dotgg  https://www.youtube.com/watch?v=5nY_cy8zcO4

►► Digital Downloads ➜ https://www.cttstore.com
►► Reddit ➜ https://www.reddit.com/r/ChrisTitusTech/
►► Titus Tech Talk ➜ https://www.youtube.com/c/TitusTechTalk
►► Twitch ➜ https://www.twitch.tv/christitustech

