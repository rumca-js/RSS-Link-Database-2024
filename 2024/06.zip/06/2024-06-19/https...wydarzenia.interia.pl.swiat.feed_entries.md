# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Marszałek Sejmu w Kijowie. Przyjął go Wołodymyr Zełenski
 - [https://wydarzenia.interia.pl/zagranica/news-marszalek-sejmu-w-kijowie-przyjal-go-wolodymyr-zelenski,nId,7584416](https://wydarzenia.interia.pl/zagranica/news-marszalek-sejmu-w-kijowie-przyjal-go-wolodymyr-zelenski,nId,7584416)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-06-19T14:54:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-marszalek-sejmu-w-kijowie-przyjal-go-wolodymyr-zelenski,nId,7584416"><img align="left" alt="Marszałek Sejmu w Kijowie. Przyjął go Wołodymyr Zełenski" src="https://i.iplsc.com/marszalek-sejmu-w-kijowie-przyjal-go-wolodymyr-zelenski/000JCD6Y8PVE95YE-C321.jpg" /></a>Szymon Hołownia pojawił się w Kijowie z roboczą wizytą, podczas której został przyjęty przez Wołodymyra Zełenskiego. - Polska nie godzi się na działania wymierzone w prawa człowieka ani na próby kwestionowania istnienia narodów - powiedział w stolicy Ukrainy marszałek Sejmu. </p><br clear="all" />

## Rośnie napięcie na Kaukazie. Komunikat MSZ o "nowej agresji"
 - [https://wydarzenia.interia.pl/zagranica/news-rosnie-napiecie-na-kaukazie-komunikat-msz-o-nowej-agresji,nId,7584237](https://wydarzenia.interia.pl/zagranica/news-rosnie-napiecie-na-kaukazie-komunikat-msz-o-nowej-agresji,nId,7584237)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-06-19T11:15:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosnie-napiecie-na-kaukazie-komunikat-msz-o-nowej-agresji,nId,7584237"><img align="left" alt="Rośnie napięcie na Kaukazie. Komunikat MSZ o &quot;nowej agresji&quot;" src="https://i.iplsc.com/rosnie-napiecie-na-kaukazie-komunikat-msz-o-nowej-agresji/000JC9N9641WGJB0-C321.jpg" /></a>&quot;Azerbejdżan zrobi wszystko, aby storpedować proces pokojowy&quot; - czytamy w komunikacie wydanym przez Ministerstwo Spraw Zagranicznych Armenii. Przedstawiciele departamentu są przekonani, że rząd w Baku planuje nowe działania wojskowe, które rozpoczną się w przeciągu kilku miesięcy.</p><br clear="all" />

## Ekstremalne upały w czasie pielgrzymki. Zmarło ponad 550 osób
 - [https://wydarzenia.interia.pl/zagranica/news-ekstremalne-upaly-w-czasie-pielgrzymki-zmarlo-ponad-550-osob,nId,7584108](https://wydarzenia.interia.pl/zagranica/news-ekstremalne-upaly-w-czasie-pielgrzymki-zmarlo-ponad-550-osob,nId,7584108)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-06-19T09:38:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ekstremalne-upaly-w-czasie-pielgrzymki-zmarlo-ponad-550-osob,nId,7584108"><img align="left" alt="Ekstremalne upały w czasie pielgrzymki. Zmarło ponad 550 osób" src="https://i.iplsc.com/ekstremalne-upaly-w-czasie-pielgrzymki-zmarlo-ponad-550-osob/000JC8P0N027X2IG-C321.jpg" /></a>Ponad 550 osób zmarło podczas tegorocznej pielgrzymki do Mekki, w której bierze udział ponad 1,8 miliona osób. Do ich śmierci przyczyniły się panujące tam ekstremalne upały. Temperatury chwilami przekraczają nawet 50 st. C. </p><br clear="all" />

## Jest największy rywalem Orbana. W tej sprawie premier ma jego wsparcie
 - [https://wydarzenia.interia.pl/zagranica/news-jest-najwiekszy-rywalem-orbana-w-tej-sprawie-premier-ma-jego,nId,7583968](https://wydarzenia.interia.pl/zagranica/news-jest-najwiekszy-rywalem-orbana-w-tej-sprawie-premier-ma-jego,nId,7583968)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-06-19T06:14:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-jest-najwiekszy-rywalem-orbana-w-tej-sprawie-premier-ma-jego,nId,7583968"><img align="left" alt="Jest największy rywalem Orbana. W tej sprawie premier ma jego wsparcie" src="https://i.iplsc.com/jest-najwiekszy-rywalem-orbana-w-tej-sprawie-premier-ma-jego/000JC7HGKJYBL6YD-C321.jpg" /></a>Mimo że jest zagorzałym przeciwnikiem rządu Viktora Orbana, to w tej kwestii popiera premiera Węgier. Mowa o liderze największej opozycyjnej partii i sprawie wsparcia dla Ukrainy. Peter Magyar zadeklarował bowiem, że jego formacja &quot;podziela stanowisko rządu&quot; i jest przeciw wysyłaniu broni atakowanemu przez Moskwę Kijowowi.</p><br clear="all" />

## Gorąco na Bałkanach. Ruch Amerykanów w sprawie prorosyjskiego prezydenta
 - [https://wydarzenia.interia.pl/zagranica/news-goraco-na-balkanach-ruch-amerykanow-w-sprawie-prorosyjskiego,nId,7583950](https://wydarzenia.interia.pl/zagranica/news-goraco-na-balkanach-ruch-amerykanow-w-sprawie-prorosyjskiego,nId,7583950)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-06-19T04:09:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-goraco-na-balkanach-ruch-amerykanow-w-sprawie-prorosyjskiego,nId,7583950"><img align="left" alt="Gorąco na Bałkanach. Ruch Amerykanów w sprawie prorosyjskiego prezydenta " src="https://i.iplsc.com/goraco-na-balkanach-ruch-amerykanow-w-sprawie-prorosyjskiego/000J1GCUOPLSA1BH-C321.jpg" /></a>Amerykański Departament Skarbu nałożył sankcje na firmy blisko powiązane z prorosyjskim przywódcą Republiki Serbskiej. Milorad Dodik od miesięcy wskazuje na konieczność &quot;rozbicia&quot; Bośni i Hercegowiny oraz wybicia się na niepodległość. &quot;Próbują destabilizować kraj&quot; - oceniają Amerykanie. Sankcje polegają m.in. na zamrożeniu aktywów w USA i zakazie prowadzenia interesów ze wskazanymi przedsiębiorstwami. </p><br clear="all" />

