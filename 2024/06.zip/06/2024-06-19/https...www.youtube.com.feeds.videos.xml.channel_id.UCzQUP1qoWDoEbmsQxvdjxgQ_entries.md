# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Joe Rogan Experience #2166 - Enhanced Games
 - [https://www.youtube.com/watch?v=qRLAiEZLpVg](https://www.youtube.com/watch?v=qRLAiEZLpVg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2024-06-19T17:00:37+00:00

Christian Angermayer and Dr. Aron D’Souza are the co-founders of the Enhanced Games, an upcoming Olympic-style event that brings together the world’s top athletes to compete without arbitrary bans on performance-enhancing substances. 

www.enhanced.org

