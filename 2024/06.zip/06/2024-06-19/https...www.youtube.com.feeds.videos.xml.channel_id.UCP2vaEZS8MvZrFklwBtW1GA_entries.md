# Source:Home Repair Tutor, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA, language:en

## Consejos para el esquinero del panel de yeso - #shorts
 - [https://www.youtube.com/watch?v=kzjRZ3N15wA](https://www.youtube.com/watch?v=kzjRZ3N15wA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA
 - date published: 2024-06-19T11:00:53+00:00

En esta ducha tuve que instalar un esquinero. Utilicé cinta adhesiva para baldosas Strait-Flex con mortero de Schluter. Apliqué el mortero al panel de yeso y al KERDI-BOARD de Schluter. Entonces empotré la cinta adhesiva para baldosas. Y usé un cuchillo para paneles de yeso de tres pulgadas para alisarlo. El último paso fue utilizar esponja para eliminar el exceso de mortero.

