# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Kalisz: PKW dostała dowody w sprawie Funduszu Sprawiedliwości. Musimy to przeanalizować
 - [https://tvn24.pl/polska/kalisz-pkw-dostala-dowody-w-sprawie-funduszu-sprawiedliwosci-musimy-to-przeanalizowac-st7970681?source=rss](https://tvn24.pl/polska/kalisz-pkw-dostala-dowody-w-sprawie-funduszu-sprawiedliwosci-musimy-to-przeanalizowac-st7970681?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T20:12:06+00:00

<img alt="Kalisz: PKW dostała dowody w sprawie Funduszu Sprawiedliwości. Musimy to przeanalizować" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3851684-19-1925-fpf-gosc-0008-ph7970594/alternates/LANDSCAPE_1280" />
    Dostaliśmy dowody w związku z Funduszem Sprawiedliwości z Ministerstwa Sprawiedliwości. Tam jest to wszystko wyszczególnione. Musimy to wszystko przeanalizować, każdy z członków PKW - mówił Ryszard Kalisz w "Faktach po Faktach". - Jeżeli informację przesyła minister sprawiedliwości, trudno tych dowodów nie traktować poważnie - dodał członek Państwowej Komisji Wyborczej.

## Proces Obywateli Rzeszy, akcja na rzecz delegalizacji  AfD i dziennikarskie śledztwo w sprawie młodzieżówki Braci Włochów
 - [https://fakty.tvn24.pl/fakty-o-swiecie/proces-obywateli-rzeszy-akcja-na-rzecz-delegalizacji-afd-i-dziennikarskie-sledztwo-w-sprawie-mlodziezowki-braci-wlochow-st7970671?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/proces-obywateli-rzeszy-akcja-na-rzecz-delegalizacji-afd-i-dziennikarskie-sledztwo-w-sprawie-mlodziezowki-braci-wlochow-st7970671?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T19:56:24+00:00

<img alt="Proces Obywateli Rzeszy, akcja na rzecz delegalizacji  AfD i dziennikarskie śledztwo w sprawie młodzieżówki Braci Włochów" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-6153307-loska-ph7970688/alternates/LANDSCAPE_1280" />
    Planowali porwać kanclerza i zaatakować parlament. Planowali po prostu obalić niemieckie władze. Za to przed sądem odpowiadają członkowie ekstremistycznego, prawicowego ugrupowania Reichsbürger - Obywatele Rzeszy. Zarzuca im się próbę przeprowadzenia zamachu stanu i działalność terrorystyczną. Proces może potrwać długo, ale wpisuje się w nowy polityczny krajobraz Europy, w którym skrajne siły są coraz groźniejsze i coraz skuteczniejsze w osiąganiu swoich celów.

## Dwie nastolatki podejrzane o oszustwo metodą na wnuczka
 - [https://tvn24.pl/tvnwarszawa/najnowsze/grodzisk-mazowiecki-seniorka-stracila-50-tysiecy-zlotych-dwie-nastolatki-sa-podejrzane-o-oszustwo-i-posiadanie-narkotykow-st7970569?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/grodzisk-mazowiecki-seniorka-stracila-50-tysiecy-zlotych-dwie-nastolatki-sa-podejrzane-o-oszustwo-i-posiadanie-narkotykow-st7970569?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T19:49:44+00:00

<img alt="Dwie nastolatki podejrzane o oszustwo metodą na wnuczka" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5933068-policjant-z-zatrzymana-nastolatka-ph7970592/alternates/LANDSCAPE_1280" />
    Policjanci z Grodziska Mazowieckiego zatrzymali dwie nastolatki podejrzane o oszustwo metodą na wnuczka". Starsza kobieta przekazała im 50 tysięcy złotych. Dla nastolatek problematyczna okazała się też zawartość pokoju hotelowego, w którym się zatrzymały.

## Aktor Bartłomiej M. skazany za gwałt na 16-latce
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-aktor-bartlomiej-m-skazany-za-gwalt-na-16-latce-st7970658?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-aktor-bartlomiej-m-skazany-za-gwalt-na-16-latce-st7970658?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T19:37:23+00:00

<img alt="Aktor Bartłomiej M. skazany za gwałt na 16-latce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9214905-aktor-bartlomiej-m-skazany-za-gwalt-na-16-latce-zdjecie-ilustracyjne-ph7970676/alternates/LANDSCAPE_1280" />
    Sąd Okręgowy w Warszawie wydał wyrok w sprawie aktora i byłego prezentera telewizyjnego - podało Radio Zet. Bartłomiej M. został skazany za gwałt na 16-latce. Wyrok jest prawomocny

## Autoagresja wśród dzieci i młodzieży. "Nawet dokumentów tak często nie nosiłam jak żyletki"
 - [https://fakty.tvn24.pl/zobacz-fakty/autoagresja-wsrod-dzieci-i-mlodziezy-nawet-dokumentow-tak-czesto-nie-nosilam-jak-zyletki-st7970514?source=rss](https://fakty.tvn24.pl/zobacz-fakty/autoagresja-wsrod-dzieci-i-mlodziezy-nawet-dokumentow-tak-czesto-nie-nosilam-jak-zyletki-st7970514?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T19:27:21+00:00

<img alt="Autoagresja wśród dzieci i młodzieży. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-9070175-otreba-ph7970632/alternates/LANDSCAPE_1280" />
    Blizny chowane pod długimi rękawami to ciche wołanie o pomoc. Dlatego właśnie wszystkich dookoła powinny postawić na równe nogi. Pani Agnieszka najgorsze ma już za sobą i teraz apeluje do innych - nie bądźcie obojętni. Apel jest jak najbardziej aktualny, bo okalecza się co szósty uczeń. Żeby im pomóc, wystarczy ich dostrzec.

## Dodatkowe tysiąc złotych do pensji. Jest decyzja
 - [https://tvn24.pl/biznes/z-kraju/100-zlotych-brutto-dla-pracownikow-pomocy-spolecznej-decyzja-rzadu-st7970656?source=rss](https://tvn24.pl/biznes/z-kraju/100-zlotych-brutto-dla-pracownikow-pomocy-spolecznej-decyzja-rzadu-st7970656?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T19:13:16+00:00

<img alt="Dodatkowe tysiąc złotych do pensji. Jest decyzja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1611718-shutterstock2228262653-ph7970687/alternates/LANDSCAPE_1280" />
    Tysiąc złotych brutto miesięcznie - tyle otrzymają pracownicy pomocy społecznej, pieczy zastępczej i opieki nad dziećmi do lat trzech od 1 lipca. Rada Ministrów przyjęła w środę uchwały w tej sprawie.

## "PiS liczył, że nigdy nie przegra i nigdy nikt nie sprawdzi, co oni robią"
 - [https://tvn24.pl/polska/afera-wokol-funduszu-sprawiedliwosci-sprawa-posla-marcina-romanowskiego-krzysztof-bosak-i-katarzyna-lubnauer-komentua-st7970605?source=rss](https://tvn24.pl/polska/afera-wokol-funduszu-sprawiedliwosci-sprawa-posla-marcina-romanowskiego-krzysztof-bosak-i-katarzyna-lubnauer-komentua-st7970605?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T19:07:05+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1453093-19-2000-kropka-gosc-0012-ph7970609/alternates/LANDSCAPE_1280" />
    Jeżeli słyszymy, że zarzuty dla posła Marcina Romanowskiego oznaczają zagrożenie wyrokiem do lat 15, to chyba nikt nie ma wątpliwości, że chodzi o naprawdę poważne przestępstwa - powiedziała w "Kropce nad i" wiceministra edukacji Katarzyna Lubnauer (KO). Komentując aferę wokół Funduszu Sprawiedliwości wicemarszałek Sejmu Krzysztof Bosak (Konfederacja) powiedział, że "nie zostały ujawnione wydatki z wszystkich funduszy rozdawniczych, które uruchomił PiS".

## "Babciowe" z wyrównaniem w ciągu trzech miesięcy
 - [https://tvn24.pl/biznes/najnowsze/babciowe-z-wyrownaniem-w-ciagu-trzech-miesiecy-st7970563?source=rss](https://tvn24.pl/biznes/najnowsze/babciowe-z-wyrownaniem-w-ciagu-trzech-miesiecy-st7970563?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T18:47:30+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2s3mfm-dzieci-dziecko-shutterstock_378882082-7409385/alternates/LANDSCAPE_1280" />
    Wnioski o pieniądze w ramach programu "Aktywny rodzic", potocznie nazywanym "babciowym", będzie można składać od 1 października. Rodzice, którzy zrobią to w ciągu trzech miesięcy od tej daty, otrzymają wyrównanie od 1 października - przekazało Ministerstwo Rodziny, Pracy i Polityki Społecznej.

## Porażka posła PiS. Województwo nadal bez marszałka
 - [https://tvn24.pl/krakow/krakow-lukasz-kmita-przegrywa-podczas-wyboru-marszalka-wojewodztwa-malopolskiego-st7970627?source=rss](https://tvn24.pl/krakow/krakow-lukasz-kmita-przegrywa-podczas-wyboru-marszalka-wojewodztwa-malopolskiego-st7970627?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T18:45:32+00:00

<img alt="Porażka posła PiS. Województwo nadal bez marszałka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2494128-posel-pis-lukasz-kmita-na-sesji-malopolskiego-sejmiku-ph7970623/alternates/LANDSCAPE_1280" />
    Po raz drugi małopolscy radni nie wybrali nowego marszałka województwa. Kandydatem był poseł Prawa i Sprawiedliwości Łukasz Kmita, były wojewoda.

## Ryzyko wielkiego exodusu milionerów
 - [https://tvn24.pl/biznes/ze-swiata/wielka-brytania-wybory-2024-ryzyko-wielkiego-exodusu-milionerow-po-reformie-podatkowej-st7970551?source=rss](https://tvn24.pl/biznes/ze-swiata/wielka-brytania-wybory-2024-ryzyko-wielkiego-exodusu-milionerow-po-reformie-podatkowej-st7970551?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T18:32:00+00:00

<img alt="Ryzyko wielkiego exodusu milionerów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-112ttw-londynskie-city-5606223/alternates/LANDSCAPE_1280" />
    W 2024 roku rekordowa liczba milionerów może opuścić Wielką Brytanię - piszą zagraniczne media. Do opuszczenia wysp krezusów miałaby "zmusić" przede wszystkim zapowiadana przez prowadzącą w sondażach Partię Pracy reforma podatkowa. Nadchodzące wyborcze rozstrzygnięcie może znacząco zmniejszyć atrakcyjność kraju, będącego niegdyś ziemią obiecaną dla najbogatszych.

## Kaczyński "wyssie z Suwerennej Polski to, co uzna za wartościowe"
 - [https://tvn24.pl/polska/afera-funduszu-sprawiedliwosci-krzysztof-kwiatkowski-i-ryszard-petru-komentuja-st7970540?source=rss](https://tvn24.pl/polska/afera-funduszu-sprawiedliwosci-krzysztof-kwiatkowski-i-ryszard-petru-komentuja-st7970540?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T18:20:44+00:00

<img alt="Kaczyński " src="https://tvn24.pl/najnowsze/cdn-zdjecie-967350-19-1925-fpf-gosc-0004-ph7970571/alternates/LANDSCAPE_1280" />
    Prezes PiS Jarosław Kaczyński będzie bronił polityków Suwerennej Polski jeszcze przez chwilę. Wyssie, co uzna za wartościowe. Na końcu w oślej ławce będzie chciał zostawić Ziobrę, Romanowskiego, Wosia - stwierdził w "Faktach po Faktach" senator KO Krzysztof Kwiatkowski. - Z Suwerennej Polski mało co zostanie, prawdopodobnie nic - ocenił Ryszard Petru z Polski 2050.

## Usłyszał zarzut zabójstwa, w areszcie spędził dwa miesiące. Lekarz z Gorzowa wrócił do pracy
 - [https://fakty.tvn24.pl/zobacz-fakty/uslyszal-zarzut-zabojstwa-w-areszcie-spedzil-dwa-miesiace-lekarz-z-gorzowa-wrocil-do-pracy-st7970473?source=rss](https://fakty.tvn24.pl/zobacz-fakty/uslyszal-zarzut-zabojstwa-w-areszcie-spedzil-dwa-miesiace-lekarz-z-gorzowa-wrocil-do-pracy-st7970473?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T17:47:02+00:00

<img alt="Usłyszał zarzut zabójstwa, w areszcie spędził dwa miesiące. Lekarz z Gorzowa wrócił do pracy" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-6015760-190619-nowicki-sr-001101-ph7970554/alternates/LANDSCAPE_1280" />
    Wstrząsająca historia lekarza z Gorzowa Wielkopolskiego. Wrócił do pracy w szpitalu, po tym jak wyszedł z aresztu. Po dwóch miesiącach za kratami okazało się, że areszt dla niego nie był zasadny. Dwa tysiące lekarzy z całej Polski napisało list, w którym podkreślają, że zasadny nie jest też zarzut zabójstwa. Doktor Kadukha odłączył terminalnie chorego pacjenta od aparatury podtrzymującej życie. Do prokuratury doniósł na niego kolega z tego samego szpitala.

## Szukali go 19 listami gończymi, w więzieniu spędzi 17 lat
 - [https://tvn24.pl/tvnwarszawa/okolice/szukali-go-19-listami-gonczymi-w-wiezieniu-spedzi-17-lat-st7970547?source=rss](https://tvn24.pl/tvnwarszawa/okolice/szukali-go-19-listami-gonczymi-w-wiezieniu-spedzi-17-lat-st7970547?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T17:34:09+00:00

<img alt="Szukali go 19 listami gończymi, w więzieniu spędzi 17 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b0f2es-czeska-policja-zdjecie-ilustracyjne-7832081/alternates/LANDSCAPE_1280" />
    56-latek poszukiwany 19 listami gończymi i dwoma europejskimi nakazami aresztowania został zatrzymamy w czeskich Pardubicach. Ma na koncie liczne oszustwa i przywłaszczenia, a w więzieniu spędzi co najmniej 17 lat.

## Przez cztery dni szukali 83-latki. Wypatrzył ją policyjny dron
 - [https://tvn24.pl/tvnwarszawa/najnowsze/gostynin-poszukiwania-seniorki-wypatrzyl-ja-policyjny-dron-lezala-w-mokradlach-st7970467?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/gostynin-poszukiwania-seniorki-wypatrzyl-ja-policyjny-dron-lezala-w-mokradlach-st7970467?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T17:22:57+00:00

<img alt="Przez cztery dni szukali 83-latki. Wypatrzył ją policyjny dron" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6536436-poszukiwania-zaginionej-seniorki-ph7970491/alternates/LANDSCAPE_1280" />
    Szczęśliwym finałem zakończyły się czterodniowe poszukiwania 83-latki z gminy Gostynin. W akcję zaangażowali się policjanci i pies tropiący. W odnalezieniu seniorki pomógł też dron. - Kobieta leżała w tak wysokich i gęstych zaroślach, że stojące kilka metrów od niej osoby nie były w stanie jej dostrzec - opisała policja.

## Pogoda na jutro - czwartek 20.06. W nocy pożegnamy burze i przywitamy pogodne niebo
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-czwartek-2006-w-nocy-pozegnamy-burze-i-przywitamy-pogodne-niebo-st7970104?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-czwartek-2006-w-nocy-pozegnamy-burze-i-przywitamy-pogodne-niebo-st7970104?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T17:15:13+00:00

<img alt="Pogoda na jutro - czwartek 20.06. W nocy pożegnamy burze i przywitamy pogodne niebo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3278999-noc-z-przejasnieniami-ph7970529/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na czwartek 20.06. W nocy niebo nad Polską będzie powoli się rozpogadzać, a strefa burz i opadów odsunie się poza granice naszego kraju. W dzień zapanuje pogodna, miejscami słoneczna aura, a na termometrach zobaczymy do 24 stopni Celsjusza.

## Postulaty artystów przechodzą dalej. Zmiany w prawie autorskim na kolejnym etapie prac
 - [https://tvn24.pl/biznes/z-kraju/tandiemy-i-godziwe-wynagrodzenie-dla-tworcow-postulat-przyjety-przez-komisje-sejmowa-st7970469?source=rss](https://tvn24.pl/biznes/z-kraju/tandiemy-i-godziwe-wynagrodzenie-dla-tworcow-postulat-przyjety-przez-komisje-sejmowa-st7970469?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T17:07:48+00:00

<img alt="Postulaty artystów przechodzą dalej. Zmiany w prawie autorskim na kolejnym etapie prac" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kzx8tu-game-developer-tworca-praca-biuro-komputer-shutterstock_718743151_1-7320476/alternates/LANDSCAPE_1280" />
    Trwają prace nad zmianami w prawie autorskim. Nad projektem nowelizacji obradowała dziś komisja sejmowa. Przyjęto na niej poprawki dotyczące prawa do odpowiedniego i godziwego wynagrodzenia oraz do tantiem z tytułu reemitowania utworu, o które ubiegali się sami artyści. Projekt został skierowany do drugiego czytania.

## "Za te wszystkie przestępstwa grozi kara pozbawienia wolności do 15 lat"
 - [https://tvn24.pl/polska/uchylenie-immunitetu-posla-marcina-romanowskiego-prokurator-krajowy-dariusz-korneluk-komentuje-st7970390?source=rss](https://tvn24.pl/polska/uchylenie-immunitetu-posla-marcina-romanowskiego-prokurator-krajowy-dariusz-korneluk-komentuje-st7970390?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T16:48:19+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1579227-19-1800-tak-jest-gosc-0007-ph7970421/alternates/LANDSCAPE_1280" />
    Zarzuty wobec posła Marcina Romanowskiego dotyczą przede wszystkim działania w ramach zorganizowanej grupy, mającej na celu popełnianie przestępstw przez ustalone osoby. To także zarzuty przekroczenia uprawnień i niedopełnienia obowiązków związane z gospodarowaniem mieniem publicznym - mówił w TVN24 zastępca prokuratora generalnego, prokurator krajowy Dariusz Korneluk. Jak dodał, politykowi Suwerennej Polski grozi kara pozbawienia wolności do 15 lat.

## Zatrzasnął auto, w którym było małe dziecko
 - [https://tvn24.pl/lublin/swidnik-zatrzasnal-auto-w-ktorym-bylo-male-dziecko-strazacy-wybili-szybe-st7970431?source=rss](https://tvn24.pl/lublin/swidnik-zatrzasnal-auto-w-ktorym-bylo-male-dziecko-strazacy-wybili-szybe-st7970431?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T16:41:22+00:00

<img alt="Zatrzasnął auto, w którym było małe dziecko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6014833-udalo-sie-wydostac-dziecko-ze-srodka-ph7970409/alternates/LANDSCAPE_1280" />
    Trzeba było działać bardzo szybko. W aucie stojącym przy jednej z ulic w Świdniku (woj. lubelskie) zostało zatrzaśnięte dziewięciomiesięczne dziecko. Kluczyki były w środku.

## Elektryki prześcigną auta spalinowe. W kolejnej dekadzie ma być ich dwukrotnie więcej
 - [https://tvn24.pl/biznes/moto/samochody-elektryczne-w-europie-do-2030-roku-bedzie-ich-75-milionow-raport-ey-st7970335?source=rss](https://tvn24.pl/biznes/moto/samochody-elektryczne-w-europie-do-2030-roku-bedzie-ich-75-milionow-raport-ey-st7970335?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T16:34:59+00:00

<img alt="Elektryki prześcigną auta spalinowe. W kolejnej dekadzie ma być ich dwukrotnie więcej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7740106-shutterstock2357402785-ph7970360/alternates/LANDSCAPE_1280" />
    Europejczycy do 2030 roku będą jeździć 75 milionami samochodów elektrycznych - prognozują analitycy z EY i Eurelectric. To więcej, niż zakładała prognoza. Z kolei ładowarek elektrycznych na starym kontynencie mamy obecnie blisko około 750 tysięcy.

## Użycie broni "w szczególnych sytuacjach". Jest decyzja w sprawie projektu
 - [https://tvn24.pl/polska/uzycie-broni-w-szczegolnych-sytuacjach-rzad-przyjal-projekt-st7970425?source=rss](https://tvn24.pl/polska/uzycie-broni-w-szczegolnych-sytuacjach-rzad-przyjal-projekt-st7970425?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T16:26:40+00:00

<img alt="Użycie broni " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qtxv0o-strefa-buforowa-przy-granicy-z-bialorusia-ph7948669/alternates/LANDSCAPE_1280" />
    Rząd podczas środowego posiedzenia przyjął projekt ustawy wspierającej działania wojska, policji i Straży Granicznej. Dokument reguluje między innymi "kwestię użycia broni w szczególnych sytuacjach".

## Z rzeki wyłowili ciało chłopca
 - [https://tvn24.pl/krakow/broszkowice-z-rzeki-wylowili-cialo-chlopca-st7970445?source=rss](https://tvn24.pl/krakow/broszkowice-z-rzeki-wylowili-cialo-chlopca-st7970445?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T16:24:10+00:00

<img alt="Z rzeki wyłowili ciało chłopca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-71vtwo-22-latek-zmarl-w-trakcie-pracy-zdjecie-ilustracyjne-ph7959097/alternates/LANDSCAPE_1280" />
    14-latek od dwóch dni był poszukiwany. Ciało chłopca ratownicy wyłowili z rzeki Soły w Broszkowicach w gminie Oświęcim. Śledczy ustalają dokładne okoliczności zdarzenia.

## ABW w siedzibie Orlenu. "Podejrzenie zaniżania cen paliw"
 - [https://tvn24.pl/polska/abw-znow-w-siedzibie-orlenu-chodzi-o-sledztwo-dotyczace-zanizania-cen-paliw-st7970374?source=rss](https://tvn24.pl/polska/abw-znow-w-siedzibie-orlenu-chodzi-o-sledztwo-dotyczace-zanizania-cen-paliw-st7970374?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T16:16:50+00:00

<img alt="ABW w siedzibie Orlenu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kk746f-orlen-shutterstock_2152259391-7929530/alternates/LANDSCAPE_1280" />
    Agencja Bezpieczeństwa Wewnętrznego weszła w środę do siedziby Orlenu w Płocku. Jak poinformowała Prokuratura Krajowa, czynności funkcjonariuszy miały związek ze śledztwem dotyczącym podejrzenia zaniżania cen paliw przez koncern.

## Płonął budynek, w którym mieszkają obcokrajowcy
 - [https://tvn24.pl/lubuskie/trzebiechow-plonal-budynek-w-ktorym-mieszkaja-obcokrajowcy-st7970437?source=rss](https://tvn24.pl/lubuskie/trzebiechow-plonal-budynek-w-ktorym-mieszkaja-obcokrajowcy-st7970437?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T16:14:45+00:00

<img alt="Płonął budynek, w którym mieszkają obcokrajowcy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1442080-pozar-budynku-pod-sulechowem-ph7970414/alternates/LANDSCAPE_1280" />
    Smugę dymu było widać z odległości wielu kilometrów. Płonął budynek, w którym mieszkają obcokrajowcy. Wszyscy zdołali wyjść przed przyjazdem strażaków.

## Popiół spadał jak śnieg. "Nie wiem, czy jeszcze mamy dom"
 - [https://tvn24.pl/tvnmeteo/swiat/popiol-spadal-jak-snieg-nie-wiem-czy-jeszcze-mamy-dom-st7970332?source=rss](https://tvn24.pl/tvnmeteo/swiat/popiol-spadal-jak-snieg-nie-wiem-czy-jeszcze-mamy-dom-st7970332?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T15:53:57+00:00

<img alt="Popiół spadał jak śnieg. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2426957-pozary-w-nowym-meksyku-ph7970384/alternates/LANDSCAPE_1280" />
    Pożary szaleją w amerykańskim stanie Nowy Meksyk. W środę lokalne władze poinformowały, że ogień przyczynił się do śmierci co najmniej jednej osoby. Płomienie strawiły do tej pory obszar o powierzchni przekraczającej osiem tysięcy hektarów i wciąż nie zostały opanowane.

## "Zjedzony przez krowę" cenny zegarek odnaleziony po 50 latach
 - [https://tvn24.pl/swiat/wielka-brytania-zjedzony-przez-krowe-cenny-zegarek-odnaleziony-po-50-latach-st7970207?source=rss](https://tvn24.pl/swiat/wielka-brytania-zjedzony-przez-krowe-cenny-zegarek-odnaleziony-po-50-latach-st7970207?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T15:38:11+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8785497-shutterstock2223768277-ph7970372/alternates/LANDSCAPE_1280" />
    Rolnik z Wielkiej Brytanii opowiedział mediom, jak po pół wieku odzyskał swój zegarek znanej luksusowej marki, o którym myślał, że został zjedzony przez krowę. - Nie myślałem, że kiedykolwiek jeszcze go zobaczę - mówi James Steel w rozmowie z BBC.

## Duże zmiany w finansach publicznych. Jest decyzja
 - [https://tvn24.pl/biznes/z-kraju/nowelizacja-ustawy-o-finansach-publicznych-90-jednostek-sektora-finansow-publicznych-w-tym-zus-i-ncbir-objetych-regula-wydatkowa-st7970359?source=rss](https://tvn24.pl/biznes/z-kraju/nowelizacja-ustawy-o-finansach-publicznych-90-jednostek-sektora-finansow-publicznych-w-tym-zus-i-ncbir-objetych-regula-wydatkowa-st7970359?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T15:31:03+00:00

<img alt="Duże zmiany w finansach publicznych. Jest decyzja" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-u36dzw-posiedzenie-rzadu-28-maja-7937931/alternates/LANDSCAPE_1280" />
    Rząd przyjął w środę projekt nowelizacji ustawy o finansach publicznych. Głównym celem projektowanej ustawy są zmiany w stabilizującej regule wydatkowej. Obejmie ona około 90 nowych jednostek sektora finansów publicznych, w tym ZUS i NCBR.

## Decyzja prokuratury w sprawie żołnierzy zatrzymanych po strzałach na granicy
 - [https://tvn24.pl/bialystok/dubicze-cerkiewne-zolnierze-zatrzymani-po-strzalach-na-granicy-nie-sa-juz-zawieszeni-w-czynnosciach-sluzbowych-st7970323?source=rss](https://tvn24.pl/bialystok/dubicze-cerkiewne-zolnierze-zatrzymani-po-strzalach-na-granicy-nie-sa-juz-zawieszeni-w-czynnosciach-sluzbowych-st7970323?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T15:26:50+00:00

<img alt="Decyzja prokuratury w sprawie żołnierzy zatrzymanych po strzałach na granicy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3531581-zarzuty-wobec-zolnierzy-sie-nie-zmienily-chodzi-o-przekroczenie-uprawnien-na-granicy-z-bialorusia-zdjecie-ilustracyjne-ph7970355/alternates/LANDSCAPE_1280" />
    Prokuratura uchyliła część środków zapobiegawczych wobec dwóch żołnierzy, którzy usłyszeli zarzuty przekroczenia uprawnień po strzałach oddanych w okolicach Dubicz Cerkiewnych (Podlasie) na granicy z Białorusią.

## Andrzej Halicki wiceszefem największej frakcji w europarlamencie
 - [https://tvn24.pl/polska/andrzej-halicki-wiceprzewodniczacym-europejskiej-partii-ludowej-st7970316?source=rss](https://tvn24.pl/polska/andrzej-halicki-wiceprzewodniczacym-europejskiej-partii-ludowej-st7970316?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T15:03:05+00:00

<img alt="Andrzej Halicki wiceszefem największej frakcji w europarlamencie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2633684-andrzej-halicki-ph7970308/alternates/LANDSCAPE_1280" />
    Europoseł Koalicji Obywatelskiej Andrzej Halicki został w środę wybrany jednym z wiceprzewodniczących Europejskiej Partii Ludowej. To największa frakcja w europarlamencie. "Rośnie znaczenie Polski w największej grupie politycznej w PE" - skomentowała eurodeputowana KO Kamila Gasiuk-Pihowicz.

## Chirurg plastyczny podejrzany o spowodowanie śmierci żony, którą operował
 - [https://tvn24.pl/swiat/usa-chirurg-plastyczny-oskarzony-o-nieumyslne-spowodowanie-smierci-operowanej-przez-siebie-zony-st7969479?source=rss](https://tvn24.pl/swiat/usa-chirurg-plastyczny-oskarzony-o-nieumyslne-spowodowanie-smierci-operowanej-przez-siebie-zony-st7969479?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T14:51:18+00:00

<img alt="Chirurg plastyczny podejrzany o spowodowanie śmierci żony, którą operował" src="https://tvn24.pl/najnowsze/cdn-zdjecie-887974-operacja-plastyczna-ph7969734/alternates/LANDSCAPE_1280" />
    Chirurg plastyczny z Florydy jest podejrzany o nieumyślne spowodowanie śmierci swojej żony podczas zabiegu. Jak podają amerykańskie media, lekarz nie przyznaje się do winy. Choć poczatkowo został zatrzymany, wyszedł już z aresztu po wpłaceniu kaucji.

## "Prowadzone są czynności sprawdzające". Dwa postępowania wobec Małgorzaty Manowskiej
 - [https://tvn24.pl/polska/malgorzata-manowska-pierwsza-prezes-sadu-najwyzszego-z-dwoma-postepowaniami-sprawdzajacymi-w-prokuraturze-st7970233?source=rss](https://tvn24.pl/polska/malgorzata-manowska-pierwsza-prezes-sadu-najwyzszego-z-dwoma-postepowaniami-sprawdzajacymi-w-prokuraturze-st7970233?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T14:36:44+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-6348284-malgorzata-manowska-pierwsza-prezes-sn-ph7964563/alternates/LANDSCAPE_1280" />
    Rzecznik Prokuratury Krajowej Przemysław Nowak przekazał, że wobec pierwszej prezes Sądu Najwyższego Małgorzaty Manowskiej prowadzone są dwa postępowania sprawdzające. Jedna sprawa dotyczy niezwoływania posiedzeń Trybunału Stanu, którego Manowska jest przewodniczącą, druga przekroczenia uprawnień w pracach Kolegium Sądu Najwyższego.

## Niższe ceny paliw na wakacje
 - [https://tvn24.pl/biznes/najnowsze/ceny-paliw-na-wakacje-w-2024-ile-kosztuje-benzyna-olej-napedowy-i-autogaz-analiza-e-petrol-st7970254?source=rss](https://tvn24.pl/biznes/najnowsze/ceny-paliw-na-wakacje-w-2024-ile-kosztuje-benzyna-olej-napedowy-i-autogaz-analiza-e-petrol-st7970254?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T14:36:03+00:00

<img alt="Niższe ceny paliw na wakacje" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie0233066a245a3752cc8386df6073926d-jak-ubezpieczyc-samochod-przed-wyjazdem-za-granice-4885339/alternates/LANDSCAPE_1280" />
    Cena benzyny PB95, oleju napędowego i gazu spadają, co jest dobrą wiadomością dla osób wybierających się autem w najbliższych dniach na wakacyjne wyjazdy. Według analityków e-petrol największa przecena dotyczy w tym tygodniu oleju napędowego, który, w porównaniu do wyników ostatniego notowania, jest tańszy o 6 gr.

## "Rowerzysta wjechał wprost pod jadącą ciężarówkę wojskową"
 - [https://tvn24.pl/trojmiasto/slupsk-rowerzysta-wjechal-wprost-pod-jadaca-ciezarowke-wojskowa-st7970305?source=rss](https://tvn24.pl/trojmiasto/slupsk-rowerzysta-wjechal-wprost-pod-jadaca-ciezarowke-wojskowa-st7970305?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T14:23:47+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8492661-potracenie-rowerzysty-przez-wojskowa-ciezarowke-w-slupsku-ph7970295/alternates/LANDSCAPE_1280" />
    Do wypadku doszło w Słupsku. Według ustaleń policji, rowerzysta wjechał wprost pod jadącą ciężarówkę wojskową. Trafił do szpitala.

## Szymon Hołownia w Kijowie. Spotkał się z Zełenskim, wygłosił przemówienie w Radzie Najwyższej
 - [https://tvn24.pl/swiat/szymon-holownia-w-kijowie-spotkal-sie-z-zelenskim-wyglosil-przemowienie-w-radzie-najwyzszej-st7970236?source=rss](https://tvn24.pl/swiat/szymon-holownia-w-kijowie-spotkal-sie-z-zelenskim-wyglosil-przemowienie-w-radzie-najwyzszej-st7970236?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T14:20:47+00:00

<img alt="Szymon Hołownia w Kijowie. Spotkał się z Zełenskim, wygłosił przemówienie w Radzie Najwyższej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5222658-szymon-holownia-wyglosil-przemowienie-w-ukrainskim-parlamencie-ph7970221/alternates/LANDSCAPE_1280" />
    Marszałek Sejmu Szymon Hołownia, który przebywa z wizytą w Kijowie, spotkał się w środę z prezydentem Ukrainy Wołodymyrem Zełenskim. Jak przekazał ukraiński przywódca, rozmawiali m.in. o sytuacji na froncie oraz współpracy na rzecz ochrony ukraińskiego nieba. Wcześniej tego dnia Hołownia wygłosił przemówienie w ukraińskim parlamencie. - Polska nie godzi się, by opresyjny reżim rosyjski mordował ukraińskiego ducha – oświadczył marszałek Sejmu.

## Pogoda na 5 dni. Polska stanie się "areną pogodowych starć"
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-5-dni-polska-stanie-sie-arena-pogodowych-starc-st7970237?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-5-dni-polska-stanie-sie-arena-pogodowych-starc-st7970237?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T14:10:18+00:00

<img alt="Pogoda na 5 dni. Polska stanie się " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1094750-burzowo-vent-ph7970284/alternates/LANDSCAPE_1280" />
    Kolejne dni przyniosą nam sporo zmian w pogodzie. Naprzemienny napływ ciepłego powietrza z Afryki i chłodniejszych mas polarnych spowoduje, że czekają nas zarówno bezchmurne, słoneczne dni, jak i gwałtowne zjawiska atmosferyczne. Na termometrach wkrótce znów zobaczymy ponad 30 stopni Celsjusza.

## Nawet 2 tysiące miesięcznie. Na jakie stypendia może liczyć rozpoczynający studia na polskich uczelniach
 - [https://tvn24.pl/polska/stypendia-dla-studentow-rozpoczynajacych-nauke-na-polskich-uczelniach-st7968104?source=rss](https://tvn24.pl/polska/stypendia-dla-studentow-rozpoczynajacych-nauke-na-polskich-uczelniach-st7968104?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T14:09:26+00:00

<img alt="Nawet 2 tysiące miesięcznie. Na jakie stypendia może liczyć rozpoczynający studia na polskich uczelniach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bx7cy6-studenci-shutterstock_2200888005-7891807/alternates/LANDSCAPE_1280" />
    Stypendium dla każdego, kto rozpocznie studia na nowo utworzonym kierunku, ale też dla przyszłych żołnierzy, laureatów olimpiad, wyróżniających się sportowców i nie tylko. Na jaką pomoc mogą liczyć absolwenci szkół średnich, którzy planują rozpoczęcie studiów w tym roku?

## Przyjechał zawiadomić o stłuczce, był pijany. "Jego wizyta nieco się przedłużyła"
 - [https://tvn24.pl/lublin/lublin-przyjechal-zawiadomic-policje-o-stluczce-byl-pijany-odpowie-za-kierowanie-w-stanie-nietrzezwosci-st7970241?source=rss](https://tvn24.pl/lublin/lublin-przyjechal-zawiadomic-policje-o-stluczce-byl-pijany-odpowie-za-kierowanie-w-stanie-nietrzezwosci-st7970241?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T14:07:43+00:00

<img alt="Przyjechał zawiadomić o stłuczce, był pijany. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8908746-przyjechal-pijany-na-komende-ph7970248/alternates/LANDSCAPE_1280" />
    21-latek chciał złożyć w komendzie policji w Lublinie zawiadomienie o tym, że ktoś uszkodził mu samochód, którym przyjechał. Pracownik biura obsługi wyczuł jednak od niego silną woń alkoholu. Mężczyzna tego dnia nie złożył zawiadomienia o stłuczce. Będzie za to odpowiadał za kierowanie w stanie nietrzeźwości.

## Dwie komisje zbadają skandale z udziałem duchownych. Na czele jednej prokurator
 - [https://tvn24.pl/katowice/diecezja-sosnowiecka-dwie-komisje-zbadaja-skandale-z-udzialem-duchownych-na-czele-jednej-byla-prokurator-st7970286?source=rss](https://tvn24.pl/katowice/diecezja-sosnowiecka-dwie-komisje-zbadaja-skandale-z-udzialem-duchownych-na-czele-jednej-byla-prokurator-st7970286?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T14:03:12+00:00

<img alt="Dwie komisje zbadają skandale z udziałem duchownych. Na czele jednej prokurator" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8156036-wazny-ph7970272/alternates/LANDSCAPE_1280" />
    Powstaną dwie komisje do spraw wyjaśnienia skandali z udziałem duchownych w diecezji sosnowieckiej. Jedną z nich kierować będzie prokurator w stanie spoczynku, a w ich skład wejdą między innymi prawnik, historyk i psycholog. - Zostanie też przeprowadzony audyt - zapowiedział biskup sosnowiecki Artur Ważny.

## Europejska mapa dobrobytu. Tak wypadła Polska
 - [https://tvn24.pl/biznes/z-kraju/rzeczywiste-spozycie-indywidualne-w-unii-europejskiej-polska-ponizej-sredniej-st7970240?source=rss](https://tvn24.pl/biznes/z-kraju/rzeczywiste-spozycie-indywidualne-w-unii-europejskiej-polska-ponizej-sredniej-st7970240?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:54:57+00:00

<img alt="Europejska mapa dobrobytu. Tak wypadła Polska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5842606-sklejka-ludzie-ph7970291/alternates/LANDSCAPE_1280" />
    Polacy konsumują mniej niż przeciętny mieszaniec Unii Europejskiej. Rzeczywiste spożycie indywidualne (AIC) na mieszkańca w Polsce w 2023 roku było 14 procent poniżej średniej unijnej- podał Eurostat. Najwyższy poziom odnotowano w Luksemburgu (38 proc. powyżej średniej UE), Austrii i Holandii (po 17 proc.).

## "Powódź" w miejskim autobusie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-woda-w-autobusie-linii-519-zostal-zalany-kiedy-jechal-przyczolkowa-st7970205?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-woda-w-autobusie-linii-519-zostal-zalany-kiedy-jechal-przyczolkowa-st7970205?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:47:16+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3648534-powodz-w-autobusie-linii-519-ph7970209/alternates/LANDSCAPE_1280" />
    Woda z zalanej po burzy ulicy Przyczółkowej wdarła się do autobusu miejskiego linii 519, jadącego z Powsina do centrum Warszawy. Nagranie dostaliśmy na Kontakt 24.

## Tak się zdenerwował na sąsiada, że podpalił mu wychodek
 - [https://tvn24.pl/lublin/gmina-horodlo-zdenerwowal-na-sasiada-podpalil-mu-wychodek-ogien-strawil-tez-szope-st7970186?source=rss](https://tvn24.pl/lublin/gmina-horodlo-zdenerwowal-na-sasiada-podpalil-mu-wychodek-ogien-strawil-tez-szope-st7970186?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:41:03+00:00

<img alt="Tak się zdenerwował na sąsiada, że podpalił mu wychodek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7440102-ogien-strawil-wychodek-i-szope-ph7970192/alternates/LANDSCAPE_1280" />
    Do pięciu lat pozbawienia wolności grozi 24-latkowi z gminy Horodło (Lubelskie), który podpalił swojemu 57-letniemu sąsiadowi wychodek. Ogień strawił też stojącą obok szopę, w której znajdowały się rower, kosa spalinowa i drewno na opał. Mężczyzna tłumaczył, że znajomy go zdenerwował.

## "Wnuczek" przysłał "asystenta prokuratura". Starsza pani nie dała się nabrać
 - [https://tvn24.pl/olsztyn/oszustwo-wnuczek-przyslal-asystenta-prokuratura-ale-starsza-pani-nie-dala-sie-nabrac-st7969646?source=rss](https://tvn24.pl/olsztyn/oszustwo-wnuczek-przyslal-asystenta-prokuratura-ale-starsza-pani-nie-dala-sie-nabrac-st7969646?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:30:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2atff1-kobieta-padla-ofiara-oszustwa-na-policjanta-5788464/alternates/LANDSCAPE_1280" />
    87-letnia mieszkanka Nowego Miasta Lubawskiego odebrała od "wnuczka" z prośbą o pomoc. Nie dała się oszukać nawet, gdy jej zapukał "asystent prokuratura". Nie wpuściła go, a wtedy znowu zadzwonił "wnuczek", próbując wzbudzić wyrzuty sumienia, sugerując, że babcia nie chce mu pomóc. Ta się jednak nie ugięła i wezwała policję.

## Wypadek na torze. Nie żyje dziewięcioletni motocyklista
 - [https://tvn24.pl/swiat/brazylia-wypadek-na-torze-nie-zyje-dziewiecioletni-motocyklista-z-argentyny-st7970017?source=rss](https://tvn24.pl/swiat/brazylia-wypadek-na-torze-nie-zyje-dziewiecioletni-motocyklista-z-argentyny-st7970017?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:24:38+00:00

<img alt="Wypadek na torze. Nie żyje dziewięcioletni motocyklista" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9828384-tor-interlagos-w-sao-paulo-ph7970085/alternates/LANDSCAPE_1280" />
    Dziewięcioletni Lorenzo Somaschini zmarł kilka dni po wypadku na torze w Brazylii. Informację o śmierci dziecka przekazał organizator wyścigów motocyklowych.

## Daniel Obajtek stawił się w warszawskiej prokuraturze
 - [https://tvn24.pl/polska/daniel-obajtek-stawil-sie-w-warszawskiej-prokuraturze-st7970177?source=rss](https://tvn24.pl/polska/daniel-obajtek-stawil-sie-w-warszawskiej-prokuraturze-st7970177?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:16:26+00:00

<img alt="Daniel Obajtek stawił się w warszawskiej prokuraturze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2524769-pap202304270na-ph7952351/alternates/LANDSCAPE_1280" />
    Były prezes Orlenu Daniel Obajtek, który zdobył mandat do europarlamentu, stawił się w środę w Prokuraturze Okręgowej w Warszawie i został przesłuchany w charakterze świadka - przekazał rzecznik Prokuratury Okręgowej w Warszawie Piotr Skiba.

## Skusiło ich pamiątkowe selfie ze znakiem granicznym. Polka i Niemiec ukarani mandatami
 - [https://tvn24.pl/rzeszow/wojtkowa-skusilo-ich-pamiatkowe-selfie-polka-i-niemiec-ukarani-mandatami-st7969929?source=rss](https://tvn24.pl/rzeszow/wojtkowa-skusilo-ich-pamiatkowe-selfie-polka-i-niemiec-ukarani-mandatami-st7969929?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:15:00+00:00

<img alt="Skusiło ich pamiątkowe selfie ze znakiem granicznym. Polka i Niemiec ukarani mandatami " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9761713-500-zl-mandatu-za-zdjecie-ze-znakiem-granicznym-ph7969930/alternates/LANDSCAPE_1280" />
    Po 500 złotych mandatu zapłacą Polka i Niemiec zatrzymani przez strażników granicznych z placówki w Wojtkowej (Podkarpackie). Turyści, skuszeni pamiątkowym "selfie" ze znakiem granicznym, weszli na pas drogi granicznej. Zbliża się sezon turystyczny - Straż Graniczna przypomina zasady przebywania w rejonie przygranicznym.

## Bójka nastolatków przy szkole, lądował śmigłowiec LPR
 - [https://tvn24.pl/katowice/jastrzebie-zdroj-bojka-nastolatkow-smiglowiec-zabral-jednego-nich-do-szpitala-st7970082?source=rss](https://tvn24.pl/katowice/jastrzebie-zdroj-bojka-nastolatkow-smiglowiec-zabral-jednego-nich-do-szpitala-st7970082?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:10:00+00:00

<img alt="Bójka nastolatków przy szkole, lądował śmigłowiec LPR " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xllpdi-smiglowiec-lpr-zdjecie-ilustracyjne-ph7304761/alternates/LANDSCAPE_1280" />
    Obok jednej ze szkół w Jastrzębiu-Zdroju (Śląskie) lądował śmigłowiec Lotniczego Pogotowia Ratunkowego. Jak informuje policja, dwóch nastolatków miało się tam pokłócić i pobić. Jeden z nich trafił do szpitala.

## Afrykański tydzień. Europa w odcieniach czerwieni i pomarańczy
 - [https://tvn24.pl/tvnmeteo/swiat/afrykanski-tydzien-europa-w-odcieniach-czerwieni-i-pomaranczy-st7969779?source=rss](https://tvn24.pl/tvnmeteo/swiat/afrykanski-tydzien-europa-w-odcieniach-czerwieni-i-pomaranczy-st7969779?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:08:42+00:00

<img alt="Afrykański tydzień. Europa w odcieniach czerwieni i pomarańczy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-7476537-upal-ph7969935/alternates/LANDSCAPE_1280" />
    Nad Bałkany nadeszła pierwsza w tym roku fala upałów. Temperatura odczuwalna może osiągać miejscami nawet ponad 40 stopni. Przed spiekotą ostrzegają służby meteorologiczne. Afrykański żar dotarł też do Węgier.

## Z kościoła skradziono relikwie bł. ks. Jerzego Popiełuszki. Małżeństwo z zarzutami
 - [https://tvn24.pl/bialystok/gmina-turosn-koscielna-ktos-ukradl-relikwie-bl-ks-jerzego-popieluszki-policja-zatrzymala-malzenstwo-st7970102?source=rss](https://tvn24.pl/bialystok/gmina-turosn-koscielna-ktos-ukradl-relikwie-bl-ks-jerzego-popieluszki-policja-zatrzymala-malzenstwo-st7970102?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T13:03:53+00:00

<img alt="Z kościoła skradziono relikwie bł. ks. Jerzego Popiełuszki. Małżeństwo z zarzutami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1425455-relikwiarz-wart-jest-dwa-tysiace-zlotych-ph7970127/alternates/LANDSCAPE_1280" />
    Z jednej ze świątyń w gminie Turośń Kościelna (woj. podlaskie) zniknął relikwiarz zawierający relikwie błogosławionego księdza Jerzego Popiełuszki. Policja zatrzymała  małżeństwo, które usłyszało zarzuty kradzieży. Odzyskany został też relikwiarz.

## Prezes CPK: projektowanie lotniska zrealizowane w połowie. Spółce brakuje pieniędzy na więcej
 - [https://tvn24.pl/biznes/najnowsze/centralny-port-komunikacyjny-ma-pieniadze-na-projekt-lotniska-po-dalsza-czesc-finansowania-musi-siegnac-do-kieszeni-skarbu-panstwa-st7970036?source=rss](https://tvn24.pl/biznes/najnowsze/centralny-port-komunikacyjny-ma-pieniadze-na-projekt-lotniska-po-dalsza-czesc-finansowania-musi-siegnac-do-kieszeni-skarbu-panstwa-st7970036?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:49:20+00:00

<img alt="Prezes CPK: projektowanie lotniska zrealizowane w połowie. Spółce brakuje pieniędzy na więcej" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fchaqs-centralny-port-komunikacyjny-wizualizacje-7796186/alternates/LANDSCAPE_1280" />
    Projektowanie lotniska w ramach Centralnego Portu Komunikacyjnego jest zrealizowane w 50 procentach - poinformował w środę prezes spółki Filip Czernicki. Dodał, że "prace projektowe przez cały czas trwają, a spółka ma środki na to, aby płacić projektantom, natomiast nie ma zapewnionego finansowania na dalsze etapy tej inwestycji".

## Przenoszą dengę, są już w 13 krajach Europy. Jak się chronić przed komarem tygrysim?
 - [https://tvn24.pl/tvnmeteo/swiat/roznoszace-denge-komary-tygrysie-w-popularnych-kierunkach-wakacyjnych-jak-zapobiegac-ukaszeniu-st7969994?source=rss](https://tvn24.pl/tvnmeteo/swiat/roznoszace-denge-komary-tygrysie-w-popularnych-kierunkach-wakacyjnych-jak-zapobiegac-ukaszeniu-st7969994?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:39:57+00:00

<img alt="Przenoszą dengę, są już w 13 krajach Europy. Jak się chronić przed komarem tygrysim? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ocnpnb-komar-egipski-aedes-aegypti-7082424/alternates/LANDSCAPE_1280" />
    Występowanie przenoszących dengę komarów tygrysich stwierdzono już w 13 państwach UE, w tym w kilku popularnych destynacjach wakacyjnych. Zaobserwowano je m.in. w Chorwacji, Grecji, Włoszech czy Hiszpanii. Co należy o nich wiedzieć? Jak chronić się przed roznoszoną przez nie chorobą? Wyjaśniamy.

## Zabraknie na podniesienie kwoty wolnej? Analitycy o rachunku za nadmierny deficyt
 - [https://tvn24.pl/biznes/z-kraju/zabraknie-na-podniesienie-kwoty-wolnej-analitycy-o-rachunku-za-nadmierny-deficyt-st7969954?source=rss](https://tvn24.pl/biznes/z-kraju/zabraknie-na-podniesienie-kwoty-wolnej-analitycy-o-rachunku-za-nadmierny-deficyt-st7969954?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:35:31+00:00

<img alt="Zabraknie na podniesienie kwoty wolnej? Analitycy o rachunku za nadmierny deficyt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-248x18-ulica-ludzie-polska-shutterstock_2170212189-7892838/alternates/LANDSCAPE_1280" />
    Uruchomienie procedury nadmiernego deficytu wobec Polski oznacza, że nie ma miejsca na duże nowe wydatki, jak np. podniesienie kwoty wolnej - oceniają ekonomiści ING. Większość analityków uważa, że procedura nie będzie się jednak wiązała z koniecznością szybkiego i głębokiego skorygowania wydatków. Z kolei Sławomir Dudek stwierdził we wpisie na X "ta procedura to ocena 'osiągnięć' rządu premiera Mateusza Morawieckiego".

## Szereg uchybień przy inwestycji Orlenu. "Będziemy działać stanowczo"
 - [https://tvn24.pl/polska/olefiny-iii-kontrole-pip-na-inwestycji-orlenu-wykazaly-szereg-nieprawidlowosci-st7969967?source=rss](https://tvn24.pl/polska/olefiny-iii-kontrole-pip-na-inwestycji-orlenu-wykazaly-szereg-nieprawidlowosci-st7969967?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:20:38+00:00

<img alt="Szereg uchybień przy inwestycji Orlenu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1cyuk4-wyzysk-cudzoziemcow-przy-inwestycji-orlenu-material-uwagi-tvn-7905269/alternates/LANDSCAPE_1280" />
    Państwowa Inspekcja Pracy wykryła "liczne przypadki naruszeń przepisów BHP" na budowie kompleksu Olefiny III pod Płockiem, realizowanej przez Orlen. Inspektorzy zakończyli dziewięć z trzynastu swoich kontroli, wciąż badają jednak legalność zatrudnienia cudzoziemców. - W przypadku stwierdzenia nieprawidłowości będziemy działać stanowczo - podkreślił główny inspektor pracy Marcin Stanecki.

## Wniosek policji o wszczęcie śledztwa w kierunku nadużycia władzy przez Jarosława Kaczyńskiego
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-jest-wniosek-o-wszczecie-sledztwa-w-kierunku-naduzycia-wladzy-przez-jaroslawa-kaczynskiego-st7970030?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-jest-wniosek-o-wszczecie-sledztwa-w-kierunku-naduzycia-wladzy-przez-jaroslawa-kaczynskiego-st7970030?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:15:47+00:00

<img alt="Wniosek policji o wszczęcie śledztwa w kierunku nadużycia władzy przez Jarosława Kaczyńskiego" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qzm0mx-incydent-przed-pomnikiem-smolenskim-ph7958735/alternates/LANDSCAPE_1280" />
    10 czerwca Jarosław Kaczyński wraz z bliskimi współpracownikami pojawił się przed pomnikiem ofiar katastrofy smoleńskiej. Prezes Prawa i Sprawiedliwości miał ze sobą sprej, którym zamalował tabliczkę na wieńcu, na której odpowiedzialnością za tragedię obciążany jest jego brat. Policja wystąpiła do prokuratury z wnioskiem o wszczęcie śledztwa w kierunku nadużycia władzy przez prezesa PiS.

## Poseł opuścił rozprawę, powołał się na ślubowanie. Pawłowicz oburzona: proszę usiąść, nie dałam zgody
 - [https://tvn24.pl/polska/trybunal-konstytucyjny-posel-pawelsliz-opuscil-rozprawe-powolal-sie-na-slubowanie-krystyna-pawlowicz-oburzona-st7969760?source=rss](https://tvn24.pl/polska/trybunal-konstytucyjny-posel-pawelsliz-opuscil-rozprawe-powolal-sie-na-slubowanie-krystyna-pawlowicz-oburzona-st7969760?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:15:00+00:00

<img alt="Poseł opuścił rozprawę, powołał się na ślubowanie. Pawłowicz oburzona: proszę usiąść, nie dałam zgody" src="https://tvn24.pl/polska/cdn-zdjecie-7188381-pawlowocz-ph7969828/alternates/LANDSCAPE_1280" />
    Trybunał Konstytucyjny Julii Przyłębskiej rozpatrzył sprawę skierowaną tam przez prezydenta, w której Andrzej Duda kwestionował ustawę przyjętą przez Sejm po wygaszeniu mandatów poselskich skazanych polityków PiS Mariusza Kamińskiego i Macieja Wąsika. Na rozprawę przyszedł poseł Polski 2050 Paweł Śliz i zawnioskował o wyłączenie ze składu sędziowskiego Krystyny Pawłowicz i Stanisława Piotrowicza. Po oddaleniu tego wniosku opuścił salę, na co oburzyła się Pawłowicz.

## Zatrucie pokarmowe w ośrodku nad morzem. Wzrosła liczba chorych
 - [https://tvn24.pl/szczecin/pogorzelica-u-122-osob-wypoczywajacych-nad-morzem-wykryto-bakterie-salmonelli-st7970009?source=rss](https://tvn24.pl/szczecin/pogorzelica-u-122-osob-wypoczywajacych-nad-morzem-wykryto-bakterie-salmonelli-st7970009?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:14:38+00:00

<img alt="Zatrucie pokarmowe w ośrodku nad morzem. Wzrosła liczba chorych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8006723-salmonella-pogorzelica-ph7969980/alternates/LANDSCAPE_1280" />
    Szczeciński sanepid poinformował, że u 122 osób przebywających w ośrodku wypoczynkowym w Pogorzelicy wykryto bakterie salmonelli. Osiem osób trafiło w związku z tym do szpitala. Ośrodek, w którym doszło do zarażenia, znajduje się pod stałym nadzorem służb, rozpoczęto tam kontrole z zakresu epidemiologii i higieny żywienia. O sprawie poinformowano Prokuraturę Rejonową w Gryficach.

## Burzowo w Warszawie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-burze-w-warszawie-ostrzezenie-st7970019?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-burze-w-warszawie-ostrzezenie-st7970019?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:13:20+00:00

<img alt="Burzowo w Warszawie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-054f22-ostrzezenie-przed-burzami-zdjecie-ilustracyjne-31772/alternates/LANDSCAPE_1280" />
    Stołeczny ratusz wydał ostrzeżenie o burzach z gradem i silnych porywach wiatru, które mogą wystąpić dzisiaj w stolicy. Na razie w Warszawie pada i lekko grzmi.

## Połamane drzewa w Otwocku, grad w Józefowie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-burze-w-warszawie-i-okolicach-ostrzezenie-skutki-st7970019?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-burze-w-warszawie-i-okolicach-ostrzezenie-skutki-st7970019?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:13:20+00:00

<img alt="Połamane drzewa w Otwocku, grad w Józefowie " src="https://kontakt24.tvn24.pl/najnowsze/cdn-zdjecie-3972217-skutki-burzy-w-otwocku-ph7970224/alternates/LANDSCAPE_1280" />
    Stołeczny ratusz wydał ostrzeżenie o burzach z gradem i silnych porywach wiatru, które mogą wystąpić dzisiaj w stolicy. W Warszawie po południu padało i lekko grzmiało. Silniejsza burza przeszła w powiatach na południowy wschód od Warszawy. Grad padał w Józefowie, silny deszcz nie ominął Piaseczna, czy Otwocka. W całym województwie burza połamała drzewa.

## Migrantka z raną oka. Dyrekcja szpitala: postrzelono ją z broni śrutowej
 - [https://tvn24.pl/najnowsze/dubicze-cerkiewne-migrantka-z-rana-oka-postrzelono-ja-z-broni-srutowej-st7969951?source=rss](https://tvn24.pl/najnowsze/dubicze-cerkiewne-migrantka-z-rana-oka-postrzelono-ja-z-broni-srutowej-st7969951?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:13:14+00:00

<img alt="Migrantka z raną oka. Dyrekcja szpitala: postrzelono ją z broni śrutowej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iz4peh-granica-polsko-bialoruska-ph7956357/alternates/LANDSCAPE_1280" />
    Do szpitala trafiła 35-letnia obywatelka Iranu, który w okolicach Dubicz Cerkiewnych (Podlasie) została postrzelona w oko z broni śrutowej. Karetkę wezwali strażnicy graniczni.

## Premier spóźnił się cztery minuty, prezydent nie czekał. Zgrzyt na Bałkanach
 - [https://tvn24.pl/swiat/czarnogora-premier-spoznil-sie-na-spotkanie-z-prezydentem-bulgarii-ten-nie-czekal-st7969582?source=rss](https://tvn24.pl/swiat/czarnogora-premier-spoznil-sie-na-spotkanie-z-prezydentem-bulgarii-ten-nie-czekal-st7969582?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:08:20+00:00

<img alt="Premier spóźnił się cztery minuty, prezydent nie czekał. Zgrzyt na Bałkanach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9100817-rumen-radev-ph7969633/alternates/LANDSCAPE_1280" />
    Prezydent Bułgarii Rumen Radew i premier Czarnogóry Milojko Spajić w poniedziałek mieli spotkać się w Podgoricy. Jednak gdy Spajić nie pojawił się punktualnie na miejscu, Radew po prostu wyszedł - informuje portal Politico.

## Prezydent powołał nowych sędziów. Wśród nich Mikołaj Pawlak
 - [https://tvn24.pl/polska/prezydent-powolal-nowych-sedziow-wsrod-nich-mikolaj-pawlak-st7969875?source=rss](https://tvn24.pl/polska/prezydent-powolal-nowych-sedziow-wsrod-nich-mikolaj-pawlak-st7969875?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T12:01:49+00:00

<img alt="Prezydent powołał nowych sędziów. Wśród nich Mikołaj Pawlak" src="https://tvn24.pl/polska/cdn-zdjecie-6309971-prezydent-duda-powolal-nowych-sedziow-wsrod-nich-mikolaj-pawlak-widoczny-z-tylu-stoi-w-trzecim-rzedzie-ph7969897/alternates/LANDSCAPE_1280" />
    Prezydent Andrzej Duda wręczył akty powołania nowym sędziom. Jednym z nich jest Mikołaj Pawlak, były Rzecznik Praw Dziecka, a wcześniej urzędnik resortu sprawiedliwości - w czasie, gdy do ministerstwa trafił wniosek Centralnego Biura Antykorupcyjnego o przekazanie 25 milionów złotych z Funduszu Sprawiedliwości na zakup Pegasusa.

## Pijany kierowca szkolnego autobusu
 - [https://tvn24.pl/katowice/jaworzno-pijany-kierowca-szkolnego-autobusu-st7970008?source=rss](https://tvn24.pl/katowice/jaworzno-pijany-kierowca-szkolnego-autobusu-st7970008?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:58:04+00:00

<img alt="Pijany kierowca szkolnego autobusu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-pg5kpz-wycieczka-szkolna-odjechala-bez-jednego-ucznia-zdjecie-ilustracyjne-ph7968487/alternates/LANDSCAPE_1280" />
    Kilkoro dzieci już było w autobusie, po drodze miał zabrać kolejne. Tak się nie stało, bo kierowcę zatrzymali policjanci. Był pod wpływem alkoholu. Dzieci do szkoły dotarły z innym, wezwanym przez przewoźnika kierowcą.

## Mężczyzna z urazem głowy w szpitalu po interwencji policjanta. Sprawą zajmuje się prokuratura
 - [https://tvn24.pl/szczecin/stargard-mezczyzna-z-urazem-glowy-trafil-do-szpitala-po-interwencji-policjanta-funkcjonariusz-zostal-zawieszony-st7969381?source=rss](https://tvn24.pl/szczecin/stargard-mezczyzna-z-urazem-glowy-trafil-do-szpitala-po-interwencji-policjanta-funkcjonariusz-zostal-zawieszony-st7969381?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:57:18+00:00

<img alt="Mężczyzna z urazem głowy w szpitalu po interwencji policjanta. Sprawą zajmuje się prokuratura" src="https://tvn24.pl/najnowsze/cdn-zdjecie-554639-policja-zdj-ilustracyjne-ph7969358/alternates/LANDSCAPE_1280" />
    Stargardzcy policjanci zostali wezwani na interwencję w sprawie rozebranego mężczyzny, który wtargnął na jedną z posesji. 30-latek nie reagował na polecenia funkcjonariuszy, więc został zatrzymany i przewieziony na komisariat. Stamtąd trafił z urazami głowy do szpitala. Przełożeni, analizując materiały z interwencji, doszli do wniosku, że prawdopodobnie jeden z funkcjonariuszy użył wobec mężczyzny bezzasadnie pałki służbowej. Sprawą zajmuje się prokuratura.

## "Zalewają internet". Jak politycy skoordynowali akcję ze zdjęciami czarnoskórych osób
 - [https://konkret24.tvn24.pl/polska/zalewaja-internet-jak-politycy-prawicy-skoordynowali-akcje-ze-zdjeciami-czarnoskorych-osob-st7967750?source=rss](https://konkret24.tvn24.pl/polska/zalewaja-internet-jak-politycy-prawicy-skoordynowali-akcje-ze-zdjeciami-czarnoskorych-osob-st7967750?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:53:52+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8524621-jak-politycy-skoordynowali-akcje-ze-zdjeciami-czarnoskorych-osob-ph7969984/alternates/LANDSCAPE_1280" />
    Niemal 60 polityków Prawa i Sprawiedliwości, Suwerennej Polski oraz Konfederacji w ciągu dwóch dni rozsyłało w mediach społecznościowych zdjęcia czarnoskórych osób przebywających w Polsce. To wywołało efekt "zalania internetu" – który teraz ci sami politycy wskazują jako… skutek działań rządu. Towarzyszący tej akcji manipulacyjny przekaz miał generować negatywne emocje.

## Inflacja na Wyspach najniższa od kilku lat
 - [https://tvn24.pl/biznes/ze-swiata/inflacja-w-wielkiej-brytanii-najnizsza-od-prawie-trzech-lat-st7969942?source=rss](https://tvn24.pl/biznes/ze-swiata/inflacja-w-wielkiej-brytanii-najnizsza-od-prawie-trzech-lat-st7969942?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:50:34+00:00

<img alt="Inflacja na Wyspach najniższa od kilku lat" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjeciee6102b33938307f512df917c9786a998-brytyjskie-wladze-oczekuja-ze-wprowadzenie-podatku-od-uslug-cyfrowych-podniesie-roczne-wplywy-do-budzetu-panstwa-w-latach-2022-2023-o-400-mln-funtow-4718315/alternates/LANDSCAPE_1280" />
    Inflacja w Wielkiej Brytanii spadła w maju do 2 procent i po raz pierwszy od prawie trzech lat znalazła się w granicach celu Banku Anglii. Do tej sytuacji przyczyniły się między innymi spadające ceny żywności, rozrywki oraz artykułów gospodarstwa domowego.

## Wtargnęła do karetki, uderzyła ratownika
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-pobila-ratownika-w-karetce-st7969804?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-pobila-ratownika-w-karetce-st7969804?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:47:44+00:00

<img alt="Wtargnęła do karetki, uderzyła ratownika" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6585487-atak-na-ratownika-medycznego-ph7969937/alternates/LANDSCAPE_1280" />
    Na ulicy Grójeckiej doszło do ataku w karetce pogotowia. Jak ustalił nasz reporter, kobieta pobiła ratownika medycznego, gdy ten udzielał pomocy jej koleżance z objawami zawału. 24-letnią napastniczkę zatrzymała policja.

## Kiedy obniżka stóp procentowych? Prognoza największego banku w Polsce
 - [https://tvn24.pl/biznes/z-kraju/kiedy-obnizka-stop-procentowych-prognoza-najwiekszego-banku-w-polsce-st7969873?source=rss](https://tvn24.pl/biznes/z-kraju/kiedy-obnizka-stop-procentowych-prognoza-najwiekszego-banku-w-polsce-st7969873?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:37:01+00:00

<img alt="Kiedy obniżka stóp procentowych? Prognoza największego banku w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5p609e-magazyn-inflacja-clean-6306052/alternates/LANDSCAPE_1280" />
    Szczyt inflacji ma być na koniec pierwszego kwartału 2025 roku na poziomie lekko poniżej 6 procent rok do roku - przewidują ekonomiści PKO BP. Zdaniem analityków, Rada Polityki Pieniężnej (RPP) powróci do obniżek stóp procentowych dopiero w lipcu 2025 roku.

## Śnięte ryby w Odrze. Podwyższony poziom złotej algi
 - [https://tvn24.pl/wroclaw/glogow-podwyzszony-poziom-zlotej-algi-w-odrze-st7969513?source=rss](https://tvn24.pl/wroclaw/glogow-podwyzszony-poziom-zlotej-algi-w-odrze-st7969513?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:35:01+00:00

<img alt="Śnięte ryby w Odrze. Podwyższony poziom złotej algi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oyl0gs-ryby-plywaja-brzuchem-do-gory-ph7958198/alternates/LANDSCAPE_1280" />
    Dolnośląski Urząd Wojewódzki we Wrocławiu opublikował wyniki badań próbek wody. W Odrze w okolicach Głogowa stwierdzono podwyższony poziom "złotej algi", co mogło być przyczyną śnięcia setek kilogramów ryb.

## Podróżowali autem z dwójką dzieci, dachowali. Ojciec trafił na izbę wytrzeźwień, a matka do więzienia
 - [https://tvn24.pl/tvnwarszawa/ulice/kisielany-kuce-podrozowali-autem-z-dwojka-dzieci-dachowali-ojciec-trafil-na-izbe-wytrzezwien-a-matka-do-wiezienia-st7969849?source=rss](https://tvn24.pl/tvnwarszawa/ulice/kisielany-kuce-podrozowali-autem-z-dwojka-dzieci-dachowali-ojciec-trafil-na-izbe-wytrzezwien-a-matka-do-wiezienia-st7969849?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:27:52+00:00

<img alt="Podróżowali autem z dwójką dzieci, dachowali. Ojciec trafił na izbę wytrzeźwień, a matka do więzienia" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-3500477-kisielany-kuce-37-latek-dachowal-w-aucie-pasazerka-i-dwojka-malych-dzieci-ph7969853/alternates/LANDSCAPE_1280" />
    W miejscowości Kisielany Kuce (województwo mazowieckie) dachował samochód osobowy. Podróżowała nim rodzina z dwójką dzieci. Kierujący pojazdem ojciec był pijany, a matka miała do odbycia zasądzoną karę więzienia.

## Za nami pierwsza taka noc w tym roku
 - [https://tvn24.pl/tvnmeteo/pogoda/za-nami-tropikalna-noc-st7969860?source=rss](https://tvn24.pl/tvnmeteo/pogoda/za-nami-tropikalna-noc-st7969860?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:27:52+00:00

<img alt="Za nami pierwsza taka noc w tym roku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x2e96p-tropikalna-noc-5148602/alternates/LANDSCAPE_1280" />
    Miniona noc była rekordowa pod względem temperatury w tym roku. Miejscami termometry pokazały aż 21,2 stopnia Celsjusza. - Za nami pierwsza noc tropikalna - przekazała w środę Ilona Śmigrodzka, synoptyk Instytutu Meteorologii i Gospodarki Wodnej (IMGW).

## Kompletnie pijany wjechał w budynek i uciekł
 - [https://tvn24.pl/wroclaw/jedlina-zdroj-kompletnie-pijany-wjechal-w-budynek-i-uciekl-st7969704?source=rss](https://tvn24.pl/wroclaw/jedlina-zdroj-kompletnie-pijany-wjechal-w-budynek-i-uciekl-st7969704?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:17:31+00:00

<img alt="Kompletnie pijany wjechał w budynek i uciekł " src="https://tvn24.pl/najnowsze/cdn-zdjecie-524987-wjechal-w-elewacje-budynku-ph7969833/alternates/LANDSCAPE_1280" />
    45-latek wjechał autem w budynek oraz skrzynkę pomiarową w Jedlinie-Zdrój (woj. dolnośląskie). Okazało się, że mężczyzna miał ponad 2,5 promila alkoholu w organizmie.

## Halle Berry niosła ogień olimpijski. Potem przejęła go książęca para
 - [https://tvn24.pl/kultura-i-styl/ogien-olimpijski-zmierza-do-paryza-w-cannes-poniosla-go-halle-berry-st7969689?source=rss](https://tvn24.pl/kultura-i-styl/ogien-olimpijski-zmierza-do-paryza-w-cannes-poniosla-go-halle-berry-st7969689?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:10:25+00:00

<img alt="Halle Berry niosła ogień olimpijski. Potem przejęła go książęca para" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9790301-halle-berry-przeniosla-ogien-olimpijski-ulicami-cannes-ph7969491/alternates/LANDSCAPE_1280" />
    Olimpijski ogień zmierza do Paryża. We wtorek amerykańska aktorka Halle Berry niosła go przez ulice Cannes. W uroczystej sztafecie uczestniczą też sportowcy i członkowie rodzin królewskich. 26 lipca zapalenie znicza zainauguruje oficjalnie tegoroczne igrzyska, które potrwają do 11 sierpnia.

## "Nie powiedziała, gdzie jedzie". Co wiemy o zaginięciu i śmierci 39-letniej Natalii
 - [https://tvn24.pl/poznan/gortatowo-poznan-smierc-39-letniej-natalii-co-wiemy-do-tej-pory-st7969794?source=rss](https://tvn24.pl/poznan/gortatowo-poznan-smierc-39-letniej-natalii-co-wiemy-do-tej-pory-st7969794?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:07:01+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1708088-39-letnia-natalia-znaleziona-martwa-ph7969737/alternates/LANDSCAPE_1280" />
    Policjanci odnaleźli w środę przed południem zwłoki zaginionej 39-letniej Natalii spod Poznania. Jej poszukiwania trwały od piątku. Ciało kobiety odnaleziono w kompleksie leśnym w północno-wschodniej części przedmieść Poznania, około 10 kilometrów od domu. Funkcjonariusze zatrzymali jej męża, który zgłosił jej zaginięcie.

## Duża sieć zmienia właściciela. Co ze sklepami w Polsce?
 - [https://tvn24.pl/biznes/z-kraju/spar-polska-zmienia-wlasciciela-jest-decyzja-w-sprawie-przyszlosci-sklepow-st7969792?source=rss](https://tvn24.pl/biznes/z-kraju/spar-polska-zmienia-wlasciciela-jest-decyzja-w-sprawie-przyszlosci-sklepow-st7969792?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T11:05:20+00:00

<img alt="Duża sieć zmienia właściciela. Co ze sklepami w Polsce?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7zv1on-zakupy-sklep-supermarket-wozek-shutterstock_2420523049-7927455/alternates/LANDSCAPE_1280" />
    Spar Group, właściciel Spar Polska, podjął decyzję o opuszczeniu polskiego rynku. Spółka znalazła już nowego nabywcę, który przejmie sklepy oraz będzie kontynuował rozwój biznesu pod tym samym szyldem. Transakcja zostanie sfinalizowana do końca bieżącego roku.

## Prowadzili taksówki na aplikację. W Polsce przebywali nielegalnie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-taksowkarze-z-uzbekistanu-zatrzymani-st7969469?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-taksowkarze-z-uzbekistanu-zatrzymani-st7969469?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:54:09+00:00

<img alt="Prowadzili taksówki na aplikację. W Polsce przebywali nielegalnie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-3444482-kontrola-taksowek-przy-dworcu-centralnym-ph7969653/alternates/LANDSCAPE_1280" />
    Podczas rutynowej kontroli kierowców przewozu osób prowadzonej w rejonie Dworca Centralnego straż graniczna zatrzymała dwóch obywateli Uzbekistanu, którzy przebywali w kraju nielegalnie.

## Nie żyje Halina Bortnowska. "Dzielny, jasny człowiek, pełna troski i myśli o innych"
 - [https://tvn24.pl/polska/halina-bortnowska-nie-zyje-ceniona-filozofka-publicystka-i-teolozka-miala-92-lata-st7969717?source=rss](https://tvn24.pl/polska/halina-bortnowska-nie-zyje-ceniona-filozofka-publicystka-i-teolozka-miala-92-lata-st7969717?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:48:55+00:00

<img alt="Nie żyje Halina Bortnowska. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1155301-halina-bortnowska-ph7969727/alternates/LANDSCAPE_1280" />
    W wieku 92 lat zmarła Halina Bortnowska. Informację o śmierci filozofki, teolożki, publicystki, animatorki przedsięwzięć społecznych i uczestniczki ruchu ekumenicznego w rozmowie z portalem tvn24.pl potwierdziła Helsińska Fundacja Praw Człowieka. Bortnowska była współzałożycielką Fundacji.

## "Tak parno, że powietrze można kroić". To nie koniec trudnej i męczącej pogody
 - [https://tvn24.pl/tvnmeteo/prognoza/tak-parno-ze-powietrze-mozna-kroic-to-nie-koniec-trudnej-i-meczacej-pogody-w-polsce-st7969314?source=rss](https://tvn24.pl/tvnmeteo/prognoza/tak-parno-ze-powietrze-mozna-kroic-to-nie-koniec-trudnej-i-meczacej-pogody-w-polsce-st7969314?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:48:30+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-754604-upal-ph7969637/alternates/LANDSCAPE_1280" />
    Do Polski napływa gorące, wilgotne powietrze z południa Europy. Sprawi ono, że w środę temperatura przekroczy w części kraju 30 stopni Celsjusza, niosąc pogodę parną i duszną. Jak prognozuje synoptyk tvnmeteo.pl Arleta Unton-Pyziołek, taka męcząca aura nie odpuści nam także w kolejnych dniach. Dlatego warto pamiętać zasady, które pomogą nam radzić sobie w takich warunkach pogodowych.

## Wykopał dół i czekał, aż cierpiący pies skona
 - [https://tvn24.pl/opole/opole-wykopal-dol-i-czekal-az-cierpiacy-pies-skona-st7969284?source=rss](https://tvn24.pl/opole/opole-wykopal-dol-i-czekal-az-cierpiacy-pies-skona-st7969284?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:40:24+00:00

<img alt="Wykopał dół i czekał, aż cierpiący pies skona" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1662164-schorowany-pies-cierpial-ph7969370/alternates/LANDSCAPE_1280" />
    90-letni właściciel nie chciał uśpić schorowanego i cierpiącego psa, wykopał dół w ogródku i czekał aż zwierzę samo skona. "Trafiłyśmy dzisiaj do psiego piekła" - napisali pracownicy Towarzystwa Opieki nad Zwierzętami z Opola, którzy zabrali czworonoga i poddali go eutanazji.

## Sprzedawała nieistniające smartfony. Usłyszała 28 zarzutów
 - [https://tvn24.pl/trojmiasto/puck-sprzedawala-nieistniajace-smartfony-uslyszala-28-zarzutow-st7969105?source=rss](https://tvn24.pl/trojmiasto/puck-sprzedawala-nieistniajace-smartfony-uslyszala-28-zarzutow-st7969105?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:32:02+00:00

<img alt="Sprzedawała nieistniające smartfony. Usłyszała 28 zarzutów" src="https://tvn24.pl/trojmiasto/cdn-zdjecie-6569999-sprzedawala-nieistniajace-smartfony-uslyszala-28-zarzutow-ph7969114/alternates/LANDSCAPE_1280" />
    28 zarzutów usłyszała 25-letnia mieszkanka powiatu puckiego. Jak ustalili śledczy, kobieta sprzedawała w sieci nieistniejące smartfony. Różnego rodzaju oszustw dopuszczała się od 2019 roku.

## Przyznano certyfikaty Błękitnej Flagi. Na liście 36 miejsc z Polski
 - [https://tvn24.pl/szczecin/blekitna-flaga-2024-ktore-kapieliska-otrzymaly-wyroznienie-st7967576?source=rss](https://tvn24.pl/szczecin/blekitna-flaga-2024-ktore-kapieliska-otrzymaly-wyroznienie-st7967576?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:27:42+00:00

<img alt="Przyznano certyfikaty Błękitnej Flagi. Na liście 36 miejsc z Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9tgaao-blekitna-flaga-2024-ph7967539/alternates/LANDSCAPE_1280" />
    Przyznano certyfikat Błękitnej Flagi na nadchodzący sezon 2024. Na całym świecie ponad pięć tysięcy miejsc z 51 krajów otrzymało to wyróżnienie. Wśród nich znalazło się 31 kąpielisk i pięć marin z Polski. Najwięcej znalazło się w województwie zachodniopomorskim.

## Burzliwy romans, oskarżenia o kradzież i groźby. Sierżant Black skazany w Rosji
 - [https://tvn24.pl/swiat/burzliwy-romans-oskarzenia-o-kradziez-i-grozby-sierzant-black-skazany-w-rosji-st7969378?source=rss](https://tvn24.pl/swiat/burzliwy-romans-oskarzenia-o-kradziez-i-grozby-sierzant-black-skazany-w-rosji-st7969378?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:23:50+00:00

<img alt="Burzliwy romans, oskarżenia o kradzież i groźby. Sierżant Black skazany w Rosji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6056473-gordon-black-ph7969281/alternates/LANDSCAPE_1280" />
    Amerykański żołnierz Gordon Black został skazany na trzy lata i dziewięć miesięcy więzienia - poinformowały w środę rosyjskie agencje. Sąd we Władywostoku uznał go za winnego kradzieży i groźby zabójstwa.

## Większość Polaków za legalizacją związków jednopłciowych, rośnie poparcie dla adopcji. Sondaż
 - [https://tvn24.pl/polska/zwiazki-jednoplciowe-legalizacja-malzenstw-i-adopcji-sondazipsos-st7969649?source=rss](https://tvn24.pl/polska/zwiazki-jednoplciowe-legalizacja-malzenstw-i-adopcji-sondazipsos-st7969649?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:16:17+00:00

<img alt="Większość Polaków za legalizacją związków jednopłciowych, rośnie poparcie dla adopcji. Sondaż" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7438383-shutterstock2154391461-ph7969690/alternates/LANDSCAPE_1280" />
    Dwie trzecie Polaków uważa, że pary jednopłciowe powinny mieć możliwość zawarcia małżeństwa lub zalegalizowania związku w inny sposób - wynika z badania przeprowadzonego przez Ipsos. Wzrosło poparcie dla adopcji dzieci przez takie pary.

## Amerykański magazyn wskazał najlepsze filmy półrocza. Wśród nich nagradzana produkcja z Polski
 - [https://tvn24.pl/kultura-i-styl/film-najlepsze-filmy-ostatniego-polrocza-wsrod-nich-zielona-granica-st7969488?source=rss](https://tvn24.pl/kultura-i-styl/film-najlepsze-filmy-ostatniego-polrocza-wsrod-nich-zielona-granica-st7969488?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:14:08+00:00

<img alt="Amerykański magazyn wskazał najlepsze filmy półrocza. Wśród nich nagradzana produkcja z Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qbw4p8-kadr-z-filmu-agnieszki-holland-zielona-granica-7301650/alternates/LANDSCAPE_1280" />
    "Zielona granica" znalazła się w dziesiątce najlepszych filmów pierwszego półrocza 2024 roku według amerykańskiego magazynu "The Hollywood Reporter". Nagradzana produkcja Agnieszki Holland została doceniona między innymi za "bezbłędną realizację".

## Po 43 latach więzienia sąd uchylił jej wyrok. Prawdziwym sprawcą zbrodni mógł być policjant
 - [https://tvn24.pl/swiat/sandra-hemme-po-43-latach-w-celi-zostala-uniewinniona-system-zawiodl-ja-przy-kazdej-okazji-st7969440?source=rss](https://tvn24.pl/swiat/sandra-hemme-po-43-latach-w-celi-zostala-uniewinniona-system-zawiodl-ja-przy-kazdej-okazji-st7969440?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:08:29+00:00

<img alt="Po 43 latach więzienia sąd uchylił jej wyrok. Prawdziwym sprawcą zbrodni mógł być policjant " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1wb3mf-po-43-latach-sedzia-uchylil-wyrok-skazujacy-sandry-hemme-ph7966273/alternates/LANDSCAPE_1280" />
    Wyrok Sandry Hemme, 64-latki skazanej w 1985 roku na karę dożywotniego więzienia, został uchylony w ubiegły piątek. W ocenie sądu obrońcy kobiety przedstawili wystarczające dowody na jej niewinność i brak zaangażowania w morderstwo Patricii Jeschke, do którego ponad 40 lat temu Amerykanka sama się przyznała. Wyjście kobiety na wolność nie jest jeszcze jednak przesądzone. Prokuratura zamierza bowiem skierować sprawę do sądu apelacyjnego.

## Kolejne zmiany na szczytach policji
 - [https://tvn24.pl/polska/kolejne-zmiany-na-szczytach-policji-st7968351?source=rss](https://tvn24.pl/polska/kolejne-zmiany-na-szczytach-policji-st7968351?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:06:20+00:00

<img alt="Kolejne zmiany na szczytach policji" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2fuo1c-kolejny-akt-oskarzenia-przeciwko-babci-kasi-zdjecie-ilustracyjne-5699980/alternates/LANDSCAPE_1280" />
    Kończy się kompletowanie kierownictwa policji. Nadzór nad pionem kryminalnym obejmie wkrótce Tomasz Michułka, a rektorem Akademii Policji zostanie Agata Malasińska-Nagórny - wynika z informacji tvn24.pl.

## Była pijana, jechała za szybko. Zginęła jej 3,5-letnia córeczka
 - [https://tvn24.pl/bialystok/dziecinne-spowodowala-wypadek-w-ktorym-zginelo-jej-dziecko-jechala-pijana-i-za-szybko-st7969499?source=rss](https://tvn24.pl/bialystok/dziecinne-spowodowala-wypadek-w-ktorym-zginelo-jej-dziecko-jechala-pijana-i-za-szybko-st7969499?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:05:00+00:00

<img alt="Była pijana, jechała za szybko. Zginęła jej 3,5-letnia córeczka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d3vfo6-w-wypadku-zginelo-35-letnie-dziecko-7642382/alternates/LANDSCAPE_1280" />
    Przed Sądem Rejonowym w Bielsku Podlaskim rozpoczął się w proces kobiety oskarżonej o spowodowanie wypadku, w którym zginęło jej 3,5-letnie dziecko, a kierowca innego samochodu doznał poważnych obrażeń. Kobieta była pijana i - jak ustalili biegli - jechała za szybko.

## Potrąciła 13-latkę na hulajnodze, bo "jej nie zauważyła"
 - [https://tvn24.pl/lublin/lukow-nie-ustapila-pierwszenstwa-i-potracila-13-latke-na-hulajnodze-st7969291?source=rss](https://tvn24.pl/lublin/lukow-nie-ustapila-pierwszenstwa-i-potracila-13-latke-na-hulajnodze-st7969291?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T10:02:04+00:00

<img alt="Potrąciła 13-latkę na hulajnodze, bo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-126314-kierujaca-samochodem-potracila-13-latke-na-hulajnodze-ph7969302/alternates/LANDSCAPE_1280" />
    W Łukowie (Lubelskie) 77-latka kierująca skodą potrącił 13-latkę na hulajnodze. Kobieta tłumaczyła, że nie zauważyła dziewczynki. Policjanci apelują o bezpieczną jazdę.

## Prawem jazdy cieszył się tylko 10 dni
 - [https://tvn24.pl/lublin/chelm-prawem-jazdy-cieszyl-sie-10-dni-brawurowa-jazde-tlumaczyl-pospiechem-st7969373?source=rss](https://tvn24.pl/lublin/chelm-prawem-jazdy-cieszyl-sie-10-dni-brawurowa-jazde-tlumaczyl-pospiechem-st7969373?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:58:28+00:00

<img alt="Prawem jazdy cieszył się tylko 10 dni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-13cyq8-stracil-prawo-jazdy-gdy-przywiozl-kolege-na-komende-zdjecie-ilustracyjne-7933866/alternates/LANDSCAPE_1280" />
    18-latek przez centrum Chełma (Lubelskie) pędził z prędkością 113 km/h. Stracił prawo jazdy po 10 dniach od zdania egzaminu, został też ukarany wysokim mandatem. Swoją jazdę - jak informuje policja - tłumaczył pośpiechem.

## Wił się na podłodze Dworca Centralnego
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wil-sie-na-podlodze-dworca-centralnego-mial-przy-sobie-narkotyki-st7969647?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wil-sie-na-podlodze-dworca-centralnego-mial-przy-sobie-narkotyki-st7969647?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:57:46+00:00

<img alt="Wił się na podłodze Dworca Centralnego" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-3644519-sobotni-wieczor-uczcil-mefka-ph7969626/alternates/LANDSCAPE_1280" />
    23-latek wił się na podłodze poczekalni warszawskiego Dworca Centralnego. Pracownicy ochrony wezwali strażników miejskich. Ci znaleźli przy mężczyźnie narkotyki.

## Protesty po egzaminach na medycynę. Tysiące kandydatów z niezwykle wysokimi ocenami
 - [https://tvn24.pl/swiat/indie-protesty-i-zarzuty-oszustwa-po-egzaminach-na-medycyne-st7969641?source=rss](https://tvn24.pl/swiat/indie-protesty-i-zarzuty-oszustwa-po-egzaminach-na-medycyne-st7969641?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:56:55+00:00

<img alt="Protesty po egzaminach na medycynę. Tysiące kandydatów z niezwykle wysokimi ocenami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2898370-indie-protesty-w-sprawie-egzaminow-na-medycyne-ph7969643/alternates/LANDSCAPE_1280" />
    Tegoroczny wstępny test na uczelnie medyczne w Indiach doprowadził do gwałtownych protestów. Po tym, jak tysiące kandydatów uzyskało zaskakująco wysokie oceny, pojawiły się zarzuty oszustwa - informuje BBC.

## Tusk: Rosja nie musi robić w Polsce kampanii strachu i nienawiści. Jest PiS
 - [https://tvn24.pl/polska/donald-tusk-rosja-nie-musi-robic-w-polsce-kampanii-strachu-i-nienawisci-jest-pis-st7969543?source=rss](https://tvn24.pl/polska/donald-tusk-rosja-nie-musi-robic-w-polsce-kampanii-strachu-i-nienawisci-jest-pis-st7969543?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:51:09+00:00

<img alt="Tusk: Rosja nie musi robić w Polsce kampanii strachu i nienawiści. Jest PiS" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mudg3t-donald-tusk-wiec-plac-zamkowy-ph7947713/alternates/LANDSCAPE_1280" />
    Premier Donald Tusk stwierdził w środę, że Rosja, która w wielu państwach organizuje i finansuje opartą na kłamstwie i dezinformacji kampanię nienawiści i strachu, w Polsce nie musi tego robić, bo - według niego - zajmuje się tym tutaj PiS.

## Tajemniczy monolit pojawił się na pustyni w Nevadzie. Zagadka wciąż bez wyjaśnienia
 - [https://tvn24.pl/ciekawostki/usa-tajemniczy-monolit-na-pustyni-w-nevadzie-zagadka-wciaz-bez-wyjasnienia-st7969054?source=rss](https://tvn24.pl/ciekawostki/usa-tajemniczy-monolit-na-pustyni-w-nevadzie-zagadka-wciaz-bez-wyjasnienia-st7969054?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:50:05+00:00

<img alt="Tajemniczy monolit pojawił się na pustyni w Nevadzie. Zagadka wciąż bez wyjaśnienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9403864-monolit-w-nevadzie-ph7969457/alternates/LANDSCAPE_1280" />
    Tajemniczy monolit został znaleziony w weekend na pustyni w Nevadzie - poinformowała policja z Las Vegas. Informacja ponownie ożywiła spekulacje na temat tego, czym może być i skąd się tam wziął. To nie pierwszy przypadek odnalezienia podobnego obiektu na świecie - tajemnicze monolity znajdywane są w różnych częściach świata od kilku lat.

## Bójka kilkunastu osób w strefie kibica. Sprawę wyjaśnia policja. Nagranie
 - [https://tvn24.pl/lubuskie/gorzow-wielkopolski-bojka-kilkunastu-osob-w-strefie-kibica-euro-2024-sprawe-wyjasnia-policja-st7969485?source=rss](https://tvn24.pl/lubuskie/gorzow-wielkopolski-bojka-kilkunastu-osob-w-strefie-kibica-euro-2024-sprawe-wyjasnia-policja-st7969485?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:46:10+00:00

<img alt="Bójka kilkunastu osób w strefie kibica. Sprawę wyjaśnia policja. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9221963-bojka-kibicow-w-gorzowie-wielkopolskim-ph7969383/alternates/LANDSCAPE_1280" />
    Kilkanaście osób wzięło udział w bójce w strefie kibica w Gorzowie Wielkopolskim. Wszystko odbyło się po meczu reprezentacji Turcji i Gruzji na Euro 2024. Na nagraniach, które pojawiły się w internecie, widać osoby bijące się ze sobą tuż obok rzeki Warty. Sprawą zajmuje się policja, która informuje, że po dojeździe na miejsce grupa osób się rozbiegła.

## Tak zdobywają fentanyl w Polsce. "Większość recept od jednego podmiotu, nawet jednego lekarza"
 - [https://tvn24.pl/polska/tak-zdobywaja-fentanyl-w-polsce-wiekszosc-recept-od-jednego-podmiotu-nawet-jednego-lekarza-st7969392?source=rss](https://tvn24.pl/polska/tak-zdobywaja-fentanyl-w-polsce-wiekszosc-recept-od-jednego-podmiotu-nawet-jednego-lekarza-st7969392?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:28:40+00:00

<img alt="Tak zdobywają fentanyl w Polsce. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hagrj7-shutterstock_2417273215-ph7965195/alternates/LANDSCAPE_1280" />
    Obserwujemy, że do aptek przychodzą młodze, wysportowane osoby z listą recept na fentanyl i skupują. Co jest ciekawe i znamienne, większość tych recept pochodzi z jednego podmiotu, nawet od jednego lekarza - mówił w TVN24 Łukasz Pietrzak, farmaceuta, kierownik apteki.

## Zderzenie dwóch aut. Utrudnienia w Alejach Jerozolimskich
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-w-alejach-jerozolimskich-obok-blue-city-st7969514?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-w-alejach-jerozolimskich-obok-blue-city-st7969514?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:25:59+00:00

<img alt="Zderzenie dwóch aut. Utrudnienia w Alejach Jerozolimskich " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-7969991-zderzenie-w-alejach-jerozolimskich-ph7969531/alternates/LANDSCAPE_1280" />
    Na wysokości centrum handlowego Blue City zderzyły się dwa samochody osobowe. Kierowca jednego z nich został zabrany do szpitala. Zablokowane są dwa pasy ruchu.

## Rząd chce wprowadzić nową opłatę
 - [https://tvn24.pl/biznes/z-kraju/nowa-oplata-gazowa-ma-pokryc-budowanie-zapasow-gazu-st7969516?source=rss](https://tvn24.pl/biznes/z-kraju/nowa-oplata-gazowa-ma-pokryc-budowanie-zapasow-gazu-st7969516?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:25:30+00:00

<img alt="Rząd chce wprowadzić nową opłatę " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rd0ba7-zabrali-okolo-90-tysiecy-zlotych-zdjecie-ilustracyjne-ph7961047/alternates/LANDSCAPE_1280" />
    Rząd planuje wprowadzenie opłaty gazowej finansującej utrzymywanie zapasów strategicznych gazu - podano w projekcie ustawy, którą resort klimatu wysłał do konsultacji.

## "20-latek przyznał, że w bieliźnie schował mefkę i trochę zioła"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/legionowo-mlody-mezczyzna-przyznal-sie-ze-ma-mefke-i-troche-ziola-st7969304?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/legionowo-mlody-mezczyzna-przyznal-sie-ze-ma-mefke-i-troche-ziola-st7969304?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:23:34+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4984375-20-latek-przyznal-ze-ma-przy-sobie-narkotyki-ph7969510/alternates/LANDSCAPE_1280" />
    Zarzut posiadania narkotyków usłyszał 20-letni mieszkaniec powiatu. Policjanci ujawnili przy nim fifkę, wtedy młody człowiek sam przyznał się, że ma przy sobie środki odurzające. Za popełnione przestępstwo grozi mu kara do 3 lat pozbawienia wolności.

## Nielegalnie przekroczyli granicę. Uciekając, schowali się w stawie
 - [https://tvn24.pl/lubuskie/radnica-proba-nielegalnego-przekroczenia-granicy-mezczyzni-po-ucieczce-ukryli-sie-w-stawie-st7969195?source=rss](https://tvn24.pl/lubuskie/radnica-proba-nielegalnego-przekroczenia-granicy-mezczyzni-po-ucieczce-ukryli-sie-w-stawie-st7969195?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:22:29+00:00

<img alt="Nielegalnie przekroczyli granicę. Uciekając, schowali się w stawie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9378747-poscig-radnica-ph7969186/alternates/LANDSCAPE_1280" />
    Kierowca samochodu nie zatrzymał się do kontroli policyjnej w Radnicy (woj. zachodniopomorskie). Mężczyźni podróżujący autem chcieli uciec mundurowym, więc porzucili pojazd i próbowali ukryć się w trzcinie na środku stawu. Wszyscy czterej wyszli z wody o własnych siłach i oddali się w ręce funkcjonariuszy. Zatrzymani to obywatele Jemenu, Syrii oraz Afganistanu.

## Alert RCB w 11 województwach. "Unikaj otwartych przestrzeni"
 - [https://tvn24.pl/tvnmeteo/prognoza/alert-rcb-w-11-wojewodztwach-burze-ulewy-silny-wiatr-grad-sroda-1906-unikaj-otwartych-przestrzeni-st7969486?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alert-rcb-w-11-wojewodztwach-burze-ulewy-silny-wiatr-grad-sroda-1906-unikaj-otwartych-przestrzeni-st7969486?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:17:18+00:00

<img alt="Alert RCB w 11 województwach. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4050275-meto2-ph7969527/alternates/LANDSCAPE_1280" />
    Alert RCB. Rządowe Centrum Bezpieczeństwa ostrzega przed burzami, podczas których będzie mocno padać i wiać. SMS-owy alert został wysłany do osób przebywających na terenie 11 województw.

## Ponad pół tysiąca pielgrzymów zmarło od upału
 - [https://tvn24.pl/tvnmeteo/swiat/ponad-pol-tysiaca-pielgrzymow-zmarlo-od-upalu-st7969380?source=rss](https://tvn24.pl/tvnmeteo/swiat/ponad-pol-tysiaca-pielgrzymow-zmarlo-od-upalu-st7969380?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:06:25+00:00

<img alt="Ponad pół tysiąca pielgrzymów zmarło od upału" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-7208803-pielgrzymka-do-mekki-ph7969477/alternates/LANDSCAPE_1280" />
    Co najmniej 550 uczestników hadżdżu, czyli corocznej pielgrzymki muzułmanów do Mekki w Arabii Saudyjskiej, zmarło w wyniku upałów - podała agencja informacyjna AFP, powołując się na źródła dyplomatyczne. Co najmniej 320 ofiar to Egipcjanie.

## Poszukiwana 39-letnia Natalia nie żyje. Zatrzymano jej męża
 - [https://tvn24.pl/poznan/gortatowo-policjanci-znalezli-zwloki-zaginionej-39-letniej-natalii-st7969474?source=rss](https://tvn24.pl/poznan/gortatowo-policjanci-znalezli-zwloki-zaginionej-39-letniej-natalii-st7969474?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:02:39+00:00

<img alt="Poszukiwana 39-letnia Natalia nie żyje. Zatrzymano jej męża" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5189095-39-letnia-natalia-zostala-znaleziona-martwa-ph7969470/alternates/LANDSCAPE_1280" />
    Policjanci odnaleźli zwłoki zaginionej 39-letniej Natalii spod Poznania. Ciało odnaleziono w kompleksie leśnym w północno-wschodniej części przedmieść Poznania. Mąż kobiety został zatrzymany. 15 czerwca zgłosił jej zaginięcie. Ciało kobiety znaleziono około 10 kilometrów od domu.

## Garmin Polska pod lupą UOKiK. Możliwa zmowa cenowa
 - [https://tvn24.pl/biznes/z-kraju/sprzet-garmin-postepowanie-uokik-ws-mozliwego-porozumienia-ograniczajacego-konkurencje-st7969250?source=rss](https://tvn24.pl/biznes/z-kraju/sprzet-garmin-postepowanie-uokik-ws-mozliwego-porozumienia-ograniczajacego-konkurencje-st7969250?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T09:01:37+00:00

<img alt="Garmin Polska pod lupą UOKiK. Możliwa zmowa cenowa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qkp7bq-shutterstock_2402485723-7937408/alternates/LANDSCAPE_1280" />
    Urząd Ochrony Konkurencji i Konsumentów (UOKiK) wszczął postępowanie wyjaśniające w sprawie możliwego porozumienia ograniczającego konkurencję. Garmin Polska - przedstawiciel producenta między innymi smartwatchów - mógł zawrzeć zmowę cenową z dystrybutorami swoich produktów - napisał UOKiK w komunikacie.

## Uchylenie immunitetu Marcina Romanowskiego. Prokurator generalny skierował wniosek
 - [https://tvn24.pl/polska/uchylenie-immunitetu-marcina-romanowskiego-prokurator-generalny-skierowal-wniosek-do-sejmu-st7969476?source=rss](https://tvn24.pl/polska/uchylenie-immunitetu-marcina-romanowskiego-prokurator-generalny-skierowal-wniosek-do-sejmu-st7969476?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T08:55:37+00:00

<img alt="Uchylenie immunitetu Marcina Romanowskiego. Prokurator generalny skierował wniosek " src="https://tvn24.pl/najnowsze/cdn-zdjecie-211926-marcin-romanowski-ph7936797/alternates/LANDSCAPE_1280" />
    Prokurator Generalny Adam Bodnar przekazał dzisiaj do Marszałka Sejmu Rzeczypospolitej Polskiej Szymona Hołowni wniosek o wyrażenie przez Sejm Rzeczypospolitej Polskiej zgody na pociągnięcie posła na Sejm RP Marcina Romanowskiego do odpowiedzialności karnej oraz jego zatrzymanie i tymczasowe aresztowanie - podała Prokuratura Krajowa.

## Zderzył się z autem, zatrzymali go świadkowie. Policja: 3,6 promila, brak prawa jazdy, auto bez aktualnych badań
 - [https://tvn24.pl/tvnwarszawa/najnowsze/nowy-dwor-mazowiecki-obywatelskie-zatrzymanie-pijanego-kierowcy-doprowadzil-do-zderzenia-st7969184?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/nowy-dwor-mazowiecki-obywatelskie-zatrzymanie-pijanego-kierowcy-doprowadzil-do-zderzenia-st7969184?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T08:45:30+00:00

<img alt="Zderzył się z autem, zatrzymali go świadkowie. Policja: 3,6 promila, brak prawa jazdy, auto bez aktualnych badań" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4531383-obywatelskie-zatrzymania-zdj-ilustracyjne-ph7969313/alternates/LANDSCAPE_1280" />
    Jechał niepewnie, doprowadził do zdarzenia z innym autem, zatrzymali go świadkowie. Gdy na miejsce dotarła policja, okazało się, że kierowca miał 3,6 promila i nie posiada prawa jazdy.

## Prezydencki minister o Kaczyńskim: Robi, co chce. To jego prywatna partia
 - [https://tvn24.pl/polska/prezydencki-minister-o-kaczynskim-robi-co-chce-to-jego-prywatna-partia-st7969212?source=rss](https://tvn24.pl/polska/prezydencki-minister-o-kaczynskim-robi-co-chce-to-jego-prywatna-partia-st7969212?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T07:58:41+00:00

<img alt="Prezydencki minister o Kaczyńskim: Robi, co chce. To jego prywatna partia" src="https://konkret24.tvn24.pl/najnowsze/cdn-zdjecie-bz1ufb-jaroslaw-kaczynski-podczas-kampanii-do-parlamentu-europejskiego-7-czerwca-2024-ph7955736/alternates/LANDSCAPE_1280" />
    PiS to prywatna partia Jarosława Kaczyńskiego. On zrobi, co chce - powiedział prezydencki minister Marcin Mastalerek. Zaznaczył przy tym, że jego zdaniem Kaczyński powinien odejść na emeryturę, ale w jego partii "nie ma naturalnej sukcesji".

## Śmiertelne potrącenie na torach. Utrudnienia w kursowaniu pociągów
 - [https://tvn24.pl/tvnwarszawa/najnowsze/kobylka-smiertelne-potracenie-na-torach-utrudnienia-na-trasie-warszawa-bialystok-st7969300?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/kobylka-smiertelne-potracenie-na-torach-utrudnienia-na-trasie-warszawa-bialystok-st7969300?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T07:57:08+00:00

<img alt="Śmiertelne potrącenie na torach. Utrudnienia w kursowaniu pociągów" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4202620-smiertelny-wypadek-na-torach-w-kobylce-ph7969325/alternates/LANDSCAPE_1280" />
    W okolicy stacji Kobyłka doszło do tragicznego wypadku. Osoba dostała się pod pociąg. Są utrudnienia w ruchu na szlaku Warszawa-Białystok.

## Dwie turystki zaginęły na greckiej wyspie. Wcześniej jedna wysłała niepokojącą wiadomość
 - [https://tvn24.pl/swiat/turystki-zaginely-na-greckiej-wyspie-wczesniej-jedna-wyslala-niepokojaca-wiadomosc-st7969227?source=rss](https://tvn24.pl/swiat/turystki-zaginely-na-greckiej-wyspie-wczesniej-jedna-wyslala-niepokojaca-wiadomosc-st7969227?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T07:56:12+00:00

<img alt="Dwie turystki zaginęły na greckiej wyspie. Wcześniej jedna wysłała niepokojącą wiadomość " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9342943-sikinos-poszukiwania-dwoch-turystek-z-francji-trwaja-ph7969182/alternates/LANDSCAPE_1280" />
    Trwają poszukiwania 73-letniej turystki z Francji, która w piątek zaginęła na greckiej wyspie Sikinos. Tego samego dnia kobieta miała przesłać właścicielowi hotelu wiadomość sugerującą, jakoby uległa wypadkowi. Lokalne służby prowadzą też akcję poszukiwawczą jej 64-letniej znajomej.

## Uszkodzone domy, zerwane linie energetyczne. "To było wstrząsające"
 - [https://tvn24.pl/tvnmeteo/swiat/uszkodzone-domy-zerwane-linie-energetyczne-traba-powietrzna-we-francji-to-bylo-wstrzasajace-st7969180?source=rss](https://tvn24.pl/tvnmeteo/swiat/uszkodzone-domy-zerwane-linie-energetyczne-traba-powietrzna-we-francji-to-bylo-wstrzasajace-st7969180?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T07:55:32+00:00

<img alt="Uszkodzone domy, zerwane linie energetyczne. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8096565-traba-powietrzna-ph7969148/alternates/LANDSCAPE_1280" />
    Trąba powietrzna pojawiła się w miejscowości Carlepont położonej na północy Francji. Strażacy przekazali, że w wyniku żywiołu 34 domy zostały uszkodzone.

## Justin Timberlake aresztowany za jazdę po alkoholu. Pokazano nagranie
 - [https://tvn24.pl/kultura-i-styl/justin-timberlake-aresztowany-za-jazde-po-alkoholu-pokazano-nagranie-st7969129?source=rss](https://tvn24.pl/kultura-i-styl/justin-timberlake-aresztowany-za-jazde-po-alkoholu-pokazano-nagranie-st7969129?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T07:42:58+00:00

<img alt="Justin Timberlake aresztowany za jazdę po alkoholu. Pokazano nagranie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1014693-justin-timberlake-ph7969308/alternates/LANDSCAPE_1280" />
    Amerykańskie media pokazały nagranie, na którym ma być widać jazdę Justina Timberlake'a krótko przed zatrzymaniem przez policję. Artysta spędził noc w areszcie, został oskarżony o prowadzenie samochodu pod wpływem alkoholu.

## Przejażdżka po parku z Władimirem Putinem. Kim dał się przewieźć
 - [https://tvn24.pl/swiat/wladimir-putin-w-korei-polnocnej-podarowal-kim-dzong-unowi-nowa-limuzyne-i-zabral-go-na-przejazdzke-st7969118?source=rss](https://tvn24.pl/swiat/wladimir-putin-w-korei-polnocnej-podarowal-kim-dzong-unowi-nowa-limuzyne-i-zabral-go-na-przejazdzke-st7969118?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T07:34:03+00:00

<img alt="Przejażdżka po parku z Władimirem Putinem. Kim dał się przewieźć" src="https://tvn24.pl/najnowsze/cdn-zdjecie-533248-wladimir-putin-i-kim-dzong-un-ph7970016/alternates/LANDSCAPE_1280" />
    Władimir Putin zabrał Kim Dzong Una na przejażdżkę limuzyną, którą wcześniej sam mu podarował. Rosyjski prezydent przebywa obecnie w Korei Północnej, gdzie został przyjęty z pełnymi honorami. Na lotnisku w Pjongjangu czekał na niego rozłożony czerwony dywan.

## Wymiana przy limuzynie. Putin się ugiął
 - [https://tvn24.pl/swiat/wymiana-przy-limuzynie-putin-sie-ugial-st7969118?source=rss](https://tvn24.pl/swiat/wymiana-przy-limuzynie-putin-sie-ugial-st7969118?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T07:34:03+00:00

<img alt="Wymiana przy limuzynie. Putin się ugiął" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6699246-putin-i-kim-dzong-un-ph7969138/alternates/LANDSCAPE_1280" />
    Władimir Putin został przyjęty w Korei Północnej z pełnymi honorami. Na lotnisku w Pjongjangu, oprócz Kim Dzong Una, czekał na  niego rozłożony czerwony dywan. Nie zabrakło też wymiany uprzejmości przy limuzynie.

## Foteliki samochodowe do wymiany. "Jeden z elementów może się luzować"
 - [https://tvn24.pl/biznes/pieniadze/fotelik-samochodowy-dla-dzieci-wycofanie-produktu-z-rynku-z-powodu-wady-konstrukcyjnej-st7969079?source=rss](https://tvn24.pl/biznes/pieniadze/fotelik-samochodowy-dla-dzieci-wycofanie-produktu-z-rynku-z-powodu-wady-konstrukcyjnej-st7969079?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T07:27:57+00:00

<img alt="Foteliki samochodowe do wymiany. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4o5ybi-dziecko-fotelik-samochod-shutterstock_1194839185-7833677/alternates/LANDSCAPE_1280" />
    Do Urzędu Ochrony Konkurencji i Konsumentów (UOKiK) wpłynęło zawiadomienie od firmy 4Kraft o wadliwych fotelikach samochodowych. Akcja dotyczy kilku modeli. Firma uruchomiła bezpłatny program wymiany .

## Wziął 150 tys. zł za ustawienie przetargu. Wpadł na gorącym uczynku
 - [https://tvn24.pl/trojmiasto/gdynia-wzial-150-tys-zl-za-ustawienie-przetargu-wpadl-na-goracym-uczynku-st7969128?source=rss](https://tvn24.pl/trojmiasto/gdynia-wzial-150-tys-zl-za-ustawienie-przetargu-wpadl-na-goracym-uczynku-st7969128?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T07:24:44+00:00

<img alt="Wziął 150 tys. zł za ustawienie przetargu. Wpadł na gorącym uczynku" src="https://tvn24.pl/trojmiasto/cdn-zdjecie-1704467-zatrzymany-za-zaklocenie-przetargu-i-przyjecie-lapowki-ph7969219/alternates/LANDSCAPE_1280" />
    Policjanci z Gdyni zatrzymali na gorącym uczynku 47-letniego mężczyznę, który za 150 tys. zł łapówki obiecał nie podbijać ceny podczas licytacji miejskiej nieruchomości w Gdyni. Mało brakowało, a gdyński urząd miasta straciłby 800 tys. zł. Policja opublikowała film z zatrzymania.

## Policjanci "Kobry" zatrzymali podejrzanego o kradzież auta. Miał przy sobie mefedron
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-kobra-zatrzymala-podejrzanego-o-kradziez-auta-mial-przy-sobie-mefedron-st7969063?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-kobra-zatrzymala-podejrzanego-o-kradziez-auta-mial-przy-sobie-mefedron-st7969063?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T06:45:47+00:00

<img alt="Policjanci " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-7335145-policja-zatrzymala-42-latka-podejrzanego-o-kradziez-samochodu-ph7969092/alternates/LANDSCAPE_1280" />
    42-letni mieszkaniec Grudziądza został zatrzymany w związku z kradzieżą samochodu dokonaną w warszawskim Wawrze. Podczas przeszukania policjanci znaleźli przy nim m.in. narzędzie do grawerowania metalu, łamak oraz mefedron.

## Skorpiony zamiast narzędzi
 - [https://tvn24.pl/szczecin/szczecin-skropiony-i-uropygi-w-paczce-nadanej-z-hongkongu-st7969119?source=rss](https://tvn24.pl/szczecin/szczecin-skropiony-i-uropygi-w-paczce-nadanej-z-hongkongu-st7969119?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T06:29:52+00:00

<img alt="Skorpiony zamiast narzędzi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7942495-skorpiony-w-paczce-szczecin-ph7969096/alternates/LANDSCAPE_1280" />
    Zachodniopomorska Krajowa Izba Skarbowa skontrolowała paczkę nadaną z Hongkongu, w której miały być narzędzia ogrodnicze. Zamiast nich urzędnicy znaleźli cztery skorpiony i dwie uropygi. Z uwagi na brak wymaganych dokumentów zwierzęta odesłano do nadawcy.

## "Krowie wymiona" zawisły nad Ziemią Lubuską
 - [https://tvn24.pl/tvnmeteo/polska/krowie-wymiona-zawisly-nadziemia-lubuska-st7969075?source=rss](https://tvn24.pl/tvnmeteo/polska/krowie-wymiona-zawisly-nadziemia-lubuska-st7969075?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T06:17:04+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3788651-chmury-mammatus-pojawily-sie-w-miejscowosci-radomicko-ph7969090/alternates/LANDSCAPE_1280" />
    Chmury mammatus z charakterystycznymi wypustkami, przypominającymi krowie wymiona, pojawiły się we wtorek w województwie lubuskim. Udało się je uchwycić na nagraniu Reporterowi 24.

## Żołnierz ranny podczas ćwiczeń
 - [https://tvn24.pl/szczecin/zegrze-pomorskie-wypadek-zolnierza-podczas-cwiczen-st7968227?source=rss](https://tvn24.pl/szczecin/zegrze-pomorskie-wypadek-zolnierza-podczas-cwiczen-st7968227?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T06:13:24+00:00

<img alt="Żołnierz ranny podczas ćwiczeń" src="https://tvn24.pl/najnowsze/cdn-zdjecie-954758-wojsko-polskie-zdjecie-ilustracyjne-ph7966706/alternates/LANDSCAPE_1280" />
    W trakcie szkolenia na placu ćwiczeń jednostki w Zegrzu Pomorskim (woj. zachodniopomorskie) żołnierz 8 Koszalińskiego Pułku Przeciwlotniczego został ranny. Mężczyzna leży w szpitalu, ale jego życiu nic nie zagraża. Okoliczności zdarzenia wyjaśnia Żandarmeria Wojskowa.

## Zandberg: Rząd wszedł w PiS-owskie buty. Utrzymując go, Lewica może się sama położyć do grobu
 - [https://tvn24.pl/polska/adrian-zandberg-rzad-wszedl-w-pis-owskie-buty-utrzymujac-go-lewica-moze-sie-sama-polozyc-do-grobu-st7969064?source=rss](https://tvn24.pl/polska/adrian-zandberg-rzad-wszedl-w-pis-owskie-buty-utrzymujac-go-lewica-moze-sie-sama-polozyc-do-grobu-st7969064?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T06:06:27+00:00

<img alt="Zandberg: Rząd wszedł w PiS-owskie buty. Utrzymując go, Lewica może się sama położyć do grobu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5954272-piasek-ph7969070/alternates/LANDSCAPE_1280" />
    Lewica, która nie zrealizuje swojego programu i będzie utrzymywała rząd, który realizuje inny, centroprawicowy program, może sama się położyć do grobu. Wyborcy Lewicy nie będą mieli wtedy powodu, żeby pójść na tę Lewicę zagłosować - stwierdził w TVN24 Adrian Zandberg, wiceprzewodniczący partii Razem.

## Wakacje na europejskiej wyspie? Eksperci wskazują 12 najlepszych
 - [https://tvn24.pl/ciekawostki/wakacje-2024-oto-12-najlepszych-wysp-w-europie-wedlug-lonely-planet-st7968124?source=rss](https://tvn24.pl/ciekawostki/wakacje-2024-oto-12-najlepszych-wysp-w-europie-wedlug-lonely-planet-st7968124?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T06:03:41+00:00

<img alt="Wakacje na europejskiej wyspie? Eksperci wskazują 12 najlepszych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hqc012-korsyka-7366048/alternates/LANDSCAPE_1280" />
    Włoskie, greckie, a może nordyckie - które europejskie wyspy są najlepsze na wakacyjny wypoczynek? Portal turystyczny Lonely Planet przygotował zestawienie dwunastu wysp na Starym Kontynencie, spośród których każda charakteryzuje się innym, wyjątkowym klimatem.

## "Oddaję wam bardzo osobistą książkę"
 - [https://tvn24.pl/polska/oddaje-wam-bardzo-osobista-ksiazke-piotr-jacon-o-wiktoria-transplciowosc-to-nie-wszystko-st7969015?source=rss](https://tvn24.pl/polska/oddaje-wam-bardzo-osobista-ksiazke-piotr-jacon-o-wiktoria-transplciowosc-to-nie-wszystko-st7969015?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T06:03:40+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1809835-spotkanie-autorskie-z-piotrem-jaconiem-ph7969014/alternates/LANDSCAPE_1280" />
    To są historie nasze, rodzinne - mówił dziennikarz TVN24 Piotr Jacoń, autor publikacji "Wiktoria. Transpłciowość to nie wszystko", w czasie autorskiego spotkania w klubie Niebo w Warszawie. Maja Heban ze Stowarzyszenia Miłość Nie Wyklucza zwróciła uwagę, że z książki "bije dojrzałość procesu".

## Atak obok Lwowa, makabryczny rozkaz Rosjan, niepokojące doniesienia z Zaporoża. Co wydarzyło się w Ukrainie
 - [https://tvn24.pl/swiat/atak-obok-lwowa-makabryczny-rozkaz-rosjan-niepokojace-doniesienia-z-zaporoza-co-wydarzylo-sie-w-ukrainie-st7969025?source=rss](https://tvn24.pl/swiat/atak-obok-lwowa-makabryczny-rozkaz-rosjan-niepokojace-doniesienia-z-zaporoza-co-wydarzylo-sie-w-ukrainie-st7969025?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T05:56:51+00:00

<img alt="Atak obok Lwowa, makabryczny rozkaz Rosjan, niepokojące doniesienia z Zaporoża. Co wydarzyło się w Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jk8ubc-ukrainskie-sily-bezpieczenstwa-7936829/alternates/LANDSCAPE_1280" />
    Jedna osoba jest ranna po ataku rosyjskiego drona w obwodzie lwowskim - poinformował w środę rano mer tego miasta Andrij Sadowy. Rosjanie zaatakowali 60 kilometrów od granicy z Polską. W sumie ukraińskie siły powietrzne zestrzeliły 19 bezzałogowców, które zaatakowały kilka regionów kraju. 847 dni temu rozpoczęła się inwazja Rosji na Ukrainę. Co jeszcze wydarzyło się w ciągu ostatniej doby w Ukrainie.

## Tę branżę dopadł paraliż. "Skala chaosu jest potężna"
 - [https://tvn24.pl/biznes/prawo/nowe-przepisy-w-sprawie-praw-jazdy-dla-obcokrajowcow-wprowadzily-chaos-st7969047?source=rss](https://tvn24.pl/biznes/prawo/nowe-przepisy-w-sprawie-praw-jazdy-dla-obcokrajowcow-wprowadzily-chaos-st7969047?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T05:50:13+00:00

<img alt="Tę branżę dopadł paraliż. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yykq1y-warszawa-ulica-korek-samochody-samochod-shutterstock_2036398358-7462242/alternates/LANDSCAPE_1280" />
    W poniedziałek zaczęły obowiązywać przepisy nowelizacji ustawy o transporcie drogowym, które z przewozu osób wykluczyły kierowców nieposiadających polskiego prawa jazdy, ale także tych, którzy w naszym kraju przebywają krócej niż 185 dni. Jak podaje środowa "Rzeczpospolita", nowe przepisy odsunęły nawet jedną czwartą zagranicznych kierowców. "Bez strategii migracyjnej biznes ma problem" - czytamy w gazecie.

## Ważne zmiany w podatku od nieruchomości
 - [https://tvn24.pl/biznes/nieruchomosci/zmiany-w-podatku-od-nieruchomosci-garaze-wielostanowiskowe-st7969045?source=rss](https://tvn24.pl/biznes/nieruchomosci/zmiany-w-podatku-od-nieruchomosci-garaze-wielostanowiskowe-st7969045?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T05:45:36+00:00

<img alt="Ważne zmiany w podatku od nieruchomości" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bh898b-shutterstock_1337461769-ph7958504/alternates/LANDSCAPE_1280" />
    Skutki zmian w podatku od nieruchomości odczują przedsiębiorcy z wielu branż, przy czym zapłacą gminnemu fiskusowi więcej - podał "Dziennik Gazeta Prawna". Dodał, że skorzystają właściciele miejsc w garażach wielostanowiskowych.

## Janusz Kowalski odchodzi z Suwerennej Polski
 - [https://tvn24.pl/polska/janusz-kowalski-odchodzi-z-suwerennej-polski-st7969072?source=rss](https://tvn24.pl/polska/janusz-kowalski-odchodzi-z-suwerennej-polski-st7969072?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T05:37:49+00:00

<img alt="Janusz Kowalski odchodzi z Suwerennej Polski " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2507806-pap202405280eo-ph7969073/alternates/LANDSCAPE_1280" />
    Janusz Kowalski poinformował w środę rano, że odchodzi z Suwerennej Polski. "Teraz skupiam się na merytorycznej pracy w klubie parlamentarnym Prawa i Sprawiedliwości" - napisał.

## Zrekonstruowali fragment Warszawy lat 30. Wejdziesz do niej smartfonem
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-rekonstrukcja-centrum-warszawy-podroz-w-czasie-dzieki-smartfonowi-st7968305?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-rekonstrukcja-centrum-warszawy-podroz-w-czasie-dzieki-smartfonowi-st7968305?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T05:19:24+00:00

<img alt="Zrekonstruowali fragment Warszawy lat 30. Wejdziesz do niej smartfonem" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-p4exmq-cyfrowa-rekonstrukcja-centrum-warszawy-ph7968071/alternates/LANDSCAPE_1280" />
    Wystarczy stanąć we wskazanym punkcie Warszawy i użyć smartfona, by zobaczyć, jak to miejsce wyglądało niespełna sto lat temu. Efekt niejednego zszokuje, bo na skrzyżowaniu Alej Jerozolimskich z Marszałkowską zmieniło się prawie wszystko.

## Najwyższy stopień alarmów IMGW. Wiatr może rozwijać prędkość do 120 km/h
 - [https://tvn24.pl/tvnmeteo/prognoza/najwyzszy-stopien-alarmow-imgw-wiatr-moze-rozwijac-predkosc-do-120-kmh-st7969031?source=rss](https://tvn24.pl/tvnmeteo/prognoza/najwyzszy-stopien-alarmow-imgw-wiatr-moze-rozwijac-predkosc-do-120-kmh-st7969031?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T05:03:04+00:00

<img alt="Najwyższy stopień alarmów IMGW. Wiatr może rozwijać prędkość do 120 km/h" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fcxqo1-burza-noc-piorun-7942511/alternates/LANDSCAPE_1280" />
    IMGW wydał ostrzeżenia trzeciego, najwyższego stopnia. W południowej Polsce w nocy szaleć będą groźne burze. Spodziewane są porywy wiatru sięgające 120 kilometrów na godzinę i ulewne opady deszczu.

## Ostrzeżenia drugiego stopnia w części kraju. Uważajmy na spiekotę i burze
 - [https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-drugiego-stopnia-w-czesci-kraju-uwazajmy-na-spiekote-i-burze-st7969031?source=rss](https://tvn24.pl/tvnmeteo/prognoza/ostrzezenia-drugiego-stopnia-w-czesci-kraju-uwazajmy-na-spiekote-i-burze-st7969031?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T05:03:04+00:00

<img alt="Ostrzeżenia drugiego stopnia w części kraju. Uważajmy na spiekotę i burze " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-pqsn9h-burze-6077781/alternates/LANDSCAPE_1280" />
    IMGW wydał ostrzeżenia pierwszego i drugiego stopnia przed burzami. Z prognoz wynika, że podczas wyładowań wiatr może się rozpędzać nawet do 110 kilometrów na godzinę. Obowiązują też ostrzeżenia przed upałem. Sprawdź, gdzie aura będzie groźna.

## Upalnie i burzowo. Przed nami trudne godziny
 - [https://tvn24.pl/tvnmeteo/prognoza/upalnie-i-burzowo-przed-nami-trudne-godziny-st7969031?source=rss](https://tvn24.pl/tvnmeteo/prognoza/upalnie-i-burzowo-przed-nami-trudne-godziny-st7969031?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T05:03:04+00:00

<img alt="Upalnie i burzowo. Przed nami trudne godziny" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-1x78rl-burze-6105351/alternates/LANDSCAPE_1280" />
    IMGW ostrzega przed pogodowymi zagrożeniami. W środę w ponad połowie województw obowiązują ostrzeżenia przed upałem i burzami, a miejscami groźnie będzie do późnych godzin nocnych.

## Wyniki Lotto z 18 czerwca 2024. Jakie liczby padły podczas ostatniego losowania?
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-18062024-liczby-z-ostatniego-losowania-st7969043?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-18062024-liczby-z-ostatniego-losowania-st7969043?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T05:01:19+00:00

<img alt="Wyniki Lotto z 18 czerwca 2024. Jakie liczby padły podczas ostatniego losowania?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ee4jh-emerytka-emeryt-kupon-lotto-senior-shutterstock_1464157709-6189722/alternates/LANDSCAPE_1280" />
    We wtorek w Lotto nie padła główna wygrana. Oznacza to, że w najbliższym losowaniu będzie można wygrać dziewięć milionów złotych. Szóstka padła w Lotto Plus. Oto wyniki Lotto i Lotto Plus z 18 czerwca 2024 roku.

## "Nowy poziom sojuszu" Rosji i Korei Północnej
 - [https://tvn24.pl/swiat/wladimir-putin-z-wizyta-w-korei-polnocnej-przywodcy-rosji-i-korei-polnocnej-podpisali-pakt-o-obronie-padly-slowa-o-sojuszu-st7968903?source=rss](https://tvn24.pl/swiat/wladimir-putin-z-wizyta-w-korei-polnocnej-przywodcy-rosji-i-korei-polnocnej-podpisali-pakt-o-obronie-padly-slowa-o-sojuszu-st7968903?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T04:39:55+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5687262-wladimir-putin-i-kim-dzong-un-wymienili-sie-podpisanymi-dokumentami-ph7970068/alternates/LANDSCAPE_1280" />
    Prezydent Rosji Władimir Putin i przywódca Korei Północnej Kim Dzong Un podpisali w środę porozumienie pogłębiające ich współpracę militarną i zobowiązujące do wzajemnej obrony w przypadku ataku. Północnokoreański lider powiedział, że stosunki obu krajów weszły na "nowy poziom sojuszu" i zadeklarował "pełne wsparcie" Rosji w wojnie z Ukrainą.

## "Putin boi się latać". Media: pierwszy taki przypadek
 - [https://tvn24.pl/swiat/putin-boi-sie-latac-media-pierwszy-taki-przypadek-st7969027?source=rss](https://tvn24.pl/swiat/putin-boi-sie-latac-media-pierwszy-taki-przypadek-st7969027?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T04:24:16+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9927805-putin-ph7969032/alternates/LANDSCAPE_1280" />
    Władimir Putin zaczął latać we własnym kraju w asyście myśliwca - napisał niezależny rosyjski portal Agientstwo. Powołuje się między innymi na relacje mieszkańców Jakucji, którą przywódca odwiedził po drodze do Korei Północnej.

## Gdzie jest burza? Poranek głośny od grzmotów
 - [https://tvn24.pl/tvnmeteo/polska/gdzie-jest-burza-burze-w-polsce-w-srode-1906-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-st7969034?source=rss](https://tvn24.pl/tvnmeteo/polska/gdzie-jest-burza-burze-w-polsce-w-srode-1906-mapa-i-radar-burz-sprawdz-gdzie-jest-burza-st7969034?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T04:22:33+00:00

<img alt="Gdzie jest burza? Poranek głośny od grzmotów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6hu6fv-burze-7166874/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W środę 19.06 nad Polską pojawiają się wyładowania atmosferyczne. Towarzyszą im obfite opady deszczu i silny wiatr. Śledź aktualną sytuację pogodową na tvnmeteo.pl.

## UNICEF: to druga najczęstsza przyczyna śmierci dzieci na świecie
 - [https://tvn24.pl/swiat/unicef-to-druga-najczestsza-przyczyna-smierci-dzieci-na-swiecie-st7969022?source=rss](https://tvn24.pl/swiat/unicef-to-druga-najczestsza-przyczyna-smierci-dzieci-na-swiecie-st7969022?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T04:17:57+00:00

<img alt="UNICEF: to druga najczęstsza przyczyna śmierci dzieci na świecie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2436219-globalne-ocieplenie-przemysl-zanieczyszczenia-srodowisko-zdjecie-ilustracyjne-ph7883984/alternates/LANDSCAPE_1280" />
    Zanieczyszczenie powietrza jest drugim czynnikiem ryzyka zgonu dzieci na świecie - wynika z raportu UNICEF. Szczególnie narażone są dzieci poniżej piątego roku życia. W 2021 roku zanieczyszczenie powietrza było przyczyną ponad 8 milionów zgonów na świecie - informuje UNICEF.

## Pogoda na dziś - 19.06. Duże różnice temperatury i gwałtowne burze
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-1906-duze-roznice-temperatury-i-gwaltowne-burze-st7968940?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-1906-duze-roznice-temperatury-i-gwaltowne-burze-st7968940?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-06-19T00:00:00+00:00

<img alt="Pogoda na dziś - 19.06. Duże różnice temperatury i gwałtowne burze" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie3c94d42519f34d02fcedaf16253cf135-pojawia-sie-burze-5246531/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. W środę 19.06 znaczną część Polski nawiedzą burze z obfitymi opadami deszczu i bardzo silnymi porywami wiatru. Padać nie powinno tylko na południowym wschodzie i tam będzie upalnie.

