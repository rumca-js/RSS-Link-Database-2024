# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## How to Protect Your Family During an Apocalyptic Election Year!
 - [https://www.youtube.com/watch?v=HglcqiylyDw](https://www.youtube.com/watch?v=HglcqiylyDw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2024-06-19T22:00:14+00:00

Get Your Infrared Sauna Blanket and PEMF Mat at https://boncharge.com/jp 
Use Code "JP" for 15% Off!

Get your Freedom Merch Here - https://awakenwithjp.com/collections/all

Upcoming LIVE shows - https://awakenwithjp.com/pages/tour

Don Doomsday tells you everything you need to know to protect your family during an apocalyptic election year!

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
https://rumble.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

## I keep the pants clean in The White House
 - [https://www.youtube.com/watch?v=Z8LgVsei5Og](https://www.youtube.com/watch?v=Z8LgVsei5Og)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2024-06-19T17:51:10+00:00

#shorts

