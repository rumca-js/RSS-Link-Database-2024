# Source:New Zealand Herald, URL:https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp, language:en

## Hundreds lose power after high voltage issue in Northland
 - [https://www.nzherald.co.nz/northern-advocate/news/hundreds-lose-power-after-high-voltage-issue-in-northland/FOYTZ6VKKFCY7HUPCMCK7QGG5A](https://www.nzherald.co.nz/northern-advocate/news/hundreds-lose-power-after-high-voltage-issue-in-northland/FOYTZ6VKKFCY7HUPCMCK7QGG5A)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T23:36:20+00:00

'Transpower is working hard to find the fault, and we hope power will be restored soon'.

## Crash sends car ‘spinning’ before man struck walking dog in Auckland’s Mt Albert
 - [https://www.nzherald.co.nz/nz/crash-sends-car-spinning-before-man-struck-walking-dog-in-aucklands-mt-albert/BSR7ULWIPNCQ5DI2UQTPSIWPZE](https://www.nzherald.co.nz/nz/crash-sends-car-spinning-before-man-struck-walking-dog-in-aucklands-mt-albert/BSR7ULWIPNCQ5DI2UQTPSIWPZE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T23:22:39+00:00

The Serious Crash Unit is investigating the fatal incident.

## Build Partners collapse: Who wants $12.7m from construction company?
 - [https://www.nzherald.co.nz/business/build-partners-collapse-who-wants-127m-from-construction-company/QHJCUKJLTZF3LGIG4XJURGNFQY](https://www.nzherald.co.nz/business/build-partners-collapse-who-wants-127m-from-construction-company/QHJCUKJLTZF3LGIG4XJURGNFQY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T22:59:09+00:00

The amount is far worse than the approximately $5m initially thought to be owed.

## New Yorkers catch alleged rapist of 13-year-old girl after he crawled ‘like a cat’ under a car
 - [https://www.nzherald.co.nz/world/new-yorkers-catch-alleged-rapist-of-13-year-old-girl-after-he-crawled-like-a-cat-under-a-car/BCUWZ7EQBRFFNNWSFAS5GMNAYM](https://www.nzherald.co.nz/world/new-yorkers-catch-alleged-rapist-of-13-year-old-girl-after-he-crawled-like-a-cat-under-a-car/BCUWZ7EQBRFFNNWSFAS5GMNAYM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T22:54:46+00:00

'He said, ‘Let me explain!’ I’m like, ‘There’s nothing to explain. You’re a rapist.'

## GDP: New Zealand escapes recession with growth in first quarter
 - [https://www.nzherald.co.nz/business/gdp-new-zealand-dodges-a-deeper-recession-with-growth-in-first-quarter/SFZCD7RG7FCELL3VKWPMS75IHM](https://www.nzherald.co.nz/business/gdp-new-zealand-dodges-a-deeper-recession-with-growth-in-first-quarter/SFZCD7RG7FCELL3VKWPMS75IHM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T22:46:30+00:00

We're out of recession, as power generators and property perform well.

## Countdown: 70 of 185 supermarkets rebranded Woolworths, where new outlets are planned
 - [https://www.nzherald.co.nz/business/countdown-70-of-185-supermarkets-rebranded-woolworths-where-new-outlets-are-planned/AFENKFG5HNE4PAXEX7TQYJQR2Y](https://www.nzherald.co.nz/business/countdown-70-of-185-supermarkets-rebranded-woolworths-where-new-outlets-are-planned/AFENKFG5HNE4PAXEX7TQYJQR2Y)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T21:58:49+00:00

'Dark store' and direct-to-boot offerings as well as EV chargers feature in overhauls.

## One dead and three others seriously injured following crash in Marlborough
 - [https://www.nzherald.co.nz/nz/one-dead-and-three-others-seriously-injured-following-crash-in-marlborough/LNGOUA5NYNH3JDTAVZYI7DX5YU](https://www.nzherald.co.nz/nz/one-dead-and-three-others-seriously-injured-following-crash-in-marlborough/LNGOUA5NYNH3JDTAVZYI7DX5YU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T21:52:08+00:00

The crash involving a van and truck occurred on State Highway 1, near Grovetown.

## Government’s ‘tough on crime’ policy is starting to blow out prison numbers as remand inmates skyrocket
 - [https://www.nzherald.co.nz/kahu/governments-tough-on-crime-policy-is-starting-to-blow-out-prison-numbers-as-remand-inmates-skyrocket/ERITC5QJEFBABIENLKMW24TZ2M](https://www.nzherald.co.nz/kahu/governments-tough-on-crime-policy-is-starting-to-blow-out-prison-numbers-as-remand-inmates-skyrocket/ERITC5QJEFBABIENLKMW24TZ2M)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T20:36:14+00:00

Prisoners on remand rises drastically under new regime.

## Viva’s NZ Wine Awards 2024: 50 Top Bottles To Pop The Cork On Now
 - [https://www.nzherald.co.nz/viva/food-drink/vivas-nz-wine-awards-2024-50-top-bottles-to-pop-the-cork-on-now/MWL67KU2O5A7FAI2KJ6SKKQSQE](https://www.nzherald.co.nz/viva/food-drink/vivas-nz-wine-awards-2024-50-top-bottles-to-pop-the-cork-on-now/MWL67KU2O5A7FAI2KJ6SKKQSQE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T20:00:00+00:00

Wine editor Jo Burzynska selects 50 top wines to try now.

## Australian man arrested after scamming Kiwis out of $200,000 in sophisticated scheme
 - [https://www.nzherald.co.nz/nz/australian-man-arrested-after-scamming-kiwis-out-of-200000-in-sophisticated-scheme/R6YOR7G2J5AJPCWJ2SJF67AT2I](https://www.nzherald.co.nz/nz/australian-man-arrested-after-scamming-kiwis-out-of-200000-in-sophisticated-scheme/R6YOR7G2J5AJPCWJ2SJF67AT2I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T19:52:03+00:00

It is alleged the victims were both hit by the ‘term deposit scam’.

## Kerry Phillips death: Mother of man left dead on side of road still waiting for police apology
 - [https://www.nzherald.co.nz/rotorua-daily-post/news/kerry-phillips-death-mother-of-man-left-dead-on-side-of-road-still-waiting-for-police-apology/JFXUVE63L5ENFNZTFBVOK726CY](https://www.nzherald.co.nz/rotorua-daily-post/news/kerry-phillips-death-mother-of-man-left-dead-on-side-of-road-still-waiting-for-police-apology/JFXUVE63L5ENFNZTFBVOK726CY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T19:35:10+00:00

Police failed to send an officer out until morning.

## Investors cheer as Cyril Ramaphosa sworn in as South Africa’s president
 - [https://www.nzherald.co.nz/business/investors-cheer-as-cyril-ramaphosa-sworn-in-as-south-africas-president/RBO6IQRGPRCYTJMOGTKPEXGLYI](https://www.nzherald.co.nz/business/investors-cheer-as-cyril-ramaphosa-sworn-in-as-south-africas-president/RBO6IQRGPRCYTJMOGTKPEXGLYI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T19:19:12+00:00

Financial Times: Rand and equities rise after ANC seals power-sharing agreement.

## Man flees police across Auckland, crashes, tries to carjack another vehicle
 - [https://www.nzherald.co.nz/nz/man-flees-police-across-auckland-crashes-tries-to-carjack-another-vehicle/XOKWRP4CMBBQTCXLTQFFJWOL24](https://www.nzherald.co.nz/nz/man-flees-police-across-auckland-crashes-tries-to-carjack-another-vehicle/XOKWRP4CMBBQTCXLTQFFJWOL24)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T18:12:17+00:00

The driver fled at high speed from West Auckland to Papakura before crashing.

## Christopher Luxon and Japan’s Fumio Kishida strike intel-sharing deal as Putin visits North Korea for first time in 24 years
 - [https://www.nzherald.co.nz/nz/politics/christopher-luxon-and-japans-fumio-kishida-strike-intel-sharing-deal-as-putin-visits-north-korea-for-first-time-in-24-years/SGRAM7EUL5H5PBLMUIBKE2EENQ](https://www.nzherald.co.nz/nz/politics/christopher-luxon-and-japans-fumio-kishida-strike-intel-sharing-deal-as-putin-visits-north-korea-for-first-time-in-24-years/SGRAM7EUL5H5PBLMUIBKE2EENQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T18:08:04+00:00

NZ and Japan to work more closely on defence.

## Frank Film: Fleur Sullivan’s legendary Moeraki restaurant closes its doors
 - [https://www.nzherald.co.nz/nz/frank-film-fleur-sullivans-legendary-moeraki-restaurant-closes-its-doors/6JF22R4TQ5FJHJUYSOEOQZ66I4](https://www.nzherald.co.nz/nz/frank-film-fleur-sullivans-legendary-moeraki-restaurant-closes-its-doors/6JF22R4TQ5FJHJUYSOEOQZ66I4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T18:00:00+00:00

Renowned restaurateur Fleur Sullivan says she is selling up.

## Tesla grumpy only ‘handpicked allies of the current Government’ consulted on secretive attempt to water down emissions standard
 - [https://www.nzherald.co.nz/nz/politics/tesla-grumpy-only-handpicked-allies-of-the-current-government-consulted-on-secretive-attempt-to-water-down-emissions-standard/GW6XFGMG2FCNZLLAJQFGSA3TI4](https://www.nzherald.co.nz/nz/politics/tesla-grumpy-only-handpicked-allies-of-the-current-government-consulted-on-secretive-attempt-to-water-down-emissions-standard/GW6XFGMG2FCNZLLAJQFGSA3TI4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:57:36+00:00

The secretive consultation has EV importers up in arms.

## Sports Insider: Can Australian rugby be trusted? Plus, how an Olympic surf break could be deadly
 - [https://www.nzherald.co.nz/sport/sports-insider-can-australian-rugby-be-trusted-plus-how-an-olympic-surfbreak-could-be-deadly/EFXELAMTU5HLNAD7QU2P2IV2ZE](https://www.nzherald.co.nz/sport/sports-insider-can-australian-rugby-be-trusted-plus-how-an-olympic-surfbreak-could-be-deadly/EFXELAMTU5HLNAD7QU2P2IV2ZE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:15:00+00:00

OPINION: Enjoy Super Rugby Pacific while you can before the Ockers bail out.

## Arrest warrant, border alert issued for accused money launderer after missed Auckland court appearance
 - [https://www.nzherald.co.nz/nz/arrest-warrant-border-alert-issued-for-accused-money-launderer-after-missed-auckland-court-appearance/RHCC6RQCMRFPZPL35AJHBELL3I](https://www.nzherald.co.nz/nz/arrest-warrant-border-alert-issued-for-accused-money-launderer-after-missed-auckland-court-appearance/RHCC6RQCMRFPZPL35AJHBELL3I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:00:00+00:00

The man is accused of laundering nearly $250k in stolen money from two scam victims.

## Breaking B2B: Cannabis firm Ora Pharm launches AI exchange, export services
 - [https://www.nzherald.co.nz/business/breaking-b2b-cannabis-firm-ora-pharm-launches-ai-exchange-export-services/YGJJ47P27BFC7E56P4IP6T7LNQ](https://www.nzherald.co.nz/business/breaking-b2b-cannabis-firm-ora-pharm-launches-ai-exchange-export-services/YGJJ47P27BFC7E56P4IP6T7LNQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:00:00+00:00

It also has a $7.5m capital raise under way.

## Earthquake-prone review will consider scrapping New Building Standard ratings
 - [https://www.nzherald.co.nz/nz/earthquake-prone-review-will-consider-scrapping-new-building-standard-ratings/MA4DX65PIZB3RMAX4L7AHSA2UE](https://www.nzherald.co.nz/nz/earthquake-prone-review-will-consider-scrapping-new-building-standard-ratings/MA4DX65PIZB3RMAX4L7AHSA2UE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:00:00+00:00

Differing opinions between engineers can make or break a building's earthquake-risk status

## Herald morning quiz: June 20
 - [https://www.nzherald.co.nz/nz/herald-morning-quiz-june-20/QLB5WOH6UNCUFICKDGTT4TEGZA](https://www.nzherald.co.nz/nz/herald-morning-quiz-june-20/QLB5WOH6UNCUFICKDGTT4TEGZA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:00:00+00:00

Test your knowledge with the Herald's morning quiz.

## NZ bank’s trading in government bonds sparked FMA complaint over market manipulation
 - [https://www.nzherald.co.nz/business/nz-banks-trading-in-government-bonds-sparked-fma-complaint-over-market-manipulation/OWZ76QAY5FGFJEVGXLKEWQQDDM](https://www.nzherald.co.nz/business/nz-banks-trading-in-government-bonds-sparked-fma-complaint-over-market-manipulation/OWZ76QAY5FGFJEVGXLKEWQQDDM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:00:00+00:00

The complaint centred on the pricing of Govt bonds issued in August 2022.

## Scott Watson appeal: Convicted killer’s bid to clear his name and when a decision is likely
 - [https://www.nzherald.co.nz/nz/scott-watson-appeal-convicted-killers-latest-bid-to-clear-his-name-and-when-a-decision-is-likely/Y2PW4H7KPVG2NICGBU2X7XFZYM](https://www.nzherald.co.nz/nz/scott-watson-appeal-convicted-killers-latest-bid-to-clear-his-name-and-when-a-decision-is-likely/Y2PW4H7KPVG2NICGBU2X7XFZYM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:00:00+00:00

Convicted killer has always denied murdering pair in the Marlborough Sounds.

## Steve Braunias: The bloody experience of watching a gallbladder being removed
 - [https://www.nzherald.co.nz/lifestyle/steve-braunias-the-bloody-experience-of-watching-a-gallbladder-being-removed/AXA6DOTFDZCURAWQCLPNAMWRTU](https://www.nzherald.co.nz/lifestyle/steve-braunias-the-bloody-experience-of-watching-a-gallbladder-being-removed/AXA6DOTFDZCURAWQCLPNAMWRTU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:00:00+00:00

Inside the blood and guts of a patient having her gall bladder removed.

## The Bain murders 30 years on: David Bain living under new name with family in Waikato
 - [https://www.nzherald.co.nz/nz/the-bain-murders-30-years-on-david-bain-living-under-new-name-with-family-in-waikato/QVMXU6I6NZDR7MYWKI4HTEN2OY](https://www.nzherald.co.nz/nz/the-bain-murders-30-years-on-david-bain-living-under-new-name-with-family-in-waikato/QVMXU6I6NZDR7MYWKI4HTEN2OY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T17:00:00+00:00

The Herald spoke to David Bain on the eve of the 30th anniversary of the murders.

## Mother of missing Marokopa children releases letter from fugitive father
 - [https://www.nzherald.co.nz/nz/mother-of-missing-marokopa-children-releases-letter-from-fugitive-father/JEJDAFKTCJHQZNSFCX7B53HMPE](https://www.nzherald.co.nz/nz/mother-of-missing-marokopa-children-releases-letter-from-fugitive-father/JEJDAFKTCJHQZNSFCX7B53HMPE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T08:41:14+00:00

“I don’t know what to say or do to help you forgive me,” the letter says.

## Person dies following Whangārei workplace incident
 - [https://www.nzherald.co.nz/nz/person-dies-following-whangarei-workplace-incident/VPUJREMFANB5RLDU2KFGO52KDE](https://www.nzherald.co.nz/nz/person-dies-following-whangarei-workplace-incident/VPUJREMFANB5RLDU2KFGO52KDE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T07:56:49+00:00

A police spokesperson said WorkSafe had been advised.

## ‘Loose lipped apprentice PM’ - Fallout from Christopher Luxon’s ‘C-listers’ clanger - Barry Soper
 - [https://www.nzherald.co.nz/nz/loose-lipped-apprentice-pm-fallout-from-christopher-luxons-c-listers-clanger-barry-soper/FSRCM6EAYRBJLBSBTY752T2CPE](https://www.nzherald.co.nz/nz/loose-lipped-apprentice-pm-fallout-from-christopher-luxons-c-listers-clanger-barry-soper/FSRCM6EAYRBJLBSBTY752T2CPE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T07:29:26+00:00

OPINION: PM's trade mission to Japan’s been pretty successful but who would have noticed?

## Auckland train disruptions: Strikes, track issues slammed as third-world by deputy mayor
 - [https://www.nzherald.co.nz/nz/auckland-train-disruptions-strikes-track-issues-slammed-as-third-world-by-deputy-mayor/BYITTKKYEBGYZJFL6OO2XGRT7U](https://www.nzherald.co.nz/nz/auckland-train-disruptions-strikes-track-issues-slammed-as-third-world-by-deputy-mayor/BYITTKKYEBGYZJFL6OO2XGRT7U)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T07:27:27+00:00

'AT is taking us all for mugs as the city’s transport network reaches third-world status.'

## Scammers using fake Clarke Gayford stories to target Kiwis - and how Meta monetises the bogus posts
 - [https://www.nzherald.co.nz/nz/scammers-using-fake-clarke-gayford-stories-to-target-kiwis-and-how-meta-monetises-the-bogus-posts/P7ZHW2ZSAFEBLBYTO4OTKIMFQU](https://www.nzherald.co.nz/nz/scammers-using-fake-clarke-gayford-stories-to-target-kiwis-and-how-meta-monetises-the-bogus-posts/P7ZHW2ZSAFEBLBYTO4OTKIMFQU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T06:30:00+00:00

Scammers are making millions off fake ads on Facebook targeting Kiwis.

## Invercargill Mayor Nobby Clark blames ‘brain fade’ for alleged verbal attacks at event
 - [https://www.nzherald.co.nz/nz/invercargill-mayor-nobby-clark-blames-brain-fade-for-alleged-verbal-attacks-at-event/Z4S7WT74UNFQFJMRHPKL7JQ2QA](https://www.nzherald.co.nz/nz/invercargill-mayor-nobby-clark-blames-brain-fade-for-alleged-verbal-attacks-at-event/Z4S7WT74UNFQFJMRHPKL7JQ2QA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T05:52:03+00:00

Nobby Clark's first term has seen two code of conduct complaints made against him.

## Pedestrian critically injured after being struck by vehicle in Auckland’s Mt Albert
 - [https://www.nzherald.co.nz/nz/pedestrian-critically-injured-after-being-struck-by-vehicle-in-aucklands-mt-albert/5E3W5ZR7C5GNNKUZIF2WXGNQWY](https://www.nzherald.co.nz/nz/pedestrian-critically-injured-after-being-struck-by-vehicle-in-aucklands-mt-albert/5E3W5ZR7C5GNNKUZIF2WXGNQWY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T05:29:33+00:00

The Serious Crash Unit was advised of the incident.

## Govt scraps pay top-up; 900-plus disabled workers miss out on minimum wage
 - [https://www.nzherald.co.nz/nz/politics/as-low-as-2-an-hour-govt-scraps-pay-top-up-900-plus-disabled-workers-miss-out-on-minimum-wage/IBCNHS52N5HF5IBVSFNEFKHQQM](https://www.nzherald.co.nz/nz/politics/as-low-as-2-an-hour-govt-scraps-pay-top-up-900-plus-disabled-workers-miss-out-on-minimum-wage/IBCNHS52N5HF5IBVSFNEFKHQQM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T05:22:10+00:00

Social Development Minister accused of an almost 'eugenic-type definition of productivity'

## The politics of memes: How Biden and Trump are fighting each other on the internet
 - [https://www.nzherald.co.nz/world/the-politics-of-memes-how-biden-and-trump-are-fighting-each-other-on-the-internet/B22MHGSVNZD5JCDVEEMSASIRKM](https://www.nzherald.co.nz/world/the-politics-of-memes-how-biden-and-trump-are-fighting-each-other-on-the-internet/B22MHGSVNZD5JCDVEEMSASIRKM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T05:10:30+00:00

Both presidential campaigns this year have embraced digital memes.

## Operation Selena trial: Prosecutors say drug kingpin Nigel Iuvale, airport worker Tungane Manuel imported hundreds of kilos of meth
 - [https://www.nzherald.co.nz/nz/crime/operation-selena-trial-prosecutors-say-drug-kingpin-nigel-iuvale-airport-worker-tungane-manuel-imported-hundreds-of-kilos-of-meth/TU326CM6FJGQVAGD5WE6CMKB5Q](https://www.nzherald.co.nz/nz/crime/operation-selena-trial-prosecutors-say-drug-kingpin-nigel-iuvale-airport-worker-tungane-manuel-imported-hundreds-of-kilos-of-meth/TU326CM6FJGQVAGD5WE6CMKB5Q)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T04:41:07+00:00

The duo are the last men standing after all other co-defendants pleaded guilty.

## Smarting beverage start-up Ārepa revamps labelling and seeks new approvals for ‘brain drink’ claims
 - [https://www.nzherald.co.nz/business/smarting-beverage-start-up-arepa-revamps-labeling-and-seeks-new-approvals-for-brain-drink-claims/WMMHVBONQ5BCVELDT3BQ5NAKWY](https://www.nzherald.co.nz/business/smarting-beverage-start-up-arepa-revamps-labeling-and-seeks-new-approvals-for-brain-drink-claims/WMMHVBONQ5BCVELDT3BQ5NAKWY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T04:38:48+00:00

The berry juice ran into trouble with Food Standards NZ last year.

## Who is responsible for $17b debt, when did Government drop cancer drugs, and changes in store for ACC and charities tax
 - [https://www.nzherald.co.nz/nz/politics/who-is-responsible-for-17b-debt-when-did-government-drop-cancer-drugs-and-changes-in-store-for-acc-and-charities-tax/4LBL6NZUPVA5BM2O7QROFXOW7I](https://www.nzherald.co.nz/nz/politics/who-is-responsible-for-17b-debt-when-did-government-drop-cancer-drugs-and-changes-in-store-for-acc-and-charities-tax/4LBL6NZUPVA5BM2O7QROFXOW7I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T03:39:08+00:00

Finance Minister Nicola Willis spilled the beans on the Budget at committee.

## Sudden death of child in Rānui, West Auckland: Second infant death at home in two years, cordons remain
 - [https://www.nzherald.co.nz/nz/sudden-death-of-child-in-ranui-west-auckland-second-infant-death-at-home-in-two-years-cordons-remain/NGSWPFX6RRGRRHCTTDJRUMS33Y](https://www.nzherald.co.nz/nz/sudden-death-of-child-in-ranui-west-auckland-second-infant-death-at-home-in-two-years-cordons-remain/NGSWPFX6RRGRRHCTTDJRUMS33Y)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T02:43:15+00:00

Another baby died at the home in 2022, meth was found in her system.

## Fleeing driver who killed mate after Dunedin liquor store burglary sentenced to almost five years in prison
 - [https://www.nzherald.co.nz/nz/fleeing-driver-who-killed-mate-after-dunedin-liquor-store-burglary-sentenced-to-almost-five-years-in-prison/FHAW3UHJLBHALDTWG37H5NP3T4](https://www.nzherald.co.nz/nz/fleeing-driver-who-killed-mate-after-dunedin-liquor-store-burglary-sentenced-to-almost-five-years-in-prison/FHAW3UHJLBHALDTWG37H5NP3T4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T02:05:52+00:00

Robert Taylor fled the scene leaving one mate dying and three others injured.

## Point Wells resident wins seawall, boat ramp battles: ‘Retirement funds eaten up’
 - [https://www.nzherald.co.nz/business/point-wells-resident-wins-seawall-boat-ramp-battles-retirement-funds-eaten-up/U7WBQ37LSVBY3DIUEB4JX5X26I](https://www.nzherald.co.nz/business/point-wells-resident-wins-seawall-boat-ramp-battles-retirement-funds-eaten-up/U7WBQ37LSVBY3DIUEB4JX5X26I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T02:00:00+00:00

'It’s been well in excess of $280,000 and there’s more to spend.'

## PM Christopher Luxon to speak to media ahead of meeting with Japan’s PM Fumio Kishida
 - [https://www.nzherald.co.nz/business/pm-christopher-luxon-to-speak-to-media-ahead-of-meeting-with-japans-pm-fumio-kishida/UJNXDACVRZFY3CFXV2OHI2SQQ4](https://www.nzherald.co.nz/business/pm-christopher-luxon-to-speak-to-media-ahead-of-meeting-with-japans-pm-fumio-kishida/UJNXDACVRZFY3CFXV2OHI2SQQ4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T00:55:54+00:00

PM to wrap up his Japan trip after meeting Japan's PM tonight

## ‘Firebomb’ destroys Dannevirke family’s vehicle: ‘We watched our $100,000 ute go up in flames’
 - [https://www.nzherald.co.nz/hawkes-bay-today/news/fire-bomb-destroys-dannevirke-familys-vehicle-we-watched-our-100000-ute-go-up-in-flames/66J4WLS2CBCOFOBVVTQU2TJXDA](https://www.nzherald.co.nz/hawkes-bay-today/news/fire-bomb-destroys-dannevirke-familys-vehicle-we-watched-our-100000-ute-go-up-in-flames/66J4WLS2CBCOFOBVVTQU2TJXDA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T00:52:34+00:00

A witness saw four masked men - one threw 'something really big' at the ute.

## Body found in hunt for missing man Ronny Okeke, police treating death as suspicious
 - [https://www.nzherald.co.nz/nz/body-found-in-hunt-for-missing-man-ronny-okeke-police-treating-death-as-suspicious/LDW67SQKZZCDZEU74MJ5XZSAEE](https://www.nzherald.co.nz/nz/body-found-in-hunt-for-missing-man-ronny-okeke-police-treating-death-as-suspicious/LDW67SQKZZCDZEU74MJ5XZSAEE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-06-19T00:10:55+00:00

The 60-year-old man disappeared from Sandringham nearly two months ago.

