# Source:It's FOSS News, URL:https://news.itsfoss.com/rss, language:en-US

## Cinnamon 6.2 is Ready for Linux Mint 22 With Subtle Feature Additions
 - [https://news.itsfoss.com/cinnamon-6-2](https://news.itsfoss.com/cinnamon-6-2)
 - RSS feed: https://news.itsfoss.com/rss
 - date published: 2024-06-19T07:19:55+00:00

Cinnamon 6.2 isn't a massive upgrade, but it's the one meant for Linux Mint 22. That makes it exciting!

