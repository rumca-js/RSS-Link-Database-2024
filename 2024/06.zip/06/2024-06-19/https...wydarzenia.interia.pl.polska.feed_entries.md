# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Pogodowy walec sunie przez Polskę. Burze, grad i niemal tysiąc zgłoszeń
 - [https://wydarzenia.interia.pl/kraj/news-pogodowy-walec-sunie-przez-polske-burze-grad-i-niemal-tysiac,nId,7584525](https://wydarzenia.interia.pl/kraj/news-pogodowy-walec-sunie-przez-polske-burze-grad-i-niemal-tysiac,nId,7584525)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-19T16:42:25+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogodowy-walec-sunie-przez-polske-burze-grad-i-niemal-tysiac,nId,7584525"><img align="left" alt="Pogodowy walec sunie przez Polskę. Burze, grad i niemal tysiąc zgłoszeń" src="https://i.iplsc.com/pogodowy-walec-sunie-przez-polske-burze-grad-i-niemal-tysiac/000JCEFCAAJWVR6M-C321.jpg" /></a>Pogoda daje do wiwatu. Przez całą Polskę przetaczają się burze. Strażacy z całego kraju otrzymali już niemal tysiąc zgłoszeń. Najwięcej było w woj. mazowieckim i śląskim. Nawałnica, która przeszła na południowy wschód od Warszawy, przyniosła grad i ulewy w kilku powiatach. Przed godz. 18 IMGW wystosował kolejne ostrzeżenia. </p><br clear="all" />

## COVID-19 wkrótce da o sobie znać. Znany lekarz ostrzega
 - [https://wydarzenia.interia.pl/kraj/news-covid-19-wkrotce-da-o-sobie-znac-znany-lekarz-ostrzega,nId,7584415](https://wydarzenia.interia.pl/kraj/news-covid-19-wkrotce-da-o-sobie-znac-znany-lekarz-ostrzega,nId,7584415)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-19T16:00:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-covid-19-wkrotce-da-o-sobie-znac-znany-lekarz-ostrzega,nId,7584415"><img align="left" alt="COVID-19 wkrótce da o sobie znać. Znany lekarz ostrzega" src="https://i.iplsc.com/covid-19-wkrotce-da-o-sobie-znac-znany-lekarz-ostrzega/000JCDVZ5B6X77FK-C321.jpg" /></a>- Spodziewamy się, że liczba zachorowań na koronawirusa będzie wzrastać - ostrzega Główny Inspektor Sanitarny. Doktor Paweł Grzesiowski dodaje, że zwiększona liczba przypadków notowana jest już w Europie Zachodniej i Stanach Zjednoczonych, a w Polsce ich wzrost nastąpi prawdopodobnie w lipcu. Ekspert radzi, aby w razie niepokojących objawów, udać się do lekarza oraz korzystać z testów &quot;combo&quot;, które pomagają wykryć chorobę.</p><br clear="all" />

## Zamieszanie wokół incydentu na granicy. Stanowcza reakcja służb
 - [https://wydarzenia.interia.pl/kraj/news-zamieszanie-wokol-incydentu-na-granicy-stanowcza-reakcja-slu,nId,7584317](https://wydarzenia.interia.pl/kraj/news-zamieszanie-wokol-incydentu-na-granicy-stanowcza-reakcja-slu,nId,7584317)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-19T12:41:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zamieszanie-wokol-incydentu-na-granicy-stanowcza-reakcja-slu,nId,7584317"><img align="left" alt="Zamieszanie wokół incydentu na granicy. Stanowcza reakcja służb" src="https://i.iplsc.com/zamieszanie-wokol-incydentu-na-granicy-stanowcza-reakcja-slu/000JCAV00L09APPE-C321.jpg" /></a>Kolejny, rzekomy, niebezpieczny incydent na granicy polsko-białoruskiej. Według informacji medialnych, 35-letnia kobieta z Iranu miała zostać postrzelona w oko przez polskich mundurowych. Na doniesienia zareagowały polskie służby, które zdementowały doniesienia i przedstawiły inną wersję zdarzenia.</p><br clear="all" />

## Burza w Trybunale Konstytucyjnym. Pawłowicz starła się z posłem
 - [https://wydarzenia.interia.pl/kraj/news-burza-w-trybunale-konstytucyjnym-pawlowicz-starla-sie-z-posl,nId,7584269](https://wydarzenia.interia.pl/kraj/news-burza-w-trybunale-konstytucyjnym-pawlowicz-starla-sie-z-posl,nId,7584269)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-19T11:43:24+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-burza-w-trybunale-konstytucyjnym-pawlowicz-starla-sie-z-posl,nId,7584269"><img align="left" alt="Burza w Trybunale Konstytucyjnym. Pawłowicz starła się z posłem" src="https://i.iplsc.com/burza-w-trybunale-konstytucyjnym-pawlowicz-starla-sie-z-posl/000JCA6LYAJTJBXT-C321.jpg" /></a>Szef Kancelarii Sejmu Jacek Cichocki oraz komendant Straży Marszałkowskiej Michał Sadoń nie stawili się na środowej rozprawie w Trybunale Konstytucyjnym - poinformowała przewodnicząca składu sędziowskiego w TK Krystyna Pawłowicz. Zachowanie świadków oceniła &quot;skandalicznym postępowaniem&quot;, które uniemożliwia dalsze postępowanie przed TK. Mimo ostrzeżeń Pawłowicz, salę sądową postanowił opuścić także poseł Paweł Śliz. Później gremium zdecydowało w sprawie przepisów o NCBR. TK uznał, że są niezgodne z konstytucją.</p><br clear="all" />

## Prokuratura chce aresztować posła Suwerennej Polski. Ruch Adama Bodnara
 - [https://wydarzenia.interia.pl/kraj/news-prokuratura-chce-aresztowac-posla-suwerennej-polski-ruch-ada,nId,7584138](https://wydarzenia.interia.pl/kraj/news-prokuratura-chce-aresztowac-posla-suwerennej-polski-ruch-ada,nId,7584138)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-19T08:55:54+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prokuratura-chce-aresztowac-posla-suwerennej-polski-ruch-ada,nId,7584138"><img align="left" alt="Prokuratura chce aresztować posła Suwerennej Polski. Ruch Adama Bodnara" src="https://i.iplsc.com/prokuratura-chce-aresztowac-posla-suwerennej-polski-ruch-ada/000JC8WV7YAJUP22-C321.jpg" /></a>Prokurator generalny przekazał do Sejmu wniosek o wyrażenie zgody na pociągnięcie posła Marcina Romanowskiego (Suwerenna Polska) do odpowiedzialności karnej, a także jego zatrzymanie i tymczasowe aresztowanie. Romanowski jako wiceminister sprawiedliwości odpowiadał za Fundusz Sprawiedliwości. Śledczy stawiają mu 11 zarzutów. </p><br clear="all" />

## Anomalie przejmują kontrolę. To zdarza się raz na 20 lat
 - [https://wydarzenia.interia.pl/kraj/news-anomalie-przejmuja-kontrole-to-zdarza-sie-raz-na-20-lat,nId,7584081](https://wydarzenia.interia.pl/kraj/news-anomalie-przejmuja-kontrole-to-zdarza-sie-raz-na-20-lat,nId,7584081)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-19T08:34:19+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-anomalie-przejmuja-kontrole-to-zdarza-sie-raz-na-20-lat,nId,7584081"><img align="left" alt="Anomalie przejmują kontrolę. To zdarza się raz na 20 lat" src="https://i.iplsc.com/anomalie-przejmuja-kontrole-to-zdarza-sie-raz-na-20-lat/000JC8KMCHFPA9GK-C321.jpg" /></a>Potężne upały, które wystąpią w ciągu dnia, będą czymś wyjątkowym. Temperatury w niektórych miastach będą o prawie 9 stopni Celsjusza wyższe niż zwykle o tej porze roku. Według IMGW sytuacja, z którą będziemy mieli do czynienia, zdarza się średnio raz na dziesiątki lat. Sprawdź, w których miastach będzie najgoręcej.</p><br clear="all" />

## Janusz Kowalski opuszcza partię. Jest komentarz Suwerennej Polski
 - [https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-opuszcza-partie-jest-komentarz-suwerennej-po,nId,7583970](https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-opuszcza-partie-jest-komentarz-suwerennej-po,nId,7583970)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-19T05:26:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-opuszcza-partie-jest-komentarz-suwerennej-po,nId,7583970"><img align="left" alt="Janusz Kowalski opuszcza partię. Jest komentarz Suwerennej Polski" src="https://i.iplsc.com/janusz-kowalski-opuszcza-partie-jest-komentarz-suwerennej-po/000JC8LI0F6KD4I8-C321.jpg" /></a>&quot;Dziś przestaję być członkiem Suwerennej Polski. Złożyłem rezygnację&quot; - poinformował poseł Janusz Kowalski. Po kilku godzinach partia wydała lakoniczny komunikat w sprawie. &quot;Janusz Kowalski, jaki jest, każdy wie. Życzymy mu powodzenia na nowej drodze&quot; - podkreślono, zapewniając o kontynuacji &quot;budowy ideowego środowiska na prawicy&quot;. Kowalski ma pozostać członkiem klubu parlamentarnego PiS.</p><br clear="all" />

## Od piekielnych upałów po silne burze. Wyjątkiem trzy województwa
 - [https://wydarzenia.interia.pl/kraj/news-od-piekielnych-upalow-po-silne-burze-wyjatkiem-trzy-wojewodz,nId,7583952](https://wydarzenia.interia.pl/kraj/news-od-piekielnych-upalow-po-silne-burze-wyjatkiem-trzy-wojewodz,nId,7583952)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-06-19T05:11:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-od-piekielnych-upalow-po-silne-burze-wyjatkiem-trzy-wojewodz,nId,7583952"><img align="left" alt="Od piekielnych upałów po silne burze. Wyjątkiem trzy województwa" src="https://i.iplsc.com/od-piekielnych-upalow-po-silne-burze-wyjatkiem-trzy-wojewodz/000JC7FV25I7FIC5-C321.jpg" /></a>Niemal w całej Polsce wydano ostrzeżenia przed upałami i burzami. Temperatury na południu i wschodzie przekroczą 30 stopni. Na północnych krańcach kraju może wystąpić silny deszcz oraz opady gradu. IMGW ostrzega przed niebezpiecznym wiatrem przekraczającym 100 km/h.</p><br clear="all" />

