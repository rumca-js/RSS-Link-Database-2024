# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## Elden Ring Is A Masterpiece
 - [https://www.youtube.com/watch?v=QlzURdmEf-8](https://www.youtube.com/watch?v=QlzURdmEf-8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-06-19T16:00:22+00:00

This is the greatest punch only elden ring run of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/?ref=moist

## Punching only Elden Ring run Malenia fight tonight
 - [https://www.youtube.com/watch?v=NmmeiHHPmxg](https://www.youtube.com/watch?v=NmmeiHHPmxg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-06-19T04:07:37+00:00

Merch https://moistglobal.com/
Comics https://badegg.co/

