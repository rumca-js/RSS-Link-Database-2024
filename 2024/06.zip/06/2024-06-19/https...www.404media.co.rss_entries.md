# Source:404 Media, URL:https://www.404media.co/rss, language:en

## Game Studio's Job Requirement:  'Non Negotiable' Nude Sauna Sessions
 - [https://www.404media.co/game-studios-job-requirement-non-negotiable-sauna-sessions](https://www.404media.co/game-studios-job-requirement-non-negotiable-sauna-sessions)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-06-19T15:10:50+00:00

"It is not about getting naked. It’s about experiencing different kind of sauna," LinkedIn's new 'saunaman' wrote.

## Emails Reveal the Playbook Used Against Libraries Planning ‘Drag Story Time’ Events
 - [https://www.404media.co/lancaster-drag-queen-story-time](https://www.404media.co/lancaster-drag-queen-story-time)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-06-19T14:31:03+00:00

Internal messages shared with 404 Media show how an official’s complaint about a drag queen story hour can spiral into bomb threats against the library hosting it.

