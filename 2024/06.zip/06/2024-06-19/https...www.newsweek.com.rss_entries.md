# Source:Newsweek, URL:https://www.newsweek.com/rss, language:en-US

## Travis Kelce Reveals His Favorite 'Date Night' Meal to Cook For Taylor Swift
 - [https://www.newsweek.com/entertainment/celebrity-news/travis-kelce-reveals-date-night-meal-taylor-swift-1915042](https://www.newsweek.com/entertainment/celebrity-news/travis-kelce-reveals-date-night-meal-taylor-swift-1915042)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T23:05:43+00:00

The NFL star mentioned in an interview at Kelce Jam his favorite meal to make for date night.

## AL East Contenders Lose Starting Pitcher to Season-Ending Surgery
 - [https://www.newsweek.com/sports/mlb/al-east-contenders-lose-starting-pitcher-season-ending-surgery-1915041](https://www.newsweek.com/sports/mlb/al-east-contenders-lose-starting-pitcher-season-ending-surgery-1915041)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T23:00:01+00:00

The hotly contested race at the top of the AL East was dealt a serious curveball Wednesday with a key starting pitcher undergoing season-ending surgery.

## Julia Roberts Shares Rare Throwback Photo of Son Henry
 - [https://www.newsweek.com/entertainment/celebrity-news/julia-roberts-throwback-photo-son-henry-17-birthday-1915038](https://www.newsweek.com/entertainment/celebrity-news/julia-roberts-throwback-photo-son-henry-17-birthday-1915038)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T22:55:38+00:00

Julia Roberts celebrates her son Henry's 17th birthday with a throwback photo, offering fans a peek into her family life.

## Why Fans Believe Kesha Threw Major Shade at Katy Perry
 - [https://www.newsweek.com/entertainment/celebrity-news/kesha-throws-shade-tweet-katy-perry-dr-luke-1915034](https://www.newsweek.com/entertainment/celebrity-news/kesha-throws-shade-tweet-katy-perry-dr-luke-1915034)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T22:46:09+00:00

Kesha's simple post sparked feud rumors after Katy Perry's new single announcement.

## City Breaks 100-Year Heat Record Amid Soaring Temperatures: 'Holy Cow'
 - [https://www.newsweek.com/boston-breaks-100-year-heat-record-amid-soaring-temperatures-1915036](https://www.newsweek.com/boston-breaks-100-year-heat-record-amid-soaring-temperatures-1915036)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T22:43:49+00:00

Boston broke a previous heat record from 1923 of 96 degrees when temperatures reached 98 degrees in the city on Wednesday.

## Top NBA Free Agent Off the Board, Signs New Max Deal
 - [https://www.newsweek.com/sports/nba/top-nba-free-agent-off-board-signs-new-max-deal-1914984](https://www.newsweek.com/sports/nba/top-nba-free-agent-off-board-signs-new-max-deal-1914984)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T22:00:01+00:00

A multi-time All-Star and champion is now spoken for, as the Indiana Pacers wasted little time retaining one of the NBA's best potential free-agents-to-be.

## College World Series Picks: Betting Guide for Texas A&M vs. Florida
 - [https://www.newsweek.com/college-world-series-picks-betting-guide-texas-m-vs-florida-1915005](https://www.newsweek.com/college-world-series-picks-betting-guide-texas-m-vs-florida-1915005)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T21:46:44+00:00

Texas A&amp;M advances to the College World Series championship with a win, while Florida needs to win twice to emerge from the loser's bracket.

## Jessica Biel Called Husband Justin Timberlake Their Family's 'Rock' 1 Day Before DWI Arrest
 - [https://www.newsweek.com/entertainment/celebrity-news/jessica-biel-called-justin-timberlake-her-rock-before-dwi-arrest-1915030](https://www.newsweek.com/entertainment/celebrity-news/jessica-biel-called-justin-timberlake-her-rock-before-dwi-arrest-1915030)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T21:45:34+00:00

The actress praised her husband for father's day just one day before his arrest.

## Map Shows States Asking People to Avoid Using Their Cars
 - [https://www.newsweek.com/map-shows-states-asking-people-avoid-car-use-1915027](https://www.newsweek.com/map-shows-states-asking-people-avoid-car-use-1915027)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T21:44:29+00:00

Starting Wednesday night, people in Ohio, Indiana, and Kentucky are being asked to limit their car usage.

## Supreme Court Has Lost 'Benefit of the Doubt,' Ex-Clerk Warns
 - [https://www.newsweek.com/supreme-court-has-lost-benefit-doubt-former-law-clerk-warned-1915023](https://www.newsweek.com/supreme-court-has-lost-benefit-doubt-former-law-clerk-warned-1915023)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T21:35:51+00:00

"Every passing day further delays a potential trial," said Leah Litman, a former law clerk for Justice Anthony Kennedy.

## Amy Klobuchar's Chances of Beating Republican Rivals in Minnesota: Poll
 - [https://www.newsweek.com/amy-klobuchar-chances-beating-republican-rivals-minnesota-poll-1915009](https://www.newsweek.com/amy-klobuchar-chances-beating-republican-rivals-minnesota-poll-1915009)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T21:12:52+00:00

Eyes will also be on Minnesota heading into November's presidential election as it has emerged as a target for Trump's campaign.

## Baseball World, Celebrities React to Willie Mays' Death
 - [https://www.newsweek.com/sports/mlb/baseball-world-celebrities-react-willie-mays-death-1915015](https://www.newsweek.com/sports/mlb/baseball-world-celebrities-react-willie-mays-death-1915015)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T21:00:01+00:00

The death of Willie Mays, baseball's oldest living Hall of Famer who many regard as the greatest player of all-time, elicited broad, heartwarming reactions

## Aaron Judge's Status Revealed for Yankees vs Orioles Following Injury
 - [https://www.newsweek.com/sports/mlb/aaron-judge-status-revealed-yankees-vs-orioles-following-injury-1914977](https://www.newsweek.com/sports/mlb/aaron-judge-status-revealed-yankees-vs-orioles-following-injury-1914977)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T20:14:26+00:00

The New York Yankees have revealed the status of superstar outfielder Aaron Judge after he left Tuesday's game with an injury.

## Massive NHL Trade Sends All-Star Goaltender West for Pierre-Luc Dubois
 - [https://www.newsweek.com/sports/massive-nhl-trade-sends-all-star-goaltender-west-pierre-luc-dubois-1915020](https://www.newsweek.com/sports/massive-nhl-trade-sends-all-star-goaltender-west-pierre-luc-dubois-1915020)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T20:06:51+00:00

The Washington Capitals and Los Angeles Kings hooked up on a massive trade Wednesday, exchanging fresh-start candidate Pierre-Luc Dubois for a former All-Star.

## Tropical Storm Alberto Forms as Texans Warned of Storm Surge
 - [https://www.newsweek.com/tropical-storm-alberto-storm-surge-texas-1915011](https://www.newsweek.com/tropical-storm-alberto-storm-surge-texas-1915011)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T20:03:12+00:00

The National Hurricane Center predicts storm surges from Tropical Storm Alberto to increase water levels up to four feet in some Texas towns.

## MLB Futures: 3 Best Bets for NL Cy Young Award
 - [https://www.newsweek.com/mlb-futures-3-best-bets-nl-cy-young-award-1914912](https://www.newsweek.com/mlb-futures-3-best-bets-nl-cy-young-award-1914912)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T20:00:01+00:00

Check out our three best bets for the NL Cy Young Award, including thoughts on Phillies ace Zack Wheeler.

## MAGA Republican Race in Virginia Too Close to Call: What Happens Next
 - [https://www.newsweek.com/maga-republican-race-virginia-too-close-call-1914999](https://www.newsweek.com/maga-republican-race-virginia-too-close-call-1914999)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T19:47:45+00:00

As of Wednesday, State Senator John McGuire was leading incumbent Bob Good by 300 votes, although the race was too close to call.

## Travis Kelce Talks Planning the 'Perfect Wedding' in New Ad
 - [https://www.newsweek.com/entertainment/celebrity-news/travis-kelce-talks-planning-perfect-wedding-new-ad-1915017](https://www.newsweek.com/entertainment/celebrity-news/travis-kelce-talks-planning-perfect-wedding-new-ad-1915017)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T19:44:30+00:00

Travis Kelce made telling remarks about a groom's role in wedding planning in the commercial.

## Putin's Meeting With Kim Jong Un Sparks Warning From UK Official
 - [https://www.newsweek.com/putin-kim-meeting-sparks-warning-grant-shapps-1915007](https://www.newsweek.com/putin-kim-meeting-sparks-warning-grant-shapps-1915007)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T19:27:54+00:00

Putin and Kim met in North Korea on Wednesday as they aim to strengthen their relations.

## New Bill Requiring Ten Commandments in Classroom Sparks Outrage: 'Bizarre'
 - [https://www.newsweek.com/new-bill-requiring-ten-commandments-classroom-sparks-outrage-1915012](https://www.newsweek.com/new-bill-requiring-ten-commandments-classroom-sparks-outrage-1915012)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T19:24:27+00:00

Louisiana becomes the first state to require the display of the Ten Commandments, sparking outrage across social media.

## LeBron James' Agent Says There's No Package Deal With His Son, Bronny
 - [https://www.newsweek.com/sports/nba/lebron-james-agent-says-theres-no-package-deal-his-son-bronny-1915000](https://www.newsweek.com/sports/nba/lebron-james-agent-says-theres-no-package-deal-his-son-bronny-1915000)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T19:15:01+00:00

LeBron James' agent, Rich Paul, says there's no package deal with his son, Bronny, in the upcoming NBA Draft.

## Jake Paul on Upcoming Mike Perry Fight: 'It's a Major Risk'
 - [https://www.newsweek.com/sports/jake-paul-upcoming-mike-perry-fight-its-major-risk-1915003](https://www.newsweek.com/sports/jake-paul-upcoming-mike-perry-fight-its-major-risk-1915003)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T19:04:15+00:00

Fighter Jake Paul has reacted to his confirmed fight with Mike Perry on July 20, stating that "It's a major risk."

## WNBA Star Rookie Tears ACL, Out For Year
 - [https://www.newsweek.com/sports/wnba-star-rookie-tears-acl-out-year-1915006](https://www.newsweek.com/sports/wnba-star-rookie-tears-acl-out-year-1915006)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T19:02:07+00:00

A star WNBA rookie has officially torn her ACL and is out for the year. She'll miss the upcoming Olympics, too.

## Ground Beef Recall Sparks Warning to Customers
 - [https://www.newsweek.com/ground-beef-recall-publix-june-1914987](https://www.newsweek.com/ground-beef-recall-publix-june-1914987)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T18:49:07+00:00

The popular Southern supermarket chain Publix issued a recall for ground beef produced at a store in Venice, Florida.

## LA To Open Largest Building for Homeless
 - [https://www.newsweek.com/los-angeles-la-opens-largest-building-homeless-1914958](https://www.newsweek.com/los-angeles-la-opens-largest-building-homeless-1914958)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T18:43:35+00:00

The $165-million project, which will ultimately have three towers, was inaugurated Wednesday with a dedication ceremony.

## 'Camouflage Cameras' Found in California Neighborhood Prompt Warning
 - [https://www.newsweek.com/camouflage-cameras-found-residential-home-prompt-warning-california-1914994](https://www.newsweek.com/camouflage-cameras-found-residential-home-prompt-warning-california-1914994)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T18:35:25+00:00

After responding to a burglary call, a neighbor found a hidden camera, sparking a warning from California police about the dangers.

## Monty Williams to Lakers? The Latest on LA's Head Coaching Search
 - [https://www.newsweek.com/sports/nba/monty-williams-lakers-latest-las-head-coaching-search-1914996](https://www.newsweek.com/sports/nba/monty-williams-lakers-latest-las-head-coaching-search-1914996)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T18:27:40+00:00

Could the Los Angeles Lakers swoop in and sign Monty Williams to be their next head coach?

## Doctor Shares US Heatwave Health Tips and Key Warning Sign
 - [https://www.newsweek.com/doctor-shares-us-heatwave-tips-warning-heat-stroke-1914988](https://www.newsweek.com/doctor-shares-us-heatwave-tips-warning-heat-stroke-1914988)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T18:06:39+00:00

As the U.S. endures record-breaking temperatures, how can you and your family stay safe?

## Maps Reveal Pollution Fallout From Ohio Train Derailment—With 16 States Hit
 - [https://www.newsweek.com/ohio-train-derailment-chemical-pollution-maps-1914972](https://www.newsweek.com/ohio-train-derailment-chemical-pollution-maps-1914972)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T18:06:01+00:00

"In total, the impacted region encompassed parts of [540,000 square miles] or 14 percent of the U.S. land area," the researchers wrote in the paper.

## Lakes on Saturn's Largest Moon Titan Shaped by Waves, Scientists Say
 - [https://www.newsweek.com/titan-saturn-lakes-formed-waves-1914450](https://www.newsweek.com/titan-saturn-lakes-formed-waves-1914450)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T18:00:01+00:00

"At the edge of one of Titan's seas, we might see waves of liquid methane and ethane lapping on the shore," a researcher said.

## Scientists Reveal How Keto Diet May Boost Your Brain and Lifespan
 - [https://www.newsweek.com/scientists-reveal-keto-diet-boost-brain-lifespan-1914974](https://www.newsweek.com/scientists-reveal-keto-diet-boost-brain-lifespan-1914974)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:54:54+00:00

"Our work indicates that the effects of the ketogenic diet benefit brain function broadly," the researchers told Newsweek.

## Stanley Cup Final Odds: Can Oilers Complete Comeback?
 - [https://www.newsweek.com/stanley-cup-final-odds-can-oilers-complete-comeback-1914946](https://www.newsweek.com/stanley-cup-final-odds-can-oilers-complete-comeback-1914946)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:52:00+00:00

Edmonton's Stanley Cup odds are now shorter than 3-to-1 across the board after Tuesday's Game 5 win cut Florida's series lead to 3-2.

## Woman Travels 1,000 Miles To Adopt Dog Rescued From China Meat Market
 - [https://www.newsweek.com/woman-travels-1000-miles-adopt-dog-rescued-china-meat-market-1914578](https://www.newsweek.com/woman-travels-1000-miles-adopt-dog-rescued-china-meat-market-1914578)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:48:25+00:00

Rupert's situation first came to the attention of a shelter in China after his owner brought him in to have all his teeth removed.

## Travis Kelce Reacts to Typo on Chiefs' Super Bowl Ring
 - [https://www.newsweek.com/sports/nfl/travis-kelce-reacts-typo-chiefs-super-bowl-ring-1914983](https://www.newsweek.com/sports/nfl/travis-kelce-reacts-typo-chiefs-super-bowl-ring-1914983)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:43:43+00:00

The Kansas City Chiefs have a massive typo on their 2023 Super Bowl ring, and Travis Kelce has now responded to the mistake.

## Stunning Images Show Sea Creatures Discovered Glowing for First Time
 - [https://www.newsweek.com/fluorescence-discovered-27-new-marine-species-biology-1914863](https://www.newsweek.com/fluorescence-discovered-27-new-marine-species-biology-1914863)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:32:29+00:00

Scientists have discovered 27 species capable of fluorescing that weren't previously known to have this ability.

## Joe Biden's Mass Amnesty Is a Lawless Act of Crass Politicking | Opinion
 - [https://www.newsweek.com/joe-bidens-mass-amnesty-lawless-act-crass-politicking-opinion-1914980](https://www.newsweek.com/joe-bidens-mass-amnesty-lawless-act-crass-politicking-opinion-1914980)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:27:49+00:00

Get your daily dose of politics, law, and culture with Josh Hammer Premium by subscribing to Newsweek today.

## Drivers Told to Avoid Gas Stations in These Two States
 - [https://www.newsweek.com/air-quality-warning-national-weather-service-indiana-michigan-gas-refuel-1914894](https://www.newsweek.com/air-quality-warning-national-weather-service-indiana-michigan-gas-refuel-1914894)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:23:36+00:00

Air quality alerts have been issued for places where levels of ozone "may approach or exceed unhealthy standards."

## Steelers News: Pittsburgh Reportedly Working on Hosting Game in Surprising European Country
 - [https://www.newsweek.com/sports/nfl/steelers-news-pittsburgh-reportedly-working-hosting-game-surprising-european-country-1914968](https://www.newsweek.com/sports/nfl/steelers-news-pittsburgh-reportedly-working-hosting-game-surprising-european-country-1914968)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:17:18+00:00

The Pittsburgh Steelers are reportedly actively working on being the first team to host a regular-season game in a surprising European country.

## Woman Tries To Leave House, but Her Cat Has Other Plans: 'Call The Police'
 - [https://www.newsweek.com/woman-tries-leave-house-her-cat-has-other-plans-call-police-1914687](https://www.newsweek.com/woman-tries-leave-house-her-cat-has-other-plans-call-police-1914687)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:15:19+00:00

The cat began hissing at her every time the woman went near the car keys, making it clear that she wasn't allowed to go out.

## Jessica Biel Is All Smiles on Set After Husband Justin Timberlake's Arrest
 - [https://www.newsweek.com/entertainment/celebrity-news/jessica-biel-smiles-better-sister-after-justin-timberlake-dwi-arrest-1914965](https://www.newsweek.com/entertainment/celebrity-news/jessica-biel-smiles-better-sister-after-justin-timberlake-dwi-arrest-1914965)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:15:18+00:00

Jessica Biel appeared to be in a good mood while filming 'The Better Sister' in NYC.

## Why Millennial Woman Is Convinced She 'Manifested' Her Boyfriend Goes Viral
 - [https://www.newsweek.com/millennial-woman-convinced-she-manifested-her-boyfriend-goes-viral-1914829](https://www.newsweek.com/millennial-woman-convinced-she-manifested-her-boyfriend-goes-viral-1914829)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:13:08+00:00

"The work, for me at least, has been to get to a place where I believe I am truly worthy of the things I'm manifesting," she said.

## Celine Dion In Tears As She Demonstrates How Rare Disease Affects Voice
 - [https://www.newsweek.com/celine-dion-tears-singing-voice-rare-disease-sps-1914899](https://www.newsweek.com/celine-dion-tears-singing-voice-rare-disease-sps-1914899)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:08:48+00:00

The legendary diva broke down as she tried to sing one of her iconic songs but could barely get the sound out.

## Heat Warning Tells Residents in One State to Avoid Alcohol
 - [https://www.newsweek.com/heat-warning-tells-arizona-residents-avoid-alcohol-1914963](https://www.newsweek.com/heat-warning-tells-arizona-residents-avoid-alcohol-1914963)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:07:01+00:00

High heat is impacting many states this week, prompting meteorologists to urge people to take proper precautions to stay cool.

## Woman Describes 'Uncomfortable' Experience When She Reveals Her Job
 - [https://www.newsweek.com/women-medicine-female-doctor-1914917](https://www.newsweek.com/women-medicine-female-doctor-1914917)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:05:33+00:00

"Her jaw just dropped," the woman said as she shared her frustration with people's internalized biases.

## Man on Train Overhears Life Advice From Kid—'Cured My Self-Consciousness'
 - [https://www.newsweek.com/man-overhears-advice-kid-wisdom-train-1914947](https://www.newsweek.com/man-overhears-advice-kid-wisdom-train-1914947)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T17:02:33+00:00

After overhearing a conversation between two students, the poster said one's sage wisdom would "save me some money with therapy."

## Donald Trump Campaign's Juneteenth Message Compared to Joe Biden's
 - [https://www.newsweek.com/donald-trump-joe-biden-juneteenth-messages-1914960](https://www.newsweek.com/donald-trump-joe-biden-juneteenth-messages-1914960)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:58:44+00:00

President Joe Biden's reelection campaign slammed Donald Trump's past comments about Juneteenth on Wednesday.

## Female Flight Attendant Shares the 'Dark Reality' of the Profession
 - [https://www.newsweek.com/flight-attendant-job-information-career-advice-tiktok-1914936](https://www.newsweek.com/flight-attendant-job-information-career-advice-tiktok-1914936)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:57:49+00:00

The job can be "quite unhealthy," the flight attendant told Newsweek, and many "suffer from bloating" as a result of their duties.

## Hysterics Over The Difference Between Sphynx Cat And Maine Coon In The Cold
 - [https://www.newsweek.com/hysterics-over-difference-between-sphynx-cat-maine-coon-cold-1914691](https://www.newsweek.com/hysterics-over-difference-between-sphynx-cat-maine-coon-cold-1914691)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:57:35+00:00

Just because they're hairless, it doesn't mean sphynx cats don't need grooming. In fact, they need even more care than their fluffy counterparts.

## Mom Spots Mistake in Second-Grader's Homework, so She Messages the Teacher
 - [https://www.newsweek.com/mom-convinced-theres-mistake-second-graders-spelling-homework-1914255](https://www.newsweek.com/mom-convinced-theres-mistake-second-graders-spelling-homework-1914255)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:54:14+00:00

Ariel Villarreal said the "moral of the story is to check your kids' homework and work with them one-on-one."

## Prince Harry and Meghan's 'Adorable' Balcony Moments Go Viral
 - [https://www.newsweek.com/prince-harry-meghan-markle-balcony-viral-tiktok-1914725](https://www.newsweek.com/prince-harry-meghan-markle-balcony-viral-tiktok-1914725)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:50:37+00:00

Meghan Markle curtsying and Prince Harry in uniform on the Buckingham Palace balcony went viral on TikTok.

## Model Says Millennial Fashion 'Staple' Is Out, Divides Opinion
 - [https://www.newsweek.com/model-declares-fashion-staple-out-1914906](https://www.newsweek.com/model-declares-fashion-staple-out-1914906)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:45:56+00:00

She is about to clear out her wardrobe in favor of styles that are "so much more in fashion right now," but not everyone agrees.

## Michael Cohen's Former Lawyer Says Donald Trump Should Be Pardoned
 - [https://www.newsweek.com/cohenr-lawyer-adviser-davis-trump-should-pardoned-biden-hochul-1914937](https://www.newsweek.com/cohenr-lawyer-adviser-davis-trump-should-pardoned-biden-hochul-1914937)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:45:39+00:00

Lanny Davis said Biden should deflate the hyper-partisanship of the campaign by supporting a pardon and commutation for Trump.

## Cat Wearing Life Jacket Greets Kayakers in Heartwarming Video: 'I'd Melt'
 - [https://www.newsweek.com/cat-wearing-life-jacket-greets-kayakers-heartwarming-video-id-melt-1914733](https://www.newsweek.com/cat-wearing-life-jacket-greets-kayakers-heartwarming-video-id-melt-1914733)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:43:20+00:00

The Siberian cat was graciously sitting on the kayak with his owner, meowing at passing kayakers.

## Gen Zer Shares 'Hot Take' From Her Dad That Made Her Rethink Dating
 - [https://www.newsweek.com/gen-z-shares-hot-take-dad-made-dating-1914833](https://www.newsweek.com/gen-z-shares-hot-take-dad-made-dating-1914833)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:40:15+00:00

"My dad has all the advice," she wrote in a TikTok comment. She said she calls her father twice a day to hear his words of wisdom.

## Mark Cuban's Donald Trump Comment Takes Off Online
 - [https://www.newsweek.com/mark-cuban-donald-trump-why-do-you-hate-him-x-twitter-1914852](https://www.newsweek.com/mark-cuban-donald-trump-why-do-you-hate-him-x-twitter-1914852)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:39:52+00:00

The business mogul is an outspoken critic of the former president, previously comparing him to a "snake oil salesman."

## How to Stay Safe in a Heatwave
 - [https://www.newsweek.com/heatwave-safety-medical-advice-1914940](https://www.newsweek.com/heatwave-safety-medical-advice-1914940)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:36:15+00:00

In the U.S., more people die from extreme heat than any other natural disaster. Experts have advice on staying safe in a heatwave.

## This Doctor's Israeli Flag Keeps Getting Torn Down
 - [https://www.newsweek.com/doctors-israeli-flag-torn-down-israel-baltimore-maryland-third-time-1914949](https://www.newsweek.com/doctors-israeli-flag-torn-down-israel-baltimore-maryland-third-time-1914949)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:34:32+00:00

An Israeli flag was ripped from its pole outside of a Baltimore doctor's office for the third time since October.

## Cowboys Reportedly 'Not Far Very Along' With Extensions for Dak Prescott, CeeDee Lamb
 - [https://www.newsweek.com/sports/nfl/cowboys-reportedly-not-far-very-along-extensions-dak-prescott-ceedee-lamb-1914941](https://www.newsweek.com/sports/nfl/cowboys-reportedly-not-far-very-along-extensions-dak-prescott-ceedee-lamb-1914941)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:33:20+00:00

Any progress on the Dallas Cowboys' contract extensions with Dak Prescott, CeeDee Lamb, and Micah Parsons is reportedly not moving quickly at all.

## Human Arm Found on Beach Closes Murder Mystery
 - [https://www.newsweek.com/human-arm-found-beach-closes-murder-mystery-1914836](https://www.newsweek.com/human-arm-found-beach-closes-murder-mystery-1914836)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:31:47+00:00

DNA testing has confirmed a human arm discovered on a beach is that of murdered teenager Sade Robinson.

## Internet Urges Man Not to Leave His Girlfriend After Wife Wants Him Back
 - [https://www.newsweek.com/internet-urges-man-not-leave-girlfriend-wife-wants-back-1914853](https://www.newsweek.com/internet-urges-man-not-leave-girlfriend-wife-wants-back-1914853)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:31:01+00:00

After three years separated from his wife, the man got an unexpected phone call that left him questioning what to do next.

## Basic Income for Homeless Saved Taxpayers Thousands, Study Reveals
 - [https://www.newsweek.com/basic-income-denver-homeless-taxpayers-1914911](https://www.newsweek.com/basic-income-denver-homeless-taxpayers-1914911)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:30:52+00:00

Providing homeless people in Denver with a basic income saved nearly $600,000 on public services in one year, the study found.

## Mom On Family Holiday Explains Why Parents Never 'Go On Vacation'
 - [https://www.newsweek.com/mom-family-holiday-explains-why-parents-never-go-vacation-1914910](https://www.newsweek.com/mom-family-holiday-explains-why-parents-never-go-vacation-1914910)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:29:08+00:00

Nika Diwa told Newsweek she posted the viral video to "reflect the realities of parenthood."

## Princess Kate's Top 5 Royal Ascot Fashion Moments
 - [https://www.newsweek.com/princess-kate-top-5-royal-ascot-fashion-moment-1914740](https://www.newsweek.com/princess-kate-top-5-royal-ascot-fashion-moment-1914740)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:28:24+00:00

Since her marriage in 2011, Kate has debuted a number of high-fashion looks for the Royal Ascot horseracing event.

## California's Move to Ban Non-Electric Trains Sparks Backlash: 'Unworkable'
 - [https://www.newsweek.com/californias-move-ban-trains-sparks-backlash-unworkable-1914837](https://www.newsweek.com/californias-move-ban-trains-sparks-backlash-unworkable-1914837)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:25:43+00:00

A plan to ban non-carbon-neutral trains in California by 2035 has been condemned by industry bodies.

## Aileen Cannon May Be an 'Outlier' in Upcoming Trump Ruling: Legal Analyst
 - [https://www.newsweek.com/aileen-cannon-outlier-upcoming-trump-ruling-1914925](https://www.newsweek.com/aileen-cannon-outlier-upcoming-trump-ruling-1914925)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:23:21+00:00

Glenn Kirschner raised concerns about whether Cannon will agree to impose a gag order on the former president.

## Republican Candidate Tells Black Americans To Leave US in Juneteenth Message
 - [https://www.newsweek.com/gop-candidate-valentina-gomez-juneteenth-missouri-1914897](https://www.newsweek.com/gop-candidate-valentina-gomez-juneteenth-missouri-1914897)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:22:38+00:00

Valentina Gomez, running for Missouri secretary of state, previously caused outrage for urging voters not to be "weak and gay."

## Russia's Accidental Self-Bombings Pass Grim Milestone
 - [https://www.newsweek.com/russia-ukraine-bombing-accidental-milestone-1914904](https://www.newsweek.com/russia-ukraine-bombing-accidental-milestone-1914904)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:21:18+00:00

Telegram channel Astra reported that Russia dropped three bombs in the Belgorod region this week.

## What Woman Did After Feeling 'Sense of Dread' in Thrift Store Backed
 - [https://www.newsweek.com/woman-left-feeling-dread-thrift-store-1914919](https://www.newsweek.com/woman-left-feeling-dread-thrift-store-1914919)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:19:44+00:00

The shopper's experience has riled up internet users, with one saying: "People can be so greedy and nasty."

## Fact Check: Was American F-22 'Raptor' Shot Down by Houthis Over Red Sea?
 - [https://www.newsweek.com/fact-check-was-american-f-22-raptor-shot-down-houthis-over-red-sea-1914443](https://www.newsweek.com/fact-check-was-american-f-22-raptor-shot-down-houthis-over-red-sea-1914443)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:16:59+00:00

The F-22, one of the most sophisticated fighter jets in the world, was said to have been shot down by Houthis, according to viral social media posts.

## Houthi Missiles Sink Ship Carrying Russian Cargo
 - [https://www.newsweek.com/houthi-missiles-sink-russian-cargo-ship-1914920](https://www.newsweek.com/houthi-missiles-sink-russian-cargo-ship-1914920)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:13:32+00:00

A Greek merchant ship carrying coal shipments for Russia sank after being hit by Houthi missiles in the Red Sea

## Pistons News: Monty Williams Dismissed With Millions Still Left on Contract
 - [https://www.newsweek.com/sports/nba/pistons-news-monty-williams-dismissed-millions-still-left-contract-1914952](https://www.newsweek.com/sports/nba/pistons-news-monty-williams-dismissed-millions-still-left-contract-1914952)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:12:46+00:00

The Detroit Pistons have dismissed head coach Monty Williams after one season, leaving millions of dollars left on his contract.

## Woman Cheered for Standing Up to Mother-in-Law Telling Her To Get a Job
 - [https://www.newsweek.com/full-time-mom-mother-law-problems-1914670](https://www.newsweek.com/full-time-mom-mother-law-problems-1914670)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:11:30+00:00

A mom of four shared her dilemma with Reddit after she was forced to move in with her husband's mom who has now told her to return to work.

## Pet Owners Urged to Follow '7-Seconds Rule' During Heatwave
 - [https://www.newsweek.com/pet-owners-urged-follow-seven-second-rule-heatwave-1914921](https://www.newsweek.com/pet-owners-urged-follow-seven-second-rule-heatwave-1914921)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T16:11:10+00:00

Pavement is much hotter than the outdoor temperature, and if the thermometer reads 85 degrees, it could be too hot for pets.

## Bride-To-Be Sets Up Wedding Registry, Then Gets Shocking Text From Fiancé
 - [https://www.newsweek.com/bride-sets-wedding-registry-gets-shocking-text-fiance-1914812](https://www.newsweek.com/bride-sets-wedding-registry-gets-shocking-text-fiance-1914812)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:37:13+00:00

Caroline Wise said she "never expected" her husband-to-be's "silly mistake" to go viral.

## Woman Shares the View From Her Window That Kills Her Each Day: 'The Guilt'
 - [https://www.newsweek.com/woman-shares-view-window-kills-each-day-guilt-1914775](https://www.newsweek.com/woman-shares-view-window-kills-each-day-guilt-1914775)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:36:38+00:00

Elmo gives his owner, Lowri, "a reason to leave the house," but, like many pet owners, she still feels guilty about it.

## 'Modern Family' WhatsApp Commercial Mocked
 - [https://www.newsweek.com/whatsapp-modern-family-reunion-1914736](https://www.newsweek.com/whatsapp-modern-family-reunion-1914736)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:35:54+00:00

The cast of "Modern Family" has reunited, but not in a way that fans expected.

## Cucumber Recall Map as FDA Issues Highest Alert in Four States
 - [https://www.newsweek.com/cucumer-recall-map-fda-alert-1914679](https://www.newsweek.com/cucumer-recall-map-fda-alert-1914679)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:35:04+00:00

The Class I risk classification applies to four states.

## Oldest Ever Liquid Wine Discovered—With Gruesome Surprise Inside
 - [https://www.newsweek.com/oldest-ever-liquid-wine-discovered-gruesome-surprise-inside-1914849](https://www.newsweek.com/oldest-ever-liquid-wine-discovered-gruesome-surprise-inside-1914849)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:33:07+00:00

There is evidence that wine was placed together with water and foods in Roman burials to accompany the deceased in their transition to the afterlife.

## Influencer, 58, Inspires Followers not to Fear Aging—'Greatest Happiness'
 - [https://www.newsweek.com/influencer-inspires-followers-not-fear-aging-1914866](https://www.newsweek.com/influencer-inspires-followers-not-fear-aging-1914866)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:31:11+00:00

"Are you afraid of getting older?" Gina Drewalowski asked viewers, before sharing why they shouldn't fear "time."

## Clippers Poach Celtics Exec, Former ESPN Analyst to be Lead Assistant
 - [https://www.newsweek.com/sports/nba/clippers-poach-celtics-exec-former-espn-analyst-lead-assistant-1914580](https://www.newsweek.com/sports/nba/clippers-poach-celtics-exec-former-espn-analyst-lead-assistant-1914580)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:30:01+00:00

The Clippers are making a bold move by hiring a familiar name to assist head coach Tyronn Lue as they look to go farther in the postseason than ever.

## The Arctic May Be Turning Green Sooner Than Scientists Thought
 - [https://www.newsweek.com/arctic-turn-green-1914815](https://www.newsweek.com/arctic-turn-green-1914815)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:27:24+00:00

A new study has found that more light is reaching algae beneath the ice due to global warming, which could have profound implications.

## Letitia James Distributes Half of $112 Million Lawsuit Win
 - [https://www.newsweek.com/ketitia-james-distributes-half-112-million-juul-lawsuit-1914800](https://www.newsweek.com/ketitia-james-distributes-half-112-million-juul-lawsuit-1914800)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:25:35+00:00

The New York attorney general's office has been distributing settlement funds from electronic cigarette-maker Juul Labs Inc.

## Internet Defends Woman's Home Renovation After Viral Backlash—'Stunning'
 - [https://www.newsweek.com/home-renovation-backlash-viral-tiktok-1914838](https://www.newsweek.com/home-renovation-backlash-viral-tiktok-1914838)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:21:22+00:00

Some social media users criticized the renovation, with one describing it as an "open concept gray nightmare," while others loved the "gorgeous work."

## Heat Wave Strikes Early—Record Temperatures Forecast in Maps
 - [https://www.newsweek.com/record-heatwave-midwest-northeast-america-national-guard-1914760](https://www.newsweek.com/record-heatwave-midwest-northeast-america-national-guard-1914760)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:14:17+00:00

Dozens of temperature records are forecast to be broken and the National Guard has been called in amid dangerous highs.

## Dog's Perfect Timing With New Toy Leaves Internet In Stitches—'Learns Fast'
 - [https://www.newsweek.com/dogs-perfect-timing-new-water-toy-1914855](https://www.newsweek.com/dogs-perfect-timing-new-water-toy-1914855)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:09:31+00:00

The dog's hilarious antics have delighted social media users, leading one person to joke that "he was just helping" by showing how it works.

## MLB Prop Picks: 3 Best Bets for Wednesday (June 19)
 - [https://www.newsweek.com/mlb-prop-picks-3-best-bets-wednesday-june-19-1914841](https://www.newsweek.com/mlb-prop-picks-3-best-bets-wednesday-june-19-1914841)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:04:11+00:00

Check out our three best MLB player prop picks for today, Wednesday June 19th, including our favorite MLB home run prediction for today!

## Russia Amasses Huge 'Striking Fist' to Attack Borova: Report
 - [https://www.newsweek.com/ukraine-russia-borova-kharkiv-1914824](https://www.newsweek.com/ukraine-russia-borova-kharkiv-1914824)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:00:05+00:00

Ukrainian Telegram channel DeepState said its analysis showed up to 10,000 Russian troops had gathered in the Kharkiv region.

## Williams F1 Announces New Head Of Aerodynamics Filling Significant Void Lasting Over A Year
 - [https://www.newsweek.com/sports/formula1/williams-f1-announces-new-head-aerodynamics-filling-significant-void-lasting-over-year-1914786](https://www.newsweek.com/sports/formula1/williams-f1-announces-new-head-aerodynamics-filling-significant-void-lasting-over-year-1914786)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:00:02+00:00

Williams Formula 1 team has appointed Adam Kenyon, a former Mercedes and Red Bull aerodynamics expert, as their new head of aerodynamics.

## Yankees 'Pissed Off' at Orioles After Aaron Judge Injury; Will They Seek Revenge?
 - [https://www.newsweek.com/sports/mlb/yankees-pissed-off-orioles-after-aaron-judge-injury-will-they-seek-revenge-1914592](https://www.newsweek.com/sports/mlb/yankees-pissed-off-orioles-after-aaron-judge-injury-will-they-seek-revenge-1914592)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T15:00:01+00:00

New York Yankees players are not happy with the Baltimore Orioles after their pitcher hit Aaron Judge with a fastball, forcing Judge to leave Tuesday's game.

## Woman Asks Internet for Help to Get Designer Bag—Goes Better Than Expected
 - [https://www.newsweek.com/woman-internet-help-get-designer-bag-1914683](https://www.newsweek.com/woman-internet-help-get-designer-bag-1914683)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T14:54:55+00:00

A shocked Kayla Ellis told Newsweek after her video received over 66 million views: "I'm a mom and a doctor from a small town."

## Medical Debt Forgiveness Given Boost From Americans
 - [https://www.newsweek.com/medical-debt-forgiveness-boost-poll-1914817](https://www.newsweek.com/medical-debt-forgiveness-boost-poll-1914817)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T14:52:36+00:00

More than half of all Americans believe the government should allow for more help with medical debts.

## 2024 Travelers Championship Picks: Current Odds, 5 Best Bets
 - [https://www.newsweek.com/2024-travelers-championship-picks-current-odds-5-best-bets-1914820](https://www.newsweek.com/2024-travelers-championship-picks-current-odds-5-best-bets-1914820)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T14:51:16+00:00

Check out the latest betting odds and five of the best Travelers Championship picks for this week's tournament.

## Tropical Storm Update: Spaghetti Models Show Impacts Hitting 3 States
 - [https://www.newsweek.com/tropical-storm-alberto-update-spaghetti-models-impacts-three-states-1914847](https://www.newsweek.com/tropical-storm-alberto-update-spaghetti-models-impacts-three-states-1914847)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T14:51:12+00:00

The storm is expected to make landfall in Mexico by Wednesday evening, but warnings have been issued for the southern U.S.

## US Boost for Taiwan Amid Rising Chinese Military Pressure
 - [https://www.newsweek.com/us-taiwan-arms-sale-china-military-pressure-1914901](https://www.newsweek.com/us-taiwan-arms-sale-china-military-pressure-1914901)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T14:29:04+00:00

An arms sale worth $360 million from the U.S. to Taiwan has been approved.

## Putin's Message to the North Korean People
 - [https://www.newsweek.com/putins-message-north-korean-people-1914697](https://www.newsweek.com/putins-message-north-korean-people-1914697)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T14:27:08+00:00

The Russian president has published an article in North Korean state-owned newspaper praising cooperation between the two countries.

## Mom Shares 'Unpopular' Regret About Her Third Pregnancy
 - [https://www.newsweek.com/mom-shares-unpopular-regret-third-pregnancy-1914798](https://www.newsweek.com/mom-shares-unpopular-regret-third-pregnancy-1914798)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T14:15:02+00:00

The mom-of-five told Newsweek about her "chaotic" birth.

## Aston Martin F1 Chief Delivers Blow - 'Car Is Tough To Drive'
 - [https://www.newsweek.com/sports/formula1/aston-martin-f1-chief-delivers-blow-car-tough-drive-1914801](https://www.newsweek.com/sports/formula1/aston-martin-f1-chief-delivers-blow-car-tough-drive-1914801)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T14:00:01+00:00

Aston Martin's Formula 1 team boss, Mike Krack, has admitted that their 2024 car, the AMR24, is challenging to drive and requires significant modifications.

## Prince William Arrives For Major Event Without Princess Kate
 - [https://www.newsweek.com/prince-william-arrives-major-event-without-princess-kate-cancer-1914770](https://www.newsweek.com/prince-william-arrives-major-event-without-princess-kate-cancer-1914770)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:59:06+00:00

William arrived at the Royal Ascot horse racing meeting on Wednesday without Kate who is continuing her cancer treatment.

## MLB Power Rankings: Mets Skyrocket, Cubs Plummet, Dodgers Rise in Wild Week
 - [https://www.newsweek.com/sports/mlb/mlb-power-rankings-mets-skyrocket-cubs-plummet-dodgers-rise-wild-week-1914571](https://www.newsweek.com/sports/mlb/mlb-power-rankings-mets-skyrocket-cubs-plummet-dodgers-rise-wild-week-1914571)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:59:02+00:00

The 11th edition of the MLB Power Rankings brings chaos, with tons of teams moving all over the board.

## Willie Mays and Barack Obama's Four Iconic Encounters: 'Inspiration'
 - [https://www.newsweek.com/willies-mays-dead-barack-obama-1914864](https://www.newsweek.com/willies-mays-dead-barack-obama-1914864)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:58:43+00:00

Baseball legend Willie Mays and President Barack Obama forged a remarkable bond that transcended sports and politics.

## Tears As Cat Finally Adopted After 1145 Days In shelter—'Here's To forever'
 - [https://www.newsweek.com/tears-cat-finally-adopted-1145-days-shelter-1914555](https://www.newsweek.com/tears-cat-finally-adopted-1145-days-shelter-1914555)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:55:15+00:00

Lucy Lou was relinquished by her previous owner through "no fault of her own" and spent over three years waiting.

## Donald Trump Lawyers Seek To Have Jack Smith Removed As Special Counsel
 - [https://www.newsweek.com/donald-trump-jack-smith-aileen-cannon-palm-beach-florida-classified-documents-appropriations-clause-1914823](https://www.newsweek.com/donald-trump-jack-smith-aileen-cannon-palm-beach-florida-classified-documents-appropriations-clause-1914823)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:52:01+00:00

The former president's lawyers claim that it is illegal to create a special Trump prosecutor position for Smith.

## Joe Rogan Calls Out Woody Harrelson's Dad—'Bad Person'
 - [https://www.newsweek.com/joe-rogan-woody-harrelson-charles-v-harrelson-jfk-assassination-1914804](https://www.newsweek.com/joe-rogan-woody-harrelson-charles-v-harrelson-jfk-assassination-1914804)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:44:18+00:00

Rogan spoke about the possibility of Harrelson's late father—who was a convicted assassin—being involved in the killing of President John F. Kennedy.

## Gen Z Graduate With Two Degrees on Why She Works in Retail—'What Happened'
 - [https://www.newsweek.com/gen-z-graduate-two-degrees-working-retail-1914585](https://www.newsweek.com/gen-z-graduate-two-degrees-working-retail-1914585)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:25:01+00:00

Michelle Holahan, vice president at an executive search firm, told Newsweek that "there are also more eyeballs on every hire."

## Community Rallies To Adopt 274 Pets in a Week After Shelter's Crisis Plea
 - [https://www.newsweek.com/community-rallies-adopt-274-pets-week-after-shelters-crisis-plea-1914749](https://www.newsweek.com/community-rallies-adopt-274-pets-week-after-shelters-crisis-plea-1914749)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:13:06+00:00

Struggling for space, the shelter reached out to the community for help, and they rallied to help the animals in need.

## Donald Trump's Chances of Winning Election Suddenly Slide
 - [https://www.newsweek.com/donald-trump-joe-biden-presidential-election-polls-1914684](https://www.newsweek.com/donald-trump-joe-biden-presidential-election-polls-1914684)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:01:11+00:00

The odds that the presumptive Republican nominee will win the presidential election have declined, one polling model shows.

## F1 News: Fernando Alonso Reveals Something 'Lost' in Modern Formula 1 - 'I Was One of Those Heroes'
 - [https://www.newsweek.com/sports/formula1/f1-news-fernando-alonso-reveals-something-lost-modern-formula-1-i-was-one-those-heroes-1914780](https://www.newsweek.com/sports/formula1/f1-news-fernando-alonso-reveals-something-lost-modern-formula-1-i-was-one-those-heroes-1914780)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:00:02+00:00

Fernando Alonso laments that modern Formula 1 has lost some of its 'heroic' character due to advanced technology.

## Arizona's 'Surprising' Source of Winter Water Revealed
 - [https://www.newsweek.com/arizona-surprising-source-winter-water-1914352](https://www.newsweek.com/arizona-surprising-source-winter-water-1914352)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T13:00:01+00:00

"This is a critical step in allowing us to improve seasonal precipitation forecasts for Arizona," said one expert.

## MLB Picks: Three Best Sides Bets for Wednesday (June 19)
 - [https://www.newsweek.com/mlb-picks-three-best-sides-bets-wednesday-june-19-1914805](https://www.newsweek.com/mlb-picks-three-best-sides-bets-wednesday-june-19-1914805)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:57:55+00:00

We like an underdog Red Sox team, a big favorite in Minnesota, and a pitcher's duel between the Chicago White Sox and Houston Astros.

## More Russian Warships Spotted Fleeing Crimea
 - [https://www.newsweek.com/russian-warships-black-sea-fleet-fleeing-crimea-1914758](https://www.newsweek.com/russian-warships-black-sea-fleet-fleeing-crimea-1914758)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:57:52+00:00

"Another small Russian ship is making its way out of our Crimea. Run, [Forrest], run!" a Ukrainian Navy spokesperson said.

## Fish Parents Spank Their Children To Encourage Better Behavior
 - [https://www.newsweek.com/fish-behavior-parent-punishment-children-cooperation-1914723](https://www.newsweek.com/fish-behavior-parent-punishment-children-cooperation-1914723)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:48:28+00:00

"This compels us to reconsider the notion of 'intelligence' not only in fish, but across the animal kingdom," said researcher Satoshi Awata.

## Nightmare Reason Teacher Trying to Get to Work Was an Hour Late: 'A Big No'
 - [https://www.newsweek.com/nightmare-reason-teacher-hour-late-work-1914710](https://www.newsweek.com/nightmare-reason-teacher-hour-late-work-1914710)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:45:36+00:00

Sydney King says she "went through all the emotions" as she waited an hour for the other driver to return before she could leave.

## Hysterics at Woman's Extreme Lengths to Explain DIY Request to Grandma
 - [https://www.newsweek.com/woman-lengths-explain-diy-request-grandma-1914773](https://www.newsweek.com/woman-lengths-explain-diy-request-grandma-1914773)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:44:37+00:00

Social media users were floored by the clip, with one saying: "The visual instructions are actually so cute."

## John Rich Corrects Troll Over Donald Trump Hair Comment
 - [https://www.newsweek.com/john-rich-corrects-troll-over-donald-trump-hair-comment-1914754](https://www.newsweek.com/john-rich-corrects-troll-over-donald-trump-hair-comment-1914754)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:34:01+00:00

Country singer uses just one word to put criticism of former president's coloring in the shade.

## Texas Border Guards Accused of Shooting Pepper Balls
 - [https://www.newsweek.com/texas-border-guards-shooting-pepper-balls-1914781](https://www.newsweek.com/texas-border-guards-shooting-pepper-balls-1914781)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:33:43+00:00

Migrants say that they have been hit by pepper balls fired by Texas National Guard members.

## Euro 2024 Picks: Betting Odds, Predictions for Wednesday (June 19)
 - [https://www.newsweek.com/euro-2024-picks-betting-odds-predictions-wednesday-june-18-1914521](https://www.newsweek.com/euro-2024-picks-betting-odds-predictions-wednesday-june-18-1914521)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:32:06+00:00

Wednesday's Euro 2024 slate features three games, including Croatia-Albania at 9 a.m. ET and Germany-Hungary at noon.

## What NATO's Likely Next Chief Means For Ukraine War
 - [https://www.newsweek.com/rutte-nato-chief-1914688](https://www.newsweek.com/rutte-nato-chief-1914688)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:30:11+00:00

Mark Rutte is set to take over from Jens Stoltenberg as the secretary-general of the alliance.

## Why Big Tech Is Pumping Big Money Into Companies Pulling CO2 From the Air
 - [https://www.newsweek.com/why-big-tech-pumping-big-money-companies-pulling-co2-air-1914561](https://www.newsweek.com/why-big-tech-pumping-big-money-companies-pulling-co2-air-1914561)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:30:01+00:00

A wave of funding announcements from Microsoft, Salesforce and other tech giants pours millions into new projects to pull CO2 directly from the air.

## Woman Worried Cat Has 'Fatal' Disease Still Can't Believe Vet's Diagnosis
 - [https://www.newsweek.com/woman-worried-cat-has-fatal-disease-still-cant-believe-vets-diagnosis-1914643](https://www.newsweek.com/woman-worried-cat-has-fatal-disease-still-cant-believe-vets-diagnosis-1914643)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:28:34+00:00

Sam, the owner of Miss Biscuit, told Newsweek that the vet's response to the situation was one of amusement,

## Ukraine Strikes Russian Territory With Homegrown Neptune Missiles
 - [https://www.newsweek.com/ukraine-russia-neptune-anti-ship-missiles-krasnodar-rostov-oil-refineries-1914728](https://www.newsweek.com/ukraine-russia-neptune-anti-ship-missiles-krasnodar-rostov-oil-refineries-1914728)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:24:01+00:00

The sinking of Russia's Black Sea Fleet flagship, the 'Moskva', in April 2022 was attributed to Ukraine's Neptune missile.

## Russia Threatens to Seize Assets From U.S. and Allies
 - [https://www.newsweek.com/russia-threatens-seize-western-assets-1914795](https://www.newsweek.com/russia-threatens-seize-western-assets-1914795)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:21:56+00:00

Russia has responded to the G7's appropriation of its frozen assets.

## Trump Media Hits 'Milestone' As Stock Slides
 - [https://www.newsweek.com/donald-trump-truth-social-media-milestone-stock-decline-1914759](https://www.newsweek.com/donald-trump-truth-social-media-milestone-stock-decline-1914759)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:04:48+00:00

The company, which owns Truth Social has registered additional shares with the SEC

## Princess Kate's Parents Appear in Public After Her Comeback
 - [https://www.newsweek.com/princess-kate-parents-carole-michael-middleton-royal-ascot-1914755](https://www.newsweek.com/princess-kate-parents-carole-michael-middleton-royal-ascot-1914755)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:02:48+00:00

Carole and Michael Middleton were photographed at Royal Ascot days after Princess Kate returned to the limelight.

## Lance Stroll's F1 Future Questioned - 'Did He Ever Want to Really Become a Race Car Driver?'
 - [https://www.newsweek.com/sports/formula1/lance-strolls-f1-future-questioned-did-he-ever-want-really-become-race-car-driver-1914778](https://www.newsweek.com/sports/formula1/lance-strolls-f1-future-questioned-did-he-ever-want-really-become-race-car-driver-1914778)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T12:00:01+00:00

Lance Stroll's motivation and genuine interest in Formula 1 are questioned as he continues his career under his father's team, Aston Martin.

## Quarter of US Backyards Have Unsafe Lead Levels, Study Warns
 - [https://www.newsweek.com/us-backyards-unsafe-soil-1914752](https://www.newsweek.com/us-backyards-unsafe-soil-1914752)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:57:56+00:00

Around 40 percent of households are beyond the safe level for lead levels in soil, the new study reported.

## McLaren Abruptly Cuts Ties With Driver - This Is His Replacement
 - [https://www.newsweek.com/sports/mclaren-abruptly-cuts-ties-driver-this-his-replacement-1914767](https://www.newsweek.com/sports/mclaren-abruptly-cuts-ties-driver-this-his-replacement-1914767)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:30:01+00:00

Arrow McLaren replaced driver Theo Pourchaire with Indy NXT star Nolan Siegel mid-season.

## California High-Speed Rail Line Gets Boost
 - [https://www.newsweek.com/california-high-speed-rail-line-gets-boost-1914694](https://www.newsweek.com/california-high-speed-rail-line-gets-boost-1914694)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:27:50+00:00

A plurality of Americans back a new high speed rail line in California despite the cost according to a Newsweek survey.

## I'm a Psychologist—Doomscrolling Has a Devastating Impact
 - [https://www.newsweek.com/i-am-psychologist-doomscrolling-has-devastating-impact-1914745](https://www.newsweek.com/i-am-psychologist-doomscrolling-has-devastating-impact-1914745)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:24:10+00:00

The way we feel is largely a result of the thoughts and images that go through our minds.

## Christina Applegate Sets Record Straight on 'Dark' Comments Amid MS Symptoms
 - [https://www.newsweek.com/christina-applegate-ms-podcast-1914730](https://www.newsweek.com/christina-applegate-ms-podcast-1914730)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:21:49+00:00

In 2021 Applegate revealed she had multiple sclerosis and said on her podcast: "This is being really honest: I don't enjoy living."

## Why Some iPhones Won't Get Apple's New iOS 18 Update
 - [https://www.newsweek.com/why-some-iphones-wont-get-apples-new-ios-18-update-1914606](https://www.newsweek.com/why-some-iphones-wont-get-apples-new-ios-18-update-1914606)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:16:32+00:00

Not all iPhone users will be able to enjoy the latest features set to be introduced with iOS 18.

## New Justin Timberlake Evidence Emerges After DWI Arrest
 - [https://www.newsweek.com/justin-timberlake-arrest-dwi-hamptons-sag-harbor-police-court-documents-1914673](https://www.newsweek.com/justin-timberlake-arrest-dwi-hamptons-sag-harbor-police-court-documents-1914673)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:15:17+00:00

Court documents reveal police said Timberlake's eyes were "bloodshot and glassy" and "a strong odor of an alcoholic beverage was emanating from his breath."

## Rudy Giuliani's Advisor Maria Ryan Blasts Bankruptcy Filings: 'Outright Lie'
 - [https://www.newsweek.com/rudy-giuliani-maria-ryan-bankruptcy-court-new-york-credits-ruby-freeman-atlanta-georgia-1914715](https://www.newsweek.com/rudy-giuliani-maria-ryan-bankruptcy-court-new-york-credits-ruby-freeman-atlanta-georgia-1914715)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:14:47+00:00

Ryan says that the bankruptcy creditors are making false claims about her.

## Woman's 'Genius' Toxic Trait Since Becoming A Mom
 - [https://www.newsweek.com/womans-genius-toxic-trait-since-becoming-mom-1914702](https://www.newsweek.com/womans-genius-toxic-trait-since-becoming-mom-1914702)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:11:02+00:00

Claire Jopson's casual confession has other moms "taking notes" for a moment of peace

## Acknowledging Juneteenth Isn't Enough. The Military Must Advocate for Change | Opinion
 - [https://www.newsweek.com/acknowledging-juneteenth-isnt-enough-military-must-advocate-change-opinion-1913021](https://www.newsweek.com/acknowledging-juneteenth-isnt-enough-military-must-advocate-change-opinion-1913021)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T11:00:01+00:00

Not only do our military uniforms not shield us from harm—but in some cases, the military actually forces us into higher-risk situations.

## Princess Kate's Bond With Royal Relative Goes Viral
 - [https://www.newsweek.com/princess-kate-bond-royal-relative-viral-video-1914669](https://www.newsweek.com/princess-kate-bond-royal-relative-viral-video-1914669)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:58:54+00:00

Footage has gone viral on social media of Kate with the Duke of Edinburgh at a 2016 lunch for Queen Elizabeth II's 90th birthday.

## 40 Russian Warships, Fighter Jets, Helicopters Join Pacific Fleet Drills
 - [https://www.newsweek.com/russia-pacific-fleet-drills-warships-1914699](https://www.newsweek.com/russia-pacific-fleet-drills-warships-1914699)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:44:42+00:00

The naval exercises kick-started on Tuesday and will run through June 28 in the Pacific Ocean, Sea of Japan and Sea of Okhotsk.

## Prince Harry and Meghan Fans 'Are a Danger'—PR Expert
 - [https://www.newsweek.com/prince-harry-meghan-markle-fans-danger-pr-1914595](https://www.newsweek.com/prince-harry-meghan-markle-fans-danger-pr-1914595)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:40:01+00:00

Prince Harry and Meghan Markle supporters were among those pushing conspiracy theories about Princess Kate.

## Tax Cuts Approved for More Than a Million Americans
 - [https://www.newsweek.com/tax-cuts-approved-millions-americans-kansas-1914666](https://www.newsweek.com/tax-cuts-approved-millions-americans-kansas-1914666)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:37:09+00:00

A two-tier tax system is set to be implemented after a major bill in Kansas passed with bipartisan support.

## 50 Cent's Tyler Perry Remark Takes Off Online
 - [https://www.newsweek.com/50-cent-tyler-perry-remark-viral-online-1914680](https://www.newsweek.com/50-cent-tyler-perry-remark-viral-online-1914680)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:35:15+00:00

"He's helping me, already going out of his way to aid my progress," 50 Cent said online after it was implied the two were rivals.

## Ricky Gervais' Justin Timberlake Message Goes Viral
 - [https://www.newsweek.com/ricky-gervais-justin-timberlake-dwi-arrest-post-twitter-x-1914650](https://www.newsweek.com/ricky-gervais-justin-timberlake-dwi-arrest-post-twitter-x-1914650)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:33:41+00:00

The British comedian's comment on the Timberlake's DWI arrest divided people online. Some found the remark hilarious, while others feel the jibe is "too soon."

## Nuclear Expansion Sparks Concerns from Scientists of 'Catastrophic Failure'
 - [https://www.newsweek.com/nuclear-advance-bill-power-senate-union-concerned-scientists-1914622](https://www.newsweek.com/nuclear-advance-bill-power-senate-union-concerned-scientists-1914622)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:32:29+00:00

The bill aims to speed things up for companies applying for permits and creates new incentives for nuclear technologies.

## Four Republican Incumbents Lose Seats in Oklahoma
 - [https://www.newsweek.com/oklahoma-state-senate-republicans-1914652](https://www.newsweek.com/oklahoma-state-senate-republicans-1914652)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:27:05+00:00

Oklahoma held a series of primary votes on Tuesday for state Senate and House seats.

## I'm 73—I Lost 132lbs by Addressing One Underlying Problem
 - [https://www.newsweek.com/i-am-73-lost-132-pounds-addressing-one-underlying-problem-1914707](https://www.newsweek.com/i-am-73-lost-132-pounds-addressing-one-underlying-problem-1914707)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:26:08+00:00

I often felt inadequate and different.

## Melania Trump Makes Rare Public Appearance After Husband Leaves New York
 - [https://www.newsweek.com/melania-trump-rare-public-appearance-after-husband-leaves-new-york-1914638](https://www.newsweek.com/melania-trump-rare-public-appearance-after-husband-leaves-new-york-1914638)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:24:07+00:00

In a rare public appearance, the former first lady has been spotted walking into Trump Tower with a Hermès Birkin bag.

## 'New Phase' in Israel-Hamas War, Trump Agenda 'Resistance': Today's Front Pages
 - [https://www.newsweek.com/newspaper-front-page-wednesday-june-19-2024-1914648](https://www.newsweek.com/newspaper-front-page-wednesday-june-19-2024-1914648)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T10:01:52+00:00

Newspapers across the United States report today on the rise of homelessness among young children, and a potential shift in the Israel-Hamas war.

## Salad Recall Update As FDA Sets Risk Level
 - [https://www.newsweek.com/salad-recall-update-fda-sets-risk-level-1914637](https://www.newsweek.com/salad-recall-update-fda-sets-risk-level-1914637)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:50:11+00:00

Salad bowls recalled due to possible undeclared pecan now classified as grade II by FDA.

## Donald Trump's Joan Rivers Remarks Raise Eyebrows
 - [https://www.newsweek.com/donald-trump-joan-rivers-voted-him-2016-general-election-cnn-apprentice-book-ramin-setoodeh-1914610](https://www.newsweek.com/donald-trump-joan-rivers-voted-him-2016-general-election-cnn-apprentice-book-ramin-setoodeh-1914610)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:46:35+00:00

"I'm surprised Joan Rivers didn't come back from the dead to dispute that foul slur," wrote one user social media user.

## New York Juneteenth Weather Update
 - [https://www.newsweek.com/new-york-weather-update-forecast-today-june-19-juneteenth-1914658](https://www.newsweek.com/new-york-weather-update-forecast-today-june-19-juneteenth-1914658)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:44:07+00:00

Hot conditions are expected on Juneteenth and the following days.

## Justin Timberlake Meme Goes Viral After Arrest
 - [https://www.newsweek.com/justin-timberlake-arrest-drinking-dwi-meme-1914627](https://www.newsweek.com/justin-timberlake-arrest-drinking-dwi-meme-1914627)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:43:16+00:00

Timberlake has suffered a series of mishaps over the years, including criticism for his treatment of Britney Spears and accusations of cultural appropriation.

## Charlottesville Overwhelmingly Rejects Donald Trump Candidate
 - [https://www.newsweek.com/charlottesville-rejects-donald-trump-candidate-john-mcguire-bob-good-1914661](https://www.newsweek.com/charlottesville-rejects-donald-trump-candidate-john-mcguire-bob-good-1914661)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:43:10+00:00

Congressman Bob Good holds more than a 14 percentage point lead in Charlottesville over John McGuire, who was backed by Donald Trump in the Virginia primary.

## Bill Maher Calls Out Stormy Daniels—'Preposterous'
 - [https://www.newsweek.com/donald-trump-trial-stormy-daniels-bill-maher-megyn-kelly-1914636](https://www.newsweek.com/donald-trump-trial-stormy-daniels-bill-maher-megyn-kelly-1914636)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:38:39+00:00

Maher criticized Daniels over her testimony during Donald Trump's recent hush-money criminal trial.

## Katy Perry Under Fire Over Dr. Luke Collaboration Rumors
 - [https://www.newsweek.com/katy-perry-dr-luke-kesha-collaboration-1914221](https://www.newsweek.com/katy-perry-dr-luke-kesha-collaboration-1914221)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:33:43+00:00

Kesha herself seemed to respond to the rumors about the song called "Woman's World."

## Prince William's Very Private Message for Kevin Costner
 - [https://www.newsweek.com/prince-william-private-message-kevin-costner-princess-diana-1914605](https://www.newsweek.com/prince-william-private-message-kevin-costner-princess-diana-1914605)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:32:15+00:00

The Prince of Wales requested a private meeting with Costner, the Oscar-winning movie star has said.

## Construction of Controversial Hydroelectric Dam Nears Completion
 - [https://www.newsweek.com/construction-controversial-hydroelectric-dam-ethiopia-nears-completion-1906328](https://www.newsweek.com/construction-controversial-hydroelectric-dam-ethiopia-nears-completion-1906328)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:19:53+00:00

The Grand Ethiopian Renaissance Dam (GERD) Africa's largest hydroelectric project is nearing completion after years of controversy

## New Nostradamus Stands by Imminent World War III Prediction
 - [https://www.newsweek.com/new-nostradamus-world-war-three-1914613](https://www.newsweek.com/new-nostradamus-world-war-three-1914613)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:09:11+00:00

There was no global conflagration on Tuesday but we're not out of the woods yet, as astrologer Kushal Kumar says a world war could break out at the end of June.

## Cheddar Recall Update As FDA Sets Concern Level
 - [https://www.newsweek.com/cheddar-recall-update-fda-sets-concern-level-1914596](https://www.newsweek.com/cheddar-recall-update-fda-sets-concern-level-1914596)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:05:47+00:00

Cheese products already in the process of being recalled have been classified as a Grade II recall by the FDA.

## Donald Trump Accused of Repeatedly 'Waving to Nobody'
 - [https://www.newsweek.com/donald-trump-waving-video-nobody-1914619](https://www.newsweek.com/donald-trump-waving-video-nobody-1914619)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:01:16+00:00

"This is nothing more than fake news being peddled," Steven Cheung, Trump's communications director, told Newsweek.

## Ted Cruz Documents Leak: Everything We Know
 - [https://www.newsweek.com/ted-cruz-documents-leak-everything-we-know-1914631](https://www.newsweek.com/ted-cruz-documents-leak-everything-we-know-1914631)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T09:00:47+00:00

A reporter published on X what he said were briefing notes for meetings between the senator and donors. They were later deleted.

## Thousands of Homebuyers Flock to New 0% Down Payment Mortgages
 - [https://www.newsweek.com/thousands-homebuyers-flock-new-0-down-payment-mortgages-1914608](https://www.newsweek.com/thousands-homebuyers-flock-new-0-down-payment-mortgages-1914608)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:53:22+00:00

Thousands of borrowers have taken on UWM's offer of a zero-down mortgage. While the company is enthusiastic, experts are skeptical.

## Roger Stone Secret Recording Sparks Fury
 - [https://www.newsweek.com/roger-stone-recording-trump-election-judges-1914624](https://www.newsweek.com/roger-stone-recording-trump-election-judges-1914624)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:50:23+00:00

The top GOP consultant was heard describing plans to use judges to challenge the 2024 election results for Donald Trump.

## Putin-Kim Jong Un Deal: What North Korea Pact Could Mean for Ukraine
 - [https://www.newsweek.com/vladimir-putin-kim-jong-un-north-korea-visit-russia-ukraine-deal-1914602](https://www.newsweek.com/vladimir-putin-kim-jong-un-north-korea-visit-russia-ukraine-deal-1914602)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:45:22+00:00

North Korea has provided "consistent and unwavering support for Russian policy, including in the Ukrainian direction," said Russian President Vladimir Putin.

## Marjorie Taylor Greene Opponent Vows To 'Fight Like Hell' To Bring Her Down
 - [https://www.newsweek.com/marjorie-taylor-greene-opponent-shawn-harris-vows-fight-defeat-her-november-elections-1914649](https://www.newsweek.com/marjorie-taylor-greene-opponent-shawn-harris-vows-fight-defeat-her-november-elections-1914649)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:38:34+00:00

Shawn Harris has said he wants to end Marjorie Taylor Greene's "toxic" career in Georgia's 14th congressional district after winning a primary runoff election.

## Putin Gets New Bargaining Chip Against US
 - [https://www.newsweek.com/gordon-black-us-soldier-army-jailed-sentenced-russia-1914629](https://www.newsweek.com/gordon-black-us-soldier-army-jailed-sentenced-russia-1914629)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:28:08+00:00

A Russian court sentenced Gordon Black, a U.S. serviceman, to three years and nine months in prison.

## US Navy 'Monitoring' Russian Warships In Sight Of Miami
 - [https://www.newsweek.com/us-navy-monitoring-russian-warships-submarine-near-miami-1914616](https://www.newsweek.com/us-navy-monitoring-russian-warships-submarine-near-miami-1914616)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:16:26+00:00

American and Canadian warships are tracking a Russian submarine as it travels along the Florida coast, the U.S. Navy has said.

## Chocolate Recall Update as FDA Sets Risk Level
 - [https://www.newsweek.com/chocolate-recall-update-fda-risk-level-set-salmonella-1914600](https://www.newsweek.com/chocolate-recall-update-fda-risk-level-set-salmonella-1914600)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:12:07+00:00

Nine products have been withdrawn due to potential salmonella contamination.

## Taylor Swift Fan Selling Friendship Bracelet From Her Mom Sparks Fury
 - [https://www.newsweek.com/taylor-swift-friendship-bracelet-mom-selling-1914607](https://www.newsweek.com/taylor-swift-friendship-bracelet-mom-selling-1914607)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:04:26+00:00

The lucky fan was given a friendship bracelet by Swift's mom at an Eras concert but then sold it online.

## Amy Coney Barrett and Clarence Thomas Are on Collision Course
 - [https://www.newsweek.com/amy-coney-barrett-scotus-supreme-court-clarence-thomas-rahimi-gun-control-trademark-donald-trump-1914291](https://www.newsweek.com/amy-coney-barrett-scotus-supreme-court-clarence-thomas-rahimi-gun-control-trademark-donald-trump-1914291)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:00:03+00:00

Supreme Court Justice Coney Barrett has signaled recently that she strongly rejects Thomas' historical analysis of American law.

## California's Reparations Dream Faces Stark Reality
 - [https://www.newsweek.com/california-reparations-dream-stark-reality-1914224](https://www.newsweek.com/california-reparations-dream-stark-reality-1914224)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:00:01+00:00

Lawmakers are having to compromise to garner support for reparations bills inspired by recommendations from a first-in-the-nation reparations task force.

## Florida Democrats Increasingly Confident as Polls Show Party Has 'Momentum'
 - [https://www.newsweek.com/florida-democrats-elections-polls-1914088](https://www.newsweek.com/florida-democrats-elections-polls-1914088)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T08:00:01+00:00

Democrats are hoping to win the state in the 2024 election.

## Everything We Know About Scooter Braun Quitting Music
 - [https://www.newsweek.com/scooter-braun-quitting-music-retiring-hybe-america-justin-bieber-1914232](https://www.newsweek.com/scooter-braun-quitting-music-retiring-hybe-america-justin-bieber-1914232)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T07:40:18+00:00

The music mogul is best known for discovering the teen Justin Bieber on YouTube and his public beef with Taylor Swift.

## Map Shows Reach of China's Nuclear-Capable Missiles
 - [https://www.newsweek.com/map-shows-reach-china-nuclear-capable-missiles-1914264](https://www.newsweek.com/map-shows-reach-china-nuclear-capable-missiles-1914264)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T06:47:06+00:00

Those with the longest range could bring the continental U.S. within reach if fired from China's east coast.

## Donald Trump 'Struggles' With Chronology of Events, Author Claims
 - [https://www.newsweek.com/donald-trump-struggles-chronology-events-ramin-setoodeh-claims-1914593](https://www.newsweek.com/donald-trump-struggles-chronology-events-ramin-setoodeh-claims-1914593)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T06:30:52+00:00

The author of a new book about Donald Trump has said he is "very challenging" to interview as he "goes from one story to the next."

## Yankees' Aaron Judge Provides Major Update on Injury
 - [https://www.newsweek.com/sports/mlb/yankees-aaron-judge-provides-major-update-injury-1914591](https://www.newsweek.com/sports/mlb/yankees-aaron-judge-provides-major-update-injury-1914591)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T04:08:07+00:00

New York Yankees star outfielder Aaron Judge provided a major update on the injury that forced him out of Tuesday's game.

## Republican Nail-Biting Race Puts Spotlight on MAGA
 - [https://www.newsweek.com/republican-nail-biting-race-puts-spotlight-maga-1914588](https://www.newsweek.com/republican-nail-biting-race-puts-spotlight-maga-1914588)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T04:05:47+00:00

Trump-endorsed candidate John McGuire is facing off against incumbent Republican Congressman Robert Good in Virginia.

## NYT 'Connections' Hints June 19: Clues and Answer for Game #374
 - [https://www.newsweek.com/nyt-connections-hints-june-19-clues-answer-game-374-1914284](https://www.newsweek.com/nyt-connections-hints-june-19-clues-answer-game-374-1914284)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T04:01:01+00:00

Need a little extra help with today's "Connections" puzzle? Newsweek has compiled some tips and hints to get you to the answers.

## Today's 'Wordle' #1,096 Clues and Answer for Wednesday, June 19 Puzzle
 - [https://www.newsweek.com/wordle-today-hints-answer-wednesday-june-19-1914258](https://www.newsweek.com/wordle-today-hints-answer-wednesday-june-19-1914258)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T04:01:01+00:00

Today's puzzle rates at a 4.2 out of 6 in difficulty, but that does not mean that everyone will solve it easily.

## Indiana Drivers Advised to Restrict Hours at the Pump
 - [https://www.newsweek.com/indiana-drivers-advised-restrict-hours-pump-1914590](https://www.newsweek.com/indiana-drivers-advised-restrict-hours-pump-1914590)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T03:52:53+00:00

Residents have been asked to lower their daily emissions during air quality alerts throughout several portions of Indiana later this week.

## Drinking Water Warning Issued Amid Raging Wildfires
 - [https://www.newsweek.com/drinking-water-warning-issued-amid-raging-wildfires-1914587](https://www.newsweek.com/drinking-water-warning-issued-amid-raging-wildfires-1914587)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T03:13:24+00:00

Approximately 20,000 acres have been consumed in wildfires raging in New Mexico since Monday.

## Willie Mays Dies at 93; Was Baseball's Oldest Living Hall of Famer
 - [https://www.newsweek.com/sports/mlb/willie-mays-dies-93-was-baseballs-oldest-living-hall-famer-1914584](https://www.newsweek.com/sports/mlb/willie-mays-dies-93-was-baseballs-oldest-living-hall-famer-1914584)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T01:16:24+00:00

Baseball's oldest living Hall of Famer, Willie Mays, died Tuesday at 93 years old, two days before MLB was set to stage a historic game in his native Alabama.

## Aaron Judge Exits Yankees' Game vs Orioles With Injury
 - [https://www.newsweek.com/sports/mlb/aaron-judge-exits-yankees-game-vs-orioles-injury-1914581](https://www.newsweek.com/sports/mlb/aaron-judge-exits-yankees-game-vs-orioles-injury-1914581)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T00:52:12+00:00

New York Yankees outfielder Aaron Judge was hit by a pitch on his hand in the third inning of a game against the Baltimore Orioles on Tuesday and left the game.

## Map Shows City Hit Record Amid 'Extreme' Heat Wave
 - [https://www.newsweek.com/map-shows-city-hit-record-amid-extreme-heat-wave-1914563](https://www.newsweek.com/map-shows-city-hit-record-amid-extreme-heat-wave-1914563)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T00:44:24+00:00

The area could reach "heat index values of 100F to 110F" on multiple days this week, according to the National Weather Service.

## Letitia James Celebrates Major Abortion Rights Win
 - [https://www.newsweek.com/letitia-james-celebrates-major-abortion-rights-win-1914576](https://www.newsweek.com/letitia-james-celebrates-major-abortion-rights-win-1914576)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2024-06-19T00:09:35+00:00

A New York appeals court reinstated the Equal Rights Amendment proposal to the ballot in November.

