# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## Apple Could Be Fined A Billion Dollars A Day
 - [https://kotaku.com/apple-ios-epic-fortnite-in-app-purchases-fine-1851549043](https://kotaku.com/apple-ios-epic-fortnite-in-app-purchases-fine-1851549043)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-06-19T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/29b6a12844d7c2e24228d4659dbc1f3e.jpg" /><p>Back in March, the European Union brought in new rules that were designed to stop companies like Apple and Google from blocking third-party companies running their own in-app item stores. This was supposed to carve a path for games like Fortnite to be able to return to mobile, now they could run in-game purchases…</p><p><a href="https://kotaku.com/apple-ios-epic-fortnite-in-app-purchases-fine-1851549043">Read more...</a></p>

## McDonald's Drive-Thru AI Is McCanceled
 - [https://kotaku.com/mcdonalds-drive-thru-ai-failure-tiktok-1851548668](https://kotaku.com/mcdonalds-drive-thru-ai-failure-tiktok-1851548668)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-06-19T14:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e826fc4d3ab7189c7d8f1f6beb046a7f.jpg" /><p>AI is such big business right now it’s propelled Nvidia, that company that you once knew for making your GeForce graphics cards, to becoming <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.bbc.co.uk/news/articles/cyrr40x0z2mo" rel="noopener noreferrer" target="_blank">the biggest business in the world</a>. And yet the technology is so far next to useless in all but the most specific circumstances. For example, McDonald’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.restaurantbusinessonline.com/technology/mcdonalds-ending-its-drive-thru-ai-test" rel="noopener noreferrer" target="_blank">has just announced</a> it’s…</p><p><a href="https://kotaku.com/mcdonalds-drive-thru-ai-failure-tiktok-1851548668">Read more...</a></p>

## All-Time Classic TimeSplitters Looking Likely For PS4, PS5
 - [https://kotaku.com/timesplitters-playstation-ps4-ps5-classics-catalog-1851548513](https://kotaku.com/timesplitters-playstation-ps4-ps5-classics-catalog-1851548513)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-06-19T13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a1afeb0be5b2601902f8eb61485c79df.jpg" /><p>If you wanna know what games are coming up next on PlayStation, you just need to ask the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.gamerating.org.tw/Search/GameList" rel="noopener noreferrer" target="_blank">Taiwanese ratings board</a>. That’s Gemastu’s brilliant trick, that allowed the site to <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/octopath-traveler-xbox-game-pass-ps4-ps5-1851520559">correctly predict</a> the arrival of Octopath Traveler last week, and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://x.com/gematsu/status/1803186507974377868" rel="noopener noreferrer" target="_blank">now suggests</a> subscribers to PlayStation Plus are about to finally be reunited…</p><p><a href="https://kotaku.com/timesplitters-playstation-ps4-ps5-classics-catalog-185

