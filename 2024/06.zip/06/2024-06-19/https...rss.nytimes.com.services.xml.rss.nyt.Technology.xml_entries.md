# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Ilya Sutskever, OpenAI Co-Founder Who Helped Oust Sam Altman, Starts His Own Company
 - [https://www.nytimes.com/2024/06/19/technology/ilya-sutskever-openai-safe-superintelligence.html](https://www.nytimes.com/2024/06/19/technology/ilya-sutskever-openai-safe-superintelligence.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2024-06-19T19:00:17+00:00

Ilya Sutskever’s new start-up, Safe Superintelligence, aims to build A.I. technologies that are smarter than a human but not dangerous.

