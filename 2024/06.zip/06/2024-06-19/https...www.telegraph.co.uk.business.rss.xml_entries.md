# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Inflation hits Bank of England’s target in boost for Sunak
 - [https://www.telegraph.co.uk/business/2024/06/19/ftse-100-markets-latest-news-inflation-cpi-fall-2pc](https://www.telegraph.co.uk/business/2024/06/19/ftse-100-markets-latest-news-inflation-cpi-fall-2pc)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2024-06-19T06:02:48+00:00



