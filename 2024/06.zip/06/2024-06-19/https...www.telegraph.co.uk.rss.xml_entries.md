# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Scotland vs Switzerland: Build-up and latest updates from Euro 2024
 - [https://www.telegraph.co.uk/football/2024/06/19/scotland-vs-switzerland-live-score-euro-2024-latest-updates](https://www.telegraph.co.uk/football/2024/06/19/scotland-vs-switzerland-live-score-euro-2024-latest-updates)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T17:47:51+00:00



## Why Ukraine’s most dangerous moment may have passed - Ukraine: The Latest, Podcast
 - [https://www.telegraph.co.uk/world-news/2024/06/19/ukraine-russia-weapons-western-aid](https://www.telegraph.co.uk/world-news/2024/06/19/ukraine-russia-weapons-western-aid)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T17:27:20+00:00



## The best masseria hotels in Puglia
 - [https://www.telegraph.co.uk/travel/destinations/europe/italy/puglia/articles/best-puglia-hotels-masserias](https://www.telegraph.co.uk/travel/destinations/europe/italy/puglia/articles/best-puglia-hotels-masserias)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T16:00:00+00:00



## Zika-like virus found in sloths spreads from Amazon to humans
 - [https://www.telegraph.co.uk/global-health/science-and-disease/oropouche-virus-outbreak-amazon-jungle-brazil-south-america](https://www.telegraph.co.uk/global-health/science-and-disease/oropouche-virus-outbreak-amazon-jungle-brazil-south-america)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T15:42:27+00:00



## Germany vs Hungary: Build-up and lineups from Euro 2024
 - [https://www.telegraph.co.uk/football/2024/06/19/germany-vs-hungary-live-score-euro-2024-latest-updates](https://www.telegraph.co.uk/football/2024/06/19/germany-vs-hungary-live-score-euro-2024-latest-updates)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T15:26:49+00:00



## The Exorcism: Even more demon-banishing for Russell Crowe? He needs to kick the habit
 - [https://www.telegraph.co.uk/films/0/the-exorcism-review-russell-crowe](https://www.telegraph.co.uk/films/0/the-exorcism-review-russell-crowe)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T13:07:21+00:00



## How to spend the perfect holiday on Rhodes
 - [https://www.telegraph.co.uk/travel/destinations/europe/greece/rhodes/articles/expert-travel-guide-rhodes](https://www.telegraph.co.uk/travel/destinations/europe/greece/rhodes/articles/expert-travel-guide-rhodes)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T13:00:00+00:00



## Croatia vs Albania: Lineups and latest updates from Euro 2024
 - [https://www.telegraph.co.uk/football/2024/06/19/croatia-vs-albania-live-score-euro-2024-latest-updates](https://www.telegraph.co.uk/football/2024/06/19/croatia-vs-albania-live-score-euro-2024-latest-updates)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T11:52:10+00:00



## Royal Ascot 2024: Day two race updates including Prince of Wales’s Stakes
 - [https://www.telegraph.co.uk/racing/2024/06/19/royal-ascot-2024-live-day-two-race-updates-prince-of-wales](https://www.telegraph.co.uk/racing/2024/06/19/royal-ascot-2024-live-day-two-race-updates-prince-of-wales)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T11:51:29+00:00



## Euro 2024 today: Matches, times, predictions and TV channels including Scotland vs Switzerland
 - [https://www.telegraph.co.uk/football/2024/06/19/euro-2024-guide-today-matches](https://www.telegraph.co.uk/football/2024/06/19/euro-2024-guide-today-matches)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T07:44:14+00:00



## Telegraph Fantasy Football Euros Edition: Round 2 tips
 - [https://www.telegraph.co.uk/fantasy-sports/fantasy-football/telegraph-fantasy-football-euros-edition-round-2-tips](https://www.telegraph.co.uk/fantasy-sports/fantasy-football/telegraph-fantasy-football-euros-edition-round-2-tips)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T06:00:00+00:00



## General election latest: Many Tories could suffer same fate as me in 1997, says Michael Portillo
 - [https://www.telegraph.co.uk/politics/2024/06/19/general-election-latest-news-sunak-starmer-farage](https://www.telegraph.co.uk/politics/2024/06/19/general-election-latest-news-sunak-starmer-farage)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T05:30:57+00:00



## Putin and Kim Jong-un to hold talks to boost defence ties
 - [https://www.telegraph.co.uk/world-news/2024/06/19/ukraine-war-putin-kim-jong-un-meeting-pyongyang-latest-news](https://www.telegraph.co.uk/world-news/2024/06/19/ukraine-war-putin-kim-jong-un-meeting-pyongyang-latest-news)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-06-19T03:18:44+00:00



