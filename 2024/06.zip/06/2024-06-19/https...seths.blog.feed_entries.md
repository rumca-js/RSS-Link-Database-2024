# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Are you weather?
 - [https://seths.blog/2024/06/are-you-weather](https://seths.blog/2024/06/are-you-weather)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-06-19T08:34:00+00:00

The thunderstorm doesn&#8217;t know we exist. Rain dances and wishes are ineffective at bringing or preventing a storm, because it isn&#8217;t caused by our actions. Metaphorical weather is tempting to mistake as a response. When someone cuts us off in traffic or doesn&#8217;t engage with us the way we might hope for, it&#8217;s easy to [&#8230;]

