# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## Baseball legend Willie Mays dies at 93
 - [https://www.nbcnews.com/video/baseball-legend-willie-mays-dies-at-93-213247557556](https://www.nbcnews.com/video/baseball-legend-willie-mays-dies-at-93-213247557556)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-06-19T01:38:09+00:00

San Francisco Giants great and Hall of Famer Willie Mays passed away at age 93. Over his career in the big leagues, which began in 1951, he recorded a .301 batting average and hit 660 home runs. NBC’s Steve Patterson looks back at his legacy.

## One dead in New Mexico from dangerous wildfire
 - [https://www.nbcnews.com/now/video/one-dead-in-new-mexico-from-dangerous-wildfire-213246021979](https://www.nbcnews.com/now/video/one-dead-in-new-mexico-from-dangerous-wildfire-213246021979)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-06-19T01:21:30+00:00

One person has died near Ruidoso, New Mexico, from a wildfire. This comes as the governor of New Mexico has declared a state of emergency due to wildfires raging across the state.

