# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## The All-New RAZER KISHI ULTRA, Hands-On Review
 - [https://www.youtube.com/watch?v=LR1Ik-HPBQ0](https://www.youtube.com/watch?v=LR1Ik-HPBQ0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2024-06-19T14:06:00+00:00

In this video we take a look at and test out the all new Razer Kishi Ultra.
This Is a great Full size mobile controller and works with android phones and Android Tablets up to 8.8" like the Lenovo legion Y700 plus it works with the iPhone 15 pro max and the ipad Mini. overall this is one of the best mobile telescopic USB C controller on the market but it comes with a high Price tag.

Buy it on amazon: https://amzn.to/3z1KNIU
Learn More Here: https://www.razer.com/mobile-controllers/razer-kishi-ultra/

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

Vip-Urcdkey Sale Code for software: ETA
Windows 10 Pro OEM Key($17): https://biitt.ly/KpEmf
Windows 11 Pro Key($23):https://biitt.ly/RUZiX
Windows10 Home Key($16):https://biitt.ly/2tPi1
Office 2019 pro key($51):https://biitt.ly/o0OQT
Office 2021 pro key($97):https://biitt.ly/iDMHc  
Office 2016 pro key($28): https://biitt.ly/xWmvn

DISCLAIMER: This video and description cont

