# Source:ThioJoe, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ, language:en-US

## My Motherboard Replacement Situation Has Been Resolved
 - [https://www.youtube.com/watch?v=8xwboip8L8c](https://www.youtube.com/watch?v=8xwboip8L8c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQSpnDG3YsFNf5-qHocF-WQ
 - date published: 2024-06-19T15:35:30+00:00

It's all been sorted 🧐

Original Video: https://www.youtube.com/watch?v=yd1TU4auPNM

▼ Time Stamps: ▼
0:00 - Intro
0:28 - Their Response
2:04 - About The Ghosting
4:03 - Asus' Warranty Country Policy
5:04 - Comments With Scam Theories
5:52 - "Just Do A Chargeback"
6:34 - Comment About The Supplier

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
• My Gear & Equipment ⇨ https://kit.co/ThioJoe
• Merch ⇨ https://teespring.com/stores/thiojoe
• My Desktop Wallpapers ⇨ https://thiojoe.art/
⇨ http://Instagram.com/ThioJoe
⇨ http://Twitter.com/ThioJoe
⇨ http://Facebook.com/ThioJoeTV
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

