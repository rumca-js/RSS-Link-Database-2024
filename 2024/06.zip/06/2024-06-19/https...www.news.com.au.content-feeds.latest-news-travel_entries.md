# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## Awkward reason airline boss serves drinks
 - [https://www.news.com.au/travel/travel-advice/flights/awkward-reason-airline-boss-serves-drinks/news-story/48b44b61e5469b9cd98b0e1922002afb?from=rss-basic](https://www.news.com.au/travel/travel-advice/flights/awkward-reason-airline-boss-serves-drinks/news-story/48b44b61e5469b9cd98b0e1922002afb?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-06-19T04:19:24.270505+00:00

Passengers on this Air New Zeleand flight would have been shocked to find its CEO serving them drinks – but there was a reason why.

