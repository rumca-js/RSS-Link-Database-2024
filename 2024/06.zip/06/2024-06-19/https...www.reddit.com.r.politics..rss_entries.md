# Source:Reddit - Politics, URL:https://www.reddit.com/r/politics/.rss, language:en-US

## Tax Dollars Are Now Funding Christian-Nationalist Schools
 - [https://www.reddit.com/r/politics/comments/1dju4a7/tax_dollars_are_now_funding_christiannationalist](https://www.reddit.com/r/politics/comments/1dju4a7/tax_dollars_are_now_funding_christiannationalist)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T21:08:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dju4a7/tax_dollars_are_now_funding_christiannationalist/"> <img alt="Tax Dollars Are Now Funding Christian-Nationalist Schools" src="https://external-preview.redd.it/NvMfv6xmS0NAj3jCS8xrVPDb3NlPFKrKh1qY-xTyzr8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e1b4eb29616de33dd5d022b2a03da0fd82dc42a5" title="Tax Dollars Are Now Funding Christian-Nationalist Schools" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/snacksv1"> /u/snacksv1 </a> <br /> <span><a href="https://nymag.com/intelligencer/article/tax-dollars-funding-christian-nationalist-schools.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dju4a7/tax_dollars_are_now_funding_christiannationalist/">[comments]</a></span> </td></tr></table>

## Louisiana governor ‘can’t wait to be sued’ after forcing the Ten Commandments in classrooms
 - [https://www.reddit.com/r/politics/comments/1djsqzq/louisiana_governor_cant_wait_to_be_sued_after](https://www.reddit.com/r/politics/comments/1djsqzq/louisiana_governor_cant_wait_to_be_sued_after)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T20:10:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djsqzq/louisiana_governor_cant_wait_to_be_sued_after/"> <img alt="Louisiana governor ‘can’t wait to be sued’ after forcing the Ten Commandments in classrooms" src="https://external-preview.redd.it/-BexLcg_0KBv3ZjeBfiptKWrFv44jXn_9EAhl7lQADM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=43cfeb90ebf9880ba1f07fd43b2fea6eb86683b5" title="Louisiana governor ‘can’t wait to be sued’ after forcing the Ten Commandments in classrooms" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Meganiummobile"> /u/Meganiummobile </a> <br /> <span><a href="https://www.independent.co.uk/news/world/americas/us-politics/ten-commandments-louisiana-governor-veto-b2565515.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djsqzq/louisiana_governor_cant_wait_to_be_sued_after/">[comments]</a></span> </td></tr></table>

## Trump Tries to Set Expectations, and Floats Excuses, for His Debate With Biden
 - [https://www.reddit.com/r/politics/comments/1djrnbf/trump_tries_to_set_expectations_and_floats](https://www.reddit.com/r/politics/comments/1djrnbf/trump_tries_to_set_expectations_and_floats)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T19:24:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djrnbf/trump_tries_to_set_expectations_and_floats/"> <img alt="Trump Tries to Set Expectations, and Floats Excuses, for His Debate With Biden" src="https://external-preview.redd.it/IKCjSO9JgOpUIWQijV3O4x9ODmqlh8i052BtX2h7_TE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b7e37bd53ab1760640a9412f7e275cf5d9494496" title="Trump Tries to Set Expectations, and Floats Excuses, for His Debate With Biden" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/drtolmn69"> /u/drtolmn69 </a> <br /> <span><a href="https://www.nytimes.com/2024/06/19/us/politics/trump-biden-debate-expectations.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djrnbf/trump_tries_to_set_expectations_and_floats/">[comments]</a></span> </td></tr></table>

## Donald Trump accused of repeatedly "waving to nobody"
 - [https://www.reddit.com/r/politics/comments/1djq90r/donald_trump_accused_of_repeatedly_waving_to](https://www.reddit.com/r/politics/comments/1djq90r/donald_trump_accused_of_repeatedly_waving_to)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T18:26:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djq90r/donald_trump_accused_of_repeatedly_waving_to/"> <img alt="Donald Trump accused of repeatedly &quot;waving to nobody&quot;" src="https://external-preview.redd.it/lGpMatuZ24ni81lYU0fe7j7oIZX57YfUwtI6d12c1V8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1d42f74338ae710727731c1955a7c933a4090df2" title="Donald Trump accused of repeatedly &quot;waving to nobody&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CrispyMiner"> /u/CrispyMiner </a> <br /> <span><a href="https://www.newsweek.com/donald-trump-waving-video-nobody-1914619">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djq90r/donald_trump_accused_of_repeatedly_waving_to/">[comments]</a></span> </td></tr></table>

## The Ten Commandments must be displayed in Louisiana classrooms under requirement signed into law
 - [https://www.reddit.com/r/politics/comments/1djpuoj/the_ten_commandments_must_be_displayed_in](https://www.reddit.com/r/politics/comments/1djpuoj/the_ten_commandments_must_be_displayed_in)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T18:10:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djpuoj/the_ten_commandments_must_be_displayed_in/"> <img alt="The Ten Commandments must be displayed in Louisiana classrooms under requirement signed into law" src="https://external-preview.redd.it/d9YP7aiLG2UF5qXlJ81LK2c8DcRBLMg2pupTfeBLc7I.jpg?width=216&amp;crop=smart&amp;auto=webp&amp;s=53f64cbd7e41ba7e1acd511375026e2ce41efa1f" title="The Ten Commandments must be displayed in Louisiana classrooms under requirement signed into law" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JonAce"> /u/JonAce </a> <br /> <span><a href="https://www.woodtv.com/news/national/ap-us-news/ap-the-ten-commandments-must-be-displayed-in-louisiana-classrooms-under-requirement-signed-into-law/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djpuoj/the_ten_commandments_must_be_displayed_in/">[comments]</a></span> </td></tr></table>

## Author Who Interviewed Trump 6 Times Offers Damning Examples Of Cognitive Struggles
 - [https://www.reddit.com/r/politics/comments/1djpeay/author_who_interviewed_trump_6_times_offers](https://www.reddit.com/r/politics/comments/1djpeay/author_who_interviewed_trump_6_times_offers)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T17:51:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djpeay/author_who_interviewed_trump_6_times_offers/"> <img alt="Author Who Interviewed Trump 6 Times Offers Damning Examples Of Cognitive Struggles" src="https://external-preview.redd.it/m6SdLuK92UJcLPx9rNfwMusux2O9Nqax_ONoRElotG0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=aaaa0d7874cfc22a7fb58b9baed7d513ebe8902c" title="Author Who Interviewed Trump 6 Times Offers Damning Examples Of Cognitive Struggles" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mostly-sun"> /u/mostly-sun </a> <br /> <span><a href="https://www.huffpost.com/entry/donald-trump-cognitive-author_n_667140d3e4b08889dbe60d67">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djpeay/author_who_interviewed_trump_6_times_offers/">[comments]</a></span> </td></tr></table>

## Texas doctor charged for leaking health records of transgender kids to far-right extremist. Eithan Haim allegedly stole private health records of transgender kids who weren’t his patients and gave their medical information to an anti-trans activist.
 - [https://www.reddit.com/r/politics/comments/1djpca7/texas_doctor_charged_for_leaking_health_records](https://www.reddit.com/r/politics/comments/1djpca7/texas_doctor_charged_for_leaking_health_records)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T17:49:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djpca7/texas_doctor_charged_for_leaking_health_records/"> <img alt="Texas doctor charged for leaking health records of transgender kids to far-right extremist. Eithan Haim allegedly stole private health records of transgender kids who weren’t his patients and gave their medical information to an anti-trans activist. " src="https://external-preview.redd.it/GHHqMKD-fZ6okNe_IFmBJ6Cdcc-gPrPn_Pse_IBQ1Sk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=75747502d49c8ec67bced43c0be88919dc8715bb" title="Texas doctor charged for leaking health records of transgender kids to far-right extremist. Eithan Haim allegedly stole private health records of transgender kids who weren’t his patients and gave their medical information to an anti-trans activist. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/southpawFA"> /u/southpawFA </a> <br /> <span><a href="https://www.advocate.com/crime/texas-doctor

## Fact Sheet: Biden-⁠Harris Administration Announces Historic Rules to Create Good-Paying, High-Quality Clean Energy Jobs
 - [https://www.reddit.com/r/politics/comments/1djov3d/fact_sheet_bidenharris_administration_announces](https://www.reddit.com/r/politics/comments/1djov3d/fact_sheet_bidenharris_administration_announces)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T17:29:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djov3d/fact_sheet_bidenharris_administration_announces/"> <img alt="Fact Sheet: Biden-⁠Harris Administration Announces Historic Rules to Create Good-Paying, High-Quality Clean Energy Jobs" src="https://external-preview.redd.it/D4ApVTqUzlai30E0NQT1Y_RowF1Ep9U50QtDLAsxB34.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=27928d9be45d463a3b4051943a3034a17f93310c" title="Fact Sheet: Biden-⁠Harris Administration Announces Historic Rules to Create Good-Paying, High-Quality Clean Energy Jobs" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/brain_overclocked"> /u/brain_overclocked </a> <br /> <span><a href="https://www.whitehouse.gov/briefing-room/statements-releases/2024/06/18/fact-sheet-biden-harris-administration-announces-historic-rules-to-create-good-paying-high-quality-clean-energy-jobs/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djov3d/fact_sheet

## Something’s Rotten About the Justices Taking So Long on Trump’s Immunity Case
 - [https://www.reddit.com/r/politics/comments/1djo6qg/somethings_rotten_about_the_justices_taking_so](https://www.reddit.com/r/politics/comments/1djo6qg/somethings_rotten_about_the_justices_taking_so)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T17:00:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djo6qg/somethings_rotten_about_the_justices_taking_so/"> <img alt="Something’s Rotten About the Justices Taking So Long on Trump’s Immunity Case" src="https://external-preview.redd.it/T_bMamXwlSZaSYyYX5vCkn1byG5PhXULpzliOnWzixE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0cb6ad79ab9f332238a696b774647489ca55ec05" title="Something’s Rotten About the Justices Taking So Long on Trump’s Immunity Case" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/unnecessarycharacter"> /u/unnecessarycharacter </a> <br /> <span><a href="https://www.nytimes.com/2024/06/19/opinion/supreme-court-trump-immunity.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djo6qg/somethings_rotten_about_the_justices_taking_so/">[comments]</a></span> </td></tr></table>

## Trump calls Biden’s student loan forgiveness a ‘vile’ publicity stunt
 - [https://www.reddit.com/r/politics/comments/1djnu99/trump_calls_bidens_student_loan_forgiveness_a](https://www.reddit.com/r/politics/comments/1djnu99/trump_calls_bidens_student_loan_forgiveness_a)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T16:46:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djnu99/trump_calls_bidens_student_loan_forgiveness_a/"> <img alt="Trump calls Biden’s student loan forgiveness a ‘vile’ publicity stunt" src="https://external-preview.redd.it/rlwPYdlxSDJl9XnnxDVZnAWDg-pFEdU5jf2QrOYMCyo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c7d90d5d57edf8d6643fa02d40ff900efe4ef522" title="Trump calls Biden’s student loan forgiveness a ‘vile’ publicity stunt" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Unlikely-Gas-1355"> /u/Unlikely-Gas-1355 </a> <br /> <span><a href="https://www.independent.co.uk/news/world/americas/us-politics/trump-student-loan-debt-biden-b2565365.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djnu99/trump_calls_bidens_student_loan_forgiveness_a/">[comments]</a></span> </td></tr></table>

## Trump’s Conviction Doesn’t Change the Fact That the Criminal Justice System Is Rigged In Favor of Rich Elites
 - [https://www.reddit.com/r/politics/comments/1djnfh7/trumps_conviction_doesnt_change_the_fact_that_the](https://www.reddit.com/r/politics/comments/1djnfh7/trumps_conviction_doesnt_change_the_fact_that_the)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T16:29:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djnfh7/trumps_conviction_doesnt_change_the_fact_that_the/"> <img alt="Trump’s Conviction Doesn’t Change the Fact That the Criminal Justice System Is Rigged In Favor of Rich Elites" src="https://external-preview.redd.it/xooqe9UhJxON8yLgPBouTUHleuEx3xroXn-fzqO3TN8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f6ccee82c80e8c2c9d0dd0ae2f0b9f0378f113af" title="Trump’s Conviction Doesn’t Change the Fact That the Criminal Justice System Is Rigged In Favor of Rich Elites" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PrestoVivace"> /u/PrestoVivace </a> <br /> <span><a href="https://inthesetimes.com/article/trump-conviction-hush-money-trial-2024">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djnfh7/trumps_conviction_doesnt_change_the_fact_that_the/">[comments]</a></span> </td></tr></table>

## Trump Brutally Exposed for Mindblowing Number of Lies in One Speech - Donald Trump made at least 30 false statements during an hour-and-a-half-long speech in Racine, Wisconsin.
 - [https://www.reddit.com/r/politics/comments/1djn7xd/trump_brutally_exposed_for_mindblowing_number_of](https://www.reddit.com/r/politics/comments/1djn7xd/trump_brutally_exposed_for_mindblowing_number_of)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T16:20:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djn7xd/trump_brutally_exposed_for_mindblowing_number_of/"> <img alt="Trump Brutally Exposed for Mindblowing Number of Lies in One Speech - Donald Trump made at least 30 false statements during an hour-and-a-half-long speech in Racine, Wisconsin." src="https://external-preview.redd.it/8NNAcj3RFr1ZKiCujvAuBaza4IXIh9kSY9Ksl_01UlI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f7f292945e36d2b1203d0642c3f5ee9ce5fcdda3" title="Trump Brutally Exposed for Mindblowing Number of Lies in One Speech - Donald Trump made at least 30 false statements during an hour-and-a-half-long speech in Racine, Wisconsin." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br /> <span><a href="https://newrepublic.com/post/182883/trump-exposed-mindblowing-lies-one-speech">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djn7xd/trump_brutally_exposed_for_

## Ted Cruz Documents Leak: Everything We Know
 - [https://www.reddit.com/r/politics/comments/1djlv1k/ted_cruz_documents_leak_everything_we_know](https://www.reddit.com/r/politics/comments/1djlv1k/ted_cruz_documents_leak_everything_we_know)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T15:24:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djlv1k/ted_cruz_documents_leak_everything_we_know/"> <img alt="Ted Cruz Documents Leak: Everything We Know" src="https://external-preview.redd.it/aI-ieYm-GEOMPy2hWTulM64UARp6cQx3OhWdrUm3IJk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9f0ebfa4a7188018a0a0e68741c1d00b76c70d55" title="Ted Cruz Documents Leak: Everything We Know" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rock-n-roll-Kevin"> /u/Rock-n-roll-Kevin </a> <br /> <span><a href="https://www.newsweek.com/ted-cruz-documents-leak-everything-we-know-1914631">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djlv1k/ted_cruz_documents_leak_everything_we_know/">[comments]</a></span> </td></tr></table>

## Fauci: Trump really believed COVID would “disappear like magic”
 - [https://www.reddit.com/r/politics/comments/1djkn7o/fauci_trump_really_believed_covid_would_disappear](https://www.reddit.com/r/politics/comments/1djkn7o/fauci_trump_really_believed_covid_would_disappear)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T14:32:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djkn7o/fauci_trump_really_believed_covid_would_disappear/"> <img alt="Fauci: Trump really believed COVID would “disappear like magic”" src="https://external-preview.redd.it/EnnQUnlgmJXS-dMkWTzBn8mjColgfjtMgDJJP6iCXrs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2b5e14bda831d4dfa20a28a36113781af035890d" title="Fauci: Trump really believed COVID would “disappear like magic”" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/devlinadl"> /u/devlinadl </a> <br /> <span><a href="https://www.salon.com/2024/06/19/fauci-really-believed-would-disappear-like-magic/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djkn7o/fauci_trump_really_believed_covid_would_disappear/">[comments]</a></span> </td></tr></table>

## King Trump and the Greedy Knights of the Business Roundtable | The nation's most powerful CEOs are lining up to fund Trump, because they and their corporations want another giant tax cut and rollbacks of regulations. It's as simple as that and there's a word for it: greed.
 - [https://www.reddit.com/r/politics/comments/1djkf2s/king_trump_and_the_greedy_knights_of_the_business](https://www.reddit.com/r/politics/comments/1djkf2s/king_trump_and_the_greedy_knights_of_the_business)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T14:23:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djkf2s/king_trump_and_the_greedy_knights_of_the_business/"> <img alt="King Trump and the Greedy Knights of the Business Roundtable | The nation's most powerful CEOs are lining up to fund Trump, because they and their corporations want another giant tax cut and rollbacks of regulations. It's as simple as that and there's a word for it: greed." src="https://external-preview.redd.it/Vl46cK2D9ouq18akSzxH1c2Y5sJphh6kDsX_GZ3Sjlw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=968a4a1d3741a5cc72b5ebf35ef13420666c49f7" title="King Trump and the Greedy Knights of the Business Roundtable | The nation's most powerful CEOs are lining up to fund Trump, because they and their corporations want another giant tax cut and rollbacks of regulations. It's as simple as that and there's a word for it: greed." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WhileFalseRepeat"> /u/WhileFalseRepeat </a> <br /

## The deceptive Biden G7 video was quickly debunked. It kept going viral anyway.
 - [https://www.reddit.com/r/politics/comments/1djk8sl/the_deceptive_biden_g7_video_was_quickly_debunked](https://www.reddit.com/r/politics/comments/1djk8sl/the_deceptive_biden_g7_video_was_quickly_debunked)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T14:15:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djk8sl/the_deceptive_biden_g7_video_was_quickly_debunked/"> <img alt="The deceptive Biden G7 video was quickly debunked. It kept going viral anyway." src="https://external-preview.redd.it/rBGhGs5b4PDMFLYIe7FFYjhrSj-kiEAs697uQtm4tC4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=267dba33fb0ec4882bfbb166aa88b45e6dbabd5c" title="The deceptive Biden G7 video was quickly debunked. It kept going viral anyway." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nbcnews"> /u/nbcnews </a> <br /> <span><a href="https://www.nbcnews.com/tech/misinformation/biden-g7-video-joe-cheapfake-kept-going-viral-rcna157591">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djk8sl/the_deceptive_biden_g7_video_was_quickly_debunked/">[comments]</a></span> </td></tr></table>

## Trump’s Spiritual Adviser Resigns Amid Allegations He Molested 12-Year-Old
 - [https://www.reddit.com/r/politics/comments/1djjkf6/trumps_spiritual_adviser_resigns_amid_allegations](https://www.reddit.com/r/politics/comments/1djjkf6/trumps_spiritual_adviser_resigns_amid_allegations)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T13:46:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djjkf6/trumps_spiritual_adviser_resigns_amid_allegations/"> <img alt="Trump’s Spiritual Adviser Resigns Amid Allegations He Molested 12-Year-Old" src="https://external-preview.redd.it/keWIqcGYArpGXdlO2zSEoxeldCm29CfRm-44E9VWwCA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f5d7d764e96f594244a45c9a4fd2bb21e4d91d1e" title="Trump’s Spiritual Adviser Resigns Amid Allegations He Molested 12-Year-Old" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/elguiridelocho"> /u/elguiridelocho </a> <br /> <span><a href="https://www.thedailybeast.com/trumps-spiritual-adviser-robert-morris-resigns-amid-allegations-he-molested-12-year-old">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djjkf6/trumps_spiritual_adviser_resigns_amid_allegations/">[comments]</a></span> </td></tr></table>

## "It doesn't take a big swing": Expert says "one group" ditching Trump over conviction — independents
 - [https://www.reddit.com/r/politics/comments/1djjhy9/it_doesnt_take_a_big_swing_expert_says_one_group](https://www.reddit.com/r/politics/comments/1djjhy9/it_doesnt_take_a_big_swing_expert_says_one_group)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T13:42:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djjhy9/it_doesnt_take_a_big_swing_expert_says_one_group/"> <img alt="&quot;It doesn't take a big swing&quot;: Expert says &quot;one group&quot; ditching Trump over conviction — independents" src="https://external-preview.redd.it/Ia2ns4am3AxrRV7ee53AuFi2YJbtb4rBInyTYk9cR9U.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e22b05cddbd1b4dcd019175109cd144fbb68b7d3" title="&quot;It doesn't take a big swing&quot;: Expert says &quot;one group&quot; ditching Trump over conviction — independents" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/harsh2k5"> /u/harsh2k5 </a> <br /> <span><a href="https://www.salon.com/2024/06/19/it-doesnt-take-a-big-swing-expert-says-one-group-ditching-over-conviction--independents/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djjhy9/it_doesnt_take_a_big_swing_expert_says_one_group/">[comments]</a></span> </td></tr></table>

## U.S. says it doesn't know what Netanyahu is talking about after he attacks Biden for 'withholding weapons'
 - [https://www.reddit.com/r/politics/comments/1djin2d/us_says_it_doesnt_know_what_netanyahu_is_talking](https://www.reddit.com/r/politics/comments/1djin2d/us_says_it_doesnt_know_what_netanyahu_is_talking)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T13:02:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djin2d/us_says_it_doesnt_know_what_netanyahu_is_talking/"> <img alt="U.S. says it doesn't know what Netanyahu is talking about after he attacks Biden for 'withholding weapons'" src="https://external-preview.redd.it/IqCP1tfbSSB1izHwZiMrTYtgR3hMtd1JotdQIgNqiww.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=15c2d82a65511a0fb283a4ccd2022396772f5c00" title="U.S. says it doesn't know what Netanyahu is talking about after he attacks Biden for 'withholding weapons'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rav4gal"> /u/Rav4gal </a> <br /> <span><a href="https://www.nbcnews.com/news/world/white-house-rejects-netanyahu-criticism-withholding-weapons-israel-rcna157884">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djin2d/us_says_it_doesnt_know_what_netanyahu_is_talking/">[comments]</a></span> </td></tr></table>

## Donald Trump's influence over GOP stung by Virginia election surprise
 - [https://www.reddit.com/r/politics/comments/1dji979/donald_trumps_influence_over_gop_stung_by](https://www.reddit.com/r/politics/comments/1dji979/donald_trumps_influence_over_gop_stung_by)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T12:43:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dji979/donald_trumps_influence_over_gop_stung_by/"> <img alt="Donald Trump's influence over GOP stung by Virginia election surprise" src="https://external-preview.redd.it/qA1Sk8xN9P7g2AkVX4u4tzChA7W2P5sTIttNblToKco.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=86854c1bfa86b5654ceb1b86162bb7d689629fac" title="Donald Trump's influence over GOP stung by Virginia election surprise" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/YoanB"> /u/YoanB </a> <br /> <span><a href="https://www.newsweek.com/donald-trump-virginia-gop-primary-john-mcguire-bob-good-1914672">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dji979/donald_trumps_influence_over_gop_stung_by/">[comments]</a></span> </td></tr></table>

## After Netanyahu Video, Sanders Says US Should Halt 'All Offensive Military Aid'
 - [https://www.reddit.com/r/politics/comments/1dji2s0/after_netanyahu_video_sanders_says_us_should_halt](https://www.reddit.com/r/politics/comments/1dji2s0/after_netanyahu_video_sanders_says_us_should_halt)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T12:35:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dji2s0/after_netanyahu_video_sanders_says_us_should_halt/"> <img alt="After Netanyahu Video, Sanders Says US Should Halt 'All Offensive Military Aid'" src="https://external-preview.redd.it/ca2DL8jQtlGY44PW7N2sufu7KbfhOjxdevRrSYDXpa0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=13f132e0a5a77174de12d0e3f6c70b1651dd7750" title="After Netanyahu Video, Sanders Says US Should Halt 'All Offensive Military Aid'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/newsspotter"> /u/newsspotter </a> <br /> <span><a href="https://www.commondreams.org/news/benjamin-netanyahu-video">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dji2s0/after_netanyahu_video_sanders_says_us_should_halt/">[comments]</a></span> </td></tr></table>

## Almost 1 in 5 say student loan debt will have major influence on their vote: Survey
 - [https://www.reddit.com/r/politics/comments/1djh0fk/almost_1_in_5_say_student_loan_debt_will_have](https://www.reddit.com/r/politics/comments/1djh0fk/almost_1_in_5_say_student_loan_debt_will_have)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T11:38:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djh0fk/almost_1_in_5_say_student_loan_debt_will_have/"> <img alt="Almost 1 in 5 say student loan debt will have major influence on their vote: Survey" src="https://external-preview.redd.it/F0MGtGEZBMZ8GqWQeKyWoW5sodiRCszu7-Yn_yW_Ekw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=56a73d97cef7b95b2bd0d9ae6bdbcebd8ce9cadf" title="Almost 1 in 5 say student loan debt will have major influence on their vote: Survey" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Infidel8"> /u/Infidel8 </a> <br /> <span><a href="https://thehill.com/homenews/education/4725493-student-loan-debt-forgiveness-biden-trump-vote-election/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djh0fk/almost_1_in_5_say_student_loan_debt_will_have/">[comments]</a></span> </td></tr></table>

## "Virtually no public information": Trump campaign pays over $3 million to mystery company
 - [https://www.reddit.com/r/politics/comments/1djh0a5/virtually_no_public_information_trump_campaign](https://www.reddit.com/r/politics/comments/1djh0a5/virtually_no_public_information_trump_campaign)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T11:38:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djh0a5/virtually_no_public_information_trump_campaign/"> <img alt="&quot;Virtually no public information&quot;: Trump campaign pays over $3 million to mystery company" src="https://external-preview.redd.it/NVK9cHRXsvR5hMTyBUmobNhfpiayrCj_VUp-SINHJac.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bff7992bce11deb33505ac5fce56c95a30b8d553" title="&quot;Virtually no public information&quot;: Trump campaign pays over $3 million to mystery company" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/damonator5000"> /u/damonator5000 </a> <br /> <span><a href="https://www.salon.com/2024/06/18/virtually-no-public-information-campaign-pays-over-3-million-to-mystery-company/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djh0a5/virtually_no_public_information_trump_campaign/">[comments]</a></span> </td></tr></table>

## Arizona is sending taxpayer money to religious schools — and billionaires see it as a model for the US
 - [https://www.reddit.com/r/politics/comments/1djgm0l/arizona_is_sending_taxpayer_money_to_religious](https://www.reddit.com/r/politics/comments/1djgm0l/arizona_is_sending_taxpayer_money_to_religious)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T11:14:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djgm0l/arizona_is_sending_taxpayer_money_to_religious/"> <img alt="Arizona is sending taxpayer money to religious schools — and billionaires see it as a model for the US " src="https://external-preview.redd.it/lftv1aUaEOksQeBU4X7hduOxwy9bewaQ3cUJLQtEALU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4e5ea8fac7c8e5b3557adda89717280e3597398f" title="Arizona is sending taxpayer money to religious schools — and billionaires see it as a model for the US " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/strongerthenbefore20"> /u/strongerthenbefore20 </a> <br /> <span><a href="https://www.cnn.com/2024/06/19/politics/arizona-private-school-vouchers-invs/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djgm0l/arizona_is_sending_taxpayer_money_to_religious/">[comments]</a></span> </td></tr></table>

## Florida Republicans terrorized a teacher because of a Black Lives Matter flag. She hit back and won
 - [https://www.reddit.com/r/politics/comments/1djgge6/florida_republicans_terrorized_a_teacher_because](https://www.reddit.com/r/politics/comments/1djgge6/florida_republicans_terrorized_a_teacher_because)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T11:05:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djgge6/florida_republicans_terrorized_a_teacher_because/"> <img alt="Florida Republicans terrorized a teacher because of a Black Lives Matter flag. She hit back and won" src="https://external-preview.redd.it/MJkPc5NTaWfB42L6zRZg6ayTxk9qeo9hDx7FuYWJTAU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=78603f292f5574c435b3f63a567471f04fcb12f5" title="Florida Republicans terrorized a teacher because of a Black Lives Matter flag. She hit back and won" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zsreport"> /u/zsreport </a> <br /> <span><a href="https://www.salon.com/2024/06/19/florida-terrorized-a-teacher-because-of-a-black-lives-matter-flag-she-hit-back-and-won/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djgge6/florida_republicans_terrorized_a_teacher_because/">[comments]</a></span> </td></tr></table>

## Congress baffled to learn the private sector works from home more than fed employees
 - [https://www.reddit.com/r/politics/comments/1djfxyd/congress_baffled_to_learn_the_private_sector](https://www.reddit.com/r/politics/comments/1djfxyd/congress_baffled_to_learn_the_private_sector)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T10:33:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djfxyd/congress_baffled_to_learn_the_private_sector/"> <img alt="Congress baffled to learn the private sector works from home more than fed employees" src="https://external-preview.redd.it/ML4oEpZ7HzVrTMBj5VqPiHZMEHMe-2M89WVMoEKC2j0.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=138f871e26b8a62868743ea8ba4c4de02c7aabe9" title="Congress baffled to learn the private sector works from home more than fed employees" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BamBamBaRoo99"> /u/BamBamBaRoo99 </a> <br /> <span><a href="https://thehill.com/opinion/technology/4720227-its-shocking-only-to-congress-private-employees-work-remotely-more-than-feds/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djfxyd/congress_baffled_to_learn_the_private_sector/">[comments]</a></span> </td></tr></table>

## Georgia becomes first state to require election law training for police
 - [https://www.reddit.com/r/politics/comments/1djftsv/georgia_becomes_first_state_to_require_election](https://www.reddit.com/r/politics/comments/1djftsv/georgia_becomes_first_state_to_require_election)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T10:25:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djftsv/georgia_becomes_first_state_to_require_election/"> <img alt="Georgia becomes first state to require election law training for police" src="https://external-preview.redd.it/edXOTrk-FZtnLMiH7G99sBywIMILzDJkU4ZTDZ4mf9E.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2e249be660c9dd2dc4db4f7995b3e216c8bf73eb" title="Georgia becomes first state to require election law training for police" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/reddicyoulous"> /u/reddicyoulous </a> <br /> <span><a href="https://www.theguardian.com/us-news/article/2024/jun/19/georgia-police-election-law-training">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djftsv/georgia_becomes_first_state_to_require_election/">[comments]</a></span> </td></tr></table>

## Shocker Poll: Trump Verdict Actually Does Matter to Voters—Big-Time
 - [https://www.reddit.com/r/politics/comments/1djft61/shocker_poll_trump_verdict_actually_does_matter](https://www.reddit.com/r/politics/comments/1djft61/shocker_poll_trump_verdict_actually_does_matter)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T10:24:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djft61/shocker_poll_trump_verdict_actually_does_matter/"> <img alt="Shocker Poll: Trump Verdict Actually Does Matter to Voters—Big-Time" src="https://external-preview.redd.it/sTPR-719lbBLwO1kTRUxfODhFd-hIPJM5I3e9heYL_k.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b2554e09afebc2aca736dcf5cda81c06a8d885ee" title="Shocker Poll: Trump Verdict Actually Does Matter to Voters—Big-Time" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/OtmShanks55"> /u/OtmShanks55 </a> <br /> <span><a href="https://newrepublic.com/article/182810/shocker-poll-trump-verdict-actually-matter-votersbig-time">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djft61/shocker_poll_trump_verdict_actually_does_matter/">[comments]</a></span> </td></tr></table>

## Witness tells House Ethics Committee that Matt Gaetz paid her for sex: Sources
 - [https://www.reddit.com/r/politics/comments/1djfnte/witness_tells_house_ethics_committee_that_matt](https://www.reddit.com/r/politics/comments/1djfnte/witness_tells_house_ethics_committee_that_matt)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T10:15:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djfnte/witness_tells_house_ethics_committee_that_matt/"> <img alt="Witness tells House Ethics Committee that Matt Gaetz paid her for sex: Sources" src="https://external-preview.redd.it/wu2sxS1-w4k3POhU9YYmwGqAS3tfqhfN7KIdqHYCE7c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ee595c3e06ad1de68dc14c8d3a5b0d0e16b91c4c" title="Witness tells House Ethics Committee that Matt Gaetz paid her for sex: Sources" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/progress18"> /u/progress18 </a> <br /> <span><a href="https://abcnews.go.com/US/witness-tells-house-ethics-committee-matt-gaetz-paid/story?id=111217102">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djfnte/witness_tells_house_ethics_committee_that_matt/">[comments]</a></span> </td></tr></table>

## Charlottesville Overwhelmingly Rejects Donald Trump Candidate
 - [https://www.reddit.com/r/politics/comments/1djf8dh/charlottesville_overwhelmingly_rejects_donald](https://www.reddit.com/r/politics/comments/1djf8dh/charlottesville_overwhelmingly_rejects_donald)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T09:46:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djf8dh/charlottesville_overwhelmingly_rejects_donald/"> <img alt="Charlottesville Overwhelmingly Rejects Donald Trump Candidate" src="https://external-preview.redd.it/ZwpYjm6FhXKPNAJDtFJ2X3-jCEjUjV4q3uja3Hy028o.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f19882bb69a3d34957e6944b37ac90b6b5bb3f80" title="Charlottesville Overwhelmingly Rejects Donald Trump Candidate" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/newsweek"> /u/newsweek </a> <br /> <span><a href="https://www.newsweek.com/charlottesville-rejects-donald-trump-candidate-john-mcguire-bob-good-1914661">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djf8dh/charlottesville_overwhelmingly_rejects_donald/">[comments]</a></span> </td></tr></table>

## Marjorie Taylor Greene Opponent Vows To 'Fight Like Hell' To Bring Her Down
 - [https://www.reddit.com/r/politics/comments/1djec6z/marjorie_taylor_greene_opponent_vows_to_fight](https://www.reddit.com/r/politics/comments/1djec6z/marjorie_taylor_greene_opponent_vows_to_fight)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T08:43:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djec6z/marjorie_taylor_greene_opponent_vows_to_fight/"> <img alt="Marjorie Taylor Greene Opponent Vows To 'Fight Like Hell' To Bring Her Down" src="https://external-preview.redd.it/9a4HEdKVQ5omPjgh0yJS4MnC-SEv0s_gM4B6MFhi2Tg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7ecd259eb6cf522a7eb3f35ca3d0bf30704fef13" title="Marjorie Taylor Greene Opponent Vows To 'Fight Like Hell' To Bring Her Down" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/newsweek"> /u/newsweek </a> <br /> <span><a href="https://www.newsweek.com/marjorie-taylor-greene-opponent-shawn-harris-vows-fight-defeat-her-november-elections-1914649">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djec6z/marjorie_taylor_greene_opponent_vows_to_fight/">[comments]</a></span> </td></tr></table>

## Florida Democrats increasingly confident as polls show party has 'momentum'
 - [https://www.reddit.com/r/politics/comments/1dje1jn/florida_democrats_increasingly_confident_as_polls](https://www.reddit.com/r/politics/comments/1dje1jn/florida_democrats_increasingly_confident_as_polls)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T08:21:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dje1jn/florida_democrats_increasingly_confident_as_polls/"> <img alt="Florida Democrats increasingly confident as polls show party has 'momentum' " src="https://external-preview.redd.it/PEPypM5jc18vaaGR6pdTxgo6zuq8E0QdxlVlRws0S9Y.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e8ae6e968c3b5813692c985563861dd39e3c121b" title="Florida Democrats increasingly confident as polls show party has 'momentum' " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/newsweek"> /u/newsweek </a> <br /> <span><a href="https://www.newsweek.com/florida-democrats-elections-polls-1914088">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dje1jn/florida_democrats_increasingly_confident_as_polls/">[comments]</a></span> </td></tr></table>

## Scoop: White House cancels meeting, scolds Netanyahu in protest over video
 - [https://www.reddit.com/r/politics/comments/1djacyi/scoop_white_house_cancels_meeting_scolds](https://www.reddit.com/r/politics/comments/1djacyi/scoop_white_house_cancels_meeting_scolds)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T04:17:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1djacyi/scoop_white_house_cancels_meeting_scolds/"> <img alt="Scoop: White House cancels meeting, scolds Netanyahu in protest over video" src="https://external-preview.redd.it/_SOWqc3vOfasqGM42mDzJ8DigH3GLTm3WZ2WQjuRUPc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e81bfd7e54ef9d69c4aad141fc0565d2f6053598" title="Scoop: White House cancels meeting, scolds Netanyahu in protest over video" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NotTaken2022"> /u/NotTaken2022 </a> <br /> <span><a href="https://www.axios.com/2024/06/19/netanyahu-video-biden-cancels-iran-meeting">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1djacyi/scoop_white_house_cancels_meeting_scolds/">[comments]</a></span> </td></tr></table>

## The Facebook Comment Section Is Taking Over The GOP
 - [https://www.reddit.com/r/politics/comments/1dj6kvt/the_facebook_comment_section_is_taking_over_the](https://www.reddit.com/r/politics/comments/1dj6kvt/the_facebook_comment_section_is_taking_over_the)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T00:56:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dj6kvt/the_facebook_comment_section_is_taking_over_the/"> <img alt="The Facebook Comment Section Is Taking Over The GOP" src="https://external-preview.redd.it/McmU5JAvx1iUAgygkT8WEqJo_HxDJA4Vl0K-Q_yAbCA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0c3083e638898e04f240971a9b0236cf666304b3" title="The Facebook Comment Section Is Taking Over The GOP" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DazzlingAdvantage600"> /u/DazzlingAdvantage600 </a> <br /> <span><a href="https://talkingpointsmemo.com/where-things-stand/the-facebook-comment-section-is-taking-over-the-gop">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dj6kvt/the_facebook_comment_section_is_taking_over_the/">[comments]</a></span> </td></tr></table>

## Star of Trump’s first impeachment, Eugene Vindman, wins Democratic House primary in Virginia
 - [https://www.reddit.com/r/politics/comments/1dj5tct/star_of_trumps_first_impeachment_eugene_vindman](https://www.reddit.com/r/politics/comments/1dj5tct/star_of_trumps_first_impeachment_eugene_vindman)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T00:18:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dj5tct/star_of_trumps_first_impeachment_eugene_vindman/"> <img alt="Star of Trump’s first impeachment, Eugene Vindman, wins Democratic House primary in Virginia" src="https://external-preview.redd.it/D2VK3yHMJbv393-UFlpOKq562m4XLpKD9uvbwgZcayA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7a130a1b6c5b82d7ee856cfb269e4b858060f30f" title="Star of Trump’s first impeachment, Eugene Vindman, wins Democratic House primary in Virginia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/unital_subalgebra"> /u/unital_subalgebra </a> <br /> <span><a href="https://www.independent.co.uk/news/world/americas/us-politics/vindman-wins-virginia-congress-democrats-b2564945.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dj5tct/star_of_trumps_first_impeachment_eugene_vindman/">[comments]</a></span> </td></tr></table>

## Key figure in first Trump impeachment wins Democratic primary for Spanberger seat
 - [https://www.reddit.com/r/politics/comments/1dj5fol/key_figure_in_first_trump_impeachment_wins](https://www.reddit.com/r/politics/comments/1dj5fol/key_figure_in_first_trump_impeachment_wins)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-06-19T00:00:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1dj5fol/key_figure_in_first_trump_impeachment_wins/"> <img alt="Key figure in first Trump impeachment wins Democratic primary for Spanberger seat" src="https://external-preview.redd.it/X2dfgGvpqB4hL7YKFDAYnWyHrvgqPqKBySS4eLSFCp4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f6e79ec8b96d41d48e9cec9d097397f594bfaf01" title="Key figure in first Trump impeachment wins Democratic primary for Spanberger seat" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HandSack135"> /u/HandSack135 </a> <br /> <span><a href="https://thehill.com/homenews/campaign/4728516-eugene-vindman-virginia-donald-trump-abigail-spanberger/mlite/?nxs-test=mlite">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1dj5fol/key_figure_in_first_trump_impeachment_wins/">[comments]</a></span> </td></tr></table>

