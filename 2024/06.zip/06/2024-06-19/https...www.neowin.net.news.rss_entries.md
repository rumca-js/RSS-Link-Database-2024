# Source:Neowin, URL:https://www.neowin.net/news/rss, language:en-us

## Microsoft details Windows 11 24H2 gaming upgrades like Prism, BattlEye Anti-Cheat, for Arm
 - [https://www.neowin.net/news/microsoft-details-windows-11-24h2-gaming-upgrades-like-prism-battleye-anti-cheat-for-arm](https://www.neowin.net/news/microsoft-details-windows-11-24h2-gaming-upgrades-like-prism-battleye-anti-cheat-for-arm)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T23:50:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/09/1633026576_windows-11-xbox_medium.jpg" /></div>Following details about printer support and app performance, Microsoft has now released details about gaming-related features and technology it has added to Windows 11 24H2 for Arm PCs. <a href="https://www.neowin.net/news/microsoft-details-windows-11-24h2-gaming-upgrades-like-prism-battleye-anti-cheat-for-arm/">Read more...</a>

## Microsoft releases some details on Windows 11 24H2 printer support, app performance for Arm
 - [https://www.neowin.net/news/microsoft-releases-some-details-on-windows-11-24h2-printer-support-app-performance-for-arm](https://www.neowin.net/news/microsoft-releases-some-details-on-windows-11-24h2-printer-support-app-performance-for-arm)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T21:46:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/04/1712503634_24h2_medium.jpg" /></div>Microsoft has published some details about Windows 11 24H2 support for printers and other peripherals as well as app performance. This is specifically for Windows on Arm-based devices. <a href="https://www.neowin.net/news/microsoft-releases-some-details-on-windows-11-24h2-printer-support-app-performance-for-arm/">Read more...</a>

## Windows 11 Insider Canary Channel build 26241 adds new File Explorer Address Bar features
 - [https://www.neowin.net/news/windows-11-insider-canary-channel-build-26241-adds-new-file-explorer-address-bar-features](https://www.neowin.net/news/windows-11-insider-canary-channel-build-26241-adds-new-file-explorer-address-bar-features)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T21:30:48+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1680966753_windows_11_insider_preview_promo_2_medium.jpg" /></div>Microsoft has released the latest Windows 11 build for members of the Windows Insider Program in the Canary Channel. The new 26241 build has some new File Explorer Address Bar features. <a href="https://www.neowin.net/news/windows-11-insider-canary-channel-build-26241-adds-new-file-explorer-address-bar-features/">Read more...</a>

## The latest Dev Home Preview version 0.15 has SSH keychain widget changes and more
 - [https://www.neowin.net/news/the-latest-dev-home-preview-version-015-has-ssh-keychain-widget-changes-and-more](https://www.neowin.net/news/the-latest-dev-home-preview-version-015-has-ssh-keychain-widget-changes-and-more)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T21:18:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1716312945_dev_home_medium.jpg" /></div>Microsoft has released the latest preview version of its Dev Home utilities software. The new 0.15 version includes some changes to its SSH keychain widget, among other changes and fixes. <a href="https://www.neowin.net/news/the-latest-dev-home-preview-version-015-has-ssh-keychain-widget-changes-and-more/">Read more...</a>

## The latest Towerborne blog post reveals more info on the game's main base, the Belfry
 - [https://www.neowin.net/news/the-latest-towerborne-blog-post-reveals-more-info-on-the-games-main-base-the-belfry](https://www.neowin.net/news/the-latest-towerborne-blog-post-reveals-more-info-on-the-games-main-base-the-belfry)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T19:32:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718823947_tower_forge-logo_medium.jpg" /></div>Stoic Games has posted a new blog entry for its upcoming third-person action-adventure game Towerborne. This post offers more info on the game&#039;s main base of operations, the Belfry. <a href="https://www.neowin.net/news/the-latest-towerborne-blog-post-reveals-more-info-on-the-games-main-base-the-belfry/">Read more...</a>

## The former OpenAI chief scientist has co-founded a new company, Safe Superintelligence Inc
 - [https://www.neowin.net/news/the-former-openai-chief-scientist-has-co-founded-a-new-company-safe-superintelligence-inc](https://www.neowin.net/news/the-former-openai-chief-scientist-has-co-founded-a-new-company-safe-superintelligence-inc)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T18:58:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1714954287_depositphotos_393791570_s_medium.jpg" /></div>Ilya Sutskever, who left his gig as Chief Scientist at OpenAI a few weeks ago, has just announced he is the co-founder of a new AI startup company, called Safe Superintelligence Inc. <a href="https://www.neowin.net/news/the-former-openai-chief-scientist-has-co-founded-a-new-company-safe-superintelligence-inc/">Read more...</a>

## Microsoft rolls out the new Copilot app experience to members of the Windows 11 Beta Channel
 - [https://www.neowin.net/news/microsoft-rolls-out-the-new-copilot-app-experience-to-members-of-the-windows-11-beta-channel](https://www.neowin.net/news/microsoft-rolls-out-the-new-copilot-app-experience-to-members-of-the-windows-11-beta-channel)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T18:32:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1680966759_windows_11_insider_preview_promo_3_medium.jpg" /></div>Microsoft has revealed it is now rolling out the new Copilot experience, which supports pinning Copilot to the Windows 11 taskbar so it works like an app, for members of the Insider Beta Channel. <a href="https://www.neowin.net/news/microsoft-rolls-out-the-new-copilot-app-experience-to-members-of-the-windows-11-beta-channel/">Read more...</a>

## Microsoft quietly pauses the rollout of Windows 11 Canary Channel build 26236
 - [https://www.neowin.net/news/microsoft-quietly-pauses-the-rollout-of-windows-11-canary-channel-build-26236](https://www.neowin.net/news/microsoft-quietly-pauses-the-rollout-of-windows-11-canary-channel-build-26236)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T17:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1680966766_windows_11_insider_preview_promo_4_medium.jpg" /></div>Microsoft has updated the blog post for last week&#039;s release of Windows 11 Canary Channel build 26236, stating it has paused the release of that build. No reason was given for this action. <a href="https://www.neowin.net/news/microsoft-quietly-pauses-the-rollout-of-windows-11-canary-channel-build-26236/">Read more...</a>

## PDF Expert One-Time Purchase Price-Dropped to 42% off
 - [https://www.neowin.net/deals/pdf-expert-one-time-purchase-price-dropped-to-42-off](https://www.neowin.net/deals/pdf-expert-one-time-purchase-price-dropped-to-42-off)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T17:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/01/1580206532_pdf-expert-mac-deal_medium.jpg" /></div>This Apple Editors&#039; Choice Winner will revolutionize the way you work and collaborate with documents. Fix distortions, remove shadows and improve contrast on difficult-to-read documents. <a href="https://www.neowin.net/deals/pdf-expert-one-time-purchase-price-dropped-to-42-off/">Read more...</a>

## iOS 18 to allow third-party apps to record Spatial videos for Apple Vision Pro
 - [https://www.neowin.net/news/ios-18-to-allow-third-party-apps-to-record-spatial-videos-for-apple-vision-pro](https://www.neowin.net/news/ios-18-to-allow-third-party-apps-to-record-spatial-videos-for-apple-vision-pro)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T15:50:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718811482_spatial-video-iphone_medium.jpg" /></div>During WWDC 2024 keynotes, Apple released an API that allows third-party app developers to offer Spatial Video recording in any app and it would work on iPhone 15 Pro models running iOS 18. <a href="https://www.neowin.net/news/ios-18-to-allow-third-party-apps-to-record-spatial-videos-for-apple-vision-pro/">Read more...</a>

## Download: Cybersecurity Architect's Handbook ($47.99 Value) for free
 - [https://www.neowin.net/sponsored/download-cybersecurity-architects-handbook-4799-value-for-free](https://www.neowin.net/sponsored/download-cybersecurity-architects-handbook-4799-value-for-free)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T15:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718303898_w_pacc31c82_medium.jpg" /></div>To prepare you for the road ahead and augment your existing skills, the book provides invaluable tips and practices that will contribute to your success as a CSA. This free offer ends on June 26. <a href="https://www.neowin.net/sponsored/download-cybersecurity-architects-handbook-4799-value-for-free/">Read more...</a>

## Apple's fancy home unlock feature won't support existing smart locks
 - [https://www.neowin.net/news/apples-fancy-home-unlock-feature-wont-support-existing-smart-locks](https://www.neowin.net/news/apples-fancy-home-unlock-feature-wont-support-existing-smart-locks)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T14:44:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718806669_apple_home_key_ios_medium.jpg" /></div>Apple unveiled its hands-free unlocking feature for the Home app, which will be a part of iOS 18. It&#039;s reported that there are no smart locks on the market right now that can support the feature. <a href="https://www.neowin.net/news/apples-fancy-home-unlock-feature-wont-support-existing-smart-locks/">Read more...</a>

## Some gamers are not happy the new Marvel vs. Capcom Collection is not coming to Xbox
 - [https://www.neowin.net/news/some-gamers-are-not-happy-the-new-marvel-vs-capcom-collection-is-not-coming-to-xbox](https://www.neowin.net/news/some-gamers-are-not-happy-the-new-marvel-vs-capcom-collection-is-not-coming-to-xbox)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T14:28:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718805424_marvel-vs-capcom_medium.jpg" /></div>Capcom announced a new collection of classic games this week, the Marvel vs. Capcom Collection, but the publisher won&#039;t bring the collection to Xbox consoles, and that has made some gamers very upset. <a href="https://www.neowin.net/news/some-gamers-are-not-happy-the-new-marvel-vs-capcom-collection-is-not-coming-to-xbox/">Read more...</a>

## Mozilla fixes Firefox installation issues in version 127.0.1
 - [https://www.neowin.net/news/mozilla-fixes-firefox-installation-issues-in-version-12701](https://www.neowin.net/news/mozilla-fixes-firefox-installation-issues-in-version-12701)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T14:06:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/02/1614094569_firefox_medium.jpg" /></div>Mozilla has released a minor update for Firefox 127, which was shipped to all users earlier this week. Version 127.0.1 is now available for download with several important bug fixes. <a href="https://www.neowin.net/news/mozilla-fixes-firefox-installation-issues-in-version-12701/">Read more...</a>

## We may finally see SSD prices go back down later this year
 - [https://www.neowin.net/news/we-may-finally-see-ssd-prices-go-back-down-later-this-year](https://www.neowin.net/news/we-may-finally-see-ssd-prices-go-back-down-later-this-year)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T13:48:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/07/1689681557_wd-black-ps5-ssd_medium.jpg" /></div>According to a South Korean news outlet, the major NAND flash memory makers like Samsung, Western Digital, and SK Hynix are boosting production, which could mean a reduction in SSD prices. <a href="https://www.neowin.net/news/we-may-finally-see-ssd-prices-go-back-down-later-this-year/">Read more...</a>

## UK anti-competition regulator looking to HPE's acquisition of Juniper Networks
 - [https://www.neowin.net/news/uk-anti-competition-regulator-looking-to-hpes-acquisition-of-juniper-networks](https://www.neowin.net/news/uk-anti-competition-regulator-looking-to-hpes-acquisition-of-juniper-networks)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T12:52:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718800138_depositphotos_358238158_s_medium.jpg" /></div>The UK&#039;s Competition and Markets Authority is investigating Hewlett Packard Enterprise&#039;s acquisition of Juniper Networks. It said that phase 1 of the investigation will close in August. <a href="https://www.neowin.net/news/uk-anti-competition-regulator-looking-to-hpes-acquisition-of-juniper-networks/">Read more...</a>

## Samsung may keep the camera upgrades reserved for the Galaxy S25 Ultra
 - [https://www.neowin.net/news/samsung-may-keep-the-camera-upgrades-reserved-for-the-galaxy-s25-ultra](https://www.neowin.net/news/samsung-may-keep-the-camera-upgrades-reserved-for-the-galaxy-s25-ultra)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T12:36:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718290345_galaxy-s24-hero_medium.jpg" /></div>Reportedly the camera upgrades in next year&#039;s Galaxy S25 lineup may be reserved only for the Galaxy S25 Ultra, and the Galaxy S25 and S25 Plus cameras may remain the same as their predecessors. <a href="https://www.neowin.net/news/samsung-may-keep-the-camera-upgrades-reserved-for-the-galaxy-s25-ultra/">Read more...</a>

## Get this 34-inch LG UltraGear OLED ultrawide PC monitor for an all-new low price of $749.99
 - [https://www.neowin.net/deals/get-this-34-inch-lg-ultragear-oled-ultrawide-pc-monitor-for-an-all-new-low-price-of-74999](https://www.neowin.net/deals/get-this-34-inch-lg-ultragear-oled-ultrawide-pc-monitor-for-an-all-new-low-price-of-74999)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T12:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/04/1714473370_lg-oled-34-inch-monitor_medium.jpg" /></div>The 34-inch LG UltraGear OLED ultrawide PC monitor includes a 240Hz refresh rate and a response time of just 0.03ms for great gaming visuals. It&#039;s hit a new all-time low price of $749.99. <a href="https://www.neowin.net/deals/get-this-34-inch-lg-ultragear-oled-ultrawide-pc-monitor-for-an-all-new-low-price-of-74999/">Read more...</a>

## Google Maps beta hints an old feature might get purged
 - [https://www.neowin.net/news/google-maps-beta-hints-an-old-feature-might-get-purged](https://www.neowin.net/news/google-maps-beta-hints-an-old-feature-might-get-purged)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T11:06:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1700061817_google_maps_running_on_phone_medium.jpg" /></div>A Google Maps feature that lets you follow businesses may not have much time left. An APK teardown of Google Maps beta suggests the feature will be removed from the navigation app, starting next year. <a href="https://www.neowin.net/news/google-maps-beta-hints-an-old-feature-might-get-purged/">Read more...</a>

## Save over $600 on the 65-inch 4K LG OLED evo C4 TV with Dolby Vision, Atmos
 - [https://www.neowin.net/deals/save-over-600-on-the-65-inch-4k-lg-oled-evo-c4-tv-with-dolby-vision-atmos](https://www.neowin.net/deals/save-over-600-on-the-65-inch-4k-lg-oled-evo-c4-tv-with-dolby-vision-atmos)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T10:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718777526_81e0zzuozyl._ac_sl1500__medium.jpg" /></div>You can currently buy the 65-inch LG OLED evo C4 for $2,096.99 on Amazon. It&#039;s presently on sale, down over $600 from its list price so you&#039;d be saving a lot by taking this opportunity to buy it. <a href="https://www.neowin.net/deals/save-over-600-on-the-65-inch-4k-lg-oled-evo-c4-tv-with-dolby-vision-atmos/">Read more...</a>

## Surface Pro 11 and Surface Laptop 7 get day-one firmware with display improvements
 - [https://www.neowin.net/news/surface-pro-11-and-surface-laptop-7-get-day-one-firmware-with-display-improvements](https://www.neowin.net/news/surface-pro-11-and-surface-laptop-7-get-day-one-firmware-with-display-improvements)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T09:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/05/1716289599_surface_pro_medium.jpg" /></div>If you purchased one of Microsoft&#039;s first Copilot+ PCs, be sure to check out Windows Update after setting up your device. There are day-one firmware updates to improve your experience. <a href="https://www.neowin.net/news/surface-pro-11-and-surface-laptop-7-get-day-one-firmware-with-display-improvements/">Read more...</a>

## WhatsApp spotted working on AR effects and filters for video calls
 - [https://www.neowin.net/news/whatsapp-spotted-working-on-ar-effects-and-filters-for-video-calls](https://www.neowin.net/news/whatsapp-spotted-working-on-ar-effects-and-filters-for-video-calls)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T08:16:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1702017531_whatsapp_logo_image_medium.jpg" /></div>WhatsApp is working on AR calling filters, avatars, and background effects for video calls. The underdevelopment feature was spotted in the latest WhatsApp beta for Android v2.24.13.14. <a href="https://www.neowin.net/news/whatsapp-spotted-working-on-ar-effects-and-filters-for-video-calls/">Read more...</a>

## This 32-inch LG 4K HDR IPS monitor is now at its lowest price following a 38% discount
 - [https://www.neowin.net/deals/this-32-inch-lg-4k-hdr-ips-monitor-is-now-at-its-lowest-price-following-a-38-discount](https://www.neowin.net/deals/this-32-inch-lg-4k-hdr-ips-monitor-is-now-at-its-lowest-price-following-a-38-discount)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T07:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718772697_0fcec621-9d31-409e-bb00-84ce4e921ecf.__cr63,0,1455,900_pt0_sx970_v1____medium.jpg" /></div>Amazon UK is currently selling the LG 32UN650P monitor for just £249.97 - that&#039;s a 38% discount off of the original £399.99 price that the monitor was originally available for. Read on to learn more. <a href="https://www.neowin.net/deals/this-32-inch-lg-4k-hdr-ips-monitor-is-now-at-its-lowest-price-following-a-38-discount/">Read more...</a>

## This is how much the Motorola Razr 50 and Razr 50 Ultra might cost you
 - [https://www.neowin.net/news/this-is-how-much-the-motorola-razr-50-and-razr-50-ultra-might-cost-you](https://www.neowin.net/news/this-is-how-much-the-motorola-razr-50-and-razr-50-ultra-might-cost-you)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T06:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718713150_moto-razr-50-launch-date_medium.jpg" /></div>Ahead of their scheduled official launch on June 25 in the US, fresh leaks have surfaced on the internet revealing the alleged prices of the Motorola Razr 50 and the Motorola Razr 50 Ultra. <a href="https://www.neowin.net/news/this-is-how-much-the-motorola-razr-50-and-razr-50-ultra-might-cost-you/">Read more...</a>

## Apple launches a website to help you find the right Mac for your needs
 - [https://www.neowin.net/news/apple-launches-a-website-to-help-you-find-the-right-mac-for-your-needs](https://www.neowin.net/news/apple-launches-a-website-to-help-you-find-the-right-mac-for-your-needs)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T04:40:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718769603_apple-help-me-choose-1_medium.jpg" /></div>Apple has launched a &#039;Help Me Choose&#039; website to make it easier to find the right Mac by asking you a few questions and suggesting a Mac that fits your needs and is within your budget. <a href="https://www.neowin.net/news/apple-launches-a-website-to-help-you-find-the-right-mac-for-your-needs/">Read more...</a>

## Microsoft: Windows 11 Pro to Enterprise upgrade fails with 0x80070005 error since KB5036893
 - [https://www.neowin.net/news/microsoft-windows-11-pro-to-enterprise-upgrade-fails-with-0x80070005-error-since-kb5036893](https://www.neowin.net/news/microsoft-windows-11-pro-to-enterprise-upgrade-fails-with-0x80070005-error-since-kb5036893)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T00:34:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/10/1666776970_windows_11_logo_medium.jpg" /></div>Microsoft has confirmed that Windows 11 Pro to Enterprise upgrade is currently broken even when using a valid subscription. Microsoft believes the issue started with the April Patch Tuesday. <a href="https://www.neowin.net/news/microsoft-windows-11-pro-to-enterprise-upgrade-fails-with-0x80070005-error-since-kb5036893/">Read more...</a>

## Microsoft: Windows 11 can't open Photos due to non-Admin Group policy/ CSP policy conflict
 - [https://www.neowin.net/news/microsoft-windows-11-cant-open-photos-due-to-non-admin-group-policy-csp-policy-conflict](https://www.neowin.net/news/microsoft-windows-11-cant-open-photos-due-to-non-admin-group-policy-csp-policy-conflict)
 - RSS feed: https://www.neowin.net/news/rss
 - date published: 2024-06-19T00:18:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/05/1653147028_windows_11_bug_(source-_sayan_s)_medium.jpg" /></div>Microsoft has confirmed that users can&#039;t open Photos app anymore after a recent Store update for the app. The issue is a result of a non-Admin Group policy or a CSP policy conflict. <a href="https://www.neowin.net/news/microsoft-windows-11-cant-open-photos-due-to-non-admin-group-policy-csp-policy-conflict/">Read more...</a>

