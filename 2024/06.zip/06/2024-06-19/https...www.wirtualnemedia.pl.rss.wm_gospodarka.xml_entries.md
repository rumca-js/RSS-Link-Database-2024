# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Producent smartwatchów pod lupą UOKiK. Przeszukano biura
 - [https://www.wirtualnemedia.pl/artykul/garmin-smartwatche-uokik-przeszukanie-siedziby](https://www.wirtualnemedia.pl/artykul/garmin-smartwatche-uokik-przeszukanie-siedziby)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-06-19T11:28:37.723562+00:00

Urząd Ochrony Konkurencji i Konsumentów wszczął postępowanie wyjaśniające w sprawie możliwego porozumienia ograniczającego konkurencję - firma Garmin Polska, przedstawiciel producenta m.in. smartwatchów, mogła zawrzeć zmowę cenową z dystrybutorami swoich produktów.

## Polacy chcą czterech dni pracy w tygodniu
 - [https://www.wirtualnemedia.pl/artykul/cztery-dni-pracy-w-tygodniu-opinie-polakow](https://www.wirtualnemedia.pl/artykul/cztery-dni-pracy-w-tygodniu-opinie-polakow)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-06-19T05:33:11.114074+00:00

63 proc. Polaków chciałoby pracować cztery dni w tygodniu, ale tylko 24 proc. zgodziłoby się na obniżenie swojego wynagrodzenia - wynika z badania Panelu Badawczego Ariadna. W zamian za zachowanie pełnej wysokości pensji 73 proc. badanych wolałaby pracować po 10 godzin dziennie.

## Nvidia wyprzedziła Microsoft. Jest najcenniejsza na giełdzie w USA
 - [https://www.wirtualnemedia.pl/artykul/nvidia-kurs-akcji-wycena-wyprzedzila-microsoft-gielda-w-usa](https://www.wirtualnemedia.pl/artykul/nvidia-kurs-akcji-wycena-wyprzedzila-microsoft-gielda-w-usa)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-06-19T05:33:11.038825+00:00

Główne indeksy na Wall Street zakończyły wtorkowe notowania wzrostami, a indeks S&amp;P 500 zanotował nowy rekord. W centrum uwagi były akcje Nvidia, gdyż spółka w ciągu dnia stała się najdroższą spółką notowaną na amerykańskiej giełdzie, detronizując na pozycji lidera Microsoft.

