# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Don't blame us for people suffering - London hospital hackers
 - [https://www.bbc.com/news/articles/ceddqglk7qgo](https://www.bbc.com/news/articles/ceddqglk7qgo)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-06-19T11:23:21+00:00

They claim the cyber attack - which has disrupted more than 1,000 procedures - was politically motivated.

## TikTok complaint referred to US justice department
 - [https://www.bbc.com/news/articles/crgg7z9d8rxo](https://www.bbc.com/news/articles/crgg7z9d8rxo)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-06-19T01:57:15+00:00

A spokesperson for the social media company said they were disappointed by the decision.

