# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed, language:en-US

## Dem Governor vetoes bill that would have helped and protected people who choose to detransition
 - [https://www.louderwithcrowder.com/detransitioners-arizona-bill-hobbs](https://www.louderwithcrowder.com/detransitioners-arizona-bill-hobbs)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-19T20:26:31+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52476504&amp;width=700&amp;height=1245&amp;coordinates=601%2C0%2C453%2C0" /><br /><br /><p>If trans people have rights, do de-trans people also have rights? Because in Arizona, they don’t. </p><p>Katie Hobbs just vetoed a bill that would have required that health care providers offer medical care to those who wish to de-transition. But Democrats are only interested in getting people to undergo medically unnecessary procedures, not fix it. They don’t care if vulnerable people later regret their sex change surgeries, as Hobbs has announced that’s a personal problem, at best.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Gov. <a href="https://twitter.com/katiehobbs?ref_src=twsrc%5Etfw">@katiehobbs</a>, a Democrat, has vetoed Arizona’s detransitioner bill of rights, which would guarantee insurance coverage for detransition care.<br /><br />Her single-line explanation:<br /><br />“This bill is u

## Watch: Joy Reid can't calm down about the dangerous rhetoric that is "white boy summer"
 - [https://www.louderwithcrowder.com/white-boy-summer](https://www.louderwithcrowder.com/white-boy-summer)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-19T20:23:37+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52476405&amp;width=700&amp;height=1245&amp;coordinates=227%2C0%2C228%2C0" /><br /><br /><p>Progressives tend to cry about things that are not real issues, which goes beyond “first-world problems.” And to no surprise, Joy Reid is always crying about something because she has nothing better to do. </p><p>Since nearly everything is racist, including things like board <a href="https://www.forbes.com/sites/paologaudiano/2020/07/29/a-board-game-that-brings-racial-inequities-to-life/" target="_blank">games </a>and <a href="https://www.scientificamerican.com/article/modern-mathematics-confronts-its-white-patriarchal-past/" target="_blank">math</a>, white boys enjoying summer are also racist because white boys can only enjoy the season if they don't vote for Trump.</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Joy Reid claims "white boy summer" is "dangerous rhetoric" <a href="https://t.co/8AfuedYqe

## New clothing company DEFENDS girls' sports against trans boys, so of course they get banned by TikTok
 - [https://www.louderwithcrowder.com/new-clothing-company-defends-girls-sports-against-trans-boys-so-of-course-they-get-banned-by-tiktok](https://www.louderwithcrowder.com/new-clothing-company-defends-girls-sports-against-trans-boys-so-of-course-they-get-banned-by-tiktok)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-19T20:21:45+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52476178&amp;width=1200&amp;height=400&amp;coordinates=0%2C122%2C0%2C99" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>The truth hurts and no one knows this better than Progressives who refuse to admit that biology is a thing. </p><p>TikTok just banned an ad that they deemed offensive because the app’s moderators refuse to admit that sex is real. </p><p><a href="https://thepostmillennial.com/tiktok-bans-offensive-ad-from-xx-xy-athletics-that-fights-for-womens-rights-in-sports#google_vignette" rel="noopener noreferrer" target="_blank"><u>According to </u><u><em><em>The Post Millenial: </em></em></u></a></p><blockquote>TikTok has permanently banned advertisements from XX-XY

## Watch: Climate whackadoodles vandalize Stonehenge in order to draw stop oil or something
 - [https://www.louderwithcrowder.com/just-stop-oil-orange-stonehenge-monument](https://www.louderwithcrowder.com/just-stop-oil-orange-stonehenge-monument)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-19T18:08:17+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52474648&amp;width=1200&amp;height=800&amp;coordinates=33%2C0%2C34%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>If leftists truly believed that humanity would cease to exist, why do so many activists waste time doing the dumbest things? Because it doesn't take a genius to realize that vandalizing ancient monuments will not help them control the direction of the wind. Nonetheless, here we are. </p><p>Two climate protestors with the extremist group Just Stop Oil were arrested after throwing orange paint at the Stonehenge monument in England. Unclear why they did that but we are supposed to believe this is part of their mission to save the world.</p><div class="rm-embe

## Watch: Middle-aged Taylor Lorenz tries to explain why zoomers are rejecting Biden in unintentionally hilarious fashion
 - [https://www.louderwithcrowder.com/lorenz-gen-z-biden](https://www.louderwithcrowder.com/lorenz-gen-z-biden)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-19T17:22:23+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52475002&amp;width=1200&amp;height=800&amp;coordinates=240%2C0%2C312%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>There is nothing more embarrassing than when an old person tries to be relatable to the younger generation. Taylor Lorenz seems to think she is the spokesperson for Gen Z, even though she's probably older than most of their parents. Nonetheless, she has the tea when it comes to all things Gaza, climate change, and TikTok bans. </p><p>Lorenz went on TikTok to try and be relatable to young whippersnappers. And what she supposedly discovered may not shock you, as she once again has mastered the leftist art of saying so much, yet nothing at all. </p><p class

## Watch: Kamala Harris X  "Queer Eye" turns into the Biden Adimn's latest cringefest for Pride month
 - [https://www.louderwithcrowder.com/queer-eye-s-white-house](https://www.louderwithcrowder.com/queer-eye-s-white-house)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-19T16:31:00+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52474505&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C25%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>If you look at all legal documents to have ever existed under the umbrella term of 'government, fiduciary duties,' nowhere will you find direction to invite the cast of “<a href="https://www.louderwithcrowder.com/van-ness-crying-podcast" target="_self"><u>Queer Eyes</u></a>” to the White House to play dress up and celebrate its 20th anniversary. But it turns out our very unserious government did not get that memo, and rather than protect the freedoms of Americans, which is their only job, they thought this was a better use of their time.</p><div class="rm-e

## EXCLUSIVE: Murderer Groomed High School Girl into Sex in Jail; Massive Cover-Up
 - [https://www.louderwithcrowder.com/exclusive-jail-massive-cover-up](https://www.louderwithcrowder.com/exclusive-jail-massive-cover-up)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-19T14:10:54+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=52474292&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C300%2C0" /><br /><br /><div class="rm-embed embed-media">
</div><p><strong><strong>COVER UP: Leaked Documents Reveal Violent Inmates Coerced Underage Vocational Program Intern at Ohio Jail Into Sex & Felony ‘Illegal Conveyance of Prohibited Items’; Local Officials Appear to Hide Evidence from US Authorities To Maintain Multi-Million Dollar Federal Funding</strong></strong></p><ul><ul><li><strong>Mug Club Undercover has exclusively obtained confidential source-leaked documents showing a major cover-up in Butler County, Ohio. We are publishing police reports, inmate letters, redacted images, and recordings today.</strong></li><li><strong>A female High School student working as a vocational program intern at Butler County jail was routinely left unsupervised within the facility with hardened federal inmates -- two of which were violent, repeat offenders.</

## Watch: Dingbat Joy Behar claims Trump will have "The View" taken off the air, effectively endorses him for president
 - [https://www.louderwithcrowder.com/joy-behar-rachel-maddow](https://www.louderwithcrowder.com/joy-behar-rachel-maddow)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-06-19T12:58:44+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52474186&amp;width=1200&amp;height=800&amp;coordinates=131%2C0%2C69%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>The shrill harpies from <em>The View</em> remain the most trusted name in low-information hackery. But every so often, they make a salient point. They were yakking it up with Rachel Maddow about the presidential election when, out of the blue, Joy Behar, of all people, ENDORSED Donald Trump for president. </p><p>She said if Trump gets re-elected president, he'll take The View off the air.</p><p>Okay, so she didn't <em>MEAN</em> it as an endorsement. Yet, still...</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">Joy Behar fears Donald

