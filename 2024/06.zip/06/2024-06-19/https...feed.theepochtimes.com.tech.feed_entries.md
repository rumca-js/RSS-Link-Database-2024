# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## FTC Refers TikTok Complaint to DOJ Following Investigation
 - [https://www.theepochtimes.com/us/ftc-refers-tiktok-complaint-to-doj-following-investigation-5670939](https://www.theepochtimes.com/us/ftc-refers-tiktok-complaint-to-doj-following-investigation-5670939)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-06-19T20:41:21+00:00

The TikTok Inc. logo is displayed on their building in Culver City, Calif., on March 11, 2024. (The Canadian Press/AP-Damian Dovarganes)

## Nvidia Eclipses Microsoft as World’s Most Valuable Company
 - [https://www.theepochtimes.com/business/nvidia-eclipses-microsoft-as-worlds-most-valuable-company-5671296](https://www.theepochtimes.com/business/nvidia-eclipses-microsoft-as-worlds-most-valuable-company-5671296)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-06-19T13:52:17+00:00

The logo of technology company Nvidia at its headquarters in Santa Clara, Calif., on Feb. 11, 2015. (Robert Galbraith/Reuters)

