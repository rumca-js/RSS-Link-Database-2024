# Source:Daily sceptic, URL:https://dailysceptic.org/feed, language:en-US

## Just as Corporations are Waking Up to the Chaos of EDI, Labour is Poised to Make it Worse Than You Can Imagine
 - [https://dailysceptic.org/2024/06/19/just-as-corporations-are-waking-up-to-the-chaos-of-edi-labour-is-poised-to-make-it-worse-than-you-can-imagine](https://dailysceptic.org/2024/06/19/just-as-corporations-are-waking-up-to-the-chaos-of-edi-labour-is-poised-to-make-it-worse-than-you-can-imagine)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-06-19T18:22:57+00:00

<p>Just as the corporate world is finally waking up to the catastrophic damage EDI has caused, Labour is about to make it worse than you can possibly imagine, says C.J. Strachan.</p>
<p>The post <a href="https://dailysceptic.org/2024/06/19/just-as-corporations-are-waking-up-to-the-chaos-of-edi-labour-is-poised-to-make-it-worse-than-you-can-imagine/">Just as Corporations are Waking Up to the Chaos of EDI, Labour is Poised to Make it Worse Than You Can Imagine</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Muslim Entrepreneur Donates Hundreds of Thousands of Pounds to Reform
 - [https://dailysceptic.org/2024/06/19/muslim-entrepreneur-donates-hundreds-of-thousands-of-pounds-to-reform](https://dailysceptic.org/2024/06/19/muslim-entrepreneur-donates-hundreds-of-thousands-of-pounds-to-reform)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-06-19T16:00:00+00:00

<p>A Muslim entrepreneur has donated hundreds of thousands of pounds to Reform U.K., saying migrants who came to Britain legally are dismayed that “we have lost control of our borders”.</p>
<p>The post <a href="https://dailysceptic.org/2024/06/19/muslim-entrepreneur-donates-hundreds-of-thousands-of-pounds-to-reform/">Muslim Entrepreneur Donates Hundreds of Thousands of Pounds to Reform</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Three Problems with the 24-Hour News Cycle
 - [https://dailysceptic.org/2024/06/19/three-problems-with-the-24-hour-news-cycle](https://dailysceptic.org/2024/06/19/three-problems-with-the-24-hour-news-cycle)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-06-19T14:00:00+00:00

<p>The relentless, social media-driven 24 hour news cycle is not conducive to the calm acquisition of knowledge about the world, says Professor James Alexander. How can we escape from it?</p>
<p>The post <a href="https://dailysceptic.org/2024/06/19/three-problems-with-the-24-hour-news-cycle/">Three Problems with the 24-Hour News Cycle</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Shh, Don’t Mention the Vaccines
 - [https://dailysceptic.org/2024/06/19/shh-dont-mention-the-vaccines](https://dailysceptic.org/2024/06/19/shh-dont-mention-the-vaccines)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-06-19T12:00:00+00:00

<p>Covid vaccines were touted as great achievements by Boris Johnson, Rishi Sunak and the Conservative party. But come the election and silence. Is it an admission that it has all gone sour, asks Prof David Livermore.</p>
<p>The post <a href="https://dailysceptic.org/2024/06/19/shh-dont-mention-the-vaccines/">Shh, Don&#8217;t Mention the Vaccines</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## We Need Covid Fine Amnesty, Says Ex-Justice Secretary During Pandemic
 - [https://dailysceptic.org/2024/06/19/we-need-covid-fine-amnesty-says-ex-justice-secretary-during-pandemic](https://dailysceptic.org/2024/06/19/we-need-covid-fine-amnesty-says-ex-justice-secretary-during-pandemic)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-06-19T10:31:28+00:00

<p>The Justice Secretary who oversaw the courts during the pandemic has called for an amnesty for the more than 29,000 people given criminal convictions for breaking Covid rules.</p>
<p>The post <a href="https://dailysceptic.org/2024/06/19/we-need-covid-fine-amnesty-says-ex-justice-secretary-during-pandemic/">We Need Covid Fine Amnesty, Says Ex-Justice Secretary During Pandemic</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Why Did the BBC and ITV Decide to Smear Reform With a Baseless Story About Election Manipulation on Social Media on the Same Day?
 - [https://dailysceptic.org/2024/06/19/why-on-the-same-day-did-the-bbc-and-itv-decide-to-smear-reform-with-a-baseless-story-about-election-manipulation-on-social-media](https://dailysceptic.org/2024/06/19/why-on-the-same-day-did-the-bbc-and-itv-decide-to-smear-reform-with-a-baseless-story-about-election-manipulation-on-social-media)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-06-19T08:00:00+00:00

<p>Why did the BBC and ITV decide to smear Reform – on the same day! – with a baseless story about 'bots' boosting their support on social media, asks Ben Pile. It's the latest example of dissenters being smeared by the MSM..</p>
<p>The post <a href="https://dailysceptic.org/2024/06/19/why-on-the-same-day-did-the-bbc-and-itv-decide-to-smear-reform-with-a-baseless-story-about-election-manipulation-on-social-media/">Why Did the BBC and ITV Decide to Smear Reform With a Baseless Story About Election Manipulation on Social Media on the Same Day?</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Nick Dixon and Toby Young Talk About Reform’s ‘Contract’ With the British People, England’s Irrepressible Football Fans and Tony Blair Discovering His Inner TERF
 - [https://dailysceptic.org/2024/06/19/nick-dixon-and-toby-young-talk-about-reforms-contract-with-the-british-people-englands-irrepressible-football-fans-and-tony-blair-discovering-his-inner-terf](https://dailysceptic.org/2024/06/19/nick-dixon-and-toby-young-talk-about-reforms-contract-with-the-british-people-englands-irrepressible-football-fans-and-tony-blair-discovering-his-inner-terf)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-06-19T06:00:00+00:00

<p>In the latest episode of the Weekly Sceptic, the talking points are Reform’s manifesto, Keir Starmer's real plans for Britain and Tony Blair's discovery of his inner TERF.</p>
<p>The post <a href="https://dailysceptic.org/2024/06/19/nick-dixon-and-toby-young-talk-about-reforms-contract-with-the-british-people-englands-irrepressible-football-fans-and-tony-blair-discovering-his-inner-terf/">Nick Dixon and Toby Young Talk About Reform’s ‘Contract’ With the British People, England’s Irrepressible Football Fans and Tony Blair Discovering His Inner TERF</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## News Round-Up
 - [https://dailysceptic.org/2024/06/19/news-round-up-1194](https://dailysceptic.org/2024/06/19/news-round-up-1194)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-06-19T01:16:09+00:00

<p>A summary of the most interesting stories in the past 24 hours that challenge the prevailing orthodoxy about the ‘climate emergency’, public health ‘crises’ and the supposed moral defects of Western civilisation.</p>
<p>The post <a href="https://dailysceptic.org/2024/06/19/news-round-up-1194/">News Round-Up</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

