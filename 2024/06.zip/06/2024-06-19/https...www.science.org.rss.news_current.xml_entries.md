# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## Climate change could make fungi more dangerous
 - [https://www.science.org/content/article/climate-change-could-make-fungi-more-dangerous](https://www.science.org/content/article/climate-change-could-make-fungi-more-dangerous)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-06-19T20:44:14.405482+00:00

Higher temperatures may trigger mutations that cause more aggressive growth or drug resistance

## Ancient family burial tells story of migration that reshaped Europe
 - [https://www.science.org/content/article/ancient-family-burial-tells-story-migration-reshaped-europe](https://www.science.org/content/article/ancient-family-burial-tells-story-migration-reshaped-europe)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-06-19T19:25:46.517351+00:00

DNA from 5500-year-old grave captures moment when herders from the steppes of Ukraine and Russia mixed with European farmers

## Is your AI hallucinating? New approach can tell when chatbots make things up
 - [https://www.science.org/content/article/is-your-ai-hallucinating-new-approach-can-tell-when-chatbots-make-things-up](https://www.science.org/content/article/is-your-ai-hallucinating-new-approach-can-tell-when-chatbots-make-things-up)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-06-19T16:11:35.627227+00:00

Second AI that acts as ‘truth cop’ could provide the reliability models need for rollout in healthcare, education, and other fields

