# Source:Energetyka, URL:https://energia.rp.pl/rss/4351-energetyka, language:pl-PL

## Europa musi się industrializować
 - [https://energia.rp.pl/akcje-specjalne/art40671451-europa-musi-sie-industrializowac](https://energia.rp.pl/akcje-specjalne/art40671451-europa-musi-sie-industrializowac)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-06-19T19:00:00+00:00

Polska potrzebuje polityki przemysłowej z prawdziwego zdarzenia – mówi Maciej Mazur, dyrektor zarządzający Polskiego Stowarzyszenia Nowej Mobilności i prezydent AVERE.

