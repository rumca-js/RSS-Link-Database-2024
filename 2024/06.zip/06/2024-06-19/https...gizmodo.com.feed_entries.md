# Source:Gizmodo, URL:https://gizmodo.com/feed, language:en

## Here's Even More Godzilla Minus One Art for Your Wall
 - [https://gizmodo.com/godzilla-minus-one-new-posters-release-toho-1851547643](https://gizmodo.com/godzilla-minus-one-new-posters-release-toho-1851547643)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/48269497682252c6577f9ffb209ca921.png" /><p>Here at io9, we love <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/godzilla-minus-one-review-toho-kaiju-1851046649">Godzilla Minus One</a>. We also love <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/open-house-2024-vice-press-posters-matt-ferguson-bttf-1851508106">very cool art</a>. And we especially love <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/godzilla-minus-one-poster-limited-edition-bottleneck-ar-1851447018">very cool Godzilla Minus One art</a>. So it’s a good job Toho is getting ready to release some of the film’s most glorious official posters for us to plaster our walls with—and we’ve got your first look.<br /></p><p><a href="https://gizmodo.com/godzilla-minus-one-new-posters-release-toho-1851547643">Read more...</a></p>

## There's New Bluey Out There, and We Can't Watch It!
 - [https://gizmodo.com/new-bluey-fourth-of-july-release-after-australia-tiktok-1851547768](https://gizmodo.com/new-bluey-fourth-of-july-release-after-australia-tiktok-1851547768)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/ff1fdce832e6795ee3dee63343082b01.png" /><p>The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/banned-bluey-episode-dad-baby-now-on-youtube-in-us-1851452765">Bluey</a> moment has reached a fever pitch as the hit animated series about a family of Heeler dogs has attracted fans across generations. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/bluey-disney-plus-bbc-australian-animation-adult-fans-1850426890">Even among those without kids</a>, the endearing and clever show has gained a considerably powerful fandom that wants more. </p><p><a href="https://gizmodo.com/new-bluey-fourth-of-july-release-after-australia-tiktok-1851547768">Read more...</a></p>

## Waves of Methane Are Crashing on the Coasts of Saturn's Bizarre Moon Titan
 - [https://gizmodo.com/saturn-moon-titan-methane-ethane-waves-sculpting-shore-1851547416](https://gizmodo.com/saturn-moon-titan-methane-ethane-waves-sculpting-shore-1851547416)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e91acf084e3a45f2851d3d17f3001a05.png" /><p>In 2006, a NASA spacecraft flew by Saturn’s largest moon and found evidence of large bodies of liquid on the surface of the bizarre world. The shocking discovery meant that Titan’s landscape is eerily similar to that of Earth’s; the two worlds are the only ones known to have  rivers, lakes, and seas on the surface.<br /></p><p><a href="https://gizmodo.com/saturn-moon-titan-methane-ethane-waves-sculpting-shore-1851547416">Read more...</a></p>

## Yes, That Was Who You Thought It Was in The Acolyte
 - [https://gizmodo.com/star-wars-the-acolyte-ki-adi-mundi-episode-4-cameo-1851547533](https://gizmodo.com/star-wars-the-acolyte-ki-adi-mundi-episode-4-cameo-1851547533)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/d0c3bacb9bd62470d8cc3eaf553c738b.jpg" /><p>For the most part, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/star-wars-the-acolyte-review-disney-plus-lucasfilm-1851517218">The Acolyte</a> has set itself apart from the rest of Star Wars—both in terms of its <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/star-wars-official-timeline-eras-old-republic-movies-tv-1850775770">placement in the timeline</a>, a hundred years before the prequel trilogy, and in its desire to focus on <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/the-acolyte-star-wars-preparation-homework-disney-plus-1851506706">new characters and explorations</a>, rather than the familiar. But that doesn’t mean there aren’t some intriguing…</p><p><a href="https://gizmodo.com/star-wars-the-acolyte-ki-adi-mundi-episode-4-cameo-185

## House of the Dragon's Most Enviable Couple on What Makes Their Relationship Work
 - [https://gizmodo.com/house-of-the-dragon-s2-interview-sea-snake-rhaenys-hbo-1851547298](https://gizmodo.com/house-of-the-dragon-s2-interview-sea-snake-rhaenys-hbo-1851547298)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4d3e9d8d8293428c2bee8ffbbed0d191.jpg" /><p>They don’t always agree, and they’ve endured tragedies that would be enough to fracture any marriage, much less one between <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/15-biggest-house-of-the-dragon-characters-s2-targaryens-1851536000">two of Westeros’ most powerful families</a>. But <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/game-of-thrones-house-of-the-dragon-hbo-velaryons-black-1849178684">Lord Corlys Velaryon</a> (Steve Toussaint) and Princess Rhaenys Targaryen (Eve Best) still somehow have the most enviable relationship on House of the…</p><p><a href="https://gizmodo.com/house-of-the-dragon-s2-interview-sea-snake-rhaenys-hbo-1851547298">Read more...</a></p>

## Thousands of American Climate Corps Workers Will Deploy This Month
 - [https://gizmodo.com/thousands-of-american-climate-corps-workers-will-deploy-1851548891](https://gizmodo.com/thousands-of-american-climate-corps-workers-will-deploy-1851548891)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T15:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/7dfd40df0664195c49bdd6bf392be839.webp" /><p>This story was originally published by <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://grist.org" rel="noopener noreferrer" target="_blank">Grist</a>. Sign up for Grist’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://go.grist.org/signup/weekly/partner?utm_campaign=republish-content&amp;utm_medium=syndication&amp;utm_source=partner" rel="noopener noreferrer" target="_blank">weekly newsletter here</a>.<br /></p><p><a href="https://gizmodo.com/thousands-of-american-climate-corps-workers-will-deploy-1851548891">Read more...</a></p>

## On The Acolyte, All Paths Converge on a Phantom Menace
 - [https://gizmodo.com/star-wars-the-acolyte-episode-4-recap-day-sith-mae-osha-1851547595](https://gizmodo.com/star-wars-the-acolyte-episode-4-recap-day-sith-mae-osha-1851547595)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/86965db8d1f0aa6cedd97d7a16dc339a.png" /><p>After last week’s episode of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/star-wars-the-acolyte-review-disney-plus-lucasfilm-1851517218">The Acolyte</a> took us into the past for a fascinating story of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/acolyte-star-wars-force-birth-explained-witches-anakin-1851538862">the Force and perspective</a> alike, things get back to the bigger mysteries of the season in “Day”. But the gift of last week’s context allows the show to re-examine its central figures in new light... just in time for that light to…</p><p><a href="https://gizmodo.com/star-wars-the-acolyte-episode-4-recap-day-sith-mae-osha-1851547595">Read more...</a></p>

## Our First Look at the Next Game of Thrones Spinoff Is Here
 - [https://gizmodo.com/knight-of-the-seven-kingdoms-first-look-game-of-thrones-1851544378](https://gizmodo.com/knight-of-the-seven-kingdoms-first-look-game-of-thrones-1851544378)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4c211c19514ef181788848afc40767f6.png" /><p>Project Hail Mary continues to expand its cast. An Uncharted sequel is actually happening. The Street Fighter movie has lost its directors. Plus, Jordan Peele’s next mystery project has a release date, and more familiar faces are confirmed for Your Friendly Neighborhood Spider-Man. Spoilers now!<br /></p><p><a href="https://gizmodo.com/knight-of-the-seven-kingdoms-first-look-game-of-thrones-1851544378">Read more...</a></p>

## Donald Trump Rambles About AI 'Clean Fakes' While Trying to Call Biden Senile
 - [https://gizmodo.com/trump-rambles-clean-fakes-deepfakes-cheap-biden-senile-1851547748](https://gizmodo.com/trump-rambles-clean-fakes-deepfakes-cheap-biden-senile-1851547748)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T12:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a61fcbc5de93f48d493a851c440c6290.png" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/donald-trump-memes-guilty-verdict-twitter-reddit-jokes-1851510671">Convicted felon Donald Trump</a> staged another rally in Racine, Wisconsin on Tuesday, where he played all his classic hits, from xenophobia to fake news. But it was Trump’s attempt to smear President Joe Biden as senile that really went off the rails. Trump rambled for several minutes about artificial intelligence and…</p><p><a href="https://gizmodo.com/trump-rambles-clean-fakes-deepfakes-cheap-biden-senile-1851547748">Read more...</a></p>

## Prion Disease Is Spreading in Deer. Here's What We Know About the Risk to Humans
 - [https://gizmodo.com/prions-venison-deer-meat-brain-disease-mad-cow-guide-1851547274](https://gizmodo.com/prions-venison-deer-meat-brain-disease-mad-cow-guide-1851547274)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T11:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/5044dbe2f796c9333c06352767f310cd.jpg" /><p>Earlier this year, a team of scientists garnered a wave of media attention with their provocative report: They claimed to have found two cases of a rare but fatal prion disease in hunters that could have plausibly been caused by them eating contaminated deer meat—a frightening reminder of the mad cow crisis over 30…</p><p><a href="https://gizmodo.com/prions-venison-deer-meat-brain-disease-mad-cow-guide-1851547274">Read more...</a></p>

## Who Needs a Turntable When You Can DJ With a Ball?
 - [https://gizmodo.com/odd-ball-bj-ball-edm-music-maker-1851538819](https://gizmodo.com/odd-ball-bj-ball-edm-music-maker-1851538819)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-06-19T10:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/52ff5863c2a776ba9740fbd29b3f2a50.jpg" /><p>I love EDM and have briefly tried my hand at DJing before to, let’s say, mixed results. So when I found out that I could make music with a pair of balls instead of a turntable or digital mixer. Who knows, maybe this will be the start of my career as a juggling DJ. <br /><br />Here’s how the Odd Ball works. It connects to your…</p><p><a href="https://gizmodo.com/odd-ball-bj-ball-edm-music-maker-1851538819">Read more...</a></p>

