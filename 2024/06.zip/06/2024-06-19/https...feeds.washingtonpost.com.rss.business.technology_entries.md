# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Could an all-inclusive cost the same as rent? He tried it.
 - [https://www.washingtonpost.com/travel/2024/06/19/seattle-man-mexico-resort-cheaper-rent](https://www.washingtonpost.com/travel/2024/06/19/seattle-man-mexico-resort-cheaper-rent)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-06-19T12:00:41+00:00

A Seattle man tested the theory that living at a Mexico resort would be comparable to a month of expenses at home.

## The new travel etiquette for tech: Wear headphones and stop filming strangers
 - [https://www.washingtonpost.com/technology/2023/12/11/tech-travel-etiquette](https://www.washingtonpost.com/technology/2023/12/11/tech-travel-etiquette)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-06-19T11:00:04+00:00

These common tech goofs can annoy those around you. Here’s how to be kinder to your fellow travelers.

