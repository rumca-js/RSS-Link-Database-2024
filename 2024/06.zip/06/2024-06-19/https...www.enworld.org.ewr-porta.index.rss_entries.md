# Source:EN World Tabletop RPG News & Reviews, URL:https://www.enworld.org/ewr-porta/index.rss, language:en

## Hidden Treasure from The Making of Original Dungeons & Dragons
 - [https://www.enworld.org/threads/hidden-treasure-from-the-making-of-original-dungeons-dragons.704839](https://www.enworld.org/threads/hidden-treasure-from-the-making-of-original-dungeons-dragons.704839)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-06-19T17:01:00+00:00

<div class="bbWrapper">This nearly 600-page book is no mere tome, it's an artifact.</div>

## 2024 Player's Handbook Reveal #2: "New Fighter"
 - [https://www.enworld.org/threads/2024-players-handbook-reveal-2-new-fighter.704843](https://www.enworld.org/threads/2024-players-handbook-reveal-2-new-fighter.704843)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-06-19T15:59:00+00:00

<div class="bbWrapper">&quot;The Fighter is now the weapon master equivalent of the Wizard!&quot;</div>

