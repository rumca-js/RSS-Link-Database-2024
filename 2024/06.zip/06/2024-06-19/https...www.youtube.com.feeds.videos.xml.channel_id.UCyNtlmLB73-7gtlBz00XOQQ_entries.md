# Source:FoldingIdeas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ, language:en-US

## I Don't Know James Rolfe
 - [https://www.youtube.com/watch?v=b3gZOt1Lo4A](https://www.youtube.com/watch?v=b3gZOt1Lo4A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyNtlmLB73-7gtlBz00XOQQ
 - date published: 2024-06-19T21:07:56+00:00

PHOTO-SENSITIVITY WARNING: occasional subtle flickering between 19:00 and 24:36

If ever there were a video I've made that required a companion essay or some kind of artist statement to go along with it I suppose it would be this one. It's a strange project that I've been working on for the better part of six months now, a process of trying to disentangle myself from myself. It's about a lot of different things, it's about James Rolfe but also not about him because we have so many versions of him and we can only react to those imperfect projections. He's been doing this for basically 20 years at this point, and out of that arise a million different ways to tell the story: AVGN is deeply influential, but what does that influence mean? I found myself fascinated with his creative fixations, the motifs and stories that he keeps coming back to, and felt like the only way to engage with that honestly was to expose all my own fixations, insecurities, and fears. 

Written by Dan Olson and Nat

