# Source:The Brazilian Report, URL:https://brazilian.report/feed, language:en-US

## Interest rates hold steady as Brazil’s Central Bank warns of inflation risks
 - [https://brazilian.report/business/2024/06/19/central-bank-lula-campos-neto-dispute](https://brazilian.report/business/2024/06/19/central-bank-lula-campos-neto-dispute)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-06-19T21:54:19+00:00

<p>The post <a href="https://brazilian.report/business/2024/06/19/central-bank-lula-campos-neto-dispute/">Interest rates hold steady as Brazil&#8217;s Central Bank warns of inflation risks</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## Ahead of policy decision, Lula allies request gag order on Central Bank chairman
 - [https://brazilian.report/liveblog/politics-insider/2024/06/19/lula-allies-gag-order-central-bank-chairman](https://brazilian.report/liveblog/politics-insider/2024/06/19/lula-allies-gag-order-central-bank-chairman)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-06-19T19:34:12+00:00

<p>Members of President Luiz Inácio Lula da Silva&#8217;s Workers&#8217; Party — including its chairperson, Congresswoman Gleisi Hoffmann&#160;—&#160;on Wednesday filed a lawsuit requesting that Central Bank chairman Roberto Campos Neto be forbidden from making political statements. Mr. Campos Neto has been a lightning rod for left-wing outrage since Lula took office in January 2023, as the [&#8230;]</p>
<p>The post <a href="https://brazilian.report/liveblog/politics-insider/2024/06/19/lula-allies-gag-order-central-bank-chairman/">Ahead of policy decision, Lula allies request gag order on Central Bank chairman</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## 12 iconic films to celebrate Brazil’s National Cinema Day
 - [https://brazilian.report/society/2024/06/19/iconic-films-national-cinema-day](https://brazilian.report/society/2024/06/19/iconic-films-national-cinema-day)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-06-19T18:54:09+00:00

<p>The post <a href="https://brazilian.report/society/2024/06/19/iconic-films-national-cinema-day/">12 iconic films to celebrate Brazil&#8217;s National Cinema Day</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## Explaining Brazil #298: Global ambitions, domestic neglect?
 - [https://brazilian.report/podcast/2024/06/19/lula-global-ambitions-domestic-neglect](https://brazilian.report/podcast/2024/06/19/lula-global-ambitions-domestic-neglect)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-06-19T14:46:31+00:00

<p>Brazil's President Lula has placed huge importance on diplomacy and international politics since returning to the country's top office — though he has faced criticism for the perception that he is ignoring domestic issues</p>
<p>The post <a href="https://brazilian.report/podcast/2024/06/19/lula-global-ambitions-domestic-neglect/">Explaining Brazil #298: Global ambitions, domestic neglect?</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## For Brazil, EU-Mercosur deal status remains unchanged
 - [https://brazilian.report/liveblog/politics-insider/2024/06/19/eu-mercosur-deal-status-remains-unchanged](https://brazilian.report/liveblog/politics-insider/2024/06/19/eu-mercosur-deal-status-remains-unchanged)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-06-19T14:29:11+00:00

<p>Foreign Minister Mauro Vieira on Wednesday told lawmakers at the House Foreign Affairs Committee that the conditions for concluding a free-trade deal between the European Union and Mercosur (the trade alliance between Brazil, Argentina, Paraguay, and Uruguay) remain “similar” to last year even after the recent EU Parliament election. Far-right parties, which have strongly opposed [&#8230;]</p>
<p>The post <a href="https://brazilian.report/liveblog/politics-insider/2024/06/19/eu-mercosur-deal-status-remains-unchanged/">For Brazil, EU-Mercosur deal status remains unchanged</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## Lula needs to pay more attention to domestic policies
 - [https://brazilian.report/opinion/2024/06/19/lula-g7-summit-politics](https://brazilian.report/opinion/2024/06/19/lula-g7-summit-politics)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-06-19T14:16:30+00:00

<p>The post <a href="https://brazilian.report/opinion/2024/06/19/lula-g7-summit-politics/">Lula needs to pay more attention to domestic policies</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

