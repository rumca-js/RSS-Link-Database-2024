# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## The U.K Has Fallen. What Happened?
 - [https://www.youtube.com/watch?v=LHzdwyvXl7g](https://www.youtube.com/watch?v=LHzdwyvXl7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2024-06-19T22:39:17+00:00

Go to https://ground.news/moon to burst your bias bubble and become a critical thinker. Subscribe through my link for 40% off unlimited access this month.

YouTube with Moon: https://www.skool.com/moon-society-5881/about

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT

