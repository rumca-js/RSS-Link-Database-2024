# Source:CD-Action - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g, language:pl

## Piękna katastrofa. Co się odwaliło z Suicide Squad: Kill the Justice League?
 - [https://www.youtube.com/watch?v=cug6zpr9sho](https://www.youtube.com/watch?v=cug6zpr9sho)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g
 - date published: 2024-06-19T16:54:53+00:00

Nie no, tak się nie robi. Panowie, wychodzimy.

Koniecznie zobacz nas w innych miejscach:

Strona :: https://cdaction.pl/
Sklep :: https://sklep.cdaction.pl/
Instagram :: https://instagram.com/cdaction
Facebook :: http://fb.me/CDAction/
Twitter :: https://twitter.com/cdaction
Discord CD-Action :: https://discord.gg/9Aqf3Cjcxx
Kontakt :: youtube@cdaction.pl

Prowadzenie i scenariusz: 

Dawid „spikain" Bojarski (http://twitter.com/spikain)

Montaż: Kacper Grela

