# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## New Samsung Laptop Has Trouble Running Software Including 'Fortnite'
 - [https://www.wsj.com/articles/new-samsung-laptop-with-ai-functions-has-trouble-running-software-including-fortnite-2f7f011a?mod=rss_Technology](https://www.wsj.com/articles/new-samsung-laptop-with-ai-functions-has-trouble-running-software-including-fortnite-2f7f011a?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-06-19T12:26:00+00:00

The issues offer a hint of the challenges some tech companies may face as they introduce new AI-powered computers and smartphones while seeking to maintain compatibility with existing software.

## 'I Felt Shameful and Fearful': Teen Who Saw AI Fake Nudes of Herself Speaks Out
 - [https://www.wsj.com/articles/teen-deepfake-ai-nudes-bill-ted-cruz-amy-klobuchar-3106eda0?mod=rss_Technology](https://www.wsj.com/articles/teen-deepfake-ai-nudes-bill-ted-cruz-amy-klobuchar-3106eda0?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-06-19T01:00:00+00:00

The Texas teenager joined Sens. Ted Cruz, Amy Klobuchar and other lawmakers in pushing for a bill to criminalize “deepfake” nonconsensual images.

