# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## AI's employment impact: 86% of workers fear job losses, but here's some good news
 - [https://www.zdnet.com/article/ai-employment-impact-86-of-workers-fear-job-losses-but-heres-some-good-news](https://www.zdnet.com/article/ai-employment-impact-86-of-workers-fear-job-losses-but-heres-some-good-news)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-06-19T04:00:00+00:00

The other 14% are the AI

## Easily navigate code delegates while debugging
 - [https://devblogs.microsoft.com/visualstudio/easily-navigate-code-delegates-while-debugging](https://devblogs.microsoft.com/visualstudio/easily-navigate-code-delegates-while-debugging)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-06-19T04:00:00+00:00

Or delegate the debugging to AI

## Google DeepMind's new AI tech will generate soundtracks for videos
 - [https://www.engadget.com/google-deepminds-new-ai-tech-will-generate-soundtracks-for-videos-113100908.html](https://www.engadget.com/google-deepminds-new-ai-tech-will-generate-soundtracks-for-videos-113100908.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-06-19T04:00:00+00:00

It just keeps using the 'Chariots of Fire' theme

## Meta halts plans to train AI on Facebook, Instagram posts in EU
 - [https://arstechnica.com/tech-policy/2024/06/meta-halts-plans-to-train-ai-on-facebook-instagram-posts-in-eu](https://arstechnica.com/tech-policy/2024/06/meta-halts-plans-to-train-ai-on-facebook-instagram-posts-in-eu)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-06-19T04:00:00+00:00

It's amazing what a little threat of a big fine does these days

## Optical PCIe 7.0 connection hits a blazing 128 GT/s
 - [https://www.tomshardware.com/tech-industry/optical-pcie-70-connection-hits-a-blazing-128-gts](https://www.tomshardware.com/tech-industry/optical-pcie-70-connection-hits-a-blazing-128-gts)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-06-19T04:00:00+00:00

That 'whoosh' you hear is all the data passing through your computer

## Remote IT support, is it just me?
 - [https://www.codeproject.com/Messages/6006065/Remote-IT-support-is-it-just-me](https://www.codeproject.com/Messages/6006065/Remote-IT-support-is-it-just-me)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-06-19T04:00:00+00:00

Your support request was rejected by our spam filter

## The rise—and fall—of the software developer
 - [https://www.adpri.org/the-rise-and-fall-of-the-software-developer](https://www.adpri.org/the-rise-and-fall-of-the-software-developer)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-06-19T04:00:00+00:00

Time to start a charity to save the endangered developer

