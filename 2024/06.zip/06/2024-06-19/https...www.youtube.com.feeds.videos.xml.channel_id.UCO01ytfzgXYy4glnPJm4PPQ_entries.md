# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## My Take On Bullying May Surprise You
 - [https://www.youtube.com/watch?v=cUm1c73f5S0](https://www.youtube.com/watch?v=cUm1c73f5S0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-19T22:00:24+00:00

A new poll from Rasmussen asks Americans what they really think of those who were bullied as kids. Some say bullying is traumatizing, while others say it’s a normal part of growing up. The answer is that it’s both. 

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1390 - https://bit.ly/3VOMKS5

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## I have no words
 - [https://www.youtube.com/watch?v=s4Uv7XpRLOI](https://www.youtube.com/watch?v=s4Uv7XpRLOI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-19T21:00:35+00:00



## Sister SUES Her Brother for Flirting with Her Ex-Boyfriend
 - [https://www.youtube.com/watch?v=ENfyTBiwvVc](https://www.youtube.com/watch?v=ENfyTBiwvVc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-19T20:00:10+00:00

Bad boundaries are a recipe for disaster, and this case proves it. A brother takes the phrase “sharing is caring” too literally when his sister gets a boyfriend. 

Puridy Debt Solutions - PDS Debt is offering a free debt analysis. It only takes thirty seconds. Get yours at https://PDSDebt.com/Walsh 

Watch "JUDGED by Matt Walsh" only on DailyWire+: https://bit.ly/3V83cfI

## Major Polling Firm Changes Its Own Results After Left-Wing Activists Complain | Ep. 1390
 - [https://www.youtube.com/watch?v=XAkqyhqoXDE](https://www.youtube.com/watch?v=XAkqyhqoXDE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-19T19:50:27+00:00

Today on the Matt Walsh Show, the term "Orwellian" is overused these days–but, no other word can describe what just happened with a Pew survey finding that a vast majority of black Americans believe in racial conspiracy theories. The findings were so upsetting to activists that Pew went back and changed the report. This is a crazy story that few are talking about. We'll discuss. Also, Donald Trump reportedly floated the idea of abolishing the income tax. That's a great idea that should garner a lot more enthusiasm than it does. And, a democratic congresswoman claims that she miraculously cured cancer. Where are the fact-checkers on this one?

TIMESTAMPS:

00:00 - 00:33 Opening
01:39 - 19:16 Major Polling Firm Changes Its Own Results After Left-Wing Activists Complain 
20:25 - 24:08 Matt Discusses His Birthday
24:09 - 36:49 GOP Lawmakers Unveil Bill To Nix Federal Taxes On Tips
36:50 - 48:48 Forty-Five Percent Of Americans Believe Bullied Kids Grow Up To Get Revenge
49:48 - 1:01:12 The

## The internet RUINED this remote tribe
 - [https://www.youtube.com/watch?v=gVfJfY-w0yI](https://www.youtube.com/watch?v=gVfJfY-w0yI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-19T17:00:52+00:00



## Firefighter Violently Assaulted by Colleague, But Guess Who Loses Their Job
 - [https://www.youtube.com/watch?v=NLFBveOQUEY](https://www.youtube.com/watch?v=NLFBveOQUEY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-06-19T00:00:10+00:00

Birch Gold - Text "WALSH" to 989898, or go to https://birchgold.com/Walsh, for your no-cost, no-obligation, FREE information kit. 

A firefighter in San Francisco was attacked by one of his coworkers and beaten with a wrench. The victim lost his job and the attacker is still collecting a paycheck.

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep. 544 - https://bit.ly/3RzFQ0j

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

