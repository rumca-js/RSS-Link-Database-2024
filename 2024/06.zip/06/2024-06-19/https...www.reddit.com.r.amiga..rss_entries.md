# Source:Amiga, URL:https://www.reddit.com/r/amiga/.rss, language:en

## £30 eBay lot, lotsa fun coverdiscs here…they include the program that kickstarted my Amiga musical journey - OctaMED Soundstudio! 😁
 - [https://www.reddit.com/r/amiga/comments/1djqgnp/30_ebay_lot_lotsa_fun_coverdiscs_herethey_include](https://www.reddit.com/r/amiga/comments/1djqgnp/30_ebay_lot_lotsa_fun_coverdiscs_herethey_include)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-19T18:35:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1djqgnp/30_ebay_lot_lotsa_fun_coverdiscs_herethey_include/"> <img alt="£30 eBay lot, lotsa fun coverdiscs here…they include the program that kickstarted my Amiga musical journey - OctaMED Soundstudio! 😁" src="https://preview.redd.it/pe4gkprook7d1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ccfd07235b716cb7a0ac88906c7e4151dc97c84c" title="£30 eBay lot, lotsa fun coverdiscs here…they include the program that kickstarted my Amiga musical journey - OctaMED Soundstudio! 😁" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Paulee_Bow"> /u/Paulee_Bow </a> <br /> <span><a href="https://i.redd.it/pe4gkprook7d1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1djqgnp/30_ebay_lot_lotsa_fun_coverdiscs_herethey_include/">[comments]</a></span> </td></tr></table>

## Reproducing Amiga RKM books for personal usage
 - [https://www.reddit.com/r/amiga/comments/1djnvqj/reproducing_amiga_rkm_books_for_personal_usage](https://www.reddit.com/r/amiga/comments/1djnvqj/reproducing_amiga_rkm_books_for_personal_usage)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-19T16:48:21+00:00

<!-- SC_OFF --><div class="md"><p>Hello!</p> <p>I am currently deeping into Amiga software development and I would love to have a paper version of some ROM Kernel Reference Manuals, such as the Exec one.</p> <p>I doubt that a printer in France would accept to reproduce the former by providing them a pdf.</p> <p>Does anyone have sent an old Amiga book to a printer? How about right for reproducing, is it still forbidden? </p> <p>Thank in advance!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/estr4g0n"> /u/estr4g0n </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1djnvqj/reproducing_amiga_rkm_books_for_personal_usage/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1djnvqj/reproducing_amiga_rkm_books_for_personal_usage/">[comments]</a></span>

## Skinny Marley Game Play
 - [https://www.reddit.com/r/amiga/comments/1djmedd/skinny_marley_game_play](https://www.reddit.com/r/amiga/comments/1djmedd/skinny_marley_game_play)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-19T15:46:14+00:00

<!-- SC_OFF --><div class="md"><p>Gameplay videos made by Skinny Marley fans are starting to appear</p> <p><a href="https://youtu.be/enc6qnoOKyQ?si=TVQhxD0CehKU5zz3">https://youtu.be/enc6qnoOKyQ?si=TVQhxD0CehKU5zz3</a></p> <h1>amigagame #indiegame #indiedev #gamedev #amiga #tooizzi</h1> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Embarrassed-You2351"> /u/Embarrassed-You2351 </a> <br /> <span><a href="https://www.reddit.com/r/amiga/comments/1djmedd/skinny_marley_game_play/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1djmedd/skinny_marley_game_play/">[comments]</a></span>

## In interview with Gary Carlston co-founder of Brøderbund.
 - [https://www.reddit.com/r/amiga/comments/1djjdy8/in_interview_with_gary_carlston_cofounder_of](https://www.reddit.com/r/amiga/comments/1djjdy8/in_interview_with_gary_carlston_cofounder_of)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-19T13:37:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1djjdy8/in_interview_with_gary_carlston_cofounder_of/"> <img alt="In interview with Gary Carlston co-founder of Brøderbund. " src="https://external-preview.redd.it/einCYj2gZCUL-djl8ch46cKu1CamAqRzIGaJvIQb4Sg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=499c2cf7d808bfcd4186d64574e5913cfd3e02c5" title="In interview with Gary Carlston co-founder of Brøderbund. " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Missed out on world-wide Tetris rights!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/123shait"> /u/123shait </a> <br /> <span><a href="https://spillhistorie.no/a-chat-with-gary-carlston-of-broderbund/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1djjdy8/in_interview_with_gary_carlston_cofounder_of/">[comments]</a></span> </td></tr></table>

## Creating a new Amiga OS: Reflections of a 50 year old developer
 - [https://www.reddit.com/r/amiga/comments/1djgqpu/creating_a_new_amiga_os_reflections_of_a_50_year](https://www.reddit.com/r/amiga/comments/1djgqpu/creating_a_new_amiga_os_reflections_of_a_50_year)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-19T11:22:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1djgqpu/creating_a_new_amiga_os_reflections_of_a_50_year/"> <img alt="Creating a new Amiga OS: Reflections of a 50 year old developer" src="https://external-preview.redd.it/NBeCzOMFIcSZrTxUhNocvgKBDBhsF7kumckBXTf5yT8.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=969b655fd90fbdd08eb07c30da444b358c657c01" title="Creating a new Amiga OS: Reflections of a 50 year old developer" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/wotanica"> /u/wotanica </a> <br /> <span><a href="https://retromodsblog.wordpress.com/2024/06/19/creating-a-new-amiga-os-reflections-of-a-50-year-old-developer/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1djgqpu/creating_a_new_amiga_os_reflections_of_a_50_year/">[comments]</a></span> </td></tr></table>

## Ep. 32 Unboxing & playing Leander Amiga game [Ελληνικά]
 - [https://www.reddit.com/r/amiga/comments/1djb8i0/ep_32_unboxing_playing_leander_amiga_game_ελληνικά](https://www.reddit.com/r/amiga/comments/1djb8i0/ep_32_unboxing_playing_leander_amiga_game_ελληνικά)
 - RSS feed: https://www.reddit.com/r/amiga/.rss
 - date published: 2024-06-19T05:11:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1djb8i0/ep_32_unboxing_playing_leander_amiga_game_ελληνικά/"> <img alt="Ep. 32 Unboxing &amp; playing Leander Amiga game [Ελληνικά]" src="https://external-preview.redd.it/HLpbH-FIlJIDMtzXZSvn19OD1Dk1gzCcO8y9GvuZuFw.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=12225e3dd71ae343c0d3febf5927d1a0a2370378" title="Ep. 32 Unboxing &amp; playing Leander Amiga game [Ελληνικά]" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Leander is a video game for the Amiga developed by Traveller's Tales and published by Psygnosis in 1991. It was the first game developed by Traveller's Tales. The game was developed on the Amiga, then converted to the Atari ST by Philipp Wyatt for W.J.S Design. A year later it was published for the Sega Genesis as Galahad by Electronic Arts.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GreekRetroMan"> /u/GreekRetroMan </a> <br /> <span><a href="https://youtu.be

