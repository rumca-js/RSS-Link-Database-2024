# Source:Le Monde, URL:https://www.lemonde.fr/en/rss/une.xml, language:en-US

## Two women go on trial for claiming French first lady is transgender
 - [https://www.lemonde.fr/en/france/article/2024/06/20/two-women-go-on-trial-for-claiming-french-first-lady-is-transgender_6675226_7.html](https://www.lemonde.fr/en/france/article/2024/06/20/two-women-go-on-trial-for-claiming-french-first-lady-is-transgender_6675226_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T23:25:08+00:00

Online rumors have suggested that Brigitte Macron has never existed, with conspiracy theorists claiming that the current first lady's brother Jean-Michel had changed gender and assumed that identity.

## Louisiana requires classrooms to display Ten Commandments
 - [https://www.lemonde.fr/en/international/article/2024/06/20/louisiana-requires-classrooms-to-display-ten-commandments_6675225_4.html](https://www.lemonde.fr/en/international/article/2024/06/20/louisiana-requires-classrooms-to-display-ten-commandments_6675225_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T23:11:56+00:00

Opponents say they will challenge the law in court, while supporters claim the message also has historical significance. Classrooms will be required to display the posters by next year.

## Vladimir Putin and Kim Jong-un consolidate an openly military alliance
 - [https://www.lemonde.fr/en/international/article/2024/06/20/vladimir-putin-and-kim-jong-un-consolidate-an-openly-military-alliance_6675224_4.html](https://www.lemonde.fr/en/international/article/2024/06/20/vladimir-putin-and-kim-jong-un-consolidate-an-openly-military-alliance_6675224_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T22:03:42+00:00

The Russian president, who was welcomed with great fanfare in Pyongyang, and the North Korean leader signed a comprehensive strategic partnership treaty which 'provides, among other things, for mutual assistance in the event of aggression.'

## 'Given the RN's stances on Russia, there would be a real security problem in the event of cohabitation'
 - [https://www.lemonde.fr/en/opinion/article/2024/06/19/given-the-rn-s-stances-on-russia-there-would-be-a-real-security-problem-in-the-event-of-cohabitation_6675222_23.html](https://www.lemonde.fr/en/opinion/article/2024/06/19/given-the-rn-s-stances-on-russia-there-would-be-a-real-security-problem-in-the-event-of-cohabitation_6675222_23.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T20:35:16+00:00

François Heisbourg, a security and defense specialist, tells Le Monde that a far-right victory in France's parliamentary elections would raise serious security issues, particularly on international issues.

## Rape and anti-Semitic insults: What investigators have pieced together from 12-year-old girl's assault
 - [https://www.lemonde.fr/en/france/article/2024/06/19/rape-and-anti-semitic-insults-what-investigators-have-pieced-together-from-12-year-old-girl-s-assault_6675216_7.html](https://www.lemonde.fr/en/france/article/2024/06/19/rape-and-anti-semitic-insults-what-investigators-have-pieced-together-from-12-year-old-girl-s-assault_6675216_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T19:15:02+00:00

On Tuesday, three teenagers were charged after they violently assaulted a girl in the Paris suburb of Courbevoie on Saturday.

## Euro 2024: Musiala shines as Germany qualifies for last 16
 - [https://www.lemonde.fr/en/sports/article/2024/06/19/euro-2024-musiala-shines-as-germany-qualifies-for-last-16_6675210_9.html](https://www.lemonde.fr/en/sports/article/2024/06/19/euro-2024-musiala-shines-as-germany-qualifies-for-last-16_6675210_9.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T18:52:48+00:00

The hosts beat Hungary 2-0 in their second group-stage match.

## French elections: Far-right ally Ciotti disowns candidate for 'anti-Semitic, homophobic' comments
 - [https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-far-right-ally-ciotti-disowns-candidate-for-anti-semitic-homophobic-comments_6675207_5.html](https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-far-right-ally-ciotti-disowns-candidate-for-anti-semitic-homophobic-comments_6675207_5.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T18:41:14+00:00

Eric Ciotti said he no longer supported Louis-Joseph Gannat, who confirmed he was behind a deleted X account that published such comments.

## Patrick Artus: 'If they don't react, the countries of Southern Europe will bear the full brunt of the negative effects of a shrinking working-age population'
 - [https://www.lemonde.fr/en/opinion/article/2024/06/19/patrick-artus-if-they-don-t-react-the-countries-of-southern-europe-will-bear-the-full-brunt-of-the-negative-effects-of-a-shrinking-working-age-population_6675206_23.html](https://www.lemonde.fr/en/opinion/article/2024/06/19/patrick-artus-if-they-don-t-react-the-countries-of-southern-europe-will-bear-the-full-brunt-of-the-negative-effects-of-a-shrinking-working-age-population_6675206_23.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T18:30:07+00:00

In his column, the economist identifies two possible reactions to the decline in the working-age population.

## Macron and Mélenchon both trivialize the far right
 - [https://www.lemonde.fr/en/politics/article/2024/06/19/macron-and-melenchon-both-trivialize-the-far-right_6675205_5.html](https://www.lemonde.fr/en/politics/article/2024/06/19/macron-and-melenchon-both-trivialize-the-far-right_6675205_5.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T18:00:16+00:00

Jean-Luc Mélenchon has said that Jordan Bardella is 'Macron, only worse.' Emmanuel Macron has put the far-right and Mélenchon's La France Insoumise party on equal footing. Both arguments only trivialize the far-right party, and might even strengthen it.

## Collective-run Paris cinema La Clef saved from closure
 - [https://www.lemonde.fr/en/culture/article/2024/06/19/collective-run-paris-cinema-la-clef-saved-from-closure_6675203_30.html](https://www.lemonde.fr/en/culture/article/2024/06/19/collective-run-paris-cinema-la-clef-saved-from-closure_6675203_30.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T17:02:04+00:00

After several years of struggle, the La Clef Revival cooperative has succeeded in buying back the historic site in the Latin Quarter. It will reopen in June 2025.

## Euro 2024: Broken-nosed Mbappé partially trains ahead of Netherlands match
 - [https://www.lemonde.fr/en/sports/article/2024/06/19/euro-2024-broken-nosed-mbappe-trains-alone-ahead-of-netherlands-match_6675202_9.html](https://www.lemonde.fr/en/sports/article/2024/06/19/euro-2024-broken-nosed-mbappe-trains-alone-ahead-of-netherlands-match_6675202_9.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T16:44:21+00:00

Kylian Mbappé appeared with bandages on his nose at France's training session, where he worked on specific exercises with a physio.

## French senators urge end to Russian LNG imports and creation of TotalEnergies 'special share'
 - [https://www.lemonde.fr/en/politics/article/2024/06/19/french-senators-urge-end-to-russian-lng-imports-and-creation-of-totalenergies-special-share_6675200_5.html](https://www.lemonde.fr/en/politics/article/2024/06/19/french-senators-urge-end-to-russian-lng-imports-and-creation-of-totalenergies-special-share_6675200_5.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T16:07:22+00:00

An investigating committee in the conservative-dominated chamber of Parliament recommended the French state to get a 'special share' in the oil and gas giant to influence its strategic decisions.

## French court sentences man over Banksy stencil theft from Centre Pompidou
 - [https://www.lemonde.fr/en/france/article/2024/06/19/french-court-sentences-man-over-banksy-stencil-theft-from-centre-pompidou_6675198_7.html](https://www.lemonde.fr/en/france/article/2024/06/19/french-court-sentences-man-over-banksy-stencil-theft-from-centre-pompidou_6675198_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T15:54:38+00:00

The defendant claimed he was a friend of Banksy and that the British artist had asked him to retrieve the artwork.

## Football: Lyon women hire Australian coach Joe Montemurro
 - [https://www.lemonde.fr/en/sports/article/2024/06/19/football-lyon-women-hire-australian-coach-joe-montemurro_6675196_9.html](https://www.lemonde.fr/en/sports/article/2024/06/19/football-lyon-women-hire-australian-coach-joe-montemurro_6675196_9.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T15:39:36+00:00

The former Arsenal and Juventus manager replaces Sonia Bompastor at the head of Olympique Lyonnais.

## Death toll from heat at hajj pilgrimage in Saudi Arabia passes 900
 - [https://www.lemonde.fr/en/international/article/2024/06/19/death-toll-from-heat-at-hajj-pilgrimage-in-saudi-arabia-passes-900_6675195_4.html](https://www.lemonde.fr/en/international/article/2024/06/19/death-toll-from-heat-at-hajj-pilgrimage-in-saudi-arabia-passes-900_6675195_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T15:32:51+00:00

Temperatures hit 51.8°C in Mecca, Islam's holiest city, on Monday, as 1.8 million people took part in the annual pilgrimage.

## Euro 2024: Albania dents Croatia's hopes with late draw
 - [https://www.lemonde.fr/en/sports/article/2024/06/19/euro-2024-albania-dents-croatia-s-hopes-with-late-draw_6675192_9.html](https://www.lemonde.fr/en/sports/article/2024/06/19/euro-2024-albania-dents-croatia-s-hopes-with-late-draw_6675192_9.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T15:18:44+00:00

Albania's Klaus Gjasula made up for his own-goal by scoring an equalizer in the thrilling finish to a 2-2 draw.

## Carlos Tavares' ruthless cost-cutting strategy
 - [https://www.lemonde.fr/en/economy/article/2024/06/19/carlos-tavares-ruthless-cost-cutting-strategy_6675189_19.html](https://www.lemonde.fr/en/economy/article/2024/06/19/carlos-tavares-ruthless-cost-cutting-strategy_6675189_19.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T14:34:12+00:00

Already a champion of low-cost management, the CEO of Stellantis wants 80% of his purchases to come from low-cost countries by 2028 to boost his profitability and stock price. He refuses to consider the political impact of the resulting job losses.

## French elections: Paris mayor admits far-right victory would overshadow Olympics
 - [https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-paris-mayor-admits-far-right-victory-would-overshadow-olympics_6675186_5.html](https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-paris-mayor-admits-far-right-victory-would-overshadow-olympics_6675186_5.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T14:20:59+00:00

Anne Hidalgo said on Wednesday that many people overseas are 'worried about the situation in France' in the run-up to the Olympics in the French capital set to begin next month.

## French elections: The left still hasn't decided on a prime minister
 - [https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-the-left-still-hasn-t-decided-on-a-prime-minister_6675180_5.html](https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-the-left-still-hasn-t-decided-on-a-prime-minister_6675180_5.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T14:05:36+00:00

The French left-wing alliance is aware that the subject is divisive, and has decided to postpone the designation of a candidate for the position.

## French elections: Far-right RN disowns candidate over anti-Semitic post
 - [https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-far-right-rn-disowns-candidate-over-anti-semitic-post_6675179_5.html](https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-far-right-rn-disowns-candidate-over-anti-semitic-post_6675179_5.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T14:04:44+00:00

Rassemblement National withdrew support for Joseph Martin, who in a post on social media in 2018 said 'gas did justice to the victims of the Holocaust.'

## Macron accused of transphobia over criticism of left-wing union policy
 - [https://www.lemonde.fr/en/politics/article/2024/06/19/macron-accused-of-transphobia-over-criticism-of-left-wing-union-policy_6675177_5.html](https://www.lemonde.fr/en/politics/article/2024/06/19/macron-accused-of-transphobia-over-criticism-of-left-wing-union-policy_6675177_5.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T13:43:13+00:00

The French president on Tuesday criticized a proposal allowing citizens to change their gender at the town hall.

## European Commission reprimands France and six countries for breaking budget rules
 - [https://www.lemonde.fr/en/economy/article/2024/06/19/european-commission-reprimands-france-and-six-countries-for-breaking-budget-rules_6675175_19.html](https://www.lemonde.fr/en/economy/article/2024/06/19/european-commission-reprimands-france-and-six-countries-for-breaking-budget-rules_6675175_19.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T13:32:41+00:00

The European Union's executive arm is considering opening 'excessive deficit procedures' against Belgium, France, Hungary, Italy, Malta, Poland, and Slovakia.

## Rassemblement National leader Jordan Bardella refuses to be PM without an absolute majority
 - [https://www.lemonde.fr/en/videos/video/2024/06/19/rassemblement-national-leader-jordan-bardella-refuses-to-be-pm-without-an-absolute-majority_6675172_108.html](https://www.lemonde.fr/en/videos/video/2024/06/19/rassemblement-national-leader-jordan-bardella-refuses-to-be-pm-without-an-absolute-majority_6675172_108.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T12:28:08+00:00

The far-right leader of the Rassemblement National said on Tuesday that he would refuse to be the president's 'collaborator'.

## Vladimir Putin and Kim Jong-un's worrying summit of pariahs
 - [https://www.lemonde.fr/en/opinion/article/2024/06/19/vladimir-putin-and-kim-jong-un-s-worrying-summit-of-pariahs_6675167_23.html](https://www.lemonde.fr/en/opinion/article/2024/06/19/vladimir-putin-and-kim-jong-un-s-worrying-summit-of-pariahs_6675167_23.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T10:45:37+00:00

The Russian president's visit to North Korea is an admission of the arms requirements of the conflict in Ukraine, which he set off more than two years ago. The meeting symbolizes a turning point, given the history of these two countries.

## French teenagers charged with anti-Semitic rape of 12-year-old girl
 - [https://www.lemonde.fr/en/france/article/2024/06/19/french-teenagers-charged-with-anti-semitic-rape-of-12-year-old-girl_6675166_7.html](https://www.lemonde.fr/en/france/article/2024/06/19/french-teenagers-charged-with-anti-semitic-rape-of-12-year-old-girl_6675166_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T10:37:49+00:00

Three boys, aged 12 to 13, were arrested on Monday after a girl reported the incident that took place in the northwestern Paris suburb of Courbevoie.

## French elections: Bardella's fluctuating and tricky-to-implement policies
 - [https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-bardella-s-fluctuating-and-tricky-to-implement-policies_6675160_5.html](https://www.lemonde.fr/en/politics/article/2024/06/19/french-elections-bardella-s-fluctuating-and-tricky-to-implement-policies_6675160_5.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T10:11:20+00:00

The far-right leader laid out his first priorities should he be appointed prime minister after parliamentary elections on June 30 and July 7.

## From Louis Vuitton to Chanel, fashion's recurring cultural appropriation controversies
 - [https://www.lemonde.fr/en/m-le-mag/article/2024/06/19/from-louis-vuitton-to-chanel-fashion-s-recurring-cultural-appropriation-controversies_6675157_117.html](https://www.lemonde.fr/en/m-le-mag/article/2024/06/19/from-louis-vuitton-to-chanel-fashion-s-recurring-cultural-appropriation-controversies_6675157_117.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T09:12:13+00:00

In early June, Louis Vuitton was accused of imitating a traditional Romanian blouse without acknowleding its origin. The fashion industry is regularly accused of cultural appropriation.

## Biden eases citizenship pathway for 500,000 undocumented spouses of Americans
 - [https://www.lemonde.fr/en/international/article/2024/06/19/biden-eases-citizenship-pathway-for-500-000-undocumented-spouses-of-americans_6675152_4.html](https://www.lemonde.fr/en/international/article/2024/06/19/biden-eases-citizenship-pathway-for-500-000-undocumented-spouses-of-americans_6675152_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T08:57:22+00:00

At the beginning of June, the American president restricted migrants' ability to apply for asylum. This time, his latest measure aims to reassure the left wing of his party.

## Mystery monolith found in Nevada desert
 - [https://www.lemonde.fr/en/international/article/2024/06/19/mystery-monolith-found-in-nevada-desert_6675151_4.html](https://www.lemonde.fr/en/international/article/2024/06/19/mystery-monolith-found-in-nevada-desert_6675151_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T08:52:42+00:00

The enigmatic object, a shiny, rectangular structure akin to others found around the world from 2020, was discovered by Las Vegas police in a desert hiking area north of the city.

## French elections: Why does the deterioration of access to public services fuel the far-right vote?
 - [https://www.lemonde.fr/en/france/article/2024/06/19/french-elections-why-does-the-deterioration-of-access-to-public-services-fuel-the-far-right-vote_6675148_7.html](https://www.lemonde.fr/en/france/article/2024/06/19/french-elections-why-does-the-deterioration-of-access-to-public-services-fuel-the-far-right-vote_6675148_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T08:31:20+00:00

Over the years, residents of rural areas have seen their access to the services they are entitled to decrease, through restructurings and dematerialization. As a result, they feel relegated and abandoned.

## French police arrest 8 in New Caledonia, including pro-independence group head
 - [https://www.lemonde.fr/en/france/article/2024/06/19/french-police-arrest-8-in-new-caledonia-including-pro-independence-group-head_6675141_7.html](https://www.lemonde.fr/en/france/article/2024/06/19/french-police-arrest-8-in-new-caledonia-including-pro-independence-group-head_6675141_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T07:15:54+00:00

Christian Tein, the leader of the pro-independence activist CCAT group, which has been blamed for the unrest that gripped the French overseas territory of New Caledonia in May, was the only one of the 8 detainees to have been named by the public prosecutor.

## North Korea rolls out red carpet for Putin
 - [https://www.lemonde.fr/en/international/article/2024/06/19/north-korea-rolls-out-red-carpet-for-putin_6675139_4.html](https://www.lemonde.fr/en/international/article/2024/06/19/north-korea-rolls-out-red-carpet-for-putin_6675139_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T07:00:02+00:00

In the two leaders' second meeting this year, Kim Jong Un spoke of a 'new era' in the countries' relations, which Putin aimed to express via a 'new foundation document.' The US voiced 'concern' about the trip over its consequences for South Korea and Ukraine.

## Swedish MPs green-light to controversial US defense deal
 - [https://www.lemonde.fr/en/international/article/2024/06/19/swedish-mps-green-light-to-controversial-us-defense-deal_6675128_4.html](https://www.lemonde.fr/en/international/article/2024/06/19/swedish-mps-green-light-to-controversial-us-defense-deal_6675128_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T03:22:18+00:00

The deal gives the US access to 17 military bases and training areas in Sweden.

## Burkina Faso suspends French broadcaster TV5 for six months
 - [https://www.lemonde.fr/en/international/article/2024/06/19/burkina-faso-suspends-french-broadcaster-tv5-for-six-months_6675127_4.html](https://www.lemonde.fr/en/international/article/2024/06/19/burkina-faso-suspends-french-broadcaster-tv5-for-six-months_6675127_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T03:00:45+00:00

Several French media outlets have been suspended in Burkina Faso in recent years.

## Paris 2024: Olympic venues are almost ready for the Games
 - [https://www.lemonde.fr/en/sports/article/2024/06/19/paris-2024-olympic-venues-are-almost-ready-for-the-games_6675126_9.html](https://www.lemonde.fr/en/sports/article/2024/06/19/paris-2024-olympic-venues-are-almost-ready-for-the-games_6675126_9.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T03:00:27+00:00

Concorde, Invalides, the Eiffel Tower, the Trocadéro: Construction is nearing completion on these sites, setting up the various temporary facilities that will host the Olympic Games in Paris this summer.

## Meloni's union of the right strategy in Italy, a model for France's far right
 - [https://www.lemonde.fr/en/opinion/article/2024/06/19/meloni-s-union-of-the-right-strategy-in-italy-a-model-for-france-s-far-right_6675125_23.html](https://www.lemonde.fr/en/opinion/article/2024/06/19/meloni-s-union-of-the-right-strategy-in-italy-a-model-for-france-s-far-right_6675125_23.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T02:00:17+00:00

The political groups that make up the coalition that has been in power in Rome since October 2022 are a mirror of the convergence of part of the French right.

## 'Attributing the fragility of the European automotive industry to unfair Chinese practices is a bit short-sighted. The problem runs much deeper.'
 - [https://www.lemonde.fr/en/opinion/article/2024/06/19/attributing-the-fragility-of-the-european-automotive-industry-to-unfair-chinese-practices-is-a-bit-short-sighted-the-problem-runs-much-deeper_6675124_23.html](https://www.lemonde.fr/en/opinion/article/2024/06/19/attributing-the-fragility-of-the-european-automotive-industry-to-unfair-chinese-practices-is-a-bit-short-sighted-the-problem-runs-much-deeper_6675124_23.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T01:10:41+00:00

The EU's decision to increase customs duties on Chinese electric cars will not exempt Europeans from making an effort to catch up with their industrial and technological lag, said Stéphane Lauer, editorial writer at Le Monde, in his column.

## Ursula von der Leyen competing to be re-elected president of the European Commission
 - [https://www.lemonde.fr/en/international/article/2024/06/19/ursula-von-der-leyen-competing-to-be-re-elected-president-of-the-european-commission_6675123_4.html](https://www.lemonde.fr/en/international/article/2024/06/19/ursula-von-der-leyen-competing-to-be-re-elected-president-of-the-european-commission_6675123_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2024-06-19T01:04:33+00:00

The 27 member states have not formally confirmed the appointment of Angela Merkel's former minister, but they are close to an agreement that would see Antonio Costa as president of the Council and Kaja Kallas in charge of foreign affairs.

