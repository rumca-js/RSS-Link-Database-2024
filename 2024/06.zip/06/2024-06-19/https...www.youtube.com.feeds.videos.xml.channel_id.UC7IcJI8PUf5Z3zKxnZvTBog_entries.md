# Source:The School of Life, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog, language:en-US

## The Real Reason We Work So Hard
 - [https://www.youtube.com/watch?v=LFsVUWDNNT8](https://www.youtube.com/watch?v=LFsVUWDNNT8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog
 - date published: 2024-06-19T13:00:18+00:00

We work as we do because – of course – we need to; because nothing is cheap, because the bills are incessant; because of all the good and wise and sensible reasons that we’ve been highly aware of since mid adolescence at least. But that is too neat and we know it deep down; we know that there is also – alongside this – something more complicated that we use the idea of necessity to avoid. 
Enjoying our Youtube videos? Get full access to all our audio content, videos, and thousands of thought-provoking articles, conversation cards and more with The School of Life Subscription: https://t.ly/H40fh


Learn, heal and grow. Get the best of The School of Life delivered straight to your inbox: https://t.ly/ERef4

FURTHER READING

You can read more on this and other subjects in our articles, here: https://t.ly/RSqUs

“We work as we do because – of course – we need to; because nothing is cheap, because the bills are incessant; because of all the good and wise and sensible reasons that we’ve bee

