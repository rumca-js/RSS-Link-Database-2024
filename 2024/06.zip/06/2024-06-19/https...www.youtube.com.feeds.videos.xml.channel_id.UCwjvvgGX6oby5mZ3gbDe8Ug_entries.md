# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Low-income people have been cleared out? What is the root cause of so many poor people in China?
 - [https://www.youtube.com/watch?v=MEHKFZUeGFM](https://www.youtube.com/watch?v=MEHKFZUeGFM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2024-06-19T23:30:07+00:00

#chinainsights 

On June 14, 2024, Luo Qiang, the vice governor of Guizhou Province, described the province's achievements at a press conference held by the State Council's Information Office. After winning the battle against poverty in Guizhou, the bottom line is not to return to poverty on a large scale. We monitored and helped the poverty-stricken population and implemented the three-year action to increase residents' income.

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

