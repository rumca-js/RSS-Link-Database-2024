# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Sky: Children of the Light - Official Days of Color 2024 Trailer
 - [https://www.youtube.com/watch?v=itLAokwrzOk](https://www.youtube.com/watch?v=itLAokwrzOk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T18:31:55+00:00

Sky: Children of the Light is a free-to-play MMO RPG developed by thatgamecompany. Players will soon be able to access the two-week Days of Color 2024 event that sets out to celebrate the game’s diverse community and making the world a more inclusive place for all. Sky kids will spread love and hope as they band together above the clouds to complete a rainbow puzzle that grows larger each day. The Days of Color 2024 for Sky: Children of the Light runs from June 24 through July 7 for PlayStation 4 (PS4), PlayStation 5 (PS5), Nintendo Switch, iOS, Android, and PC (Steam).

#SkyChildrenOfTheLight #DaysOfColor2024 #IGN

## Elden Ring: Everything You Need to Prepare For Shadow of the Erdtree
 - [https://www.youtube.com/watch?v=O4urf2TPlDY](https://www.youtube.com/watch?v=O4urf2TPlDY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T17:15:01+00:00

After over two years since the release of Elden Ring, Shadow of the Erdtree is finally here, but if you’re like many, you may not be ready for what’s coming in the Land of Shadow. But fret not Tarnished, because, over the next hour, we’re going over some of our best builds, pro tips from a speed runner, and everything you need to know and do to best prep yourself for Elden Ring: Shadow of the Erdtree.

00:00 - Intro
00:27 - Shadow of the Erdtree Everything You NEED to Do Before Elden Ring's DLC
11:35 - How to Reach Shadow of the Erdtree FAST!
25:43 - The Best Spirit Ash Summon You NEED to Get Before Erdtree
30:59 - Elden Ring Speedrunner Shows You How to MELT Mohg and Radahn (Before Erdtree DLC)
39:48 - 7 Essential Gear Sets to Build BEFORE Erdtree
53:31 - Everything You Need to Know About a Greatsword Build in Elden Ring
01:04:33 - This Elden Ring Faith Build is SUPER POWERFUL!

## Tales of the Shire Preview: Living a Hobbit’s Life in Peace
 - [https://www.youtube.com/watch?v=Shyc9EyPdCg](https://www.youtube.com/watch?v=Shyc9EyPdCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T13:00:33+00:00

Even in my all-too-brief hands-on demo, it was clear that Tales of the Shire is shaping up to be exactly what I was hoping it would be: a zero-stakes, relaxing time spent in the Shire. Previewed by Ryan McCaffrey

#IGN #Gaming

## Flippy Fest 2024: An EverQuest Celebration
 - [https://www.youtube.com/watch?v=NPt9mGqURQk](https://www.youtube.com/watch?v=NPt9mGqURQk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T13:00:31+00:00

Check out Flippy Fest, the first-ever livestream event for EverQuest. The event celebrates the past 28 years of development and looks forward to the current devs behind EverQuest and EverQuest ll. Make sure to watch the video to find out what to expect for Year of Darkpaw: An EverQuest Celebration. 

#IGN #Gaming

## Mario & Luigi: Brothership - Official Announcement Trailer | Nintendo Direct 2024
 - [https://www.youtube.com/watch?v=5BTHdsLYGPM](https://www.youtube.com/watch?v=5BTHdsLYGPM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T09:52:32+00:00

Check out the Mario & Luigi: Brothership trailer. Get a look at some Mario & Luigi: Brothership gameplay, enemies, and more as the duo embark on a new seafaring adventure. Mario & Luigi Brothership is coming to Nintendo Switch on November 7, 2024.

#Mario #Nintendo #Gaming

## Everything Announced in the Nintendo Direct (June 2024)
 - [https://www.youtube.com/watch?v=GblXfFCZkFE](https://www.youtube.com/watch?v=GblXfFCZkFE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T01:32:54+00:00

Nintendo came out swinging with the presumably last Nintendo Direct that belongs solely to the Nintendo Switch. With a brand new Zelda game where you finally play as the titular character in The Legend of Zelda: Echoes of Wisdom and, after seven years, a first-look at Metroid Prime 4 gameplay, which very much looks like a Switch 2 release. Here's everything that was announced in the June 2024 Nintendo Direct.

#IGN #Gaming #nintendo

## Here’s what to expect from PlayStation this summer. Presented by The United States @marinecorps
 - [https://www.youtube.com/watch?v=BVRs9pj9d5c](https://www.youtube.com/watch?v=BVRs9pj9d5c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T00:47:25+00:00



## Here’s what we’re anticipating from Xbox this summer. Presented by The United States @marinecorps
 - [https://www.youtube.com/watch?v=fX6eMmfqyko](https://www.youtube.com/watch?v=fX6eMmfqyko)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T00:46:34+00:00



## Is Metroid Prime 4 the first Switch 2 game? Presented by @xfinity
 - [https://www.youtube.com/watch?v=u9C0lCjGBXo](https://www.youtube.com/watch?v=u9C0lCjGBXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T00:07:58+00:00



## Street Fighter 6 - Official Character Guide: M. Bison Trailer
 - [https://www.youtube.com/watch?v=oYSyqdXBs2Q](https://www.youtube.com/watch?v=oYSyqdXBs2Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T00:02:59+00:00

Your demise awaits! Watch the latest Street Fighter 6 trailer for a deep dive into M. Bison's moves, special abilities, and more ahead of the character's arrival in the fighting game on June 26, 2024. The trailer showcases moves like psycho crusher attack, double knee press, and much more.

#IGN #Gaming #StreetFighter6

## The Beast Within - Official Trailer (2024) Kit Harington, Ashleigh Cummings
 - [https://www.youtube.com/watch?v=aabVx84XZ9A](https://www.youtube.com/watch?v=aabVx84XZ9A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-06-19T00:00:01+00:00

Check out the trailer for The Beast Within, an upcoming movie starring Kit Harington, Ashleigh Cummings, James Cosmo, and Caoilinn Springall.

After a series of strange events leads her to question her family’s isolated life on a fortified compound deep in the English wilds, 10-year-old Willow follows her parents on one of their secret late-night treks to the heart of the ancient forest. But upon witnessing her father undergo a terrible transformation, she too becomes ensnared by the dark ancestral secret they’ve tried so desperately to conceal.

The Beast Within is produced by Merlin Merton, Martin Owen, Ryan Hamilton, Karl Hall, Sebastian Street, Alex Chang, Jack Christian, Evan Ross, Jordan Wagner, and Ying Ye. It is written by Greer Taylor Ellison and Alexander J. Farrell.

The Beast Within, directed by Alexander J. Farrell, opens in theaters nationwide on July 26, 2024.

#IGN #Movies

