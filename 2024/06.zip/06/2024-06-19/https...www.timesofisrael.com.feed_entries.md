# Source:The Times of Israel, URL:https://www.timesofisrael.com/feed, language:en-US

## Eugene Vindman, who featured in Trump’s first impeachment, wins Virginia primary
 - [https://www.timesofisrael.com/eugene-vindman-who-featured-in-trumps-first-impeachment-wins-virginia-primary](https://www.timesofisrael.com/eugene-vindman-who-featured-in-trumps-first-impeachment-wins-virginia-primary)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T22:16:21+00:00

<p>Ex-official with Jewish Ukrainian roots to represent Democrats in competitive race for US House seat; pro-Israel challenger slightly ahead in another state district's GOP primary</p>
<p>The post <a href="https://www.timesofisrael.com/eugene-vindman-who-featured-in-trumps-first-impeachment-wins-virginia-primary/">Eugene Vindman, who featured in Trump’s first impeachment, wins Virginia primary</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/dude-e1718834014308-1024x640.jpg" title="Eugene Vindman, who featured in Trump’s first impeachment, wins Virginia primary" width="160" /></figure>

## Italian PM’s party shrugs off video of youth wing members performing fascist salutes
 - [https://www.timesofisrael.com/italian-pms-party-shrugs-off-video-of-youth-wing-members-performing-fascist-salutes](https://www.timesofisrael.com/italian-pms-party-shrugs-off-video-of-youth-wing-members-performing-fascist-salutes)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T21:28:38+00:00

<p>Far-right Brothers of Italy claims investigative media report into National Youth, which also featured shouts of 'Seig Heil' and 'Duce,' shows 'fragmented, decontextualized images'</p>
<p>The post <a href="https://www.timesofisrael.com/italian-pms-party-shrugs-off-video-of-youth-wing-members-performing-fascist-salutes/">Italian PM&#8217;s party shrugs off video of youth wing members performing fascist salutes</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AFP__20220922__32JW8JX__v1__HighRes__ItalyPoliticsVoteParties-e1718832030317-1024x640.jpg" title="Italian PM&#8217;s party shrugs off video of youth wing members performing fascist salutes" width="160" /></figure>

## Shipping industry urges Red Sea action as Yemen’s Houthis sink second merchant ship
 - [https://www.timesofisrael.com/shipping-industry-urges-red-sea-action-as-yemens-houthis-sink-second-merchant-ship](https://www.timesofisrael.com/shipping-industry-urges-red-sea-action-as-yemens-houthis-sink-second-merchant-ship)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T20:52:35+00:00

<p>Joint statement of world's largest seafaring groups calls for 'swift de-escalation' amid spike in attacks by Iran-backed rebels, who are terrorizing trade route in support of Gaza</p>
<p>The post <a href="https://www.timesofisrael.com/shipping-industry-urges-red-sea-action-as-yemens-houthis-sink-second-merchant-ship/">Shipping industry urges Red Sea action as Yemen&#8217;s Houthis sink second merchant ship</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AP24166550313887-1024x640.jpg" title="Shipping industry urges Red Sea action as Yemen&#8217;s Houthis sink second merchant ship" width="160" /></figure>

## Israel seeks to replace Red Cross with ‘external party’ for Palestinian prisoner visits
 - [https://www.timesofisrael.com/israel-seeks-to-replace-red-cross-with-external-party-for-palestinian-prisoner-visits](https://www.timesofisrael.com/israel-seeks-to-replace-red-cross-with-external-party-for-palestinian-prisoner-visits)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T20:52:33+00:00

<p>Civil rights group blasts proposal, says government 'circumventing international law' and 'overriding international regulations based on professional oversight and neutrality'</p>
<p>The post <a href="https://www.timesofisrael.com/israel-seeks-to-replace-red-cross-with-external-party-for-palestinian-prisoner-visits/">Israel seeks to replace Red Cross with &#8216;external party&#8217; for Palestinian prisoner visits</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/F240214CG46-1024x640.jpg" title="Israel seeks to replace Red Cross with &#8216;external party&#8217; for Palestinian prisoner visits" width="160" /></figure>

## Fighting off Houthis for months, US carrier in Red Sea may be running out of steam
 - [https://www.timesofisrael.com/fighting-off-houthis-for-months-us-carrier-in-red-sea-may-be-running-out-of-steam](https://www.timesofisrael.com/fighting-off-houthis-for-months-us-carrier-in-red-sea-may-be-running-out-of-steam)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T20:52:29+00:00

<p>The USS Dwight D. Eisenhower is long overdue for a break from the longest-running naval battle since WWII, but experts worry effort to protect shipping could flounder without it</p>
<p>The post <a href="https://www.timesofisrael.com/fighting-off-houthis-for-months-us-carrier-in-red-sea-may-be-running-out-of-steam/">Fighting off Houthis for months, US carrier in Red Sea may be running out of steam</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AP24166397493847-1-1024x640.jpg" title="Fighting off Houthis for months, US carrier in Red Sea may be running out of steam" width="160" /></figure>

## Canada puts Iran’s Revolutionary Guards on terror blacklist
 - [https://www.timesofisrael.com/canada-puts-irans-revolutionary-guards-on-terror-blacklist](https://www.timesofisrael.com/canada-puts-irans-revolutionary-guards-on-terror-blacklist)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T20:52:27+00:00

<p>Ottawa warns citizens to leave Iran, dropping long-standing objections, after opposition lawmakers and others step up pressure following missile attack on Israel</p>
<p>The post <a href="https://www.timesofisrael.com/canada-puts-irans-revolutionary-guards-on-terror-blacklist/">Canada puts Iran&#8217;s Revolutionary Guards on terror blacklist</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2022/03/AP21103299573725-e1648753684204-1024x640.jpg" title="Canada puts Iran&#8217;s Revolutionary Guards on terror blacklist" width="160" /></figure>

## Rescued hostage Almog Meir Jan grapples with return to freedom
 - [https://www.timesofisrael.com/rescued-hostage-almog-meir-jan-grapples-with-return-to-freedom](https://www.timesofisrael.com/rescued-hostage-almog-meir-jan-grapples-with-return-to-freedom)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T20:52:24+00:00

<p>Meir Jan's uncle, Aviram Meir, discusses his nephew's physical and emotional health, his need to see his fellow hostages and the embrace he receives from the Israeli public</p>
<p>The post <a href="https://www.timesofisrael.com/rescued-hostage-almog-meir-jan-grapples-with-return-to-freedom/">Rescued hostage Almog Meir Jan grapples with return to freedom</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/WhatsApp-Image-2024-06-19-at-18.05.20-1024x640.jpeg" title="Rescued hostage Almog Meir Jan grapples with return to freedom" width="160" /></figure>

## Staff Sgt. Dor Yarhi, 21: Sports lover made the most of each moment
 - [https://www.timesofisrael.com/staff-sgt-dor-yarhi-21-sports-lover-made-the-most-of-each-moment](https://www.timesofisrael.com/staff-sgt-dor-yarhi-21-sports-lover-made-the-most-of-each-moment)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T19:20:09+00:00

<p>Killed battling the Hamas invasion of the Nahal Oz IDF outpost on Oct. 7</p>
<p>The post <a href="https://www.timesofisrael.com/staff-sgt-dor-yarhi-21-sports-lover-made-the-most-of-each-moment/">Staff Sgt. Dor Yarhi, 21: Sports lover made the most of each moment</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/Untitled-design62-1024x640.jpg" title="Staff Sgt. Dor Yarhi, 21: Sports lover made the most of each moment" width="160" /></figure>

## Margarita Gusak, 21: Artist with plans to attend medical school
 - [https://www.timesofisrael.com/margarita-gusak-21-artist-with-plans-to-attend-medical-school](https://www.timesofisrael.com/margarita-gusak-21-artist-with-plans-to-attend-medical-school)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T19:15:36+00:00

<p>Murdered by Hamas terrorists while fleeing the Supernova music festival on October 7</p>
<p>The post <a href="https://www.timesofisrael.com/margarita-gusak-21-artist-with-plans-to-attend-medical-school/">Margarita Gusak, 21: Artist with plans to attend medical school</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/F9EOWUCW0AAy_6M-e1718796359831-1024x640.jpg" title="Margarita Gusak, 21: Artist with plans to attend medical school" width="160" /></figure>

## Amid multiplying spats, Netanyahu urges coalition partners to ‘get a grip’
 - [https://www.timesofisrael.com/amid-multiplying-spats-netanyahu-urges-coalition-partners-to-get-a-grip](https://www.timesofisrael.com/amid-multiplying-spats-netanyahu-urges-coalition-partners-to-get-a-grip)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T18:46:57+00:00

<p>PM says government members must set aside 'partisan interests' and unite around war effort in Gaza, as he faces Haredi anger, public row with Ben Gvir, dissent from Barkat</p>
<p>The post <a href="https://www.timesofisrael.com/amid-multiplying-spats-netanyahu-urges-coalition-partners-to-get-a-grip/">Amid multiplying spats, Netanyahu urges coalition partners to ‘get a grip&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/vlcsnap-2024-06-19-17h30m46s822-copy-1024x640.jpg" title="Amid multiplying spats, Netanyahu urges coalition partners to ‘get a grip&#8217;" width="160" /></figure>

## Nasrallah says ‘no place’ in Israel would be safe in war, threatens to target Cyprus
 - [https://www.timesofisrael.com/nasrallah-says-no-place-in-israel-would-be-safe-in-war-threatens-to-target-cyprus](https://www.timesofisrael.com/nasrallah-says-no-place-in-israel-would-be-safe-in-war-threatens-to-target-cyprus)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T18:46:54+00:00

<p>In televised speech, terror leader claims Hezbollah does not want total war but is prepared for it, will not halt fighting until permanent ceasefire is reached in Gaza</p>
<p>The post <a href="https://www.timesofisrael.com/nasrallah-says-no-place-in-israel-would-be-safe-in-war-threatens-to-target-cyprus/">Nasrallah says ‘no place’ in Israel would be safe in war, threatens to target Cyprus</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/image-24-1024x640.jpg" title="Nasrallah says ‘no place’ in Israel would be safe in war, threatens to target Cyprus" width="160" /></figure>

## Brussels declines to host upcoming Belgium-Israel soccer match, citing security risk
 - [https://www.timesofisrael.com/brussels-declines-to-host-upcoming-belgium-israel-soccer-match-citing-security-risk](https://www.timesofisrael.com/brussels-declines-to-host-upcoming-belgium-israel-soccer-match-citing-security-risk)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T18:46:46+00:00

<p>City official say game scheduled for September would provoke demonstrations endangering players, spectators, residents and police </p>
<p>The post <a href="https://www.timesofisrael.com/brussels-declines-to-host-upcoming-belgium-israel-soccer-match-citing-security-risk/">Brussels declines to host upcoming Belgium-Israel soccer match, citing security risk</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AP24160652202583-1024x640.jpg" title="Brussels declines to host upcoming Belgium-Israel soccer match, citing security risk" width="160" /></figure>

## ‘Their voice’: New forum of slain surveillance soldiers’ families demands Oct. 7 probe
 - [https://www.timesofisrael.com/their-voice-new-forum-of-slain-surveillance-soldiers-families-demands-oct-7-probe](https://www.timesofisrael.com/their-voice-new-forum-of-slain-surveillance-soldiers-families-demands-oct-7-probe)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T17:51:44+00:00

<p>Group joins calls to form state commission of inquiry, says resignations 'will not absolve' those who failed to prevent massacre of female troops at Nahal Oz base</p>
<p>The post <a href="https://www.timesofisrael.com/their-voice-new-forum-of-slain-surveillance-soldiers-families-demands-oct-7-probe/">&#8216;Their voice&#8217;: New forum of slain surveillance soldiers&#8217; families demands Oct. 7 probe</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/01/ezgif.com-gif-maker-1024x640.jpg" title="&#8216;Their voice&#8217;: New forum of slain surveillance soldiers&#8217; families demands Oct. 7 probe" width="160" /></figure>

## Two teens charged over ‘horrific’ antisemitic rape of 12-year-old girl near Paris
 - [https://www.timesofisrael.com/two-teens-charged-over-horrific-antisemitic-rape-of-12-year-old-girl-near-paris](https://www.timesofisrael.com/two-teens-charged-over-horrific-antisemitic-rape-of-12-year-old-girl-near-paris)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T16:51:41+00:00

<p>Third suspect indicted with anti-Jewish threats as attack sends shockwaves through France; Macron decries 'scourge,' urges schools to discuss hatred of Jews</p>
<p>The post <a href="https://www.timesofisrael.com/two-teens-charged-over-horrific-antisemitic-rape-of-12-year-old-girl-near-paris/">Two teens charged over &#8216;horrific&#8217; antisemitic rape of 12-year-old girl near Paris</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AFP__20240517__34RY8TF__v4__HighRes__FrancePoliceReligionInvestigation-1024x640.jpg" title="Two teens charged over &#8216;horrific&#8217; antisemitic rape of 12-year-old girl near Paris" width="160" /></figure>

## ADL revises ‘report card’ grading US campuses’ handling of antisemitism
 - [https://www.timesofisrael.com/adl-revises-report-card-grading-us-campuses-handling-of-antisemitism](https://www.timesofisrael.com/adl-revises-report-card-grading-us-campuses-handling-of-antisemitism)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T16:51:39+00:00

<p>Watchdog reassesses 12 US universities' grades upwards, 3 downwards, citing new information and 'serious incidents' since failing many leading schools</p>
<p>The post <a href="https://www.timesofisrael.com/adl-revises-report-card-grading-us-campuses-handling-of-antisemitism/">ADL revises &#8216;report card&#8217; grading US campuses&#8217; handling of antisemitism</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/AP24144421033367-1024x640.jpg" title="ADL revises &#8216;report card&#8217; grading US campuses&#8217; handling of antisemitism" width="160" /></figure>

## Poll: Over half of Arab Israelis feel sense of ‘shared destiny’ with Jews
 - [https://www.timesofisrael.com/poll-over-half-of-arab-israelis-feel-sense-of-shared-destiny-with-jews](https://www.timesofisrael.com/poll-over-half-of-arab-israelis-feel-sense-of-shared-destiny-with-jews)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T15:16:46+00:00

<p>Survey of Arab citizens also finds that over two thirds are in favor of an Arab party joining a future government coalition, and 40% say it doesn't have to be a center-left one</p>
<p>The post <a href="https://www.timesofisrael.com/poll-over-half-of-arab-israelis-feel-sense-of-shared-destiny-with-jews/">Poll: Over half of Arab Israelis feel sense of &#8216;shared destiny&#8217; with Jews</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2015/03/000_Nic6429203-1024x640.jpg" title="Poll: Over half of Arab Israelis feel sense of &#8216;shared destiny&#8217; with Jews" width="160" /></figure>

## Is the US poised to sanction an Israeli minister for the first time?
 - [https://www.timesofisrael.com/is-the-us-poised-to-sanction-an-israeli-minister-for-the-first-time](https://www.timesofisrael.com/is-the-us-poised-to-sanction-an-israeli-minister-for-the-first-time)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T14:34:04+00:00

<p>Some in administration suggest order Biden signed to target West Bank destabilizers should be used against Smotrich, whose withholding of funds has the PA on the verge of collapse</p>
<p>The post <a href="https://www.timesofisrael.com/is-the-us-poised-to-sanction-an-israeli-minister-for-the-first-time/">Is the US poised to sanction an Israeli minister for the first time?</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/F240421CG06-1024x640.jpg" title="Is the US poised to sanction an Israeli minister for the first time?" width="160" /></figure>

## Failure of ‘Rabbis Bill’ shatters Haredi trust in PM, putting coalition on thin ice
 - [https://www.timesofisrael.com/failure-of-rabbis-bill-shatters-haredi-trust-in-pm-putting-coalition-on-thin-ice](https://www.timesofisrael.com/failure-of-rabbis-bill-shatters-haredi-trust-in-pm-putting-coalition-on-thin-ice)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T14:30:23+00:00

<p>After Likud MKs rebel over contentious measure, ultra-Orthodox lawmakers accuse Netanyahu of being unable to keep party in line, doubt he can deliver on IDF draft bill</p>
<p>The post <a href="https://www.timesofisrael.com/failure-of-rabbis-bill-shatters-haredi-trust-in-pm-putting-coalition-on-thin-ice/">Failure of &#8216;Rabbis Bill&#8217; shatters Haredi trust in PM, putting coalition on thin ice</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/04/F230123YS83-1024x640.jpg" title="Failure of &#8216;Rabbis Bill&#8217; shatters Haredi trust in PM, putting coalition on thin ice" width="160" /></figure>

## After Ben Gvir demands spot on war cabinet, PM accuses him of leaking state secrets
 - [https://www.timesofisrael.com/after-ben-gvir-demands-spot-on-war-cabinet-pm-accuses-him-of-leaking-state-secrets](https://www.timesofisrael.com/after-ben-gvir-demands-spot-on-war-cabinet-pm-accuses-him-of-leaking-state-secrets)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T14:11:17+00:00

<p>Far-right minister snipes at Netanyahu's pacemaker; Gantz wonders why PM appointed minister to the cabinet and gave him power over police if he believes he is untrustworthy</p>
<p>The post <a href="https://www.timesofisrael.com/after-ben-gvir-demands-spot-on-war-cabinet-pm-accuses-him-of-leaking-state-secrets/">After Ben Gvir demands spot on war cabinet, PM accuses him of leaking state secrets</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/08/33FZ2CR-highres-e1692982591845-1024x640.jpg" title="After Ben Gvir demands spot on war cabinet, PM accuses him of leaking state secrets" width="160" /></figure>

## Hostage freed in November deal says she was held in a Gaza hospital before release
 - [https://www.timesofisrael.com/hostage-freed-in-november-deal-says-she-was-held-in-a-gaza-hospital-before-release](https://www.timesofisrael.com/hostage-freed-in-november-deal-says-she-was-held-in-a-gaza-hospital-before-release)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T13:57:35+00:00

<p>In an interview with BBC, 75-year-old Arabic teacher Ada Sagi says being kidnapped from Nir Oz by Hamas terrorists destroyed her belief in peace between Israelis and Palestinians</p>
<p>The post <a href="https://www.timesofisrael.com/hostage-freed-in-november-deal-says-she-was-held-in-a-gaza-hospital-before-release/">Hostage freed in November deal says she was held in a Gaza hospital before release</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/10/AP23285445925681-1024x640.jpg" title="Hostage freed in November deal says she was held in a Gaza hospital before release" width="160" /></figure>

## As war winds down, diplomacy is paramount, but Netanyahu has other priorities
 - [https://www.timesofisrael.com/as-war-winds-down-diplomacy-is-paramount-but-netanyahu-has-other-priorities](https://www.timesofisrael.com/as-war-winds-down-diplomacy-is-paramount-but-netanyahu-has-other-priorities)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T13:36:12+00:00

<p>With Hamas being routed as an organized army yet still a potent guerrilla force, it's time for intensive work on alternative rule for Gaza. Instead, the PM picks fights with the US</p>
<p>The post <a href="https://www.timesofisrael.com/as-war-winds-down-diplomacy-is-paramount-but-netanyahu-has-other-priorities/">As war winds down, diplomacy is paramount, but Netanyahu has other priorities</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/DSC02418-1024x640.jpg" title="As war winds down, diplomacy is paramount, but Netanyahu has other priorities" width="160" /></figure>

## UN rights office: Israeli Gaza strikes may have ‘systematically violated’ laws of war
 - [https://www.timesofisrael.com/un-rights-office-israeli-gaza-strikes-may-have-systematically-violated-laws-of-war](https://www.timesofisrael.com/un-rights-office-israeli-gaza-strikes-may-have-systematically-violated-laws-of-war)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T11:55:41+00:00

<p>Report does not mention Hamas's October 7 attack, cites six incidents with high casualty counts that it calls 'emblematic' of a pattern of behavior on Israel's part</p>
<p>The post <a href="https://www.timesofisrael.com/un-rights-office-israeli-gaza-strikes-may-have-systematically-violated-laws-of-war/">UN rights office: Israeli Gaza strikes may have &#8216;systematically violated&#8217; laws of war</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/Untitled-1666-1024x640.jpg" title="UN rights office: Israeli Gaza strikes may have &#8216;systematically violated&#8217; laws of war" width="160" /></figure>

## US officials say Gaza aid pier may be dismantled soon, after little success – report
 - [https://www.timesofisrael.com/us-officials-say-gaza-aid-pier-may-be-dismantled-soon-after-little-success-report](https://www.timesofisrael.com/us-officials-say-gaza-aid-pier-may-be-dismantled-soon-after-little-success-report)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T11:02:27+00:00

<p>New York Times reports said structure could be taken down in early July, weeks earlier than planned and after only 10 days of actual operation, due to unexpected weather conditions</p>
<p>The post <a href="https://www.timesofisrael.com/us-officials-say-gaza-aid-pier-may-be-dismantled-soon-after-little-success-report/">US officials say Gaza aid pier may be dismantled soon, after little success &#8211; report</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AP24149609530466-e1717986633910-1024x640.jpg" title="US officials say Gaza aid pier may be dismantled soon, after little success &#8211; report" width="160" /></figure>

## Israel at War: The Paradox of Religious Zionism - Sponsored Content
 - [https://www.timesofisrael.com/spotlight/israel-at-war-the-paradox-of-religious-zionism](https://www.timesofisrael.com/spotlight/israel-at-war-the-paradox-of-religious-zionism)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T10:54:47+00:00

<p>Yossi Klein Halevi and Donniel Hartman detail the strengths and weaknesses of this diverse community</p>
<p>The post <a href="https://www.timesofisrael.com/spotlight/israel-at-war-the-paradox-of-religious-zionism/">Israel at War: The Paradox of Religious Zionism</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/10/WhatsApp_Image_2023-10-07_at_22.38.48_1-1024x640.jpeg" title="Israel at War: The Paradox of Religious Zionism" width="160" /></figure>

## Daily Briefing June 19: Day 257 – Report from Rafah: How Hamas triggers booby-traps
 - [https://www.timesofisrael.com/daily-briefing-june-19-day-257-report-from-rafah-how-hamas-triggers-booby-traps](https://www.timesofisrael.com/daily-briefing-june-19-day-257-report-from-rafah-how-hamas-triggers-booby-traps)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T10:38:51+00:00

<p>Military reporter Emanuel Fabian describes his recent embed with the Givati Infantry Brigade in Gaza, speaks about Israel's recently announced Lebanon war plan and arms sales</p>
<p>The post <a href="https://www.timesofisrael.com/daily-briefing-june-19-day-257-report-from-rafah-how-hamas-triggers-booby-traps/">Daily Briefing June 19: Day 257 &#8211; Report from Rafah: How Hamas triggers booby-traps</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/DSC02589-1024x640.jpg" title="Daily Briefing June 19: Day 257 &#8211; Report from Rafah: How Hamas triggers booby-traps" width="160" /></figure>

## Putin says Russia, North Korea made new defense pact to aid each other if attacked
 - [https://www.timesofisrael.com/putin-says-russia-north-korea-made-new-defense-pact-to-aid-each-other-if-attacked](https://www.timesofisrael.com/putin-says-russia-north-korea-made-new-defense-pact-to-aid-each-other-if-attacked)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T10:38:44+00:00

<p>Deal announced during Russian president's visit to Pyongyang; provides Moscow with munitions for Ukraine war in exchange for cash, technology to enhance Kim's nuclear program</p>
<p>The post <a href="https://www.timesofisrael.com/putin-says-russia-north-korea-made-new-defense-pact-to-aid-each-other-if-attacked/">Putin says Russia, North Korea made new defense pact to aid each other if attacked</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AP24171200037349-1024x640.jpg" title="Putin says Russia, North Korea made new defense pact to aid each other if attacked" width="160" /></figure>

## Syrian officer killed in alleged Israeli strike; Hezbollah explosive drone hits north
 - [https://www.timesofisrael.com/syrian-officer-killed-in-alleged-israeli-strike-hezbollah-explosive-drone-hits-north](https://www.timesofisrael.com/syrian-officer-killed-in-alleged-israeli-strike-hezbollah-explosive-drone-hits-north)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T10:22:49+00:00

<p>State media says Israeli drones struck military sites in southern Syria; separately IDF says it targeted weapons depot belonging to Lebanese terror group</p>
<p>The post <a href="https://www.timesofisrael.com/syrian-officer-killed-in-alleged-israeli-strike-hezbollah-explosive-drone-hits-north/">Syrian officer killed in alleged Israeli strike; Hezbollah explosive drone hits north</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AFP__20240618__34XE4QH__v1__HighRes__IsraelLebanonPalestinianConflict-1-1024x640.jpg" title="Syrian officer killed in alleged Israeli strike; Hezbollah explosive drone hits north" width="160" /></figure>

## Trade in smuggled cigarettes said to hamper aid deliveries in Gaza
 - [https://www.timesofisrael.com/trade-in-smuggled-cigarettes-said-to-hamper-aid-deliveries-in-gaza](https://www.timesofisrael.com/trade-in-smuggled-cigarettes-said-to-hamper-aid-deliveries-in-gaza)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T10:12:54+00:00

<p>With a single cigarette selling for as much as $25, trucks reportedly targeted by smugglers seeking to retrieve their goods, criminals trying to get to them first</p>
<p>The post <a href="https://www.timesofisrael.com/trade-in-smuggled-cigarettes-said-to-hamper-aid-deliveries-in-gaza/">Trade in smuggled cigarettes said to hamper aid deliveries in Gaza</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/05/F240403ARK52-1024x640.jpg" title="Trade in smuggled cigarettes said to hamper aid deliveries in Gaza" width="160" /></figure>

## IDF slams right-wing pundit for ‘lie’ that military chief wants Hamas to rule Gaza
 - [https://www.timesofisrael.com/idf-slams-right-wing-pundit-for-lie-that-military-chief-wants-hamas-to-rule-gaza](https://www.timesofisrael.com/idf-slams-right-wing-pundit-for-lie-that-military-chief-wants-hamas-to-rule-gaza)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T09:31:00+00:00

<p>In rare critique, military rejects assertion by Yaakov Bardugo that Halevi is pushing an alleged Washington framework to end the war</p>
<p>The post <a href="https://www.timesofisrael.com/idf-slams-right-wing-pundit-for-lie-that-military-chief-wants-hamas-to-rule-gaza/">IDF slams right-wing pundit for &#8216;lie&#8217; that military chief wants Hamas to rule Gaza</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/F240520YS153-1024x640.jpg" title="IDF slams right-wing pundit for &#8216;lie&#8217; that military chief wants Hamas to rule Gaza" width="160" /></figure>

## Houthis sink commercial shipping vessel in Red Sea, Filipino sailor killed
 - [https://www.timesofisrael.com/houthis-sink-commercial-shipping-vessel-in-red-sea-filipino-sailor-killed](https://www.timesofisrael.com/houthis-sink-commercial-shipping-vessel-in-red-sea-filipino-sailor-killed)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T09:20:43+00:00

<p>Liberian-flagged, Greek-owned-and-operated ship was attacked by boat drone last week; US says crewman killed in attack, but Philippines yet to confirm; Sri Lankan national wounded</p>
<p>The post <a href="https://www.timesofisrael.com/houthis-sink-commercial-shipping-vessel-in-red-sea-filipino-sailor-killed/">Houthis sink commercial shipping vessel in Red Sea, Filipino sailor killed</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/03/AFP__20240302__34KM9KL__v1__HighRes__YemenConflictShipping-1024x640.jpg" title="Houthis sink commercial shipping vessel in Red Sea, Filipino sailor killed" width="160" /></figure>

## Haredim threaten to bolt coalition as PM pulls ‘Rabbis Bill’ from Knesset agenda
 - [https://www.timesofisrael.com/haredim-threaten-to-bolt-coalition-as-pm-pulls-rabbis-bill-from-knesset-agenda](https://www.timesofisrael.com/haredim-threaten-to-bolt-coalition-as-pm-pulls-rabbis-bill-from-knesset-agenda)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T08:57:26+00:00

<p>Cancelation announced hours before vote was scheduled on contentious law, as Likud MKs voice opposition; Shas, UTJ issue veiled threats to topple government</p>
<p>The post <a href="https://www.timesofisrael.com/haredim-threaten-to-bolt-coalition-as-pm-pulls-rabbis-bill-from-knesset-agenda/">Haredim threaten to bolt coalition as PM pulls &#8216;Rabbis Bill&#8217; from Knesset agenda</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/F240610YS36-1024x640.jpg" title="Haredim threaten to bolt coalition as PM pulls &#8216;Rabbis Bill&#8217; from Knesset agenda" width="160" /></figure>

## Emergency gear for IDF special forces - Sponsored Content
 - [https://my.israelgives.org/en/fundme/Shalmonsquad?partner=timesofisrael](https://my.israelgives.org/en/fundme/Shalmonsquad?partner=timesofisrael)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T08:39:48+00:00

<p>The war is unfortunately far from over and the threats to Israel’s existence are only increasing. With much gratitude and humility, we turn to you and again ask for your help. </p>
<p>The post <a href="https://www.timesofisrael.com/spotlight/emergency-gear-for-idf-special-forces/">Emergency gear for IDF special forces</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/Shalmon_main1-1024x640.jpeg" title="Emergency gear for IDF special forces" width="160" /></figure>

## Noam Chomsky’s wife denies reports famed linguist and Israel critic died in Brazil
 - [https://www.timesofisrael.com/noam-chomskys-wife-denies-reports-famed-linguist-and-israel-critic-died-in-brazil](https://www.timesofisrael.com/noam-chomskys-wife-denies-reports-famed-linguist-and-israel-critic-died-in-brazil)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T08:31:17+00:00

<p>Prominent activist, 95, had been hospitalized while recovering from a stroke suffered a year ago, Valeria Chomsky says, as false reports of his death spread on social media</p>
<p>The post <a href="https://www.timesofisrael.com/noam-chomskys-wife-denies-reports-famed-linguist-and-israel-critic-died-in-brazil/">Noam Chomsky&#8217;s wife denies reports famed linguist and Israel critic died in Brazil</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AFP__20240619__34XF37T__v1__HighRes__FilesBrazilUsPoliticsLinguisticsChomskyHealth-1024x640.jpg" title="Noam Chomsky&#8217;s wife denies reports famed linguist and Israel critic died in Brazil" width="160" /></figure>

## US cancels talks in Washington over Netanyahu’s complaint of weapons holdup – report
 - [https://www.timesofisrael.com/us-cancels-talks-in-washington-over-netanyahus-complaint-of-weapons-holdup-report](https://www.timesofisrael.com/us-cancels-talks-in-washington-over-netanyahus-complaint-of-weapons-holdup-report)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T07:40:35+00:00

<p>Some Israeli officials said to already be en route when Thursday meetings called off; in video, Netanyahu accused US of withholding arms transfers, sparking White House irritation</p>
<p>The post <a href="https://www.timesofisrael.com/us-cancels-talks-in-washington-over-netanyahus-complaint-of-weapons-holdup-report/">US cancels talks in Washington over Netanyahu&#8217;s complaint of weapons holdup &#8211; report</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AP24170654132532-1024x640.jpg" title="US cancels talks in Washington over Netanyahu&#8217;s complaint of weapons holdup &#8211; report" width="160" /></figure>

## TAU’s $10 million Doolittle prize seeks scientists who can ‘talk to the animals’
 - [https://www.timesofisrael.com/taus-10-million-doolittle-prize-seeks-scientists-who-can-talk-to-the-animals](https://www.timesofisrael.com/taus-10-million-doolittle-prize-seeks-scientists-who-can-talk-to-the-animals)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T06:15:26+00:00

<p>The award inaugurated this month at Tel Aviv University hopes to spur research, with the aim of creating human-animal dialogue 'at their own level'</p>
<p>The post <a href="https://www.timesofisrael.com/taus-10-million-doolittle-prize-seeks-scientists-who-can-talk-to-the-animals/">TAU&#8217;s $10 million Doolittle prize seeks scientists who can &#8216;talk to the animals&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/F191013DCFF08-1024x640.jpg" title="TAU&#8217;s $10 million Doolittle prize seeks scientists who can &#8216;talk to the animals&#8217;" width="160" /></figure>

## Wikipedia moves to bar ADL, claiming reliability concerns on Israel and antisemitim
 - [https://www.timesofisrael.com/wikipedia-moves-to-bar-adl-claiming-reliability-concerns-on-israel-and-antisemitim](https://www.timesofisrael.com/wikipedia-moves-to-bar-adl-claiming-reliability-concerns-on-israel-and-antisemitim)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T03:40:12+00:00

<p>Editor who initiated deliberation that ultimately led to ban on using the Jewish group as a source accuses it of 'shameless politicization,' as only a small minority defend it</p>
<p>The post <a href="https://www.timesofisrael.com/wikipedia-moves-to-bar-adl-claiming-reliability-concerns-on-israel-and-antisemitim/">Wikipedia moves to bar ADL, claiming reliability concerns on Israel and antisemitim</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AFP__20130104__Par7407694__v1002__HighRes__FranceLogoWikipedia-e1718767607497-1024x640.jpg" title="Wikipedia moves to bar ADL, claiming reliability concerns on Israel and antisemitim" width="160" /></figure>

## In Rafah, IDF focuses on tunnels with aim of destroying Hamas brigade within a month
 - [https://www.timesofisrael.com/in-rafah-idf-focuses-on-tunnels-with-aim-of-destroying-hamas-brigade-within-a-month](https://www.timesofisrael.com/in-rafah-idf-focuses-on-tunnels-with-aim-of-destroying-hamas-brigade-within-a-month)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T03:00:57+00:00

<p>ToI joins commander of Givati Brigade in Gaza's southernmost city, where army says the terror group's operatives have embedded themselves inside booby-trapped buildings and tunnels</p>
<p>The post <a href="https://www.timesofisrael.com/in-rafah-idf-focuses-on-tunnels-with-aim-of-destroying-hamas-brigade-within-a-month/">In Rafah, IDF focuses on tunnels with aim of destroying Hamas brigade within a month</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/DSC02244-1024x640.jpg" title="In Rafah, IDF focuses on tunnels with aim of destroying Hamas brigade within a month" width="160" /></figure>

## Mass anti-government rally held outside Knesset for second night in a row
 - [https://www.timesofisrael.com/mass-anti-government-rally-held-outside-knesset-for-second-night-in-a-row](https://www.timesofisrael.com/mass-anti-government-rally-held-outside-knesset-for-second-night-in-a-row)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T02:29:25+00:00

<p>Planned march to President's Residence fizzles out as protesters blame unclear directions from organizers and police roadblocks, on third day of 'week of disruption'</p>
<p>The post <a href="https://www.timesofisrael.com/mass-anti-government-rally-held-outside-knesset-for-second-night-in-a-row/">Mass anti-government rally held outside Knesset for second night in a row</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/F240618NRF19-1024x640.jpg" title="Mass anti-government rally held outside Knesset for second night in a row" width="160" /></figure>

## Qatari PM meets Haniyeh to push for ceasefire as US blames Sinwar for lack of deal
 - [https://www.timesofisrael.com/qatari-pm-meets-haniyeh-to-push-for-ceasefire-as-us-blames-sinwar-for-lack-of-deal](https://www.timesofisrael.com/qatari-pm-meets-haniyeh-to-push-for-ceasefire-as-us-blames-sinwar-for-lack-of-deal)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T01:00:22+00:00

<p>Source says main stumbling block to agreement remains terror group's demand for Gaza war to end and Israel's insistence that the fighting continue until all the hostages are freed</p>
<p>The post <a href="https://www.timesofisrael.com/qatari-pm-meets-haniyeh-to-push-for-ceasefire-as-us-blames-sinwar-for-lack-of-deal/">Qatari PM meets Haniyeh to push for ceasefire as US blames Sinwar for lack of deal</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AFP__20240612__34WH2PJ__v1__HighRes__QatarUsPoliticsDiplomacyIsraelPalestinianConfli-e1718198267434-1024x640.jpg" title="Qatari PM meets Haniyeh to push for ceasefire as US blames Sinwar for lack of deal" width="160" /></figure>

## Diplomats report at least 550 pilgrims died during hajj, most of them from the heat
 - [https://www.timesofisrael.com/diplomats-report-at-least-550-pilgrims-died-during-hajj-most-of-them-from-the-heat](https://www.timesofisrael.com/diplomats-report-at-least-550-pilgrims-died-during-hajj-most-of-them-from-the-heat)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-06-19T00:06:10+00:00

<p>Sources tell AFP over half of those killed were Egyptians, with one diplomat saying death toll was 'absolutely' boosted by the high number of unregistered pilgrims</p>
<p>The post <a href="https://www.timesofisrael.com/diplomats-report-at-least-550-pilgrims-died-during-hajj-most-of-them-from-the-heat/">Diplomats report at least 550 pilgrims died during hajj, most of them from the heat</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/06/AFP__20240618__34XC3LT__v1__HighRes__SaudiReligionIslamHajj-e1718754215653-1024x640.jpg" title="Diplomats report at least 550 pilgrims died during hajj, most of them from the heat" width="160" /></figure>

