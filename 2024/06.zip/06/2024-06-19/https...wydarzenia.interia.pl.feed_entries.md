# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Z Charkowa do Walencji. Ucieczka przed rosyjskim ostrzałem
 - [https://wydarzenia.interia.pl/zagranica/news-z-charkowa-do-walencji-ucieczka-przed-rosyjskim-ostrzalem,nId,7584773](https://wydarzenia.interia.pl/zagranica/news-z-charkowa-do-walencji-ucieczka-przed-rosyjskim-ostrzalem,nId,7584773)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T20:35:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-z-charkowa-do-walencji-ucieczka-przed-rosyjskim-ostrzalem,nId,7584773"><img align="left" alt="Z Charkowa do Walencji. Ucieczka przed rosyjskim ostrzałem" src="https://i.iplsc.com/z-charkowa-do-walencji-ucieczka-przed-rosyjskim-ostrzalem/000JCF2ZBUB16TOV-C321.jpg" /></a>Musiały uciekać z Charkowa do Walencji przed rosyjskim ostrzałem. Dwie białuchy arktyczne zostały przetransportowane do instytut oceanograficzny w środkowo wschodniej Hiszpanii. Podkreślono, że była to udana &quot;międzynarodowa operacja wysokiego ryzyka&quot;.</p><br clear="all" />

## Turysta zapłaci więcej? Kraj wprowadza podwójne cennik
 - [https://wydarzenia.interia.pl/zagranica/news-turysta-zaplaci-wiecej-kraj-wprowadza-podwojne-cennik,nId,7584762](https://wydarzenia.interia.pl/zagranica/news-turysta-zaplaci-wiecej-kraj-wprowadza-podwojne-cennik,nId,7584762)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T20:19:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-turysta-zaplaci-wiecej-kraj-wprowadza-podwojne-cennik,nId,7584762"><img align="left" alt="Turysta zapłaci więcej? Kraj wprowadza podwójne cennik" src="https://i.iplsc.com/turysta-zaplaci-wiecej-kraj-wprowadza-podwojne-cennik/000JCEWEFXIRCDSX-C321.jpg" /></a>Menu dla lokalnych klientów ma być tańsze, a dla gości z zagranicy - droższe. Na takie rozwiązanie decyduje się coraz więcej japońskich restauracji, by rozwój turystyki nie wpływał negatywnie na miejscowych konsumentów. </p><br clear="all" />

## Potężne burze w dwóch regionach. Wydano alerty najwyższego stopnia
 - [https://wydarzenia.interia.pl/kraj/news-potezne-burze-w-dwoch-regionach-wydano-alerty-najwyzszego-st,nId,7584757](https://wydarzenia.interia.pl/kraj/news-potezne-burze-w-dwoch-regionach-wydano-alerty-najwyzszego-st,nId,7584757)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T20:05:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-potezne-burze-w-dwoch-regionach-wydano-alerty-najwyzszego-st,nId,7584757"><img align="left" alt="Potężne burze w dwóch regionach. Wydano alerty najwyższego stopnia" src="https://i.iplsc.com/potezne-burze-w-dwoch-regionach-wydano-alerty-najwyzszego-st/000JCEXIYOHDG7LE-C321.jpg" /></a>Pogoda w najbliższych godzinach nie da odetchnąć. Przez Polskę wciąż przechodzą burze, a w niektórych miejscach zjawiska są szczególnie gwałtowne. IMGW wydało alerty najwyższego - trzeciego stopnia - dla dwóch regionów. Zagrzmi na Śląsku i w Małopolsce, a burzom towarzyszyć będą ulewy oraz porywisty wiatr, nawet do 120 km/h.</p><br clear="all" />

## Tę historię znała cała Polska. Nad morzem stanie rzeźba Baltica
 - [https://wydarzenia.interia.pl/pomorskie/news-te-historie-znala-cala-polska-nad-morzem-stanie-rzezba-balti,nId,7584745](https://wydarzenia.interia.pl/pomorskie/news-te-historie-znala-cala-polska-nad-morzem-stanie-rzezba-balti,nId,7584745)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T19:19:05+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-te-historie-znala-cala-polska-nad-morzem-stanie-rzezba-balti,nId,7584745"><img align="left" alt="Tę historię znała cała Polska. Nad morzem stanie rzeźba Baltica" src="https://i.iplsc.com/te-historie-znala-cala-polska-nad-morzem-stanie-rzezba-balti/000JCEQ6VQ5EO70C-C321.jpg" /></a>Na terenie nabrzeża Rybackiego w Gdyni powstanie pomnik słynnego psa Baltica. Ma to być upamiętnienie cudem uratowanego 14 lat temu zwierzaka, który dryfując na krze lodowej został uratowany przez załogę statku badawczego. </p><br clear="all" />

## Rosja zmienia strategię. Sprzęt przy granicy z NATO wycofany
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-zmienia-strategie-sprzet-przy-granicy-z-nato-wycofany,nId,7584729](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-zmienia-strategie-sprzet-przy-granicy-z-nato-wycofany,nId,7584729)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T18:58:10+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-zmienia-strategie-sprzet-przy-granicy-z-nato-wycofany,nId,7584729"><img align="left" alt="Rosja zmienia strategię. Sprzęt przy granicy z NATO wycofany" src="https://i.iplsc.com/rosja-zmienia-strategie-sprzet-przy-granicy-z-nato-wycofany/000JCEPUYWLD0YS5-C321.jpg" /></a>Rosyjskie bazy wojskowe przy granicy z Finlandią opustoszały. Stacjonujące tam dotychczas siły miały zostać przeniesione do Ukrainy - informuje fiński serwis yle.fi. Po wstąpieniu Helsinek do NATO wielokrotnie Moskwa zaznaczała swoją obecność w pobliżu nowej granicy z wojskowym paktem.</p><br clear="all" />

## "Znaczące konsekwencja dla świata". Moskwa coraz bliżej Pjongjangu
 - [https://wydarzenia.interia.pl/zagranica/news-znaczace-konsekwencja-dla-swiata-moskwa-coraz-blizej-pjongja,nId,7584716](https://wydarzenia.interia.pl/zagranica/news-znaczace-konsekwencja-dla-swiata-moskwa-coraz-blizej-pjongja,nId,7584716)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T18:45:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-znaczace-konsekwencja-dla-swiata-moskwa-coraz-blizej-pjongja,nId,7584716"><img align="left" alt="&quot;Znaczące konsekwencja dla świata&quot;. Moskwa coraz bliżej Pjongjangu" src="https://i.iplsc.com/znaczace-konsekwencja-dla-swiata-moskwa-coraz-blizej-pjongja/000JCEL4YDXK2LS7-C321.jpg" /></a>Wizyta Władimira Putina w Korei Północnej zakończyła się podpisaniem traktatu o partnerstwie strategicznym między Moskwą a Pjongjangiem. Dokument zawiera zapis o wzajemnej pomocy w &quot;walce z agresją&quot;. Zdaniem zachodnich mediów pogłębienie relacji między tymi państwami może mieć &quot;znaczące konsekwencje dla świata&quot;.</p><br clear="all" />

## Precyzyjna akcja USA. Ważny "cel" wyeliminowany
 - [https://wydarzenia.interia.pl/zagranica/news-precyzyjna-akcja-usa-wazny-cel-wyeliminowany,nId,7584748](https://wydarzenia.interia.pl/zagranica/news-precyzyjna-akcja-usa-wazny-cel-wyeliminowany,nId,7584748)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T18:37:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-precyzyjna-akcja-usa-wazny-cel-wyeliminowany,nId,7584748"><img align="left" alt="Precyzyjna akcja USA. Ważny &quot;cel&quot; wyeliminowany" src="https://i.iplsc.com/precyzyjna-akcja-usa-wazny-cel-wyeliminowany/000JCEQ90OG6LE95-C321.jpg" /></a>Usamah Jamal Muhammad Ibrahim al-Janabi, wysoki rangą urzędnik Państwa Islamskiego, zginął podczas nalotu w Syrii - przekazało Centralne Dowództwo USA.</p><br clear="all" />

## Spór w małopolskim PiS trwa. Radni podzieleni w głosowaniu nad marszałkiem
 - [https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-spor-w-malopolskim-pis-trwa-radni-podzieleni-w-glosowaniu-na,nId,7584738](https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-spor-w-malopolskim-pis-trwa-radni-podzieleni-w-glosowaniu-na,nId,7584738)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T18:09:21+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-spor-w-malopolskim-pis-trwa-radni-podzieleni-w-glosowaniu-na,nId,7584738"><img align="left" alt="Spór w małopolskim PiS trwa. Radni podzieleni w głosowaniu nad marszałkiem" src="https://i.iplsc.com/spor-w-malopolskim-pis-trwa-radni-podzieleni-w-glosowaniu-na/000JCEP02XNE36P0-C321.jpg" /></a>Małopolscy radni po raz kolejny nie wybrali Łukasza Kmity na marszałka województwa małopolskiego. Zaledwie kilkanaście godzin wcześniej w Krakowie pojawił się Jarosław Kaczyński. Prezes Prawa i Sprawiedliwości namawiał samorządowców do głosowania na posła i byłego wojewodę, jednak bezskutecznie. </p><br clear="all" />

## Policja publikuje wymowną grafikę. Czarna seria na drogach trwa
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-policja-publikuje-wymowna-grafike-czarna-seria-na-drogach-tr,nId,7584726](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-policja-publikuje-wymowna-grafike-czarna-seria-na-drogach-tr,nId,7584726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T17:59:49+00:00

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-policja-publikuje-wymowna-grafike-czarna-seria-na-drogach-tr,nId,7584726"><img align="left" alt="Policja publikuje wymowną grafikę. Czarna seria na drogach trwa" src="https://i.iplsc.com/policja-publikuje-wymowna-grafike-czarna-seria-na-drogach-tr/000GYVYL7558Q239-C321.jpg" /></a>Od początku roku na polskich drogach zginęło 102 motocyklistów, a w wypadkach 928 osób zostało rannych - przekazała w komunikacie Komenda Główna Policji. Tylko w ciągu ostatniego siedmiu dni tragiczne statystyki wzrosły. &quot;Dajcie się zauważyć!&quot; - apelują do fanów jednośladów policjanci. I zamieszczają wymowną grafikę.</p><br clear="all" />

## Policja publikuje wymowny nekrolog. Czarna seria na drogach trwa
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-policja-publikuje-wymowny-nekrolog-czarna-seria-na-drogach-t,nId,7584726](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-policja-publikuje-wymowny-nekrolog-czarna-seria-na-drogach-t,nId,7584726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T17:59:49+00:00

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-policja-publikuje-wymowny-nekrolog-czarna-seria-na-drogach-t,nId,7584726"><img align="left" alt="Policja publikuje wymowny nekrolog. Czarna seria na drogach trwa" src="https://i.iplsc.com/policja-publikuje-wymowny-nekrolog-czarna-seria-na-drogach-t/000JCELY8SDE0SYF-C321.jpg" /></a>Od początku roku na polskich drogach zginęło 102 motocyklistów, a w wypadkach 928 osób zostało rannych - przekazała w komunikacie Komenda Główna Policji. Tylko w ciągu ostatniego siedmiu dni tragiczne statystyki wzrosły. &quot;Dajcie się zauważyć!&quot; - apelują do fanów jednośladów policjanci. I zamieszczają wymowną grafikę.</p><br clear="all" />

## "Czuję się jak Prigożyn". Ukraiński wojskowy szczerze o werbowaniu więźniów
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-czuje-sie-jak-prigozyn-ukrainski-wojskowy-szczerze-o-werbowa,nId,7584707](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-czuje-sie-jak-prigozyn-ukrainski-wojskowy-szczerze-o-werbowa,nId,7584707)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T17:43:31+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-czuje-sie-jak-prigozyn-ukrainski-wojskowy-szczerze-o-werbowa,nId,7584707"><img align="left" alt="&quot;Czuję się jak Prigożyn&quot;. Ukraiński wojskowy szczerze o werbowaniu więźniów" src="https://i.iplsc.com/czuje-sie-jak-prigozyn-ukrainski-wojskowy-szczerze-o-werbowa/000JCEID6I3V7D97-C321.jpg" /></a>- Selekcja więźniów bardzo przypomina tę w Rosji. Jednak służba takich żołnierzy nie będzie miała nic wspólnego z rosyjską praktyką - powiedział Dmytro Kucharczuk. Ukraiński dowódca odpowiadający za mobilizację skazańców ujawnił przebieg procesu rekrutacji skazańców. - Czuję się trochę jak Prigożyn, ale rozmawiam z każdą osobą, przeprowadzam wywiad - tłumaczył w rozmowie z &quot;Ukraińską Prawdą&quot;.</p><br clear="all" />

## Drogowy pirat zatrzymany w Gdańsku. 32-latek miał sporo na sumieniu
 - [https://wydarzenia.interia.pl/news-drogowy-pirat-zatrzymany-w-gdansku-32-latek-mial-sporo-na-su,nId,7584702](https://wydarzenia.interia.pl/news-drogowy-pirat-zatrzymany-w-gdansku-32-latek-mial-sporo-na-su,nId,7584702)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T17:13:35+00:00

<p><a href="https://wydarzenia.interia.pl/news-drogowy-pirat-zatrzymany-w-gdansku-32-latek-mial-sporo-na-su,nId,7584702"><img align="left" alt="Drogowy pirat zatrzymany w Gdańsku. 32-latek miał sporo na sumieniu" src="https://i.iplsc.com/drogowy-pirat-zatrzymany-w-gdansku-32-latek-mial-sporo-na-su/000JCE86X9JWWVPY-C321.jpg" /></a>Chwile grozy przeżyli mieszkańcy Wrzeszcza, którzy byli świadkami policyjnego pościgu. Uciekający 32-latek nie zatrzymał się do rutynowej kontroli, jednak jego próba była daremna. Po zatrzymaniu na jaw wyszła przeszłość kierowcy. Teraz czekają go surowe konsekwencje - prosto z ulicy trafił do aresztu. </p><br clear="all" />

## Lawina komentarzy po decyzji TK. "Sędzia Pawłowicz nie ma prawa"
 - [https://wydarzenia.interia.pl/kraj/news-lawina-komentarzy-po-decyzji-tk-sedzia-pawlowicz-nie-ma-praw,nId,7584685](https://wydarzenia.interia.pl/kraj/news-lawina-komentarzy-po-decyzji-tk-sedzia-pawlowicz-nie-ma-praw,nId,7584685)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T16:54:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-lawina-komentarzy-po-decyzji-tk-sedzia-pawlowicz-nie-ma-praw,nId,7584685"><img align="left" alt="Lawina komentarzy po decyzji TK. &quot;Sędzia Pawłowicz nie ma prawa&quot;" src="https://i.iplsc.com/lawina-komentarzy-po-decyzji-tk-sedzia-pawlowicz-nie-ma-praw/000JCE9HEJHURCEX-C321.jpg" /></a>Według Trybunału Konstytucyjnego nowelizacja przyjęta przez Sejm podczas obrad, do których marszałek Sejmu nie dopuścił Mariusza Kamińskiego i Macieja Wąsika z PiS, jest niekonstytucyjna. Krótko po wydaniu decyzji w sieci pojawił się szereg komentarzy.</p><br clear="all" />

## Gwałtowne burze nad Polską. Powalone drzewa, pozalewane ulice i posesje
 - [https://wydarzenia.interia.pl/kraj/news-gwaltowne-burze-nad-polska-powalone-drzewa-pozalewane-ulice-,nId,7584525](https://wydarzenia.interia.pl/kraj/news-gwaltowne-burze-nad-polska-powalone-drzewa-pozalewane-ulice-,nId,7584525)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T16:42:25+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-gwaltowne-burze-nad-polska-powalone-drzewa-pozalewane-ulice-,nId,7584525"><img align="left" alt="Gwałtowne burze nad Polską. Powalone drzewa, pozalewane ulice i posesje" src="https://i.iplsc.com/gwaltowne-burze-nad-polska-powalone-drzewa-pozalewane-ulice/000JCEFCAAJWVR6M-C321.jpg" /></a>Przez całą Polskę przetaczają się burze. Strażacy interweniowali już kilkaset razy. Najwięcej zgłoszeń było w woj. mazowieckim, wielkopolskim i śląskim. Nawałnica, która przeszła na południowy wschód od Warszawy, przyniosła grad i ulewy w kilku powiatach. Przed godz. 18 IMGW wystosował kolejne ostrzeżenia. </p><br clear="all" />

## Mark Rutte nowym szefem NATO? "To odbędzie się kosztem Polski"
 - [https://wydarzenia.interia.pl/zagranica/news-mark-rutte-nowym-szefem-nato-to-odbedzie-sie-kosztem-polski,nId,7584379](https://wydarzenia.interia.pl/zagranica/news-mark-rutte-nowym-szefem-nato-to-odbedzie-sie-kosztem-polski,nId,7584379)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T16:28:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mark-rutte-nowym-szefem-nato-to-odbedzie-sie-kosztem-polski,nId,7584379"><img align="left" alt="Mark Rutte nowym szefem NATO? &quot;To odbędzie się kosztem Polski&quot;" src="https://i.iplsc.com/mark-rutte-nowym-szefem-nato-to-odbedzie-sie-kosztem-polski/000JCC567GN0295W-C321.jpg" /></a>- Mark Rutte jest ikoną polityki ustępstw wobec Rosji. To najgorszy wybór - mówi w rozmowie z Interią Witold Waszczykowski, komentując prawdopodobne objęcie fotela szefa NATO przez premiera Holandii. Paweł Jabłoński twierdzi z kolei, że od wybuchu wojny na Ukrainie Rutte jest racjonalnym przywódcą, jednak ma &quot;niechlubną kartę konszachtów z Rosjanami&quot;. Obawy tonują natomiast Bronisław Komorowski i dr Małgorzata Bonikowska. - Absolutnie nie ma się czego obawiać - wskazuje były prezydent. - To bardzo dobry wybór - podkreśla ekspertka.</p><br clear="all" />

## Spór po decyzji prezydenta Warszawy. RPO: Nie narusza wolności
 - [https://wydarzenia.interia.pl/kraj/news-spor-po-decyzji-prezydenta-warszawy-rpo-nie-narusza-wolnosci,nId,7584522](https://wydarzenia.interia.pl/kraj/news-spor-po-decyzji-prezydenta-warszawy-rpo-nie-narusza-wolnosci,nId,7584522)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T16:20:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-spor-po-decyzji-prezydenta-warszawy-rpo-nie-narusza-wolnosci,nId,7584522"><img align="left" alt="Spór po decyzji prezydenta Warszawy. RPO: Nie narusza wolności" src="https://i.iplsc.com/spor-po-decyzji-prezydenta-warszawy-rpo-nie-narusza-wolnosci/000JCDXQ7Y9FDM03-C321.jpg" /></a>Brak symboli religijnych w warszawskich urzędach nie narusza wolności sumienia i wyznania - ocenił Rzecznik Praw Obywatelskich. Prośbę o interwencję prof. Marcina Wiącka złożył Sebastian Kaleta. Według polityka Suwerennej Polski ostania decyzja Rafała Trzaskowskiego miała naruszać konstytucję gwarantującą wolność religijną. </p><br clear="all" />

## Masowe zatrucie w ośrodku wczasowym. Powodem znana bakteria
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-masowe-zatrucie-w-osrodku-wczasowym-powodem-znana-bakteria,nId,7584512](https://wydarzenia.interia.pl/zachodniopomorskie/news-masowe-zatrucie-w-osrodku-wczasowym-powodem-znana-bakteria,nId,7584512)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T15:30:05+00:00

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-masowe-zatrucie-w-osrodku-wczasowym-powodem-znana-bakteria,nId,7584512"><img align="left" alt="Masowe zatrucie w ośrodku wczasowym. Powodem znana bakteria" src="https://i.iplsc.com/masowe-zatrucie-w-osrodku-wczasowym-powodem-znana-bakteria/000HHZC8YE6NQRO5-C321.jpg" /></a>Do masowego zatrucia pokarmowego doszło w ośrodku wczasowym w Pogorzelicy (woj. zachodniopomorskie). W środę szczeciński sanepid podał, że powodem była salmonella. W sumie zachorowało ponad sto osób, z czego kilka trafiło do szpitala. </p><br clear="all" />

## Były Rzecznik Praw Dziecka w nowej roli. Mikołaj Pawlak będzie orzekał
 - [https://wydarzenia.interia.pl/kraj/news-byly-rzecznik-praw-dziecka-w-nowej-roli-mikolaj-pawlak-bedzi,nId,7584499](https://wydarzenia.interia.pl/kraj/news-byly-rzecznik-praw-dziecka-w-nowej-roli-mikolaj-pawlak-bedzi,nId,7584499)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T15:11:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-byly-rzecznik-praw-dziecka-w-nowej-roli-mikolaj-pawlak-bedzi,nId,7584499"><img align="left" alt="Były Rzecznik Praw Dziecka w nowej roli. Mikołaj Pawlak będzie orzekał" src="https://i.iplsc.com/byly-rzecznik-praw-dziecka-w-nowej-roli-mikolaj-pawlak-bedzi/000JCDGQRBBKY72R-C321.jpg" /></a>Mikołaj Pawlak dostał akt powołania na stanowisko sędziego. Były Rzecznik Praw Dziecka wraz z innymi powołanymi złożył ślubowanie przed prezydentem Andrzejem Dudą. Prawnik ma orzekać w Skierniewicach (woj. łódzkie).</p><br clear="all" />

## Mikołaj Pawlak z nową funkcją. Decyzja Andrzeja Dudy
 - [https://wydarzenia.interia.pl/kraj/news-mikolaj-pawlak-z-nowa-funkcja-decyzja-andrzeja-dudy,nId,7584499](https://wydarzenia.interia.pl/kraj/news-mikolaj-pawlak-z-nowa-funkcja-decyzja-andrzeja-dudy,nId,7584499)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T15:11:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mikolaj-pawlak-z-nowa-funkcja-decyzja-andrzeja-dudy,nId,7584499"><img align="left" alt="Mikołaj Pawlak z nową funkcją. Decyzja Andrzeja Dudy" src="https://i.iplsc.com/mikolaj-pawlak-z-nowa-funkcja-decyzja-andrzeja-dudy/000JCDGQRBBKY72R-C321.jpg" /></a>Mikołaj Pawlak dostał akt powołania na stanowisko sędziego. Były Rzecznik Praw Dziecka wraz z innymi powołanymi złożył ślubowanie przed prezydentem Andrzejem Dudą. Prawnik ma orzekać w Skierniewicach (woj. łódzkie).</p><br clear="all" />

## Zatrzymanie żołnierzy na granicy. Prokuratura z nową decyzją
 - [https://wydarzenia.interia.pl/kraj/news-zatrzymanie-zolnierzy-na-granicy-prokuratura-z-nowa-decyzja,nId,7584493](https://wydarzenia.interia.pl/kraj/news-zatrzymanie-zolnierzy-na-granicy-prokuratura-z-nowa-decyzja,nId,7584493)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T14:44:55+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zatrzymanie-zolnierzy-na-granicy-prokuratura-z-nowa-decyzja,nId,7584493"><img align="left" alt="Zatrzymanie żołnierzy na granicy. Prokuratura z nową decyzją" src="https://i.iplsc.com/zatrzymanie-zolnierzy-na-granicy-prokuratura-z-nowa-decyzja/000JCDETLAOLY06T-C321.jpg" /></a>- Prokuratura uchyliła dwa z trzech środków zapobiegawczych wobec żołnierzy, którzy zostali zatrzymani na granicy z Białorusią za złamanie procedur posługiwania się bronią - potwierdziła Interii rzeczniczka Prokuratora Generalnego Anna Adamiak.</p><br clear="all" />

## Ekspert wskazuje na czarny scenariusz. "Wybiją zęby polityce Macrona"
 - [https://wydarzenia.interia.pl/zagranica/news-ekspert-wskazuje-na-czarny-scenariusz-wybija-zeby-polityce-m,nId,7584340](https://wydarzenia.interia.pl/zagranica/news-ekspert-wskazuje-na-czarny-scenariusz-wybija-zeby-polityce-m,nId,7584340)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T14:22:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ekspert-wskazuje-na-czarny-scenariusz-wybija-zeby-polityce-m,nId,7584340"><img align="left" alt="Ekspert wskazuje na czarny scenariusz. &quot;Wybiją zęby polityce Macrona&quot;" src="https://i.iplsc.com/ekspert-wskazuje-na-czarny-scenariusz-wybija-zeby-polityce-m/000JCBMD3TX9HNS0-C321.jpg" /></a>Francja jest na rozdrożu, a już wkrótce może dojść do nowych wstrząsów. - Porażka obozu prezydenta w wyborach parlamentarnych oznacza wybicie zębów nowej polityce Emmanuela Macrona ws. Ukrainy i Rosji - podkreśla dr Witold Sokała. - Może to być groźne dla sojuszników z UE i NATO - dodaje. Powodem jest możliwość przejęcia władzy przez skrajną prawicę lub lewicę. Realizacji czarnego scenariusza sprzyjają społeczne nastroje. Obóz Macrona w sondażach jest dopiero trzeci, ale Pałac Elizejski nie składa broni i liczy na nowe rozdanie tuż po wyborach.</p><br clear="all" />

## Służby z szerszym dostępem do użycia broni. "Projekt dedykuję SOP"
 - [https://wydarzenia.interia.pl/kraj/news-sluzby-z-szerszym-dostepem-do-uzycia-broni-projekt-dedykuje-,nId,7584470](https://wydarzenia.interia.pl/kraj/news-sluzby-z-szerszym-dostepem-do-uzycia-broni-projekt-dedykuje-,nId,7584470)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T14:11:10+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sluzby-z-szerszym-dostepem-do-uzycia-broni-projekt-dedykuje-,nId,7584470"><img align="left" alt="Służby z szerszym dostępem do użycia broni. &quot;Projekt dedykuję SOP&quot;" src="https://i.iplsc.com/sluzby-z-szerszym-dostepem-do-uzycia-broni-projekt-dedykuje/000JCD6EPXMBQSQE-C321.jpg" /></a>- Chciałbym zadedykować wam dzisiejszy projekt, jaki przyjęliśmy w rządzie, który pozwoli skutecznie chronić polską granicę i polskie państwo przed aktami agresji - powiedział premier Donald Tusk do funkcjonariuszy podczas obchodów 100-lecia Służby Ochrony Państwa. Mowa o projekcie zmian przepisów regulujących zasady użycia broni przez służby mundurowe.</p><br clear="all" />

## Brytyjski symbol zdewastowany. Dwoje aktywistów zatrzymanych
 - [https://wydarzenia.interia.pl/zagranica/news-brytyjski-symbol-zdewastowany-dwoje-aktywistow-zatrzymanych,nId,7584389](https://wydarzenia.interia.pl/zagranica/news-brytyjski-symbol-zdewastowany-dwoje-aktywistow-zatrzymanych,nId,7584389)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T13:34:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-brytyjski-symbol-zdewastowany-dwoje-aktywistow-zatrzymanych,nId,7584389"><img align="left" alt="Brytyjski symbol zdewastowany. Dwoje aktywistów zatrzymanych" src="https://i.iplsc.com/brytyjski-symbol-zdewastowany-dwoje-aktywistow-zatrzymanych/000JCC1A7RB73U1L-C321.jpg" /></a>Protestujący rozpylili farbę proszkową na słynną kamienną budowlę Stonehenge. Aktywiści ubrali byli w koszulki &quot;Just Stop Oil &quot;- organizacji, która usiłuje skłonić brytyjski rząd do wstrzymania produkcji i zużycia paliw kopalnych. Służby zatrzymały dwie osoby w związku z incydentem. </p><br clear="all" />

## Daniel Obajtek w Polsce. Stawił się w prokuraturze
 - [https://wydarzenia.interia.pl/kraj/news-daniel-obajtek-w-polsce-stawil-sie-w-prokuraturze,nId,7584418](https://wydarzenia.interia.pl/kraj/news-daniel-obajtek-w-polsce-stawil-sie-w-prokuraturze,nId,7584418)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T13:25:45+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-daniel-obajtek-w-polsce-stawil-sie-w-prokuraturze,nId,7584418"><img align="left" alt="Daniel Obajtek w Polsce. Stawił się w prokuraturze" src="https://i.iplsc.com/daniel-obajtek-w-polsce-stawil-sie-w-prokuraturze/000GDJY4YCVFG1QO-C321.jpg" /></a>Daniel Obajtek stawił się w środę w Prokuraturze Okręgowej w Warszawie. Były prezes Orlenu został przesłuchany w charakterze świadka - potwierdził rzecznik Prokuratury Okręgowej w Warszawie prok. Piotr Skiba.</p><br clear="all" />

## Prezes PiS ze sprayem przed pomnikiem smoleńskim. Policja reaguje na incydent
 - [https://wydarzenia.interia.pl/kraj/news-prezes-pis-ze-sprayem-przed-pomnikiem-smolenskim-policja-rea,nId,7584369](https://wydarzenia.interia.pl/kraj/news-prezes-pis-ze-sprayem-przed-pomnikiem-smolenskim-policja-rea,nId,7584369)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T13:14:52+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezes-pis-ze-sprayem-przed-pomnikiem-smolenskim-policja-rea,nId,7584369"><img align="left" alt="Prezes PiS ze sprayem przed pomnikiem smoleńskim. Policja reaguje na incydent" src="https://i.iplsc.com/prezes-pis-ze-sprayem-przed-pomnikiem-smolenskim-policja-rea/000JCBTPG7LE8Y75-C321.jpg" /></a>Stołeczna policja miała wystąpić do prokuratury z wnioskiem o wszczęcie śledztwa w kierunku nadużycia władzy przez Jarosława Kaczyńskiego. To pokłosie &quot;interwencji poselskiej&quot; prezesa PiS z 10 czerwca, kiedy to wdał się w scysję z policjantami, a także zamalował sprayem tablicę na jednym z wieńców złożonych przed pomnikiem smoleńskim.</p><br clear="all" />

## Gwałtowne burze na Mazowszu i nie tylko. Z nieba lecą tony wody
 - [https://wydarzenia.interia.pl/kraj/news-gwaltowne-burze-na-mazowszu-i-nie-tylko-z-nieba-leca-tony-wo,nId,7584364](https://wydarzenia.interia.pl/kraj/news-gwaltowne-burze-na-mazowszu-i-nie-tylko-z-nieba-leca-tony-wo,nId,7584364)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T13:08:10+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-gwaltowne-burze-na-mazowszu-i-nie-tylko-z-nieba-leca-tony-wo,nId,7584364"><img align="left" alt="Gwałtowne burze na Mazowszu i nie tylko. Z nieba lecą tony wody" src="https://i.iplsc.com/gwaltowne-burze-na-mazowszu-i-nie-tylko-z-nieba-leca-tony-wo/000JCC1EUVWUMKWX-C321.jpg" /></a>Potężne burze formują się w centrum i na południu Polski. Nawałnice zbliżają się do Warszawy. W mediach społecznościowych pojawiają się pierwsze nagrania żywiołu. Miejscami może padać grad o średnicy kilku centymetrów. Wieje też bardzo silny wiatr. Sprawdź, gdzie jest burza i jakie niesie zagrożenia.</p><br clear="all" />

## Jak zdążyć z wnioskiem o 800 plus i Dobry Start? Jedna metoda wygrywa
 - [https://wydarzenia.interia.pl/news-jak-zdazyc-z-wnioskiem-o-800-plus-i-dobry-start-jedna-metoda,nId,7582022](https://wydarzenia.interia.pl/news-jak-zdazyc-z-wnioskiem-o-800-plus-i-dobry-start-jedna-metoda,nId,7582022)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T13:06:31+00:00

<p><a href="https://wydarzenia.interia.pl/news-jak-zdazyc-z-wnioskiem-o-800-plus-i-dobry-start-jedna-metoda,nId,7582022"><img align="left" alt="Jak zdążyć z wnioskiem o 800 plus i Dobry Start? Jedna metoda wygrywa" src="https://i.iplsc.com/jak-zdazyc-z-wnioskiem-o-800-plus-i-dobry-start-jedna-metoda/000IZ7GN8NNCOF6I-C321.jpg" /></a>Coraz bliżej ważne terminy składania wniosków do ZUS. By nie stracić pieniędzy, do końca czerwca trzeba złożyć wniosek o 800 plus na nowy okres rozliczeniowy, a od 1 lipca można składać wnioski w programie Dobry Start, by uzyskać 300 zł wyprawki szkolnej. Najszybsza metoda to aplikacja mZUS, która pomoże w wypełnianiu wniosków oraz zapewni szybki dostęp do informacji o złożonych dokumentach i ich statusie. Kto może korzystać z aplikacji mZUS, jak ją zainstalować i jak używać? Wyjaśniamy.</p><br clear="all" />

## Halina Bortnowska nie żyje. Współzałożycielka HFPC miała 92 lata
 - [https://wydarzenia.interia.pl/kraj/news-halina-bortnowska-nie-zyje-wspolzalozycielka-hfpc-miala-92-l,nId,7584362](https://wydarzenia.interia.pl/kraj/news-halina-bortnowska-nie-zyje-wspolzalozycielka-hfpc-miala-92-l,nId,7584362)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T12:56:04+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-halina-bortnowska-nie-zyje-wspolzalozycielka-hfpc-miala-92-l,nId,7584362"><img align="left" alt="Halina Bortnowska nie żyje. Współzałożycielka HFPC miała 92 lata" src="https://i.iplsc.com/halina-bortnowska-nie-zyje-wspolzalozycielka-hfpc-miala-92-l/000JCBTIBT8MHMND-C321.jpg" /></a>Halina Bortnowska - ceniona filozofka, publicystka i teolożka - zmarła w środę nad ranem. Publikowała na łamach m.in. &quot;Gazety Wyborczej&quot; i &quot;Znaku&quot;, była uważana za jedną z najwybitniejszych publicystek &quot;Tygodnika Powszechnego&quot;. &quot;Dzielny, jasny człowiek, wielkiej odwagi, pełna troski i myśli o innych&quot; - skomentowała w sieci aktorka Maja Komorowska. </p><br clear="all" />

## Janusz Kowalski odchodzi z partii. Jakie ma plany?
 - [https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-odchodzi-z-partii-jakie-ma-plany,nId,7584158](https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-odchodzi-z-partii-jakie-ma-plany,nId,7584158)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T12:26:54+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-odchodzi-z-partii-jakie-ma-plany,nId,7584158"><img align="left" alt="Janusz Kowalski odchodzi z partii. Jakie ma plany?" src="https://i.iplsc.com/janusz-kowalski-odchodzi-z-partii-jakie-ma-plany/000JC8Y8O82O71JM-C321.jpg" /></a>Janusz Kowalski, poseł Suwerennej Polski poinformował, że odchodzi z partii. - Na dezintegrację i kłótnie w ramach Koalicji 13 grudnia Zjednoczona Prawica powinna odpowiedzieć jednością i wspólną pracą - komentuje w rozmowie z Interią Janusz Kowalski.   </p><br clear="all" />

## Awantura w Trybunale Konstytucyjnym. "Nie dałam zgody, pan nie może wyjść"
 - [https://wydarzenia.interia.pl/kraj/news-awantura-w-trybunale-konstytucyjnym-nie-dalam-zgody-pan-nie-,nId,7584269](https://wydarzenia.interia.pl/kraj/news-awantura-w-trybunale-konstytucyjnym-nie-dalam-zgody-pan-nie-,nId,7584269)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T11:43:24+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-awantura-w-trybunale-konstytucyjnym-nie-dalam-zgody-pan-nie-,nId,7584269"><img align="left" alt="Awantura w Trybunale Konstytucyjnym. &quot;Nie dałam zgody, pan nie może wyjść&quot;" src="https://i.iplsc.com/awantura-w-trybunale-konstytucyjnym-nie-dalam-zgody-pan-nie/000JCA6LYAJTJBXT-C321.jpg" /></a>Szef Kancelarii Sejmu Jacek Cichocki oraz komendant Straży Marszałkowskiej Michał Sadoń nie stawili się na środowej rozprawie w Trybunale Konstytucyjnym - poinformowała przewodnicząca składu sędziowskiego w TK Krystyna Pawłowicz. Zachowanie świadków oceniła &quot;skandalicznym postępowaniem&quot;, które uniemożliwia dalsze postępowanie przed TK. Mimo ostrzeżeń Pawłowicz, salę sądową postanowił opuścić także poseł Paweł Śliz. Później gremium zdecydowało w sprawie przepisów o NCBR. TK uznał, że są niezgodne z konstytucją.</p><br clear="all" />

## Przestrzegają przed trąbami powietrznymi. "Uważajcie dziś na siebie!"
 - [https://wydarzenia.interia.pl/kraj/news-przestrzegaja-przed-trabami-powietrznymi-uwazajcie-dzis-na-s,nId,7584280](https://wydarzenia.interia.pl/kraj/news-przestrzegaja-przed-trabami-powietrznymi-uwazajcie-dzis-na-s,nId,7584280)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T11:39:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-przestrzegaja-przed-trabami-powietrznymi-uwazajcie-dzis-na-s,nId,7584280"><img align="left" alt="Przestrzegają przed trąbami powietrznymi. &quot;Uważajcie dziś na siebie!&quot;" src="https://i.iplsc.com/przestrzegaja-przed-trabami-powietrznymi-uwazajcie-dzis-na-s/000JCAF8MWNL072P-C321.jpg" /></a>Pogoda w najbliższych godzinach zrobi się niezwykle niebezpieczna. Sieć Obserwatorów Burz wystosowała swój najwyższy stopień zagrożenia. Ostrzega przed bardzo silnymi burzami, ulewami i gradem o kilkucentymetrowej średnicy. Nie wyklucza też pojawienia się trąb powietrznych. Podobne alerty wystosowali też Polscy Łowcy Burz.</p><br clear="all" />

## Putin wszedł w tłum. Chwilę później interweniowała ochrona
 - [https://wydarzenia.interia.pl/zagranica/news-putin-wszedl-w-tlum-chwile-pozniej-interweniowala-ochrona,nId,7584252](https://wydarzenia.interia.pl/zagranica/news-putin-wszedl-w-tlum-chwile-pozniej-interweniowala-ochrona,nId,7584252)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T11:32:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-putin-wszedl-w-tlum-chwile-pozniej-interweniowala-ochrona,nId,7584252"><img align="left" alt="Putin wszedł w tłum. Chwilę później interweniowała ochrona" src="https://i.iplsc.com/putin-wszedl-w-tlum-chwile-pozniej-interweniowala-ochrona/000JC9NK1M5RGYHL-C321.jpg" /></a>Władimir Putin wchodzi w tłum mieszkańców Jakucji, wyciąga do ludzi rękę, a następnie nie może jej wyswobodzić - właśnie to widzimy na nagraniu, które obiegło sieć. Wszystko przez mężczyznę, który złapał dyktatora za dłoń i nie chciał jej puścić. Interweniować musiała ochrona. Zaraz potem zaskoczony Putin pośpiesznie oddalił się od zgromadzonych.</p><br clear="all" />

## Byli prezydenci Polski ofiarami rosyjskich służb. Do sieci trafiły nagrania
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-byli-prezydenci-polski-ofiarami-rosyjskich-sluzb-do-sieci-tr,nId,7584249](https://wydarzenia.interia.pl/tylko-w-interii/news-byli-prezydenci-polski-ofiarami-rosyjskich-sluzb-do-sieci-tr,nId,7584249)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T11:20:11+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-byli-prezydenci-polski-ofiarami-rosyjskich-sluzb-do-sieci-tr,nId,7584249"><img align="left" alt="Byli prezydenci Polski ofiarami rosyjskich służb. Do sieci trafiły nagrania" src="https://i.iplsc.com/byli-prezydenci-polski-ofiarami-rosyjskich-sluzb-do-sieci-tr/000JCBDOTJBVK67G-C321.jpg" /></a>Rosyjscy pranksterzy opublikowali w środę dwa nagrania, na których rzekomo rozmawiają z byłymi prezydentami Polski Bronisławem Komorowskim i Aleksandrem Kwaśniewskim. Sugerują, że udało im się &quot;wkręcić&quot; polskich polityków, udając Petra Poroszenkę. W rozmowach poruszali tematy bezpieczeństwa. Jak udało nam się ustalić, sprawa nie ma nic wspólnego z niewinnym żartem. To prawdopodobnie operacja rosyjskich służb.</p><br clear="all" />

## Rośnie napięcie na Kaukazie. Komunikat MSZ Armenii o "nowej agresji"
 - [https://wydarzenia.interia.pl/zagranica/news-rosnie-napiecie-na-kaukazie-komunikat-msz-armenii-o-nowej-ag,nId,7584237](https://wydarzenia.interia.pl/zagranica/news-rosnie-napiecie-na-kaukazie-komunikat-msz-armenii-o-nowej-ag,nId,7584237)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T11:15:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosnie-napiecie-na-kaukazie-komunikat-msz-armenii-o-nowej-ag,nId,7584237"><img align="left" alt="Rośnie napięcie na Kaukazie. Komunikat MSZ Armenii o &quot;nowej agresji&quot;" src="https://i.iplsc.com/rosnie-napiecie-na-kaukazie-komunikat-msz-armenii-o-nowej-ag/000JC9N9641WGJB0-C321.jpg" /></a>&quot;Azerbejdżan zrobi wszystko, aby storpedować proces pokojowy&quot; - czytamy w komunikacie wydanym przez Ministerstwo Spraw Zagranicznych Armenii. Przedstawiciele departamentu są przekonani, że rząd w Baku planuje nowe działania wojskowe, które rozpoczną się w przeciągu kilku miesięcy.</p><br clear="all" />

## W tych szkołach uczą na przyszłych influencerów. "Innowacja"
 - [https://wydarzenia.interia.pl/kraj/news-w-tych-szkolach-ucza-na-przyszlych-influencerow-innowacja,nId,7582092](https://wydarzenia.interia.pl/kraj/news-w-tych-szkolach-ucza-na-przyszlych-influencerow-innowacja,nId,7582092)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T10:47:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-w-tych-szkolach-ucza-na-przyszlych-influencerow-innowacja,nId,7582092"><img align="left" alt="W tych szkołach uczą na przyszłych influencerów. &quot;Innowacja&quot;" src="https://i.iplsc.com/w-tych-szkolach-ucza-na-przyszlych-influencerow-innowacja/000JC7RTNDYQRO3C-C321.jpg" /></a>Profil vlogerski, vlogersko-teatralny, a może influencersko-psychologiczny? Do takich klas rekrutują właśnie przyszli licealiści w całej Polsce. Jak słyszymy, profile te cieszą się dużym zainteresowaniem. - Rodzice dzwonią i pytają, czy rekrutacja jest otwarta - mówi Interii nauczycielka i opiekunka kierunku vlogersko-medialnego z Włocławka. Nie ukrywa, że uczniowie tego profilu aspirują do tego, aby w przyszłości wykonywać zawód influencera.</p><br clear="all" />

## Ministerialny program hitem. Po 12 minutach wyczerpano pulę
 - [https://wydarzenia.interia.pl/kraj/news-ministerialny-program-hitem-po-12-minutach-wyczerpano-pule,nId,7584194](https://wydarzenia.interia.pl/kraj/news-ministerialny-program-hitem-po-12-minutach-wyczerpano-pule,nId,7584194)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T10:30:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ministerialny-program-hitem-po-12-minutach-wyczerpano-pule,nId,7584194"><img align="left" alt="Ministerialny program hitem. Po 12 minutach wyczerpano pulę" src="https://i.iplsc.com/ministerialny-program-hitem-po-12-minutach-wyczerpano-pule/000JC9C83V50OEXL-C321.jpg" /></a>Ministerstwo Edukacji Narodowej poinformowało o wyczerpaniu puli dostępnych środków na dofinansowanie wycieczek szkolnych. Nabór wniosków w ramach projektu &quot;Podróże z klasą&quot; cieszył się wielkim zainteresowaniem. Po zaledwie 12 minutach wyczerpano pulę środków poświęconych na cel. </p><br clear="all" />

## Pierwsza taka noc w 2024 roku. Można się było poczuć jak w tropikach
 - [https://wydarzenia.interia.pl/kraj/news-pierwsza-taka-noc-w-2024-roku-mozna-sie-bylo-poczuc-jak-w-tr,nId,7584223](https://wydarzenia.interia.pl/kraj/news-pierwsza-taka-noc-w-2024-roku-mozna-sie-bylo-poczuc-jak-w-tr,nId,7584223)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T10:29:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pierwsza-taka-noc-w-2024-roku-mozna-sie-bylo-poczuc-jak-w-tr,nId,7584223"><img align="left" alt="Pierwsza taka noc w 2024 roku. Można się było poczuć jak w tropikach" src="https://i.iplsc.com/pierwsza-taka-noc-w-2024-roku-mozna-sie-bylo-poczuc-jak-w-tr/000JC9AY4H1RSQ93-C321.jpg" /></a>&quot;Za nami pierwsza noc tropikalna w 2024 roku&quot; - ogłosili synoptycy z IMGW. W jednej z małopolskich miejscowości temperatura przekroczyła 21 stopni Celsjusza. Kolejne noce również będą ciepłe, jednak na tropikalne trzeba będzie jeszcze trochę poczekać.</p><br clear="all" />

## Prezydencki minister ocenił działania Donalda Tuska. "Polityczny geniusz"
 - [https://wydarzenia.interia.pl/kraj/news-prezydencki-minister-ocenil-dzialania-donalda-tuska-politycz,nId,7584012](https://wydarzenia.interia.pl/kraj/news-prezydencki-minister-ocenil-dzialania-donalda-tuska-politycz,nId,7584012)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T09:57:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydencki-minister-ocenil-dzialania-donalda-tuska-politycz,nId,7584012"><img align="left" alt="Prezydencki minister ocenił działania Donalda Tuska. &quot;Polityczny geniusz&quot;" src="https://i.iplsc.com/prezydencki-minister-ocenil-dzialania-donalda-tuska-politycz/000JC83OO3CHEKMH-C321.jpg" /></a>- Przecież to jest geniusz polityczny. Nie ma tak sprawnego człowieka, który tak manipuluje - ocenił ruchy Donalda Tuska przed wyborami do PE prezydencki minister. Marcin Mastalerek dodał też, że &quot;Jarosław Kaczyński nie jest w stanie zrobić tego na takim poziomie&quot;. W rozmowie skomentował również sytuację w PiS i poszukiwania kandydata na prezydent RP z ramienia tej partii.</p><br clear="all" />

## "Przegrywamy tę wojnę". Ukraiński dowódca o fatalnej sytuacji na froncie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-przegrywamy-te-wojne-ukrainski-dowodca-o-fatalnej-sytuacji-n,nId,7584142](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-przegrywamy-te-wojne-ukrainski-dowodca-o-fatalnej-sytuacji-n,nId,7584142)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T09:25:22+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-przegrywamy-te-wojne-ukrainski-dowodca-o-fatalnej-sytuacji-n,nId,7584142"><img align="left" alt="&quot;Przegrywamy tę wojnę&quot;. Ukraiński dowódca o fatalnej sytuacji na froncie" src="https://i.iplsc.com/przegrywamy-te-wojne-ukrainski-dowodca-o-fatalnej-sytuacji-n/000JC8QA30QQJFIC-C321.jpg" /></a>- Tak, teraz przegrywamy tę wojnę. To oczywiste. Tracimy terytoria, tracimy najlepszych ludzi - twierdzi Dmytro Kukcharczuk. Dowódca ukraińskiego II Batalionu 3. Brygady Szturmowej przedstawił fatalne prognozy dla Sił Zbrojnych Ukrainy w obronie przed rosyjską inwazją i krytycznie odniósł się do postawy ukraińskiego społeczeństwa.</p><br clear="all" />

## Alert RCB dla kilkunastu województw. "Zabezpiecz rzeczy"
 - [https://wydarzenia.interia.pl/kraj/news-alert-rcb-dla-kilkunastu-wojewodztw-zabezpiecz-rzeczy,nId,7584151](https://wydarzenia.interia.pl/kraj/news-alert-rcb-dla-kilkunastu-wojewodztw-zabezpiecz-rzeczy,nId,7584151)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T09:25:08+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-alert-rcb-dla-kilkunastu-wojewodztw-zabezpiecz-rzeczy,nId,7584151"><img align="left" alt="Alert RCB dla kilkunastu województw. &quot;Zabezpiecz rzeczy&quot;" src="https://i.iplsc.com/alert-rcb-dla-kilkunastu-wojewodztw-zabezpiecz-rzeczy/000JC8XJP7VSFRKL-C321.jpg" /></a>Burzowa strefa rozwinie się w Polsce. Oprócz ulewnego deszczu i gradu możliwe będą wichury wiejące nawet do 110 km/h. Państwowe służby wydały alert RCB dla 11 województw. Sprawdź, gdzie trzeba będzie zachować szczególną ostrożność.</p><br clear="all" />

## Izraelska armia uderzy na Liban? Zatwierdzono plan inwazji
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-izraelska-armia-uderzy-na-liban-zatwierdzono-plan-inwazji,nId,7584069](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-izraelska-armia-uderzy-na-liban-zatwierdzono-plan-inwazji,nId,7584069)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T09:19:19+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-izraelska-armia-uderzy-na-liban-zatwierdzono-plan-inwazji,nId,7584069"><img align="left" alt="Izraelska armia uderzy na Liban? Zatwierdzono plan inwazji" src="https://i.iplsc.com/izraelska-armia-uderzy-na-liban-zatwierdzono-plan-inwazji/000JC8F6U3V52V8I-C321.jpg" /></a>&quot;W ramach oceny sytuacyjnej zatwierdzono plany operacyjne ofensywy w Libanie oraz podjęto decyzje o kontynuacji zwiększania gotowości wojsk w terenie&quot; - poinformowały Siły Obronne Izraela. Jak zapowiedziano, będzie to kontynuacja &quot;walk na Arenie Północnej&quot; prowadzonych przez izraelskie wojsko.</p><br clear="all" />

## "Rosja w Polsce nic nie musi organizować". Tusk reaguje na głośny materiał
 - [https://wydarzenia.interia.pl/kraj/news-rosja-w-polsce-nic-nie-musi-organizowac-tusk-reaguje-na-glos,nId,7584077](https://wydarzenia.interia.pl/kraj/news-rosja-w-polsce-nic-nie-musi-organizowac-tusk-reaguje-na-glos,nId,7584077)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T09:15:41+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rosja-w-polsce-nic-nie-musi-organizowac-tusk-reaguje-na-glos,nId,7584077"><img align="left" alt="&quot;Rosja w Polsce nic nie musi organizować&quot;. Tusk reaguje na głośny materiał" src="https://i.iplsc.com/rosja-w-polsce-nic-nie-musi-organizowac-tusk-reaguje-na-glos/000JC8F2QA768MJT-C321.jpg" /></a>&quot;Rosja organizuje i finansuje w wielu państwach Europy kampanię nienawiści i strachu&quot; - napisał premier Donald Tusk, reagując na wtorkowy głośny spot PiS. Szef rządu ocenił, że w Polsce Moskwa nie musi niczego organizować. &quot;Jest PiS&quot; - skwitował.</p><br clear="all" />

## Zaginiona 39-letnia Natalia nie żyje. Zatrzymano męża kobiety
 - [https://wydarzenia.interia.pl/wielkopolskie/news-zaginiona-39-letnia-natalia-nie-zyje-zatrzymano-meza-kobiety,nId,7584146](https://wydarzenia.interia.pl/wielkopolskie/news-zaginiona-39-letnia-natalia-nie-zyje-zatrzymano-meza-kobiety,nId,7584146)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T08:59:35+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-zaginiona-39-letnia-natalia-nie-zyje-zatrzymano-meza-kobiety,nId,7584146"><img align="left" alt="Zaginiona 39-letnia Natalia nie żyje. Zatrzymano męża kobiety" src="https://i.iplsc.com/zaginiona-39-letnia-natalia-nie-zyje-zatrzymano-meza-kobiety/000FZ899M2IC99HN-C321.jpg" /></a>Zaginiona Natalia Panocha-Raczkiewicz nie żyje - poinformował Interię rzecznik prasowy Komendanta Wojewódzkiego Policji w Poznaniu mł. insp. Andrzej Borowiak. W sprawie policjanci zatrzymali męża 39-latki. Poszukiwania kobiety trwały od piątku.</p><br clear="all" />

## Policyjny pościg za migrantami. Zatrzymano ich w stawie
 - [https://wydarzenia.interia.pl/kraj/news-policyjny-poscig-za-migrantami-zatrzymano-ich-w-stawie,nId,7584058](https://wydarzenia.interia.pl/kraj/news-policyjny-poscig-za-migrantami-zatrzymano-ich-w-stawie,nId,7584058)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T08:21:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-policyjny-poscig-za-migrantami-zatrzymano-ich-w-stawie,nId,7584058"><img align="left" alt="Policyjny pościg za migrantami. Zatrzymano ich w stawie" src="https://i.iplsc.com/policyjny-poscig-za-migrantami-zatrzymano-ich-w-stawie/000JC8KF2SV2LUJ4-C321.jpg" /></a>Czterech nielegalnych migrantów z Jemenu, Syrii oraz Afganistanu nie zatrzymało się do rutynowej kontroli drogowej. Policjanci ruszyli za nimi w pościg. Mężczyźni postanowili ukryć się po szyję w stawie. Zlokalizowano ich za pomocą drona. </p><br clear="all" />

## Regulacje w sprawie użycia broni na granicy. "Wykreślono jedną przesłankę"
 - [https://wydarzenia.interia.pl/kraj/news-regulacje-w-sprawie-uzycia-broni-na-granicy-wykreslono-jedna,nId,7584038](https://wydarzenia.interia.pl/kraj/news-regulacje-w-sprawie-uzycia-broni-na-granicy-wykreslono-jedna,nId,7584038)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T07:44:47+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-regulacje-w-sprawie-uzycia-broni-na-granicy-wykreslono-jedna,nId,7584038"><img align="left" alt="Regulacje w sprawie użycia broni na granicy. &quot;Wykreślono jedną przesłankę&quot;" src="https://i.iplsc.com/regulacje-w-sprawie-uzycia-broni-na-granicy-wykreslono-jedna/000JC86Z8VSDHC86-C321.jpg" /></a>- Z projektu ustawy ws. wojska i służb wykreślono punkt mówiący, że nie będzie traktowane jako przestępstwo użycie broni przy siłowym przekroczeniu granic m.in. pojazdami - przekazał wiceszef MSWiA Wiesław Szczepański. Jak dodał, wykreślenia dokonano na wniosek wiceszefa MON Cezarego Tomczyka. Wcześniej informowano o czterech przesłankach dotyczących użycia broni.</p><br clear="all" />

## "Prokurator jest już blisko". Fala komentarzy po rezygnacji J. Kowalskiego
 - [https://wydarzenia.interia.pl/kraj/news-prokurator-jest-juz-blisko-fala-komentarzy-po-rezygnacji-j-k,nId,7584002](https://wydarzenia.interia.pl/kraj/news-prokurator-jest-juz-blisko-fala-komentarzy-po-rezygnacji-j-k,nId,7584002)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T07:07:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prokurator-jest-juz-blisko-fala-komentarzy-po-rezygnacji-j-k,nId,7584002"><img align="left" alt="&quot;Prokurator jest już blisko&quot;. Fala komentarzy po rezygnacji J. Kowalskiego" src="https://i.iplsc.com/prokurator-jest-juz-blisko-fala-komentarzy-po-rezygnacji-j-k/000JC83VGG1SUVX1-C321.jpg" /></a>Janusz Kowalski odchodzi z Suwerennej Polski, a w sieci zawrzało od komentarzy. Wybrany na europosła Marcin Kierwiński (KO) określił decyzję parlamentarzysty jako &quot;ucieczkę&quot;. &quot;Widać prokurator już bardzo blisko partii Ziobry&quot; - dodał. &quot;Januszu, będziemy dalej z pełną determinacją i odwagą działać dla dobra Polski&quot; - zapewniła z kolei Marlena Maląg z PiS.

</p><br clear="all" />

## Wybuchy blisko granicy z Polską. Rosjanie zaatakowali obwód lwowski
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wybuchy-blisko-granicy-z-polska-rosjanie-zaatakowali-obwod-l,nId,7584007](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wybuchy-blisko-granicy-z-polska-rosjanie-zaatakowali-obwod-l,nId,7584007)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T06:51:34+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wybuchy-blisko-granicy-z-polska-rosjanie-zaatakowali-obwod-l,nId,7584007"><img align="left" alt="Wybuchy blisko granicy z Polską. Rosjanie zaatakowali obwód lwowski" src="https://i.iplsc.com/wybuchy-blisko-granicy-z-polska-rosjanie-zaatakowali-obwod-l/000JC7UJ99JVUMKX-C321.jpg" /></a>Uszkodzony biurowiec, wielopiętrowy budynek mieszkalny i jedna osoba ranna - to bilans rosyjskiego ataku przeprowadzonego w nocy na obwód lwowski w Ukrainie. Rosyjskie wojsko dwukrotnie ostrzelało region przy użyciu irańskich dronów &quot;Szached&quot;.</p><br clear="all" />

## Fala porwała 20-latkę. Sieć obiegło dramatyczne nagranie
 - [https://wydarzenia.interia.pl/zagranica/news-fala-porwala-20-latke-siec-obieglo-dramatyczne-nagranie,nId,7583997](https://wydarzenia.interia.pl/zagranica/news-fala-porwala-20-latke-siec-obieglo-dramatyczne-nagranie,nId,7583997)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T06:31:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-fala-porwala-20-latke-siec-obieglo-dramatyczne-nagranie,nId,7583997"><img align="left" alt="Fala porwała 20-latkę. Sieć obiegło dramatyczne nagranie" src="https://i.iplsc.com/fala-porwala-20-latke-siec-obieglo-dramatyczne-nagranie/000HXPVW5USFRKIY-C321.jpg" /></a>Od trzech dni w Soczi trwają poszukiwania 20-latki, która podczas sztormu poszła się kąpać w morzu. W sieci krąży nagranie, na którym widać, jak wchodzi do wody z mężczyzną i w pewnym momencie tracą grunt pod nogami, a fala porywa kobietę. </p><br clear="all" />

## Putin wychwala sojusznika. Na stole tajemniczy dokument
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-wychwala-sojusznika-na-stole-tajemniczy-dokument,nId,7583979](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-wychwala-sojusznika-na-stole-tajemniczy-dokument,nId,7583979)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T05:58:24+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-wychwala-sojusznika-na-stole-tajemniczy-dokument,nId,7583979"><img align="left" alt="Putin wychwala sojusznika. Na stole tajemniczy dokument" src="https://i.iplsc.com/putin-wychwala-sojusznika-na-stole-tajemniczy-dokument/000JC7HCEMXTB2FX-C321.jpg" /></a>- Bardzo doceniamy konsekwentne i niezachwiane wsparcie dla polityki rosyjskiej, w tym na kierunku ukraińskim - stwierdził Władimir Putin w trakcie rozmowy z Kim Dzong Unem. Prezydent Rosji przebywa z oficjalną wizytą w Pjongjangu, gdzie odbywa negocjacje z najważniejszymi politykami północnokoreańskiego reżimu.</p><br clear="all" />

## Janusz Kowalski odchodzi z Suwerennej Polski. Jasna deklaracja
 - [https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-odchodzi-z-suwerennej-polski-jasna-deklaracj,nId,7583970](https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-odchodzi-z-suwerennej-polski-jasna-deklaracj,nId,7583970)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T05:26:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-odchodzi-z-suwerennej-polski-jasna-deklaracj,nId,7583970"><img align="left" alt="Janusz Kowalski odchodzi z Suwerennej Polski. Jasna deklaracja" src="https://i.iplsc.com/janusz-kowalski-odchodzi-z-suwerennej-polski-jasna-deklaracj/000J4D9TCUATEF1T-C321.jpg" /></a>&quot;Dziś przestaję być członkiem Suwerennej Polski. Złożyłem rezygnację. O koleżankach i kolegach z Suwerennej Polski zawsze wypowiadać się będę w samych superlatywach&quot; - poinformował poseł Janusz Kowalski. Przekazał, że pozostanie członkiem klubu parlamentarnego PiS.</p><br clear="all" />

## Od upałów po silne burze. Wyjątkiem trzy województwa
 - [https://wydarzenia.interia.pl/kraj/news-od-upalow-po-silne-burze-wyjatkiem-trzy-wojewodztwa,nId,7583952](https://wydarzenia.interia.pl/kraj/news-od-upalow-po-silne-burze-wyjatkiem-trzy-wojewodztwa,nId,7583952)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T05:11:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-od-upalow-po-silne-burze-wyjatkiem-trzy-wojewodztwa,nId,7583952"><img align="left" alt="Od upałów po silne burze. Wyjątkiem trzy województwa" src="https://i.iplsc.com/od-upalow-po-silne-burze-wyjatkiem-trzy-wojewodztwa/000JC7FV25I7FIC5-C321.jpg" /></a>Niemal w całej Polsce wydano ostrzeżenia przed upałami i burzami. Temperatury na południu i wschodzie przekroczą 30 stopni. Na północnych krańcach kraju może wystąpić silny deszcz oraz opady gradu. IMGW ostrzega przed niebezpiecznym wiatrem przekraczającym 100 km/h.</p><br clear="all" />

## Tragiczny miesiąc dla Ukrainy. Tak źle nie było od roku
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-tragiczny-miesiac-dla-ukrainy-tak-zle-nie-bylo-od-roku,nId,7583956](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-tragiczny-miesiac-dla-ukrainy-tak-zle-nie-bylo-od-roku,nId,7583956)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T05:00:16+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-tragiczny-miesiac-dla-ukrainy-tak-zle-nie-bylo-od-roku,nId,7583956"><img align="left" alt="Tragiczny miesiąc dla Ukrainy. Tak źle nie było od roku" src="https://i.iplsc.com/tragiczny-miesiac-dla-ukrainy-tak-zle-nie-bylo-od-roku/000JC7FE4QCILD6N-C321.jpg" /></a>Ponad 11 tys. zabitych i ponad 20 tys. rannych cywilów odnotowano od początku wojny na Ukrainie - poinformowała podsekretarz generalna ONZ Rosemary DiCarlo. - Te liczby są prawdopodobnie większe - dodała. Wyjątkowo tragiczny był ostatni miesiąc.</p><br clear="all" />

## Znany kurort wprowadza zakaz chodzenia boso. "Sprzeczne z przyzwoitością"
 - [https://wydarzenia.interia.pl/zagranica/news-znany-kurort-wprowadza-zakaz-chodzenia-boso-sprzeczne-z-przy,nId,7582608](https://wydarzenia.interia.pl/zagranica/news-znany-kurort-wprowadza-zakaz-chodzenia-boso-sprzeczne-z-przy,nId,7582608)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-06-19T04:27:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-znany-kurort-wprowadza-zakaz-chodzenia-boso-sprzeczne-z-przy,nId,7582608"><img align="left" alt="Znany kurort wprowadza zakaz chodzenia boso. &quot;Sprzeczne z przyzwoitością&quot;" src="https://i.iplsc.com/znany-kurort-wprowadza-zakaz-chodzenia-boso-sprzeczne-z-przy/000JC7EHG7MK087D-C321.jpg" /></a>Burmistrz znanego nadmorskiego kurortu San Felice Circeo we włoskim regionie Lacjum wprowadziła serię niecodziennych zakazów. Wśród nich znalazło się m.in. chodzenie boso, które jest &quot;sprzeczne z przyzwoitością&quot;. Za złamanie zakazu grożą wysokie kary. 
</p><br clear="all" />

