# Source:RT - Daily news, URL:https://www.rt.com/rss, language:en

## US surprised at speed Russia built new alliances – WSJ
 - [https://www.rt.com/news/599598-us-surprised-russia-alliances/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599598-us-surprised-russia-alliances/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T22:27:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/66735a262030275d17035469.jpg" style="margin-right: 10px;" /> The speed and depth of Moscow’s security partnerships with “adversaries” of Washington has reportedly taken American spies by surprise <br /><a href="https://www.rt.com/news/599598-us-surprised-russia-alliances/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Fewer and fewer Westerners are buying the ‘Atlanticism’ idea
 - [https://www.rt.com/news/599503-us-europe-poll-ideia-atlanticism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599503-us-europe-poll-ideia-atlanticism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T20:51:39+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/66719dd92030273993552a30.jpg" style="margin-right: 10px;" /> A recent poll has shown a growing number of people in the US and Western Europe are tired of NATO’s professed goals <br /><a href="https://www.rt.com/news/599503-us-europe-poll-ideia-atlanticism/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## ‘No place’ is safe if Israel starts war – Hezbollah
 - [https://www.rt.com/news/599597-hezbollah-nasrallah-israel-cyprus/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599597-hezbollah-nasrallah-israel-cyprus/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T20:41:15+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/667328c385f540221c6d019b.jpg" style="margin-right: 10px;" /> Hezbollah has drones and missiles which can reach any target in Israel, its leader Hassan Nasrallah has said <br /><a href="https://www.rt.com/news/599597-hezbollah-nasrallah-israel-cyprus/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine could invite Russia to next peace talks – Zelensky aide
 - [https://www.rt.com/russia/599595-yermak-ukraine-russia-peace-talks/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599595-yermak-ukraine-russia-peace-talks/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T20:25:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/66731ad620302775171294f5.jpg" style="margin-right: 10px;" /> A representative of Russia might be invited to the next peace conference, Vladimir Zelensky’s chief of staff Andrey Yermak has said <br /><a href="https://www.rt.com/russia/599595-yermak-ukraine-russia-peace-talks/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## More than half of Russia-Vietnam trade conducted using the countries’ currencies – Putin
 - [https://www.rt.com/business/599591-russia-vietnam-trade-national-currencies/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/599591-russia-vietnam-trade-national-currencies/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T19:41:01+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6673275b20302722bc77b7ed.jpg" style="margin-right: 10px;" /> Moscow and Hanoi have been diverting bilateral trade away from “widely discredited currencies,” according to the Russian president <br /><a href="https://www.rt.com/business/599591-russia-vietnam-trade-national-currencies/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Switzerland considers distributing cocaine to addicts
 - [https://www.rt.com/news/599584-switzerland-addicts-cocaine-distribution/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599584-switzerland-addicts-cocaine-distribution/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T19:15:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6673209185f54078a24a8ea5.jpg" style="margin-right: 10px;" /> Switzerland is considering a controlled cocaine distribution program aimed at tackling the ongoing crack epidemic <br /><a href="https://www.rt.com/news/599584-switzerland-addicts-cocaine-distribution/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin arrives in Vietnam after historic visit to North Korea
 - [https://www.rt.com/news/599594-putin-arrives-vietnam/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599594-putin-arrives-vietnam/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T18:57:48+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/static.en/thumbnail/dev_story.jpg" style="margin-right: 10px;" /> The Russian president will meet Vietnam’s leaders to discuss cooperation in a broad range of spheres <br /><a href="https://www.rt.com/news/599594-putin-arrives-vietnam/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ottawa honors memory of Sikh activist designated as ‘terrorist’ by New Delhi
 - [https://www.rt.com/india/599596-ottawa-honors-memory-of-sikh-activist-nijjar/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/599596-ottawa-honors-memory-of-sikh-activist-nijjar/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T18:14:45+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/66731fc120302771c649a607.jpg" style="margin-right: 10px;" /> Pro-Khalistan separatist Hardeep Singh Nijjar was gunned down by unidentified assailants near Vancouver last year <br /><a href="https://www.rt.com/india/599596-ottawa-honors-memory-of-sikh-activist-nijjar/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia-EU trade dips to near 25-year low – data
 - [https://www.rt.com/business/599582-russia-eu-trade-drop/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/599582-russia-eu-trade-drop/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T17:39:13+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/66730cfb20302772744452ad.jpg" style="margin-right: 10px;" /> Bilateral trade between Russia and the EU has dropped to its lowest level since 2000 amid Western sanctions, according to a report <br /><a href="https://www.rt.com/business/599582-russia-eu-trade-drop/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin’s state visit to North Korea: Warm welcome, bilateral agreements and a new comprehensive partnership treaty
 - [https://www.rt.com/russia/599585-putin-north-korea-visit-recap/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599585-putin-north-korea-visit-recap/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T16:58:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672ff8985f54078a24a8e90.jpg" style="margin-right: 10px;" /> Moscow and Pyongyang have agreed to work together to enhance cooperation in all spheres and defend each other in case of foreign aggression <br /><a href="https://www.rt.com/russia/599585-putin-north-korea-visit-recap/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel’s isolation: An anti-Semitic horror story or inevitable outcome?
 - [https://www.rt.com/news/599408-gaza-israel-isolation-opinions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599408-gaza-israel-isolation-opinions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T16:52:00+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672e28e203027725b567898.jpg" style="margin-right: 10px;" /> Opinions are split on the impact of the Gaza war on West Jerusalem, but the trend ss worrying <br /><a href="https://www.rt.com/news/599408-gaza-israel-isolation-opinions/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Polish MP calls for landmines at Russian border
 - [https://www.rt.com/news/599579-poland-landmines-border-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599579-poland-landmines-border-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T16:39:57+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672fc8b2030277274445294.jpg" style="margin-right: 10px;" /> Former defense minister Mariusz Blaszczak has proposed deploying landmines near Kaliningrad Region <br /><a href="https://www.rt.com/news/599579-poland-landmines-border-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## AI could fuel anti-Semitism – UNESCO
 - [https://www.rt.com/news/599567-ai-risks-holocaust-un/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599567-ai-risks-holocaust-un/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T15:34:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672f00320302771d77bf019.jpg" style="margin-right: 10px;" /> Artificial intelligence technology could pose risks in misrepresenting or distorting the history of the Holocaust, a UN report has warned <br /><a href="https://www.rt.com/news/599567-ai-risks-holocaust-un/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## WATCH Ukrainian armor get blown up near key Donbass town
 - [https://www.rt.com/russia/599580-ukrainian-armor-destruction-video/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599580-ukrainian-armor-destruction-video/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T15:29:57+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672f82785f540799220f3e5.png" style="margin-right: 10px;" /> A Ukrainian armored personnel carrier was incinerated in a powerful explosion near Chasov Yar, drone video shows <br /><a href="https://www.rt.com/russia/599580-ukrainian-armor-destruction-video/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## McDonald’s scraps AI trial after bacon added to ice cream – media
 - [https://www.rt.com/news/599575-mcdonalds-scraps-ai-assistant-trial/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599575-mcdonalds-scraps-ai-assistant-trial/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T14:41:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672e91a85f5407bd619a5a5.jpg" style="margin-right: 10px;" /> The fast food giant is ending its AI drive-through pilot project with IBM after videos of order mix-ups went viral  <br /><a href="https://www.rt.com/news/599575-mcdonalds-scraps-ai-assistant-trial/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine ‘snatching’ US Patriot missiles promised to Switzerland
 - [https://www.rt.com/news/599576-patriot-missiles-ukraine-switzerland/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599576-patriot-missiles-ukraine-switzerland/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T14:37:14+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672dfe4203027725b56788e.jpg" style="margin-right: 10px;" /> The supply of US air defense systems to Switzerland will be delayed due to Washington’s decision to prioritize the arming of Ukraine <br /><a href="https://www.rt.com/news/599576-patriot-missiles-ukraine-switzerland/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Nancy Pelosi’s meeting with Dalai Lama in India irks China
 - [https://www.rt.com/india/599566-nancy-pelosis-meeting-with-dalai/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/599566-nancy-pelosis-meeting-with-dalai/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T13:29:02+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672d06785f540221c6d015b.jpg" style="margin-right: 10px;" /> The visit to the residence of the spiritual leader comes a week after the US passed a bill to “resolve” tensions between China and Tibet <br /><a href="https://www.rt.com/india/599566-nancy-pelosis-meeting-with-dalai/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## South Africa’s president starts new term under power-sharing deal
 - [https://www.rt.com/africa/599561-ramaphosa-second-presidential-term-inauguration/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/599561-ramaphosa-second-presidential-term-inauguration/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T13:27:34+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672d6dc203027725b56787d.jpg" style="margin-right: 10px;" /> South Africa’s President Cyril Ramaphosa has been sworn in for a second term, to lead a Government of National Unity <br /><a href="https://www.rt.com/africa/599561-ramaphosa-second-presidential-term-inauguration/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU state imprisons Russian academic for ‘spying’
 - [https://www.rt.com/russia/599570-estonia-jails-russian-academic/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599570-estonia-jails-russian-academic/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T13:22:06+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672d964203027727d69c66a.jpg" style="margin-right: 10px;" /> An Estonian court sentenced erstwhile professor Vyacheslav Morozov to six years in prison for allegedly providing intelligence to Moscow <br /><a href="https://www.rt.com/russia/599570-estonia-jails-russian-academic/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Killers of Donbass commander sentenced in Russia
 - [https://www.rt.com/russia/599564-pavlov-murder-sentense-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599564-pavlov-murder-sentense-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T12:23:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672c9a12030270df27dbf78.jpg" style="margin-right: 10px;" /> A Russian military tribunal has sentenced members of an SBU “terrorist cell” who killed Arsen ‘Motorola’ Pavlov <br /><a href="https://www.rt.com/russia/599564-pavlov-murder-sentense-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Hungary unveils MEGA slogan for EU presidency
 - [https://www.rt.com/news/599558-hungary-mega-slogan-eu-presidency/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599558-hungary-mega-slogan-eu-presidency/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T12:15:42+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672cb0185f54078a24a8e6f.jpg" style="margin-right: 10px;" /> The official motto for the Hungarian presidency of the EU that starts on July 1 is ‘Make Europe Great Again’ <br /><a href="https://www.rt.com/news/599558-hungary-mega-slogan-eu-presidency/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Boeing can’t find new CEO – WSJ
 - [https://www.rt.com/business/599553-boeing-cant-find-new-ceo/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/599553-boeing-cant-find-new-ceo/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T11:40:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672baca85f54003343d0110.jpg" style="margin-right: 10px;" /> US aerospace giant Boeing is struggling to find a new CEO due to scrutiny over its safety record, The Wall Street Journal has reported <br /><a href="https://www.rt.com/business/599553-boeing-cant-find-new-ceo/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Islamist terrorists snuck into EU from Ukraine – German spies
 - [https://www.rt.com/news/599556-gearmany-jihadists-ukrainian-refugees/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599556-gearmany-jihadists-ukrainian-refugees/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T10:58:00+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672b85b2030270de907e92e.jpg" style="margin-right: 10px;" /> Germany’s national security agency BfV has outlined major threats that the country faces domestically and internationally <br /><a href="https://www.rt.com/news/599556-gearmany-jihadists-ukrainian-refugees/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US-supplied F-16s to be stationed inside Ukraine – White House
 - [https://www.rt.com/russia/599557-us-f16-stationed-in-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599557-us-f16-stationed-in-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T10:57:27+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672b79d85f540221c6d013d.jpg" style="margin-right: 10px;" /> Vladimir Zelensky and President Joe Biden have signed a bilateral security agreement on the delivery of F-16s to Ukraine <br /><a href="https://www.rt.com/russia/599557-us-f16-stationed-in-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US greenlights new arms sale to Taiwan
 - [https://www.rt.com/news/599548-us-approves-taiwan-arms-sale/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599548-us-approves-taiwan-arms-sale/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T10:22:45+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672b02485f540799220f3ba.jpg" style="margin-right: 10px;" /> The US has approved the sale of $360 million worth of drones and missiles to Taiwan, the State Department has said

  <br /><a href="https://www.rt.com/news/599548-us-approves-taiwan-arms-sale/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian warships arrive in Libya (VIDEO)
 - [https://www.rt.com/africa/599549-russian-warships-arrive-libya/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/599549-russian-warships-arrive-libya/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T09:59:55+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672a4b72030270df27dbf41.jpg" style="margin-right: 10px;" /> A Russian frigate and guided missile cruiser have arrived at Libya’s Tobruk naval base <br /><a href="https://www.rt.com/africa/599549-russian-warships-arrive-libya/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Another African state to apply for BRICS membership
 - [https://www.rt.com/africa/599546-zimbabwe-brics-membership-intention/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/599546-zimbabwe-brics-membership-intention/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T09:52:52+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/66729ea185f540019b7f3e62.jpg" style="margin-right: 10px;" /> Zimbabwe’s defense minister says the country will apply to join BRICS to strengthen economic ties with like-minded nations <br /><a href="https://www.rt.com/africa/599546-zimbabwe-brics-membership-intention/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia and North Korea agree on mutual aid against aggression – Putin
 - [https://www.rt.com/news/599552-russia-north-korea-mutual-defense/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599552-russia-north-korea-mutual-defense/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T09:47:52+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/static.en/thumbnail/dev_story.jpg" style="margin-right: 10px;" /> Russia and North Korea have pledged to jointly oppose foreign aggression against either nation, President Vladimir Putin has announced <br /><a href="https://www.rt.com/news/599552-russia-north-korea-mutual-defense/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Nvidia becomes world’s most valuable company
 - [https://www.rt.com/business/599544-nvidia-worlds-most-valuable-company/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/599544-nvidia-worlds-most-valuable-company/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T09:16:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/667294152030273c8060c074.jpg" style="margin-right: 10px;" /> US artificial intelligence chipmaker Nvidia has dethroned Microsoft to become the world’s most valuable company <br /><a href="https://www.rt.com/business/599544-nvidia-worlds-most-valuable-company/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Concerns grow over press freedom in Ukraine – NYT
 - [https://www.rt.com/russia/599543-ukraine-press-freedom-zelensky/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599543-ukraine-press-freedom-zelensky/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T08:35:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672925785f5407bd619a569.jpg" style="margin-right: 10px;" /> The Ukrainian government’s restrictions and pressure on the media exceed wartime security needs, local journalists have told the NYT <br /><a href="https://www.rt.com/russia/599543-ukraine-press-freedom-zelensky/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Details emerge of alleged contract hit ordered by ex-Zelensky mentor
 - [https://www.rt.com/russia/599542-kolomoysky-attempted-murder-case/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599542-kolomoysky-attempted-murder-case/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T08:12:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/66728b4085f54078a24a8e20.jpg" style="margin-right: 10px;" /> The case against Igor Kolomoysky concerns the attempted murder of a lawyer who worked for Victor Pinchuk, according to Ukrainian media <br /><a href="https://www.rt.com/russia/599542-kolomoysky-attempted-murder-case/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## India expanding nuclear arsenal with an eye on China – report
 - [https://www.rt.com/india/599540-india-expanding-nuclear-arsenal/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/599540-india-expanding-nuclear-arsenal/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T07:26:47+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/667287f885f54001e43eab9a.jpg" style="margin-right: 10px;" /> Both New Delhi and Beijing increased their number of nuclear missiles last year, according to SIPRI <br /><a href="https://www.rt.com/india/599540-india-expanding-nuclear-arsenal/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US soldier sentenced to nearly four years in Russian prison
 - [https://www.rt.com/news/599531-us-soldier-sentenced-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599531-us-soldier-sentenced-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T06:45:53+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/66726d6b85f540019b7f3e3f.jpg" style="margin-right: 10px;" /> A Russian court had handed US soldier Gordon Black a prison term of almost four years for grand larceny and death threats <br /><a href="https://www.rt.com/news/599531-us-soldier-sentenced-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine frustrated with US over F-16 pilot training
 - [https://www.rt.com/news/599527-ukraine-attacks-us-f16s/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599527-ukraine-attacks-us-f16s/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T05:52:07+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672622985f5407bd619a542.jpg" style="margin-right: 10px;" /> The US is making excuses for training F-16 pilots too slowly, Ukrainian lawmaker Aleksandra Ustinova has said <br /><a href="https://www.rt.com/news/599527-ukraine-attacks-us-f16s/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin welcomed in Pyongyang with spectacular ceremony (VIDEO)
 - [https://www.rt.com/russia/599530-putin-pyongyang-welcoming-ceremony/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599530-putin-pyongyang-welcoming-ceremony/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T04:55:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672617c2030270df27dbef4.png" style="margin-right: 10px;" /> North Korea’s Kim Jong-un has welcomed Russian President Vladimir Putin in Pyongyang with a spectacular ceremony on Wednesday <br /><a href="https://www.rt.com/russia/599530-putin-pyongyang-welcoming-ceremony/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin’s state visit to North Korea: LIVE UPDATES
 - [https://www.rt.com/russia/599519-putin-state-visit-north-korea/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599519-putin-state-visit-north-korea/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T02:01:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/66723bdd2030271fa9108677.jpg" style="margin-right: 10px;" /> Russian President Vladimir Putin has a “very busy agenda” for his official state visit to Democratic People’s Republic of Korea <br /><a href="https://www.rt.com/russia/599519-putin-state-visit-north-korea/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine will never join NATO – Moscow
 - [https://www.rt.com/russia/599518-ukraine-never-join-nato/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/599518-ukraine-never-join-nato/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T01:29:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672345185f54078a24a8dd8.jpg" style="margin-right: 10px;" /> Ukraine will never become a member of the North Atlantic Treaty Organization, Russian Deputy Foreign Minister Sergey Ryabkov has said <br /><a href="https://www.rt.com/russia/599518-ukraine-never-join-nato/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Sweden opens doors to US troops and possibly nukes
 - [https://www.rt.com/news/599517-sweden-us-military-pact/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/599517-sweden-us-military-pact/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-06-19T00:40:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.06/thumbnail/6672259885f54078a24a8dce.jpg" style="margin-right: 10px;" /> Lawmakers in Stockholm have approved a military pact, allowing US troops access to 17 Swedish military bases <br /><a href="https://www.rt.com/news/599517-sweden-us-military-pact/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

