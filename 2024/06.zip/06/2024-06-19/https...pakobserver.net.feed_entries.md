# Source:Pakistan Observer, URL:https://pakobserver.net/feed, language:en-US

## T20 World Cup 2024: South Africa beat USA by 18 runs
 - [https://pakobserver.net/t20-world-cup-2024-south-africa-beat-usa-by-18-runs](https://pakobserver.net/t20-world-cup-2024-south-africa-beat-usa-by-18-runs)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T18:00:05+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/sa-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />South Africa beat United States of America (USA) by 18 runs in a Super 8s stage Group B match of the ICC Men&#8217;s T20 World Cup in North Sound on Wednesday. Chasing a challenging 195-run target for the victory, USA reached 176/6 in the allocated 20 overs. Andries Gous was the highest scorer with 80 [&#8230;]

## How many Pakistani pilgrims died during Hajj 2024?
 - [https://pakobserver.net/how-many-pakistani-pilgrims-died-during-hajj-2024](https://pakobserver.net/how-many-pakistani-pilgrims-died-during-hajj-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T17:48:23+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/444-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Over 500 people have lost their lives during this year&#8217;s Hajj pilgrimage in Saudi Arabia amid soaring temperatures and several Pakistanis also died during holy journey. Amid the reports, Pakistan’s Ministry of Religious Affairs confirmed that at least nine Pakistanis have died during Hajj 2024. Ministry also urged public to avoid rumors circulating on social [&#8230;]

## Chinese Communist Party official Liu Jianchao due in Pakistan for CPEC talks
 - [https://pakobserver.net/chinese-communist-party-official-liu-jianchao-due-in-pakistan-for-cpec-talks](https://pakobserver.net/chinese-communist-party-official-liu-jianchao-due-in-pakistan-for-cpec-talks)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T17:31:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/pak-china-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – Minister of International Department of the Communist Party of China (IDCPC) and member of the Communist Party’s Central Committee, Liu Jianchao, is slated to visit Pakistan. Chinese diplomat and politician will land in Islamabad on two day official visit from June 20-22. He is arriving at the invitation of Deputy Prime Minister and Foreign [&#8230;]

## Karachi, Sindh weather update; rains expected in upper districts
 - [https://pakobserver.net/karachi-sindh-weather-update-rains-expected-in-upper-districts](https://pakobserver.net/karachi-sindh-weather-update-rains-expected-in-upper-districts)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T16:46:34+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/10/KW-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – Mainly hot and dry weather is expected in most parts of Sindh on Wednesday night, Thursday and Friday. Hot and humid weather is expected in coastal areas and isolated rains in upper districts. Per Pakistan Meteorological Department (PMD), weak moist currents from Arabian Sea are penetrating upper/central parts of Pakistan. A shallow westerly [&#8230;]

## Shoaib Malik, Sana Javed’s loved up Eid pictures leave fans in awe
 - [https://pakobserver.net/shoaib-malik-sana-javeds-loved-up-eid-pictures-leave-fans-in-awe](https://pakobserver.net/shoaib-malik-sana-javeds-loved-up-eid-pictures-leave-fans-in-awe)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T16:16:17+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/554-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Pakistani showbiz stars celebrated Eid ul Adha with great fervour and excitement, and even shared their pictures, showcasing their best outfits for the first day. Shoaib Malik, and Sana Javed also flaunted their beautiful pictures on Festival of Sacrifice. Shoaib and Sana delighted fans with their romantic Eidul Adha snaps, marking their first celebration of [&#8230;]

## Lahore, Punjab weather update; rains, gusty winds expected
 - [https://pakobserver.net/lahore-punjab-weather-update-rains-gusty-winds-expected](https://pakobserver.net/lahore-punjab-weather-update-rains-gusty-winds-expected)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T14:43:18+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/08/LHR-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Rain-wind/thunderstorms are expected in Lahore and parts of Punjab on Wednesday evening/night, Thursday and Friday. Per Pakistan Meteorological Department (PMD), weak moist currents from Arabian Sea are penetrating upper/central parts of Pakistan. A shallow westerly wave also prevails over upper/central parts. Under these weather conditions, rain-wind/thunderstorms are likely at isolated places in Murree, [&#8230;]

## T20 World Cup 2024: USA opt to bowl first against South Africa
 - [https://pakobserver.net/t20-world-cup-2024-usa-opt-to-bowl-first-against-south-africa](https://pakobserver.net/t20-world-cup-2024-usa-opt-to-bowl-first-against-south-africa)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T14:24:05+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/sa-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />United States of America (USA) skipper Aaron Jones has won the toss and opted to bowl first against South Africa in a Super 8s stage Group B match of the ICC Men&#8217;s T20 World Cup in North Sound on Wednesday. South Africa Playing XI: Quinton de Kock (wk), Reeza Hendricks, Aiden Markram (c), Heinrich Klaasen, [&#8230;]

## Deadly heatwave in Saudi Arabia kills 577 pilgrims during Hajj 2024
 - [https://pakobserver.net/deadly-heatwave-in-saudi-arabia-kills-577-pilgrims-during-hajj-2024](https://pakobserver.net/deadly-heatwave-in-saudi-arabia-kills-577-pilgrims-during-hajj-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T13:43:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/ihram-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Extreme temperatures of around 52 degrees Celsius caused hundreds of deaths during the annual pilgrimage of Hajj 2024 as over 1.8 million gathered in Kingdom this year. Amid the scorching weather, pilgrims used umbrellas for shade, while the Saudi government urged people to stay hydrated and avoid being outdoors during the peak heat hours. This [&#8230;]

## 200 Prize Bond June 2024 Results and Winners List Update
 - [https://pakobserver.net/200-prize-bond-june-2024-results-and-winners-list-update](https://pakobserver.net/200-prize-bond-june-2024-results-and-winners-list-update)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T13:26:28+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/3gy-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; Pakistanis continue to buy prize bonds for the chance to win cash prizes, and opportunity to earn without interest attracts a lot of investment and the upcoming balloting is Rs200 Prize Bond. Rs200 Prize Bond June 2024 Results The balloting for Rs200 prize bond, was scheduled for June 17 at Rawalpindi office of [&#8230;]

## Looters empty Coca-Cola truck after crash in Faisalabad (VIDEO)
 - [https://pakobserver.net/looters-empty-coca-cola-truck-after-crash-in-faisalabad-video](https://pakobserver.net/looters-empty-coca-cola-truck-after-crash-in-faisalabad-video)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T11:40:33+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/gg334-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />A delivery truck of leading beverage was looted after it crashed in Faisalabad during Eidul Adha days. Eyewitnesses said they were travelling on Manawala-Sheikhupura Road when noticed chaotic scenes as people stormed a Coca-Cola truck in broad daylight. The vehicle was moving to deliver famous drinks when it collided with a bike on the busy [&#8230;]

## Key TTP leader Abdul Mannan aka Hakeemullah killed in Afghanistan
 - [https://pakobserver.net/key-ttp-leader-abdul-mannan-aka-hakeemullah-killed-in-afghanistan](https://pakobserver.net/key-ttp-leader-abdul-mannan-aka-hakeemullah-killed-in-afghanistan)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T11:05:08+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/618499c407008-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Notorious Tehreek-e-Taliban Pakistan leader Abdul Mannan, who was key operative in Bajaur attacks, has been killed in Kunar, Afghanistan. The dead ringleader was member of TTP&#8217;s Malakand Shura and was involved in targeted killings, landmine blasts in Bajaur, attacks on security checkposts, and also in extortion incidents. Hakeemullah was reportedly close ally of TTP leader [&#8230;]

## Peshawar, Khyber Pakhtunkhwa weather update; rains, gusty winds predicted
 - [https://pakobserver.net/peshawar-khyber-pakhtunkhwa-weather-update-rains-gusty-winds-predicted](https://pakobserver.net/peshawar-khyber-pakhtunkhwa-weather-update-rains-gusty-winds-predicted)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T11:00:49+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/07/monsoon-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />PESHAWAR – Isolated rain-wind/thunderstorms are predicted in Peshawar and parts of Khyber Pakhtunkhwa on Wednesday evening/night, Thursday and Friday. Per Pakistan Meteorological Department (PMD), weak moist currents from Arabian Sea are penetrating central parts of Pakistan. A shallow westerly wave also prevails over upper parts. Under these weather conditions, rain-wind/thunderstorms are likely at isolated places [&#8230;]

## Prices of these Infinix smartphones to go up in July 2024
 - [https://pakobserver.net/prices-of-these-infinix-smartphones-to-go-up-in-july-2024](https://pakobserver.net/prices-of-these-infinix-smartphones-to-go-up-in-july-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T10:49:28+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/06/hel-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – The federal government has proposed imposition of standard 18 percent sales tax on all mobile phones valued below $500 (Rs139,008 as of June 19, 2024), a move if approved would jack up the prices of mobile phones of various companies, including Infinix. The proposal was laid forth in the budget for next fiscal [&#8230;]

## Islamabad, Pakistan weather update; isolated rains, gusty winds likely
 - [https://pakobserver.net/islamabad-pakistan-weather-update-isolated-rains-gusty-winds-likely](https://pakobserver.net/islamabad-pakistan-weather-update-isolated-rains-gusty-winds-likely)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T10:44:11+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/08/ISD-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – Isolated rain-wind/thunderstorms are likely in Islamabad, Rawalpindi, and parts of Pakistan on Wednesday evening/night, Thursday and Friday. Per Pakistan Meteorological Department (PMD), weak moist currents from Arabian Sea are penetrating central parts of Pakistan. A shallow westerly wave also prevails over upper parts. Under these weather conditions, rain-wind/thunderstorms are likely at isolated places [&#8230;]

## Minimum bank statement update for Finland Schengen visa from Pakistan June 2024
 - [https://pakobserver.net/minimum-bank-statement-update-for-finland-schengen-visa-from-pakistan-june-2024](https://pakobserver.net/minimum-bank-statement-update-for-finland-schengen-visa-from-pakistan-june-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T07:58:31+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/schengen-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Finland is one of the popular tourist destinations in the world as it offers stunning blend of unique natural beauty, fascinating culture, and outdoor activities. Tourists from across the world land in the European country to spend quality times. Pakistani nationals are required to get the short-stay schengen visit visa to enter the [&#8230;]

## Post-Hajj flight operation all set to begin tomorrow
 - [https://pakobserver.net/post-hajj-flight-operation-all-set-to-begin-tomorrow](https://pakobserver.net/post-hajj-flight-operation-all-set-to-begin-tomorrow)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T07:30:06+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/hajj-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />MAKKAH &#8211; Post Hajj flight operation to bring back Pakistani pilgrims under government scheme from Saudi Arabia will begin tomorrow (Thursday). The pilgrims will be provided five liter Zamzam water at the airport. The flight operation will culminate on 20th of next month. Over 86,000 Pakistanis undertook Hajj pilgrimage under government scheme this year.

## BISE Rawalpindi Matric Results 2024; check latest date update
 - [https://pakobserver.net/bise-rawalpindi-matric-results-2024-check-latest-date-update](https://pakobserver.net/bise-rawalpindi-matric-results-2024-check-latest-date-update)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T06:12:17+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/08/resulsts-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />RAWALPINDI &#8211; Hundreds of thousands of students appeared in matric exams this year in Rawalpindi and other cities of Punjab and now all are waiting Matric Results 2024. Sources familiar with development revealed that BISE Rawalpindiis expected to announce Matric results in last week of July or first half of August 2024. Matric Results Date [&#8230;]

## Gold rates in Saudi Arabia today – 19 June 2024
 - [https://pakobserver.net/gold-rates-in-saudi-arabia-today-19-june-2024](https://pakobserver.net/gold-rates-in-saudi-arabia-today-19-june-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T05:56:28+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/10/gold6-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – The price of per tola price 24-karat gold in Saudi Arabia on Wednesday (June 19) declined to 3,248 Saudi Riyal (SAR), according to forex.pk. Furthermore, the 10 grams of 24-k gold is being sold for SAR 2,788 in the kingdom while the per ounce gold price stands at SAR 8,671. Note: The gold [&#8230;]

## Earthquake shakes Islamabad, Rawalpindi and parts of KP
 - [https://pakobserver.net/earthquake-shakes-islamabad-rawalpindi-and-parts-of-kp](https://pakobserver.net/earthquake-shakes-islamabad-rawalpindi-and-parts-of-kp)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T05:53:12+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2021/10/ear-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; A 4.7 magnitude earthquake jolted parts of Islamabad, Rawalpindi and Khyber Pakhtunkhwa on Wednesday. The National Seismic Monitoring Centre in the federal capital said tremors were felt across the twin cities and several cities of the country&#8217;s northwestern province. The epicenter was the southeastern region of Afghanistan while The depth of the earthquake [&#8230;]

## UK Pound to PKR rate today – 19 June 2024
 - [https://pakobserver.net/uk-pound-to-pkr-rate-today-19-june-2024](https://pakobserver.net/uk-pound-to-pkr-rate-today-19-june-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T05:45:43+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/pound-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />UK Pound GBP&#8217;s buying rate in Pakistan is Rs349.7 while the selling rate is Rs. 353.25 in the open market on Wednesday. Pound moved down slightly against rupee in the open market. GBP to PKR Rate – 19 June 2024 Date  Latest Exchange Rate CHANGE  June 19, 2024 Rs. 349.7 0 June 18, 2024 Rs. [&#8230;]

## Dirham to PKR rate today – 19 June 2024
 - [https://pakobserver.net/dirham-to-pkr-rate-today-19-june-2024](https://pakobserver.net/dirham-to-pkr-rate-today-19-june-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T05:42:55+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/dirham-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />UAE Dirham buying rate in open market of Pakistan dropped to Rs74.8 on Wednesday while the selling rate is Rs75.6. UAE Dirham saw no change against Pakistani rupee as compared to the previous trading day’s closing. AED to PKR Rate – 19 June 2024 Date  Latest Exchange Rate CHANGE  June 19, 2024 Rs74.8 0 source: [&#8230;]

## Saudi Riyal to PKR rate today – 19 June 2024
 - [https://pakobserver.net/saudi-riyal-to-pkr-rate-today-19-june-2024](https://pakobserver.net/saudi-riyal-to-pkr-rate-today-19-june-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T05:41:13+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/riyal-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The buying rate for Saudi Arabia Riyal in Pakistan stands at Rs72.8 while the selling rate stands at Rs73.55 on Wednesday in open market, according to forex.pk. Data available on the currency website showed the Saudi Riyal saw no change against Pakistani rupee in the open market. SAR to PKR Rate – 19 [&#8230;]

## Currency exchange rates in Pakistan today – June 19, 2024
 - [https://pakobserver.net/currency-exchange-rates-in-pakistan-today-june-19-2024](https://pakobserver.net/currency-exchange-rates-in-pakistan-today-june-19-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T05:17:50+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/curreny-rate-today-15-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI- On Wednesday, June 19, 2024, the exchange rate for one US Dollar against Pakistani rupees was recorded at Rs 277.6 in the local and open market, with a selling rate of Rs 280.5. Note: Exchange rates can vary based on the location and the Exchange Company or bank involved in the transaction. Below are the [&#8230;]

## Gold rate in Pakistan today – 19 June, 2024
 - [https://pakobserver.net/gold-rate-in-pakistan-today-19-june-2024](https://pakobserver.net/gold-rate-in-pakistan-today-19-june-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-06-19T05:15:33+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/gold-rate-in-pakistan-today-24-March-2023-1-1024x576-4-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI—On Wednesday, June 19, 2024, the 24-karat gold rate was PKR 241,200. Similarly, the bullion market recorded the gold price for 24-karat at Rs 206,790 per 10g. Gold Price in Pakistan’s different cities. City Gold Silver Karachi PKR 241,200 PKR 2,550 Lahore PKR 241,200 PKR 2,550 Islamabad PKR 241,200 PKR 2,550 Peshawar PKR 241,200 PKR [&#8230;]

