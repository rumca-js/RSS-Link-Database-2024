# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Are Israel and Hezbollah on the verge of full-blown war?
 - [https://www.aljazeera.com/program/inside-story/2024/6/19/are-israel-and-hezbollah-on-the-verge-of-full-blown-war?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/6/19/are-israel-and-hezbollah-on-the-verge-of-full-blown-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T21:34:32+00:00

Israel&#039;s military says plans for an offensive in Lebanon have been approved.

## Canada lists Iran Revolutionary Guards as ‘terrorist’ group
 - [https://www.aljazeera.com/news/2024/6/19/canada-lists-iran-revolutionary-guards-as-terrorist-group?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/canada-lists-iran-revolutionary-guards-as-terrorist-group?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T21:30:41+00:00

Ottawa cites the IRGC&#039;s ties to Hamas and Hezbollah, accusing Iran of &#039;complete disregard for human rights&#039;.

## Attacks and rhetoric: Israel, Hezbollah could plunge Lebanon into war
 - [https://www.aljazeera.com/news/2024/6/19/attacks-rhetoric-israel-hezbollah-could-plunge-lebanon-war?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/attacks-rhetoric-israel-hezbollah-could-plunge-lebanon-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T21:14:44+00:00

Both sides are barely staying within the rules of engagement, leaving Lebanese anxious over what comes next.

## Hezbollah chief Nasrallah says Israel should be ‘scared’ of all-out war
 - [https://www.aljazeera.com/news/2024/6/19/hezbollah-chief-nasrallah-says-israel-should-be-scared-of-all-out-war?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/hezbollah-chief-nasrallah-says-israel-should-be-scared-of-all-out-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T19:37:28+00:00

Hassan Nasrallah says invading northern Israel is a &#039;standing&#039; possibility if a major conflict is imposed on Lebanon.

## Tropical Storm Alberto forms over Western Gulf of Mexico
 - [https://www.aljazeera.com/news/2024/6/19/tropical-storm-alberto-forms-over-western-gulf-of-mexico?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/tropical-storm-alberto-forms-over-western-gulf-of-mexico?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T18:40:47+00:00

Alberto, the first named storm of 2024 Atlantic hurricane season, expected to make landfall in north Mexico on Thursday.

## Climate activists arrested after spray painting UK’s Stonehenge monument
 - [https://www.aljazeera.com/news/2024/6/19/climate-activists-arrested-after-spray-painting-uks-stonehenge-monument?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/climate-activists-arrested-after-spray-painting-uks-stonehenge-monument?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T18:39:14+00:00

UK police say they arrested two people &#039;on suspicion of damaging&#039; the prehistoric UNESCO World Heritage Site.

## ‘A lack of trust’: How deepfakes and AI could rattle the US elections
 - [https://www.aljazeera.com/news/2024/6/19/a-lack-of-trust-how-deepfakes-and-ai-could-rattle-the-us-elections?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/a-lack-of-trust-how-deepfakes-and-ai-could-rattle-the-us-elections?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T18:02:31+00:00

At least 20 states have passed regulations against election deepfakes, but federal action remains stalled.

## Russia’s Putin praises Vietnam for its ‘balanced’ stance on Ukraine
 - [https://www.aljazeera.com/news/2024/6/19/russias-putin-praises-vietnam-for-its-balanced-stance-on-ukraine?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/russias-putin-praises-vietnam-for-its-balanced-stance-on-ukraine?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T17:56:36+00:00

Putin hails Vietnam for backing &#039;a pragmatic way to solve the crisis&#039; in Ukraine in an op-ed released before his visit.

## Video shows Hindu mob attacking Muslim-owned shop in India
 - [https://www.aljazeera.com/program/newsfeed/2024/6/19/video-shows-hindu-mob-attacking-muslim-owned-shop-in-india?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/19/video-shows-hindu-mob-attacking-muslim-owned-shop-in-india?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T17:51:59+00:00

Video captured a Hindu mob ransacking the clothing shop of a Muslim man in Nahan, India.

## US elections 2024: Who will be Donald Trump’s vice president?
 - [https://www.aljazeera.com/news/2024/6/19/us-elections-2024-who-will-be-donald-trumps-vice-president?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/us-elections-2024-who-will-be-donald-trumps-vice-president?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T17:45:05+00:00

Several names are on Trump&#039;s shortlist, with the ex-president set to unveil his pick before or at July&#039;s GOP convention.

## “The Israeli army is one of the most criminal in the world” says UN expert
 - [https://www.aljazeera.com/program/newsfeed/2024/6/19/the-israeli-army-is-one-of-the-most-criminal-in-the-world-says-un-expert?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/19/the-israeli-army-is-one-of-the-most-criminal-in-the-world-says-un-expert?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T16:52:16+00:00

“The Israeli army is one of the most criminal armies in the world” Chris Sidoti, a member of the UN’s COI told reporters

## Shipping industry groups call for action after Houthis sink second vessel
 - [https://www.aljazeera.com/news/2024/6/19/shipping-industry-groups-call-for-action-after-houthis-sink-second-vessel?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/shipping-industry-groups-call-for-action-after-houthis-sink-second-vessel?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T16:14:58+00:00

Organisations decry the &#039;unacceptable situation&#039; of assaults by Yemeni group against vessels in the Red Sea.

## ‘Never seen anything like this’: UN Commission of Inquiry on Israel-Gaza
 - [https://www.aljazeera.com/program/newsfeed/2024/6/19/never-seen-anything-like-this-un-commission-of-inquiry-on-israel-gaza?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/19/never-seen-anything-like-this-un-commission-of-inquiry-on-israel-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T16:05:21+00:00

Navi Pillay of the UN Commission of Inquiry said that her team has submitted 7,000 pieces of evidence to the ICC.

## Whitehawk’s Football Ultras
 - [https://www.aljazeera.com/program/al-jazeera-world/2024/6/19/whitehawks-football-ultras?traffic_source=rss](https://www.aljazeera.com/program/al-jazeera-world/2024/6/19/whitehawks-football-ultras?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T16:00:23+00:00

The small, non-league English football club uses its loyal fandom to oppose all forms of injustice.

## Euro 2024: by the numbers – Ronaldo on target and the Germans are efficient
 - [https://www.aljazeera.com/sports/2024/6/19/euro-2024-by-the-numbers-ronaldo-on-target-and-the-germans-are-efficient?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/19/euro-2024-by-the-numbers-ronaldo-on-target-and-the-germans-are-efficient?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T14:50:12+00:00

Star footballer Cristiano Ronaldo may not have kicked a goal at Euro 2024 yet - but that&#039;s not for a lack of attempts.

## Biden’s new immigration plan: How will it work?
 - [https://www.aljazeera.com/news/2024/6/19/bidens-new-immigration-plan-how-will-it-work?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/bidens-new-immigration-plan-how-will-it-work?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T14:33:23+00:00

Ahead of the 2024 election, Biden gives some undocumented migrants a pathway to US citizenship.

## In a smuggler paradise on Tunisia-Libya border, closure wrecks livelihoods
 - [https://www.aljazeera.com/news/2024/6/19/in-a-smuggler-paradise-on-tunisia-libya-border-closure-wrecks-livelihoods?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/in-a-smuggler-paradise-on-tunisia-libya-border-closure-wrecks-livelihoods?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T14:07:22+00:00

The people of Ben Guerdane survived off the Ras Jadir border crossing. Its closure hurt them, badly.

## West Indies vs England – T20 World Cup Super Eight: Teams, pitch, form
 - [https://www.aljazeera.com/sports/2024/6/19/west-indies-vs-england-t20-world-cup-super-eight-teams-pitch-form-h2h?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/19/west-indies-vs-england-t20-world-cup-super-eight-teams-pitch-form-h2h?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T14:01:46+00:00

The two most successful T20 teams go head-to-head in a mighty Super Eights clash in Saint Lucia.

## Video: South Africa’s Ramaphosa hails ‘new era’ at inauguration
 - [https://www.aljazeera.com/program/newsfeed/2024/6/19/video-south-africas-ramaphosa-hails-new-era-at-inauguration?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/19/video-south-africas-ramaphosa-hails-new-era-at-inauguration?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T13:57:11+00:00

South Africa’s President Cyril Ramaphosa has been sworn in for his second full term in office.

## Afghanistan – Land of Contrasts
 - [https://www.aljazeera.com/program/between-us/2024/6/19/afghanistan-land-of-contrasts?traffic_source=rss](https://www.aljazeera.com/program/between-us/2024/6/19/afghanistan-land-of-contrasts?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T13:11:47+00:00

&quot;Whoever goes to Afghanistan has one story that they will probably remember for the rest of their lives.&quot;

## Will the tariff row between the EU and China spark a trade war?
 - [https://www.aljazeera.com/program/counting-the-cost/2024/6/19/will-the-tariff-row-between-the-eu-and-china-spark-a-trade-war?traffic_source=rss](https://www.aljazeera.com/program/counting-the-cost/2024/6/19/will-the-tariff-row-between-the-eu-and-china-spark-a-trade-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T12:50:22+00:00

Main political parties have laid out their economic plans in election manifestos.

## Football brings hope to injured and traumatised children from Gaza
 - [https://www.aljazeera.com/program/newsfeed/2024/6/19/football-brings-hope-to-injured-and-traumatised-children-from-gaza?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/19/football-brings-hope-to-injured-and-traumatised-children-from-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T12:48:45+00:00

After his dream of being a football player was crushed by the war, this Palestinian has a new goal of becoming a coach.

## ‘New era’: Ramaphosa sworn in as South Africa’s president for second term
 - [https://www.aljazeera.com/news/2024/6/19/new-era-ramaphosa-sworn-in-as-south-africas-president-for-second-term?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/new-era-ramaphosa-sworn-in-as-south-africas-president-for-second-term?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T12:45:52+00:00

ANC leader now set to appoint cabinet featuring his weakened party and coalition partners in unity government.

## What is a heat dome?
 - [https://www.aljazeera.com/program/newsfeed/2024/6/19/what-is-a-heat-dome?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/19/what-is-a-heat-dome?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T12:24:42+00:00

More than 75 million people across the United States are under heat alerts as temperatures soar.

## New Caledonia police arrest pro-independence leader over deadly protests
 - [https://www.aljazeera.com/news/2024/6/19/new-caledonia-police-arrest-pro-independence-leader-over-deadly-protests?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/new-caledonia-police-arrest-pro-independence-leader-over-deadly-protests?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T12:23:33+00:00

Christian Tein is accused of instigating riots against French rule last month that killed nine people.

## Israel’s actions in Gaza ‘intentional attack on civilians’: UN inquiry
 - [https://www.aljazeera.com/news/2024/6/19/israels-actions-in-gaza-intentional-attack-on-civilians-un-inquiry?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/israels-actions-in-gaza-intentional-attack-on-civilians-un-inquiry?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T12:17:13+00:00

New report says Israeli military and Palestinian groups committed war crimes and rights abuses since October 7.

## Why is Russia’s Putin visiting Vietnam after North Korea?
 - [https://www.aljazeera.com/news/2024/6/19/why-is-russias-putin-visiting-vietnam-after-north-korea?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/why-is-russias-putin-visiting-vietnam-after-north-korea?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T12:14:22+00:00

Vietnam is a rising nation the West wants closer ties with. The visit is a signal from Russia: Putin isn&#039;t isolated.

## Landslides kill at least 15, displace millions, in Bangladesh and India
 - [https://www.aljazeera.com/news/2024/6/19/landslides-kill-at-least-15-displace-millions-in-bangladesh-and-india?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/landslides-kill-at-least-15-displace-millions-in-bangladesh-and-india?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T11:48:23+00:00

Hundreds of thousands are stranded by flash floods and heavy rain with refugee camps for Rohingya Muslims most affected.

## Beware of Vietnam’s new authoritarian president
 - [https://www.aljazeera.com/opinions/2024/6/19/beware-of-vietnams-new-authoritarian-president?traffic_source=rss](https://www.aljazeera.com/opinions/2024/6/19/beware-of-vietnams-new-authoritarian-president?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T11:38:34+00:00

To Lam&#039;s rise to power is indicative of the Vietnam government’s worsening repression.

## Video: This Gaza amusement park is filled with displaced Palestinians
 - [https://www.aljazeera.com/program/newsfeed/2024/6/19/video-this-gaza-amusement-park-is-filled-with-displaced-palestinians?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/19/video-this-gaza-amusement-park-is-filled-with-displaced-palestinians?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T11:31:19+00:00

One of Gaza’s biggest amusement parks has become an informal camp for forcibly displaced Palestinians seeking refuge.

## Civil war in Sudan takes centre stage at UN
 - [https://www.aljazeera.com/news/2024/6/19/civil-war-in-sudan-takes-centre-stage-at-un?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/civil-war-in-sudan-takes-centre-stage-at-un?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T10:55:15+00:00

UN report from January cited &#039;credible&#039; evidence outside forces may be arming paramilitary.

## Sudan accuses UAE of fuelling civil war with arms supplies
 - [https://www.aljazeera.com/news/2024/6/19/sudan-accuses-uae-of-fuelling-civil-war-with-arms-supplies?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/sudan-accuses-uae-of-fuelling-civil-war-with-arms-supplies?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T10:55:15+00:00

Report by UN experts in January found &#039;credible&#039; evidence that United Arab Emirates has been arming RSF paramilitary.

## As big pharma exits Nigeria, asthma patients face spiralling costs
 - [https://www.aljazeera.com/features/2024/6/19/as-big-pharma-exits-nigeria-asthma-patients-face-spiralling-costs?traffic_source=rss](https://www.aljazeera.com/features/2024/6/19/as-big-pharma-exits-nigeria-asthma-patients-face-spiralling-costs?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T10:42:04+00:00

Price of asthma inhalers has more than doubled amid scarcity and added costs after GSK exited Nigerian market in 2023.

## USA vs South Africa – T20 World Cup Super Eight: Teams, pitch, weather
 - [https://www.aljazeera.com/sports/2024/6/19/usa-vs-south-africa-t20-world-cup-super-eight-teams-pitch-weather-h2h-conditions-form?traffic_source=rss](https://www.aljazeera.com/sports/2024/6/19/usa-vs-south-africa-t20-world-cup-super-eight-teams-pitch-weather-h2h-conditions-form?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T09:57:51+00:00

USA will look to build on their success and cause another upset against favourites South Africa at North Sound, Antigua.

## Russia jails US soldier as it dangles prisoner swap deal
 - [https://www.aljazeera.com/news/2024/6/19/russia-jails-us-soldier-as-it-dangles-prisoner-swap-deal?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/russia-jails-us-soldier-as-it-dangles-prisoner-swap-deal?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T09:27:28+00:00

Sentence expands list of US citizens detained in Russia as Moscow says awaiting response on prisoner swap proposals.

## Four people killed, at least a dozen missing as extreme weather hits China
 - [https://www.aljazeera.com/gallery/2024/6/19/four-people-killed-over-a-dozen-missing-as-extreme-weather-hits-china?traffic_source=rss](https://www.aljazeera.com/gallery/2024/6/19/four-people-killed-over-a-dozen-missing-as-extreme-weather-hits-china?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T09:04:52+00:00

Record-breaking rains cause intense flooding in the south, while the north reels from drought and high temperatures.

## North Korea welcomes Russian President Vladimir Putin with big ceremony
 - [https://www.aljazeera.com/program/newsfeed/2024/6/19/north-korea-welcomes-putin-with-big-ceremony?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/19/north-korea-welcomes-putin-with-big-ceremony?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T08:42:29+00:00

This is the welcome ceremony North Korea held for Russian President Vladimir Putin&#039;s first visit there in 24 years.

## In Scotland, support grows for Labour as SNP’s dominance looks set to fade
 - [https://www.aljazeera.com/news/2024/6/19/in-scotland-support-grows-for-labour-as-snps-dominance-looks-set-to-fade?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/in-scotland-support-grows-for-labour-as-snps-dominance-looks-set-to-fade?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T08:34:37+00:00

Although independence remains a popular idea, Labour is viewed by many as the strongest party to oust the Conservatives.

## China and Malaysia deepen ties with renewed economic pact
 - [https://www.aljazeera.com/news/2024/6/19/china-and-malaysia-deepen-ties-with-renewed-economic-pact?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/china-and-malaysia-deepen-ties-with-renewed-economic-pact?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T08:22:42+00:00

Deal signed as China seeks to raise influence in Asia Pacific region amid rising geopolitical tension.

## Israel ready for ‘all-out war’ in Lebanon
 - [https://www.aljazeera.com/news/2024/6/19/israel-ready-for-all-out-war-in-lebanon?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/israel-ready-for-all-out-war-in-lebanon?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T07:52:09+00:00

The Israeli military says it has approved operational plans for an offensive against Hezbollah.

## Explosions as fire rips through Chad weapons depot
 - [https://www.aljazeera.com/program/newsfeed/2024/6/19/explosions-as-fire-rips-through-chad-weapons-depot?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/6/19/explosions-as-fire-rips-through-chad-weapons-depot?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T07:40:07+00:00

A fire at a weapons depot in Chad sent a series of explosions near the international airport in the capital N&#039;Djamena.

## Russia’s Vladimir Putin visits North Korea for first time since 2000
 - [https://www.aljazeera.com/gallery/2024/6/19/russias-vladimir-putin-visits-north-korea-for-first-time-since-2000?traffic_source=rss](https://www.aljazeera.com/gallery/2024/6/19/russias-vladimir-putin-visits-north-korea-for-first-time-since-2000?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T03:58:54+00:00

Russian and North Korean leaders aim to deepen ties as both countries face isolation.

## McDonald’s scraps AI pilot after order mix-ups go viral
 - [https://www.aljazeera.com/economy/2024/6/19/mcdonalds-scrap-ai-pilot-at-drive-through-outlets-after-order-mix-ups?traffic_source=rss](https://www.aljazeera.com/economy/2024/6/19/mcdonalds-scrap-ai-pilot-at-drive-through-outlets-after-order-mix-ups?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T03:24:48+00:00

Fast food giant pulls plug on AI-powered voice-ordering at about 100 outlets after viral videos of order mishaps.

## ‘Our house was shaking’: Chad ammunition depot fire triggers explosions
 - [https://www.aljazeera.com/news/2024/6/19/our-house-was-shaking-chad-ammunition-depot-fire-triggers-explosions?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/our-house-was-shaking-chad-ammunition-depot-fire-triggers-explosions?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T02:25:26+00:00

President Mahamat Idriss Deby Itno says there have been deaths and injuries but does not specify the number.

## Nvidia becomes world’s most valuable company, dethroning Microsoft
 - [https://www.aljazeera.com/economy/2024/6/19/nvidia-becomes-worlds-most-valuable-company-dethroning-microsoft?traffic_source=rss](https://www.aljazeera.com/economy/2024/6/19/nvidia-becomes-worlds-most-valuable-company-dethroning-microsoft?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T01:25:25+00:00

Chip giant&#039;s market capitalisation hits $3.335 trillion as stock prices continues its stellar rise.

## Russia-Ukraine war: List of key events, day 845
 - [https://www.aljazeera.com/news/2024/6/19/russia-ukraine-war-list-of-key-events-day-845?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/russia-ukraine-war-list-of-key-events-day-845?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T01:24:38+00:00

As the war enters its 845th day, these are the main developments.

## Putin flies into Pyongyang to waiting Kim and red carpet welcome
 - [https://www.aljazeera.com/news/2024/6/19/putin-flies-into-pyongyang-to-waiting-kim-and-red-carpet-welcome?traffic_source=rss](https://www.aljazeera.com/news/2024/6/19/putin-flies-into-pyongyang-to-waiting-kim-and-red-carpet-welcome?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-06-19T00:44:36+00:00

North Korea says Russian leader&#039;s visit is a historic event showing the &#039;invincibility&#039; of the two countries&#039; ties.

