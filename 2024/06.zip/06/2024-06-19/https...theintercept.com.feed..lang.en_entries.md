# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## War Clouds Over Lebanon as Hezbollah and Israel Clash
 - [https://theintercept.com/2024/06/19/intercepted-podcast-israel-lebanon-hezbollah](https://theintercept.com/2024/06/19/intercepted-podcast-israel-lebanon-hezbollah)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-06-19T10:00:00+00:00

<p>Crossfire between Israel and Hezbollah intensified last week, with the Lebanese militia calling for a Gaza ceasefire.</p>
<p>The post <a href="https://theintercept.com/2024/06/19/intercepted-podcast-israel-lebanon-hezbollah/">War Clouds Over Lebanon as Hezbollah and Israel Clash</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

