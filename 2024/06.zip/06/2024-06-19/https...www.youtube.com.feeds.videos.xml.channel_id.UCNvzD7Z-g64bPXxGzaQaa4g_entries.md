# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Watch Dogs 1 in 2024 is NOT THE SAME GAME
 - [https://www.youtube.com/watch?v=FfyS9i7YV9s](https://www.youtube.com/watch?v=FfyS9i7YV9s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-06-19T16:25:36+00:00

Watch_Dogs is worth replaying/revisiting with mods.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1

~~SOURCES~~

news story about the graphical 'downgrade' - https://www.gamespot.com/articles/watch-dogs-visuals-have-not-been-downgraded-ubisoft-says/1100-6418171/

original e3 2012 trailer - https://www.youtube.com/watch?v=xU7WGAJPRRw

full E3 2012 Ubisoft Show - https://www.youtube.com/watch?v=_-JRivOZz2w

Watch Dogs metacritic - https://www.metacritic.com/game/watch-dogs/

living city mod - https://www.nexusmods.com/watchdogs/mods/81

The Fall of Windy City - A lighting Overhaul - https://www.nexusmods.com/watchdogs/mods/156

Nextgen graphics overhaul - https://www.nexusmods.com/watchdogs/mods/128?tab=posts

(look at 'posts' to explain how to merge this and 'living city' )

watchdogs mod installer - https://www.nexusmods.com/watchdogs/mods/15

Watch dogs definitive e3 mod 2012 reimagining - https://www.nexusmods.com/watchdogs/mods/209?tab=posts

