# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Watch CNN Hosts LOSE IT As They Accidentally Reveal This About Trump
 - [https://www.youtube.com/watch?v=0lG8ugiLC4Q](https://www.youtube.com/watch?v=0lG8ugiLC4Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-06-19T20:06:52+00:00

Wake up everyday and choose freedom, order at https://1775coffee.com/BRAND

Corporate media has spent 8 years, in consensus, branding Trump a racist and White Nationalist. Meanwhile, actual Black voters are migrating away from Dems/Biden to Trump in what even CNN is describing as a historic shift 

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

All links: https://linktr.ee/RussellBrand

## CNN Reporter HUMILIATED By This Fact When Trying To SHUT DOWN Tucker Tour
 - [https://www.youtube.com/watch?v=Wq-LhHw-Aqk](https://www.youtube.com/watch?v=Wq-LhHw-Aqk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-06-19T17:36:01+00:00

Contact Zero Debt USA to see how they can help: https://www.zapmydebt.com/

Wake up everyday and choose freedom, order at https://1775coffee.com/BRAND

As CNN try to shut down Tucker Carlson’s upcoming tour, they endorse Ticketmaster shows by war criminals The Clintons. 

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

All links: https://linktr.ee/RussellBrand

## Kansas just SUED Pfizer over COVID Vaccine Safety Claims. What’s next!? - Stay Free 389
 - [https://www.youtube.com/watch?v=rqtKbMvaLgc](https://www.youtube.com/watch?v=rqtKbMvaLgc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-06-19T17:08:50+00:00

Contact Zero Debt USA to see how they can help: https://www.zapmydebt.com/

Order your Contagion Kit today at http://www.twc.health/BRAND use code BRAND for 10% off + FREE SHIPPING.

Join us here for a PREVIEW of our daily one-hour RUMBLE show. 
To continue watching the show in full, join me exclusively over on RUMBLE: https://bit.ly/stayfree389-YTLIVE

On today’s episode, I’ll be discussing Kansas suing Pfizer due to allegedly ‘misleading the public’ on vaccine safety,  500,000 NATO Troops are on High Readiness for War With Russia, Vaccine companies paid $79 billion in criminal penalties, Justin Timberlake has been done for drink driving, Biden malfunctions and Steve Bannon will be serving time with violent criminals and ‘sex offenders’. But what’s really going on behind all of this? Watch the show for more!

Check out social medias and more - https://linktr.ee/RussellBrand

