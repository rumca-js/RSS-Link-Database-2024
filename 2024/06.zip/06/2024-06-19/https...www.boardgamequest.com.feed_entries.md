# Source:Board Game Quest, URL:https://www.boardgamequest.com/feed, language:en-US

## World Wonders Mundo Expansion Pack Giveaway
 - [https://www.boardgamequest.com/world-wonders-mundo-expansion-pack-giveaway](https://www.boardgamequest.com/world-wonders-mundo-expansion-pack-giveaway)
 - RSS feed: https://www.boardgamequest.com/feed
 - date published: 2024-06-19T15:44:53+00:00

<img alt="World Wonder Mundo Pack Giveaway" class="webfeedsFeaturedVisual wp-post-image" height="337" src="https://www.boardgamequest.com/wp-content/uploads/2024/06/World-Wonders-Giveaway-1024x539.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="640" />World Wonders was one of the hit board games from 2023 and Arcane Wonders is back again with a new expansion pack! If you missed it last week, we posted our review of what&#8217;s new in the Mundo Pack. The short answer is more wonders and a new way for them to score! All good [&#8230;]
<p><a href="https://www.boardgamequest.com/world-wonders-mundo-expansion-pack-giveaway/" rel="nofollow">Source</a></p>

## Xylotar Review
 - [https://www.boardgamequest.com/xylotar-review](https://www.boardgamequest.com/xylotar-review)
 - RSS feed: https://www.boardgamequest.com/feed
 - date published: 2024-06-19T12:38:13+00:00

<img alt="Xylotar" class="webfeedsFeaturedVisual wp-post-image" height="889" src="https://www.boardgamequest.com/wp-content/uploads/2024/06/Xylotar-737x1024.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="640" />Bobby McColdsnap is a synth loving polar bear who wanted to play the keytar. According to the rulebook he acquired this love from some fictional song&#8230; I presume the real truth is he jammed out to Edgar Winter Group’s Frankenstein. That small fact check aside, it&#8217;s undoubted that the polar bear had keytar-jamming aspirations. But, [&#8230;]
<p><a href="https://www.boardgamequest.com/xylotar-review/" rel="nofollow">Source</a></p>

