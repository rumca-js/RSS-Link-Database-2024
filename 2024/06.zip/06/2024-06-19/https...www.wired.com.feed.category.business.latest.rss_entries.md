# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Adobe Says It Won't Train AI Using Artists' Work. Creatives Aren't Convinced
 - [https://www.wired.com/story/adobe-says-it-wont-train-ai-using-artists-work-creatives-arent-convinced](https://www.wired.com/story/adobe-says-it-wont-train-ai-using-artists-work-creatives-arent-convinced)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2024-06-19T17:59:56+00:00

Adobe has issued new wording to explain how users' content will be treated, after a backlash earlier this month from artists who believed their work will be used to train AI.

