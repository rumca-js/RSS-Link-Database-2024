# Source:RP - Edukacja, URL:https://edukacja.rp.pl/rss/8681-edukacja, language:pl-PL

## Pieniądze z rządowego programu dla szkół skończyły się w 12 minut
 - [https://edukacja.rp.pl/oswiata/art40669841-pieniadze-z-rzadowego-programu-dla-szkol-skonczyly-sie-w-12-minut](https://edukacja.rp.pl/oswiata/art40669841-pieniadze-z-rzadowego-programu-dla-szkol-skonczyly-sie-w-12-minut)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-06-19T17:20:22+00:00

Okazuje się, że kwota przygotowana na dofinansowanie szkolnych wycieczek była zbyt niska w stosunku do zainteresowania programem.

## W jakim kierunku będzie podążać polska oświata w nowym roku szkolnym?
 - [https://edukacja.rp.pl/szkoly-podstawowe-i-srednie/art40662711-w-jakim-kierunku-bedzie-podazac-polska-oswiata-w-nowym-roku-szkolnym](https://edukacja.rp.pl/szkoly-podstawowe-i-srednie/art40662711-w-jakim-kierunku-bedzie-podazac-polska-oswiata-w-nowym-roku-szkolnym)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-06-19T05:26:00+00:00

Edukacja prozdrowotna, wychowanie obywatelskie, edukacja dla bezpieczeństwa i pro obronna, rozwój kompetencji cyfrowych i dobrostan uczniów znalazły się wśród priorytetów polityki oświatowej państwa w roku szkolnym 2024/2025.

