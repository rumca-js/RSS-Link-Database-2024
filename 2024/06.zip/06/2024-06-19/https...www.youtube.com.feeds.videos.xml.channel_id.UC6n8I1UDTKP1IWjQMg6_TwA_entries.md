# Source:The B1M, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC6n8I1UDTKP1IWjQMg6_TwA, language:en

## How to Dismantle a Nuclear Reactor
 - [https://www.youtube.com/watch?v=31FzwWKvSOY](https://www.youtube.com/watch?v=31FzwWKvSOY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC6n8I1UDTKP1IWjQMg6_TwA
 - date published: 2024-06-19T10:55:51+00:00

Step inside the complex world of nuclear decommissioning.
Skip the waitlist and invest in blue-chip art for the very first time by signing up for Masterworks - https://www.masterworks.art/theb1m

This video contains paid promotion for Masterworks. Purchase shares in great masterpieces from artists like Pablo Picasso, Banksy, Andy Warhol, and more. See important Masterworks disclosures - https://www.masterworks.com/cd

Full story here - https://www.theb1m.com/video/how-to-dismantle-a-nuclear-reactor

Additional footage and images courtesy of EBRD, IAEA, JAVYS, Entenergy Corporation, Georgia Power, Ultra Safe Nuclear and U.S. Department of Energy.

Research sources:
https://www.javys.sk/en/
https://www.ebrd.com/what-we-do/sectors/nuclear-safety/bohunice.html
https://www.iaea.org/bulletin/decommissioning-by-design-how-advanced-reactors-are-designed-with-disposal-in-mind
https://www.world-nuclear-news.org/Articles/Bohunice-reactors-fully-dismantled-in-decommissioi
https://edition.cnn.com/

## Dismantling a NUCLEAR Reactor
 - [https://www.youtube.com/watch?v=OubkzEAK5Zo](https://www.youtube.com/watch?v=OubkzEAK5Zo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC6n8I1UDTKP1IWjQMg6_TwA
 - date published: 2024-06-19T07:23:02+00:00



