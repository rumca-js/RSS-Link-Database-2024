# Source:GameLinked, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHDxYLv8iovIbhrfl16CNyg, language:en

## Which summer gaming showcase was best? - Gamers 2 Gamers
 - [https://www.youtube.com/watch?v=XgezTjJRpIo](https://www.youtube.com/watch?v=XgezTjJRpIo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHDxYLv8iovIbhrfl16CNyg
 - date published: 2024-06-19T21:00:04+00:00

We saw #xbox, we saw #summergamefest, and...#ubisoft was there too

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► LISTEN TO THE GAMING NEWS: https://lmg.gg/GameLinkedPodcast
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► WHERE WE BUY GAMES: https://lmg.gg/shopgames

## You Can Play As Zelda…
 - [https://www.youtube.com/watch?v=oOHizOGWVBo](https://www.youtube.com/watch?v=oOHizOGWVBo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHDxYLv8iovIbhrfl16CNyg
 - date published: 2024-06-19T04:11:02+00:00

Check out iFixit’s options for laptop repairs, including replacement batteries and SSDs, at https://ifix.gd/GameLinked

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► LISTEN TO THE GAMING NEWS: https://lmg.gg/GameLinkedPodcast
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► WHERE WE BUY GAMES: https://lmg.gg/shopgames

NEWS SOURCES: https://lmg.gg/zmBzA
-------------------------------------------------------------------
Timestamps:
0:00 i WISH
0:08 Nintendo Direct - Zelda, Metroid Prime 4
1:57 Todd Howard responds to Starfield fans
3:10 Game studio closures anger Shawn Layden
4:48 QUICK BITS INTRO
4:56 Elden Ring Shadow of the Erdtree reviews
5:44 A Quiet Place: The Road Ahead
6:08 Playstation Portal Public Wi-Fi update
6:49 Age of Pirates: Captain Blood
7:29 Helldivers 2 players save kids

