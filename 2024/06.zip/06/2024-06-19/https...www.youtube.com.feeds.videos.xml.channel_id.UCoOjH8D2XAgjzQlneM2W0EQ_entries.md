# Source:Jake Tran, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ, language:en-US

## How L’Oreal Poisoned the World
 - [https://www.youtube.com/watch?v=agK3EZv8Q44](https://www.youtube.com/watch?v=agK3EZv8Q44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCoOjH8D2XAgjzQlneM2W0EQ
 - date published: 2024-06-19T15:15:00+00:00

🍦 Click HERE to get our Evil Goods All-Natural Moisturizer! https://amzn.to/45c8wlU

📈 Do you watch YouTube? If you do, I’m looking for a few more people to work closely with, who want to earn a full-time income without showing their face. If you’re interested, DM me “YOUTUBE” on my Instagram: https://www.instagram.com/jaketran/

😈 Watch exclusive documentaries that are too controversial to ever be released to the public: https://jake.yt/join 
Updated refund policy: Email us within your first month of joining and we'll refund you for your first month. There is no refund if you cancel at a later time.

📹 Take a peak at all the private documentaries here: https://jake.yt/hidden-vids

🟢 Watch and listen to our videos on Spotify! https://jake.yt/spotify

🐤 Follow me on Twitter: @jaketrann https://jake.yt/x
📸 Follow me on IG: @jaketran https://jake.yt/IG
Please watch out for fake IG accounts. I will never message you asking for money or to invest. My IG account is spelled exactly like this

