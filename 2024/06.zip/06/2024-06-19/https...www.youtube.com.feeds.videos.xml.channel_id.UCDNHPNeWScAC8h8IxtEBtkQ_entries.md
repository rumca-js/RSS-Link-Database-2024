# Source:EonsOfBattle, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDNHPNeWScAC8h8IxtEBtkQ, language:en

## Can I Make THIS Space Marine Kit Look Good?
 - [https://www.youtube.com/watch?v=AiHeWtlsoag](https://www.youtube.com/watch?v=AiHeWtlsoag)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDNHPNeWScAC8h8IxtEBtkQ
 - date published: 2024-06-19T10:00:08+00:00

https://www.cobaltkeep.com/shop
Coupon Code: EOB20 for 20% off Detail and Sprue Nippers!
Thanks to Cobalt Keep for helping us continue to create great videos!

In this video Jay tackles the Warhammer 40k Space Marine Primaris ATV! We have new videos every Monday, Wednesday and Friday!

We have a Patreon! Support us here and get more content!:
https://www.patreon.com/eonsofbattle

We make lots of 3D Models and Terrain for your table:
https://comicsgamesandthings.com/shop/?partner=eons-of-battle
https://www.myminifactory.com/users/eonsofbattle

https://eonsofbattle.co/
Help Support the Show in Style! T-Shirts and Sweatshirts Available!
Buy two or more items and get free shipping!

We also do the occastional live stream!
https://www.twitch.tv/eonsofbattle

Discord Server:
https://discord.gg/ymhENeyFTP

Check Out Our Live Streams!:
https://youtube.com/playlist?list=PLX1fXqW4h5RQi83twKZ4S-AmO0tytlhB0

EonsOfBattle Instagram:
https://www.instagram.com/eonsofbattle/

EonsOfBattle Facebook Pa

