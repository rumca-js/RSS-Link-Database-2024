# Source:RP - Edukacja, URL:https://edukacja.rp.pl/rss/8681-edukacja, language:pl-PL

## Uczestniczka Powstania Warszawskiego Wanda Traczyk-Stawska Damą Orderu Uśmiechu
 - [https://edukacja.rp.pl/oswiata/art40167491-uczestniczka-powstania-warszawskiego-wanda-traczyk-stawska-dama-orderu-usmiechu](https://edukacja.rp.pl/oswiata/art40167491-uczestniczka-powstania-warszawskiego-wanda-traczyk-stawska-dama-orderu-usmiechu)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-04-15T13:58:34+00:00

Uczestniczka Powstania Warszawskiego Wanda Traczyk-Stawska ps. Pączek została uhonorowana Międzynarodowym Orderem Uśmiechu. To jedyne odznaczenie na świecie to jest przyznawane na wniosek dzieci.

