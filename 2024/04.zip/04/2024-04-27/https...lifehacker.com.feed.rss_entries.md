# Source:LifeHacker, URL:https://lifehacker.com/feed/rss, language:en-us

## 50 Movies That Are Basically Perfect
 - [https://lifehacker.com/movies-that-are-basically-perfect](https://lifehacker.com/movies-that-are-basically-perfect)
 - RSS feed: https://lifehacker.com/feed/rss
 - date published: 2024-04-27T12:00:00+00:00

From The Seventh Seal to The Sixth Sense, these movies hold up to endless rewatches.

