# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en

## 'You can’t shoot your dog and then be VP:’ Dems, GOP bash Kristi Noem over memoir
 - [https://www.politico.com/news/2024/04/27/dems-gop-bash-kristi-noem-memoir-00154789](https://www.politico.com/news/2024/04/27/dems-gop-bash-kristi-noem-memoir-00154789)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-04-27T17:08:48+00:00

The South Dakota governor has seen her political caché skyrocket in recent years and is reportedly a top contender to become Donald Trump’s 2024 running mate.

