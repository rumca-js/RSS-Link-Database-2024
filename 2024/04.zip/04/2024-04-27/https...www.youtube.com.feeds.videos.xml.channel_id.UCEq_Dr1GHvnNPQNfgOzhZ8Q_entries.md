# Source:Solid jj, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q, language:en-US

## Yu-Gi-Oh GX Brainrot
 - [https://www.youtube.com/watch?v=yR4jTVpD4R0](https://www.youtube.com/watch?v=yR4jTVpD4R0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q
 - date published: 2024-04-27T19:00:22+00:00

One glance at the Yu-Gi-Oh GX wiki page is enough to destroy a man.

10% Gamer Supps (Code: SOLID) ▼
https://gamersupps.gg/SOLID

Ad Animation by ​⁠@Crashgen 

Podcast: ​⁠@JoeSchmoesPodcast 

Second channel: ​⁠@Solidusjj 
Patreon: https://patreon.com/solidjj
BadTakeDelete Discord: https://discord.gg/X5ttfJR6es

