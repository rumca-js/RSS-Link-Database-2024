# Source:Home - CBSNews.com, URL:https://www.cbsnews.com/latest/rss/main, language:en

## Transcript: Senate Minority Leader Mitch McConnell on "Face the Nation"
 - [https://www.cbsnews.com/news/transcript-senate-minority-leader-mitch-mcconnell-face-the-nation-april-28-2024](https://www.cbsnews.com/news/transcript-senate-minority-leader-mitch-mcconnell-face-the-nation-april-28-2024)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T22:12:46+00:00

The following is a transcript of an interview with Senate Minority Leader Mitch McConnell that will air on April 28, 2024.

## Hamas releases propaganda video of two hostages, including U.S. citizen
 - [https://www.cbsnews.com/news/hamas-releases-propaganda-video-of-two-hostages-omri-miran-keith-siegel](https://www.cbsnews.com/news/hamas-releases-propaganda-video-of-two-hostages-omri-miran-keith-siegel)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T20:31:00+00:00

The hostages seen on the video were identified as Omri Miran and Keith Siegel by the campaign group the Hostages and Missing Families Forum.

## 4/27: Saturday Morning
 - [https://www.cbsnews.com/video/042724-cbs-saturday-morning](https://www.cbsnews.com/video/042724-cbs-saturday-morning)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T19:13:32+00:00

Recap of former president Donald Trump's New York trial; Chef works to bring unique flavors to over 30 cruise ship restaurants.

## Detroit sets NFL Draft attendance record with more than 700,00 fans
 - [https://www.cbsnews.com/news/detroit-sets-nfl-draft-attendance-record-with-more-than-70000-fans-attending](https://www.cbsnews.com/news/detroit-sets-nfl-draft-attendance-record-with-more-than-70000-fans-attending)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T18:35:00+00:00

The NFL draft has a new attendance record after more than 700,000 fans flooded downtown Detroit for the three-day event.

## United Auto Workers reaches deal with Daimler Truck, averting potential strike
 - [https://www.cbsnews.com/news/united-auto-workers-reaches-deal-daimler-truck](https://www.cbsnews.com/news/united-auto-workers-reaches-deal-daimler-truck)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T17:41:09+00:00

The union struck a four-year agreement with the German company on Friday evening, just before the expiration of the previous contract.

## Clean up begins after tornadoes hammer parts of Iowa and Nebraska
 - [https://www.cbsnews.com/news/tornado-storm-clean-up-iowa-nebraska-midwest](https://www.cbsnews.com/news/tornado-storm-clean-up-iowa-nebraska-midwest)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T17:29:00+00:00

There have been several injuries linked to tornadoes on Friday, but no fatalities have been reported.

## Iraqi social media influencer shot dead in Baghdad
 - [https://www.cbsnews.com/news/iraq-investigating-killing-um-fahad-social-media-influencer](https://www.cbsnews.com/news/iraq-investigating-killing-um-fahad-social-media-influencer)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T17:20:15+00:00

Iraqi authorities are investigating the killing of a well-known social media influencer Um Fahad who was shot by an armed motorcyclist in front of her home in central Baghdad.

## Republic First Bank closes, first FDIC-insured bank to fail in 2024
 - [https://www.cbsnews.com/news/republic-bank-failure-fulton-bank-pa-nj-ny-fdic](https://www.cbsnews.com/news/republic-bank-failure-fulton-bank-pa-nj-ny-fdic)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T16:27:34+00:00

Regulators have closed Republic First Bank's 32 branches in Pennsylvania, New Jersey and New York and they will be taken over by Fulton Bank.

## One mountain climber dead, another injured after thousand-foot fall
 - [https://www.cbsnews.com/news/climber-dead-injured-denali-alaska](https://www.cbsnews.com/news/climber-dead-injured-denali-alaska)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T16:21:17+00:00

Another climbing party saw the pair fall and cared for the surviving climber until help arrived the next morning.

## Chef works to bring unique flavors to over 30 cruise ship restaurants
 - [https://www.cbsnews.com/video/chef-works-to-bring-unique-flavors-to-over-30-cruise-ship-restaurants](https://www.cbsnews.com/video/chef-works-to-bring-unique-flavors-to-over-30-cruise-ship-restaurants)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T15:55:34+00:00

Alexis Quaretti is the executive culinary director of Oceania Cruises and oversees more than 30 restaurants across the cruise line's fleet of ships. Michelle Miller has more.

## Hamas is reviewing Israel cease-fire proposal
 - [https://www.cbsnews.com/news/hamas-israel-cease-fire-proposal-reviewed-pressure-for-peace-mounts](https://www.cbsnews.com/news/hamas-israel-cease-fire-proposal-reviewed-pressure-for-peace-mounts)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T15:13:09+00:00

Hamas says it received the cease-fire proposal from Israel after a high-level Egyptian delegation wrapped up a visit to Israel.

## Eye on America: The Kinsey Collection, and revisiting the Tulsa Race Massacre
 - [https://www.cbsnews.com/video/eye-on-america-the-kinsey-collection-and-revisiting-the-tulsa-race-massacre](https://www.cbsnews.com/video/eye-on-america-the-kinsey-collection-and-revisiting-the-tulsa-race-massacre)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T15:01:01+00:00

In Oklahoma, Nate Burleson shares his family’s personal connection to one of America’s darkest chapters. Then in Texas, we tour the renowned Kinsey Collection, the largest private holding of African American art and artifacts. Watch these stories and more on Eye on America with host Michelle Miller.

## Comedian Nate Bargatze on his life and career
 - [https://www.cbsnews.com/video/comedian-nate-bargatze-on-his-life-and-career](https://www.cbsnews.com/video/comedian-nate-bargatze-on-his-life-and-career)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:58:14+00:00

Comedian Nate Bargatze is having quite the year: He's bringing laughs across the country with his "Be Funny" tour, and this week he's a headline comic at the Hollywood Bowl with stars like Jerry Seinfeld. Dana Jacobson sat down with Bargatze to talk about his journey to the stage.

## Saturday Sessions: Charley Crockett performs "Solitary Road"
 - [https://www.cbsnews.com/video/saturday-sessions-charley-crockett-performs-solitary-road](https://www.cbsnews.com/video/saturday-sessions-charley-crockett-performs-solitary-road)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:58:02+00:00

A descendent of American folk hero Davey Crockett, Charley Crockett was raised in a Texas trailer park. He bought his first guitar in a pawn shop and taught himself how to play it. In 2015, he started releasing records independently. Fourteen albums later, Crockett has established himself as one of the leaders in traditional country music's revival. From his new album "$10 Cowboy," here is Charley Crockett with "Solitary Road."

## Saturday Sessions: Charley Crockett performs "$10 Cowboy"
 - [https://www.cbsnews.com/video/saturday-sessions-charley-crockett-performs-10-cowboy](https://www.cbsnews.com/video/saturday-sessions-charley-crockett-performs-10-cowboy)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:58:01+00:00

A descendent of American folk hero Davey Crockett, Charley Crockett was raised in a Texas trailer park. He bought his first guitar in a pawn shop and taught himself how to play it. In 2015, he started releasing records independently. Fourteen albums later, Crockett has established himself as one of the leaders in traditional country music's revival. With the title track from his new album, here is Charley Crockett with "$10 Cowboy."

## Saturday Sessions: Charley Crockett performs "America"
 - [https://www.cbsnews.com/video/saturday-sessions-charley-crockett-performs-america](https://www.cbsnews.com/video/saturday-sessions-charley-crockett-performs-america)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:57:45+00:00

A descendent of American folk hero Davey Crockett, Charley Crockett was raised in a Texas trailer park. He bought his first guitar in a pawn shop and taught himself how to play it. In 2015, he started releasing records independently. Fourteen albums later, Crockett has established himself as one of the leaders in traditional country music's revival. From his new album "$10 Cowboy," here is Charley Crockett with "America."

## South Dakota Gov. Kristi Noem writes about killing her dog in new book
 - [https://www.cbsnews.com/news/south-dakota-governor-kristi-noem-writes-about-killing-dog-in-book](https://www.cbsnews.com/news/south-dakota-governor-kristi-noem-writes-about-killing-dog-in-book)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:46:52+00:00

South Dakota Gov. Kristi Noem — a potential running mate for presumptive Republican presidential candidate Donald Trump — is getting attention again.

## Inside America's mass timber movement
 - [https://www.cbsnews.com/video/inside-americas-mass-timber-movement](https://www.cbsnews.com/video/inside-americas-mass-timber-movement)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:42:49+00:00

Mass timber is a type of wood being used to build large buildings, like high-rises and airports. Jeff Glor traveled to Oregon to understand more about the material, its safety, and whether it's sustainable to use long-term.

## Fire still burning after freight train derailment
 - [https://www.cbsnews.com/news/freight-train-derailment-fire-interstate-40-arizona-new-mexico-line](https://www.cbsnews.com/news/freight-train-derailment-fire-interstate-40-arizona-new-mexico-line)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:37:00+00:00

Authorities say a freight train derailment and fire have forced the closure of a key east-west interstate trucking route near the Arizona-New Mexico state line.

## Russia arrests another suspect in concert hall attack that killed 144
 - [https://www.cbsnews.com/news/russia-concert-hall-attack-suspect-arrested](https://www.cbsnews.com/news/russia-concert-hall-attack-suspect-arrested)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:14:07+00:00

A Moscow court has detained another suspect as an accomplice in the attack by gunmen on a suburban Moscow concert hall in March.

## Japan works to preserve ancient tradition
 - [https://www.cbsnews.com/video/japan-works-to-preserve-ancient-tradition](https://www.cbsnews.com/video/japan-works-to-preserve-ancient-tradition)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:00:52+00:00

Public baths have been the center of city life in Japan for centuries. But since 2006, hundreds of such baths have closed. Some are working to preserve the ancient tradition, which they say allows for socializing and relaxation.

## The Uplift: An angel officer
 - [https://www.cbsnews.com/video/the-uplift-an-angel-officer](https://www.cbsnews.com/video/the-uplift-an-angel-officer)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:00:52+00:00

A police officer becomes a guardian angel for a little girl struggling at school. A New Jersey toddler goes viral for the way she speaks, bringing joy and laughs to millions. A 7-year-old makes history at the rodeo. Plus, more inspiring stories.

## Intimacy coordinators are on the rise on film and TV sets. Here's what they do.
 - [https://www.cbsnews.com/news/intimacy-coordinator-unique-jobs](https://www.cbsnews.com/news/intimacy-coordinator-unique-jobs)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T14:00:21+00:00

Intimacy coordination is a relatively new and growing field with movie and television productions required to make a good-faith effort to hire one if needed on set.

## Game company puts new spin on virtual tennis
 - [https://www.cbsnews.com/video/game-company-puts-new-spin-on-virtual-tennis](https://www.cbsnews.com/video/game-company-puts-new-spin-on-virtual-tennis)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T13:45:19+00:00

First there was "Tennis for Two," then Atari's "Pong." Tennis has been a popular subject for video games for decades. Now, gaming company 2K Games is putting a unique spin on the classic game with "Topspin Tennis," which features real-life athletes. Michelle Miller has more.

## Efforts to secure ceasefire in Gaza continue
 - [https://www.cbsnews.com/video/efforts-to-secure-ceasefire-in-gaza-continue](https://www.cbsnews.com/video/efforts-to-secure-ceasefire-in-gaza-continue)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T13:42:10+00:00

Attempts to establish a ceasefire in Gaza are ongoing, with Hamas saying today that it is reviewing the latest Israeli counter-proposals as international negotiators work for a truce. Meanwhile, aid workers trying to make a difference in Gaza face perilous conditions.

## Exclusive discounts from CBS Mornings Deals
 - [https://www.cbsnews.com/video/cbs-mornings-deals-042724](https://www.cbsnews.com/video/cbs-mornings-deals-042724)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T13:42:10+00:00

On this edition of CBS Mornings Deals, Ashley Bellman shows us items that might just become essentials in your everyday life. Visit cbsdeals.com to take advantage of these exclusive deals today. CBS earns commissions on purchases made through cbsdeals.com.

## College student protests over Israel-Hamas war grow
 - [https://www.cbsnews.com/video/college-student-protests-over-israel-hamas-war-grow](https://www.cbsnews.com/video/college-student-protests-over-israel-hamas-war-grow)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T13:12:00+00:00

College students are continuing to protest the Israel-Hamas war. At New York City's Columbia University, where an encampment of students first made headlines, tensions are high and negotiations between students and administrators are stalled.

## Recap of former president Donald Trump's New York trial
 - [https://www.cbsnews.com/video/recap-of-former-president-donald-trumps-new-york-trial](https://www.cbsnews.com/video/recap-of-former-president-donald-trumps-new-york-trial)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T13:12:00+00:00

Former president Donald Trump's New York "hush money" trial has wrapped its second week. Former National Enquirer publisher David Pecker spent four days on the stand detailing his tabloid's efforts to hide stories that could have damaged Trump's 2016 campaign.

## Another American man visiting Turks and Caicos arrested after bullets found in his luggage
 - [https://www.cbsnews.com/video/another-american-man-visiting-turks-and-caicos-arrested-after-bullets-found-in-his-luggage](https://www.cbsnews.com/video/another-american-man-visiting-turks-and-caicos-arrested-after-bullets-found-in-his-luggage)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T13:11:59+00:00

An American man has been arrested in Turks and Caicos after bullets were found in his luggage. This is the second such case this week, and the fourth in recent months.

## College protesters dig in as demonstrations against war grow
 - [https://www.cbsnews.com/news/college-student-protesters-demonstrations-israel-hamas-war-grow](https://www.cbsnews.com/news/college-student-protesters-demonstrations-israel-hamas-war-grow)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T13:03:59+00:00

Protesters nationwide are demanding that schools cut financial ties to Israel and divest from companies they say are enabling the conflict.

## Match Group CEO on romance scams: "Things happen in life"
 - [https://www.cbsnews.com/news/match-group-ceo-bernard-kim-on-romance-scams](https://www.cbsnews.com/news/match-group-ceo-bernard-kim-on-romance-scams)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T13:00:20+00:00

The CEO of the nation's largest online dating company responded to questions stemming from a yearlong CBS News investigation​ into the growing threat of romance scammers.

## Eye Opener: Australia beachgoers save whales washed up on shore
 - [https://www.cbsnews.com/video/eye-opener-australia-beachgoers-save-whales-washed-up-on-shore](https://www.cbsnews.com/video/eye-opener-australia-beachgoers-save-whales-washed-up-on-shore)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T12:47:01+00:00

Beachgoers in Australia helped save a pod of whales that washed up on shore, with more than 100 volunteers helping out. Meanwhile, campus protests over the Israel-Hamas war are spreading internationally. All that and all that matters in today’s Eye Opener.

## Harvey Weinstein to appear in NY court next week
 - [https://www.cbsnews.com/news/harvey-weinstein-possible-retrial-court-new-york](https://www.cbsnews.com/news/harvey-weinstein-possible-retrial-court-new-york)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T12:44:22+00:00

Harvey Weinstein's 2020 conviction​ on felony sex crime charges was overturned by the State of New York Court of Appeals.

## Pro-Palestinian student protest at Northeastern Univeristy cleared by police
 - [https://www.cbsnews.com/news/northeastern-university-boston-pro-palestine-protests](https://www.cbsnews.com/news/northeastern-university-boston-pro-palestine-protests)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T12:37:00+00:00

An encampment at Northeastern University is being cleared. Campus officials reported the use of "virulent antisemitic slurs."

## Russia attacks Ukrainian energy sector as Kyiv launches drones
 - [https://www.cbsnews.com/news/russia-renews-attacks-ukrainian-energy-sector-kyiv-launches-drones-southern-russia](https://www.cbsnews.com/news/russia-renews-attacks-ukrainian-energy-sector-kyiv-launches-drones-southern-russia)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T11:20:30+00:00

Russia has launched a barrage of missiles against Ukraine directed at energy facilities.

## How to watch the Boston Bruins vs. Toronto Maple Leafs NHL Playoffs game tonight: Game 4 Livestream options, more
 - [https://www.cbsnews.com/essentials/how-to-watch-tonights-boston-bruins-vs-toronto-maple-leafs-nhl-playoff-game-4](https://www.cbsnews.com/essentials/how-to-watch-tonights-boston-bruins-vs-toronto-maple-leafs-nhl-playoff-game-4)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T05:22:04+00:00

Here's how and when to watch Game 4 of the Boston Bruins vs. Toronto Maple Leafs Stanley Cup NFL Playoffs series.

## How to watch the Cleveland Cavaliers vs. Orlando Magic NBA Playoffs game tonight: Game 4 livestream options, more
 - [https://www.cbsnews.com/essentials/how-to-watch-todays-cavaliers-vs-magic-nba-playoffs-game-game-4-livestream-options-start-time-and-more](https://www.cbsnews.com/essentials/how-to-watch-todays-cavaliers-vs-magic-nba-playoffs-game-game-4-livestream-options-start-time-and-more)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T05:06:47+00:00

Find out how and when to watch Game 4 of the Cavaliers vs. Magic NBA Playoffs series, even if you don't have cable.

## How to watch the Denver Nuggets vs. Los Angeles Lakers NBA Playoffs game tonight: Game 4 livestream options, more
 - [https://www.cbsnews.com/news/how-to-watch-tonights-denver-nuggets-vs-los-angeles-lakers-game-4](https://www.cbsnews.com/news/how-to-watch-tonights-denver-nuggets-vs-los-angeles-lakers-game-4)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T04:59:00+00:00

Here's how and when to watch Game 4 of the Denver Nuggets vs. Los Angeles Lakers NBA Playoffs series.

## How to watch the Denver Nuggets vs. Los Angeles Lakers NBA Playoffs game tonight: Game 4 livestream options, more
 - [https://www.cbsnews.com/essentials/how-to-watch-tonights-denver-nuggets-vs-los-angeles-lakers-game-4](https://www.cbsnews.com/essentials/how-to-watch-tonights-denver-nuggets-vs-los-angeles-lakers-game-4)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T04:59:00+00:00

Here's how and when to watch Game 4 of the Denver Nuggets vs. Los Angeles Lakers NBA Playoffs series.

## How to watch tonight's Boston Celtics vs. Miami Heat NBA Playoffs game: Game 3 livestream options, start time, more
 - [https://www.cbsnews.com/essentials/how-to-watch-tonights-boston-celtics-vs-miami-heat-nba-playoffs-game-3](https://www.cbsnews.com/essentials/how-to-watch-tonights-boston-celtics-vs-miami-heat-nba-playoffs-game-3)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T04:47:00+00:00

Game 3 of the Celtics vs. Heat NBA Playoffs series is can't-miss basketball. Here's how and when to watch tonight.

## How to watch the OKC Thunder vs. New Orleans Pelicans NBA Playoffs game tonight: Game 3 livestream options, more
 - [https://www.cbsnews.com/essentials/how-to-watch-todays-okc-thunder-vs-new-orleans-pelicans-nba-playoffs-game-3](https://www.cbsnews.com/essentials/how-to-watch-todays-okc-thunder-vs-new-orleans-pelicans-nba-playoffs-game-3)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T04:10:19+00:00

Here's how and when to watch Game 3 of the OKC Thunder vs. New Orleans Pelicans NBA Playoffs series.

## 4/26: CBS Evening News
 - [https://www.cbsnews.com/video/042624-cbs-evening-news](https://www.cbsnews.com/video/042624-cbs-evening-news)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T04:00:49+00:00

More than a dozen tornadoes touch down across Texas, Oklahoma and Nebraska; High schoolers organize benefit dinner for young cancer patients and families

## 50 walk away from burning double-decker bus on I-595 in Davie
 - [https://www.cbsnews.com/news/burned-double-decker-bus-affects-traffic-on-i-595](https://www.cbsnews.com/news/burned-double-decker-bus-affects-traffic-on-i-595)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T03:15:14+00:00

About 50 people are lucky to be alive Friday afternoon after the double-decker bus they were in caught fire, shutting down the westbound lanes of I-595 in Davie.

## Hersh Goldberg-Polin's mother speaks out after Hamas releases hostage video of her son
 - [https://www.cbsnews.com/video/hersh-goldberg-polin-mother-speaks-out-after-hamas-releases-hostage-video-of-her-son](https://www.cbsnews.com/video/hersh-goldberg-polin-mother-speaks-out-after-hamas-releases-hostage-video-of-her-son)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T01:50:00+00:00

For more than 200 days after Hersh Goldberg-Polin was taken hostage by Hamas on Oct.7, his mother hadn't heard his voice or seen video that proved he was alive. But that changed this week, when Hamas released a propaganda video showing Hersh – an Israeli-American – alive with his left arm amputated. CBS News' Debora Patta sat down with his mother, Rachel Goldberg-Polin, to ask about the "overwhelming and emotional" moment she saw that video and how she hopes all parties involved can reach a compromise to end the suffering.

## Possible TikTok ban leaves some small businesses concerned for their survival
 - [https://www.cbsnews.com/news/possible-tiktok-ban-small-businesses-concerned-survival](https://www.cbsnews.com/news/possible-tiktok-ban-small-businesses-concerned-survival)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:52:47+00:00

Under the new law signed this week, ByteDance has nine to 12 months to sell the platform to an American owner, or TikTok faces being banned in the U.S.

## Emergency exit slide falls off Delta flight
 - [https://www.cbsnews.com/video/emergency-exit-slide-falls-off-delta-flight](https://www.cbsnews.com/video/emergency-exit-slide-falls-off-delta-flight)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:52:00+00:00

A Delta Air Lines flight en route to Los Angeles was forced to circle back to New York's JFK International Airport Friday morning after it dropped an emergency exit slide.

## High schoolers organize benefit dinner for young cancer patients and families
 - [https://www.cbsnews.com/video/high-schoolers-organize-benefit-dinner-for-young-cancer-patients-and-families](https://www.cbsnews.com/video/high-schoolers-organize-benefit-dinner-for-young-cancer-patients-and-families)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:52:00+00:00

Meet high school freshmen Joshua Small and Alexander Morris, a dynamic duo making a difference in their New York city community. The two long-time friends are teaming up to raise money to help young cancer patients and their families.

## Another American arrested in Turks and Caicos after bullets found in luggage
 - [https://www.cbsnews.com/video/another-american-arrested-in-turks-and-caicos-after-bullets-found-in-luggage](https://www.cbsnews.com/video/another-american-arrested-in-turks-and-caicos-after-bullets-found-in-luggage)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:51:00+00:00

Another American has been arrested in the Caribbean territory of Turks and Caicos after ammunition was allegedly found in his luggage. The Virginia man is the fourth American detained under similar circumstances in the last several months. Kris Van Cleave has more.

## Small business owners brace for possible TikTok ban
 - [https://www.cbsnews.com/video/small-business-owners-brace-for-possible-tiktok-ban](https://www.cbsnews.com/video/small-business-owners-brace-for-possible-tiktok-ban)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:50:00+00:00

With the clock ticking on TikTok, millions of users, including small businesses, are scrambling to figure out what to do next. Jo Ling Kent reports.

## Decades after finding an abandoned baby, officer makes remarkable discovery
 - [https://www.cbsnews.com/news/officer-abandoned-baby-south-bend-indiana-gene-eyster-matthew-hegedus-stewart-remarkable-discovery](https://www.cbsnews.com/news/officer-abandoned-baby-south-bend-indiana-gene-eyster-matthew-hegedus-stewart-remarkable-discovery)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:49:16+00:00

For more than two decades, retired Lt. Gene Eyster wondered what became of that boy he found abandoned in a cardboard box in an apartment hallway.

## Blinken meets with Chinese President Xi Jinping
 - [https://www.cbsnews.com/video/042624-blinken-meets-with-chinese-president-xi-jinping](https://www.cbsnews.com/video/042624-blinken-meets-with-chinese-president-xi-jinping)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:49:00+00:00

Secretary of State Antony Blinken met Friday with Chinese President Xi Jinping and other top officials in Beijing. Blinken raised concern that China is helping Russia to produce tanks, armored vehicles and weapons for its war in Ukraine. Nancy Cordes has more from the White House.

## Pro-Palestinian protests emerge on more college campuses
 - [https://www.cbsnews.com/video/pro-palestinian-protests-emerge-on-more-college-campuses](https://www.cbsnews.com/video/pro-palestinian-protests-emerge-on-more-college-campuses)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:48:00+00:00

Pro-Palestinian protests emerged on more college campuses Friday amid growing concerns about outside demonstrators not linked to schools where protests are being staged. Lilia Luciano has details.

## Retired officer reunites with man he saved as a baby who followed in his footsteps
 - [https://www.cbsnews.com/video/retired-officer-reunites-man-he-saved-baby-followed-footsteps](https://www.cbsnews.com/video/retired-officer-reunites-man-he-saved-baby-followed-footsteps)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:47:00+00:00

Retired police lieutenant Gene Eyster of South Bend, Indiana, had always wondered what became of the abandoned baby he saved 24 years ago. Steve Hartman goes "On the Road" to reveal how a phone call from a fellow officer revealed their incredible connection.

## Trump trial closes out first week of testimony
 - [https://www.cbsnews.com/video/trump-trial-closes-out-first-week-of-testimony](https://www.cbsnews.com/video/trump-trial-closes-out-first-week-of-testimony)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:47:00+00:00

Ex-tabloid publisher David Pecker took the stand again Friday to detail the scheme he helped broker to suppress stories that could have hurt Donald Trump's 2016 campaign. Robert Costa has more.

## Where severe weather is headed next after tornadoes
 - [https://www.cbsnews.com/video/where-severe-weather-is-headed-next-after-tornadoes](https://www.cbsnews.com/video/where-severe-weather-is-headed-next-after-tornadoes)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-04-27T00:42:00+00:00

The Weather Channel meteorologist Mike Bettes has a look at where dangerous storms are headed next after tornadoes touched down Friday in three states.

