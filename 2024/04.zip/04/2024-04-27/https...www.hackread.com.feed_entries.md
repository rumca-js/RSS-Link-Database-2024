# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## DHS Establishes AI Safety Board with Tech Titans and Experts
 - [https://www.hackread.com/dhs-establishes-ai-safety-board-tech-titans](https://www.hackread.com/dhs-establishes-ai-safety-board-tech-titans)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2024-04-27T06:11:13+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>The Department of Homeland Security (DHS) has formed an AI Safety Board to ensure secure AI use in critical infrastructure.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/dhs-establishes-ai-safety-board-tech-titans/" rel="nofollow">DHS Establishes AI Safety Board with Tech Titans and Experts</a></p>

