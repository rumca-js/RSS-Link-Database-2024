# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Zełenski: Rosja zaatakowała infrastrukturę kluczową dla zapewnienia bezpiecznych dostaw do Unii Europejskiej
 - [https://tvn24.pl/swiat/atak-rosji-na-ukraine-wolodymyr-zelenski-zaatakowano-infrastrukture-energetyczna-wazna-dla-ue-st7891247?source=rss](https://tvn24.pl/swiat/atak-rosji-na-ukraine-wolodymyr-zelenski-zaatakowano-infrastrukture-energetyczna-wazna-dla-ue-st7891247?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-04-27T19:28:39+00:00

<img alt="Zełenski: Rosja zaatakowała infrastrukturę kluczową dla zapewnienia bezpiecznych dostaw do Unii Europejskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ja5m4-prezydent-ukrainy-wolodymyr-zelenski-podczas-wizyty-w-obwodzie-charkowskim-7861682/alternates/LANDSCAPE_1280" />
    Rosja zaatakowała w sobotę 34 rakietami w kilku ukraińskich obwodach. Jak przekazał prezydent Wołodymyr Zełenski, celem były obiekty infrastruktury energetycznej. Dodał, że Rosja skupiła swoją uwagę na obiektach istotnych dla dostaw gazu do Unii Europejskiej.

## Zastrzeliła swoją suczkę, która "zrujnowała polowanie". Gubernatorka może zostać wiceprezydentką przy Trumpie
 - [https://tvn24.pl/swiat/usa-kristi-noem-zastrzelila-suczke-ktora-zrujnowala-polowanie-gubernatorka-rozwazana-przez-donalda-trumpa-na-wiceprezydent-st7890320?source=rss](https://tvn24.pl/swiat/usa-kristi-noem-zastrzelila-suczke-ktora-zrujnowala-polowanie-gubernatorka-rozwazana-przez-donalda-trumpa-na-wiceprezydent-st7890320?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-04-27T12:53:23+00:00

<img alt="Zastrzeliła swoją suczkę, która " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qgj59e-kristi-noem-gubernatorka-poludniowej-dakoty-7890327/alternates/LANDSCAPE_1280" />
    Kristi Noem - która jest poważnie rozważana do funkcji wiceprezydentki USA, gdyby Donald Trump wygrał wybory - opisała w książce, jak zastrzeliła swoją suczkę po nieudanym polowaniu na bażanty - podał "Guardian" po zapoznaniu się z treścią publikacji, która niebawem ma się ukazać w USA. Republikańska polityczka przekonuje w niej, że to dowód, iż w razie potrzeby jest zdolna zrobić wszystko, co "trudne, brudne i brzydkie".

## Jechał tak szybko, że nie zapanował nad autem. Wpadł na pas zieleni i uderzył w bariery
 - [https://tvn24.pl/wroclaw/legnica-4-tysiace-mandatu-i-10-punktow-karnych-samochod-nie-powinien-znalezc-sie-na-drodze-st7890334?source=rss](https://tvn24.pl/wroclaw/legnica-4-tysiace-mandatu-i-10-punktow-karnych-samochod-nie-powinien-znalezc-sie-na-drodze-st7890334?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-04-27T11:44:51+00:00

<img alt="Jechał tak szybko, że nie zapanował nad autem. Wpadł na pas zieleni i uderzył w bariery" src="https://tvn24.pl/najnowsze/cdn-zdjecie-phsm8d-niebezpieczna-sytuacja-na-drodze-w-legnicy-7890314/alternates/LANDSCAPE_1280" />
    Nawet pięć lat więzienia grozi 58-letniemu mieszkańcowi Legnicy (woj. dolnośląskie), który jadąc samochodem z dużą prędkością, stracił panowanie nad kierownicą i uderzył w krawężnik oraz przydrożne bariery. Mężczyzna był trzeźwy, ale pojazd, którym kierował, nie był zarejestrowany i ubezpieczony.

## Weszła do domu i usłyszała chrapanie. W łóżku leżał włamywacz
 - [https://tvn24.pl/lodz/poddebice-weszla-do-domu-i-uslyszala-chrapanie-w-lozku-lezal-wlamywacz-st7890034?source=rss](https://tvn24.pl/lodz/poddebice-weszla-do-domu-i-uslyszala-chrapanie-w-lozku-lezal-wlamywacz-st7890034?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-04-27T08:31:51+00:00

<img alt="Weszła do domu i usłyszała chrapanie. W łóżku leżał włamywacz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3fr8jd-51-latek-zasnal-w-miejscu-wlamania-7889995/alternates/LANDSCAPE_1280" />
    Do niecodziennej sytuacji doszło w jednym z domów w gminie Poddębice (Łódzkie). Jego właścicielka zastała w łóżku śpiącego włamywacza. Wcześniej 51-latek przygotował sobie jedzenie. Okazało się dodatkowo, że mężczyzna był pijany.

## Laserami wyczyszczą wieżę bazyliki Mariackiej
 - [https://tvn24.pl/krakow/krakow-konserwacja-bazyliki-mariackiej-wieza-zostanie-wyczyszczona-metoda-ablacji-laserowej-st7889324?source=rss](https://tvn24.pl/krakow/krakow-konserwacja-bazyliki-mariackiej-wieza-zostanie-wyczyszczona-metoda-ablacji-laserowej-st7889324?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-04-27T06:20:00+00:00

<img alt="Laserami wyczyszczą wieżę bazyliki Mariackiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1x9ced-krakow-7846307/alternates/LANDSCAPE_1280" />
    Przy pomocy ablacji laserowej wyczyszczona zostanie elewacja wieży hejnałowej bazyliki Mariackiej w Krakowie. Wybrano tę metodę ze względu na jej niską inwazyjność w porównaniu do czyszczenia wodą. Prace konserwatorskie w kościele zakończą się w 2025 roku.

