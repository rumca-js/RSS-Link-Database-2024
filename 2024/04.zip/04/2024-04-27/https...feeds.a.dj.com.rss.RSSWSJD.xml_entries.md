# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Investors Cheer AI Spending Boom in Big Tech---Just Not at Meta
 - [https://www.wsj.com/articles/investors-cheer-ai-spending-boom-in-big-techjust-not-at-meta-42af2528?mod=rss_Technology](https://www.wsj.com/articles/investors-cheer-ai-spending-boom-in-big-techjust-not-at-meta-42af2528?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-04-27T01:00:00+00:00

Meta had its worst trading day in 18 months after warning of years of AI investment. Shares of Microsoft and Google parent Alphabet rallied.

## Meet the AI Expert Advising the White House, JPMorgan, Google and the Rest of Corporate America
 - [https://www.wsj.com/articles/ai-expert-mollick-white-house-jpmorgan-google-d8fd440f?mod=rss_Technology](https://www.wsj.com/articles/ai-expert-mollick-white-house-jpmorgan-google-d8fd440f?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-04-27T01:00:00+00:00

Ethan Mollick at the University of Pennsylvania has become the go-to authority on the new technology

