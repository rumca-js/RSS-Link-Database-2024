# Source:Gulf Insider, URL:https://www.gulf-insider.com/feed, language:en-US

## Russia Claims the United States Is Putting Pressure on Turkish Airlines to Bar Its Citizens From Flying to Mexico
 - [https://www.gulf-insider.com/russia-claims-the-united-states-is-putting-pressure-on-turkish-airlines-to-bar-its-citizens-from-flying-to-mexico](https://www.gulf-insider.com/russia-claims-the-united-states-is-putting-pressure-on-turkish-airlines-to-bar-its-citizens-from-flying-to-mexico)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T12:37:05+00:00

<p>Russia has accused the United States of putting pressure on Turkish Airlines to refuse its citizens carriage on flights between Istanbul and Mexico after a war of words broke out between Russian officials and the Turkish flag carrier. The issue came to a head earlier this week when Russia’s embassy in Anchorage claimed Turkish Airlines &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/russia-claims-the-united-states-is-putting-pressure-on-turkish-airlines-to-bar-its-citizens-from-flying-to-mexico/">Russia Claims the United States Is Putting Pressure on Turkish Airlines to Bar Its Citizens From Flying to Mexico</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## ‘World’s Largest’ Coral-Restoration Project Unveiled in Saudi Arabia
 - [https://www.gulf-insider.com/worlds-largest-coral-restoration-project-unveiled-in-saudi-arabia](https://www.gulf-insider.com/worlds-largest-coral-restoration-project-unveiled-in-saudi-arabia)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T11:32:10+00:00

<p>One of Saudi Arabia&#8217;s top universities has announced a Red Sea project described as the world’s largest coral reef restoration. The King Abdullah University of Science and Technology initiative aims to produce hundreds of thousands of corals each year. The scheme “represents a significant step towards restoring reefs globally”, according to the university, and is seen as important because &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/worlds-largest-coral-restoration-project-unveiled-in-saudi-arabia/">‘World’s Largest’ Coral-Restoration Project Unveiled in Saudi Arabia</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Abu Dhabi’s Driverless Racing Event Will Boost Autonomous Car Safety, Says Expert
 - [https://www.gulf-insider.com/abu-dhabis-driverless-racing-event-will-boost-autonomous-car-safety-says-expert](https://www.gulf-insider.com/abu-dhabis-driverless-racing-event-will-boost-autonomous-car-safety-says-expert)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T11:21:22+00:00

<p>One of the main goals of a new self-driving race car league in Abu Dhabi is to help reduce the number of road accidents around the globe, said a senior figure. On Saturday, teams from across the world will be competing in the event, the first in the UAE. Self-driving cars will take to a track that is &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/abu-dhabis-driverless-racing-event-will-boost-autonomous-car-safety-says-expert/">Abu Dhabi’s Driverless Racing Event Will Boost Autonomous Car Safety, Says Expert</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Bahrain High Criminal Court Set to Deliver Verdict in Landmark Money Laundering Case
 - [https://www.gulf-insider.com/bahrain-high-criminal-court-set-to-deliver-verdict-in-landmark-money-laundering-case](https://www.gulf-insider.com/bahrain-high-criminal-court-set-to-deliver-verdict-in-landmark-money-laundering-case)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T10:53:41+00:00

<p>The Bahrain High Criminal Court is set to deliver its verdict in a money laundering saga that has rocked the nation. Two individuals stand accused of orchestrating a scheme that fleeced unsuspecting victims of a staggering BD10 million. A hearing is set for May 13 to deliver the sentence. According to court documents, the defendants &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/bahrain-high-criminal-court-set-to-deliver-verdict-in-landmark-money-laundering-case/">Bahrain High Criminal Court Set to Deliver Verdict in Landmark Money Laundering Case</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## What’s Behind a Dramatic Fall in Indian Families’ Savings
 - [https://www.gulf-insider.com/whats-behind-a-dramatic-fall-in-indian-families-savings](https://www.gulf-insider.com/whats-behind-a-dramatic-fall-in-indian-families-savings)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T08:58:35+00:00

<p>For decades, India has been a nation of savers. They stash away a significant portion of their earnings for future security, often at the expense of current consumption. But something seems to be amiss now. Recent data from the Reserve Bank of India says India&#8217;s net household savings stood at a 47-year-old low. Household net &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/whats-behind-a-dramatic-fall-in-indian-families-savings/">What’s Behind a Dramatic Fall in Indian Families’ Savings</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Synthetic Diamonds Made in Minutes Not Days Could Upend Gemstone Economics
 - [https://www.gulf-insider.com/synthetic-diamonds-made-in-minutes-not-days-could-upend-gemstone-economics](https://www.gulf-insider.com/synthetic-diamonds-made-in-minutes-not-days-could-upend-gemstone-economics)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T08:53:15+00:00

<p>A new method for making diamonds bypasses the high temperatures and pressures, opening the door to making them at a fraction of the existing cost. The world of fine crystal control called The Diamond Age in science fiction may be closer than we think. Although we have known how to make synthetic diamonds since the &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/synthetic-diamonds-made-in-minutes-not-days-could-upend-gemstone-economics/">Synthetic Diamonds Made in Minutes Not Days Could Upend Gemstone Economics</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Aramco Signs Multi-Year Global Partnership Deal with FIFA
 - [https://www.gulf-insider.com/aramco-signs-multi-year-global-partnership-deal-with-fifa](https://www.gulf-insider.com/aramco-signs-multi-year-global-partnership-deal-with-fifa)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T08:42:44+00:00

<p>Saudi Aramco has signed a four-year worldwide partnership deal with the world soccer governing body, FIFA, making the state-energy giant a partner including in major tournaments such as the World Cup 2026 and the Women’s World Cup 2027. “This partnership will assist FIFA to successfully deliver its flagship tournaments over the next four years and, &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/aramco-signs-multi-year-global-partnership-deal-with-fifa/">Aramco Signs Multi-Year Global Partnership Deal with FIFA</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Fly Jinnah Launches New Flights Connecting Muscat With Islamabad
 - [https://www.gulf-insider.com/fly-jinnah-launches-new-flights-connecting-muscat-with-islamabad](https://www.gulf-insider.com/fly-jinnah-launches-new-flights-connecting-muscat-with-islamabad)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T08:27:36+00:00

<p>Fly Jinnah, Pakistan’s low-cost carrier, has announced the launch of its new non-stop flights between Muscat and Islamabad in Pakistan, starting from 10 May 2024. The new route will initially start with a frequency of two weekly flights connecting the two capitals. Flight Schedule between Muscat International Airport and Islamabad International Airport, effective 10 May, &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/fly-jinnah-launches-new-flights-connecting-muscat-with-islamabad/">Fly Jinnah Launches New Flights Connecting Muscat With Islamabad</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi Council of Senior Scholars: Performing Hajj Without Permit Not Permissible
 - [https://www.gulf-insider.com/saudi-council-of-senior-scholars-performing-hajj-without-permit-not-permissible](https://www.gulf-insider.com/saudi-council-of-senior-scholars-performing-hajj-without-permit-not-permissible)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T08:23:03+00:00

<p>The Council of Senior Scholars in Saudi Arabia said in a statement that it is mandatory for Muslims to obtain a Hajj permit if they will perform pilgrimage. The council said obtaining a permit is obligatory to comply with the Sharia law, and facilitate Hajj and safeguard the sanctity of the Holy Sites. Performing Hajj &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-council-of-senior-scholars-performing-hajj-without-permit-not-permissible/">Saudi Council of Senior Scholars: Performing Hajj Without Permit Not Permissible</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Watch: Trump Challenges Biden To Debate
 - [https://www.gulf-insider.com/watch-trump-challenges-biden-to-debate](https://www.gulf-insider.com/watch-trump-challenges-biden-to-debate)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T07:40:00+00:00

<p>In a Friday interview with Howard Stern, President Joe Biden said he&#8217;d be &#8220;happy to debate&#8221; Donald Trump, telling Stern: &#8220;I am, somewhere, I don’t know when, but I am happy to debate him.&#8221; Biden&#8217;s remarks appeared off the cuff, rather than something his handlers approved, citing a top Democratic official familiar with the campaign&#8217;s &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/watch-trump-challenges-biden-to-debate/">Watch: Trump Challenges Biden To Debate</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## UCLA Students Forced to Take Mandatory ‘Fat Positivity’ Class
 - [https://www.gulf-insider.com/ucla-students-forced-to-take-mandatory-fat-positivity-class](https://www.gulf-insider.com/ucla-students-forced-to-take-mandatory-fat-positivity-class)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T07:12:16+00:00

<p>UCLA medical school is under fire for forcing students to attend ‘health equity’ classes where ‘fat positivity’ is promoted, and reading material claims that the medical term ‘obesity’ is a slur “used to exact violence on fat people.” Yes, really. The Washington Free Beacon obtained the  entire syllabus for the mandatory course, titled Structural Racism and Health Equity, &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/ucla-students-forced-to-take-mandatory-fat-positivity-class/">UCLA Students Forced to Take Mandatory ‘Fat Positivity’ Class</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Pentagon Chief Trolls Iran On Effectiveness Of Weapons After Israel Attack
 - [https://www.gulf-insider.com/pentagon-chief-trolls-iran-on-effectiveness-of-weapons-after-israel-attack](https://www.gulf-insider.com/pentagon-chief-trolls-iran-on-effectiveness-of-weapons-after-israel-attack)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T07:01:30+00:00

<p>US Defense Secretary Lloyd Austin on Friday weighed in on the April 13 Iranian attack on Israel, which was the Islamic Republic&#8217;s first-ever direct attack on the Jewish state. It included some 300 drones and missiles launched at Israel &#8211; the vast majority of which were intercepted by Israeli anti-air defenses, but also with US &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/pentagon-chief-trolls-iran-on-effectiveness-of-weapons-after-israel-attack/">Pentagon Chief Trolls Iran On Effectiveness Of Weapons After Israel Attack</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## California’s New Minimum Wage: A Cure That Exacerbates The Sickness
 - [https://www.gulf-insider.com/californias-new-minimum-wage-a-cure-that-exacerbates-the-sickness](https://www.gulf-insider.com/californias-new-minimum-wage-a-cure-that-exacerbates-the-sickness)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T06:47:47+00:00

<p>The solution to a problem shouldn’t make the problem worse. But apparently, California’s policy makers missed that memo. On April 1st, the state instituted a $20 minimum wage for fast food workers, the highest in the US. With California’s absurdly high cost of living, the policy appeared to make life more manageable for low-income residents. Unfortunately, as the adage goes, “If it sounds too &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/californias-new-minimum-wage-a-cure-that-exacerbates-the-sickness/">California&#8217;s New Minimum Wage: A Cure That Exacerbates The Sickness</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Worst In 70 Years: Biden Approval Rating Absolutely Dismal
 - [https://www.gulf-insider.com/worst-in-70-years-biden-approval-rating-absolutely-dismal](https://www.gulf-insider.com/worst-in-70-years-biden-approval-rating-absolutely-dismal)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T06:33:36+00:00

<p>President Joe Biden has the worst job approval rating since Eisenhower during his recently completed 13th quarter in office, according to a new poll by Gallup. While Biden clocks in at 38.7%, the previous low was set by George H.W. Bush at 41.8% in 1992. Donald Trump and Barack Obama averaged 46.8% and 45.9% respectively during the &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/worst-in-70-years-biden-approval-rating-absolutely-dismal/">Worst In 70 Years: Biden Approval Rating Absolutely Dismal</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## US: Disgruntled School Employee Uses AI To Frame Principal With Racist Rant
 - [https://www.gulf-insider.com/disgruntled-school-employee-uses-ai-to-frame-principal-with-racist-rant](https://www.gulf-insider.com/disgruntled-school-employee-uses-ai-to-frame-principal-with-racist-rant)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T06:23:13+00:00

<p>A disgruntled ex-athletics director at a northern&#160;Baltimore County Public School used artificial intelligence to&#160;impersonate the voice of his boss, the high school&#8217;s principal, then posted the racist and antisemitic hate rant on social media to share with the world. Baltimore County Police Chief Robert McCullough told reporters his investigators worked with FBI agents and experts from the University &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/disgruntled-school-employee-uses-ai-to-frame-principal-with-racist-rant/">US: Disgruntled School Employee Uses AI To Frame Principal With Racist Rant </a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## The Terrifying Potential of Robots
 - [https://www.gulf-insider.com/the-terrifying-potential-of-robots](https://www.gulf-insider.com/the-terrifying-potential-of-robots)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T06:14:56+00:00

<p>For those curious, owning a flamethrower is broadly legal across the United States, with Maryland being the exception, as the state has effectively banned these devices. In California, flamethrowers are legal but require a permit.  With the legality all sorted out. What&#8217;s been making headlines this week is a Unitree Go2 quadruple robot equipped with a flamethrower. &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/the-terrifying-potential-of-robots/">The Terrifying Potential of Robots</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## UK Navy Reports Two Vessels Attacked in Red Sea, One Damaged
 - [https://www.gulf-insider.com/uk-navy-reports-two-vessels-attacked-in-red-sea-one-damaged](https://www.gulf-insider.com/uk-navy-reports-two-vessels-attacked-in-red-sea-one-damaged)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T05:44:01+00:00

<p>Yemen&#8217;s Iran-backed Houthi rebels may have launched attacks on two vessels transiting southwest of&#160;Mukha, a&#160;port city on the highly contested southern Red Sea.&#160; The UK Navy has confirmed two attacks on vessels in a series of headlines hitting the Terminal around 1400 ET.  There are also reports that one of the vessels is &#8220;damaged.&#8221;&#160; UK Navy Says &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/uk-navy-reports-two-vessels-attacked-in-red-sea-one-damaged/">UK Navy Reports Two Vessels Attacked in Red Sea, One Damaged</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## UAE Records Mild Earthquake; Residents Feel Tremors
 - [https://www.gulf-insider.com/uae-records-mild-earthquake-residents-feel-tremors-2](https://www.gulf-insider.com/uae-records-mild-earthquake-residents-feel-tremors-2)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T05:27:08+00:00

<p>Some residents felt tremors during the early hours of the morning as the UAE recorded an earthquake of magnitude 2.8 on Saturday, as per the National Centre of Meteorology. The quake took place at 3.03am local time off the coast of Khor Fakkan, at a depth of 5km. As per the NCM, although residents felt &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/uae-records-mild-earthquake-residents-feel-tremors-2/">UAE Records Mild Earthquake; Residents Feel Tremors</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Bahrain Comic Con 2024 Kicks Off
 - [https://www.gulf-insider.com/bahrain-comic-con-2024-kicks-off](https://www.gulf-insider.com/bahrain-comic-con-2024-kicks-off)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T05:22:30+00:00

<p>Under the patronage of His Highness Shaikh Khalid bin Hamad Al Khalifa, First Deputy Chairman of the Supreme Council for Youth and Sports, Chairman of the General Sports Authority, and President of the Bahrain Olympic Committee, the fifth edition of the Bahrain Comic Con kicked off today at the Bahrain International Circuit. HH Shaikh Khalid’s sons, &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/bahrain-comic-con-2024-kicks-off/">Bahrain Comic Con 2024 Kicks Off</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi: Direct KSA to Iraq Flight Routes Announced
 - [https://www.gulf-insider.com/saudi-direct-ksa-to-iraq-flight-routes-announced](https://www.gulf-insider.com/saudi-direct-ksa-to-iraq-flight-routes-announced)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T05:17:28+00:00

<p>The Saudi General Authority of Civil Aviation announced the launch of direct flights from Dammam to Najaf. The decision is in line with the Kingdom’s national aviation sector strategy, aimed at doubling capacity to accommodate over 330 million passengers annually, and extending services to more than 250 global destinations. These flights, along with flights to &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-direct-ksa-to-iraq-flight-routes-announced/">Saudi: Direct KSA to Iraq Flight Routes Announced</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi: Endangered Red-Necked Ostrich Chicks Born in Royal Reserve
 - [https://www.gulf-insider.com/endangered-red-necked-ostrich-chicks-born-in-royal-reserve](https://www.gulf-insider.com/endangered-red-necked-ostrich-chicks-born-in-royal-reserve)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T05:12:22+00:00

<p>The Imam Turki bin Abdullah Royal Nature Reserve Development Authority has announced the birth of three endangered red-necked ostrich chicks. The birds have been considered extinct in the northern region of the Kingdom for a century and have now returned thanks to the efforts of the ITBA, the Saudi Press Agency reported on Friday. The &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/endangered-red-necked-ostrich-chicks-born-in-royal-reserve/">Saudi: Endangered Red-Necked Ostrich Chicks Born in Royal Reserve</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Kuwait Temporarily Halts Issuance of Work Visas for Egyptian Nationals
 - [https://www.gulf-insider.com/kuwait-temporarily-halts-issuance-of-work-visas-for-egyptian-nationals](https://www.gulf-insider.com/kuwait-temporarily-halts-issuance-of-work-visas-for-egyptian-nationals)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T05:04:37+00:00

<p>Kuwait has temporarily halted the issuance of work visas for Egyptian nationals, citing reliable sources from the Ministry of Interior and the Public Authority for Manpower. This decision, effective from April 23, follows the recent resumption of visa services and is aimed at introducing stricter oversight measures in the visa issuance process. The suspension is &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/kuwait-temporarily-halts-issuance-of-work-visas-for-egyptian-nationals/">Kuwait Temporarily Halts Issuance of Work Visas for Egyptian Nationals</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Oman: Three Nurses Killed Outside Nizwa Hospital
 - [https://www.gulf-insider.com/oman-three-nurses-killed-outside-nizwa-hospital](https://www.gulf-insider.com/oman-three-nurses-killed-outside-nizwa-hospital)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T04:58:26+00:00

<p>Three nurses were killed in a traffic accident that took place on Thursday outside Oman’s Nizwa Hospital, located in the Al Dakhiliyah governorate. The nurses tragically lost their lives when two vehicles collided and veered towards them as they awaited an opportunity to cross the highway. The accident also resulted in injuries to two other &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/oman-three-nurses-killed-outside-nizwa-hospital/">Oman: Three Nurses Killed Outside Nizwa Hospital</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## First Saudi Opera Premiers in Riyadh
 - [https://www.gulf-insider.com/first-saudi-opera-premiers-in-riyadh](https://www.gulf-insider.com/first-saudi-opera-premiers-in-riyadh)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T04:53:45+00:00

<p>Saudi Arabia’s first opera show started premiering in Riyadh where it will stage 10 performances over eight days. “Zarqa Al Yamama”, also considered the largest Arabic opera production, started its domestic showings at the King Fahd Cultural Centre in Riyadh on Thursday and runs through May 4. Last February, the opera had its international premiere &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/first-saudi-opera-premiers-in-riyadh/">First Saudi Opera Premiers in Riyadh</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Health Ministry Reports 15 Food Poisoning Cases Linked to One Establishment in Riyadh
 - [https://www.gulf-insider.com/health-ministry-reports-15-food-poisoning-cases-linked-to-one-establishment-in-riyadh](https://www.gulf-insider.com/health-ministry-reports-15-food-poisoning-cases-linked-to-one-establishment-in-riyadh)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T04:49:26+00:00

<p>Dr. Mohammed Al-Abdali, spokesperson for the Saudi Ministry of Health, reported several food poisoning cases in Riyadh, with 15 confirmed incidents traced back to a single establishment, which has since been closed. The affected individuals received necessary medical care, and the ministry is coordinating with relevant authorities to handle the situation appropriately.</p>
<p>The post <a href="https://www.gulf-insider.com/health-ministry-reports-15-food-poisoning-cases-linked-to-one-establishment-in-riyadh/">Health Ministry Reports 15 Food Poisoning Cases Linked to One Establishment in Riyadh</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi Arabia Starting Direct Flights Between Dammam and Najaf
 - [https://www.gulf-insider.com/saudi-arabia-starting-direct-flights-between-dammam-and-najaf](https://www.gulf-insider.com/saudi-arabia-starting-direct-flights-between-dammam-and-najaf)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T04:45:46+00:00

<p>Saudi Arabia has announced new direct flights between Dammam and the Iraqi city of Al Najaf. The General Authority of Civil Aviation (GACA) said on Friday that the move was in line with the Kingdom&#8217;s national aviation strategy aimed at increasing capacity to over 330 million passengers annually to and from more than 250 global &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-arabia-starting-direct-flights-between-dammam-and-najaf/">Saudi Arabia Starting Direct Flights Between Dammam and Najaf</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## China Warns US Not to Step on Its ‘Red Lines’
 - [https://www.gulf-insider.com/china-warns-us-not-to-step-on-its-red-lines](https://www.gulf-insider.com/china-warns-us-not-to-step-on-its-red-lines)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T04:10:51+00:00

<p>Chinese Foreign Minister Wang Yi has cautioned his US counterpart Antony Blinken against stepping on China&#8217;s &#8220;red lines” at a meeting between the two countries&#8217; top diplomats in Beijing. Mr Wang acknowledged the China-US relationship was beginning to stabilise, but said it was still being tested by &#8220;negative factors&#8221;. After meeting China&#8217;s President Xi Jinping, &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/china-warns-us-not-to-step-on-its-red-lines/">China Warns US Not to Step on Its ‘Red Lines’</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Climb Stairs to Live Longer, Say Cardiologists
 - [https://www.gulf-insider.com/climb-stairs-to-live-longer-say-cardiologists](https://www.gulf-insider.com/climb-stairs-to-live-longer-say-cardiologists)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T04:05:10+00:00

<p>Climbing stairs is associated with a longer life, according to research presented at ESC Preventive Cardiology 2024, a scientific congress of the European Society of Cardiology (ESC). &#8220;If you have the choice of taking the stairs or the lift, go for the stairs as it will help your heart,&#8221; said study author Dr. Sophie Paddock of &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/climb-stairs-to-live-longer-say-cardiologists/">Climb Stairs to Live Longer, Say Cardiologists</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi Arabia Issues Visa Warning, Cracks Down On Fake Hajj Companies
 - [https://www.gulf-insider.com/saudi-arabia-issues-visa-warning-cracks-down-on-fake-hajj-companies](https://www.gulf-insider.com/saudi-arabia-issues-visa-warning-cracks-down-on-fake-hajj-companies)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-04-27T02:49:54+00:00

<p>Saudi Arabia’s Ministry of Hajj and Umrah has warned pilgrims about fake Hajj companies for 2024. It has also emphasised that a Hajj visa issued by Saudi authorities or official channels is mandatory. It said fake Hajj companies often advertise on social media in various countries. Saudi Hajj visaThe ministry commended the Iraqi Supreme Authority &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-arabia-issues-visa-warning-cracks-down-on-fake-hajj-companies/">Saudi Arabia Issues Visa Warning, Cracks Down On Fake Hajj Companies</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

