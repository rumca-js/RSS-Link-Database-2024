# Source:Times of India, URL:https://timesofindia.indiatimes.com/rssfeedstopstories.cms, language:en-gb

## No insurance? Be ready to pay more at hospitals
 - [https://timesofindia.indiatimes.com/india/no-insurance-be-ready-to-pay-more-at-hospitals/articleshow/109657934.cms](https://timesofindia.indiatimes.com/india/no-insurance-be-ready-to-pay-more-at-hospitals/articleshow/109657934.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T23:22:05+00:00



## Sindhi nationalist condemns forced conversion of Hindu girls
 - [https://timesofindia.indiatimes.com/world/pakistan/sindhi-nationalist-condemns-forced-conversion-of-hindu-girls/articleshow/109655440.cms](https://timesofindia.indiatimes.com/world/pakistan/sindhi-nationalist-condemns-forced-conversion-of-hindu-girls/articleshow/109655440.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T22:26:08+00:00



## ICICI Bank Q4 net profit jumps 17.4% to 10,708 crore
 - [https://timesofindia.indiatimes.com/business/india-business/icici-bank-q4-net-profit-jumps-17-4-to-10708-crore-asset-quality-improves/articleshow/109655155.cms](https://timesofindia.indiatimes.com/business/india-business/icici-bank-q4-net-profit-jumps-17-4-to-10708-crore-asset-quality-improves/articleshow/109655155.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T22:21:15+00:00

ICICI Bank, the second-largest private lender, has reported a net profit of Rs 10,708 crore for the quarter ended March 2024, marking an increase of 17.4%, surpassing analyst forecasts. The bank’s board has recommended a dividend of Rs 10 per share. At the end of the quarter, the bank’s deposits stood at Rs 14,12,825 crore, up by 19.6% from March 2023.

## ‘Beacon of hope’: Navy veteran released from Qatar hails PM Modi
 - [https://timesofindia.indiatimes.com/india/beacon-of-hope-navy-veteran-released-from-qatar-hails-pm-modi/articleshow/109654993.cms](https://timesofindia.indiatimes.com/india/beacon-of-hope-navy-veteran-released-from-qatar-hails-pm-modi/articleshow/109654993.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T22:02:15+00:00



## ‘Not even 1/4th of our claim’: Karnataka slams 3.4k crore drought aid
 - [https://timesofindia.indiatimes.com/india/not-even-1/4th-of-our-claim-karnataka-slams-3-4k-crore-drought-aid/articleshow/109654967.cms](https://timesofindia.indiatimes.com/india/not-even-1/4th-of-our-claim-karnataka-slams-3-4k-crore-drought-aid/articleshow/109654967.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T21:56:00+00:00

Nearly six months after Karnataka submitted a memorandum, the state on Saturday finally received Rs 3,454 crore from Centre under Natural Disaster Response Fund (NDRF) to counter the prevailing drought situation. This, however, is way short of Karnataka’s initial demand of Rs 18,174 crore, which included Rs 5,662 crore for compensation to farmers.

## Eye on China, govt aims to double electronics value addition to 40%
 - [https://timesofindia.indiatimes.com/india/eye-on-china-govt-aims-to-double-electronics-value-addition-to-40/articleshow/109654980.cms](https://timesofindia.indiatimes.com/india/eye-on-china-govt-aims-to-double-electronics-value-addition-to-40/articleshow/109654980.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T21:54:48+00:00



## Polls jam flow of water from Karnataka to Telangana
 - [https://timesofindia.indiatimes.com/india/polls-jam-flow-of-water-from-karnataka-to-telangana/articleshow/109654843.cms](https://timesofindia.indiatimes.com/india/polls-jam-flow-of-water-from-karnataka-to-telangana/articleshow/109654843.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T21:35:54+00:00

The vagaries of climate change may not have made it to the manifestos of parties in this Lok Sabha election, but drinking water is all set to become a prickly political issue just days before people line up to vote in Telangana on May 13. As water levels dip in reservoirs across the state, govt is hoping Karnataka comes to its rescue.

## 'Sugar turns into fat in liver, can affect kids as young as 9'
 - [https://timesofindia.indiatimes.com/times-special/sugar-turns-into-fat-in-liver-can-affect-kids-as-young-as-9/articleshow/109654844.cms](https://timesofindia.indiatimes.com/times-special/sugar-turns-into-fat-in-liver-can-affect-kids-as-young-as-9/articleshow/109654844.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T21:29:52+00:00



## 2 youths forced into cyber fraud by Chinese co in Cambodia
 - [https://timesofindia.indiatimes.com/india/2-telangana-youths-forced-into-cyber-fraud-by-chinese-company-in-cambodia-one-rescued/articleshow/109654842.cms](https://timesofindia.indiatimes.com/india/2-telangana-youths-forced-into-cyber-fraud-by-chinese-company-in-cambodia-one-rescued/articleshow/109654842.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T21:29:50+00:00

A job racket involving a Chinese company - operating in Cambodia and committing cyber frauds - was busted by Cambodian police after an alert by Rajanna Sircilla district police in Telangana.A graduate from Sircilla district, who was sent to Sihanoukville, a coastal city in Cambodia, three months ago by the fraudsters to work in Chinese firm, has been rescued and is being brought back to Telangana.

## BJP will alter Constitution, deny people’s rights: Priyanka Gandhi
 - [https://timesofindia.indiatimes.com/india/bjp-will-alter-constitution-deny-peoples-rights-priyanka-gandhi/articleshow/109654834.cms](https://timesofindia.indiatimes.com/india/bjp-will-alter-constitution-deny-peoples-rights-priyanka-gandhi/articleshow/109654834.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T21:25:33+00:00

Congress general secretary Priyanka Gandhi Vadra launched a scathing attack on BJP-led NDA govt over inflation and unemployment during a campaign rally for Lok Sabha elections in Dharampur of Gujarat’s Valsad district on Saturday. She alleged that BJP would alter the Constitution if it came to office for a third time.

## Mamata, BJP spar over arms recovery in Sandeshkhali
 - [https://timesofindia.indiatimes.com/india/mamata-bjp-spar-over-arms-recovery-in-sandeshkhali/articleshow/109654819.cms](https://timesofindia.indiatimes.com/india/mamata-bjp-spar-over-arms-recovery-in-sandeshkhali/articleshow/109654819.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T21:11:47+00:00



## 26/11 prosecutor Ujjwal Nikam gets BJP ticket
 - [https://timesofindia.indiatimes.com/india/26/11-prosecutor-ujjwal-nikam-gets-bjp-ticket/articleshow/109654813.cms](https://timesofindia.indiatimes.com/india/26/11-prosecutor-ujjwal-nikam-gets-bjp-ticket/articleshow/109654813.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T21:09:13+00:00

BJP has fielded 26/11 prosecutor Ujjwal Nikam as its candidate from Mumbai North Central seat, dropping two-term incumbent Poonam Mahajan from the contest. Nikam, a prominent presence on prime time TV during the trial of Ajmal Kasab as well as during the trial of the accused in the 1993 serial blasts, is expected to be a good fit for BJP’s “tough-on-terrorism” plank.

## Widespread public support: Vadra on Amethi poll entry plan
 - [https://timesofindia.indiatimes.com/india/widespread-public-support-vadra-on-amethi-poll-entry-plan/articleshow/109654796.cms](https://timesofindia.indiatimes.com/india/widespread-public-support-vadra-on-amethi-poll-entry-plan/articleshow/109654796.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:52:49+00:00



## Thakur cites 'inheritance tax' issue to fire salvo at Gandhis
 - [https://timesofindia.indiatimes.com/india/thakur-cites-inheritance-tax-issue-to-fire-salvo-at-gandhis/articleshow/109654779.cms](https://timesofindia.indiatimes.com/india/thakur-cites-inheritance-tax-issue-to-fire-salvo-at-gandhis/articleshow/109654779.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:47:44+00:00



## Two CRPF men killed in Manipur attack, 1st strike on peacekeepers
 - [https://timesofindia.indiatimes.com/india/two-crpf-men-killed-in-manipur-attack-1st-strike-on-peacekeepers-in-state/articleshow/109654773.cms](https://timesofindia.indiatimes.com/india/two-crpf-men-killed-in-manipur-attack-1st-strike-on-peacekeepers-in-state/articleshow/109654773.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:46:37+00:00

Two personnel from 128 Battalion of CRPF lost their lives and two colleagues were wounded in an attack by unidentified militants at 12.15am Saturday in Manipur’s Bishnupur district. This was the first attack on a Central Armed Police Force deployed for peacekeeping duties in the state since the ethnic conflict began in May last year.

## In Godhra, Amit Shah pays homage to Ram temple kar sevaks
 - [https://timesofindia.indiatimes.com/india/in-godhra-amit-shah-pays-homage-to-ram-temple-kar-sevaks/articleshow/109654755.cms](https://timesofindia.indiatimes.com/india/in-godhra-amit-shah-pays-homage-to-ram-temple-kar-sevaks/articleshow/109654755.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:38:20+00:00



## Girlfriend's father guns down BTech student in her Ghaziabad
 - [https://timesofindia.indiatimes.com/city/ghaziabad/girlfriends-father-guns-down-btech-student-in-her-ghaziabad-apartment/articleshow/109654748.cms](https://timesofindia.indiatimes.com/city/ghaziabad/girlfriends-father-guns-down-btech-student-in-her-ghaziabad-apartment/articleshow/109654748.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:34:57+00:00

A third-year BTech student was shot dead by his girlfriend's father at a condominium in Crossings Republik, where both the youngsters lived but in separate flats, in the early hours of Saturday. Rajesh Kumar Singh, a retired BSF jawan, pumped 4-5 bullets into the chest of Vipul Verma after a spat with him at his daughter’s flat on the 14th floor of Paramount Symphony in the Ghaziabad township, police said.

## No Muslim in MVA list of 48 picks, Maha Cong neta sulks
 - [https://timesofindia.indiatimes.com/city/mumbai/no-muslim-in-mva-list-of-48-picks-maha-cong-neta-sulks/articleshow/109654743.cms](https://timesofindia.indiatimes.com/city/mumbai/no-muslim-in-mva-list-of-48-picks-maha-cong-neta-sulks/articleshow/109654743.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:28:39+00:00



## Cong skips call on Rae Bareli, Amethi; Rahul may visit old seat soon
 - [https://timesofindia.indiatimes.com/india/congress-again-skips-call-on-rae-bareli-amethi-rahul-may-visit-old-seat-soon/articleshow/109654715.cms](https://timesofindia.indiatimes.com/india/congress-again-skips-call-on-rae-bareli-amethi-rahul-may-visit-old-seat-soon/articleshow/109654715.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:24:54+00:00

Stoking the suspense further on Amethi and Rae Bareli candidatures, Congress on Saturday left it to party president Mallikarjun Kharge to decide on the nominees, amid another strong demand that Rahul Gandhi and Priyanka Gandhi Vadra contest from the twin seats identified with the Gandhi family. Congress has announced all its 17 candidates from UP, barring Amethi and Rae Bareli.

## Arrest illegal and arbitrary, ED acting with malice: CM Kejriwal
 - [https://timesofindia.indiatimes.com/india/arrest-illegal-and-arbitrary-ed-acting-with-malice-cm-kejriwal/articleshow/109654679.cms](https://timesofindia.indiatimes.com/india/arrest-illegal-and-arbitrary-ed-acting-with-malice-cm-kejriwal/articleshow/109654679.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:16:59+00:00

Accusing the Centre of “misusing” Enforcement Directorate to “crush” its political opponents ahead of the parliamentary elections, chief minister Arvind Kejriwal has told Supreme Court that his arrest was illegal, arbitrary and an unprecedented assault on the tenets of democracy based on free and fair elections and federalism. CM said ED was acting with “malicious intent” against him in a gross affront to due process of law.

## Fading glow? Lals may no longer be red-hot in Haryana politics
 - [https://timesofindia.indiatimes.com/india/fading-glow-lals-may-no-longer-be-red-hot-in-haryana-politics/articleshow/109654653.cms](https://timesofindia.indiatimes.com/india/fading-glow-lals-may-no-longer-be-red-hot-in-haryana-politics/articleshow/109654653.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:06:26+00:00



## Phase 2 turnout higher than 2019 in Maharashtra, K’taka & Chh’garh
 - [https://timesofindia.indiatimes.com/india/phase-2-turnout-higher-than-2019-in-maharashtra-karnataka-chhattisgarh/articleshow/109654651.cms](https://timesofindia.indiatimes.com/india/phase-2-turnout-higher-than-2019-in-maharashtra-karnataka-chhattisgarh/articleshow/109654651.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:06:19+00:00

Voter turnout in the second phase of the Lok Sabha election reached 66.7%, as of Saturday evening, for 88 constituencies that went to the polls. There’s possibility of a slight increase as the Election Commission receives more reports from states. The turnout until late Friday night was approximately 64.7%. The overall turnout was 69.4% in 2019 in 81 of these seats.

## Live ballads, anthems and musical battle cries set tone for polls
 - [https://timesofindia.indiatimes.com/india/live-ballads-anthems-and-musical-battle-cries-set-tone-for-polls/articleshow/109654649.cms](https://timesofindia.indiatimes.com/india/live-ballads-anthems-and-musical-battle-cries-set-tone-for-polls/articleshow/109654649.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T20:04:04+00:00



## It’s Congress that wants to change Constitution: PM Modi
 - [https://timesofindia.indiatimes.com/india/its-congress-that-wants-to-change-constitution-pm-modi/articleshow/109654630.cms](https://timesofindia.indiatimes.com/india/its-congress-that-wants-to-change-constitution-pm-modi/articleshow/109654630.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T19:57:05+00:00

PM Modi alleged at a campaign rally in Kolhapur, Maharashtra, on Saturday that Congress wants to extend the “Karnataka model” of offering reservation to all Muslims in the country by “planning a dacoity on 27% OBC quota”, and that it “plans to change the Constitution for this appeasement”. Later, addressing a rally in Sancoale, South Goa, Modi said “the Constitution holds no significance” for Congress.

## MCOCA to be invoked against Bishnoi, others for Salman home firing
 - [https://timesofindia.indiatimes.com/india/mcoca-to-be-invoked-against-bishnoi-others-for-salman-home-firing/articleshow/109654636.cms](https://timesofindia.indiatimes.com/india/mcoca-to-be-invoked-against-bishnoi-others-for-salman-home-firing/articleshow/109654636.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T19:56:33+00:00



## Nobody can break Delhi CM, wife Sunita says as she begins campaign
 - [https://timesofindia.indiatimes.com/india/nobody-can-break-delhi-cm-wife-sunita-says-as-she-begins-city-campaign/articleshow/109654609.cms](https://timesofindia.indiatimes.com/india/nobody-can-break-delhi-cm-wife-sunita-says-as-she-begins-city-campaign/articleshow/109654609.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T19:49:32+00:00



## Lakhimpur horror: 17-yr-old girl confined & raped for 3 days
 - [https://timesofindia.indiatimes.com/india/lakhimpur-horror-17-yr-old-girl-confined-raped-for-3-days/articleshow/109654589.cms](https://timesofindia.indiatimes.com/india/lakhimpur-horror-17-yr-old-girl-confined-raped-for-3-days/articleshow/109654589.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T19:42:54+00:00



## 10 years after son's death in Red attack, Cong neta killed by Maoists
 - [https://timesofindia.indiatimes.com/india/10-years-after-sons-death-in-red-attack-cong-neta-killed-by-maoists-in-bastar/articleshow/109654562.cms](https://timesofindia.indiatimes.com/india/10-years-after-sons-death-in-red-attack-cong-neta-killed-by-maoists-in-bastar/articleshow/109654562.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T19:33:14+00:00



## UGC ex-chief DP Singh named new TISS head
 - [https://timesofindia.indiatimes.com/india/ugc-ex-chief-dp-singh-named-new-tiss-head/articleshow/109654560.cms](https://timesofindia.indiatimes.com/india/ugc-ex-chief-dp-singh-named-new-tiss-head/articleshow/109654560.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T19:32:01+00:00



## Forest fires reach doorsteps of Nainital, IAF called in to help
 - [https://timesofindia.indiatimes.com/city/dehradun/forest-fires-reach-doorsteps-of-nainital-iaf-called-in-to-help/articleshow/109654558.cms](https://timesofindia.indiatimes.com/city/dehradun/forest-fires-reach-doorsteps-of-nainital-iaf-called-in-to-help/articleshow/109654558.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T19:31:49+00:00

A day after the wildfires raging in Uttrakhand's Kumaon region reached precariously close to Nainital town, authorities on Saturday deployed an MI-17 helicopter from the Indian Air Force to douse the blaze in Lariakanta area of Nainital and adjoining areas like Pines, Bhumiyadhar, Jeolikote, Narayan Nagar, Bhowali, Ramgarh, and Mukteshwar.

## Bulgarian in Cadila rape row seeks job back
 - [https://timesofindia.indiatimes.com/india/bulgarian-in-cadila-rape-row-seeks-job-back/articleshow/109654490.cms](https://timesofindia.indiatimes.com/india/bulgarian-in-cadila-rape-row-seeks-job-back/articleshow/109654490.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T19:20:20+00:00



## Eye on LS polls? Centre lifts 5-month ban on onion exports
 - [https://timesofindia.indiatimes.com/india/eye-on-ls-polls-centre-lifts-5-month-ban-on-onion-exports/articleshow/109654417.cms](https://timesofindia.indiatimes.com/india/eye-on-ls-polls-centre-lifts-5-month-ban-on-onion-exports/articleshow/109654417.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T19:05:01+00:00



## Piyush Goyal challenges Rahul Gandhi to contest against him or Modi
 - [https://timesofindia.indiatimes.com/india/piyush-goyal-challenge-rahul-gandhi-to-contest-against-him-or-modi/articleshow/109654160.cms](https://timesofindia.indiatimes.com/india/piyush-goyal-challenge-rahul-gandhi-to-contest-against-him-or-modi/articleshow/109654160.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T18:33:40+00:00



## Rajasthan take 'royal' stride towards IPL play-off
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/lsg-vs-rr-ipl-2024-highlights-rajasthan-take-royal-stride-towards-play-off-beat-lucknow-super-giants-by-7-wickets/articleshow/109653861.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/lsg-vs-rr-ipl-2024-highlights-rajasthan-take-royal-stride-towards-play-off-beat-lucknow-super-giants-by-7-wickets/articleshow/109653861.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T18:23:52+00:00

Sanju Samson's unbeaten 71 off 33 balls, despite being five runs shy of his counterpart KL Rahul's 76, had a much greater impact due to his aggressive play. His innings propelled the Rajasthan Royals to a seven-wicket victory over the Lucknow Super Giants on Saturday, giving them a significant boost towards the IPL playoffs.

## Best Selling Microwave Ovens You Must Have For Convenience, Ease of Usage and Culinary Exploration
 - [https://timesofindia.indiatimes.com/hot-picks/best-selling-microwave-ovens-you-must-have-for-convenience-ease-of-usage-and-culinary-exploration/articleshow/109571302.cms](https://timesofindia.indiatimes.com/hot-picks/best-selling-microwave-ovens-you-must-have-for-convenience-ease-of-usage-and-culinary-exploration/articleshow/109571302.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T17:52:32+00:00

The best-selling microwave ovens are designed to accommodate any lifestyle and cooking choice, whether a busy professional seeking to simplify meal preparation or a food enthusiast exploring new recipes. These gadgets save time and effort in the kitchen and raise the bar for convenience and accuracy in cooking because of their cutting-edge features, simple controls, and stylish designs.

## Hardik in focus as Agarkar set to meet Rohit in Delhi
 - [https://timesofindia.indiatimes.com/sports/cricket/icc-mens-t20-world-cup/t20-world-cup-squad-selection-hardik-pandya-in-focus-as-ajit-agarkar-set-to-meet-rohit-sharma-in-delhi/articleshow/109653681.cms](https://timesofindia.indiatimes.com/sports/cricket/icc-mens-t20-world-cup/t20-world-cup-squad-selection-hardik-pandya-in-focus-as-ajit-agarkar-set-to-meet-rohit-sharma-in-delhi/articleshow/109653681.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T17:44:32+00:00

Chairman of national selection committee Ajit Agarkar and skipper Rohit Sharma are expected to have an informal meeting in the national capital on a possible 15-member squad for the T20 World Cup in the Americas.

## Rahul to fight from Amethi, Priyanka from Raebareli?
 - [https://timesofindia.indiatimes.com/india/up-congress-urges-top-party-leadership-to-field-rahul-from-amethi-priyanka-raebareli/articleshow/109653632.cms](https://timesofindia.indiatimes.com/india/up-congress-urges-top-party-leadership-to-field-rahul-from-amethi-priyanka-raebareli/articleshow/109653632.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T17:30:47+00:00



## MDH says its products are safe; rejects pesticide allegation
 - [https://timesofindia.indiatimes.com/business/india-business/mdh-says-its-products-are-safe-rejects-pesticide-allegation/articleshow/109653543.cms](https://timesofindia.indiatimes.com/business/india-business/mdh-says-its-products-are-safe-rejects-pesticide-allegation/articleshow/109653543.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T17:21:28+00:00



## ED summons AAP MLA Amanatullah Khan in Delhi Waqf Board case
 - [https://timesofindia.indiatimes.com/city/delhi/ed-summons-aap-mla-amanatullah-khan-in-delhi-waqf-board-case/articleshow/109653292.cms](https://timesofindia.indiatimes.com/city/delhi/ed-summons-aap-mla-amanatullah-khan-in-delhi-waqf-board-case/articleshow/109653292.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T17:08:47+00:00

The Enforcement Directorate (ED) summoned AAP MLA Amanatullah Khan to appear before it on April 29 in a money laundering case related to alleged irregularities in the Delhi Waqf Board during his chairmanship. The central agency has called the AAP MLA to provide his statement in accordance with the Prevention of Money Laundering Act (PMLA).

## Trials for Vande Metro trains to begin in July
 - [https://timesofindia.indiatimes.com/india/trials-for-short-distance-vande-metro-trains-to-begin-in-july-for-vande-bharat-sleeper-in-may/articleshow/109653225.cms](https://timesofindia.indiatimes.com/india/trials-for-short-distance-vande-metro-trains-to-begin-in-july-for-vande-bharat-sleeper-in-may/articleshow/109653225.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T16:57:20+00:00

Indian Railways is gearing up to commence trial runs of short-distance Vande Metro trains in July, alongside the launch of the sleeper version of Vande Bharat next month. The Vande Metro trains are slated to operate on routes spanning 100-250 kilometers, while the Vande Bharat Sleeper trains will be designated for routes exceeding 1,000 kilometers. Officials indicate that the Vande Metro trains will establish connections across approximately 124 cities.

## McGurk: From losing contract to smoking Bumrah
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/jake-fraser-mcgurk-from-losing-state-contract-to-smoking-jasprit-bumrah/articleshow/109653071.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/jake-fraser-mcgurk-from-losing-state-contract-to-smoking-jasprit-bumrah/articleshow/109653071.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T16:46:52+00:00

In the 2022-23 season, Cricket Victoria downgraded Jake Fraser-McGurk contract to the level of a rookie, leaving the hard-hitting batter with no option but to shift to South Australia for greener pastures.

## Congress moves EC over Anurag Thakur's 'outrageous speech', 'property to Muslims' remark
 - [https://timesofindia.indiatimes.com/india/name-and-shame-these-offenders-congress-hits-back-at-anurag-thakur-property-to-muslim-claims/articleshow/109652649.cms](https://timesofindia.indiatimes.com/india/name-and-shame-these-offenders-congress-hits-back-at-anurag-thakur-property-to-muslim-claims/articleshow/109652649.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T16:20:56+00:00

The Indian National Congress on Saturday disagreed and took action against Union Minister Anurag Thakur's claims about the "distribution of property to Muslims, " by taking it to the Election Commission of India. Thakur during a public rally in Himachal Pradesh said, "You have to decide whether the children's property should remain with them or should it go to Muslims."

## Hardik Pandya slammed for not utilising Bumrah properly
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/hardik-pandya-slammed-for-not-utilising-jasprit-bumrah-properly-against-jake-fraser-mcgurk/articleshow/109652630.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/hardik-pandya-slammed-for-not-utilising-jasprit-bumrah-properly-against-jake-fraser-mcgurk/articleshow/109652630.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T16:16:15+00:00

Powerful hitting from Jake Fraser-McGurk and Tristan Stubbs propelled the Delhi Capitals to a 10-run victory over the Mumbai Indians in a high-scoring IPL match on Saturday. Fraser-McGurk smashed 84 runs off just 27 balls, hitting 11 fours and six sixes, while Stubbs added an unbeaten 48 off 25 balls later in the innings, helping Delhi post a formidable total of 257 for four in 20 overs.

## 'Not 400 par but ...': Akhilesh mocks BJP's poll slogan
 - [https://timesofindia.indiatimes.com/india/not-400-par-but-akhilesh-yadav-mocks-bjps-lok-sabha-slogan/articleshow/109652668.cms](https://timesofindia.indiatimes.com/india/not-400-par-but-akhilesh-yadav-mocks-bjps-lok-sabha-slogan/articleshow/109652668.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T16:15:18+00:00

Samajwadi Party's Akhilesh Yadav criticizes BJP's shift from '400 paar' to '400 haar' slogan, emphasizes on Constitution, reservation policies and promises of free wheat, data for Kannauj Lok Sabha seat.

## Pant latest to join 'Impact Sub' bashing club, says it's...
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/rishabh-pant-latest-to-join-impact-sub-bashing-club-says-its-/articleshow/109652320.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/rishabh-pant-latest-to-join-impact-sub-bashing-club-says-its-/articleshow/109652320.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T15:33:56+00:00

Delhi Capitals skipper Rishabh Pant is the latest India star to express his apprehensions about the contentious Impact Player rule after his team won back-to-back high-scoring IPL matches in which chasing teams Gujarat Titans and Mumbai Indians came really close.

## ISI inteference: Need firewall around judiciary to deter meddling, says Pak SC judge
 - [https://timesofindia.indiatimes.com/world/pakistan/isi-interfering-in-justice-system-need-firewall-around-judiciary-to-deter-meddling-says-pakistan-sc-judge/articleshow/109652102.cms](https://timesofindia.indiatimes.com/world/pakistan/isi-interfering-in-justice-system-need-firewall-around-judiciary-to-deter-meddling-says-pakistan-sc-judge/articleshow/109652102.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T15:28:49+00:00



## 'Nobody can break Kejriwal': Wife Sunita at maiden roadshow
 - [https://timesofindia.indiatimes.com/india/remove-dictatorship-and-save-democracy-top-quotes-from-sunita-kejriwals-maiden-roadshow-for-lok-sabha-polls/articleshow/109651308.cms](https://timesofindia.indiatimes.com/india/remove-dictatorship-and-save-democracy-top-quotes-from-sunita-kejriwals-maiden-roadshow-for-lok-sabha-polls/articleshow/109651308.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T14:29:01+00:00

Sunita Kejriwal, the wife of Delhi's chief minister Arvind Kejriwal, made her political debut with a roadshow for the AAP's East Delhi candidate during the Lok Sabha polls. She actively interacted with party supporters in the Kondli area of the East Delhi constituency during the event.

## IPL: Delhi go past Mumbai in run-fest at Kotla
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/ipl-2024-delhi-capitals-go-past-mumbai-indians-in-run-fest-at-kotla/articleshow/109651394.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/ipl-2024-delhi-capitals-go-past-mumbai-indians-in-run-fest-at-kotla/articleshow/109651394.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T14:27:09+00:00

Delhi Capitals defeated Mumbai Indians in an thrilling IPL match at the Arun Jaitley Stadium. Fraser-McGurk's batting brilliance, supported by a strong bowling performance by Rasikh Dar Salam, helped them achieve their highest IPL total and secure a crucial 10-run win which has kept DC in the hunt for a place in the playoffs.

## Congress wants to give property of your children to Muslims: Anurag Thakur
 - [https://timesofindia.indiatimes.com/india/himachal-pradesh-anurag-thakur-says-congress-wants-to-give-property-of-your-children-to-muslims/articleshow/109651124.cms](https://timesofindia.indiatimes.com/india/himachal-pradesh-anurag-thakur-says-congress-wants-to-give-property-of-your-children-to-muslims/articleshow/109651124.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T14:16:17+00:00

Union minister and BJP candidate from the Hamirpur parliamentary seat Anurag Thakur, accused the Congress of having foreign influences evident in its manifesto. Criticizing the Congress stance on inheritance, he alleged that the party aims to transfer the property of citizens' children to Muslims, dismantle the nation's nuclear arsenal, and promote division based on caste and regional identities.

## Cong, allies want to split south India into separate nation: PM
 - [https://timesofindia.indiatimes.com/elections/lok-sabha-elections/lok-sabha-election-news/unable-to-compete-congress-resorting-to-anti-national-agendas-pm-modi/articleshow/109650357.cms](https://timesofindia.indiatimes.com/elections/lok-sabha-elections/lok-sabha-election-news/unable-to-compete-congress-resorting-to-anti-national-agendas-pm-modi/articleshow/109650357.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T14:15:11+00:00

Prime Minister Narendra Modi on Saturday unleashed a scathing attack on the opposition INDIA bloc, particularly the Congress, accusing it of using "anti-national agendas and appeasement' to compete against BJP-led NDA in the ongoing Lok Sabha polls. Addressing a public rally in Maharashtra's Kolhapur, Prime Minister Narendra Modi lashed out at the opposition INDIA bloc for "demanding separate nation by splitting South India'.

## Confusion over who won toss in LSG-RR game. Watch
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-confusion-miscommunication-over-who-won-toss-during-lucknow-super-giants-rajasthan-royals-ipl-game/articleshow/109651011.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-confusion-miscommunication-over-who-won-toss-during-lucknow-super-giants-rajasthan-royals-ipl-game/articleshow/109651011.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T14:03:41+00:00

Royals skipper Sanju  Samson eventually won the toss and decided to field against Lucknow in the 44th match of this IPL season. Both LSG and RR retained the same playing XIs from their respective previous matches. Placed at the top of the table with 14 points in the bag, RR will look to continue with their surge and consolidate their position.

## 'He should fight on 4-5 seats': Piyush Goyal's jab at Rahul Gandhi
 - [https://timesofindia.indiatimes.com/india/he-should-fight-on-4-5-seats-piyush-goyals-jab-at-rahul-gandhi/articleshow/109650048.cms](https://timesofindia.indiatimes.com/india/he-should-fight-on-4-5-seats-piyush-goyals-jab-at-rahul-gandhi/articleshow/109650048.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T13:33:26+00:00

Union Minister and Bharatiya Janata Party (BJP) candidate from the Mumbai North Lok Sabha seat, Piyush Goyal, launched a strong criticism against Congress leader Rahul Gandhi. Goyal said, “I challenge Rahul to contest elections against me from the North Mumbai constituency. He should also try his luck from Varanasi. If he contests on 4-5 seats, maybe by chance, he might win on one.”

## 'Uncle's nonsense at weddings': Priyanka Gandhi mocks PM Modi
 - [https://timesofindia.indiatimes.com/india/uncles-nonsense-at-weddings-priyanka-gandhi-mocks-pm-modis-allegations-of-wealth-distribution-as-wedding-banter/articleshow/109650577.cms](https://timesofindia.indiatimes.com/india/uncles-nonsense-at-weddings-priyanka-gandhi-mocks-pm-modis-allegations-of-wealth-distribution-as-wedding-banter/articleshow/109650577.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T13:27:36+00:00

During a Gujarat rally, Priyanka Gandhi humorously critiques PM Modi's wealth redistribution claims and inflation policies. Rahul Gandhi predicts Modi's potential tears during speeches, hinting at underlying anxiety.

## Rohit breaks Kohli's this IPL record
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/despite-failing-against-delhi-capitals-rohit-sharma-manages-to-break-virat-kohlis-this-ipl-record/articleshow/109650440.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/despite-failing-against-delhi-capitals-rohit-sharma-manages-to-break-virat-kohlis-this-ipl-record/articleshow/109650440.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T13:19:42+00:00

Rohit Sharma's below-par performance against Delhi Capitals didn't hinder his achievement of a unique IPL record, as his 8-run knock surpassed Virat Kohli in this milestone.

## 'Hand of foreign forces in Congress manifesto': Anurag Thakur
 - [https://timesofindia.indiatimes.com/india/we-gave-all-rights-to-muslims-equally-anurag-thakur-slams-congress-at-public-rally-in-himachal-pradesh/articleshow/109650096.cms](https://timesofindia.indiatimes.com/india/we-gave-all-rights-to-muslims-equally-anurag-thakur-slams-congress-at-public-rally-in-himachal-pradesh/articleshow/109650096.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T13:07:46+00:00

Following the completion of Phase 2 of the Lok Sabha election, the BJP has started tightening its grip around Congress's manifesto. Union Minister Anurag Thakur during a public rally on Saturday claimed that 'foreign forces were involved in making the Congress party's election promises.' Thakur said that these forces wanted to give away the property of people's children to Muslims, get rid of the country's nuclear weapons, and divide the nation based on caste and region.

## Women will never forgive PM's 'Mangalsutra' remark: Congress
 - [https://timesofindia.indiatimes.com/city/chennai/women-will-never-forgive-pm-modi-for-his-mangalsutra-remark-mahila-congress/articleshow/109650162.cms](https://timesofindia.indiatimes.com/city/chennai/women-will-never-forgive-pm-modi-for-his-mangalsutra-remark-mahila-congress/articleshow/109650162.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T13:01:24+00:00



## Watch: Rohit Sharma gives Rishabh Pant a kite to fly
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-amid-fours-and-sixes-in-delhi-rohit-sharma-gives-rishabh-pant-a-kite-to-fly/articleshow/109649832.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-amid-fours-and-sixes-in-delhi-rohit-sharma-gives-rishabh-pant-a-kite-to-fly/articleshow/109649832.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T12:55:32+00:00

When Mumbai Indians took to the field to pursue Delhi Capitals' massive score of 257 for 4 in their Indian Premier League encounter in the capital city on Saturday, a kite suddenly plummeted to the center of the pitch, eliciting laughter from the spectators. However, what ensued quickly became a viral video online.

## Seized weapons might have been brought by CBI: WB CM Mamata
 - [https://timesofindia.indiatimes.com/elections/lok-sabha-elections/lok-sabha-election-news/tmc-calls-sandeshkhali-arms-recovery-bjps-ploy-writes-to-state-poll-chief/articleshow/109649088.cms](https://timesofindia.indiatimes.com/elections/lok-sabha-elections/lok-sabha-election-news/tmc-calls-sandeshkhali-arms-recovery-bjps-ploy-writes-to-state-poll-chief/articleshow/109649088.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T12:54:15+00:00

The Trinamool Congress (TMC) lodged a complaint with the chief electoral officer of West Bengal regarding a coordinated operation conducted by the Central Bureau of Investigation (CBI) and bomb squads from the elite National Security Guard (NSG). In the complaint, CM Mamata Banerjee's TMC has accused the CBI and NSG of working in cahoots with the Bharatiya Janata Party (BJP).

## Watch: Hardik Pandya loses cool at Mumbai Indians bowlers
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-hardik-pandya-loses-cool-as-mumbai-indians-bowlers-fail-to-stop-fiery-jake-fraser-mcgurk/articleshow/109649650.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-hardik-pandya-loses-cool-as-mumbai-indians-bowlers-fail-to-stop-fiery-jake-fraser-mcgurk/articleshow/109649650.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T12:40:51+00:00

Jake Fraser-McGurk displayed outstanding batting prowess with a blistering 27-ball 84 in the intense Delhi heat, guiding the Delhi Capitals to a formidable total of 257 for four against the Mumbai Indians in an IPL match on Saturday. Fraser-McGurk excelled in the opening stages, while Tristan Stubbs impressed in the closing overs with an unbeaten 48 off 25 balls, helping DC achieve their highest IPL score.

## IAF, Navy induct Israel-made supersonic 'Rampage' missiles
 - [https://timesofindia.indiatimes.com/india/indian-air-force-navy-induct-air-to-surface-rampage-missile-in-its-fleet/articleshow/109649375.cms](https://timesofindia.indiatimes.com/india/indian-air-force-navy-induct-air-to-surface-rampage-missile-in-its-fleet/articleshow/109649375.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T12:33:13+00:00

The Indian Air Force has enhanced its arsenal of fighter aircraft with the introduction of Rampage long-range supersonic air-to-ground missiles, capable of striking targets up to 250 kilometers away. Known as the High-Speed Low Drag-Mark 2 missile within the Indian Air Force, this weapon has seen significant use by the Israeli Air Force in recent operations against Iranian targets.

## 4,4,6,4,4,4: Stubbs hammers Wood into submission. Watch
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/4-4-6-4-4-4-red-hot-tristan-stubbs-hammers-pacer-luke-wood-into-submission-watch/articleshow/109649367.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/4-4-6-4-4-4-red-hot-tristan-stubbs-hammers-pacer-luke-wood-into-submission-watch/articleshow/109649367.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T12:21:05+00:00

Bringing his big-hitting prowess to the fore, young Jake Fraser-McGurk gave the scorching Delhi heat competition with a sizzling 27-ball 84 that powered Delhi Capitals to a massive 257 for four against Mumbai Indians in an IPL contest on Saturday. While McGurk sparkled upfront, Tristan Stubbs dazzled with an unbeaten 48 off 25 balls at the death overs as DC put up a superlative batting effort to register their highest-ever score in IPL.

## BJP fields 26/11 lawyer Ujjwal Nikam from Mumbai North Central
 - [https://timesofindia.indiatimes.com/india/lok-sabha-polls-bjp-fields-26/11-prosecutor-ujjwal-nikam-from-mumbai-north-central/articleshow/109649050.cms](https://timesofindia.indiatimes.com/india/lok-sabha-polls-bjp-fields-26/11-prosecutor-ujjwal-nikam-from-mumbai-north-central/articleshow/109649050.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T12:01:18+00:00



## Fraser-McGurk's demolition job: A jaw-dropping 95 percent...
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/jake-fraser-mcgurks-demolition-job-a-jaw-dropping-95-percent-/articleshow/109648444.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/jake-fraser-mcgurks-demolition-job-a-jaw-dropping-95-percent-/articleshow/109648444.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T11:38:44+00:00

Delhi Capitals batsman Jake Fraser-McGurk has been demonstrating outstanding power-hitting prowess in IPL 2024. His remarkable ability to strike the ball with force and precision has been a standout feature of his performances.

## Will not strike deal with those who enslaved Pak: Imran Khan
 - [https://timesofindia.indiatimes.com/world/pakistan/prefer-remaining-in-jail-for-nine-more-years-former-pakistan-pm-imran-khan-rules-out-negotiations/articleshow/109648481.cms](https://timesofindia.indiatimes.com/world/pakistan/prefer-remaining-in-jail-for-nine-more-years-former-pakistan-pm-imran-khan-rules-out-negotiations/articleshow/109648481.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T11:35:23+00:00

Rejecting the possibility of reaching an agreement, ex-Pakistan PM Imran Khan declared his willingness to face another nine years in prison rather than enter into negotiations with what he labeled as the entities that have "enslaved" the nation. Khan emphasized the imposition of what he deemed the "worst dictatorship" on the country in his statement, cautioning against its adverse impacts on the economy, governance, democracy and the judiciary.

## Telecom department has a ‘MS Dhoni scam’ warning for you
 - [https://timesofindia.indiatimes.com/technology/social/telecom-department-has-a-ms-dhoni-scam-warning-for-you/articleshow/109625228.cms](https://timesofindia.indiatimes.com/technology/social/telecom-department-has-a-ms-dhoni-scam-warning-for-you/articleshow/109625228.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T11:11:04+00:00

Scammers impersonate Dhoni on Instagram, seeking money for fake reasons. DoT warns fans to avoid such cons. Sanchar Saathi portal assists in blocking lost phones and reporting fraud.

## WhatsApp has a new look in India, this is what changed
 - [https://timesofindia.indiatimes.com/technology/social/whatsapp-is-rolling-out-new-interface-in-india-heres-what-has-changed/articleshow/109647799.cms](https://timesofindia.indiatimes.com/technology/social/whatsapp-is-rolling-out-new-interface-in-india-heres-what-has-changed/articleshow/109647799.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T11:08:05+00:00

WhatsApp updates with green-themed interface, enhancing user experience with color changes, Dark Mode improvements, and logo relocation in India. User feedback varies post-update rollout.

## Run riot continues as DC now smash their powerplay record
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/run-riot-continues-in-ipl-2024-as-delhi-capitals-now-smash-their-powerplay-record/articleshow/109647486.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/run-riot-continues-in-ipl-2024-as-delhi-capitals-now-smash-their-powerplay-record/articleshow/109647486.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T10:57:00+00:00

The trend of batsmen dominating bowlers continued as the Delhi Capitals set a new record for their highest-ever powerplay score in IPL history. This milestone was achieved during their match against the Mumbai Indians at the Arun Jaitley Stadium in Delhi on Saturday.

## 'If my role... ': Upasana Singh on joining Kapil Sharma's show
 - [https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-upasana-singh-on-joining-the-great-indian-kapil-show-yes-if-my-role-is-good/articleshow/109647049.cms](https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-upasana-singh-on-joining-the-great-indian-kapil-show-yes-if-my-role-is-good/articleshow/109647049.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T10:40:33+00:00

Upasana Singh, a versatile actress, known for comedy, has shifted focus to production and Punjabi films. She discussed her roles in popular TV shows, thoughts on men cross-dressing, and potential return to Kapil Sharma's new show if offered a substantial role.

## IPL: Delhi's Fraser-McGurk smashes 15-ball fifty vs Mumbai
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/dc-vs-mi-jake-fraser-mcgurk-smashes-15-ball-fifty-against-mumbai-indians/articleshow/109646878.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/dc-vs-mi-jake-fraser-mcgurk-smashes-15-ball-fifty-against-mumbai-indians/articleshow/109646878.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T10:30:41+00:00

After Mumbai Indians chose to field first at the Arun Jaitley Stadium in Delhi, the Delhi Capitals opener Jake Fraser-McGurk set the stage ablaze with a scintillating half-century off a mere 15 balls, showcasing his explosive batting prowess. It was his third fifty of this IPL season. DC are currently No. 6 on the points table.

## Special PMLA court denies Hemant Soren's interim bail
 - [https://timesofindia.indiatimes.com/india/special-pmla-court-denies-hemant-sorens-interim-bail-in-land-scam-case/articleshow/109645736.cms](https://timesofindia.indiatimes.com/india/special-pmla-court-denies-hemant-sorens-interim-bail-in-land-scam-case/articleshow/109645736.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T10:15:32+00:00

Ranchi Court denies Hemant Soren's interim bail plea for uncle's funeral, prompting a Supreme Court appeal. Soren alleges illegal detention, seeks urgent hearing amidst ongoing Lok Sabha elections.

## How Russia and Iran are dodging Western sanctions
 - [https://timesofindia.indiatimes.com/world/europe/why-russia-and-iran-can-dodge-western-sanctions/articleshow/109646572.cms](https://timesofindia.indiatimes.com/world/europe/why-russia-and-iran-can-dodge-western-sanctions/articleshow/109646572.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T10:13:40+00:00



## Putin may have played no role in Navalny's death: US intel report
 - [https://timesofindia.indiatimes.com/world/rest-of-world/us-intelligence-believes-vladimir-putin-probably-didnt-order-alexei-navalny-to-be-killed/articleshow/109646305.cms](https://timesofindia.indiatimes.com/world/rest-of-world/us-intelligence-believes-vladimir-putin-probably-didnt-order-alexei-navalny-to-be-killed/articleshow/109646305.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T10:02:49+00:00

US intel agencies believe Putin didn't order Navalny's killing, though they haven't absolved him of responsibility. Kremlin denies involvement in Navalny's death. US assessment broadly accepted in the intelligence community.

## 'Vague, baseless': Kejriwal hits back at ED in counter-affidavit
 - [https://timesofindia.indiatimes.com/india/not-a-single-rupee-delhi-cm-arvind-kejriwal-submits-affidavit-in-sc-responding-to-eds-allegations/articleshow/109645336.cms](https://timesofindia.indiatimes.com/india/not-a-single-rupee-delhi-cm-arvind-kejriwal-submits-affidavit-in-sc-responding-to-eds-allegations/articleshow/109645336.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T09:54:10+00:00

Delhi CM Kejriwal responds to ED's allegations, denying involvement in kickbacks and conspiracy related to Delhi Excise policy case, emphasizing lack of evidence against AAP.

## Best gaming laptops under 7k for serious gamers
 - [https://timesofindia.indiatimes.com/hot-picks/best-gaming-laptops-under-70000-best-laptop-for-premium-performance-for-serious-gamers/articleshow/109629069.cms](https://timesofindia.indiatimes.com/hot-picks/best-gaming-laptops-under-70000-best-laptop-for-premium-performance-for-serious-gamers/articleshow/109629069.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T09:45:11+00:00

Struggling to bring your A-game because your laptop can't catch up? Well then, it's time to upgrade to one of these ten powerful gaming laptops. This guide is a curated list of the best-performing gaming laptops, all under INR 70,000.

## Make Vizag capital: YSRCP releases poll manifesto
 - [https://timesofindia.indiatimes.com/india/make-visakhapatnam-capital-ysrcp-releases-poll-manifesto/articleshow/109645769.cms](https://timesofindia.indiatimes.com/india/make-visakhapatnam-capital-ysrcp-releases-poll-manifesto/articleshow/109645769.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T09:41:06+00:00

"Immediately after YSRCP forms the government in 2024, Visakhapatnam will be made the executive capital as the seat of the government. It will be developed as the growth engine for the state," said Reddy, addressing a press conference. He further promised that Amaravati would be developed as the legislative capital and Kurnool as the judicial capital.

## 'He hasn't made an impact': Irfan urges caution on Hardik's role
 - [https://timesofindia.indiatimes.com/sports/cricket/icc-mens-t20-world-cup/he-hasnt-made-an-impact-at-international-level-irfan-pathan-urges-caution-on-hardik-pandyas-role-in-team-india/articleshow/109645401.cms](https://timesofindia.indiatimes.com/sports/cricket/icc-mens-t20-world-cup/he-hasnt-made-an-impact-at-international-level-irfan-pathan-urges-caution-on-hardik-pandyas-role-in-team-india/articleshow/109645401.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T09:34:01+00:00

Former India pacer Irfan Pathan has urged Indian cricket to reconsider Hardik Pandya's role as an all-rounder, highlighting the need for significant performances in ICC tournaments. Pathan's comments come amid Pandya's struggles in the IPL season. He argued that Indian cricket should not prioritize Pandya as much as they have so far.

## Watch: West Bengal CM Mamata Banerjee slips and falls inside chopper, injured
 - [https://timesofindia.indiatimes.com/india/mamata-banerjee-suffers-injury-after-falling-inside-helicopter/articleshow/109644907.cms](https://timesofindia.indiatimes.com/india/mamata-banerjee-suffers-injury-after-falling-inside-helicopter/articleshow/109644907.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T09:01:43+00:00

West Bengal chief minister Mamata Banerjee suffered an injury on Saturday after boarding a helicopter in Durgapur. The CM was helped by her security personnel and she continued with her onward travel to Asansol, said reports. The incident comes just a month after the CM suffered a serious injury on her forehead after slipping at her residence.

## Allahabad HC grants bail to ex-MP Dhananjay Singh
 - [https://timesofindia.indiatimes.com/india/allahabad-hc-grants-bail-to-ex-mp-dhananjay-singh/articleshow/109644962.cms](https://timesofindia.indiatimes.com/india/allahabad-hc-grants-bail-to-ex-mp-dhananjay-singh/articleshow/109644962.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T09:00:54+00:00



## Earthquake jolts Japan's Bonin Islands, USGS says
 - [https://timesofindia.indiatimes.com/world/rest-of-world/earthquake-jolts-japans-bonin-islands-usgs-says/articleshow/109644906.cms](https://timesofindia.indiatimes.com/world/rest-of-world/earthquake-jolts-japans-bonin-islands-usgs-says/articleshow/109644906.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T08:58:52+00:00



## Zaheer picks Pant as sole keeper in his India T20 WC squad
 - [https://timesofindia.indiatimes.com/sports/cricket/icc-mens-t20-world-cup/zaheer-khan-picks-rishabh-pant-as-sole-wicketkeeper-in-his-india-squad-for-t20-world-cup/articleshow/109644649.cms](https://timesofindia.indiatimes.com/sports/cricket/icc-mens-t20-world-cup/zaheer-khan-picks-rishabh-pant-as-sole-wicketkeeper-in-his-india-squad-for-t20-world-cup/articleshow/109644649.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T08:53:39+00:00

Former India pacer Zaheer Khan has revealed his squad for the upcoming T20 World Cup, with Rishabh Pant as the sole wicketkeeper. Khan also includes Yash Dayal, a 26-year-old left-arm seamer, to add a new dimension to India's bowling attack. Khan considered Mohammed Shami's injury layoff and highlighted Dayal's versatility in different bowling roles.

## Nainital fires: IAF helicopter roped in as situation worsens
 - [https://timesofindia.indiatimes.com/city/dehradun/iaf-helicopter-roped-in-to-douse-forest-fires-in-nainital-as-situation-worsens-in-uttarakhand-district/articleshow/109644637.cms](https://timesofindia.indiatimes.com/city/dehradun/iaf-helicopter-roped-in-to-douse-forest-fires-in-nainital-as-situation-worsens-in-uttarakhand-district/articleshow/109644637.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T08:47:24+00:00

Indian Air Force helicopter assists in dousing forest fires in Nainital district. Chief Minister Dhami oversees efforts. Army, forest officials collaborate. Boating halted in Naini lake. 575 fire incidents since November in Uttarakhand, costing Rs 14 lakh.

## Centre allows export of 99,150 MT onion to six countries
 - [https://timesofindia.indiatimes.com/business/india-business/centre-allows-export-of-99150-mt-onion-to-six-countries/articleshow/109644650.cms](https://timesofindia.indiatimes.com/business/india-business/centre-allows-export-of-99150-mt-onion-to-six-countries/articleshow/109644650.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T08:44:28+00:00

Centre on Saturday allowed export of 99,150 MT onion to six countries - Bangladesh, UAE, Bhutan, Bahrain, Mauritius and Sri Lanka. The Indian govt allows export of 2000 MT of white onion cultivated specially for export markets in Middle-East and some European countries. National Cooperative Exports Limited (NCEL) is the agency for export of onion to these countries.

## Three Indian women killed in fatal road accident in US
 - [https://timesofindia.indiatimes.com/nri/us-canada-news/overspeeding-suv-goes-airborne-three-indian-women-killed-in-fatal-road-accident-in-us/articleshow/109643909.cms](https://timesofindia.indiatimes.com/nri/us-canada-news/overspeeding-suv-goes-airborne-three-indian-women-killed-in-fatal-road-accident-in-us/articleshow/109643909.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T08:04:39+00:00

Three Indian women from Anand district died in a US car crash. A speeding SUV swerved on I-85 in Greenville County, hitting trees. Coroner Mike Ellis confirmed the victims were from Georgia.

## 'There's no…': Ex-Pakistan captain on comparing Virat and Babar
 - [https://timesofindia.indiatimes.com/sports/cricket/news/theres-no-former-pakistan-captain-on-comparison-between-virat-kohli-and-babar-azam/articleshow/109643604.cms](https://timesofindia.indiatimes.com/sports/cricket/news/theres-no-former-pakistan-captain-on-comparison-between-virat-kohli-and-babar-azam/articleshow/109643604.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T07:50:44+00:00

Virat Kohli and Babar Azam are two exceptional modern-day batsmen, each with a unique style. While Kohli boasts higher averages and centuries, Azam showcases potential and elegant stroke play, contributing significantly to their respective teams. While Kohli has proven himself across all formats over a longer period, Azam has shown immense potential and continues to impress with his batting skills.

## JioCinema’s ‘free’ IPL offer: How to watch it for free on any TV
 - [https://timesofindia.indiatimes.com/technology/tech-tips/watch-ipl-2024-on-jiocinema-for-free-on-any-tv-heres-how/articleshow/109642811.cms](https://timesofindia.indiatimes.com/technology/tech-tips/watch-ipl-2024-on-jiocinema-for-free-on-any-tv-heres-how/articleshow/109642811.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T07:14:33+00:00

Stream IPL 2024 on TV via Star Sports or JioCinema. Easily convert any TV into a smart TV using dongles like Amazon Fire TV Stick. Enjoy matches without logging in, all for free on JioCinema.

## US FDA gathering information on MDH and Everest products
 - [https://timesofindia.indiatimes.com/india/us-fda-gathering-information-on-mdh-and-everest-spice-products-amidst-carcinogenic-pesticide-concerns/articleshow/109642413.cms](https://timesofindia.indiatimes.com/india/us-fda-gathering-information-on-mdh-and-everest-spice-products-amidst-carcinogenic-pesticide-concerns/articleshow/109642413.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T06:54:03+00:00

US Food and Drug Administration (FDA) is currently investigating products from spice manufacturers MDH and Everest following Hong Kong's decision to halt sales of certain items due to the alleged presence of high levels of a carcinogenic pesticide. Earlier this month, Hong Kong suspended the sale of three MDH spice blends and an Everest spice mix for fish curries.

## AAP MLA Amanatullah Khan gets bail from Delhi court
 - [https://timesofindia.indiatimes.com/city/delhi/aap-mla-amanatullah-khan-gets-bail-from-delhi-court-in-waqf-board-case/articleshow/109642255.cms](https://timesofindia.indiatimes.com/city/delhi/aap-mla-amanatullah-khan-gets-bail-from-delhi-court-in-waqf-board-case/articleshow/109642255.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T06:47:04+00:00



## Watch: Rahul reveals what he secretly admires about Dhoni
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/dhoni-ki-cap-mein-hamesha-watch-what-kl-rahul-secretly-admires-about-csk-talisman/articleshow/109641653.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/dhoni-ki-cap-mein-hamesha-watch-what-kl-rahul-secretly-admires-about-csk-talisman/articleshow/109641653.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T06:12:12+00:00

KL Rahul's admiration for MS Dhoni fuels his leadership at Lucknow Super Giants, anchoring the team's batting line-up. His impactful performances reflect his cricket expertise and strategic approach to the game. Lucknow Super Giants have beaten Chennai Super Kings in both their matches this season. The host broadcaster shared a video of Rahul talking about IPL and Dhoni.

## 'Ploy by BJP': TMC moves EC after CBI raids Sandeshkhali
 - [https://timesofindia.indiatimes.com/india/ploy-by-bjp-tmc-moves-ec-after-cbi-raids-sandeshkhali-locations/articleshow/109641607.cms](https://timesofindia.indiatimes.com/india/ploy-by-bjp-tmc-moves-ec-after-cbi-raids-sandeshkhali-locations/articleshow/109641607.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T06:11:07+00:00

TMC raised concerns over the CBI raid during Phase II polling, suspecting BJP-CBI collusion in arms recovery at Sandeshkhali. TMC wrote a letter to EC to raise a complaint against CBI raids and also alleged weapon planting and targeting by Modi in West Bengal elections. TMC also claimed that they wanted to tarnish TMC's image.

## 'Get used to living frugally': China asks officials to use own cup, travel by bike
 - [https://timesofindia.indiatimes.com/business/international-business/get-used-to-living-frugally-china-asks-officials-to-use-own-cup-travel-by-bike/articleshow/109640681.cms](https://timesofindia.indiatimes.com/business/international-business/get-used-to-living-frugally-china-asks-officials-to-use-own-cup-travel-by-bike/articleshow/109640681.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T06:05:04+00:00

China implements austerity measures like budget cuts and frugality campaigns to address economic challenges, redirect resources, and curb unnecessary spending. However, critics question the effectiveness of these measures in resolving long-term economic issues.

## How Iran's use of 'North Korean tactics' against Israel may change Middle East dynamics
 - [https://timesofindia.indiatimes.com/world/middle-east/how-irans-use-of-north-korean-tactics-against-israel-may-change-middle-east-dynamics/articleshow/109640857.cms](https://timesofindia.indiatimes.com/world/middle-east/how-irans-use-of-north-korean-tactics-against-israel-may-change-middle-east-dynamics/articleshow/109640857.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T05:39:11+00:00



## 'Asking for trouble': Why Japanese academics are shunning China
 - [https://timesofindia.indiatimes.com/world/rest-of-world/asking-for-trouble-why-japanese-academics-are-shunning-china/articleshow/109640702.cms](https://timesofindia.indiatimes.com/world/rest-of-world/asking-for-trouble-why-japanese-academics-are-shunning-china/articleshow/109640702.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T05:35:17+00:00

The unsettling incident is part of a troubling pattern involving several Chinese academics based in Japan, including Hu Shiyun and Zhu Jianrong, who have also vanished under mysterious circumstances. These cases have prompted fears among the academic community, leading to a decline in participation in academic events in China.

## 'Wasn't because of Impact Player': Ex-India player on big scores
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/it-wasnt-because-of-impact-player-rule-former-india-cricketer-on-big-scores-in-ipl/articleshow/109640751.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/it-wasnt-because-of-impact-player-rule-former-india-cricketer-on-big-scores-in-ipl/articleshow/109640751.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T05:29:28+00:00

Aakash Chopra, a cricketer and commentator, attributed Kolkata Knight Riders' high score to their aggressive mindset, dismissing the "Impact Player" rule as the sole reason. Former India cricketer Chopra argued that bowlers were hit more due to the change in mindset, with openers scoring half-centuries and Ramandeep Singh hitting a six.

## 'BJP opposing inheritance tax because of...' Prashant Bhushan
 - [https://timesofindia.indiatimes.com/india/bjp-opposing-inheritance-tax-because-of-adani-ambani-says-prashant-bhushan/articleshow/109639808.cms](https://timesofindia.indiatimes.com/india/bjp-opposing-inheritance-tax-because-of-adani-ambani-says-prashant-bhushan/articleshow/109639808.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T05:09:42+00:00

Advocate Prashant Bhushan expressed support for an inheritance tax on Friday, urging Congress to be "on the front foot" in response to Sam Pitroda's statements, noting that every wealthy country has one. In a post on X, Prahsnat Bhushan wrote, "Congress Party should be on the front foot on Sam Pitroda’s remarks on inheritance tax."

## Watch: Pant tells what he has learnt from Rohit Sharma
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/the-trust-factor-he-brings-watch-what-rishabh-pant-has-learnt-from-rohit-sharma/articleshow/109640408.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/the-trust-factor-he-brings-watch-what-rishabh-pant-has-learnt-from-rohit-sharma/articleshow/109640408.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T05:07:29+00:00

Delhi Capitals, led by Rishabh Pant, face Mumbai Indians. Pant learns from Rohit Sharma about innovation, proactive mindset, understanding players, trust, and strategic leadership. Recent performance shows promise for Capitals against inconsistent Mumbai Indians. The two teams are delicately placed in the table. Capitals have a chance to push the top four and MI are clearly staring down a cliff.

## Woman casts vote before performing hubby's last rites
 - [https://timesofindia.indiatimes.com/city/nagpur/woman-casts-vote-before-performing-hubbys-last-rites/articleshow/109639812.cms](https://timesofindia.indiatimes.com/city/nagpur/woman-casts-vote-before-performing-hubbys-last-rites/articleshow/109639812.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T04:41:37+00:00



## KKR's Gambhir argues with fourth umpire for a single - Watch
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/ipl-2024-frustrated-kkr-mentor-gautam-gambhir-argues-with-fourth-umpire-for-a-single-watch/articleshow/109639412.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/ipl-2024-frustrated-kkr-mentor-gautam-gambhir-argues-with-fourth-umpire-for-a-single-watch/articleshow/109639412.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T04:12:38+00:00

Kolkata Knight Riders were stunned by Punjab Kings' impressive run chase at Eden Gardens, which overshadowed a disagreement between KKR mentor Gautam Gambhir and the umpire. The Kings, inspired by Jonny Bairstow's century, chased down a formidable target of 262 runs. However, Gambhir's frustration escalated during a contentious moment in KKR's innings.

## First time voters: From watching videos to booking tickets
 - [https://timesofindia.indiatimes.com/city/bengaluru/bubbly-curious-excited-first-time-electors-get-a-taste-of-democracy/articleshow/109639413.cms](https://timesofindia.indiatimes.com/city/bengaluru/bubbly-curious-excited-first-time-electors-get-a-taste-of-democracy/articleshow/109639413.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T04:08:47+00:00

Kruthika P, Aditi Nayak, Manish, Ravi, Keerthi, and Keshav voted in different locations after thorough research on candidates, showing great enthusiasm as first-time voters.

## Gujarat director straddled political divide with poll films
 - [https://timesofindia.indiatimes.com/city/vadodara/gujarat-director-straddled-political-divide-with-poll-films/articleshow/109639385.cms](https://timesofindia.indiatimes.com/city/vadodara/gujarat-director-straddled-political-divide-with-poll-films/articleshow/109639385.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T04:07:01+00:00

Dhiru Mistry, a pioneering filmmaker, influenced Gujarat's political landscape for decades through impactful campaign films for Congress (I), Congress (O), Jan Sangh. His work represented parties' manifesto, emblem, and vision, shaping electoral communication.

## Arif Khan quits as Cong star campaigner over 'unfair decision'
 - [https://timesofindia.indiatimes.com/india/lot-of-anger-in-community-cong-leader-after-stepping-down-from-panel-over-absence-of-muslim-face-in-mva-list-for-ls-polls/articleshow/109639277.cms](https://timesofindia.indiatimes.com/india/lot-of-anger-in-community-cong-leader-after-stepping-down-from-panel-over-absence-of-muslim-face-in-mva-list-for-ls-polls/articleshow/109639277.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T04:00:44+00:00

Muhammed Arif 'Naseem' Khan resigns from Congress campaign committee during Lok Sabha elections due to MVA bloc's decision not to field any minority candidate, upsetting minority community members. Lack of Muslim representation questioned.

## Lucknow has more voters aged 80+ than first-timers
 - [https://timesofindia.indiatimes.com/city/lucknow/lucknow-has-more-voters-aged-80-than-first-timers/articleshow/109639266.cms](https://timesofindia.indiatimes.com/city/lucknow/lucknow-has-more-voters-aged-80-than-first-timers/articleshow/109639266.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T03:59:32+00:00

In Lucknow, political parties aim to boost first-time voter turnout. Elderly voters hold significant sway, surpassing 18-19 age group. Men outnumber women voters, reflecting evolving demographics and electoral patterns.

## 69% vote in K'taka for 14 LS seats, Bengaluru limps to 57%
 - [https://timesofindia.indiatimes.com/city/bengaluru/69-vote-in-karnataka-phase-1-for-14-ls-seats-bengaluru-limps-to-57/articleshow/109639136.cms](https://timesofindia.indiatimes.com/city/bengaluru/69-vote-in-karnataka-phase-1-for-14-ls-seats-bengaluru-limps-to-57/articleshow/109639136.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T03:54:43+00:00

69% turnout in 14 Karnataka Lok Sabha seats, with Bengaluru at 57%. Mysuru exceeded 70%. 247 candidates contesting. Bangalore Rural had the highest turnout.

## 'Haarne pe bahut pareshan...': Preity Zinta's bond with Punjab Kings
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/haarne-pe-bahut-pareshan-ho-jaati-hai-irfan-pathan-shares-preity-zintas-passionate-involvement-with-punjab-kings/articleshow/109638891.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/haarne-pe-bahut-pareshan-ho-jaati-hai-irfan-pathan-shares-preity-zintas-passionate-involvement-with-punjab-kings/articleshow/109638891.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T03:34:09+00:00

Former India all-rounder Irfan Pathan praised Bollywood actress and co-owner Preity Zinta's emotional investment and dedication to the Punjab Kings cricket team during a mid-innings discussion on Star Sports. Pathan, who represented Punjab Kings in the IPL for three years, praised Zinta's emotional control and passionate support for the team.

## How Punjab Kings raised the bar with historic victory against KKR
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/heist-and-history-at-eden-how-punjab-kings-set-the-bar-higher-with-historic-victory-against-kolkata-knight-riders/articleshow/109638054.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/heist-and-history-at-eden-how-punjab-kings-set-the-bar-higher-with-historic-victory-against-kolkata-knight-riders/articleshow/109638054.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T02:16:12+00:00

The match recorded the highest number of sixes (42) in any T20 game as after KKR hit 18 of those, PBKS bettered that by getting six more to record the highest run-chase in any T20 match scoring 262 for two in 18.4 overs. ​​Shashank Singh kept his good form going to finish off things staying undefeated on 68 along with Bairstow, who got 108 off 48 balls with the help of eight fours and nine sixes.

## Harasser storms house of 15-yr-old, doesn't find her, shoots mom
 - [https://timesofindia.indiatimes.com/city/delhi/harasser-storms-house-of-15-yr-old-girl-doesnt-find-her-shoots-mom-in-delhis-jahangirpuri/articleshow/109637948.cms](https://timesofindia.indiatimes.com/city/delhi/harasser-storms-house-of-15-yr-old-girl-doesnt-find-her-shoots-mom-in-delhis-jahangirpuri/articleshow/109637948.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T01:59:55+00:00

In Jahangirpuri, an 18-year-old boy shot a woman, mother to a 15-year-old girl, following persistent harassment. Despite prior warnings, police failed to prevent the tragedy, leading to community tension and ongoing investigations.

## Indian fisherman arrested by Pak dies in Karachi ‘after fall’
 - [https://timesofindia.indiatimes.com/city/mumbai/maharashtra-fisherman-arrested-by-pakistan-dies-in-karachi-jail/articleshow/109637931.cms](https://timesofindia.indiatimes.com/city/mumbai/maharashtra-fisherman-arrested-by-pakistan-dies-in-karachi-jail/articleshow/109637931.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T01:59:00+00:00

Vinod Kol, a fisherman from Dahanu, died in a Karachi jail after violating maritime boundaries. Sandhya Nair reported it, marking the first for an Indian in a Pakistan jail this year. His body will be sent to India on April 29.

## ' I cant breathe:' Black man dies after being pinned down by cops in Ohio
 - [https://timesofindia.indiatimes.com/world/us/-i-cant-breathe-black-man-dies-after-being-pinned-down-by-cops-in-ohio/articleshow/109637770.cms](https://timesofindia.indiatimes.com/world/us/-i-cant-breathe-black-man-dies-after-being-pinned-down-by-cops-in-ohio/articleshow/109637770.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T01:46:49+00:00



## Two CRPF jawan killed in militant attack in Manipur
 - [https://timesofindia.indiatimes.com/city/imphal/two-crpf-jawan-killed-in-militant-attack-in-manipur/articleshow/109637846.cms](https://timesofindia.indiatimes.com/city/imphal/two-crpf-jawan-killed-in-militant-attack-in-manipur/articleshow/109637846.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T01:43:16+00:00



## Can Lucknow Super Giants ground high-flying Rajasthan Royals?
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/ipl-2024-can-lucknow-super-giants-ground-high-flying-rajasthan-royals/articleshow/109637844.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/ipl-2024-can-lucknow-super-giants-ground-high-flying-rajasthan-royals/articleshow/109637844.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T01:42:25+00:00

LSG will eye revenge after having lost their inaugural encounter against Royals in Jaipur by 20 runs. In the last few matches, LSG have had to face injuries in their fast-bowling unit, with young sensation Mayank Yadav and left-arm pacer Mohsin Khan going missing. RR will benefit from the presence of Avesh Khan, as he has been a part of LSG in the past. He knows the pitch and conditions well.

## T20 World Cup selection takes centrestage as DC face MI
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/t20-world-cup-selection-takes-centrestage-as-delhi-capitals-face-mumbai-indians/articleshow/109637746.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/t20-world-cup-selection-takes-centrestage-as-delhi-capitals-face-mumbai-indians/articleshow/109637746.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T01:17:50+00:00

Amidst intense training in the sweltering heat, IPL players like Axar Patel and Rishabh Pant aim to secure T20 World Cup spots. This is a time when each IPL performance counts, with the selection for the upcoming T20 World Cup due soon. At a time when Indian cricket seems to be grappling with workload-management issues, one could see Hardik Pandya going full throttle with the ball in high heat and Axar Patel turning up for a lengthy nets session barely 40 hours after playing a tough match against Gujarat Titans.

## From inane to evocative, the ‘free & colourful’ world of poll symbols
 - [https://timesofindia.indiatimes.com/india/from-inane-to-evocative-the-free-colourful-world-of-symbols/articleshow/109637543.cms](https://timesofindia.indiatimes.com/india/from-inane-to-evocative-the-free-colourful-world-of-symbols/articleshow/109637543.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T00:40:49+00:00

The chai kettle is one of the many symbols that have been adopted by candidates like Dwivedi in the ongoing elections. From daily household items that the aam aadmi uses in kitchens to aspirational gear and gadgets, they’re all in the fray. And while they were first introduced to reach out to the people at a time when the literacy rate stood at a mere 16%, they’re still as relevant, with party factions even going to court to claim them after a split.

## Watch: Shashank does the iconic SRK pose after win against KKR
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-shashank-singh-does-the-iconic-shah-rukh-khan-pose-after-punjab-kings-win-against-kolkata-knight-riders/articleshow/109637527.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-shashank-singh-does-the-iconic-shah-rukh-khan-pose-after-punjab-kings-win-against-kolkata-knight-riders/articleshow/109637527.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T00:33:58+00:00

Punjab Kings' Shashank Singh's explosive 68 runs off 28 balls led to a historic T20 victory against Kolkata Knight Riders. The match witnessed the highest successful chase globally, with notable performances from Jonny Bairstow and Prabhsimran Singh. The match also saw the most number of sixes hit in the format.

## In clash of super-rich Reddys, can Ram tip scale in Telangana's Chevella?
 - [https://timesofindia.indiatimes.com/city/hyderabad/in-clash-of-super-rich-reddys-can-ram-tip-scale/articleshow/109637503.cms](https://timesofindia.indiatimes.com/city/hyderabad/in-clash-of-super-rich-reddys-can-ram-tip-scale/articleshow/109637503.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T00:31:50+00:00



## Politics of guarantee: Born in Karnataka, now set for a pan-India (con)test
 - [https://timesofindia.indiatimes.com/city/bengaluru/politics-of-guarantee-born-in-karnataka-now-set-for-a-pan-india-contest/articleshow/109637467.cms](https://timesofindia.indiatimes.com/city/bengaluru/politics-of-guarantee-born-in-karnataka-now-set-for-a-pan-india-contest/articleshow/109637467.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-27T00:22:58+00:00

Congress and BJP battle over guarantees in Karnataka, with Congress emphasizing local implementation and BJP relying on Modi's national appeal. Congress expands guarantees nationally, countering 'Modi ki guarantee' with 25 new promises.

