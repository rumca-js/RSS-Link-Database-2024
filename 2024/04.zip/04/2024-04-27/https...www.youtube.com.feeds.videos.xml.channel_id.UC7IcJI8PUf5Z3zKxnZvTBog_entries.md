# Source:The School of Life, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog, language:en-US

## We We Love People Who Don't Love Us Back  #shorts  #love
 - [https://www.youtube.com/watch?v=PqHsN1ZHkH8](https://www.youtube.com/watch?v=PqHsN1ZHkH8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog
 - date published: 2024-04-27T13:00:31+00:00

Enjoying our YouTube videos? Get full access to all our audio content, videos, and thousands of thought-provoking articles, conversation cards and more with The School of Life Subscription: https://9qq0.short.gy/YbY86t

Learn, heal and grow; get the best of The School of Life delivered straight to your inbox: https://9qq0.short.gy/hJnlBw

FURTHER READING

You can read more on this and other subjects in our articles, here: https://www.theschooloflife.com/article/why-we-love-people-who-dont-love-us-back/

"Relationships in which our love is not adequately requited are — for most of us — a grave inconvenience, from which we will seek to extricate ourselves as fast as possible. Why would we possibly want to be in a couple in which our love is not adequately honoured? Why would we bother to waste time around someone who doesn’t return our affection? Who can be bothered with cold, confusing or distant people??

