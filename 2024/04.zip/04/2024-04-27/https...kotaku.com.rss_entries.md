# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## Fallout 76's Redemption Arc, A Great New Zelda-Like, And More Gaming Opinions For The Week
 - [https://kotaku.com/final-fantasy-16-dlc-rising-tide-phantom-fury-1851438696](https://kotaku.com/final-fantasy-16-dlc-rising-tide-phantom-fury-1851438696)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-27T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/b1f8641685e74d59581401060080e5a3.jpg" /><p>Fallout 76 is getting plenty of attention in the wake of the hugely popular Amazon show, and we’re happy to see it. Also, we reflect on Final Fantasy 16's DLC now that Clive’s journey is truly at an end, and recommend a fresh new Zelda-like that’s also a twin-stick shooter. Enjoy!</p><p><a href="https://kotaku.com/final-fantasy-16-dlc-rising-tide-phantom-fury-1851438696">Read more...</a></p>

## Fallout 4's Big Update, Stellar Blade's Launch Day Patch, And More Of The Week's Gaming News
 - [https://kotaku.com/fallout-4-helldivers-2-stellar-blade-gaming-news-1851438694](https://kotaku.com/fallout-4-helldivers-2-stellar-blade-gaming-news-1851438694)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-27T13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4878931de11cc765af27f2e5b35d21cc.jpg" /><p>This week’s gaming news saw Helldivers 2 continue its efforts at world domination, Fallout 4's big next-gen patch cause problems as well as fix them, and much more.</p><p><a href="https://kotaku.com/fallout-4-helldivers-2-stellar-blade-gaming-news-1851438694">Read more...</a></p>

