# Source:Reddit - Politics, URL:https://www.reddit.com/r/politics/.rss, language:en-US

## Discussion Thread: 2024 White House Correspondents' Dinner
 - [https://www.reddit.com/r/politics/comments/1cernb8/discussion_thread_2024_white_house_correspondents](https://www.reddit.com/r/politics/comments/1cernb8/discussion_thread_2024_white_house_correspondents)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T23:05:33+00:00

<!-- SC_OFF --><div class="md"><p>C-SPAN's description-in-advance of tonight's event is: &quot;Saturday Night Live cast member Colin Jost is the featured entertainer at the 2024 White House Correspondents' Association dinner in Washington, DC.&quot;</p> <p><strong>News:</strong></p> <ul> <li><p>The New York Times (metered paywall): <a href="https://www.nytimes.com/2024/04/27/us/politics/biden-white-house-correspondents-dinner.html">Biden Warms Up for a Media Roast on Saturday | At the annual White House Correspondents’ Association dinner, hosted by Colin Jost, President Biden and members of the news media will (hopefully) share some laughs.</a></p></li> <li><p>NBC: <a href="https://www.nbcnews.com/politics/joe-biden/pro-palestinian-protests-white-house-correspondents-dinner-rcna149074">Protests planned for Washington's premier party weekend | Pro-Palestinian protesters are looking to puncture the festive bubble surrounding the White House Correspondents Association Dinner.</a></p></li

## Arizona Dem says state is bluer 'not because Arizona is necessarily a blue state,' but from distaste for GOP 'extremism'
 - [https://www.reddit.com/r/politics/comments/1cepm0d/arizona_dem_says_state_is_bluer_not_because](https://www.reddit.com/r/politics/comments/1cepm0d/arizona_dem_says_state_is_bluer_not_because)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T21:33:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cepm0d/arizona_dem_says_state_is_bluer_not_because/"> <img alt="Arizona Dem says state is bluer 'not because Arizona is necessarily a blue state,' but from distaste for GOP 'extremism'" src="https://external-preview.redd.it/0ztQXs__KFtQ58gYY2MJJ7ZLyLZIMziefSMiascDV6o.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7c3540e0643867f391c987dafe0548310edd5bd6" title="Arizona Dem says state is bluer 'not because Arizona is necessarily a blue state,' but from distaste for GOP 'extremism'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/gta4auto"> /u/gta4auto </a> <br /> <span><a href="https://www.businessinsider.com/arizona-extreme-gop-abortion-ban-trump-biden-2024-4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cepm0d/arizona_dem_says_state_is_bluer_not_because/">[comments]</a></span> </td></tr></table>

## Florida Rep. Bill Posey becomes latest Republican to announce retirement
 - [https://www.reddit.com/r/politics/comments/1cenrg1/florida_rep_bill_posey_becomes_latest_republican](https://www.reddit.com/r/politics/comments/1cenrg1/florida_rep_bill_posey_becomes_latest_republican)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T20:12:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cenrg1/florida_rep_bill_posey_becomes_latest_republican/"> <img alt="Florida Rep. Bill Posey becomes latest Republican to announce retirement" src="https://external-preview.redd.it/QchLSKs_HupEaivGfIQIeOmcaXfMPNFDuUYKWePG8Oo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f48b13de463698da1d00795b0d0a3ee39fd08d0b" title="Florida Rep. Bill Posey becomes latest Republican to announce retirement" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FreeChickenDinner"> /u/FreeChickenDinner </a> <br /> <span><a href="https://thehill.com/homenews/house/4626110-florida-bill-posey-not-seeking-reelection-2024-house-elections/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cenrg1/florida_rep_bill_posey_becomes_latest_republican/">[comments]</a></span> </td></tr></table>

## Jamie Raskin Goes Scorched Earth on SCOTUS Trump Immunity Case
 - [https://www.reddit.com/r/politics/comments/1cennq8/jamie_raskin_goes_scorched_earth_on_scotus_trump](https://www.reddit.com/r/politics/comments/1cennq8/jamie_raskin_goes_scorched_earth_on_scotus_trump)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T20:08:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cennq8/jamie_raskin_goes_scorched_earth_on_scotus_trump/"> <img alt="Jamie Raskin Goes Scorched Earth on SCOTUS Trump Immunity Case" src="https://external-preview.redd.it/gOYo76Zkr_Srh9k3WhMdoDVzA_Z_JIMKh9cTuDpcH5o.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=482283187169f37cdbe95048381d733fe0f7b0a5" title="Jamie Raskin Goes Scorched Earth on SCOTUS Trump Immunity Case" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/duderos"> /u/duderos </a> <br /> <span><a href="https://newrepublic.com/post/181041/jamie-raskin-supreme-court-trump-immunity">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cennq8/jamie_raskin_goes_scorched_earth_on_scotus_trump/">[comments]</a></span> </td></tr></table>

## Minority rule is threatening American democracy like never before
 - [https://www.reddit.com/r/politics/comments/1cenk8i/minority_rule_is_threatening_american_democracy](https://www.reddit.com/r/politics/comments/1cenk8i/minority_rule_is_threatening_american_democracy)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T20:04:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cenk8i/minority_rule_is_threatening_american_democracy/"> <img alt="Minority rule is threatening American democracy like never before" src="https://external-preview.redd.it/AKcJEmJhk5k38B34ncVIL3kS8TV3cUSxKfyGLsrTJe0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c0bdb2ba934e7c700624d3a1a21b658c6af38cf7" title="Minority rule is threatening American democracy like never before" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Hopeforpeace19"> /u/Hopeforpeace19 </a> <br /> <span><a href="https://www.motherjones.com/politics/2024/04/minority-rule-is-threatening-american-democracy-like-never-before/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cenk8i/minority_rule_is_threatening_american_democracy/">[comments]</a></span> </td></tr></table>

## "Cruel and Insane": Republicans condemn Kristi Noem's dog-killing revelation
 - [https://www.reddit.com/r/politics/comments/1cenj74/cruel_and_insane_republicans_condemn_kristi_noems](https://www.reddit.com/r/politics/comments/1cenj74/cruel_and_insane_republicans_condemn_kristi_noems)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T20:02:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cenj74/cruel_and_insane_republicans_condemn_kristi_noems/"> <img alt="&quot;Cruel and Insane&quot;: Republicans condemn Kristi Noem's dog-killing revelation" src="https://external-preview.redd.it/uyz_zFkXB0mpuId93sfxMcRFBCSCqQKIn1HxJBskxbo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0c3fdd71250bbcc7112f34adc8634c95cda2ed2c" title="&quot;Cruel and Insane&quot;: Republicans condemn Kristi Noem's dog-killing revelation" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br /> <span><a href="https://www.salon.com/2024/04/27/cruel-and-insane-condemn-kristi-noems-dog-revelation/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cenj74/cruel_and_insane_republicans_condemn_kristi_noems/">[comments]</a></span> </td></tr></table>

## Biden embraces Trump-style taunts, calling Trump a ‘loser’
 - [https://www.reddit.com/r/politics/comments/1cemzqa/biden_embraces_trumpstyle_taunts_calling_trump_a](https://www.reddit.com/r/politics/comments/1cemzqa/biden_embraces_trumpstyle_taunts_calling_trump_a)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T19:39:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cemzqa/biden_embraces_trumpstyle_taunts_calling_trump_a/"> <img alt="Biden embraces Trump-style taunts, calling Trump a ‘loser’" src="https://external-preview.redd.it/87QpQDoF1FR8vxfsT2AZlt15z-FlKf1QGEN89mWayfY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2363560e6b86b497bbfc056db1b635f7e0209adb" title="Biden embraces Trump-style taunts, calling Trump a ‘loser’" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/etfvpu"> /u/etfvpu </a> <br /> <span><a href="https://www.seattletimes.com/nation-world/nation-politics/biden-embraces-trump-style-taunts-calling-trump-a-loser/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cemzqa/biden_embraces_trumpstyle_taunts_calling_trump_a/">[comments]</a></span> </td></tr></table>

## Bill Barr Is Happy to Debase Himself for Donald Trump Again
 - [https://www.reddit.com/r/politics/comments/1cemrru/bill_barr_is_happy_to_debase_himself_for_donald](https://www.reddit.com/r/politics/comments/1cemrru/bill_barr_is_happy_to_debase_himself_for_donald)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T19:30:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cemrru/bill_barr_is_happy_to_debase_himself_for_donald/"> <img alt="Bill Barr Is Happy to Debase Himself for Donald Trump Again" src="https://external-preview.redd.it/cGorIXYZ5fCfFdTLbssoMNsQCC3IR7Qlg4nxTa2U2yk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=11a03d289f64b4f28aa23c14ba65773a72593f52" title="Bill Barr Is Happy to Debase Himself for Donald Trump Again" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Murky-Site7468"> /u/Murky-Site7468 </a> <br /> <span><a href="https://www.motherjones.com/politics/2024/04/bill-barr-donald-trump-vote-cnn-kaitlin-collins/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cemrru/bill_barr_is_happy_to_debase_himself_for_donald/">[comments]</a></span> </td></tr></table>

## A 'coat hanger' could unlock Mar-a-Lago storage room where Trump stored classified docs: Witness
 - [https://www.reddit.com/r/politics/comments/1cempjk/a_coat_hanger_could_unlock_maralago_storage_room](https://www.reddit.com/r/politics/comments/1cempjk/a_coat_hanger_could_unlock_maralago_storage_room)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T19:27:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cempjk/a_coat_hanger_could_unlock_maralago_storage_room/"> <img alt="A 'coat hanger' could unlock Mar-a-Lago storage room where Trump stored classified docs: Witness" src="https://external-preview.redd.it/LwI14cYsWeKoiLQc8kfe3qmroHrBUmxs6XzKk7YYW0I.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ab15aacba18bc9e3badc98b970ce083cc33867ee" title="A 'coat hanger' could unlock Mar-a-Lago storage room where Trump stored classified docs: Witness" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/progress18"> /u/progress18 </a> <br /> <span><a href="https://abcnews.go.com/US/coat-hanger-unlock-mar-lago-storage-room-trump/story?id=109716197">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cempjk/a_coat_hanger_could_unlock_maralago_storage_room/">[comments]</a></span> </td></tr></table>

## Samuel Alito Has a Very Strange Theory for How to Protect Democracy
 - [https://www.reddit.com/r/politics/comments/1cek5kr/samuel_alito_has_a_very_strange_theory_for_how_to](https://www.reddit.com/r/politics/comments/1cek5kr/samuel_alito_has_a_very_strange_theory_for_how_to)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T17:38:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cek5kr/samuel_alito_has_a_very_strange_theory_for_how_to/"> <img alt="Samuel Alito Has a Very Strange Theory for How to Protect Democracy" src="https://external-preview.redd.it/09zKCqwz0rHZdA5fPYQ6TBcDOJ_68YzkSJ0WLkNpWbc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2fe5fc0f82da5ed2056ea76bf169d7479c84966a" title="Samuel Alito Has a Very Strange Theory for How to Protect Democracy" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/RichKatz"> /u/RichKatz </a> <br /> <span><a href="https://www.motherjones.com/politics/2024/04/samuel-alito-supreme-court-trump-immunity/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cek5kr/samuel_alito_has_a_very_strange_theory_for_how_to/">[comments]</a></span> </td></tr></table>

## How Reaganomics Fueled America's Homelessness Crisis
 - [https://www.reddit.com/r/politics/comments/1cejt23/how_reaganomics_fueled_americas_homelessness](https://www.reddit.com/r/politics/comments/1cejt23/how_reaganomics_fueled_americas_homelessness)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T17:24:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cejt23/how_reaganomics_fueled_americas_homelessness/"> <img alt="How Reaganomics Fueled America's Homelessness Crisis" src="https://external-preview.redd.it/2ylS8XNEKSayl9wn1jJ0qoOxCn_fR2VQ7RbSaxcwIig.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1dc61513c36781f10ff95aa5482fd8d0bba8f32c" title="How Reaganomics Fueled America's Homelessness Crisis" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PrestoVivace"> /u/PrestoVivace </a> <br /> <span><a href="https://www.commondreams.org/opinion/reaganomics-homelessness-crisis">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cejt23/how_reaganomics_fueled_americas_homelessness/">[comments]</a></span> </td></tr></table>

## Biden administration reinstates LGBTQ+ protections in health care
 - [https://www.reddit.com/r/politics/comments/1ceikix/biden_administration_reinstates_lgbtq_protections](https://www.reddit.com/r/politics/comments/1ceikix/biden_administration_reinstates_lgbtq_protections)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T16:30:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceikix/biden_administration_reinstates_lgbtq_protections/"> <img alt="Biden administration reinstates LGBTQ+ protections in health care" src="https://external-preview.redd.it/I0t97W07Wj76C1Kh2EfAZwFHyuTe31iHjq9zsGO3Q8c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=996557a95424cd3d998c522945ddb2b6c25649f2" title="Biden administration reinstates LGBTQ+ protections in health care" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/aslan_is_on_the_move"> /u/aslan_is_on_the_move </a> <br /> <span><a href="https://www.washingtonpost.com/health/2024/04/26/biden-lgbtq-health-care-protections/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceikix/biden_administration_reinstates_lgbtq_protections/">[comments]</a></span> </td></tr></table>

## Violent Arrest of Emory Professor Spotlights Brutality of Police Crackdown on Campus Protests | "To sustain this level of blind support for Israel, the U.S. must erode its own democracy," said one foreign policy expert. "And that is what we see happening on U.S. campuses now."
 - [https://www.reddit.com/r/politics/comments/1cehzde/violent_arrest_of_emory_professor_spotlights](https://www.reddit.com/r/politics/comments/1cehzde/violent_arrest_of_emory_professor_spotlights)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T16:04:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cehzde/violent_arrest_of_emory_professor_spotlights/"> <img alt="Violent Arrest of Emory Professor Spotlights Brutality of Police Crackdown on Campus Protests | &quot;To sustain this level of blind support for Israel, the U.S. must erode its own democracy,&quot; said one foreign policy expert. &quot;And that is what we see happening on U.S. campuses now.&quot;" src="https://external-preview.redd.it/ItGI6BH--NddtUrUiwC1G8gYuhxXDAbhA9oVSwtxQ6c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0c33d67aff93802d19ca0d085f8ad05d44c92aab" title="Violent Arrest of Emory Professor Spotlights Brutality of Police Crackdown on Campus Protests | &quot;To sustain this level of blind support for Israel, the U.S. must erode its own democracy,&quot; said one foreign policy expert. &quot;And that is what we see happening on U.S. campuses now.&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Social

## Shocker From Top Conservative Judge: Trump Likely To Skate Completely - J. Michael Luttig sees two potential outcomes from Thursday’s Supreme Court arguments. Both are grim for our democracy.
 - [https://www.reddit.com/r/politics/comments/1cehnsh/shocker_from_top_conservative_judge_trump_likely](https://www.reddit.com/r/politics/comments/1cehnsh/shocker_from_top_conservative_judge_trump_likely)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T15:51:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cehnsh/shocker_from_top_conservative_judge_trump_likely/"> <img alt="Shocker From Top Conservative Judge: Trump Likely To Skate Completely - J. Michael Luttig sees two potential outcomes from Thursday’s Supreme Court arguments. Both are grim for our democracy." src="https://external-preview.redd.it/QVmogGMlMjNff2O1WovSXfE3NuFtexeSe-XzwkoEmE4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e0aa86b94c8a0a8892a7a7947c88ff36e3cbe17b" title="Shocker From Top Conservative Judge: Trump Likely To Skate Completely - J. Michael Luttig sees two potential outcomes from Thursday’s Supreme Court arguments. Both are grim for our democracy." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br /> <span><a href="https://newrepublic.com/article/181059/luttig-trump-january-6-case">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cehnsh/shocker_

## Trump is among 'unindicted co-conspirators' in effort to overturn 2020 election in Michigan, investigator says
 - [https://www.reddit.com/r/politics/comments/1ceh7p0/trump_is_among_unindicted_coconspirators_in](https://www.reddit.com/r/politics/comments/1ceh7p0/trump_is_among_unindicted_coconspirators_in)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T15:31:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceh7p0/trump_is_among_unindicted_coconspirators_in/"> <img alt="Trump is among 'unindicted co-conspirators' in effort to overturn 2020 election in Michigan, investigator says" src="https://external-preview.redd.it/lPk9OOqvp9PdTfcT_i9q9xcMLZGySknHdnp1M-7_g00.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5a266ca70b934a4836b906ec4ac1c0f6a49ae52b" title="Trump is among 'unindicted co-conspirators' in effort to overturn 2020 election in Michigan, investigator says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ben_watson_jr"> /u/ben_watson_jr </a> <br /> <span><a href="https://www.nbcnews.com/politics/politics-news/trump-unindicted-co-conspirators-effort-overturn-2020-election-michiga-rcna149248">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceh7p0/trump_is_among_unindicted_coconspirators_in/">[comments]</a></span> </td></tr></table>

## Democratic governors admonish Noem for shooting her dog by posing with their pets
 - [https://www.reddit.com/r/politics/comments/1cegkzg/democratic_governors_admonish_noem_for_shooting](https://www.reddit.com/r/politics/comments/1cegkzg/democratic_governors_admonish_noem_for_shooting)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T15:03:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cegkzg/democratic_governors_admonish_noem_for_shooting/"> <img alt="Democratic governors admonish Noem for shooting her dog by posing with their pets" src="https://external-preview.redd.it/H6rzsu8v5IJNf5OqcA_CsHWxN8n-GRWQeMBLN1MWe-w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bdd4af6129e794744ce10b72453bd18dbc5788a0" title="Democratic governors admonish Noem for shooting her dog by posing with their pets" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br /> <span><a href="https://thehill.com/homenews/state-watch/4626019-gretchen-whitmer-phil-murphy-tim-walz-kristi-noem-social-media-dogs/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cegkzg/democratic_governors_admonish_noem_for_shooting/">[comments]</a></span> </td></tr></table>

## Miami Grand Prix shuts down effort to hold Trump fundraiser at F1 race
 - [https://www.reddit.com/r/politics/comments/1ceg5ce/miami_grand_prix_shuts_down_effort_to_hold_trump](https://www.reddit.com/r/politics/comments/1ceg5ce/miami_grand_prix_shuts_down_effort_to_hold_trump)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T14:44:26+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceg5ce/miami_grand_prix_shuts_down_effort_to_hold_trump/"> <img alt="Miami Grand Prix shuts down effort to hold Trump fundraiser at F1 race" src="https://external-preview.redd.it/kUzMgaRUTOXlO4iA-o0yw95SPREhyiMft-5X3I-zXkM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=01a966b78ea4d238509ef1f0cf2782052f511635" title="Miami Grand Prix shuts down effort to hold Trump fundraiser at F1 race" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheCJbreeZy"> /u/TheCJbreeZy </a> <br /> <span><a href="https://www.washingtonpost.com/sports/2024/04/26/trump-fundraiser-miami-grand-prix/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceg5ce/miami_grand_prix_shuts_down_effort_to_hold_trump/">[comments]</a></span> </td></tr></table>

## Trump will dismantle key US weather and science agency, climate experts fear
 - [https://www.reddit.com/r/politics/comments/1ceg18s/trump_will_dismantle_key_us_weather_and_science](https://www.reddit.com/r/politics/comments/1ceg18s/trump_will_dismantle_key_us_weather_and_science)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T14:39:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceg18s/trump_will_dismantle_key_us_weather_and_science/"> <img alt="Trump will dismantle key US weather and science agency, climate experts fear" src="https://external-preview.redd.it/n7fd-MHSedtdPXeNyVJYrA8lNXVLAAxf9kgU7XJQaNc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f8bd5e5168e65dc2f8c82a87aff68f7d2dcd9567" title="Trump will dismantle key US weather and science agency, climate experts fear" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Murranji"> /u/Murranji </a> <br /> <span><a href="https://www.theguardian.com/us-news/2024/apr/26/trump-presidency-gut-noaa-weather-climate-crisis">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceg18s/trump_will_dismantle_key_us_weather_and_science/">[comments]</a></span> </td></tr></table>

## Trump VP contender Kristi Noem defends killing her dog
 - [https://www.reddit.com/r/politics/comments/1cefsyp/trump_vp_contender_kristi_noem_defends_killing](https://www.reddit.com/r/politics/comments/1cefsyp/trump_vp_contender_kristi_noem_defends_killing)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T14:28:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cefsyp/trump_vp_contender_kristi_noem_defends_killing/"> <img alt="Trump VP contender Kristi Noem defends killing her dog" src="https://external-preview.redd.it/7Q4-CNVyol6cdJYR2BcE7rXueVB3_kdrWeg8d3rqPCg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=098b2d60ebd2bd932dd523fa49823d9102a08b5d" title="Trump VP contender Kristi Noem defends killing her dog" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/polopiko"> /u/polopiko </a> <br /> <span><a href="https://www.bbc.com/news/world-us-canada-68909801?xtor=AL-72-%5Bpartner%5D-%5Bbbc.news.twitter%5D-%5Bheadline%5D-%5Bnews%5D-%5Bbizdev%5D-%5Bisapi%5D&amp;at_ptr_name=twitter&amp;at_campaign=Social_Flow&amp;at_bbc_team=editorial&amp;at_format=link&amp;at_link_origin=BBCWorld&amp;at_link_id=E5823A1A-041C-11EF-80BC-B59E4B3AC5C4&amp;at_link_type=web_link&amp;at_medium=social&amp;at_campaign_type=owned">[link]</a></span> &#32; <span><a href="

## This Whole King Trump Thing Is Getting Awfully Literal
 - [https://www.reddit.com/r/politics/comments/1ceffwi/this_whole_king_trump_thing_is_getting_awfully](https://www.reddit.com/r/politics/comments/1ceffwi/this_whole_king_trump_thing_is_getting_awfully)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T14:11:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceffwi/this_whole_king_trump_thing_is_getting_awfully/"> <img alt="This Whole King Trump Thing Is Getting Awfully Literal" src="https://external-preview.redd.it/Qdjsc-EQ-9BewjzjnxS1P2d5rv0xgwAeKa6CejZ_HMI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=94c3b12096dd17b726d6374bbbffd3041c504f55" title="This Whole King Trump Thing Is Getting Awfully Literal" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Majano57"> /u/Majano57 </a> <br /> <span><a href="https://www.nytimes.com/2024/04/26/opinion/trump-immunity-supreme-court.html?unlocked_article_code=1.nk0.0ccq.Q1o5evb0lDWT">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceffwi/this_whole_king_trump_thing_is_getting_awfully/">[comments]</a></span> </td></tr></table>

## Court upholds New York law that says ISPs must offer $15 broadband
 - [https://www.reddit.com/r/politics/comments/1ceeyc0/court_upholds_new_york_law_that_says_isps_must](https://www.reddit.com/r/politics/comments/1ceeyc0/court_upholds_new_york_law_that_says_isps_must)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T13:48:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceeyc0/court_upholds_new_york_law_that_says_isps_must/"> <img alt="Court upholds New York law that says ISPs must offer $15 broadband" src="https://external-preview.redd.it/5T2_6eBZgDqOkIrpi1R84m5BmEmeUgoxbr-lAp_Oz3I.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=901394606f2dd7876172ff1502a4ffd9039d148f" title="Court upholds New York law that says ISPs must offer $15 broadband" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rit56"> /u/rit56 </a> <br /> <span><a href="https://arstechnica.com/tech-policy/2024/04/court-upholds-new-york-law-that-says-isps-must-offer-15-broadband/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceeyc0/court_upholds_new_york_law_that_says_isps_must/">[comments]</a></span> </td></tr></table>

## G.O.P. Asks Secret Service to Move Protesters Away From Convention Venue
 - [https://www.reddit.com/r/politics/comments/1ceewte/gop_asks_secret_service_to_move_protesters_away](https://www.reddit.com/r/politics/comments/1ceewte/gop_asks_secret_service_to_move_protesters_away)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T13:46:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceewte/gop_asks_secret_service_to_move_protesters_away/"> <img alt="G.O.P. Asks Secret Service to Move Protesters Away From Convention Venue" src="https://external-preview.redd.it/pvVV_o8W0EOHDbO3-PQ5TUODSPP9GIMJMdNF0wGZAwM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=07319d1b818307302f611e0ec396a946bc0890c4" title="G.O.P. Asks Secret Service to Move Protesters Away From Convention Venue" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/newzee1"> /u/newzee1 </a> <br /> <span><a href="https://www.nytimes.com/2024/04/26/us/politics/republican-convention-protest-milwaukee.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceewte/gop_asks_secret_service_to_move_protesters_away/">[comments]</a></span> </td></tr></table>

## In ethics complaint, Republicans accuse 2 Dems of ‘insurrection’ for protesting on the House floor
 - [https://www.reddit.com/r/politics/comments/1ceepr8/in_ethics_complaint_republicans_accuse_2_dems_of](https://www.reddit.com/r/politics/comments/1ceepr8/in_ethics_complaint_republicans_accuse_2_dems_of)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T13:36:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceepr8/in_ethics_complaint_republicans_accuse_2_dems_of/"> <img alt="In ethics complaint, Republicans accuse 2 Dems of ‘insurrection’ for protesting on the House floor" src="https://external-preview.redd.it/E7F-q5xaB4RyYp10V9Dhcy751rB1SAlXOmO3DsNfXXM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d22e37540361503c7f777c242800e722b2b0e579" title="In ethics complaint, Republicans accuse 2 Dems of ‘insurrection’ for protesting on the House floor" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/hunter15991"> /u/hunter15991 </a> <br /> <span><a href="https://azmirror.com/2024/04/26/in-ethics-complaint-republicans-accuse-2-dems-of-insurrection-for-protesting-on-the-house-floor/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceepr8/in_ethics_complaint_republicans_accuse_2_dems_of/">[comments]</a></span> </td></tr></table>

## Barr: Trump Brought Up ‘Things Like’ Executing Rivals a Lot
 - [https://www.reddit.com/r/politics/comments/1ceel7v/barr_trump_brought_up_things_like_executing](https://www.reddit.com/r/politics/comments/1ceel7v/barr_trump_brought_up_things_like_executing)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T13:30:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceel7v/barr_trump_brought_up_things_like_executing/"> <img alt="Barr: Trump Brought Up ‘Things Like’ Executing Rivals a Lot" src="https://external-preview.redd.it/l0utOx6yxhgkcj8NnXUNGgoq7QoA8AlmciS1tgGOe4U.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=86ab40e59ac508ebf4f767aaa80ec6cdf0aaf5ea" title="Barr: Trump Brought Up ‘Things Like’ Executing Rivals a Lot" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Quirkie"> /u/Quirkie </a> <br /> <span><a href="https://www.thedailybeast.com/barr-trump-brought-up-things-like-executing-rivals-a-lot">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceel7v/barr_trump_brought_up_things_like_executing/">[comments]</a></span> </td></tr></table>

## Donald Trump Has Never Sounded Like This
 - [https://www.reddit.com/r/politics/comments/1ceedc2/donald_trump_has_never_sounded_like_this](https://www.reddit.com/r/politics/comments/1ceedc2/donald_trump_has_never_sounded_like_this)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T13:19:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceedc2/donald_trump_has_never_sounded_like_this/"> <img alt="Donald Trump Has Never Sounded Like This" src="https://external-preview.redd.it/jgj2AsJkVqq-JUcmO9ye_ZDCgBSoD8Svi6r5vPFOUeQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=57a59b3cd787dab09ed8e0ffb878a52ff06c886a" title="Donald Trump Has Never Sounded Like This" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/newzee1"> /u/newzee1 </a> <br /> <span><a href="https://www.nytimes.com/2024/04/27/magazine/trump-rallies-rhetoric.html?unlocked_article_code=1.nk0.dsGw.oCKGMjVrQTro">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceedc2/donald_trump_has_never_sounded_like_this/">[comments]</a></span> </td></tr></table>

## ‘Where’s Cricket?’ Don’t Ask. Kristi Noem Defends Killing Her Dog.
 - [https://www.reddit.com/r/politics/comments/1ceed19/wheres_cricket_dont_ask_kristi_noem_defends](https://www.reddit.com/r/politics/comments/1ceed19/wheres_cricket_dont_ask_kristi_noem_defends)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T13:18:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ceed19/wheres_cricket_dont_ask_kristi_noem_defends/"> <img alt="‘Where’s Cricket?’ Don’t Ask. Kristi Noem Defends Killing Her Dog." src="https://external-preview.redd.it/Z8aJ4WD7jIQHEIVDtaMCngR4VGQrLvyPMD8UWTdQI8g.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4be0c94aa0ee48f67c4a51f3c4ebe09ca1ce24a9" title="‘Where’s Cricket?’ Don’t Ask. Kristi Noem Defends Killing Her Dog." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/denys1973"> /u/denys1973 </a> <br /> <span><a href="https://www.nytimes.com/2024/04/26/us/politics/kristi-noem-dog-killing.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ceed19/wheres_cricket_dont_ask_kristi_noem_defends/">[comments]</a></span> </td></tr></table>

## A physician, a lawyer, a CEO: the 84 fake electors who allegedly tried to steal the 2020 election
 - [https://www.reddit.com/r/politics/comments/1cedzs3/a_physician_a_lawyer_a_ceo_the_84_fake_electors](https://www.reddit.com/r/politics/comments/1cedzs3/a_physician_a_lawyer_a_ceo_the_84_fake_electors)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T13:00:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cedzs3/a_physician_a_lawyer_a_ceo_the_84_fake_electors/"> <img alt="A physician, a lawyer, a CEO: the 84 fake electors who allegedly tried to steal the 2020 election" src="https://external-preview.redd.it/ZoeQplZ9a2E4OI9y2i-m5W7P7h2Q7TbtombUfUZ0dX4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ac0c79ee2e68d702a1d850f27f69c07d5169d3cd" title="A physician, a lawyer, a CEO: the 84 fake electors who allegedly tried to steal the 2020 election" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/kait2121"> /u/kait2121 </a> <br /> <span><a href="https://www.theguardian.com/us-news/2024/apr/27/fake-electors-2020-presidential-election">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cedzs3/a_physician_a_lawyer_a_ceo_the_84_fake_electors/">[comments]</a></span> </td></tr></table>

## Abortion threatens GOP’s chances in Florida statehouse races
 - [https://www.reddit.com/r/politics/comments/1cedzq0/abortion_threatens_gops_chances_in_florida](https://www.reddit.com/r/politics/comments/1cedzq0/abortion_threatens_gops_chances_in_florida)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T13:00:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cedzq0/abortion_threatens_gops_chances_in_florida/"> <img alt="Abortion threatens GOP’s chances in Florida statehouse races" src="https://external-preview.redd.it/p_MbjO1A_M7fnqLglyDKkPHtUuNVspUiEfGP_B-Kq2U.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=94bd971deeb34461530e71fcae05f9e15d956350" title="Abortion threatens GOP’s chances in Florida statehouse races" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zsreport"> /u/zsreport </a> <br /> <span><a href="https://thehill.com/homenews/campaign/4624576-florida-ron-desantis-abortion-ban-six-weeks-state-legislature-election-joe-biden/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cedzq0/abortion_threatens_gops_chances_in_florida/">[comments]</a></span> </td></tr></table>

## Bernie Sanders to Netanyahu: 'It Is Not Antisemitic to Hold You Accountable'
 - [https://www.reddit.com/r/politics/comments/1cedcuj/bernie_sanders_to_netanyahu_it_is_not_antisemitic](https://www.reddit.com/r/politics/comments/1cedcuj/bernie_sanders_to_netanyahu_it_is_not_antisemitic)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T12:27:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cedcuj/bernie_sanders_to_netanyahu_it_is_not_antisemitic/"> <img alt="Bernie Sanders to Netanyahu: 'It Is Not Antisemitic to Hold You Accountable'" src="https://external-preview.redd.it/N9idnGFuRrN17v7izUzK8cfyYNMYPDDEZFNwi2n2Ekg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f7f984230e73c36ac1be690968be4087b139cd22" title="Bernie Sanders to Netanyahu: 'It Is Not Antisemitic to Hold You Accountable'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Particular_Log_3594"> /u/Particular_Log_3594 </a> <br /> <span><a href="https://www.commondreams.org/news/sanders-netanyahu-antisemitism">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1cedcuj/bernie_sanders_to_netanyahu_it_is_not_antisemitic/">[comments]</a></span> </td></tr></table>

## SCOTUS v. Pregnant Patients: Idaho’s Abortion Fight Could Blow Up a “Revolutionary” Health Care Law | “My reaction can be summed up as ‘appalled,’” says health policy guru Sara Rosenbaum.
 - [https://www.reddit.com/r/politics/comments/1cec4jh/scotus_v_pregnant_patients_idahos_abortion_fight](https://www.reddit.com/r/politics/comments/1cec4jh/scotus_v_pregnant_patients_idahos_abortion_fight)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T11:16:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1cec4jh/scotus_v_pregnant_patients_idahos_abortion_fight/"> <img alt="SCOTUS v. Pregnant Patients: Idaho’s Abortion Fight Could Blow Up a “Revolutionary” Health Care Law | “My reaction can be summed up as ‘appalled,’” says health policy guru Sara Rosenbaum." src="https://external-preview.redd.it/10Jq4fp9Ibb8I0zpdyJhtVQlHn7TbXzLOwihPQ6aRVc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=aa730f554075734c824cae8157b5a2c855033237" title="SCOTUS v. Pregnant Patients: Idaho’s Abortion Fight Could Blow Up a “Revolutionary” Health Care Law | “My reaction can be summed up as ‘appalled,’” says health policy guru Sara Rosenbaum." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Murky-Site7468"> /u/Murky-Site7468 </a> <br /> <span><a href="https://www.motherjones.com/politics/2024/04/scotus-v-pregnant-patients-idahos-abortion-fight-could-blow-up-a-revolutionary-health-care-law/">[link]</a></span> 

## Barr, who said Trump shouldn’t be near Oval Office, says he will vote for him in 2024
 - [https://www.reddit.com/r/politics/comments/1ce6252/barr_who_said_trump_shouldnt_be_near_oval_office](https://www.reddit.com/r/politics/comments/1ce6252/barr_who_said_trump_shouldnt_be_near_oval_office)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T04:44:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ce6252/barr_who_said_trump_shouldnt_be_near_oval_office/"> <img alt="Barr, who said Trump shouldn’t be near Oval Office, says he will vote for him in 2024" src="https://external-preview.redd.it/wYEYMPsFBymsvRz0xYk47kiNVTmTqnWFjyf5uRtP3Gw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3ddc7a988205b5ce56c90369d6aa683f764b7eca" title="Barr, who said Trump shouldn’t be near Oval Office, says he will vote for him in 2024" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Oleg101"> /u/Oleg101 </a> <br /> <span><a href="https://www.cnn.com/2024/04/26/politics/barr-vote-for-trump-2024/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ce6252/barr_who_said_trump_shouldnt_be_near_oval_office/">[comments]</a></span> </td></tr></table>

## Supreme Court Justice Samuel Alito Argues Presidents Must Be Allowed to Commit Federal Crimes or Democracy as We Know It Will Be Over
 - [https://www.reddit.com/r/politics/comments/1ce4u3y/supreme_court_justice_samuel_alito_argues](https://www.reddit.com/r/politics/comments/1ce4u3y/supreme_court_justice_samuel_alito_argues)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T03:35:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ce4u3y/supreme_court_justice_samuel_alito_argues/"> <img alt="Supreme Court Justice Samuel Alito Argues Presidents Must Be Allowed to Commit Federal Crimes or Democracy as We Know It Will Be Over" src="https://external-preview.redd.it/d_tFbO3zqPz1QydU6y1WRUHt2Z-c3rhIpfjHLoNqiXg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=972a743fe4e5dcd19721b1bf5b1992c5253e563b" title="Supreme Court Justice Samuel Alito Argues Presidents Must Be Allowed to Commit Federal Crimes or Democracy as We Know It Will Be Over" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DCC_4LIFE"> /u/DCC_4LIFE </a> <br /> <span><a href="https://www.vanityfair.com/news/supreme-court-justice-samuel-alito-argues-presidents-must-be-allowed-to-commit-federal-crimes-or-democracy-as-we-know-it-will-be-over">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ce4u3y/supreme_court_justice_samuel

## 'That was embarrassing': Tribe torches Trump-friendly SCOTUS justices on immunity
 - [https://www.reddit.com/r/politics/comments/1ce42od/that_was_embarrassing_tribe_torches_trumpfriendly](https://www.reddit.com/r/politics/comments/1ce42od/that_was_embarrassing_tribe_torches_trumpfriendly)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T02:53:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ce42od/that_was_embarrassing_tribe_torches_trumpfriendly/"> <img alt="'That was embarrassing': Tribe torches Trump-friendly SCOTUS justices on immunity" src="https://external-preview.redd.it/2YN4AsVngnw9M0O7_8SUT8K21CY6BjVepP5KDUl1z5s.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b46838c84d8285d48dd9e7498162463847c592df" title="'That was embarrassing': Tribe torches Trump-friendly SCOTUS justices on immunity" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/99999999999999999901"> /u/99999999999999999901 </a> <br /> <span><a href="https://www.msnbc.com/the-last-word/watch/-that-was-embarrassing-tribe-torches-trump-friendly-scotus-justices-on-immunity-209742917527">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ce42od/that_was_embarrassing_tribe_torches_trumpfriendly/">[comments]</a></span> </td></tr></table>

## ‘High priest of policy’: Sen. Whitehouse slams ‘pompous’ Gorsuch on Trump immunity
 - [https://www.reddit.com/r/politics/comments/1ce40d5/high_priest_of_policy_sen_whitehouse_slams](https://www.reddit.com/r/politics/comments/1ce40d5/high_priest_of_policy_sen_whitehouse_slams)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T02:50:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ce40d5/high_priest_of_policy_sen_whitehouse_slams/"> <img alt="‘High priest of policy’: Sen. Whitehouse slams ‘pompous’ Gorsuch on Trump immunity" src="https://external-preview.redd.it/0c-WTaEaS0z2isLo8HnWyKEgD9jSjB0UFzqB-M790zE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b24d3b07823e80aae3feed0fe95e71910f80a62e" title="‘High priest of policy’: Sen. Whitehouse slams ‘pompous’ Gorsuch on Trump immunity" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/99999999999999999901"> /u/99999999999999999901 </a> <br /> <span><a href="https://www.msnbc.com/the-last-word/watch/-high-priest-of-policy-sen-whitehouse-slams-pompous-gorsuch-on-trump-immunity-209743429644">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ce40d5/high_priest_of_policy_sen_whitehouse_slams/">[comments]</a></span> </td></tr></table>

## Bill Barr Says Trump Told Him To Execute People, But Will Still Vote For Him Because Of Stoves
 - [https://www.reddit.com/r/politics/comments/1ce3y5w/bill_barr_says_trump_told_him_to_execute_people](https://www.reddit.com/r/politics/comments/1ce3y5w/bill_barr_says_trump_told_him_to_execute_people)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T02:47:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ce3y5w/bill_barr_says_trump_told_him_to_execute_people/"> <img alt="Bill Barr Says Trump Told Him To Execute People, But Will Still Vote For Him Because Of Stoves" src="https://external-preview.redd.it/PD5JzuyKb_7CxMGj6pQmZsBn4swd_Qz5ABo2e1QlBEM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=fe53ec56749c98439561cbf52b12c3070ad5195f" title="Bill Barr Says Trump Told Him To Execute People, But Will Still Vote For Him Because Of Stoves" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ev6464"> /u/ev6464 </a> <br /> <span><a href="https://www.cnn.com/2024/04/26/politics/video/bill-barr-vote-trump-intv-sot-collins-src-digvid">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ce3y5w/bill_barr_says_trump_told_him_to_execute_people/">[comments]</a></span> </td></tr></table>

## The Court Just Sealed Everyone’s Fate, Including Its Own
 - [https://www.reddit.com/r/politics/comments/1ce2eg4/the_court_just_sealed_everyones_fate_including](https://www.reddit.com/r/politics/comments/1ce2eg4/the_court_just_sealed_everyones_fate_including)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T01:27:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ce2eg4/the_court_just_sealed_everyones_fate_including/"> <img alt="The Court Just Sealed Everyone’s Fate, Including Its Own" src="https://external-preview.redd.it/D_FGRVASKOVPieoXwTg-Y_aeW5Pe793t8TH70D5XZL8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4a450474a5e76f5d9d12e763f5b47d6f6f8b359b" title="The Court Just Sealed Everyone’s Fate, Including Its Own" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/marji80"> /u/marji80 </a> <br /> <span><a href="https://newrepublic.com/article/181032/supreme-court-trump-immunity-sealed-fate">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ce2eg4/the_court_just_sealed_everyones_fate_including/">[comments]</a></span> </td></tr></table>

## The Court is Corrupt. Say It With Me.
 - [https://www.reddit.com/r/politics/comments/1ce1sj4/the_court_is_corrupt_say_it_with_me](https://www.reddit.com/r/politics/comments/1ce1sj4/the_court_is_corrupt_say_it_with_me)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T00:57:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ce1sj4/the_court_is_corrupt_say_it_with_me/"> <img alt="The Court is Corrupt. Say It With Me." src="https://external-preview.redd.it/29MFJYMQHTno_nCETBJTxiLNmcA8hO_hB8vomaWEaEU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ece339989c18e62001493032dd30a1a20c5c7d97" title="The Court is Corrupt. Say It With Me." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/marji80"> /u/marji80 </a> <br /> <span><a href="https://talkingpointsmemo.com/edblog/the-court-is-corrupt-say-it-with-me">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ce1sj4/the_court_is_corrupt_say_it_with_me/">[comments]</a></span> </td></tr></table>

## We’ve Been Entertaining an Illusion About the Supreme Court. It’s Finally Been Shattered.
 - [https://www.reddit.com/r/politics/comments/1ce0poh/weve_been_entertaining_an_illusion_about_the](https://www.reddit.com/r/politics/comments/1ce0poh/weve_been_entertaining_an_illusion_about_the)
 - RSS feed: https://www.reddit.com/r/politics/.rss
 - date published: 2024-04-27T00:05:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/politics/comments/1ce0poh/weve_been_entertaining_an_illusion_about_the/"> <img alt="We’ve Been Entertaining an Illusion About the Supreme Court. It’s Finally Been Shattered." src="https://external-preview.redd.it/tLcxFbnm5RK5N2yLp9ASobe6tCGoZmdiPaZf2oEy_qY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=833a0d1cd56911861e1cc0a1d236a87c49cbf92f" title="We’ve Been Entertaining an Illusion About the Supreme Court. It’s Finally Been Shattered." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/marji80"> /u/marji80 </a> <br /> <span><a href="https://slate.com/news-and-politics/2024/04/supreme-court-immunity-arguments-which-way-now.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/politics/comments/1ce0poh/weve_been_entertaining_an_illusion_about_the/">[comments]</a></span> </td></tr></table>

