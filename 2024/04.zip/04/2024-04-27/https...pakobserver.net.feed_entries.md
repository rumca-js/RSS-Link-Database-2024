# Source:Pakistan Observer, URL:https://pakobserver.net/feed, language:en-US

## Pakistani PM Sharif joins global leaders at WEF meeting in Saudi Arabia
 - [https://pakobserver.net/pakistani-pm-sharif-joins-global-leaders-at-wef-meeting-in-saudi-arabia](https://pakobserver.net/pakistani-pm-sharif-joins-global-leaders-at-wef-meeting-in-saudi-arabia)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T16:33:46+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/GMLzx7wWMAE_rmw-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – Prime Minister Shehbaz Sharif has landed in Saudi Arabia to attend in a special World Economic Forum (WEF) meeting focusing on &#8216;Global Collaboration, Growth, and Energy for Development,&#8217; scheduled from April 28 to 29. The premier embarked on Kingdom to attend meeting came from Kingdom’s Crown Prince Mohammed bin Salman and WEF Executive [&#8230;]

## Sessions judge Shakirullah Marwat kidnapped in northwestern Pakistan
 - [https://pakobserver.net/sessions-judge-shakirullah-marwat-kidnapped-in-northwestern-pakistan](https://pakobserver.net/sessions-judge-shakirullah-marwat-kidnapped-in-northwestern-pakistan)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T16:24:30+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/hh333-2-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />PESHAWAR – A district and sessions Judge Shakirullah Marwat has been kidnapped by armed men near Dera Ismail Khan-Tank Road on Saturday, sources said. Armed abductors took District and Sessions Judge Shakirullah Marwat near the border area, leaving behind his official vehicle, and security personnel. The incident occurred as judge Marwat was returning from duty [&#8230;]

## Suzuki Cultus Latest Price, Installment Plans in Pakistan 2024
 - [https://pakobserver.net/suzuki-cultus-latest-price-and-installment-plans-in-pakistan-2024](https://pakobserver.net/suzuki-cultus-latest-price-and-installment-plans-in-pakistan-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T15:15:34+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/gg44-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Suzuki Cultus remains among top hatchback cars of Pak Suzuki Motor Company after Alto as the 1000cc vehicle is known for its affordability and practicality. The car is ranked among budget-friendly options for those looking for a compact and reliable vehicle, especially for drive within cities. With new hike, price of Suzuki Cultus stands at [&#8230;]

## Roshan Gharana Program 2024: Check CM Maryam Nawaz Solar System Registration
 - [https://pakobserver.net/roshan-gharana-program-2024-check-cm-maryam-nawaz-solar-system-registration](https://pakobserver.net/roshan-gharana-program-2024-check-cm-maryam-nawaz-solar-system-registration)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T14:53:40+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/free-solar-panels-for-50-000-families-in-punjab-are-you-eligible-to-apply-check-here-1713235842-2905-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Punjab government announced to roll out Roshan Gharana Program across the region, and thousands of solar panels will be distributed among the common people. Under the initiative, more than 50,000 solar systems will be distributed to deserving families. In the latest development, Punjab CM Maryam Nawaz directed immediate launch of the pilot project aimed at [&#8230;]

## PAKvNZ: New Zealand win toss, opt to field first against Pakistan in series decider T20I
 - [https://pakobserver.net/pakvnz-new-zealand-win-toss-opt-to-field-first-against-pakistan-in-series-decider-t20i](https://pakobserver.net/pakvnz-new-zealand-win-toss-opt-to-field-first-against-pakistan-in-series-decider-t20i)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T14:07:24+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/1051984_3079713_NZ-Pak_updates-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />New Zealand skipper won the toss and decided to bowl first in the fifth and last T20I against Pakistan at Lahore&#8217;s Gaddafi Stadium, Lahore, on Sunday. The toss took place at 7:00 PM in iconic stadium of provincial capital where both the skippers, Babar Azam and his counterpart Michael Bracewell, were present. Black Caps are [&#8230;]

## Prince Mansour bin Badr bin Saud of Saudi Arabia passes away
 - [https://pakobserver.net/prince-mansour-bin-badr-bin-saud-of-saudi-arabia-passes-away](https://pakobserver.net/prince-mansour-bin-badr-bin-saud-of-saudi-arabia-passes-away)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T13:04:29+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/1422040100029806700-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />RIYADH – Mansour bin Badr bin Saud breathed his last on Saturday, the Royal Court announced. A statement shared by Saudi Press Agency (SPA) said the funeral prayer of Prince Mansour bin Badr will be held today at Imam Turki bin Abdullah Mosque in port city of Jeddah after Asr prayer. Royal Court also extended [&#8230;]

## Iraqi social media star Om Fahad shot dead amid dispute with rival TikToker
 - [https://pakobserver.net/iraqi-social-media-star-om-fahad-shot-dead-amid-dispute-with-rival-tiktoker](https://pakobserver.net/iraqi-social-media-star-om-fahad-shot-dead-amid-dispute-with-rival-tiktoker)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T12:53:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/hhh32-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />BAGHDAD – In a tragic incident in the Iraqi capital where TikTok sensation Om Fahad was gunned down outside her residence, prompting high-level probe in the Middle Eastern nation. Ghufran Sawadi, who was famous on internet with her social media name Om Fahad. She was shot dead outside her home in Baghdad&#8217;s Zayouna district, and [&#8230;]

## Solar Power Tax in Pakistan: Power Division’s latest update clears confusion
 - [https://pakobserver.net/solar-power-tax-in-pakistan-power-divisions-latest-update-clears-confusion](https://pakobserver.net/solar-power-tax-in-pakistan-power-divisions-latest-update-clears-confusion)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T12:00:54+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/solar-panel-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – The reports of taxation on solar panels for residential or commercial purposes shocked everyone but now the government has responded to these reports. Amid the contrasting reports, Power Division turned down reports about fixed tax on solar power. calling it misleading. Power Division clarified that no official proposal has been submitted to the [&#8230;]

## Gold rates in Pakistan drop after hitting record high; Check April 27 rates here
 - [https://pakobserver.net/gold-rates-in-pakistan-drop-after-hitting-record-high-check-april-27-rates-here](https://pakobserver.net/gold-rates-in-pakistan-drop-after-hitting-record-high-check-april-27-rates-here)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T11:28:01+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/gold-prices-in-pakistan-see-increase-today-amid-surge-in-international-market-1697860057-5816-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – Gold rates in Pakistan moved down on Saturday after hitting all-time high above Rs250,000 per tola earlier in the session amid soaring rates in international market. Data shared by Sarafa association shows Rs600 drop per tola and the new rates stands at Rs244,400. Meanwhile, the price of 10-gram bullion saw losses of around [&#8230;]

## Will leave no stone unturned for security of Chinese nationals, Naqvi tells Zhao Shiren
 - [https://pakobserver.net/will-leave-no-stone-unturned-for-security-of-chinese-nationals-naqvi-tells-zhao-shiren](https://pakobserver.net/will-leave-no-stone-unturned-for-security-of-chinese-nationals-naqvi-tells-zhao-shiren)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T10:26:55+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/yt-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Interior Minister Mohsin Naqvi reiterated on Saturday that Pakistan will not allow any conspiracy to harm its friendship with China. He expressed it during a meeting with Zhao Shiren, the Chinese Consul General in Lahore, during his visit to the consulate. During the meetings, matters related to mutual interest and security of Chinese [&#8230;]

## SC forms larger bench to hear IHC judges’ letters on April 30
 - [https://pakobserver.net/sc-forms-larger-bench-to-hear-ihc-judges-letters-on-april-30](https://pakobserver.net/sc-forms-larger-bench-to-hear-ihc-judges-letters-on-april-30)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T09:54:37+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/A-general-view-of-the-Supreme-Court-of-Pakistan-in1668673145-0-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD  &#8211;  A Supreme Court larger bench comprising six judges is scheduled to hear the case regarding the letters from six judges of the Islamabad High Court (IHC) on April 30. The cause list has been issued by the registrar office of the top court, indicating that several petitions will be collectively addressed on Tuesday. [&#8230;]

## Govt decides to establish special protection force for security of foreign nationals
 - [https://pakobserver.net/govt-decides-to-establish-special-protection-force-for-security-of-foreign-nationals](https://pakobserver.net/govt-decides-to-establish-special-protection-force-for-security-of-foreign-nationals)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T09:43:08+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/7136865471714201337-150x150.jpeg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD  &#8211; A meeting chaired by Interior Minister Mohsin Naqvi on law and order situation has decided in principle to establish a special protection force for the security of foreign nationals in the federal capital territory. On the occasion, the Interior Minister directed to ensure foolproof security of foreign nationals. The Interior Minister said special [&#8230;]

## Justice Shah calls for systematic reforms in judiciary
 - [https://pakobserver.net/justice-shah-calls-for-systematic-reforms-in-judiciary](https://pakobserver.net/justice-shah-calls-for-systematic-reforms-in-judiciary)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T09:37:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/807838_98249709-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE  &#8211; Supreme Court  Judge Justice Mansoor Ali Shah said,  “Until we are not subject to a system, we cannot move forward,”. Justice Syed Mansoor Ali Shah said that the constitution says that judiciary should be independent. It is the first time that the practice and procedure have come up, and the reforms are needed [&#8230;]

## SSP Riffat Bukhari of Punjab Police wins prestigious global award
 - [https://pakobserver.net/ssp-riffat-bukhari-of-punjab-police-wins-prestigious-global-award](https://pakobserver.net/ssp-riffat-bukhari-of-punjab-police-wins-prestigious-global-award)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T08:41:37+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/ssp-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Punjab Police officer Riffat Bukhari has been selected for an international award for her outstanding services in the police department Acknowledging Bukhari&#8217;s exemplary performance, the International Association of Women Police has picked her for the Excellence in Performance Award 2024. This award is presented annually to one female police officer from around the [&#8230;]

## Heroic Punjab ASP Shehbano Naqvi’s wedding celebrations go viral
 - [https://pakobserver.net/heroic-punjab-asp-shehbano-naqvis-wedding-celebrations-go-viral](https://pakobserver.net/heroic-punjab-asp-shehbano-naqvis-wedding-celebrations-go-viral)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T08:33:12+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/hero-cop-asp-shehrbano-s-mehndi-photoshoot-goes-viral-1714202521-1098-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE  &#8211; Punjab Police ASP Shehbano Naqvi, known for her heroic rescue of a woman from a charged mob, is now making headlines for her wedding celebrations.  Her Mehndi ceremony took place on Friday, attracting attention with photos of her in a stunning Mustard Lehnga and her groom exuding desi vibes. &#160; View this post [&#8230;]

## Normal and urgent passport delivery time; check latest update here
 - [https://pakobserver.net/normal-and-urgent-passport-delivery-time-check-latest-update-here](https://pakobserver.net/normal-and-urgent-passport-delivery-time-check-latest-update-here)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T08:09:30+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/p9-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />By Mahmood Idrees LAHORE – Applicants of normal and urgent category passports in Pakistan are facing mental agony due to massive delay, which is attributed to slow printing process due to some technical reasons. Details available on official website of the Directorate General of Immigration and Passports say the normal fee passport will be issued [&#8230;]

## Pakistan, Canada to enhance cooperation in all fields
 - [https://pakobserver.net/pakistan-canada-to-enhance-cooperation-in-all-fields](https://pakobserver.net/pakistan-canada-to-enhance-cooperation-in-all-fields)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T07:47:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/4693720321714199290-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />OTTAWA  &#8211; Pakistan and Canada on Saturday agreed to enhance cooperation in all fields of mutual interest. This came at the 5th round of Pakistan- Canada Bilateral Political Consultations in Ottawa. The two sides discussed the entire spectrum of bilateral relations and identified opportunities and possibilities for further cooperation, especially in the spheres of trade, [&#8230;]

## Pakistan’s IT exports hit record high of $2.28 billion
 - [https://pakobserver.net/pakistans-it-exports-hit-record-high-of-2-28-billion](https://pakobserver.net/pakistans-it-exports-hit-record-high-of-2-28-billion)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T07:24:39+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/it6-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; The IT exports of Pakistan have registered a record growth in March 2024, thanks to the special efforts being made by the Special Investment Facilitation Council. Official data showed the country&#8217;s IT exports surged to record high of $306 million in March this year.  Total IT exports in the first nine months of [&#8230;]

## PM Shehbaz due in Riyadh today to attend WEF’ special meeting
 - [https://pakobserver.net/pm-shehbaz-due-in-riyadh-today-to-attend-wef-special-meeting](https://pakobserver.net/pm-shehbaz-due-in-riyadh-today-to-attend-wef-special-meeting)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T07:15:36+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/hehbaz-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – Prime Minister Shehbaz Sharif will arrive in Saudi Arabia&#8217;s capital Riyadh on Saturday to participate in a special meeting of World Economic Forum on Global Cooperation, Growth and Energy. The prime minister has been invited to attend the moot by Saudi Crown Prince and Prime Minister Muhammad bin Salman Al Saud and the [&#8230;]

## Minimum bank statement for Portugal Schengen visit visa in Pakistan April 2024
 - [https://pakobserver.net/minimum-bank-statement-for-portugal-schengen-visit-visa-in-pakistan-april-2024](https://pakobserver.net/minimum-bank-statement-for-portugal-schengen-visit-visa-in-pakistan-april-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T07:12:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/03/port-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Portugal is one of the great destinations for budget travelers due to its economical accommodation and cheap food. Its beautiful cities, historic landmarks, splendid beaches, or religious sites also make him the one of the most attractive tourist countries in the world. Pakistani tourists are required to obtain the short-term Schengen visa to travel to [&#8230;]

## How much tax will be imposed on 12-kilowatt solar panel in Pakistan?
 - [https://pakobserver.net/how-much-tax-will-be-imposed-on-12-kilowatt-solar-panel-in-pakistan](https://pakobserver.net/how-much-tax-will-be-imposed-on-12-kilowatt-solar-panel-in-pakistan)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T06:16:52+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/sika-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Tax on solar panel: The Pakistani government is mulling over imposition of tax on residential and commercial solar panel users. The tax on solar panel has become a hot issue in Pakistan as the government in the past has been promoting the solar energy to cut dependency on oil-based energy. It is the reason people [&#8230;]

## Gold rates in Saudi Arabia today – 27 April 2024
 - [https://pakobserver.net/gold-rates-in-saudi-arabia-today-27-april-2024](https://pakobserver.net/gold-rates-in-saudi-arabia-today-27-april-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T05:35:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/10/gold6-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – The price of per tola price 24-karat gold in Saudi Arabia on Saturday (April 27) surged to 3,283 Saudi Riyal (SAR), according to forex.pk. Furthermore, the 10 grams of 24-k gold is being sold for SAR 2,818 in the kingdom while the per ounce gold price stands at SAR 8,764. Note: The gold [&#8230;]

## UK Pound to PKR rate today – 27 April 2024
 - [https://pakobserver.net/uk-pound-to-pkr-rate-today-27-april-2024](https://pakobserver.net/uk-pound-to-pkr-rate-today-27-april-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T05:32:37+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/pound-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; The buying rate of the UK Pound Sterling stands at Rs343.75 in Pakistan while its selling rate stands at Rs347.9 on Saturday in the open market of Pakistan. Data available on forex.pk showed that the Pound gained Rs1.2 against the Pakistani rupee in the open market. GBP to PKR Rate – 26 April [&#8230;]

## Dirham to PKR rate today – 27 April 2024
 - [https://pakobserver.net/dirham-to-pkr-rate-today-27-april-2024](https://pakobserver.net/dirham-to-pkr-rate-today-27-april-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T05:29:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/dirham-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The United Arab Emirates (UAE) Dirham buying rate in the open market of Pakistan stands at Rs75 on Saturday while the selling rate is Rs75.75, according to forex.pk. The UAE Dirham gained five paisas against Pakistani rupee as compared to the previous trading day&#8217;s closing of Rs74.95 in the open market of the [&#8230;]

## Saudi Riyal to PKR rate today – 27 April 2024
 - [https://pakobserver.net/saudi-riyal-to-pkr-rate-today-27-april-2024](https://pakobserver.net/saudi-riyal-to-pkr-rate-today-27-april-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T05:25:40+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/riyal-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The buying rate for Saudi Arabia Riyal in Pakistan stands unchanged at Rs73.3 while the selling rate stands at Rs73.95 on Saturday in open market, according to forex.pk. Data available on the currency website showed the Saudi Riyal saw no change against Pakistani rupee in the open market. SAR to PKR Rate – [&#8230;]

## Currency exchange rates in Pakistan today – April 27 , 2024
 - [https://pakobserver.net/currency-exchange-rates-in-pakistan-today-april-27-2024](https://pakobserver.net/currency-exchange-rates-in-pakistan-today-april-27-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T05:19:57+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/curreny-rate-today-15-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI—On Sunday, April 27, 2024, the exchange rate for one US Dollar against Pakistani rupees was recorded at Rs 277.25 in the local and open market, with a selling rate of Rs 279.8. Note: Exchange rates can vary based on the location and the Exchange Company or bank involved in the transaction. Below are the foreign [&#8230;]

## Gold rate in Pakistan today – 27 April, 2024
 - [https://pakobserver.net/gold-rate-in-pakistan-today-27-april-2024](https://pakobserver.net/gold-rate-in-pakistan-today-27-april-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T05:16:12+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/gold-rate-in-pakistan-today-24-March-2023-1-1024x576-4-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI—On Saturday, April 27, 2024, the 24-karat gold rate was PKR 238,800. Similarly, the bullion market recorded the gold price for 24-karat at Rs 204,740 per 10g. Gold Price in Pakistan’s different cities. City Gold Silver Karachi PKR 238,800 PKR 2,550 Lahore PKR 238,800 PKR 2,550 Islamabad PKR 238,800 PKR 2,550 Peshawar PKR 238,800 PKR [&#8230;]

## China hopes US can view China’s development in positive light: Xi
 - [https://pakobserver.net/china-hopes-us-can-view-chinas-development-in-positive-light-xi](https://pakobserver.net/china-hopes-us-can-view-chinas-development-in-positive-light-xi)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:40+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/07/President-Xi-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Chinese President Xi Jinping said here Friday that China is happy to see a confident, open, prosperous and thriving United States, and hopes the United States can also look at China’s development in a positive light. “This is a fundamental issue that must be addressed, just like the first button of a shirt that must [&#8230;]

## Decisions taken to cut power prices, minimise theft: PM
 - [https://pakobserver.net/decisions-taken-to-cut-power-prices-minimise-theft-pm](https://pakobserver.net/decisions-taken-to-cut-power-prices-minimise-theft-pm)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:37+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/INP-26-15-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Prime Minister Shehbaz Sharif said on Friday the government was pursuing agenda of economic reforms in the country and the elements involved in deep-rooted menace of corruption and criminal negligence would be held accountable. He was chairing a meeting of federal cabinet at the PM House on Friday. PM Shehbaz said he had completed the [&#8230;]

## Judges’ letter: SC clubs all pleas for hearing on April 30
 - [https://pakobserver.net/judges-letter-sc-clubs-all-pleas-for-hearing-on-april-30](https://pakobserver.net/judges-letter-sc-clubs-all-pleas-for-hearing-on-april-30)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:34+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/isa7-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Supreme Court of Pakistan on Friday clubbed all pleas filed after IHC judges’ letter raised allegations of interference by intelligence agencies in the judicial domain. The apex court clubbed the pleas moved by Islamabad, Lahore, Balochistan High Court Bars, Aitzaz Ahsan, Shehbaz Khosa and Mian Dawood. The attorney general of Pakistan and all the [&#8230;]

## Nawaz set to lead PML-N again
 - [https://pakobserver.net/nawaz-set-to-lead-pml-n-again](https://pakobserver.net/nawaz-set-to-lead-pml-n-again)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:30+00:00

<img alt="Rana Sanaullah arrest" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/05/255468991651827435-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Fida Hussnain Lahore In a major development, the Pakistan Muslim League-Nawaz (PML-N) organizational meeting decided to elect party Supremo and former Prime Minister Nawaz Sharif as its president, the sources said. The sources said that a resolution was unanimously approved in this regard. “The party leaders expressed the unwavering support and confidence in Nawaz Sharif’s [&#8230;]

## SIC second largest party in NA, ECP tells NA secretariat
 - [https://pakobserver.net/sic-second-largest-party-in-na-ecp-tells-na-secretariat](https://pakobserver.net/sic-second-largest-party-in-na-ecp-tells-na-secretariat)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:27+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/ECP-Feb-22-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Election Commission of Pakistan on Friday officially informed the National Assembly Secretariat that Sunni Alliance Council is the second largest party in National Assembly. The ECP officially notified the National Assembly Secretariat regarding the party positions in NA. According to the ECP report, Sunni Alliance Council has total 82 members including 49 from Punjab [&#8230;]

## FBR makes 12 senior officers OSD
 - [https://pakobserver.net/fbr-makes-12-senior-officers-osd](https://pakobserver.net/fbr-makes-12-senior-officers-osd)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:25+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/FBR-696x398-696x398-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />In a major reshuffle, the Federal Board of Revenue has notified transfers of 12 BS-21-22 officers of the Inland Revenue Service and Pakistan Customs Service to Member (Admin Pool), Federal Board of Revenue (Hq), Islamabad, local news channel reported on Friday. According to sources, the transfers are made on the instructions of Prime Minister Shehbaz [&#8230;]

## Warrant issued for arrest of Achakzai
 - [https://pakobserver.net/warrant-issued-for-arrest-of-achakzai](https://pakobserver.net/warrant-issued-for-arrest-of-achakzai)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:22+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/Mahmood-Khan-Achakzai-has-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />A lower court on Friday issued a warrants for the arrest of Mahmood Khan Achakzai, the chief of the Pakhtunkhwa Milli Awami Party over charges of illegal occupation and violation of the Maintenance of Public Order. A judicial magistrate in Quetta issued the arrest warrant for Achakzai in connection with the case registered at the [&#8230;]

## KSE-100 index soars 700 points
 - [https://pakobserver.net/kse-100-index-soars-700-points](https://pakobserver.net/kse-100-index-soars-700-points)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:18+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/psx-4-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Pakistan Stock Exchange’s benchmark KSE-100 index soared by over 700 points on Friday on anticipation of a cut in the key policy rate. The benchmark KSE-100 index gained 771.34 points, or 1.07 per cent, to stand at 72,742.74 points at the day’s close from the previous close of 71,971.40. Yousuf M Farooq, director of [&#8230;]

## Pak Navy’s 1st Hangor Class submarine launched
 - [https://pakobserver.net/pak-navys-1st-hangor-class-submarine-launched](https://pakobserver.net/pak-navys-1st-hangor-class-submarine-launched)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:13+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/04/PAK-NAVY-CHINA-1-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Launching ceremony of 1st Hangor Class submarine constructed for Pakistan Navy was held at Wuchang Shipbuilding Industry Group Company Ltd, Shuangliu Base at Wuhan China. Chief of the Naval Staff Admiral Naveed Ashraf graced the occasion as Chief Guest. While addressing the ceremony Chief of the Naval Staff highlighted the importance of maritime security under [&#8230;]

## Pakistan in ‘contact with US’ on energy requirements: FO
 - [https://pakobserver.net/pakistan-in-contact-with-us-on-energy-requirements-fo](https://pakobserver.net/pakistan-in-contact-with-us-on-energy-requirements-fo)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-04-27T03:15:10+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/mumtaz-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Foreign Office Spokesperson Mumtaz Zahra Baloch on Friday said Pakistan was in contact with the United States regarding the country’s requirements for energy. Addressing her weekly media briefing in Islamabad, the spokesperson said she had seen the US’s statement on Pakistan’s willingness to get energy from Iran. Earlier this week, a State Department spokesperson had [&#8230;]

