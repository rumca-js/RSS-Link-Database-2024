# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## US TikTok ban, Why Google sucks now, Nvidia contributes to NVK: Linux & Open Source News
 - [https://www.youtube.com/watch?v=SDDHG3YH2vI](https://www.youtube.com/watch?v=SDDHG3YH2vI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw
 - date published: 2024-04-27T15:31:46+00:00

Try out Proton Mail, the secure email that protects your privacy: https://proton.me/mail/TheLinuxEXP

Grab a brand new laptop or desktop running Linux: https://www.tuxedocomputers.com/en#


👏 SUPPORT THE CHANNEL:
Get access to:
- a Daily Linux News show
- a weekly patroncast for more personal thoughts
- polls on the next topics I cover,
- your name in the credits

YouTube: https://www.youtube.com/@thelinuxexp/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want:
https://paypal.me/thelinuxexp
Liberapay: https://liberapay.com/TheLinuxExperiment/

👕 GET TLE MERCH
Support the channel AND get cool new gear: https://the-linux-experiment.creator-spring.com/

🎙️ LINUX AND OPEN SOURCE NEWS PODCAST:
Listen to the latest Linux and open source news, with more in depth coverage, and ad-free!  https://podcast.thelinuxexp.com

🏆 FOLLOW ME ELSEWHERE:
Website: https://thelinuxexp.com
Mastodon: https://mastodon.social/web/@thelinuxEXP
Pixelfed: https://pixelfed

