# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## U.S. Intel Suggests Putin May Not Have Ordered Navalny Death in Prison: WSJ
 - [https://www.themoscowtimes.com/2024/04/27/us-intel-suggests-putin-may-not-have-ordered-navalny-death-in-prison-wsj-a84974](https://www.themoscowtimes.com/2024/04/27/us-intel-suggests-putin-may-not-have-ordered-navalny-death-in-prison-wsj-a84974)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-27T20:02:00+00:00

The findings based on both classified intelligence and analysis of public facts, raise new questions about Navalny's death.

## Russian Journalist Detained Over Videos Produced for Navalny’s Team
 - [https://www.themoscowtimes.com/2024/04/27/russian-journalist-detained-over-videos-produced-for-navalnys-team-a84975](https://www.themoscowtimes.com/2024/04/27/russian-journalist-detained-over-videos-produced-for-navalnys-team-a84975)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-27T17:19:00+00:00

The court said he is accused of "taking part in the preparation of photos and videos to be published on the YouTube channel NavalnyLIVE."

## Russia Hits Ukrainian Energy Sites in ‘Massive’ Overnight Attack
 - [https://www.themoscowtimes.com/2024/04/27/russia-hits-ukrainian-energy-sites-in-massive-overnight-attack-a84973](https://www.themoscowtimes.com/2024/04/27/russia-hits-ukrainian-energy-sites-in-massive-overnight-attack-a84973)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-27T08:45:57+00:00

The Ukrainian air force said Moscow fired 34 missiles, of which 21 were shot down.

