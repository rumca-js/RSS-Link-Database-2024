# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Nie żyje polski youtuber i gracz w FIFA
 - [https://www.wirtualnemedia.pl/artykul/nie-zyje-dawid-dev-blach-zmarl](https://www.wirtualnemedia.pl/artykul/nie-zyje-dawid-dev-blach-zmarl)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-27T09:39:53.692604+00:00

Zmarł Dawid "DEV" Błach, youtuber związany z piłkarską sceną EA Sports FC 24, a wcześniej z FIFA. Miał 31 lat.

## Netflix pokaże film „Bokser”. Eryk Kulm Jr w roli głównej
 - [https://www.wirtualnemedia.pl/artykul/netflix-oglasza-film-bokser-eryk-kulm-jr-ada-chlebicka-kiedy-premiera](https://www.wirtualnemedia.pl/artykul/netflix-oglasza-film-bokser-eryk-kulm-jr-ada-chlebicka-kiedy-premiera)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-27T06:24:12.144101+00:00

Najnowszy film Mitji Okorna, zatytułowany „Bokser”, to historia o pogoni za marzeniami, odwadze, ale i o gorzkiej cenie sukcesu. W rolach głównych zobaczymy Adę Chlebicką oraz Eryka Kulma Jr, który by wcielić się w rolę profesjonalnego pięściarza, przeszedł znaczącą metamorfozę.

## Czy pomyliliśmy się polecając nowy hit Netfliksa „Reniferek”? Tego nie powiedział nam twórca
 - [https://www.wirtualnemedia.pl/artykul/reniferek-netflix-czy-tworca-oszukal-widzow-stalkerka-namierzona-internetowy-lincz-czy-warto-ogladac-serial](https://www.wirtualnemedia.pl/artykul/reniferek-netflix-czy-tworca-oszukal-widzow-stalkerka-namierzona-internetowy-lincz-czy-warto-ogladac-serial)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-27T06:24:12.117383+00:00

W ubiegłym tygodniu serial „Reniferek” szturmem zdobył miejsca w top 10 Netfliksa, zachwycił widzów i krytyków. Samo dzieło filmowe nadal jest godne polecenia, ponieważ opowiada wciągającą, brutalną, niejednoznaczną historię, w której role kata i ofiary nie są przyporządkowane nikomu raz na zawsze. W związku z popularnością serialu, opartego na rzeczywistych doświadczeniach twórcy, musimy jednak zapytać o zaplecze etyczne i konsekwencje emisji obrazu, mające wpływ na życie realnych osób.

## Znani youtuberzy tworzą nowy kanał. Będą konkurencją dla gigantów?
 - [https://www.wirtualnemedia.pl/artykul/rafal-masny-program-pierwszy-polskiego-youtube-a-kanal-zero](https://www.wirtualnemedia.pl/artykul/rafal-masny-program-pierwszy-polskiego-youtube-a-kanal-zero)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-27T06:24:12.085414+00:00

Program Pierwszy Polskiego YouTube’a to nowy kanał od znanych youtuberów. Nie zobaczymy tam na razie polityków. - Dziś są oni specjalistami od wywiadów i sztuczek retorycznych pozwalających wyprowadzić rozmowę na przychylne im tory - tłumaczy nam Rafał Masny, jeden z twórców projektu.

