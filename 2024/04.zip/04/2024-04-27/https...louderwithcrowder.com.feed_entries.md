# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed, language:en-US

## "The Democrat Party can KISS MY A$$": Rock legend goes anti-woke, trashes the Left like it's a 70s hotel room
 - [https://www.louderwithcrowder.com/cherie-currie-democrats](https://www.louderwithcrowder.com/cherie-currie-democrats)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-04-27T11:09:35+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52116380&amp;width=1200&amp;height=800&amp;coordinates=68%2C0%2C132%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>It is hardly the case that a celebrity goes from voting Republican to Democrat. But more often than not, if a well-known person is <a href="https://www.foxnews.com/entertainment/kat-von-d-leaving-california-part-time-tyrannical-government-overreach" target="_blank">changing </a>their political affiliation it is almost always because they are trashing the left. </p><p>Singer Cherie Currie is the latest celebrity to announce her disdain with Democrat policies and although voting ‚ÄúDem used to be cool,‚Äù it ‚Äúnow makes you a fool.‚Äù</p><p>‚ÄúWhen your pa

## Grab popcorn! The WH wanted to secretly FIRE Karine Jean-Pierre, but was afraid to because she is a black, lesbian immigrant
 - [https://www.louderwithcrowder.com/kjp-biden-fire](https://www.louderwithcrowder.com/kjp-biden-fire)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-04-27T11:06:41+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.webp?id=52116600&amp;width=1200&amp;height=800&amp;coordinates=97%2C0%2C98%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>It is no surprise that White House Press Secretary Karine Jean-Pierre (<a href="https://www.louderwithcrowder.com/doocy-jean-pierre-gas-prices" target="_blank">KJP</a>) got hired because she is a Black lesbian. But it just so happens that she also cannot get fired because she is a Black lesbian. </p><p>It turns out that when you hire people based on the color of their skin and their sexual preferences, you don‚Äôt end up with the most qualified candidate. Who would have guessed? </p><p>Subsequently, KJP sucks at her job but the White House is too scared t

## "Stop taking things away from our little girls": Dad breaks down speaking out against letting boys ruin girls sports
 - [https://www.louderwithcrowder.com/dad-speaks-out-girls-sports](https://www.louderwithcrowder.com/dad-speaks-out-girls-sports)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-04-27T11:00:25+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=52116040&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C200%2C0" /><br /><br /><p><em>Subscribe to Louder with Crowder on Rumble! Download the app on <a href="https://apps.apple.com/us/app/rumble/id1518427877" target="_blank">Apple</a> and <a href="https://play.google.com/store/apps/details?id=com.rumble.battles" target="_blank">Google Play</a>.</em></p><p>Transgender ideology is based on the lie that sex and gender are two different things. But because that is blatantly false, even Progressives can‚Äôt keep up with their lack of logic. This is why they are destroying girls‚Äô sports in the process and they don‚Äôt care as long as they get to claim that they did all they could to make sure trans women are women. </p><p>Not everyone has witnessed first-hand what it feels like to have your hard work and dedication destroyed all because of an asinine ideology that makes no sense. But this dad has, which is why 

