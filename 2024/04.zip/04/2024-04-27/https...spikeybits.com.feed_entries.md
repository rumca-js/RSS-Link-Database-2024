# Source:Spikey Bits, URL:https://spikeybits.com/feed, language:en-US

## New 40k Orks & Adeptus Custodes Available Now!
 - [https://spikeybits.com/warhammer-40k/new-40k-orks-adeptus-custodes-available-now](https://spikeybits.com/warhammer-40k/new-40k-orks-adeptus-custodes-available-now)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-27T19:30:32+00:00

<p><p><a href="https://spikeybits.com/?p=460805&amp;preview=true"><img alt="orks custodes now avialable warhammer 40k" class="aligncenter wp-image-460943 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/orks-custodes-now-avialable-warhammer-40k.png" width="1280" /></a>The new Orks and Adeptus Custodes releases, including codexes and Combat Patrols, are available now on store shelves and online!</p>
<div>
<div class="iframe-block iframe-block--contained">
<div class="iframe-block__inner&lt;/p&gt;
&lt;p&gt;&lt;a href="></p>
<p><a href="https://spikeybits.com/warhammer-40k/new-40k-orks-adeptus-custodes-available-now/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/new-40k-orks-adeptus-custodes-available-now/">New 40k Orks &#038; Adeptus Custodes Available Now!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New Precision Tau Dice Maximize Your Odds For the Greater Good
 - [https://spikeybits.com/tabletop-news/roll-for-the-greater-good-with-precision-dice-designs](https://spikeybits.com/tabletop-news/roll-for-the-greater-good-with-precision-dice-designs)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-27T17:30:02+00:00

<p><p><a href="https://spikeybits.com/2024/04/roll-for-the-greater-good-with-precision-dice-designs.html"><img alt="Tau Dice Baron of" class="aligncenter wp-image-459533 size-full" height="721" src="https://spikeybits.com/wp-content/uploads/2024/04/Tau-Dice-Baron-of.png" width="1202" /></a>These new hand-swirled resin precision dice from Baron of Dice are bubble-free and perfect for the arrival of 10th Edition 40k Tau!</p>
<p><span id="more-459265"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch"></p>
<p><a href="https://spikeybits.com/tabletop-news/roll-for-the-greater-good-with-precision-dice-designs/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/tabletop-news/roll-for-the-greater-good-with-precision-dice-designs/">New Precision Tau Dice Maximize Your Odds For the Greater Good</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New Tau Rules, Next Primarch, GW Release Roadmap For May
 - [https://spikeybits.com/tabletop-news/new-tau-rules-next-primarch-gw-release-roadmap-for-may](https://spikeybits.com/tabletop-news/new-tau-rules-next-primarch-gw-release-roadmap-for-may)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-27T16:05:37+00:00

<p><p><a href="https://spikeybits.com/?p=460801&amp;preview=true"><img alt="gw rumors and new releases warhammer 40k age of sigmar horus heresy the old world necromunda notext games workshop new releases warhammer roadmap" class="aligncenter wp-image-451936 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2023/12/gw-rumors-and-new-releases-warhammer-40k-age-of-sigmar-horus-heresy-the-old-world-necromunda.png" width="1280" /></a>Don&#8217;t miss the scoop on Games</p>
<p><a href="https://spikeybits.com/tabletop-news/new-tau-rules-next-primarch-gw-release-roadmap-for-may/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/tabletop-news/new-tau-rules-next-primarch-gw-release-roadmap-for-may/">New Tau Rules, Next Primarch, GW Release Roadmap For May</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Gear Up With Mech Suits & More From the Tablehammer April Patreon!
 - [https://spikeybits.com/warhammer-40k/mech-suits-tablehammer-april-patreon](https://spikeybits.com/warhammer-40k/mech-suits-tablehammer-april-patreon)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-27T13:30:03+00:00

<p><p><a href="https://spikeybits.com/warhammer-40k/mech-suits-tablehammer-april-patreon/"><img alt="Tablehammer April Patreon" class="aligncenter wp-image-460769" height="711" src="https://spikeybits.com/wp-content/uploads/2024/04/Screenshot_255-e1713974409204.png" width="1280" /></a>From mech suits to RPG guards, The Tablehammer April Patreon release is chock full of alternative Warhammer 40k models you&#8217;ve got to check out!</p>
<p><span id="more-460583"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch"></p>
<p><a href="https://spikeybits.com/warhammer-40k/mech-suits-tablehammer-april-patreon/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/mech-suits-tablehammer-april-patreon/">Gear Up With Mech Suits &#038; More From the Tablehammer April Patreon!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New 40k Tau & Horus Heresy Solar Auxilia: FIRST LOOK
 - [https://spikeybits.com/warhammer-40k/new-40k-tau-horus-heresy-solar-auxilia-first-look](https://spikeybits.com/warhammer-40k/new-40k-tau-horus-heresy-solar-auxilia-first-look)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-27T10:30:45+00:00

<p><p><a href="https://spikeybits.com/?p=460947&amp;preview=true"><img alt="warhammer-logo-wal-hor-store-GW-first-look-pre-orders-new-release" class="aligncenter wp-image-446574 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2023/10/warhammer-logo-wal-hor-store-GW-first-look-pre-orders-new-release.png" width="1280" /></a>Here is a first look at the new Tau codex and miniatures for 10th Edition Warhammer 40k and more, which are available for pre-order this weekend.</p>
<p><span id="more-460947"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch"></p>
<p><a href="https://spikeybits.com/warhammer-40k/new-40k-tau-horus-heresy-solar-auxilia-first-look/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/new-40k-tau-horus-heresy-solar-auxilia-first-look/">New 40k Tau &#038; Horus Heresy Solar Auxilia: FIRST LOOK</a> from <a href="https://spikeybits.com">Spikey B

