# Source:emzdanowicz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA, language:pl

## Najlepsze gry indie kwietnia (2024)
 - [https://www.youtube.com/watch?v=8GPAcoC3SkI](https://www.youtube.com/watch?v=8GPAcoC3SkI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA
 - date published: 2024-04-27T15:55:34+00:00

Oto najciekawsze gry niezależne, w które zagrałem w kwietniu.

Zobacz też moje wrażenia z nowego polskiego hitu, Manor Lords: https://www.youtube.com/watch?v=MzMz9AbNawQ

0:00 Najciekawsze indyki kwietnia
0:28 Buckshot Roulette
2:30 Harold Halibut
4:58 Minishoot Adventures
6:53 Children of the Sun
8:49 Shadow of the Depths
10:11 Tohou: Hero of Ice Fairy

Linki do Steama:

https://store.steampowered.com/app/2835570/Buckshot_Roulette/
https://store.steampowered.com/app/924750/Harold_Halibut/
https://store.steampowered.com/app/1634860/Minishoot_Adventures/
https://store.steampowered.com/app/1309950/Children_of_the_Sun/
https://store.steampowered.com/app/2100150/Shadow_of_the_Depth/
https://store.steampowered.com/app/1955830/TouhouHeroofIceFairy/

Na moim kanale znajdziesz recenzje gier wideo. Recenzje gier na PC, recenzje gier konsolowych. Publikuję tu także wrażenia z gier, czyli materiały nieco luźniejsze, które recenzjami gier nie są. Nieważne, czy twoją ulubioną platformą do gier jes

