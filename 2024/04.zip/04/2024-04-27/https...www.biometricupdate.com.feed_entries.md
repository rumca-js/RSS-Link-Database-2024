# Source:Biometric Update, URL:https://www.biometricupdate.com/feed, language:en-US

## Biometrics to support easier interactions grow with new tech, guidance
 - [https://www.biometricupdate.com/202404/biometrics-to-support-easier-interactions-grow-with-new-tech-guidance](https://www.biometricupdate.com/202404/biometrics-to-support-easier-interactions-grow-with-new-tech-guidance)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2024-04-27T17:57:31+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1536" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2024/04/27135152/user-authentication-scaled.jpg" width="2048" />
		Iris biometrics capturing at a distance, authentication for encryption keys and open digital identity APIs are all confirmed as mature technologies in a trio of the most-read stories on <em>Biometric Update </em>this week. NIST has made room for passkeys in its digital identity guidelines, NEC technology has enabled the introduction of new biometric border control gates in Singapore, and OSIA has been officially accepted by the ITU. Each represents an expansion supporting ease of use. Meanwhile Microsoft has decided not to make deepfakes creation easier, a Jumio executive offers some practical advice as age verification gets serious, and biometric payment cards gain more traction in Asia with a deal for Idex.
<h2>Most-read biometrics news this week</h2>
NIST is not 

