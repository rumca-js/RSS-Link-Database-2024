# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Chiński robot imponuje “ludzką” szybkością i precyzją. Bez problemu obierze ogórka i odkręci butelkę
 - [https://www.chip.pl/2024/04/astribot-s1-humanoidalny-robot](https://www.chip.pl/2024/04/astribot-s1-humanoidalny-robot)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T21:38:48+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2024/04/astribot-s1.jpeg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/04/astribot-s1.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>Chiński robot Astribot S1 może wykonywać ruchy z maksymalną prędkością 10 m/s i bez problemu podnieść jednym ramieniem 10 kg. Wydaje się, że idealnie sprawdzi się w fabryce lub innym zakładzie produkcyjnym, w którym liczy się &#8220;ludzka&#8221; szybkość i precyzja. Era humanoidalnych robotów jest w rozkwicie, a nowe modele są szkolone na coraz lepszych pomocników [&#8230;]</p>

## Pierwszy latający samochód już w powietrzu. Na pokładzie wyjątkowy gość
 - [https://www.chip.pl/2024/04/latajacy-samochod-aircar-pierwszy-lot](https://www.chip.pl/2024/04/latajacy-samochod-aircar-pierwszy-lot)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T20:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1920" src="https://konto.chip.pl/wp-content/uploads/2024/04/aircar-1-scaled.jpeg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/04/aircar-1-scaled.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>Pierwszy latający samochód AirCar wzbił się w powietrze w Słowacji. Na pokładzie znalazł się wyjątkowy pasażer &#8211; francuski wirtuoz muzyki elektronicznej, Jean-Michel Jarre. Tuż za polską granicą pisze się historia, bowiem w powietrze wzbił się AirCar firmy Klein Vision. Nie byłoby w tym nic dziwnego, gdyby nie fakt, że &#8211; jak sama nazwa wskazuje &#8211; [&#8230;]</p>

## Antywirusy i ochrona komputera: kilka istotnych pytań i odpowiedzi
 - [https://www.chip.pl/2024/04/antywirusy-fakty-mity-funkcje-zasady-dzialania](https://www.chip.pl/2024/04/antywirusy-fakty-mity-funkcje-zasady-dzialania)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T19:01:39+00:00

<img alt="Antywirusy" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2024/04/Antywirusy-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/04/Antywirusy-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jeśli używasz systemu Windows, masz na pewno program antywirusowy. Niestety, jest to niezbędne, gdyż w internecie roi się od dziesiątków różnego rodzaju szkodników, a cyberprzestępcy używają licznych sposobów na to, aby zaszkodzić. Jednak istnieje w powszechnej świadomości wiele szkodliwych przekonań na temat antywirusów. Czas wyjaśnić, jak jest naprawdę. Antywirusy towarzyszą komputerom osobistym praktycznie od samego [&#8230;]</p>

## Wodór produkują na niespotykaną do tej pory skalę. Wzrost o 4000%
 - [https://www.chip.pl/2024/04/wodor-paliwo-nowy-elektrolizer-rewolucja](https://www.chip.pl/2024/04/wodor-paliwo-nowy-elektrolizer-rewolucja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T19:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1333" src="https://konto.chip.pl/wp-content/uploads/2024/03/Wodor-bezpieczna-elektroliza-1.jpg" style="margin-bottom: 10px;" width="2000" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/Wodor-bezpieczna-elektroliza-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Niemal o 4000% wzrosła żywotność katalizatora wykorzystywanego przez japońskich naukowców w procesie wytwarzania wodoru z wody. Przedstawiciele RIKEN Center for Sustainable Resource Science wyjaśniają, jak udało im się uzyskać tak imponujący wynik. Ich artykuł w tej sprawie trafił na łamy Nature Catalysis i opisuje, jak działa ta rewolucyjna metoda pozwalająca na ekstrakcję wodoru z wody. [&#8230;]</p>

## Dwutlenek węgla zmienia w coś znacznie przydatniejszego. Rewolucyjny reaktor już działa i zachwyca
 - [https://www.chip.pl/2024/04/reaktor-elektrochemiczny-przeksztalcanie-co2](https://www.chip.pl/2024/04/reaktor-elektrochemiczny-przeksztalcanie-co2)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T17:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="583" src="https://konto.chip.pl/wp-content/uploads/2022/12/dwutlenek-wegla.jpeg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/dwutlenek-wegla.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>Bardzo imponujące wydają się możliwości związane z działaniem pewnego reaktora elektrochemicznego zaprojektowanego przez inżynierów związanych z Georgia Institute of Technology. Urządzenie to jest skonstruowane tak, aby przekształcać dwutlenek węgla na przykład w paliwo czy tworzywa sztuczne. Przeprowadzone testy wykazały wysoką wydajność energetyczną oraz opłacalność pod względem ekonomicznym. To dwa podstawowe aspekty wyróżniające nowe podejście względem [&#8230;]</p>

## Piasek zachowuje się wbrew zdrowemu rozsądkowi. Fizycy wyjaśniają, dlaczego się tak dzieje
 - [https://www.chip.pl/2024/04/piasek-materialy-ziarniste-nietypowe-zachowanie](https://www.chip.pl/2024/04/piasek-materialy-ziarniste-nietypowe-zachowanie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T16:00:39+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/09/piasek.jpg" style="margin-bottom: 10px;" width="1620" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/09/piasek.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Niektóre materiały mają tendencję do zmiennego zachowania. W efekcie raz funkcjonują tak, jakby były ciałami stałymi, a kiedy indziej &#8211; cieczami. Naukowcy postanowili wyjaśnić, dlaczego się tak dzieje, odnosząc się do różnych sytuacji, na przykład piasku przepływającego przez klepsydrę. Za ustaleniami w tej sprawie stoją Onuttom Narayan z Uniwersytetu Kalifornijskiego i Harsh Mathur z Case [&#8230;]</p>

## Samsung wystartował z nową promocją – dwa smartfony w cenie jednego
 - [https://www.chip.pl/2024/04/samsung-promocja-galaxy-s20-fe](https://www.chip.pl/2024/04/samsung-promocja-galaxy-s20-fe)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T15:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/09/samsung-galaxy-z-fold5-46-1.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/09/samsung-galaxy-z-fold5-46-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zwykle południowokoreański gigant raczy nas promocjami typu cashback, gdzie po zakupie sprzętu można odzyskać część wydanych na niego środków. Tymczasem teraz Samsung zorganizował zupełnie inną akcję – kupując jeden z wybranych smartfonów, drugi możemy otrzymać w prezencie. Nie zabrakło jednak pewnego ALE. Jeśli śledzicie na bieżąco podobne wiadomości, to zapewne wiecie, że ta promocja już [&#8230;]</p>

## Test laptopa MSI Raider GE68 HX 14V. NVIDIA GeForce RTX 4090 robi różnicę
 - [https://www.chip.pl/2024/04/msi-raider-ge68-hx-14v-test-recenzja-opinia](https://www.chip.pl/2024/04/msi-raider-ge68-hx-14v-test-recenzja-opinia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T14:05:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1125" src="https://konto.chip.pl/wp-content/uploads/2024/04/MSI-Raider-GE68-HX-14V-3.jpg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/04/MSI-Raider-GE68-HX-14V-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>MSI Raider GE68 HX 14V to jeden z najwydajniejszych laptopów, jakie możecie kupić w sklepach. Model 14VIG-407PL wyposażony został w kartę graficzną NVIDIA GeForce RTX 4090, procesor Intel Core i9-14900HX, 32 GB pamięci DDR5 i 2 TB dysk. Taka konstrukcja powinna świetnie sprawdzić się w grach, ale również w zastosowaniach profesjonalnych. Sprawdźmy więc, czy rzeczywiście [&#8230;]</p>

## Nowa metoda pomiaru z kwantowym podłożem. Pomogło zjawisko znane od XIX wieku
 - [https://www.chip.pl/2024/04/metoda-pomiaru-kwantowe-anomalne-zjawisko-halla](https://www.chip.pl/2024/04/metoda-pomiaru-kwantowe-anomalne-zjawisko-halla)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T13:13:55+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="685" src="https://konto.chip.pl/wp-content/uploads/2024/04/zjawisko-halla.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/04/zjawisko-halla.jpg" style="display: block; margin: 1em auto;" /></p>
<p>A w zasadzie jego wariant, ponieważ mówimy o kwantowej wersji tzw. anomalnego zjawiska Halla. Odkryte w 1879 roku zjawisko stanowiło niedawno obiekt zainteresowania naukowców z Uniwersytetu w Würzburgu.&#160; Tylko po co to wszystko? Celem było opracowanie narzędzia, które pozwoliłoby na wykonywanie precyzyjnych pomiarów rezystancji elektrycznej. Takowe pełnią w bardzo istotną rolę w produkcji przemysłowej lub [&#8230;]</p>

## Problemy z procesorami? Intel obarcza winą producentów płyt głównych
 - [https://www.chip.pl/2024/04/intel-procesory-plyty-glowne-firmware](https://www.chip.pl/2024/04/intel-procesory-plyty-glowne-firmware)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T11:59:41+00:00

<img alt="Intel" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2024/04/Intel-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/04/Intel-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Od jakiegoś czasu na całym świecie pojawiają się informacje o problemach z wydajnością i stabilnością procesorów Intela należących do 13. i 14. generacji. Producent twierdzi, że to nie jego wina, a producentów płyt głównych, którzy nie przestrzegają wydanych zaleceń. Kto ma rację? Pierwsze wiadomości o szwankowaniu procesorów pojawiły się już kilka miesięcy temu. Raporty wskazywały [&#8230;]</p>

## 5 sposobów na podrasowanie komputera. Podnieś wydajność dzięki kilku prostym działaniom
 - [https://www.chip.pl/2024/04/komputer-optymalizacja-dzialania-sprzetu](https://www.chip.pl/2024/04/komputer-optymalizacja-dzialania-sprzetu)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T11:10:15+00:00

<img alt="Komputer" class="attachment-full size-full wp-post-image" height="1440" src="https://konto.chip.pl/wp-content/uploads/2024/04/Komputer-stacjonarny-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/04/Komputer-stacjonarny-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Komputer działa wolno i masz ochotę powiedzieć, że to nie to samo, co kiedyś? System jest aktualny, wszystkie pojawiające się w Windows Update nowości wprowadzasz na bieżąco, a mimo to nie widać polepszenia? Cóż &#8211; nie musisz jeszcze myśleć o wymianie sprzętu na nowy. Istnieje kilka sposobów na to, aby przywrócić mu sprawność. Są znacznie [&#8230;]</p>

## W to nagranie nie uwierzysz. Obejrzyj jak ukraiński pilot myśliwca sieje zniszczenie z iPada
 - [https://www.chip.pl/2024/04/ukraina-mysliwiec-pilot-ipad](https://www.chip.pl/2024/04/ukraina-mysliwiec-pilot-ipad)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T10:02:26+00:00

<img alt="Su-27" class="attachment-full size-full wp-post-image" height="1068" src="https://konto.chip.pl/wp-content/uploads/2023/08/Ukraina-bomba-JDAM-ER-MiG-29-Su-27.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/Ukraina-bomba-JDAM-ER-MiG-29-Su-27.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Ukraina dostanie wprawdzie myśliwce F-16, ale ma też na służbie kilkadziesiąt samolotów bojowych dawnej ery, które muszą być modernizowane, aby przyjąć na pokład nowoczesne uzbrojenie. Jak wynika z najnowszych dowodów, modernizacja nie obejmuje wyłącznie przebudowy pylonów pod skrzydłami. Tablety Apple w ukraińskich myśliwcach, czyli jak dostosować stare do nowego Modernizacja samolotów bojowych z kilkoma dekadami [&#8230;]</p>

## Parking w Warszawie? Podążaj za niebieską tablicą
 - [https://www.chip.pl/2024/04/parking-warszawa-niebieskie-tablice-zdm](https://www.chip.pl/2024/04/parking-warszawa-niebieskie-tablice-zdm)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T08:58:33+00:00

<img alt="Parking Warszawa" class="attachment-full size-full wp-post-image" height="644" src="https://konto.chip.pl/wp-content/uploads/2024/04/Parking-Warszawa.jpg" style="margin-bottom: 10px;" width="1200" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/04/Parking-Warszawa.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Warszawski Zarząd Dróg Miejskich niedawno przeprowadził program pilotażowy niebieskich tablic, który okazał się bardzo udaną inicjatywą. Dlatego zostaje wdrożony plan wprowadzenia na ulicach aż trzydziestu ośmiu nowych &#8211; ogłoszono właśnie przetarg na ich dostawę i montaż na terenie miasta. Wszystkie mają pomóc w znalezieniu parkingu z wolnymi miejscami. Samo znalezienie parkingu to żadna sztuka, jednak [&#8230;]</p>

## Plastikowy rower dla dorosłych. Jak daleko na nim zajedziemy?
 - [https://www.chip.pl/2024/04/rower-rcyl-plastik-recykling-ekologia](https://www.chip.pl/2024/04/rower-rcyl-plastik-recykling-ekologia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T08:06:48+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2024/04/Rower-RYCL-plastik-3.jpg" style="margin-bottom: 10px;" width="1792" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/04/Rower-RYCL-plastik-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Hasła &#8220;ratuj planetę i wymień swój samochód na rower&#8221; zyskują zupełnie nowe znaczenie po tym, co opracowała firma igus. Mowa o plastikowym rowerze RCYL, który ustanawia nowy standard dla ekologicznych środków transportu, a to przez fakt, że wykorzystuje w swojej konstrukcji plastik z recyklingu. RCYL musi być marzeniem ekologów. Ten rower to po prostu ucieleśnienie [&#8230;]</p>

## Pierwsza samotna planeta na koncie TESS. Te tajemnicze obiekty wciąż zastanawiają naukowców
 - [https://www.chip.pl/2024/04/samotna-planeta-teleskop-tess-obserwacja](https://www.chip.pl/2024/04/samotna-planeta-teleskop-tess-obserwacja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T07:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1041" src="https://konto.chip.pl/wp-content/uploads/2022/01/tess.jpg" style="margin-bottom: 10px;" width="1852" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/01/tess.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Samotne planety, zwane również swobodnymi, wzbudzają ogromne zainteresowanie w świecie astronomii. To za sprawą ich niezwykłej natury, poznawanej coraz lepiej, choćby dzięki ostatnim dokonaniom teleskopu TESS. Transiting Exoplanet Survey Satellite, bo tak brzmi pełna nazwa należącego do NASA instrumentu, zyskał ostatnio pierwszy łup w zakresie poszukiwania samotnych planet. To istotne osiągnięcie, szczególnie cenne ze względu [&#8230;]</p>

## Obejrzyj, jak Twarde są twarde. Rosjanie uczyli jak niszczyć te polskie czołgi
 - [https://www.chip.pl/2024/04/rosja-polski-czolg-twardy-nagranie](https://www.chip.pl/2024/04/rosja-polski-czolg-twardy-nagranie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-04-27T04:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1281" src="https://konto.chip.pl/wp-content/uploads/2022/06/Przyszlosc-czolgu-PT-91-Twardy.-Opisujemy-najliczniejsze-czolgi-Wojska-Polskiego-6.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/06/Przyszlosc-czolgu-PT-91-Twardy.-Opisujemy-najliczniejsze-czolgi-Wojska-Polskiego-6.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Rosjanie pochwalili się nagraniem ze zwalczania byłych polskich czołgów PT-91 Twardy w rękach Ukrainy, które daje nam wiele do myślenia. Przeciwpancerne pociski nie są straszne polskim czołgom Twardy Polskie czołgi Twardy, czyli te z serii PT-91, już od kwietnia 2023 są stałym elementem krajobrazu za naszą wschodnią granicą, jako że przekazaliśmy ukraińskiemu wojsku przynajmniej 30 [&#8230;]</p>

