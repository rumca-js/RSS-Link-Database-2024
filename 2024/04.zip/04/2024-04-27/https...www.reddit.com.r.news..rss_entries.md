# Source:Reddit - News, URL:https://www.reddit.com/r/news/.rss, language:en-US

## Louisiana man sentenced to 50 years in prison, physical castration for raping teen
 - [https://www.reddit.com/r/news/comments/1ces7xs/louisiana_man_sentenced_to_50_years_in_prison](https://www.reddit.com/r/news/comments/1ces7xs/louisiana_man_sentenced_to_50_years_in_prison)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T23:32:13+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/elephant35e"> /u/elephant35e </a> <br /> <span><a href="https://www.cbsnews.com/news/glenn-sullivan-jr-louisiana-sentenced-rape-prison-castration/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ces7xs/louisiana_man_sentenced_to_50_years_in_prison/">[comments]</a></span>

## ‘Like a war zone’: Emory University grapples with fallout from police response to protest
 - [https://www.reddit.com/r/news/comments/1cerxw0/like_a_war_zone_emory_university_grapples_with](https://www.reddit.com/r/news/comments/1cerxw0/like_a_war_zone_emory_university_grapples_with)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T23:19:11+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/GratefulDeadpool"> /u/GratefulDeadpool </a> <br /> <span><a href="https://www.theguardian.com/us-news/2024/apr/27/emory-university-georgia-police-campus-protests">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cerxw0/like_a_war_zone_emory_university_grapples_with/">[comments]</a></span>

## Police arrest Finns Party MP over nightclub shooting
 - [https://www.reddit.com/r/news/comments/1cenvsq/police_arrest_finns_party_mp_over_nightclub](https://www.reddit.com/r/news/comments/1cenvsq/police_arrest_finns_party_mp_over_nightclub)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T20:17:59+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/mmicoandthegirl"> /u/mmicoandthegirl </a> <br /> <span><a href="https://yle.fi/a/74-20086058">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cenvsq/police_arrest_finns_party_mp_over_nightclub/">[comments]</a></span>

## USC cancels main stage commencement ceremony
 - [https://www.reddit.com/r/news/comments/1cekvic/usc_cancels_main_stage_commencement_ceremony](https://www.reddit.com/r/news/comments/1cekvic/usc_cancels_main_stage_commencement_ceremony)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T18:08:38+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/vemeron"> /u/vemeron </a> <br /> <span><a href="https://www.fox2detroit.com/news/usc-cancels-commencement-ceremony">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cekvic/usc_cancels_main_stage_commencement_ceremony/">[comments]</a></span>

## Commerce Department announces new restrictions on U.S. firearms exports
 - [https://www.reddit.com/r/news/comments/1cekveo/commerce_department_announces_new_restrictions_on](https://www.reddit.com/r/news/comments/1cekveo/commerce_department_announces_new_restrictions_on)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T18:08:32+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/jeetah"> /u/jeetah </a> <br /> <span><a href="https://apnews.com/article/gun-exports-biden-commerce-9f6fa1be36e266f316eb7da5d37870ae">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cekveo/commerce_department_announces_new_restrictions_on/">[comments]</a></span>

## Iraqi TikTok star Umm Fahad shot dead in Baghdad
 - [https://www.reddit.com/r/news/comments/1cekr65/iraqi_tiktok_star_umm_fahad_shot_dead_in_baghdad](https://www.reddit.com/r/news/comments/1cekr65/iraqi_tiktok_star_umm_fahad_shot_dead_in_baghdad)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T18:03:42+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/andrevan"> /u/andrevan </a> <br /> <span><a href="https://www.cnn.com/2024/04/27/middleeast/iraq-tiktok-star-umm-fahad-killed-intl/index.html?Date=20240427&amp;Profile=CNN%20International&amp;utm_content=1714233618&amp;utm_medium=social&amp;utm_source=facebook">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cekr65/iraqi_tiktok_star_umm_fahad_shot_dead_in_baghdad/">[comments]</a></span>

## Residents begin going through the rubble after tornadoes hammer parts of Nebraska and Iowa
 - [https://www.reddit.com/r/news/comments/1cejssu/residents_begin_going_through_the_rubble_after](https://www.reddit.com/r/news/comments/1cejssu/residents_begin_going_through_the_rubble_after)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T17:23:41+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/kundu123"> /u/kundu123 </a> <br /> <span><a href="https://www.informnny.com/news/ap-tornadoes-collapse-buildings-and-level-homes-in-nebraska-and-iowa/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cejssu/residents_begin_going_through_the_rubble_after/">[comments]</a></span>

## Columbia University says it has banned student protester who said 'Zionists don't deserve to live'
 - [https://www.reddit.com/r/news/comments/1cejbau/columbia_university_says_it_has_banned_student](https://www.reddit.com/r/news/comments/1cejbau/columbia_university_says_it_has_banned_student)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T17:02:35+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/a_dogs_mother"> /u/a_dogs_mother </a> <br /> <span><a href="https://www.nbcnews.com/news/us-news/columbia-university-says-banned-khymani-james-protester-said-zionists-rcna149642">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cejbau/columbia_university_says_it_has_banned_student/">[comments]</a></span>

## ‘Sophisticated’: Four men arrested after break-in string targeting South Asians in 25 Mass. towns
 - [https://www.reddit.com/r/news/comments/1ceh8md/sophisticated_four_men_arrested_after_breakin](https://www.reddit.com/r/news/comments/1ceh8md/sophisticated_four_men_arrested_after_breakin)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T15:32:40+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Fair-Bath-5512"> /u/Fair-Bath-5512 </a> <br /> <span><a href="https://www.boston25news.com/news/local/sophisticated-several-arrests-made-after-break-in-string-targeting-south-asians-mass/5OCWIP5P5JBZPJYGAZUBQ5CN4E/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ceh8md/sophisticated_four_men_arrested_after_breakin/">[comments]</a></span>

## Kansas City, Missouri, police officer charged with stealing $300,000 in donations from anti-crime charity
 - [https://www.reddit.com/r/news/comments/1cefhym/kansas_city_missouri_police_officer_charged_with](https://www.reddit.com/r/news/comments/1cefhym/kansas_city_missouri_police_officer_charged_with)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T14:14:22+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/nosotros_road_sodium"> /u/nosotros_road_sodium </a> <br /> <span><a href="https://www.kshb.com/news/crime/kansas-city-missouri-police-officer-charged-with-stealing-300-000-in-donations-from-anti-crime-charity">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cefhym/kansas_city_missouri_police_officer_charged_with/">[comments]</a></span>

## Louvre Considers Moving Mona Lisa to Underground Room
 - [https://www.reddit.com/r/news/comments/1cecbrq/louvre_considers_moving_mona_lisa_to_underground](https://www.reddit.com/r/news/comments/1cecbrq/louvre_considers_moving_mona_lisa_to_underground)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T11:28:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/lordatlas"> /u/lordatlas </a> <br /> <span><a href="https://www.artnews.com/art-news/news/louvre-considers-moving-mona-lisa-to-underground-chamber-to-end-public-disappointment-1234704489/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cecbrq/louvre_considers_moving_mona_lisa_to_underground/">[comments]</a></span>

## TikTok will not be sold, Chinese parent ByteDance tells US - BBC News
 - [https://www.reddit.com/r/news/comments/1cebon0/tiktok_will_not_be_sold_chinese_parent_bytedance](https://www.reddit.com/r/news/comments/1cebon0/tiktok_will_not_be_sold_chinese_parent_bytedance)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T10:48:40+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Pasivite"> /u/Pasivite </a> <br /> <span><a href="https://www.bbc.com/news/articles/c289n8m4j19o.amp">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1cebon0/tiktok_will_not_be_sold_chinese_parent_bytedance/">[comments]</a></span>

## Devastating tornadoes rip through Nebraska and Iowa, sending crews searching flattened homes as storm threat continues
 - [https://www.reddit.com/r/news/comments/1ceb21r/devastating_tornadoes_rip_through_nebraska_and](https://www.reddit.com/r/news/comments/1ceb21r/devastating_tornadoes_rip_through_nebraska_and)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T10:07:42+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/antihostile"> /u/antihostile </a> <br /> <span><a href="https://www.cnn.com/2024/04/27/weather/plains-midwest-storms-tornadoes-climate-saturday/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ceb21r/devastating_tornadoes_rip_through_nebraska_and/">[comments]</a></span>

## Pelosi urges Gaza campus protesters to target Hamas as well as Israel
 - [https://www.reddit.com/r/news/comments/1ce8otp/pelosi_urges_gaza_campus_protesters_to_target](https://www.reddit.com/r/news/comments/1ce8otp/pelosi_urges_gaza_campus_protesters_to_target)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T07:27:42+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/4920185"> /u/4920185 </a> <br /> <span><a href="https://www.bbc.com/news/world-us-canada-68909910">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ce8otp/pelosi_urges_gaza_campus_protesters_to_target/">[comments]</a></span>

## 3 women diagnosed with HIV after ‘vampire facials’ at unlicensed U.S. spa
 - [https://www.reddit.com/r/news/comments/1ce84iu/3_women_diagnosed_with_hiv_after_vampire_facials](https://www.reddit.com/r/news/comments/1ce84iu/3_women_diagnosed_with_hiv_after_vampire_facials)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T06:51:11+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/zuuzuu"> /u/zuuzuu </a> <br /> <span><a href="https://globalnews.ca/news/10453073/vampire-facials-hiv-new-mexico-unlicensed-spa/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ce84iu/3_women_diagnosed_with_hiv_after_vampire_facials/">[comments]</a></span>

## Ex-Amazon exec claims she was asked to ignore copyright law in race to AI
 - [https://www.reddit.com/r/news/comments/1ce631q/examazon_exec_claims_she_was_asked_to_ignore](https://www.reddit.com/r/news/comments/1ce631q/examazon_exec_claims_she_was_asked_to_ignore)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T04:46:22+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/WhiteBearPrince"> /u/WhiteBearPrince </a> <br /> <span><a href="https://www.theregister.com/2024/04/22/ghaderi_v_amazon/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ce631q/examazon_exec_claims_she_was_asked_to_ignore/">[comments]</a></span>

## Clearwater property owners sell $58M real estate portfolio to Church of Scientology parishioner
 - [https://www.reddit.com/r/news/comments/1ce5l6j/clearwater_property_owners_sell_58m_real_estate](https://www.reddit.com/r/news/comments/1ce5l6j/clearwater_property_owners_sell_58m_real_estate)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T04:17:10+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/xdeltax97"> /u/xdeltax97 </a> <br /> <span><a href="https://www.fox13news.com/news/clearwater-property-owners-sell-58m-real-estate-portfolio-to-church-of-scientology-entities">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ce5l6j/clearwater_property_owners_sell_58m_real_estate/">[comments]</a></span>

## Andrew Tate and brother Tristan to be tried in Romania on rape and trafficking charges
 - [https://www.reddit.com/r/news/comments/1ce57uj/andrew_tate_and_brother_tristan_to_be_tried_in](https://www.reddit.com/r/news/comments/1ce57uj/andrew_tate_and_brother_tristan_to_be_tried_in)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T03:56:59+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/nosotros_road_sodium"> /u/nosotros_road_sodium </a> <br /> <span><a href="https://www.bbc.com/news/world-europe-68907298">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ce57uj/andrew_tate_and_brother_tristan_to_be_tried_in/">[comments]</a></span>

## 7-year-old brings gun to school in backpack, police say
 - [https://www.reddit.com/r/news/comments/1ce4db1/7yearold_brings_gun_to_school_in_backpack_police](https://www.reddit.com/r/news/comments/1ce4db1/7yearold_brings_gun_to_school_in_backpack_police)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T03:09:47+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AtrusHomeboy"> /u/AtrusHomeboy </a> <br /> <span><a href="https://www.fox13memphis.com/education/7-year-old-brings-gun-to-school-in-backpack-police-say/article_6e526eb8-03e7-11ef-a51b-b33c4386f846.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ce4db1/7yearold_brings_gun_to_school_in_backpack_police/">[comments]</a></span>

## Detroit is about to break the all-time NFL draft attendance record
 - [https://www.reddit.com/r/news/comments/1ce3idd/detroit_is_about_to_break_the_alltime_nfl_draft](https://www.reddit.com/r/news/comments/1ce3idd/detroit_is_about_to_break_the_alltime_nfl_draft)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-04-27T02:24:25+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/kundu123"> /u/kundu123 </a> <br /> <span><a href="https://www.mlive.com/lions/2024/04/detroit-is-about-to-break-the-all-time-nfl-draft-attendance-record.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1ce3idd/detroit_is_about_to_break_the_alltime_nfl_draft/">[comments]</a></span>

