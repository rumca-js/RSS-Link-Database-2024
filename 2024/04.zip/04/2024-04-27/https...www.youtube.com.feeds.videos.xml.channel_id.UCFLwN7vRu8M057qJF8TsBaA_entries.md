# Source:UpIsNotJump, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA, language:en-US

## Fallout TV show - ep. 3 review #fallout #review #gaming #fallouttvshow  #gamer #funny
 - [https://www.youtube.com/watch?v=KayypoQX38o](https://www.youtube.com/watch?v=KayypoQX38o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLwN7vRu8M057qJF8TsBaA
 - date published: 2024-04-27T18:30:24+00:00

I'm reveiwing each episode of the new Fallout TV show until you get bored of it! What did you think of episode 3?

