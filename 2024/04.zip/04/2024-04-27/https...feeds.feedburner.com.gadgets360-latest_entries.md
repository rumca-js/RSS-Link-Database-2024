# Source:Gadgets 360, URL:https://feeds.feedburner.com/gadgets360-latest, language:en

## Oppo A60 With 6.67-inch LCD Screen, Snapdragon 680 SoC Launched: Price, Specifications
 - [https://www.gadgets360.com/mobiles/news/oppo-a60-price-launch-sale-specifications-features-5535722](https://www.gadgets360.com/mobiles/news/oppo-a60-price-launch-sale-specifications-features-5535722)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-27T10:54:48+00:00

Oppo A60 sports a dual rear camera setup

## Google Parent Alphabet Joins $2 Trillion Club as Results Show AI Strength
 - [https://www.gadgets360.com/internet/news/alphabet-usd-2-trillion-market-capitalisation-google-ai-strength-5535304](https://www.gadgets360.com/internet/news/alphabet-usd-2-trillion-market-capitalisation-google-ai-strength-5535304)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-27T09:31:12+00:00

Alphabet joined Apple, Microsoft, Saudi Aramco, and Nvidia in crossing the $2 trillion threshold

## Apple ID Account Bug Locks Some Users Out of Accounts, Forces Password Reset
 - [https://www.gadgets360.com/mobiles/news/apple-id-login-password-reset-error-bug-how-to-fix-5534544](https://www.gadgets360.com/mobiles/news/apple-id-login-password-reset-error-bug-how-to-fix-5534544)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-27T08:07:12+00:00

App passwords will also need to be set up again after a password reset

## Google Pixel 8a Video Showing AI Features Leaks; Promotional Images Indicate 7-Year Software Support
 - [https://www.gadgets360.com/mobiles/news/google-pixel-8a-ai-features-reveal-leak-specifications-expected-5534273](https://www.gadgets360.com/mobiles/news/google-pixel-8a-ai-features-reveal-leak-specifications-expected-5534273)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-27T06:38:38+00:00

Google Pixel 8a is expected to succeed last year's Pixel 7a (pictured) smartphone

## Vivo X100 Ultra, Vivo S19 and Vivo S19 Pro Bag 3C Certification Ahead of Anticipated Launch in China
 - [https://www.gadgets360.com/mobiles/news/vivo-x100-ultra-s19-certification-china-launch-specifications-expected-5533491](https://www.gadgets360.com/mobiles/news/vivo-x100-ultra-s19-certification-china-launch-specifications-expected-5533491)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-27T03:58:34+00:00

Vivo X100 series (pictured) was previously launched in India and other markets

## Apple Renews Talks With OpenAI for iPhone Generative AI Features
 - [https://www.gadgets360.com/mobiles/news/apple-openai-iphone-generative-ai-features-discussions-5533308](https://www.gadgets360.com/mobiles/news/apple-openai-iphone-generative-ai-features-discussions-5533308)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-27T02:39:58+00:00

Apple is said to be seeking partners to power a chatbot-like feature akin to OpenAI’s ChatGPT

