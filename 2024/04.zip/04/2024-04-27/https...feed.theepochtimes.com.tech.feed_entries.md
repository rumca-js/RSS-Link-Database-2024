# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Social Media Poses Numerous Risks to Young Minds, Change ‘Needed Soon’, New Study Warns
 - [https://www.theepochtimes.com/tech/social-media-poses-numerous-risks-to-young-minds-change-needed-soon-new-study-warns-5638536](https://www.theepochtimes.com/tech/social-media-poses-numerous-risks-to-young-minds-change-needed-soon-new-study-warns-5638536)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-04-27T21:02:20+00:00

Children's developing minds are at risk from social media stimuli, experts say. (Alain Jocard/AFP/Getty Images)

