# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Australia Threatening The UNKTHINKABLE For Elon Musk - This Is Insane
 - [https://www.youtube.com/watch?v=wjjIIosn908](https://www.youtube.com/watch?v=wjjIIosn908)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-04-27T17:00:27+00:00

Wake up everyday and choose freedom, order at https://1775coffee.com/BRAND

Australia's prime minister said Elon Musk is an "arrogant billionaire who thinks he is above the law" over his reluctance to remove footage of last week's Church stabbing from X.

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

