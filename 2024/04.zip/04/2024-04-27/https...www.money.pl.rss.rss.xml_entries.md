# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Kasowy PIT rozchwieje finanse państwa? Eksperci: istnieje takie ryzyko
 - [https://www.money.pl/podatki/kasowy-pit-rozchwieje-finanse-panstwa-eksperci-istnieje-takie-ryzyko-7020389185178560a.html](https://www.money.pl/podatki/kasowy-pit-rozchwieje-finanse-panstwa-eksperci-istnieje-takie-ryzyko-7020389185178560a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-04-27T16:05:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/26c4c36d-df29-487e-b375-9ecfcdad36c7" width="308" /> Wprowadzenie kasowego PIT-u przez rząd oznacza też kasową składkę zdrowotną. Przedsiębiorcy odprowadzą ją, dopiero kiedy dostaną zapłatę za fakturę. Istnieje ryzyko, że zatory płatnicze z sektora MŚP przejdą na Narodowy Fundusz Zdrowia. Ministerstwo Zdrowia analizuje projekt.

## Biją na alarm i apelują do rządu o środki dla tej grupy pracowników
 - [https://www.money.pl/pieniadze/bija-na-alarm-i-apeluja-do-rzadu-o-srodki-dla-tej-grupy-pracownikow-7021393923488672a.html](https://www.money.pl/pieniadze/bija-na-alarm-i-apeluja-do-rzadu-o-srodki-dla-tej-grupy-pracownikow-7021393923488672a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-04-27T12:00:46+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/698c02a9-787b-42af-a2fc-1e17db7e3321" width="308" /> Polski Związek Pracodawców Ochrona alarmuje, że bez urealnienia wartości subsydiów płacowych z PFRON firmy ochrony nie będą w stanie utrzymać poziomu zatrudnienia osób z niepełnosprawnością. Branża ta, dzięki postępowi technologii, jest szansą dla takich pracowników.

## CBA nakryło proboszcza. Są poważne zarzuty. Kuria podjęła decyzję
 - [https://www.money.pl/podatki/cba-nakrylo-proboszcza-sa-powazne-zarzuty-kuria-podjela-decyzje-7021402372287424a.html](https://www.money.pl/podatki/cba-nakrylo-proboszcza-sa-powazne-zarzuty-kuria-podjela-decyzje-7021402372287424a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-04-27T09:30:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6fc1c1a9-e444-409c-8d8d-e6402830e613" width="308" /> Zatrzymany przez CBA proboszcz parafii św. Faustyny w Warszawie został zawieszony w wykonywaniu obowiązków - poinformowano w oświadczeniu opublikowanym na stronie Diecezji Warszawsko-Praskiej.

## Proboszcz zatrzymany przez CBA. Kuria podjęła decyzję
 - [https://www.money.pl/podatki/proboszcz-zatrzymany-przez-cba-kuria-podjela-decyzje-7021402372287424a.html](https://www.money.pl/podatki/proboszcz-zatrzymany-przez-cba-kuria-podjela-decyzje-7021402372287424a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-04-27T09:30:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6fc1c1a9-e444-409c-8d8d-e6402830e613" width="308" /> Zatrzymany przez CBA proboszcz parafii św. Faustyny w Warszawie został zawieszony w wykonywaniu obowiązków - poinformowano w oświadczeniu opublikowanym na stronie Diecezji Warszawsko-Praskiej.

## Niedopłata podatku. Co wtedy? Jest ważny termin
 - [https://www.money.pl/podatki/niedoplata-podatku-co-wtedy-jest-wazny-termin-7021201461124000a.html](https://www.money.pl/podatki/niedoplata-podatku-co-wtedy-jest-wazny-termin-7021201461124000a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-04-27T05:50:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/193e0dec-32e0-4741-a7cf-e635e434451d" width="308" /> Podatnicy podatku PIT, z których zaznania za 2023 rok wynika niedopłata podatku, powinni go uregulować najpóźniej 30 kwietnia 2024 r. Wpłaty należy dokonać na mikrorachunek podatkowy. Podatnik, który nie zna numeru - powinien posłużyć się generatorem mikrorachunku.

