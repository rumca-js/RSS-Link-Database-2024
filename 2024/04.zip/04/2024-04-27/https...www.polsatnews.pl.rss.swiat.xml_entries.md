# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Hakerzy uderzyli w Białoruś. Upublicznili dane o KGB. "Prawda wyjdzie na jaw"
 - [https://www.polsatnews.pl/wiadomosc/2024-04-27/hakerzy-uderzyli-w-bialorus-upublicznili-dane-o-kgb-prawda-wyjdzie-na-jaw](https://www.polsatnews.pl/wiadomosc/2024-04-27/hakerzy-uderzyli-w-bialorus-upublicznili-dane-o-kgb-prawda-wyjdzie-na-jaw)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-04-27T17:09:00+00:00

Białoruskie KGB zhakowane. Jego strona internetowa zdjęta na dwa miesiące - taki komunikat opublikowała grupa Belarusian Cyber-Partisans. W ramach akcji skierowanej przeciwko dyktaturze Alaksandra Łukaszenki hakerzy wykradli i upublicznili dane ponad 8600 pracowników szpiegowskiej agencji.

## Papież Franciszek zaproszony na szczyt G7. Będzie mówił o sztucznej inteligencji
 - [https://www.polsatnews.pl/wiadomosc/2024-04-27/papiez-franciszek-zaproszony-na-szczyt-g7-bedzie-mowil-o-sztucznej-inteligencji](https://www.polsatnews.pl/wiadomosc/2024-04-27/papiez-franciszek-zaproszony-na-szczyt-g7-bedzie-mowil-o-sztucznej-inteligencji)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-04-27T15:38:00+00:00

Papież Franciszek weźmie udział w organizowanym przez Włochy szczycie grupy G7. Przywódcę Kościoła zaproszono, ponieważ niejednokrotnie mówił o sztucznej inteligencji i jej właściwym wykorzystaniu. Uznano, że swoim zdaniem o AI powinien podzielić się na specjalnym panelu. - Obecność Franciszka dodaje prestiżu grupie G7 - uznała premier Włoch Giorgia Meloni.

## Turyści zdenerwowali Japończyków. Przy górze Fudżi stanie specjalna bariera
 - [https://www.polsatnews.pl/wiadomosc/2024-04-27/turysci-zdenerwowali-japonczykow-przy-gorze-fudzi-stanie-specjalna-bariera](https://www.polsatnews.pl/wiadomosc/2024-04-27/turysci-zdenerwowali-japonczykow-przy-gorze-fudzi-stanie-specjalna-bariera)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-04-27T14:38:00+00:00

Fudżi - najsłynniejsza japońska góra, a zarazem czynny wulkan - z roku na rok przyciąga coraz więcej zagranicznych turystów. Większość z nich chce zrobić pamiątkowe zdjęcie z górą w tle, nie zważając przy tym na dobre wychowanie i przepisy. Miejscowi Japończycy mają dość i stawiają sporą, czarną siatkę, która zasłoni widok miejscu w obleganym przez przyjezdnych.

## Aktywista z Ghany przytula drzewa. Ustanowił światowy rekord
 - [https://www.polsatnews.pl/wiadomosc/2024-04-27/aktywista-z-ghany-przytula-drzewa-ustanowil-swiatowy-rekord](https://www.polsatnews.pl/wiadomosc/2024-04-27/aktywista-z-ghany-przytula-drzewa-ustanowil-swiatowy-rekord)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-04-27T14:20:00+00:00

29-letni aktywista i student leśnictwa z Ghany Abubakar Tahiru ustanowił rekord Guinnessa w liczbie drzew przytulonych w ciągu godziny. W 60 minut udało mu się uścisnąć 1123 rośliny. Chciał w ten sposób zwrócić uwagę na kluczową rolę drzew w naszym ekosystemie i pilną potrzebę ochrony środowiska.

## Rosja. Ukraińskie drony zaatakowały. Na celowniku "kluczowe obiekty technologiczne"
 - [https://www.polsatnews.pl/wiadomosc/2024-04-27/rosja-ukrainskie-drony-zaatakowaly-na-celowniku-kluczowe-obiekty-technologiczne](https://www.polsatnews.pl/wiadomosc/2024-04-27/rosja-ukrainskie-drony-zaatakowaly-na-celowniku-kluczowe-obiekty-technologiczne)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-04-27T10:29:00+00:00

W nocnym ataku ukraińskie drony uderzyły w dwie rafinerie i lotnisko wojskowe w kraju krasnodarskim w Rosji. W zaatakowanych obiektach wybuchły pożary. Rosyjskie władze twierdzą, że nie doszło poważnych zniszczeń, a ich obronie przeciwlotniczej udało się zestrzelić w sumie 68 ukraińskich dronów. Tej samej nocy Rosjanie uderzyli w ukraińskie elektrociepłownie.

## Izrael zaproponował rozejm. "Hamas przeanalizuje propozycję"
 - [https://www.polsatnews.pl/wiadomosc/2024-04-27/wojna-w-strefie-gazy-hamas-reaguje-na-izraelska-propozycje-rozejmu](https://www.polsatnews.pl/wiadomosc/2024-04-27/wojna-w-strefie-gazy-hamas-reaguje-na-izraelska-propozycje-rozejmu)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-04-27T08:01:00+00:00

- Hamas przeanalizuje tę propozycję i przedstawi swoją odpowiedź - przekazał jeden z przywódców palestyńskiej organizacji, Chalil Al-Hajja. To odpowiedź na oficjalną izraelską propozycję rozejmu, która pojawiła się po wizycie egipskich mediatorów. Izrael daje ostatnią szansę negocjacjom, choć nie zaprzestaje ataków wokół Rafah - ostatniego miasta w Strefie Gazy pod kontrolą Hamasu.

## Ukraina i Rosja miały negocjować rozejm. Wyciekł tajny dokument
 - [https://www.polsatnews.pl/wiadomosc/2024-04-27/ukraina-i-rosja-mialy-negocjowac-rozejm-wyciekl-tajny-dokument](https://www.polsatnews.pl/wiadomosc/2024-04-27/ukraina-i-rosja-mialy-negocjowac-rozejm-wyciekl-tajny-dokument)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-04-27T07:43:00+00:00

Ukraina i Rosja miały uzgodnione warunki pokoju. Według informacji zawartych w porozumieniu Ukraina miała oddać Rosji część okupowanych terenów, w tym m.in. Donbas, w zamian za gwarancję bezpieczeństwa ze strony mocarstwa. Ponadto Kijów miał złożyć deklarację ws. broni jądrowej. Szczegóły miały być ustalone między Wołodymyrem Zełenskim a Władimirem Putinem, jednak do spotkania nigdy nie doszło.

