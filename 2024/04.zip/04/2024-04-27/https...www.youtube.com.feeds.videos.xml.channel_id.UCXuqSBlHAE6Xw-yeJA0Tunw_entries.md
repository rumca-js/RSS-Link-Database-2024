# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Bought a Recording Jammer. It’s Legal.
 - [https://www.youtube.com/watch?v=FyeCn7HlLck](https://www.youtube.com/watch?v=FyeCn7HlLck)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2024-04-27T16:59:51+00:00

Get the AI-powered UPDF Editor with an exclusive discount now: https://bit.ly/49folsk

Check out the UGREEN NASync DXP480T Plus at https://bit.ly/3Ts3KLB (35% off until May 9th)

With this Ultrasonic Recording Jammer, Linus can finally speak his mind! Of course, he was already doing that..

Discuss on the forum:  https://linustechtips.com/topic/1568350-i-bought-a-recording-jammer-it%E2%80%99s-legal/

Some light reading about ultrasonic jamming:
https://synrg.csl.illinois.edu/papers/backdoor_mobisys17.pdf
https://people.cs.uchicago.edu/~ravenben/publications/pdf/ultra-chi20.pdf
https://counterespionage.com/ultrasonic-microphone-jammers/
https://arxiv.org/pdf/1904.08490

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► EQUIPMENT WE USE TO FILM LTT: https://lmg.gg/LTTEquipment
► OU

