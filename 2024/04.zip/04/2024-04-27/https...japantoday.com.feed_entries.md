# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## S Korea to consult Naver, after report firm faces Japan pressure to divest stake
 - [https://japantoday.com/category/business/south-korea-to-consult-naver-after-report-firm-faces-japan-pressure-to-divest-stake](https://japantoday.com/category/business/south-korea-to-consult-naver-after-report-firm-faces-japan-pressure-to-divest-stake)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:42:43+00:00

South Korea said on Saturday it will consult with Naver, after media reported that the domestic internet company was under pressure from Japan to divest from a venture,…

## Offensive depth has Rangers on verge of sweep, Avalanche and Oilers each up 2-1 in first round
 - [https://japantoday.com/category/sports/offensive-depth-has-rangers-on-verge-of-sweep-avalanche-and-oilers-each-up-2-1-in-first-round](https://japantoday.com/category/sports/offensive-depth-has-rangers-on-verge-of-sweep-avalanche-and-oilers-each-up-2-1-in-first-round)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:37:59+00:00

Nine players have already scored for the New York Rangers and Edmonton Oilers, 10 for the Colorado Avalanche.
That depth of scoring early in the NHL playoffs has…

## Olympics boss distances himself from athletics prize money move
 - [https://japantoday.com/category/sports/olympics-boss-distances-himself-from-athletics-prize-money-move](https://japantoday.com/category/sports/olympics-boss-distances-himself-from-athletics-prize-money-move)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:37:52+00:00

The head of the International Olympic Committee (IOC) distanced himself from a taboo-busting move from World Athletics' governing body to offer prize money to gold medallists at this…

## Nadal, Sinner and Swiatek advance at Madrid Open
 - [https://japantoday.com/category/sports/swiatek-reaches-madrid-open-round-of-16-after-easy-win-over-cirstea](https://japantoday.com/category/sports/swiatek-reaches-madrid-open-round-of-16-after-easy-win-over-cirstea)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:37:45+00:00

Rafael Nadal tore his headband off, thrust his arms in the air, and soaked up the cheers. It was only a second-round win, but coming from where Nadal…

## Hawks come from behind to beat Lions
 - [https://japantoday.com/category/sports/baseball-hawks-come-from-behind-to-beat-lions](https://japantoday.com/category/sports/baseball-hawks-come-from-behind-to-beat-lions)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:37:31+00:00

Ukyo Shuto doubled and scored the winning run on Hikaru Kawase's one-out 10th-inning single as the Pacific League-leading SoftBank Hawks came from behind Saturday to beat the Seibu…

## Liverpool's Premier League title hopes suffer blow; Sheffield Utd relegated
 - [https://japantoday.com/category/sports/liverpool-premier-league-title-hopes-suffer-blow-sheffield-utd-relegated](https://japantoday.com/category/sports/liverpool-premier-league-title-hopes-suffer-blow-sheffield-utd-relegated)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:36:37+00:00

Liverpool's fading Premier League title hopes were dealt a near-fatal blow on Saturday as West Ham rescued a draw against Jurgen Klopp's men while Sheffield United dropped through…

## Retrial of Harvey Weinstein unlikely to occur soon, if ever, experts say
 - [https://japantoday.com/category/entertainment/retrial-of-harvey-weinstein-unlikely-to-occur-soon-if-ever-experts-say](https://japantoday.com/category/entertainment/retrial-of-harvey-weinstein-unlikely-to-occur-soon-if-ever-experts-say)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:36:07+00:00

The retrial in New York of Harvey Weinstein — whose moviemaking prowess once wowed Hollywood — won’t be coming to a courtroom anytime soon, if ever, legal experts…

## Star K-pop producer causes online stir after lashing out at industry bosses
 - [https://japantoday.com/category/entertainment/star-k-pop-producer-causes-online-stir-after-lashing-out-at-industry-bosses](https://japantoday.com/category/entertainment/star-k-pop-producer-causes-online-stir-after-lashing-out-at-industry-bosses)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:35:19+00:00

The creative director behind the girl band NewJeans has found online fame after a tearful, profanity-laced news conference in which she slammed some of K-pop's most powerful executives…

## 66-year-old man arrested for stealing woman’s clothes from her house
 - [https://japantoday.com/category/crime/66-year-old-man-arrested-for-stealing-woman%E2%80%99s-underwear-clothes-from-her-house](https://japantoday.com/category/crime/66-year-old-man-arrested-for-stealing-woman%E2%80%99s-underwear-clothes-from-her-house)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:34:47+00:00

Police in Tokyo have arrested a 66-year-old man on suspicion of breaking and entering and stealing a woman’s underwear, clothes and other items from her house while she…

## 30 years since apartheid ended, South Africa's celebrations are set against growing discontent
 - [https://japantoday.com/category/world/it%27s-30-years-since-apartheid-ended.-south-africa%27s-celebrations-are-set-against-growing-discontent](https://japantoday.com/category/world/it%27s-30-years-since-apartheid-ended.-south-africa%27s-celebrations-are-set-against-growing-discontent)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:32:54+00:00

South Africa marked 30 years since the end of apartheid and the birth of its democracy with a ceremony in the capital Saturday that included a 21-gun salute…

## 20 Cambodian soldiers killed in ammunition explosion at military base
 - [https://japantoday.com/category/world/20-cambodian-soldiers-killed-in-ammunition-explosion-at-a-military-base](https://japantoday.com/category/world/20-cambodian-soldiers-killed-in-ammunition-explosion-at-a-military-base)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:32:44+00:00

An ammunition explosion at a base in southwestern Cambodia on Saturday afternoon killed 20 soldiers and wounded several others, Prime Minister Hun Manet said.
Hun Manet said in…

## As EU election campaigns kick off in Germany, the Ukraine war, rise of far right are dominant themes
 - [https://japantoday.com/category/world/as-eu-election-campaigns-kick-off-in-germany-the-ukraine-war-rise-of-far-right-are-dominant-themes](https://japantoday.com/category/world/as-eu-election-campaigns-kick-off-in-germany-the-ukraine-war-rise-of-far-right-are-dominant-themes)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:32:36+00:00

Several German parties on Saturday kicked off their campaigns for the election of the European Parliament in June with a focus on issues such as the war in…

## Russia arrests another suspect in concert hall attack that killed 144
 - [https://japantoday.com/category/world/russia-arrests-another-suspect-in-the-concert-hall-attack-that-killed-144](https://japantoday.com/category/world/russia-arrests-another-suspect-in-the-concert-hall-attack-that-killed-144)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:32:28+00:00

A Moscow court has detained another suspect as an accomplice in the attack by gunmen on a suburban Moscow concert hall that killed 144 people in March, the…

## Yemen's Houthi rebels claim downing of U.S. Reaper drone, release footage showing wreckage of aircraft
 - [https://japantoday.com/category/world/yemen%27s-houthi-rebels-claim-downing-us-reaper-drone-release-footage-showing-wreckage-of-aircraft](https://japantoday.com/category/world/yemen%27s-houthi-rebels-claim-downing-us-reaper-drone-release-footage-showing-wreckage-of-aircraft)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:32:15+00:00

Yemen's Houthi rebels on Saturday claimed shooting down another of the U.S. military's MQ-9 Reaper drones, airing footage of parts that corresponded to known pieces of the unmanned…

## Hamas reviewing Israeli proposal for cease-fire in Gaza, as a planned Rafah offensive looms
 - [https://japantoday.com/category/world/hamas-is-reviewing-an-israeli-proposal-for-a-cease-fire-in-gaza-as-possible-rafah-offensive-looms](https://japantoday.com/category/world/hamas-is-reviewing-an-israeli-proposal-for-a-cease-fire-in-gaza-as-possible-rafah-offensive-looms)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:32:02+00:00

Hamas said Saturday it was reviewing a new Israeli proposal for a cease-fire in Gaza, as Egypt intensified efforts to broker a deal to end the months-long war…

## Police make arrests, clear pro-Palestinian camps at two U.S. universities
 - [https://japantoday.com/category/world/police-detain-100-as-pro-palestinian-camp-cleared-at-us-university](https://japantoday.com/category/world/police-detain-100-as-pro-palestinian-camp-cleared-at-us-university)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:31:50+00:00

Police detained more than 150 people while clearing pro-Palestinian encampments at two U.S. universities Saturday, in the latest campus clashes triggered by protests over Israel's war against Hamas.…

## Russian missiles pound power plants in central and western Ukraine
 - [https://japantoday.com/category/world/russian-missiles-pound-power-plants-in-central-and-western-ukraine1](https://japantoday.com/category/world/russian-missiles-pound-power-plants-in-central-and-western-ukraine1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:31:31+00:00

Russian missiles pounded power facilities in central and western Ukraine on Saturday, increasing pressure on the ailing energy system as the country faces a shortage of air defences…

## Godzilla projection mapping
 - [https://japantoday.com/category/picture-of-the-day/godzilla-projection-mapping](https://japantoday.com/category/picture-of-the-day/godzilla-projection-mapping)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T21:11:49+00:00

A Godzilla projection mapping display is shown on the surface of the Tokyo Metropolitan Government building Saturday night, to mark the 70th anniversary of his birth, as a…

## Japan Airlines cancels flight after captain gets drunk at U.S. hotel
 - [https://japantoday.com/category/national/japan-airlines-cancels-flight-as-captain-drunk-at-u.s.-hotel](https://japantoday.com/category/national/japan-airlines-cancels-flight-as-captain-drunk-at-u.s.-hotel)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T07:16:51+00:00

Japan Airlines Co said Friday it recently canceled a flight from Dallas to Tokyo after the 49-year-old captain engaged in disruptive behavior while drunk at his hotel in…

## Emperor, empress to visit Britain as state guests in June
 - [https://japantoday.com/category/national/japan-imperial-couple-to-visit-britain-as-state-guests-in-june](https://japantoday.com/category/national/japan-imperial-couple-to-visit-britain-as-state-guests-in-june)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T07:16:33+00:00

Emperor Naruhito and Empress Masako will visit Britain as state guests in late June, the Imperial Household Agency said Saturday, marking the first state visit by a sitting…

## Golden Week holidays start amid post-COVID tourism boom, weak yen
 - [https://japantoday.com/category/national/Golden-Week-holidays-start-amid-post-COVID-tourism-boom-weak-yen](https://japantoday.com/category/national/Golden-Week-holidays-start-amid-post-COVID-tourism-boom-weak-yen)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T07:16:15+00:00

Japan's Golden Week holidays started Saturday, with train stations and airports across the country crowded with tourists amid easing fears of COVID-19, while the yen's sharp fall against…

## Thousands rally in Australian capitals to demand gender violence justice
 - [https://japantoday.com/category/world/thousands-rally-in-australian-capitals-to-demand-gender-violence-justice](https://japantoday.com/category/world/thousands-rally-in-australian-capitals-to-demand-gender-violence-justice)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T05:42:21+00:00

Violence against women is an &quot;epidemic&quot; in Australia, Prime Minister Anthony Albanese said on Saturday, as thousands attended rallies in Sydney and other major Australian cities urging tougher…

## Hamas studying new Israeli truce proposal as mediators seek to revive talks
 - [https://japantoday.com/category/world/hamas-studying-new-israeli-truce-proposal-as-mediators-seek-to-revive-talks](https://japantoday.com/category/world/hamas-studying-new-israeli-truce-proposal-as-mediators-seek-to-revive-talks)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T04:26:34+00:00

Hamas said it was studying on Saturday the latest Israeli counterproposal regarding a potential ceasefire in Gaza, a day after a delegation from mediator Egypt reportedly arrived in…

## Ohtani responds to Toronto boos by hitting 7th homer as Dodgers beat Blue Jays 12-2
 - [https://japantoday.com/category/sports/shohei-ohtani-responds-to-toronto-boos-by-hitting-7th-homer-as-the-dodgers-beat-the-blue-jays-12-2](https://japantoday.com/category/sports/shohei-ohtani-responds-to-toronto-boos-by-hitting-7th-homer-as-the-dodgers-beat-the-blue-jays-12-2)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T03:35:05+00:00

Shohei Ohtani responded to boos from the Toronto crowd by hitting his seventh home run, Max Muncy and Will Smith also went deep and the Los Angeles Dodgers…

## Imanaga continues impressive MLB start, raising record to 4-0 as Cubs beat Red Sox 7-1
 - [https://japantoday.com/category/sports/shota-imanaga-continues-impressive-mlb-start-raising-record-to-4-0-as-cubs-beat-red-sox-7-1](https://japantoday.com/category/sports/shota-imanaga-continues-impressive-mlb-start-raising-record-to-4-0-as-cubs-beat-red-sox-7-1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T02:50:44+00:00

Shota Imanaga continued an impressive start to his major league career by pitching one-run ball into the seventh inning to lead the Chicago Cubs to a 7-1 victory…

## Leicester promoted to Premier League as Leeds crash
 - [https://japantoday.com/category/sports/leicester-promoted-to-premier-league-as-leeds-crash](https://japantoday.com/category/sports/leicester-promoted-to-premier-league-as-leeds-crash)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-04-27T00:51:00+00:00

Leicester City were promoted to the Premier League on Friday after rivals Leeds United crashed to a shock 4-0 defeat at Queens Park Rangers.
The result leaves Leicester…

