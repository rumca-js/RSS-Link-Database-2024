# Source:EN World Tabletop RPG News & Reviews, URL:https://www.enworld.org/ewr-porta/index.rss, language:en

## Full Drink Menu To Make Taverns Memorable
 - [https://www.enworld.org/threads/full-drink-menu-to-make-taverns-memorable.703913](https://www.enworld.org/threads/full-drink-menu-to-make-taverns-memorable.703913)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-04-27T20:11:00+00:00

<div class="bbWrapper">Put something else besides whiskey on the bar, whether that's lively quicksilver mead, tasty scumple, thimblebrew microbrew, or something else.</div>

## Parsley Turns Classic Adventure Games Into Fun For Everyone
 - [https://www.enworld.org/threads/parsley-turns-classic-adventure-games-into-fun-for-everyone.703542](https://www.enworld.org/threads/parsley-turns-classic-adventure-games-into-fun-for-everyone.703542)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-04-27T09:34:00+00:00

<div class="bbWrapper">A new spin on a retro form of text adventure games.</div>

## Parsley Turns Classic Adventure Games Into Fun For Everyone
 - [https://www.enworld.org/threads/parsely-turns-classic-adventure-games-into-fun-for-everyone.703542](https://www.enworld.org/threads/parsely-turns-classic-adventure-games-into-fun-for-everyone.703542)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-04-27T09:34:00+00:00

<div class="bbWrapper">A new spin on a retro form of text adventure games.</div>

