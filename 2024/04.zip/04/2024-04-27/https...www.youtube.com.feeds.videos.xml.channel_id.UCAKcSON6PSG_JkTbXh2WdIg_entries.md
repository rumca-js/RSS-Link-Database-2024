# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Sid Sriram – Came Along (live for The Current)
 - [https://www.youtube.com/watch?v=LXdxqzrjIWM](https://www.youtube.com/watch?v=LXdxqzrjIWM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2024-04-27T02:00:07+00:00

“I'm a creature of habit,” Sid Sriram admits, “and I really get used to like a certain routine.”

That said, Sriram is not inflexible. In fact, he tends to embrace serendipity in his life, and it has served him well. In was, in fact, his embrace of serendipity that led him from his home in California to a successful career in India — and it’s also what led him to visit Minneapolis to work with producer Ryan Olson. This led to the album Sidharth, a collection of songs that let Sriram explore his many influences without boundaries, it led him to explore the meaning of his very name.

During a recent visit to The Current studio, Sriram played songs from Sidharth, and then sat down with host Ayisha Jaffer to discuss his life and his career so far. Watch and listen to "Came Along" above.

Musicians
Sid Sriram – vocals
Evan Slack – guitar

Credits 
Guest – @sidsrirammusic 
Host – Ayisha Jaffer
Producer – Derrick Stevens
Video and Audio – Eric Romani
Camera Operators – Megan Lundberg, Nikhil

