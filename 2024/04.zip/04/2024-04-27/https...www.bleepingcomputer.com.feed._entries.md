# Source:BleepingComputer, URL:https://www.bleepingcomputer.com/feed/, language:en-US

## Japanese police create fake support scam payment cards to warn victims
 - [https://www.bleepingcomputer.com/news/security/japanese-police-create-fake-support-scam-payment-cards-to-warn-victims](https://www.bleepingcomputer.com/news/security/japanese-police-create-fake-support-scam-payment-cards-to-warn-victims)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2024-04-27T17:11:02+00:00

Japanese police placed dummy payment cards in convenience stores to protect the elderly targeted by tech support scams or unpaid money fraud. [...]

## Okta warns of "unprecedented" credential stuffing attacks on customers
 - [https://www.bleepingcomputer.com/news/security/okta-warns-of-unprecedented-credential-stuffing-attacks-on-customers](https://www.bleepingcomputer.com/news/security/okta-warns-of-unprecedented-credential-stuffing-attacks-on-customers)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2024-04-27T14:55:26+00:00

Okta warns of an "unprecedented" spike in credential stuffing attacks targeting its identity and access management solutions, with some customer accounts breached in the attacks. [...]

