# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## AMD makes older PCs more upgradeable once again
 - [https://www.digitaltrends.com/computing/amd-new-ryzen-5000-ryzen-8000-cpus-announced](https://www.digitaltrends.com/computing/amd-new-ryzen-5000-ryzen-8000-cpus-announced)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-04-27T00:43:20.808809+00:00

AMD just unveiled several new processors during an event in China, and owners of AM4 motherboards might be happy.

