# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## How 1,200-Year-Old Keris Daggers Tradition Is Fighting To Survive | Still Standing
 - [https://www.youtube.com/watch?v=juZryA0Y5C0](https://www.youtube.com/watch?v=juZryA0Y5C0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2024-04-27T15:00:38+00:00

Keris daggers, used as deadly weapons centuries ago, are now collector's items and heirlooms in Indonesia passed down from generation to generation. Believed to have magical powers, these daggers are forged by empus, masters of their craft, and some take months to complete because of the rituals and time-consuming steps involved. But the number of empus in the country is dwindling, and the government is trying to get more young people involved in the dying art form. A new keris culture study program was established at the Indonesian Institute of the Arts, Surakarta, and one of the country's most famous empus, Subandi Suponingrat, was recruited to help train new recruits — including his own son.    

MORE STILL STANDING VIDEOS:
12 Fascinating Jobs Done By Women Around The World | Still Standing | Business Insider Marathon
https://www.youtube.com/watch?v=ZTThCI8WsOY
How One Of The Oldest Forms Of BBQ Is Preserved By One Mayan Chef | Still Standing
https://www.youtube.com/watch?v=KFfBh1P

