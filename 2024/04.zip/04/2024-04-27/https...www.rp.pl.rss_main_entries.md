# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Przerwana seria Bartosza Zmarzlika. Grand Prix Chorwacji dla Jacka Holdera
 - [https://sport.rp.pl/zuzel/art40266271-przerwana-seria-bartosza-zmarzlika-grand-prix-chorwacji-dla-jacka-holdera](https://sport.rp.pl/zuzel/art40266271-przerwana-seria-bartosza-zmarzlika-grand-prix-chorwacji-dla-jacka-holdera)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T20:14:00+00:00

Bartosz Zmarzlik bez trzeciej z rzędu wygranej w Grand Prix Chorwacji. W miejscowości Donji Kraljevec na inaugurację tegorocznego cyklu zwyciężył Australijczyk Jack Holder.

## Nowy Kylian Mbappe pilnie poszukiwany. Lamine Yamal na celowniku Paris Saint-Germain
 - [https://sport.rp.pl/pilka-nozna/art40266191-nowy-kylian-mbappe-pilnie-poszukiwany-lamine-yamal-na-celowniku-paris-saint-germain](https://sport.rp.pl/pilka-nozna/art40266191-nowy-kylian-mbappe-pilnie-poszukiwany-lamine-yamal-na-celowniku-paris-saint-germain)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T19:45:42+00:00

Paris Saint-Germain pogodziło się z odejściem Kyliana Mbappe i próbuje znaleźć następcę. Wśród kandydatów jest Lamine Yamal, za którego Francuzi chcą zapłacić 200 mln euro.

## Święto szachów i hitowe transfery w Katowicach
 - [https://sport.rp.pl/inne-sporty/art40266181-swieto-szachow-i-hitowe-transfery-w-katowicach](https://sport.rp.pl/inne-sporty/art40266181-swieto-szachow-i-hitowe-transfery-w-katowicach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T19:41:23+00:00

Blisko tysiąc uczestników rywalizuje w turniejach XI Festiwalu Szachowego. Katowice na trzy dni stały się dzięki temu europejską stolicą królewskiej gry.

## Nerwy, przepychanki, kłótnie: Zawiercie nie rezygnuje z marzeń
 - [https://sport.rp.pl/siatkowka/art40266161-nerwy-przepychanki-klotnie-zawiercie-nie-rezygnuje-z-marzen](https://sport.rp.pl/siatkowka/art40266161-nerwy-przepychanki-klotnie-zawiercie-nie-rezygnuje-z-marzen)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T18:53:44+00:00

W drugim meczu finału Aluron CMC Warta Zawiercie pokonało 3:1 Jastrzębski Węgiel. O tytule mistrzów Polski zadecyduje niedzielny mecz. Gospodarzem będzie Jastrzębski Węgiel.

## Ukraińskie wojsko dementuje doniesienia mediów o czołgach Abrams
 - [https://www.rp.pl/konflikty-zbrojne/art40266131-ukrainskie-wojsko-dementuje-doniesienia-mediow-o-czolgach-abrams](https://www.rp.pl/konflikty-zbrojne/art40266131-ukrainskie-wojsko-dementuje-doniesienia-mediow-o-czolgach-abrams)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T18:04:50+00:00

Ukraińska 47. Oddzielna Brygada Zmechanizowana odrzuciła doniesienia Associated Press (AP), z których wynikało, że siły ukraińskie wycofały z frontu dostarczone przez USA czołgi Abrams.

## Problemy z Teslą Cybertruck. Wstrzymana produkcja przez... mydło
 - [https://moto.rp.pl/tu-i-teraz/art40265921-problemy-z-tesla-cybertruck-wstrzymana-produkcja-przez-mydlo](https://moto.rp.pl/tu-i-teraz/art40265921-problemy-z-tesla-cybertruck-wstrzymana-produkcja-przez-mydlo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T16:23:51+00:00

Pedał gazu w Tesli Cybertruck, kontrowersyjnie wyglądającym elektrycznym pick-upie może ulec zablokowaniu, a dokładniej utknąć pod tapicerką. Departament Transportu USA postanowił wezwać do warsztatu wszystkie wyprodukowane do tej pory egzemplarze auta.

## W niedzielę, 28 kwietnia, sklepy otwarte. Okazja do zaopatrzenia się na majówkę
 - [https://www.rp.pl/handel/art40265961-w-niedziele-28-kwietnia-sklepy-otwarte-okazja-do-zaopatrzenia-sie-na-majowke](https://www.rp.pl/handel/art40265961-w-niedziele-28-kwietnia-sklepy-otwarte-okazja-do-zaopatrzenia-sie-na-majowke)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T15:37:00+00:00

W najbliższą niedzielę Polacy będą mogli uzupełnić zapasy na majowe spotkania przy grillu. To dlatego, że zakaz handlu nie obowiązuje w ostatnią niedzielę przypadającą w styczniu, kwietniu, czerwcu i sierpniu, niedzielę bezpośrednio poprzedzającą pierwszy dzień Wielkanocy oraz w kolejne dwie niedziele poprzedzające pierwszy dzień Bożego Narodzenia.

## Ukraińcy stworzyli niezwykły okręt podwodny w technologii stealth. Rosja ma problem
 - [https://cyfrowa.rp.pl/technologie/art40265951-ukraincy-stworzyli-niezwykly-okret-podwodny-w-technologii-stealth-rosja-ma-problem](https://cyfrowa.rp.pl/technologie/art40265951-ukraincy-stworzyli-niezwykly-okret-podwodny-w-technologii-stealth-rosja-ma-problem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T15:23:00+00:00

Przypominający mantę i trudny do wykrycia Kronos jest w stanie wejść pod wodą w 180-stopniowy zakręt z pełną prędkością i zaatakować wrogi okręt torpedami lub podczepić miny.

## Nowy model Bugatti będzie napędzany 16-cylindrową hybrydą o mocy 1800 KM
 - [https://moto.rp.pl/samochod-jutra/art40265691-nowy-model-bugatti-bedzie-napedzany-16-cylindrowa-hybryda-o-mocy-1800-km](https://moto.rp.pl/samochod-jutra/art40265691-nowy-model-bugatti-bedzie-napedzany-16-cylindrowa-hybryda-o-mocy-1800-km)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T14:47:24+00:00

Bugatti chce wkrótce przedstawić następcę modelu Chiron. Na pierwszych zdjęciach pokazano póki co wysokoobrotowy, wolnossący silnik V16. Teraz Mate Rimac, dyrektor generalny marki zdradza kilka nowych szczegółów.

## Dramatyczny koniec poszukiwań nurka GROM na Bałtyku. Wojsko odnalazło ciało
 - [https://www.rp.pl/wojsko/art40265851-dramatyczny-koniec-poszukiwan-nurka-grom-na-baltyku-wojsko-odnalazlo-cialo](https://www.rp.pl/wojsko/art40265851-dramatyczny-koniec-poszukiwan-nurka-grom-na-baltyku-wojsko-odnalazlo-cialo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T14:42:33+00:00

Wojsko odnalazło ciało nurka GROMu, który zaginął w środę podczas ćwiczeń na Morzu Bałtyckim.

## Derby Mankinka - tragiczne losy piłkarza Lecha Poznań z Zambii. Zginął w katastrofie
 - [https://www.rp.pl/plus-minus/art40256601-derby-mankinka-tragiczne-losy-pilkarza-lecha-poznan-z-zambii-zginal-w-katastrofie](https://www.rp.pl/plus-minus/art40256601-derby-mankinka-tragiczne-losy-pilkarza-lecha-poznan-z-zambii-zginal-w-katastrofie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T14:37:50+00:00

Derby Mankinka, czyli pierwszy czarnoskóry piłkarski mistrz Polski, 27 kwietnia 1993 roku zginął w katastrofie lotniczej z reprezentacją Zambii na pokładzie. Czy ta historia mogła się potoczyć inaczej?

## „Nie chcemy polexitu, tylko reformy Unii Europejskiej”. Konwencja wyborcza PiS
 - [https://www.rp.pl/polityka/art40265671-nie-chcemy-polexitu-tylko-reformy-unii-europejskiej-konwencja-wyborcza-pis](https://www.rp.pl/polityka/art40265671-nie-chcemy-polexitu-tylko-reformy-unii-europejskiej-konwencja-wyborcza-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T14:08:54+00:00

To właśnie my, konserwatyści, wygramy w Europie – zapewniali uczestnicy konwencji Prawa i Sprawiedliwości przed wyborami do Parlamentu Europejskiego.

## Krystyna Janda na Woronicza w Teatrze TV
 - [https://www.rp.pl/teatr/art40265401-krystyna-janda-na-woronicza-w-teatrze-tv](https://www.rp.pl/teatr/art40265401-krystyna-janda-na-woronicza-w-teatrze-tv)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T13:22:46+00:00

Pięć premier w maju, w tym nagradzany "1989", spektakle z Krystyną Jandą i Jerzym Radziwiłowiczem, zapowiada nowa dyrekcja Teatru TV. Wśród nich nie będzie ani jednego spektaklu powstałego specjalnie na potrzeby telewizyjnej sceny, co było specjalnością Teatru TV.

## Berliner Zeitung: PiS zrobi z Sikorskiego rosyjskiego agenta
 - [https://www.rp.pl/polityka/art40265641-berliner-zeitung-pis-zrobi-z-sikorskiego-rosyjskiego-agenta](https://www.rp.pl/polityka/art40265641-berliner-zeitung-pis-zrobi-z-sikorskiego-rosyjskiego-agenta)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T12:38:00+00:00

Pierwsze expose ministra spraw zagranicznych Radosława Sikorskiego spotkało się z zainteresowaniem niemieckich mediów. O wystąpieniu szefa polskiej dyplomacji w Sejmie pisze w sobotę „Berliner Zeitung”.

## Tor wodny z i do portu w Baltimore odblokowany
 - [https://www.rp.pl/transport/art40265621-tor-wodny-z-i-do-portu-w-baltimore-odblokowany](https://www.rp.pl/transport/art40265621-tor-wodny-z-i-do-portu-w-baltimore-odblokowany)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T12:29:00+00:00

Pierwsze cztery statki handlowe opuściły port w Baltimore, gdzie zawalił się most, korzystając z nowego tymczasowego szlaku o szerokości 300 m i głębokości 11 m.

## Piotr Arak: Po 20 latach w UE musimy nauczyć się budować koalicje
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art40253591-piotr-arak-po-20-latach-w-ue-musimy-nauczyc-sie-budowac-koalicje](https://www.rp.pl/opinie-polityczno-spoleczne/art40253591-piotr-arak-po-20-latach-w-ue-musimy-nauczyc-sie-budowac-koalicje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T12:13:31+00:00

„Unia to też my” – to nie tylko stwierdzenie faktu naszego członkostwa. To przypomnienie, że mamy prawo i obowiązek kształtować UE tak, aby odpowiadała naszym wspólnym interesom, ideom i aspiracjom. To zrozumienie, że jesteśmy członkiem, któremu mityczna Bruksela nic nie nakazuje, ale że braliśmy udział w procesie decyzyjnym, choć jego efekty nie są idealne.

## Rada ministrów na śmieciówkach. Jak zarabiali członkowie rządu w zeszłym roku?
 - [https://www.rp.pl/polityka/art40265581-rada-ministrow-na-smieciowkach-jak-zarabiali-czlonkowie-rzadu-w-zeszlym-roku](https://www.rp.pl/polityka/art40265581-rada-ministrow-na-smieciowkach-jak-zarabiali-czlonkowie-rzadu-w-zeszlym-roku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T11:56:31+00:00

Jak wynika z oświadczeń majątkowych członków rządu, w zeszłym roku utrzymywali się oni głównie z uposażeń i diet poselskich, prac dorywczych na umowę-zlecenie oraz wynajmu mieszkań. Wśród najlepiej zarabiających w rządzie znaleźli się emeryci.

## Bezrobocie w Niemczech rośnie, we Francji jest już wysokie, ale ma zmaleć
 - [https://www.rp.pl/gospodarka/art40265571-bezrobocie-w-niemczech-rosnie-we-francji-jest-juz-wysokie-ale-ma-zmalec](https://www.rp.pl/gospodarka/art40265571-bezrobocie-w-niemczech-rosnie-we-francji-jest-juz-wysokie-ale-ma-zmalec)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T11:39:00+00:00

Bezrobocie w Niemczech najwyższe od 2015 r. We Francji stabilizacja na poziomie 7,4 proc., ale rośnie wśród młodych, zmalało natomiast wśród seniorów. Firmy nie kwapią się z zatrudnianiem. Za to niemieccy konsumenci bardzo optymistycznie oceniają perspektywy swych dochodów — wynika z ankiety instytutów GfK i NIM dotyczącej nastrojów w maju. A brytyjskich są najlepsze od 2 lat.

## Słynny artykuł o zniesławieniu ma zniknąć z kodeksu karnego
 - [https://www.rp.pl/prawo-karne/art40265531-slynny-artykul-o-znieslawieniu-ma-zniknac-z-kodeksu-karnego](https://www.rp.pl/prawo-karne/art40265531-slynny-artykul-o-znieslawieniu-ma-zniknac-z-kodeksu-karnego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:56:10+00:00

Minister sprawiedliwości Adam Bodnar zapowiedział, iż jego resort podejmie kroki w kierunku zniesienia przepisów karnych dotyczących zniesławienia, czyli art. 212 kodeksu karnego.

## Wisła Kraków i rwący nurt pierwszej ligi. Droga do Ekstraklasy daleka
 - [https://sport.rp.pl/pilka-nozna/art40255531-wisla-krakow-i-rwacy-nurt-pierwszej-ligi-droga-do-ekstraklasy-daleka](https://sport.rp.pl/pilka-nozna/art40255531-wisla-krakow-i-rwacy-nurt-pierwszej-ligi-droga-do-ekstraklasy-daleka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:49:11+00:00

Trener Wisły Kraków Albert Rude tłumaczy, że jego piłkarze są zmęczeni, choć w dwa miesiące rozegrali tylko trzynaście meczów. Szanse na bezpośredni awans do Ekstraklasy Biała Gwiazda ma już tylko matematyczne.

## Magnus Carlsen wraca do Polski. Będzie gwiazdą turnieju w Warszawie
 - [https://sport.rp.pl/inne-sporty/art40252331-magnus-carlsen-wraca-do-polski-bedzie-gwiazda-turnieju-w-warszawie](https://sport.rp.pl/inne-sporty/art40252331-magnus-carlsen-wraca-do-polski-bedzie-gwiazda-turnieju-w-warszawie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:42:37+00:00

Magnus Carlsen będzie największą gwiazdą turnieju Superbet Rapid & Blitz Poland, który w dniach 8-12 maja ugości Centrum Konferencyjnym POLIN w Warszawie.

## Chorwacja: Przestawiamy turystykę na zrównoważone tory
 - [https://turystyka.rp.pl/popularne-trendy/art40265431-chorwacja-przestawiamy-turystyke-na-zrownowazone-tory](https://turystyka.rp.pl/popularne-trendy/art40265431-chorwacja-przestawiamy-turystyke-na-zrownowazone-tory)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:39:28+00:00

Chcemy wypracować wizerunek kraju zrównoważonego, dbającego o swoje zasoby, który kojarzy się z wysoką jakością. To wielkie zadanie dla chorwackiej turystyki - mówi dyrektor Chorwackiej Wspólnoty Turystycznej Kristjan Staničić.

## Chorwacja: Przestawiamy turystykę na zrównoważone tory. Celem - wysoka jakość
 - [https://turystyka.rp.pl/popularne-trendy/art40265431-chorwacja-przestawiamy-turystyke-na-zrownowazone-tory-celem-wysoka-jakosc](https://turystyka.rp.pl/popularne-trendy/art40265431-chorwacja-przestawiamy-turystyke-na-zrownowazone-tory-celem-wysoka-jakosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:39:28+00:00

Chcemy wypracować wizerunek kraju zrównoważonego, dbającego o swoje zasoby, który kojarzy się z wysoką jakością. To wielkie zadanie dla chorwackiej turystyki - mówi dyrektor Chorwackiej Wspólnoty Turystycznej Kristjan Staničić.

## WTA Madryt. Iga Świątek zagrała koncert. Sprinterski awans do 1/8 finału
 - [https://sport.rp.pl/tenis/art40255551-wta-madryt-iga-swiatek-zagrala-koncert-sprinterski-awans-do-1-8-finalu](https://sport.rp.pl/tenis/art40255551-wta-madryt-iga-swiatek-zagrala-koncert-sprinterski-awans-do-1-8-finalu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:37:16+00:00

Iga Świątek pokonała Soranę Cirsteę 6:1, 6:1 i awansowała do 1/8 finału turnieju w Madrycie. Sobotni mecz pokazał, że forma Polki rośnie. 22-latka z Raszyna znów może zostać w tym roku królową "mączki".

## Koniec wizyt w urzędzie. Samochód zarejestrujesz przez internet
 - [https://moto.rp.pl/prawo/art40265451-koniec-wizyt-w-urzedzie-samochod-zarejestrujesz-przez-internet](https://moto.rp.pl/prawo/art40265451-koniec-wizyt-w-urzedzie-samochod-zarejestrujesz-przez-internet)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:36:11+00:00

Rejestracja samochodów przez internet ma być łatwa i powszechnie dostępna, zarówno dla osób prywatnych, jak i dla firm leasingowych, salonów czy importerów. Niestety poczekamy na to jeszcze 2,5 roku.

## Kolejna polska restauracja z gwiazdką Michelin będzie na Pomorzu? Decyzja władz
 - [https://sukces.rp.pl/kuchnia/art40253481-kolejna-polska-restauracja-z-gwiazdka-michelin-bedzie-na-pomorzu-decyzja-wladz](https://sukces.rp.pl/kuchnia/art40253481-kolejna-polska-restauracja-z-gwiazdka-michelin-bedzie-na-pomorzu-decyzja-wladz)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:23:41+00:00

Już w tym roku na łamach przewodnika kulinarnego Michelin – najbardziej znanej tego typu publikacji na świecie – mogą się znaleźć restauracje z Pomorza. To efekt porozumienia Polskiej Organizacji Turystycznej i władz województwa pomorskiego z wydawcą przewodnika.

## „Tylko my możemy zatrzymać brunatne siły w Europie”. Konwencja wyborcza Lewicy
 - [https://www.rp.pl/polityka/art40265471-tylko-my-mozemy-zatrzymac-brunatne-sily-w-europie-konwencja-wyborcza-lewicy](https://www.rp.pl/polityka/art40265471-tylko-my-mozemy-zatrzymac-brunatne-sily-w-europie-konwencja-wyborcza-lewicy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:03:37+00:00

Europa dla Ciebie – pod takim hasłem wystartuje do eurowyborów Lewica. Jej działacze podczas konwencji programowej przekonywali, że warto na nich oddać głos.

## Infrastruktura gazowa Ukrainy zaatakowana. To także atak na unijny gaz
 - [https://energia.rp.pl/gaz/art40265441-infrastruktura-gazowa-ukrainy-zaatakowana-to-takze-atak-na-unijny-gaz](https://energia.rp.pl/gaz/art40265441-infrastruktura-gazowa-ukrainy-zaatakowana-to-takze-atak-na-unijny-gaz)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T10:02:00+00:00

Umowa na tranzyt rosyjskiego gazu przez Ukrainę wygasa za osiem miesięcy. Kreml nie ma już złudzeń, że da się ją przedłużyć. W sobotę nad ranem rosyjski agresor zaatakował magistrale gazowe i magazyny Ukrainy. Ataki były nieskuteczne.

## Artur Bartkiewicz: Wybory do Parlamentu Europejskiego. Dlaczego tym razem Lewicy miałoby się udać?
 - [https://www.rp.pl/publicystyka/art40265341-artur-bartkiewicz-wybory-do-parlamentu-europejskiego-dlaczego-tym-razem-lewicy-mialoby-sie-udac](https://www.rp.pl/publicystyka/art40265341-artur-bartkiewicz-wybory-do-parlamentu-europejskiego-dlaczego-tym-razem-lewicy-mialoby-sie-udac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T09:17:27+00:00

Tuż przed weekendową konwencją Lewicy Onet opublikował ranking zaufania do polityków, z którego wynikało, że ok. 40 proc. Polaków nie zna członków Lewicy zasiadających w rządzie - minister pracy Agnieszki Dziemianowicz-Bąk i wicepremiera Krzysztofa Gawkowskiego. To najlepszy dowód na to, że Lewica ma dziś poważny problem.

## Znaleziono szczątki kilkudziesięciu osób. To ofiary zbrodni niemieckich
 - [https://historia.rp.pl/historia-polski/art40265381-znaleziono-szczatki-kilkudziesieciu-osob-to-ofiary-zbrodni-niemieckich](https://historia.rp.pl/historia-polski/art40265381-znaleziono-szczatki-kilkudziesieciu-osob-to-ofiary-zbrodni-niemieckich)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T09:10:43+00:00

Pion śledczy IPN przeprowadził ekshumacje szczątków ofiar zbrodni niemieckich dokonanych w lutym 1940 roku. Pochowano ich w masowym grobie na leśnej polanie w pobliżu miejscowości Tury i Dąbrowice w powiecie kolskim.

## Karygodne błędy odpoczywania. Jak nie powinien wyglądać relaks?
 - [https://kobieta.rp.pl/styl-zycia/art40243311-karygodne-bledy-odpoczywania-jak-nie-powinien-wygladac-relaks](https://kobieta.rp.pl/styl-zycia/art40243311-karygodne-bledy-odpoczywania-jak-nie-powinien-wygladac-relaks)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T09:01:17+00:00

W czasach, gdy wolne dni stają się dobrem luksusowym i deficytowym, warto wiedzieć, ile dobrego robi dla organizmu lenistwo.

## Przemysław Prekiel: Krótka ławka Lewicy
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art40253731-przemyslaw-prekiel-krotka-lawka-lewicy](https://www.rp.pl/opinie-polityczno-spoleczne/art40253731-przemyslaw-prekiel-krotka-lawka-lewicy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T08:23:47+00:00

Zapowiedź współprzewodniczącego Nowej Lewicy Roberta Biedronia o tym, iż będzie zabiegał, aby na ich listach znaleźli się dwaj byli premierzy Marek Belka i Włodzimierz Cimoszewicz to wywieszenie białej flagi w europejskim wyścigu i potwierdzenie krótkiej ławki lewicowej formacji.

## Rosja i Iran mają sposoby na zachodnie sankcje
 - [https://www.rp.pl/polityka/art40265291-rosja-i-iran-maja-sposoby-na-zachodnie-sankcje](https://www.rp.pl/polityka/art40265291-rosja-i-iran-maja-sposoby-na-zachodnie-sankcje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T08:01:28+00:00

Od blisko 40 lat obowiązują sankcje przeciwko Iranowi, a na Rosję nałożono rekordową liczbę restrykcji w bardzo krótkim czasie. Efekt jest ograniczony, ale nie ma alternatywy wobec sankcji.

## Wypłata środków z rachunku PPK na wkład własny do kredytu hipotecznego
 - [https://www.rp.pl/praca-emerytury-i-renty/art40265241-wyplata-srodkow-z-rachunku-ppk-na-wklad-wlasny-do-kredytu-hipotecznego](https://www.rp.pl/praca-emerytury-i-renty/art40265241-wyplata-srodkow-z-rachunku-ppk-na-wklad-wlasny-do-kredytu-hipotecznego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T06:58:17+00:00

Uczestnik PPK, który nie ma jeszcze 45 lat, może złożyć wniosek o wypłatę środków z rachunku PPK na pokrycie wkładu własnego - wymaganego, aby otrzymać kredyt hipoteczny. Uczestnik może wypłacić na wkład własny nawet 100% środków, bez pomniejszeń, ale z obowiązkiem zwrotu na rachunek PPK.

## Marek Isański: Wybory kopertowe, czyli „prawo” państwa kontra prawa obywatela
 - [https://www.rp.pl/opinie-prawne/art40265231-marek-isanski-wybory-kopertowe-czyli-prawo-panstwa-kontra-prawa-obywatela](https://www.rp.pl/opinie-prawne/art40265231-marek-isanski-wybory-kopertowe-czyli-prawo-panstwa-kontra-prawa-obywatela)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T06:47:34+00:00

Tematem pracy Komisji Nadzwyczajnej ds. wyborów kopertowych jest wyjaśnienie zmarnowania prawie 100 mln zł pieniędzy obywateli. Jednak znaczenie ustaleń tej Komisji ma w rzeczywistości zupełnie inne cele. Obnażają one bowiem jak organy państwa lekceważą Konstytucję. Jak robią co chcą. Czyli jak niszczą państwo. Wybory kopertowe to jedynie wierzchołek góry lodowej.

## Powrót strat wojennych do Muzeum Zamkowego w Malborku
 - [https://www.rp.pl/kultura/art40265191-powrot-strat-wojennych-do-muzeum-zamkowego-w-malborku](https://www.rp.pl/kultura/art40265191-powrot-strat-wojennych-do-muzeum-zamkowego-w-malborku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T06:46:51+00:00

27 kwietnia przekazane zostaną dwa zabytkowe obiekty pochodzące z przedwojennych zbiorów Zamku: kwatera witrażowa i skrzydło ołtarzowe z dawnego kościoła NMP na Zamku Wysokim.

## Czy rodzina musi zapłacić za nas PIT? Oto, co mówią na temat przepisy
 - [https://www.rp.pl/podatki/art40265171-czy-rodzina-musi-zaplacic-za-nas-pit-oto-co-mowia-na-temat-przepisy](https://www.rp.pl/podatki/art40265171-czy-rodzina-musi-zaplacic-za-nas-pit-oto-co-mowia-na-temat-przepisy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T06:27:00+00:00

Osobą, która musi uregulować swoje zobowiązania wobec fiskusa, jest najczęściej sam podatnik. Zdarzają się jednak sytuacje, gdy za zobowiązania podatkowe odpowiadają osoby trzecie.

## Wybory samorządowe 2024. Niektórzy kandydaci w II turze walczyli tylko ze sobą
 - [https://regiony.rp.pl/z-regionow/art40265161-wybory-samorzadowe-2024-niektorzy-kandydaci-w-ii-turze-walczyli-tylko-ze-soba](https://regiony.rp.pl/z-regionow/art40265161-wybory-samorzadowe-2024-niektorzy-kandydaci-w-ii-turze-walczyli-tylko-ze-soba)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T06:10:13+00:00

W drugiej turze Jerzy Dorobek stoczył walkę sam ze sobą, bo kontrkandydat Jerzy Maciej Staniszewski zrezygnował z walki o fotel burmistrza Bodzanowa na Mazowszu. Jedyny kandydat wygrał w tym nietypowym pojedynku uzyskując 85 proc. poparcia. Takich gmin w Polsce było więcej.

## Sondaż: Broń atomowa USA w Polsce dzieli Polaków
 - [https://www.rp.pl/polityka/art40265141-sondaz-bron-atomowa-usa-w-polsce-dzieli-polakow](https://www.rp.pl/polityka/art40265141-sondaz-bron-atomowa-usa-w-polsce-dzieli-polakow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T05:48:47+00:00

"Jak ocenia Pani/Pan przedstawiony przez prezydenta Andrzeja Dudę pomysł, by w Polsce pojawiła się broń atomowa USA (w ramach programu Nuclear Sharing)?" - takie pytanie zadaliśmy uczestnikom sondażu SW Research dla rp.pl.

## Hekatomba małych partii. Pod nóż idą ugrupowania m.in. Kołodziejczaka, Piecha i „Jaszczura”
 - [https://www.rp.pl/polityka/art40253451-hekatomba-malych-partii-pod-noz-ida-ugrupowania-m-in-kolodziejczaka-piecha-i-jaszczura](https://www.rp.pl/polityka/art40253451-hekatomba-malych-partii-pod-noz-ida-ugrupowania-m-in-kolodziejczaka-piecha-i-jaszczura)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T05:22:26+00:00

Wskutek niezłożenia w terminie sprawozdań, zdelegalizowanych zostanie kilkanaście partii, z czego część jest lub była związana ze znanymi politykami i celebrytami.

## Wojna Rosji z Ukrainą. Dzień 794
 - [https://www.rp.pl/konflikty-zbrojne/art40264541-wojna-rosji-z-ukraina-dzien-794](https://www.rp.pl/konflikty-zbrojne/art40264541-wojna-rosji-z-ukraina-dzien-794)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-04-27T04:30:00+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę

