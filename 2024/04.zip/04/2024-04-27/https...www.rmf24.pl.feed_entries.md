# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Śmierć Nawalnego. Najnowsze doniesienia amerykańskiego wywiadu
 - [https://www.rmf24.pl/fakty/swiat/news-smierc-nawalnego-najnowsze-doniesienia-amerykanskiego-wywiad,nId,7477838](https://www.rmf24.pl/fakty/swiat/news-smierc-nawalnego-najnowsze-doniesienia-amerykanskiego-wywiad,nId,7477838)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T20:15:32+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-smierc-nawalnego-najnowsze-doniesienia-amerykanskiego-wywiad,nId,7477838"><img align="left" alt="Śmierć Nawalnego. Najnowsze doniesienia amerykańskiego wywiadu" src="https://interia-s.pluscdn.pl/smierc-nawalnego-najnowsze-doniesienia-amerykanskiego-wywiad/000J15F6AFA7558T-C307.jpg" /></a>Amerykańskie agencje wywiadowcze uważają, że Władimir Putin prawdopodobnie nie nakazał zamordowania w lutym przywódcy opozycji Aleksieja Nawalnego w kolonii karnej za kołem podbiegunowym - poinformował dziennik &quot;Wall Street Journal&quot;, cytowany przez portal Politico.</p><br clear="all" />

## Joachim Brudziński "jedynką" PiS w okręgu nr 13
 - [https://www.rmf24.pl/raporty/raport-eurowybory-2024/news-joachim-brudzinski-jedynka-pis-w-okregu-nr-13,nId,7477834](https://www.rmf24.pl/raporty/raport-eurowybory-2024/news-joachim-brudzinski-jedynka-pis-w-okregu-nr-13,nId,7477834)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T19:39:48+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-eurowybory-2024/news-joachim-brudzinski-jedynka-pis-w-okregu-nr-13,nId,7477834"><img align="left" alt="Joachim Brudziński &quot;jedynką&quot; PiS w okręgu nr 13" src="https://interia-s.pluscdn.pl/joachim-brudzinski-jedynka-pis-w-okregu-nr-13/000J15BYIUQ7SEMW-C307.jpg" /></a>PiS zarejestrowało kandydatów do PE z okręgu nr 13, czyli woj. zachodniopomorskiego i lubuskiego. Europoseł Joachim Brudziński został &quot;jedynką&quot; na liście, drugie miejsce zajęła Elżbieta Rafalska, trzecie Małgorzata Golińska, czwarty jest Jerzy Materna, a piąty Artur Szałabawka.</p><br clear="all" />

## Fałszywa zbiórka na pogrzeb mężczyzny podpalonego na łódzkim przystanku?
 - [https://www.rmf24.pl/regiony/lodz/news-falszywa-zbiorka-na-pogrzeb-mezczyzny-podpalonego-na-lodzkim,nId,7477832](https://www.rmf24.pl/regiony/lodz/news-falszywa-zbiorka-na-pogrzeb-mezczyzny-podpalonego-na-lodzkim,nId,7477832)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T19:08:42+00:00

<p><a href="https://www.rmf24.pl/regiony/lodz/news-falszywa-zbiorka-na-pogrzeb-mezczyzny-podpalonego-na-lodzkim,nId,7477832"><img align="left" alt="Fałszywa zbiórka na pogrzeb mężczyzny podpalonego na łódzkim przystanku? " src="https://interia-s.pluscdn.pl/falszywa-zbiorka-na-pogrzeb-mezczyzny-podpalonego-na-lodzkim/000J1594K9IW09AO-C307.jpg" /></a>Na jednym z portali internetowych zamieszczona została zbiórka na – jak podkreślano w opisie – &quot;godny pogrzeb&quot; 33-latka, który został podpalony na przystanku komunikacji miejskiej w Łodzi. Organizator &quot;akcji&quot; miał już nawet zebrać część pieniędzy. Jak się okazało, w opisie były jednak nieścisłości. Ogłoszenie zostało usunięte ze strony, a sprawą zajmuje się prokuratura.</p><br clear="all" />

## Pod nosem krajów UE Rosjanie przewożą statkami broń do Królewca
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-pod-nosem-krajow-ue-rosjanie-przewoza-statkami-bron-do-krole,nId,7477823](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-pod-nosem-krajow-ue-rosjanie-przewoza-statkami-bron-do-krole,nId,7477823)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T19:02:33+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-pod-nosem-krajow-ue-rosjanie-przewoza-statkami-bron-do-krole,nId,7477823"><img align="left" alt="Pod nosem krajów UE Rosjanie przewożą statkami broń do Królewca" src="https://interia-s.pluscdn.pl/pod-nosem-krajow-ue-rosjanie-przewoza-statkami-bron-do-krole/000J158XCCPII2QK-C307.jpg" /></a>Drwiąc z sankcji i śmiejąc się w twarz krajom wspierającym Ukrainę, Rosjanie wykorzystują flotę-widmo do transportu ropy naftowej i broni. Szlak morski, którym regularnie pływa kilka rosyjskich statków przebiega wzdłuż wybrzeży Unii Europejskiej.</p><br clear="all" />

## Japończycy zasłonią wulkan Fudżi. Turyści nie przestrzegali zasad
 - [https://www.rmf24.pl/fakty/swiat/news-japonczycy-zaslonia-wulkan-fudzi-turysci-nie-przestrzegali-z,nId,7477814](https://www.rmf24.pl/fakty/swiat/news-japonczycy-zaslonia-wulkan-fudzi-turysci-nie-przestrzegali-z,nId,7477814)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T17:49:50+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-japonczycy-zaslonia-wulkan-fudzi-turysci-nie-przestrzegali-z,nId,7477814"><img align="left" alt="Japończycy zasłonią wulkan Fudżi. Turyści nie przestrzegali zasad" src="https://interia-s.pluscdn.pl/japonczycy-zaslonia-wulkan-fudzi-turysci-nie-przestrzegali-z/000J153MDRRKITOY-C307.jpg" /></a>Władze miasta Fujikawaguchiko zirytowani zachowaniem turystów, zdecydowali się na radykalny krok. Wulkan Fudżi, święta góra Japończyków zostanie zasłonięta specjalnym ekranem. W najbardziej popularnym miejscu do fotografowania.</p><br clear="all" />

## Huti twierdzą, że zestrzelili amerykańskiego drona za 30 mln dolarów
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-huti-twierdza-ze-zestrzelili-amerykanskiego-drona-za-30-mln-,nId,7477805](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-huti-twierdza-ze-zestrzelili-amerykanskiego-drona-za-30-mln-,nId,7477805)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T17:11:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-huti-twierdza-ze-zestrzelili-amerykanskiego-drona-za-30-mln-,nId,7477805"><img align="left" alt="Huti twierdzą, że zestrzelili amerykańskiego drona za 30 mln dolarów" src="https://interia-s.pluscdn.pl/huti-twierdza-ze-zestrzelili-amerykanskiego-drona-za-30-mln/000J15112F0RSO14-C307.jpg" /></a>Huti z Jemenu zwiększają swoją aktywność. Rebelianci wystrzelili pociski w kierunku okrętów płynących na Morzu Czerwonym. Organizacja twierdzi też, że jej bojownikom udało się trafić amerykańskiego drona bojowego. USA przyznaje, że MQ-9 Reaper faktycznie rozbił się w Jemenie.</p><br clear="all" />

## Jemeńscy Huti twierdzą, że zestrzelili amerykańskiego reapera
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-jemenscy-huti-twierdza-ze-zestrzelili-amerykanskiego-reapera,nId,7477805](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-jemenscy-huti-twierdza-ze-zestrzelili-amerykanskiego-reapera,nId,7477805)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T17:11:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-jemenscy-huti-twierdza-ze-zestrzelili-amerykanskiego-reapera,nId,7477805"><img align="left" alt="Jemeńscy Huti twierdzą, że zestrzelili amerykańskiego reapera" src="https://interia-s.pluscdn.pl/jemenscy-huti-twierdza-ze-zestrzelili-amerykanskiego-reapera/000J15112F0RSO14-C307.jpg" /></a>Huti z Jemenu zwiększają swoją aktywność. Rebelianci wystrzelili pociski w kierunku okrętów płynących na Morzu Czerwonym. Organizacja twierdzi też, że jej bojownikom udało się trafić amerykańskiego drona bojowego. USA przyznaje, że MQ-9 Reaper faktycznie rozbił się w Jemenie.</p><br clear="all" />

## Proboszcz z Warszawy zatrzymany przez CBA. Jest reakcja kurii
 - [https://www.rmf24.pl/regiony/warszawa/news-proboszcz-z-warszawy-zatrzymany-przez-cba-jest-reakcja-kurii,nId,7477811](https://www.rmf24.pl/regiony/warszawa/news-proboszcz-z-warszawy-zatrzymany-przez-cba-jest-reakcja-kurii,nId,7477811)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T17:08:25+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-proboszcz-z-warszawy-zatrzymany-przez-cba-jest-reakcja-kurii,nId,7477811"><img align="left" alt="Proboszcz z Warszawy zatrzymany przez CBA. Jest reakcja kurii" src="https://interia-s.pluscdn.pl/proboszcz-z-warszawy-zatrzymany-przez-cba-jest-reakcja-kurii/000J1512K8ECKULD-C307.jpg" /></a>Zatrzymany przez CBA proboszcz parafii św. Faustyny w Warszawie został zawieszony w wykonywaniu obowiązków - poinformowano w oświadczeniu opublikowanym na stronie Diecezji Warszawsko-Praskiej. Jak podkreślono w oświadczeniu, do czasu wyjaśnienia sprawy zarządzanie parafią obejmie administrator.</p><br clear="all" />

## Harry Kane goni rekord Roberta Lewandowskiego
 - [https://www.rmf24.pl/sport/pilka-nozna/news-harry-kane-goni-rekord-roberta-lewandowskiego,nId,7477806](https://www.rmf24.pl/sport/pilka-nozna/news-harry-kane-goni-rekord-roberta-lewandowskiego,nId,7477806)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T16:42:37+00:00

<p><a href="https://www.rmf24.pl/sport/pilka-nozna/news-harry-kane-goni-rekord-roberta-lewandowskiego,nId,7477806"><img align="left" alt="Harry Kane goni rekord Roberta Lewandowskiego" src="https://interia-s.pluscdn.pl/harry-kane-goni-rekord-roberta-lewandowskiego/000J14Z43H6DF21W-C307.jpg" /></a>Bayern Monachium pokonał u siebie Eintracht Frankfurt 2:1 w 31. kolejce piłkarskiej ekstraklasy Niemiec. Obie bramki zdobył Anglik Harry Kane, który z 35 golami goni rekord sezonu Roberta Lewandowskiego (41). Czwarty w tabeli RB Lipsk wygrał z piątą Borussią Dortumund 4:1.</p><br clear="all" />

## Na majówkę w Beskidy. A jak w Beskidy, to rowerem
 - [https://www.rmf24.pl/regiony/news-na-majowke-w-beskidy-a-jak-w-beskidy-to-rowerem,nId,7477792](https://www.rmf24.pl/regiony/news-na-majowke-w-beskidy-a-jak-w-beskidy-to-rowerem,nId,7477792)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T16:10:47+00:00

<p><a href="https://www.rmf24.pl/regiony/news-na-majowke-w-beskidy-a-jak-w-beskidy-to-rowerem,nId,7477792"><img align="left" alt="Na majówkę w Beskidy. A jak w Beskidy, to rowerem" src="https://interia-s.pluscdn.pl/na-majowke-w-beskidy-a-jak-w-beskidy-to-rowerem/000J14UV7TH1M3JI-C307.jpg" /></a>Jedni ograniczają się do krótkich wędrówek, np. parkowymi alejkami wzdłuż Wisły. Są tacy, którzy np. wjeżdżają kolejką na pobliską Czantorię i schodzą szlakiem. Ale są i tacy, którzy planują nieco dłuższą podróż. Pogoda w Beskidach sprzyja turystyce.</p><br clear="all" />

## Kaczyński przestawił kandydata PiS na komisarza w Unii Europejskiej
 - [https://www.rmf24.pl/raporty/raport-eurowybory-2024/news-kaczynski-przestawil-kandydata-pis-na-komisarza-w-unii-europ,nId,7477786](https://www.rmf24.pl/raporty/raport-eurowybory-2024/news-kaczynski-przestawil-kandydata-pis-na-komisarza-w-unii-europ,nId,7477786)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T15:15:33+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-eurowybory-2024/news-kaczynski-przestawil-kandydata-pis-na-komisarza-w-unii-europ,nId,7477786"><img align="left" alt="Kaczyński przestawił kandydata PiS na komisarza w Unii Europejskiej" src="https://interia-s.pluscdn.pl/kaczynski-przestawil-kandydata-pis-na-komisarza-w-unii-europ/000J14QC0F4B9ARY-C307.jpg" /></a>&quot;Jacek Saryusz-Wolski jest naszym kandydatem na komisarza w Unii Europejskiej. Jest kompetentnym człowiekiem, ma bardzo silny charakter i mocny temperament&quot; - zapowiedział prezes PiS Jarosław Kaczyński na konwencji PiS w Warszawie.</p><br clear="all" />

## Wypadek kolumny wojskowej na A4. Ranni amerykańscy żołnierze
 - [https://www.rmf24.pl/regiony/wroclaw/news-wypadek-kolumny-wojskowej-na-a4-ranni-amerykanscy-zolnierze,nId,7477780](https://www.rmf24.pl/regiony/wroclaw/news-wypadek-kolumny-wojskowej-na-a4-ranni-amerykanscy-zolnierze,nId,7477780)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T14:49:03+00:00

<p><a href="https://www.rmf24.pl/regiony/wroclaw/news-wypadek-kolumny-wojskowej-na-a4-ranni-amerykanscy-zolnierze,nId,7477780"><img align="left" alt="Wypadek kolumny wojskowej na A4. Ranni amerykańscy żołnierze " src="https://interia-s.pluscdn.pl/wypadek-kolumny-wojskowej-na-a4-ranni-amerykanscy-zolnierze/000J14O8FIDCLWUI-C307.jpg" /></a>Trzech amerykańskich żołnierzy zostało rannych w wypadku, do którego doszło na autostradzie A4 pomiędzy węzłami Legnickie Pole a Legnica Wschód. Zderzyły się tam dwa pojazdy jadące w wojskowej kolumnie. </p><br clear="all" />

## Patrick Wilson w RMF FM: "Choć nie mam polskiej krwi, to kocham ten kraj"
 - [https://www.rmf24.pl/kultura/news-patrick-wilson-w-rmf-fm-choc-nie-mam-polskiej-krwi-to-kocham,nId,7477778](https://www.rmf24.pl/kultura/news-patrick-wilson-w-rmf-fm-choc-nie-mam-polskiej-krwi-to-kocham,nId,7477778)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T14:38:17+00:00

<p><a href="https://www.rmf24.pl/kultura/news-patrick-wilson-w-rmf-fm-choc-nie-mam-polskiej-krwi-to-kocham,nId,7477778"><img align="left" alt="Patrick Wilson w RMF FM: &quot;Choć nie mam polskiej krwi, to kocham ten kraj&quot;" src="https://interia-s.pluscdn.pl/patrick-wilson-w-rmf-fm-choc-nie-mam-polskiej-krwi-to-kocham/000J14O00QPETYD1-C307.jpg" /></a>Aktor Patrick Wilson odbierze wieczorem na festiwalu Mastercard Off Camera w Krakowie nagrodę &quot;Pod Prąd&quot;. Przyznawana jest artystom szczególnie zasłużonym dla niezależnego kina. Wilson umiejętnie łączy udział w widowiskowych filmach jak &quot;Aquaman&quot; z mniejszymi produkcjami, a także z pracą na Broadwayu i w kinie gatunkowym, w horrorze. &quot;Choć nie mam polskiej krwi, to kocham ten kraj&quot; - deklaruje w RMF FM Patrick Wilson.</p><br clear="all" />

## Patrick Wilson w RMF FM: "Choć nie mam polskiej krwi, to kocham ten kraj"
 - [https://www.rmf24.pl/regiony/krakow/news-patrick-wilson-w-rmf-fm-choc-nie-mam-polskiej-krwi-to-kocham,nId,7477778](https://www.rmf24.pl/regiony/krakow/news-patrick-wilson-w-rmf-fm-choc-nie-mam-polskiej-krwi-to-kocham,nId,7477778)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T14:38:17+00:00

<p><a href="https://www.rmf24.pl/regiony/krakow/news-patrick-wilson-w-rmf-fm-choc-nie-mam-polskiej-krwi-to-kocham,nId,7477778"><img align="left" alt="Patrick Wilson w RMF FM: &quot;Choć nie mam polskiej krwi, to kocham ten kraj&quot;" src="https://interia-s.pluscdn.pl/patrick-wilson-w-rmf-fm-choc-nie-mam-polskiej-krwi-to-kocham/000J14R6FRMUFJGP-C307.jpg" /></a>Aktor Patrick Wilson odbierze wieczorem na festiwalu Mastercard Off Camera w Krakowie nagrodę &quot;Pod Prąd&quot;. Przyznawana jest artystom szczególnie zasłużonym dla niezależnego kina. Wilson umiejętnie łączy udział w widowiskowych filmach jak &quot;Aquaman&quot; z mniejszymi produkcjami, a także z pracą na Broadwayu i w kinie gatunkowym, w horrorze. &quot;Choć nie mam polskiej krwi, to kocham ten kraj&quot; - deklaruje w RMF FM Patrick Wilson.</p><br clear="all" />

## Zełenski wyznaczył deadline Johnsonowi. Pomoc dla Ukrainy nadeszła w ostatniej chwili
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zelenski-wyznaczyl-deadline-johnsonowi-pomoc-dla-ukrainy-nad,nId,7477764](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zelenski-wyznaczyl-deadline-johnsonowi-pomoc-dla-ukrainy-nad,nId,7477764)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T14:35:44+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zelenski-wyznaczyl-deadline-johnsonowi-pomoc-dla-ukrainy-nad,nId,7477764"><img align="left" alt="Zełenski wyznaczył deadline Johnsonowi. Pomoc dla Ukrainy nadeszła w ostatniej chwili" src="https://interia-s.pluscdn.pl/zelenski-wyznaczyl-deadline-johnsonowi-pomoc-dla-ukrainy-nad/000J14ND0RXD3BAJ-C307.jpg" /></a>Rosjanie nasilają ataki na wschodzie Ukrainy. Siły Władimira Putina chcą zmaksymalizować zdobycze terytorialne, póki do Kijowa nie dotarła jeszcze pomoc z Zachodu. Tymczasem Politico ujawnia, że wsparcie amerykańskie dotrze na front w ostatniej chwili. W czasie grudniowej rozmowy ze spikerem Mike'iem Johnsonem Wołodymyr Zełenski podał termin, w którym Ukrainie skończą się zasoby do odpierania rosyjskiej nawałnicy.</p><br clear="all" />

## Do kiedy złożyć PIT za 2023 rok? Niedługo mija termin!
 - [https://www.rmf24.pl/ekonomia/news-do-kiedy-zlozyc-pit-za-2023-rok-niedlugo-mija-termin,nId,7477768](https://www.rmf24.pl/ekonomia/news-do-kiedy-zlozyc-pit-za-2023-rok-niedlugo-mija-termin,nId,7477768)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T13:58:27+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-do-kiedy-zlozyc-pit-za-2023-rok-niedlugo-mija-termin,nId,7477768"><img align="left" alt="Do kiedy złożyć PIT za 2023 rok? Niedługo mija termin! " src="https://interia-s.pluscdn.pl/do-kiedy-zlozyc-pit-za-2023-rok-niedlugo-mija-termin/000J14LPG0NBL2HB-C307.jpg" /></a>Do 30 kwietnia trzeba złożyć zeznania podatkowe PIT za 2023 r.. Najprostszą formą rozliczenia podatku - jak twierdzi Ministerstwo Finansów - jest usługa Twój e-PIT. Podatnicy złożyli już w ten sposób ponad 6,7 mln deklaracji. PIT można też złożyć przez system e-Deklaracje lub w formie papierowej.</p><br clear="all" />

## Odnaleziono ciało zaginionego żołnierza GROM
 - [https://www.rmf24.pl/fakty/polska/news-odnaleziono-cialo-zaginionego-zolnierza-grom,nId,7477753](https://www.rmf24.pl/fakty/polska/news-odnaleziono-cialo-zaginionego-zolnierza-grom,nId,7477753)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T12:55:01+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-odnaleziono-cialo-zaginionego-zolnierza-grom,nId,7477753"><img align="left" alt="Odnaleziono ciało zaginionego żołnierza GROM" src="https://interia-s.pluscdn.pl/odnaleziono-cialo-zaginionego-zolnierza-grom/000J13VRPXL8D6Q9-C307.jpg" /></a>Służby odnalazły ciało nurka, który zaginął 24 kwietnia. Żołnierz z jednostki wojskowej GROM nie wypłynął na powierzchnię w czasie ćwiczeń wojskowych niedaleko Westerplatte w Gdańsku.</p><br clear="all" />

## Turysta zaatakowany przez rekina zaledwie 10 metrów od brzegu
 - [https://www.rmf24.pl/fakty/swiat/news-turysta-zaatakowany-przez-rekina-zaledwie-10-metrow-od-brzeg,nId,7477736](https://www.rmf24.pl/fakty/swiat/news-turysta-zaatakowany-przez-rekina-zaledwie-10-metrow-od-brzeg,nId,7477736)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T12:14:27+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-turysta-zaatakowany-przez-rekina-zaledwie-10-metrow-od-brzeg,nId,7477736"><img align="left" alt="Turysta zaatakowany przez rekina zaledwie 10 metrów od brzegu" src="https://interia-s.pluscdn.pl/turysta-zaatakowany-przez-rekina-zaledwie-10-metrow-od-brzeg/000J13RYEQJGP7VS-C307.jpg" /></a>Brytyjski turysta wylądował w szpitalu z ciężkimi obrażeniami po ataku rekina na karaibskiej wyspie Tobago. Do ataku doszło zaledwie 10 metrów od brzegu. </p><br clear="all" />

## Kilkanaście tornad w jeden dzień. Przerażające nagrania z Ameryki [FILMY]
 - [https://www.rmf24.pl/fakty/swiat/news-kilkanascie-tornad-w-jeden-dzien-przerazajace-nagrania-z-ame,nId,7477660](https://www.rmf24.pl/fakty/swiat/news-kilkanascie-tornad-w-jeden-dzien-przerazajace-nagrania-z-ame,nId,7477660)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T12:01:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-kilkanascie-tornad-w-jeden-dzien-przerazajace-nagrania-z-ame,nId,7477660"><img align="left" alt="Kilkanaście tornad w jeden dzień. Przerażające nagrania z Ameryki [FILMY]" src="https://interia-s.pluscdn.pl/kilkanascie-tornad-w-jeden-dzien-przerazajace-nagrania-z-ame/000J13QLI3V545B9-C307.jpg" /></a>Co najmniej kilkanaście tornad, w tym jedno szerokie na ponad kilometr, ostrzeżenia najwyższego stopnia, dziesiątki zrównanych z ziemią domów i dramat wielu ludzi - tak wyglądał piątek w amerykańskich stanach Nebraska i Iowa. W związku z tym, że tornada wystąpiły w ciągu dnia, media społecznościowe zalały budzące grozę nagrania.</p><br clear="all" />

## Premier: Rosyjska rakieta spadła 15 km od naszej granicy
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-premier-rosyjska-rakieta-spadla-15-km-od-naszej-granicy,nId,7477721](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-premier-rosyjska-rakieta-spadla-15-km-od-naszej-granicy,nId,7477721)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T10:49:56+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-premier-rosyjska-rakieta-spadla-15-km-od-naszej-granicy,nId,7477721"><img align="left" alt="Premier: Rosyjska rakieta spadła 15 km od naszej granicy" src="https://interia-s.pluscdn.pl/premier-rosyjska-rakieta-spadla-15-km-od-naszej-granicy/000J13MUM5TP4GV4-C307.jpg" /></a>W nocy z piątku na sobotę siły rosyjskie przeprowadziły kolejny atak rakietowy na ukraińską infrastrukturę energetyczną. Spośród 34 rakiet, które wystrzelili Rosjanie, ukraińskiej obronie powietrznej udało się zestrzelić 21. Jedna z nich - jak poinformował premier Donald Tusk - spadła 15 km od polskiej granicy.</p><br clear="all" />

## Iga Świątek awansowała do czwartej rundy turnieju w Madrycie
 - [https://www.rmf24.pl/sport/tenis/news-iga-swiatek-awansowala-do-czwartej-rundy-turnieju-w-madrycie,nId,7477719](https://www.rmf24.pl/sport/tenis/news-iga-swiatek-awansowala-do-czwartej-rundy-turnieju-w-madrycie,nId,7477719)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T10:38:18+00:00

<p><a href="https://www.rmf24.pl/sport/tenis/news-iga-swiatek-awansowala-do-czwartej-rundy-turnieju-w-madrycie,nId,7477719"><img align="left" alt="Iga Świątek awansowała do czwartej rundy turnieju w Madrycie" src="https://interia-s.pluscdn.pl/iga-swiatek-awansowala-do-czwartej-rundy-turnieju-w-madrycie/000J13NC295XBRU3-C307.jpg" /></a>Iga Świątek wygrała z Rumunką Soraną Cirsteą 6:1, 6:1 w trzeciej rundzie turnieju WTA 1000 na kortach ziemnych w Madrycie. Rywalką Polki w 1/8 finału będzie Hiszpanka Sara Sorribes Tormo.</p><br clear="all" />

## Iga Świątek awansowała do czwartej rundy turnieju WTA w Madrycie
 - [https://www.rmf24.pl/sport/tenis/news-iga-swiatek-awansowala-do-czwartej-rundy-turnieju-wta-w-madr,nId,7477719](https://www.rmf24.pl/sport/tenis/news-iga-swiatek-awansowala-do-czwartej-rundy-turnieju-wta-w-madr,nId,7477719)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T10:38:18+00:00

<p><a href="https://www.rmf24.pl/sport/tenis/news-iga-swiatek-awansowala-do-czwartej-rundy-turnieju-wta-w-madr,nId,7477719"><img align="left" alt="Iga Świątek awansowała do czwartej rundy turnieju WTA w Madrycie" src="https://interia-s.pluscdn.pl/iga-swiatek-awansowala-do-czwartej-rundy-turnieju-wta-w-madr/000J13NC295XBRU3-C307.jpg" /></a>Iga Świątek wygrała z Rumunką Soraną Cirsteą 6:1, 6:1 w trzeciej rundzie turnieju WTA 1000 na kortach ziemnych w Madrycie. Mecz trwał godzinę i 18 minut.</p><br clear="all" />

## Śmierć strażaka w Wielkopolsce. Zasłabł podczas ćwiczeń w komorze dymowej
 - [https://www.rmf24.pl/regiony/poznan/news-smierc-strazaka-w-wielkopolsce-zaslabl-podczas-cwiczen-w-kom,nId,7477711](https://www.rmf24.pl/regiony/poznan/news-smierc-strazaka-w-wielkopolsce-zaslabl-podczas-cwiczen-w-kom,nId,7477711)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T10:14:00+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-smierc-strazaka-w-wielkopolsce-zaslabl-podczas-cwiczen-w-kom,nId,7477711"><img align="left" alt="Śmierć strażaka w Wielkopolsce. Zasłabł podczas ćwiczeń w komorze dymowej" src="https://interia-s.pluscdn.pl/smierc-strazaka-w-wielkopolsce-zaslabl-podczas-cwiczen-w-kom/000J13KF4RLMF92H-C307.jpg" /></a>Tragiczny wypadek w Ostrowie Wielkopolskim. Podczas ćwiczeń w komorze dymowej zasłabł jeden ze strażaków z OSP z powiatu kaliskiego. Niestety, życia mężczyzny nie udało się uratować.</p><br clear="all" />

## Ogień olimpijski wyruszył do Francji
 - [https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-ogien-olimpijski-wyruszyl-do-francji,nId,7477715](https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-ogien-olimpijski-wyruszyl-do-francji,nId,7477715)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T10:11:08+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-igrzyska-paryz-2024/news-ogien-olimpijski-wyruszyl-do-francji,nId,7477715"><img align="left" alt="Ogień olimpijski wyruszył do Francji" src="https://interia-s.pluscdn.pl/ogien-olimpijski-wyruszyl-do-francji/000J13KGMR323A77-C307.jpg" /></a>Olimpijski ogień wyruszył w trwającą ponad półtora tygodnia podróż z Grecji do Francji. Umieszczony został na pokładzie XIX-wiecznego, trzymasztowego żaglowca „Belem”. </p><br clear="all" />

## Skatowana trzylatka w Wejherowie. Policja zatrzymała partnera matki dziecka
 - [https://www.rmf24.pl/regiony/trojmiasto/news-skatowana-trzylatka-w-wejherowie-policja-zatrzymala-partnera,nId,7477704](https://www.rmf24.pl/regiony/trojmiasto/news-skatowana-trzylatka-w-wejherowie-policja-zatrzymala-partnera,nId,7477704)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T09:34:32+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-skatowana-trzylatka-w-wejherowie-policja-zatrzymala-partnera,nId,7477704"><img align="left" alt="Skatowana trzylatka w Wejherowie. Policja zatrzymała partnera matki dziecka" src="https://interia-s.pluscdn.pl/skatowana-trzylatka-w-wejherowie-policja-zatrzymala-partnera/000J13HU952RRKJ1-C307.jpg" /></a>Skatowana 3-letnia dziewczynka trafiła w piątek do szpitala w Wejherowie - dowiedział się reporter RMF FM. Po pogotowie zadzwoniła matka dziecka. Policja zatrzymała już 23-letniego partnera kobiety.</p><br clear="all" />

## Lewica zaprezentowała "jedynki" na listach w wyborach do PE
 - [https://www.rmf24.pl/raporty/raport-eurowybory-2024/news-lewica-zaprezentowala-jedynki-na-listach-w-wyborach-do-pe,nId,7477699](https://www.rmf24.pl/raporty/raport-eurowybory-2024/news-lewica-zaprezentowala-jedynki-na-listach-w-wyborach-do-pe,nId,7477699)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T09:07:10+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-eurowybory-2024/news-lewica-zaprezentowala-jedynki-na-listach-w-wyborach-do-pe,nId,7477699"><img align="left" alt="Lewica zaprezentowała &quot;jedynki&quot; na listach w wyborach do PE" src="https://interia-s.pluscdn.pl/lewica-zaprezentowala-jedynki-na-listach-w-wyborach-do-pe/000J13GJ66FMVIV0-C307.jpg" /></a>Lewica zaprezentowała podczas sobotniej konwencji &quot;jedynki&quot; na listach wyborczych do Parlamentu Europejskiego. Wśród nich znaleźli się m.in. szefowa klubu Lewicy Anna Maria Żukowska, wiceszef MS Krzysztof Śmiszek, wiceministra kultury Joanna Scheuring-Wielgus i wiceszef MSZ Andrzej Szejna.</p><br clear="all" />

## Rafał P. w rękach "łowców głów". Był poszukiwany za podwójne zabójstwo
 - [https://www.rmf24.pl/regiony/slaskie/news-rafal-p-w-rekach-lowcow-glow-byl-poszukiwany-za-podwojne-zab,nId,7477696](https://www.rmf24.pl/regiony/slaskie/news-rafal-p-w-rekach-lowcow-glow-byl-poszukiwany-za-podwojne-zab,nId,7477696)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T09:01:56+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-rafal-p-w-rekach-lowcow-glow-byl-poszukiwany-za-podwojne-zab,nId,7477696"><img align="left" alt="Rafał P. w rękach &quot;łowców głów&quot;. Był poszukiwany za podwójne zabójstwo" src="https://interia-s.pluscdn.pl/rafal-p-w-rekach-lowcow-glow-byl-poszukiwany-za-podwojne-zab/000J13EZIURCE0T5-C307.jpg" /></a>Rafał P., który był poszukiwany za podwójne zabójstwo w Będzinie, został sprowadzony do Polski. Mężczyzna ukrywał się na terenie Niderlandów, gdzie został wytropiony i zatrzymany przez holenderski zespół wyspecjalizowany w zatrzymywaniu najbardziej niebezpiecznych przestępców.</p><br clear="all" />

## Lekarze: "Przed nami potężne uderzenie alergii". Co teraz uczula?
 - [https://www.rmf24.pl/aktualnosci/news-lekarze-przed-nami-potezne-uderzenie-alergii-co-teraz-uczula,nId,7477692](https://www.rmf24.pl/aktualnosci/news-lekarze-przed-nami-potezne-uderzenie-alergii-co-teraz-uczula,nId,7477692)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T08:49:40+00:00

<p><a href="https://www.rmf24.pl/aktualnosci/news-lekarze-przed-nami-potezne-uderzenie-alergii-co-teraz-uczula,nId,7477692"><img align="left" alt="Lekarze: &quot;Przed nami potężne uderzenie alergii&quot;. Co teraz uczula?" src="https://interia-s.pluscdn.pl/lekarze-przed-nami-potezne-uderzenie-alergii-co-teraz-uczula/000J13EHN3G30RXC-C307.jpg" /></a>Najbliższe dni mogą być trudne dla alergików - tak ostrzegają w RMF FM lekarze. Głównym powodem jest wzrost temperatury.</p><br clear="all" />

## 4-latka zdążyła na przeszczep nerki. Pomogła policyjna eskorta
 - [https://www.rmf24.pl/regiony/warszawa/news-4-latka-zdazyla-na-przeszczep-nerki-pomogla-policyjna-eskort,nId,7477678](https://www.rmf24.pl/regiony/warszawa/news-4-latka-zdazyla-na-przeszczep-nerki-pomogla-policyjna-eskort,nId,7477678)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T08:06:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-4-latka-zdazyla-na-przeszczep-nerki-pomogla-policyjna-eskort,nId,7477678"><img align="left" alt="4-latka zdążyła na przeszczep nerki. Pomogła policyjna eskorta" src="https://interia-s.pluscdn.pl/4-latka-zdazyla-na-przeszczep-nerki-pomogla-policyjna-eskort/000J13A950KUKCXP-C307.jpg" /></a>Żyrardowscy policjanci eskortowali auto z 4-letnią dziewczynką, która jechała na przeszczep nerki. Radiowóz pomógł szybko dojechać małej pacjentce prosto pod drzwi szpitala w Warszawie.</p><br clear="all" />

## Policja poszukuje zaginionej 14-letniej Wiktorii
 - [https://www.rmf24.pl/regiony/trojmiasto/news-policja-poszukuje-zaginionej-14-letniej-wiktorii,nId,7477669](https://www.rmf24.pl/regiony/trojmiasto/news-policja-poszukuje-zaginionej-14-letniej-wiktorii,nId,7477669)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T07:22:57+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-policja-poszukuje-zaginionej-14-letniej-wiktorii,nId,7477669"><img align="left" alt="Policja poszukuje zaginionej 14-letniej Wiktorii  " src="https://interia-s.pluscdn.pl/policja-poszukuje-zaginionej-14-letniej-wiktorii/000J137IQWEBCT3Y-C307.jpg" /></a>Policjanci z Sopotu poszukują zaginionej Wiktorii Kozickiej. Wczoraj (26 kwietnia) w godzinach popołudniowych nastolatka wyszła ze szkoły w Sopocie i do tej pory nie wróciła do domu ani nie skontaktowała się z bliskimi.</p><br clear="all" />

## Michał Kobosko: Mam ambicje, żeby wystartować z Warszawy do PE
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa/news-michal-kobosko-mam-ambicje-zeby-wystartowac-z-warszawy-do-pe,nId,7475803](https://www.rmf24.pl/tylko-w-rmf24/rozmowa/news-michal-kobosko-mam-ambicje-zeby-wystartowac-z-warszawy-do-pe,nId,7475803)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T06:32:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa/news-michal-kobosko-mam-ambicje-zeby-wystartowac-z-warszawy-do-pe,nId,7475803"><img align="left" alt="Michał Kobosko: Mam ambicje, żeby wystartować z Warszawy do PE" src="https://interia-s.pluscdn.pl/michal-kobosko-mam-ambicje-zeby-wystartowac-z-warszawy-do-pe/000J135U5NVGMQV9-C307.jpg" /></a>&quot;Tak, mam takie ambicje, żeby wystartować z Warszawy do Parlamentu Europejskiego&quot; - przyznał Michał Kobosko, który w sobotni poranek był Gościem Krzysztofa Ziemca w RMF FM. Wiceprzewodniczący Polski 2050 poinformował, że Trzecia Droga zaprezentuje swoje listy wyborcze w poniedziałek.</p><br clear="all" />

## Majówkowy city break tuż za granicą! Miasta naszych sąsiadów mają świetne propozycje
 - [https://www.rmf24.pl/fakty/swiat/news-majowkowy-city-break-tuz-za-granica-miasta-naszych-sasiadow-,nId,7475867](https://www.rmf24.pl/fakty/swiat/news-majowkowy-city-break-tuz-za-granica-miasta-naszych-sasiadow-,nId,7475867)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T06:02:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-majowkowy-city-break-tuz-za-granica-miasta-naszych-sasiadow-,nId,7475867"><img align="left" alt="Majówkowy city break tuż za granicą! Miasta naszych sąsiadów mają świetne propozycje" src="https://interia-s.pluscdn.pl/majowkowy-city-break-tuz-za-granica-miasta-naszych-sasiadow/000J0ZS0K5YINS1O-C307.jpg" /></a>Majówka to idealna pora na krótki wypad do sąsiedniego kraju. W zasięgu kilkugodzinnej podróży samochodem, autobusem lub pociągiem są miejsca, które w tym okresie przyciągają turystów różnymi wydarzeniami.</p><br clear="all" />

## Opublikowano oświadczenie majątkowe Donalda Tuska
 - [https://www.rmf24.pl/polityka/news-opublikowano-oswiadczenie-majatkowe-donalda-tuska,nId,7477647](https://www.rmf24.pl/polityka/news-opublikowano-oswiadczenie-majatkowe-donalda-tuska,nId,7477647)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T05:15:03+00:00

<p><a href="https://www.rmf24.pl/polityka/news-opublikowano-oswiadczenie-majatkowe-donalda-tuska,nId,7477647"><img align="left" alt="Opublikowano oświadczenie majątkowe Donalda Tuska" src="https://interia-s.pluscdn.pl/opublikowano-oswiadczenie-majatkowe-donalda-tuska/000J12YN5DG5B852-C307.jpg" /></a>Na stronie Kancelarii Prezesa Rady Ministrów opublikowano oświadczenie majątkowe premiera Donalda Tuska za rok 2023. Premier ma między innymi 120 tys. zł oraz 295 tys. euro oszczędności. </p><br clear="all" />

## ​Michał Kobosko Gościem Krzysztofa Ziemca w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa/news-michal-kobosko-gosciem-krzysztofa-ziemca-w-rmf-fm,nId,7475803](https://www.rmf24.pl/tylko-w-rmf24/rozmowa/news-michal-kobosko-gosciem-krzysztofa-ziemca-w-rmf-fm,nId,7475803)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T05:10:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa/news-michal-kobosko-gosciem-krzysztofa-ziemca-w-rmf-fm,nId,7475803"><img align="left" alt="​Michał Kobosko Gościem Krzysztofa Ziemca w RMF FM" src="https://interia-s.pluscdn.pl/michal-kobosko-gosciem-krzysztofa-ziemca-w-rmf-fm/000J0ZGPK8HQ8Y5R-C307.jpg" /></a>Michał Kobosko, poseł i wiceprzewodniczący partii Polska 2050, będzie Gościem Krzysztofa Ziemca w RMF FM. Porozmawiamy z nim m.in. o wyborach do Parlamentu Europejskiego.</p><br clear="all" />

## Alarmy przeciwlotnicze w kilku ukraińskich obwodach [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-alarmy-przeciwlotnicze-w-kilku-ukrainskich-obwodach-relacja,nId,7477645](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-alarmy-przeciwlotnicze-w-kilku-ukrainskich-obwodach-relacja,nId,7477645)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T04:21:37+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-alarmy-przeciwlotnicze-w-kilku-ukrainskich-obwodach-relacja,nId,7477645"><img align="left" alt="Alarmy przeciwlotnicze w kilku ukraińskich obwodach [RELACJA]" src="https://interia-s.pluscdn.pl/alarmy-przeciwlotnicze-w-kilku-ukrainskich-obwodach-relacja/000J12WYACYS5AY1-C307.jpg" /></a>Alarmy przeciwlotnicze ogłoszono w sobotę nad ranem w kilku ukraińskich obwodach, m.in. chersońskim, mikołajowskim, kirowogradzkim i dniepropietrowskim - poinformował portal Ukraińska Prawda, powołując się na źródła wojskowe. W nocy ukraińskie media podawały informacje o starcie w Rosji bombowców Tu-95MS, które mogą przenosić rakiety manewrujące, a także o eksplozjach w Charkowie, Chersoniu, Dnieprze i obwodzie lwowskim. W związku z rozpoczęciem kolejnej fali ataków lotnictwa dalekiego zasięgu Federacji Rosyjskiej na obiekty znajdujące się...</p><br clear="all" />

## Alarmy przeciwlotnicze w kilku ukraińskich obwodach [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarmy-przeciwlotnicze-w-kilku-ukrainskich-obwodach-relacja,nId,7477645](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarmy-przeciwlotnicze-w-kilku-ukrainskich-obwodach-relacja,nId,7477645)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T04:21:37+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarmy-przeciwlotnicze-w-kilku-ukrainskich-obwodach-relacja,nId,7477645"><img align="left" alt="Alarmy przeciwlotnicze w kilku ukraińskich obwodach [RELACJA]" src="https://interia-s.pluscdn.pl/alarmy-przeciwlotnicze-w-kilku-ukrainskich-obwodach-relacja/000J12WYACYS5AY1-C307.jpg" /></a>W godzinach porannych ogłoszono kolejne alarmy przeciwlotnicze w kilku ukraińskich obwodach, m.in. chersońskim, mikołajowskim, kirowogradzkim i dniepropietrowskim - poinformował portal Ukraińska Prawda, powołując się na źródła wojskowe. Wcześniej w nocy ukraińskie media podawały informacje o starcie w Rosji bombowców Tu-95MS, które mogą przenosić pociski manewrujące, a także o eksplozjach w Charkowie, Chersoniu, Dnieprze i obwodzie lwowskim. Minionej nocy Dowództwo Operacyjne Rodzajów Sił Zbrojnych dwukrotnie aktywowało polskie i sojusznicze...</p><br clear="all" />

## Kolejny rosyjski atak na ukraińską infrastrukturę energetyczną [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-kolejny-rosyjski-atak-na-ukrainska-infrastrukture-energetycz,nId,7477645](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-kolejny-rosyjski-atak-na-ukrainska-infrastrukture-energetycz,nId,7477645)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T04:21:37+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-kolejny-rosyjski-atak-na-ukrainska-infrastrukture-energetycz,nId,7477645"><img align="left" alt="Kolejny rosyjski atak na ukraińską infrastrukturę energetyczną [RELACJA]" src="https://interia-s.pluscdn.pl/kolejny-rosyjski-atak-na-ukrainska-infrastrukture-energetycz/000J12WYACYS5AY1-C307.jpg" /></a>W godzinach porannych Rosja zaatakowała infrastrukturę energetyczną w trzech obwodach Ukrainy, niszcząc sprzęt i raniąc co najmniej jednego pracownika - przekazał za pośrednictwem aplikacji Telegram ukraiński minister energii Herman Hałuszczenko. Ukraińskiej obronie powietrznej udało się zestrzelić 21 z 34 rosyjskich pocisków. Minionej nocy Dowództwo Operacyjne Rodzajów Sił Zbrojnych dwukrotnie aktywowało polskie i sojusznicze myśliwce w związku ze &quot;wzmożoną aktywnością rosyjskiego lotnictwa dalekiego zasięgu&quot;. Maszyny powróciły do swoich...</p><br clear="all" />

## Zmasowany atak ukraińskich dronów na lotnisko i rafinerie w Rosji [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zmasowany-atak-ukrainskich-dronow-na-lotnisko-i-rafinerie-w-,nId,7477645](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zmasowany-atak-ukrainskich-dronow-na-lotnisko-i-rafinerie-w-,nId,7477645)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T04:21:37+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zmasowany-atak-ukrainskich-dronow-na-lotnisko-i-rafinerie-w-,nId,7477645"><img align="left" alt="Zmasowany atak ukraińskich dronów na lotnisko i rafinerie w Rosji [RELACJA]" src="https://interia-s.pluscdn.pl/zmasowany-atak-ukrainskich-dronow-na-lotnisko-i-rafinerie-w/000J13ND25I9QXJV-C307.jpg" /></a>Służba Bezpieczeństwa Ukrainy zorganizowała zmasowany atak dronów na lotnisko wojskowe i rafinerie ropy naftowej w regionie krasnodarskim w Rosji - poinformowała na Telegramie telewizja Hromadske, powołując się na źródło w służbach specjalnych. W godzinach porannych Rosja zaatakowała infrastrukturę energetyczną w trzech obwodach Ukrainy, niszcząc sprzęt i raniąc co najmniej jednego pracownika - przekazał za pośrednictwem aplikacji Telegram ukraiński minister energii Herman Hałuszczenko. Ukraińskiej obronie powietrznej udało się zestrzelić 21...</p><br clear="all" />

## Dowództwo operacyjne: Aktywowano polskie i sojusznicze statki powietrzne
 - [https://www.rmf24.pl/fakty/swiat/news-dowodztwo-operacyjne-aktywowano-polskie-i-sojusznicze-statki,nId,7477643](https://www.rmf24.pl/fakty/swiat/news-dowodztwo-operacyjne-aktywowano-polskie-i-sojusznicze-statki,nId,7477643)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T04:05:27+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-dowodztwo-operacyjne-aktywowano-polskie-i-sojusznicze-statki,nId,7477643"><img align="left" alt="Dowództwo operacyjne: Aktywowano polskie i sojusznicze statki powietrzne" src="https://interia-s.pluscdn.pl/dowodztwo-operacyjne-aktywowano-polskie-i-sojusznicze-statki/000J12W6SI9PT0JP-C307.jpg" /></a>W związku z rozpoczęciem kolejnej fali ataków lotnictwa dalekiego zasięgu Federacji Rosyjskiej na obiekty znajdujące się na terytorium Ukrainy, aktywowano polskie i sojusznicze statki powietrzne - taką informację w sobotni poranek podało polskie Dowództwo Operacyjne Rodzajów Sił Zbrojnych. Po ponad dwóch godzinach maszyny powróciły do swoich baz.</p><br clear="all" />

## Dowództwo operacyjne: Poderwano polskie i sojusznicze myśliwce
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-dowodztwo-operacyjne-poderwano-polskie-i-sojusznicze-mysliwc,nId,7477643](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-dowodztwo-operacyjne-poderwano-polskie-i-sojusznicze-mysliwc,nId,7477643)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-27T04:05:27+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-dowodztwo-operacyjne-poderwano-polskie-i-sojusznicze-mysliwc,nId,7477643"><img align="left" alt="Dowództwo operacyjne: Poderwano polskie i sojusznicze myśliwce" src="https://interia-s.pluscdn.pl/dowodztwo-operacyjne-poderwano-polskie-i-sojusznicze-mysliwc/000J12W6SI9PT0JP-C307.jpg" /></a>&quot;W związku z rozpoczęciem kolejnej fali ataków lotnictwa dalekiego zasięgu Federacji Rosyjskiej na obiekty znajdujące się na terytorium Ukrainy, aktywowano polskie i sojusznicze statki powietrzne&quot; - taką informację w sobotni poranek podało Dowództwo Operacyjne Rodzajów Sił Zbrojnych. Po ponad dwóch godzinach zagrożenie minęło, a maszyny powróciły do swoich baz.</p><br clear="all" />

