# Source:Ku Bogu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0WiIwugwTXU5YBFvatbNg, language:pl

## Audiobook: Żywot Św. Ignacego Loyoli (część 6)
 - [https://www.youtube.com/watch?v=UQUiDWchaGs](https://www.youtube.com/watch?v=UQUiDWchaGs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0WiIwugwTXU5YBFvatbNg
 - date published: 2024-04-27T07:00:21+00:00

Kanał prowadzi fundacja 'ku Bogu'
► Bardzo ważne abyś zauważyła/zauważył, że możesz nas wesprzeć!. 
Jeśli pragniesz pomóc w realizacji podobnych treści zapraszamy Cię na naszą stronę www:

kuBogu.pl

gdzie znajdziesz dostępne formy wsparcia

==============PONADTO MOŻESZ WYKONAĆ TRADYCYJNY PRZELEW================

☑ TRADYCYJNY PRZELEW
    Fundacja "ku Bogu", ul. Telewizyjna 1, 91-164 Łódź
    NIP: 7521459851
    REGON: 383925907

► w PLN; IBAN: PL47 1020 5226 0000 6702 0802 8161
► w EUR; IBAN: PL92 1020 5226 0000 6002 0802 8179
► w USD; IBAN: PL94 1020 5226 0000 6902 0802 8187
► SWIFT/BIC – BPKOPLPW  (dla przelewów zagranicznych)

☑ PAYPAL - https://www.paypal.me/KuBoguPL
☑ SKLEP KU BOGU - https://kubogu.pl/sklep/

==============SOCIAL MEDIA================
☑ CENTRUM DOWODZENIA https://kuBogu.pl
☑ FEJS - https://www.facebook.com/KuBoguYT/
☑ INSTAGRAM - https://www.instagram.com/_ku_bogu/

Z Panem Bogiem
Igor Nadolski - fundator i założyciel

