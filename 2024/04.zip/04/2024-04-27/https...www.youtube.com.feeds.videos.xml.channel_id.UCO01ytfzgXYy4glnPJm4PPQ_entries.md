# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Removing Even More Parental Rights
 - [https://www.youtube.com/watch?v=acYLxBKViAA](https://www.youtube.com/watch?v=acYLxBKViAA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-04-27T17:00:01+00:00



## Matt Walsh Reacts To VIRAL Videos
 - [https://www.youtube.com/watch?v=G_8Fkn4v1iM](https://www.youtube.com/watch?v=G_8Fkn4v1iM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-04-27T15:00:26+00:00

BJU Press - Learn how BJU Press can help you prepare your kids for a future full of possibilities at http://www.HomeSchoolHelp.com/Walsh

Ever wonder what Matt would say to these random viral videos? Find out now.

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## This Is The New Era Of Race Hoaxes, And It’s Terrifying
 - [https://www.youtube.com/watch?v=90n9w-i1v5Y](https://www.youtube.com/watch?v=90n9w-i1v5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-04-27T00:30:04+00:00

ExpressVPN - Get 3 Months FREE! www.ExpressVPN.com/MattWalshShow

We have now crossed the rubicon. AI-generated race hoaxes are officially here. This is the first case and will certainly not be the last.

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1356 - https://bit.ly/3xOHPa2

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

