# Source:Grimdark Magazine, URL:https://www.grimdarkmagazine.com/feed, language:en-AU

## REVIEW: Age of the Dryad by Jacob Sannox
 - [https://www.grimdarkmagazine.com/review-age-of-the-dryad-by-jacob-sannox](https://www.grimdarkmagazine.com/review-age-of-the-dryad-by-jacob-sannox)
 - RSS feed: https://www.grimdarkmagazine.com/feed
 - date published: 2024-04-27T04:43:49+00:00

<p>Nature won the war. Dryads, spirit protectors of the forests, have defeated mankind. Their King Dark Oak now reigns across The Old Continent, but his victory over Queen Cathryn only intensifies his need to control. Fueled by the painful memories of his past, he confines mankind to his unforgiving regime. Mankind is leaderless, powerless, and scattered. Still, Dark Oak is not satisfied. His boundless rage may destroy the very forests he sought to protect. A new age dawns in Jacob Sannox’s second book of The Dark Oak Chronicles. Age of the Dryad is classic fantasy meets post apocalypse. For a thousand years the combined people were unified. Defying all odds, they stood against the dark lord and political turmoil. Their gathered strength is nothing compared to the new king of the Dryads. Dark Oak easily shatters their legacy. His victory topples their entire civilization. He imposes extreme sanctions, reducing mankind to simple hunters and gatherers. Displaced and homeless people beca

