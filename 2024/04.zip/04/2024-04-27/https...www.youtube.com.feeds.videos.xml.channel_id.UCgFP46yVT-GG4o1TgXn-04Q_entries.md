# Source:China Uncensored, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCgFP46yVT-GG4o1TgXn-04Q, language:en

## Is China's Economy Recovering?
 - [https://www.youtube.com/watch?v=e459xsCeFEo](https://www.youtube.com/watch?v=e459xsCeFEo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCgFP46yVT-GG4o1TgXn-04Q
 - date published: 2024-04-27T13:58:39+00:00

After a pretty bleak few years, is the Chinese economy recovering?

Creating Communist China in Dwarf Fortress https://youtu.be/C_fKlajRrGY

YouTube demonetizes our channels, we need your support!
https://www.patreon.com/ChinaUncensored
https://chinauncensored.locals.com

We also accept bitcoin!
https://chinauncensored.tv/bitcoin

And Paypal: 
https://www.paypal.com/donate/?hosted_button_id=GAHZXYHGCBP3L

Buy our merchandise!
https://chinauncensored.tv/merchandise

China Uncensored on Odysee
https://odysee.com/@ChinaUncensored

China Uncensored on Rumble
https://rumble.com/c/ChinaUncensored

Make sure to share this video with your friends!
______________________________
Subscribe for updates:
youtube.com/ChinaUncensored?sub_confirmation=1

______________________________
Twitter: https://twitter.com/ChinaUncensored
Facebook: https://facebook.com/ChinaUncensored
Instagram: https://instagram.com/ChinaUncensored

And check out the China Unscripted podcast!
https://youtube.com/chinaunscrip

