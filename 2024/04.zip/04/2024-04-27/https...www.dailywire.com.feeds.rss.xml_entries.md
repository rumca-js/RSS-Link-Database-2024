# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Georgia State Patrol Officer Tackles And Carries Off Protester At Emory University
 - [https://www.dailywire.com/news/georgia-state-patrol-officer-tackles-and-carries-off-protester-at-emory-university](https://www.dailywire.com/news/georgia-state-patrol-officer-tackles-and-carries-off-protester-at-emory-university)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T17:35:17+00:00

A Georgia State Patrol officer tackled a pro-Palestinian demonstrator during a protest at Atlantaâ€™s Emory University this week and later appeared to have to pick up and carry the protester out of the area. &#8220;This was one of the first takedowns of many, several protesters were arrested today on the campus,&#8221; a local reporter wrote ...

## Michigan Imam: People Who Support Jewish State Of Israel Are â€˜Savages,â€™ â€˜Barbaricâ€™
 - [https://www.dailywire.com/news/michigan-imam-people-who-support-jewish-state-of-israel-are-savages-barbaric](https://www.dailywire.com/news/michigan-imam-people-who-support-jewish-state-of-israel-are-savages-barbaric)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T15:35:09+00:00

An Imam speaking in Dearborn, Michigan, this month claimed that Zionists, people who support the Jewish state of Israel, are &#8220;savages&#8221; and are &#8220;barbaric.&#8221; The Middle East Media Research Institute (MEMRI) translated the speech from Dr. Baqir Berry that was broadcast by the Islamic Institute of Knowledge. &#8220;Zionism is the ISIS of today,&#8221; he claimed. ...

## Planned Parenthood To Spend $10 Million Against Pro-Life Candidates In 2024 Battleground State
 - [https://www.dailywire.com/news/planned-parenthood-to-spend-10-million-against-pro-life-candidates-in-2024-battleground-state](https://www.dailywire.com/news/planned-parenthood-to-spend-10-million-against-pro-life-candidates-in-2024-battleground-state)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T15:00:45+00:00

Planned Parenthood will be spending millions of dollars to campaign against pro-life candidates in North Carolina for the 2024 election as Republicans attempt to gain control of the governor&#8217;s mansion.  Planned Parenthood, Planned Parenthood Votes, and Planned Parenthood Action PAC North Carolina said on Thursday that they would be spending $10 million in support of ...

## Maher Rips Far-Left Protesters Blocking Roads: â€˜Activism Merges With Narcissismâ€™
 - [https://www.dailywire.com/news/maher-rips-far-left-protesters-blocking-roads-activism-merges-with-narcissism](https://www.dailywire.com/news/maher-rips-far-left-protesters-blocking-roads-activism-merges-with-narcissism)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T14:32:37+00:00

Comedian Bill Maher mocked far-left protesters this week who are blocking traffic on major roadways in an attempt to end Israel&#8217;s war against Hamas terrorists inside Gaza. Maher made the remarks after the anti-Israel protesters have blocked roads in New York, San Francisco, Chicago, Seattle, Oregon, Philadelphia, and more. &#8220;Someone needs to tell the people ...

## Bill Barr: Biden Is â€˜The Real Threat To Democracyâ€™ And â€˜Our Freedomsâ€™
 - [https://www.dailywire.com/news/bill-barr-biden-is-the-real-threat-to-democracy-and-our-freedoms](https://www.dailywire.com/news/bill-barr-biden-is-the-real-threat-to-democracy-and-our-freedoms)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T14:04:06+00:00

Former U.S. Attorney General William Barr slammed President Joe Biden during an interview this week when explaining why he has decided to support former President Donald Trump this November. Barr made the remarks during a CNN interview with Kaitlan Collins when asked why he was supporting the former president as Trump. &#8220;It&#8217;s my duty to ...

## Man Charged With Making Bomb Threat To Republican Senate Candidate Is Donor To Democrat Opponent
 - [https://www.dailywire.com/news/man-charged-with-making-bomb-threat-to-republican-senate-candidate-is-donor-to-democrat-opponent](https://www.dailywire.com/news/man-charged-with-making-bomb-threat-to-republican-senate-candidate-is-donor-to-democrat-opponent)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T14:04:02+00:00

A Wisconsin man who donated to Sen. Tammy Baldwin (D-WI) has been charged with making a bomb threat to the campaign office of her Republican challenger.Â  Police charged 72-year-old Joseph Quade with making terrorist threats on Friday after investigating a message sent to the Senate campaign office of Eric Hovde that said the office â€œmight ...

## AOC Praises Columbia Protest Encampment After â€˜Student Leaderâ€™ Said â€˜Zionists Donâ€™t Deserve To Liveâ€™
 - [https://www.dailywire.com/news/aoc-praises-columbia-protest-encampment-after-student-leader-said-zionists-dont-deserve-to-live](https://www.dailywire.com/news/aoc-praises-columbia-protest-encampment-after-student-leader-said-zionists-dont-deserve-to-live)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T13:22:29+00:00

Rep. Alexandria Ocasio-Cortez (D-NY) visited the anti-Semitic protest encampment at Columbia University this week and praised its leadership, which comes after video went viral of one of the most vocal students in the protest saying earlier this year that â€œZionists donâ€™t deserve to live.â€� Ocasio-Cortez traveled to the school on Friday where the demonstrations have ...

## Chinese Nationals Accused Of Conspiracy To Smuggle American Technology Into China
 - [https://www.dailywire.com/news/chinese-nationals-accused-of-conspiracy-to-smuggle-american-technology-into-china](https://www.dailywire.com/news/chinese-nationals-accused-of-conspiracy-to-smuggle-american-technology-into-china)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T11:52:38+00:00

Two Chinese nationals have been accused by the Justice Department of attempting to illegally export American technology to China. The two, 44-year-old Han Li and 64-year-old Lin Chen, are charged with crimes related to an alleged conspiracy to smuggle American-made technology related to semiconductor production to restricted Chinese companies. If convicted, the two could face ...

## Biden Turns To Steven Spielberg For Messaging Strategy As Poll Numbers Lag
 - [https://www.dailywire.com/news/biden-turns-to-steven-spielberg-for-messaging-strategy-as-poll-numbers-lag](https://www.dailywire.com/news/biden-turns-to-steven-spielberg-for-messaging-strategy-as-poll-numbers-lag)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T11:10:57+00:00

President Joe Biden has reportedly turned to Hollywood director Steven Spielberg for political â€œstrategyâ€� as he campaigns for re-election against former President Donald Trump.Â  Spielberg, known for directing hit films like â€œETâ€� and â€œRaiders of the Lost Ark,â€� has been giving Biden advice on messaging for the Democratic National Committee in August. The news was ...

## â€˜The Whole Neighborhoodâ€™s Goneâ€™: Tornadoes Rip Through Midwest Destroying Homes
 - [https://www.dailywire.com/news/the-whole-neighborhoods-gone-tornadoes-rip-through-midwest-destroying-homes](https://www.dailywire.com/news/the-whole-neighborhoods-gone-tornadoes-rip-through-midwest-destroying-homes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-04-27T09:51:34+00:00

Tornadoes ripped through Iowa and Nebraska on Friday, with no reported deaths despite whole neighborhoods being destroyed.Â  Parts of Omaha, Nebraska, and northwest Iowa were severely damaged by the storms. Omaha Fire Chief Kathy Bossman said that there were many houses â€œflattenedâ€� and many more with â€œsignificant damage.â€� Bossman added that emergency crews had to ...

