# Source:Nerd of the Rings, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA, language:en-US

## Giants & Stone-Giants of Middle Earth | Tolkien Explained
 - [https://www.youtube.com/watch?v=Tow0xoHUW2c](https://www.youtube.com/watch?v=Tow0xoHUW2c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCW0gH2G-cMKAEjEkI4YhnPA
 - date published: 2024-04-27T16:00:22+00:00

The existence of giants may be debatable in Middle-earth, but Tolkien's use of them in his early legendarium is very real.  Today, we explore the appearances and references of giants (and stone-giants) in The Hobbit and The Lord of the Rings, and also dive into Tolkien's abandoned writings.

Hit subscribe and the bell for great Tolkien content every week!
Nerd of the Rings on PATREON: https://www.patreon.com/NerdoftheRings

NOTR merch: https://nerdoftherings.creator-spring.com/

To purchase artist work, check out these amazing artists!
Tulikoura - https://www.deviantart.com/tulikoura
Matthew Stewart - http://www.matthew-stewart.com/
BellaBergolts - https://www.deviantart.com/bellabergolts
Magdalena Katanska - https://www.artstation.com/magdalenakatanska/prints  https://www.instagram.com/qualiney
Jerry Vanderstelt - https://vandersteltstudio.com/store/
Anna Podedworna - https://www.artstation.com/akreon
Jenny Dolfen - goldseven.wordpress.com/
Kimberly80 - https://www.deviantart.com/kim

