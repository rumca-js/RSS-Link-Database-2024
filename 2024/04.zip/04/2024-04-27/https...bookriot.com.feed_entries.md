# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## Book Riot’s YA Book Deals of the Day for April 27, 2024
 - [https://bookriot.com/book-riots-ya-book-deals-of-the-day-for-april-27-2024](https://bookriot.com/book-riots-ya-book-deals-of-the-day-for-april-27-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-27T10:30:00+00:00

Inspiration for youth activists, a dark (and delicious) serial killer story, a fairy tale with twists and turns, and more of today's best YA book deals.

## Book Riot’s Deals of the Day for April 27, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-april-27-2024](https://bookriot.com/book-riots-deals-of-the-day-for-april-27-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-27T10:00:00+00:00

The crooked underbelly of 1930s Chicago, an Iceland sea captain, the value of memory, and more of today's best book deals.

