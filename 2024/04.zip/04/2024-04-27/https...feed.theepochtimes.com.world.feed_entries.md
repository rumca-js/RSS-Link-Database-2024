# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## Belgian Foreign Affairs Committee Chair Says She Was Hacked by CCP Spies
 - [https://www.theepochtimes.com/china/belgian-foreign-affairs-committee-chair-says-she-was-hacked-by-ccp-spies-5638934](https://www.theepochtimes.com/china/belgian-foreign-affairs-committee-chair-says-she-was-hacked-by-ccp-spies-5638934)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T21:32:00+00:00

European Union flags are displayed at the European Council headquarters in Brussels on Nov. 29, 2019. (Kenzo Tribouillard/AFP via Getty Images)

## Student Sues Toronto Metropolitan University for ‘Pervasive Antisemitism’
 - [https://www.theepochtimes.com/world/student-sues-toronto-metropolitan-university-for-pervasive-antisemitism-5638962](https://www.theepochtimes.com/world/student-sues-toronto-metropolitan-university-for-pervasive-antisemitism-5638962)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T21:24:12+00:00

The renamed Toronto Metropolitan University (TMU), formerly known as Ryerson University in Toronto on April 26, 2023. (The Canadian Press/Nathan Denette)

## David Krayden: Plastics Registry Is a Nightmare for Industry and a Farce for Canadians
 - [https://www.theepochtimes.com/opinion/david-krayden-plastics-registry-is-a-nightmare-for-industry-and-a-farce-for-canadians-5638226](https://www.theepochtimes.com/opinion/david-krayden-plastics-registry-is-a-nightmare-for-industry-and-a-farce-for-canadians-5638226)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T19:49:50+00:00

Environment Minister Steven Guilbeault speaks at a press conference during the fourth session of the Intergovernmental Negotiating Committee to develop an international treaty on plastic pollution, in Ottawa on April 22, 2024. (The Canadian Press/Sean Kilpatrick)

## Taiwan Seeks to Collaborate With US Tech Industries for Drone Production
 - [https://www.theepochtimes.com/china/taiwan-seeks-to-collaborate-with-us-tech-industries-for-drone-production-5638600](https://www.theepochtimes.com/china/taiwan-seeks-to-collaborate-with-us-tech-industries-for-drone-production-5638600)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T17:28:57+00:00

IRTI and Chiayi County held drone development collaboration agreement signing ceremony in San Jose on Apr. 25, 2024.(Nathan Su/The Epoch Times)

## Communist Pro-Gaza Students Chase Jacob Rees-Mogg After Speech at Cardiff University
 - [https://www.theepochtimes.com/world/communist-pro-gaza-students-chase-jacob-rees-mogg-after-speech-at-cardiff-university-5638847](https://www.theepochtimes.com/world/communist-pro-gaza-students-chase-jacob-rees-mogg-after-speech-at-cardiff-university-5638847)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T15:55:07+00:00

Sir Jacob Rees-Mogg during the launch of the Popular Conservatism movement at the Emmanuel Centre in central London on Feb. 6, 2024. (Victoria Jones/PA Wire)

## Yousaf: ‘Poor Choice’ for Greens to Back No Confidence Motion in Me
 - [https://www.theepochtimes.com/world/yousaf-poor-choice-for-greens-to-back-no-confidence-motion-in-me-5638885](https://www.theepochtimes.com/world/yousaf-poor-choice-for-greens-to-back-no-confidence-motion-in-me-5638885)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T15:24:42+00:00

First Minister of Scotland Humza Yousaf tours the recently completed Clarice Pears building during a to visit to the University of Glasgow on May 26, 2023. (Robert Perry/PA)

## Four Vietnamese Nationals Held in Facebook People Smugglers Probe
 - [https://www.theepochtimes.com/world/four-vietnamese-nationals-held-in-facebook-people-smugglers-probe-5638814](https://www.theepochtimes.com/world/four-vietnamese-nationals-held-in-facebook-people-smugglers-probe-5638814)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T10:32:00+00:00

Undated file photo of the sign of the National Crime Agency. (Kirsty O’Connor/PA)

## ONS Staff to Ignore Order to Work in Office 2 Days a Week
 - [https://www.theepochtimes.com/world/ons-staff-to-ignore-order-to-work-in-office-2-days-a-week-5638807](https://www.theepochtimes.com/world/ons-staff-to-ignore-order-to-work-in-office-2-days-a-week-5638807)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T10:22:21+00:00

A woman using a laptop on a dining room table set up as a remote office to work from home on March 4, 2020. (Joe Giddens/PA Wire)

## ‘Hundreds of Thousands’ Expected at Pro-Palestinian March in London on Saturday
 - [https://www.theepochtimes.com/world/hundreds-of-thousands-expected-at-pro-palestinian-march-in-london-on-saturday-5638809](https://www.theepochtimes.com/world/hundreds-of-thousands-expected-at-pro-palestinian-march-in-london-on-saturday-5638809)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T09:57:55+00:00

People take part in a pro-Palestine march in central London on April 13, 2024. (Jeff Moore/PA)

## Quebec Municipality to Require Visitors to Scan QR Code to Enter and Leave
 - [https://www.theepochtimes.com/world/quebec-municipality-to-require-visitors-to-scan-qr-code-to-enter-and-leave-5638705](https://www.theepochtimes.com/world/quebec-municipality-to-require-visitors-to-scan-qr-code-to-enter-and-leave-5638705)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T03:19:18+00:00

The Quebec provincial flag is seen in a file photo. (The Canadian Press/Adrian Wyld)

## Legal Threat as Asbestos-Park Hit by Algae Outbreak
 - [https://www.theepochtimes.com/world/legal-threat-as-asbestos-park-hit-by-algae-outbreak-5638649](https://www.theepochtimes.com/world/legal-threat-as-asbestos-park-hit-by-algae-outbreak-5638649)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T03:00:53+00:00

Signs and barricades are placed around Rozelle Parklands for it’s clossure after asbestos was found, in Sydney, Jan. 10, 2024. A newly opened parkland in Sydney near a controversial motorway project has been closed after the discovery of asbestos in mulch surrounding a playground. (AAP Image/Bianca De Marchi)

## Treasurer Faces ‘Hard Truths’ in Global Industrial Race
 - [https://www.theepochtimes.com/world/treasurer-faces-hard-truths-in-global-industrial-race-5638643](https://www.theepochtimes.com/world/treasurer-faces-hard-truths-in-global-industrial-race-5638643)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T02:00:30+00:00

Remote-controlled stackers and reclaimers moving iron ore at Rio Tinto's Port Dampier operations in Western Australia's Pilbara region. (Amy Coopes/AFP/Getty Images)

## Half of Nurses, Midwives Considering Leaving Profession
 - [https://www.theepochtimes.com/world/half-of-nurses-midwives-considering-leaving-profession-5638640](https://www.theepochtimes.com/world/half-of-nurses-midwives-considering-leaving-profession-5638640)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T01:00:42+00:00

Ambulances arrive at St Vincent's Hospital in Sydney, Australia, on Dec. 28, 2021. (Jenny Evans/Getty Images)

## Centrelink Claims Backlog Slashed After Hiring Blitz
 - [https://www.theepochtimes.com/world/centrelink-claims-backlog-slashed-after-hiring-blitz-5638637](https://www.theepochtimes.com/world/centrelink-claims-backlog-slashed-after-hiring-blitz-5638637)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-04-27T00:00:24+00:00

A Medicare and Centrelink office sign is seen at Bondi Junction in Sydney, Australia, on March 21, 2016. (Matt King/Getty Images)

