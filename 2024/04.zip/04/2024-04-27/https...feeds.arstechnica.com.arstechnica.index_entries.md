# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## Why Germany ditched nuclear before coal—and why it won’t go back
 - [https://arstechnica.com/?p=2020372](https://arstechnica.com/?p=2020372)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-04-27T11:27:05+00:00

The past year has seen record renewable power production nationwide.

## There’s never been a better time to get into Fallout 76
 - [https://arstechnica.com/?p=2019560](https://arstechnica.com/?p=2019560)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-04-27T11:00:19+00:00

<em>Fallout 76</em> is good now. Actually, it’s always been good.

## NASA still doesn’t understand root cause of Orion heat shield issue
 - [https://arstechnica.com/?p=2020378](https://arstechnica.com/?p=2020378)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-04-27T00:22:09+00:00

“When we stitch it all together, we’ll either have flight rationale or we won’t."

