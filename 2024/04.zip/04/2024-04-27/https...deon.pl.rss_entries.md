# Source:DEON.pl, URL:https://deon.pl/rss, language:pl

## Bóg sędzia czy ojciec, surowy i wymagający czy troskliwy i wspierający?
 - [https://deon.pl/wiara/bog-sedzia-czy-ojciec-surowy-i-wymagajacy-czy-troskliwy-i-wspierajacy,2803910](https://deon.pl/wiara/bog-sedzia-czy-ojciec-surowy-i-wymagajacy-czy-troskliwy-i-wspierajacy,2803910)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T22:00:00+00:00



## Wielki sukces Polaków. Polsko-fińska drużyna w ścisłej czołówce podczas największych ćwiczeń cyberobrony NATO
 - [https://deon.pl/swiat/wiadomosci-ze-swiata/wielki-sukces-polakow-polsko-finska-druzyna-w-scislej-czolowce-podczas-najwiekszych-cwiczen-cyberobrony-nato,2803880](https://deon.pl/swiat/wiadomosci-ze-swiata/wielki-sukces-polakow-polsko-finska-druzyna-w-scislej-czolowce-podczas-najwiekszych-cwiczen-cyberobrony-nato,2803880)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T18:00:00+00:00



## Kard. Comastri w 10. rocznicę kanonizacji: Za co kochamy św. Jana Pawła II?
 - [https://deon.pl/kosciol/kard-comastri-w-10-rocznice-kanonizacji-za-co-kochamy-sw-jana-pawla-ii,2803844](https://deon.pl/kosciol/kard-comastri-w-10-rocznice-kanonizacji-za-co-kochamy-sw-jana-pawla-ii,2803844)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T16:30:00+00:00



## Synoptyk IMGW: Pogoda się poprawia – ładna sobota zapowiedzią jeszcze pogodniejszej niedzieli
 - [https://deon.pl/swiat/synoptyk-imgw-pogoda-sie-poprawia--ladna-sobota-zapowiedzia-jeszcze-pogodniejszej-niedzieli,2803829](https://deon.pl/swiat/synoptyk-imgw-pogoda-sie-poprawia--ladna-sobota-zapowiedzia-jeszcze-pogodniejszej-niedzieli,2803829)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T15:00:00+00:00



## Watykan/ Papież: nie zostawiajcie seniorów samych, nie wystarczą programy pomocy
 - [https://deon.pl/kosciol/watykan-papiez-nie-zostawiajcie-seniorow-samych-nie-wystarcza-programy-pomocy,2803802](https://deon.pl/kosciol/watykan-papiez-nie-zostawiajcie-seniorow-samych-nie-wystarcza-programy-pomocy,2803802)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T14:00:00+00:00



## Czechy: zrekonstruowano twarz św. Wojciecha z X wieku
 - [https://deon.pl/kosciol/czechy-zrekonstruowano-twarz-sw-wojciecha-z-x-wieku,2803769](https://deon.pl/kosciol/czechy-zrekonstruowano-twarz-sw-wojciecha-z-x-wieku,2803769)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T13:30:00+00:00



## Olsztyn/ Powstała nowa noclegownia dla osób w kryzysie bezdomności
 - [https://deon.pl/swiat/olsztyn-powstala-nowa-noclegownia-dla-osob-w-kryzysie-bezdomnosci,2803754](https://deon.pl/swiat/olsztyn-powstala-nowa-noclegownia-dla-osob-w-kryzysie-bezdomnosci,2803754)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T12:00:00+00:00



## Z gajów oliwnych należących do sanktuarium w Fatimie pozyskano w 2023 roku 13 ton oliwy
 - [https://deon.pl/kosciol/z-gajow-oliwnych-nalezacych-do-sanktuarium-w-fatimie-pozyskano-w-2023-roku-13-ton-oliwy,2803535](https://deon.pl/kosciol/z-gajow-oliwnych-nalezacych-do-sanktuarium-w-fatimie-pozyskano-w-2023-roku-13-ton-oliwy,2803535)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T09:00:00+00:00



## Chiny/ Sekretarz stanu USA: mamy dowody na to, że Chiny ingerują w amerykańskie wybory
 - [https://deon.pl/swiat/chiny-sekretarz-stanu-usa-mamy-dowody-na-to-ze-chiny-ingeruja-w-amerykanskie-wybory,2803493](https://deon.pl/swiat/chiny-sekretarz-stanu-usa-mamy-dowody-na-to-ze-chiny-ingeruja-w-amerykanskie-wybory,2803493)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T08:00:00+00:00



## Byliśmy przekonani o świętości Jana Pawła II – wspomina kard. Stanisław Dziwisz
 - [https://deon.pl/kosciol/bylismy-przekonani-o-swietosci-jana-pawla-ii--wspomina-kard-stanislaw-dziwisz,2803448](https://deon.pl/kosciol/bylismy-przekonani-o-swietosci-jana-pawla-ii--wspomina-kard-stanislaw-dziwisz,2803448)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T07:00:00+00:00



## Logika rzecznika
 - [https://deon.pl/kosciol/komentarze/logika-rzecznika,2803142](https://deon.pl/kosciol/komentarze/logika-rzecznika,2803142)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T05:02:10+00:00



## Święty Jan Paweł II – ‘papież miłosierdzia’
 - [https://deon.pl/wiara/swiety-jan-pawel-ii--papiez-milosierdzia,2803553](https://deon.pl/wiara/swiety-jan-pawel-ii--papiez-milosierdzia,2803553)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T05:00:00+00:00



## "Pracujesz dla Jezusa, a nie dla pieniędzy". To nic innego, jak przemoc
 - [https://deon.pl/wiara/pracujesz-dla-jezusa-a-nie-dla-pieniedzy-to-nic-innego-jak-przemoc,2802353](https://deon.pl/wiara/pracujesz-dla-jezusa-a-nie-dla-pieniedzy-to-nic-innego-jak-przemoc,2802353)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-27T04:00:00+00:00



