# Source:CodeProject Latest Articles, URL:https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1, language:en-us

## SequelMax: C++ XML SAX Parser
 - [https://www.codeproject.com/Articles/692153/SequelMax-Cplusplus-XML-SAX-Parser](https://www.codeproject.com/Articles/692153/SequelMax-Cplusplus-XML-SAX-Parser)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-04-27T06:17:00+00:00

A new C++ SAX library to simplify parsing

## Portable Elmax: C++ XML DOM Parser
 - [https://www.codeproject.com/Articles/687720/Portable-Elmax-Cplusplus-XML-DOM-Parser](https://www.codeproject.com/Articles/687720/Portable-Elmax-Cplusplus-XML-DOM-Parser)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-04-27T06:09:00+00:00

Tutorial on a cross-platform C++ XML DOM library

