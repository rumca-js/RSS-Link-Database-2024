# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## What do we do about Diddy's music?
 - [https://www.youtube.com/watch?v=uAU3RmWtA1M](https://www.youtube.com/watch?v=uAU3RmWtA1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2024-04-27T18:20:58+00:00

I think the choice is obvious... P.S. Sign up to my Patreon for behind the scenes bloopers and early access to videos here: https://www.patreon.com/julienolke

Actors: Julie Nolke
Writer: Julie Nolke
Camera: Sam Larson
Editor: Julie Nolke

