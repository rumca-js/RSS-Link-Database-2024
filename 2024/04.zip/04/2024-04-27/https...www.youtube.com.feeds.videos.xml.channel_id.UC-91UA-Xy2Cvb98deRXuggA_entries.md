# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## THIS IS WHY TIPPING CULTURE IS OUT OF CONTROL
 - [https://www.youtube.com/watch?v=cy89CxZryjo](https://www.youtube.com/watch?v=cy89CxZryjo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2024-04-27T06:48:16+00:00

Get 50% off your first order of CookUnity meals — go to https://cookunity.com/fluke50 and use my code FLUKE50 at checkout to try them out for yourself! Thanks to CookUnity for sponsoring this video!

❤️ Support my content! 
 https://www.patreon.com/joshuafluke

🔥 Need a resume/cover letter? Check out my templates!  
https://joshuafluke.store/

👊 Join the community! 
https://discord.gg/Joshuafluke

Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke

Ever wondered why every checkout now begs for a tip? Dive into the wild world of tipping culture where digital screens guilt you into generosity at every turn. Today, we dissect the evolution of tipping—from traditional dine-and-dash settings to your morning coffee run that ends with a digital tip jar staring you down. Why are employe

