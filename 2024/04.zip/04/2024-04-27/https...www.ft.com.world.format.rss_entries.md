# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## Tory Dan Poulter defects to Labour
 - [https://www.ft.com/content/e84c79ff-09b0-49ef-a139-7aac6e866a2c](https://www.ft.com/content/e84c79ff-09b0-49ef-a139-7aac6e866a2c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T18:21:53+00:00

MP for Central Suffolk and North Ipswich says country needs an early election

## Art and activism come together at the Canal Projects Library
 - [https://www.ft.com/content/e7eccf66-d956-44e0-959a-712ec2f86f35](https://www.ft.com/content/e7eccf66-d956-44e0-959a-712ec2f86f35)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T04:00:42+00:00

Social practice — artists’ community-based work — is about exploring the world outside the white cube

## Curator Matthew Higgs: ‘People have become fatigued by huge art fairs with hundreds of galleries’
 - [https://www.ft.com/content/2597510a-fb59-44ce-885b-ee0ad18168b7](https://www.ft.com/content/2597510a-fb59-44ce-885b-ee0ad18168b7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T04:00:42+00:00

Independent Art Fair’s curatorial adviser believes New York’s art market is still growing even during an industry slowdown

## Dubai deluge brings home climate change dangers to a desert nation
 - [https://www.ft.com/content/a12272e7-536f-49ac-85d8-97e60dfec05e](https://www.ft.com/content/a12272e7-536f-49ac-85d8-97e60dfec05e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T04:00:42+00:00



## Frieze New York 2024
 - [https://www.ft.com/content/6c17e689-57ff-4732-9c0c-03f0f6a1021e](https://www.ft.com/content/6c17e689-57ff-4732-9c0c-03f0f6a1021e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T04:00:42+00:00

The fair arrives as galleries, braving a downturn, find new ways to collaborate. Also: interviews with artists Amalia Mesa-Bains and Charisse Pearlina Weston, a profile of gallerist Ales Ortuzar and much more

## Volleyball at the Eiffel Tower: Paris begins Olympic makeover
 - [https://www.ft.com/content/dd2016bf-7362-4e09-855d-af9b19614bdd](https://www.ft.com/content/dd2016bf-7362-4e09-855d-af9b19614bdd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T04:00:42+00:00

Preparations have begun to allow breakdancers at the Place de la Concorde and archers at Les Invalides

## What new aid really means for Ukraine — and for Putin
 - [https://www.ft.com/content/b346bcde-a9b0-47e4-bfc9-d507a91dfbdc](https://www.ft.com/content/b346bcde-a9b0-47e4-bfc9-d507a91dfbdc)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T04:00:42+00:00

Kyiv will have to husband its new resources carefully before trying to liberate Russian-occupied land

## Gallerist Ales Ortuzar: ‘I wanted to break the echo chamber’
 - [https://www.ft.com/content/18540b56-94b7-4ae7-ae8b-b81a6fe21ac9](https://www.ft.com/content/18540b56-94b7-4ae7-ae8b-b81a6fe21ac9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T04:00:41+00:00

Ortuzar Projects represents only 14 artists, all with low US profiles

## Divided Bank of England faces political heat over calls for rate cuts
 - [https://www.ft.com/content/49eb3e63-d97a-4dfa-ae5c-3a633e18fbf7](https://www.ft.com/content/49eb3e63-d97a-4dfa-ae5c-3a633e18fbf7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T03:00:40+00:00

Analysts warn chancellor against public comments on likelihood of lower interest rates

## Frank Field, MP and welfare reformer, 1942-2024
 - [https://www.ft.com/content/16481845-ebfe-4a63-b480-13d2b3cfc8a7](https://www.ft.com/content/16481845-ebfe-4a63-b480-13d2b3cfc8a7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-04-27T03:00:40+00:00

Former UK labour minister eschewed tribalism and held out the promise of a more collaborative style of politics

