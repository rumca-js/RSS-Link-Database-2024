# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## "The Guardian": Siły rosyjskie w Ukrainie mogą osiągnąć 500 tys. żołnierzy
 - [https://forsal.pl/swiat/rosja/artykuly/9497892,the-guardian-sily-rosyjskie-w-ukrainie-moga-osiagnac-500-tys-zolni.html](https://forsal.pl/swiat/rosja/artykuly/9497892,the-guardian-sily-rosyjskie-w-ukrainie-moga-osiagnac-500-tys-zolni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T17:40:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WrLktkuTURBXy8yZDQ5YTA0Yy0xMjhhLTQ4YjctODhlOS01NzNlYmVlZmExZWYuanBlZ5GTBc0BHcyg" />W inwazji na Ukrainie do niedawna brało udział 400 tys. rosyjskich żołnierzy, ale uważa się, że już niedługo liczebność tych sił może wzrosnąć do 500 tys.- ocenia w sobotę na łamach &quot;Guardiana&quot; brytyjski ekspert; podkreśla, że Kijów musi znaleźć sposób na pozyskanie nowych żołnierzy.

## Rosja nasila ataki. To ostatnia okazja przed wzmocnieniem Ukrainy
 - [https://forsal.pl/swiat/artykuly/9497891,rosja-nasila-ataki-to-ostatnia-okazja-przed-wzmocnieniem-ukrainy.html](https://forsal.pl/swiat/artykuly/9497891,rosja-nasila-ataki-to-ostatnia-okazja-przed-wzmocnieniem-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T17:39:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cPFktkuTURBXy8wZTQ1MDk0Ny1mNmRiLTRkMTktOTNjOS02ZjkzZDM5NzZkZjEuanBlZ5GTBc0BHcyg" />Rosja intensyfikuje ataki na Ukrainę, próbując wykorzystać czas przed przybyciem do tego kraju dostaw zachodniego sprzętu wojskowego i amunicji - ocenił dowódca Centrum Wywiadu Estońskich Sił Obronnych pułkownik Ants Kiviselg. Dodał, że możliwość załamania się frontu ukraińskiego maleje.

## Według wywiadu USA Putin nie rozkazał zabić Nawalnego w kolonii karnej
 - [https://forsal.pl/swiat/rosja/artykuly/9497890,wedlug-wywiadu-usa-putin-nie-rozkazal-zabic-nawalnego-w-kolonii-karnej.html](https://forsal.pl/swiat/rosja/artykuly/9497890,wedlug-wywiadu-usa-putin-nie-rozkazal-zabic-nawalnego-w-kolonii-karnej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T17:38:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3WqktktTURBXy9iZDcxNGU4OS1jZGJhLTQ2YTUtODM3My0xZDAwYTY3MjY5NmYucG5nkZMFzQEdzKA" />Amerykańskie agencje wywiadowcze uważają, że Władimir Putin prawdopodobnie nie nakazał zamordowania w lutym przywódcy opozycji Aleksieja Nawalnego w kolonii karnej za kołem podbiegunowym - poinformował w sobotę dziennik „Wall Street Journal”, cytowany przez portal Politico.

## Kaczyński: Idziemy do PE, żeby odrzucić Zielony Ład
 - [https://forsal.pl/kraj/polityka/artykuly/9497874,kaczynski-idziemy-do-pe-zeby-odrzucic-zielony-lad.html](https://forsal.pl/kraj/polityka/artykuly/9497874,kaczynski-idziemy-do-pe-zeby-odrzucic-zielony-lad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T14:25:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Es-ktkuTURBXy80NGYyYjJiYS0zZmNkLTQ5MWEtYmNlYy02YzgwMmYxZjhiNjUuanBlZ5GTBc0BHcyg" />Idziemy do Parlamentu Europejskiego, żeby odrzucić Zielony Ład - podkreślił prezes PiS Jarosław Kaczyński, który w sobotę wziął udział w konwencji PiS. Jak przekonywał, Zielony Ład oznacza m.in. wyższe ceny energii, a także wyższe ceny działalności gospodarczej.

## Lewica zaprezentowała "jedynki" na listach w wyborach do Parlamentu Europejskiego
 - [https://forsal.pl/kraj/polityka/artykuly/9497863,lewica-zaprezentowala-jedynki-na-listach-w-wyborach-do-parlamentu-eu.html](https://forsal.pl/kraj/polityka/artykuly/9497863,lewica-zaprezentowala-jedynki-na-listach-w-wyborach-do-parlamentu-eu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T11:20:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FGhktkuTURBXy9mYTVmNTFkZC1mMjljLTQ2ODMtYTE5Ni02NWU0MDZiNDgxMzEuanBlZ5GTBc0BHcyg" />Lewica zaprezentowała podczas sobotniej konwencji &quot;jedynki&quot; na listach w wyborczych do Parlamentu Europejskiego. Wśród nich znaleźli się m.in. szefowa klubu Lewicy Anna Maria Żukowska, wiceszef MS Krzysztof Śmiszek, wiceministra kultury Joanna Scheuring-Wielgus i wiceszef MSZ Andrzej Szejna.

## Czy zawieszenie usług konsularnych dla Ukraińców spowoduje, że pójdą na front?
 - [https://forsal.pl/swiat/ukraina/artykuly/9497840,czy-zawieszenie-uslug-konsularnych-dla-ukraincow-spowoduje-ze-pojda-n.html](https://forsal.pl/swiat/ukraina/artykuly/9497840,czy-zawieszenie-uslug-konsularnych-dla-ukraincow-spowoduje-ze-pojda-n.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T11:15:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9goktkuTURBXy8wZDVkMWVhNy0yNThiLTQ1MzgtYjY0Zi04ZGQyZDVkMTBhNTEuanBlZ5GTBc0BHcyg" />Ograniczanie obywatelom Ukrainy dostępu do usług konsularnych nie spowoduje, że wrócą do swojego kraju – ocenił adwokat, ekspert ds. legalizacji osób z państw spoza UE i autor książek Przemysław Lis-Markiewicz.

## Jak powinien wyglądać kolejowy komponent CPK? Oto spór ekspertów
 - [https://forsal.pl/transport/artykuly/9497839,jak-powinien-wygladac-kolejowy-komponent-cpk-oto-spor-ekspertow.html](https://forsal.pl/transport/artykuly/9497839,jak-powinien-wygladac-kolejowy-komponent-cpk-oto-spor-ekspertow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T11:15:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IwGktktTURBXy80MjMzYTk4YS1hZjYyLTQwNjQtODJmMS1lMjY5MGVkZWJiZmUucG5nkZMFzQEdzKA" />Eksperci nie są zgodni co do tego, jak powinien zostać zrealizowany komponent kolejowy planowany w ramach Centralnego Portu Komunikacyjnego. Koncepcji &quot;piasty i szprych&quot; broni m.in. jej twórca Patryk Wild. Przeciwnego zdania jest m.in. Piotr Rachwalski, który wskazuje głównie na potrzebę budowy &quot;igreka&quot;.

## Co czytają Polacy? Oto szóstka najpopularniejszych pisarek i pisarzy [GALERIA]
 - [https://forsal.pl/lifestyle/kultura/artykuly/9497595,co-czytaja-polacy-oto-szostka-najpopularniejszych-pisarek-i-pisarzy-.html](https://forsal.pl/lifestyle/kultura/artykuly/9497595,co-czytaja-polacy-oto-szostka-najpopularniejszych-pisarek-i-pisarzy-.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T11:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VPqktkuTURBXy9iMmM3MDhhOC0wM2JjLTRjNjQtOWUyZS03NDUxMzA4NTY0YTMuanBlZ5GTBc0BHcyg" />W corocznym raporcie Biblioteki Narodowej możemy przeczytać m.in. o tym, jaki odsetek Polek i Polaków przeczytał w ciągu minionych 12 miesięcy chociaż jedną książkę, jakie gatunki literackie preferujemy, a także - jakich autorów i autorki cenimy najbardziej.

## Oświadczenie majątkowe Donalda Tuska. Wiemy, jak duży majątek ma premier
 - [https://forsal.pl/kraj/polityka/artykuly/9497841,oswiadczenie-majatkowe-donalda-tuska-wiemy-jak-duzy-majatek-ma-premi.html](https://forsal.pl/kraj/polityka/artykuly/9497841,oswiadczenie-majatkowe-donalda-tuska-wiemy-jak-duzy-majatek-ma-premi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T07:19:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hMgktkuTURBXy83YTFmODU1YS04N2U5LTRjYWMtYjEyZS1mNDA4YzZlOTg5ZDYuanBlZ5GTBc0BHcyg" />Na stronie Kancelarii Prezesa Rady Ministrów opublikowano oświadczenie majątkowe premiera Donalda Tuska za rok 2023. Premier ma 120 tys. zł oraz 295 tys. euro oszczędności. Ma też trzy polisy na życie o łącznej wartości 440 tys. zł.

## Hamas: Otrzymaliśmy oficjalną propozycję Izraela w sprawie rozejmu
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9497838,hamas-otrzymalismy-oficjalna-propozycje-izraela-w-sprawie-rozejmu.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9497838,hamas-otrzymalismy-oficjalna-propozycje-izraela-w-sprawie-rozejmu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T07:09:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/v21ktkuTURBXy9jNzNlZTUxNy00MjczLTQxMzUtYjhkZC0wMTkzZDEwYWM4ZDUuanBlZ5GTBc0BHcyg" />Członek kierownictwa Hamasu Chalil Al-Hajja poinformował w sobotę rano w komunikacie, że jego ugrupowanie otrzymaliśmy oficjalną propozycję Izraela w sprawie rozejmu. Izraelscy negocjatorzy powiedzieli egipskim mediatorom, że &quot;dają ostatnią szansę&quot; rokowaniom - podał portal Times of Israel.

## Rosja zaatakowała infrastrukturę energetyczną Ukrainy w trzech obwodach
 - [https://forsal.pl/swiat/ukraina/artykuly/9497837,rosja-zaatakowala-infrastrukture-energetyczna-ukrainy-w-trzech-obwodac.html](https://forsal.pl/swiat/ukraina/artykuly/9497837,rosja-zaatakowala-infrastrukture-energetyczna-ukrainy-w-trzech-obwodac.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T07:08:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/H_cktkuTURBXy8zZmI1NTJhMC04MTY1LTQ4NGQtOTJmZi0xMjZkZGY0OWNiZWUuanBlZ5GTBc0BHcyg" />Rosja zaatakowała w sobotę infrastrukturę energetyczną w trzech obwodach Ukrainy, niszcząc sprzęt i raniąc co najmniej jednego pracownika - przekazał za pośrednictwem aplikacji Telegram ukraiński minister energii Herman Hałuszczenko.

## Policjantów czekają podwyżki? "Na stanowisku kursanta około 6000 zł"
 - [https://forsal.pl/praca/aktualnosci/artykuly/9497497,policjantow-czekaja-podwyzki-na-stanowisku-kursanta-okolo-6000-zl.html](https://forsal.pl/praca/aktualnosci/artykuly/9497497,policjantow-czekaja-podwyzki-na-stanowisku-kursanta-okolo-6000-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T06:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EckktkuTURBXy9jNDllNWUwNy1lZjFhLTQ2OGMtYmVhNC04YjRiMDdiMjJhNmYuanBlZ5GTBc0BHcyg" />Z powodu zarobków kursantów w policji, które są niższe niż w przypadku żołnierzy, chętnych do tego zawodu jest coraz mniej. Z związku z tym w Rządowym Centrum Legislacji pojawił się projekt ustawy, który ma podnieść uposażenie kandydatów po przyjęciu do służby i skierowaniu na szkolenie zawodowe o 1010 zł.

## Cała Unia Europejska pracuje. Wskaźnik zatrudnienia najwyższy od 2009 roku
 - [https://forsal.pl/praca/artykuly/9496731,cala-unia-europejska-pracuje-wskaznik-zatrudnienia-najwyzszy-od-2009.html](https://forsal.pl/praca/artykuly/9496731,cala-unia-europejska-pracuje-wskaznik-zatrudnienia-najwyzszy-od-2009.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EQ9ktkuTURBXy8yMGMyOWI5NS1iMWE5LTRiOWMtYTYyYS0wY2UzODIwZTJhNzguanBlZ5GTBc0BHcyg" />W 2023 r. zatrudnienie w Unii Europejskiej było na poziomie ponad 75 proc., co stanowi najwyższy odsetek osób zatrudnionych odnotowany od 2009 r.

## Gdzie bylibyśmy gospodarczo, gdybyśmy nie weszli do UE? [WYWIAD]
 - [https://forsal.pl/gospodarka/artykuly/9497477,gdzie-bylibysmy-gospodarczo-gdybysmy-nie-weszli-do-ue-wywiad.html](https://forsal.pl/gospodarka/artykuly/9497477,gdzie-bylibysmy-gospodarczo-gdybysmy-nie-weszli-do-ue-wywiad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jpgktkuTURBXy8yZDk5N2Q2Ni02YmIzLTQzYmEtYjJmNS1hYWU0YmM5ZWQ4ZmYuanBlZ5GTBc0BHcyg" />Do UE łatwo się przyzwyczaić, można na nią narzekać i trzeba ją zmieniać na lepsze, ale kiedy jej nie ma – to boli

## Kredyt bez wkładu własnego wciąż jest w ofercie. Gorzej z mieszkaniami w ofercie deweloperów
 - [https://forsal.pl/nieruchomosci/artykuly/9497524,kredyt-bez-wkladu-wlasnego-wciaz-jest-w-ofercie-gorzej-z-mieszkaniami.html](https://forsal.pl/nieruchomosci/artykuly/9497524,kredyt-bez-wkladu-wlasnego-wciaz-jest-w-ofercie-gorzej-z-mieszkaniami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SURktkuTURBXy8zYTMwNmFiNS0xZTE4LTQxYTEtOWZkMC02ZjI3ZmU3MmQxMWEuanBlZ5GTBc0BHcyg" />Sześć banków deklaruje udzielanie „Rodzinnego Kredytu Mieszkaniowego” z gwarantowanym przez państwo wkładem własnym. Problem w tym, że aby skorzystać z takiego kredytu, trzeba upatrzyć sobie mieszkanie, które spełnia określone kryteria cenowe. Eksperci portali RynekPierwotny.pl i GetHome.pl sprawdzili, ile takich lokali jest w ofercie firm deweloperskich działających w największych miastach.

## Kwaśniewski: Rozszerzenie z 2004 to ostatni piękny moment w historii Europy
 - [https://forsal.pl/kraj/polityka/artykuly/9497471,kwasniewski-rozszerzenie-z-2004-to-ostatni-piekny-moment-w-historii-e.html](https://forsal.pl/kraj/polityka/artykuly/9497471,kwasniewski-rozszerzenie-z-2004-to-ostatni-piekny-moment-w-historii-e.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4s5ktkuTURBXy8yMjE5NWM4Yy1lZWE3LTRlYjAtYmMyNC1mODViYmVhYmQ4ZDAuanBlZ5GTBc0BHcyg" />Rozszerzeniowy big bang z 2004 r. to właściwie ostatni piękny moment w historii Europy

## Złe wieści dla Kremla. Wydarzenia minionego tygodnia odmienią losy wojny w Ukrainie?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9497817,zle-wiesci-dla-kremla-wydarzenia-minionego-tygodnia-odmienia-losy-woj.html](https://forsal.pl/swiat/aktualnosci/artykuly/9497817,zle-wiesci-dla-kremla-wydarzenia-minionego-tygodnia-odmienia-losy-woj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-04-27T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/L4MktktTURBXy8wODUxZmQxMC00ZThiLTQyODItYjgwMy03OGNiYjM5N2I4YzgucG5nkZMFzQEdzKA" />Złe wieści dla Kremla: na początku tygodnia ruszyły nowe transze pomocy Zachodu dla Ukrainy, zaś na jego koniec Antony Blinken dogadywał się z Pekinem w sprawie ograniczenia chińskiego wsparcia dla Rosji. Tymczasem w Europie Emmanuel Macron już otwarcie staje na czele ruchu modernizacyjnego, a w Polsce rząd przystępuje do reformy systemu walki z korupcją. W obu przypadkach: oby na serio.

