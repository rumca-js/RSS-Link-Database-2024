# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## This Week In Techdirt History: April 21st – 27th
 - [https://www.techdirt.com/2024/04/27/this-week-in-techdirt-history-april-21st-27th](https://www.techdirt.com/2024/04/27/this-week-in-techdirt-history-april-21st-27th)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-27T19:06:00+00:00

Five Years Ago This week in 2019, another attempt to hold Twitter responsible for terrorist attacks was tossed out of court (but it didn&#8217;t stop the trend of rushing to blame social media for every tragedy) while we got a look behind the scenes of how Facebook dealt with the Christchurch shooting. Another Hollywood company [&#8230;]

## LittleBigPlanet: Now You Don’t Own What You’ve Created, Either
 - [https://www.techdirt.com/2024/04/26/littlebigplanet-now-you-dont-own-what-youve-created-either](https://www.techdirt.com/2024/04/26/littlebigplanet-now-you-dont-own-what-youve-created-either)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-27T02:39:00+00:00

For several years now, we&#8217;ve had a running series of posts discussing how, when it comes to digital goods, you often don&#8217;t own what you&#8217;ve bought. This ugliness shows up with all kinds of content, including purchased movies, books, and shows on digital platforms. But it has reared its head acutely as of late in [&#8230;]

