# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Ministry Of Ungentlemanly Warfare - Decent But Disappointing
 - [https://www.youtube.com/watch?v=d-R4AKnJc98](https://www.youtube.com/watch?v=d-R4AKnJc98)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2024-04-27T16:00:26+00:00

While it might not have been the all-action extraveganza promised in the trailers, and definitely not one of Guy Ritchie's better films, Ministry was still a decent WW2 adventure movie. But could have been so much more. 

Want to help support this channel? 
Check out the Drinker Merch Store: https://drinkershop.com/
Check out my books on Amazon: https://www.amazon.com/Will-Jordan/e/B00BCO7SA8/ref=dp_byline_cont_pop_ebooks_1
Subscribe on Patreon: https://www.patreon.com/TheCriticalDrinker
Subscribe on Subscribestar: https://www.subscribestar.com/the-critical-drinker

