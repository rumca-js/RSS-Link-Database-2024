# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Śmierć Aleksieja Nawalnego. Media podały nowe informacje
 - [https://wydarzenia.interia.pl/zagranica/news-smierc-aleksieja-nawalnego-media-podaly-nowe-informacje,nId,7477824](https://wydarzenia.interia.pl/zagranica/news-smierc-aleksieja-nawalnego-media-podaly-nowe-informacje,nId,7477824)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-04-27T19:26:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-smierc-aleksieja-nawalnego-media-podaly-nowe-informacje,nId,7477824"><img align="left" alt="Śmierć Aleksieja Nawalnego. Media podały nowe informacje" src="https://i.iplsc.com/smierc-aleksieja-nawalnego-media-podaly-nowe-informacje/000J156Z5RG0KUNO-C321.jpg" /></a>Władimir Putin nie wydał bezpośredniego rozkazu ws. śmierci Aleksieja Nawalnego - podał dziennik &quot;Wall Street Journal&quot;. Amerykańskie agencje wywiadowcze są zgodne, co do tego, że rosyjski przywódca nie miał bezpośredniego udziału w tym zdarzeniu. Jednakże część z europejskich urzędników nie zgadza się z taką tezą. Z kolei były współpracownik rosyjskiego opozycjonisty przekazał, że sam pomysł, iż Władimir Putin nie wyraził zgody na zlikwidowanie Nawalnego &quot;jest absurdalny&quot;.</p><br clear="all" />

## Zasłonią górę Fudżi. Japończycy wściekli na turystów
 - [https://wydarzenia.interia.pl/zagranica/news-zaslonia-gore-fudzi-japonczycy-wsciekli-na-turystow,nId,7477819](https://wydarzenia.interia.pl/zagranica/news-zaslonia-gore-fudzi-japonczycy-wsciekli-na-turystow,nId,7477819)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-04-27T17:50:51+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zaslonia-gore-fudzi-japonczycy-wsciekli-na-turystow,nId,7477819"><img align="left" alt="Zasłonią górę Fudżi. Japończycy wściekli na turystów " src="https://i.iplsc.com/zaslonia-gore-fudzi-japonczycy-wsciekli-na-turystow/000J152IG6I1L071-C321.jpg" /></a>W jednym z najpopularniejszych punktów widokowych przy górze Fudżi stanie czarny ekran. Ma on zasłonić widok na najsłynniejszą górę Japonii. Decyzję podjęli lokalni mieszkańcy, którzy są zmęczeni zachowaniem zagranicznych turystów. </p><br clear="all" />

