# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Wyciek danych ujawnia wyniki sprzedaży gier first-party od Sony
 - [https://ithardware.pl/aktualnosci/wyciek_danych_ujawnia_wyniki_sprzedazy_gier_first_party_od_sony-32760.html](https://ithardware.pl/aktualnosci/wyciek_danych_ujawnia_wyniki_sprzedazy_gier_first_party_od_sony-32760.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-27T20:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/32760_1.jpg" />            Ubiegłoroczny wyciek danych z Insomniac Games dostarczył&nbsp;ciekawych&nbsp;szczeg&oacute;ł&oacute;w&nbsp;nie tylko o działalności studia, ale r&oacute;wnież Sony i dane te nadal są źr&oacute;dłem interesujących informacji. Przykładowo teraz...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wyciek_danych_ujawnia_wyniki_sprzedazy_gier_first_party_od_sony-32760.html">https://ithardware.pl/aktualnosci/wyciek_danych_ujawnia_wyniki_sprzedazy_gier_first_party_od_sony-32760.html</a></p>

## NVIDIA GeForce RTX 4060 Ti - odnotowano spadek podaży Ada Lovelace
 - [https://ithardware.pl/aktualnosci/nvidia_geforce_rtx_4060_ti_odnotowano_spadek_podazy_ada_lovelace-32759.html](https://ithardware.pl/aktualnosci/nvidia_geforce_rtx_4060_ti_odnotowano_spadek_podazy_ada_lovelace-32759.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-27T18:46:10+00:00

<img src="https://ithardware.pl/artykuly/min/32759_1.jpg" />            W ostatnim czasie pojawiały się informacje o podniesieniu cen kart graficznych GeForce&nbsp;RTX 4060, RTX 3050, GTX 1650 czy nawet kłopotach z dostępnością RTX 4090. Teraz z obozu NVIDII dopływa kolejna niepokojąca wiadomość o spadku podaży...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_geforce_rtx_4060_ti_odnotowano_spadek_podazy_ada_lovelace-32759.html">https://ithardware.pl/aktualnosci/nvidia_geforce_rtx_4060_ti_odnotowano_spadek_podazy_ada_lovelace-32759.html</a></p>

## Manor Lords. Polska gra odnosi sukces tuż po premierze
 - [https://ithardware.pl/aktualnosci/manor_lords_polska_gra_odnosi_sukces_tuz_po_premierze-32758.html](https://ithardware.pl/aktualnosci/manor_lords_polska_gra_odnosi_sukces_tuz_po_premierze-32758.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-27T16:16:00+00:00

<img src="https://ithardware.pl/artykuly/min/32758_1.jpg" />            Manor Lords wywołało spore zamieszanie, kiedy to do listy życzeń grę dodało 3 mln użytkownik&oacute;w Steam. Popularność została otrzymana także po wydaniu produkcji.

Manor Lords to gra, za kt&oacute;rą nie stoi duże studio ani nawet...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/manor_lords_polska_gra_odnosi_sukces_tuz_po_premierze-32758.html">https://ithardware.pl/aktualnosci/manor_lords_polska_gra_odnosi_sukces_tuz_po_premierze-32758.html</a></p>

## Microsoft notuje wzrost przychodów ze sprzedaży gier. Konsole nadal jednak nie sprzedają się dobrze
 - [https://ithardware.pl/aktualnosci/microsoft_notuje_wzrost_przychodow_ze_sprzedazy_gier_konsole_nadal_jednak_nie_sprzedaja_sie_dobrze-32757.html](https://ithardware.pl/aktualnosci/microsoft_notuje_wzrost_przychodow_ze_sprzedazy_gier_konsole_nadal_jednak_nie_sprzedaja_sie_dobrze-32757.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-27T14:06:09+00:00

<img src="https://ithardware.pl/artykuly/min/32757_1.jpg" />            Przejęcie Activision Blizzard okazało się dla Microsoftu strzałem w dziesiątkę, ponieważ firma z Redmond zanotowała zauważalny wzrost przychod&oacute;w&nbsp;z segmentu gier. Jak na razie fuzja nie pomogła konsolom Xbox, kt&oacute;re zanotowały...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_notuje_wzrost_przychodow_ze_sprzedazy_gier_konsole_nadal_jednak_nie_sprzedaja_sie_dobrze-32757.html">https://ithardware.pl/aktualnosci/microsoft_notuje_wzrost_przychodow_ze_sprzedazy_gier_konsole_nadal_jednak_nie_sprzedaja_sie_dobrze-32757.html</a></p>

## Przetestowałem chińską myszkę Thorn. Lamzu jak zwykle mnie nie zawiodło
 - [https://ithardware.pl/testyirecenzje/przetestowalem_chinska_myszke_thorn_lamzu_jak_zwykle_mnie_nie_zawiodlo-32719.html](https://ithardware.pl/testyirecenzje/przetestowalem_chinska_myszke_thorn_lamzu_jak_zwykle_mnie_nie_zawiodlo-32719.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-27T10:46:20+00:00

<img src="https://ithardware.pl/artykuly/min/32719_1.jpg" />            Test Lamzu Thorn - Jak wypadła?

Zapewne niewielka część z was kojarzy markę Lamzu, ze względu na jej młody wiek i azjatyckie korzenie. Jednak nie jest to producent, obok kt&oacute;rego produkt&oacute;w można przejść obojętnie i zaraz...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/przetestowalem_chinska_myszke_thorn_lamzu_jak_zwykle_mnie_nie_zawiodlo-32719.html">https://ithardware.pl/testyirecenzje/przetestowalem_chinska_myszke_thorn_lamzu_jak_zwykle_mnie_nie_zawiodlo-32719.html</a></p>

## Chip Intel Lunar Lake dostrzeżony. Wydajność iGPU Battlemage zapowiada się bardzo obiecująco
 - [https://ithardware.pl/aktualnosci/chip_intel_lunar_lake_dostrzezony_wydajnosc_igpu_battlemage_zapowiada_sie_bardzo_obiecujaco-32756.html](https://ithardware.pl/aktualnosci/chip_intel_lunar_lake_dostrzezony_wydajnosc_igpu_battlemage_zapowiada_sie_bardzo_obiecujaco-32756.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-27T09:39:40+00:00

<img src="https://ithardware.pl/artykuly/min/32756_1.jpg" />            W bazie Sisoftware znalazł się laptop HP wyposażony w chip z rodziny Lunar Lake. Układ ten dysponuje nowym iGPU, kt&oacute;re zaskakuje swoją wydajnością. Jak się jednak okazuje, może to nie być najmocniejsza integra&nbsp;jaką szykuje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chip_intel_lunar_lake_dostrzezony_wydajnosc_igpu_battlemage_zapowiada_sie_bardzo_obiecujaco-32756.html">https://ithardware.pl/aktualnosci/chip_intel_lunar_lake_dostrzezony_wydajnosc_igpu_battlemage_zapowiada_sie_bardzo_obiecujaco-32756.html</a></p>

## MSI skupia się na serii GeForce RTX. Co z kartami Radeon?
 - [https://ithardware.pl/aktualnosci/msi_skupia_sie_na_serii_geforce_rtx_co_z_kartami_radeon-32755.html](https://ithardware.pl/aktualnosci/msi_skupia_sie_na_serii_geforce_rtx_co_z_kartami_radeon-32755.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-27T08:36:40+00:00

<img src="https://ithardware.pl/artykuly/min/32755_1.jpg" />            MSI kieruje obecnie swoją uwagę na karty graficzne GeForce RTX. Tajwański producent sprzętu nie rezygnuje jednak ze wsp&oacute;łpracy z AMD podkreślając pozytywny rozw&oacute;j w obszarze płyt gł&oacute;wnych.

MSI z większym zainteresowaniem...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/msi_skupia_sie_na_serii_geforce_rtx_co_z_kartami_radeon-32755.html">https://ithardware.pl/aktualnosci/msi_skupia_sie_na_serii_geforce_rtx_co_z_kartami_radeon-32755.html</a></p>

