# Source:RT - Daily news, URL:https://www.rt.com/rss, language:en

## WATCH German-made Leopard tank joins Moscow‚Äôs NATO trophy display
 - [https://www.rt.com/russia/596704-german-leopard-trophy-moscow/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/596704-german-leopard-trophy-moscow/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T22:49:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d7e4685f54076804d7325.png" style="margin-right: 10px;" /> Russia is finalizing preparations for the Victory Day celebrations with dozens of captured Western war machines to be showcased in Moscow <br /><a href="https://www.rt.com/russia/596704-german-leopard-trophy-moscow/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Islamists rally for German ‚ÄòCaliphate‚Äô in Hamburg
 - [https://www.rt.com/news/596703-islamists-rally-german-caliphate-hamburg/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596703-islamists-rally-german-caliphate-hamburg/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T22:38:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d7d6e85f5407991602261.jpg" style="margin-right: 10px;" /> A large crowd has gathered for an Islamist rally in Hamburg reportedly calling for the establishment of a ‚Äúcaliphate‚Äù in Germany <br /><a href="https://www.rt.com/news/596703-islamists-rally-german-caliphate-hamburg/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## China calls for ‚Äòinternational investigation‚Äô into Nord Stream attack
 - [https://www.rt.com/news/596702-china-nord-stream-investigation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596702-china-nord-stream-investigation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T21:14:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d63e32030273a153ad427.jpg" style="margin-right: 10px;" /> With no conclusions coming from Western-led probes, Beijing wants Russia involved in a fresh investigation into the 2022 Nord Stream attack <br /><a href="https://www.rt.com/news/596702-china-nord-stream-investigation/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Hamas releases new hostage video
 - [https://www.rt.com/news/596701-hamas-israeli-hostage-video/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596701-hamas-israeli-hostage-video/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T20:14:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d571285f5407a5305ba44.jpg" style="margin-right: 10px;" /> Footage of hostages just released by Palestinian militant group Hamas accuses the Israeli government of abandoning its citizens in Gaza <br /><a href="https://www.rt.com/news/596701-hamas-israeli-hostage-video/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Bernie Sanders hits back at Netanyahu over antisemitism claims
 - [https://www.rt.com/news/596698-sanders-slams-netanyahu-antisemitism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596698-sanders-slams-netanyahu-antisemitism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T20:00:35+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d53f685f5407d33647cd7.jpg" style="margin-right: 10px;" /> Israeli prime minister Netanyahu should be accountable for his ‚Äúextremist‚Äù government‚Äôs policies in Gaza, US senator Bernie Sanders has said <br /><a href="https://www.rt.com/news/596698-sanders-slams-netanyahu-antisemitism/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Situation on the front lines ‚Äòdifficult‚Äô ‚Äì Ukraine‚Äôs top military commander
 - [https://www.rt.com/russia/596700-situation-difficult-ukraine-top-commander/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/596700-situation-difficult-ukraine-top-commander/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T19:46:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d55a585f54079f17cbd32.jpg" style="margin-right: 10px;" /> The situation is already ‚Äúdifficult‚Äù for Kiev and is getting even worse, Ukraine‚Äôs highest military commander has admitted <br /><a href="https://www.rt.com/russia/596700-situation-difficult-ukraine-top-commander/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Neglect, abuse, harassment: The West is ignoring the fate of Palestinians stuck in Israeli jails
 - [https://www.rt.com/news/596620-palestinian-prisoners-israel-jails/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596620-palestinian-prisoners-israel-jails/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T19:02:07+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d4b7185f54079f17cbd28.jpg" style="margin-right: 10px;" /> Palestinian detainees freed by Israel tell of abuse and of indefinite detention, but their cause is unlikely to gain much traction in West <br /><a href="https://www.rt.com/news/596620-palestinian-prisoners-israel-jails/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## WATCH Russian Grad rockets pound Ukrainian positions
 - [https://www.rt.com/russia/596699-russia-grad-rockets-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/596699-russia-grad-rockets-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T18:37:03+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d4001203027455428d9c2.png" style="margin-right: 10px;" /> Barrages of Russian rockets struck Ukrainian positions in a week that saw Kiev lose more than 8,000 troops <br /><a href="https://www.rt.com/russia/596699-russia-grad-rockets-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## World‚Äôs most famous painting could get its own room
 - [https://www.rt.com/news/596686-mona-lisa-painting-louvre/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596686-mona-lisa-painting-louvre/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T17:48:39+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d2eeb85f5407a1f37792e.jpg" style="margin-right: 10px;" /> The iconic painting could soon get an individual display to give thousands of daily visitors a better experience <br /><a href="https://www.rt.com/news/596686-mona-lisa-painting-louvre/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ukraine lost over 8,000 soldiers in a week ‚Äì Russian MOD
 - [https://www.rt.com/russia/596697-ukraine-lost-soldiers-week-russian/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/596697-ukraine-lost-soldiers-week-russian/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T17:08:25+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d308385f54076804d7312.jpg" style="margin-right: 10px;" /> Ukrainian forces have lost thousands of troops, hundreds of pieces of equipment in past week, as Russia presses its advance, Moscow has said <br /><a href="https://www.rt.com/russia/596697-ukraine-lost-soldiers-week-russian/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Boston cops clear pro-Palestinian college protest (VIDEOS)
 - [https://www.rt.com/news/596692-israel-palestinian-protest-northeastern-boston/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596692-israel-palestinian-protest-northeastern-boston/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T17:00:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d284285f5400e7b2be366.jpg" style="margin-right: 10px;" /> Police have raided a protest camp at Northeastern University after demonstrators allegedly made death threats to Jews <br /><a href="https://www.rt.com/news/596692-israel-palestinian-protest-northeastern-boston/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Half of Russia-China payments conducted via third parties ‚Äì Reuters
 - [https://www.rt.com/business/596682-russia-china-payments-intermediaries-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/596682-russia-china-payments-intermediaries-sanctions/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T16:27:39+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d118c85f5407d33647cb2.jpg" style="margin-right: 10px;" /> Market for third-party payment is reportedly flourishing as US threatens sanctions against Chinese banks <br /><a href="https://www.rt.com/business/596682-russia-china-payments-intermediaries-sanctions/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US lawmakers want to deploy ‚Äòanti-Semitism monitors‚Äô at colleges
 - [https://www.rt.com/news/596689-college-antisemitism-protest-bill/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596689-college-antisemitism-protest-bill/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T16:10:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d14f585f54079f17cbd13.jpg" style="margin-right: 10px;" /> A new bill would strip funding from American universities that refuse to tackle anti-Israel protests on campus <br /><a href="https://www.rt.com/news/596689-college-antisemitism-protest-bill/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US to build new ‚Äòdoomsday plane‚Äô
 - [https://www.rt.com/news/596685-us-doomsday-aircraft/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596685-us-doomsday-aircraft/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T15:43:13+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d0c622030270383607a6d.jpg" style="margin-right: 10px;" /> A successor to the US command and control aircraft will be developed by Sierra Nevada Corp, the Air Force has announced <br /><a href="https://www.rt.com/news/596685-us-doomsday-aircraft/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel struck zones in Gaza that it had declared ‚Äòsafe‚Äô ‚Äì NBC
 - [https://www.rt.com/news/596691-nbc-idf-gaza-strikes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596691-nbc-idf-gaza-strikes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T15:38:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d1b742030274cf61ffe25.jpg" style="margin-right: 10px;" /> An investigation claims to have found that Palestinians have been killed in airstrikes on areas of Rafah that the IDF had designated ‚Äòsafe‚Äô <br /><a href="https://www.rt.com/news/596691-nbc-idf-gaza-strikes/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Cuba sends dead ‚ÄòRussian‚Äô to Canadian family
 - [https://www.rt.com/news/596684-canada-cuba-body-misplaced/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596684-canada-cuba-body-misplaced/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T15:30:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662d252c85f5407a5305ba2c.jpg" style="margin-right: 10px;" /> The family of a Canadian man who died in Cuba says they received the body of a Russian man by mistake <br /><a href="https://www.rt.com/news/596684-canada-cuba-body-misplaced/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## British deportation bill driving migrants to Ireland ‚Äì Deputy PM
 - [https://www.rt.com/news/596683-rwanda-deportation-bill-ireland/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596683-rwanda-deportation-bill-ireland/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T14:32:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cfe3b2030274d084c3f28.jpg" style="margin-right: 10px;" /> More and more migrants are choosing asylum in Ireland over potential deportation to Rwanda, Micheal Martin has said <br /><a href="https://www.rt.com/news/596683-rwanda-deportation-bill-ireland/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Somalia detains US-trained forces suspected of stealing food
 - [https://www.rt.com/africa/596680-somalia-detains-us-trained-forces-alleged-food-thieves/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/596680-somalia-detains-us-trained-forces-alleged-food-thieves/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T14:00:15+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cfaa385f5400e7b2be349.jpg" style="margin-right: 10px;" /> The Somali government has launched an investigation into alleged theft by elite unit of its army that fights militant group al-Shabaab <br /><a href="https://www.rt.com/africa/596680-somalia-detains-us-trained-forces-alleged-food-thieves/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## 12th suspect in Moscow terror attack arrested
 - [https://www.rt.com/russia/596676-crocus-terror-suspect-arrested/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/596676-crocus-terror-suspect-arrested/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T14:00:05+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cf14385f54031cf6e5faf.png" style="margin-right: 10px;" /> Basmanny Court in Moscow has ordered the pretrial detention of a 12th suspect in the Crocus City Hall terrorist attack <br /><a href="https://www.rt.com/russia/596676-crocus-terror-suspect-arrested/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Another $30 million US drone destroyed off Yemen‚Äôs coast ‚Äì CBS
 - [https://www.rt.com/news/596681-us-drone-downed-yemen/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596681-us-drone-downed-yemen/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T13:37:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cfab485f5407a5305ba07.jpg" style="margin-right: 10px;" /> Military officials say the US Air Force has lost a total of three MQ-9 Reaper UAVs in the region since November <br /><a href="https://www.rt.com/news/596681-us-drone-downed-yemen/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US TikTok ban unconstitutional ‚Äì presidential candidate
 - [https://www.rt.com/news/596672-rfk-lawsuit-tiktok-ban/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596672-rfk-lawsuit-tiktok-ban/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T13:36:44+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662ce39c85f54079916021fd.jpg" style="margin-right: 10px;" /> Robert F. Kennedy Jr. says he will challenge the potential TikTok ban in the US on constitutional grounds <br /><a href="https://www.rt.com/news/596672-rfk-lawsuit-tiktok-ban/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Much of Ukraine aid stolen ‚Äì French party leader
 - [https://www.rt.com/news/596679-ukraine-aid-corruption/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596679-ukraine-aid-corruption/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T13:31:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cf8e92030274d3e3dc649.jpg" style="margin-right: 10px;" /> A large part of Western assistance to Kiev is being embezzled by local officials, Florian Philippot has said <br /><a href="https://www.rt.com/news/596679-ukraine-aid-corruption/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## WhatsApp threatens to exit India ¬†
 - [https://www.rt.com/india/596678-whatsapp-threatens-to-exit-india/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/596678-whatsapp-threatens-to-exit-india/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T12:54:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cf5602030274b6e4f4698.jpg" style="margin-right: 10px;" /> Meta‚Äôs WhatsApp, which has 500 million users in India, has warned it cannot comply with local law ¬† <br /><a href="https://www.rt.com/india/596678-whatsapp-threatens-to-exit-india/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Iran to release crew of seized Israel-linked ship ‚Äì foreign minister
 - [https://www.rt.com/news/596677-iran-detained-israeli-ship-crew-release/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596677-iran-detained-israeli-ship-crew-release/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T12:51:39+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cf2ba85f5400e7b2be340.jpg" style="margin-right: 10px;" /> The crew of the container ship MCS Aries, detained in the Persian Gulf on April 13, will be released, the Iranian foreign minister has said <br /><a href="https://www.rt.com/news/596677-iran-detained-israeli-ship-crew-release/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia to tackle EU sanctions on LNG operations ‚Äì Kremlin
 - [https://www.rt.com/business/596669-russia-tackle-eu-sanctions-lng/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/596669-russia-tackle-eu-sanctions-lng/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T12:29:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cef182030274ee8180eba.jpg" style="margin-right: 10px;" /> Kremlin spokesman Dmitry Peskov says Russia will find ways to overcome the illegal sanctions being considered by EU lawmakers <br /><a href="https://www.rt.com/business/596669-russia-tackle-eu-sanctions-lng/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US spies believe Putin didn‚Äôt order Navalny‚Äôs death ‚Äì WSJ
 - [https://www.rt.com/news/596674-navalny-putin-us-cia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596674-navalny-putin-us-cia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T12:26:07+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cee4085f5407a5305b9f9.jpg" style="margin-right: 10px;" /> President Vladimir Putin isn‚Äôt likely to have mandated the killing of opposition figure Alexey Navalny, the Wall Street Journal has reported <br /><a href="https://www.rt.com/news/596674-navalny-putin-us-cia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Germany cracks down on pro-Palestine protesters (VIDEO)
 - [https://www.rt.com/news/596671-germany-palestine-protester-camp/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596671-germany-palestine-protester-camp/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T11:33:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cde7d2030274cf61ffdfc.jpg" style="margin-right: 10px;" /> Berlin police arrested some 75 people after clashing with demonstrators camping outside the Chancellery <br /><a href="https://www.rt.com/news/596671-germany-palestine-protester-camp/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Polish foreign minister rebukes president over US nukes remark
 - [https://www.rt.com/news/596670-polish-president-not-authorized-us-nukes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596670-polish-president-not-authorized-us-nukes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T11:03:46+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cda212030274d3e3dc636.jpg" style="margin-right: 10px;" /> President Andrzej Duda should not have spoken publicly about hosting US weapons on Polish soil, the foreign minister says <br /><a href="https://www.rt.com/news/596670-polish-president-not-authorized-us-nukes/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Another African state considers closing French military base - media
 - [https://www.rt.com/africa/596664-gabon-considers-closing-french-military-base/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/596664-gabon-considers-closing-french-military-base/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T10:40:39+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cd37b85f54031cf6e5f91.jpg" style="margin-right: 10px;" /> A proposal for Gabon to review its security ties with France Gabon has reportedly been submitted to the military government <br /><a href="https://www.rt.com/africa/596664-gabon-considers-closing-french-military-base/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Musk doubts White House Ukraine claims
 - [https://www.rt.com/news/596660-musk-ukraine-victory-condition/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596660-musk-ukraine-victory-condition/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T10:22:35+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cbd5185f54076804d72b9.jpg" style="margin-right: 10px;" /> Elon Musk has reiterated his doubts about White House claims that Ukraine can win the conflict with Russia <br /><a href="https://www.rt.com/news/596660-musk-ukraine-victory-condition/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## UK blocked Ukraine peace deal ‚Äì Moscow
 - [https://www.rt.com/russia/596665-kremlin-istanbul-peace-deal/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/596665-kremlin-istanbul-peace-deal/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T10:07:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662ccc3285f5407a5305b9e1.jpg" style="margin-right: 10px;" /> Kremlin spokesman Dmitry Peskov has denied claims in the German press that the Istanbul peace negotiations broke down because of Moscow <br /><a href="https://www.rt.com/russia/596665-kremlin-istanbul-peace-deal/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US economy could be headed for stagflation ‚Äì Business Insider
 - [https://www.rt.com/business/596658-us-economy-stagflation-slow-growth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/596658-us-economy-stagflation-slow-growth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T10:01:27+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662ccc222030274d084c3ef1.jpg" style="margin-right: 10px;" /> The American economy could face stagflation as growth has been much weaker than expected, Business Insider reports <br /><a href="https://www.rt.com/business/596658-us-economy-stagflation-slow-growth/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Spain to send Patriot missiles to Ukraine
 - [https://www.rt.com/news/596663-spain-patriot-missiles-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596663-spain-patriot-missiles-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T09:31:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cbf6620302706334762e9.jpg" style="margin-right: 10px;" /> Kiev is going to get ‚Äúa set‚Äù of missiles for the Patriot air defense system, Spanish Defense Minister Margarita Robles has said <br /><a href="https://www.rt.com/news/596663-spain-patriot-missiles-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Tesla Autopilot feature linked to hundreds of crashes and 14 deaths
 - [https://www.rt.com/news/596662-tesla-autopilot-linked-crash-investigation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596662-tesla-autopilot-linked-crash-investigation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T09:27:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cbf2c2030274d3e3dc628.jpg" style="margin-right: 10px;" /> US auto-safety regulators have linked Tesla‚Äôs Autopilot system to hundreds of crashes and over a dozen deaths <br /><a href="https://www.rt.com/news/596662-tesla-autopilot-linked-crash-investigation/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Details emerge of failed Russia-Ukraine peace treaty ‚Äì Welt
 - [https://www.rt.com/russia/596659-russia-ukraine-peace-deal-2022/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/596659-russia-ukraine-peace-deal-2022/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T08:34:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662cb70f2030274cf61ffdd2.jpg" style="margin-right: 10px;" /> Russia and Ukraine were close to a peace deal in 2022, under which Kiev was ready to commit to neutral status, Welt has reported <br /><a href="https://www.rt.com/russia/596659-russia-ukraine-peace-deal-2022/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## CNN pressures Blinken on Chinese ‚Äòelection interference‚Äô
 - [https://www.rt.com/news/596656-blinken-cnn-election-interferense/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596656-blinken-cnn-election-interferense/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T08:07:37+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662caecb203027457e7c3675.jpg" style="margin-right: 10px;" /> US Secretary of State Antony Blinken claims there‚Äôs ‚Äúevidence‚Äù of Chinese attempts to meddle in US elections <br /><a href="https://www.rt.com/news/596656-blinken-cnn-election-interferense/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel rebuffs US call to investigate mass graves in Gaza ‚Äì Politico
 - [https://www.rt.com/news/596655-gaza-mass-graves-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596655-gaza-mass-graves-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T07:43:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662ca70785f54079916021c7.jpg" style="margin-right: 10px;" /> Accusations against Israeli troops of torture and executions are ‚Äúfake news,‚Äù an IDF spokesman has told Politico <br /><a href="https://www.rt.com/news/596655-gaza-mass-graves-israel/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Drone raid on Russian energy infrastructure repelled
 - [https://www.rt.com/russia/596652-drone-raid-on-russian-energy-repelled/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/596652-drone-raid-on-russian-energy-repelled/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T05:36:17+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662c8e0e20302744f23aff0e.jpg" style="margin-right: 10px;" /> Ukrainian UAVs attacked several Russian oil refineries in Krasnodar Region on Saturday <br /><a href="https://www.rt.com/russia/596652-drone-raid-on-russian-energy-repelled/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US won‚Äôt sanction IDF despite ‚Äògross human rights violations‚Äô ‚Äì media
 - [https://www.rt.com/news/596651-us-idf-sanctions-human-rights/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596651-us-idf-sanctions-human-rights/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T04:01:07+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662c787620302737757c3ca6.jpg" style="margin-right: 10px;" /> Washington has determined that three IDF units had committed ‚Äúgross human rights violations,‚Äù but will keep military aid to Israel flowing <br /><a href="https://www.rt.com/news/596651-us-idf-sanctions-human-rights/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Violent tornadoes leave trail of catastrophic damage in US (VIDEOS)
 - [https://www.rt.com/news/596650-tornado-destruction-nebraska-iowa/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/596650-tornado-destruction-nebraska-iowa/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-04-27T01:55:15+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.04/thumbnail/662c5a2885f54076804d727a.jpg" style="margin-right: 10px;" /> Multiple powerful tornadoes have ripped through the central US, leaving hundreds of houses badly damaged or completely destroyed <br /><a href="https://www.rt.com/news/596650-tornado-destruction-nebraska-iowa/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

