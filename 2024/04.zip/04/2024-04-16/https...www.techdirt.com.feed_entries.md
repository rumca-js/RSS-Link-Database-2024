# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## Roku Eyes Patent That Would Inject Ads Into… Everything
 - [https://www.techdirt.com/2024/04/16/roku-eyes-patent-that-would-inject-ads-into-everything](https://www.techdirt.com/2024/04/16/roku-eyes-patent-that-would-inject-ads-into-everything)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-16T22:32:03+00:00

When last we checked in with our friends at Roku, they had made the unpopular decision to effectively &#8220;brick&#8221; user streaming hardware and television sets if users didn&#8217;t agree to a typically draconian end user agreement that effectively bans your legal right to sue the company. Eroding your legal rights using fine print isn&#8217;t new; [&#8230;]

## Techdirt Podcast Episode 387: Abolishing Section 230 Would Abolish Wikipedia
 - [https://www.techdirt.com/2024/04/16/techdirt-podcast-episode-387-abolishing-section-230-would-abolish-wikipedia](https://www.techdirt.com/2024/04/16/techdirt-podcast-episode-387-abolishing-section-230-would-abolish-wikipedia)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-16T20:30:00+00:00

Last week, the House Energy and Commerce Committee had a hearing all about Section 230, in which they didn&#8217;t even attempt to find a witness pointing out its benefits. Among the many organizations that could have provided that vital perspective is the Wikimedia Foundation (as seen in three excellent posts on Medium), and this week [&#8230;]

## Internet Child Safety Laws Will Lead To Helpful Sites Being Blocked; Just Look At Schools
 - [https://www.techdirt.com/2024/04/16/internet-child-safety-laws-will-lead-to-helpful-sites-being-blocked-just-look-at-schools](https://www.techdirt.com/2024/04/16/internet-child-safety-laws-will-lead-to-helpful-sites-being-blocked-just-look-at-schools)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-16T19:00:03+00:00

Various states and the federal government are proposing and passing a wide variety of &#8220;kid safety&#8221; laws. Almost all of them pretend that they’re about conduct of social media sites and not about the content on them, but when you boil down what the underlying concerns are, they all end up actually being about the [&#8230;]

## Congress Decides To Give FBI Another Free Pass On Section 702 Abuses
 - [https://www.techdirt.com/2024/04/16/congress-decides-to-give-fbi-another-free-pass-on-section-702-abuses](https://www.techdirt.com/2024/04/16/congress-decides-to-give-fbi-another-free-pass-on-section-702-abuses)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-16T17:55:59+00:00

It looks like we&#8217;re headed to several more years of the same old abuse. The House vote on Section 702 reauthorization &#8212; something postponed several times since EOY2023 due to infighting and out-fighting &#8212; has indicated that whatever concerns people might have about warrantless access to US persons&#8217; communications can be handled the next time [&#8230;]

## Daily Deal: The Award-Winning Luminar Neo Bundle
 - [https://www.techdirt.com/2024/04/16/daily-deal-the-award-winning-luminar-neo-bundle-7](https://www.techdirt.com/2024/04/16/daily-deal-the-award-winning-luminar-neo-bundle-7)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-16T17:50:59+00:00

Luminar Neo is an easy-to-use photo editing software that empowers photography lovers to express the beauty they imagined using innovative AI-driven tools. Luminar Neo was built from the ground up to be different from previous Luminar editors. It keeps your favorite LuminarAI tools and expands your arsenal with more state-of-the-art technologies and important changes at [&#8230;]

## Blame Silly Politicians For Google Starting To Block News Sites In California
 - [https://www.techdirt.com/2024/04/16/google-starts-blocking-some-news-sites-in-california-blame-silly-politicians-for-pushing-bad-laws](https://www.techdirt.com/2024/04/16/google-starts-blocking-some-news-sites-in-california-blame-silly-politicians-for-pushing-bad-laws)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-16T16:26:00+00:00

That thing is happening again, where politicians are pushing a bad law that will benefit Rupert Murdoch, while harming the public. Rather than blaming Murdoch or the politicians pushing the law, they’re blaming “big tech” for actually responding to the law accordingly. Because that’s easier. But it’s wrong. In this case, it’s California’s terrible attempt [&#8230;]

## Telecoms To Get $45 Billion In Taxpayer Broadband Subsidies, But Are Whining Because They Might Have To Deliver Affordable Broadband To A Few Poor People
 - [https://www.techdirt.com/2024/04/16/telecoms-to-get-45-billion-in-taxpayer-broadband-subsidies-but-are-whining-because-they-might-have-to-deliver-affordable-broadband-to-a-few-poor-people](https://www.techdirt.com/2024/04/16/telecoms-to-get-45-billion-in-taxpayer-broadband-subsidies-but-are-whining-because-they-might-have-to-deliver-affordable-broadband-to-a-few-poor-people)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-16T12:23:00+00:00

The 2021 infrastructure bill is throwing more than $42 billion at America&#8217;s mediocre broadband networks. And while a lot of that money will be put to good use shoring up fiber, a lot of it is being dumped in the laps of regional monopolies with a long, long history of taking subsidies in exchange for [&#8230;]

## Bandai Namco Sends Threat Letter To Modding Site Over Supposed Trademark Issues
 - [https://www.techdirt.com/2024/04/15/bandai-namco-sends-threat-letter-to-modding-site-over-supposed-trademark-issues](https://www.techdirt.com/2024/04/15/bandai-namco-sends-threat-letter-to-modding-site-over-supposed-trademark-issues)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-04-16T03:02:11+00:00

Here we go again. There seems to be a thing happening among a select few big name video game publishers that have decided for some reason that they want to go to war with their own modding communities. The reasons for doing so vary, but they all amount to wanting to strictly control the experience [&#8230;]

