# Source:CodeProject Latest Articles, URL:https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1, language:en-us

## Java Code Change Impact Analysis - Introduction to JCCI
 - [https://www.codeproject.com/Tips/5380674/Java-Code-Change-Impact-Analysis-Introduction-to-J](https://www.codeproject.com/Tips/5380674/Java-Code-Change-Impact-Analysis-Introduction-to-J)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-04-16T19:37:00+00:00

Java Code Change Impact Analysis

## .NET 8 â€” Transactional Outbox Pattern With EF Core
 - [https://www.codeproject.com/Articles/5380671/NET-8-Transactional-Outbox-Pattern-With-EF-Core](https://www.codeproject.com/Articles/5380671/NET-8-Transactional-Outbox-Pattern-With-EF-Core)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-04-16T13:48:00+00:00

In this project, I've implemented the Transactional Outbox Pattern using EF Core.

## ASPNETFilters
 - [https://www.codeproject.com/Articles/5380672/ASPNETFilters](https://www.codeproject.com/Articles/5380672/ASPNETFilters)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-04-16T12:03:00+00:00

Filters are integral components of every .NET API. In this post, I aim to delve into the various types of filters accessible in .NET Core.

## EFTransactionalOutbox
 - [https://www.codeproject.com/Articles/5380671/EFTransactionalOutbox](https://www.codeproject.com/Articles/5380671/EFTransactionalOutbox)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-04-16T12:03:00+00:00

In this project, I've implemented the Transactional Outbox Pattern using EF Core.

