# Source:Times of India, URL:https://timesofindia.indiatimes.com/rssfeedstopstories.cms, language:en-gb

## Biggest stellar black hole in Milky Way found ‘by chance
 - [https://timesofindia.indiatimes.com/world/europe/astronomers-find-biggest-stellar-black-hole-in-milky-way-galaxy-by-chance/articleshow/109359372.cms](https://timesofindia.indiatimes.com/world/europe/astronomers-find-biggest-stellar-black-hole-in-milky-way-galaxy-by-chance/articleshow/109359372.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T23:17:49+00:00



## Sarika first Keralite with cerebral palsy to clear UPSC
 - [https://timesofindia.indiatimes.com/india/sarika-first-keralite-with-cerebral-palsy-to-clear-upsc/articleshow/109357888.cms](https://timesofindia.indiatimes.com/india/sarika-first-keralite-with-cerebral-palsy-to-clear-upsc/articleshow/109357888.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T22:36:22+00:00



## Was praying for rank in top 70, no 1 a surprise: UPSC topper
 - [https://timesofindia.indiatimes.com/india/was-praying-for-rank-in-top-70-number-1-a-surprise-upsc-topper-aditya-srivastava/articleshow/109357677.cms](https://timesofindia.indiatimes.com/india/was-praying-for-rank-in-top-70-number-1-a-surprise-upsc-topper-aditya-srivastava/articleshow/109357677.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T22:30:08+00:00



## Trump On Trial: Why it’s gonna get stormy
 - [https://timesofindia.indiatimes.com/world/us/trump-on-trial-why-its-gonna-get-stormy/articleshow/109356800.cms](https://timesofindia.indiatimes.com/world/us/trump-on-trial-why-its-gonna-get-stormy/articleshow/109356800.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T22:04:57+00:00



## India aims to achieve debris-free space missions by 2030: Isro chief
 - [https://timesofindia.indiatimes.com/india/india-aims-to-achieve-debris-free-space-missions-by-2030-isro-chief/articleshow/109356772.cms](https://timesofindia.indiatimes.com/india/india-aims-to-achieve-debris-free-space-missions-by-2030-isro-chief/articleshow/109356772.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T22:02:29+00:00



## IITian Aditya Srivastava tops civils exam; two women among top 5
 - [https://timesofindia.indiatimes.com/india/iitian-aditya-srivastava-tops-civils-exam-two-women-among-top-5/articleshow/109356673.cms](https://timesofindia.indiatimes.com/india/iitian-aditya-srivastava-tops-civils-exam-two-women-among-top-5/articleshow/109356673.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T21:43:40+00:00



## Ramdev, aide say sorry to SC, offer to issue public apology
 - [https://timesofindia.indiatimes.com/india/ramdev-aide-say-sorry-to-sc-offer-to-issue-public-apology/articleshow/109356261.cms](https://timesofindia.indiatimes.com/india/ramdev-aide-say-sorry-to-sc-offer-to-issue-public-apology/articleshow/109356261.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T21:38:07+00:00

Baba Ramdev and his disciple Balkrishna appeared before the Supreme Court and admitted to giving misleading advertisements about Patanjali products, apologizing with folded hands. The court criticized their actions, stating there was a procedure to get products recognized by a competent authority and admonishing them for irresponsible behavior. Despite their defense of ignorance of the law, the court reminded them of previous orders they had violated.

## RBI introduces fresh guidelines for online payment merchants
 - [https://timesofindia.indiatimes.com/business/india-business/rbi-diktat-to-payment-cos-on-merchants/articleshow/109356362.cms](https://timesofindia.indiatimes.com/business/india-business/rbi-diktat-to-payment-cos-on-merchants/articleshow/109356362.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T21:34:21+00:00

RBI tightens scrutiny on online payment sector, introducing new guidelines with varying due diligence levels for merchants. Payment aggregators must track merchant-employed agents. Data storage restrictions start Aug 1, 2025.

## PM Modi: ‘I’m indebted to Constitution, it’s article of faith for us'
 - [https://timesofindia.indiatimes.com/india/pm-modi-counters-opposition-im-indebted-to-constitution-its-article-of-faith-for-us/articleshow/109356230.cms](https://timesofindia.indiatimes.com/india/pm-modi-counters-opposition-im-indebted-to-constitution-its-article-of-faith-for-us/articleshow/109356230.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T21:27:33+00:00



## Zee withdraws Sony merger plea at NCLT
 - [https://timesofindia.indiatimes.com/business/india-business/zee-withdraws-sony-merger-plea-at-nclt/articleshow/109356210.cms](https://timesofindia.indiatimes.com/business/india-business/zee-withdraws-sony-merger-plea-at-nclt/articleshow/109356210.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T21:18:59+00:00

Zee withdraws merger app against Sony, pursuing $90M claim in Singapore arbitration. Spent Rs 367 crore on failed deal. Focuses on cost-cutting measures like workforce rationalization, MD's pay cut amid industry consolidation concerns.

## In SC, govt praises PV, Manmohan for ending ‘licence raj’
 - [https://timesofindia.indiatimes.com/india/in-sc-government-praises-pv-narasimha-rao-manmohan-singh-for-ending-licence-raj-opening-economy/articleshow/109356193.cms](https://timesofindia.indiatimes.com/india/in-sc-government-praises-pv-narasimha-rao-manmohan-singh-for-ending-licence-raj-opening-economy/articleshow/109356193.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T21:16:31+00:00

The BJP-led NDA government praised former PM Narasimha Rao and his finance minister Manmohan Singh for their role in economic liberalization in 1991. Solicitor General Tushar Mehta highlighted their efforts in the Supreme Court, stating that while many laws were liberalized, the Industry (Development and Regulation) Act, 1951, remained unchanged, giving the government overarching control over industries.

## Higher the Covid toll, greater the faith in gold
 - [https://timesofindia.indiatimes.com/business/india-business/higher-the-covid-toll-greater-the-faith-in-gold/articleshow/109356187.cms](https://timesofindia.indiatimes.com/business/india-business/higher-the-covid-toll-greater-the-faith-in-gold/articleshow/109356187.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T21:13:25+00:00

Gold savings increased in Covid vulnerable districts, while financial assets decreased. Poorer households allocated more to gold. Higher financial access reduced gold allocation. 'Flight to safety' trend seen. Insights from International Review of Economics &amp; Finance and RBI report.

## Won’t get into action by central agencies, says EC
 - [https://timesofindia.indiatimes.com/india/wont-get-into-action-by-central-agencies-says-ec/articleshow/109356151.cms](https://timesofindia.indiatimes.com/india/wont-get-into-action-by-central-agencies-says-ec/articleshow/109356151.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T21:06:55+00:00

The Election Commission released its report card on the enforcement of the model code of conduct (MCC) during the first month of elections. It decided against acting on opposition parties' requests to stop alleged misuse of central agencies like CBI, ED, and NIA, citing a commitment to not interfere with the legal process.

## Bullet to ballot: Democracy's giant strides in Maha's maoist heartland
 - [https://timesofindia.indiatimes.com/india/bullet-to-ballot-democracys-giant-strides-in-mahas-maoist-heartland/articleshow/109356081.cms](https://timesofindia.indiatimes.com/india/bullet-to-ballot-democracys-giant-strides-in-mahas-maoist-heartland/articleshow/109356081.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:48:37+00:00



## We know flaws of ballot papers, SC tells EVM critics
 - [https://timesofindia.indiatimes.com/india/we-know-flaws-of-ballot-papers-sc-tells-evm-critics/articleshow/109355885.cms](https://timesofindia.indiatimes.com/india/we-know-flaws-of-ballot-papers-sc-tells-evm-critics/articleshow/109355885.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:37:56+00:00



## High court upholds rule to retire below-par judges at 50
 - [https://timesofindia.indiatimes.com/india/high-court-upholds-rule-to-retire-below-par-judges-at-50/articleshow/109355878.cms](https://timesofindia.indiatimes.com/india/high-court-upholds-rule-to-retire-below-par-judges-at-50/articleshow/109355878.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:37:34+00:00

Gujarat high court supports compulsory retirement of non-performing district judges at 50, emphasizing judges' representation of the State and sovereign judicial power, distinct from other government services.

## Gratifications to voters will kill democracy: HC
 - [https://timesofindia.indiatimes.com/india/gratifications-to-voters-will-kill-democracy-hc/articleshow/109355800.cms](https://timesofindia.indiatimes.com/india/gratifications-to-voters-will-kill-democracy-hc/articleshow/109355800.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:26:10+00:00



## Centre sets up panel to address queer community concerns
 - [https://timesofindia.indiatimes.com/india/following-sc-directive-centre-sets-up-panel-to-address-queer-community-concerns/articleshow/109355797.cms](https://timesofindia.indiatimes.com/india/following-sc-directive-centre-sets-up-panel-to-address-queer-community-concerns/articleshow/109355797.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:25:45+00:00

Centre forms committee to address queer community issues after SC's ruling on same-sex marriages. Committee chaired by Union cabinet secretary. It includes members from various ministries and is mandated to ensure no discrimination, violence, or involuntary medical treatment against queer persons.

## 50% of Lok Sabha candidates of both NCP factions are turncoats
 - [https://timesofindia.indiatimes.com/india/50-of-lok-sabha-candidates-of-both-ncp-factions-are-turncoats/articleshow/109355772.cms](https://timesofindia.indiatimes.com/india/50-of-lok-sabha-candidates-of-both-ncp-factions-are-turncoats/articleshow/109355772.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:18:51+00:00



## Manipur shifts Churachandpur SP days before Phase-1 polls
 - [https://timesofindia.indiatimes.com/india/manipur-shifts-churachandpur-sp-days-before-phase-1-polls/articleshow/109355752.cms](https://timesofindia.indiatimes.com/india/manipur-shifts-churachandpur-sp-days-before-phase-1-polls/articleshow/109355752.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:13:54+00:00

Gunmen attacked fuel tankers in Tamenglong, causing oil spill and injuring a driver. The incident prompted reinforcement before Manipur's Lok Sabha elections. Constable suspension resulted in mob violence, leading to SP transfer.

## 'Jos did what he...': RR skipper Sanju Samson
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/jos-did-what-he-rr-skipper-sanju-samson-says-buttlers-knock-should-go-right-on-top/articleshow/109355715.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/jos-did-what-he-rr-skipper-sanju-samson-says-buttlers-knock-should-go-right-on-top/articleshow/109355715.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:10:26+00:00

Facing the daunting task of chasing down KKR's imposing total, powered by Sunil Narine's scintillating 109 off 56 deliveries, Jos Buttler emerged as the game-changer for the Rajasthan Royals. Despite the team's dire situation at 121/6 in the 13th over, Buttler remained undeterred, orchestrating a breathtaking comeback. With the pressure mounting and the required run rate soaring, Buttler exhibited nerves of steel as he steered the Royals past the mammoth target of 224 on the very last ball of the game.

## 'Operation CMF': Navy seizes 940kg of drugs in Arabian Sea
 - [https://timesofindia.indiatimes.com/india/in-1st-op-as-part-of-cmf-navy-seizes-940kg-of-drugs-in-arabian-sea/articleshow/109355727.cms](https://timesofindia.indiatimes.com/india/in-1st-op-as-part-of-cmf-navy-seizes-940kg-of-drugs-in-arabian-sea/articleshow/109355727.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:09:46+00:00

Indian warship seized 940 kg drugs in Arabian Sea under Operation Crimson Barracuda. INS Talwar seized methamphetamines, hash, heroin. CTF-150 commander commended Indian Navy for disrupting criminal activities.

## Centre determined to end Red menace: Shah on C'garh op
 - [https://timesofindia.indiatimes.com/india/centre-determined-to-end-red-menace-amit-shah-on-chhattisgarh-op/articleshow/109355713.cms](https://timesofindia.indiatimes.com/india/centre-determined-to-end-red-menace-amit-shah-on-chhattisgarh-op/articleshow/109355713.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T20:04:56+00:00

Amit Shah commended security forces for eliminating 29 Naxals in Chhattisgarh, vowing to eradicate Naxalism under PM Modi. Injuries to personnel emphasize the government's efforts for a Naxal-free future.

## EC bars Surjewala for 48 hours over Hema remark
 - [https://timesofindia.indiatimes.com/india/in-first-campaign-ban-this-poll-ec-bars-surjewala-for-48-hours-over-hema-remark/articleshow/109355662.cms](https://timesofindia.indiatimes.com/india/in-first-campaign-ban-this-poll-ec-bars-surjewala-for-48-hours-over-hema-remark/articleshow/109355662.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:53:48+00:00



## No irregularity in dissolution of Maulana Azad Foundation: HC
 - [https://timesofindia.indiatimes.com/india/no-irregularity-in-dissolution-of-maulana-azad-foundation-hc/articleshow/109355643.cms](https://timesofindia.indiatimes.com/india/no-irregularity-in-dissolution-of-maulana-azad-foundation-hc/articleshow/109355643.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:50:53+00:00



## Axe envoy to Ireland for acting like BJP 'apparatchik': Cong
 - [https://timesofindia.indiatimes.com/india/axe-envoy-to-ireland-for-acting-like-bjp-apparatchik-congress/articleshow/109355601.cms](https://timesofindia.indiatimes.com/india/axe-envoy-to-ireland-for-acting-like-bjp-apparatchik-congress/articleshow/109355601.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:47:29+00:00

Congress demands dismissal of Indian ambassador for political comments. Jairam Ramesh criticizes Mishra's conduct. Two professionals, Prem Kumar Choudhary and Manish Yadav, join Congress ahead of Lok Sabha elections.

## Cong 'guarantee cards' amount to bribery: BJP to EC
 - [https://timesofindia.indiatimes.com/india/congress-guarantee-cards-amount-to-bribery-stop-distribution-bjp-to-ec/articleshow/109355544.cms](https://timesofindia.indiatimes.com/india/congress-guarantee-cards-amount-to-bribery-stop-distribution-bjp-to-ec/articleshow/109355544.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:43:49+00:00

BJP urged the Election Commission to halt Congress' 'Ghar Ghar Guarantee', citing bribery concerns and the risk of favoring registered supporters over others. BJP claimed that such an initiative was akin to manipulation of voters' trust and misrepresentation of guarantee cards as legitimate instruments for accessing promised "freebies, largesse and utopian promises".

## 'Let's not go by religion or caste': SC on mob violence, lynchings
 - [https://timesofindia.indiatimes.com/india/lets-not-make-it-communal-sc-on-mob-violence-lynchings/articleshow/109355435.cms](https://timesofindia.indiatimes.com/india/lets-not-make-it-communal-sc-on-mob-violence-lynchings/articleshow/109355435.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:39:04+00:00

Supreme Court intervenes in mob lynching hearing, urging lawyers to avoid bringing religion or caste into proceedings and maintain discipline. NFIW highlights Muslim lynching, Gujarat govt calls for focus on all victims regardless of community.

## PM Modi appeals for 'special' Ram Navami, Didi sees BJP riot plot
 - [https://timesofindia.indiatimes.com/india/pm-modi-appeals-for-special-ram-navami-didi-sees-bjp-riot-plot/articleshow/109355380.cms](https://timesofindia.indiatimes.com/india/pm-modi-appeals-for-special-ram-navami-didi-sees-bjp-riot-plot/articleshow/109355380.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:34:08+00:00

Ram Navami gains spotlight in Bengal's election campaigns with contrasting views from PM Modi and Mamata Banerjee. Trinamool designates it a holiday, PM mentions Ayodhya's idol installation, accuses Trinamool of hindering celebrations.

## After Kejriwal, wife no, 2 on AAP list of Gujarat star campaigners
 - [https://timesofindia.indiatimes.com/india/after-kejriwal-wife-is-number-2-on-aap-list-of-gujarat-star-campaigners/articleshow/109355354.cms](https://timesofindia.indiatimes.com/india/after-kejriwal-wife-is-number-2-on-aap-list-of-gujarat-star-campaigners/articleshow/109355354.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:29:20+00:00

Sunita Kejriwal, wife of Delhi Chief Minister Arvind Kejriwal, is set to campaign for the Aam Aadmi Party (AAP) in the Lok Sabha polls in Gujarat, despite Kejriwal's arrest in a money laundering case. She has emerged as a prominent figure in AAP's campaigning efforts, reading out messages from her husband who is currently in custody.

## 'Don't have idea...': KKR skipper Iyer after losing a thriller vs RR
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/dont-have-idea-kkr-skipper-shreyas-iyer-after-losing-a-thriller-against-rr/articleshow/109355346.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/dont-have-idea-kkr-skipper-shreyas-iyer-after-losing-a-thriller-against-rr/articleshow/109355346.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:28:57+00:00

In his post-match remarks, Kolkata Knight Riders skipper Shreyas Iyer conveyed the roller-coaster of emotions experienced by the team, particularly in the tense final moments of the game. He admitted that they hadn't anticipated finding themselves in such a closely contested situation, which made the outcome even more challenging to process. Iyer also acknowledged that it was a bitter pill to swallow for his team.

## Pick 6 VCs from list given by state govt: SC to Bengal govt
 - [https://timesofindia.indiatimes.com/india/pick-6-vcs-from-list-given-by-state-government-supreme-court-to-bengal-government/articleshow/109355340.cms](https://timesofindia.indiatimes.com/india/pick-6-vcs-from-list-given-by-state-government-supreme-court-to-bengal-government/articleshow/109355340.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:25:46+00:00

SC instructs West Bengal governor to appoint six vice-chancellors from state govt's list. Conflict with Trinamool Congress govt persists. SC may establish a search committee for future appointments.

## Shivaji's descendant Chhatrapati Udayanraje Bhosale in BJP's 12th list
 - [https://timesofindia.indiatimes.com/india/shivajis-descendant-chhatrapati-udayanraje-bhosale-in-bjps-12th-list/articleshow/109355314.cms](https://timesofindia.indiatimes.com/india/shivajis-descendant-chhatrapati-udayanraje-bhosale-in-bjps-12th-list/articleshow/109355314.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:23:17+00:00



## Discrepancy in WB cops' 2022 blast FIR may not be 'accidental': NIA
 - [https://timesofindia.indiatimes.com/india/nia-discrepancy-in-wb-cops-2022-blast-fir-may-not-be-accidental/articleshow/109355281.cms](https://timesofindia.indiatimes.com/india/nia-discrepancy-in-wb-cops-2022-blast-fir-may-not-be-accidental/articleshow/109355281.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:15:37+00:00

NIA investigates Bhupatinagar blast FIR time conflict, suspecting alteration. Witness statements differ, raising doubts on FIR accuracy. Rajkumar Manna, Buddhadeb Manna, Biswajit Gayen involved. House explosion details, hospital deaths scrutinized alongside call records.

## 'Guys like Dhoni & Kohli...': Buttler reveals Sangakkara's advice
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/guys-like-dhoni-and-kohli-jos-buttler-reveals-sangakkaras-advice-after-win-over-kkr/articleshow/109355151.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/guys-like-dhoni-and-kohli-jos-buttler-reveals-sangakkaras-advice-after-win-over-kkr/articleshow/109355151.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T19:02:07+00:00

Facing a daunting target of 224 runs, RR found themselves in a precarious position at 121-6 in the 13th over. However, England's Jos Buttler showcased remarkable resilience and determination, unleashing a sensational 60-ball innings to guide his team to victory with just one ball to spare at Kolkata's iconic Eden Gardens.

## Buttler ton powers Rajasthan Royals to record IPL chase
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/kkr-vs-rr-ipl-2024-highlights-jos-buttler-ton-powers-rajasthan-royals-to-record-ipl-chase/articleshow/109354655.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/kkr-vs-rr-ipl-2024-highlights-jos-buttler-ton-powers-rajasthan-royals-to-record-ipl-chase/articleshow/109354655.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T18:48:12+00:00

Jos Buttler delivered an outstanding performance, smashing an unbeaten 107 runs to outshine Sunil Narine's maiden T20 century as Rajasthan Royals secured a thrilling victory over Kolkata Knight Riders on Tuesday, sealing a joint-record IPL chase on the final ball. This remarkable feat saw Rajasthan equaling their own record set in 2020 when they chased down 224 against Kings XI Punjab in Sharjah.

## Laptops have replaced stones in hands of J&K youth: Amit Shah
 - [https://timesofindia.indiatimes.com/india/jks-love-for-modi-will-let-lotus-bloom-amit-shah/articleshow/109354928.cms](https://timesofindia.indiatimes.com/india/jks-love-for-modi-will-let-lotus-bloom-amit-shah/articleshow/109354928.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T18:43:24+00:00



## Buttler goes past Gayle, becomes second highest centurion in IPL
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/jos-buttler-goes-past-chris-gayle-becomes-second-highest-centurion-in-ipl/articleshow/109354890.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/jos-buttler-goes-past-chris-gayle-becomes-second-highest-centurion-in-ipl/articleshow/109354890.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T18:36:20+00:00

Once again, Rajasthan Royals' Jos Buttler demonstrated his batting brilliance by storming his way to a spectacular unbeaten century, propelling himself to the second position in the all-time list of most hundreds in the history of the Indian Premier League (IPL).

## Ram Navami Suryatilak livestream -- where and how to watch
 - [https://timesofindia.indiatimes.com/technology/tech-news/ayodhya-ram-mandir-ram-navami-mahotsav-livestream-where-and-how-to-watch-mobile-phone-advisory/articleshow/109354854.cms](https://timesofindia.indiatimes.com/technology/tech-news/ayodhya-ram-mandir-ram-navami-mahotsav-livestream-where-and-how-to-watch-mobile-phone-advisory/articleshow/109354854.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T18:32:32+00:00

Ram Navami at Ram Mandir in Ayodhya will have extended hours from 3.30 a.m. to 11 p.m. with special rituals, Bhog offerings, LED screen broadcasts, and Prasad distribution, requesting devotees not to bring mobile phones.

## 'China seeks to subvert int'l order by taking over UN': Whistleblower
 - [https://timesofindia.indiatimes.com/world/china/china-seeks-to-subvert-rules-based-international-order-by-taking-over-un-whistleblower/articleshow/109354749.cms](https://timesofindia.indiatimes.com/world/china/china-seeks-to-subvert-rules-based-international-order-by-taking-over-un-whistleblower/articleshow/109354749.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T18:30:36+00:00

A UN whistleblower, Emma Reilly, has submitted evidence claiming that China is working to reshape the rules-based international order to reflect its priorities. This includes influencing votes, editing reports to remove criticism, and even bribing UN officials. Reilly alleges that China pressures the UN to avoid discussing sensitive topics like human rights abuses in Xinjiang and suppresses dissent by targeting activists' families.

## Democratic sliding in India may prompt west to review cooperation: Report
 - [https://timesofindia.indiatimes.com/world/uk/democratic-sliding-in-india-could-prompt-west-to-review-its-cooperation-with-delhi-chatham-house/articleshow/109354780.cms](https://timesofindia.indiatimes.com/world/uk/democratic-sliding-in-india-could-prompt-west-to-review-its-cooperation-with-delhi-chatham-house/articleshow/109354780.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T18:29:21+00:00

Chatham House paper warns of India's democratic decline influencing Western cooperation, highlighting concerns about authoritarianism under Modi and Hindutva's impact on foreign policy, potentially leading to restrictions on collaboration in sensitive areas.

## Boat capsizes in Jhelum, 5 schoolkids among 6 dead
 - [https://timesofindia.indiatimes.com/india/6-drown-3-missing-as-boat-capsizes-in-jhelum-in-srinagar/articleshow/109354726.cms](https://timesofindia.indiatimes.com/india/6-drown-3-missing-as-boat-capsizes-in-jhelum-in-srinagar/articleshow/109354726.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T18:23:57+00:00

Six, including five schoolchildren, drowned in Jhelum River near Batwara, Srinagar. Boat capsized with 15 people at 8 am. 3 missing, 6 rescued. SDRF, NDRF, police, locals aiding in the rescue operation.

## What Israel says on claims of Indian YouTuber denied entry in nightclubs
 - [https://timesofindia.indiatimes.com/india/we-love-our-indian-brothers-and-sisters-israeli-embassy-on-claims-of-indian-youtuber-denied-entry-into-its-nightclubs/articleshow/109354390.cms](https://timesofindia.indiatimes.com/india/we-love-our-indian-brothers-and-sisters-israeli-embassy-on-claims-of-indian-youtuber-denied-entry-into-its-nightclubs/articleshow/109354390.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T17:54:19+00:00



## Best laptop under 60000: Top picks for personal, work, gaming needs
 - [https://timesofindia.indiatimes.com/hot-picks/best-laptop-under-60000-top-picks-for-your-personal-work-gaming-needs/articleshow/109342489.cms](https://timesofindia.indiatimes.com/hot-picks/best-laptop-under-60000-top-picks-for-your-personal-work-gaming-needs/articleshow/109342489.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T17:03:18+00:00

Want to buy a powerful and efficient laptop under 60000? We have handpicked and listed some of the best options that we have found online based on reviews and ratings. So, you can compare these laptops based on your needs and buy the right one easily.

## Narine credits Gambhir for his resurgence as KKR opener
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/he-gave-me-the-confidence-sunil-narine-credits-gautam-gambhir-for-his-resurgence-as-kkr-opener/articleshow/109353787.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/he-gave-me-the-confidence-sunil-narine-credits-gautam-gambhir-for-his-resurgence-as-kkr-opener/articleshow/109353787.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T17:01:22+00:00

Sunil Narine put up an exhilarating display of power-hitting, hammering his maiden century in T20 cricket as he helped Kolkata Knight Riders post 223/6 in the IPL 2024 match against Rajasthan Royals at the Eden Gardens on Tuesday.

## 700 inmates get job in hotel industry: Tihar prisons chief
 - [https://timesofindia.indiatimes.com/india/700-inmates-get-job-in-hotel-industry-1200-more-to-get-employed-soon-tihar-prisons-chief/articleshow/109353318.cms](https://timesofindia.indiatimes.com/india/700-inmates-get-job-in-hotel-industry-1200-more-to-get-employed-soon-tihar-prisons-chief/articleshow/109353318.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T16:26:48+00:00



## Watch: Avesh's theatrics after grabbing blinder
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-avesh-khan-grabs-a-one-handed-blinder-on-his-follow-through-takes-samsons-glove-and-shows-it-to-dressing-room/articleshow/109353303.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-avesh-khan-grabs-a-one-handed-blinder-on-his-follow-through-takes-samsons-glove-and-shows-it-to-dressing-room/articleshow/109353303.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T16:23:53+00:00

The remarkable feat didn't end there, as Avesh Khan, in a moment of flair, took skipper Sanju Samson's glove and theatrically displayed it towards the dressing room. This theatrics by Avesh transpired due to Samson's statement after their last match against GT: "I need to tell my fast bowlers that it's a bit easier to catch with the gloves instead of hands."

## UN diplomat's shirtless yoga video goes viral in China
 - [https://timesofindia.indiatimes.com/world/china/un-diplomats-shirtless-yoga-video-goes-viral-in-china/articleshow/109351477.cms](https://timesofindia.indiatimes.com/world/china/un-diplomats-shirtless-yoga-video-goes-viral-in-china/articleshow/109351477.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T16:22:21+00:00

UN Resident Coordinator for China, Siddharth Chatterjee, promotes deep breathing exercises for health benefits, overcoming challenges to achieve physical and mental balance through intense yoga routines and cold exposure.

## First for India: Vistara finances 2 aircraft from GIFT City
 - [https://timesofindia.indiatimes.com/business/india-business/first-for-india-vistara-finances-2-aircraft-from-gift-city/articleshow/109353228.cms](https://timesofindia.indiatimes.com/business/india-business/first-for-india-vistara-finances-2-aircraft-from-gift-city/articleshow/109353228.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T16:18:04+00:00

Tata Group's Vistara secures financing for two Airbus A320neos from GIFT City, bolstering the city's appeal for Indian carriers. Vistara joins Air India in tapping into GIFT City for aircraft leasing. This marks a significant move for Indian carriers seeking financial support from the city.

## Narine third KKR batter to achieve this feat in IPL
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/sunil-narine-becomes-third-kkr-player-to-achieve-this-feat-in-ipl/articleshow/109352877.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/sunil-narine-becomes-third-kkr-player-to-achieve-this-feat-in-ipl/articleshow/109352877.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T15:59:20+00:00

Sunil Narine, renowned for his crafty spin bowling, has also displayed his explosive batting prowess consistently throughout this IPL season. His ability to effortlessly clear the boundary ropes, particularly in the shortest format of the game, solidifies his reputation as a formidable force with the bat.

## Delhi LG lashes out at AAP minister in open letter
 - [https://timesofindia.indiatimes.com/india/delhi-l-g-accuses-aap-minister-of-exploiting-tragedy-for-narrow-and-partisan-political-gain/articleshow/109351858.cms](https://timesofindia.indiatimes.com/india/delhi-l-g-accuses-aap-minister-of-exploiting-tragedy-for-narrow-and-partisan-political-gain/articleshow/109351858.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T15:57:45+00:00

Delhi's LG VK Saxena criticized Atishi for politicizing a woman's water-related death. Earlier, Delhi minister Atishi sought an inquiry into water scarcity issues and asked LG to fire the CEO of the Delhi Jal Board. Saxena cited Economic Survey data and accused AAP of deceiving with free water. L-G accused of hindering Delhi Jal Board.

## How this WhatsApp chat filters will help users find msg faster
 - [https://timesofindia.indiatimes.com/technology/social/whatsapp-launches-chat-filters-heres-how-this-feature-will-help-users-find-messages-faster/articleshow/109352549.cms](https://timesofindia.indiatimes.com/technology/social/whatsapp-launches-chat-filters-heres-how-this-feature-will-help-users-find-messages-faster/articleshow/109352549.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T15:33:32+00:00

WhatsApp introduced chat filters to help users quickly find messages. Three filters segregate messages under All, Unread, and Groups menus, aiming for efficient organization and message retrieval.

## ‘NOT TRUE’: Ektaa refutes Smriti’s claim over bagging role in KSBKBT
 - [https://timesofindia.indiatimes.com/tv/news/hindi/ektaa-kapoor-refutes-smriti-iranis-claim-regarding-how-she-bagged-kyunki-saas-bhi-kabhi-bahu-thi-says-not-true/articleshow/109352207.cms](https://timesofindia.indiatimes.com/tv/news/hindi/ektaa-kapoor-refutes-smriti-iranis-claim-regarding-how-she-bagged-kyunki-saas-bhi-kabhi-bahu-thi-says-not-true/articleshow/109352207.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T15:15:00+00:00

Smriti Irani claimed astrologer aided her Tulsi role in Kyunki Saas Bhi Kabhi Bahu Thi, but Ektaa Kapoor refuted, asserting Monisha's audition selection. Ekta clarified on Instagram, contradicting Smriti's narrative.

## Luck eludes Iyer as he loses toss despite kissing coin
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/luck-finally-eludes-shreyas-iyer-kkr-skipper-loses-toss-against-rr-despite-kissing-coin-before-flipping/articleshow/109351589.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/luck-finally-eludes-shreyas-iyer-kkr-skipper-loses-toss-against-rr-despite-kissing-coin-before-flipping/articleshow/109351589.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T14:23:20+00:00

Shreyas Iyer, the captain of Kolkata Knight Riders, performed his usual pre-toss custom of planting a kiss on the coin before the IPL 2024 match against Rajasthan Royals at the renowned Eden Gardens on Tuesday. However, his superstitious practice failed to bring him fortune, as he ended up losing the coin toss.

## Iran’s conflict with Israel puts US ally Jordan on edge
 - [https://timesofindia.indiatimes.com/world/middle-east/irans-conflict-with-israel-puts-us-ally-jordan-on-edge/articleshow/109350716.cms](https://timesofindia.indiatimes.com/world/middle-east/irans-conflict-with-israel-puts-us-ally-jordan-on-edge/articleshow/109350716.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:49:24+00:00

Jordan has witnessed a period of unrest, with demonstrations in the capital city backing Hamas, the Iran-supported armed group engaged in conflict with Israel in Gaza since the beginning of October. The protests, which have resulted in Palestinian casualties and disrupted lives, have persisted for several weeks. Slogans such as 'all of Jordan is Hamas' and 'Jordanian day of rage' have caused alarm among security personnel, leading to numerous arrests.

## What if Fed rate hikes are sparking US economic boom?
 - [https://timesofindia.indiatimes.com/business/international-business/what-if-fed-rate-hikes-are-actually-sparking-us-economic-boom/articleshow/109350709.cms](https://timesofindia.indiatimes.com/business/international-business/what-if-fed-rate-hikes-are-actually-sparking-us-economic-boom/articleshow/109350709.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:48:48+00:00

The US economy continues to perform robustly, consistently creating a large number of jobs and surpassing the expectations of experts who had predicted an economic slowdown. Amid this economic strength, some Wall Street analysts are considering an unconventional theory regarding the impact of recent interest rate increases. They speculate that the rate hikes over the past two years might not be hindering economic growth but could be contributing to it.

## 'Don't be selective': SC warns petitioners over lynching plea
 - [https://timesofindia.indiatimes.com/india/dont-be-selective-sc-warns-petitioners-over-mob-lynching-and-cow-vigilantism-plea/articleshow/109348884.cms](https://timesofindia.indiatimes.com/india/dont-be-selective-sc-warns-petitioners-over-mob-lynching-and-cow-vigilantism-plea/articleshow/109348884.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:46:02+00:00

The Supreme Court directed petitioners to include all mob lynching cases, ensuring unbiased coverage. The court emphasized universal relief sought and deferred the hearing on rising vigilantism post-summer vacation. Hearing the plea filed by the women's federation, the bench also asked the state governments to responds within six months regarding the mob lynching and cow vigilantism cases.

## Govt issues important warning for these Google Chrome users
 - [https://timesofindia.indiatimes.com/technology/tech-news/government-issues-important-warning-for-these-google-chrome-users/articleshow/109350623.cms](https://timesofindia.indiatimes.com/technology/tech-news/government-issues-important-warning-for-these-google-chrome-users/articleshow/109350623.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:32:50+00:00

CERT-in issued a 'high' severity warning about security flaws in Google Chrome, allowing arbitrary code execution, DoS, sensitive data exposure, and login credential theft. Users urged to update Chrome immediately for protection.

## INS Talwar seizes 940 kgs of narcotics in operation Crimson Barracuda
 - [https://timesofindia.indiatimes.com/india/indian-navys-ins-talwar-seizes-940-kgs-of-narcotics-in-operation-crimson-barracuda/articleshow/109350501.cms](https://timesofindia.indiatimes.com/india/indian-navys-ins-talwar-seizes-940-kgs-of-narcotics-in-operation-crimson-barracuda/articleshow/109350501.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:31:28+00:00

Indian Naval warship INS Talwa intercepted a suspicious dhow on Monday and apprehended 940 Kg narcotics from it. The operation, executed with precision by the ship's specialist boarding teams and MARCOs (Marine Commandos), resulted in the confiscation of a staggering 940 kilograms of contraband narcotics. The seized drugs, indicative of illicit trafficking activities in the region, are being disposed of in accordance with the established procedures outlined in the CMF (Combined Maritime Forces) Standard Operating Procedures (SOPs).

## Read: TOP 5 entertainment news of the day
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/gunmen-in-salman-khan-firing-case-to-remain-in-police-custody-till-april-25-anushka-sharma-offers-glimpse-of-akaay-aamir-khan-filing-fir-against-fake-video-top-5-entertainment-news-of-the-day/articleshow/109348745.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/gunmen-in-salman-khan-firing-case-to-remain-in-police-custody-till-april-25-anushka-sharma-offers-glimpse-of-akaay-aamir-khan-filing-fir-against-fake-video-top-5-entertainment-news-of-the-day/articleshow/109348745.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:30:00+00:00

In Bollywood's bustling realm, today's highlights include: Salman Khan shooting suspects held till April 25, Aamir Khan's FIR against fake video, Anushka Sharma's airport glimpse of Akaay, 'Singham Again' delay, and Zeenat Aman's poised response to Mumtaz's live-in criticism, advocating for diverse perspectives.

## Remarks on Hema Malini: EC bans Surjewala from campaigning for 48 hrs
 - [https://timesofindia.indiatimes.com/india/ec-bans-congress-randeep-surjewala-from-campaigning-over-remarks-on-hema-malini/articleshow/109350254.cms](https://timesofindia.indiatimes.com/india/ec-bans-congress-randeep-surjewala-from-campaigning-over-remarks-on-hema-malini/articleshow/109350254.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:22:02+00:00



## How a Mumbai man lost Rs 45.69 lakh in share trading scam
 - [https://timesofindia.indiatimes.com/technology/tech-news/how-a-mumbai-man-lost-rs-45-69-lakh-in-share-trading-scam/articleshow/109350135.cms](https://timesofindia.indiatimes.com/technology/tech-news/how-a-mumbai-man-lost-rs-45-69-lakh-in-share-trading-scam/articleshow/109350135.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:18:32+00:00

A 44-year-old man from Navi Mumbai lost Rs 45.69 lakh to cyber fraudsters in a fake trading scam, promising high returns. The scammers used social media to lure him into investing in share trading, leading to no returns.

## Unemployment rate to decline by 97 basis points by 2028: Report
 - [https://timesofindia.indiatimes.com/business/india-business/indias-unemployment-rate-to-decline-by-97-basis-points-by-2028-orf-report/articleshow/109350119.cms](https://timesofindia.indiatimes.com/business/india-business/indias-unemployment-rate-to-decline-by-97-basis-points-by-2028-orf-report/articleshow/109350119.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:10:27+00:00

India's unemployment rate is expected to drop by 97 basis points by 2028, as per a recent report by the Observer Research Foundation (ORF). The India Employment Outlook 2030 report forecasts a decrease from 4.47 percent in 2024 to 3.68 percent in 2028, aligning with India's push towards the USD 5 trillion milestone. The report highlights that India's job market is evolving, boosted by the country's rapid economic growth post the Covid-19 pandemic.

## IMF raises India's growth projection to 6.8% in 2024
 - [https://timesofindia.indiatimes.com/business/india-business/imf-raises-indias-growth-projection-to-6-8-in-2024/articleshow/109350138.cms](https://timesofindia.indiatimes.com/business/india-business/imf-raises-indias-growth-projection-to-6-8-in-2024/articleshow/109350138.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T13:08:14+00:00

The International Monetary Fund on Tuesday raised India's growth projection to 6.8 per cent from its January forecast of 6.5 per cent citing bullish domestic demand conditions and a rising working-age population. With this, India continues to be the fastest growing economy of the world, ahead of China's growth projection of 4.6 per cent during the same period.

## 'That line about Dhoni...': Gilchrist on Pandya's painful comment
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/that-line-about-ms-dhoni-adam-gilchrist-on-hardik-pandyas-painful-comment-after-mumbai-indians-defeat/articleshow/109349585.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/that-line-about-ms-dhoni-adam-gilchrist-on-hardik-pandyas-painful-comment-after-mumbai-indians-defeat/articleshow/109349585.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:50:39+00:00

Hardik Pandya, the newly appointed captain of Mumbai Indians, couldn't hide his disappointment and pressure after the team suffered their fourth loss in six matches. The dejection was evident on his face as he struggled to control his emotions.The five-time champions had a rough start to the tournament, losing their first three matches consecutively. However, they managed to get their campaign back on track with two wins against Delhi Capitals and Royal Challengers Bengaluru. But succumbed to another defeat against CSK by 20 runs.

## 'Party apparatchik': Congress calls for sacking of India's envoy
 - [https://timesofindia.indiatimes.com/india/party-apparatchik-congress-calls-for-sacking-of-indias-envoy-to-ireland-over-attack-on-opposition/articleshow/109346841.cms](https://timesofindia.indiatimes.com/india/party-apparatchik-congress-calls-for-sacking-of-indias-envoy-to-ireland-over-attack-on-opposition/articleshow/109346841.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:50:26+00:00

The Congress party has strongly criticized India's ambassador to Ireland for his disparaging remarks towards the opposition party. Jairam Ramesh, the party's general secretary, condemned Ambassador Akhilesh Mishra's behavior, stating it was inappropriate for him to openly attack opposition parties like a "party apparatchik." Ramesh called for the ambassador's dismissal.

## Maha CM visits Salman's house; asks cops to increase security
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/maharashtra-cm-eknath-shinde-visits-salman-khan-at-his-galaxy-residence-assures-the-superstar-the-government-is-with-him-watch-video/articleshow/109349572.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/maharashtra-cm-eknath-shinde-visits-salman-khan-at-his-galaxy-residence-assures-the-superstar-the-government-is-with-him-watch-video/articleshow/109349572.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:41:07+00:00

Following the shooting near Salman Khan's residence, Maharashtra CM Eknath Shinde visited, reassuring Khan's family of increased security. He pledged to eradicate criminal elements, highlighting the arrest of two suspects linked to Lawrence Bishnoi's gang. Kachchh DSP AR Zankant confirmed the suspects' ties and their subsequent handover to Mumbai Police.

## Aamir Khan has files FIR against his fake video endorsing party
 - [https://timesofindia.indiatimes.com/technology/tech-news/aamir-khan-has-filed-fir-against-this-political-party-video-going-viral-online/articleshow/109349421.cms](https://timesofindia.indiatimes.com/technology/tech-news/aamir-khan-has-filed-fir-against-this-political-party-video-going-viral-online/articleshow/109349421.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:36:59+00:00

Aamir Khan refutes political affiliation, files FIR against fake video endorsing party. His office clarifies no political endorsements in 35-year career. 'Satyamev Jayate' video edited to target BJP. Lok Sabha elections near, FIR lodged with Mumbai Police.

## At least 18 Maoists killed in encounter with security personnel in Chhattisgarh
 - [https://timesofindia.indiatimes.com/india/chhattisgarh-at-least-8-maoists-killed-3-security-personnel-injured-in-encounter/articleshow/109349113.cms](https://timesofindia.indiatimes.com/india/chhattisgarh-at-least-8-maoists-killed-3-security-personnel-injured-in-encounter/articleshow/109349113.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:33:46+00:00

On Tuesday midday, at least 18 Maoists were killed in a significant engagement with security forces in the deep forests of Bastar's Kanker district. Three Border Security Force and District Reserve Guard men were injured by bullets during the incident, and evacuation was ongoing. This is one of the biggest killings in an operation in Bastar.

## Rahul slams PM over electoral bond issue, calls it 'form of extortion'
 - [https://timesofindia.indiatimes.com/india/rahul-gandhi-slams-pm-modi-over-electoral-bond-issue-calls-it-form-of-extortion/articleshow/109347156.cms](https://timesofindia.indiatimes.com/india/rahul-gandhi-slams-pm-modi-over-electoral-bond-issue-calls-it-form-of-extortion/articleshow/109347156.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:28:35+00:00

Senior Congress leader Rahul Gandhi launched an attack on Prime Minister Narendra Modi on Tuesday over the electoral bond issue, describing it as a "form of extortion" and alleging "intimidatory tactics" against targeted businessmen. "There are some people in every small town or village who extort money on the streets by threatening physical harm. In Malayalam you call this extortion 'kolla adikkal' (loot), but Modi calls it electoral bonds. What a common thief is doing on the streets, the PM is doing at an international level," Gandhi alleged.

## Best 1 ton ac models to provide consistent cooling in your indoor space
 - [https://timesofindia.indiatimes.com/hot-picks/best-1-ton-ac-models-to-provide-consistent-cooling-in-your-indoor-space-top-recommendations/articleshow/109343461.cms](https://timesofindia.indiatimes.com/hot-picks/best-1-ton-ac-models-to-provide-consistent-cooling-in-your-indoor-space-top-recommendations/articleshow/109343461.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:27:47+00:00

A good 1 ton AC is ample to cool down an area of up to 120 square meters. So if your living room or bedroom has an area equivalent to that and you want a functional air conditioner, our listicle of the best 1 ton ACs will do the trick for you. The AC’s in this article have the highest customer rating and positive reviews, so you can place your bet on these to survive through India’s scorching heat.

## PM Modi: You can see example of Google, Samsung and Apple...
 - [https://timesofindia.indiatimes.com/technology/tech-news/prime-minister-narendra-modi-you-can-see-the-example-of-google-samsung-and-apple-/articleshow/109348508.cms](https://timesofindia.indiatimes.com/technology/tech-news/prime-minister-narendra-modi-you-can-see-the-example-of-google-samsung-and-apple-/articleshow/109348508.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:07:43+00:00

PM Modi emphasizes local manufacturing, youth employment, and affordable data benefits like online learning and telemedicine. He encourages global investment while ensuring products reflect India's essence and local labor contributes.

## Muslim student in UK loses bid to overturn prayer ban
 - [https://timesofindia.indiatimes.com/world/uk/muslim-student-in-uk-loses-case-against-his-school-over-on-site-prayer-ban/articleshow/109346963.cms](https://timesofindia.indiatimes.com/world/uk/muslim-student-in-uk-loses-case-against-his-school-over-on-site-prayer-ban/articleshow/109346963.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:03:37+00:00

In a UK court, a Muslim student has lost a case against Michaela Community School for prohibiting on-site prayer rituals. The student claimed the ban infringed on her religious freedom, causing alienation for religious minorities. The court upheld the school's decision, stating it did not violate her rights. This ruling highlights the ongoing debate over religious practices in educational institutions.

## Chinese couple abandons baby with nanny for windfall
 - [https://timesofindia.indiatimes.com/world/china/chinese-couple-abandons-baby-with-nanny-for-usd-55-million-inheritance/articleshow/109346851.cms](https://timesofindia.indiatimes.com/world/china/chinese-couple-abandons-baby-with-nanny-for-usd-55-million-inheritance/articleshow/109346851.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T12:02:50+00:00

A Chinese couple from Harbin, Heilongjiang province, mysteriously disappeared after leaving their baby with a nanny, sparking intense online debate about a possible elaborate scam involving a substantial sum of money.

## Raina shares candid chat with MS Dhoni
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/bahut-hi-gajabe-commentary-kar-rahe-bhojpuriya-me-suresh-raina-shares-candid-chat-with-ms-dhoni/articleshow/109348028.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/bahut-hi-gajabe-commentary-kar-rahe-bhojpuriya-me-suresh-raina-shares-candid-chat-with-ms-dhoni/articleshow/109348028.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T11:54:32+00:00

MS Dhoni and Suresh Raina's friendship is renowned in the cricket community. Their connection extends past the boundaries of the field, as evidenced by their camaraderie when they're not playing.

## What Nasa said on mystery object that hit Florida home
 - [https://timesofindia.indiatimes.com/world/us/what-nasa-said-on-mystery-object-that-hit-florida-mans-home/articleshow/109346399.cms](https://timesofindia.indiatimes.com/world/us/what-nasa-said-on-mystery-object-that-hit-florida-mans-home/articleshow/109346399.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T11:06:28+00:00



## Michael Platt: The enigmatic billionaire you've never heard of
 - [https://timesofindia.indiatimes.com/world/uk/michael-platt-the-enigmatic-billionaire-youve-never-heard-of/articleshow/109346229.cms](https://timesofindia.indiatimes.com/world/uk/michael-platt-the-enigmatic-billionaire-youve-never-heard-of/articleshow/109346229.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T11:04:22+00:00

Michael Platt, Britain's richest man, remains a mystery despite his £14.3 billion fortune. Learn more about his secretive life and extraordinary success in the finance world.

## AAP releases star campaigners' list for Guj; Arvind, Sunita included
 - [https://timesofindia.indiatimes.com/india/lok-sabha-polls-aap-releases-list-of-star-campaigners-for-gujarat-cm-arvind-wife-sunitas-names-included/articleshow/109345205.cms](https://timesofindia.indiatimes.com/india/lok-sabha-polls-aap-releases-list-of-star-campaigners-for-gujarat-cm-arvind-wife-sunitas-names-included/articleshow/109345205.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T11:03:16+00:00

Aam Aadmi Party's star campaigners for Gujarat polls include Arvind Kejriwal, Sunita Kejriwal, Bhagwant Mann, Manish Sisodia, Satyendar Jain, Raghav Chadha. Contesting 2 seats with election on May 7.

## Donald Trump denies falling asleep during historic criminal trial
 - [https://timesofindia.indiatimes.com/world/us/donald-trump-denies-falling-asleep-during-historic-criminal-trial/articleshow/109346300.cms](https://timesofindia.indiatimes.com/world/us/donald-trump-denies-falling-asleep-during-historic-criminal-trial/articleshow/109346300.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:59:50+00:00

Former US President Donald Trump has denied claims of dozing off during his ongoing criminal trial in New York. Trump faces charges of falsifying business records linked to a payment made to adult film star Stormy Daniels. The trial has garnered widespread attention, with both supporters and protesters closely watching. Social media buzzed with nicknames like “Sleepy Don” and “Don Snoreleone,” drawing comparisons to a famous mafia character.

## Wipro CEO sold his shares in IT giant for Rs 5cr weeks before taking charge
 - [https://timesofindia.indiatimes.com/business/india-business/wipro-ceo-srinivas-pallia-sold-all-his-shares-in-it-giant-for-rs-5-crore-weeks-before-taking-charge/articleshow/109345478.cms](https://timesofindia.indiatimes.com/business/india-business/wipro-ceo-srinivas-pallia-sold-all-his-shares-in-it-giant-for-rs-5-crore-weeks-before-taking-charge/articleshow/109345478.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:56:39+00:00

Srinivas Pallia, the newly appointed CEO of Wipro, sold all his shares worth Rs 5 crore in a significant transaction before taking on the top position. The company declined to comment on the matter, citing a silent period ahead of its quarterly and annual results announcement.

## Wrong couple given divorce 'accidentally' by UK law firm
 - [https://timesofindia.indiatimes.com/world/uk/law-firm-accidentally-divorced-wrong-couple-after-clicking-wrong-button/articleshow/109344645.cms](https://timesofindia.indiatimes.com/world/uk/law-firm-accidentally-divorced-wrong-couple-after-clicking-wrong-button/articleshow/109344645.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:54:57+00:00

In 2023, UK couple Mr and Mrs William were accidentally divorced by Vardags due to an operator's oversight. Despite efforts to rescind the divorce order, the court upheld it, emphasizing the importance of finality in divorce proceedings.

## 'Don't try to bring down system': SC on pleas doubting EVMs, VVPATs
 - [https://timesofindia.indiatimes.com/india/we-can-go-back-to-paper-ballots-supreme-court-discusses-issues-with-vvpat-system/articleshow/109343118.cms](https://timesofindia.indiatimes.com/india/we-can-go-back-to-paper-ballots-supreme-court-discusses-issues-with-vvpat-system/articleshow/109343118.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:40:33+00:00

VVPAT is a system that allows voters to verify if their vote has been cast correctly and counted towards the candidate they intended to support. The VVPAT produces a paper slip that is securely stored and can be accessed in case of any disputes or discrepancies. In light of the concerns and doubts raised by the opposition regarding the Electronic Voting Machine (EVM) system, petitions have been filed demanding the cross-verification of each vote cast.

## Shooters opened fire in bid to kill Salman Khan: Mumbai Police
 - [https://timesofindia.indiatimes.com/city/mumbai/accused-opened-fire-outside-salman-khans-house-in-bid-to-kill-him-police-to-court/articleshow/109344823.cms](https://timesofindia.indiatimes.com/city/mumbai/accused-opened-fire-outside-salman-khans-house-in-bid-to-kill-him-police-to-court/articleshow/109344823.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:36:10+00:00

The Mumbai police's crime branch presented two accused who opened fire outside Bollywood superstar Salman Khan's house in Bandra, Mumbai. The accused, Vicky Gupta (24) and Sagar Pal (21), both residents of Bihar, were on the run after the firing incident outside Khan's house at the Galaxy Apartment in Bandra area here early Sunday morning. They were arrested late Monday night from Mata No Madh village in Gujarat's Kutch district and later brought to Mumbai.

## Tesla's global job cuts to hit China sales team: Report
 - [https://timesofindia.indiatimes.com/business/international-business/elon-musk-led-teslas-global-job-cuts-to-hit-china-sales-team-report/articleshow/109344149.cms](https://timesofindia.indiatimes.com/business/international-business/elon-musk-led-teslas-global-job-cuts-to-hit-china-sales-team-report/articleshow/109344149.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:32:50+00:00

Tesla's China job cuts due to sales decline in EV market competition. Analysts link layoffs to cost pressures. BYD's new models impact global deliveries, leading to price war.

## 'Treated as a soft target ...': Robert Vadra hints at joining politics
 - [https://timesofindia.indiatimes.com/india/treated-as-a-soft-target-robert-vadra-hints-at-joining-politics/articleshow/109342350.cms](https://timesofindia.indiatimes.com/india/treated-as-a-soft-target-robert-vadra-hints-at-joining-politics/articleshow/109342350.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:28:56+00:00

Robert Vadra considers entering Lok Sabha elections from Amethi, Moradabad, or Haryana, if Congress approves. He views himself as a soft target due to Gandhi family association and advocates for a secular country in politics.

## Over a million high-skilled Indians are waiting endlessly for job-based US green card
 - [https://timesofindia.indiatimes.com/nri/us-canada-news/over-a-million-high-skilled-indians-are-waiting-endlessly-for-a-employment-based-green-card/articleshow/109343280.cms](https://timesofindia.indiatimes.com/nri/us-canada-news/over-a-million-high-skilled-indians-are-waiting-endlessly-for-a-employment-based-green-card/articleshow/109343280.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:09:42+00:00

Mumbai is witnessing a trend that is no longer surprising. It is a harsh reality that over one million Indians are still waiting in employment-based green card backlogs. According to a recent analysis by the National Foundation for American Policy (NFAP), more than 1.2 million Indians, along with their dependents, are currently waiting in the employment-based green card categories.

## Saudi Arabia 'confirms' helping Israel against Iranian attack
 - [https://timesofindia.indiatimes.com/world/middle-east/saudi-arabia-confirms-helping-israel-against-iranian-attack/articleshow/109344061.cms](https://timesofindia.indiatimes.com/world/middle-east/saudi-arabia-confirms-helping-israel-against-iranian-attack/articleshow/109344061.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:08:30+00:00

Saudi Arabia joins regional coalition to counter Iranian attack, crucial in defense due to drones in Jordanian airspace. US supports Israel post-attack. Concerns rise over potential conflict escalation.

## 'Kohli wouldn't have conceded this many had he bowled...'
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/virat-kohli-wouldnt-have-conceded-this-many-had-he-bowled-/articleshow/109343816.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/virat-kohli-wouldnt-have-conceded-this-many-had-he-bowled-/articleshow/109343816.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:07:48+00:00

Kris Srikkanth, a former Indian cricketer, criticized the Royal Challengers Bengaluru's bowling performance against Sunrisers Hyderabad in the Indian Premier League match, stating that RCB should play with 11 batters, especially at M Chinnaswamy Stadium, and suggested star batter Virat Kohli could have bowled better than those who conceded 287 runs.

## Lucknow’s Aditya Srivastava tops UPSC civil services exams
 - [https://timesofindia.indiatimes.com/city/lucknow/lucknows-aditya-srivastava-tops-upsc-civil-services-exams/articleshow/109343992.cms](https://timesofindia.indiatimes.com/city/lucknow/lucknows-aditya-srivastava-tops-upsc-civil-services-exams/articleshow/109343992.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:06:30+00:00

Lucknow's Aditya Srivastava, an IPS, topped UPSC 2023 exams, currently training at Hyderabad Police Academy. He is an IIT Kanpur alumni and son of CAG office's audit officer, Ajay Srivastava. UPSC Final Result declared on April 16, 2024.

## Who is Aditya Srivastava, UPSC Civil Services topper 2023?
 - [https://timesofindia.indiatimes.com/education/news/who-is-aditya-srivastava-upsc-civil-services-topper-2023/articleshow/109343668.cms](https://timesofindia.indiatimes.com/education/news/who-is-aditya-srivastava-upsc-civil-services-topper-2023/articleshow/109343668.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T10:05:19+00:00

Lucknow's Aditya Srivastava, an IIT Kanpur graduate (possibly gold medalist), topped the 2023 UPSC Civil Services Exam. After excelling in school (95% in 12th) and working at Goldman Sachs, Srivastava chose the IAS to contribute to society at the grassroots level. He seeks to improve the system and innovate within its framework.

## TMC 'hatched conspiracies' to stop Ram Navami celebrations: PM
 - [https://timesofindia.indiatimes.com/elections/lok-sabha-elections/lok-sabha-election-news/pm-modi-says-tmc-hatched-conspiracies-to-stop-ram-navami-celebrations-lok-sabha/articleshow/109342639.cms](https://timesofindia.indiatimes.com/elections/lok-sabha-elections/lok-sabha-election-news/pm-modi-says-tmc-hatched-conspiracies-to-stop-ram-navami-celebrations-lok-sabha/articleshow/109342639.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T09:54:29+00:00

Prime Minister Narendra Modi criticized the Trinamool Congress (TMC) government in West Bengal, accusing it of plotting against the Ram Navami celebrations. Speaking at a rally in Balurghat, PM Modi condemned the state government's attempt to halt the Vishva Hindu Parishad's rally in Howrah. The Calcutta High Court was approached by the government to intervene and prevent the event, sparking tension between the ruling party and religious groups.

## Soon, your network provider will warn you about scam calls
 - [https://timesofindia.indiatimes.com/business/india-business/tracking-mobile-frauds-with-caller-id-soon-your-network-provider-will-warn-you-about-scam-calls-heres-how/articleshow/109342140.cms](https://timesofindia.indiatimes.com/business/india-business/tracking-mobile-frauds-with-caller-id-soon-your-network-provider-will-warn-you-about-scam-calls-heres-how/articleshow/109342140.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T09:51:44+00:00

India is set to take strict actions against online and phone frauds with the establishment of a National Cyber Security Agency (NCSA) and the implementation of Calling Name Presentation (CNAP) service to combat fraudulent calls.

## 'Pak sustained its nuclear programme despite economic turmoil'
 - [https://timesofindia.indiatimes.com/world/us/pakistan-sustained-its-nuclear-programme-despite-economic-turmoil-top-us-intelligence-official-tells-congress/articleshow/109342542.cms](https://timesofindia.indiatimes.com/world/us/pakistan-sustained-its-nuclear-programme-despite-economic-turmoil-top-us-intelligence-official-tells-congress/articleshow/109342542.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T09:39:16+00:00

Pakistan sustained its nuclear modernisation efforts last year despite its economic turmoil as its contentious relationship with India continues to drive its defence policy, the top US intelligence official has told Congress. The remarks by Lt Gen Jeffrey Kruse, Director of the Defence Intelligence Agency came during a Congressional hearing on China on Monday. Kruse told lawmakers that Pakistan has sought international support, including from the UN Security Council, to resolve its dispute with India about Kashmir.

## Are Indian stock markets closed on Ram Navami?
 - [https://timesofindia.indiatimes.com/business/india-business/ram-navami-holiday-2024-are-indian-stock-markets-bse-sensex-nifty50-closed-on-april-17/articleshow/109341814.cms](https://timesofindia.indiatimes.com/business/india-business/ram-navami-holiday-2024-are-indian-stock-markets-bse-sensex-nifty50-closed-on-april-17/articleshow/109341814.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T09:38:54+00:00

BSE and NSE will be closed on April 17 for Ram Navami and April 11 for Eid-Ul-Fitr. MCX and NCDEX will also be closed. Muhurat Trading will happen on Diwali. Indices showed mixed performance in March.

## Zomato has an all-new solution for your house parties: All the details
 - [https://timesofindia.indiatimes.com/technology/tech-news/zomato-has-an-all-new-solution-for-your-house-parties-all-the-details/articleshow/109341854.cms](https://timesofindia.indiatimes.com/technology/tech-news/zomato-has-an-all-new-solution-for-your-house-parties-all-the-details/articleshow/109341854.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T09:07:35+00:00

Zomato's CEO Deepinder Goyal launches India's first large order fleet on X, all-electric, serves up to 50 people. Addresses past delivery challenges, focuses on sustainability, adds cooling compartments, hot boxes with temperature control.

## SC appreciates Indian Railways for installation of 'Kavach'
 - [https://timesofindia.indiatimes.com/business/india-business/supreme-court-appreciates-indian-railways-for-installation-of-kavach-anti-collision-system-in-trains/articleshow/109341815.cms](https://timesofindia.indiatimes.com/business/india-business/supreme-court-appreciates-indian-railways-for-installation-of-kavach-anti-collision-system-in-trains/articleshow/109341815.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T09:06:37+00:00

Praise for Indian Railways Kavach system: The court had agreed to hear the PIL on implementation of ‘Kavach’ and had asked the Centre to brief it on steps taken or proposed to be taken for putting in place anti-collision systems to prevent train accidents.

## Banks to remain closed on April 17 for Ram Navami in several states
 - [https://timesofindia.indiatimes.com/business/india-business/ram-navami-2024-bank-holiday-banks-to-remain-closed-on-april-17-for-ram-navami-in-several-states-check-list/articleshow/109336378.cms](https://timesofindia.indiatimes.com/business/india-business/ram-navami-2024-bank-holiday-banks-to-remain-closed-on-april-17-for-ram-navami-in-several-states-check-list/articleshow/109336378.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T09:01:06+00:00

Indian banks to close on April 17 for Ram Navami, with upcoming elections affecting banking operations in various states. ET report details additional holiday closures in different regions.

## Cybercrooks get IT professional to disrobe on video call for 'verification'
 - [https://timesofindia.indiatimes.com/city/pune/cybercrooks-get-it-professional-to-disrobe-on-video-call-for-verification/articleshow/109341149.cms](https://timesofindia.indiatimes.com/city/pune/cybercrooks-get-it-professional-to-disrobe-on-video-call-for-verification/articleshow/109341149.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:45:45+00:00

An IT professional in Pune was duped of Rs13.94 lakh by fraudulent callers posing as courier firm reps and NCB officers. The victim was coerced into disrobing on a video call under false pretenses of 'verification'.

## Ram Lalla's 'Suryatilak': How the ritual will be performed
 - [https://timesofindia.indiatimes.com/city/lucknow/ayodhya-ram-navami-celebrations-ram-lalla-suryatilak-no-electronic-device-or-battery-used-how-the-ritual-will-be-performed/articleshow/109340517.cms](https://timesofindia.indiatimes.com/city/lucknow/ayodhya-ram-navami-celebrations-ram-lalla-suryatilak-no-electronic-device-or-battery-used-how-the-ritual-will-be-performed/articleshow/109340517.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:43:39+00:00

CBRI scientists, with collaboration from Indian Institute of Astrophysics and Optics &amp; Allied Engg, use an optomechanical system to safeguard Ram Lalla idol from excess heat during the Suryatilak ritual at the Ram temple in Ayodhya.

## UPSC result out: Check direct link to download; toppers' list here
 - [https://timesofindia.indiatimes.com/education/news/upsc-civil-services-2023-final-result-out-check-direct-link-to-download-and-toppers-list-here/articleshow/109339703.cms](https://timesofindia.indiatimes.com/education/news/upsc-civil-services-2023-final-result-out-check-direct-link-to-download-and-toppers-list-here/articleshow/109339703.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:34:14+00:00

On April 16, 2024, the UPSC announced the final results for the Civil Services Examination (CSE) 2023 through a public notice on upsc.gov.in. Candidates can view their names, roll numbers, and All India Ranks (AIR) on the UPSC website. Detailed instructions and a direct link to the result download are provided.

## 'Hardik's inclusion in T20 WC squad depends on IPL bowling'
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/hardik-pandyas-inclusion-in-t20-world-cup-squad-depends-on-ipl-bowling-performance-report/articleshow/109340445.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/hardik-pandyas-inclusion-in-t20-world-cup-squad-depends-on-ipl-bowling-performance-report/articleshow/109340445.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:33:51+00:00

India captain Rohit Sharma and head coach Rahul Dravid discussed squad composition for the upcoming T20 World Cup in Mumbai. They decided that bowling regularly during IPL 2024 is crucial for Hardik Pandya's inclusion and focused on selecting fast bowling all-rounders for the tournament co-hosted by the USA and Caribbean islands.

## BJP's Uttar Pradesh battle: Riding high on M-Y factor
 - [https://timesofindia.indiatimes.com/city/lucknow/bjps-viksit-bharat-campaign-took-brand-modi-to-ups-20-population/articleshow/109340244.cms](https://timesofindia.indiatimes.com/city/lucknow/bjps-viksit-bharat-campaign-took-brand-modi-to-ups-20-population/articleshow/109340244.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:24:30+00:00

BJP's 'Brand Modi' campaign, 'Viksit Bharat Abhiyan', strategically implemented welfare schemes to reach 20% of UP's population. The initiative involved various programs and key party members, aiming to counter anti-incumbency sentiments effectively.

## 'Half of them don't understand English': Sehwag blasts RCB
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/half-of-them-dont-even-understand-english-virender-sehwag-lambasts-rcb-management/articleshow/109339306.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/half-of-them-dont-even-understand-english-virender-sehwag-lambasts-rcb-management/articleshow/109339306.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:19:28+00:00

Royal Challengers Bengaluru's struggles in IPL 2024 concern ex-cricketers Virender Sehwag and Manoj Tiwary. Sehwag criticized the lack of Indian support staff, hindering player communication. Tiwary questioned franchise decisions, noting key player departures. Sunrisers Hyderabad's record-breaking total of 287-3 further highlighted RCB's woes, despite efforts from Kohli, du Plessis, and Karthik, leading to their sixth defeat.

## Pathan on why Karthik is unlikely to play T20 World Cup
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/what-about-team-india-regulars-irfan-pathan-explains-why-red-hot-dinesh-karthiks-inclusion-in-t20-world-cup-squad-is-unlikely/articleshow/109339736.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/what-about-team-india-regulars-irfan-pathan-explains-why-red-hot-dinesh-karthiks-inclusion-in-t20-world-cup-squad-is-unlikely/articleshow/109339736.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:14:39+00:00

Veteran batter Dinesh Karthik's 83 off 35 went in vain as Sunrisers Hyderabad defeated host Royal Challengers Bengaluru by 25 runs in the highest aggregate total for a T20 match with a tally of 549 runs in the Match 30 of the Indian Premier League at M. Chinnaswamy Stadium on Monday.

## Wakefit co-founder's clever 'ad twist' to Murthy's 70 hrs work week call
 - [https://timesofindia.indiatimes.com/technology/tech-news/wakefit-co-founders-clever-ad-twist-to-narayana-murthys-70-hours-work-week-call/articleshow/109339691.cms](https://timesofindia.indiatimes.com/technology/tech-news/wakefit-co-founders-clever-ad-twist-to-narayana-murthys-70-hours-work-week-call/articleshow/109339691.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:14:06+00:00

Narayana Murthy's 70-hour workweek remark ignited a debate on youth productivity. Wakefit suggests 70 hours of sleep for job efficiency. Murthy discussed technology, Infosys, and low work productivity in India, urging competition with countries like China, Japan, and post-World War 2 Germany.

## Salman house firing: Court sends both shooters to 10-day custody
 - [https://timesofindia.indiatimes.com/city/mumbai/salman-khan-house-firing-case-mumbai-court-sends-both-shooters-to-10-day-police-custody/articleshow/109339435.cms](https://timesofindia.indiatimes.com/city/mumbai/salman-khan-house-firing-case-mumbai-court-sends-both-shooters-to-10-day-police-custody/articleshow/109339435.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:06:01+00:00



## Isro achieves breakthrough with nozzle for rocket engines
 - [https://timesofindia.indiatimes.com/india/isro-achieves-breakthrough-with-lightweight-carbon-carbon-rocket-engine-nozzle/articleshow/109339599.cms](https://timesofindia.indiatimes.com/india/isro-achieves-breakthrough-with-lightweight-carbon-carbon-rocket-engine-nozzle/articleshow/109339599.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T08:05:23+00:00



## Every inch of train occupied, where will those with tickets go?
 - [https://timesofindia.indiatimes.com/city/lucknow/aisle-to-toilets-every-inch-of-train-coaches-occupied-where-will-passengers-with-tickets-go/articleshow/109338699.cms](https://timesofindia.indiatimes.com/city/lucknow/aisle-to-toilets-every-inch-of-train-coaches-occupied-where-will-passengers-with-tickets-go/articleshow/109338699.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T07:45:03+00:00

Passengers face severe overcrowding on trains, leading to chaotic scenes. Social media exposes ticketless travelers. Railways seek journey details for resolution, urging direct concerns on 139.

## Tipping in Rupees in Thailand! RBI, govt to popularise Indian currency
 - [https://timesofindia.indiatimes.com/business/india-business/soon-you-may-be-able-to-tip-in-rupees-in-thailand-rbi-government-look-to-popularise-use-of-indian-currency/articleshow/109337256.cms](https://timesofindia.indiatimes.com/business/india-business/soon-you-may-be-able-to-tip-in-rupees-in-thailand-rbi-government-look-to-popularise-use-of-indian-currency/articleshow/109337256.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T07:44:04+00:00

India and Thailand may be exploring a currency deal to promote the use of the rupee in the South-East Asian country. Promoting the local currency through bilateral swap deals with different countries was a strategy employed by China to make the yuan more widely accepted.

## Kaun Banega Crorepati 16 registration starts on 26th April; read deets
 - [https://timesofindia.indiatimes.com/tv/news/hindi/kaun-banega-crorepati-16-registration-starts-on-26th-april-read-deets/articleshow/109338016.cms](https://timesofindia.indiatimes.com/tv/news/hindi/kaun-banega-crorepati-16-registration-starts-on-26th-april-read-deets/articleshow/109338016.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T07:19:03+00:00

Kaun Banega Crorepati 16, hosted by Amitabh Bachchan, starts registration on 26th April. Contestants can win big prizes. Get ready for life-changing opportunities and thrilling quiz challenges.

## India imposes port restrictions on export of commodities to Maldives
 - [https://timesofindia.indiatimes.com/india/india-imposes-fresh-port-restrictions-on-export-of-essential-commodities-to-maldives/articleshow/109337662.cms](https://timesofindia.indiatimes.com/india/india-imposes-fresh-port-restrictions-on-export-of-essential-commodities-to-maldives/articleshow/109337662.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T07:06:52+00:00

India imposes export restrictions to Maldives with increased quotas for specific items. The highest since 1981. Strengthening ties despite strained relations since President Muizzu criticized New Delhi.

## These routes in India have base airfares of less than Rs 1,000!
 - [https://timesofindia.indiatimes.com/business/india-business/these-routes-in-india-have-base-airfares-of-less-than-rs-1000-one-route-has-a-base-fare-of-rs-150-check-list/articleshow/109334020.cms](https://timesofindia.indiatimes.com/business/india-business/these-routes-in-india-have-base-airfares-of-less-than-rs-1000-one-route-has-a-base-fare-of-rs-150-check-list/articleshow/109334020.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T07:03:04+00:00

At least 22 routes feature base airfares below Rs 1,000 per person, with the lowest being Rs 150 for flights connecting Lilabari and Tezpur in Assam.  The Regional Connectivity Scheme (RCS) flights typically have a duration of approximately 50 minutes on most routes.

## Watch: UP cop saves man from coming under train
 - [https://timesofindia.indiatimes.com/city/allahabad/up-rpf-cop-saves-man-from-coming-under-train-at-prayagraj-railway-station/articleshow/109337508.cms](https://timesofindia.indiatimes.com/city/allahabad/up-rpf-cop-saves-man-from-coming-under-train-at-prayagraj-railway-station/articleshow/109337508.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T07:02:02+00:00

At Prayagraj junction, Assistant Sub Inspector Sanjay Kumar Rawat's quick actions saved SS Shekhawat from a potential accident, showcasing the vital role of RPF personnel in ensuring passenger safety. The incident underscores the importance of caution during train boarding.

## Watch - 'Mujhe yeh hairstyle chahiye': SRK teases KKR star
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-mujhe-yeh-hairstyle-chahiye-shah-rukh-khan-teases-kkr-star-for-his-new-look/articleshow/109337276.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-mujhe-yeh-hairstyle-chahiye-shah-rukh-khan-teases-kkr-star-for-his-new-look/articleshow/109337276.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T06:59:47+00:00

Shah Rukh Khan, co-owner of Kolkata Knight Riders, was amazed by KKR spinner Suyash Sharma's new hairstyle during a post-match meet with Lucknow Super Giants. In a video, SRK joked about Suyash's haircut, asking if he sought permission. Suyash, a 20-year-old leg-spinner, surprised fans with his short-hair look. KKR face Rajasthan Royals next at Eden Gardens.

## IPL: Sunrisers Hyderabad now have '300' in sight
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/after-breaking-highest-total-record-twice-this-ipl-sunrisers-hyderabad-now-eyeing-300/articleshow/109336753.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/after-breaking-highest-total-record-twice-this-ipl-sunrisers-hyderabad-now-eyeing-300/articleshow/109336753.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T06:47:19+00:00

After breaking the Indian Premier League's highest total record for a second time this season by racking up 287 runs on Monday, Sunrisers Hyderabad are now looking to breach the 300-mark, their in-form opener Travis Head said. Hyderabad set a new mark last month by posting 277-3 against Mumbai Indians but bettered that by making 287-3 against Royal Challengers Bengaluru, the Pat Cummins-led side winning the match by 25 runs.

## Patanjali ads case: You can't degrade allopathy, SC tells Ramdev
 - [https://timesofindia.indiatimes.com/india/patanjali-ads-case-you-are-doing-good-work-but-cant-degrade-allopathy-sc-tells-ramdev/articleshow/109336487.cms](https://timesofindia.indiatimes.com/india/patanjali-ads-case-you-are-doing-good-work-but-cant-degrade-allopathy-sc-tells-ramdev/articleshow/109336487.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T06:42:44+00:00



## Congressman calls for action against rising attacks on Hindus in US
 - [https://timesofindia.indiatimes.com/world/us/us-congressman-calls-for-action-against-rising-hate-crimes-against-hindus-in-us/articleshow/109336386.cms](https://timesofindia.indiatimes.com/world/us/us-congressman-calls-for-action-against-rising-hate-crimes-against-hindus-in-us/articleshow/109336386.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T06:34:47+00:00

Shri Thanedar raised concerns about Hindu temple attacks, hate crimes, and law enforcement response in the US. He introduced a resolution condemning Hinduphobia and seeks bipartisan support to fight racism.

## Aamir Khan files an FIR with the Mumbai Police against fake video
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/aamir-khan-files-an-fir-with-the-mumbai-police-against-fake-video-issues-an-official-statement-read-details/articleshow/109336296.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/aamir-khan-files-an-fir-with-the-mumbai-police-against-fake-video-issues-an-official-statement-read-details/articleshow/109336296.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T06:31:55+00:00

The country is in election mode these days. The Lok Sabha election 2024 is just around the corner, and as a result, a wide range of political information is already circulating rapidly on social media.

## Why Samsung beating Apple is 'good news' for Google
 - [https://timesofindia.indiatimes.com/technology/mobiles-tabs/why-samsung-beating-apple-for-as-worlds-biggest-smartphone-brand-is-good-news-for-google/articleshow/109335527.cms](https://timesofindia.indiatimes.com/technology/mobiles-tabs/why-samsung-beating-apple-for-as-worlds-biggest-smartphone-brand-is-good-news-for-google/articleshow/109335527.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T06:09:47+00:00

Android is set to outpace iOS in 2024 as Samsung regains the top spot globally. Apple struggles due to competition from Chinese brands like Huawei. AI innovation plays a key role in Samsung's growth.

## 'My name is Kejriwal, not terrorist': Sanjay on Delhi CM's message
 - [https://timesofindia.indiatimes.com/india/my-name-is-arvind-kejriwal-and-i-am-not-a-terrorist-aap-mp-sanjay-singh-on-delhi-cms-message/articleshow/109335241.cms](https://timesofindia.indiatimes.com/india/my-name-is-arvind-kejriwal-and-i-am-not-a-terrorist-aap-mp-sanjay-singh-on-delhi-cms-message/articleshow/109335241.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T06:00:04+00:00

Aam Aadmi Party (AAP) Member of Parliament Sanjay Singh addressed the media in a press briefing on Tuesday. He mentioned that Delhi Chief Minister Arvind Kejriwal, who worked 'like a son and a brother for the country,' conveyed a message from Tihar Jail. 'My name is Arvind Kejriwal and I am not a terrorist,' Singh emphasized.

## Salman Khan house firing: Two accused gunmen arrive at Mumbai airport
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/salman-khan-house-firing-two-accused-gunmen-arrive-at-mumbai-airport-to-be-interrogated-by-mumbai-crime-branch/articleshow/109334612.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/salman-khan-house-firing-two-accused-gunmen-arrive-at-mumbai-airport-to-be-interrogated-by-mumbai-crime-branch/articleshow/109334612.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T05:57:17+00:00

Salman Khan house firing:  Accused gunmen,  Vicky Gupta and Sagar Pal, arrived at the Mumbai airport from Gujarat, escorted by armed guards as the Mumbai Crime Branch begin their investigations into the firing incident that took place outside Salman Khan's Bandra residence on Sunday morning.  An FIR was registered against the two, under sections 307 (attempted murder) of the Indian Penal Code and the Arms Act.

## SEBI warns retail investors: Read here
 - [https://timesofindia.indiatimes.com/technology/tech-news/sebi-warns-retail-investors-these-transactions-remain-as-paper-trades-within-whatsapp-facebook-and-other-apps/articleshow/109335123.cms](https://timesofindia.indiatimes.com/technology/tech-news/sebi-warns-retail-investors-these-transactions-remain-as-paper-trades-within-whatsapp-facebook-and-other-apps/articleshow/109335123.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T05:56:34+00:00

A Kolkata resident lost Rs 20 lakh in a WhatsApp investment scam, while Delhi Police Cyber Cell probed an online investment scam where a woman lost Rs 25 lakh due to a fraudulent third-party trading app.

## 'Rs 47 crore on the bench': RCB under fire
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/rs-47-crore-on-the-bench-rcb-under-fire-for-not-playing-big-ticket-players/articleshow/109333656.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/rs-47-crore-on-the-bench-rcb-under-fire-for-not-playing-big-ticket-players/articleshow/109333656.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T05:44:53+00:00

Royal Challengers Bengaluru made headlines by benching four star players during their IPL match against Sunrisers Hyderabad. With a combined value of Rs 47 crore, players like Cameron Green, Alzarri Joseph, Glenn Maxwell, and Mohammed Siraj remained sidelined, prompting debate. Travis Head's century led SRH to a record total, despite efforts from Virat Kohli and Faf du Plessis for RCB.

## EPFO eyes revamp with leveraging tech for automatic claims settlement
 - [https://timesofindia.indiatimes.com/business/india-business/epfo-eyes-major-revamp-with-leveraging-tech-for-automatic-claims-settlement-restructuring-of-offices-commissions-study-to-iit-delhi/articleshow/109334100.cms](https://timesofindia.indiatimes.com/business/india-business/epfo-eyes-major-revamp-with-leveraging-tech-for-automatic-claims-settlement-restructuring-of-offices-commissions-study-to-iit-delhi/articleshow/109334100.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T05:38:39+00:00

The government is considering a revamp of the Employees' Provident Fund Organisation (EPFO) to align with the broader vision of universal social security and to significantly improve service delivery.

## 'BCCI needs to enforce Sale of RCB'
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/bcci-needs-to-enforce-sale-of-rcb-indian-tennis-great-after-franchises-torrid-run-in-ipl/articleshow/109334417.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/bcci-needs-to-enforce-sale-of-rcb-indian-tennis-great-after-franchises-torrid-run-in-ipl/articleshow/109334417.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T05:33:48+00:00

With the weakest bowling attack among all the 10 franchises, and their spearhead Mohammed Siraj sitting out of the game against SRH, RCB's bowling was thoroughly exposed against Sunrisers Hyderabad and it all came circling back to the owners, who didn't pick the team wisely during the December auction last year. RCB on Monday suffered their fifth straight defeat and sixth in 7 matches.

## Railways says Vande Bharat Express very popular
 - [https://timesofindia.indiatimes.com/business/india-business/indian-railways-says-vande-bharat-express-very-popular-over-2-crore-people-travelled-by-new-trains-since-2019-launch/articleshow/109329581.cms](https://timesofindia.indiatimes.com/business/india-business/indian-railways-says-vande-bharat-express-very-popular-over-2-crore-people-travelled-by-new-trains-since-2019-launch/articleshow/109329581.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T05:16:45+00:00

Vande Bharat trains, known as India's first semi-high speed rail service, have successfully transported over two crore passengers by the end of March 31 this year.  Today, as per railway data, 102 Vande Bharat train services are operational on 100 different routes.

## Ranveer Singh danced at Shankar's daughter's reception
 - [https://timesofindia.indiatimes.com/entertainment/tamil/movies/news/ranveer-singh-danced-at-shankars-daughters-reception/articleshow/109333948.cms](https://timesofindia.indiatimes.com/entertainment/tamil/movies/news/ranveer-singh-danced-at-shankars-daughters-reception/articleshow/109333948.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T05:15:16+00:00

The star actor was seen dancing along with Aditi Shankar and her brother Arjith Shankar at the wedding reception for 'Appadi Podu' song from Vijay &amp; Trisha-starrer 'Ghilli'.

## Gujarat bizman, wife give up Rs 200 cr to become monks
 - [https://timesofindia.indiatimes.com/city/ahmedabad/meet-bhavesh-bhai-bhandari-gujarat-businessman-wife-give-up-rs-200-crore-wealth-to-become-monks/articleshow/109332400.cms](https://timesofindia.indiatimes.com/city/ahmedabad/meet-bhavesh-bhai-bhandari-gujarat-businessman-wife-give-up-rs-200-crore-wealth-to-become-monks/articleshow/109332400.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T04:53:04+00:00

In Gujarat, Bhavesh Bhandari and his wife donated Rs 200 crore to become Jain monks, inspired by their children. The couple gave up worldly belongings during a ceremony in February.

## US NSA Sullivan postpones India visit amid tensions in Middle East
 - [https://timesofindia.indiatimes.com/india/us-national-security-advisor-jake-sullivan-postpones-india-visit-amid-tensions-in-middle-east/articleshow/109333332.cms](https://timesofindia.indiatimes.com/india/us-national-security-advisor-jake-sullivan-postpones-india-visit-amid-tensions-in-middle-east/articleshow/109333332.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T04:48:40+00:00

The visit of the National Security Advisor of the United States, Jake Sullivan, to India this week has been postponed due to the ongoing turn of events in the Middle East. NSA Sullivan aims to conduct the annual review of the Initiative for Critical and Emerging Technology (iCET) at the soonest possible time.

## 'Better than Gayle...': Ex-India player hits out at Kohli's SR critics
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/better-than-gayle-just-behind-rohit-hardik-former-india-t20-world-cup-winner-hits-out-at-virat-kohlis-strike-rate-critics/articleshow/109332873.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/better-than-gayle-just-behind-rohit-hardik-former-india-t20-world-cup-winner-hits-out-at-virat-kohlis-strike-rate-critics/articleshow/109332873.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T04:42:23+00:00

The current Orange Cap holder, Virat Kohli so far has 361 runs to his name in 7 matches and has a staggering average of 72.20. And the much-talked about Kohli's season's strike-rate is also over 147. However, despite Kohli being in red-hot form, his side Royal Challengers Bengaluru has had a horrendous season, losing six out of their 7 matches.

## Watch: Du Plessis and Cummins' convo at toss sparks debate
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-faf-du-plessis-and-pat-cumminss-conversation-at-toss-sparks-debate/articleshow/109332316.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/watch-faf-du-plessis-and-pat-cumminss-conversation-at-toss-sparks-debate/articleshow/109332316.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T04:16:42+00:00

The conversation between RCB's Faf du Plessis and SRH's Pat Cummins before the toss in Bengaluru sparked a social media frenzy. Faf's coin-flipping gesture hinted at last week's toss controversy during MI vs RCB at Wankhede Stadium. Despite winning the toss, RCB struggled against SRH's formidable batting, with Travis Head and Heinrich Klaasen powering their team to victory.

## Boat capsizes in J&K's Jhelum river, some feared missing
 - [https://timesofindia.indiatimes.com/city/srinagar/boat-capsizes-in-jammu-kashmirs-jhelum-river-some-people-feared-missing/articleshow/109332172.cms](https://timesofindia.indiatimes.com/city/srinagar/boat-capsizes-in-jammu-kashmirs-jhelum-river-some-people-feared-missing/articleshow/109332172.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T04:07:43+00:00



## RJD's Tejashwi 'lone campaigner' against NDA's might in Bihar
 - [https://timesofindia.indiatimes.com/city/patna/tejas-lone-campaigner-against-ndas-might-in-state/articleshow/109331764.cms](https://timesofindia.indiatimes.com/city/patna/tejas-lone-campaigner-against-ndas-might-in-state/articleshow/109331764.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T03:50:53+00:00

Tejashwi Prasad Yadav leads Bihar Lok Sabha campaign solo, supported by VIP's Mukesh Sahani. Lalu Prasad's health constraints. RJD's star campaigners include Tejashwi, Lalu, and Rabri. Congress leaders Kharge and Rahul to join campaign.

## Lok Sabha polls: BSP announces new list of 11 candidates
 - [https://timesofindia.indiatimes.com/india/bsp-announces-new-list-of-11-candidates-fields-athar-jamal-against-pm-modi-in-varanasi/articleshow/109331423.cms](https://timesofindia.indiatimes.com/india/bsp-announces-new-list-of-11-candidates-fields-athar-jamal-against-pm-modi-in-varanasi/articleshow/109331423.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T03:49:49+00:00



## Viral video shows priests & parking staff assaulting devotees in Haridwar
 - [https://timesofindia.indiatimes.com/city/dehradun/pujari-vs-devotees-viral-video-shows-priests-staff-at-haridwar-assaulting-devotees-with-sticks/articleshow/109331283.cms](https://timesofindia.indiatimes.com/city/dehradun/pujari-vs-devotees-viral-video-shows-priests-staff-at-haridwar-assaulting-devotees-with-sticks/articleshow/109331283.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T03:34:42+00:00

Violent clash at Siddhpeeth Dakshin Kali Mandir in Haridwar between Saharanpur pilgrims and priest over a parking receipt escalated to physical assault. Video footage of the incident went viral on social media.

## RCB star Maxwell takes a break from IPL 2024
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/struggling-for-form-rcb-all-rounder-glenn-maxwell-takes-a-break-from-ipl-2024/articleshow/109331091.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/struggling-for-form-rcb-all-rounder-glenn-maxwell-takes-a-break-from-ipl-2024/articleshow/109331091.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T03:29:35+00:00

Royal challengers Bengaluru's star all-rounder Glenn Maxwell on Monday informed that he has decided to take an break from IPL 2024 over 'mental and physical fatigue'. Maxwell had just 32 runs to his name in the 6 games for RCB this season.

## Adieu Derek Underwood, Sunil Gavaskar's nemesis
 - [https://timesofindia.indiatimes.com/sports/cricket/news/adieu-derek-underwood-sunil-gavaskars-nemesis/articleshow/109330540.cms](https://timesofindia.indiatimes.com/sports/cricket/news/adieu-derek-underwood-sunil-gavaskars-nemesis/articleshow/109330540.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T03:10:55+00:00

Derek Underwood, England's top spinner post-World War II, passed away at 78. He took 297 wickets in 86 Tests and 2,465 wickets for Kent in his career. Underwood was known for his quick bowling and precise accuracy, making him a formidable opponent during a time of uncovered wickets.

## Snowfall in Kashmir's Sonamarg as north India sizzles at 40°C
 - [https://timesofindia.indiatimes.com/city/jammu/jammu-and-kashmir-sonamarg-receives-fresh-snowfall-rain-lashes-kishtwar/articleshow/109330519.cms](https://timesofindia.indiatimes.com/city/jammu/jammu-and-kashmir-sonamarg-receives-fresh-snowfall-rain-lashes-kishtwar/articleshow/109330519.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T03:08:10+00:00

Sonamarg in Jammu and Kashmir's Ganderbal District received a fresh spell of snowfall on Monday evening.

## Ram Navami: No VIP ‘darshan’ at Ayodhya temple till April 19
 - [https://timesofindia.indiatimes.com/city/lucknow/ram-navami-celebrations-no-vip-darshan-at-ayodhya-temple-till-april-19/articleshow/109329795.cms](https://timesofindia.indiatimes.com/city/lucknow/ram-navami-celebrations-no-vip-darshan-at-ayodhya-temple-till-april-19/articleshow/109329795.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T02:35:24+00:00

Ram temple trust urges VIPs to visit after April 19 due to Ram Navami preparations. Special arrangements made, gates open early with live screening. Devotees advised to store belongings safely. Police set up holding areas for crowd control.

## 'Took Rohit's words seriously': DK 'auditions' for T20 WC
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/took-rohit-sharmas-words-seriously-aged-38-dinesh-karthik-auditions-for-t20-world-cup-with-unreal-blitz/articleshow/109329693.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/took-rohit-sharmas-words-seriously-aged-38-dinesh-karthik-auditions-for-t20-world-cup-with-unreal-blitz/articleshow/109329693.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T02:31:55+00:00

Sunrisers Hyderabad amassed 287-3 for the highest-ever Indian Premier League total and beat Royal Challengers Bengaluru by 25 runs on a Monday full of records and featuring a century by Travis Head. The match produced the highest aggregate for a T20 game with a tally of 549 runs.

## Sons held for rape; their dads kill survivor’s mother
 - [https://timesofindia.indiatimes.com/city/ranchi/two-boys-held-for-rape-their-dads-murder-survivors-mother-in-jharkhand/articleshow/109329745.cms](https://timesofindia.indiatimes.com/city/ranchi/two-boys-held-for-rape-their-dads-murder-survivors-mother-in-jharkhand/articleshow/109329745.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T02:30:40+00:00

Three men arrested for killing woman after daughter raped by their sons. Revenge for police action and land dispute. Weapon recovered. Elder daughter locked house during attack.

## Georgia lawmakers scuffle over controversial 'foreign agent' bill
 - [https://timesofindia.indiatimes.com/world/us/georgia-lawmakers-scuffle-over-controversial-foreign-agent-bill/articleshow/109329677.cms](https://timesofindia.indiatimes.com/world/us/georgia-lawmakers-scuffle-over-controversial-foreign-agent-bill/articleshow/109329677.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T02:26:41+00:00

Georgia's parliament debates a bill akin to Russian laws, sparking violence. Critics fear suppression of democratic freedoms. Protests erupt, President vows veto. Controversy deepens political divisions ahead of elections.

## India world's largest democracy, important partner: US
 - [https://timesofindia.indiatimes.com/india/india-worlds-largest-democracy-important-strategic-partner-says-us/articleshow/109329516.cms](https://timesofindia.indiatimes.com/india/india-worlds-largest-democracy-important-strategic-partner-says-us/articleshow/109329516.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T02:25:11+00:00

The US state department spokesperson on Monday addressed recent publications about democratic decline in India and reaffirmed New Delhi as an important strategic partner to Washington. While responding to a question in a press briefing, Mathew Miller said 'India is the world's largest democracy, it is an important strategic partner of the United States, and I expect that to remain true.'

## Key functionary who 'managed' AAP funds for Goa polls arrested
 - [https://timesofindia.indiatimes.com/city/delhi/key-functionary-who-managed-aap-funds-for-goa-polls-arrested/articleshow/109329551.cms](https://timesofindia.indiatimes.com/city/delhi/key-functionary-who-managed-aap-funds-for-goa-polls-arrested/articleshow/109329551.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T02:13:20+00:00

Chanpreet Singh arrested for receiving Rs 17 crore, linked to AAP bribery scandal for Goa campaign. Income Tax Dept interrogated hawala dealers. ED alleges OML funds involvement in the conspiracy.

## Salman Khan house firing case: Mumbai Police arrest two shooters from Gujarat
 - [https://timesofindia.indiatimes.com/city/mumbai/salman-khan-house-firing-case-mumbai-police-arrest-two-shooters-from-gujarat/articleshow/109329197.cms](https://timesofindia.indiatimes.com/city/mumbai/salman-khan-house-firing-case-mumbai-police-arrest-two-shooters-from-gujarat/articleshow/109329197.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T02:05:33+00:00

Two individuals from Bihar were swiftly arrested by the city crime branch for firing at Salman Khan's residence in Bandstand, following orders from Lawrence Bishnoi to create fear, not harm.

## TCS has set this record for new orders first time in company's history
 - [https://timesofindia.indiatimes.com/technology/tech-news/tcs-has-set-this-record-for-new-orders-first-time-in-the-companys-history/articleshow/109329337.cms](https://timesofindia.indiatimes.com/technology/tech-news/tcs-has-set-this-record-for-new-orders-first-time-in-the-companys-history/articleshow/109329337.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T01:52:22+00:00

In Q4 FY 2024, TCS reported 9% net profit growth. Full-year net profit surged 9% to Rs 45,908 crore. COO discussed discretionary spends, order pipeline, and generative AI. CEO shared outlook on deal pipeline, pricing, and Gen AI deals.

## Disney may have ‘old-style TV’ plan to keep viewers on platform
 - [https://timesofindia.indiatimes.com/technology/tech-news/disney-may-have-old-style-tv-plan-to-keep-viewers-on-platform/articleshow/109323662.cms](https://timesofindia.indiatimes.com/technology/tech-news/disney-may-have-old-style-tv-plan-to-keep-viewers-on-platform/articleshow/109323662.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T01:44:01+00:00

Disney+ lost 1.3M subscribers post price hike. Planning channels with continuous Star Wars, Marvel, Disney, classic animations, and Pixar films. Channels may include commercials, require subscription, and focus on genres.

## KCR placed BRS at PM's feet for Kavitha's release: T'gana CM Reddy
 - [https://timesofindia.indiatimes.com/city/hyderabad/revanth-kcr-placed-brs-at-modis-feet-for-kavithas-release/articleshow/109329138.cms](https://timesofindia.indiatimes.com/city/hyderabad/revanth-kcr-placed-brs-at-modis-feet-for-kavithas-release/articleshow/109329138.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T01:40:35+00:00

Revanth Reddy accuses KCR of aiding BJP for Kavitha's bail, promises Congress victory in Palamuru. Vows Mudiraj community support, MSP bonus, SC categorisation bill, and development projects in Narayanpet and Mahbubnagar.

## Delhi: Man thrashed and shot after his cab collides with e-rick
 - [https://timesofindia.indiatimes.com/city/delhi/man-thrashed-and-shot-after-his-cab-collides-with-e-rickshaw-in-delhi/articleshow/109329061.cms](https://timesofindia.indiatimes.com/city/delhi/man-thrashed-and-shot-after-his-cab-collides-with-e-rickshaw-in-delhi/articleshow/109329061.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T01:31:03+00:00

Saqib killed near Red Fort in a shooting following a road rage incident. The altercation after an e-rickshaw collision led to gunfire. Faisal viewed CCTV footage. Saqib, from Zakir Nagar, left behind a wife and son.

## In Mysuru, BJP banks on royalty, Congress on loyalty
 - [https://timesofindia.indiatimes.com/city/bengaluru/in-mysuru-bjp-banks-on-royalty-congress-on-loyalty/articleshow/109328977.cms](https://timesofindia.indiatimes.com/city/bengaluru/in-mysuru-bjp-banks-on-royalty-congress-on-loyalty/articleshow/109328977.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T01:20:45+00:00

The political spectacle in Mysuru's Lok Sabha constituency showcases a clash between BJP's Yaduveer and Congress' Lakshmana, emphasizing lineage and allegiance. Diverse groups like Dalits, Muslims, and Lingayats hold significance in shaping the electoral outcome.

## 'The real Thala': DK receives a standing ovation. Watch
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/the-real-thala-dinesh-karthik-receives-a-standing-ovation-after-smacking-a-whirlwind-35-ball-83-watch/articleshow/109328904.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/the-real-thala-dinesh-karthik-receives-a-standing-ovation-after-smacking-a-whirlwind-35-ball-83-watch/articleshow/109328904.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T01:17:42+00:00

Sunrisers Hyderabad amassed 287-3 for the highest-ever Indian Premier League total and beat Royal Challengers Bengaluru by 25 runs on a Monday full of records and featuring a century by Travis Head. The match produced the highest aggregate for a T20 game with a tally of 549 runs.

## Anger, Hurt, Disappointment: Kohli's emotional evening at Chinnaswamy
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/anger-hurt-disappointment-virat-kohlis-raw-emotions-on-display-in-rcbs-fifth-straight-defeat-watch/articleshow/109328731.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/anger-hurt-disappointment-virat-kohlis-raw-emotions-on-display-in-rcbs-fifth-straight-defeat-watch/articleshow/109328731.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T00:46:33+00:00

Sunrisers Hyderabad amassed 287-3 for the highest-ever Indian Premier League total and beat Royal Challengers Bengaluru by 25 runs on a Monday full of records and featuring a century by Travis Head. The match produced the highest aggregate for a T20 game with a tally of 549 runs.

## PM slams CPM, taunts Rahul on Amethi 'escape'
 - [https://timesofindia.indiatimes.com/india/pm-slams-cpm-taunts-rahul-on-amethi-escape/articleshow/109328494.cms](https://timesofindia.indiatimes.com/india/pm-slams-cpm-taunts-rahul-on-amethi-escape/articleshow/109328494.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T00:00:22+00:00



## PM slams CPM, taunts Rahul on Amethi 'escape'
 - [https://timesofindia.indiatimes.com/city/thiruvananthapuram/pm-slams-cpm-taunts-rahul-on-amethi-escape/articleshow/109328494.cms](https://timesofindia.indiatimes.com/city/thiruvananthapuram/pm-slams-cpm-taunts-rahul-on-amethi-escape/articleshow/109328494.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-04-16T00:00:22+00:00



