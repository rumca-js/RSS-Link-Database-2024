# Source:Board Game Quest, URL:https://www.boardgamequest.com/feed, language:en-US

## One Small Step Review
 - [https://www.boardgamequest.com/one-small-step-review](https://www.boardgamequest.com/one-small-step-review)
 - RSS feed: https://www.boardgamequest.com/feed
 - date published: 2024-04-16T13:07:07+00:00

<img alt="One Small Step" class="webfeedsFeaturedVisual wp-post-image" height="611" src="https://www.boardgamequest.com/wp-content/uploads/2024/04/One-Small-Step-1024x978.webp" style="display: block; margin-bottom: 5px; clear: both;" width="640" />The year is 1957. The first Frisbees are sold, Elvis Presley purchases Graceland, and the USSR launches Sputnik 1, which kicks off the Space Race, an escalating competition between the Soviet Union and the United States to further space flight and be the first to land a man on the moon. One Small Step by [&#8230;]
<p><a href="https://www.boardgamequest.com/one-small-step-review/" rel="nofollow">Source</a></p>

