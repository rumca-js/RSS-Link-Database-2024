# Source:Insight News Media, URL:https://insightnews.media/feed, language:en-US

## European Commission approves Ukraine’s €50 billion reform plan
 - [https://insightnews.media/european-commission-approves-ukraines-e50-billion-reform-plan](https://insightnews.media/european-commission-approves-ukraines-e50-billion-reform-plan)
 - RSS feed: https://insightnews.media/feed
 - date published: 2024-04-16T22:33:24+00:00

<p>The European Commission has approved the Ukraine&#8217;s €50 billion reform plan under the Ukraine Facility mechanism. The Ukraine Plan reform plan was proposed by the [&#8230;]</p>
<p>The post <a href="https://insightnews.media/european-commission-approves-ukraines-e50-billion-reform-plan/">European Commission approves Ukraine&#8217;s €50 billion reform plan</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

## Bulgaria: Proposal to impose sanctions to counter Russian influence
 - [https://insightnews.media/bulgaria-proposal-to-impose-sanctions-to-counter-russian-influence](https://insightnews.media/bulgaria-proposal-to-impose-sanctions-to-counter-russian-influence)
 - RSS feed: https://insightnews.media/feed
 - date published: 2024-04-16T09:57:10+00:00

<p>A group of fifteen Bulgarian MPs, including well-known individuals like Nadezhda Yordanova and Ivaylo Mirchev, have presented a draft bill to the National Assembly with [&#8230;]</p>
<p>The post <a href="https://insightnews.media/bulgaria-proposal-to-impose-sanctions-to-counter-russian-influence/">Bulgaria: Proposal to impose sanctions to counter Russian influence</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

## Borrell calls for urgent rebalancing of trade with China for EU security
 - [https://insightnews.media/borrell-calls-for-urgent-rebalancing-of-trade-with-china-for-eu-security](https://insightnews.media/borrell-calls-for-urgent-rebalancing-of-trade-with-china-for-eu-security)
 - RSS feed: https://insightnews.media/feed
 - date published: 2024-04-16T09:44:28+00:00

<p>Josep Borrell, the head of the European Union&#8217;s diplomacy, stated that the EU needs to balance trade relations with China to reduce its dependence on [&#8230;]</p>
<p>The post <a href="https://insightnews.media/borrell-calls-for-urgent-rebalancing-of-trade-with-china-for-eu-security/">Borrell calls for urgent rebalancing of trade with China for EU security</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

## Political tensions in Croatia ahead of snap parliamentary elections
 - [https://insightnews.media/political-tensions-in-croatia-ahead-of-snap-parliamentary-elections](https://insightnews.media/political-tensions-in-croatia-ahead-of-snap-parliamentary-elections)
 - RSS feed: https://insightnews.media/feed
 - date published: 2024-04-16T07:44:17+00:00

<p>Political tensions are rising in Croatia ahead of this week&#8217;s snap elections. The pro-Russian president, who decided to run for a prime minister role, attacked [&#8230;]</p>
<p>The post <a href="https://insightnews.media/political-tensions-in-croatia-ahead-of-snap-parliamentary-elections/">Political tensions in Croatia ahead of snap parliamentary elections</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

## Russian propaganda is deeply embedded in discussions in the West – expert
 - [https://insightnews.media/russian-propaganda-is-deeply-embedded-in-discussions-in-the-west-expert](https://insightnews.media/russian-propaganda-is-deeply-embedded-in-discussions-in-the-west-expert)
 - RSS feed: https://insightnews.media/feed
 - date published: 2024-04-16T06:54:46+00:00

<p>In an interview with the German newspaper Tagesspiegel, political scientist Anton Shekhovtsov stated that Russian propaganda is now deeply embedded in discussions held in the [&#8230;]</p>
<p>The post <a href="https://insightnews.media/russian-propaganda-is-deeply-embedded-in-discussions-in-the-west-expert/">Russian propaganda is deeply embedded in discussions in the West &#8211; expert</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

