# Source:Nautilus, URL:https://nautil.us/feed, language:en-US

## The Part-Time Climate Scientist
 - [https://nautil.us/the-part-time-climate-scientist-542351](https://nautil.us/the-part-time-climate-scientist-542351)
 - RSS feed: https://nautil.us/feed
 - date published: 2024-04-16T20:17:22+00:00

<p>A humble steam engineer put humans in the driver’s seat. </p>
<p>The post <a href="https://nautil.us/the-part-time-climate-scientist-542351/">The Part-Time Climate Scientist</a> appeared first on <a href="https://nautil.us">Nautilus</a>.</p>

