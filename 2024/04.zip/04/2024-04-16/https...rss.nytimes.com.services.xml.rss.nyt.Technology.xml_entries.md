# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Microsoft Makes High-Stakes Play in Tech Cold War With Emirati A.I. Deal
 - [https://www.nytimes.com/2024/04/16/technology/microsoft-g42-uae-ai.html](https://www.nytimes.com/2024/04/16/technology/microsoft-g42-uae-ai.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2024-04-16T04:00:06+00:00

Microsoft plans to invest $1.5 billion in G42, an Emirati company with ties to China, as Washington and Beijing maneuver to secure tech influence in the Gulf.

