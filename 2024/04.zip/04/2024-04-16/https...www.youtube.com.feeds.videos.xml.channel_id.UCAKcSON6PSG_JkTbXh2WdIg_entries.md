# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Tim Wilson of Urban Lights Music shares tips on taking care of your records #vinyl #recordstore
 - [https://www.youtube.com/watch?v=ajjDyTpD_UA](https://www.youtube.com/watch?v=ajjDyTpD_UA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2024-04-16T20:52:11+00:00

Timothy Wilson is the owner and operator of City Lights Music, a record store on University Avenue in St. Paul that has been a mainstay in the community for 30 years. “We’ve seen the rise and fall of vinyl and the rise and fall of CDs and cassettes,” Wilson says. “And now we’re back to vinyl again, so that’s an awesome experience, and we’re excited.” 

Given there's a whole new generation of vinyl enthusiasts, Wilson shares advice for taking care of records.

Credits
Video and Photo – Eric Xu Romani
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://www.instagram.com/thecurrent/
https://www.tiktok.com/

## Timothy Wilson of Urban Lights Music talks about how to take care of your records
 - [https://www.youtube.com/watch?v=AdzFUuefEuY](https://www.youtube.com/watch?v=AdzFUuefEuY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2024-04-16T17:56:16+00:00

“It totally skipped a generation,” Timothy Wilson says. “There was about a 10-year gap, maybe 15, where everything [vinyl] just kind of stopped. Now, it’s spun back around again.”

Wilson would know. He’s the owner and operator of City Lights Music, a record store on University Avenue in St. Paul that has been a mainstay in the community for 30 years. “We’ve seen the rise and fall of vinyl and the rise and fall of CDs and cassettes,” Wilson says. “And now we’re back to vinyl again, so that’s an awesome experience, and we’re excited.” 

Given there's a whole new generation of vinyl enthusiasts, Wilson shares his advice for taking care of records.

Credits
Video and Photo – Eric Xu Romani
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to

