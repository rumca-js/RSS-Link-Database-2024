# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## Plans to expand African vaccine production face steep hurdles
 - [https://www.science.org/content/article/plans-expand-african-vaccine-production-face-steep-hurdles](https://www.science.org/content/article/plans-expand-african-vaccine-production-face-steep-hurdles)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-04-16T22:32:15.530981+00:00

Moderna’s pause on Kenya project highlights difficulties in creating a competitive vaccine sector on the continent

## Should researchers use AI to write papers? Group aims for community-driven standards
 - [https://www.science.org/content/article/should-researchers-use-ai-write-papers-group-aims-community-driven-standards](https://www.science.org/content/article/should-researchers-use-ai-write-papers-group-aims-community-driven-standards)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-04-16T22:32:14.016674+00:00

Tools such as ChatGPT may be used for 1% to 5% of manuscripts, recent estimates suggest

## Young toads are teaching Australian lizards to avoid deadly snacks
 - [https://www.science.org/content/article/young-toads-are-teaching-australian-lizards-to-avoid-deadly-snacks](https://www.science.org/content/article/young-toads-are-teaching-australian-lizards-to-avoid-deadly-snacks)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-04-16T20:22:28.318752+00:00

Massive trial shows monitor lizards will learn to avoid toxic and invasive adult toads after tasting less-dangerous juveniles

## Giant planets ran amok soon after Solar System’s birth
 - [https://www.science.org/content/article/giant-planets-ran-amok-soon-after-solar-system-s-birth](https://www.science.org/content/article/giant-planets-ran-amok-soon-after-solar-system-s-birth)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-04-16T10:29:45.845156+00:00

Meteorites suggest cataclysmic “instability” occurred around the time of the Moon’s formation

## Researchers need ‘open’ bibliographic databases, new declaration says
 - [https://www.science.org/content/article/researchers-need-open-bibliographic-databases-new-declaration-says](https://www.science.org/content/article/researchers-need-open-bibliographic-databases-new-declaration-says)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-04-16T09:23:37.202284+00:00

Major platforms such as the Web of Science, widely used to generate metrics and evaluate researchers, are proprietary

