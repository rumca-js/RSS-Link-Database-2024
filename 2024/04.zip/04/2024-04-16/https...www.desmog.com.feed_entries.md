# Source:DeSmog, URL:https://www.desmog.com/feed, language:en-US

## ‘Hard-Right’ NatCon Event Was Organised by Oil Funded Group
 - [https://www.desmog.com/2024/04/16/national-conservatism-natcon-event-farage-braverman-organised-mcc-oil-funded-hungary-group](https://www.desmog.com/2024/04/16/national-conservatism-natcon-event-farage-braverman-organised-mcc-oil-funded-hungary-group)
 - RSS feed: https://www.desmog.com/feed
 - date published: 2024-04-16T16:27:53+00:00

<p>A gathering of “Europe’s hard-right elite” held in Brussels today was organised by a fossil fuel funded think tank, DeSmog can reveal.&#160; The National Conservatism (NatCon) conference was mired in controversy after the mayor of Brussels ordered police to shut down the event, leading to a standoff with its organisers.&#160; The conference was due to [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2024/04/16/national-conservatism-natcon-event-farage-braverman-organised-mcc-oil-funded-hungary-group/">‘Hard-Right’ NatCon Event Was Organised by Oil Funded Group</a> appeared first on <a href="https://www.desmog.com">DeSmog</a>.</p>

