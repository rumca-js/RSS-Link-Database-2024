# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Fatalne pudło. Ten mecz powinien potoczyć się inaczej
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/fc-barcelona-paris-saint-germain.-robert-lewandowski-nie-wykorzystal-stuprocentowej-sytuacji_sto10105450/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/fc-barcelona-paris-saint-germain.-robert-lewandowski-nie-wykorzystal-stuprocentowej-sytuacji_sto10105450/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T21:12:12+00:00

<img alt="Fatalne pudło. Ten mecz powinien potoczyć się inaczej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d33cgn-fc-barcelona-paris-saint-germain-w-cwiercfinale-ligi-mistrzow-7873283/alternates/LANDSCAPE_1280" />
    Polak mógł podwyższyć wynik meczu na 2:0, ale nie wykorzystał niemal stuprocentowej sytuacji.

## Borussia odwróciła losy rywalizacji z Atletico. Szalone spotkanie w Dortmundzie
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/borussia-dortmund-atletico-madryt-wynik-i-relacja-z-rewanzowego-meczu-1-4-finalu-champions-league_sto10105441/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/borussia-dortmund-atletico-madryt-wynik-i-relacja-z-rewanzowego-meczu-1-4-finalu-champions-league_sto10105441/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T21:02:17+00:00

<img alt="Borussia odwróciła losy rywalizacji z Atletico. Szalone spotkanie w Dortmundzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4qlp44-marcel-sabitzer-odegral-wielka-role-w-awansie-borussii-do-polfinalu-ligi-mistrzow-7873272/alternates/LANDSCAPE_1280" />
    W rewanżowym ćwierćfinale Ligi Mistrzów.

## Wielki triumf PSG. Barcelona odpadła z Ligi Mistrzów
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/barcelona-paris-saint-germain-wynik-i-relacja.-liga-mistrzow_sto10105346/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/barcelona-paris-saint-germain-wynik-i-relacja.-liga-mistrzow_sto10105346/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T21:01:17+00:00

<img alt="Wielki triumf PSG. Barcelona odpadła z Ligi Mistrzów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kep5vn-vitinha-z-prawej-cieszy-sie-ze-swojego-gola-w-meczu-barcelona-psg-7873270/alternates/LANDSCAPE_1280" />
    Zaprzepaściła swoją szansę na sukces.

## Czołowe zderzenie osobówki z ciężarówką. Wśród rannych dziecko
 - [https://tvn24.pl/poznan/rogozno-woj-wielkopolskie-czolowe-zderzenie-osobowki-z-ciezarowka-piec-osob-poszkodowanych-w-tym-dziecko-st7873244?source=rss](https://tvn24.pl/poznan/rogozno-woj-wielkopolskie-czolowe-zderzenie-osobowki-z-ciezarowka-piec-osob-poszkodowanych-w-tym-dziecko-st7873244?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T20:53:05+00:00

<img alt="Czołowe zderzenie osobówki z ciężarówką. Wśród rannych dziecko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7wydm0-wypadek-skl-7873239/alternates/LANDSCAPE_1280" />
    Wypadek w Rogoźnie (woj. wielkopolskie).

## Piłkarz Barcelony wyrzucony z boiska. To nie była oczywista sytuacja
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/fc-barcelona-paris-saint-germain.-ronald-araujo-z-czerwona-kartka.-gospodarze-oslabieni_sto10105402/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/fc-barcelona-paris-saint-germain.-ronald-araujo-z-czerwona-kartka.-gospodarze-oslabieni_sto10105402/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T20:12:21+00:00

<img alt="Piłkarz Barcelony wyrzucony z boiska. To nie była oczywista sytuacja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-irzyt2-ronald-araujo-wyrzucony-z-boiska-za-faul-na-bradleyu-barcoli-w-meczu-barcelona-psg-w-lidze-mistrzow-7873230/alternates/LANDSCAPE_1280" />
    Duma Katalonii zmuszona była grać w osłabieniu.

## Zmiany w zarządzie Orlenu
 - [https://tvn24.pl/biznes/z-kraju/orlen-nowi-czlonkowie-zarzadu-st7873180?source=rss](https://tvn24.pl/biznes/z-kraju/orlen-nowi-czlonkowie-zarzadu-st7873180?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T19:58:23+00:00

<img alt="Zmiany w zarządzie Orlenu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wa6z6o-siedziba-pkn-orlen-7787042/alternates/LANDSCAPE_1280" />
    Komunikat spółki.

## "Gdy je zobaczymy, oddalmy się, pozostawiając w spokoju"
 - [https://tvn24.pl/tvnmeteo/polska/zmije-zygzakowate-gdy-je-zobaczymy-oddalmy-sie-pozostawiajac-je-w-spokoju-st7872023?source=rss](https://tvn24.pl/tvnmeteo/polska/zmije-zygzakowate-gdy-je-zobaczymy-oddalmy-sie-pozostawiajac-je-w-spokoju-st7872023?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T19:44:52+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecieb63668b1beeca61b5b9603bbed2abcbc-zmija-zygzakowata-5233284/alternates/LANDSCAPE_1280" />
    Na tatrzańskich szlakach pojawiają się żmije.

## Piter lepsza w "polskim" starciu deblistek
 - [https://eurosport.tvn24.pl/tenis/wta-rouen/2024/katarzyna-piter-lepsza-od-katarzyny-kawy-w-polskim-starciu-deblistek-w-rouen_sto10105377/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-rouen/2024/katarzyna-piter-lepsza-od-katarzyny-kawy-w-polskim-starciu-deblistek-w-rouen_sto10105377/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T19:28:08+00:00

<img alt="Piter lepsza w " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jvbswr-katarzyna-piter-lepsza-od-katarzyny-kawy-w-polskim-starciu-deblistek-w-rouen-7873203/alternates/LANDSCAPE_1280" />
    W Rouen.

## Pytanie o ciastko za 250 tysięcy złotych w "Milionerach"
 - [https://tvn24.pl/toteraz/milionerzy-pytanie-o-ciastko-z-ciemnego-biszkoptu-za-250-tysiecy-zlotych-st7871656?source=rss](https://tvn24.pl/toteraz/milionerzy-pytanie-o-ciastko-z-ciemnego-biszkoptu-za-250-tysiecy-zlotych-st7871656?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T19:06:00+00:00

<img alt="Pytanie o ciastko za 250 tysięcy złotych w " src="https://tvn24.pl/toteraz/cdn-zdjecie-bvno8z-milionerzy-pytanie-o-ciastko-za-250-tysiecy-zlotych-7871645/alternates/LANDSCAPE_1280" />
    Odpowiadał pan Sławomir z Katowic.

## Hit w Barcelonie. Lewandowski i spółka bronią skromnej zaliczki
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/live-fc-barcelona-paris-saint-germain_mtc1438566/live-commentary.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/live-fc-barcelona-paris-saint-germain_mtc1438566/live-commentary.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T18:54:00+00:00

<img alt="Hit w Barcelonie. Lewandowski i spółka bronią skromnej zaliczki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mm9up8-robert-lewandowski-7873084/alternates/LANDSCAPE_1280" />
    Relacja i wynik na żywo w eurosport.pl.

## Spotkanie Dudy z Trumpem? "Ryzykowne działanie"
 - [https://tvn24.pl/polska/mozliwe-spotkanie-andrzeja-dudy-z-donaldem-trumpem-ryszard-schnepf-to-ryzykowny-krok-st7873078?source=rss](https://tvn24.pl/polska/mozliwe-spotkanie-andrzeja-dudy-z-donaldem-trumpem-ryszard-schnepf-to-ryzykowny-krok-st7873078?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T18:45:16+00:00

<img alt="Spotkanie Dudy z Trumpem? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-835xlj-16-1925-fpf-gosc-0017-7873042/alternates/LANDSCAPE_1280" />
    Ocenia w "Faktach po Faktach" Ryszard Schnepf, były ambasador Polski w USA.

## Samochód uderzył w tira, tir w inny samochód i przystanek. Pięć osób w szpitalu
 - [https://tvn24.pl/rzeszow/tyczyn-rzeszow-samochod-uderzyl-w-tira-tir-w-inny-samochod-i-przystanek-ranni-st7872940?source=rss](https://tvn24.pl/rzeszow/tyczyn-rzeszow-samochod-uderzyl-w-tira-tir-w-inny-samochod-i-przystanek-ranni-st7872940?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T16:48:21+00:00

<img alt="Samochód uderzył w tira, tir w inny samochód i przystanek. Pięć osób w szpitalu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-wcc9dk-wypadek-na-s2-zdjecie-ilustracyjne-7798125/alternates/LANDSCAPE_1280" />
    Do poważnego wypadku doszło w Tyczynie koło Rzeszowa.

## Szef BBN o "kopule". Wskazuje warunki prezydenta
 - [https://tvn24.pl/polska/zelazna-kopula-nad-europa-szef-biura-bezpieczenstwa-narodowego-jacek-siewiera-o-warunkach-prezydenta-st7872790?source=rss](https://tvn24.pl/polska/zelazna-kopula-nad-europa-szef-biura-bezpieczenstwa-narodowego-jacek-siewiera-o-warunkach-prezydenta-st7872790?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T16:45:00+00:00

<img alt="Szef BBN o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2g8jcp-jacek-siewiera-7872842/alternates/LANDSCAPE_1280" />
    Briefing Jacka Siewiery.

## Polska zorganizuje mistrzostwa świata
 - [https://eurosport.tvn24.pl/pilka-reczna/polska-i-czechy-gospodarzami-mistrzostw-swiata-kobiet-w-pilce-recznej-w-2031-roku_sto20002256/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/polska-i-czechy-gospodarzami-mistrzostw-swiata-kobiet-w-pilce-recznej-w-2031-roku_sto20002256/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T14:27:13+00:00

<img alt="Polska zorganizuje mistrzostwa świata " src="https://tvn24.pl/najnowsze/cdn-zdjecie-s48csr-monika-kobylinska-to-kapitan-reprezentacji-polski-7519390/alternates/LANDSCAPE_1280" />
    W piłce ręcznej.

## "Ktoś znalazł lukę w przepisach"
 - [https://eurosport.tvn24.pl/kajakarstwo-1/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-protest-odrzucony-polscy-kanadyjkarze-musza-walczyc-w-kwalifikacjach_sto20002212/story.shtml?source=rss](https://eurosport.tvn24.pl/kajakarstwo-1/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-protest-odrzucony-polscy-kanadyjkarze-musza-walczyc-w-kwalifikacjach_sto20002212/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T13:41:37+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vjtm7y-polscy-kanadyjkarze-powalcza-o-awans-na-io-w-paryzu-zrodlo-pzkaj-7872608/alternates/LANDSCAPE_1280" />
    Kuriozalna decyzja uderzyła w Polaków.

## Prezydent Duda o potkaniu z Trumpem
 - [https://tvn24.pl/polska/andrzej-duda-wizyta-w-usa-spotkanie-z-donaldem-trumpem-st7872477?source=rss](https://tvn24.pl/polska/andrzej-duda-wizyta-w-usa-spotkanie-z-donaldem-trumpem-st7872477?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T13:33:10+00:00

<img alt="Prezydent Duda o potkaniu z Trumpem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bnbvho-plansza-pilne-szeroki-drv-4712015/alternates/LANDSCAPE_1280" />
    Andrzej Duda leci do USA.

## Samolot leciał do Moskwy. Piloci ustawili kod alarmowy
 - [https://tvn24.pl/swiat/rosja-samolot-zglosil-sytuacje-krytyczna-nad-baltykiem-st7872338?source=rss](https://tvn24.pl/swiat/rosja-samolot-zglosil-sytuacje-krytyczna-nad-baltykiem-st7872338?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T13:23:47+00:00

<img alt="Samolot leciał do Moskwy. Piloci ustawili kod alarmowy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7blzf-aeroflot-airbus-a321-211-dirk-daniel-mann-shutterstock_1342865774-7872388/alternates/LANDSCAPE_1280" />
    Powód zgłoszenia jest nieznany.

## Polę przyjęto do szpitala, gdy już nie mogła oddychać. Zmarła. Śledztwo ma trwać jeszcze rok
 - [https://tvn24.pl/tvnwarszawa/okolice/piaseczno-smierc-18-letniej-poli-prokuratura-chce-przedluzyc-sledztwo-st7871752?source=rss](https://tvn24.pl/tvnwarszawa/okolice/piaseczno-smierc-18-letniej-poli-prokuratura-chce-przedluzyc-sledztwo-st7871752?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T13:15:37+00:00

<img alt="Polę przyjęto do szpitala, gdy już nie mogła oddychać. Zmarła. Śledztwo ma trwać jeszcze rok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x1dhl7-nie-zyje-18-letnia-pola-7146736/alternates/LANDSCAPE_1280" />
    18-latka początkowo miała objawy grypy.

## Pierwszy taki mecz od lat. Marciniak poprowadzi ćwierćfinałowy hit
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-europy/2023-2024/liga-europy.-szymon-marciniak-sedzia-meczu-as-roma-ac-milan_sto10104922/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-europy/2023-2024/liga-europy.-szymon-marciniak-sedzia-meczu-as-roma-ac-milan_sto10104922/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T12:15:23+00:00

<img alt="Pierwszy taki mecz od lat. Marciniak poprowadzi ćwierćfinałowy hit" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y8xpxv-marciniak-posedziuje-wloskim-klubom-7872339/alternates/LANDSCAPE_1280" />
    Szymon Marciniak wraca do sędziowania w Lidze Europy. Polak poprowadzi czwartkowy szlagier, w którym AS Roma podejmie AC Milan.

## Kontrola "oczekiwana społecznie". Jest zapowiedź NIK
 - [https://tvn24.pl/biznes/z-kraju/najwyzsza-izba-kontroli-o-kontroli-w-komisji-nadzoru-finansowego-zapowiedz-nik-st7872122?source=rss](https://tvn24.pl/biznes/z-kraju/najwyzsza-izba-kontroli-o-kontroli-w-komisji-nadzoru-finansowego-zapowiedz-nik-st7872122?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T12:13:12+00:00

<img alt="Kontrola " src="https://tvn24.pl/najnowsze/cdn-zdjecie-psmnp6-nik-najwyzsza-izba-kontroli-7344112/alternates/LANDSCAPE_1280" />
    NIK o szczegółach.

## "Potwierdziliśmy chęć startu w czerwcowych wyborach wspólnie"
 - [https://tvn24.pl/polska/wybory-do-parlamentu-europejskiego-2024-polska-2050-i-psl-wystartuja-wspolnie-st7872193?source=rss](https://tvn24.pl/polska/wybory-do-parlamentu-europejskiego-2024-polska-2050-i-psl-wystartuja-wspolnie-st7872193?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T11:56:26+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lsqaxi-szymon-holownia-i-wladyslaw-kosiniak-kamysz-7857774/alternates/LANDSCAPE_1280" />
    Jako koalicja Trzecia Droga.

## "Bankructwa, malwersacje i miliardowe straty". Producenci żywności przeciwni systemowi kaucyjnemu
 - [https://tvn24.pl/biznes/pieniadze/system-kaucyjny-w-polsce-polska-federacja-producentow-zywnosci-apeluje-do-premiera-donalda-tuska-st7871577?source=rss](https://tvn24.pl/biznes/pieniadze/system-kaucyjny-w-polsce-polska-federacja-producentow-zywnosci-apeluje-do-premiera-donalda-tuska-st7871577?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T11:18:32+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3pdf8l-butelki-plastik-3385099/alternates/LANDSCAPE_1280" />
    Apel branży spożywczej do premiera Donalda Tuska.

## Tak źle nie było od 65 lat. Rekordowy wzrost przypadków groźnej choroby u sąsiada Polski
 - [https://tvn24.pl/swiat/czechy-zachorowania-na-krztusiec-rekordowo-rosna-1500-nowych-chorych-w-tydzien-st7871700?source=rss](https://tvn24.pl/swiat/czechy-zachorowania-na-krztusiec-rekordowo-rosna-1500-nowych-chorych-w-tydzien-st7871700?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T11:06:29+00:00

<img alt="Tak źle nie było od 65 lat. Rekordowy wzrost przypadków groźnej choroby u sąsiada Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3rkaqr-krztusiec-to-choroba-objawiajaca-sie-przewleklym-napadowym-kaszlem-5069901/alternates/LANDSCAPE_1280" />
    W ciągu ostatniego tygodnia przybyło 1,5 tysiąca chorych.

## Zaskakujący finał rutynowej kontroli paczki dla więźnia
 - [https://tvn24.pl/tvnwarszawa/okolice/mazowieckie-przytuly-stare-narkotyki-i-telefon-komorkowy-ukryte-w-przesylce-do-osadzonego-w-zakladzie-karnym-st7871957?source=rss](https://tvn24.pl/tvnwarszawa/okolice/mazowieckie-przytuly-stare-narkotyki-i-telefon-komorkowy-ukryte-w-przesylce-do-osadzonego-w-zakladzie-karnym-st7871957?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T11:00:28+00:00

<img alt="Zaskakujący finał rutynowej kontroli paczki dla więźnia" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-tkmzbt-paczka-z-ukryta-zawartoscia-7871979/alternates/LANDSCAPE_1280" />
    Teraz sprawą zajmie się policja.

## Koledzy, a niemal pobili się o karnego. "Dorośnijcie!"
 - [https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/klotnia-o-rzut-karny-w-meczu-chelsea-everton-komentarze-ekspertow-premier-league_sto10104751/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/klotnia-o-rzut-karny-w-meczu-chelsea-everton-komentarze-ekspertow-premier-league_sto10104751/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T10:54:40+00:00

<img alt="Koledzy, a niemal pobili się o karnego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-on585h-czterech-graczy-chelsea-chcialo-wykonywac-rzut-karny-7872096/alternates/LANDSCAPE_1280" />
    Kuriozalna sytuacja w drużynie Chelsea.

## Oburzenie po prezentacji. "Stroje jak ze 'Słonecznego patrolu'"
 - [https://eurosport.tvn24.pl/lekkoatletyka/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-kontrowersyjne-stroje-lekkoatletek.-lawina-krytyki_sto20002177/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/igrzyska-olimpijskie-paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-kontrowersyjne-stroje-lekkoatletek.-lawina-krytyki_sto20002177/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T10:25:09+00:00

<img alt="Oburzenie po prezentacji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ihitd7-anna-cockrell-wystapila-w-kontrowersyjnym-stroju-7871966/alternates/LANDSCAPE_1280" />
    Lawina krytyki w świecie sportu.

## Loty, wyścigi i imprezy. Na to poszły miliony z kasy Orlenu
 - [https://tvn24.pl/biznes/z-kraju/orlen-ogromne-wydatki-na-loty-prywatnymi-samolotami-komentarze-politykow-st7871759?source=rss](https://tvn24.pl/biznes/z-kraju/orlen-ogromne-wydatki-na-loty-prywatnymi-samolotami-komentarze-politykow-st7871759?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T10:14:20+00:00

<img alt="Loty, wyścigi i imprezy. Na to poszły miliony z kasy Orlenu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7wadp9-pap_20230704_0h7-7871846/alternates/LANDSCAPE_1280" />
    Komentarze polityków.

## Prezydent o budowie "kopuły" nad Europą: to biznesowy projekt niemiecki
 - [https://tvn24.pl/polska/kopula-nad-europa-prezydent-andrzej-duda-o-projekcie-budowy-systemu-obrony-powietrznej-to-niemiecki-projekt-st7871816?source=rss](https://tvn24.pl/polska/kopula-nad-europa-prezydent-andrzej-duda-o-projekcie-budowy-systemu-obrony-powietrznej-to-niemiecki-projekt-st7871816?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T10:07:28+00:00

<img alt="Prezydent o budowie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xvp89h-duda-z-pap-7871855/alternates/LANDSCAPE_1280" />
    Od lat jesteśmy w trakcie tworzenia systemu, który ma być spójny i ma stanowić jednolitą osłonę przeciwrakietową i przeciwlotniczą Polski - mówił Andrzej Duda.

## "Widziałam kilku Duńczyków, którzy płakali na ulicy"
 - [https://kontakt24.tvn24.pl/najnowsze/widzialam-kilku-dunczykow-ktorzy-plakali-na-ulicy-pozar-zabytkowej-gieldy-papierow-wartosciowych-7871852?source=rss](https://kontakt24.tvn24.pl/najnowsze/widzialam-kilku-dunczykow-ktorzy-plakali-na-ulicy-pozar-zabytkowej-gieldy-papierow-wartosciowych-7871852?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T10:03:53+00:00

<img alt="" src="https://kontakt24.tvn24.pl/najnowsze/cdn-zdjecie-xsf70o-plonie-zabytkowa-gielda-papierow-wartosciowych-w-kopenhadze-7871614/alternates/LANDSCAPE_1280" />
    Nagranie z pożaru otrzymaliśmy na Kontakt24.

## Przez skrzyżowanie na czerwonym. Nagranie
 - [https://tvn24.pl/lodz/lodz-przez-skrzyzowanie-na-czerwonym-nagranie-gitd-kamery-wylapuja-dziesiatki-tysiecy-takich-kierowcow-st7871655?source=rss](https://tvn24.pl/lodz/lodz-przez-skrzyzowanie-na-czerwonym-nagranie-gitd-kamery-wylapuja-dziesiatki-tysiecy-takich-kierowcow-st7871655?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T10:00:21+00:00

<img alt="Przez skrzyżowanie na czerwonym. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7ttvg6-do-zdarzenia-doszlo-na-inflanckiej-w%20lodzi-7871711/alternates/LANDSCAPE_1280" />
    W Łodzi.

## Problemy ze wzrokiem mogą sygnalizować rozwój poważnej choroby
 - [https://tvn24.pl/swiat/zdrowie-problemy-ze-wzrokiem-a-demencja-nowe-badanie-brytyjskich-naukowcow-st7871634?source=rss](https://tvn24.pl/swiat/zdrowie-problemy-ze-wzrokiem-a-demencja-nowe-badanie-brytyjskich-naukowcow-st7871634?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T09:56:33+00:00

<img alt="Problemy ze wzrokiem mogą sygnalizować rozwój poważnej choroby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-it7b9w-lekarz-okulista-badanie-oko-shutterstock_2266690753-7871760/alternates/LANDSCAPE_1280" />
    Niepokojące sygnały mogą się pojawić już 12 lat przed postawieniem diagnozy.

## Wzniecono ogień olimpijski, pochodnia w rękach mistrza
 - [https://eurosport.tvn24.pl/igrzyska-olimpijskie/paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-we-wtorek-odbyla-sie-ceremonia-wzniecenia-ognia-olimpijskiego_sto20002186/story.shtml?source=rss](https://eurosport.tvn24.pl/igrzyska-olimpijskie/paryz-2024/2024/igrzyska-olimpijskie-paryz-2024.-we-wtorek-odbyla-sie-ceremonia-wzniecenia-ognia-olimpijskiego_sto20002186/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T09:41:13+00:00

<img alt="Wzniecono ogień olimpijski, pochodnia w rękach mistrza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-auz06n-wzniecono-ogien-olimpijski-7871847/alternates/LANDSCAPE_1280" />
    W Olimpii.

## Kiedy Iga Świątek gra pierwszy mecz w Stuttgarcie?
 - [https://eurosport.tvn24.pl/tenis/wta-stuttgart/2024/wta-stuttgart-2024.-kiedy-iga-swiatek-gra-pierwszy-mecz-kiedy-mecz-swiatek-o-ktorej-godzinie-z-kim-z_sto10103840/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-stuttgart/2024/wta-stuttgart-2024.-kiedy-iga-swiatek-gra-pierwszy-mecz-kiedy-mecz-swiatek-o-ktorej-godzinie-z-kim-z_sto10103840/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T09:04:12+00:00

<img alt="Kiedy Iga Świątek gra pierwszy mecz w Stuttgarcie?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j204nw-iga-swiatek-porsche-tennis-grand-prix-2022-wta-stuttgart-tennis-esp-player-feature-7873119/alternates/LANDSCAPE_1280" />
    Poznała już rywalkę.

## Zwrócił uwagę nastolatkom, zginął na oczach syna. "Żyje się tutaj w strachu"
 - [https://tvn24.pl/swiat/szwecja-polak-zastrzelony-w-sztokholmie-na-oczach-12-letniego-syna-material-uwagi-tvn-st7871604?source=rss](https://tvn24.pl/swiat/szwecja-polak-zastrzelony-w-sztokholmie-na-oczach-12-letniego-syna-material-uwagi-tvn-st7871604?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T09:02:38+00:00

<img alt="Zwrócił uwagę nastolatkom, zginął na oczach syna. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6augsw-szwecja-7871580/alternates/LANDSCAPE_1280" />
    Reporter "Uwagi!" TVN odwiedził dzielnicę Sztokholmu, w której zastrzelono Polaka.

## Gortat trenuje z najmłodszymi. "Kompletnie nie wiedzą, kim jestem"
 - [https://eurosport.tvn24.pl/koszykowka/marcin-gortat-prowadzi-17.-edycje-marcin-gortat-camp_sto10104640/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/marcin-gortat-prowadzi-17.-edycje-marcin-gortat-camp_sto10104640/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T08:55:28+00:00

<img alt="Gortat trenuje z najmłodszymi. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-okucdx-marcin-gortat-prowadzi-swoj-camp-od-2008-roku-7871703/alternates/LANDSCAPE_1280" />
    Trwa 17. edycja Marcin Gortat Camp.

## Niemcy złagodzą prawo aborcyjne? Jest rekomendacja rządowej komisji
 - [https://tvn24.pl/swiat/niemcy-aborcja-komisja-ekspercka-za-dopuszczeniem-aborcji-do-12-tygodnia-ciazy-st7871273?source=rss](https://tvn24.pl/swiat/niemcy-aborcja-komisja-ekspercka-za-dopuszczeniem-aborcji-do-12-tygodnia-ciazy-st7871273?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T08:53:34+00:00

<img alt="Niemcy złagodzą prawo aborcyjne? Jest rekomendacja rządowej komisji " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z10wxx-aborcja-7863748/alternates/LANDSCAPE_1280" />
    W Niemczech aborcja, poza pewnymi wyjątkami, jest przestępstwem.

## Lewandowski jest wszędzie. "Barcelona musi dokończyć dzieło"
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/fc-barcelona-psg-hiszpanskie-media-przed-meczem-przewidywane-sklady-liga-mistrzow_sto10104611/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/fc-barcelona-psg-hiszpanskie-media-przed-meczem-przewidywane-sklady-liga-mistrzow_sto10104611/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T08:50:46+00:00

<img alt="Lewandowski jest wszędzie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sqdnfr-hiszpanie-wierza-w-barcelone-i-atletico-7871695/alternates/LANDSCAPE_1280" />
    W Hiszpanii ekscytacja przed rewanżem Barcelony z PSG w ćwierćfinale Ligi Mistrzów.

## Gwiazdy potwierdzone. Amerykanie myślą tylko o złocie
 - [https://eurosport.tvn24.pl/koszykowka/igrzyska-olimpijskie-paryz-2024/2024/paryz-2024.-jaki-sklad-amerykanow-kto-zagra-czy-wystapi-stephen-curry_sto20002183/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/igrzyska-olimpijskie-paryz-2024/2024/paryz-2024.-jaki-sklad-amerykanow-kto-zagra-czy-wystapi-stephen-curry_sto20002183/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T08:01:00+00:00

<img alt="Gwiazdy potwierdzone. Amerykanie myślą tylko o złocie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-608u2b-lebron-james-23-of-the-los-angeles-lakers-stephen-curry-30-of-the-golden-state-warriors-looks-on-during-the-game-on-march-16-2024-at-crypto-7871594/alternates/LANDSCAPE_1280" />
    Powtórka z zeszłorocznych mistrzostw świata wydaje się niemożliwa.

## Zakaz palenia na ulicy w odległości mniejszej niż 5 metrów od innych
 - [https://tvn24.pl/swiat/wlochy-turyn-wprowadza-ograniczenia-palenia-na-swiezym-powietrzu-nowy-zakaz-st7871489?source=rss](https://tvn24.pl/swiat/wlochy-turyn-wprowadza-ograniczenia-palenia-na-swiezym-powietrzu-nowy-zakaz-st7871489?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T07:58:10+00:00

<img alt="Zakaz palenia na ulicy w odległości mniejszej niż 5 metrów od innych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sv62t6-wlochy-wladze-turynu-walcza-z-paleniem-na-swiezym-powietrzu-nowy-zakaz-7871551/alternates/LANDSCAPE_1280" />
    Kolejne miasto wprowadza ograniczenia.

## Problem z popularną ulgą. Część rodziców może nie skorzystać
 - [https://tvn24.pl/biznes/z-kraju/ulga-na-dziecko-2024-pit-za-2023-rok-coraz-trudniej-skorzystac-z-ulgi-na-jedno-dziecko-st7871477?source=rss](https://tvn24.pl/biznes/z-kraju/ulga-na-dziecko-2024-pit-za-2023-rok-coraz-trudniej-skorzystac-z-ulgi-na-jedno-dziecko-st7871477?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T07:55:21+00:00

<img alt="Problem z popularną ulgą. Część rodziców może nie skorzystać" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nru5sj-dziecko-ulica-rodzic-rodzice-miasto-shutterstock2145975353-6124402/alternates/LANDSCAPE_1280" />
    Przez limit dochodów.

## Nowa opinia po wypadku na A1. Może wpłynąć na zmianę zarzutu dla Sebastiana M.
 - [https://tvn24.pl/lodz/piotrkow-trybunalski-uzupelniajaca-opinia-bieglego-w-sprawie-wypadku-na-a1-sebastian-m-z-nowymi-zarzutami-st7870460?source=rss](https://tvn24.pl/lodz/piotrkow-trybunalski-uzupelniajaca-opinia-bieglego-w-sprawie-wypadku-na-a1-sebastian-m-z-nowymi-zarzutami-st7870460?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T07:52:26+00:00

<img alt="Nowa opinia po wypadku na A1. Może wpłynąć na zmianę zarzutu dla Sebastiana M." src="https://tvn24.pl/najnowsze/cdn-zdjecie-3oee4v-tragiczny-wypadek-na-autostradzie-a1-kolo-piotrkowa-trybunalskiego-7352239/alternates/LANDSCAPE_1280" />
    Cały czas trwa proces ekstradycyjny 32-latka.

## Najgorzej wykonany karny w historii?
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/kuriozalny-rzut-karny-w-meczu-osasuna-valencia-ante-budimir-autorem-wideo-la-liga_sto10104594/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/kuriozalny-rzut-karny-w-meczu-osasuna-valencia-ante-budimir-autorem-wideo-la-liga_sto10104594/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T07:14:19+00:00

<img alt="Najgorzej wykonany karny w historii?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-67buk4-budimir-popisal-sie-w-meczu-z-valencia-7871481/alternates/LANDSCAPE_1280" />
    "Nikt nie wie, co miał na myśli".

## "Bili ją wszyscy". Na papierze toaletowym spisała relację z więzienia
 - [https://tvn24.pl/swiat/bialorus-wieziona-przez-rezim-alaksandra-lukaszenki-przemycila-na-papierze-toaletowym-relacje-z-zakladu-karnego-st7871280?source=rss](https://tvn24.pl/swiat/bialorus-wieziona-przez-rezim-alaksandra-lukaszenki-przemycila-na-papierze-toaletowym-relacje-z-zakladu-karnego-st7871280?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T06:47:46+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o4zp0v-areszt-w-zodzinie-7871322/alternates/LANDSCAPE_1280" />
    Kaciaryna Nowikawa jest więziona przez reżim Alaksandra Łukaszenki.

## Aktywiści ponownie próbowali blokować warszawskie mosty
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-blokady-mostow-w-warszawie-utrudnienia-st7869551?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-blokady-mostow-w-warszawie-utrudnienia-st7869551?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T06:25:00+00:00

<img alt="Aktywiści ponownie próbowali blokować warszawskie mosty" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4uljs4-proba-blokady-mostu-poniatowskiego-7871405/alternates/LANDSCAPE_1280" />
    Akcja Ostatniego Pokolenia.

## Pokłócili się o karnego. "Wstyd"
 - [https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/wielka-klotnia-o-rzut-karny-w-meczu-chelsea-everton_sto10104587/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/wielka-klotnia-o-rzut-karny-w-meczu-chelsea-everton_sto10104587/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T06:03:27+00:00

<img alt="Pokłócili się o karnego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ki66x-pilkarze-chelsea-poklocili-sie-o-to-kto-ma-wykonywac-karnego-7871364/alternates/LANDSCAPE_1280" />
    Piłkarze Chelsea wprawili w osłupienie.

## Specjalnie nie trafił rzutu wolnego. Zrobił to dla kibiców
 - [https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/boban-marjanovic-nie-trafil-rzutu-wolnego.-kibice-nba-dostali-kurczaka_sto20002162/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/boban-marjanovic-nie-trafil-rzutu-wolnego.-kibice-nba-dostali-kurczaka_sto20002162/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T05:55:20+00:00

<img alt="Specjalnie nie trafił rzutu wolnego. Zrobił to dla kibiców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gnd3pg-boban-marjanovic-uradowal-fanow-7871358/alternates/LANDSCAPE_1280" />
    W lidze NBA.

## Pewne siebie PSG w Barcelonie. "Odwrócimy wynik"
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/barcelona-psg.-trener-luis-enrique-wierzy-w-awans-mimo-porazki-w-pierwszym-meczu_sto10104449/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/barcelona-psg.-trener-luis-enrique-wierzy-w-awans-mimo-porazki-w-pierwszym-meczu_sto10104449/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T05:00:47+00:00

<img alt="Pewne siebie PSG w Barcelonie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8swuft-luis-enrique-wierzy-w-awans-barcelony-do-polfinalu-ligi-mistrzow-7871314/alternates/LANDSCAPE_1280" />
    Przed rewanżem w ćwierćfinale Ligi Mistrzów.

## Miasto przygotowuje specjalną nagrodę dla trenera Bayeru
 - [https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2023-2024/bayer-leverkusen-mistrzem-niemiec.-miasto-chce-nazwac-ulice-imieniem-trenera-xabiego-alonso_sto10104342/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/bundesliga/2023-2024/bayer-leverkusen-mistrzem-niemiec.-miasto-chce-nazwac-ulice-imieniem-trenera-xabiego-alonso_sto10104342/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T04:30:44+00:00

<img alt="Miasto przygotowuje specjalną nagrodę dla trenera Bayeru" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tzcgk2-xabi-alonso-moze-miec-swoja-ulice-w-leverkusen-7871295/alternates/LANDSCAPE_1280" />
    Leverkusen pragnie uhonorować Xabiego Alonso za ostatni sukces.

## "Iran nieświadomie ujawnił to całemu światu". Co pokazał atak na Izrael?
 - [https://tvn24.pl/swiat/usa-nyt-iran-pokazal-swiatu-ze-jego-wladze-sa-zinfiltrowane-przez-zachodnie-wywiady-st7871268?source=rss](https://tvn24.pl/swiat/usa-nyt-iran-pokazal-swiatu-ze-jego-wladze-sa-zinfiltrowane-przez-zachodnie-wywiady-st7871268?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-04-16T04:29:43+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2escz8-niebo-nad-izraelskim-miastem-aszkelon-podczas-iranskiego-ataku-7868593/alternates/LANDSCAPE_1280" />
    Publicysta "NYT" uważa, że irański reżim obawia się izraelskiego kontruderzenia.

