# Source:The Rubin Report, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng, language:en

## Press Sec Embarrasses Herself by Mocking & Laughing at This Serious Question
 - [https://www.youtube.com/watch?v=1LJjR00KVHQ](https://www.youtube.com/watch?v=1LJjR00KVHQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-04-16T22:15:00+00:00

Dave Rubin of “The Rubin Report” shares DM clip of White House Press Secretary Karine Jean-Pierre’s response to being asked if there will be a Trump-Biden debate.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=5S_AnGtqNQY&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #KarineJeanPierre #debate #debates #Biden #DaveRubin

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help heal our democracy. To hear what Dave has to say on these

## John Legend’s MSNBC Legal Analysis Will Make You Dumber
 - [https://www.youtube.com/watch?v=QRfysKcfc40](https://www.youtube.com/watch?v=QRfysKcfc40)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-04-16T21:15:01+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of MSNBC's Jen Psaki getting legal analysis from John Legend.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=5S_AnGtqNQY&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #JohnLegend #MSNBC #legalanalysis #JenPsaki #DaveRubin

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help heal our democracy. To hear what Dave has to say on these and a variety of other topics watch this playlis

## Protesters Shut Down Golden Gate Bridge, Commuters Did This
 - [https://www.youtube.com/watch?v=0aJcS_JbEBU](https://www.youtube.com/watch?v=0aJcS_JbEBU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-04-16T20:15:00+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of footage from an insane pro Palestine protest that shut down the Golden Gate Bridge and trapped motorists for almost 5 hours.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=5S_AnGtqNQY&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------
#RubinReport #FreePalestine #PalestineProtest #Palestine #GoldenGateBridge #DaveRubin

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help heal our democracy. To 

## Don Lemon Goes Quiet After Elon Musk Explains the Simple Math of Democrat’s Plan
 - [https://www.youtube.com/watch?v=dmrHCucwSq0](https://www.youtube.com/watch?v=dmrHCucwSq0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-04-16T18:15:02+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of Elon Musk explaining to Don Lemon the simple math behind how Democrats are using the migrant crisis to increase their political power.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=5S_AnGtqNQY&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #ElonMusk #math #migrants #Democrats #DonLemon #DaveRubin

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help heal our democracy. To hear

## ‘The View’s’ Joy Behar Goes Silent After This Answer from Coleman Hughes
 - [https://www.youtube.com/watch?v=lzcHK0ntb6A](https://www.youtube.com/watch?v=lzcHK0ntb6A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-04-16T02:15:01+00:00

Dave Rubin of “The Rubin Report” reacts to a DM clip of Coleman Hughes explaining to "The View's" Joy Behar the similarities between proponents of anti-racism theory, like Ibram X. Kendi and Robin DiAngelo, and white supremacists.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=i0rCjIZ9yEg&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------
#DaveRubinReacts #TheView #ColemanHughes #JoyBehar #antiracism #Kendi #DaveRubin #RubinReport 

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escala

## Joe Rogan Can’t Stop Laughing at Renato Moicano’s Name Checking Ludwig von Mises
 - [https://www.youtube.com/watch?v=CNlb6ynIpAE](https://www.youtube.com/watch?v=CNlb6ynIpAE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-04-16T01:15:00+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of UFC fighter Renato Moicano telling Joe Rogan and the crowd why Ludwig von Mises’ lessons in Austrian economics will change their lives.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=b9yVLtPfyhY&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #JoeRogan #UFC #RenatoMoicano #Mises #austrianeconomics #daverubin 

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help heal our democra

## Leaked Footage Shows How Dangerous Pro-Palestine Activists Are Getting
 - [https://www.youtube.com/watch?v=CiKz7x0BqX0](https://www.youtube.com/watch?v=CiKz7x0BqX0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJdKr0Bgd_5saZYqLCa9mng
 - date published: 2024-04-16T00:15:00+00:00

Dave Rubin of “The Rubin Report” shares a DM clip of pro-Palestine activist Shabbir Rizvi teaching activists at the Anti-War Committee Chicago how to chant “death to America” and “death to Israel” in Farsi.
Watch Dave Rubin's FULL DIRECT MESSAGE: https://www.youtube.com/watch?v=b9yVLtPfyhY&amp;list=PLEbhOtC9klbDG22n--rCDbv02-n8l6agL&amp;index=1&amp;pp=gAQBiAQB

WATCH the MEMBER-EXCLUSIVE segment of the show here: https://rubinreport.locals.com/

Check out the NEW RUBIN REPORT MERCH here:
https://daverubin.store/

----------

#RubinReport #FreePalestine #Palestine #activist #daverubin 

The Direct Message segments of the Rubin Report are a chance for Dave Rubin to directly address current events, political news and the topics of the day. Whether it’s encouraging critical thinking, defending free speech, or fending off political correctness, it’s only by having calm rational conversations about these issues that can help de-escalate the political polarization and help heal our democracy

