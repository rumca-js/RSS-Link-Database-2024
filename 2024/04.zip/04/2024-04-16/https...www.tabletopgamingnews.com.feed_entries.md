# Source:Tabletop Gaming News – TGN, URL:https://www.tabletopgamingnews.com/feed, language:en-US

## TTRPG Creators Set Sail for the Dark Caribbean in Upcoming “CABIN FEVER” Event
 - [https://www.tabletopgamingnews.com/ttrpg-creators-set-sail-for-the-dark-caribbean-in-upcoming-cabin-fever-event](https://www.tabletopgamingnews.com/ttrpg-creators-set-sail-for-the-dark-caribbean-in-upcoming-cabin-fever-event)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-04-16T21:55:43+00:00

<a href="https://www.tabletopgamingnews.com/ttrpg-creators-set-sail-for-the-dark-caribbean-in-upcoming-cabin-fever-event/" rel="nofollow" title="TTRPG Creators Set Sail for the Dark Caribbean in Upcoming &#8220;CABIN FEVER&#8221; Event"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1085" src="https://www.tabletopgamingnews.com/wp-content/uploads/2024/04/CABIN-FEVER-Banner-with-Text.jpg" style="display: block; margin: auto; margin-bottom: 5px;" width="1928" /></a>In May, the tabletop RPG community is invited to participate in the CABIN FEVER game jam, which revolves around the Pirate Borg RPG. The event encourages creators from across the globe to submit their original content in one of five categories: Adventures and Modules, PC Class, Monsters, NPCs, or Ships, Generators and Random Tables, and &#8230;

## One-Hit Heroes Exceeds Kickstarter Funding Goal, Introduces Unique Co-Op Card Game Mechanics
 - [https://www.tabletopgamingnews.com/one-hit-heroes-exceeds-kickstarter-funding-goal-introduces-unique-co-op-card-game-mechanics](https://www.tabletopgamingnews.com/one-hit-heroes-exceeds-kickstarter-funding-goal-introduces-unique-co-op-card-game-mechanics)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-04-16T21:44:41+00:00

<a href="https://www.tabletopgamingnews.com/one-hit-heroes-exceeds-kickstarter-funding-goal-introduces-unique-co-op-card-game-mechanics/" rel="nofollow" title="One-Hit Heroes Exceeds Kickstarter Funding Goal, Introduces Unique Co-Op Card Game Mechanics"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="600" src="https://www.tabletopgamingnews.com/wp-content/uploads/2024/04/pic8036003.webp" style="display: block; margin: auto; margin-bottom: 5px;" width="786" /></a>One-Hit Heroes, a new tabletop game by Wiggles 3D, has surpassed its Kickstarter funding target, achieving $62,492 in pledges against a goal of $21,734 with 29 days remaining until the campaign ends on May 16. The game is centered around a cooperative experience where players choose a hero and collectively face off against various bosses. &#8230;

## Corvus Belli Clarifies Details for Warcrow Universe’s Two Game Formats
 - [https://www.tabletopgamingnews.com/corvus-belli-clarifies-details-for-warcrow-universes-two-game-formats](https://www.tabletopgamingnews.com/corvus-belli-clarifies-details-for-warcrow-universes-two-game-formats)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-04-16T21:24:34+00:00

<a href="https://www.tabletopgamingnews.com/corvus-belli-clarifies-details-for-warcrow-universes-two-game-formats/" rel="nofollow" title="Corvus Belli Clarifies Details for Warcrow Universe&#8217;s Two Game Formats"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="590" src="https://www.tabletopgamingnews.com/wp-content/uploads/2024/04/Screenshot-2024-04-16-at-23-22-21-¿Warcrow-Adventures-or-Warcrow-the-wargame.png" style="display: block; margin: auto; margin-bottom: 5px;" width="1047" /></a>Launched in 2023, the Warcrow universe has quickly expanded to include two distinct game formats: &#8220;Warcrow Adventures,&#8221; a dungeon crawler, and &#8220;Warcrow the Wargame,&#8221; a tactical wargame. Each game offers unique experiences rooted in the same fantasy universe, detailed with rich lore and an enchanting setting. Here are further details on each game. Warcrow Adventures: &#8230;

## The Council Convenes: Mini Rogue’s Season 2 Triumphs on Kickstarter
 - [https://www.tabletopgamingnews.com/the-council-convenes-mini-rogues-season-2-triumphs-on-kickstarter](https://www.tabletopgamingnews.com/the-council-convenes-mini-rogues-season-2-triumphs-on-kickstarter)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-04-16T20:32:00+00:00

<a href="https://www.tabletopgamingnews.com/the-council-convenes-mini-rogues-season-2-triumphs-on-kickstarter/" rel="nofollow" title="The Council Convenes: Mini Rogue&#8217;s Season 2 Triumphs on Kickstarter"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="563" src="https://www.tabletopgamingnews.com/wp-content/uploads/2024/04/Screenshot-2024-04-16-at-22-30-25-Mini-Rogue-Season-2.png" style="display: block; margin: auto; margin-bottom: 5px;" width="588" /></a>Mini Rogue &#8211; Season 2 Surpasses Kickstarter Goal Nuts! Publishing recently launched a Kickstarter campaign for &#8220;The Council,&#8221; the second season of the roguelike microgame Mini Rogue. The campaign has successfully exceeded its funding target, garnering $49,341 against a goal of $14,856, with 811 backers and 13 days remaining until its conclusion on April 30. &#8230;

## Vecna: Eve of Ruin—A Multiverse-spanning Dungeons & Dragons Adventure for Levels 10-20, Launching in May
 - [https://www.tabletopgamingnews.com/vecna-eve-of-ruin-a-multiverse-spanning-dungeons-dragons-adventure-for-levels-10-20-launching-in-may](https://www.tabletopgamingnews.com/vecna-eve-of-ruin-a-multiverse-spanning-dungeons-dragons-adventure-for-levels-10-20-launching-in-may)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-04-16T20:22:41+00:00

<a href="https://www.tabletopgamingnews.com/vecna-eve-of-ruin-a-multiverse-spanning-dungeons-dragons-adventure-for-levels-10-20-launching-in-may/" rel="nofollow" title="Vecna: Eve of Ruin—A Multiverse-spanning Dungeons &amp; Dragons Adventure for Levels 10-20, Launching in May"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="739" src="https://www.tabletopgamingnews.com/wp-content/uploads/2024/04/vecna_-eve-of-ruin.jpg" style="display: block; margin: auto; margin-bottom: 5px;" width="1200" /></a>Wizards of the Coast has announced that &#8220;Vecna: Eve of Ruin&#8221; will be released on May 21. This new Dungeons &#38; Dragons adventure is designed for characters of levels 10–20 and spans multiple universes, challenging players to thwart the lich Vecna, made famous by the Netflix show Stranger Things. The adventure begins in the Forgotten &#8230;

## Awaken Realms Launches Crowdfunding for “Castles of Burgundy: Special Edition Reprint” on Gamefound
 - [https://www.tabletopgamingnews.com/awaken-realms-launches-crowdfunding-for-castles-of-burgundy-special-edition-reprint-on-gamefound](https://www.tabletopgamingnews.com/awaken-realms-launches-crowdfunding-for-castles-of-burgundy-special-edition-reprint-on-gamefound)
 - RSS feed: https://www.tabletopgamingnews.com/feed
 - date published: 2024-04-16T20:09:37+00:00

<a href="https://www.tabletopgamingnews.com/awaken-realms-launches-crowdfunding-for-castles-of-burgundy-special-edition-reprint-on-gamefound/" rel="nofollow" title="Awaken Realms Launches Crowdfunding for &#8220;Castles of Burgundy: Special Edition Reprint&#8221; on Gamefound"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="448" src="https://www.tabletopgamingnews.com/wp-content/uploads/2024/04/Screenshot-2024-04-16-at-22-08-10-Castles-of-Burgundy-Special-Edition-Reprint-by-Awaken-Realms.png" style="display: block; margin: auto; margin-bottom: 5px;" width="661" /></a>Awaken Realms has reintroduced the &#8220;Castles of Burgundy: Special Edition&#8221; via a crowdfunding campaign on Gamefound. The campaign quickly achieved its initial funding goal of $20,000, reaching the target in just 3 minutes and 28 seconds. As of now, the project has gathered $672,284 from 4,247 backers, with 13 days remaining in the campaign. &#8220;Castles &#8230;

