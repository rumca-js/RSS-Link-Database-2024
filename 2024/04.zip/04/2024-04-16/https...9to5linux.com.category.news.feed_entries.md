# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## VirtualBox 7.0.16 Released with Initial Support for Linux 6.8 and 6.9 Kernels
 - [https://9to5linux.com/virtualbox-7-0-16-released-with-initial-support-for-linux-6-8-and-6-9-kernels](https://9to5linux.com/virtualbox-7-0-16-released-with-initial-support-for-linux-6-8-and-6-9-kernels)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-04-16T20:38:59+00:00

<p>VirtualBox 7.0.16 open-source virtualization software is now available for download with initial support for Linux 6.8 and 6.9 kernels, improved support for building VirtualBox kernel modules with GCC 13.2, and more.</p>
<p>The post <a href="https://9to5linux.com/virtualbox-7-0-16-released-with-initial-support-for-linux-6-8-and-6-9-kernels">VirtualBox 7.0.16 Released with Initial Support for Linux 6.8 and 6.9 Kernels</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Calamares 3.3.6 Linux Installer Improves Support for Plymouth Splash Screens
 - [https://9to5linux.com/calamares-3-3-6-linux-installer-improves-support-for-plymouth-splash-screens](https://9to5linux.com/calamares-3-3-6-linux-installer-improves-support-for-plymouth-splash-screens)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-04-16T14:27:12+00:00

<p>The Calamares 3.3.6 open-source universal graphical installer for GNU/Linux distributions is now available for download. Here's what's new!</p>
<p>The post <a href="https://9to5linux.com/calamares-3-3-6-linux-installer-improves-support-for-plymouth-splash-screens">Calamares 3.3.6 Linux Installer Improves Support for Plymouth Splash Screens</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Firefox 126 Enters Beta Testing with a Revamped Dialog for Clearing User Data
 - [https://9to5linux.com/firefox-126-enters-beta-testing-with-a-revamped-dialog-for-clearing-user-data](https://9to5linux.com/firefox-126-enters-beta-testing-with-a-revamped-dialog-for-clearing-user-data)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-04-16T13:42:49+00:00

<p>Firefox 126 open-source web browser is now available for public beta testing with a simpler and more unified dialog for clearing user data, a new option to enable or disable the Split console feature in Developer Tools, and more.</p>
<p>The post <a href="https://9to5linux.com/firefox-126-enters-beta-testing-with-a-revamped-dialog-for-clearing-user-data">Firefox 126 Enters Beta Testing with a Revamped Dialog for Clearing User Data</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## KDE Plasma 6.0.4 Is Out to Improve Plasma Wayland, System Monitor, and More
 - [https://9to5linux.com/kde-plasma-6-0-4-is-out-now-to-improve-plasma-wayland-system-monitor-and-more](https://9to5linux.com/kde-plasma-6-0-4-is-out-now-to-improve-plasma-wayland-system-monitor-and-more)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-04-16T12:53:17+00:00

<p>KDE Plasma 6.0.4 is now available as the fourth maintenance update to the latest KDE Plasma 6 desktop environment series fixing more bugs and crashes, but also adding some performance and UI improvements.</p>
<p>The post <a href="https://9to5linux.com/kde-plasma-6-0-4-is-out-now-to-improve-plasma-wayland-system-monitor-and-more">KDE Plasma 6.0.4 Is Out to Improve Plasma Wayland, System Monitor, and More</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

