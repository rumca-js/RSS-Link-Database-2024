# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Zdecydowana większość Polaków "nie ufa ludziom"
 - [https://wydarzenia.interia.pl/kraj/news-zdecydowana-wiekszosc-polakow-nie-ufa-ludziom,nId,7455008](https://wydarzenia.interia.pl/kraj/news-zdecydowana-wiekszosc-polakow-nie-ufa-ludziom,nId,7455008)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-04-16T16:19:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zdecydowana-wiekszosc-polakow-nie-ufa-ludziom,nId,7455008"><img align="left" alt="Zdecydowana większość Polaków &quot;nie ufa ludziom&quot; " src="https://i.iplsc.com/zdecydowana-wiekszosc-polakow-nie-ufa-ludziom/000GQK799Y3JGMQX-C321.jpg" /></a>73 proc. Polaków uważa, że trzeba być ostrożnym i większości ludzi nie można zaufać - tak wynika z przeprowadzonego w lutym badania CBOS. Wyniki badania opinii publicznej dotyczące zaufania społecznego wykazały, że tylko 24 proc. Polaków uważa, że większości ludzi można zaufać. W badaniu zapytano też o zaufanie do instytucji państwowych i organizacji życia publicznego. </p><br clear="all" />

## Morawiecki apeluje do Tuska. Zarzuca mu złamanie unijnej zasady
 - [https://wydarzenia.interia.pl/kraj/news-morawiecki-apeluje-do-tuska-zarzuca-mu-zlamanie-unijnej-zasa,nId,7454866](https://wydarzenia.interia.pl/kraj/news-morawiecki-apeluje-do-tuska-zarzuca-mu-zlamanie-unijnej-zasa,nId,7454866)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-04-16T13:02:54+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-morawiecki-apeluje-do-tuska-zarzuca-mu-zlamanie-unijnej-zasa,nId,7454866"><img align="left" alt="Morawiecki apeluje do Tuska. Zarzuca mu złamanie unijnej zasady" src="https://i.iplsc.com/morawiecki-apeluje-do-tuska-zarzuca-mu-zlamanie-unijnej-zasa/000IYR4MNL1BIMOI-C321.jpg" /></a>- Premier Donald Tusk powinien w jak najostrzejszy sposób zawetować pakt migracyjny, ponieważ ma do tego podstawę prawną w postaci konkluzji Rady Europejskiej - stwierdził były premier i wiceszef Prawa i Sprawiedliwości Mateusz Morawiecki. Zdaniem polityka Tusk, popierając ten projekt, załamał jedną z zasad ustaloną przez Radę Europejską. Ponadto zarzucił mu, że nie respektuje wyników referendum z 2023 roku.  </p><br clear="all" />

## "PiS ukradł nam czas". Premier alarmuje ws. unijnych miliardów
 - [https://wydarzenia.interia.pl/kraj/news-pis-ukradl-nam-czas-premier-alarmuje-ws-unijnych-miliardow,nId,7454851](https://wydarzenia.interia.pl/kraj/news-pis-ukradl-nam-czas-premier-alarmuje-ws-unijnych-miliardow,nId,7454851)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-04-16T12:32:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pis-ukradl-nam-czas-premier-alarmuje-ws-unijnych-miliardow,nId,7454851"><img align="left" alt="&quot;PiS ukradł nam czas&quot;. Premier alarmuje ws. unijnych miliardów" src="https://i.iplsc.com/pis-ukradl-nam-czas-premier-alarmuje-ws-unijnych-miliardow/000IYR3O6J7FJGO3-C321.jpg" /></a>- Otrzymałem uspokajające informacje o polskich żołnierzach stacjonujących w Libanie oraz Iraku - powiedział premier po Radzie Ministrów. Donald Tusk krytykował także byłego szefa MON Antoniego Macierewicza za &quot;kwestionowanie przetargów przygotowanych w 2014 roku&quot;. Premier mówił także o perspektywie utraty części unijnych środków. - PiS ukradł nam czas - powiedział</p><br clear="all" />

## Komisja ds. wyborów kopertowych. Łukasz Szumowski zeznaje
 - [https://wydarzenia.interia.pl/kraj/na-zywo-komisja-ds-wyborow-kopertowych-lukasz-szumowski-zeznaje,nzId,5651](https://wydarzenia.interia.pl/kraj/na-zywo-komisja-ds-wyborow-kopertowych-lukasz-szumowski-zeznaje,nzId,5651)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-04-16T11:33:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/na-zywo-komisja-ds-wyborow-kopertowych-lukasz-szumowski-zeznaje,nzId,5651"><img align="left" alt="Komisja ds. wyborów kopertowych. Łukasz Szumowski zeznaje" src="https://i.iplsc.com/komisja-ds-wyborow-kopertowych-lukasz-szumowski-zeznaje/000IYQR39S9UJ52V-C321.jpg" /></a>Przed komisją ds. wyborów korespondencyjnych z 2020 roku zeznaje Łukasz Szumowski - ówczesny minister zdrowia. Jego przesłuchanie to skutek wcześniejszych zeznań wicepremiera w rządzie PiS Jarosława Gowina. Mówił on, że Szumowski &quot;przekonywał go, że te wybory nie mogą się odbyć i nagle ta decyzja została zmieniona&quot;.</p><br clear="all" />

## Inwigilowani Pegasusem. Adam Bodnar podał konkretną liczbę
 - [https://wydarzenia.interia.pl/kraj/news-inwigilowani-pegasusem-adam-bodnar-podal-konkretna-liczbe,nId,7454772](https://wydarzenia.interia.pl/kraj/news-inwigilowani-pegasusem-adam-bodnar-podal-konkretna-liczbe,nId,7454772)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-04-16T10:54:08+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-inwigilowani-pegasusem-adam-bodnar-podal-konkretna-liczbe,nId,7454772"><img align="left" alt="Inwigilowani Pegasusem. Adam Bodnar podał konkretną liczbę" src="https://i.iplsc.com/inwigilowani-pegasusem-adam-bodnar-podal-konkretna-liczbe/000IJF23RSMT8PU8-C321.jpg" /></a>W latach 2017-2022 kontrola operacyjna przy użyciu Pegasusa objęła 578 osób - wynika z informacji prokuratora generalnego przesłanej do Sejmu i Senatu. Najwięcej osób było objętych taką kontrolą w 2021 roku - dokładnie 162. O tym, że Adam Bodnar przesłał takie pismo do parlamentu jako pierwsze poinformowały w poniedziałek &quot;Wydarzenia&quot; Polsatu.</p><br clear="all" />

## PiS ma plan na Tobiasza Bocheńskiego. Jarosław Kaczyński powierzył mu misję
 - [https://wydarzenia.interia.pl/kraj/news-pis-ma-plan-na-tobiasza-bochenskiego-jaroslaw-kaczynski-powi,nId,7454543](https://wydarzenia.interia.pl/kraj/news-pis-ma-plan-na-tobiasza-bochenskiego-jaroslaw-kaczynski-powi,nId,7454543)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-04-16T07:40:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pis-ma-plan-na-tobiasza-bochenskiego-jaroslaw-kaczynski-powi,nId,7454543"><img align="left" alt="PiS ma plan na Tobiasza Bocheńskiego. Jarosław Kaczyński powierzył mu misję " src="https://i.iplsc.com/pis-ma-plan-na-tobiasza-bochenskiego-jaroslaw-kaczynski-powi/000IYN68CN9CVHQA-C321.jpg" /></a>Tobiasza Bocheńskiego czeka kolejne zadanie. Po porażce w wyborach na prezydenta Warszawy szefostwo PiS planuje powierzyć mu zarządzanie stołecznymi strukturami partii. Te mają znajdować się w &quot;złym stanie&quot;. Ewentualny sukces miałby zwiększyć szanse polityka na silny mandat przed następnymi wyborami parlamentarnymi. </p><br clear="all" />

## Czarne chmury nad minister klimatu. "Nie ma naszej zgody"
 - [https://wydarzenia.interia.pl/kraj/news-czarne-chmury-nad-minister-klimatu-nie-ma-naszej-zgody,nId,7454501](https://wydarzenia.interia.pl/kraj/news-czarne-chmury-nad-minister-klimatu-nie-ma-naszej-zgody,nId,7454501)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-04-16T06:24:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-czarne-chmury-nad-minister-klimatu-nie-ma-naszej-zgody,nId,7454501"><img align="left" alt="Czarne chmury nad minister klimatu. &quot;Nie ma naszej zgody&quot;" src="https://i.iplsc.com/czarne-chmury-nad-minister-klimatu-nie-ma-naszej-zgody/000IYMEIBOGA2H9V-C321.jpg" /></a>- Twardo stoimy za panią minister. Nie ma i nie będzie naszej zgody na odwoływanie dobrych ministrów - zapewnił szef klubu parlamentarnego Polski 2050 Mirosław Suchoń, komentując doniesienia o ewentualnej dymisji szefowej resortu klimatu Pauliny Hennig-Kloski w ramach zapowiadanej rekonstrukcji rządu. Za Hennig-Kloską ciągnie się sprawa tzw. afery wiatrakowej z początku kadencji.</p><br clear="all" />

