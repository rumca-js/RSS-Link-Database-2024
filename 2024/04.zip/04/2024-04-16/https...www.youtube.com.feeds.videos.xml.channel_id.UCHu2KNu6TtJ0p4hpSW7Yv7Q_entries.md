# Source:Jazza, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHu2KNu6TtJ0p4hpSW7Yv7Q, language:en-US

## I tried RUG TUFTING!!!
 - [https://www.youtube.com/watch?v=zqAHbRqplCQ](https://www.youtube.com/watch?v=zqAHbRqplCQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHu2KNu6TtJ0p4hpSW7Yv7Q
 - date published: 2024-04-16T11:00:50+00:00

✨support me on Patreon: https://www.patreon.com/jazzastudios
🖌️ GET MY APP, BRUSHES, MERCH and MORE!
➨ https://www.jazzastudios.com
--------------------------------
JAZZA'S OFFICIAL SOCIALS! - Follow/Sub ↴
▶ TikTok: https://www.tiktok.com/@jazzastudios
▶ Instagram: https://www.instagram.com/jazzastudios/
▶ Twitter: https://twitter.com/jazzastudios
▶ Facebook: https://www.facebook.com/JazzaOfficial/
--------------------------------

