# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed, language:en-US

## EU Officials Dodge Their Own Surveillance Law
 - [https://reclaimthenet.org/eu-officials-dodge-their-own-surveillance-law](https://reclaimthenet.org/eu-officials-dodge-their-own-surveillance-law)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-04-16T18:24:11+00:00

<a href="https://reclaimthenet.org/eu-officials-dodge-their-own-surveillance-law" rel="nofollow" title="EU Officials Dodge Their Own Surveillance Law"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/04/eu-spy-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Leaked documents suggest EU officials seek immunity from their own controversial online surveillance laws, raising accusations of hypocrisy.</p>
<p>The post <a href="https://reclaimthenet.org/eu-officials-dodge-their-own-surveillance-law">EU Officials Dodge Their Own Surveillance Law</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## House Judiciary Probes Brazil’s Overreaching Censorship Pressure On X
 - [https://reclaimthenet.org/house-judiciary-probes-brazils-overreaching-x-censorship](https://reclaimthenet.org/house-judiciary-probes-brazils-overreaching-x-censorship)
 - RSS feed: https://reclaimthenet.org/feed
 - date published: 2024-04-16T17:38:00+00:00

<a href="https://reclaimthenet.org/house-judiciary-probes-brazils-overreaching-x-censorship" rel="nofollow" title="House Judiciary Probes Brazil&#8217;s Overreaching Censorship Pressure On X"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1440" src="https://reclaimthenet.org/wp-content/uploads/2024/04/musk-24-scaled.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="2560" /></a><p>Amidst escalating tensions, X responds to a US House subpoena, spotlighting its standoff with Brazilian censorship demands.</p>
<p>The post <a href="https://reclaimthenet.org/house-judiciary-probes-brazils-overreaching-x-censorship">House Judiciary Probes Brazil&#8217;s Overreaching Censorship Pressure On X</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

