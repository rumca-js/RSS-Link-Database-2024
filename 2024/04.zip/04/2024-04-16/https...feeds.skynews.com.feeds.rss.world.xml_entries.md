# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Tourists could face water restrictions in Spain
 - [https://news.sky.com/story/tourists-visiting-catalonia-could-be-subject-to-water-restrictions-due-to-drought-emergency-13116847](https://news.sky.com/story/tourists-visiting-catalonia-could-be-subject-to-water-restrictions-due-to-drought-emergency-13116847)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T21:18:00+00:00

Tourists visiting Catalonia in Spain could be subject to water restrictions as the region battles a "drought emergency", the regional government has said.

## Assange's wife accuses US of 'weasel words'
 - [https://news.sky.com/story/julian-assanges-wife-accuses-us-of-weasel-words-after-providing-assurances-in-extradition-bid-13116835](https://news.sky.com/story/julian-assanges-wife-accuses-us-of-weasel-words-after-providing-assurances-in-extradition-bid-13116835)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T19:38:00+00:00

Julian Assange's wife has accused the United States government of "blatant weasel words" as she tries to stop her husband being sent to America to stand trial.

## Sunak tells Netanyahu now is 'moment for calm heads' in wake of Iran attack
 - [https://news.sky.com/story/rishi-sunak-tells-benjamin-netanyahu-now-is-moment-for-calm-heads-in-wake-of-iran-attack-13116778](https://news.sky.com/story/rishi-sunak-tells-benjamin-netanyahu-now-is-moment-for-calm-heads-in-wake-of-iran-attack-13116778)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T17:48:00+00:00

Rishi Sunak has told Israeli Prime Minister Benjamin Netanyahu that it is "a moment for calm heads to prevail" in the wake of Iran's attack over the weekend.

## Seeing Iranian missile fuel tank up close makes claims that attack was symbolic seem absurd
 - [https://news.sky.com/story/seeing-iranian-missile-fuel-tank-up-close-makes-claims-that-attack-on-israel-was-symbolic-seem-absurd-13116767](https://news.sky.com/story/seeing-iranian-missile-fuel-tank-up-close-makes-claims-that-attack-on-israel-was-symbolic-seem-absurd-13116767)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T17:11:00+00:00

When the first pictures of downed Iranian rockets emerged on Sunday morning, they didn't look real.

## Flights diverted at one of world's busiest airports after year's rainfall in a day
 - [https://news.sky.com/story/dubai-arrival-flights-diverted-at-worlds-busiest-airport-as-city-state-struck-by-years-rainfall-in-a-day-13116616](https://news.sky.com/story/dubai-arrival-flights-diverted-at-worlds-busiest-airport-as-city-state-struck-by-years-rainfall-in-a-day-13116616)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T14:36:00+00:00

Flights arriving into Dubai airport - the world's busiest for international travel - are being temporarily diverted this evening to other locations as the city-state is hit by major flooding after heavy rainfall.

## Homes, roads and airport tarmac flooded as Dubai struck by year's rainfall in a day
 - [https://news.sky.com/story/dubai-homes-and-roads-flooded-and-airport-tarmac-looks-like-a-lake-as-city-state-struck-by-years-rainfall-in-a-day-13116616](https://news.sky.com/story/dubai-homes-and-roads-flooded-and-airport-tarmac-looks-like-a-lake-as-city-state-struck-by-years-rainfall-in-a-day-13116616)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T14:36:00+00:00

The United Arab Emirates has been hit by heavy rainfall, including in Dubai where homes and roads were flooded and partially submerged cars were left abandoned.

## Are we heading for World War Three? Experts give their verdicts
 - [https://news.sky.com/story/are-we-heading-for-world-war-three-experts-give-their-verdicts-13116540](https://news.sky.com/story/are-we-heading-for-world-war-three-experts-give-their-verdicts-13116540)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T12:31:00+00:00

In a world that has grown more dangerous in recent years, the nightmare scenario of a Third World War is in the public consciousness.

## EasyJet suspends flights to Israel after Iran attack causes travel chaos
 - [https://news.sky.com/story/easyjet-suspends-flights-to-tel-aviv-over-iran-israel-conflict-after-attack-caused-travel-chaos-above-middle-east-13116492](https://news.sky.com/story/easyjet-suspends-flights-to-tel-aviv-over-iran-israel-conflict-after-attack-caused-travel-chaos-above-middle-east-13116492)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T11:19:00+00:00

EasyJet has suspended all flights to Tel Aviv over safety concerns for journeys to Israel - days after Iran's attack caused chaos for airlines.

## Farage says police would have to 'drag him off stage' after attempt to shut down conference
 - [https://news.sky.com/story/nigel-farage-says-police-would-have-to-drag-him-off-stage-after-attempt-to-shut-down-conference-13116481](https://news.sky.com/story/nigel-farage-says-police-would-have-to-drag-him-off-stage-after-attempt-to-shut-down-conference-13116481)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T11:13:00+00:00

Nigel Farage said police would "have to drag me off stage" after officers moved to shut down the National Conservatism conference in Brussels.

## Paris Olympics torch lit at site of ancient games
 - [https://news.sky.com/story/paris-olympics-torch-lit-at-site-of-ancient-games-in-greece-13116407](https://news.sky.com/story/paris-olympics-torch-lit-at-site-of-ancient-games-in-greece-13116407)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T09:24:00+00:00

The flame that will burn at the Paris Olympics has been kindled at the site of the ancient games in Greece.

## 'Bollard man' who confronted Sydney attacker offered Australian citizenship
 - [https://news.sky.com/story/sydney-mall-attack-bollard-man-who-confronted-knifeman-offered-citizenship-by-australian-prime-minister-13116403](https://news.sky.com/story/sydney-mall-attack-bollard-man-who-confronted-knifeman-offered-citizenship-by-australian-prime-minister-13116403)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T09:09:00+00:00

A Frenchman who confonted the Sydney shopping centre attacker - earning the nickname "Bollard man" - has been offered Australian citizenship.&#160;

## Nuclear accident 'dangerously close' after Ukraine plant attacked
 - [https://news.sky.com/story/ukraine-world-dangerously-close-to-nuclear-accident-after-zaporizhzhia-power-plant-attacked-three-times-13116375](https://news.sky.com/story/ukraine-world-dangerously-close-to-nuclear-accident-after-zaporizhzhia-power-plant-attacked-three-times-13116375)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T08:25:00+00:00

The world is "dangerously close to a nuclear accident" after attacks on a power plant in Ukraine, the head of the International Atomic Energy Agency (IAEA) warned.

## Woman dies after consuming drink at a wellness retreat
 - [https://news.sky.com/story/australia-woman-dies-after-consuming-drink-at-a-wellness-retreat-13116349](https://news.sky.com/story/australia-woman-dies-after-consuming-drink-at-a-wellness-retreat-13116349)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T07:10:00+00:00

A woman has died after consuming a drink at a wellness retreat in Australia.

## Fire breaks out at one of Copenhagen's oldest buildings
 - [https://news.sky.com/story/fire-breaks-out-at-old-stock-exchange-building-in-copenhagen-13116344](https://news.sky.com/story/fire-breaks-out-at-old-stock-exchange-building-in-copenhagen-13116344)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T07:01:00+00:00

A fire has broken out at one of Copenhagen's oldest buildings.

## Mystery object that crashed into Florida home was 'discarded space junk'
 - [https://news.sky.com/story/mystery-object-that-crashed-into-florida-home-last-month-was-discarded-space-junk-nasa-says-13116316](https://news.sky.com/story/mystery-object-that-crashed-into-florida-home-last-month-was-discarded-space-junk-nasa-says-13116316)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-04-16T04:24:00+00:00

A mystery object that fell from the sky before crashing into a home in Florida last month was a piece of space junk, NASA has said.

