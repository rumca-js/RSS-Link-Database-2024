# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## GTA VI Publisher Cancels $140 Million In New Projects And Lays Off Hundreds
 - [https://kotaku.com/gta-6-grand-theft-auto-take-two-layoffs-cancelled-1851414715](https://kotaku.com/gta-6-grand-theft-auto-take-two-layoffs-cancelled-1851414715)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T22:59:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/65ff697b94368ac0feca385bed9a655a.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/gta-6-development-2026-delay-rockstar-office-release-1851359831">Grand Theft Auto VI</a> publisher Take-Two Interactive announced massive cuts in an SEC filing at the end of business today. The company revealed it will lay off 5 percent of its roughly 11,000-strong workforce and has cancelled several in-development projects valued at $140 million in an effort at “rationalizing its…</p><p><a href="https://kotaku.com/gta-6-grand-theft-auto-take-two-layoffs-cancelled-1851414715">Read more...</a></p>

## Publishers Pivoting To Live-Service Games Have Most Devs Worried
 - [https://kotaku.com/live-service-games-survey-devs-worried-unsure-future-1851414325](https://kotaku.com/live-service-games-survey-devs-worried-unsure-future-1851414325)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T21:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/0b64f1000860d378f8e94789ea07c974.jpg" /><p>A newly published survey shows that most game developers aren’t too sure about live-service video games—like Destiny 2 and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/suicide-squad-justice-league-review-is-it-good-batman-1851222047">Suicide Squad</a>—representing a sustainable future for the industry, and think the return of paid DLC might be a better option instead. </p><p><a href="https://kotaku.com/live-service-games-survey-devs-worried-unsure-future-1851414325">Read more...</a></p>

## 8 Final Fantasy Games Are Leaving PlayStation Plus Next Month
 - [https://kotaku.com/final-fantasy-games-leaving-ps-plus-list-may-21-extra-1851414292](https://kotaku.com/final-fantasy-games-leaving-ps-plus-list-may-21-extra-1851414292)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T20:17:05+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/b4d40ccfe2eaaa8406a4542ae5b036a9.jpg" /><p>PlayStation Plus’ Extra and Premium tiers—which include free games you can play as part of your membership—are losing over two dozen titles in May, including eight different <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/best-final-fantasy-games-rpg-7-6-10-12-square-enix-ff-1850560934">Final Fantasy games</a>. If you want to beat them all before they leave, you’d better hurry!</p><p><a href="https://kotaku.com/final-fantasy-games-leaving-ps-plus-list-may-21-extra-1851414292">Read more...</a></p>

## The Internet Reacts To Keanu Reeves As Shadow The Hedgehog
 - [https://kotaku.com/sonic-the-hedgehog-3-shadow-keanu-reeves-reaction-1851414208](https://kotaku.com/sonic-the-hedgehog-3-shadow-keanu-reeves-reaction-1851414208)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T19:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/644e069ac0fee0ff99e054e08ca6ad89.jpg" /><p>After years of speculation, it was revealed that The Matrix, John Wick, and Cyberpunk 2077 star <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/sonic-the-hedgehog-3-movie-shadow-actor-keanu-reeves-1851411677">Keanu Reeves is voicing the broody antihero Shadow</a> in Sonic the Hedgehog 3. Reeves had been a fan-favorite to play Shadow in Paramount’s live-action adaptation since the character debuted in Sonic the Hedgehog 2’s…</p><p><a href="https://kotaku.com/sonic-the-hedgehog-3-shadow-keanu-reeves-reaction-1851414208">Read more...</a></p>

## Hades II Technical Test Is Coming, Time To Get Excited
 - [https://kotaku.com/hades-2-technical-test-sign-up-steam-pc-1851414040](https://kotaku.com/hades-2-technical-test-sign-up-steam-pc-1851414040)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/716c34a1dffd2e658f8c6fc6b948ab8d.jpg" /><p>If you’ve been anxiously awaiting <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/hades-2-early-access-release-2024-pc-steam-epic-games-1850839390">Hades II</a>, the sequel to Supergiant’s stunning <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/hades-the-kotaku-review-1845204803">2020 roguelike</a>, I’ve got good news for you. While the hotly anticipated title isn’t quite entering Early Access just yet, the studio says it’s not all that far off. And ahead of that milestone, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/the-secret-to-the-success-of-bastion-pyre-and-hades-1838082618">Supergiant</a> will be running a t<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://twitter.com/SupergiantGames/status/1780281671394435328" rel

## This Retro Yoyo Platformer Is The Best Game We Saw At PAX East
 - [https://kotaku.com/pipistrello-cursed-yoyo-pocket-trap-pax-east-2024-1851413711](https://kotaku.com/pipistrello-cursed-yoyo-pocket-trap-pax-east-2024-1851413711)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/664d51ee532daba3ddcd1721e086935a.jpg" /><p><a href="https://kotaku.com/pipistrello-cursed-yoyo-pocket-trap-pax-east-2024-1851413711">Read more...</a></p>

## Puppy Chews Up Steam Deck, Is Very Cute And Sorry
 - [https://kotaku.com/steam-deck-cute-puppy-dog-chewed-destroyed-reddit-1851413853](https://kotaku.com/steam-deck-cute-puppy-dog-chewed-destroyed-reddit-1851413853)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T18:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/5a004800a028240a9e1bf7699e5f5e51.jpg" /><p>Puppies are curious creatures. And sometimes that curiosity leads to them getting destructive, as one unlucky <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/valve-steam-deck-pc-console-switch-horizon-zero-dawn-re-1848628507">Steam Deck</a> owner learned recently.<br /></p><p><a href="https://kotaku.com/steam-deck-cute-puppy-dog-chewed-destroyed-reddit-1851413853">Read more...</a></p>

## Star Wars Outlaws Is Getting Every Scoundrel’s Favorite Card Game
 - [https://kotaku.com/star-wars-outlaws-ubisoft-esrb-minigame-sabacc-1851413817](https://kotaku.com/star-wars-outlaws-ubisoft-esrb-minigame-sabacc-1851413817)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/2847a7e921b4e02eb74e63662db12a8d.jpg" /><p>The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/star-wars-outlaws-new-trailer-release-date-han-solo-1851397459">latest trailer</a> for <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/star-wars-outlaws-jabba-the-hutt-preorder-1851412755">Star Wars Outlaws</a>, Ubisoft’s upcoming open-world RPG set in a galaxy far far away, gave us a deeper dive into the story of protagonist Kay Vess, as well as an August 30 release date. In addition to the trailer, the game has also been rated by the Entertainment Software Rating Board (<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/hollow-knight-silksong-esrb-rating-team-cherry-xbox-1851391050">ESRB</a>). The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.esrb.org/ratings/39874/st

## Fallout Is A Great Case For Releasing TV Seasons All At Once
 - [https://kotaku.com/fallout-x-men-97-weekly-episodes-marathon-binge-1851413633](https://kotaku.com/fallout-x-men-97-weekly-episodes-marathon-binge-1851413633)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T17:00:30+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/ef89c31aa6b573dee3007f56badb125d.jpg" /><p>BenDavid Grabinski, one of the co-leads behind the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/scott-pilgrim-takes-off-netflix-anime-review-1851031794">Scott Pilgrim Takes Off anime</a>, recently took to X (formerly Twitter) to express that he thought there was <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://x.com/bdgrabinski/status/1778234823364247997" rel="noopener noreferrer" target="_blank">“literally no upside”</a> to Netflix’s model that releases entire seasons of a show at once. He said that while <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/scott-pilgrim-takes-off-netflix-ramona-backlash-1851043407">Scott Pilgrim</a> did this when it launched on Netflix…</p><p><a href="https://kotaku.com/fallout-x-men-97-weekly-episodes-marathon-binge-185141363

## Steam Hit Ready Or Not Source Code Stolen In Massive Hack
 - [https://kotaku.com/ready-not-steam-swat-shooter-ps5-xbox-hack-1851413503](https://kotaku.com/ready-not-steam-swat-shooter-ps5-xbox-hack-1851413503)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/00e69c28fdb0399e35f0b4d43946fbcc.jpg" /><p>Hackers stole millions of files from the studio behind the controversial hit <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/controversial-steam-best-seller-ready-or-not-is-an-unse-1848317351">Steamshooter Ready or Not</a>, including the source code and console builds of the game, Insider Gaming reports. The development team at Void Interactive has not made the data breach public yet and it doesn’t appear to have included any employee…</p><p><a href="https://kotaku.com/ready-not-steam-swat-shooter-ps5-xbox-hack-1851413503">Read more...</a></p>

## That Silly Crab Soulslike Hits Xbox Game Pass This Month
 - [https://kotaku.com/xbox-game-pass-another-crabs-treasure-nice-death-nhl-24-1851413430](https://kotaku.com/xbox-game-pass-another-crabs-treasure-nice-death-nhl-24-1851413430)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a03978f947fbccbc678a0205d36c5de1.jpg" /><p>We’re about halfway through April, which means <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://news.xbox.com/en-us/2024/04/16/xbox-game-pass-april-2024-wave-2/" rel="noopener noreferrer" target="_blank">another wave of titles</a> is up for grabs for<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/the-12-best-games-on-xbox-game-pass-1841477023"> Xbox Game Pass</a> subscribers. You’ve got a hockey sim, a JRPG, a tower defense action-strategy game, and more, as well as<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/another-crab-s-treasure-gun-assist-mode-aggro-crab-1850915814"> that hilariously silly crustacean Soulslike</a>. It’s a pretty good month, to be honest, as there’s a little…</p><p><a href="https://kotaku.com/xbox-game-pass-another-crabs-treasure-nice-d

## Someone Bought 4,000 Worthless Copies Of Alan Wake
 - [https://kotaku.com/alan-wake-4-000-copies-worthless-don-t-work-ebay-1851413432](https://kotaku.com/alan-wake-4-000-copies-worthless-don-t-work-ebay-1851413432)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T16:07:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/781b9a6b8e7b52a113fb2902aad8fb7e.jpg" /><p>We’ve all bought a second or maybe even third copy of a game we really, really love. Longtime Kotaku readers know of my obsession with <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/i-cant-stop-buying-resident-evil-4-1831898574">re-buying Resident Evil 4.</a> But I’m not sure there’s a game I love so much that I would buy thousands of copies of it. And there’s definitely not a game out there that I adore enough to…</p><p><a href="https://kotaku.com/alan-wake-4-000-copies-worthless-don-t-work-ebay-1851413432">Read more...</a></p>

## 17 Hidden Secrets To Get More Out Of Your Nintendo Switch
 - [https://kotaku.com/nintendo-switch-tips-joycons-bluetooth-1851413171](https://kotaku.com/nintendo-switch-tips-joycons-bluetooth-1851413171)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T15:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/927be949cc2fcf48a5c7cc6a78c81da2.jpg" /><p>The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://howl.me/clAP8KOq9lB" rel="sponsored noopener noreferrer nofollow noskim" target="_blank">Nintendo Switch</a> has been around the block. To hammer that point home, Nintendo’s ultra-successful console celebrated its seventh release anniversary just last month. The little console that is still widely loved for its innovative controllers and portable form factor, so much so the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/nintendo-switch-2-1851242349">long-speculated Nintendo Switch…</a></p><p><a href="https://kotaku.com/nintendo-switch-tips-joycons-bluetooth-1851413171">Read more...</a></p>

## Final Fantasy 14 Benchmark Gives Fans A Taste Of Dawntrail’s New Features
 - [https://kotaku.com/final-fantasy-14-dawntrail-benchmark-female-hrothgar-1851413073](https://kotaku.com/final-fantasy-14-dawntrail-benchmark-female-hrothgar-1851413073)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T15:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e76c7b40e9257f51a7f068297b117196.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/final-fantasy-14-ff14-dawntrail-release-date-elden-ring-1851362771">Dawntrail</a>—the next expansion for Square Enix’s masterfully designed MMORPG <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/final-fantasy-14-ff14-coins-xbox-square-enix-1851348186">Final Fantasy XIV</a>—doesn’t release until July 2, but fans can get a taste of what’s to come right now. The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://na.finalfantasyxiv.com/lodestone/topics/detail/ffe3a1a5430a5a8168ca9782ab9ec0e57cd5be62" rel="noopener noreferrer" target="_blank">official benchmark</a> for the game is available as of April 14, and will let players experience some of the expansion’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" 

## Overwatch 2 Players Are Getting Banned For Swearing, And They’re Not Thrilled
 - [https://kotaku.com/overwatch-2-profanity-filter-rule-code-of-conduct-ban-1851413127](https://kotaku.com/overwatch-2-profanity-filter-rule-code-of-conduct-ban-1851413127)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/52866431ef6136e6d37e9f05b4b21987.jpg" /><p>Blizzard’s customer service is in hot water after a series of exchanges about Overwatch 2’s profanity rules caught the attention of the community and subsequently went viral. Apparently, profanity of any kind is considered against the hero shooter’s code of conduct, and if someone reports it, seemingly regardless of…</p><p><a href="https://kotaku.com/overwatch-2-profanity-filter-rule-code-of-conduct-ban-1851413127">Read more...</a></p>

## Yoko Taro Explains Why He Envies Stellar Blade And Its Director
 - [https://kotaku.com/stellar-blade-nier-yoko-taro-jealous-hyung-tae-kim-1851413085](https://kotaku.com/stellar-blade-nier-yoko-taro-jealous-hyung-tae-kim-1851413085)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T14:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/52f989182b3398ab387644161c839dea.jpg" /><p>The similarities between <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/nier-automata-the-kotaku-review-1793002839">Nier: Automata</a> and Shift Up’s upcoming PlayStation 5 exclusive, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/stellar-blade-ps5-game-demo-preview-dmc-sekiro-1851375165">Stellar Blade</a>, are evident—and not just because <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.ign.com/articles/stellar-blade-dev-talks-inspirations-and-yes-nier-automata-is-right-up-there" rel="noopener noreferrer" target="_blank">the former inspired the latter</a>. Both games center women piecing together a world at its collapse, which makes the two sisters of a sort. And as it does between sisters, jealousy…</p><p><a href="https://kotaku.com/stellar-blade-nier-

## Final Fantasy VII: The Kotaku Retro Review
 - [https://kotaku.com/final-fantasy-7-ff7-review-1997-worth-playing-1851411735](https://kotaku.com/final-fantasy-7-ff7-review-1997-worth-playing-1851411735)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/bc272ac1102a82af30e860fd5d284518.jpg" /><p>After helping my childhood friend, Cloud, through a reality-bending experience to reclaim his identity, I listen as he apologizes for his worst actions and explains to a room full of people why he misled everyone. Yes, his mind was under the influence of an invasive presence, but this confession comes from a place of…</p><p><a href="https://kotaku.com/final-fantasy-7-ff7-review-1997-worth-playing-1851411735">Read more...</a></p>

## Jabba Is Not Just A Pre-Order Bonus In Star Wars Outlaws, Ubisoft Confirms
 - [https://kotaku.com/star-wars-outlaws-jabba-the-hutt-preorder-1851412755](https://kotaku.com/star-wars-outlaws-jabba-the-hutt-preorder-1851412755)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T14:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/274aa97918daaa595434d2182fb69c13.jpg" /><p>Ubisoft’s decision to keep a mission featuring everyone’s favorite intergalactic crime lord, Jabba the Hutt, behind the most eye-wateringly expensive versions of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/star-wars-outlaws-release-date-pc-xbox-ps5-timeline-1851141003">Star Wars Outlaws</a> caused widespread internet panic in recent days. Given how much of the game’s promotion has featured the grumpy space worm, was the key…</p><p><a href="https://kotaku.com/star-wars-outlaws-jabba-the-hutt-preorder-1851412755">Read more...</a></p>

## If You’re Worried About The Fallout TV Series Messing With Canon, You’re Missing The Point
 - [https://kotaku.com/fallout-tv-series-canon-amazon-good-adaptation-1851411618](https://kotaku.com/fallout-tv-series-canon-amazon-good-adaptation-1851411618)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-04-16T14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/657bd8548cb5a71e86e4b6cd98782486.jpg" /><p>What makes a good video game adaptation? For some, it’s a rock solid story set in a well-known world, but for a very vocal group of gamers, it’s a faithful, beat-by-beat recreation of beloved source material. Those who fall into that latter school of thought are the same people who are angry that <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/halo-tv-master-chief-sex-scene-pablo-schreiber-makee-1851179655">Master Chief had sex</a>…</p><p><a href="https://kotaku.com/fallout-tv-series-canon-amazon-good-adaptation-1851411618">Read more...</a></p>

