# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## Google Workers Protest Cloud Contract With Israel's Government
 - [https://www.wired.com/story/google-no-tech-for-apartheid-project-nimbus-israel-gaza-protest](https://www.wired.com/story/google-no-tech-for-apartheid-project-nimbus-israel-gaza-protest)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2024-04-16T17:09:10+00:00

Google employees are staging sit-ins and protests at company offices in New York and California over “Project Nimbus,” a cloud contract with Israel's government, as the country's war with Hamas continues.

