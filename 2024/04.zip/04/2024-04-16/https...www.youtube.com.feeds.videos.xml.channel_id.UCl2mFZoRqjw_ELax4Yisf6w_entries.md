# Source:Louis Rossmann, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Banks start using purchase history for targeted ads 🤦
 - [https://www.youtube.com/watch?v=VCiXu6S6vEw](https://www.youtube.com/watch?v=VCiXu6S6vEw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2024-04-16T22:50:55+00:00

👉 https://media.chase.com/news/chase-launches-chase-media-solutions
👉 https://www.pcmag.com/news/chase-bank-to-let-advertisers-target-customers-based-on-spending-habits
👉 Merchandise: https://store.rossmanngroup.com/memes-dreams.html
🔵 Cheesy mugs & t-shirts: https://bit.ly/rossmannstore
👉 Rossmann chat: https://matrix.to/#/#rossmannrepair:matrix.org

👉 Equipment used:
🔵 Chair: https://ebay.us/uYLTzn
🔵 Chair: https://amzn.to/49ldfme
🔵 Blue Microphone: https://amzn.to/3g1hsok
🔵 Headset microphone: https://amzn.to/3TEO3BR
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av 
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to earn ad

