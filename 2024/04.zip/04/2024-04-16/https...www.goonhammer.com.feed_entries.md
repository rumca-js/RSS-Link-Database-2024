# Source:Goonhammer, URL:https://www.goonhammer.com/feed, language:en-GB

## Goonhammer’s Ashes of Malifaux Review Part 6: The Outcasts
 - [https://www.goonhammer.com/goonhammers-ashes-of-malifaux-review-part-6-the-outcasts](https://www.goonhammer.com/goonhammers-ashes-of-malifaux-review-part-6-the-outcasts)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T17:00:44+00:00

We&#8217;re closing in on the final leg here in our Ashes review.  Last time, we explored the forests and fens of Malifaux to spy on the Neverborn.  Now, we&#8217;re going out to the wide-open spaces &#8211; the Badlands, the town of Freiholt, and the other places where outlaws and Outcasts gather and plot. Ella Mae [&#8230;]

## Games Industry News Roundup- April 16th, 2024
 - [https://www.goonhammer.com/games-industry-news-roundup-april-16th-2024](https://www.goonhammer.com/games-industry-news-roundup-april-16th-2024)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T16:00:46+00:00

Here at Goonhammer, we know that it’s hard to keep track of all the news happening all the time in the games industry. So much is always going on with games of all sorts, and their related media, it can be a real blink-and-you’ll miss it situation.  That&#8217;s why every week, we round up five [&#8230;]

## Age of Sigmar Event Report and Goodbye to Third Edition
 - [https://www.goonhammer.com/age-of-sigmar-event-report-and-goodbye-to-third-edition](https://www.goonhammer.com/age-of-sigmar-event-report-and-goodbye-to-third-edition)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T15:00:10+00:00

Two weekends past I attended a one-day, three-game Age of Sigmar event at Ragnarok Hobbies. There were 16 players total and we used all the standard rules you&#8217;d expect for a 2,000 point tournament with the current General&#8217;s Handbook. The TO also had optional &#8220;AoS+&#8221; rules in hidden envelopes for anyone that wanted to use [&#8230;]

## Codex Adeptus Custodes – 10th Edition: Crusade Review
 - [https://www.goonhammer.com/codex-adeptus-custodes-10th-edition-crusade-review](https://www.goonhammer.com/codex-adeptus-custodes-10th-edition-crusade-review)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T14:00:05+00:00

&#160; Beanith: When the editors told Norman and myself that the Golden Boys and Girls were getting a reboot, I was overcome with joy and spent the afternoon wondering if Lisa Kudrow would have big enough chops to fill Betty White’s shoes and if Amy Poehler would be sassy enough to play a believable Sophia. [&#8230;]

## Codex Orks – 10th Edition: Crusade Review
 - [https://www.goonhammer.com/codex-orks-10th-edition-crusade-review](https://www.goonhammer.com/codex-orks-10th-edition-crusade-review)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T13:00:11+00:00

Welcome Boyz (gender neutral connotation) to another crusade review. The Orks have made a huge splash with their new detachments but are their crusade rules up to snuff? I assume you clicked this article to find out, so read on! As always we’d like to thank GW for providing us with a copy of the [&#8230;]

## The Best Year in Gaming: Round 2 in the Southwest Conference, Part 2
 - [https://www.goonhammer.com/the-best-year-in-gaming-round-2-in-the-southwest-conference-part-2](https://www.goonhammer.com/the-best-year-in-gaming-round-2-in-the-southwest-conference-part-2)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T12:15:57+00:00

Welcome back to our Best Year in Gaming March Madness bracket competition! Yesterday we finished off the Northwest Conference, and today we&#8217;re moving on to Round 2 in the Southwest Conference. It was an interesting round with a pair of upsets &#8211; 2011 absolutely trounced 1988, partly because a bunch of our Patrons are philistines [&#8230;]

## The Best Year in Gaming: 2017
 - [https://www.goonhammer.com/the-best-year-in-gaming-2017](https://www.goonhammer.com/the-best-year-in-gaming-2017)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T12:10:58+00:00

We take a deep look at the games of 2017 - a surprisingly deep year - and talk about what made it the best year in gaming.

## The Best Year in Gaming: 2023
 - [https://www.goonhammer.com/the-best-year-in-gaming-2023](https://www.goonhammer.com/the-best-year-in-gaming-2023)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T12:00:05+00:00

We take a look back at 2023 and talk about the games released and how it made it into the conversation as one of the best years in gaming history.

## Playin’ and Slayin’ #79 | Adepticon 2024 | The Biggest Space Hulk Game in the World
 - [https://www.goonhammer.com/playin-and-slayin-79-adepticon-2024-the-biggest-space-hulk-game-in-the-world](https://www.goonhammer.com/playin-and-slayin-79-adepticon-2024-the-biggest-space-hulk-game-in-the-world)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T11:00:46+00:00

The Thunderhawk has landed, and the guys have returned home from Adepticon, the world&#8217;s largest miniature gaming convention. Troy, Ty, and Josh are sharing their experiences and highlights from the event. Troy provides a detailed recap of the Space Hulk events that he ran over the weekend, and they all reminisce about the fun memories [&#8230;]

## CYRAC: Kill Team Q2 2024 Spring Tier List
 - [https://www.goonhammer.com/cyrac-kill-team-q2-2024-spring-tier-list](https://www.goonhammer.com/cyrac-kill-team-q2-2024-spring-tier-list)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T10:30:05+00:00

John from Can You Roll a Crit? posts his latest tier list for Kill Team! With the changes from the latest balance dataslate and the new Nightmare kill teams, he covers who are the winners and losers for the new Spring meta!

## JAKTP Episode 61: New Hierotek Meta? Psychomancer Ted Talk from Minnesota
 - [https://www.goonhammer.com/jaktp-episode-61-new-hierotek-meta-psychomancer-ted-talk-from-minnesota](https://www.goonhammer.com/jaktp-episode-61-new-hierotek-meta-psychomancer-ted-talk-from-minnesota)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-04-16T10:00:11+00:00

Travis and Jason are Joined by Ted, talking about the Psychomancer&#8217;s role in his Hierotek Circle playstyle. Differing from the Chronomancer that was popularized at Adepticon! JAKTP Patreon Link: https://www.patreon.com/JustAnotherKillteamPodcast JAKTP Discord Link: https://discord.gg/6653HG9XKb JAKTP Youtube! https://www.youtube.com/channel/@justanotherkillteampodcast Wargames Atlantic Affiliate Link: https://wargamesatlantic.com/?aff=7 Twin Cities Kill Team: https://discord.gg/tek4De5V7R If you have any questions or comments feel [&#8230;]

