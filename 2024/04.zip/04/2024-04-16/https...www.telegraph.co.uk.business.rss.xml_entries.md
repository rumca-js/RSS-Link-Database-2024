# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Oil rises as Israel vows to respond to Iran attack - latest updates
 - [https://www.telegraph.co.uk/business/2024/04/16/ftse-100-markets-latest-news-oil-price-israel-uk-employment](https://www.telegraph.co.uk/business/2024/04/16/ftse-100-markets-latest-news-oil-price-israel-uk-employment)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2024-04-16T06:00:24+00:00



