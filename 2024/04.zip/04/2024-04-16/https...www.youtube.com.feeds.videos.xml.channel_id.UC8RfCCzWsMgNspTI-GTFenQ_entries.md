# Source:Luetin09, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ, language:en-US

## 40K - NO ONE NOTICED THIS FOR 10,000 YEARS? | Warhammer 40,000 Lore/Discussion
 - [https://www.youtube.com/watch?v=Fy1TQbDVgJg](https://www.youtube.com/watch?v=Fy1TQbDVgJg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC8RfCCzWsMgNspTI-GTFenQ
 - date published: 2024-04-16T22:47:36+00:00

► Subscribe: http://goo.gl/oeZMBS 
► Patreon: https://www.patreon.com/Luetin 
► Twitch: http://www.twitch.tv/Luetin
► Twitter: http://twitter.com/luetin09

► BGM Credits:
► Kevin MacLeod (Royalty Free Music): http://incompetech.com/music/
► https://epidemicsound.com

This video is an opinion editorial commentary.
Copyright Disclaimer Under Section 107 of the Copyright Act 1976, allowance is made for fair use purposes such as criticism, commentary, parody, news reporting, teaching, scholarship, and research.

All works used in this video (Images, audio etc) belong to their respective authors
(This does not include the audio commentary or licensed BGM).

Games workshop, Warhammer 40,000, Warhammer, 40k, Space Marine Etc are all Trademarks of Games Workshop Ltd. Games Workshop does not endorse or support the 'Lore' videos. All views and opinions expressed in this video belong to Luetin09 and in no way reflect the views or opinions of Games Workshop Ltd.

