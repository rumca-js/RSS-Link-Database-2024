# Source:Techquickie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q, language:en-US

## The NEW Chip Inside Your Phone! (NPUs)
 - [https://www.youtube.com/watch?v=jRvgELYaDc4](https://www.youtube.com/watch?v=jRvgELYaDc4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q
 - date published: 2024-04-16T20:17:29+00:00

Check out the MSI MAG 1250GL PCIE5 at https://lmg.gg/FDM5n

Neural processing units (NPUs) such as Apple's Neural Engine or the machine learning engine on Google Tensor chips can be found on the iPhone and the Pixel. How do they help run AI right on your phone?

Leave a reply with your requests for future episodes.

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

