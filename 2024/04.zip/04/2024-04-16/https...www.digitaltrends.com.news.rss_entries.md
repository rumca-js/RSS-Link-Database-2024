# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Own an RTX 4090? We have some bad news
 - [https://www.digitaltrends.com/computing/micro-center-rtx-4090-trade-in](https://www.digitaltrends.com/computing/micro-center-rtx-4090-trade-in)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-04-16T18:11:22.467058+00:00

The trade-in value for your expensive RTX 4090 has reportedly tanked, despite the high cost when buying used.

