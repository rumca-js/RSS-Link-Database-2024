# Source:RP - Finanse osobiste, URL:https://pieniadze.rp.pl/rss/1941-finanse-osobiste, language:pl-PL

## Inflacja uderzyła w oprocentowanie obligacji skarbowych. Jak nie stracić?
 - [https://pieniadze.rp.pl/portfel-inwestycyjny/art40177271-inflacja-uderzyla-w-oprocentowanie-obligacji-skarbowych-jak-nie-stracic](https://pieniadze.rp.pl/portfel-inwestycyjny/art40177271-inflacja-uderzyla-w-oprocentowanie-obligacji-skarbowych-jak-nie-stracic)
 - RSS feed: https://pieniadze.rp.pl/rss/1941-finanse-osobiste
 - date published: 2024-04-16T10:15:55+00:00

Część posiadaczy detalicznych obligacji skarbowych kupowanych w maju czeka niemiła niespodzianka. Oprocentowanie ich papierów może spaść nawet kilkukrotnie. Wszystko przez inflację, która gwałtownie wyhamowała.

