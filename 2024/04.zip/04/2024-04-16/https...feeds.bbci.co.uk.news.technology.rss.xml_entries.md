# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Apple update addresses Jerusalem emoji controversy
 - [https://www.bbc.co.uk/news/technology-68831685](https://www.bbc.co.uk/news/technology-68831685)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-04-16T21:55:31+00:00

A new software update stops the Palestinian flag emoji appearing when iPhone users type "Jerusalem".

## Wearable AI gadget faces onslaught of bad reviews
 - [https://www.bbc.com/news/articles/cljdnw77ge6o](https://www.bbc.com/news/articles/cljdnw77ge6o)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-04-16T12:32:49+00:00

A new AI-fuelled gadget has fallen foul of the tech world's expectations.

