# Source:Publisher weekly, URL:https://www.publishersweekly.com/pw/feeds/recent/index.xml, language:en-US

## BISG Looks to the Future at Annual Meeting
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/trade-shows-events/article/94820-bisg-looks-to-the-future-at-annual-meeting.html](http://www.publishersweekly.com/pw/by-topic/industry-news/trade-shows-events/article/94820-bisg-looks-to-the-future-at-annual-meeting.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Bologna 2024: Dead Bunnies and Naked Bottoms: What Makes Children's Books Travel Internationally?
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94835-bologna-2024-dead-bunnies-and-naked-bottoms-what-makes-children-s-books-travel-internationally.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94835-bologna-2024-dead-bunnies-and-naked-bottoms-what-makes-children-s-books-travel-internationally.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Bologna 2024: How Children's Books Can Inspire Action on Sustainability
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94827-bologna-2024-how-children-s-books-can-inspire-action-on-sustainability.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94827-bologna-2024-how-children-s-books-can-inspire-action-on-sustainability.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Bologna 2024: TikTok Pushes English-Language Book Sales in Europe
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94830-bologna-2024-tiktok-pushes-english-language-book-sales-in-europe.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94830-bologna-2024-tiktok-pushes-english-language-book-sales-in-europe.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Carrie Bloxson Promoted at Hachette Book Group, Hachette UK
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/people/article/94822-carrie-bloxson-promoted-at-hachette-book-group-hachette-uk.html](http://www.publishersweekly.com/pw/by-topic/industry-news/people/article/94822-carrie-bloxson-promoted-at-hachette-book-group-hachette-uk.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Earth Day 2024: Q&As with Authors Centering Environmental Conservation
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94833-earth-day-2024-q-as-with-authors-centering-environmental-conservation.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94833-earth-day-2024-q-as-with-authors-centering-environmental-conservation.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Five Publishers Join Lawsuit to Stop Iowa Book Banning Bill
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/94824-five-publishers-join-lawsuit-to-stop-iowa-book-banning-bill.html](http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/94824-five-publishers-join-lawsuit-to-stop-iowa-book-banning-bill.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Four Questions with Ann Zhao
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94831-four-questions-with-ann-zhao.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94831-four-questions-with-ann-zhao.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Just Announced : 'Billy the Kid Comes Home for Christmas' by Dolly Parton
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94825-just-announced-billy-the-kid-comes-home-for-christmas-by-dolly-parton.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94825-just-announced-billy-the-kid-comes-home-for-christmas-by-dolly-parton.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## New PEN America Report Finds School Book Bans at Record Levels
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/94823-new-pen-america-report-finds-school-book-bans-at-record-levels.html](http://www.publishersweekly.com/pw/by-topic/industry-news/publisher-news/article/94823-new-pen-america-report-finds-school-book-bans-at-record-levels.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Noteworthy Picture Book and Novel Sequels: April 2024
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94836-noteworthy-picture-book-and-novel-sequels-april-2024.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94836-noteworthy-picture-book-and-novel-sequels-april-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Obituary: Faith Ringgold
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94834-obituary-faith-ringgold.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94834-obituary-faith-ringgold.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## PW Bookstore of the Year 2024 Finalist: Medicine for Nightmares Bookstore and Gallery
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/awards-and-prizes/article/94779-pw-bookstore-of-the-year-2024-finalist-medicine-for-nightmares-bookstore-and-gallery.html](http://www.publishersweekly.com/pw/by-topic/industry-news/awards-and-prizes/article/94779-pw-bookstore-of-the-year-2024-finalist-medicine-for-nightmares-bookstore-and-gallery.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## PW Sales Rep of the Year 2024 Finalist: Julie Isgrigg
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/awards-and-prizes/article/94783-pw-sales-rep-of-the-year-2024-finalist-julie-isgrigg.html](http://www.publishersweekly.com/pw/by-topic/industry-news/awards-and-prizes/article/94783-pw-sales-rep-of-the-year-2024-finalist-julie-isgrigg.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Q & A with Pan Cooke
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94837-q-a-with-pan-cooke.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94837-q-a-with-pan-cooke.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



## Religion Book Deals: April 17, 2024
 - [http://www.publishersweekly.com/pw/by-topic/industry-news/religion/article/94829-religion-book-deals-april-17-2024.html](http://www.publishersweekly.com/pw/by-topic/industry-news/religion/article/94829-religion-book-deals-april-17-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00

Bethany House to publish Way Church co-founder Noah Herrin's book on manhood, IVP takes bestselling author Jim Cymbala's book of devotions, and more.

## Rights Report: Week of April 15, 2024
 - [http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94838-rights-report-week-of-april-15-2024.html](http://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94838-rights-report-week-of-april-15-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-04-16T04:00:00+00:00



