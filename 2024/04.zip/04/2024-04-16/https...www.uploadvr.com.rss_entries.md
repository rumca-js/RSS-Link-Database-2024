# Source:UploadVR, URL:https://www.uploadvr.com/rss, language:en

## Micro Machines VR &amp; Battle Bows Find A New Home With Beyond Frames
 - [https://www.uploadvr.com/beyond-frames-micro-battle](https://www.uploadvr.com/beyond-frames-micro-battle)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-04-16T14:40:52+00:00

Micro Machines VR and Battle Bows have been transferred to new management following the studio's closure.

## Escape Simulator VR Hands-On: A Great New Way To Play
 - [https://www.uploadvr.com/escape-simulator-vr-impressions](https://www.uploadvr.com/escape-simulator-vr-impressions)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-04-16T11:00:51+00:00

Escape Simulator demonstrates how VR can further enhance existing games.

Our impressions.

## Pimax Announces New Wired PC VR Headsets, $700 Crystal Light &amp; $1800 Crystal Super
 - [https://www.uploadvr.com/pimax-crystal-light-and-crystal-super](https://www.uploadvr.com/pimax-crystal-light-and-crystal-super)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-04-16T01:43:29+00:00

Pimax just announced two new wired PC VR headsets, the $700 Crystal Light and the $1800 Crystal Super.

Specs &amp; details here:

## OpenXR 1.1 Brings Extensions Like Foveated Rendering &amp; More Into The Core Spec
 - [https://www.uploadvr.com/openxr-1-1](https://www.uploadvr.com/openxr-1-1)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-04-16T00:42:20+00:00

OpenXR 1.1 brings a foveated rendering extension &amp; more into the core specification.

Full details here.

