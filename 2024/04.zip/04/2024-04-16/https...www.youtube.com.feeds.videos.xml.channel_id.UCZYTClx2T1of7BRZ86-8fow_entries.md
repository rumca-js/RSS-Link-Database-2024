# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Does Our Solar System Have Immigrants?
 - [https://www.youtube.com/watch?v=01LIfE0-LWo](https://www.youtube.com/watch?v=01LIfE0-LWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2024-04-16T17:00:00+00:00

Visit https://brilliant.org/scishow/ to get started learning STEM for free. The first 200 people will get 20% off their annual premium subscription and a 30-day free trial.

In 2017, astronomers discovered 'Oumuamua — the first definitive interstellar visitor to our solar system. But definitive evidence of space rocks that don't just visit but *join* our solar system is a little more elusive.

Hosted by: Reid Reimers (he/him)
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Adam Brainard, Alex Hackman, Ash, Benjamin Carleski, Bryan Cloer, charles george, Chris Mackey, Chris Peters, Christoph Schwanke, Christopher R Boucher, DrakoEsper, Eric Jensen, Friso, Garrett Galloway, Harrison Mills, J. Copen, Jaap Westera, Jason A Saslow, Jeffrey Mckishen, Jeremy Mattern, Kenny Wilson, Kevin Bealer, Kevin Knupp, Lyndsay Brown, Matt Curls,

