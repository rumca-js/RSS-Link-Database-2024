# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## MSHP Express #4 – Mateusz Wójcik i drifty z Porshe
 - [https://sekurak.pl/mshp-express-4-mateusz-wojcik-i-drifty-z-porshe](https://sekurak.pl/mshp-express-4-mateusz-wojcik-i-drifty-z-porshe)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2024-04-16T10:22:45+00:00

<p>Zapraszamy Was na czwarty odcinek MSHP Express, czyli zapowiedzi prelegentów na majowe Mega Sekurak Hacking Party. Prezentujemy Mateusza Wójcika, który podczas MSHP opowie o bezpieczeństwie sektora automotive. Bilety na imprezę możecie kupić tutaj:&#160;https://sklep.securitum.pl/mshp-maj-2024 Więcej informacji o samym wydarzeniu znajdziecie również na stronie&#160;hackingparty.pl~Łukasz Łopuszański</p>
<p>Artykuł <a href="https://sekurak.pl/mshp-express-4-mateusz-wojcik-i-drifty-z-porshe/" rel="nofollow">MSHP Express #4 &#8211; Mateusz Wójcik i drifty z Porshe</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

