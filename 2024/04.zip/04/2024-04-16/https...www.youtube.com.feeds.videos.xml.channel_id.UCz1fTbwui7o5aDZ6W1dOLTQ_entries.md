# Source:Literature Devil, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ, language:en-US

## Netflix Avatar is Garbage Part 4: King Bumi is Ruined!
 - [https://www.youtube.com/watch?v=TtZ1f6SEQZw](https://www.youtube.com/watch?v=TtZ1f6SEQZw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ
 - date published: 2024-04-16T21:00:14+00:00

Netflix's live action version of Avatar the Last Airbender is absolute garbage and a gutted, soulless version of the source material. This time Avatar Aang faces live action Bumy, mad King of Omashu. In the original, he's a mad genius. In live action, he's just mad. And in typical current year fashion, it's the old mentor who learns from the young since the young apparently know everything and the old need to loosen up and get with the times.

If you liked this check out my main channel: https://www.youtube.com/channel/UCz1fTbwui7o5aDZ6W1dOLTQ

#avatarnetflix #avatarthelastairbender #aang #avatar #netflixseries #netflix #avatarnetflix #avatarthelastairbender #avatarthelastairbendernetflix #avatarthelastairbenderreaction

## Morning Nonsense: Hazbin Hotel and The Deadly Sins of Writing!
 - [https://www.youtube.com/watch?v=7Rd0D9arJ5U](https://www.youtube.com/watch?v=7Rd0D9arJ5U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ
 - date published: 2024-04-16T03:39:44+00:00

MAIN RULE: Please do NOT attack or insult other members of the chat with superchats.

Get Dr. Alpha: Dead Man's Lullaby: https://www.indiegogo.com/projects/dr-alpha-dead-man-s-lullaby-vol-1/x/22169562#/

Dr. Alpha: Miracle Child on Amazon: https://www.amazon.com/dp/B0B7F95YF3

Rumble: https://rumble.com/c/c-2621304

MUSIC:
There You Are (POGO): https://www.youtube.com/watch?v=5tOAZkrkuVA
Surrender (First to Eleven): https://www.youtube.com/watch?v=nUk6ARY7dSg
Walk Like An Egyptian (Bangles): https://www.youtube.com/watch?v=tMnGmoLS6zo
Saturday Night's Alright for Fighting (Elton John): https://www.youtube.com/watch?v=26wEWSUUsUc
Smells Like Teen Spirit Major Key (Nirvana/Sleep Good): https://www.youtube.com/watch?v=dVehv_LDWaE
Surface Pressure JoJo Remix (Thai McGrath): https://www.youtube.com/watch?v=MVOrUkLOEOI
Segata Sanshiro: https://www.youtube.com/watch?v=POkU70cjYI8
Out to Lunch: https://www.youtube.com/watch?v=Vn1pf0Xi3nU
Walking Around in Circles: https://www.youtube.com/watc

