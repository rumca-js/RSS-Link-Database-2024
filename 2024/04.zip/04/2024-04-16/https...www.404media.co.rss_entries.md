# Source:404 Media, URL:https://www.404media.co/rss, language:en

## This Man Wants to ‘Save the World’ By Letting You Jerk Off Into a Computer
 - [https://www.404media.co/orifice-ai-sex-toy](https://www.404media.co/orifice-ai-sex-toy)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-04-16T14:42:49+00:00

The creator of the gimmicky DIY sex sleeve says any criticism against the Orifice is “gene warfare."

## The Dystopian Future of TV Is AI-Generated 'FAST' Garbage
 - [https://www.404media.co/the-dystopian-future-of-tv-is-ai-generated-fast-garbage](https://www.404media.co/the-dystopian-future-of-tv-is-ai-generated-fast-garbage)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-04-16T13:10:05+00:00

TCL's new AI-generated movie "Next Stop Paris" is the next evolution in the algorithmification of TV.

