# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## Grand Theft Auto publisher Take-Two Interactive is laying off 5% of its workforce and 'rationalizing its pipeline,' the latest skin-crawling corporate euphemism for people losing their jobs
 - [https://www.pcgamer.com/gaming-industry/grand-theft-auto-publisher-take-two-interactive-is-laying-off-5-of-its-workforce-and-rationalizing-its-pipeline-the-latest-skin-crawling-corporate-euphemism-for-people-losing-their-jobs](https://www.pcgamer.com/gaming-industry/grand-theft-auto-publisher-take-two-interactive-is-laying-off-5-of-its-workforce-and-rationalizing-its-pipeline-the-latest-skin-crawling-corporate-euphemism-for-people-losing-their-jobs)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T23:17:55+00:00

Alongside the job cuts, Take-Two is also cancelling multiple projects currently in development.

## It took almost 10 years, but REDkit modding tools are finally coming to The Witcher 3 and a test version on Steam is live now
 - [https://www.pcgamer.com/games/rpg/it-took-almost-10-years-but-redkit-modding-tools-are-finally-coming-to-the-witcher-3-and-a-test-version-on-steam-is-live-now](https://www.pcgamer.com/games/rpg/it-took-almost-10-years-but-redkit-modding-tools-are-finally-coming-to-the-witcher-3-and-a-test-version-on-steam-is-live-now)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T22:59:54+00:00

Steam Workshop support is also on the way.

## I swore I wouldn't use child labor in Frostpunk 2… but then the kids went feral, formed gangs, and started having deadly knife fights in the streets
 - [https://www.pcgamer.com/games/city-builder/i-swore-i-wouldnt-use-child-labor-in-frostpunk-2-but-then-the-kids-went-feral-formed-gangs-and-started-having-deadly-knife-fights-in-the-streets](https://www.pcgamer.com/games/city-builder/i-swore-i-wouldnt-use-child-labor-in-frostpunk-2-but-then-the-kids-went-feral-formed-gangs-and-started-having-deadly-knife-fights-in-the-streets)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T22:18:03+00:00

Kids stab the darndest things.

## Gigantic walkers are back in Helldivers 2 with a vengeance, and you're gonna want to bring a 380mm barrage
 - [https://www.pcgamer.com/games/third-person-shooter/gigantic-walkers-are-back-in-helldivers-2-with-a-vengeance-and-youre-gonna-want-to-bring-a-380mm-barrage](https://www.pcgamer.com/games/third-person-shooter/gigantic-walkers-are-back-in-helldivers-2-with-a-vengeance-and-youre-gonna-want-to-bring-a-380mm-barrage)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T22:13:52+00:00

The Automatons have their own Bile Titans now.

## Hades 2 technical test set to begin 'shortly,' signups are open now
 - [https://www.pcgamer.com/games/action/hades-2-technical-test-set-to-begin-shortly-signups-are-open-now](https://www.pcgamer.com/games/action/hades-2-technical-test-set-to-begin-shortly-signups-are-open-now)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T20:02:19+00:00

The early access launch of Hades 2 will follow once the technical test is complete.

## XDefiant is finally getting closer: a stress test starts on Friday and will run all weekend long
 - [https://www.pcgamer.com/games/fps/xdefiant-is-finally-getting-closer-a-stress-test-starts-on-friday-and-will-run-all-weekend-long](https://www.pcgamer.com/games/fps/xdefiant-is-finally-getting-closer-a-stress-test-starts-on-friday-and-will-run-all-weekend-long)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T19:51:37+00:00

Ubisoft had initially said the XDefiant server stress test would only run for 12 hours, but apparently minds have changed.

## Early '90s sci-fi adventure Hamlet was innovating on the survival horror genre before it even existed
 - [https://www.pcgamer.com/games/horror/early-90s-sci-fi-adventure-hamlet-was-innovating-on-the-survival-horror-genre-before-it-even-existed](https://www.pcgamer.com/games/horror/early-90s-sci-fi-adventure-hamlet-was-innovating-on-the-survival-horror-genre-before-it-even-existed)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T18:58:28+00:00

This PC-98 classic presaged Resident Evil by adding action and horror to the dungeon crawler.

## Borderlands 3 community scores a big win for science: 'These players have helped trace the evolutionary relationships of more than a million different kinds of bacteria that live in the human gut'
 - [https://www.pcgamer.com/games/fps/borderlands-3-community-scores-a-big-win-for-science-these-players-have-helped-trace-the-evolutionary-relationships-of-more-than-a-million-different-kinds-of-bacteria-that-live-in-the-human-gut](https://www.pcgamer.com/games/fps/borderlands-3-community-scores-a-big-win-for-science-these-players-have-helped-trace-the-evolutionary-relationships-of-more-than-a-million-different-kinds-of-bacteria-that-live-in-the-human-gut)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T17:52:09+00:00

Launched in 2020, the Borderlands Science project was a major success.

## The blasphemy of playing Half-Life with a gamepad is now easier as Black Mesa gets a sudden weighty update, devs tease 'more dangerous patch' to come
 - [https://www.pcgamer.com/games/fps/the-blasphemy-of-playing-half-life-with-a-gamepad-is-now-easier-as-black-mesa-gets-a-sudden-weighty-update-devs-tease-more-dangerous-patch-to-come](https://www.pcgamer.com/games/fps/the-blasphemy-of-playing-half-life-with-a-gamepad-is-now-easier-as-black-mesa-gets-a-sudden-weighty-update-devs-tease-more-dangerous-patch-to-come)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T16:43:37+00:00

I admit it, I didn't foresee these consequences.

## Here's a portable PS1 built from the remnants of an actual console and it only took folding the motherboard 'like a book'
 - [https://www.pcgamer.com/hardware/heres-a-portable-ps1-built-from-the-remnants-of-an-actual-console-and-it-only-took-folding-the-motherboard-like-a-book](https://www.pcgamer.com/hardware/heres-a-portable-ps1-built-from-the-remnants-of-an-actual-console-and-it-only-took-folding-the-motherboard-like-a-book)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T16:32:04+00:00

Does this hurt the motherboard?

## As Destiny 2 enters its latest 'We're so back' era, you can grab all of its expansions for $45 in the Steam FPS Fest
 - [https://www.pcgamer.com/games/fps/as-destiny-2-enters-its-latest-were-so-back-era-you-can-grab-all-of-its-expansions-for-dollar45-in-the-steam-fps-fest](https://www.pcgamer.com/games/fps/as-destiny-2-enters-its-latest-were-so-back-era-you-can-grab-all-of-its-expansions-for-dollar45-in-the-steam-fps-fest)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T16:23:10+00:00

The recent Into the Light update has been a big hit.

## It's weird that the Fallout TV show glosses over one of the series' biggest antagonists
 - [https://www.pcgamer.com/movies-tv/its-weird-that-the-fallout-tv-show-glosses-over-one-of-the-series-biggest-antagonists](https://www.pcgamer.com/movies-tv/its-weird-that-the-fallout-tv-show-glosses-over-one-of-the-series-biggest-antagonists)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T16:23:07+00:00

Especially when it still appears.

## Final Fantasy 14's graphical update has committed the cardinal sin of messing with lalafell teeth, making them more terrifying than ever
 - [https://www.pcgamer.com/games/mmo/final-fantasy-14s-graphical-update-has-committed-the-cardinal-sin-of-messing-with-lalafell-teeth-making-them-more-terrifying-than-ever](https://www.pcgamer.com/games/mmo/final-fantasy-14s-graphical-update-has-committed-the-cardinal-sin-of-messing-with-lalafell-teeth-making-them-more-terrifying-than-ever)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T16:10:45+00:00

Fans aren't sure if they prefer W I D E void or dolphin mouth.

## After community suspicion, Palworld finally fixes an issue that held your Pals back from achieving their full potential
 - [https://www.pcgamer.com/games/survival-crafting/after-community-suspicion-palworld-finally-fixes-an-issue-that-held-your-pals-back-from-achieving-their-full-potential](https://www.pcgamer.com/games/survival-crafting/after-community-suspicion-palworld-finally-fixes-an-issue-that-held-your-pals-back-from-achieving-their-full-potential)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T15:37:49+00:00

Get back to work.

## Playseat's latest racing seat makes it crystal clear that you like F1, in case a cockpit in your room wasn't clear enough
 - [https://www.pcgamer.com/hardware/playseats-latest-racing-seat-makes-it-crystal-clear-that-you-like-f1-in-case-a-cockpit-in-your-room-wasnt-clear-enough](https://www.pcgamer.com/hardware/playseats-latest-racing-seat-makes-it-crystal-clear-that-you-like-f1-in-case-a-cockpit-in-your-room-wasnt-clear-enough)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T15:24:21+00:00

I still want one, though.

## The PC Gaming Show returns June 9 to celebrate its 10-year anniversary and the most exciting new PC games
 - [https://www.pcgamer.com/gaming-industry/the-pc-gaming-show-2024-announcement](https://www.pcgamer.com/gaming-industry/the-pc-gaming-show-2024-announcement)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T15:00:32+00:00

Join us for another round of world premieres, exclusive announcements, and developer interviews.

## Updated Star Citizen minimum system requirements look gentle but they're more guidelines than actual rules
 - [https://www.pcgamer.com/games/mmo/updated-star-citizen-minimum-system-requirements-look-gentle-but-theyre-more-guidelines-than-actual-rules](https://www.pcgamer.com/games/mmo/updated-star-citizen-minimum-system-requirements-look-gentle-but-theyre-more-guidelines-than-actual-rules)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T14:35:38+00:00

You still don't want to play this game with less than 32GB of RAM or without a decent CPU.

## US promises Samsung $6.4B to build more chips on US soil, which only increases the chance of a Made in USA GPU at some point
 - [https://www.pcgamer.com/hardware/graphics-cards/us-promises-samsung-dollar64b-to-build-more-chips-on-us-soil-which-only-increases-the-chance-of-a-made-in-usa-gpu-at-some-point](https://www.pcgamer.com/hardware/graphics-cards/us-promises-samsung-dollar64b-to-build-more-chips-on-us-soil-which-only-increases-the-chance-of-a-made-in-usa-gpu-at-some-point)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T12:22:45+00:00

Samsung, TSMC, and Intel are all big benefactors from the CHIPS and Science Act cash the US Government is throwing around right now.

## Blizzard obliterates an orb from WoW Classic: Season of Discovery's 3rd phase for causing problems, leaves a terrifying class of Crusader-enchanted players in its wake
 - [https://www.pcgamer.com/games/world-of-warcraft/blizzard-obliterates-an-orb-from-wow-classic-season-of-discoverys-3rd-phase-for-causing-problems-leaves-a-terrifying-class-of-crusader-enchanted-players-in-its-wake](https://www.pcgamer.com/games/world-of-warcraft/blizzard-obliterates-an-orb-from-wow-classic-season-of-discoverys-3rd-phase-for-causing-problems-leaves-a-terrifying-class-of-crusader-enchanted-players-in-its-wake)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T11:39:00+00:00

Enchantment!

## Fortnite executive says its user creation monetisation is strictly '18-plus' but 'in regions where it is permissible, yes we should lower that age'
 - [https://www.pcgamer.com/games/third-person-shooter/fortnite-executive-says-its-user-creation-monetisation-is-strictly-18-plus-but-in-regions-where-it-is-permissible-yes-we-should-lower-that-age](https://www.pcgamer.com/games/third-person-shooter/fortnite-executive-says-its-user-creation-monetisation-is-strictly-18-plus-but-in-regions-where-it-is-permissible-yes-we-should-lower-that-age)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T11:38:36+00:00

"There's a lot of Lego creators that want to still express themselves, [who] can't right now because of how these rules work".

## Children of the Sun review
 - [https://www.pcgamer.com/games/fps/children-of-the-sun-review](https://www.pcgamer.com/games/fps/children-of-the-sun-review)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T11:16:09+00:00

Wipe out a cult with a single bullet.

## My top TikTok account of the minute: this 'guy with two microscopes' that peeps inside computer chips
 - [https://www.pcgamer.com/hardware/processors/my-top-tiktok-account-of-the-minute-this-guy-with-two-microscopes-that-peeps-inside-computer-chips](https://www.pcgamer.com/hardware/processors/my-top-tiktok-account-of-the-minute-this-guy-with-two-microscopes-that-peeps-inside-computer-chips)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T11:14:27+00:00

Ready for your close-up?

## Fan project to revive LawBreakers gets Cliff Bleszinski's backing, as he eyes the prize of somehow getting Nexon interested: 'That's what I'm hoping for'
 - [https://www.pcgamer.com/games/fps/fan-project-aiming-to-revive-lawbreakers-gets-cliff-bleszinskis-backing-as-he-eyes-the-prize-of-somehow-getting-nexon-interested-thats-what-im-hoping-for](https://www.pcgamer.com/games/fps/fan-project-aiming-to-revive-lawbreakers-gets-cliff-bleszinskis-backing-as-he-eyes-the-prize-of-somehow-getting-nexon-interested-thats-what-im-hoping-for)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T11:04:31+00:00

Don't call it a comeback. Mainly because you can't play it.

## The most underrated Deus Ex game is criminally cheap on Steam, even though you all deserve to pay more after being so mean about it
 - [https://www.pcgamer.com/games/rpg/the-most-underrated-deus-ex-game-is-criminally-cheap-on-steam-even-though-you-all-deserve-to-pay-more-after-being-so-mean-about-it](https://www.pcgamer.com/games/rpg/the-most-underrated-deus-ex-game-is-criminally-cheap-on-steam-even-though-you-all-deserve-to-pay-more-after-being-so-mean-about-it)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T10:59:53+00:00

I've been carrying this grudge for 21 years.

## My new roguelike obsession is a turn-based strategy game that makes you feel like a samurai John Wick
 - [https://www.pcgamer.com/games/roguelike/my-new-roguelike-obsession-is-a-turn-based-strategy-game-that-makes-you-feel-like-a-samurai-john-wick](https://www.pcgamer.com/games/roguelike/my-new-roguelike-obsession-is-a-turn-based-strategy-game-that-makes-you-feel-like-a-samurai-john-wick)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T10:30:23+00:00

Shogun Showdown is one part Slay the Spire, one part Into the Breach, and one part Kurosawa movie.

## Fallout fans are doing the maths on Lucy's level by the end of the TV show, and it turns out she's barely tougher than a radroach
 - [https://www.pcgamer.com/movies-tv/fallout-fans-are-doing-the-maths-on-lucys-level-by-the-end-of-the-tv-show-and-it-turns-out-shes-barely-tougher-than-a-radroach](https://www.pcgamer.com/movies-tv/fallout-fans-are-doing-the-maths-on-lucys-level-by-the-end-of-the-tv-show-and-it-turns-out-shes-barely-tougher-than-a-radroach)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T10:20:34+00:00

It's about the journey, not the destination.

## The best free demos to play now in the Steam FPS Fest
 - [https://www.pcgamer.com/software/the-best-free-demos-to-play-now-in-the-steam-fps-fest](https://www.pcgamer.com/software/the-best-free-demos-to-play-now-in-the-steam-fps-fest)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T09:58:11+00:00

Sample great shooters today.

## Ubisoft responds as Star Wars Outlaws comes under fire for Jabba the Hutt season pass exclusive
 - [https://www.pcgamer.com/games/action/ubisoft-responds-as-star-wars-outlaws-comes-under-fire-for-jabba-the-hutt-season-pass-exclusive](https://www.pcgamer.com/games/action/ubisoft-responds-as-star-wars-outlaws-comes-under-fire-for-jabba-the-hutt-season-pass-exclusive)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T01:43:24+00:00

It's just one Jabba mission among many.

## Desktop ATX motherboards with SO-DIMM memory slots? It's not as silly as it sounds
 - [https://www.pcgamer.com/hardware/memory/desktop-atx-motherboards-with-so-dimm-memory-slots-its-not-as-silly-as-it-sounds](https://www.pcgamer.com/hardware/memory/desktop-atx-motherboards-with-so-dimm-memory-slots-its-not-as-silly-as-it-sounds)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-04-16T01:06:11+00:00

Asus went and did it.

