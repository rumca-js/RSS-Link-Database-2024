# Source:Austin Evans, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg, language:en-US

## Don’t Buy This “Steam Deck”
 - [https://www.youtube.com/watch?v=mVymXimICE4](https://www.youtube.com/watch?v=mVymXimICE4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg
 - date published: 2024-04-16T14:49:02+00:00

The Ayaneo Next Lite seems like a great, cheaper alternative to the Steam Deck. It isn’t.

