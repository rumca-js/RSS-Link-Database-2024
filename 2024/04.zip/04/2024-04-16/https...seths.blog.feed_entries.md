# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Refusing the salon of the refused
 - [https://seths.blog/2024/04/refusing-the-salon-of-the-refused](https://seths.blog/2024/04/refusing-the-salon-of-the-refused)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-04-16T09:44:00+00:00

This week is the 150th anniversary of the most important failed art exhibit of all time. It was organized by and featured artists who weren&#8217;t even among those that had a slot at the runner&#8217;s up exhibit for artists who weren&#8217;t featured in the real Salon in Paris. Manet didn&#8217;t have the guts to join [&#8230;]

