# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Rapid Expansion of Cloud Computing May Hit a Wall With Limited Supply of Power, Water
 - [https://www.theepochtimes.com/business/rapid-expansion-of-cloud-computing-may-hit-a-wall-with-limited-supply-of-power-water-5630195](https://www.theepochtimes.com/business/rapid-expansion-of-cloud-computing-may-hit-a-wall-with-limited-supply-of-power-water-5630195)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-04-16T11:54:39+00:00

Attendees at Amazon's annual cloud computing conference walk past the Amazon Web Services logo in Las Vegas, Nevada, on Nov. 30, 2017. (Salvador Rodriguez/Reuters)

## eSafety Commissioner Issues Guidelines on Harmful Content Online in Wake of Stabbing Attacks
 - [https://www.theepochtimes.com/world/esafety-commissioner-issues-guidelines-on-harmful-content-online-in-wake-of-stabbing-attacks-5630101](https://www.theepochtimes.com/world/esafety-commissioner-issues-guidelines-on-harmful-content-online-in-wake-of-stabbing-attacks-5630101)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-04-16T02:23:12+00:00

This photo taken on Feb. 12, 2023, in Brussels shows reflexions on a smartphone screen of logos of online platforms google, Facebook, LinkedIn, Amazon, Apple store, and TikTok. (KENZO TRIBOUILLARD/AFP via Getty Images)

