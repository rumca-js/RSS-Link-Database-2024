# Source:Marc Brunet, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg, language:en-US

## 6h painting in 60 sec - Frieren Art School 💎 #digitalpainting #frieren #paintingprocess
 - [https://www.youtube.com/watch?v=IaOPd8Q9_MI](https://www.youtube.com/watch?v=IaOPd8Q9_MI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg
 - date published: 2024-04-16T05:03:48+00:00

👨‍🎨 Need help with your art? Visit ➡️cgart.school for my college-equivalent ART School program! NOW ON SALE!

🎵 Robin Hustin - Light It Up

