# Source:TIME - tech, URL:https://time.com/tech/feed, language:en-UK

## We Need to be Ready for Biotech’s ChatGPT Moment
 - [https://time.com/6967625/we-need-to-be-ready-for-biotechs-chatgpt-moment](https://time.com/6967625/we-need-to-be-ready-for-biotechs-chatgpt-moment)
 - RSS feed: https://time.com/tech/feed
 - date published: 2024-04-16T20:20:30+00:00

Like the digital revolution, the biotech revolution stands to transform America’s economy as we know it, writes Eric Schmidt.

## Exclusive: Tech Companies Are Failing to Keep Elections Safe, Rights Groups Say
 - [https://time.com/6967334/ai-elections-disinformation-meta-tiktok](https://time.com/6967334/ai-elections-disinformation-meta-tiktok)
 - RSS feed: https://time.com/tech/feed
 - date published: 2024-04-16T12:02:37+00:00

At least 160 rights groups are calling on tech platforms to adopt greater election safeguards amid concerns over AI-powered disinformation.

## How Virtual Reality Could Transform Architecture
 - [https://time.com/6964951/vr-virtual-reality-architecture-meta-quest](https://time.com/6964951/vr-virtual-reality-architecture-meta-quest)
 - RSS feed: https://time.com/tech/feed
 - date published: 2024-04-16T11:00:00+00:00

Some architects believe virtual reality will lead to more efficient and effective design. Others see it as little more than a gimmick.

