# Source:Eurogamer.net Latest Articles Feed, URL:https://www.eurogamer.net/feed, language:en-gb

## The Witcher 3's official mod editor is now available for testing on Steam
 - [https://www.eurogamer.net/the-witcher-3s-official-mod-editor-is-now-available-for-testing-on-steam?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/the-witcher-3s-official-mod-editor-is-now-available-for-testing-on-steam?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T22:57:24+00:00

<img src="https://assetsio.gnwcdn.com/Geralt-in-The-Witcher-3-Wild-Hunt.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
CD Projekt's official mod editor for The Witcher 3: Wild Hunt is now available for playtesting on Steam - albeit initially only to select registrants - ahead of its full release "later this year".
</p><p>
The editor, formally known as The Witcher 3 REDkit, is <a href="https://store.steampowered.com/news/app/2684660/view/7454095233531125781">described as</a> a "comprehensive modding tool" that's based on the same tools used by CD Projekt to create to Wild Hunt in the first place, and one that "should allow for nearly limitless freedom in modding it".
</p><p>
"From crafting new quests, items, weapons, and characters to developing animations, entire storylines, and new territories," the blurb on REDkit's Steam page continues, "this tool empowers you to shape your adventure precisely how you envision it."
</p> <p><a href=

## Wizards of the Coast "now talking to lots of partners" about next Baldur's Gate
 - [https://www.eurogamer.net/wizards-of-the-coast-now-talking-to-lots-of-partners-about-next-baldurs-gate?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/wizards-of-the-coast-now-talking-to-lots-of-partners-about-next-baldurs-gate?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T21:29:56+00:00

<img src="https://assetsio.gnwcdn.com/BG3_Astarion.webp?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Larian Studios didn't so much smash last year's Baldur's Gate 3 out of the park as launch it straight into orbit, collecting countless Game of the Year awards and even a few BAFTAs along the way. But while the studio has made it clear it has no interest in returning for a Baldur's Gate 4, Dungeons and Dragons owner Wizard of the Coast is definitely onboard for more, and is currently "talking to lots of partners" about the future of the series.
</p><p>
That's according to Eugene Evans, senior vice president of digital strategy and licensing for Wizards of the Coast and parent company Hasbro, who <a href="https://www.pcgamer.com/games/rpg/hasbro-wants-to-make-another-baldurs-gate-sequel-but-its-early-days-yet-we-certainly-hope-that-its-not-another-25-years/">spoke with PC Gamer</a> following <a href="https://www.eurogamer.net/baldurs-gate-

## Hades 2's technical test set to begin "shortly" and sign-ups are now open
 - [https://www.eurogamer.net/hades-2s-technical-test-set-to-begin-shortly-and-sign-ups-are-open-now?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/hades-2s-technical-test-set-to-begin-shortly-and-sign-ups-are-open-now?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T20:00:23+00:00

<img src="https://assetsio.gnwcdn.com/Hades_II_Trailer-(1).png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Hades 2, the hugely anticipated follow-up to developer Supergiant Games' acclaimed 2020 roguelike dungeon crawler, is almost upon us - albeit initially as an early access release - and ahead of its arrival Supergiant is hosting a technical test, with sign-ups officially now open.
</p><p>
Supergiant <a href="https://www.eurogamer.net/hades-is-getting-a-sequel-the-princess-of-the-underworld-is-heading-our-way">announced a second Hades was in the works</a> at the tail-end of 2022, this time promising a new protagonist in the form of the Princess of the Underworld, a new antagonist in the Titan of Time, and a new adventure "rooted in the Underworld of Greek myth and its deep connections to the dawn of witchcraft."
</p><p>
Last September <a href="https://www.eurogamer.net/hades-2-early-access-will-launch-early-next-year">brought word</

## Fallout TV show holding "iconic" stuff back for Season 2, including deathclaws
 - [https://www.eurogamer.net/fallout-tv-show-holding-iconic-stuff-back-for-season-2-including-deathclaws?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/fallout-tv-show-holding-iconic-stuff-back-for-season-2-including-deathclaws?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T18:16:07+00:00

<img src="https://assetsio.gnwcdn.com/Ella-Purnell-Lucy-Fallout-Amazon.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Amazon's Fallout TV show has - a few <a href="https://www.eurogamer.net/certain non-Bethesda Fallout games may no longer be considered canon">minor controversies</a> aside - been a hit with fans since arriving last week; but while it's covered plenty of the video games' post-apocalyptic basics across its eight episodes - from Pip-Boys and Power Armour to Vaults and Vault-Tec - not everything's made the cut. And its creators have now explained they deliberately held some "iconic" stuff back, including deathclaws, to better do them justice in a potential Season 2.
</p><p>
"We wanted to get Deathclaws, but we didn't want to just throw it away," co-showrunner Graham Wagner <a href="https://www.thewrap.com/fallout-season-2-deathclaws-new-vegas/">told the The Wrap</a>. "It's such a monumental piece [of the Fallout mythology]

## PC image quality enhanced: the new DLSS and XeSS tested
 - [https://www.eurogamer.net/digitalfoundry-2024-image-quality-enhanced-the-new-dlss-and-xess-tested?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/digitalfoundry-2024-image-quality-enhanced-the-new-dlss-and-xess-tested?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T14:41:02+00:00

<img src="https://assetsio.gnwcdn.com/IQ-SITE.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Machine learning-based image reconstruction has evolved into a genuinely game-changing technology - and what sets this apart from other PC features is that users can effectively mod improved versions of Nvidia DLSS and Intel XeSS into games with existing support, simply by swapping a .DLL file in the install directories. With that in mind, we wanted to use this unofficial modding technique to give a preview of sorts for the latest versions of DLSS and XeSS, to see what has changed. 
</p><p>
The headlines are straightforward enough: The DLSS SDK has been updated to version 3.7 with a new reconstruction model called 'Model E', while XeSS has transitioned to version 1.3, promising greater quality and stability. We've covered DLSS across the years, but it's been some time since we first looked at XeSS prior to its launch. Back then, my conclusions

## Which games will get Sony's PS5 Pro "Enhanced" label?
 - [https://www.eurogamer.net/which-games-will-get-sonys-ps5-pro-enhanced-label?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/which-games-will-get-sonys-ps5-pro-enhanced-label?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T14:40:14+00:00

<img src="https://assetsio.gnwcdn.com/Untitled-2_GUY1yeR.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Sony's unannounced but widely-expected PlayStation 5 Pro should run games at 60fps with ray-tracing, upscaled to 4K resolution using the console's fresh PlayStation Spectral Super Resolution (PSSR) technology. 
</p><p>
This is Sony's preferred standard for PS5 Pro, <a href="https://www.theverge.com/2024/4/16/24131799/sony-ps5-pro-enhanced-requirements-ultra-boost-mode">The Verge</a> reports, though Sony will also allow games to boast of being PS5 Pro "Enhanced" while offering lower frame-rates if they still offer a boosted maximum resolution on Pro compared to how the game runs on the vanilla PS5.
</p><p>
A third option allows for a game to be described as PS5 Pro "Enhanced" despite having no frame-rate or resolution boost, if its developer enables new ray-tracing effects for a visual difference. This too could qualify games for the

## Xbox announces late April additions to Game Pass
 - [https://www.eurogamer.net/xbox-announces-late-april-additions-to-game-pass?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/xbox-announces-late-april-additions-to-game-pass?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T13:45:08+00:00

<img src="https://assetsio.gnwcdn.com/GKqy4N0aoAEjh2O.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Xbox has announced the next wave of games coming to Game Pass in late April.
</p><p>
It begins today with the release of Harold Halibut across cloud, PC and Xbox Series X/S. "A visually arresting, warm-hearted tale of a gofer searching for his purpose, Harold Halibut flounders amongst endless fetch-quests and waffle," reads our <a href="https://www.eurogamer.net/harold-halibut-review">Eurogamer Harold Halibut review</a>.
</p><p>
Then later in the month the subscription service will receive the likes of <a href="https://www.eurogamer.net/manor-lords-release-date-time-9431">Manor Lords</a> on PC (26th April), and the day one releases Eiyuden Chronicle: Hundred Heroes (23rd April) and Another Crab's Treasure (25th April).
</p> <p><a href="https://www.eurogamer.net/xbox-announces-late-april-additions-to-game-pass?utm_source=feed&amp;utm_me

## Nintendo Indie World Showcase announced
 - [https://www.eurogamer.net/nintendo-indie-world-showcase-announced?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/nintendo-indie-world-showcase-announced?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T13:34:17+00:00

<img src="https://assetsio.gnwcdn.com/GLScytDXUAAehzJ.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Nintendo has announced that the next Indie World Showcase will take place tomorrow.</p><p>Airing on Wednesday, 17th April on YouTube, the show will last for around 20 minutes, the company said. Starting at 3pm UK time, the showcase will cover a number of announcements and updates for a variety of indie games, all of which will be coming to Nintendo Switch this year.</p><p>Will we finally hear something more about Hollow Knight Silksong? After all, it has been a while since it was first announced, and <a href="https://www.eurogamer.net/hollow-knight-silksong-gets-xbox-store-page-on-april-fools-day">Xbox did add a sales page for the Indie game recently</a>.</p> <p><a href="https://www.eurogamer.net/nintendo-indie-world-showcase-announced?utm_source=feed&amp;utm_medium=rss&amp;utm_campaign=feed">Read more</a></p>

## Apex Legends won't censor game for Saudi Arabia esports tournament, Respawn says
 - [https://www.eurogamer.net/apex-legends-wont-censor-game-for-saudi-arabia-esports-tournament-respawn-says?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/apex-legends-wont-censor-game-for-saudi-arabia-esports-tournament-respawn-says?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T12:29:55+00:00

<img src="https://assetsio.gnwcdn.com/image-(90).png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Apex Legends developer Respawn has told fans it will not change the game to block certain characters and cosmetics from being played during the Esports World Cup in Saudi Arabia this summer, despite concerns over how the country might censor the battle royale's diverse character roster. 
</p><p>
Earlier this month, the Esports World Cup social media feed announced that Apex Legends had "[entered] the arena", stating only the "best will compete for fame, fortune, and glory" at the Riyadh-based tournament. 
</p><p>
This revelation was immediately met with ire from the Apex Legends community. Fans pointed to the contradiction of a country notorious for its poor LGBTQ+ rights hosting a tournament featuring Respawn's inclusive battle royale, which includes many playable LGBTQ+ characters, as well as Pride cosmetics. 
</p> <p><a href="https://www

## Baldur's Gate 3 mod suggests popular NPC previously considered as a party member
 - [https://www.eurogamer.net/baldurs-gate-3-mod-suggests-popular-npc-previously-considered-as-a-party-member?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/baldurs-gate-3-mod-suggests-popular-npc-previously-considered-as-a-party-member?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T12:16:22+00:00

<img src="https://assetsio.gnwcdn.com/16zr0xlt65nc1.webp?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Baldur's Gate 3 players who have modded their games are seeing references to a popular NPC character that suggests they were once set for full-on companion status.
</p><p>
The <a href="https://www.nexusmods.com/baldursgate3/mods/2631">Overexplained Interaction Options</a> mod allows you to see which of your party members will approve or disapprove of conversation options, and was originally uploaded to Nexus Mods last year. 
</p><p>
Over time, players have been using the mod as they progress into Baldur's Gate 3's final third - and it's within Act Three that references to a very familiar name pop up.
</p> <p><a href="https://www.eurogamer.net/baldurs-gate-3-mod-suggests-popular-npc-previously-considered-as-a-party-member?utm_source=feed&amp;utm_medium=rss&amp;utm_campaign=feed">Read more</a></p>

## Keanu Reeves in Sonic the Hedgehog was foreshadowed all along
 - [https://www.eurogamer.net/keanu-reeves-in-sonic-the-hedgehog-was-foreshadowed-all-along?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/keanu-reeves-in-sonic-the-hedgehog-was-foreshadowed-all-along?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T12:02:41+00:00

<img src="https://assetsio.gnwcdn.com/shadow-the-hedgehog.png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Last night it was revealed that <a href="https://www.eurogamer.net/sonic-the-hedgehog-3-movie-reportedly-casts-keanu-reeves-as-shadow">Keanu Reeves will be the voice of Shadow</a> in the forthcoming Sonic the Hedgehog 3 film.
</p><p>
The news quickly spread across social media, with users sharing memes of Shadow, Cyberpunk 2077 and more in celebration.
</p><p>
Thing is, the first Sonic film foreshadowed (get it) Keanu Reeves' involvement way back in the first film. Sort of.
</p> <p><a href="https://www.eurogamer.net/keanu-reeves-in-sonic-the-hedgehog-was-foreshadowed-all-along?utm_source=feed&amp;utm_medium=rss&amp;utm_campaign=feed">Read more</a></p>

## The Witcher's video game voice star weighs in on Netflix adaptation
 - [https://www.eurogamer.net/the-witchers-video-game-voice-star-weighs-in-on-netflix-adaptation?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/the-witchers-video-game-voice-star-weighs-in-on-netflix-adaptation?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T11:16:49+00:00

<img src="https://assetsio.gnwcdn.com/Geralt-in-The-Witcher-3-Wild-Hunt.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Doug Cockle, the gravelly voice of Geralt in CD Projekt Red's Witcher video games, has shared his thoughts on the Netflix series.</p><p>Speaking with YouTube channel <a href="https://www.youtube.com/watch?v=GcorgrQB9Is&amp;t=2044s">Behind the Voice</a>, Cockle said there were some "choices" made in the writers room for the Netflix adaptation he didn't understand, but appreciated "we have to give different mediums their space".</p><p>The actor noted the show is a "different medium from the games", which themselves are a different medium from the books, comics and other Witcher-related media. The show's "gotta have room to be its own thing", Cockle said.</p> <p><a href="https://www.eurogamer.net/the-witchers-video-game-voice-star-weighs-in-on-netflix-adaptation?utm_source=feed&amp;utm_medium=rss&amp;utm_campaign=feed">Re

## Elden Ring's Shadow of the Erdtree Collector's Edition comes with 18 inches of impalement
 - [https://www.eurogamer.net/elden-rings-shadow-of-the-erdtree-collectors-edition-comes-with-18-inches-of-impalement?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/elden-rings-shadow-of-the-erdtree-collectors-edition-comes-with-18-inches-of-impalement?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T11:11:37+00:00

<img src="https://assetsio.gnwcdn.com/ELDEN-RING-Shadow-of-the-Erdtree-_-Official-Gameplay-Reveal-Trailer-1-44-screenshot-(1).png?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
The Collector's Edition of <a href="https://www.eurogamer.net/elden-ring-shadow-of-the-erdtree-dlc-everything-we-know-9415">Elden Ring DLC</a> Shadow of the Erdtree comes with 18 inches of impalement.
</p><p>
The edition, priced at &pound;224.99, includes the Shadow of the Erdtree expansion, the soundtrack, a hardcover art book, and a statue of new nemesis Messmer the Impaler that's 18 inches tall. 
</p><p>
Notably, this edition does not actually include the original <a href="https://www.eurogamer.net/elden-ring-walkthrough-8042">Elden Ring</a> game, <a href="https://store.bandainamcoent.eu/elden-ring-physical-full-game-ps5-shadow-of-the-erdtree-collector-edition/">unlike other versions</a>.
</p> <p><a href="https://www.eurogamer.net/elden-rings-shadow-of-the-erdtr

## Watch us play the first 90 minutes of Harold Halibut on Xbox Series X
 - [https://www.eurogamer.net/watch-us-play-the-first-90-minutes-of-harold-halibut-on-xbox-series-x?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/watch-us-play-the-first-90-minutes-of-harold-halibut-on-xbox-series-x?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T11:00:00+00:00

<img src="https://assetsio.gnwcdn.com/harold-halibut-2024.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>Yep, you're herring me right. Hot on the heels of yesterday's o-fish-al Eurogamer <a href="https://www.eurogamer.net/harold-halibut-review" target="_blank">review</a>, I'll be diving into the first 90 minnows of Harold Halibut on the Xbox Series X for you in today's live stream!</p><p>If, like me, you've been reeled in by the game's stunning, handcrafted visuals but want to know whether the gameplay is any good before you pike it up, you have come to the right plaice.</p><p>From 2pm BST today, I'll be streaming the Xbox Series X version of Harold Halibut on the link below. So, pick a perch and tuna in for this look at the beginning portion of this "handmade narrative game about friendship and life on a city-sized spaceship submerged in an alien ocean."</p> <p><a href="https://www.eurogamer.net/watch-us-play-the-first-90-minutes-of-h

## Apple pulls iPhone GBA emulator, but not because it encourages piracy
 - [https://www.eurogamer.net/apple-pulls-iphone-gba-emulator-but-not-because-it-encourages-piracy?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/apple-pulls-iphone-gba-emulator-but-not-because-it-encourages-piracy?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T10:51:06+00:00

<img src="https://assetsio.gnwcdn.com/Untitled-1w.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Just days after <a href="https://www.eurogamer.net/apples-app-store-permits-game-emulators-for-the-first-time">changing its policies to allow video game emulators on iPhone</a>, Apple has pulled Game Boy Advance emulator app iGBA from its App Store. 
</p><p>
But this wasn't due to a change of heart by Apple on the moralities of emulators themselves. Instead, it was because iGBA turned out to be a rip-off of another emulator, the open-source GBA4iOS.
</p><p>
An Apple spokesperson confirmed the decision and the company's reasoning for the emulator takedown to <a href="https://www.macrumors.com/2024/04/15/apple-further-explains-igba-removal/">MacRumors</a>, and restated its position that emulators which ran downloaded versions of games, or ROMs, were still allowed on the App Store, despite piracy concerns. 
</p> <p><a href="https://www.euroga

## The Walking Dead publisher crowdfunding big-budget Invincible game
 - [https://www.eurogamer.net/the-walking-dead-publisher-crowdfunding-big-budget-invincible-game?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/the-walking-dead-publisher-crowdfunding-big-budget-invincible-game?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T10:08:46+00:00

<img src="https://assetsio.gnwcdn.com/Skybound-Invincible-promo.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>The Walking Dead publisher Skybound has plans for a new AAA Invincible game, and is now crowdfunding to make it all happen.</p><p>Skybound said this game - which will be based upon Prime's hit superhero animated series (which in turn is based on the comics) of the same name - will be developed by a 30-person studio boasting veterans from the likes of Activision Blizzard, EA and Amazon Games. In addition, Invincible (and The Walking Dead) creator Robert Kirkman is also on board.</p><p>This, Skybound said, will ensure "the company is making the best video game in the universe" for fans of the series. It went on to describe the project as a "first-of-its-kind Invincible experience".</p> <p><a href="https://www.eurogamer.net/the-walking-dead-publisher-crowdfunding-big-budget-invincible-game?utm_source=feed&amp;utm_medium=rss&amp;u

## Stellar Blade is superior to NieR: Automata, says Yoko Taro
 - [https://www.eurogamer.net/stellar-blade-is-superior-to-nier-automata-says-yoko-taro?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/stellar-blade-is-superior-to-nier-automata-says-yoko-taro?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T10:01:32+00:00

<img src="https://assetsio.gnwcdn.com/53627564482_29a59c85e1_h.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
<a href="https://www.eurogamer.net/stellar-blade-release-date-time-9430">Stellar Blade</a> is better than NieR: Automata, according to the latter's esteemed director Yoko Taro.
</p><p>
Shift Up's forthcoming action game has been compared to Taro's work since its reveal and now <a href="https://www.ign.com/articles/stellar-blade-x-nier-automata-taro-yoko-hyung-tae-kim">IGN Japan</a> has put the two together in an interview between Taro and Stellar Blade creative director Hyung-Tae Kim.
</p><p>
So why does Taro think Stellar Blade is superior? The "next-gen quality" graphics and "cute female characters", among other reasons as the pair pat each other on the back.
</p> <p><a href="https://www.eurogamer.net/stellar-blade-is-superior-to-nier-automata-says-yoko-taro?utm_source=feed&amp;utm_medium=rss&amp;utm_campaign=feed">Read more

## Star Wars Outlaws' pricey extra Jabba the Hutt mission is "optional" and "additional", Ubisoft says
 - [https://www.eurogamer.net/star-wars-outlaws-pricey-extra-jabba-the-hutt-mission-is-optional-and-additional-ubisoft-says?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/star-wars-outlaws-pricey-extra-jabba-the-hutt-mission-is-optional-and-additional-ubisoft-says?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T09:34:06+00:00

<img src="https://assetsio.gnwcdn.com/Untitled-2_Nd4hMnJ.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>
Ubisoft has responded to the <a href="https://www.eurogamer.net/psa-dont-spend-115-on-star-wars-outlaws-ultimate-edition">outcry over Star Wars Outlaws' Jabba the Hutt mission</a>, which will be available at the game's launch only to owners of the game's pricey Gold or Ultimate Editions.
</p><p>
These editions, priced at &pound;95 and &pound;115 respectively, include the Star Wars Outlaws season pass, which the "Jabba's Gambit" mission is described to be a component of. 
</p><p>
Yesterday, Eurogamer reported on how there was confusion over whether the mission would be the only method of encountering greedy space slug Jabba the Hutt - who has <a href="https://www.eurogamer.net/star-wars-outlaws-players-will-return-to-tatooine-and-its-iconic-mos-eisley-cantina">popped up repeatedly in marketing for the game</a>. It was also unclear wh

## Planetiles offers a satellite's view of Dorfromantik
 - [https://www.eurogamer.net/planetiles-offers-a-satellites-view-of-dorfromantik?utm_source=feed&utm_medium=rss&utm_campaign=feed](https://www.eurogamer.net/planetiles-offers-a-satellites-view-of-dorfromantik?utm_source=feed&utm_medium=rss&utm_campaign=feed)
 - RSS feed: https://www.eurogamer.net/feed
 - date published: 2024-04-16T09:18:22+00:00

<img src="https://assetsio.gnwcdn.com/20240416092948_1.jpg?width=1920&amp;height=1920&amp;fit=bounds&amp;quality=80&amp;format=jpg&amp;auto=webp" /> <p>I don't know if you've ever taken off in a plane from somewhere like Gatwick. There's this moment, about thirty seconds into the flight, where you get enough height and you look down and England has become a cheery parody of itself. It's all green and grass and roughly stitched together fields. There's even a train tootling through it all, although sadly you'll only see smoke coming from it if the electrical wiring has caught fire.</p><p>Anyway, this is what I think of as being Dorfromantik height. It's the height from which that beautiful, thoughtful, mesmerising puzzle game is played. The farms and forests and rivers and towns all pass by beneath you as if you're just out from Gatwick. You're making your decisions about where to play tiles as you wait for the seatbelt sign to come off and the coffee trolley to make its first pass.</p

