# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Helsinki
 - [https://www.youtube.com/watch?v=RvGCtM25fN0](https://www.youtube.com/watch?v=RvGCtM25fN0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-04-16T20:59:54+00:00



## Inflammation
 - [https://www.youtube.com/watch?v=wJ8MVPHSqNU](https://www.youtube.com/watch?v=wJ8MVPHSqNU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-04-16T08:06:31+00:00



## Essential cells
 - [https://www.youtube.com/watch?v=H13080_nPKQ](https://www.youtube.com/watch?v=H13080_nPKQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-04-16T07:50:56+00:00

Sorry, I re-uploaded this one in error, but if you are watching for the first time, thats good.

