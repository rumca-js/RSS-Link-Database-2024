# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## How Old Guard Media Kills Long Form Discussion
 - [https://www.youtube.com/watch?v=e1fMWlQ_uk4](https://www.youtube.com/watch?v=e1fMWlQ_uk4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-04-16T17:07:48+00:00

In this excerpt from our most recent podcast with Vivek Ramaswamy, he and Dr. Peterson discuss his run-in with the Atlantic, how they purposely removed context from his interview, and why the establishment media attempts to kill nuance and long form discussion.

Dr. Peterson's extensive catalog is available now on DailyWire+: https://bit.ly/3KrWbS8

// LINKS //
All links: https://linktr.ee/drjordanbpeterson
Website: https://jordanbpeterson.com
Tour Locations: https://jordanbpeterson.com/events
X: https://twitter.com/jordanbpeterson
Instagram: https://instagram.com/jordan.b.peterson
Facebook: https://facebook.com/drjordanpeterson
Telegram: https://t.me/DrJordanPeterson
Newsletter: https://mailchi.mp/jordanbpeterson.com/youtubesignup

// COURSES //
Discovering Personality: https://jordanbpeterson.com/personality
Self Authoring Suite: https://selfauthoring.com
Understand Myself (personality test): https://understandmyself.com

// BOOKS //
Beyond Order: 12 More Rules for Life: https://jor

## Vivek: "I'm Going to Vote For Donald Trump"
 - [https://www.youtube.com/watch?v=JkCjTtU8w5o](https://www.youtube.com/watch?v=JkCjTtU8w5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-04-16T05:00:09+00:00

In this excerpt from our most recent podcast with Vivek Ramaswamy, he and Dr. Peterson discuss the ongoing U.S. presidential campaign, and the candidate Vivek has endorsed officially.

Dr. Peterson's extensive catalog is available now on DailyWire+: https://bit.ly/3KrWbS8

// LINKS //
All links: https://linktr.ee/drjordanbpeterson
Website: https://jordanbpeterson.com
Tour Locations: https://jordanbpeterson.com/events
X: https://twitter.com/jordanbpeterson
Instagram: https://instagram.com/jordan.b.peterson
Facebook: https://facebook.com/drjordanpeterson
Telegram: https://t.me/DrJordanPeterson
Newsletter: https://mailchi.mp/jordanbpeterson.com/youtubesignup

// COURSES //
Discovering Personality: https://jordanbpeterson.com/personality
Self Authoring Suite: https://selfauthoring.com
Understand Myself (personality test): https://understandmyself.com

// BOOKS //
Beyond Order: 12 More Rules for Life: https://jordanbpeterson.com/Beyond-Order
12 Rules for Life: An Antidote to Chaos: https:/

