# Source:LinuxGizmos.com, URL:https://linuxgizmos.com/feed, language:en-US

## Radxa Teases Upcoming AICore SG2300x Module with Octa-core SOPHON SG2300x SoC
 - [https://linuxgizmos.com/radxa-teases-upcoming-aicore-sg2300x-module-with-octa-core-sophon-sg2300x-soc](https://linuxgizmos.com/radxa-teases-upcoming-aicore-sg2300x-module-with-octa-core-sophon-sg2300x-soc)
 - RSS feed: https://linuxgizmos.com/feed
 - date published: 2024-04-16T05:47:26+00:00

Radxa Teases Upcoming AICore SG2300x Module with Octa-core SOPHON SG2300x SoC
Radxa has recently previewed a new compact embedded module, the AICore SG2300x, built around the SOPHON SG2300x System-on-Chip. This module promises significant computational power for AI applications, featuring dual PHYs and a high-performance Tensor Processing Unit.

