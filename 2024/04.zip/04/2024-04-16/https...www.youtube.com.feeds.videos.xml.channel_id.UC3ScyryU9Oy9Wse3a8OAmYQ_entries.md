# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Ukrainian Teen Describes Being Taken & Held by Russia | Children of Ukraine | FRONTLINE
 - [https://www.youtube.com/watch?v=Cga5fiNFOrE](https://www.youtube.com/watch?v=Cga5fiNFOrE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2024-04-16T15:30:23+00:00

Artem Hutorov is among the Ukrainian teens who share their experiences of being taken & held in Russian-controlled territory in the new FRONTLINE documentary "Children of Ukraine."

This journalism is made possible by viewers like you. Support your local PBS station here: https://www.pbs.org/donate​

Artem Hutorov was 15 years old when a convoy of Russian soldiers and minibuses pulled up to his school in the Ukrainian town of Kupiansk.

The soldiers were armed, the Ukrainian teenager recalls, and their faces were hidden under balaclavas. 

In the above excerpt from the new FRONTLINE documentary "Children of Ukraine," Artem describes what happened next.

“The Russians surrounded the buses, and we were taken out under the control of armed men,” Artem says.

In that moment, he adds, he feared “that we would be shot from all sides.”

For the full story, watch “Children of Ukraine,” premiering Tues., April 16 at 10.9c on YouTube and PBS stations. 

Explore additional reporting on "Children

