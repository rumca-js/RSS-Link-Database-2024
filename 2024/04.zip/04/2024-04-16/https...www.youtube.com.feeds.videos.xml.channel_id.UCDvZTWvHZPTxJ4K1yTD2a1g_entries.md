# Source:Squidmar Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDvZTWvHZPTxJ4K1yTD2a1g, language:en-US

## I turned an amateur painter into a competition winner in one week
 - [https://www.youtube.com/watch?v=hoHu6VxRiIc](https://www.youtube.com/watch?v=hoHu6VxRiIc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDvZTWvHZPTxJ4K1yTD2a1g
 - date published: 2024-04-16T14:17:59+00:00

Join Lord of the Print now and get 99 orcs miniatures STL for only $10!
Lord of the Print Patreon :  https://www.patreon.com/lordoftheprint
Lord of the Print Tribes ; https://www.myminifactory.com/users/LordofthePrint?show=tribe#/

This week, we coached a beginner miniature painter in to a - Hopefully - competition winner in one week! Teaching him everything we know about miniature painting!

Mitch Taranto Tattoos: https://www.instagram.com/mistertarantula/
Mitch Taranto Miniatures: https://www.instagram.com/tarantula_miniz/

🖌️🧟‍♂️👕 Support us by buying the exclusive Squidmar Brushes, Merchandice & sona miniatures: https://www.squidmar.com/shop
🏆 Support me on Patreon: https://www.patreon.com/squidmarminiatures 
👍 Squidmars website for full list of gear I use: https://www.squidmar.com/gear  

_____________________

Emil On 
Instagram http://www.instagram.com/squidmarminiatures
facebook  http://www.facebook.com/ageofsquidmar
Twitter http://www.twitter.com/ageofsquidmar
Lukas instagram

