# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Caitlin Clark celebrates WNBA Draft, first overall selection in NYC with ‘fav person in the world’
 - [https://www.foxnews.com/sports/caitlin-clark-celebrates-wnba-draft-first-overall-selection-nyc-fav-person-world](https://www.foxnews.com/sports/caitlin-clark-celebrates-wnba-draft-first-overall-selection-nyc-fav-person-world)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T23:36:51+00:00

Caitlin Clark, the top overall pick in the 2024 WNBA Draft, celebrated the night in New York City with boyfriend Connor McCaffery.

## Blue state Dem in hot water for racial slur sets new record in Senate primary
 - [https://www.foxnews.com/politics/blue-state-dem-hot-water-racial-slur-sets-new-record-senate-primary](https://www.foxnews.com/politics/blue-state-dem-hot-water-racial-slur-sets-new-record-senate-primary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T23:35:42+00:00

Democratic Rep. David Trone is the largest self-funded candidate of a Senate primary race after contributing $18.5 million to his Maryland Senate campaign.

## Blake Griffin announces retirement from NBA after long career
 - [https://www.foxnews.com/sports/blake-griffin-announces-retirement-nba-long-career](https://www.foxnews.com/sports/blake-griffin-announces-retirement-nba-long-career)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T23:32:24+00:00

Blake Griffin, the No. 1 overall pick of the 2009 NBA Draft by the Los Angeles Clippers, announced his retirement after more than a dozen seasons.

## 2 Kennedy children endorse opponent of progressive Los Angeles DA, cite parole hearing for RFK's killer
 - [https://www.foxnews.com/politics/2-kennedy-children-endorse-opponent-progressive-los-angeles-da-parole-hearing-rfks-killer](https://www.foxnews.com/politics/2-kennedy-children-endorse-opponent-progressive-los-angeles-da-parole-hearing-rfks-killer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T23:25:08+00:00

Two adult children of Robert F. Kennedy said they will endorse Independent Nathan Hochman for Los Angeles County District Attorney, the opponent of progressive incumbent George Gascón.

## Former GOP congressman crashes into Florida highway patrol vehicle in alleged road rage incident: report
 - [https://www.foxnews.com/politics/former-gop-congressman-crashes-florida-highway-patrol-vehicle-alleged-road-rage-incident-report](https://www.foxnews.com/politics/former-gop-congressman-crashes-florida-highway-patrol-vehicle-alleged-road-rage-incident-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T23:21:47+00:00

Former U.S. Congressman Madison Cawthorn was allegedly involved in a car accident with a Florida state trooper on Monday, April 15, 2024, according to a witness who identified him.

## Algerian journalist claims country expelled him without explanation
 - [https://www.foxnews.com/world/algerian-journalist-claims-country-expelled-explanation](https://www.foxnews.com/world/algerian-journalist-claims-country-expelled-explanation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T23:17:54+00:00

Farid Alilat, a writer for Algeria&apos;s French-language Jeune Afrique magazine, claims he was detained for 11 hours after returning from a trip abroad.

## Trump says criminal trial is having a 'reverse effect,' as he campaigns at New York bodega, vows to save city
 - [https://www.foxnews.com/politics/trump-says-criminal-trial-is-having-a-reverse-effect-campaigns-new-york-bodega-vows-save-city](https://www.foxnews.com/politics/trump-says-criminal-trial-is-having-a-reverse-effect-campaigns-new-york-bodega-vows-save-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T23:13:31+00:00

Former President Trump said the criminal trial is having a “reverse effect,&quot; during a campaign visit Tuesday evening to an Upper Manhattan bodega, while vowing to “straighten out New York&quot; by working with the Democrat mayor and governor if elected to another term in the White House.

## One of Trevor Bauer's accusers charged with fraud against him after allegedly faking pregnancy, abortion
 - [https://www.foxnews.com/sports/one-trevor-bauers-accusers-charged-fraud-against-him-allegedly-faking-pregnancy-abortion](https://www.foxnews.com/sports/one-trevor-bauers-accusers-charged-fraud-against-him-allegedly-faking-pregnancy-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T23:10:47+00:00

Darcy Adanna Esemonu, the woman who alleged Trevor Bauer sexually assaulted her, has been charged with two counts of felony fraud and theft by extortion against Bauer.

## Courtney Love brands Taylor Swift as 'not important,' gets slammed online
 - [https://www.foxnews.com/entertainment/courtney-love-brands-taylor-swift-not-important-gets-slammed-online](https://www.foxnews.com/entertainment/courtney-love-brands-taylor-swift-not-important-gets-slammed-online)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:58:12+00:00

Courtney Love spoke candidly about Taylor Swift, calling her &quot;not important&quot; and &quot;not interesting,&quot; but quickly received backlash online.

## Ecuador rations electricity as drought persists in the northern Andes
 - [https://www.foxnews.com/world/ecuador-rations-electricity-drought-persists-northern-andes](https://www.foxnews.com/world/ecuador-rations-electricity-drought-persists-northern-andes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:52:36+00:00

Ecuador&apos;s main cities began to ration electricity on Tuesday as a drought is depleting reservoirs and limiting output at hydroelectric plants that produce a majority of the country&apos;s power.

## Boston Marathon winners eye Paris Olympics following stunning victories
 - [https://www.foxnews.com/sports/boston-marathon-winners-eye-paris-olympics-stunning-victories](https://www.foxnews.com/sports/boston-marathon-winners-eye-paris-olympics-stunning-victories)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:50:45+00:00

Sisay Lemma of Ethiopia and Hellen Obiri of Kenya, the two winners of this year&apos;s Boston Marathon, are now prime candidates for this year&apos;s Paris Olympics.

## Harrison Ford shares how a 'boozy lunch' with Jimmy Buffett led to a spontaneous ear piercing
 - [https://www.foxnews.com/entertainment/harrison-ford-shares-how-boozy-lunch-jimmy-buffett-led-spontaneous-piercing](https://www.foxnews.com/entertainment/harrison-ford-shares-how-boozy-lunch-jimmy-buffett-led-spontaneous-piercing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:45:40+00:00

Harrison Ford recalled how enjoying a &quot;boozy lunch&quot; with Jimmy Buffett led him to get his ear pierced. He shared the story during a tribute event honoring the late musician.

## Minnesota Dems disavow endorsement of candidate accused of stalking opponent
 - [https://www.foxnews.com/politics/minnesota-dems-disavow-endorsement-candidate-accused-stalking-opponent](https://www.foxnews.com/politics/minnesota-dems-disavow-endorsement-candidate-accused-stalking-opponent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:43:56+00:00

Minnesota Democrats have disavowed a local party chapter&apos;s backing of Judd Hoff, a state House candidate with a violent criminal history.

## Both sides claim victory after Supreme Court rules Texas rancher can sue state over flooded lands
 - [https://www.foxnews.com/media/sides-claim-victory-supreme-court-rules-texas-rancher-sue-state-flooded-lands](https://www.foxnews.com/media/sides-claim-victory-supreme-court-rules-texas-rancher-sue-state-flooded-lands)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:30:56+00:00

The Supreme Court ruled that ranchers and other property owners can move forward with a Fifth Amendment lawsuit claiming Texas highway construction flooded their lands.

## African migrants swarm NYC’s City Hall for hearing on ‘experiences of Black immigrants’
 - [https://www.foxnews.com/politics/african-migrants-swarm-nycs-city-hall-hearing-experiences-black-immigrants](https://www.foxnews.com/politics/african-migrants-swarm-nycs-city-hall-hearing-experiences-black-immigrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:25:15+00:00

A hearing at NYC&apos;s City Hall drew a crowd of more than 1,000 people Tuesday morning, including some who reportedly thought they would be getting work visas or green cards.

## Chicago woman sentenced to 50 years without parole after killing pregnant teen and cutting baby from womb
 - [https://www.foxnews.com/us/chicago-woman-sentenced-50-years-without-parole-after-killing-pregnant-teen-cutting-baby-from-womb](https://www.foxnews.com/us/chicago-woman-sentenced-50-years-without-parole-after-killing-pregnant-teen-cutting-baby-from-womb)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:19:45+00:00

Clarisa Figueroa was sentenced to 50 years in prison for the April 2019 murder of 19-year-old Marlen Ochoa-Lopez, whose baby was cut from her womb.

## A painting of Winston Churchill by an artist whose work he hated is up for auction
 - [https://www.foxnews.com/entertainment/painting-winston-churchill-artist-whose-work-hated-auction](https://www.foxnews.com/entertainment/painting-winston-churchill-artist-whose-work-hated-auction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:19:29+00:00

A portrait of Winston Churchill by modernist artist Graham Sutherland went on display Tuesday ahead of an auction in June; the British leader loathed the artist&apos;s work.

## Katie Couric torched for 'cringeworthy' condescension toward Trump supporters reminiscent of Hillary
 - [https://www.foxnews.com/media/katie-couric-torched-cringeworthy-condescension-trump-supporters-hillary](https://www.foxnews.com/media/katie-couric-torched-cringeworthy-condescension-trump-supporters-hillary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:19:08+00:00

Katie Couric was ripped for targeting Trump supporters in a way some found similar to Hillary Clinton&apos;s remark that they can be categorized in a &quot;basket of deplorables.&quot;

## Parts of central US hit by severe storms, while tornadoes strike in Kansas and Iowa
 - [https://www.foxnews.com/us/parts-central-us-hit-severe-storms-while-tornadoes-strike-kansas-iowa](https://www.foxnews.com/us/parts-central-us-hit-severe-storms-while-tornadoes-strike-kansas-iowa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:17:10+00:00

In parts of the middle U.S. on Tuesday, strong storms caused damage and spawned tornadoes in Iowa and Kansas; one tornado left two people injured when their RV flipped over.

## Draft report says Missouri's House speaker stymied ethics investigation into his spending
 - [https://www.foxnews.com/politics/draft-report-says-missouris-house-speaker-stymied-ethics-investigation-spending](https://www.foxnews.com/politics/draft-report-says-missouris-house-speaker-stymied-ethics-investigation-spending)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:14:41+00:00

An ethics panel in Missouri is at an impasse over alleged misconduct by Republican House Speaker Dean Plocher, who reportedly used his office to interfere with an investigation into his actions.

## Rory McIlroy vows commitment to PGA Tour amid LIV Golf speculation: 'My future is here'
 - [https://www.foxnews.com/sports/rory-mcilroy-vows-commitment-pga-tour-liv-golf-speculation-my-future-here](https://www.foxnews.com/sports/rory-mcilroy-vows-commitment-pga-tour-liv-golf-speculation-my-future-here)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:14:08+00:00

PGA Tour star Rory McIlroy reaffirmed his commitment to the Tour on Tuesday after reports speculated about his potential move to LIV Golf.

## Participant, studio behind 'Food, Inc.' and 'An Inconvenient Truth,' shuts down
 - [https://www.foxnews.com/entertainment/participant-studio-food-inc-an-inconvenient-truth-shuts-down](https://www.foxnews.com/entertainment/participant-studio-food-inc-an-inconvenient-truth-shuts-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:12:52+00:00

Participant, the film and television studio behind activist pieces like &quot;Food, Inc.,&quot; &quot;Waiting for Superman&quot; and Al Gore&apos;s &quot;An Inconvenient Truth,&quot; is closing after 20 years.

## Boat containing decomposing bodies of 9 African migrants washes up in Brazil
 - [https://www.foxnews.com/world/boat-containing-decomposing-bodies-9-african-migrants-washes-up-brazil](https://www.foxnews.com/world/boat-containing-decomposing-bodies-9-african-migrants-washes-up-brazil)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:11:29+00:00

A boat containing the bodies of nine migrants from Mali and Mauritania was found adrift Saturday in the Atlantic Ocean off Brazil&apos;s coast.

## U.S. Air Force uncovers ancient campsite on New Mexico base: 'Marks a pivotal moment'
 - [https://www.foxnews.com/lifestyle/u-s-air-force-uncovers-ancient-camp-site-new-mexico-base-marks-pivotal-moment](https://www.foxnews.com/lifestyle/u-s-air-force-uncovers-ancient-camp-site-new-mexico-base-marks-pivotal-moment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:10:47+00:00

United States Air Force (USAF) service members announced the discovery of an ancient campsite on Holloman Air Force Base, near White Sands National Park in New Mexico.

## Former Arkansas deputy pleads guilty to violating suspect's civil rights in violent arrest
 - [https://www.foxnews.com/us/former-arkansas-deputy-pleads-guilty-violating-suspects-civil-rights-violent-arrest](https://www.foxnews.com/us/former-arkansas-deputy-pleads-guilty-violating-suspects-civil-rights-violent-arrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:10:19+00:00

Former Crawford County Sheriff&apos;s Deputy Zackary King has pleaded guilty to violating the civil rights of a suspect he struck during a 2022 arrest.

## River suddenly turns bright green, residents demand tests amid toxic pollution: report
 - [https://www.foxnews.com/world/river-suddenly-turns-bright-green-residents-demand-tests-amid-toxic-pollution-report](https://www.foxnews.com/world/river-suddenly-turns-bright-green-residents-demand-tests-amid-toxic-pollution-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:03:09+00:00

A waterway in a small Russian city has turned bright green and residents are demanding tests amid fears of toxic pollution in the area.

## Jewish organization leader says Israel will be protected by God, despite attacks by Iran or its proxies
 - [https://www.foxnews.com/world/jewish-organization-leader-israel-protected-god-despite-attacks-iran-proxies](https://www.foxnews.com/world/jewish-organization-leader-israel-protected-god-despite-attacks-iran-proxies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:01:54+00:00

Aish CEO Rabbi Steven Burg told Fox News Digital Israel will continue to be protected by God as countries like Iran continue to attack the Holy Land.

## 'Definition of insanity': Frustrated House Republicans blast GOP rebels' threat to oust Johnson
 - [https://www.foxnews.com/politics/definition-of-insanity-frustrated-house-republicans-blast-gop-rebels-threat-oust-johnson](https://www.foxnews.com/politics/definition-of-insanity-frustrated-house-republicans-blast-gop-rebels-threat-oust-johnson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:01:04+00:00

House Republicans are distancing themselves from the effort by two GOP lawmakers to oust Speaker Mike Johnson.

## NPR claims conservative activist Chris Rufo is 'targeting' their CEO with her old pro-Democrat posts
 - [https://www.foxnews.com/media/npr-claims-conservative-activist-chris-rufo-targeting-their-ceo-old-pro-democrat-posts](https://www.foxnews.com/media/npr-claims-conservative-activist-chris-rufo-targeting-their-ceo-old-pro-democrat-posts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T22:00:40+00:00

NPR went after conservative journalist Christopher Rufo after he reposted old leftist tweets from NPR CEO Katherine Maher from before she was at the outlet.

## Kate Hudson tells brother Oliver to ‘block, delete’ haters after his comments about Goldie Hawn's lifestyle
 - [https://www.foxnews.com/entertainment/kate-hudson-tells-brother-oliver-block-delete-haters-after-comments-about-goldie-hawns-lifestyle](https://www.foxnews.com/entertainment/kate-hudson-tells-brother-oliver-block-delete-haters-after-comments-about-goldie-hawns-lifestyle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:55:40+00:00

Kate Hudson gave her brother Oliver Hudson advice after his comments about Goldie Hawn causing &quot;trauma&quot; in his childhood went viral. Oliver later clarified there &quot;was no trauma.&quot;

## Tuition hikes coming to Georgia's public universities this fall
 - [https://www.foxnews.com/us/tuition-hikes-coming-georgias-public-universities-fall](https://www.foxnews.com/us/tuition-hikes-coming-georgias-public-universities-fall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:53:25+00:00

Georgia&apos;s public universities and colleges will increase tuition, effective at the start of the 2024-25 academic year, amid rising costs of operation.

## Blue city mayor defunds police force by more than $8 million to aid migrants
 - [https://www.foxnews.com/politics/blue-city-mayor-defunds-police-force-more-than-8-million-aid-migrants](https://www.foxnews.com/politics/blue-city-mayor-defunds-police-force-more-than-8-million-aid-migrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:45:32+00:00

Denver is making cuts to public services, including the police, to dig up an additional $45 million to fund care for a deluge of migrants coming into the liberal city.

## West Virginia AG vows to keep defending girls' sports despite court ruling against transgender ban
 - [https://www.foxnews.com/politics/west-virginia-ag-vows-keep-defending-girls-sports-despite-court-ruling-against-transgender-ban](https://www.foxnews.com/politics/west-virginia-ag-vows-keep-defending-girls-sports-despite-court-ruling-against-transgender-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:38:50+00:00

West Virginia Attorney General Patrick Morrisey, a Republican, vowed to keep fighting to keep biological males out of girls sports after a federal appeals court ruled Tuesday to overturn a state transgender sports ban.

## Supreme Court wary of obstruction charge used against some Jan 6 riot defendants
 - [https://www.foxnews.com/politics/supreme-court-wary-of-obstruction-charge-used-against-some-january-6-riot-defendants](https://www.foxnews.com/politics/supreme-court-wary-of-obstruction-charge-used-against-some-january-6-riot-defendants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:34:10+00:00

The Supreme Court&apos;s ruling on an obstruction of justice case for a Capitol riot defendant could have major implication on Trump&apos;s unrelated election interference case

## US files 2nd labor complaint after Mexico refuses to act on union-busting by a Mexican company
 - [https://www.foxnews.com/politics/us-files-2nd-labor-complaint-mexico-refuses-act-union-busting-mexican-company](https://www.foxnews.com/politics/us-files-2nd-labor-complaint-mexico-refuses-act-union-busting-mexican-company)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:32:41+00:00

The U.S. Trade Representatives Office said Tuesday it has filed a labor complaint after Mexico refused to act in the case of a Mexican call center that allegedly fired or threatened union organizers.

## Giannis Antetokounmpo reportedly expected to miss start of Bucks-Pacers series
 - [https://www.foxnews.com/sports/giannis-antetokounmpo-reportedly-expected-to-miss-start-of-bucks-pacers-series](https://www.foxnews.com/sports/giannis-antetokounmpo-reportedly-expected-to-miss-start-of-bucks-pacers-series)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:31:32+00:00

The Bucks are reportedly bracing to be without their two-time MVP, but are hopeful he can return by the end of their first-round series against the Pacers.

## 2024 WNBA Championship odds: Aces favored; Fever's odds shorten
 - [https://www.foxnews.com/sports/2024-wnba-championship-odds](https://www.foxnews.com/sports/2024-wnba-championship-odds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:31:29+00:00

The Aces — not Caitlin Clark and the Fever — are favored to win the WNBA title. Check out the odds, including where Clark &amp; Co. sit on the board.

## NASCAR Power Rankings: Chase Elliott hits highest position of season
 - [https://www.foxnews.com/sports/power-rankings-chase-elliott-hits-highest-position-of-season](https://www.foxnews.com/sports/power-rankings-chase-elliott-hits-highest-position-of-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:31:25+00:00

Chase Elliott cracks the top three this week thanks to his win Sunday at Texas. But which two drivers is he still looking to pass?

## Fundraising effort for conflict-hit Ethiopia garners $630M, just over half of $1B goal
 - [https://www.foxnews.com/world/fundraising-effort-conflict-hit-ethiopia-garners-630m-half-1b-goal](https://www.foxnews.com/world/fundraising-effort-conflict-hit-ethiopia-garners-630m-half-1b-goal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:31:08+00:00

A U.N.-backed gathering has reportedly raised some $630 million in funding for conflict-ravaged Ethiopia, but still fell far short of its billion-dollar goal.

## House resolution condemning 'From the River to the Sea' chant as antisemitic passes with 44 opposed
 - [https://www.foxnews.com/politics/house-resolution-condemning-river-sea-chant-antisemitic-passes-44-opposed](https://www.foxnews.com/politics/house-resolution-condemning-river-sea-chant-antisemitic-passes-44-opposed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:23:53+00:00

Dozens of House Democrats voted against a bill to condemn the pro-Palestinian chant &quot;From the river to the sea&quot; on Tuesday.

## Caitlin Clark's Fever jersey sells out most sizes one hour after being drafted
 - [https://www.foxnews.com/sports/caitlin-clarks-fever-jersey-mostly-sold-out-just-one-hour-after-being-drafted](https://www.foxnews.com/sports/caitlin-clarks-fever-jersey-mostly-sold-out-just-one-hour-after-being-drafted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:14:48+00:00

Caitlin Clark fever has already made its way into the WNBA, with the majority or her jerseys selling out just an hour after becoming available.

## Joel Klatt: Coaches in full panic over spring transfer portal. How do we fix it?
 - [https://www.foxnews.com/sports/joel-klatt-coaches-in-full-panic-over-spring-transfer-portal-how-do-we-fix-it](https://www.foxnews.com/sports/joel-klatt-coaches-in-full-panic-over-spring-transfer-portal-how-do-we-fix-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:11:12+00:00

College football coaches have told FOX Sports&apos; Joel Klatt that they&apos;re in panic over the upcoming spring transfer window. Here&apos;s how Klatt would fix the issue.

## Drinking 100% orange juice is linked to surprising health benefits, study finds
 - [https://www.foxnews.com/health/drinking-100-orange-juice-linked-surprising-health-benefits-study-finds](https://www.foxnews.com/health/drinking-100-orange-juice-linked-surprising-health-benefits-study-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:10:37+00:00

A study by Toronto Metropolitan University researched the effects of drinking 100% orange juice vs. sugar-sweetened orange beverages on appetite, food intake and glycemic response in adults.

## Liev Schreiber suffered actor's 'worst nightmare' when his migraine caused amnesia during live show
 - [https://www.foxnews.com/entertainment/liev-schreiber-suffered-actors-worst-nightmare-migraine-caused-amnesia-live-show](https://www.foxnews.com/entertainment/liev-schreiber-suffered-actors-worst-nightmare-migraine-caused-amnesia-live-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:04:52+00:00

Liev Schreiber experienced a medical scare just moments before he was supposed to appear on stage on Broadway and was later diagnosed with temporary amnesia.

## As Warriors dynasty winds down, Steve Kerr eyes another run: 'We're not at the end'
 - [https://www.foxnews.com/sports/as-warriors-dynasty-winds-down-steve-kerr-eyes-another-run-not-at-the-end](https://www.foxnews.com/sports/as-warriors-dynasty-winds-down-steve-kerr-eyes-another-run-not-at-the-end)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T21:03:59+00:00

Steve Kerr looks back on Golden State&apos;s decade of success with gratitude, while vowing to enjoy every last second of his most challenging season as a coach.

## Oklahoma boy's pet octopus is TikTok sensation: 'Wildlife is magnificent'
 - [https://www.foxnews.com/lifestyle/oklahoma-boys-pet-octopus-tiktok-sensation-wildlifewmagnificent](https://www.foxnews.com/lifestyle/oklahoma-boys-pet-octopus-tiktok-sensation-wildlifewmagnificent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T20:58:54+00:00

An Oklahoma boy with a precocious passion for marine biology adopted an octopus after years of begging. The octopus, named Terrance, recently had dozens of babies.

## Joe Burrow believes Bengals match up perfectly against Chiefs: 'We’re built to beat them'
 - [https://www.foxnews.com/sports/joe-burrow-believes-bengals-match-up-perfectly-against-chiefs-built-beat-them](https://www.foxnews.com/sports/joe-burrow-believes-bengals-match-up-perfectly-against-chiefs-built-beat-them)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T20:57:24+00:00

Cincinnati Bengals quarterback Joe Burrow feels his squad is &quot;built to beat&quot; Patrick Mahomes and the Kansas City Chiefs despite them being back-to-back Super Bowl champions.

## Tourists filmed brazenly destroying ancient rock formations at Nevada's Lake Mead: 'Send them to jail'
 - [https://www.foxnews.com/us/tourists-filmed-brazenly-destroying-ancient-rock-formations-nevadas-lake-mead](https://www.foxnews.com/us/tourists-filmed-brazenly-destroying-ancient-rock-formations-nevadas-lake-mead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T20:56:24+00:00

National Park Service (NPS) officials are searching for the two adult men who were filmed destroying ancient rock formations at Lake Mead in Nevada.

## Top Republican demands Biden admin block Iranian foreign minister's visit to UN: 'an insult' to victims
 - [https://www.foxnews.com/world/top-republican-demands-biden-admin-block-iranian-foreign-ministers-visit-to-un-an-insult-to-victims](https://www.foxnews.com/world/top-republican-demands-biden-admin-block-iranian-foreign-ministers-visit-to-un-an-insult-to-victims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T20:54:30+00:00

The United Nations and U.S. State Department both declined to confirm the foreign minister&apos;s visit, but each stressed the need to adhere to access for representatives of all member states.

## Caitlin Clark rocks Prada outfit close to $17,000 for 2024 WNBA Draft
 - [https://www.foxnews.com/sports/caitlin-clark-rocks-prada-outfit-2024-wnba-draft](https://www.foxnews.com/sports/caitlin-clark-rocks-prada-outfit-2024-wnba-draft)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T20:18:09+00:00

Caitlin Clark, the No. 1 overall pick in the 2024 WNBA Draft, was rocking a full Prada outfit on the orange carpet that was nearly $17,000.

## MSNBC host praises 'DEI' officials prosecuting Trump: 'Wonderfully poetic'
 - [https://www.foxnews.com/media/msnbc-host-praises-deis-prosecuting-trump-wonderfully-poetic](https://www.foxnews.com/media/msnbc-host-praises-deis-prosecuting-trump-wonderfully-poetic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T20:03:09+00:00

MSNBC&apos;s Joy Reid applauded the &quot;DEIs&quot; prosecuting Donald Trump on Monday, calling it &quot;wonderfully poetic&quot; as his first criminal trial in New York is underway.

## Arizona rancher defense consultant claims 'cartel influence' in murder probe, rips sheriff's past comments
 - [https://www.foxnews.com/us/arizona-rancher-defense-consiltant-claims-cartel-influence-murder-probe-rips-sheriffs-past-comments](https://www.foxnews.com/us/arizona-rancher-defense-consiltant-claims-cartel-influence-murder-probe-rips-sheriffs-past-comments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:58:58+00:00

George Alan Kelly&apos;s defense is expected to call Santa Cruz County Sheriff David Hathaway, arguing the probe was mired by &quot;cartel influence.&quot;

## Sen Hawley calls on Energy Secretary Granholm to resign in heated exchange over stock trades
 - [https://www.foxnews.com/politics/sen-hawley-calls-on-energy-secretary-granholm-to-resign-in-heated-exchange-over-stock-trades](https://www.foxnews.com/politics/sen-hawley-calls-on-energy-secretary-granholm-to-resign-in-heated-exchange-over-stock-trades)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:57:57+00:00

Sen. Josh Hawley, R-Mo., called on Energy Secretary Jennifer Granholm to immediately resign during a contentious exchange at a hearing on Tuesday morning.

## Utah teen and dad go on Ford racing trip after CEO learns of son’s cancer battle: ‘Hard to put into words’
 - [https://www.foxnews.com/lifestyle/utah-teen-dad-ford-racing-trip-ceo-learns-sons-cancer-battle-hard-put-words](https://www.foxnews.com/lifestyle/utah-teen-dad-ford-racing-trip-ceo-learns-sons-cancer-battle-hard-put-words)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:53:07+00:00

A teen with cancer got a unique experience thanks to the CEO of Ford. The 18-year-old and his dad from Utah were gifted a trip to the performance racing school.

## Ex-MLB infielder arrested as 1 of 4 alleged 'scam artists' in insurance fraud scheme, police say
 - [https://www.foxnews.com/sports/ex-mlb-infielder-arrested-alleged-scam-artists-insurance-fraud-scheme-police-say](https://www.foxnews.com/sports/ex-mlb-infielder-arrested-alleged-scam-artists-insurance-fraud-scheme-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:52:13+00:00

Former MLB infielder Yuniesky Betancourt has been charged by authorities with four felony counts for his involvement in an alleged insurance fraud scam.

## Weedkiller manufacturer seeks lawmakers' help to squelch claims it failed to warn about cancer
 - [https://www.foxnews.com/us/weedkiller-manufacturer-seeks-lawmakers-help-squelch-claims-failed-warn-cancer](https://www.foxnews.com/us/weedkiller-manufacturer-seeks-lawmakers-help-squelch-claims-failed-warn-cancer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:48:49+00:00

Chemical giant Bayer has been lobbying lawmakers to pass bills that would provide it with a legal shield against lawsuits that assert its weedkiller Roundup causes cancer.

## Ukraine prime minister calls for more investment in war-torn country during Chicago stop of US visit
 - [https://www.foxnews.com/politics/ukraine-prime-minister-calls-more-investment-war-torn-country-during-chicago-stop-us-visit](https://www.foxnews.com/politics/ukraine-prime-minister-calls-more-investment-war-torn-country-during-chicago-stop-us-visit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:46:13+00:00

Ukraine Prime Minister Denys Shmyhal spoke to Chicago-area business leaders on Tuesday, as part of multiple stops aimed at drumming up investment in the war-torn country.

## Pentagon spox on whether US will help Israeli attack on Iran: 'That’s a question for Israel'
 - [https://www.foxnews.com/media/pentagon-spox-whether-us-will-help-israeli-attack-iran-question-israel](https://www.foxnews.com/media/pentagon-spox-whether-us-will-help-israeli-attack-iran-question-israel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:30:05+00:00

Pentagon spokesperson Sabrina Singh pressed by FOX News Channel&apos;s Bill Hemmer on the possibility of the US helping Israel&apos;s attack against Iran as the Jewish State&apos;s war cabinet weighs its next move.

## USC cancels valedictorian's graduation speech after anti-Israel social media posts, security concerns emerge
 - [https://www.foxnews.com/media/usc-cancels-valedictorians-graduation-speech-anti-israel-social-media-posts-security-concerns](https://www.foxnews.com/media/usc-cancels-valedictorians-graduation-speech-anti-israel-social-media-posts-security-concerns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:27:36+00:00

A Muslim valedictorian at the University of Southern California has been barred from giving a commencement speech after anti-Israel posts came to light.

## Tennessee woman gets life in prison for killing 4 people over custody dispute
 - [https://www.foxnews.com/us/tennessee-woman-gets-life-prison-killing-4-people-custody-dispute](https://www.foxnews.com/us/tennessee-woman-gets-life-prison-killing-4-people-custody-dispute)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:27:19+00:00

Jazzmine Hall, 29, of Athens, Tennessee, pleaded guilty Monday to killing four people over a custody dispute, and has been sentenced to life in prison.

## Patrick Mahomes gushes about Taylor Swift, praises her interest in football
 - [https://www.foxnews.com/sports/patrick-mahomes-gushes-taylor-swift-praises-her-interest-in-football](https://www.foxnews.com/sports/patrick-mahomes-gushes-taylor-swift-praises-her-interest-in-football)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:23:39+00:00

Kansas City Chiefs great Patrick Mahomes raved about Taylor Swift and dismissed any notion she was a distraction to the team during its skid.

## Watch out for the new ‘ghost hackers’
 - [https://www.foxnews.com/tech/watch-out-new-ghost-hackers](https://www.foxnews.com/tech/watch-out-new-ghost-hackers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:20:02+00:00

Learn how to secure social media accounts, implement legacy contacts, and create a digital estate plan to protect your online assets from &apos;ghost hackers&apos; after your death.

## China pushing US fentanyl crisis, House panel report reveals
 - [https://www.foxnews.com/politics/china-pushing-us-fentanyl-crisis-house-panel-report-reveals](https://www.foxnews.com/politics/china-pushing-us-fentanyl-crisis-house-panel-report-reveals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:18:02+00:00

A new House report released Tuesday revealed that China is fueling the fentanyl crisis in the U.S. to create &quot;chaos and devastation&quot; from the epidemic.

## Indian police kill 29 suspected Maoist rebels in a gunbattle in a central state
 - [https://www.foxnews.com/world/indian-police-kill-29-suspected-maoist-rebels-gunbattle-central-state](https://www.foxnews.com/world/indian-police-kill-29-suspected-maoist-rebels-gunbattle-central-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T19:15:45+00:00

At least 29 suspected Maoist rebels were killed by police in India in the central state of Chhattisgarh on Tuesday; this comes three days before the beginning of a national election.

## Excused juror reveals selection process for Trump's hush money trial: 'Not a fan'
 - [https://www.foxnews.com/politics/excused-juror-reveals-selection-process-trumps-hush-money-trial](https://www.foxnews.com/politics/excused-juror-reveals-selection-process-trumps-hush-money-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:58:21+00:00

An excused juror in former President Donald Trump&apos;s hush money trial spoke to Fox News Tuesday about the selection process after she was dismissed.

## Circus performer follows in parents' footsteps as human cannonball, feeling 7 G's with each launch
 - [https://www.foxnews.com/lifestyle/circus-performer-human-cannonball](https://www.foxnews.com/lifestyle/circus-performer-human-cannonball)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:45:33+00:00

Skyler Miser has grown up around the circus. Now as the Ringling Rocket, she knows circus life well, as both of her parents are also former performers.

## Trump trial: Why can't Americans see or hear what is going on inside the courtroom?
 - [https://www.foxnews.com/politics/trump-trial-why-cant-americans-see-hear-going-inside-courtroom](https://www.foxnews.com/politics/trump-trial-why-cant-americans-see-hear-going-inside-courtroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:45:13+00:00

Former President Donald Trump is the first U.S. president to face criminal charges in an American courtroom, yet most of the country is getting news about the trial secondhand.

## Lawyer for former top lawmaker in Michigan House expects he will be charged
 - [https://www.foxnews.com/politics/lawyer-former-top-lawmaker-michigan-house-expects-be-charged](https://www.foxnews.com/politics/lawyer-former-top-lawmaker-michigan-house-expects-be-charged)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:43:51+00:00

The lawyer for Lee Chatfield, the former leader of the Michigan House, said Tuesday that prosecutors plan to file charges against Chatfield for financial crimes.

## Scott Peterson defense drops motion to seal in bid for new trial after prosecutors note files mostly public
 - [https://www.foxnews.com/us/scott-peterson-defense-drops-motion-seal-bid-new-trial-prosecutors-note-files-mostly-public](https://www.foxnews.com/us/scott-peterson-defense-drops-motion-seal-bid-new-trial-prosecutors-note-files-mostly-public)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:43:49+00:00

Scott Peterson returns to court as he seeks a new trial in murder of pregnant wife Laci Peterson and unborn son Conner with help from LA Innocence Project.

## Crop-rich California region may fall under state monitoring to preserve groundwater flow
 - [https://www.foxnews.com/us/crop-rich-california-region-may-fall-state-monitoring-preserve-groundwater-flow](https://www.foxnews.com/us/crop-rich-california-region-may-fall-state-monitoring-preserve-groundwater-flow)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:41:54+00:00

In a first-of-its kind move, California might regulate groundwater use in part of San Joaquin Valley; this comes 10 years after lawmakers tasked local communities with managing the resource.

## House delivers Mayorkas impeachment articles to Schumer, setting up trial proceedings
 - [https://www.foxnews.com/politics/house-delivers-mayorkas-impeachment-articles-schumer-setting-up-trial-proceedings](https://www.foxnews.com/politics/house-delivers-mayorkas-impeachment-articles-schumer-setting-up-trial-proceedings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:40:45+00:00

The long-awaited articles of impeachment against DHS Secretary Mayorkas were delivered to the Senate on Tuesday, setting in motion a required procedure in the upper chamber.

## Belgian police shut down a far right conference as it rallies ahead of Europe's June elections
 - [https://www.foxnews.com/world/belgian-police-shut-down-far-right-conference-rallies-ahead-europes-june-elections](https://www.foxnews.com/world/belgian-police-shut-down-far-right-conference-rallies-ahead-europes-june-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:40:14+00:00

An annual gathering of far-right politicians and supporters, held this year in Brussels, was shut down by Belgian police on Tuesday who cited concerns about public order.

## New Jersey Republican introduces bill to block child labor from use in domestic EV industry
 - [https://www.foxnews.com/politics/republican-introduces-bill-block-child-labor-domestic-ev-industry](https://www.foxnews.com/politics/republican-introduces-bill-block-child-labor-domestic-ev-industry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:37:53+00:00

FIRST ON FOX: Republican Rep. Chris Smith unveiled an effort to block cobalt extracted using child labor from being used to build U.S. electric vehicle batteries.

## Man gets 37 years for carjacking, kidnapping FBI employee in South Dakota
 - [https://www.foxnews.com/us/man-gets-37-years-carjacking-kidnapping-fbi-employee-south-dakota](https://www.foxnews.com/us/man-gets-37-years-carjacking-kidnapping-fbi-employee-south-dakota)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:34:41+00:00

Juan Alvarez-Sorto, a 25-year-old Salvadoran national, was sentenced to 37 years in prison Friday for carjacking and kidnapping an FBI employee in South Dakota.

## Man accused of killing 79-year-old, leading New Mexico police on chase in stolen car
 - [https://www.foxnews.com/us/man-accused-killing-79-year-old-leading-new-mexico-police-chase-stolen-car](https://www.foxnews.com/us/man-accused-killing-79-year-old-leading-new-mexico-police-chase-stolen-car)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:33:30+00:00

Dorien Ray, 21, of McComb, Mississippi, has been arrested under suspicion he killed a 79-year-old man at a New Mexico rest stop, before stealing his car and leading police on a chase.

## Legal experts say Biden admin's legal theory in Jan 6 prosecution 'on the ropes' after Supreme Court argument
 - [https://www.foxnews.com/politics/legal-experts-say-biden-admins-legal-theory-jan-6-prosecution-ropes-supreme-court-argument](https://www.foxnews.com/politics/legal-experts-say-biden-admins-legal-theory-jan-6-prosecution-ropes-supreme-court-argument)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:24:01+00:00

Legal experts say the DOJ was “on the ropes&quot; in Tuesday’s oral arguments at the Supreme Court in a case questioning whether a Jan. 6 rioter can be charged with obstruction.

## Trump risks losing key voter base with opposition to Arizona abortion law, pro-lifers say
 - [https://www.foxnews.com/politics/trump-risks-losing-key-voter-base-opposition-arizona-abortion-law-pro-lifers-say](https://www.foxnews.com/politics/trump-risks-losing-key-voter-base-opposition-arizona-abortion-law-pro-lifers-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:21:35+00:00

Pro-life and Christian activists say that former President Donald Trump risks alienating a key voting bloc with his moderated stance on abortion ahead of the 2024 election.

## Rare species of rodent captured on West Virginia trail camera
 - [https://www.foxnews.com/lifestyle/rare-species-rodent-captured-west-virginia-trail-camera](https://www.foxnews.com/lifestyle/rare-species-rodent-captured-west-virginia-trail-camera)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:16:23+00:00

Along a West Virginia trail, a camera caught on video the Allegheny woodrat, a rodent that is considered to be a &quot;species of concern&quot; in some American states.

## New York Times reporter declares Trump stared at her after she reported he fell asleep
 - [https://www.foxnews.com/media/new-york-times-reporter-declares-trump-stared-her-after-she-reported-he-fell-asleep](https://www.foxnews.com/media/new-york-times-reporter-declares-trump-stared-her-after-she-reported-he-fell-asleep)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:15:57+00:00

New York Times reporter Maggie Haberman said Monday that Donald Trump glared at her before walking out of the courtroom, after she reported that Trump had fallen asleep.

## Texas set to be fined $100,000 per day after failing to investigate allegations of abuse in foster care system
 - [https://www.foxnews.com/us/texas-fined-100000-per-day-failing-investigate-allegations-abuse-foster-care-system](https://www.foxnews.com/us/texas-fined-100000-per-day-failing-investigate-allegations-abuse-foster-care-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T18:05:06+00:00

U.S. District Judge Janis Graham Jack is fining Texas $100,000 per day for not adequately investigating the allegations of abuse in the state&apos;s foster care system.

## UFC, Arman Tsarukyan avoid potential lawsuit after fan at the center of viral punch video speaks out
 - [https://www.foxnews.com/sports/ufc-arman-tsarukyan-avoid-potential-lawsuit-fan-center-viral-punch-video-speaks-out](https://www.foxnews.com/sports/ufc-arman-tsarukyan-avoid-potential-lawsuit-fan-center-viral-punch-video-speaks-out)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:59:53+00:00

UFC fighter Arman Tsarukyan will not face any legal action after throwing a punch at a fan during his walkout at UFC 300, the fan confirmed on Monday.

## Elderly Army veteran carjacked delivering pizzas, survives violent attack by playing dead
 - [https://www.foxnews.com/us/elderly-army-veteran-carjacked-delivering-pizzas-survives-violent-attack-playing-dead](https://www.foxnews.com/us/elderly-army-veteran-carjacked-delivering-pizzas-survives-violent-attack-playing-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:57:40+00:00

Ernie Aimone, 81, was attacked last Wednesday for the first time in 40 years delivering pizza in Chicago. He was punched by a teen who stole his car, then crashed it in a police chase.

## Tom Selleck had 'no desire' to be an actor, calls 4-decade Hollywood career 'accidental'
 - [https://www.foxnews.com/entertainment/tom-selleck-had-no-desire-to-be-an-actor-calls-four-decade-hollywood-career-accidental](https://www.foxnews.com/entertainment/tom-selleck-had-no-desire-to-be-an-actor-calls-four-decade-hollywood-career-accidental)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:56:20+00:00

&quot;Blue Bloods&quot; star Tom Selleck is releasing a new memoir about his life and career, revealing he had not always planned on being an actor.

## AG Garland pressed on Hur report, says Biden 'has no impairment'
 - [https://www.foxnews.com/politics/ag-garland-pressed-hur-report-biden-no-impairment](https://www.foxnews.com/politics/ag-garland-pressed-hur-report-biden-no-impairment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:41:11+00:00

Attorney General Merrick Garland, when asked on Capitol Hill about special counsel Robert Hur&apos;s report on President Biden, said the president has &quot;no impairment.&quot;

## Supreme Court sides with decorated war veteran who did not receive his full educational benefits
 - [https://www.foxnews.com/us/supreme-court-sides-with-decorated-war-veteran-did-not-receive-full-educational-benefits](https://www.foxnews.com/us/supreme-court-sides-with-decorated-war-veteran-did-not-receive-full-educational-benefits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:40:53+00:00

The Supreme Court has ruled that the Department of Veterans Affairs improperly calculated educational benefits of war veteran James Rudisill, who served in Afghanistan and Iraq.

## Federal judge says Harvard Medical School professor engaged in ‘rampant plagiarism’ for Lockheed Martin trial
 - [https://www.foxnews.com/media/federal-judge-harvard-medical-school-professor-rampant-plagiarism-lockheed-martin-trial](https://www.foxnews.com/media/federal-judge-harvard-medical-school-professor-rampant-plagiarism-lockheed-martin-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:38:19+00:00

A federal judge has ruled Harvard Medical School assistant professor Dipak Panigrahy plagiarized large portions of an export report for a Lockheed Martin lawsuit.

## Fetterman slams anti-Israel agitators, says disruption 'makes you an a--hole'
 - [https://www.foxnews.com/politics/fetterman-slams-anti-israel-agitators-disruption-makes-you-a-hole](https://www.foxnews.com/politics/fetterman-slams-anti-israel-agitators-disruption-makes-you-a-hole)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:35:11+00:00

Sen. John Fetterman did not mince words on anti-Israel agitators, blasting people for &quot;blocking a bridge or berating folks in Starbucks.&quot;

## Johnson likely forced to get Dem help on foreign aid plan as Republicans decry lack of border measures
 - [https://www.foxnews.com/politics/johnson-likely-forced-get-dem-help-foreign-aid-plan-republicans-decry-lack-border-measures](https://www.foxnews.com/politics/johnson-likely-forced-get-dem-help-foreign-aid-plan-republicans-decry-lack-border-measures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:35:00+00:00

Speaker Mike Johnson is facing opposition to his foreign aid plan from Republicans calling for border security measures.

## Kiefer Sutherland denies rumors that he bullied younger costars in ‘Stand by Me’
 - [https://www.foxnews.com/entertainment/kiefer-sutherland-denies-rumors-bullied-younger-costars-stand-by-me](https://www.foxnews.com/entertainment/kiefer-sutherland-denies-rumors-bullied-younger-costars-stand-by-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:31:10+00:00

Kiefer Sutherland recently shut down rumors that he &quot;picked on&quot; his younger &quot;Stand by Me&quot; costars once and for all.

## Law enforcement officers killed in gunfire ambush identified by New York officials
 - [https://www.foxnews.com/us/law-enforcement-officers-killed-gunfire-ambush-identified-new-york-officials](https://www.foxnews.com/us/law-enforcement-officers-killed-gunfire-ambush-identified-new-york-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:31:03+00:00

Officer Michael Jensen and Sheriff&apos;s Deputy Michael Hoosock were shot and killed earlier this week when a suspect ambushed law enforcement outside a residential home.

## 'Tulsa King' star Sylvester Stallone moves on from 'toxic' set allegations as new season approaches
 - [https://www.foxnews.com/entertainment/tulsa-king-star-sylvester-stallone-moves-on-toxic-set-allegations-new-season-approaches](https://www.foxnews.com/entertainment/tulsa-king-star-sylvester-stallone-moves-on-toxic-set-allegations-new-season-approaches)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:27:35+00:00

Sylvester Stallone is business as usual as he prepares for the second season of &quot;Tulsa King&quot; to premiere. The &quot;Rocky&quot; star allegedly created a &quot;toxic&quot; set while filming the show.

## Wisconsin Republican leaders ignore the governor's request to spend $125M to combat 'forever chemicals'
 - [https://www.foxnews.com/us/wisconsin-republican-leaders-ignoring-governors-request-spend-125m-combat-forever-chemicals](https://www.foxnews.com/us/wisconsin-republican-leaders-ignoring-governors-request-spend-125m-combat-forever-chemicals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:09:26+00:00

Republican leaders in Wisconsin will not attend Gov. Tony Evers&apos; most recent meeting to discuss the spending of $125 million in an effort to combat PFAS chemicals in polluted groundwater.

## Winnie the Pooh, Mickey Mouse, soon Superman: When characters enter the public domain, anything goes
 - [https://www.foxnews.com/lifestyle/winnie-pooh-mickey-mouse-soon-superman-characters-enter-public-domain-anything-goes](https://www.foxnews.com/lifestyle/winnie-pooh-mickey-mouse-soon-superman-characters-enter-public-domain-anything-goes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:07:37+00:00

Artists are sure to create all manner of strange adaptations when well-known characters enter the public domain, as was the case with Winnie the Pooh and Mickey Mouse.

## Olympic torch-lighting ceremony explained: What to know ahead of the Paris Games
 - [https://www.foxnews.com/sports/olympic-torch-lighting-ceremony-explained-what-know-ahead-paris-games](https://www.foxnews.com/sports/olympic-torch-lighting-ceremony-explained-what-know-ahead-paris-games)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T17:04:28+00:00

The Olympic flame-lighting ceremony has roots in ancient Greece and connects modern Olympic Games to their origin. The flame for the Paris games was lit on April 16, 2024.

## Antisemitic incidents in US skyrocketed in 2023, ADL report says, averaging 24 per day
 - [https://www.foxnews.com/us/antisemitic-incidents-us-skyrocketed-2023-adl-report-averaging-24-day](https://www.foxnews.com/us/antisemitic-incidents-us-skyrocketed-2023-adl-report-averaging-24-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:59:03+00:00

Numbers released by the Anti-Defamation League show antisemitic incidents reached an all-time high in the U.S. last year, averaging one every hour.

## Iconic spire atop 17th-century Old Stock Exchange in Denmark collapses in fire
 - [https://www.foxnews.com/world/iconic-spire-atop-17th-century-old-stock-exchange-denmark-collapses-fire](https://www.foxnews.com/world/iconic-spire-atop-17th-century-old-stock-exchange-denmark-collapses-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:55:41+00:00

Copenhagen&apos;s Old Stock Exchange caught fire, bringing down its well-known spire. Many valuables from within were saved when pedestrians stopped to lend a hand.

## Putin shared surprising advice with Iranian counterpart following unprecedented attack on Israel
 - [https://www.foxnews.com/world/putin-shared-surprising-advice-iranian-counterpart-following-unprecedented-attack-israel](https://www.foxnews.com/world/putin-shared-surprising-advice-iranian-counterpart-following-unprecedented-attack-israel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:50:41+00:00

President Biden reportedly warned Israeli Prime Minister Benjamin Netanyahu that America will not support further, direct action taken against Iran, suggesting his counterpart &quot;take the win.&quot;

## Suspended NPR whistleblower blasts CEO Katherine Maher: Lacks perspective on what America 'is all about'
 - [https://www.foxnews.com/media/suspended-npr-whistleblower-blasts-ceo-katherine-maher-lacks-perspective-what-america-about](https://www.foxnews.com/media/suspended-npr-whistleblower-blasts-ceo-katherine-maher-lacks-perspective-what-america-about)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:49:28+00:00

Suspended NPR editor Uri Berliner doesn’t think embattled CEO Katherine Maher is right for the job after her far-left political views on social media came to light.

## Ahead of Olympic Games, Paris grapples with security, transportation preparations
 - [https://www.foxnews.com/world/ahead-olympic-games-paris-grapples-security-transportation-preparations](https://www.foxnews.com/world/ahead-olympic-games-paris-grapples-security-transportation-preparations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:44:46+00:00

Measures are being taken to prepare Paris&apos; security and transportation for the upcoming Olympics, which will flood the city with millions more people than usual.

## US Defense Secretary meets with Chinese counterpart for first time since 2022 to ease escalating tensions
 - [https://www.foxnews.com/us/us-defense-secretary-meets-chinese-counterpart-first-time-2022-ease-escalating-tensions](https://www.foxnews.com/us/us-defense-secretary-meets-chinese-counterpart-first-time-2022-ease-escalating-tensions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:43:01+00:00

Pentagon chief Austin Lloyd met with his Chinese counterpart for the first time since 2022 in an attempt to open communications between the to militaries and ease rising tensions.

## UK court upholds school's ban on prayer following Muslim student's legal challenge
 - [https://www.foxnews.com/world/uk-court-upholds-schools-ban-prayer-muslim-students-legal-challenge](https://www.foxnews.com/world/uk-court-upholds-schools-ban-prayer-muslim-students-legal-challenge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:42:16+00:00

A Muslim student at a London school lost a court battle over the school&apos;s ban on prayer. The judge ruled that the student had accepted the school&apos;s rules upon enrollment.

## Anti-Israel agitators’ ‘unlawful’ tactics will ‘not be tolerated,’ California Highway Patrol warns
 - [https://www.foxnews.com/us/anti-israel-agitators-unlawful-tactics-not-tolerated-california-highway-patrol-warns](https://www.foxnews.com/us/anti-israel-agitators-unlawful-tactics-not-tolerated-california-highway-patrol-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:35:44+00:00

The California Highway Patrol has arrested 38 people linked to anti-Israel protests that disrupted traffic on the Golden Gate Bridge and in Oakland, California.

## Kevin Costner denied Chris Hemsworth romantic lead in his film, casting himself instead: 'I'm still young'
 - [https://www.foxnews.com/entertainment/kevin-costner-denied-chris-hemsworth-romantic-lead-film-casting-himself-instead-still-young](https://www.foxnews.com/entertainment/kevin-costner-denied-chris-hemsworth-romantic-lead-film-casting-himself-instead-still-young)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:32:32+00:00

Kevin Costner still thinks he has what it takes to star in a romantic leading role, opting to cast himself in one of his movies instead of Hollywood hunk Chris Hemsworth, who lobbied for the part.

## Soros nonprofit drops massive 8-figure donation to super PAC bankrolling left-wing groups
 - [https://www.foxnews.com/politics/soros-nonprofit-drops-massive-8-figure-donation-super-pac-bankrolling-left-wing-groups](https://www.foxnews.com/politics/soros-nonprofit-drops-massive-8-figure-donation-super-pac-bankrolling-left-wing-groups)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:27:51+00:00

Liberal mega donor George Soros funneled $60 million into a liberal Super PAC last quarter that was disbursed to a variety of far-left groups, including Planned Parenthood.

## Legendary MLB manager Whitey Herzog dead at 92
 - [https://www.foxnews.com/sports/legendary-mlb-manager-whitey-herzog-dead](https://www.foxnews.com/sports/legendary-mlb-manager-whitey-herzog-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:14:44+00:00

Baseball Hall of Fame manager Whitey Herzog, who guided the St. Louis Cardinals to a World Series title in 1982, has died at age 92, the team said.

## West Virginia transgender sports ban overturned in federal appeals court
 - [https://www.foxnews.com/sports/west-virginia-transgender-sports-ban-overturned-federal-appeals-court](https://www.foxnews.com/sports/west-virginia-transgender-sports-ban-overturned-federal-appeals-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:12:55+00:00

West Virginia&apos;s law banning transgender athletes from competing in girls sports was struck down by a federal appeals court on Tuesday morning.

## Baltimore bridge collapse survivor 'fought for his life' after car plunged into river
 - [https://www.foxnews.com/us/baltimore-bridge-collapse-survivor-fought-life-car-plunged-river](https://www.foxnews.com/us/baltimore-bridge-collapse-survivor-fought-life-car-plunged-river)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:10:50+00:00

Baltimore bridge collapse survivor Julio Cervantes Suarez&apos;s attorneys say workers were not warned of a potential collapse while they were taking breaks in their cars.

## Rebecca Ferguson shares how costars responded to viral 'idiot' comments, 'Rust' armorer to serve maximum time
 - [https://www.foxnews.com/entertainment/rebecca-ferguson-shares-how-costars-responded-viral-idiot-comments-rust-armorer-serve-maximum-time](https://www.foxnews.com/entertainment/rebecca-ferguson-shares-how-costars-responded-viral-idiot-comments-rust-armorer-serve-maximum-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:00:34+00:00

The Fox News Entertainment newsletter brings you the latest Hollywood headlines, celebrity interviews and stories from Los Angeles and beyond.

## Mike Johnson calls out Dems for appeasing 'pro-Hamas' wing as anti-Israel protesters burn American flag
 - [https://www.foxnews.com/media/mike-johnson-calls-dems-appeasing-pro-hamas-wing-anti-israel-protesters-burn-american-flags](https://www.foxnews.com/media/mike-johnson-calls-dems-appeasing-pro-hamas-wing-anti-israel-protesters-burn-american-flags)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T16:00:17+00:00

House Speaker Johnson slammed Sen. Chuck Schumer for refusing to condemn anti-Israel demonstrations nationwide, arguing it is &apos;shameful&apos; some leaders are &apos;turning their back&apos; on Israel.

## Last surviving Medal of Honor recipient from the Korean War will lie in honor at the US Capitol
 - [https://www.foxnews.com/politics/last-surviving-medal-honor-recipient-korean-war-lie-honor-us-capitol](https://www.foxnews.com/politics/last-surviving-medal-honor-recipient-korean-war-lie-honor-us-capitol)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:58:46+00:00

Colonel Ralph Puckett, Jr., a Medal of Honor recipient from the Korean War, will lie in honor in the Rotunda of the U.S. Capitol, Congress&apos; leaders announced on Tuesday.

## Married teacher caught 'putting her clothes on' after naked teen runs from car: police
 - [https://www.foxnews.com/us/married-teacher-caught-putting-clothes-after-naked-teen-runs-car-police](https://www.foxnews.com/us/married-teacher-caught-putting-clothes-after-naked-teen-runs-car-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:52:37+00:00

A married Nebraska teacher allegedly sexually abused one of her teenage students and was charged with a felony that carries a maximum of 20 years in prison.

## 12-year-old girl hooks multiple fishing records, plus our latest American Culture Quiz
 - [https://www.foxnews.com/lifestyle/12-year-old-girl-hooks-multiple-fishing-records-latest-american-culture-quiz](https://www.foxnews.com/lifestyle/12-year-old-girl-hooks-multiple-fishing-records-latest-american-culture-quiz)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:37:09+00:00

The Fox News Lifestyle Newsletter brings you trending stories on family, travel, food, neighbors helping neighbors, pets, autos, military veterans, heroes, faith and American values.

## White House deems House impeachment inquiry 'over,' President Biden formally declines to testify
 - [https://www.foxnews.com/politics/white-house-deems-house-impeachment-inquiry-over-president-biden-formally-declines-testify](https://www.foxnews.com/politics/white-house-deems-house-impeachment-inquiry-over-president-biden-formally-declines-testify)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:36:31+00:00

President Biden formally declined to testify at the request of House Oversight Committee Chairman James Comer, R-Ky. regarding his family&apos;s business dealings.

## Patrick Mahomes explains why he avoided calling for tight gun-control laws after shooting, endorsing president
 - [https://www.foxnews.com/sports/patrick-mahomes-explains-why-he-avoided-calling-tight-gun-control-laws-shooting-endorsing-president](https://www.foxnews.com/sports/patrick-mahomes-explains-why-he-avoided-calling-tight-gun-control-laws-shooting-endorsing-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:32:20+00:00

Kansas City Chiefs star Patrick Mahomes explained why he avoided calling for tighter gun laws after the Super Bowl parade shooting and not endorsing a presidential candidate.

## Russia’s invasion of Ukraine threatens global security, German chancellor says
 - [https://www.foxnews.com/world/russias-invasion-ukraine-threatens-global-security-german-chancellor-says](https://www.foxnews.com/world/russias-invasion-ukraine-threatens-global-security-german-chancellor-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:24:46+00:00

German Chancellor Olaf Scholz met with Chinese leader Xi Jinping and conveyed concerns about Russia&apos;s invasion of Ukraine, voicing the threat it poses to global security.

## Biden under fire for shutting down US oil production, urged to impose sanctions on Venezuela
 - [https://www.foxnews.com/politics/biden-under-fire-shutting-us-oil-production-impose-sanctions-venezuela](https://www.foxnews.com/politics/biden-under-fire-shutting-us-oil-production-impose-sanctions-venezuela)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:18:46+00:00

FIRST ON FOX: Senate Republicans are calling on President Biden to revoke sanctions relief for Venezuela over the nation&apos;s apparent violation of an agreement with opposition leaders.

## Bragg files motion to hold Trump in contempt for alleged gag order violations, threatens 30 days of jail time
 - [https://www.foxnews.com/politics/bragg-files-motion-hold-trump-contempt-alleged-gag-order-violations-threatens-30-days-jail-time](https://www.foxnews.com/politics/bragg-files-motion-hold-trump-contempt-alleged-gag-order-violations-threatens-30-days-jail-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:15:47+00:00

Manhattan District Attorney Alvin Bragg has filed a motion to hold former President Trump in contempt of court, claiming he violated the gag order imposed upon him by publishing three social media posts relating to two known witnesses in his criminal trial—Michael Cohen and Stormy Daniels.

## Australia's prime minister helps French worker who intervened during mall stabbing attack renew his visa
 - [https://www.foxnews.com/world/australias-prime-minister-helps-french-worker-who-intervened-mall-stabbing-attack-renew-visa](https://www.foxnews.com/world/australias-prime-minister-helps-french-worker-who-intervened-mall-stabbing-attack-renew-visa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:09:28+00:00

Prime Minister Anthony Albanese made a statement on Tuesday saying the French construction who confronted the man who stabbed six people at a Sydney shopping mall is &quot;welcome to stay in the country.&quot;

## Azerbaijan urges top UN court to throw out Armenia's accusations of racial discrimination
 - [https://www.foxnews.com/world/azerbaijan-urges-top-un-court-throw-out-armenias-accusations-racial-discrimination](https://www.foxnews.com/world/azerbaijan-urges-top-un-court-throw-out-armenias-accusations-racial-discrimination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:06:07+00:00

Azerbaijan says the UN&apos;s International Court of Justice does not have jurisdiction to hear Armenia&apos;s case alleging Azerbaijan violated a convention prohibiting racial discrimination.

## GOP lawmaker demands action from Japan PM on key issue impacting hundreds of US children abroad
 - [https://www.foxnews.com/politics/gop-lawmaker-demands-action-japan-pm-key-issue-impacting-hundreds-us-children-abroad](https://www.foxnews.com/politics/gop-lawmaker-demands-action-japan-pm-key-issue-impacting-hundreds-us-children-abroad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:05:48+00:00

GOP Rep. Chris Smith is calling on Japan&apos;s prime minister to act to ensure that hundreds of American children abducted by their parents in Japan are reunited with their families.

## North Korea to put Chinese surveillance cameras in schools and workplaces to monitor citizens, report says
 - [https://www.foxnews.com/world/north-korea-chinese-surveillance-cameras-schools-workplaces-monitor-citizens-report-says](https://www.foxnews.com/world/north-korea-chinese-surveillance-cameras-schools-workplaces-monitor-citizens-report-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T15:01:50+00:00

North Korea is intensifying its surveillance of citizens through the widespread installation of surveillance cameras and the collection of biometric data.

## Massie threatens to oust Speaker Johnson if he doesn’t step down over foreign aid plan
 - [https://www.foxnews.com/politics/massie-threatens-oust-speaker-johnson-if-he-doesnt-step-down-over-foreign-aid-plan](https://www.foxnews.com/politics/massie-threatens-oust-speaker-johnson-if-he-doesnt-step-down-over-foreign-aid-plan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:57:19+00:00

Speaker Mike Johnson is facing another threat to oust him from leadership as he struggles to navigate a fractured and unruly conference.

## 'American Idol' judge Katy Perry suffers wardrobe malfunction during show
 - [https://www.foxnews.com/entertainment/american-idol-judge-katy-perry-suffers-wardrobe-malfunction-during-show](https://www.foxnews.com/entertainment/american-idol-judge-katy-perry-suffers-wardrobe-malfunction-during-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:55:21+00:00

During Monday&apos;s episode of &quot;American Idol,&quot; Katy Perry found herself in the middle of a major wardrobe malfunction moments before a contestant took the stage.

## John Mellencamp scolds audiences to have 'etiquette' at his shows after viral video of him yelling at hecklers
 - [https://www.foxnews.com/media/john-mellencamp-scolds-audiences-have-etiquette-shows-viral-video-yelling-hecklers](https://www.foxnews.com/media/john-mellencamp-scolds-audiences-have-etiquette-shows-viral-video-yelling-hecklers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:47:31+00:00

Rock icon John Mellencamp is asking rowdy fans to avoid his shows in the future after a March incident when the singer stormed off stage after yelling at hecklers.

## Suspects charged with killing Kansas women belonged to anti-government ‘God’s Misfit’s’ group, affidavit says
 - [https://www.foxnews.com/us/suspects-charged-killing-kansas-women-belonged-anti-government-gods-misfits-group-affidavit](https://www.foxnews.com/us/suspects-charged-killing-kansas-women-belonged-anti-government-gods-misfits-group-affidavit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:41:19+00:00

The four suspects charged in the killings of two missing Kansas women belonged to an anti-government group called the &quot;God&apos;s Misfits,&quot; investigators say.

## Prince Harry loses 1st appeal bid in court battle over UK security protection
 - [https://www.foxnews.com/entertainment/prince-harry-loses-first-appeal-bid-court-battle-over-uk-security-protection](https://www.foxnews.com/entertainment/prince-harry-loses-first-appeal-bid-court-battle-over-uk-security-protection)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:32:23+00:00

A judge rejected Prince Harry&apos;s request to appeal an earlier ruling upholding a government panel’s decision to limit his access to publicly funded security.

## Left-wing rabbi warns Biden, Democrats not to count on Jewish votes from the pulpit
 - [https://www.foxnews.com/media/left-wing-rabbi-warns-biden-democrats-not-count-jewish-votes-pulpit-be-careful](https://www.foxnews.com/media/left-wing-rabbi-warns-biden-democrats-not-count-jewish-votes-pulpit-be-careful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:30:49+00:00

Liberal New York City rabbi warns Biden, Democrats not to count carte blanche on Jewish voters amid the party&apos;s increasing tolerance for antisemitism.

## US ambassador urges Japan to boost weapon production for stronger security alliance
 - [https://www.foxnews.com/world/us-ambassador-urges-japan-boost-weapon-production-stronger-security-alliance](https://www.foxnews.com/world/us-ambassador-urges-japan-boost-weapon-production-stronger-security-alliance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:30:25+00:00

The U.S. ambassador to Japan has urged Tokyo to take a greater role in developing, producing and supplying weapons for a stronger security alliance during conflict.

## UK lawmakers to vote on bill that would outlaw tobacco sale, create 'first smoke-free generation'
 - [https://www.foxnews.com/world/uk-lawmakers-vote-bill-outlaw-tobacco-sale-create-first-smoke-free-generation](https://www.foxnews.com/world/uk-lawmakers-vote-bill-outlaw-tobacco-sale-create-first-smoke-free-generation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:29:54+00:00

United Kingdom lawmakers will debate and vote on a bill that would phase out the legal sale of tobacco entirely by raising the age of sale by one year each year.

## Maine targets Second Amendment with several gun safety bills after deadliest shooting in state's history
 - [https://www.foxnews.com/us/maine-targets-second-amendment-several-gun-safety-bills-deadliest-shooting-states-history](https://www.foxnews.com/us/maine-targets-second-amendment-several-gun-safety-bills-deadliest-shooting-states-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:21:28+00:00

The Maine Legislature is set to pass bills impacting the rights of gun-owning residents across the state following the deadliest shooting in Maine&apos;s history last year.

## Biden appeases Iran, flip the script on student loan bailouts, and more from Fox News Opinion
 - [https://www.foxnews.com/opinion/biden-appeases-iran-flip-script-student-loan-bailouts-more-fox-news-opinion](https://www.foxnews.com/opinion/biden-appeases-iran-flip-script-student-loan-bailouts-more-fox-news-opinion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T14:08:47+00:00

Read the latest from Fox News Opinion &amp; watch videos from Sean Hannity, Raymond Arroyo &amp; more.

## Perfect pie crust today includes lard, which has returned to glory after years of bad publicity
 - [https://www.foxnews.com/food-drink/perfect-pie-crust-today-lard-returned-glory-years-bad-publicity](https://www.foxnews.com/food-drink/perfect-pie-crust-today-lard-returned-glory-years-bad-publicity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:55:53+00:00

Lard, essential to the human diet for centuries, suffered a wave of bad publicity in recent decades. It&apos;s enjoying a sudden rebirth, thanks in large part to pie makers.

## Turkey's Erdogan faces uncertain future after shock election losses expert says
 - [https://www.foxnews.com/world/turkeys-erdogan-faces-uncertain-future-shock-election-losses-expert-says](https://www.foxnews.com/world/turkeys-erdogan-faces-uncertain-future-shock-election-losses-expert-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:53:53+00:00

Turkey has suffered significant economic woes throughout the coronavirus pandemic, leading a tight general election last year that Turkish President Recep Tayyip Erdoğan barely managed to survive.

## Navy expects to miss recruiting goal by more than 6,000 amid worldwide threats from China, Russia
 - [https://www.foxnews.com/us/navy-expects-miss-recruiting-goal-more-6000-worldwide-threats-china-russia](https://www.foxnews.com/us/navy-expects-miss-recruiting-goal-more-6000-worldwide-threats-china-russia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:50:08+00:00

The United States Navy is expecting to fall short of its recruitment goals, failing to keep up with success from the U.S. Army and Air Force reported this recruiting year.

## Biden returns to campaign trail as Trump forced to remain in court for second day of New York hush money trial
 - [https://www.foxnews.com/politics/biden-returns-campaign-trail-trump-forced-remain-court-second-day-new-york-hush-money-trial](https://www.foxnews.com/politics/biden-returns-campaign-trail-trump-forced-remain-court-second-day-new-york-hush-money-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:46:01+00:00

President Biden returns to the campaign trail on Tuesday while Trump has been ordered to attend the court proceedings Tuesday and every day of the trial.

## Dem Chicago alderman warns 'we are not taking care of our own' as city approves $70M for migrants
 - [https://www.foxnews.com/politics/dem-chicago-alderman-warns-we-are-not-taking-care-our-own-city-approves-70m-migrants](https://www.foxnews.com/politics/dem-chicago-alderman-warns-we-are-not-taking-care-our-own-city-approves-70m-migrants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:42:30+00:00

Some Democratic officials in Chicago voiced opposition toward Mayor Brandon Johnson&apos;s request for another $70 million in funding to care for migrants.

## US envoy to UN urges Russia, China to halt support for North Korea's weapon programs
 - [https://www.foxnews.com/world/us-envoy-un-urges-russia-china-halt-support-north-koreas-weapon-programs](https://www.foxnews.com/world/us-envoy-un-urges-russia-china-halt-support-north-koreas-weapon-programs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:41:09+00:00

U.S. Ambassador Linda Thomas-Greenfield urged Russia and China to halt their support for North Korea, saying that it shields the country from sanctions.

## 'NCIS' cast shares 'secret sauce' to long-running show
 - [https://www.foxnews.com/entertainment/ncis-cast-shares-secret-sauce-long-running-show](https://www.foxnews.com/entertainment/ncis-cast-shares-secret-sauce-long-running-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:39:26+00:00

&quot;NCIS&quot; stars Sean Murray, Rocky Carroll, Gary Cole, Vanessa Lachey and LL Cool J revealed that the cast is a &quot;family&quot; 22 years into the franchise.

## The Notorious BIG, ABBA and 'Rudolph, the Red-Nosed Reindeer' to join National Recording Registry
 - [https://www.foxnews.com/entertainment/notorious-b-i-g-abba-rudolph-red-nosed-reindeer-join-national-recording-registry](https://www.foxnews.com/entertainment/notorious-b-i-g-abba-rudolph-red-nosed-reindeer-join-national-recording-registry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:30:47+00:00

Blondie, Green Day, and the Chicks are among the artists with albums being inducted into the National Recording Registry at the Library of Congress in 2024.

## New developments in carjacking, death of Florida woman include link to shooting, deputy's arrest for info leak
 - [https://www.foxnews.com/us/new-developments-carjacking-death-florida-woman-include-link-shooting-deputys-arrest-info-leak](https://www.foxnews.com/us/new-developments-carjacking-death-florida-woman-include-link-shooting-deputys-arrest-info-leak)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:29:24+00:00

Investigators have located the suspect car in the deadly carjacking of a woman in Winter Springs, Florida, but have still not found the people responsible.

## 20 bikes for every type of bike rider
 - [https://www.foxnews.com/lifestyle/bikes-for-every-type-bike-rider](https://www.foxnews.com/lifestyle/bikes-for-every-type-bike-rider)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:19:58+00:00

Whether you want a bike for your daily commute or to ride through the deep woods, we&apos;ve got an option for you.

## US approves potential $140M aircraft support deal for Iraq, Pentagon officials confirm
 - [https://www.foxnews.com/politics/us-approves-potential-140m-aircraft-support-deal-iraq-pentagon-officials-confirm](https://www.foxnews.com/politics/us-approves-potential-140m-aircraft-support-deal-iraq-pentagon-officials-confirm)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:17:53+00:00

The U.S. State Department has given approval for the potential sale of aircraft contractor logistics support to Iraq, at an estimated cost of $140 million.

## Warren Buffett’s BNSF Railway to lay out defense in Montana asbestos deaths lawsuit
 - [https://www.foxnews.com/us/warren-buffetts-bnsf-railway-defense-montana-asbestos-deaths-lawsuit](https://www.foxnews.com/us/warren-buffetts-bnsf-railway-defense-montana-asbestos-deaths-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:16:23+00:00

Warren Buffett’s BNSF Railway is being sued for allegedly polluting a Montana town with asbestos, resulting in the deaths of at least two people from mesothelioma.

## NPR suspends veteran editor who blew whistle on liberal bias at organization
 - [https://www.foxnews.com/media/npr-suspends-veteran-editor-who-blew-whistle-liberal-bias-organization](https://www.foxnews.com/media/npr-suspends-veteran-editor-who-blew-whistle-liberal-bias-organization)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T13:15:55+00:00

NPR has suspended veteran editor Uri Berliner after he detailed his employer’s &quot;absence of viewpoint diversity&quot; last week in a stunning rebuke of the news organization.

## Biden admin launches partnership with 50 countries to stifle future pandemics
 - [https://www.foxnews.com/politics/biden-admin-launches-partnership-50-countries-stifle-future-pandemics](https://www.foxnews.com/politics/biden-admin-launches-partnership-50-countries-stifle-future-pandemics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T12:58:31+00:00

President Biden&apos;s administration is launching a program to assist 50 countries in identifying and responding to infectious diseases to prevent future pandemics.

## Black voters reportedly souring on Biden, consider 3rd-party candidates: 'The economy sucks'
 - [https://www.foxnews.com/media/black-voters-reportedly-souring-biden-consider-3rd-party-candidates-economy-sucks](https://www.foxnews.com/media/black-voters-reportedly-souring-biden-consider-3rd-party-candidates-economy-sucks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T12:40:02+00:00

A reporter working for a local news outlet in Georgia spoke with multiple Black voters, noting that Donald Trump may benefit from decreased enthusiasm for Biden.

## Greece proposes 2 marine parks as part of $830M environmental protection program
 - [https://www.foxnews.com/world/greece-proposes-2-marine-parks-830m-environmental-protection-program](https://www.foxnews.com/world/greece-proposes-2-marine-parks-830m-environmental-protection-program)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T12:34:11+00:00

Greece has proposed a plan to create two large marine parks as part of an $830 million program to protect marine ecosystems, drawing criticism from Turkey.

## Russian deserters of Ukraine war hide abroad, but as asylum claims surge, foreign countries are suspicious
 - [https://www.foxnews.com/world/russian-deserters-ukraine-war-hide-abroad-asylum-claims-surge-foreign-countries-suspicious](https://www.foxnews.com/world/russian-deserters-ukraine-war-hide-abroad-asylum-claims-surge-foreign-countries-suspicious)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T12:18:55+00:00

Russian soldiers who defected and fled Russia since the start of the war with Ukraine speak about their reasons for leaving and their struggles finding a safe place to land.

## Singapore's outgoing PM to stay on as senior minister, his successor says
 - [https://www.foxnews.com/world/singapores-outgoing-pm-stay-senior-minister-successor-says](https://www.foxnews.com/world/singapores-outgoing-pm-stay-senior-minister-successor-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T12:14:13+00:00

Singapore&apos;s Prime Minister Lee Hsien Loong will transition out of office after 20 years, with Deputy Prime Minister Lawrence Wong set to succeed him on May 15.

## Rory McIlroy gets caught up in LIV Golf rumors, supposedly offered massive deal: report
 - [https://www.foxnews.com/sports/rory-mcilroy-gets-caught-up-liv-golf-rumors-offered-massive-deal-report](https://www.foxnews.com/sports/rory-mcilroy-gets-caught-up-liv-golf-rumors-offered-massive-deal-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T12:08:51+00:00

Rory McIlroy was rumored to be linked to a jump to LIV Golf on Monday with a massive sum and equity in the organization coming his way.

## Iraq’s Abu Ghraib prison detainee shares emotional testimony in trial against Virginia military contractor
 - [https://www.foxnews.com/us/iraqs-abu-ghraib-prison-detainee-shares-emotional-testimony-trial-against-virginia-military-contractor](https://www.foxnews.com/us/iraqs-abu-ghraib-prison-detainee-shares-emotional-testimony-trial-against-virginia-military-contractor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T11:36:57+00:00

Former detainees of Iraq’s Abu Ghraib prison are suing Virginia-based military contractor CACI for what they claim is its role in the torture they suffered while imprisoned.

## Pilot and dog swim to shore in California after small plane crashes off coast, authorities say
 - [https://www.foxnews.com/us/pilot-dog-swim-shore-california-small-plane-crashes-coast-authorities-say](https://www.foxnews.com/us/pilot-dog-swim-shore-california-small-plane-crashes-coast-authorities-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T11:34:58+00:00

A pilot and his dog survived a small plane crash into the ocean off the coast of Rancho Palos Verdes, California, on Sunday evening, authorities said.

## NFL star Russell Wilson calls for WNBA players to get paid more after Caitlin Clark's rookie salary revealed
 - [https://www.foxnews.com/sports/nfl-star-russell-wilson-calls-wnba-players-get-paid-more-caitlin-clarks-rookie-salary-revealed](https://www.foxnews.com/sports/nfl-star-russell-wilson-calls-wnba-players-get-paid-more-caitlin-clarks-rookie-salary-revealed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T11:31:56+00:00

Pittsburgh Steelers star Russell Wilson called for Caitlin Clark and other WNBA players to get paid more as their salaries were debated on social media.

## Katie Couric says her 'Today' co-anchor Bryant Gumbel gave her 'endless s---' for going on maternity leave
 - [https://www.foxnews.com/media/katie-couric-says-today-co-anchor-bryant-gumbel-gave-endless-s-maternity-leave](https://www.foxnews.com/media/katie-couric-says-today-co-anchor-bryant-gumbel-gave-endless-s-maternity-leave)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T11:30:55+00:00

In an interview with Bill Maher, former NBC star Katie Couric revealed the &quot;incredibly sexist attitude&quot; she received from her &quot;Today&quot; co-anchor Bryant Gumbel.

## Australia says bishop, priest’s church stabbing was a 'terrorist incident'
 - [https://www.foxnews.com/world/australia-bishop-priests-church-stabbing-terrorist-incident](https://www.foxnews.com/world/australia-bishop-priests-church-stabbing-terrorist-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T11:20:56+00:00

A stabbing attack at the the Assyrian Christ The Good Shepherd Church in Wakeley, Australia is being investigated as a &quot;terrorist incident,&quot; police say.

## Israel pushes for new sanctions on Iran, urges countries to declare Revolutionary Guard a terror group
 - [https://www.foxnews.com/world/israel-pushes-new-sanctions-iran-urges-countries-declare-revolutionary-guard-terror-group](https://www.foxnews.com/world/israel-pushes-new-sanctions-iran-urges-countries-declare-revolutionary-guard-terror-group)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T11:18:05+00:00

Israeli Foreign Minister Israel Katz on Tuesday said he is urging 32 countries to impose additional sanctions on Iran targeting its missile program after attack on Israel.

## Fruits and vegetables ripe in spring and how you can incorporate them into yummy seasonal dishes
 - [https://www.foxnews.com/lifestyle/foods-season-spring-cook](https://www.foxnews.com/lifestyle/foods-season-spring-cook)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T11:17:16+00:00

There are an abundance of fruit and vegetables that thrive in the spring. Take advantage of these fruits and vegetables seasonal in spring for a fresh bite.

## Baltimore Bridge collapse: Salvage crews race against clock after fourth body found, FBI launches probe
 - [https://www.foxnews.com/us/baltimore-bridge-collapse-salvage-crews-race-clock-fourth-body-found-fbi-launches-probe](https://www.foxnews.com/us/baltimore-bridge-collapse-salvage-crews-race-clock-fourth-body-found-fbi-launches-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T11:15:25+00:00

Crews are using the largest crane on the Eastern Seaboard to haul sections of Baltimore’s Francis Scott Key Bridge out of the Baltimore harbor in a race against the clock.

## NASA's plan to bring Mars samples to Earth undergoes revision due to budget cuts
 - [https://www.foxnews.com/science/nasas-plan-mars-samples-earth-revision-budget-cuts](https://www.foxnews.com/science/nasas-plan-mars-samples-earth-revision-budget-cuts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T11:12:03+00:00

NASA&apos;s plan to retrieve samples from Mars for analysis on Earth is on hold due to cost and time constraints. The project has been deemed too expensive.

## Possible jurors in Trump hush money trial excused after making admission and more top headlines
 - [https://www.foxnews.com/us/possible-jurors-trump-hush-money-trial-excused-after-making-admission-top-headlines](https://www.foxnews.com/us/possible-jurors-trump-hush-money-trial-excused-after-making-admission-top-headlines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T10:41:14+00:00

Get all the stories you need-to-know from the most powerful name in news delivered first thing every morning to your inbox.

## Maui fire after-action report to identify strengths, weaknesses in response to deadly Hawaii wildfires
 - [https://www.foxnews.com/us/maui-fire-after-action-report-identify-strengths-weaknesses-response-deadly-hawaii-wildfires](https://www.foxnews.com/us/maui-fire-after-action-report-identify-strengths-weaknesses-response-deadly-hawaii-wildfires)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T10:40:53+00:00

After the deadliest wildfire in the U.S. in over a century killed 101 people in Hawaii, the Maui Fire Department is expected to release a report analyzing their response.

## Coral reefs around the world are experiencing mass bleaching in warming oceans, scientists say
 - [https://www.foxnews.com/science/coral-reefs-world-experiencing-mass-bleaching-warming-oceans-scientists-say](https://www.foxnews.com/science/coral-reefs-world-experiencing-mass-bleaching-warming-oceans-scientists-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T10:40:17+00:00

Coral reefs around the world are experiencing global bleaching for the fourth time due to prolonged warming of the oceans, according to reef scientists.

## Orioles' Cedric Mullins makes unbelievable diving play for early catch-of-the-year candidate
 - [https://www.foxnews.com/sports/orioles-cedric-mullins-makes-unbelievable-diving-play-early-catch-of-the-year-candidate](https://www.foxnews.com/sports/orioles-cedric-mullins-makes-unbelievable-diving-play-early-catch-of-the-year-candidate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T10:32:33+00:00

Baltimore Orioles center fielder Cedric Mullins is already up for &quot;Catch of the Year&quot; after the tremendous diving play he made against the Minnesota Twins on Monday night.

## Ken Holtzman, former MLB star who won multiple World Series titles, dead at 78
 - [https://www.foxnews.com/sports/ken-holtzman-former-mlb-star-who-won-multiple-world-series-titles-dead](https://www.foxnews.com/sports/ken-holtzman-former-mlb-star-who-won-multiple-world-series-titles-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T10:27:56+00:00

Former MLB star pitcher Ken Holtzman, who played for the Chicago Cubs and Oakland Athletics among others during his career, has died. He was 78.

## Caitlin Clark's boyfriend has 3-emoji response to Iowa star's outfit at WNBA Draft
 - [https://www.foxnews.com/sports/caitlin-clarks-boyfriend-3-emoji-response-iowa-stars-outfit-wnba-draft](https://www.foxnews.com/sports/caitlin-clarks-boyfriend-3-emoji-response-iowa-stars-outfit-wnba-draft)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T10:23:59+00:00

Caitlin Clark&apos;s boyfriend, Connor McCaffrey, reacted on X to the former Iowa superstar&apos;s outfit as she hit the orange carpet for the WNBA Draft.

## Houston man arrested for impersonating police officer after attempting to pull over real deputies
 - [https://www.foxnews.com/us/houston-man-arrested-impersonating-police-officer-after-attempting-pull-over-real-deputies](https://www.foxnews.com/us/houston-man-arrested-impersonating-police-officer-after-attempting-pull-over-real-deputies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T10:09:00+00:00

A Houston man &quot;fully equipped to deceive&quot; was arrested for impersonating a police officer after he attempted to pull over real deputies during a racing event over the weekend.

## Foreign policy expert reveals 2 key offensive strategies US must 'seize' on to win 'Cold War' with China
 - [https://www.foxnews.com/politics/foreign-policy-expert-reveals-2-key-offensive-strategies-win-cold-war-china](https://www.foxnews.com/politics/foreign-policy-expert-reveals-2-key-offensive-strategies-win-cold-war-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T10:00:19+00:00

Author Michael Sobolik explained to Fox News Digital the ways the United States must go on offense against China in order to win the developing Cold War between the nations.

## Bill Maher knocks CNN's non-stop Trump bashing: 'No one's been harder on him than me… and I'm bored with it'
 - [https://www.foxnews.com/media/bill-maher-knocks-cnns-non-stop-trump-bashing](https://www.foxnews.com/media/bill-maher-knocks-cnns-non-stop-trump-bashing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T10:00:00+00:00

HBO&apos;s Bill Maher took a swipe at sister network CNN for its over-the-top &quot;negative&quot; coverage of former President Trump, saying he&apos;s &quot;bored&quot; by it despite being a Trump hater himself.

## Bodies of 3-year-old girl and her mother recovered after deadly Indonesia landslide
 - [https://www.foxnews.com/world/bodies-3-year-old-girl-mother-recovered-deadly-indonesia-landslide](https://www.foxnews.com/world/bodies-3-year-old-girl-mother-recovered-deadly-indonesia-landslide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T09:55:41+00:00

Emergency crews recovered the bodies of a 3-year-old girl and her mother on Tuesday, who were both victims of a deadly landslide over the weekend.

## Bay Area Christians fight city over 'hostile and targeted' cross removal: 'Discriminatory action'
 - [https://www.foxnews.com/media/bay-area-christians-fight-city-hostile-targeted-cross-removal-discriminatory-action](https://www.foxnews.com/media/bay-area-christians-fight-city-hostile-targeted-cross-removal-discriminatory-action)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T09:00:13+00:00

A conservative legal defense organization filed a petition for relief after the City of Albany removed a cross maintained by the local Lions Club in June 2023.

## 3 surprising lessons after losing a spouse and trying to move forward in life: 'Still evolving'
 - [https://www.foxnews.com/lifestyle/3-surprising-lessons-losing-spouse-moving-forward-evolving](https://www.foxnews.com/lifestyle/3-surprising-lessons-losing-spouse-moving-forward-evolving)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T09:00:02+00:00

Author Warren Kozak of New York City has written a moving book about the loss of his wife to cancer and the emotional and psychological fallout — also sharing tips and advice for others.

## Ozempic babies: Women claim weight-loss drugs are making them more fertile and experts agree
 - [https://www.foxnews.com/health/ozempic-babies-women-claim-weight-loss-drugs-fertile-experts-agree](https://www.foxnews.com/health/ozempic-babies-women-claim-weight-loss-drugs-fertile-experts-agree)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T08:30:05+00:00

Women taking weight-loss drugs like Ozempic are reporting unexpected pregnancies. Drs. Rachel McConnell and Angela Fitch said these medications could boost fertility.

## Alabama senator seeks to expose abortions at the Department of Veterans Affairs
 - [https://www.foxnews.com/politics/sen-tuberville-quarterly-abortion-reports-veterans-affairs](https://www.foxnews.com/politics/sen-tuberville-quarterly-abortion-reports-veterans-affairs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T08:14:38+00:00

Tommy Tuberville is looking to increase transparency between the VA and taxpayers by requiring the department to report on abortions facilitated each quarter.

## FLASHBACK: Biden made revealing comment about niece's Obama admin role while praising 'rising China'
 - [https://www.foxnews.com/politics/flashback-biden-revealing-comment-nieces-obama-admin-role-praising-rising-china](https://www.foxnews.com/politics/flashback-biden-revealing-comment-nieces-obama-admin-role-praising-rising-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T08:00:56+00:00

Then-Vice President Biden gave a shoutout to his niece during a 2011 China speech, telling the crowd she&apos;s devoted to &apos;making sure&apos; the China-US relationship &apos;gets better and better.&apos;

## Senate prepares for Mayorkas impeachment articles while GOP braces for possible dismissal motion
 - [https://www.foxnews.com/politics/senate-mayorkas-impeachment-articles-gop-dismissal](https://www.foxnews.com/politics/senate-mayorkas-impeachment-articles-gop-dismissal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T08:00:44+00:00

The Senate is expected to received the two articles of impeachment against DHS Secretary Mayorkas on Tuesday at 2:15 p.m., setting up a potential trial.

## Morgan Wallen's first performance after Nashville arrest follows controversy at concert venue
 - [https://www.foxnews.com/entertainment/morgan-wallen-first-performance-nashville-arrest-follows-controversy-concert-venue](https://www.foxnews.com/entertainment/morgan-wallen-first-performance-nashville-arrest-follows-controversy-concert-venue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T08:00:19+00:00

Morgan Wallen returns to the stage on Saturday to perform for the first time since his Nashville arrest, and organizers are monitoring the country star&apos;s concert.

## Iran's attack on Israel shines spotlight on Tehran's advancing nuclear weapons program
 - [https://www.foxnews.com/world/irans-attack-israel-shines-spotlight-tehrans-advancing-nuclear-weapons-program](https://www.foxnews.com/world/irans-attack-israel-shines-spotlight-tehrans-advancing-nuclear-weapons-program)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T08:00:13+00:00

After Iran&apos;s first-ever massive aerial attack on Israel, Tehran’s illicit nuclear weapons program is front and center in the minds of security experts.

## Israel’s success, Iran’s failure and the chances of igniting the Mideast powder keg
 - [https://www.foxnews.com/politics/israels-success-irans-failure-chances-igniting-mideast-powder-keg](https://www.foxnews.com/politics/israels-success-irans-failure-chances-igniting-mideast-powder-keg)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T07:05:08+00:00

Over the weekend Iran launched more than 300 drones and missiles to Israel. The Jewish state responded with far superior military technology in retaliation.

## GREG GUTFELD: We've never seemed weaker, and the bad guys can see it
 - [https://www.foxnews.com/opinion/greg-gutfeld-never-seemed-weaker-bad-guys-can-see-it](https://www.foxnews.com/opinion/greg-gutfeld-never-seemed-weaker-bad-guys-can-see-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T03:51:38+00:00

&apos;Gutfeld!&apos; panelists react to Iran launching hundreds of missiles and drones at Israel.

## Trump should risk arrest and attend son's graduation, Piers Morgan says, force Dems into 'political suicide'
 - [https://www.foxnews.com/media/trump-risk-arrest-attend-sons-graduation-piers-morgan-force-dems-political-suicide](https://www.foxnews.com/media/trump-risk-arrest-attend-sons-graduation-piers-morgan-force-dems-political-suicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T02:31:55+00:00

Former President Trump was warned not to miss any court dates by Judge Juan Merchan, but Piers Morgan said he should attend his son&apos;s graduation anyway.

## SEAN HANNITY: Biden is 'willing and able' to throw Israel under the bus
 - [https://www.foxnews.com/media/sean-hannity-biden-willing-able-throw-israel-under-bus](https://www.foxnews.com/media/sean-hannity-biden-willing-able-throw-israel-under-bus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T02:22:16+00:00

Fox News host Sean Hannity criticized President Biden for appeasing his “radical base&quot; and his weak “don’t&quot; message that did not deter Iran from attacking Israel.

## LAURA INGRAHAM: America under Biden is 'ashamed and shaky'
 - [https://www.foxnews.com/media/laura-ingraham-america-under-biden-ashamed-shaky](https://www.foxnews.com/media/laura-ingraham-america-under-biden-ashamed-shaky)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T02:00:38+00:00

Fox News host Laura Ingraham gives her take on how American has changed under the Biden administration on &apos;The Ingraham Angle.&apos;

## Houston IRS office forced to close early after fight breaks out: 'I ain’t doing no playing'
 - [https://www.foxnews.com/us/houston-irs-office-forced-close-early-after-fight-breaks-out-aint-doing-no-playing](https://www.foxnews.com/us/houston-irs-office-forced-close-early-after-fight-breaks-out-aint-doing-no-playing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T01:51:55+00:00

Chaos broke out at an IRS office in Houston after taxpayers got into a brawl and people rushed into the building. The office was forced to close early.

## JESSE WATTERS: Trump isn't even allowed to attend his son Barron's high school graduation
 - [https://www.foxnews.com/media/jesse-watters-trump-isnt-even-allowed-attend-son-barrons-high-school-graduation](https://www.foxnews.com/media/jesse-watters-trump-isnt-even-allowed-attend-son-barrons-high-school-graduation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T01:47:36+00:00

Fox News host Jesse Watters shreds the show trials against former President Trump on &quot;Jesse Watters Primetime.&quot;

## Chiefs' Rashee Rice sued for $1 million by 2 'severely injured' victims in Dallas car crash
 - [https://www.foxnews.com/sports/chiefs-rashee-rice-sued-1-million-2-severely-injured-victims-dallas-car-crash](https://www.foxnews.com/sports/chiefs-rashee-rice-sued-1-million-2-severely-injured-victims-dallas-car-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T01:45:03+00:00

Kansas City Chiefs wide receiver Rashee Rice is being sued, along with SMU cornerback Teddy Knox, for $1 million by two victims in the recent Dallas car crash.

## Illegal migrant convicted of child rape arrested after district court ignored detainer request
 - [https://www.foxnews.com/us/illegal-migrant-convicted-child-rape-arrested-district-court-ignored-detainer-request](https://www.foxnews.com/us/illegal-migrant-convicted-child-rape-arrested-district-court-ignored-detainer-request)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T01:44:55+00:00

An illegal immigrant charged with child rape was arrested after a District Court ignored a detainer request and let him back into the community.

## LSU star Angel Reese selected No. 7 overall by Chicago Sky
 - [https://www.foxnews.com/sports/lsu-star-angel-reese-selected-no-7-overall-chicago-sky](https://www.foxnews.com/sports/lsu-star-angel-reese-selected-no-7-overall-chicago-sky)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T01:31:03+00:00

LSU star Angel Reese is heading to the Windy City, as the Chicago Sky drafted her seventh overall in the 2024 WNBA Draft after previously taking South Carolina&apos;s Kamilla Cardoso.

## Speaker Johnson says it’s U.S.’s ‘biblical admonition’ to help Israel
 - [https://www.foxnews.com/politics/speaker-johnson-says-us-biblical-admonition-help-israel](https://www.foxnews.com/politics/speaker-johnson-says-us-biblical-admonition-help-israel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T01:27:14+00:00

Speaker Mike Johnson spoke at a pro-Israel event shortly after unveiling a path to fund Israel and other allies on Monday night.

## Alexa PenaVega and husband Carlos mourn the loss of stillborn daughter Indy
 - [https://www.foxnews.com/entertainment/alexa-penavega-husband-carlos-mourn-loss-stillborn-daughter-indy](https://www.foxnews.com/entertainment/alexa-penavega-husband-carlos-mourn-loss-stillborn-daughter-indy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T01:14:27+00:00

Actress Alexa PenaVega and husband Carlos PenaVega announced on social media that daughter Indy was &quot;born at rest&quot; following &quot;beautiful and peaceful delivery.&quot;

## Colorado county sues state government over sanctuary immigration policies: 'Quality of life comes first'
 - [https://www.foxnews.com/us/colorado-county-sues-state-government-sanctuary-immigration-policies-quality-life-comes-first](https://www.foxnews.com/us/colorado-county-sues-state-government-sanctuary-immigration-policies-quality-life-comes-first)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:58:28+00:00

Douglas County officials sued the state of Colorado over its immigration policies on Monday, petitioning for the right to work with federal authorities on immigration matters.

## IAEA warns that attacks on a nuclear plant in Russian-controlled Ukraine put the world at risk
 - [https://www.foxnews.com/world/iaea-warns-attacks-nuclear-plant-russian-controlled-ukraine-put-world-risk](https://www.foxnews.com/world/iaea-warns-attacks-nuclear-plant-russian-controlled-ukraine-put-world-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:39:51+00:00

Ukraine and Russia traded blame for the attacks on Europe’s largest nuclear power plant before the United Nations Security Council on Monday; attacks put the world &apos;close to a nuclear accident.&apos;

## Fix autocorrect if it’s driving you ducking crazy
 - [https://www.foxnews.com/tech/fix-autocorrect-driving-you-ducking-crazy](https://www.foxnews.com/tech/fix-autocorrect-driving-you-ducking-crazy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:39:43+00:00

Discover easy solutions to tame autocorrect frustration on iOS and Android devices. Turn off, customize and add personal touches to your typing experience.

## 'Golden Bachelor' star Theresa Nist quotes Dr. Seuss after announcing divorce
 - [https://www.foxnews.com/entertainment/golden-bachelor-star-theresa-nist-quotes-dr-seuss-after-announcing-divorce](https://www.foxnews.com/entertainment/golden-bachelor-star-theresa-nist-quotes-dr-seuss-after-announcing-divorce)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:38:28+00:00

&quot;Golden Bachelor&quot; winner Theresa Nist shared a Dr. Suess quote on social media just days after announcing her divorce from Gerry Turner. The reality TV show couple tied the knot in an on-air ceremony in January.

## Biden hosts Czech leader at White House to promote Ukraine aid amid holdup in Congress
 - [https://www.foxnews.com/politics/biden-hosts-czech-leader-white-house-promote-ukraine-aid-amid-holdup-congress](https://www.foxnews.com/politics/biden-hosts-czech-leader-white-house-promote-ukraine-aid-amid-holdup-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:38:05+00:00

As President Joe Biden hosted Czech Prime Minister Petr Fiala in the Oval Office on Monday, Biden urged the U.S. House to take up supplemental funding for Ukraine and Israel.

## Paris Hilton backs California bill to bring more transparency to youth treatment facilities
 - [https://www.foxnews.com/politics/paris-hilton-backs-california-bill-bring-transparency-youth-treatment-facilities](https://www.foxnews.com/politics/paris-hilton-backs-california-bill-bring-transparency-youth-treatment-facilities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:36:16+00:00

Hilton Hotel heiress and media personality Paris Hilton has joined California state lawmakers in pushing for legislation that would require greater transparency from youth treatment facilities.

## Johnson unveils plan to fund Israel, Ukraine in closed-door House GOP meeting
 - [https://www.foxnews.com/politics/johnson-unveils-plan-fund-israel-ukraine-closed-door-house-gop-meeting](https://www.foxnews.com/politics/johnson-unveils-plan-fund-israel-ukraine-closed-door-house-gop-meeting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:20:48+00:00

House Speaker Mike Johnson unveiled a plan to fund the U.S.&apos;s foreign aid priorities amid mounting pressure and global conflicts.

## Texas Gov. Abbott blasts Homeland Security Secretary Alejandro Mayorkas over border crisis: 'Bunch of lies'
 - [https://www.foxnews.com/us/texas-gov-abbott-blasts-homeland-security-secretary-alejandro-mayorkas-border-crisis-bunch-lies](https://www.foxnews.com/us/texas-gov-abbott-blasts-homeland-security-secretary-alejandro-mayorkas-border-crisis-bunch-lies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:15:00+00:00

Texas Gov. Greg Abbott sat down with FOX4 News to discuss second attempt to impeach Homeland Security Secretary Alejandro Mayorkas over the border crisis.

## California sues beach city over voter ID law backed by majority of residents
 - [https://www.foxnews.com/politics/california-sues-beach-city-voter-id-law-backed-majority-residents](https://www.foxnews.com/politics/california-sues-beach-city-voter-id-law-backed-majority-residents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:03:48+00:00

California officials are suing Huntington Beach over a voter ID amendment the city passed last month with support from a majority of residents.

## White House official confronted on international blunders under Biden: 'Got your hands full'
 - [https://www.foxnews.com/media/white-house-official-confronted-international-blunders-biden-got-hands-full](https://www.foxnews.com/media/white-house-official-confronted-international-blunders-biden-got-hands-full)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-04-16T00:00:12+00:00

White House national security communications advisor John Kirby was pressed on the international chaos under the Biden administration by Fox News anchor Bill Hemmer.

