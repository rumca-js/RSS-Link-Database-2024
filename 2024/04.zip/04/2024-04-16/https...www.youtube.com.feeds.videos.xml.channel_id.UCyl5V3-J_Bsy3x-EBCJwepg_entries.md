# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## TRAILER: Travis Interviews the World ft. Dr. Jordan B Peterson
 - [https://www.youtube.com/watch?v=AO-vf7UHu6M](https://www.youtube.com/watch?v=AO-vf7UHu6M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2024-04-16T20:10:29+00:00

This Wednesday, The Babylon Bee presents a brand-new interview show: Travis Interviews the World - with our first guest, the apparently well-known Canadian man Dr. Jordan B Peterson (@JordanBPeterson).

#interview #comedy #dailywire #babylonbee

