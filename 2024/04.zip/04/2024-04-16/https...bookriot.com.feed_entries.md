# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## Bringing an Oasis to the Book Desert
 - [https://bookriot.com/today-in-books-april-16-2024](https://bookriot.com/today-in-books-april-16-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-16T14:54:52+00:00

A local hero brings a book vending machine to St. Louis's "book desert" communities,  Congress explores AI regulation, and more bookish news.

## Book Riot’s Deals of the Day for April 16, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-april-16-2024](https://bookriot.com/book-riots-deals-of-the-day-for-april-16-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-16T14:44:03+00:00

Tales from the culinary underbelly, ghosts, gods, &#038; gangsters, a reluctant ex-spy pulled back into the fray, and more of today's best book deals.

## Twisty-Turny Tales That Blur the Line Between Fantasy and Reality in Black Life
 - [https://bookriot.com/weird-black-girls-elwin-cotman](https://bookriot.com/weird-black-girls-elwin-cotman)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-16T13:00:00+00:00

In WEIRD BLACK GIRLS, Elwin Cotman delivers seven short stories that go long on the absurdity and anxiety of modern Black life.

## Book Clubs Are Having a Moment
 - [https://bookriot.com/book-clubs-are-having-a-moment](https://bookriot.com/book-clubs-are-having-a-moment)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-16T12:30:00+00:00

What do you think of the surge and current popularity of book clubs?

## Double The Book Bans In Half The Time: PEN America’s Latest Book Ban Report
 - [https://bookriot.com/pen-americas-latest-book-ban-report](https://bookriot.com/pen-americas-latest-book-ban-report)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-16T12:05:00+00:00

PEN's new report shows that book bans continue to rise and continue to target books by or about queer people and people of color.

## The Best New Book Releases Out April 16, 2024
 - [https://bookriot.com/best-new-book-releases-out-april-16-2024](https://bookriot.com/best-new-book-releases-out-april-16-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-16T11:00:00+00:00

A memoir of survival by Salman Rushdie, a Japanese thriller/mystery, a tale of four sisters in Ireland, and more round out today's list of new releases. Which ones are you adding to your list?

## Cookbook Showdown: The Best Weed Cookbooks, Tested
 - [https://bookriot.com/weed-cookbooks](https://bookriot.com/weed-cookbooks)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-16T10:30:00+00:00

Take your 4/20 to the next level with these recipes.

## 8 Useful Books About Focusing to Improve Your Attention Span
 - [https://bookriot.com/books-about-focusing](https://bookriot.com/books-about-focusing)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-04-16T10:00:00+00:00

Do you find it difficult to focus while reading?

