# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Russian-Backed Official Survives Assassination Attempt in Occupied Ukraine, Colleague Says
 - [https://www.themoscowtimes.com/2024/04/16/russian-backed-official-survives-assassination-attempt-in-occupied-ukraine-colleague-says-a84862](https://www.themoscowtimes.com/2024/04/16/russian-backed-official-survives-assassination-attempt-in-occupied-ukraine-colleague-says-a84862)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T15:46:00+00:00

“Anton was lucky, the main direction of the explosion went past him. He was just grazed,” local pro-Russian politician Vladimir Rogov said.

## Russia’s Orenburg Holds WWII Victory Parade Rehearsals Amid Flood Crisis
 - [https://www.themoscowtimes.com/2024/04/16/russias-orenburg-holds-wwii-victory-parade-rehearsals-amid-flood-crisis-a84858](https://www.themoscowtimes.com/2024/04/16/russias-orenburg-holds-wwii-victory-parade-rehearsals-amid-flood-crisis-a84858)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T15:07:00+00:00

As thousands of homes remained submerged underwater, city officials pressed on with rehearsals for Russia's showpiece patriotic holiday.

## Russia But Not Putin Invited To French D-Day Anniversary – Organizers
 - [https://www.themoscowtimes.com/2024/04/16/russia-but-not-putin-invited-to-french-d-day-anniversary-organizers-a84859](https://www.themoscowtimes.com/2024/04/16/russia-but-not-putin-invited-to-french-d-day-anniversary-organizers-a84859)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T14:40:00+00:00

Putin, who is wanted by the International Criminal Court, was not invited due to Russia's "war of aggression" in Ukraine.

## Putin Urges Restraint in Call With Iran's Raisi
 - [https://www.themoscowtimes.com/2024/04/16/putin-urges-restraint-in-call-with-irans-raisi-a84860](https://www.themoscowtimes.com/2024/04/16/putin-urges-restraint-in-call-with-irans-raisi-a84860)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T14:11:05+00:00

The Russian leader expressed the hope that all sides would show reasonable restraint and prevent a new round of confrontation.

## She Photographed Russian Political Prisoners. Now She's Charged With 'Extremism.'
 - [https://www.themoscowtimes.com/2024/04/16/she-photographed-russian-political-prisoners-now-shes-charged-with-extremism-a84848](https://www.themoscowtimes.com/2024/04/16/she-photographed-russian-political-prisoners-now-shes-charged-with-extremism-a84848)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T14:02:00+00:00

Antonina Favorskaya and her colleagues consider the charges against her to be revenge for her journalism and political views.

## IMF Raises Russia’s Growth Forecast for 2024
 - [https://www.themoscowtimes.com/2024/04/16/imf-raises-russias-growth-forecast-for-2024-a84861](https://www.themoscowtimes.com/2024/04/16/imf-raises-russias-growth-forecast-for-2024-a84861)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T13:48:45+00:00

Russia’s economy is expected to grow 3.2% this year, up from the previous forecast of 2.6% issued in January.

## Raiffeisen Touts Russia ‘Expansion’ in Job Ads Despite Intended Exit – FT
 - [https://www.themoscowtimes.com/2024/04/16/raiffeisen-touts-russia-expansion-in-job-ads-despite-intended-exit-ft-a84855](https://www.themoscowtimes.com/2024/04/16/raiffeisen-touts-russia-expansion-in-job-ads-despite-intended-exit-ft-a84855)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T12:16:00+00:00

The Austrian bank has placed more than 2,400 job ads in Russia since December 2023, the Financial Times reported.

## Russia Says Arrested Man Behind Car Bomb Attack on Ukrainian Defector
 - [https://www.themoscowtimes.com/2024/04/16/russia-says-arrested-man-behind-car-bomb-attack-on-ukrainian-defector-a84854](https://www.themoscowtimes.com/2024/04/16/russia-says-arrested-man-behind-car-bomb-attack-on-ukrainian-defector-a84854)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T11:04:00+00:00

Vasily Prozorov, a former member of Ukraine’s SBU security service, was injured last week after a bomb went off under his SUV in Moscow.

## Talks for New Black Sea Shipping Deal Collapsed in March – Reuters
 - [https://www.themoscowtimes.com/2024/04/16/talks-for-new-black-sea-shipping-deal-collapsed-in-march-reuters-a84852](https://www.themoscowtimes.com/2024/04/16/talks-for-new-black-sea-shipping-deal-collapsed-in-march-reuters-a84852)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T09:44:00+00:00

“At the very last minute, Ukraine suddenly pulled out and the deal was scuttled,” a source was quoted as saying.

## Moscow Court Arrests in Absentia Exiled Journalist Zygar
 - [https://www.themoscowtimes.com/2024/04/16/moscow-court-arrests-in-absentia-exiled-journalist-zygar-a84853](https://www.themoscowtimes.com/2024/04/16/moscow-court-arrests-in-absentia-exiled-journalist-zygar-a84853)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T09:15:00+00:00

Mikhail Zygar is accused of spreading “false information” about the Russian military.

## More Evacuations in Russia’s Urals, Western Siberia as Water Levels Rise
 - [https://www.themoscowtimes.com/2024/04/16/more-evacuations-in-russias-urals-western-siberia-as-water-levels-rise-a84851](https://www.themoscowtimes.com/2024/04/16/more-evacuations-in-russias-urals-western-siberia-as-water-levels-rise-a84851)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-04-16T08:20:00+00:00

Authorities in the Kurgan and Tyumen regions have urged residents to flee as the nearby Tobol and Ishim rivers swelled to dangerous levels.

