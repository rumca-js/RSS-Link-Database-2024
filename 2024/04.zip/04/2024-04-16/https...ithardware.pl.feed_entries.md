# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Mafia 4 coraz bliżej. Take-Two szykuje się do oficjalnej zapowiedzi
 - [https://ithardware.pl/aktualnosci/mafia_4_coraz_blizej_take_two_szykuje_sie_do_oficjalnej_zapowiedzi-32579.html](https://ithardware.pl/aktualnosci/mafia_4_coraz_blizej_take_two_szykuje_sie_do_oficjalnej_zapowiedzi-32579.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T19:22:00+00:00

<img src="https://ithardware.pl/artykuly/min/32579_1.jpg" />            Mafia, niegdyś popularna seria gier od czeskiego studia&nbsp;Illusion Softworks dziś pozostaje w cieniu. Jest jednak szansa na odkurzenie IP po czterech latach, kiedy to na światło dzienny wyszedł remake pierwszej części i remastery drugiego oraz...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mafia_4_coraz_blizej_take_two_szykuje_sie_do_oficjalnej_zapowiedzi-32579.html">https://ithardware.pl/aktualnosci/mafia_4_coraz_blizej_take_two_szykuje_sie_do_oficjalnej_zapowiedzi-32579.html</a></p>

## NVIDIA DLSS w trzech kolejnych tytułach, w tym w Manor Lords. Udostępniono nowy sterownik Game Ready
 - [https://ithardware.pl/aktualnosci/nvidia_dlss_w_trzech_kolejnych_tytulach_w_tym_w_manor_lords_udostepniono_nowy_sterownik_game_ready-32578.html](https://ithardware.pl/aktualnosci/nvidia_dlss_w_trzech_kolejnych_tytulach_w_tym_w_manor_lords_udostepniono_nowy_sterownik_game_ready-32578.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T18:25:00+00:00

<img src="https://ithardware.pl/artykuly/min/32578_1.jpg" />            NVIDIA DLSS trafia do kolejnych gier. Tym razem technologia wzbogaciła&nbsp;trzy produkcje w tym polski tytuł Manor Lords. To nie wszystkie wieści ze stajni Zielonych.

Każdego tygodnia nowe gry otrzymują wsparcie technik&nbsp;NVIDIA...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_dlss_w_trzech_kolejnych_tytulach_w_tym_w_manor_lords_udostepniono_nowy_sterownik_game_ready-32578.html">https://ithardware.pl/aktualnosci/nvidia_dlss_w_trzech_kolejnych_tytulach_w_tym_w_manor_lords_udostepniono_nowy_sterownik_game_ready-32578.html</a></p>

## Wiedżmin 3 pozwoli tworzyć własne zadania, animacje i lokacje. CD Projekt udostępnia nowe narzędzie
 - [https://ithardware.pl/aktualnosci/wiedzmin_3_pozwoli_tworzyc_wlasne_zadania_animacje_i_lokacje_cd_projekt_udostepnia_nowe_narzedzie-32577.html](https://ithardware.pl/aktualnosci/wiedzmin_3_pozwoli_tworzyc_wlasne_zadania_animacje_i_lokacje_cd_projekt_udostepnia_nowe_narzedzie-32577.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T16:23:55+00:00

<img src="https://ithardware.pl/artykuly/min/32577_1.jpg" />            Wiedźmin 3: Dziki Gon jest z nami blisko 10 lat. To szmat czasu, a w międzyczasie dostaliśmy wielką next genową aktualizację, kt&oacute;ra poprawiła oprawę graficzną. Dodano nawet jedno fabularne zadanie i chociaż teraz CD Projekt RED zajęty...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wiedzmin_3_pozwoli_tworzyc_wlasne_zadania_animacje_i_lokacje_cd_projekt_udostepnia_nowe_narzedzie-32577.html">https://ithardware.pl/aktualnosci/wiedzmin_3_pozwoli_tworzyc_wlasne_zadania_animacje_i_lokacje_cd_projekt_udostepnia_nowe_narzedzie-32577.html</a></p>

## Słuchawki Fresh ‘n Rebel Clam Blaze - 80 godzin słuchania muzyki na jednym ładowaniu baterii
 - [https://ithardware.pl/aktualnosci/sluchawki_fresh_n_rebel_clam_blaze_80_godzin_sluchania_muzyki_na_jednym_ladowaniu_baterii-32576.html](https://ithardware.pl/aktualnosci/sluchawki_fresh_n_rebel_clam_blaze_80_godzin_sluchania_muzyki_na_jednym_ladowaniu_baterii-32576.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T15:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/32576_1.jpg" />            Clam Blaze to słuchawki od holenderskiej firmy&nbsp;Fresh &lsquo;n Rebel, kt&oacute;re debiutują na rynku. Jest to urządzenie bezprzewodowe działające na&nbsp;nausznych Bluetooth 5.2, kt&oacute;re oferuje m.in.&nbsp;wyciszanie hałasu ENC, redukcję...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sluchawki_fresh_n_rebel_clam_blaze_80_godzin_sluchania_muzyki_na_jednym_ladowaniu_baterii-32576.html">https://ithardware.pl/aktualnosci/sluchawki_fresh_n_rebel_clam_blaze_80_godzin_sluchania_muzyki_na_jednym_ladowaniu_baterii-32576.html</a></p>

## Duży wydawca nie pojawi się na targach Gamescom 2024
 - [https://ithardware.pl/aktualnosci/duzy_wydawca_nie_pojawi_sie_na_targach_gamescom_2024-32575.html](https://ithardware.pl/aktualnosci/duzy_wydawca_nie_pojawi_sie_na_targach_gamescom_2024-32575.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T14:48:10+00:00

<img src="https://ithardware.pl/artykuly/min/32575_1.jpg" />            Targi Gamescom 2024 odbędą się 21-25 sierpnia. Tymczasem już teraz odpadł jeden z gł&oacute;wnych graczy, kt&oacute;rzy pojawiał się na niemieckim wydarzeniu.

Nintendo to firma, kt&oacute;rej zabraknie na Gamescom 2024. Taką informację...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/duzy_wydawca_nie_pojawi_sie_na_targach_gamescom_2024-32575.html">https://ithardware.pl/aktualnosci/duzy_wydawca_nie_pojawi_sie_na_targach_gamescom_2024-32575.html</a></p>

## Gracze wściekli na Ubisoft. Chodzi o misję w Star Wars Outlaws. Wydawca odnosi się do krytyki
 - [https://ithardware.pl/aktualnosci/gracze_wsciekli_na_ubisoft_chodzi_o_misje_w_star_wars_outlaws_wydawca_odnosi_sie_do_krytyki-32574.html](https://ithardware.pl/aktualnosci/gracze_wsciekli_na_ubisoft_chodzi_o_misje_w_star_wars_outlaws_wydawca_odnosi_sie_do_krytyki-32574.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T13:40:00+00:00

<img src="https://ithardware.pl/artykuly/min/32574_1.jpg" />            W zeszłym tygodniu Star Wars Outlaws wywołał poruszenie za sprawą ekskluzywnej misji, w kt&oacute;rej wystąpi doskonale znany przedstawiciel gwiezdnego p&oacute;łświatka&nbsp;Jabba Hutt. Problem w tym, że zadanie zostało zarezerwowane dla...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gracze_wsciekli_na_ubisoft_chodzi_o_misje_w_star_wars_outlaws_wydawca_odnosi_sie_do_krytyki-32574.html">https://ithardware.pl/aktualnosci/gracze_wsciekli_na_ubisoft_chodzi_o_misje_w_star_wars_outlaws_wydawca_odnosi_sie_do_krytyki-32574.html</a></p>

## NFC z zupełnie nowym zastosowaniem w smartfonach. Chodzi o ładowanie
 - [https://ithardware.pl/aktualnosci/nfc_z_zupelnie_nowym_zastosowaniem_w_smartfonach_chodzi_o_ladowanie-32573.html](https://ithardware.pl/aktualnosci/nfc_z_zupelnie_nowym_zastosowaniem_w_smartfonach_chodzi_o_ladowanie-32573.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T12:06:00+00:00

<img src="https://ithardware.pl/artykuly/min/32573_1.jpg" />            Google ma pracować nad wykorzystaniem technologii ładowania bezprzewodowego przez NFC. Nowość może zostać dodana już do Androida 15.

Możliwość bezprzewodowego ładowania smartfona nie jest czymś nowym. Technologia ta...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nfc_z_zupelnie_nowym_zastosowaniem_w_smartfonach_chodzi_o_ladowanie-32573.html">https://ithardware.pl/aktualnosci/nfc_z_zupelnie_nowym_zastosowaniem_w_smartfonach_chodzi_o_ladowanie-32573.html</a></p>

## Elegoo Saturn 4 Ultra - test drukarki żywicznej. Jestem pod wrażeniem
 - [https://ithardware.pl/testyirecenzje/elegoo_saturn_4_ultra-32571.html](https://ithardware.pl/testyirecenzje/elegoo_saturn_4_ultra-32571.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T11:52:30+00:00

<img src="https://ithardware.pl/artykuly/min/32571_1.jpg" />            Elegoo Saturn 4 Ultra- test drukarki żywicznej

Kiedy słyszycie o drukarkach 3D, większość z was myśli zapewne o drukarkach filamentowych (FDM), kt&oacute;re wydają się popularniejsze ze względu na bardziej praktyczny charakter. Jeśli jednak...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/elegoo_saturn_4_ultra-32571.html">https://ithardware.pl/testyirecenzje/elegoo_saturn_4_ultra-32571.html</a></p>

## ASUS zapowiada nowy monitor 8K typu Mini LED -  1200 nitów i 4096 stref podświetlenia
 - [https://ithardware.pl/aktualnosci/asus_zapowiada_nowy_monitor_8k_typu_mini_led_1200_nitow_i_4096_stref_podswietlenia-32568.html](https://ithardware.pl/aktualnosci/asus_zapowiada_nowy_monitor_8k_typu_mini_led_1200_nitow_i_4096_stref_podswietlenia-32568.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T11:42:00+00:00

<img src="https://ithardware.pl/artykuly/min/32568_1.jpg" />            ASUS zaprezentował zupełnie nowy monitor 8K i jak zapewne się domyślacie, nie jest to produkt skierowany do graczy, ale do profesjonalist&oacute;w, kt&oacute;rzy są w stanie zrobić lepszy użytek z tak wysokiej rozdzielczości.&nbsp;

ASUS ProArt...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/asus_zapowiada_nowy_monitor_8k_typu_mini_led_1200_nitow_i_4096_stref_podswietlenia-32568.html">https://ithardware.pl/aktualnosci/asus_zapowiada_nowy_monitor_8k_typu_mini_led_1200_nitow_i_4096_stref_podswietlenia-32568.html</a></p>

## Samsung dostaje ogromne pieniądze od USA na budowę nowej fabryki
 - [https://ithardware.pl/aktualnosci/samsung_dostaje_ogromne_pieniadze_od_usa_na_budowe_nowej_fabryki-32567.html](https://ithardware.pl/aktualnosci/samsung_dostaje_ogromne_pieniadze_od_usa_na_budowe_nowej_fabryki-32567.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T10:25:40+00:00

<img src="https://ithardware.pl/artykuly/min/32567_1.jpg" />            Departament Handlu USA ogłosił kolejnego beneficjenta ustawy CHIPS and Science Act. Zgodnie z oczekiwaniami administracja Bidena przyznała Samsungowi potężny zastrzyk got&oacute;wki, bo firma otrzyma dotacje o wartości do 6,4 miliarda...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_dostaje_ogromne_pieniadze_od_usa_na_budowe_nowej_fabryki-32567.html">https://ithardware.pl/aktualnosci/samsung_dostaje_ogromne_pieniadze_od_usa_na_budowe_nowej_fabryki-32567.html</a></p>

## Nazwa Alfa Romeo Milano jest niezgodna z prawem, ponieważ samochód będzie produkowany w Polsce
 - [https://ithardware.pl/aktualnosci/nazwa_alfa_romeo_milano_jest_niezgodna_z_prawem_poniewaz_samochod_bedzie_produkowany_w_polsce-32572.html](https://ithardware.pl/aktualnosci/nazwa_alfa_romeo_milano_jest_niezgodna_z_prawem_poniewaz_samochod_bedzie_produkowany_w_polsce-32572.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T09:16:30+00:00

<img src="https://ithardware.pl/artykuly/min/32572_1.jpg" />            Trwające napięcia między Włochami a sp&oacute;łką macierzystą Alfy Romeo, Stellantis, osiągnęły w zeszłym tygodniu punkt kulminacyjny, gdy włoski rząd powiedział producentowi samochod&oacute;w, że nazwanie nadchodzącej Alfy Romeo EV...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nazwa_alfa_romeo_milano_jest_niezgodna_z_prawem_poniewaz_samochod_bedzie_produkowany_w_polsce-32572.html">https://ithardware.pl/aktualnosci/nazwa_alfa_romeo_milano_jest_niezgodna_z_prawem_poniewaz_samochod_bedzie_produkowany_w_polsce-32572.html</a></p>

## Black Shark zapowiada inteligetny pierścień z bardzo długim czasem pracy na baterii
 - [https://ithardware.pl/aktualnosci/black_shark_zapowiada_inteligetny_pierscien_z_bardzo_dlugim_czasem_pracy_na_baterii-32565.html](https://ithardware.pl/aktualnosci/black_shark_zapowiada_inteligetny_pierscien_z_bardzo_dlugim_czasem_pracy_na_baterii-32565.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T09:16:20+00:00

<img src="https://ithardware.pl/artykuly/min/32565_1.jpg" />            Wygląda na to, że inteligentne pierścienie mogą być kolejną kategorią produkt&oacute;w, kt&oacute;ra podbije rynek, a tak przynajmniej zdają się myśleć producenci sprzętu mobilnego. Kiedy Samsung szykuje się do premiera swojego Galaxy Ring...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/black_shark_zapowiada_inteligetny_pierscien_z_bardzo_dlugim_czasem_pracy_na_baterii-32565.html">https://ithardware.pl/aktualnosci/black_shark_zapowiada_inteligetny_pierscien_z_bardzo_dlugim_czasem_pracy_na_baterii-32565.html</a></p>

## Szykujcie się na większe pojemności dyskó SSD. Samsung szykuje 290-warstwowe pamięci
 - [https://ithardware.pl/aktualnosci/szykujcie_sie_na_wieksze_pojemnosci_dysko_ssd_samsung_szykuje_290_warstwowe_pamieci-32564.html](https://ithardware.pl/aktualnosci/szykujcie_sie_na_wieksze_pojemnosci_dysko_ssd_samsung_szykuje_290_warstwowe_pamieci-32564.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T07:29:00+00:00

<img src="https://ithardware.pl/artykuly/min/32564_1.jpg" />            Według doniesień medialnych Hankyung firma Samsung Electronics ma rozpocząć masową produkcję dziewiątej generacji V-NAND jeszcze w tym miesiącu. Nowa generacja 3D NAND od Samsunga będzie zawierać 290 aktywnych warstw, co nie stanowi znaczącego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/szykujcie_sie_na_wieksze_pojemnosci_dysko_ssd_samsung_szykuje_290_warstwowe_pamieci-32564.html">https://ithardware.pl/aktualnosci/szykujcie_sie_na_wieksze_pojemnosci_dysko_ssd_samsung_szykuje_290_warstwowe_pamieci-32564.html</a></p>

## PlayStation 5 Pro - wyciekły szczegóły specyfikacji
 - [https://ithardware.pl/aktualnosci/playstation_5_pro_wyciekly_szczegoly_specyfikacji-32569.html](https://ithardware.pl/aktualnosci/playstation_5_pro_wyciekly_szczegoly_specyfikacji-32569.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T07:05:30+00:00

<img src="https://ithardware.pl/artykuly/min/32569_1.jpg" />            W sieci pojawia się coraz więcej przeciek&oacute;w na temat specyfikacji PlayStation 5 Pro i jeśli ktoś ma jeszcze wątpliwości, czy Sony rzeczywiście szykuje takowy sprzęt, to ostatnie działania firmy, kt&oacute;ra zaczyna ściągać z sieci...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/playstation_5_pro_wyciekly_szczegoly_specyfikacji-32569.html">https://ithardware.pl/aktualnosci/playstation_5_pro_wyciekly_szczegoly_specyfikacji-32569.html</a></p>

## Frostpunk 2 - start bety, wymagania PC i trailer omawiający rozgrywkę
 - [https://ithardware.pl/aktualnosci/frostpunk_2_start_bety_wymagania_pc_i_trailer_omawiajacy_rozgrywke-32566.html](https://ithardware.pl/aktualnosci/frostpunk_2_start_bety_wymagania_pc_i_trailer_omawiajacy_rozgrywke-32566.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T06:47:35+00:00

<img src="https://ithardware.pl/artykuly/min/32566_1.jpg" />            11 bit studios uruchomiło betę gry Frostpunk 2 i przy okazji ujawniło wymagania sprzętowe gry na PC. Ponadto zesp&oacute;ł udostępnił szczeg&oacute;łowy zwiastun rozgrywki, kt&oacute;ry możecie obejrzeć poniżej.&nbsp;

Frostpunk 2 to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/frostpunk_2_start_bety_wymagania_pc_i_trailer_omawiajacy_rozgrywke-32566.html">https://ithardware.pl/aktualnosci/frostpunk_2_start_bety_wymagania_pc_i_trailer_omawiajacy_rozgrywke-32566.html</a></p>

## YouTube rozszerza działania przeciwko aplikacjom blokującym reklamy
 - [https://ithardware.pl/aktualnosci/youtube_rozszerza_dzialania_przeciwko_aplikacjom_blokujacym_reklamy-32563.html](https://ithardware.pl/aktualnosci/youtube_rozszerza_dzialania_przeciwko_aplikacjom_blokujacym_reklamy-32563.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-04-16T06:03:27+00:00

<img src="https://ithardware.pl/artykuly/min/32563_1.jpg" />            YouTube, czyli największy serwis wideo, od jakiegoś czasu pr&oacute;buje uniemożliwić użytkownikom blokowanie reklam. Przez dłuższy czas w temacie panowała cisza, ale to właśnie uległo zmianie.&nbsp;

W sierpniu 2023 r. YT generował...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/youtube_rozszerza_dzialania_przeciwko_aplikacjom_blokujacym_reklamy-32563.html">https://ithardware.pl/aktualnosci/youtube_rozszerza_dzialania_przeciwko_aplikacjom_blokujacym_reklamy-32563.html</a></p>

