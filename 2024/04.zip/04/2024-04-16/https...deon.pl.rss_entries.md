# Source:DEON.pl, URL:https://deon.pl/rss, language:pl

## Co robić, gdy ukąsi cię żmija? Przyrodnik tłumaczy, dlaczego nie należy się poruszać
 - [https://deon.pl/swiat/co-robic-gdy-ukasi-cie-zmija-przyrodnik-tlumaczy-dlaczego-nie-nalezy-sie-poruszac,2794175](https://deon.pl/swiat/co-robic-gdy-ukasi-cie-zmija-przyrodnik-tlumaczy-dlaczego-nie-nalezy-sie-poruszac,2794175)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T13:55:40+00:00



## Bp Przybylski: O powołaniach trzeba myśleć szerzej niż tylko w kontekście rekrutacji do seminariów
 - [https://deon.pl/kosciol/bp-przybylski-o-powolaniach-trzeba-myslec-szerzej-niz-tylko-w-kontekscie-rekrutacji-do-seminariow,2794457](https://deon.pl/kosciol/bp-przybylski-o-powolaniach-trzeba-myslec-szerzej-niz-tylko-w-kontekscie-rekrutacji-do-seminariow,2794457)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T13:20:08+00:00



## "Ksiądz Spolsky". Ta grupa na Facebooku jest tylko dla księży
 - [https://deon.pl/kosciol/ksiadz-spolsky-ta-grupa-na-facebooku-jest-tylko-dla-ksiezy,2794418](https://deon.pl/kosciol/ksiadz-spolsky-ta-grupa-na-facebooku-jest-tylko-dla-ksiezy,2794418)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T13:09:46+00:00



## Minister zdrowia o niechcianej ciąży: Natychmiast kupiłabym córce tabletkę
 - [https://deon.pl/swiat/minister-zdrowia-o-niechcianej-ciazy-natychmiast-kupilabym-corce-tabletke,2794112](https://deon.pl/swiat/minister-zdrowia-o-niechcianej-ciazy-natychmiast-kupilabym-corce-tabletke,2794112)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T12:23:01+00:00



## Kościół, co w politykę się miesza
 - [https://deon.pl/kosciol/komentarze/kosciol-co-w-polityke-sie-miesza,2794379](https://deon.pl/kosciol/komentarze/kosciol-co-w-polityke-sie-miesza,2794379)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T11:25:18+00:00



## Polski arcybiskup nuncjuszem apostolskim. Papież wybrał poliglotę
 - [https://deon.pl/kosciol/polski-arcybiskup-nuncjuszem-apostolskim-papiez-wybral-poliglote,2794352](https://deon.pl/kosciol/polski-arcybiskup-nuncjuszem-apostolskim-papiez-wybral-poliglote,2794352)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T11:06:27+00:00



## Prezydent Słowacji odwiedza Polskę. To jej wizyta pożegnalna
 - [https://deon.pl/swiat/prezydent-slowacji-odwiedza-polske-to-jej-wizyta-pozegnalna,2794091](https://deon.pl/swiat/prezydent-slowacji-odwiedza-polske-to-jej-wizyta-pozegnalna,2794091)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T10:04:52+00:00



## Okradli kościół, żeby zarobić na złomie. Wynieśli jeden cenny przedmiot
 - [https://deon.pl/kosciol/okradli-kosciol-zeby-zarobic-na-zlomie-wyniesli-jeden-cenny-przedmiot,2794232](https://deon.pl/kosciol/okradli-kosciol-zeby-zarobic-na-zlomie-wyniesli-jeden-cenny-przedmiot,2794232)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T08:19:41+00:00



## Polska powinna wesprzeć Izrael w konflikcie z Iranem? Tak mówi wiceminister MSZ
 - [https://deon.pl/swiat/polska-powinna-wesprzec-izrael-w-konflikcie-z-iranem-tak-mowi-wiceminister-msz,2794028](https://deon.pl/swiat/polska-powinna-wesprzec-izrael-w-konflikcie-z-iranem-tak-mowi-wiceminister-msz,2794028)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T07:49:04+00:00



## Nie wypadliśmy Mu z rąk. O Kościele w Polsce
 - [https://deon.pl/wiara/duchowosc/nie-wypadlismy-mu-z-rak-o-kosciele-w-polsce,2793920](https://deon.pl/wiara/duchowosc/nie-wypadlismy-mu-z-rak-o-kosciele-w-polsce,2793920)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T07:15:00+00:00



## 10 maja początek procesu beatyfikacyjnego Heleny Kmieć. Od tej pory będzie nazywana Służebnicą Bożą
 - [https://deon.pl/kosciol/10-maja-poczatek-procesu-beatyfikacyjnego-heleny-kmiec-od-tej-pory-bedzie-nazywana-sluzebnica-boza,2793983](https://deon.pl/kosciol/10-maja-poczatek-procesu-beatyfikacyjnego-heleny-kmiec-od-tej-pory-bedzie-nazywana-sluzebnica-boza,2793983)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T06:19:46+00:00



## Kiedy czujesz, że Bóg o Tobie nie pamięta, pomoże Ci ten psalm. Jest stworzony na takie chwile
 - [https://deon.pl/wiara/kiedy-czujesz-ze-bog-o-tobie-nie-pamieta-pomoze-ci-ten-psalm-jest-stworzony-na-takie-chwile,2793353](https://deon.pl/wiara/kiedy-czujesz-ze-bog-o-tobie-nie-pamieta-pomoze-ci-ten-psalm-jest-stworzony-na-takie-chwile,2793353)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T06:01:38+00:00



## Nie wypadliśmy Mu z rąk – o Kościele w Polsce | Podcast Dialogi w połowie drogi - odc. II/33 (51)
 - [https://deon.pl/podcast-dialogi-w-polowie-drogi/nie-wypadlismy-mu-z-rak--o-kosciele-w-polsce--podcast-dialogi-w-polowie-drogi---odc-ii33-51,2793890](https://deon.pl/podcast-dialogi-w-polowie-drogi/nie-wypadlismy-mu-z-rak--o-kosciele-w-polsce--podcast-dialogi-w-polowie-drogi---odc-ii33-51,2793890)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T06:00:00+00:00



## Możemy tworzyć więzi albo sieć uwikłań. To od nas zależy, co wybieramy
 - [https://deon.pl/wiara/mozemy-tworzyc-wiezi-albo-siec-uwiklan-to-od-nas-zalezy-co-wybieramy,2793950](https://deon.pl/wiara/mozemy-tworzyc-wiezi-albo-siec-uwiklan-to-od-nas-zalezy-co-wybieramy,2793950)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-04-16T05:10:36+00:00



