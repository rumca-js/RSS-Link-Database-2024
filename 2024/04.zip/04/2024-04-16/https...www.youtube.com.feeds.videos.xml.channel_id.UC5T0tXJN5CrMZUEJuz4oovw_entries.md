# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## Civil War: More Like Civil BORE!
 - [https://www.youtube.com/watch?v=vARZ0GwWk_w](https://www.youtube.com/watch?v=vARZ0GwWk_w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2024-04-16T19:41:51+00:00

A speculative fiction film about a modern American Civil War where the hardest thing to believe was journalists as heroes.
#hollywood 
Edited by @PierryChan and @QTRBlackGarrett 

Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Subscribe to the Nerdrotic Network: @nerdrotic @NerdroticLive @NerdroticDaily

## The Real BBC with MauLer and HeelvsBabyface
 - [https://www.youtube.com/watch?v=wX7tfWrKFHk](https://www.youtube.com/watch?v=wX7tfWrKFHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2024-04-16T14:55:59+00:00

Welcome to Bagging, Boarding, and Chatting. The Comic Book Show with Gary from @nerdrotic, Az from @HeelvsBabyface & @MauLerYT 

#Hollywood #Disney #marvel 

Produced by @XrayGirl_ from @pourchoices_ 

Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Streamlab Donations: https://streamlabs.com/sutrowatchtower/tip

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsored by MetaPCs!
https://www.metapcs.com/creator-nerdrotic/

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/collections/nerdrotic-coffee

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/nerdrotic-mug?

