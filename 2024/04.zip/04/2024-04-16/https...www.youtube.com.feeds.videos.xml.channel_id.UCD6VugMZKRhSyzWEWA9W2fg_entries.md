# Source:SssethTzeentach, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg, language:en-US

## Songs of Syx Review | Deranged Edition™
 - [https://www.youtube.com/watch?v=oucHl9NM97g](https://www.youtube.com/watch?v=oucHl9NM97g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD6VugMZKRhSyzWEWA9W2fg
 - date published: 2024-04-16T17:00:07+00:00

Use my link https://displate.com/ssethtzeentach (the discount is applied automatically) or use my code SSETH 
to get up to 33% off your Displate order.

STEAM: https://store.steampowered.com/app/1162750/Songs_of_Syx/
20% off April 16th - April 23rd (We could only get a week sale)
GOG: https://af.gog.com/redeem/OILEDUPTHUG?as=1630110786
25% off April 16th - May 1st

-----------------------
Send Sseth Shekels: https://www.paypal.me/SsethTzeentachGB
Send Sseth Shekels per video:  https://www.patreon.com/Sseth
Send Sseth Shekels / crypto: https://www.subscribestar.com/ssethtzeentach

Website: https://www.ssethtzeentach.com/
Twitter: https://twitter.com/SsethTzeentach
FB: https://www.facebook.com/sseth672/

