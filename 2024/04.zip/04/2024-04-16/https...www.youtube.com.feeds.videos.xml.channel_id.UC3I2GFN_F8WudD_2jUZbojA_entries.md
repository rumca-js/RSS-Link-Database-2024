# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Mick Jenkins - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=8_fNS-vLU5U](https://www.youtube.com/watch?v=8_fNS-vLU5U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-04-16T15:00:08+00:00

http://KEXP.ORG presents Mick Jenkins performing live in the KEXP studio. Recorded February 12, 2024.

Songs:
Michelin Star
ROY G.  BIV
Mop
"2011"

Mick Jenkins - Vocals
Sllime64 - DJ
Manoah Hyppolite - Drums

Host: Larry Myzell, Jr.
Audio Engineer: Kevin Suggs
Mastering Engineer: Ian Davidson

Cameras: Jim Beckmann, Carlos Cruz, Jonathan Jacobson, Scott Holpainen
Editor: Carlos Cruz 

https://mickjenkins.co
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Mick Jenkins - ROY G  BIV (Live on KEXP)
 - [https://www.youtube.com/watch?v=ns0Yp2qdLuI](https://www.youtube.com/watch?v=ns0Yp2qdLuI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-04-16T11:00:44+00:00

http://KEXP.ORG presents Mick Jenkins performing “ROY G  BIV” live in the KEXP studio. Recorded February 12, 2024.

Mick Jenkins - Vocals
Sllime64 - DJ
Manoah Hyppolite - Drums

Host: Larry Myzell, Jr.
Audio Engineer: Kevin Suggs
Mastering Engineer: Ian Davidson

Cameras: Jim Beckmann, Carlos Cruz, Jonathan Jacobson, Scott Holpainen
Editor: Carlos Cruz 

https://mickjenkins.co
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Mick Jenkins - Mop (Live on KEXP)
 - [https://www.youtube.com/watch?v=_ydHSkCCJnc](https://www.youtube.com/watch?v=_ydHSkCCJnc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-04-16T11:00:27+00:00

http://KEXP.ORG presents Mick Jenkins performing “Mop” live in the KEXP studio. Recorded February 12, 2024.

Mick Jenkins - Vocals
Sllime64 - DJ
Manoah Hyppolite - Drums

Host: Larry Myzell, Jr.
Audio Engineer: Kevin Suggs
Mastering Engineer: Ian Davidson

Cameras: Jim Beckmann, Carlos Cruz, Jonathan Jacobson, Scott Holpainen
Editor: Carlos Cruz 

https://mickjenkins.co
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Mick Jenkins - Michelin Star (Live on KEXP)
 - [https://www.youtube.com/watch?v=CmdXamgl3aQ](https://www.youtube.com/watch?v=CmdXamgl3aQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-04-16T11:00:09+00:00

http://KEXP.ORG presents Mick Jenkins performing "Michelin Star"  live in the KEXP studio. Recorded February 12, 2024.

Mick Jenkins - Vocals
Sllime64 - DJ
Manoah Hyppolite - Drums

Host: Larry Myzell, Jr.
Audio Engineer: Kevin Suggs
Mastering Engineer: Ian Davidson

Cameras: Jim Beckmann, Carlos Cruz, Jonathan Jacobson, Scott Holpainen
Editor: Carlos Cruz 

https://mickjenkins.co
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Mick Jenkins - " 2011" (Live on KEXP)
 - [https://www.youtube.com/watch?v=4cPCkUUF5v4](https://www.youtube.com/watch?v=4cPCkUUF5v4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-04-16T11:00:03+00:00

http://KEXP.ORG presents Mick Jenkins performing “2011” live in the KEXP studio. Recorded February 12, 2024.

Mick Jenkins - Vocals
Sllime64 - DJ
Manoah Hyppolite - Drums

Host: Larry Myzell, Jr.
Audio Engineer: Kevin Suggs
Mastering Engineer: Ian Davidson

Cameras: Jim Beckmann, Carlos Cruz, Jonathan Jacobson, Scott Holpainen
Editor: Carlos Cruz 

https://mickjenkins.co
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

