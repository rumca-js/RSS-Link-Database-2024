# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## These Protestors Deserve A Century In Prison
 - [https://www.youtube.com/watch?v=G6-xDFlFSfQ](https://www.youtube.com/watch?v=G6-xDFlFSfQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-04-16T21:30:01+00:00

ExpressVPN - Get 3 Months FREE of ExpressVPN at http://www.ExpressVPN.com/Walsh

Yesterday pro-Hamas demonstrators shut down major highways and bridges across the country. These aren't protests. They're acts of terrorism.

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1348 - https://bit.ly/3U48Spc 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Does This Body Cam Footage Prove This State Trooper's Innocence?
 - [https://www.youtube.com/watch?v=2BgEVIZbaTw](https://www.youtube.com/watch?v=2BgEVIZbaTw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-04-16T18:00:01+00:00

Regina Caeli Academy - Join me at the Courage Under Fire Gala! Use code DAILYWIRE for exclusive access to your tickets at http://www.courageunderfiregala.org 

A state trooper in New York was acquitted of manslaughter charges after shooting an unarmed subject who engaged in a high speed car chase. 

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1347 - https://bit.ly/3vHx0pS 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Would a jury of peers be less painful for these petty claims? Absolutely.
 - [https://www.youtube.com/watch?v=vw_ciD5JVlE](https://www.youtube.com/watch?v=vw_ciD5JVlE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-04-16T17:30:07+00:00

Tune in tonight to watch episode 3 of my new show "JUDGED by Matt Walsh" at 8 pm ET only on @dailywireplus.

## Am I now the preeminent legal authority in the world? No question.
 - [https://www.youtube.com/watch?v=X4utrMIKaiA](https://www.youtube.com/watch?v=X4utrMIKaiA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-04-16T15:30:17+00:00

Watch my new show “JUDGED by Matt Walsh” on @DailyWirePlus

## Is There A Civil War In Our Near Future?
 - [https://www.youtube.com/watch?v=6gnYlw9hOhA](https://www.youtube.com/watch?v=6gnYlw9hOhA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-04-16T00:30:03+00:00

PreBorn! - Help save babies from abortion: https://preborn.com/Matt 

Does A24's new hit film, Civil War, have anything to say about our current cultural climate? 

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1347 - https://bit.ly/3vHx0pS 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

