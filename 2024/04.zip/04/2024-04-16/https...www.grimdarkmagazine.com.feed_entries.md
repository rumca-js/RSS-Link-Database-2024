# Source:Grimdark Magazine, URL:https://www.grimdarkmagazine.com/feed, language:en-AU

## REVIEW: The Last Phi Hunter by Salinee Goldenberg
 - [https://www.grimdarkmagazine.com/review-the-last-phi-hunter-by-salinee-goldenberg](https://www.grimdarkmagazine.com/review-the-last-phi-hunter-by-salinee-goldenberg)
 - RSS feed: https://www.grimdarkmagazine.com/feed
 - date published: 2024-04-16T04:25:49+00:00

<p>Wildly entertaining, The Last Phi Hunter is Salinee Goldenberg’s Thai-inspired debut fantasy. The story follows Ex, the youngest member of the Phi Hunters Order, who is set out on the road to glory in hopes to slay the infamous Shar-Ala, a demon of nightmares. His journey is abruptly interrupted when he becomes an unwitting escort for a pregnant runaway who desperately needs to get through a spirit-infested forest. On this journey, the two become entangled in a complicated web of demons, assassins, and nefarious political schemes. Goldenberg’s writing is vibrant and refreshing, balancing the humour of her characters with the darkness of the lore, which provides readers with a truly engrossing experience. The story is gory and visceral in its descriptions, whilst also charming and humorous, perfect for fans who enjoy their grimdark books with a certain aspect of lightness to it. Goldenberg’s characters are brilliant. The narrative in The Last Phi Hunter is told through multiple poin

