# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## This ZSH Plugin Manager Is Really SUS
 - [https://www.youtube.com/watch?v=pHVbjLTFmVo](https://www.youtube.com/watch?v=pHVbjLTFmVo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2024-04-16T21:00:22+00:00

I don't know if there is actually anything malicious about this project but after digging into the zsh plugin manager zi it does look a little bit sus and maube it's best to avoid it.

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Dylan Nugent Thread: https://recurse.social/@dylnuge/112224580867240812
Zdharma Vanishes: https://www.reddit.com/r/zsh/comments/qinb6j/httpsgithubcomzdharma_has_suddenly_disappeared_i/
Zinit Continuum: https://github.com/zdharma-continuum/zinit
Z-shell Website: https://wiki.zshell.dev/

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson.xyz/discord
🐦 Twitter: 

