# Source:Eli the Computer Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ, language:en-US

## Silicon Dojo TEST yet again
 - [https://www.youtube.com/watch?v=-L9oOLOK-vs](https://www.youtube.com/watch?v=-L9oOLOK-vs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ
 - date published: 2024-04-16T18:24:50+00:00



## Silicon Dojo TEST again
 - [https://www.youtube.com/watch?v=veKOGTmzR8w](https://www.youtube.com/watch?v=veKOGTmzR8w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ
 - date published: 2024-04-16T18:11:40+00:00



## Silicon Dojo TEST
 - [https://www.youtube.com/watch?v=dcyWOQBmXJE](https://www.youtube.com/watch?v=dcyWOQBmXJE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ
 - date published: 2024-04-16T17:44:11+00:00



