# Source:Colombia News | Colombia Reports, URL:https://colombiareports.com/feed, language:en-US

## Colombia says EMC guerrilla leader abandoned peace talks
 - [https://colombiareports.com/colombia-says-emc-guerrilla-leader-abandoned-peace-talks](https://colombiareports.com/colombia-says-emc-guerrilla-leader-abandoned-peace-talks)
 - RSS feed: https://colombiareports.com/feed
 - date published: 2024-04-16T18:59:08+00:00

<p>The founder and supreme commander of guerrilla group EMC has abandoned peace talks, according to the lead negotiator of Colombia&#8217;s government. In a statement, government negotiator Camilo Gonzalez said that&#8230;</p>
<p>The post <a href="https://colombiareports.com/colombia-says-emc-guerrilla-leader-abandoned-peace-talks/">Colombia says EMC guerrilla leader abandoned peace talks</a> appeared first on <a href="https://colombiareports.com">Colombia News | Colombia Reports</a>.</p>

## Terror on Colombia-Venezuela border after assassination of anti-corruption activist
 - [https://colombiareports.com/terror-on-colombia-venezuela-border-after-assassination-of-anti-corruption-activist](https://colombiareports.com/terror-on-colombia-venezuela-border-after-assassination-of-anti-corruption-activist)
 - RSS feed: https://colombiareports.com/feed
 - date published: 2024-04-16T16:34:43+00:00

<p>The assassination of Cucuta&#8217;s citizen ombudsman again put the spotlight on the corrupt political elite in the largest city on Colombia&#8217;s border with Venezuela. An assassin took the life of&#8230;</p>
<p>The post <a href="https://colombiareports.com/terror-on-colombia-venezuela-border-after-assassination-of-anti-corruption-activist/">Terror on Colombia-Venezuela border after assassination of anti-corruption activist</a> appeared first on <a href="https://colombiareports.com">Colombia News | Colombia Reports</a>.</p>

