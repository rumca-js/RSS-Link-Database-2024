# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Factory Striders Do Exist In Helldivers 2
 - [https://www.youtube.com/watch?v=j9Qj6KcywrQ](https://www.youtube.com/watch?v=j9Qj6KcywrQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-04-16T22:36:34+00:00

Here’s how to find Factory Striders. If you couldn’t find them before as of today Factory Striders are showing up in larger numbers in Helldivers 2. We spotted them in Eradication Missions and a Destroy Automaton Fabricators mission. If you still can’t find one, it looks like Eliminate Factory Strider's mission will be in the game. To take down one of these AT-AT-looking fellas use two 500 kg bombs or two 110mm rocket runs. You can blast off individual cannons and turrets to de-fang this beast.

#helldivers2 #gaming #gamespot

## It's Time To Remake Fallout 1 & 2
 - [https://www.youtube.com/watch?v=sNV3owlTE8E](https://www.youtube.com/watch?v=sNV3owlTE8E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-04-16T14:00:39+00:00

With Fallout 5 still years away and recent success of its television adaption, as well as game's Like Baldur's Gate 3, Jean-Luc thinks it's time to bring back the beloved classics that started the Fallout franchise.

#fallout #fallout2 #bethesda

