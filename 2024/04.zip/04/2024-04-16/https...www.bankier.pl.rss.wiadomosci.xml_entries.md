# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Dow Jones przerwał spadkową serię. Powell tonuje oczekiwania inwestorów
 - [https://www.bankier.pl/wiadomosc/Dow-Jones-przerwal-spadkowa-serie-S-P500-i-Nasdaq-znow-pod-kreska-8729993.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dow-Jones-przerwal-spadkowa-serie-S-P500-i-Nasdaq-znow-pod-kreska-8729993.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/c/6b41e0444bb6ed-948-568-204-399-3888-2333.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Giełdowym bykom nie pomógł Jerome Powell. Szef Rezerwy Federalnej
powiedział, że obniżki stóp procentowych zostaną opóźnione.</p>

## Będzie nowa maksymalna cena energii dla gospodarstw domowych. Projekt ustawy o bonie energetycznym
 - [https://www.bankier.pl/wiadomosc/Bedzie-nowa-maksymalna-cena-energii-dla-gospodarstw-domowych-Projekt-ustawy-o-bonie-energetycznym-8729944.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bedzie-nowa-maksymalna-cena-energii-dla-gospodarstw-domowych-Projekt-ustawy-o-bonie-energetycznym-8729944.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T18:09:09.579081+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/72c8f400c59dfb-948-568-0-0-1765-1059.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W projektowanej ustawie o bonie energetycznym mają się znaleźć przepisy, na mocy których w II połowie 2024 r. będzie obowiązywać maksymalna cena energii elektrycznej dla gospodarstw w wysokości 500 zł za MWh – wynika z opublikowanej we wtorek informacji z Wykazu prac programowych i legislacyjnych Rady Ministrów.</p>

## Kto był podsłuchiwany przez Pegasusa? Bodnar: To inwigilowani będą decydować o upublicznieniu ich nazwisk
 - [https://www.bankier.pl/wiadomosc/Kto-byl-podsluchiwany-przez-Pegasusa-Bodnar-To-inwigilowani-beda-decydowac-o-upublicznieniu-ich-nazwisk-8729929.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kto-byl-podsluchiwany-przez-Pegasusa-Bodnar-To-inwigilowani-beda-decydowac-o-upublicznieniu-ich-nazwisk-8729929.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T18:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/f1cf0cf24242d1-948-568-0-140-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Minister sprawiedliwości Adam Bodnar powiedział we wtorek w Kielcach, że to osoby inwigilowane przy użyciu systemu Pegasus będą decydować o upublicznieniu ich nazwisk. Dodał, że raport w tej sprawie zostanie przedstawiony prawdopodobnie na najbliższym posiedzeniu Sejmu.</p>

## Minister cyfryzacji: Jesteśmy na cybernetycznej zimnej wojnie
 - [https://www.bankier.pl/wiadomosc/Minister-cyfryzacji-Jestesmy-na-cybernetycznej-zimnej-wojnie-8729904.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-cyfryzacji-Jestesmy-na-cybernetycznej-zimnej-wojnie-8729904.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T17:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/1/d4d6b294234536-948-568-0-50-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jesteśmy na cybernetycznej zimnej wojnie; ataki kierowane są nie tylko z Rosji i Białorusi, ale i z państw przyjaznych Moskwie - podkreślił wicepremier, minister cyfryzacji Krzysztof Gawkowski. Zapowiedział przedstawienie projektu noweli ustawy o Krajowym Systemie Cyberbezpieczeństwa.</p>

## Pełczyńska-Nałęcz: Do końca roku możemy dostać maksymalnie 10 mld euro z KPO
 - [https://www.bankier.pl/wiadomosc/Pelczynska-Nalecz-Do-konca-roku-mozemy-dostac-maksymalnie-10-mld-euro-z-KPO-8729910.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pelczynska-Nalecz-Do-konca-roku-mozemy-dostac-maksymalnie-10-mld-euro-z-KPO-8729910.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T17:04:31.554604+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/c/df87b2094a1a0d-948-568-19-35-1540-924.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chcemy złożyć wnioski o kolejne płatności z KPO po wakacjach, żeby kolejne środki wpłynęły do końca tego roku. Możemy dostać maksimum 10 mld euro, ale będzie to zapewne mniej – powiedziała we wtorek minister funduszy i polityki regionalnej Katarzyna Pełczyńska-Nałęcz.</p>

## Finlandia szuka oszczędności. Rząd podnosi podatki, obniża emerytury i zasiłki
 - [https://www.bankier.pl/wiadomosc/Finlandia-szuka-oszczednosci-Rzad-podnosi-podatki-obniza-emerytury-i-zasilki-8729884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Finlandia-szuka-oszczednosci-Rzad-podnosi-podatki-obniza-emerytury-i-zasilki-8729884.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T16:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/5735cc205bc00e-948-568-0-30-3700-2220.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podstawowa stawka VAT zostanie podniesiona o 1,5 pkt proc., do 25,5 proc. Wyższe podatki zapłacą lepiej zarabiający i pobierający wyższe świadczenia emerytalne. Podniesiona zostanie także akcyza na papierosy i alkohol.  Wyżej opodatkowane będą także słodycze, napoje bezalkoholowe, jak również auta elektryczne i hybrydowe.</p>

## Rekordowy wzrost mocy instalacji wiatrowych na świecie w 2023 roku
 - [https://www.bankier.pl/wiadomosc/Rekordowy-wzrost-mocy-instalacji-wiatrowych-na-swiecie-w-2023-roku-8729882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rekordowy-wzrost-mocy-instalacji-wiatrowych-na-swiecie-w-2023-roku-8729882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T16:52:00+00:00

<p>W 2023 r. zwiększono moc instalacji w energetyce wiatrowej o 117 GW, co oznacza wzrost o 50 proc. w porównaniu z rokiem poprzednim –  wynika z opublikowanego we wtorek raportu Global Wind Energy Council (GWEC).</p>

## Promocja na 33. urodziny giełdy. Indeksy GPW mocno w dół, WIG20 najsłabszy w Europie
 - [https://www.bankier.pl/wiadomosc/Sesja-na-GPW-16-kwietnia-WIG20-najslabszym-indeksem-w-Europie-8729781.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sesja-na-GPW-16-kwietnia-WIG20-najslabszym-indeksem-w-Europie-8729781.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T16:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/e8737c9f15237a-948-568-50-300-3950-2369.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wtorkowa sesja na GPW, przypadająca na 33. rocznicę jej otwarcia, 
upłynęła pod znakiem głębszej korekty. WIG20 był tego dnia najsłabszym 
giełdowym indeksem w Europie, chociaż chmurne nastroje towarzyszyły 
inwestorom na całym świecie. Ich uwaga koncentrowała się na Bliskim 
Wschodzie.</p>

## Rząd chce wzrostu opłat pobieranych od operatorów telekomunikacyjnych
 - [https://www.bankier.pl/wiadomosc/Rzad-chce-wzrostu-oplat-pobieranych-od-operatorow-telekomunikacyjnych-8729843.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-chce-wzrostu-oplat-pobieranych-od-operatorow-telekomunikacyjnych-8729843.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T16:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/1/a5c594d80a79b2-933-560-0-2-933-560.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Konsultacje społeczne projektu ustawy Prawo Komunikacji Elektronicznej mają przede wszystkim wypracować optymalne zmiany opłat pobieranych od operatorów telekomunikacyjnych - poinformowało ministerstwo we wtorkowej informacji prasowej. Podkreśliło, że opłaty te nie były zmieniane od wielu lat.</p>

## Pożar strawił Starą Giełdę w Danii. "Straty są ogromne. To narodowa tragedia"
 - [https://www.bankier.pl/wiadomosc/Pozar-strawil-Stara-Gielde-w-Danii-Straty-sa-ogromne-To-narodowa-tragedia-8729842.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pozar-strawil-Stara-Gielde-w-Danii-Straty-sa-ogromne-To-narodowa-tragedia-8729842.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T15:48:43.973291+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/078f8ec262d925-948-568-0-416-3264-1958.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zniszczony we wtorek przez pożar gmach Starej Giełdy Papierów Wartościowych w stylu romantyzmu holenderskiego nazywany był kopenhaską katedrą Notre Dame. Zabytek z 1625 roku stracił charakterystyczną wieżę z iglicą w kształcie wijących się ogonów czterech smoków - element panoramy miasta.</p>

## Szumowski przed komisją śledzczą: nie rekomendowałem przeprowadzenia wyborów korespondencyjnych
 - [https://www.bankier.pl/wiadomosc/Szumowski-przed-komisja-sledzcza-nie-rekomendowalem-przeprowadzenia-wyborow-korespondencyjnych-8729827.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szumowski-przed-komisja-sledzcza-nie-rekomendowalem-przeprowadzenia-wyborow-korespondencyjnych-8729827.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T15:48:43.937911+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/80863c47afec88-948-568-0-266-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były minister zdrowia Łukasz Szumowski zeznał przed komisją śledczą, że nie rekomendował przeprowadzenia wyborów korespondencyjnych 10 maja 2020 r. Rekomendowałem przesunięcie wyborów prezydenckich o dwa lata - podkreślił Szumowski.</p>

## Zabraknie pieniędzy na "Czyste powietrze"? "Reformy programu są potrzebne od zaraz"
 - [https://www.bankier.pl/wiadomosc/Zabraknie-pieniedzy-na-Czyste-powietrze-Reformy-programu-sa-potrzebna-od-zaraz-8729828.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zabraknie-pieniedzy-na-Czyste-powietrze-Reformy-programu-sa-potrzebna-od-zaraz-8729828.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T15:48:43.875149+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/5/ec4b8b8b40b9e1-948-568-0-37-1819-1091.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Andrzej Guła z Polskiego Alarmu Smogowego (PAS) ocenił, że za 1,5 roku mogą się skończyć pieniądze na program "Czyste Powietrze". Dodał, że konieczne jest m.in. uruchomienie środków na ten cel m.in. z ETS. PAS opublikował też ranking gmin "Czystego Powietrza". Najaktywniejszymi samorządami są Rybnik i Radlin.</p>

## Tusk: Ewentualne zwycięstwo Trumpa w USA byłoby niekorzystne
 - [https://www.bankier.pl/wiadomosc/Tusk-Ewentualne-zwyciestwo-Trumpa-w-USA-byloby-niekorzystne-8729752.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tusk-Ewentualne-zwyciestwo-Trumpa-w-USA-byloby-niekorzystne-8729752.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T14:43:50.315810+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/9bf0563d7353ab-945-560-0-67-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Polsce prawie wszyscy rozumiemy, że z punktu widzenia bezpieczeństwa Polski, Europy i przyszłości NATO ewentualne zwycięstwo Donalda Trumpa w wyborach prezydenckich w USA byłoby prawdopodobnie z niekorzyścią dla tych spraw - ocenił we wtorek premier Donald Tusk.</p>

## Francuskie Ministerstwo Finansów szuka 20 mld euro oszczędności
 - [https://www.bankier.pl/wiadomosc/Francuskie-Ministerstwo-Finansow-szuka-20-mld-euro-oszczednosci-8729760.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Francuskie-Ministerstwo-Finansow-szuka-20-mld-euro-oszczednosci-8729760.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T14:43:50.289554+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/8/68cef303d16232-945-560-0-103-1730-1037.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Francuskie ministerstwo finansów szuka cięć, by znaleźć 20 mld euro niezbędnych do zapanowania nad budżetem - pisze we wtorek dziennik "Le Figaro". Trudnością jest kampania przed wyborami do Parlamentu Europejskiego, w czasie której politycy unikają "irytujących" tematów.</p>

## Premier Tusk: Skala nieprawidłowości w Orlenie jest uderzająca. Spółką rządzili specjaliści od brudnych interesów
 - [https://www.bankier.pl/wiadomosc/Premier-Tusk-Skala-nieprawidlowosci-w-Orlenie-jest-uderzajaca-Spolka-rzadzili-specjalisci-od-brudnych-interesow-8729772.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-Tusk-Skala-nieprawidlowosci-w-Orlenie-jest-uderzajaca-Spolka-rzadzili-specjalisci-od-brudnych-interesow-8729772.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T14:43:50.230519+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/d/06be89c031e89f-948-568-0-195-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skala nieprawidłowości w Orlenie jest uderzająca; firmą tą rządzili ludzie, którzy przejdą do historii jako specjaliści od brudnych interesów - powiedział podczas wtorkowej konferencji prasowej premier Donald Tusk.</p>

## Wojna w Ukrainie. Co najmniej 37 000 osób zaginęło w trakcie rosyjskiej inwazji
 - [https://www.bankier.pl/wiadomosc/Wojna-w-Ukrainie-Co-najmniej-37-000-osob-zaginelo-w-trakcie-rosyjskiej-inwazji-8729725.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wojna-w-Ukrainie-Co-najmniej-37-000-osob-zaginelo-w-trakcie-rosyjskiej-inwazji-8729725.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T13:38:26.198137+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/9e33729776c11b-948-568-0-89-1280-767.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Co najmniej 37 000 Ukraińców jest uważanych za zaginionych w wyniku rosyjskiej inwazji na pełną skalę - poinformował we wtorek ukraiński rzecznik ds. praw człowieka Dmytro Łubiniec. Liczba ta obejmuje zarówno cywilów, jak i żołnierzy.</p>

## Kamiński o użyciu Pegasusa: wszystkie wnioski były realizowane za zgodą sądu
 - [https://www.bankier.pl/wiadomosc/Kaminski-o-uzyciu-Pegasusa-wszystkie-wnioski-byly-realizowane-za-zgoda-sadu-8729712.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaminski-o-uzyciu-Pegasusa-wszystkie-wnioski-byly-realizowane-za-zgoda-sadu-8729712.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T13:38:26.173706+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/6/427659806ad3a5-945-560-33-11-1466-879.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wszystkie wnioski były realizowane za zgodą sądu - zapewnił we wtorek były szef MSWiA Mariusz Kamiński, pytany o informacje, że kontrola operacyjna przy użyciu Pegasusa w latach 2017-2022 objęła ponad 500 osób.</p>

## MFW podwyższył prognozę dynamiki PKB Polski
 - [https://www.bankier.pl/wiadomosc/MFW-podwyzszyl-prognoze-dynamiki-PKB-Polski-8729719.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MFW-podwyzszyl-prognoze-dynamiki-PKB-Polski-8729719.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T13:38:26.152778+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/5cb305ed39c1c4-948-568-0-97-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Międzynarodowy Fundusz Walutowy podwyższył prognozę dynamiki PKB Polski w 2024 r. do 3,1 proc. z 2,8 proc., a w 2025 r. do 3,5 proc. z 3,2 proc. - wynika z najnowszej wersji cyklicznego raportu MFW World Economic Outlook.</p>

## Ukraina cierpi na niedobór żołnierzy. Prezydent Zełenski podpisał nową ustawę o mobilizacji
 - [https://www.bankier.pl/wiadomosc/Ukraina-cierpi-na-niedobor-zolnierzy-Prezydent-Zelenski-podpisal-nowa-ustawe-o-mobilizacji-8729739.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-cierpi-na-niedobor-zolnierzy-Prezydent-Zelenski-podpisal-nowa-ustawe-o-mobilizacji-8729739.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T13:38:26.131449+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/625a1ffe2ca7c7-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Ukrainy Wołodymyr Zełenski podpisał we wtorek nową ustawę o mobilizacji, przyjętą 11 kwietnia br. przez ukraińską Radę Najwyższą (parlament) - podała strona internetowa Rady.</p>

## Premier Tusk: Będziemy współpracować przy projekcie European Sky Shield
 - [https://www.bankier.pl/wiadomosc/Premier-Tusk-Bedziemy-wspolpracowac-przy-projekcie-European-Sky-Shield-8729706.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-Tusk-Bedziemy-wspolpracowac-przy-projekcie-European-Sky-Shield-8729706.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T13:38:26.110352+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/e5358aa4bafe5b-948-568-0-0-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska będzie chciała wykorzystać wszystkie okazje, aby nabywać środki strzegące nieba nad Polską - poinformował  premier Donald Tusk na briefingu.</p>

## Wielomiliardowe przejęcie na rynku opakowań. Giganci mają fabryki także w Polsce
 - [https://www.bankier.pl/wiadomosc/Ogromne-przejecie-International-Paper-i-DS-Smith-na-rynku-opakowan-Giganci-maja-fabryki-takze-w-Polsce-8729723.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ogromne-przejecie-International-Paper-i-DS-Smith-na-rynku-opakowan-Giganci-maja-fabryki-takze-w-Polsce-8729723.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T13:38:26.024278+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/d/8d867419e368fe-948-568-2-22-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brytyjski producent opakowań DS Smith połączy się z amerykańskim konkurentem International Paper. Transakcja została ogłoszona we wtorek, 16 kwietnia, i ma opiewać na blisko 6 mld funtów. Obie firmy mają zakłady produkcyjne i biura w Polsce.</p>

## Polacy słono zapłacą za system kaucyjny? Branża apeluje do premiera Tuska
 - [https://www.bankier.pl/wiadomosc/Polacy-slono-zaplaca-za-system-kaucyjny-Branza-apeluje-do-premiera-Tuska-8729694.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-slono-zaplaca-za-system-kaucyjny-Branza-apeluje-do-premiera-Tuska-8729694.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T13:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/8aa37fa44b70fd-945-567-0-34-1710-1026.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Bez uszczelnienia przepisów dot. systemu kaucyjnego ceny napojów mogą wzrosnąć, zapłacimy też dodatkowy VAT od kaucji - wskazują organizacje z branży napojów i handlu w apelu do premiera Donalda Tuska. Domagają się m.in. przesunięcia o rok startu polskiego sytemu kaucyjnego.</p>

## NIK: urzędy niedostatecznie dbają o osoby z niepełnosprawnościami
 - [https://www.bankier.pl/wiadomosc/NIK-urzedy-niedostatecznie-dbaja-o-osoby-z-niepelnosprawnosciami-8729689.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NIK-urzedy-niedostatecznie-dbaja-o-osoby-z-niepelnosprawnosciami-8729689.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T13:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/0eb1219e72ff31-948-568-0-86-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najwyższa Izba Kontroli poinformowała we wtorek, że kontrola wybranych jednostek samorządowych w woj. kujawsko-pomorskim wykazała, że niedostatecznie dbają one o osoby z niepełnosprawnościami. Brakuje dla nich m.in łazienek, a na stronach internetowych informacji odczytywanych maszynowo.</p>

## Kamiński i Wąsik wezwani do prokuratury ws. głosowania w Sejmie
 - [https://www.bankier.pl/wiadomosc/Kaminski-i-Wasik-wezwani-do-prokuratury-ws-glosowania-w-Sejmie-8729677.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaminski-i-Wasik-wezwani-do-prokuratury-ws-glosowania-w-Sejmie-8729677.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T12:33:13.081417+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/b/2a4ee0d4266fb1-948-568-0-0-3457-2074.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były szef MSWiA Mariusz Kamiński przekazał we wtorek, że razem z Maciejem Wąsikiem otrzymali wezwanie do prokuratury na najbliższy czwartek. Według Kamińskiego ma im zostać postawiony zarzut nielegalnego udziału w głosowaniach w Sejmie.</p>

## Inflacja bazowa szybko spada, ale wciąż przekracza cel NBP
 - [https://www.bankier.pl/wiadomosc/Inflacja-bazowa-w-marcu-2024-roku-nadal-szybko-spadala-8729664.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-bazowa-w-marcu-2024-roku-nadal-szybko-spadala-8729664.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T12:33:13.022959+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/8d94345fc52b29-948-568-0-0-2032-1219.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W marcu odnotowano dalszy spadek tzw. inflacji bazowej –
wynika z danych Narodowego Banku Polskiego.</p>

## Możesz dostać smartfon, jeśli weźmiesz kartę. Wiosenna promocja banku
 - [https://www.bankier.pl/wiadomosc/Citi-Handlowy-oferuje-smartfona-jesli-wezmiesz-karte-Promocja-Przywitaj-wiosne-z-Karta-Kredytowa-Citibank-8729477.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Citi-Handlowy-oferuje-smartfona-jesli-wezmiesz-karte-Promocja-Przywitaj-wiosne-z-Karta-Kredytowa-Citibank-8729477.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T12:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/3/a3f314887864b6-948-568-0-0-3167-1900.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Citi Handlowy ruszył z kolejną
promocją karty kredytowej Citi Simplicity. Za wyrobienie plastiku i 
aktywne korzystanie oferuje Samsunga Galaxy A15 i do 300 zł w punktach w
 programie
"Bezcenne Chwile". Poniżej omawiamy szczegóły promocji "Przywitaj wiosnę
 z Kartą
Kredytową Citibank".</p>

## Morawiecki: Wzywam Donalda Tuska, żeby zawetował pakt migracyjny
 - [https://www.bankier.pl/wiadomosc/Morawiecki-Wzywam-Donalda-Tuska-zeby-zawetowal-pakt-migracyjny-8729632.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Morawiecki-Wzywam-Donalda-Tuska-zeby-zawetowal-pakt-migracyjny-8729632.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T12:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/3/a9bfe5f690646e-948-568-0-0-2510-1505.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Premier Donald Tusk powinien w jak najostrzejszy sposób zawetować pakt migracyjny, ponieważ ma do tego podstawę prawną w postaci konkluzji Rady Europejskiej - powiedział we wtorek były premier RP Mateusz Morawiecki na konferencji prasowej w Parlamencie Europejskim w Brukseli.</p>

## Komisja ds. wyborów kopertowych. Skóra: Nikt nie przegrywał bazy PESEL z Ministerstwa Cyfryzacji
 - [https://www.bankier.pl/wiadomosc/Komisja-ds-wyborow-kopertowych-Skora-Nikt-nie-przegrywal-bazy-PESEL-z-Ministerstwa-Cyfryzacji-8729625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Komisja-ds-wyborow-kopertowych-Skora-Nikt-nie-przegrywal-bazy-PESEL-z-Ministerstwa-Cyfryzacji-8729625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T12:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/aeb8bd55e354f9-948-568-0-0-1897-1138.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nikt nie przegrywał bazy PESEL z Ministerstwa Cyfryzacji, baza ta została nam udostępniona; zgodnie z poleceniem mojego przełożonego osobiście odebrałem nośnik z danymi - zeznał przed komisją śledczą ds. wyborów korespondencyjnych Paweł Skóra, b. dyrektor Pionu Informatyki i Telekomunikacji Poczty Polskiej.</p>

## Interwencja ws. bonu energetycznego. PiS z kontrolą poselską w resorcie klimatu
 - [https://www.bankier.pl/wiadomosc/Interwencja-ws-bonu-energetycznego-PiS-z-kontrola-poselska-w-resorcie-klimatu-8729595.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Interwencja-ws-bonu-energetycznego-PiS-z-kontrola-poselska-w-resorcie-klimatu-8729595.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T11:28:23.282642+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/7/f6ded819aa23f2-948-568-0-169-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Posłowie PiS: Paweł Jabłoński i Paweł Sałek zapowiedzieli kontrolę poselską w resorcie klimatu i środowiska. Chcą interweniować m.in. ws. projektu dotyczącego bonu energetycznego.</p>

## Prokurator Generalny o Pegasusie w Polsce: kontrola objęła 578 osób
 - [https://www.bankier.pl/wiadomosc/Prokurator-Generalny-o-Pegasusie-w-Polsce-kontrola-objela-578-osob-8729591.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prokurator-Generalny-o-Pegasusie-w-Polsce-kontrola-objela-578-osob-8729591.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T11:28:23.215709+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/7/cafcfb3e97b725-937-562-40-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W latach 2017-2022 kontrola operacyjna przy użyciu Pegasusa objęła 578 osób - wynika z informacji Prokuratora Generalnego przesłanej do Sejmu i Senatu. Najwięcej osób było objętych taką kontrolą w 2021 roku - 162.</p>

## Biedronka wygrywa wojnę cenową w marcu, Lidl zdeklasowany
 - [https://www.bankier.pl/wiadomosc/Biedronka-najtansza-w-marcu-za-nia-Auchan-i-dopiero-Lidl-8729552.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biedronka-najtansza-w-marcu-za-nia-Auchan-i-dopiero-Lidl-8729552.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T11:28:23.130123+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/848e398af0e0f0-948-568-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najtańsza w marcu była sieć Biedronka, wyprzedziła Auchan - podała agencja badawcza ASM SFA.</p>

## Leszczyna: Będzie zawiadomienie do prokuratury ws. Cieszyńskiego
 - [https://www.bankier.pl/wiadomosc/Leszczyna-Bedzie-zawiadomienie-do-prokuratury-ws-Cieszynskiego-8729565.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Leszczyna-Bedzie-zawiadomienie-do-prokuratury-ws-Cieszynskiego-8729565.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T10:23:08.033815+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/848f420c785121-948-568-0-0-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Złożenie zawiadomienia do prokuratury ws. przekroczenia uprawnień przez b. wiceministra zdrowia Janusza Cieszyńskiego zapowiedziała minister zdrowia Izabela Leszczyna. Wypłacił wielomilionową zaliczkę na zakup respiratorów, wiedząc, że to jest niezgodne z ustawą o finansach publicznych - powiedziała.</p>

## Unijne sankcje na Iran? "Trzeba mieć coś, na co da się je nałożyć"
 - [https://www.bankier.pl/wiadomosc/Unijne-sankcje-na-Iran-Trzeba-miec-cos-na-co-da-sie-je-nalozyc-8729527.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Unijne-sankcje-na-Iran-Trzeba-miec-cos-na-co-da-sie-je-nalozyc-8729527.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T10:23:08.013891+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/044aef60b954db-948-568-0-130-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />By nałożyć sankcje na Iran, musimy znaleźć coś, co podlega sankcjom - powiedział we wtorek w wywiadzie dla "Le Monde" szef unijnej dyplomacji Josep Borrell. Tymczasem uznanie irańskiego Korpusu Strażników Rewolucji za organizację terrorystyczną wymaga wyroku sądu.</p>

## MSZ odradza podróże do Iranu. Możliwe problemy z opuszczeniem kraju
 - [https://www.bankier.pl/wiadomosc/MSZ-odradza-podroze-do-Iranu-Mozliwe-problemy-z-opuszczeniem-kraju-8729531.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MSZ-odradza-podroze-do-Iranu-Mozliwe-problemy-z-opuszczeniem-kraju-8729531.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T10:23:07.984241+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/1/d38bc044f504b9-945-560-0-61-3504-2102.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Resort spraw zagranicznych odradza wszelkie podróże do Iranu - przekazano we wtorek w komunikacie. Nie można wykluczyć, że dojdzie do kolejnego zawieszenia lub zamknięcia ruchu lotniczego, a tym samym problemów z opuszczeniem Iranu - podkreśla resort.</p>

## ZUS wstrzymał o ponad 33 proc. więcej zasiłków chorobowych
 - [https://www.bankier.pl/wiadomosc/ZUS-wstrzymal-o-ponad-33-proc-wiecej-zasilkow-chorobowych-8729551.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ZUS-wstrzymal-o-ponad-33-proc-wiecej-zasilkow-chorobowych-8729551.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T10:23:07.964134+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/b02c10488c728f-948-568-105-0-1808-1084.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jak wynika z
danych Zakładu Ubezpieczeń Społecznych, w ubiegłym roku kwota wstrzymanych
zasiłków chorobowych podskoczyła rok do roku o ponad 33 proc. Natomiast o
więcej niż 7 proc. zwiększyła się liczba kontroli osób przebywających na
zwolnieniach lekarskich.</p>

## Problem z transmisjami meczów PKO BP Ekstraklasy. Canal+ zmienił kanał
 - [https://www.bankier.pl/wiadomosc/Problem-z-transmisjami-meczow-PKO-BP-Ekstraklasy-Canal-zmienil-kanal-8729491.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Problem-z-transmisjami-meczow-PKO-BP-Ekstraklasy-Canal-zmienil-kanal-8729491.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T10:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/873b6aa7b7525b-948-568-0-4-1987-1192.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Część kibiców piłkarskich od kilku dni nie może śledzić rozgrywek PKO BP Ekstraklasy. Canal+ przeniósł większość meczów na antenę Canal+ Sport 3, która nie znajduje się w ofercie wielu operatorów sieci kablowych – informuje serwis „Wirtualne Media”.</p>

## Wydobycie magnezu wraca do Europy. Trwa zrywanie zależności od Chin
 - [https://www.bankier.pl/wiadomosc/Wydobycie-magnezu-wraca-do-Europy-Trwa-zrywanie-zaleznosci-od-Chin-8729478.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wydobycie-magnezu-wraca-do-Europy-Trwa-zrywanie-zaleznosci-od-Chin-8729478.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T10:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/cd9f908365edba-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 2027 roku do Europy wróci wygaszone ponad dekadę temu wydobycie magnezu, kluczowego dla produkcji aluminium - podaje Financial Times. Obecnie 95% dostaw tego surowca trafia do Unii Europejskiej z Chin.</p>

## Kolejny kamień milowy dla Polskiej Elektrowni Jądrowej
 - [https://www.bankier.pl/wiadomosc/Zatwierdzono-projekt-robot-geologicznych-dla-pomorskiej-elektrowni-jadrowej-8729506.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zatwierdzono-projekt-robot-geologicznych-dla-pomorskiej-elektrowni-jadrowej-8729506.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T10:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/b/b7ba073cc689c1-725-434-197-120-725-434.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo klimatu zatwierdziło spółce Polskie Elektrownie Jądrowe (PEJ) Projekt Robót Geologicznych dla elektrowni jądrowej na Pomorzu - poinformowały we wtorek PEJ. Umożliwia to rozpoczęcie pogłębionych badań geologicznych w lokalizacji pod elektrownię.</p>

## NIK planuje doraźną kontrolę w KNF. Chodzi m.in. o VeloBank
 - [https://www.bankier.pl/wiadomosc/NIK-planuje-dorazna-kontrole-w-KNF-Chodzi-m-in-o-VeloBank-8729501.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NIK-planuje-dorazna-kontrole-w-KNF-Chodzi-m-in-o-VeloBank-8729501.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T10:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/4c1ce1b7235374-948-568-0-258-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />NIK planuje doraźną kontrolę w KNF, przyglądać się będzie działaniom związanym m.in. z VeloBankiem - podała Izba w komunikacie.</p>

## Brytyjskie płace rosną najmocniej od 2,5 roku. Niestety rośnie też bezrobocie
 - [https://www.bankier.pl/wiadomosc/Brytyjskie-place-rosna-najmocniej-od-2-5-roku-Niestety-rosnie-tez-bezrobocie-8729493.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjskie-place-rosna-najmocniej-od-2-5-roku-Niestety-rosnie-tez-bezrobocie-8729493.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T09:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/9/21b1d5601a55a7-945-560-0-60-4800-2879.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Efektem spadającej inflacji w Wielkiej Brytanii jest najwyższy od ponad 2,5 roku wzrost realnych płac, które były w lutym o 2,4 proc. wyższe niż rok temu - podał we wtorek urząd statystyczny ONS. Gorszą wiadomością jest natomiast wyższy niż przewidywano wzrost bezrobocia.</p>

## Skromne zarobki nieadekwatne do odpowiedzialności. Greccy dziennikarze strajkuja
 - [https://www.bankier.pl/wiadomosc/Skromne-zarobki-nieadekwatne-do-odpowiedzialnosci-Greccy-dziennikarze-strajkuja-8729490.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skromne-zarobki-nieadekwatne-do-odpowiedzialnosci-Greccy-dziennikarze-strajkuja-8729490.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T09:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/037b08239f615b-945-560-0-108-1487-892.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dziennikarze w Grecji prowadzą we wtorek 24-godzinny strajk, domagając się lepszych warunków pracy - informuje portal eKathimerini. Strajkują m.in. pracownicy agencji informacyjnej AMNA.</p>

## Ceny materiałów budowlanych w marcu znów spadły
 - [https://www.bankier.pl/wiadomosc/Ceny-materialow-budowlanych-w-marcu-znow-spadly-8729481.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-materialow-budowlanych-w-marcu-znow-spadly-8729481.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T09:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/8f6314ea73afed-948-568-0-110-2464-1478.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny materiałów budowlanych oraz do domu i ogrodu w marcu spadły średnio o 3,0 proc. rdr, po spadku o 3,0 proc. miesiąc wcześniej - podały Polskie Składy Budowlane w komunikacie.</p>

## Mieszkańcy DPS-ów płacą dwukrotnie za opiekę zdrowotną. NFZ nie sfinansuje świadczeń
 - [https://www.bankier.pl/wiadomosc/Mieszkancy-DPS-ow-placa-dwukrotnie-za-opieke-zdrowotna-Zwiazek-Powiatow-Polskich-chce-finansowania-czesci-swiadczen-z-NFZ-u-8729386.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mieszkancy-DPS-ow-placa-dwukrotnie-za-opieke-zdrowotna-Zwiazek-Powiatow-Polskich-chce-finansowania-czesci-swiadczen-z-NFZ-u-8729386.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T09:18:07.377810+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/0/79ea2c8732a935-948-568-0-247-3665-2198.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Związek Powiatów Polski apeluje do Ministerstwa Zdrowia o zmianę sposobu finansowania kosztów świadczeń udzielanych w domach pomocy społecznej. Ich mieszkańcy płacą za nie podwójnie - w postaci składki na ubezpieczenie zdrowotne oraz w formie opłat za pobyt w DPS-ie.</p>

## Nowe dopłaty dla rolników. Szczególnie tych z małych gospodarstw
 - [https://www.bankier.pl/wiadomosc/Nowe-doplaty-dla-rolnikow-Szczegolnie-tych-z-malych-gospodarstw-8729441.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowe-doplaty-dla-rolnikow-Szczegolnie-tych-z-malych-gospodarstw-8729441.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T08:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/26f5b2fcc2e4aa-948-567-0-77-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do połowy roku rząd planuje przyjąć projekt zmiany ustawowej, wprowadzającej na lata 2023-2027 nowe formy wsparcia w ramach dopłat bezpośrednich dla rolników: nowy ekoschemat i płatności dla małych gospodarstw.</p>

## Zrezygnował z lukratywnego stanowiska. Partyjny kolega von der Leyen nie chce kontrowersji
 - [https://www.bankier.pl/wiadomosc/Zrezygnowal-z-lukratywnego-stanowiska-Partyjny-kolega-von-der-Leyen-nie-chce-kontrowersji-8729431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zrezygnowal-z-lukratywnego-stanowiska-Partyjny-kolega-von-der-Leyen-nie-chce-kontrowersji-8729431.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T08:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/f/872bbe7633a8c6-948-568-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Markus Pieper, kolega Ursuli von der Leyen z CDU, nie obejmie stanowiska pełnomocnika Komisji Europejskiej ds. małych i średnich przedsiębiorstw. Taką decyzję podjął on sam po kontrowersjach związanych z rekrutacją na to stanowisko.</p>

## Złoty słabnie trzecią sesję z rzędu. Kurs euro wrócił do 4,30 zł
 - [https://www.bankier.pl/wiadomosc/Zloty-slabnie-trzecia-sesje-z-rzedu-Kurs-euro-wrocil-do-4-30-zl-8729425.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zloty-slabnie-trzecia-sesje-z-rzedu-Kurs-euro-wrocil-do-4-30-zl-8729425.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T08:13:04.561431+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/81a860af55c1af-948-568-0-170-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro przekroczył poziom 4,30 zł, zwyżkując trzecią
sesję z rzędu. Dolar w zaledwie tydzień podrożał o 15 groszy.</p>

## Dalej kantują na składzie odzieży. UOKiK ukarał 2 firmy
 - [https://www.bankier.pl/wiadomosc/Dalej-kantuja-na-skladzie-odziezy-Lord-i-Lavard-z-kara-od-UOKiK-8729446.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dalej-kantuja-na-skladzie-odziezy-Lord-i-Lavard-z-kara-od-UOKiK-8729446.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T08:13:04.531399+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/458946d3fde718-948-568-0-22-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezes UOKiK Tomasz Chróstny nałożył kary na dwie firmy za wprowadzanie konsumentów w błąd przez podawanie nieprawdziwych informacji o składzie ubrań - podał we wtorek Urząd. Firma Lord ma zapłacić ponad 213 tys. zł, a Polskie Sklepy Odzieżowe (Lavard) - ponad 3,8 mln zł.</p>

## Fala fałszywych SMS-ów. Można stracić prawie 1300 zł
 - [https://www.bankier.pl/wiadomosc/Fala-falszywych-SMS-ow-Mozna-stracic-prawie-1300-zl-8729444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fala-falszywych-SMS-ow-Mozna-stracic-prawie-1300-zl-8729444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T08:13:04.511154+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/8/f350fe1540bf77-948-568-175-66-1607-964.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Osoby, które otrzymały SMS-y sugerujące, że zostały wpisane
do rejestru długów, powinny być ostrożne. Użytkowników telefonów komórkowych
zalała właśnie nowa fala fałszywych wiadomości, które łudząco przypominają
prawdziwe, ponieważ zawierają informacje znane tylko posiadaczom telefonów.
Nieopatrzne podanie swoich danych może się skończyć utratą niemałej kwoty.</p>

## Michelin kończy produkcję w Olsztynie. Pracownicy całego wydziału zostaną zwolnieni
 - [https://www.bankier.pl/wiadomosc/Michelin-konczy-produkcje-w-Olsztynie-Pracownicy-calego-wydzialu-zostana-zwolnieni-8729424.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Michelin-konczy-produkcje-w-Olsztynie-Pracownicy-calego-wydzialu-zostana-zwolnieni-8729424.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T08:13:04.476124+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/2/6484ff77c23db4-948-568-0-0-3074-1844.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kolejna fabryka w Polsce zostanie zlikwidowana, a produkcja przeniesiona do innego kraju. Michelin Polska zdecydował o zamknięciu zakładu produkującego opony ciężarowe w Olsztynie. Powodem są wysokie koszty produkcji.</p>

## Chińczycy trzymają się mocno? Pekin zadowolony z początku roku
 - [https://www.bankier.pl/wiadomosc/Chinczycy-trzymaja-sie-mocno-Pekin-zadowolony-z-poczatku-roku-8729426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chinczycy-trzymaja-sie-mocno-Pekin-zadowolony-z-poczatku-roku-8729426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T08:13:04.444603+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/d89b177e4b567c-945-560-0-87-4366-2619.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Druga największa gospodarka świata wzrosła w pierwszym kwartale 2024 r. mocniej niż oczekiwano. Jednak opublikowane dane w szczegółach okazują się dość niejednolite i dają inwestorom mieszany obraz co do kondycji chińskiego smoka.</p>

## Siemoniak: Pegasusem w Polsce inwigilowano ponad 500 osób
 - [https://www.bankier.pl/wiadomosc/Siemoniak-Pegasusem-w-Polsce-inwigilowano-ponad-500-osob-8729388.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Siemoniak-Pegasusem-w-Polsce-inwigilowano-ponad-500-osob-8729388.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T07:08:05.340865+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/cda178f5b8aa12-948-568-11-11-4488-2693.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 500 osób było inwigilowanych przy pomocy Pegasusa - poinformował we wtorek minister koordynator służb specjalnych Tomasz Siemoniak.</p>

## Iran wygrał starcie z Izraelem? Tel Awiw na obronę miał wydać 1 mld dolarów
 - [https://www.bankier.pl/wiadomosc/Iran-wygral-starcie-z-Izraelem-Tel-Awiw-na-obrone-mial-wydac-1-mld-dolarow-8729375.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Iran-wygral-starcie-z-Izraelem-Tel-Awiw-na-obrone-mial-wydac-1-mld-dolarow-8729375.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T07:08:05.264706+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/eb780e6fbeff74-948-568-0-75-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zestrzelenie setek dronów i rakiet manewrujących, lotnictwo i marynarka w najwyższej gotowości, piechota rozmieszczona razem z dywizjami zmechanizowanymi - to realia sobotniej nocy w Izraelu. O ataku Iran kanałami dyplomatycznymi poinformował już wcześniej. Armia więc musiała jedynie czekać i płacić. </p>

## Coraz trudniej skorzystać z ulgi podatkowej na jedno dziecko. Limity stoją od lat
 - [https://www.bankier.pl/wiadomosc/Coraz-trudniej-skorzystac-z-ulgi-podatkowej-na-jedno-dziecko-Limity-stoja-od-lat-8729364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-trudniej-skorzystac-z-ulgi-podatkowej-na-jedno-dziecko-Limity-stoja-od-lat-8729364.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T06:02:53.977658+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/d/679423d249d8b8-948-568-0-227-3497-2098.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rodzice jedynaków tracą podatkową ulgę, bo ich pensje rosną, a limit dochodów nie zmienia się od lat - pisze we wtorek „Rzeczpospolita”. Jak zaznacza gazeta, do limitu dochodów określonego w uldze zbliżają się już zarabiający pensję minimalną.</p>

## System kaucyjny jednak od 2026 roku? Pośpiech może wywołać problemy
 - [https://www.bankier.pl/wiadomosc/System-kaucyjny-jednak-od-2026-roku-Pospiech-moze-wywolac-problemy-8729343.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/System-kaucyjny-jednak-od-2026-roku-Pospiech-moze-wywolac-problemy-8729343.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T06:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/3ee8ffc08fc727-948-568-0-0-2338-1402.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />System kaucyjny w Polsce, zgodnie z ustawą, powinien zacząć działać od 2025 roku. To sposób na motywowanie konsumentów do zwrotu zużytych butelek i puszek, by zwiększyć poziom recyklingu. Zmniejszy...</p>

## Emerytura w wieku 67 lat? Ekspertka: To będzie standard dla obu płci
 - [https://www.bankier.pl/wiadomosc/Emerytura-w-wieku-67-lat-Ekspertka-To-bedzie-standard-dla-obu-plci-8729327.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Emerytura-w-wieku-67-lat-Ekspertka-To-bedzie-standard-dla-obu-plci-8729327.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T05:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/a1f5e424d376a6-948-568-0-144-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podwyższenie wieku emerytalnego jest niezbędne, żeby w dłuższej perspektywie utrzymać stabilny system ubezpieczeń społecznych. Standardem jest 67 lat dla obu płci - powiedziała PAP dyrektorka Instytutu Statystyki i Demografii SGH prof. Agnieszka Chłoń-Domińczak.</p>

## Mieszkańcy Argentyny jedzą coraz mniej wołowiny. "Ludzie nie mają pieniędzy"
 - [https://www.bankier.pl/wiadomosc/Mieszkancy-Argentyny-jedza-coraz-mniej-wolowiny-Ludzie-nie-maja-pieniedzy-8729323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mieszkancy-Argentyny-jedza-coraz-mniej-wolowiny-Ludzie-nie-maja-pieniedzy-8729323.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T05:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/de131837197015-945-560-0-191-4256-2553.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Argentyna słynie z produkcji wołowiny i zamiłowania do tego mięsa, ale w marcu jego spożycie spadło do "historycznie niskiego poziomu" – podał w poniedziałek dziennik "Clarin". Spadek wiązany jest z kryzysem gospodarczym i szalejącą inflacją.</p>

## Tylko kilka inwestycji dało zarobić. Większość notuje spore straty
 - [https://www.bankier.pl/wiadomosc/Zloto-i-akcje-XTB-daly-zarobic-Wiekszosc-inwestycji-gwiazd-notuje-spore-straty-w-tym-Bitcoin-i-Nvidia-8729255.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zloto-i-akcje-XTB-daly-zarobic-Wiekszosc-inwestycji-gwiazd-notuje-spore-straty-w-tym-Bitcoin-i-Nvidia-8729255.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T04:57:47.946106+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/d/d8da0020da26ec-948-568-0-0-1592-955.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W połowie miesiąca sprawdzamy, jak wyglądają wyniki w „Portfelu Gwiazd”. To inwestycyjne wskazania gości zaproszonych do edukacyjnego projektu przez Andrzeja Steca, redaktora naczelnego Bankier.pl. Kto zyskał, a kto, na czym wtopił najwięcej?</p>

## Inflacja odkryła karty, ale to dolar miał asa w rękawie
 - [https://www.bankier.pl/wiadomosc/Inflacja-odkryla-karty-ale-to-dolar-mial-asa-w-rekawie-8729112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-odkryla-karty-ale-to-dolar-mial-asa-w-rekawie-8729112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T04:57:47.877763+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/163dac1e6ea704-948-568-202-0-2675-1604.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowa fala odczytów inflacji naświetliła, w jakiej hierarchii najważniejsze banki centralne ustawią się w kolejce do obniżek. Przetasowania, które okazały się korzystne dla dolara, zostały dodatkowo spotęgowane przez wzrost napięcia geopolitycznego przed atakiem Iranu na Izrael. W rezultacie indeks dolarowy poszybował najwyżej od niemal pół roku.</p>

## Bez składek i wypłaty za L4. To m.in zyskują firmy zatrudniające więźniów
 - [https://www.bankier.pl/wiadomosc/Pracuja-dla-nich-wiezniowie-Tyle-zyskuja-na-ich-zatrudnieniu-8728845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pracuja-dla-nich-wiezniowie-Tyle-zyskuja-na-ich-zatrudnieniu-8728845.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T04:57:47.704035+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/bf7fa1599a8e1a-945-560-3-22-1496-897.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Służba
Więzienna od wielu lat współpracuje z podmiotami zewnętrznymi w zakresie
zatrudniania skazanych. Przedsiębiorstwa, które korzystają z ich pracy, zyskują
nie tylko siłę roboczą, o którą często trudno na wolnym rynku, ale też mogą
liczyć na wiele innych udogodnień.</p>

## Polacy zarabiający za granicą muszą rozliczyć PIT. Są dwie metody
 - [https://www.bankier.pl/wiadomosc/Jak-rozliczyc-dochody-z-zagranicy-w-PIT-Sa-dwie-metody-8725913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jak-rozliczyc-dochody-z-zagranicy-w-PIT-Sa-dwie-metody-8725913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T04:57:47.684353+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/5/95200d278d8ce3-948-568-0-12-1280-767.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pracowałeś za granicą lub otrzymałeś wpływy z tytułu posiadanych udziałów w spółkach z siedzibą poza Polską? Nie zapomnij ująć tych dochodów w rocznym rozliczeniu PIT za 2023 r. Ekspert podpowiada jak ustalić kwotę podatku.</p>

## Kiedy Polska dogoni Zachód? Według ZBP potrzeba na to dekad
 - [https://www.bankier.pl/wiadomosc/Kiedy-Polska-dogoni-Zachod-Potrzeba-na-to-30-lat-8728707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kiedy-Polska-dogoni-Zachod-Potrzeba-na-to-30-lat-8728707.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T04:57:47.665379+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/181261589c88d1-948-568-0-99-3990-2393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PKB per capita wg stanu na koniec 2023 r. w Polsce wyniosło 14,7 tys. EUR. Oznacza to niewielki wzrost r/r o 0,55%. Pozycjonuje to nas na 5. miejscu od końca. Polska gospodarka nadgania dystans w stosunku do krajów UE-27, choć do osiągnięcia średniego poziomu dla krajów UE-27 (28,94 tys. EUR) jest jeszcze bardzo daleko.</p>

## Najlepsze lokaty półroczne. Tu można trafić na najlepszą stawkę na rynku
 - [https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-6-miesiecy-kwiecien-2024-Ranking-Bankier-pl-8728780.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-6-miesiecy-kwiecien-2024-Ranking-Bankier-pl-8728780.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T04:57:47.644555+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/f4e9ef8d0a9927-948-568-0-1510-1925-1155.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />8 proc. w skali roku proponuje lider tabeli z najlepszymi propozycjami na 6 miesięcy. Takie oprocentowanie można otrzymać, o ile jest się nowym klientem i spełni dodatkowe wymogi. To jednocześnie najwyższa stawka, na którą można obecnie liczyć, zakładając lokatę.</p>

## Wzrost cen mieszkań w Polsce odjeżdża Unii Europejskiej [Wykres dnia]
 - [https://www.bankier.pl/wiadomosc/Wzrost-cen-mieszkan-w-Polsce-odjezdza-Unii-Europejskiej-Wykres-dnia-8728708.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wzrost-cen-mieszkan-w-Polsce-odjezdza-Unii-Europejskiej-Wykres-dnia-8728708.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T04:57:47.623811+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/27f08c27ec1dc7-948-568-0-278-1989-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć jeszcze pod koniec 2019 r. ceny mieszkań w Polsce rosły wolniej niż w Unii Europejskiej to w ciągu ostatnich trzech lat różnica między rodzimą mieszkaniówką a średnią unijną zaczęła się rozjeżdżać.</p>

## Kiedy koniec hossy na GPW? Już niedługo, ale jeszcze nie teraz
 - [https://www.bankier.pl/wiadomosc/Kiedy-koniec-hossy-na-GPW-Juz-niedlugo-ale-jeszcze-nie-teraz-8727424.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kiedy-koniec-hossy-na-GPW-Juz-niedlugo-ale-jeszcze-nie-teraz-8727424.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T04:57:47.603978+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/0/91975fdfdd5ef9-948-568-0-44-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Hossa na warszawskiej giełdzie trwa już prawie półtora roku
i właśnie osiągnęła pierwsze „kamienie milowe”.</p>

## Afera GetBack. 131 osób z zarzutami, będzie areszt dla Leszka Czarneckiego?
 - [https://www.bankier.pl/wiadomosc/Afera-GetBack-Bedzie-areszt-dla-Leszka-Czarneckiego-8729291.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Afera-GetBack-Bedzie-areszt-dla-Leszka-Czarneckiego-8729291.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T03:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/d6a50c09b8c09f-945-560-0-303-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />131 osób z zarzutami, finansowe wątki nadal badane, trwają starania o areszt dla Leszka Czarneckiego - to bilans śledztwa w rocznicę wybuchu afery windykacyjnej spółki GetBack - podaje wtorkowa "Rzeczpospolita".</p>

## Polska firma wygrywa z Google. To precedens w skali europejskiej
 - [https://www.bankier.pl/wiadomosc/Ceneo-wygrywa-z-Google-To-precedens-w-skali-europejskiej-8729290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceneo-wygrywa-z-Google-To-precedens-w-skali-europejskiej-8729290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T03:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/a/c3fdf8784eee0e-780-467-187-70-780-467.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Warszawski sąd zakazał wyszukiwarce Google faworyzowania własnej porównywarki cenowej. Nie wolno mu też przekierowywać ruchu do Google Shopping kosztem Ceneo ani utrudniać dostępu do polskiej porównywarki przez usuwanie prowadzących do niej wyników wyszukiwania – pisze we wtorek "Dziennik Gazeta Prawna".</p>

## Koniec eldorado w IT. Popyt na pracowników maleje
 - [https://www.bankier.pl/wiadomosc/Koniec-eldorado-w-IT-Popyt-na-pracownikow-maleje-8729289.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-eldorado-w-IT-Popyt-na-pracownikow-maleje-8729289.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T03:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/22bf4afa55dcf4-948-568-0-40-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosną długi firm informatycznych i listy zwalnianych specjalistów, którzy coraz częściej idą na swoje - pisze we wtorek "Rzeczpospolita". Gazeta zwraca uwagę, że w tym roku największe spadki liczby ofert pracy w porównaniu z ostatnim kwartałem 2023 r. odnotowano w tzw. backendzie, gdzie popyt na pracowników zmalał o 4,5 pkt proc.</p>

## Boeing zapewnia, że samoloty 787 Dreamliner i 777 są bezpieczne
 - [https://www.bankier.pl/wiadomosc/Boeing-zapewnia-ze-samoloty-787-Dreamliner-i-777-sa-bezpieczne-8729288.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Boeing-zapewnia-ze-samoloty-787-Dreamliner-i-777-sa-bezpieczne-8729288.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-04-16T03:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/6e62c47103814d-948-568-37-217-2962-1777.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Boeing oświadczył w poniedziałek, że jest "pewny bezpieczeństwa i trwałości samolotów 787 i 777". Amerykański koncern zapewnił o tym przed zaplanowanym na środę przesłuchaniem w Kongresie w związku zarzutami, że maszyny te nie są bezpieczne.</p>

