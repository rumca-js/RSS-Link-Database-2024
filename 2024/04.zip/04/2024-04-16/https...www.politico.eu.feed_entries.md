# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## Britain’s Conservatives just agreed the world’s toughest smoking ban. Tory MPs hate it
 - [https://www.politico.eu/article/britain-conservative-agree-world-toughest-smoke-ban-tory-hate-it-cigar-tobacco/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/britain-conservative-agree-world-toughest-smoke-ban-tory-hate-it-cigar-tobacco/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T18:45:16+00:00

Prime Minister Rishi Sunak wants to stub out cigarettes for future generations — but a chunk of his own MPs are railing against it.

## ‘It takes two to tango’: Polish ex-PM refuses to rule out a single far-right group in EU Parliament
 - [https://www.politico.eu/article/mateusz-morawiecki-refuse-rule-out-single-far-right-group-eu-parliament-ecr-id/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/mateusz-morawiecki-refuse-rule-out-single-far-right-group-eu-parliament-ecr-id/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T17:31:23+00:00

"Too early to say" if ECR and ID will merge, former Polish PM says.

## France invites Russia to D-Day ceremony — just not Vladimir Putin
 - [https://www.politico.eu/article/france-invites-russia-d-day-ceremony-80th-anniversary-not-vladimir-putin/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/france-invites-russia-d-day-ceremony-80th-anniversary-not-vladimir-putin/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T17:24:26+00:00

Normandy event organizers give Kremlin chief the cold shoulder over Ukraine war.

## EU leaders meet as Israel weighs response to Iran attack — live updates
 - [https://www.politico.eu/article/eu-leaders-summit-israel-iran-attack-ukraine-war-live-updates/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/eu-leaders-summit-israel-iran-attack-ukraine-war-live-updates/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T16:04:05+00:00

EU leaders talk foreign policy and the future of the single market at summit in Brussels.

## Russian victory in Chasiv Yar would jeopardize ‘last stronghold’ of Donetsk region, Ukrainians say
 - [https://www.politico.eu/article/russian-victory-over-ukranian-key-city-chasiv-yar-jeopardize-entire-donetsk-region/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/russian-victory-over-ukranian-key-city-chasiv-yar-jeopardize-entire-donetsk-region/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T15:57:41+00:00

Kyiv needs Western weapons to help defend the city, an army spokesperson told POLITICO.

## Friendly Arab nations urge restraint, but will Netanyahu listen?
 - [https://www.politico.eu/article/friendly-arab-nations-urge-restraint-but-will-netanyahu-listen/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/friendly-arab-nations-urge-restraint-but-will-netanyahu-listen/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T15:12:36+00:00

World is waiting to see how Israel will retaliate after Iran’s attack, and if Bibi will match the forbearance of a legendary predecessor.

## Former high priest of EU politics Selmayr finds higher calling in the Vatican
 - [https://www.politico.eu/article/former-high-priest-eu-politics-berlaymont-monster-martin-selmayr-new-ambassador-vatican-higher-calling/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/former-high-priest-eu-politics-berlaymont-monster-martin-selmayr-new-ambassador-vatican-higher-calling/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T14:53:53+00:00

"The monster of the Berlaymont" has been nominated for a new role.

## EDIS vote in ECON: Ignoring consequences of rush is careless
 - [https://www.politico.eu/sponsored-content/edis-vote-in-econ-ignoring-consequences-of-rush-is-careless/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/sponsored-content/edis-vote-in-econ-ignoring-consequences-of-rush-is-careless/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T13:30:03+00:00

The European Deposit Insurance Scheme is back on Parliament’s banking union agenda, but key regulatory issues remain unresolved, and premature ‘compromise’ may have a far-reaching impact on upcoming European elections.

## Farage: Trump hates the EU so much he ‘makes me look like a Europhile’
 - [https://www.politico.eu/article/nigel-farage-says-donald-trump-hates-the-eu-so-much-makes-me-look-europhile/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/nigel-farage-says-donald-trump-hates-the-eu-so-much-makes-me-look-europhile/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T13:17:28+00:00

The Brexiteer also predicted the former US president would return to office come November. "It's gonna be so great."

## Time for a European single market ‘with teeth’ to take on China, India, leaders told
 - [https://www.politico.eu/article/enrico-letta-report-says-time-for-european-single-market/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/enrico-letta-report-says-time-for-european-single-market/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T12:59:44+00:00

Former Italian Prime Minister Enrico Letta tells POLITICO that government subsidies should become a "European tool."

## France is ‘overwhelmed with propaganda,’ minister says
 - [https://www.politico.eu/article/france-overwhelmed-with-propaganda-european-affairs-minister-says/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/france-overwhelmed-with-propaganda-european-affairs-minister-says/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T12:32:18+00:00

Paris called out several pro-Russian disinformation campaigns in the run-up to June's EU election.

## Macron salutes French ‘heroes’ who intervened in Sydney stabbings
 - [https://www.politico.eu/article/emmanuel-macron-salutes-french-heroes-intervened-sydney-stabbings/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/emmanuel-macron-salutes-french-heroes-intervened-sydney-stabbings/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T11:51:48+00:00

Attacker fatally stabbed six people before he was shot dead by police.

## Scholz wants Xi to stop Russia’s war. Xi wants Europe to stop trade war.
 - [https://www.politico.eu/article/german-olaf-scholz-wants-china-xi-jinping-stop-russia-trade-war-ev/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/german-olaf-scholz-wants-china-xi-jinping-stop-russia-trade-war-ev/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T11:03:20+00:00

Beijing "is not a security threat," Chinese president tells German chancellor.

## Brussels police move to shut down Farage and Orbán’s right-wing jamboree
 - [https://www.politico.eu/article/brussels-police-shut-down-nigel-farage-viktor-orban-right-wing-jamboree/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/brussels-police-shut-down-nigel-farage-viktor-orban-right-wing-jamboree/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T10:22:17+00:00

"Tinpot dictatorship" fumed one of the National Conservatism Conference organizers.

## Liz Truss thinks the ‘deep state’ is out to get Donald Trump
 - [https://www.politico.eu/article/liz-truss-deep-state-get-donald-trump/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/liz-truss-deep-state-get-donald-trump/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T09:18:27+00:00

Ex-UK prime minister has a warning for the man hoping return to the White House.

## Vestager’s kids tell her ‘to put down that phone’
 - [https://www.politico.eu/article/eu-commission-digital-margrethe-vestager-advice-kids-put-down-phone/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/eu-commission-digital-margrethe-vestager-advice-kids-put-down-phone/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T08:58:36+00:00

Once one of the EU's top tweeters, digital chief Margrethe Vestager says she's now less enthusiastic about social media.

## Breton takes victory lap after killing von der Leyen’s business envoy pick
 - [https://www.politico.eu/article/french-breton-victory-eu-von-der-leyen-sme-business-envoy-pick-mep-pieper-elections/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/french-breton-victory-eu-von-der-leyen-sme-business-envoy-pick-mep-pieper-elections/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T08:03:39+00:00

Markus Pieper resigned hours before his first day as the EU's SME envoy.

## Le Pacte vert bat de l’aile
 - [https://www.politico.eu/article/le-pacte-vert-bat-de-laile/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/le-pacte-vert-bat-de-laile/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T05:20:00+00:00

La source d’informations quotidiennes sur l’énergie et le climat en France. Par NICOLAS CAMUT Avec AUDE LE GENTIL et ARTHUR NAZARET Infos et tuyaux à partager ? Ecrivez à Nicolas Camut, Aude Le Gentil et Arthur Nazaret | Voir dans le navigateur AU MENU — Quel avenir pour le Pacte vert européen ? — Le […]

## Deepfakes, distrust and disinformation: Welcome to the AI election
 - [https://www.politico.eu/article/deepfakes-distrust-disinformation-welcome-ai-election-2024/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/deepfakes-distrust-disinformation-welcome-ai-election-2024/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T04:30:00+00:00

From phony robocalls to lifelike forged photos, the trendy tech is evolving at breakneck pace — as billions head to the polls.

## How people view AI, disinformation and elections — in charts
 - [https://www.politico.eu/article/people-view-ai-disinformation-perception-elections-charts-openai-chatgpt/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/people-view-ai-disinformation-perception-elections-charts-openai-chatgpt/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T04:30:00+00:00

Polls worldwide show an apprehension toward the emerging tech — and gaps in understanding how it works and its impact on election-related falsehoods.

## Spot the deepfake: The AI tools undermining our own eyes and ears
 - [https://www.politico.eu/article/spot-deepfake-artificial-intelligence-tools-undermine-eyes-ears/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/spot-deepfake-artificial-intelligence-tools-undermine-eyes-ears/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T04:30:00+00:00

Affordable and accessible generative AI tools have led to a rise in false video, images and audio on social media. Can you spot the difference?

## L’avenir du Pacte vert suspendu aux élections européennes
 - [https://www.politico.eu/article/lavenir-du-pacte-vert-suspendu-aux-elections-europeennes/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/lavenir-du-pacte-vert-suspendu-aux-elections-europeennes/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T04:00:00+00:00

Dans une Europe qui penche à droite, le torchon brûle autour du Pacte Vert européen.

## The impact of AI on disinformation and democracy
 - [https://www.politico.eu/sponsored-content/the-impact-of-ai-on-disinformation-and-democracy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/sponsored-content/the-impact-of-ai-on-disinformation-and-democracy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T03:00:00+00:00

Why high-quality tech journalism matters to the 2024 global election cycle.

## Germany’s Scholz lashed out at EU foreign policy chief over Gaza stance
 - [https://www.politico.eu/article/olaf-scholz-josep-borrell-benjamin-netanyahu-karl-nehammer-lashed-out-at-eu-foreign-policy-chief-on-gaza-stance/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/olaf-scholz-josep-borrell-benjamin-netanyahu-karl-nehammer-lashed-out-at-eu-foreign-policy-chief-on-gaza-stance/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T02:02:00+00:00

At EU summit in March, German and Austrian chancellors criticized Josep Borrell privately while publicly agreeing to calling for a cease-fire.

## Stop EU companies from bankrolling nature destruction
 - [https://www.politico.eu/article/deforestation-climate-change-stop-eu-companies-from-bankrolling-nature-destruction/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/deforestation-climate-change-stop-eu-companies-from-bankrolling-nature-destruction/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T02:01:00+00:00

Europe is complicit in the destruction of ecosystems and should regulate its funding of companies associated with deforestation.

## Liz Truss on Trump, Brexit and … fleas? 9 things we learned reading her new book
 - [https://www.politico.eu/article/liz-truss-trump-brexit-fleas-book-united-kingdom/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/liz-truss-trump-brexit-fleas-book-united-kingdom/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T02:00:00+00:00

Lettuce read the new tome by Britain's shortest-serving prime minister so you don't have to.

## Liz Truss says the EU ‘only understands pain’
 - [https://www.politico.eu/article/liz-truss-says-britain-should-played-hardball-brexit-negotiations-eu-only-understands-pain/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/liz-truss-says-britain-should-played-hardball-brexit-negotiations-eu-only-understands-pain/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T02:00:00+00:00

Ex-PM laments the fact her predecessor Theresa May wasn’t more 'hard­headed.'

## Meet Russia’s Christian soldier who wants to oust Putin
 - [https://www.politico.eu/article/meet-russia-christian-soldier-who-wants-to-oust-putin/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/meet-russia-christian-soldier-who-wants-to-oust-putin/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-04-16T02:00:00+00:00

“When we have enough forces, we will liberate a whole Russian region. We will set up a government … The rebellion will grow, and we will move on to other regions until we march on Moscow,” says Caesar.

