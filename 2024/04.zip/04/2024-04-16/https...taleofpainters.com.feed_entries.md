# Source:Tale of Painters, URL:https://taleofpainters.com/feed, language:en-GB

## Showcase: Legions Imperialis Iron Warriors Land Raider Transport Detachment (inc. painting guide)
 - [https://taleofpainters.com/2024/04/showcase-legions-imperialis-iron-warriors-land-raider-transport-detachment-inc-painting-guide](https://taleofpainters.com/2024/04/showcase-legions-imperialis-iron-warriors-land-raider-transport-detachment-inc-painting-guide)
 - RSS feed: https://taleofpainters.com/feed
 - date published: 2024-04-16T16:00:00+00:00

<p>On today's post I talk about hotdogs, ebay and hollowness as well as the usual how I painted the Iron Warriors' Land Raiders and a 2200pt army photograph. </p>
<p>The post <a href="https://taleofpainters.com/2024/04/showcase-legions-imperialis-iron-warriors-land-raider-transport-detachment-inc-painting-guide/">Showcase: Legions Imperialis Iron Warriors Land Raider Transport Detachment (inc. painting guide)</a> appeared first on <a href="https://taleofpainters.com">Tale of Painters</a>.</p>

