# Source:Daily Mail - Home, URL:https://www.dailymail.co.uk/home/index.rss, language:en-gb

## Paul McCartney's psychedelic Wings 1972 double-decker tour bus goes up for auction - here's how much it could sell for
 - [https://www.dailymail.co.uk/money/cars/article-13309661/Paul-McCartneys-psychedelic-Wings-1972-double-decker-tour-bus-goes-auction-heres-sell-for.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/cars/article-13309661/Paul-McCartneys-psychedelic-Wings-1972-double-decker-tour-bus-goes-auction-heres-sell-for.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T23:12:37+00:00

The famed psychedelic Wings tour bus that housed rock legend Paul McCartney, Linda McCartney, his family and the band is heading for auction 22nd April.

## Craft breweries under threat with a 49% leap in closures last year
 - [https://www.dailymail.co.uk/money/smallbusiness/article-13314231/Craft-breweries-threat-49-leap-closures-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/smallbusiness/article-13314231/Craft-breweries-threat-49-leap-closures-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T23:02:05+00:00

Smaller breweries have been hit particularly hard by rising interest rates and higher costs, with many relying on debt to finance equipment, raw materials and in some cases, operating costs.

## The 25 trickiest home buying terms explained, from gazundering to covenants
 - [https://www.dailymail.co.uk/money/mortgageshome/article-13314979/The-25-trickiest-home-buying-terms-explained-gazundering-covenants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mortgageshome/article-13314979/The-25-trickiest-home-buying-terms-explained-gazundering-covenants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T23:02:02+00:00

The home buying process is filled with jargon, and Zoopla asked people to explain 25 key terms to see how much they really understood.

## Kate Garraway issues desperate plea after receiving 'unsettling post making demands' following the death of her beloved husband Derek Draper
 - [https://www.dailymail.co.uk/tvshowbiz/article-13316151/kate-garraway-post-demands-death-husband-derek-draper.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13316151/kate-garraway-post-demands-death-husband-derek-draper.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T22:14:58+00:00

Kate Garraway has issued a desperate plea after she received 'unsettling post making demands' from Haringey Council following the death of her husband Derek Draper.

## EPHRAIM HARDCASTLE: The 40th anniversary of the murder of WPC Yvonne Fletcher outside the Libyan embassy revives unhappy memories at Scotland Yard
 - [https://www.dailymail.co.uk/debate/article-13316415/EPHRAIM-HARDCASTLE-40th-anniversary-murder-WPC-Yvonne-Fletcher-outside-Libyan-embassy-revives-unhappy-memories-Scotland-Yard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13316415/EPHRAIM-HARDCASTLE-40th-anniversary-murder-WPC-Yvonne-Fletcher-outside-Libyan-embassy-revives-unhappy-memories-Scotland-Yard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:53:32+00:00

EPHRAIM HARDCASTLE: Today's 40th anniversary of the murder of WPC Yvonne Fletcher (left) outside London's Libyan embassy revives unhappy memories at Scotland Yard.

## Truss was smokin'! Even though she takes a while to catch light and can leave an acrid taste: QUENTIN LETTS watches MPs debate the smoking ban
 - [https://www.dailymail.co.uk/debate/article-13316529/Truss-smokin-takes-catch-light-leave-acrid-taste-QUENTIN-LETTS-watches-MPs-debate-smoking-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13316529/Truss-smokin-takes-catch-light-leave-acrid-taste-QUENTIN-LETTS-watches-MPs-debate-smoking-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:50:22+00:00

This is the rolling ban whereby someone aged 15 or younger this year will never, in their lives, be allowed to buy fags but someone born a year earlier will be free to do so.

## Is Ivy Getty's family proof that money really CAN'T buy happiness? As billionaire heiress files for divorce, inside the torrid lives of oil dynasty's OTHER scions - from HIV cheating scandal and teen marriages to drug deaths and KIDNAP plots
 - [https://www.dailymail.co.uk/femail/article-13314159/ivy-getty-family-divorce-tragedy-scandal-billionaire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314159/ivy-getty-family-divorce-tragedy-scandal-billionaire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:44:14+00:00

One might assume that being part of one of the richest families in the world guarantees you a lavish, carefree life. But in the case of the billionaire Getty family, nothing could be further from the truth.

## Alison Hammond gets a mixed response after making her For The Love Of Dogs debut as fans accuse her of having 'no rapport' with the pups: 'Sorry, but you're no Paul O'Grady'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13316215/Alison-Hammond-gets-mixed-response-making-Love-Dogs-debut-fans-accuse-having-no-rapport-pups-Sorry-youre-no-Paul-OGrady.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13316215/Alison-Hammond-gets-mixed-response-making-Love-Dogs-debut-fans-accuse-having-no-rapport-pups-Sorry-youre-no-Paul-OGrady.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:37:58+00:00

Paul became an ambassador for Battersea Dogs & Cats Home in 2012 following the success of the award-winning programme, which he hosted up until shortly before his death last year.

## Michael Palin In Nigeria review: Palin's legendary charm is pushed to the limit by the chaos of Lagos, writes CHRISTOPHER STEVENS
 - [https://www.dailymail.co.uk/tvshowbiz/article-13316115/Michael-Palin-Nigeria-review-Palins-legendary-charm-pushed-limit-chaos-Lagos-writes-CHRISTOPHER-STEVENS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13316115/Michael-Palin-Nigeria-review-Palins-legendary-charm-pushed-limit-chaos-Lagos-writes-CHRISTOPHER-STEVENS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:37:43+00:00

Who would win a fight between a crocodile and a Python? Michael Palin (pictured) wasn't sticking around to find out, at a festival in Nigeria.

## There's a 50-50 chance AI will be able to do ALL our jobs within a century, experts say
 - [https://www.dailymail.co.uk/sciencetech/article-13315791/Experts-predict-AI-one-day-clever-job-workers-claim-are.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13315791/Experts-predict-AI-one-day-clever-job-workers-claim-are.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:30:39+00:00

With millions of jobs at risk from AI in the future, a survey of 16,000 workers found nearly half admit the technology can already outperform them in 'routine tasks' - and pays better attention to detail.

## Barcelona 1-4 PSG (agg 4-6) - Champions League quarter-final: Live score, team news and updates as Kylian Mbappe double seals stunning comeback win for French champions
 - [https://www.dailymail.co.uk/sport/live/article-13313779/Barcelona-vs-PSG-Borussia-Dortmund-vs-Atletico-Madrid-Champions-League-2023-24-Live-Results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/live/article-13313779/Barcelona-vs-PSG-Borussia-Dortmund-vs-Atletico-Madrid-Champions-League-2023-24-Live-Results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:25:40+00:00

Follow Mail Sport's live blog for the latest scores, team news and updates from Tuesday's Champions League second legs.

## EDEN CONFIDENTIAL: Princess Martha Louise of Norway blasts 'lies' about her love guru fiance
 - [https://www.dailymail.co.uk/usshowbiz/article-13316413/Princess-Martha-Louise-Norway-love-guru-fiance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/usshowbiz/article-13316413/Princess-Martha-Louise-Norway-love-guru-fiance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:23:27+00:00

Tension appears to be mounting ahead of Princess Martha Louise of Norway and Durek Verrett's wedding this summer.

## Tom Hollander reveals how he considered letting himself go to become a 'fat actor' to get work
 - [https://www.dailymail.co.uk/tvshowbiz/article-13316333/Tom-Hollander-reveals-considered-fat-actor-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13316333/Tom-Hollander-reveals-considered-fat-actor-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:06:12+00:00

Actor Tom Hollander, 56, who has won roles in The Night Manager, Pirates of the Caribbean and West End show, Patriots, revealed that he considered becoming fat to secure work.

## I'll carry on fighting to defend our way of life. If parents don't like it, their children can go elsewhere, writes Britain's strictest head KATHARINE BIRBALSINGH following landmark court ruling backing a prayer ban at her school
 - [https://www.dailymail.co.uk/debate/article-13316477/Ill-carry-fighting-defend-way-life-parents-dont-like-children-writes-Britains-strictest-head-KATHARINE-BIRBALSINGH-following-landmark-court-ruling-backing-prayer-ban-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13316477/Ill-carry-fighting-defend-way-life-parents-dont-like-children-writes-Britains-strictest-head-KATHARINE-BIRBALSINGH-following-landmark-court-ruling-backing-prayer-ban-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:05:00+00:00

KATHARINE BIRBALSINGH: A school should be free to do what is right for the pupils it serves. The court's decision is therefore a victory for all schools.

## MATT GOODWIN: Police shutting down a Conservatism conference in the heart of the EU was a tactic straight out of the Soviet playbook
 - [https://www.dailymail.co.uk/debate/article-13316287/MATT-GOODWIN-heart-EU-tactic-straight-Soviet-playbook-needed-clarification-Britain-right-leave-surely-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13316287/MATT-GOODWIN-heart-EU-tactic-straight-Soviet-playbook-needed-clarification-Britain-right-leave-surely-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:04:30+00:00

MATT GOODWIN: If anyone, anywhere, needed any clarification as to why Britain was right to leave the European Union - this should surely be it.

## Alison Hammond, 49, 'is dating a 6ft 10in Russian masseur 20 YEARS her junior' and 'has never been happier'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13316233/Alison-Hammond-49-dating-6ft-10in-Russian-masseur-20-YEARS-junior-never-happier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13316233/Alison-Hammond-49-dating-6ft-10in-Russian-masseur-20-YEARS-junior-never-happier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T21:01:11+00:00

The This Morning presenter,49, is reportedly dating David Putman, a model and dancer who is roughly 20 years her junior.

## Barcelona fans mistakenly throw objects at their OWN team bus as they clash with police in violent scenes outside the stadium ahead of Champions League showdown with PSG
 - [https://www.dailymail.co.uk/sport/football/article-13315931/Barcelona-fans-mistakenly-throw-objects-team-bus-clash-police-violent-scenes-outside-stadium-ahead-Champions-League-showdown-PSG.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13315931/Barcelona-fans-mistakenly-throw-objects-team-bus-clash-police-violent-scenes-outside-stadium-ahead-Champions-League-showdown-PSG.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T20:21:39+00:00

Barcelona fans mistakenly threw objects at their own team bus ahead of their Champions League quarter-final second leg against PSG this evening.

## Scientists find 'vampire' bacteria that has a thirst for HUMAN blood
 - [https://www.dailymail.co.uk/sciencetech/article-13315303/bacterial-vampirism-infections-IBD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13315303/bacterial-vampirism-infections-IBD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T20:17:26+00:00

Bacteria like E. coli and salmonella can home in on blood, a process called 'bacterial vampirism.' In people with IBD who have small cuts in the gut, these bacteria can easily find their way into the blood.

## Alison Hammond hits back after trolls savaged This Morning star for replacing Paul O'Grady as host of For The Love Of Dogs: 'If you don't want to watch it, don't watch it'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13316099/Alison-Hammond-hits-trolls-slammed-new-gig-hosting-Love-Dogs-Paul-OGradys-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13316099/Alison-Hammond-hits-trolls-slammed-new-gig-hosting-Love-Dogs-Paul-OGradys-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T20:16:49+00:00

The TV presenter, 49, will head to Battersea Dogs & Cats Home on the show to help the animals in its care look for a new place to live.

## Idris and Sabrina Elba put on a stylish display as they are joined in rare red carpet appearance with his mum for Knuckles world premiere
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315895/Idris-Sabrina-Elba-stylish-mum-Knuckles-world-premiere.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315895/Idris-Sabrina-Elba-stylish-mum-Knuckles-world-premiere.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T19:59:31+00:00

The actor looked incredibly dapper as he attended the world premiere of his new Paramount+ series Knuckles at the Odeon Luxe in Leicester Square, London on Tuesday.

## Queen Mathilde of Belgium and Grand Duchess Maria Teresa of Luxembourg don glittering tiaras and elegant gowns as they attend a lavish state banquet in Brussels
 - [https://www.dailymail.co.uk/femail/article-13315919/grand-duchess-maria-teresa-queen-mathilde-state-banquet-belgium.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13315919/grand-duchess-maria-teresa-queen-mathilde-state-banquet-belgium.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T19:41:12+00:00

Grand Duchess Maria Teresa of Luxembourg, 68, and Grand Duke Henri are paying a state visit to Belgium and their first evening consisted of a lavish banquet at the Laken Castle.

## 'Holy mackerel... searing pain': Wildlife expert Coyote Peterson live-streams being bitten by a lethal giant centipede (as an ER doctor keeps a careful eye on him)
 - [https://www.dailymail.co.uk/travel/article-13314853/brave-wilderness-coyote-peterson-doctor-er-jordan-wagner-centipede-bite.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/travel/article-13314853/brave-wilderness-coyote-peterson-doctor-er-jordan-wagner-centipede-bite.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T19:26:09+00:00

Coyote's tormentor is a mysterious and potentially lethal Thai giant cherry centipede, which bites him under the watchful eye of Dr Jordan Wagner - aka YouTube's Doctor ER.

## Sydney Sweeney 'is not pretty and she can't act' declares top Hollywood producer Carol Baum, calling her movie Anyone But You 'unwatchable'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315349/Hollywood-producer-Carol-Baum-Sydney-Sweeney-not-pretty-act.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315349/Hollywood-producer-Carol-Baum-Sydney-Sweeney-not-pretty-act.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T19:20:46+00:00

Sydney Sweeney, 26, has been fiercely blasted by one of Hollywood's top female producers at a screening in New York last week.

## Travis Kelce confirmed as the host of new game show 'Are You Smarter Than a Celebrity?' as Taylor Swift's boyfriend and NFL star lands 20-episode season with Amazon Prime
 - [https://www.dailymail.co.uk/sport/nfl/article-13316007/Travis-Kelce-confirmed-host-new-game-Smarter-Celebrity-Taylor-Swifts-boyfriend-NFL-star-lands-20-episode-season-Amazon-Prime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/nfl/article-13316007/Travis-Kelce-confirmed-host-new-game-Smarter-Celebrity-Taylor-Swifts-boyfriend-NFL-star-lands-20-episode-season-Amazon-Prime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T19:13:57+00:00

The Chiefs star and Taylor Swift 's boyfriend will front 20 episodes of the new show - a spinoff of 'Are You Smarter Than a 5th Grader?' - as he continues to add to his growing portfolio of work.

## Rylan Clark reveals the shocking damage done to his home following extreme winds - after his house was invaded by a bat AND snakes
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315987/Rylan-Clark-reveals-shocking-damage-home-following-extreme-winds-house-invaded-bat-snakes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315987/Rylan-Clark-reveals-shocking-damage-home-following-extreme-winds-house-invaded-bat-snakes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T19:06:48+00:00

The TV presenter, 35, took to his Instagram Stories on Tuesday to show his followers a tree had been knocked over during the blustery weather.

## Eighties Cosmo cover girl Dayle Haddon, 75, who starred in movies with Nick Nolte and dated Tarzan's Christopher Lambert is still stunning at Dior show in New York... 50 years after becoming famous
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315659/Dayle-Haddon-worked-Nick-Nolte-stunning-Dior-New-York.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315659/Dayle-Haddon-worked-Nick-Nolte-stunning-Dior-New-York.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T19:01:45+00:00

The 75-year-old Canadian was a top Vogue cover girl in the 1970s and 1980s, posed nude for Playboy. She the parlayed that modeling fame into movies like Cyborg and Bullets Over Broadway.

## Jude Bellingham blasts 'disgusting' racist abuse as Aurelien Tchouameni becomes the latest star to be targeted in Spain... and admits he has 'got used to' slurs since Real Madrid move
 - [https://www.dailymail.co.uk/sport/football/article-13315853/Jude-Bellingham-racist-abuse-Aurelien-Tchouameni-Spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13315853/Jude-Bellingham-racist-abuse-Aurelien-Tchouameni-Spain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T18:55:21+00:00

A tearful Vinicius Junior recently revealed that he was 'losing his desire' for the game in the wake of abuse and Bellingham took aim at authorities on the eve on Madrid versus Manchester City.

## Danny Dyer horrified to learn son Arty, nine, is a fan of controversial influencer and self-proclaimed misogynist Andrew Tate while filming documentary on toxic masculinity
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315661/danny-dyer-son-arty-fan-andrew-tate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315661/danny-dyer-son-arty-fan-andrew-tate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T18:55:00+00:00

Danny Dyer, 46, has spoken of his horror at learning his young son Arty, nine, is a fan of controversial influencer and self-proclaimed misogynist Andrew Tate.

## Aaron Rodgers suggests HIV/AIDS pandemic of the 1980s was created by the federal government and immunologist Dr. Anthony Fauci in bizarre months-old resurfaced clip: 'The blueprint was made in the 80s'
 - [https://www.dailymail.co.uk/sport/nfl/article-13315631/aaron-rodgers-hiv-aids-pandemic-fake-anthony-fauci.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/nfl/article-13315631/aaron-rodgers-hiv-aids-pandemic-fake-anthony-fauci.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T18:30:59+00:00

Aaron Rodgers' issues with Dr. Anthony Fauci didn't begin with the COVID-19 pandemic of 2020. As revealed in resurfaced footage, the New York Jets quarterback has other issues too.

## RICHARD EDEN: Princess Margaret made secret visits to Caribbean villas of the rich and famous including David Bowie while they were not at home, reveals TV star Susannah Constantine
 - [https://www.dailymail.co.uk/femail/article-13315765/RICHARD-EDEN-Princess-Margaret-secret-visits-Caribbean-villas-rich-famous-including-David-Bowie-not-home-reveals-TV-star-Susannah-Constantine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13315765/RICHARD-EDEN-Princess-Margaret-secret-visits-Caribbean-villas-rich-famous-including-David-Bowie-not-home-reveals-TV-star-Susannah-Constantine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T18:25:39+00:00

Susannah Constantine has made the revelation that the princess would secretly enter the holiday homes of rich and famous people who lived on Mustique in the West Indies.

## There IS a link between women's periods and the moon after all, study finds
 - [https://www.dailymail.co.uk/sciencetech/article-13314907/Strange-Link-Menstrual-Cycles-Moon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13314907/Strange-Link-Menstrual-Cycles-Moon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T18:22:45+00:00

Researchers in France and the US discovered there is a link between menstrual cycles and the full moon. The moon affects the body's circadian rhythms, syncing the cycles.

## Pop Idol's Michelle McManus looks incredible in a stylish floral dress as she shows off impressive weight loss
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315703/Pop-Idol-Michelle-McManus-weight-loss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315703/Pop-Idol-Michelle-McManus-weight-loss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T18:17:34+00:00

The Scottish singer, 43, who has previously spoke about her battle with weight and journey to sobriety, displayed her slender frame as she proudly posed for a selfie.

## Pamela Anderson lands starring role in The Naked Gun reboot alongside Liam Neeson - 30 years after iconic franchise with Leslie Nielsen ended
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315675/Pamela-Anderson-Liam-Neeson-Naked-Gun-reboot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315675/Pamela-Anderson-Liam-Neeson-Naked-Gun-reboot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T18:06:41+00:00

The Canadian-American actress, 56, will star opposite of Liam Neeson in the untitled remake, slated to hit theaters on July 18, 2025.

## Victoria Beckham gives fans a never seen before sneak peek inside her £24million Miami penthouse as she prepares to celebrate the big 50
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315701/Victoria-Beckham-fans-never-seen-sneak-peek-inside-24million-Miami-penthouse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315701/Victoria-Beckham-fans-never-seen-sneak-peek-inside-24million-Miami-penthouse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T17:58:23+00:00

The Spice Girl has given fans never seen before glimpse inside her Miami penthouse as she shared a candid snap relaxing on the sofa.

## NASA says Mars samples that may contain signs of life are STUCK on Red Planet... as it calls on private sector's help retrieving them
 - [https://www.dailymail.co.uk/sciencetech/article-13311379/NASA-needs-help-retrieving-Mars-samples-Perseverance-Rover-collected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13311379/NASA-needs-help-retrieving-Mars-samples-Perseverance-Rover-collected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T17:44:08+00:00

NASA announced it needs help bringing rock samples back from Mars that Perseverance Rover had collected in its search for signs of life. The existing plan is 'too expensive' and would take 'too long.'

## Rory McIlroy says bombshell $850m LIV Golf rumors are FALSE and he 'will play on the PGA Tour for the rest of my career' as Ryder Cup star categorically rejects shock reports of a move to Saudi-backed rebel circuit
 - [https://www.dailymail.co.uk/sport/golf/article-13315471/Rory-McIlroy-LIV-Golf-rumors-FALSE-play-PGA-Tour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/golf/article-13315471/Rory-McIlroy-LIV-Golf-rumors-FALSE-play-PGA-Tour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T17:34:33+00:00

It was claimed in recent days that the Northern Irishman was close to a seismic U-turn to join the Saudi-backed breakaway. 'I honestly don't know how these things get started,' McIlroy said.

## Fancy splashing out? Former water reservoir transformed into quirky Grand Design-style two-bed home goes on the market for £1.25million
 - [https://www.dailymail.co.uk/property/article-13315541/Former-water-reservoir-converted-two-bed-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/property/article-13315541/Former-water-reservoir-converted-two-bed-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T17:22:33+00:00

Fairlinch is now a quirky single-storey property with spectacular panoramic views across the countryside and towards the north Devon coastline.

## How Britain's greatest Olympian Sir Steve Redgrave didn't make final interviews for British Rowing job... and for the first time in 40 years, he won't be at Paris Games as his BBC work has dried up
 - [https://www.dailymail.co.uk/sport/olympics/article-13315133/How-Britains-greatest-Olympian-Sir-Steve-Redgrave-didnt-make-final-interviews-British-Rowing-job-time-40-years-wont-Paris-Games-BBC-work-dried-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13315133/How-Britains-greatest-Olympian-Sir-Steve-Redgrave-didnt-make-final-interviews-British-Rowing-job-time-40-years-wont-Paris-Games-BBC-work-dried-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T17:14:23+00:00

EXCLUSIVE BY DAVID COVERDALE: There will be something a little different about the Olympics this summer. For the first time in 40 years, Sir Steve Redgrave will not be there.

## The Beatles fans ecstatic as sons of Sir Paul McCartney and John Lennon release song Primrose Hill, insisting they look and sound just like the stars
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315613/beatles-sons-paul-mccartney-john-lennon-song-primrose-hill-look-sound-like-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315613/beatles-sons-paul-mccartney-john-lennon-song-primrose-hill-look-sound-like-stars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T17:02:28+00:00

Fans of James McCartney and Sean Ono Lennon have praised the duo after they came together to release a new song together, following in the footsteps of their world famous fathers.

## Queen Letizia of Spain sports a smart navy suit as she and King Felipe depart Madrid for state visit to The Netherlands
 - [https://www.dailymail.co.uk/femail/article-13315057/queen-letizia-spain-state-visit-netherlands-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13315057/queen-letizia-spain-state-visit-netherlands-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:59:45+00:00

Queen Letizia of Spain looked chic on Tuesday as she prepared for a state visit to The Netherlands alongside her husband, King Felipe VI.

## No Sharon? No problem! Simon Cowell and Amanda Holden have the last laugh at Britain's Got Talent launch after THAT Osbourne feud as he contradicts her claim that he dumps old colleagues by vowing to work with Cheryl
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315399/Simon-Cowell-Amanda-Holden-Alesha-Dixon-Bruno-Tonioli-look-good-spirits-reunite-Britains-Got-Talent-photocall-ahead-17th-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315399/Simon-Cowell-Amanda-Holden-Alesha-Dixon-Bruno-Tonioli-look-good-spirits-reunite-Britains-Got-Talent-photocall-ahead-17th-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:59:26+00:00

The quartet are back in action for the ITV show's 17th series with Ant McPartlin and Declan Donnelly returning as hosts.

## Football's first superstar who worked at the same pit as my grandad... and puts the PFA to shame
 - [https://www.dailymail.co.uk/sport/football/article-13315063/Football-pit-grandad-puts-PFA-shame.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13315063/Football-pit-grandad-puts-PFA-shame.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:47:43+00:00

IAN HERBERT: He fought for a fair player wage and the right to transfer between clubs, taking on a powerful Edwardian Establishment determined to limit the money workers took.

## Here's everything that could go wrong with your jam, Meghan…and my tips to make sure it doesn't - by a gold-winning marmalade maker
 - [https://www.dailymail.co.uk/femail/article-13315111/WRONG-jam-Meghan-markle-american-riviera-orchard-gold-winning-marmalade-maker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13315111/WRONG-jam-Meghan-markle-american-riviera-orchard-gold-winning-marmalade-maker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:45:39+00:00

As Meghan launches the first product from her new American Riviera Orchard range - strawberry jam - one award-winning expert LUCY DEEDES dishes some pithy words of advice…

## People are calling $700 AI gadget the worst piece of tech they've ever used - even though it was touted as the 'iPhone killer'
 - [https://www.dailymail.co.uk/sciencetech/article-13315229/Humane-AI-Pin-worst-iPhone-killer-review-criticisms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13315229/Humane-AI-Pin-worst-iPhone-killer-review-criticisms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:45:10+00:00

Humane's tiny, $700 wearable computer, AI Pin, vowed to be user's virtual personal assistant and a veritable 'iPhone killer.' But savage reviews blasted its AI for wrong answers

## The Beatles' iconic documentary Let It Be is to be made available on Disney+ for the FIRST time in more than 50 years after loving restoration of Michael Lindsay-Hogg's film
 - [https://www.dailymail.co.uk/tvshowbiz/article-13315069/The-Beatles-iconic-documentary-Let-available-Disney-time-50-years-loving-restoration-Michael-Lindsay-Hoggs-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13315069/The-Beatles-iconic-documentary-Let-available-Disney-time-50-years-loving-restoration-Michael-Lindsay-Hoggs-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:32:23+00:00

The Beatles ' iconic documentary film Let It Be is set to be made available for the first time in more than 50 years on Disney+. It was released in May 1970 in the wake of the band's breakup.

## My mother was brutally killed 30 years ago on Christmas Eve and the killer has never been caught - she gave me a chilling warning just hours before her murder
 - [https://www.dailymail.co.uk/femail/article-13314969/Tracy-Mertens-Christmas-Eve-Murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314969/Tracy-Mertens-Christmas-Eve-Murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:26:32+00:00

Kelly Hill, 40, from Lancaster, has bravely decided to speak out in a bid to find justice and answers - and remains hopeful someone will be caught in her lifetime.

## My terrifying whooping cough ordeal: A&E doctor tells how she was left unable to breathe for an agonising 30 seconds - as cases soar around the country. So should you be worried?
 - [https://www.dailymail.co.uk/health/article-13314983/My-terrifying-whooping-cough-ordeal-doctor-tells-left-unable-breathe-agonising-30-seconds-cases-soar-country-worried.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13314983/My-terrifying-whooping-cough-ordeal-doctor-tells-left-unable-breathe-agonising-30-seconds-cases-soar-country-worried.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:21:23+00:00

DR SALEYHA AHSAN: I'm now at Day 23 of the '100-day' cough. What I have is whooping cough. It started with a mild cough in March, but within days I had severe coughing fits.

## Scouts CEO praises 'charming' Princess of Wales' ability to 'put people at ease' and reveals 'what you see is what you get with Kate'
 - [https://www.dailymail.co.uk/femail/article-13315301/Scouts-CEO-praises-charming-Princess-Wales-ability-people-ease-reveals-Kate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13315301/Scouts-CEO-praises-charming-Princess-Wales-ability-people-ease-reveals-Kate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:13:10+00:00

Speaking to the Mirror , Matt Hyde said 'what you see is what you get' with the Princess. The royal first started volunteering for the organisation while living on the Isle of Anglesey in 2012.

## Can you sell a car that has outstanding parking tickets? Consumer expert DEAN DUNHAM replies...
 - [https://www.dailymail.co.uk/money/mailplus/article-13315105/Can-sell-car-outstanding-parking-tickets-Consumer-expert-DEAN-DUNHAM-replies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mailplus/article-13315105/Can-sell-car-outstanding-parking-tickets-Consumer-expert-DEAN-DUNHAM-replies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T16:03:33+00:00

When you get a parking ticket, also known as a Penalty Charge Notice or PCN for parking violations on public roads, it is linked to the vehicle not the driver.

## Wigan fire: Heartbreak as boy, 4, dies two days after house inferno: Ethan Mason was left fighting for his life after his father ran back into the burning building to save him
 - [https://www.dailymail.co.uk/news/article-13315331/wigan-house-fire-boy-ethan-mason-dies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13315331/wigan-house-fire-boy-ethan-mason-dies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:55:36+00:00

Ethan Mason had been rescued after his 'dad ran back inside to save his little boy', his family said. Tragically, his father, aged 45, died from his injuries.

## Lioness Beth Mead reveals how Prince William's 'face lit up' when she walked into the room and they enjoyed 'easy' conversation when royal presented her with her MBE
 - [https://www.dailymail.co.uk/femail/article-13314195/beth-mead-prince-william-mbe-ceremony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314195/beth-mead-prince-william-mbe-ceremony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:55:07+00:00

In an interview with OK magazine, the England striker spoke on the 'easy' conversation she had with the future monarch at the investiture ceremony last year

## 'My dad kicked b***s for a living and I kick people's heads': One-armed kickboxer and son of a Chelsea legend makes amazing start to his career in top-flight fighting competition
 - [https://www.dailymail.co.uk/sport/mma/article-13313815/One-armed-kickboxer-makes-amazing-start-career.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/mma/article-13313815/One-armed-kickboxer-makes-amazing-start-career.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:45:32+00:00

The English-born fighter, who moved to Canada when his father gave up football punditry to become a pastor, is viewed as one of the best Muay Thai fighters in North America.

## Tesla reportedly halts ALL Cybertruck deliveries due to fatal flaw that causes EV to accelerate to top speeds
 - [https://www.dailymail.co.uk/sciencetech/article-13314593/tesla-halts-cybertruck-deliveries-ev-acceleration-speed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13314593/tesla-halts-cybertruck-deliveries-ev-acceleration-speed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:38:28+00:00

An analysis told DailyMail.com that all Cybertruck deliveries have been put on pause. The recall is due to a potentially fatal issue with the accelerator that will take weeks to resolve.

## Experts say THIS is how often you need to be washing your makeup brushes to avoid acne - and it's annoyingly often
 - [https://www.dailymail.co.uk/wellness-us/article-13311797/expert-dermatologist-advice-makeup-brush-clean-pimples-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/wellness-us/article-13311797/expert-dermatologist-advice-makeup-brush-clean-pimples-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:35:33+00:00

Although it may be a loborious task, skin health experts say washing your makeup brushes at least once a week is essential for avoiding nasty problems like acne and infections.

## Popeyes turns viral hack into official menu item as popular chicken chain announces the launch of mouthwatering new arrival
 - [https://www.dailymail.co.uk/femail/article-13314045/popeyes-menu-hack-official-item-double-stack-sandwich.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314045/popeyes-menu-hack-official-item-double-stack-sandwich.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:32:57+00:00

Popeye's has turned a fan-favourite menu 'hack' into an official menu item with the launch of a new offering. The item in question will be available across the UK from £7.99.

## Queen Mary of Denmark welcomes Olena Zelenska, to Copenhagen as Ukraine's Firsy Lady praises the Danish royal family for its ongoing 'support'
 - [https://www.dailymail.co.uk/femail/article-13314705/Queen-Mary-Denmark-Olena-Zelenska-Copenhagen-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314705/Queen-Mary-Denmark-Olena-Zelenska-Copenhagen-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:31:59+00:00

The Australian-born Queen, 52, skipped formalities and greeted the wife of President Volodymyr Zelenskyy , Olena Zelenska, with a warm hug.

## Blind psychic Baba Vanga's chilling WW3 prediction revealed as tensions between Iran and Israel escalate
 - [https://www.dailymail.co.uk/femail/article-13313999/Blind-psychic-Baba-Vanga-prediction-Israel-Iran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313999/Blind-psychic-Baba-Vanga-prediction-Israel-Iran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:26:31+00:00

Baba Vanga, who reportedly predicted 9/11 and the Covid-19 pandemic and died in 1996, has made a chilling WW3 prediction as tensions between Iran and Israel escalate.

## The 'leatherjackets' that can destroy your lawn in days: Couple reveal how their 'perfect' grass has been replaced by a mudbath after infestation of daddy-longlegs larvae
 - [https://www.dailymail.co.uk/femail/gardening/article-13314157/leatherjackets-destroy-lawn-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/gardening/article-13314157/leatherjackets-destroy-lawn-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:22:29+00:00

One couple shared on Instagram how an infestation of the grubs, known as 'leatherjackets' have ruined the lawn they had professionally turfed just three years ago.

## Ozempic warning: 21 year-old woman develops deadly blood complication after taking Mounjaro for just three weeks
 - [https://www.dailymail.co.uk/health/article-13314401/ozempic-complication-ketoacidosis-mounjaro-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13314401/ozempic-complication-ketoacidosis-mounjaro-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:14:33+00:00

An unnamed patient in Kuwait, 21, went into ketoacidosis after three weeks of taking tirzepatide, the active ingredient in blockbuster weight loss drugs Mounjaro and Zepbound.

## Meghan Markle fans praise the look of her 'rustic jam' with homemade labels using 'her own calligraphy' (but some notice the paper is peeling off!)
 - [https://www.dailymail.co.uk/femail/article-13314755/Meghan-Markle-jam-homemade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314755/Meghan-Markle-jam-homemade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:14:25+00:00

The Duchess of Sussex , 42,  sent out strawberry jam to a number of pals, including Delfina Blaquier and fashion designer Tracy Robbins, who shared shots on Instagram.

## Did Drake get a nose job and a BBL? Plastic surgeons weigh in as rap feud with former friend Rick Ross gets ugly and personal
 - [https://www.dailymail.co.uk/health/article-13311547/drake-nose-job-plastic-surgery-rick-ross.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13311547/drake-nose-job-plastic-surgery-rick-ross.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:00:53+00:00

While the nose job accusation is new, rumors that Drake - whose real name is Aubrey Graham - has had work done on his body have been circulating for years. DailyMail.com put the claims to surgeons.

## 'In too deep, Matt? Conspiracy-loving ex-footballer Le Tissier looks awkward sat alongside a YouTuber streamer, as he spouts bizarre theories claiming Johan Cruyff, Princess Diana and JFK are alive'
 - [https://www.dailymail.co.uk/sport/football/article-13314297/Matt-Conspiracy-ex-footballer-Le-Tissier-awkward-YouTuber-streamer-spouts-bizarre-Johan-Cruyff-Princess-Diana-JFK-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13314297/Matt-Conspiracy-ex-footballer-Le-Tissier-awkward-YouTuber-streamer-spouts-bizarre-Johan-Cruyff-Princess-Diana-JFK-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T15:00:38+00:00

Matt Le Tissier appeared uncomfortable as he sat alongside a Youtuber spouting a bizarre conspiracy theory involving Princess Diana , JFK and Johan Cruyff.

## Princess Martha Louise has pre-wedding fallout with her future mother-in-law: Norwegian royal blasts claims by her shaman fiancé's mother that he grew up poor and insists he was 'one of the richest kids in school' and was raised in a $3m property
 - [https://www.dailymail.co.uk/femail/article-13314535/princess-martha-louise-durek-varrett-hits-richest-kid-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314535/princess-martha-louise-durek-varrett-hits-richest-kid-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T14:57:39+00:00

In a defiant Instagram post, the royal, 52, included comments from one of Durek's former classmates who insisted he was 'one of the richest kids' in their school in California.

## Legendary Sky Sports commentator Martin Tyler, 78, reveals he's had surgery to save his voice after a keratin build-up in his throat - caused by 'overuse' - risked leaving him mute
 - [https://www.dailymail.co.uk/sport/football/article-13314163/Martin-Tyler-reveals-underwent-surgery-save-iconic-voice-legendary-Sky-Sports-commentator-opening-frightening-prospect-permanently-unable-speak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13314163/Martin-Tyler-reveals-underwent-surgery-save-iconic-voice-legendary-Sky-Sports-commentator-opening-frightening-prospect-permanently-unable-speak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T14:43:28+00:00

It was announced in June 2023 that the legendary Sky Sports commentator would be leaving his position with the broadcaster, ending a 33-year spell with the company.

## America's electric vehicle push happened 'too soon and too fast,' warn ex-auto executives - but former Big Three boss Bob Lutz insists hybrids ARE the future
 - [https://www.dailymail.co.uk/yourmoney/electric-vehicles/article-13311175/electric-vehicle-push-ford-executive-hybrids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/yourmoney/electric-vehicles/article-13311175/electric-vehicle-push-ford-executive-hybrids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T14:42:47+00:00

Former automotive executives have said America's electric vehicle push happened 'too soon and too fast', amid slumping EV sales.

## Proposed design for a train station in Nanjing is ridiculed by Chinese internet users - with one joking 'that is a giant sanitary pad!'
 - [https://www.dailymail.co.uk/sciencetech/article-13314473/train-station-Nanjing-ridiculed-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13314473/train-station-Nanjing-ridiculed-China.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T14:17:15+00:00

The design of a new train station in the Chinese City of Nanjing has been relentlessly mocked on social media, with internet users comparing the shape to a sanitary pad.

## Sienna Miller looks incredible in a tiny black bikini as she surfs the waves in Costa Rica - three months after welcoming her second child
 - [https://www.dailymail.co.uk/tvshowbiz/article-13314083/Sienna-Miller-bikini-surfing-Costa-Rica-second-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13314083/Sienna-Miller-bikini-surfing-Costa-Rica-second-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T14:04:47+00:00

Sienna Miller enjoyed the surf during her recent holiday in Costa Rica, looking incredible in a skimpy bikini.

## Alfa Romeo EV will NOT be called Milano after claims it breaks law by being built in Poland
 - [https://www.dailymail.co.uk/money/electriccars/article-13314491/Alfa-Romeo-EV-NOT-called-Milano-claims-breaks-law-built-Poland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/electriccars/article-13314491/Alfa-Romeo-EV-NOT-called-Milano-claims-breaks-law-built-Poland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T14:03:44+00:00

After unveiling it just a week ago, a monumental fallout in Italy has seen Alfa Romeo do a screeching U-turn on its new Milano's name.

## Controversial Irish Wrexham star James McClean salutes fans singing 'he hates the f***ing King', weeks after Ryan Reynolds' team invited Prince William to their stadium
 - [https://www.dailymail.co.uk/sport/football/article-13314249/Controversial-Irish-Wrexham-star-James-McClean-salutes-fans-singing-hates-f-ing-King-weeks-Ryan-Reynolds-team-invited-Prince-William-stadium.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13314249/Controversial-Irish-Wrexham-star-James-McClean-salutes-fans-singing-hates-f-ing-King-weeks-Ryan-Reynolds-team-invited-Prince-William-stadium.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T13:27:36+00:00

Controversial Irish star James McClean has saluted Wrexham fans singing an anti-King Charles III chant, weeks after Prince William visited the club.

## Sam Fox thanks fans for her birthday messages while wife Linda Olsen shares loved-up photo tribute as they enjoy a holiday after ex Page Three model was accused of assaulting her
 - [https://www.dailymail.co.uk/tvshowbiz/article-13314275/Sam-Fox-thanks-fans-birthday-messages-wife-Linda-Olsen-shares-loved-photo-tribute-enjoy-holiday-ex-Page-Three-model-accused-assaulting-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13314275/Sam-Fox-thanks-fans-birthday-messages-wife-Linda-Olsen-shares-loved-photo-tribute-enjoy-holiday-ex-Page-Three-model-accused-assaulting-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T13:27:25+00:00

The couple are enjoying a romantic break just days after the ex Page Three model appeared in court to deny assaulting her wife on board a plane.

## Woman warns fashionistas 'do not rent out your clothes' as she reveals she wasn't entitled to compensation from lending platform Hurr when her £400 ski coat was damaged by two borrowers
 - [https://www.dailymail.co.uk/femail/article-13310493/Woman-warns-rent-clothes-Hurr-damaged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13310493/Woman-warns-rent-clothes-Hurr-damaged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:44:28+00:00

Aspiring lawyer Devon Lloyd, 24, from London , took to TikTok to explain her 'stress' after she received her £400 ski coat back from a renter spoiled.

## Is Sian Brooke the BBC's lucky charm? As Blue Lights returns with rave reviews how the channel's golden girl has drawn in millions of viewers with a string of primetime shows
 - [https://www.dailymail.co.uk/tvshowbiz/article-13314129/Is-Sian-Brooke-BBCs-lucky-charm-Blue-Lights-returns-rave-reviews-channels-golden-girl-drawn-viewers-string-primetime-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13314129/Is-Sian-Brooke-BBCs-lucky-charm-Blue-Lights-returns-rave-reviews-channels-golden-girl-drawn-viewers-string-primetime-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:38:27+00:00

It's the latest of Sian's series to receive rave reviews of late, having been plucked by BBC bosses to star in several primetime shows on the channel.

## Is there a spat splitting the Lionesses? Chelsea star Lauren James 'unfollows' Mary Earps and Ella Toone after Man United players made light of her struggles against them on Instagram
 - [https://www.dailymail.co.uk/sport/football/article-13314265/Is-spat-splitting-Lionesses-Chelsea-star-Lauren-James-unfollows-Mary-Earps-Ella-Toone-Man-United-players-light-struggles-against-Instagram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13314265/Is-spat-splitting-Lionesses-Chelsea-star-Lauren-James-unfollows-Mary-Earps-Ella-Toone-Man-United-players-light-struggles-against-Instagram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:36:36+00:00

It came after the Chelsea star endured a difficult outing against Manchester United during Sunday's FA Women's Cup semi-final on Sunday and was embroiled in a controversial incident.

## How sheer dresses became the look of the season on red carpets as stars ditch typical glamour for festival-inspired fashion
 - [https://www.dailymail.co.uk/femail/article-13314225/How-sheer-dresses-look-season-red-carpets-stars-ditch-typical-glamour-festival-inspired-fashion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314225/How-sheer-dresses-look-season-red-carpets-stars-ditch-typical-glamour-festival-inspired-fashion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:36:04+00:00

A-listers and homegrown stars have all opted for the look, from Kendall Jenner to Katy Perry and Ice Spice .

## Queen Mary and King Frederik of Denmark join Queen Margrethe to celebrate her 84th birthday - after a frosty display on Easter ski-ing trip
 - [https://www.dailymail.co.uk/femail/article-13314141/queen-mary-king-frederik-pose-fredensborg-castle-margrethes-birthday-rumours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314141/queen-mary-king-frederik-pose-fredensborg-castle-margrethes-birthday-rumours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:34:42+00:00

Queen Mary, King Frederik,  Queen Margrethe and her sister, Princess Benedikte, posed outside Fredensborg Castle as they greeted royal fans on Margrethe's birthday.

## Why Rishi Sunak's 'mad' smoking ban 'is destined to fail': Critics warn trailblazing law to stop Generation Alpha getting hooked on cigarettes will prove a 'charter for criminals' - amid fears health chiefs may take aim at sugar, caffeine and alcohol next
 - [https://www.dailymail.co.uk/health/article-13313449/Why-Rishi-Sunaks-mad-smoking-ban-destined-fail-Critics-warn-trailblazing-law-stop-Generation-Alpha-getting-hooked-cigarettes-prove-charter-criminals-amid-fears-health-chiefs-aim-sugar-caffeine-alcohol-next.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13313449/Why-Rishi-Sunaks-mad-smoking-ban-destined-fail-Critics-warn-trailblazing-law-stop-Generation-Alpha-getting-hooked-cigarettes-prove-charter-criminals-amid-fears-health-chiefs-aim-sugar-caffeine-alcohol-next.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:33:59+00:00

Under the Prime Minister's hotly-contested proposal, being debated in parliament today, anyone born after 2009 won't ever be able to legally buy tobacco.

## Flight attendant reveals what your choice of travel outfit REALLY says about you - as she weighs in on the WORST ensembles plane passengers can wear
 - [https://www.dailymail.co.uk/femail/article-13277017/what-plane-outfit-says-you.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13277017/what-plane-outfit-says-you.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:33:39+00:00

Flight attendant Cher Killough, from Dallas, Texas, is going viral on TikTok for talking about what cabin crew really think about those who step onboard - especially what they are wearing.

## Your ultimate guide to bagging a Paris Olympics ticket: They go on sale tomorrow, here's how to see an event for less than 100 euros or even for FREE - and whether to book a hotel now or wait until the last minute
 - [https://www.dailymail.co.uk/money/mailplus/article-13313975/Your-ultimate-guide-bagging-Paris-Olympics-ticket-sale-tomorrow-heres-event-100-euros-FREE-book-hotel-wait-minute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mailplus/article-13313975/Your-ultimate-guide-bagging-Paris-Olympics-ticket-sale-tomorrow-heres-event-100-euros-FREE-book-hotel-wait-minute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:32:55+00:00

With tickets for the Olympics opening ceremony currently on sale for a cool £2,300,you may think it's too late to grab a bargain and go. But we've got some tips and tricks to help you save some cash.

## Traveler issues severe warning to any 'morning people' who want to visit Argentina - claiming the South American country 'will DESTROY' early risers
 - [https://www.dailymail.co.uk/travel/article-13289089/man-warning-morning-person-visiting-argentina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/travel/article-13289089/man-warning-morning-person-visiting-argentina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:31:15+00:00

Christian Grossi has become an online sensation by documenting his fun-filled life, which sees him traveling the world. He has shared a lesson about Argentina online.

## Budget-friendly car maker Dacia launches seven-year warranty - and it's available for used vehicles too
 - [https://www.dailymail.co.uk/money/cars/article-13314345/Budget-friendly-car-maker-Dacia-launches-seven-year-warranty-available-used-vehicles-too.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/cars/article-13314345/Budget-friendly-car-maker-Dacia-launches-seven-year-warranty-available-used-vehicles-too.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:29:03+00:00

Called Dacia Zen, it provides cover for up to seven years, as long as the owner has the vehicle serviced each year to allow for the warranty to roll-on.

## The top 100 most BORING tourist attractions in the world revealed: A railway trip in Missouri is No.1 while Shrek's Adventure London and FOUR Legoland parks make the top 25
 - [https://www.dailymail.co.uk/travel/article-13310853/Most-boring-attractions-world-Shrek-Adventure-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/travel/article-13310853/Most-boring-attractions-world-Shrek-Adventure-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:27:29+00:00

The study was drawn up by an analysis of 66.7 million Google reviews of 3,290 popular attractions worldwide. Read on for the full 100, with the top 10 plotted on MailOnline Travel's world map.

## Queen Camilla heads to Buckingham Palace where she will host young pioneers from domestic violence charity SafeLives as she returns to work following the Easter break
 - [https://www.dailymail.co.uk/femail/article-13314253/Queen-Camilla-heads-Buckingham-Palace-host-young-pioneers-domestic-violence-charity-SafeLives-returns-work-following-Easter-break.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13314253/Queen-Camilla-heads-Buckingham-Palace-host-young-pioneers-domestic-violence-charity-SafeLives-returns-work-following-Easter-break.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:26:42+00:00

The Queen, 76, smiled as she departed from Clarence House for Buckingham Palace today, where she will meet with representatives from the SafeLives charity.

## Cheryl argues with her Girls Aloud bandmates live on Radio 2 as hilarious video shows Scott Mills struggling to regain control of chaotic interview
 - [https://www.dailymail.co.uk/tvshowbiz/article-13313623/Cheryl-argues-Girls-Aloud-bandmates-live-Radio-2.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13313623/Cheryl-argues-Girls-Aloud-bandmates-live-Radio-2.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:25:23+00:00

Girls Aloud have insisted they 'don't do disagreements, just differences in opinions,' but things got hilariously heated during a radio interview.

## Woman, 24, who became a prostitute at AGE 15 to earn money for a PHONE lays bare her 'wild' experiences with 'old, unattractive' clients and 'violent pimps' - as she reveals how she finally turned her life around to become a married mom-of-one
 - [https://www.dailymail.co.uk/femail/article-13310685/prostitute-married-one-child-got-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13310685/prostitute-married-one-child-got-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:23:31+00:00

The anonymous Kansas-based mom-of-one took to Reddit to dish about the 'violence' she saw and experienced while working as an escort as a teenager. Pictured is a stock image.

## Adam Peaty insists he has 'nothing left to prove' after being named in Team GB's swimming squad for Paris Olympics as he bids to win third straight breaststroke gold following year away from the sport
 - [https://www.dailymail.co.uk/sport/othersports/article-13314327/Adam-Peaty-insists-left-prove-named-Team-GBs-swimming-squad-Paris-Olympics-bids-win-straight-breaststroke-gold-following-year-away-sport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/othersports/article-13314327/Adam-Peaty-insists-left-prove-named-Team-GBs-swimming-squad-Paris-Olympics-bids-win-straight-breaststroke-gold-following-year-away-sport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:15:42+00:00

Peaty, who stepped away from the sport a year ago due to fatigue and mental health concerns, will defend his Olympic title in the 100m breaststroke as one of a 33-strong Team GB swimming team.

## Bargain hunters boost B&M sales as former Wilko shops see brisk trade
 - [https://www.dailymail.co.uk/money/markets/article-13313761/Bargain-hunters-boost-B-M-sales-former-Wilko-shops-brisk-trade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/markets/article-13313761/Bargain-hunters-boost-B-M-sales-former-Wilko-shops-brisk-trade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:04:14+00:00

B&amp;M has already opened 47 new stores over the past year, having bought out some of Wilko's closed shops, which it said were 'performing ahead of expectations'.

## Jamie Oliver's Air Fryer Meals: Chef fails to impress in new Channel 4 series - as viewers brand the show 'desperate' and 'nowhere near reality'
 - [https://www.dailymail.co.uk/femail/article-13313475/Jamie-Olivers-Air-Fryer-Meals-viewers-blast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313475/Jamie-Olivers-Air-Fryer-Meals-viewers-blast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T12:03:00+00:00

The first episode of the Channel 4 programme broadcasted across the UK on Monday evening, but, unlike the nifty kitchen device that the 48-year-old represents, it's left viewers less than dazzled.

## The £213,000 I paid to HMRC has gone missing... and now it's going to charge me interest: SALLY SORTS IT
 - [https://www.dailymail.co.uk/money/mailplus/article-13313963/SALLY-SORTS-Help-money-paid-HMRC-gone-missing-going-charge-interest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mailplus/article-13313963/SALLY-SORTS-Help-money-paid-HMRC-gone-missing-going-charge-interest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:58:09+00:00

Dear Sally, I am at my wits' end with St James's Place. I am the executor of my friend's estate, who held investments with the firm. There is an inheritance tax bill of £800,000 to pay on his estate.

## Romantic moment a man uses plane PA system to propose to his girlfriend mid flight
 - [https://www.dailymail.co.uk/femail/article-13313729/Romantic-moment-man-proposes-girlfriend-mid-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313729/Romantic-moment-man-proposes-girlfriend-mid-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:45:55+00:00

In a video shared to TikTok, the unknown man can be seen talking into a PA system onboard Nigerian airline Air Peace, as he asks his intending fiancée to 'come out' of her seat and 'say yes' to him.

## Gathering of right-wing politicians in Brussels descends into chaos as police and local mayor 'attempt to shut down conference' with Nigel Farage lashing out at 'monstrous' efforts to silence speakers and warns: 'We are up against a new form of communism'
 - [https://www.dailymail.co.uk/news/article-13314255/Gathering-right-wing-politicians-Brussels-descends-chaos-police-local-mayor-attempt-shut-conference-Nigel-Farage-lashing-monstrous-efforts-silence-speakers-warns-against-new-form-communism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13314255/Gathering-right-wing-politicians-Brussels-descends-chaos-police-local-mayor-attempt-shut-conference-Nigel-Farage-lashing-monstrous-efforts-silence-speakers-warns-against-new-form-communism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:35:09+00:00

The ex-UKIP leader claimed police and a local mayor in the Belgian capital were attempting to cancel a 'National Conservatism' gathering.

## From amazing food to swanky hotels and electrifying sport - discovering that you don't HAVE to be into country music to enjoy a visit to Nashville (but it helps!)
 - [https://www.dailymail.co.uk/travel/article-13082483/Nashville-review-country-music-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/travel/article-13082483/Nashville-review-country-music-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:34:05+00:00

MailOnline's Jess Hamilton recalls a whirlwind weekend in Nashville. Drawn in by loud music and bright lights, she  found herself not only wanting to stay for that - but everything else too.

## Who is Roberto Cavalli's grieving girlfriend Sandra Nilsson? Swedish Playboy model, 38, spent a decade by the side of her 'favourite designer', 83, who bought her a private island - and once she said she didn't care about looks in a man
 - [https://www.dailymail.co.uk/femail/article-13313565/Who-Roberto-Cavallis-grieving-girlfriend-Sandra-Nilsson-Swedish-Playboy-model-38-spent-decade-favourite-designer-83-bought-private-island-said-didnt-care-looks-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313565/Who-Roberto-Cavallis-grieving-girlfriend-Sandra-Nilsson-Swedish-Playboy-model-38-spent-decade-favourite-designer-83-bought-private-island-said-didnt-care-looks-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:31:34+00:00

Among the mourners at designer Roberto Cavalli's funeral ceremony in Florence yesterday was his girlfriend Sandra Nilsson, a former Swedish model 45-year his junior.

## Homeless man, 26, who posed as a Good Samaritan to help drunken woman he found staggering across London park home before raping her is jailed
 - [https://www.dailymail.co.uk/news/article-13313901/homeless-man-posed-good-samaritan-raped-woman-london-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13313901/homeless-man-posed-good-samaritan-raped-woman-london-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:30:34+00:00

Louai Dahman preyed on the victim by posing as a chaperone, taking her on a bus from Green Park to her flat in South London, where he followed her inside and raped her, the court heard.

## The chemicals in your garage that may raise risk of incurable muscle-wasting disease that killed Stephen Hawking
 - [https://www.dailymail.co.uk/health/article-13310419/The-chemicals-garage-raise-risk-incurable-muscle-wasting-disease-killed-Stephen-Hawking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13310419/The-chemicals-garage-raise-risk-incurable-muscle-wasting-disease-killed-Stephen-Hawking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:28:44+00:00

Researchers found that storing chemicals - including gasoline, weed killer, pesticides, paint, and woodworking supplies - in a garage connected to the home may be linked to the development of ALS.

## The 15 revolutionary tiny tweaks that can turbocharge your health - from the simple way to lose half a stone to the tricks that slash your risk of cancer
 - [https://www.dailymail.co.uk/health/article-13314069/The-15-revolutionary-tiny-tweaks-turbocharge-health-simple-way-lose-half-stone-tricks-slash-risk-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13314069/The-15-revolutionary-tiny-tweaks-turbocharge-health-simple-way-lose-half-stone-tricks-slash-risk-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:25:37+00:00

When it comes to living more healthily, the expert consensus is changes to daily habits are more likely to produce long-lasting results. Unlike attempts at transformations they are easier to stick to.

## Aeroplane crisis summits, deceptive teamsheets and a blasé owner who thought the game was up - the secrets behind football's greatest comeback as Barcelona shocked the world to beat PSG 6-1
 - [https://www.dailymail.co.uk/sport/football/article-13310077/Barcelona-PSG-relived-comeback-shocked-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13310077/Barcelona-PSG-relived-comeback-shocked-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:23:37+00:00

PETE JENSON: Back in March 2017 they had won the first game 4-0 only for Barcelona to do what no team had ever done before and overturn a four-goal deficit with a 6-1 second-leg victory.

## Giant kangaroo twice the size of a human roamed Australia 5 million years ago, study reveals
 - [https://www.dailymail.co.uk/sciencetech/article-13313763/Giant-kangaroo-Australia-study-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13313763/Giant-kangaroo-Australia-study-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:21:45+00:00

Scientists from Flinders University have discovered three species of giant kangaroo that roamed Australia five million years ago, with the biggest growing to twice the size of a human.

## Grand Duke Henri of Luxembourg, 69, reveals that he 'intends to retire at some point' - and even knows the date he plans to hand the baton over to his son Guillaume
 - [https://www.dailymail.co.uk/femail/article-13313749/Grand-Duke-Henri-Luxembourg-69-reveals-intends-retire-point-knows-date-plans-hand-baton-son-Guillaume.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313749/Grand-Duke-Henri-Luxembourg-69-reveals-intends-retire-point-knows-date-plans-hand-baton-son-Guillaume.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:19:55+00:00

Speaking to La Libre , as reported by Point de Vue , the Luxembourg royal, 69, quipped that he knows the exact date he plans to pass the baton to his son Guillaume, 42 - but 'won't tell' the press yet.

## It was one of the most joyous - and most glamorous - royal visits of all time. So can YOU tell what's wrong with this magnificent photograph of the Queen?
 - [https://www.dailymail.co.uk/news/royals/article-13296809/Joyous-glamorous-royal-wrong-photograph-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/royals/article-13296809/Joyous-glamorous-royal-wrong-photograph-Queen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:10:46+00:00

This famous black and white panorama by photographer Bert Hardy captures the young Queen Elizabeth at the Paris opera house on her first state visit to France in April 1957.

## Rise of the middle-aged pension hunters: Forget tall, dark and handsome... These women are only after one thing from a chap - his supersized retirement fund!
 - [https://www.dailymail.co.uk/femail/article-13313713/Rise-middle-aged-pension-hunters-Forget-tall-dark-handsome-women-one-thing-chap-supersized-retirement-fund.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313713/Rise-middle-aged-pension-hunters-Forget-tall-dark-handsome-women-one-thing-chap-supersized-retirement-fund.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:07:10+00:00

Meet the Pension Hunters - single, divorced or widowed forty- or fifty-somethings, like Tracey (pictured), Helen and Sophie seeking a man in his 60s or beyond with a retirement plan.

## Happy sweet 16th, Princess Eléonore! King Philippe of Belgium's daughter is radiant as she poses for new portraits to mark her birthday
 - [https://www.dailymail.co.uk/femail/article-13313767/Happy-sweet-16th-Princess-El-onore-King-Philippe-Belgiums-daughter-radiant-poses-new-portraits-mark-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313767/Happy-sweet-16th-Princess-El-onore-King-Philippe-Belgiums-daughter-radiant-poses-new-portraits-mark-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:04:55+00:00

In the first of the new portraits, which were shared on the royal family 's official Instagram page, the 16-year-old sat on the grand staircase at Belgium's Palace of Laeken.

## Nigella Lawson, whose dinner party was once stormed by MI5 over fears for Salman Rushdie's life, pours praise on close friend's new book about 2022 knife attack - saying she rushed to buy it, and read it in one go
 - [https://www.dailymail.co.uk/femail/article-13313845/Nigella-Lawson-salman-rushdie-book-knife-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313845/Nigella-Lawson-salman-rushdie-book-knife-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:02:57+00:00

The TV cook, 64, has been friends with Salman Rushdie, 76, since she was in her early twenties, and used to cook for him while he was in hiding after a fatwa was placed on his head in 1988.

## Mesmerising charts show world's most and least populated countries over time - and how Britain has slipped down the rankings and out of the top 20
 - [https://www.dailymail.co.uk/health/article-13309391/Mesmerising-charts-worlds-populated-countries-time-Britain-slipped-rankings-20.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13309391/Mesmerising-charts-worlds-populated-countries-time-Britain-slipped-rankings-20.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T11:01:47+00:00

India, home to 1.41billion people, pips China to top spot, with its population having tripled in size since the 60s.Over a third of the world's residents live in one of the two nations.

## Lizzie Cundy slams 'sensitive and overdramatic' Hannah Waddingham after she berated a photographer for asking her to 'show some leg'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13313769/Lizzie-Cundy-overdramatic-Hannah-Waddingham-berated-photogapher.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13313769/Lizzie-Cundy-overdramatic-Hannah-Waddingham-berated-photogapher.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:56:37+00:00

The TV personality, 55, insisted the actress 'should have worn a trouser suit' if she didn't want to show her legs at the event, after Hannah was filmed berating a photographer at the Olivier Awards.

## Tiger Woods sends 'cease and desist' order to new play-and-party golf course in North Wales... but the owner calls it a 'COMPLIMENT' that the Anglesey venue caught the icon's eye!
 - [https://www.dailymail.co.uk/sport/golf/article-13313625/Tiger-Woods-sends-cease-desist-order-new-play-party-golf-course-North-Wales-owner-calls-COMPLIMENT-Anglesey-venue-caught-icons-eye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/golf/article-13313625/Tiger-Woods-sends-cease-desist-order-new-play-party-golf-course-North-Wales-owner-calls-COMPLIMENT-Anglesey-venue-caught-icons-eye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:53:56+00:00

A trademark firm representing Tiger Woods has issued a 'cease and desist' letter to a Welsh golf course over concerns that fans may be misled by a similar name to one of his ventures.

## Ivy Getty and Tobias Engel divorce: Inside the couple's 3-day San Francisco wedding attended by Anya Taylor-Joy and officiated by Nancy Pelosi as the pair call time on their marriage
 - [https://www.dailymail.co.uk/femail/article-13313451/Ivy-Getty-Tobias-Engel-divorce-Inside-couples-3-day-San-Francisco-wedding-attended-Anya-Taylor-Joy-officiated-Nancy-Pelosi-pair-call-time-marriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313451/Ivy-Getty-Tobias-Engel-divorce-Inside-couples-3-day-San-Francisco-wedding-attended-Anya-Taylor-Joy-officiated-Nancy-Pelosi-pair-call-time-marriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:35:07+00:00

The New York-based model, 29, filed for divorce in January, Page Six reports, after hosting a three-day extravaganza for her wedding to Tobias in November 2021.

## Olympic torch is lit in spectacular ceremony in ancient Olympia to mark 100-day countdown for the Paris 2024 Games... with flame to arrive in France next month ahead of July 26 opening ceremony
 - [https://www.dailymail.co.uk/sport/olympics/article-13313865/Olympic-Games-Paris-torch-Olympia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/olympics/article-13313865/Olympic-Games-Paris-torch-Olympia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:33:54+00:00

The torch for the Paris 2024 Olympic Games was lit in ancient Olympia in a traditional ceremony on Tuesday, marking the final stretch of the seven-year preparations for the Games' start on July 26.

## WhatsApp has made a subtle change that has left users FURIOUS - as one vents 'it's hurting my soul'
 - [https://www.dailymail.co.uk/sciencetech/article-13313891/WhatsApp-change-users-furious.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13313891/WhatsApp-change-users-furious.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:30:45+00:00

Users have been left furious following a subtle change within the app.
'Online' and 'Typing' - words displayed under the other user's name in your chats - now have a capital 'O' and a capital 'T'.

## William announces first public engagement since Kate Middleton's cancer diagnosis: Prince of Wales will visit food charity in Surrey and youth centre in west London on Thursday as the Princess continues recovery at home
 - [https://www.dailymail.co.uk/news/article-13314043/William-announces-public-engagement-Kate-Middletons-cancer-diagnosis-Prince-Wales-visit-food-charity-Surrey-youth-centre-west-London-Thursday-Princess-continues-recovery-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13314043/William-announces-public-engagement-Kate-Middletons-cancer-diagnosis-Prince-Wales-visit-food-charity-Surrey-youth-centre-west-London-Thursday-Princess-continues-recovery-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:29:24+00:00

The Prince of Wales will visit Surrey and West London this Thursday to highlight the community and environmental impact that organisations in the area are having through their work.

## Ex-Playboy model Karen McDougal who claims she had a ten month affair with former President is cleared to testify at his hush-money trial
 - [https://www.dailymail.co.uk/news/article-13314063/Karen-McDougal-playboy-model-trump-stormy-daniels-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13314063/Karen-McDougal-playboy-model-trump-stormy-daniels-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:29:05+00:00

Five months before the 2016 presidential election, American Media Inc, the publisher of the National Enquirer, paid Karen McDougal, 53, $150,000 in exchange for her tell all story.

## Woman who is CEO of her own six-figure business at 23 reveals her high school bullies now apply to work for her - and how she dealt with one who once poured ketchup over her head
 - [https://www.dailymail.co.uk/femail/article-13313463/Young-CEO-high-school-bullies-apply-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313463/Young-CEO-high-school-bullies-apply-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:17:51+00:00

Vicky Owens, from Stockport in Greater Manchester, is the founder of Alderley Edge-based Socially Speaking Media, a thriving six-figure business.

## Family of Irish teacher jailed for refusing to 'call a boy a girl' face their own legal woes: Enoch Burke's brother has conviction for breach of the peace struck out - but his father will be tried for assaulting a police officer
 - [https://www.dailymail.co.uk/femail/article-13313471/enoch-burke-family-legal-battle-trans-rights-row-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13313471/enoch-burke-family-legal-battle-trans-rights-row-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:12:10+00:00

He's been at the centre of a trans rights scandal in Ireland for the past two years - and now Enoch Burke's father and brother have become embroiled in their own legal battles.

## How secret to tackling menopause may be muscle-building supplement loved by gym bros
 - [https://www.dailymail.co.uk/health/article-13309525/gym-goers-supplement-tackling-menopause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13309525/gym-goers-supplement-tackling-menopause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T10:02:32+00:00

Creatine - gym-bros' favourite muscle-building supplement - could be the secret to beating some of the most dramatic results of the menopause, says Rob Hobson, sports and registered nutritionist.

## I flew from Scotland to Denmark for 24 hours for a family trip to Legoland - the flights were £30 and it was £180 cheaper than going to Windsor
 - [https://www.dailymail.co.uk/travel/article-13313465/Family-flew-Legoland-Denmark-save.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/travel/article-13313465/Family-flew-Legoland-Denmark-save.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T09:36:02+00:00

Nicola, 46, and her husband Alan Sutcliffe, 57, from Glasgow took their son Matthew, 8, to Legoland Billund after realising it was cheaper than going to Legoland Windsor.

## Blue Lights' 'beautifully tense' second series is lauded by critics for 'skipping effortlessly from comedy to breakneck drama' as the police thriller returns with 'first-rate' opener
 - [https://www.dailymail.co.uk/tvshowbiz/article-13313541/Blue-Lights-series-two-praised-critics-BBC-returns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13313541/Blue-Lights-series-two-praised-critics-BBC-returns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T09:23:27+00:00

The BBC series returned to screens on Monday night after its debut run became a sleeper hit, and has already been renewed for series three and four.

## I'm a vet and here are my 5 unpopular opinions about pet ownership - and the bad habit that gives me the ick
 - [https://www.dailymail.co.uk/femail/article-13310549/Vet-unpopular-opinions-pet-ownership.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13310549/Vet-unpopular-opinions-pet-ownership.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T09:23:10+00:00

British vet and TikTokker Ben the Vet has revealed five unpopular opinions he has about pet ownership - from feeding pets raw meat to calling them your children.

## Embarrassing moment Chelsea's Noni Madueke snatches the ball and rollicks Nicolas Jackson in row over penalty-taking duties is revealed in new extended footage - before Cole Palmer pulls rank
 - [https://www.dailymail.co.uk/sport/football/article-13313453/Noni-Madueke-Nicolas-Jackson-Chelsea-penalty-spat-Conor-Gallagher-Cole-Palme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13313453/Noni-Madueke-Nicolas-Jackson-Chelsea-penalty-spat-Conor-Gallagher-Cole-Palme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T09:20:55+00:00

The embarrassing moment, in the 64th minute of Chelsea's 6-0 thrashing of Everton on Monday night, left manager Mauricio Pochettino furious.

## The shocking extent of Britain's plastic crisis: 1.7 BILLION pieces of rubbish are thrown away by UK households every week, study reveals
 - [https://www.dailymail.co.uk/sciencetech/article-13313413/Britains-plastic-crisis-rubbish-study.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13313413/Britains-plastic-crisis-rubbish-study.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T09:20:53+00:00

A shocking report has laid bare Britain's plastic crisis, with households throwing away a whopping 1.7 billion pieces of rubbish every week.

## Blue Lights fans praise 'phenomenal' season two premiere as 'off the scale brilliant' and admit they're struggling not to binge watch whole series: 'The Line of Duty replacement we needed'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13313503/Blue-Lights-fans-praise-phenomenal-season-two-premiere-scale-brilliant-admit-theyre-struggling-not-binge-watch-series-Line-Duty-replacement-needed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13313503/Blue-Lights-fans-praise-phenomenal-season-two-premiere-scale-brilliant-admit-theyre-struggling-not-binge-watch-series-Line-Duty-replacement-needed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T09:02:23+00:00

The gripping police drama follows three rookie cops in Belfast as they try to keep the peace in the post-Troubles era.

## What are the 10 best and cheapest used cars for young drivers to buy?
 - [https://www.dailymail.co.uk/money/cars/article-13310575/What-10-best-cheapest-used-cars-young-drivers-buy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/cars/article-13310575/What-10-best-cheapest-used-cars-young-drivers-buy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T08:47:11+00:00

The Citroen C1 has been crowned the best second hand car for Gen Z drivers (those aged 17-27), according to a new study. Cars were ranked on cost, insurance, safety and mpg.

## Family faces £8,000-a-DAY hospital bills after uninsured British tourist, 32, falls into mystery coma in Cambodia: Parents fly out and 'have already paid out more than £60,000'
 - [https://www.dailymail.co.uk/news/article-13313501/Family-faces-8-000-DAY-hospital-bills-uninsured-British-tourist-32-falls-mystery-coma-Cambodia-Parents-fly-paid-60-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13313501/Family-faces-8-000-DAY-hospital-bills-uninsured-British-tourist-32-falls-mystery-coma-Cambodia-Parents-fly-paid-60-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T08:18:06+00:00

Ben Wilkins, 32, from Chinley in Derbyshire, was just two weeks into his holiday to the island of Koh Rong when he fell sick.

## British tourist is left in intensive care after being bitten by venomous snake during meditation session while on holiday to Cyprus to mark her 40th birthday
 - [https://www.dailymail.co.uk/news/article-13313385/venomous-snake-bite-british-tourist-cyprus-intensive-care.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13313385/venomous-snake-bite-british-tourist-cyprus-intensive-care.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T08:12:28+00:00

Sam West, from Shifnal, in Shropshire, was bitten by a 1.5m-long blunt nosed viper on April 3 as she was getting ready to start a meditation session at the Atlantica Aphrodite Hills hotel.

## Apprentice fans surprised to see cameraman filming from a wheelchair - and question why show is using 'budget' option instead of high tech equipment
 - [https://www.dailymail.co.uk/femail/article-13310235/bbc-apprentice-wheelchair-filming-budget-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13310235/bbc-apprentice-wheelchair-filming-budget-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T08:07:56+00:00

A video posted on TikTok shows a candidate from The Apprentice strolling while pulling a suitcase next to the River Thames by Tower Bridge in London.

## Naomi Watts and her youngest child Kai, 15, look the spitting image of one another as they step out in glamorous gowns during Dior fashion show
 - [https://www.dailymail.co.uk/tvshowbiz/article-13312931/Naomi-Watts-child-Kai-identical-Dior-fashion-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13312931/Naomi-Watts-child-Kai-identical-Dior-fashion-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T08:03:12+00:00

Naomi Watts and her youngest child Kai were two peas in a pod on Monday as they stepped out in stylish dresses at the Dior pre-fall fashion show in Brooklyn.

## Louise Thompson reveals her son Leo, two, is 'fascinated' by her stoma bag as she says people could 'learn from their children' who are unaffected by 'awkward and taboo' subjects
 - [https://www.dailymail.co.uk/tvshowbiz/article-13313417/Louise-Thompson-reveals-son-Leo-two-fascinated-stoma-bag-says-people-learn-children-unaffected-awkward-taboo-subjects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13313417/Louise-Thompson-reveals-son-Leo-two-fascinated-stoma-bag-says-people-learn-children-unaffected-awkward-taboo-subjects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T08:02:20+00:00

Louise Thompson has sweetly shared how her son Leo is 'fascinated' by her stoma bag after she had one fitted after years of suffering with ulcerative colitis.

## How Holby City alum Jing Lusi went from soap star to Hollywood sensation: Actress, 38, who adopted 'wild and erratic' persona in school to defy stereotypes about East Asians and ditched plans for a law career to pursue acting is ITV's latest action hero
 - [https://www.dailymail.co.uk/femail/article-13310403/Holby-City-Jing-Lusi-Hollywood-ITV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13310403/Holby-City-Jing-Lusi-Hollywood-ITV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T07:22:34+00:00

Jing Lusi has risen from soap star to flourishing Hollywood sensation, with roles in huge ensemble films including Argylle and Crazy Rich Asians in her repertoire.

## National Portrait Gallery is facing backlash after wrongly claiming art dealer used slaves to 'establish and sustain' his career
 - [https://www.dailymail.co.uk/news/article-13313279/National-Portrait-Gallery-backlash-wrongly-claiming-art-dealer-used-slaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13313279/National-Portrait-Gallery-backlash-wrongly-claiming-art-dealer-used-slaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T07:14:47+00:00

Donald Gajadhar, the great-great-grandson of art dealer Edward Fox White, spotted the slur when he visited the gallery last summer.

## The sweet stuff! Meghan unveils first product from new lifestyle collection American Riviera Orchard with 50 influencers sent her strawberry jam - including fashion designer Tracy Robbins and Argentine socialite Delfina Balquier
 - [https://www.dailymail.co.uk/news/article-13313341/Meghan-Markle-American-Riviera-Orchard-product-jam-Prince-Harry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13313341/Meghan-Markle-American-Riviera-Orchard-product-jam-Prince-Harry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T07:13:08+00:00

Fashion designer Tracy Robbins and Argentine socialite Delfina Balquier are among those who have posted an image of Meghan's American Riviera Orchard product on their Instagram Stories.

## Relief for Brits as wages outstrip inflation by biggest margin since 2021 despite signs jobs market is weakening… but inactivity crisis deepens
 - [https://www.dailymail.co.uk/news/article-13313367/Wages-inflation-jobs-market-employment-pay-inactivity-economy-Chancellor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13313367/Wages-inflation-jobs-market-employment-pay-inactivity-economy-Chancellor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T07:05:44+00:00

Regular pay rose by 2.1 per cent year-on-year in real terms in the three months to February. That was the highest rate since September 2021, reflecting easing prices.

## The enormous stellar black hole hiding in Earth's backyard: Scientists discover a huge void in the Milky Way that's 33 times as massive as the Sun
 - [https://www.dailymail.co.uk/sciencetech/article-13310197/black-hole-milky-way-33-times-massive-sun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-13310197/black-hole-milky-way-33-times-massive-sun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T07:00:46+00:00

A black hole called Gaia BH3 is 'extremely' close to us, astronomically speaking, according to experts at the Paris Observatory in France.

## Hilarious voice to text messages that'll make you wish people still used landlines
 - [https://www.dailymail.co.uk/femail/article-13310539/Hilarious-voice-text-messages-thatll-make-wish-stuck-landlines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13310539/Hilarious-voice-text-messages-thatll-make-wish-stuck-landlines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T06:45:48+00:00

People from around the world have shared hilarious voice text mishaps and BuzzFeed collated some of the best into an online gallery.

## Surf legend Kelly Slater chokes back tears and gets emotional about his family after loss in Australia ends his incredible career
 - [https://www.dailymail.co.uk/sport/othersports/article-13313147/Kelly-Slater-retires-Margaret-River-Western-Australia-Griffin-Colapinto.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/othersports/article-13313147/Kelly-Slater-retires-Margaret-River-Western-Australia-Griffin-Colapinto.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T06:33:08+00:00

Surfing legend Kelly Slater was close to being overcome with emotion after getting knocked out of the Margaret River Pro competition in Western Australia on Tuesday.

## Dele Alli reveals he is targeting playing at the 2026 World Cup for England as injured star insists he wants to stay in the Premier League despite Everton contract expiring this summer
 - [https://www.dailymail.co.uk/sport/football/article-13312367/Dele-Alli-reveals-targeting-playing-2026-World-Cup-England-injured-star-insists-wants-stay-Premier-League-despite-Everton-contract-expiring-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-13312367/Dele-Alli-reveals-targeting-playing-2026-World-Cup-England-injured-star-insists-wants-stay-Premier-League-despite-Everton-contract-expiring-summer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T06:14:46+00:00

Dele Alli has revealed his ambitions to play for England at the 2026 World Cup, despite not featuring in a single game this season for Everton.

## Brave decisions, a historic abdication - and an outlandish rain mac that she designed herself from a wipe-clean  tablecloth...Happy birthday Margrethe of Denmark, Queen of colour!
 - [https://www.dailymail.co.uk/news/royals/article-13297475/Abdication-outlandish-mac-designed-Margrethe-Denmark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/royals/article-13297475/Abdication-outlandish-mac-designed-Margrethe-Denmark.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T06:00:46+00:00

The Danish nation is still getting used to the fact that the long-reigning queen is now an ex-monarch, following her shock New Year's Eve announcement that she would step aside.

## Billionaire oil heiress Ivy Getty files for DIVORCE from husband Tobias Engel after four years of marriage
 - [https://www.dailymail.co.uk/tvshowbiz/article-13313077/Ivy-Getty-files-DIVORCE-husband-Tobias-Engel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13313077/Ivy-Getty-files-DIVORCE-husband-Tobias-Engel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T05:51:37+00:00

Billionaire heiress Ivy Love Getty - the great-granddaughter of oil tycoon J. Paul Getty - has filed for divorce from her husband Tobias 'Toby' Engel.

## A pension 'pot for life' would be popular, but many savers worry about making poor choices
 - [https://www.dailymail.co.uk/money/pensions/article-13264269/Pension-pot-life-popular-savers-worry-poor-choices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/pensions/article-13264269/Pension-pot-life-popular-savers-worry-poor-choices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T05:00:52+00:00

The Government is looking into whether to allow savers to open a pension that all current and future employers can pay into throughout their working lives.

## What to do in a dispute with the taxman: HEATHER ROGERS explains
 - [https://www.dailymail.co.uk/money/bills/article-13310731/Dispute-taxman-HEATHER-ROGERS-explains.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/bills/article-13310731/Dispute-taxman-HEATHER-ROGERS-explains.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T05:00:49+00:00

You might find yourself, or your business, the subject of a tax enquiry even if you believe you did nothing wrong. Or, HMRC might have aggrieved you! Our tax expert Heather Rogers explains what to do...

## Are landlords in crisis? We reveal how higher mortgage rates are impacting buy-to-let investors
 - [https://www.dailymail.co.uk/money/buytolet/article-13301267/Are-landlords-crisis-reveal-higher-mortgage-rates-impacting-buy-let-investors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/buytolet/article-13301267/Are-landlords-crisis-reveal-higher-mortgage-rates-impacting-buy-let-investors.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T05:00:46+00:00

The buy-to-let market has been battered by rising mortgage rates - but for many landlords this just means a good buying opportunity.

## Spy Kids star Alexa PenaVega and husband Carlos share tragic news about stillbirth of fourth baby: 'It has been a painful journey'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13312345/Alexa-PenaVega-suffers-stillbirth-fourth-baby-husband-Carlos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13312345/Alexa-PenaVega-suffers-stillbirth-fourth-baby-husband-Carlos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T03:54:01+00:00

The couple announced the devastating news in a joint Instagram post on Monday, writing that losing their baby 'has been a painful journey.'

## Read the sick texts cricket commentator Michael Slater allegedly sent woman he is accused of bashing and threatening to kill - as he collapses in court
 - [https://www.dailymail.co.uk/sport/cricket/article-13312567/Michael-Slater-allegedly-bashed-threatened-kill-woman-breaking-home-court-charges-collapse-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/cricket/article-13312567/Michael-Slater-allegedly-bashed-threatened-kill-woman-breaking-home-court-charges-collapse-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T03:36:55+00:00

The 54-year-old former cricket star is facing 19 charges including breaking into a dwelling with intent at night, common assault, assault occasioning bodily harm and choking or suffocation.

## How is the Red Sea crisis affecting British companies?
 - [https://www.dailymail.co.uk/money/markets/article-13275877/How-Red-Sea-crisis-affecting-British-companies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/markets/article-13275877/How-Red-Sea-crisis-affecting-British-companies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T02:00:49+00:00

Many shipping companies have halted all transit through the Suez Canal amid threats of attacks by the Houthis, a militant organisation controlling much of Yemen.

## I lost £900 to Booking.com scam: Holidaymakers warned of fraud ahead of summer rush
 - [https://www.dailymail.co.uk/money/beatthescammers/article-13310643/I-lost-900-Booking-com-scam-Holidaymakers-warned-fraud-ahead-summer-rush.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/beatthescammers/article-13310643/I-lost-900-Booking-com-scam-Holidaymakers-warned-fraud-ahead-summer-rush.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T02:00:46+00:00

Customers of Booking.com have told how they lost money after falling for a convincing fraud perpetrated through the website's messaging app.

## Henry Cavill reveals he is expecting first child with girlfriend Natalie Viscuso: 'I'm very excited about it'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13312627/Henry-Cavill-expecting-child-girlfriend-Natalie-Viscuso.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13312627/Henry-Cavill-expecting-child-girlfriend-Natalie-Viscuso.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T01:49:19+00:00

The star, 40, shared the joyous news with Access Hollywoo d at the premiere of Ministry of Ungentlemanly Warfare on Monday.

## Taylor Swift enjoys another loved-up moment with boyfriend Travis Kelce as duo dance in the crowd at Coachella
 - [https://www.dailymail.co.uk/tvshowbiz/article-13311967/Taylor-Swift-enjoys-loved-moment-boyfriend-Travis-Kelce-Coachella.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13311967/Taylor-Swift-enjoys-loved-moment-boyfriend-Travis-Kelce-Coachella.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T01:09:45+00:00

The couple were spotted sharing a loving moment as they watched one of the acts perform from the midst of the crowd.

## Mackenzie Crook, 52, is dwarfed by  lookalike son Jude, 21, as they make a rare public appearance at the UK premiere of Jeanne du Barry
 - [https://www.dailymail.co.uk/tvshowbiz/article-13312421/Mackenzie-Crook-son-Jude-rare-Jeanne-Barry-premiere.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13312421/Mackenzie-Crook-son-Jude-rare-Jeanne-Barry-premiere.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T01:08:30+00:00

The Game of Thrones star, 52, made a rare appearance with his much taller son Jude, 21, as they attended the UK premiere of Jeanne du Barry at The Curzon Mayfair.

## Britain's Got Talent head judge Simon Cowell claims he has already 'worked out who will win' ahead of new series - as he admits 'there was one person everyone gravitated towards'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13312331/Britain-Got-Talent-Simon-Cowell-works-winner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13312331/Britain-Got-Talent-Simon-Cowell-works-winner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T01:07:59+00:00

It seems the judge, 64, has already worked out who might win the new series, as his fellow judges all eyed the same performer.

## Horoscope today: Daily guide to what the stars have in store for YOU - April 16, 2024
 - [https://www.dailymail.co.uk/femail/horoscopes/article-13310851/horoscope-today-daily-star-sign-april-16-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/horoscopes/article-13310851/horoscope-today-daily-star-sign-april-16-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T01:00:49+00:00

OSCAR CAINER: As we build towards the Jupiter and Uranus convergence, Venus (love) is colouring mysterious Pluto's influence.

## To destroy Iran's nuclear threat, Israel should attack its missile launch sites
 - [https://www.dailymail.co.uk/debate/article-13311933/Iran-nuclear-threat-Israel-attack-missile-launch-Mark-Almond.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-13311933/Iran-nuclear-threat-Israel-attack-missile-launch-Mark-Almond.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:54:04+00:00

Israel 's Prime Minister ­ Benjamin Netanyahu may feel he faces an impossible dilemma following the successful neutralisation of Iran 's missile and drone onslaught over the weekend.

## Zendaya, the 'It Girl next door' who still shops at her local Waitrose
 - [https://www.dailymail.co.uk/femail/article-13311651/zendaya-girl-door-shops-waitrose-vogue-cover-tom-holland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-13311651/zendaya-girl-door-shops-waitrose-vogue-cover-tom-holland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:51:37+00:00

Every era has its stars. In the 1950s, those talents who made it, such as Marilyn Monroe and Elvis Presley, remain household names.

## The police investigation into Angela Rayner MUST not be in Manchester
 - [https://www.dailymail.co.uk/columnists/article-13311657/nadine-dorries-police-investigation-angela-rayner-not-manchester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/columnists/article-13311657/nadine-dorries-police-investigation-angela-rayner-not-manchester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:45:51+00:00

When Angela Rayner last week said she'd do the 'right thing' and resign if a police investigation into her former living arrangements found that she had broken the law, I was instantly suspicious.

## The expert guide to spending a penny: How often is too often? Why swimming makes you want to go. And how many seconds is the ideal duration
 - [https://www.dailymail.co.uk/health/article-13311359/expert-guide-peeing-swimming-ideal-duration-urine-spend-penny.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13311359/expert-guide-peeing-swimming-ideal-duration-urine-spend-penny.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:42:48+00:00

We MOSTLY do it without thinking. Yet experts say when - and how - we urinate can reflect or even improve our general health.

## How this A Place In The Sun presenter had to be talked down from a building after doctors misdiagnosed her and gave her antidepressants
 - [https://www.dailymail.co.uk/health/article-13310193/How-Place-Sun-tv-channel-four-presenter-suicidal-jump-building-misdiagnosed-antidepressants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13310193/How-Place-Sun-tv-channel-four-presenter-suicidal-jump-building-misdiagnosed-antidepressants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:42:40+00:00

Her GP diagnosed depression and put her on antidepressants, but they didn't seem to help, and there was a reason for that - she didn't have depression.

## Fantastic fangs and where to whiten them! Johnny Depp bares his yellowing teeth at Jeanne du Barry premiere - after fans trolled Hollywood legend for poor dental hygiene
 - [https://www.dailymail.co.uk/tvshowbiz/article-13312019/Fantastic-fangs-whiten-Johnny-Depp-bares-yellowing-teeth-Jeanne-du-Barry-premiere-fans-trolled-Hollywood-legend-poor-dental-hygiene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13312019/Fantastic-fangs-whiten-Johnny-Depp-bares-yellowing-teeth-Jeanne-du-Barry-premiere-fans-trolled-Hollywood-legend-poor-dental-hygiene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:40:42+00:00

Now significantly older, Johnny Depp was clearly none the wiser on Monday evening as he revealed a set of yellowing teeth that only Captain Jack Sparrow could be proud of.

## Sir Paul McCartney 'had steamy threesome with two fans for a full three days at luxury Beverly Hills Hotel during The Beatles heyday'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13312191/paul-mccartney-threesome-fans-beatles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13312191/paul-mccartney-threesome-fans-beatles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:25:57+00:00

Sir Paul McCartney allegedly had a threesome with two female fans for a full three days during The Beatles' heyday.

## Taylor Swift's Coachella conversations with Travis Kelce revealed: Lip reader breaks down what pop star said at the iconic music festival
 - [https://www.dailymail.co.uk/tvshowbiz/article-13312229/Taylor-Swifts-Coachella-conversations-Travis-Kelce-revealed-TikToker-lip-reads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13312229/Taylor-Swifts-Coachella-conversations-Travis-Kelce-revealed-TikToker-lip-reads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:18:56+00:00

Jackie Gonzalez, a deaf TikToker, has shared what Swift, 34, allegedly said in a series of videos taken from the festival.

## Bombshell Raquel Welch's iconic wardrobe from the golden years of Hollywood sells for $1 million dollars at auction
 - [https://www.dailymail.co.uk/news/article-13312361/Bombshell-Raquel-Welchs-iconic-wardrobe-golden-years-Hollywood-sells-1-million-dollars-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13312361/Bombshell-Raquel-Welchs-iconic-wardrobe-golden-years-Hollywood-sells-1-million-dollars-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:17:32+00:00

The late actress Raquel Welch (pictured) was a much-loved American bombshell who took the world by storm during the golden years of Hollywood.

## Annabel Croft will pay tribute to late husband Mel Coleman by travelling North Yorkshire in a campervan for new This Morning role - after couple planned to explore Britain in a converted van before his death
 - [https://www.dailymail.co.uk/tvshowbiz/article-13312279/Annabel-Croft-pay-tribute-late-husband-Mel-Coleman-travelling-North-Yorkshire-campervan-new-Morning-role-couple-planned-explore-Britain-converted-van-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13312279/Annabel-Croft-pay-tribute-late-husband-Mel-Coleman-travelling-North-Yorkshire-campervan-new-Morning-role-couple-planned-explore-Britain-converted-van-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:10:28+00:00

The former tennis star, 57, will present a three-part series on the ITV show called Camper Vannabel, where she will explore North Yorkshire.

## Legendary BBC game show could return to screens after 15 YEARS with a new reboot that 'could spark bidding war between big companies'
 - [https://www.dailymail.co.uk/tvshowbiz/article-13311929/BBC-Hole-Wall-reboot-bidding-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13311929/BBC-Hole-Wall-reboot-bidding-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/home/index.rss
 - date published: 2024-04-16T00:07:08+00:00

Iconic cult game A Hole In The Wall has been eyed for a new reboot, 15 years since its last series, and might 'spark a bidding war between companies'.

