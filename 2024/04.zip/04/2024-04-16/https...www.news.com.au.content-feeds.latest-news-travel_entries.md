# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## ‘Horrible’: Fresh warning for Aussies in Bali
 - [https://www.news.com.au/travel/travel-updates/warnings/dfat-issues-fresh-advice-as-dengue-fever-cases-rise-in-bali/news-story/5e186ecc30df1cd1ffa662da0a0d0fcd?from=rss-basic](https://www.news.com.au/travel/travel-updates/warnings/dfat-issues-fresh-advice-as-dengue-fever-cases-rise-in-bali/news-story/5e186ecc30df1cd1ffa662da0a0d0fcd?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-04-16T08:18:04.706615+00:00

Aussie tourists are falling sick from a common but dangerous illness in the tropical tourism mecca.

## Mum’s horror 5m plunge at camp site
 - [https://www.news.com.au/travel/travel-updates/incidents/doctors-dreaded-words-to-mum-after-five-metre-fall/news-story/65c6640d40916417793d1ac659b11a3c?from=rss-basic](https://www.news.com.au/travel/travel-updates/incidents/doctors-dreaded-words-to-mum-after-five-metre-fall/news-story/65c6640d40916417793d1ac659b11a3c?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-04-16T05:02:56.454654+00:00

An Australian mum is paralysed from the waist down after she fell off a cliff at a camp site while holidaying with family.

## ‘Dirty trick’: Bali tourist scam strikes again
 - [https://www.news.com.au/travel/travel-updates/warnings/dirty-trick-bali-tourist-scam-strikes-again/news-story/621c890ae2958017b9b092bcf1865fe9?from=rss-basic](https://www.news.com.au/travel/travel-updates/warnings/dirty-trick-bali-tourist-scam-strikes-again/news-story/621c890ae2958017b9b092bcf1865fe9?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-04-16T02:52:54.375049+00:00

A tourist has been caught on film confronting a money-exchange teller after claiming the staffer had cut her short when handing the cash over.

