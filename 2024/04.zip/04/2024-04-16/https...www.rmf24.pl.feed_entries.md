# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Piłkarska LM. PSG w półfinale z Borussią Dortmund
 - [https://www.rmf24.pl/sport/news-pilkarska-lm-psg-w-polfinale-z-borussia-dortmund,nId,7455289](https://www.rmf24.pl/sport/news-pilkarska-lm-psg-w-polfinale-z-borussia-dortmund,nId,7455289)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T21:54:51+00:00

<p><a href="https://www.rmf24.pl/sport/news-pilkarska-lm-psg-w-polfinale-z-borussia-dortmund,nId,7455289"><img align="left" alt="Piłkarska LM. PSG w półfinale z Borussią Dortmund " src="https://interia-s.pluscdn.pl/pilkarska-lm-psg-w-polfinale-z-borussia-dortmund/000IYTZN5EO6VVSD-C307.jpg" /></a>Piłkarze Barcelony, z Robertem Lewandowskim w składzie, przegrali u siebie z Paris Saint-Germain 1:4 i odpadli w ćwierćfinale Ligi Mistrzów. Pierwsze spotkanie wygrali na wyjeździe 3:2. Rywalem PSG w półfnale będzie Borussia Dortmund, która pokonała w rewanżu Atletico Madryt 4:2.</p><br clear="all" />

## Adwokatka ze Słupska skazana za usiłowanie zabójstwa
 - [https://www.rmf24.pl/regiony/trojmiasto/news-adwokatka-ze-slupska-skazana-za-usilowanie-zabojstwa,nId,7455264](https://www.rmf24.pl/regiony/trojmiasto/news-adwokatka-ze-slupska-skazana-za-usilowanie-zabojstwa,nId,7455264)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T20:55:19+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-adwokatka-ze-slupska-skazana-za-usilowanie-zabojstwa,nId,7455264"><img align="left" alt="Adwokatka ze Słupska skazana za usiłowanie zabójstwa " src="https://interia-s.pluscdn.pl/adwokatka-ze-slupska-skazana-za-usilowanie-zabojstwa/000IYTSMYGCF5GTQ-C307.jpg" /></a>Na 10 lat i 6 miesięcy pozbawienia wolności skazał sąd 41-letnią adwokatkę Katarzynę R. Uznał oskarżoną winną wszystkich zarzucanych jej czynów, w tym usiłowania zabójstwa. Wyrok nie jest prawomocny.</p><br clear="all" />

## Zabójstwo w Jagatowie. Prokuratura ujawnia nowe informacje
 - [https://www.rmf24.pl/regiony/trojmiasto/news-zabojstwo-w-jagatowie-prokuratura-ujawnia-nowe-informacje,nId,7455259](https://www.rmf24.pl/regiony/trojmiasto/news-zabojstwo-w-jagatowie-prokuratura-ujawnia-nowe-informacje,nId,7455259)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T20:32:35+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-zabojstwo-w-jagatowie-prokuratura-ujawnia-nowe-informacje,nId,7455259"><img align="left" alt="Zabójstwo w Jagatowie. Prokuratura ujawnia nowe informacje" src="https://interia-s.pluscdn.pl/zabojstwo-w-jagatowie-prokuratura-ujawnia-nowe-informacje/000IYTRBVX2G5CAF-C307.jpg" /></a>Wtorek był trzecim dniem poszukiwań 43-letniego Rafała Zyski, podejrzanego o zabójstwo żony. Prokuratura po sekcji zwłok kobiety podała, że na jej ciele były liczne rany kłute. Przyczyną śmierci był masywny krwotok.</p><br clear="all" />

## Dziennik powstańczy Aliny Janowskiej. "Gotowy scenariusz na film"
 - [https://www.rmf24.pl/regiony/warszawa/news-dziennik-powstanczy-aliny-janowskiej-gotowy-scenariusz-na-fi,nId,7455247](https://www.rmf24.pl/regiony/warszawa/news-dziennik-powstanczy-aliny-janowskiej-gotowy-scenariusz-na-fi,nId,7455247)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T19:24:53+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-dziennik-powstanczy-aliny-janowskiej-gotowy-scenariusz-na-fi,nId,7455247"><img align="left" alt="Dziennik powstańczy Aliny Janowskiej. &quot;Gotowy scenariusz na film&quot;" src="https://interia-s.pluscdn.pl/dziennik-powstanczy-aliny-janowskiej-gotowy-scenariusz-na-fi/000IYTLFYAL3O5MT-C307.jpg" /></a>Mama nigdy nie mówiła o istnieniu tego pamiętnika. Odkryłem go przekopując się przez pozostałe po niej materiały - wspomina Michał Zabłocki, syn Aliny Janowskiej. Powstańczy dziennik aktorki został przekazany do Muzeum Powstania Warszawskiego.</p><br clear="all" />

## Drony nad bazą wojskową. Alarm w Rumunii
 - [https://www.rmf24.pl/fakty/swiat/news-drony-nad-baza-wojskowa-alarm-w-rumunii,nId,7455232](https://www.rmf24.pl/fakty/swiat/news-drony-nad-baza-wojskowa-alarm-w-rumunii,nId,7455232)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T18:54:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-drony-nad-baza-wojskowa-alarm-w-rumunii,nId,7455232"><img align="left" alt="Drony nad bazą wojskową. Alarm w Rumunii" src="https://interia-s.pluscdn.pl/drony-nad-baza-wojskowa-alarm-w-rumunii/000IYTHRT6FMWMF8-C307.jpg" /></a>​Nad bazą Rumuńskich Sił Powietrznych pod Konstancą zaobserwowano w nocy z poniedziałku na wtorek drony, prawdopodobnie komercyjne. O sytuacji została jednak poinformowana prokuratura wojskowa.</p><br clear="all" />

## "Nasza Notre Dame". Ogień strawił Starą Giełdę w Kopenhadze
 - [https://www.rmf24.pl/fakty/swiat/news-nasza-notre-dame-ogien-strawil-stara-gielde-w-kopenhadze,nId,7455225](https://www.rmf24.pl/fakty/swiat/news-nasza-notre-dame-ogien-strawil-stara-gielde-w-kopenhadze,nId,7455225)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T18:48:39+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-nasza-notre-dame-ogien-strawil-stara-gielde-w-kopenhadze,nId,7455225"><img align="left" alt="&quot;Nasza Notre Dame&quot;. Ogień strawił Starą Giełdę w Kopenhadze" src="https://interia-s.pluscdn.pl/nasza-notre-dame-ogien-strawil-stara-gielde-w-kopenhadze/000IYTI6DF20T5A0-C307.jpg" /></a>Około godziny 16:00 strażacy poinformowali, że pożar zabytkowego gmachu Starej Giełdy w Kopenhadze jest pod kontrolą. Wciąż pracują na miejscu, dlatego nikt nie mówi jeszcze o szkodach, jakie wyrządził ogień w liczącym 400 lat budynku. Są i tacy, którzy mają odwagę przyznać, że ten jeden z najstarszych w stolicy Danii budynków został całkowicie zniszczony. Po tym jak zawaliła się charakterystyczna wieża z iglicą, mieszkańców zaczęli mówić: &quot;To nasza Notre Dame&quot;.</p><br clear="all" />

## Dubaj pod wodą. Lotnisko zamieniło się w morze [FILMY]
 - [https://www.rmf24.pl/raporty/raport-kryzys-klimatyczny/news-dubaj-pod-woda-lotnisko-zamienilo-sie-w-morze-filmy,nId,7455198](https://www.rmf24.pl/raporty/raport-kryzys-klimatyczny/news-dubaj-pod-woda-lotnisko-zamienilo-sie-w-morze-filmy,nId,7455198)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T18:14:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-kryzys-klimatyczny/news-dubaj-pod-woda-lotnisko-zamienilo-sie-w-morze-filmy,nId,7455198"><img align="left" alt="Dubaj pod wodą. Lotnisko zamieniło się w morze [FILMY]" src="https://interia-s.pluscdn.pl/dubaj-pod-woda-lotnisko-zamienilo-sie-w-morze-filmy/000IYTEUQBCRSRH3-C307.jpg" /></a>Czegoś takiego w Dubaju nie widzieli już dawno. We wtorek nad miasto nadciągnęła potężna ulewa, która doprowadziła do licznych zalań. Pod wodą znalazło się m.in. międzynarodowe lotnisko i liczne ulice w centrum.</p><br clear="all" />

## Paweł Zalewski gościem Rozmowy o 7:00 w Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-pawel-zalewski-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7454978](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-pawel-zalewski-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7454978)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T17:30:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-pawel-zalewski-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7454978"><img align="left" alt="Paweł Zalewski gościem Rozmowy o 7:00 w Radiu RMF24" src="https://interia-s.pluscdn.pl/pawel-zalewski-gosciem-rozmowy-o-7-00-w-radiu-rmf24/000IYSJ544B72OAD-C307.jpg" /></a>Gościem Rozmowy o 7:00 w Radiu RMF24 będzie Paweł Zalewski - wiceminister obrony narodowej, poseł Polski 2050. Porozmawiamy z nim m.in. o potrzebie budowy nad Polską europejskiej tarczy antyrakietowej.</p><br clear="all" />

## Roztrzaskał ule w ogrodzie pałacowym w Wilanowie. Policja szuka sprawcy
 - [https://www.rmf24.pl/regiony/warszawa/news-roztrzaskal-ule-w-ogrodzie-palacowym-w-wilanowie-policja-szu,nId,7455188](https://www.rmf24.pl/regiony/warszawa/news-roztrzaskal-ule-w-ogrodzie-palacowym-w-wilanowie-policja-szu,nId,7455188)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T17:02:35+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-roztrzaskal-ule-w-ogrodzie-palacowym-w-wilanowie-policja-szu,nId,7455188"><img align="left" alt="Roztrzaskał ule w ogrodzie pałacowym w Wilanowie. Policja szuka sprawcy" src="https://interia-s.pluscdn.pl/roztrzaskal-ule-w-ogrodzie-palacowym-w-wilanowie-policja-szu/000IYT86L04O00YU-C307.jpg" /></a>Nieznany sprawca - używając gaśnic - zniszczył pasiekę w ogrodzie pałacowym w Wilanowie - poinformowało w mediach społecznościowych Muzeum Pałacu Króla Jana III w Wilanowie. Sprawę bada policja.</p><br clear="all" />

## Noworodek przy granicy. Wezwano wojskowy ambulans
 - [https://www.rmf24.pl/regiony/bialystok/news-noworodek-przy-granicy-wezwano-wojskowy-ambulans,nId,7455187](https://www.rmf24.pl/regiony/bialystok/news-noworodek-przy-granicy-wezwano-wojskowy-ambulans,nId,7455187)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T16:55:43+00:00

<p><a href="https://www.rmf24.pl/regiony/bialystok/news-noworodek-przy-granicy-wezwano-wojskowy-ambulans,nId,7455187"><img align="left" alt="Noworodek przy granicy. Wezwano wojskowy ambulans" src="https://interia-s.pluscdn.pl/noworodek-przy-granicy-wezwano-wojskowy-ambulans/000IYT8MT8PVBXS8-C307.jpg" /></a>Nietypowa interwencja służb przy granicy w rejonie Białowieży w Podlaskiem. Funkcjonariusze straży granicznej i żołnierze Wojska Polskiego udzielili pomocy kobiecie, która kilkanaście godzin wcześniej urodziła dziecko.</p><br clear="all" />

## Rosja intensyfikuje ostrzał Charkowa. Cel? Odciąć, a potem zająć miasto
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-rosja-intensyfikuje-ostrzal-charkowa-cel-odciac-a-potem-zaja,nId,7454991](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-rosja-intensyfikuje-ostrzal-charkowa-cel-odciac-a-potem-zaja,nId,7454991)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T16:18:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-rosja-intensyfikuje-ostrzal-charkowa-cel-odciac-a-potem-zaja,nId,7454991"><img align="left" alt="Rosja intensyfikuje ostrzał Charkowa. Cel? Odciąć, a potem zająć miasto" src="https://interia-s.pluscdn.pl/rosja-intensyfikuje-ostrzal-charkowa-cel-odciac-a-potem-zaja/000IYT2NDT2T0IJ6-C307.jpg" /></a>Rosja może przygotowywać atak na Charków i w tym celu intensyfikuje ostrzał miasta, chcąc wypędzić z niego mieszkańców - pisze Bloomberg. Choć Kreml na razie nie ma wystarczających sił, by zająć miasto, to może się wkrótce zmienić. Rosjanie planują bowiem powołać pod broń setki tysięcy mężczyzn.</p><br clear="all" />

## Śmierć Polaka w Strefie Gazy. Kiedy wnioski o pomoc prawną?
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-smierc-polaka-w-strefie-gazy-kiedy-wnioski-o-pomoc-prawna-do,nId,7455159](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-smierc-polaka-w-strefie-gazy-kiedy-wnioski-o-pomoc-prawna-do,nId,7455159)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T16:09:54+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-smierc-polaka-w-strefie-gazy-kiedy-wnioski-o-pomoc-prawna-do,nId,7455159"><img align="left" alt="Śmierć Polaka w Strefie Gazy. Kiedy wnioski o pomoc prawną?" src="https://interia-s.pluscdn.pl/smierc-polaka-w-strefie-gazy-kiedy-wnioski-o-pomoc-prawna/000IYT5VLE90CN9B-C307.jpg" /></a>Najwcześniej za miesiąc mają być gotowe do wysłania wnioski o pomoc prawną do Izraela i Autonomii Palestyńskiej - dowiedział się reporter RMF FM. Chodzi o śledztwo dotyczące śmierci polskiego wolontariusza w izraelskim nalocie na konwój humanitarny w Gazie. Te dokumenty trafiły już do Warszawy z prowadzącej postępowanie w tej sprawie prokuratury w Przemyślu.</p><br clear="all" />

## Pełczyńska-Nałęcz o rewizji KPO: Nie jest wymogiem, jest decyzją rządową
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-pelczynska-nalecz-o-rewizji-kpo-nie-jest-wymogiem-jest-decyz,nId,7454755](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-pelczynska-nalecz-o-rewizji-kpo-nie-jest-wymogiem-jest-decyz,nId,7454755)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T16:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-pelczynska-nalecz-o-rewizji-kpo-nie-jest-wymogiem-jest-decyz,nId,7454755"><img align="left" alt="Pełczyńska-Nałęcz o rewizji KPO: Nie jest wymogiem, jest decyzją rządową" src="https://interia-s.pluscdn.pl/pelczynska-nalecz-o-rewizji-kpo-nie-jest-wymogiem-jest-decyz/000IYPPSX1852U55-C307.jpg" /></a>„Kumulacja jest ogromna” – przyznała Katarzyna Pełczyńska-Nałęcz, nawiązując do 135 mld euro z Unii Europejskiej. „To jest szansa ogromna i tej szansy nie wolno zaprzepaścić” – dodała minister funduszy i polityki regionalnej. Teraz przed rządem stoi wyzwanie. Jak mówiła Pełczyńska-Nałęcz, „zainwestowanie tych pieniędzy w sensowny sposób”.</p><br clear="all" />

## Pełczyńska-Nałęcz o rewizji KPO: Uznajemy pewne rzeczy za niecelowe, niepotrzebne, złe
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-pelczynska-nalecz-o-rewizji-kpo-uznajemy-pewne-rzeczy-za-nie,nId,7454755](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-pelczynska-nalecz-o-rewizji-kpo-uznajemy-pewne-rzeczy-za-nie,nId,7454755)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T16:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-pelczynska-nalecz-o-rewizji-kpo-uznajemy-pewne-rzeczy-za-nie,nId,7454755"><img align="left" alt="Pełczyńska-Nałęcz o rewizji KPO: Uznajemy pewne rzeczy za niecelowe, niepotrzebne, złe " src="https://interia-s.pluscdn.pl/pelczynska-nalecz-o-rewizji-kpo-uznajemy-pewne-rzeczy-za-nie/000IYT8VX083PEWC-C307.jpg" /></a>&quot;Kumulacja jest ogromna&quot; - przyznała Katarzyna Pełczyńska-Nałęcz, nawiązując do 135 mld euro z Unii Europejskiej. Część tych pieniędzy to przyznane nam 27 mld euro z KPO. &quot;To jest szansa ogromna i tej szansy nie wolno zaprzepaścić&quot; - dodała minister funduszy i polityki regionalnej. Teraz przed rządem stoi wyzwanie. Jak mówiła Pełczyńska-Nałęcz, &quot;zainwestowanie tych pieniędzy w sensowny sposób&quot;.</p><br clear="all" />

## Tir wjechał w przystanek. Osiem osób poszkodowanych w wypadku w Tyczynie
 - [https://www.rmf24.pl/regiony/rzeszow/news-tir-wjechal-w-przystanek-osiem-osob-poszkodowanych-w-wypadku,nId,7455004](https://www.rmf24.pl/regiony/rzeszow/news-tir-wjechal-w-przystanek-osiem-osob-poszkodowanych-w-wypadku,nId,7455004)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T15:41:54+00:00

<p><a href="https://www.rmf24.pl/regiony/rzeszow/news-tir-wjechal-w-przystanek-osiem-osob-poszkodowanych-w-wypadku,nId,7455004"><img align="left" alt="Tir wjechał w przystanek. Osiem osób poszkodowanych w wypadku w Tyczynie" src="https://interia-s.pluscdn.pl/tir-wjechal-w-przystanek-osiem-osob-poszkodowanych-w-wypadku/000IYT3LD13DKR5G-C307.jpg" /></a>Poważny wypadek w Tyczynie koło Rzeszowa. Osobowy hyundai zjechał na przeciwny pas ruchu i zderzył się z tirem, który z kolei uderzył w volvo, a następnie w przystanek. Osiem osób zostało poszkodowanych, z których pięć trafiło do szpitala.</p><br clear="all" />

## Katarzyna Pełczyńska-Nałęcz gościem Popołudniowej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-katarzyna-pelczynska-nalecz-gosciem-popoludniowej-rozmowy-w-,nId,7454755](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-katarzyna-pelczynska-nalecz-gosciem-popoludniowej-rozmowy-w-,nId,7454755)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T15:40:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-katarzyna-pelczynska-nalecz-gosciem-popoludniowej-rozmowy-w-,nId,7454755"><img align="left" alt="Katarzyna Pełczyńska-Nałęcz gościem Popołudniowej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/katarzyna-pelczynska-nalecz-gosciem-popoludniowej-rozmowy-w/000IYPPSX1852U55-C307.jpg" /></a>Gościem Piotra Salaka w Popołudniowej rozmowie w RMF FM będzie minister funduszy i polityki regionalnej Katarzyna Pełczyńska-Nałęcz. Porozmawiamy o tym, do kogo trafi 27 mld zł z unijnego funduszu odbudowy na realizację KPO i kiedy Polska może liczyć na kolejne transze. </p><br clear="all" />

## Przesłuchanie Szumowskiego. Nie czuje się winny ws. wyborów kopertowych
 - [https://www.rmf24.pl/raporty/raport-wybory-kopertowe/news-przesluchanie-szumowskiego-nie-czuje-sie-winny-ws-wyborow-ko,nId,7454952](https://www.rmf24.pl/raporty/raport-wybory-kopertowe/news-przesluchanie-szumowskiego-nie-czuje-sie-winny-ws-wyborow-ko,nId,7454952)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T14:31:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wybory-kopertowe/news-przesluchanie-szumowskiego-nie-czuje-sie-winny-ws-wyborow-ko,nId,7454952"><img align="left" alt="Przesłuchanie Szumowskiego. Nie czuje się winny ws. wyborów kopertowych" src="https://interia-s.pluscdn.pl/przesluchanie-szumowskiego-nie-czuje-sie-winny-ws-wyborow-ko/000IYSDYO5P5JD8Y-C307.jpg" /></a>&quot;Nie mam sobie nic do zarzucenia&quot; - mówił przed sejmową komisją śledczą do spraw wyborów kopertowych Łukasz Szumowski. Były minister zdrowia w rządzie PiS tłumaczy się, dlaczego w 2020 roku rekomendował głosowanie korespondencyjne, choć wcześniej był temu przeciwny.</p><br clear="all" />

## Wakaty w szkołach. Winny m.in. ogromny hałas
 - [https://www.rmf24.pl/news-wakaty-w-szkolach-winny-m-in-ogromny-halas,nId,7454961](https://www.rmf24.pl/news-wakaty-w-szkolach-winny-m-in-ogromny-halas,nId,7454961)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T14:22:23+00:00

<p><a href="https://www.rmf24.pl/news-wakaty-w-szkolach-winny-m-in-ogromny-halas,nId,7454961"><img align="left" alt="Wakaty w szkołach. Winny m.in. ogromny hałas" src="https://interia-s.pluscdn.pl/wakaty-w-szkolach-winny-m-in-ogromny-halas/000IYSEDSUX77EG1-C307.jpg" /></a>Hałas w szkołach wymieniany jest jako jeden z najbardziej uciążliwych źródeł dyskomfortu. Tak wynika z badania Future Classroom Lab, w którym udział wzięło 18 europejskich państw, w tym Polska. Głośne korytarze i niewygłuszone sale lekcyjne wpływają źle zarówno na nauczycieli, jak i na uczniów. A to często przekłada się u uczniów na wyniki w nauce, a wśród nauczycieli na decyzję o odejściu z zawodu. </p><br clear="all" />

## Andrzej Duda spotka się z Donaldem Trumpem?
 - [https://www.rmf24.pl/fakty/polska/news-duda-spotka-sie-z-trumpem-jezeli-bedzie-taka-mozliwosc,nId,7454946](https://www.rmf24.pl/fakty/polska/news-duda-spotka-sie-z-trumpem-jezeli-bedzie-taka-mozliwosc,nId,7454946)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T14:04:06+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-duda-spotka-sie-z-trumpem-jezeli-bedzie-taka-mozliwosc,nId,7454946"><img align="left" alt="Andrzej Duda spotka się z Donaldem Trumpem?" src="https://interia-s.pluscdn.pl/andrzej-duda-spotka-sie-z-donaldem-trumpem/000IYS4AQ6NQSQES-C307.jpg" /></a>Jeżeli będzie taka możliwość, spotkam się towarzysko z Donaldem Trumpem - powiedział przed odlotem do Stanów Zjednoczonych Andrzej Duda. Prezydent podkreślił, że Polsce zależy na relacjach ze wszystkimi, którzy w Ameryce podejmują decyzje.</p><br clear="all" />

## Projekt budowy żelaznej kopuły nad Europą. Tusk odpowiada Dudzie
 - [https://www.rmf24.pl/polityka/news-projekt-budowy-zelaznej-kopuly-nad-europa-tusk-odpowiada-dud,nId,7454917](https://www.rmf24.pl/polityka/news-projekt-budowy-zelaznej-kopuly-nad-europa-tusk-odpowiada-dud,nId,7454917)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T13:33:43+00:00

<p><a href="https://www.rmf24.pl/polityka/news-projekt-budowy-zelaznej-kopuly-nad-europa-tusk-odpowiada-dud,nId,7454917"><img align="left" alt="Projekt budowy żelaznej kopuły nad Europą. Tusk odpowiada Dudzie" src="https://interia-s.pluscdn.pl/projekt-budowy-zelaznej-kopuly-nad-europa-tusk-odpowiada-dud/000IYSE6JNNCSW7B-C307.jpg" /></a>&quot;Dla mnie jest nieistotne, kto ma jaki biznes w kwestiach zbrojeniowych czy obronnych. Dla mnie jest istotne to, kiedy Polska będzie bezpieczniejsza&quot; - powiedział premier Donald Tusk, odnosząc się do słów Andrzeja Dudy o projekcie budowy żelaznej kopuły nad Europą. Prezydent stwierdził, że jest to  &quot;biznesowy projekt niemiecki&quot;, który pojawił się przed dwoma laty. Szef rządu, podczas konferencji prasowej w ostry sposób komentował również działania byłego ministra obrony Antoniego Macierewcza.</p><br clear="all" />

## Stare auto na środku warszawskiego placu. "To walka z patologią parkowania"
 - [https://www.rmf24.pl/regiony/warszawa/news-stare-auto-na-srodku-warszawskiego-placu-to-walka-z-patologi,nId,7454900](https://www.rmf24.pl/regiony/warszawa/news-stare-auto-na-srodku-warszawskiego-placu-to-walka-z-patologi,nId,7454900)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T13:25:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-stare-auto-na-srodku-warszawskiego-placu-to-walka-z-patologi,nId,7454900"><img align="left" alt="Stare auto na środku warszawskiego placu. &quot;To walka z patologią parkowania&quot;" src="https://interia-s.pluscdn.pl/stare-auto-na-srodku-warszawskiego-placu-to-walka-z-patologi/000IYRDDM2DRPBDX-C307.jpg" /></a>​Mandat niższy niż opłata parkingowa? To możliwe, o czym świadczy zaparkowana na środku warszawskiego placu Pięciu Rogów kilkudziesięcioletnia skoda. Właściciel pojazdu mówi wprost - to prowokacja, która ma pokazać walkę z patologiami parkowania w Polsce.</p><br clear="all" />

## Skrajna prawica przeganiana w Brukseli z miejsca na miejsce. Już trzeci raz
 - [https://www.rmf24.pl/fakty/swiat/news-skrajna-prawica-przeganiana-w-brukseli-z-miejsca-na-miejsce-,nId,7454888](https://www.rmf24.pl/fakty/swiat/news-skrajna-prawica-przeganiana-w-brukseli-z-miejsca-na-miejsce-,nId,7454888)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T13:00:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-skrajna-prawica-przeganiana-w-brukseli-z-miejsca-na-miejsce-,nId,7454888"><img align="left" alt="Skrajna prawica przeganiana w Brukseli z miejsca na miejsce. Już trzeci raz" src="https://interia-s.pluscdn.pl/skrajna-prawica-przeganiana-w-brukseli-z-miejsca-na-miejsce/000IYR4QJY8BT7HX-C307.jpg" /></a>​Międzynarodówka skrajnej prawicy niemile widziana w Brukseli i przeganiania z miejsca na miejsce. Emir Kir, burmistrz jednej z brukselskich gmin, poinformował tuż po południu na platformie X, że wydał zakaz organizowania Narodowej Konferencji Konserwatyzmu. Na miejsce przybyła policja i uczestnicy musieli opuścić centrum kongresowe.</p><br clear="all" />

## Sztuczna inteligencja zmienia oblicze wojny. Rozmawiamy z ekspertami
 - [https://www.rmf24.pl/regiony/poznan/news-sztuczna-inteligencja-zmienia-oblicze-wojny-rozmawiamy-z-eks,nId,7454830](https://www.rmf24.pl/regiony/poznan/news-sztuczna-inteligencja-zmienia-oblicze-wojny-rozmawiamy-z-eks,nId,7454830)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T12:33:59+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-sztuczna-inteligencja-zmienia-oblicze-wojny-rozmawiamy-z-eks,nId,7454830"><img align="left" alt="Sztuczna inteligencja zmienia oblicze wojny. Rozmawiamy z ekspertami" src="https://interia-s.pluscdn.pl/sztuczna-inteligencja-zmienia-oblicze-wojny-rozmawiamy-z-eks/000IYR2HKSA3KNL0-C307.jpg" /></a>Sztuczna inteligencja już dawno zmieniła oblicze współczesnej wojny - przyznaje Adam Danieluk, prezes ISSA Polska, jeden z gości Międzynarodowego Kongresu Cyberbezpieczeństwa INSECON odbywającego się w Poznaniu. Nasz dziennikarz rozmawiał także z gen. Krzysztofem Królem, doradcą Szefa Sztabu Generalnego Wojska Polskiego oraz prof. Jerzym Kosińskim z Zakładu Systemów Bezpieczeństwa Akademii Marynarki Wojennej w Gdyni.</p><br clear="all" />

## Tadżyk z Państwa Islamskiego deportowany z Polski. Komunikat ABW
 - [https://www.rmf24.pl/fakty/polska/news-tadzyk-z-panstwa-islamskiego-deportowany-z-polski-komunikat-,nId,7454862](https://www.rmf24.pl/fakty/polska/news-tadzyk-z-panstwa-islamskiego-deportowany-z-polski-komunikat-,nId,7454862)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T12:24:20+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-tadzyk-z-panstwa-islamskiego-deportowany-z-polski-komunikat-,nId,7454862"><img align="left" alt="Tadżyk z Państwa Islamskiego deportowany z Polski. Komunikat ABW" src="https://interia-s.pluscdn.pl/tadzyk-z-panstwa-islamskiego-deportowany-z-polski-komunikat/000IYR3YP80AE93O-C307.jpg" /></a>Obywatel Tadżykistanu i członek organizacji terrorystycznej Państwa Islamskiego, został deportowany z terytorium Polski. Cudzoziemiec został wydalony lotem specjalnym w asyście funkcjonariuszy straży granicznej.</p><br clear="all" />

## Kamiński i Wąsik wezwani do prokuratury. Usłyszą zarzuty
 - [https://www.rmf24.pl/fakty/polska/news-kaminski-i-wasik-wezwani-do-prokuratury-uslysza-zarzuty,nId,7454818](https://www.rmf24.pl/fakty/polska/news-kaminski-i-wasik-wezwani-do-prokuratury-uslysza-zarzuty,nId,7454818)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T11:49:23+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-kaminski-i-wasik-wezwani-do-prokuratury-uslysza-zarzuty,nId,7454818"><img align="left" alt="Kamiński i Wąsik wezwani do prokuratury. Usłyszą zarzuty" src="https://interia-s.pluscdn.pl/kaminski-i-wasik-wezwani-do-prokuratury-uslysza-zarzuty/000IYQSVEQKK8FI7-C307.jpg" /></a>Mariusz Kamiński i Maciej Wąsik zostali wezwani w najbliższy czwartek do prokuratury. Mają usłyszeć zarzuty dotyczące nielegalnego udziału w głosowaniach w Sejmie.</p><br clear="all" />

## Robert Bąkiewicz z zarzutami. Chodzi o uszkodzenie zabytku
 - [https://www.rmf24.pl/fakty/polska/news-robert-bakiewicz-z-zarzutami-chodzi-o-uszkodzenie-zabytku,nId,7454800](https://www.rmf24.pl/fakty/polska/news-robert-bakiewicz-z-zarzutami-chodzi-o-uszkodzenie-zabytku,nId,7454800)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T11:40:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-robert-bakiewicz-z-zarzutami-chodzi-o-uszkodzenie-zabytku,nId,7454800"><img align="left" alt="Robert Bąkiewicz z zarzutami. Chodzi o uszkodzenie zabytku" src="https://interia-s.pluscdn.pl/robert-bakiewicz-z-zarzutami-chodzi-o-uszkodzenie-zabytku/000IYQUFJX2IGP6R-C307.jpg" /></a>Robert Bąkiewicz - jeden z liderów środowisk narodowych - z zarzutami. Jest podejrzany o uszkodzenie zabytku. Grozi mu 8 lat więzienia. </p><br clear="all" />

## 578 osób inwigilowanych Pegasusem
 - [https://www.rmf24.pl/raporty/raport-pegasus/news-578-osob-inwigilowanych-pegasusem,nId,7454789](https://www.rmf24.pl/raporty/raport-pegasus/news-578-osob-inwigilowanych-pegasusem,nId,7454789)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T11:33:43+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-pegasus/news-578-osob-inwigilowanych-pegasusem,nId,7454789"><img align="left" alt="578 osób inwigilowanych Pegasusem" src="https://interia-s.pluscdn.pl/578-osob-inwigilowanych-pegasusem/000IYQC2UW1H9VPX-C307.jpg" /></a>Znamy liczby zawarte w informacji, przekazanej wczoraj do Sejmu i Senatu przez Prokuratora Generalnego Adama Bodnara.</p><br clear="all" />

## Prokuratura dostała kluczową opinię ws. wypadku na A1
 - [https://www.rmf24.pl/regiony/lodz/news-wypadek-na-a1-prokuratura-dostala-kluczowa-opinie-ws-sebasti,nId,7454779](https://www.rmf24.pl/regiony/lodz/news-wypadek-na-a1-prokuratura-dostala-kluczowa-opinie-ws-sebasti,nId,7454779)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T11:33:00+00:00

<p><a href="https://www.rmf24.pl/regiony/lodz/news-wypadek-na-a1-prokuratura-dostala-kluczowa-opinie-ws-sebasti,nId,7454779"><img align="left" alt="Prokuratura dostała kluczową opinię ws. wypadku na A1 " src="https://interia-s.pluscdn.pl/prokuratura-dostala-kluczowa-opinie-ws-wypadku-na-a1/000IYQATXQWEA769-C307.jpg" /></a>Prokuratura uzyskała kluczową opinię w sprawie wypadku na autostradzie A1 koło Piotrkowa Trybunalskiego, w którym zginęła 3-osobowa rodzina. Biegli z zakresu wypadków drogowych uzupełnili rekonstrukcję tego tragicznego zdarzenia. </p><br clear="all" />

## Piorun uderzył w samolot LOT-u. Maszyna musiała zawrócić
 - [https://www.rmf24.pl/pogoda/news-piorun-uderzyl-w-samolot-lot-u-maszyna-musiala-zawrocic,nId,7454740](https://www.rmf24.pl/pogoda/news-piorun-uderzyl-w-samolot-lot-u-maszyna-musiala-zawrocic,nId,7454740)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T10:36:00+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-piorun-uderzyl-w-samolot-lot-u-maszyna-musiala-zawrocic,nId,7454740"><img align="left" alt="Piorun uderzył w samolot LOT-u. Maszyna musiała zawrócić " src="https://interia-s.pluscdn.pl/piorun-uderzyl-w-samolot-lot-u-maszyna-musiala-zawrocic/000IYPPA0180AIOU-C307.jpg" /></a>W okolicach Szczecina piorun uderzył w samolot Polskich Linii Lotniczych LOT. Maszyna musiała zawrócić do Warszawy. </p><br clear="all" />

## Duda o budowie żelaznej kopuły nad Europą: Biznesowy projekt niemiecki
 - [https://www.rmf24.pl/polityka/news-prezydent-o-budowie-zelaznej-kopuly-nad-europa-biznesowy-pro,nId,7454757](https://www.rmf24.pl/polityka/news-prezydent-o-budowie-zelaznej-kopuly-nad-europa-biznesowy-pro,nId,7454757)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T10:35:43+00:00

<p><a href="https://www.rmf24.pl/polityka/news-prezydent-o-budowie-zelaznej-kopuly-nad-europa-biznesowy-pro,nId,7454757"><img align="left" alt="Duda o budowie żelaznej kopuły nad Europą: Biznesowy projekt niemiecki" src="https://interia-s.pluscdn.pl/duda-o-budowie-zelaznej-kopuly-nad-europa-biznesowy-projekt/000IYPQESH2RQEST-C307.jpg" /></a>Od wielu lat budujemy system obrony powietrznej oparty przede wszystkim na systemie Patriot - oświadczył prezydent Andrzej Duda, odnosząc się do pomysłu budowy tzw. żelaznej kopuły nad Europą. Zwrócił uwagę, że to jest &quot;biznesowy projekt niemiecki&quot;, który pojawił się przed dwoma laty.</p><br clear="all" />

## ​Zima wróciła w Tatry. Rośnie zagrożenie lawinowe
 - [https://www.rmf24.pl/regiony/zakopane/news-zima-wrocila-w-tatry-rosnie-zagrozenie-lawinowe,nId,7454728](https://www.rmf24.pl/regiony/zakopane/news-zima-wrocila-w-tatry-rosnie-zagrozenie-lawinowe,nId,7454728)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T10:25:00+00:00

<p><a href="https://www.rmf24.pl/regiony/zakopane/news-zima-wrocila-w-tatry-rosnie-zagrozenie-lawinowe,nId,7454728"><img align="left" alt="​Zima wróciła w Tatry. Rośnie zagrożenie lawinowe" src="https://interia-s.pluscdn.pl/zima-wrocila-w-tatry-rosnie-zagrozenie-lawinowe/000IYPLSXS6FO5NV-C307.jpg" /></a>W Tatrach obowiązuje obecnie drugi, czyli umiarkowany stopień zagrożenia lawinowego. &quot;Przyzwyczailiśmy się w ostatnich dniach do temperatury sięgającej powyżej 20 stopni C, a tu nadciąga ochłodzenie. Wysoko w Tatrach spadł śnieg i trzeba było podwyższyć stopień zagrożenia lawinowego&quot; - mówi reporterowi RMF RM Maciejowi Pałahickiemu ratownik dyżurny TOPR Jakub Hornowski.</p><br clear="all" />

## Michelin Polska wygasza produkcję części opon. Co z pracownikami?
 - [https://www.rmf24.pl/regiony/olsztyn/news-michelin-polska-wygasza-produkcje-czesci-opon-co-z-pracownik,nId,7454730](https://www.rmf24.pl/regiony/olsztyn/news-michelin-polska-wygasza-produkcje-czesci-opon-co-z-pracownik,nId,7454730)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T10:08:29+00:00

<p><a href="https://www.rmf24.pl/regiony/olsztyn/news-michelin-polska-wygasza-produkcje-czesci-opon-co-z-pracownik,nId,7454730"><img align="left" alt="Michelin Polska wygasza produkcję części opon. Co z pracownikami?" src="https://interia-s.pluscdn.pl/michelin-polska-wygasza-produkcje-czesci-opon-co-z-pracownik/000IYPNM6NQSTO0Y-C307.jpg" /></a>Michelin Polska pod koniec roku wygasi produkcję opon do samochodów ciężarowych w fabryce w Olsztynie, ale nie zwolni pracujących w tym zakładzie ludzi - zapewnia rzecznik prasowy Michelin Polska Piotr Staszałek.</p><br clear="all" />

## "Spiker Johnson zamiast być rozgrywającym, staje się cheerleaderem"
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-spiker-johnson-zamiast-byc-rozgrywajacym-staje-sie-cheerlead,nId,7454648](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-spiker-johnson-zamiast-byc-rozgrywajacym-staje-sie-cheerlead,nId,7454648)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T10:02:57+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-spiker-johnson-zamiast-byc-rozgrywajacym-staje-sie-cheerlead,nId,7454648"><img align="left" alt="&quot;Spiker Johnson zamiast być rozgrywającym, staje się cheerleaderem&quot;" src="https://interia-s.pluscdn.pl/spiker-johnson-zamiast-byc-rozgrywajacym-staje-sie-cheerlead/000IYOGQ2HAXXUFN-C307.jpg" /></a>&quot;Johnson jest szantażowany przez członków własnej partii&quot; - tłumaczy profesor Małgorzata Zachara–Szymańska z Uniwersytetu Jagiellońskiego. Amerykanistka wyjaśnia, że spiker republikanów z trzeciej osoby w państwie stał się marionetką w rękach polityków, a sprawa przegłosowania pakietu wsparcia dla Ukrainy nadal nie jest oczywista.</p><br clear="all" />

## Pilna kontrola NIK w KNF. Chodzi o instytucje powiązane z Leszkiem Czarneckim
 - [https://www.rmf24.pl/fakty/polska/news-pilna-kontrola-nik-w-knf-chodzi-o-instytucje-powiazane-z-les,nId,7454652](https://www.rmf24.pl/fakty/polska/news-pilna-kontrola-nik-w-knf-chodzi-o-instytucje-powiazane-z-les,nId,7454652)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T09:55:12+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-pilna-kontrola-nik-w-knf-chodzi-o-instytucje-powiazane-z-les,nId,7454652"><img align="left" alt="Pilna kontrola NIK w KNF. Chodzi o instytucje powiązane z Leszkiem Czarneckim" src="https://interia-s.pluscdn.pl/pilna-kontrola-nik-w-knf-chodzi-o-instytucje-powiazane-z-les/000IYP0CHRI8K7AS-C307.jpg" /></a>Jak dowiedział się dziennikarz RMF FM, kontrolerzy Najwyższej Izby Kontroli zbadają działania KNF oraz Bankowego Funduszu Gwarancyjnego wobec kilku prywatnych instytucji, powiązanych między innymi z miliarderem Leszkiem Czarneckim. NIK przyjrzy się m.in. roli polityków poprzedniej władzy w procesie przejęcia Getin Noble Banku.</p><br clear="all" />

## Fabryka lewych dokumentów w Gdańsku. Nawet 11 tys. euro za pakiet
 - [https://www.rmf24.pl/regiony/trojmiasto/news-fabryka-lewych-dokumentow-w-gdansku-nawet-11-tys-euro-za-pak,nId,7454689](https://www.rmf24.pl/regiony/trojmiasto/news-fabryka-lewych-dokumentow-w-gdansku-nawet-11-tys-euro-za-pak,nId,7454689)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T09:50:00+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-fabryka-lewych-dokumentow-w-gdansku-nawet-11-tys-euro-za-pak,nId,7454689"><img align="left" alt="Fabryka lewych dokumentów w Gdańsku. Nawet 11 tys. euro za pakiet" src="https://interia-s.pluscdn.pl/fabryka-lewych-dokumentow-w-gdansku-nawet-11-tys-euro-za-pak/000IYOX715O13CHD-C307.jpg" /></a>Funkcjonariusze straży granicznej zatrzymali 25-letnią Ukrainkę, która fałszowała dokumenty. W jednym z mieszkań w Gdańsku śledczy znaleźli ponad 2750 sztuk podrobionych dowodów osobistych, praw jazdy i paszportów, których czarnorynkowa wartość szacowana jest nawet na 14,5 mln zł. </p><br clear="all" />

## Posiedzenie rządu w trybie zastrzeżonym. Premier zaprosił m.in. szefa BBN
 - [https://www.rmf24.pl/polityka/news-posiedzenie-rzadu-w-trybie-zastrzezonym-premier-zaprosil-m-i,nId,7454686](https://www.rmf24.pl/polityka/news-posiedzenie-rzadu-w-trybie-zastrzezonym-premier-zaprosil-m-i,nId,7454686)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T09:21:29+00:00

<p><a href="https://www.rmf24.pl/polityka/news-posiedzenie-rzadu-w-trybie-zastrzezonym-premier-zaprosil-m-i,nId,7454686"><img align="left" alt="Posiedzenie rządu w trybie zastrzeżonym. Premier zaprosił m.in. szefa BBN" src="https://interia-s.pluscdn.pl/posiedzenie-rzadu-w-trybie-zastrzezonym-premier-zaprosil-m-i/000IYOVC546K9OOB-C307.jpg" /></a>Trwa posiedzenie rządu. Pierwsza część odbywa się w trybie zastrzeżonym. W związku z sytuacją na Bliskim Wschodzie premier Donald Tusk zaprosił na to posiedzenie szefa BBN Jacka Siewierę, szefa SGWP gen. Wiesława Kukułę i dowódcę operacyjnego RSZ gen. dyw. Macieja Klisza. </p><br clear="all" />

## Nie pokazywał żadnych emocji. 17-latek aresztowany ws. zbrodni w Sztokholmie
 - [https://www.rmf24.pl/fakty/swiat/news-nie-okazywal-zadnych-emocji-17-latek-aresztowany-w-zwiazku-z,nId,7454665](https://www.rmf24.pl/fakty/swiat/news-nie-okazywal-zadnych-emocji-17-latek-aresztowany-w-zwiazku-z,nId,7454665)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T08:59:07+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-nie-okazywal-zadnych-emocji-17-latek-aresztowany-w-zwiazku-z,nId,7454665"><img align="left" alt="Nie pokazywał żadnych emocji. 17-latek aresztowany ws. zbrodni w Sztokholmie" src="https://interia-s.pluscdn.pl/nie-pokazywal-zadnych-emocji-17-latek-aresztowany-ws-zbrodni/000IYOGJ93N03DOC-C307.jpg" /></a>Sąd rejonowy w Huddinge pod Sztokholmem aresztował we wtorek na dwa tygodnie 17-latka w związku z zabójstwem 39-latka polskiego pochodzenia. Prokuratura zarzuca nastolatkowi &quot;ukrywanie przestępstwa&quot;.</p><br clear="all" />

## Rodzina posła PiS hoduje konie. Lasy Państwowe piszą o nieprawidłowościach
 - [https://www.rmf24.pl/regiony/lodz/news-rodzina-posla-pis-hoduje-konie-lasy-panstwowe-pisza-o-niepra,nId,7454611](https://www.rmf24.pl/regiony/lodz/news-rodzina-posla-pis-hoduje-konie-lasy-panstwowe-pisza-o-niepra,nId,7454611)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T08:38:00+00:00

<p><a href="https://www.rmf24.pl/regiony/lodz/news-rodzina-posla-pis-hoduje-konie-lasy-panstwowe-pisza-o-niepra,nId,7454611"><img align="left" alt="Rodzina posła PiS hoduje konie. Lasy Państwowe piszą o nieprawidłowościach" src="https://interia-s.pluscdn.pl/rodzina-posla-pis-hoduje-konie-lasy-panstwowe-pisza-o-niepra/000IYNQEWOQLS8SA-C307.jpg" /></a>Lasy Państwowe informują o nieprawidłowościach związanych z hodowlą koni prowadzoną przez rodzinę posła Prawa i Sprawiedliwości Roberta Telusa w okolicach Opoczna. Kontrola w tej sprawie ma potrwać do końca tygodnia. </p><br clear="all" />

## Xi Jinping przyjął Olafa Scholza. Co Niemcy chcą ugrać w Chinach?
 - [https://www.rmf24.pl/fakty/swiat/news-xi-jinping-przyjal-w-pekinie-olafa-scholza-co-niemcy-chca-ug,nId,7454568](https://www.rmf24.pl/fakty/swiat/news-xi-jinping-przyjal-w-pekinie-olafa-scholza-co-niemcy-chca-ug,nId,7454568)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T07:45:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-xi-jinping-przyjal-w-pekinie-olafa-scholza-co-niemcy-chca-ug,nId,7454568"><img align="left" alt="Xi Jinping przyjął Olafa Scholza. Co Niemcy chcą ugrać w Chinach?" src="https://interia-s.pluscdn.pl/xi-jinping-przyjal-olafa-scholza-co-niemcy-chca-ugrac-w-chin/000IYN5YBQPF1S0L-C307.jpg" /></a>Olaf Scholz, razem z prezesami największych niemieckich koncernów motoryzacyjnych, jest z wizytą w Chinach. Trzeci i ostatni dzień podróży kanclerz Niemiec rozpoczął od spotkania z Xi Jinpingiem. Chiński przywódca zapewnił, że relacje Pekinu z Berlinem nadal będą się rozwijać, dopóki trzecia do wielkości gospodarka świata będzie szukać wspólnej płaszczyzny współpracy.  </p><br clear="all" />

## „400 lat dziedzictwa kulturowego w płomieniach". Pożar w Kopenhadze
 - [https://www.rmf24.pl/fakty/swiat/news-400-lat-dziedzictwa-kulturowego-w-plomieniach-pozar-w-kopenh,nId,7454594](https://www.rmf24.pl/fakty/swiat/news-400-lat-dziedzictwa-kulturowego-w-plomieniach-pozar-w-kopenh,nId,7454594)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T07:43:53+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-400-lat-dziedzictwa-kulturowego-w-plomieniach-pozar-w-kopenh,nId,7454594"><img align="left" alt="„400 lat dziedzictwa kulturowego w płomieniach&quot;. Pożar w Kopenhadze" src="https://interia-s.pluscdn.pl/400-lat-dziedzictwa-kulturowego-w-plomieniach-pozar-w-kopenh/000IYN7N3JGP7UP0-C307.jpg" /></a>Płonie jeden z najbardziej charakterystycznych budynków w stolicy Danii Kopenhadze. Rano wybuchł pożar w zabytkowym gmachu Starej Giełdy Papierów Wartościowych z 1625 roku. Nie ma informacji o poszkodowanych.</p><br clear="all" />

## Izrael wysłał wiadomość krajom arabskim w sprawie ataku na Iran
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-izrael-wyslal-wiadomosc-krajom-arabskim-w-sprawie-ataku-na-i,nId,7454547](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-izrael-wyslal-wiadomosc-krajom-arabskim-w-sprawie-ataku-na-i,nId,7454547)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T07:31:50+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-izrael-wyslal-wiadomosc-krajom-arabskim-w-sprawie-ataku-na-i,nId,7454547"><img align="left" alt="Izrael wysłał wiadomość krajom arabskim w sprawie ataku na Iran" src="https://interia-s.pluscdn.pl/izrael-wyslal-wiadomosc-krajom-arabskim-w-sprawie-ataku-na-i/000IYN5XC4JFI9S9-C307.jpg" /></a>Izrael zakulisowo poinformował kraje arabskie, że ewentualny odwet na Iranie nie zostanie zrealizowany w sposób, który miałby zagrozić poszczególnym państwom na Bliskim Wschodzie i ich władzom. W ten sposób Tel Awiw próbuje uspokoić kraje Zatoki Perskiej, Jordanię i Egipt, które obawiają się, że konflikt irańsko-izraelski obejmie pierścieniem ognia także ich.</p><br clear="all" />

## Stawką bezpieczeństwo nawet miliarda ludzi. Francuski wiceadmirał alarmuje
 - [https://www.rmf24.pl/fakty/swiat/news-stawka-bezpieczenstwo-nawet-miliarda-ludzi-francuski-wiceadm,nId,7454536](https://www.rmf24.pl/fakty/swiat/news-stawka-bezpieczenstwo-nawet-miliarda-ludzi-francuski-wiceadm,nId,7454536)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T06:33:37+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-stawka-bezpieczenstwo-nawet-miliarda-ludzi-francuski-wiceadm,nId,7454536"><img align="left" alt="Stawką bezpieczeństwo nawet miliarda ludzi. Francuski wiceadmirał alarmuje" src="https://interia-s.pluscdn.pl/stawka-bezpieczenstwo-nawet-miliarda-ludzi-francuski-wiceadm/000IYMNT8SB4PA76-C307.jpg" /></a>Blisko miliard ludzi w Europie i Ameryce Północnej jest narażonych na niebezpieczeństwo z powodu rosyjskich prób uderzenia w zachodnią infrastrukturę podwodną - ostrzega francuski wiceadmirał Didier Maleterre. Jak podkreśla wojskowy, Rosjanie chcą wykorzystać luki w systemach bezpieczeństwa farm wiatrowych, rurociągów i podwodnych kabli energetycznych. </p><br clear="all" />

## Siemoniak: Pegasusem inwigilowano ponad pół tysiąca ludzi
 - [https://www.rmf24.pl/polityka/news-siemoniak-pegasusem-inwigilowano-ponad-pol-tysiaca-ludzi,nId,7454530](https://www.rmf24.pl/polityka/news-siemoniak-pegasusem-inwigilowano-ponad-pol-tysiaca-ludzi,nId,7454530)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T06:26:31+00:00

<p><a href="https://www.rmf24.pl/polityka/news-siemoniak-pegasusem-inwigilowano-ponad-pol-tysiaca-ludzi,nId,7454530"><img align="left" alt="Siemoniak: Pegasusem inwigilowano ponad pół tysiąca ludzi" src="https://interia-s.pluscdn.pl/siemoniak-pegasusem-inwigilowano-ponad-pol-tysiaca-ludzi/000IYMN3LPRPBF9Y-C307.jpg" /></a>W najbliższym czasie do parlamentu trafi raport dotyczący stosowania przez służby systemów kontroli operacyjnej - w tym Pegasusa. Wówczas powinniśmy poznać liczbę osób, które były inwigilowane przy pomocy izraelskiego oprogramowania. Dziś minister koordynator służb specjalnych Tomasz Siemoniak przyznaje, że Pegasusem inwigilowanych było &quot;ponad 500 osób&quot;.</p><br clear="all" />

## Lekarze krytykują propozycję przepisów w sprawie pigułki "dzień po"
 - [https://www.rmf24.pl/fakty/polska/news-lekarze-krytykuja-propozycje-przepisow-w-sprawie-pigulki-dzi,nId,7454520](https://www.rmf24.pl/fakty/polska/news-lekarze-krytykuja-propozycje-przepisow-w-sprawie-pigulki-dzi,nId,7454520)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T06:05:57+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-lekarze-krytykuja-propozycje-przepisow-w-sprawie-pigulki-dzi,nId,7454520"><img align="left" alt="Lekarze krytykują propozycję przepisów w sprawie pigułki &quot;dzień po&quot;" src="https://interia-s.pluscdn.pl/lekarze-krytykuja-propozycje-przepisow-w-sprawie-pigulki-dzi/000IYMGO6MNF6NPK-C307.jpg" /></a>Wiele krytycznych uwag do nowych przepisów w sprawie pigułki &quot;dzień po&quot; złoży Naczelna Rada Lekarska - dowiedział się dziennikarz RMF FM. Chodzi o nowe rozporządzenie Ministerstwa Zdrowia, które od maja ma ułatwić dostęp do antykoncepcji awaryjnej. Konsultacje publiczne propozycji przepisów potrwają do środy. Od maja, zgodnie z planem resortu zdrowia, receptę na pigułkę &quot;dzień po&quot; poza lekarzami, będą mogli wystawiać także farmaceuci i położne.</p><br clear="all" />

## Czarnek: Oszuści z Brukseli - oddajcie nam natychmiast wszystkie pieniądze!
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-czarnek-oszusci-z-brukseli-oddajcie-nam-natychmiast-wszystki,nId,7452624](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-czarnek-oszusci-z-brukseli-oddajcie-nam-natychmiast-wszystki,nId,7452624)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T06:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-czarnek-oszusci-z-brukseli-oddajcie-nam-natychmiast-wszystki,nId,7452624"><img align="left" alt="Czarnek: Oszuści z Brukseli - oddajcie nam natychmiast wszystkie pieniądze!" src="https://interia-s.pluscdn.pl/czarnek-oszusci-z-brukseli-oddajcie-nam-natychmiast-wszystki/000IYN199E6NS0L3-C307.jpg" /></a>&quot;Wyjątkowo nieuczciwi oszuści z Brukseli w końcu jednak zwrócili Polakom pieniądze, które niezgodnie z prawem przetrzymywali 2 lata&quot; - tak poseł Prawa i Sprawiedliwości Przemysław Czarnek skomentował fakt, że 27 mld zł wpłynęło wczoraj na konto Polski z Krajowego Planu Odbudowy. &quot;Wyjątkowi oszuści z Brukseli - oddajcie nam natychmiast wszystkie pieniądze!&quot; - dodał w Porannej rozmowie w RMF FM. </p><br clear="all" />

## Przemysław Czarnek gościem Porannej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-przemyslaw-czarnek-gosciem-porannej-rozmowy-w-rmf-fm,nId,7452624](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-przemyslaw-czarnek-gosciem-porannej-rozmowy-w-rmf-fm,nId,7452624)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T05:57:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-przemyslaw-czarnek-gosciem-porannej-rozmowy-w-rmf-fm,nId,7452624"><img align="left" alt="Przemysław Czarnek gościem Porannej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/przemyslaw-czarnek-gosciem-porannej-rozmowy-w-rmf-fm/000IYIXBLOJQ4A6Y-C307.jpg" /></a>Gościem Porannej rozmowy w RMF FM jest poseł Prawa i Sprawiedliwości Przemysław Czarnek. Porozmawiamy z nim m.in. o jego pozycji w partii po wyborach samorządowych na Lubelszczyźnie, gdzie PiS zdobył większość mandatów w sejmiku wojewódzkim.</p><br clear="all" />

## Boeing zapewnia o bezpieczeństwie samolotów. Sygnalista ma inne zdanie
 - [https://www.rmf24.pl/fakty/swiat/news-boeing-zapewnia-o-bezpieczenstwie-samolotow-sygnalista-ma-in,nId,7454483](https://www.rmf24.pl/fakty/swiat/news-boeing-zapewnia-o-bezpieczenstwie-samolotow-sygnalista-ma-in,nId,7454483)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T05:44:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-boeing-zapewnia-o-bezpieczenstwie-samolotow-sygnalista-ma-in,nId,7454483"><img align="left" alt="Boeing zapewnia o bezpieczeństwie samolotów. Sygnalista ma inne zdanie  " src="https://interia-s.pluscdn.pl/boeing-zapewnia-o-bezpieczenstwie-samolotow-sygnalista-ma-in/000IYMDY8R49X2DQ-C307.jpg" /></a>Boeing oświadczył, że jest &quot;pewny bezpieczeństwa i trwałości samolotów 787 i 777&quot;. Amerykański koncern zapewnia również, że od początku roku znacząco wzrosła liczba zgłoszeń pracowników dotyczących jakości produkowanych maszyn. Deklaracje padają na dzień przed zaplanowanym w tej sprawie przesłuchaniem w Kongresie. Jeden z sygnalistów zwraca uwagę na wady konstrukcyjne i produkcyjne w kadłubach samolotów. </p><br clear="all" />

## Pożar sortowni śmieci w Przemyślu
 - [https://www.rmf24.pl/regiony/rzeszow/news-pozar-sortowni-smieci-w-przemyslu,nId,7454492](https://www.rmf24.pl/regiony/rzeszow/news-pozar-sortowni-smieci-w-przemyslu,nId,7454492)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T05:29:00+00:00

<p><a href="https://www.rmf24.pl/regiony/rzeszow/news-pozar-sortowni-smieci-w-przemyslu,nId,7454492"><img align="left" alt="Pożar sortowni śmieci w Przemyślu" src="https://interia-s.pluscdn.pl/pozar-sortowni-smieci-w-przemyslu/000IYMFGI1OAD126-C307.jpg" /></a>Płonie sortownia śmieci w Przemyślu. Z  ogniem, który zauważono o poranku, walczy kilkanaście jednostek straży pożarnej.</p><br clear="all" />

## Cios w warszawski narkobiznes. Policja likwiduje magazyn dilerów
 - [https://www.rmf24.pl/regiony/warszawa/news-cios-w-warszawski-narkobiznes-policja-likwiduje-magazyn-dile,nId,7452715](https://www.rmf24.pl/regiony/warszawa/news-cios-w-warszawski-narkobiznes-policja-likwiduje-magazyn-dile,nId,7452715)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T05:00:25+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-cios-w-warszawski-narkobiznes-policja-likwiduje-magazyn-dile,nId,7452715"><img align="left" alt="Cios w warszawski narkobiznes. Policja likwiduje magazyn dilerów" src="https://interia-s.pluscdn.pl/cios-w-warszawski-narkobiznes-policja-likwiduje-magazyn-dile/000IYJSX98D6QA61-C307.jpg" /></a>Ponad 130 kilogramów narkotyków wartych ponad 5 milionów złotych przejęli stołeczni policjanci. Zlikwidowali magazyn środków odurzających i zatrzymali 27-letniego mężczyznę. </p><br clear="all" />

## Mykoła Kniażycki: Ukrainie brakuje amunicji, sprzętu, żołnierzy
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-mykola-kniazycki-ukrainie-brakuje-amunicji-sprzetu-zolnierzy,nId,7452637](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-mykola-kniazycki-ukrainie-brakuje-amunicji-sprzetu-zolnierzy,nId,7452637)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T05:00:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-mykola-kniazycki-ukrainie-brakuje-amunicji-sprzetu-zolnierzy,nId,7452637"><img align="left" alt="Mykoła Kniażycki: Ukrainie brakuje amunicji, sprzętu, żołnierzy" src="https://interia-s.pluscdn.pl/mykola-kniazycki-ukrainie-brakuje-amunicji-sprzetu-zolnierzy/000IYJ01V0EXJX1E-C307.jpg" /></a>„Mam nadzieję, że amerykańska pomoc dla Ukrainy będzie zatwierdzona w tym tygodniu, bo Rosjanie przygotowują kontrofensywę na Charków, wschód Ukrainy” - mówił w Rozmowie o 7:00 w Radiu RMF24 deputowany Rady Najwyższej Ukrainy Mykoła Kniażycki. Jak dodawał, Ukrainie brakuje teraz amunicji, sprzętu i żołnierzy.</p><br clear="all" />

## USA: Izba Reprezentantów zajmie się wsparciem dla Ukrainy, Izraela i Tajwanu
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-usa-izba-reprezentantow-zajmie-sie-wsparciem-dla-ukrainy-izr,nId,7454476](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-usa-izba-reprezentantow-zajmie-sie-wsparciem-dla-ukrainy-izr,nId,7454476)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T04:19:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-usa-izba-reprezentantow-zajmie-sie-wsparciem-dla-ukrainy-izr,nId,7454476"><img align="left" alt="USA: Izba Reprezentantów zajmie się wsparciem dla Ukrainy, Izraela i Tajwanu" src="https://interia-s.pluscdn.pl/usa-izba-reprezentantow-zajmie-sie-wsparciem-dla-ukrainy-izr/000IYMB678MFA73T-C307.jpg" /></a>Izba Reprezentantów zajmie się osobnymi pakietami środków na pomoc dla Ukrainy, Izraela, państw regionu Indo-Pacyfiku, a także ustawą pozwalającą na użycie zamrożonych rosyjskich aktywów - poinformował spiker Izby Mike Johnson. Zapowiedź polityka daje nadzieję na uchwalenie pakietu dla Ukrainy przed końcem tygodnia.</p><br clear="all" />

## Jest szansa na koniec impasu ws. pomocy USA dla Ukrainy [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-jest-szansa-na-koniec-impasu-ws-pomocy-usa-dla-ukrainy-relac,nId,7454474](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-jest-szansa-na-koniec-impasu-ws-pomocy-usa-dla-ukrainy-relac,nId,7454474)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T03:37:22+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-jest-szansa-na-koniec-impasu-ws-pomocy-usa-dla-ukrainy-relac,nId,7454474"><img align="left" alt="Jest szansa na koniec impasu ws. pomocy USA dla Ukrainy [RELACJA]" src="https://interia-s.pluscdn.pl/jest-szansa-na-koniec-impasu-ws-pomocy-usa-dla-ukrainy-relac/000IYMAQ9L640RSN-C307.jpg" /></a>Amerykańska Izba Reprezentantów zajmie się osobnymi pakietami środków na pomoc dla Ukrainy, Izraela, państw regionu Indo-Pacyfiku, a także ustawą pozwalającą na użycie zamrożonych rosyjskich aktywów - poinformował spiker Izby Mike Johnson. Daje to nadzieję na uchwalenie pakietu dla Ukrainy przed końcem tygodnia.</p><br clear="all" />

## Polskie firmy IT zwalniają pracowników i tną ich pensje
 - [https://www.rmf24.pl/ekonomia/news-polskie-firmy-it-zwalniaja-pracownikow-i-tna-ich-pensje,nId,7454473](https://www.rmf24.pl/ekonomia/news-polskie-firmy-it-zwalniaja-pracownikow-i-tna-ich-pensje,nId,7454473)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T03:31:07+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-polskie-firmy-it-zwalniaja-pracownikow-i-tna-ich-pensje,nId,7454473"><img align="left" alt="Polskie firmy IT zwalniają pracowników i tną ich pensje" src="https://interia-s.pluscdn.pl/polskie-firmy-it-zwalniaja-pracownikow-i-tna-ich-pensje/000IYMAMO70CS0KV-C307.jpg" /></a>Rosną długi firm informatycznych i listy zwalnianych specjalistów - pisze &quot;Rzeczpospolita&quot;. Według szacunków 95 proc. polskich firm IT zmniejszyło zatrudnienie. </p><br clear="all" />

## „Akt terroru”. Starcia z policją po ataku na kościół w Sydney
 - [https://www.rmf24.pl/fakty/swiat/news-akt-terroru-starcia-z-policja-po-ataku-na-kosciol-w-sydney,nId,7454472](https://www.rmf24.pl/fakty/swiat/news-akt-terroru-starcia-z-policja-po-ataku-na-kosciol-w-sydney,nId,7454472)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-04-16T03:16:57+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-akt-terroru-starcia-z-policja-po-ataku-na-kosciol-w-sydney,nId,7454472"><img align="left" alt="„Akt terroru”. Starcia z policją po ataku na kościół w Sydney" src="https://interia-s.pluscdn.pl/akt-terroru-starcia-z-policja-po-ataku-na-kosciol-w-sydney/000IYMAIGB753211-C307.jpg" /></a>Poniedziałkowy atak nożownika w kościele w Sydney był aktem terroru, a sprawca przypuszczalnie kierował się ekstremizmem religijnym -przekazał australijska policja. Ranne zostały cztery osoby, w tym biskup Asyryjskiego Kościoła Chrystusa Dobrego Pasterza Mar Mari Emmanuel. Policja zatrzymała podejrzanego 15-latka.</p><br clear="all" />

