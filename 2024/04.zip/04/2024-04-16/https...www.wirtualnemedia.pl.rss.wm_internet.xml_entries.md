# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Kolejna dziennikarka przechodzi z TVP do Kanału Zero
 - [https://www.wirtualnemedia.pl/artykul/maria-stepan-tvp-dziennikarka-kanal-zero](https://www.wirtualnemedia.pl/artykul/maria-stepan-tvp-dziennikarka-kanal-zero)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-16T08:53:10.901550+00:00

Do zespołu Kanału Zero dołącza Maria Stepan, poprzednio związana z „Wiadomościami” i TVP Info.

## Brand24 urósł o 30 proc. Podaje cztery przyczyny
 - [https://www.wirtualnemedia.pl/artykul/brand24-kurs-akcji-na-gieldzie-przychody-od-klientow](https://www.wirtualnemedia.pl/artykul/brand24-kurs-akcji-na-gieldzie-przychody-od-klientow)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-16T06:43:27.373100+00:00

Zajmująca się monitoringiem internetu spółka Brand24 w zeszłym kwartale zwiększyła swoje miesięczne przychody powtarzalne o 30 proc. do 622 tys. dolarów (2,48 mln zł). Wynika to m.in. z podwyżki cen i pozyskania większych klientów.

## Sztuczna inteligencja masowo wykorzystywana w generowaniu dezinformacji
 - [https://www.wirtualnemedia.pl/artykul/sztuczna-inteligencja-szerzenie-dezinformacji-jak-z-tym-walczyc](https://www.wirtualnemedia.pl/artykul/sztuczna-inteligencja-szerzenie-dezinformacji-jak-z-tym-walczyc)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-16T06:43:27.347297+00:00

Podmioty szerzące dezinformację powszechnie zaczęły wykorzystywać sztuczną inteligencję do generowania fałszywych treści, zdjęć i filmów - powiedział PAP rzecznik Wojsk Obrony Cyberprzestrzeni Przemysław Lipczyński. Ostrzegł również, że najskuteczniejsza forma dezinformacji, to ta zbudowana na faktach z domieszką kłamstwa. - Skala dezinformacji jest znacznie większa niż mogłoby się nam wydawać - podkreślił Lipczyński.

## MCI Capital inwestuje w platformy dla hotelarzy. Wykłada prawie 200 mln zł
 - [https://www.wirtualnemedia.pl/artykul/mci-capital-inwestycja-nowa-profitroom-kurs-akcji](https://www.wirtualnemedia.pl/artykul/mci-capital-inwestycja-nowa-profitroom-kurs-akcji)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-16T05:38:07.168021+00:00

Spółka zależna funduszu MCI Capital uzgodniła kupno ok. 65 proc. akcji firmy Profitroom, oferującej systemy cyfrowe dla branży hotelarskiej. Wartość inwestycji to 190 mln zł.

## „Jak tak, to Allegro” w nowym cyklu reklam
 - [https://www.wirtualnemedia.pl/artykul/allegro-miedzynarodowa-kampania](https://www.wirtualnemedia.pl/artykul/allegro-miedzynarodowa-kampania)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-16T04:33:20.182878+00:00

Pod hasłem „Jak tak, to Allegro” ruszyła międzynarodowa kampania reklamowa, skupiająca się na różnorodności kategorii i szerokim wyborze produktów na platformie. Działania przygotowała agencja DDB Warszawa.

## Meghan Markle wyprodukuje dwa absurdalne programy dla Netfliksa. O czym będą opowiadać?
 - [https://www.wirtualnemedia.pl/artykul/meghan-markle-nowe-programy-dla-netfliksa-o-czym-beda-opowiadac-kiedy-premiera](https://www.wirtualnemedia.pl/artykul/meghan-markle-nowe-programy-dla-netfliksa-o-czym-beda-opowiadac-kiedy-premiera)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-16T04:33:20.163385+00:00

Meghan Markle zapowiedziała dwa nowe dokumenty dla Netfliksa, które stworzy za pośrednictwem wytwórni Archewell Productions. Seriale powstaną w ramach stałej umowy podpisanej z platformą. Ich opis sugeruje, że pomysły księżnej Sussex są na wyczerpaniu.

## Ponad jedna trzecia Polaków korzysta z alternatywnych źródeł informacji. To źródło teorii spiskowych
 - [https://www.wirtualnemedia.pl/artykul/ponad-jedna-trzecia-polakow-czerpie-wiedze-z-alternatywnych-zrodel-informacji-jak-to-wplywa-na-wiare-w-teorie-spiskowe](https://www.wirtualnemedia.pl/artykul/ponad-jedna-trzecia-polakow-czerpie-wiedze-z-alternatywnych-zrodel-informacji-jak-to-wplywa-na-wiare-w-teorie-spiskowe)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-16T04:33:20.144028+00:00

35 proc. dorosłych Polaków czerpie wiedzę z tzw. alternatywnych źródeł informacji – wynika z raportu Stowarzyszenia Demagog i Fundacji Digital Poland „Dezinformacja oczami Polaków”. Wpływa to na wiarę w różne teorie spiskowe – na przykład, że kolejne pandemie zostały już zaplanowane, czy że wojna w Ukrainie została wywołana, by na terenie Polski utworzyć żydowskie państwo Polin.

## o2.pl stawia na treści regionalne i wzmacnia redakcję
 - [https://www.wirtualnemedia.pl/artykul/o2-pl-portal-redakcja](https://www.wirtualnemedia.pl/artykul/o2-pl-portal-redakcja)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-04-16T04:33:20.124032+00:00

Nowe hasło „Blisko ludzi” będzie promować portal o2.pl (Grupa Wirtualna Polska). W ostatnich miesiącach skład redakcji zwiększył się prawie dwukrotnie, od marca br. na jej czele stanął Jacek Stańczyk. Zgodnie z nową strategią rozwoju w serwisie pojawiać się będzie jeszcze więcej treści regionalnych.

