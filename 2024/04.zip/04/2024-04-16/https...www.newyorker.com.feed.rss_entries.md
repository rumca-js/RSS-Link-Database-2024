# Source:The New Yorker, URL:https://www.newyorker.com/feed/rss, language:en-US

## Trump on Trial: The Defense Rests
 - [https://www.newyorker.com/cartoons/blitts-kvetchbook/trump-on-trial-the-defense-rests](https://www.newyorker.com/cartoons/blitts-kvetchbook/trump-on-trial-the-defense-rests)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-04-16T17:34:30+00:00

But is quickly roused awake!

## How to Both-Sides a “Civil War”
 - [https://www.newyorker.com/news/daily-comment/how-to-both-sides-a-civil-war](https://www.newyorker.com/news/daily-comment/how-to-both-sides-a-civil-war)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-04-16T16:16:23+00:00

In his new film, Alex Garland seems to be trying to have it both ways, using our dire politics as buzzy I.P. while tap-dancing around conversations that might get him in trouble.

## Daily Cartoon: Tuesday, April 16th
 - [https://www.newyorker.com/cartoons/daily-cartoon/tuesday-april-16th-goldilocks-and-the-fed](https://www.newyorker.com/cartoons/daily-cartoon/tuesday-april-16th-goldilocks-and-the-fed)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-04-16T14:23:54+00:00

“First, Goldilocks said the interest rates were too high. Then, Goldilocks said they were too low. Then, in agreement with the Federal Reserve Board, she finally said they were just right.”

## How I Use the Internet, According to Nineties Action Movies
 - [https://www.newyorker.com/humor/shouts-murmurs/how-i-use-the-internet-according-to-nineties-action-movies](https://www.newyorker.com/humor/shouts-murmurs/how-i-use-the-internet-according-to-nineties-action-movies)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-04-16T10:00:00+00:00

I pull up a digitized photo on the screen. Leaning in, I drag a bright-green box around a detail in the image, type rapidly for a full fifteen seconds, and then softly say, “Enhance.”

## The Crossword: Tuesday, April 16, 2024
 - [https://www.newyorker.com/puzzles-and-games-dept/crossword/2024/04/16](https://www.newyorker.com/puzzles-and-games-dept/crossword/2024/04/16)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-04-16T10:00:00+00:00

Perciatelli or tripoline: five letters.

## The Fate of Israel’s Hostages After Iran’s Rocket Attack
 - [https://www.newyorker.com/news/news-desk/the-fate-of-israels-hostages-after-irans-rocket-attack](https://www.newyorker.com/news/news-desk/the-fate-of-israels-hostages-after-irans-rocket-attack)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-04-16T10:00:00+00:00

As Prime Minister Benjamin Netanyahu oversees an increasingly fraught regional confrontation, the families of Hamas captives work to free their loved ones.

## The Unseen Sides of Francesca Woodman
 - [https://www.newyorker.com/culture/photo-booth/the-unseen-sides-of-francesca-woodman](https://www.newyorker.com/culture/photo-booth/the-unseen-sides-of-francesca-woodman)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-04-16T10:00:00+00:00

A new show at the Gagosian Gallery showcases the photographer’s tragically abbreviated career, including a never-before-exhibited masterpiece.

