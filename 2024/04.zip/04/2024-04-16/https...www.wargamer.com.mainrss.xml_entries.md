# Source:Wargamer, URL:https://www.wargamer.com/mainrss.xml, language:en-US

## A new Lego Star Wars Podracing set lands in May
 - [https://www.wargamer.com/lego/star-wars-podracing-diorama](https://www.wargamer.com/lego/star-wars-podracing-diorama)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T16:12:31+00:00

<img alt="A new Lego Star Wars Podracing set lands in May" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/04/lego-star-wars-podracing-diorama-1.jpg" title="A new Lego Star Wars Podracing set lands in May" width="1920" />
								<p>A new Lego Star Wars Podracing diorama will release on May 1 to celebrate the brand&rsquo;s 25th anniversary. &lsquo;Mos Espa Podrace Diorama&rsquo; is a 718-piece set that depicts one of our favorite prequel features &ndash; Podracing. This particular slice of Tatooine history will set you back $79.99 (&pound;69.99). The Star Wars Lego set is 4.5 &hellip; <a href="https://www.wargamer.com/lego/star-wars-podracing-diorama">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/lego/star-wars-podracing-diorama">A new Lego Star Wars Podracing set lands in May</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com/biggest-lego-sets">Biggest LEGO sets</a>, 

## The best Pokémon cards of all time
 - [https://www.wargamer.com/pokemon-trading-card-game/best-pokemon-cards](https://www.wargamer.com/pokemon-trading-card-game/best-pokemon-cards)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T16:02:30+00:00

<img alt="The best Pokémon cards of all time" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2021/05/best-pokemon-cards.jpg" title="The best Pokémon cards of all time" width="1920" />
								<p>Looking for the <strong>best Pokémon cards</strong>? There's a lot to choose from. With 25 years of expansions, Pokémon cards have become so numerous that filling your Pokédex is a lifetime achievement. But throughout all the playground trades and professional battles, some cards have cemented themselves as the best ever.</p>
<p>So what defines the best Pokémon cards? We could pick the <a href="https://www.wargamer.com/pokemon-trading-card-game/most-powerful-pokemon">most powerful Pokémon cards</a>, the most popular, or the prettiest. We could examine cards from the <a href="https://www.wargamer.com/pokemon-trading-card-game/best-pokemon-decks">best Pokémon decks</a>, or the <a href="https://www.wargamer.com/pokemon-trading-card-game/rare-p

## Yu Gi Oh! Banlist 2024
 - [https://www.wargamer.com/yugioh-trading-card-game/yu-gi-oh-banlist](https://www.wargamer.com/yugioh-trading-card-game/yu-gi-oh-banlist)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T15:59:28+00:00

<img alt="Yu Gi Oh! Banlist 2024" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2023/08/yugioh-banlist.jpg" title="Yu Gi Oh! Banlist 2024" width="1920" />
								<p>Though Yugioh is more of a wild west than other TCGs like Magic the Gathering or Pokemon TCG, the official <strong>Yugioh banlist</strong> makes many Yugioh cards Forbidden, Limited, or Semi Limited to keep the game fair, fun, and balanced. To help you keep your beloved tournament decks legal, we track the full list and latest updates in this guide.</p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/yugioh-trading-card-game/yu-gi-oh-banlist">Yu Gi Oh! Banlist 2024</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com/yugioh-trading-card-game/yu-gi-oh-banlist">Yugioh banlist</a>, <a href="https://www.wargamer.com/trading-card-games">Best Trading Card Games</a>, <a href="https://www.wargamer.com/yu-gi-oh-master-duel/meta-decks">Yugi

## 8 Warhammer 40k retcons bigger than female Adeptus Custodes
 - [https://www.wargamer.com/warhammer-40k/retcons-bigger-than-female-custodes](https://www.wargamer.com/warhammer-40k/retcons-bigger-than-female-custodes)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T15:25:35+00:00

<img alt="8 Warhammer 40k retcons bigger than female Adeptus Custodes" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/04/warhammer-40k-retcons.jpg" title="8 Warhammer 40k retcons bigger than female Adeptus Custodes" width="1920" />
								<p>Warhammer 40k retcons are part and parcel of the franchise: over 37 years the lore of the game has evolved, usually by introducing new features, occasionally by rewriting what came before. This whistle-stop tour will introduce you to a few honking great Warhammer 40k retcons you may have missed. With the recent Warhammer 40k Codex &hellip; <a href="https://www.wargamer.com/warhammer-40k/retcons-bigger-than-female-custodes">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/warhammer-40k/retcons-bigger-than-female-custodes">8 Warhammer 40k retcons bigger than female Adeptus Custodes</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com/wa

## New Vecna book returns to one of DnD 5e’s wonkiest dungeons
 - [https://www.wargamer.com/dnd/vecna-eve-of-ruin-death-house](https://www.wargamer.com/dnd/vecna-eve-of-ruin-death-house)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T15:03:40+00:00

<img alt="New Vecna book returns to one of DnD 5e’s wonkiest dungeons" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/04/dnd-vecna-eve-of-ruin-death-house-inquisitor.jpg" title="New Vecna book returns to one of DnD 5e’s wonkiest dungeons" width="1920" />
								<p>Vecna: Eve of Ruin takes Dungeons and Dragons players back to Ravenloft, and this means revisiting one of fifth edition&rsquo;s most well-known &ndash; and wonky &ndash; starter dungeons. We&rsquo;re talking about the infamous Death House. Designed back in 2016, this meat grinder of a building would mash level-one D&amp;D characters to a pulp, before they &hellip; <a href="https://www.wargamer.com/dnd/vecna-eve-of-ruin-death-house">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/dnd/vecna-eve-of-ruin-death-house">New Vecna book returns to one of DnD 5e’s wonkiest dungeons</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www

## You don’t need to be a DnD expert to play Vecna: Eve of Ruin
 - [https://www.wargamer.com/dnd/vecna-eve-of-ruin-expert](https://www.wargamer.com/dnd/vecna-eve-of-ruin-expert)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T15:00:41+00:00

<img alt="You don’t need to be a DnD expert to play Vecna: Eve of Ruin" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/04/dnd-vecna-eve-of-ruin-expert.jpg" title="You don’t need to be a DnD expert to play Vecna: Eve of Ruin" width="1920" />
								<p>Vecna: Eve of Ruin features many famous faces from Dungeons and Dragons history, but Wizards of the Coast says you won&rsquo;t need to be an expert to play. &ldquo;We don&rsquo;t expect people to know all this information or read Wikipedia pages before you pick up this book&rdquo;, says senior designer Amanda Hamon in a press &hellip; <a href="https://www.wargamer.com/dnd/vecna-eve-of-ruin-expert">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/dnd/vecna-eve-of-ruin-expert">You don’t need to be a DnD expert to play Vecna: Eve of Ruin</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com/dnd/classes">DnD classes guide</a>, <a 

## The final DnD 5e campaign goes “off the rails”
 - [https://www.wargamer.com/dnd/vecna-eve-of-ruin-multiverse](https://www.wargamer.com/dnd/vecna-eve-of-ruin-multiverse)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T15:00:39+00:00

<img alt="The final DnD 5e campaign goes &#8220;off the rails&#8221;" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/04/dnd-vecna-eve-of-ruin-multiverse.jpg" title="The final DnD 5e campaign goes &#8220;off the rails&#8221;" width="1920" />
								<p>Wizards of the Coast promises that Vecna: Eve of Ruin, its final DnD campaign before the arrival of the new core rulebooks, will be an &ldquo;off-the-rails&rdquo; adventure across the entire multiverse. In a press event on April 10, senior designer Amanda Hamon promises the book is &ldquo;as high-level as we can get and as memorable &hellip; <a href="https://www.wargamer.com/dnd/vecna-eve-of-ruin-multiverse">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/dnd/vecna-eve-of-ruin-multiverse">The final DnD 5e campaign goes &#8220;off the rails&#8221;</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com/dnd/classes">DnD classes g

## DnD’s new Vecna adventure is about the importance of consent
 - [https://www.wargamer.com/dnd/vecna-eve-of-ruin-consent](https://www.wargamer.com/dnd/vecna-eve-of-ruin-consent)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T15:00:15+00:00

<img alt="DnD&#8217;s new Vecna adventure is about the importance of consent" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/04/dnd-vecna-eve-of-ruin-consent.jpg" title="DnD&#8217;s new Vecna adventure is about the importance of consent" width="1920" />
								<p>More details about Vecna: Eve of Ruin were&nbsp;shared in a press event on April 10, and they reveal a surprising theme in the upcoming DnD book &ndash; the power of consent. Senior game designer Amanda Hamon says the campaign challenges you to stop Vecna and his cults, who &ldquo;steal secrets non-consensually&rdquo; to gain power. &ldquo;Even &hellip; <a href="https://www.wargamer.com/dnd/vecna-eve-of-ruin-consent">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/dnd/vecna-eve-of-ruin-consent">DnD&#8217;s new Vecna adventure is about the importance of consent</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com

## A complete guide to MTG planes
 - [https://www.wargamer.com/magic-the-gathering/mtg-planes](https://www.wargamer.com/magic-the-gathering/mtg-planes)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T14:04:12+00:00

<img alt="A complete guide to MTG planes" class="webfeedsFeaturedVisual" height="1081" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/04/magic-the-gathering-mtg-planes.jpg" title="A complete guide to MTG planes" width="1920" />
								<p>There are dozens of planes in Magic: The Gathering&rsquo;s extensive multiverse. But not all MTG planes are made equal. While some rival the depth of Dominaria with detailed cosmologies, a roster of gods, and multiple factions, others have scant little revealed about them. Here, you&rsquo;ll find information on the 29 most important planes in Magic &hellip; <a href="https://www.wargamer.com/magic-the-gathering/mtg-planes">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/magic-the-gathering/mtg-planes">A complete guide to MTG planes</a>
				</div>
				MORE FROM WARGAMER: <a href="https://www.wargamer.com/magic-the-gathering/mtg-sets-in-order">All MTG sets in order</a>, <a href="https://www.wargamer.com/

## Fallout TV show fans should watch out for Fallout Factions
 - [https://www.wargamer.com/fallout-factions-nuka-world/preview-fallout-tv-show](https://www.wargamer.com/fallout-factions-nuka-world/preview-fallout-tv-show)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T11:30:29+00:00

<img alt="Fallout TV show fans should watch out for Fallout Factions" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/04/fallout-factions-fallout-tv-show.jpg" title="Fallout TV show fans should watch out for Fallout Factions" width="1920" />
								<p>Whether you&rsquo;ve just discovered the world of Fallout via the Fallout TV show, or you&rsquo;ve been playing the videogames since they were isometric RPGs made by Black Isle Studios, Wargamer has a hot tip for you. We&rsquo;re currently testing Fallout Factions, an upcoming miniature wargame set in the Fallout universe, and so far, it&rsquo;s great. &hellip; <a href="https://www.wargamer.com/fallout-factions-nuka-world/preview-fallout-tv-show">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/fallout-factions-nuka-world/preview-fallout-tv-show">Fallout TV show fans should watch out for Fallout Factions</a>
				</div>
				MORE FROM WARGAMER: <a

## Breakout Standard deck fuels 520% MTG card price spike
 - [https://www.wargamer.com/magic-the-gathering/mtg-card-aftermath-analyst-price-spike](https://www.wargamer.com/magic-the-gathering/mtg-card-aftermath-analyst-price-spike)
 - RSS feed: https://www.wargamer.com/mainrss.xml
 - date published: 2024-04-16T10:50:37+00:00

<img alt="Breakout Standard deck fuels 520% MTG card price spike" class="webfeedsFeaturedVisual" height="1080" src="https://www.wargamer.com/wp-content/sites/wargamer/2024/04/mtg-card-aftermath-analyst-price-spike-art.jpg" title="Breakout Standard deck fuels 520% MTG card price spike" width="1920" />
								<p>A budget MTG card from Murders at Karlov Manor has seen a 520% price increase in recent weeks, and it&rsquo;s all thanks to an increasingly popular Standard deck. On March 18, Aftermath Analyst cost a measly $0.44 (&pound;0.35) on TCGPlayer. But as of April 16, that value has hit $2.73 (&pound;2.19). MTGGoldfish saw a similar &hellip; <a href="https://www.wargamer.com/magic-the-gathering/mtg-card-aftermath-analyst-price-spike">Continued</a></p>
 				<div>
				Continue reading <a href="https://www.wargamer.com/magic-the-gathering/mtg-card-aftermath-analyst-price-spike">Breakout Standard deck fuels 520% MTG card price spike</a>
				</div>
				MORE FROM WARGAMER: <a href="https://

