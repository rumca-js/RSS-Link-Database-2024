# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Democrats Question U.S. Claims That Israel Isn’t Violating International Law Using American Weapons
 - [https://theintercept.com/2024/04/16/israel-weapons-aid-us-biden-escobar](https://theintercept.com/2024/04/16/israel-weapons-aid-us-biden-escobar)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-04-16T20:03:12+00:00

<p>Biden campaign co-chair Rep. Veronica Escobar co-led a congressional letter questioning the administration's compliance with its own arms transfer memo.</p>
<p>The post <a href="https://theintercept.com/2024/04/16/israel-weapons-aid-us-biden-escobar/">Democrats Question U.S. Claims That Israel Isn’t Violating International Law Using American Weapons</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

