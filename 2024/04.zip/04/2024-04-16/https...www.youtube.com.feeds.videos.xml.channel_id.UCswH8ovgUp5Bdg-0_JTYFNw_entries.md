# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## WHAT happened to Maddie?!
 - [https://www.youtube.com/watch?v=sILlukDY4VY](https://www.youtube.com/watch?v=sILlukDY4VY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-04-16T22:00:30+00:00

Anxiety or gaslighting? Let me know what you think

## WW3... IT'S HAPPENING
 - [https://www.youtube.com/watch?v=0W60nYgtarc](https://www.youtube.com/watch?v=0W60nYgtarc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-04-16T17:00:01+00:00

Call 1(800) 245-6000 or visit https://taxnetworkusa.com/brand to get tax help. Don't let tax issues overpower you. Turn to Tax Network USA, and find your path to financial peace of mind.

In terrifying developments, Israel's war cabinet are considering whether to 'go big' against Iran - despite WW3 fears. 

Watch MY Interview with Tucker Carlson exclusively on Locals here: https://bit.ly/TuckerCarlsonLocals

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

## LANDMARK Lawsuit Against Government For Human Rights Violations During Pandemic - PREVIEW #346
 - [https://www.youtube.com/watch?v=BdWghbS_Z64](https://www.youtube.com/watch?v=BdWghbS_Z64)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-04-16T11:08:16+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show. To continue watching the show in full, join me exclusively over on RUMBLE: https://bit.ly/stayfree-346-Dr-Malhotra
--------------------------------------------------------------------------------------------------------------------------
Call 1(800) 245-6000 or visit https://taxnetworkusa.com/brand to get tax help. Don't let tax issues overpower you. Turn to Tax Network USA, and find your path to financial peace of mind.

Joining me now is Dr. Aseem Malhotra, a consultant cardiologist and public health campaigner. Dr. Aseem recently testified as an expert witness in the Helsinki District Court on April 12, 2024. The case is against the Finnish government for human rights violations due to the introduction of a vaccine passport in December 2022, when it was known that the vaccine didn’t stop transmission.

Join the awakening wonders community here: https://bit.ly/RussellBrand-Support

Visit the new merch store: https://bit.l

