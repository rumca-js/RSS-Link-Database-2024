# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## „Przyjaźń od kuchni” - McDonald’s reklamuje się jako pracodawca
 - [https://www.wirtualnemedia.pl/artykul/mcdonald-s-praca-zarobki-employer-branding](https://www.wirtualnemedia.pl/artykul/mcdonald-s-praca-zarobki-employer-branding)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-04-16T05:17:59.314656+00:00

W swojej najnowszej kampanii „McDonald’s. Przyjaźń od kuchni” popularna sieć fastfoodów stawia na employer branding.

## Carslberg Polska testuje nowe opakowania piwa
 - [https://www.wirtualnemedia.pl/artykul/carslberg-piwo-nowe-opakowania](https://www.wirtualnemedia.pl/artykul/carslberg-piwo-nowe-opakowania)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-04-16T04:13:08.776646+00:00

Carlsberg Polska testuje na polskim nowe opakowanie piwa – karton z zaokrąglonymi narożami. Rozwiązanie to ma pozwolić zaoszczędzić do 224 ton dwutlenku węgla rocznie, zwiększyć obszar komunikacji marketingowej z konsumentami i zapobiegać nieestetycznym zagnieceniom naroży.

