# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 NEW AA games You'll REGRET Overlooking
 - [https://www.youtube.com/watch?v=tb7e5GxG5Dc](https://www.youtube.com/watch?v=tb7e5GxG5Dc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-04-16T15:00:45+00:00

Here are some mid-budget, slightly less mainstream games that pack a punch.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1     

0:00 Intro 
0:15 Number 10
2:02 Number 9
3:45 Number 8
4:37 Number 7
6:04 Number 6
7:34 Number 5
9:00 Number 4
10:43 Number 3
11:59 Number 2
13:17 Number 1

