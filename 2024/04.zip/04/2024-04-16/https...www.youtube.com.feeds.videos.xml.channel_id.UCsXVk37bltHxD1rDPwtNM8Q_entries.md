# Source:Kurzgesagt – In a Nutshell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q, language:en-US

## There Are Thousands of Alien Empires in The Milky Way
 - [https://www.youtube.com/watch?v=L_JQOH1tEEA](https://www.youtube.com/watch?v=L_JQOH1tEEA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCsXVk37bltHxD1rDPwtNM8Q
 - date published: 2024-04-16T14:00:03+00:00

Go to https://ground.news/nutshell to get 40% off unlimited access to Ground News so you can compare coverage and think critically about the news you read. 

Get a very special piece of kurzgesagt you can take home (and support our channel in the process!) directly from the kurzgesagt shop here: https://shop.kgs.link/shop-191

Sources & further reading:
https://sites.google.com/view/sources-alien-empire-ocean

We often assume that advanced technology will make it easy for aliens to colonize space. But what if space exploration is always difficult, no matter how advanced you are? 
Let’s travel back in human history, to the colonization of Oceania over 5000 years ago, to find parallels between ancient explorers and extraterrestrial civilizations.

OUR CHANNELS
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
German:        https://kgs.link/youtubeDE
Spanish:        https://kgs.link/youtubeES
French:          https://kgs.link/youtubeFR
Portuguese:  https://kgs.link/youtubePT
Arabic:           https://kgs.link

