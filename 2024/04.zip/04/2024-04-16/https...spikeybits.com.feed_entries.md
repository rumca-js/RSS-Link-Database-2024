# Source:Spikey Bits, URL:https://spikeybits.com/feed, language:en-US

## Current 40k Armies You CAN’T Sleep On, Towering Over The Meta!
 - [https://spikeybits.com/warhammer-40k/meta-current-armies-you-cant-sleep-on](https://spikeybits.com/warhammer-40k/meta-current-armies-you-cant-sleep-on)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T19:30:00+00:00

<p><p><a href="https://spikeybits.com/?p=460069&amp;preview=true"><img alt="Imperial Knight Wal Hor 1200" class="wp-image-460159 size-full aligncenter" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/Imperial-Knight-Wal-Hor-1200.png" width="1280" /></a></p>
<p>40k tournament players are familiar with two F-tier armies on seemingly different trajectories, but not all is what it seems in the meta.</p>
<p><span id="more-460069"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
<div></p>
<p><a href="https://spikeybits.com/warhammer-40k/meta-current-armies-you-cant-sleep-on/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/meta-current-armies-you-cant-sleep-on/">Current 40k Armies You CAN&#8217;T Sleep On, Towering Over The Meta!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## AdeptiCon Changes Locations: Moving to a Bigger Venue In 2025
 - [https://spikeybits.com/adepticon/adepticon-changes-locations-moving-to-a-bigger-venue-in-2025](https://spikeybits.com/adepticon/adepticon-changes-locations-moving-to-a-bigger-venue-in-2025)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T18:30:15+00:00

<p><p><a href="https://spikeybits.com/?p=460160&amp;preview=true"><img alt="AdeptiCon 2025 Location Change" class="aligncenter wp-image-460161 size-full" height="529" src="https://spikeybits.com/wp-content/uploads/2024/04/AdeptiCon-2025-Location-Change.png" width="780" /></a></p>
<p>AdeptiCon has outgrown the Schaumburg Convention Center with year-over-year growth, and there is going to be a big location change in 2025!</p>
<p><span id="more-460160"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch"></p>
<p><a href="https://spikeybits.com/adepticon/adepticon-changes-locations-moving-to-a-bigger-venue-in-2025/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/adepticon/adepticon-changes-locations-moving-to-a-bigger-venue-in-2025/">AdeptiCon Changes Locations: Moving to a Bigger Venue In 2025</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## GW Said Slaanesh Codex & They Can’t Take It Back Now!
 - [https://spikeybits.com/2024/04/gw-said-codex-slaanesh-they-cant-take-it-back-now.html](https://spikeybits.com/2024/04/gw-said-codex-slaanesh-they-cant-take-it-back-now.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T17:30:40+00:00

<p><p><a href="https://spikeybits.com/?p=460164&amp;preview=true"><img alt="fulgrim slaanesh wal hor title" class="aligncenter wp-image-460171 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/fulgrim-slaanesh-wal-hor-title.png" width="1280" /></a>GW is removing some 40k Emperor&#8217;s Children from the Chaos Space Marines Codex, and hinted that a book for Slaanesh is on the menu as</p>
<p><a href="https://spikeybits.com/2024/04/gw-said-codex-slaanesh-they-cant-take-it-back-now.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/04/gw-said-codex-slaanesh-they-cant-take-it-back-now.html">GW Said Slaanesh Codex &#038; They Can&#8217;t Take It Back Now!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## GW Said Slaanesh Codex & They Can’t Take It Back Now!
 - [https://spikeybits.com/warhammer-40k/gw-said-codex-slaanesh-they-cant-take-it-back-now](https://spikeybits.com/warhammer-40k/gw-said-codex-slaanesh-they-cant-take-it-back-now)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T17:30:40+00:00

<p><p><a href="https://spikeybits.com/?p=460164&amp;preview=true"><img alt="fulgrim slaanesh wal hor title" class="aligncenter wp-image-460171 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/fulgrim-slaanesh-wal-hor-title.png" width="1280" /></a>GW is removing some 40k Emperor&#8217;s Children from the Chaos Space Marines Codex, and hinted that a book for Slaanesh is on the menu as</p>
<p><a href="https://spikeybits.com/warhammer-40k/gw-said-codex-slaanesh-they-cant-take-it-back-now/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/gw-said-codex-slaanesh-they-cant-take-it-back-now/">GW Said Slaanesh Codex &#038; They Can&#8217;t Take It Back Now!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Update Your Old World Bases With Trays, Converters & Resin Designs
 - [https://spikeybits.com/basing/update-your-old-world-bases-with-trays-converters-resin-designs](https://spikeybits.com/basing/update-your-old-world-bases-with-trays-converters-resin-designs)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T16:30:52+00:00

<p><p><a href="https://spikeybits.com/?p=459851&amp;preview=true"><img alt="warhammer the old world bases resin converters movement trays" class="aligncenter wp-image-460182 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/warhammer-the-old-world-bases-resin-converters-movement-trays.png" width="1280" /></a>Easily rank up or rebase your Warhammer the Old World models with these square bases, movement trays, and converters from Elrik&#8217;s</p>
<p><a href="https://spikeybits.com/basing/update-your-old-world-bases-with-trays-converters-resin-designs/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/basing/update-your-old-world-bases-with-trays-converters-resin-designs/">Update Your Old World Bases With Trays, Converters &#038; Resin Designs</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Update Your Old World Bases With Trays, Converters & Resin Designs
 - [https://spikeybits.com/2024/04/update-your-old-world-bases-with-trays-converters-resin-designs.html](https://spikeybits.com/2024/04/update-your-old-world-bases-with-trays-converters-resin-designs.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T16:30:52+00:00

<p><p><a href="https://spikeybits.com/?p=459851&amp;preview=true"><img alt="warhammer the old world bases resin converters movement trays" class="aligncenter wp-image-460182 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/warhammer-the-old-world-bases-resin-converters-movement-trays.png" width="1280" /></a>Easily rank up or rebase your Warhammer the Old World models with these square bases, movement trays, and converters from Elrik&#8217;s</p>
<p><a href="https://spikeybits.com/2024/04/update-your-old-world-bases-with-trays-converters-resin-designs.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/04/update-your-old-world-bases-with-trays-converters-resin-designs.html">Update Your Old World Bases With Trays, Converters &#038; Resin Designs</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## GW Should Really Do The Right Thing Here…
 - [https://spikeybits.com/warhammer-40k/gw-should-really-do-the-right-thing-here](https://spikeybits.com/warhammer-40k/gw-should-really-do-the-right-thing-here)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T16:05:06+00:00

<p><p><a href="https://spikeybits.com/?p=460068&amp;preview=true"><img alt="made to order orks custodes battleforces" class="aligncenter wp-image-460066 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/made-to-order-orks-custodes-battleforces.png" width="1280" /></a>Games Workshop pulled a fast one with low numbers of these battleforces, but we have a fix that would make GW look like the</p>
<p><a href="https://spikeybits.com/warhammer-40k/gw-should-really-do-the-right-thing-here/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/gw-should-really-do-the-right-thing-here/">GW Should Really Do The Right Thing Here&#8230;</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## GW Should Really Do The Right Thing Here…
 - [https://spikeybits.com/2024/04/gw-should-really-do-the-right-thing-here.html](https://spikeybits.com/2024/04/gw-should-really-do-the-right-thing-here.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T15:30:06+00:00

<p><p><a href="https://spikeybits.com/?p=460068&amp;preview=true"><img alt="made to order orks custodes battleforces" class="aligncenter wp-image-460066 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/04/made-to-order-orks-custodes-battleforces.png" width="1280" /></a>Games Workshop pulled a fast one with low numbers of these battleforces, but we have a fix that would make GW look like the</p>
<p><a href="https://spikeybits.com/2024/04/gw-should-really-do-the-right-thing-here.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/04/gw-should-really-do-the-right-thing-here.html">GW Should Really Do The Right Thing Here&#8230;</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Cover Your Table With Easy To Build Terrain From One Small Box
 - [https://spikeybits.com/terrain/cover-your-table-in-easy-to-build-terrain-from-squad-marks](https://spikeybits.com/terrain/cover-your-table-in-easy-to-build-terrain-from-squad-marks)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T14:30:17+00:00

<p><p><a href="https://spikeybits.com/?p=459230&amp;preview=true"><img alt="Cyber City Terrain feature" class="aligncenter wp-image-428750" height="664" src="https://spikeybits.com/wp-content/uploads/2023/03/Cyber-City-Terrain-feature.png" width="1283" /></a>Cover your table with easy-to-build scenery for your next tabletop adventure with Squad Marks Battle Ready Terrain!</p>
<p><span id="more-459230"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p><span>This is a</p>
<p><a href="https://spikeybits.com/terrain/cover-your-table-in-easy-to-build-terrain-from-squad-marks/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/terrain/cover-your-table-in-easy-to-build-terrain-from-squad-marks/">Cover Your Table With Easy To Build Terrain From One Small Box</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Cover Your Table With Easy To Build Terrain From One Small Box
 - [https://spikeybits.com/2024/04/cover-your-table-in-easy-to-build-terrain-from-squad-marks.html](https://spikeybits.com/2024/04/cover-your-table-in-easy-to-build-terrain-from-squad-marks.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T14:30:17+00:00

<p><p><a href="https://spikeybits.com/?p=459230&amp;preview=true"><img alt="Cyber City Terrain feature" class="aligncenter wp-image-428750" height="664" src="https://spikeybits.com/wp-content/uploads/2023/03/Cyber-City-Terrain-feature.png" width="1283" /></a>Cover your table with easy-to-build scenery for your next tabletop adventure with Squad Marks Battle Ready Terrain!</p>
<p><span id="more-459230"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p><span>This is a</p>
<p><a href="https://spikeybits.com/2024/04/cover-your-table-in-easy-to-build-terrain-from-squad-marks.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/04/cover-your-table-in-easy-to-build-terrain-from-squad-marks.html">Cover Your Table With Easy To Build Terrain From One Small Box</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Aelven Banners Held High: New GW Rumor Engine
 - [https://spikeybits.com/2024/04/new-banners-held-high-gw-rumor-engine.html](https://spikeybits.com/2024/04/new-banners-held-high-gw-rumor-engine.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T13:30:32+00:00

<p><p><a href="https://spikeybits.com/?p=460155&amp;preview=true"><img alt="Rumor Engine new GW header wal hor" class="aligncenter wp-image-330587 size-full" height="493" src="https://spikeybits.com/wp-content/uploads/2020/08/402380a6-rumor-engine-new-gw-header-wal-hor.jpg" width="740" /></a>This new Games Workshop rumor engine preview looks like it could be part of a new Lumineth or High Elves banner, or</p>
<p><a href="https://spikeybits.com/2024/04/new-banners-held-high-gw-rumor-engine.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/04/new-banners-held-high-gw-rumor-engine.html">Aelven Banners Held High: New GW Rumor Engine</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Aelven Banners Held High: New GW Rumor Engine
 - [https://spikeybits.com/warhammer-40k/new-banners-held-high-gw-rumor-engine](https://spikeybits.com/warhammer-40k/new-banners-held-high-gw-rumor-engine)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T13:30:32+00:00

<p><p><a href="https://spikeybits.com/?p=460155&amp;preview=true"><img alt="Rumor Engine new GW header wal hor" class="aligncenter wp-image-330587 size-full" height="493" src="https://spikeybits.com/wp-content/uploads/2020/08/402380a6-rumor-engine-new-gw-header-wal-hor.jpg" width="740" /></a>This new Games Workshop rumor engine preview looks like it could be part of a new Lumineth or High Elves banner, or</p>
<p><a href="https://spikeybits.com/warhammer-40k/new-banners-held-high-gw-rumor-engine/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/new-banners-held-high-gw-rumor-engine/">Aelven Banners Held High: New GW Rumor Engine</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New AoS Darkoath Army Box & Old World Pricing CONFIRMED
 - [https://spikeybits.com/age-of-sigmar/new-aos-darkoath-army-box-old-world-pricing-confirmed](https://spikeybits.com/age-of-sigmar/new-aos-darkoath-army-box-old-world-pricing-confirmed)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T12:05:44+00:00

<p><p><a href="https://spikeybits.com/?p=460075&amp;preview=true"><img alt="new release pricing dark oath box set warhammer age of sigmar slaves to darkness chaos" class="aligncenter wp-image-460017 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/03/new-release-pricing-dark-oath-box-set-warhammer-age-of-sigmar-slaves-to-darkness-chaos.png" width="1280" /></a>Here is the confirmed pre-order pricing for the Darkoath Army Box for AoS and a</p>
<p><a href="https://spikeybits.com/age-of-sigmar/new-aos-darkoath-army-box-old-world-pricing-confirmed/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/age-of-sigmar/new-aos-darkoath-army-box-old-world-pricing-confirmed/">New AoS Darkoath Army Box &#038; Old World Pricing CONFIRMED</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New AoS Darkoath Army Box & Old World Pricing CONFIRMED
 - [https://spikeybits.com/2024/04/new-aos-darkoath-army-box-old-world-pricing-confirmed.html](https://spikeybits.com/2024/04/new-aos-darkoath-army-box-old-world-pricing-confirmed.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T10:30:44+00:00

<p><p><a href="https://spikeybits.com/?p=460075&amp;preview=true"><img alt="new release pricing dark oath box set warhammer age of sigmar slaves to darkness chaos" class="aligncenter wp-image-460017 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/03/new-release-pricing-dark-oath-box-set-warhammer-age-of-sigmar-slaves-to-darkness-chaos.png" width="1280" /></a>Here is the confirmed pre-order pricing for the Darkoath Army Box for AoS and a</p>
<p><a href="https://spikeybits.com/2024/04/new-aos-darkoath-army-box-old-world-pricing-confirmed.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/04/new-aos-darkoath-army-box-old-world-pricing-confirmed.html">New AoS Darkoath Army Box &#038; Old World Pricing CONFIRMED</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Rev Up the WAAAGH! Kromlech’s Orc Tigerwagon Is Back!
 - [https://spikeybits.com/2024/04/kromlechs-orc-tigerwagon-is-back-once-again.html](https://spikeybits.com/2024/04/kromlechs-orc-tigerwagon-is-back-once-again.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T09:30:18+00:00

<p><p><a href="https://spikeybits.com/?p=459195&amp;preview=true"><img alt="ORC TIGERWAGON " class="aligncenter wp-image-459196" height="726" src="https://spikeybits.com/wp-content/uploads/2024/04/Screenshot_180.png" width="1280" /></a>Everyone&#8217;s WAAAGH! just got a massive resupply, as Kromlech has brought back their infamous Orc Tigerwagon!</p>
<p><span id="more-459195"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p><span>Kromlech always releases some of</p>
<p><a href="https://spikeybits.com/2024/04/kromlechs-orc-tigerwagon-is-back-once-again.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/04/kromlechs-orc-tigerwagon-is-back-once-again.html">Rev Up the WAAAGH! Kromlech&#8217;s Orc Tigerwagon Is Back!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Rev Up the WAAAGH! Kromlech’s Orc Tigerwagon Is Back!
 - [https://spikeybits.com/warhammer-40k/kromlechs-orc-tigerwagon-is-back-once-again](https://spikeybits.com/warhammer-40k/kromlechs-orc-tigerwagon-is-back-once-again)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-04-16T09:30:18+00:00

<p><p><a href="https://spikeybits.com/?p=459195&amp;preview=true"><img alt="ORC TIGERWAGON " class="aligncenter wp-image-459196" height="726" src="https://spikeybits.com/wp-content/uploads/2024/04/Screenshot_180.png" width="1280" /></a>Everyone&#8217;s WAAAGH! just got a massive resupply, as Kromlech has brought back their infamous Orc Tigerwagon!</p>
<p><span id="more-459195"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p><span>Kromlech always releases some of</p>
<p><a href="https://spikeybits.com/warhammer-40k/kromlechs-orc-tigerwagon-is-back-once-again/">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/warhammer-40k/kromlechs-orc-tigerwagon-is-back-once-again/">Rev Up the WAAAGH! Kromlech&#8217;s Orc Tigerwagon Is Back!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

