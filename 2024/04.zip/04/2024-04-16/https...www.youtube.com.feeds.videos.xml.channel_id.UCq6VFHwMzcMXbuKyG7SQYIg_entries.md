# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## Embarrassing Alpha Male Bootcamp
 - [https://www.youtube.com/watch?v=9wWMAAGdYcY](https://www.youtube.com/watch?v=9wWMAAGdYcY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-04-16T19:00:04+00:00

This is the greatest silly camp of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/?ref=moist

## Giving away money and playing Gears 2
 - [https://www.youtube.com/watch?v=lY45A5kWhI4](https://www.youtube.com/watch?v=lY45A5kWhI4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-04-16T06:24:48+00:00

Merch https://moistglobal.com/
Comics https://badegg.co/

