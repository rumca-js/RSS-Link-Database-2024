# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## How to Paint: Regal Blue  | Intermediate | #Warhammer
 - [https://www.youtube.com/watch?v=OXKljazI5WM](https://www.youtube.com/watch?v=OXKljazI5WM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2024-04-16T09:52:19+00:00

Painting loyal Space Marines, or the noble robes of mortal champions? This step-by-step guide will show you how to paint a rich and regal blue that you can use on many of your models, with just five paints. Follow along as we paint this bold colour onto Space Marine armour, a Freeguild Marshal's soft cloak, and the hard scales of a Seraphon.

Base Paints:
Macragge Blue
 Layer Paints:
Altdorf Guard Blue
Calgar Blue
Shade Paints:
Tyran Blue, Nuln Oil

If you're new to painting, our Citadel Colour Painting Essentials playlist hosts an array of beginner-friendly videos to help you get started.

Follow for more Warhammer, more often:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/

