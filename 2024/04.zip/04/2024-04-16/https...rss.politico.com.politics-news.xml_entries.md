# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en

## ‘Parameters of a conceptual agreement’? Not so fast.
 - [https://www.politico.com/newsletters/new-york-playbook-pm/2024/04/16/hochul-weve-agreed-lawmakers-we-have-00152549](https://www.politico.com/newsletters/new-york-playbook-pm/2024/04/16/hochul-weve-agreed-lawmakers-we-have-00152549)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-04-16T15:41:09+00:00



## Biden cracks jokes about Trump as hush money trial kicks off
 - [https://www.politico.com/video/2024/04/16/biden-cracks-jokes-about-trump-as-hush-money-trial-kicks-off-1294391](https://www.politico.com/video/2024/04/16/biden-cracks-jokes-about-trump-as-hush-money-trial-kicks-off-1294391)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-04-16T15:39:42+00:00



