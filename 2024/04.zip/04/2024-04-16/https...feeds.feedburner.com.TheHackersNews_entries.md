# Source:The Hacker News, URL:https://feeds.feedburner.com/TheHackersNews, language:en-US

## OpenJS Foundation Targeted in Potential JavaScript Project Takeover Attempt
 - [https://thehackernews.com/2024/04/openjs-foundation-targeted-in-potential.html](https://thehackernews.com/2024/04/openjs-foundation-targeted-in-potential.html)
 - RSS feed: https://feeds.feedburner.com/TheHackersNews
 - date published: 2024-04-16T15:16:00+00:00

Security researchers have uncovered a "credible" takeover attempt targeting the OpenJS Foundation in a manner that evokes similarities to the recently uncovered incident aimed at the open-source XZ Utils project.
"The OpenJS Foundation Cross Project Council received a suspicious series of emails with similar messages, bearing different names and overlapping GitHub-associated emails," OpenJS

## TA558 Hackers Weaponize Images for Wide-Scale Malware Attacks
 - [https://thehackernews.com/2024/04/ta558-hackers-weaponize-images-for-wide.html](https://thehackernews.com/2024/04/ta558-hackers-weaponize-images-for-wide.html)
 - RSS feed: https://feeds.feedburner.com/TheHackersNews
 - date published: 2024-04-16T13:39:00+00:00

The threat actor tracked as&nbsp;TA558&nbsp;has been observed leveraging steganography as an obfuscation technique to deliver a wide range of malware such as Agent Tesla, FormBook, Remcos RAT, LokiBot, GuLoader, Snake Keylogger, and XWorm, among others.
"The group made extensive use of steganography by sending VBSs, PowerShell code, as well as RTF documents with an embedded exploit, inside

## AWS, Google, and Azure CLI Tools Could Leak Credentials in Build Logs
 - [https://thehackernews.com/2024/04/aws-google-and-azure-cli-tools-could.html](https://thehackernews.com/2024/04/aws-google-and-azure-cli-tools-could.html)
 - RSS feed: https://feeds.feedburner.com/TheHackersNews
 - date published: 2024-04-16T13:26:00+00:00

New cybersecurity research has found that command-line interface (CLI) tools from Amazon Web Services (AWS) and Google Cloud can expose sensitive credentials in build logs, posing significant risks to organizations.
The vulnerability has been codenamed&nbsp;LeakyCLI&nbsp;by cloud security firm Orca.
"Some commands on Azure CLI, AWS CLI, and Google Cloud CLI can expose sensitive information in

## Widely-Used PuTTY SSH Client Found Vulnerable to Key Recovery Attack
 - [https://thehackernews.com/2024/04/widely-used-putty-ssh-client-found.html](https://thehackernews.com/2024/04/widely-used-putty-ssh-client-found.html)
 - RSS feed: https://feeds.feedburner.com/TheHackersNews
 - date published: 2024-04-16T11:14:00+00:00

The maintainers of the&nbsp;PuTTY Secure Shell (SSH) and Telnet client&nbsp;are alerting users of a critical vulnerability impacting versions from 0.68 through 0.80 that could be exploited to achieve full recovery of NIST P-521 (ecdsa-sha2-nistp521) private keys.
The flaw has been assigned the CVE identifier&nbsp;CVE-2024-31497, with the discovery credited to researchers Fabian Bäumer and Marcus

## Identity in the Shadows: Shedding Light on Cybersecurity's Unseen Threats
 - [https://thehackernews.com/2024/04/identity-in-shadows-shedding-light-on.html](https://thehackernews.com/2024/04/identity-in-shadows-shedding-light-on.html)
 - RSS feed: https://feeds.feedburner.com/TheHackersNews
 - date published: 2024-04-16T11:10:00+00:00

In today's rapidly evolving digital landscape, organizations face an increasingly complex array of cybersecurity threats. The proliferation of cloud services and remote work arrangements has heightened the vulnerability of digital identities to exploitation, making it imperative for businesses to fortify their identity security measures.
Our recent research report,&nbsp;The Identity Underground

## FTC Fines Mental Health Startup Cerebral $7 Million for Major Privacy Violations
 - [https://thehackernews.com/2024/04/ftc-fines-mental-health-startup.html](https://thehackernews.com/2024/04/ftc-fines-mental-health-startup.html)
 - RSS feed: https://feeds.feedburner.com/TheHackersNews
 - date published: 2024-04-16T08:36:00+00:00

The U.S. Federal Trade Commission (FTC) has ordered the mental telehealth company Cerebral from using or disclosing personal data for advertising purposes.
It has also been fined more than $7 million over charges that it revealed users' sensitive personal health information and other data to third parties for advertising purposes and failed to honor its easy cancellation policies.
"Cerebral and

## Hive RAT Creators and $3.5M Cryptojacking Mastermind Arrested in Global Crackdown
 - [https://thehackernews.com/2024/04/hive-rat-creators-and-35m-cryptojacking.html](https://thehackernews.com/2024/04/hive-rat-creators-and-35m-cryptojacking.html)
 - RSS feed: https://feeds.feedburner.com/TheHackersNews
 - date published: 2024-04-16T07:33:00+00:00

Two individuals have been arrested in Australia and the U.S. in connection with an alleged scheme to develop and distribute a remote access trojan called Hive RAT (previously Firebird).
The U.S. Justice Department (DoJ)&nbsp;said&nbsp;the malware "gave the malware purchasers control over victim computers and enabled them to access victims' private communications, their login credentials, and

