# Source:Lost in Time, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCac6m8K3OGHUT4itHwpCAmw, language:en

## Madrid 128 years ago in color!🇪🇸 #shorts #history
 - [https://www.youtube.com/watch?v=6YHhR6rcY4s](https://www.youtube.com/watch?v=6YHhR6rcY4s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCac6m8K3OGHUT4itHwpCAmw
 - date published: 2024-04-16T17:03:45+00:00



