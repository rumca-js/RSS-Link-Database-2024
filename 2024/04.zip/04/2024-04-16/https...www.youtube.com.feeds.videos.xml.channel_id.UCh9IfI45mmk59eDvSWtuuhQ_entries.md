# Source:Ryan George, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ, language:en-US

## When The Band Introduction Takes Too Long
 - [https://www.youtube.com/watch?v=qOCHMWHugtQ](https://www.youtube.com/watch?v=qOCHMWHugtQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCh9IfI45mmk59eDvSWtuuhQ
 - date published: 2024-04-16T13:58:35+00:00

Download Opera for free: https://opr.as/jmoh-ryangeorge

Hi there hello please click the subscribe button and turn on notifications so I can feed my cats and dog and baby.
Twitter/Instagram: @TheRyanGeorge

Written in collaboration with Scott Roberts

