# Source:RP - Edukacja, URL:https://edukacja.rp.pl/rss/8681-edukacja, language:pl-PL

## Podstawa programowa w szkołach. Barbara Nowacka zapowiada odchudzenie o 20 proc.
 - [https://www.rp.pl/polityka/art40177301-podstawa-programowa-w-szkolach-barbara-nowacka-zapowiada-odchudzenie-o-20-proc](https://www.rp.pl/polityka/art40177301-podstawa-programowa-w-szkolach-barbara-nowacka-zapowiada-odchudzenie-o-20-proc)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-04-16T12:03:00+00:00

- Mam poczucie głębokiej niesprawiedliwości, że dzieci rodziców zamożniejszych albo z większą ilością czasu i wysokimi kompetencjami społecznymi mogły się znacznie lepiej przygotowywać w domu - powiedziała minister edukacji Barbara Nowacka (KO), broniąc zmian dotyczących prac domowych. W rozmowie z Polsat News zapowiedziała szybkie odchudzenie podstawy programowej w szkołach.

