# Source:Home Repair Tutor, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA, language:en

## Floor Joist Blocking for Subfloor Panels - #shorts
 - [https://www.youtube.com/watch?v=l8e6m0rxj80](https://www.youtube.com/watch?v=l8e6m0rxj80)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA
 - date published: 2024-04-16T11:00:44+00:00

Floor joist blocking for subfloor panels...if you're remodeling a bathroom and need help, join our Video Library and make your project easier at https://homerepairtutor.com/

