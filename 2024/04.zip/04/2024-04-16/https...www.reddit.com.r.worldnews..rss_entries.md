# Source:Reddit - World News, URL:https://www.reddit.com/r/worldnews/.rss, language:en

## Zelensky: Russia fires 10 times more shells, uses 300 aircraft in Ukraine only
 - [https://www.reddit.com/r/worldnews/comments/1c5ql23/zelensky_russia_fires_10_times_more_shells_uses](https://www.reddit.com/r/worldnews/comments/1c5ql23/zelensky_russia_fires_10_times_more_shells_uses)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T20:35:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5ql23/zelensky_russia_fires_10_times_more_shells_uses/"> <img alt="Zelensky: Russia fires 10 times more shells, uses 300 aircraft in Ukraine only" src="https://external-preview.redd.it/CbfFgFR37Q_0x_rPGZsT7Nc5Ek6zsZTQukNTzcW205o.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=994ac2ad5214df74ac62c99aaf6f7940c15ce14d" title="Zelensky: Russia fires 10 times more shells, uses 300 aircraft in Ukraine only" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/stuckollg"> /u/stuckollg </a> <br /> <span><a href="https://kyivindependent.com/zelensky-14/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5ql23/zelensky_russia_fires_10_times_more_shells_uses/">[comments]</a></span> </td></tr></table>

## Huge Saharan dust blob cooling eastern Atlantic
 - [https://www.reddit.com/r/worldnews/comments/1c5pueq/huge_saharan_dust_blob_cooling_eastern_atlantic](https://www.reddit.com/r/worldnews/comments/1c5pueq/huge_saharan_dust_blob_cooling_eastern_atlantic)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T20:05:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5pueq/huge_saharan_dust_blob_cooling_eastern_atlantic/"> <img alt="Huge Saharan dust blob cooling eastern Atlantic" src="https://external-preview.redd.it/YJqx_oF1pUOFQmlMjSepklPAtnbC-0kihheUI4DdUPQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=19fcd44db2e527dbdefd41b22ba1501ac3a1e90a" title="Huge Saharan dust blob cooling eastern Atlantic" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CrispyMiner"> /u/CrispyMiner </a> <br /> <span><a href="https://www.yahoo.com/news/huge-saharan-dust-blob-cooling-205355023.html?guccounter=1&amp;guce_referrer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8&amp;guce_referrer_sig=AQAAABAaK0Y5_RYD7ZGiVL9WCkT5Tc_sXsa3m_z1NFaVzoZ4hbzn4ANColDrmqu-7vxq8bN5aNuH12bh2IHVXGd7et3Y9ez3gaUjsM-Z03blTmouDCEeHQAI0R_C4AdkYitvxcsZEYE7onuoBtn8DctydDzjxOCVlBQviyppbcxfK10v">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5pueq/huge_saharan_dust_b

## Russian peacekeepers are leaving Azerbaijan territory, Karabakh region now fully under government control - Azerbaijan government newspaper
 - [https://www.reddit.com/r/worldnews/comments/1c5p5sb/russian_peacekeepers_are_leaving_azerbaijan](https://www.reddit.com/r/worldnews/comments/1c5p5sb/russian_peacekeepers_are_leaving_azerbaijan)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T19:37:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5p5sb/russian_peacekeepers_are_leaving_azerbaijan/"> <img alt="Russian peacekeepers are leaving Azerbaijan territory, Karabakh region now fully under government control - Azerbaijan government newspaper" src="https://external-preview.redd.it/V-nyW0hZxHeB00dRAl7HCpcQKR78y6Dc3-GnH_FAalc.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=cf31cb5bbb439787b980fe93236a47cb46f3b5e3" title="Russian peacekeepers are leaving Azerbaijan territory, Karabakh region now fully under government control - Azerbaijan government newspaper" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Weak-Address-386"> /u/Weak-Address-386 </a> <br /> <span><a href="https://caliber.az/post/234168/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5p5sb/russian_peacekeepers_are_leaving_azerbaijan/">[comments]</a></span> </td></tr></table>

## EU pledges €3.5 billion to protect world's oceans
 - [https://www.reddit.com/r/worldnews/comments/1c5otlf/eu_pledges_35_billion_to_protect_worlds_oceans](https://www.reddit.com/r/worldnews/comments/1c5otlf/eu_pledges_35_billion_to_protect_worlds_oceans)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T19:23:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5otlf/eu_pledges_35_billion_to_protect_worlds_oceans/"> <img alt="EU pledges €3.5 billion to protect world's oceans " src="https://external-preview.redd.it/Ey-zMfI3PNkqkXOFyp9FzIRlD1k17SSvVFOdtKqCHyk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2852545f0a1e2a030e78c4551a96f1bd5b477fdd" title="EU pledges €3.5 billion to protect world's oceans " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/donutloop"> /u/donutloop </a> <br /> <span><a href="https://www.dw.com/en/eu-pledges-35-billion-to-protect-worlds-oceans/a-68836625">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5otlf/eu_pledges_35_billion_to_protect_worlds_oceans/">[comments]</a></span> </td></tr></table>

## UK MPs back smoking ban for those born after 2009
 - [https://www.reddit.com/r/worldnews/comments/1c5nzlb/uk_mps_back_smoking_ban_for_those_born_after_2009](https://www.reddit.com/r/worldnews/comments/1c5nzlb/uk_mps_back_smoking_ban_for_those_born_after_2009)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T18:50:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5nzlb/uk_mps_back_smoking_ban_for_those_born_after_2009/"> <img alt="UK MPs back smoking ban for those born after 2009" src="https://external-preview.redd.it/A5VHLNmYrnf0nEgApddkTpYf-WvmNrHdbAmClyqKb7k.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0e5cbdeb128e6eb35852e0d4320a6937c5339f8c" title="UK MPs back smoking ban for those born after 2009" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Yaarmehearty"> /u/Yaarmehearty </a> <br /> <span><a href="https://www.bbc.co.uk/news/uk-politics-68824493">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5nzlb/uk_mps_back_smoking_ban_for_those_born_after_2009/">[comments]</a></span> </td></tr></table>

## Artur Demidenko a Russian pacifist, died last Friday in pre-detention custody in Belgorod. He helped Ukrainians flee the country. Then the Kremlin caught him. | Guardian
 - [https://www.reddit.com/r/worldnews/comments/1c5nwqm/artur_demidenko_a_russian_pacifist_died_last](https://www.reddit.com/r/worldnews/comments/1c5nwqm/artur_demidenko_a_russian_pacifist_died_last)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T18:46:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5nwqm/artur_demidenko_a_russian_pacifist_died_last/"> <img alt="Artur Demidenko a Russian pacifist, died last Friday in pre-detention custody in Belgorod. He helped Ukrainians flee the country. Then the Kremlin caught him. | Guardian" src="https://external-preview.redd.it/1kwU7yP-zoLyBqjWhflfxzwYloYT2t4YY0NaxwmjsQk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=47acd56753ca929365e37582aef0784be5311a50" title="Artur Demidenko a Russian pacifist, died last Friday in pre-detention custody in Belgorod. He helped Ukrainians flee the country. Then the Kremlin caught him. | Guardian" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/peretonea"> /u/peretonea </a> <br /> <span><a href="https://www.theguardian.com/world/2024/apr/13/a-russian-pacifist-helped-ukrainians-flee-the-country-then-the-kremlin-caught-him">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/commen

## Mussolini’s wartime bunker opens to the public in Rome
 - [https://www.reddit.com/r/worldnews/comments/1c5nqni/mussolinis_wartime_bunker_opens_to_the_public_in](https://www.reddit.com/r/worldnews/comments/1c5nqni/mussolinis_wartime_bunker_opens_to_the_public_in)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T18:40:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5nqni/mussolinis_wartime_bunker_opens_to_the_public_in/"> <img alt="Mussolini’s wartime bunker opens to the public in Rome" src="https://external-preview.redd.it/iXZRDkZMtJIe4Hlozn8uPwKStiCYot2Z_7AZmVEIirs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=550425f42c332894fc0a2df32589414c788557ae" title="Mussolini’s wartime bunker opens to the public in Rome" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Lunavenandi"> /u/Lunavenandi </a> <br /> <span><a href="https://www.cnn.com/travel/article/mussolini-bunker-rome">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5nqni/mussolinis_wartime_bunker_opens_to_the_public_in/">[comments]</a></span> </td></tr></table>

## Dubai Grinds to Standstill as Cloud Seeding Worsens Flooding
 - [https://www.reddit.com/r/worldnews/comments/1c5n7dv/dubai_grinds_to_standstill_as_cloud_seeding](https://www.reddit.com/r/worldnews/comments/1c5n7dv/dubai_grinds_to_standstill_as_cloud_seeding)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T18:18:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5n7dv/dubai_grinds_to_standstill_as_cloud_seeding/"> <img alt="Dubai Grinds to Standstill as Cloud Seeding Worsens Flooding" src="https://external-preview.redd.it/ztgyc-5u7oXn_DfbK_MkVyjF4UT9Kn-U9_CRWT14uyM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f13e02697acee9211928cc891116bf8628c4c6dc" title="Dubai Grinds to Standstill as Cloud Seeding Worsens Flooding" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/joe4942"> /u/joe4942 </a> <br /> <span><a href="https://www.bloomberg.com/news/articles/2024-04-16/dubai-grinds-to-standstill-as-cloud-seeding-worsens-flooding">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5n7dv/dubai_grinds_to_standstill_as_cloud_seeding/">[comments]</a></span> </td></tr></table>

## Italy passes measures to allow anti-abortion activists to enter abortion clinics
 - [https://www.reddit.com/r/worldnews/comments/1c5mqxo/italy_passes_measures_to_allow_antiabortion](https://www.reddit.com/r/worldnews/comments/1c5mqxo/italy_passes_measures_to_allow_antiabortion)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T18:00:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5mqxo/italy_passes_measures_to_allow_antiabortion/"> <img alt="Italy passes measures to allow anti-abortion activists to enter abortion clinics" src="https://external-preview.redd.it/kUxV2EahIKuSy9DJ1rcvS2_Pw2D8CJEpW_6EnJJFCxU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d8b62ec9810fa2890cd6b78f0d6fefc593224efe" title="Italy passes measures to allow anti-abortion activists to enter abortion clinics" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/3kOlen"> /u/3kOlen </a> <br /> <span><a href="https://www.theguardian.com/world/2024/apr/16/italy-passes-measures-to-allow-anti-abortion-activists-to-enter-abortion-clinics">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5mqxo/italy_passes_measures_to_allow_antiabortion/">[comments]</a></span> </td></tr></table>

## Vladimir Putin not welcome at French ceremony for 80th anniversary of D-day
 - [https://www.reddit.com/r/worldnews/comments/1c5lhzn/vladimir_putin_not_welcome_at_french_ceremony_for](https://www.reddit.com/r/worldnews/comments/1c5lhzn/vladimir_putin_not_welcome_at_french_ceremony_for)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T17:11:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5lhzn/vladimir_putin_not_welcome_at_french_ceremony_for/"> <img alt="Vladimir Putin not welcome at French ceremony for 80th anniversary of D-day" src="https://external-preview.redd.it/iaCoNGcrIVza2SNaESxGraTnyEHnXm_6R6vh9dDawQk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=71ceca6e2247717c2e733ae51d87349feadcd5cb" title="Vladimir Putin not welcome at French ceremony for 80th anniversary of D-day" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/4920185"> /u/4920185 </a> <br /> <span><a href="https://www.theguardian.com/world/2024/apr/16/vladimir-putin-not-welcome-at-ceremony-for-80th-anniversary-of-d-day">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5lhzn/vladimir_putin_not_welcome_at_french_ceremony_for/">[comments]</a></span> </td></tr></table>

## US to help Armenia modernize its military
 - [https://www.reddit.com/r/worldnews/comments/1c5l9of/us_to_help_armenia_modernize_its_military](https://www.reddit.com/r/worldnews/comments/1c5l9of/us_to_help_armenia_modernize_its_military)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T17:01:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5l9of/us_to_help_armenia_modernize_its_military/"> <img alt="US to help Armenia modernize its military" src="https://external-preview.redd.it/lzHW3WwJS7dUKKElwVFZpM7JmypqKEkIi9bsVNcgKtY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=86b1240c75203ecc462e5f3576d909b5121bb84b" title="US to help Armenia modernize its military" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DavidofSasun"> /u/DavidofSasun </a> <br /> <span><a href="https://eurasianet.org/us-to-help-armenia-modernize-its-military">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5l9of/us_to_help_armenia_modernize_its_military/">[comments]</a></span> </td></tr></table>

## ‘Humanitarian aid in Sudan is constantly being blocked by all the belligerents’
 - [https://www.reddit.com/r/worldnews/comments/1c5l21s/humanitarian_aid_in_sudan_is_constantly_being](https://www.reddit.com/r/worldnews/comments/1c5l21s/humanitarian_aid_in_sudan_is_constantly_being)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T16:53:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5l21s/humanitarian_aid_in_sudan_is_constantly_being/"> <img alt="‘Humanitarian aid in Sudan is constantly being blocked by all the belligerents’" src="https://external-preview.redd.it/kgxhhvDhff1FDeRkPm1RuWgVQNhO4fcm3bih5NAAR4s.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4ba0e625561f16abdcd9e7a3ab0f3a7eef556cfd" title="‘Humanitarian aid in Sudan is constantly being blocked by all the belligerents’" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DoremusJessup"> /u/DoremusJessup </a> <br /> <span><a href="https://www.france24.com/en/africa/20240416-humanitarian-aid-sudan-constantly-blocked-by-belligerents-humanitarian-conference">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5l21s/humanitarian_aid_in_sudan_is_constantly_being/">[comments]</a></span> </td></tr></table>

## World faces ‘deathly silence’ of nature as wildlife disappears. Loss of intensity and diversity of noises in ecosystems reflects an alarming decline in healthy biodiversity, say sound ecologists.
 - [https://www.reddit.com/r/worldnews/comments/1c5kqu4/world_faces_deathly_silence_of_nature_as_wildlife](https://www.reddit.com/r/worldnews/comments/1c5kqu4/world_faces_deathly_silence_of_nature_as_wildlife)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T16:41:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5kqu4/world_faces_deathly_silence_of_nature_as_wildlife/"> <img alt="World faces ‘deathly silence’ of nature as wildlife disappears. Loss of intensity and diversity of noises in ecosystems reflects an alarming decline in healthy biodiversity, say sound ecologists." src="https://external-preview.redd.it/JXLCgJFKRmPJz7_55Z2n6z6Zo07XuQ6kD0yB8K4mO9s.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8f4e2596cc3605533c94233762d7d486a36b6148" title="World faces ‘deathly silence’ of nature as wildlife disappears. Loss of intensity and diversity of noises in ecosystems reflects an alarming decline in healthy biodiversity, say sound ecologists." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/lamdefinitelynotadog"> /u/lamdefinitelynotadog </a> <br /> <span><a href="https://www.theguardian.com/environment/2024/apr/16/world-faces-deathly-silence-of-nature-as-wildlife-disappears-warn-experts-aoe"

## U.S. deploys midrange missile system in Indo-Pacific for first time
 - [https://www.reddit.com/r/worldnews/comments/1c5km9d/us_deploys_midrange_missile_system_in_indopacific](https://www.reddit.com/r/worldnews/comments/1c5km9d/us_deploys_midrange_missile_system_in_indopacific)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T16:35:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5km9d/us_deploys_midrange_missile_system_in_indopacific/"> <img alt="U.S. deploys midrange missile system in Indo-Pacific for first time" src="https://external-preview.redd.it/ZPadb_JKz6fvr4LxrS_S4PKOUkCogvdw09290Hzyk7w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c9b4f37cb3300b6294178ed1d44949556651656e" title="U.S. deploys midrange missile system in Indo-Pacific for first time" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/lurker_bee"> /u/lurker_bee </a> <br /> <span><a href="https://www.japantimes.co.jp/news/2024/04/16/asia-pacific/politics/us-midrange-missiles-philippines-china/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5km9d/us_deploys_midrange_missile_system_in_indopacific/">[comments]</a></span> </td></tr></table>

## Poll: 74% of Israelis oppose counterstrike on Iran if it harms security alliances
 - [https://www.reddit.com/r/worldnews/comments/1c5kc2c/poll_74_of_israelis_oppose_counterstrike_on_iran](https://www.reddit.com/r/worldnews/comments/1c5kc2c/poll_74_of_israelis_oppose_counterstrike_on_iran)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T16:24:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5kc2c/poll_74_of_israelis_oppose_counterstrike_on_iran/"> <img alt="Poll: 74% of Israelis oppose counterstrike on Iran if it harms security alliances" src="https://external-preview.redd.it/Zcz9oLjuLusFVBHDvdxkDby-BeIIO18OyKrqN40s5t0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bdaa49298c432ce1d084349d1bc9fa491d4816d8" title="Poll: 74% of Israelis oppose counterstrike on Iran if it harms security alliances" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SyntheticSweetener"> /u/SyntheticSweetener </a> <br /> <span><a href="https://www.timesofisrael.com/poll-74-of-israelis-oppose-counterstrike-on-iran-if-it-harms-security-alliances/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5kc2c/poll_74_of_israelis_oppose_counterstrike_on_iran/">[comments]</a></span> </td></tr></table>

## Russia: the mass media control agency will evaluate the blocking of TikTok by May 8, now users can only see videos from two years ago
 - [https://www.reddit.com/r/worldnews/comments/1c5k69h/russia_the_mass_media_control_agency_will](https://www.reddit.com/r/worldnews/comments/1c5k69h/russia_the_mass_media_control_agency_will)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T16:17:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5k69h/russia_the_mass_media_control_agency_will/"> <img alt="Russia: the mass media control agency will evaluate the blocking of TikTok by May 8, now users can only see videos from two years ago" src="https://external-preview.redd.it/6dn-Y3u8bJ9faxZ8eQYUSLit3WsZ8QHtp-JCdx8QJnk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=403fb0b461eac44ff3f798d9d7336122c6b224d6" title="Russia: the mass media control agency will evaluate the blocking of TikTok by May 8, now users can only see videos from two years ago" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/giuliomagnifico"> /u/giuliomagnifico </a> <br /> <span><a href="https://www.agenzianova.com/en/news/Russia%27s-mass-media-control-agency-will-evaluate-the-blocking-of-TikTok-by-May-8/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5k69h/russia_the_mass_media_control_agency_will/">[comments]</a></

## Dubai flooding amid atypical heavy rains snarls traffic on UAE roads and airport runways
 - [https://www.reddit.com/r/worldnews/comments/1c5k2o8/dubai_flooding_amid_atypical_heavy_rains_snarls](https://www.reddit.com/r/worldnews/comments/1c5k2o8/dubai_flooding_amid_atypical_heavy_rains_snarls)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T16:13:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5k2o8/dubai_flooding_amid_atypical_heavy_rains_snarls/"> <img alt="Dubai flooding amid atypical heavy rains snarls traffic on UAE roads and airport runways" src="https://external-preview.redd.it/UTmv5OiE5dQKUi3YGH3Jc4VvuZcpAMbvuCWE0d6LIKo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=af541a23e059839eed942b342346c941026fd20d" title="Dubai flooding amid atypical heavy rains snarls traffic on UAE roads and airport runways" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ObjectiveAd6551"> /u/ObjectiveAd6551 </a> <br /> <span><a href="https://www.cbsnews.com/news/dubai-flooding-today-heavy-rain-snarls-traffic-uae-roads-and-airport/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5k2o8/dubai_flooding_amid_atypical_heavy_rains_snarls/">[comments]</a></span> </td></tr></table>

## Russian victory in Chasiv Yar would jeopardize ‘last stronghold’ of Donetsk region, Ukrainians say
 - [https://www.reddit.com/r/worldnews/comments/1c5k2d8/russian_victory_in_chasiv_yar_would_jeopardize](https://www.reddit.com/r/worldnews/comments/1c5k2d8/russian_victory_in_chasiv_yar_would_jeopardize)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T16:13:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5k2d8/russian_victory_in_chasiv_yar_would_jeopardize/"> <img alt="Russian victory in Chasiv Yar would jeopardize ‘last stronghold’ of Donetsk region, Ukrainians say" src="https://external-preview.redd.it/Q0fhK7sg-tTtYq0zKBo_rR7vDfHk2tTpIVTOQyaxDcc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c5e6603a3b5c399a1f9a2ce56049695ac0f360c6" title="Russian victory in Chasiv Yar would jeopardize ‘last stronghold’ of Donetsk region, Ukrainians say" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/alexino_rl"> /u/alexino_rl </a> <br /> <span><a href="https://www.politico.eu/article/russian-victory-over-ukranian-key-city-chasiv-yar-jeopardize-entire-donetsk-region/?utm_source=RSS_Feed&amp;utm_medium=RSS&amp;utm_campaign=RSS_Syndication">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5k2d8/russian_victory_in_chasiv_yar_would_jeopardize/">[comments]</a></sp

## Yellen says Iran's actions could cause global 'economic spillovers' and warns of more sanctions
 - [https://www.reddit.com/r/worldnews/comments/1c5k287/yellen_says_irans_actions_could_cause_global](https://www.reddit.com/r/worldnews/comments/1c5k287/yellen_says_irans_actions_could_cause_global)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T16:13:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5k287/yellen_says_irans_actions_could_cause_global/"> <img alt="Yellen says Iran's actions could cause global 'economic spillovers' and warns of more sanctions" src="https://external-preview.redd.it/aJa80fCvoOVodGWpU_nXpOT8ELRRmONGRntqbxJJBas.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=286db1af6a0d0a78f7707f3e280c2e8083212ff5" title="Yellen says Iran's actions could cause global 'economic spillovers' and warns of more sanctions" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/National-Novel-2525"> /u/National-Novel-2525 </a> <br /> <span><a href="https://apnews.com/article/imf-world-bank-yellen-sanctions-iran-ukraine-china-7643ff47d58f2a1d6314dae0f0a455bd">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5k287/yellen_says_irans_actions_could_cause_global/">[comments]</a></span> </td></tr></table>

## Israel kills senior Hezbollah field commander after attack drones penetrate border from Lebanon
 - [https://www.reddit.com/r/worldnews/comments/1c5j97e/israel_kills_senior_hezbollah_field_commander](https://www.reddit.com/r/worldnews/comments/1c5j97e/israel_kills_senior_hezbollah_field_commander)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T15:41:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5j97e/israel_kills_senior_hezbollah_field_commander/"> <img alt="Israel kills senior Hezbollah field commander after attack drones penetrate border from Lebanon" src="https://external-preview.redd.it/GM8gh4MFuJpGtEPiHADkDv7GB7rts6z-V2s22-8ZH08.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=6afb0737b14f2453e8649ed90d197070685c3b59" title="Israel kills senior Hezbollah field commander after attack drones penetrate border from Lebanon" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/giuliomagnifico"> /u/giuliomagnifico </a> <br /> <span><a href="https://www.ynetnews.com/article/rkszb113ga#autoplay">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5j97e/israel_kills_senior_hezbollah_field_commander/">[comments]</a></span> </td></tr></table>

## Indian security forces kill at least 29 Maoists in gunbattle
 - [https://www.reddit.com/r/worldnews/comments/1c5igbw/indian_security_forces_kill_at_least_29_maoists](https://www.reddit.com/r/worldnews/comments/1c5igbw/indian_security_forces_kill_at_least_29_maoists)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T15:08:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5igbw/indian_security_forces_kill_at_least_29_maoists/"> <img alt="Indian security forces kill at least 29 Maoists in gunbattle" src="https://external-preview.redd.it/mKqHVAGaLWiUITRbgNRDoP35M9U5u0blA-Wx_P_WJ-c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=28283100db87356cfdaee78c5280027752fa681d" title="Indian security forces kill at least 29 Maoists in gunbattle" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Cloud_Drago"> /u/Cloud_Drago </a> <br /> <span><a href="https://www.reuters.com/world/india/least-18-maoists-killed-gunbattle-with-indian-security-forces-local-media-says-2024-04-16/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5igbw/indian_security_forces_kill_at_least_29_maoists/">[comments]</a></span> </td></tr></table>

## Iranians brace for potential Israeli strikes amid fears for economy, anger at regime
 - [https://www.reddit.com/r/worldnews/comments/1c5gx84/iranians_brace_for_potential_israeli_strikes_amid](https://www.reddit.com/r/worldnews/comments/1c5gx84/iranians_brace_for_potential_israeli_strikes_amid)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T14:04:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5gx84/iranians_brace_for_potential_israeli_strikes_amid/"> <img alt="Iranians brace for potential Israeli strikes amid fears for economy, anger at regime" src="https://external-preview.redd.it/hQ1Kzq3oPZpmO-0mFtKxOFIiS4d8d9PwLTP5jA5ZBrA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ed17b5eb9fefd3a03c9348accb707e6e94df8976" title="Iranians brace for potential Israeli strikes amid fears for economy, anger at regime" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yuri_2022"> /u/yuri_2022 </a> <br /> <span><a href="https://www.timesofisrael.com/iranians-brace-for-potential-israeli-strikes-amid-fears-for-economy-anger-at-regime/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5gx84/iranians_brace_for_potential_israeli_strikes_amid/">[comments]</a></span> </td></tr></table>

## Putin Urges Iran’s Raisi to Avoid ‘Catastrophic’ Conflict
 - [https://www.reddit.com/r/worldnews/comments/1c5gs39/putin_urges_irans_raisi_to_avoid_catastrophic](https://www.reddit.com/r/worldnews/comments/1c5gs39/putin_urges_irans_raisi_to_avoid_catastrophic)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T13:58:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5gs39/putin_urges_irans_raisi_to_avoid_catastrophic/"> <img alt="Putin Urges Iran’s Raisi to Avoid ‘Catastrophic’ Conflict" src="https://external-preview.redd.it/gSP2RzY6iZKUjBBo5cNSN05cRy0d3z8l9Na7mkCcEwY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6f6dd54c1f4c35a3c80a781a1084599f37300c5b" title="Putin Urges Iran’s Raisi to Avoid ‘Catastrophic’ Conflict" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bloomberg"> /u/bloomberg </a> <br /> <span><a href="https://www.bloomberg.com/news/articles/2024-04-16/putin-urges-iran-s-raisi-to-avoid-catastrophic-conflict">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5gs39/putin_urges_irans_raisi_to_avoid_catastrophic/">[comments]</a></span> </td></tr></table>

## The House plans to hold separate votes on aid for Israel and Ukraine after delays
 - [https://www.reddit.com/r/worldnews/comments/1c5fx06/the_house_plans_to_hold_separate_votes_on_aid_for](https://www.reddit.com/r/worldnews/comments/1c5fx06/the_house_plans_to_hold_separate_votes_on_aid_for)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T13:19:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5fx06/the_house_plans_to_hold_separate_votes_on_aid_for/"> <img alt="The House plans to hold separate votes on aid for Israel and Ukraine after delays" src="https://external-preview.redd.it/GusmyGyAFYU4Vuu5iZjt2C1soBQ_GeknfZGfnJ4rCKg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=96385ef9c31f782d99fceccf6dc3a616c45c1454" title="The House plans to hold separate votes on aid for Israel and Ukraine after delays" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Youngstown_Mafia"> /u/Youngstown_Mafia </a> <br /> <span><a href="https://www.npr.org/2024/04/15/1244948784/house-israel-ukraine-aid-funding-bill">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5fx06/the_house_plans_to_hold_separate_votes_on_aid_for/">[comments]</a></span> </td></tr></table>

## Ukraine downs 9 drones from Russian attacks
 - [https://www.reddit.com/r/worldnews/comments/1c5fjqd/ukraine_downs_9_drones_from_russian_attacks](https://www.reddit.com/r/worldnews/comments/1c5fjqd/ukraine_downs_9_drones_from_russian_attacks)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T13:02:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5fjqd/ukraine_downs_9_drones_from_russian_attacks/"> <img alt="Ukraine downs 9 drones from Russian attacks" src="https://external-preview.redd.it/kJIJBhBt8tIeK49pUZZSJ_GGEaxYA9pHUrhKx3_Uu2s.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=796909241918d803ef3c52c950ee245aeda6549b" title="Ukraine downs 9 drones from Russian attacks" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/znanirani"> /u/znanirani </a> <br /> <span><a href="https://www.voanews.com/a/ukraine-downs-9-drones-from-russian-attacks/7571708.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5fjqd/ukraine_downs_9_drones_from_russian_attacks/">[comments]</a></span> </td></tr></table>

## Global heating pushes coral reefs towards worst planet-wide mass bleaching on record
 - [https://www.reddit.com/r/worldnews/comments/1c5faxb/global_heating_pushes_coral_reefs_towards_worst](https://www.reddit.com/r/worldnews/comments/1c5faxb/global_heating_pushes_coral_reefs_towards_worst)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T12:50:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5faxb/global_heating_pushes_coral_reefs_towards_worst/"> <img alt="Global heating pushes coral reefs towards worst planet-wide mass bleaching on record" src="https://external-preview.redd.it/S3lPBWi_leSwLrFD0ba9CVlJbDhyxSDwV1hFHEVaIK4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9fcdf62b13d0fc6fe74cbf2b32c3ab566819e1ef" title="Global heating pushes coral reefs towards worst planet-wide mass bleaching on record" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IntrepidGentian"> /u/IntrepidGentian </a> <br /> <span><a href="https://www.theguardian.com/environment/2024/apr/15/great-barrier-reef-coral-bleaching-global-heating">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5faxb/global_heating_pushes_coral_reefs_towards_worst/">[comments]</a></span> </td></tr></table>

## The Latest | Israel must stop settler attacks on Palestinians, UN human rights office says
 - [https://www.reddit.com/r/worldnews/comments/1c5evvm/the_latest_israel_must_stop_settler_attacks_on](https://www.reddit.com/r/worldnews/comments/1c5evvm/the_latest_israel_must_stop_settler_attacks_on)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T12:29:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5evvm/the_latest_israel_must_stop_settler_attacks_on/"> <img alt="The Latest | Israel must stop settler attacks on Palestinians, UN human rights office says" src="https://external-preview.redd.it/rztrmz5vbkiZvTg_jQ9OjmJBU9kPfjrWVkOREFniKNg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c77900a130ca05e15a647c42387b02c608a45885" title="The Latest | Israel must stop settler attacks on Palestinians, UN human rights office says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/National-Novel-2525"> /u/National-Novel-2525 </a> <br /> <span><a href="https://apnews.com/article/israel-iran-hamas-latest-04-16-2024-2d556f46e9dd08b68930f86777524b21">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5evvm/the_latest_israel_must_stop_settler_attacks_on/">[comments]</a></span> </td></tr></table>

## Brussels police tries to shut down Orbán, Farage's far-right gathering
 - [https://www.reddit.com/r/worldnews/comments/1c5etly/brussels_police_tries_to_shut_down_orbán_farages](https://www.reddit.com/r/worldnews/comments/1c5etly/brussels_police_tries_to_shut_down_orbán_farages)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T12:26:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5etly/brussels_police_tries_to_shut_down_orbán_farages/"> <img alt="Brussels police tries to shut down Orbán, Farage's far-right gathering" src="https://external-preview.redd.it/j45iehh0J2JkKaiYpT_nD1G10RgLgBkZ8ZScGNgDdig.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=af320c9292d9e481f78db51628195833ee48fefd" title="Brussels police tries to shut down Orbán, Farage's far-right gathering" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/OddAioli6993"> /u/OddAioli6993 </a> <br /> <span><a href="https://www.euronews.com/my-europe/2024/04/16/brussels-police-shuts-down-orban-and-farages-far-right-gathering">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5etly/brussels_police_tries_to_shut_down_orbán_farages/">[comments]</a></span> </td></tr></table>

## France’s battle plan to produce one million heat pumps a year
 - [https://www.reddit.com/r/worldnews/comments/1c5eeql/frances_battle_plan_to_produce_one_million_heat](https://www.reddit.com/r/worldnews/comments/1c5eeql/frances_battle_plan_to_produce_one_million_heat)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T12:04:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5eeql/frances_battle_plan_to_produce_one_million_heat/"> <img alt="France’s battle plan to produce one million heat pumps a year" src="https://external-preview.redd.it/pAFvDb_uJBxTcJJHAE1YpxufE3iyqalzEJ8GLb2Kv9E.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f11454ccad76e87ff43f34c7e0318f28350f4227" title="France’s battle plan to produce one million heat pumps a year" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BubsyFanboy"> /u/BubsyFanboy </a> <br /> <span><a href="https://www.euractiv.com/section/all/news/frances-battle-plan-to-produce-one-million-heat-pumps-a-year/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5eeql/frances_battle_plan_to_produce_one_million_heat/">[comments]</a></span> </td></tr></table>

## About 50 of the Nova festival survivors committed suicide - I24NEWS
 - [https://www.reddit.com/r/worldnews/comments/1c5e5ym/about_50_of_the_nova_festival_survivors_committed](https://www.reddit.com/r/worldnews/comments/1c5e5ym/about_50_of_the_nova_festival_survivors_committed)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T11:52:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5e5ym/about_50_of_the_nova_festival_survivors_committed/"> <img alt="About 50 of the Nova festival survivors committed suicide - I24NEWS" src="https://external-preview.redd.it/zXyuSDsS4eU03dFznxYUb5QZyTWdH27GC2CYHSNzmcM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ed83fe388fd30c04f0f7eeac0aed8c504f7c9c60" title="About 50 of the Nova festival survivors committed suicide - I24NEWS" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/msSecretg"> /u/msSecretg </a> <br /> <span><a href="https://www.i24news.tv/en/news/israel-at-war/survivor-testimonies/artc-oct-7-festival-massacre-survivor-reveals-about-50-survivors-later-committed-suicide">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5e5ym/about_50_of_the_nova_festival_survivors_committed/">[comments]</a></span> </td></tr></table>

## Philippines' Marcos says 'not one person died' as police make huge drug bust, in dig at predecessor
 - [https://www.reddit.com/r/worldnews/comments/1c5du3f/philippines_marcos_says_not_one_person_died_as](https://www.reddit.com/r/worldnews/comments/1c5du3f/philippines_marcos_says_not_one_person_died_as)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T11:34:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5du3f/philippines_marcos_says_not_one_person_died_as/"> <img alt="Philippines' Marcos says 'not one person died' as police make huge drug bust, in dig at predecessor" src="https://external-preview.redd.it/BCbR3JKknyeGh-yzuPlC9jYY6pbllHV6T_hLmvY1nY4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9124b193844ce818effe5409be5373475110c966" title="Philippines' Marcos says 'not one person died' as police make huge drug bust, in dig at predecessor" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Astronaut520"> /u/Astronaut520 </a> <br /> <span><a href="https://apnews.com/article/philippines-president-marcos-duterte-illegal-drugs-crackdown-6d5461d5a5d71bbcb769382f6655fc8b">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5du3f/philippines_marcos_says_not_one_person_died_as/">[comments]</a></span> </td></tr></table>

## Record-high ocean temperatures have put more than 54% of the planet’s reef areas under stress, starving them and turning them white, in the past year.
 - [https://www.reddit.com/r/worldnews/comments/1c5dpnd/recordhigh_ocean_temperatures_have_put_more_than](https://www.reddit.com/r/worldnews/comments/1c5dpnd/recordhigh_ocean_temperatures_have_put_more_than)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T11:27:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5dpnd/recordhigh_ocean_temperatures_have_put_more_than/"> <img alt="Record-high ocean temperatures have put more than 54% of the planet’s reef areas under stress, starving them and turning them white, in the past year." src="https://external-preview.redd.it/Aii-0TANzvSGl8umvxCDFU7WWw4oHeq8hAQ3Mv4wqZg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=644dca16d787bac22913cd5f986aba08b8af7f74" title="Record-high ocean temperatures have put more than 54% of the planet’s reef areas under stress, starving them and turning them white, in the past year." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Party-Appointment-99"> /u/Party-Appointment-99 </a> <br /> <span><a href="https://www.washingtonpost.com/climate-environment/2024/04/15/global-coral-bleaching-ocean-temperatures/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5dpnd/recordhigh_ocean_tempera

## Michaela School: Muslim student loses prayer ban challenge
 - [https://www.reddit.com/r/worldnews/comments/1c5djmx/michaela_school_muslim_student_loses_prayer_ban](https://www.reddit.com/r/worldnews/comments/1c5djmx/michaela_school_muslim_student_loses_prayer_ban)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T11:18:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5djmx/michaela_school_muslim_student_loses_prayer_ban/"> <img alt="Michaela School: Muslim student loses prayer ban challenge" src="https://external-preview.redd.it/ALzuS_H4MkINZ2xquJ4JMDwTAnTFDk3II0LeRmq4_5M.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f9fad97fb88ba14776c9e38d1f39f436942e2cdd" title="Michaela School: Muslim student loses prayer ban challenge" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/libtin"> /u/libtin </a> <br /> <span><a href="https://www.bbc.co.uk/news/uk-england-london-68731366">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5djmx/michaela_school_muslim_student_loses_prayer_ban/">[comments]</a></span> </td></tr></table>

## Iran says any action against its interests will get a severe response
 - [https://www.reddit.com/r/worldnews/comments/1c5d8lg/iran_says_any_action_against_its_interests_will](https://www.reddit.com/r/worldnews/comments/1c5d8lg/iran_says_any_action_against_its_interests_will)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T11:01:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5d8lg/iran_says_any_action_against_its_interests_will/"> <img alt="Iran says any action against its interests will get a severe response" src="https://external-preview.redd.it/SRkEKflxS1BhZ1-MBIVS3KoFplpuJyY9P0dS32k_ads.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d3273535d967fd5c0654b5ef853093d389a979b1" title="Iran says any action against its interests will get a severe response" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/cosmocolada"> /u/cosmocolada </a> <br /> <span><a href="https://www.reuters.com/world/middle-east/iran-says-any-action-against-its-interests-will-get-severe-response-2024-04-16/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5d8lg/iran_says_any_action_against_its_interests_will/">[comments]</a></span> </td></tr></table>

## Iran did not provide US with attack warning or targets, White House says
 - [https://www.reddit.com/r/worldnews/comments/1c5cxz0/iran_did_not_provide_us_with_attack_warning_or](https://www.reddit.com/r/worldnews/comments/1c5cxz0/iran_did_not_provide_us_with_attack_warning_or)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T10:42:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5cxz0/iran_did_not_provide_us_with_attack_warning_or/"> <img alt="Iran did not provide US with attack warning or targets, White House says" src="https://external-preview.redd.it/ebIH4kkiPutkyjiLaucm6D51H5G03RvyGGNpYQWbgcc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a682e2f7de4ac6d0e8055c01806eb2efc6f50426" title="Iran did not provide US with attack warning or targets, White House says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/swahilitutgirl"> /u/swahilitutgirl </a> <br /> <span><a href="https://www.reuters.com/world/iran-did-not-provide-us-with-attack-warning-or-targets-white-house-says-2024-04-15/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5cxz0/iran_did_not_provide_us_with_attack_warning_or/">[comments]</a></span> </td></tr></table>

## Russia takes advantage of Ukraine’s depleted arsenal and the weather to advance in Donetsk
 - [https://www.reddit.com/r/worldnews/comments/1c5cjzj/russia_takes_advantage_of_ukraines_depleted](https://www.reddit.com/r/worldnews/comments/1c5cjzj/russia_takes_advantage_of_ukraines_depleted)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T10:17:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5cjzj/russia_takes_advantage_of_ukraines_depleted/"> <img alt="Russia takes advantage of Ukraine’s depleted arsenal and the weather to advance in Donetsk" src="https://external-preview.redd.it/umnMG957-alXtBN9dnwzbiw5YtCBL-Ywb9WS3SJstw4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b7356c12d23dffd2245a54103e5234e96a325217" title="Russia takes advantage of Ukraine’s depleted arsenal and the weather to advance in Donetsk" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Logibenq"> /u/Logibenq </a> <br /> <span><a href="https://english.elpais.com/international/2024-04-16/russia-takes-advantage-of-ukraines-depleted-arsenal-and-the-weather-to-advance-in-donetsk.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5cjzj/russia_takes_advantage_of_ukraines_depleted/">[comments]</a></span> </td></tr></table>

## /r/WorldNews Live Thread: Russian Invasion of Ukraine Day 783, Part 1 (Thread #929)
 - [https://www.reddit.com/r/worldnews/comments/1c5br5j/rworldnews_live_thread_russian_invasion_of](https://www.reddit.com/r/worldnews/comments/1c5br5j/rworldnews_live_thread_russian_invasion_of)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T09:21:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5br5j/rworldnews_live_thread_russian_invasion_of/"> <img alt="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 783, Part 1 (Thread #929)" src="https://a.thumbs.redditmedia.com/jWqSTFxxKuo9aDK8JeM4yZL4Nb_RTA85H45u1-h63L8.jpg" title="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 783, Part 1 (Thread #929)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WorldNewsMods"> /u/WorldNewsMods </a> <br /> <span><a href="https://www.reddit.com/live/18hnzysb1elcs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5br5j/rworldnews_live_thread_russian_invasion_of/">[comments]</a></span> </td></tr></table>

## Russia plans 'false flag' attacks on Zaporizhzhia nuclear plant, Kyiv tells UN.While IAEA announced that 6 of the plant's reactors had been moved into a state of cold shutdown, IAEA chief warned that the potential for a disaster is still high"We are getting dangerously close to a nuclear accident"
 - [https://www.reddit.com/r/worldnews/comments/1c5bmxr/russia_plans_false_flag_attacks_on_zaporizhzhia](https://www.reddit.com/r/worldnews/comments/1c5bmxr/russia_plans_false_flag_attacks_on_zaporizhzhia)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T09:13:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5bmxr/russia_plans_false_flag_attacks_on_zaporizhzhia/"> <img alt="Russia plans 'false flag' attacks on Zaporizhzhia nuclear plant, Kyiv tells UN.While IAEA announced that 6 of the plant's reactors had been moved into a state of cold shutdown, IAEA chief warned that the potential for a disaster is still high&quot;We are getting dangerously close to a nuclear accident&quot;" src="https://external-preview.redd.it/77HMNIdZkagnV7wdKT60mRcEFhmJ5yZ0lcVyB5X4gVY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0a6a02b24bb2cde8c62bf925d5cdbe37c5869618" title="Russia plans 'false flag' attacks on Zaporizhzhia nuclear plant, Kyiv tells UN.While IAEA announced that 6 of the plant's reactors had been moved into a state of cold shutdown, IAEA chief warned that the potential for a disaster is still high&quot;We are getting dangerously close to a nuclear accident&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://

## Hundreds of Israeli settlers mobilize across Palestinian villages in the West Bank after missing Israeli boy found dead | CNN
 - [https://www.reddit.com/r/worldnews/comments/1c5betd/hundreds_of_israeli_settlers_mobilize_across](https://www.reddit.com/r/worldnews/comments/1c5betd/hundreds_of_israeli_settlers_mobilize_across)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T08:58:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5betd/hundreds_of_israeli_settlers_mobilize_across/"> <img alt="Hundreds of Israeli settlers mobilize across Palestinian villages in the West Bank after missing Israeli boy found dead | CNN" src="https://external-preview.redd.it/Pb5dG0jfIgAioiXK11xXNkXw-9EO-p67go5iE1oMoYc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=57fc3289373146fae29a6e3bac3c68e2b3690713" title="Hundreds of Israeli settlers mobilize across Palestinian villages in the West Bank after missing Israeli boy found dead | CNN" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rotchend"> /u/Rotchend </a> <br /> <span><a href="https://edition.cnn.com/2024/04/13/world/israeli-settlers-mobilize-across-west-bank-intl/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5betd/hundreds_of_israeli_settlers_mobilize_across/">[comments]</a></span> </td></tr></table>

## Argentina reinforces ties with the US with purchase of used F-16s
 - [https://www.reddit.com/r/worldnews/comments/1c5balu/argentina_reinforces_ties_with_the_us_with](https://www.reddit.com/r/worldnews/comments/1c5balu/argentina_reinforces_ties_with_the_us_with)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T08:50:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5balu/argentina_reinforces_ties_with_the_us_with/"> <img alt="Argentina reinforces ties with the US with purchase of used F-16s" src="https://external-preview.redd.it/5O1xVzv7WujU4seJKk-RR4NjC-Nu5nfVOpcNR4aTbB4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9bdce2d28aedc1a4f12d734c681a895e4debdcf3" title="Argentina reinforces ties with the US with purchase of used F-16s" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Logibenq"> /u/Logibenq </a> <br /> <span><a href="https://english.elpais.com/international/2024-04-16/argentina-reinforces-ties-with-the-us-with-purchase-of-used-f-16s.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5balu/argentina_reinforces_ties_with_the_us_with/">[comments]</a></span> </td></tr></table>

## Teaching coexistence, not hate: U.S. organization designs alternative to UNRWA schools - I24NEWS
 - [https://www.reddit.com/r/worldnews/comments/1c5arzf/teaching_coexistence_not_hate_us_organization](https://www.reddit.com/r/worldnews/comments/1c5arzf/teaching_coexistence_not_hate_us_organization)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T08:13:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5arzf/teaching_coexistence_not_hate_us_organization/"> <img alt="Teaching coexistence, not hate: U.S. organization designs alternative to UNRWA schools - I24NEWS" src="https://external-preview.redd.it/NXOePrV56WfoclIReTEPeCvz5ghhw_o1lxL-o-ZTmx8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0ef0251e67271726c53a4c2a39926b8040e537c7" title="Teaching coexistence, not hate: U.S. organization designs alternative to UNRWA schools - I24NEWS" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/legitrabbi"> /u/legitrabbi </a> <br /> <span><a href="https://www.i24news.tv/en/news/palestinian-territories/artc-teaching-coexistence-not-hate-u-s-organization-designs-alternative-to-unrwa-schools">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5arzf/teaching_coexistence_not_hate_us_organization/">[comments]</a></span> </td></tr></table>

## Ukrainian defenders down all Russian attack drones overnight
 - [https://www.reddit.com/r/worldnews/comments/1c5ajo9/ukrainian_defenders_down_all_russian_attack](https://www.reddit.com/r/worldnews/comments/1c5ajo9/ukrainian_defenders_down_all_russian_attack)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T07:57:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5ajo9/ukrainian_defenders_down_all_russian_attack/"> <img alt="Ukrainian defenders down all Russian attack drones overnight" src="https://external-preview.redd.it/FWeahpaunYMIUuk57R9NRF59rxm6X13VJ6hK5xcfFTU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=59d07c1807a4e784c70f3abd8c77ec3d852ed3eb" title="Ukrainian defenders down all Russian attack drones overnight" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/eaglemaxie"> /u/eaglemaxie </a> <br /> <span><a href="https://www.pravda.com.ua/eng/news/2024/04/16/7451404/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5ajo9/ukrainian_defenders_down_all_russian_attack/">[comments]</a></span> </td></tr></table>

## Far Right’s Ties to Russia Sow Rising Alarm in Germany
 - [https://www.reddit.com/r/worldnews/comments/1c5agop/far_rights_ties_to_russia_sow_rising_alarm_in](https://www.reddit.com/r/worldnews/comments/1c5agop/far_rights_ties_to_russia_sow_rising_alarm_in)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T07:51:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5agop/far_rights_ties_to_russia_sow_rising_alarm_in/"> <img alt="Far Right’s Ties to Russia Sow Rising Alarm in Germany" src="https://external-preview.redd.it/FWUy2gcN7uHdT2qEhE9p4uw2s4UzQgwgv9URcZ9R5h0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d91999c2af7c48947c2eded1c9e8aa8a7d35e1f6" title="Far Right’s Ties to Russia Sow Rising Alarm in Germany" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AlertTangerine"> /u/AlertTangerine </a> <br /> <span><a href="https://www.nytimes.com/2024/04/15/world/europe/germany-afd-russia.html?unlocked_article_code=1.kk0.AB--.nHxIXtzgzzHz">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5agop/far_rights_ties_to_russia_sow_rising_alarm_in/">[comments]</a></span> </td></tr></table>

## Copenhagen's historic stock exchange in flames
 - [https://www.reddit.com/r/worldnews/comments/1c5a0f9/copenhagens_historic_stock_exchange_in_flames](https://www.reddit.com/r/worldnews/comments/1c5a0f9/copenhagens_historic_stock_exchange_in_flames)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T07:20:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c5a0f9/copenhagens_historic_stock_exchange_in_flames/"> <img alt="Copenhagen's historic stock exchange in flames" src="https://external-preview.redd.it/D00qNz-d57noDDl79gShoxfZnaiBQO_E96XqGcb7E-w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9dd85c44874645bf72db5d2737d41a93aff06ceb" title="Copenhagen's historic stock exchange in flames" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/wordmuff"> /u/wordmuff </a> <br /> <span><a href="https://www.bbc.co.uk/news/world-europe-68824189">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c5a0f9/copenhagens_historic_stock_exchange_in_flames/">[comments]</a></span> </td></tr></table>

## US accuses Hamas of being 'obstacle' to Gaza truce after it rejected Israel's proposal
 - [https://www.reddit.com/r/worldnews/comments/1c57f1b/us_accuses_hamas_of_being_obstacle_to_gaza_truce](https://www.reddit.com/r/worldnews/comments/1c57f1b/us_accuses_hamas_of_being_obstacle_to_gaza_truce)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T04:37:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c57f1b/us_accuses_hamas_of_being_obstacle_to_gaza_truce/"> <img alt="US accuses Hamas of being 'obstacle' to Gaza truce after it rejected Israel's proposal" src="https://external-preview.redd.it/huaXrpNRAHoS34rL9Cwyj671wxyMNXvHGz2dE9yIfko.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a0664010959a4b2604485065ec09a49c342e5bcf" title="US accuses Hamas of being 'obstacle' to Gaza truce after it rejected Israel's proposal" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/yuri_2022"> /u/yuri_2022 </a> <br /> <span><a href="https://www.timesofisrael.com/us-accuses-hamas-of-being-obstacle-to-gaza-truce-after-rejecting-israels-proposal/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c57f1b/us_accuses_hamas_of_being_obstacle_to_gaza_truce/">[comments]</a></span> </td></tr></table>

## U.S. officials expect Israeli response to Iran strikes will be limited
 - [https://www.reddit.com/r/worldnews/comments/1c55vtc/us_officials_expect_israeli_response_to_iran](https://www.reddit.com/r/worldnews/comments/1c55vtc/us_officials_expect_israeli_response_to_iran)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T03:14:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c55vtc/us_officials_expect_israeli_response_to_iran/"> <img alt="U.S. officials expect Israeli response to Iran strikes will be limited" src="https://external-preview.redd.it/ndzwEP-vWX3nlaXbrTutUi6jkgch7upfNqbZ1j3ojt4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3a15a7bbeb816902eadb40815a2a5767f0a1e892" title="U.S. officials expect Israeli response to Iran strikes will be limited" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/nbcnews"> /u/nbcnews </a> <br /> <span><a href="https://www.nbcnews.com/news/world/us-officials-expect-israeli-response-iran-strikes-will-limited-rcna147949">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c55vtc/us_officials_expect_israeli_response_to_iran/">[comments]</a></span> </td></tr></table>

## A knife attack in Australia against a bishop and a priest is being treated as terrorism, police say
 - [https://www.reddit.com/r/worldnews/comments/1c555pa/a_knife_attack_in_australia_against_a_bishop_and](https://www.reddit.com/r/worldnews/comments/1c555pa/a_knife_attack_in_australia_against_a_bishop_and)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T02:38:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c555pa/a_knife_attack_in_australia_against_a_bishop_and/"> <img alt="A knife attack in Australia against a bishop and a priest is being treated as terrorism, police say" src="https://external-preview.redd.it/u1mB4_iSY16AR9_5Gvzt8jh1032g_vPi8Swswo2axsI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8b76ee30b59cfdfd3c60039318b16883975cdf90" title="A knife attack in Australia against a bishop and a priest is being treated as terrorism, police say" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Nova__mars"> /u/Nova__mars </a> <br /> <span><a href="https://apnews.com/article/australia-church-stabbing-0fd1e9d4ae21915d16318456d1e58bc7">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c555pa/a_knife_attack_in_australia_against_a_bishop_and/">[comments]</a></span> </td></tr></table>

## Ukrainian Commander: Eastern Front Has 'Deteriorated Significantly'
 - [https://www.reddit.com/r/worldnews/comments/1c54bg3/ukrainian_commander_eastern_front_has](https://www.reddit.com/r/worldnews/comments/1c54bg3/ukrainian_commander_eastern_front_has)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T01:57:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c54bg3/ukrainian_commander_eastern_front_has/"> <img alt="Ukrainian Commander: Eastern Front Has 'Deteriorated Significantly'" src="https://external-preview.redd.it/7SuSYzyjC_f_XCDfpX5zKmEss-eTqK_8CbsqsZsfg0c.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7609651bd441a1126761b4f0e00440156d84e5d4" title="Ukrainian Commander: Eastern Front Has 'Deteriorated Significantly'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GooseberryGOLD"> /u/GooseberryGOLD </a> <br /> <span><a href="https://www.improvethenews.org/story/2024/ukrainian-commander-eastern-front-has-deteriorated-significantly">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c54bg3/ukrainian_commander_eastern_front_has/">[comments]</a></span> </td></tr></table>

## Israel’s military chief says that Israel will respond to Iran’s weekend missile strike
 - [https://www.reddit.com/r/worldnews/comments/1c53gf8/israels_military_chief_says_that_israel_will](https://www.reddit.com/r/worldnews/comments/1c53gf8/israels_military_chief_says_that_israel_will)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T01:16:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c53gf8/israels_military_chief_says_that_israel_will/"> <img alt="Israel’s military chief says that Israel will respond to Iran’s weekend missile strike" src="https://external-preview.redd.it/0YmesBDpVm6_Y0KQfM9Ys3Plewk7a0QCX9_g-lMThQM.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=9e4bd3a23e33276b3b18ca2189f6b12a539bdd2a" title="Israel’s military chief says that Israel will respond to Iran’s weekend missile strike" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/pasta-cocoa"> /u/pasta-cocoa </a> <br /> <span><a href="https://www.stripes.com/theaters/middle_east/2024-04-15/israel-response-iran-attack-13557162.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c53gf8/israels_military_chief_says_that_israel_will/">[comments]</a></span> </td></tr></table>

## Iran's Crackdown On Women Intensifies Under Cover Of War
 - [https://www.reddit.com/r/worldnews/comments/1c51y43/irans_crackdown_on_women_intensifies_under_cover](https://www.reddit.com/r/worldnews/comments/1c51y43/irans_crackdown_on_women_intensifies_under_cover)
 - RSS feed: https://www.reddit.com/r/worldnews/.rss
 - date published: 2024-04-16T00:07:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1c51y43/irans_crackdown_on_women_intensifies_under_cover/"> <img alt="Iran's Crackdown On Women Intensifies Under Cover Of War" src="https://external-preview.redd.it/jhPCnHmNB8BWCJqsbniL5XnHkfDt_NsFcoTjCSKNxvs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4f67fafefcf76f0b9ce4186cac047f12774dc6b7" title="Iran's Crackdown On Women Intensifies Under Cover Of War" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/danmghm"> /u/danmghm </a> <br /> <span><a href="https://www.iranintl.com/en/202404154516">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1c51y43/irans_crackdown_on_women_intensifies_under_cover/">[comments]</a></span> </td></tr></table>

