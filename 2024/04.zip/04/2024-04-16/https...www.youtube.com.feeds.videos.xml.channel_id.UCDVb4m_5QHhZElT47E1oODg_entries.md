# Source:The Dave Cullen Show, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg, language:en-US

## Does Anyone Still Care?
 - [https://www.youtube.com/watch?v=gP1Hp35IBn4](https://www.youtube.com/watch?v=gP1Hp35IBn4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg
 - date published: 2024-04-16T17:45:52+00:00

📲Download Raid to win a console using my link only ➡️ https://pl.go-ga.me/wycwamwq and get 2 epic heroes + a free legendary! 🔥 ☘️Take part in the SpringHunt event and get your gift at https://springhunt.plarium.com (make sure to download Raid using my link first) 💎 Prizes include GAMING CONSOLES and Amazon gift cards with a total value of $10,000!

Tip me: https://www.subscribestar.com/dave-cullen/tip
Support my Work on Paychute: https://www.paychute.com/c/davecullenshow
Subscribestar: https://www.subscribestar.com/dave-cullen

Follow me on Bitchute: https://www.bitchute.com/channel/hybM74uIHJKg/

Sources:

https://comicbookmovie.com/captain-america/captain-america-new-world-order/captain-america-returns-in-first-official-look-at-brave-new-world-a210397#gs.7aj21l

Disclaimer: Raid: Shadow Legends «Influencers Spring Event». Entry is Open to legal residents of THE 50 UNITED STATES AND THE DISTRICT OF COLUMBIA ( excluding New York and Florida), or of UNITED KINGDOM who are 18 years or o

