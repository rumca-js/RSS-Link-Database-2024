# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Owoce zostaną na krzakach przez brak pracowników. Tego boją się plantatorzy
 - [https://businessinsider.com.pl/gospodarka/owoce-zostana-na-krzakach-przez-brak-pracownikow-tego-boja-sie-plantatorzy/2w5jyf6](https://businessinsider.com.pl/gospodarka/owoce-zostana-na-krzakach-przez-brak-pracownikow-tego-boja-sie-plantatorzy/2w5jyf6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T20:04:04+00:00

Choć sezon na truskawki jeszcze na dobre się nie zaczął, plantatorzy obawiają się, że nie biedzie chętnych do zbierania plonów. Niedobór pracowników sezonowych może oznaczać, że duża część owoców się zmarnuje.

## "Sukces inflacyjny zajmie więcej czasu". Padły kluczowe słowa dla światowych rynków
 - [https://businessinsider.com.pl/gospodarka/sukces-inflacyjny-zajmie-wiecej-czasu-padly-kluczowe-slowa-dla-swiatowych-rynkow/ynzr1xq](https://businessinsider.com.pl/gospodarka/sukces-inflacyjny-zajmie-wiecej-czasu-padly-kluczowe-slowa-dla-swiatowych-rynkow/ynzr1xq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T19:55:07+00:00

Przewodniczący Rezerwy Federalnej USA Jerome Powell powiedział we wtorek, że powrót inflacji do celu banku centralnego na poziomie 2 proc. zajmie prawdopodobnie "więcej czasu, niż oczekiwano". Te słowa wskazują na prawdopodobne przesunięcie w czasie obniżek stóp procentowych.

## Zarząd Orlenu już w pełnym składzie. Kim są nowo powołani
 - [https://businessinsider.com.pl/gielda/zarzad-orlenu-juz-w-pelnym-skladzie-kim-sa-nowo-powolani/nksrr6s](https://businessinsider.com.pl/gielda/zarzad-orlenu-juz-w-pelnym-skladzie-kim-sa-nowo-powolani/nksrr6s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T19:29:44+00:00

Po ekipie Daniela Obajtka zostało w Orlenie już tylko wspomnienie. Od 11 kwietnia największą spółką w Polsce kieruje Ireneusz Fąfara, a we wtorek 16 kwietnia skompletowano skład nowego zarządu spółki, zwalniając jednocześnie ostatniego członka zarządu ze "składu Obajtka". Oto jakie kompetencje mają nowi zarządzający.

## Chciała od urzędników odszkodowanie za płot. Dostała trzy miliony kary
 - [https://businessinsider.com.pl/wiadomosci/chciala-od-urzednikow-odszkodowanie-za-plot-dostala-ponad-3-mln-zl-kary/0wv2m0r](https://businessinsider.com.pl/wiadomosci/chciala-od-urzednikow-odszkodowanie-za-plot-dostala-ponad-3-mln-zl-kary/0wv2m0r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T19:01:53+00:00

Robotnicy pracujący na zlecenie łódzkiego samorządu uszkodzili płot Iwony Owczarek. Kobieta wezwała miejscowy zarząd dróg do pokrycia kosztów naprawy. W odpowiedzi dostała... ponad 3 mln zł kary. Okazało się, że płot od 70 lat stoi w pasie drogi. Sprawa trafiła do sądu. A perypetie mieszkanki Łodzi szeroko relacjonuje program Telewizji Polsat "Interwencja".

## Ile więcej zapłacimy za prąd po nowej ustawie. Znamy już maksymalną cenę od lipca
 - [https://businessinsider.com.pl/prawo/ile-wiecej-zaplacimy-za-prad-po-nowej-ustawie-znamy-juz-maksymalna-cene-od-lipca/drg2mjl](https://businessinsider.com.pl/prawo/ile-wiecej-zaplacimy-za-prad-po-nowej-ustawie-znamy-juz-maksymalna-cene-od-lipca/drg2mjl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T18:03:37+00:00

W projektowanej ustawie o bonie energetycznym mają się znaleźć przepisy, na mocy których w drugiej połowie 2024 r. będzie obowiązywać maksymalna cena energii elektrycznej dla gospodarstw w wysokości 500 zł za MWh – wynika z informacji opublikowanej we wtorek na stronach Kancelarii premiera. To o 22 proc. wyżej niż obecnie wynosi cena zamrożona.

## Znamy już maksymalną cenę energii od lipca. Jest projekt ustawy
 - [https://businessinsider.com.pl/prawo/znamy-juz-maksymalna-cene-energii-od-lipca-jest-projekt-ustawy/drg2mjl](https://businessinsider.com.pl/prawo/znamy-juz-maksymalna-cene-energii-od-lipca-jest-projekt-ustawy/drg2mjl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T18:03:37+00:00

W projektowanej ustawie o bonie energetycznym mają się znaleźć przepisy, na mocy których w drugiej połowie 2024 r. będzie obowiązywać maksymalna cena energii elektrycznej dla gospodarstw w wysokości 500 zł za MWh – wynika z informacji opublikowanej we wtorek na stronach Kancelarii premiera.

## Najwięksi akcjonariusze pozbywają się akcji Allegro. Półtora miliarda do kieszeni
 - [https://businessinsider.com.pl/gielda/wiadomosci/najwieksi-akcjonariusze-pozbywaja-sie-akcji-allegro-poltora-miliarda-do-kieszeni/vnk9rdq](https://businessinsider.com.pl/gielda/wiadomosci/najwieksi-akcjonariusze-pozbywaja-sie-akcji-allegro-poltora-miliarda-do-kieszeni/vnk9rdq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T17:36:42+00:00

Kilka dni temu Allegro dostało powiadomienie od swoich menadżerów. Ci szykowali się do sprzedaży należących do nich akcji spółki, żeby spłacić podatek od ich przyznania. We wtorek przyszła kolejna wiadomość tego typu, ale już od największych akcjonariuszy. Jak podaje Bloomberg, ich oferta opiewa na 50 mln akcji.

## Kiedy kolejne pieniądze z KPO? Minister podaje harmonogram
 - [https://businessinsider.com.pl/gospodarka/kiedy-kolejne-pieniadze-z-kpo-minister-podaje-harmonogram/4yvyyd9](https://businessinsider.com.pl/gospodarka/kiedy-kolejne-pieniadze-z-kpo-minister-podaje-harmonogram/4yvyyd9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T16:49:28+00:00

— Chcemy złożyć wnioski o kolejne płatności z KPO po wakacjach, żeby środki wpłynęły do końca tego roku. Możemy dostać maksimum 10 mld euro – powiedziała we wtorek minister funduszy i polityki regionalnej Katarzyna Pełczyńska-Nałęcz.

## Gigantyczne inwestycje w sieci energetyczne. "Będziemy się zadłużać"
 - [https://businessinsider.com.pl/biznes/gigantyczne-inwestycje-w-sieci-energetyczne-bedziemy-sie-zadluzac/1pepddp](https://businessinsider.com.pl/biznes/gigantyczne-inwestycje-w-sieci-energetyczne-bedziemy-sie-zadluzac/1pepddp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T16:30:23+00:00

Operator sieci elektroenergetycznych ma przed sobą wielomiliardowe inwestycje. To będzie wymagało zupełnie innego podejścia do finansowania programu inwestycyjnego, np. do zadłużenia na rynkach finansowych — poinformował podczas Kongresu Energetyki Przyszłości w Toruniu prezes Polskich Sieci Elektroenergetycznych Grzegorz Onichimowski.

## Nowa aplikacja dla dronów. Od razu zaatakowali ją hakerzy
 - [https://businessinsider.com.pl/wiadomosci/nowa-aplikacja-dla-dronow-od-razu-przechwycili-ja-hakerzy/enpybh8](https://businessinsider.com.pl/wiadomosci/nowa-aplikacja-dla-dronow-od-razu-przechwycili-ja-hakerzy/enpybh8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T16:19:12+00:00

Wystartowała aplikacja DroneTower — oficjalny system do zgłaszania zamiaru wykonania lotu dronem. Z tej okazji w poniedziałek odbyła się konferencja prasowa z udziałem ministra infrastruktury Dariusza Klimczaka. Jednak jeszcze tego samego dnia aplikację zaatakowali hakerzy.

## Wybory do europarlamentu 2024. Kalendarium wyborcze
 - [https://businessinsider.com.pl/prawo/wybory-do-europarlamentu-2024-te-daty-warto-znac/fydnpd3](https://businessinsider.com.pl/prawo/wybory-do-europarlamentu-2024-te-daty-warto-znac/fydnpd3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T16:08:49+00:00

Tegoroczne wybory do europarlamentu odbędą się w Polsce 9 czerwca. Zanim jednak Polki i Polacy pójdą do urn, aby wybrać swoich reprezentantów w PE, warto pamiętać o ważnych datach, które dotyczą szerokiej grupy wyborców.

## Michał Tusk ma nową pracę. Trafił do urzędu marszałkowskiego
 - [https://businessinsider.com.pl/wiadomosci/michal-tusk-ma-nowa-prace-trafil-do-urzedu-marszalkowskiego/e0jdvfg](https://businessinsider.com.pl/wiadomosci/michal-tusk-ma-nowa-prace-trafil-do-urzedu-marszalkowskiego/e0jdvfg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T16:02:09+00:00

Syn premiera Michał Tusk od kwietnia pracuje w nowym miejscu. Znalazł zatrudnienie w pomorskim urzędzie marszałkowskim. Sam zainteresowany nie chce komentować swojej nowej posady. To jednak nie pierwszy raz, gdy syn szefa rządu trafia do jednostki samorządowej.

## Robert Bąkiewicz z zarzutem. Prokuratura: doszło do popełnienia przestępstwa
 - [https://businessinsider.com.pl/wiadomosci/robert-bakiewicz-uslyszal-zarzut-doszlo-do-popelnienia-przestepstwa/m3gx0hq](https://businessinsider.com.pl/wiadomosci/robert-bakiewicz-uslyszal-zarzut-doszlo-do-popelnienia-przestepstwa/m3gx0hq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T15:47:39+00:00

Robert Bąkiewicz usłyszał we wtorek zarzut uszkodzenia zabytku. "Materiał zgromadzony w sprawie pozwolił na stwierdzenie, że doszło do popełnienia przestępstwa" – powiedział rzecznik prokuratury. Czyn ten jest zagrożony karą od sześciu miesięcy do 8 lat pozbawienia wolności.

## 578 osób podsłuchiwanych Pegasusem. Jest komunikat
 - [https://businessinsider.com.pl/wiadomosci/578-osob-podsluchiwanych-pegasusem-jest-komunikat/0qtg5dl](https://businessinsider.com.pl/wiadomosci/578-osob-podsluchiwanych-pegasusem-jest-komunikat/0qtg5dl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T15:34:11+00:00

W latach 2017-2022 kontrola operacyjna przy użyciu Pegasusa objęła 578 osób — wynika z informacji Prokuratora Generalnego przesłanej do Sejmu i Senatu. Najwięcej osób było objętych taką kontrolą w 2021 r. — 162.

## Za trzy lata wyprzedzimy Hiszpanię. Prognozy dla polskiej gospodarki w górę
 - [https://businessinsider.com.pl/gospodarka/za-trzy-lata-wyprzedzimy-hiszpanie-prognozy-dla-polskiej-gospodarki-w-gore/ngzkl78](https://businessinsider.com.pl/gospodarka/za-trzy-lata-wyprzedzimy-hiszpanie-prognozy-dla-polskiej-gospodarki-w-gore/ngzkl78)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T15:17:48+00:00

Prognozy Międzynarodowego Funduszu Walutowego dla Polski poszły wyraźnie w górę. Czy to oznacza, że wbijemy się do pierwszej 20. największych gospodarek świata? Zaraz przed nami są Szwajcaria i Turcja, a w rankingu PKB na mieszkańca według siły nabywczej gonimy m.in. Czechy i Hiszpanię.

## Wybory do europarlamentu 2024. Za tydzień mija ważny termin
 - [https://businessinsider.com.pl/prawo/wybory-do-europarlamentu-2024-22-kwietnia-mija-wazy-termin/mwvmyjh](https://businessinsider.com.pl/prawo/wybory-do-europarlamentu-2024-22-kwietnia-mija-wazy-termin/mwvmyjh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T15:15:21+00:00

W 2024 r. Polki i Polacy wezmą udział w eurowyborach, w których wyłonieni zostaną reprezentanci do unijnego parlamentu. Komitety, które chcą wystawić swoich kandydatów, mają już niewiele czasu na zgłoszenie się do PKW.

## Oto nowa szefowa GIOŚ. Jest komunikat resortu
 - [https://businessinsider.com.pl/wiadomosci/oto-nowa-szefowa-gios-jest-komunikat-resortu/bjbqsfj](https://businessinsider.com.pl/wiadomosci/oto-nowa-szefowa-gios-jest-komunikat-resortu/bjbqsfj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T15:07:48+00:00

Joanna Piekutowska została wybrana na stanowisko Głównego Inspektora Ochrony Środowiska — poinformował we wtorek resort klimatu. Piekutowska od 1992 r. jest związana z Inspekcją Ochrony Środowiska.

## Polski ChatGPT już działa. Jak wypada? Nie zna marszałka Sejmu
 - [https://businessinsider.com.pl/technologie/polski-chatgpt-bielik-juz-dziala-ale-nie-zna-marszalka-sejmu/hlm4zg6](https://businessinsider.com.pl/technologie/polski-chatgpt-bielik-juz-dziala-ale-nie-zna-marszalka-sejmu/hlm4zg6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T14:57:36+00:00

Bielik to model sztucznej inteligencji stworzony wyłącznie na języku polskim. Jak wypada? Zdarzają mu się wpadki. Polski ChatGPT nie wie, kto jest marszałkiem Sejmu.

## W Zaporożu coraz poważniej. "Bezpieczeństwo nuklearne zagrożone"
 - [https://businessinsider.com.pl/wiadomosci/w-zaporozu-coraz-powazniej-bezpieczenstwo-nuklearne-zagrozone/r9w0qcd](https://businessinsider.com.pl/wiadomosci/w-zaporozu-coraz-powazniej-bezpieczenstwo-nuklearne-zagrozone/r9w0qcd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T14:56:26+00:00

Sytuacja w Zaporoskiej Elektrowni Atomowej wymyka się spod kontroli. Jak informuje szef Międzynarodowej Agencji Energii Atomowej Rafael Grossi, "bezpieczeństwo nuklearne jest tam zagrożone". I zaapelował o zaprzestanie ataków na elektrownię.

## Budują na wsiach ładowarki do samochodów elektrycznych. Tłumaczą dlaczego
 - [https://businessinsider.com.pl/technologie/motoryzacja/buduja-na-wsiach-ladowarki-do-samochodow-elektrycznych-tlumacza-dlaczego/c86jr22](https://businessinsider.com.pl/technologie/motoryzacja/buduja-na-wsiach-ladowarki-do-samochodow-elektrycznych-tlumacza-dlaczego/c86jr22)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T14:52:47+00:00

Powerdot, firma specjalizująca się w budowie stacji ładowania dla pojazdów elektrycznych postanowiła inwestować w ładowarki w małych, wiejskich gminach, gdzie nie ma zarejestrowanego ani jednego elektrycznego samochodu. Dlaczego? Przedsiębiorstwo tłumaczy powody swojej decyzji.

## Prawie 2 tys. chętnych do pracy w TVP. Stacja podsumowała rekrutację
 - [https://businessinsider.com.pl/wiadomosci/prawie-2-tys-chetnych-do-pracy-w-tvp-stacja-podsumowala-rekrutacje/3p5h7em](https://businessinsider.com.pl/wiadomosci/prawie-2-tys-chetnych-do-pracy-w-tvp-stacja-podsumowala-rekrutacje/3p5h7em)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T14:30:03+00:00

Telewizja Polska zakończyła pierwszy proces rekrutacji. Do pracy w TVP zgłosiła się potężna fala kandydatów, spośród których wybrani zostaną dziennikarze i prowadzący. Co ciekawe, kilkadziesiąt aplikacji zostało wysłanych z zagranicy.

## Zagrożenie z Iranu dla rynku ropy naftowej to nie tylko spadek wydobycia
 - [https://businessinsider.com.pl/gielda/wiadomosci/zagrozenie-z-iranu-dla-rynku-ropy-naftowej-to-nie-tylko-spadek-wydobycia/kbqxk9h](https://businessinsider.com.pl/gielda/wiadomosci/zagrozenie-z-iranu-dla-rynku-ropy-naftowej-to-nie-tylko-spadek-wydobycia/kbqxk9h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T14:13:13+00:00

Analitycy Banku Pekao przeanalizowali notowania kluczowych surowców energetycznych. Zwracają uwagę na potencjalne skutki eskalacji konfliktu Izraela z Iranem dla rynku ropy, głównie w zakresie zaburzeń podaży tego surowca, co mogłoby wywindować ceny. Spodziewają się lekkiego wzrostu notowań gazu ziemnego, który i tak pozostaje konkurencyjny wobec wysokoemisyjnego węgla. Ceny emisji dwutlenku węgla mają według prognoz rosnąć.

## Restauracja serwuje alkohol za darmo. Ale trzeba ze sobą rozmawiać
 - [https://businessinsider.com.pl/lifestyle/restauracja-serwuje-alkohol-za-darmo-ale-trzeba-ze-soba-rozmawiac/4nx8hm2](https://businessinsider.com.pl/lifestyle/restauracja-serwuje-alkohol-za-darmo-ale-trzeba-ze-soba-rozmawiac/4nx8hm2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T14:09:16+00:00

Restauracja we Włoszech oferuje bezpłatną butelkę wina klientom, którzy podczas posiłku nie będą korzystać ze smartfona. "To naprawdę piękna rzecz widzieć, jak ludzie rozmawiają ze sobą, zamiast oglądać zdjęcia lub odpowiadać na wiadomości na telefonie" — mówi właściciel lokalu.

## Kiedyś była milionerką, dzisiaj "królowa Zakopanego" jest bankrutką
 - [https://businessinsider.com.pl/gospodarka/kiedys-byla-milionerka-dzisiaj-krolowa-zakopanego-jest-bankrutka/nv78jtw](https://businessinsider.com.pl/gospodarka/kiedys-byla-milionerka-dzisiaj-krolowa-zakopanego-jest-bankrutka/nv78jtw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T14:05:10+00:00

W zimowej stolicy Polski oraz na Mazowszu Małgorzata Ch. prowadziła ekskluzywne hotele, a jej majątek był tak pokaźny, że znalazła się na liście najbogatszych Polaków. Dzisiaj kobieta, która bywała określana mianem "królowej Zakopanego", jest bankrutką, a w jej sprawie toczy się proces w sądzie.

## Tajemnicza rezydencja Aleksandra Łukaszenki. "Największa łapówka"
 - [https://businessinsider.com.pl/wiadomosci/rezydencja-wschod-ma-nalezec-do-aleksandra-lukaszenki-najwieksza-lapowka/et1t082](https://businessinsider.com.pl/wiadomosci/rezydencja-wschod-ma-nalezec-do-aleksandra-lukaszenki-najwieksza-lapowka/et1t082)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T13:53:58+00:00

Na terenie Zalewu Zasławskiego pod Mińskiem stoi ogromna trzykondygnacyjna rezydencja. Oficjalnie jest tam rządowa linia telekomunikacyjna, a dom kontrolują służby bezpieczeństwa. Jednak w rzeczywistości wielka posiadłość ma należeć do Aleksandra Łukaszenki. Organizacja byłych mundurowych BELPOL informuje, że pod tym adresem zameldowani są synowie i wnuki białoruskiego dyktatora.

## Gigant ostrzega: polskie firmy coraz słabsze wobec hakerów
 - [https://businessinsider.com.pl/gospodarka/gigant-ostrzega-polskie-firmy-coraz-slabsze-wobec-hakerow/7gebqz6](https://businessinsider.com.pl/gospodarka/gigant-ostrzega-polskie-firmy-coraz-slabsze-wobec-hakerow/7gebqz6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T13:41:42+00:00

Polskie firmy cofają się w kwestii cyberbezpieczeństwa — tak wynika z tegorocznego raportu Cisco Cybersecurity Readiness Index 2024. Zaledwie 2 proc. polskich firm jest na tyle dojrzałych, że mogą skutecznie stawić czoła współczesnym zagrożeniom cybernetycznym. Odsetek ten jest wyraźnie niższy w porównaniu z poprzednią edycją badania, gdzie 7 proc. firm zostało sklasyfikowanych jako dojrzałe.

## Kontrola w gospodarstwie byłego ministra. Odkryto trzy martwe konie
 - [https://businessinsider.com.pl/wiadomosci/trzy-martwe-konie-u-bylego-ministra-rolnictwa-zrebaka-ukrywano-pod-plandeka/q1r2vzg](https://businessinsider.com.pl/wiadomosci/trzy-martwe-konie-u-bylego-ministra-rolnictwa-zrebaka-ukrywano-pod-plandeka/q1r2vzg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T13:35:12+00:00

Na gruntach dzierżawionych przez rodzinę Roberta Telusa od państwa miało dochodzić do licznych nieprawidłowości. Podczas kontroli znaleziono m.in. martwe zwierzęta. Co na to polityk PiS? Jest zaskoczony działaniami Lasów Państwowych i zapowiada konsekwencje.

## "Krytyczna sytuacja" nad Bałtykiem. Rosyjski samolot musiał lądować awaryjnie
 - [https://businessinsider.com.pl/wiadomosci/krytyczna-sytuacja-nad-baltykiem-rosyjski-samolot-musial-ladowac-awaryjnie/c1evvf4](https://businessinsider.com.pl/wiadomosci/krytyczna-sytuacja-nad-baltykiem-rosyjski-samolot-musial-ladowac-awaryjnie/c1evvf4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T13:32:23+00:00

Samolot linii Aerofłot, który we wtorek przed południem wystartował z Kaliningradu i miał lecieć do Moskwy, zgłosił sytuację krytyczną nad Morzem Bałtyckim. W efekcie musiał awaryjnie wylądować w Sankt Petersburgu. Nie wiadomo, co dokładnie stało się z maszyną.

## Jedna czwarta załogi na bruk. Zwolnienia w kolejnej fabryce w Polsce
 - [https://businessinsider.com.pl/gospodarka/jedna-czwarta-zalogi-na-bruk-zwolnienia-w-kolejnej-fabryce-w-polsce/e7jdns3](https://businessinsider.com.pl/gospodarka/jedna-czwarta-zalogi-na-bruk-zwolnienia-w-kolejnej-fabryce-w-polsce/e7jdns3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T13:16:17+00:00

Produkująca łopaty do turbin wiatrowych Goleniów LM Wind Power Blades działa w Polsce od 2008 r. I wkrótce będzie działać w okrojonym zakresie. Zwalnia jedną czwartą załogi, czyli dwieście osób. W tej firmie nie tylko w Polsce będą cięcia.

## Będą problemy z wydaniem pieniędzy z KPO. Donald Tusk zapowiada negocjacje z Brukselą
 - [https://businessinsider.com.pl/gospodarka/beda-problemy-z-wydaniem-kpo-donald-tusk-zapowiada-negocjacje-z-bruksela/k97rngn](https://businessinsider.com.pl/gospodarka/beda-problemy-z-wydaniem-kpo-donald-tusk-zapowiada-negocjacje-z-bruksela/k97rngn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T13:01:47+00:00

Podczas konferencji prasowej po posiedzeniu rządu premier Donald Tusk poruszył kwestię wydatkowania pieniędzy z Krajowego Planu Odbudowy. Zapowiedział, że będzie próbował przekonać Komisję Europejską do tego, by nie przepadły pieniądze, których nie uda się wydać na czas. — Będę rozmawiał z tymi, którzy chcą kandydować na różne stanowiska w Europie, żeby wzięli pod uwagę tę okoliczność — zapewniał.

## Premier komentuje sprawę spółki Orlenu. "Włosy mi na głowie stanęły"
 - [https://businessinsider.com.pl/gospodarka/premier-komentuje-sprawe-spolki-ots-wlosy-mi-na-glowie-stanely/51pl8sy](https://businessinsider.com.pl/gospodarka/premier-komentuje-sprawe-spolki-ots-wlosy-mi-na-glowie-stanely/51pl8sy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T12:47:57+00:00

— Kiedy dotarły do mnie pierwsze informacje o tej stracie, to mi włosy na głowie stanęły. Inne okoliczności tej sprawy również są bulwersujące — tak o sprawie należącej do Orlenu szwajcarskiej spółki OTS mówił we wtorek premier Donald Tusk.

## Szkolenia dla flipperów. "Dzięki nam jest mniej pustostanów"
 - [https://businessinsider.com.pl/nieruchomosci/szkolenia-z-flippowania-ile-zarabia-flipper-dzieki-nam-jest-mniej-pustostanow/htp67yk](https://businessinsider.com.pl/nieruchomosci/szkolenia-z-flippowania-ile-zarabia-flipper-dzieki-nam-jest-mniej-pustostanow/htp67yk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T12:15:13+00:00

Fliperów na rynku nieruchomości przybywa, bo przyciągają ich zyski. Twierdzą, że na jednej inwestycji można zarobić od kilku do nawet kilkuset tysięcy złotych. Przybywa też szkoleń dla nich. "Dzięki naszym działaniom na rynku jest coraz mniej pustostanów" — twierdzi uczestnik szkolenia.

## Tyle ZUS wydał na pielgrzymki na Jasną Górę. "By zawierzyć Bogu pracę urzędników"
 - [https://businessinsider.com.pl/wiadomosci/zwiazkowcy-ujawnili-niektore-wydatki-zus-320-tys-zl-na-religijne-wyprawy/c2p5he6](https://businessinsider.com.pl/wiadomosci/zwiazkowcy-ujawnili-niektore-wydatki-zus-320-tys-zl-na-religijne-wyprawy/c2p5he6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T12:05:42+00:00

Ponad 320 tys. zł w ciągu siedmiu lat prezesury Gertrudy Uścińskiej wydał Zakład Ubezpieczeń Społecznych na pielgrzymki do Częstochowy. W wyprawach brała udział sama prezeska, a pracownicy mieli być co roku zachęcani do uczestniczenia w modlitwach — informuje Związek Zawodowy Związkowa Alternatywa.

## Kolejny spadek inflacji. Dane w tym zakresie będą jednak kłopotem dla NBP
 - [https://businessinsider.com.pl/gospodarka/inflacja-znowu-w-dol-mocny-spadek-rowno-rok-po-niechlubnym-rekordzie/zg173j9](https://businessinsider.com.pl/gospodarka/inflacja-znowu-w-dol-mocny-spadek-rowno-rok-po-niechlubnym-rekordzie/zg173j9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T12:00:16+00:00

Mamy kolejny dowód na spadek dynamiki cen w Polsce. Najnowsze statystyki NBP wskazują, że równo rok po rekordzie inflacja bazowa spadła mocno spadła i jest na najniższym poziomie od jesieni 2021 r. Jednak nie należy przedwcześnie ogłaszać tryumfu nad inflacją: druga połowa roku przyniesie bowiem odbicie.

## Chińska gospodarka ma się lepiej,  ale ból jeszcze się nie skończył
 - [https://businessinsider.com.pl/gospodarka/chinska-gospodarka-ma-sie-lepiej-ale-bol-jeszcze-sie-nie-skonczyl/7se6hdl](https://businessinsider.com.pl/gospodarka/chinska-gospodarka-ma-sie-lepiej-ale-bol-jeszcze-sie-nie-skonczyl/7se6hdl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T11:39:38+00:00

Chiński gospodarka rośnie, w pierwszym kwartale togo roku PKB wzrósł o 5,3 proc. Ale nie oznacza to, że kryzys gospodarczy Chin się skończył.

## Oficjalnie: gigant wygasza zakład w Polsce. Firma się tłumaczy
 - [https://businessinsider.com.pl/firmy/oficjalnie-gigant-wygasza-zaklad-w-polsce-firma-sie-tlumaczy/dy2bbf9](https://businessinsider.com.pl/firmy/oficjalnie-gigant-wygasza-zaklad-w-polsce-firma-sie-tlumaczy/dy2bbf9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T11:39:10+00:00

Michelin Polska zdecydował o zakończeniu produkcji opon do samochodów ciężarowych w swoim zakładzie w Olsztynie wraz z końcem roku. Firma tłumaczy się z kontrowersji związanych z tą decyzją.

## Żelazna kopuła również nad Europą? Andrzej Duda komentuje
 - [https://businessinsider.com.pl/wiadomosci/zelazna-kopula-rowniez-nad-europa-andrzej-duda-komentuje/dqr673e](https://businessinsider.com.pl/wiadomosci/zelazna-kopula-rowniez-nad-europa-andrzej-duda-komentuje/dqr673e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T11:18:52+00:00

Od wielu lat budujemy system obrony powietrznej oparty przede wszystkim na systemie Patriot — oświadczył we wtorek prezydent Andrzej Duda, sceptycznie odnosząc się przy tym do pomysłu budowy tzw. żelaznej kopuły nad Europą. Zwrócił uwagę, że to jest "biznesowy projekt niemiecki", który pojawił się przed dwoma laty.

## Superbogaci pouciekali z Norwegii. Nie bawią się w dyskrecję, oburzenie ich nie obchodzi
 - [https://businessinsider.com.pl/wiadomosci/bogacze-pouciekali-z-norwegii-nie-bawia-sie-w-dyskrecje-oburzenie-ich-nie-obchodzi/6jh5dl1](https://businessinsider.com.pl/wiadomosci/bogacze-pouciekali-z-norwegii-nie-bawia-sie-w-dyskrecje-oburzenie-ich-nie-obchodzi/6jh5dl1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T11:13:00+00:00

Ci, którzy przenoszą się do raju podatkowego, zwykle robią to tak niepozornie, jak to tylko możliwe. Tord Ueland Kolstad nie dba jednak o dyskrecję. Hodowca łososi i magnat nieruchomości otwarcie i publicznie mówi o tym, że wyprowadził się z Bodø w północnej Norwegii, aby zaoszczędzić na podatkach. Nie jest jedyny.

## Zaplanuj urlop na słonecznej Maderze. Pokoje z widokiem na ocean
 - [https://businessinsider.com.pl/lifestyle/podroze/zaplanuj-urlop-na-slonecznej-maderze-pokoje-z-widokiem-na-ocean/h0nhl5b](https://businessinsider.com.pl/lifestyle/podroze/zaplanuj-urlop-na-slonecznej-maderze-pokoje-z-widokiem-na-ocean/h0nhl5b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T11:00:00+00:00

Madera to malownicza wyspa na Oceanie Atlantyckim, nazywana jest rajskim ogrodem, w którym wiosna panuje przez cały rok. Słynie z zapierających dech w piersiach widoków, bujnej roślinności, wyśmienitej kuchni oraz kameralnych miasteczek i wiosek bogatych w zabytki. Jest to największa i najbardziej popularna wyspa z archipelagu wysp portugalskich. Charakteryzują ją piękne plaże, kwiaty i bogata zielona roślinność z unikatowymi na skalę światową lasami laurowymi, które objęte są ochroną UNESCO. W artykule polecamy sprawdzone hotele od biura podróży Rainbow, które mają dostępne terminy wiosną i latem i są różnorodne pod względem standardu i ceny. Zapraszamy!

## Tak urósł polski dług publiczny. Skokowy wzrost
 - [https://businessinsider.com.pl/gospodarka/tak-urosl-polski-dlug-publiczny-skokowy-wzrost/ewym57d](https://businessinsider.com.pl/gospodarka/tak-urosl-polski-dlug-publiczny-skokowy-wzrost/ewym57d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T10:59:36+00:00

Duży wzrost wydatków na łagodzenie skutków pandemii, tarcze antyinflacyjne oraz na obronność skutkował skokowym zwiększenia deficytu polskich finansów publicznych. Prze rok urósł o 63 proc., czyli o 67 mld zł, a przez dwa lata o 260 proc., czyli aż 126 mld zł.

## Niezapomniane chwile w designerskich i postindustrialnych wnętrzach. Specjalne ceny
 - [https://businessinsider.com.pl/lifestyle/podroze/niezapomniane-chwile-w-designerskich-i-postindustrialnych-wnetrzach-specjalne-ceny/72m1bvd](https://businessinsider.com.pl/lifestyle/podroze/niezapomniane-chwile-w-designerskich-i-postindustrialnych-wnetrzach-specjalne-ceny/72m1bvd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T10:30:00+00:00

W sercu województwa kujawsko-pomorskiego, nad brzegiem Dużego Jeziora Żnińskiego, kryje się wyjątkowe miejsce, które łączy historyczny urok z nowoczesnymi udogodnieniami. Cukrownia Żnin, zaaranżowana w postindustrialnych wnętrzach dawnej fabryki cukru, przyciąga miłośników historii, nowoczesnych i designerskich wnętrz oraz natury. Obiekt otoczony jest rozległym zielonym terenem, idealnym do spacerowania i aktywnego wypoczynku. Co więcej? Cukrownia Żnin wraz z serwisem Triverna.pl przygotowali specjalne ceny dla gości dokonujących rezerwacji poprzez linki zamieszczone w poniższym artykule. Serdecznie zapraszamy!

## Jest nowy prezes kluczowej instytucji dla polskiego lotnictwa
 - [https://businessinsider.com.pl/wiadomosci/ulc-ma-nowego-prezesa-poprzedni-odszedl-po-osmiu-latach/h9let4l](https://businessinsider.com.pl/wiadomosci/ulc-ma-nowego-prezesa-poprzedni-odszedl-po-osmiu-latach/h9let4l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T10:27:15+00:00

Premier Donald Tusk, na wniosek ministra infrastruktury Dariusza Klimczaka, powołał Juliana Rottera na stanowisko p.o. prezesa Urzędu Lotnictwa Cywilnego (ULC) — poinformowało we wtorek Ministerstwo Infrastruktury.

## NIK skontroluje... KNF. Chodzi o VeloBank
 - [https://businessinsider.com.pl/finanse/nik-skontroluje-knf-chodzi-o-velobank/1g50ztk](https://businessinsider.com.pl/finanse/nik-skontroluje-knf-chodzi-o-velobank/1g50ztk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:47:38+00:00

Najwyższa Izba Kontroli (NIK) zapowiedziała doraźną kontrolę w Komisji Nadzoru Finansowego (KNF). Jak wynika z komunikatu Izby, skoncentruje się na działaniach związanych z VeloBankiem.

## Oto nowi "królowie" warzywnej drożyzny
 - [https://businessinsider.com.pl/poradnik-finansowy/oto-nowi-krolowie-warzywnej-drozyzny/pd3lmd6](https://businessinsider.com.pl/poradnik-finansowy/oto-nowi-krolowie-warzywnej-drozyzny/pd3lmd6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:42:03+00:00

W zeszłym roku o tej porze ceny niektórych nowalijek wręcz eksplodowały. Jak jest dzisiaj? Eksperci z największej hurtowni owocowo-warzywnej w kraju mają głównie optymistyczne wieści. Jednocześnie ostrzegają, że ceny dwóch artykułów nieprzyjemnie ich zaskoczyły.

## PZU i PFR chcą zmian w Banku Pekao. Tutaj miotła kadrowa dotarła z opóźnieniem
 - [https://businessinsider.com.pl/gielda/wiadomosci/do-tej-panstwowej-spolki-kadrowa-miotla-dociera-dopiero-teraz-szykuja-sie-roszady/t0642s4](https://businessinsider.com.pl/gielda/wiadomosci/do-tej-panstwowej-spolki-kadrowa-miotla-dociera-dopiero-teraz-szykuja-sie-roszady/t0642s4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:38:05+00:00

Dwaj główni akcjonariusze Banku Pekao zgłosili kandydatów do rady nadzorczej. Walne zgromadzenie, które m.in. dokona roszad w tym gremium, odbędzie się w środę. Kolejnym krokiem prawdopodobnie będzie wymiana zarządu.

## Nietypowe posiedzenie rządu. Na nim m.in. generałowie i szef BBN
 - [https://businessinsider.com.pl/wiadomosci/niezwykle-posiedzenie-rzadu-na-nim-min-szef-bbn-i-szef-sztabu-generalnego/sb3803b](https://businessinsider.com.pl/wiadomosci/niezwykle-posiedzenie-rzadu-na-nim-min-szef-bbn-i-szef-sztabu-generalnego/sb3803b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:36:21+00:00

Premier Donald Tusk otwierając obrady rządu, poinformował, że dziś posiedzenie rządu będzie "nietypowe". Jego pierwsza część będzie poświęcona m.in. narastającemu konfliktowi na Bliskim Wschodzie. Dlatego - jak wskazał Tusk - zostali zaproszeni szef BBN Jacek Siewiera, szef Sztabu Generalnego WP gen. Wiesław Kukuła i dowódca operacyjny Rodzajów Sił Zbrojnych gen. dyw. Maciej Klisz.

## Rozbudowa ważnej autostrady pod znakiem zapytania? Mieszkańcy jej nie chcą
 - [https://businessinsider.com.pl/gospodarka/rozbudowa-waznej-autostrady-pod-znakiem-zapytania-mieszkancy-jej-nie-chca/r0yyy45](https://businessinsider.com.pl/gospodarka/rozbudowa-waznej-autostrady-pod-znakiem-zapytania-mieszkancy-jej-nie-chca/r0yyy45)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:36:19+00:00

Generalna Dyrekcja Dróg Krajowych i Autostrad (GDDKiA) zaproponowała rozbudowę autostrady A4 od Wrocławia do Legnicy. Dobry pomysł? Niekoniecznie. Zmianom sprzeciwiają się mieszkańcy i Dolnośląski Urzęd Wojewódzki.

## Niezapomniane chwile w designerskich i postindustrialnych wnętrzach nad jeziorem. Specjalne ceny
 - [https://businessinsider.com.pl/lifestyle/podroze/niezapomniane-chwile-w-designerskich-i-postindustrialnych-wnetrzach-nad-jeziorem/72m1bvd](https://businessinsider.com.pl/lifestyle/podroze/niezapomniane-chwile-w-designerskich-i-postindustrialnych-wnetrzach-nad-jeziorem/72m1bvd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:30:00+00:00

W sercu województwa kujawsko-pomorskiego, nad brzegiem Dużego Jeziora Żnińskiego, kryje się wyjątkowe miejsce, które łączy historyczny urok z nowoczesnymi udogodnieniami. Cukrownia Żnin, zaaranżowana w postindustrialnych wnętrzach dawnej fabryki cukru, przyciąga miłośników historii, nowoczesnych i designerskich wnętrz oraz natury. Obiekt otoczony jest rozległym zielonym terenem, idealnym do spacerowania i aktywnego wypoczynku. Co więcej? Cukrownia Żnin wraz z serwisem Triverna.pl przygotowali specjalne ceny dla gości dokonujących rezerwacji poprzez linki zamieszczone w poniższym artykule. Serdecznie zapraszamy!

## Bartłomiej Obajtek został zwolniony dyscyplinarnie. Znamy powody
 - [https://businessinsider.com.pl/wiadomosci/bartlomiej-obajtek-zostal-zwolniony-dyscyplinarnie-znamy-powody/65y7nhr](https://businessinsider.com.pl/wiadomosci/bartlomiej-obajtek-zostal-zwolniony-dyscyplinarnie-znamy-powody/65y7nhr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:26:16+00:00

Bartłomiej Obajtek, były dyrektor generalny Lasów Państwowych i prywatnie brat Daniela Obajtka, został w połowie stycznia odwołany. Teraz okazuje się, że było to zwolnienie dyscyplinarne. Taką informację przekazał Wirtualnej Polsce wiceminister klimatu Mikołaj Dorożała.

## Pożar zabytkowej Starej Giełdy Papierów Wartościowych
 - [https://businessinsider.com.pl/wiadomosci/pozar-zabytkowej-starej-gieldy-papierow-wartosciowych/dprh57k](https://businessinsider.com.pl/wiadomosci/pozar-zabytkowej-starej-gieldy-papierow-wartosciowych/dprh57k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:25:13+00:00

We wtorek rano wybuchł pożar w zabytkowym gmachu Starej Giełdy Papierów Wartościowych w Kopenhadze. Jest to jeden z najstarszych i najbardziej charakterystycznych budynków stolicy Danii.

## Jest nowa opinia w sprawie Sebastiana M. Może zmienić zarzuty na poważniejsze
 - [https://businessinsider.com.pl/wiadomosci/jest-nowa-opinia-w-sprawie-sebastiana-m-moze-zmienic-zarzuty-na-powazniejsze/m4fw2vg](https://businessinsider.com.pl/wiadomosci/jest-nowa-opinia-w-sprawie-sebastiana-m-moze-zmienic-zarzuty-na-powazniejsze/m4fw2vg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:19:22+00:00

Prokuratura w Piotrkowie Trybunalskim (województwo łódzkie) otrzymała dodatkową opinię biegłego dotyczącą tragicznego wypadku na autostradzie A1, w wyniku którego zginęło małżeństwo wraz z pięcioletnim dzieckiem. Informację potwierdziła portalowi tvn24.pl rzeczniczka Prokuratury Krajowej, prokurator Anna Adamiak. Opinia ta może wpłynąć na zmianę zarzutów.

## Auchan w Rosji kupiony przez 23-latka. Sieć w końcu opuszcza listę wstydu
 - [https://businessinsider.com.pl/wiadomosci/auchan-w-rosji-kupiony-przez-23-latka-siec-w-koncu-opuszcza-liste-wstydu/xv9vddw](https://businessinsider.com.pl/wiadomosci/auchan-w-rosji-kupiony-przez-23-latka-siec-w-koncu-opuszcza-liste-wstydu/xv9vddw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:16:24+00:00

Firma Ceetrus, należąca do francuskiej grupy Auchan, która po inwazji Kremla na Ukrainę widniała na "listach wstydu" w Rosji, w końcu sprzedała swoje aktywa w tym kraju. Kupił je 23-letni Rosjanin.

## Plan robót geologicznych dla pierwszej elektrowni jądrowej zatwierdzony
 - [https://businessinsider.com.pl/gospodarka/plan-robot-geologicznych-dla-pierwszej-elektrowni-jadrowej-zatwierdzony/sqsjske](https://businessinsider.com.pl/gospodarka/plan-robot-geologicznych-dla-pierwszej-elektrowni-jadrowej-zatwierdzony/sqsjske)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:15:43+00:00

Polskie Elektrownie Jądrowe, które są odpowiedzialne za budowę pierwszej w kraju elektrowni jądrowej, mają już zatwierdzony projekt robót geologicznych dla tej inwestycji. Prace geologiczne ruszą w maju.

## Wielki strajk dziennikarzy w Grecji. "Zbyt skromne zarobki"
 - [https://businessinsider.com.pl/gospodarka/wielki-strajk-dziennikarzy-w-grecji-zbyt-skromne-zarobki/zp1lg92](https://businessinsider.com.pl/gospodarka/wielki-strajk-dziennikarzy-w-grecji-zbyt-skromne-zarobki/zp1lg92)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:14:56+00:00

Grecki sektor medialny zanurzył się we wtorek w 24-godzinny strajk, z dziennikarzami domagającymi się lepszych warunków pracy — donosi lokalny portal eKathimerini. Wśród strajkujących są pracownicy agencji informacyjnej AMNA.

## Tak zyskaliśmy na wejściu do UE. Polska trafiła do czołówki
 - [https://businessinsider.com.pl/gospodarka/makroekonomia/polska-w-ue-bilans-zyskow-daje-nam-pozycje-lidera/cmvx05j](https://businessinsider.com.pl/gospodarka/makroekonomia/polska-w-ue-bilans-zyskow-daje-nam-pozycje-lidera/cmvx05j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T09:10:52+00:00

Dla państw naszego regionu wejście do Unii Europejskiej to olbrzymi sukces gospodarczy i społeczny. Polska i Litwa są największymi beneficjentami dołączenia dwie dekady temu do europejskiej wspólnoty – wynika z raportu Polskiego Instytutu Ekonomicznego, który poznał Business Insider Polska. Dzięki unijnej akcesji naszego PKB na głowę mieszkańca jest aż o 40 proc. wyższe niż gdybyśmy pozostali poza UE.

## W końcu ruszy e-rejestracja. Ale nie wszędzie naraz
 - [https://businessinsider.com.pl/wiadomosci/w-koncu-ruszy-e-rejestracja-ale-nie-wszedzie-naraz/0pe80dm](https://businessinsider.com.pl/wiadomosci/w-koncu-ruszy-e-rejestracja-ale-nie-wszedzie-naraz/0pe80dm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T08:36:09+00:00

Umawianie się do lekarzy ma być łatwiejsza, a pomoże w tym e-rejestracja. Jej wdrażanie będzie jednak stopniowe. Minister zdrowia Izabela Leszczyna przekazała, że pierwsze elementy e-rejestracji zamierza wprowadzić od 1 czerwca.

## Złoty w odwrocie, giełda traci. Globalne rynki finansowe znalazły się w istotnym punkcie
 - [https://businessinsider.com.pl/gielda/wiadomosci/minorowe-nastroje-na-rynkach-zloty-w-odwrocie-gielda-i-obligacje-traca/q3g48r1](https://businessinsider.com.pl/gielda/wiadomosci/minorowe-nastroje-na-rynkach-zloty-w-odwrocie-gielda-i-obligacje-traca/q3g48r1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T08:32:34+00:00

Złoty osłabiał się we wtorek rano wobec dolara. To piąta z rzędu sesja, gdy nasza waluta traci. To jednak głównie efekt wzmocnienia "zielonego", korzystającego na zwiększonej awersji do ryzyka i poszukiwania przez globalny kapitał bezpiecznych przystani. Negatywnie odbija się to także na rynkach akcji, w tym na notowaniach czołowych indeksów z GPW.

## Paliwa niskiej jakości ratunkiem dla Rosji. Tak Kreml chce zaspokoić sezonowy popyt
 - [https://businessinsider.com.pl/wiadomosci/paliwo-niskiej-jakosci-ratunkiem-dla-rosji-tak-kreml-chce-zaspokoic-sezonowy-popyt/lsr9tpy](https://businessinsider.com.pl/wiadomosci/paliwo-niskiej-jakosci-ratunkiem-dla-rosji-tak-kreml-chce-zaspokoic-sezonowy-popyt/lsr9tpy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T08:11:52+00:00

Rząd Rosji rozważa możliwość złagodzenia rygorystycznych norm środowiskowych dotyczących paliw, aby umożliwić stosowanie benzyny niskiej jakości — donosi Reuters. W ten sposób Kreml mógłby zapobiec niedostatkom paliwa w sezonie po tym, jak Ukraińcy ostrzelali rosyjskie rafinerie. Taka benzyna może jednak niszczyć nowoczesne pojazdy.

## Emerytura od 67. roku życia? "To niezbędne"
 - [https://businessinsider.com.pl/praca/emerytury/emerytura-od-67-roku-zycia-to-niezbedne/4jxtt5x](https://businessinsider.com.pl/praca/emerytury/emerytura-od-67-roku-zycia-to-niezbedne/4jxtt5x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T08:03:36+00:00

To politycznie bardzo trudny temat, ale przy kurczących się zasobach na rynku pracy jest to niezbędne — uważa dyrektorka Instytutu Statystyki i Demografii SGH prof. Agnieszka Chłoń-Domińczak.

## Masz dochody z giełdy? Nie popełnij tych błędów, rozliczając PIT za 2023 r.
 - [https://businessinsider.com.pl/prawo/podatki/masz-dochody-z-gieldy-uniknij-bledow-w-pit-38-bo-moga-cie-sporo-kosztowac/vc5k2j2](https://businessinsider.com.pl/prawo/podatki/masz-dochody-z-gieldy-uniknij-bledow-w-pit-38-bo-moga-cie-sporo-kosztowac/vc5k2j2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T08:00:00+00:00

Masz dochody z giełdy lub funduszy, dostałeś PIT-8C i musisz rozliczyć się w PIT-38? Uważaj na to, co wpisujesz w PIT, bo choć zmieniły się przepisy, to do rozliczeń za 2023 r. nadal trzeba stosować stare regulacje. Bazowanie na PIT-8C też może być błędem. Tłumaczymy, jak uniknąć wpadek, rozliczając dochody i straty m.in. z giełdy i funduszy w 2023 r.

## Zaskoczenie z Chin. Ale nie jest tak różowo w drugiej co do wielkości gospodarce świata
 - [https://businessinsider.com.pl/gospodarka/zaskoczenie-z-chin-ale-nie-jest-tak-rozowo-u-gospodarczego-wicelidera-swiata/dtnb15f](https://businessinsider.com.pl/gospodarka/zaskoczenie-z-chin-ale-nie-jest-tak-rozowo-u-gospodarczego-wicelidera-swiata/dtnb15f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T07:39:56+00:00

Zamiast spowolnić — jak wskazywały prognozy — chińska gospodarka w pierwszych trzech miesiącach tego roku przyśpieszyła. Ale struktura danych nie napawa już takim optymizmem, choć ekonomiści przyznają, że oczekiwania na cały rok były ustawione zbyt nisko i może nas teraz czekać rewizja prognoz w górę.

## Auchan zdetronizowany po wielu miesiącach. Jest nowy najtańszy sklep w Polsce
 - [https://businessinsider.com.pl/wiadomosci/auchan-zdetronizowany-jest-nowy-najtanszy-sklep-w-polsce/jpsr1gz](https://businessinsider.com.pl/wiadomosci/auchan-zdetronizowany-jest-nowy-najtanszy-sklep-w-polsce/jpsr1gz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T07:21:27+00:00

Według koszyka firmy ASM Sales Force Agency Auchan w marcu nie był już najtańszym sklepem w Polsce. Ogółem w siedmiu sieciach ceny skoczyły, a w sześciu były niższe niż w lutym.

## Polacy wciąż są nieświadomi tego, co czeka ich finanse. "Najwyższa pora się zainteresować"
 - [https://businessinsider.com.pl/gospodarka/polacy-wciaz-to-bagatelizuja-najwyzsza-pora-sie-zainteresowac/896h8lv](https://businessinsider.com.pl/gospodarka/polacy-wciaz-to-bagatelizuja-najwyzsza-pora-sie-zainteresowac/896h8lv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T06:28:25+00:00

25 proc. Polaków wierzy, że emerytura z ZUS wystarczy im na godne życie, a 21 proc. z nas godzi się na pracę do śmierci. To wnioski z raportu przygotowanego na zlecenie Goldman Sachs TFI. Tylko 54 proc. z nas myśli o tym, co będzie na starość. Problem w tym, że na myśleniu często się kończy. — Dla 30- i 40-latków nadszedł czas, aby zadbać o swoją przyszłą emeryturę — mówi Business Insiderowi Radosław Sosna, executive director w Goldman Sachs TFI.

## Kolejna firma tnie koszty w Polsce. Produkcja ma być przeniesiona do Rumunii
 - [https://businessinsider.com.pl/wiadomosci/kolejna-firma-tnie-koszty-w-polsce-produkcja-ma-byc-przeniesiona-do-rumunii/475630f](https://businessinsider.com.pl/wiadomosci/kolejna-firma-tnie-koszty-w-polsce-produkcja-ma-byc-przeniesiona-do-rumunii/475630f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T06:02:56+00:00

Fabryka opon Michelin w Olsztynie, która jest jednym z największych pracodawców w województwie warmińsko-mazurskim, likwiduje jeden ze swoich wydziałów — informuje portal olsztyn.com.pl. Produkcja opon do aut ciężarowych ma zostać przeniesiona do Rumunii. Nie wszyscy z 500-osobowej załogi stracą jednak pracę.

## Kurs JPY/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-jena-japonskiego-dzisiaj-po-ile-jest-jen-japonski-16-kwietnia-2024-r/0wstyx7](https://businessinsider.com.pl/gielda/kursy-walut/kurs-jena-japonskiego-dzisiaj-po-ile-jest-jen-japonski-16-kwietnia-2024-r/0wstyx7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T06:00:16+00:00

Jadąc do Japonii czy to w celach turystycznych, czy też biznesowych, warto znać aktualny kurs jena (JPY). Z tego artykułu dowiesz się, jaki jest aktualny kurs japońskiej waluty na dzień 16 kwietnia 2024, a także jak kurs zmienia się w ujęciu tygodniowym. Ułatwi to podjąć decyzję, kiedy kupić jeny.

## Rodzice jedynaków mają problem z ulgą w PIT
 - [https://businessinsider.com.pl/prawo/podatki/rodzice-jedynakow-maja-problem-z-ulga-w-pit/7z7m36b](https://businessinsider.com.pl/prawo/podatki/rodzice-jedynakow-maja-problem-z-ulga-w-pit/7z7m36b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:54:01+00:00

Rodzice jedynaków tracą podatkową ulgę, bo ich pensje rosną, a limit dochodów nie zmienia się od lat — podaje"Rzeczpospolita".

## Premier Czech: nie chcę znów widzieć rosyjskich czołgów w moim kraju
 - [https://businessinsider.com.pl/wiadomosci/premier-czech-nie-chce-znow-widziec-rosyjskich-czolgow-w-moim-kraju/9dg5hhp](https://businessinsider.com.pl/wiadomosci/premier-czech-nie-chce-znow-widziec-rosyjskich-czolgow-w-moim-kraju/9dg5hhp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:39:28+00:00

Politycy coraz głośniej mówią, że Rosja nie zatrzyma się na Ukrainie. — W 1968 roku widziałem rosyjskie czołgi na ulicach Pragi i nie chcę ich nigdy więcej ich widzieć — powiedział premier Czech Petr Fiala podczas spotkania z prezydentem USA Joe Bidenem.

## Szykuje się oblężenie zamku w Stobnicy. Znamy termin
 - [https://businessinsider.com.pl/wiadomosci/szykuje-sie-oblezenie-zamku-w-stobnicy-znamy-termin/8z2w3e3](https://businessinsider.com.pl/wiadomosci/szykuje-sie-oblezenie-zamku-w-stobnicy-znamy-termin/8z2w3e3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:25:00+00:00

Słynny — i niezwykle kontrowersyjny — zamek w wielkopolskiej Stobnicy ciągle nie jest ukończony. Właściciele jednak i tak chcą zrobić z niego atrakcję turystyczną. Na maj szykują "pierwsze oblężenie Stobnicy".

## Rząd pod presją w sprawie CPK. Polscy biznesmeni zabrali głos
 - [https://businessinsider.com.pl/wiadomosci/rzad-pod-presja-w-sprawie-cpk-polscy-biznesmeni-zabrali-glos/rny7n1c](https://businessinsider.com.pl/wiadomosci/rzad-pod-presja-w-sprawie-cpk-polscy-biznesmeni-zabrali-glos/rny7n1c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:13:50+00:00

"Choć CPK to projekt kojarzony z partią, której nie do końca po drodze z biznesem, to generalnie jest przez niego popierany — tak wynika z moich rozmów z polskimi przedsiębiorcami. Wadą CPK jest jego silne upolitycznienie" — mówi w rozmowie z "Pulsem Biznesu" Piotr Dębicki, prezes Formiki. Zwolennikiem lotniska jest także m.in. Krzysztof Domarecki, założyciel i główny akcjonariusz Seleny. Nieco inne zdanie ma natomiast Mateusz Juroszek, przewodniczący RN w spółkach Atal i STS.

## Jest coraz gorzej. Depresja pracowników kosztuje miliardy
 - [https://businessinsider.com.pl/praca/jest-coraz-gorzej-depresja-pracownikow-kosztuje-miliardy/mtn8mys](https://businessinsider.com.pl/praca/jest-coraz-gorzej-depresja-pracownikow-kosztuje-miliardy/mtn8mys)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:05:31+00:00

Depresja to coraz większy problem wśród Polaków. Obecnie na chorobę tę cierpi co najmniej cztery miliony naszych rodaków. To wymierne — gigantyczne — koszty wynikające choćby ze zwolnień lekarskich. O problemie pisze "Rzeczpospolita".

## Kurs TRY/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-trypln-16-kwietnia-2024-r/xlt6lb7](https://businessinsider.com.pl/gielda/kursy-walut/kurs-trypln-16-kwietnia-2024-r/xlt6lb7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:50+00:00

Przedstawiamy aktualne notowania kursu liry tureckiej. Oto jak zmienia się kurs liry do polskiego złotego. Warto zapoznać się ze zmianami, by podjąć decyzję, kiedy wymienić walutę, jeśli wybieramy się np na wakacje do tureckich kurortów.

## Kurs HUF/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-hufpln-16-kwietnia-2024-r/1lz5dxx](https://businessinsider.com.pl/gielda/kursy-walut/kurs-hufpln-16-kwietnia-2024-r/1lz5dxx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:45+00:00

Poznaj bieżące notowanie kursu węgierskiego forinta wraz ze zmianami w odniesieniu dziennym i tygodniowym. Poniższe dane dotyczą kursu HUF na dzień 16 kwietnia 2024. Czy złoty wzmacania się, czy traci? Pokazujemy to na wykresie i w danych poniższego artykułu.

## Kurs DKK/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dkkpln-16-kwietnia-2024-r/qjkgby7](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dkkpln-16-kwietnia-2024-r/qjkgby7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:40+00:00

Jeśli potrzebujesz informacji o kursie korony duńskiej, przedstawiamy bieżące notowania. Wczorajszy kurs wynosił 0,57705 zł. Zobacz, jak sytuacja kształtuje się dziś: 16 kwietnia 2024.

## Kurs SEK/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-sekpln-16-kwietnia-2024-r/lzkwknx](https://businessinsider.com.pl/gielda/kursy-walut/kurs-sekpln-16-kwietnia-2024-r/lzkwknx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:35+00:00

Prezentujemy aktualne notowania kursu waluty korony szwedzkiej (SEK) na dzień 16 kwietnia 2024. Warto zwrócić uwagę, że kurs korony może mieć wpływ na ceny importowanych towarów i usług.

## Kurs NOK/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-nokpln-16-kwietnia-2024-r/06b0s4r](https://businessinsider.com.pl/gielda/kursy-walut/kurs-nokpln-16-kwietnia-2024-r/06b0s4r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:25+00:00

Pokazujemy bieżące notowania kursu korony norweskiej oraz zmiany kursu w ujęciu dziennym. Wczoraj kurs NOK wynosił 0,3703 zł. Dzisiejszą zmianę sprawdzisz w poniższym artykule.

## Kurs CZK/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-czkpln-16-kwietnia-2024-r/9h8tx9n](https://businessinsider.com.pl/gielda/kursy-walut/kurs-czkpln-16-kwietnia-2024-r/9h8tx9n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:20+00:00

Przedstawiamy notowania aktualnego kursu waluty CZK z dnia 16 kwietnia 2024. Wczoraj wynosił 0,17015 zł.

## Kurs GBP/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-16-kwietnia-2024-r/gt803cj](https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-16-kwietnia-2024-r/gt803cj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:15+00:00

W tym artykule znajdują się informacje o bieżącym kursie funta brytyjskiego 16 kwietnia 2024. Wczorajszy 5,04245 zł jak zmienił się dziś? Sprawdzisz poniżej.

## Kurs CHF/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-16-kwietnia-2024-r/0jrz38b](https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-16-kwietnia-2024-r/0jrz38b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:10+00:00

Poznaj bieżący kurs franka szwajcarskiego na dzień 16 kwietnia 2024. CHF to waluta, która przede wszystkim interesuje osoby mające kredyt we frankach. Czy polska waluta wzmocniła się, czy osłabła? Wczoraj kurs szwajcarskiej waluty wynosił 4,44375 zł. Jak wygląda dzisiejszy kurs CHF/PLN, sprawdzisz w tym artykule.

## Kurs USD/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-16-kwietnia-2024-r/wskzvxm](https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-16-kwietnia-2024-r/wskzvxm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:05+00:00

Zobacz aktualne notowania waluty USD. Pokazujemy, jak zmienia się kurs amerykańskiej waluty w stosunku do polskiej złotówki. Czy PLN umacnia się, czy słabnie? Wczoraj kurs USD wynosił 4,05135 zł.

## Kurs EUR/PLN 16 kwietnia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-16-kwietnia-2024-r/8s785wt](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-16-kwietnia-2024-r/8s785wt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:02+00:00

Oto bieżący kurs waluty euro na dzień 16 kwietnia 2024. Euro to obecnie najważniejsza waluta w Unii Europejskiej, a od kursu euro uzależniona jest cena wielu importowanych i eksportowanych towarów i produktów. Jak wyglądają jej aktualne notowania oraz ile wynosi wartość względem złotówki? Wczoraj kurs euro wynosił: 4,3045 zł.

## Kredyt na garaż – warunki, opłacalność, jaki wybrać
 - [https://businessinsider.com.pl/poradnik-finansowy/kredyt-na-garaz-jaki-wybrac-ktory-jest-oplacalny/yrwwryr](https://businessinsider.com.pl/poradnik-finansowy/kredyt-na-garaz-jaki-wybrac-ktory-jest-oplacalny/yrwwryr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T05:00:00+00:00

Budowa domu zwykle wiąże się z potrzebą zaciągnięcia kredytu. Czasami w kosztorysie budowy domu przygotowanym dla banku nie zostanie uwzględniony garaż — może to być na przykład przeoczenie lub ktoś planuje wybudować go później. Bywa, że na garaż także potrzeba dodatkowych pieniędzy. Można wtedy wnioskować o udzielenie kredytu lub pożyczki. Które z dostępnych typów finansowania jest najbardziej opłacalne? Czy można otrzymać kredyt hipoteczny na garaż? Jak działa pożyczka hipoteczna?

## Halving bitcoina zachęca do szukania tańszych źródeł prądu. Wyjaśniamy, o co chodzi w tym procesie
 - [https://businessinsider.com.pl/technologie/nowe-technologie/halving-bitcoina-i-jego-kulisy-wyjasniamy-o-co-w-tym-chodzi/bewdjfn](https://businessinsider.com.pl/technologie/nowe-technologie/halving-bitcoina-i-jego-kulisy-wyjasniamy-o-co-w-tym-chodzi/bewdjfn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T04:46:35+00:00

Halving, czyli aktualizacja oprogramowania w blockchainie bitcoin, ma miejsce co cztery lata. W ostatnim czasie, gdy BTC ma już wysokie wyceny, powoduje wielomiliardowe spadki przychodów dla firm, które zajmują się tzw. wydobywaniem bitcoinów, zapewniając płynne funkcjonowanie cyfrowej waluty. Z tego powodu "górnicy" BTC muszą szukać alternatywnych źródeł prądu, aby mieć jak najniższe koszty. Im mniej wydadzą na prąd, tym więcej mogą zarobić.

## Impreza z Mateuszem Morawieckim odwołana. Bilety kosztowały nawet 20 tys. euro
 - [https://businessinsider.com.pl/wiadomosci/impreza-z-mateuszem-morawieckim-odwolana-bilety-kosztowaly-nawet-20-tys-euro/5rkn5pn](https://businessinsider.com.pl/wiadomosci/impreza-z-mateuszem-morawieckim-odwolana-bilety-kosztowaly-nawet-20-tys-euro/5rkn5pn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T04:45:44+00:00

Konferencja, na której głównym mówcą miał być były polski premier Mateusz Morawiecki, w ostatniej chwili została wyrzucona ze słynnej sali w sercu Brukseli. O sprawie we wtorek pisze "Rzeczpospolita".

## Podatki od nieruchomości znów w górę? Cios we flipperów również uderzy w nabywców [ANALIZA]
 - [https://businessinsider.com.pl/prawo/podatki/kiedy-i-jaki-podatek-od-nieruchomosci-trzeba-zaplacic-uwazaj-zwlaszcza-przy-najmie/jsz5v5q](https://businessinsider.com.pl/prawo/podatki/kiedy-i-jaki-podatek-od-nieruchomosci-trzeba-zaplacic-uwazaj-zwlaszcza-przy-najmie/jsz5v5q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T04:35:50+00:00

Cokolwiek dzieje się z nieruchomością, to fiskus chce mieć w tym swój udział. Podatki trzeba bowiem płacić przy nabyciu, użytkowaniu, najmie i sprzedaży. Zasadniczo podatki spadają na właścicieli, a ci przerzucają je na korzystających. Podwyżka dla flipperów również uderzy w nabywców. Zdaniem ekspertów, nie tędy więc droga. Potrzebne jest też wsparcie dla podatników.

## Podatki od nieruchomości znów w górę? Cios we flipperów również uderzy w nabywców [ANALIZA]
 - [https://businessinsider.com.pl/prawo/podatki/takie-podatki-placimy-od-nieruchomosci-w-polsce-to-malo/jsz5v5q](https://businessinsider.com.pl/prawo/podatki/takie-podatki-placimy-od-nieruchomosci-w-polsce-to-malo/jsz5v5q)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T04:35:50+00:00

Cokolwiek dzieje się z nieruchomością, to fiskus chce mieć w tym swój udział. Podatki trzeba bowiem płacić przy nabyciu, użytkowaniu, najmie i sprzedaży. Zasadniczo podatki spadają na właścicieli, a ci przerzucają je na korzystających. Podwyżka dla flipperów również uderzy w nabywców. Zdaniem ekspertów, nie tędy więc droga. Potrzebne jest też wsparcie dla podatników.

## Koniec eldorado jednej branży. Zwolnienia pracowników
 - [https://businessinsider.com.pl/praca/koniec-eldorado-jednej-branzy-zwolnienia-pracownikow/jej3w7j](https://businessinsider.com.pl/praca/koniec-eldorado-jednej-branzy-zwolnienia-pracownikow/jej3w7j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T04:20:02+00:00

Jeszcze do niedawna branża IT radziła sobie świetnie. Teraz sytuacja jest w odwrocie. Długi firm informatycznych rosną, a specjaliści coraz częściej są zwalniani — podaje "Rzeczpospolita".

## Polacy nieświadomi emerytalnego kataklizmu. "Leci meteoryt, którego nie chcemy widzieć"
 - [https://businessinsider.com.pl/gospodarka/polacy-nieswiadomi-emerytalnego-kataklizmu-meteoryt-ktorego-nie-chcemy-widziec-sondaz/wv553gt](https://businessinsider.com.pl/gospodarka/polacy-nieswiadomi-emerytalnego-kataklizmu-meteoryt-ktorego-nie-chcemy-widziec-sondaz/wv553gt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T04:16:00+00:00

Polacy nie mają pojęcia, jakich świadczeń mogą spodziewać się na emeryturze. A jeśli już wydaje im się, że wiedzą, to przewidywania te nie mają nic wspólnego z rzeczywistością — wynika z badania przeprowadzonego przez UCE Research dla Business Insider Polska. — Leci na nas meteoryt, którego nie chcemy widzieć — tak płynące z niego wnioski komentuje dr Antoni Kolek, prezes Instytutu Emerytalnego.

## Nie tylko droga ropa. Tak wojnę Izraela z Iranem odczujemy w Polsce
 - [https://businessinsider.com.pl/gospodarka/nie-tylko-droga-ropa-tak-wojne-izraela-z-iranem-odczujemy-w-polsce/jqntfs7](https://businessinsider.com.pl/gospodarka/nie-tylko-droga-ropa-tak-wojne-izraela-z-iranem-odczujemy-w-polsce/jqntfs7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T04:15:00+00:00

Eskalacja konfliktu na Bliskim Wschodzie znacznie zwiększa ryzyko, że ceny ropy poszybują. Choć ani Izrael, ani tym bardziej Iran nie są kluczowymi partnerami handlowymi Polski, to wojna może przełożyć się również na nasze portfele. Eksperci wskazują, że odczujemy ją nie tylko poprzez wyższe ceny na stacjach paliw.

## Ta zmiana dotknie milionów Polaków. Chodzi o ZUS od umów-zleceń. Znamy termin reformy
 - [https://businessinsider.com.pl/prawo/praca/to-pewne-umowy-zlecenia-beda-ozusowane-juz-od-2025-r/jhpl8pc](https://businessinsider.com.pl/prawo/praca/to-pewne-umowy-zlecenia-beda-ozusowane-juz-od-2025-r/jhpl8pc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-04-16T04:05:00+00:00

Ta rewolucja była zapowiadana już od kilku lat, ale żaden rząd jej nie przeprowadził. Teraz nie ma od niej ucieczki. Chodzi o ozusowanie wszystkich umów-zleceń. Ministerstwo Funduszy i Rozwoju Regionalnego potwierdził Business Insider Polska, że reforma w tym zakresie jest utrzymana w Krajowym Planie Odbudowy bez zmian. Ma wejść w życie 1 stycznia 2025 r.

