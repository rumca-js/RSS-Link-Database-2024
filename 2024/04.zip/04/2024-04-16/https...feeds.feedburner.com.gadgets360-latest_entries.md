# Source:Gadgets 360, URL:https://feeds.feedburner.com/gadgets360-latest, language:en

## Next Gen Brand Infinix Invites You to Take Charge! Unveiling the Infinix Note 40 Pro 5G Series With Groundbreaking Charging Tech
 - [https://www.gadgets360.com/mobiles/sponsored/next-gen-brand-infinix-invites-you-to-take-charge-unveiling-the-infinix-note-40-pro-5g-series-with-groundbreaking-charging-tech-5457401](https://www.gadgets360.com/mobiles/sponsored/next-gen-brand-infinix-invites-you-to-take-charge-unveiling-the-infinix-note-40-pro-5g-series-with-groundbreaking-charging-tech-5457401)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T17:43:42+00:00

‍‍‍‍‍‍

## Motorola Edge 50 Ultra, Edge 50 Fusion With 50-Megapixel Main Cameras Launched: Price, Specifications
 - [https://www.gadgets360.com/mobiles/news/motorola-edge-50-ultra-fusion-launch-price-specifications-features-5455447](https://www.gadgets360.com/mobiles/news/motorola-edge-50-ultra-fusion-launch-price-specifications-features-5455447)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T14:06:44+00:00

Motorola Edge 50 Ultra (left), Edge 50 Fusion (right) come with IP68 ratings

## Metaverse Experience Centre With VR, AR and Immersive Technologies Launched in Noida
 - [https://www.gadgets360.com/cryptocurrency/news/metaverse-experience-centre-launch-noida-ar-vr-immersive-technologies-5456016](https://www.gadgets360.com/cryptocurrency/news/metaverse-experience-centre-launch-noida-ar-vr-immersive-technologies-5456016)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T13:57:19+00:00

The Metaverse Experience Centre to serve as a hotspot for R&D around virtual ecosystems

## YouTube Confirms “Appropriate Action” on Third-Party Ad-Blocking Apps in Renewed Crackdown
 - [https://www.gadgets360.com/apps/news/youtube-to-take-action-against-revanced-third-party-ad-blocking-apps-5455868](https://www.gadgets360.com/apps/news/youtube-to-take-action-against-revanced-third-party-ad-blocking-apps-5455868)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T13:56:40+00:00

YouTube urged users to subscribe to YouTube Premium for an ad-free experience

## Haier S800QT 4K QLED Smart TV Series With 120Hz Refresh Rate Launched in India: Price, Specifications
 - [https://www.gadgets360.com/tv/news/haier-s800qt-qled-tv-price-india-launch-specifications-features-5455820](https://www.gadgets360.com/tv/news/haier-s800qt-qled-tv-price-india-launch-specifications-features-5455820)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T13:49:02+00:00

Haier S800Q QLED smart TV models are bundled with a Bluetooth voice remote control

## Elon Musk Confirms Plans to Charge New Users on X a ‘Small Fee’ Before They Can Write Posts
 - [https://www.gadgets360.com/social-networking/news/elon-musk-x-new-users-fee-write-posts-like-bookmark-reply-5455589](https://www.gadgets360.com/social-networking/news/elon-musk-x-new-users-fee-write-posts-like-bookmark-reply-5455589)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T13:34:42+00:00

Earlier, new X users in New Zealand and the Philippines were reportedly being charged to write posts

## Crypto Tax Compliance in India 'Very Low', Clearances Imperative to Gain Government's Trust: Taxnodes CEO
 - [https://www.gadgets360.com/cryptocurrency/news/crypto-tax-compliance-low-clearances-imperative-taxnodes-ceo-5455475](https://www.gadgets360.com/cryptocurrency/news/crypto-tax-compliance-low-clearances-imperative-taxnodes-ceo-5455475)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T12:40:20+00:00

India collects one percent TDS on each crypto transaction

## Google's Next Foldable to Be Reportedly Called Pixel 9 Pro Fold
 - [https://www.gadgets360.com/mobiles/news/google-pixel-9-pro-fold-2-renaming-specifications-report-5455190](https://www.gadgets360.com/mobiles/news/google-pixel-9-pro-fold-2-renaming-specifications-report-5455190)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T12:40:06+00:00

Google's Pixel 9 series might include four models this year

## Instagram Said to Be Testing AI-Powered Chatbots for Influencers That Can Interact With Followers
 - [https://www.gadgets360.com/apps/news/instagram-testing-ai-chatbots-for-influencers-creator-ai-report-5454616](https://www.gadgets360.com/apps/news/instagram-testing-ai-chatbots-for-influencers-creator-ai-report-5454616)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T12:04:56+00:00

Reportedly the AI will use influencers’ data to copy the way they speak

## Moto G64 First Impressions: No Big Improvements
 - [https://www.gadgets360.com/mobiles/reviews/moto-g64-first-impressions-5452477](https://www.gadgets360.com/mobiles/reviews/moto-g64-first-impressions-5452477)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T11:53:45+00:00

Moto G64 5G is available in three colour options (Pictured: Mint Green)

## iQoo Z9, iQoo Z9x, iQoo Z9 Turbo Specifications Leaked Ahead of April 24 Launch
 - [https://www.gadgets360.com/mobiles/news/iqoo-z9x-turbo-series-launch-april-24-specifications-report-5454464](https://www.gadgets360.com/mobiles/news/iqoo-z9x-turbo-series-launch-april-24-specifications-report-5454464)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T11:34:58+00:00

iQoo Z9, iQoo Z9x, iQoo Z9 Turbo are said to pack dual rear cameras

## Redmi Pad SE Confirmed to Launch in India on April 23; Design, Key Features Teased
 - [https://www.gadgets360.com/tablets/news/redmi-pad-se-india-launch-date-design-specifications-features-5454309](https://www.gadgets360.com/tablets/news/redmi-pad-se-india-launch-date-design-specifications-features-5454309)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T11:31:58+00:00

Redmi Pad SE is teased in green, green and lavender colourways

## Baidu Claims Ernie Bot Garnered Over 200 Million Users Amid Rising Competition
 - [https://www.gadgets360.com/ai/news/baidu-ernie-bot-ai-chatbot-millions-users-rising-competition-5454858](https://www.gadgets360.com/ai/news/baidu-ernie-bot-ai-chatbot-millions-users-rising-competition-5454858)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T11:25:04+00:00

Ernie Bot was launched by Baidu eight months ago

## Adobe Explores OpenAI Partnership as It Adds Firefly AI to Premiere Pro Video Tools
 - [https://www.gadgets360.com/ai/news/adobe-openai-sora-partnership-add-ai-video-tools-5454627](https://www.gadgets360.com/ai/news/adobe-openai-sora-partnership-add-ai-video-tools-5454627)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T11:04:59+00:00

Adobe recently previewed new features coming to Premiere Pro powered by its Firefly AI

## Adobe Premiere Pro to Get Support for New Generative AI-Powered Video Editing Tools
 - [https://www.gadgets360.com/ai/news/adobe-premiere-pro-ai-video-editing-tools-openai-sora-5454033](https://www.gadgets360.com/ai/news/adobe-premiere-pro-ai-video-editing-tools-openai-sora-5454033)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T10:20:33+00:00

Adobe's new Premiere Pro features could arrive later this year

## Oppo A1s, Oppo A1i With MediaTek Dimensity 6020 Chips, 5,000mAh Batteries Launched: Price, Specifications
 - [https://www.gadgets360.com/mobiles/news/oppo-a1s-a1i-price-launch-sale-date-specifications-features-5453329](https://www.gadgets360.com/mobiles/news/oppo-a1s-a1i-price-launch-sale-date-specifications-features-5453329)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T09:51:56+00:00

Oppo A1s comes in Dusk Mountain Purple, Night Sea Black and Tianshuibi (green) colourways

## Google Pixel 9 User Interface for Purported iPhone 15-Like Satellite Connectivity Feature Leaked: See Video
 - [https://www.gadgets360.com/mobiles/news/google-pixel-9-pro-satellite-connection-ui-interface-video-leak-5453629](https://www.gadgets360.com/mobiles/news/google-pixel-9-pro-satellite-connection-ui-interface-video-leak-5453629)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T09:04:49+00:00

Google will reportedly partner with T-Mobile to offer satellite connectivity features

## Limitless AI Pendant With AI-Powered Audio Recording and Transcription Features Launched; Features, Price
 - [https://www.gadgets360.com/wearables/news/limitless-ai-pendant-price-launch-specifications-features-5453480](https://www.gadgets360.com/wearables/news/limitless-ai-pendant-price-launch-specifications-features-5453480)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T08:47:40+00:00

The Limitless AI Pendant supports USB-C charging

## Bharat  Web3 Association Teams Up With Japan's JADA to Boost Sector Growth
 - [https://www.gadgets360.com/cryptocurrency/news/bharat-web3-association-bwa-japan-jada-mou-boost-growth-5453467](https://www.gadgets360.com/cryptocurrency/news/bharat-web3-association-bwa-japan-jada-mou-boost-growth-5453467)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T08:21:25+00:00

Web3 market experts are betting big on Asia’s potential to drive innovation into the sector

## Vivo Y200i Price, Design, Key Features Leak via Certification Sites; Benchmarks Surface on Geekbench
 - [https://www.gadgets360.com/mobiles/news/vivo-y200i-price-design-key-features-leak-geekbench-3c-china-telecom-listing-report-5452028](https://www.gadgets360.com/mobiles/news/vivo-y200i-price-design-key-features-leak-geekbench-3c-china-telecom-listing-report-5452028)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T07:42:35+00:00

Vivo Y200i is expected to succeed the Vivo Y100i (pictured)

## Nothing Phone 2a Gets Additional Camera Improvements and Bug Fixes With Nothing OS 2.5.5 Update
 - [https://www.gadgets360.com/mobiles/news/nothing-phone-2a-os-2-5-5-update-rollout-april-security-patch-changelog-features-5452245](https://www.gadgets360.com/mobiles/news/nothing-phone-2a-os-2-5-5-update-rollout-april-security-patch-changelog-features-5452245)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T07:21:00+00:00

Nothing Phone 2a received multiple updates since its launch in March

## Adobe Unveils Acrobat AI Assistant for PDFs; Can Generate Summaries, Answer Questions
 - [https://www.gadgets360.com/ai/news/adobe-acrobat-ai-assistant-pdf-launched-generate-summary-features-5452614](https://www.gadgets360.com/ai/news/adobe-acrobat-ai-assistant-pdf-launched-generate-summary-features-5452614)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T07:20:37+00:00

The Acrobat AI Assistant can also offer intelligent citations to users

## Samsung One UI 6.1 Update With Galaxy AI Features Coming to Galaxy S22 Series, 2022 Foldables, Tab S8 Series in May
 - [https://www.gadgets360.com/mobiles/news/samsung-one-ui-6-1-s22-fold-flip-4-tab-s8-series-galaxy-ai-features-rollout-may-5452810](https://www.gadgets360.com/mobiles/news/samsung-one-ui-6-1-s22-fold-flip-4-tab-s8-series-galaxy-ai-features-rollout-may-5452810)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T07:12:31+00:00

Samsung Galaxy S22 Ultra (pictured) was launched in February 2022

## Moto G64 5G With 50-Megapixel Camera, MediaTek Dimensity 7025 SoC Launched in India: Price, Specifications
 - [https://www.gadgets360.com/mobiles/news/moto-g64-5g-price-in-india-launch-sale-specifications-features-5452627](https://www.gadgets360.com/mobiles/news/moto-g64-5g-price-in-india-launch-sale-specifications-features-5452627)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T06:50:35+00:00

Moto G64 5G is available in Ice Lilac, Mint Green, and Pearl Blue (pictured) colourways

## Asus Zenbook Duo (2024) With Dual 14-inch OLED Touchscreen Displays Launched in India
 - [https://www.gadgets360.com/laptops/news/asus-zenbook-duo-2024-price-in-india-launch-sale-specifications-features-5452362](https://www.gadgets360.com/laptops/news/asus-zenbook-duo-2024-price-in-india-launch-sale-specifications-features-5452362)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T06:30:10+00:00

Asus Zenbook Duo (2024) has dual OLED touchscreens with 100 percent DCI:P3 colour gamut coverage

## Asus Zenbook Duo 2024 Review: Portable Productivity Powerhouse
 - [https://www.gadgets360.com/laptops/reviews/asus-zenbook-duo-2024-review-5448102](https://www.gadgets360.com/laptops/reviews/asus-zenbook-duo-2024-review-5448102)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T06:16:01+00:00

The Zenbook Duo 2024 in dual display mode is a productivity beast

## Vivo V30e Display, Camera, More Details Surface Online; Said to Launch in India Soon
 - [https://www.gadgets360.com/mobiles/news/vivo-v30e-india-launch-display-camera-battery-specifications-leak-5451806](https://www.gadgets360.com/mobiles/news/vivo-v30e-india-launch-display-camera-battery-specifications-leak-5451806)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-04-16T05:21:44+00:00

Vivo V30 and V30 Pro (pictured) were launched in India in March

