# Source:Screen Junkies, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A, language:en-US

## Honest Trailers | Sherlock Holmes (2009) & Game of Shadows
 - [https://www.youtube.com/watch?v=BAAzW95z7yA](https://www.youtube.com/watch?v=BAAzW95z7yA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A
 - date published: 2024-04-16T17:00:10+00:00

Greetings, vault dweller! And welcome to our complete timeline of the world of Fallout. https://youtu.be/6jD3ALrbjhA

Subscribe to ScreenJunkies! ► https://fandom.link/SJSubscribe

Honest Trailers | Sherlock Holmes (2009) & Game of Shadows
Voice Narration: Jon Bailey aka Epic Voice Guy
Title Design: Robert Holtby
Written by: Spencer Gilbert, Lon Harris
Produced by: Spencer Gilbert
Edited by: Kevin Williamsen
Post-Production Manager: Emin Bassavand
Content Manager: Mikołaj Kossakowski
Post-Production Specialist: Rebecca Castaneda
Director of Video Production: Max Dionne

#honesttrailers #sherlockholmes #movie #trailer

