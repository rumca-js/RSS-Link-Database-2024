# Source:Just Some Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q, language:en-US

## X-Men 97: Remember It
 - [https://www.youtube.com/watch?v=Hu_cC6ufc6Y](https://www.youtube.com/watch?v=Hu_cC6ufc6Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q
 - date published: 2024-04-16T23:30:03+00:00

X-Men 97: Remember It
----------------------------------------------------------------------------------------------
Art and Animation by Just Some Guy

Original trailer concept: FMA Brotherhood & Black Summoner

Music: "Enkon Hakuchuumu" by Sakagami Souichi - Copyright (C) 2015 Trial & Error/Sakagami Souichi All rights reserved.

Trial & Error: http://www.tandess.com/en/music/

