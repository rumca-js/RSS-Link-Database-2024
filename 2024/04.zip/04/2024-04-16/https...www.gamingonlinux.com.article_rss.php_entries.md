# Source:GamingOnLinux Latest Articles, URL:https://www.gamingonlinux.com/article_rss.php, language:en-us

## Free Stars: Children of Infinity, sequel to The Ur-Quan Masters now on Kickstarter
 - [https://www.gamingonlinux.com/2024/04/free-stars-children-of-infinity-sequel-to-the-ur-quan-masters-now-on-kickstarter](https://www.gamingonlinux.com/2024/04/free-stars-children-of-infinity-sequel-to-the-ur-quan-masters-now-on-kickstarter)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-04-16T16:08:46+00:00

Pistol Shrimp Games, founded by Toys for Bob veterans, have today launched the Kickstarter campaign for Free Stars: Children of Infinity which is a direct sequel to The Ur-Quan Masters (Star Control 2).

## PAC-MAN Mega Tunnel Battle: Chomp Champs launches in early May
 - [https://www.gamingonlinux.com/2024/04/pac-man-mega-tunnel-battle-chomp-champs-launches-in-early-may](https://www.gamingonlinux.com/2024/04/pac-man-mega-tunnel-battle-chomp-champs-launches-in-early-may)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-04-16T12:39:40+00:00

I know I'm going to be suckered into PAC-MAN Mega Tunnel Battle: Chomp Champs when it releases on May 8th, after previously being a Stadia exclusive.

## It took about 15 years but epic roguelike Caves of Qud is nearly done
 - [https://www.gamingonlinux.com/2024/04/it-took-about-15-years-but-epic-roguelike-caves-of-qud-is-nearly-done](https://www.gamingonlinux.com/2024/04/it-took-about-15-years-but-epic-roguelike-caves-of-qud-is-nearly-done)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-04-16T12:22:30+00:00

Caves of Qud from developer Freehold Games and publisher Kitfox Games is approaching the 1.0 finishing line, and so their roadmap towards the release has been put up and it sounds really exciting.

## Emulation tool RetroDECK brings in Ryujinx for Nintendo Switch, many other improvements
 - [https://www.gamingonlinux.com/2024/04/emulation-tool-retrodeck-brings-in-ryujinx-for-nintendo-switch-many-other-improvements](https://www.gamingonlinux.com/2024/04/emulation-tool-retrodeck-brings-in-ryujinx-for-nintendo-switch-many-other-improvements)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-04-16T12:05:42+00:00

RetroDECK is one of the simplest options for getting various emulators set up on Steam Deck and Desktop Linux, and the latest release has lots of fun improvements to check out.

## Ubuntu 24.04 LTS (Noble Numbat) Beta released
 - [https://www.gamingonlinux.com/2024/04/ubuntu-2404-lts-noble-numbat-beta-released](https://www.gamingonlinux.com/2024/04/ubuntu-2404-lts-noble-numbat-beta-released)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-04-16T11:51:49+00:00

Canonical is gearing up for the release of the next LTS (long term support) version of Ubuntu, with a first Beta now available for Ubuntu 24.04 LTS (Noble Numbat).

## Descent 3 has been made open source
 - [https://www.gamingonlinux.com/2024/04/descent-3-has-been-made-open-source](https://www.gamingonlinux.com/2024/04/descent-3-has-been-made-open-source)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-04-16T11:26:11+00:00

Another classic has been given the open source treatment, with Descent 3 from Outrage Entertainment now available under the MIT license.

## Half-Life remake Black Mesa has a big upgrade with DXVK 2.3.1, optimizations and bug fixes
 - [https://www.gamingonlinux.com/2024/04/half-life-remake-black-mesa-has-a-big-upgrade-with-dxvk-231-optimizations-and-bug-fixes](https://www.gamingonlinux.com/2024/04/half-life-remake-black-mesa-has-a-big-upgrade-with-dxvk-231-optimizations-and-bug-fixes)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-04-16T08:42:42+00:00

Crowbar Collective have released the Necro Patch for the Half-Life remake Black Mesa, which brings with it some essential bug fixes and some nice optimizations.

## Steam FPS Fest 2024 is live with tons of great discounts
 - [https://www.gamingonlinux.com/2024/04/steam-fps-fest-2024-is-live-with-tons-of-great-discounts](https://www.gamingonlinux.com/2024/04/steam-fps-fest-2024-is-live-with-tons-of-great-discounts)
 - RSS feed: https://www.gamingonlinux.com/article_rss.php
 - date published: 2024-04-16T08:29:52+00:00

Another festival of games is live on Steam now with Steam FPS Fest 2024 running until April 22nd at 10am PT / 5pm UTC, and there's also plenty of demos for games to try too.

