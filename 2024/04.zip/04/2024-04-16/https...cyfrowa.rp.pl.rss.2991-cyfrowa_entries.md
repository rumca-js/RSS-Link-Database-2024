# Source:RP - Cyfrowa, URL:https://cyfrowa.rp.pl/rss/2991-cyfrowa, language:pl-PL

## Sprzedaż iPhone'ów runęła i Apple traci pozycję lidera. Jest nowy król smartfonów
 - [https://cyfrowa.rp.pl/globalne-interesy/art40178301-sprzedaz-iphone-ow-runela-i-apple-traci-pozycje-lidera-jest-nowy-krol-smartfonow](https://cyfrowa.rp.pl/globalne-interesy/art40178301-sprzedaz-iphone-ow-runela-i-apple-traci-pozycje-lidera-jest-nowy-krol-smartfonow)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-04-16T12:14:00+00:00

Początek roku dla koncernu kierowanego przez Tima Cooka jest fatalny. Jak wynika z najnowszych danych IDC, do rąk fanów marki trafiło o jedną dziesiątą mniej smartfonów niż przed rokiem.

## Klikasz i kupujesz to, co widzisz w TV. Pomoże polska sztuczna inteligencja
 - [https://cyfrowa.rp.pl/biznes-ludzie-startupy/art40163371-klikasz-i-kupujesz-to-co-widzisz-w-tv-pomoze-polska-sztuczna-inteligencja](https://cyfrowa.rp.pl/biznes-ludzie-startupy/art40163371-klikasz-i-kupujesz-to-co-widzisz-w-tv-pomoze-polska-sztuczna-inteligencja)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-04-16T05:26:00+00:00

Polski start-up opracował aplikację umożliwiającą zakup produktów, które oglądamy właśnie na ekranie – czy to obserwując program telewizyjny, czy też np. na YouTubie.

## Koniec eldorado w polskim IT. Niższe płace i zwolnienia pracowników
 - [https://cyfrowa.rp.pl/it/art40172881-koniec-eldorado-w-polskim-it-nizsze-place-i-zwolnienia-pracownikow](https://cyfrowa.rp.pl/it/art40172881-koniec-eldorado-w-polskim-it-nizsze-place-i-zwolnienia-pracownikow)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-04-16T02:30:00+00:00

Mocno rosną długi firm informatycznych i listy zwalnianych specjalistów, którzy coraz częściej idą na swoje. Kto najczęściej traci pracę?

## Lawinowo przybywa programistów na swoim. Mają bardzo niepewną przyszłość
 - [https://cyfrowa.rp.pl/it/art40173121-lawinowo-przybywa-programistow-na-swoim-maja-bardzo-niepewna-przyszlosc](https://cyfrowa.rp.pl/it/art40173121-lawinowo-przybywa-programistow-na-swoim-maja-bardzo-niepewna-przyszlosc)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-04-16T01:07:00+00:00

O 16 proc. skoczyła w Polsce w ub.r. liczba firm IT. Tylko w I kwartale 2024 r. przybyło 1,5 tys. takich biznesów – wynika z analiz Dun & Bradstreet dla „Rzeczpospolitej”.

