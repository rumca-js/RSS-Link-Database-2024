# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## What to Watch: New Guy Ritchie Movie, Possessed Ballerina, Spy x Family Movie, & More
 - [https://www.youtube.com/watch?v=ylDZcfodJzM](https://www.youtube.com/watch?v=ylDZcfodJzM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-04-16T22:18:38+00:00

Guy Ritchie is back! Welcome to this week's What to Watch. 'The Ministry of Ungentlemanly Warfare', 'Spy x Family Code: White', and 'Abigail' are in theaters. 'Rebel Moon – Part Two: The Scargiver' is on Netflix, 'Under the Bridge' is on Hulu, and 'The Spiderwick Chronicles' is premiering on Roku. What will you be watching?

► Buy Tickets for The Ministry of Ungentlemanly Warfare: https://www.fandango.com/the-ministry-of-ungentlemanly-warfare-2024-234768/movie-overview?cmp=Trailers_YouTube_Desc
► Buy Tickets for Spy x Family Code: White: https://www.fandango.com/spy-x-family-code-white-2024-234146/movie-overview?cmp=Trailers_YouTube_Desc
► Learn more about Rebel Moon – Part Two: The Scargiver: https://www.rottentomatoes.com/m/rebel_moon_part_2_the_scargiver?cmp=Trailers_YouTube_Desc 
► Learn more about Under the Bridge: https://www.rottentomatoes.com/tv/under_the_bridge_2024?cmp=Trailers_YouTube_Desc 
► Learn more about The Spiderwick Chronicles: https://www.rottentomatoes.com/tv/the_

## You Can't Run Forever Trailer #1 (2024)
 - [https://www.youtube.com/watch?v=ktwVVZIl1nA](https://www.youtube.com/watch?v=ktwVVZIl1nA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-04-16T17:30:47+00:00

Check out the official trailer for You Can't Run Forever starring J.K. Simmons! 
► Visit Fandango: https://www.fandango.com/?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: April 19, 2024
Starring: J.K. Simmons, Fernanda Urrejola, Allen Leech,
Director: Michelle Schumacher
Synopsis: Miranda, a young woman already suffering from acute anxiety due to a past tragedy, faces a new terror when a serial killer chooses her as his new target. In a harrowing hunt through the woods, Miranda finds strength she never knew she had as she tries to elude her murderous tracker. Academy Award® winner J.K. Simmons stars in a spine-chilling thriller about the strength of family and the astonishing power of the human spirit.

► Learn more: https://www.rottentomatoes.com/?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://

## Alien - 45th Anniversary Re-Release Trailer #1 (2024)
 - [https://www.youtube.com/watch?v=S5B3_VxCX_Y](https://www.youtube.com/watch?v=S5B3_VxCX_Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-04-16T16:55:51+00:00

Check out the official re-release trailer for Alien's 45th anniversary directed by Ridley Scott! 
► Buy tickets for Alien on Fandango: http://www.fandango.com/alien-1979-235716/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Re-Release Date: April 26, 2024
Starring: Tom Skerritt, Sigourney Weaver, John Hurt
Director: Ridley Scott
Synopsis: In deep space, the crew of the commercial starship Nostromo is awakened from their cryo-sleep capsules halfway through their journey home to investigate a distress call from an alien vessel. The terror begins when the crew encounters a nest of eggs inside the alien ship. An organism from inside an egg leaps out and attaches itself to one of the crew, causing him to fall into a coma.
► Learn more: https://www.rottentomatoes.com/m/alien?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomato

## The Fall Guy Featurette - In 60 Seconds (2024)
 - [https://www.youtube.com/watch?v=6iyvspCqQbY](https://www.youtube.com/watch?v=6iyvspCqQbY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-04-16T16:25:53+00:00

Check out a behind the scenes featurette for The Fall Guy starring Ryan Gosling! 

► Buy Tickets on Fandango: https://www.fandango.com/the-fall-guy-2024-234088/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: May 3, 2024
Starring: Emily Blunt, Ryan Gosling, Stephanie Hsu, Winston Duke
Director: David Leitch
Synopsis: A former stuntman springs back into action when the star of a new movie goes missing.

► Learn more: https://www.rottentomatoes.com/m/the_fall_guy_2024?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movie

