# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Fanboys will HATE my Console Tier List
 - [https://www.youtube.com/watch?v=SKIXCPn2xB0](https://www.youtube.com/watch?v=SKIXCPn2xB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2024-04-16T19:17:48+00:00

Visit https://www.squarespace.com/LTT and use offer code LTT for 10% off

Save 10% and Free Shipping at Ridge by using offer code LINUS at https://www.ridge.com/LINUS

Console Wars never change.. and we want to enlist on the side of Gamers. Tier Lists are a great way to rate gaming machines and there are PLENTY of rankings to go around. What PlayStation is the greatest of all time? What Xbox sits atop of the rest? Why is Nintendo always changing their naming?

Discuss on the forum: https://linustechtips.com/topic/1566968-fanboys-will-hate-my-console-tier-list/

Buy a PS5: https://geni.us/sqyxv
Buy a PS4: https://geni.us/YUFH
Buy a Nintendo Switch OLED: https://geni.us/GkbzrS0
Buy an Xbox Series X: https://geni.us/sBZdR0
Buy an Xbox Series S: https://geni.us/AZmFJ

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND P

