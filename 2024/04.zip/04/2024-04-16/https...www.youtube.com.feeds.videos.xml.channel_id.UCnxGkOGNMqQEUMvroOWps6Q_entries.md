# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Graham Hancock and Flint Dibble Disagree Over Sphinx Water-Erosion Theory
 - [https://www.youtube.com/watch?v=oITaI2kDIFI](https://www.youtube.com/watch?v=oITaI2kDIFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2024-04-16T17:35:22+00:00

JRE #2136 w/Graham Hancock & Flint Dibble
YouTube: https://youtu.be/iBRl6XECIbM
JRE on Spotify: https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk

