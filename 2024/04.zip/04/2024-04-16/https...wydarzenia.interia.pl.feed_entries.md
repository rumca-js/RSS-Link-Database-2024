# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Nad bazą wojskową w Konstancy krążyły tajemnicze drony
 - [https://wydarzenia.interia.pl/zagranica/news-nad-baza-wojskowa-w-konstancy-krazyly-tajemnicze-drony,nId,7455240](https://wydarzenia.interia.pl/zagranica/news-nad-baza-wojskowa-w-konstancy-krazyly-tajemnicze-drony,nId,7455240)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T19:24:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nad-baza-wojskowa-w-konstancy-krazyly-tajemnicze-drony,nId,7455240"><img align="left" alt="Nad bazą wojskową w Konstancy krążyły tajemnicze drony" src="https://i.iplsc.com/nad-baza-wojskowa-w-konstancy-krazyly-tajemnicze-drony/000IYTLCHCAFCDU5-C321.jpg" /></a>Nad bazą lotniczą rumuńskich sił powietrznych pod Konstancą zaobserwowano w nocy z poniedziałku na wtorek drony - podaje portal News.ro, powołując się na ministerstwo obrony. Jak dodano, drony miały być niewielkich rozmiarów, &quot;najprawdopodobniej typu komercyjnego&quot;. Informacje o zdarzeniu przekazano cywilnym władzom ruchu lotniczego i prokuraturze wojskowej.</p><br clear="all" />

## Są wyniki sekcji zwłok kobiety z Jagatowa. Sprawca wciąż jest poszukiwany
 - [https://wydarzenia.interia.pl/pomorskie/news-sa-wyniki-sekcji-zwlok-kobiety-z-jagatowa-sprawca-wciaz-jest,nId,7455230](https://wydarzenia.interia.pl/pomorskie/news-sa-wyniki-sekcji-zwlok-kobiety-z-jagatowa-sprawca-wciaz-jest,nId,7455230)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T19:20:55+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-sa-wyniki-sekcji-zwlok-kobiety-z-jagatowa-sprawca-wciaz-jest,nId,7455230"><img align="left" alt="Są wyniki sekcji zwłok kobiety z Jagatowa. Sprawca wciąż jest poszukiwany " src="https://i.iplsc.com/sa-wyniki-sekcji-zwlok-kobiety-z-jagatowa-sprawca-wciaz-jest/000IYTLQQN4KHTMP-C321.jpg" /></a>Są wyniki sekcji zwłok zamordowanej 40-letniej kobiety z Jagatowa. Z opinii biegłego wynika, że zmarła ona na skutek wykrwawienia. Nadal trwają poszukiwania męża kobiety, któremu prokuratura postawiła zarzut zabójstwa. </p><br clear="all" />

## Spór o migrację. Premierzy pokłócili się w sieci
 - [https://wydarzenia.interia.pl/kraj/news-spor-o-migracje-premierzy-poklocili-sie-w-sieci,nId,7455224](https://wydarzenia.interia.pl/kraj/news-spor-o-migracje-premierzy-poklocili-sie-w-sieci,nId,7455224)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T18:23:58+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-spor-o-migracje-premierzy-poklocili-sie-w-sieci,nId,7455224"><img align="left" alt="Spór o migrację. Premierzy pokłócili się w sieci" src="https://i.iplsc.com/spor-o-migracje-premierzy-poklocili-sie-w-sieci/000IYTGAOGB71M2E-C321.jpg" /></a>&quot;Mateusz Morawiecki odpowiada jako były premier za sprowadzenie setek tysięcy przybyszów z Afryki i Azji do Polski&quot; - zarzuca Donald Tusk. To reakcja na wcześniejsze wypowiedzi wiceprezesa z PiS, który w Brukseli sugerował, iż &quot;Tusk jest zwolennikiem paktu migracyjnego, najlepszy dowód dał poprzez tzw. unieważnienie referendum&quot;. Morawiecki nie czekał także z ripostą na wpis lidera Platformy Obywatelskiej, zarzucając mu &quot;robienie z Polaków głupków&quot;.</p><br clear="all" />

## Afera z Protasiewiczem. Młoda działaczka przerywa milczenie
 - [https://wydarzenia.interia.pl/kraj/news-afera-z-protasiewiczem-mloda-dzialaczka-przerywa-milczenie,nId,7455203](https://wydarzenia.interia.pl/kraj/news-afera-z-protasiewiczem-mloda-dzialaczka-przerywa-milczenie,nId,7455203)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T18:20:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-afera-z-protasiewiczem-mloda-dzialaczka-przerywa-milczenie,nId,7455203"><img align="left" alt="Afera z Protasiewiczem. Młoda działaczka przerywa milczenie" src="https://i.iplsc.com/afera-z-protasiewiczem-mloda-dzialaczka-przerywa-milczenie/000IYTEH769R35GW-C321.jpg" /></a>Kilkanaście godzin po wybuchu afery związanej z wpisami Jacka Protasiewicza głos w mediach zabrała Daria Brzezicka, o której wspomniał w nagraniach i której zdjęcia pokazał polityk. Młoda działaczka Polskiego Stronnictwa Ludowego ujawniła prawdę o relacji, jaka łączy ją z byłym już wicewojewodą dolnośląskim.</p><br clear="all" />

## Rozdadzą 35,5 tys. darmowych biletów kolejowych. Wystarczy rozwiązać quiz
 - [https://wydarzenia.interia.pl/zagranica/news-rozdadza-35-5-tys-darmowych-biletow-kolejowych-wystarczy-roz,nId,7455213](https://wydarzenia.interia.pl/zagranica/news-rozdadza-35-5-tys-darmowych-biletow-kolejowych-wystarczy-roz,nId,7455213)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T18:20:12+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rozdadza-35-5-tys-darmowych-biletow-kolejowych-wystarczy-roz,nId,7455213"><img align="left" alt="Rozdadzą 35,5 tys. darmowych biletów kolejowych. Wystarczy rozwiązać quiz " src="https://i.iplsc.com/rozdadza-35-5-tys-darmowych-biletow-kolejowych-wystarczy-roz/000IYTE8WR5FRJGL-C321.jpg" /></a>Unia Europejska przekaże młodym ludziom ponad 35 tys. biletów na darmowe podróże koleją po Europie. Osoby w wieku 18 i 19 lat z UE i państw stowarzyszonych będą mogły podczas wakacji skorzystać z programu DiscoverEU. Wystarczy, że poprawnie rozwiążą quiz.</p><br clear="all" />

## Nietypowa interwencja na granicy. Etiopka tuż po porodzie potrzebowała pomocy
 - [https://wydarzenia.interia.pl/podlaskie/news-nietypowa-interwencja-na-granicy-etiopka-tuz-po-porodzie-pot,nId,7455174](https://wydarzenia.interia.pl/podlaskie/news-nietypowa-interwencja-na-granicy-etiopka-tuz-po-porodzie-pot,nId,7455174)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T16:56:49+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-nietypowa-interwencja-na-granicy-etiopka-tuz-po-porodzie-pot,nId,7455174"><img align="left" alt="Nietypowa interwencja na granicy. Etiopka tuż po porodzie potrzebowała pomocy" src="https://i.iplsc.com/nietypowa-interwencja-na-granicy-etiopka-tuz-po-porodzie-pot/000IYT6AUYAISEMW-C321.jpg" /></a>&quot;Dziś funkcjonariusze Straży Granicznej z placówki w Białowieży ujawnili kobietę potrzebującą natychmiastowej pomocy medycznej&quot; - przekazano we wtorkowym komunikacie w mediach społecznościowych. Obywatelka Etiopii kilkanaście godzin wcześniej urodziła córeczkę. Na miejsce konieczne było wezwanie wojskowego ambulansu.</p><br clear="all" />

## Spięcie podczas obrad sejmowej komisji. "Pan tak na serio?"
 - [https://wydarzenia.interia.pl/kraj/news-spiecie-podczas-obrad-sejmowej-komisji-pan-tak-na-serio,nId,7455046](https://wydarzenia.interia.pl/kraj/news-spiecie-podczas-obrad-sejmowej-komisji-pan-tak-na-serio,nId,7455046)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T16:36:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-spiecie-podczas-obrad-sejmowej-komisji-pan-tak-na-serio,nId,7455046"><img align="left" alt="Spięcie podczas obrad sejmowej komisji. &quot;Pan tak na serio?&quot;" src="https://i.iplsc.com/spiecie-podczas-obrad-sejmowej-komisji-pan-tak-na-serio/000IYT4Q1JMHLITJ-C321.jpg" /></a>- Nie mam sobie nic do zarzucenia - stwierdził Łukasz Szumowski, zapytany o swoje postępowanie, gdy podczas epidemii koronawirusa ważyły się losy tzw. wyborów kopertowych. Były minister zdrowia zeznawał we wtorek przed sejmową komisją śledczą. Nie obyło się bez kłótni polityków PiS i KO. Waldemar Buda chwalił Łukasza Szumowskiego za działania z 2020 roku, Dariusz Joński przypominał o pieniądzach za respiratory, których nie było.</p><br clear="all" />

## Dramatyczny wypadek koło Rzeszowa. Tir wjechał w przystanek, są ranni
 - [https://wydarzenia.interia.pl/kraj/news-dramatyczny-wypadek-kolo-rzeszowa-tir-wjechal-w-przystanek-s,nId,7455166](https://wydarzenia.interia.pl/kraj/news-dramatyczny-wypadek-kolo-rzeszowa-tir-wjechal-w-przystanek-s,nId,7455166)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T16:21:54+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dramatyczny-wypadek-kolo-rzeszowa-tir-wjechal-w-przystanek-s,nId,7455166"><img align="left" alt="Dramatyczny wypadek koło Rzeszowa. Tir wjechał w przystanek, są ranni" src="https://i.iplsc.com/dramatyczny-wypadek-kolo-rzeszowa-tir-wjechal-w-przystanek-s/000IYT4ZEPH7J7C6-C321.jpg" /></a>W Tyczynie koło Rzeszowa ciężarówka wjechała w przystanek autobusowy. Wcześniej straciła koło w wyniku zderzenia się z samochodem osobowym marki Hyundai, który zjechał na przeciwny pas ruchu. W pobliżu wiaty przystankowej byli piesi. Pięć osób trafiło do szpitala. Ruch w tym rejonie jest całkowicie zablokowany. </p><br clear="all" />

## "Bitwa o Kraków. Decydujące starcie". Debata Interii. Kandydaci przepraszają... wyborców PiS
 - [https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-bitwa-o-krakow-decydujace-starcie-debata-interii-kandydaci-p,nId,7454902](https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-bitwa-o-krakow-decydujace-starcie-debata-interii-kandydaci-p,nId,7454902)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T15:59:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-bitwa-o-krakow-decydujace-starcie-debata-interii-kandydaci-p,nId,7454902"><img align="left" alt="&quot;Bitwa o Kraków. Decydujące starcie&quot;. Debata Interii. Kandydaci przepraszają... wyborców PiS" src="https://i.iplsc.com/bitwa-o-krakow-decydujace-starcie-debata-interii-kandydaci-p/000IYSE727TKEBCQ-C321.jpg" /></a>Tylko w Interii kandydaci na prezydenta Krakowa zmierzyli się w bezpośrednim starciu. Aleksander Miszalski i Łukasz Gibała w ostrej, ale merytorycznej wymianie zdań starają się odpowiedzieć na pytania naszych dziennikarzy i przekonać niezdecydowanych krakowian, żeby oddali na nich głosy. Przygotowali też niespodziankę. Oto najciekawsze starcie tej kampanii wyborczej! Zobacz debatę &quot;Bitwa o Kraków. Decydujące starcie&quot; poniżej:</p><br clear="all" />

## Michał Tusk ma nową pracę. Wiemy, od kiedy pełni funkcję
 - [https://wydarzenia.interia.pl/kraj/news-michal-tusk-ma-nowa-prace-wiemy-od-kiedy-pelni-funkcje,nId,7454854](https://wydarzenia.interia.pl/kraj/news-michal-tusk-ma-nowa-prace-wiemy-od-kiedy-pelni-funkcje,nId,7454854)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T14:35:53+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-michal-tusk-ma-nowa-prace-wiemy-od-kiedy-pelni-funkcje,nId,7454854"><img align="left" alt="Michał Tusk ma nową pracę. Wiemy, od kiedy pełni funkcję" src="https://i.iplsc.com/michal-tusk-ma-nowa-prace-wiemy-od-kiedy-pelni-funkcje/000IYRBOSNUC5QA5-C321.jpg" /></a>Jak dowiaduje się Interia, od początku kwietnia syn premiera ma nową posadę. Michał Tusk został głównym specjalistą w departamencie infrastruktury Urzędu Marszałkowskiego Województwa Pomorskiego. Jak przebiegała rekrutacja? - Potwierdzam, Michał Tusk jest u nas zatrudniony. Zazwyczaj kandydaci przychodzą do urzędu, mamy dwa etapy rozmów. Wybiera się odpowiednią osobę - powiedział Interii Michał Piotrowski, rzecznik instytucji.</p><br clear="all" />

## Prezydent o spotkaniu z Donaldem Trumpem: Jeśli będzie możliwość
 - [https://wydarzenia.interia.pl/kraj/news-prezydent-o-spotkaniu-z-donaldem-trumpem-jesli-bedzie-mozliw,nId,7454916](https://wydarzenia.interia.pl/kraj/news-prezydent-o-spotkaniu-z-donaldem-trumpem-jesli-bedzie-mozliw,nId,7454916)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T13:30:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydent-o-spotkaniu-z-donaldem-trumpem-jesli-bedzie-mozliw,nId,7454916"><img align="left" alt="Prezydent o spotkaniu z Donaldem Trumpem: Jeśli będzie możliwość" src="https://i.iplsc.com/prezydent-o-spotkaniu-z-donaldem-trumpem-jesli-bedzie-mozliw/000IYRE8XQYL3O6U-C321.jpg" /></a>Andrzej Duda wylatuje na wizytę roboczą do USA. - Jeśli będzie możliwość to tak, towarzysko spotkam się z Donaldem Trumpem - oświadczył prezydent. Polityk przyznał, że &quot;nie jest dla niego niczym nowym spotykanie się z przyjaciółmi, którzy są byłymi prezydentami&quot;. </p><br clear="all" />

## "Bitwa o Kraków. Decydujące starcie". Miszalski i Gibała twarzą w twarz
 - [https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-bitwa-o-krakow-decydujace-starcie-miszalski-i-gibala-twarza-,nId,7454879](https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-bitwa-o-krakow-decydujace-starcie-miszalski-i-gibala-twarza-,nId,7454879)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T13:16:09+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-bitwa-o-krakow-decydujace-starcie-miszalski-i-gibala-twarza-,nId,7454879"><img align="left" alt="&quot;Bitwa o Kraków. Decydujące starcie&quot;. Miszalski i Gibała twarzą w twarz" src="https://i.iplsc.com/bitwa-o-krakow-decydujace-starcie-miszalski-i-gibala-twarza/000IYR3VVFFYIQ3B-C321.jpg" /></a>Ostre wymiany zdań, zaskakujące odpowiedzi, wymowne &quot;szpilki&quot;, łapanie się za słówka i niespodzianka dla wyborców PiS - to wszystko w debacie Interii między kandydatami na prezydenta Krakowa. &quot;Bitwa o Kraków. Decydujące starcie&quot; na stronie głównej Interii o godz. 18.</p><br clear="all" />

## Malował po budynku ministerstwa. Bąkiewicz usłyszał zarzut
 - [https://wydarzenia.interia.pl/kraj/news-malowal-po-budynku-ministerstwa-bakiewicz-uslyszal-zarzut,nId,7454873](https://wydarzenia.interia.pl/kraj/news-malowal-po-budynku-ministerstwa-bakiewicz-uslyszal-zarzut,nId,7454873)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T12:48:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-malowal-po-budynku-ministerstwa-bakiewicz-uslyszal-zarzut,nId,7454873"><img align="left" alt="Malował po budynku ministerstwa. Bąkiewicz usłyszał zarzut" src="https://i.iplsc.com/malowal-po-budynku-ministerstwa-bakiewicz-uslyszal-zarzut/000IYR2CYS2U7EEU-C321.jpg" /></a>Robert Bąkiewicz usłyszał we wtorek zarzut uszkodzenia zabytku. Końcem stycznia opublikował nagranie, na którym maluje na budynku Ministerstwa Klimatu i Środowiska symbol Polski Walczącej. Bąkiewicz nie przyznał się do zarzuconego mu czynu i odmówił składania wyjaśnień. </p><br clear="all" />

## Posiedzenie rządu z udziałem generałów. Donald Tusk przekazał informacje
 - [https://wydarzenia.interia.pl/kraj/news-posiedzenie-rzadu-z-udzialem-generalow-donald-tusk-przekazal,nId,7454851](https://wydarzenia.interia.pl/kraj/news-posiedzenie-rzadu-z-udzialem-generalow-donald-tusk-przekazal,nId,7454851)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T12:32:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-posiedzenie-rzadu-z-udzialem-generalow-donald-tusk-przekazal,nId,7454851"><img align="left" alt="Posiedzenie rządu z udziałem generałów. Donald Tusk przekazał informacje " src="https://i.iplsc.com/posiedzenie-rzadu-z-udzialem-generalow-donald-tusk-przekazal/000IYR3O6J7FJGO3-C321.jpg" /></a>- Otrzymałem uspokajające informacje o polskich żołnierzach stacjonujących w Libanie oraz Iraku - powiedział premier. We wtorek część obrad Rady Ministrów była tajna , na spotkanie zaproszono szefa BBN oraz najwyższych dowódców wojskowych, aby porozmawiać o ostatnim ataku Iranu na Izrael. Donald Tusk krytykował także byłego szefa MON Antoniego Macierewicza za &quot;kwestionowanie przetargów przygotowanych w 2014 roku&quot;. </p><br clear="all" />

## Tadżyk z Państwa Islamskiego w Polsce. Komunikat rzecznika służb
 - [https://wydarzenia.interia.pl/kraj/news-tadzyk-z-panstwa-islamskiego-w-polsce-komunikat-rzecznika-sl,nId,7454853](https://wydarzenia.interia.pl/kraj/news-tadzyk-z-panstwa-islamskiego-w-polsce-komunikat-rzecznika-sl,nId,7454853)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T12:09:33+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tadzyk-z-panstwa-islamskiego-w-polsce-komunikat-rzecznika-sl,nId,7454853"><img align="left" alt="Tadżyk z Państwa Islamskiego w Polsce. Komunikat rzecznika służb" src="https://i.iplsc.com/tadzyk-z-panstwa-islamskiego-w-polsce-komunikat-rzecznika-sl/000IYR2VAVJ3SRH2-C321.jpg" /></a>&quot;Na wniosek szefa ABW z terytorium Rzeczypospolitej Polskiej został deportowany obywatel Tadżykistanu - członek organizacji terrorystycznej Państwa Islamskiego, poszukiwany na podstawie czerwonej noty Interpolu&quot; - przekazał w mediach społecznościowych rzecznik prasowy ministra-koordynatora służb specjalnych Jacek Dobrzyński.</p><br clear="all" />

## Andrzej Duda krytycznie o Żelaznej Kopule nad Europą: To projekt niemiecki
 - [https://wydarzenia.interia.pl/kraj/news-andrzej-duda-krytycznie-o-zelaznej-kopule-nad-europa-to-proj,nId,7454750](https://wydarzenia.interia.pl/kraj/news-andrzej-duda-krytycznie-o-zelaznej-kopule-nad-europa-to-proj,nId,7454750)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T11:52:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-andrzej-duda-krytycznie-o-zelaznej-kopule-nad-europa-to-proj,nId,7454750"><img align="left" alt="Andrzej Duda krytycznie o Żelaznej Kopule nad Europą: To projekt niemiecki " src="https://i.iplsc.com/andrzej-duda-krytycznie-o-zelaznej-kopule-nad-europa-to-proj/000IYPSLFO3ESSNT-C321.jpg" /></a>- Myśmy do tej pory nie rozważali przystąpienia do projektu, ponieważ realizujemy swój - powiedział Andrzej Duda, odnosząc się do propozycji budowy Żelaznej Kopuły nad Europą. Prezydent podkreślił, że Polska współpracuje ze Stanami Zjednoczonymi i Wielką Brytanią, a tworzony projekt opiera się na systemie Patriot oraz na sprzęcie wyprodukowanym przez polski przemysł zbrojeniowy. </p><br clear="all" />

## Prezydent USA pokazał zeznanie podatkowe. Wiemy, ile zarobił
 - [https://wydarzenia.interia.pl/zagranica/news-prezydent-usa-pokazal-zeznanie-podatkowe-wiemy-ile-zarobil,nId,7454726](https://wydarzenia.interia.pl/zagranica/news-prezydent-usa-pokazal-zeznanie-podatkowe-wiemy-ile-zarobil,nId,7454726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T11:48:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prezydent-usa-pokazal-zeznanie-podatkowe-wiemy-ile-zarobil,nId,7454726"><img align="left" alt="Prezydent USA pokazał zeznanie podatkowe. Wiemy, ile zarobił" src="https://i.iplsc.com/prezydent-usa-pokazal-zeznanie-podatkowe-wiemy-ile-zarobil/000IYPNI4B7558R7-C321.jpg" /></a>Nieco ponad 600 tys. dolarów zarobiła amerykańska para prezydencka w 2023 roku. Joe i Jill Bidenowie opublikowali sprawozdania finansowe, z których wynika, że znaczną sumę zarobków przeznaczyli na podatki i cele charytatywne. Biden powrócił do zwyczaju publikowania dokumentów o swoich dochodach. Donald Trump odmawiał podawania takich informacji opinii publicznej. </p><br clear="all" />

## Sukces Ukrainy na rosyjskiej ziemi. Zniszczyli system wart miliony
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-sukces-ukrainy-na-rosyjskiej-ziemi-zniszczyli-system-wart-mi,nId,7454717](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-sukces-ukrainy-na-rosyjskiej-ziemi-zniszczyli-system-wart-mi,nId,7454717)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T11:37:11+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-sukces-ukrainy-na-rosyjskiej-ziemi-zniszczyli-system-wart-mi,nId,7454717"><img align="left" alt="Sukces Ukrainy na rosyjskiej ziemi. Zniszczyli system wart miliony" src="https://i.iplsc.com/sukces-ukrainy-na-rosyjskiej-ziemi-zniszczyli-system-wart-mi/000IYPP1D0YUC5RD-C321.jpg" /></a>Ukraińcy zniszczyli rosyjski system radarowy dalekiego zasięgu Nebo-U. To bardzo dotkliwa strata, bo system kosztował miliony dolarów i był dla rosyjskich wojsk kluczowy. Teraz okupant będzie mieć mniejsze zdolności do przeprowadzania ataków z powietrza. Bez Nebo-U w regionie bardziej problematyczne może stać się także wykrywanie ukraińskich pocisków.</p><br clear="all" />

## Kolejne kłopoty Kamińskiego i Wąsika. "Mamy usłyszeć zarzuty"
 - [https://wydarzenia.interia.pl/kraj/news-kolejne-klopoty-kaminskiego-i-wasika-mamy-uslyszec-zarzuty,nId,7454798](https://wydarzenia.interia.pl/kraj/news-kolejne-klopoty-kaminskiego-i-wasika-mamy-uslyszec-zarzuty,nId,7454798)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T11:26:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kolejne-klopoty-kaminskiego-i-wasika-mamy-uslyszec-zarzuty,nId,7454798"><img align="left" alt="Kolejne kłopoty Kamińskiego i Wąsika. &quot;Mamy usłyszeć zarzuty&quot;" src="https://i.iplsc.com/kolejne-klopoty-kaminskiego-i-wasika-mamy-uslyszec-zarzuty/000IYQT8JC14H31W-C321.jpg" /></a>- Zostaliśmy wezwani z Maciejem Wąsikiem do prokuratury celem ogłoszenia nam zarzutów ws. rzekomo nielegalnego głosowania w Sejmie - poinformował Mariusz Kamiński na konferencji prasowej. Jak dodał, &quot;są to działania bezprawne&quot;.</p><br clear="all" />

## Obywatele małych wysp dokonają wyboru. Na szali przyszłość regionu
 - [https://wydarzenia.interia.pl/zagranica/news-obywatele-malych-wysp-dokonaja-wyboru-na-szali-przyszlosc-re,nId,7454636](https://wydarzenia.interia.pl/zagranica/news-obywatele-malych-wysp-dokonaja-wyboru-na-szali-przyszlosc-re,nId,7454636)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T10:35:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-obywatele-malych-wysp-dokonaja-wyboru-na-szali-przyszlosc-re,nId,7454636"><img align="left" alt="Obywatele małych wysp dokonają wyboru. Na szali przyszłość regionu" src="https://i.iplsc.com/obywatele-malych-wysp-dokonaja-wyboru-na-szali-przyszlosc-re/000IYO8WO9AOJOS0-C321.jpg" /></a>Mieszkańcy jednego z najmniejszych państw świata - Wysp Salomona - wybiorą w tym tygodniu nowy parlament. Kształt nowego układu politycznych sił będzie miał jednak znaczenie nie tylko dla obywateli wysp, ale i dla całego regionu. Wpłynie też na geopolityczne prognozy. Stawką są bowiem relacje ze skonfliktowanymi Tajwanem i Chinami, a w konsekwencji także potencjał Państwa Środka w rywalizacji z USA. </p><br clear="all" />

## Wybory samorządowe 2024. Druga tura. Tak oddasz ważny głos
 - [https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-wybory-samorzadowe-2024-druga-tura-tak-oddasz-wazny-glos,nId,7452524](https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-wybory-samorzadowe-2024-druga-tura-tak-oddasz-wazny-glos,nId,7452524)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T10:11:16+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-samorzadowe-2024/news-wybory-samorzadowe-2024-druga-tura-tak-oddasz-wazny-glos,nId,7452524"><img align="left" alt="Wybory samorządowe 2024. Druga tura. Tak oddasz ważny głos" src="https://i.iplsc.com/wybory-samorzadowe-2024-druga-tura-tak-oddasz-wazny-glos/000IUDXRFPBHELUH-C321.jpg" /></a>Niedawno w Polsce odbyły się wybory samorządowe. W niektórych miejscowościach nie udało się w pierwszej turze wyłonić nowych włodarzy. Wobec tego, 21 kwietnia odbędzie się dogrywka. Ile kart czeka na wyborców, którzy pójdą zagłosować, jak oddać ważny głos i co w sytuacji, gdy jeden z kandydatów się wycofa? Odpowiadamy.</p><br clear="all" />

## "UE nie dowozi". Polacy zmieniają swoje nastawienie. Pierwsze takie badanie
 - [https://wydarzenia.interia.pl/kraj/news-ue-nie-dowozi-polacy-zmieniaja-swoje-nastawienie-pierwsze-ta,nId,7454670](https://wydarzenia.interia.pl/kraj/news-ue-nie-dowozi-polacy-zmieniaja-swoje-nastawienie-pierwsze-ta,nId,7454670)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T10:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ue-nie-dowozi-polacy-zmieniaja-swoje-nastawienie-pierwsze-ta,nId,7454670"><img align="left" alt="&quot;UE nie dowozi&quot;. Polacy zmieniają swoje nastawienie. Pierwsze takie badanie" src="https://i.iplsc.com/ue-nie-dowozi-polacy-zmieniaja-swoje-nastawienie-pierwsze-ta/000IYOJ0V2N3H6EK-C321.jpg" /></a>Chociaż Polacy nadal pozytywnie oceniają nasze członkostwo w Unii Europejskiej, to czasy naiwnego idealizowania Wspólnoty mamy już za sobą. Z najnowszego badania Opinii 24 dla think tanku More in Common, którego wyniki Interia publikuje jako pierwsza, dowiadujemy się m.in., że chcielibyśmy, żeby głos Polski był w UE bardziej szanowany, a Francja i Niemcy nie odgrywały w niej tak dominującej roli jak dotychczas.</p><br clear="all" />

## Ekspert tłumaczy porażkę Iranu. "Nieświadomie ujawnili to całemu światu"
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-ekspert-tlumaczy-porazke-iranu-nieswiadomie-ujawnili-to-cale,nId,7454505](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-ekspert-tlumaczy-porazke-iranu-nieswiadomie-ujawnili-to-cale,nId,7454505)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T09:33:05+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-ekspert-tlumaczy-porazke-iranu-nieswiadomie-ujawnili-to-cale,nId,7454505"><img align="left" alt="Ekspert tłumaczy porażkę Iranu. &quot;Nieświadomie ujawnili to całemu światu&quot;" src="https://i.iplsc.com/ekspert-tlumaczy-porazke-iranu-nieswiadomie-ujawnili-to-cale/000IYMYXNPII2RMW-C321.jpg" /></a>Atak Iranu na Izrael ujawnił jedynie słabość irańskiego reżimu - oceniają zagraniczne media i eksperci. Większość rakiet i dronów, którymi zaatakowali, zestrzelono, a o planach nalotu Zachód wiedział z wyprzedzeniem. &quot;Iran właśnie nieświadomie ujawnił całemu światu, że irański rząd jest zinfiltrowany przez zachodnie wywiady&quot; - ocenił jeden z analityków.</p><br clear="all" />

## Niecodzienne posiedzenie rządu. W KPRM pojawił się człowiek prezydenta
 - [https://wydarzenia.interia.pl/kraj/news-niecodzienne-posiedzenie-rzadu-w-kprm-pojawil-sie-czlowiek-p,nId,7454682](https://wydarzenia.interia.pl/kraj/news-niecodzienne-posiedzenie-rzadu-w-kprm-pojawil-sie-czlowiek-p,nId,7454682)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T09:18:47+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niecodzienne-posiedzenie-rzadu-w-kprm-pojawil-sie-czlowiek-p,nId,7454682"><img align="left" alt="Niecodzienne posiedzenie rządu. W KPRM pojawił się człowiek prezydenta" src="https://i.iplsc.com/niecodzienne-posiedzenie-rzadu-w-kprm-pojawil-sie-czlowiek-p/000IYOW5O3FU1MY3-C321.jpg" /></a>Posiedzenie rządu inne niż wszystkie. Jak przekazał premier Donald Tusk, w cotygodniowym spotkaniu Rady Ministrów biorą udział także szef BBN Jacek Siewiera, szef SGWP gen. Wiesław Kukuła i dowódca operacyjny RSZ gen. dyw. Maciej Klisz. Biuro Bezpieczeństwa Narodowego to urząd podlegający pod Prezydenta RP. Jak wytłumaczono, posiedzenie ma związek z sytuacją międzynarodową i na Bliskim Wschodzie. Posiedzenie nie jest otwarte dla mediów.</p><br clear="all" />

## Jacek Kurski mógł pomóc PiS? Przemysław Czarnek o wyborach
 - [https://wydarzenia.interia.pl/kraj/news-jacek-kurski-mogl-pomoc-pis-przemyslaw-czarnek-o-wyborach,nId,7454588](https://wydarzenia.interia.pl/kraj/news-jacek-kurski-mogl-pomoc-pis-przemyslaw-czarnek-o-wyborach,nId,7454588)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T09:05:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jacek-kurski-mogl-pomoc-pis-przemyslaw-czarnek-o-wyborach,nId,7454588"><img align="left" alt="Jacek Kurski mógł pomóc PiS? Przemysław Czarnek o wyborach" src="https://i.iplsc.com/jacek-kurski-mogl-pomoc-pis-przemyslaw-czarnek-o-wyborach/000IYNX6FDMYY04I-C321.jpg" /></a>- Gdyby Jacek Kurski do końca był szefem TVP, to być może byśmy wygrali (wybory parlamentarne - red.) tak jak wygraliśmy, ale moglibyśmy starać się o jakieś koalicyjne rządy - ocenił Przemysław Czarnek. Dodał również, że Kurski &quot;cieszy się dużą popularnością w elektoracie PiS i go mobilizuje&quot;. Poseł PiS nie wykluczył również, że były prezes TVP może wystartować w wyborach do europarlamentu.</p><br clear="all" />

## Tysiące ludzi na ulicach. "Rosyjska ustawa" rozpala kraj
 - [https://wydarzenia.interia.pl/zagranica/news-tysiace-ludzi-na-ulicach-rosyjska-ustawa-rozpala-kraj,nId,7454589](https://wydarzenia.interia.pl/zagranica/news-tysiace-ludzi-na-ulicach-rosyjska-ustawa-rozpala-kraj,nId,7454589)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T08:54:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tysiace-ludzi-na-ulicach-rosyjska-ustawa-rozpala-kraj,nId,7454589"><img align="left" alt="Tysiące ludzi na ulicach. &quot;Rosyjska ustawa&quot; rozpala kraj" src="https://i.iplsc.com/tysiace-ludzi-na-ulicach-rosyjska-ustawa-rozpala-kraj/000IYOA9JJ2O98EC-C321.jpg" /></a>Kilkadziesiąt tysięcy osób na ulicach i pierwsze aresztowania - to bilans antyrządowych protestów w stolicy Gruzji. Jak podają lokalne media, co najmniej cztery osoby pozbawiono już wolności. Obywatele wyszli na ulice Tbilisi, aby zaprotestować przeciwko procedowaniu ustawy o tzw. agentach zagranicznych, zwanej po prostu &quot;rosyjską ustawą&quot;. Zdaniem demonstrantów rządzący wprowadzają w Gruzji przepisy rodem z Rosji. </p><br clear="all" />

## Izrael szykuje się na odwet. Władze zwróciły się do krajów arabskich
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-izrael-szykuje-sie-na-odwet-wladze-zwrocily-sie-do-krajow-ar,nId,7454582](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-izrael-szykuje-sie-na-odwet-wladze-zwrocily-sie-do-krajow-ar,nId,7454582)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T08:34:59+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-izrael-szykuje-sie-na-odwet-wladze-zwrocily-sie-do-krajow-ar,nId,7454582"><img align="left" alt="Izrael szykuje się na odwet. Władze zwróciły się do krajów arabskich" src="https://i.iplsc.com/izrael-szykuje-sie-na-odwet-wladze-zwrocily-sie-do-krajow-ar/000IYNQ3JAVK8GLN-C321.jpg" /></a>Izrael zapewnił władze Jordanii, Egiptu, a także państw Zatoki Perskiej, że planowany odwet na Iranie nie będzie wiązał się dla nich z zagrożeniem - podają izraelskie media. Izraelski gabinet wojenny nie chce zaangażować w konflikt innych państw w regionie Bliskiego Wschodu. Poinformowano również, że atak ma być konsultowany ze Stanami Zjednoczonymi. </p><br clear="all" />

## Wiosna zaczyna przegrywać z zimą. Chłód, deszcz, alerty przed burzami
 - [https://wydarzenia.interia.pl/kraj/news-wiosna-zaczyna-przegrywac-z-zima-chlod-deszcz-alerty-przed-b,nId,7454560](https://wydarzenia.interia.pl/kraj/news-wiosna-zaczyna-przegrywac-z-zima-chlod-deszcz-alerty-przed-b,nId,7454560)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T07:57:41+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wiosna-zaczyna-przegrywac-z-zima-chlod-deszcz-alerty-przed-b,nId,7454560"><img align="left" alt="Wiosna zaczyna przegrywać z zimą. Chłód, deszcz, alerty przed burzami" src="https://i.iplsc.com/wiosna-zaczyna-przegrywac-z-zima-chlod-deszcz-alerty-przed-b/000IYN6DLNGFRKIU-C321.jpg" /></a>Wiosenna aura przegrywa z tą zimową. Do Polski napływają chłodniejsze masy powietrza, co wyraźnie czuć po wyjściu na zewnątrz. Wtorek może być pochmurny i wietrzny. W kilku województwach obowiązują alerty przed burzami. Z każdym kolejnym dniem będzie coraz chłodniej. W weekend w górach może spaść nawet 30 cm śniegu. </p><br clear="all" />

## Kalendarz wyborów do Parlamentu Europejskiego 2024. Najważniejsze terminy
 - [https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-kalendarz-wyborow-do-parlamentu-europejskiego-2024-najwaznie,nId,7440854](https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-kalendarz-wyborow-do-parlamentu-europejskiego-2024-najwaznie,nId,7440854)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T07:45:25+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-do-parlamentu-europejskiego-2024/news-kalendarz-wyborow-do-parlamentu-europejskiego-2024-najwaznie,nId,7440854"><img align="left" alt="Kalendarz wyborów do Parlamentu Europejskiego 2024. Najważniejsze terminy" src="https://i.iplsc.com/kalendarz-wyborow-do-parlamentu-europejskiego-2024-najwaznie/000IYN4LS47Q10XN-C321.jpg" /></a>9 czerwca 2024 roku odbędą się wybory do Parlamentu Europejskiego. Zanim jednak do nich dojdzie, część głosujących i startujących będzie musiała dotrzymać ważnych terminów. Przedstawiamy kalendarz wyborów europejskich. </p><br clear="all" />

## Piorun uderzył w samolot nad Polską. Maszyna musiała zawracać
 - [https://wydarzenia.interia.pl/kraj/news-piorun-uderzyl-w-samolot-nad-polska-maszyna-musiala-zawracac,nId,7454509](https://wydarzenia.interia.pl/kraj/news-piorun-uderzyl-w-samolot-nad-polska-maszyna-musiala-zawracac,nId,7454509)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T06:55:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-piorun-uderzyl-w-samolot-nad-polska-maszyna-musiala-zawracac,nId,7454509"><img align="left" alt="Piorun uderzył w samolot nad Polską. Maszyna musiała zawracać" src="https://i.iplsc.com/piorun-uderzyl-w-samolot-nad-polska-maszyna-musiala-zawracac/000IYMYHPHA1966D-C321.jpg" /></a>Samolot PLL LOT musiał zawracać w poniedziałek do Warszawy, kiedy nad Szczecinem uderzył w niego piorun. Nad szczecińskim lotniskiem przechodził front burzowy. Pogoda nie powiedziała jeszcze ostatniego słowa. Burze zawitają do Polski również we wtorek.</p><br clear="all" />

## Poseł PiS krytykuje kolegów z klubu. "To wstyd i żenada"
 - [https://wydarzenia.interia.pl/kraj/news-posel-pis-krytykuje-kolegow-z-klubu-to-wstyd-i-zenada,nId,7454510](https://wydarzenia.interia.pl/kraj/news-posel-pis-krytykuje-kolegow-z-klubu-to-wstyd-i-zenada,nId,7454510)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T06:42:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-posel-pis-krytykuje-kolegow-z-klubu-to-wstyd-i-zenada,nId,7454510"><img align="left" alt="Poseł PiS krytykuje kolegów z klubu. &quot;To wstyd i żenada&quot;" src="https://i.iplsc.com/posel-pis-krytykuje-kolegow-z-klubu-to-wstyd-i-zenada/000IYMKMD7UQ3BAG-C321.jpg" /></a>- Posłowie zachowali się żenująco - tak poseł PiS Bolesław Piecha skomentował zachowanie parlamentarzystów ze swojego klubu, którzy kilka dni temu w hotelu sejmowym urządzili huczną imprezę. Zdaniem polityka &quot;to nie licuje z powagą posła&quot;, a koledzy &quot;powinni przeprosić&quot;. Wcześniej Łukasz Mejza, uczestnik imprezy w hotelu dla posłów, mówił o &quot;przywracaniu najlepszych tradycji tego miejsca&quot;. </p><br clear="all" />

## Inwigilacja systemem Pegasus. Minister Siemoniak ujawnia nowe dane
 - [https://wydarzenia.interia.pl/kraj/news-inwigilacja-systemem-pegasus-minister-siemoniak-ujawnia-nowe,nId,7454511](https://wydarzenia.interia.pl/kraj/news-inwigilacja-systemem-pegasus-minister-siemoniak-ujawnia-nowe,nId,7454511)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T05:49:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-inwigilacja-systemem-pegasus-minister-siemoniak-ujawnia-nowe,nId,7454511"><img align="left" alt="Inwigilacja systemem Pegasus. Minister Siemoniak ujawnia nowe dane" src="https://i.iplsc.com/inwigilacja-systemem-pegasus-minister-siemoniak-ujawnia-nowe/000IYMFEFJC7W1EW-C321.jpg" /></a>- Nieco ponad 500 osób było inwigilowanych za pomocą systemu Pegasus - poinformował Tomasz Siemoniak, minister koordynator służb specjalnych. Dane te dotyczą lat 2017-2021. Wkrótce więcej w tej sprawie ma ujawnić minister sprawiedliwości. </p><br clear="all" />

## MON zwalnia ekspertów od kluczowego regionu. Potencjał zmniejszony o połowę
 - [https://wydarzenia.interia.pl/kraj/news-mon-zwalnia-ekspertow-od-kluczowego-regionu-potencjal-zmniej,nId,7453067](https://wydarzenia.interia.pl/kraj/news-mon-zwalnia-ekspertow-od-kluczowego-regionu-potencjal-zmniej,nId,7453067)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T05:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mon-zwalnia-ekspertow-od-kluczowego-regionu-potencjal-zmniej,nId,7453067"><img align="left" alt="MON zwalnia ekspertów od kluczowego regionu. Potencjał zmniejszony o połowę" src="https://i.iplsc.com/mon-zwalnia-ekspertow-od-kluczowego-regionu-potencjal-zmniej/000IYLAVEO99GIAU-C321.jpg" /></a>Nadzorowana przez resort obrony Akademia Sztuki Wojennej w ramach zwolnień grupowych zlikwidowała Ośrodek Badań Azji - instytucję analityczną zajmującą się bezpieczeństwem na największym kontynencie świata. Eksperci alarmują, że drastycznie spadną zdolności analityczne polskiego wojska.</p><br clear="all" />

## Niespokojnie na Bałkanach. Przywódca Serbii o rozpadzie sąsiedniego kraju
 - [https://wydarzenia.interia.pl/zagranica/news-niespokojnie-na-balkanach-przywodca-serbii-o-rozpadzie-sasie,nId,7454477](https://wydarzenia.interia.pl/zagranica/news-niespokojnie-na-balkanach-przywodca-serbii-o-rozpadzie-sasie,nId,7454477)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T04:44:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niespokojnie-na-balkanach-przywodca-serbii-o-rozpadzie-sasie,nId,7454477"><img align="left" alt="Niespokojnie na Bałkanach. Przywódca Serbii o rozpadzie sąsiedniego kraju" src="https://i.iplsc.com/niespokojnie-na-balkanach-przywodca-serbii-o-rozpadzie-sasie/000IYMC94B869S7O-C321.jpg" /></a>Już wkrótce członkiem Rady Europy może zostać Kosowo. Serbia nie wyraża zgody na takie działanie i głośno protestuje. Prezydent Aleksandar Vuczić zapowiedział, że w reakcji na taki rozwój wydarzeń jego kraj opuści szeregi organizacji. Na tym nie koniec problemów. Serbię czeka poważne &quot;starcie&quot; na forum Organizacji Narodów Zjednoczonych. Tymczasem lider Republiki Serbskiej z sąsiedniej Bośni i Hercegowiny zapowiedział rozpad tego kraju.</p><br clear="all" />

## Daniel Obajtek reaguje na słowa Borysa Budki. "Kiedyś za to odpowiecie"
 - [https://wydarzenia.interia.pl/kraj/news-daniel-obajtek-reaguje-na-slowa-borysa-budki-kiedys-za-to-od,nId,7453099](https://wydarzenia.interia.pl/kraj/news-daniel-obajtek-reaguje-na-slowa-borysa-budki-kiedys-za-to-od,nId,7453099)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-04-16T04:30:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-daniel-obajtek-reaguje-na-slowa-borysa-budki-kiedys-za-to-od,nId,7453099"><img align="left" alt="Daniel Obajtek reaguje na słowa Borysa Budki. &quot;Kiedyś za to odpowiecie&quot;" src="https://i.iplsc.com/daniel-obajtek-reaguje-na-slowa-borysa-budki-kiedys-za-to-od/000IYLFIM60GA2IC-C321.jpg" /></a>&quot;Nie róbcie ludziom wody z mózgu. Kiedyś to wy za to odpowiecie&quot; - napisał Daniel Obajtek, reagując na słowa ministra Borysa Budki na temat strat Orlenu i &quot;nietrafionych, chybionych inwestycji&quot;. Były prezes koncernu przypomniał, że przestał pełnić swoją funkcję dwa miesiące temu, a straty związane z działalnością spółki to - jego zdaniem - wina nowego zarządu. &quot;Panie ministrze, weź się Pan wreszcie za prawdziwą robotę&quot; - dodał.</p><br clear="all" />

