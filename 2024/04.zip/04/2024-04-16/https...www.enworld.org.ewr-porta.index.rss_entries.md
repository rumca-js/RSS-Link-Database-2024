# Source:EN World Tabletop RPG News & Reviews, URL:https://www.enworld.org/ewr-porta/index.rss, language:en

## THE BLACK RAINBOW SOCIETY – Talking With Gavriel Quiroga
 - [https://www.enworld.org/threads/the-black-rainbow-society-%E2%80%93-talking-with-gavriel-quiroga.703494](https://www.enworld.org/threads/the-black-rainbow-society-%E2%80%93-talking-with-gavriel-quiroga.703494)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-04-16T12:30:00+00:00

<div class="bbWrapper">Gavriel Quiroga is back with a new project on Kickstarter: THE BLACK RAINBOW SOCIETY. We talk about the book and, at the end, Gavriel offers a limited time freebie for EN World readers.</div>

