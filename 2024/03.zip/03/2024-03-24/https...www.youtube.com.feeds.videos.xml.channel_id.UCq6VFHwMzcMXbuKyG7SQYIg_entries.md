# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## Most Pathetic Alpha Male Program Ever
 - [https://www.youtube.com/watch?v=vPKCDz-w8hg](https://www.youtube.com/watch?v=vPKCDz-w8hg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-03-24T19:15:03+00:00

This is the greatest alpha male speech of All Time 
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/?ref=moist

## Halo TV Show is Still Bad
 - [https://www.youtube.com/watch?v=tgWNQzc2pb0](https://www.youtube.com/watch?v=tgWNQzc2pb0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-03-24T02:30:27+00:00

This is the greatest season 2 improvement of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/?ref=moist

## Most handsome samurai
 - [https://www.youtube.com/watch?v=Xf0gvl-_fOo](https://www.youtube.com/watch?v=Xf0gvl-_fOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-03-24T01:23:43+00:00

Merch https://moistglobal.com/
Comics https://badegg.co/

