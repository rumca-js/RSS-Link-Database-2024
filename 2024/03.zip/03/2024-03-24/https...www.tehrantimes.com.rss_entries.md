# Source:Tehran Times, URL:https://www.tehrantimes.com/rss, language:en-US

## UN special rapporteurs decry underreporting of sexual violence against Palestinians
 - [https://www.tehrantimes.com/news/496416/UN-special-rapporteurs-decry-underreporting-of-sexual-violence](https://www.tehrantimes.com/news/496416/UN-special-rapporteurs-decry-underreporting-of-sexual-violence)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-03-24T23:50:29+00:00

As accounts of sexual violence against Palestinian women in Gaza are coming out, two women special rapporteurs of the UN say the issue is underreported and undervalued.

## Iran: Israel opening another ‘shameful chapter to its dark list of crimes’
 - [https://www.tehrantimes.com/news/496415/Iran-Israel-opening-another-shameful-chapter-to-its-dark-list](https://www.tehrantimes.com/news/496415/Iran-Israel-opening-another-shameful-chapter-to-its-dark-list)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-03-24T23:22:26+00:00

TEHRAN - The Iranian Foreign Ministry on Sunday denounced the anti-human and horrific crimes of the Israeli army against medical staff, patients, the injured and displaced Palestinians in al-Shifa Hospital in Gaza.

## Iran down UAE at 2024 IIHF Women's Asia and Oceania Cup
 - [https://www.tehrantimes.com/news/496414/Iran-down-UAE-at-2024-IIHF-Women-s-Asia-and-Oceania-Cup](https://www.tehrantimes.com/news/496414/Iran-down-UAE-at-2024-IIHF-Women-s-Asia-and-Oceania-Cup)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-03-24T20:14:00+00:00

TEHRAN – Iran national team defeated the UAE 16-0 at the 2024 IIHF Women's Asia and Oceania Cup at the Gorodskoi Katok in Bishkek, Kyrgyzstan on Sunday.

## WHO, Japan renew partnership to combat malaria in Iran
 - [https://www.tehrantimes.com/news/496413/WHO-Japan-renew-partnership-to-combat-malaria-in-Iran](https://www.tehrantimes.com/news/496413/WHO-Japan-renew-partnership-to-combat-malaria-in-Iran)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-03-24T11:52:20+00:00

TEHRAN – The World Health Organization has launched a new project with the financial support of the Government of Japan to revive malaria prevention and control in south-eastern provinces of Iran, which host vulnerable populations, including Afghan refugees.

## More-than-normal rainfall expected by mid-April
 - [https://www.tehrantimes.com/news/496410/More-than-normal-rainfall-expected-by-mid-April](https://www.tehrantimes.com/news/496410/More-than-normal-rainfall-expected-by-mid-April)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-03-24T10:25:08+00:00

TEHRAN – Forecasts show that precipitations will be more than normal in the country by the end of the current calendar month (April 19), according to the National Atmospheric Science and Meteorological Research Center.

## Tens of schools, health centers built in deprived areas
 - [https://www.tehrantimes.com/news/496407/Tens-of-schools-health-centers-built-in-deprived-areas](https://www.tehrantimes.com/news/496407/Tens-of-schools-health-centers-built-in-deprived-areas)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-03-24T09:25:31+00:00

TEHRAN – Some 220 schools and 25 health centers have been constructed in deprived areas of southern provinces by the Headquarters for Executing the Order of the Imam Khomeini.

## Tehran, Beijing agree on forming joint environmental working group
 - [https://www.tehrantimes.com/news/496404/Tehran-Beijing-agree-on-forming-joint-environmental-working](https://www.tehrantimes.com/news/496404/Tehran-Beijing-agree-on-forming-joint-environmental-working)
 - RSS feed: https://www.tehrantimes.com/rss
 - date published: 2024-03-24T08:18:58+00:00

TEHRAN – Iran and China have agreed on boosting cooperation in areas related to the environment through forming a joint working group.

