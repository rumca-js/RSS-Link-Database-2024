# Source:CBC | Top Stories News, URL:https://www.cbc.ca/webfeed/rss/rss-topstories, language:en

## Cross Country Checkup: How much do you share about your kids online?
 - [https://www.cbc.ca/news/canada/cross-country-checkup-how-much-do-you-share-about-your-kids-online-1.7125226?cmp=rss](https://www.cbc.ca/news/canada/cross-country-checkup-how-much-do-you-share-about-your-kids-online-1.7125226?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T16:06:00+00:00

<img alt="" height="349" src="https://liveimages.cbc.ca/gU3ABqIjZryzH9VFGtkH/thumbnail.jpeg" title="" width="620" /><p>It's a two-topic Sunday: We want to know where you draw the line between your kids’ public and private life. And, with news of Princess Catherine's cancer diagnosis we're asking: What was it like for you to share your cancer diagnosis?</p>

## Canada wins women's world curling championship as Rachel Homan guides country to 1st gold since 2018
 - [https://www.cbc.ca/sports/olympics/winter/curling/rachel-homan-womens-curling-world-championship-march-24-1.7153807?cmp=rss](https://www.cbc.ca/sports/olympics/winter/curling/rachel-homan-womens-curling-world-championship-march-24-1.7153807?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T14:14:49+00:00

<img alt="A female curling skip delivers a stone with her right hand." height="349" src="https://i.cbc.ca/1.7154174.1711319340!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/cur-world-women-20240324.JPG" title="Canada skip Rachel Homan delivers a stone during the gold-medal game against Switzerland at the women&apos;s curling world championship in Sydney, N.S., on Sunday." width="620" /><p>Canada's Rachel Homan defeated Switzerland's Silvana Tirinzoni 7-5 on Sunday to win gold at the women's curling world championship in Sydney, N.S.</p>

## As Russia mourns concert hall attack, some families wonder if loved ones are alive
 - [https://www.cbc.ca/news/world/moscow-russia-isis-attack-concert-hall-1.7153975?cmp=rss](https://www.cbc.ca/news/world/moscow-russia-isis-attack-concert-hall-1.7153975?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T12:00:33+00:00

<img alt="A woman places flowers at a makeshift memorial. " height="349" src="https://i.cbc.ca/1.7153986.1711291161!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/russia-crimea.jpg" title="A woman places flowers in memory of the victims of the attack in Moscow, in the center of Simferopol, in Russian-held Crimea, Sunday, March 24, 2024. Russia observed a national day of mourning on Sunday, two days after an attack on a suburban Moscow concert hall that killed over 130 people. (AP Photo)" width="620" /><p>Family and friends of those still missing after an attack that killed more than 130 people at a suburban Moscow concert hall waited for news of their loved ones as Russia observed a day of national mourning on Sunday.</p>

## Anti-authority narratives could tear 'fabric of society,' intelligence report warns
 - [https://www.cbc.ca/news/politics/threats-of-violence-canada-elections-1.7153960?cmp=rss](https://www.cbc.ca/news/politics/threats-of-violence-canada-elections-1.7153960?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T10:51:52+00:00

<img alt="A law enforcement officer stands with a firearm beside a car." height="349" src="https://i.cbc.ca/1.6486461.1711290110!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/parliament-hill-evacuation-20220611.jpg" title="A member of the Parliamentary Protective Service (PPS) responds to an incident on Parliament Hill in Ottawa on Saturday, June 11, 2022. THE CANADIAN PRESS/ Patrick Doyle" width="620" /><p>A report by a body overseeing the integrity of Canadian elections is warning about the level of threats and intimidation directed toward politicians.</p>

## Nigerian army rescues children abducted from school over 2 weeks ago
 - [https://www.cbc.ca/news/world/nigerian-schoolchildren-released-1.7153924?cmp=rss](https://www.cbc.ca/news/world/nigerian-schoolchildren-released-1.7153924?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T09:17:58+00:00

<img alt="Parents wait outside a school in Kaduna state, Nigeria." height="349" src="https://i.cbc.ca/1.7153935.1711283229!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/nigeria-school-kidnap.jpg" title="Parents wait for news about the kidnapped LEA Primary and Secondary School Kuriga students in Kuriga, Kaduna state, Nigeria, Saturday, March 9, 2024. Security forces swept through large forests in Nigeria&apos;s northwest region on Friday in search of nearly 300 children who were abducted from their school a day earlier in the West African nation&apos;s latest mass kidnap which analysts and activists blamed on the failure of intelligence and slow security response. (AP Photo/Sunday Alamba)" width="620" /><p>The Nigerian army on Sunday rescued students and staff who were abducted by gunmen from a school in the country's north earlier this month, the military said, days before a deadline to pay a ransom.</p>

## Christine Blasey Ford's testimony against Kavanaugh made her a target. But she would do it again
 - [https://www.cbc.ca/radio/sunday/christine-blasey-ford-memoir-one-way-back-1.7152943?cmp=rss](https://www.cbc.ca/radio/sunday/christine-blasey-ford-memoir-one-way-back-1.7152943?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T08:30:00+00:00

<img alt="Closeup of a woman with long blonde hair speaking into a microphone" height="349" src="https://i.cbc.ca/1.7152377.1711125350!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/1041759264.jpg" title="WASHINGTON, DC - SEPTEMBER 27:  Christine Blasey Ford testifies before the U.S. Senate Judiciary Committee at the Dirksen Senate Office Building on Capitol Hill September 27, 2018 in Washington, DC. Blasey Ford, a professor at Palo Alto University and a research psychologist at the Stanford University School of Medicine, has accused Supreme Court nominee Brett Kavanaugh of sexually assaulting her during a party in 1982 when they were high school students in suburban Maryland.  (Photo by Andrew Harnik-Pool/Getty Images)" width="620" /><p>Christine Blasey Ford was propelled into the public sphere in 2018 when she testified in front of the U.S. Senate judiciary committee that Brett Kavanaugh, then a U.S. Supreme Court nominee, sexually assaulted her when they were both

## Love behind a paywall, a foiled scam attempt: CBC's Marketplace cheat sheet
 - [https://www.cbc.ca/news/business/marketplace-cheat-sheet-march24-1.7152587?cmp=rss](https://www.cbc.ca/news/business/marketplace-cheat-sheet-march24-1.7152587?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T08:00:00+00:00

<img alt="woman being hypnotized by a phone " height="349" src="https://i.cbc.ca/1.7144839.1710537120!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/dating-app.jpg" title="Users say it’s becoming more common for dating apps to use tactics to get them to spend money on finding a date. " width="620" /><p>CBC's Marketplace rounds up the consumer and health news you need from the week.</p>

## Halifax senior stuck with $45K bill for new sewer, water lines before she can sell her duplex
 - [https://www.cbc.ca/news/canada/nova-scotia/halifax-senior-sell-home-of-50-years-halifax-water-upgrades-will-cost-thousands-1.7151430?cmp=rss](https://www.cbc.ca/news/canada/nova-scotia/halifax-senior-sell-home-of-50-years-halifax-water-upgrades-will-cost-thousands-1.7151430?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T05:00:00+00:00

<img alt="A woman with short black hair sits in an armchair with a bed behind her, and photos on the wall" height="349" src="https://i.cbc.ca/1.7151434.1711052125!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/arlene-best.jpg" title="Arlene Best in her bachelor room at Northwood&apos;s assisted living facility in Halifax. Best says she&apos;s unsure how her family will find the money to pay for the pipe upgrades needed to subdivide her duplex." width="620" /><p>A Halifax senior says major issues selling her home of 50 years have become a cautionary tale for those in old duplexes around the city.</p>

## This is why you're burnt out from using dating apps
 - [https://www.cbc.ca/news/canada/dating-apps-burnout-1.7152917?cmp=rss](https://www.cbc.ca/news/canada/dating-apps-burnout-1.7152917?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T04:01:00+00:00

<img alt="A woman and a man are seen next to each other, looking tired with their hands on their heads. In the middle is an iPhone, with stacked purple, yellow and blue hearts on the screen." height="349" src="https://i.cbc.ca/1.7152945.1711145796!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/headline-image-dating-app-series.jpg" title="The way dating apps are designed and how users are behaving are contributing to more young people feeling burnt out or fed up of using dating apps." width="620" /><p></p>

## How the NDP's motion on Israel could bring a profound shift in Canadian foreign policy
 - [https://www.cbc.ca/news/politics/canada-israel-palestine-gaza-ndp-liberal-joly-1.7153127?cmp=rss](https://www.cbc.ca/news/politics/canada-israel-palestine-gaza-ndp-liberal-joly-1.7153127?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T04:00:00+00:00

<img alt="A soldier stands next to a wrecked car in a pitted lot filled with rubble." height="349" src="https://i.cbc.ca/1.7153243.1711149856!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/israel-palestinians-underneath-unwra.jpg" title="An Israeli soldier takes up a position next to a damaged car that is piled up with concrete as protection for Israeli soldiers next to UNRWA headquarters where the military discovered tunnels underneath the U.N. agency that the military says Hamas militants used to attack its forces during a ground operation in Gaza, Thursday, Feb. 8, 2024. The Israeli military says it has discovered tunnels underneath the main headquarters of the U.N. agency for Palestinian refugees in Gaza City, alleging that Hamas militants used the space as an electrical supply room. The unveiling of the tunnels marked the latest chapter in Israel&apos;s campaign against the embattled agency, which it accuses of collaborating with Hamas." width="620" /><p>Foreign

## I used to judge people who chose to leave Newfoundland for work. Then I had to leave, too
 - [https://www.cbc.ca/news/canada/i-used-to-judge-people-who-chose-to-leave-newfoundland-for-work-then-i-had-to-leave-too-1.7150471?cmp=rss](https://www.cbc.ca/news/canada/i-used-to-judge-people-who-chose-to-leave-newfoundland-for-work-then-i-had-to-leave-too-1.7150471?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T04:00:00+00:00

<img alt="A woman wearing a turquoise shirt, sunglasses and a tuque stands on a rocky outcrop. There are barrens, mountains and ponds behind her. " height="349" src="https://i.cbc.ca/1.7150496.1711061516!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/lindsey-harrington-2022.jpg" title="For most of her career in Newfoundland, Lindsey Harrington did what she preached: she shared stories of Newfoundlanders who stayed on the island. But life had other plans for her. In this photo from 2022, she is on a hike with friends on a visit home." width="620" /><p>For most of her career in Newfoundland,Lindsey Harrington did what she preached: she stayed on the island instead of finding work on the mainland. But life had other plans for her.</p>

## Rio Tinto says it's a green mining giant. Investigation shows environmental gaps from Quebec to the Amazon
 - [https://www.cbc.ca/news/canada/montreal/rio-tinto-quebec-amazon-bauxite-aluminum-1.7153444?cmp=rss](https://www.cbc.ca/news/canada/montreal/rio-tinto-quebec-amazon-bauxite-aluminum-1.7153444?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T04:00:00+00:00

<img alt="A field with bauxite. " height="349" src="https://i.cbc.ca/1.7153499.1711227564!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/rio-tinto.jpg" title="Radio-Canada&apos;s Enquête team travelled to Brazil as part of its investigation into Rio Tinto&apos;s production chain. " width="620" /><p>According to Radio-Canada’s Enquête program, Rio Tinto’s brand as an eco-friendly business is contradicted by its environmental record in Quebec as well as its footprint in the Amazon region of Brazil.</p>

## Unfilled residency spots show family doctor shortage worsening, physicians say
 - [https://www.cbc.ca/news/canada/toronto/ontario-family-doctor-residents-shortage-1.7151071?cmp=rss](https://www.cbc.ca/news/canada/toronto/ontario-family-doctor-residents-shortage-1.7151071?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T04:00:00+00:00

<img alt="Ddoctor " height="349" src="https://i.cbc.ca/1.5214518.1689453995!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/doctors-doctor.jpg" title="The province of Manitoba and Doctors Manitoba, which bargains on behalf of physicians, have settled on a new four-year contract. The agreement still needs to be ratified by doctors. " width="620" /><p>Physicians are sounding the alarm after more than a hundred spaces reserved for training new family doctors in Ontario went unfilled this year.</p>

## With inconsistent support for brain injuries in Canada, peer groups are a lifeline
 - [https://www.cbc.ca/news/canada/saskatchewan/brain-injury-peer-support-group-saskatchewan-1.7149081?cmp=rss](https://www.cbc.ca/news/canada/saskatchewan/brain-injury-peer-support-group-saskatchewan-1.7149081?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-03-24T04:00:00+00:00

<img alt="A middle-aged woman wearing a purple T-shirt that says, &apos;I survived a brain injury. What&apos;s your super power.&apos;" height="349" src="https://i.cbc.ca/1.7149142.1710888275!/fileImage/httpImage/image.jpeg_gen/derivatives/16x9_620/carla-eckert.jpeg" title="Carla Eckert got a brain injury from encephalitis in 2022. She&apos;s maintained a positive attitude, as evidenced by her collection of inspirational T-shirts." width="620" /><p>Brain injuries are misunderstood and isolating. They can have little to no external signs but completely upend someone’s inner workings and daily life. In the absence of robust, consistent supports across Canada, survivors turn to one another.</p>

