# Source:RT - Daily news, URL:https://www.rt.com/rss, language:en

## Poland summons Russian envoy over ‚Äòmissile incident‚Äô
 - [https://www.rt.com/news/594847-poland-russian-missile-incident/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/594847-poland-russian-missile-incident/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T22:54:13+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/6600aec920302710f124fe43.jpg" style="margin-right: 10px;" /> Poland has accused Russia of violating its airspace during airstrikes on Ukraine <br /><a href="https://www.rt.com/news/594847-poland-russian-missile-incident/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Macron obsessing over personal security amid Ukrainian conflict ‚Äì media
 - [https://www.rt.com/news/594834-macron-personal-security-obsession/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/594834-macron-personal-security-obsession/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T20:59:47+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/660093d2203027110859549b.jpg" style="margin-right: 10px;" /> France‚Äôs President is increasingly worried about his personal security, fearing retaliation over his attempts to be tough on Russia <br /><a href="https://www.rt.com/news/594834-macron-personal-security-obsession/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Suspects in Moscow concert hall attack brought before court (VIDEOS)
 - [https://www.rt.com/russia/594846-moscow-concert-hall-attackers-court/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/594846-moscow-concert-hall-attackers-court/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T20:03:34+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/6600895b85f540110e02ca31.jpeg" style="margin-right: 10px;" />  <br /><a href="https://www.rt.com/russia/594846-moscow-concert-hall-attackers-court/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kiev bar mocks Moscow concert hall attack
 - [https://www.rt.com/russia/594828-kiev-bar-moscow-massacre/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/594828-kiev-bar-moscow-massacre/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T16:28:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/66004f6785f540110e02ca20.png" style="margin-right: 10px;" /> A Kiev bar is now offering a fried snack set dubbed ‚ÄòCrocus City‚Äô to mock the deadly terrorist attack on the Moscow concert venue <br /><a href="https://www.rt.com/russia/594828-kiev-bar-moscow-massacre/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Hero teen helps over 100 to safety during Moscow terrorist attack
 - [https://www.rt.com/russia/594831-teenager-saved-hundred-crocus-city-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/594831-teenager-saved-hundred-crocus-city-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T16:20:49+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/66004a0985f540146270e459.jpg" style="margin-right: 10px;" /> 15-year old Islam Khalilov, who worked part-time at Crocus City Hall, led over 100 people to safety during Friday‚Äôs terrorist attack <br /><a href="https://www.rt.com/russia/594831-teenager-saved-hundred-crocus-city-attack/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO‚Äôs illegal 1999 bombing of Yugoslavia ‚Äòa huge tragedy‚Äô ‚Äì Putin
 - [https://www.rt.com/russia/594830-putin-bombing-nato-belgrade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/594830-putin-bombing-nato-belgrade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T15:51:42+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/6600469785f540146270e452.jpg" style="margin-right: 10px;" /> When it bombed Yugoslavia in 1999, NATO in fact started a war in the center of Europe, President Vladimir Putin has said 25 years on <br /><a href="https://www.rt.com/russia/594830-putin-bombing-nato-belgrade/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ruins of Yugoslavia: How Russia learned that NATO poses a threat
 - [https://www.rt.com/news/594825-ruins-of-yugoslavia-25/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/594825-ruins-of-yugoslavia-25/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T15:07:05+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/66003d522030270bab32c9f1.jpg" style="margin-right: 10px;" /> The alliance‚Äôs strikes on Belgrade in the spring of 1999 forever changed relations between the West and Moscow <br /><a href="https://www.rt.com/news/594825-ruins-of-yugoslavia-25/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia mourns concert hall terror victims
 - [https://www.rt.com/russia/594823-mourning-russia-crocus-city-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/594823-mourning-russia-crocus-city-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T14:23:38+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/66001cb885f540122b6106c2.jpg" style="margin-right: 10px;" /> Russia is in mourning for the victims of Friday‚Äôs concert hall terrorist attack, with people laying flowers near the venue <br /><a href="https://www.rt.com/russia/594823-mourning-russia-crocus-city-attack/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Death toll in Moscow terrorist attack rises to 137
 - [https://www.rt.com/russia/594829-death-toll-moscow-terrorist-attack-137/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/594829-death-toll-moscow-terrorist-attack-137/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T14:02:37+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/static.en/thumbnail/breaking.jpg" style="margin-right: 10px;" />  <br /><a href="https://www.rt.com/russia/594829-death-toll-moscow-terrorist-attack-137/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel summons Turkish envoy after Erdogan‚Äôs ‚Äòsend Netanyahu to Allah‚Äô remark
 - [https://www.rt.com/news/594827-israel-summoned-turkish-envoy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/594827-israel-summoned-turkish-envoy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T13:19:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/6600266885f540146270e441.jpg" style="margin-right: 10px;" /> Israel has summoned the Turkish envoy after President Erdogan‚Äôs verbal attack on Prime Minister Netanyahu <br /><a href="https://www.rt.com/news/594827-israel-summoned-turkish-envoy/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## President doubles down on ‚ÄòMexico first‚Äô policy
 - [https://www.rt.com/news/594826-president-doubles-down-mexico-first/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/594826-president-doubles-down-mexico-first/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T12:31:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/66001b2c203027013348df6d.jpg" style="margin-right: 10px;" /> Mexico‚Äôs president said his country won‚Äôt act as police in the US fight against the drug influx <br /><a href="https://www.rt.com/news/594826-president-doubles-down-mexico-first/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Abducted schoolchildren freed ‚Äì Nigerian authorities
 - [https://www.rt.com/africa/594821-nigeria-kuriga-schoolchildren-released/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/594821-nigeria-kuriga-schoolchildren-released/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T11:41:20+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/65ffee312030270bab32c9c7.jpg" style="margin-right: 10px;" /> Nigerian authorities have announced the release of over 100 children and school staff abducted in the north of the country in early March <br /><a href="https://www.rt.com/africa/594821-nigeria-kuriga-schoolchildren-released/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## VIDEO shows first minutes of deadly Moscow terrorist attack
 - [https://www.rt.com/russia/594820-gunmen-entering-moscow-concert-hall/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/594820-gunmen-entering-moscow-concert-hall/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T09:45:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/65ffe4c485f5400e8a42d174.png" style="margin-right: 10px;" /> Video shared on social media purportedly shows gunmen entering a Moscow concert hall, where at least 133 people died in a terrorist attack <br /><a href="https://www.rt.com/russia/594820-gunmen-entering-moscow-concert-hall/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US destroyed anti-terrorism cooperation ‚Äì Moscow
 - [https://www.rt.com/news/594819-russian-envoy-us-destroyed-counterterrorism-cooperation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/594819-russian-envoy-us-destroyed-counterterrorism-cooperation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T08:21:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/65ffd45a2030270ac34e5503.jpg" style="margin-right: 10px;" /> The US has scuttled its once-effective counterterrorism cooperation with Russia, Moscow‚Äôs ambassador Anatoly Antonov has claimed <br /><a href="https://www.rt.com/news/594819-russian-envoy-us-destroyed-counterterrorism-cooperation/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Transgender teen sent to prison for killing 12-year-old girl
 - [https://www.rt.com/news/594818-transgender-teen-sent-to-prison/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/594818-transgender-teen-sent-to-prison/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T06:36:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/65ffb29c85f540110e02c9f5.jpg" style="margin-right: 10px;" /> A trans teen is sentenced after confessing to shooting his underage girlfriend while on a movie date <br /><a href="https://www.rt.com/news/594818-transgender-teen-sent-to-prison/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel announces major land grab in West Bank
 - [https://www.rt.com/news/594817-israel-major-land-grab-palestine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/594817-israel-major-land-grab-palestine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T02:50:05+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/65ff949d85f5400e8a42d15f.jpg" style="margin-right: 10px;" /> Israel has paved a way for more new Jewish settlements in the West Bank <br /><a href="https://www.rt.com/news/594817-israel-major-land-grab-palestine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU state orders suspension of Telegram
 - [https://www.rt.com/news/594816-eu-state-blocks-telegram/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/594816-eu-state-blocks-telegram/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss
 - date published: 2024-03-24T01:06:45+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.03/thumbnail/65ff73f020302706ce611d5b.jpg" style="margin-right: 10px;" /> Spain‚Äôs top court has ordered a block on access to Telegram due to an ongoing copyright probe <br /><a href="https://www.rt.com/news/594816-eu-state-blocks-telegram/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

