# Source:The Brazilian Report, URL:https://brazilian.report/feed, language:en-US

## Supreme Court and Congress in tug-of-war over cannabis decriminalization
 - [https://brazilian.report/power/2024/03/24/tug-of-war-cannabis-drugs-decriminalization](https://brazilian.report/power/2024/03/24/tug-of-war-cannabis-drugs-decriminalization)
 - RSS feed: https://brazilian.report/feed
 - date published: 2024-03-24T11:51:45+00:00

<p>The post <a href="https://brazilian.report/power/2024/03/24/tug-of-war-cannabis-drugs-decriminalization/">Supreme Court and Congress in tug-of-war over cannabis decriminalization</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

