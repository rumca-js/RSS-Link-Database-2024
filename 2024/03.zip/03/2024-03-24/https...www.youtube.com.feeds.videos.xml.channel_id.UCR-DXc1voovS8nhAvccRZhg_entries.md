# Source:Jeff Geerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## Another baby book for the collection! #shorts
 - [https://www.youtube.com/watch?v=bOJW5-GyAp0](https://www.youtube.com/watch?v=bOJW5-GyAp0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2024-03-24T18:38:33+00:00

The book is 'Computer Engineering for Big Babies,' the second in the 'Computer Engineering for Babies' series. I just love these little books, and so far the original has held up to four kids' rambunctious usage. It's not perfect—it relies on light hitting optical sensors to denote the current page—but it's fun, and the kids mostly love pressing the buttons. As do I! :)

Music: Panama Hat No Voice by Audionautix is licensed under a Creative Commons Attribution 4.0 license. https://creativecommons.org/licenses/by/4.0/

