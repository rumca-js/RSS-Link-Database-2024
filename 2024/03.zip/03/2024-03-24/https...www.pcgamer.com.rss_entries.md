# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## Hyper Light Drifter's long-awaited sequel feels like the first game got caught in a transporter accident with Risk of Rain⁠ 2—and I can't wait for more
 - [https://www.pcgamer.com/games/roguelike/hyper-light-drifters-long-awaited-sequel-feels-like-the-first-game-got-caught-in-a-transporter-accident-with-risk-of-rain-2and-im-digging-it-so-far](https://www.pcgamer.com/games/roguelike/hyper-light-drifters-long-awaited-sequel-feels-like-the-first-game-got-caught-in-a-transporter-accident-with-risk-of-rain-2and-im-digging-it-so-far)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-03-24T20:36:19+00:00

Procedural generation's still an open question, but Hyper Light Breaker's combat is already a winner.

## Larian originally wanted Baldur's Gate 3 to have multiple narrators, also Astarion was a tiefling
 - [https://www.pcgamer.com/games/baldurs-gate/larian-originally-wanted-baldurs-gate-3-to-have-multiple-narrators-also-astarion-was-a-tiefling](https://www.pcgamer.com/games/baldurs-gate/larian-originally-wanted-baldurs-gate-3-to-have-multiple-narrators-also-astarion-was-a-tiefling)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-03-24T17:24:51+00:00

Which perhaps would have made him too devilish a rascal.

## Today's Wordle answer for Sunday, March 24
 - [https://www.pcgamer.com/games/puzzle/wordle-answer-today-march-24-2024](https://www.pcgamer.com/games/puzzle/wordle-answer-today-march-24-2024)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-03-24T04:00:09+00:00

A hint to help you out and today's Wordle answer if you need it.

## Helldivers 2 players find creative ways to punish toxic hosts: 'I ran with your super samples to the edge of the mission area, and kept on running'
 - [https://www.pcgamer.com/games/third-person-shooter/helldivers-2-players-find-creative-ways-to-punish-toxic-hosts-i-ran-with-your-super-samples-to-the-edge-of-the-mission-area-and-kept-on-running](https://www.pcgamer.com/games/third-person-shooter/helldivers-2-players-find-creative-ways-to-punish-toxic-hosts-i-ran-with-your-super-samples-to-the-edge-of-the-mission-area-and-kept-on-running)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-03-24T01:53:21+00:00

Some people just never learned good-natured good sportsmanship.

## How are CD Projekt's side quests so good? Cyberpunk quest designer says they reject 'over 90%' of their pitches
 - [https://www.pcgamer.com/games/rpg/how-are-cd-projekts-side-quests-so-good-cyberpunk-quest-designer-says-they-reject-over-90-of-their-pitches](https://www.pcgamer.com/games/rpg/how-are-cd-projekts-side-quests-so-good-cyberpunk-quest-designer-says-they-reject-over-90-of-their-pitches)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-03-24T00:40:00+00:00

Just use the good ideas. Simple as.

