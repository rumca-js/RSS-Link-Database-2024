# Source:Austin Evans, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg, language:en-US

## Is Xbox EVEN Worth It?
 - [https://www.youtube.com/watch?v=Aurn2CUKwCY](https://www.youtube.com/watch?v=Aurn2CUKwCY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXGgrKt94gR6lmN4aN3mYTg
 - date published: 2024-03-24T15:00:36+00:00

Subscribe for more! https://www.youtube.com/austinevans
TikTok: https://www.tiktok.com/@austintechtips
Instagram: https://instagram.com/austinnotduncan
Twitter: https://twitter.com/austinnotduncan
Threads: https://www.threads.net/@austinnotduncan

Chapter Titles:
0:00 Is Xbox Still Worth It?
0:41 Early Issues
2:01 Why Series S Exists
3:46 Game Pass
5:50 Exclusives
7:21 The Game Pass Problem
8:58 Future of Xbox

