# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Silna burza geomagnetyczna. Możliwe problemy z sieciami energetycznymi
 - [https://tvn24.pl/tvnmeteo/nauka/silna-burza-geomagnetyczna-mozliwe-problemy-z-sieciami-energetycznymi-st7836677?source=rss](https://tvn24.pl/tvnmeteo/nauka/silna-burza-geomagnetyczna-mozliwe-problemy-z-sieciami-energetycznymi-st7836677?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-03-24T20:14:42+00:00

<img alt="Silna burza geomagnetyczna. Możliwe problemy z sieciami energetycznymi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ksp8xa-burza-sloneczna-5482008/alternates/LANDSCAPE_1280" />
    Burza geomagnetyczna osiągnęła poziom G4 w pięciostopniowej skali. Jak przekazało Centrum Badań Kosmicznych Polskiej Akademii Nauk, może spowodować problemy z sieciami energetycznymi i problemy ze śledzeniem satelitów na orbicie Ziemi.

## Zamach terrorystyczny pod Moskwą. Parafianowicz o "najbardziej prawdopodobnym scenariuszu"
 - [https://tvn24.pl/swiat/rosja-zamach-terrorystyczny-pod-moskwa-dziennikarz-zbigniew-parafianowicz-komentuje-st7836475?source=rss](https://tvn24.pl/swiat/rosja-zamach-terrorystyczny-pod-moskwa-dziennikarz-zbigniew-parafianowicz-komentuje-st7836475?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-03-24T16:05:07+00:00

<img alt="Zamach terrorystyczny pod Moskwą. Parafianowicz o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-he8o77-crocus-city-hall-7836514/alternates/LANDSCAPE_1280" />
    To była kwestia czasu, kiedy ISIS zaatakuje na terytorium Rosji. Kraj ten od dawna jest na celowniku Państwa Islamskiego - powiedział w niedzielę w TVN24 Zbigniew Parafianowicz, reportażysta i dziennikarz "Dziennika Gazety Prawnej", ekspert od Bliskiego Wschodu i Ukrainy. Według niego Władimir Putin będzie próbował wykorzystać piątkowy zamach do jeszcze silniejszego uderzenia w Ukrainę.

## Dorośli w szkolnych ławkach. "Wróciły wszystkie lęki i obawy"
 - [https://tvn24.pl/najnowsze/back-to-school-prawdziwy-egzamin-na-antenie-ttv-uczestnicy-o-swoim-powrocie-do-szkoly-st7836093?source=rss](https://tvn24.pl/najnowsze/back-to-school-prawdziwy-egzamin-na-antenie-ttv-uczestnicy-o-swoim-powrocie-do-szkoly-st7836093?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-03-24T10:44:30+00:00

<img alt="Dorośli w szkolnych ławkach. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z80f4k-program-back-to-school-prawdziwy-egzamin-na-antenie-ttv-7836156/alternates/LANDSCAPE_1280" />
    Najgorsze było to, że język ciała się zmienia - na nowo stajesz się uczniem. Dziwnie mi było z tym, że mam 40 lat, a i tak traktowano mnie jak uczniaka, za którego się decyduje i któremu się wmawia, że niczego nie osiągnie - wspomina Maciej Liziniewicz. Mężczyzna w ramach nowego programu "Back to school prawdziwy egzamin" na antenie TTV - musiał w roli ucznia wrócić do klasy szkoły podstawowej. - To była konfrontacja z systemem, w którym zmuszeni jesteśmy pracować - dodawała Małgorzata Kozak, jej klasa składała się z dorosłych. Premierowy odcinek programu już w tę niedzielę.

## Seria eksplozji na Krymie, ukraiński sztab raportuje o atakach na duże rosyjskie okręty desantowe
 - [https://tvn24.pl/swiat/ukraina-seria-eksplozji-na-krymie-sztab-generalny-informuje-o-atakach-na-duze-rosyjskie-okrety-desantowe-st7835836?source=rss](https://tvn24.pl/swiat/ukraina-seria-eksplozji-na-krymie-sztab-generalny-informuje-o-atakach-na-duze-rosyjskie-okrety-desantowe-st7835836?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-03-24T09:34:10+00:00

<img alt="Seria eksplozji na Krymie, ukraiński sztab raportuje o atakach na duże rosyjskie okręty desantowe " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7ldq1t-yamal-7836063/alternates/LANDSCAPE_1280" />
    Ukraiński sztab generalny poinformował w niedzielę rano o ataku na okupowany Krym. Trafione miały zostać rosyjskie okręty desantowe Jamał i Azow, centrum łączności rosyjskiej floty w Sewastopolu, a także rosyjska infrastruktura krytyczna. Okupacyjne władze półwyspu oznajmiły, że siły ukraińskie przypuściły "najbardziej zmasowany atak" na miasto.

## "Światła północy" rozbłysły nad Polską
 - [https://tvn24.pl/tvnmeteo/polska/zorza-polarna-nad-polska-240324-tej-nocy-moze-pojawic-sie-ponownie-st7835841?source=rss](https://tvn24.pl/tvnmeteo/polska/zorza-polarna-nad-polska-240324-tej-nocy-moze-pojawic-sie-ponownie-st7835841?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-03-24T08:26:52+00:00

<img alt="" src="https://kontakt24.tvn24.pl/najnowsze/cdn-zdjecie-ln1glr-zorza-7835804/alternates/LANDSCAPE_1280" />
    Zorza polarna rozświetliła niebo nad Polską. Chociaż w wielu częściach kraju noc była pochmurna, Reporterom 24 udało się uwiecznić to malownicze zjawisko. Jeśli przegapiliście świetlny spektakl, już wkrótce będzie okazja, by nadrobić zaległości.

