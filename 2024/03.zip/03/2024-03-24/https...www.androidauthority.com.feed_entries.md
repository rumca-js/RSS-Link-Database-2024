# Source:Android Authority, URL:https://www.androidauthority.com/feed, language:en-US

## First chance to pick up the Meta Quest 2 for just $199
 - [https://www.androidauthority.com/meta-quest-2-deal-3428062](https://www.androidauthority.com/meta-quest-2-deal-3428062)
 - RSS feed: https://www.androidauthority.com/feed
 - date published: 2024-03-24T14:21:10+00:00

The VR headset is 33% off for the first time, but the Amazon sale ends soon.

## 5 months later, I still hate the Pixel’s hidden brightness and shadows sliders
 - [https://www.androidauthority.com/still-hate-pixel-hidden-brightness-shadows-sliders-3427609](https://www.androidauthority.com/still-hate-pixel-hidden-brightness-shadows-sliders-3427609)
 - RSS feed: https://www.androidauthority.com/feed
 - date published: 2024-03-24T14:00:58+00:00

My photography has suffered as a result of this change.

## Do you know how terrible the early smartphone era was?
 - [https://www.androidauthority.com/early-smartphone-era-terrible-3384514](https://www.androidauthority.com/early-smartphone-era-terrible-3384514)
 - RSS feed: https://www.androidauthority.com/feed
 - date published: 2024-03-24T13:00:37+00:00

How bad were early smartphones compared to modern phones? Let me count the ways.

