# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Velocity and possibility
 - [https://seths.blog/2024/03/velocity-and-possibility](https://seths.blog/2024/03/velocity-and-possibility)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-03-24T08:54:00+00:00

The art of project management includes the dance between velocity and possibility. If you describe the outcome with specificity and remove as many variables as possible, you&#8217;ll get the work done with more speed, higher reliability and less cost. That velocity, though, might encourage us to recognize that all sorts of options are available. There [&#8230;]

