# Source:Spikey Bits, URL:https://spikeybits.com/feed, language:en-US

## New Forge World, Necromunda, Legions, & More Pre-Orders Revealed
 - [https://spikeybits.com/2024/03/new-underworlds-necromunda-legions-more-pre-orders-revealed.html](https://spikeybits.com/2024/03/new-underworlds-necromunda-legions-more-pre-orders-revealed.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T19:30:57+00:00

<p><p><a href="https://spikeybits.com/2024/03/new-underworlds-necromunda-legions-more-pre-orders-revealed.html"><img alt="next week new forge world legion imperialis" class="aligncenter wp-image-458508 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/03/next-week-new-forge-world-legion-imperialis.png" width="1280" /></a>GW has announced new Necromunda, Underworlds, Legions Imperialis, and Horus Heresy Forge World releases hitting pre-order this Saturday!</p>
<p><span id="more-458492"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p>
<p><a href="https://spikeybits.com/2024/03/new-underworlds-necromunda-legions-more-pre-orders-revealed.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/new-underworlds-necromunda-legions-more-pre-orders-revealed.html">New Forge World, Necromunda, Legions, &#038; More Pre

## This 4 Piece Bundle Will Change the Way You Paint Miniatures Forever
 - [https://spikeybits.com/2024/03/4-piece-hobby-holder-bundle-is-all-you-need.html](https://spikeybits.com/2024/03/4-piece-hobby-holder-bundle-is-all-you-need.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T18:30:28+00:00

<p><p><a href="https://spikeybits.com/?p=457570&amp;preview=true"><img alt="Game Envy Hobby Holder" class="aligncenter wp-image-453333" height="705" src="https://spikeybits.com/wp-content/uploads/2024/01/Screenshot_189.png" width="1280" /></a>The Hobby Holder Bundle for miniatures is the ultimate solution for hobbyists; it has everything from ergonomic handles to versatile attachments!<br />
<span id="more-457570"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p>
<p><a href="https://spikeybits.com/2024/03/4-piece-hobby-holder-bundle-is-all-you-need.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/4-piece-hobby-holder-bundle-is-all-you-need.html">This 4 Piece Bundle Will Change the Way You Paint Miniatures Forever</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Discount Alert: Fallout Miniatures & Dozens of Games On Sale Cheap
 - [https://spikeybits.com/2024/03/discount-alert-fallout-miniatures-dozens-of-games-on-sale-cheap.html](https://spikeybits.com/2024/03/discount-alert-fallout-miniatures-dozens-of-games-on-sale-cheap.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T17:00:19+00:00

<p><p><a href="https://spikeybits.com/?p=457416&amp;preview=true"><img alt="fallout minis tv series 1" class="aligncenter wp-image-457879 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/03/fallout-minis-tv-series-1.png" width="1280" /></a>There&#8217;s never been a better time to get into Fallout miniatures and tabletop gaming, especially with all of these new sales and releases!<span id="more-457416"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p><a href="https://spikeybits.com/2024/03/discount-alert-fallout-miniatures-dozens-of-games-on-sale-cheap.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/discount-alert-fallout-miniatures-dozens-of-games-on-sale-cheap.html">Discount Alert: Fallout Miniatures &#038; Dozens of Games On Sale Cheap</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Get $105 in Miniatures for Cheap: No Sub Required!
 - [https://spikeybits.com/2024/03/get-105-in-miniatures-for-cheap-no-sub-required.html](https://spikeybits.com/2024/03/get-105-in-miniatures-for-cheap-no-sub-required.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T16:30:45+00:00

<p><p><a href="https://spikeybits.com/?p=457627&amp;preview=true"><img alt="minaiture-crate-and-drop-shots-mystery-box-2" class="aligncenter wp-image-449770 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2023/11/minaiture-crate-and-drop-shots-mystery-box-2.png" width="1280" /></a><span>For a limited time, get $105 in miniatures for only $56 (almost 50% off) in our March Mystery Miniatures box with no subscription required!</span></p>
<p><span id="more-457627"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch"></p>
<p><a href="https://spikeybits.com/2024/03/get-105-in-miniatures-for-cheap-no-sub-required.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/get-105-in-miniatures-for-cheap-no-sub-required.html">Get $105 in Miniatures for Cheap: No Sub Required!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## You Won’t Believe How Good These Golden Demon Miniatures Are!
 - [https://spikeybits.com/2024/03/you-wont-believe-how-good-these-golden-demon-miniatures-are.html](https://spikeybits.com/2024/03/you-wont-believe-how-good-these-golden-demon-miniatures-are.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T15:30:08+00:00

<p><p><a href="https://spikeybits.com/?p=458461&amp;preview=true"><img alt="golden demon adepticon 2024" class="aligncenter wp-image-458490 size-full" height="729" src="https://spikeybits.com/wp-content/uploads/2024/03/golden-demon-adepticon-2024.png" width="1192" /></a>You won&#8217;t believe how good these painted miniatures are from the AdeptiCon 2024 Golden Demon; here are all our favorites so far.</p>
<p><span id="more-458461"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch"></p>
<p><a href="https://spikeybits.com/2024/03/you-wont-believe-how-good-these-golden-demon-miniatures-are.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/you-wont-believe-how-good-these-golden-demon-miniatures-are.html">You Won&#8217;t Believe How Good These Golden Demon Miniatures Are!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Become The Chaos Champion With This Daemon Prince!
 - [https://spikeybits.com/2024/03/become-the-champion-chaos-needs-with-this-alternative-daemon-prince.html](https://spikeybits.com/2024/03/become-the-champion-chaos-needs-with-this-alternative-daemon-prince.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T14:30:51+00:00

<p><p><a href="https://spikeybits.com/2024/03/become-the-champion-chaos-needs-with-this-alternative-daemon-prince.html"><img alt="New Daemon Prince Pop" class="aligncenter wp-image-457135" height="818" src="https://spikeybits.com/wp-content/uploads/2024/03/Screenshot_185.png" width="1285" /></a>Be THE Champion of Chaos with this new skulled-up Daemon Prince alternative model from Pop Goes The Monkey!</p>
<p><span id="more-457133"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p>This time</p>
<p><a href="https://spikeybits.com/2024/03/become-the-champion-chaos-needs-with-this-alternative-daemon-prince.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/become-the-champion-chaos-needs-with-this-alternative-daemon-prince.html">Become The Chaos Champion With This Daemon Prince!</a> from <a href="https://spikeybits.com">Sp

## These AdeptiCon ’24 Long War 40k Doubles Armies are Dope!
 - [https://spikeybits.com/2024/03/these-adepticon-24-long-war-40k-doubles-armies-are-dope.html](https://spikeybits.com/2024/03/these-adepticon-24-long-war-40k-doubles-armies-are-dope.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T13:30:12+00:00

<p><p><a href="https://spikeybits.com/?p=458313&amp;preview=true"><img alt="Adepticon feature" class="aligncenter wp-image-458396" height="698" src="https://spikeybits.com/wp-content/uploads/2024/03/Adepticon-feature.png" width="1242" /></a>These are some of our favorite Warhammer 40k armies from the Long War Doubles tournament we held at AdeptiCon 2024!</p>
<p><span id="more-458313"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p>Adepticon</p>
<p><a href="https://spikeybits.com/2024/03/these-adepticon-24-long-war-40k-doubles-armies-are-dope.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/these-adepticon-24-long-war-40k-doubles-armies-are-dope.html">These AdeptiCon &#8217;24 Long War 40k Doubles Armies are Dope!</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Shop Till You Drop: AdeptiCon’s Coolest Vendor Hall Booths
 - [https://spikeybits.com/2024/03/these-are-the-must-see-vendor-booths-of-adepticon-2024.html](https://spikeybits.com/2024/03/these-are-the-must-see-vendor-booths-of-adepticon-2024.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T12:30:12+00:00

<p><p><span><a href="https://spikeybits.com/?p=458286&amp;preview=true"><img alt="Vendor booths" class="aligncenter wp-image-458305 size-full" height="690" src="https://spikeybits.com/wp-content/uploads/2024/03/Vendor-booths.png" width="1207" /></a>Check out all the vendor hall booths at AdeptiCon 2024 from a ton of great companies in the hobby- these are our favorites!</span></p>
<p><span id="more-458286"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch"></p>
<p><a href="https://spikeybits.com/2024/03/these-are-the-must-see-vendor-booths-of-adepticon-2024.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/these-are-the-must-see-vendor-booths-of-adepticon-2024.html">Shop Till You Drop: AdeptiCon&#8217;s Coolest Vendor Hall Booths</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## New Orc & Goblin Old World, Horus Heresy: Pricing & Links
 - [https://spikeybits.com/2024/03/new-orcs-goblin-warhammer-the-old-world-horus-heresy-pricing-links.html](https://spikeybits.com/2024/03/new-orcs-goblin-warhammer-the-old-world-horus-heresy-pricing-links.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T10:30:12+00:00

<p><p><a href="https://spikeybits.com/2024/03/new-orcs-goblin-warhammer-the-old-world-horus-heresy-pricing-links.html"><img alt="orks goblins warhammer old world new releases" class="aligncenter wp-image-457827 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/03/orks-goblins-warhammer-old-world-new-releases.png" width="1280" /></a>Here are the pricing and links for all the new Old World Orcs &amp; Goblin Tribes and Horus Heresy Solar Auxilia releases now</p>
<p><a href="https://spikeybits.com/2024/03/new-orcs-goblin-warhammer-the-old-world-horus-heresy-pricing-links.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/new-orcs-goblin-warhammer-the-old-world-horus-heresy-pricing-links.html">New Orc &#038; Goblin Old World, Horus Heresy: Pricing &#038; Links</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Incredible 40k Team Tournament Armies From AdeptiCon 2024
 - [https://spikeybits.com/2024/03/incredible-40k-team-tournament-armies-from-adepticon-2024.html](https://spikeybits.com/2024/03/incredible-40k-team-tournament-armies-from-adepticon-2024.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-03-24T06:30:35+00:00

<p><p><a href="https://spikeybits.com/2024/03/incredible-40k-team-tournament-armies-from-adepticon-2024.html"><img alt="helsreach" class="aligncenter wp-image-458488 size-full" height="756" src="https://spikeybits.com/wp-content/uploads/2024/03/helsreach.png" width="1274" /></a>The marque event for Adepticon is the Warhammer 40k Team Tournament, and the 2024 armies were incredible to behold!</p>
<p><span id="more-458414"></span> </p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p>Adepticon has</p>
<p><a href="https://spikeybits.com/2024/03/incredible-40k-team-tournament-armies-from-adepticon-2024.html">Read More</a></p>
<p>Continue reading <a href="https://spikeybits.com/2024/03/incredible-40k-team-tournament-armies-from-adepticon-2024.html">Incredible 40k Team Tournament Armies From AdeptiCon 2024</a> from <a href="https://spikeybits.com">Spikey Bits</a>.</p>

