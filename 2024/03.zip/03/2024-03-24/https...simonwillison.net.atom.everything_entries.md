# Source:Simon Willison's Weblog, URL:https://simonwillison.net/atom/everything, language:en-us

## Reviving PyMiniRacer
 - [https://simonwillison.net/2024/Mar/24/reviving-pyminiracer/#atom-everything](https://simonwillison.net/2024/Mar/24/reviving-pyminiracer/#atom-everything)
 - RSS feed: https://simonwillison.net/atom/everything
 - date published: 2024-03-24T17:00:55+00:00

<p><a href="https://bpcreech.com/post/mini-racer/">Reviving PyMiniRacer</a></p>
<p>PyMiniRacer is &quot;a V8 bridge in Python&quot; - it&#x27;s a library that lets Python code execute JavaScript code in a V8 isolate and pass values back and forth (provided they serialize to JSON) between the two environments.</p>

<p>It was originally released in 2016 by Sqreen, a web app security startup startup. They were acquired by Datadog in 2021 and the project lost its corporate sponsor, but in this post Ben Creech announces that he is revitalizing the project, with the approval of the original maintainers.</p>

<p>I&#x27;m always interested in new options for running untrusted code in a safe sandbox. PyMiniRacer has the three features I care most about: code can&#x27;t access the filesystem or network by default, you can limit the RAM available to it and you can have it raise an error if code execution exceeds a time limit.</p>

<p>The documentation includes a newly written architectu

## shelmet
 - [https://simonwillison.net/2024/Mar/24/shelmet/#atom-everything](https://simonwillison.net/2024/Mar/24/shelmet/#atom-everything)
 - RSS feed: https://simonwillison.net/atom/everything
 - date published: 2024-03-24T04:37:52+00:00

<p><a href="https://shelmet.readthedocs.io/en/latest/">shelmet</a></p>
<p>This looks like a pleasant ergonomic alternative to Python&#x27;s subprocess module, plus a whole bunch of other useful utilities. Lets you do things like this:</p>

<p>sh.cmd(&quot;ps&quot;, &quot;aux&quot;).pipe(&quot;grep&quot;, &quot;-i&quot;, check=False).run(&quot;search term&quot;)</p>

<p>I like the way it uses context managers as well: &#x27;with sh.environ({&quot;KEY1&quot;: &quot;val1&quot;})&#x27; sets new environment variables for the duration of the block, &#x27;with sh.cd(&quot;path/to/dir&quot;)&#x27; temporarily changes the working directory and &#x27;with sh.atomicfile(&quot;file.txt&quot;) as fp&#x27; lets you write to a temporary file that will be atomically renamed when the block finishes.</p>

    <p>Via <a href="https://micro.webology.dev/2024/03/23/on-scratching-itches.html">Jeff Triplett</a></p>

