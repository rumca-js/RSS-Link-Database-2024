# Source:ZDNET, URL:https://www.zdnet.com/news/rss.xml, language:en-US

## Amazon Fire TV Omni Series QLED review: Worth it for Alexa fans, and now $180 off
 - [https://www.zdnet.com/home-and-office/home-entertainment/amazon-fire-tv-omni-series-qled-review/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/amazon-fire-tv-omni-series-qled-review/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-03-24T18:25:56.126079+00:00

The Amazon Fire TV Omni QLED offers excellent picture and audio quality, and now the 55-inch Omni QLED is $180 off during Amazon's Big Spring Sale.

## Best Buy dropped the M1 MacBook Air to $649, and you can still grab these savings
 - [https://www.zdnet.com/home-and-office/best-buy-dropped-the-m1-macbook-air-to-649-and-you-can-still-grab-these-savings/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-buy-dropped-the-m1-macbook-air-to-649-and-you-can-still-grab-these-savings/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-03-24T16:12:21+00:00

Walmart's new partnership with Apple discounts the M1 MacBook Air to $699, and Best Buy just countered with an even better price of $649. Don't miss out on these savings.

## The Roborock S8 Pro Ultra is still at an all-time-low price during Amazon's Big Spring Sale
 - [https://www.zdnet.com/home-and-office/this-great-roborock-robot-vacuum-mop-just-hit-an-all-time-low-price-during-amazon-spring-sale/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/this-great-roborock-robot-vacuum-mop-just-hit-an-all-time-low-price-during-amazon-spring-sale/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-03-24T16:07:05+00:00

If you've had your eye on the Roborock S8 Pro Ultra, it's $600 off (an all-time-low price) right now during Amazon's Big Spring Sale -- and it's one of my favorites.

## The 100+ best Amazon Big Spring Sale deals to shop on Day 5
 - [https://www.zdnet.com/article/best-amazon-big-spring-sale-deals-day-5-march-24/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-amazon-big-spring-sale-deals-day-5-march-24/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-03-24T15:41:32+00:00

Day 5 of the Amazon Big Spring Sale is underway, and you can still shop tons of deals on top tech and home products from Apple, Bose, iRobot, and more.

## Samsung will give you a free 65-inch 4K TV right now, but Amazon's offer is even better
 - [https://www.zdnet.com/home-and-office/home-entertainment/samsung-will-give-you-a-free-65-inch-4k-tv-right-now-but-amazons-offer-is-even-better/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/samsung-will-give-you-a-free-65-inch-4k-tv-right-now-but-amazons-offer-is-even-better/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-03-24T02:15:00+00:00

Preordering any of the company's 2024 TVs will qualify you for a 65-inch TU690T model at no extra charge. Amazon will give you an even bigger discount.

