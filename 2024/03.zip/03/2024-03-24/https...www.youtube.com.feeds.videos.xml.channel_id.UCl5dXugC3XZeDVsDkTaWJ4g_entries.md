# Source:Mountain Trekker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl5dXugC3XZeDVsDkTaWJ4g, language:en-US

## AFEEM KHA LIYA : Turkey Trip
 - [https://www.youtube.com/watch?v=qBfYRgdSxFA](https://www.youtube.com/watch?v=qBfYRgdSxFA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl5dXugC3XZeDVsDkTaWJ4g
 - date published: 2024-03-24T03:29:00+00:00

While returning from Goreme, Cappadocia, to Istanbul, I visited another destination called Afyonkarahisar. I visited places like Ayazini, Phrigiyan Valley, Aydalaz Castle, Sultan Divani Mevlevihanesi Museum, and Taşhan in Afyonkarahisar. Watch this video to learn more about the place and my experience.  #TravelVlog #MountainTrekker #Afyonkarahisar

If you like my videos, PLEASE SHARE them and let others get inspired to explore this beautiful world. SUBSCRIBE - http://bit.ly/subscribeMT

MOUNTAINTREKKER TRAVEL SERIES 
# Thailand series 2017 - http://bit.ly/MTthailand2017 
# Europe series - http://bit.ly/MTeurope2016 
# Bangladesh series - http://bit.ly/MTbangladesh2015
# Spiti (India) series - http://bit.ly/MTspiti2017 
# Malaysia series - http://bit.ly/MTmalaysia2017 
# Russia series - http://bit.ly/MTrussia2017 
# Bali series - http://bit.ly/MTbali2017 
# Mizoram series - http://bit.ly/MTmizoram2017 
# Egypt series: http://bit.ly/MTegypt2018 
# USA series: http://bit.ly/MTus

