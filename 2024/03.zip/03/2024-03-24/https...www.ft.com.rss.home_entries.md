# Source:FT - International homepage, URL:https://www.ft.com/rss/home, language:en

## Trump’s looming $464mn guarantee deadline ...
 - [https://www.ft.com/content/c3ba6a41-be2f-467d-a64b-df37ba4417d8](https://www.ft.com/content/c3ba6a41-be2f-467d-a64b-df37ba4417d8)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T23:30:08+00:00



## US and Japan plan biggest upgrade to security pact in more than 60 years ...
 - [https://www.ft.com/content/df99994d-ec4b-4c3c-9c42-738ec9b338d0](https://www.ft.com/content/df99994d-ec4b-4c3c-9c42-738ec9b338d0)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T18:00:49+00:00

Biden and Kishida to announce move to counter China at White House meeting next month ...

## What is the preventive cancer treatment for Princess Catherine?  ...
 - [https://www.ft.com/content/7910c2da-f936-4edf-8085-45063a04de1a](https://www.ft.com/content/7910c2da-f936-4edf-8085-45063a04de1a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T15:04:15+00:00

How chemotherapy can target microscopic cells to prevent the disease from spreading ...

## More than 130 kidnapped children freed in northern Nigeria  ...
 - [https://www.ft.com/content/986a6b11-a4db-41d2-8ae5-ba64c1f6e56b](https://www.ft.com/content/986a6b11-a4db-41d2-8ae5-ba64c1f6e56b)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T12:00:54+00:00

Release of pupils snatched in Kaduna state is a boost for Bola Tinubu’s government ...

## We need a cure for the curse of digital overabundance ...
 - [https://www.ft.com/content/1a72dabf-96cc-420d-ba21-480f68f5039b](https://www.ft.com/content/1a72dabf-96cc-420d-ba21-480f68f5039b)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T12:00:48+00:00

Having all the products of human civilisation at your fingertips can feel overwhelming ...

## IMF head says China at ‘fork in the road’ on reforms to boost demand ...
 - [https://www.ft.com/content/be0a8eb8-9f8a-462d-9e1e-9d9f4a85012c](https://www.ft.com/content/be0a8eb8-9f8a-462d-9e1e-9d9f4a85012c)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T06:30:29+00:00

Kristalina Georgieva’s remarks at Beijing conference come as China export glut tensions rise ...

## China blocks use of Intel and AMD chips in government computers ...
 - [https://www.ft.com/content/7bf0f79b-dea7-49fa-8253-f678d5acd64a](https://www.ft.com/content/7bf0f79b-dea7-49fa-8253-f678d5acd64a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T05:00:48+00:00

Microsoft’s Windows and foreign database programs also sidelined as Beijing favours Chinese hardware and software ...

## China’s ecommerce groups make inroads in South Korea with lure of low prices ...
 - [https://www.ft.com/content/a1b58b28-7a82-41b3-b120-94782b4a2b36](https://www.ft.com/content/a1b58b28-7a82-41b3-b120-94782b4a2b36)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T05:00:48+00:00

AliExpress and Temu are undercutting domestic competition and US rivals in world’s fourth-largest online shopping market ...

## Covid still warps our sense of time ...
 - [https://www.ft.com/content/5076e6b9-1be9-44a4-afa8-d0f96ab6afc4](https://www.ft.com/content/5076e6b9-1be9-44a4-afa8-d0f96ab6afc4)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T05:00:48+00:00

Four years after lockdowns began we are still learning about pandemic hangovers ...

## EU must wean itself off Russian nuclear fuel, Belgian PM says ...
 - [https://www.ft.com/content/a36aaae0-ec2e-4cad-ad90-c7cda0220046](https://www.ft.com/content/a36aaae0-ec2e-4cad-ad90-c7cda0220046)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T05:00:48+00:00

Alexander De Croo urges bloc not to replace one energy dependency for another ...

## Senegal’s politicians jostle to replace Macky Sall in delayed vote  ...
 - [https://www.ft.com/content/97e790f5-b510-41e4-855f-5358936e2402](https://www.ft.com/content/97e790f5-b510-41e4-855f-5358936e2402)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T05:00:48+00:00

Previously stable west African democracy was hit by protests ahead of Sunday election ...

## The threat to Netanyahu from Israel’s ultraorthodox army exemption  ...
 - [https://www.ft.com/content/c35044ef-8c4c-4e56-95ab-e0fe25ed2d60](https://www.ft.com/content/c35044ef-8c4c-4e56-95ab-e0fe25ed2d60)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T05:00:48+00:00

Conflict has laid bare tensions in ruling coalition over religious students skipping military service ...

## Thiel, Bezos and Zuckerberg join parade of insiders selling tech stocks  ...
 - [https://www.ft.com/content/3bcc3949-0bf6-4f41-bc46-57cbb0df3a7f](https://www.ft.com/content/3bcc3949-0bf6-4f41-bc46-57cbb0df3a7f)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T05:00:48+00:00

Bosses sell hundreds of millions of dollars in company shares this quarter in sign that markets may be peaking  ...

## US investment funds pull $13.3bn from BlackRock in anti-ESG campaign ...
 - [https://www.ft.com/content/9306c8f2-530d-45ca-a830-4d26e5a90509](https://www.ft.com/content/9306c8f2-530d-45ca-a830-4d26e5a90509)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T05:00:48+00:00

Latest loss of $8.5bn in Texas comes after asset manager tried to make inroads in the Republican state ...

## Menopause support must tread a fine line between awareness and stigma ...
 - [https://www.ft.com/content/a6d5efa0-9731-46f9-b7a5-a67a5a9814c3](https://www.ft.com/content/a6d5efa0-9731-46f9-b7a5-a67a5a9814c3)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-03-24T04:00:48+00:00

More employers are offering help but must avoid the risk of ‘meno-washing’ ...

