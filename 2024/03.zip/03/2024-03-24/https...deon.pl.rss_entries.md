# Source:DEON.pl, URL:https://deon.pl/rss, language:pl

## „W ciszy dali wyraz człowieczeństwa” – Markowa upamiętniła 80. Rocznicę męczeństwa rodziny Ulmów
 - [https://deon.pl/kosciol/w-ciszy-dali-wyraz-czlowieczenstwa--markowa-upamietnila-80-rocznice-meczenstwa-rodziny-ulmow,2774663](https://deon.pl/kosciol/w-ciszy-dali-wyraz-czlowieczenstwa--markowa-upamietnila-80-rocznice-meczenstwa-rodziny-ulmow,2774663)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-03-24T14:49:25+00:00



## W Wielkim Tygodniu przeżyjemy to wszystko, co Jezus uczynił dla naszego zbawienia
 - [https://deon.pl/kosciol/w-wielkim-tygodniu-przezyjemy-to-wszystko-co-jezus-uczynil-dla-naszego-zbawienia,2774648](https://deon.pl/kosciol/w-wielkim-tygodniu-przezyjemy-to-wszystko-co-jezus-uczynil-dla-naszego-zbawienia,2774648)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-03-24T14:24:59+00:00



## Papież Franciszek przewodniczył Mszy św. w Niedzielę Palmową
 - [https://deon.pl/kosciol/serwis-papieski/papiez-franciszek-przewodniczyl-mszy-sw-w-niedziele-palmowa,2774639](https://deon.pl/kosciol/serwis-papieski/papiez-franciszek-przewodniczyl-mszy-sw-w-niedziele-palmowa,2774639)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-03-24T10:46:00+00:00



## Niedziela Palmowa to początek Wielkiego Tygodnia
 - [https://deon.pl/kosciol/niedziela-palmowa-to-poczatek-wielkiego-tygodnia,2774627](https://deon.pl/kosciol/niedziela-palmowa-to-poczatek-wielkiego-tygodnia,2774627)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-03-24T10:28:03+00:00



## Port Lotniczy Rzeszów-Jasionka otrzymał imię Rodziny Ulmów
 - [https://deon.pl/swiat/port-lotniczy-rzeszow-jasionka-otrzymal-imie-rodziny-ulmow,2774612](https://deon.pl/swiat/port-lotniczy-rzeszow-jasionka-otrzymal-imie-rodziny-ulmow,2774612)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-03-24T10:13:04+00:00



## Na polskim biegunie zimna pojawiły się pierwsze bociany
 - [https://deon.pl/swiat/wiadomosci-z-polski/na-polskim-biegunie-zimna-pojawily-sie-pierwsze-bociany,2774600](https://deon.pl/swiat/wiadomosci-z-polski/na-polskim-biegunie-zimna-pojawily-sie-pierwsze-bociany,2774600)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-03-24T09:27:47+00:00



## Rysowana krzyżem mapa mojego serca
 - [https://deon.pl/wiara/rysowana-krzyzem-mapa-mojego-serca,2774582](https://deon.pl/wiara/rysowana-krzyzem-mapa-mojego-serca,2774582)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-03-24T08:37:23+00:00



## Bogaci w technologię, ale ubodzy w człowieczeństwo
 - [https://deon.pl/kosciol/komentarze/bogaci-w-technologie-ale-ubodzy-w-czlowieczenstwo,2774552](https://deon.pl/kosciol/komentarze/bogaci-w-technologie-ale-ubodzy-w-czlowieczenstwo,2774552)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-03-24T07:00:00+00:00



