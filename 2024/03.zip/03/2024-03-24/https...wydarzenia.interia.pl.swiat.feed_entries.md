# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Jak Putin odpowie po zamachu? Zły znak dla Kijowa
 - [https://wydarzenia.interia.pl/zagranica/news-jak-putin-odpowie-po-zamachu-zly-znak-dla-kijowa,nId,7409799](https://wydarzenia.interia.pl/zagranica/news-jak-putin-odpowie-po-zamachu-zly-znak-dla-kijowa,nId,7409799)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-03-24T21:36:53+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-jak-putin-odpowie-po-zamachu-zly-znak-dla-kijowa,nId,7409799"><img align="left" alt="Jak Putin odpowie po zamachu? Zły znak dla Kijowa" src="https://i.iplsc.com/jak-putin-odpowie-po-zamachu-zly-znak-dla-kijowa/000IU17UX5V0DVD7-C321.jpg" /></a>Niemiecka prasa skomentowała zamach pod Moskwą. Dziennikarze nie zostawili suchej nitki na Władimirze Putinie. &quot;Obiecał (swoim obywatelom - red.) bezpieczeństwo i porządek. (...) Nie dotrzymał swojej części umowy&quot; - napisał jeden z nich. Do serii zarzutów dodano późną reakcję rosyjskiego przywódcy, który zabrał głos dopiero 19 godzin po ataku. Jaki będzie następny ruch Kremla? &quot;Gniew Putina uderzy z całą mocą w Ukrainę&quot; - czytamy.</p><br clear="all" />

## Akcja w Petersburgu. Do centrum handlowego przyjechali saperzy
 - [https://wydarzenia.interia.pl/zagranica/news-akcja-w-petersburgu-do-centrum-handlowego-przyjechali-saperz,nId,7409737](https://wydarzenia.interia.pl/zagranica/news-akcja-w-petersburgu-do-centrum-handlowego-przyjechali-saperz,nId,7409737)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-03-24T17:06:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-akcja-w-petersburgu-do-centrum-handlowego-przyjechali-saperz,nId,7409737"><img align="left" alt="Akcja w Petersburgu. Do centrum handlowego przyjechali saperzy" src="https://i.iplsc.com/akcja-w-petersburgu-do-centrum-handlowego-przyjechali-saperz/000ITZ8AYGEN4NUE-C321.jpg" /></a>W Petersburgu ewakuowano centrum handlowe London Mall. Według doniesień medialnych ewakuacja rozpoczęła się po telefonie o podłożeniu bomby. W sprawie aresztowano jedną osobę. Z kolei w Moskwie pasażerka weszła na pokład samolotu odlatującego z portu Szeremietiewo i oświadczyła, że ma ze sobą ładunek wybuchowy.</p><br clear="all" />

## Niedawny sojusznik USA zwraca się ku Rosji. Kreml "walczy o wpływy"
 - [https://wydarzenia.interia.pl/zagranica/news-niedawny-sojusznik-usa-zwraca-sie-ku-rosji-kreml-walczy-o-wp,nId,7409687](https://wydarzenia.interia.pl/zagranica/news-niedawny-sojusznik-usa-zwraca-sie-ku-rosji-kreml-walczy-o-wp,nId,7409687)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-03-24T12:56:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niedawny-sojusznik-usa-zwraca-sie-ku-rosji-kreml-walczy-o-wp,nId,7409687"><img align="left" alt="Niedawny sojusznik USA zwraca się ku Rosji. Kreml &quot;walczy o wpływy&quot;" src="https://i.iplsc.com/niedawny-sojusznik-usa-zwraca-sie-ku-rosji-kreml-walczy-o-wp/000ITXZANJP0VD95-C321.jpg" /></a>Rosja walczy o znacznie większe wpływy w Nigrze. Rządząca krajem wojskowa junta nie chce, by kraj dalej był wspierany przez Stany Zjednoczone. Niger jest kolejnym afrykańskim krajem, w którym rośnie wpływ Kremla, a maleje państw Zachodu.</p><br clear="all" />

## Zełenski kpi z Putina. Zacharowa odpowiada w mocnych słowach
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-kpi-z-putina-zacharowa-odpowiada-w-mocnych-slowach,nId,7409666](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-kpi-z-putina-zacharowa-odpowiada-w-mocnych-slowach,nId,7409666)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-03-24T11:47:03+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-kpi-z-putina-zacharowa-odpowiada-w-mocnych-slowach,nId,7409666"><img align="left" alt="Zełenski kpi z Putina. Zacharowa odpowiada w mocnych słowach" src="https://i.iplsc.com/zelenski-kpi-z-putina-zacharowa-odpowiada-w-mocnych-slowach/000ITXK7KC28Y9D4-C321.jpg" /></a>&quot;Jedyną głową państwa, która była na tyle mądra, aby obwinić Rosję za atak terrorystyczny, jest Zełenski. Ponieważ na złodzieju czapka gore&quot; - stwierdziła we wpisie w swoich mediach społecznościowych rzeczniczka rosyjskiego MSZ Maria Zacharowa. Tak skomentowała ona oświadczenie ukraińskiego prezydenta, który w odniesieniu do zamachu na podmoskiewską salę koncertową przekazał, że &quot;nędznik Putin, zamiast zająć się swoimi rosyjskimi obywatelami, milczał przez jeden dzień - myślał o tym, jak zrzucić winę na Ukrainę&quot;.</p><br clear="all" />

## Tadżykistan zaprzecza insynuacjom Rosji. Mowa o "sprawcach" zamachu
 - [https://wydarzenia.interia.pl/zagranica/news-tadzykistan-zaprzecza-insynuacjom-rosji-mowa-o-sprawcach-zam,nId,7409648](https://wydarzenia.interia.pl/zagranica/news-tadzykistan-zaprzecza-insynuacjom-rosji-mowa-o-sprawcach-zam,nId,7409648)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-03-24T09:53:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tadzykistan-zaprzecza-insynuacjom-rosji-mowa-o-sprawcach-zam,nId,7409648"><img align="left" alt="Tadżykistan zaprzecza insynuacjom Rosji. Mowa o &quot;sprawcach&quot; zamachu" src="https://i.iplsc.com/tadzykistan-zaprzecza-insynuacjom-rosji-mowa-o-sprawcach-zam/000ITXCB0BKWXVOS-C321.jpg" /></a>Ministerstwo Spraw Wewnętrznych Tadżykistanu zaprzeczyło w oficjalnym komunikacie doniesieniom rosyjskich mediów, twierdzącym, że w ataku na salę koncertową Crocus City Hall brali udział obywatele tego państwa. Jak podkreślono, dwóch obywateli tego państwa, którym zarzuca się udział w ataku, w listopadzie ub. roku powróciło do Tadżykistanu i od tamtej pory przebywają oni w swoim miejscu zamieszkania.</p><br clear="all" />

## Ubiega się o fotel prezydenta. Polskę traktuje jak drugą ojczyznę
 - [https://wydarzenia.interia.pl/zagranica/news-ubiega-sie-o-fotel-prezydenta-polske-traktuje-jak-druga-ojcz,nId,7409611](https://wydarzenia.interia.pl/zagranica/news-ubiega-sie-o-fotel-prezydenta-polske-traktuje-jak-druga-ojcz,nId,7409611)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-03-24T08:25:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ubiega-sie-o-fotel-prezydenta-polske-traktuje-jak-druga-ojcz,nId,7409611"><img align="left" alt="Ubiega się o fotel prezydenta. Polskę traktuje jak drugą ojczyznę" src="https://i.iplsc.com/ubiega-sie-o-fotel-prezydenta-polske-traktuje-jak-druga-ojcz/000ITX1X4JHQCF7P-C321.jpg" /></a>Malik Gakou, jeden z kandydatów ubiegających się o urząd prezydenta w Senegalu, jako drugą ojczyznę traktuje Polskę. 62-latek przed laty studiował w naszym kraju. W wywiadach zapewniał już, że jeśli wygra marcowe wybory, w pierwszą zagraniczną podróż wybierze się do Polski. W wyborach prezydenckich startuje także 17 innych kandydatów, wśród których znalazła się pierwsza od ponad dekady kobieta.</p><br clear="all" />

