# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Twórcy Crash Bandicoot N. Sane Trilogy współpracują z Microsoftem nad stworzeniem nowej gry
 - [https://ithardware.pl/aktualnosci/tworcy_crash_bandicoot_n_sane_trilogy_wspolpracuja_z_microsoftem_nad_stworzeniem_nowej_gry-32217.html](https://ithardware.pl/aktualnosci/tworcy_crash_bandicoot_n_sane_trilogy_wspolpracuja_z_microsoftem_nad_stworzeniem_nowej_gry-32217.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-24T20:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/32217_1.jpg" />            Jakiś czas temu tw&oacute;rcy Crash Bandicoot 4 i&nbsp;Spyro Reignited Trilogy zostali pozbawieni siedziby, a także zawisła nad nimi groźba całkowitego zamknięcia. Tak się jednak nie stało, a deweloperzy nawiązali wsp&oacute;łpracę z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tworcy_crash_bandicoot_n_sane_trilogy_wspolpracuja_z_microsoftem_nad_stworzeniem_nowej_gry-32217.html">https://ithardware.pl/aktualnosci/tworcy_crash_bandicoot_n_sane_trilogy_wspolpracuja_z_microsoftem_nad_stworzeniem_nowej_gry-32217.html</a></p>

## CD Projekt RED nie chce wydawać gier we wczesnym dostępie. Firma nie pójdzie śladami Larian
 - [https://ithardware.pl/aktualnosci/cd_projekt_red_nie_chce_wydawac_gier_we_wczesnym_dostepie_firma_nie_pojdzie_sladami_larian-32216.html](https://ithardware.pl/aktualnosci/cd_projekt_red_nie_chce_wydawac_gier_we_wczesnym_dostepie_firma_nie_pojdzie_sladami_larian-32216.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-24T15:36:20+00:00

<img src="https://ithardware.pl/artykuly/min/32216_1.jpg" />            Cyberpunk 2077 po latach łatania stał się wreszcie grą, kt&oacute;rą da radę spokojnie polecić. Stan nie jest idealny, ale i tak niepor&oacute;wnywalnie lepszy od tego co gra zaserwowała graczom w chwili premiery. Czy gdyby produkcję...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cd_projekt_red_nie_chce_wydawac_gier_we_wczesnym_dostepie_firma_nie_pojdzie_sladami_larian-32216.html">https://ithardware.pl/aktualnosci/cd_projekt_red_nie_chce_wydawac_gier_we_wczesnym_dostepie_firma_nie_pojdzie_sladami_larian-32216.html</a></p>

## Baldur's Gate 3 notuje świetną sprzedaż. Ujawnion nowe dane
 - [https://ithardware.pl/aktualnosci/baldur_s_gate_3_notuje_swietna_sprzedaz_ujawnion_nowe_dane-32215.html](https://ithardware.pl/aktualnosci/baldur_s_gate_3_notuje_swietna_sprzedaz_ujawnion_nowe_dane-32215.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-24T14:24:00+00:00

<img src="https://ithardware.pl/artykuly/min/32215_1.jpg" />            Baldur's Gate 3 to gra, kt&oacute;ra niewątpliwie odniosła sukces i stanowi zwieńczenie tej kultowej trylogii. Robi to w świetnym stylu, na co wskazują dane sprzedaży.

Ujawniono nowe wyniki sprzedaży Baldur's Gate 3

Około...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/baldur_s_gate_3_notuje_swietna_sprzedaz_ujawnion_nowe_dane-32215.html">https://ithardware.pl/aktualnosci/baldur_s_gate_3_notuje_swietna_sprzedaz_ujawnion_nowe_dane-32215.html</a></p>

## AMD podniosło limit OC pamięci Radeona RX 7900 GRE. Można liczyć na znaczący wzrost FPS
 - [https://ithardware.pl/aktualnosci/amd_podnioslo_limit_oc_pamieci_radeona_rx_7900_gre_mozna_liczyc_na_znaczacy_wzrost_fps-32214.html](https://ithardware.pl/aktualnosci/amd_podnioslo_limit_oc_pamieci_radeona_rx_7900_gre_mozna_liczyc_na_znaczacy_wzrost_fps-32214.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-24T11:47:40+00:00

<img src="https://ithardware.pl/artykuly/min/32214_1.jpg" />            AMD wydało nową wersję sterownik&oacute;w dla kart graficznych Radeon. Aktualizacja oznaczona jako Adrenalin Edition 24.3.1 wprowadza między innymi nowy limit podkręcania pamięci dla Radeona RX 7900 GRE.

Stare ograniczenia OC pamięci to...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_podnioslo_limit_oc_pamieci_radeona_rx_7900_gre_mozna_liczyc_na_znaczacy_wzrost_fps-32214.html">https://ithardware.pl/aktualnosci/amd_podnioslo_limit_oc_pamieci_radeona_rx_7900_gre_mozna_liczyc_na_znaczacy_wzrost_fps-32214.html</a></p>

## Acer Nitro 5 - laptop napędzany mocą NVIDIA® GeForce RTX™
 - [https://ithardware.pl/artykuly/acer_nitro_5_laptop_napedzany_moca_geforce_rtx-32032.html](https://ithardware.pl/artykuly/acer_nitro_5_laptop_napedzany_moca_geforce_rtx-32032.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-24T11:10:20+00:00

<img src="https://ithardware.pl/artykuly/min/32032_1.jpg" />            Acer Nitro 5 - laptop&nbsp;napędzane mocą GeForce RTX

&nbsp;



Rynek laptop&oacute;w co jakiś czas przechodzi prawdziwą rewolucję i wraz z wprowadzeniem najnowszych kart graficznych NVIDIA&reg; GeForce RTX&trade; 4000, jesteśmy świadkami...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/acer_nitro_5_laptop_napedzany_moca_geforce_rtx-32032.html">https://ithardware.pl/artykuly/acer_nitro_5_laptop_napedzany_moca_geforce_rtx-32032.html</a></p>

## AMD ma używać litografii 4 nm Samsunga do produkcji APU Ryzen i GPU Radeon
 - [https://ithardware.pl/aktualnosci/amd_ma_uzywac_litografii_4_nm_samsunga_do_produkcji_apu_ryzen_i_gpu_radeon-32213.html](https://ithardware.pl/aktualnosci/amd_ma_uzywac_litografii_4_nm_samsunga_do_produkcji_apu_ryzen_i_gpu_radeon-32213.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-24T10:26:40+00:00

<img src="https://ithardware.pl/artykuly/min/32213_1.jpg" />            AMD ma planować wykorzystanie procesu 4 nm od Samsunga do wytwarzania niekt&oacute;rych ze swoich chip&oacute;w. Według doniesień od znanego informatora, Czerwoni zamierzają użyć tej litografii do produkcji układ&oacute;w z niskiego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ma_uzywac_litografii_4_nm_samsunga_do_produkcji_apu_ryzen_i_gpu_radeon-32213.html">https://ithardware.pl/aktualnosci/amd_ma_uzywac_litografii_4_nm_samsunga_do_produkcji_apu_ryzen_i_gpu_radeon-32213.html</a></p>

## iPhone 16 może posiadać więcej RAM z powodu AI
 - [https://ithardware.pl/aktualnosci/iphone_16_moze_posiadac_wiecej_ram_z_powodu_ai-32212.html](https://ithardware.pl/aktualnosci/iphone_16_moze_posiadac_wiecej_ram_z_powodu_ai-32212.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-24T09:34:50+00:00

<img src="https://ithardware.pl/artykuly/min/32212_1.jpg" />            Według przewidywań Apple może wyposażyć iPhona 16 w większą ilość pamięci RAM. Jest to efekt wykorzystania sztucznej inteligencji na urządzeniu, do czego zwyczajnie potrzeba więcej pamięci. Apple ma jednak rozważać opcję użycia kości...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/iphone_16_moze_posiadac_wiecej_ram_z_powodu_ai-32212.html">https://ithardware.pl/aktualnosci/iphone_16_moze_posiadac_wiecej_ram_z_powodu_ai-32212.html</a></p>

