# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "Lukewarm" (Full Song)
 - [https://www.youtube.com/watch?v=1CVpHjj9bxM](https://www.youtube.com/watch?v=1CVpHjj9bxM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2024-03-24T12:00:02+00:00

This song was created using AI and remixing the riffs. I enjoyed it.
Watch the remix here: https://youtu.be/0fo_2Untavg

