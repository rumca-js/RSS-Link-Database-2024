# Source:TIME, URL:https://time.com/feed, language:en-UK

## Russia Concert Hall Attack Suspects Appear in a Moscow Courtroom
 - [https://time.com/6960153/russia-concert-hall-attack-suspects-moscow-courtroom](https://time.com/6960153/russia-concert-hall-attack-suspects-moscow-courtroom)
 - RSS feed: https://time.com/feed
 - date published: 2024-03-24T20:42:08+00:00

Suspects in the Russia concert hall attack, which left more than 130 dead, arrived at a Moscow district court on Sunday night.

## King Charles III ‘Frustrated’ By Speed of Cancer Recovery, Keen to ‘Get Back to Normality’
 - [https://time.com/6960101/king-charles-cancer-health-update-peter-phillips-interview](https://time.com/6960101/king-charles-cancer-health-update-peter-phillips-interview)
 - RSS feed: https://time.com/feed
 - date published: 2024-03-24T20:07:22+00:00

King Charles' nephew, Princess Anne's son Peter Phillips, shared an update on His Majesty's health and mindset amid his cancer diagnosis.

## Simon Harris Set to Be Youngest Ever Leader of Ireland After Taking Over as Fine Gael Head
 - [https://time.com/6960104/simon-harris-new-ireland-leader-fine-gael-head](https://time.com/6960104/simon-harris-new-ireland-leader-fine-gael-head)
 - RSS feed: https://time.com/feed
 - date published: 2024-03-24T19:32:20+00:00

Simon Harris is the new leader of Ireland’s Fine Gael political party and is poised to become the next Taoiseach (Prime Minister).

## Thousands Attend Palm Sunday Celebrations in Jerusalem Against Backdrop of War
 - [https://time.com/6960083/palm-sunday-christian-faithful-jerusalem-church-celebrations](https://time.com/6960083/palm-sunday-christian-faithful-jerusalem-church-celebrations)
 - RSS feed: https://time.com/feed
 - date published: 2024-03-24T15:53:17+00:00

Thousands of Christian faithful attended Palm Sunday celebrations at Jerusalem’s sacred Mount of Olives, as conflict surges in the background.

## The Hidden History of Those Who Wrote the Christian Story
 - [https://time.com/6960036/hidden-history-christianity-candida-moss](https://time.com/6960036/hidden-history-christianity-candida-moss)
 - RSS feed: https://time.com/feed
 - date published: 2024-03-24T13:39:14+00:00

The untold history of the people who helped Jesus' disciples and the Church share the Christian story.

## Kate Middleton and Prince William Break Silence After Cancer Diagnosis Reveal
 - [https://time.com/6960051/kate-middleton-prince-william-statement-cancer-diagnosis-update](https://time.com/6960051/kate-middleton-prince-william-statement-cancer-diagnosis-update)
 - RSS feed: https://time.com/feed
 - date published: 2024-03-24T13:12:59+00:00

The Prince and Princess of Wales are “extremely moved” by the outpouring of support following Kate's cancer diagnosis reveal.

## Biden and Trump Win Louisiana’s Presidential Primary Having Already Clinched Nominations
 - [https://time.com/6960047/biden-trump-louisiana-presidential-primary-win](https://time.com/6960047/biden-trump-louisiana-presidential-primary-win)
 - RSS feed: https://time.com/feed
 - date published: 2024-03-24T12:20:47+00:00

Biden and Trump won Louisiana's primary on Saturday, collecting more delegates after they already clinched their party nominations.

