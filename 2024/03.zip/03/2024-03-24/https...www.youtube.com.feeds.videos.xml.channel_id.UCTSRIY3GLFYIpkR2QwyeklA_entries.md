# Source:Drew Gooden, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTSRIY3GLFYIpkR2QwyeklA, language:en-US

## Netflix missed the point of Avatar
 - [https://www.youtube.com/watch?v=rZlx5vU4tSo](https://www.youtube.com/watch?v=rZlx5vU4tSo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTSRIY3GLFYIpkR2QwyeklA
 - date published: 2024-03-24T18:47:59+00:00

💻
Thanks to Opera for sponsoring this video! Get a browser that’s literally better at everything, download Opera today: https://opr.as/03-Opera-Browser-DrewGooden

i'm gonna go rewatch the animated show now

00:00 - intro
01:49 - a terrible first impression
12:43 - opera
13:54 - what is the point of an adaptation?
14:29 - sokka/suki
18:14 - katara
21:05 - aang
26:45 - things I liked
29:30 - oh no i'm getting mad again
34:50 - outro

merch:
https://www.drewgoodenshop.com/

follow me:
twitter - https://www.twitter.com/drewisgooden
instagram - https://www.instagram.com/drewisgooden

