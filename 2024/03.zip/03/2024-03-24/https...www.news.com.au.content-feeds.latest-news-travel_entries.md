# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## McDonald’s stores shut in Sri Lanka over poor hygiene case
 - [https://www.news.com.au/travel/travel-updates/health-safety/mcdonalds-stores-shut-in-sri-lanka-over-poor-hygiene-case/news-story/0fbdfe187af192da80db8ca33933d4ce?from=rss-basic](https://www.news.com.au/travel/travel-updates/health-safety/mcdonalds-stores-shut-in-sri-lanka-over-poor-hygiene-case/news-story/0fbdfe187af192da80db8ca33933d4ce?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-03-24T10:48:18.603921+00:00

McDonald’s stores across Sri Lanka shut on Sunday after the fast-food giant launched a legal battle with its local franchise holder over allegations of poor hygiene.

## Contiki doesn’t look like it used to
 - [https://www.news.com.au/finance/business/travel/gen-z-has-revolutionised-travel-but-one-thing-never-goes-out-of-style/news-story/b2d8b37eed006f423003b39faf3e6e2b?from=rss-basic](https://www.news.com.au/finance/business/travel/gen-z-has-revolutionised-travel-but-one-thing-never-goes-out-of-style/news-story/b2d8b37eed006f423003b39faf3e6e2b?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-03-24T08:38:45.758088+00:00

A brand as old as Levi’s and Converse is still the first stop for first-time travellers.

## ‘Act immediately’: Warning as fires rage
 - [https://www.news.com.au/technology/environment/perth-residents-urged-to-act-immediately-as-fires-continue-to-rage/news-story/28598bfbccca374fec8f52b4c5f6a70a?from=rss-basic](https://www.news.com.au/technology/environment/perth-residents-urged-to-act-immediately-as-fires-continue-to-rage/news-story/28598bfbccca374fec8f52b4c5f6a70a?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-03-24T08:38:44.286323+00:00

Residents are being urged to evacuate immediately as bushfires burn a major state forest.

