# Source:Gizmodo, URL:https://gizmodo.com/feed, language:en

## Gerard Way Returns to Comics with Paranoid Gardens
 - [https://gizmodo.com/gerard-way-paranoid-gardens-dark-horse-1851361831](https://gizmodo.com/gerard-way-paranoid-gardens-dark-horse-1851361831)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-03-24T20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/38aab868cd784813d5ffe9bee5bba051.jpg" /><p>Since 1994, My Chemical Romance frontman <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/gerard-ways-new-track-for-umbrella-academy-is-an-absolu-1832084457?_ga=2.160636217.585366997.1595186675-105069102.1526253072">Gerard Way</a> has dipped in and out of making comics. Beyond teaming with Gabriel Bá on <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/the-umbrella-academys-season-2-time-jump-into-the-past-1844378970?_ga=2.175420966.585366997.1595186675-105069102.1526253072">The Umbrella Academy</a>, he started <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/checking-in-on-the-weirdo-superhero-comics-dc-is-doing-1784145198">DC’s Young Animal imprint</a>, teamed with acclaimed artists such as Nick Derington and Becky Cloonan, and co-created

## Open Channel: Tell Us Your Thoughts on Ghostbusters: Frozen Empire
 - [https://gizmodo.com/open-channel-ghostbusters-frozen-empire-1851361538](https://gizmodo.com/open-channel-ghostbusters-frozen-empire-1851361538)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-03-24T18:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/c9d5a57668405286cac4413a35584ada.jpg" /><p>In 2021, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/ghostbusters-afterlife-is-great-until-its-derailed-by-1847571602">Ghostbusters: Afterlife</a> came onto the scene as the first new entry since the mixed <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/movie-review-ghostbusters-isnt-perfect-but-its-so-muc-1783418211">2016 reboot</a>, and as the official Ghostbusters 3 the franchise had been trying to birth for decades. A decent reception and solid box office success ensured it wouldn’t be a one-and-done, and here that sequel is with <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/ghostbusters-frozen-empire-movie-review-paul-rudd-finn-1851345433">Ghostbusters…</a></p><p><a href="https://gizmodo.com/open-channel-ghostbusters-frozen-e

## The Greatest App of All Time Day 24: Uber vs. Calculator
 - [https://gizmodo.com/the-greatest-app-of-all-time-uber-calculator-1851361715](https://gizmodo.com/the-greatest-app-of-all-time-uber-calculator-1851361715)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-03-24T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/9e804db2c258d2260c3a26b718b31fb1.jpg" /><p>It’s Day 22 of Gizmodo’s March Madness bracket challenge to name the greatest app of all time and we’ve reached the final round of the Sweet 16. Yesterday’s tournament saw Google Earth running away with more than 87 percent of the vote and HQ Trivia has been eliminated. RIP HQ Trivia. Today we have our most…</p><p><a href="https://gizmodo.com/the-greatest-app-of-all-time-uber-calculator-1851361715">Read more...</a></p>

## Night Swim and Lisa Frankenstein Bring Some Extra Horror to Peacock
 - [https://gizmodo.com/lisa-frankenstein-night-swim-peacock-streaming-dates-1851361724](https://gizmodo.com/lisa-frankenstein-night-swim-peacock-streaming-dates-1851361724)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-03-24T16:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/91c72cb6e91ddc08ceafcc20eb0c8602.jpg" /><p>If you ended up missing either <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/night-swim-review-movie-blumhouse-killer-pool-horror-1851140206">Night Swim</a> or <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/defense-of-lisa-frankenstein-horror-movie-diablo-cody-1851261426">Lisa Frankenstein</a> during their respective runs, Peacock’s got covered. The two Universal films are landing on NBCUniversal’s streaming platform over the next two weeks—Lisa will drop next Friday, March 29, while Night Swim arrives the following week on April 5.<br /></p><p><a href="https://gizmodo.com/lisa-frankenstein-night-swim-peacock-streaming-dates-1851361724">Read more...</a></p>

## Studio Ghibli Fest Returns with Even More Classics Hitting Theaters
 - [https://gizmodo.com/studio-ghibli-fest-2024-films-re-releases-1851361471](https://gizmodo.com/studio-ghibli-fest-2024-films-re-releases-1851361471)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-03-24T14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/251d1cb969ef42848af92eb494dbb2a3.jpg" /><p>Last year, GKids and Fathom Events re-released nine of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/boy-and-heron-review-hayao-miyazaki-studio-ghibli-anime-1850941832">Hayao Miyazaki’s</a> films into theaters as part of its annual <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/studio-ghibli-fest-2023-us-dates-miyazaki-spirited-away-1850167659">Studio Ghibli Fest</a>. It ended up being the most successful marathon yet—”millions” participated, according to GKIDS President David Jesteadt. This year is bringing the tradition back, and it’s got more…</p><p><a href="https://gizmodo.com/studio-ghibli-fest-2024-films-re-releases-1851361471">Read more...</a></p>

