# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Big Tech's Latest Obsession Is Finding Enough Energy
 - [https://www.wsj.com/articles/big-techs-latest-obsession-is-finding-enough-energy-f00055b2?mod=rss_Technology](https://www.wsj.com/articles/big-techs-latest-obsession-is-finding-enough-energy-f00055b2?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-03-24T11:00:00+00:00

The AI boom is fueling an insatiable appetite for electricity, which is creating risks to the grid and the transition to cleaner energy sources.

## Elon Musk's X Needs Creators, but They Don't Need X
 - [https://www.wsj.com/articles/elon-musk-x-content-creators-recruitment-f104dc77?mod=rss_Technology](https://www.wsj.com/articles/elon-musk-x-content-creators-recruitment-f104dc77?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-03-24T09:30:00+00:00

Despite the platform’s push, many creators say X is still a long way from becoming a major source of revenue for them.

## Bad Haircut? A Hot Chinese App Is Giving Americans Blunt Advice
 - [https://www.wsj.com/articles/bad-haircut-a-hot-chinese-app-is-giving-americans-blunt-advice-b82e67e2?mod=rss_Technology](https://www.wsj.com/articles/bad-haircut-a-hot-chinese-app-is-giving-americans-blunt-advice-b82e67e2?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-03-24T01:00:00+00:00

Xiaohongshu, a mix of Instagram and Reddit, is a destination for personal-style suggestions.

