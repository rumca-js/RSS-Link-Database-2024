# Source:Novaspirit Tech, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCrjKdwxaQMSV_NDywgKXVmw, language:en

## Dual Boot Windows and Linux With rEFInd
 - [https://www.youtube.com/watch?v=1vEkn_kcXas](https://www.youtube.com/watch?v=1vEkn_kcXas)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCrjKdwxaQMSV_NDywgKXVmw
 - date published: 2024-03-24T13:00:04+00:00

○○○ LINKS ○○○

https://www.rodsbooks.com/refind/
https://github.com/topics/refind-theme

○○○ SHOP ○○○

Novaspirit Shop ► https://teespring.com/stores/novaspirit-tech

Amazon Store ► http://amzn.to/2AYs3dI

○○○ SUPPORT ○○○
💗 Patreon ► https://goo.gl/xpgbzB

○○○ SOCIAL ○○○
🎮 Twitch ► https://twitch.tv/novaspirit
🎮 Pandemic Playground ► https://www.youtube.com/channel/UCuplGze2Zq63gu2Axd2_eKA 
▶️ novaspirit tv ► https://goo.gl/uokXYr
🎮 Novaspirit Gaming ► https://www.youtube.com/channel/UCKPqnB9itH7to4923ZVo-2Q
🐤 Twitter ► https://twitter.com/novaspirittech
👾 Discord chat ► https://discord.gg/v8dAnFV
FB Group Novaspirit ► https://www.facebook.com/groups/novasspirittech


○○○ Send Me Stuff ○○○
Don Hui
PO BOX 765
Farmingville, NY 11738

○○○ Music ○○○
From Epidemic Sounds


patreon @ https://patreon.com/novaspirittech
Tweet me: @ http://twitter.com/novaspirittech
facebook: @ http://facebook.com/novaspirittech
Instagram @ https://instagram.com/novaspirittech

DISCLAIMER: This video 

