# Source:Argentina - Buenos Aires Times, URL:https://www.batimes.com.ar/feed, language:en

## Milei government casts doubt over dictatorship crimes on Memory Day
 - [https://www.batimes.com.ar/news/argentina/milei-government-casts-doubt-over-dictatorship-crimes-on-memory-day.phtml](https://www.batimes.com.ar/news/argentina/milei-government-casts-doubt-over-dictatorship-crimes-on-memory-day.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-03-24T21:49:54+00:00

<p><img alt="24 de marzo rally protest" src="https://fotos.perfil.com/2024/03/24/trim/540/304/24-de-marzo-rally-protest-1775461.jpg" /></p>Milei administration echoes vice-president's line, demanding justice for "the victims of terrorism" during military dictatorship era and questioning 30,000 disappeared estimate from human rights groups. <a href="https://www.batimes.com.ar/news/argentina/milei-government-casts-doubt-over-dictatorship-crimes-on-memory-day.phtml">Leer más</a>

## Argentines send message to Milei with march in memory of dictatorship
 - [https://www.batimes.com.ar/news/argentina/argentines-send-message-to-milei-with-march-in-memory-of-dictatorship.phtml](https://www.batimes.com.ar/news/argentina/argentines-send-message-to-milei-with-march-in-memory-of-dictatorship.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-03-24T20:03:47+00:00

<p><img alt="March 24 rally" src="https://fotos.perfil.com/2024/03/24/trim/540/304/march-24-rally-1775430.jpg" /></p>Huge crowds head to Plaza de Mayo to mark the 48th anniversary of the coup d'état that brought Argentina’s brutal 1976-1983 military dictatorship to power, resulting in the disappearance, exile and execution of tens of thousands of people in secret death camps across the country.  <a href="https://www.batimes.com.ar/news/argentina/argentines-send-message-to-milei-with-march-in-memory-of-dictatorship.phtml">Leer más</a>

