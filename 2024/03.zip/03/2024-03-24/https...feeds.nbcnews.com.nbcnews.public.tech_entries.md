# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## A modern-day woolly mammoth may be just a few years away, biotech company says
 - [https://www.nbcnews.com/nightly-news/video/a-modern-day-woolly-mammoth-may-be-just-a-few-years-away-biotech-company-says-207585349632](https://www.nbcnews.com/nightly-news/video/a-modern-day-woolly-mammoth-may-be-just-a-few-years-away-biotech-company-says-207585349632)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-03-24T23:01:44+00:00

Colossal Biosciences, a Dallas-based biotechnology company, says it has developed the technology necessary to bring the woolly mammoth back from extinction. NBC News’ Morgan Chesky reports on the opportunities this new technology could bring as well as the concerns some scientists are raising.

## Stephen Breyer says he’d be ‘amazed’ if a Supreme Court justice was behind the Dobbs leak
 - [https://www.nbcnews.com/meet-the-press/video/stephen-breyer-says-he-d-be-amazed-if-a-supreme-court-justice-was-behind-the-dobbs-leak-207575109681](https://www.nbcnews.com/meet-the-press/video/stephen-breyer-says-he-d-be-amazed-if-a-supreme-court-justice-was-behind-the-dobbs-leak-207575109681)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-03-24T13:51:32+00:00

Former Supreme Court Justice Stephen Breyer tells Kristen Welker he has his own “theories” about who leaked the decision to overturn Roe v. Wade.

