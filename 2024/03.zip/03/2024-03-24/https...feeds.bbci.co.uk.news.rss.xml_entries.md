# Source:BBC, URL:https://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Russia charges four men over Moscow concert attack
 - [https://www.bbc.co.uk/news/world-europe-68652380](https://www.bbc.co.uk/news/world-europe-68652380)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T23:00:37+00:00

Suspects appear in a Moscow court accused of an act of terrorism at Crocus City Hall, where 137 people were killed.

## Arsenal fight back to fuel title chase with win at Villa
 - [https://www.bbc.co.uk/sport/football/68589819](https://www.bbc.co.uk/sport/football/68589819)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T22:13:53+00:00

Arsenal fuel their chase of the Women's Super League title as they come from behind to beat Aston Villa at Villa Park.

## Junior doctors in Wales to begin four-day strike
 - [https://www.bbc.com/news/articles/c4nv9yxv03do](https://www.bbc.com/news/articles/c4nv9yxv03do)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T21:55:11+00:00

Junior doctors are set to begin their longest walk-out to date in an ongoing dispute over pay.

## Murder arrest at Heathrow after man hit by car
 - [https://www.bbc.co.uk/news/uk-england-london-68651829](https://www.bbc.co.uk/news/uk-england-london-68651829)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T21:31:00+00:00

A 33-year-old man was arrested at the airport on Sunday afternoon, following the death of another man, 35.

## England will return 'stronger' - Packer proud of 100 caps
 - [https://www.bbc.co.uk/sport/rugby-union/68651867](https://www.bbc.co.uk/sport/rugby-union/68651867)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T20:35:30+00:00

England will "come back stronger" after winning their opening Women's Six Nations game against Italy, says captain Marlie Packer.

## West Ham boss Skinner 'sick' of wrong decisions
 - [https://www.bbc.co.uk/sport/football/68652064](https://www.bbc.co.uk/sport/football/68652064)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T20:29:04+00:00

West Ham boss Rehanne Skinner says she is "getting a bit sick" of incorrect decisions after having a goal ruled out against Chelsea on Sunday.

## England's Walker & Maguire ruled out of Belgium game
 - [https://www.bbc.co.uk/sport/football/68651573](https://www.bbc.co.uk/sport/football/68651573)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T20:01:47+00:00

England defenders Kyle Walker and Harry Maguire are ruled out of Tuesday's friendly with Belgium.

## I ran 'toughest race' to inspire women worldwide
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-68651150](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-68651150)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T19:21:23+00:00

Jasmin Paris made history by becoming the first woman to finish the gruelling 100-mile Barkley Marathons.

## Private funeral to be held for Strictly's Windsor
 - [https://www.bbc.co.uk/news/uk-england-suffolk-68651672](https://www.bbc.co.uk/news/uk-england-suffolk-68651672)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T18:59:01+00:00

Robin Windsor's funeral will be held in his home town of Ipswich on Tuesday.

## Young girl and woman die after being hit by car
 - [https://www.bbc.co.uk/news/uk-england-devon-68650043](https://www.bbc.co.uk/news/uk-england-devon-68650043)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T18:49:42+00:00

Police say they sustained serious injuries and were taken to hospital, but later died.

## Chelsea win at West Ham to return to top of WSL
 - [https://www.bbc.co.uk/sport/football/68589817](https://www.bbc.co.uk/sport/football/68589817)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T18:41:33+00:00

Chelsea return to the top of the Women's Super League with a battling 2-0 victory at West Ham.

## England comfortably beat Italy despite Beckett red card
 - [https://www.bbc.co.uk/sport/av/rugby-union/68646307](https://www.bbc.co.uk/sport/av/rugby-union/68646307)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T17:57:24+00:00

Watch highlights as a 14-player England side record a bonus-point win over Italy after Sarah Beckett was sent off in their Women's Six Nations opener in Parma.

## England win Six Nations opener as Beckett sent off
 - [https://www.bbc.co.uk/sport/rugby-union/68639619](https://www.bbc.co.uk/sport/rugby-union/68639619)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T17:47:07+00:00

A 14-player England side record a bonus-point win over Italy after Sarah Beckett's red card in their Women's Six Nations opener in Parma.

## Avanti to pay train drivers £600 a shift for overtime
 - [https://www.bbc.co.uk/news/business-68650114](https://www.bbc.co.uk/news/business-68650114)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T17:43:24+00:00

West Coast Main Line drivers to receive £600 a shift, up from £125, after company strikes deal with union.

## Overturned lorry and car crash leads to M40 delays
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-68651664](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-68651664)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T17:36:25+00:00

Drivers wait in long queues after a lorry and a car crash in separate incidents in Buckinghamshire.

## Boy, 12, charged with attempted murder
 - [https://www.bbc.com/news/articles/c9w90849xx7o](https://www.bbc.com/news/articles/c9w90849xx7o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T17:22:13+00:00

A 15-year-old girl was stabbed in Sittingbourne on Friday, Kent Police said.

## Simon Harris set to be youngest Irish PM after becoming party leader
 - [https://www.bbc.co.uk/news/world-europe-68650644](https://www.bbc.co.uk/news/world-europe-68650644)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T16:56:53+00:00

The 37-year-old is now on course to become Ireland's youngest taoiseach (prime minister).

## Five-try Bath beat Sale to move up to second
 - [https://www.bbc.co.uk/sport/rugby-union/68627282](https://www.bbc.co.uk/sport/rugby-union/68627282)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T16:45:56+00:00

Finn Russell kicks 18 points as Bath beat Sale 42-24 to move up to second in the Premiership.

## Kildunne extends England's lead with 'lovely' run
 - [https://www.bbc.co.uk/sport/av/rugby-union/68650592](https://www.bbc.co.uk/sport/av/rugby-union/68650592)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T16:33:34+00:00

Watch as Ellie Kildunne extends England's lead against Italy after a "lovely" run at the Women's Six Nations in Parma.

## Tame WSL Merseyside derby ends in draw at Goodison
 - [https://www.bbc.co.uk/sport/football/68589818](https://www.bbc.co.uk/sport/football/68589818)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T15:12:02+00:00

Everton and Liverpool play out a goalless draw in the Merseyside derby in an uneventful afternoon at Goodison Park.

## Rosenberg: As Russia mourns, how will Putin react to concert attack?
 - [https://www.bbc.co.uk/news/world-europe-68650914](https://www.bbc.co.uk/news/world-europe-68650914)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T15:01:58+00:00

More than 130 people were killed when gunmen entered a packed Moscow venue and opened fire.

## Watch: Ready, steady, eau! Waiters race returns to Paris
 - [https://www.bbc.co.uk/news/world-europe-68649600](https://www.bbc.co.uk/news/world-europe-68649600)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T14:53:46+00:00

The competition for waiters and waitresses began in 1914, but has not been held since 2011 due to lack of sponsors.

## Give Kate and family space to heal, says ex-royal aide
 - [https://www.bbc.co.uk/news/uk-68650322](https://www.bbc.co.uk/news/uk-68650322)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T14:45:14+00:00

The Royal Family will get back to normal after "this sticky patch", says ex-royal spokesman Paddy Harverson.

## Passenger reported overboard from cruise ship
 - [https://www.bbc.co.uk/news/uk-england-hampshire-68650734](https://www.bbc.co.uk/news/uk-england-hampshire-68650734)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T14:23:32+00:00

The man was reported missing from the MSC Euribia which left Southampton on 15 March.

## Newscast
 - [https://www.bbc.co.uk/sounds/play/p0hlm7jr](https://www.bbc.co.uk/sounds/play/p0hlm7jr)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T13:50:00+00:00

The chancellor tells Laura pensions would rise by at least 2.5% under Tories.

## Zelensky hits back after Russia blames Ukraine for concert attack
 - [https://www.bbc.co.uk/news/world-europe-68649229](https://www.bbc.co.uk/news/world-europe-68649229)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T13:14:53+00:00

Ukraine's leader says Russians should ask questions of their own security services instead.

## Four dead in Armagh car crash
 - [https://www.bbc.co.uk/news/uk-northern-ireland-68649286](https://www.bbc.co.uk/news/uk-northern-ireland-68649286)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T12:26:39+00:00

The driver and three passengers were declared dead at the scene.

## New road schemes in Wales could be considered again
 - [https://www.bbc.co.uk/news/uk-wales-68649940](https://www.bbc.co.uk/news/uk-wales-68649940)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T12:24:43+00:00

An M4 relief road and a third Menai crossing were some of the projects that never went ahead.

## 'From the operating table to victory - a redemption story for Sainz'
 - [https://www.bbc.co.uk/sport/formula1/68649296](https://www.bbc.co.uk/sport/formula1/68649296)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T12:20:50+00:00

To go from an operation to a grand prix victory in such a short time, as Carlos Sainz did in Australia, is both remarkable and entirely typical of what F1 drivers do.

## SWPL Cup final: Rangers extend lead over Thistle
 - [https://www.bbc.co.uk/sport/live/football/68592535](https://www.bbc.co.uk/sport/live/football/68592535)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T12:20:28+00:00

Rangers take on Partick Thistle in the SWPL Cup final at Tynecastle. Follow live updates and listen to BBC Scotland's Sportsound.

## 'Political mood has changed' on assisted dying - MSP
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-68645698](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-68645698)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T12:16:24+00:00

The MSP behind a new attempt to legalise assisted dying for terminally-ill people says he is "convinced" it will be passed.

## Triple lock for pensions if we win election - Hunt
 - [https://www.bbc.co.uk/news/business-68649894](https://www.bbc.co.uk/news/business-68649894)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T11:29:13+00:00

Chancellor Jeremy Hunt says he will pay for the "expensive" pledge through economic growth.

## Is this a chance for a fresh start for Palestinian politics?
 - [https://www.bbc.co.uk/news/world-middle-east-68636033](https://www.bbc.co.uk/news/world-middle-east-68636033)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T11:21:40+00:00

With many challenges ahead, the future of Palestinian leadership is yet to be decided, writes Lucy Williamson.

## Brazil defeat 'good experiment' for England - Southgate
 - [https://www.bbc.co.uk/sport/av/football/68650085](https://www.bbc.co.uk/sport/av/football/68650085)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T10:39:54+00:00

England manager Gareth Southgate says his side's 1-0 defeat by Brazil was a "good experiment" and a chance to "find out" about the squad's more inexperienced players.

## Mayor rules out changes to Ulez while mayor
 - [https://www.bbc.co.uk/news/uk-england-london-68645199](https://www.bbc.co.uk/news/uk-england-london-68645199)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T10:15:17+00:00

Sadiq Khan says Ulez will not include pay-per-mile charges or tighter restrictions while he is mayor.

## Alonso penalised over Russell crash incident
 - [https://www.bbc.co.uk/sport/formula1/68649182](https://www.bbc.co.uk/sport/formula1/68649182)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T09:47:19+00:00

Aston Martin driver Fernando Alonso is penalised 20 seconds for "potentially dangerous driving" at the Australian Grand Prix.

## Woman arrested as missing young siblings found
 - [https://www.bbc.co.uk/news/uk-england-gloucestershire-68649830](https://www.bbc.co.uk/news/uk-england-gloucestershire-68649830)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T09:44:13+00:00

Three siblings who were reported missing on Friday have now been found, police said.

## 'Most unwanted' dog finds home after four years
 - [https://www.bbc.co.uk/news/uk-england-leeds-68638925](https://www.bbc.co.uk/news/uk-england-leeds-68638925)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T08:58:59+00:00

Dogs Trust Leeds staff say it was emotional to see lurcher Jake finally rehomed in Keighley.

## Horizon scandal 'hitting post office recruitment'
 - [https://www.bbc.com/news/articles/cd18xj71vqzo](https://www.bbc.com/news/articles/cd18xj71vqzo)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T08:04:16+00:00

Liberal Democrat Tim Farron says the scandal is putting off potential candidates to run branches.

## Severino disqualified for biting Lima in UFC fight
 - [https://www.bbc.co.uk/sport/mixed-martial-arts/68649309](https://www.bbc.co.uk/sport/mixed-martial-arts/68649309)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T08:03:42+00:00

Igor Severino is disqualified from UFC Fight Night in Las Vegas after biting Andre Lima on the arm during their flyweight bout.

## Sainz wins Australian Grand Prix after Verstappen retires
 - [https://www.bbc.co.uk/sport/formula1/68649128](https://www.bbc.co.uk/sport/formula1/68649128)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T08:02:03+00:00

Carlos Sainz leads Charles Leclerc to a Ferrari one-two in the Australian Grand Prix as Max Verstappen's domination of Formula 1 stalls.

## Chancellor to be quizzed after inflation hits lowest level in over two years
 - [https://www.bbc.co.uk/news/live/uk-politics-68639367](https://www.bbc.co.uk/news/live/uk-politics-68639367)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T08:00:59+00:00

Jeremy Hunt is back in the red seat after sharing the last Budget before the general election

## Hygiene poverty is a sign of crisis, says charity
 - [https://www.bbc.co.uk/news/uk-england-london-68630920](https://www.bbc.co.uk/news/uk-england-london-68630920)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T07:54:53+00:00

The Hygiene Bank says families feel shame and isolation when they cannot afford to buy toiletries.

## Chichester teen gets British water ski team spot
 - [https://www.bbc.com/news/articles/c2v95jvv830o](https://www.bbc.com/news/articles/c2v95jvv830o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T07:16:57+00:00

Willow Skipsey started water skiing just 18-months ago and has now been chosen for a national squad.

## Unique Roman helmet found in field on display again
 - [https://www.bbc.co.uk/news/uk-england-leicestershire-68627992](https://www.bbc.co.uk/news/uk-england-leicestershire-68627992)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T07:08:25+00:00

The helmet, found more than 20 years ago, is being displayed again at a museum.

## Watch: Swans make heart shape during courtship dance
 - [https://www.bbc.co.uk/news/uk-england-nottinghamshire-68640686](https://www.bbc.co.uk/news/uk-england-nottinghamshire-68640686)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T07:08:03+00:00

The "romantic" ritual happens when a pair of swans establish a territory, a wildlife trust says.

## Abductors release more than 280 Nigerian pupils
 - [https://www.bbc.co.uk/news/world-africa-68649221](https://www.bbc.co.uk/news/world-africa-68649221)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T07:00:22+00:00

Gunmen rode through the school in Kuriga in north-western Nigeria seizing children as young as eight.

## Kyiv hit by multiple blasts as Russia strikes Ukraine
 - [https://www.bbc.co.uk/news/world-europe-68648815](https://www.bbc.co.uk/news/world-europe-68648815)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T06:31:39+00:00

All of Ukraine is on alert and the Polish air force activated after blasts are reported around Lviv.

## England collapse gifts New Zealand win in third T20
 - [https://www.bbc.co.uk/sport/cricket/68648845](https://www.bbc.co.uk/sport/cricket/68648845)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T06:23:14+00:00

A remarkable collapse from England hands New Zealand a dramatic three-run victory in the third T20 as the hosts keep the series alive in Nelson.

## Harris set to succeed Varadkar as new Fine Gael leader
 - [https://www.bbc.co.uk/news/world-europe-68639607](https://www.bbc.co.uk/news/world-europe-68639607)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T06:16:33+00:00

With no other candidates in the running, Simon Harris has a clear run at party's top job.

## Simon Harris - the man on the brink of Irish history
 - [https://www.bbc.co.uk/news/world-europe-68624474](https://www.bbc.co.uk/news/world-europe-68624474)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T06:16:23+00:00

The favourite to replace Leo Varadkar as taoiseach organised his first political meeting aged 16.

## The Papers: Kate 'reassures nation' and 'murderous' Moscow attack
 - [https://www.bbc.co.uk/news/blogs-the-papers-68648684](https://www.bbc.co.uk/news/blogs-the-papers-68648684)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T05:50:17+00:00

Nearly all of Sunday's papers lead with reaction to news of the Princess of Wales's cancer diagnosis.

## Watch: Lights out at famous landmarks for Earth Hour
 - [https://www.bbc.co.uk/news/world-68648866](https://www.bbc.co.uk/news/world-68648866)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T03:27:25+00:00

Iconic buildings around the world go dark as part of the annual Earth Hour environmental campaign.

## ‘Having a certificate of loss proves my baby existed’
 - [https://www.bbc.co.uk/news/uk-68593787](https://www.bbc.co.uk/news/uk-68593787)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T00:46:27+00:00

Women who have lost pregnancies before 24 weeks share their feelings about baby loss certificates.

## Pilgrimage helped Traitors star Amanda say 'goodbye mum'
 - [https://www.bbc.co.uk/news/uk-68633812](https://www.bbc.co.uk/news/uk-68633812)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T00:24:32+00:00

The star of the first series of BBC show on the celebrity walk that helped her deal with her grief.

## How jealous K-pop super fans try to dictate their idols' private lives
 - [https://www.bbc.co.uk/news/world-asia-68572668](https://www.bbc.co.uk/news/world-asia-68572668)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T00:07:05+00:00

They invest massive amounts of time and money - and expect control of their K-pop idol's private lives.

## Your pictures on the theme of 'reflections'
 - [https://www.bbc.co.uk/news/in-pictures-68615860](https://www.bbc.co.uk/news/in-pictures-68615860)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T00:06:44+00:00

A selection of striking images from our readers around the world.

## The man in the iron lung: How Paul Alexander lived life to the full
 - [https://www.bbc.co.uk/news/health-68627630](https://www.bbc.co.uk/news/health-68627630)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-24T00:06:37+00:00

He spent 72 years using an iron lung machine to breathe after surviving polio as a child.

