# Source:NBC world, URL:https://feeds.nbcnews.com/nbcnews/public/world, language:en-US

## Death toll climbs as Russia holds day of mourning for terror attack victims
 - [https://www.nbcnews.com/nightly-news/video/death-toll-climbs-as-russia-holds-day-of-mourning-for-terror-attack-victims-207586373695](https://www.nbcnews.com/nightly-news/video/death-toll-climbs-as-russia-holds-day-of-mourning-for-terror-attack-victims-207586373695)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2024-03-24T23:00:53+00:00

Moscow fell silent as Russians, joined by President Vladimir Putin, held a national day of mourning for the victims of Friday’s terror attack at a concert hall. It was the deadliest terror attack Russia has seen in 20 years, as the death toll rose to at least 137 people. While ISIS claimed responsibility for the attack, President Putin repeatedly implicated Ukraine. NBC News’ Matt Bradley reports.

## Pope condemns Moscow concert attack as 'inhuman actions'
 - [https://www.nbcnews.com/video/pope-condemns-moscow-concert-attack-as-inhuman-actions-207576645571](https://www.nbcnews.com/video/pope-condemns-moscow-concert-attack-as-inhuman-actions-207576645571)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/world
 - date published: 2024-03-24T12:57:32+00:00

Following the Palm Sunday mass in St. Peter's Square, Pope Francis condemned the terror attack on a Moscow concert hall. Francis said the attacks, which have claimed the lives of more than 130 people, "offend God."

