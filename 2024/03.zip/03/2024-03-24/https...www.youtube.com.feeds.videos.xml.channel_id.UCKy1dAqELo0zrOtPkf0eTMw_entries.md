# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Shadows of the Damned: Remastered - Official PAX East 2024 Trailer
 - [https://www.youtube.com/watch?v=Y2l2CVQqxhw](https://www.youtube.com/watch?v=Y2l2CVQqxhw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-03-24T16:31:52+00:00

Shadows of the Damned: Remastered is a remake of 2011's action-adventure game developed by Grasshopper Manufacture Inc. Players will journey into a "Hell Rock and Roll" themed world as demon hunter Garcia Hotspur to makes his way through the darkest depths of Hell. Garcia proceeds by lighting up the darkness with his burning passion to rescue his true love from an insidious demon king. Shadows of the Damned: Remastered is launching soon for PlayStation 4 (PS4), PlayStation 5 (PS5), Xbox One, Xbox Series S|X, Nintendo Switch, and PC with a demo available on the show floor at PAX East 2024.

#IGN #Gaming #PAXEast2024 #ShadowsOfTheDamned

## Granblue Fantasy Versus: Rising - Official Vane Gameplay Trailer
 - [https://www.youtube.com/watch?v=sXO843yVECs](https://www.youtube.com/watch?v=sXO843yVECs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-03-24T13:31:46+00:00

Granblue Fantasy Versus: Rising is a 2D anime multiplayer action fighting game developed by Cygames Inc. and Arc System Works. A new character approaches in the form of a playable DLC character being Vane. Watch the gameplay trailer to see the gameplay of Vane, the vice-captain of the White Dragons and chef extraordinaire. Vane is coming to Granblue Fantasy Versus: Rising on April 2 for PlayStation 4 (PS4), PlayStation 5 (PS5), and PC.

#IGN #Gaming #GranblueFantasyVersusRising #Vane

