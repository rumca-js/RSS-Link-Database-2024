# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## Ekonomia rynku podatności, czyli jak kupuje się błędy?
 - [https://www.youtube.com/watch?v=9lwDu6HIeio](https://www.youtube.com/watch?v=9lwDu6HIeio)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2024-03-24T17:00:11+00:00

💰 Jak kupuje się Pegasusa? Przede wszystkim; za nie swoje pieniądze, a podatników i to zawsze są najprzyjemniejsze zakupy. Znaleźliśmy się w sytuacji, że ofensywne oprogramowanie do inwigilacji na nieznaną wcześniej skalę sprzedawane jest przez prywatne firmy, o których niewiele tak naprawdę wiadomo. Jak działa cały przemysł handlu podatnościami? No i czy w ogóle można coś z nim zrobić?
 
🕵🏻 Buying Spying: How the commercial surveillance industry works and what can be done about it
https://blog.google/threat-analysis-group/commercial-surveillance-vendors-google-tag-report/

🇺🇸 Executive Order on Prohibition on Use by the United States Government of 
Commercial Spyware that Poses Risks to National Security
https://www.whitehouse.gov/briefing-room/presidential-actions/2023/03/27/executive-order-on-prohibition-on-use-by-the-united-states-government-of-commercial-spyware-that-poses-risks-to-national-security/

💻 Joint Statement on Efforts to Counter the Proliferation and Misuse o

