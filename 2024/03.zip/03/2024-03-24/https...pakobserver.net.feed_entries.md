# Source:Pakistan Observer, URL:https://pakobserver.net/feed, language:en-US

## PCB announces national selection committee
 - [https://pakobserver.net/pcb-announces-national-selection-committee](https://pakobserver.net/pcb-announces-national-selection-committee)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T11:13:09+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/03/pcb-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE: Pakistan Cricket Board (PCB) Chairman Mohsin Naqvi has announced a seven-member national selection committee. Speaking at a press conference along with newly nominated members at PCB headquarters at Gaddafi Stadium on Sunday, he said that there will be no chairman and all seven members will have equal powers. The selection committee will consist of [&#8230;]

## Lahore receives light rain
 - [https://pakobserver.net/lahore-receives-light-rain](https://pakobserver.net/lahore-receives-light-rain)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T10:26:45+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/LW-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Parts of Punjab including Lahore received rainfall of varying intensities on Sunday, making the weather pleasant. Experts have predicted partly cloudy weather with chances of rains for upper districts during the next two days. Rainfall (mm): Bhakkar 18, Jhang 13, Faisalabad 12, Hafizabad, Joharabad, Sargodha 04, Okara, Sheikhupura, T T Singh 03, Lahore [&#8230;]

## UHS declares Doctor of Physical Therapy result
 - [https://pakobserver.net/uhs-declares-doctor-of-physical-therapy-result](https://pakobserver.net/uhs-declares-doctor-of-physical-therapy-result)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T09:55:35+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/uhs-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; The University of Health Sciences (UHS) released the result of the first professional Doctor of Physical Therapy (DPT) annual examinations 2023. According to the notification issued on Saturday, 445 candidates from 18 colleges appeared for the examination, out of which 269 passed and 171 failed. Thus the success rate was 61.14 per cent. [&#8230;]

## Torkham border closed for pedestrians after FIA, FC officials clash
 - [https://pakobserver.net/torkham-border-closed-for-pedestrians-after-fia-fc-officials-clash](https://pakobserver.net/torkham-border-closed-for-pedestrians-after-fia-fc-officials-clash)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T09:44:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/03/torkham-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />PESHAWAR &#8211; The Torkham border crossing between Pakistan and Afghanistan has been closed to pedestrians after a clash between the officials of the Frontier Corps (FC) and the Federal Investigation Agency (FIA). As many as five people were shifted to Landi Kotal Hospital after they sustained injuries during the clash. Their condition is reported to be [&#8230;]

## Torkham border reopened for pedestrians after four hours closure
 - [https://pakobserver.net/torkham-border-reopened-for-pedestrians-after-four-hours-closure](https://pakobserver.net/torkham-border-reopened-for-pedestrians-after-four-hours-closure)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T09:44:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/03/torkham-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />PESHAWAR &#8211; The Torkham border crossing between Pakistan and Afghanistan has been reopened for pedestrians after a brief closure due to a clash between Frontier Corps (FC) and Federal Investigation Agency (FIA) officials on Sunday. As many as five people were shifted to Landi Kotal Hospital after they sustained injuries during the clash. Their condition is [&#8230;]

## PCB dissolves national selection committee
 - [https://pakobserver.net/pcb-dissolves-national-selection-committee](https://pakobserver.net/pcb-dissolves-national-selection-committee)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T09:10:50+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/03/MN-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; The Pakistan Cricket Board (PCB) has dissolved the national selection committee ahead of the ICC T20 World Cup 2024. Former left-arm pacer Wahab Riaz was heading the committee which included former off-spinner Tauseef Ahmed, opener Wajahatullah Wasti and Wasim Haider. Kamran Akmal and Rao Iftikhar were the consultants while Hasan Muzaffar Cheema was the [&#8230;]

## Currency exchange rates in Pakistan today – March 24, 2024
 - [https://pakobserver.net/currency-exchange-rates-in-pakistan-today-march-24-2024](https://pakobserver.net/currency-exchange-rates-in-pakistan-today-march-24-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T05:08:18+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/curreny-rate-today-15-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI—On Sunday, March 24, 2024, the exchange rate for one US Dollar against Pakistani rupees was recorded at Rs 278.2 in the local and open market, with a selling rate of Rs 280.95. Note: Exchange rates can vary based on the location and the Exchange Company or bank involved in the transaction. Below are the foreign [&#8230;]

## Gold rate in Pakistan today – 24 March, 2024
 - [https://pakobserver.net/gold-rate-in-pakistan-today-24-march-2024](https://pakobserver.net/gold-rate-in-pakistan-today-24-march-2024)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T05:06:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/gold-rate-in-pakistan-today-24-March-2023-1-1024x576-4-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI—On Sunday, March 24, 2024, the 24-karat gold rate was PKR 225,150. Similarly, the bullion market recorded the gold price for 24-karat at Rs 193,030 per 10g. Gold Price in Pakistan’s different cities. City Gold Silver Karachi PKR 225,150 PKR 2,550 Lahore PKR 225,150 PKR 2,550 Islamabad PKR 225,150 PKR 2,550 Peshawar PKR 225,150 PKR [&#8230;]

## Azerbaijan shifts to renewables reducing oil product exports
 - [https://pakobserver.net/azerbaijan-shifts-to-renewables-reducing-oil-product-exports](https://pakobserver.net/azerbaijan-shifts-to-renewables-reducing-oil-product-exports)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T04:11:10+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2021/01/Oil-gains-as-OPEC-resumes-output-cut-extension-talks-after-impasse-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Azerbaijan sharply reduced the export of oil products. In January of this year, Azerbaijan exported 28,058.72 tons of oil products worth 17,434.46 thousand US dollars. The State Customs Committee, the value of the oil products exported by Azerbaijan during the reporting period decreased by 2.6 times and the volume by 2.4 times compared to the [&#8230;]

## German wind power sector welcomes govt offshore terminal funding
 - [https://pakobserver.net/german-wind-power-sector-welcomes-govt-offshore-terminal-funding](https://pakobserver.net/german-wind-power-sector-welcomes-govt-offshore-terminal-funding)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T04:11:05+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/03/3-18-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The German Offshore Wind Energy Foundation said the government’s decision to help fund the expansion of an offshore terminal is important to achieve expansion goals for wind energy at sea. In a statement, the foundation said it welcomed a government move to contribute to the costs of expanding the terminal at the port of Cuxhaven, [&#8230;]

## Saudi Arabia maintains strong position on UN maritime connectivity index
 - [https://pakobserver.net/saudi-arabia-maintains-strong-position-on-un-maritime-connectivity-index](https://pakobserver.net/saudi-arabia-maintains-strong-position-on-un-maritime-connectivity-index)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T04:11:03+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/03/de-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Saudi Arabia has scored above 240 points on a UN index measuring maritime connectivity for the fifth quarter in a row, reflecting improved shipping services. The Kingdom was awarded 248 points by the international body for the first three months of the year, maintaining the levels that started in the same period of 2023. The [&#8230;]

## EU imported €111.3b worth of energy products in Q4 2023
 - [https://pakobserver.net/eu-imported-e111-3b-worth-of-energy-products-in-q4-2023](https://pakobserver.net/eu-imported-e111-3b-worth-of-energy-products-in-q4-2023)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T04:10:59+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/encomey-watch-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />In the fourth quarter of 2023, the EU imported €111.3 billion worth of energy products amounting to a total of 187.9 million tonnes. Compared with the same quarter of 2022, imports decreased both in value (-34.2%) and in net mass (-11.7%), according to figures published by Eurostat, the statistical office of the European Union. When [&#8230;]

## Saudi deals prompt Pakistani IT firms to eye $3.5bn in exports
 - [https://pakobserver.net/saudi-deals-prompt-pakistani-it-firms-to-eye-3-5bn-in-exports](https://pakobserver.net/saudi-deals-prompt-pakistani-it-firms-to-eye-3-5bn-in-exports)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T04:10:53+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2020/07/1200px-Flag_of_Saudi_Arabia.svg_-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Major deals with Saudi firms have left Pakistan’s information technology exporters hopeful of hitting the $3.5 billion trade milestone in 2024. The South Asian nation recorded monthly IT exports of $257 million in February, 32 percent more than in the same month last year. Monthly IT exports in the second month of 2024 were higher [&#8230;]

## PM seeks comprehensive strategy for increase in IT exports
 - [https://pakobserver.net/pm-seeks-comprehensive-strategy-for-increase-in-it-exports](https://pakobserver.net/pm-seeks-comprehensive-strategy-for-increase-in-it-exports)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T04:10:47+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/03/PM-Shehbaz--150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Prime Minister Shehbaz Sharif sought a comprehensive strategy for increase in information technology exports of the country on priority basis the other day. He was chairing a meeting on progress of the information technology sector. Prominent information technology experts attended the meeting and gave their proposals. The PM said information technology had a prominent role [&#8230;]

## CDA levies heavy taxes on  Islamabad properties
 - [https://pakobserver.net/cda-levies-heavy-taxes-on-islamabad-properties](https://pakobserver.net/cda-levies-heavy-taxes-on-islamabad-properties)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T04:10:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/cda-1-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Capital Development Authority , the municipal services agency that operates in Islamabad has imposed heavy taxes on the real estate properties in the federal capital, Geo News reported on Saturday. As per a notification issued by the CDA, Rs24,000 of tax have been imposed on the owners of 140 square yards plots present in the [&#8230;]

## FPCCI appoints Shahida Parveen as Convener KPK Regional Committee
 - [https://pakobserver.net/fpcci-appoints-shahida-parveen-as-convener-kpk-regional-committee](https://pakobserver.net/fpcci-appoints-shahida-parveen-as-convener-kpk-regional-committee)
 - RSS feed: https://pakobserver.net/feed
 - date published: 2024-03-24T04:10:41+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/fpcci-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Federation of Pakistan Chambers of Commerce and Industry (FPCCI) has appointed Mrs Shahida Parveen as Convener FPCCI’s Women Khyber Pakhtunkhwa Regional Standing Committee on Women Empowerment &#38; Development for the year 2024-2025. The committee would represent Women Chamber Of Commerce &#38; Industry, Peshawar Division, according to press statement received here. Shahida Parveen, the Proprietor [&#8230;]

