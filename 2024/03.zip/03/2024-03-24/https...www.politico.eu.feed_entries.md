# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## The Week … Britain faced up to big threats
 - [https://www.politico.eu/podcast/the-week-britain-faced-up-to-big-threats/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/podcast/the-week-britain-faced-up-to-big-threats/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-03-24T19:32:17+00:00

This week, Jack and Sam discuss why defence and security – both domestic and foreign – will be a big focus as they look at reaction to Friday’s terror attack in Russia and claims that China has been behind cyber attacks targeting MPs and peers, threatening British democracy. Plus, there’s Rishi Sunak’s final appearance before […]

## No evidence Ukraine involved in Moscow terror attack, US vice president says
 - [https://www.politico.com/news/2024/03/24/ukraine-deadly-moscow-attack-kamala-00148712?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/news/2024/03/24/ukraine-deadly-moscow-attack-kamala-00148712?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-03-24T15:12:18+00:00

The attack on a concert hall in Russia’s capital Friday night killed at least 133 people.

## Report: French police put migrants’ lives at risk with aggressive tactics against small boats
 - [https://www.politico.eu/article/france-maritime-police-migrants-english-channel-small-boats-risk/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/france-maritime-police-migrants-english-channel-small-boats-risk/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-03-24T12:54:14+00:00

UK PM Sunak has pledged to “stop the boats” from crossing the Channel and said he would pay millions of pounds to France for help.

## Massive barrage of missiles, drones hits Kyiv and western Ukraine
 - [https://www.politico.eu/article/russia-ukraine-attack-missiles-drones-kyiv-lviv-poland/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/russia-ukraine-attack-missiles-drones-kyiv-lviv-poland/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-03-24T11:11:51+00:00

One cruise missile violated Polish airspace.

## Report: Beijing behind cyberattacks on UK MPs and peers, deputy PM to warn
 - [https://www.politico.eu/article/report-beijing-behind-cyberattacks-on-uk-mps-deputy-pm-to-warn/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/report-beijing-behind-cyberattacks-on-uk-mps-deputy-pm-to-warn/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-03-24T10:17:14+00:00

Parliament’s director of security has called a group of MPs and peers for a briefing on the matter, the Sunday Times reports.

