# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Księga Zachariasza || Rozdział 10
 - [https://www.youtube.com/watch?v=PhBIC1VqzIU](https://www.youtube.com/watch?v=PhBIC1VqzIU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2024-03-24T23:00:21+00:00

Przeczytajmy razem całe Pismo Święte! Od 1 października 2020 czytamy Pismo Święte, codziennie 1 rozdział życiodajnego SŁOWA BOGA.
Wykorzystano Najnowszy przekład Pisma Świętego z komentarzem opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.

________________________________________
PORADNIK ANTYZWIĄZKOWY
→ https://langustanapalmie.pl/produkt/poradnik-antyzwiazkowy/
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Audiobooka z Nowenną Pompejańską znajdziecie tu ♡
➡  https://bit.ly/nowennapompejańska
Dostępny także w zestawie z Audiobookiem "Jak się modlić"
➡ https://bit.ly/nowennaijaksięmodlić
____________________

## Zasypiaki || 24.03.2024 Niedziela
 - [https://www.youtube.com/watch?v=Uv1Vh9xGRcw](https://www.youtube.com/watch?v=Uv1Vh9xGRcw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2024-03-24T19:00:25+00:00

Czy szukasz czegoś więcej niż zwykłej kołysanki na dobranoc? 
Oto "Zasypiaki" - wieczorne Langustowe spotkania z Bogiem. 🌙🙏

Bez względu na to, czy jesteś na początku swojej podróży, czy jesteś już w przyjaźni z Nim, znajdziesz tu coś dla siebie. 🛤️💖 
To więcej niż podcast, to społeczność ludzi, którzy, podobnie jak Ty, szukają prawdziwych odpowiedzi. 🎧💭

Działaj! 🚀 Dołącz do nas na "Zasypiakach" i daj szansę Bogu i sobie. 
Czekamy na Ciebie codziennie o 20:00. ⏰🌟

🔥 Działaj z nami! ☞
→ https://niezlafundacja.pl/#darowizna
→ https://langustanapalmie.pl/przekaz-darowizne/
→ https://patronite.pl/langustanapalmie

#Zasypiaki #Podcast #AdamSzustak #NocneSpotkania 💫🌌

    @Langustanapalmie 
________________________________________
Aby nas wesprzeć kliknij tu 
→ https://patronite.pl/langustanapalmie
→ http://bit.ly/Subskrybuj_Languste

♡ Historie potłuczone
Spreaker → https://www.spreaker.com/show/historie-potluczone
Spotify → https://spoti.fi/2NVIRHb
Apple → https://apple.co/2ZIPQ

## Dobranocka [#279] Ekspert
 - [https://www.youtube.com/watch?v=TNLy_nE7304](https://www.youtube.com/watch?v=TNLy_nE7304)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2024-03-24T18:00:12+00:00

@Langustanapalmie   #dobranocka 

Bajka na dobranoc dla tych starszych dzieci. 
Opowiada ojciec Adam Szustak OP.

zdjęcia i montaż: Łukasz Głąb
Produkcja Serii: Sylwia Smoczyńska || Kamil Siciak

Muzyka:
Kai Engel: Brooks, z albumu Chapter Two: Mild – na licencji Creative Commons Attribution (https://creativecommons.org/licenses/...)
Źródło: http://freemusicarchive.org/music/Kai...
Wykonawca: http://www.kai-engel.com/

________________________________________
PORADNIK ANTYZWIĄZKOWY
→ https://langustanapalmie.pl/produkt/poradnik-antyzwiazkowy/
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Audiobooka znajdziecie tu ♡
➡  https://bit.ly/nowennapompejańska
Dostępny także w zestawie z Audiobookiem "Jak się modlić

## Historie potłuczone [#145] O Krysi, co chłopakiem chciała zostać
 - [https://www.youtube.com/watch?v=Bks5ODSNBNg](https://www.youtube.com/watch?v=Bks5ODSNBNg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2024-03-24T16:00:13+00:00

@Langustanapalmie    #historiepotłuczone

Historie potłuczone to opowieści o córkach i synach Boga, pięknych i brzydkich, świętych i grzesznych, szczęśliwych i na skraju rozpaczy. To opowieści o drodze, którą idzie się do nieba i o zakrętach i chaszczach, które spychają do piekła. To opowieści o ludziach po prostu. Czyli o nas.

Muzyka: Kai Engel: Brand New World, https://freemusicarchive.org/music/Kai_Engel/Sustains/Kai_Engel_-_Sustains_-_01_Brand_New_World

________________________________________
𝗕𝗜𝗟𝗘𝗧𝗬 na trasę TCHNIENIA znajdziecie tu: ☞ 🎟️
https://ekobilet.pl/shop/tchnienia
https://langustanapalmie.pl/pages/wydarzenia
________________________________________
PORADNIK ANTYZWIĄZKOWY
→ https://langustanapalmie.pl/produkt/poradnik-antyzwiazkowy/
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundac

## Mocno Stronniczy [73] Musisz wiedzieć czego potrzebujesz
 - [https://www.youtube.com/watch?v=V8WYPeI5oMw](https://www.youtube.com/watch?v=V8WYPeI5oMw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA
 - date published: 2024-03-24T01:44:46+00:00

@Langustanapalmie   @STREFAWODZA    #mocnostronniczy

Takich dwóch jak Ci, to nie ma ani jednego. 😁
Zapraszamy na kolejny odcinek zupełnie niesłychanej serii ojców Tomasza Nowaka OP i Adama Szustaka OP.

montaż: Marcin Jończyk
produkcja serii: Kamil Siciak
grafika: Sylwia Smoczyńska
________________________________________
𝗕𝗜𝗟𝗘𝗧𝗬 na trasę TCHNIENIA znajdziecie tu: ☞ 🎟️
https://ekobilet.pl/shop/tchnienia
https://langustanapalmie.pl/pages/wydarzenia
________________________________________
PORADNIK ANTYZWIĄZKOWY
→ https://langustanapalmie.pl/produkt/poradnik-antyzwiazkowy/
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Audiobooka znajdziecie tu ♡
➡  https://bit.ly/nowennapompejańska
Dostępny także w zestawie z

