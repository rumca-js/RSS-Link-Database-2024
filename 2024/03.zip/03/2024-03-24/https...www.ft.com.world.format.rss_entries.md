# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## UK launches ‘national endeavour’ to reinforce nuclear deterrent ...
 - [https://www.ft.com/content/a276c351-7e48-4662-a9fe-27363ac24a2b](https://www.ft.com/content/a276c351-7e48-4662-a9fe-27363ac24a2b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T22:31:57+00:00

Government and industry will invest £760mn towards critical skills and infrastructure  ...

## FirstFT: US and Japan plan upgrade to security alliance  ...
 - [https://www.ft.com/content/3a729f77-9e93-4337-a221-eb811518ee61](https://www.ft.com/content/3a729f77-9e93-4337-a221-eb811518ee61)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T22:20:50+00:00

Also in today’s newsletter, China blocks use of Intel and AMD chips in government computers and a day of mourning in Russia ...

## Courtroom politics ...
 - [https://www.ft.com/content/3fc1ee2b-06a9-4d44-bc89-c0770536be2a](https://www.ft.com/content/3fc1ee2b-06a9-4d44-bc89-c0770536be2a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T18:15:49+00:00

Deadline looms for Trump to raise $464mn appeal case guarantee, while Bankman-Fried set to be sentenced ...

## NHS should ‘seek to use’ private healthcare capacity, Wes Streeting says ...
 - [https://www.ft.com/content/f1950c91-617a-46dc-ac36-2ee03d9b1e73](https://www.ft.com/content/f1950c91-617a-46dc-ac36-2ee03d9b1e73)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T18:00:49+00:00

Shadow health secretary says that in the longer term, he would like no one to need to go private ...

## UK MPs to be alerted to threat of Chinese cyber attacks ...
 - [https://www.ft.com/content/822a6457-e543-4ab8-8457-1d7402f108c7](https://www.ft.com/content/822a6457-e543-4ab8-8457-1d7402f108c7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T17:18:44+00:00

Reprisals in the offing just as company from China eyes investment in Midlands battery gigafactory   ...

## EU to provide €165mn for Tunisian security forces to curb migration ...
 - [https://www.ft.com/content/17c4cb4f-410d-49ed-80ce-278ed597dd0a](https://www.ft.com/content/17c4cb4f-410d-49ed-80ce-278ed597dd0a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T15:09:48+00:00

Funding comes as bloc faces political pressure to cut arrival numbers ...

## Israel kills and detains hundreds in Gaza hospital raid ...
 - [https://www.ft.com/content/5bbfb6c5-d044-44a8-891c-b403db9cef90](https://www.ft.com/content/5bbfb6c5-d044-44a8-891c-b403db9cef90)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T12:56:55+00:00

Al-Shifa operation against Palestinian militants is one of the largest battles since the war began  ...

## Russia mourns concert attack dead as Isis suspects due in court ...
 - [https://www.ft.com/content/93d072a6-9fb3-4d47-bd8c-4cd5bdb0769b](https://www.ft.com/content/93d072a6-9fb3-4d47-bd8c-4cd5bdb0769b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T12:52:33+00:00

At least 133 people killed and more than 150 injured in assault claimed by Islamist group  ...

## Conservatives to retain UK pension triple lock in manifesto ...
 - [https://www.ft.com/content/9d9f5161-a75d-432e-a194-29cd40354970](https://www.ft.com/content/9d9f5161-a75d-432e-a194-29cd40354970)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T12:29:26+00:00

Chancellor’s pledge paves way for protection of pensioners until end of decade, despite strains on public finances   ...

## Europe is making trade conditional on production methods ...
 - [https://www.ft.com/content/98975933-128a-4fbf-8df1-04c800bf75ea](https://www.ft.com/content/98975933-128a-4fbf-8df1-04c800bf75ea)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T12:13:02+00:00

Businesses are upset by the extra regulation resulting from the restrictions ...

## Have the inflows into bitcoin funds dried up? ...
 - [https://www.ft.com/content/4cc278fa-01b6-466a-b596-93ad8cfb2e13](https://www.ft.com/content/4cc278fa-01b6-466a-b596-93ad8cfb2e13)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T12:00:48+00:00

Market Questions is the FT’s guide to the week ahead ...

## Prime Paris property with rue la-la ...
 - [https://www.ft.com/content/2e8b9a30-c3bb-42ba-bbf3-88fa866f9afe](https://www.ft.com/content/2e8b9a30-c3bb-42ba-bbf3-88fa866f9afe)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-03-24T11:00:48+00:00

What’s hot on the city’s real-estate... ...

