# Source:CodeProject Latest Articles, URL:https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1, language:en-us

## Dynamically updating firmware from arbitrary sources on an ESP32
 - [https://www.codeproject.com/Articles/5379529/Dynamically-updating-firmware-from-arbitrary-sourc](https://www.codeproject.com/Articles/5379529/Dynamically-updating-firmware-from-arbitrary-sourc)
 - RSS feed: https://www.codeproject.com/WebServices/ArticleRSS.aspx?cat=1
 - date published: 2024-03-24T15:59:00+00:00

Do you need to be able to perform a firmware update without using WiFi? This project is for you.

