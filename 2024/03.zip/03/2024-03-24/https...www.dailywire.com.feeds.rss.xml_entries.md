# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Border Patrol Chief Jason Owens Declares Biden‚Äôs Border Crisis A ‚ÄòNational Security Threat‚Äô
 - [https://www.dailywire.com/news/border-patrol-chief-jason-owens-declares-bidens-border-crisis-a-national-security-threat](https://www.dailywire.com/news/border-patrol-chief-jason-owens-declares-bidens-border-crisis-a-national-security-threat)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-03-24T17:33:51+00:00

U.S. Border Patrol Chief Jason Owens said over the weekend that the hundreds of thousands of illegal aliens who have evaded capture and made it into the U.S. homeland keep him up at night and that the situation is a &#8220;national security threat.&#8221; Owens made the remarks during a Sunday interview with CBS News&#8217; &#8220;Face ...

## Kevin McCarthy Weighs In On Returning To Government If Trump Wins
 - [https://www.dailywire.com/news/kevin-mccarthy-weighs-in-on-returning-to-government-if-trump-wins](https://www.dailywire.com/news/kevin-mccarthy-weighs-in-on-returning-to-government-if-trump-wins)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-03-24T17:26:47+00:00

Former House Speaker Kevin McCarthy (R-CA) suggested over the weekend that he would be open to returning to serve in the U.S. government in some capacity if former President Donald Trump wins back the White House this fall. McCarthy made the remarks during a Sunday interview with CBS News&#8217; Margaret Brennan on &#8220;Face The Nation&#8221; ...

## Chip Roy Blasts NY AG Letitia James For Trying To Seize Trump Assets: ‚ÄòLawfare‚Äô, ‚ÄòTargeting‚Äô
 - [https://www.dailywire.com/news/chip-roy-blasts-ny-ag-letitia-james-for-trying-to-seize-trump-assets-lawfare-targeting](https://www.dailywire.com/news/chip-roy-blasts-ny-ag-letitia-james-for-trying-to-seize-trump-assets-lawfare-targeting)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-03-24T14:24:05+00:00

Rep. Chip Roy (R-TX) blasted New York Attorney General Letitia James over the weekend as she prepares to begin seizing assets belonging to former President Donald Trump if he can&#8217;t pay a nearly half-a-billion dollar bond as he appeals the ruling of his civil fraud case. &#8220;Obviously, I believe in the rule of law. And, ...

## AOC Claims Israel Committing ‚ÄòGenocide‚Äô; Disagrees Hamas Could End War By Releasing Hostages, Surrendering
 - [https://www.dailywire.com/news/aoc-claims-israel-committing-genocide-disagrees-hamas-could-end-war-by-releasing-hostages-surrendering](https://www.dailywire.com/news/aoc-claims-israel-committing-genocide-disagrees-hamas-could-end-war-by-releasing-hostages-surrendering)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-03-24T14:05:12+00:00

Rep. Alexandria Ocasio-Cortez (D-NY) claimed on Sunday that Israel was intentionally committing a &#8220;genocide&#8221; inside Gaza and that the Hamas terrorist organization could not end the war by releasing the hostages and surrendering to the Israel Defense Forces (IDF). AOC&#8217;s comments on CNN&#8217;s &#8220;State of the Union&#8221; on Sunday come despite efforts by Israel to ...

## AOC Urges New York To Seize Trump‚Äôs Assets: He ‚ÄòOrdered Essentially A Terrorist Attack‚Äô
 - [https://www.dailywire.com/news/aoc-urges-new-york-to-seize-trumps-assets-he-ordered-essentially-a-terrorist-attack](https://www.dailywire.com/news/aoc-urges-new-york-to-seize-trumps-assets-he-ordered-essentially-a-terrorist-attack)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-03-24T13:55:21+00:00

Rep. Alexandria Ocasio-Cortez (D-NY) pushed the state of New York to seize former President Donald Trump&#8217;s assets in the state if he cannot secure an unprecedented bond while he appeals the civil fraud case against him and his company. AOC made the remarks about the $464 million bond during a Sunday interview with CNN&#8217;s Jake ...

## VP Harris Pushes Gun Control In Parkland Visit, Promotes New Push For ‚ÄòRed Flag Laws‚Äô
 - [https://www.dailywire.com/news/vp-harris-pushes-gun-control-in-parkland-visit-promotes-new-push-for-red-flag-laws](https://www.dailywire.com/news/vp-harris-pushes-gun-control-in-parkland-visit-promotes-new-push-for-red-flag-laws)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-03-24T11:41:30+00:00

The Biden administration is renewing its push for stricter gun control and an assault weapons ban with the creation of a new national office to push ‚Äúred flag laws.‚Äù Vice President Kamala Harris traveled to Parkland, Florida, on Saturday and toured the halls of Marjory Stoneman Douglas High School, the site of a 2018 mass ...

## Judge Greenlights Gaetz, Greene Lawsuit Against California Cities Over Canceled ‚ÄòAmerica First‚Äô Rallies
 - [https://www.dailywire.com/news/judge-greenlights-gaetz-greene-lawsuit-against-california-cities-over-canceled-america-first-rallies](https://www.dailywire.com/news/judge-greenlights-gaetz-greene-lawsuit-against-california-cities-over-canceled-america-first-rallies)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-03-24T11:40:05+00:00

A federal judge on Friday greenlit legal action from GOP Reps. Matt Gaetz of Florida and Marjorie Taylor Greene of Georgia against two California cities over rallies canceled in each in 2021. Gaetz and Greene sued the cities of Anaheim and Riverside last year after multiple venues repeatedly canceled reservations by the lawmakers to hold ...

## Matt Gaetz ‚ÄòUnleashed The Demons‚Äô In GOP When He ‚ÄòDrove Kevin McCarthy Out,‚Äô Newt Gingrich Says
 - [https://www.dailywire.com/news/matt-gaetz-unleashed-the-demons-in-gop-when-he-drove-kevin-mccarthy-out-newt-gingrich-says](https://www.dailywire.com/news/matt-gaetz-unleashed-the-demons-in-gop-when-he-drove-kevin-mccarthy-out-newt-gingrich-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-03-24T09:21:20+00:00

Former House Speaker Newt Gingrich (R-GA) blames the current House GOP dysfunction on Rep. Matt Gaetz of Florida. Gingrich appeared on Fox News on Friday with host Laura Ingraham to bemoan the chaos that has fractured the House Republican caucus and which threatens to oust the second Republican speaker since October. He said trouble within ...

