# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## Book Riot’s Deals of the Day for March 24, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-march-24-2024](https://bookriot.com/book-riots-deals-of-the-day-for-march-24-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-24T10:00:00+00:00

Wicked bugs, Little House retold, a sparkling Sapphic romance, and more of today's best book deals.

