# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## Funniest/Most Insightful Comments Of The Week At Techdirt
 - [https://www.techdirt.com/2024/03/24/funniest-most-insightful-comments-of-the-week-at-techdirt-103](https://www.techdirt.com/2024/03/24/funniest-most-insightful-comments-of-the-week-at-techdirt-103)
 - RSS feed: https://www.techdirt.com/feed
 - date published: 2024-03-24T19:00:00+00:00

This week, our first place winner on the insightful side is MrWilson, replying to another commenter who was bandying about the court rulings that erroneously agreed that Biden and the FBI violated the first amendment by coercing platforms: You mean a conservative think tank shopped for a favorite Trump-appointed judge known for his willingness to [&#8230;]

