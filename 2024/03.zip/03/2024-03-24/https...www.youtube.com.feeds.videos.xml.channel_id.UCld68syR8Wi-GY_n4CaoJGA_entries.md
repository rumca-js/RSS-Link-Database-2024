# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## COSMIC Desktop Alpha Is Only Weeks Away!!
 - [https://www.youtube.com/watch?v=FoDBjLEsivQ](https://www.youtube.com/watch?v=FoDBjLEsivQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2024-03-24T20:00:05+00:00

The COSMIC desktop alpha was supposed to come out at the end of March but it's been delayed just a little bit until May to round out developing the first party COSMIC applications

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
January Post: https://blog.system76.com/post/cosmic-the-road-to-alpha
February Post: https://blog.system76.com/post/closing-in-on-a-cosmic-alpha
March Post: https://blog.system76.com/post/cosmic-more-alpha-more-fun

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson.xyz/discord
🐦 Twitter: https://brodierobertson.xyz/twitter
🌐 Mastodon: https://brodierober

