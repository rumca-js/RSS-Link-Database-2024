# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Do Artifacts Have Politics? [pdf]
 - [https://faculty.cc.gatech.edu/~beki/cs4001/Winner.pdf](https://faculty.cc.gatech.edu/~beki/cs4001/Winner.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T22:57:03+00:00

<p>Article URL: <a href="https://faculty.cc.gatech.edu/~beki/cs4001/Winner.pdf">https://faculty.cc.gatech.edu/~beki/cs4001/Winner.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39811287">https://news.ycombinator.com/item?id=39811287</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## 'Quantum tornado' allows scientists to mimic a black hole on Earth
 - [https://www.space.com/quantum-tornado-black-hole-physics-simulation-absolute-zero](https://www.space.com/quantum-tornado-black-hole-physics-simulation-absolute-zero)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T22:11:33+00:00

<p>Article URL: <a href="https://www.space.com/quantum-tornado-black-hole-physics-simulation-absolute-zero">https://www.space.com/quantum-tornado-black-hole-physics-simulation-absolute-zero</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39810979">https://news.ycombinator.com/item?id=39810979</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Cargo thefts spiked 68% in Q4, led by food and beverage freight
 - [https://www.freightwaves.com/news/cargo-thefts-spiked-68-in-q4-led-by-food-and-beverage-freight](https://www.freightwaves.com/news/cargo-thefts-spiked-68-in-q4-led-by-food-and-beverage-freight)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T21:59:02+00:00

<p>Article URL: <a href="https://www.freightwaves.com/news/cargo-thefts-spiked-68-in-q4-led-by-food-and-beverage-freight">https://www.freightwaves.com/news/cargo-thefts-spiked-68-in-q4-led-by-food-and-beverage-freight</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39810882">https://news.ycombinator.com/item?id=39810882</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Notes from Sam Bankman-Fried, Circa Late 2022
 - [https://twitter.com/TechEmails/status/1768730786839331295](https://twitter.com/TechEmails/status/1768730786839331295)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T21:55:38+00:00

<p>Article URL: <a href="https://twitter.com/TechEmails/status/1768730786839331295">https://twitter.com/TechEmails/status/1768730786839331295</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39810856">https://news.ycombinator.com/item?id=39810856</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Facebook Is Filled with AI-Generated Garbage–and Older Adults Are Being Tricked
 - [https://www.thedailybeast.com/how-seniors-are-falling-for-ai-generated-pics-on-facebook](https://www.thedailybeast.com/how-seniors-are-falling-for-ai-generated-pics-on-facebook)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T21:31:52+00:00

<p>Article URL: <a href="https://www.thedailybeast.com/how-seniors-are-falling-for-ai-generated-pics-on-facebook">https://www.thedailybeast.com/how-seniors-are-falling-for-ai-generated-pics-on-facebook</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39810706">https://news.ycombinator.com/item?id=39810706</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Nuclear's role in a net-zero world
 - [https://knowablemagazine.org/content/article/food-environment/2024/nuclears-role-in-a-net-zero-world](https://knowablemagazine.org/content/article/food-environment/2024/nuclears-role-in-a-net-zero-world)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T21:28:57+00:00

<p>Article URL: <a href="https://knowablemagazine.org/content/article/food-environment/2024/nuclears-role-in-a-net-zero-world">https://knowablemagazine.org/content/article/food-environment/2024/nuclears-role-in-a-net-zero-world</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39810692">https://news.ycombinator.com/item?id=39810692</a></p>
<p>Points: 9</p>
<p># Comments: 5</p>

## Catching a break: How gig workers find rest
 - [https://restofworld.org/2024/gig-worker-rest-breaks](https://restofworld.org/2024/gig-worker-rest-breaks)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T21:21:21+00:00

<p>Article URL: <a href="https://restofworld.org/2024/gig-worker-rest-breaks/">https://restofworld.org/2024/gig-worker-rest-breaks/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39810629">https://news.ycombinator.com/item?id=39810629</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Monolith – CLI tool for saving complete web pages as a single HTML file
 - [https://github.com/Y2Z/monolith](https://github.com/Y2Z/monolith)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T20:48:06+00:00

<p>Article URL: <a href="https://github.com/Y2Z/monolith">https://github.com/Y2Z/monolith</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39810378">https://news.ycombinator.com/item?id=39810378</a></p>
<p>Points: 29</p>
<p># Comments: 3</p>

## "She's Bouncing the Ball " on the Uncanny Way Octopuses Play
 - [https://lithub.com/shes-bouncing-the-ball-on-the-uncanny-way-octopuses-play](https://lithub.com/shes-bouncing-the-ball-on-the-uncanny-way-octopuses-play)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T20:41:59+00:00

<p>Article URL: <a href="https://lithub.com/shes-bouncing-the-ball-on-the-uncanny-way-octopuses-play/">https://lithub.com/shes-bouncing-the-ball-on-the-uncanny-way-octopuses-play/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39810320">https://news.ycombinator.com/item?id=39810320</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Gemini on the iPhone would be AI's mainstream moment
 - [https://www.cnet.com/tech/mobile/google-gemini-on-the-iphone-would-be-ais-mainstream-moment](https://www.cnet.com/tech/mobile/google-gemini-on-the-iphone-would-be-ais-mainstream-moment)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T19:52:23+00:00

<p>Article URL: <a href="https://www.cnet.com/tech/mobile/google-gemini-on-the-iphone-would-be-ais-mainstream-moment/">https://www.cnet.com/tech/mobile/google-gemini-on-the-iphone-would-be-ais-mainstream-moment/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39809861">https://news.ycombinator.com/item?id=39809861</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## Your customers hate MVPs. Make a SLC instead
 - [https://longform.asmartbear.com/slc](https://longform.asmartbear.com/slc)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T19:11:28+00:00

<p>Article URL: <a href="https://longform.asmartbear.com/slc/">https://longform.asmartbear.com/slc/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39809447">https://news.ycombinator.com/item?id=39809447</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Scientists traced a mysterious Covid case back to six toilets
 - [https://www.technologyreview.com/2024/03/22/1090059/how-scientists-traced-a-mysterious-covid-case-back-to-six-toilets](https://www.technologyreview.com/2024/03/22/1090059/how-scientists-traced-a-mysterious-covid-case-back-to-six-toilets)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T19:00:45+00:00

<p>Article URL: <a href="https://www.technologyreview.com/2024/03/22/1090059/how-scientists-traced-a-mysterious-covid-case-back-to-six-toilets/">https://www.technologyreview.com/2024/03/22/1090059/how-scientists-traced-a-mysterious-covid-case-back-to-six-toilets/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39809369">https://news.ycombinator.com/item?id=39809369</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Majority of web apps could just run on a single server
 - [https://old.reddit.com/r/webdev/comments/1bmfrjm/majority_of_web_apps_could_just_run_on_a_single](https://old.reddit.com/r/webdev/comments/1bmfrjm/majority_of_web_apps_could_just_run_on_a_single)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T18:56:56+00:00

<p>Article URL: <a href="https://old.reddit.com/r/webdev/comments/1bmfrjm/majority_of_web_apps_could_just_run_on_a_single/">https://old.reddit.com/r/webdev/comments/1bmfrjm/majority_of_web_apps_could_just_run_on_a_single/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39809342">https://news.ycombinator.com/item?id=39809342</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Gerbil Scheme – A Lisp for the 21st Century
 - [https://cons.io](https://cons.io)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T18:54:47+00:00

<p>Article URL: <a href="https://cons.io/">https://cons.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39809323">https://news.ycombinator.com/item?id=39809323</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Show HN: Math I'm creating, Space Numbers
 - [https://github.com/abidsikder/space-numbers](https://github.com/abidsikder/space-numbers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T18:52:10+00:00

<p>Hi HN!<p>I had a math idea whose thread I've been pulling on, and ended up creating this concept of Space Numbers. To read about it, see the pdf at the linked repo: <a href="https://github.com/abidsikder/space-numbers">https://github.com/abidsikder/space-numbers</a><p>I'd appreciate feedback and ideas about the concepts, as well as further mathematical topics to take a look at that might be related, thank you all!!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39809294">https://news.ycombinator.com/item?id=39809294</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## GPT-4, without specialized training, beat a GPT-3.5 class model that cost $10M
 - [https://www.threads.net/@ethan_mollick/post/C46AfItO8RS](https://www.threads.net/@ethan_mollick/post/C46AfItO8RS)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T18:34:33+00:00

<p>Article URL: <a href="https://www.threads.net/@ethan_mollick/post/C46AfItO8RS">https://www.threads.net/@ethan_mollick/post/C46AfItO8RS</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39809177">https://news.ycombinator.com/item?id=39809177</a></p>
<p>Points: 18</p>
<p># Comments: 6</p>

## Why are bidets just now getting popular in America?
 - [https://www.cnn.com/2024/03/24/business/bidet-boom-america-toilets/index.html](https://www.cnn.com/2024/03/24/business/bidet-boom-america-toilets/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T18:20:14+00:00

<p>Article URL: <a href="https://www.cnn.com/2024/03/24/business/bidet-boom-america-toilets/index.html">https://www.cnn.com/2024/03/24/business/bidet-boom-america-toilets/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39809065">https://news.ycombinator.com/item?id=39809065</a></p>
<p>Points: 27</p>
<p># Comments: 55</p>

## Ask HN: How common is developer burnout? Have you ever been burnt out?
 - [https://news.ycombinator.com/item?id=39809061](https://news.ycombinator.com/item?id=39809061)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T18:19:57+00:00

<p>When I graduated from college I found a job working for a Fortune 500 where I completed a pretty complex project. I was there for two years and it felt like a stressful meat grinder. The experience was so bad that I quickly pivoted to a less stressful role, and have been there for quite some time now.<p>This has got me wondering: how stressful do people find the software industry at large? There seems to be a big draw for young developers to try to go FAANG, but honestly, these companies just sound like another high-performance meat grinder. You get paid a lot but are constantly under scrutiny. And smaller companies are all going pseudo-agile to try to squeeze every last ounce from their developers.<p>This makes me wonder if finding a low-key, sane culture is the key to sustainability in the industry, and avoiding burn out.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39809061">https://news.ycombinator.com/item?id=39809061</a></p>
<p>Points: 33

## If you watched certain YouTube videos, investigators demanded your data
 - [https://mashable.com/article/google-ordered-to-hand-over-viewer-data-privacy-concerns](https://mashable.com/article/google-ordered-to-hand-over-viewer-data-privacy-concerns)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T18:10:02+00:00

<p>Article URL: <a href="https://mashable.com/article/google-ordered-to-hand-over-viewer-data-privacy-concerns">https://mashable.com/article/google-ordered-to-hand-over-viewer-data-privacy-concerns</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808994">https://news.ycombinator.com/item?id=39808994</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Why isn't preprint review being adopted?
 - [https://www.theroadgoeson.com/why-isnt-preprint-review-being-adopted](https://www.theroadgoeson.com/why-isnt-preprint-review-being-adopted)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T18:06:59+00:00

<p>Article URL: <a href="https://www.theroadgoeson.com/why-isnt-preprint-review-being-adopted">https://www.theroadgoeson.com/why-isnt-preprint-review-being-adopted</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808967">https://news.ycombinator.com/item?id=39808967</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Aegis v3.0 – a free, secure and open source 2FA app for Android
 - [https://github.com/beemdevelopment/Aegis/releases/tag/v3.0](https://github.com/beemdevelopment/Aegis/releases/tag/v3.0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T18:00:40+00:00

<p>Article URL: <a href="https://github.com/beemdevelopment/Aegis/releases/tag/v3.0">https://github.com/beemdevelopment/Aegis/releases/tag/v3.0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808921">https://news.ycombinator.com/item?id=39808921</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## C++ left arrow operator (2016)
 - [https://www.atnnn.com/p/operator-larrow](https://www.atnnn.com/p/operator-larrow)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T17:22:01+00:00

<p>Article URL: <a href="https://www.atnnn.com/p/operator-larrow/">https://www.atnnn.com/p/operator-larrow/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808616">https://news.ycombinator.com/item?id=39808616</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## Only Walking for Exercise?
 - [https://theconversation.com/only-walking-for-exercise-heres-how-to-get-the-most-out-of-it-224159](https://theconversation.com/only-walking-for-exercise-heres-how-to-get-the-most-out-of-it-224159)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T17:09:04+00:00

<p>Article URL: <a href="https://theconversation.com/only-walking-for-exercise-heres-how-to-get-the-most-out-of-it-224159">https://theconversation.com/only-walking-for-exercise-heres-how-to-get-the-most-out-of-it-224159</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808497">https://news.ycombinator.com/item?id=39808497</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## GoGoGrandparent (YC S16) is hiring senior/staff back end and lead engineers
 - [https://news.ycombinator.com/item?id=39808425](https://news.ycombinator.com/item?id=39808425)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T17:00:29+00:00

<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808425">https://news.ycombinator.com/item?id=39808425</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## The ü/ü Conundrum
 - [https://unravelweb.dev/2024/02/12/the-u-u-conundrum](https://unravelweb.dev/2024/02/12/the-u-u-conundrum)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T16:50:41+00:00

<p>Article URL: <a href="https://unravelweb.dev/2024/02/12/the-u-u-conundrum/">https://unravelweb.dev/2024/02/12/the-u-u-conundrum/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808357">https://news.ycombinator.com/item?id=39808357</a></p>
<p>Points: 11</p>
<p># Comments: 5</p>

## Ten years of selling web data: a personal perspective
 - [https://substack.thewebscraping.club/p/selling-web-scraped-data](https://substack.thewebscraping.club/p/selling-web-scraped-data)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T16:26:39+00:00

<p>Article URL: <a href="https://substack.thewebscraping.club/p/selling-web-scraped-data">https://substack.thewebscraping.club/p/selling-web-scraped-data</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808171">https://news.ycombinator.com/item?id=39808171</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## The Mirror (Godot bashed game engine)
 - [https://github.com/the-mirror-gdp/the-mirror](https://github.com/the-mirror-gdp/the-mirror)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T16:18:07+00:00

<p>Article URL: <a href="https://github.com/the-mirror-gdp/the-mirror">https://github.com/the-mirror-gdp/the-mirror</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808104">https://news.ycombinator.com/item?id=39808104</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Programmers are bad at managing state (2020)
 - [https://nolanlawson.com/2020/12/29/programmers-are-bad-at-managing-state](https://nolanlawson.com/2020/12/29/programmers-are-bad-at-managing-state)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T16:12:26+00:00

<p>Article URL: <a href="https://nolanlawson.com/2020/12/29/programmers-are-bad-at-managing-state/">https://nolanlawson.com/2020/12/29/programmers-are-bad-at-managing-state/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39808069">https://news.ycombinator.com/item?id=39808069</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Do ten times as much (2023)
 - [https://www.betonit.ai/p/do-ten-times-as-much](https://www.betonit.ai/p/do-ten-times-as-much)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:57:45+00:00

<p>Article URL: <a href="https://www.betonit.ai/p/do-ten-times-as-much">https://www.betonit.ai/p/do-ten-times-as-much</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807998">https://news.ycombinator.com/item?id=39807998</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## American Military-Civil fusion at risk with the loss off the Shift fellowship
 - [https://warontherocks.com/2024/03/american-military-civil-fusion-at-risk-with-the-loss-of-the-shift-fellowship](https://warontherocks.com/2024/03/american-military-civil-fusion-at-risk-with-the-loss-of-the-shift-fellowship)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:54:56+00:00

<p>Article URL: <a href="https://warontherocks.com/2024/03/american-military-civil-fusion-at-risk-with-the-loss-of-the-shift-fellowship/">https://warontherocks.com/2024/03/american-military-civil-fusion-at-risk-with-the-loss-of-the-shift-fellowship/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807980">https://news.ycombinator.com/item?id=39807980</a></p>
<p>Points: 4</p>
<p># Comments: 2</p>

## What Happens When a Fifteen Year Old Pumps and Dumps with a Net Profit of $800k?
 - [http://www.kentlaw.edu/faculty/rwarner/classes/legalaspects_ukraine/securities/case_studies/ledbed.htm](http://www.kentlaw.edu/faculty/rwarner/classes/legalaspects_ukraine/securities/case_studies/ledbed.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:52:06+00:00

<p>Article URL: <a href="http://www.kentlaw.edu/faculty/rwarner/classes/legalaspects_ukraine/securities/case_studies/ledbed.htm">http://www.kentlaw.edu/faculty/rwarner/classes/legalaspects_ukraine/securities/case_studies/ledbed.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807967">https://news.ycombinator.com/item?id=39807967</a></p>
<p>Points: 18</p>
<p># Comments: 3</p>

## Be more lucky
 - [https://newsletter.pnote.eu/p/be-more-lucky](https://newsletter.pnote.eu/p/be-more-lucky)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:43:29+00:00

<p>Article URL: <a href="https://newsletter.pnote.eu/p/be-more-lucky">https://newsletter.pnote.eu/p/be-more-lucky</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807914">https://news.ycombinator.com/item?id=39807914</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Show HN: Glossarie – a new, immersive way to learn a language
 - [https://glossarie.app](https://glossarie.app)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:43:16+00:00

<p>Hi HN, For over two years I've been working on an App to learn languages (currently French, Italian and Spanish), together with my partner, a language teacher. I think it is finally ready to share with this community!<p>The idea is to introduce vocabulary and grammar whilst you read eBooks in your own language. I've found that it is easier to remember vocabulary 'in context' and with regular repetition. Plus you don't have to carve out dedicated time for language learning. Other apps require you to build a habit around various exercises or ‘games’, whereas lots of people already read books.<p>From testing with early users so far it's proving effective for building a basic understanding of a language and quickly getting to the point where you can read and broadly understand text in the target language. It’s even better in combination with other apps that help with listening/speaking like Pimsleur.<p>There were lots of technical challenges making this. It turned out to be (r

## Condvars and atomics do not mix
 - [https://zeux.io/2024/03/23/condvars-atomic](https://zeux.io/2024/03/23/condvars-atomic)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:30:22+00:00

<p>Article URL: <a href="https://zeux.io/2024/03/23/condvars-atomic/">https://zeux.io/2024/03/23/condvars-atomic/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807842">https://news.ycombinator.com/item?id=39807842</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## What Is Green Software and Why Do We Need It?
 - [https://spectrum.ieee.org/green-software](https://spectrum.ieee.org/green-software)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:23:35+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/green-software">https://spectrum.ieee.org/green-software</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807795">https://news.ycombinator.com/item?id=39807795</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## 'Super memory': Why Emily Nash is sharing her brain with science
 - [https://www.ctvnews.ca/w5/why-18-year-old-canadian-emily-nash-is-sharing-her-unique-brain-with-science-1.6818765](https://www.ctvnews.ca/w5/why-18-year-old-canadian-emily-nash-is-sharing-her-unique-brain-with-science-1.6818765)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:19:27+00:00

<p>Article URL: <a href="https://www.ctvnews.ca/w5/why-18-year-old-canadian-emily-nash-is-sharing-her-unique-brain-with-science-1.6818765">https://www.ctvnews.ca/w5/why-18-year-old-canadian-emily-nash-is-sharing-her-unique-brain-with-science-1.6818765</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807759">https://news.ycombinator.com/item?id=39807759</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## How ML Model Data Poisoning Works in 5 Minutes
 - [https://journal.hexmos.com/training-data-poisoning/?src=hn](https://journal.hexmos.com/training-data-poisoning/?src=hn)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:15:23+00:00

<p>Article URL: <a href="https://journal.hexmos.com/training-data-poisoning/?src=hn">https://journal.hexmos.com/training-data-poisoning/?src=hn</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807735">https://news.ycombinator.com/item?id=39807735</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Type-Safe Printf() in TypeScript
 - [https://www.typescriptlang.org/play?#code/C4TwDgpgBAypDGUC8UDkATVUA+aDOqA3AFCiSwIAq4EAPDFBAB7AQB26eFE8AfMrEYt2nNJigB+KGwCuAWwBGEAE5QAXIOasOXVAUlQ8wZQEs2Ac3XSIANxUlSNKAAVTbYADMAgsvN5aAGJywPxIxFARUEHAQtqiAAYApAAkAN5mHiqawjrc8AC+aRlZAEoQRvnxBgDacDzUkPS8ADRQAHQdrmaePn60ZUa8ALrq4ZHRsSJc8UVsmaoA+vkp6XNZDFpTeYWr81ADwJU1dfANdDAt7Z1uPb7+B8OjkVDVQw4eMmzwwCYA9mxQMA3DyBYKTXJGNzmXgACg8wQ00VaHTaAEM7houu5vHdQSEAJRQVJjCLwf54X4AGwgbUpv3MMPiZXgEBMdnQUHhMUhZnMGgARGkufl+VBURwxRioGl0X5KviSPliMQAPQqqAASWAeigZGgeFRmQAhMQgd0PDD+QAJCCUumtRJ4NpQRIcgDULo5KFdbX5rX5AHVfspKeg-VAAKytAAsrQAnAqgA](https://www.typescriptlang.org/play?#code/C4TwDgpgBAypDGUC8UDkATVUA+aDOqA3AFCiSwIAq4EAPDFBAB7AQB26eFE8AfMrEYt2nNJigB+KGwCuAWwBGEAE5QAXIOasOXVAUlQ8wZQEs2Ac3XSIANxUlSNKAAVTbYADMAgsvN5aAGJywPxIxFARUEHAQtqiAAYApAAkAN5mHiqawjrc8AC+aRlZAEoQRvnxBgDacDzUkPS8ADRQAHQdrmaePn60ZUa8ALrq4ZHRsSJc8UVsmaoA+vkp6XNZDFpTeYWr81ADwJU1dfANdDAt7Z1uPb7+B8OjkVDVQw4eMmzwwCYA9mxQMA3DyBYKTXJGNzmXgACg8wQ00VaHTaAEM7houu5vHdQSEAJRQVJjCLwf54X4AGwgbUpv3MMPiZXgEBMdnQUHhMUhZnMGgARGkufl+VBURwxRioGl0X5KviSPliMQAPQqqAASWAeigZGgeFRmQAhMQgd0PDD+QAJCCUumtRJ4NpQRIcgDULo5KFdbX5rX5AHVfspKeg-VAAKytAAsrQAnAqgA)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T15:02:02+00:00

<p>Article URL: <a href="https://www.typescriptlang.org/play?#code/C4TwDgpgBAypDGUC8UDkATVUA+aDOqA3AFCiSwIAq4EAPDFBAB7AQB26eFE8AfMrEYt2nNJigB+KGwCuAWwBGEAE5QAXIOasOXVAUlQ8wZQEs2Ac3XSIANxUlSNKAAVTbYADMAgsvN5aAGJywPxIxFARUEHAQtqiAAYApAAkAN5mHiqawjrc8AC+aRlZAEoQRvnxBgDacDzUkPS8ADRQAHQdrmaePn60ZUa8ALrq4ZHRsSJc8UVsmaoA+vkp6XNZDFpTeYWr81ADwJU1dfANdDAt7Z1uPb7+B8OjkVDVQw4eMmzwwCYA9mxQMA3DyBYKTXJGNzmXgACg8wQ00VaHTaAEM7houu5vHdQSEAJRQVJjCLwf54X4AGwgbUpv3MMPiZXgEBMdnQUHhMUhZnMGgARGkufl+VBURwxRioGl0X5KviSPliMQAPQqqAASWAeigZGgeFRmQAhMQgd0PDD+QAJCCUumtRJ4NpQRIcgDULo5KFdbX5rX5AHVfspKeg-VAAKytAAsrQAnAqgA">https://www.typescriptlang.org/play?#code/C4TwDgpgBAypDGUC8UDkATVUA+aDOqA3AFCiSwIAq4EAPDFBAB7AQB26eFE8AfMrEYt2nNJigB+KGwCuAWwBGEAE5QAXIOasOXVAUlQ8wZQEs2Ac3XSIANxUlSNKAAVTbYADMAgsvN5aAGJywPxIxFARUEHAQtqiAAYApAAkAN5mHiqawjrc8AC+aRlZAEoQRvnxBgDacDzUkPS8ADRQAHQdrmaePn60ZUa8ALrq4ZHRsSJc8UVsmaoA+vkp6XNZDFpTeYWr81ADwJU1dfANdDAt7Z1uPb7+B8OjkVDVQw4eMmzwwCYA9mxQMA3DyBYKTXJGNzmXgACg8wQ00VaHTaAEM7houu5

## Weather Planning for Eclipse Day
 - [https://eclipsophile.com/eclipse-day-weather](https://eclipsophile.com/eclipse-day-weather)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T14:31:45+00:00

<p>Article URL: <a href="https://eclipsophile.com/eclipse-day-weather/">https://eclipsophile.com/eclipse-day-weather/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807463">https://news.ycombinator.com/item?id=39807463</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Antimatter Propulsion [pdf]
 - [https://ntrs.nasa.gov/api/citations/20200001904/downloads/20200001904.pdf](https://ntrs.nasa.gov/api/citations/20200001904/downloads/20200001904.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T14:24:54+00:00

<p>Article URL: <a href="https://ntrs.nasa.gov/api/citations/20200001904/downloads/20200001904.pdf">https://ntrs.nasa.gov/api/citations/20200001904/downloads/20200001904.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39807417">https://news.ycombinator.com/item?id=39807417</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## ARM64EC (and ARM64X) Explained
 - [http://www.emulators.com/docs/abc_arm64ec_explained.htm](http://www.emulators.com/docs/abc_arm64ec_explained.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T12:16:46+00:00

<p>Article URL: <a href="http://www.emulators.com/docs/abc_arm64ec_explained.htm">http://www.emulators.com/docs/abc_arm64ec_explained.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806746">https://news.ycombinator.com/item?id=39806746</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Sieve (YC W22) Is hiring ML engineers to build the future of video AI
 - [https://sievedata.com/about/jobs](https://sievedata.com/about/jobs)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T12:00:08+00:00

<p>Article URL: <a href="https://sievedata.com/about/jobs">https://sievedata.com/about/jobs</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806654">https://news.ycombinator.com/item?id=39806654</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## Filling Nuclear Power's $5T Hole Is Beyond the Banks
 - [https://www.bloomberg.com/news/articles/2024-03-22/filling-nuclear-power-s-5-trillion-hole-is-beyond-the-banks](https://www.bloomberg.com/news/articles/2024-03-22/filling-nuclear-power-s-5-trillion-hole-is-beyond-the-banks)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T11:53:24+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2024-03-22/filling-nuclear-power-s-5-trillion-hole-is-beyond-the-banks">https://www.bloomberg.com/news/articles/2024-03-22/filling-nuclear-power-s-5-trillion-hole-is-beyond-the-banks</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806619">https://news.ycombinator.com/item?id=39806619</a></p>
<p>Points: 11</p>
<p># Comments: 5</p>

## Build time is a collective responsibility
 - [https://yoyo-code.com/build-time-is-collective-responsibility](https://yoyo-code.com/build-time-is-collective-responsibility)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T11:53:22+00:00

<p>Article URL: <a href="https://yoyo-code.com/build-time-is-collective-responsibility/">https://yoyo-code.com/build-time-is-collective-responsibility/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806618">https://news.ycombinator.com/item?id=39806618</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Israel Has Formed a Task Force to Carry Out Covert Campaigns at US Universities
 - [https://truthout.org/articles/israel-has-formed-a-task-force-to-carry-out-covert-campaigns-at-us-universities](https://truthout.org/articles/israel-has-formed-a-task-force-to-carry-out-covert-campaigns-at-us-universities)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T11:47:07+00:00

<p>Article URL: <a href="https://truthout.org/articles/israel-has-formed-a-task-force-to-carry-out-covert-campaigns-at-us-universities/">https://truthout.org/articles/israel-has-formed-a-task-force-to-carry-out-covert-campaigns-at-us-universities/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806584">https://news.ycombinator.com/item?id=39806584</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Ask HN: What is your approach for managing personal digital assets?
 - [https://news.ycombinator.com/item?id=39806509](https://news.ycombinator.com/item?id=39806509)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T11:31:28+00:00

<p>I've been facing this issue for quite a while and haven't come across a solution that meets my needs.<p>I have many files and digital content scattered everywhere. Some files and texts in my email accounts (personal and work). Some in Storage services such as Dropbox, GDrive, ...  and some in messaging apps. There is also the photo gallery on my phone.
These are photos, videos, text, pdfs, ... . The challenge comes in when I'm trying to find a specific file or info. I often find myself asking questions like:<p>- Where's the photo of me wearing a cap?<p>- Where are all my invoices from before 2023?<p>- Did my friend ever text me his phone number somewhere?<p>- ...<p>I'd really appreciate any advice or recommendations for tools or methods you've used that worked for you.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806509">https://news.ycombinator.com/item?id=39806509</a></p>
<p>Points: 21</p>
<p># Comments: 0</p>

## The Matrix
 - [https://en.wikipedia.org/wiki/The_Matrix](https://en.wikipedia.org/wiki/The_Matrix)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T11:11:06+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/The_Matrix">https://en.wikipedia.org/wiki/The_Matrix</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806424">https://news.ycombinator.com/item?id=39806424</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## LLM pricing comparison tool – [free]
 - [https://www.botgenuity.com/tools/llm-pricing](https://www.botgenuity.com/tools/llm-pricing)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T11:07:16+00:00

<p>Article URL: <a href="https://www.botgenuity.com/tools/llm-pricing">https://www.botgenuity.com/tools/llm-pricing</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806406">https://news.ycombinator.com/item?id=39806406</a></p>
<p>Points: 22</p>
<p># Comments: 5</p>

## StarTech Unveils 15-in-1 Thunderbolt 4/USB4 Dock with Quad Display Support
 - [https://www.anandtech.com/show/21306/startech-unveils-15in1-thunderbolt-4usb4-dock-with-quad-display-support](https://www.anandtech.com/show/21306/startech-unveils-15in1-thunderbolt-4usb4-dock-with-quad-display-support)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T11:00:37+00:00

<p>Article URL: <a href="https://www.anandtech.com/show/21306/startech-unveils-15in1-thunderbolt-4usb4-dock-with-quad-display-support">https://www.anandtech.com/show/21306/startech-unveils-15in1-thunderbolt-4usb4-dock-with-quad-display-support</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806382">https://news.ycombinator.com/item?id=39806382</a></p>
<p>Points: 16</p>
<p># Comments: 3</p>

## Tinyssh
 - [https://tinyssh.org](https://tinyssh.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T10:04:55+00:00

<p>Article URL: <a href="https://tinyssh.org/">https://tinyssh.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806139">https://news.ycombinator.com/item?id=39806139</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## TinySSH is a small SSH server using NaCl, TweetNaCl
 - [https://github.com/janmojzis/tinyssh](https://github.com/janmojzis/tinyssh)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T10:04:55+00:00

<p>Article URL: <a href="https://github.com/janmojzis/tinyssh">https://github.com/janmojzis/tinyssh</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39806139">https://news.ycombinator.com/item?id=39806139</a></p>
<p>Points: 132</p>
<p># Comments: 43</p>

## Reactive Programming Without Functions
 - [https://programming-journal.org/2024/8/11](https://programming-journal.org/2024/8/11)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T08:41:22+00:00

<p>Article URL: <a href="https://programming-journal.org/2024/8/11/">https://programming-journal.org/2024/8/11/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805846">https://news.ycombinator.com/item?id=39805846</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Dead Man's Switch
 - [https://www.deadmansswitch.net](https://www.deadmansswitch.net)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T08:33:23+00:00

<p>Article URL: <a href="https://www.deadmansswitch.net/">https://www.deadmansswitch.net/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805834">https://news.ycombinator.com/item?id=39805834</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## The data model behind Notion's flexibility
 - [https://www.notion.so/blog/data-model-behind-notion](https://www.notion.so/blog/data-model-behind-notion)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T08:07:54+00:00

<p>Article URL: <a href="https://www.notion.so/blog/data-model-behind-notion">https://www.notion.so/blog/data-model-behind-notion</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805744">https://news.ycombinator.com/item?id=39805744</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Lezer: A parsing system for CodeMirror, inspired by Tree-sitter
 - [https://marijnhaverbeke.nl/blog/lezer.html](https://marijnhaverbeke.nl/blog/lezer.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T07:17:28+00:00

<p>Article URL: <a href="https://marijnhaverbeke.nl/blog/lezer.html">https://marijnhaverbeke.nl/blog/lezer.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805591">https://news.ycombinator.com/item?id=39805591</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## Fans quitting Spotify to save their love of music (2022)
 - [https://www.theguardian.com/music/2022/sep/27/theres-endless-choice-but-youre-not-listening-fans-quitting-spotify-to-save-their-love-of-music](https://www.theguardian.com/music/2022/sep/27/theres-endless-choice-but-youre-not-listening-fans-quitting-spotify-to-save-their-love-of-music)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T07:03:37+00:00

<p>Article URL: <a href="https://www.theguardian.com/music/2022/sep/27/theres-endless-choice-but-youre-not-listening-fans-quitting-spotify-to-save-their-love-of-music">https://www.theguardian.com/music/2022/sep/27/theres-endless-choice-but-youre-not-listening-fans-quitting-spotify-to-save-their-love-of-music</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805548">https://news.ycombinator.com/item?id=39805548</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## D2 Playground
 - [https://play.d2lang.com](https://play.d2lang.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T06:56:58+00:00

<p>Article URL: <a href="https://play.d2lang.com/">https://play.d2lang.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805529">https://news.ycombinator.com/item?id=39805529</a></p>
<p>Points: 5</p>
<p># Comments: 2</p>

## Scythians Between Russia and Ukraine
 - [https://languagelog.ldc.upenn.edu/nll/?p=63123](https://languagelog.ldc.upenn.edu/nll/?p=63123)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T06:50:56+00:00

<p>Article URL: <a href="https://languagelog.ldc.upenn.edu/nll/?p=63123">https://languagelog.ldc.upenn.edu/nll/?p=63123</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805515">https://news.ycombinator.com/item?id=39805515</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## The Biggest Crisis Is the End of Scarcity
 - [https://foreignpolicy.com/2024/03/16/end-of-scarcity-crisis-growth-war](https://foreignpolicy.com/2024/03/16/end-of-scarcity-crisis-growth-war)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T06:32:16+00:00

<p>Article URL: <a href="https://foreignpolicy.com/2024/03/16/end-of-scarcity-crisis-growth-war/">https://foreignpolicy.com/2024/03/16/end-of-scarcity-crisis-growth-war/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805459">https://news.ycombinator.com/item?id=39805459</a></p>
<p>Points: 11</p>
<p># Comments: 6</p>

## Why don't humans have tails?
 - [https://www.cnn.com/2024/03/23/world/humans-tails-genetic-mutation-junk-dna-scn/index.html](https://www.cnn.com/2024/03/23/world/humans-tails-genetic-mutation-junk-dna-scn/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T05:18:54+00:00

<p>Article URL: <a href="https://www.cnn.com/2024/03/23/world/humans-tails-genetic-mutation-junk-dna-scn/index.html">https://www.cnn.com/2024/03/23/world/humans-tails-genetic-mutation-junk-dna-scn/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805299">https://news.ycombinator.com/item?id=39805299</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Creating an autopilot in X-Plane using Python
 - [https://austinsnerdythings.com/2021/10/15/creating-an-autopilot-in-x-plane-using-python-part-1](https://austinsnerdythings.com/2021/10/15/creating-an-autopilot-in-x-plane-using-python-part-1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T05:07:49+00:00

<p>Article URL: <a href="https://austinsnerdythings.com/2021/10/15/creating-an-autopilot-in-x-plane-using-python-part-1/">https://austinsnerdythings.com/2021/10/15/creating-an-autopilot-in-x-plane-using-python-part-1/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805269">https://news.ycombinator.com/item?id=39805269</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## For the Love of Cats in Turkey
 - [https://www.sapiens.org/culture/cat-human-bonds-history-turkey](https://www.sapiens.org/culture/cat-human-bonds-history-turkey)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T03:55:38+00:00

<p>Article URL: <a href="https://www.sapiens.org/culture/cat-human-bonds-history-turkey/">https://www.sapiens.org/culture/cat-human-bonds-history-turkey/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805052">https://news.ycombinator.com/item?id=39805052</a></p>
<p>Points: 14</p>
<p># Comments: 0</p>

## A nostalgic look back at when the Internet still felt joyful
 - [https://www.cnn.com/2024/03/14/style/lan-party-online-gamers-photos/index.html](https://www.cnn.com/2024/03/14/style/lan-party-online-gamers-photos/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T03:41:49+00:00

<p>Article URL: <a href="https://www.cnn.com/2024/03/14/style/lan-party-online-gamers-photos/index.html">https://www.cnn.com/2024/03/14/style/lan-party-online-gamers-photos/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39805005">https://news.ycombinator.com/item?id=39805005</a></p>
<p>Points: 23</p>
<p># Comments: 11</p>

## Solving the Nerd-Sniping Problem: When Electronics Meets Heat Equations
 - [https://praveshkoirala.com/2024/03/07/solving-the-nerd-sniping-problem-when-electronics-meets-heat](https://praveshkoirala.com/2024/03/07/solving-the-nerd-sniping-problem-when-electronics-meets-heat)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T02:58:13+00:00

<p>Article URL: <a href="https://praveshkoirala.com/2024/03/07/solving-the-nerd-sniping-problem-when-electronics-meets-heat/">https://praveshkoirala.com/2024/03/07/solving-the-nerd-sniping-problem-when-electronics-meets-heat/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39804829">https://news.ycombinator.com/item?id=39804829</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Cable ISP Fined $10k for Lying to FCC About Where It Offers Broadband
 - [https://ordonews.com/cable-isp-fined-10000-for-lying-to-fcc-about-where-it-offers-broadband](https://ordonews.com/cable-isp-fined-10000-for-lying-to-fcc-about-where-it-offers-broadband)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T01:59:36+00:00

<p>Article URL: <a href="https://ordonews.com/cable-isp-fined-10000-for-lying-to-fcc-about-where-it-offers-broadband/">https://ordonews.com/cable-isp-fined-10000-for-lying-to-fcc-about-where-it-offers-broadband/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39804529">https://news.ycombinator.com/item?id=39804529</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Core I9 14900KF Breaks World Record, Almost Achieves 9.1GHz (2023)
 - [https://www.tomshardware.com/news/core-i9-14900kf-breaks-world-record-almost-achieves-91ghz](https://www.tomshardware.com/news/core-i9-14900kf-breaks-world-record-almost-achieves-91ghz)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T01:39:26+00:00

<p>Article URL: <a href="https://www.tomshardware.com/news/core-i9-14900kf-breaks-world-record-almost-achieves-91ghz">https://www.tomshardware.com/news/core-i9-14900kf-breaks-world-record-almost-achieves-91ghz</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39804422">https://news.ycombinator.com/item?id=39804422</a></p>
<p>Points: 49</p>
<p># Comments: 24</p>

## CodeCrafters (YC S22) Is Hiring a Bootcamps Partnership Manager
 - [https://www.ycombinator.com/companies/codecrafters/jobs/tH6WSC3-bootcamps-partnerships-manager](https://www.ycombinator.com/companies/codecrafters/jobs/tH6WSC3-bootcamps-partnerships-manager)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T01:00:14+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/codecrafters/jobs/tH6WSC3-bootcamps-partnerships-manager">https://www.ycombinator.com/companies/codecrafters/jobs/tH6WSC3-bootcamps-partnerships-manager</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39804248">https://news.ycombinator.com/item?id=39804248</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## Linux Crisis Tools
 - [https://www.brendangregg.com/blog/2024-03-24/linux-crisis-tools.html](https://www.brendangregg.com/blog/2024-03-24/linux-crisis-tools.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T00:51:44+00:00

<p>Article URL: <a href="https://www.brendangregg.com/blog/2024-03-24/linux-crisis-tools.html">https://www.brendangregg.com/blog/2024-03-24/linux-crisis-tools.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39804214">https://news.ycombinator.com/item?id=39804214</a></p>
<p>Points: 306</p>
<p># Comments: 60</p>

## After 41 years, my first assembly program on my first computer, the Tomy Tutor
 - [http://oldvcr.blogspot.com/2024/03/after-41-years-my-first-assembly.html](http://oldvcr.blogspot.com/2024/03/after-41-years-my-first-assembly.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T00:50:43+00:00

<p>Article URL: <a href="http://oldvcr.blogspot.com/2024/03/after-41-years-my-first-assembly.html">http://oldvcr.blogspot.com/2024/03/after-41-years-my-first-assembly.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39804204">https://news.ycombinator.com/item?id=39804204</a></p>
<p>Points: 70</p>
<p># Comments: 10</p>

## Speaking without vocal cords, thanks to a new AI-assisted wearable device
 - [https://newsroom.ucla.edu/releases/speaking-without-vocal-cords-ucla-engineering-wearable-tech](https://newsroom.ucla.edu/releases/speaking-without-vocal-cords-ucla-engineering-wearable-tech)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T00:39:38+00:00

<p>Article URL: <a href="https://newsroom.ucla.edu/releases/speaking-without-vocal-cords-ucla-engineering-wearable-tech">https://newsroom.ucla.edu/releases/speaking-without-vocal-cords-ucla-engineering-wearable-tech</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39804138">https://news.ycombinator.com/item?id=39804138</a></p>
<p>Points: 54</p>
<p># Comments: 7</p>

## Oxide Cloud Computer. No Cables. No Assembly. Just Cloud
 - [https://oxide.computer](https://oxide.computer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T00:20:40+00:00

<p>Article URL: <a href="https://oxide.computer/">https://oxide.computer/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39804052">https://news.ycombinator.com/item?id=39804052</a></p>
<p>Points: 107</p>
<p># Comments: 69</p>

## Sheets of Graph Paper Were Used to Design Super Mario Bros
 - [https://www.archdaily.com/783657/the-sheets-of-graph-paper-they-used-to-design-super-mario-bros](https://www.archdaily.com/783657/the-sheets-of-graph-paper-they-used-to-design-super-mario-bros)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-03-24T00:12:22+00:00

<p>Article URL: <a href="https://www.archdaily.com/783657/the-sheets-of-graph-paper-they-used-to-design-super-mario-bros">https://www.archdaily.com/783657/the-sheets-of-graph-paper-they-used-to-design-super-mario-bros</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39803999">https://news.ycombinator.com/item?id=39803999</a></p>
<p>Points: 25</p>
<p># Comments: 3</p>

