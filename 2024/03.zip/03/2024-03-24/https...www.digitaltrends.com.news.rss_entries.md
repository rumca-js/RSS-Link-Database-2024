# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## Marvel 1943: Rise of Hydra: release date window, trailers, gameplay, and more
 - [https://www.digitaltrends.com/news/marvel-1943-rise-of-hydra-release-date-trailers-gameplay-news-rumors](https://www.digitaltrends.com/news/marvel-1943-rise-of-hydra-release-date-trailers-gameplay-news-rumors)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-03-24T09:42:36.387787+00:00

We're going back to the past to team up with two legendary heroes in Marvel 1943: Rise of Hydra. Details are scarce, but here's what we know.

