# Source:It's FOSS News, URL:https://news.itsfoss.com/rss, language:en-US

## Varia: A Sleek Open-Source Download Manager With Browser Extensions
 - [https://news.itsfoss.com/varia-download-manager](https://news.itsfoss.com/varia-download-manager)
 - RSS feed: https://news.itsfoss.com/rss
 - date published: 2024-03-24T06:01:41+00:00

Take a look at this interesting download manager!

