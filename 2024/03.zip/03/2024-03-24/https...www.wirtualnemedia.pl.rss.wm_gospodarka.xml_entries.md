# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Jak rozwiązać problem mikroplastiku
 - [https://www.wirtualnemedia.pl/artykul/jak-rozwiazac-problem-mikroplastiku](https://www.wirtualnemedia.pl/artykul/jak-rozwiazac-problem-mikroplastiku)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-03-24T08:23:15.640547+00:00

Naukowcy opracowali naturalny plastik produkowany z alg, który w ciągu miesięcy całkowicie się rozkłada, nie tworząc nawet mikrocząstek. Tymczasem zanieczyszczenie mikroplastikiem to rosnące na całym świecie zagrożenie.

## Założyciel Tigers inwestuje w nową spółkę
 - [https://www.wirtualnemedia.pl/artykul/franciszek-georgiew-tigers-sawicki-legal](https://www.wirtualnemedia.pl/artykul/franciszek-georgiew-tigers-sawicki-legal)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-03-24T08:23:15.618925+00:00

Franciszek Georgiew, założyciel agencji marketingowej Tigers oraz holdingu XXII Ventures (Huqiao, Automation House i Experiment 5M), inwestuje w kolejną spółkę. Od marca 2024 roku kancelaria prawna Sawicki Legal jest częścią holdingu XXII Ventures.

