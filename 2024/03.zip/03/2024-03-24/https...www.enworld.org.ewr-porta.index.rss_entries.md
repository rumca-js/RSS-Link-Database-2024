# Source:EN World Tabletop RPG News & Reviews, URL:https://www.enworld.org/ewr-porta/index.rss, language:en

## News Digest for March 24. 2024
 - [https://www.enworld.org/threads/news-digest-for-march-24-2024.703268](https://www.enworld.org/threads/news-digest-for-march-24-2024.703268)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-03-24T15:25:00+00:00

<div class="bbWrapper">D&amp;D LEGO and Converse, Previews of D&amp;D 2024, no more Baldur's Gate, and more!</div>

## Freebies, Sales, and Charity Bundles for March 24, 2024
 - [https://www.enworld.org/threads/freebies-sales-and-charity-bundles-for-march-24-2024.703306](https://www.enworld.org/threads/freebies-sales-and-charity-bundles-for-march-24-2024.703306)
 - RSS feed: https://www.enworld.org/ewr-porta/index.rss
 - date published: 2024-03-24T15:04:00+00:00

<div class="bbWrapper">D&amp;D, Pathfinder, Avatar: The Last Airbender, Dungeon Crawl Classics, OSR, Dragonbane, Call of Cthulhu, Warhammer Fantasy Role Play, World of Darkness, and more!</div>

