# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Everyone Who Tried This Has FAILED – Khadas Mind Modular PC
 - [https://www.youtube.com/watch?v=kaf3pdJ_Cow](https://www.youtube.com/watch?v=kaf3pdJ_Cow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2024-03-24T17:00:17+00:00

Thanks again Khadas for sponsoring today’s video! Save $100 on Khadas Mind using coupon code LTTMIND on Khadas.com and Aliexpress.

Purchase Khadas Mind from Khadas.com: https://www.khadas.com/mind
Purchase Khadas Mind from Aliexpress: https://s.click.aliexpress.com/e/_oF7auvO
*Coupon code valid on Khadas.com and Aliexpress, valid until end of April 2024.

This thing makes the Mac Mini look gigantic! And don’t even get us started on how big your full tower gaming rig is. The Khadas Mind is a tiny workstation that has big plans. On top of containing a 12-core Intel processor this thing will be able to dock with an RTX 4060 Ti using their new-fangled Mind Connector! The only thing in their way? That pesky PCIe standard.

Discuss on the forum: https://linustechtips.com/topic/1564088-everyone-who-tried-this-has-failed-%E2%80%93-khadas-mind-modular-pc/

Purchase Khadas Mind on Amazon:
US: https://lmg.gg/khadasmindus
UK: https://lmg.gg/khadasminduk
FR: https://lmg.gg/khadasmindfr



