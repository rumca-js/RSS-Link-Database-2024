# Source:BGR, URL:https://bgr.com/feed, language:en-US

## Google bringing Gemini AI to iPhone is so infuriating, but not surprising
 - [https://bgr.com/business/google-bringing-gemini-ai-to-iphone-is-so-infuriating-but-not-surprising](https://bgr.com/business/google-bringing-gemini-ai-to-iphone-is-so-infuriating-but-not-surprising)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-03-24T23:03:00+00:00

<p>Spend enough time in the online content creation business, and there’s a good chance you’ll eventually come to regard Google sort of like the alien &#8230;</p>
<p>The post <a href="https://bgr.com/business/google-bringing-gemini-ai-to-iphone-is-so-infuriating-but-not-surprising/">Google bringing Gemini AI to iPhone is so infuriating, but not surprising</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## How to add a beneficiary to your Apple Savings account
 - [https://bgr.com/tech/how-to-add-a-beneficiary-to-your-apple-savings-account](https://bgr.com/tech/how-to-add-a-beneficiary-to-your-apple-savings-account)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-03-24T22:18:00+00:00

<p>Apple&#8217;s Savings account is a feature exclusive to Apple Card users and lets you earn interest on your deposits. You can even automatically deposit Daily &#8230;</p>
<p>The post <a href="https://bgr.com/tech/how-to-add-a-beneficiary-to-your-apple-savings-account/">How to add a beneficiary to your Apple Savings account</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Researchers found a ‘ghost shark’ off the coast of Thailand
 - [https://bgr.com/science/researchers-found-a-ghost-shark-off-the-coast-of-thailand](https://bgr.com/science/researchers-found-a-ghost-shark-off-the-coast-of-thailand)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-03-24T19:12:00+00:00

<p>The ocean is a terrifying place. Don’t get me wrong, I think it is absolutely beautiful, too, and I plan to enjoy my stint on &#8230;</p>
<p>The post <a href="https://bgr.com/science/researchers-found-a-ghost-shark-off-the-coast-of-thailand/">Researchers found a &#8216;ghost shark&#8217; off the coast of Thailand</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## 7 AI features that are already hiding on your iPhone
 - [https://bgr.com/tech/ai-features-that-are-already-hiding-on-your-iphone](https://bgr.com/tech/ai-features-that-are-already-hiding-on-your-iphone)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-03-24T16:06:00+00:00

<p>Apple&#8217;s upcoming software update iOS 18 is expected to be full of AI features for iPhone users. Still, it doesn&#8217;t mean you can&#8217;t take advantage &#8230;</p>
<p>The post <a href="https://bgr.com/tech/ai-features-that-are-already-hiding-on-your-iphone/">7 AI features that are already hiding on your iPhone</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## The Pixel 8a is the phone Apple’s iPhone SE 4 needs to beat
 - [https://bgr.com/tech/the-pixel-8a-is-the-phone-apples-iphone-se-4-needs-to-beat](https://bgr.com/tech/the-pixel-8a-is-the-phone-apples-iphone-se-4-needs-to-beat)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-03-24T14:34:00+00:00

<p>With less than two months to go until Google I/O 2024, the Pixel 8a doesn&#8217;t have any more secrets after the big specs leak this &#8230;</p>
<p>The post <a href="https://bgr.com/tech/the-pixel-8a-is-the-phone-apples-iphone-se-4-needs-to-beat/">The Pixel 8a is the phone Apple’s iPhone SE 4 needs to beat</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## NASA volunteers help find 15 rare asteroids with tails
 - [https://bgr.com/science/nasa-volunteers-help-find-15-rare-asteroids-with-tails](https://bgr.com/science/nasa-volunteers-help-find-15-rare-asteroids-with-tails)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-03-24T13:02:00+00:00

<p>Despite popular belief, not all space rocks with tails are comets. In fact, asteroids with tails are by far some of the rarest asteroids that &#8230;</p>
<p>The post <a href="https://bgr.com/science/nasa-volunteers-help-find-15-rare-asteroids-with-tails/">NASA volunteers help find 15 rare asteroids with tails</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

