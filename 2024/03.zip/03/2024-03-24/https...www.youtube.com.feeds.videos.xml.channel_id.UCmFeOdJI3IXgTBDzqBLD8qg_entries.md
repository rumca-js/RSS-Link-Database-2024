# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## Neuralink Is The Worst Thing Ever Made
 - [https://www.youtube.com/watch?v=Fi_NVIbYGCk](https://www.youtube.com/watch?v=Fi_NVIbYGCk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2024-03-24T05:43:55+00:00

Moon Society: https://www.skool.com/moon-society-5881/about

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT

