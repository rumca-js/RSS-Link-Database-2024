# Source:Reddit - News, URL:https://www.reddit.com/r/news/.rss, language:en-US

## California Insurance Commissioner Ricardo Lara responds after State Farm announces it will not renew thousands of policies | abc7.com
 - [https://www.reddit.com/r/news/comments/1bmwjbc/california_insurance_commissioner_ricardo_lara](https://www.reddit.com/r/news/comments/1bmwjbc/california_insurance_commissioner_ricardo_lara)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T21:49:57+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/DCC_4LIFE"> /u/DCC_4LIFE </a> <br /> <span><a href="https://abc7.com/california-insurance-commissioner-ricardo-lara-speaks-out-after-state-farm-announces-it-will-not-renew-thousands-of-policies/14559707/#amp_ct=1711316800524&amp;amp_tf=From%20%251%24s&amp;aoh=17113167223223&amp;referrer=https%3A%2F%2Fwww.google.com&amp;ampshare=https%3A%2F%2Fabc7.com%2Fcalifornia-insurance-commissioner-ricardo-lara-speaks-out-after-state-farm-announces-it-will-not-renew-thousands-of-policies%2F14559707%2F">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmwjbc/california_insurance_commissioner_ricardo_lara/">[comments]</a></span>

## Simon Harris to become Ireland’s youngest prime minister
 - [https://www.reddit.com/r/news/comments/1bmvuuv/simon_harris_to_become_irelands_youngest_prime](https://www.reddit.com/r/news/comments/1bmvuuv/simon_harris_to_become_irelands_youngest_prime)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T21:21:36+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/SunImaginary3947"> /u/SunImaginary3947 </a> <br /> <span><a href="https://www.theguardian.com/world/2024/mar/24/simon-harris-to-become-ireland-youngest-prime-minister">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmvuuv/simon_harris_to_become_irelands_youngest_prime/">[comments]</a></span>

## State Farm won’t renew 72,000 insurance policies in California - Los Angeles Times
 - [https://www.reddit.com/r/news/comments/1bmv115/state_farm_wont_renew_72000_insurance_policies_in](https://www.reddit.com/r/news/comments/1bmv115/state_farm_wont_renew_72000_insurance_policies_in)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T20:47:49+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/DCC_4LIFE"> /u/DCC_4LIFE </a> <br /> <span><a href="https://www.latimes.com/california/story/2024-03-23/state-farm-wont-renew-72-000-insurance-policies-in-california-worsening-the-states-insurance-crisis">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmv115/state_farm_wont_renew_72000_insurance_policies_in/">[comments]</a></span>

## A digital lifeline for millions of Americans is in jeopardy. Here’s why | CNN Business
 - [https://www.reddit.com/r/news/comments/1bmu2j8/a_digital_lifeline_for_millions_of_americans_is](https://www.reddit.com/r/news/comments/1bmu2j8/a_digital_lifeline_for_millions_of_americans_is)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T20:08:00+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/StrikeForceOne"> /u/StrikeForceOne </a> <br /> <span><a href="https://www.cnn.com/2024/03/23/tech/acp-affordable-connectivity-program/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmu2j8/a_digital_lifeline_for_millions_of_americans_is/">[comments]</a></span>

## Rare disorder causes man to see people's faces as 'demonic'
 - [https://www.reddit.com/r/news/comments/1bmspkc/rare_disorder_causes_man_to_see_peoples_faces_as](https://www.reddit.com/r/news/comments/1bmspkc/rare_disorder_causes_man_to_see_peoples_faces_as)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T19:12:42+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Trexmasterman"> /u/Trexmasterman </a> <br /> <span><a href="https://www.nbcnews.com/health/health-news/disorder-man-sees-demonic-faces-rcna144533">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmspkc/rare_disorder_causes_man_to_see_peoples_faces_as/">[comments]</a></span>

## US, Japan plan biggest upgrade to security pact in over 60 years, FT reports
 - [https://www.reddit.com/r/news/comments/1bmsom7/us_japan_plan_biggest_upgrade_to_security_pact_in](https://www.reddit.com/r/news/comments/1bmsom7/us_japan_plan_biggest_upgrade_to_security_pact_in)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T19:11:40+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/twotwo_twentytwo"> /u/twotwo_twentytwo </a> <br /> <span><a href="https://www.reuters.com/world/us-japan-plan-biggest-upgrade-security-pact-more-than-60-years-ft-reports-2024-03-24/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmsom7/us_japan_plan_biggest_upgrade_to_security_pact_in/">[comments]</a></span>

## Gunmen attack police station in Armenian capital of Yerevan
 - [https://www.reddit.com/r/news/comments/1bmnh1v/gunmen_attack_police_station_in_armenian_capital](https://www.reddit.com/r/news/comments/1bmnh1v/gunmen_attack_police_station_in_armenian_capital)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T15:31:43+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/LatterTarget7"> /u/LatterTarget7 </a> <br /> <span><a href="https://www.reuters.com/world/asia-pacific/gunmen-storm-police-station-armenian-capital-yerevan-news-agencies-report-2024-03-24/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmnh1v/gunmen_attack_police_station_in_armenian_capital/">[comments]</a></span>

## Mega Millions jackpot rises to $1.1 billion after another drawing without a big winner
 - [https://www.reddit.com/r/news/comments/1bmnern/mega_millions_jackpot_rises_to_11_billion_after](https://www.reddit.com/r/news/comments/1bmnern/mega_millions_jackpot_rises_to_11_billion_after)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T15:29:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/a_dogs_mother"> /u/a_dogs_mother </a> <br /> <span><a href="https://apnews.com/article/mega-millions-jackpot-lottery-c0c579d6d29716483756f81646a7430f">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmnern/mega_millions_jackpot_rises_to_11_billion_after/">[comments]</a></span>

## Texas medical panel won't provide list of exceptions to abortion ban
 - [https://www.reddit.com/r/news/comments/1bmnal1/texas_medical_panel_wont_provide_list_of](https://www.reddit.com/r/news/comments/1bmnal1/texas_medical_panel_wont_provide_list_of)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T15:23:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/a_dogs_mother"> /u/a_dogs_mother </a> <br /> <span><a href="https://apnews.com/article/abortion-texas-medical-board-exception-guidelines-a6deef7c6fa4917c8cdbfd339a343dc4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmnal1/texas_medical_panel_wont_provide_list_of/">[comments]</a></span>

## Poland demands explanation from Russia after a missile enters its airspace during attack on Ukraine
 - [https://www.reddit.com/r/news/comments/1bmm81n/poland_demands_explanation_from_russia_after_a](https://www.reddit.com/r/news/comments/1bmm81n/poland_demands_explanation_from_russia_after_a)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T14:36:29+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/slothvader"> /u/slothvader </a> <br /> <span><a href="https://apnews.com/article/russia-ukraine-missile-airspace-violation-c9d2511f169e9f80a08082726c118114">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmm81n/poland_demands_explanation_from_russia_after_a/">[comments]</a></span>

## 85 years after a racist mob drove Opal Lee’s family away, she’s getting a new home on the same spot
 - [https://www.reddit.com/r/news/comments/1bml1um/85_years_after_a_racist_mob_drove_opal_lees](https://www.reddit.com/r/news/comments/1bml1um/85_years_after_a_racist_mob_drove_opal_lees)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T13:42:27+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/AudibleNod"> /u/AudibleNod </a> <br /> <span><a href="https://apnews.com/article/opal-lee-new-house-racist-mob-fort-worth-texas-d06e8163c65abaee8569957a5d97092e">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bml1um/85_years_after_a_racist_mob_drove_opal_lees/">[comments]</a></span>

## UN experts demand investigation into claims Israeli forces killed, raped and sexually assaulted Palestinian women and girls | CNN
 - [https://www.reddit.com/r/news/comments/1bmj1o4/un_experts_demand_investigation_into_claims](https://www.reddit.com/r/news/comments/1bmj1o4/un_experts_demand_investigation_into_claims)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T11:57:04+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Therealomerali"> /u/Therealomerali </a> <br /> <span><a href="https://www.cnn.com/2024/02/20/middleeast/israel-hamas-un-investigation-sexual-abuse-intl/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmj1o4/un_experts_demand_investigation_into_claims/">[comments]</a></span>

## Mexico's president says he won't fight drug cartels on US orders, calls it a 'Mexico First' policy | AP News
 - [https://www.reddit.com/r/news/comments/1bmedy6/mexicos_president_says_he_wont_fight_drug_cartels](https://www.reddit.com/r/news/comments/1bmedy6/mexicos_president_says_he_wont_fight_drug_cartels)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T06:44:43+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/DCC_4LIFE"> /u/DCC_4LIFE </a> <br /> <span><a href="https://apnews.com/article/mexico-first-nationalistic-policy-drug-cartels-6e7a78ff41c895b4e10930463f24e9fb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmedy6/mexicos_president_says_he_wont_fight_drug_cartels/">[comments]</a></span>

## iPhone's Emergency SOS: Family trapped on Mt. Hood rescued via Satellite
 - [https://www.reddit.com/r/news/comments/1bmd5hh/iphones_emergency_sos_family_trapped_on_mt_hood](https://www.reddit.com/r/news/comments/1bmd5hh/iphones_emergency_sos_family_trapped_on_mt_hood)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T05:22:14+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/TopMore7548"> /u/TopMore7548 </a> <br /> <span><a href="https://forums.appleinsider.com/discussion/235862">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmd5hh/iphones_emergency_sos_family_trapped_on_mt_hood/">[comments]</a></span>

## Search and rescue mission in Delaware County ongoing after child falls into Chester Creek - CBS News
 - [https://www.reddit.com/r/news/comments/1bmc1hl/search_and_rescue_mission_in_delaware_county](https://www.reddit.com/r/news/comments/1bmc1hl/search_and_rescue_mission_in_delaware_county)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T04:16:11+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/DCC_4LIFE"> /u/DCC_4LIFE </a> <br /> <span><a href="https://www.cbsnews.com/philadelphia/news/search-and-rescue-mission-ongoing-delaware-county-child-fell-into-chester-creek/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bmc1hl/search_and_rescue_mission_in_delaware_county/">[comments]</a></span>

## Cable ISP Fined $10,000 For Lying To FCC About Where It Offers Broadband
 - [https://www.reddit.com/r/news/comments/1bm9iv1/cable_isp_fined_10000_for_lying_to_fcc_about](https://www.reddit.com/r/news/comments/1bm9iv1/cable_isp_fined_10000_for_lying_to_fcc_about)
 - RSS feed: https://www.reddit.com/r/news/.rss
 - date published: 2024-03-24T02:02:02+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/TopMore7548"> /u/TopMore7548 </a> <br /> <span><a href="https://ordonews.com/cable-isp-fined-10000-for-lying-to-fcc-about-where-it-offers-broadband/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/news/comments/1bm9iv1/cable_isp_fined_10000_for_lying_to_fcc_about/">[comments]</a></span>

