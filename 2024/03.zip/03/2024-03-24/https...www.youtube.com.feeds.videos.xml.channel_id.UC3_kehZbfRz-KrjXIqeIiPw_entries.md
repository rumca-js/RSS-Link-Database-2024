# Source:Leadhead, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3_kehZbfRz-KrjXIqeIiPw, language:en

## How TTT Helped me get my Social Skills Back
 - [https://www.youtube.com/watch?v=9hZUrUZBcac](https://www.youtube.com/watch?v=9hZUrUZBcac)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3_kehZbfRz-KrjXIqeIiPw
 - date published: 2024-03-24T16:30:01+00:00

Patreon: https://www.patreon.com/LeadheadYT
Discord: https://discord.gg/PVvXESU7WU
Second Channel: https://www.youtube.com/Porkbrain
Twitter: https://twitter.com/LeadheadYT

The music in this video is from the Metal Gear Solid 2 OST by Norihiko Hibino and Harry Gregson-Williams, as well as a cover of Carcelera by Vince Py, linked here: https://www.youtube.com/watch?v=66fjjc9-9K4

