# Source:Goonhammer, URL:https://www.goonhammer.com/feed, language:en-GB

## Black Library Review: Outgunned by Denny Flowers
 - [https://www.goonhammer.com/black-library-review-outgunned-by-denny-flowers](https://www.goonhammer.com/black-library-review-outgunned-by-denny-flowers)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-24T14:00:58+00:00

&#160; &#8220;The Aeronautica Imperialis are the masters of the skies in the 41st millennium, waging wars of breakneck aerial combat where only skill stands between victory and death. Flight Commander Lucille von Shard is an ace, a living exemplar of what it means to fly in the name of the Emperor… or so Propagandist Kile [&#8230;]

## The Best Year in Gaming: 1976 vs. 2003
 - [https://www.goonhammer.com/the-best-year-in-gaming-1976-vs-2003](https://www.goonhammer.com/the-best-year-in-gaming-1976-vs-2003)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-24T11:15:36+00:00

Today we look at 1976 vs. 2003 to determine the best year in gaming.

## The Best Year in Gaming: 2003
 - [https://www.goonhammer.com/the-best-year-in-gaming-2003](https://www.goonhammer.com/the-best-year-in-gaming-2003)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-24T11:01:12+00:00

We look at the top games of 2003 and the year's case as the best year in gaming.

## The Best Year in Gaming: 1976
 - [https://www.goonhammer.com/the-best-year-in-gaming-1976](https://www.goonhammer.com/the-best-year-in-gaming-1976)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-24T11:00:40+00:00

We take a look at the games and events of 1976, and make the best case we can for why it was the best year in gaming.

## CYRAC: Kill Team Termination Adepticon Preview Review
 - [https://www.goonhammer.com/cyrac-kill-team-termination-adepticon-preview-review](https://www.goonhammer.com/cyrac-kill-team-termination-adepticon-preview-review)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-24T10:00:23+00:00

John from Can You Roll a Crit? returns with a new video covering the latest reveal for Kill Team from Adepticon 2024! He covers the box and the two new kill teams: Hearnkyn Yaegirs and Brood Brothers, going over their new models and teased rules!

