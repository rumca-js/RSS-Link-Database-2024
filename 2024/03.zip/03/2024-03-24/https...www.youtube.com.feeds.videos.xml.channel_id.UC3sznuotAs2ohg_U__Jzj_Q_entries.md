# Source:The Film Theorists, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3sznuotAs2ohg_U__Jzj_Q, language:en-US

## Film Theory: This Series is NOT Made for Kids! (Guby)
 - [https://www.youtube.com/watch?v=DH6Utz9KYOQ](https://www.youtube.com/watch?v=DH6Utz9KYOQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3sznuotAs2ohg_U__Jzj_Q
 - date published: 2024-03-24T18:05:00+00:00

*SUBSCRIBE to Save the Kids from GÜBY*
Hurry, before it’s too late! 👉 https://tinyurl.com/ft-guby-sub

GÜBY is DEFINITELY not made for kids. So, what the HECK is GÜBY then? While the show may be bright and colorful on the outside, it is deep, dark, and terrifying on the inside. It turns out the TV show host is kidnapping kids through the TV. Come with us, loyal Theorists, as Lee dives into his first analog horror series as host. It is CREEPY!

Watch the GÜBY & Friends Series ► https://www.youtube.com/@GUUUBY
‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐
*🔽 Don’t Miss Out!*
Get Your TheoryWear! ► https://theorywear.com/
Dive into the Reddit! ► https://www.reddit.com/r/GameTheorists/

Need Royalty Free Music for your Content? Try Epidemic Sound.
Get Your 30 Day Free Trial Now ► http://share.epidemicsound.com/TheFilmTheorists
‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐
*👀 Watch MORE Theories:*
Amazing Digital Circus is Hell! ►► https://youtu.be/Aa8bBpZxFws
The Next B

