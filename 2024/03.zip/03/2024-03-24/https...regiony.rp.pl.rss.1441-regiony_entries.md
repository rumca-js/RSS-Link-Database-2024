# Source:RP - Regiony, URL:https://regiony.rp.pl/rss/1441-regiony, language:pl-PL

## Rafał Bruski, prezydent Bydgoszczy: Ten rząd traktuje samorządy po partnersku
 - [https://regiony.rp.pl/okiem-samorzadowca/art40050981-rafal-bruski-prezydent-bydgoszczy-ten-rzad-traktuje-samorzady-po-partnersku](https://regiony.rp.pl/okiem-samorzadowca/art40050981-rafal-bruski-prezydent-bydgoszczy-ten-rzad-traktuje-samorzady-po-partnersku)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-03-24T10:43:00+00:00

Naprawa finansów publicznych wymaga zmiany ustaw, wypracowywanych wspólnie przez rząd i samorządy. Efekty pewnie będzie widać za kilka miesięcy – mówi Rafał Bruski, ubiegający się o reelekcję prezydent Bydgoszczy.

