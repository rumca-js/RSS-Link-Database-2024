# Source:thenewboston, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJbPGzawDH1njbqV-D5HqKw, language:en

## Prompt Engineering for Beginners - Tutorial 17 - Anthropic Claude 3
 - [https://www.youtube.com/watch?v=_7zmngXU3vE](https://www.youtube.com/watch?v=_7zmngXU3vE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJbPGzawDH1njbqV-D5HqKw
 - date published: 2024-03-24T17:02:07+00:00

OpenAI Docs: https://platform.openai.com/docs/introduction
Anthropic Docs: https://docs.anthropic.com/claude/docs
PromptLayer: https://promptlayer.com/
DevSprout: https://www.youtube.com/c/devsprout
Source Code: https://github.com/buckyroberts/AI-Playground

