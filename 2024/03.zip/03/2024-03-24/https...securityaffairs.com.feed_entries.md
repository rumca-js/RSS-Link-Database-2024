# Source:Security Affairs, URL:https://securityaffairs.com/feed, language:en-US

## Security Affairs newsletter Round 464 by Pierluigi Paganini – INTERNATIONAL EDITION
 - [https://securityaffairs.com/161016/breaking-news/security-affairs-newsletter-round-464-by-pierluigi-paganini-international-edition.html](https://securityaffairs.com/161016/breaking-news/security-affairs-newsletter-round-464-by-pierluigi-paganini-international-edition.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2024-03-24T15:57:30+00:00

A new round of the weekly SecurityAffairs newsletter arrived! Every week the best security articles from Security Affairs are free for you in your email box. Enjoy a new round of the weekly SecurityAffairs newsletter, including the international press. Russia-linked APT29 targeted German political parties with WINELOADER backdoor Mozilla fixed Firefox zero-days exploited at Pwn2Own [&#8230;]

## Cybercriminals Accelerate Online Scams During Ramadan and Eid Fitr
 - [https://securityaffairs.com/161009/cyber-crime/cybercriminals-accelerate-scams-ramadan.html](https://securityaffairs.com/161009/cyber-crime/cybercriminals-accelerate-scams-ramadan.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2024-03-24T10:37:05+00:00

During the month of Ramadan, Resecurity observed a significant increase in fraudulent activities and scams. During the month of Ramadan, Resecurity observed a significant increase in fraudulent activities and scams, coinciding with a surge in retail and online transactions. Middle Eastern enterprises, facing this heightened risk, are urged to bolster consumer protection and reinforce their [&#8230;]

