# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## How do humans find any joy at all? | @JordanBPeterson
 - [https://www.youtube.com/watch?v=cucVk8k3J4E](https://www.youtube.com/watch?v=cucVk8k3J4E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-03-24T18:00:23+00:00



