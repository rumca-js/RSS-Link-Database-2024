# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Users Outraged by Instagram and Threads Limiting Political Content Ahead of Election
 - [https://www.theepochtimes.com/us/users-outraged-by-instagram-and-threads-limiting-political-content-ahead-of-election-5613886](https://www.theepochtimes.com/us/users-outraged-by-instagram-and-threads-limiting-political-content-ahead-of-election-5613886)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-03-24T14:23:58+00:00

The social network Instagram logo on a smartphone screen in Moscow on March 14, 2022. (-/AFP via Getty Images)

