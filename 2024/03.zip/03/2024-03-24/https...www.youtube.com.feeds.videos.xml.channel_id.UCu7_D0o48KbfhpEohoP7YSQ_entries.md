# Source:Andreas Spiess, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCu7_D0o48KbfhpEohoP7YSQ, language:en-US

## How does NB-IOT and CAT-M1 / LTE-M compare to LoRaWAN (Tutorial)?
 - [https://www.youtube.com/watch?v=6PLnpPH8_Ic](https://www.youtube.com/watch?v=6PLnpPH8_Ic)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCu7_D0o48KbfhpEohoP7YSQ
 - date published: 2024-03-24T08:00:03+00:00

Smartphones connect nearly everywhere to the Internet. What if we could use all their towers to connect our sensors and other gadgets to the Internet? Would LoRaWAN or Sigfox be obsolete?
If you are brave, you will follow my journey and learn much about cellular IOT technology and how to survive the minefield it is built on. Then, you can decide what to do with LoRaWAN.

My second channel: https://www.youtube.com/HB9BLAWireless

Links:
Walter: https://www.crowdsupply.com/dptechnics/walter
SIM7080 ESP32-S3 board: https://s.click.aliexpress.com/e/_Ddg3kQv
SIM7080 Pi hat: https://s.click.aliexpress.com/e/_DBpX5ut
SIM7080 Pi Pico hat: https://s.click.aliexpress.com/e/_DkNOWAv
Soracom SIM: https://www.soracom.io/
Crout SIM: https://crout.de/
Swiss Communication Competence Center: https://swiss-ccc.com/
Anritsu MT8821C: https://www.anritsu.com/en-us/test-measurement/products/mt8821c

Patreon supporter companies:
https://passiv-energie.gmbh/
https://www.welectron.com/
https://yosmar

