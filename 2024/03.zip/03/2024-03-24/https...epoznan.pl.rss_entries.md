# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Coraz więcej ogródków gastronomicznych na Starym Rynku. Niemal wszystkie... bez parasoli
 - [https://epoznan.pl/news-news-149199-coraz_wiecej_ogrodkow_gastronomicznych_na_starym_rynku_niemal_wszystkie_bez_parasoli?rss=1](https://epoznan.pl/news-news-149199-coraz_wiecej_ogrodkow_gastronomicznych_na_starym_rynku_niemal_wszystkie_bez_parasoli?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T19:00:00+00:00

Okazało się, że mają wadliwe mocowanie.

## Dziki niepokoją mieszkańców. &quot;Po odłowieniu zwierzęta niestety zostaną uśmiercone&quot;
 - [https://epoznan.pl/news-news-149200-dziki_niepokoja_mieszkancow_po_odlowieniu_zwierzeta_niestety_zostana_usmiercone?rss=1](https://epoznan.pl/news-news-149200-dziki_niepokoja_mieszkancow_po_odlowieniu_zwierzeta_niestety_zostana_usmiercone?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T18:00:00+00:00

Gmina Nowy Tomyśl liczy na współpracę z Poznaniem.

## Wnętrza jednej z inwestycji w Poznaniu mają ozdobić studenci
 - [https://epoznan.pl/news-news-149195-wnetrza_jednej_z_inwestycji_w_poznaniu_maja_ozdobic_studenci?rss=1](https://epoznan.pl/news-news-149195-wnetrza_jednej_z_inwestycji_w_poznaniu_maja_ozdobic_studenci?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T17:00:00+00:00

BPI Real Estate Poland, belgijski deweloper realizujący na Starołęce w Poznaniu inwestycję Panoramiqa, ogłosił konkurs &quot;Światło i bryła - impresje miejskie&quot; dla studentów Politechniki Poznańskiej.

## Wnętrza jednej z powstających inwestycji mieszkaniowych w Poznaniu mają ozdobić studenci
 - [https://epoznan.pl/news-news-149195-wnetrza_jednej_z_powstajacych_inwestycji_mieszkaniowych_w_poznaniu_maja_ozdobic_studenci?rss=1](https://epoznan.pl/news-news-149195-wnetrza_jednej_z_powstajacych_inwestycji_mieszkaniowych_w_poznaniu_maja_ozdobic_studenci?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T17:00:00+00:00

BPI Real Estate Poland, belgijski deweloper realizujący na Starołęce w Poznaniu inwestycję Panoramiqa, ogłosił konkurs &quot;Światło i bryła - impresje miejskie&quot; dla studentów Politechniki Poznańskiej.

## Z powodu &#039;usterki&#039; zamknęli Aquapark Term Maltańskich. &quot;O krok od tragedii&quot;
 - [https://epoznan.pl/news-news-149201-z_powodu_usterki_zamkneli_aquapark_term_maltanskich_o_krok_od_tragedii?rss=1](https://epoznan.pl/news-news-149201-z_powodu_usterki_zamkneli_aquapark_term_maltanskich_o_krok_od_tragedii?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T16:30:00+00:00

Trwa naprawa.

## Policjanci publikują zdjęcia z dworca i proszą o pomoc
 - [https://epoznan.pl/news-news-149196-policjanci_publikuja_zdjecia_z_dworca_i_prosza_o_pomoc?rss=1](https://epoznan.pl/news-news-149196-policjanci_publikuja_zdjecia_z_dworca_i_prosza_o_pomoc?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T16:00:00+00:00

Chodzi o kradzież.

## Rusza remont. Pasażerowie komunikacji zbiorowej muszą przygotować się na około 3 tygodnie utrudnień
 - [https://epoznan.pl/news-news-149198-rusza_remont_pasazerowie_komunikacji_zbiorowej_musza_przygotowac_sie_na_okolo_3_tygodnie_utrudnien?rss=1](https://epoznan.pl/news-news-149198-rusza_remont_pasazerowie_komunikacji_zbiorowej_musza_przygotowac_sie_na_okolo_3_tygodnie_utrudnien?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T15:45:00+00:00

Od wtorku 26 marca prowadzony będzie etapami remont nawierzchni ulicy Promienistej na odcinku od pętli autobusowej Os. Kopernika do ul. Rembertowskiej.

## Trzy razy jednego dnia pod ten sam market podjeżdżał radiowóz
 - [https://epoznan.pl/news-news-149194-trzy_razy_jednego_dnia_pod_ten_sam_market_podjezdzal_radiowoz?rss=1](https://epoznan.pl/news-news-149194-trzy_razy_jednego_dnia_pod_ten_sam_market_podjezdzal_radiowoz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T15:30:00+00:00

Już wiadomo, co się działo.

## &quot;Odbieramy niepokojące sygnały od pacjentów&quot;. NFZ nie wydaje żadnych bonów do aptek!
 - [https://epoznan.pl/news-news-149197-odbieramy_niepokojace_sygnaly_od_pacjentow_nfz_nie_wydaje_zadnych_bonow_do_aptek?rss=1](https://epoznan.pl/news-news-149197-odbieramy_niepokojace_sygnaly_od_pacjentow_nfz_nie_wydaje_zadnych_bonow_do_aptek?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T15:15:00+00:00

Jest apel, by nie wpłacać pieniędzy.

## Uwaga. NFZ nie wydaje żadnych bonów do aptek!
 - [https://epoznan.pl/news-news-149197-uwaga_nfz_nie_wydaje_zadnych_bonow_do_aptek?rss=1](https://epoznan.pl/news-news-149197-uwaga_nfz_nie_wydaje_zadnych_bonow_do_aptek?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T15:15:00+00:00

Jest apel, by nie wpłacać pieniędzy.

## Nowa pływalnia w Poznaniu coraz bliżej. 8 firm chętnych, by ją zbudować
 - [https://epoznan.pl/news-news-149192-nowa_plywalnia_w_poznaniu_coraz_blizej_8_firm_chetnych_by_ja_zbudowac?rss=1](https://epoznan.pl/news-news-149192-nowa_plywalnia_w_poznaniu_coraz_blizej_8_firm_chetnych_by_ja_zbudowac?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T15:00:00+00:00

Prace mają ruszyć jeszcze w tym roku.

## Zarobiła 3500 złotych na zablokowanym przez operatora telefonie
 - [https://epoznan.pl/news-news-149193-zarobila_3500_zlotych_na_zablokowanym_przez_operatora_telefonie?rss=1](https://epoznan.pl/news-news-149193-zarobila_3500_zlotych_na_zablokowanym_przez_operatora_telefonie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T14:30:00+00:00

Policjanci  z Zespołu do Walki z Przestępczością Gospodarczą na początku marca otrzymali informację o tym, że mieszkaniec Szamotuł padł ofiarą oszustwa.

## Wybitny architekt uczczony. Na ścianie kamienicy, w której mieszkał
 - [https://epoznan.pl/news-news-149191-wybitny_architekt_uczczony_na_scianie_kamienicy_w_ktorej_mieszkal?rss=1](https://epoznan.pl/news-news-149191-wybitny_architekt_uczczony_na_scianie_kamienicy_w_ktorej_mieszkal?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T13:45:00+00:00

W piątek odsłonięta została tablica upamiętniająca Rogera Sławskiego, poznaniaka, naczelnego architekta Powszechnej Wystawy Krajowej.

## Zwłoki młodej kobiety w mieszkaniu. To poznańska policjantka
 - [https://epoznan.pl/news-news-149190-zwloki_mlodej_kobiety_w_mieszkaniu_to_poznanska_policjantka?rss=1](https://epoznan.pl/news-news-149190-zwloki_mlodej_kobiety_w_mieszkaniu_to_poznanska_policjantka?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T13:15:00+00:00

Ciało zostało zabezpieczone do badań sekcyjnych.

## Robert Biedroń zaśpiewał &quot;Odę do radości&quot; w centrum Poznania
 - [https://epoznan.pl/news-news-149189-robert_biedron_zaspiewal_ode_do_radosci_w_centrum_poznania?rss=1](https://epoznan.pl/news-news-149189-robert_biedron_zaspiewal_ode_do_radosci_w_centrum_poznania?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T13:00:00+00:00

W związku z przypadającą w tym roku ważną rocznicą.

## Ostatnia szansa, by odwiedzić tegoroczny Jarmark Wielkanocny. Sporo się dzieje
 - [https://epoznan.pl/news-news-149188-ostatnia_szansa_by_odwiedzic_tegoroczny_jarmark_wielkanocny_sporo_sie_dzieje?rss=1](https://epoznan.pl/news-news-149188-ostatnia_szansa_by_odwiedzic_tegoroczny_jarmark_wielkanocny_sporo_sie_dzieje?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T12:30:00+00:00

Potrwa do godziny 19:00.

## Z palmami przeszli ulicami miasta
 - [https://epoznan.pl/news-news-149187-z_palmami_przeszli_ulicami_miasta?rss=1](https://epoznan.pl/news-news-149187-z_palmami_przeszli_ulicami_miasta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T11:45:00+00:00

Kościół Katolicki obchodzi Niedzielę Palmową.

## Strażnicy miejscy zatrzymywali rowerzystów na ulicach Poznania
 - [https://epoznan.pl/news-news-149186-straznicy_miejscy_zatrzymywali_rowerzystow_na_ulicach_poznania?rss=1](https://epoznan.pl/news-news-149186-straznicy_miejscy_zatrzymywali_rowerzystow_na_ulicach_poznania?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T11:30:00+00:00

Dostawali między innymi odblaski.

## Wyjątkowa atrakcja. &quot;Ryjek&quot; ciągnie &quot;kowbojkę&quot; nad Maltą
 - [https://epoznan.pl/news-news-149185-wyjatkowa_atrakcja_ryjek_ciagnie_kowbojke_nad_malta?rss=1](https://epoznan.pl/news-news-149185-wyjatkowa_atrakcja_ryjek_ciagnie_kowbojke_nad_malta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T11:00:00+00:00

To na powitanie wiosny.

## Słowa roty zabrzmiały na rynku. &quot;Ci ludzie stali się żołnierzami i przyjęli na siebie odpowiedzialność&quot;
 - [https://epoznan.pl/news-news-149184-slowa_roty_zabrzmialy_na_rynku_ci_ludzie_stali_sie_zolnierzami_i_przyjeli_na_siebie_odpowiedzialnosc?rss=1](https://epoznan.pl/news-news-149184-slowa_roty_zabrzmialy_na_rynku_ci_ludzie_stali_sie_zolnierzami_i_przyjeli_na_siebie_odpowiedzialnosc?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T10:30:00+00:00

Blisko 40 żołnierzy złożyło uroczystą przysięgę.

## Kandydaci na prezydenta Poznania miksowali w klubie Stonewall. Jaśkowiak: &quot;czułem się jak Travolta&quot;
 - [https://epoznan.pl/news-news-149183-kandydaci_na_prezydenta_poznania_miksowali_w_klubie_stonewall_jaskowiak_czulem_sie_jak_travolta?rss=1](https://epoznan.pl/news-news-149183-kandydaci_na_prezydenta_poznania_miksowali_w_klubie_stonewall_jaskowiak_czulem_sie_jak_travolta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T10:00:00+00:00

Akcja miała szczytny cel.

## Policjanci odzyskali skradziony motorower. &quot;17-latek wskazał, gdzie go porzucił&quot;
 - [https://epoznan.pl/news-news-149164-policjanci_odzyskali_skradziony_motorower_17_latek_wskazal_gdzie_go_porzucil?rss=1](https://epoznan.pl/news-news-149164-policjanci_odzyskali_skradziony_motorower_17_latek_wskazal_gdzie_go_porzucil?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T09:30:00+00:00

Jednoślad po wykonaniu przez policjantów niezbędnych czynności szybko wrócił do swojego właściciela, a sprawca kradzieży stanie przed Sądem.

## Rusza jeden z &quot;pierwszych tegorocznych, dużych remontów ulic&quot; w Poznaniu
 - [https://epoznan.pl/news-news-149182-rusza_jeden_z_pierwszych_tegorocznych_duzych_remontow_ulic_w_poznaniu?rss=1](https://epoznan.pl/news-news-149182-rusza_jeden_z_pierwszych_tegorocznych_duzych_remontow_ulic_w_poznaniu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T09:00:00+00:00

Roboty na ulicy Promienistej potrwają do końca kwietnia.

## Kolejna taka niedziela dopiero przed majówką.  Dziś &quot;transport zbiorowy będzie wzmocniony&quot;
 - [https://epoznan.pl/news-news-149181-kolejna_taka_niedziela_dopiero_przed_majowka_dzis_transport_zbiorowy_bedzie_wzmocniony?rss=1](https://epoznan.pl/news-news-149181-kolejna_taka_niedziela_dopiero_przed_majowka_dzis_transport_zbiorowy_bedzie_wzmocniony?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T08:30:00+00:00

24 marca to jedna z siedmiu niedziel, kiedy wszystkie sklepy mogą być otwarte.

## Wieczorna akcja służb na osiedu Tysiąclecia. Strażacy siłowo weszli do mieszkania
 - [https://epoznan.pl/news-news-149180-wieczorna_akcja_sluzb_na_osiedu_tysiaclecia_strazacy_silowo_weszli_do_mieszkania?rss=1](https://epoznan.pl/news-news-149180-wieczorna_akcja_sluzb_na_osiedu_tysiaclecia_strazacy_silowo_weszli_do_mieszkania?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-03-24T08:15:00+00:00

Do zdarzenia doszło w sobotę wieczorem.

