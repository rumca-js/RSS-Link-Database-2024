# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Czerwony Półksiężyc: Armia izraelska zarządziła ewakuację szpitala w Chan Junis
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9470309,czerwony-polksiezyc-armia-izraelska-zarzadzila-ewakuacje-szpitala-w-c.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9470309,czerwony-polksiezyc-armia-izraelska-zarzadzila-ewakuacje-szpitala-w-c.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T19:22:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LOxktkuTURBXy9jODJlOTM4OC0zOWRjLTRmMGItOTlhNi01YjBlMTE3Y2MyNmUuanBlZ5GTBc0BHcyg" />Armia izraelska zarządziła ewakuację szpitala w mieście Chan Junis w Strefie Gazy - powiadomił w niedzielę palestyński Czerwony Półksiężyc. Zdaniem izraelskiego wywiadu palestyńskie organizacje terrorystyczne wykorzystują szpitale jak centra operacyjne, z których prowadzą walkę, czemu zaprzecza Hamas.

## Szef Naftohazu: Rosyjski atak nie wpłynie na dostawy gazu dla odbiorców
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9470306,szef-naftohazu-rosyjski-atak-nie-wplynie-na-dostawy-gazu-dla-odbiorco.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9470306,szef-naftohazu-rosyjski-atak-nie-wplynie-na-dostawy-gazu-dla-odbiorco.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T19:19:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CtVktkuTURBXy81YTZiNzdjZC0zN2I3LTQxMWEtODg0OC1iMjNlYzY3MTk5ZDIuanBlZ5GTBc0BHcyg" />### dochodzi informacja o uszkodzeniu infrastruktury Naftohazu ###Prezes ukraińskiego koncernu paliwowego Naftohaz Ołeksij Czernyszow poinformował w niedzielę, że rosyjski ostrzał uszkodził naziemną infrastrukturę jednego z podziemnych magazynów firmy na zachodzie kraju, ale wrogi atak nie wpłynie na dostawy gazu dla odbiorców.

## Przedwyborcza debata kandydatów na prezydenta Warszawy w TVP. Poznaliśmy termin
 - [https://forsal.pl/kraj/polityka/artykuly/9470077,przedwyborcza-debata-kandydatow-na-prezydenta-warszawy-w-tvp-poznalis.html](https://forsal.pl/kraj/polityka/artykuly/9470077,przedwyborcza-debata-kandydatow-na-prezydenta-warszawy-w-tvp-poznalis.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T17:03:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/R1-ktkuTURBXy83ZmJlZDYyYS1hZDRiLTRkNGQtYTYxYi0xZjVmN2JhYmIzYzEuanBlZ5GTBc0BHcyg" />Prezydent Warszawy Rafał Trzaskowski przekazał, że w środę o godz. 20 w TVP odbędzie się przedwyborcza debata kandydatów na urząd prezydenta stolicy. &quot;Porozmawiajmy o najważniejszych sprawach dla Warszawy&quot; - powiedział Trzaskowski.

## Dlaczego samozwańcze Państwo Islamskie wybrało Rosję za cel ataku?
 - [https://forsal.pl/swiat/rosja/artykuly/9470066,dlaczego-samozwancze-panstwo-islamskie-wybralo-rosje-za-cel-ataku.html](https://forsal.pl/swiat/rosja/artykuly/9470066,dlaczego-samozwancze-panstwo-islamskie-wybralo-rosje-za-cel-ataku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T15:27:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Tj9ktkuTURBXy80MjczODQxNi0yYjE4LTRlYzMtYjlmNi1mMjU1Njk5NDViMDguanBlZ5GTBc0BHcyg" />- W relacjach Rosji z dżihadystami jest sporo złej krwi ze względu na wojny w Czeczenii, stosunek Rosji do muzułmanów na jej terenie, wykorzystywanie, mordowanie, traktowanie jako kozła ofiarnego w razie problemów, napuszczanie na nich neonazistów - mowi w rozmowie z DGP Kacper Rękawek, ekspert Międzynarodowego Centrum Zwalczania Terroryzmu (ICCT) w Hadze.

## Ukraińska armia: Uderzyliśmy w dwa rosyjskie okręty desantowe w Sewastopolu
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9470026,ukrainska-armia-uderzylismy-w-dwa-rosyjskie-okrety-desantowe-w-sewast.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9470026,ukrainska-armia-uderzylismy-w-dwa-rosyjskie-okrety-desantowe-w-sewast.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T13:19:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jwsktkuTURBXy9mYTMzODIxOS04MGM1LTRmZjItODliMy05MmIyZjliYjE1MWUuanBlZ5GTBc0BHcyg" />Ukraińska armia uderzyła w dwa rosyjskie okręty desantowe Jamał i Azow, a także w centrum łączności w Sewastopolu na okupowanym przez Rosję Krymie - poinformował w niedziele rano Sztab Generalny Sił Zbrojnych Ukrainy.

## Rosja zbudowała linię kolejową z Rostowa na Krym
 - [https://forsal.pl/swiat/artykuly/9470025,rosja-zbudowala-linie-kolejowa-z-rostowa-na-krym.html](https://forsal.pl/swiat/artykuly/9470025,rosja-zbudowala-linie-kolejowa-z-rostowa-na-krym.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T13:17:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JBVktkuTURBXy8xNTMyZTZmZS1lYWQzLTQyYzctYjk4YS1kNmIwNTIzODAzZWIuanBlZ5GTBc0BHcyg" />Nowo wybudowana linia kolejowa z Rostowa nad Donem na Krym jest jednym z największych rosyjskich projektów infrastrukturalnych na czasowo okupowanych terenach Ukrainy - przekazało w niedzielę brytyjskie ministerstwo obrony.

## Izraelczycy chcą przedterminowych wyborów. "Bibi" z władzą żegnać się nie zamierza
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9468297,izraelczycy-chca-przedterminowych-wyborow-bibi-z-wladza-zegnac-sie-nie-zamierza.html](https://forsal.pl/swiat/aktualnosci/artykuly/9468297,izraelczycy-chca-przedterminowych-wyborow-bibi-z-wladza-zegnac-sie-nie-zamierza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T13:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VstktkuTURBXy81MWM2NmI4NC1iYmY2LTQ3ZDgtOTQ1OS01YThkOTgwYzFiODcuanBlZ5GTBc0BHcyg" />Izraelczycy coraz głośniej domagają się przedterminowych wyborów. Ale „Bibi” z władzą żegnać się nie zamierza.

## Pszczoły-roboty i maszyny czytające emocje. AI "przejmuje" biznes i nasze życie
 - [https://forsal.pl/lifestyle/technologie/artykuly/9465335,pszczoly-roboty-i-maszyny-czytajace-emocje-ai-przejmuje-biznes-i-na.html](https://forsal.pl/lifestyle/technologie/artykuly/9465335,pszczoly-roboty-i-maszyny-czytajace-emocje-ai-przejmuje-biznes-i-na.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T13:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/p1GktkuTURBXy85OThiMzBlYi0xNWRlLTQ4ZjUtOTFiZS03MmJlYWYzNGI1YzIuanBlZ5GTBc0BHcyg" />Od butów, które niemal same Cię niosą, przez szczoteczki do zębów, które dbają o Twoje zdrowie lepiej niż dentysta, aż po roje sztucznych pszczół zapylających pola w miejsce tych prawdziwych – to wszystko nie są sceny z najnowszej produkcji Hollywood. To rzeczywistość, która czeka tuż za rogiem.

## Wojna cenowa w Polsce zbija "sklepową inflację"
 - [https://forsal.pl/biznes/handel/artykuly/9468313,wojna-cenowa-w-polsce-zbija-sklepowa-inflacje.html](https://forsal.pl/biznes/handel/artykuly/9468313,wojna-cenowa-w-polsce-zbija-sklepowa-inflacje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T13:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VS2ktkuTURBXy80MjEwYTVmNi1lMGUxLTRkZTEtOGMwZC01MmU4N2FlYWQwYzUuanBlZ5GTBc0BHcyg" />Sprzedaż detaliczna w cenach bieżących była w lutym o 6,7 proc. wyższa niż rok wcześniej, zaś sprzedaż liczona w cenach stałych urosła o 6,1 proc. (najlepszy wynik od wiosny 2022 r.) – podał GUS. Porównanie tych liczb pozwala stwierdzić, jaka była „sklepowa inflacja” (ogólny wskaźnik jest dużo szerszy, obejmuje m.in. usługi). Okazuje się, że wyniosła 0,6 proc. i jest najniższa od trzech lat. U sprzedawców paliw oraz samochodów ceny w skali roku spadają. Największy wzrost – przekraczający 4 proc. – ma miejsce w drogeriach i aptekach. A efekty głośnej wojny cenowej pomiędzy największymi dyskontami? W pewnej mierze to ona ściągnęła sklepową inflację tak nisko, ale szczegółów nie znamy, bo od kilku lat w kategorii „pozostała sprzedaż w niewyspecjalizowanych sklepach” dane nie są publikowane.

## Liczba rannych w ataku terrorystów na salę koncertową w Rosji wzrosła do 154
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9470009,liczba-rannych-w-ataku-terrorystow-na-sale-koncertowa-w-rosji-wzrosla.html](https://forsal.pl/swiat/aktualnosci/artykuly/9470009,liczba-rannych-w-ataku-terrorystow-na-sale-koncertowa-w-rosji-wzrosla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T10:07:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ob1ktkuTURBXy85OTkyM2FkOS00OWU4LTQ5NzUtOTZlYi1iNDdmOTM5NTcwOGEuanBlZ5GTBc0BHcyg" />Liczba osób, które ucierpiały w wyniku ataku terrorystów na salę koncertową Crocus City Hall w piątek wieczorem, wzrosła do 154 – powiadomiły struktury ministerstwa zdrowia. Liczba ofiar śmiertelnych to 133.

## Rosję czeka kolejna "wojna"? Grozi jej rosnąca wewnętrzna destabilizacja i gniew muzułmanów
 - [https://forsal.pl/swiat/rosja/artykuly/9470002,rosje-czeka-kolejna-wojna-grozi-jej-rosnaca-wewnetrzna-destabilizac.html](https://forsal.pl/swiat/rosja/artykuly/9470002,rosje-czeka-kolejna-wojna-grozi-jej-rosnaca-wewnetrzna-destabilizac.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T08:57:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dMPktkuTURBXy9iZDY4ZjA2Mi03YTRmLTQwMDYtODQ5Zi1lYWNmMDM5N2RhZTkuanBlZ5GTBc0BHcyg" />Wymarzony przez Rosjan „świat wielobiegunowy” właśnie wybuchł im w twarz. Zamach w Krasnogorsku sygnalizuje, że najprawdopodobniej muszą walczyć na więcej niż jednym froncie.

## Czy panele fotowoltaiczne trzeba myć? Jak często? I ile to kosztuje?
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/9469537,czy-panele-fotowoltaiczne-trzeba-myc-jak-czesto-i-ile-to-kosztuje.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/9469537,czy-panele-fotowoltaiczne-trzeba-myc-jak-czesto-i-ile-to-kosztuje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T08:00:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aVRktkuTURBXy8zMGM1N2ViMy1hNmJkLTQ3ZWItODI1NC1mNDVmNTQ4MjM3MTIuanBlZ5GTBc0BHcyg" />Panele fotowoltaiczne są każdego dnia narażone na kontakt z zanieczyszczeniami. Na ich powierzchni gromadzą się m.in. pyłki roślin, spaliny oraz ptasie odchody. Niestety prowadzi to do obniżenia wydajności modułów i to nawet o 20 proc. Warto zatem zadbać o czystość instalacji, jeśli zależy nam na jej efektywnym działaniu. W jaki sposób należy o nią dbać?

## Zmasowany atak bombowy na Ukrainie. Pod ostrzałem zachodnia część kraju
 - [https://forsal.pl/swiat/ukraina/artykuly/9469996,zmasowany-atak-bombowy-na-ukrainie-pod-ostrzalem-zachodnia-czesc-kraj.html](https://forsal.pl/swiat/ukraina/artykuly/9469996,zmasowany-atak-bombowy-na-ukrainie-pod-ostrzalem-zachodnia-czesc-kraj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T07:39:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/L7_ktkuTURBXy8wMTg1NzcxMy02M2JmLTRkMTItOTQxYy0zODM3M2JmNTc5NzIuanBlZ5GTBc0BHcyg" />Mer Lwowa Andrij Sadowy poinformował w niedzielę nad ranem, że Rosjanie zaatakowali obwód lwowski za pomocą 20 rakiet i 7 dronów szturmowych. W Kijowie obrona powietrzna zestrzeliła około 10 rakiet manewrujących.

## Reuters: Państwo Islamskie opublikowało materiał filmowy z ataku w Krasnogorsku
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9469993,reuters-panstwo-islamskie-opublikowalo-material-filmowy-z-ataku-w-kra.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9469993,reuters-panstwo-islamskie-opublikowalo-material-filmowy-z-ataku-w-kra.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T07:26:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MlvktkuTURBXy9jZGYxMTM4ZS03YjFhLTQ0MTAtOTQ0NC0xYmYwNjMyMTMxZmQuanBlZ5GTBc0BHcyg" />Państwo Islamskie (IS) opublikowało w sobotę na swoim kanale w Telegramie materiał filmowy z ataku na salę koncertową w Krasnogorsku pod Moskwą - podała agencja Reuters.

## Wybory prezydenckie na Słowacji. Są wstępne wyniki
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9469992,wybory-prezydenckie-na-slowacji-sa-wstepne-wyniki.html](https://forsal.pl/swiat/aktualnosci/artykuly/9469992,wybory-prezydenckie-na-slowacji-sa-wstepne-wyniki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T07:25:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ugaktkuTURBXy85NDc3OTA4OS1iMjAzLTRjNTQtODBlZi1lYTE3NTI0YTdiMjguanBlZ5GTBc0BHcyg" />Po przeliczeniu głosów z ponad 80 proc. komisji wyborczych w słowackich wyborach prezydenckich wiadomo, że za dwa tygodnie, 6 kwietnia br., odbędzie się druga tura głosowania. Spotkają się w niej przewodniczący parlamentu, były premier Peter Pellegrini oraz były dyplomata i były minister spraw zagranicznych Ivan Korczok.

## "FP": Niestabilny Trump będzie miał pod kontrolą "guzik nuklearny". Trzeba to zmienić
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9469990,fp-niestabilny-trump-bedzie-mial-pod-kontrola-guzik-nuklearny-tr.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9469990,fp-niestabilny-trump-bedzie-mial-pod-kontrola-guzik-nuklearny-tr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T07:21:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vBUktktTURBXy84YjYxMDg2Yy02NDdiLTQ5YTEtOWFhYi05ZDM5YWM0NDJkNDIucG5nkZMFzQEdzKA" />Donald Trump niemal na pewno zostanie kandydatem Republikanów w amerykańskich wyborach; jeśli je wygra, to niestabilny prezydent będzie miał nieograniczone proceduralnie prawo do przyciśnięcia &quot;guzika nuklearnego&quot;. Pora to ograniczyć - pisze w &quot;Foreign Policy&quot; ekspert ośrodka FAS ds. doktryny obronnej.

## Rosyjska rakieta w polskiej przestrzeni powietrznej. Jest reakcja MON i BBN
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9469989,rosyjska-rakieta-w-polskiej-przestrzeni-powietrznej-jest-reakcja-mon.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9469989,rosyjska-rakieta-w-polskiej-przestrzeni-powietrznej-jest-reakcja-mon.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T07:16:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/952ktkuTURBXy9kNjM0NWE0Yi0xZDQyLTRmNWMtYjQ2NS05MTQ4YTZkM2IwZDMuanBlZ5GTBc0BHcyg" />Doszło do naruszenia polskiej przestrzeni powietrznej przez jedną z rakiet manewrujących wystrzelonych w nocy przez rosyjskie lotnictwo - poinformowało w niedzielę rano Dowództwo Operacyjne Rodzajów Sił Zbrojnych. Szef BBN Jacek Siewiera rozmawiał ws. incydentu z ministrem obrony Władysławem Kosiniakiem-Kamyszem.

## Jak wypłacić pieniądze z PPK? Polacy coraz częściej to robią. Ile się na tym traci?
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9469268,jak-wyplacic-pieniadze-z-ppk-polacy-coraz-czesciej-to-robia-ile-sie.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9469268,jak-wyplacic-pieniadze-z-ppk-polacy-coraz-czesciej-to-robia-ile-sie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T07:00:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PJwktkuTURBXy82ZjQ4NGY1Yy0yNmVlLTQ3YzEtYWQ2Ni00MmZhNDIyYmI1YTQuanBlZ5GTBc0BHcyg" />PPK, czyli Pracownicze Plany Kapitałowe, pozwalają pracownikom na gromadzenie - przy współudziale pracodawcy i państwa - oszczędności. Z założenia mają one być wypłacane każdej osobie po ukończeniu przez nią 60. roku życia. W praktyce wypłaty z PPK możliwe są wcześniej. Kiedy można wypłacić z PPK środki zgromadzone na indywidualnym koncie? W jaki sposób należy to zrobić? Czy jest potrzebny wniosek do wypłaty z PPK?

## Mistrzowie wymazywania. Co wydarzyło się 4 marca 2020 r.?
 - [https://forsal.pl/kraj/artykuly/9468254,mistrzowie-wymazywania-co-wydarzylo-sie-4-marca-2020-r.html](https://forsal.pl/kraj/artykuly/9468254,mistrzowie-wymazywania-co-wydarzylo-sie-4-marca-2020-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T07:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yiwktkuTURBXy9iNjJkOWM5Yi1mNDRjLTRiZmQtOTNjOC1kOWJiZDdiNzE0YTYuanBlZ5GTBc0BHcyg" />Nie było żadnego symbolicznego upamiętnienia ofiar pandemii. Nie mamy nawet języka, by o nich mówić. A bez tego trudno przeżywać żałobę.

## Rynek pracy. Jak poczucie tożsamości wpływa na wybory?
 - [https://forsal.pl/praca/kariera/artykuly/9468309,rynek-pracy-jak-poczucie-tozsamosci-wplywa-na-wybory.html](https://forsal.pl/praca/kariera/artykuly/9468309,rynek-pracy-jak-poczucie-tozsamosci-wplywa-na-wybory.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T07:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/595ktkuTURBXy9jMTQ5MjQzNS0yM2VhLTQ4OTUtYTlkNC0zMzk2ZTA3ZjZlOTguanBlZ5GTBc0BHcyg" />Czy identyfikowanie się z daną grupą społeczną determinuje typ zajęcia, jakie chcemy wykonywać?

## Co dalej z inflacją? Ekspert BGK: Stopy pod koniec roku będą redukowane
 - [https://forsal.pl/gospodarka/artykuly/9469956,co-dalej-z-inflacja-ekspert-bgk-stopy-pod-koniec-roku-beda-redukowan.html](https://forsal.pl/gospodarka/artykuly/9469956,co-dalej-z-inflacja-ekspert-bgk-stopy-pod-koniec-roku-beda-redukowan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T06:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/D_NktkuTURBXy9hNjc1YTdkNi05NWUwLTQyMGQtYWRlMy0zMmQwZGZkOTIyZWYuanBlZ5GTBc0BHcyg" />Procesy cenowe w naszej gospodarce są przede wszystkim zależne od czynników zewnętrznych. Dlatego obawy dotyczące silnego zakotwiczenia inflacji powyżej celu w ostatnich kwartałach wydawały mi się mocno nieuzasadnione – mówi Piotr Dmitrowski, dyrektor biura analiz makroekonomicznych i rynków finansowych Banku Gospodarstwa Krajowego

## Czy NATO "ochroni nas w razie wojny z Rosją"?
 - [https://forsal.pl/kraj/bezpieczenstwo/artykuly/9468317,czy-nato-ochroni-nas-w-razie-wojny-z-rosja.html](https://forsal.pl/kraj/bezpieczenstwo/artykuly/9468317,czy-nato-ochroni-nas-w-razie-wojny-z-rosja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T06:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ma3ktkuTURBXy9mYzlhMGE1ZC0yNzhmLTRhYzYtOTJiOS0yZDNiMzgwMzZiN2IuanBlZ5GTBc0BHcyg" />Oglądam w „Super Expressie” wyniki sondażu: 54 proc. odpowiada „tak” na pytanie, czy NATO „ochroni nas w razie wojny z Rosją”; 30 proc. odpowiada „nie”. Pojęcia nie mam, co sam bym odpowiedział. Analogie historyczne zawodzą, a wróżenie, co by było, gdyby było, ma sens taki sobie.

## Dlaczego Ukraińcy walczyli z Rosją w Sudanie?
 - [https://forsal.pl/swiat/ukraina/artykuly/9469507,dlaczego-ukraincy-walczyli-z-rosja-w-sudanie.html](https://forsal.pl/swiat/ukraina/artykuly/9469507,dlaczego-ukraincy-walczyli-z-rosja-w-sudanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T06:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/iAfktkuTURBXy9jOTYwM2FjMC04MmFiLTQ5ZjQtYjc4OS0wMWQzMGEzNTU4YmYuanBlZ5GTBc0BHcyg" />Wiadomość jest elektryzująca, nawet jeśli w ogólnym rozrachunku skutki domniemanej ukraińskiej eskapady do Afryki będą pomijalne.

## Napięcia na Indo-Pacyfiku. Gdzie tykają bomby?
 - [https://forsal.pl/swiat/artykuly/9468293,napiecia-na-indo-pacyfiku-gdzie-tykaja-bomby.html](https://forsal.pl/swiat/artykuly/9468293,napiecia-na-indo-pacyfiku-gdzie-tykaja-bomby.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T06:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HfwktkuTURBXy9kYjU3ZWRhNy1mZmVlLTRjNDEtYjhkYi01ZWQ4YzE4YzhmYWIuanBlZ5GTBc0BHcyg" />Gdy mowa o napięciach na Indo-Pacyfiku, odruchowo myślimy o kwestii tajwańskiej. Ale bomby tykają także gdzie indziej, a jedną z najgroźniejszych w ostatnim czasie jest spór pomiędzy Chińską Republiką Ludową a Filipinami.

## Wybory samorządowe 2024. Kandydaci na prezydenta Krakowa [SYLWETKI]
 - [https://forsal.pl/kraj/polityka/artykuly/9469960,wybory-samorzadowe-2024-kandydaci-na-prezydenta-krakowa-sylwetki.html](https://forsal.pl/kraj/polityka/artykuly/9469960,wybory-samorzadowe-2024-kandydaci-na-prezydenta-krakowa-sylwetki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T06:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KvqktktTURBXy9hYTE5MjI0ZS0zZjRmLTQ5MDEtOTM5Yy0zYWU5NDQxZjkzOGYucG5nkZMFzQEdzKA" />Wybory samorządowe umożliwiają obywatelom wybór władz, które będą decydować o kierunkach rozwoju ich miejscowości na kolejne pięć lat. Już niedługo obywatele polskich miast znów będą głosować na kandydatów na różne stanowiska - od radnych po prezydentów. Sprawdźmy, kto w tym roku ubiega się o fotel prezydenta Krakowa.

## Nowe wiadomości ws. drugiej waloryzacji emerytur. Jest stanowisko szefowej resortu
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9469251,nowe-wiadomosci-ws-drugiej-waloryzacji-emerytur-jest-stanowisko-szef.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9469251,nowe-wiadomosci-ws-drugiej-waloryzacji-emerytur-jest-stanowisko-szef.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T06:00:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/n6vktkuTURBXy84Mjk1MDlkMC0xYzgzLTQ5ZWEtYWRjYS0wNDliZGVjMTIwMjcuanBlZ5GTBc0BHcyg" />&quot;Na razie wygląda na to, że wzrost inflacji został zatrzymany i być może nie będzie potrzeby interwencyjnej waloryzacji. Natomiast przygotowani powinniśmy być na oba scenariusze&quot; – powiedziała dla Dziennika Gazety Prawnej ministra rodziny, pracy i polityki społecznej Agnieszka Dziemianowicz-Bąk.

## (Nie)potrzebny komisarz? Jakie ma szanse Radosław Sikorski i czy w ogóle warto się nad tym zastanawiać [OPINIA]
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9469787,niepotrzebny-komisarz-jakie-ma-szanse-radoslaw-sikorski-i-czy-w-ogo.html](https://forsal.pl/swiat/unia-europejska/artykuly/9469787,niepotrzebny-komisarz-jakie-ma-szanse-radoslaw-sikorski-i-czy-w-ogo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-03-24T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_YyktkuTURBXy8xZWViNTQ2YS0zNmVjLTQyOGYtODcwNi1hNWZlNmNlYTY4Y2UuanBlZ5GTBc0BHcyg" />Choć obecny szef polskiej dyplomacji Radosław Sikorski uchodzi za głównego kandydata do objęcia fotela komisarza ds. obrony, to kluczowe jest jednak pytanie o sam zakres działań komisarza.

