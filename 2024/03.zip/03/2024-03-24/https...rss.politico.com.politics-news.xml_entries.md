# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en

## Ronna McDaniel on previous RNC positions: ‘You kind of take one for the whole team’
 - [https://www.politico.com/news/2024/03/24/ronna-mcdaniel-on-previous-rnc-positions-you-kind-of-take-one-for-the-whole-team-00148716](https://www.politico.com/news/2024/03/24/ronna-mcdaniel-on-previous-rnc-positions-you-kind-of-take-one-for-the-whole-team-00148716)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-03-24T11:09:11+00:00

McDaniel addressed her decision not speak out against Trump's calls to free those imprisoned for their role in the Jan. 6 attack on the Capitol.

## ‘Our bosses owe you an apology’: Todd slams NBC's McDaniel hire during Welker MTP segment
 - [https://www.politico.com/news/2024/03/24/ronna-mcdaniel-roils-nbc-i-think-our-bosses-owe-you-an-apology-00148719](https://www.politico.com/news/2024/03/24/ronna-mcdaniel-roils-nbc-i-think-our-bosses-owe-you-an-apology-00148719)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-03-24T11:08:49+00:00

The former host of 'Meet The Press' launched his attack on the network during a panel discussion with the current host.

