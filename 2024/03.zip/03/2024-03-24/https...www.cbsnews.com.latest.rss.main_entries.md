# Source:Home - CBSNews.com, URL:https://www.cbsnews.com/latest/rss/main, language:en

## Ohtani to speak to media for first time since gambling allegations against former interpreter
 - [https://www.cbsnews.com/news/ohtani-to-speak-to-media-for-1st-time-since-illegal-gambling-theft-allegations-against-interpreter](https://www.cbsnews.com/news/ohtani-to-speak-to-media-for-1st-time-since-illegal-gambling-theft-allegations-against-interpreter)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T22:06:40+00:00

"It's the right thing to do," said Manager Dave Roberts. "I'm happy he's going to speak and speak to what he knows and give his thoughts on the whole situation. I think it will give us all a little bit more clarity."

## How to see the penumbral lunar eclipse, March's full moon
 - [https://www.cbsnews.com/news/how-to-see-penumbral-lunar-eclipse-march-full-worm-moon](https://www.cbsnews.com/news/how-to-see-penumbral-lunar-eclipse-march-full-worm-moon)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T21:12:00+00:00

As March's full Worm Moon rises late Sunday into early Monday, it will travel through the Earth's penumbra — the faint outer part of its shadow — creating a penumbral eclipse.

## New Jersey first lady Tammy Murphy suspends run for U.S. Senate
 - [https://www.cbsnews.com/news/tammy-murphy-suspends-senate-run-new-jersey-first-lady](https://www.cbsnews.com/news/tammy-murphy-suspends-senate-run-new-jersey-first-lady)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T20:52:46+00:00

New Jersey first lady Tammy Murphy on Sunday suspended her campaign for U.S. Senate.

## Navy identifies U.S. sailor lost overboard in the Red Sea
 - [https://www.cbsnews.com/news/us-navy-sailor-oriola-michael-aregbesola-overboard-red-sea](https://www.cbsnews.com/news/us-navy-sailor-oriola-michael-aregbesola-overboard-red-sea)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T18:35:36+00:00

Aviation Machinist's Mate 2nd Class Oriola Michael Aregbesola, 34, was lost overboard while working in the Red Sea, the Navy said.

## Full transcript of "Face the Nation," March 24, 2024
 - [https://www.cbsnews.com/news/face-the-nation-full-transcript-03-24-2024](https://www.cbsnews.com/news/face-the-nation-full-transcript-03-24-2024)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T18:20:09+00:00

On this "Face the Nation" broadcast, former House Speaker Kevin McCarthy and House Foreign Affairs Committee chair Rep. Michael McCaul join Margaret Brennan.

## 3/24: Face The Nation
 - [https://www.cbsnews.com/video/324-face-the-nation](https://www.cbsnews.com/video/324-face-the-nation)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T18:01:01+00:00

This week on "Face the Nation," Margaret Brennan speaks to House Foreign Affairs Committee chair Rep. Michael McCaul and former counterintelligence official Sam Vinograd as Russia grapples with an attack at a Moscow concert hall that left more than 130 dead. Plus, former House Speaker Kevin McCarthy joins.

## Face The Nation: Warnock, Montoya-Galvez, Vinograd
 - [https://www.cbsnews.com/video/face-the-nation-warnock-montoya-galvez-vinograd](https://www.cbsnews.com/video/face-the-nation-warnock-montoya-galvez-vinograd)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T17:55:28+00:00

Missed the second half of the show? The latest on...Sen. Raphael Warnock tells "Face the Nation" that he believes that "Georgia voters are going to do for Joe Biden what they did for me" and go blue again in 2020, in an exclusive interview with CBS News' Camilo Montoya-Galvez, U.S. Border Patrol chief Jason Owens said the situation at the southern border is a "national security threat", and Samantha Vinograd, a CBS News contributor and former counterterrorism official for the Department of Homeland Security in the Biden and Obama administrations tells "Face the Nation" that when she worked with the agency, they "were concerned about the threat that ISIS-K posed to American interests and to the homeland."

## Border Patrol chief Jason Owens says border situation is a "national security threat"
 - [https://www.cbsnews.com/video/border-patrol-chief-jason-owens-says-border-situation-is-a-national-security-threat](https://www.cbsnews.com/video/border-patrol-chief-jason-owens-says-border-situation-is-a-national-security-threat)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T17:30:00+00:00

In an exclusive interview with CBS News' Camilo Montoya-Galvez, U.S. Border Patrol chief Jason Owens said the situation at the southern border is a "national security threat." "What's keeping me up at night is the 140,000 known got-aways," Owens said.

## Russia observes national day of mourning as concert hall attack death toll climbs
 - [https://www.cbsnews.com/news/russia-concert-hall-attack-national-day-of-mourning-death-toll-rises](https://www.cbsnews.com/news/russia-concert-hall-attack-national-day-of-mourning-death-toll-rises)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T17:10:55+00:00

Family and friends of those missing were still waiting for news of their loved ones two days after attack on the concert hall near Moscow, which also left 150 injured.

## Former House Speaker Kevin McCarthy: "Do not be fearful of a motion to vacate"
 - [https://www.cbsnews.com/news/kevin-mccarthy-motion-to-vacate-mike-johnson-face-the-nation](https://www.cbsnews.com/news/kevin-mccarthy-motion-to-vacate-mike-johnson-face-the-nation)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T16:42:01+00:00

Former House Speaker Kevin McCarthy, who became the first speaker in history to be ousted from his post last year, suggested that a motion to vacate the current speaker is unlikely.

## Former DHS official says U.S. watching ISIS-K for threats "to American interests and homeland"
 - [https://www.cbsnews.com/video/former-dhs-official-says-u-s-watching-isis-k-for-threats-to-american-interests-and-homeland](https://www.cbsnews.com/video/former-dhs-official-says-u-s-watching-isis-k-for-threats-to-american-interests-and-homeland)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T16:37:00+00:00

Samantha Vinograd, a CBS News contributor and former counterterrorism official for the Department of Homeland Security in the Biden and Obama administrations tells "Face the Nation" that when she worked with the agency, they "were concerned about the threat that ISIS-K posed to American interests and to the homeland."

## Sen. Raphael Warnock says "Georgia voters are going to do for Joe Biden what they did for me"
 - [https://www.cbsnews.com/video/sen-raphael-warnock-says-georgia-voters-are-going-to-do-for-joe-biden-what-they-did-for-me](https://www.cbsnews.com/video/sen-raphael-warnock-says-georgia-voters-are-going-to-do-for-joe-biden-what-they-did-for-me)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T16:37:00+00:00

Democratic Sen. Raphael Warnock tells "Face the Nation" that he believes that "Georgia voters are going to do for Joe Biden what they did for me" and go blue again in 2020. "The more Donald Trump talks, the better our fortunes will be," he said about Democrats.

## Transcript: Former House Speaker Kevin McCarthy on "Face the Nation," March 24, 2024
 - [https://www.cbsnews.com/news/kevin-mccarthy-face-the-nation-03-24-2024](https://www.cbsnews.com/news/kevin-mccarthy-face-the-nation-03-24-2024)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T16:36:45+00:00

The following is a transcript of an interview with former House Speaker Kevin McCarthy that aired on March 24, 2024.

## Transcript: House Foreign Affairs Committee chairman Rep. Michael McCaul on "Face the Nation," March 24, 2024
 - [https://www.cbsnews.com/news/michael-mccaul-house-foreign-affairs-committee-chair-face-the-nation-transcript-03-24-2024](https://www.cbsnews.com/news/michael-mccaul-house-foreign-affairs-committee-chair-face-the-nation-transcript-03-24-2024)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T16:24:00+00:00

The following is a transcript of an interview with House Foreign Affairs Committe chairman Rep. Michael McCaul, Republican of Texas, that aired on March 24, 2024.

## Former House Speaker Kevin McCarthy: "Do not be fearful of a motion to vacate"
 - [https://www.cbsnews.com/video/former-house-speaker-kevin-mccarthy-do-not-be-fearful-of-a-motion-to-vacate](https://www.cbsnews.com/video/former-house-speaker-kevin-mccarthy-do-not-be-fearful-of-a-motion-to-vacate)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T16:09:00+00:00

Former House Speaker Kevin McCarthy tells "Face the Nation" that he doesn't believe that the motion to vacate current Speaker Michael Johnson will be successful. Although McCarthy was removed from his post by a similar action, he said "do not be fearful of a motion to vacate."

## Rep. Michael McCaul says Speaker Mike Johnson is in a "difficult spot" regarding Ukraine aid bill
 - [https://www.cbsnews.com/video/rep-michael-mccaul-says-speaker-mike-johnson-is-in-a-difficult-spot-regarding-ukraine-aid-bill](https://www.cbsnews.com/video/rep-michael-mccaul-says-speaker-mike-johnson-is-in-a-difficult-spot-regarding-ukraine-aid-bill)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T16:09:00+00:00

Republican Rep. Michael McCaul, the chair of the House Foreign Affairs Committee, tells "Face the Nation" that House Speaker Mike Johnson is in a "difficult spot" regarding a bill offering aid to Ukraine. Despite the threat of a motion to vacate, McCaul said Johnson "knows how important" it is to offer aid to Ukraine.

## Trump faces Monday deadline to post $464 million bond or face seizure of assets
 - [https://www.cbsnews.com/video/trump-faces-monday-deadline-to-post-464-million-bond-or-face-seizure-of-assets-1](https://www.cbsnews.com/video/trump-faces-monday-deadline-to-post-464-million-bond-or-face-seizure-of-assets-1)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T16:06:00+00:00

Former President Donald Trump faces a Monday deadline to post a $464 million bond or face seizure of his assets. New York Attorney General Letitia James could use a marshal or sheriff to begin freezing Trump's bank accounts and taking Trump's properties, Robert Costa reports.

## Trump faces Monday deadline to post $464 million bond or face seizure of assets
 - [https://www.cbsnews.com/video/trump-faces-monday-deadline-to-post-464-million-bond-or-face-seizure-of-assets](https://www.cbsnews.com/video/trump-faces-monday-deadline-to-post-464-million-bond-or-face-seizure-of-assets)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T16:06:00+00:00

Former President Donald Trump faces a Monday deadline to post a $464 million bond or face seizure of his assets. New York Attorney General Letitia James could use a marshal or sheriff to begin freezing Trump's bank accounts and taking Trump's properties, Robert Costa reports.

## Open: This is "Face the Nation with Margaret Brennan," March 24, 2024
 - [https://www.cbsnews.com/video/open-this-is-face-the-nation-with-margaret-brennan-march-24-2024](https://www.cbsnews.com/video/open-this-is-face-the-nation-with-margaret-brennan-march-24-2024)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T15:41:00+00:00

This week on "Face the Nation," Margaret Brennan speaks to House Foreign Affairs Committee chair Rep. Michael McCaul and former counterintelligence official Sam Vinograd as Russia grapples with an attack at a Moscow concert hall that left more than 130 dead. Plus, former House Speaker Kevin McCarthy joins.

## Russia observing national day of mourning after concert hall attack
 - [https://www.cbsnews.com/video/russia-observing-national-day-of-mourning-after-concert-hall-attack](https://www.cbsnews.com/video/russia-observing-national-day-of-mourning-after-concert-hall-attack)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T15:41:00+00:00

Russia is observing a national day of mourning on Sunday after more than 130 people were killed in a terrorist attack at a concert venue in Moscow, ISIS has claimed responsibility for the attack, but Russian President Vladimir Putin has claimed it was linked to Ukraine — which has been denied by the U.S. and Ukraine. Debora Patta has the latest.

## Here Comes the Sun: Hilary Swank and more
 - [https://www.cbsnews.com/video/here-comes-the-sun-hilary-swank-and-more](https://www.cbsnews.com/video/here-comes-the-sun-hilary-swank-and-more)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T15:31:01+00:00

Actor Hilary Swank sits down with Tracy Smith to discuss her latest film, “Ordinary Angels.” Then, Conor Knighton travels to New Orleans to meet portraitist Michael Deas and to learn about his paintings found on stamps, Time magazine covers and more. “Here Comes the Sun” is a closer look at some of the people, places and things we bring you every week on “CBS Sunday Morning.”

## U.S. Border Patrol chief calls southern border a "national security threat"
 - [https://www.cbsnews.com/news/jason-owens-border-patrol-southern-border-national-security-threat](https://www.cbsnews.com/news/jason-owens-border-patrol-southern-border-national-security-threat)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T15:17:00+00:00

For the third consecutive year, Border Patrol is on track to record two million apprehensions at the U.S. southern border.

## Princess Kate "extremely moved" by public response to her cancer diagnosis
 - [https://www.cbsnews.com/news/princess-kate-prince-william-extremely-moved-response-cancer-diagnosis-palace-says](https://www.cbsnews.com/news/princess-kate-prince-william-extremely-moved-response-cancer-diagnosis-palace-says)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T15:04:34+00:00

Princess Kate and her husband also said they "are grateful for the understanding of their request for privacy at this time."

## Nature: Birds of Costa Rica
 - [https://www.cbsnews.com/video/nature-birds-of-costa-rica](https://www.cbsnews.com/video/nature-birds-of-costa-rica)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T14:30:00+00:00

"Sunday Morning" takes us among the colorful birds in the jungle near San Jose, Costa Rica. Videographer: Judith Lehmberg.

## Fareed Zakaria decries the "anti-Americanism" in America's politics today
 - [https://www.cbsnews.com/news/fareed-zakaria-on-age-of-revolutions-anti-americanism-in-politics](https://www.cbsnews.com/news/fareed-zakaria-on-age-of-revolutions-anti-americanism-in-politics)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T14:21:37+00:00

The host of CNN's "GPS" is an optimist who is nonetheless concerned about what he sees in response to a changing America. His new book, "Age of Revolutions," discusses how societies both embrace change and resist it.

## Fareed Zakaria on "Age of Revolutions"
 - [https://www.cbsnews.com/video/fareed-zakaria-on-age-of-revolutions](https://www.cbsnews.com/video/fareed-zakaria-on-age-of-revolutions)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T14:20:00+00:00

As host of CNN's "GPS," Fareed Zakaria dives into global issues with scholars, presidents, and the occasional celebrity. An optimist, Zakaria is nonetheless concerned about what he characterizes as a darkness in America brought on by people "who feel that they are not benefiting from all the changes in society." He talks with "Sunday Morning" contributor Kelefa Sanneh about his new book, "Age of Revolutions," in which he writes about how societies both embrace change and resist it.

## Steve Martin: Comic, banjo player, and now documentary film subject
 - [https://www.cbsnews.com/news/steve-martin-a-documentary-in-two-pieces](https://www.cbsnews.com/news/steve-martin-a-documentary-in-two-pieces)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T14:08:28+00:00

The 78-year-old comedian known for being wild and crazy is now the subject of a documentary on Apple TV+, titled "STEVE! (martin) a documentary in 2 pieces."

## Steve Martin gets the documentary film treatment
 - [https://www.cbsnews.com/video/steve-martin-gets-the-documentary-film-treatment](https://www.cbsnews.com/video/steve-martin-gets-the-documentary-film-treatment)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T14:07:00+00:00

The comedian known for being wild and crazy is now the subject of a documentary on Apple TV+, titled "STEVE! (martin) a documentary in 2 pieces." Correspondent Tracy Smith talks with Steve Martin, and with filmmaker and longtime fan Morgan Neville, about telling the 78-year-old legend's life story, from his comedy records and "SNL," to walking away from standup, to playing a mean banjo.

## Writer Percival Everett: "In ownership of language there resides great power"
 - [https://www.cbsnews.com/news/writer-percival-everett-on-his-novel-james-race-and-language](https://www.cbsnews.com/news/writer-percival-everett-on-his-novel-james-race-and-language)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T14:00:39+00:00

In his latest book, "James," the author who tackled race in such satirical novels as "Erasure" (basis of the Oscar-winning "American Fiction") re-tells the story of "Huckleberry Finn" from the point of view of Huck's enslaved friend, Jim.

## "James" author Percival Everett on race, language and art
 - [https://www.cbsnews.com/video/james-author-percival-everett-on-race-language-and-art](https://www.cbsnews.com/video/james-author-percival-everett-on-race-language-and-art)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:58:00+00:00

Author Percival Everett has challenged the schism of race in such satirical novels as "Erasure" (basis of the Oscar-winning film "American Fiction"). His latest, "James," re-tells the story of "Huckleberry Finn" from the point of view of Huck's enslaved friend, Jim, for whom language becomes a shield, and an avenue toward freedom. Everett talks with correspondent Martha Teichner about his writing, his artwork, and his penchant for privacy.

## The long struggle to free Evan Gershkovich from a Moscow prison
 - [https://www.cbsnews.com/news/the-long-struggle-to-free-evan-gershkovich-from-a-moscow-prison](https://www.cbsnews.com/news/the-long-struggle-to-free-evan-gershkovich-from-a-moscow-prison)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:49:47+00:00

Last March 29, the Wall Street Journal reporter was on assignment in Russia when he was arrested by security forces and accused of being a spy, a charge vigorously denied by Gershkovich, the paper, and the U.S. government.

## Evan Gershkovich's first year in captivity in a Moscow prison
 - [https://www.cbsnews.com/video/evan-gershkovichs-first-year-in-captivity-in-a-moscow-prison](https://www.cbsnews.com/video/evan-gershkovichs-first-year-in-captivity-in-a-moscow-prison)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:47:00+00:00

Last March 29, Wall Street Journal reporter Evan Gershkovich was on assignment in Russia when he was arrested by security forces and accused of being a spy, a charge vigorously denied by Gershkovich, the paper, and the U.S. government. "60 Minutes" correspondent Lesley Stahl talks with Gershkovich's sister, Danielle; with Wall Street Journal editor-in-chief Emma Tucker; and U.S. Special Envoy for Hostage Affairs Roger Carstens about the ongoing negotiations to bring Gershkovich home. Stahl also talks with longtime Kremlin critic Gary Kasparov about how Russian President Vladimir Putin is using prisoners as pawns on his geopolitical chessboard against the West.

## Passage: In memoriam
 - [https://www.cbsnews.com/video/passage-in-memoriam-3-24-2024](https://www.cbsnews.com/video/passage-in-memoriam-3-24-2024)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:43:00+00:00

"Sunday Morning" remembers some of the notable figures who left us this week, including character actor M. Emmet Walsh, best known for his roles in the Coen Brothers' "Blood Simple" and the sci-fi classic "Blade Runner."

## Doris Kearns Goodwin's personal history in "An Unfinished Love Story"
 - [https://www.cbsnews.com/news/historian-doris-kearns-goodwin-an-unfinished-love-story](https://www.cbsnews.com/news/historian-doris-kearns-goodwin-an-unfinished-love-story)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:37:07+00:00

The Pulitzer Prize-winner talks about her latest book devoted to her late husband, Richard Goodwin, a speechwriter for JFK, LBJ and RFK, and about how history and politics shaped their lives together.

## Doris Kearns Goodwin on "An Unfinished Love Story"
 - [https://www.cbsnews.com/video/doris-kearns-goodwin-on-an-unfinished-love-story](https://www.cbsnews.com/video/doris-kearns-goodwin-on-an-unfinished-love-story)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:35:00+00:00

Pulitzer Prize-winning historian Doris Kearns Goodwin's latest book is devoted to her late husband, Richard Goodwin, whose speeches for Presidents John F. Kennedy and Lyndon B. Johnson and Senator Robert F. Kennedy produced some of the most memorable phrases of the era. She talks about her upcoming book, "An Unfinished Love Story: A Personal History of the 1960s," with CBS News chief election and campaign correspondent Robert Costa, and about how history and politics shaped their lives together. Goodwin also explains why she believes people who choose to tune out from participating in this year's critical presidential election are "cowardly."

## PR expert on what lessons royals have learned from Kate's cancer news
 - [https://www.cbsnews.com/video/pr-expert-on-what-lessons-royals-have-learned-from-kates-cancer-news](https://www.cbsnews.com/video/pr-expert-on-what-lessons-royals-have-learned-from-kates-cancer-news)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:32:00+00:00

After months of speculation about her condition, Princess Kate, wife of the heir to the British throne, announced Friday that she has cancer. Correspondent Holly Williams talks with Julian Payne, a former spokesman for the King and Queen, about what lessons the royal family may have learned after Kate's withdrawal from the public for medical reasons led to rumors and dizzying conspiracy theories.

## Death toll rises in Russia terror attack
 - [https://www.cbsnews.com/video/death-toll-rises-in-russia-terror-attack](https://www.cbsnews.com/video/death-toll-rises-in-russia-terror-attack)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:28:00+00:00

In the aftermath of Friday's terrorist attack at a concert venue outside Moscow (when armed men in combat fatigues opened fire and then set the place ablaze), the death toll has now climbed to more than 130. Although ISIS claimed responsibility, Russian President Vladimir Putin has pointed a finger at Ukraine, a charge Ukraine flatly denies. CBS News foreign correspondent Debora Patta reports.

## Christian Cooper, the "Extraordinary Birder"
 - [https://www.cbsnews.com/video/christian-cooper-the-extraordinary-birder](https://www.cbsnews.com/video/christian-cooper-the-extraordinary-birder)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:22:00+00:00

Christian Cooper made national news in May 2020 when, while birdwatching in New York's Central Park, a white woman called 911 to report that an "African American man was threatening her life" after he'd asked her to put her dog on a leash. His recording of their interaction went viral, just as the country was rocked by the George Floyd murder. Since then, he has hosted a National Geographic Wild series, "Extraordinary Birder with Christian Cooper," and written a memoir about growing up a closeted gay teenager on Long Island, titled "Better Living Through Birding: Notes from a Black Man in the Natural World." Nancy Giles reports.

## Transcript: Sen. Raphael Warnock on "Face the Nation," March 24, 2024
 - [https://www.cbsnews.com/news/raphael-warnock-face-the-nation-03-24-2024](https://www.cbsnews.com/news/raphael-warnock-face-the-nation-03-24-2024)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:19:23+00:00

The following is a transcript of an interview with Sen. Raphael Warnock, Democrat of Georgia, that aired on March 24, 2024.

## Almanac: March 24
 - [https://www.cbsnews.com/video/almanac-march-24](https://www.cbsnews.com/video/almanac-march-24)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:18:00+00:00

"Sunday Morning" looks back at historical events on this date.

## Husband of U.S. journalist detained in Russia: "I'm not going to give up"
 - [https://www.cbsnews.com/news/us-journalist-alsu-kurmasheva-detained-in-russia](https://www.cbsnews.com/news/us-journalist-alsu-kurmasheva-detained-in-russia)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:14:00+00:00

Alsu Kurmasheva, an American-Russian journalist, was visiting her mother in Russia when authorities confiscated her passports and jailed her - an act one NGO calls "state-sponsored hostage-taking."

## Detained: The heartbreaking ordeal of journalist Alsu Kurmasheva
 - [https://www.cbsnews.com/video/detained-the-heartbreaking-ordeal-of-journalist-alsu-kurmasheva](https://www.cbsnews.com/video/detained-the-heartbreaking-ordeal-of-journalist-alsu-kurmasheva)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T13:09:00+00:00

Alsu Kurmasheva, an American-Russian journalist working for Radio Free Europe-Radio Liberty, was visiting her mother in Russia when authorities there confiscated her passports and jailed her. Kurmasheva faces charges that could lead to years of imprisonment because she edited a book of people's opinions about Russia's war with Ukraine. Correspondent Seth Doane talks with Kurmasheva's family and colleagues about the increasing dangers that journalists are facing from governments trying to mask the truth – what Jodie Ginsberg, chief executive officer of the Committee to Protect Journalists, calls "state-sponsored hostage-taking."

## How to watch today's EchoPark Automotive Grand Prix NASCAR race: Livestream options, more
 - [https://www.cbsnews.com/essentials/2024-echopark-automotive-grand-prix-nascar-race-livestream-options](https://www.cbsnews.com/essentials/2024-echopark-automotive-grand-prix-nascar-race-livestream-options)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T08:32:33+00:00

The NASCAR EchoPark Automotive Grand Prix is happening today. Get all the information you need to watch or stream today's race.

## Who Poisoned Angela Craig?
 - [https://www.cbsnews.com/video/who-poisoned-angela-craig](https://www.cbsnews.com/video/who-poisoned-angela-craig)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T07:44:26+00:00

A mother of six becomes deathly ill with unusual symptoms. Investigators suspect she was murdered with a poison protein shake."48 Hours" contributor Natalie Morales reports.

## Did a dentist accused of murder poison his wife's protein shakes?
 - [https://www.cbsnews.com/news/james-craig-colorado-dentist-accused-murder-angela-craig-poison-protein-shakes-48-hours](https://www.cbsnews.com/news/james-craig-colorado-dentist-accused-murder-angela-craig-poison-protein-shakes-48-hours)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T06:12:46+00:00

Angela Craig's autopsy revealed she had been poisoned. Police claim the evidence points to her husband James — alleging he purchased potassium cyanide and arsenic and laced her protein shakes with poison.

## How to watch NASCAR races in 2024: Livestreaming options, schedule, more
 - [https://www.cbsnews.com/essentials/how-to-watch-nascar-races-in-2024](https://www.cbsnews.com/essentials/how-to-watch-nascar-races-in-2024)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T04:00:20+00:00

Find out how to watch the 2024 NASCAR season even if you don't have cable.

## Winning numbers drawn for estimated $750 million Powerball jackpot
 - [https://www.cbsnews.com/news/powerball-winning-numbers-drawn-estimated-750-million-dollar-jackpot](https://www.cbsnews.com/news/powerball-winning-numbers-drawn-estimated-750-million-dollar-jackpot)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T03:04:35+00:00

There has not been a grand prize winner since New Year's Day.

## New footage shows son of YouTube mom Ruby Franke getting help from neighbor after escape
 - [https://www.cbsnews.com/video/new-footage-shows-son-of-youtube-mom-ruby-franke-getting-help-from-neighbor-after-escape](https://www.cbsnews.com/video/new-footage-shows-son-of-youtube-mom-ruby-franke-getting-help-from-neighbor-after-escape)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T02:03:00+00:00

Newly released footage from the Washington County Attorney's Office shows the moment YouTube mom Ruby Franke's 12-year-old son walked up to a neighbor's house to ask for help after escaping his home.

## Search and rescue mission in Delaware County ongoing after child falls into Chester Creek
 - [https://www.cbsnews.com/news/search-and-rescue-mission-ongoing-delaware-county-child-fell-into-chester-creek](https://www.cbsnews.com/news/search-and-rescue-mission-ongoing-delaware-county-child-fell-into-chester-creek)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-03-24T00:40:00+00:00

A search and rescue mission is ongoing in Chester after a 6-year-old Lin'Ajah Brooker fell into Chester Creek, according to the Chester Bureau of Fire.

