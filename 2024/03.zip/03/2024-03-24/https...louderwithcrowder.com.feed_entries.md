# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed, language:en-US

## Watch: LSU coach goes BEAST MODE on WaPo reporter, preemptively calls them out for upcoming hit piece
 - [https://www.louderwithcrowder.com/lsu-kim-mulkey-washington-post](https://www.louderwithcrowder.com/lsu-kim-mulkey-washington-post)
 - RSS feed: https://louderwithcrowder.com/feed
 - date published: 2024-03-24T11:48:48+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=51823900&amp;width=2000&amp;height=1500&amp;coordinates=0%2C0%2C320%2C0" /><br /><br /><p>Spoiler: College Basketball is a topic I'm unfamiliar with. Mayhaps LSU Women's Coach Kim Mulkey is a giant jerkface. Albeit, a giant jerkface who knows how to win because her LSU Tigers are the defending NCAA champions. But what I lack in hoops knowledge I make up for in knowing how journalismers are failures as people and suck at life. I'm all-in on Mulkey going beast mode on a Washington Post journalismer who, apparently, is planning to drop a hit piece.</p><p>Mulkey preemptively went on the attack and called out the sh*tty excuse for journalisming. Apparently, WaPo has been working on a story for two years. They called LSU with a list of questions two days before the team was leaving the NCAA Tournament that needed to be answered on the day they got on the bus.</p><p>Here's Coach with more.</p><div class="rm-embed

