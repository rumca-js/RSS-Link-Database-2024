# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Joni Mitchell’s Spotify protest ends as her music is added back to the streaming platform
 - [https://www.foxnews.com/media/joni-mitchells-spotify-protest-ends-her-music-added-back-streaming-platform](https://www.foxnews.com/media/joni-mitchells-spotify-protest-ends-her-music-added-back-streaming-platform)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T23:00:56+00:00

Joni Mitchell is back on Spotify after a two-year protest from the platform over alleged &apos;misinformation&apos; on the Joe Rogan Podcast regarding COVID-19.

## Trevor Bauer throws three scoreless innings against Yankees in latest outing
 - [https://www.foxnews.com/sports/trevor-bauer-throws-3-scoreless-innings-against-yankees-latest-outing](https://www.foxnews.com/sports/trevor-bauer-throws-3-scoreless-innings-against-yankees-latest-outing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T22:52:17+00:00

Trevor Bauer was back on the mound again, this time facing big leaguers as he threw three scoreless innings against the New York Yankees in Mexico City.

## New Jersey's first lady Tammy Murphy suspends Senate campaign for Bob Menendez's seat
 - [https://www.foxnews.com/politics/new-jerseys-first-lady-tammy-murphy-suspends-senate-campaign-bob-menendezs-seat](https://www.foxnews.com/politics/new-jerseys-first-lady-tammy-murphy-suspends-senate-campaign-bob-menendezs-seat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T22:45:28+00:00

Tammy Murphy suspended her bid for U.S. Senate on Sunday. Her campaign was criticized for allegedly being nepotistic, considering her position as wife of Governor Phil Murphy.

## LSU star Angel Reese waves goodbye to Middle Tennessee State player who fouled out
 - [https://www.foxnews.com/sports/lsu-star-angel-reese-waves-goodbye-middle-tennessee-state-player-fouled-out](https://www.foxnews.com/sports/lsu-star-angel-reese-waves-goodbye-middle-tennessee-state-player-fouled-out)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T22:39:24+00:00

LSU Tigers star Angel Reese waved goodbye to a Middle Tennessee State player who fouled out of their NCAA Women&apos;s Basketball Tournament game on Sunday.

## Fani Willis says she’s the only DA in US with enough ‘courage’ to prosecute Trump
 - [https://www.foxnews.com/politics/fani-willis-says-shes-only-da-us-enough-courage-prosecute-trump](https://www.foxnews.com/politics/fani-willis-says-shes-only-da-us-enough-courage-prosecute-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T22:37:44+00:00

Fani Willis told reporters Saturday she is the only DA in the country with enough &quot;courage&quot; to prosecute former President Donald Trump in the Georgia election interference case.

## Border Patrol chief says not knowing who enters the US illegally, or why, adds up to a ‘national threat’
 - [https://www.foxnews.com/media/border-patrol-chief-says-knowing-enters-us-illegally-adds-national-threat](https://www.foxnews.com/media/border-patrol-chief-says-knowing-enters-us-illegally-adds-national-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T22:36:23+00:00

Border Patrol Chief Jason Owens said not knowing who was entering the country illegally and why, among other things, adds up to a national security threat.

## Harris' 'shameful' warning for Israel crashes and burns online: 'Kick rocks, Kamala'
 - [https://www.foxnews.com/media/harris-shameful-warning-israel-crashes-burns-online-kick-rocks-kamala](https://www.foxnews.com/media/harris-shameful-warning-israel-crashes-burns-online-kick-rocks-kamala)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T22:00:46+00:00

Vice President Kamala Harris’ comments on Sunday regarding Israel’s imminent invasion of Rafah in Gaza were attacked as ignorant and shameful on social media.

## Priscilla Presley recalls Elvis’ ‘vulgar’ first impression on her: ‘'Boy, who was this guy?’
 - [https://www.foxnews.com/entertainment/priscilla-presley-recalls-elvis-vulgar-first-impression-on-her-boy-who-was-this-guy](https://www.foxnews.com/entertainment/priscilla-presley-recalls-elvis-vulgar-first-impression-on-her-boy-who-was-this-guy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T21:52:47+00:00

Priscilla Presley shared new details about her and Evlis&apos; relationship at an event, including his affairs and her &quot;vulgar&quot; and &quot;disgusted&quot; first impression of him.

## X pledges $300K to pay legal fees for Canadian doctor who bucked COVID vaccination mandates
 - [https://www.foxnews.com/us/x-pledges-pay-legal-fees-canadian-doctor-bucked-covid-vaccination-mandates](https://www.foxnews.com/us/x-pledges-pay-legal-fees-canadian-doctor-bucked-covid-vaccination-mandates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T21:35:17+00:00

A Canadian doctor who specializes in immunology was ordered by the courts to pay $300,000. She was given assistance by X, which offered to cover the bill in support of free speech.

## Marquette coach Shaka Smart gets emotional after team edges out Colorado to reach Sweet 16
 - [https://www.foxnews.com/sports/marquette-coach-shaka-smart-gets-emotional-team-edges-out-colorado-reach-sweet-16](https://www.foxnews.com/sports/marquette-coach-shaka-smart-gets-emotional-team-edges-out-colorado-reach-sweet-16)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T21:28:58+00:00

For Marquette head coach Shaka Smart, reaching the Sweet 16 again has been a battle of adversity, one that got him emotional after his Golden Eagles beat Colorado to get there.

## UFC fighter receives massive bonus after getting bitten during bout
 - [https://www.foxnews.com/sports/ufc-fighter-receives-massive-bonus-getting-bit-bout](https://www.foxnews.com/sports/ufc-fighter-receives-massive-bonus-getting-bit-bout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T21:10:39+00:00

Andre Lima &quot;felt the pain,&quot; but UFC CEO Dana White is rewarding him for the unfortunate incident of getting bitten during his fight in Las Vegas Saturday night.

## ABC host can't believe Rubio would serve as Trump's VP if asked: 'Really?'
 - [https://www.foxnews.com/media/abc-host-cant-believe-rubio-would-serve-trumps-vp-asked-really](https://www.foxnews.com/media/abc-host-cant-believe-rubio-would-serve-trumps-vp-asked-really)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T21:00:27+00:00

ABC News&apos; Jonathan Karl questioned Sen. Marco Rubio&apos;s indication that he would be &quot;honored&quot; to serve as Trump&apos;s VP, and bluntly asked, &quot;really?&quot;

## NCAA wrestling champs wear '100% Jesus' headbands at event
 - [https://www.foxnews.com/sports/ncaa-wrestling-champs-wear-100-jesus-headbands-event](https://www.foxnews.com/sports/ncaa-wrestling-champs-wear-100-jesus-headbands-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T20:58:49+00:00

Penn State&apos;s Aaron Brooks and Iowa State&apos;s David Carr showed their support for Jesus Christ on Saturday as they won national championships.

## 'Yellowstone' star 'kicked off' flight for allegedly refusing to sit next to passenger wearing a mask
 - [https://www.foxnews.com/entertainment/yellowstone-star-kicked-off-flight-allegedly-refusing-sit-next-passenger-wearing-mask](https://www.foxnews.com/entertainment/yellowstone-star-kicked-off-flight-allegedly-refusing-sit-next-passenger-wearing-mask)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T20:57:47+00:00

Forrie J. Smith claimed an airline kicked him off a flight after he said he &quot;didn&apos;t feel comfortable&quot; sitting next to someone wearing a mask&quot; on the plane.

## Woman rejects 'worst name ever' for her child, pleads with others for a 'sanity' check
 - [https://www.foxnews.com/lifestyle/woman-rejects-worst-name-child-pleads-sanity](https://www.foxnews.com/lifestyle/woman-rejects-worst-name-child-pleads-sanity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T20:43:11+00:00

On Reddit, a mom-to-be shared the dilemma she and her husband are facing as they can&apos;t agree on what to name their new baby daughter. Others on the platform weighed in.

## Chileans arrested in California suburb days after LAPD forms task force to counter transnational crime ring
 - [https://www.foxnews.com/us/chileans-arrested-california-suburb-days-lapd-forms-task-force-counter-transnational-crime-ring](https://www.foxnews.com/us/chileans-arrested-california-suburb-days-lapd-forms-task-force-counter-transnational-crime-ring)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T20:09:18+00:00

Irvine police arrested on Friday arrested three men just days after the LAPD formed a task force to address an international crime ring targeting luxury homes in the U.S.

## Wyoming governor cites constitutional concerns after signing school choice bill, narrows eligibility for funds
 - [https://www.foxnews.com/media/wyoming-governor-constitutional-concerns-signing-school-choice-bill-narrows-eligibility](https://www.foxnews.com/media/wyoming-governor-constitutional-concerns-signing-school-choice-bill-narrows-eligibility)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T20:00:29+00:00

Wyoming Gov. Mark Gordon signed a school choice bill into law on Thursday and cited constitutionality concerns when he vetoed most of the eligibility provisions in the measure.

## Tim Tebow collaborates with Sentinel Foundation to rescue 59 children with disabilities from Haiti
 - [https://www.foxnews.com/world/tim-tebow-collaborates-sentinel-foundation-rescue-59-children-disabilities-haiti](https://www.foxnews.com/world/tim-tebow-collaborates-sentinel-foundation-rescue-59-children-disabilities-haiti)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T19:56:32+00:00

The operation rescued 59 children with disabilities from Haiti, moving them through Jamaica with help from Rep. Cory Mills, who has already staged two rescue operations in Haiti.

## All Senate Dems vote against barring taxpayer funds to fly illegal migrants to US towns
 - [https://www.foxnews.com/politics/all-senate-dems-vote-against-barring-taxpayer-funds-fly-illegal-migrants-us-towns](https://www.foxnews.com/politics/all-senate-dems-vote-against-barring-taxpayer-funds-fly-illegal-migrants-us-towns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T19:47:16+00:00

Every Democratic senator voted against an amendment that would ban the use of taxpayer funds to transport illegal immigrants to the U.S., Sen. Hagerty says.

## Mark Wahlberg admits he always falls asleep during a certain bedtime routine with wife
 - [https://www.foxnews.com/entertainment/mark-wahlberg-admits-always-falls-asleep-certain-bedtime-routine-wife](https://www.foxnews.com/entertainment/mark-wahlberg-admits-always-falls-asleep-certain-bedtime-routine-wife)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T19:43:04+00:00

Mark Wahlberg is sharing how and why watching television with his wife Rhea Durham ahead of bed always makes him fall asleep.

## Shohei Ohtani's ex-interpreter's past comes into question as Red Sox, university refute connection: reports
 - [https://www.foxnews.com/sports/shohei-ohtanis-ex-interpreters-past-comes-question-red-sox-university-refute-connection-reports](https://www.foxnews.com/sports/shohei-ohtanis-ex-interpreters-past-comes-question-red-sox-university-refute-connection-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T19:31:00+00:00

Mystery continues to swirl around Ippei Mizuhara, the ex-interpreter for Los Angeles Dodgers superstar Shohei Ohtani, after allegations he stole millions from the ballplayer.

## Former Justice Breyer throws cold water on theory Dobbs leak came from a justice: 'I'd be amazed'
 - [https://www.foxnews.com/politics/former-justice-breyer-throws-cold-water-theory-dobbs-leak-came-justice-id-amazed](https://www.foxnews.com/politics/former-justice-breyer-throws-cold-water-theory-dobbs-leak-came-justice-id-amazed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T19:30:49+00:00

Retired Supreme Court Justice Stephen Breyer said he&apos;d be &quot;amazed&quot; if the Dobbs decision leak in 2022 came from a fellow SCOTUS justice, according to a new interview.

## NCAA ref pulled from women's tournament game at halftime over 'background conflict'
 - [https://www.foxnews.com/sports/ncaa-ref-pulled-womens-tournament-game-halftime-background-conflict](https://www.foxnews.com/sports/ncaa-ref-pulled-womens-tournament-game-halftime-background-conflict)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T19:11:43+00:00

NCAA referee Tommi Paris was pulled from calling an NCAA Women&apos;s Tournament game between Chattanooga and NC State over a &quot;background conflict.&quot;

## Former ‘Price is Right’ Producer shares protocol for contestants so excited they ‘pee their pants’
 - [https://www.foxnews.com/entertainment/former-price-is-right-producer-shares-protocol-contestants-so-excited-they-pee-their-pants](https://www.foxnews.com/entertainment/former-price-is-right-producer-shares-protocol-contestants-so-excited-they-pee-their-pants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T19:03:38+00:00

Former &quot;The Price is Right&quot; producer Mike Richards revealed that the game show as a plan in place if a contestant gets so excited to play they need the bathroom.

## Cancer and Princess Kate: What type of diagnosis did Kate Middleton receive?
 - [https://www.foxnews.com/health/cancer-princess-kate-what-type-diagnosis-did-kate-middleton-get](https://www.foxnews.com/health/cancer-princess-kate-what-type-diagnosis-did-kate-middleton-get)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T19:00:56+00:00

Doctors who have vast experience in diagnosing and treating cancer are surmising about the type of cancer Prince Kate Middleton may have — and offered theories based on their medical expertise.

## Iowa's Caitlin Clark makes bold statement after early tournament victory
 - [https://www.foxnews.com/sports/iowas-caitlin-clark-makes-bold-statement-early-tournament-victory](https://www.foxnews.com/sports/iowas-caitlin-clark-makes-bold-statement-early-tournament-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T18:44:55+00:00

Iowa Hawkeyes star Caitlin Clark believes the NCAA Women&apos;s Basketball Tournament is more popular than the men&apos;s this year and made the claim after Saturday&apos;s win.

## AOC doubles down on claims Israel carrying out ‘genocide’ with ‘mass famine’ in Gaza: ‘Crossed the threshold'
 - [https://www.foxnews.com/politics/aoc-doubles-down-claims-israel-carrying-genocide-mass-famine-gaza-crossed-threshold](https://www.foxnews.com/politics/aoc-doubles-down-claims-israel-carrying-genocide-mass-famine-gaza-crossed-threshold)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T18:25:19+00:00

Rep. Alexandria Ocasio-Cortez, D-N.Y., accused Israel of carrying out a &quot;genocide&quot; in Gaza against one million &quot;innocent&quot; Palestinians amid the Jewish state&apos;s war against Hamas.

## ‘Showgirls’ star Elizabeth Berkley thanks fans for years of support: ‘You always believed’
 - [https://www.foxnews.com/entertainment/showgirls-star-elizabeth-berkley-thanks-fans-years-support-you-always-believed](https://www.foxnews.com/entertainment/showgirls-star-elizabeth-berkley-thanks-fans-years-support-you-always-believed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T18:24:53+00:00

&quot;Showgirls&quot; star Elizabeth Berkley thanked fans for their years of support at a recent screening of the film, discussing its impact on her life and how she&apos;s fully embraced it.

## Harris suggests 'consequences' are on the table for Israel if Netanyahu invades Rafah
 - [https://www.foxnews.com/politics/harris-suggests-consequences-table-israel-netanyahu-invades-rafah](https://www.foxnews.com/politics/harris-suggests-consequences-table-israel-netanyahu-invades-rafah)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T18:08:38+00:00

Vice President Kamala Harris suggested &quot;consequences&quot; may be on the table for Israel if Prime Minister Benjamin Netanyahu moves forward with an invasion of Rafah.

## Georgia star running back Trevor Etienne arrested on multiple misdemeanors
 - [https://www.foxnews.com/sports/georgia-star-running-back-trevor-etienne-arrested-multiple-misdemeanors](https://www.foxnews.com/sports/georgia-star-running-back-trevor-etienne-arrested-multiple-misdemeanors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T18:01:04+00:00

Top Georgia Bulldogs transfer Trevor Etienne was charged with multiple misdemeanors following a DUI arrest on Sunday morning and was booked into an Athens jail.

## 'Fox News Sunday' on March 24, 2024
 - [https://www.foxnews.com/transcript/fox-news-sunday-march-24-2024](https://www.foxnews.com/transcript/fox-news-sunday-march-24-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T17:55:55+00:00

This week, Shannon Bream welcomes Sen. Tim Kaine, D-Va., Sen. Tom Cotton, R-Ark., and more to discuss the week’s top political headlines.

## Kate Middleton 'wrote every word' of emotional cancer announcement, friend says: report
 - [https://www.foxnews.com/entertainment/kate-middleton-wrote-every-word-emotional-cancer-announcement-friend-says-report](https://www.foxnews.com/entertainment/kate-middleton-wrote-every-word-emotional-cancer-announcement-friend-says-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T17:52:10+00:00

Kate Middleton&apos;s purported close friend told The Sunday Times why the princess chose to leave a video message to announce her cancer diagnosis and that she &quot;wrote every word&quot; of the speech.

## Tennis star Aryna Sabalenka smashes racket as emotional week comes to unfortunate end
 - [https://www.foxnews.com/sports/tennis-star-aryna-sabalenka-smashes-racket-emotional-week-comes-unfortunate-end](https://www.foxnews.com/sports/tennis-star-aryna-sabalenka-smashes-racket-emotional-week-comes-unfortunate-end)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T17:45:02+00:00

Belarusian tennis star Aryna Sabalenka smashed her racket in frustration as she lost in straight sets to Anhelina Kalinina on Saturday at the Miami Open.

## Ronna McDaniel clashes with NBC News host in heated interview: 'Do you owe this country an apology?'
 - [https://www.foxnews.com/media/ronna-mcdaniel-clashes-nbc-news-host-heated-interview-owe-country-apology](https://www.foxnews.com/media/ronna-mcdaniel-clashes-nbc-news-host-heated-interview-owe-country-apology)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T17:42:10+00:00

NBC News host Kristen Welker and RNC Chair Ronna McDaniel clashed in a heated interview on &quot;Meet the Press&quot; following NBC&apos;s hiring of McDaniel as a political analyst.

## Following Schumer and Biden comments on Jewish state, locals have a message: 'Stay out of Israeli politics'
 - [https://www.foxnews.com/world/following-schumer-biden-comments-jewish-state-locals-have-message-stay-out-of-israeli-politics](https://www.foxnews.com/world/following-schumer-biden-comments-jewish-state-locals-have-message-stay-out-of-israeli-politics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T17:35:35+00:00

Some Israelis in Jerusalem told Fox News Digital that Schumer should stay out of their politics; feel that the Biden administration is turning on them due to internal political considerations.

## Zelenskyy responds to Moscow concert hall shooting, rips Putin for suggesting Ukraine behind terror attack
 - [https://www.foxnews.com/world/zelenskyy-responds-moscow-concert-hall-shooting-rips-putin-suggesting-ukraine-behind-terror-attack](https://www.foxnews.com/world/zelenskyy-responds-moscow-concert-hall-shooting-rips-putin-suggesting-ukraine-behind-terror-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T17:10:09+00:00

Ukrainian President Volodymyr Zelenskyy deemed Russian President Vladimir Putin and his lieutenants &quot;scum&quot; for trying to link Kyiv to the suburban Moscow terror attack.

## Hungarian rally car crash leaves multiple dead, several others injured
 - [https://www.foxnews.com/sports/hungarian-rally-car-crash-leaves-multiple-dead-several-others-injured](https://www.foxnews.com/sports/hungarian-rally-car-crash-leaves-multiple-dead-several-others-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T16:48:48+00:00

At least four people were killed and a handful of others were injured in a rally car race in Hungary on Sunday afternoon, police said. An investigation was launched.

## Rep. Greene on filing motion against Speaker Mike Johnson: 'I'm not bringing chaos, I'm forcing change'
 - [https://www.foxnews.com/media/marjorie-taylor-greene-filing-motion-speaker-mike-johnson-chaos-forcing-change](https://www.foxnews.com/media/marjorie-taylor-greene-filing-motion-speaker-mike-johnson-chaos-forcing-change)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T16:18:45+00:00

Rep. Marjorie Taylor Greene, R-Ga., blasted House Speaker Mike Johnson, R-La., for backing a massive federal funding package while defending the motion she filed to vacate his position.

## 'Charlie and the Chocolate Factory,' 'Matilda' and other Roald Dahl books that were made into popular movies
 - [https://www.foxnews.com/entertainment/roald-dahl-books-movies](https://www.foxnews.com/entertainment/roald-dahl-books-movies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T15:57:36+00:00

Roald Dahl&apos;s books are the inspiration behind many hit movies. &quot;Charlie and the Chocolate Factory,&quot; &quot;Matilda&quot; and &quot;The BFG&quot; and others have translated to the big screen.

## Rubio warns ISIS-K could exploit US southern border following deadly Moscow attack
 - [https://www.foxnews.com/politics/rubio-warns-isis-k-could-exploit-us-southern-border-following-deadly-moscow-attack](https://www.foxnews.com/politics/rubio-warns-isis-k-could-exploit-us-southern-border-following-deadly-moscow-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T15:56:32+00:00

Sen. Marco Rubio, R-Fla., warned that Americans should be concerned about ISIS-K terrorists potentially trying to exploit the U.S. southern border.

## Kate Middleton's treatment by media leaves journalist teary-eyed during live broadcast: 'So angry right now'
 - [https://www.foxnews.com/media/kate-middleton-treatment-media-journalist-tears-live-broadcast-angry](https://www.foxnews.com/media/kate-middleton-treatment-media-journalist-tears-live-broadcast-angry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T15:51:57+00:00

A royal commentator broke down in tears during a live segment as she discussed breaking news of Princess Kate&apos;s cancer diagnosis and the media speculation beforehand.

## Kamala Harris rejects Putin linking Moscow concert attack to Ukraine, says ISIS 'by all accounts responsible'
 - [https://www.foxnews.com/politics/kamala-harris-rejects-putin-linking-moscow-concert-attack-ukraine-says-isis-accounts-responsible](https://www.foxnews.com/politics/kamala-harris-rejects-putin-linking-moscow-concert-attack-ukraine-says-isis-accounts-responsible)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T15:48:48+00:00

Vice President Kamala Harris insisted ISIS bears full responsibility for a shooting attack at a suburban Moscow concert hall, rejecting Russian Vladimir Putin&apos;s mention of Ukraine.

## Attack in Moscow a 'very dangerous echo' of Biden's botched Afghanistan withdrawal: Sen. Cotton
 - [https://www.foxnews.com/politics/cotton-attack-moscow-very-dangerous-echo-bidens-botched-afghanistan-withdrawal-sen-cotton](https://www.foxnews.com/politics/cotton-attack-moscow-very-dangerous-echo-bidens-botched-afghanistan-withdrawal-sen-cotton)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T15:30:03+00:00

Sen. Tom Cotton said the attack on Russia at a concert venue that left more than 130 people dead is a &quot;dangerous echo of President Biden&apos;s failed withdrawal from Afghanistan.&quot;

## NBC's Chuck Todd explodes on network bosses on the air for hiring Ronna McDaniel as analyst, calls for apology
 - [https://www.foxnews.com/media/nbcs-chuck-todd-explodes-network-bosses-air-hiring-ronna-mcdaniel-analyst-calls-apology](https://www.foxnews.com/media/nbcs-chuck-todd-explodes-network-bosses-air-hiring-ronna-mcdaniel-analyst-calls-apology)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T15:26:40+00:00

Former &quot;Meet The Press&quot; host Chuck Todd blasted NBC News bosses on the air Sunday for the hiring of ex-RNC chair Ronna McDaniel as an analyst.

## Jewish holiday of Purim may have echoes in American history, says New York rabbi
 - [https://www.foxnews.com/lifestyle/jewish-holiday-purim-echoes-american-history-new-york-rabbi](https://www.foxnews.com/lifestyle/jewish-holiday-purim-echoes-american-history-new-york-rabbi)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T15:21:56+00:00

Rabbi Dr. Ari Lamm reflects on the story of Purim as told in the Book of Esther, and how its message may have motivated President Abraham Lincoln.

## Former Disney star 'never regretted' getting breast implants as a teen after being encouraged by mom
 - [https://www.foxnews.com/entertainment/former-disney-star-never-regretted-getting-breast-implants-teen-encouraged-mom](https://www.foxnews.com/entertainment/former-disney-star-never-regretted-getting-breast-implants-teen-encouraged-mom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T15:13:02+00:00

Former Disney Channel star Christy Carlson Romano, whose mother encouraged her to get breast implants as a teen, says she doesn&apos;t regret having the surgery. She also thanked her mom for the support.

## Hero teen saves over 100 people in deadly Moscow terror attack: video
 - [https://www.foxnews.com/world/hero-teen-saves-100-people-deadly-moscow-terror-attack-video](https://www.foxnews.com/world/hero-teen-saves-100-people-deadly-moscow-terror-attack-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T14:35:58+00:00

A young Russian boy is credited with saving over 100 lives as he led people away from the massacre at a Moscow concert hall on Friday.

## UFC bout stopped after fighter bites opponent: 'I felt the pain'
 - [https://www.foxnews.com/sports/ufc-bout-stopped-fighter-bites-opponent-felt-pain](https://www.foxnews.com/sports/ufc-bout-stopped-fighter-bites-opponent-felt-pain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T14:33:45+00:00

A flyweight bout between Igor Severino and Andre Lima had to be stopped after Severino bit Lima in the second round of the fight on Saturday night.

## F1 star Max Verstappen's car spews black smoke, catches fire in bad day at Australian Grand Prix
 - [https://www.foxnews.com/sports/f1-star-max-verstappens-car-spews-black-smoke-catches-fire-bad-day-australian-grand-prix](https://www.foxnews.com/sports/f1-star-max-verstappens-car-spews-black-smoke-catches-fire-bad-day-australian-grand-prix)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T13:57:04+00:00

Formula One star Max Verstappen had a tough day at the Australian Grand Prix on Sunday as he only made it about three laps before his vehicle started to smoke.

## The Grits Belt is an unmarked but undeniable demarcation of American culinary cultures
 - [https://www.foxnews.com/lifestyle/grits-belt-unmarked-undeniable-demarcation-american-culinary-cultures](https://www.foxnews.com/lifestyle/grits-belt-unmarked-undeniable-demarcation-american-culinary-cultures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T13:52:09+00:00

The Grits Belt is an undefined but undeniable cultural demarcation seperating two Americas, one in which the main starch is potatoes and another in which it is grits. Here&apos;s why.

## Anti-Trump GOP Alaska Senator doesn't shoot down notion of becoming independent
 - [https://www.foxnews.com/media/anti-trump-gop-alaska-senator-doesnt-shoot-down-notion-becoming-independent](https://www.foxnews.com/media/anti-trump-gop-alaska-senator-doesnt-shoot-down-notion-becoming-independent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T13:48:25+00:00

Sen. Lisa Murkowski did not rule out changing her party affiliation during an interview with CNN, and said she regretted the GOP becoming the party of Trump.

## Russian missile enters Polish airspace as Moscow lashes out at Ukraine after ISIS attack
 - [https://www.foxnews.com/world/russian-missile-enters-polish-airspace-moscow-lashes-ukraine-isis-attack](https://www.foxnews.com/world/russian-missile-enters-polish-airspace-moscow-lashes-ukraine-isis-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T13:30:40+00:00

Poland scrambled its air defenses Sunday after a Russian missile entered its airspace on its way toward Ukraine.

## Pennsylvania inmate who escaped prison nearly 4 months ago captured leaving Philadelphia Planet Fitness
 - [https://www.foxnews.com/us/pennsylvania-inmate-escaped-prison-nearly-4-months-ago-captured-leaving-philadelphia-planet-fitness](https://www.foxnews.com/us/pennsylvania-inmate-escaped-prison-nearly-4-months-ago-captured-leaving-philadelphia-planet-fitness)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T13:21:57+00:00

Isaiah Tilghman, 33, was captured Friday outside a Plant Fitness in Philadelphia after escaping from the Blair County Prison on Dec. 3.

## Kamala Harris claps to Puerto Rico protest song, stops once aide translates what they're actually singing
 - [https://www.foxnews.com/politics/kamala-harris-claps-puerto-rico-protest-song-stops-once-aide-translates-actually-singing](https://www.foxnews.com/politics/kamala-harris-claps-puerto-rico-protest-song-stops-once-aide-translates-actually-singing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T13:04:54+00:00

Kamala Harris suddenly stopped clapping to a Puerto Rican band once a San Juan community center staffer told her they were criticizing the vice president about Palestine and Haiti.

## NBC News hiring of ex-RNC chair Ronna McDaniel as analyst sets off liberal uproar: 'Appalling'
 - [https://www.foxnews.com/media/nbc-news-hiring-ex-rnc-chair-ronna-mcdaniel-analyst-sets-liberal-uproar-appalling](https://www.foxnews.com/media/nbc-news-hiring-ex-rnc-chair-ronna-mcdaniel-analyst-sets-liberal-uproar-appalling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T13:04:26+00:00

Amid fierce liberal backlash, former RNC chair Ronna McDaniel won&apos;t appear on the progressive channel MSNBC despite NBC News hiring her as an analyst.

## Holy Week leads the faithful to Easter Sunday: Here are the special days observed and what they mean
 - [https://www.foxnews.com/lifestyle/holy-week-leads-faithful-easter-sunday-special-days-observed-what-they-mean](https://www.foxnews.com/lifestyle/holy-week-leads-faithful-easter-sunday-special-days-observed-what-they-mean)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T12:54:41+00:00

Holy Week leading up to Easter is regarded as the most spiritually significant week of the year in Christianity, containing many traditions and rituals. Here&apos;s what to know.

## Veteran British left-wing disruptor George Galloway slammed for Princess Kate conspiracy theories
 - [https://www.foxnews.com/politics/veteran-british-left-wing-disruptor-george-galloway-slammed-princess-kate-conspiracy-theories](https://www.foxnews.com/politics/veteran-british-left-wing-disruptor-george-galloway-slammed-princess-kate-conspiracy-theories)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T11:55:42+00:00

Veteran British political disruptor George Galloway has come under fire by fellow members of Parliament for his conspiracy theories regarding the Princess of Wales.

## Mountain lion attack kills 21-year-old man, injures younger brother in California
 - [https://www.foxnews.com/us/mountain-lion-attack-kills-21-year-old-man-injures-younger-brother-california](https://www.foxnews.com/us/mountain-lion-attack-kills-21-year-old-man-injures-younger-brother-california)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T11:26:01+00:00

A 21-year-old man was killed and his 18-year-old brother was injured when a mountain lion attacked them in a remote area in El Dorado County, California.

## RFK Jr.'s pending vice presidential pick could bring major cash influx, boost to third-party bid: report
 - [https://www.foxnews.com/politics/rfk-jr-s-pending-vice-presidential-pick-could-bring-major-cash-influx-boost-third-party-bid-report](https://www.foxnews.com/politics/rfk-jr-s-pending-vice-presidential-pick-could-bring-major-cash-influx-boost-third-party-bid-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T11:23:35+00:00

Robert F. Kennedy Jr.&apos;s expected announcement of a vice presidential pick will likely bring a boost in donations and support to his campaign Democrats initially counted out.

## AMERICAN VALUES: Do they still hold strong? This town questions their future
 - [https://www.foxnews.com/media/american-values-hold-strong-town-questions-future](https://www.foxnews.com/media/american-values-hold-strong-town-questions-future)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T10:30:19+00:00

Residents in the small town of Noel, Missouri, explain what they think of when they hear “American Values&quot; and what has happened to those commonly held values over time.

## Sleep disorders and suicide: A mental health expert reveals the concerning link
 - [https://www.foxnews.com/health/sleep-disorders-suicide-mental-health-expert-reveals-link](https://www.foxnews.com/health/sleep-disorders-suicide-mental-health-expert-reveals-link)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T10:00:40+00:00

Taft Parsons III, M.D., vice president and chief psychiatric officer at CVS Health in Birmingham, Michigan, discussed the concerning link between chronic sleep issues and suicide.

## Easter bunny teaches kids 'true meaning' of Easter in new book with faith focus
 - [https://www.foxnews.com/lifestyle/easter-bunny-teaches-kids-true-meaning-easter-book-faith-focus](https://www.foxnews.com/lifestyle/easter-bunny-teaches-kids-true-meaning-easter-book-faith-focus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T09:30:29+00:00

&quot;The Story of the First Easter Bunny,&quot; a new book by New Jersey author Anthony DeStefano, works to claim the Easter Bunny as a Christian symbol and teach kids the real meaning of Easter.

## Two Texas boys, ages 7 and 12, taken into custody in connection with woman stabbed: Sheriff
 - [https://www.foxnews.com/us/two-texas-boys-ages-7-12-taken-custody-connection-woman-stabbed-sheriff](https://www.foxnews.com/us/two-texas-boys-ages-7-12-taken-custody-connection-woman-stabbed-sheriff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T09:26:27+00:00

Two Texas boys, ages seven and 12, were detained in connection with a stabbing Saturday afternoon that left a woman hospitalized in critical condition.

## Florida woman arrested for allegedly kidnapping neighbor's 2-year-old, refusing to return child to parent
 - [https://www.foxnews.com/us/florida-woman-arrested-allegedly-kidnapping-neighbors-2-year-old-refusing-return-child-parent](https://www.foxnews.com/us/florida-woman-arrested-allegedly-kidnapping-neighbors-2-year-old-refusing-return-child-parent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T08:45:03+00:00

A Florida woman is facing charges after allegedly kidnapping her neighbor&apos;s child, locking herself and the child inside her apartment and refusing to return the child.

## Jenny McCarthy says husband Donnie Wahlberg 'still gives me butterflies' with weekly romantic gesture
 - [https://www.foxnews.com/entertainment/jenny-mccarthy-says-husband-donnie-wahlberg-still-gives-me-butterflies-with-romantic-weekly-gesture](https://www.foxnews.com/entertainment/jenny-mccarthy-says-husband-donnie-wahlberg-still-gives-me-butterflies-with-romantic-weekly-gesture)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T07:51:24+00:00

Jenny McCarthy shared how her husband Donnie Wahlberg &quot;treats me like a queen&quot; ahead of their 10th anniversary. McCarthy shared that Wahlberg sends her flowers every week.

## Virginia mother killed, body found in trash truck: police
 - [https://www.foxnews.com/us/virginia-mother-killed-body-found-trash-truck-police](https://www.foxnews.com/us/virginia-mother-killed-body-found-trash-truck-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T04:13:42+00:00

Police in Virginia said that a 30-year-old mother was found dead in a trash truck after authorities began searching for her when she failed to pick up her child from daycare.

## Celtics' Jrue Holiday says he's dealing with 'dead arm,' no timetable for return
 - [https://www.foxnews.com/sports/celtics-jrue-holiday-says-hes-dealing-with-dead-arm-no-timetable-for-return](https://www.foxnews.com/sports/celtics-jrue-holiday-says-hes-dealing-with-dead-arm-no-timetable-for-return)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T03:23:38+00:00

The Celtics will likely secure the top seed in the Eastern Conference. Boston’s comfortable lead over the Bucks means the team doesn&apos;t have to rush Jrue Holiday back to action.

## FAU's Dusty May set to become Michigan head coach after March Madness elimination: report
 - [https://www.foxnews.com/sports/faus-dusty-may-michigan-head-coach-march-madness-elimination](https://www.foxnews.com/sports/faus-dusty-may-michigan-head-coach-march-madness-elimination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T03:04:31+00:00

After six seasons at Florida Atlantic University, Dusty May is reportedly becoming the next head coach of Michigan

## Washington pastor reveals words of hope, faith and strength for Kate Middleton: 'God is with you'
 - [https://www.foxnews.com/lifestyle/washington-pastor-words-hope-faith-strength-kate-middleton-god-you](https://www.foxnews.com/lifestyle/washington-pastor-words-hope-faith-strength-kate-middleton-god-you)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T02:29:16+00:00

One day after Princess Kate Middleton announced she&apos;s battling cancer, Pastor Jesse Bradley of Washington shared prayers, faith and words of hope for her and all those who are struggling.

## Kate Middleton, Prince William 'enormously touched' by 'kind messages' from the public after cancer diagnosis
 - [https://www.foxnews.com/entertainment/kate-middleton-prince-william-enormously-touched-by-kind-messages-from-public-after-cancer-diagnosis](https://www.foxnews.com/entertainment/kate-middleton-prince-william-enormously-touched-by-kind-messages-from-public-after-cancer-diagnosis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T02:20:49+00:00

Kate Middleton and husband Prince William are &quot;enormously touched&quot; by the &quot;kind messages&quot; of support they have received since the Princess of Wales revealed her cancer diagnosis.

## US warning to Americans about imminent attack in Moscow proves prophetic 2 weeks later
 - [https://www.foxnews.com/world/us-warning-americans-imminent-attack-moscow-proves-prophetic-2-weeks-later](https://www.foxnews.com/world/us-warning-americans-imminent-attack-moscow-proves-prophetic-2-weeks-later)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T02:20:46+00:00

Two weeks after the U.S. State Department issued a warning there were &quot;imminent&quot; plans for an extremist attack near Moscow, Russia, a concert hall was targeted by ISIS.

## No. 11 N.C. State advances to Sweet 16 with overtime victory, continuing improbable March run
 - [https://www.foxnews.com/sports/no-11-nc-state-advances-sweet-16-overtime-victory-continuing-improbable-march-run](https://www.foxnews.com/sports/no-11-nc-state-advances-sweet-16-overtime-victory-continuing-improbable-march-run)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T02:04:16+00:00

The North Carolina State Wolfpack have played seven games in the last 12 days, have won all seven and are off to the Sweet 16, 41 years after winning a national title.

## Influential pollster says NY AG seizing Trump's property would 'elect' him
 - [https://www.foxnews.com/politics/influential-pollster-says-ny-ag-seizing-trumps-property-would-elect-him](https://www.foxnews.com/politics/influential-pollster-says-ny-ag-seizing-trumps-property-would-elect-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T01:49:59+00:00

Pollster Frank Luntz recently hypothesized that New York Attorney General Letitia James would seal Trump&apos;s fate as the next U.S. president if she began seizing his assets.

## Michigan teacher fired after parent exposes her creative side hustle
 - [https://www.foxnews.com/us/michigan-teacher-fired-parent-exposes-creative-side-hustle](https://www.foxnews.com/us/michigan-teacher-fired-parent-exposes-creative-side-hustle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T01:43:47+00:00

A Detroit-area high school teacher says she was fired from her job because she works as a rapper on the side and a parent complained she was a bad influence.

## Texas secessionist says shocking footage of migrants surging border 'moved the needle' for 'TEXIT' support
 - [https://www.foxnews.com/us/texas-secessionist-says-shocking-footage-migrants-surging-border-moved-needle-texit-support](https://www.foxnews.com/us/texas-secessionist-says-shocking-footage-migrants-surging-border-moved-needle-texit-support)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T01:38:11+00:00

A leading Texas secessionist said that continued border crisis and recent video footage of migrants rushing across the southern border has &apos;moved the needle&apos; for support in the TEXIT movement.

## LA County Sheriff’s Department's organized retail theft crime task force conducts major fencing bust
 - [https://www.foxnews.com/us/la-county-sheriffs-departments-organized-retail-theft-crime-task-force-conducts-major-fencing-bust](https://www.foxnews.com/us/la-county-sheriffs-departments-organized-retail-theft-crime-task-force-conducts-major-fencing-bust)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T01:34:37+00:00

Fox News embedded with the Los Angeles Sheriff during a a bust in a crime-ridden neighborhood in the city of Angels, recovering $500,000 worth of merchandise.

## Caitlin Clark bounces back from sluggish start; Iowa cruises to first-round NCAA Tournament victory
 - [https://www.foxnews.com/sports/caitlin-clark-bounces-back-from-sluggish-start-as-iowa-cruises-to-ncaa-tournament-first-round-victory](https://www.foxnews.com/sports/caitlin-clark-bounces-back-from-sluggish-start-as-iowa-cruises-to-ncaa-tournament-first-round-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T01:13:38+00:00

The Iowa women&apos;s basketball team shook off some rust after a nearly two-week layoff between the Big Ten tournament title game and first round of the NCAA tournament.

## Biden campaign rips page from Trump playbook with name-calling strategy
 - [https://www.foxnews.com/politics/biden-campaign-rips-page-trump-playbook-name-calling-strategy](https://www.foxnews.com/politics/biden-campaign-rips-page-trump-playbook-name-calling-strategy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T00:37:50+00:00

The Biden campaign sent out an email entitled &quot;Broke Don Hides in Basement,&quot; last week, jeering at the former president&apos;s financial woes and taking a page from his playbook.

## Fani Willis doubles down after Nathan Wade scandal, warns 'train is coming'
 - [https://www.foxnews.com/politics/fani-willis-doubles-down-nathan-wade-scandal-warns-train-coming](https://www.foxnews.com/politics/fani-willis-doubles-down-nathan-wade-scandal-warns-train-coming)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T00:28:40+00:00

Fulton County District Attorney Fani Willis said her team hasn&apos;t been slowed down by accusations of impropriety in her case against former President Trump, adding she did nothing illegal.

## No. 1 UNC pulls away late from ninth-seeded Michigan State to make Sweet 16
 - [https://www.foxnews.com/sports/no-1-unc-pulls-away-late-ninth-seeded-michigan-state-make-sweet-16](https://www.foxnews.com/sports/no-1-unc-pulls-away-late-ninth-seeded-michigan-state-make-sweet-16)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-03-24T00:23:50+00:00

North Carolina is now 7-0 against Michigan State in March Madness history after its victory in the second round of the tournament Saturday.

