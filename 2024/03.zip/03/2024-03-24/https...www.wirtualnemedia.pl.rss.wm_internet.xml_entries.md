# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Kanał Zero ma już milion subskrybentów
 - [https://www.wirtualnemedia.pl/artykul/kanal-zero-milion-subskrypcji-krzysztof-stanowski](https://www.wirtualnemedia.pl/artykul/kanal-zero-milion-subskrypcji-krzysztof-stanowski)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-24T21:32:37.137135+00:00

Kanał Zero, założony przez dziennikarza Krzysztofa Stanowskiego, przekroczył w niedzielę wieczorem milion subskrypcji. Stanowski poinformował o tym w trakcie wywiadu z Rafałem Ziemkiewiczem. Projekt oficjalnie wystartował w lutym.

## Znany serwis streamingowy uruchamia kolejne darmowe kanały telewizyjne
 - [https://www.wirtualnemedia.pl/artykul/darmowe-kanaly-tv-online-rakuten-streaming-jak-ogladac](https://www.wirtualnemedia.pl/artykul/darmowe-kanaly-tv-online-rakuten-streaming-jak-ogladac)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-24T08:33:15.098169+00:00

Serwis streamingowy Rakuten TV zawarł porozumienie z A+E Networks EMEA w sprawie uruchomienia w Europie nowego pakietu z bezpłatnymi kanałami FAST na swojej platformie.

## Kanał Zero traci widzów. Spadki wyświetleń niemal o połowę
 - [https://www.wirtualnemedia.pl/artykul/kanal-zero-krzysztof-stanowski-youtube-porazka](https://www.wirtualnemedia.pl/artykul/kanal-zero-krzysztof-stanowski-youtube-porazka)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-24T08:33:15.081701+00:00

Kanał Zero zanotował ostatnio spadek w zakresie wyświetleń tygodniowych. Projekt Krzysztofa Stanowskiego zbliża się do miliona subskrypcji na YouTube.

