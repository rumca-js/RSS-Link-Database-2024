# Source:Grimdark Magazine, URL:https://www.grimdarkmagazine.com/feed, language:en-AU

## REVIEW: Dreams of Fire by Shauna Lawless
 - [https://www.grimdarkmagazine.com/review-dreams-of-fire-by-shauna-lawless](https://www.grimdarkmagazine.com/review-dreams-of-fire-by-shauna-lawless)
 - RSS feed: https://www.grimdarkmagazine.com/feed
 - date published: 2024-03-24T04:25:47+00:00

<p>Shauna Lawless already sits pretty high on my auto-buy author list based on her first two novels, The Children of Gods and Fighting Men and The Words of Kings and Prophets. So I was extremely excited to learn that Lawless was returning to her Middle Ages Irish historical fantasy Gael Song series with her novella Dreams of Fire. Let me tell you: I pressed that pre-order link as soon as it appeared on my newsfeed. I love Shauna Lawlewss’ writing and I love novellas. It was going to make a great reading day. And it did. Even if you have yet to read the other novels in the Gael Song series, you can start with Dreams of Fire as a bit of an amuse-bouche and enjoy it with no other knowledge. The events in Dreams of Fire take place about a century before the first novel, so it is the perfect introduction if you are still unsure if this series will be for you. If, like me, you have read and loved the other novels, this novella allows you to see these beloved characters from a diffe

