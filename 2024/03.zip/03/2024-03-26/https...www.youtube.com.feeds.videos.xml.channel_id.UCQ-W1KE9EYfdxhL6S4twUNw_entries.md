# Source:The Cherno, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQ-W1KE9EYfdxhL6S4twUNw, language:en

## Worst Implicit Casting in C++
 - [https://www.youtube.com/watch?v=hVjvo_cXHrU](https://www.youtube.com/watch?v=hVjvo_cXHrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCQ-W1KE9EYfdxhL6S4twUNw
 - date published: 2024-03-26T10:00:37+00:00

Live Stream ► https://twitch.tv/thecherno
Patreon ► https://patreon.com/thecherno
Instagram ► https://instagram.com/thecherno
Twitter ► https://twitter.com/thecherno
Discord ► https://discord.gg/thecherno

Hazel ► https://hazelengine.com
🕹️ Play our latest game FREE (made in Hazel!) ► https://studiocherno.itch.io/dichotomy

🌏 Need web hosting? ► https://hostinger.com/cherno

💰 Links to stuff I use:
⌨ Keyboard ► https://geni.us/T2J7
🐭 Mouse ► https://geni.us/BuY7
💻 Monitors ► https://geni.us/wZFSwSK

#Hazel #GameEngine #Cpp #Shorts

