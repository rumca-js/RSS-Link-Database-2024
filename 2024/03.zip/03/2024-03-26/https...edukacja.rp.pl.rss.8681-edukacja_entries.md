# Source:RP - Edukacja, URL:https://edukacja.rp.pl/rss/8681-edukacja, language:pl-PL

## Warto uczyć się chemii. Bez niej nie byłoby smartfonów
 - [https://edukacja.rp.pl/uczelnie-wyzsze/art40056751-warto-uczyc-sie-chemii-bez-niej-nie-byloby-smartfonow](https://edukacja.rp.pl/uczelnie-wyzsze/art40056751-warto-uczyc-sie-chemii-bez-niej-nie-byloby-smartfonow)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-03-26T14:00:00+00:00

Im więcej uczniowie będą mieli kontaktu z rzetelnym przedstawieniem nauk przyrodniczymi, tym lepiej dla gospodarki i społeczeństwa – przekonuje prof. dr hab. Wojciech Macyk, dziekan Wydziału Chemii UJ, i zachęca do udziału w próbnej maturze z chemii.

## Rektorzy o swoich uczelniach
 - [https://edukacja.rp.pl/uczelnie-wyzsze/art40063391-rektorzy-o-swoich-uczelniach](https://edukacja.rp.pl/uczelnie-wyzsze/art40063391-rektorzy-o-swoich-uczelniach)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-03-26T13:00:00+00:00

Choć do października jeszcze daleko, to już wyższe uczelnie powoli przygotowują się do nowego roku akademickiego.

