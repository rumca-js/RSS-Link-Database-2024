# Source:It's FOSS News, URL:https://news.itsfoss.com/rss, language:en-US

## Fedora 40 Features: I like the subtle changes!
 - [https://news.itsfoss.com/fedora-40](https://news.itsfoss.com/fedora-40)
 - RSS feed: https://news.itsfoss.com/rss
 - date published: 2024-03-26T13:08:53+00:00

What can you expect with Fedora 40? Here's everything you need to know.

