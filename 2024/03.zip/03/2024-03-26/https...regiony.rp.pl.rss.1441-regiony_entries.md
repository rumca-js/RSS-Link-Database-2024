# Source:RP - Regiony, URL:https://regiony.rp.pl/rss/1441-regiony, language:pl-PL

## NIK: rząd PiS ręcznie sterował finansami JST. "Nieudolne reformy i klientelizm"
 - [https://regiony.rp.pl/finanse-w-regionach/art40062351-nik-rzad-pis-recznie-sterowal-finansami-jst-nieudolne-reformy-i-klientelizm](https://regiony.rp.pl/finanse-w-regionach/art40062351-nik-rzad-pis-recznie-sterowal-finansami-jst-nieudolne-reformy-i-klientelizm)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-03-26T13:04:02+00:00

NIK zarzuca poprzedniemu rządowi dyskryminację dużych miast przy podziale pieniędzy i uzależnienie samorządów od władzy centralnej. Izba uważa, że konieczne jest stworzenie nowego systemu samorządowych dochodów.

