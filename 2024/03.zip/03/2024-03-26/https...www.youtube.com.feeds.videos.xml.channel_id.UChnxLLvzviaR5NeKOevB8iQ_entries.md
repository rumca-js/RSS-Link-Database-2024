# Source:Red Means Recording, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ, language:en-US

## Sound Design on the Yamaha Montage
 - [https://www.youtube.com/watch?v=uH7e9wumYWg](https://www.youtube.com/watch?v=uH7e9wumYWg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2024-03-26T21:51:35+00:00

Let me show you what I've learned about this beastly sound design tool.
Grab your own Montage here: https://www.zzounds.com/a--3970449/item--YAMMONTAGEM6

Support the channel on Patreon: http://bit.ly/rmrpatreon
Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

## what's your favorite rompler? #synth #synthesizer #rompler #vgm
 - [https://www.youtube.com/watch?v=4W9he_2T8iQ](https://www.youtube.com/watch?v=4W9he_2T8iQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChnxLLvzviaR5NeKOevB8iQ
 - date published: 2024-03-26T19:08:44+00:00

Support the channel on Patreon: http://bit.ly/rmrpatreon
Take a lesson with me: https://rmr.media/education

Find my music here: 
Bandcamp: http://bit.ly/2Kq617o
Spotify: https://spoti.fi/2N40SoX
YouTube Music: https://bit.ly/3PZQ4ol
iTunes: https://apple.co/2pqh3SK
Amazon Music: https://amzn.to/2O9q1fe

Connect:
Twitter: http://bit.ly/rmrtwitters
Website: http://bit.ly/rmrmedia

