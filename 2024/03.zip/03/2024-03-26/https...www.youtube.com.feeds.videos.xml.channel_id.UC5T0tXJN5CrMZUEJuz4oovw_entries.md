# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## The Hollywood Great Depression | Diddy Do It? - The Real BBC with MauLer and HeelvsBabyface
 - [https://www.youtube.com/watch?v=hYEWXzy0p44](https://www.youtube.com/watch?v=hYEWXzy0p44)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2024-03-26T11:28:18+00:00

Welcome to Bagging, Boarding, and Chatting. The Comic Book Show with Gary from @nerdrotic, Az from @HeelvsBabyface and @MauLerYT  

#Hollywood #Disney #marvel 

Produced by @XrayGirl_ from @pourchoices_ 

Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Streamlab Donations: https://streamlabs.com/sutrowatchtower/tip

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsored by MetaPCs!
https://www.metapcs.com/creator-nerdrotic/

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/collections/nerdrotic-coffee

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/nerdrotic-mug?

