# Source:The New Yorker, URL:https://www.newyorker.com/feed/rss, language:en-US

## Daily Cartoon: Tuesday, March 26th
 - [https://www.newyorker.com/cartoons/daily-cartoon/tuesday-march-26th-first-one](https://www.newyorker.com/cartoons/daily-cartoon/tuesday-march-26th-first-one)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-03-26T15:51:08+00:00

“I hate being the first one to the party!”

## Canoeing in a Superfund Site
 - [https://www.newyorker.com/news/our-local-correspondents/canoeing-in-a-superfund-site](https://www.newyorker.com/news/our-local-correspondents/canoeing-in-a-superfund-site)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-03-26T10:00:00+00:00

Paddling in the Gowanus Canal, in Brooklyn, has inspired one recovering lawyer to write poetry about toxic sludge, floating condoms, and gentrification.

## Percival Everett’s Philosophical Twist on “Huckleberry Finn”
 - [https://www.newyorker.com/books/page-turner/percival-everetts-philosophical-twist-on-huckleberry-finn](https://www.newyorker.com/books/page-turner/percival-everetts-philosophical-twist-on-huckleberry-finn)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-03-26T10:00:00+00:00

In his new novel, “James,” Everett explores how an emblem of American slavery can write himself into being.

## The Aftermath of China’s Comedy Crackdown
 - [https://www.newyorker.com/news/dispatch/the-aftermath-of-chinas-comedy-crackdown](https://www.newyorker.com/news/dispatch/the-aftermath-of-chinas-comedy-crackdown)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-03-26T10:00:00+00:00

Standup flourished during the pandemic. Now performers fear the state—and audience members.

## The Crossword: Tuesday, March 26, 2024
 - [https://www.newyorker.com/puzzles-and-games-dept/crossword/2024/03/26](https://www.newyorker.com/puzzles-and-games-dept/crossword/2024/03/26)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-03-26T10:00:00+00:00

A moderately challenging puzzle.

## “The Real Housewives of Roku City”
 - [https://www.newyorker.com/humor/shouts-murmurs/the-real-housewives-of-roku-city](https://www.newyorker.com/humor/shouts-murmurs/the-real-housewives-of-roku-city)
 - RSS feed: https://www.newyorker.com/feed/rss
 - date published: 2024-03-26T10:00:00+00:00

These ladies bring tons of drama and are no strangers to a TV screen.

