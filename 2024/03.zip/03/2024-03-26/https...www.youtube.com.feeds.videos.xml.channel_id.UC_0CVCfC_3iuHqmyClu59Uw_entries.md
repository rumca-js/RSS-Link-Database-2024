# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## The All-New Faster NUC BOX-155H From ASRock Is Here! Hands On First Look
 - [https://www.youtube.com/watch?v=ibkJwwTe4yE](https://www.youtube.com/watch?v=ibkJwwTe4yE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2024-03-26T15:06:00+00:00

In this video we take look at at the all new ASRock NUC BOX 155H Mini AI PC. Powered by the new Intel Core Ultra 7 155H and supporting up to 96GB of ram this little PC has potential for sure. We do an unboxing, go over the specs run some benchmarks and test out some gaming on this mini travle PC. With a TDP up to 60 watts can this PC compete with RYZEN? Lets find out.

Buy It From Newegg: https://howl.me/clUs1HcUyzF

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

Vip-Urcdkey Sale Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows 11 Pro Key($21): https://biitt.ly/RUZiX
Windows10 Home Key($14): https://biitt.ly/2tPi1
Office 2019 pro key($46): https://biitt.ly/o0OQT
Office 2021 pro key($59): https://biitt.ly/iDMHc

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME
1

