# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## Bomb Squad Called Into NYT Offices After Discovery Of Suspicious Bag
 - [https://www.youtube.com/watch?v=cr1oIWKLewY](https://www.youtube.com/watch?v=cr1oIWKLewY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2024-03-06T19:21:18+00:00

#satire #breakingnews #worldnews #usnews #woke #babylonbee

