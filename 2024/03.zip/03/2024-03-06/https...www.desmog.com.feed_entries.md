# Source:DeSmog, URL:https://www.desmog.com/feed, language:en-US

## Why the Oil and Chemical Lobby Is Taking Aim at New York’s Plastic Waste Bill
 - [https://www.desmog.com/2024/03/06/american-chemistry-council-plastics-chemical-recycling-new-york](https://www.desmog.com/2024/03/06/american-chemistry-council-plastics-chemical-recycling-new-york)
 - RSS feed: https://www.desmog.com/feed
 - date published: 2024-03-06T21:14:00+00:00

<p>A version of this piece was originally published by ExxonKnews. Last week at the New York State Capitol, more than 300 advocates joined lawmakers for a rally to urge the passage of a landmark waste reduction bill that proponents say is the best piece of legislation in the country aimed at lessening plastic trash. The [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2024/03/06/american-chemistry-council-plastics-chemical-recycling-new-york/">Why the Oil and Chemical Lobby Is Taking Aim at New York’s Plastic Waste Bill</a> appeared first on <a href="https://www.desmog.com">DeSmog</a>.</p>

