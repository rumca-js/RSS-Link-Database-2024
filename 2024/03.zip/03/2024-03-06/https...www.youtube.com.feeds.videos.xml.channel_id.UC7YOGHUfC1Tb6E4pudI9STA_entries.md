# Source:Mental Outlaw, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA, language:en-US

## BlackCat Hacked The Healthcare Industry
 - [https://www.youtube.com/watch?v=0Ua8HrgZsAg](https://www.youtube.com/watch?v=0Ua8HrgZsAg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7YOGHUfC1Tb6E4pudI9STA
 - date published: 2024-03-06T02:27:26+00:00

in this video I discuss how blackcat/AlphV hacked the healthcare industry as revenge for the FBI seizing their site on the darkweb and how they received a ransomware payment of 22 million in Bitcoin

My merch is available at
https://based.win/

Subscribe to me on Odysee.com
https://odysee.com/@AlphaNerd:8

₿💰💵💲Help Support the Channel by Donating Crypto💲💵💰₿

Monero
45F2bNHVcRzXVBsvZ5giyvKGAgm6LFhMsjUUVPTEtdgJJ5SNyxzSNUmFSBR5qCCWLpjiUjYMkmZoX9b3cChNjvxR7kvh436

Bitcoin
3MMKHXPQrGHEsmdHaAGD59FWhKFGeUsAxV

Ethereum
0xeA4DA3F9BAb091Eb86921CA6E41712438f4E5079

Litecoin
MBfrxLJMuw26hbVi2MjCVDFkkExz8rYvUF

