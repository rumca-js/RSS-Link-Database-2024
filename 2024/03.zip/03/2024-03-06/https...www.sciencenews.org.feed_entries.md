# Source:Science News, URL:https://www.sciencenews.org/feed, language:en-US

## Forests might serve as enormous neutrino detectors
 - [https://www.sciencenews.org/article/forests-neutrino-detectors-physics](https://www.sciencenews.org/article/forests-neutrino-detectors-physics)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-03-06T15:30:00+00:00

Trees could act as antennas that pick up radio waves of ultra-high energy neutrinos interactions, one physicist proposes.

## See 3-D models of animal anatomy from openVertebrate’s public collection
 - [https://www.sciencenews.org/article/3d-animal-anatomy-openvertebrate](https://www.sciencenews.org/article/3d-animal-anatomy-openvertebrate)
 - RSS feed: https://www.sciencenews.org/feed
 - date published: 2024-03-06T13:00:00+00:00

Over six years, researchers took CT scans of over 13,000 vertebrates to make museum collections more easily accessible to researchers and the public.

