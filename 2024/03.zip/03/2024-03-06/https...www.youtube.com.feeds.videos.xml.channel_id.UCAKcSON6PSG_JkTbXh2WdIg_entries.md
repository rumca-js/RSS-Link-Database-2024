# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## U2 play "Who's Gonna Ride Your Wild Horses" at Sphere #u2 #lasvegas
 - [https://www.youtube.com/watch?v=yq0kfRzCX8U](https://www.youtube.com/watch?v=yq0kfRzCX8U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2024-03-06T22:14:15+00:00

On Saturday, March 2, U2 concluded their historic residency at Sphere in Las Vegas.

Back on February 6, a member of our team, The Current's Promotions Manager Shellae Mueller, attended U2's concert at Sphere. Here is Shellae's view of the concert and the stunning visuals at Sphere as the band performed "Who's Gonna Ride Your Wild Horses."

Musicians
Edge – guitar, backing vocals
Bono – vocals
Adam Clayton – bass
Bram van den Berg – drums

Credits
Video – Shellae Mueller
Post-production – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://www.instagram.com/thecurrent/
https://www.tiktok.com/@thecurrent.org

#shorts #sphere #music

