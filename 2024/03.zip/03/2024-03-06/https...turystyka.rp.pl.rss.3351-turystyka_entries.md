# Source:Turystyka, URL:https://turystyka.rp.pl/rss/3351-turystyka, language:pl-PL

## Lotnisko we Wrocławiu: Udany luty zapowiedzią dobrego sezonu letniego
 - [https://turystyka.rp.pl/lotniska/art39950331-lotnisko-we-wroclawiu-udany-luty-zapowiedzia-dobrego-sezonu-letniego](https://turystyka.rp.pl/lotniska/art39950331-lotnisko-we-wroclawiu-udany-luty-zapowiedzia-dobrego-sezonu-letniego)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-03-06T12:35:15+00:00

W lutym liczba operacji lotniczych i pasażerów obsłużonych w Porcie Lotniczym Wrocław zwiększyła się o prawie 17 procent względem poprzedniego roku.

## Internetowi giganci łączą siły, by współtworzyć przepisy
 - [https://turystyka.rp.pl/biura-podrozy/art39949751-internetowi-giganci-lacza-sily-by-wspoltworzyc-przepisy](https://turystyka.rp.pl/biura-podrozy/art39949751-internetowi-giganci-lacza-sily-by-wspoltworzyc-przepisy)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-03-06T10:24:21+00:00

Expedia Group, Booking Holdings, eDreams Odigeo, Amadeus, Travelport i Skyscanner łączą siły w sojuszu Global Travel Tech, którego celem będzie wspieranie innowacyjności i konkurencyjności w branży turystycznej. To odpowiedź na nadchodzące zmiany przepisów, które będą miały wpływ na platformy turystyczne na całym świecie.

## Minister na targach ITB Berlin: Musimy przekonać turystów, że Polska jest bezpieczna
 - [https://turystyka.rp.pl/popularne-trendy/art39948891-minister-na-targach-itb-berlin-musimy-przekonac-turystow-ze-polska-jest-bezpieczna](https://turystyka.rp.pl/popularne-trendy/art39948891-minister-na-targach-itb-berlin-musimy-przekonac-turystow-ze-polska-jest-bezpieczna)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-03-06T08:13:22+00:00

– Tu jest moja wizytówka, proszę przysłać państwa uwagi i sugestie – to najczęściej powtarzana przez wiceministra sportu i turystyki Piotra Borysa fraza podczas wczorajszych spotkań z przedstawicielami branży turystycznej na targach turystycznych w Berlinie. Minister deklaruje chęć rozmowy, ale i pomoc w rozwiązywaniu problemów.

