# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Notorious killer tells police where he buried victim's body 55 years ago
 - [https://news.sky.com/story/muriel-mckay-death-notorious-killer-tells-police-where-he-buried-victims-body-55-years-ago-13088743](https://news.sky.com/story/muriel-mckay-death-notorious-killer-tells-police-where-he-buried-victims-body-55-years-ago-13088743)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T20:27:00+00:00

A notorious killer has told British detectives where he buried his victim's remains 55 years ago, after they flew to his Caribbean home to interview him.

## Zelenskyy witnesses deadly Russian missile strike as he visits Odesa with Greek PM
 - [https://news.sky.com/story/ukraine-president-zelenskyy-witnesses-deadly-russian-missile-strike-as-he-visits-odesa-with-greek-pm-13088721](https://news.sky.com/story/ukraine-president-zelenskyy-witnesses-deadly-russian-missile-strike-as-he-visits-odesa-with-greek-pm-13088721)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T19:57:00+00:00

Volodymyr Zelenskyy witnessed a deadly Russian missile strike just a few hundred metres away as he visited Odesa in Ukraine.

## 'At least two sailors killed' after suspected Houthi attack
 - [https://news.sky.com/story/at-least-two-sailors-killed-after-suspected-houthi-attack-13088615](https://news.sky.com/story/at-least-two-sailors-killed-after-suspected-houthi-attack-13088615)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T17:17:00+00:00

At least two sailors have died after a suspected Houthi attack in the Gulf of Aden, according to the British Embassy in Yemen.

## German ambassador refuses to apologise for leaked call 'revealing British troops in Ukraine'
 - [https://news.sky.com/story/german-ambassador-refuses-to-apologise-for-leaked-call-revealing-british-troops-in-ukraine-13088416](https://news.sky.com/story/german-ambassador-refuses-to-apologise-for-leaked-call-revealing-british-troops-in-ukraine-13088416)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T12:42:00+00:00

Germany's ambassador to the UK has said there is "no need" for his country to apologise after a recording leaked by Russia revealed the head of the air force discussing secret details about alleged British troops in Ukraine.

## Real Madrid boss Carlo Ancelotti facing nearly five years in prison on tax-fraud charges
 - [https://news.sky.com/story/real-madrid-manager-carlo-ancelotti-facing-nearly-five-years-in-prison-on-tax-fraud-charges-13088328](https://news.sky.com/story/real-madrid-manager-carlo-ancelotti-facing-nearly-five-years-in-prison-on-tax-fraud-charges-13088328)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T10:34:00+00:00

Real Madrid football manager Carlo Ancelotti is facing nearly five years in prison after being accused of tax fraud in Spain.

## Number of steps a day it takes to cut risk of early death (and it's less than you think)
 - [https://news.sky.com/story/number-of-steps-a-day-it-takes-to-cut-risk-of-early-death-new-study-13088295](https://news.sky.com/story/number-of-steps-a-day-it-takes-to-cut-risk-of-early-death-new-study-13088295)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T10:06:00+00:00

If you've failed in your quest of walking 10,000 steps a day - researchers have some good news for you.

## Alexei Navalny's widow urges Russians to protest on election day
 - [https://news.sky.com/story/alexei-navalnys-widow-yulia-navalnaya-urges-russians-to-protest-on-election-day-13088290](https://news.sky.com/story/alexei-navalnys-widow-yulia-navalnaya-urges-russians-to-protest-on-election-day-13088290)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T09:59:00+00:00

Yulia Navalnaya has suggested Russians should write Alexei Navalny's name on their voting ballots and urged them to protest at the upcoming elections.

## Five SAS soldiers under investigation for alleged war crimes in Syria
 - [https://news.sky.com/story/five-sas-soldiers-under-investigation-for-alleged-war-crimes-in-syria-13088282](https://news.sky.com/story/five-sas-soldiers-under-investigation-for-alleged-war-crimes-in-syria-13088282)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T09:38:00+00:00

Five SAS soldiers are being investigated for potential war crimes over the death of a suspected militant in Syria two years ago.

## Who 'killed' Stalin? Russian communists ask for probe into 'Western involvement' in dictator's death
 - [https://news.sky.com/story/joseph-stalin-russian-communists-ask-fsb-to-investigate-wests-possible-involvement-in-death-of-soviet-leader-13088274](https://news.sky.com/story/joseph-stalin-russian-communists-ask-fsb-to-investigate-wests-possible-involvement-in-death-of-soviet-leader-13088274)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T09:23:00+00:00

The Communists of Russia party has asked the security service to investigate whether Western intelligence services were involved in the death of Joseph Stalin.

## UK to warn Israel over Gaza aid as patience running 'thin', Cameron says
 - [https://news.sky.com/story/uk-to-warn-israel-over-gaza-aid-as-patience-running-thin-lord-cameron-says-13088246](https://news.sky.com/story/uk-to-warn-israel-over-gaza-aid-as-patience-running-thin-lord-cameron-says-13088246)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T08:16:00+00:00

The UK's patience is running "thin" with Israel over aid entering Gaza, Lord David Cameron has said, as he is set to warn Israeli war cabinet member Benny Gantz over the matter today.

## We're on course for the oldest presidential race in US history - and one most people don't want
 - [https://news.sky.com/story/were-on-course-for-the-oldest-presidential-race-in-us-history-and-one-most-people-dont-want-13088203](https://news.sky.com/story/were-on-course-for-the-oldest-presidential-race-in-us-history-and-one-most-people-dont-want-13088203)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T05:54:00+00:00

This was less Super Tuesday and more Predictable Tuesday.&#160;

## Biden-Trump rematch looks certain after pair dominate Super Tuesday votes
 - [https://news.sky.com/story/biden-trump-rematch-looks-certain-after-pair-dominate-super-tuesday-votes-13088175](https://news.sky.com/story/biden-trump-rematch-looks-certain-after-pair-dominate-super-tuesday-votes-13088175)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-03-06T03:42:00+00:00

US President Joe Biden and his predecessor Donald Trump swept to victory in statewide nomination contests on Tuesday, setting up a historic rematch in November's election.

