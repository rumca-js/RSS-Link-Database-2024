# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Drinker does Gaming - Final Fantasy VII Rebirth
 - [https://www.youtube.com/watch?v=eDgark3-mrs](https://www.youtube.com/watch?v=eDgark3-mrs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2024-03-06T21:36:21+00:00



