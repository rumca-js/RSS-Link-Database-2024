# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Death of Two Great Open Source Emulators
 - [https://www.youtube.com/watch?v=2zba7mgqpKE](https://www.youtube.com/watch?v=2zba7mgqpKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2024-03-06T20:00:02+00:00

Recently Nintendo went to war with both the Yuzu Switch emulator and as the developers are the same, the Citra 3DS emulator was taken down as well as they decided to just settle, forks are forming but they're not in the best of states. Luckily Ryujinx, Panda3DS and Mikage also exist.

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
PCGamer Article: https://www.pcgamer.com/nintendo-is-suing-the-makers-of-the-switch-emulator-yuzu-claims-there-is-no-lawful-way-to-use-yuzu/
Yuzu Tweet: https://web.archive.org/web/20230514001441/https://twitter.com/yuzuemu/status/1657458477080666112
Verge Article: https://www.theverge.com/2024/3/4/24090357/nintendo-yuzu-emulator-lawsuit-settlement
Yuzu Website: https://yuzu-emu.org/
Citra Emulator: https://citra-emu.org/
Yuzu Github:

