# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Jedna trzecia kancelarii Sławomira Mentzena na sprzedaż. Podano ceny akcji
 - [https://www.wirtualnemedia.pl/artykul/slawomir-mentzen-kancelaria-prawna-akcje-gielda-sprzedaz](https://www.wirtualnemedia.pl/artykul/slawomir-mentzen-kancelaria-prawna-akcje-gielda-sprzedaz)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-03-06T05:13:24.490274+00:00

Kancelaria prawna Sławomira Mentzena zaczyna sprzedaż swoich akcji przed debiutem giełdowym. Zapisy na kupno akcji potrwają do 28 marca. Spółka wycenia się na ponad 30 mln zł.

