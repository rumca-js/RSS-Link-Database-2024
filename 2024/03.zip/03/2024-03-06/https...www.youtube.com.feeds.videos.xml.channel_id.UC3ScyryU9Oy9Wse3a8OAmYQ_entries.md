# Source:FRONTLINE PBS | Official, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ, language:en-US

## Fractured (trailer) | FRONTLINE
 - [https://www.youtube.com/watch?v=mNz4y1sPGl0](https://www.youtube.com/watch?v=mNz4y1sPGl0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3ScyryU9Oy9Wse3a8OAmYQ
 - date published: 2024-03-06T15:20:51+00:00

FRONTLINE, WFAE & Firelight Media investigate the long waits for mental health care that defendants who are deemed too sick to stand trial face in North Carolina. Premiering on Tuesday, Mar. 5 at 4/3c.

This journalism is made possible by viewers like you. Support your local PBS station here: https://www.pbs.org/donate​

Subscribe on YouTube: http://bit.ly/1BycsJW
Instagram: https://www.instagram.com/frontlinepbs​
Twitter: https://twitter.com/frontlinepbs​
Facebook: https://www.facebook.com/frontline

FRONTLINE is produced at GBH in Boston and is broadcast nationwide on PBS. Funding for FRONTLINE is provided through the support of PBS viewers and by the Corporation for Public Broadcasting. Additional support for FRONTLINE is provided by the Abrams Foundation, Park Foundation, the John D. and Catherine T. MacArthur Foundation, the Heising-Simons Foundation, and the FRONTLINE Journalism Fund, with major support from Jon and Jo Ann Hagler on behalf of the Jon L. Hagler Foundatio

