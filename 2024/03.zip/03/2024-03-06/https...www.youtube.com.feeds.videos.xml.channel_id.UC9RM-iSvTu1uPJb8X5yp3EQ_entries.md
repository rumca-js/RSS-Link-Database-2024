# Source:Wendover Productions, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC9RM-iSvTu1uPJb8X5yp3EQ, language:en-US

## The Growing Reality of War in Space
 - [https://www.youtube.com/watch?v=V0DmliiUFHk](https://www.youtube.com/watch?v=V0DmliiUFHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC9RM-iSvTu1uPJb8X5yp3EQ
 - date published: 2024-03-06T14:26:59+00:00

Get Nebula using my link for 40% off an annual subscription: https://go.nebula.tv/wendover
Watch the Logistics of X: https://nebula.tv/thelogisticsofx

Youtube: http://www.YouTube.com/WendoverProductions
Instagram: http://Instagram.com/sam.from.wendover
Twitter: http://www.Twitter.com/WendoverPro
Sponsorship Enquiries: wendover@standard.tv
Other emails: sam@wendover.productions
Reddit: http://Reddit.com/r/WendoverProductions

Writing by Sam Denby and Tristan Purdy
Editing by Alexander Williard
Animation led by Max Moser
Sound by Graham Haerther 
Thumbnail by Simon Buckmaster

References
[1] https://cyberscoop.com/viasat-ka-sat-hack-black-hat/ 
[2] https://aviationweek.com/defense-space/missile-defense-weapons/arrow-3-makes-combat-debut-thwarting-long-range-missile 
[3] https://media.defense.gov/2023/Sep/14/2003301146/-1/-1/0/COMPREHENSIVE-REPORT-FOR-RELEASE.PDF 
[4] https://spacenews.com/dod-satellites-in-low-earth-orbit-promise-more-connectivity-for-military-users/
[5] https

