# Source:Mrwhosetheboss, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCMiJRAwDNSNzuYeN2uWa0pA, language:en-US

## 5 Most BRUTAL Tech Pranks Ever!
 - [https://www.youtube.com/watch?v=eSucdOAIwrg](https://www.youtube.com/watch?v=eSucdOAIwrg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCMiJRAwDNSNzuYeN2uWa0pA
 - date published: 2024-03-06T17:39:55+00:00



