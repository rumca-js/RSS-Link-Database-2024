# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## ‘Death Cult’: Another Senior NZ Official Draws Scrutiny for Open Hostility Towards Government
 - [https://www.theepochtimes.com/world/death-cult-another-senior-nz-official-draws-scrutiny-for-open-hostility-towards-government-5601668](https://www.theepochtimes.com/world/death-cult-another-senior-nz-official-draws-scrutiny-for-open-hostility-towards-government-5601668)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T23:18:22+00:00

(L-R) Winston Peters, leader of New Zealand First party, New Zealand's incoming Prime Minister Christopher Luxon, and David Seymour, leader of the ACT New Zealand party, attend the signing of an agreement to form a three-party coalition government at Parliament in Wellington on Nov. 24, 2023. (Marty Melville/AFP via Getty Images)

## Rowdy Pro-Palestine Protests Blocking Events Escalate in Toronto
 - [https://www.theepochtimes.com/world/rowdy-pro-palestine-protests-blocking-events-escalate-in-toronto-5601595](https://www.theepochtimes.com/world/rowdy-pro-palestine-protests-blocking-events-escalate-in-toronto-5601595)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T22:12:06+00:00

Protesters wave flags and sing as police line the entrance to the Art Gallery of Ontario, where a cancelled event for Prime Minister Justin Trudeau and Italy's Prime Minister Giorgia Meloni was to take place, in Toronto on March 2, 2024. (The Canadian Press/Cole Burston)

## Why Ottawa’s ‘Economic Plan’ to Excel in EV Industry May ‘Flop’: Economist
 - [https://www.theepochtimes.com/world/why-ottawas-economic-plan-to-excel-in-ev-industry-may-flop-economist-5602055](https://www.theepochtimes.com/world/why-ottawas-economic-plan-to-excel-in-ev-industry-may-flop-economist-5602055)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T22:08:34+00:00

Deputy Prime Minister and Minister of Finance Chrystia Freeland responds to a question during a news conference in Ottawa on Oct. 24, 2023. (The Canadian Press/Adrian Wyld)

## Hamas, Israel Deadlocked in Ceasefire Negotiations
 - [https://www.theepochtimes.com/world/hamas-israel-deadlocked-in-ceasefire-negotiations-5602163](https://www.theepochtimes.com/world/hamas-israel-deadlocked-in-ceasefire-negotiations-5602163)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T21:30:36+00:00

An Israeli army tank moving along the border area from Israel near the border with the Gaza Strip on March 6, 2024. (Jack Guez/AFP via Getty Images)

## BC’s Attempt to Ban Drug Use in Parks Fails Court Appeal
 - [https://www.theepochtimes.com/world/bcs-attempt-to-ban-drug-use-in-parks-fails-court-appeal-5601871](https://www.theepochtimes.com/world/bcs-attempt-to-ban-drug-use-in-parks-fails-court-appeal-5601871)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T21:05:33+00:00

The Law Courts building, which is home to B.C. Supreme Court and the Court of Appeal, is seen in Vancouver, on Nov. 23, 2023. (The Canadian Press/Darryl Dyck)

## India Halts Pakistan-Bound Chinese Ship Over Missile Program Fears
 - [https://www.theepochtimes.com/world/india-halts-pakistan-bound-chinese-ship-over-missile-program-fears-5601798](https://www.theepochtimes.com/world/india-halts-pakistan-bound-chinese-ship-over-missile-program-fears-5601798)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T20:26:03+00:00

In this file photo, a worker watches operations at the container off-loading terminal in the Jawaharlal Nehru Port Trust (JNPT) premises in Mumbai, India. Customs intercepted a Pakistan-bound shipment from China on Jan. 23, 2024 at JNPT on suspicion that it contained military-grade materials. (Indranil Mukherjee/AFP via Getty Images)

## Ottawa Rejects Commission’s Recommendation to Disclose Emergencies Act Documents
 - [https://www.theepochtimes.com/world/ottawa-rejects-commissions-recommendation-to-disclose-emergencies-act-documents-5602002](https://www.theepochtimes.com/world/ottawa-rejects-commissions-recommendation-to-disclose-emergencies-act-documents-5602002)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T20:11:28+00:00

Final preparations are made prior to the start of the Public Emergency Order Commission in Ottawa on Oct. 13, 2022. (The Canadian Press/Sean Kilpatrick)

## Russia Says It Will Not Meddle in US Elections
 - [https://www.theepochtimes.com/us/russia-says-it-will-not-meddle-in-us-elections-5602009](https://www.theepochtimes.com/us/russia-says-it-will-not-meddle-in-us-elections-5602009)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T20:08:38+00:00

Russian President Vladimir Putin attends the G20 virtual summit via a video link in Moscow, on Nov. 22, 2023. (Sputnik/Mikhail Klimentyev/Kremlin via Reuters)

## 9 Ontario Nurses Fired for Refusing COVID Vaccines Should Be Reinstated, Arbitrator Rules
 - [https://www.theepochtimes.com/world/9-ontario-nurses-fired-for-refusing-covid-vaccines-should-be-reinstated-arbitrator-rules-5602011](https://www.theepochtimes.com/world/9-ontario-nurses-fired-for-refusing-covid-vaccines-should-be-reinstated-arbitrator-rules-5602011)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T19:45:17+00:00

A health-care worker fills a syringe with Pfizer's COVID-19 vaccine in a file image. (Robyn Beck/AFP via Getty Images)

## In Contrast to China, Japanese Economy Surges With Historic Stock Market Peak
 - [https://www.theepochtimes.com/world/in-contrast-to-china-japanese-economy-surges-with-historic-stock-market-peak-5599084](https://www.theepochtimes.com/world/in-contrast-to-china-japanese-economy-surges-with-historic-stock-market-peak-5599084)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T18:50:52+00:00

An electronic board displays stock prices of companies listed on the Tokyo Stock Exchange, along a street in Tokyo, on Feb. 26, 2024.  (Kazuhiro Nogi/AFP via Getty Images)

## Daylight Saving Time: Get Ready to Spring Forward This Weekend
 - [https://www.theepochtimes.com/world/daylight-saving-time-get-ready-to-spring-forward-this-weekend-5602012](https://www.theepochtimes.com/world/daylight-saving-time-get-ready-to-spring-forward-this-weekend-5602012)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T18:32:56+00:00

Daylight saving time will begin at 2 a.m. on March 10 and end on Nov. 3. (Jeff Pachoud/AFP via Getty Images)

## ‘Toxic Masculinity’ Narrative Harming Boys, MP Tells Parliament
 - [https://www.theepochtimes.com/world/toxic-masculinity-narrative-harming-boys-mp-tells-parliament-5601892](https://www.theepochtimes.com/world/toxic-masculinity-narrative-harming-boys-mp-tells-parliament-5601892)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T17:35:12+00:00

School pupils walking in a file photo on Jan. 26, 2012. (David Jones/PA Wire)

## Government Admits To Sharing ‘Commercially Sensitive’ Data On Vaccine Deaths With Big Pharma
 - [https://www.theepochtimes.com/world/government-admits-to-sharing-commercially-sensitive-data-on-vaccine-deaths-with-big-pharma-5601796](https://www.theepochtimes.com/world/government-admits-to-sharing-commercially-sensitive-data-on-vaccine-deaths-with-big-pharma-5601796)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T17:25:07+00:00

UK Health Security Agency Chief Executive Jenny Harries attends a press conference inside the Downing Street Briefing Room in central London on Oct. 20, 2021. (Toby Melville /Pool/AFP via Getty Images)

## Assessment of Government Borrowing ‘Nebulous at Best’, Says Public Accounts Committee
 - [https://www.theepochtimes.com/world/assessment-of-government-borrowing-nebulous-at-best-says-public-accounts-committee-5601766](https://www.theepochtimes.com/world/assessment-of-government-borrowing-nebulous-at-best-says-public-accounts-committee-5601766)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T17:24:53+00:00

Dame Meg Hillier MP in an undated file photo. (Jessica Taylor/PA)

## Syrian Refugee Sympathetically Profiled by BBC Convicted for Child Rape
 - [https://www.theepochtimes.com/world/syrian-refugee-sympathetically-profiled-by-bbc-convicted-for-child-rape-5601772](https://www.theepochtimes.com/world/syrian-refugee-sympathetically-profiled-by-bbc-convicted-for-child-rape-5601772)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T17:11:57+00:00

A general view of BBC Broadcasting House, in central London on July 10, 2023. (Lucy North/PA Wire)

## CBC Says Government-Facebook Feud to Blame for Declining Website Traffic
 - [https://www.theepochtimes.com/world/cbc-says-government-facebook-feud-to-blame-for-declining-website-traffic-5601949](https://www.theepochtimes.com/world/cbc-says-government-facebook-feud-to-blame-for-declining-website-traffic-5601949)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T16:25:50+00:00

People walk into the CBC building in Toronto on April 4, 2012. (The Canadian Press/Nathan Denette)

## Chancellor Cuts National Insurance and Abolishes Non-Dom Status in Final Budget Before Election
 - [https://www.theepochtimes.com/world/chancellor-cuts-national-insurance-and-abolishes-non-dom-status-in-final-budget-before-election-5601813](https://www.theepochtimes.com/world/chancellor-cuts-national-insurance-and-abolishes-non-dom-status-in-final-budget-before-election-5601813)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T16:13:52+00:00

Chancellor of the Exchequer Jeremy Hunt (C, holding red ministerial box) leaves Downing Street, before delivering his Budget in the Houses of Parliament in London on March 6, 2024. (James Manning/PA Wire)

## US Forces Shoot Down Houthi Missile, Drones Targeting Warship in Red Sea
 - [https://www.theepochtimes.com/world/us-forces-shoot-down-houthi-missile-drones-targeting-warship-in-red-sea-5601844](https://www.theepochtimes.com/world/us-forces-shoot-down-houthi-missile-drones-targeting-warship-in-red-sea-5601844)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T15:58:11+00:00

The U.S. Navy guided-missile destroyer USS Carney transits the Suez Canal, Egypt, on Oct. 18, 2023. (Aaron Lau/U.S. Navy via Reuters)

## Federal Accountants Were Afraid to Speak Out on ArriveCan Irregularities, Says Union Exec
 - [https://www.theepochtimes.com/world/federal-accountants-were-afraid-to-speak-out-on-arrivecan-irregularities-says-union-exec-5601888](https://www.theepochtimes.com/world/federal-accountants-were-afraid-to-speak-out-on-arrivecan-irregularities-says-union-exec-5601888)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T15:52:27+00:00

A smartphone set to the opening screen of the ArriveCan app is seen in a file photo. (The Canadian Press/Giordano Ciampini)

## Net Zero Time Frame ‘Unrealistic’ and Green Investments Could Cost 5 Percent of GDP: Report
 - [https://www.theepochtimes.com/world/net-zero-time-frame-unrealistic-and-green-investments-could-cost-5-percent-of-gdp-report-5601832](https://www.theepochtimes.com/world/net-zero-time-frame-unrealistic-and-green-investments-could-cost-5-percent-of-gdp-report-5601832)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T15:45:54+00:00

Wind turbines generate electricity in Runcorn, England, on Sept. 21, 2023. (Christopher Furlong/Getty Images)

## Cabinet Minister Pays Damages to Academic She Accused of Hamas Sympathy
 - [https://www.theepochtimes.com/world/cabinet-minister-pays-damages-to-academic-she-accused-of-hamas-sympathy-5601853](https://www.theepochtimes.com/world/cabinet-minister-pays-damages-to-academic-she-accused-of-hamas-sympathy-5601853)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T15:05:49+00:00

Minister for Higher and Further Education, Michelle Donelan addresses delegates during the Conservative Party Spring Conference, at Blackpool Winter Gardens in Blackpool, north-west England, on March 18, 2022. (Paul Ellis/AFP via Getty Images)

## US Officials Investigating After Five Canadians Killed in Nashville Plane Crash
 - [https://www.theepochtimes.com/world/us-officials-investigating-after-five-canadians-killed-in-nashville-plane-crash-5601909](https://www.theepochtimes.com/world/us-officials-investigating-after-five-canadians-killed-in-nashville-plane-crash-5601909)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T14:55:51+00:00

Investigators look over a small plane crash alongside eastbound Interstate 40 at mile marker 202, in Nashville, Tenn, on March 5, 2024. (The Associated Press/George Walker IV)

## Bank of Canada Holds Policy Rate at 5%, Reiterates Inflation Outlook Concern
 - [https://www.theepochtimes.com/business/bank-of-canada-holds-policy-rate-at-5-reiterates-inflation-outlook-concern-5601208](https://www.theepochtimes.com/business/bank-of-canada-holds-policy-rate-at-5-reiterates-inflation-outlook-concern-5601208)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T14:48:56+00:00

The Bank of Canada wording on a Canadian $50 bill is pictured in Ottawa on Jan. 11, 2023. Canada's central bank kept its overnight rate target at 5 percent on March 6, 2024. (The Canadian Press/Sean Kilpatrick)

## State Funeral for Former Prime Minister Mulroney to Be Held in Montreal March 23
 - [https://www.theepochtimes.com/world/state-funeral-for-former-prime-minister-mulroney-to-be-held-in-montreal-march-23-post-5601880](https://www.theepochtimes.com/world/state-funeral-for-former-prime-minister-mulroney-to-be-held-in-montreal-march-23-post-5601880)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T14:21:49+00:00

A framed portrait of former prime minister Brian Mulroney leans against the Centennial Flame on Parliament Hill  
as Canadians mourn his death at the age of 84, in Ottawa, on March 1, 2024. (The Canadian Press/Justin Tang)

## Navalny Died His Own Death, Russian Spy Chief Says
 - [https://www.theepochtimes.com/world/navalny-died-his-own-death-russian-spy-chief-says-5601795](https://www.theepochtimes.com/world/navalny-died-his-own-death-russian-spy-chief-says-5601795)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T13:19:22+00:00

Lyudmila Navalnaya (the woman wearing glasses), mother of Alexei Navalny, accompanied by Alla, mother of Navalny's widow Yulia, visits the grave of her son at the Borisovo cemetery in Moscow on March 2, 2024. (Olga Maltseva/AFP via Getty Images)

## Wokeism vs. Classical Liberal Truth-Based Order at the Root of Online Harms Bill Debate
 - [https://www.theepochtimes.com/opinion/wokeism-vs-classical-liberal-truth-based-order-at-the-root-of-online-harms-bill-debate-5600590](https://www.theepochtimes.com/opinion/wokeism-vs-classical-liberal-truth-based-order-at-the-root-of-online-harms-bill-debate-5600590)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T13:02:37+00:00

The Parliament Buildings are seen beyond the Alexandra Bridge in Ottawa on Sept. 7, 2022. (The Canadian Press/Adrian Wyld)

## Birmingham City Council Approves Tax Hike, Cuts to Key Services
 - [https://www.theepochtimes.com/world/birmingham-city-council-approves-tax-hike-cuts-to-key-services-5601816](https://www.theepochtimes.com/world/birmingham-city-council-approves-tax-hike-cuts-to-key-services-5601816)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T12:25:45+00:00

A general view of Council House in Birmingham on Sept. 19, 2023. (Matthew Cooper/PA Wire)

## Pro-Palestine Group Withdraws Support for Event Featuring Hijacker
 - [https://www.theepochtimes.com/world/pro-palestine-group-withdraws-support-for-event-featuring-hijacker-5601793](https://www.theepochtimes.com/world/pro-palestine-group-withdraws-support-for-event-featuring-hijacker-5601793)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T12:03:46+00:00

People take part in a Palestine Solidarity Campaign rally outside the Houses of Parliament in London, as MPs debate calls for a ceasefire in Gaza on Feb. 21, 2024. (Lucy North/PA Wire)

## Investigation Ongoing Over Death of McConnell’s Sister-in-Law, Texas Officials Say
 - [https://www.theepochtimes.com/us/investigation-ongoing-over-death-of-mcconnells-sister-in-law-texas-officials-say-5601477](https://www.theepochtimes.com/us/investigation-ongoing-over-death-of-mcconnells-sister-in-law-texas-officials-say-5601477)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T12:00:26+00:00

Angela Chao attends the AFI Awards Luncheon at Four Seasons Hotel Los Angeles at Beverly Hills in Los Angeles, Calif., on Jan. 12, 2024. (Frazer Harrison/Getty Images)

## Met Commissioner Says Violence Against Women and Girls Need to be Treated Like Terrorism
 - [https://www.theepochtimes.com/world/met-commissioner-says-violence-against-women-and-girls-need-to-be-treated-like-terrorism-5601743](https://www.theepochtimes.com/world/met-commissioner-says-violence-against-women-and-girls-need-to-be-treated-like-terrorism-5601743)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T11:51:42+00:00

Metropolitan Police Commissioner Sir Mark Rowley at the scene where Elianne Andam, 15, was stabbed to death in Croydon, south London, on Sep. 27, 2023. (Lucy North/PA Wire)

## Ministers Review Rules Following Report of Chinese Research Collaboration
 - [https://www.theepochtimes.com/china/ministers-review-rules-following-report-of-chinese-research-collaboration-5564753](https://www.theepochtimes.com/china/ministers-review-rules-following-report-of-chinese-research-collaboration-5564753)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T11:42:24+00:00

British Chancellor of the Exchequer George Osborne (L) and Chinese leader Xi Jinping wear 3D glasses as they are shown a demonstration of medical equipment during a Hamlyn Centre for Robotic Surgery presentation at Imperial College London, in central London, on Oct. 21, 2015. (Anthony Devlin/AFP via Getty Images)

## Sen. Schmitt Urges Pentagon to Help Philippines Counter China’s ‘Aggressive Behavior’
 - [https://www.theepochtimes.com/world/sen-schmitt-urges-pentagon-to-help-philippines-counter-chinas-aggression-in-disputed-sea-5601554](https://www.theepochtimes.com/world/sen-schmitt-urges-pentagon-to-help-philippines-counter-chinas-aggression-in-disputed-sea-5601554)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T11:28:05+00:00

Sen. Eric Schmitt (R-Mo.) is ceremonially sworn in by Vice President Kamala Harris for the 118th Congress in the Old Senate Chamber at the U.S. Capitol, on Jan. 3, 2023. (Olivier Douliery/AFP via Getty Images)

## MPs Demand Power to Block Foreign Takeover of UK Press Amid Telegraph Sale
 - [https://www.theepochtimes.com/world/mps-demand-power-to-block-foreign-takeover-of-uk-press-amid-telegraph-sale-5575078](https://www.theepochtimes.com/world/mps-demand-power-to-block-foreign-takeover-of-uk-press-amid-telegraph-sale-5575078)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T11:09:29+00:00

Immigration Minister Robert Jenrick prepares to speak to the media outside BBC Broadcasting House in London on Oct. 22, 2023. (Stefan Rousseau/PA)

## ICC Issues Arrest Warrants for 2 Russian Military Officials Over Alleged War Crimes
 - [https://www.theepochtimes.com/world/icc-issues-arrest-warrants-for-2-russian-military-officials-over-alleged-war-crimes-5601741](https://www.theepochtimes.com/world/icc-issues-arrest-warrants-for-2-russian-military-officials-over-alleged-war-crimes-5601741)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T11:03:31+00:00

An exterior view of the International Criminal Court in the Hague, Netherlands, on March 31, 2021. (Piroschka van de Wouw/Reuters)

## Peers Push for Decriminalisation of BBC Licence Fee Evasion
 - [https://www.theepochtimes.com/world/peers-push-for-decriminalisation-of-bbc-licence-fee-evasion-5601037](https://www.theepochtimes.com/world/peers-push-for-decriminalisation-of-bbc-licence-fee-evasion-5601037)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T10:45:22+00:00

A general view of BBC Broadcasting House, in central London on July 10, 2023. (Lucy North/PA Wire)

## Regulator Fines Optus $1.5 Million for Large-Scale Safety Rules Violation
 - [https://www.theepochtimes.com/world/regulator-fines-optus-1-5-million-for-large-scale-safety-rules-violation-5601623](https://www.theepochtimes.com/world/regulator-fines-optus-1-5-million-for-large-scale-safety-rules-violation-5601623)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T05:30:28+00:00

Pedestrians walk past an Optus store in Sydney, Australia, on Nov. 21, 2023. (Lisa Maree Williams/Getty Images)

## Non-Alcoholic Drinks: A Hidden Threat for Adolescents
 - [https://www.theepochtimes.com/world/non-alcoholic-drinks-a-hidden-threat-for-adolescents-5601530](https://www.theepochtimes.com/world/non-alcoholic-drinks-a-hidden-threat-for-adolescents-5601530)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T05:08:19+00:00

Choosing drinks with a little less alcohol for events where drinks flow freely is an excellent strategy. (Roman Samborskyi/Shutterstock)

## US Slaps Sanctions on Greek Spyware Vendor, Says It Targeted US Officials
 - [https://www.theepochtimes.com/us/us-slaps-sanctions-on-greek-spyware-vendor-says-it-targeted-us-officials-5601165](https://www.theepochtimes.com/us/us-slaps-sanctions-on-greek-spyware-vendor-says-it-targeted-us-officials-5601165)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T04:56:43+00:00

Signage is seen at the United States Department of the Treasury headquarters in Washington on Aug. 29, 2020. (Andrew Kelly/Reuters)

## Russia Says It Is Considering Putting a Nuclear Power Plant on the Moon With China
 - [https://www.theepochtimes.com/world/russia-says-it-is-considering-putting-a-nuclear-power-plant-on-the-moon-with-china-5600952](https://www.theepochtimes.com/world/russia-says-it-is-considering-putting-a-nuclear-power-plant-on-the-moon-with-china-5600952)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T04:51:42+00:00

Head of the Roscosmos space corporation Yuri Borisov attends a State Committee meeting ahead of the planned launch of the Soyuz MS-24 spacecraft to the International Space Station (ISS) at the Russian leased Baikonur cosmodrome in Kazakhstan on Sept. 14, 2023. (Maxim Shipenkov/Pool via Reuters)

## Ontario Elementary Rankings Let You See How Your Child’s School Fares
 - [https://www.theepochtimes.com/world/ontario-elementary-rankings-let-you-see-how-your-childs-school-fares-5601502](https://www.theepochtimes.com/world/ontario-elementary-rankings-let-you-see-how-your-childs-school-fares-5601502)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T04:07:06+00:00

Federal, state, and local governments spend an average of nearly $15,000 per student in our public schools. (Ground Picture/Shutterstock)

## Farmers Call for Exception to New Emissions ‘Tax’ on Vehicles
 - [https://www.theepochtimes.com/world/farmers-calls-for-exception-to-new-emissions-tax-on-vehicles-5601527](https://www.theepochtimes.com/world/farmers-calls-for-exception-to-new-emissions-tax-on-vehicles-5601527)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T03:24:49+00:00

A freshly cut tree is seen on the back of a ute in Luddenham, Australia, on Dec. 3, 2016. (Mark Kolbe/Getty Images)

## Exploding Lithium-Ion Battery Kills 2 in State’s 1st Battery Fire Death
 - [https://www.theepochtimes.com/world/exploding-lithium-ion-battery-kills-2-in-states-1st-battery-fire-death-5601512](https://www.theepochtimes.com/world/exploding-lithium-ion-battery-kills-2-in-states-1st-battery-fire-death-5601512)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T03:13:34+00:00

A technician unpacks a completely burned Lithium-ion car battery before its dismantling by the German recycling firm Accurec in Krefeld, Germany, November 16, 2017.  (REUTERS/Wolfgang Rattay/File Photo)

## Anthony Furey: An Important Lesson I Learned From Brian Mulroney
 - [https://www.theepochtimes.com/opinion/anthony-furey-an-important-lesson-i-learned-from-brian-mulroney-5601246](https://www.theepochtimes.com/opinion/anthony-furey-an-important-lesson-i-learned-from-brian-mulroney-5601246)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T02:28:34+00:00

Former Prime Minister Brian Mulroney leaves Parliament Hill in Ottawa on June 6, 2012.  (The Canadian Press/Adrian Wyld)

## Fired Winnipeg Scientist Involved in Gain-of-Function Research at Wuhan Lab, Where Canada Sent Virus Samples
 - [https://www.theepochtimes.com/world/fired-winnipeg-scientist-involved-in-gain-of-function-research-at-wuhan-lab-where-canada-sent-virus-samples-5601482](https://www.theepochtimes.com/world/fired-winnipeg-scientist-involved-in-gain-of-function-research-at-wuhan-lab-where-canada-sent-virus-samples-5601482)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T02:08:18+00:00

The Wuhan Institute of Virology in Wuhan, in China's central Hubei province, on February 3, 2021. (Hector Retamal/AFP via Getty Images)

## Australia’s ‘Destiny’: Prime Minister Says Nation’s Prosperity Lies in Southeast Asia
 - [https://www.theepochtimes.com/world/australias-destiny-prime-minister-says-nations-prosperity-lies-in-southeast-asia-5601494](https://www.theepochtimes.com/world/australias-destiny-prime-minister-says-nations-prosperity-lies-in-southeast-asia-5601494)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T02:07:12+00:00

Australian Prime Minister Anthony Albanese addresses the Leaders' Plenary during the 2024 ASEAN-Australia Special Summit at the Convention and Exhibition Centre in Melbourne, Australia on March 6, 2024. (Joel Carrett/Pool/AFP via Getty Images)

## Leaked Hacking Files Spur Concerns of China Weakening US for War
 - [https://www.theepochtimes.com/article/leaked-hacking-files-spur-concerns-of-china-weakening-us-for-war-5598768](https://www.theepochtimes.com/article/leaked-hacking-files-spur-concerns-of-china-weakening-us-for-war-5598768)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T01:59:55+00:00

(Illustration by The Epoch Times, Getty Images, Shutterstock)

## When It Comes to Terrorist Threats, the Feds Need to Call a Spade a Spade
 - [https://www.theepochtimes.com/opinion/when-it-comes-to-terrorist-threats-the-feds-need-to-call-a-spade-a-spade-5601179](https://www.theepochtimes.com/opinion/when-it-comes-to-terrorist-threats-the-feds-need-to-call-a-spade-a-spade-5601179)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T01:37:46+00:00

A police officer runs with his weapon drawn in Ottawa on Oct. 22, 2014, during an attack on Parliament Hill by Michael Zehaf Bibeau, who shot Cpl. Nathan Cirillo and injured a security guard before being shot dead by Parliament’s sergeant-at-arms. (The Canadian Press/Sean Kilpatrick)

## Qantas Fined $250,000 For Standing Down Worker Concerned With COVID-19
 - [https://www.theepochtimes.com/world/qantas-fined-250000-for-standing-down-worker-concerned-with-covid-19-post-5601460](https://www.theepochtimes.com/world/qantas-fined-250000-for-standing-down-worker-concerned-with-covid-19-post-5601460)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T01:33:36+00:00

A Boeing 787-9 Dreamliner from Qantas Air Lines is seen on the tarmac of LAX Los Angeles airport on May 11, 2019. (Daniel Slim/AFP via Getty Images)

## Victoria’s Offshore Wind Zone Slashed to One-Fifth of Original Size
 - [https://www.theepochtimes.com/world/victorias-offshore-wind-zone-slashed-to-one-fifth-of-original-size-5601368](https://www.theepochtimes.com/world/victorias-offshore-wind-zone-slashed-to-one-fifth-of-original-size-5601368)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T01:02:45+00:00

offshore wind farm infrastructure, a driver of clean renewable energy will be built n Victoria's new offshore wind zone. (John Moore/Getty Images)

## Canadian Economy to Remain Sluggish Through 2024: Budget Office
 - [https://www.theepochtimes.com/world/canadian-economy-to-remain-sluggish-through-2024-budget-office-5601442](https://www.theepochtimes.com/world/canadian-economy-to-remain-sluggish-through-2024-budget-office-5601442)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T00:52:23+00:00

Parliamentary Budget Officer Yves Giroux waits to appear before the Commons Finance committee on Parliament Hill in Ottawa on March 10, 2020. (The Canadian Press/Adrian Wyld)

## NZ Rugby Team to Apologise for Calling Government “Redneck”
 - [https://www.theepochtimes.com/world/nz-rugby-team-to-apologise-for-calling-government-redneck-5601432](https://www.theepochtimes.com/world/nz-rugby-team-to-apologise-for-calling-government-redneck-5601432)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T00:48:10+00:00

Grace Steinmetz of the Chiefs Manawa looks to fend off the tackled during the round one Super Rugby Aupiki match between Chiefs Manawa and Hurricanes Poua at FMG Stadium Waikato in Hamilton, New Zealand on March 2, 2024. (Michael Bradley/Getty Images)

## No Conviction Recorded After Man Attacks 71-Year-Old at Women’s Rights Rally
 - [https://www.theepochtimes.com/world/no-conviction-recorded-after-man-attacks-71-year-old-at-womens-rights-rally-5601393](https://www.theepochtimes.com/world/no-conviction-recorded-after-man-attacks-71-year-old-at-womens-rights-rally-5601393)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T00:29:58+00:00

Posie Parker (Kelly Jay Keen) speaks during a Standing for Women protest in Glasgow, Scotland, on Feb. 5, 2023. (Jeff J Mitchell/Getty Images)

## The Sound of Silence: Tinnitus on the Rise as 80 percent of Hearing Needs Unmet
 - [https://www.theepochtimes.com/world/the-sound-of-silence-tinnitus-on-the-rise-as-80-percent-of-hearing-needs-unmet-5601389](https://www.theepochtimes.com/world/the-sound-of-silence-tinnitus-on-the-rise-as-80-percent-of-hearing-needs-unmet-5601389)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T00:10:05+00:00

(Eric Nicholas/Shutterstock)

## CBSA Union President Decries ‘Two-Tiered’ Disciplinary System as ArriveCan Investigation Continues
 - [https://www.theepochtimes.com/world/cbsa-union-president-decries-two-tiered-disciplinary-system-as-arrivecan-investigation-continues-5601224](https://www.theepochtimes.com/world/cbsa-union-president-decries-two-tiered-disciplinary-system-as-arrivecan-investigation-continues-5601224)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-03-06T00:01:58+00:00

A Canada Border Services Agency (CBSA) patch is seen on a CBSA officer’s uniform in Calgary, Alberta, on Aug. 1, 2019. (Jeff Mcintosh/The Canadian Press)

