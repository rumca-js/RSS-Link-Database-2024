# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Oni już są w ćwierćfinale Ligi Mistrzów. Kto jeszcze powalczy o awans?
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/kto-zagra-w-cwiercfinale-druzyny-pewne-gry-w-1-4-finalu_sto10049852/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/kto-zagra-w-cwiercfinale-druzyny-pewne-gry-w-1-4-finalu_sto10049852/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T22:05:31+00:00

<img alt="Oni już są w ćwierćfinale Ligi Mistrzów. Kto jeszcze powalczy o awans?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lnqjdy-harry-kane-bayern-7808433/alternates/LANDSCAPE_1280" />
    Znamy już czterech ćwierćfinalistów rozgrywek. W następny wtorek i w środę kolejne spotkania.

## "Rękawice wysmarowane mydłem". Fatalny błąd Polaka w Lidze Mistrzów
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/blad-kamila-grabary-w-meczu-ligi-mistrzow-manchester-city-fc-kopenhaga_sto10051093/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/blad-kamila-grabary-w-meczu-ligi-mistrzow-manchester-city-fc-kopenhaga_sto10051093/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T20:39:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7q56z9-kamil-grabara-popelnil-fatalny-blad-w-meczu-ligi-mistrzow-7808350/alternates/LANDSCAPE_1280" />
    O tej bramce już jest głośno.

## Wieczór Grabary jak z koszmarów
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/real-madryt-rb-lipsk-wynik-na-zywo-i-relacja-live_sto10051051/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/real-madryt-rb-lipsk-wynik-na-zywo-i-relacja-live_sto10051051/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T20:11:00+00:00

<img alt="Wieczór Grabary jak z koszmarów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vz1r7f-kamil-grabara-i-erling-haaland-graja-ze-soba-w-18-finalu-ligi-mistrzow-7808331/alternates/LANDSCAPE_1280" />
    Wynik na żywo i relacja live w Eurosport.pl.

## Pytanie w "Milionerach" za 75 tysięcy złotych o światowe zasoby słodkiej wody
 - [https://tvn24.pl/toteraz/milionerzy-pytanie-o-swiatowe-zasoby-slodkiej-wody-za-75-tysiecy-zlotych-st7807969?source=rss](https://tvn24.pl/toteraz/milionerzy-pytanie-o-swiatowe-zasoby-slodkiej-wody-za-75-tysiecy-zlotych-st7807969?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T20:00:00+00:00

<img alt="Pytanie w " src="https://tvn24.pl/toteraz/cdn-zdjecie-shu76w-pytanie-w-milionerach-za-75-tysiecy-zlotych-o-swiatowe-zasoby-slodkiej-wody-7807987/alternates/LANDSCAPE_1280" />
    Odpowiadał pan Daniel Świątoniowski.

## Real pieczętuje awans. Przynajmniej taki ma plan
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/real-madryt-rb-lipsk-wynik-na-zywo-i-relacja-live_sto10050979/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/real-madryt-rb-lipsk-wynik-na-zywo-i-relacja-live_sto10050979/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T19:53:00+00:00

<img alt="Real pieczętuje awans. Przynajmniej taki ma plan" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f1kp9i-brahim-diaz-ouvre-le-score-pour-le-real-madrid-sur-la-pelouse-du-rb-leipzig-7808325/alternates/LANDSCAPE_1280" />
    Wynik na żywo i relacja live w Eurosport.pl.

## Błąd sprzed lat. Francuska biathlonistka niewpuszczona do USA
 - [https://eurosport.tvn24.pl/biathlon/salt-lake-city-ut/2023-2024/sophie-chauveau-nie-poleciala-na-zawody-pucharu-swiata_sto10050309/story.shtml?source=rss](https://eurosport.tvn24.pl/biathlon/salt-lake-city-ut/2023-2024/sophie-chauveau-nie-poleciala-na-zawody-pucharu-swiata_sto10050309/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T19:47:17+00:00

<img alt="Błąd sprzed lat. Francuska biathlonistka niewpuszczona do USA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nu0gda-sophie-chauveau-to-francuska-biathlonistka-7808318/alternates/LANDSCAPE_1280" />
    "To cios dla niej i rozczarowanie dla drużyny".

## "Byłem szczęśliwym pijakiem, ale już nim nie jestem"
 - [https://eurosport.tvn24.pl/pilka-nozna/paul-gascoigne-wciaz-walczy-z-nalogiem.-wywiad-z-bylym-pilkarzem_sto10050884/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/paul-gascoigne-wciaz-walczy-z-nalogiem.-wywiad-z-bylym-pilkarzem_sto10050884/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T19:41:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8g5shr-paul-gascoigne-w-2020-roku-7808311/alternates/LANDSCAPE_1280" />
    Paul Gascoigne się nie poddaje.

## Wielki pożar przy stadionie. Mecz drużyny reprezentanta Polski przełożony
 - [https://eurosport.tvn24.pl/pilka-nozna/championship/2023-2024/wielki-pozar-w-southampton.-mecz-druzyny-jana-bednarka-przelozony_sto10050961/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/championship/2023-2024/wielki-pozar-w-southampton.-mecz-druzyny-jana-bednarka-przelozony_sto10050961/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T18:44:19+00:00

<img alt="Wielki pożar przy stadionie. Mecz drużyny reprezentanta Polski przełożony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5whc9e-mecz-southampton-fc-z-preston-north-end-zostal-przelozony-z-powodu-pozaru-w-okolicy-stadionu-gospodarzy-7808246/alternates/LANDSCAPE_1280" />
    Ligowe spotkanie Southampton FC z Preston North End w środę się nie odbędzie.

## Powrót króla slalomu. Sensacyjne doniesienia już budzą kontrowersje
 - [https://eurosport.tvn24.pl/narciarstwo-alpejskie/solden/2023-2024/lucas-braathen-wraca-do-pucharu-swiata.-kiedy-oglosi-decyzje-kiedy-pierwszy-start_sto10050732/story.shtml?source=rss](https://eurosport.tvn24.pl/narciarstwo-alpejskie/solden/2023-2024/lucas-braathen-wraca-do-pucharu-swiata.-kiedy-oglosi-decyzje-kiedy-pierwszy-start_sto10050732/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T17:50:00+00:00

<img alt="Powrót króla slalomu. Sensacyjne doniesienia już budzą kontrowersje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iflsx9-norways-lucas-braathen-competes-in-the-first-run-of-the-mens-slalom-event-of-the-fis-alpine-ski-world-cup-in-adelboden-on-january-8-2023-7808133/alternates/LANDSCAPE_1280" />
    Decyzja w czwartek.

## "Instytucja zupełnie poobijana, zmasakrowana"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1808,S00E1808,481340?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-1808,S00E1808,481340?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T17:29:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qu95ki-julia-przylebska-i-tk-7808104/alternates/LANDSCAPE_1280" />
    Czym stał się Trybunał Konstytucyjny przez minione osiem lat i jakie są tego skutki? Materiał Arkadiusza Wierzuka.

## Z Kielc do Azji. Egzotyczny transfer byłego reprezentanta Polski
 - [https://eurosport.tvn24.pl/pilka-reczna/pawel-paczkowski-po-sezonie-odejdzie-z-industrii-kielce-do-japonskiego-klubu-toyota-auto-body-brave-_sto10050228/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/pawel-paczkowski-po-sezonie-odejdzie-z-industrii-kielce-do-japonskiego-klubu-toyota-auto-body-brave-_sto10050228/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T17:09:04+00:00

<img alt="Z Kielc do Azji. Egzotyczny transfer byłego reprezentanta Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qu6po0-pawel-paczkowski-to-byly-reprezentant-polski-7808132/alternates/LANDSCAPE_1280" />
    Paweł Paczkowski po zakończeniu trwającego sezonu odejdzie z Industrii Kielce. W środę ogłoszono, że rozgrywający podpisał kontrakt w dalekiej Japonii. Nowym pracodawcą Polaka będzie obecny lider tamtejszej ligi Toyota Auto Body Brave Kings.

## Leci na zawody na swój koszt. Działacze nie chcą "szastać pieniędzmi"
 - [https://eurosport.tvn24.pl/biathlon/salt-lake-city-ut/2023-2024/sebastian-samuelsson-sam-oplacil-bilet-w-klasie-biznes-na-zawody-pucharu-swiata_sto10050044/story.shtml?source=rss](https://eurosport.tvn24.pl/biathlon/salt-lake-city-ut/2023-2024/sebastian-samuelsson-sam-oplacil-bilet-w-klasie-biznes-na-zawody-pucharu-swiata_sto10050044/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T13:20:39+00:00

<img alt="Leci na zawody na swój koszt. Działacze nie chcą " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jfmumw-sebastian-samuelsson-to-dwukrotny-medalista-olimpijski-7807585/alternates/LANDSCAPE_1280" />
    Zawody PŚ w biathlonie po raz pierwszy w tym sezonie odbędą się za oceanem.

## Kontrowersyjne kaski pod lupą ekspertów
 - [https://eurosport.tvn24.pl/kolarstwo/kosmiczne-kaski-grupy-visma.-jakie-sa-ich-zalety-czy-spelniaja-przepisy-uci_sto10050136/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/kosmiczne-kaski-grupy-visma.-jakie-sa-ich-zalety-czy-spelniaja-przepisy-uci_sto10050136/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T12:57:00+00:00

<img alt="Kontrowersyjne kaski pod lupą ekspertów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pyeor1-grupa-visma-z-kontrowersyjnymi-kaskami-7807501/alternates/LANDSCAPE_1280" />
    Dla niektórych odrażające, dla innych niebezpieczne. Nie wiadomo na razie, czy będą mogły być stosowane.

## A2 zablokowana, na S7 utrudnienia
 - [https://tvn24.pl/lodz/trasa-a2-zablokowana-na-s7-utrudnienia-rolnicy-protestuja-tez-poza-stolica-objazdy-mapa-st7807295?source=rss](https://tvn24.pl/lodz/trasa-a2-zablokowana-na-s7-utrudnienia-rolnicy-protestuja-tez-poza-stolica-objazdy-mapa-st7807295?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T11:58:46+00:00

<img alt="A2 zablokowana, na S7 utrudnienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iaislx-a2-w-kierunku-poznania-rolnicy-protest-7807482/alternates/LANDSCAPE_1280" />
    Rolnicy protestują też poza Warszawą.

## "Jej serce stanęło na zawsze"
 - [https://eurosport.tvn24.pl/siatkowka/ruxandra-dumitrescu-nie-zyje.-siatkarka-reprezentacji-rumunii-i-grecji_sto10050196/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/ruxandra-dumitrescu-nie-zyje.-siatkarka-reprezentacji-rumunii-i-grecji_sto10050196/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T11:12:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yg3kib-ruxandra-dumitrescu-7807225/alternates/LANDSCAPE_1280" />
    Nie żyje była siatkarka.

## Trener Realu z zarzutami. "Prokuratura żąda więzienia"
 - [https://eurosport.tvn24.pl/pilka-nozna/lpf-primera-division/2024/carlo-ancelotti-jest-oskarzony-o-oszustwa-podatkowe.-prokuratura-zada-wiezienia_sto10050183/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/lpf-primera-division/2024/carlo-ancelotti-jest-oskarzony-o-oszustwa-podatkowe.-prokuratura-zada-wiezienia_sto10050183/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T10:38:20+00:00

<img alt="Trener Realu z zarzutami. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-557v27-carlo-ancelotti-7807106/alternates/LANDSCAPE_1280" />
    Carlo Ancelotti jest oskarżony o oszustwa podatkowe.

## Barcelona coraz bliższa powrotu do domu. Są kolejne wizualizacje
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/fc-barcelona-zaprezentowala-projekt-nowego-camp-nou.-powrot-coraz-blizej_sto10049394/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/fc-barcelona-zaprezentowala-projekt-nowego-camp-nou.-powrot-coraz-blizej_sto10049394/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T10:24:41+00:00

<img alt="Barcelona coraz bliższa powrotu do domu. Są kolejne wizualizacje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xz4ckv-fc-barcelona-przez-lata-grala-na-legendarnym-camp-nou-7807075/alternates/LANDSCAPE_1280" />
    Tak ma wyglądać nowe Camp Nou.

## Tąpnięcie w sprzedaży iPhone'ów na kluczowym rynku
 - [https://tvn24.pl/biznes/tech/apple-chiny-tapniecie-w-sprzedazy-iphoneow-st7806912?source=rss](https://tvn24.pl/biznes/tech/apple-chiny-tapniecie-w-sprzedazy-iphoneow-st7806912?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T10:16:55+00:00

<img alt="Tąpnięcie w sprzedaży iPhone'ów na kluczowym rynku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x03bqy-smartfon-smartfony-sklep-shutterstock_1051250048-7323725/alternates/LANDSCAPE_1280" />
    Pisze BBC.

## Nieśmiały powrót zimy
 - [https://tvn24.pl/tvnmeteo/pogoda/niesmialy-powrot-zimy-snieg-spadl-na-poludniu-kraju-st7806865?source=rss](https://tvn24.pl/tvnmeteo/pogoda/niesmialy-powrot-zimy-snieg-spadl-na-poludniu-kraju-st7806865?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T10:16:43+00:00

<img alt="Nieśmiały powrót zimy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ba1t0o-hala-gasienicowa-060324-7807003/alternates/LANDSCAPE_1280" />
     Śnieg spadł na południu kraju.

## Sochan antybohaterem. Wywołał awanturę
 - [https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/jeremy-sochan-starl-sie-z-rywalem-w-meczu-houston-rockets-san-antonio-spurs.-co-sie-stalo_sto10050120/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/nba/2023-2024/jeremy-sochan-starl-sie-z-rywalem-w-meczu-houston-rockets-san-antonio-spurs.-co-sie-stalo_sto10050120/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T10:06:33+00:00

<img alt="Sochan antybohaterem. Wywołał awanturę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-79fokp-jeremy-sochan-starl-sie-z-rywalem-w-meczu-houston-rockets-san-antonio-spurs-7807031/alternates/LANDSCAPE_1280" />
    W meczu z Houston Rockets.

## Niespodziewany problem po strzale Mbappe
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/liga-mistrzow.-kylian-mbappe-rozerwal-siatke-w-meczu-real-sociedad-psg_sto10050085/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/liga-mistrzow.-kylian-mbappe-rozerwal-siatke-w-meczu-real-sociedad-psg_sto10050085/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T09:36:13+00:00

<img alt="Niespodziewany problem po strzale Mbappe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8zu3ez-mbappe-rozerwal-siatke-7806907/alternates/LANDSCAPE_1280" />
    Trzeba było przerwać mecz Ligi Mistrzów.

## Świątek walczy o prestiżową nagrodę. Ma wyjątkowe wsparcie
 - [https://eurosport.tvn24.pl/tenis/iga-swiatek-powalczy-o-nagrode-laureus.-mikaela-shiffrin-wsparla-polke_sto10050060/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/iga-swiatek-powalczy-o-nagrode-laureus.-mikaela-shiffrin-wsparla-polke_sto10050060/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T09:08:33+00:00

<img alt="Świątek walczy o prestiżową nagrodę. Ma wyjątkowe wsparcie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k94how-mikaela-shiffrin-wsparla-ige-swiatek-7806782/alternates/LANDSCAPE_1280" />
    Polka nominowana została w kategorii "Sportsmenka roku".

## Gorące posiedzenie Sejmu. Oglądaj na żywo
 - [https://tvn24.pl/go/live,1/go3,93471?source=rss](https://tvn24.pl/go/live,1/go3,93471?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T09:04:46+00:00

<img alt="Gorące posiedzenie Sejmu. Oglądaj na żywo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-490s10-posiedzenie-sejmu-7806761/alternates/LANDSCAPE_1280" />
    W TVN24 i TVN24 GO.

## "Istnieje wiele niebezpieczeństw"
 - [https://eurosport.tvn24.pl/igrzyska-olimpijskie/paryz-2024/2024/ceremonie-otwarcia-zobaczy-znacznie-mniej-widzow-niz-planowano_sto10049792/story.shtml?source=rss](https://eurosport.tvn24.pl/igrzyska-olimpijskie/paryz-2024/2024/ceremonie-otwarcia-zobaczy-znacznie-mniej-widzow-niz-planowano_sto10049792/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T08:14:46+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-omwwpa-ceremonie-otwarcia-igrzysk-olimpijskich-w-paryzu-zobaczy-znacznie-mniej-widzow-niz-planowano-7806649/alternates/LANDSCAPE_1280" />
    Otwarcie igrzysk olimpijskich w Paryżu może zobaczyć znacznie mniej widzów.

## Linette poznała pierwszą rywalkę w Indian Wells
 - [https://eurosport.tvn24.pl/tenis/wta-indian-wells/2024/magda-linette-poznala-rywalke-w-pierwszej-rundzie-turnieju-wta-1000-w-indian-wells-2024.-zagra-z-tay_sto10050038/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-indian-wells/2024/magda-linette-poznala-rywalke-w-pierwszej-rundzie-turnieju-wta-1000-w-indian-wells-2024.-zagra-z-tay_sto10050038/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T06:44:13+00:00

<img alt="Linette poznała pierwszą rywalkę w Indian Wells" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1p385b-magda-linette-7806508/alternates/LANDSCAPE_1280" />
    Polka już wie, z kim przyjdzie jej zmierzyć się w pierwszej rundzie turnieju.

## Wielka rywalka Justyny Kowalczyk chce wrócić
 - [https://eurosport.tvn24.pl/biegi-narciarskie/mistrzostwa-swiata/2022-2023/therese-johaug-mysli-o-powrocie-do-biegow-narciarskich.-chcialaby-wystartowac-na-mistrzostwach-swiat_sto10049590/story.shtml?source=rss](https://eurosport.tvn24.pl/biegi-narciarskie/mistrzostwa-swiata/2022-2023/therese-johaug-mysli-o-powrocie-do-biegow-narciarskich.-chcialaby-wystartowac-na-mistrzostwach-swiat_sto10049590/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T06:37:01+00:00

<img alt="Wielka rywalka Justyny Kowalczyk chce wrócić" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ozmcjj-therese-johaug-7806503/alternates/LANDSCAPE_1280" />
    Therese Johaug stęskniła się za biegami narciarskimi.

## Ulga w Bayernie. "Zrobiliśmy ważny krok naprzód"
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/bayern-monachium-w-cwiercfinale.-thomas-mueller-o-awansie_sto10050033/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/bayern-monachium-w-cwiercfinale.-thomas-mueller-o-awansie_sto10050033/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T06:24:44+00:00

<img alt="Ulga w Bayernie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1olx3g-bayern-w-cwiercfinale-7806486/alternates/LANDSCAPE_1280" />
    Piłkarze z Monachium zagrają w ćwierćfinale Ligi Mistrzów.

## Świątek i Hurkacz rozbici w osiem minut
 - [https://eurosport.tvn24.pl/tenis/wta-indian-wells/2024/iga-swiatek-i-hubert-hurkacz-pokonani-w-osiem-minut-w-pokazowym-turnieju-tie-break-tens_sto10050026/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-indian-wells/2024/iga-swiatek-i-hubert-hurkacz-pokonani-w-osiem-minut-w-pokazowym-turnieju-tie-break-tens_sto10050026/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T05:50:14+00:00

<img alt="Świątek i Hurkacz rozbici w osiem minut" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uvtw3b-iga-swiatek-i-hubert-hurkacz-szybko-odpadli-w-tie-break-tens-7806460/alternates/LANDSCAPE_1280" />
    W pokazowym turnieju Tie Break Tens, który jest rozgrzewką przed Indian Wells.

## Wielkie wygrane i dwie małe niespodzianki
 - [https://tvn24.pl/swiat/wybory-w-usa-superwtorek-wyniki-donalda-trumpa-i-joe-bidena-st7806441?source=rss](https://tvn24.pl/swiat/wybory-w-usa-superwtorek-wyniki-donalda-trumpa-i-joe-bidena-st7806441?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-03-06T04:27:03+00:00

<img alt="Wielkie wygrane i dwie małe niespodzianki " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nosimi-superwtorek-w-usa-7806442/alternates/LANDSCAPE_1280" />
    Superwtorek w USA.

