# Source:CD-Action - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g, language:pl

## Inquisitor: Tajemnica kiepskiej gry
 - [https://www.youtube.com/watch?v=eUk_uSbIi8k](https://www.youtube.com/watch?v=eUk_uSbIi8k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g
 - date published: 2024-03-06T17:02:00+00:00

Mordimer Maderfaker wreszcie doczekał się własnej gry. Wyszedł kaszalot, czy niczego sobie produkcja? Jak przystało na opowieść o wampirze: mamy do czynienia z rzeczą wybitnie bladą. 

Koniecznie zobacz nas w innych miejscach:

Strona :: https://cdaction.pl/
Sklep :: https://sklep.cdaction.pl/
Instagram :: https://instagram.com/cdaction
Facebook :: http://fb.me/CDAction/
Twitter :: https://twitter.com/cdaction
Discord CD-Action :: https://discord.gg/9Aqf3Cjcxx
Kontakt :: youtube@cdaction.pl

Prowadzenie, scenariusz i montaż:

Kuba „SztywnyPatyk" Stolarz (http://twitter.com/sztywnypatyyk)

