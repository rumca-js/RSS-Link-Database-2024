# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## Linus Reads Really Mean Comments
 - [https://www.youtube.com/watch?v=WXV-zB3EfNw](https://www.youtube.com/watch?v=WXV-zB3EfNw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2024-03-06T18:00:38+00:00

Get your Laifen Wave electric toothbrush below and save 10%!
Laifen Website: https://bit.ly/48GQxUC
Amazon ABS $69.99: https://amzn.to/3wKq4bl
Amazon Aluminum Alloy $79.99: https://amzn.to/3Ihpogn
Amazon Stainless Steel $99.99: https://amzn.to/3TffVfE

Back at it with the mean comments eh? Perfect! We sat down several members of our staff to read and react to some of your YouTube comments. Some are nice, some are mean…. So join us for the ride! Be sure to leave more down below in case we ever want to do this again ;)

Discuss on the forum: https://linustechtips.com/topic/1561378-linus-reads-really-mean-comments/

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► EQUIPMENT WE USE TO FILM LTT: https://lmg.gg/LTTEquipment
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset

FOLLO

