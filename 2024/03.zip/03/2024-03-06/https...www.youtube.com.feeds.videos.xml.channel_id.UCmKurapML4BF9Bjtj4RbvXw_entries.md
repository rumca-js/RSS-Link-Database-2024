# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## Long, Long Ago - Jon Schmidt (Bonus Tracks Album) The Piano Guys
 - [https://www.youtube.com/watch?v=wnZ5mh9bRJM](https://www.youtube.com/watch?v=wnZ5mh9bRJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2024-03-06T13:00:54+00:00

Dive into a gentle, nostalgic experience with Jon Schmidt's cover of 'Long Long Ago.' In this heartfelt piano rendition, Jon brings a fresh touch to the classic melody, inviting listeners on a soothing journey through memory and melody. His approach combines a simple reverence for the original with a personal touch, making each note a soft echo of the past. Ideal for moments of reflection or a peaceful break, this version of 'Long Long Ago' is a humble tribute to the timeless power of music to stir emotions and memories. Join us in appreciating the beauty of simplicity and the warmth of nostalgia. If you enjoy these serene musical moments, please consider liking, sharing, and subscribing. 🎹🌿

Download the Album "Bonus Tracks" https://thepianoguys.com/products/bonus-tracks

👉 Subscribe to our channel https://bit.ly/2XH4GCF for more heartwarming melodies that capture the spirit of the season. 

WE’RE ON TOUR: https://smarturl.it/the10tour 
The Piano Guys Christmas Playlist: htt

