# Source:Goonhammer, URL:https://www.goonhammer.com/feed, language:en-GB

## War of the North – A Hits and Crits ASOIAF: TMG Season 4 Event
 - [https://www.goonhammer.com/war-of-the-north-a-hits-and-crits-asoiaf-tmg-season-4-event](https://www.goonhammer.com/war-of-the-north-a-hits-and-crits-asoiaf-tmg-season-4-event)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-06T19:00:20+00:00

War of the North, the first big ASOIAF: TMG event, took place in Hamburg on February 10th-11th and was hosted by Hits and Crits. We sat down with Chris and Dennis from the Hits and Crits Team and discussed their first big event, as well as the top lists and the impact Season 4 has [&#8230;]

## The Goonhammer Hot Take: Dark Angels Points Update
 - [https://www.goonhammer.com/the-goonhammer-hot-take-dark-angels-points-update](https://www.goonhammer.com/the-goonhammer-hot-take-dark-angels-points-update)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-06T17:18:58+00:00

We take a look at the new points update for Dark Angels - What changed and what it means for the faction.

## No Joker Puns Here: Malifaux at Captaincon 2024 (Part II)
 - [https://www.goonhammer.com/no-joker-puns-here-malifaux-at-captaincon-2024-part-ii](https://www.goonhammer.com/no-joker-puns-here-malifaux-at-captaincon-2024-part-ii)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-06T16:00:52+00:00

Last time, we experienced the thrills and chills of the third annual Malifaux Content Creators&#8217; Invitational. I achieved my lifelong dream of taking a game off of Landon in real life, scored another nifty MCCI glass, and made everyone thoroughly sick of Mah Tucket.&#160; But Saturday, the real challenge began. The Booty and Plunder open [&#8230;]

## Marvel Crisis Protocol – Iceman & Shadowcat Review
 - [https://www.goonhammer.com/marvel-crisis-protocol-iceman-shadowcat-review](https://www.goonhammer.com/marvel-crisis-protocol-iceman-shadowcat-review)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-06T15:00:41+00:00

Who is Iceman? Iceman (Bobby Drake) is one of the original five X-Men, debuting alongside the other four in X-Men #1 (1963). He’s been a constant fixture of the team ever since, with only brief periods away when he was a member of The Champions, The Defenders, and a founding member of X-Factor. Over the [&#8230;]

## Competitive Innovations in the Mortal Realms – Everything’s Bigger in Texas
 - [https://www.goonhammer.com/competitive-innovations-in-the-mortal-realms-everythings-bigger-in-texas](https://www.goonhammer.com/competitive-innovations-in-the-mortal-realms-everythings-bigger-in-texas)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-06T14:27:27+00:00

This week we&#8217;re going across North America, with a super major down in Texas the famous Lone Star Grand Tournament, and then two events in central Canada. The effects of the Battlescroll are still being felt with some surprise new entries appearing on the block that are getting a second shot at life. The Lone [&#8230;]

## Competitive Innovations in 10th: Dressed for Success pt.1
 - [https://www.goonhammer.com/competitive-innovations-in-10th-dressed-for-success-pt-1](https://www.goonhammer.com/competitive-innovations-in-10th-dressed-for-success-pt-1)
 - RSS feed: https://www.goonhammer.com/feed
 - date published: 2024-03-06T13:00:23+00:00

The twists and turns of the metagame continue unabated this week, as Necrons get marginally barged back into their tombs by a triumvirate of snappily-dressed factions. Whether it&#8217;s glorious golden armour, a Nemesis Dreadknight or just a straight-up Gundam, going hard on heavy pressure pieces can be enough to overwhelm the damage output of some [&#8230;]

