# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## "Zauważyliśmy zdarzenie". Fiskus rozsyła "listy behawioralne"
 - [https://www.money.pl/podatki/zauwazylismy-zdarzenie-fiskus-rozsyla-listy-behawioralne-7003142623656608a.html](https://www.money.pl/podatki/zauwazylismy-zdarzenie-fiskus-rozsyla-listy-behawioralne-7003142623656608a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T19:42:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d6ad04e7-d057-4a50-a220-5e786fb12ea8" width="308" /> Niektórzy Polacy handlujący w sieci czy wynajmujący mieszkania otrzymują nietypowe listy od skarbówki. "Zauważyliśmy zdarzenie, które wywołuje skutki podatkowe" – można w nich przeczytać. Są to "listy behawioralne". Prawnik tłumaczy, jak na nie reagować i czy jest się czego bać.

## Kolejna obietnica po nowemu. Rząd zmienia zasady przyznawania "babciowego"
 - [https://www.money.pl/gospodarka/kolejna-obietnica-po-nowemu-rzad-zmienia-zasady-przyznawania-babciowego-7003111301835488a.html](https://www.money.pl/gospodarka/kolejna-obietnica-po-nowemu-rzad-zmienia-zasady-przyznawania-babciowego-7003111301835488a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T17:21:35+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bcbba34d-056f-4c50-9620-8b6c15859ea1" width="308" /> "Babciowe" to jeden z flagowych pomysłów Koalicji Obywatelskiej. To nowe świadczenie, które miało być przyznawane matkom wracającym do pracy tuż po urodzeniu dziecka. Jednak będzie trudniej je otrzymać. Trzeba będzie spełnić dodatkowy warunek.

## Fed wysyła sygnał. Ważne słowa Jerome Powella w sprawie stóp procentowych
 - [https://www.money.pl/banki/fed-wysyla-sygnal-wazne-slowa-jerome-powella-w-sprawie-stop-procentowych-7003093575244448a.html](https://www.money.pl/banki/fed-wysyla-sygnal-wazne-slowa-jerome-powella-w-sprawie-stop-procentowych-7003093575244448a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T16:32:59+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/df9fb7b6-8edb-47df-b92d-f87b6dee1d5b" width="308" /> Dalszy postęp w obniżaniu inflacji w Stanach Zjednoczonych. Mimo to Rezerwa Federalna, czyli bank centralny, spodziewa się obniżki stóp procentowych jeszcze w tym roku – podał szef Fed Jerome Powell, cytowany przez Agencję Reutera.

## Państwowy gigant znów bez sternika. Dotychczasowy szybko rezygnuje
 - [https://www.money.pl/gielda/panstwowy-gigant-znow-bez-sternika-dotychczasowy-szybko-rezygnuje-7003078136982240a.html](https://www.money.pl/gielda/panstwowy-gigant-znow-bez-sternika-dotychczasowy-szybko-rezygnuje-7003078136982240a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T14:56:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f0354a9d-bb2b-4142-a00b-359288796a85" width="308" /> KGHM Polska Miedź znów pozostaje bez szefa. Zbigniew Bryja, dotychczasowy p.o. prezesa, w środę złożył rezygnację. W dokumencie zrezygnował także z zasiadania w zarządzie, jak i w radzie nadzorczej spółki. Firma do 28 lutego czekała na wnioski w konkursie mającym wyłonić nowe władze.

## Rolnicy protestują przed Sejmem. Dwóch z nich miało wtargnąć na teren
 - [https://www.money.pl/gospodarka/rolnicy-protestuja-przed-sejmem-dwoch-z-nich-mialo-wtargnac-na-teren-7003062284704416a.html](https://www.money.pl/gospodarka/rolnicy-protestuja-przed-sejmem-dwoch-z-nich-mialo-wtargnac-na-teren-7003062284704416a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T14:04:02+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/907ce5cc-1786-4c84-9663-e9b0817b3416" width="308" /> Rolnicy protestują w Warszawie przed Sejmem. Dwóch z nich miało wtargnąć na teren parlamentu – podał dziennikarz portalu interia.pl i opublikował w mediach społecznościowych filmik z tego incydentu. Doszło też do starć ze służbami porządkowymi oddzielającymi protest od Sejmu.

## Ofensywa PiS ws. VAT na żywność. Mają apel do Marszałka Hołowni
 - [https://www.money.pl/podatki/ofensywa-pis-ws-vat-na-zywnosc-maja-apel-do-marszalka-holowni-7003052707633888a.html](https://www.money.pl/podatki/ofensywa-pis-ws-vat-na-zywnosc-maja-apel-do-marszalka-holowni-7003052707633888a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T13:12:44+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/67c49e21-3fcd-4ab0-82ba-25cf0434b887" width="308" /> Posłowie PiS zaapelowali w środę do marszałka Sejmu Szymona Hołowni o "odmrożenie" ich projektu dotyczącego przedłużenia zerowej stawki VAT na żywność. Jest to reakcja na słowa premiera Donalda Tuska, który wskazał, że "mogłaby wrócić 5 proc. stawka".

## Wakacje kredytowe po nowemu. Oto kto skorzysta z pomocy
 - [https://www.money.pl/banki/wakacje-kredytowe-po-nowemu-oto-kto-skorzysta-z-pomocy-7003038242757280a.html](https://www.money.pl/banki/wakacje-kredytowe-po-nowemu-oto-kto-skorzysta-z-pomocy-7003038242757280a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T12:48:53+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/37eda982-7981-4e93-96ba-9ed9983a83ac" width="308" /> Rząd przyjął we wtorek projekt ustawy o wakacjach kredytowych. W porównaniu z poprzednią ustawą nie wszyscy będą mogli skorzystać z pomocy. Jak jednak wynika z analizy HRE Investment Trust, z wakacji kredytowych skorzystają posiadacze około 500 tysięcy hipotek.

## KE wycofuje się z Zielonego ładu w rolnictwie
 - [https://www.money.pl/gospodarka/ke-wycofuje-sie-z-zielonego-ladu-w-rolnictwie-7003041073506976a.html](https://www.money.pl/gospodarka/ke-wycofuje-sie-z-zielonego-ladu-w-rolnictwie-7003041073506976a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T12:09:09+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/60b3bd40-f9ab-442e-a2b4-bb37bd01e838" width="308" /> Komisja Europejska przedstawi w przyszłym tygodniu nowe propozycje legislacyjne wychodzące naprzeciw postulatom protestujących rolników - informuje RMF FM. - Będzie propozycja bardzo dużego zmniejszenia obciążeń dla rolników – zapowiada komisarz ds. rolnictwa Janusz Wojciechowski w rozmowie z dziennikarką RMF FM w Brukseli.

## Gazprom pozwał Orlen i Europol Gaz
 - [https://www.money.pl/gospodarka/gazprom-pozwal-orlen-i-europol-gaz-7003033439775392a.html](https://www.money.pl/gospodarka/gazprom-pozwal-orlen-i-europol-gaz-7003033439775392a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T12:05:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b88535d8-1f66-42a9-876a-fe3ff7232664" width="308" /> Pozew Gazpromu przeciwko spółkom Orlen i Europol Gaz, które są właścicielem polskiego odcinka gazociągu Jamał-Europa, wpłynął do sądu arbitrażowego w Petersburgu - informuje "Rzeczpospolita".

## Fuzja Orlenu z Lotosem. ABW zabezpiecza dokumenty
 - [https://www.money.pl/gospodarka/fuzja-orlenu-z-lotosem-abw-zabezpiecza-dokumenty-7003025660951264a.html](https://www.money.pl/gospodarka/fuzja-orlenu-z-lotosem-abw-zabezpiecza-dokumenty-7003025660951264a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T11:13:41+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/87764544-06ac-4ec7-b427-d725ba25d62f" width="308" /> W biurach Orlenu w Płocku i w Warszawie, a także na terenie Gdańska funkcjonariusze ABW prowadzą w środę czynności związane z zabezpieczaniem materiału dowodowego w sprawie połączenia Orlenu z Grupą Lotos - poinformowała PAP zastępca prokuratora okręgowego w Płocku Monika Mieczykowska.

## Zboże z Ukrainy zalało Polskę. GUS rozwiewa wątpliwości
 - [https://www.money.pl/gospodarka/zboze-z-ukrainy-zalalo-polske-gus-rozwiewa-watpliwosci-7003005472221856a.html](https://www.money.pl/gospodarka/zboze-z-ukrainy-zalalo-polske-gus-rozwiewa-watpliwosci-7003005472221856a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T11:06:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/37f8674d-cc72-4075-b781-51e0ee5d640f" width="308" /> Napływ zboża z Ukrainy, to jeden z powodów, dlaczego polscy rolnicy wyszli na ulice. Główny Urząd Statystyczny przekazał informacje dotyczące importu produktów rolnych z Ukrainy. Jak się okazuje, Polska w 2022 roku została zalana zbożem zza wschodniej granicy.

## Wydano miliony na pikniki Lasów Państwowych. Ponad połowa w jednym okręgu wyborczym
 - [https://www.money.pl/gospodarka/wydano-miliony-na-pikniki-lasow-panstwowych-ponad-polowa-w-jednym-okregu-wyborczym-7003016221518560a.html](https://www.money.pl/gospodarka/wydano-miliony-na-pikniki-lasow-panstwowych-ponad-polowa-w-jednym-okregu-wyborczym-7003016221518560a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T10:50:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/104c96f8-beee-4163-a305-e0d422e12193" width="308" /> Niemal 3 mln zł - tyle kosztowało 31 pikników Lasów Państwowych "Drewno – surowiec wszech czasów". Ponad połowa z nich odbyła się w miejscowościach powiatów tarnogórskiego i gliwickiego, okręgu wyborczym Józefa Kubicy, byłego dyrektora generalnego Lasów Państwowych i kandydata z listy PiS do sejmu w ostatnich wyborach - informuje serwis gwarek.com.pl.

## Ukraina chce złagodzić spór z Polską. Stawia warunek
 - [https://www.money.pl/gospodarka/ukraina-chce-zlagodzic-spor-z-polska-stawia-warunek-7002990004181696a.html](https://www.money.pl/gospodarka/ukraina-chce-zlagodzic-spor-z-polska-stawia-warunek-7002990004181696a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T09:16:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/06df6656-b9d6-4957-9b4b-7cd85dba10c9" width="308" /> W Polsce trwa strajk rolników, którzy protestują m.in. przeciwko importowi zboża z Ukrainy. To doprowadziło do osłabienia relacji pomiędzy Warszawą a Kijowem. Jak jednak wskazał ukraiński wiceminister gospodarki Taras Kaczka, są gotowi czasowo zaakceptować ograniczenia w handlu z Unią Europejską.

## Kadrowy chaos w Lasach Państwowych. Minister się tłumaczy
 - [https://www.money.pl/gospodarka/kadrowy-chaos-w-lasach-panstwowych-minister-sie-tlumaczy-7002983337118368a.html](https://www.money.pl/gospodarka/kadrowy-chaos-w-lasach-panstwowych-minister-sie-tlumaczy-7002983337118368a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T08:39:51+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5d6cad0a-27fe-4378-b3ec-8f9a8d154939" width="308" /> Jan Tabor został zastępcą dyrektora  Biura Urządzania Lasu i Geodezji Leśnej. Spadł na cztery łapy.  Jan Tabor był drugą osobą w Lasach Państwowych za PiS,  współdecydował o wszystkim, co się w tym mrocznych czasach działo w lasach - piszą aktywiści z Nasze Lasy. Minister już odpowiedziała na zarzuty.

## Chińska gospodarka to studnia bez dna? Pekin pompuje w nią biliony. Oto efekty
 - [https://www.money.pl/pieniadze/chinska-gospodarka-to-studnia-bez-dna-pekin-pompuje-w-nia-biliony-oto-efekty-7002983087164064a.html](https://www.money.pl/pieniadze/chinska-gospodarka-to-studnia-bez-dna-pekin-pompuje-w-nia-biliony-oto-efekty-7002983087164064a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T08:35:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/967f6bc3-f9e2-4463-a122-b2a1bba5c9f5" width="308" /> Chiny, które przez lata napędzały światową gospodarkę, wciąż mają spore kłopoty. Zmagają się z konsekwencjami wojny handlowej z USA, zachwianiem rynku nieruchomości, spadkiem konsumpcji. Pekin robi wiele, by pobudzić gospodarkę. Co osiągnął?  O szczegółach czytamy w "Obserwatorze Finansowym".

## Największe banki w Polsce w wielkich opałach. W grę wchodzą wielomilionowe kary
 - [https://www.money.pl/banki/najwieksze-banki-w-polsce-w-wielkich-opalach-w-gre-wchodza-wielomilionowe-kary-7002965275605600a.html](https://www.money.pl/banki/najwieksze-banki-w-polsce-w-wielkich-opalach-w-gre-wchodza-wielomilionowe-kary-7002965275605600a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T08:10:51+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7cc6b46c-fab3-4a90-a200-43ba3f2be8b0" width="308" /> Komisja Nadzoru Finansowego wszczęła postępowania wobec największych banków. Sprawa może zakończyć się nałożeniem wielomilionowych kar.

## Niemieckie media grzmią o inwestycji w Polsce. "To błąd"
 - [https://www.money.pl/gospodarka/niemieckie-media-grzmia-o-inwestycji-w-polsce-to-blad-7002973084531264a.html](https://www.money.pl/gospodarka/niemieckie-media-grzmia-o-inwestycji-w-polsce-to-blad-7002973084531264a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T08:09:38+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2ac97977-b09d-4966-8713-83cc38918135" width="308" /> Berliński dziennik "Tagesspiegel" pisze o przeniesieniu przez niemiecką firmę Miele produkcji do Polski. "Tradycyjne niemieckie firmy przenoszone za granicę,  to błąd" - pisze niemiecki dziennik.

## Kursy walut 06.03.2024. Środowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-06-03-2024-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-7002953205115456a.html](https://www.money.pl/pieniadze/kursy-walut-06-03-2024-srodowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-7002953205115456a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T06:22:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/dcbc9ed1-8f1b-4ecb-81ba-721d559c5d6c" width="308" /> Kursy walut - 06.03.2024. W środę za jednego dolara (USD) zapłacimy 3,97 zł. Cena jednego funta szterlinga (GBP) to 5,04 zł, a franka szwajcarskiego (CHF) 4,49 zł. Z kolei euro (EUR) możemy zakupić za 4,31 zł.

## Kwota wolna od podatku. "Pora wywiązać się z obietnic"
 - [https://www.money.pl/podatki/kwota-wolna-od-podatku-pora-wywiazac-sie-z-obietnic-7002949156944480a.html](https://www.money.pl/podatki/kwota-wolna-od-podatku-pora-wywiazac-sie-z-obietnic-7002949156944480a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T06:21:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8a3b12cb-7d05-4ca8-b0be-34a3522e6e3d" width="308" /> Wszystko wskazuje na to, że Donald Tusk ogłosi pomysł na podwyżkę kwoty wolnej od podatku w ramach podsumowania 100 dni rządu. Była to najważniejsza obietnica Koalicji Obywatelskiej w kampanii wyborczej.

## Zmiana kwoty wolnej od podatku. "Pora wywiązać się z obietnic"
 - [https://www.money.pl/podatki/zmiana-kwoty-wolnej-od-podatku-pora-wywiazac-sie-z-obietnic-7002949156944480a.html](https://www.money.pl/podatki/zmiana-kwoty-wolnej-od-podatku-pora-wywiazac-sie-z-obietnic-7002949156944480a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T06:21:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8a3b12cb-7d05-4ca8-b0be-34a3522e6e3d" width="308" /> Wszystko wskazuje na to, że Donald Tusk ogłosi pomysł na podwyżkę kwoty wolnej od podatku w ramach podsumowania 100 dni rządu. Była to najważniejsza obietnica Koalicji Obywatelskiej w kampanii wyborczej.

## Rząd szykuje kluczową zmianę dla przedsiębiorców. Zależeć będzie od niej także składka zdrowotna
 - [https://www.money.pl/podatki/rzad-szykuje-kluczowa-zmiane-dla-przedsiebiorcow-zalezec-bedzie-od-niej-takze-skladka-zdrowotna-7002951203142240a.html](https://www.money.pl/podatki/rzad-szykuje-kluczowa-zmiane-dla-przedsiebiorcow-zalezec-bedzie-od-niej-takze-skladka-zdrowotna-7002951203142240a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T06:14:11+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/095bce04-df3c-4aba-a320-bc195c240cf6" width="308" /> Ruszyły prace nad kasowym PIT. "Rzeczpospolita" podkreśla, że jeśli przedsiębiorca wybierze kasowe rozliczenie i nie dostanie pieniędzy od kontrahenta, podatek zapłaci dopiero po dwóch latach, a ulga będzie też na składkę zdrowotną.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 06.03.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-06-03-2024-7002950949894720a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-06-03-2024-7002950949894720a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T06:00:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 06.03.2024. W środę za jedno euro (EUR) trzeba zapłacić 4.3107 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 06.03.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-06-03-2024-7002950956653152a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-06-03-2024-7002950956653152a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T06:00:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 06.03.2024. W środę za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.0449 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 06.03.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-06-03-2024-7002950948182592a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-06-03-2024-7002950948182592a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T06:00:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 06.03.2024. W środę za jednego franka (CHF) trzeba zapłacić 4.4899 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 06.03.2024
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-06-03-2024-7002950934190688a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-06-03-2024-7002950934190688a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T06:00:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 06.03.2024. W środę za jednego dolara (USD) trzeba zapłacić 3.9706 zł.

## Obajtek i jego prawa ręka. Ujawniają jak pieniądze Orlenu płynęły do ludzi związanych z PiS
 - [https://www.money.pl/gospodarka/obajtek-i-jego-prawa-reka-ujawniaja-jak-pieniadze-orlenu-plynely-do-ludzi-zwiazanych-z-pis-7002944574823008a.html](https://www.money.pl/gospodarka/obajtek-i-jego-prawa-reka-ujawniaja-jak-pieniadze-orlenu-plynely-do-ludzi-zwiazanych-z-pis-7002944574823008a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T05:55:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cb6aadad-ed49-4096-b6f9-8a7b9aa87003" width="308" /> Onet od kilku dni opisuje  kulisy operacji podsłuchiwania rozmów byłego prezesa Orlenu Daniela Obajtka. Teraz portal ujawnia, że Adam Burak, prawa ręka Obajtka i członek zarządu Orlenu  ds. marketingu i komunikacji "stał za stworzeniem całego systemu kierowania strumienia pieniędzy ze spółek Skarbu Państwa do zaufanych biznesmenów".

## Kołodziejczak uderza w koncerny tytoniowe. Podaje liczby
 - [https://www.money.pl/gospodarka/kolodziejczak-uderza-w-koncerny-tytoniowe-podaje-liczby-7002941765753440a.html](https://www.money.pl/gospodarka/kolodziejczak-uderza-w-koncerny-tytoniowe-podaje-liczby-7002941765753440a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-03-06T05:30:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c88b5f25-52d6-4498-bebc-56168e750017" width="308" /> W Polsce papierosy produkują cztery koncerny tytoniowe. Firmy w większym stopniu powinny wykorzystywać polski surowiec. Jedynie 1/8 polskiego tytoniu jest przerabiana w Polsce, reszta pochodzi z importu - poinformował  wiceminister rolnictwa Michał Kołodziejczak.

