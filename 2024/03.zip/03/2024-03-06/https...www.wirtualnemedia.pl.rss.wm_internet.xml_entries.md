# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Shoper kupuje resztę platformę e-commerce’owej
 - [https://www.wirtualnemedia.pl/artykul/shoper-platforma-e-commerce-apilo](https://www.wirtualnemedia.pl/artykul/shoper-platforma-e-commerce-apilo)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-06T17:11:50.420263+00:00

Firma Shoper przejęła pozostałe 20 proc. udziałów spółki Apilo do zarządzania sprzedażą internetową. Cena wyniosła 2,4 mln zł plus maksymalnie 8 mln zł w ramach tzw. earn out.

## Netflix zamówił drugi sezon serialu „1670”. Kiedy premiera?
 - [https://www.wirtualnemedia.pl/artykul/netflix-zamowil-drugi-sezon-1670-kiedy-premiera-co-sie-wydarzy-bartlomiej-topa-jan-pawel-adamczycha](https://www.wirtualnemedia.pl/artykul/netflix-zamowil-drugi-sezon-1670-kiedy-premiera-co-sie-wydarzy-bartlomiej-topa-jan-pawel-adamczycha)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-06T16:07:59.124460+00:00

Netflix oficjalnie potwierdził, że powstanie drugi sezon serialu „1670”, który trafił do serwisu pod koniec ubiegłego roku. Ruszyły już prace nad kolejnym rozdziałem historii mieszkańców Adamczychy, w tym Jana Pawła. Premiera drugiego sezonu zaplanowana jest na 2025 r.

## W dobie deepfejków przyszłość mediów społecznościowych jest pod znakiem zapytania
 - [https://www.wirtualnemedia.pl/artykul/deepfejk-koniec-media-spolecznosciowe](https://www.wirtualnemedia.pl/artykul/deepfejk-koniec-media-spolecznosciowe)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-06T06:28:45.947887+00:00

Z powodu deepfejków i fake newsów coraz mniej możemy ufać temu, co jest zamieszczone w sieci. Ludzie wrócą więc do kontaktów osobistych. W tej sytuacji przyszłość mediów społecznościowych stoi pod znakiem zapytania - uważa ekspert od AI dr Tomasz Michalak z IDEAS NCBR.

## TVP zamyka kanały z archiwaliami. „Audycje mediów publicznych powinny być bezpłatne”
 - [https://www.wirtualnemedia.pl/artykul/tvp-koniec-youtube-kanaly](https://www.wirtualnemedia.pl/artykul/tvp-koniec-youtube-kanaly)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-06T05:22:43.683733+00:00

Telewizja Polska w ostatnim czasie doprowadziła do zamknięcia kilku kanałów na YouTube z jej archiwalnymi programami. Nadawca publiczny tłumaczy takie działania przysługującymi mu prawami autorskimi. Byli prezesi TVP w rozmowie z Wirtualnemedia.pl przekonują, że przynajmniej część treści powinna być udostępniana bezpłatnie.

## Powstaje kodeks influencer marketingu
 - [https://www.wirtualnemedia.pl/artykul/kodeks-influencer-marketing](https://www.wirtualnemedia.pl/artykul/kodeks-influencer-marketing)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-06T05:22:43.668001+00:00

Związek Pracodawców Branży Internetowej IAB Polska oraz IAA Polska Międzynarodowe Stowarzyszenie Reklamy rozpoczęły współpracę, mającą na celu wypracowanie i wprowadzenie standardów i edukacji rynku w kontekście influencer marketingu.

## Michalik analizuje z prawnikami słowa Stanowskiego. "Tak robią przemocowcy"
 - [https://www.wirtualnemedia.pl/artykul/krzysztof-stanowski-pozew-eliza-michalik](https://www.wirtualnemedia.pl/artykul/krzysztof-stanowski-pozew-eliza-michalik)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-06T05:22:43.653399+00:00

Eliza Michalik przyznała w nagraniu na swoim youtubowym kanale, że analizuje z prawnikami wypowiedź Krzysztofa Stanowskiego. - Teksty typu „jesteś pier***” to typowe teksty przemocowca, które słyszy każda kobieta, która doznała przemocy psychicznej. To jest penalizowane w Kodeksie Karnym i Kodeksie Cywilnym. Nie chcę reagować pod wpływem emocji, a rozmów z prawnikami - powiedziała dziennikarka.

## Piłkarski program Kanału Zero traci widzów. Przegrywa z Kanałem Sportowym
 - [https://www.wirtualnemedia.pl/artykul/kanal-zero-youtube-program-kanal-sportowy](https://www.wirtualnemedia.pl/artykul/kanal-zero-youtube-program-kanal-sportowy)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-06T05:22:43.638697+00:00

Kanał Zero emituje od swojego startu program piłkarski „Zero do Zera”, który początkowo miał więcej wyświetleń niż „Moc Futbolu” Kanału Sportowego, ale ostatnio zaczął przegrywać pod względem liczby odsłon.

## Spotify reaguje na słowa ministra kultury. Sugeruje podwyżkę cen
 - [https://www.wirtualnemedia.pl/artykul/spotify-podwyzka-ceny](https://www.wirtualnemedia.pl/artykul/spotify-podwyzka-ceny)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-06T05:22:43.623881+00:00

Platforma streamingowa Spotify odniosła się do zapowiedzi ministra kultury Bartłomieja Sienkiewicza, że na mocy nowelizacji prawa autorskie tantiemy będą też płacić wydawcy internetowi. Koncern tłumaczy, że „nie jest w stanie wchłonąć dodatkowych kosztów podwójnej płatności”, sugerując podwyżkę cen dla użytkowników.

## Światowa awaria Facebooka i Instagrama. "W czasie awarii mediów społecznościowych czekajmy na jej usunięcie"
 - [https://www.wirtualnemedia.pl/artykul/awaria-facebook-instagram-co-robic-jak-odzyskac-konto](https://www.wirtualnemedia.pl/artykul/awaria-facebook-instagram-co-robic-jak-odzyskac-konto)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-03-06T05:22:43.606198+00:00

W czasie awarii mediów społecznościowych czekajmy na jej usunięcie; nie działajmy pochopnie i włączmy uwierzytelnianie dwuskładnikowe - radzi inżynier europejskiego dostawcy rozwiązań do ochrony sieci Stormshield z grupy Airbusa, Aleksander Kostuch.

