# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Mężczyzna z Niemiec miał zaszczepić się 217 razy. Lekarze nie dowierzają
 - [https://www.polsatnews.pl/wiadomosc/2024-03-06/mezczyzna-z-niemiec-mial-zaszczepic-sie-217-razy-lekarze-nie-dowierzaja](https://www.polsatnews.pl/wiadomosc/2024-03-06/mezczyzna-z-niemiec-mial-zaszczepic-sie-217-razy-lekarze-nie-dowierzaja)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-03-06T20:38:00+00:00

62-letni obywatel Niemiec miał z powodów prywatnych otrzymać 217 szczepionek przeciwko Covid-19 w przeciągu 29 miesięcy. Naukowcy postanowili zbadać ewentualne skutki uboczne lub oznaki zakażenia wirusem.

## Donald Trump bez konkurencji. Nikki Haley wycofuje się z wyścigu
 - [https://www.polsatnews.pl/wiadomosc/2024-03-06/donald-trump-bez-konkurencji-nikki-haley-wycofuje-sie-z-wyscigu](https://www.polsatnews.pl/wiadomosc/2024-03-06/donald-trump-bez-konkurencji-nikki-haley-wycofuje-sie-z-wyscigu)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-03-06T15:27:00+00:00

Nikki Haley, jedyna pozostała konkurentka Donalda Trumpa w rywalizacji o nominację Partii Republikańskiej w wyborach prezydenckich w USA, w środę ogłosiła wycofanie się z wyścigu. Zawieszenie swojej kampanii ogłosiła dzień po serii przegranych prawyborów.

## Problemy zdrowotne papieża. Na audiencji generalnej nie przeczytał katechezy
 - [https://www.polsatnews.pl/wiadomosc/2024-03-06/problemy-zdrowotne-papieza-na-audiencji-generalnej-nie-przeczytal-katechezy](https://www.polsatnews.pl/wiadomosc/2024-03-06/problemy-zdrowotne-papieza-na-audiencji-generalnej-nie-przeczytal-katechezy)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-03-06T08:47:00+00:00

Na środowej audiencji generalnej papież Franciszek zrezygnował z czytania katechezy. Wyjaśnił wiernym zgromadzonym na placu św. Piotra, że nadal ma problemy ze zdrowiem. Lekturę powierzył swojemu współpracownikowi. To kolejna taka sytuacja w ostatnim czasie.

## Łotwa z zakazem importu produktów rolnych z Rosji i Białorusi. Opublikowano listę
 - [https://www.polsatnews.pl/wiadomosc/2024-03-06/lotwa-z-zakazem-importu-produktow-rolnych-z-rosji-i-bialorusi-opublikowano-liste](https://www.polsatnews.pl/wiadomosc/2024-03-06/lotwa-z-zakazem-importu-produktow-rolnych-z-rosji-i-bialorusi-opublikowano-liste)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-03-06T07:45:00+00:00

Łotewski rząd zatwierdził listę produktów, które zostaną objęte embargiem. Chodzi o artykułu rolne i spożywcze pochodzące z Rosji i Białorusi, których zakup pośrednio finansuje agresję Kremla i Mińska. Polski premier Donald Tusk zapowiedział, że zwróci się do Komisji Europejskiej ws. wprowadzenia całkowitego zakazu importu tych produktów przez całą UE.

## "Superwtorek" w USA. Joe Biden i Donald Trump zdominowali prawybory
 - [https://www.polsatnews.pl/wiadomosc/2024-03-06/superwtorek-w-usa-joe-biden-i-donald-trump-zdominowali-prawybory](https://www.polsatnews.pl/wiadomosc/2024-03-06/superwtorek-w-usa-joe-biden-i-donald-trump-zdominowali-prawybory)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-03-06T06:22:00+00:00

- To by się nigdy nie zdarzyło, gdybym ja był prezydentem - przekonywał Donald Trump, mówiąc o wybuchu konfliktu między Izraelem i Hamasem. Były prezydent obwinił też Joe Bidena o wojnę w Ukrainie. - To wszystko wina Bidena - stwierdził prezydent w czasie tzw. superwtorku, który przybliżył go to otrzymania nominacji republikanów w nadchodzących wyborach prezydenckich.

