# Source:UploadVR, URL:https://www.uploadvr.com/rss, language:en

## Thief Simulator VR Gets Free Introductory Chapter On Quest
 - [https://www.uploadvr.com/thief-simulator-vr-prologue-quest](https://www.uploadvr.com/thief-simulator-vr-prologue-quest)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-03-06T21:00:42+00:00

Thief Simulator VR received a free prologue chapter on Quest App Lab.

## Meteora: The Race Against Space Time Cascades Toward PSVR 2
 - [https://www.uploadvr.com/meteora-the-race-against-space-time-psvr-2-announcement](https://www.uploadvr.com/meteora-the-race-against-space-time-psvr-2-announcement)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-03-06T17:55:09+00:00

Meteora: The Race Against Space Time lets you race across the stars on PSVR 2.

## Meta Explains Why Quest Headsets Stopped Working, Vows To Make Them &quot;More Resilient&quot;
 - [https://www.uploadvr.com/meta-explains-why-quest-headsets-stopped-working-vows-more-resilient](https://www.uploadvr.com/meta-explains-why-quest-headsets-stopped-working-vows-more-resilient)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-03-06T14:15:07+00:00

Meta's VP of VR explained why Quest headsets were unusable for an hour yesterday, and vowed to make them &quot;more resilient&quot; to issues like it.

## MLB Home Run Derby VR Scores A Quest Store Release Date
 - [https://www.uploadvr.com/mlb-home-run-derby-vr-release-date](https://www.uploadvr.com/mlb-home-run-derby-vr-release-date)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-03-06T14:00:13+00:00

MLB Home Run Derby VR leaves App Lab for the main Quest Store soon, adding a new progression system and expanded multiplayer.

## Meta Horizon Worlds Is Getting A &#x27;Survivor&#x27; Island On Friday
 - [https://www.uploadvr.com/meta-horizon-worlds-survivor-island](https://www.uploadvr.com/meta-horizon-worlds-survivor-island)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-03-06T12:58:49+00:00

Survivor: Horizon Island brings the CBS series to Meta's Horizon Worlds this week.

