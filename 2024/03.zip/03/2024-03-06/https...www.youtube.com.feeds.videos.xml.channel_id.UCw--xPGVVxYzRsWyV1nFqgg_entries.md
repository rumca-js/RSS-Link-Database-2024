# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## Brandon Sanderson Forced Audible To Change!! 🎧
 - [https://www.youtube.com/watch?v=kqRC7SNQoFY](https://www.youtube.com/watch?v=kqRC7SNQoFY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2024-03-06T17:30:06+00:00

The mad lad Brandon Sanderson got Audible to change! 
The new second channel: https://www.youtube.com/channel/UCC-EqiFg67s2Nd0imgRXg5w 

My books
Neon Ghosts: https://amzn.to/3Y2N1QI (digital)
Neon Ghosts: Physical: https://tinyurl.com/NGPreOrder 
Breach of Peace: https://tinyurl.com/BoPTLT  
Rebels Creed: https://tinyurl.com/RCTLTDG 
merch: https://www.danielbgreene.com

Patreon: https://www.patreon.com/DanielBGreene 
Join the Discord here: https://discord.gg/xUrPj6EP3f
All the Me Social Links: https://linktr.ee/DanielGreene

Sanderson’s Blog Post: brandonsanderson.com/regarding-audible/

