# Source:The School of Life, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog, language:en-US

## Why We Behave As We Do
 - [https://www.youtube.com/watch?v=cFOwoOhYSiU](https://www.youtube.com/watch?v=cFOwoOhYSiU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog
 - date published: 2024-03-06T14:00:29+00:00

A key principle governing the natural world is that animals adapt to thrive in particular habitats; what we call an animal’s character is essentially a set of traits that gives it maximal opportunity to flourish in specific circumstances.  We humans are - in the end, beneath a layer of civilisation - not so different.



Enjoying our YouTube videos? Get full access to all our audio content, videos, and thousands of thought-provoking articles, conversation cards and more with The School of Life Subscription: https://9qq0.short.gy/wtzpqS




Be more mindful, present and inspired. Get the best of The School of Life delivered straight to your inbox: https://9qq0.short.gy/6jo2Uh


FURTHER READING


You can read more on this and other subjects in our articles, here: https://9qq0.short.gy/B26viZ


“A key principle governing the natural world is that animals adapt to thrive in particular habitats; what we call an animal’s character is essentially a set of traits that gives it maximal

