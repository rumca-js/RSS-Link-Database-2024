# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## TFW the post-Europe tour blues hit...but you remember the US tour is only a month away!!!
 - [https://www.youtube.com/watch?v=bnWWvWi0yZA](https://www.youtube.com/watch?v=bnWWvWi0yZA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2024-03-06T17:53:11+00:00

Store: https://www.scarypocketsfunk.com
Patreon: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

