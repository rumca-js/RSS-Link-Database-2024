# Source:RP - Cyfrowa, URL:https://cyfrowa.rp.pl/rss/2991-cyfrowa, language:pl-PL

## Największy błąd Elona Muska. Po co mu ta wojna?
 - [https://cyfrowa.rp.pl/globalne-interesy/art39951271-najwiekszy-blad-elona-muska-po-co-mu-ta-wojna](https://cyfrowa.rp.pl/globalne-interesy/art39951271-najwiekszy-blad-elona-muska-po-co-mu-ta-wojna)
 - RSS feed: https://cyfrowa.rp.pl/rss/2991-cyfrowa
 - date published: 2024-03-06T15:15:00+00:00

Gra idzie o wielkie pieniądze, dominację w branży sztucznej inteligencji i wielkie ego. Właściciel X, Tesli i SpaceX stworzył spółkę OpenAI, która stworzyła bota ChatGPT, ale się z niej niepotrzebnie wycofał. Teraz pluje sobie w brodę i wytacza armaty.

