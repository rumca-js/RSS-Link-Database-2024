# Source:Kuba Klawiter, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA, language:pl-PL

## Chomąto do smartfona #shorts
 - [https://www.youtube.com/watch?v=iPOrq_RkZQc](https://www.youtube.com/watch?v=iPOrq_RkZQc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLr4hMhk_2KE0GUBSBrspGA
 - date published: 2024-03-06T12:50:38+00:00



