# Source:Squidmar Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDvZTWvHZPTxJ4K1yTD2a1g, language:en-US

## I painted Warhammer in a Race Car - Celebrities control my life for a week
 - [https://www.youtube.com/watch?v=hyDv9X00SGU](https://www.youtube.com/watch?v=hyDv9X00SGU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDvZTWvHZPTxJ4K1yTD2a1g
 - date published: 2024-03-06T16:00:25+00:00

Head to https://squarespace.com/squidmar to save 10% off your first purchase of a website or domain using code SQUIDMAR

This week, we got challenged by Nerdforge, Jazza, Rahul Kohli and Matthew Mercer from Critical Role to paint warhammer miniatures in the most chaotic situations possible. In a racecar, In a Blizzard, while getting electric chocks (emulating labour pains) and getting a tattoo.

🖌️🧟‍♂️👕 Support us by buying the exclusive Squidmar Brushes, Merchandice & sona miniatures: https://www.squidmar.com/shop
🏆 Support me on Patreon: https://www.patreon.com/squidmarminiatures 
👍 Squidmars website for full list of gear I use: https://www.squidmar.com/gear  

_____________________

Emil On 
Instagram http://www.instagram.com/squidmarminiatures
facebook  http://www.facebook.com/ageofsquidmar
Twitter http://www.twitter.com/ageofsquidmar
Lukas instagram: https://www.instagram.com/lukas_miniatures/

Videos edited by Maxime Dader & Viktor Westermark

