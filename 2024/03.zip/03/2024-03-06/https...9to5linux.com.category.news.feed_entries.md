# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## KDE Plasma 5.27.11 LTS Fixes Flatpak Support in Discover, Plasma Wayland
 - [https://9to5linux.com/kde-plasma-5-27-11-lts-fixes-flatpak-support-in-discover-plasma-wayland](https://9to5linux.com/kde-plasma-5-27-11-lts-fixes-flatpak-support-in-discover-plasma-wayland)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-03-06T16:13:17+00:00

<p>KDE Plasma 5.27.11 is now available as a bugfix update to the KDE Plasma 5.27 LTS desktop environment series to address more issues, crashes, and bugs.</p>
<p>The post <a href="https://9to5linux.com/kde-plasma-5-27-11-lts-fixes-flatpak-support-in-discover-plasma-wayland">KDE Plasma 5.27.11 LTS Fixes Flatpak Support in Discover, Plasma Wayland</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

