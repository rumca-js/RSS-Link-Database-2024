# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Nikki Haley Is OUT
 - [https://www.youtube.com/watch?v=tUmTFDZnC_U](https://www.youtube.com/watch?v=tUmTFDZnC_U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-03-06T22:30:13+00:00



## Katt Williams On God's Existence
 - [https://www.youtube.com/watch?v=lAQbreFPM2M](https://www.youtube.com/watch?v=lAQbreFPM2M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-03-06T20:00:25+00:00



## Nikki Haley Is OUT
 - [https://www.youtube.com/watch?v=M0HL1I2-k1Q](https://www.youtube.com/watch?v=M0HL1I2-k1Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-03-06T18:00:06+00:00

Former UN Ambassador Nikki Haley drops out of the race; Arizona Senator Krysten Sinema decides not to run after all; and Joe Biden quotes the Cookie Monster as he prepares for his most consequential State of the Union address.

Ep.1919

- - -

1️⃣  Click here to join the member exclusive portion of my show:  https://bit.ly/41LQK62

2️⃣ Watch Bill Whittle’s An Empire of Terror only on DailyWire+: https://bit.ly/4aink3N

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

PureTalk - Get a FREE Samsung 5G smartphone. Enter promo code: Shapiro at  https://www.puretalkusa.com/landing/shapiro

Current - Simplify your banking with Current today! http://www.current.com/shapiro

Food For The Poor - Donate Today! Text ‘Plate’ to 51555 or visit https://www.foodforthepoor.org/shapiro

ZipRecruiter - Try ZipRecruiter for FREE: https://www.ziprecruiter.com/dailywire

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire

## Taylor Swift at the Super Bowl
 - [https://www.youtube.com/watch?v=sZQyJzCev3k](https://www.youtube.com/watch?v=sZQyJzCev3k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-03-06T02:00:19+00:00



## What's Your Biggest Ick?
 - [https://www.youtube.com/watch?v=_R9MLuCkFc8](https://www.youtube.com/watch?v=_R9MLuCkFc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-03-06T00:30:34+00:00



