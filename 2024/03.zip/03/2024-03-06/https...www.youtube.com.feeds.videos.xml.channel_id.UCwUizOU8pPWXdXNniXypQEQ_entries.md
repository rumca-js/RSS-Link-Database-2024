# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Trustworthy Lies are Good For You
 - [https://www.youtube.com/watch?v=2yKBruY_1cI](https://www.youtube.com/watch?v=2yKBruY_1cI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2024-03-06T23:00:03+00:00

Get Your Infrared Sauna Blanket at https://boncharge.com/jp 
Use Code "JP" for 15% Off!

Get your Freedom Merch Here - https://awakenwithjp.com/collections/all

Upcoming LIVE shows - https://awakenwithjp.com/pages/tour

Get updates from me via email here: https://awakenwithjp.com/joinme

Covid can be treated like the flu now! And other breaking news...

Connect with me at: 
http://www.facebook.com/AwakenWithJP
http://www.Instagram.com/AwakenWithJP
https://rumble.com/AwakenWithJP
http://www.twitter.com/AwakenWithJP
https://mewe.com/p/awakenwithjp
https://parler.com/profile/AwakenWithJP
http://www.AwakenWithJP.com

