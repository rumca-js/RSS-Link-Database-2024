# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Chwiejna równowaga na orbicie. Rosja myśli o broni atomowej w kosmosie
 - [https://www.chip.pl/2024/03/bron-atomowa-na-orbicie-pomysly-ograniczenia](https://www.chip.pl/2024/03/bron-atomowa-na-orbicie-pomysly-ograniczenia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T20:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1008" src="https://konto.chip.pl/wp-content/uploads/2023/04/orbita-ziemia.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/orbita-ziemia.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Żyjemy w czasach, których jeszcze dekadę temu nikt się nie spodziewał. Przyzwyczajeni do tego, że o wojnie czytaliśmy tylko w książkach do historii, zostaliśmy postawieni przez Rosję w sytuacji, w której ponure widmo wojny powróciło ze zdwojoną siłą. Od czasów II wojny światowej wiele jednak się zmieniło i teraz zbrojenia mogą się nie ograniczyć jedynie [&#8230;]</p>

## Wielka księżycowa rakieta wielokrotnego użytku. Chiny podały terminy pierwszych lotów
 - [https://www.chip.pl/2024/03/chinska-rakieta-ksiezycowa-wkrotce-testy](https://www.chip.pl/2024/03/chinska-rakieta-ksiezycowa-wkrotce-testy)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T18:00:00+00:00

<img alt="ksiezyc" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/07/ksiezyc-1.jpeg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/07/ksiezyc-1.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>chiński program kosmiczny</p>

## OnePlus 13 zmieni się nie do poznania. Producent szykuje poważne odświeżenie projektu
 - [https://www.chip.pl/2024/03/oneplus-13-zmiana-wygladu](https://www.chip.pl/2024/03/oneplus-13-zmiana-wygladu)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T17:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2024/02/oneplus-12-recenzja-24.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/oneplus-12-recenzja-24.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Podczas gdy tacy giganci jak Samsung czy Apple stawiają na ujednolicony wygląd swoich smartfonów, pozostali producenci bawią się z projektem. OnePlus nie jest wyjątkiem i wraz z pojawieniem się modelu OnePlus 13, zobaczymy nowy wygląd flagowca firmy. OnePlus 13 przejdzie prawdziwą metamorfozę W ostatnich latach OnePlus stawiał na dość charakterystyczny, spójny wygląd swoich flagowców, których [&#8230;]</p>

## Po co nam premiera Galaxy A35 i Galaxy A55, skoro już teraz wiemy o nich wszystko?
 - [https://www.chip.pl/2024/03/samsung-galaxy-a35-i-galaxy-a55-specyfikacja-wyglad](https://www.chip.pl/2024/03/samsung-galaxy-a35-i-galaxy-a55-specyfikacja-wyglad)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T17:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1268" src="https://konto.chip.pl/wp-content/uploads/2023/12/samsung-galaxy-a54-5g-13.jpg" style="margin-bottom: 10px;" width="1902" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/samsung-galaxy-a54-5g-13.jpg" style="display: block; margin: 1em auto;" /></p>
<p>W obecnych czasach premiery smartfonów to w zasadzie czysta formalność i okazja, by zweryfikować (najczęściej trafne) przecieki, jakie przez miesiące trafiały do sieci. Urządzenia Samsunga, nawet te bardziej budżetowe, nie są tutaj żadnym wyjątkiem, czego najlepszym przykładem są Galaxy A35 i Galaxy A55. Na tydzień przed premierą wiemy o nich wszystko. Pełna specyfikacja Galaxy A35 [&#8230;]</p>

## Realme 12 zalicza premierę. Namiesza w segmencie budżetowym
 - [https://www.chip.pl/2024/03/realme-12-5g-premiera-specyfikacja-ceny](https://www.chip.pl/2024/03/realme-12-5g-premiera-specyfikacja-ceny)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T16:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="720" src="https://konto.chip.pl/wp-content/uploads/2024/03/realme-12-5g-premiera-5.jpg" style="margin-bottom: 10px;" width="1077" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/realme-12-5g-premiera-5.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Debiut Realme 12 może być dla wielu osób czymś dziwnym, bo na rynku dostępna jest już seria Realme 12 Pro. Producent, z jakichś bliżej niewyjaśnionych powodów, kazał nam długo czekać na premierę podstawowej „dwunastki”. Skoro już ten smartfon został zaprezentowany, warto przyjrzeć mu się bliżej. Chińscy producenci smartfonów lubią wprowadzać zamieszanie w swojej ofercie i [&#8230;]</p>

## Krótki test zasilacza FSP Hydro PTM X PRO ATX3.0(PCIe5.0) 1000W
 - [https://www.chip.pl/2024/03/fsp-hydro-ptm-x-pro-atx30-pcie50-1000w-test-recenzja-opinia](https://www.chip.pl/2024/03/fsp-hydro-ptm-x-pro-atx30-pcie50-1000w-test-recenzja-opinia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T15:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1125" src="https://konto.chip.pl/wp-content/uploads/2024/02/FSP-Hydro-PTM-X-PRO-ATX3.0PCIe5.0-1000W-5.jpg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/FSP-Hydro-PTM-X-PRO-ATX3.0PCIe5.0-1000W-5.jpg" style="display: block; margin: 1em auto;" /></p>
<p>FSP Hydro PTM X PRO ATX3.0(PCIe5.0) 1000W to kolejna ciekawa konstrukcja od FSP, która ma złącze 12VHPWR. Tym razem mamy moc 1000 W zamkniętą w naprawdę małej obudowie &#8211; długość to zaledwie 130 mm. Jak konstrukcja wypadnie w praktyce? Co otrzymujemy wraz z FSP Hydro PTM X PRO ATX3.0(PCIe5.0) 1000W? W pudełku znajdziemy sporo papierków, [&#8230;]</p>

## Gigantyczna trawa może stanowić ważne źródło energii. Na Śląsku badali jej przydatność
 - [https://www.chip.pl/2024/03/zrodlo-energii-miskant-olbrzymi](https://www.chip.pl/2024/03/zrodlo-energii-miskant-olbrzymi)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T14:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1920" src="https://konto.chip.pl/wp-content/uploads/2024/03/2880px-Miscanthus_Bestand-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/2880px-Miscanthus_Bestand-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Rośliny również mogą być wykorzystywane w energetyce i przemyśle paliwowym. Przykładem tego jest miskant olbrzymi, który był badany przez polskich naukowców pod kątem produkcji biomasy i pobierania zanieczyszczeń ze skażonych gleb. Poznajmy to interesujące źródło energii z bliska. Temat roślin energetycznych rzadko pojawia się w dyskursie naukowym lub w ogóle w oficjalnych przekazach. Okazuje się, [&#8230;]</p>

## Copilot pozwala na tworzenie własnych GPT. Nie jest to jednak dla każdego
 - [https://www.chip.pl/2024/03/microsoft-copilot-pro-tworzenie-gpt](https://www.chip.pl/2024/03/microsoft-copilot-pro-tworzenie-gpt)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T13:30:00+00:00

<img alt="Copilot GPT" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2024/03/Copilot-GPT.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/Copilot-GPT.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Microsoft już od dłuższego czasu kładzie bardzo duży nacisk na rozwój sztucznej inteligencji. Bazuje na niej Copilot, czyli &#8220;SI dla wszystkich&#8221;, obecne zarówno w Windows 11, jak i Windows 10. Kolejną nową funkcją, jaką otrzymał, jest możliwość tworzenia własnych chatbotów. GPT to skrót od słów &#8220;Generative Pretrained Transformer&#8221;. Oznacza sztuczną inteligencję wytrenowaną tak, aby mogła [&#8230;]</p>

## Za mało rozpędu w sieci przy ofercie na kartę? To chyba nie w T-Mobile, bo tam właśnie srogo dorzucili do pieca
 - [https://www.chip.pl/2024/03/t-mobile-na-karte-promocja-5g](https://www.chip.pl/2024/03/t-mobile-na-karte-promocja-5g)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T13:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2024/03/t-mobile-5g-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/t-mobile-5g-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Dotychczas oferty na kartę nie kojarzyły się jakoś szczególnie mocno ze swobodnym śmiganiem po Internecie, ale wiele się w tej materii ostatnio zmienia. Niech za przykład posłuży najnowsza propozycja od T-Mobile, w ramach której przez cały rok można tam uzyskać dodatkowo kosmiczne aż 5200 GB do wykorzystania. Magentowy operator podpowiada kilka zastosowań dla takiej fury [&#8230;]</p>

## Androida na Windows 11 już nie będzie. Microsoft kończy wsparcie
 - [https://www.chip.pl/2024/03/microsoft-windows-11-system-android](https://www.chip.pl/2024/03/microsoft-windows-11-system-android)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T12:00:00+00:00

<img alt="Windows 11" class="attachment-full size-full wp-post-image" height="683" src="https://konto.chip.pl/wp-content/uploads/2024/03/Android-na-Win11.png" style="margin-bottom: 10px;" width="1024" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/Android-na-Win11.png" style="display: block; margin: 1em auto;" /></p>
<p>Gdy Microsoft ogłaszał Windows 11, jedną z największych innowacji miała być możliwość korzystania z aplikacji stworzonych z myślą o systemie Android. Jednak chyba eksperyment się nie powiódł, gdyż oficjalnie ogłosił koniec wsparcia dla mechanizmu umożliwiającego ich działanie &#8211; Windows Subsystem for Android. Wszystko wydawało się bardzo praktyczne i piękne &#8211; na Androida istnieją tysiące aplikacji, [&#8230;]</p>

## Samsung Music Frame – słuchałem obrazka
 - [https://www.chip.pl/2024/03/samsung-music-frame-wrazenia-opinie-dzwiek](https://www.chip.pl/2024/03/samsung-music-frame-wrazenia-opinie-dzwiek)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T11:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1440" src="https://konto.chip.pl/wp-content/uploads/2024/02/samsung-telewizory-2024-8.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/samsung-telewizory-2024-8.jpg" style="display: block; margin: 1em auto;" /></p>
<p>World of Samsung we Frankfurcie był europejską premierą tegorocznych nowości ze świata RTV u Samsunga. Gama produktów audio to odświeżone soundbary oraz nowy głośnik Music Frame. Głośnik, który rewelacyjnie prezentował się na wszystkich zdjęciach. A jak gra i funkcjonuje na co dzień? Na pewno dla wielu będzie to zakupowy strzał w dziesiątkę. Sprzęt RTV to [&#8230;]</p>

## Pierwszy elektryczny samochód muscle na świecie. Nowy Dodge Charger właśnie zadebiutował
 - [https://www.chip.pl/2024/03/pierwszy-elektryczny-samochod-muscle-dodge-charger](https://www.chip.pl/2024/03/pierwszy-elektryczny-samochod-muscle-dodge-charger)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T11:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2024/03/DG024_011CH1kqma7g7rphj9l6iatnvnqemko.jpg" style="margin-bottom: 10px;" width="1619" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/DG024_011CH1kqma7g7rphj9l6iatnvnqemko.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Od dawna zastanawialiśmy się, jak firma Dodge zmieni charakter swoich charakterystycznych samochodów i wygląda na to, że w przypadku modelu Charger rynek wkrótce oceni, czy był on aż tak bardzo związany z silnikami Hemi V8. Wszystko przez to, że ósma już generacja Dodge Charger całkowicie rezygnuje z V8. Dodge Charger nowej generacji to pierwszy taki [&#8230;]</p>

## Ten celownik rozwiązuje największy problem współczesnej wojny. Brytyjczycy już go mają
 - [https://www.chip.pl/2024/03/brytyjczycy-celownik-broni-smash-x4-drony](https://www.chip.pl/2024/03/brytyjczycy-celownik-broni-smash-x4-drony)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T10:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2024/03/Drony-Smash-4-celowniki.jpg" style="margin-bottom: 10px;" width="1578" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/Drony-Smash-4-celowniki.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Celownik nie brzmi jak coś, co może wnieść potencjał żołnierza na nowy poziom, ale pamiętajmy, że dziś zaawansowany &#8220;celownik&#8221; to nie byle kawałek metalu, a niesamowity wręcz system wizyjny. Przykładem tego niech będzie SMASH X4, który trafił właśnie w ręce jednej z brytyjskich brygad. Do dronów jak do kaczek. Brytyjczycy zestrzelą nowe zagrożenie dzięki celownikom [&#8230;]</p>

## Dwa tysiące osób pracowało nad samochodem, który nie powstanie
 - [https://www.chip.pl/2024/03/apple-car-samochod-anulowany](https://www.chip.pl/2024/03/apple-car-samochod-anulowany)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T09:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="401" src="https://konto.chip.pl/wp-content/uploads/2021/11/apple-car-wizualizacja-5.jpeg" style="margin-bottom: 10px;" width="744" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/11/apple-car-wizualizacja-5.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>Ponad dekada pracy w piach, tysiące osób, zapewne miliardy dolarów, ściśle tajny projekt, o którym spekulowano od lat. Informacja o jego zakończeniu stała się jednak jawna. Apple Car, iCar, Apple Road Pro czy projekt Titan – nazw mogło być wiele. Samochód od Apple na szczęście nie powstanie. Przed Apple jednak dwa kluczowe motoryzacyjne wyzwania na [&#8230;]</p>

## Jednakowe ładunki się wzajemnie odpychają. Ale nie zawsze
 - [https://www.chip.pl/2024/03/jednakowe-ladunki-sie-przyciagaja](https://www.chip.pl/2024/03/jednakowe-ladunki-sie-przyciagaja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T08:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2024/03/wiry-elektronowe.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/wiry-elektronowe.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Przeciwne ładunki się przyciągają, a takie same się odpychają. Tak przynajmniej uczymy się w szkole. Jak jednak donoszą naukowcy, są sytuacje, w których powyższa reguła się nie sprawdza. Fakt odpychania się takich samych ładunków sprawdza się zarówno w elektrostatyce, jak i magnetyzmie. Tao samo dotyczy ładunków w próżni. Niezależnie od tego, czy mamy do czynienia [&#8230;]</p>

## Pierwszy taki pomiar dotyczący jonów uranu. Jak został wykonany?
 - [https://www.chip.pl/2024/03/pomiar-ciezkich-jonow-uranu-elektrodynamika-kwantowa](https://www.chip.pl/2024/03/pomiar-ciezkich-jonow-uranu-elektrodynamika-kwantowa)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T08:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="900" src="https://konto.chip.pl/wp-content/uploads/2024/02/pomiary-jonow.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/pomiary-jonow.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Międzynarodowy zespół złożony z przedstawicieli różnych europejskich instytutów badawczych przeprowadził pierwszy w historii wysoce precyzyjny pomiar dotyczący najcięższych jonów uranu.&#160; Naukowcy wykorzystali w tym celu spektroskopię rentgenowską. Dzięki przyjętemu podejściu mogli rozróżnić jednoelektronowe i wieloelektronowe efekty elektrodynamiki kwantowej. Wszystko to w obecności silnego pola, co ostatecznie doprowadziło do historycznego porównania energii przejścia między poszczególnymi jonami [&#8230;]</p>

## Pentax Film Project nabiera rozpędu, nowy analogowy kompakt już latem
 - [https://www.chip.pl/2024/03/pentax-film-project-kompakt-aps-c-lato](https://www.chip.pl/2024/03/pentax-film-project-kompakt-aps-c-lato)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T07:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="806" src="https://konto.chip.pl/wp-content/uploads/2024/03/Pentaxs-New-Film-Camera.jpg" style="margin-bottom: 10px;" width="1536" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/03/Pentaxs-New-Film-Camera.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Pomysł wprowadzenia na rynek nowego aparatu analogowego na film 35 mm pod marką Pentax pojawił się w firmie Ricoh pod koniec 2022 roku. Prace trwały przez cały zeszły rok i wygląda na to, że doczekaliśmy się działającego prototypu, którego co prawda nie możemy jeszcze zobaczyć, ale za to główny projektant, p. Takeo Suzuki podzielił się [&#8230;]</p>

## Kolejny okręt Rosjan poszedł na dno. To triumf obrońców i nowoczesnej technologii
 - [https://www.chip.pl/2024/03/rosja-okret-projekt-22160-zniszczenie-siergiej-kotow](https://www.chip.pl/2024/03/rosja-okret-projekt-22160-zniszczenie-siergiej-kotow)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-03-06T04:46:50+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="900" src="https://konto.chip.pl/wp-content/uploads/2022/03/Rosyjska-korweta-projektu-22160-jest-stealth.-Ukrainskie-czujniki-ja-namierzyly-a-artyleria-uszkodzila-1.jpg" style="margin-bottom: 10px;" width="1269" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/03/Rosyjska-korweta-projektu-22160-jest-stealth.-Ukrainskie-czujniki-ja-namierzyly-a-artyleria-uszkodzila-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Wojna morska zmienia się na naszych oczach, a Rosjanie czują to na własnej skórze. Tak się składa, że kolejny okręt rosyjskiej marynarki został zatopiony w ramach ataku &#8220;nowoczesną bronią&#8221;, która nie naraziła atakującej strony na żadne ryzyko. Jak zatopić okręt bez dostępu do najpotężniejszych broni? Rosjanie już to wiedzą, ucząc się na własnych wpadkach Potęga [&#8230;]</p>

