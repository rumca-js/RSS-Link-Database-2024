# Source:BBC, URL:https://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Rust armourer guilty of cinematographer's death
 - [https://www.bbc.co.uk/news/world-us-canada-68486069](https://www.bbc.co.uk/news/world-us-canada-68486069)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T23:23:35+00:00

Hannah Gutierrez-Reed was found not guilty of a second charge - tampering with evidence.

## Ngannou & Fury exchange barbs at news conference
 - [https://www.bbc.co.uk/sport/av/boxing/68497100](https://www.bbc.co.uk/sport/av/boxing/68497100)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T22:30:18+00:00

Watch Francis Ngannou's exchange with Tyson Fury at a news conference for the former UFC champion's fight against Anthony Joshua in Saudi Arabia on Friday.

## Real Madrid hold off Leipzig to reach quarter-finals
 - [https://www.bbc.co.uk/sport/football/68482757](https://www.bbc.co.uk/sport/football/68482757)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T22:17:12+00:00

Real Madrid reach the Champions League quarter-finals as Vinicius Junior makes RB Leipzig pay for their missed chances in a 2-1 aggregate win.

## House of Lords inflict more defeats on Rwanda bill
 - [https://www.bbc.co.uk/news/uk-politics-68493351](https://www.bbc.co.uk/news/uk-politics-68493351)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T22:06:35+00:00

Peers fight to change the government bill aimed at deporting asylum seekers to the East African country.

## Arsenal beat Villa to reach Women's League Cup final
 - [https://www.bbc.co.uk/sport/football/68496636](https://www.bbc.co.uk/sport/football/68496636)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T21:24:49+00:00

Stina Blackstenius scores a hat-trick as Arsenal reach the Women's League Cup final by beating Aston Villa.

## Minister's claim about academic cost taxpayer £15,000
 - [https://www.bbc.co.uk/news/uk-politics-68496320](https://www.bbc.co.uk/news/uk-politics-68496320)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T20:47:00+00:00

The science secretary has accepted her original comments about Professor Kate Sang were wrong.

## Who will Haley voters support in Trump-Biden election?
 - [https://www.bbc.co.uk/news/world-us-canada-68483834](https://www.bbc.co.uk/news/world-us-canada-68483834)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T20:46:31+00:00

After the Republican drops out, the voters she leaves behind could play a key role in deciding the presidency.

## Protesters crash truck into Mexico's National Palace
 - [https://www.bbc.co.uk/news/world-latin-america-68494147](https://www.bbc.co.uk/news/world-latin-america-68494147)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T20:13:03+00:00

President Andres Manuel Lopez Obrador was inside the building giving a press conference at the time.

## Everything you need to know about the budget… and probably more
 - [https://www.bbc.co.uk/sounds/play/p0hh1gpj](https://www.bbc.co.uk/sounds/play/p0hh1gpj)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T19:52:00+00:00

Budget 2024: Does this mean a May election is off the cards?

## Ngannou clashes with Fury at Joshua news conference
 - [https://www.bbc.co.uk/sport/boxing/68488867](https://www.bbc.co.uk/sport/boxing/68488867)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T19:42:45+00:00

Ex-UFC champion Francis Ngannou clashes with Tyson Fury and says he is "just getting started" in boxing before his heavyweight fight with Anthony Joshua.

## Why fat Labradors can blame their genes
 - [https://www.bbc.co.uk/news/science-environment-68492504](https://www.bbc.co.uk/news/science-environment-68492504)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T19:16:10+00:00

Scientists used the 'sausage in a box' test to find out that dogs can be a "hard-wired" for obesity.

## Verstappen says his father Jos is 'not a liar'
 - [https://www.bbc.co.uk/sport/formula1/68496582](https://www.bbc.co.uk/sport/formula1/68496582)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T19:06:39+00:00

Max Verstappen says his father is "not a liar" in the wake of his claim that the controversy around Christian Horner is "driving people apart".

## Politician touched women on night out, report says
 - [https://www.bbc.co.uk/news/uk-wales-politics-68490882](https://www.bbc.co.uk/news/uk-wales-politics-68490882)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T19:06:03+00:00

Rhys ab Owen touched and swore at two women while drunk on a night out, an investigation finds.

## Public inquiry to be announced into Emma Caldwell case
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-68496203](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-68496203)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T18:59:13+00:00

Justice Secretary Angela Constance is set to confirm the move in a Holyrood statement on Thursday.

## Tory peer pays student damages for antisemitism claim
 - [https://www.bbc.co.uk/news/uk-68493685](https://www.bbc.co.uk/news/uk-68493685)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T18:56:22+00:00

Jacqueline Foster "deeply" apologises to an Oxford student after wrongly accusing her of being antisemitic.

## Teacher suspended after allegedly shooting student
 - [https://www.bbc.co.uk/news/world-asia-68490662](https://www.bbc.co.uk/news/world-asia-68490662)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T18:40:47+00:00

Students in Bangladesh organised a protest calling for the teacher's suspension after the alleged incident.

## Dharshini David: An election giveaway but taxes will still rise
 - [https://www.bbc.co.uk/news/business-68493947](https://www.bbc.co.uk/news/business-68493947)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T18:23:05+00:00

My main takeaway from Wednesday's Budget is that many are still going to see their tax bills rise.

## Oil and gas profits windfall tax extended until 2029
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-business-68489807](https://www.bbc.co.uk/news/uk-scotland-scotland-business-68489807)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T18:02:46+00:00

The decision puts the chancellor at odds with the Scottish Conservative leader who lobbied against the move.

## Is the tax take the highest for 70 years?
 - [https://www.bbc.co.uk/news/uk-politics-68494168](https://www.bbc.co.uk/news/uk-politics-68494168)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T17:38:09+00:00

Chancellor Jeremy Hunt and Labour leader Keir Starmer made a number of claims on Budget day.

## PC shot dead 'didn't have chance', colleague says
 - [https://www.bbc.co.uk/news/uk-england-bradford-west-yorkshire-68492559](https://www.bbc.co.uk/news/uk-england-bradford-west-yorkshire-68492559)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T17:23:41+00:00

Piran Ditta Khan is on trial accused of murdering Sharon Beshenivsky in the 2005 shooting.

## Chelsea's Kerr has club's 'full support' - Hayes
 - [https://www.bbc.co.uk/sport/football/68492930](https://www.bbc.co.uk/sport/football/68492930)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T17:07:51+00:00

Chelsea manager Emma Hayes says Sam Kerr has the club's "full support" after being charged with racially aggravated harassment of a London police officer.

## Explosions hit Odesa as Zelensky meets Greek PM
 - [https://www.bbc.co.uk/news/world-europe-68492688](https://www.bbc.co.uk/news/world-europe-68492688)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T16:55:46+00:00

Ukraine's navy says five people have been killed after missile strikes in the southern port city.

## Fire forces Southampton to postpone Preston game
 - [https://www.bbc.co.uk/sport/football/68492867](https://www.bbc.co.uk/sport/football/68492867)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T16:31:22+00:00

Southampton postpone Wednesday's Championship game with Preston following a major fire next to St Mary's.

## Defence begins in Marten and Gordon trial
 - [https://www.bbc.co.uk/news/uk-68490395](https://www.bbc.co.uk/news/uk-68490395)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T16:28:15+00:00

There is no legal obligation to register a pregnancy with the NHS, the court is told.

## Major fire near Southampton's football ground
 - [https://www.bbc.co.uk/news/uk-england-hampshire-68492318](https://www.bbc.co.uk/news/uk-england-hampshire-68492318)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T15:56:45+00:00

A plume of smoke is seen across the city after a major fire breaks out at industrial units.

## Budget tax cuts are a Tory con, says Keir Starmer
 - [https://www.bbc.co.uk/news/uk-politics-68488467](https://www.bbc.co.uk/news/uk-politics-68488467)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T15:49:16+00:00

Labour says people are still being asked to pay "more for less", despite a cut to National Insurance.

## What is the new vaping tax and when will it start?
 - [https://www.bbc.co.uk/news/health-66784967](https://www.bbc.co.uk/news/health-66784967)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T15:25:45+00:00

The government will introduce a new vaping tax on top of measures to stop children vaping.

## Prosecutors demand near five-year Ancelotti sentence
 - [https://www.bbc.co.uk/sport/football/68490581](https://www.bbc.co.uk/sport/football/68490581)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T14:59:54+00:00

Spanish prosecutors call for Real Madrid boss Carlo Ancelotti to be jailed for four years and nine months for avoiding 1m euros (£854,000) in tax.

## Red panda found in luggage at Bangkok airport
 - [https://www.bbc.co.uk/news/world-asia-68492687](https://www.bbc.co.uk/news/world-asia-68492687)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T14:58:07+00:00

Six Indian nationals have been arrested for attempting to smuggle dozens of animals out of Thailand.

## Why England have so much to prove in foothills of Himalayas
 - [https://www.bbc.co.uk/sport/cricket/68492376](https://www.bbc.co.uk/sport/cricket/68492376)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T14:37:16+00:00

England - as a team, and as individuals - have lots of questions to answer when they face India in the final Test of the series, writes Stephan Shemilt.

## Child benefit to be paid to more families
 - [https://www.bbc.co.uk/news/business-68491052](https://www.bbc.co.uk/news/business-68491052)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T14:25:40+00:00

The chancellor says changes mean 170,000 families will not pay charges on the benefit.

## Watch: Tories ask to 'pay more and more for less and less' - Starmer
 - [https://www.bbc.co.uk/news/uk-politics-68491892](https://www.bbc.co.uk/news/uk-politics-68491892)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T14:25:23+00:00

The Labour leader says the Conservatives are 'stubbornly clinging to the failed ideas of of the past'.

## Watch: Chancellor announces 2p National Insurance cut
 - [https://www.bbc.co.uk/news/uk-politics-68492917](https://www.bbc.co.uk/news/uk-politics-68492917)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T14:23:40+00:00

The cut means that National Insurance will fall from 10% to 8%, following an earlier 2p cut in the Autumn statement.

## Cargo ship damaged in fresh attack off Yemen
 - [https://www.bbc.co.uk/news/world-middle-east-68490695](https://www.bbc.co.uk/news/world-middle-east-68490695)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T14:02:24+00:00

Crew members are being rescued after a loud bang and smoke were reported, a security firm says.

## What does the Budget mean for you?
 - [https://www.bbc.co.uk/news/business-68480102](https://www.bbc.co.uk/news/business-68480102)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T13:54:40+00:00

Tax and spending cuts will have a significant impact on your finances, so here's what it means for you.

## Sons publish book García Márquez wanted destroyed
 - [https://www.bbc.co.uk/news/entertainment-arts-68488756](https://www.bbc.co.uk/news/entertainment-arts-68488756)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T13:43:47+00:00

The Nobel Prize-winning author's son explains why the "betrayal" of his father's wishes is justified.

## Huge fire near St Mary's Stadium in Southampton
 - [https://www.bbc.co.uk/news/live/uk-england-hampshire-68492344](https://www.bbc.co.uk/news/live/uk-england-hampshire-68492344)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T13:24:16+00:00

A large plume of smoke is billowing across Southampton.

## UK economy set to grow faster than expected
 - [https://www.bbc.co.uk/news/business-68489236](https://www.bbc.co.uk/news/business-68489236)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T13:22:47+00:00

The government's official forecaster has raised its prediction for UK growth in 2024 and 2025.

## Guy Ritchie reimagines The Gentlemen for Netflix series
 - [https://www.bbc.co.uk/news/entertainment-arts-68488859](https://www.bbc.co.uk/news/entertainment-arts-68488859)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T13:08:02+00:00

Ray Winstone and Giancarlo Esposito are among the stars of a new TV adaptation of the 2019 film.

## Hunt: UK growth higher than every large European economy
 - [https://www.bbc.co.uk/news/uk-politics-68489588](https://www.bbc.co.uk/news/uk-politics-68489588)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T12:52:16+00:00

The chancellor opens the 2024 Budget amid noisy scenes in the Commons.

## Navalny's widow urges Russians to protest on election day
 - [https://www.bbc.co.uk/news/world-europe-68479832](https://www.bbc.co.uk/news/world-europe-68479832)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T12:49:22+00:00

Yulia Navalnaya urges opponents of Vladimir Putin to form long queues at polling stations at the same time.

## Dishwashers and Friends reruns - PM talks home life
 - [https://www.bbc.co.uk/news/uk-politics-68490392](https://www.bbc.co.uk/news/uk-politics-68490392)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T12:40:04+00:00

The prime minister and his wife, Akshata Murty, shared insights about their home life.

## Real midfielder Bellingham banned for two games
 - [https://www.bbc.co.uk/sport/football/68489144](https://www.bbc.co.uk/sport/football/68489144)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T12:33:50+00:00

Real Madrid midfielder Jude Bellingham is banned for two La Liga matches for his red card after the controversial draw at Valencia.

## John Lewis and Co-op announce pay rises for staff
 - [https://www.bbc.co.uk/news/business-68440286](https://www.bbc.co.uk/news/business-68440286)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T12:18:33+00:00

Workers at the retailers will get a rise above minimum wage as shops battle for staff.

## Grandparents charged with toddler's murder
 - [https://www.bbc.co.uk/news/uk-wales-68490830](https://www.bbc.co.uk/news/uk-wales-68490830)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T12:17:09+00:00

Two-year-old Ethan Griffiths was taken to hospital in August 2021 and later died of a brain injury.

## K-pop star apologises after relationship goes public
 - [https://www.bbc.co.uk/news/world-asia-68487232](https://www.bbc.co.uk/news/world-asia-68487232)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T12:12:32+00:00

Some fans expressed disappointment after the 23-year-old confirmed she is dating actor Lee Jae-wook.

## Emma Caldwell killer Iain Packer to appeal against conviction
 - [https://www.bbc.com/news/articles/cv2yr92ekg7o](https://www.bbc.com/news/articles/cv2yr92ekg7o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T11:46:18+00:00

Packer was convicted of the murder and of 32 other crimes last month.

## School checking absent pupils' bins, cars and post
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-68441335](https://www.bbc.co.uk/news/uk-england-south-yorkshire-68441335)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T11:40:37+00:00

Astrea Academy Woodfields in Doncaster is accused of "invasive snooping tactics".

## Wales change centre pairing against France
 - [https://www.bbc.co.uk/sport/rugby-union/68482001](https://www.bbc.co.uk/sport/rugby-union/68482001)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T11:37:13+00:00

Scarlets centre Joe Roberts replaces George North to make his Six Nations debut alongside Owen Watkin on Sunday.

## 'My son Ali has already died': Father's plea for Gaza's starving children
 - [https://www.bbc.co.uk/news/world-middle-east-68483180](https://www.bbc.co.uk/news/world-middle-east-68483180)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T11:23:53+00:00

Ali was one of at least 10 children who a WHO team said died from lack of food in a north Gaza hospital.

## NI terrorism threat level reduced to substantial
 - [https://www.bbc.co.uk/news/uk-northern-ireland-68489012](https://www.bbc.co.uk/news/uk-northern-ireland-68489012)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T11:13:33+00:00

The decision to change the threat level is taken by MI5, independently of ministers.

## Mother charged with murder of 10-year-old girl
 - [https://www.bbc.co.uk/news/uk-england-birmingham-68489970](https://www.bbc.co.uk/news/uk-england-birmingham-68489970)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T11:02:58+00:00

Shay Kang was found with injuries at an address in Rowley Regis, West Midlands, on Monday.

## Rahm criticises world rankings as LIV ends interest
 - [https://www.bbc.co.uk/sport/golf/68479599](https://www.bbc.co.uk/sport/golf/68479599)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T10:47:25+00:00

Masters champion Jon Rahm says Official World Golf Ranking is not "a good system" after LIV Golf withdraws its application to join.

## German ambassador to UK not sorry for leaked call
 - [https://www.bbc.co.uk/news/world-europe-68488962](https://www.bbc.co.uk/news/world-europe-68488962)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T10:45:54+00:00

Miguel Berger told the BBC one of the participants had likely dialled in over a mobile phone or hotel internet.

## TV's Nigel Lythgoe faces new sexual assault claim
 - [https://www.bbc.co.uk/news/entertainment-arts-68484416](https://www.bbc.co.uk/news/entertainment-arts-68484416)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T09:30:08+00:00

The British executive and talent show judge faces a string of allegations, which he has denied.

## Boy, 11, found dead at house as police investigate
 - [https://www.bbc.co.uk/news/uk-england-lancashire-68488698](https://www.bbc.co.uk/news/uk-england-lancashire-68488698)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T09:12:32+00:00

The boy's death is being treated as unexplained and is being investigated by police.

## Cameron to warn Israel minister over Gaza aid
 - [https://www.bbc.co.uk/news/uk-politics-68488466](https://www.bbc.co.uk/news/uk-politics-68488466)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T08:59:01+00:00

The foreign secretary says there is "dreadful suffering" in Gaza, as he is due to meet minister Benny Gantz later.

## 'Best midfielder in the world' - Man City's invincible Rodri
 - [https://www.bbc.co.uk/sport/football/68449995](https://www.bbc.co.uk/sport/football/68449995)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T08:58:03+00:00

Manchester City midfielder Rodri's unbeaten run now stands at an incredible 59 games. BBC Sport discusses why he is so important to the team.

## England recall Wood for Robinson for fifth Test
 - [https://www.bbc.co.uk/sport/cricket/68488004](https://www.bbc.co.uk/sport/cricket/68488004)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T08:48:53+00:00

England recall fast bowler Mark Wood in place of Ollie Robinson in the only change to their XI for the final Test against India in Dharamsala.

## Election poll tracker: How do the parties compare?
 - [https://www.bbc.co.uk/news/uk-politics-68079726](https://www.bbc.co.uk/news/uk-politics-68079726)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:59:28+00:00

How do people say they will vote in the UK general election? Our poll tracker measures the trends.

## Raducanu 'not too concerned' about tournament results
 - [https://www.bbc.co.uk/sport/tennis/68487680](https://www.bbc.co.uk/sport/tennis/68487680)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:56:59+00:00

Emma Raducanu says she is "not too concerned" about tournament results, as the priority this year is to develop her game.

## Why Pollock may be England’s next breakthrough star
 - [https://www.bbc.co.uk/sport/rugby-union/68423080](https://www.bbc.co.uk/sport/rugby-union/68423080)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:52:06+00:00

With the Under-20 Six Nations producing senior internationals quicker than ever before, BBC Sport looks at why Henry Pollock might be England's next breakthrough star.

## Super Tuesday: Everything Points to Trump vs Biden
 - [https://www.bbc.co.uk/sounds/play/p0hgw47r](https://www.bbc.co.uk/sounds/play/p0hgw47r)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:38:00+00:00

Trump and Biden win almost every state in election season's biggest primary night.

## Man charged over Clapham shooting
 - [https://www.bbc.co.uk/news/uk-england-london-68487507](https://www.bbc.co.uk/news/uk-england-london-68487507)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:36:31+00:00

Two women suffered shotgun pellet injuries and another person was hit by a moped.

## Hunt expected to cut National Insurance by another 2p in Budget
 - [https://www.bbc.co.uk/news/live/uk-politics-68465603](https://www.bbc.co.uk/news/live/uk-politics-68465603)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:33:13+00:00

It would mean the main rate for employees falling from 10% to 8% - which could save the average worker around £450 a year.

## Junior doctors in Northern Ireland strike over pay
 - [https://www.bbc.co.uk/news/uk-northern-ireland-68479873](https://www.bbc.co.uk/news/uk-northern-ireland-68479873)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:21:51+00:00

The department says the action, a first for NI doctors, will cause disruption to patient care.

## MP says Milton Keynes misrepresented by EastEnders
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-68483686](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-68483686)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:14:37+00:00

One viewer says the programme portrays the city as a "slum".

## Starling murmurations fascinate car park crowd
 - [https://www.bbc.com/news/articles/c51317pzj42o](https://www.bbc.com/news/articles/c51317pzj42o)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:12:42+00:00

Crowds flock to watch a starling murmuration close to a Redditch car park.

## Chris Mason: One of the last chances to move the political dial
 - [https://www.bbc.co.uk/news/uk-politics-68487118](https://www.bbc.co.uk/news/uk-politics-68487118)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T06:00:23+00:00

The statement comes amid Tory fears that many voters have stopped listening, says our political editor.

## Watch best tries of Six Nations so far
 - [https://www.bbc.co.uk/sport/av/rugby-union/68467891](https://www.bbc.co.uk/sport/av/rugby-union/68467891)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T05:53:28+00:00

Watch the best tries from the first three rounds of the Six Nations, including superb scores by Scotland's Duhan van der Merwe.

## Clarke and Aspinall break down Joshua v Ngannou
 - [https://www.bbc.co.uk/sport/av/boxing/68485172](https://www.bbc.co.uk/sport/av/boxing/68485172)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T05:47:39+00:00

Heavyweight boxer Frazer Clarke and UFC champion Tom Aspinall break down Friday's Anthony Joshua v Francis Ngannou fight.

## Peru PM resigns after recording with woman leaked
 - [https://www.bbc.co.uk/news/world-latin-america-68486544](https://www.bbc.co.uk/news/world-latin-america-68486544)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T05:11:41+00:00

Alberto Otárola denies allegations he helped a woman gain lucrative government contracts.

## Action demanded over Bristol 'knife crime scourge'
 - [https://www.bbc.co.uk/news/uk-england-bristol-68467141](https://www.bbc.co.uk/news/uk-england-bristol-68467141)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T04:37:55+00:00

Organisations in Bristol have signed the document after a number of stabbings in 2024.

## Barrage of missiles intercepted by Israel’s Iron Dome
 - [https://www.bbc.co.uk/news/world-middle-east-68476386](https://www.bbc.co.uk/news/world-middle-east-68476386)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T03:20:16+00:00

Dramatic footage shows multiple missiles exploding in the border area between Israel and Lebanon.

## Key takeaways from Super Tuesday's results so far
 - [https://www.bbc.co.uk/news/world-us-canada-68472310](https://www.bbc.co.uk/news/world-us-canada-68472310)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T02:25:54+00:00

Donald Trump is dominating again, but could be denied a clean sweep as Vermont remains neck and neck.

## iPhone China sales slide as Huawei soars - report
 - [https://www.bbc.co.uk/news/business-68486928](https://www.bbc.co.uk/news/business-68486928)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T02:18:32+00:00

Apple phone sales fell 24% in the first six weeks of the year, according to researcher Counterpoint.

## Number of indie record shops hits 10-year high
 - [https://www.bbc.co.uk/news/newsbeat-68483084](https://www.bbc.co.uk/news/newsbeat-68483084)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T02:18:30+00:00

A demand for vinyl is credited with there being 122 more owner-run music shops than there were in 2014.

## Health staff to start court fight over long Covid
 - [https://www.bbc.co.uk/news/health-68479912](https://www.bbc.co.uk/news/health-68479912)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T02:00:54+00:00

They say they are disabled after catching Covid at work, with no protection from employers.

## Ban on FKA twigs Calvin Klein ad partially lifted
 - [https://www.bbc.co.uk/news/newsbeat-68478328](https://www.bbc.co.uk/news/newsbeat-68478328)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T01:39:14+00:00

The ruling in January caused controversy, with the singer calling the ban "double standards".

## Haiti PM in Puerto Rico as gang violence continues
 - [https://www.bbc.co.uk/news/world-latin-america-68486536](https://www.bbc.co.uk/news/world-latin-america-68486536)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T01:29:14+00:00

Ariel Henry lands in San Juan after armed gangs attacked Haiti's main airport to stop his re-entry.

## The Papers: Hunt's £10bn 'tax cut gamble' and SAS murder inquiry
 - [https://www.bbc.co.uk/news/blogs-the-papers-68486420](https://www.bbc.co.uk/news/blogs-the-papers-68486420)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T01:22:25+00:00

Speculation ahead of the Budget and an investigation into possible war crimes in Syria lead the papers.

## Judges pledge to surge rape cases to cut backlogs
 - [https://www.bbc.co.uk/news/uk-68483956](https://www.bbc.co.uk/news/uk-68483956)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T01:01:14+00:00

The unprecedented move is an attempt by the judiciary to crack some of the worst court delays.

## Can the Panama Canal save itself?
 - [https://www.bbc.co.uk/news/business-68467529](https://www.bbc.co.uk/news/business-68467529)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-03-06T00:02:57+00:00

The authority that runs the canal is looking at ways to conserve the water it needs to stay open.

