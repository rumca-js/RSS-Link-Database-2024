# Source:Wintergatan, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcXhhVwCT6_WqjkEniejRJQ, language:en-US

## Playing Bass with Marbles - Testing 3 New Ideas
 - [https://www.youtube.com/watch?v=JadbqfeZ09M](https://www.youtube.com/watch?v=JadbqfeZ09M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcXhhVwCT6_WqjkEniejRJQ
 - date published: 2024-03-06T21:22:52+00:00

The design requirement process pushed me to gather some more information about how the instruments were supposed to play. So here we are with some prototyping again.

Thank you to all Wintergatan Youtube Members!

Video edited By Martin and Hannes from the Trainerds Youtube Channel:
https://www.youtube.com/c/TRAINERDS

—
MUSIC DOWNLOADS ► https://wintergatan.bandcamp.com 
WINTERGATAN RECORDS ► http://www.wintergatan.net/#/shop
SPOTIFY ► http://bit.ly/2oKxXWd 
ITUNES ► http://apple.co/2ntWNsZ 
MERCH ► https://teespring.com/stores/wintergatan
COMMUNITY DISCORD ► https://discord.gg/wintergatan
SECOND OFFICIAL CHANNEL:► https://www.youtube.com/c/Wintergatan2021
—

