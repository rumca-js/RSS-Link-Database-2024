# Source:Board Game Quest, URL:https://www.boardgamequest.com/feed, language:en-US

## Printing Press Review
 - [https://www.boardgamequest.com/printing-press-review](https://www.boardgamequest.com/printing-press-review)
 - RSS feed: https://www.boardgamequest.com/feed
 - date published: 2024-03-06T14:05:00+00:00

<img alt="Printing Press" class="webfeedsFeaturedVisual not-transparent wp-post-image" height="640" src="https://www.boardgamequest.com/wp-content/uploads/2024/02/Printing-Press-jpg.webp" width="640" />Publisher Granna’s 2022 Gutenberg was a surprise hit. Taking the history of the printing press and turning it into a bidding/rondel Euro title struck a chord with players around the world. Now in 2024, the smaller spin-off title Printing Press has arrived from Portal Games. Now, though, instead of competing with medium-heavy Euros, this new [&#8230;]
<p><a href="https://www.boardgamequest.com/printing-press-review/" rel="nofollow">Source</a></p>

