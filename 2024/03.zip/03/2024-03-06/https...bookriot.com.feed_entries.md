# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## New Nonfiction by Women
 - [https://bookriot.com/new-nonfiction-by-women](https://bookriot.com/new-nonfiction-by-women)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T18:00:00+00:00

Which nonfiction books by women are you reading this month?

## Reading Rainbow Documentary Trailer Drops
 - [https://bookriot.com/reading-rainbow-documentary-trailer-drops](https://bookriot.com/reading-rainbow-documentary-trailer-drops)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T17:20:50+00:00

We now have a trailer!! 📚🌈🦋

## Book Riot’s Children’s Deals of the Day for March 6, 2024
 - [https://bookriot.com/book-riots-childrens-deals-of-the-day-for-march-6-2024](https://bookriot.com/book-riots-childrens-deals-of-the-day-for-march-6-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T16:15:39+00:00

Ramadan with Curious George, a princess academy, Snoopy saves the day, and more of today's best children's book deals.

## Book Riot’s Romance Deals for March 6, 2024
 - [https://bookriot.com/book-riots-romance-deals-for-march-6-2024](https://bookriot.com/book-riots-romance-deals-for-march-6-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T16:06:06+00:00

There's a Southern Wedding, a Historical Romantasy, Romantic Suspense, and More in Today's Best Romance Deals

## Book Riot’s Deals of the Day for Wednesday, March 6, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-wednesday-march-6-2024](https://bookriot.com/book-riots-deals-of-the-day-for-wednesday-march-6-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T13:30:00+00:00

A small town enemies-to-lovers romance, finding refuge and friendship in books, women in wartime, and more of today's best book deals.

## Missing Children and a Forbidden Forest Ruled by the Fae
 - [https://bookriot.com/read-this-book-march-6-2024](https://bookriot.com/read-this-book-march-6-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T13:00:00+00:00

**Dark fantasy/horror novella alert**

## 8 of the Best Haunted House Stories To Make You Shiver
 - [https://bookriot.com/best-haunted-house-stories](https://bookriot.com/best-haunted-house-stories)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T12:30:00+00:00

What's your favorite haunted house book?

## 10 of the Best Bookish Gifts for Gardeners
 - [https://bookriot.com/best-bookish-gifts-for-gardeners](https://bookriot.com/best-bookish-gifts-for-gardeners)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T12:00:00+00:00

Bookish peeps and nature lovers, get in here!<p>- Ashlie Swicker</p>

## Spring into March with These New Comics and Graphic Novels
 - [https://bookriot.com/march-2024-new-comics-and-graphic-novels](https://bookriot.com/march-2024-new-comics-and-graphic-novels)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T11:30:00+00:00

Get into these magical girls, kingdom-saving lesbian marriages, alternate dimensions, and more.

## 10 Fresh Paranormal Romance Reads
 - [https://bookriot.com/fresh-paranormal-romance-reads](https://bookriot.com/fresh-paranormal-romance-reads)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-03-06T11:00:00+00:00

A little monster romance never hurt anyone.

