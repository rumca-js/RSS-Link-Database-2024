# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## Your Printer is Now a Subscription
 - [https://www.youtube.com/watch?v=tUYrCxHuRgU](https://www.youtube.com/watch?v=tUYrCxHuRgU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2024-03-06T17:00:44+00:00

HP launches an actual printing subscription with rented printers, a two-year commitment, and a pages per month cap.

Watch the full WAN Show: https://www.youtube.com/watch?v=qs-sYNsqPYA&amp;t=10869s


► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## Why Does the Vision Pro cost so much?
 - [https://www.youtube.com/watch?v=mtBAu7rA6ew](https://www.youtube.com/watch?v=mtBAu7rA6ew)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2024-03-06T17:00:39+00:00

A research firm has released an estimated bill of materials for the Apple Vision Pro, giving a range for the cost of its component parts. 

Watch the full WAN Show: https://www.youtube.com/watch?v=qs-sYNsqPYA&amp;t=10869s

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## Reject Modernity, Embrace Repairable Laptops
 - [https://www.youtube.com/watch?v=b9FfEAxpAMg](https://www.youtube.com/watch?v=b9FfEAxpAMg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2024-03-06T17:00:27+00:00

iFixit teams up with Lenovo to create new highly repairable business laptops with mostly replaceable components. 

Watch the full WAN Show: https://www.youtube.com/watch?v=qs-sYNsqPYA&amp;t=10869s

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

