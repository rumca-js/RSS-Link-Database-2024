# Source:Na Gałęzi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtecHyLSXoL3P-xgFsbQh-g, language:pl

## Szogun - dlaczego ten serial jest tak ładny?
 - [https://www.youtube.com/watch?v=tyw4RoKuSFU](https://www.youtube.com/watch?v=tyw4RoKuSFU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtecHyLSXoL3P-xgFsbQh-g
 - date published: 2024-03-06T14:59:51+00:00

Na Gałęzi na Instagramie - https://www.instagram.com/mlukanski/

Dlaczego ujęcia w Szogunie wyglądają tak dobrze i charakterystycznie? To serial, w którym twórcy bardzo sprytnie podeszli do kreowania swojego świata, szczególnie od strony wyjątkowo dobrze dobranego oświetlenia. Omawiamy wybrane sceny i analizujemy kunszt najnowszego serialu dostępnego w Disney+

