# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## ChatGPT-maker OpenAI hits back at Musk criticism
 - [https://www.bbc.co.uk/news/technology-68488230](https://www.bbc.co.uk/news/technology-68488230)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-03-06T11:59:24+00:00

OpenAI rejects claims it is focusing too much on profit, saying it is an idea Elon Musk endorsed.

