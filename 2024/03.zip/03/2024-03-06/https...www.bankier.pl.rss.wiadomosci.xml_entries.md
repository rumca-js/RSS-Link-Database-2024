# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Powell powtórzył zapowiedź obniżek stóp. S&P500 ruszył w górę
 - [https://www.bankier.pl/wiadomosc/Powell-powtorzyl-zapowiedz-obnizek-stop-S-P500-ruszyl-w-gore-8706824.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powell-powtorzyl-zapowiedz-obnizek-stop-S-P500-ruszyl-w-gore-8706824.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T21:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/4c7fc2737fc792-948-568-0-140-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Inwestorzy analizują ostatnie przemówienie prezesa Fedu, który zapewniał, że w tym roku dojdzie do obniżki stóp procentowych.</p>

## "Economist": koszty wojny zmuszą Izrael do cięcia osłon społecznych
 - [https://www.bankier.pl/wiadomosc/Economist-koszty-wojny-zmusza-Izrael-do-ciecia-oslon-spolecznych-8706780.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Economist-koszty-wojny-zmusza-Izrael-do-ciecia-oslon-spolecznych-8706780.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T19:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/136f9158cbbbce-948-568-30-7-2970-1781.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Premier Izraela Benjamin Netanjahu liczy na to, że Kneset szybko zatwierdzi projekt budżetu wojennego i że zachowane zostaną środki dla jego politycznych sojuszników. Ofiarą wojny padną jednak tradycyjne, hojne osłony społeczne i wydatki na edukację - pisze "Economist".</p>

## Właściciel Biedronki pokazuje wyniki. Jest lepiej niż było
 - [https://www.bankier.pl/wiadomosc/Wlasciciel-Biedronki-pokazuje-wyniki-Jest-lepiej-niz-bylo-8706760.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wlasciciel-Biedronki-pokazuje-wyniki-Jest-lepiej-niz-bylo-8706760.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T18:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/fdb7ea47fabdf2-948-568-2-115-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grupa Jeronimo Martins, właściciel m.in. sklepów Biedronka, miała w czwartym kwartale 2023 roku 198 mln euro zysku netto jednostki dominującej, o 15,8 proc. więcej niż przed rokiem - podała spółka w raporcie.</p>

## Dariusz Marzec powołany na funkcję prezesa zarządu PGE
 - [https://www.bankier.pl/wiadomosc/Dariusz-Marzec-powolany-na-funkcje-prezesa-zarzadu-PGE-8706741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dariusz-Marzec-powolany-na-funkcje-prezesa-zarzadu-PGE-8706741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T18:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/6/4277541fb5c866-948-568-0-160-4000-2400.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dariusz Marzec został powołany na funkcję prezesa zarządu PGE - podała spółka w komunikacie. Rada Nadzorcza powołała także Marcina Laskowskiego do pełnienia funkcji wiceprezesa zarządu ds. regulacji. (PAP Biznes)</p>

## Szef MSWiA: To nie rolnicy, tylko prowokatorzy zaatakowali polską policję
 - [https://www.bankier.pl/wiadomosc/Szef-MSWiA-To-nie-rolnicy-tylko-prowokatorzy-zaatakowali-polska-policje-8706714.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szef-MSWiA-To-nie-rolnicy-tylko-prowokatorzy-zaatakowali-polska-policje-8706714.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T17:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/7/735bbf9f9dee93-948-568-0-0-4504-2702.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szef MSWiA Marcin Kierwiński powiedział w środę w Sejmie, że rolnicy przyjechali do Warszawy, żeby protestować w sposób pokojowy. Zastrzegł, że wśród protestujących znaleźli się prowokatorzy, którzy zaatakowali policję i w tej sytuacji, policjanci musieli zareagować.</p>

## Sejm przyjął uchwałę w sprawie Trybunału Konstytucyjnego
 - [https://www.bankier.pl/wiadomosc/Sejm-przyjal-uchwale-w-sprawie-Trybunalu-Konstytucyjnego-8706703.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejm-przyjal-uchwale-w-sprawie-Trybunalu-Konstytucyjnego-8706703.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T17:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/0/ad7c0efe478912-948-568-690-614-2310-1385.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm w środę po południu przyjął uchwałę w sprawie usunięcia skutków kryzysu konstytucyjnego lat 2015-2023 w kontekście działalności Trybunału Konstytucyjnego. Poparło ją 240 posłów, przeciw było 197, nikt się nie wstrzymał od głosu.</p>

## Chińscy policjanci będą wkrótce patrolować węgierskie ulice
 - [https://www.bankier.pl/wiadomosc/Chinscy-policjanci-beda-wkrotce-patrolowac-wegierskie-ulice-8706648.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chinscy-policjanci-beda-wkrotce-patrolowac-wegierskie-ulice-8706648.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T16:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/5bbd7ef4965354-948-568-30-130-3970-2381.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podpisane w połowie lutego węgiersko-chińskie porozumienie dopuszcza patrole chińskich policjantów na terenie Węgier – poinformowało węgierskie ministerstwo spraw wewnętrznych w odpowiedzi na pytanie portalu Telex.</p>

## Poprawa nastrojów na GPW. Marshall tnie krótką na spółkach z WIG20
 - [https://www.bankier.pl/wiadomosc/Poprawa-nastrojow-na-GPW-Marshall-tnie-krotka-na-spolkach-z-WIG20-8706626.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Poprawa-nastrojow-na-GPW-Marshall-tnie-krotka-na-spolkach-z-WIG20-8706626.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T16:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/af80e37115f955-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spokojna sesja zakończyła się zwyżkami głównych indeksów na GPW. Rosły także wyceny na rynkach zewnętrznych, które bez większych emocji podeszły do przemówienia szefa Fedu. Z kolei decyzja RPP i jej komunikat także zostały odebrane neutralnie przez krajowych inwestorów.</p>

## KGHM ma nowego prezesa. Andrzej Szydło stanie na czele spółki
 - [https://www.bankier.pl/wiadomosc/Andrzej-Szydlo-wybrany-na-prezesa-zarzadu-KGHM-Polska-Miedz-RN-wybrala-zarzad-8706617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Andrzej-Szydlo-wybrany-na-prezesa-zarzadu-KGHM-Polska-Miedz-RN-wybrala-zarzad-8706617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T16:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/34308941023a7f-945-560-0-55-1470-881.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Andrzej Szydło został wybrany na prezesa zarządu KGHM Polska Miedź - podała spółka w komunikacie. W środę rada nadzorcza spółki podjęła uchwały o powołaniu zarządu KGHM.</p>

## Rywalka Donalda Trumpa wycofuje się z wyścigu
 - [https://www.bankier.pl/wiadomosc/Rywalka-Donalda-Trumpa-wycofuje-sie-z-wyscigu-8706547.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rywalka-Donalda-Trumpa-wycofuje-sie-z-wyscigu-8706547.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T15:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/873e35a0ceece3-948-568-0-45-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nikki Haley, jedyna pozostała konkurentka Donalda Trumpa w rywalizacji o nominację Partii Republikańskiej w wyborach prezydenckich w USA, w środę ogłosiła wycofanie się z wyścigu. Zawieszenie swojej kampanii ogłosiła dzień po serii przegranych prawyborów.</p>

## Zbigniew Bryja zrezygnował z rady nadzorczej KGHM i z delegowania do zarządu spółki
 - [https://www.bankier.pl/wiadomosc/Zbigniew-Bryja-zrezygnowal-z-rady-nadzorczej-KGHM-i-z-delegowania-do-zarzadu-spolki-8706514.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zbigniew-Bryja-zrezygnowal-z-rady-nadzorczej-KGHM-i-z-delegowania-do-zarzadu-spolki-8706514.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T14:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/b0dc388c05d645-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zbigniew Bryja zrezygnował z delegowania do czasowego wykonywania czynności prezesa i członków zarządu KGHM, oraz z pełnienia funkcji członka rady nadzorczej - poinformowała w środę spółka.</p>

## RPP podjęła decyzję ws. stóp procentowych i nie zaskoczyła rynku. Nikt nie liczył na obniżkę
 - [https://www.bankier.pl/wiadomosc/Rada-Polityki-Pienieznej-w-marcu-2024-nie-zmienila-stop-procentowych-8706241.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rada-Polityki-Pienieznej-w-marcu-2024-nie-zmienila-stop-procentowych-8706241.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T14:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/419d628b33ed77-948-568-525-487-2475-1484.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada Polityki Pieniężnej ponownie pozostawiła stopy
procentowe na niezmienionym poziomie. Nikt nie oczekiwał innej decyzji.</p>

## Prezydent powołał siedmiu nowych członków Państwowej Komisji Wyborczej
 - [https://www.bankier.pl/wiadomosc/Prezydent-powolal-siedmiu-nowych-czlonkow-Panstwowej-Komisji-Wyborczej-8706410.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-powolal-siedmiu-nowych-czlonkow-Panstwowej-Komisji-Wyborczej-8706410.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T13:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/b37440c95b44ba-948-568-4-385-1830-1098.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda powołał w środę w skład Państwowej Komisji Wyborczej: Mirosława Suskiego, Arkadiusza Pikulika, Konrada Składowskiego, Ryszarda Balickiego, Macieja Klisia, Pawła Gierasa i Ryszarda Kalisza. Ich kadencja w PKW rozpocznie się 14 marca.</p>

## Orlen pokazał wcześniej ukrywane dane. Marże wysokie, ale wyniki słabe
 - [https://www.bankier.pl/wiadomosc/Orlen-pokazal-wczesniej-ukrywane-dane-Marze-wysokie-ale-wyniki-slabe-8706379.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orlen-pokazal-wczesniej-ukrywane-dane-Marze-wysokie-ale-wyniki-slabe-8706379.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/77981639f698f2-948-568-0-150-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 5 marca Orlen zaczął publikować wybrane dane 
makroekonomiczne
w układzie miesięcznym, w tym modelową marżę rafineryjną. Wynika z nich 
między innymi, że przedwyborcze zaniżenie cen paliw skończyło
się niczym innym jak utraconymi zyskami dla akcjonariuszy spółki. Pisali
 o tym
analitycy już wcześniej, ale teraz wyraźnie widać, że zamiast zarabiać 
krocie, spółka
ledwo dowoziła wynik rafinerii dla swoich właścicieli.</p>

## Premia w kolejnym banku. Do zgarnięcia łatwe 300 zł
 - [https://www.bankier.pl/wiadomosc/PKO-Bank-Polski-zaplaci-do-300-zl-za-konto-Sprawdz-warunki-promocji-8706389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-Bank-Polski-zaplaci-do-300-zl-za-konto-Sprawdz-warunki-promocji-8706389.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T12:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/bfbedac4499e5e-948-568-0-165-1950-1170.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PKO Bank Polski to jeden z tych banków, które sporadycznie kuszą niezdecydowanych premią za założenie konta. Tym razem zainteresowani rachunkiem w tym banku mogą zyskać do 300 zł. Warunki ograniczają się do dokonywania płatności, logowania na konto i… wpisania kodu.</p>

## Będzie morski korytarz pomocy humanitarnej do Strefy Gazy? Chce tego UE
 - [https://www.bankier.pl/wiadomosc/Bedzie-morski-korytarz-pomocy-humanitarnej-do-Strefy-Gazy-Chce-tego-UE-8706381.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bedzie-morski-korytarz-pomocy-humanitarnej-do-Strefy-Gazy-Chce-tego-UE-8706381.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T12:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/fd25b323720fd9-948-568-0-151-2242-1345.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przewodnicząca Komisji Europejskiej Ursula von der Leyen odwiedzi w piątek Cypr, gdzie omówi z władzami tego kraju plany uruchomienia morskiego korytarza pomocy humanitarnej dla cywilów ze Strefy Gazy - powiadomiła w środę agencja Reutera.</p>

## Oszuści atakują klientów serwisu Booking.com. NASK ostrzega
 - [https://www.bankier.pl/wiadomosc/Oszusci-atakuja-klientow-serwisu-Booking-com-NASK-ostrzega-8706349.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oszusci-atakuja-klientow-serwisu-Booking-com-NASK-ostrzega-8706349.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T12:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/3/595dfe4de7469c-948-568-0-45-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Naukowa i Akademicka Sieć Komputerowa (NASK) ostrzega przed nowymi atakami na klientów Booking.com. Oszuści w ten sposób wyłudzają dane logowania do serwisu.</p>

## Rodzina zmarłej w Egipcie Magdaleny Żuk domaga się zadośćuczynienia od biura podróży. Ruszył proces
 - [https://www.bankier.pl/wiadomosc/Rodzina-zmarlej-w-Egipcie-Magdaleny-Zuk-domaga-sie-zadoscuczynienia-od-biura-podrozy-Ruszyl-proces-8706340.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rodzina-zmarlej-w-Egipcie-Magdaleny-Zuk-domaga-sie-zadoscuczynienia-od-biura-podrozy-Ruszyl-proces-8706340.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T12:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/b4729b20aaea7c-948-568-0-114-1702-1021.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przed Sądem Okręgowym w Łodzi ruszył w środę proces cywilny, w którym rodzina zmarłej w 2017 r. w Egipcie Magdaleny Żuk domaga się zadośćuczynienia od organizującego wyjazd biura podróży. Z powodu niestawienia się świadków rozprawę odroczono do 15 lipca.</p>

## TVN ukarany przez KRRiT za program "Bielmo. Franciszkańska 3". Stacja reaguje
 - [https://www.bankier.pl/wiadomosc/TVN-ukarany-przez-KRRiT-za-program-Bielmo-Franciszkanska-3-Stacja-reaguje-8706334.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/TVN-ukarany-przez-KRRiT-za-program-Bielmo-Franciszkanska-3-Stacja-reaguje-8706334.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T12:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/6/7fcb74cf5fce51-948-568-0-75-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przewodniczący Krajowej Rady Radiofonii i Telewizji Maciej Świrski nałożył sankcję pieniężną w wysokości 550 tys. zł na TVN24 za emisję filmu "Bielmo. Franciszkańska 3". Kara finansowa dla TVN24 jest kolejną próbą zastraszenia naszej i wielu innych redakcji"- poinformował redaktor naczelny TVN24 Michał Samul.</p>

## Schron dla wszystkich? Rząd myśli o nowym obowiązku dla deweloperów. "Ceny mieszkań poszybowałyby o kilkadziesiąt procent"
 - [https://www.bankier.pl/wiadomosc/Schron-dla-wszystkich-Rzad-mysli-o-nowym-obowiazku-dla-deweloperow-Ceny-mieszkan-poszybowalyby-o-kilkadziesiat-procent-8706308.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Schron-dla-wszystkich-Rzad-mysli-o-nowym-obowiazku-dla-deweloperow-Ceny-mieszkan-poszybowalyby-o-kilkadziesiat-procent-8706308.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T11:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/f/9cc8888f14d527-948-568-0-1290-2357-1414.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już nie tylko miejsce parkingowe, ale i schron. - 
Rozważamy wprowadzenie obowiązku dla deweloperów, aby - mówiąc krótko - w
 nowowybudowanych blokach były miejsca, które będą miały wszystkie 
budowlane parametry schronu - powiedział w wywiadzie dla RMF FM 
wiceminister obrony Paweł Zalewski z Polski 2050. </p>

## Co dalej ze stawką VAT na żywność? PiS prosi rząd o odmrożenie ich ustawy
 - [https://www.bankier.pl/wiadomosc/Co-dalej-ze-stawka-VAT-na-zywnosc-PiS-prosi-rzad-o-odmrozenie-ich-ustawy-8706321.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-dalej-ze-stawka-VAT-na-zywnosc-PiS-prosi-rzad-o-odmrozenie-ich-ustawy-8706321.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T11:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/0/ddffd544090817-948-568-0-137-2506-1503.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Posłowie PiS zaapelowali w środę do marszałka Sejmu Szymona Hołowni o "odmrożenie" ich projektu dotyczącego przedłużenia zerowej stawki VAT na żywność. To efekt wypowiedzi premiera Donalda Tuska dotyczącej tej sprawy.</p>

## Wysokość składek OC pójdzie w górę przez unijną dyrektywę? Ministerstwo Finansów uspokaja
 - [https://www.bankier.pl/wiadomosc/Wysokosc-skladek-OC-pojdzie-w-gore-przez-unijna-dyrektywe-Ministerstwo-Finansow-uspokaja-8706320.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wysokosc-skladek-OC-pojdzie-w-gore-przez-unijna-dyrektywe-Ministerstwo-Finansow-uspokaja-8706320.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T11:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/1ad788526f0d4b-945-567-0-103-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podwyższenie sum gwarancyjnych powinno mieć marginalny wpływ na wysokość składek OC - napisał resort finansów w ocenie skutków regulacji projektu ustawy implementującej dyrektywę UE w sprawie podwyższenia sum gwarancyjnych.</p>

## "Willa Plus". Prokuratura potwierdziła wszczęcie śledztwa ws. programu
 - [https://www.bankier.pl/wiadomosc/Willa-Plus-Prokuratura-potwierdzila-wszczecie-sledztwa-ws-programu-8706285.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Willa-Plus-Prokuratura-potwierdzila-wszczecie-sledztwa-ws-programu-8706285.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T11:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/b986b89042383d-948-568-0-44-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prokuratura Okręgowa w Warszawie potwierdziła wszczęcie śledztwa ws. programu ministerstwa edukacji, z którego do organizacji bliskich PiS miało trafić 40 mln zł.  Postępowanie toczy się w sprawie, co oznacza, że nikt nie usłyszał zarzutów.</p>

## ABW w Orlenie. Funkcjonariusze zabezpieczają dokumenty ws. fuzji z Lotosem
 - [https://www.bankier.pl/wiadomosc/ABW-w-Orlenie-Funkcjonariusze-zabezpieczaja-dokumenty-ws-fuzji-z-Lotosem-8706277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ABW-w-Orlenie-Funkcjonariusze-zabezpieczaja-dokumenty-ws-fuzji-z-Lotosem-8706277.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T11:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/ac6b1bb68cae02-948-568-0-240-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W biurach Orlenu w Płocku i w Warszawie, a także na terenie Gdańska funkcjonariusze ABW prowadzą w środę czynności związane z zabezpieczaniem materiału dowodowego w sprawie połączenia Orlenu z Grupą Lotos - poinformowała PAP zastępca prokuratora okręgowego w Płocku Monika Mieczykowska.</p>

## Siekierski: Doprowadziliśmy do istotnych ograniczeń Zielonego Ładu
 - [https://www.bankier.pl/wiadomosc/Siekierski-Doprowadzilismy-do-istotnych-ograniczen-Zielonego-Ladu-8706276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Siekierski-Doprowadzilismy-do-istotnych-ograniczen-Zielonego-Ladu-8706276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T10:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/22602b3cc9a342-948-568-0-227-4134-2480.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Premier Donald Tusk prowadzi rozmowy z rolnikami, Komisja Europejska zgodziła się na ustępstwa ws. Zielonego Ładu, prowadzone są rozmowy dwustronne z Ukrainą nt. wymiany handlowej - powiedział w środę w Sejmie minister rolnictwa Czesław Siekierski.</p>

## Spór o aborcję w Sejmie. "Zawsze jest dobry czas na prawa kobiet"
 - [https://www.bankier.pl/wiadomosc/Spor-o-aborcje-w-Sejmie-Zawsze-jest-dobry-czas-na-prawa-kobiet-8706249.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spor-o-aborcje-w-Sejmie-Zawsze-jest-dobry-czas-na-prawa-kobiet-8706249.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T10:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/07d842294cc5be-948-568-0-0-3360-2015.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Projekty dotyczące przerywania ciąży mają być procedowane w Sejmie 11 kwietnia. Problem nie jest we mnie; problem jest w tym, czy jest dziś polityczna zgoda, by potraktować kobiety tak, jak na to zasługują, i prawo zmienić – powiedział w środę marszałek Sejmu Szymon Hołownia.</p>

## Resort pracy: Wakacje od ZUS-u de facto obciążą innych podatników
 - [https://www.bankier.pl/wiadomosc/Resort-pracy-Wakacje-od-ZUS-u-de-facto-obciaza-innych-podatnikow-8706244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Resort-pracy-Wakacje-od-ZUS-u-de-facto-obciaza-innych-podatnikow-8706244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T10:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/8/47e742c9b2332d-945-560-0-0-1227-736.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ciężar tzw. wakacji składkowych dla 
mikroprzedsiębiorców ma przejąć budżet państwa, więc koszt ich 
sfinansowania zostanie przeniesiony na inne podmioty płacące podatki, 
którzy zostaną oskładkowani niejako podwójnie - ocenia Ministerstwo 
Rodziny, Pracy i Polityki Społecznej w uwagach do projektu ustawy.</p>

## Revolut ułatwi zakup kryptowalut bezpośrednio do portfeli MetaMask
 - [https://www.bankier.pl/wiadomosc/Revolut-ulatwi-zakup-kryptowalut-bezposrednio-do-portfeli-MetaMask-8706194.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Revolut-ulatwi-zakup-kryptowalut-bezposrednio-do-portfeli-MetaMask-8706194.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T10:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/1/a52fc863364e86-948-568-0-140-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gdy rynek kryptowalut bije rekordy, fintechy wzbogacają ofertę dla inwestorów w cyfrowe aktywa. Revolut uruchomił właśnie nową usługę, która ułatwi zakup cyfrowych aktywów bezpośrednio do portfeli MetaMask. </p>

## "NYT": Trump spotkał się z Muskiem. Pilnie poszukuje pieniędzy na swoją kampanię
 - [https://www.bankier.pl/wiadomosc/WSJ-Trump-spotkal-sie-z-Muskiem-Pilnie-poszukuje-pieniedzy-na-swoja-kampanie-8706237.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/WSJ-Trump-spotkal-sie-z-Muskiem-Pilnie-poszukuje-pieniedzy-na-swoja-kampanie-8706237.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T10:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/1/2b9f72c06392f0-948-568-0-500-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były prezydent USA Donald Trump, który poszukuje 
sposobu na sfinansowanie kampanii wyborczej w kontekście prawdopodobnej 
rywalizacji o urząd głowy państwa z Joe Bidenem, spotkał się w niedzielę
 z miliarderem Elonem Muskiem; nie jest jednak jasne, czy Musk poprze 
Trumpa - poinformował dziennik "New York Times".</p>

## Kurs euro bez większych zmian. Frank najtańszy od listopada
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-Frank-najtanszy-od-listopada-8706205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-Frank-najtanszy-od-listopada-8706205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T09:10:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/20bf26ad73769b-948-568-297-457-3954-2372.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro utrzymywał się powyżej 4,30 zł w oczekiwaniu na
popołudniowy komunikat z Rady Polityki Pieniężnej.</p>

## Monika Pawłowska objęła mandat po Mariuszu Kamińskim. Złożyła ślubowanie poselskie
 - [https://www.bankier.pl/wiadomosc/Monika-Pawlowska-objela-mandat-po-Mariuszu-Kaminskim-Zlozyla-slubowanie-poselskie-8706202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Monika-Pawlowska-objela-mandat-po-Mariuszu-Kaminskim-Zlozyla-slubowanie-poselskie-8706202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T09:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/b/5b1b90694cac95-948-568-0-96-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę po rozpoczęciu posiedzenia Sejmu ślubowanie złożyła posłanka Monika Pawłowska, która objęła mandat poselski po Mariuszu Kamińskim.</p>

## IFC: Polska potrzebuje setek miliardów euro inwestycji w związku zieloną transformacją
 - [https://www.bankier.pl/wiadomosc/IFC-Polska-potrzebuje-setek-miliardow-euro-inwestycji-w-zwiazku-zielona-transformacja-8706199.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/IFC-Polska-potrzebuje-setek-miliardow-euro-inwestycji-w-zwiazku-zielona-transformacja-8706199.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/0f328a008e096b-948-568-600-0-3400-2039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sektor bankowy w Polsce jest silny, ale biorąc pod uwagę potrzeby kapitałowe związane z zieloną transformacją, potrzeba silniejszego rynku finansowego i rynku kapitałowego – powiedział PAP Biznes Ary Naim, menedżer regionalny w IFC z Grupy Banku Światowego. Polskie potrzeby inwestycyjne w tym zakresie mogą wynosić setki miliardów euro – dodał.</p>

## UE wytacza działa. Nadchodzą karne cła na chińskie samochody elektryczne
 - [https://www.bankier.pl/wiadomosc/UE-wytacza-dziala-Nadchodza-karne-cla-na-chinskie-samochody-elektryczne-8706153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UE-wytacza-dziala-Nadchodza-karne-cla-na-chinskie-samochody-elektryczne-8706153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/f/cb61c7d1293ea6-948-567-0-54-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wszystkie pojazdy elektryczne, które trafią do Unii Europejskiej z Chin po 6 marca 2024 roku, mogą zostać dotknięte karnymi cłami antysubsydyjnymi. Wspólnota rozpocznie od czwartku rejestrację celną importu elektryków z Państwa Środka - podała agencja Reutera.</p>

## Zwolnili 10 proc. załogi z dnia na dzień. Teraz pracownicy Aptiv założyli związek zawodowy
 - [https://www.bankier.pl/wiadomosc/Pracownicy-Aptiv-zalozyli-zwiazek-zawodowy-Wczesniej-firma-zwolnila-10-proc-zalogi-8706163.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pracownicy-Aptiv-zalozyli-zwiazek-zawodowy-Wczesniej-firma-zwolnila-10-proc-zalogi-8706163.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T08:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/c76caa157e801b-948-568-0-81-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po ostatnich zwolnieniach grupowych w krakowskim 
oddziale firmy Aptiv pracownicy założyli związek zawodowy. "Teraz mają 
do kogo się zwrócić o wsparcie nie tylko w zakresie zwolnień" - 
podkreśla OPZZ Konfederacja Pracy.</p>

## Elon Musk nie jest już najbogatszym człowiekiem na świecie. Nie jest nawet drugi
 - [https://www.bankier.pl/wiadomosc/Elon-Musk-nie-jest-juz-najbogatszym-czlowiekiem-na-swiecie-Nie-jest-nawet-drugi-8706192.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Elon-Musk-nie-jest-juz-najbogatszym-czlowiekiem-na-swiecie-Nie-jest-nawet-drugi-8706192.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T08:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/4/86c2188bcb6e91-948-568-26-26-3473-2084.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jak wynika
ze sporządzanego na bieżąco rankingu Bloomberga, obecnie najbogatszym
człowiekiem świata jest Jeff Bezos,
założyciel Amazona. Z kolei
na drugim miejscu uplasował się Bernard Arnault, właściciel firmy LVMH,
zajmującej się towarami luksusowymi. Elon Musk spadł na trzecią pozycję.</p>

## Ujawnił tajne informacje o wojnie na Ukrainie na portalu randkowym, został aresztowany
 - [https://www.bankier.pl/wiadomosc/Ujawnil-tajne-informacje-o-wojnie-na-Ukrainie-na-portalu-randkowym-zostal-aresztowany-8706021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ujawnil-tajne-informacje-o-wojnie-na-Ukrainie-na-portalu-randkowym-zostal-aresztowany-8706021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T08:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/c/b031195d7fee50-948-568-20-190-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />63-letni emerytowany podpułkownik wojsk lądowych USA David Slater został aresztowany i usłyszał zarzuty przekazywania informacji niejawnych kobiecie poznanej na zagranicznym portalu randkowym - poinformował resort sprawiedliwości USA. Mężczyzna ujawniał tajne dane m.in. na temat rosyjskiego wojska.</p>

## Musk znów pozwany. Nie zapłacił odpraw zwolnionym dyrektorom Twittera, teraz żądają milionów dolarów
 - [https://www.bankier.pl/wiadomosc/Musk-znow-pozwany-Nie-zaplacil-odpraw-zwolnionym-dyrektorom-Twittera-teraz-zadaja-milionow-dolarow-8706142.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Musk-znow-pozwany-Nie-zaplacil-odpraw-zwolnionym-dyrektorom-Twittera-teraz-zadaja-milionow-dolarow-8706142.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T08:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/e18c7fbe9d110a-948-568-0-333-3600-2159.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeden z najbogatszych ludzi świata zmierzy się w 
sądzie z byłymi dyrektorami Twittera (obecnie X). Pozywają oni Elona 
Muska o niezapłacone odprawy, których suma wynosi 128 mln dolarów. 
</p>

## Ukraina będzie honorować wyroki polskiego sądu wobec swoich obywateli
 - [https://www.bankier.pl/wiadomosc/Ukraina-bedzie-honorowac-wyroki-polskiego-sadu-wobec-swoich-obywateli-8706122.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-bedzie-honorowac-wyroki-polskiego-sadu-wobec-swoich-obywateli-8706122.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T06:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/9/bfc548bcd2df67-945-567-0-0-2188-1313.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wyroki wydane w Polsce wobec obywateli Ukrainy będą uznawane i egzekwowane w ich państwie. Zmiany wymusiła duża liczba skazanych w ostatnich latach, którzy przed wykonaniem kary orzeczonej przez polski sąd powrócili do Ukrainy - pisze w środę "Rzeczpospolita".</p>

## Podwójna ulga dla przedsiębiorców. Kasowy nie tylko PIT, ale też składka zdrowotna
 - [https://www.bankier.pl/wiadomosc/Podwojna-ulga-dla-przedsiebiorcow-Kasowy-nie-tylko-PIT-ale-tez-skladka-zdrowotna-8706120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podwojna-ulga-dla-przedsiebiorcow-Kasowy-nie-tylko-PIT-ale-tez-skladka-zdrowotna-8706120.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T06:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/b/9860762cb28382-948-568-0-570-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeśli przedsiębiorca wybierze kasowe rozliczenie i nie dostanie pieniędzy od kontrahenta, podatek zapłaci dopiero po dwóch latach. Ulga będzie też na składkę zdrowotną - pisze w środę "Rzeczpospolita".</p>

## Ponad 8 lat sporów wokół Trybunału Konstytucyjnego. Przed nami kolejna ich odsłona
 - [https://www.bankier.pl/wiadomosc/Ponad-8-lat-sporow-wokol-Trybunalu-Konstytucyjnego-Przed-nami-kolejna-ich-odslona-8706106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ponad-8-lat-sporow-wokol-Trybunalu-Konstytucyjnego-Przed-nami-kolejna-ich-odslona-8706106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/7ddfbb14802b03-945-567-15-63-1450-870.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm w tym tygodniu ma rozpocząć debatę nad reformą Trybunału Konstytucyjnego. W poniedziałek większość rządząca przedstawiła projekty uchwały, dwóch ustaw oraz propozycji zmiany konstytucji. Spór wokół TK trwa od ponad ośmiu lat, a jego korzenie sięgają wyboru sędziów dokonanego jesienią 2015 r.</p>

## Mekka polskiej turystyki? Tatry nadal rekordowo popularne
 - [https://www.bankier.pl/wiadomosc/Mekka-polskiej-turystyki-Tatry-nadal-rekordowo-popularne-8706101.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mekka-polskiej-turystyki-Tatry-nadal-rekordowo-popularne-8706101.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/b/757364e0dd9578-948-568-0-97-1779-1067.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />4 mln 510 tys. turystów odwiedziło Tatrzański Park Narodowy w 2023 r. – wynika z danych TPN. Najwięcej wejść, ponad 912 tys., odnotowano w sierpniu, a największą popularnością cieszy się nieprzerwanie Morskie Oko i Kasprowy Wierch.</p>

## Trump i Biden zdominowali "superwtorek", lecz ponieśli też porażki
 - [https://www.bankier.pl/wiadomosc/Trump-i-Biden-zdominowali-superwtorek-lecz-poniesli-tez-porazki-8706100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trump-i-Biden-zdominowali-superwtorek-lecz-poniesli-tez-porazki-8706100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/9795fceabf6540-948-568-0-134-1634-980.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były prezydent Donald Trump wygrał 12 z 13 rozstrzygniętych wtorkowych prawyborów Partii Republikańskiej w ramach "superwtorku", zaś prezydent Joe Biden - 15 z 16 rozstrzygniętych prawyborów Demokratów. Obaj są w efekcie praktycznie pewni nominacji swoich partii w listopadowych wyborach prezydenckich.</p>

## Praca zdalna wcale nie taka bezpieczna? Nowe dane o wypadkach i ofiarach śmiertelnych podczas home office
 - [https://www.bankier.pl/wiadomosc/Praca-zdalna-wcale-nie-taka-bezpieczna-Nowe-dane-o-wypadkach-i-ofiarach-smiertelnych-podczas-home-office-8706091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Praca-zdalna-wcale-nie-taka-bezpieczna-Nowe-dane-o-wypadkach-i-ofiarach-smiertelnych-podczas-home-office-8706091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/1/6a7df8dc58abc5-948-568-30-120-3970-2381.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2023 r. do Państwowej Inspekcji Pracy zgłoszono pięć wypadków przy pracy zdalnej. Na pięć osób poszkodowanych cztery poniosły śmierć, a jedna była ciężko ranna - wynika z informacji przekazanej PAP przez Główny Inspektorat Pracy.</p>

## Kolejny protest rolników w Warszawie. Szykują się spore utrudnienia w ruchu
 - [https://www.bankier.pl/wiadomosc/Protest-rolnikow-w-Warszawie-Utrudnienia-w-ruchu-8706089.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Protest-rolnikow-w-Warszawie-Utrudnienia-w-ruchu-8706089.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/4/8a841a6b2e3271-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Warszawy Rafał Trzaskowski zaapelował, by w środę korzystać z komunikacji miejskiej. Ratusz i policja uprzedzają, że mogą pojawić się utrudnienia w ruchu w związku ze zgłoszonymi manifestacjami.</p>

## Coraz trudniej o mieszkanie za mniej niż 10 tys. zł/mkw.
 - [https://www.bankier.pl/wiadomosc/Coraz-trudniej-o-mieszkanie-za-mniej-niz-10-tys-zl-mkw-8705639.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-trudniej-o-mieszkanie-za-mniej-niz-10-tys-zl-mkw-8705639.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/9/95098ca06f0252-948-568-0-619-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Początek 2024 r. przyniósł dalsze wypieranie z ogłoszeń mieszkań wycenianych na mniej niż 10 tys. zł/mkw. – wynika z danych Rynku Pierwotnego. Rośnie za to udział mieszkań najdroższych, wycenianych na więcej niż 15 tys. zł/mkw.</p>

## Gdy prywatne życie staje się marginesem. Uwaga na pracoholizm
 - [https://www.bankier.pl/wiadomosc/Gdy-prywatne-zycie-staje-sie-marginesem-Uwaga-na-pracoholizm-8705947.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gdy-prywatne-zycie-staje-sie-marginesem-Uwaga-na-pracoholizm-8705947.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/13618170c05dee-948-568-0-75-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Według badań CBOS nawet 11 proc.
Polaków, czyli około 2,5 mln osób, może być dotkniętych pracoholizmem. Jeśli
Twoje życie jest kartką i tylko ta niewielka cześć za narysowanym na niej
marginesem to Twoje życie prywatne – to masz problem.</p>

## Kryzys w największej gospodarce Afryki. Terapia szokowa nie pomogła, mieszkańcy wyszli na ulice
 - [https://www.bankier.pl/wiadomosc/Kryzys-w-najwiekszej-gospodarce-Afryki-Terapia-szokowa-nie-pomogla-mieszkancy-wyszli-na-ulice-8703482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kryzys-w-najwiekszej-gospodarce-Afryki-Terapia-szokowa-nie-pomogla-mieszkancy-wyszli-na-ulice-8703482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/bcba87aee8dd59-948-568-7-119-2992-1795.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nigeria - największa gospodarka Afryki i najludniejszy kraj na kontynencie - zmaga się z potężnym kryzysem finansowym, dwucyfrową inflacją i olbrzymim bezrobociem. Sytuacja w kraju gwałtownie pogorszyła się w ciągu ostatnich miesięcy, a jego mieszkańcy wyszli na ulice. Korzenie problemów są jednak stare jak nigeryjska niepodległość.</p>

## Najlepsze TERAZ lokaty bankowe. Stawka rośnie do 8 proc. w skali roku
 - [https://www.bankier.pl/wiadomosc/Najlepsze-TERAZ-lokaty-bankowe-marzec-2024-r-8705672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-TERAZ-lokaty-bankowe-marzec-2024-r-8705672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/a/d0303bdb0ea55d-948-568-140-50-1860-1115.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od niedawna ponownie można zyskać na lokacie terminowej 8 proc. w skali roku. Taką stawkę ma promocyjna lokata, do której bank postanowił powrócić po kilku miesiącach. Aby ją otworzyć, trzeba przygotować się na spełnienie kilku dodatkowych wymogów.</p>

## To może być początek Doliny Fintechowej w Polsce. Co z regulacją MiCA zrobi rząd i KNF?
 - [https://www.bankier.pl/wiadomosc/To-moze-byc-poczatek-Doliny-Fintechowej-w-Polsce-Co-z-regulacja-MiCA-zrobi-rzad-i-KNF-8705606.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/To-moze-byc-poczatek-Doliny-Fintechowej-w-Polsce-Co-z-regulacja-MiCA-zrobi-rzad-i-KNF-8705606.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/329cf9b5fd1bcf-948-568-0-210-3368-2020.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mamy talenty, technologię i wiedzę, by na lata stać się
beneficjentem fintechowej fali w Europie. Okazja do przyjęcia nowych regulacji prawnych nadchodzi wraz z
nieuchronnym wdrożeniem unijnego rozporządzenia MiCA. Pytanie, czy rządzący,
jak i nadzór finansowy są otwarte na zmiany i chcą budować nowy segment
polskiej gospodarki. </p>

## Zwiększone ambicje w polskim planie na rzecz energii i klimatu
 - [https://www.bankier.pl/wiadomosc/Zwiekszone-ambicje-w-polskim-planie-na-rzecz-energii-i-klimatu-8706086.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zwiekszone-ambicje-w-polskim-planie-na-rzecz-energii-i-klimatu-8706086.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-03-06T04:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/594a9883a3004c-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Większa redukcja emisji, wzrost udziału energii z OZE, spadek wydobycia węgla znalazły się w najnowszej wersji polskiego Krajowego Planu na rzecz Energii i Klimatu (KPEiK) do 2030 r., który trafił do Komisji Europejskiej i został przez nią opublikowany.</p>

