# Source:Daily sceptic, URL:https://dailysceptic.org/feed, language:en-US

## Trans Influencer Axed by Doritos for Violent Comments About Children
 - [https://dailysceptic.org/2024/03/06/trans-influencer-axed-by-doritos-for-violent-comments-about-children](https://dailysceptic.org/2024/03/06/trans-influencer-axed-by-doritos-for-violent-comments-about-children)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-03-06T19:30:00+00:00

<p>Doritos sacked a transgender influencer after finding out he had written social media posts threatening to do "thuggish things" to a 12-year-old girl.</p>
<p>The post <a href="https://dailysceptic.org/2024/03/06/trans-influencer-axed-by-doritos-for-violent-comments-about-children/">Trans Influencer Axed by Doritos for Violent Comments About Children</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## France Enjoys Electricity Prices 41% Cheaper Than Germany Thanks to Nuclear Industry
 - [https://dailysceptic.org/2024/03/06/france-enjoys-electricity-prices-41-cheaper-than-germany-thanks-to-nuclear-industry](https://dailysceptic.org/2024/03/06/france-enjoys-electricity-prices-41-cheaper-than-germany-thanks-to-nuclear-industry)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-03-06T17:43:08+00:00

<p>France enjoys electricity prices 41% cheaper than Germany thanks to its nuclear industry, while Germany becomes increasingly dependent on unreliable renewables and environmentally harmful biomass.</p>
<p>The post <a href="https://dailysceptic.org/2024/03/06/france-enjoys-electricity-prices-41-cheaper-than-germany-thanks-to-nuclear-industry/">France Enjoys Electricity Prices 41% Cheaper Than Germany Thanks to Nuclear Industry</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Priest Faces Up to Three Years in Jail on “Hate Crime” Charges for Criticising Islam
 - [https://dailysceptic.org/2024/03/06/priest-faces-up-to-three-years-in-jail-on-hate-crime-charges-for-criticising-islam](https://dailysceptic.org/2024/03/06/priest-faces-up-to-three-years-in-jail-on-hate-crime-charges-for-criticising-islam)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-03-06T15:31:21+00:00

<p>A Spanish priest is facing up to three years in prison on "hate crime" charges for his heated words about Islam. "There is no longer any true right to free speech in Spain," he said.</p>
<p>The post <a href="https://dailysceptic.org/2024/03/06/priest-faces-up-to-three-years-in-jail-on-hate-crime-charges-for-criticising-islam/">Priest Faces Up to Three Years in Jail on &#8220;Hate Crime&#8221; Charges for Criticising Islam</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## The Pathologisation of Prosperity
 - [https://dailysceptic.org/2024/03/06/the-pathologisation-of-prosperity](https://dailysceptic.org/2024/03/06/the-pathologisation-of-prosperity)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-03-06T13:21:36+00:00

<p>Britain needs to bring in negative interest rates via digital currency, raise taxes and increase inflation, according to Jeremy Hunt's economic adviser. Why have the Tories turned their backs on prosperity?</p>
<p>The post <a href="https://dailysceptic.org/2024/03/06/the-pathologisation-of-prosperity/">The Pathologisation of Prosperity</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Migrants Are So Miserable in Britain They’re Desperate to Leave – But We Won’t Let Them
 - [https://dailysceptic.org/2024/03/06/migrants-are-so-miserable-in-britain-theyre-desperate-to-leave-but-we-wont-let-them](https://dailysceptic.org/2024/03/06/migrants-are-so-miserable-in-britain-theyre-desperate-to-leave-but-we-wont-let-them)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-03-06T11:00:00+00:00

<p>A growing number of illegal migrants are finding life in Britain so miserable, they’re desperate to leave. But we won’t let them. Michael Deacon wonders why the British state doesn't have the basic decency to let them go.</p>
<p>The post <a href="https://dailysceptic.org/2024/03/06/migrants-are-so-miserable-in-britain-theyre-desperate-to-leave-but-we-wont-let-them/">Migrants Are So Miserable in Britain They&#8217;re Desperate to Leave – But We Won&#8217;t Let Them</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Lockdowns Are a “Failed Experiment”, Welsh First Minister Tells Covid Inquiry
 - [https://dailysceptic.org/2024/03/06/lockdowns-are-a-failed-experiment-welsh-first-minister-tells-covid-inquiry](https://dailysceptic.org/2024/03/06/lockdowns-are-a-failed-experiment-welsh-first-minister-tells-covid-inquiry)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-03-06T09:00:00+00:00

<p>Wales's First Minister Mark Drakeford has told the Covid Inquiry that local Covid lockdowns were a "failed experiment". If they were an experiment, where was the consent, ask Carl Heneghan and Tom Jefferson.</p>
<p>The post <a href="https://dailysceptic.org/2024/03/06/lockdowns-are-a-failed-experiment-welsh-first-minister-tells-covid-inquiry/">Lockdowns Are a &#8220;Failed Experiment&#8221;, Welsh First Minister Tells Covid Inquiry</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Population is Not Being Told the True Cost of Net Zero, Warns Former World Bank Economist
 - [https://dailysceptic.org/2024/03/06/population-is-not-being-told-the-true-cost-of-net-zero-warns-former-world-bank-economist](https://dailysceptic.org/2024/03/06/population-is-not-being-told-the-true-cost-of-net-zero-warns-former-world-bank-economist)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-03-06T07:00:00+00:00

<p>The population is not being told the truth about the real cost of Net Zero, a former World Bank economist has warned. It will require at least 5% of GDP for the next 20 years – and savage cuts in living standards.</p>
<p>The post <a href="https://dailysceptic.org/2024/03/06/population-is-not-being-told-the-true-cost-of-net-zero-warns-former-world-bank-economist/">Population is Not Being Told the True Cost of Net Zero, Warns Former World Bank Economist</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## News Round-Up
 - [https://dailysceptic.org/2024/03/06/news-round-up-1089](https://dailysceptic.org/2024/03/06/news-round-up-1089)
 - RSS feed: https://dailysceptic.org/feed
 - date published: 2024-03-06T00:55:57+00:00

<p>A summary of the most interesting stories in the past 24 hours that challenge the prevailing orthodoxy about the virus and the vaccines, the ‘climate emergency’ and the supposed moral defects of Western civilisation.</p>
<p>The post <a href="https://dailysceptic.org/2024/03/06/news-round-up-1089/">News Round-Up</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

