# Source:Lindsey Stirling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g, language:en-US

## Fri 3/8 @ 9am PT - music video premiere for Eye Of The Untold Her #newmusicvideo #newmusic
 - [https://www.youtube.com/watch?v=pdO5J-rU-Qs](https://www.youtube.com/watch?v=pdO5J-rU-Qs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g
 - date published: 2024-03-06T17:41:53+00:00



