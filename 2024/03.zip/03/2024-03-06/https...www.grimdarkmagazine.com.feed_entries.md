# Source:Grimdark Magazine, URL:https://www.grimdarkmagazine.com/feed, language:en-AU

## REVIEW: Venom & Vow by Anna-Marie McLemore and Elliot McLemore
 - [https://www.grimdarkmagazine.com/review-venom-vow-by-anna-marie-mclemore-and-elliot-mclemore](https://www.grimdarkmagazine.com/review-venom-vow-by-anna-marie-mclemore-and-elliot-mclemore)
 - RSS feed: https://www.grimdarkmagazine.com/feed
 - date published: 2024-03-06T03:50:58+00:00

<p>I have long been a fan of Anna-Marie McLemore’s writing. Their work is haunting and lyrical, language as beautiful as the stories are impactful. In a bit of a change from their previous work, Venom &#38; Vow is cowritten with their husband, Elliot McLemore. Venom &#38; Vow is queer, incisive and full of murky morality. Deception is core to characters and plot – taking queer gender expression as a means to deceive as well as explore identity. Not all is well in the world of Venom &#38; Vow. Cade McKenna is a transgender prince, pretending to be his brother in public. Patrick McKenna is the unwilling heir to the throne, desperate to escape his duties. Valencia Palafox is a lady-in-waiting attending the future queen of Eliana – an enemy country. Gael Palma is an infamous assassin. Sounds like a lot of characters, but it breaks down to two – a transgender prince and a bigender assassin/lady. For the most part, the story progresses along expected paths. Patrick and Valencia mee

