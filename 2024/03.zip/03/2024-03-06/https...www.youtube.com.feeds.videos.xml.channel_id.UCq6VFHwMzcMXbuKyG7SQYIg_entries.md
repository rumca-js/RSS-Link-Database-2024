# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## Goodbye Rooster Teeth
 - [https://www.youtube.com/watch?v=J1qGCpkm7t0](https://www.youtube.com/watch?v=J1qGCpkm7t0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-03-06T20:30:01+00:00

This is the greatest content group of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/?ref=moist

## Opinions Are Weapons
 - [https://www.youtube.com/watch?v=_8BEwu77t1I](https://www.youtube.com/watch?v=_8BEwu77t1I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-03-06T02:45:03+00:00

Spotify link
https://open.spotify.com/album/4HorYdbljaBkrDkawwLtUk?si=Uzz1iWLaSLu8WtpERjrhCw&amp;nd=1Ep Bundle Link:
https://the-gentlemen-merch-shop.myshopify.com/products/the-gentle-men-ep-bundle
 streaming services link:
https://linktr.ee/TheGentleMen
Lyrics and vocals by me and Troy McKubre of Solstate
Music by Troy McKubre of Solstate
Solstate: https://www.youtube.com/@UCKLX_ObUa9pf1QwSGya0vAw 
This is the greatest opinion moment of All Time

