# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## Developers don’t need performance reviews
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64430](https://www.codeproject.com/script/News/View.aspx?nwid=64430)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

No one *needs* them

## GitHub kills 'Copilot Voice' tool
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64423](https://www.codeproject.com/script/News/View.aspx?nwid=64423)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

Developers would rather just talk to themselves

## Google takes aim at SEO-optimized junk pages and spam with new search update
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64429](https://www.codeproject.com/script/News/View.aspx?nwid=64429)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

Barn door closed? Check. Now, where's the horse?

## Google will pay you $5 million to figure out what the hell quantum computers do
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64427](https://www.codeproject.com/script/News/View.aspx?nwid=64427)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

And then some magic happens. (I'll send my deposit information separately)

## Hackers exploited Windows 0-day for 6 months after Microsoft knew of it
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64425](https://www.codeproject.com/script/News/View.aspx?nwid=64425)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

Security is our first...main...major...*a* priority

## Microsoft is killing support for running Android apps on Windows 11
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64421](https://www.codeproject.com/script/News/View.aspx?nwid=64421)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

Now how am I supposed to play Candy Crush?

## Modern currency
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64424](https://www.codeproject.com/script/News/View.aspx?nwid=64424)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00



## NASA really made its own tabletop RPG for you to play
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64431](https://www.codeproject.com/script/News/View.aspx?nwid=64431)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

Roll D20 to launch

## New Monitor Advice
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64420](https://www.codeproject.com/script/News/View.aspx?nwid=64420)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

Hercules Graphics OK?

## Thanks to AI, the coder is no longer king: All hail the QA engineer
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64428](https://www.codeproject.com/script/News/View.aspx?nwid=64428)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

Someone has to make sure the AI-generated code actually works

## The AI wars heat up with Claude 3, claimed to have “near-human” abilities
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64426](https://www.codeproject.com/script/News/View.aspx?nwid=64426)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

This week's delivery from the AI of the Week Club

## Windows 11 is reportedly getting 'AI File Explorer'
 - [https://www.codeproject.com/script/News/View.aspx?nwid=64422](https://www.codeproject.com/script/News/View.aspx?nwid=64422)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-03-06T05:00:00+00:00

Is that you, Clippy?

