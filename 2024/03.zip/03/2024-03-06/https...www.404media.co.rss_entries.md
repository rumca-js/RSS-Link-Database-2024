# Source:404 Media, URL:https://www.404media.co/rss, language:en

## Governor Says National Guard, More Surveillance Coming to NYC Subways
 - [https://www.404media.co/governor-says-national-guard-more-surveillance-coming-to-nyc-subways](https://www.404media.co/governor-says-national-guard-more-surveillance-coming-to-nyc-subways)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-03-06T19:02:16+00:00

Governor Kathy Hochul announced "a new program bill that will allow judges to ban people convicted of an assault within the system from using MTA services as part of sentencing."

## LA Car Culture Warriors In Shambles After Overwhelming Vote for New Bike Lines
 - [https://www.404media.co/nimbys-in-shambles-after-la-overwhelmingly-votes-for-new-bike-lanes](https://www.404media.co/nimbys-in-shambles-after-la-overwhelmingly-votes-for-new-bike-lanes)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-03-06T18:58:48+00:00

A survey of Nextdoor users losing their minds after voters overwhelmingly supported HLA, which will add new bike and bus lanes.

## Join 404 Media's Third FOIA Forum Here
 - [https://www.404media.co/join-404-medias-third-foia-forum-here](https://www.404media.co/join-404-medias-third-foia-forum-here)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-03-06T18:50:20+00:00

Here's the link to our third FOIA Forum.

## Podcast: AI-Powered TikTok Hustlers
 - [https://www.404media.co/404-media-podcast-28-ai-powered-tiktok-hustlers](https://www.404media.co/404-media-podcast-28-ai-powered-tiktok-hustlers)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-03-06T14:04:16+00:00

The wild world of AI-powered content hustlers on TikTok and Instagram; Etsy ripoffs; and a development in Oregon that could have global ramifications for Apple.

