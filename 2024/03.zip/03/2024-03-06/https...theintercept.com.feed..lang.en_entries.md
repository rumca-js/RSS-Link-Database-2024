# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Rep. Josh Gottheimer Goes to War Against High Schoolers Protesting for Gaza
 - [https://theintercept.com/2024/03/06/nj-josh-gottheimer-high-school-protest-gaza-israel](https://theintercept.com/2024/03/06/nj-josh-gottheimer-high-school-protest-gaza-israel)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-03-06T22:32:02+00:00

<p>While Congress has obsessed over Palestine solidarity protests on college campuses, Gottheimer’s fixation on high school students is unusual.</p>
<p>The post <a href="https://theintercept.com/2024/03/06/nj-josh-gottheimer-high-school-protest-gaza-israel/">Rep. Josh Gottheimer Goes to War Against High Schoolers Protesting for Gaza</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## How Homeland Security Is Undermining Faith in U.S. Elections
 - [https://theintercept.com/2024/03/06/homeland-security-us-elections](https://theintercept.com/2024/03/06/homeland-security-us-elections)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-03-06T22:07:29+00:00

<p>Voters are being told that the election system is both under attack and vulnerable to manipulation.</p>
<p>The post <a href="https://theintercept.com/2024/03/06/homeland-security-us-elections/">How Homeland Security Is Undermining Faith in U.S. Elections</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## The Informant at the Heart of the Gretchen Whitmer Kidnapping Plot Was a Liability. So Federal Agents Shut Him Up.
 - [https://theintercept.com/2024/03/06/gretchen-whitmer-kidnapping-informant](https://theintercept.com/2024/03/06/gretchen-whitmer-kidnapping-informant)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-03-06T18:30:21+00:00

<p>Internal FBI reports and undercover recordings reveal that federal agents were concerned about entrapment claims.</p>
<p>The post <a href="https://theintercept.com/2024/03/06/gretchen-whitmer-kidnapping-informant/">The Informant at the Heart of the Gretchen Whitmer Kidnapping Plot Was a Liability. So Federal Agents Shut Him Up.</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## George Latimer Awarded County Jail Contracts to Private Firms That Donated to His Campaign
 - [https://theintercept.com/2024/03/06/george-latimer-jail-contracts-wellpath-donation](https://theintercept.com/2024/03/06/george-latimer-jail-contracts-wellpath-donation)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-03-06T14:01:17+00:00

<p>As Westchester County executive, New York Rep. Jamaal Bowman’s primary opponent received thousands from Aramark and Wellpath.</p>
<p>The post <a href="https://theintercept.com/2024/03/06/george-latimer-jail-contracts-wellpath-donation/">George Latimer Awarded County Jail Contracts to Private Firms That Donated to His Campaign</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## U.S. Endorses Pakistan’s Sham Election
 - [https://theintercept.com/2024/03/06/intercepted-pakistans-sham-election](https://theintercept.com/2024/03/06/intercepted-pakistans-sham-election)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-03-06T11:00:00+00:00

<p>Allegations of widespread electoral fraud, rigging, and violence mar Pakistan’s election. </p>
<p>The post <a href="https://theintercept.com/2024/03/06/intercepted-pakistans-sham-election/">U.S. Endorses Pakistan’s Sham Election</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## Leaked U.S. Cable: Israeli Invasion of Rafah Would Have “Catastrophic Humanitarian Consequences”
 - [https://theintercept.com/2024/03/05/israel-rafah-humanitarian-aid-us-cable](https://theintercept.com/2024/03/05/israel-rafah-humanitarian-aid-us-cable)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-03-06T00:28:18+00:00

<p>With 1.5 million Palestinians trapped in Rafah, a leaked U.S. diplomatic cable says an Israeli offensive would cut off all aid and seize an already collapsed health system. </p>
<p>The post <a href="https://theintercept.com/2024/03/05/israel-rafah-humanitarian-aid-us-cable/">Leaked U.S. Cable: Israeli Invasion of Rafah Would Have “Catastrophic Humanitarian Consequences”</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

