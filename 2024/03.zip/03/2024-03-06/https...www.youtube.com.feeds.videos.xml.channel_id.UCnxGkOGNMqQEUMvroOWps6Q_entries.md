# Source:JRE Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q, language:en-US

## Zack Snyder on Becoming Known for "The Snyder Cut"
 - [https://www.youtube.com/watch?v=AivaTomduXI](https://www.youtube.com/watch?v=AivaTomduXI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2024-03-06T18:15:00+00:00

JRE #2114 w/Zack Snyder
YouTube: https://youtu.be/KD1--GoDzkA
JRE on Spotify: https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk

## Zack Snyder on Receiving Backlash from Comic Book Fans
 - [https://www.youtube.com/watch?v=3suBldl7WOo](https://www.youtube.com/watch?v=3suBldl7WOo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnxGkOGNMqQEUMvroOWps6Q
 - date published: 2024-03-06T18:15:00+00:00

JRE #2114 w/Zack Snyder
YouTube: https://youtu.be/KD1--GoDzkA
JRE on Spotify: https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk

