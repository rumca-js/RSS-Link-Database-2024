# Source:Wykop, URL:https://wykop.pl/rss, language:pl-PL

## Przed panią Iwoną broń nie ma tajemnic
 - [https://wykop.pl/link/7386537/przed-pania-iwona-bron-nie-ma-tajemnic](https://wykop.pl/link/7386537/przed-pania-iwona-bron-nie-ma-tajemnic)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T20:57:05+00:00

Instruktorka, która się kulom nie kłania. XDDDDDD

## NEO z Matrix'a wersja 2k24 w programie Clout MMA
 - [https://wykop.pl/link/7386511/neo-z-matrix-a-wersja-2k24-w-programie-clout-mma](https://wykop.pl/link/7386511/neo-z-matrix-a-wersja-2k24-w-programie-clout-mma)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T20:32:24+00:00

<img src="https://wykop.pl/cdn/c3397993/08fce3a9e8e8d368a2f2d2803117a7ae5575df2ab184c8fef4b1a188d9cde332.png" /><br /> Niesamowity unik ochroniarza, który oszukał przeznaczenie

## Przemoc ma płeć. Pobiła faceta i chwali się na wykopie
 - [https://wykop.pl/link/7386501/przemoc-ma-plec-pobila-faceta-i-chwali-sie-na-wykopie](https://wykop.pl/link/7386501/przemoc-ma-plec-pobila-faceta-i-chwali-sie-na-wykopie)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T20:22:17+00:00

<img src="https://wykop.pl/cdn/c3397993/7d74bbc1d37dbd326a02255914346265e6c4d66d9e7c53e041811422a445cf60,w104h74.jpg" /><br /> Sama siebie określa "toksyczną". Gdyby to było w drugą stronę to niebieska karta i wywalenie z mieszkania. Chłop zastraszony i boi się, usprawiedliwiając kobietę.

## Dzieci w Strefie Gazy umierają z niedożywienia. "To jest prawdziwy dramat, prawd
 - [https://wykop.pl/link/7386487/dzieci-w-strefie-gazy-umieraja-z-niedozywienia-to-jest-prawdziwy-dramat-prawd](https://wykop.pl/link/7386487/dzieci-w-strefie-gazy-umieraja-z-niedozywienia-to-jest-prawdziwy-dramat-prawd)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T20:13:54+00:00

<img src="https://wykop.pl/cdn/c3397993/9d182bef8b44acd096b58a9381945917a2cc9f75e86127452e218039a43f0454,w104h74.jpg" /><br /> Dzieci w Gazie umierają z głodu i na nagraniach z tamtejszych szpitali dokładnie widać, jak wygląda ta śmierć. Brakuje leków, tlenu, paliwa, prądu, a konsekwencje niedożywienia dotykają tam prawie każde dziecko poniżej drugiego roku życia. Niektóre nagrania są tak drastyczne, że nie możemy ich pokaz

## Nie żyje drugi z żołnierzy poszkodowanych w wypadku na poligonie drawskim
 - [https://wykop.pl/link/7386331/nie-zyje-drugi-z-zolnierzy-poszkodowanych-w-wypadku-na-poligonie-drawskim](https://wykop.pl/link/7386331/nie-zyje-drugi-z-zolnierzy-poszkodowanych-w-wypadku-na-poligonie-drawskim)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T17:04:35+00:00

<img src="https://wykop.pl/cdn/c3397993/6e4c67557084f34f460d2d567acd2307a1c209e94979897a8af37b099044a8cb,w104h74.jpg" /><br /> 1 Warszawska Brygada Pancerna podała, że w środę po południu w szpitalu zmarł drugi z żołnierzy poszkodowanych w wypadku na poligonie w Drawsku Pomorskim. Na obu żołnierzy w trakcie ćwiczeń najechał pojazd gąsienicowy.

## Szef MSWiA zwrócił się do PiS. "Gdzie macie przyzwoitość?"
 - [https://wykop.pl/link/7386295/szef-mswia-zwrocil-sie-do-pis-gdzie-macie-przyzwoitosc](https://wykop.pl/link/7386295/szef-mswia-zwrocil-sie-do-pis-gdzie-macie-przyzwoitosc)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T16:46:48+00:00

<img src="https://wykop.pl/cdn/c3397993/4f7526628960ad8054438a557b30078af3bd03738a608528c1f21f50f030257a,w104h74.jpg" /><br /> - Czy wam naprawdę nie jest wstyd, że atakujecie policjantów, w kierunku których rzucane są kostki brukowe? Wstydźcie się, waszą nieodpowiedzialną retoryką prowadzicie do aktów przemocy - mówił w Sejmie minister spraw wewnętrznych i administracji Marcin Kierwiński.

## AI Elona Muska będzie wyłapywał ukryte haczyki w ustawach kongresu
 - [https://wykop.pl/link/7386279/ai-elona-muska-bedzie-wylapywal-ukryte-haczyki-w-ustawach-kongresu](https://wykop.pl/link/7386279/ai-elona-muska-bedzie-wylapywal-ukryte-haczyki-w-ustawach-kongresu)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T16:38:46+00:00

<img src="https://wykop.pl/cdn/c3397993/09a6a513aebaa846e20aa7aea34b4d38a0578b0199260029453e86d86d447f25,w104h74.jpg" /><br /> Elon Musk zapowiedział, że jego nowy projekt AI, Grok, będzie w stanie przeczytać i podsumować długie i skomplikowane ustawy, które często przygotowuje kongres USA. Grok ma pomóc obywatelom zrozumieć, co tak naprawdę zawierają te dokumenty i jak wpływają na ich życie.

## Projekt CPK zamrożony.
 - [https://wykop.pl/link/7386271/projekt-cpk-zamrozony](https://wykop.pl/link/7386271/projekt-cpk-zamrozony)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T16:32:04+00:00

<img src="https://wykop.pl/cdn/c3397993/2a8ff1ce8786af928c4aab09096354e9c25d081ecf12ed4bdb5a69ac66a0139c,w104h74.jpg" /><br /> Szok i niedowierzanie.

## Policja pałuje gościa stojącego z flagą
 - [https://wykop.pl/link/7386247/policja-paluje-goscia-stojacego-z-flaga](https://wykop.pl/link/7386247/policja-paluje-goscia-stojacego-z-flaga)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T16:07:33+00:00

<img src="https://wykop.pl/cdn/c3397993/c905419a2ef989b449f8ea2987b1f3cbd57305228f3c5b5f55c5ce6717d14e61,w104h74.jpg" /><br /> Proszę powiedzcie, co ten człowiek z biało czerwoną flagą zrobił, że został spacyfikowany przez policję? Flaga na ziemi podeptana.. Anna Kaszuba ·...

## PILNE! Policja użyła GAZU wobec PROTESTUJĄCYCH rolników!
 - [https://wykop.pl/link/7386243/pilne-policja-uzyla-gazu-wobec-protestujacych-rolnikow](https://wykop.pl/link/7386243/pilne-policja-uzyla-gazu-wobec-protestujacych-rolnikow)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T16:00:15+00:00

<img src="https://wykop.pl/cdn/c3397993/640183c46e3a64e45b2859d5afd960437defa434c32dbf0c1a80a48fda414987,w104h74.jpg" /><br /> Pod Sejmem trwają starcia rolników z policją. Komenda Stołeczna wydała w mediach społecznościowych komunikat dotyczący zachowań rolników. "Zachowania zagrażające bezpieczeństwu naszych funkcjonariuszy, w tym rzucanie w nich kostką brukową, nie mogą być lekceważone"

## Przełom. Kijów gotowy na zaakceptowanie embarga na swoje zboża
 - [https://wykop.pl/link/7386229/przelom-kijow-gotowy-na-zaakceptowanie-embarga-na-swoje-zboza](https://wykop.pl/link/7386229/przelom-kijow-gotowy-na-zaakceptowanie-embarga-na-swoje-zboza)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T15:41:57+00:00

<img src="https://wykop.pl/cdn/c3397993/233783a6f8fee825e269ba76d427dcd9eabeeda55a6537585293fcbed9fa0400,w104h74.jpg" /><br /> Taras Kaczka stwierdził, że Kijów popiera zezwolenie niektórym krajom na zamknięcie swoich rynków dla ukraińskiego zboża, z wyjątkiem dalszego tranzytu do innych krajów. Nie można było tak od razu???

## Garry Kasparov dodany na liste terrorystów i ekstremistów przez Rosje
 - [https://wykop.pl/link/7386227/garry-kasparov-dodany-na-liste-terrorystow-i-ekstremistow-przez-rosje](https://wykop.pl/link/7386227/garry-kasparov-dodany-na-liste-terrorystow-i-ekstremistow-przez-rosje)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T15:40:10+00:00

<img src="https://wykop.pl/cdn/c3397993/f5a782fc28ee48d77d14e9ac286bb73839a729852f338c4b40d203b672b7fec7,w104h74.jpg" /><br /> W dodatku wszczęto przeciwko niemu sprawę karną pod zarzutem terroryzmu

## Gemini, nowe AI Googla nie pokaże dzieciom C++ bo taki kod „nie jest bezpieczny”
 - [https://wykop.pl/link/7386225/gemini-nowe-ai-googla-nie-pokaze-dzieciom-c-bo-taki-kod-nie-jest-bezpieczny](https://wykop.pl/link/7386225/gemini-nowe-ai-googla-nie-pokaze-dzieciom-c-bo-taki-kod-nie-jest-bezpieczny)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T15:38:25+00:00

<img src="https://wykop.pl/cdn/c3397993/c42f1b5f03f31572a4d0e53ae36a6562078028de5469ad847c314a6a835834c5,w104h74.jpg" /><br /> Google tak wytrenowało swój nowy model AI, Gemini, że ten LLM stara się unikać pokazywania wszystkiego, co mogłoby być potencjalnie niebezpieczne. Do tego stopnia, że unika pokazywania dzieciom kodu, ktôry mogłyby wg niego być „niebezpieczny” albo „nieetyczny”. Zobaczcie sami :D

## "Prowokatorzy" na proteście rolników? Szef związku: Każdy może założyć kamizelkę
 - [https://wykop.pl/link/7386189/prowokatorzy-na-protescie-rolnikow-szef-zwiazku-kazdy-moze-zalozyc-kamizelke](https://wykop.pl/link/7386189/prowokatorzy-na-protescie-rolnikow-szef-zwiazku-kazdy-moze-zalozyc-kamizelke)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T15:12:45+00:00

<img src="https://wykop.pl/cdn/c3397993/d620804e1b81296d3612d0bc89a1bd2c6a79822a369ea557d8ac0ab626814532,w104h74.jpg" /><br /> - Wydaje mi się, że w okolicach Sejmu mamy do czynienia z prowokacjami - uważa przewodniczący OPZZ Rolników i Organizacji Rolniczych Sławomir Izdebski w rozmowie z Polsat News. Szef związku stwierdził, że być może za najbardziej agresywne działania podczas protestu nie odpowiadają rolnicy, bo "każdy

## Największe banki działające w Polsce źle liczyły WIRON!KNF wszczyna postępowanie
 - [https://wykop.pl/link/7386187/najwieksze-banki-dzialajace-w-polsce-zle-liczyly-wiron-knf-wszczyna-postepowanie](https://wykop.pl/link/7386187/najwieksze-banki-dzialajace-w-polsce-zle-liczyly-wiron-knf-wszczyna-postepowanie)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T15:11:45+00:00

<img src="https://wykop.pl/cdn/c3397993/7d3e9be70c9eaac4a8beb50c70a0798dfff9755adbdead4a79d273fdc3f7280f.png" /><br /> Według informacji, które udało się ustalić DGP, wskazano na nieprawidłowości w obliczaniu wskaźnika WIRON. Mowa o bankach: Pekao, Santanderze, Millennium, BNP Paribas oraz mBanku

## Policja używa gazu na strajkujących rolników
 - [https://wykop.pl/link/7386137/policja-uzywa-gazu-na-strajkujacych-rolnikow](https://wykop.pl/link/7386137/policja-uzywa-gazu-na-strajkujacych-rolnikow)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T14:36:33+00:00

<img src="https://wykop.pl/cdn/c3397993/8ec028745c55fd69df6018b11b5806ca6777014575b32cae8983f76890f9bc9e,w104h74.jpg" /><br /> Sytuacja pod sejmem 6.03.2024 r. Strajk rolników

## Wojciechowska żeruje na tragedii zgwałconej i zamordowanej Lizy
 - [https://wykop.pl/link/7386089/wojciechowska-zeruje-na-tragedii-zgwalconej-i-zamordowanej-lizy](https://wykop.pl/link/7386089/wojciechowska-zeruje-na-tragedii-zgwalconej-i-zamordowanej-lizy)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T14:08:34+00:00

<img src="https://wykop.pl/cdn/c3397993/d21ababd4cf4963a5869564e567f9941dbc20b9208080cf7e009e3e8bfbfb862,w104h74.jpg" /><br /> Oczywiste jest, że od zmiany definicji gwałtu, ulice nie staną się bezpieczne. Stała się tragedia, zboczeniec napadł, okradł, zgwałcił i zamordował niewinna ofiarę. Wg obecnych przepisów jest to przestępstwo zagrożone najwyższa karą. Ale dla niektórych jest to pomysł na wypromowanie się.

## Afera dyplomowa. Mamy oświadczenia Lewandowskiego i Milika
 - [https://wykop.pl/link/7386075/afera-dyplomowa-mamy-oswiadczenia-lewandowskiego-i-milika](https://wykop.pl/link/7386075/afera-dyplomowa-mamy-oswiadczenia-lewandowskiego-i-milika)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T13:59:30+00:00

<img src="https://wykop.pl/cdn/c3397993/73c1d0e42541e939a06db070851b55830eeee92a78873af4d1a6ea8559913ed1,w104h74.jpg" /><br /> W skrócie: Robuś i Areczek nic nie wiedzieli i oni uczyli się rzetelnie, a że na zajęciach nie bywali... cóż geniusze nie muszą... ( ͡° ͜ʖ ͡°)

## Protestujący rolnicy wtargnęli na teren Sejmu
 - [https://wykop.pl/link/7386037/protestujacy-rolnicy-wtargneli-na-teren-sejmu](https://wykop.pl/link/7386037/protestujacy-rolnicy-wtargneli-na-teren-sejmu)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T13:27:32+00:00

<img src="https://wykop.pl/cdn/c3397993/099487fde7a318d68ad686e06a44f0e5cf21762fda96312098320369135a9810,w104h74.jpg" /><br /> Protestujący rolnicy dostali się na teren Sejmu - informuje reporter Jakub Krzywiecki. Wcześniej grupa protestujących zaczęła rozbierać nawierzchnię z bruku i rzucać "pozyskanymi" tak kostkami w stronę policji.

## Kostka brukowa poszła w ruch. Gorąco przed Sejmem
 - [https://wykop.pl/link/7386033/kostka-brukowa-poszla-w-ruch-goraco-przed-sejmem](https://wykop.pl/link/7386033/kostka-brukowa-poszla-w-ruch-goraco-przed-sejmem)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T13:26:37+00:00

<img src="https://wykop.pl/cdn/c3397993/311afed376f67bfb770790ab8462ed5f66d931745322aa05b8491ab915b1272f.png" /><br /> Zaognia się sytuacja podczas protestu rolników przez Sejmem. Grupa protestujących w pewnym momencie zaczęła rozbierać nawierzchnię z bruku i rzucać pozyskanymi tak kostkami w stronę policji. Na miejscu rozpylono gaz łzawiący, uszkodzone są barierki zabezpieczające budynek parlamentu. Sytuację nagrał

## Wydano miliony na pikniki Lasów Państwowych. Ponad połowa w jednym okręgu wyborc
 - [https://wykop.pl/link/7385941/wydano-miliony-na-pikniki-lasow-panstwowych-ponad-polowa-w-jednym-okregu-wyborc](https://wykop.pl/link/7385941/wydano-miliony-na-pikniki-lasow-panstwowych-ponad-polowa-w-jednym-okregu-wyborc)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T12:34:29+00:00

<img src="https://wykop.pl/cdn/c3397993/41628144327893907566a321249a6ec1b060203c9437b445c2541da13a3c7757,w104h74.jpg" /><br /> Niemal 3 mln zł - tyle kosztowało 31 pikników Lasów Państwowych "Drewno – surowiec wszech czasów". Ponad połowa z nich odbyła się w miejscowościach powiatów tarnogórskiego i gliwickiego, okręgu wyborczym Józefa Kubicy, byłego dyrektora generalnego Lasów Państwowych i kandydata z listy PiS do sejmu w

## Zboże z Ukrainy zalało Polskę. GUS rozwiewa wątpliwości
 - [https://wykop.pl/link/7385939/zboze-z-ukrainy-zalalo-polske-gus-rozwiewa-watpliwosci](https://wykop.pl/link/7385939/zboze-z-ukrainy-zalalo-polske-gus-rozwiewa-watpliwosci)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T12:33:44+00:00

<img src="https://wykop.pl/cdn/c3397993/1178691b3cfc667b454e48293ca74f69e6874cbcde5816ffdfb7384b9fba1a06,w104h74.jpg" /><br /> Napływ zboża z Ukrainy, to jeden z powodów, dlaczego polscy rolnicy wyszli na ulice. Główny Urząd Statystyczny przekazał informacje dotyczące importu produktów rolnych z Ukrainy. Jak się okazuje, Polska w 2022 roku została zalana zbożem zza wschodniej granicy.

## Orlen. Poseł Kropiwnicki zapowiada wniosek do prokuratury ws. detektywa
 - [https://wykop.pl/link/7385931/orlen-posel-kropiwnicki-zapowiada-wniosek-do-prokuratury-ws-detektywa](https://wykop.pl/link/7385931/orlen-posel-kropiwnicki-zapowiada-wniosek-do-prokuratury-ws-detektywa)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T12:26:43+00:00

<img src="https://wykop.pl/cdn/c3397993/d78dd5bc43b98e3b0a64cbeaf213f7f04a0b53c3f18398672790a1f67c5a74b2,w104h74.jpg" /><br /> Poseł KO Robert Kropiwnicki zapowiada wniosek do prokuratury w sprawie detektywa wynajętego przez byłego prezesa Orlenu Daniela Obajtka. - Śledzenie posłów przez firmę detektywistyczną jest naruszeniem prawa.

## Brytyjscy żołnierze mogą stanąć przed sądem, bo zabili dżihadystę
 - [https://wykop.pl/link/7385907/brytyjscy-zolnierze-moga-stanac-przed-sadem-bo-zabili-dzihadyste](https://wykop.pl/link/7385907/brytyjscy-zolnierze-moga-stanac-przed-sadem-bo-zabili-dzihadyste)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T11:58:15+00:00

<img src="https://wykop.pl/cdn/c3397993/4a4205d64601aa4f607b03400d23e984b774838e926f446bb5b812f432e3be71,w104h74.jpg" /><br /> Pięciu żołnierzom z brytyjskiej jednostki specjalnej (SAS), grożą zarzuty zabójstwa. Zdaniem przełożonych, dwa lata temu w Syrii, komandosi zabili dżihadystę zamiast go aresztować – ujawnił w środę dziennik „Daily Mail”.

## KE wycofuje się z Zielonego ładu w rolnictwie. Są konkretne propozycje
 - [https://wykop.pl/link/7385897/ke-wycofuje-sie-z-zielonego-ladu-w-rolnictwie-sa-konkretne-propozycje](https://wykop.pl/link/7385897/ke-wycofuje-sie-z-zielonego-ladu-w-rolnictwie-sa-konkretne-propozycje)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T11:52:59+00:00

<img src="https://wykop.pl/cdn/c3397993/12afe1fea021f41a15c27f6be48d6885a8d3de8ec2e7a517ac8959f48770fe35,w104h74.jpg" /><br /> Komisja Europejska przedstawi w przyszłym tygodniu nowe propozycje legislacyjne wychodzące naprzeciw postulatom protestujących rolników. „Będzie propozycja bardzo dużego zmniejszenia obciążeń dla rolników” – zapowiada komisarz ds. rolnictwa.

## Niemiecki poseł apeluje o niedostarczanie komponentów do produkcji amunicji
 - [https://wykop.pl/link/7385883/niemiecki-posel-apeluje-o-niedostarczanie-komponentow-do-produkcji-amunicji](https://wykop.pl/link/7385883/niemiecki-posel-apeluje-o-niedostarczanie-komponentow-do-produkcji-amunicji)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T11:43:55+00:00

<img src="https://wykop.pl/cdn/c3397993/e3d92f1df77f4198feb132c4e3d6b48c0a9f8fd544e1bece2e77d9c17414c846,w104h74.jpg" /><br /> Ukrinform przytoczył słowa Rodericha Kiesewettera, posła do Bundestagu i członka Komisji Spraw Zagranicznych, udzielonych w wywiadzie dla Guildhall. Polityk zaznaczył, że dostawy środków służących do produkcji amunicji do Rosji są niedopuszczalne.

## Serial „1670” powróci! Netflix zamówił drugi sezon polskiego hitu
 - [https://wykop.pl/link/7385879/serial-1670-powroci-netflix-zamowil-drugi-sezon-polskiego-hitu](https://wykop.pl/link/7385879/serial-1670-powroci-netflix-zamowil-drugi-sezon-polskiego-hitu)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T11:41:53+00:00

<img src="https://wykop.pl/cdn/c3397993/e158d16c30895e7a25caf419d99b823495f35132ffabb57b89f44261a8bcf810,w104h74.jpg" /><br /> Netflix trzymał nas trochę w niepewności, ale w końcu potwierdził, że polski serial komediowy „1670” powróci z drugim sezonem. Jesteście gotowi na więcej przygód Jana Pawła?

## Funkcjonariusze ABW weszli do biur Orlenu.
 - [https://wykop.pl/link/7385849/funkcjonariusze-abw-weszli-do-biur-orlenu](https://wykop.pl/link/7385849/funkcjonariusze-abw-weszli-do-biur-orlenu)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T11:20:14+00:00

<img src="https://wykop.pl/cdn/c3397993/4675715c169aded853c234c2f18bb5df7c8739b049cc616e704138d539425dda,w104h74.jpg" /><br /> W biurach Orlenu w Płocku i w Warszawie, a także na terenie Gdańska funkcjonariusze ABW prowadzą w środę czynności związane z zabezpieczaniem materiału dowodowego w sprawie połączenia Orlenu z Grupą Lotos — poinformowała zastępca prokuratora okręgowego w Płocku Monika Mieczykowska.

## Brutalne pobicie w szkole w Zakroczymiu. Winna ofiara, bo była na boisku.
 - [https://wykop.pl/link/7385825/brutalne-pobicie-w-szkole-w-zakroczymiu-winna-ofiara-bo-byla-na-boisku](https://wykop.pl/link/7385825/brutalne-pobicie-w-szkole-w-zakroczymiu-winna-ofiara-bo-byla-na-boisku)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T11:02:24+00:00

<img src="https://wykop.pl/cdn/c3397993/bedfadeddec620833ba5e443ecf707343e1c8d524af34cd6277034947bd2a15b,w104h74.jpg" /><br /> Bili dotąd, aż złamali mu nos i kości czaszki. Kiedy służby pojawiły się na miejscu, wyszła pani dyrektor i stwierdziła, że to mój syn jest winny, bo powinien być na świetlicy a nie na boisku – opowiada mama pobitego Konrada.

## Wyciek danych - operacje "korekty" płci mogą powodować sterylizację a nawet zgon
 - [https://wykop.pl/link/7385801/wyciek-danych-operacje-korekty-plci-moga-powodowac-sterylizacje-a-nawet-zgon](https://wykop.pl/link/7385801/wyciek-danych-operacje-korekty-plci-moga-powodowac-sterylizacje-a-nawet-zgon)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T10:43:14+00:00

Nowo ujawnione wewnętrzne akta Światowego Stowarzyszenia na rzecz Zdrowia Osób Transpłciowych (WPATH) dowodzą, że praktyka medycyny transpłciowej nie jest ani naukowa, ani medyczna. Obrażenia opisane w aktach WPATH obejmują sterylizację, utratę funkcji seksualnych, guzy wątroby i śmierć.

## Nago spacerował po Świdnicy. Prokurator wrócił do pracy - Swidnica24.pl
 - [https://wykop.pl/link/7385787/nago-spacerowal-po-swidnicy-prokurator-wrocil-do-pracy-swidnica24-pl](https://wykop.pl/link/7385787/nago-spacerowal-po-swidnicy-prokurator-wrocil-do-pracy-swidnica24-pl)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T10:28:55+00:00

<img src="https://wykop.pl/cdn/c3397993/ae8bf5b9904843674b4a79d6a496306aaf19d6d65683e958c9b543ff2f221708,w104h74.jpg" /><br /> Umorzone zostało postępowanie dyscyplinarne dotyczące prokuratora Macieja W., który spacerował nago po świdnickim osiedlu Zarzecze. Został on przywrócony do obowiązków służbowych w Prokuraturze Rejonowej w Świdnicy. Przypomnijmy, 9 września 2021 roku nagi mężczyzna spacerował po świdnickim osiedlu.

## Drugie życie ukraińskiej pralki w Rosji
 - [https://wykop.pl/link/7385745/drugie-zycie-ukrainskiej-pralki-w-rosji](https://wykop.pl/link/7385745/drugie-zycie-ukrainskiej-pralki-w-rosji)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T09:52:01+00:00

<img src="https://wykop.pl/cdn/c3397993/515427422b0a0309c07405edf7d738e84d1f4701000cd75ef455bf5512a4bb07,w104h74.jpg" /><br /> 1.Trzeba ukraść pralkę na Ukrainie. 2.Trzeba przewieźć pralkę tysiąć pięset sto dziewieńcet kilometrów za Amur. Koszty nie mają znaczenia "trofiejna". 3.Etap wyparcia -Nuu my nie mamy bieżącej wody? A co ty Kolia taki zdziwiony? 4.Etap adaptacji. Przerób pralkę na piłę do patyków. 5.Zwycięstwo.

## Europa odcięta od części internetu. Strategiczne podmorskie kable uszkodzone.
 - [https://wykop.pl/link/7385727/europa-odcieta-od-czesci-internetu-strategiczne-podmorskie-kable-uszkodzone](https://wykop.pl/link/7385727/europa-odcieta-od-czesci-internetu-strategiczne-podmorskie-kable-uszkodzone)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T09:39:01+00:00

<img src="https://wykop.pl/cdn/c3397993/21b809edd25d70ced1ac01d02d7b1670dbdfc7c2567d6171eeede027f2e8b281,w104h74.jpg" /><br /> Część z kabli stanowiących główne połączenie internetowe pomiędzy Azją, Europą i Północną Afryką zostało przecięte.

## Mentzen: Protest rolników to pomysł Tuska. Aborcja? I tak nic się nie zmieni
 - [https://wykop.pl/link/7385723/mentzen-protest-rolnikow-to-pomysl-tuska-aborcja-i-tak-nic-sie-nie-zmieni](https://wykop.pl/link/7385723/mentzen-protest-rolnikow-to-pomysl-tuska-aborcja-i-tak-nic-sie-nie-zmieni)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T09:28:54+00:00

<img src="https://wykop.pl/cdn/c3397993/80675a9251486af4b21e9d4620d7e83a9471363e0a294e4e08507f78a500d260,w104h74.jpg" /><br /> Sławomir Mentzen - współprzewodniczący Konfederacji, prezes Nowej Nadziei Gościem Radia ZET. Zaprasza Bogdan Rymanowski!

## Wyrok SCT w Krakowie to pułapka. Zbiórka na prawnika.
 - [https://wykop.pl/link/7385713/wyrok-sct-w-krakowie-to-pulapka-zbiorka-na-prawnika](https://wykop.pl/link/7385713/wyrok-sct-w-krakowie-to-pulapka-zbiorka-na-prawnika)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T09:21:12+00:00

<img src="https://wykop.pl/cdn/c3397993/da11a811a513f456465a8569f4c8257eb3b6abf3a08d9d2bb01dcb2311a40501,w104h74.jpg" /><br /> Zrzutka ma na celu opłacenie pośrednictwa prawnika wymaganego do złożenia skargi do NSA na wyrok WSA w Krakowie z dnia 11 stycznia 2024, który odrzucił skargi obywateli na SCT w Krakowie. Jeśli ten wyrok stanie się prawomocny, sądy w przyszłosci beda powoływac się na ten wyrok.

## Korea Południowa zakazuje sprzedaży akumulatorów do Rosji
 - [https://wykop.pl/link/7385681/korea-poludniowa-zakazuje-sprzedazy-akumulatorow-do-rosji](https://wykop.pl/link/7385681/korea-poludniowa-zakazuje-sprzedazy-akumulatorow-do-rosji)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T09:05:40+00:00

<img src="https://wykop.pl/cdn/c3397993/6d6d2e7b6eaf2586146081dc95717a74e034a631892e806130a76fcf3c0733af,w104h74.jpg" /><br /> Korea Południowa zakazała sprzedaży do Rosji akumulatorów i komponentów służących do ich produkcji. Sankcje obejmują między innymi ogniwa używane w pojazdach elektrycznych.

## Łotwa z zakazem importu produktów rolnych z Rosji i Białorusi.
 - [https://wykop.pl/link/7385669/lotwa-z-zakazem-importu-produktow-rolnych-z-rosji-i-bialorusi](https://wykop.pl/link/7385669/lotwa-z-zakazem-importu-produktow-rolnych-z-rosji-i-bialorusi)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T08:53:22+00:00

<img src="https://wykop.pl/cdn/c3397993/8c2f8e625b13769497c1a0ea7a37bba3e0e5e77e93d0e67b5a3517108c8aeae0,w104h74.jpg" /><br /> Łotewski rząd zatwierdził listę produktów, które zostaną objęte embargiem. Chodzi o artykułu rolne i spożywcze pochodzące z Rosji i Białorusi, których zakup pośrednio finansuje agresję Kremla i Mińska.Rząd w Rydze zatwierdził i opublikował pełną listę produktów, które od 8 marca nie mogą już przekra

## Protest rolników w Warszawie. Problemy na drogach dojazdowych. Policja ostrzega
 - [https://wykop.pl/link/7385657/protest-rolnikow-w-warszawie-problemy-na-drogach-dojazdowych-policja-ostrzega](https://wykop.pl/link/7385657/protest-rolnikow-w-warszawie-problemy-na-drogach-dojazdowych-policja-ostrzega)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T08:28:45+00:00

<img src="https://wykop.pl/cdn/c3397993/b0d045e0bc90806d120786507a5f9d355b7269d978fb6d4302eab9ffba4841ce,w104h74.jpg" /><br /> Rolnicy nie schodzą z barykad i wracają z kolejnym wielkim protestem w Warszawie. Manifestujący spotkają się w środę o 11:00 przed Kancelarią Prezesa Rady Ministrów i przed gmachem Sejmu. Utrudnienia dotyczą także blokad dróg dojazdowych do stolicy m.in. od strony Białegostoku. Policja przypomina ro

## Pół Polka- pół Grenlandka uczy grenlandzkiego
 - [https://wykop.pl/link/7385639/pol-polka-pol-grenlandka-uczy-grenlandzkiego](https://wykop.pl/link/7385639/pol-polka-pol-grenlandka-uczy-grenlandzkiego)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T08:10:25+00:00

<img src="https://wykop.pl/cdn/c3397993/f279cf1f486a35a55bbdc9294587901a6492439b56375426a6b16e798037889b,w104h74.jpg" /><br /> Córka Polaka z Elbląga i Grenlandki, którą poznał w Kopenhadze, daje lekcję grenlandzkiego. Grenlandia- to terytorium Danii na mroźnej dalekiej Północy, zamieszkałe przez Inuitów z domieszkami skandynawskimi.

## Adwokat od "trumny na kółkach" skazany. Proces trwał 5 lat
 - [https://wykop.pl/link/7385635/adwokat-od-trumny-na-kolkach-skazany-proces-trwal-5-lat](https://wykop.pl/link/7385635/adwokat-od-trumny-na-kolkach-skazany-proces-trwal-5-lat)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T08:03:56+00:00

<img src="https://wykop.pl/cdn/c3397993/e04ddef6789827eebd217284714a24f7dbcb89a56976fb86c45bca7973775d60,w104h74.jpg" /><br /> Zapadł wyrok w sprawie 30 łódzkich adwokatów oskarżonych o przyjmowanie lewych zwolnień od lekarki sądowej. Wśród oskarżonych był słynny adwokat od "trumny na kółkach". Proces trwał 5 lat.

## "Jaśniepan". Rolnicy wściekli na nowego wroga. Jadą z gnojowicą
 - [https://wykop.pl/link/7385595/jasniepan-rolnicy-wsciekli-na-nowego-wroga-jada-z-gnojowica](https://wykop.pl/link/7385595/jasniepan-rolnicy-wsciekli-na-nowego-wroga-jada-z-gnojowica)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T07:37:58+00:00

<img src="https://wykop.pl/cdn/c3397993/6e4db53f2ede17a39b1ee0967e7e2bc66acc6e670f651563f6d67825b9324b7d,w104h74.jpg" /><br /> 6 marca rolnicza "Solidarność" organizuje w Warszawie duży protest. Jednak prezydent Warszawy Rafał Trzaskowski zezwolił organizatorom na przyprowadzenie tylko jednego ciągnika. Rozjuszył tym uczestników demonstracji, którzy nie zamierzają go posłuchać i szykują się do siłowego wjazdu do stolicy.

## Fentanyl już jest na polskich ulicach. "Za chwilę będzie tu jak w USA"
 - [https://wykop.pl/link/7385587/fentanyl-juz-jest-na-polskich-ulicach-za-chwile-bedzie-tu-jak-w-usa](https://wykop.pl/link/7385587/fentanyl-juz-jest-na-polskich-ulicach-za-chwile-bedzie-tu-jak-w-usa)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T07:34:45+00:00

<img src="https://wykop.pl/cdn/c3397993/5e4ad63fe73cb008e17ad4c2cb8f070fbf777f2005707561f8f0dc621346e85d.png" /><br /> – Jeden z najbardziej niebezpiecznych narkotyków wchodzi do Polski. – Uzależnieni od niego ludzie nie są zdolni do normalnego funkcjonowania – mówi Adam Nyk, socjolog, terapeuta z warszawskiego Monaru.

## Przekręt na sklepowych parkingach. Nałożyli na ciebie mandat? Uważaj
 - [https://wykop.pl/link/7385559/przekret-na-sklepowych-parkingach-nalozyli-na-ciebie-mandat-uwazaj](https://wykop.pl/link/7385559/przekret-na-sklepowych-parkingach-nalozyli-na-ciebie-mandat-uwazaj)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T07:16:38+00:00

<img src="https://wykop.pl/cdn/c3397993/be98effc32858ca33e8b4a1dda73c11d81d003729e2d993d3ea3cae07d11cf93,w104h74.jpg" /><br /> APCOA ostrzega, że na fałszywych wezwaniach do zapłaty podawany jest inny numer rachunku bankowego, nienależący do firmy, który służy do wyłudzenia pieniędzy.

## 20% zniżki na ciuchy North Face za kurs o przywilejach dla białych
 - [https://wykop.pl/link/7385539/20-znizki-na-ciuchy-north-face-za-kurs-o-przywilejach-dla-bialych](https://wykop.pl/link/7385539/20-znizki-na-ciuchy-north-face-za-kurs-o-przywilejach-dla-bialych)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T06:50:54+00:00

<img src="https://wykop.pl/cdn/c3397993/56c19af1f032cc91b4296cca61a16cffc4725a8d71569b62bfd8a7d0d6e36976,w104h74.jpg" /><br /> Z kursu dowiesz się m. in. że jeśli w sklepie nie będziesz "skakać" wokoło czarnego klienta to pewne jesteś rasistą

## UOKiK potwierdza: To klient musi mieć odliczoną gotówkę, nie kasjer drobne na re
 - [https://wykop.pl/link/7385533/uokik-potwierdza-to-klient-musi-miec-odliczona-gotowke-nie-kasjer-drobne-na-re](https://wykop.pl/link/7385533/uokik-potwierdza-to-klient-musi-miec-odliczona-gotowke-nie-kasjer-drobne-na-re)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T06:36:44+00:00

<img src="https://wykop.pl/cdn/c3397993/7f4360eda4956d779bfbbed63d0966ad5e77fd1dc6bee67e4034db638dfa4ad5,w104h74.jpg" /><br /> Dzisiaj znów kasjerka nie miał mi wydać 75 zł ze 100, gdzie chciałem zapłacić gotówką. Dodatkowo uświadomiła mnie, że to klient musi mieć wyliczone pieniądze, a ona nie musi mieć w kasie jej zapasu aby wydać klientowi.

## Listy przychodziły przez miesiąc, bo listonosz wyjechał. Skandal na poczcie
 - [https://wykop.pl/link/7385531/listy-przychodzily-przez-miesiac-bo-listonosz-wyjechal-skandal-na-poczcie](https://wykop.pl/link/7385531/listy-przychodzily-przez-miesiac-bo-listonosz-wyjechal-skandal-na-poczcie)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T06:35:49+00:00

<img src="https://wykop.pl/cdn/c3397993/94ec4695acab89c9b9b96b42e56915c9fea3b6fd405e8d4417ce56ffd8874a40,w104h74.jpg" /><br /> W Strzałkowie (woj. wielkopolskie) mieszkańcy nie dostawali listów i paczek od miesiąca. Brakiem korespondencji i otrzymywanymi drogą elektroniczną

## Podczas wykopalisk odnaleziono najstarszy chleb na świecie
 - [https://wykop.pl/link/7385525/podczas-wykopalisk-odnaleziono-najstarszy-chleb-na-swiecie](https://wykop.pl/link/7385525/podczas-wykopalisk-odnaleziono-najstarszy-chleb-na-swiecie)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T06:20:58+00:00

<img src="https://wykop.pl/cdn/c3397993/1b3178035ee5d22209f9f2e5c8c01815c20f68c0d6bb688f20403b8f3bff6580,w104h74.jpg" /><br /> Podczas wykopalisk archeologicznych w starożytnej osadzie Catalhoyuk w środkowej Turcji odnaleziono najstarszy chleb na świecie; eksperci oceniają wiek bochenka na 8 600 lat - poinformowała agencja Anatolia.

## Polska numerem 1 na świecie. Jesteśmy liderami w zakresie cyberbezpieczeństwa
 - [https://wykop.pl/link/7385523/polska-numerem-1-na-swiecie-jestesmy-liderami-w-zakresie-cyberbezpieczenstwa](https://wykop.pl/link/7385523/polska-numerem-1-na-swiecie-jestesmy-liderami-w-zakresie-cyberbezpieczenstwa)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T06:16:56+00:00

<img src="https://wykop.pl/cdn/c3397993/8a382de122b0c4b83a860a6bceb8890239495e88b37922e72a40126e73c2bc53,w104h74.jpg" /><br /> Okazuje się bowiem, że Polska zajęła 1 miejsce w rankingu National Cyber Security Index i uplasowała się na najwyższej możliwej pozycji. Oznacza to, że nasz kraj jest gotowy do radzenia sobie i zapobiegania incydentom związanym z cyberzagrożeniami.

## Ogromne pieniądze dla neo-KRS. Najwięcej dostała koleżanka Zbigniewa Ziobry
 - [https://wykop.pl/link/7385519/ogromne-pieniadze-dla-neo-krs-najwiecej-dostala-kolezanka-zbigniewa-ziobry](https://wykop.pl/link/7385519/ogromne-pieniadze-dla-neo-krs-najwiecej-dostala-kolezanka-zbigniewa-ziobry)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T06:05:49+00:00

<img src="https://wykop.pl/cdn/c3397993/b2bbf296221e9c18c6347f3d86694f09575f56b494c1fe2470c5902cd0162aa6,w104h74.jpg" /><br /> 239 tys. zł zarobiła w ubiegłym roku przewodnicząca neo-KRS — a prywatnie szkolna koleżanka Zbigniewa Ziobry — Dagmara Pawełczyk-Woicka — donosi "Gazeta Wyborcza". Obłowić się mieli jednak także inni zwolennicy reform sądownictwa forsowanych przez byłego ministra sprawiedliwości.

## TVP likwiduje kanały pasjonackie na YouTube
 - [https://wykop.pl/link/7385417/tvp-likwiduje-kanaly-pasjonackie-na-youtube](https://wykop.pl/link/7385417/tvp-likwiduje-kanaly-pasjonackie-na-youtube)
 - RSS feed: https://wykop.pl/rss
 - date published: 2024-03-06T00:07:55+00:00

<img src="https://wykop.pl/cdn/c3397993/68007f6d64d9a74faa321edffdd192db75daf386dc7949ea2e08f2453461f5e8,w104h74.jpg" /><br /> Na YouTube nie obejrzymy już - dostępnych przez lata - unikatowo nagranych archiwalnych programów i opraw graficznych - w telewizji też ich nie zobaczymy, bo nikt nie kwapił się ich wydobywać z archiwum. Czysta woda...

