# Source:Tomasz Samołyk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg, language:pl-PL

## Taki Bóg nie istnieje #shorts
 - [https://www.youtube.com/watch?v=G_rAFqTtsy4](https://www.youtube.com/watch?v=G_rAFqTtsy4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg
 - date published: 2024-03-06T07:00:10+00:00



