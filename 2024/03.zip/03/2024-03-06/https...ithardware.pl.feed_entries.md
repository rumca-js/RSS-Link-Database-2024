# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Frostpunk 2 zaprezentowany na nowym zwiastunie. 11 bit studios ujawnia datę premiery
 - [https://ithardware.pl/aktualnosci/frostpunk_2_zaprezentowany_na_nowym_zwiastunie_11_bit_studios_ujawnia_date_premiery-31944.html](https://ithardware.pl/aktualnosci/frostpunk_2_zaprezentowany_na_nowym_zwiastunie_11_bit_studios_ujawnia_date_premiery-31944.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T22:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/31944_1.jpg" />            W zeszłym roku 11 bit studios ogłosiło, że premiera Frostpunk 2 odbędzie się w pierwszej połowie 2024 roku. Teraz z kolei wydawca ujawnił konkretny termin wydania gry.

Xbox Partner Preview obfitował w prezentację r&oacute;żnych gier. Jednym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/frostpunk_2_zaprezentowany_na_nowym_zwiastunie_11_bit_studios_ujawnia_date_premiery-31944.html">https://ithardware.pl/aktualnosci/frostpunk_2_zaprezentowany_na_nowym_zwiastunie_11_bit_studios_ujawnia_date_premiery-31944.html</a></p>

## Warner Bros. odchodzi od gier gier AAA na rzecz produkcji usług
 - [https://ithardware.pl/aktualnosci/warner_bros_odchodzi_od_gier_gier_aaa_na_rzecz_produkcji_uslug-31943.html](https://ithardware.pl/aktualnosci/warner_bros_odchodzi_od_gier_gier_aaa_na_rzecz_produkcji_uslug-31943.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T18:50:14+00:00

<img src="https://ithardware.pl/artykuly/min/31943_1.jpg" />            Warner Bros. mimo sukcesu Hogwarts Legacy oraz klęski poniesionej przez&nbsp;Suicide Squad: Kill The Justice League Warnes Bros. zamierza zmienić swoją politykę dotyczącą gier i stawiać na gry usługi.

Hogwarts Legacy jest grą single player...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/warner_bros_odchodzi_od_gier_gier_aaa_na_rzecz_produkcji_uslug-31943.html">https://ithardware.pl/aktualnosci/warner_bros_odchodzi_od_gier_gier_aaa_na_rzecz_produkcji_uslug-31943.html</a></p>

## Ghost of Tsushima Director’s Cut oficjalnie na PC. Znamy datę premiery i ulepszenia
 - [https://ithardware.pl/aktualnosci/ghost_of_tsushima_director_s_cut_oficjalnie_na_pc_znamy_date_premiery_i_ulepszenia-31942.html](https://ithardware.pl/aktualnosci/ghost_of_tsushima_director_s_cut_oficjalnie_na_pc_znamy_date_premiery_i_ulepszenia-31942.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T17:46:48+00:00

<img src="https://ithardware.pl/artykuly/min/31942_1.jpg" />            Potwierdziły się plotki.&nbsp;Ghost of Tsushima Director&rsquo;s Cut zmierza na komputery i zadebiutuje już za parę miesięcy. Sony ujawniło informacje o porcie i tego, jakie zmiany zaoferuje.

Spekulacje o zapowiedzi&nbsp;Ghost of Tsushima na PC...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ghost_of_tsushima_director_s_cut_oficjalnie_na_pc_znamy_date_premiery_i_ulepszenia-31942.html">https://ithardware.pl/aktualnosci/ghost_of_tsushima_director_s_cut_oficjalnie_na_pc_znamy_date_premiery_i_ulepszenia-31942.html</a></p>

## STALKER: Legends of the Zone Trilogy zmierza na konsole. Znamy cenę i datę premiery
 - [https://ithardware.pl/aktualnosci/stalker_legends_of_the_zone_trilogy_zmierza_na_konsole_znamy_cene_i_date_premiery-31941.html](https://ithardware.pl/aktualnosci/stalker_legends_of_the_zone_trilogy_zmierza_na_konsole_znamy_cene_i_date_premiery-31941.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T16:46:52+00:00

<img src="https://ithardware.pl/artykuly/min/31941_1.jpg" />            W sklepach detalicznych w Japonii pojawił się&nbsp;STALKER: Legends of the Zone Trilogy, czyli pakiet złożony z pierwszych części serii, kt&oacute;ry zmierza na konsole. Wychodzi więc na to, że marka wyląduje wreszcie na urządzeniach Sony oraz...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/stalker_legends_of_the_zone_trilogy_zmierza_na_konsole_znamy_cene_i_date_premiery-31941.html">https://ithardware.pl/aktualnosci/stalker_legends_of_the_zone_trilogy_zmierza_na_konsole_znamy_cene_i_date_premiery-31941.html</a></p>

## MSI MAG 341CQP QD-OLED - testo nowego OLEDa. Krok w dobrym kierunku
 - [https://ithardware.pl/testyirecenzje/msi_mag_341cqp_qd_oled-31924.html](https://ithardware.pl/testyirecenzje/msi_mag_341cqp_qd_oled-31924.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T14:00:01+00:00

<img src="https://ithardware.pl/artykuly/min/31924_1.jpg" />            MSI MAG 341CQP QD-OLED - testo nowego OLEDa. Krok w dobrym kierunku

Kiedy kilka lat temu na rynku zaczęły pojawiać się pierwsze monitory OLED, większość z nas podchodziła do nich bardzo sceptycznie. Gł&oacute;wnie ze względu na duże ryzyko...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/msi_mag_341cqp_qd_oled-31924.html">https://ithardware.pl/testyirecenzje/msi_mag_341cqp_qd_oled-31924.html</a></p>

## Gaomon – nowa marka tabletów graficznych debiutuje na polskim rynku
 - [https://ithardware.pl/aktualnosci/gaomon_nowa_marka_tabletow_graficznych_debiutuje_na_polskim_rynku-31940.html](https://ithardware.pl/aktualnosci/gaomon_nowa_marka_tabletow_graficznych_debiutuje_na_polskim_rynku-31940.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T13:44:18+00:00

<img src="https://ithardware.pl/artykuly/min/31940_1.jpg" />            Na rynku nie brakuje tablet&oacute;w graficznych r&oacute;żnych producent&oacute;w. Tym razem firma&nbsp;Dilectro Electronics, kt&oacute;ra od kilku lat dostarcza polskim klientom r&oacute;żne urządzenia wprowadza na rynek polski nową markę...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gaomon_nowa_marka_tabletow_graficznych_debiutuje_na_polskim_rynku-31940.html">https://ithardware.pl/aktualnosci/gaomon_nowa_marka_tabletow_graficznych_debiutuje_na_polskim_rynku-31940.html</a></p>

## AMD idzie śladem Nvidii. Szykują specjalny układ graficzny dla Chin
 - [https://ithardware.pl/aktualnosci/amd_idzie_sladem_nvidii_szykuja_specjalny_uklad_graficzny_dla_chin-31939.html](https://ithardware.pl/aktualnosci/amd_idzie_sladem_nvidii_szykuja_specjalny_uklad_graficzny_dla_chin-31939.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T12:35:30+00:00

<img src="https://ithardware.pl/artykuly/min/31939_1.jpg" />            Amerykański zakaz eksportu potężnych akcelerator&oacute;w AI i procesor&oacute;w graficznych do Chin zaowocował opracowaniem specjalnych, okrojonych wersji.&nbsp;Nie tylko Nvidia, ale także AMD pr&oacute;bowało takiej strategii.

Sankcje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_idzie_sladem_nvidii_szykuja_specjalny_uklad_graficzny_dla_chin-31939.html">https://ithardware.pl/aktualnosci/amd_idzie_sladem_nvidii_szykuja_specjalny_uklad_graficzny_dla_chin-31939.html</a></p>

## Tak wygląda "samozapłon" elektryka. Uwaga na podpalaczy
 - [https://ithardware.pl/aktualnosci/tak_wyglada_samozaplon_elektryka_uwaga_na_podpalaczy-31932.html](https://ithardware.pl/aktualnosci/tak_wyglada_samozaplon_elektryka_uwaga_na_podpalaczy-31932.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T12:19:02+00:00

<img src="https://ithardware.pl/artykuly/min/31932_1.jpg" />            W zeszłym tygodniu w słowackiej wiosce Miloslavov niedaleko stolicy Bratysławy zapalił się elektryczny Volkswagen ID.3, o czym poinformowała jednostka straży pożarnej. W związku z popularnym mitem o skłonności pojazd&oacute;w elektrycznych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tak_wyglada_samozaplon_elektryka_uwaga_na_podpalaczy-31932.html">https://ithardware.pl/aktualnosci/tak_wyglada_samozaplon_elektryka_uwaga_na_podpalaczy-31932.html</a></p>

## NVIDIA: Rekordowe finanse i rekordowy wpływ na inne firmy. Układy do AI to strzał w 10
 - [https://ithardware.pl/aktualnosci/nvidia_rekordowe_finanse_i_rekordowy_wplyw_na_inne_firmy_uklady_do_ai_to_strzal_w_10-31938.html](https://ithardware.pl/aktualnosci/nvidia_rekordowe_finanse_i_rekordowy_wplyw_na_inne_firmy_uklady_do_ai_to_strzal_w_10-31938.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T12:12:20+00:00

<img src="https://ithardware.pl/artykuly/min/31938_1.jpg" />            Według najnowszego raportu firmy badawczej Omdia, w 2024 roku Nvidia może wygenerować przychody sięgające 87 miliard&oacute;w dolar&oacute;w wyłącznie z procesor&oacute;w graficznych dla centr&oacute;w danych.

Omdia podaje r&oacute;wnież...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_rekordowe_finanse_i_rekordowy_wplyw_na_inne_firmy_uklady_do_ai_to_strzal_w_10-31938.html">https://ithardware.pl/aktualnosci/nvidia_rekordowe_finanse_i_rekordowy_wplyw_na_inne_firmy_uklady_do_ai_to_strzal_w_10-31938.html</a></p>

## JEDEC publikuje specyfikację GDDR7 — nowy standard będzie napędzać GPU NVIDII i AMD
 - [https://ithardware.pl/aktualnosci/jedec_publikuje_specyfikacje_gddr7_nowy_standard_bedzie_napedzac_gpu_nvidii_i_amd-31931.html](https://ithardware.pl/aktualnosci/jedec_publikuje_specyfikacje_gddr7_nowy_standard_bedzie_napedzac_gpu_nvidii_i_amd-31931.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T11:12:01+00:00

<img src="https://ithardware.pl/artykuly/min/31931_1.png" />            Jak podaje BusinessWire, JEDEC opublikował specyfikację standardu pamięci GDDR7. Pamięci nowej generacji będą wykorzystywane w kartach graficznych, a AMD, Micron, NVIDIA, Samsung i SK hynix ogłosiły wsparcie dla tego standardu. Przewidujemy, że...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/jedec_publikuje_specyfikacje_gddr7_nowy_standard_bedzie_napedzac_gpu_nvidii_i_amd-31931.html">https://ithardware.pl/aktualnosci/jedec_publikuje_specyfikacje_gddr7_nowy_standard_bedzie_napedzac_gpu_nvidii_i_amd-31931.html</a></p>

## CBDC nie obchodzi Japończyków, pomimo trwających testów i wysiłków rządu
 - [https://ithardware.pl/aktualnosci/cbdc_nie_obchodzi_japonczykow_pomimo_trwajacych_testow_i_wysilkow_rzadu-31937.html](https://ithardware.pl/aktualnosci/cbdc_nie_obchodzi_japonczykow_pomimo_trwajacych_testow_i_wysilkow_rzadu-31937.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T11:00:50+00:00

<img src="https://ithardware.pl/artykuly/min/31937_1.jpg" />            Nowe ustalenia wykazują, że w Japonii koncepcja CBDC nie zdążyła jeszcze zdobyć popularności wśr&oacute;d miejscowych mieszkańc&oacute;w.

Kazuo Ueda, prezes Banku Japonii (BoJ), podczas niedawnego przem&oacute;wienia, zauważył, że mniej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cbdc_nie_obchodzi_japonczykow_pomimo_trwajacych_testow_i_wysilkow_rzadu-31937.html">https://ithardware.pl/aktualnosci/cbdc_nie_obchodzi_japonczykow_pomimo_trwajacych_testow_i_wysilkow_rzadu-31937.html</a></p>

## Samsung Foundry zmienia nazwę procesu 3 nm na 2 nm. Rywalizacja z Intelem przybiera na sile
 - [https://ithardware.pl/aktualnosci/samsung_foundry_zmienia_nazwe_procesu_3_nm_na_2_nm_rywalizacja_z_intelem_przybiera_na_sile-31929.html](https://ithardware.pl/aktualnosci/samsung_foundry_zmienia_nazwe_procesu_3_nm_na_2_nm_rywalizacja_z_intelem_przybiera_na_sile-31929.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T10:41:01+00:00

<img src="https://ithardware.pl/artykuly/min/31929_1.jpg" />            Według doniesień Samsung Foundry zdecydowało się zmienić nazwę swojej technologii produkcji wafli w klasie 3 nm drugiej generacji, znanej jako SF3, na proces produkcyjny w klasie 2 nm, zwany SF2, co wymagało przepisania...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_foundry_zmienia_nazwe_procesu_3_nm_na_2_nm_rywalizacja_z_intelem_przybiera_na_sile-31929.html">https://ithardware.pl/aktualnosci/samsung_foundry_zmienia_nazwe_procesu_3_nm_na_2_nm_rywalizacja_z_intelem_przybiera_na_sile-31929.html</a></p>

## Sprzedaż iPhone'a Apple w Chinach spadła o 24 procent wraz ze wzrostem popularności Huawei
 - [https://ithardware.pl/aktualnosci/sprzedaz_iphone_a_apple_w_chinach_spadla_o_24_procent_wraz_ze_wzrostem_popularnosci_huawei-31934.html](https://ithardware.pl/aktualnosci/sprzedaz_iphone_a_apple_w_chinach_spadla_o_24_procent_wraz_ze_wzrostem_popularnosci_huawei-31934.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T09:43:40+00:00

<img src="https://ithardware.pl/artykuly/min/31934_1.jpg" />            Według badań firmy Counterpoint sprzedaż iPhone'a Apple w Chinach spadła o 24 procent w por&oacute;wnaniu do roku poprzedniego w ciągu pierwszych sześciu tygodni 2024 roku. Wzrost konkurencji ze strony lokalnych rywali, takich jak Huawei,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sprzedaz_iphone_a_apple_w_chinach_spadla_o_24_procent_wraz_ze_wzrostem_popularnosci_huawei-31934.html">https://ithardware.pl/aktualnosci/sprzedaz_iphone_a_apple_w_chinach_spadla_o_24_procent_wraz_ze_wzrostem_popularnosci_huawei-31934.html</a></p>

## To koniec pewnej ery. NVIDIA odsyła markę GTX na emeryturę
 - [https://ithardware.pl/aktualnosci/to_koniec_pewnej_ery_nvidia_odsyla_marke_gtx_na_emeryture-31928.html](https://ithardware.pl/aktualnosci/to_koniec_pewnej_ery_nvidia_odsyla_marke_gtx_na_emeryture-31928.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T09:29:01+00:00

<img src="https://ithardware.pl/artykuly/min/31928_1.jpg" />            NVIDIA wprowadziła markę GTX w 2004 roku wraz z serią GeForce 7 i high-endową kartą do gier GeForce 7800 GTX. Oznaczenie GTX przekształciło się w markę wraz z wypuszczeniem karty GeForce GTX 280 w 2008 roku i w ostatnich latach było ono...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/to_koniec_pewnej_ery_nvidia_odsyla_marke_gtx_na_emeryture-31928.html">https://ithardware.pl/aktualnosci/to_koniec_pewnej_ery_nvidia_odsyla_marke_gtx_na_emeryture-31928.html</a></p>

## Bitcoin pobił rekord wszechczasów. Cena kryptowaluty osiąga nowe wyżyny
 - [https://ithardware.pl/aktualnosci/bitcoin_pobil_rekord_wszechczasow_cena_kryptowaluty_osiaga_nowe_wyzyny-31930.html](https://ithardware.pl/aktualnosci/bitcoin_pobil_rekord_wszechczasow_cena_kryptowaluty_osiaga_nowe_wyzyny-31930.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T08:23:33+00:00

<img src="https://ithardware.pl/artykuly/min/31930_1.jpg" />            Bitcoin (BTC) pobił wczoraj rekord ceny, osiągając poziom powyżej 69 324 USD, ale bardzo szybko zaliczył też spory spadek o ponad 10%, ponieważ właściciele tej kryptowaluty szybko zaczęli wyprzedawać ją na giełdach, powodując w pewnym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/bitcoin_pobil_rekord_wszechczasow_cena_kryptowaluty_osiaga_nowe_wyzyny-31930.html">https://ithardware.pl/aktualnosci/bitcoin_pobil_rekord_wszechczasow_cena_kryptowaluty_osiaga_nowe_wyzyny-31930.html</a></p>

## Nothing Phone (2a) oficjalnie. Mocny średniak z oryginalnym designem w dobrej cenie
 - [https://ithardware.pl/aktualnosci/nothing_phone_2a_oficjalnie_mocny_sredniak_z_oryginalnym_designem_w_dobrej_cenie-31927.html](https://ithardware.pl/aktualnosci/nothing_phone_2a_oficjalnie_mocny_sredniak_z_oryginalnym_designem_w_dobrej_cenie-31927.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T08:03:57+00:00

<img src="https://ithardware.pl/artykuly/min/31927_1.jpg" />            Nothing Phone (2a) właśnie zadebiutował na rynku i oferuje bardzo zbliżone możliwości do modelu Nothing Phone (2) w niższej cenie. Producent zapewnia, że zapewnia optymalne codzienne doświadczenia dzięki wiedzy Nothing w zakresie inżynierii i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nothing_phone_2a_oficjalnie_mocny_sredniak_z_oryginalnym_designem_w_dobrej_cenie-31927.html">https://ithardware.pl/aktualnosci/nothing_phone_2a_oficjalnie_mocny_sredniak_z_oryginalnym_designem_w_dobrej_cenie-31927.html</a></p>

## HBO Max również będzie blokować dzielenie się kontem. Firma zapowiada działania jeszcze w tym roku
 - [https://ithardware.pl/aktualnosci/hbo_max_rowniez_bedzie_blokowac_dzielenie_sie_kontem_firma_zapowiada_dzialania_jeszcze_w_tym_roku-31926.html](https://ithardware.pl/aktualnosci/hbo_max_rowniez_bedzie_blokowac_dzielenie_sie_kontem_firma_zapowiada_dzialania_jeszcze_w_tym_roku-31926.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-03-06T07:10:45+00:00

<img src="https://ithardware.pl/artykuly/min/31926_1.jpg" />            Warner Bros. Discovery (WBD) planuje p&oacute;jść śladami Netflixa oraz Disneya i uniemożliwić użytkownikom Max udostępnianie swoich haseł znajomym i rodzinie, kt&oacute;rzy nie mieszkają w gł&oacute;wnym gospodarstwie domowym.&nbsp;

Jak...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hbo_max_rowniez_bedzie_blokowac_dzielenie_sie_kontem_firma_zapowiada_dzialania_jeszcze_w_tym_roku-31926.html">https://ithardware.pl/aktualnosci/hbo_max_rowniez_bedzie_blokowac_dzielenie_sie_kontem_firma_zapowiada_dzialania_jeszcze_w_tym_roku-31926.html</a></p>

