# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Jeremy Hunt’s Budget: key points at a glance
 - [https://www.telegraph.co.uk/business/2024/03/06/budget-2024-key-points-jeremy-hunt-speech](https://www.telegraph.co.uk/business/2024/03/06/budget-2024-key-points-jeremy-hunt-speech)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2024-03-06T12:35:26+00:00



