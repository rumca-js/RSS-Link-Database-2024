# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Experience Han and Leia's Wedding All Over Again in This Sumptuous Star Wars Picture Book
 - [https://gizmodo.com/star-wars-han-leia-wedding-picture-book-disney-1851305581](https://gizmodo.com/star-wars-han-leia-wedding-picture-book-disney-1851305581)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-03-06T17:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/833d9e42cd9297e1823149141d589964.png" /><p>A few years ago Star Wars fans got to see the story of Han Solo and Leia Organa’s wedding—in <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/han-solo-princess-leia-wedding-canon-and-eu-explained-1848550618">the current canon</a>, at least—unfold in the pages of Beth Revis’ <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/han-and-leia-went-to-disney-world-for-their-honeymoon-1848533686">The Princess and the Scoundrel</a>. But now readers young and old will get to see Star Wars’ fairy tale wedding in a new light, with a gorgeous new picture book about…</p><p><a href="https://gizmodo.com/star-wars-han-leia-wedding-picture-book-disney-1851305581">Read more...</a></p>

