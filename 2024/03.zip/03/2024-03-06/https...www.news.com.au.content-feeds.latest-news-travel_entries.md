# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## ‘It’s crazy’: Strangers get huge shock on plane
 - [https://www.news.com.au/travel/travel-updates/travel-stories/strangers-get-huge-shock-on-plane/news-story/df0825e9d6649e8f4b213a6b3edd0dea?from=rss-basic](https://www.news.com.au/travel/travel-updates/travel-stories/strangers-get-huge-shock-on-plane/news-story/df0825e9d6649e8f4b213a6b3edd0dea?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-03-06T23:47:53.462310+00:00

A wild moment unfolded at the airport when a man was told he had already checked in with staff later uncovering something truly unbelievable.

## Virgin to offer pets in cabin flights
 - [https://www.news.com.au/travel/travel-advice/flights/virgins-first-of-its-kind-move-in-australia/news-story/3f4689dbbec58dd8c397ddce485be961?from=rss-basic](https://www.news.com.au/travel/travel-advice/flights/virgins-first-of-its-kind-move-in-australia/news-story/3f4689dbbec58dd8c397ddce485be961?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-03-06T22:43:05.850337+00:00

Virgin Australia has just revealed its plans for a huge change — and if approved, they will be the first-ever airline in the country to offer it.

## Unusual sight on new flight to Australia
 - [https://www.news.com.au/travel/travel-advice/flights/turkish-airlines-istanbul-to-melbourne-flight-features-flying-chefs/news-story/bc01ad2785284930022a6146df3ef9d8?from=rss-basic](https://www.news.com.au/travel/travel-advice/flights/turkish-airlines-istanbul-to-melbourne-flight-features-flying-chefs/news-story/bc01ad2785284930022a6146df3ef9d8?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-03-06T20:34:15.321327+00:00

As Turkish Airlines start a new route between Melbourne and Istanbul, their in flight staff featured a surprising appearance.

## Aldi’s bizarre $50 item makes a comeback
 - [https://www.news.com.au/travel/travel-ideas/best-of-travel/aldi-bring-back-the-viral-sleeping-bag-onesie-just-in-time-for-winter/news-story/685e0d07753e1e28a3a8793512a2583b?from=rss-basic](https://www.news.com.au/travel/travel-ideas/best-of-travel/aldi-bring-back-the-viral-sleeping-bag-onesie-just-in-time-for-winter/news-story/685e0d07753e1e28a3a8793512a2583b?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel
 - date published: 2024-03-06T02:18:14.147160+00:00

As summer starts to become a distant memory, with winter well on the way — a fan-favourite item from Aldi is making a massive comeback.

