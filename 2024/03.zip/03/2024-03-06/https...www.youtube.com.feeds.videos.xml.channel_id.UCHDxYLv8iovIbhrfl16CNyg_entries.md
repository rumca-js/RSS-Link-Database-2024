# Source:GameLinked, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHDxYLv8iovIbhrfl16CNyg, language:en

## Nintendo Wins, Gamers Lose
 - [https://www.youtube.com/watch?v=fDgDDCN7p98](https://www.youtube.com/watch?v=fDgDDCN7p98)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHDxYLv8iovIbhrfl16CNyg
 - date published: 2024-03-06T02:17:31+00:00

Check out the Ridge 11-Year Anniversary Sale using the link below and save today! https://ridge.com/GAMELINKED

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► LISTEN TO THE GAMING NEWS: https://lmg.gg/GameLinkedPodcast
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► WHERE WE BUY GAMES: https://lmg.gg/shopgames

NEWS SOURCES: https://lmg.gg/VCj7o
-------------------------------------------------------------------
Timestamps:
0:00 How dare you, Dave?
0:10 Nintendo kills Yuzu, Citra emulators
1:23 Meta to delete all Oculus accounts
2:20 Helldivers 2 getting mechs soon
4:20 QUICK BITS INTRO
4:30 Dune: Awakening details
5:18 Rumored Titanfall game
5:53 Suicide Squad PS refunds
6:25 BG3 Xbox will have 4 discs
7:02 Arthur Clark narrating audiobook

