# Source:RP - Finanse osobiste, URL:https://pieniadze.rp.pl/rss/1941-finanse-osobiste, language:pl-PL

## Granty na cyfryzację firm w przygotowaniu
 - [https://pieniadze.rp.pl/finanse-firmy/art39947411-granty-na-cyfryzacje-firm-w-przygotowaniu](https://pieniadze.rp.pl/finanse-firmy/art39947411-granty-na-cyfryzacje-firm-w-przygotowaniu)
 - RSS feed: https://pieniadze.rp.pl/rss/1941-finanse-osobiste
 - date published: 2024-03-06T02:00:00+00:00

Agencja Rozwoju Przemysłu przygotowuje się do uruchomienia nowego projektu grantowego o nazwie „Dig.IT. Transformacja cyfrowa polskich MŚP”.

