# Source:C++ Weekly With Jason Turner, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw, language:en

## CS101++ - What is`goto`?
 - [https://www.youtube.com/watch?v=-HoOCRav4oc](https://www.youtube.com/watch?v=-HoOCRav4oc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw
 - date published: 2024-03-06T16:29:52+00:00

☟☟ Awesome T-Shirts! Sponsors! Books! ☟☟

https://github.com/lefticus/cpp_weekly/discussions/categories/cs101 for open ended conversions about CS101++ videos 

T-SHIRTS AVAILABLE!

► The best C++ T-Shirts anywhere! https://my-store-d16a2f.creator-spring.com/


WANT MORE JASON?

► My Training Classes: http://emptycrate.com/training.html
► Follow me on twitter: https://twitter.com/lefticus


SUPPORT THE CHANNEL

► Patreon: https://www.patreon.com/lefticus 
► Github Sponsors: https://github.com/sponsors/lefticus
► Paypal Donation: https://www.paypal.com/donate/?hosted_button_id=PQ4A2V6ZZFQEU


GET INVOLVED

► Video Idea List: https://github.com/lefticus/cpp_weekly/issues


JASON'S BOOKS

► C++ Best Practices
  Amazon Paperback: https://amzn.to/3wpAU3Z
  Leanpub Ebook: https://leanpub.com/cppbestpractices


JASON'S PUZZLE BOOKS

► Object Lifetime Puzzlers Book 1
  Amazon Paperback: https://amzn.to/3g6Ervj
  Leanpub Ebook: https://leanpub.com/objectlifetimepuzzlers_book1
  
► Obje

