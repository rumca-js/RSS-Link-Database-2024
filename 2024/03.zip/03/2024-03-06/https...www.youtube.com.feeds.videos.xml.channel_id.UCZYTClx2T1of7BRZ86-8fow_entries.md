# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## Finding True North Is Harder Than You Think
 - [https://www.youtube.com/watch?v=rkGJGsJM77I](https://www.youtube.com/watch?v=rkGJGsJM77I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2024-03-06T22:00:25+00:00

Sure, you can point to the geographic north pole on a globe. But getting there, even with fancy equipment like GPS, isn't so straightforward. So scientists are looking into a navigation tool some animals use naturally.

Hosted by: Stefan Chin
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Adam Brainard, Alex Hackman, Ash, Benjamin Carleski, Bryan Cloer, charles george, Chris Mackey, Chris Peters, Christoph Schwanke, Christopher R Boucher, DrakoEsper, Eric Jensen, Friso, Garrett Galloway, Harrison Mills, J. Copen, Jaap Westera, Jason A Saslow, Jeffrey Mckishen, Jeremy Mattern, Kenny Wilson, Kevin Bealer, Kevin Knupp, Lyndsay Brown, Matt Curls, Michelle Dove, Piya Shedden, Rizwan Kassim, Sam Lutfi
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com

