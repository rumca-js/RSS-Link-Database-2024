# Source:Le Monde - science, URL:https://www.lemonde.fr/en/science/rss_full.xml, language:en-US

## Thousands of animal experiments in France are conducted 'outside the regulatory framework'
 - [https://www.lemonde.fr/en/science/article/2024/03/06/thousands-of-animal-experiments-in-france-are-conducted-outside-the-regulatory-framework_6591506_10.html](https://www.lemonde.fr/en/science/article/2024/03/06/thousands-of-animal-experiments-in-france-are-conducted-outside-the-regulatory-framework_6591506_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2024-03-06T15:08:21+00:00

An administrative court has suspended 10 authorizations for research projects involving mice, hamsters and macaques.

