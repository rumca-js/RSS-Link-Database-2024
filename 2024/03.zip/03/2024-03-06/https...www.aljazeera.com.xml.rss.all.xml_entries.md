# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Minnesota’s ‘stunning’ uncommitted vote reveals enduring problem for Biden
 - [https://www.aljazeera.com/news/2024/3/6/minnesotas-stunning-uncommitted-vote-reveals-enduring-problem-for-biden?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/minnesotas-stunning-uncommitted-vote-reveals-enduring-problem-for-biden?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T22:19:49+00:00

Analysts say the Super Tuesday results show the protest movement against Biden extends beyond Arab and Muslim voters.

## US denies pressuring Haiti PM Henry to resign, urges political ‘transition’
 - [https://www.aljazeera.com/news/2024/3/6/us-denies-pressuring-haiti-pm-henry-to-resign-urges-political-transition?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/us-denies-pressuring-haiti-pm-henry-to-resign-urges-political-transition?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T21:12:33+00:00

US officials urge Ariel Henry to set up &#039;inclusive governance structure&#039; that will stem violence and lead to elections.

## South Africa asks ICJ for more measures against Israel over Gaza ‘famine’
 - [https://www.aljazeera.com/news/2024/3/6/south-africa-asks-icj-for-more-measures-against-israel-over-gaza-famine?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/south-africa-asks-icj-for-more-measures-against-israel-over-gaza-famine?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T20:50:26+00:00

South Africa warns Palestinians in Gaza are facing starvation, asks court to order all parties to cease hostilities.

## Will Joe Biden and Donald Trump face each other in the US elections?
 - [https://www.aljazeera.com/program/inside-story/2024/3/6/will-joe-biden-and-donald-trump-face-each-other-in-the-us-elections?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/3/6/will-joe-biden-and-donald-trump-face-each-other-in-the-us-elections?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T19:41:34+00:00

The current and former presidents swept polls in the Super Tuesday vote, but both have vulnerabilities.

## The US prepares new ceasefire draft resolution
 - [https://www.aljazeera.com/program/newsfeed/2024/3/6/the-us-prepares-new-ceasefire-draft-resolution?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/3/6/the-us-prepares-new-ceasefire-draft-resolution?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T19:35:33+00:00

The US says it’s prepared a new ceasefire draft resolution to secure a 6-week ceasefire in Gaza.

## Biden to deliver State of the Union address: All you need to know
 - [https://www.aljazeera.com/news/2024/3/6/biden-to-deliver-state-of-the-union-address-all-you-need-to-know?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/biden-to-deliver-state-of-the-union-address-all-you-need-to-know?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T19:24:56+00:00

The US president will lay out his policy priorities in a speech to Congress eight months before November&#039;s election.

## EU aid chief visits UNRWA camp in Ramallah as funding is restored
 - [https://www.aljazeera.com/program/newsfeed/2024/3/6/eu-aid-chief-visits-unrwa-camp-in-ramallah-as-funding-is-restored?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/3/6/eu-aid-chief-visits-unrwa-camp-in-ramallah-as-funding-is-restored?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T18:56:36+00:00

The EU’s Humanitarian Commissioner says he’s seen first-hand how important the work of UNRWA is

## Russia attacks Ukraine’s Odesa as Greek PM visits war-stricken city
 - [https://www.aljazeera.com/news/2024/3/6/ukraines-odesa-hit-in-attack-as-greek-pm-was-touring-war-stricken-city?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/ukraines-odesa-hit-in-attack-as-greek-pm-was-touring-war-stricken-city?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T18:55:59+00:00

At least five people killed in attack, a navy spokesperson was quoted as saying by Ukrainska Pravda media outlet.

## Ayotzinapa protesters knock down door of Mexico’s presidential palace
 - [https://www.aljazeera.com/news/2024/3/6/ayotzinapa-protesters-knock-down-door-of-mexicos-presidential-palace?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/ayotzinapa-protesters-knock-down-door-of-mexicos-presidential-palace?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T18:13:44+00:00

Demonstrators used a truck to ram the palace door, as part of a protest for justice in the case of 43 missing students.

## Houthi missile attack forces crew to abandon ship in Gulf of Aden
 - [https://www.aljazeera.com/news/2024/3/6/suspected-houthi-attack-ship-gulf-of-aden-yemen?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/suspected-houthi-attack-ship-gulf-of-aden-yemen?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T17:13:18+00:00

Officials say the attack on the Greek-owned, Barbados-flagged ship has caused fatalities.

## Nikki Haley suspends US presidential campaign
 - [https://www.aljazeera.com/program/newsfeed/2024/3/6/nikki-haley-suspends-us-presidential-campaign?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/3/6/nikki-haley-suspends-us-presidential-campaign?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T16:33:22+00:00

Nikki Haley has suspended her campaign for US president, leaving Donald Trump as the leading candidate for Republicans.

## What happened on Super Tuesday
 - [https://www.aljazeera.com/program/newsfeed/2024/3/6/what-happened-on-super-tuesday?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/3/6/what-happened-on-super-tuesday?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T16:26:57+00:00

Results revealed President Joe Biden and former President Donald Trump could face vulnerabilities in the US election.

## Russia takes more ground in east Ukraine but loses another ship at sea
 - [https://www.aljazeera.com/news/2024/3/6/russia-takes-more-ground-in-east-ukraine-but-loses-another-ship-at-sea?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/russia-takes-more-ground-in-east-ukraine-but-loses-another-ship-at-sea?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T16:16:02+00:00

Ukraine’s naval drones score another hit in the past week, but its troops continue to fall back in Donetsk.

## Egypt strikes expanded $8bn deal with the IMF
 - [https://www.aljazeera.com/news/2024/3/6/egypt-strikes-expanded-8-billion-deal-with-the-imf?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/egypt-strikes-expanded-8-billion-deal-with-the-imf?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T16:10:25+00:00

The deal comes as the central bank said it would let the Egyptian pound trade freely.

## Yulia Navalnaya calls on Russians to join election protest
 - [https://www.aljazeera.com/program/newsfeed/2024/3/6/yulia-navalnaya-calls-on-russians-to-join-election-protest?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/3/6/yulia-navalnaya-calls-on-russians-to-join-election-protest?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T16:09:21+00:00

Yulia Navalnaya, widow of opposition leader Alexey Navalny, called on Russians to join an election day protest.

## Could soaring housing prices affect Biden’s re-election bid?
 - [https://www.aljazeera.com/program/counting-the-cost/2024/3/6/could-soaring-housing-prices-affect-bidens-re-election-bid?traffic_source=rss](https://www.aljazeera.com/program/counting-the-cost/2024/3/6/could-soaring-housing-prices-affect-bidens-re-election-bid?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T15:21:00+00:00

The US economy is remarkably strong. But, borrowing costs are high and many Americans can&#039;t afford to buy a home.

## Portugal braces for snap election as far right advances
 - [https://www.aljazeera.com/news/2024/3/6/portugal-braces-for-general-election-as-far-right-advances?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/portugal-braces-for-general-election-as-far-right-advances?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T14:44:39+00:00

Chega, an Islamophobic nationalist party, is predicted to win a large chunk of support in Sunday&#039;s vote.

## China does not have the leverage to end the Red Sea crisis; the US does
 - [https://www.aljazeera.com/opinions/2024/3/6/china-does-not-have-the-leverage-to-end-the-red-sea-crisis-the-us-does?traffic_source=rss](https://www.aljazeera.com/opinions/2024/3/6/china-does-not-have-the-leverage-to-end-the-red-sea-crisis-the-us-does?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T14:16:31+00:00

Contrary to US claims, Chinese influence over Iran is limited, and it cannot help stop Houthi attacks.

## Haiti gang leader warns of ‘genocide’ if PM returns
 - [https://www.aljazeera.com/program/newsfeed/2024/3/6/haiti-gang-leader-warns-of-genocide-if-pm-returns?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/3/6/haiti-gang-leader-warns-of-genocide-if-pm-returns?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T13:56:44+00:00

The gang leader behind an uprising in Haiti while their leader is out of the country has said there could be civil war.

## Trump’s Gaza comments highlight tough choice for peace-supporting US voters
 - [https://www.aljazeera.com/news/2024/3/6/trumps-talk-on-gaza-highlights-stark-choice-for-voters-in-us-election?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/trumps-talk-on-gaza-highlights-stark-choice-for-voters-in-us-election?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T13:38:38+00:00

Former president&#039;s rhetoric shows voters seeking to punish Biden for backing Israel face dilemma in upcoming election.

## Israel is pillaging not just Gaza’s cities but also its waters
 - [https://www.aljazeera.com/opinions/2024/3/6/israel-is-pillaging-not-just-gazas-cities-but-also-its-waters?traffic_source=rss](https://www.aljazeera.com/opinions/2024/3/6/israel-is-pillaging-not-just-gazas-cities-but-also-its-waters?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T13:26:41+00:00

Foreign companies, including European ones, are helping Israel loot Gaza’s natural gas reserves. They must be stopped.

## How to distract a starving child: Hunger in Rafah amid Israel’s war on Gaza
 - [https://www.aljazeera.com/news/2024/3/6/how-to-distract-a-starving-child-hunger-in-rafah-amid-israels-war-on-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/how-to-distract-a-starving-child-hunger-in-rafah-amid-israels-war-on-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T13:25:21+00:00

Two mothers recount how hunger took hold of their children and what they do to try to make sure they survive somehow.

## Children in Gaza march to demand ceasefire before Ramadan
 - [https://www.aljazeera.com/program/newsfeed/2024/3/6/children-in-gaza-march-to-demand-ceasefire-before-ramadan?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/3/6/children-in-gaza-march-to-demand-ceasefire-before-ramadan?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T12:56:41+00:00

Children in Gaza have staged a protest march to demand an immediate ceasefire to end the war before Ramadan.

## ‘Joyful but afraid’: Disabled Indian academic Saibaba’s family on acquittal
 - [https://www.aljazeera.com/news/2024/3/6/joyful-but-afraid-disabled-india-academic-saibabas-family-on-acquittal?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/joyful-but-afraid-disabled-india-academic-saibabas-family-on-acquittal?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T12:10:26+00:00

Wheelchair-bound ex-Delhi University professor is acquitted after 10 years of imprisonment over alleged Maoist links.

## Navalny’s widow calls for Russia election day protests against Putin
 - [https://www.aljazeera.com/news/2024/3/6/navalnys-widow-calls-for-russia-election-day-protests-against-putin?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/navalnys-widow-calls-for-russia-election-day-protests-against-putin?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T12:01:04+00:00

Yulia Navalnaya calls presidential election a &#039;sham&#039;, urges Russians to register their protest at polling stations.

## New AI video tools increase worries of deepfakes ahead of elections
 - [https://www.aljazeera.com/economy/2024/3/6/new-ai-video-tools-increase-worries-of-deepfakes-ahead-of-elections?traffic_source=rss](https://www.aljazeera.com/economy/2024/3/6/new-ai-video-tools-increase-worries-of-deepfakes-ahead-of-elections?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T12:01:03+00:00

Experts worry malicious actors could use AI to create deepfakes, confusing and misleading voters in an election year.

## Haley set to quit Republican nomination race
 - [https://www.aljazeera.com/news/2024/3/6/haley-set-to-quit-republican-nomination-race?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/haley-set-to-quit-republican-nomination-race?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T11:50:43+00:00

This is a breaking news story, more details to follow.

## Haitian capital ‘paralysed’ by wave of violence
 - [https://www.aljazeera.com/gallery/2024/3/6/haitian-capital-paralysed-by-wave-of-violence?traffic_source=rss](https://www.aljazeera.com/gallery/2024/3/6/haitian-capital-paralysed-by-wave-of-violence?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T11:50:19+00:00

Port-au-Prince gripped by violence as authorities struggle to regain control from armed gangs wreaking havoc.

## Pakistan top court says ex-PM Bhutto, hanged in 1979, was denied fair trial
 - [https://www.aljazeera.com/news/2024/3/6/pakistan-top-court-says-ex-pm-bhutto-hanged-in-1979-was-denied-fair-trial?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/pakistan-top-court-says-ex-pm-bhutto-hanged-in-1979-was-denied-fair-trial?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T11:42:19+00:00

Court&#039;s ruling comes in response to a 2011 reference filed by Bhutto&#039;s son-in-law and former President Asif Ali Zardari.

## Why are people blaming Yemen’s Houthis for cutting the Red Sea cables?
 - [https://www.aljazeera.com/news/2024/3/6/why-are-people-blaming-the-houthis-for-cutting-the-red-sea-cables?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/why-are-people-blaming-the-houthis-for-cutting-the-red-sea-cables?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T11:07:58+00:00

Questions swirled after four cables were cut; some observers say it may be the Houthis, others say it was an accident.

## Palestinian boy talks about his only friend dying in Gaza
 - [https://www.aljazeera.com/program/newsfeed/2024/3/6/palestinian-boy-talks-about-his-only-friend-dying-in-gaza?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/3/6/palestinian-boy-talks-about-his-only-friend-dying-in-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T11:06:58+00:00

This Palestinian boy in Gaza told his uncle he was sad because his only friend had been killed.

## UK: University Challenge student wrongly accused of anti-Semitism wins case
 - [https://www.aljazeera.com/news/2024/3/6/uk-university-challenge-student-wrongly-accused-of-anti-semitism-wins-case?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/uk-university-challenge-student-wrongly-accused-of-anti-semitism-wins-case?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T10:42:40+00:00

Jacqueline Foster, a Conservative member of the House of Lords, forced to pay damages and apologise to Melika Gorgianeh.

## Spanish prosecutors accuse Real Madrid manager Carlo Ancelotti of tax fraud
 - [https://www.aljazeera.com/sports/2024/3/6/la-liga-real-madrid-carlo-ancelotti-tax-fraud-jail-term?traffic_source=rss](https://www.aljazeera.com/sports/2024/3/6/la-liga-real-madrid-carlo-ancelotti-tax-fraud-jail-term?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T10:18:48+00:00

Prosecutors have called for a prison sentence of four years and nine months for the Italian manager.

## What went wrong with the British media coverage of the Gaza war?
 - [https://www.aljazeera.com/opinions/2024/3/6/what-went-wrong-with-the-british-media-coverage-of-the-gaza-war?traffic_source=rss](https://www.aljazeera.com/opinions/2024/3/6/what-went-wrong-with-the-british-media-coverage-of-the-gaza-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T09:28:21+00:00

All journalists should take note of a new report on the shortcomings of British media&#039;s output on Israel&#039;s war on Gaza.

## In Gaza, football means life amid Israel’s continuing war
 - [https://www.aljazeera.com/sports/2024/3/6/israel-war-on-gaza-football-fans-champions-league-real-madrid-barcelona-fans-children-fifa-uefa?traffic_source=rss](https://www.aljazeera.com/sports/2024/3/6/israel-war-on-gaza-football-fans-champions-league-real-madrid-barcelona-fans-children-fifa-uefa?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T09:22:18+00:00

The people of Gaza have kept alive their love for football amid displacement, destruction and communications blackouts.

## When is Ramadan 2024 and how is the moon sighted?
 - [https://www.aljazeera.com/news/2024/3/6/when-is-ramadan-2024-and-how-is-the-moon-sighted?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/when-is-ramadan-2024-and-how-is-the-moon-sighted?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T08:54:27+00:00

For most countries, the first day of fasting is likely to be March 12, depending on the sighting of the new moon.

## Chinese coast guard ship blasts water cannon at Philippine vessel
 - [https://www.aljazeera.com/program/newsfeed/2024/3/6/chinese-coast-guard-ship-blasts-water-cannon-at-philippine-vessel?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/3/6/chinese-coast-guard-ship-blasts-water-cannon-at-philippine-vessel?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T08:40:52+00:00

Video shows a Chinese coast guard ship blasting a water cannon through the window of a civilian Philippine vessel.

## Venezuela sets presidential polls for July amid ban on opposition candidate
 - [https://www.aljazeera.com/news/2024/3/6/venezuela-sets-presidential-polls-for-july-amid-ban-on-opposition-candidate?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/venezuela-sets-presidential-polls-for-july-amid-ban-on-opposition-candidate?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T08:32:17+00:00

Incumbent Maduro&#039;s strongest adversary, Maria Corina Machado, was banned from public office for alleged corruption.

## Sudan war threatens ‘world’s largest hunger crisis’: WFP
 - [https://www.aljazeera.com/news/2024/3/6/sudan-war-could-trigger-worst-famine-in-world-wfp?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/sudan-war-could-trigger-worst-famine-in-world-wfp?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T08:29:05+00:00

Warring generals leave at least 25 million facing food insecurity, with humanitarian response at ‘breaking point’.

## Who is Jason Palmer, the only Democrat to beat Joe Biden in American Samoa?
 - [https://www.aljazeera.com/news/2024/3/6/who-is-jason-palmer-the-only-democrat-to-beat-joe-biden-on-super-tuesday?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/who-is-jason-palmer-the-only-democrat-to-beat-joe-biden-on-super-tuesday?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T07:56:50+00:00

Palmer won against Biden in American Samoa, a territory he never visited before the caucus.

## Indigenous Bolivian women take up taekwondo against gender-based violence
 - [https://www.aljazeera.com/gallery/2024/3/6/indigenous-bolivian-women-take-up-taekwondo-against-gender-based-violence?traffic_source=rss](https://www.aljazeera.com/gallery/2024/3/6/indigenous-bolivian-women-take-up-taekwondo-against-gender-based-violence?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T07:24:56+00:00

Bolivia has one of the highest rates of gender violence, with 80 percent women experiencing it in their lifetime.

## Peru’s PM Alberto Otarola quits amid claims of influence peddling
 - [https://www.aljazeera.com/news/2024/3/6/peru-pm-resigns-over-influence-peddling-claims?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/peru-pm-resigns-over-influence-peddling-claims?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T07:18:51+00:00

Alberto Otarola quit despite denying he attempted to influence government contracts to help love interest.

## Israel’s war on Gaza: List of key events, day 152
 - [https://www.aljazeera.com/news/2024/3/6/israels-war-on-gaza-list-of-key-events-day-152?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/israels-war-on-gaza-list-of-key-events-day-152?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T07:10:19+00:00

Israel continues attacks while its forces turned back a 14-truck food aid convoy.

## Five takeaways from the US Super Tuesday primary races
 - [https://www.aljazeera.com/news/2024/3/6/five-takeaways-from-the-us-super-tuesday-primary-races?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/five-takeaways-from-the-us-super-tuesday-primary-races?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T06:59:34+00:00

Nikki Haley delivers a powerful rebuke to Trump with a victory in Vermont, while Biden faces continued protest.

## Can Jeremy Hunt’s spring budget revive Britain’s Tories?
 - [https://www.aljazeera.com/news/2024/3/6/can-jeremy-hunts-spring-budget-revive-britains-tories?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/can-jeremy-hunts-spring-budget-revive-britains-tories?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T06:41:01+00:00

Will the chancellor offer tax cuts in a bid to win votes or steer clear of any bold moves with potential to backfire?

## Simona Halep set for tennis return as doping ban is cut to nine months
 - [https://www.aljazeera.com/sports/2024/3/6/simona-halep-set-for-tennis-return-as-doping-ban-is-cut-to-nine-months?traffic_source=rss](https://www.aljazeera.com/sports/2024/3/6/simona-halep-set-for-tennis-return-as-doping-ban-is-cut-to-nine-months?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T06:33:01+00:00

The former Grand Slam champion was banned for four years in 2022, but can now return to the game immediately.

## Army brat to Pakistan’s ‘anti-establishment’ face: Who is Omar Ayub Khan?
 - [https://www.aljazeera.com/news/2024/3/6/army-brat-to-anti-establishment-evolution-of-pakistans-omar-ayub-khan?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/army-brat-to-anti-establishment-evolution-of-pakistans-omar-ayub-khan?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T05:23:37+00:00

His grandfather led Pakistan&#039;s first military coup. Is PTI&#039;s Omar Ayub Khan the democracy champion his country needs?

## Haiti gang leader warns of civil war unless PM Ariel Henry steps down
 - [https://www.aljazeera.com/news/2024/3/6/haiti-gang-leader-warns-of-civil-war-unless-pm-ariel-henry-steps-down?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/haiti-gang-leader-warns-of-civil-war-unless-pm-ariel-henry-steps-down?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T04:28:53+00:00

Thousands have fled since gangs began a coordinated campaign to push Henry from power.

## Refugees, migrants held in ‘violent, squalid’ Malaysian detention centres
 - [https://www.aljazeera.com/news/2024/3/6/refugees-migrants-held-in-violent-squalid-malaysian-detention-centres?traffic_source=rss](https://www.aljazeera.com/news/2024/3/6/refugees-migrants-held-in-violent-squalid-malaysian-detention-centres?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-03-06T04:21:50+00:00

Human Rights Watch report accuses Malaysia of subjecting detainees, including children, to torture.

