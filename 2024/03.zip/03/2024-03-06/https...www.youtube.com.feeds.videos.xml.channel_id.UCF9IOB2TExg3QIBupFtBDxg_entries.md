# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## New and damning evidence
 - [https://www.youtube.com/watch?v=wXcMhWEjkqE](https://www.youtube.com/watch?v=wXcMhWEjkqE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-03-06T10:47:59+00:00

To be reported to the UK police. Read the full letter here, https://twitter.com/JimFergusonUK/status/1765289139677618585/photo/1

