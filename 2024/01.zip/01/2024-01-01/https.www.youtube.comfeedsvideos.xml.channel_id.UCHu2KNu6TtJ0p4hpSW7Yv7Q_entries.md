# Source:Jazza, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHu2KNu6TtJ0p4hpSW7Yv7Q, language:en-US

## MAKE MOLDS with HOT GLUE?
 - [https://www.youtube.com/watch?v=IiRihgGPqP0](https://www.youtube.com/watch?v=IiRihgGPqP0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHu2KNu6TtJ0p4hpSW7Yv7Q
 - date published: 2024-01-01T12:03:00+00:00

This is a surprisingly useful #arthack for making terrain with Hot Glue! This short was made with @CapCutofficial  (spon)
👉CapCut for PC/Mac: https://www.capcut.com/tools/desktop-video-editor?utm_source=youtube&amp;utm_medium=social&amp;utm_campaign=jazzadec23
👉CapCut for Mobile: https://capcut-yt.onelink.me/W3Oy/v8cgkduv

