# Source:Insight News Media, URL:https://insightnews.media/feed/, language:en-US

## “Sponsors of the war” – top-10 international companies still operating in Russia in 2024
 - [https://insightnews.media/sponsors-of-the-war-top-10-international-companies-still-operating-in-russia-in-2024](https://insightnews.media/sponsors-of-the-war-top-10-international-companies-still-operating-in-russia-in-2024)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2024-01-01T14:53:18+00:00

<p>In 2024, during the 22 months of Russia’s full-scale war against Ukraine, a large number of foreign companies refused to leave Russia and are still &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/sponsors-of-the-war-top-10-international-companies-still-operating-in-russia-in-2024/"> <span class="screen-reader-text">&#8220;Sponsors of the war&#8221; – top-10 international companies still operating in Russia in 2024</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/sponsors-of-the-war-top-10-international-companies-still-operating-in-russia-in-2024/">&#8220;Sponsors of the war&#8221; – top-10 international companies still operating in Russia in 2024</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

## Sanctioned Russian powder factories get cotton pulp from Central Asia
 - [https://insightnews.media/sanctioned-russian-powder-factories-get-cotton-pulp-from-central-asia](https://insightnews.media/sanctioned-russian-powder-factories-get-cotton-pulp-from-central-asia)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2024-01-01T09:02:47+00:00

<p>Sanctions have restricted Russian purchases of foreign military technologies. However, Moscow can still rely on its two Central Asian neighbors for gunpowder components, as exports &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/sanctioned-russian-powder-factories-get-cotton-pulp-from-central-asia/"> <span class="screen-reader-text">Sanctioned Russian powder factories get cotton pulp from Central Asia</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/sanctioned-russian-powder-factories-get-cotton-pulp-from-central-asia/">Sanctioned Russian powder factories get cotton pulp from Central Asia</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

