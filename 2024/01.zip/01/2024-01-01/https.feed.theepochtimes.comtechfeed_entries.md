# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Supreme Court’s John Roberts Urges ‘Caution’ on Using Artificial Intelligence
 - [https://www.theepochtimes.com/us/supreme-courts-john-roberts-urges-caution-on-using-artificial-intelligence-5556294](https://www.theepochtimes.com/us/supreme-courts-john-roberts-urges-caution-on-using-artificial-intelligence-5556294)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-01-01T15:02:08+00:00

Chief Justice John Roberts attends the State of the Union address in the House Chamber of the U.S. Capitol in Washington on Feb. 7, 2023. (Jacquelyn Martin/Pool/Getty Images)

