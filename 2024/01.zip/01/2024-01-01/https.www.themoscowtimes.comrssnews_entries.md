# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## St. Petersburg Police Round Up Thousands of Migrant Workers in New Year's Raids – Reports
 - [https://www.themoscowtimes.com/2024/01/01/st-petersburg-police-round-up-thousands-of-migrant-workers-in-new-years-raids-reports-a83624](https://www.themoscowtimes.com/2024/01/01/st-petersburg-police-round-up-thousands-of-migrant-workers-in-new-years-raids-reports-a83624)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-01T15:38:00+00:00

More than 600 of those detained had reportedly broken Russia’s immigration laws, with over 100 people expected to be deported from the country.

## Putin Says Russia Will 'Intensify' Strikes on Ukraine After Belgorod Attack
 - [https://www.themoscowtimes.com/2024/01/01/putin-says-russia-will-intensify-strikes-on-ukraine-after-belgorod-attack-a83623](https://www.themoscowtimes.com/2024/01/01/putin-says-russia-will-intensify-strikes-on-ukraine-after-belgorod-attack-a83623)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-01T13:06:14+00:00

"I'm burning with rage myself. But do we need to attack civilians? No, we hit military targets, and we'll continue to do that," Putin said.

## Far East Russia Issues Tsunami Warning After Earthquake Strikes Japan
 - [https://www.themoscowtimes.com/2024/01/01/far-east-russia-issues-tsunami-warning-after-earthquake-strikes-japan-a83622](https://www.themoscowtimes.com/2024/01/01/far-east-russia-issues-tsunami-warning-after-earthquake-strikes-japan-a83622)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-01T09:56:49+00:00

Authorities in Vladivostok said they expect waves to reach 30 centimeters by Monday evening and urged fishing vessels to return to shore.

## Zelensky Vows to Wreak 'Wrath' Against Russia in 2024
 - [https://www.themoscowtimes.com/2024/01/01/zelensky-vows-to-wreak-wrath-against-russia-in-2024-a83621](https://www.themoscowtimes.com/2024/01/01/zelensky-vows-to-wreak-wrath-against-russia-in-2024-a83621)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-01T08:37:37+00:00

"Next year, the enemy will feel the wrath of domestic production," Ukraine's president said during his New Year's Eve address.

