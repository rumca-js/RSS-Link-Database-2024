# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Policja znalazła ciało mężczyzny. Jego partnerka została zatrzymana
 - [https://wydarzenia.interia.pl/pomorskie/news-policja-znalazla-cialo-mezczyzny-jego-partnerka-zostala-zatr,nId,7243066](https://wydarzenia.interia.pl/pomorskie/news-policja-znalazla-cialo-mezczyzny-jego-partnerka-zostala-zatr,nId,7243066)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-01-01T15:22:19+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-policja-znalazla-cialo-mezczyzny-jego-partnerka-zostala-zatr,nId,7243066"><img align="left" alt="Policja znalazła ciało mężczyzny. Jego partnerka została zatrzymana" src="https://i.iplsc.com/policja-znalazla-cialo-mezczyzny-jego-partnerka-zostala-zatr/000IBEQFWNKWTFO4-C321.jpg" /></a>Policjanci zostali wezwani do interwencji w sprawie kłótni rodzinnej. Na miejscu znaleźli ciało 31-letniego mężczyzny. W sprawie została zatrzymana partnerka mężczyzny. Jak podano, funkcjonariusze już wcześniej musieli uspokajać skonfliktowaną parę.</p><br clear="all" />

## Skandaliczny słowa Jana Pietrzaka. Mówił o "barakach dla imigrantów"
 - [https://wydarzenia.interia.pl/kraj/news-skandaliczny-slowa-jana-pietrzaka-mowil-o-barakach-dla-imigr,nId,7243021](https://wydarzenia.interia.pl/kraj/news-skandaliczny-slowa-jana-pietrzaka-mowil-o-barakach-dla-imigr,nId,7243021)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-01-01T12:04:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-skandaliczny-slowa-jana-pietrzaka-mowil-o-barakach-dla-imigr,nId,7243021"><img align="left" alt="Skandaliczny słowa Jana Pietrzaka. Mówił o &quot;barakach dla imigrantów&quot;" src="https://i.iplsc.com/skandaliczny-slowa-jana-pietrzaka-mowil-o-barakach-dla-imigr/000IBDH4RCCSW657-C321.jpg" /></a>Jan Pietrzak na antenie Republiki powiedział - jak sam to określił - &quot;okrutny żart&quot;. - Mamy baraki dla imigrantów - stwierdził, wskazując na byłe, niemieckie obozy koncentracyjne w Polsce. Prowadząca program Katarzyna Gójska oceniła, że ktoś kto ma osobiste, tragiczne doświadczenia związane z wojną, &quot;może sobie pozwolić na więcej&quot;. Ośrodek Monitorowania Zachowań Rasistowskich przekazał, że zawiadomi w tej sprawie prokuraturę.</p><br clear="all" />

