# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Metawersum ma odpowiadać za 2,8 proc. światowego PKB. Ludzie zyskają "wirtualne dzieci" w abonamencie
 - [https://businessinsider.com.pl/technologie/nowe-technologie/w-metawersum-mamy-wychowywac-wirtualne-dzieci-za-25-dol-miesiecznie/2rfr70w](https://businessinsider.com.pl/technologie/nowe-technologie/w-metawersum-mamy-wychowywac-wirtualne-dzieci-za-25-dol-miesiecznie/2rfr70w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T15:40:42+00:00

W zeszłym roku większość z nas poznała określenie na to, co miało być zacieraniem granic między światem rzeczywistym a internetem: metawersum. Później jednak poznaliśmy ChatGPT i sztuczna inteligencja zdominowała nagłówki w mediach i codzienne dyskusje. Tymczasem metawersum nie zniknęło. Są kolejne nowości i doniesienia, a niektóre z nich wydają się dość zastanawiające. By nie powiedzieć: alarmujące.

## 2023 — rok hossy. 2024 — oczekiwana kontynuacja pozytywnej koniunktury w pierwszych miesiącach
 - [https://businessinsider.com.pl/gospodarka/2023-rok-hossy-co-czeka-rynki-w-2024-r-sebastian-buczek-odpowiada/634p3rl](https://businessinsider.com.pl/gospodarka/2023-rok-hossy-co-czeka-rynki-w-2024-r-sebastian-buczek-odpowiada/634p3rl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T14:50:52+00:00

Skończył się rok 2023. Do historii rynków finansowych przejdzie jako znakomity. Dlaczego? Inwestorzy osiągnęli spektakularne zyski. Najbezpieczniejsze fundusze dłużne, dawniej nazywane gotówkowymi, osiągnęły stopy zwrotu na poziomie 12 proc. Fundusze akcji dostarczyły ponad 40 proc. zysków — pisze dla Business Inisder Polska Sebastian Buczek, prezes Quercus TFI S.A.

## TikTok z ogromnymi przychodami. Użytkownicy wydali aż 10 miliardów dolarów na "napiwki"
 - [https://businessinsider.com.pl/technologie/nowe-technologie/tiktok-zgarnal-10-miliardow-dolarow-z-napiwkow-rekordowe-przychody/7e90w76](https://businessinsider.com.pl/technologie/nowe-technologie/tiktok-zgarnal-10-miliardow-dolarow-z-napiwkow-rekordowe-przychody/7e90w76)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T14:28:06+00:00

TikTok to pierwsza aplikacja mobilna, która nie jest grą, a mimo to wygenerowała aż 10 mld dol. przychodu – i mowa tu o wydatkach konsumentów, nie zaś reklamodawców. Platforma należąca do chińskiej spółki ByteDance jest na dobrej drodze, aby stać się najbardziej dochodową aplikacją w historii. Za co konkretnie płacą użytkownicy?

## Nie tylko Myszka Miki. 10 najważniejszych zmian na świecie w styczniu
 - [https://businessinsider.com.pl/wiadomosci/nie-tylko-myszka-miki-10-najwazniejszych-zmian-na-swiecie-w-styczniu/6gcf7eg](https://businessinsider.com.pl/wiadomosci/nie-tylko-myszka-miki-10-najwazniejszych-zmian-na-swiecie-w-styczniu/6gcf7eg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T14:17:12+00:00

W styczniu, po 95 latach wygasają prawa autorskie Disneya do kultowej Myszki Miki. W efekcie stanie się ona domeną publiczną. Do ważnego wydarzenia dojdzie na Tajwanie, a Rosja i Chiny zyskają nowych sojuszników. O czym jeszcze warto wiedzieć na początku nowego roku?

## Jak realny wzrost płac wpłynie na konsumpcję? Dyrektor finansowa Nestlé o 2024 r.
 - [https://businessinsider.com.pl/firmy/jak-realny-wzrost-plac-wplynie-na-konsumpcje-dyrektor-finansowa-nestle-o-2024-r/h50nqlh](https://businessinsider.com.pl/firmy/jak-realny-wzrost-plac-wplynie-na-konsumpcje-dyrektor-finansowa-nestle-o-2024-r/h50nqlh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T13:31:50+00:00

2023 r. oznaczał spadki sprzedaży wielu kategorii produktów FMCG. Jak jednak wskazuje Maria Teresa Lillo Sanz, dyrektor finansowa Nestlé Polska w specjalnym materiale dla Business Insider Polska, 2024 r. może być pod tym względem zauważalnie lepszy.

## Nvidia o 2024 roku: "Pora na łączenie sił i szukanie przyjaciół"
 - [https://businessinsider.com.pl/technologie/nowe-technologie/firmy-postawia-na-rozwoj-ai-i-infrastruktury-nvidia-dzieli-sie-prognoza-na-2024-rok/k2plkv6](https://businessinsider.com.pl/technologie/nowe-technologie/firmy-postawia-na-rozwoj-ai-i-infrastruktury-nvidia-dzieli-sie-prognoza-na-2024-rok/k2plkv6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T13:18:00+00:00

Rok 2024 będzie polegał na szukaniu przyjaciół – tworzeniu partnerstw i współprac z dostawcami usług chmurowych, firmami zajmującymi się przechowywaniem danych i analizą oraz innymi, którzy wiedzą, jak efektywnie obsługiwać, dostosowywać i wdrażać duże zbiory danych - pisze w komentarzu dla redakcji Business Insider Polska Rod Evans, wiceprezes ds. superkomputerów i sztucznej inteligencji na region EMEA w NVIDIA.

## Rząd Donalda Tuska się rozrasta. Jedno ministerstwo zamieniło się w dwa
 - [https://businessinsider.com.pl/wiadomosci/rzad-donalda-tuska-sie-rozrasta-jedno-ministerstwo-zamienilo-sie-w-dwa/648w1zw](https://businessinsider.com.pl/wiadomosci/rzad-donalda-tuska-sie-rozrasta-jedno-ministerstwo-zamienilo-sie-w-dwa/648w1zw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T13:15:01+00:00

Ministerstwo Edukacji i Nauki przeszło 1 stycznia 2024 r. do historii. Na jego miejsce powstały dwa odrębne resorty: edukacji narodowej oraz nauki i szkolnictwa wyższego.

## Pięć najważniejszych trendów, które zdecydują o polskim biznesie w 2024 roku
 - [https://businessinsider.com.pl/gospodarka/piec-najwazniejszych-trendow-ktore-zdecyduja-o-biznesie-w-2024-roku/9cz8rn2](https://businessinsider.com.pl/gospodarka/piec-najwazniejszych-trendow-ktore-zdecyduja-o-biznesie-w-2024-roku/9cz8rn2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T12:08:18+00:00

Zachodni biznes chce przenosić produkcję do Polski, bo uważa, że gdyby stracił dziś dostęp do azjatyckich producentów, to jest to dziesięciokrotnie większy problem niż zakręcenie kurka z rosyjskim gazem — piszą ekonomiści ING Banku Śląskiego w felietonie dla Business Insider Polska. To ich zdaniem spora szansa dla naszego kraju. Czekają nas jednak także wyzwania.

## AI ma jedną dużą wadę. Zużywa tyle prądu, co cała Holandia
 - [https://businessinsider.com.pl/technologie/nowe-technologie/ai-ma-jedna-duza-wade-zuzywa-tyle-pradu-co-cala-holandia/b2hkd51](https://businessinsider.com.pl/technologie/nowe-technologie/ai-ma-jedna-duza-wade-zuzywa-tyle-pradu-co-cala-holandia/b2hkd51)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T11:51:28+00:00

Sztuczna inteligencja to nie tylko narzędzia do generowania tekstów, grafik czy nawet wideo. To nie tylko technologia, która zmienia sposób, w jaki pracujemy i żyjemy. To także infrastruktura pełna serwerów i wyspecjalizowanych chipów, która ma wręcz gigantyczny apetyt na prąd.

## "Ogromny popyt i ograniczona dostępność mieszkań". Prezes Skanska o wyzwaniach na 2024 r.
 - [https://businessinsider.com.pl/wiadomosci/ograniczona-dostepnosc-mieszkan-skanska-o-wyzwaniach-na-2024-r/3wm44wz](https://businessinsider.com.pl/wiadomosci/ograniczona-dostepnosc-mieszkan-skanska-o-wyzwaniach-na-2024-r/3wm44wz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T11:30:30+00:00

Wprowadzanie zaawansowanych rozwiązań energetycznych i ekologicznych generuje dodatkowe koszty dla deweloperów, co z kolei wpływa na finalną cenę nieruchomości — o tym w felietonie dla Business Insidera Bartosz Kalinowski, prezes Skanska Residential Development Poland. Menadżer nakreśla szanse i wyzwania na 2024 r.

## Wyzwania gospodarcze rządu w 2024 roku
 - [https://businessinsider.com.pl/gospodarka/wyzwania-gospodarcze-rzadu-w-2024-roku/vqm5c1b](https://businessinsider.com.pl/gospodarka/wyzwania-gospodarcze-rzadu-w-2024-roku/vqm5c1b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T11:04:04+00:00

W 2024 r. w 76 państwach odbędą się wybory parlamentarne lub prezydenckie, gdzie liczba uprawnionych do głosowania przekroczy 4,2 mld osób, co odpowiada 51 proc. światowej populacji. Bieżący rok wyznaczy nową agendę polityczną i geoekonomiczną dla świata. Będzie to rok sprawdzianu demokracji i odporności poszczególnych gospodarek, który pokaże, czy tak głęboka erozja norm międzynarodowych i praw podstawowych jednostki, naznaczona zwłaszcza zaangażowaniem 32 państw w różnego rodzaju konflikty zbrojne, szczególnie widoczne na przykładzie wojny Rosji z Ukrainą oraz Izraela z Hamasem zredukuje niepewność. Czy jeszcze bardziej zaburzy, czy też odbuduje łańcuchy dostaw, wpływając zwłaszcza na ceny nośników energii? O tym w felietonie dla Business Insider pisze prof. Konrad Raczkowski, prorektor Uniwersytetu Kardynała Stefana Wyszyńskiego.

## Iwona Śledzińska-Katarasińska nie żyje. Była rekordzistką polskiej polityki
 - [https://businessinsider.com.pl/wiadomosci/iwona-sledzinska-katarasinska-nie-zyje-byla-rekordzistka-polskiej-polityki/fv53c0h](https://businessinsider.com.pl/wiadomosci/iwona-sledzinska-katarasinska-nie-zyje-byla-rekordzistka-polskiej-polityki/fv53c0h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T10:55:00+00:00

Nie żyje Iwona Śledzińska-Katarasińska. Polityczka była rekordzistką polskiego parlamentaryzmu — w Sejmie zasiadała nieprzerwanie przez 32 lata.

## Ostrzeżenie przed tsunami. Silne trzęsienie ziemi w Japonii
 - [https://businessinsider.com.pl/wiadomosci/ostrzezenie-przed-tsunami-silne-trzesienie-ziemi-w-japonii/p0fmcbw](https://businessinsider.com.pl/wiadomosci/ostrzezenie-przed-tsunami-silne-trzesienie-ziemi-w-japonii/p0fmcbw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T10:44:02+00:00

Silne trzęsienie ziemi, do którego doszło na Morzu Japońskim, władze z Tokio wydały ostrzeżenie o ryzyku powstania tsunami i zaleciły ewakuację zachodniego wybrzeża wyspy Honsiu. — Elektrownie atomowe działają bez zakłóceń — przekazał rzecznik japońskiego rządu Yoshimasa Hayashi.

## "To będzie dobry rok". Prezes PFR ma optymistyczne prognozy
 - [https://businessinsider.com.pl/gospodarka/makroekonomia/prezes-pfr-ma-optymistyczne-prognozy-to-bedzie-dobry-rok/80scy0y](https://businessinsider.com.pl/gospodarka/makroekonomia/prezes-pfr-ma-optymistyczne-prognozy-to-bedzie-dobry-rok/80scy0y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T09:57:58+00:00

Wzrost gospodarczy zaskoczy in plus. Najprawdopodobniej przekroczy 4 proc. w drugiej połowie roku, a być może zbliży się nawet do 5 proc. w końcówce roku – przewiduje w specjalnym komentarzu dla Business Insider Polska prezes Polskiego Funduszu Rozwoju Paweł Borys. Jego zdaniem konsumenci mogą oczekiwać wzrostu wynagrodzeń powyżej dynamiki spadającej inflacji, a firmy spadku presji kosztowej i silniejszego krajowego popytu.

## Dzień wolny 2 stycznia 2024 r. Wielu pracowników ma dłuższe święta
 - [https://businessinsider.com.pl/wiadomosci/dzien-wolny-2-stycznia-2024-r-wielu-pracownikow-ma-dluzsze-swieta/eyrn0ke](https://businessinsider.com.pl/wiadomosci/dzien-wolny-2-stycznia-2024-r-wielu-pracownikow-ma-dluzsze-swieta/eyrn0ke)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T09:31:00+00:00

Chociaż 2 stycznia nie jest dniem ustawowo wolnym od pracy, to 2 stycznia 2024 r. spora grupa pracowników będzie miała przedłużone święta. Decyzją premiera do pracy nie pójdą m.in. dla urzędników w korpusie służby cywilnej.

## 500 plus zmienia się w 800 plus. Co rodzice powinni wiedzieć?
 - [https://businessinsider.com.pl/prawo/500-plus-zmienia-sie-w-800-plus-co-rodzice-powinni-wiedziec/g4qdl2l](https://businessinsider.com.pl/prawo/500-plus-zmienia-sie-w-800-plus-co-rodzice-powinni-wiedziec/g4qdl2l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T08:50:36+00:00

Od 1 stycznia świadczenie 500 plus wzrasta o 300 zł. Więcej pieniędzy trafi do kilku milionów rodzin, bo obecnie wypłaca się je na ok. 6,7 mln dzieci. Opiekunowie nie muszą składać dodatkowych wniosków. Świadczenia w nowej wysokości będą wypłacane już od stycznia 2024 r.

## Witamy w Nowym Średniowieczu. Słynny myśliciel mówi, jak ma wyglądać porządek świata w 2100 r.
 - [https://businessinsider.com.pl/wiadomosci/przepowiednia-slynnego-mysliciela-jak-bedzie-wygladac-przyszlosc-nowe-sredniowiecze/pyjt9t9](https://businessinsider.com.pl/wiadomosci/przepowiednia-slynnego-mysliciela-jak-bedzie-wygladac-przyszlosc-nowe-sredniowiecze/pyjt9t9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T08:15:00+00:00

Od czasu inwazji Rosji na Ukrainę wydaje się, że zimna wojna wróciła. Ale tak nie jest, mówi globalny myśliciel Parag Khanna, który wiele lat temu przewidział zmiany władzy, które pojawiają się dzisiaj. Teraz po raz kolejny odważył się spojrzeć w przyszłość naszego świata.

## Co z cenami samochodów w 2024 r.? Siedem najważniejszych prognoz motoryzacyjnych na nowy rok
 - [https://businessinsider.com.pl/technologie/motoryzacja/co-z-cenami-samochodow-w-2024-r-7-najwazniejszych-prognoz-na-nowy-rok/gbfmb98](https://businessinsider.com.pl/technologie/motoryzacja/co-z-cenami-samochodow-w-2024-r-7-najwazniejszych-prognoz-na-nowy-rok/gbfmb98)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T08:12:32+00:00

Rok temu była niepewność, teraz optymizm rośnie. Agresywne rabaty, koniec ery manuali i sprzedaż blisko rekordu. Oto siedem prognoz z rynku samochodów w Polsce na zbliżający się rok.

## Do gospodarki wraca koniunktura. Ekonomiści mają dobre wieści na nowy rok
 - [https://businessinsider.com.pl/gospodarka/makroekonomia/ekonomisci-maja-dobre-wiesci-na-nowy-rok-gospodarka-przyspieszy-place-tez/mssc9ps](https://businessinsider.com.pl/gospodarka/makroekonomia/ekonomisci-maja-dobre-wiesci-na-nowy-rok-gospodarka-przyspieszy-place-tez/mssc9ps)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T08:04:22+00:00

Wzrost PKB wyraźnie przyspieszy, a bezrobocie pozostanie na rekordowo niskich poziomach. Do tego można się spodziewać, że wystrzelą płacę, które realnie zwiększą się najmocniej od sześciu lat. Takie wnioski płyną z przygotowanych specjalnie dla Business Insider Polska prognoz ekonomistów z największych banków w Polsce.

## Kurs EUR/PLN 1 stycznia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-1-stycznia-2024-r/cc5lg10](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-1-stycznia-2024-r/cc5lg10)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T05:00:01+00:00

Przedstawiamy notowania aktualnego kursu waluty euro z dnia 1 stycznia 2024.  Wczoraj wynosił on: 4,34475 zł. Od kursu uzależnione są ceny importowanych towarów oraz usług. Obecnie euro jest walutą obowiązującą w 20 państwach członkowskich Unii Europejskiej, a także kilku, które nie są jej członkami.

## Pięć minut w Korei Północnej. Pojechałam na najbardziej strzeżoną granicę świata
 - [https://businessinsider.com.pl/wiadomosci/kup-sobie-wlasnego-kim-dzong-una-tak-wyglada-najbardziej-strzezona-granica-swiata/m11h7me](https://businessinsider.com.pl/wiadomosci/kup-sobie-wlasnego-kim-dzong-una-tak-wyglada-najbardziej-strzezona-granica-swiata/m11h7me)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-01T05:00:00+00:00

Korea Północna uznawana jest za najbardziej zamknięty kraj, a strefa zdemilitaryzowana pomiędzy nią i Koreą Południową za jedno z najbardziej niebezpiecznych miejsc na świecie. To kraina abstrakcji — z jednej strony zasieki, miny oraz strach, z drugiej zardzewiały drut kolczasty, wino od uciekinierów na sprzedaż i kwitnący biznes. Pojechałam na koreańską granicę, przeszłam na teren reżimu i na własne oczy zobaczyłam oszustwo Kima, o którym usłyszałam: — Mają tam ludzi, których zadaniem jest udawanie mieszkańców. Z głośników puszczają dźwięk szczekających psów i dzieci bawiących się na placu zabaw.

