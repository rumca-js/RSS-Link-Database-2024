# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Ethiopia signs agreement to use Somaliland’s Red Sea port
 - [https://www.aljazeera.com/news/2024/1/1/ethiopia-signs-agreement-to-use-somalilands-red-sea-port?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/ethiopia-signs-agreement-to-use-somalilands-red-sea-port?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T20:55:31+00:00

The deal will pave the way for the landlocked country to use the port of Berbera.

## How has Israel’s brutal Gaza war mobilised international youth?
 - [https://www.aljazeera.com/program/inside-story/2024/1/1/how-has-israels-brutal-gaza-war-mobilised-international-youth?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/1/1/how-has-israels-brutal-gaza-war-mobilised-international-youth?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T20:33:10+00:00

Young people have been driving protests around the world, calling for an immediate ceasefire in Gaza.

## Israel says it will pull out thousands of troops from Gaza
 - [https://www.aljazeera.com/news/2024/1/1/israel-says-it-will-pull-out-thousands-of-troops-from-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/israel-says-it-will-pull-out-thousands-of-troops-from-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T20:30:56+00:00

Israel has come under pressure from its principal ally, the United States, to move to a more low-intensity war.

## Former Chad opposition leader appointed as PM of transitional government
 - [https://www.aljazeera.com/news/2024/1/1/former-chad-opposition-leader-appointed-as-pm-of-transitional-government?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/former-chad-opposition-leader-appointed-as-pm-of-transitional-government?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T19:20:15+00:00

Succes Masra returned from exile in November after signing a reconciliation agreement with Chad&#039;s military rulers.

## Israel’s Supreme Court strikes down judicial overhaul law
 - [https://www.aljazeera.com/news/2024/1/1/israels-supreme-court-strikes-down-judicial-overhaul-law?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/israels-supreme-court-strikes-down-judicial-overhaul-law?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T19:18:18+00:00

The majority of the court&#039;s judges vote to strike down the law, saying it would severely damage Israel&#039;s democracy.

## Photos: Powerful earthquake hits Japan, residents flee some coastal areas
 - [https://www.aljazeera.com/gallery/2024/1/1/photos-powerful-earthquake-hits-japan-residents-flee-some-coastal-areas?traffic_source=rss](https://www.aljazeera.com/gallery/2024/1/1/photos-powerful-earthquake-hits-japan-residents-flee-some-coastal-areas?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T18:29:19+00:00

The Japan Meteorological Agency issued tsunami warnings for the coastal prefectures of Ishikawa, Niigata and Toyama.

## Iran deploys warship to Red Sea amid soaring tensions
 - [https://www.aljazeera.com/news/2024/1/1/iran-deploys-warship-to-red-sea-following-us-navy-attack-on-houthis?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/iran-deploys-warship-to-red-sea-following-us-navy-attack-on-houthis?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T17:23:45+00:00

Alborz warship enters Bab al-Mandeb Strait, Iranian media reports a day after Yemen&#039;s Houthis say 10 fighters killed.

## Palestinian men are not ‘terrorists in the making’
 - [https://www.aljazeera.com/opinions/2024/1/1/palestinian-men-are-not-terrorists-in-the?traffic_source=rss](https://www.aljazeera.com/opinions/2024/1/1/palestinian-men-are-not-terrorists-in-the?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T16:15:13+00:00

The world cannot continue to ignore the humanity and suffering of Palestinian men in Gaza and beyond.

## Putin vows to ‘intensify’ strikes on Ukraine after deadly Belgorod attack
 - [https://www.aljazeera.com/news/2024/1/1/putin-vows-to-intensify-strikes-on-ukraine-after-deadly-belgorod-attack?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/putin-vows-to-intensify-strikes-on-ukraine-after-deadly-belgorod-attack?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T16:10:33+00:00

At least five people are killed in New Year’s Day attacks on Odesa, southern Ukraine and Russian-occupied Donetsk.

## Supporters of DRC president Tshisekedi celebrate re-election
 - [https://www.aljazeera.com/program/newsfeed/2024/1/1/supporters-of-drc-president-tshisekedi-celebrate-re-election?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/1/supporters-of-drc-president-tshisekedi-celebrate-re-election?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T14:18:42+00:00

Supporters of Felix Tshisekedi are celebrating his re-election as president of the Democratic Republic of Congo.

## Israel flattened my home, killed my family. But I lit a candle for Gaza
 - [https://www.aljazeera.com/features/2024/1/1/israel-flattened-my-home-killed-my-family-but-i-lit-a-candle-for-gaza?traffic_source=rss](https://www.aljazeera.com/features/2024/1/1/israel-flattened-my-home-killed-my-family-but-i-lit-a-candle-for-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T13:56:32+00:00

Displaced and humiliated, I held on to the hope that my Gaza City home had survived the bombing. Then the photos came.

## Displaced Palestinian mother in Gaza gives birth to quadruplets
 - [https://www.aljazeera.com/program/newsfeed/2024/1/1/displaced-palestinian-mother-in-gaza-gives-birth-to-quadruplets-3?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/1/displaced-palestinian-mother-in-gaza-gives-birth-to-quadruplets-3?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T13:43:35+00:00

This Palestinian mother has given birth to quadruplets in Gaza after fleeing with her family from the north.

## First scenes as tsunami waves hit Japan after earthquakes
 - [https://www.aljazeera.com/program/newsfeed/2024/1/1/first-scenes-as-japan-hit-by-tsunami-waves-after-strong-earthquakes?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/1/first-scenes-as-japan-hit-by-tsunami-waves-after-strong-earthquakes?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T13:40:43+00:00

More than a dozen strong earthquakes struck central Japan, triggering tsunami waves along Honshu&#039;s western coast.

## I teach in secret, defying the Taliban ban and fighting despair
 - [https://www.aljazeera.com/opinions/2024/1/1/i-teach-in-secret-defying-the-taliban-ban-and-fighting-despair?traffic_source=rss](https://www.aljazeera.com/opinions/2024/1/1/i-teach-in-secret-defying-the-taliban-ban-and-fighting-despair?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T13:32:54+00:00

The biggest challenge of teaching Afghan girls and women is not the security risk or bad internet, but the hopelessness.

## Six killed in ambush in disputed area between Sudan and South Sudan
 - [https://www.aljazeera.com/news/2024/1/1/six-dead-in-disputed-oil-rich-area-between-sudan-and-south-sudan?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/six-dead-in-disputed-oil-rich-area-between-sudan-and-south-sudan?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T13:07:08+00:00

The oil-rich region experiences frequent bouts of violence from rival factions of an ethnic group across both countries.

## Calls for Gaza ceasefire ring out as world enters 2024
 - [https://www.aljazeera.com/program/newsfeed/2024/1/1/calls-for-gaza-ceasefire-ring-out-as-world-enters-2024?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/1/calls-for-gaza-ceasefire-ring-out-as-world-enters-2024?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T13:05:19+00:00

As the world ushered in a new year, hundreds refrained from celebrating to instead call for a ceasefire in Gaza.

## ‘Completely alienated’: British Muslims on Labour, Tory stance on Gaza war
 - [https://www.aljazeera.com/news/2024/1/1/completely-alienated-british-muslims-on-labour-tory-stance-on-gaza-war?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/completely-alienated-british-muslims-on-labour-tory-stance-on-gaza-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T12:29:55+00:00

Surveys have shown a sharp drop in support for both of Britain&#039;s big parties among Muslims ahead of elections.

## Who is Crown Prince Frederik, Denmark’s king-in-waiting?
 - [https://www.aljazeera.com/news/2024/1/1/who-is-crown-prince-frederik-denmarks-king-in-waiting?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/who-is-crown-prince-frederik-denmarks-king-in-waiting?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T12:25:57+00:00

His ascension to the throne comes after Queen Margrethe II announced her surprise abdication on New Year&#039;s Eve.

## Mexico’s weed ‘nuns’ taking the plant back from the narcos
 - [https://www.aljazeera.com/gallery/2024/1/1/photos-mexicos-weed-nuns-taking-the-plant-back-from-the?traffic_source=rss](https://www.aljazeera.com/gallery/2024/1/1/photos-mexicos-weed-nuns-taking-the-plant-back-from-the?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T11:51:23+00:00

In a country ravaged by drug war and embedded in Christianity, image of marijuana-smoking nun is an act of rebellion.

## US sinks Houthi boats in the Red Sea: How did the fight unfold?
 - [https://www.aljazeera.com/news/2024/1/1/us-sinks-houthi-boats-in-the-red-sea-how-did-the-fight-unfold?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/us-sinks-houthi-boats-in-the-red-sea-how-did-the-fight-unfold?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T11:03:52+00:00

Shipping company Maersk halts operations after maritime escalation between the Houthis and US forces.

## Nobel laureate Muhammad Yunus convicted in Bangladesh labour law case
 - [https://www.aljazeera.com/news/2024/1/1/nobel-laureate-muhammad-yunus-convicted-in-bangladesh-labour-law-case?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/nobel-laureate-muhammad-yunus-convicted-in-bangladesh-labour-law-case?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T10:53:32+00:00

Yunus is accused by PM Sheikh Hasina of &#039;sucking blood&#039; from the poor, but supporters say charges politically motivated.

## Analysis: Is the Israeli army as militarily successful as it claims?
 - [https://www.aljazeera.com/news/2024/1/1/analysis-is-the-israeli-army-as-militarily-successful-as-it-claims?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/analysis-is-the-israeli-army-as-militarily-successful-as-it-claims?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T10:34:02+00:00

As we enter 2024, the Israeli army can claim some successes in the war on Gaza — and also has failures to reckon with.

## Israel’s war on Gaza: List of key events, day 87
 - [https://www.aljazeera.com/news/2024/1/1/israels-war-on-gaza-list-of-key-events-day-87?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/israels-war-on-gaza-list-of-key-events-day-87?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T10:18:24+00:00

Israel rejects South Africa&#039;s ICJ claim and the world protests on New Year&#039;s Eve - here are the latest updates.

## Injured Palestinian boy in Gaza no longer recognises his own face
 - [https://www.aljazeera.com/program/newsfeed/2024/1/1/injured-palestinian-boy-in-gaza-no-longer-recognises-his-own-face?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/1/injured-palestinian-boy-in-gaza-no-longer-recognises-his-own-face?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T08:33:14+00:00

This 11-year-old boy, injured in an Israeli strike on Gaza, says the sight of his disfigured face makes him cry.

## Kenyan farmers battle toxic legacy of locust plague three years on
 - [https://www.aljazeera.com/features/2024/1/1/kenyan-farmers-battle-toxic-legacy-of-locust-plague-three-years-on?traffic_source=rss](https://www.aljazeera.com/features/2024/1/1/kenyan-farmers-battle-toxic-legacy-of-locust-plague-three-years-on?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T08:23:06+00:00

Experts say multiple errors were made in a UN-coordinated campaign to tackle the locust invasion in Kenya.

## Russia says ‘indiscriminate Ukrainian attack’ on Belgorod killed dozens
 - [https://www.aljazeera.com/program/newsfeed/2024/1/1/russia-says-indiscriminate-ukrainian-attack-on-belgorod-killed-dozens?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/1/russia-says-indiscriminate-ukrainian-attack-on-belgorod-killed-dozens?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T08:19:16+00:00

Russia has begun retaliating for what it says was an indiscriminate Ukrainian attack on the Russian city of Belgorod.

## Australian cricketer David Warner retires from ODIs ahead of last Test
 - [https://www.aljazeera.com/sports/2024/1/1/australian-cricketer-david-warner-retires-from-tests-and-odis-pakistan-series?traffic_source=rss](https://www.aljazeera.com/sports/2024/1/1/australian-cricketer-david-warner-retires-from-tests-and-odis-pakistan-series?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T07:32:20+00:00

Warner has called time on his ODI career after confirming the Sydney Test against Pakistan would be his last.

## Magnitude 7.4 earthquake strikes Japan, tsunami warning issued
 - [https://www.aljazeera.com/news/2024/1/1/magnitude-7-4-earthquake-strikes-japan-tsunami-warning-issued?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/magnitude-7-4-earthquake-strikes-japan-tsunami-warning-issued?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T07:31:17+00:00

Japan issues tsunami warning for Ishikawa prefecture after earthquake hits the Noto region.

## ‘Turbulence’ hits India-US ties after Sikh separatist murder plot
 - [https://www.aljazeera.com/news/2024/1/1/turbulence-hits-india-us-ties-after-sikh-separatist-murder-plot?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/turbulence-hits-india-us-ties-after-sikh-separatist-murder-plot?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T06:11:01+00:00

Six months after Indian PM Modi addressed the US Congress, Joe Biden has turned down an invite to India&#039;s Republic Day.

## Kim Jong Un tells army to ‘annihilate’ South Korea, US if provoked
 - [https://www.aljazeera.com/news/2024/1/1/kim-jong-un-tells-army-to-annihilate-south-korea-us-if-provoked?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/kim-jong-un-tells-army-to-annihilate-south-korea-us-if-provoked?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T05:56:51+00:00

North Korean leader echoes earlier bellicose rhetoric after promising to launch new satellites and expand arsenal.

## Ukraine, Russia accuse each other of New Year’s Day attacks
 - [https://www.aljazeera.com/news/2024/1/1/ukraine-russia-accuse-each-other-of-new-years-day-attacks?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/ukraine-russia-accuse-each-other-of-new-years-day-attacks?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T04:53:38+00:00

At least five people have been killed in Donetsk and Odesa amid an escalating wave of attacks since Friday.

## Taiwan’s Tsai Ing-wen says island’s future must be decided by its people
 - [https://www.aljazeera.com/news/2024/1/1/taiwans-tsai-ing-wen-says-islands-future-must-be-decided-by-its-people?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/taiwans-tsai-ing-wen-says-islands-future-must-be-decided-by-its-people?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T03:43:34+00:00

Self-ruled Taiwan, which is claimed by Beijing, will go to the polls latest this month to choose a new president.

## Russia-Ukraine war: List of key events, day 677
 - [https://www.aljazeera.com/news/2024/1/1/russia-ukraine-war-list-of-key-events-day-677?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/russia-ukraine-war-list-of-key-events-day-677?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T01:15:15+00:00

As the war enters its 677th day, these are the main developments.

## Best of 2023: Editor’s picks from the Asia Pacific
 - [https://www.aljazeera.com/news/2024/1/1/best-of-2023-editors-picks-from-the-asia-pacific?traffic_source=rss](https://www.aljazeera.com/news/2024/1/1/best-of-2023-editors-picks-from-the-asia-pacific?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-01T00:04:17+00:00

From the continuing crisis in Myanmar to the US&#039;s expanding military ties, these are Al Jazeera&#039;s highlights.

