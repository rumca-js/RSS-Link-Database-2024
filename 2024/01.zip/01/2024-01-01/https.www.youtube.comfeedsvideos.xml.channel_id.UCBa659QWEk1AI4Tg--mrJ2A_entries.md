# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## After ten years, it's time to stop making videos.
 - [https://www.youtube.com/watch?v=7DKv5H5Frt0](https://www.youtube.com/watch?v=7DKv5H5Frt0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2024-01-01T16:00:06+00:00

Find me here: ❓ LATERAL, free weekly podcast: https://lateralcast.com/ https://youtube.com/lateralcast 📰 WEEKLY NEWSLETTER https://www.tomscott.com/newsletter/ 🟥➕ TOM SCOTT PLUS: https://youtube.com/tomscottplus 👥 THE TECHNICAL DIFFICULTIES: https://youtube.com/techdif 🟥 MAIN SITE: https://www.tomscott.com/


CREDITS

Producer: Cambria Bailey-Jones
Director: Guy Larsen
DoP: Jamie MacLeod | https://www.jamiemacleod.co.uk/
Stunt Coordinators: Dilwyn Sanderson-Jones; Scott Heffield 
Drone Team: Lec Park; Andrew Lawrence 
Pilot: Will Banks 
Refueller & Ground Co-Ordinator: Gary Wise 
BTS: Bryn Williams | https://www.brynscamera.com/
Editor / Colourist: Jamie MacLeod
Composer: Ben Squires | https://www.benjaminsquires.co.uk/
Sound Mix: Dan Pugsley | https://www.cassinisound.com/

A Penny4 Production | https://www.penny4.co.uk/

Special thanks to Abi Hensby and the team at GB Helicopters | https://gbhelicopters.com/

"Lifted" by Benjamin Squires is available on streaming platforms: https:/

