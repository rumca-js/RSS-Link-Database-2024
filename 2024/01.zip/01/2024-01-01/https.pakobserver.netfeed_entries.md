# Source:Pakistan Observer, URL:https://pakobserver.net/feed/, language:en-US

## Samsung Galaxy Note 20 PTA Tax in Pakistan Jan 2024 update
 - [https://pakobserver.net/samsung-galaxy-note-20-pta-tax-in-pakistan-jan-2024-update](https://pakobserver.net/samsung-galaxy-note-20-pta-tax-in-pakistan-jan-2024-update)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T17:14:29+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/gg4r-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Korean giant Samsung remains dominant force in mobile phone market, mainly in the Android sector, where it is touted as trendsetter. The company back-to-back delivers top-notch smartphones, and the Samsung Galaxy Note Ultra stands out as an impressive device. The company known for its flagship devices, and Samsung Note 20 is also exceptional, known for [&#8230;]

## Pakistan’s Senate passes resolution to impose strict punishments over anti-army propaganda
 - [https://pakobserver.net/pakistans-senate-passes-resolution-to-impose-strict-punishments-over-anti-army-propaganda](https://pakobserver.net/pakistans-senate-passes-resolution-to-impose-strict-punishments-over-anti-army-propaganda)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T17:06:30+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/hj3-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – Pakistan’s upper house of parliament passed a resolution, allowing strict punishment against people involved in the dissemination of propaganda against the Army and other security forces. A handful of bills sailed in the house in the first session of 2024 and PPP Senator Bahramand Khan Tangi tabled a resolution, calling for 10 years [&#8230;]

## Canada Digital Nomad Visa 2024: Check all details for Work Visa for Freelancers
 - [https://pakobserver.net/canada-digital-nomad-visa-2024-check-all-details-for-work-visa-for-freelancers](https://pakobserver.net/canada-digital-nomad-visa-2024-check-all-details-for-work-visa-for-freelancers)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T16:46:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/What-Can-You-Do-On-A-Canada-Visitor-Visa-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Canada announced rolling out Digital Nomad Visa 2024, in response to the changing landscape of the job market, as North American country is luring freelancers and digital nomads from across the globe. The new work visa allows freelancers to have temporary residence in Canada besides working remotely, the move aimed to end the requirement for [&#8230;]

## Honda Pridor price in Pakistan January 2024 update
 - [https://pakobserver.net/honda-pridor-price-in-pakistan-january-2024-update](https://pakobserver.net/honda-pridor-price-in-pakistan-january-2024-update)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T15:53:19+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/tt3-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Japanese auto giant Atlas Honda rolled out its Pridor years a decade back, and the 100cc bike still continues to rule the streets despite being a niche product. Honda Pridor replaced the previous 100cc bike, and it comes with several features including EURO-II Standard, improved carburetor, stylish muffler with chrome guard, stylish bright head light. [&#8230;]

## Zong increases internet package prices again; Check new rates here
 - [https://pakobserver.net/zong-increases-internet-package-prices-again-check-new-rates-here](https://pakobserver.net/zong-increases-internet-package-prices-again-check-new-rates-here)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T15:11:04+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/yy4-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Inflation in Pakistan accelerated for a second straight month as the government jacked up energy costs and a weak currency stoked price gains. Amid the situation, telecom company Zong increased tariffs influenced by cost hikes. Amid back-to-back hikes, Zong announced an increase in the price of its packages. Zong Internet Packages in Pakistan Packages Old [&#8230;]

## Weather update for Lahore, Pakistan; fog forces closure of Motorways
 - [https://pakobserver.net/weather-update-for-lahore-pakistan-fog-forces-closure-of-motorways](https://pakobserver.net/weather-update-for-lahore-pakistan-fog-forces-closure-of-motorways)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T14:40:58+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/ffog-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Blanketed by fog, parts of Pakistan including Lahore remained in the grip of cold wave on Monday with experts predicting the prevailing harsh weather conditions to persist during the next two days. Leh remained the coldest place in the country where mercury dropped 10 degrees Celsius below freezing. Minimum temperature in Lahore was [&#8230;]

## Haier’s Ehsaas Banaye Zindagi Asaan: A Journey of Comfort and Joy in Old Age Homes
 - [https://pakobserver.net/haiers-ehsaas-banaye-zindagi-asaan-a-journey-of-comfort-and-joy-in-old-age-homes](https://pakobserver.net/haiers-ehsaas-banaye-zindagi-asaan-a-journey-of-comfort-and-joy-in-old-age-homes)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T14:35:53+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/r3-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Haier&#8217;s latest endeavor, &#8220;Ehsaas Banaye Zindagi Asaan,&#8221; is a heartfelt campaign dedicated to infusing warmth and companionship into the lives of the elderly residing in old age homes. Recognizing that many seniors spend their golden years in loneliness, distanced from family, Haier seeks to bridge this gap not just through products, but also by sharing [&#8230;]

## Jamshed Dasti burst into tears after alleging his wife was stripped, harassed during agencies’ raid
 - [https://pakobserver.net/jamshed-dasti-burst-into-tears-after-alleging-his-wife-was-stripped-harassed-during-agencies-raid](https://pakobserver.net/jamshed-dasti-burst-into-tears-after-alleging-his-wife-was-stripped-harassed-during-agencies-raid)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T14:13:39+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/gg3-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Former lawmaker and PTI leader Jamshed Dasti breaks down into tears as he accused the CTD and intelligence agencies of raiding his house and harassing his wife and other family members. The outspoken politician shared a video from an unknown location, saying his house was raided by CTD and intelligence agencies where his wife was [&#8230;]

## Australian PM hosts reception for Pakistan cricket team
 - [https://pakobserver.net/australian-pm-hosts-reception-for-pakistan-cricket-team](https://pakobserver.net/australian-pm-hosts-reception-for-pakistan-cricket-team)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T13:46:26+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/PM-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />SYDNEY &#8211; Prime Minister of Australia Anthony Albanese hosted a reception in honour of the Pakistan and Australia teams and their respective management at Kirribilli House, Sydney on Monday. Chairman PCB Management Committee Zaka Ashraf also attended the event. High Commissioner of Pakistan in Australia, Zahid Hafeez Chaudhri, and officials from Cricket Australia were also [&#8230;]

## Weather update for Islamabad, Pakistan; fog continues to persist in plains
 - [https://pakobserver.net/weather-update-for-islamabad-pakistan-fog-continues-to-persist-in-plains](https://pakobserver.net/weather-update-for-islamabad-pakistan-fog-continues-to-persist-in-plains)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T13:33:25+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/smogggg-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – The Pakistan Meteorological Department (PMD) has forecast mainly cold and dry weather across Pakistan during the next two days. As per the synoptic situation, continental air prevails over most parts of Pakistan. Under these conditions, mainly cold and dry weather is expected in Islamabad, Rawalpindi and most parts of the country on Monday [&#8230;]

## Pakistan, India swap nuclear installations, inmates lists despite political tensions
 - [https://pakobserver.net/pakistan-india-swap-nuclear-installations-inmates-lists-despite-political-tensions](https://pakobserver.net/pakistan-india-swap-nuclear-installations-inmates-lists-despite-political-tensions)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T13:32:17+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/india-urged-to-release-pakistani-fishermen-1682946506-4423-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; Arch rivals Pakistan and India shared a list of nuclear installations and facilities that cannot be targeted amid an escalation of hostilities following a decade-old agreement. The Asian giants exchanged lists of nuclear installations and facilities under the 1988 truce on the Prohibition of Attacks against Nuclear Installations and Facilities. Both sides used [&#8230;]

## Karachi, Sindh weather update; fog persists in upper, interior districts
 - [https://pakobserver.net/karachi-sindh-weather-update-fog-persists-in-upper-interior-districts](https://pakobserver.net/karachi-sindh-weather-update-fog-persists-in-upper-interior-districts)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T12:55:41+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/fg-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The Pakistan Meteorological Department (PMD) has predicted mainly cold and dry weather for Karachi, Hyderabad and most parts of Sindh during the next two days. As per the synoptic situation, continental air prevails over most parts of Pakistan. Under these conditions, mainly cold and dry weather is expected across Sindh including Karachi and [&#8230;]

## Punjab shares new update for Learner Driving License Fee
 - [https://pakobserver.net/punjab-shares-new-update-for-learner-driving-license-fee](https://pakobserver.net/punjab-shares-new-update-for-learner-driving-license-fee)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T12:18:55+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Driving-Licence-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Over 1 million people in Punjab traffic police centres across Punjab to get learner driving licenses online as authorities set a January 1 deadline for the massive hike in fees. As the government’s decision about the hike in fees triggered huge influx of applicants and major driving license were packed to their capacity, Punjab Chief [&#8230;]

## Pakistan Railways generates record Rs41b revenue
 - [https://pakobserver.net/pakistan-railways-generates-record-rs41b-revenue](https://pakobserver.net/pakistan-railways-generates-record-rs41b-revenue)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T12:18:42+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Pakistan-Railways-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – The Pakistan Railways has generated record revenue of Rs41 billion during July-December 2023 as compared with Rs28b during the same period of last fiscal year. The revenue generation is Rs13b more than the first half of last financial year. The PR has generated Rs24b from passenger trains, Rs11.5b from freight trains and Rs5.5b [&#8230;]

## Petrol Price in Pakistan – January 2024
 - [https://pakobserver.net/petrol-price-in-pakistan-january-2024](https://pakobserver.net/petrol-price-in-pakistan-january-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T11:49:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/ggg44f-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Pakistan’s interim government on Sunday decided against lowering the prices of petrol and high-speed diesel for the first half of January 2024. As the country revised fuel prices every fortnight, people were expecting further reduction in petrol prices for the next two weeks but the country’s Oil and Gas Regulatory Authority (OGRA) recommended government to [&#8230;]

## Supreme Court’s larger bench to hear lifetime disqualification case tomorrow
 - [https://pakobserver.net/supreme-courts-larger-bench-to-hear-lifetime-disqualification-case-tomorrow](https://pakobserver.net/supreme-courts-larger-bench-to-hear-lifetime-disqualification-case-tomorrow)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T11:19:46+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/SC-b6-1-1024x344-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – Supreme Court of Pakistan on Monday formed larger bench to hear life-long disqualification case under Article 62(1) (f) tomorrow at 11:30 am. On the first day of 2024, the apex court formed 7-member bench comprising Chief Justice Qazi Faez Isa, Justice Mansoor Ali Shah, Justice Yahya Afridi, Justice Aminuddin, Justice Jamal Mandokhail, Justice [&#8230;]

## Pakistan Railways revises timings of Shalimar Express
 - [https://pakobserver.net/pakistan-railways-revises-timings-of-shalimar-express](https://pakobserver.net/pakistan-railways-revises-timings-of-shalimar-express)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T11:14:47+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/trains-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Pakistan Railways has decided to revise timings of 27up Karachi-Lahore Shalimar Express. The train plying on main Multan- Faisalabad route will depart from Karachi Cantt at 6:30 am. Prior to that, Shalimar Express’s scheduled departure from Karachi Cantt was 7:30 am. The new timings will be effective from January 8, 2024.

## Zaka Ashraf meets Glenn McGrath
 - [https://pakobserver.net/zaka-ashraf-meets-glenn-mcgrath](https://pakobserver.net/zaka-ashraf-meets-glenn-mcgrath)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T10:59:29+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Glenn-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />SYDNEY – Chairman Pakistan Cricket Board (PCB) Management Committee Zaka Ashraf met legendary Australian cricketer Glenn McGrath during the Prime Minister’s reception at PM House. As per the PCB, former fast bowler and Zaka Ashraf discussed matters of mutual interests during the brief interaction.

## Election 2024: Nawaz Sharif’s nomination papers for NA-130 challenged
 - [https://pakobserver.net/election-2024-nawaz-sharifs-nomination-papers-for-na-130-challenged](https://pakobserver.net/election-2024-nawaz-sharifs-nomination-papers-for-na-130-challenged)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T09:49:37+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Nawaz-Sharifs-nomination-papers-challenged-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211;  As the general election draws near, a nationwide process of filing appeals against the decisions of Returning Officers regarding candidates&#8217; nomination papers is gaining momentum. In a significant development, Pakistan Muslim League-Nawaz (PML-N) Supremo Nawaz Sharif is facing a challenge to the acceptance of his nomination papers from NA-130 Lahore as an appeal [&#8230;]

## Babar Azam wraps up 2023’s roller coaster, sets sights on triumphs in 2024
 - [https://pakobserver.net/babar-azam-wraps-up-2023s-roller-coaster-sets-sights-on-triumphs-in-2024](https://pakobserver.net/babar-azam-wraps-up-2023s-roller-coaster-sets-sights-on-triumphs-in-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T09:18:04+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Babar-Azam-on-new-year-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211;  Former Pakistan Captain Babar Azam, one of the leading batsmen in the International Cricket Council (ICC) rankings, took to social media to share his reflections on the year gone by and his aspirations for the upcoming year. In a tweet, Babar Azam expressed, &#8220;A roller coaster year comes to an end with new [&#8230;]

## Faizabad Sit-in Case: Commission summons former PM Shehbaz Sharif
 - [https://pakobserver.net/faizabad-sit-in-case-commission-summons-former-pm-shehbaz-sharif](https://pakobserver.net/faizabad-sit-in-case-commission-summons-former-pm-shehbaz-sharif)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T09:07:25+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Shehbaz-Sharif-Jan-1-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; The Faizabad Protest Commission on Monday summoned Pakistan Muslim League-Nawaz (PML-N) President and former Prime Minister Shehbaz Sharif. The Commission summoned him as former Punjab chief minister to record his statement on January 3, 2024. The Commission took a proactive step by preparing a comprehensive questionnaire for Shehbaz Sharif in the Faizabad protest—an [&#8230;]

## FBR sets another record of collecting Rs1.021tr tax just in Dec 2023
 - [https://pakobserver.net/fbr-sets-another-record-of-collecting-rs1-021tr-tax-just-in-dec-2023](https://pakobserver.net/fbr-sets-another-record-of-collecting-rs1-021tr-tax-just-in-dec-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T08:40:17+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Tax-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211;  The Federal Board of Revenue (FBR) has made an historic achievement as it achieved a groundbreaking milestone in tax collection. In a historic move, the FBR collected an unprecedented Rs1.021 trillion in December 2023, showcasing its financial prowess and resilience in the face of economic challenges. The achievement not only surpassed the set [&#8230;]

## PTI intends to approach SC to challenge rejection of nomination papers
 - [https://pakobserver.net/pti-intends-to-approach-sc-to-challenge-rejection-of-nomination-papers](https://pakobserver.net/pti-intends-to-approach-sc-to-challenge-rejection-of-nomination-papers)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T08:21:12+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Gohar-Khan-Dec2-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; Pakistan Tehreek-e-Insaf (PTI) on Monday announced its intention to appeal to the Supreme Court of Pakistan regarding the rejection of its candidates&#8217; nomination papers. S Dr. Babar Awan, a senior leader of PTI, emphasized that the constitution does not prevent anyone from participating in elections, and allegations of papers being snatched from people [&#8230;]

## Showbiz stars extend New Year wishes with calls for global peace
 - [https://pakobserver.net/showbiz-stars-extend-new-year-wishes-with-calls-for-global-peace](https://pakobserver.net/showbiz-stars-extend-new-year-wishes-with-calls-for-global-peace)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T07:27:26+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/celebrities-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; As the new year dawned, the celebrities from the Pakistani entertainment extended their heartfelt wishes for 2023. The celebrities took to the social media to extend good wishes on the eve of new year. Actress Shagufta Ejaz shared a family photograph on Instagram, using the occasion to not only convey New Year greetings [&#8230;]

## Extended deadline for election appeals as electoral process gains momentum
 - [https://pakobserver.net/extended-deadline-for-election-appeals-as-electoral-process-gains-momentum](https://pakobserver.net/extended-deadline-for-election-appeals-as-electoral-process-gains-momentum)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T06:40:57+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/ECP-Dec-23-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; The deadline for filing appeals against the acceptance or rejection of nomination papers for the upcoming general elections has been extended until Wednesday. The Election Commission has announced that decisions on these appeals will be finalized by the 10th of this month. A preliminary list featuring the names of candidates is set to [&#8230;]

## Pakistan Olympic Association accepts Arif Hasan’s resignation
 - [https://pakobserver.net/pakistan-olympic-association-accepts-arif-hasans-resignation](https://pakobserver.net/pakistan-olympic-association-accepts-arif-hasans-resignation)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T06:30:25+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Arif-Hasan-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211;  Pakistan Olympic Association (POA) Executive Committee has formally accepted the resignation of Arif Hasan, the former President. The decision was made during a pivotal meeting held on Sunday, chaired by Senior Vice President Syed Aqil Shah. Of the 25 committee members present, 23 voted in favor of acknowledging the retirement of retired Lieutenant [&#8230;]

## Warner hints at playing 2025 Champions Trophy in Pakistan despite ODI retirement
 - [https://pakobserver.net/warner-hints-at-playing-2025-champions-trophy-in-pakistan-despite-odi-retirement](https://pakobserver.net/warner-hints-at-playing-2025-champions-trophy-in-pakistan-despite-odi-retirement)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T06:10:45+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Warner-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />SYDNEY- Australian opener David Warner has officially announced One-Day International (ODI) cricket career. However, Warner hinted at the possibility of returning for the 2025 Champions Trophy if the team requires his services despite bidding farewell to ODIs. The Champions Trophy, scheduled to take place in Pakistan, is making a comeback in 2025 after a hiatus [&#8230;]

## Currency exchange rates in Pakistan today – January 1, 2024
 - [https://pakobserver.net/currency-exchange-rates-in-pakistan-today-january-1-2024](https://pakobserver.net/currency-exchange-rates-in-pakistan-today-january-1-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T04:36:35+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/curreny-rate-today-15-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The exchange rate for one US Dollar against Pakistani Rupees was recorded at Rs 281.5 in the local and open market, with a selling rate of Rs 284 on Monday, January 1, 2024. Note: Exchange rates can vary based on the location and the Exchange Company or bank involved in the transaction. Below are [&#8230;]

## Gold rate in Pakistan today – 1 January, 2023
 - [https://pakobserver.net/gold-rate-in-pakistan-today-1-january-2023](https://pakobserver.net/gold-rate-in-pakistan-today-1-january-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-01T04:34:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/gold-rate-in-pakistan-today-24-March-2023-1-1024x576-4-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The gold rate of 24-karat is being traded at PKR 219,200 on Monday, January 1, 2023. Similarly, the gold price for 24-karat was recorded at Rs 187,930 per 10g as per the bullion market. Gold Price in Pakistan’s different cities. City Gold Silver Karachi PKR 219,200 PKR 2,450 Lahore PKR 219,200 PKR 2,450 [&#8230;]

