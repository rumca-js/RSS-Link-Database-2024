# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Israeli Military Censor Bans Reporting on Eight Specific Subjects Related to War With Hamas
 - [https://reclaimthenet.org/israeli-military-censor-bans-reporting-on-eight-specific-subjects-related-to-war-with-hamas](https://reclaimthenet.org/israeli-military-censor-bans-reporting-on-eight-specific-subjects-related-to-war-with-hamas)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2024-01-01T14:10:07+00:00

<a href="https://reclaimthenet.org/israeli-military-censor-bans-reporting-on-eight-specific-subjects-related-to-war-with-hamas" rel="nofollow" title="Israeli Military Censor Bans Reporting on Eight Specific Subjects Related to War With Hamas"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/12/isr-net.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Censored media topics.</p>
<p>The post <a href="https://reclaimthenet.org/israeli-military-censor-bans-reporting-on-eight-specific-subjects-related-to-war-with-hamas">Israeli Military Censor Bans Reporting on Eight Specific Subjects Related to War With Hamas</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

## Meta Censors Jewish and Muslim Co-Existence Podcast
 - [https://reclaimthenet.org/meta-censors-jewish-and-muslim-co-existence-podcast](https://reclaimthenet.org/meta-censors-jewish-and-muslim-co-existence-podcast)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2024-01-01T14:03:08+00:00

<a href="https://reclaimthenet.org/meta-censors-jewish-and-muslim-co-existence-podcast" rel="nofollow" title="Meta Censors Jewish and Muslim Co-Existence Podcast"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/12/peace-talk.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Facebook pulled the podcast episode.</p>
<p>The post <a href="https://reclaimthenet.org/meta-censors-jewish-and-muslim-co-existence-podcast">Meta Censors Jewish and Muslim Co-Existence Podcast</a> appeared first on <a href="https://reclaimthenet.org">Reclaim The Net</a>.</p>

