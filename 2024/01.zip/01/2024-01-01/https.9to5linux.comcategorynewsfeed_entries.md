# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## Scribus 1.6 Open-Source Desktop Publishing App Released as a Major Update
 - [https://9to5linux.com/scribus-1-6-open-source-desktop-publishing-app-released-as-a-major-update](https://9to5linux.com/scribus-1-6-open-source-desktop-publishing-app-released-as-a-major-update)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-01-01T01:12:18+00:00

<p>Scribus 1.6 free, open-source, cross-platform, and powerful desktop publishing software is now available for download.</p>
<p>The post <a href="https://9to5linux.com/scribus-1-6-open-source-desktop-publishing-app-released-as-a-major-update">Scribus 1.6 Open-Source Desktop Publishing App Released as a Major Update</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

