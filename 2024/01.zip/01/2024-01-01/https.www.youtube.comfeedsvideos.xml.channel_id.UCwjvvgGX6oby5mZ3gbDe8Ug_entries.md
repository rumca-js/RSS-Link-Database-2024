# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Beijing: Riches and Officials Gather and now they are shocked/U turn policy can't save the collapse
 - [https://www.youtube.com/watch?v=mKZqjETzpj8](https://www.youtube.com/watch?v=mKZqjETzpj8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2024-01-01T03:40:45+00:00

#Chinainsights#Chinanews
Beijing is a special city where the rich and powerful gather in large numbers. Here, in a seemingly ordinary residential neighborhood in Beijing, someone was renovating a second-hand house that was just purchased. When the family took down the balcony wall, they found 150 million yuan in cash, equivalent to US$21 million. They were in shock and had to call the police. The police didn't dare to touch the cash and called the Public Prosecutor's Office. In the end, the money was seized. 
We begin our episode with this comical story. The rest of the story however is full of chills as it deals with buying and selling real estate in Beijing. 

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will

