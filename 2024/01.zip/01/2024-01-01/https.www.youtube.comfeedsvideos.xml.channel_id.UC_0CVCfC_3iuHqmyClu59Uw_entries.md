# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## MS-01 First Look, An All-New Ultra Fast Mini PC With GPU Support! Hands On
 - [https://www.youtube.com/watch?v=NUlptjU0vFQ](https://www.youtube.com/watch?v=NUlptjU0vFQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2024-01-01T15:06:00+00:00

In this video we go hands on with the all new minis forum MS-01, An ultra Fast Mini PC workstation that you can add a low profile GPU to! With Dual 10 Gigabit Ethernet USB 4, A 14 Core i9 CPU and a Super Small form facto this new mini pc is FAST.

Learn More about The MS-01 Here: https://shareasale.com/r.cfm?b=1620564&amp;u=2839303&amp;m=101288&amp;urllink=store%2Eminisforum%2Ecom%2Fproducts%2Fminisforum%2Dms%2D01&amp;afftrack=

Buy the XFX Low Profile radeon RX 6400 Here: https://amzn.to/3NO7yod
Buy a Low profile Graphics card here: https://howl.me/clkodccz6Su

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

Vip-Urcdkey Black Friday Sale Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows 11 Pro Key($21): https://biitt.ly/RUZiX
Windows10 Home Key($14): https://biitt.ly/2tPi1
Office 2019 pro key($46): https://biitt.ly/o0OQT
Office 2021 pro key($59): https://biitt.ly/iDMHc

Equipment I Us

