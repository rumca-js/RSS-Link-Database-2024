# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## USS Gerald R. Ford aircraft carrier heads home after standing guard near Israel following Oct. 7 attack
 - [https://www.foxnews.com/us/uss-gerald-r-ford-aircraft-carrier-heads-home-standing-guard-israel-attack](https://www.foxnews.com/us/uss-gerald-r-ford-aircraft-carrier-heads-home-standing-guard-israel-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T23:21:23+00:00

U.S. Navy officials said the USS Gerald R. Ford aircraft carrier strike group would be heading home after being deployed to the Middle East following the Oct. 7 attack on Israel.

## Pro-Palestinian caravan snarls New York traffic around JFK, LaGuardia Airport
 - [https://www.foxnews.com/us/pro-palestinian-caravan-snarls-new-york-traffic-jfk-laguardia-airport](https://www.foxnews.com/us/pro-palestinian-caravan-snarls-new-york-traffic-jfk-laguardia-airport)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T23:02:43+00:00

A caravan of pro-Palestinian protesters held up traffic around JFK and LaGuardia airports on New Year&apos;s Day, creating a headache on one of the busiest travel days.

## One person dies after fireworks accident during San Francisco New Year's Eve celebrations
 - [https://www.foxnews.com/us/person-dies-fireworks-accident-during-san-francisco-new-years-eve-celebrations](https://www.foxnews.com/us/person-dies-fireworks-accident-during-san-francisco-new-years-eve-celebrations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T22:43:53+00:00

A person has died after a fireworks mishap during New Year&apos;s Eve celebrations at Treasure Island in San Francisco, according to the San Francisco Fire Department.

## New Jersey twins born on different days, years at hospital during New Year's
 - [https://www.foxnews.com/us/new-jersey-twins-born-different-days-years-hospital-new-years](https://www.foxnews.com/us/new-jersey-twins-born-different-days-years-hospital-new-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T22:35:25+00:00

A set of New Jersey twins were born in 2023 and 2024 over the New Year&apos;s weekend. Ezra and Ezekial were born at Virtua Voorhees Hospital in Voorhees Township, New Jersey.

## Travis Kelce, Taylor Swift share New Year’s kiss after Chiefs secure eighth consecutive division title
 - [https://www.foxnews.com/sports/travis-kelce-taylor-swift-share-new-years-kiss-chiefs-secure-eighth-consecutive-division-title](https://www.foxnews.com/sports/travis-kelce-taylor-swift-share-new-years-kiss-chiefs-secure-eighth-consecutive-division-title)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T22:20:35+00:00

Kansas City Chiefs tight end Travis Kelce celebrated the New Year and the team&apos;s eighth division title with a midnight kiss with Taylor Swift.

## California business apologizes after Black ESPN journalist accuses workers of racial profiling: 'Deeply sorry'
 - [https://www.foxnews.com/media/california-business-apologizes-black-sports-journalist-accuses-racial-profiling-deeply-sorry](https://www.foxnews.com/media/california-business-apologizes-black-sports-journalist-accuses-racial-profiling-deeply-sorry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T22:00:30+00:00

ESPN writer and &quot;The Conversations Project&quot; co-host Marc Spears accused employees at a California business of racially profiling him and his group, prompting the founder to apologize.

## Tennessee police wrangle wayward beaver out of hospital on Christmas Day
 - [https://www.foxnews.com/us/tennessee-police-wrangle-wayward-beaver-hospital-christmas-day](https://www.foxnews.com/us/tennessee-police-wrangle-wayward-beaver-hospital-christmas-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T21:59:44+00:00

The Bartlett Police Department released video of their officers catching a wayward beaver at Saint Francis Hospital on Christmas, eventually releasing the animal into the wild.

## Quarterback DJ Uiagalelei transferring to Florida State, to play for 3rd college team
 - [https://www.foxnews.com/sports/quarterback-dj-uiagalelei-transferring-florida-state-play-third-college-team](https://www.foxnews.com/sports/quarterback-dj-uiagalelei-transferring-florida-state-play-third-college-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T21:55:55+00:00

Former Oregon State quarterback DJ Uiagalelei told ESPN he will transfer to Florida State. It will be the third school that Uiagalelei has played for in his college career.

## IDF confirms troops killed Hamas leader involved in Oct. 7 attack
 - [https://www.foxnews.com/world/idf-confirms-troops-killed-hamas-leader-involved-attack](https://www.foxnews.com/world/idf-confirms-troops-killed-hamas-leader-involved-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T21:02:49+00:00

Israeli Defense Forces claim to have killed Adil Mismah, a Hamas commander who helped lead the Oct. 7 massacre that claimed the lives of over 1,200 people.

## Japan lowers tsunami warning after earthquakes rock region, but government warns of lingering waves
 - [https://www.foxnews.com/world/japan-lowers-tsunami-warning-earthquakes-rock-region-government-warns-lingering-waves](https://www.foxnews.com/world/japan-lowers-tsunami-warning-earthquakes-rock-region-government-warns-lingering-waves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T20:35:33+00:00

Japan is downgrading its tsunami warning after several earthquakes, including one a magnitude of 7.6, rocked the west coast of Japan&apos;s main island, Honshu.

## Packers' Aaron Jones struck in face during postgame scuffle with Vikings
 - [https://www.foxnews.com/sports/packers-aaron-jones-struck-face-postgame-scuffle-vikings](https://www.foxnews.com/sports/packers-aaron-jones-struck-face-postgame-scuffle-vikings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T20:18:07+00:00

Aaron Jones was trying to &apos;deescalate&apos; an altercation between two players

## Two minute tech tricks: Start the year with a clean inbox
 - [https://www.foxnews.com/tech/tech-trick-start-year-with-clean-inbox](https://www.foxnews.com/tech/tech-trick-start-year-with-clean-inbox)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T20:14:20+00:00

Start the New Year with a clean slate. Learn how to clear your email inbox from your phone or computer using simple tips from a tech expert.

## Kathy Griffin leans on pal Jane Fonda after filing for divorce: ‘My heart is broken’
 - [https://www.foxnews.com/entertainment/kathy-griffin-leans-pal-jane-fonda-filing-divorce-heart-broken](https://www.foxnews.com/entertainment/kathy-griffin-leans-pal-jane-fonda-filing-divorce-heart-broken)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T19:57:07+00:00

Kathy Griffin filed for divorce from marketing executive Randy Bick in Los Angeles Superior Court on Thursday citing &quot;irreconcilable differences.&quot;

## 16-year-old boy killed in stabbing incident during fireworks display in London
 - [https://www.foxnews.com/world/16-year-old-boy-killed-stabbing-incident-fireworks-display-london](https://www.foxnews.com/world/16-year-old-boy-killed-stabbing-incident-fireworks-display-london)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T19:53:18+00:00

A 16-year-old boy was fatally stabbed on Primrose Hill in central London during New Year&apos;s Eve fireworks celebrations. Despite efforts to revive him, he did not survive.

## Pakistan human rights commission raises concerns over 'pre-poll rigging' ahead of upcoming elections
 - [https://www.foxnews.com/world/pakistan-human-rights-commission-raises-concerns-pre-poll-rigging-ahead-upcoming-elections](https://www.foxnews.com/world/pakistan-human-rights-commission-raises-concerns-pre-poll-rigging-ahead-upcoming-elections)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T19:45:09+00:00

The Human Rights Commission of Pakistan is voicing their concerns about the fairness of upcoming parliamentary elections in the country and whether they will be credible.

## UK saw record decline of migrant crossings of English Channel in 2023
 - [https://www.foxnews.com/world/uk-saw-record-decline-migrant-crossings-english-channel-2023](https://www.foxnews.com/world/uk-saw-record-decline-migrant-crossings-english-channel-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T19:44:46+00:00

In 2023, the number of migrants crossing the English Channel decreased by over a third compared to the previous year, marking the first decline since record-keeping began.

## Supreme Court chief justice report urges caution on use of AI ahead of contentious election year
 - [https://www.foxnews.com/politics/supreme-court-chief-justice-report-urges-caution-use-ai-contentious-election-year](https://www.foxnews.com/politics/supreme-court-chief-justice-report-urges-caution-use-ai-contentious-election-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T19:43:48+00:00

In a year-end report, Supreme Court Chief Justice John Roberts spoke on his &quot;go-slow&quot; approach to dealing with matters concerning artificial intelligence.

## Chicago mayor ripped for objecting to illegal immigrants flown into city: ‘Take it up with your pal Joe'
 - [https://www.foxnews.com/media/chicago-mayor-ripped-objecting-illegal-immigrants-flown-city-take-it-up-your-pal-joe](https://www.foxnews.com/media/chicago-mayor-ripped-objecting-illegal-immigrants-flown-city-take-it-up-your-pal-joe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T19:00:37+00:00

Conservatives ripped Chicago Mayor Brandon Johnson after he complained on X about Gov. Greg Abbott, R-Texas, flying migrants from Texas to Chicago without warning the city.

## Germany detains fifth suspect in alleged plot to attack Cologne Cathedral over the holidays
 - [https://www.foxnews.com/world/germany-detains-fifth-suspect-alleged-plot-attack-cologne-cathedral-holidays](https://www.foxnews.com/world/germany-detains-fifth-suspect-alleged-plot-attack-cologne-cathedral-holidays)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T18:47:49+00:00

German authorities have detained a 41-year-old German-Turkish man in connection to an alleged threat to attack the Cologne Cathedral over the holidays.

## 2 arrested after Ugandan Olympic runner fatally stabbed in Kenya
 - [https://www.foxnews.com/world/2-arrested-ugandan-olympic-runner-fatally-stabbed-kenya](https://www.foxnews.com/world/2-arrested-ugandan-olympic-runner-fatally-stabbed-kenya)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T18:47:09+00:00

Two men have been arrested in connection with the murder of Ugandan Olympic runner Benjamin Kiplagat. He was found fatally stabbed in a car in Kenya on New Year&apos;s Eve.

## Fulton County Jail inmate faces arson charges after allegedly setting cell ablaze
 - [https://www.foxnews.com/us/fulton-county-jail-inmate-faces-arson-charges-allegedly-setting-cell-ablaze](https://www.foxnews.com/us/fulton-county-jail-inmate-faces-arson-charges-allegedly-setting-cell-ablaze)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T18:27:45+00:00

A Fulton County Jail inmate who is accused of starting a fire in his cell is facing arson charges. The fire caused over a dozen prisoners to be relocated within the jail.

## Israeli Supreme Court hands Netanyahu a loss on judicial overhaul as Hamas war rages
 - [https://www.foxnews.com/world/israeli-supreme-court-hands-netanyahu-loss-judicial-overhaul-hamas-war-rages](https://www.foxnews.com/world/israeli-supreme-court-hands-netanyahu-loss-judicial-overhaul-hamas-war-rages)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T18:23:26+00:00

Israeli Prime Minister Benjamin Netanyahu suffered a blow from the country&apos;s supreme court on Monday after it struck down a portion of his judicial reforms.

## Shirtless Kirk Cousins, son lead ‘Skol’ chant before Vikings' loss to Packers
 - [https://www.foxnews.com/sports/shirtless-kirk-cousins-son-lead-skol-chant-before-vikings-loss-packers](https://www.foxnews.com/sports/shirtless-kirk-cousins-son-lead-skol-chant-before-vikings-loss-packers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T18:18:20+00:00

Minnesota Vikings quarterback Kirk Cousins and his son led the crown in the &quot;Skol&quot; chant before losing to the Green Bay Packers on Sunday night.

## Migrant encounters at southern border hit record 302K in December, sources say
 - [https://www.foxnews.com/politics/migrant-encounters-southern-border-hit-record-302k-december-sources-say](https://www.foxnews.com/politics/migrant-encounters-southern-border-hit-record-302k-december-sources-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T18:15:25+00:00

Illegal migrant encounters broke all previous records in December 2023, with Customs and Border Patrol authorities reporting over 302,000 incidents in the last month of the year.

## New Jersey man faces charges after allegedly attempting to aid militant Islamist group
 - [https://www.foxnews.com/us/new-jersey-man-faces-charges-allegedly-attempting-aid-militant-islamist-group](https://www.foxnews.com/us/new-jersey-man-faces-charges-allegedly-attempting-aid-militant-islamist-group)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T17:45:25+00:00

A New Jersey man has been arrested in Kenya and charged by the U.S. Justice Department for attempting to aid the militant Islamist group al Shabaab, officials say.

## New York City parkway crash kills 5 in Queens, police say
 - [https://www.foxnews.com/us/new-york-city-parkway-crash-kills-5-queens-police-say](https://www.foxnews.com/us/new-york-city-parkway-crash-kills-5-queens-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T17:42:26+00:00

Five people were killed in a car crash on the Cross Island Parkway in Queens, New York City on Monday. A Mazda collided with another vehicle near the Whitestone Bridge.

## Colorado mother accused of murdering 2 children appears in UK court
 - [https://www.foxnews.com/us/colorado-mother-accused-murdering-2-children-appears-uk-court](https://www.foxnews.com/us/colorado-mother-accused-murdering-2-children-appears-uk-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T17:36:06+00:00

A Colorado woman accused of killing two of her young children and injuring a third appeared in a London court for an initial hearing facing extradition to the U.S.

## NJ mayor accuses migrant buses of bypassing NYC order through 'loophole'
 - [https://www.foxnews.com/us/nj-mayor-accuses-migrant-buses-bypassing-nyc-order-loophole](https://www.foxnews.com/us/nj-mayor-accuses-migrant-buses-bypassing-nyc-order-loophole)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T17:26:44+00:00

Buses carrying migrants bound for New York City have allegedly been avoiding an executive order by New York Mayor Eric Adams, which regulates the drop-off of migrants.

## Harvard students pen editorial calling on President Gay to resign, stating she has 'failed'
 - [https://www.foxnews.com/media/harvard-students-pen-editorial-calling-president-gay-resign-stating-she-failed](https://www.foxnews.com/media/harvard-students-pen-editorial-calling-president-gay-resign-stating-she-failed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T17:19:22+00:00

Students call on disgraced President Claudine Gay to resign from her position following week of allegations regarding antisemitism and plagiarism.

## Steelers win over Seahawks extends Mike Tomlin's remarkable streak
 - [https://www.foxnews.com/sports/steelers-win-over-seahawks-extends-mike-tomlins-remarkable-streak](https://www.foxnews.com/sports/steelers-win-over-seahawks-extends-mike-tomlins-remarkable-streak)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T17:09:51+00:00

The Pittsburgh Steelers moved to 9-7 with a win over the Seattle Seahawks on Sunday, assuring that Mike Tomlin&apos;s streak of non-losing seasons continued.

## Bill Clinton to be identified in previously redacted Jefferey Epstein documents: Report
 - [https://www.foxnews.com/media/bill-clinton-identified-previously-redacted-jefferey-epstein-documents-report](https://www.foxnews.com/media/bill-clinton-identified-previously-redacted-jefferey-epstein-documents-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T17:01:31+00:00

Former President Bill Clinton is going to be identified in previously redacted documents related to convicted sex offender Jefferey Epstein, according to ABC News.

## ‘80s supermodel Carol Alt, 63, reveals her weight loss secrets for the New Year
 - [https://www.foxnews.com/entertainment/80s-supermodel-carol-alt-63-reveals-weight-loss-secrets-new-year](https://www.foxnews.com/entertainment/80s-supermodel-carol-alt-63-reveals-weight-loss-secrets-new-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T16:59:46+00:00

Carol Alt has appeared in more than 700 magazines throughout her decades-long career. She scored the SI Swimsuit cover in 1982 after being photographed by John G. Zimmerman.

## Kim Jong Un, Xi Jinping declare 2024 'year of DPRK-China friendship'
 - [https://www.foxnews.com/world/kim-jong-un-xi-jinping-declare-2024-year-dprk-china-friendship](https://www.foxnews.com/world/kim-jong-un-xi-jinping-declare-2024-year-dprk-china-friendship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T16:43:59+00:00

Chinese Communist Party leader Xi Jinping and North Korean dictator Kim Jong Un are celebrating 2024 as the &quot;year of DPRK-China friendship,&quot; according to official statements.

## Bengals’ Ja’Marr Chase takes credit after second quarter scuffle with Chiefs: ‘I started it off’
 - [https://www.foxnews.com/sports/bengals-jamarr-chase-takes-credit-second-quarter-scuffle-chiefs-i-started-it-off](https://www.foxnews.com/sports/bengals-jamarr-chase-takes-credit-second-quarter-scuffle-chiefs-i-started-it-off)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T16:08:47+00:00

Cincinnati Bengals wide receiver Ja’Marr Chase took credit for starting the trash-talking with the Kansas City Chiefs during Sunday&apos;s game between the two rivals.

## Berlin sees decrease in New Year's violence with boosted police presence
 - [https://www.foxnews.com/world/berlin-sees-decrease-new-years-violence-boosted-police-presence](https://www.foxnews.com/world/berlin-sees-decrease-new-years-violence-boosted-police-presence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T15:54:24+00:00

Berlin&apos;s New Year&apos;s Eve celebrations were more peaceful than last year despite the temporary detention of 390 people and injuries to 54 police officers, authorities say.

## 1 dead, 21 injured in Austria bar fire on New Year's Day
 - [https://www.foxnews.com/world/1-dead-21-injured-austria-bar-fire-new-years-day](https://www.foxnews.com/world/1-dead-21-injured-austria-bar-fire-new-years-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T15:45:50+00:00

A fire at a bar in the southeastern Austrian city of Graz left one person dead and 21 others injured in the early hours of New Year&apos;s Day, according to police.

## As Americans ring in 2024, they should learn from ‘successes and mistakes’ of 1924, Cal Thomas says
 - [https://www.foxnews.com/media/americans-ring-2024-should-learn-successes-mistakes-1924-cal-thomas-says](https://www.foxnews.com/media/americans-ring-2024-should-learn-successes-mistakes-1924-cal-thomas-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T15:44:23+00:00

As we enter 2024, Americans should learn from their mistakes, according to famed columnist Cal Thomas, who rang in 2024 with a piece examining the events of 100 years ago.

## Jeremy Renner reflects on near-fatal snowplow accident one year later: ‘I have so many things to fight for'
 - [https://www.foxnews.com/entertainment/jeremy-renner-reflects-near-fatal-snowplow-accident-one-year-later](https://www.foxnews.com/entertainment/jeremy-renner-reflects-near-fatal-snowplow-accident-one-year-later)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T15:27:21+00:00

The &quot;Mayor of Kingstown&quot; star hinted a return to acting a year after his near-fatal accident. He also released a &quot;musical diary&quot; titled &quot;Wait&quot; on New Year&apos;s Day.

## Lesser-known endangered species in the US threatened by funding disparities
 - [https://www.foxnews.com/us/lesser-known-endangered-species-us-threatened-funding-disparities](https://www.foxnews.com/us/lesser-known-endangered-species-us-threatened-funding-disparities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T15:26:39+00:00

The Endangered Species Act has designated over 1,700 species in the U.S. as threatened or endangered, but there are discrepancies in the distribution of funds for their recovery.

## World needs America to stand strong, but not stand alone
 - [https://www.foxnews.com/opinion/world-needs-america-stand-strong-stand-alone](https://www.foxnews.com/opinion/world-needs-america-stand-strong-stand-alone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T15:00:53+00:00

The two mighty oceans no longer protect America from the world. The U.S. needs to be strong and work with our allies to stand up to rising threats, including China.

## 10 apps that will help make your New Year’s resolutions a reality
 - [https://www.foxnews.com/tech/10-apps-that-will-help-make-your-new-years-resolutions-a-reality](https://www.foxnews.com/tech/10-apps-that-will-help-make-your-new-years-resolutions-a-reality)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T15:00:37+00:00

Kurt “CyberGuy&quot; Knutsson has put together a list of 10 apps that will help you make your 2024 New Year’s resolutions a reality.

## US Coast Guard extinguishes lithium-ion battery fire on Alaska cargo ship after several days of burning
 - [https://www.foxnews.com/us/us-coast-guard-extinguishes-lithium-ion-battery-fire-alaska-cargo-ship-several-days-burning](https://www.foxnews.com/us/us-coast-guard-extinguishes-lithium-ion-battery-fire-alaska-cargo-ship-several-days-burning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:57:29+00:00

The U.S. Coast Guard has extinguished a fire involving lithium-ion batteries on the cargo ship Genius Star XI after it burned for several days, officials say.

## Green Day reworks hit song lyrics to trash 'MAGA agenda' during 'Dick Clark's New Year’s Rockin’ Eve’ on ABC
 - [https://www.foxnews.com/media/green-day-reworks-hit-song-lyrics-trash-maga-agenda-during-dick-clarks-new-years-rockin-eve-abc](https://www.foxnews.com/media/green-day-reworks-hit-song-lyrics-trash-maga-agenda-during-dick-clarks-new-years-rockin-eve-abc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:49:26+00:00

The band Green Day took a shot at former President Trump with reworked lyrics of their hit song &quot;American Idiot&quot; during a New Year&apos;s Eve performance on ABC.

## Nuggets’ Aaron Gordon explains dog bite that required 21 stitches: ‘Probably had a little bit too much eggnog’
 - [https://www.foxnews.com/sports/nuggets-aaron-gordon-explains-dog-bite-required-21-stitches-probably-had-little-bit-too-much-eggnog](https://www.foxnews.com/sports/nuggets-aaron-gordon-explains-dog-bite-required-21-stitches-probably-had-little-bit-too-much-eggnog)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:44:09+00:00

Denver Nuggets forward Aaron Gordon explained the incident that required him to receive 21 stitches on Christmas Day after his dog bit him.

## US rings in 2024 with sweeping legal changes, including gun regulations and minimum wage increases
 - [https://www.foxnews.com/us/us-rings-2024-sweeping-legal-changes-gun-regulations-minimum-wage-increases](https://www.foxnews.com/us/us-rings-2024-sweeping-legal-changes-gun-regulations-minimum-wage-increases)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:35:23+00:00

In the U.S., a range of new laws take effect on Jan. 1, impacting various aspects of daily life. In Illinois, drivers can display items like fuzzy dice without being pulled over.

## Taylor Swift breaks Elvis Presley’s record for most weeks at No. 1 on Billboard 200 chart
 - [https://www.foxnews.com/entertainment/taylor-swift-breaks-elvis-presleys-record-most-weeks-no-1-billboard-200-chart](https://www.foxnews.com/entertainment/taylor-swift-breaks-elvis-presleys-record-most-weeks-no-1-billboard-200-chart)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:31:54+00:00

The &quot;Cruel Summer&quot; singer still needs to beat the Fab Four. The Beatles have spent 132 weeks in the No. 1 spot across their 19 albums between 1964 and 2001.

## Disney 'Coco' voice actress Ana Ofelia Murguía dead at 90, Mexico says
 - [https://www.foxnews.com/entertainment/disney-coco-voice-actress-ana-ofelia-murguia-dead-90-mexico-says](https://www.foxnews.com/entertainment/disney-coco-voice-actress-ana-ofelia-murguia-dead-90-mexico-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:27:20+00:00

Mexican actress Ana Ofelia Murguía, most famous outside her home country for her central role in the Disney Pixar film &quot;Coco,&quot; has passed away at the age of 90.

## Israeli forces reveal footage of K9 unit clearing houses in Gaza, uncovering Hamas weapons
 - [https://www.foxnews.com/world/israeli-forces-reveal-footage-k9-unit-clearing-houses-gaza-uncovering-hamas-weapons](https://www.foxnews.com/world/israeli-forces-reveal-footage-k9-unit-clearing-houses-gaza-uncovering-hamas-weapons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:22:28+00:00

Israel detailed its K9 operations in Gaza with newly-released footage on Monday, citing two instances where Israeli dogs &quot;neutralized&quot; terrorists.

## California law students provide pro bono help to struggling Maui residents after wildfires
 - [https://www.foxnews.com/lifestyle/california-law-students-provide-pro-bono-help-struggling-maui-residents-wildfires](https://www.foxnews.com/lifestyle/california-law-students-provide-pro-bono-help-struggling-maui-residents-wildfires)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:20:39+00:00

A group of about 20 Pepperdine University Caruso School of Law students is providing legal assistance to the residents of Maui as they work to rebuild their lives after the wildfires.

## Illinois enacts 320 new state laws, including bans on semi-automatic weapons and indoor vaping
 - [https://www.foxnews.com/us/illinois-enacts-320-new-state-laws-bans-semi-automatic-weapons-indoor-vaping](https://www.foxnews.com/us/illinois-enacts-320-new-state-laws-bans-semi-automatic-weapons-indoor-vaping)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:19:50+00:00

Illinois residents are facing 320 new state laws such as a ban on semi-automatic weapons, mandatory paid time off for workers and restrictions on book-banning.

## California father arrested after son used his stolen gun to kill 10-year-old boy: police
 - [https://www.foxnews.com/us/california-father-arrested-son-used-stolen-gun-kill-10-year-old-boy](https://www.foxnews.com/us/california-father-arrested-son-used-stolen-gun-kill-10-year-old-boy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:16:04+00:00

California police arrested a father and his 10-year-old son after the son shot and killed another young boy on Saturday.

## The New Year's resolution most Americans gave up on and when
 - [https://www.foxnews.com/us/new-years-resolution-americans-gave](https://www.foxnews.com/us/new-years-resolution-americans-gave)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T14:09:37+00:00

Americans revealed what New Year&apos;s resolutions they gave up on this year. The goals ranged from going to bed earlier to going to the gym more.

## Oregon weekly newspaper forced to shut down after alleged embezzlement by former employee
 - [https://www.foxnews.com/us/oregon-weekly-newspaper-forced-shut-down-alleged-embezzlement-former-employee](https://www.foxnews.com/us/oregon-weekly-newspaper-forced-shut-down-alleged-embezzlement-former-employee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T13:58:39+00:00

An Oregon weekly newspaper has been forced to lay off its entire staff and cease print operations after discovering that a former employee allegedly embezzled funds.

## Arkansas police chase ends in arrest of suspect linked to Maine co-worker's murder
 - [https://www.foxnews.com/us/arkansas-police-chase-ends-arrest-suspect-linked-maine-co-workers-murder](https://www.foxnews.com/us/arkansas-police-chase-ends-arrest-suspect-linked-maine-co-workers-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T13:35:00+00:00

A suspect was arrested in Arkansas after a police chase following the death of a co-worker in Waterville, Maine on Sunday. Shots were fired during the arrest, police say.

## Maryland police shoot naked man who charged at them with 'machete-like weapon' and knife
 - [https://www.foxnews.com/us/maryland-police-shoot-naked-man-charged-machete-weapon-knife](https://www.foxnews.com/us/maryland-police-shoot-naked-man-charged-machete-weapon-knife)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T13:11:07+00:00

Baltimore police officers shot a man in the leg after he charged at them with a machete-like weapon and another knife on Saturday. The incident occurred during routine patrols.

## 2024 forecast looks like a bleak return to, ‘It’s the economy, stupid’
 - [https://www.foxnews.com/opinion/2024-forecast-looks-like-bleak-return-economy-stupid](https://www.foxnews.com/opinion/2024-forecast-looks-like-bleak-return-economy-stupid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T13:00:41+00:00

Heading into the 2024 election, the economic situation looks bleak for Biden. It could well mean the return of, ‘It’s the economy, stupid,’ as voters fixate on their own finances.

## California shooting leaves 1 dead, 4 injured in Los Angeles County
 - [https://www.foxnews.com/us/california-shooting-leaves-1-dead-4-injured-los-angeles-county](https://www.foxnews.com/us/california-shooting-leaves-1-dead-4-injured-los-angeles-county)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T12:48:30+00:00

A Los Angeles shooting left one person dead and four injured early Monday morning, police say. The incident reportedly took place near a shopping mall.

## Japan issues tsunami warnings, orders evacuations after earthquakes
 - [https://www.foxnews.com/world/japan-issues-tsunami-warnings-orders-evacuations-earthquakes](https://www.foxnews.com/world/japan-issues-tsunami-warnings-orders-evacuations-earthquakes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T12:25:22+00:00

A series of powerful earthquakes struck Japan on New Year&apos;s Day, damaging infrastructure and necessitating evacuations as authorities prepare for high risks of tsunami.

## Israel announces partial troop withdrawal from Gaza in new phase of Hamas war
 - [https://www.foxnews.com/world/israel-announces-partial-troop-withdrawal-gaza-new-phase-hamas-war](https://www.foxnews.com/world/israel-announces-partial-troop-withdrawal-gaza-new-phase-hamas-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T11:34:23+00:00

Israel is planning to withdraw a large number of troops from Gaza as the war against Hamas enters a new phase, allowing some reservests to return to work.

## What’s next for tech in 2024?
 - [https://www.foxnews.com/tech/whats-next-for-tech-in-2024](https://www.foxnews.com/tech/whats-next-for-tech-in-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T11:00:43+00:00

Kurt “CyberGuy&quot; Knutsson looks ahead to the seven emerging trends and innovations in tech that will no doubt transform our lives over the next year.

## A look at NBA contenders heading into 2024
 - [https://www.foxnews.com/sports/look-nba-contenders-heading-2024](https://www.foxnews.com/sports/look-nba-contenders-heading-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T10:55:57+00:00

As the NBA season heads into 2024, Fox News Digital takes a look at what to look for in the top six teams in the Western and Eastern conferences.

## Winter quiz! How well do you know these fun facts about the coldest season?
 - [https://www.foxnews.com/lifestyle/winter-quiz-how-well-know-fun-facts-coldest-season](https://www.foxnews.com/lifestyle/winter-quiz-how-well-know-fun-facts-coldest-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T10:30:52+00:00

Winter quiz! How well do you know facts about the cold, snowy season? Test your knowledge in this fun and engaging lifestyle quiz about this popular season of the year.

## Pro-Palestinian protesters attempt to disrupt New Year's Eve festivities in New York City, Boston
 - [https://www.foxnews.com/us/pro-palestinian-protesters-attempt-disrupt-new-years-eve-festivities-new-york-city-boston](https://www.foxnews.com/us/pro-palestinian-protesters-attempt-disrupt-new-years-eve-festivities-new-york-city-boston)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T10:12:39+00:00

Pro-Palestinian protesters marched in New York City on Sunday to call for a ceasefire between Israel and Hamas amid New Year&apos;s Eve celebrations.

## After one year, 'America's most dangerous law' is damaging policing profession in Illinois, says local sheriff
 - [https://www.foxnews.com/media/one-year-americas-dangerous-law-damaging-policing-profession-illinois-says-local-sheriff](https://www.foxnews.com/media/one-year-americas-dangerous-law-damaging-policing-profession-illinois-says-local-sheriff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T10:06:05+00:00

Jefferson County Sheriff Jeff Bullard said after one year in effect, the SAFE-T Act is having the &quot;intended result&quot; and damaging the policing profession in Illinois.

## Taylor Swift and Travis Kelce's best moments: From friendship bracelets to kisses
 - [https://www.foxnews.com/entertainment/taylor-swift-travis-kelce-best-moments-friendship-bracelets-kisses](https://www.foxnews.com/entertainment/taylor-swift-travis-kelce-best-moments-friendship-bracelets-kisses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T10:00:51+00:00

Taylor Swift and Travis Kelce have made numerous headlines since debuting their romantic relationship in September. Here&apos;s a look at all their best moments so far.

## College Football Playoff semifinals preview: Rose Bowl and Sugar Bowl take center stage
 - [https://www.foxnews.com/sports/college-football-playoff-semifinals-preview-rose-bowl-sugar-bowl-center-stage](https://www.foxnews.com/sports/college-football-playoff-semifinals-preview-rose-bowl-sugar-bowl-center-stage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T10:00:28+00:00

Alabama and Michigan to play at the Rose Bowl while Washington and Texas are to square off in the Sugar Bowl for the right to play for the national championship.

## Gwen Stefani, Blake Shelton, Pierce Brosnan share their new year resolutions: 'Stop drinking'
 - [https://www.foxnews.com/entertainment/gwen-stefani-blake-shelton-pierce-brosnan-share-new-year-resolutions-stop-drinking](https://www.foxnews.com/entertainment/gwen-stefani-blake-shelton-pierce-brosnan-share-new-year-resolutions-stop-drinking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T10:00:25+00:00

Gwen Stefani, Blake Shelton and Pierce Brosnan shared what their resolutions are going into the new year, which include limiting drinking and being more kind.

## Travis Barker, Kim Kardashian, Tyrese Gibson indulge kids with cars, islands, and more flashy gifts
 - [https://www.foxnews.com/entertainment/travis-barker-kim-kardashian-tyrese-gibson-indulge-kids-cars-islands-flashy-gifts](https://www.foxnews.com/entertainment/travis-barker-kim-kardashian-tyrese-gibson-indulge-kids-cars-islands-flashy-gifts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T10:00:25+00:00

Celebrity parents like Travis Barker, Beyoncé, Cardi B, Tyrese Gibson and Kim Kardashian have given their children extremely expensive gifts.

## New Year can bring better sleep at night if you follow these 9 smart steps
 - [https://www.foxnews.com/health/new-year-can-bring-better-sleep-follow-9-smart-steps](https://www.foxnews.com/health/new-year-can-bring-better-sleep-follow-9-smart-steps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:30:54+00:00

When it comes to setting healthy resolutions, sleep is just as essential as nutrition and exercise, experts agree. Here are nine of the year&apos;s most noteworthy sleep findings.

## Mark Wahlberg, Shania Twain, Chris Young share diet tips to maintain fit figures
 - [https://www.foxnews.com/entertainment/mark-wahlberg-shania-twain-chris-young-diet-tips-maintain-fit-figures](https://www.foxnews.com/entertainment/mark-wahlberg-shania-twain-chris-young-diet-tips-maintain-fit-figures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:30:47+00:00

Celebrities including Mark Wahlberg, Shania Twain and country star Chris Young shared their diet tips and revealed how they maintain a healthy lifestyle.

## Ketchup vs. mustard: Which is 'better' for you? Experts chime in on the debate
 - [https://www.foxnews.com/lifestyle/ketchup-vs-mustard-which-better-experts-chime-in-debate](https://www.foxnews.com/lifestyle/ketchup-vs-mustard-which-better-experts-chime-in-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:15:21+00:00

Is ketchup or mustard better for your health? Nutrition pros break down the specs of both food condiments and reveal the best option to squeeze onto your next entree.

## 9 injured in NYC after car plows into civilians, cops during New Year's Eve celebration
 - [https://www.foxnews.com/us/9-injured-nyc-after-car-plows-civilians-cops-during-new-years-eve-celebration](https://www.foxnews.com/us/9-injured-nyc-after-car-plows-civilians-cops-during-new-years-eve-celebration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:03:10+00:00

At least nine people were injured after a car plowed into New Year&apos;s Eve revelers and police officers in New York City, according to officials.

## Family, freedom and unity: House lawmakers reveal their 2024 New Year's resolutions
 - [https://www.foxnews.com/politics/family-freedom-unity-house-lawmakers-reveal-their-2024-new-years-resolutions](https://www.foxnews.com/politics/family-freedom-unity-house-lawmakers-reveal-their-2024-new-years-resolutions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:00:59+00:00

House lawmakers on both sides of the aisle dished on their New Year&apos;s resolutions to Fox News Digital before leaving town for the holidays.

## New laws coming into effect in 2024 – Clean slates, crackdowns and reforms
 - [https://www.foxnews.com/us/new-laws-coming-effect-2024-clean-slates-crackdowns-reforms](https://www.foxnews.com/us/new-laws-coming-effect-2024-clean-slates-crackdowns-reforms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:00:49+00:00

From coast-to-coast, U.S. states are adopting a slew of new laws in 2024, including some that wipe criminal records and a Texas crackdown on illegal immigration.

## 'Complete inaction': Congressional ethics violators of 2023 have yet to be held accountable, watchdog says
 - [https://www.foxnews.com/politics/congressional-ethics-violators-2023-have-yet-held-accountable-watchdog-says](https://www.foxnews.com/politics/congressional-ethics-violators-2023-have-yet-held-accountable-watchdog-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:00:28+00:00

Conservative government watchdog Foundation for Accountability and Civic Trust says the Office of Congressional Ethics is violating its mission of investigating alleged violations.

## Jeffrey Epstein's friend list: Ghislaine Maxwell lawsuit holds clues to names about to be made public
 - [https://www.foxnews.com/us/jeffrey-epstein-friend-list-ghislaine-maxwell-lawsuit-holds-clues-names-about-made-public](https://www.foxnews.com/us/jeffrey-epstein-friend-list-ghislaine-maxwell-lawsuit-holds-clues-names-about-made-public)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:00:25+00:00

Whose Jeffrey Epstein-linked names could be among the 170 John and Jane Does a federal judge has ordered to be identified in court documents?

## Top lawmaker on AI working group says privacy regs should be a priority for Congress
 - [https://www.foxnews.com/politics/top-lawmaker-ai-working-group-privacy-regs-priority-congress](https://www.foxnews.com/politics/top-lawmaker-ai-working-group-privacy-regs-priority-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:00:19+00:00

One of the top AI experts in Congress tells Fox News Digital that the technology could be a catalyst for huge leaps in the U.S. economy, but it brings disruption too.

## North Dakota coal miners unearth ancient mammoth fossil, including 7-foot-long tusk: 'Exciting find'
 - [https://www.foxnews.com/us/north-dakota-coal-miners-unearth-ancient-mammoth-fossil-including-7-foot-long-tusk-exciting-find](https://www.foxnews.com/us/north-dakota-coal-miners-unearth-ancient-mammoth-fossil-including-7-foot-long-tusk-exciting-find)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:00:14+00:00

While working earlier this year in North Dakota, a group of coal miners discovered an ancient mammoth fossil, which included a seven-foot-long tusk.

## Left-wing climate group is quietly training judges how to handle global warming cases
 - [https://www.foxnews.com/politics/left-wing-climate-group-quietly-training-judges-handling-global-warming-cases](https://www.foxnews.com/politics/left-wing-climate-group-quietly-training-judges-handling-global-warming-cases)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:00:11+00:00

A Washington, D.C.-based judicial advocacy group that&apos;s focused on environmental law is quietly training dozens of judges nationwide on how to handle future climate change cases.

## Brian Walshe fights murder case with new lawyer year after wife’s disappearance
 - [https://www.foxnews.com/us/brian-walshe-fights-murder-case-new-lawyer-year-after-wifes-disappearance](https://www.foxnews.com/us/brian-walshe-fights-murder-case-new-lawyer-year-after-wifes-disappearance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:00:05+00:00

Brian Walshe&apos;s high-powered defense lawyer, Tracy Miner, suddenly withdrew from the murder case as both sides prep for 2024 court showdown

## 'M*A*S*H' star Mike Farrell says executive thought show would be pulled off the air, but ‘it struck a chord’
 - [https://www.foxnews.com/entertainment/mash-star-says-executive-thought-show-would-be-pulled-off-air-it-struck-a-chord](https://www.foxnews.com/entertainment/mash-star-says-executive-thought-show-would-be-pulled-off-air-it-struck-a-chord)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T09:00:03+00:00

Mike Farrell starred on the beloved TV series &quot;M*A*S*H,&quot; and ahead of the special on the show airing on Fox on Jan. 1, the actor spoke to Fox News Digital about his time on the hit series.

## Revelers watch ball drop in US, around the world to ring in 2024: 'It's beautiful'
 - [https://www.foxnews.com/world/revelers-watch-ball-drop-us-around-the-world-ring-2024-its-beautiful](https://www.foxnews.com/world/revelers-watch-ball-drop-us-around-the-world-ring-2024-its-beautiful)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T07:07:45+00:00

Revelers around the world celebrated bringing in the new year by watching the ball drop, kissing loved ones and being treated to firework showcases.

## AI development expected to 'explode' in 2024, experts say
 - [https://www.foxnews.com/us/ai-development-expected-explode-2024-experts-say](https://www.foxnews.com/us/ai-development-expected-explode-2024-experts-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T07:00:29+00:00

Artificial intelligence continued to rapidly develop and gain unique uses in 2023, leading experts to predict a big year for the new technology in the coming year.

## On this day in history, January 1, 1953, country music legend Hank Williams dies
 - [https://www.foxnews.com/lifestyle/this-day-history-jan-1-1953-country-music-legend-hank-williams-dies](https://www.foxnews.com/lifestyle/this-day-history-jan-1-1953-country-music-legend-hank-williams-dies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T05:02:30+00:00

Hank Williams was a country music icon from Alabama who rose to stardom in the 1940s. On this day in history, Jan. 1, 1953, Williams died at just 29 years old.

## Packers keep playoff hopes alive with win over division-rival Vikings
 - [https://www.foxnews.com/sports/packers-keep-playoff-hopes-alive-win-division-rival-vikings](https://www.foxnews.com/sports/packers-keep-playoff-hopes-alive-win-division-rival-vikings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T04:39:43+00:00

The Green Bay Packers kept their playoff hopes alive on Sunday night, taking down their division rival Minnesota Vikings, 33-10, as they enter Week 18 with a chance.

## Dive team claims to have found body of missing Orlando woman Sandra Lemire in pond near Disney World
 - [https://www.foxnews.com/us/dive-team-claims-have-found-body-missing-orlando-woman-sandra-lemire-pond-near-disney-world](https://www.foxnews.com/us/dive-team-claims-have-found-body-missing-orlando-woman-sandra-lemire-pond-near-disney-world)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T03:33:18+00:00

Authorities in Orlando uncovered a submerged van with unidentified remains found in a pond near Walt Disney World on New Year&apos;s Eve.

## Ian Ziering, ‘Beverly Hills, 90210’ alum, involved in brawl with bikers: report
 - [https://www.foxnews.com/entertainment/ian-ziering-beverly-hills-90210-alum-involved-brawl-bikers-report](https://www.foxnews.com/entertainment/ian-ziering-beverly-hills-90210-alum-involved-brawl-bikers-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T03:22:55+00:00

According to TMZ, “Beverly Hills, 90210&quot; alum Ian Ziering got into a street brawl on Hollywood Blvd. with bikers in LA on Sunday.

## Longtime Texas Democrat Eddie Bernice Johnson dies at 88
 - [https://www.foxnews.com/politics/longtime-texas-democrat-eddie-bernice-johnson-dies-88](https://www.foxnews.com/politics/longtime-texas-democrat-eddie-bernice-johnson-dies-88)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T03:02:54+00:00

U.S. Rep. Eddie Bernice Johnson, a trailblazing Democrat from the Dallas area who spent three decades in politics, died Sunday at the age of 88.

## WATCH: Ohio state troopers catch loose pig at McDonald's drive-thru
 - [https://www.foxnews.com/us/watch-ohio-state-troopers-catch-loose-pig-mcdonalds-drive](https://www.foxnews.com/us/watch-ohio-state-troopers-catch-loose-pig-mcdonalds-drive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T02:34:33+00:00

Ohio State Highway Patrol shared video of their officers capturing a loose pig at a McDonald&apos;s drive-thru, with the pig&apos;s owner there to assist.

## Colorado mother accused of murdering 2 children, arrested in UK: police
 - [https://www.foxnews.com/us/colorado-mother-accused-murdering-children-arrested-uk-police](https://www.foxnews.com/us/colorado-mother-accused-murdering-children-arrested-uk-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T02:11:43+00:00

A Colorado Springs, Colorado, mother accused of killing her two children and injuring a third, was arrested in the United Kingdom on Saturday.

## Houthi Red Sea attacks ‘will likely continue,’ US Navy says
 - [https://www.foxnews.com/world/houthi-red-sea-attacks-will-likely-continue-us-navy-says](https://www.foxnews.com/world/houthi-red-sea-attacks-will-likely-continue-us-navy-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T01:25:23+00:00

Iran-backed Houthi rebels in Yemen are continuing their attacks on commercial vessels despite the formation of an international maritime mission.

## Chiefs claim AFC West title with win over rival Bengals at home
 - [https://www.foxnews.com/sports/chiefs-claim-afc-west-title-win-rival-bengals-home](https://www.foxnews.com/sports/chiefs-claim-afc-west-title-win-rival-bengals-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T01:19:02+00:00

The Kansas City Chiefs had a different-looking team again this season, but they captured their eighth straight AFC West title with a win over the Cincinnati Bengals on Sunday.

## Kim Jong Un tells military leaders to mobilize most powerful means to destroy enemies, including US: reports
 - [https://www.foxnews.com/world/kim-jong-un-tells-military-leaders-mobilize-most-powerful-means-destroy-enemies-including-us-reports](https://www.foxnews.com/world/kim-jong-un-tells-military-leaders-mobilize-most-powerful-means-destroy-enemies-including-us-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T01:18:57+00:00

Kim Jong Un, North Korea&apos;s dictator, told senior military leaders over the weekend that they must mobilize the most powerful means to destroy enemies, including the U.S.

## ‘Fifty Shades’ star Jamie Dornan reveals he faced a ‘scary’ stalker situation after the film’s success
 - [https://www.foxnews.com/entertainment/fifty-shades-star-jamie-dornan-reveals-faced-scary-stalker-situation-after-films-success](https://www.foxnews.com/entertainment/fifty-shades-star-jamie-dornan-reveals-faced-scary-stalker-situation-after-films-success)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T00:55:23+00:00

&quot;Fifty Shades of Grey&quot; star Jamie Dornan revealed sometime after his mega-success with the film, he and his family faced a stalker situation from an obsessed person.

## Florida man arrested for deliberately hitting deer, filming it for TikTok: police
 - [https://www.foxnews.com/us/florida-man-arrested-deliberately-hitting-deer-filming-tiktok-police](https://www.foxnews.com/us/florida-man-arrested-deliberately-hitting-deer-filming-tiktok-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T00:52:57+00:00

Florida man Clay Kinney, 27, was charged with animal torment, animal torture and a moving traffic violation after allegedly hitting a deer purposefully and filming it.

## Panthers' Bryce Young slams tablet on sideline as frustrations boil over in team's 14th loss
 - [https://www.foxnews.com/sports/panthers-bryce-young-slams-tablet-sideline-frustrations-boil-over](https://www.foxnews.com/sports/panthers-bryce-young-slams-tablet-sideline-frustrations-boil-over)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T00:40:49+00:00

Carolina Panthers rookie quarterback Bryce Young hasn&apos;t shown emotion on many occasions this season, but his frustration boiled over in the team&apos;s latest loss.

## California woman charged with murder after allegedly hitting woman with her car on purpose: police
 - [https://www.foxnews.com/us/california-woman-charged-murder-allegedly-hitting-woman-car-purpose-police](https://www.foxnews.com/us/california-woman-charged-murder-allegedly-hitting-woman-car-purpose-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T00:27:40+00:00

California police arrested and charged a woman with murder after she allegedly ran a woman over who confronted her about stealing a package from her porch.

## 'Systemic racism' responsible for 80% of Black community's health issues, doctor argues
 - [https://www.foxnews.com/media/systemic-racism-responsible-black-communitys-health-issues-doctor-argues](https://www.foxnews.com/media/systemic-racism-responsible-black-communitys-health-issues-doctor-argues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T00:23:14+00:00

Dr. Uché Blackstock argued on MSNBC’s “Velshi&quot; that individual choices outside of systemic racism are only responsible for about 20% of health issues.

## Army veteran tragically run over by 8 vehicles after celebrating 26th birthday: 'It's a nightmare'
 - [https://www.foxnews.com/us/army-veteran-tragically-run-eight-vehicles-celebrating-26th-birthday-nightmare](https://www.foxnews.com/us/army-veteran-tragically-run-eight-vehicles-celebrating-26th-birthday-nightmare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T00:15:51+00:00

Jack Dyer, 26, a U.S. Army veteran, was killed on Dec. 17, when he fell off his motorcycle in Florida. He was run over by 8 vehicles, authorities say.

## Houston man with Alzheimer’s brutally beaten, robbed in parking lot
 - [https://www.foxnews.com/us/houston-man-alzheimers-brutally-beaten-robbed-parking-lot](https://www.foxnews.com/us/houston-man-alzheimers-brutally-beaten-robbed-parking-lot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T00:12:23+00:00

A man suffering from dementia and Alzheimer&apos;s was beaten and assaulted after exiting his vehicle in the parking lot of La Michoacana Meat Market in North Houston last week.

## Panthers owner David Tepper appears to throw drink at Jaguars fan from suite
 - [https://www.foxnews.com/sports/panthers-owner-david-tepper-appears-throw-drink-jaguars-fan](https://www.foxnews.com/sports/panthers-owner-david-tepper-appears-throw-drink-jaguars-fan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-01T00:10:51+00:00

Carolina Panthers owner David Tepper seemingly threw a drink at a Jacksonville Jaguars fan on Sunday during a shutout loss that dropped the Panthers to a dreadful 2-14.

