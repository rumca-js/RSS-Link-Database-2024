# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Police in Kenya suspect a man was attacked by a lion while riding a motorcycle
 - [https://abcnews.go.com/International/wireStory/police-kenya-suspect-man-attacked-lion-riding-motorcycle-106034631](https://abcnews.go.com/International/wireStory/police-kenya-suspect-man-attacked-lion-riding-motorcycle-106034631)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T23:18:25+00:00

Kenyan police have recovered the body of a man believed to have been attacked and killed by a lion while riding a motorcycle near a national reserve in the south of the country

## Former NBA G League player held in woman's killing due in Vegas court after transfer from Sacramento
 - [https://abcnews.go.com/Sports/wireStory/former-nba-league-player-held-womans-killing-due-106035526](https://abcnews.go.com/Sports/wireStory/former-nba-league-player-held-womans-killing-due-106035526)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T23:16:49+00:00

A former NBA developmental league player accused with his ex-girlfriend of killing a woman last month in southern Nevada has been transferred to a Las Vegas jail and is due to face a judge on Tuesday

## Teen found camping in mountains was victim of 'cyber kidnapping': Police
 - [https://abcnews.go.com/US/utah-missing-foreign-exchange-student-cyber-kidnapping/story?id=106032547](https://abcnews.go.com/US/utah-missing-foreign-exchange-student-cyber-kidnapping/story?id=106032547)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T22:35:40+00:00

A foreign exchange student who disappeared in an alleged cyber kidnapping was found safe inside a tent on a Utah mountainside following a dayslong search, police said.

## WATCH:  Eyewitness captures quake chaos at Japan train station
 - [https://abcnews.go.com/International/video/eyewitness-captures-quake-chaos-japan-train-station-106035121](https://abcnews.go.com/International/video/eyewitness-captures-quake-chaos-japan-train-station-106035121)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T21:31:15+00:00

An eyewitness captured scenes of panic in a train station in Kanazawa city after a massive earthquake hit central Japan.

## WATCH:  Panic, destruction seen after powerful earthquake strikes western Japan
 - [https://abcnews.go.com/International/video/panic-destruction-after-powerful-earthquake-strikes-western-japan-106035272](https://abcnews.go.com/International/video/panic-destruction-after-powerful-earthquake-strikes-western-japan-106035272)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T21:30:50+00:00

Footage showed buildings shaking, a massive fire and crowds panicking after a 7.5 magnitude earthquake struck Japan.

## 10 shot, 2 fatally, at New Year's warehouse party: Police
 - [https://abcnews.go.com/US/los-angeles-new-years-party-shooting/story?id=106034448](https://abcnews.go.com/US/los-angeles-new-years-party-shooting/story?id=106034448)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T21:04:12+00:00

Ten people were shot, two fatally, during a New Year's party in downtown Los Angeles, police said.

## Mexican actor Ana Ofelia Murguía, who voiced Mama Coco in 'Coco,' dies at 90
 - [https://abcnews.go.com/Entertainment/wireStory/mexican-actor-ana-ofelia-murgua-voiced-mama-coco-106034548](https://abcnews.go.com/Entertainment/wireStory/mexican-actor-ana-ofelia-murgua-voiced-mama-coco-106034548)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T20:22:03+00:00

The Mexican actor who gave voice to the character of &ldquo;Mama Coco&rdquo; in the popular Pixar film &ldquo;Coco&rdquo; has died

## 16-year-old boy fatally stabbed on a hill overlooking London during New Year's Eve
 - [https://abcnews.go.com/International/wireStory/16-year-boy-fatally-stabbed-hill-overlooking-london-106034350](https://abcnews.go.com/International/wireStory/16-year-boy-fatally-stabbed-hill-overlooking-london-106034350)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T19:55:00+00:00

A 16-year-old boy was stabbed to death on a hill overlooking central London as crowds gathered to watch New Year's Eve fireworks

## $810 million Powerball jackpot up for grabs in Monday night drawing
 - [https://abcnews.go.com/US/810-million-powerball-jackpot-grabs-monday-night-drawing/story?id=106029942](https://abcnews.go.com/US/810-million-powerball-jackpot-grabs-monday-night-drawing/story?id=106029942)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T18:44:33+00:00

The prize stands at an estimated $810 million in the first Powerball jackpot drawing of the year on Monday night at 10:59 pm ET.

## Wrong-way driver injures 7 pedestrians, 1 officer in New Year's Day police chase
 - [https://abcnews.go.com/US/wrong-driver-hits-injures-7-pedestrians-1-officer/story?id=106029945](https://abcnews.go.com/US/wrong-driver-hits-injures-7-pedestrians-1-officer/story?id=106029945)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T16:06:12+00:00

A driver fleeing an early New Year's Day dispute struck at least five pedestrians and injured three police officers before crashing on a New York City sidewalk.

## WATCH:  Woman says her dog will only sing along to 'The First Noel'
 - [https://abcnews.go.com/GMA/Living/video/woman-dog-sing-noel-105997135](https://abcnews.go.com/GMA/Living/video/woman-dog-sing-noel-105997135)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T15:02:37+00:00

We could listen to this pup sing-a-long all day.

## A fire at a bar in Austria kills 1 and severely injures 21 New Year's party revelers
 - [https://abcnews.go.com/International/wireStory/fire-bar-austria-kills-1-severely-injures-21-106029394](https://abcnews.go.com/International/wireStory/fire-bar-austria-kills-1-severely-injures-21-106029394)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T12:54:01+00:00

One person has died and 21 people have been severely injured in a fire that broke out at a bar in the southeastern Austrian city of Graz

## WATCH:  New Year's fireworks illuminate Hong Kong skyline
 - [https://abcnews.go.com/International/video/new-years-fireworks-illuminate-hong-kong-skyline-106029536](https://abcnews.go.com/International/video/new-years-fireworks-illuminate-hong-kong-skyline-106029536)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T12:51:07+00:00

Hong Kong welcomed 2024 with a spectacular New Year's Eve fireworks display over Victoria Harbor.

## Russia launches record number of drones across Ukraine
 - [https://abcnews.go.com/International/wireStory/russia-launches-record-number-drones-ukraine-moscow-kyiv-106029203](https://abcnews.go.com/International/wireStory/russia-launches-record-number-drones-ukraine-moscow-kyiv-106029203)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T11:50:25+00:00

The Ukrainian air force says Russia launched a record 90 Shahed drones over Ukraine during the early hours of New Year&rsquo;s Day

## Early morning shooting kills woman and wounds 4 others in Los Angeles County
 - [https://abcnews.go.com/US/wireStory/early-morning-shooting-kills-woman-wounds-4-los-106029112](https://abcnews.go.com/US/wireStory/early-morning-shooting-kills-woman-wounds-4-los-106029112)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T11:49:53+00:00

Police in California say a woman was killed and four people were wounded in a Los Angeles County shooting shortly after the arrival of the new year

## Powerful earthquake strikes Japan
 - [https://abcnews.go.com/International/powerful-earthquake-strikes-japan/story?id=106028492](https://abcnews.go.com/International/powerful-earthquake-strikes-japan/story?id=106028492)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T08:23:54+00:00

A powerful earthquake with a preliminary magnitude of 7.5 struck Japan on Monday, the U.S. Geological Survey said.

## On New Year's Eve, DeSantis urges crowd to help him 'win the Iowa caucuses'
 - [https://abcnews.go.com/Politics/wireStory/new-years-eve-desantis-urges-crowd-defy-odds-106028185](https://abcnews.go.com/Politics/wireStory/new-years-eve-desantis-urges-crowd-defy-odds-106028185)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T07:26:36+00:00

Ron DeSantis is underscoring how much Iowa means to him, campaigning there into the waning hours of 2023

## China's manufacturing activity slows in December in sign the economy is struggling
 - [https://abcnews.go.com/Business/wireStory/chinas-manufacturing-activity-slows-december-latest-sign-economy-106028366](https://abcnews.go.com/Business/wireStory/chinas-manufacturing-activity-slows-december-latest-sign-economy-106028366)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T07:26:34+00:00

A survey of factory managers in China shows manufacturing contracted in December in the latest sign the world's second-largest economy remains sluggish

## The Empire State rings in the new year with a pay bump for minimum-wage workers
 - [https://abcnews.go.com/US/wireStory/empire-state-rings-new-year-pay-bump-minimum-106028461](https://abcnews.go.com/US/wireStory/empire-state-rings-new-year-pay-bump-minimum-106028461)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T07:26:29+00:00

New York&rsquo;s minimum-wage workers have more than just the new year to celebrate

## WATCH:  Couple welcomes twins hours apart on Christmas Eve and Christmas Day
 - [https://abcnews.go.com/GMA/Family/video/couple-welcomes-twins-hours-apart-christmas-eve-christmas-105998769](https://abcnews.go.com/GMA/Family/video/couple-welcomes-twins-hours-apart-christmas-eve-christmas-105998769)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T06:59:21+00:00

Robert Ka'ala was born at 10:12 p.m. on Christmas Eve. A few hours later, his twin sister Madalena Kahana was born on Christmas Day.

## Judge allows new court in Mississippi's majority-Black capital, rejecting NAACP request to stop it
 - [https://abcnews.go.com/US/wireStory/judge-allows-new-court-mississippis-majority-black-capital-106027196](https://abcnews.go.com/US/wireStory/judge-allows-new-court-mississippis-majority-black-capital-106027196)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-01T03:52:30+00:00

Mississippi officials can create a state-run court in the majority-Black capital

