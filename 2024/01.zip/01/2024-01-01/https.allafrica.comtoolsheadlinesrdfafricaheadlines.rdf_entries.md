# Source:All Africa, URL:https://allafrica.com/tools/headlines/rdf/africa/headlines.rdf, language:en

## Africa: South Africa's ICJ Move Steps Up Pressure for End to War in Gaza
 - [https://allafrica.com/stories/202401010003.html](https://allafrica.com/stories/202401010003.html)
 - RSS feed: https://allafrica.com/tools/headlines/rdf/africa/headlines.rdf
 - date published: 2024-01-01T09:51:01+00:00

[allAfrica] Cape Town -- South Africa's referral of Israel to the International Court of Justice (ICJ) on the grounds that the country is contravening the Genocide Convention adopted by the United Nations in the wake of the Holocaust steps up diplomatic pressures to end the war in Gaza.

