# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## Iron ore/China: rusty metal shines in markets
 - [https://www.ft.com/content/3d8a489e-3409-4748-a41a-46083a3051e0](https://www.ft.com/content/3d8a489e-3409-4748-a41a-46083a3051e0)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-01-01T17:00:53+00:00

Traders have reason to be optimistic despite property market woes in Asian country

## Israel pulls some troops from Gaza to manage forces
 - [https://www.ft.com/content/76ac7fda-86ae-4cfd-b90b-6d8d0db12afb](https://www.ft.com/content/76ac7fda-86ae-4cfd-b90b-6d8d0db12afb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-01-01T13:24:48+00:00

Withdrawal of 5 battalions first significant IDF reduction in besieged enclave since October 7

## Small boat crossings to UK fall by a third in 2023
 - [https://www.ft.com/content/ebb7af60-02b8-4175-bd58-db6a1015df87](https://www.ft.com/content/ebb7af60-02b8-4175-bd58-db6a1015df87)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-01-01T12:51:44+00:00

Border staff say arrivals were ‘unusually low’ due to high wind and ‘confounding factors’

## Banks: investors should demand more ambition on profitability targets
 - [https://www.ft.com/content/d6634628-5e50-4ba5-9f22-13f3b005eda3](https://www.ft.com/content/d6634628-5e50-4ba5-9f22-13f3b005eda3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-01-01T10:30:53+00:00

The amount of regulatory capital required by banks weighs down their return on tangible equity

## Lighter regulation needed to attract ‘captive’ insurers to London
 - [https://www.ft.com/content/6088854e-cbeb-4c40-ac57-8213c7453f6b](https://www.ft.com/content/6088854e-cbeb-4c40-ac57-8213c7453f6b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2024-01-01T09:32:51+00:00

Calls by industry come ahead of promised UK government consultation on new regime

