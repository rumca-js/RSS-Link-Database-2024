# Source:BezPlanu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g, language:pl-PL

## Tu jest Nigeria!
 - [https://www.youtube.com/watch?v=5MJGxz2el-g](https://www.youtube.com/watch?v=5MJGxz2el-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNu7GSRF7Y10OIWHQHpAx1g
 - date published: 2024-01-01T11:12:39+00:00

Jedziemy do miasta Ibadan, żeby poznać kulturę ludności Joruba.

Wszystkie odcinki BezPlanu chronologicznie: http://bit.ly/2MqAO7Q
Wsparcie kanału: https://patronite.pl/BezPlanu

Tu kupicie bransoletki i naszyjniki Acholi:
https://bezplanu.com

Gabriel:
https://www.instagram.com/ariakueh/

Wstępny montaż: @VaSilly 
Vasily https://www.instagram.com/vasilykob/

Tłumaczenie: Justyna Obruśnik
https://useme.com/pl/roles/contractor/justyna-obrusnik,145695/

Czas akcji: listopad 2023r.

