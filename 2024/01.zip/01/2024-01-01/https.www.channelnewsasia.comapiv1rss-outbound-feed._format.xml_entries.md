# Source:Channel Asia Latest News, URL:https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml, language:en

## ASML says Dutch government revoked some export license
 - [https://www.channelnewsasia.com/business/asml-says-dutch-government-revoked-some-export-license-4020206](https://www.channelnewsasia.com/business/asml-says-dutch-government-revoked-some-export-license-4020206)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T23:32:53+00:00



## Do people always say you ‘look tired’? 5 easy steps to freshen up your complexion
 - [https://www.channelnewsasia.com/style-beauty/tired-complexion-how-look-fresh-makeup-skincare-3880686](https://www.channelnewsasia.com/style-beauty/tired-complexion-how-look-fresh-makeup-skincare-3880686)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T23:20:17+00:00

You’re not tired, so why does everyone you meet keep saying that? You may not feel it but fatigue can show up on your skin in many ways.

## At least six dead after huge earthquake rocks Japan on New Year's Day
 - [https://www.channelnewsasia.com/asia/japan-earthquake-ishikawa-new-years-day-tsunami-six-dead-4020116](https://www.channelnewsasia.com/asia/japan-earthquake-ishikawa-new-years-day-tsunami-six-dead-4020116)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T22:41:17+00:00



## At least five dead after huge earthquake rocks Japan on New Year's Day
 - [https://www.channelnewsasia.com/asia/japan-earthquake-ishikawa-new-years-day-tsunami-dead-4020116](https://www.channelnewsasia.com/asia/japan-earthquake-ishikawa-new-years-day-tsunami-dead-4020116)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T22:41:00+00:00



## Salah scores twice as league-leading Liverpool beat Newcastle 4-2
 - [https://www.channelnewsasia.com/sport/salah-scores-twice-league-leading-liverpool-beat-newcastle-4-2-4020151](https://www.channelnewsasia.com/sport/salah-scores-twice-league-leading-liverpool-beat-newcastle-4-2-4020151)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T22:10:30+00:00



## CNA Explains: Why 2024 is a historic year for elections
 - [https://www.channelnewsasia.com/world/2024-elections-record-year-cna-explains-historic-vote-4014251](https://www.channelnewsasia.com/world/2024-elections-record-year-cna-explains-historic-vote-4014251)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T22:06:35+00:00

Which are the polls to watch closely, and what are some of the most pressing risks and consequences? CNA's Chew Hui Min breaks it down.

## Commentary: Can biofuels be the answer to the transition away from fossil fuels?
 - [https://www.channelnewsasia.com/commentary/cop28-fossil-fuel-biofuel-sustainable-aviation-palm-oil-4016206](https://www.channelnewsasia.com/commentary/cop28-fossil-fuel-biofuel-sustainable-aviation-palm-oil-4016206)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T22:00:00+00:00

Let us not be beguiled by the "bio" prefix, but recognise the potential and the limitations of biofuels, says NTU’s Kelvin Law.

## Commentary: How the 'visionaries' of Silicon Valley prioritise profits over technological progress
 - [https://www.channelnewsasia.com/commentary/tech-innovation-silicon-valley-companies-prioritise-profit-over-innovation-progress-4018536](https://www.channelnewsasia.com/commentary/tech-innovation-silicon-valley-companies-prioritise-profit-over-innovation-progress-4018536)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T22:00:00+00:00

The profit motive seen across Silicon Valley frequently impedes innovation, says this management professor.

## Commentary: Will the world see more conflict in 2024? Here are 5 hotspots to watch
 - [https://www.channelnewsasia.com/commentary/2024-war-gaza-ukraine-myanmar-mali-lebanon-pakistan-sri-lanka-4018736](https://www.channelnewsasia.com/commentary/2024-war-gaza-ukraine-myanmar-mali-lebanon-pakistan-sri-lanka-4018736)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T22:00:00+00:00

Some nations have been dealing with simmering unrest, which could erupt in in 2024 and seize the global spotlight, says a Flinders University academic.

## ‘We are the more creative and cutting-edge high jewellery brand on Place Vendome’: Bucheron’s CEO Helene Poulit-Duquesne
 - [https://www.channelnewsasia.com/people/luxury-jewellery-boucheron-ceo-helene-poulit-duquesne-4014011](https://www.channelnewsasia.com/people/luxury-jewellery-boucheron-ceo-helene-poulit-duquesne-4014011)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T20:28:25+00:00

CNA Luxury catches up with Bucheron’s CEO Helene Poulit-Duquesne at its recently reopened boutique at Marina Bay Sands on what her plans are for the 165-year-old brand.

## Israel signals tactics shift, troops pull back as US carrier heads home
 - [https://www.channelnewsasia.com/world/israel-pulls-some-tanks-out-gaza-palestinians-still-under-heavy-bombardment-4020071](https://www.channelnewsasia.com/world/israel-pulls-some-tanks-out-gaza-palestinians-still-under-heavy-bombardment-4020071)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T19:55:00+00:00



## US Navy ending aircraft carrier's Middle East deployment
 - [https://www.channelnewsasia.com/world/us-navy-ending-aircraft-carriers-middle-east-deployment-4020006](https://www.channelnewsasia.com/world/us-navy-ending-aircraft-carriers-middle-east-deployment-4020006)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T19:00:57+00:00



## Israel's top court strikes down key government legal reform
 - [https://www.channelnewsasia.com/world/israels-top-court-strikes-down-key-government-legal-reform-4019986](https://www.channelnewsasia.com/world/israels-top-court-strikes-down-key-government-legal-reform-4019986)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T17:35:40+00:00



## Bank of Israel cuts rate by 25 basis points, first easing by developed country
 - [https://www.channelnewsasia.com/business/bank-israel-cuts-rate-25-basis-points-first-easing-developed-country-4019951](https://www.channelnewsasia.com/business/bank-israel-cuts-rate-25-basis-points-first-easing-developed-country-4019951)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T16:50:31+00:00



## Ghana's Partey and Lamptey miss out on Cup of Nations finals
 - [https://www.channelnewsasia.com/sport/ghanas-partey-and-lamptey-miss-out-cup-nations-finals-4019916](https://www.channelnewsasia.com/sport/ghanas-partey-and-lamptey-miss-out-cup-nations-finals-4019916)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T16:18:31+00:00



## Philippine bourse eyes six IPOs in 2024
 - [https://www.channelnewsasia.com/business/philippine-bourse-eyes-six-ipos-2024-4019906](https://www.channelnewsasia.com/business/philippine-bourse-eyes-six-ipos-2024-4019906)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T16:03:24+00:00



## Elgar looking to bow out on top
 - [https://www.channelnewsasia.com/sport/elgar-looking-bow-out-top-4019901](https://www.channelnewsasia.com/sport/elgar-looking-bow-out-top-4019901)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T15:59:43+00:00



## HSBC completes sale of retail banking business in France
 - [https://www.channelnewsasia.com/business/hsbc-completes-sale-retail-banking-business-france-4019876](https://www.channelnewsasia.com/business/hsbc-completes-sale-retail-banking-business-france-4019876)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T15:42:10+00:00



## Chinese EV giant BYD posts 62% jump in 2023 vehicle sales
 - [https://www.channelnewsasia.com/business/chinese-ev-giant-byd-posts-62-jump-2023-vehicle-sales-4019826](https://www.channelnewsasia.com/business/chinese-ev-giant-byd-posts-62-jump-2023-vehicle-sales-4019826)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T14:02:55+00:00



## Mitoma named in Japan's Asian Cup squad despite ankle injury
 - [https://www.channelnewsasia.com/sport/mitoma-named-japans-asian-cup-squad-despite-ankle-injury-4019821](https://www.channelnewsasia.com/sport/mitoma-named-japans-asian-cup-squad-despite-ankle-injury-4019821)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T13:54:13+00:00



## PSG sign Brazilian defender Beraldo on a five-year deal
 - [https://www.channelnewsasia.com/sport/psg-sign-brazilian-defender-beraldo-five-year-deal-4019816](https://www.channelnewsasia.com/sport/psg-sign-brazilian-defender-beraldo-five-year-deal-4019816)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T13:51:30+00:00



## Dutch police arrest more than 200 during New Year riots
 - [https://www.channelnewsasia.com/world/dutch-police-arrest-more-200-during-new-year-riots-4019766](https://www.channelnewsasia.com/world/dutch-police-arrest-more-200-during-new-year-riots-4019766)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T13:27:21+00:00



## China Evergrande's EV share sale deal lapses
 - [https://www.channelnewsasia.com/business/china-evergrandes-ev-share-sale-deal-lapses-4019801](https://www.channelnewsasia.com/business/china-evergrandes-ev-share-sale-deal-lapses-4019801)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T13:05:04+00:00



## Putin says Russia will 'intensify' attacks on Ukraine
 - [https://www.channelnewsasia.com/world/russia-president-vladimir-putin-intensify-attacks-ukraine-4019786](https://www.channelnewsasia.com/world/russia-president-vladimir-putin-intensify-attacks-ukraine-4019786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T13:02:57+00:00



## Brighton recall Sarmiento from West Brom loan spell
 - [https://www.channelnewsasia.com/sport/brighton-recall-sarmiento-west-brom-loan-spell-4019796](https://www.channelnewsasia.com/sport/brighton-recall-sarmiento-west-brom-loan-spell-4019796)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T13:01:56+00:00



## Chinese automaker Geely raises sales target for 2024 to 1.9 million units
 - [https://www.channelnewsasia.com/business/chinese-automaker-geely-raises-sales-target-2024-19-million-units-4019776](https://www.channelnewsasia.com/business/chinese-automaker-geely-raises-sales-target-2024-19-million-units-4019776)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T12:27:56+00:00



## United's Van de Beek loaned to Frankfurt for rest of season
 - [https://www.channelnewsasia.com/sport/uniteds-van-de-beek-loaned-frankfurt-rest-season-4019771](https://www.channelnewsasia.com/sport/uniteds-van-de-beek-loaned-frankfurt-rest-season-4019771)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T12:13:45+00:00



## United's Van de Beek loaned to Frankfurt for rest of season
 - [https://www.channelnewsasia.com/sport/manchester-united-donny-van-beek-loan-frankfurt-4019771](https://www.channelnewsasia.com/sport/manchester-united-donny-van-beek-loan-frankfurt-4019771)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T12:13:00+00:00



## Pakistan December CPI up 29.7% y/y - statistics bureau
 - [https://www.channelnewsasia.com/business/pakistan-december-cpi-297-y-y-statistics-bureau-4019756](https://www.channelnewsasia.com/business/pakistan-december-cpi-297-y-y-statistics-bureau-4019756)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T11:34:18+00:00



## Baidu terminates $3.6 billion purchase of JOYY's China live-streaming unit
 - [https://www.channelnewsasia.com/business/baidu-terminates-36-billion-purchase-joyys-china-live-streaming-unit-4019751](https://www.channelnewsasia.com/business/baidu-terminates-36-billion-purchase-joyys-china-live-streaming-unit-4019751)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T11:32:55+00:00



## Baidu terminates purchase of JOYY's live streaming business
 - [https://www.channelnewsasia.com/business/baidu-terminates-purchase-joyys-live-streaming-business-4019751](https://www.channelnewsasia.com/business/baidu-terminates-purchase-joyys-live-streaming-business-4019751)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T11:32:55+00:00



## UK warns it is willing to take 'direct action' over Red Sea attacks
 - [https://www.channelnewsasia.com/world/united-kingdom-houthi-rebels-yemen-red-sea-attacks-direct-action-4019726](https://www.channelnewsasia.com/world/united-kingdom-houthi-rebels-yemen-red-sea-attacks-direct-action-4019726)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T11:32:00+00:00



## Nobel winner Yunus convicted in Bangladesh labour law case
 - [https://www.channelnewsasia.com/asia/bangladesh-nobel-winner-muhammad-yunus-convicted-labour-law-4019696](https://www.channelnewsasia.com/asia/bangladesh-nobel-winner-muhammad-yunus-convicted-labour-law-4019696)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T11:27:46+00:00



## Taiwan Votes 2024: The best and worst case scenarios for the island's foreign policy and cross-strait ties
 - [https://www.channelnewsasia.com/asia/taiwan-election-2024-presidential-candidates-cross-strait-foreign-policy-best-worst-case-scenarios-4015011](https://www.channelnewsasia.com/asia/taiwan-election-2024-presidential-candidates-cross-strait-foreign-policy-best-worst-case-scenarios-4015011)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T10:00:00+00:00

If elected president, how will candidates William Lai Ching-te, Hou Yu-ih and Ko Wen-je likely conduct cross-strait ties with China and Taiwan’s foreign policy? CNA gets experts to weigh in.

## Nsue to captain Equatorial Guinea at Cup of Nations finals
 - [https://www.channelnewsasia.com/sport/nsue-captain-equatorial-guinea-cup-nations-finals-4019666](https://www.channelnewsasia.com/sport/nsue-captain-equatorial-guinea-cup-nations-finals-4019666)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T09:53:10+00:00



## Sauber to race as Stake F1 team in 2024 and 2025
 - [https://www.channelnewsasia.com/sport/sauber-race-stake-f1-team-2024-and-2025-4019631](https://www.channelnewsasia.com/sport/sauber-race-stake-f1-team-2024-and-2025-4019631)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T09:21:45+00:00



## More than 140 Rohingya arrive in Indonesia's North Sumatra
 - [https://www.channelnewsasia.com/asia/indonesia-north-sumatra-rohingya-myanmar-arrive-4019616](https://www.channelnewsasia.com/asia/indonesia-north-sumatra-rohingya-myanmar-arrive-4019616)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T09:19:03+00:00



## Sales of Indian SUVs soar, smaller cars skid in December
 - [https://www.channelnewsasia.com/business/sales-indian-suvs-soar-smaller-cars-skid-december-4019626](https://www.channelnewsasia.com/business/sales-indian-suvs-soar-smaller-cars-skid-december-4019626)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T09:03:00+00:00



## Swiatek keeps winning in United Cup as Poland reach quarter-finals
 - [https://www.channelnewsasia.com/sport/swiatek-keeps-winning-united-cup-poland-reach-quarter-finals-4019611](https://www.channelnewsasia.com/sport/swiatek-keeps-winning-united-cup-poland-reach-quarter-finals-4019611)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T08:19:12+00:00



## Magnitude 7.4 earthquake strikes Japan, tsunami warning issued
 - [https://www.channelnewsasia.com/asia/japan-earthquake-magnitude-76-tsunami-warning-western-coastal-regions-4019601](https://www.channelnewsasia.com/asia/japan-earthquake-magnitude-76-tsunami-warning-western-coastal-regions-4019601)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T07:41:18+00:00



## Heavy rains in Australia's east bring more pain to storm-hit residents
 - [https://www.channelnewsasia.com/world/heavy-rains-australias-east-bring-more-pain-storm-hit-residents-4019581](https://www.channelnewsasia.com/world/heavy-rains-australias-east-bring-more-pain-storm-hit-residents-4019581)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T07:29:31+00:00



## 'Kind of the way our season has gone,' says Spurs' Postecoglou after Sarr injury
 - [https://www.channelnewsasia.com/sport/kind-way-our-season-has-gone-says-spurs-postecoglou-after-sarr-injury-4019586](https://www.channelnewsasia.com/sport/kind-way-our-season-has-gone-says-spurs-postecoglou-after-sarr-injury-4019586)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T06:47:19+00:00



## Bank of Korea's Rhee eyes warning signs of prolonged monetary tightening
 - [https://www.channelnewsasia.com/business/bank-koreas-rhee-eyes-warning-signs-prolonged-monetary-tightening-4019576](https://www.channelnewsasia.com/business/bank-koreas-rhee-eyes-warning-signs-prolonged-monetary-tightening-4019576)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T06:27:54+00:00



## Israel begins new year under rockets barrage as army pounds Gaza
 - [https://www.channelnewsasia.com/world/israel-gaza-rockets-barrage-new-year-2024-4019571](https://www.channelnewsasia.com/world/israel-gaza-rockets-barrage-new-year-2024-4019571)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T06:19:11+00:00



## Kvitova to miss Australian Open after announcing pregnancy
 - [https://www.channelnewsasia.com/sport/kvitova-miss-australian-open-after-announcing-pregnancy-4019546](https://www.channelnewsasia.com/sport/kvitova-miss-australian-open-after-announcing-pregnancy-4019546)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T04:36:10+00:00



## Rice calls for mentality change after Arsenal suffer second straight defeat
 - [https://www.channelnewsasia.com/sport/rice-calls-mentality-change-after-arsenal-suffer-second-straight-defeat-4019531](https://www.channelnewsasia.com/sport/rice-calls-mentality-change-after-arsenal-suffer-second-straight-defeat-4019531)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T04:25:44+00:00



## China President Xi says willing to work with US for stable relationship
 - [https://www.channelnewsasia.com/asia/china-xi-jinping-us-joe-biden-diplomatic-ties-anniversary-stable-relationship-4019481](https://www.channelnewsasia.com/asia/china-xi-jinping-us-joe-biden-diplomatic-ties-anniversary-stable-relationship-4019481)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T03:46:05+00:00

Chinese leader Xi Jinping and US President Joe Biden also exchanged congratulations on the 45th anniversary of diplomatic ties between the two countries.

## New mother Osaka makes winning return in Brisbane
 - [https://www.channelnewsasia.com/sport/new-mother-osaka-makes-winning-return-brisbane-4019461](https://www.channelnewsasia.com/sport/new-mother-osaka-makes-winning-return-brisbane-4019461)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T03:07:52+00:00



## Taiwan president says ties with China must be decided by will of the people
 - [https://www.channelnewsasia.com/asia/taiwan-president-tsai-china-ties-will-people-4019411](https://www.channelnewsasia.com/asia/taiwan-president-tsai-china-ties-will-people-4019411)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T03:03:34+00:00



## Kim Jong Un tells army to 'annihilate' South Korea, US if they initiate conflict
 - [https://www.channelnewsasia.com/asia/kim-jong-un-tells-army-annihilate-south-korea-us-if-they-initiate-conflict-4019451](https://www.channelnewsasia.com/asia/kim-jong-un-tells-army-annihilate-south-korea-us-if-they-initiate-conflict-4019451)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T02:57:17+00:00



## Box office 2023: Wonka tops year-end weekend, Barbie is No. 1 movie, Eras Tour concert film pushes industry sales
 - [https://www.channelnewsasia.com/entertainment/wonka-timothee-chalamet-hollywood-box-office-4019426](https://www.channelnewsasia.com/entertainment/wonka-timothee-chalamet-hollywood-box-office-4019426)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T02:56:14+00:00

In 2023, Hollywood saw months-long actor and writer strikes , the unlikely yet successful pairing of Barbenheimer, and an increasing demand for more original stories.

## China's new home prices up in Dec for 4th straight month - survey
 - [https://www.channelnewsasia.com/business/chinas-new-home-prices-dec-4th-straight-month-survey-4019436](https://www.channelnewsasia.com/business/chinas-new-home-prices-dec-4th-straight-month-survey-4019436)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T02:46:14+00:00



## In pictures: Asia rings in New Year 2024
 - [https://www.channelnewsasia.com/asia/new-year-2024-asia-fireworks-parades-parties-4019276](https://www.channelnewsasia.com/asia/new-year-2024-asia-fireworks-parades-parties-4019276)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T01:23:00+00:00



## Australia's Warner retires from ODIs as well as tests
 - [https://www.channelnewsasia.com/sport/australias-warner-retires-odis-well-tests-4019346](https://www.channelnewsasia.com/sport/australias-warner-retires-odis-well-tests-4019346)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T00:39:11+00:00



## Warner retires from one-dayers as well as tests
 - [https://www.channelnewsasia.com/sport/warner-retires-one-dayers-well-tests-4019346](https://www.channelnewsasia.com/sport/warner-retires-one-dayers-well-tests-4019346)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T00:39:11+00:00



## South Korea Dec exports up for third month but at slower pace
 - [https://www.channelnewsasia.com/business/south-korea-dec-exports-third-month-slower-pace-4019336](https://www.channelnewsasia.com/business/south-korea-dec-exports-third-month-slower-pace-4019336)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T00:37:31+00:00



## PGA Tour unable to finalize deal with PIF ahead of Dec. 31 deadline
 - [https://www.channelnewsasia.com/sport/pga-tour-unable-finalize-deal-pif-ahead-dec-31-deadline-4019321](https://www.channelnewsasia.com/sport/pga-tour-unable-finalize-deal-pif-ahead-dec-31-deadline-4019321)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T00:22:59+00:00



## She’s there to listen to the problems of underprivileged, vulnerable women who have no one to talk to
 - [https://www.channelnewsasia.com/women/daughters-tomorrow-befriender-volunteer-lam-li-min-3979586](https://www.channelnewsasia.com/women/daughters-tomorrow-befriender-volunteer-lam-li-min-3979586)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-01T00:14:35+00:00

This stay-at-home mother is a Daughters Of Tomorrow (DOT) volunteer who offers a friendly ear to low-income women – they confide in her about their financial, health and relationship problems. Lam Li Min tells CNA Women that she thinks of these women as friends.

