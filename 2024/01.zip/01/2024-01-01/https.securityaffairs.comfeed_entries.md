# Source:Security Affairs, URL:https://securityaffairs.com/feed, language:en-US

## Top 2023 Security Affairs cybersecurity stories
 - [https://securityaffairs.com/156722/breaking-news/top-2023-security-affairs-stories.html](https://securityaffairs.com/156722/breaking-news/top-2023-security-affairs-stories.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2024-01-01T18:30:49+00:00

These are the Top 2023 Security Affairs cybersecurity stories … enjoy it. CYBERCRIMINALS LAUNCHED “LEAKSMAS” EVENT IN THE DARK WEB EXPOSING MASSIVE VOLUMES OF LEAKED PII AND COMPROMISED DATA Leaksmas: On Christmas Eve, multiple threat actors released substantial data leaks, Resecurity experts reported. 1.7 TB OF DATA STOLEN FROM DIGITAL INTELLIGENCE FIRM CELLEBRITE LEAKED ONLINE [&#8230;]

## Malware exploits undocumented Google OAuth endpoint to regenerate Google cookies
 - [https://securityaffairs.com/156723/hacking/exploit-regenerates-google-cookies.html](https://securityaffairs.com/156723/hacking/exploit-regenerates-google-cookies.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2024-01-01T17:58:03+00:00

CloudSEK researchers analyzed a zero-day exploit that can allow the generation of persistent Google cookies through token manipulation. In October 2023, a developer known as PRISMA first uncovered an exploit that allows the generation of persistent Google cookies through token manipulation. An attacker can use the exploit to access Google services, even after a user&#8217;s [&#8230;]

## Cactus RANSOMWARE gang hit the Swedish retail and grocery provider Coop
 - [https://securityaffairs.com/156709/cyber-crime/cactus-ransomware-coop-sweden.html](https://securityaffairs.com/156709/cyber-crime/cactus-ransomware-coop-sweden.html)
 - RSS feed: https://securityaffairs.com/feed
 - date published: 2024-01-01T12:35:43+00:00

The Cactus ransomware group claims to have hacked Coop, one of the largest retail and grocery providers in Sweden. Coop is one of the largest retail and grocery providers in Sweden, with approximately 800 stores across the country. The stores are co-owned by 3.5 million members in 29 consumer associations. All surplus that is created [&#8230;]

