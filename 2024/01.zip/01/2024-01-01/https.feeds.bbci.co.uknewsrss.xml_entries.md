# Source:BBC, URL:https://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Liverpool 4-2 Newcastle: Eddie Howe 'confused' by penalty decisions in Anfield defeat
 - [https://www.bbc.co.uk/sport/av/football/67859160?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67859160?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T22:57:13+00:00

Newcastle manager Eddie Howe is "confused" by the two penalties awarded to Liverpool and one not awarded to his side in their 4-2 Premier League defeat at Anfield.

## Luke Littler v Rob Cross: Teenager confident of winning PDC World Darts Championship
 - [https://www.bbc.co.uk/sport/darts/67859195?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/darts/67859195?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T22:31:43+00:00

Teenager Luke Littler says he has what it takes to win the PDC World Championship as he prepares for a semi-final against Rob Cross.

## Liverpool 4-2 Newcastle: Mohamed Salah scores twice for Premier League leaders
 - [https://www.bbc.co.uk/sport/football/67818598?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67818598?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T22:21:42+00:00

Mohamed Salah scores twice as Liverpool break down resilient Newcastle to open up a three-point lead at the top of the Premier League.

## Teenager killed in three-car collision on New Year's Day
 - [https://www.bbc.co.uk/news/uk-england-dorset-67858032?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-dorset-67858032?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T19:35:19+00:00

An 18-year-old passenger was killed and three other people injured in the crash on New Year's Day.

## Leinster 21-22 Ulster: Away side hang on for famous win at the RDS
 - [https://www.bbc.co.uk/sport/rugby-union/67857956?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67857956?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T19:08:11+00:00

Ulster claim a famous win at the RDS as they beat Leinster 21-22 in a pulsating United Rugby Championship contest in Dublin.

## Japan earthquake: Powerful tremors destroy buildings and trigger evacuations
 - [https://www.bbc.co.uk/news/world-asia-67859702?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67859702?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T19:03:34+00:00

Dozens of buildings have collapsed in several towns, trapping an unknown number of people on New Year's Day.

## Man dies in shooting outside Granton pub before New Year bells
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-67856748?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-67856748?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T18:13:43+00:00

Another man is in hospital after what police described as a targeted attack at the Edinburgh bar.

## Stoke City 0-0 Ipswich Town: Fourth draw in five games for Tractor Boys
 - [https://www.bbc.co.uk/sport/football/67818351?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67818351?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T17:39:03+00:00

Second-placed Ipswich draw for the fourth time in five Championship fixtures as their game with 10-man Stoke ends goalless.

## Israel Supreme Court strikes down judicial reforms
 - [https://www.bbc.co.uk/news/world-middle-east-67859177?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67859177?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T17:37:34+00:00

The controversial plans triggered nationwide protests last year against Benjamin Netanyahu's government.

## Leicester City 4-1 Huddersfield Town: Tom Cannon scores twice as Foxes go 10 points clear at top of Championship
 - [https://www.bbc.co.uk/sport/football/67818350?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67818350?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T17:32:14+00:00

Tom Cannon scores twice, his first goals for Leicester, as they thrash Huddersfield to go 10 points clear at the top of the Championship.

## NFL Plays of the Week: Odell Beckham Jr & Justin Fields star
 - [https://www.bbc.co.uk/sport/av/american-football/67859154?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/67859154?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T17:17:20+00:00

Baltimore Ravens; Odell Beckham Jr and Justin Fields of the Chicago Bears star in the best plays of the week from the NFL.

## Loony Dookers brave icy Forth for New Year's Day plunge
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-67856747?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-67856747?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T17:07:25+00:00

Swimmers have continued the traditional dip in the Firth of Forth to kick off 2024.

## Luke Littler, 16, charges into World Darts Championship semi-finals
 - [https://www.bbc.co.uk/sport/darts/67858060?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/darts/67858060?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T17:02:40+00:00

Teenager Luke Littler powers through to the PDC World Darts Championship semi-finals with a 5-1 victory over Northern Ireland's Brendan Dolan.

## Mother arrested over children’s deaths in US appears in UK court
 - [https://www.bbc.co.uk/news/world-67857888?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-67857888?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T16:06:18+00:00

Kimberlee Singler faces extradition to the US after being charged with murder and attempted murder.

## Marvel star Jeremy Renner: I'm so blessed a year after accident
 - [https://www.bbc.co.uk/news/entertainment-arts-67856733?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67856733?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T15:54:15+00:00

The Marvel star reflects on his recovery after being run over by his own snow plough last New Year's Day.

## United Cup: Great Britain out after Australia beat United States
 - [https://www.bbc.co.uk/sport/tennis/67858248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67858248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T15:41:59+00:00

Great Britain miss out on the United Cup quarter-finals after Australia qualify from Group C with a 2-1 victory over the United States.

## Putin vows to 'intensify' attacks against Ukraine military targets
 - [https://www.bbc.co.uk/news/world-67858038?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-67858038?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T15:37:01+00:00

The Russian leader's comments come after days of aerial bombardment by both sides in the conflict.

## We're a scapegoat for PPE failures, says Michelle Mone's husband
 - [https://www.bbc.co.uk/news/uk-67857460?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67857460?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T15:16:21+00:00

Doug Barrowman says his family has been "treated as a punchbag" for "lamentable failures" by ministers.

## Muhammad Yunus: Nobel laureate sentenced to jail in Bangladesh
 - [https://www.bbc.co.uk/news/world-67858016?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-67858016?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T14:39:27+00:00

Supporters of the Bangladeshi economist say the case against him is politically motivated.

## Sunderland 2-0 Preston North End: First home win for Black Cats boss Michael Beale
 - [https://www.bbc.co.uk/sport/football/67818352?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67818352?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T14:33:38+00:00

Alex Pritchard and Nazariy Rusyn fire Sunderland to 2-0 win over Preston North End in the Championship

## Cheadle murder arrest after two women found dead
 - [https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-67856207?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-67856207?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T13:47:50+00:00

The women, aged 91 and 63, were discovered at a house in Staffordshire on New Year's Eve.

## Brisbane International: Andy Murray loses to Grigor Dimitrov in first round
 - [https://www.bbc.co.uk/sport/tennis/67857027?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67857027?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T12:23:40+00:00

Andy Murray makes a first-round exit at the Brisbane International as Grigor Dimitrov comes from behind to win in three sets.

## Disney's Coco voice actor Ana Ofelia Murguía dies aged 90
 - [https://www.bbc.co.uk/news/entertainment-arts-67856726?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67856726?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T12:15:04+00:00

Ana Ofelia Murguía voiced great-grandmother Mama Coco in the Oscar-winning animation.

## Greater Manchester Police officer charged with child sex attack
 - [https://www.bbc.co.uk/news/uk-england-manchester-67856969?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-67856969?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T12:11:52+00:00

PC Dean Dempster, 34, is charged with the sexual assault of a child under 13 and misconduct.

## In Pictures: New Year 2024 celebrations from around the world
 - [https://www.bbc.co.uk/news/world-67855973?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-67855973?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T11:44:39+00:00

From fireworks to meditation - here's how the world welcomed the new year.

## Alarm in Kanazawa as city rocked by earthquake
 - [https://www.bbc.co.uk/news/world-asia-67855819?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67855819?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T11:33:15+00:00

Japan has been hit by a series of earthquakes, prompting evacuation orders and tsunami warnings.

## Migrant Channel crossings fell in 2023, official data says
 - [https://www.bbc.co.uk/news/uk-england-kent-67856720?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-kent-67856720?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T11:24:43+00:00

Government figures show 29,437 people crossed the Channel in 2023, down 36% on 2022.

## New year: Fireworks and street parties ring in 2024 across UK
 - [https://www.bbc.co.uk/news/uk-67855970?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67855970?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T11:17:41+00:00

London began the new year with a message of inclusivity, while Britpop band Pulp helped Scotland enter 2024.

## King and Queen at Sandringham church for New Year’s Eve service
 - [https://www.bbc.co.uk/news/uk-england-norfolk-67856075?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-norfolk-67856075?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T10:28:10+00:00

Charles and Camilla wave at onlookers as they visit St Mary Magdalene Church in Sandringham.

## Melissa Hoskins: Tributes paid to former Olympic cyclist after car death
 - [https://www.bbc.co.uk/sport/cycling/67856425?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/67856425?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T10:15:39+00:00

Tributes are paid to two-time Olympian Melissa Hoskins following her death in Adelaide, Australia after being hit by a car.

## Microsoft boss changes tune after criticism of UK
 - [https://www.bbc.co.uk/news/business-67839205?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67839205?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T09:58:28+00:00

Brad Smith had said the UK was bad for business after a takeover of Activision was initially blocked.

## Cerne Abbas Giant: Has the mystery of the chalk hill figure been solved?
 - [https://www.bbc.co.uk/news/uk-england-dorset-67717015?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-dorset-67717015?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T09:46:48+00:00

The origins of the Cerne Abbas Giant hill figure are unravelled by Oxford academics.

## Period pants could get cheaper after VAT is removed
 - [https://www.bbc.co.uk/news/business-67855869?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67855869?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T09:15:15+00:00

Shoppers will no longer pay VAT on period pants following a campaign by charities and retailers.

## Arrest after boy, 16, dies in New Year's Eve stabbing
 - [https://www.bbc.co.uk/news/uk-england-london-67856252?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67856252?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T09:11:55+00:00

A man has been held after the boy, believed to be 16, was stabbed to death in Primrose Hill, London.

## Petra Kvitova: World number 17 announces pregnancy
 - [https://www.bbc.co.uk/sport/tennis/67856302?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67856302?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T09:04:52+00:00

Petra Kvitova announces she is expecting her first child and will miss the upcoming Australian Open.

## Watch: Moment quake hits Japan coastal town
 - [https://www.bbc.co.uk/news/world-asia-67856117?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67856117?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T08:56:21+00:00

Footage from Japanese broadcaster NHK shows the 7.6 magnitude earthquake shake Ishikawa prefecture.

## Tsunami warning in Japan after strong earthquake
 - [https://www.bbc.co.uk/news/world-asia-67855990?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67855990?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T08:15:27+00:00

A powerful 7.6 magnitude earthquake struck the country's central region on Monday.

## Student's lost artwork found 4,000 miles away
 - [https://www.bbc.co.uk/news/articles/cljx6r70x6lo?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/cljx6r70x6lo?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T08:07:11+00:00

Grace Hart feared losing her university place, until a Pakistan-based photographer got in touch.

## NFL Week 17 results & review: Ravens, 49ers claim top seeds, Eagles upset at home
 - [https://www.bbc.co.uk/sport/american-football/67855066?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/american-football/67855066?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T07:58:23+00:00

The Baltimore Ravens and San Francisco 49ers clinch the two top play-off seeds after both win on New Year's Eve, while the Philadelphia Eagles suffer a big upset home defeat.

## Naomi Osaka: Former world number one wins first match of comeback at Brisbane International
 - [https://www.bbc.co.uk/sport/tennis/67855933?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67855933?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T07:39:19+00:00

New mother Naomi Osaka wins the first match of her comeback by beating Tamara Korpatsch in straight sets at the Brisbane International.

## The Birmingham child who paved the way for the heel prick test
 - [https://www.bbc.co.uk/news/uk-england-birmingham-67627128?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-67627128?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T07:28:43+00:00

Sheila Jones, who had Phenylketonuria (PKU), was treated by pioneering doctors 70 years ago.

## Taiwan and China will 'surely be reunified' says Xi in New Year's Eve address
 - [https://www.bbc.co.uk/news/world-asia-china-67855477?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-67855477?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T05:09:57+00:00

The Chinese leader's New Year's Eve message comes just weeks ahead of Taiwan's crucial general election.

## Disney's earliest Mickey and Minnie Mouse enter public domain as US copyright expires
 - [https://www.bbc.co.uk/news/entertainment-arts-67833411?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67833411?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T05:00:08+00:00

Disney's copyright on the earliest version of the cartoon characters expires in the US on 1 January.

## Israel says war in Gaza expected to continue throughout 2024
 - [https://www.bbc.co.uk/news/world-middle-east-67855117?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67855117?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T02:43:27+00:00

In a new year message, Israel's military says it expects fighting in Gaza for the rest of the year.

## Red Sea: UK defence secretary says British forces will repel Houthi attacks
 - [https://www.bbc.co.uk/news/uk-67855304?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67855304?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T02:40:41+00:00

The defence secretary says British forces will take direct action against Houthi rebels targeting vessels in the key shipping lane.

## Ukraine war: Zelensky promises more Ukraine-made weapons in new year speech
 - [https://www.bbc.co.uk/news/world-europe-67855158?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67855158?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T02:31:26+00:00

The Ukrainian president's message comes as five people were killed in attacks early on New Year's Day.

## Australia veteran David Warner retires from ODI cricket
 - [https://www.bbc.co.uk/news/world-australia-67855359?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-67855359?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T02:30:33+00:00

The veteran player, aged 37, made the announcement in the lead up to his final test match.

## Hogmanay fireworks see in new year in Edinburgh
 - [https://www.bbc.co.uk/news/uk-67854633?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67854633?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T00:37:51+00:00

Tens of thousands of revellers have taken part in the celebrations.

## 'I was a gambling addict who stole £1.3m and went to prison'
 - [https://www.bbc.co.uk/news/uk-england-norfolk-67503468?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-norfolk-67503468?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T00:29:00+00:00

Andy May, who has just got out of prison, wants to help other people with gambling addictions.

## Post Office scandal TV drama 'like a dream' say victims
 - [https://www.bbc.co.uk/news/business-67806869?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67806869?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T00:19:49+00:00

Horizon victims hope a new mini-series will give their story the "oxygen it deserves".

## BBC Sound Of 2024: Soul sensation Elmiene kicks off the countdown
 - [https://www.bbc.co.uk/news/entertainment-arts-67695420?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67695420?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T00:18:25+00:00

Velvety smooth vocals and unabashedly intimate songs make the Oxford crooner one to watch in 2024.

## Scotland sees in 2024 with fireworks and song
 - [https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-67804796?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-north-east-orkney-shetland-67804796?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T00:17:26+00:00

Tens of thousands watch fireworks explode over Edinburgh's skyline as a New Year begins.

## Almost three million tested for cancer in England
 - [https://www.bbc.co.uk/news/health-67841348?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-67841348?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T00:09:56+00:00

Record numbers are being tested for cancer but treatment targets are still being missed in England.

## Household energy price rise of 5% comes into force
 - [https://www.bbc.co.uk/news/business-67785266?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67785266?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T00:00:16+00:00

A higher cap for the next three months adds £94 to the typical annual domestic energy bill.

## Justin Welby: Political leaders should treat opponents as human beings
 - [https://www.bbc.co.uk/news/uk-67844356?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67844356?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-01T00:00:04+00:00

The Archbishop of Canterbury urges politicians to "forswear wedge issues" and avoid divisive topics.

