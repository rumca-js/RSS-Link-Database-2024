# Source:Gadgets 360, URL:https://feeds.feedburner.com/gadgets360-latest, language:en

## OnePlus Ace 3 Teaser Shows Thin Bezels, Confirmed to Get 3 Years of Android Updates
 - [https://www.gadgets360.com/mobiles/news/oneplus-ace-3-teaser-bezel-size-os-updates-display-details-launch-january-4-4781312](https://www.gadgets360.com/mobiles/news/oneplus-ace-3-teaser-bezel-size-os-updates-display-details-launch-january-4-4781312)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-01T13:26:34+00:00

OnePlus Ace 3 is confirmed to launch in black, blue and gold colour options

## iPhone 16 Pro Models Tipped to Feature Larger Displays Again; Full Dimensions Suggested
 - [https://www.gadgets360.com/mobiles/news/iphone-16-pro-max-series-display-size-leak-dimensions-report-4780720](https://www.gadgets360.com/mobiles/news/iphone-16-pro-max-series-display-size-leak-dimensions-report-4780720)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-01T12:10:22+00:00

iPhone 15 Pro and iPhone 15 Pro Max come in Black, Blue, Natural Titanium and White colourways

## Redmi Note 13 Series Price in India Leaked Ahead of January 4 Launch; Colours, Storage Options Tipped
 - [https://www.gadgets360.com/mobiles/news/redmi-note-13-5g-pro-plus-series-india-price-colour-options-configurations-launch-4780192](https://www.gadgets360.com/mobiles/news/redmi-note-13-5g-pro-plus-series-india-price-colour-options-configurations-launch-4780192)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-01T10:47:34+00:00

Redmi Note 13 series was launched in China in September

## Realme Set to Announce New Phone in India on January 3, Could Be Realme 12 Series
 - [https://www.gadgets360.com/mobiles/news/realme-new-phone-announcement-january-3-12-series-gt-5-pro-india-launch-4780414](https://www.gadgets360.com/mobiles/news/realme-new-phone-announcement-january-3-12-series-gt-5-pro-india-launch-4780414)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-01T10:00:02+00:00

The Realme 12 series could feature a periscope camera

## iPhone 15 Series, iPads, MacBooks, Apple Watches Available at Discounted Prices at Vijay Sales Apple Days Sale
 - [https://www.gadgets360.com/mobiles/news/iphone-15-plus-pro-max-13-ipad-air-macbook-airpods-apple-watch-series-9-vijay-sales-india-4779188](https://www.gadgets360.com/mobiles/news/iphone-15-plus-pro-max-13-ipad-air-macbook-airpods-apple-watch-series-9-vijay-sales-india-4779188)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-01T09:27:52+00:00

iPhone 15 and iPhone 15 Plus (pictured) are offered in Black, Blue, Green, Pink, and Yellow colourways

## Steam’s Best of 2023 Reveals Its Highest-Selling and Most-Played Games of the Past Year
 - [https://www.gadgets360.com/games/news/steam-best-of-2023-games-top-sellers-most-played-winter-sale-baldurs-gate-3-apex-legends-starfield-valve-4780058](https://www.gadgets360.com/games/news/steam-best-of-2023-games-top-sellers-most-played-winter-sale-baldurs-gate-3-apex-legends-starfield-valve-4780058)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-01T08:49:48+00:00

Baldur's Gate 3 was crowned Game of the Year at The Game Awards 2023

## Poco X6 Series, Poco M6 4G Design Renders, Colour Options Leaked; Camera Details Tipped
 - [https://www.gadgets360.com/mobiles/news/poco-x6-pro-series-india-launch-design-colour-options-m6-4g-global-expected-specifications-4779191](https://www.gadgets360.com/mobiles/news/poco-x6-pro-series-india-launch-design-colour-options-m6-4g-global-expected-specifications-4779191)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-01T05:50:49+00:00

Poco M6 4G is expected to join Poco M6 5G (pictured) in the lineup

## ISRO Successfully Launches X-Ray Polarimeter Satellite; Will Study Black Holes, Other Celestial Objects
 - [https://www.gadgets360.com/science/news/isro-launch-x-ray-polarimeter-satellite-xposat-black-hole-mission-insight-4779307](https://www.gadgets360.com/science/news/isro-launch-x-ray-polarimeter-satellite-xposat-black-hole-mission-insight-4779307)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-01T05:32:29+00:00

The launch placed the XPoSat into a 650 km Low Earth Orbit

