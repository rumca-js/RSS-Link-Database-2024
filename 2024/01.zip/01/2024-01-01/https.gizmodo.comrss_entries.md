# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Ring 2024 In With All the Amazing New Lego Sets Out In January
 - [https://gizmodo.com/lego-releases-january-2024-marvel-star-wars-city-1851132796](https://gizmodo.com/lego-releases-january-2024-marvel-star-wars-city-1851132796)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-01-01T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/55dbcd343a6b232dfedd6e4e7d0166a6.png" /><p>New year, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/best-toys-2023-star-wars-marvel-hasbro-neca-tmnt-1851078771">new... Lego</a>? That’s how that saying goes, right? After a <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/lego-new-sets-october-2023-star-wars-marvel-christmas-1850887349">few</a> <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/lego-new-sets-november-23-mario-gwp-black-friday-vip-1850981430">quiet</a> <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/lego-releases-december-2023-orient-express-modular-1851066867">months</a> to round out 2023, Lego is starting 2024 <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/lego-technic-earth-and-moon-in-orbit-orrery-

