# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Liverpool vs Newcastle United live: Kieran Trippier benched as Howe and Klopp name lineups
 - [https://www.telegraph.co.uk/football/2024/01/01/liverpool-vs-newcastle-live-score-updates-premier-league](https://www.telegraph.co.uk/football/2024/01/01/liverpool-vs-newcastle-live-score-updates-premier-league)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-01-01T19:03:48+00:00



## Ukraine: The Latest - 'We will celebrate victory with the whole world'
 - [https://www.telegraph.co.uk/world-news/2024/01/01/ukraine-the-latest-we-will-celebrate-victory-with-the-w](https://www.telegraph.co.uk/world-news/2024/01/01/ukraine-the-latest-we-will-celebrate-victory-with-the-w)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-01-01T17:38:35+00:00



## Luke Littler vs Brendan Dolan, live: latest updates from World Darts Championship
 - [https://www.telegraph.co.uk/darts/2024/01/01/luke-littler-vs-brendan-dolan-live-score-updates-pdc-world](https://www.telegraph.co.uk/darts/2024/01/01/luke-littler-vs-brendan-dolan-live-score-updates-pdc-world)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-01-01T13:41:09+00:00



## Israel-Hamas war live: Hamas launches New Year rocket salvo on Israel
 - [https://www.telegraph.co.uk/world-news/2024/01/01/israel-hamas-war-latest-missiles-new-year](https://www.telegraph.co.uk/world-news/2024/01/01/israel-hamas-war-latest-missiles-new-year)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-01-01T09:21:41+00:00



## Nine ways to be more positive in 2024
 - [https://www.telegraph.co.uk/christmas/2024/01/01/nine-ways-to-be-more-positive-in-2024](https://www.telegraph.co.uk/christmas/2024/01/01/nine-ways-to-be-more-positive-in-2024)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2024-01-01T08:00:00+00:00



