# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Philadelphia Mummers PARADE turns ugly as spectator grabs Trump flag from participant sparking fracas and chants of 'f***ing liberal'
 - [https://www.dailymail.co.uk/news/article-12917155/Philadelphia-Mummers-PARADE-turns-ugly-spectator-grabs-Trump-flag-participant-sparking-fracas-chants-f-ing-liberal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917155/Philadelphia-Mummers-PARADE-turns-ugly-spectator-grabs-Trump-flag-participant-sparking-fracas-chants-f-ing-liberal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T23:32:43+00:00

The Philadelphia Mummers parade turned ugly after a spectator grabbed the Trump flag from one of its participants sparking a fracas and chants of 'f***ing liberal.'

## Tasman Highway crash: Teenage pedestrian killed at Orielton, highway closed in both directions
 - [https://www.dailymail.co.uk/news/article-12917443/Teen-dies-crash-highway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917443/Teen-dies-crash-highway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T23:30:03+00:00

A teenage boy has died in a horror car crash on a major highway just days into the new year.

## The WHO is accused of 'trans bias' after calling for self-ID to become a right in its first global guide to transgender care
 - [https://www.dailymail.co.uk/news/article-12917509/WHO-accused-trans-bias-calling-self-ID-right-transgender-care.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917509/WHO-accused-trans-bias-calling-self-ID-right-transgender-care.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T23:28:58+00:00

The agency was accused of choosing a group of 'blatantly biased' activists and medics to develop its guidance on improving access to 'health services by trans and gender diverse people'.

## Wannabe YouTube star is slapped in the face in prank gone wrong - as he's slammed for 'pathetic' stunt
 - [https://www.dailymail.co.uk/news/article-12917135/YouTuber-slapped-prank-gone-wrong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917135/YouTuber-slapped-prank-gone-wrong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T23:26:22+00:00

Izanal, who posts prank videos to YouTube and Instagram, was slapped across the face by a woman's boyfriend after he  asked her if she was single.

## Tragic twist after two children drowned in Swan River on New Year's Eve
 - [https://www.dailymail.co.uk/news/article-12917209/Swan-River-two-children-drowned-New-Years-Eve-twist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917209/Swan-River-two-children-drowned-New-Years-Eve-twist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T23:13:33+00:00

Two children who drowned in Swan River in Perth on New Year's Eve had recently arrived in Australia as refugees from the Middle East.

## Rifle-wielding teen is found walking streets carrying his sister's DECAPITATED HEAD in broad daylight after leaving her naked corpse lying outside gas station in Mexico
 - [https://www.dailymail.co.uk/news/article-12917169/Rifle-wielding-teen-walking-streets-carrying-sisters-DECAPITATED-HEAD-broad-daylight-leaving-naked-corpse-lying-outside-gas-station-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917169/Rifle-wielding-teen-walking-streets-carrying-sisters-DECAPITATED-HEAD-broad-daylight-leaving-naked-corpse-lying-outside-gas-station-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T23:08:43+00:00

19-year-old Sebastián was arrested in western Mexico after he was spotted walking in broad daylight holding the head of his 29-year-old sister, Julieta, on Saturday

## The UK should send warships to the Red Sea to protect ships from Iranian-backed Houthi terrorists, naval chiefs demand
 - [https://www.dailymail.co.uk/news/article-12917411/The-UK-send-warships-Red-Sea-protect-ships-Iranian-backed-Houthi-terrorists-naval-chiefs-demand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917411/The-UK-send-warships-Red-Sea-protect-ships-Iranian-backed-Houthi-terrorists-naval-chiefs-demand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T22:55:30+00:00

Defence Secretary Grant Shapps insisted that British forces were ready to act against Houthi rebels who are targeting cargo ships.

## Freed asylum seeker Mohammed Ali Nadari back behind bars after he was arrested twice within weeks
 - [https://www.dailymail.co.uk/news/article-12917179/Mohammed-Ali-Nadari-high-court-detainee-released-merrylands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917179/Mohammed-Ali-Nadari-high-court-detainee-released-merrylands.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T22:30:52+00:00

Mohammed Ali Nadari, 45, was one of the 148 asylum seekers released under the controversial High Court decision that ruled that indefinite detention was unlawful.

## Police launch the first investigation of its kind into 'virtual rape' in the metaverse after a young girl is 'attacked by several men' in an online video game
 - [https://www.dailymail.co.uk/news/article-12917329/Police-launch-investigation-kind-virtual-rape-metaverse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917329/Police-launch-investigation-kind-virtual-rape-metaverse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T22:24:08+00:00

The girl under the age of 16 is said to have been left distraught after her avatar - her digital character - was gang raped by the online strangers.

## Now 200 more bank branches are set to close as lenders continue to withdraw from the UK's high streets
 - [https://www.dailymail.co.uk/news/article-12917381/Now-200-bank-branches-set-close-lenders-continue-withdraw-UKs-high-streets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917381/Now-200-bank-branches-set-close-lenders-continue-withdraw-UKs-high-streets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T22:23:43+00:00

The latest exodus follows the 645 that closed last year. Nearly 6,000 have disappeared since the start of 2015.And the trend will not change this year as banks continue to cut costs.

## Flight chaos as woman 'attacks airline staff' on plane bound from Gold Coast to Melbourne
 - [https://www.dailymail.co.uk/news/article-12917373/woman-attacks-staff-plane-Gold-Coast-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917373/woman-attacks-staff-plane-Gold-Coast-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T22:22:44+00:00

There were chaotic scenes at Gold Coast airport on New Year's Eve, when a Victorian woman was arrested after allegedly attacking airline staff.

## Meadowbank fire: Man caught up in apartment blaze and left fighting for life dies from his injuries
 - [https://www.dailymail.co.uk/news/article-12917291/Meadowbank-fire-Man-caught-apartment-blaze-left-fighting-life-dies-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917291/Meadowbank-fire-Man-caught-apartment-blaze-left-fighting-life-dies-injuries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T22:21:30+00:00

A 45-year-old man who was left fighting for his life after his apartment caught fire has died after succumbing to his injuries.

## Six-year-old Perth boy is killed in New Zealand alongside four-year-old cousin in horrific UTV accident
 - [https://www.dailymail.co.uk/news/article-12917269/Six-year-old-Perth-boy-killed-New-Zealand-alongside-four-year-old-cousin-horrific-UTV-accident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917269/Six-year-old-Perth-boy-killed-New-Zealand-alongside-four-year-old-cousin-horrific-UTV-accident.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T22:15:07+00:00

The little boys were killed after they came off a UTV and fell into the swollen Waikāinga Stream at a property in Peria, east of Kaitāia on New Zealand 's North Island, at about 5.15pm on December 19.

## Green Day is slammed for changing lyrics of American Idiot to 'I'm not a part of the MAGA agenda' on ABC's New Year's Rockin' Eve
 - [https://www.dailymail.co.uk/news/article-12917111/Green-Day-change-lyrics-American-Idiot-MAGA-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917111/Green-Day-change-lyrics-American-Idiot-MAGA-Trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T22:12:51+00:00

Playing at Dick Clark's New Year's Rockin' Eve, the band changed the line 'I'm not a part of a redneck agenda' to 'I'm not a part of the MAGA agenda' - which they started doing in 2017.

## NYC-bound migrants are being dropped off at New Jersey train stations to bypass Mayor Eric Adams' executive order limiting bus arrivals from Texas
 - [https://www.dailymail.co.uk/news/article-12917129/migrants-new-jersey-new-york-city-texas-eric-adams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917129/migrants-new-jersey-new-york-city-texas-eric-adams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T21:49:22+00:00

An influx of migrants were dropped off at train stations in New Jersey over the weekend. Nearly 397 migrants arrived and are believed to be getting into New York City from the Garden State.

## Gold Coast flooding: Thousands face no power for 10 days after floods in Queensland as more rain and wild weather forecast for today
 - [https://www.dailymail.co.uk/news/article-12917075/Gold-Coast-flooding-Thousands-face-no-power-10-days-floods-Queensland-rain-wild-weather-forecast-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917075/Gold-Coast-flooding-Thousands-face-no-power-10-days-floods-Queensland-rain-wild-weather-forecast-today.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T21:38:08+00:00

More wild weather is on the way for south east Queensland and northern NSW, with residents warned to brace for heavy rain prompting fears of significant flooding.

## Americans want a strongman president: Half of Republican voters and more than a third of Democrats back leader who will 'bend the rules' of democracy to achieve political goals
 - [https://www.dailymail.co.uk/news/article-12917011/president-poll-majority-voters-bend-rules-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917011/president-poll-majority-voters-bend-rules-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T21:27:49+00:00

The question - along with several others meant to foreshadow early stages of democratic decline - was posed to exactly 1,500 Americans spread across the US.

## Ice cold hangover cure: New Year's Day swimmers brave frigid sea water for annual plunges in Boston and New York
 - [https://www.dailymail.co.uk/news/article-12916709/Polar-plunge-Coney-Island-Boston-L-Street-Brownies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916709/Polar-plunge-Coney-Island-Boston-L-Street-Brownies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T21:22:27+00:00

New Year's Day swimmers braved the frigid sea water for the annual polar bear plunges that took place in New York and Boston, as part of an annual tradition that dates back more than 100 years.

## Locals' uprising against the 'Lord of the Manor': Stately home Holkham Hall at centre of bitter row after Norfolk villagers claim its owner the Earl of Leicester 'unfairly' took over 3,000 acres of public land
 - [https://www.dailymail.co.uk/news/article-12917037/Locals-uprising-against-Lord-Manor-Stately-home-Holkham-Hall-centre-bitter-row-Norfolk-villagers-claim-owner-Earl-Leicester-unfairly-took-3-000-acres-public-land.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917037/Locals-uprising-against-Lord-Manor-Stately-home-Holkham-Hall-centre-bitter-row-Norfolk-villagers-claim-owner-Earl-Leicester-unfairly-took-3-000-acres-public-land.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T21:20:06+00:00

Holkham Hall, valued at more than £200 million, is on the north Norfolk coast and owned by the Earl of Leicester, Thomas Coke, who argues the 3,000 acres of land is lawfully part of his estate.

## More than 302,000 illegal migrants crossed into the US in December setting the record for most entries in HISTORY as Biden grapples with the fallout of his administration's policies
 - [https://www.dailymail.co.uk/news/article-12917047/migrants-border-history-biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917047/migrants-border-history-biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T21:12:47+00:00

A record number of migrants crossed the U.S. southern border in December, according to a new report, topping the highest amount ever recorded as President Joe Biden grapples with crisis.

## Gov. Greg Abbott shipped over 85,000 illegal migrants from Texas in over one year drawing ire of Democrats as crisis turns from just remote border towns to America's biggest cities
 - [https://www.dailymail.co.uk/news/article-12916871/Gov-Greg-Abbott-shipped-85-000-illegal-migrants-Texas-one-year-drawing-ire-Democrats-crisis-turns-just-remote-border-towns-Americas-biggest-cities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916871/Gov-Greg-Abbott-shipped-85-000-illegal-migrants-Texas-one-year-drawing-ire-Democrats-crisis-turns-just-remote-border-towns-Americas-biggest-cities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T21:10:21+00:00

Since August 2022, Texas Gov. Greg Abbott has transported 85,400 illegal migrants to sanctuary cities run by Democrats who are now calling for federal assistance in dealing with the crisis.

## CNN's David Axelrod is slammed for for claiming Taylor Swift is 'killing the Kansas City Chiefs' - before quickly backtracking after they won
 - [https://www.dailymail.co.uk/news/article-12916853/CNNs-David-Axelrod-slammed-claiming-Taylor-Swift-killing-Kansas-City-Chiefs-quickly-backtracking-won.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916853/CNNs-David-Axelrod-slammed-claiming-Taylor-Swift-killing-Kansas-City-Chiefs-quickly-backtracking-won.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T20:47:03+00:00

A CNN political commentator has gotten a lot of hate on X (formerly Twitter ) after he questioned how Taylor Swift is affecting the Kansas City Chiefs on December 31.

## Over 200 service members demand Biden's military leadership be court-martialed and FIRED for forced 'experimentation' on troops with COVID-19 vaccine mandate leaving 'significant' physical and mental scars
 - [https://www.dailymail.co.uk/news/article-12917065/biden-military-leadership-fired-covid-mandate-troops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917065/biden-military-leadership-fired-covid-mandate-troops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T20:39:09+00:00

Over 200 active duty and retired service members are vowing to hold the Biden administration accountable for 'trampling' on their rights by enforcing the COVID-19 vaccine mandate.

## Allegedly drunk driver hits pedestrian and slams into a shop before fleeing scene
 - [https://www.dailymail.co.uk/news/article-12917033/Allegedly-drunk-driver-hits-pedestrian-fleeing-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917033/Allegedly-drunk-driver-hits-pedestrian-fleeing-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T20:29:25+00:00

Charges have been laid after a woman was struck by an allegedly drunk driver who ploughed into a convenience store in Sydney's inner-west.

## US office buildings face $117BN debt time bomb: Mortgages due this year threaten to sink US economy as thousands of workplaces remain empty
 - [https://www.dailymail.co.uk/news/article-12916911/US-office-buildings-face-117BN-debt-time-bomb-Mortgages-year-threaten-sink-economy-thousands-workplaces-remain-empty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916911/US-office-buildings-face-117BN-debt-time-bomb-Mortgages-year-threaten-sink-economy-thousands-workplaces-remain-empty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T20:10:25+00:00

Owners of office space around the country took out their loans when interest rates were half what they are now, and may not be able to refinance them at higher ones.

## Royle Family star Sue Johnston, 80, says people should have the right to die as she backs Dame Esther Rantzen's assisted dying campaign
 - [https://www.dailymail.co.uk/news/article-12916957/royle-family-sue-johnston-dame-esther-rantzen-assisted-dying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916957/royle-family-sue-johnston-dame-esther-rantzen-assisted-dying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T20:07:46+00:00

Ms Johnston supports the terminally ill being able to end their own lives, provided there are legal safeguards. Dame Esther has called on MPs to hold a debate for a free vote on assisted dying.

## Trump leads Biden by two points and is winning with Hispanic and young voters in first poll of 2024 as 17 percent say they will vote for a third candidate
 - [https://www.dailymail.co.uk/news/article-12916901/trump-biden-winning-hispanic-voters-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916901/trump-biden-winning-hispanic-voters-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T19:23:39+00:00

Donald Trump is beating Joe Biden in two key voter groups, giving him an overall lead in the presidential race, the first new poll of 2024 found.

## New Year's Day travel nightmare: Pro-Palestinian mob targets roads around JFK Airport causing gridlock for miserable passengers leaving NYC
 - [https://www.dailymail.co.uk/news/article-12916895/new-years-day-pro-palestinian-mob-jfk-airport-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916895/new-years-day-pro-palestinian-mob-jfk-airport-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T19:12:26+00:00

A pro-Palestine mob has created a New Years Day nightmare as they have blockaded the JFK airport and surrounding roads, causing a gridlock for travelers.

## Man, 33, is electrocuted and dies after jumping into waterfall 'to cool himself off' while out celebrating New Year's at club in Brazil
 - [https://www.dailymail.co.uk/news/article-12916625/Man-electrocuted-waterfall-pool-Brazil-New-Years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916625/Man-electrocuted-waterfall-pool-Brazil-New-Years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T19:11:44+00:00

A man died after going into cardiac arrest at New Year's party in Brazil moments after he jumped into the waterfall area of a pool and was electrocuted.

## 2023 was America's bloodiest ever year with 40 mass murders - the most on record - with both murder-suicides and the number of teens killed or injured also hitting shocking new highs
 - [https://www.dailymail.co.uk/news/article-12916239/americas-bloodiest-year-mass-murders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916239/americas-bloodiest-year-mass-murders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T19:10:56+00:00

From Texas to Maine, there have been a total of 40 mass killings involving guns this year, data from The AP, USA Today, and Northeastern University shows.

## British safari guide, 56, is 'lucky to be alive' after spending 'absolutely terrifying' night clinging to a truck after taking a wrong turn into crocodile-infested waters in Kruger National Park
 - [https://www.dailymail.co.uk/news/article-12916837/British-safari-guide-5-lucky-alive-night-crocodile-infested-waters-Kruger-National-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916837/British-safari-guide-5-lucky-alive-night-crocodile-infested-waters-Kruger-National-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T19:09:34+00:00

Mike Turner, 56, had just picked up the second-hand open-topped 'game viewer' 4x4 and was following directions from Google Maps to a guest house when he was directed across a bridge.

## Boy, 10, shoots dead another 10-year-old kid after 'bragging' about stolen firearm stashed in his dad's car
 - [https://www.dailymail.co.uk/news/article-12916667/Boy-10-shoots-dead-10-year-old-kid-bragging-stolen-firearm-stashed-dads-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916667/Boy-10-shoots-dead-10-year-old-kid-bragging-stolen-firearm-stashed-dads-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T19:00:56+00:00

A 10-year-old boy shot dead another 10-year-old after the juvenile 'bragged' about a stolen firearm he found stashed in his father's car

## 'How on earth this could be allowed to happen?': Mother 'sickened' after teenage killer who murdered her son 'stars in rap video from prison' over Christmas
 - [https://www.dailymail.co.uk/news/article-12916597/How-earth-allowed-happen-Mother-sickened-teenage-killer-murdered-son-stars-rap-video-prison-Christmas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916597/How-earth-allowed-happen-Mother-sickened-teenage-killer-murdered-son-stars-rap-video-prison-Christmas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T18:43:59+00:00

Zoey McGill believes Calum Maddison, who was 15 when he knifed her son Jack Woodley (pictured) in the back, is the rapper in a short drill rap-style film uploaded to TikTok over Christmas.

## Furious mom of teen DUI suspect squares up to cop and the pair both end up getting arrested
 - [https://www.dailymail.co.uk/news/article-12916561/mom-fight-cops-arresting-drunk-driver-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916561/mom-fight-cops-arresting-drunk-driver-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T18:24:02+00:00

A New Mexico mother attacked a police officer as her son was being arrested for DUI on August 27. She jumped on the officer's back and was pulled off by another officer.

## Off-duty cop is shot dead while confronting three robbers - including teen girl - as they stole beer from a North Carolina convenience store
 - [https://www.dailymail.co.uk/news/article-12916593/Off-duty-cop-shot-dead-confronting-three-robbers-including-teen-girl-stole-beer-North-Carolina-convenience-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916593/Off-duty-cop-shot-dead-confronting-three-robbers-including-teen-girl-stole-beer-North-Carolina-convenience-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T18:03:12+00:00

Sergeant Philip Dale Nix saw the trio robbing a Sheetz on Sandy Ridge Road in Greensboro, North Carolina, on Saturday and was allegedly shot dead by Jamere Justice Foster, 18.

## Heavy rain and 60mph gales set to spark more travel chaos for Brits on first day back to the office tomorrow - with yellow warnings in place across the country
 - [https://www.dailymail.co.uk/news/article-12916735/Heavy-rain-60mph-gales-set-spark-travel-chaos-Brits-day-office-tomorrow-yellow-warnings-place-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916735/Heavy-rain-60mph-gales-set-spark-travel-chaos-Brits-day-office-tomorrow-yellow-warnings-place-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T18:02:31+00:00

The Met Office has issued a yellow weather warning for wind and rain for large parts of the country until 9pm tomorrow, with the heaviest downpours hitting Wales, the Midlands and eastern England.

## Rude awakening: 4.1-magnitude earthquake strikes Los Angeles on New Year's Day
 - [https://www.dailymail.co.uk/news/article-12916745/Rude-awakening-4-1-magnitude-earthquake-strikes-Los-Angeles-New-Years-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916745/Rude-awakening-4-1-magnitude-earthquake-strikes-Los-Angeles-New-Years-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T17:55:00+00:00

In a rude awakening for revelers nursing hangovers, the tremblor struck 12 miles off the coast of Rancho Palos Verdes in Los Angeles County at 8.27am.

## Fury after war veteran, 102, was left stranded in his flat on Christmas Day after retirement block's lift broke down
 - [https://www.dailymail.co.uk/news/article-12916485/Fury-war-veteran-102-left-stranded-flat-Christmas-Day-retirement-blocks-lift-broke-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916485/Fury-war-veteran-102-left-stranded-flat-Christmas-Day-retirement-blocks-lift-broke-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T17:50:20+00:00

Frank Proctor, who served in World War Two, had hoped to spend his birthday surrounded by his grand-children and great-grandchildren, but instead was left alone in the flat bock in Southampton.

## Next government shutdown in 18 DAYS: Congress STILL divided over topline spending number and border security as negotiations continue but controversial 'poison pills' like banning Pride flags and defunding DEI could tank any deal
 - [https://www.dailymail.co.uk/news/article-12916563/government-shutdown-congress-divided-border-security.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916563/government-shutdown-congress-divided-border-security.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T17:36:33+00:00

The U.S. government is at risk for another shutdown with only 18 days to come to an agreement on a topline spending number and a way to handle border security.

## David Axelrod says trying to keep Trump off the ballot would 'rip country apart' as Sen. Lindsey Graham says ex-president has 'legitimate claim' for immunity from January 6 prosecution
 - [https://www.dailymail.co.uk/news/article-12916473/obama-david-axelrod-trump-ballot-warning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916473/obama-david-axelrod-trump-ballot-warning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T17:04:26+00:00

Sen. Lindsey Graham said Trump's claim he should have immunity over Jan. 6 cases is 'legitimate' - as Obama senior advisor David Axelrod said efforts to keep him off the ballot will 'rip the country apart.'

## California becomes first state to offer health insurance to ALL illegal migrants: Taxpayers will be forced to fork out $3.1BN PER YEAR in medical care for an extra 700,000 people
 - [https://www.dailymail.co.uk/news/article-12916381/California-state-offer-health-insurance-illegal-migrants-Taxpayers-forced-fork-3-1BN-medical-care-extra-700-000-people-1-1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916381/California-state-offer-health-insurance-illegal-migrants-Taxpayers-forced-fork-3-1BN-medical-care-extra-700-000-people-1-1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T16:58:19+00:00

California has become the first state to offer universal health insurance to all illegal migrants regardless of whether they have any documentation.

## Donald Trump confirms Melania's mother Amalija, 78, is 'very ill' causing the former first lady to skip New Years Eve party at Mar-a-Lago: It's a 'very tough' situation he told an adoring crowd during toast to ring in 2024
 - [https://www.dailymail.co.uk/news/article-12916489/Donald-Trump-confirms-Melanias-mother-Amalija-78-ill-causing-former-lady-skip-New-Years-Eve-party-Mar-Lago-tough-situation-told-adoring-crowd-toast-ring-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916489/Donald-Trump-confirms-Melanias-mother-Amalija-78-ill-causing-former-lady-skip-New-Years-Eve-party-Mar-Lago-tough-situation-told-adoring-crowd-toast-ring-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T15:59:52+00:00

Former President Donald Trump confirmed Melania's mother Amalija Knavs, is 'very ill' and the situation has been 'tough' for their family.

## Missing Chinese exchange student, 17, is found 'very cold and scared' inside a tent on a mountainside after being 'cyber kidnapped'
 - [https://www.dailymail.co.uk/news/article-12916323/missing-chinese-exchange-student-cyber-kidnapped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916323/missing-chinese-exchange-student-cyber-kidnapped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T15:59:37+00:00

Chinese exchange student  Kai Zhuang, 17, was discovered in the Brigham City Canyon area on Sunday night after he was last seen early Thursday morning. Police believe he was 'cyber kidnapped.'

## Disney's earliest Mickey Mouse enters the public domain: Steamboat Willie made cinema history in 1928 and can now be used and watched for free after copyright expired
 - [https://www.dailymail.co.uk/news/article-12916289/disney-mickey-mouse-public-domain-copyright.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916289/disney-mickey-mouse-public-domain-copyright.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T15:57:33+00:00

Cartoonists and Disney lovers can celebrate the New Year with the release of Images from a cinema classic featuring Mickey and Minnie Mouse.

## Pictured: Schoolboy, 16, who was stabbed to death in front of thousands of people watching the fireworks on Primrose Hill is named by police as they probe New Year's Eve murder
 - [https://www.dailymail.co.uk/news/article-12916527/Primrose-Hill-stabbing-victim-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916527/Primrose-Hill-stabbing-victim-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T15:55:40+00:00

Schoolboy Harry Pitman was killed as he stood and waited to watch the fireworks extravaganza.

## Grieving mother of speedboat killer Jack Shepherd's victim fears he will never tell the truth about Thames first date crash just weeks before his release from prison
 - [https://www.dailymail.co.uk/news/article-12916331/grieving-mother-speedboat-killer-jack-shepherds-victim-speaks-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916331/grieving-mother-speedboat-killer-jack-shepherds-victim-speaks-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T14:53:20+00:00

Exclusive: Roz Wickens, 58, spoke of her continuing anguish over the loss of daughter Charlotte Brown, 24, just weeks before Shepherd's expected release from prison.

## Moment huge wildfires rage near Spanish resort with Brit holidaymakers celebrating NYE forced to evacuate after 'fireworks triggered blaze'
 - [https://www.dailymail.co.uk/news/article-12916333/mijas-spain-wildfire-new-years-eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916333/mijas-spain-wildfire-new-years-eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T14:51:14+00:00

It took an army of firefighters to control a blaze that forced people from their homes amid New Year's Eve celebrations in southern Spain.

## Inside LA's swankest new $165,000-per-month rehab facility Carrara - where VIP patients are tended to by at least 20 staff including masseuses and a celebrity chef on tap
 - [https://www.dailymail.co.uk/news/article-12891177/inside-swanky-los-angeles-rehab-facility-masseuses-celebrity-chef.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12891177/inside-swanky-los-angeles-rehab-facility-masseuses-celebrity-chef.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T14:10:07+00:00

Carrara in Hollywood Hills opened its doors on New Year's Day, offering up to six patients at a time everything from workout sessions to sound baths as part of its 5* program.

## Reparations movement in California is plunged into chaos after San Francisco mayor abandons $4 million pledge - as New York becomes third state to launch task force to address state's 'painful legacy of slavery'
 - [https://www.dailymail.co.uk/news/article-12894461/Reparations-movement-California-New-York-slavery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12894461/Reparations-movement-California-New-York-slavery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T14:09:56+00:00

California 's reparations movement faces an uncertain future after San Francisco's mayor scrapped plans for a designated office to explore the issue.

## Ukrainian dwarf Natalia Grace may SUE adoptive parents for civil damages - as legal expert says she has a 'good chance' of winning big after a 'fraud was perpetrated on the court' when she was legally re-aged
 - [https://www.dailymail.co.uk/news/article-12885613/Ukrainian-dwarf-Natalia-Grace-SUE-adoptive-parents-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12885613/Ukrainian-dwarf-Natalia-Grace-SUE-adoptive-parents-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T14:08:59+00:00

Ukranian dwarf Natalia Grace could be set to sue her adoptive parents to combat their claims that she was a homicidal adult posing as a six-year-old.

## Fugitive US mother, 35, who fled to the UK 'after killing her two children' was found hiding in London hotel after going on the run because 'she knew exactly what was going to happen', court hears as she fights extradition
 - [https://www.dailymail.co.uk/news/article-12916313/Fugitive-mother-35-fled-UK-killing-two-children-hiding-London-hotel-going-run-knew-exactly-going-happen-court-hears-fights-extradition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916313/Fugitive-mother-35-fled-UK-killing-two-children-hiding-London-hotel-going-run-knew-exactly-going-happen-court-hears-fights-extradition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T13:46:37+00:00

Kimberlee Singler, 35, appeared in the dock at Westminster Magistrates' Court this morning where she revealed her intention to fight extradition back to Colorado to face trial.

## Dipping into 2024! Swimmers brave the cold for traditional New Year's Day plunge into the sea
 - [https://www.dailymail.co.uk/news/article-12916317/brave-outdoor-swimmers-new-years-day-dip-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916317/brave-outdoor-swimmers-new-years-day-dip-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T13:46:18+00:00

From Kent to Fife, hundreds of swimmers braved the icy waters to ring in the New Year.

## Inside the exclusive New Year's Day White Party at lavish waterfront Crypto Castle as VIP guests turn up in luxury cars - but some missed the dress code memo
 - [https://www.dailymail.co.uk/news/article-12916005/New-Years-Day-party-Crypto-Castle-Miss-B.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916005/New-Years-Day-party-Crypto-Castle-Miss-B.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T13:44:43+00:00

Socialites and influencers have gathered for an exclusive New Year's Day party at the luxurious Crypto Castle, in Sydney's ritzy eastern suburbs.

## Pictured: Widowed pensioner, 91, who was found dead by her daughter at home in market town on New Year's Eve - as murder detectives arrest 68-year-old man
 - [https://www.dailymail.co.uk/news/article-12916279/Pictured-Widowed-pensioner-91-dead-daughter-home-market-town-New-Years-Eve-murder-detectives-arrest-68-year-old-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916279/Pictured-Widowed-pensioner-91-dead-daughter-home-market-town-New-Years-Eve-murder-detectives-arrest-68-year-old-man.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T13:43:38+00:00

A murder investigation is underway after an elderly woman and her daughter were found dead at their home in Cheadle on New Year's Eve.

## EXCLUSIVE: Defiant Jack Grealish 'WON'T let the burglars win' after £1m Boxing Day raid as he 'refuses to be driven from his Cheshire mansion'
 - [https://www.dailymail.co.uk/news/article-12916263/jack-grealish-refused-driven-cheshire-mansion-1million-boxing-day-raid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916263/jack-grealish-refused-driven-cheshire-mansion-1million-boxing-day-raid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T13:40:31+00:00

It comes after the Manchester City and England ace broke his silence last night revealing the impact the Boxing Day raid had on him, his fiancé, Sasha, and his family.

## How Japanese earthquake has chilling echoes of 2011 tsunami disaster that killed at least 20,000 and caused nuclear meltdown
 - [https://www.dailymail.co.uk/news/article-12916139/How-Japanese-earthquake-chilling-echoes-2011-tsunami-disaster-killed-20-000-caused-nuclear-meltdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916139/How-Japanese-earthquake-chilling-echoes-2011-tsunami-disaster-killed-20-000-caused-nuclear-meltdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T13:35:04+00:00

Japan is now bracing for waves of up to 5 metres (16.4ft) to hit later today, in an eerily similar echo of the 2011 tsunami that killed at least 20,000 and caused a nuclear reactor to go into meltdown.

## Abu Ousayd: Islamic cleric unleashes bizarre anti-Semitic rant at Bankstown's Al Madina Dawah Centre saying Muslims shouldn't celebrate NYE because it's a 'day of circumcision'
 - [https://www.dailymail.co.uk/news/article-12916111/Abu-Ousayd-Islamic-cleric-New-Years-Eve-Bankstowns-Al-Madina-Dawah-Centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916111/Abu-Ousayd-Islamic-cleric-New-Years-Eve-Bankstowns-Al-Madina-Dawah-Centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T13:15:10+00:00

Abu Ousayd launched a bizarre tirade against New Year's Eve celebrations, describing the festivities as a 'celebration of foreskin' and urging Muslims not to take part.

## XL Bully campaigners win temporary injunction to stop 240 dogs in rescue homes being put down after strict laws came into force on December 31
 - [https://www.dailymail.co.uk/news/article-12916167/american-bully-xl-campaigners-injunction-stop-dogs-dying-rescue-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916167/american-bully-xl-campaigners-injunction-stop-dogs-dying-rescue-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T12:41:42+00:00

Under the Government's guidelines, XL Bully dogs that arrived in rescue homes since October 31, which had not been rehomed, would need to be destroyed.

## 'We lost you 13 years ago today Maudie. You are still with us': Jason Watkins shares heartbreaking video of his daughter who died from sepsis singing Somewhere Over The Rainbow at the kitchen table
 - [https://www.dailymail.co.uk/news/article-12916165/We-lost-13-years-ago-today-Maudie-Jason-Watkins-shares-heartbreaking-video-daughter-died-sepsis-singing-Rainbow-kitchen-table.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916165/We-lost-13-years-ago-today-Maudie-Jason-Watkins-shares-heartbreaking-video-daughter-died-sepsis-singing-Rainbow-kitchen-table.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T12:39:24+00:00

Jason Watkins has shared a heartbreaking video of his daughter Maude singing 'Somewhere over the rainbow' on the 13th anniversary of her death and said that she 'is still with' his family.

## Xi Jinping congratulates Biden saying he wants to 'promote world peace' with America as the two countries mark 45 years of diplomatic ties a day after warning China's reunification with Taiwan is 'inevitable'
 - [https://www.dailymail.co.uk/news/article-12916189/xi-jinping-china-congratulates-president-biden-peace-taiwan-reunification.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916189/xi-jinping-china-congratulates-president-biden-peace-taiwan-reunification.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T12:28:04+00:00

Xi called China and U.S. forming ties 'a major event' in the history of bilateral relations and in international relations while also issuing a stark warning about the future of Taiwan.

## Families living on millionaires' peninsula fear for their lives after invasion of boy racers driving souped up cars
 - [https://www.dailymail.co.uk/news/article-12916193/Families-living-millionaires-peninsula-fear-lives-invasion-boy-racers-driving-souped-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916193/Families-living-millionaires-peninsula-fear-lives-invasion-boy-racers-driving-souped-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T12:24:10+00:00

The exclusive Sandbanks is 'being used as a race track' where petrolheads come screeching down the neighbourhood in their kitted out cars almost every night.

## Alex Scott shows off her incredible abs in a tiny white two-piece while girlfriend Jess Glynne soaks up the sun as they ring in the New Year in Mexico
 - [https://www.dailymail.co.uk/tvshowbiz/article-12916227/Alex-Scott-shows-incredible-abs-tiny-white-two-piece-girlfriend-Jess-Glynne-soaks-sun-ring-New-Year-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12916227/Alex-Scott-shows-incredible-abs-tiny-white-two-piece-girlfriend-Jess-Glynne-soaks-sun-ring-New-Year-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T12:17:42+00:00

The footballer, 39, was flaunting her taut abs in a tiny white bikini as she soaked up the sun during the break with her songstress girlfriend, 34

## MrBeast fires off brutal put down after Elon Musk suggests he should up load his hugely popular videos to X
 - [https://www.dailymail.co.uk/news/article-12916137/MrBeast-elon-musk-videos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916137/MrBeast-elon-musk-videos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T11:26:08+00:00

The hugely popular streamer claimed that X's monetization policies are not comparable to YouTube.

## Mornington Peninsula house goes up in flames after disastrous fireworks mishap - as tradie is hailed a hero for dragging a disabled women from her burning bedroom
 - [https://www.dailymail.co.uk/news/article-12915955/Mornington-Peninsula-fireworks-house-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915955/Mornington-Peninsula-fireworks-house-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T10:52:37+00:00

A tradie has been hailed as a hero for rescuing a disabled woman from her bedroom after illegal fireworks caused her house on Victoria's Mornington Peninsula to go up in flames.

## Denmark's backing for new king: Survey taken days before Queen Margrethe's dramatic abdication revealed over 80% of population had a positive opinion of scandal-hit Crown Prince Frederik
 - [https://www.dailymail.co.uk/news/article-12916051/Denmarks-backing-new-king-Survey-taken-days-Queen-Margrethes-dramatic-abdication-revealed-80-population-positive-opinion-scandal-hit-Crown-Prince-Frederik.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916051/Denmarks-backing-new-king-Survey-taken-days-Queen-Margrethes-dramatic-abdication-revealed-80-population-positive-opinion-scandal-hit-Crown-Prince-Frederik.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T10:31:07+00:00

An opinion poll carried out by Epinion revealed that 84% had a positive view of the soon-to-be-king, while 85% thought highly of his wife, Crown Princess Mary.

## Cleaner loses sex discrimination case after failing to prove man was responsible for leaving 'explosion of excrement' in disabled loo she had to scrub
 - [https://www.dailymail.co.uk/news/article-12916097/Cleaner-loses-sex-discrimination-case-failing-prove-man-responsible-leaving-explosion-excrement-disabled-loo-scrub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916097/Cleaner-loses-sex-discrimination-case-failing-prove-man-responsible-leaving-explosion-excrement-disabled-loo-scrub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T10:27:11+00:00

Jenniene Talbot was employed as a cleaning operative at Par Market - one of the UK's largest indoor markets in St Austell, Cornwall - from June 1 until June 22 last year.

## Schoolboy, 16, is stabbed dead on Primrose Hill in New Year's Eve murder just minutes before midnight as crowds gathered to watch fireworks
 - [https://www.dailymail.co.uk/news/article-12916017/Schoolboy-16-stabbed-dead-Primrose-Hill-New-Years-Eve-murder-just-minutes-midnight-crowds-gathered-watch-fireworks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12916017/Schoolboy-16-stabbed-dead-Primrose-Hill-New-Years-Eve-murder-just-minutes-midnight-crowds-gathered-watch-fireworks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T10:21:46+00:00

Police say the victim was attacked on Primrose Hill - where big crowds had gathered to watch London Eye's firework display - at around 11.40pm on New Year's Eve.

## Bodhi Mani Risby-Jones: Extraordinary claim from naked Aussie tradie over rampage that almost saw him imprisoned in Indonesia
 - [https://www.dailymail.co.uk/news/article-12915921/Bodhi-Mani-Risby-Jones-Indonesia-rampage-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915921/Bodhi-Mani-Risby-Jones-Indonesia-rampage-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T09:29:53+00:00

Bodhi Mani Risby-Jones, 23, was locked up in an Indonesian prison on April 27 after he was accused by police of drunken attacks on multiple people, including one who received serious leg injuries.

## Israel warns war in Gaza will continue 'throughout 2024' - as Hamas launches barrage of rockets across the border on the dot of midnight
 - [https://www.dailymail.co.uk/news/article-12915985/Israel-warns-war-Gaza-continue-2024-Hamas-launches-barrage-rockets-border-dot-midnight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915985/Israel-warns-war-Gaza-continue-2024-Hamas-launches-barrage-rockets-border-dot-midnight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T09:28:51+00:00

Daniel Hagari, spokesman for the Israel Defence Forces (IDF) said in a new year's message that Israeli troops were preparing for continued fighting in 2024.

## How outrageous movie Saltburn is giving a boost... to Sophie Ellis-Bextor: Iconic track Murder on the Dancefloor rises in the Spotify charts as Gen Z discover singer after song was used in THAT full frontal scene
 - [https://www.dailymail.co.uk/news/article-12915875/saltburn-movie-sophie-ellis-bextor-murder-dancefloor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915875/saltburn-movie-sophie-ellis-bextor-murder-dancefloor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T09:26:06+00:00

The singer, 44, was beaten to the top spot by Daniel Bedingfield's Gotta Get Thru This when the track was originally released in 2001.

## Rohan Dennis: Harrowing new details emerge about what allegedly happened before world champion cyclist is accused of fatally striking his wife Melissa Hoskins with a ute
 - [https://www.dailymail.co.uk/news/article-12915905/Rohan-Dennis-Melissa-Hoskins-cyclist-new-details.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915905/Rohan-Dennis-Melissa-Hoskins-cyclist-new-details.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T08:34:25+00:00

Ms Hoskins was allegedly struck by a vehicle in Adelaide 's inner-north on Sunday, December 31. She was taken to the Royal Adelaide Hospital suffering serious injuries, and died hours later.

## Meadowbank fire: Man is fighting for life after suffering horrific burns in mysterious explosion at a penthouse apartment
 - [https://www.dailymail.co.uk/news/article-12915927/Meadowbank-apartment-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915927/Meadowbank-apartment-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T08:18:53+00:00

Emergency services raced to the apartment block on Angus St in Meadowbank at about 3:30pm on Monday after reports of a large fire breaking out through the penthouse apartment.

## Victims' Commissioner slams 'culture of disbelief' among police in sexual offence cases as forces see falling charge rates - with cases taking up to FIVE YEARS to get to court
 - [https://www.dailymail.co.uk/news/article-12849825/Victims-Commissioner-disbelief-police-sexual-offence-falling-charge-rates-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12849825/Victims-Commissioner-disbelief-police-sexual-offence-falling-charge-rates-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T08:14:51+00:00

Forces are seeing as few as 3.6 percent of recorded sexual offences, including rape, resulting in a charge or summons, latest data shows.

## Heartbreaking rollcall of women and girls 'killed by men' in 2023: From retired teacher, 83, Beatrice Corry murdered by her son to Emma Pattison and her daughter Lettie, Elianne Andam and Grace O'Malley-Kumar who all 'died at the hands of males'
 - [https://www.dailymail.co.uk/news/article-12799089/Heartbreaking-rollcall-women-girls-killed-men-2023-retired-teacher-83-Beatrice-Corry-murdered-son-Emma-Pattison-daughter-Lettie-Elianne-Andam-Grace-OMalley-Kumar-died-hands-males.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12799089/Heartbreaking-rollcall-women-girls-killed-men-2023-retired-teacher-83-Beatrice-Corry-murdered-son-Emma-Pattison-daughter-Lettie-Elianne-Andam-Grace-OMalley-Kumar-died-hands-males.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T08:12:15+00:00

The 99 women include head of Epsom College Emma Pattison, teenager Elianne Andam , student Grace O'Malley-Kumar and mother-of-four Alison Bowen.

## Female driver, 30, allegedly leads police on a wild pursuit in south-west Sydney hitting EIGHT cars and injuring a cop before she was brought to a stop
 - [https://www.dailymail.co.uk/news/article-12915829/Female-driver-police-chase-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915829/Female-driver-police-chase-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T08:09:35+00:00

The 30-year-old woman was allegedly seen speeding in a grey Mazda 3 along the Hume Highway at Pheasant's Nest, southwest of Sydney , at 10:30am on Monday.

## Bindarrah: Two workers killed in freak crash between a truck and a train are identified - as the man behind the wheel of the heavy vehicle is charged
 - [https://www.dailymail.co.uk/news/article-12915865/Bindarrah-truck-train-crash-two-killed-identified-killed-freak-crash-truck-train-identified.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915865/Bindarrah-truck-train-crash-two-killed-identified-killed-freak-crash-truck-train-identified.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T08:06:41+00:00

Train drivers Kevin Baker, 57, and Mick Warren, 48, both from Port Augusta, have been identified as two men killed on Sunday when a train collided with a truck, as a man is charged over the incident.

## Florida dive team claims it's finally solved mystery of Orlando woman, 47, who vanished 11 YEARS AGO while driving home from McDonald's date with a man she met on SpeedDate.com - as they discover van at the bottom of a pond near Disney World
 - [https://www.dailymail.co.uk/news/article-12915843/Florida-dive-team-Sandra-Lemire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915843/Florida-dive-team-Sandra-Lemire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T07:30:22+00:00

A Florida-based search team claims to have found the body Sandra Lemire, a mother of three who went missing over a decade years ago after meeting up with a man she met online.

## President Biden claims the US is in a better position than any country in the world - despite migrant crisis, crime and a struggling economy - as he speaks to Ryan Seacrest via satellite from a beach holiday St Croix
 - [https://www.dailymail.co.uk/news/article-12915849/President-Biden-claims-better-position-country-world-despite-migrant-crisis-crime-struggling-economy-speaks-Ryan-Seacrest-satellite-beach-holiday-St-Croix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915849/President-Biden-claims-better-position-country-world-despite-migrant-crisis-crime-struggling-economy-speaks-Ryan-Seacrest-satellite-beach-holiday-St-Croix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T07:19:06+00:00

President Joe Biden and First Lady Jill Biden said America is better positioned to lead the world than any other country and dished on his holiday meals in a New Years Eve interview.

## Colorado Republican Lauren Boebert says she was forced to switch congressional districts because Ryan Reynolds and Barbra Streisand are donating money to her Democratic opponent
 - [https://www.dailymail.co.uk/news/article-12915861/Colorado-Lauren-Boebert-barbra-streisand-ryan-reynolds-adam-frisch-maga.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915861/Colorado-Lauren-Boebert-barbra-streisand-ryan-reynolds-adam-frisch-maga.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T07:18:47+00:00

Maga firebrand left furious after her Democrat rival Adam Frisch had his $7.7million war chest swollen by $1,500 from Streisand and $1,500 from Reynolds

## Glamorous teenage influencer Paris Ow-Yang's $150,000 battle after crashing her Mercedes into a parked van
 - [https://www.dailymail.co.uk/news/article-12915555/OnlyFans-Paris-Ow-Yang-car-crash-Mercedes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915555/OnlyFans-Paris-Ow-Yang-car-crash-Mercedes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T06:38:15+00:00

Paris Ow-Yang, 18, has become embroiled in a legal dispute over $150,000 she owes businessman Adam Troost, the owner of a van she crashed into while four times over the limit.

## Why would you even bother going? Alarming footage shows NYE crowds swarming train stations as Aussies complain about waiting FOUR HOURS to get home
 - [https://www.dailymail.co.uk/news/article-12915725/New-Years-Eve-crowds-train-station-NYE-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915725/New-Years-Eve-crowds-train-station-NYE-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T06:05:53+00:00

The Sydney train network was plunged into commuter chaos after tens of thousands of people waited hours to go home following New Years Eve celebrations in the city.

## Army veteran run over by EIGHT vehicles after falling from his motorcycle on his 26th birthday, as family questions how he was struck so many times: 'He's not a deer in the road, he is a human being'
 - [https://www.dailymail.co.uk/news/article-12915733/John-jack-dyer-paratrooper-motorcycle-eight-vehicles-Orlando-deer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915733/John-jack-dyer-paratrooper-motorcycle-eight-vehicles-Orlando-deer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T05:45:51+00:00

By the time Jack Dyer was found, he had been repeatedly struck by passing drivers, all seemingly unaware they had just hit a person, the Florida Highway Patrol (FHP) said.

## Massive cash boost for millions of Aussies - here's who's eligible
 - [https://www.dailymail.co.uk/news/article-12915453/Centrelink-cash-boost-Aussies-Youth-Allowance-austudy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915453/Centrelink-cash-boost-Aussies-Youth-Allowance-austudy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T05:33:52+00:00

Almost one million Australians have got a new year's present with an increase to social welfare support payments from January 1.

## PICTURED: Surfer killed by shark in Maui identified as 39-year-old Jason Carter: Victim was rushed to hospital by jet ski, but died from his injuries
 - [https://www.dailymail.co.uk/news/article-12915739/surfer-killed-shark-Maui-Jason-Carter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915739/surfer-killed-shark-Maui-Jason-Carter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T05:30:29+00:00

The Hawaii man killed Saturday in a fatal shark 'encounter' off the coast of Maui has been identified as 39-year-old Jason Carter.

## Field Day 2024: New Year's revellers let loose at the first summer music festival of the year sporting some very brazen and revealing outfits
 - [https://www.dailymail.co.uk/news/article-12915699/Field-Day-2024-New-Years-music-festival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915699/Field-Day-2024-New-Years-music-festival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T05:05:04+00:00

New Year's Day has kicked off for thousands of music lovers in Sydney as concert-goers flood the Domain in scantily-clad outfits for the annual Field Day festival.

## Major update after fisherman 'illegally speared' beloved Gus the groper leaving Cronulla locals fuming - as mystery surrounds what happened to the beloved fish
 - [https://www.dailymail.co.uk/news/article-12915575/Update-Cronulla-blue-groper-spear-fisherman-fined.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915575/Update-Cronulla-blue-groper-spear-fisherman-fined.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T05:02:12+00:00

A fisherman who illegally speared a beloved blue groper then proudly posed with the fish in his bloodied wetsuit has been questioned by police about his actions.

## Furious Aussies say the ABC should be dropped from broadcasting Sydney's NYE fireworks after the family-friendly 9pm event was hijacked by pro-Palestine slogan and angry Indigenous rap group 3%
 - [https://www.dailymail.co.uk/news/article-12915295/ABC-dropped-broadcasting-Sydneys-NYE-fireworks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915295/ABC-dropped-broadcasting-Sydneys-NYE-fireworks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T04:30:44+00:00

The ABC has been criticised in lieu of its coverage of New Year's Eve performances and firework displays watched by millions of Australians.

## 'Perfect American family': Neighbor of NY police officer who 'murdered wife and sons' before turning gun on himself describes his shock at the horrific massacre
 - [https://www.dailymail.co.uk/news/article-12915521/Neighbor-NY-police-officer-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915521/Neighbor-NY-police-officer-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T04:22:06+00:00

Neighbors of Sergeant Watson Morgan, 49, who is accused of shooting his wife and kids before turning the gun on himself, have described them as the 'perfect American family.'

## Another famous Aussie beach is trashed in shocking scenes reminiscent of Christmas Day mayhem
 - [https://www.dailymail.co.uk/news/article-12915643/Noosa-North-Shore-rubbish-Christmas-Bronte-Beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915643/Noosa-North-Shore-rubbish-Christmas-Bronte-Beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T04:12:22+00:00

Furious Aussie locals have lashed out at Aussie tourists for trashing a popular beach in Queensland after leaving a trail of destruction while camping over the Christmas break.

## How Aussies have entered the new year $30,000 poorer - but one group is set to be better off
 - [https://www.dailymail.co.uk/news/article-12915271/Apprentices-trainees-government-cash-splash-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915271/Apprentices-trainees-government-cash-splash-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T04:06:13+00:00

The Albanese government has today announced a new package to alleviate pressures on one group of people - new 'priority' apprentices and trainees.

## Oklahoma donut shop that was FIREBOMBED by homophobic neo-Nazi arsonist throws a drag party to celebrate his conviction
 - [https://www.dailymail.co.uk/news/article-12915531/Oklahoma-Donut-firebomb-coby-dale-green-lgbt-drag-tulsa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915531/Oklahoma-Donut-firebomb-coby-dale-green-lgbt-drag-tulsa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T03:48:36+00:00

The Donut Hole in Tulsa threw open its doors and handed out 700 free donuts on Saturday as neo-Nazi Coby Dale Green was convicted in a federal court for the hate crime in October last year.

## Anderson Cooper and Andy Cohen are back on the BOOZE as they break last year's prohibition and down tequila shots at New Year's Eve show in Times Square
 - [https://www.dailymail.co.uk/news/article-12915615/Anderson-Cooper-Andy-Cohen-shots-New-Years-Eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915615/Anderson-Cooper-Andy-Cohen-shots-New-Years-Eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T03:19:52+00:00

Anderson Cooper and Andy Cohen knocked back shots during CNN 's live New Year's Eve Show, just a year after the network banned on-air drinking during the festivities.

## Piper had just graduated from preschool when she was rushed to hospital. Her mother has shared an urgent warning after the five-year-old was struck by an illness common among older Australians
 - [https://www.dailymail.co.uk/news/article-12915097/Five-year-old-girl-Piper-stroke-preschool-graduation-Albury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915097/Five-year-old-girl-Piper-stroke-preschool-graduation-Albury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T02:47:09+00:00

A five-year-old girl who suffered a devastating stroke 40 minutes after her preschool graduation on December 18 has begun to make a 'miraculous' recovery.

## Mill Park explosion injures 15 people and leaves eight with serious burns after horror NYE celebration
 - [https://www.dailymail.co.uk/news/article-12915583/Mill-Park-explosion-injures-15-people-leaves-eight-burns-horror-NYE-celebration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915583/Mill-Park-explosion-injures-15-people-leaves-eight-burns-horror-NYE-celebration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T02:35:41+00:00

Almost a dozen people are in hospital after a fire exploded in the garden of a home in Mill Park, in Melbourne's northeast, at 11.10pm on Sunday.

## Business Secretary Kemi Badenoch tops Conservative poll to become the next Party leader after Rishi Sunak
 - [https://www.dailymail.co.uk/news/article-12915573/Kemi-Badenoch-Conservative-poll-leader.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915573/Kemi-Badenoch-Conservative-poll-leader.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T02:35:40+00:00

Kemi Badenoch is the favourite to become the next Tory Party leader, according to a poll of members.

## Pro-Palestine protesters march on midtown as NYPD steps up security in Times Square for New Year's Eve countdown
 - [https://www.dailymail.co.uk/news/article-12915609/Palestine-protesters-march-midtown-NYPD-steps-security-Times-Square-New-Years-Eve-countdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915609/Palestine-protesters-march-midtown-NYPD-steps-security-Times-Square-New-Years-Eve-countdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T02:34:10+00:00

Pro-Palestinian protesters are marching through New York City on New Years Eve after Mayor Eric Adams said he had the NYPD prepared to step up security ahead of the party in Times Square.

## Calls for compulsory eye tests for over-70s to carry on driving after the number of 90-year-olds with driving licences DOUBLES in the last decade
 - [https://www.dailymail.co.uk/news/article-12915571/Calls-compulsory-eye-tests-70s-carry-driving.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915571/Calls-compulsory-eye-tests-70s-carry-driving.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T02:32:27+00:00

The Department for Transport said the over-70s must renew licences every three years and reveal if a medical condition affects their driving ability.

## Campaigners demand cheap social tariff on energy for struggling households as bills are set to rise 5%
 - [https://www.dailymail.co.uk/news/article-12915557/Campaigners-demand-cheap-social-tariff-energy-struggling-households.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915557/Campaigners-demand-cheap-social-tariff-energy-struggling-households.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T02:30:36+00:00

Consumer and anti-poverty groups say long-term reform of bills is required through the introduction of a social tariff for low income households.

## Major update after Aussie father was left fighting for life following moped accident in Bali
 - [https://www.dailymail.co.uk/news/article-12915563/update-Aussie-tourist-fighting-life-Bali-moped-Kevin-Malligan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915563/update-Aussie-tourist-fighting-life-Bali-moped-Kevin-Malligan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T02:21:41+00:00

There has been a major update in the case of Australian man Kevin Malligan, who is fighting for his life after he fell off a moped while on holiday in Bali.

## New Year rush to join the gym? It's better to wait until spring if you really want to work on your fitness
 - [https://www.dailymail.co.uk/news/article-12915529/New-Year-rush-join-gym-better-wait-spring-really-want-work-fitness.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915529/New-Year-rush-join-gym-better-wait-spring-really-want-work-fitness.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T02:20:15+00:00

A study of more than 1,700 people who signed up for a year's gym membership found they were more likely to stick to exercising if they joined in either the spring or autumn.

## Prince Philip 'pulled strings' for Haile Selassie when the Emperor of Ethiopia wanted his wayward grandson to go to Gordonstoun school
 - [https://www.dailymail.co.uk/news/article-12915619/Prince-Philip-Haile-Selassie-Emperor-Ethiopia-Gordonstoun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915619/Prince-Philip-Haile-Selassie-Emperor-Ethiopia-Gordonstoun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T02:07:53+00:00

Philip attended the boarding school in Moray in the 1930s and forged a friendship with the emperor during a state visit to Britain in 1954.

## Have a good Un (unless you're American)! Kim Jong Un attends new year celebrations in North Korea and delivers fresh diatribe against the US as he vows to step up weapons tests in 2024
 - [https://www.dailymail.co.uk/news/article-12915505/Have-good-unless-youre-American-Kim-Jong-attends-new-year-celebrations-North-Korea-delivers-fresh-diatribe-against-vows-step-weapons-tests-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915505/Have-good-unless-youre-American-Kim-Jong-attends-new-year-celebrations-North-Korea-delivers-fresh-diatribe-against-vows-step-weapons-tests-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T01:33:50+00:00

Throughout his ramble he vowed to launch three additional military spy satellites, produce more nuclear materials and introduce attack drones.

## Finance chief of Daily Telegraph's parent group is set to quit amid UAE deal to buy the newspaper
 - [https://www.dailymail.co.uk/news/article-12915559/Finance-chief-Telegraph-Cormac-Oshea-quit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915559/Finance-chief-Telegraph-Cormac-Oshea-quit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T01:32:10+00:00

The finance chief of the Daily Telegraph's parent company is set to quit, as an investigation into the planned acquisition of the newspaper by an Abu Dhabi-backed consortium continues.

## Hundreds of thousands of people crowd into NYC's Times Square to celebrate the New Year Eve countdown - as man reveals how he pees his pants while waiting in line
 - [https://www.dailymail.co.uk/news/article-12915375/Crowds-gather-Times-Square-New-Years-Eve-countdown-man-reveals-pees-pants-waiting-line.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915375/Crowds-gather-Times-Square-New-Years-Eve-countdown-man-reveals-pees-pants-waiting-line.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T01:29:26+00:00

Hundreds of thousands of people have gathered in Times Square as the New Years Eve countdown begins.

## New Year's Eve Melbourne: Woman risks losing her eye after she is hit by an illegal firework
 - [https://www.dailymail.co.uk/news/article-12915501/Melbourne-Woman-risks-losing-eye-illegal-firework.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915501/Melbourne-Woman-risks-losing-eye-illegal-firework.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T01:26:12+00:00

A woman could lose her eye after she was hit in the face by a firework while on a Melbourne beach celebrating the new year.

## Wild Aussie act as NYE revellers strip down and race to Bondi Beach to catch the first sunrise of 2024
 - [https://www.dailymail.co.uk/news/article-12915377/New-Years-Eve-Bondi-Beach-wild-NYE-act-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915377/New-Years-Eve-Bondi-Beach-wild-NYE-act-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T01:10:39+00:00

Sydneysiders have marked the start of 2024 with a very early morning dip at the city's most iconic beach after a night of wild celebrations.

## Ohio woman Brittany Watts, 33, speaks out after she was charged with felony abuse of a corpse following miscarriage
 - [https://www.dailymail.co.uk/news/article-12915285/Brittany-Watts-felony-abuse-corpse-miscarriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915285/Brittany-Watts-felony-abuse-corpse-miscarriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:48:36+00:00

The 33-year-old was charged with gross abuse of a corpse, a fifth-degree felony, after she suffered a miscarriage at home and attempted to flush the fetus down the toilet.

## Cheerleaders from Blair to Clegg told us joining the euro was the road to riches... Now we know it would have shackled us to a sclerotic project to form an EU superstate
 - [https://www.dailymail.co.uk/news/article-12915341/Cheerleaders-Blair-Clegg-told-joining-euro-road-riches-know-shackled-sclerotic-project-form-EU-superstate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915341/Cheerleaders-Blair-Clegg-told-joining-euro-road-riches-know-shackled-sclerotic-project-form-EU-superstate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:30:06+00:00

Judged by economic criteria, the single currency must be reckoned a failure. Perhaps not the disaster some of its opponents predicted but in no conceivable sense a success.

## World champion cyclist Rohan Dennis' haunting Instagram post just days before he allegedly hit and killed his Olympian wife Melissa Hoskins with his ute on their quiet Adelaide street
 - [https://www.dailymail.co.uk/news/article-12915085/Rohan-Dennis-Instagram-post-charged-wife-Melissa-Hoskins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915085/Rohan-Dennis-Instagram-post-charged-wife-Melissa-Hoskins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:29:53+00:00

Four days before he allegedly struck and killed his wife in their quiet family street, champion cyclist Rohan  Dennis posted a photo of them and their two children in front of a Christmas tree.

## Colorado mom Kimberlee Singler, 35, suspected of murdering two of her kids is arrested in the UK nearly two weeks after horrific killings
 - [https://www.dailymail.co.uk/news/article-12915455/Kimberlee-Singler-arrested-United-Kingdom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915455/Kimberlee-Singler-arrested-United-Kingdom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:29:50+00:00

Kimberlee Singler, the Colorado mother who allegedly killed two of her children and was on the run has been taken into the custody thousands of miles away in the United Kingdom.

## Bindarrah truck crash: Heavy vehicle driver charged over train collision that killed two people in South Australia
 - [https://www.dailymail.co.uk/news/article-12915349/Bindarrah-truck-crash-Heavy-vehicle-driver-charged-train-collision-killed-two-people-South-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915349/Bindarrah-truck-crash-Heavy-vehicle-driver-charged-train-collision-killed-two-people-South-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:27:44+00:00

A Pacific National freight train crashed with a truck at Bindarrah in South Australia on Sunday morning, about 30km west of the NSW border.

## This is why 2024 will be a good year for social workers, quantity surveyors and cyber security managers
 - [https://www.dailymail.co.uk/news/article-12915291/This-2024-good-year-social-workers-quantity-surveyors-cyber-security-managers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915291/This-2024-good-year-social-workers-quantity-surveyors-cyber-security-managers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:27:13+00:00

Hays said the roles will also command above average pay, adding that its research suggests half of workers intend to look for a new job in 2024.

## The year GoFundMe campaigns came unstuck - and what the crowdfunding platform is doing about it after pleas that tugged at Aussies' heart-strings were NOT all they seemed
 - [https://www.dailymail.co.uk/news/article-12862213/GoFundMe-campaigns-Australia-donations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12862213/GoFundMe-campaigns-Australia-donations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:25:10+00:00

Daily Mail Australia chronicles several online fundraisers that initially tugged at Aussies' heart-strings this year: yet, on closer inspection, were perhaps not all that they seemed.

## Back to full strength! Cheese company that 'castrated' the Cerne Abbas Giant of his 35ft manhood reinstates the historic pecker on its vintage cheddar packaging
 - [https://www.dailymail.co.uk/news/article-12915419/Back-strength-Cheese-company-castrated-Cerne-Abbas-Giant-35ft-manhood-reinstates-historic-pecker-vintage-cheddar-packaging.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915419/Back-strength-Cheese-company-castrated-Cerne-Abbas-Giant-35ft-manhood-reinstates-historic-pecker-vintage-cheddar-packaging.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:17:46+00:00

A cheese company accused of 'castrating' the Cerne Abbas Giant has now reinstated the iconic chalk figure's manhood on their packaging.

## Former Biden head of nuclear waste policy Sam Brinton ends 2023 a FREE person after being accused of stealing women's clothing from airport suitcases
 - [https://www.dailymail.co.uk/news/article-12915165/Sam-Brinton-Biden-official-free-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915165/Sam-Brinton-Biden-official-free-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:14:28+00:00

Despite facing a series of theft charges related to stealing airport luggage, nonbinary former Biden administration official Sam Brinton ends his 2023 a free person.

## Massive demand for weight loss jab is 'driven by women going through menopause and perimenopause'
 - [https://www.dailymail.co.uk/news/article-12915017/Demand-weight-loss-jab-women-menopause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915017/Demand-weight-loss-jab-women-menopause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:10:43+00:00

Trials of appetite-suppressant drugs such as Wegovy have seen people lose up to 20 per cent of their body weight. This has resulted in 'thousands-long' waiting lists with private providers.

## Town centres collapse as more than 10,000 shops are lost in 2023 - leaving a gaping black hole at the heart of communities across the nation
 - [https://www.dailymail.co.uk/news/article-12915045/Town-centres-collapse-shops-lost-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915045/Town-centres-collapse-shops-lost-2023.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:08:50+00:00

Experts have said the collapse of retailers in 2023 was moderated by the fact that several of the most poorly-run businesses failed in previous years.

## Gender change loophole on UK passports is revealed: Ministers' fears over 'self-identification' after it emerges that official documents can be altered with just a doctor's note
 - [https://www.dailymail.co.uk/news/article-12915183/Gender-change-loophole-UK-passports-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915183/Gender-change-loophole-UK-passports-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:07:29+00:00

The Mail understands equalities minister Kemi Badenoch is 'keenly aware' of the issue. She raised it with Suella Braverman and recently wrote to James Cleverly to check on progress.

## Kentucky man charged with rape, sodomy and strangulation after stashing a teen girl inside trap door hidden under a rug claims he was simply HELPING the girl after her grandma kicked her out of the house
 - [https://www.dailymail.co.uk/news/article-12915209/Kentucky-man-teen-hidden-trap-door.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915209/Kentucky-man-teen-hidden-trap-door.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-01T00:06:17+00:00

Zackary Jones, 34, was arrested after a missing 16-year-old girl from North Carolina was found inside a trap door at his house on Christmas Day after his mother called the cops.

