# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## This Youtuber is Finally Taking A Break
 - [https://www.youtube.com/watch?v=ICJVyhfXnB0](https://www.youtube.com/watch?v=ICJVyhfXnB0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-01-01T20:45:00+00:00

This is the greatest break of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/?ref=moist

## Top 5 Worst Movies of 2023
 - [https://www.youtube.com/watch?v=eTCbX8zixL8](https://www.youtube.com/watch?v=eTCbX8zixL8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2024-01-01T02:30:13+00:00

This is the greatest bad movie year of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/?ref=moist

