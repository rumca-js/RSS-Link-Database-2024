# Source:Times of India, URL:https://timesofindia.indiatimes.com/rssfeedstopstories.cms, language:en-gb

## Amid Covid surge, Leh admin makes masks compulsory in public places
 - [https://timesofindia.indiatimes.com/india/amid-covid-surge-leh-admin-makes-masks-compulsory-in-public-places/articleshow/106460917.cms](https://timesofindia.indiatimes.com/india/amid-covid-surge-leh-admin-makes-masks-compulsory-in-public-places/articleshow/106460917.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T22:35:27+00:00



## India, Pak exchange lists of N-installations and prisoners
 - [https://timesofindia.indiatimes.com/india/india-pakistan-exchange-lists-of-n-installations-and-prisoners/articleshow/106460909.cms](https://timesofindia.indiatimes.com/india/india-pakistan-exchange-lists-of-n-installations-and-prisoners/articleshow/106460909.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T22:35:08+00:00

The customary exchange of lists of prisoners and fishermen between India and Pakistan on the first day of the new year took place on Monday with India calling for early release and repatriation of civilian prisoners, missing Indian defence personnel, and fishermen along with their boats, from Pakistan's custody. In this context, Pakistan was asked to expedite the release and repatriation of 184 Indian fishermen, who have completed their sentence, the government said. Under the provisions of the 2008 Agreement on Consular Access, such lists are exchanged every year on January 1 and July 1.

## HP govt issues notification to give ST status to Hattee community
 - [https://timesofindia.indiatimes.com/india/himachal-govt-issues-notification-to-give-st-status-to-hattee-community/articleshow/106460825.cms](https://timesofindia.indiatimes.com/india/himachal-govt-issues-notification-to-give-st-status-to-hattee-community/articleshow/106460825.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T22:32:06+00:00

The Himachal Pradesh government issued a notification granting Scheduled Tribe status to the Hattee community of Trans-Giri area in Sirmaur district. This decision was delayed due to the state government seeking clarification on the Constitution (Scheduled Tribes) Order. The Hattee community had been demanding ST status similar to the Jaunsar-Bawar area in Uttarakhand. The community expressed gratitude to CM Sukhvinder Singh Sukhu for issuing the notification. Jai Ram Thakur, the leader of the opposition, highlighted the delay in granting the Hattee community tribal status.

## 'Maha must decide on notifying casino law'
 - [https://timesofindia.indiatimes.com/india/maha-must-decide-on-notifying-casino-law/articleshow/106460564.cms](https://timesofindia.indiatimes.com/india/maha-must-decide-on-notifying-casino-law/articleshow/106460564.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T22:21:59+00:00



## Retired army officer charred to death in UP
 - [https://timesofindia.indiatimes.com/india/retired-army-officer-charred-to-death-in-up/articleshow/106460561.cms](https://timesofindia.indiatimes.com/india/retired-army-officer-charred-to-death-in-up/articleshow/106460561.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T22:21:48+00:00



## Cop held after woman found dead in his house
 - [https://timesofindia.indiatimes.com/india/cop-held-after-woman-found-dead-in-his-house/articleshow/106460556.cms](https://timesofindia.indiatimes.com/india/cop-held-after-woman-found-dead-in-his-house/articleshow/106460556.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T22:21:40+00:00



## Rape survivor forced to compromise, thrown off car
 - [https://timesofindia.indiatimes.com/india/rape-survivor-forced-to-compromise-thrown-off-car/articleshow/106460483.cms](https://timesofindia.indiatimes.com/india/rape-survivor-forced-to-compromise-thrown-off-car/articleshow/106460483.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T22:18:46+00:00



## Winter wildfires surge in Uttarakhand , 1000+ alerts received
 - [https://timesofindia.indiatimes.com/india/winter-wildfires-surge-in-uttarakhand-1000-alerts-received/articleshow/106460041.cms](https://timesofindia.indiatimes.com/india/winter-wildfires-surge-in-uttarakhand-1000-alerts-received/articleshow/106460041.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T21:56:43+00:00

Uttarakhand witnesses rise in winter wildfires, with Forest Survey of India sending 1006 fire alerts between November 1 and January 1. Fires reported across districts including Uttarkashi, Nainital, Bageshwar, Tehri, Dehradun, Pithoragarh, Pauri, and Almora. Concerns raised about increased human-wildlife conflicts as animals try to escape flames. Wildlife conservationists link fires to illegal activities. Reasons for fire surge include controlled burning, agricultural residue burning, waste burning, and forest clearing.  Villagers expressed concern, citing the absence of rainfall or snow in the last three months, making the region dry.

## Pastor held over 'role in conversion & black magic'
 - [https://timesofindia.indiatimes.com/india/pastor-held-over-role-in-conversion-black-magic/articleshow/106460029.cms](https://timesofindia.indiatimes.com/india/pastor-held-over-role-in-conversion-black-magic/articleshow/106460029.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T21:49:50+00:00

A controversial Goa pastor, Domnic D'Souza, was arrested Monday for alleged involvement in conversion and black magic. The action followed a complaint by a Tamil Nadu man who accused the pastor of denying him entry into his Five Pillars Church at Sodiem in Goa's Siolim and trying to convert him. D'Souza was arrested earlier in another case of alleged "forcible conversions" in May 2022 before being let out on bail. "We have registered cases against D'Souza, his wife Joan and some others, all attached to Five Pillars Church," said Mapusa DSP Jivba Dalvi.

## As prices fall, government may lift ban on onion export
 - [https://timesofindia.indiatimes.com/india/as-prices-fall-government-may-lift-ban-on-onion-export/articleshow/106460028.cms](https://timesofindia.indiatimes.com/india/as-prices-fall-government-may-lift-ban-on-onion-export/articleshow/106460028.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T21:48:58+00:00

The government intervention of procuring kharif onion and disposing them of simultaneously have brought down average retail prices by 30% and wholesale prices by 35% in the past one month. Considering the trend of decline in prices and the short shelf life of the summer crop, the government may look at the option of lifting the export ban in a calibrated manner, officials said. Sources in the onion trade said that they have been informed by government functionaries that the Centre would allow export by government cooperatives.

## Maoist-forces crossfire claims life of 6-mth-old
 - [https://timesofindia.indiatimes.com/india/maoist-forces-crossfire-claims-life-of-6-mth-old/articleshow/106460021.cms](https://timesofindia.indiatimes.com/india/maoist-forces-crossfire-claims-life-of-6-mth-old/articleshow/106460021.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T21:45:56+00:00

A six-month-old baby was killed and her mother injured during an encounter between security forces and Maoists in Bijapur district, Chhattisgarh. The gun battle took place at Mutvandi village in a forest region, around 45 km from Bijapur town. The forces went on an operation in the forests of Gangaloor, based on specific intelligence about the presence of Chandranna and Mangli, Maoist leaders. The mother and child were caught in the crossfire, and the security forces had to retreat after two personnel were injured.

## 'One Nation-One Pass' launched for smooth transit of forest produce
 - [https://timesofindia.indiatimes.com/india/one-nation-one-pass-launched-for-smooth-transit-of-forest-produce/articleshow/106459814.cms](https://timesofindia.indiatimes.com/india/one-nation-one-pass-launched-for-smooth-transit-of-forest-produce/articleshow/106459814.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T21:28:27+00:00



## Centre lists Goldy Brar as terrorist under UAPA
 - [https://timesofindia.indiatimes.com/india/centre-lists-goldy-brar-as-terrorist-under-uapa/articleshow/106459771.cms](https://timesofindia.indiatimes.com/india/centre-lists-goldy-brar-as-terrorist-under-uapa/articleshow/106459771.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T20:46:56+00:00

The Centre on Monday listed Canada-based Babbar Khalsa International (BKI) operative and gangster Satwinder Singh alias Goldy Brar, accused in cases relating to extortion and targeted killings in Punjab and smuggling of high-grade arms, ammunition and explosive materials via drones from across India’s western border for such killings, as a ‘terrorist’ in the Fourth Schedule to the Unlawful Activities (Prevention) Act, 1967 (UAPA). Goldy is closely associated with gangster Lawrence Bishnoi and also has links with BKI operative Lakhbir Singh alias Landa.

## New national cooperation policy to come up this month
 - [https://timesofindia.indiatimes.com/india/new-national-cooperation-policy-to-come-up-this-month/articleshow/106459753.cms](https://timesofindia.indiatimes.com/india/new-national-cooperation-policy-to-come-up-this-month/articleshow/106459753.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T20:39:45+00:00

India will introduce a new national cooperation policy this month to strengthen the cooperative movement at the grassroots level. The policy aims to promote cooperative-based economic development through a legal and institutional framework. It will focus on creating vibrant economic entities, modernizing them with technology, expanding into export markets, and providing a level-playing field through incentives and capital infusion. The policy may propose the establishment of a National Cooperative Tribunal and a National Board for Cooperatives, as well as a National Cooperative Bank of India.

## Govt 'weaponising tech' to exclude poor, says Congress
 - [https://timesofindia.indiatimes.com/india/govt-weaponising-tech-to-exclude-poor-says-congress/articleshow/106459731.cms](https://timesofindia.indiatimes.com/india/govt-weaponising-tech-to-exclude-poor-says-congress/articleshow/106459731.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T20:29:41+00:00



## Truckers protest 10-year jail for hit-and-run cases
 - [https://timesofindia.indiatimes.com/india/truckers-protest-10-year-jail-for-hit-and-run-cases/articleshow/106459730.cms](https://timesofindia.indiatimes.com/india/truckers-protest-10-year-jail-for-hit-and-run-cases/articleshow/106459730.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T20:29:27+00:00

Truck and bus drivers are protesting against the provision of up to 10 years jail for hit-and-run cases. The protests are happening across some states. Truckers and transporters organizations are appealing to the Centre to address the issue before it escalates. The largest truckers' body, AIMTC, has written to the prime minister and the home minister expressing their concerns. The provision in the new law has become a cause of concern for truck drivers. Trucks have been stranded in Gujarat, Maharashtra, Madhya Pradesh, Uttar Pradesh, Odisha and Rajasthan.

## Visit Ayodhya...it will make you recollect Tretayuga: Yogi Adityanath
 - [https://timesofindia.indiatimes.com/india/visit-ayodhya-it-will-make-you-recollect-tretayuga-yogi/articleshow/106459728.cms](https://timesofindia.indiatimes.com/india/visit-ayodhya-it-will-make-you-recollect-tretayuga-yogi/articleshow/106459728.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T20:29:13+00:00



## RJD's 'temple means mental slavery' poster triggers row
 - [https://timesofindia.indiatimes.com/india/rjds-temple-means-mental-slavery-poster-triggers-row/articleshow/106459723.cms](https://timesofindia.indiatimes.com/india/rjds-temple-means-mental-slavery-poster-triggers-row/articleshow/106459723.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T20:24:44+00:00

A controversial poster criticizing temples, equating them with superstition, idiocy, and ignorance, surfaced outside the residence of RJD chief Lalu Prasad's wife Rabri Devi. The poster features the photograph of RJD MLA Fateh Bahadur Singh and prominent party leaders. It drew criticism from the BJP and JD(U) in Bihar ahead of the inauguration of the Ram temple in Ayodhya. The BJP called RJD "anti-Sanatan" and emphasized that the Ram temple symbolizes the faith of the nation. RJD MP Manoj Jha criticized BJP for using the temple card for political gain.

## VHP writes to UP police over racket duping devotees
 - [https://timesofindia.indiatimes.com/india/vhp-writes-to-up-police-over-racket-duping-devotees/articleshow/106459699.cms](https://timesofindia.indiatimes.com/india/vhp-writes-to-up-police-over-racket-duping-devotees/articleshow/106459699.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T20:18:18+00:00



## Trust members selected Ram Lalla idol on December 29
 - [https://timesofindia.indiatimes.com/india/trust-members-selected-ram-lalla-idol-on-december-29/articleshow/106459670.cms](https://timesofindia.indiatimes.com/india/trust-members-selected-ram-lalla-idol-on-december-29/articleshow/106459670.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T20:13:43+00:00

The idol of Ram Lalla for the Ayodhya Ram temple was selected on December 29 through a voting process. The chosen idol will be revealed to the public on January 17 during the 'nagar yatra'. No photographs or videos of the idol will be released until then. The idol will be 'blindfolded' during the 'nagar yatra'. The consecration ceremony will begin on January 22 at 12.20pm, and everyone is encouraged to perform aarti, distribute prasad, and light lamps after sunset.

## Uttarakhand bans agri land purchase by 'outsiders'
 - [https://timesofindia.indiatimes.com/india/uttarakhand-bans-agri-land-purchase-by-outsiders/articleshow/106459646.cms](https://timesofindia.indiatimes.com/india/uttarakhand-bans-agri-land-purchase-by-outsiders/articleshow/106459646.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T20:07:44+00:00

The purchase of agricultural and horticulture land by people of other states has been banned in Uttarakhand until a five-member committee submits its final report on new land laws. The committee, headed by additional chief secretary Radha Raturi, was instructed by Chief Minister Pushkar Singh Dhami to review the draft submitted by a committee led by former chief secretary Subhash Kumar in 2022. The committee will interact with people in different parts of the state and take suggestions from experts before presenting its final draft.

## After US, India 2nd country to send dedicated sat to study black holes
 - [https://timesofindia.indiatimes.com/india/after-us-india-second-country-to-send-dedicated-sat-to-study-black-holes/articleshow/106459602.cms](https://timesofindia.indiatimes.com/india/after-us-india-second-country-to-send-dedicated-sat-to-study-black-holes/articleshow/106459602.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T19:47:53+00:00

Isro ushered in the New Year with the successful launch of XPoSat (X-ray Polarimeter Satellite), India's first satellite to conduct research on black holes and other celestial objects. Workhorse PSLV placed the satellite on its 60th flight in a 650km orbit. The final stage of PSLV-C58 then turned into an orbital experimental module (POEM) to test the 10 payloads over the next month. Around 22 minutes after the lift-off from Satish Dhawan Space Centre in Sriharikota, the rocket injected XPoSat.

## Following, abusing a woman not offence of outraging modesty: HC
 - [https://timesofindia.indiatimes.com/india/following-abusing-a-woman-not-offence-of-outraging-modesty-high-court/articleshow/106459600.cms](https://timesofindia.indiatimes.com/india/following-abusing-a-woman-not-offence-of-outraging-modesty-high-court/articleshow/106459600.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T19:47:29+00:00

Following, abusing and pushing a woman might be "annoying" acts, but did not constitute the offence of outraging the modesty under IPC Section 354, the Nagpur bench of Bombay HC ruled, and granted relief to a man convicted by the judicial magistrate first class court at Wardha. Justice Anil Pansare acquitted the appellant, a 36-year-old labourer, saying the prosecution failed to prove its case beyond reasonable doubt. A college student had filed a police complaint against the man alleging that he had followed her a couple of times and abused her.

## Gunmen posing as cops kill 4 in Manipur; 6 hurt
 - [https://timesofindia.indiatimes.com/india/gunmen-posing-as-cops-kill-4-in-manipur-6-hurt/articleshow/106459594.cms](https://timesofindia.indiatimes.com/india/gunmen-posing-as-cops-kill-4-in-manipur-6-hurt/articleshow/106459594.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T19:45:37+00:00

Assailants posing as cops opened fire at a marketplace in Manipur's Thoubal district, resulting in four civilian deaths and injuries to six others. A village defense volunteer also died from a gunfight. The attack was linked to an extortion attempt. The state has declared a curfew in three districts. CM N Biren Singh appealed for peace and assured that the attackers will be caught. The attack at Lilong Chingjao came hours after Biren Singh, in a New Year message, expressed concern over the recent spike in violence.

## 2023 was 2nd warmest on record in the country since 1901: IMD
 - [https://timesofindia.indiatimes.com/india/2023-was-2nd-warmest-on-record-in-the-country-since-1901-says-imd/articleshow/106459573.cms](https://timesofindia.indiatimes.com/india/2023-was-2nd-warmest-on-record-in-the-country-since-1901-says-imd/articleshow/106459573.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T19:41:31+00:00

The year 2023 was the second warmest on record in India, with a temperature anomaly of 0.65°C above the long-term average. Thunderstorms and lightning caused over 50% of the 2,376 human casualties due to extreme weather events. Globally, 2023 was the warmest year on record, with a temperature anomaly of 1.40°C above the pre-industrial level. The India Meteorological Department attributed the high temperatures to El Nino conditions. Madhya Pradesh reported the highest number of casualties, followed by Uttar Pradesh.

## HC 'not inclined' to give Teesta relief in grave digging case
 - [https://timesofindia.indiatimes.com/india/high-court-not-inclined-to-give-teesta-relief-in-grave-digging-case/articleshow/106459572.cms](https://timesofindia.indiatimes.com/india/high-court-not-inclined-to-give-teesta-relief-in-grave-digging-case/articleshow/106459572.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T19:40:58+00:00

Gujarat high court on Monday indicated that looking at the record of social activist Teesta Setalvad, it was not inclined to grant her any relief in the Pandarwada mass grave digging case. Setalvad had filed a petition in court in 2017 after her name was included in an FIR in 2011 in connection with digging graves and exhuming 28 bodies from a mass burial site near Pandarwada in Panchmahal district in December 2005. The bodies were of those killed during the post-Godhra violence.

## Sky beckons: DGCA issues maximum pilot licences in 2023
 - [https://timesofindia.indiatimes.com/india/sky-beckons-dgca-issues-maximum-pilot-licences-in-2023/articleshow/106459549.cms](https://timesofindia.indiatimes.com/india/sky-beckons-dgca-issues-maximum-pilot-licences-in-2023/articleshow/106459549.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T19:35:19+00:00

India issued the highest ever number of commercial pilot licences (CPL) — 1,622 — last year, almost 40% more than 1,165 in 2022. Last year, 292 women got CPLs (18% of total issued) — 22% more than 2022, said an official of Directorate General of Civil Aviation (DGCA). While the number of CPLs issued by DGCA in the last decade has almost doubled — from 783 in 2013-14 to 1,622 last year, share of those going to women has nearly tripled — from 116 to 293 — in the same period.

## UK media focus on 'cows, curry and caste’ Brit Indians experience prejudice
 - [https://timesofindia.indiatimes.com/world/uk/british-indians-experiencing-prejudice-in-uk-due-to-uk-media-focus-on-cows-curry-and-caste/articleshow/106459358.cms](https://timesofindia.indiatimes.com/world/uk/british-indians-experiencing-prejudice-in-uk-due-to-uk-media-focus-on-cows-curry-and-caste/articleshow/106459358.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T19:24:53+00:00

A survey of the British Indian and Hindu community has found that many are experiencing prejudice owing to their misrepresentation in the UK media deriving from a "colonial" focus on “cows, curry and caste”. Fifty-nine per cent of survey participants said they had personally witnessed or experienced prejudice as a result of the British media reporting on Hindus and Hinduism and 79% said media reports on Hinduism had resulted in negative perceptions of British Indians. The nation wide survey was carried out among 2,061 respondents, by Insight UK, an organisation that represents British Hindu and Indian communities.

## Wrong to say collegium lacks transparency: CJI DY Chandrachud
 - [https://timesofindia.indiatimes.com/india/wrong-to-say-collegium-lacks-transparency-cji-dy-chandrachud/articleshow/106459500.cms](https://timesofindia.indiatimes.com/india/wrong-to-say-collegium-lacks-transparency-cji-dy-chandrachud/articleshow/106459500.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T19:22:38+00:00

Days after his retired colleague Justice SK Kaul said one has to accept that there is a problem with the collegium method of appointment of judges, Chief Justice of India D Y Chandrachud defended the system and said steps have been taken to ensure greater transparency. “To say that the collegium system is lacking in transparency would not be correct. We have taken steps to ensure that greater transparency is maintained. A sense of objectivity in the decision-making process is maintained,” the CJI said in an interview Monday.

## Israeli SC overturns Netanyahu's controversial law
 - [https://timesofindia.indiatimes.com/world/middle-east/israeli-supreme-court-strikes-down-netanyahus-contentious-judicial-overhaul/articleshow/106458907.cms](https://timesofindia.indiatimes.com/world/middle-east/israeli-supreme-court-strikes-down-netanyahus-contentious-judicial-overhaul/articleshow/106458907.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T17:57:41+00:00

Israel's Supreme Court on Monday struck down a key component of Prime Minister Benjamin Netanyahu's judicial overhaul. The court's 8-7 majority decision overturned a law enacted in July, a crucial element of Netanyahu's proposed justice system overhaul. The now-invalidated law aimed to prevent judges from overturning government decisions they deemed "unreasonable." Critics argued that this move by Netanyahu raised concerns about potential corruption and the improper appointment of unqualified individuals to key positions. Prime Minister Netanyahu has so far not commented on the Supreme Court’s ruling.

## Mamata vs Abhishek? Trinamool leaders engage in war of words
 - [https://timesofindia.indiatimes.com/india/old-guard-vs-young-turks-on-foundation-day-senior-trinamool-leaders-engage-in-open-war-of-words/articleshow/106458756.cms](https://timesofindia.indiatimes.com/india/old-guard-vs-young-turks-on-foundation-day-senior-trinamool-leaders-engage-in-open-war-of-words/articleshow/106458756.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T17:20:16+00:00



## '10 straight wins and then one bad day': Gavaskar sums up India's show in 2023
 - [https://timesofindia.indiatimes.com/sports/cricket/news/10-straight-wins-and-then-one-bad-day-sunil-gavaskar-sums-up-team-indias-outstanding-show-in-2023/articleshow/106458601.cms](https://timesofindia.indiatimes.com/sports/cricket/news/10-straight-wins-and-then-one-bad-day-sunil-gavaskar-sums-up-team-indias-outstanding-show-in-2023/articleshow/106458601.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T16:54:39+00:00

The Indian men's team lifted the Asia Cup trophy and secured the gold medal at the Hangzhou Asian Games. Despite these successes, the Rohit Sharma-led side faced defeats against Australia in both the World Test Championship (WTC) and the World Cup finals. The batting great also commended the women's team for their historic wins over England &amp; Australia. Under the captaincy of Harmanpreet Kaur, the women's team achieved notable success by defeating England and Australia in one-off Tests.

## People buried alive, houses destroyed: Japan earthquake leaves behind trail of destruction
 - [https://timesofindia.indiatimes.com/world/rest-of-world/people-buried-alive-houses-destroyed-powerful-japan-earthquake-leaves-behind-a-trail-of-destruction/articleshow/106458357.cms](https://timesofindia.indiatimes.com/world/rest-of-world/people-buried-alive-houses-destroyed-powerful-japan-earthquake-leaves-behind-a-trail-of-destruction/articleshow/106458357.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T16:40:35+00:00



## Three shot dead in Manipur, curfew reimposed in five districts
 - [https://timesofindia.indiatimes.com/india/three-shot-dead-in-manipur-curfew-reimposed-in-five-districts/articleshow/106458395.cms](https://timesofindia.indiatimes.com/india/three-shot-dead-in-manipur-curfew-reimposed-in-five-districts/articleshow/106458395.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T16:27:37+00:00



## Army, NDRF join op to rescue child stuck in borewell
 - [https://timesofindia.indiatimes.com/india/army-ndrf-join-ops-to-rescue-3-year-old-girl-stuck-in-borewell-in-gujarats-dwarka/articleshow/106458010.cms](https://timesofindia.indiatimes.com/india/army-ndrf-join-ops-to-rescue-3-year-old-girl-stuck-in-borewell-in-gujarats-dwarka/articleshow/106458010.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T15:42:42+00:00



## Hard landing in Dubai: AI derosters pilot & orders probe
 - [https://timesofindia.indiatimes.com/india/hard-landing-in-dubai-ai-off-rosters-pilot-orders-probe-a320-grounded-there-for-a-week/articleshow/106457826.cms](https://timesofindia.indiatimes.com/india/hard-landing-in-dubai-ai-off-rosters-pilot-orders-probe-a320-grounded-there-for-a-week/articleshow/106457826.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T15:18:32+00:00

An Air India flight made a very heavy landing in Dubai on December 20. Luckily for everyone onboard the relatively young 5.5-year-old Airbus A320neo (VT CIQ) did not suffer structural damage when it made the heavy landing (3.5 G) and came to a stop safely. The pilot has been removed from flying duties pending investigation. The plane remained grounded in Dubai for extensive checks for a week before being allowed to fly back to Air India's engineering base in Mumbai.

## 'Kohli, Sachin and...': Lyon names best players he has played against
 - [https://timesofindia.indiatimes.com/sports/cricket/news/virat-kohli-sachin-tendulkar-and-nathan-lyon-names-best-players-he-has-played-against/articleshow/106457717.cms](https://timesofindia.indiatimes.com/sports/cricket/news/virat-kohli-sachin-tendulkar-and-nathan-lyon-names-best-players-he-has-played-against/articleshow/106457717.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T15:07:34+00:00

Nathan Lyon, the 36-year-old Australian, is widely regarded as one of the premier off-spinners in the current cricket landscape, consistently troubling the world's top batters with his elusive spin. Recently, the seasoned veteran achieved a significant milestone by becoming the eighth bowler to reach 500 wickets in Test cricket. After outclassing some of the top batters, Lyon selected the best batsmen he has faced in his illustrious decade-long Test career. He also disclosed the strategies and tactics he employs to dismiss these players.

## 'More heads will roll': Xi goes full Stalin with purge in China
 - [https://timesofindia.indiatimes.com/world/china/xi-jinpings-surge-and-purge-what-it-means-for-china-and-world/articleshow/106457428.cms](https://timesofindia.indiatimes.com/world/china/xi-jinpings-surge-and-purge-what-it-means-for-china-and-world/articleshow/106457428.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T14:48:13+00:00

Chinese President Xi Jinping intensifies his purge of military and government officials, focusing on the People's Liberation Army (PLA). Last Friday, nine high-ranking military officers were dismissed from China's national legislative body, including former Rocket Force commander Li Yuchao. Ding Laihang, a former Air Force commander, and a naval officer were also expelled. This is the first instance of these military branches being affected in the recent personnel changes. The purge raises concerns about oversight of China's military investments as it competes with the US in critical areas like Taiwan and the South China Sea.

## Putin says he wants peace in Ukraine but ...
 - [https://timesofindia.indiatimes.com/world/europe/putin-says-he-wants-peace-in-ukraine-but-on-russias-terms/articleshow/106457166.cms](https://timesofindia.indiatimes.com/world/europe/putin-says-he-wants-peace-in-ukraine-but-on-russias-terms/articleshow/106457166.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T14:23:01+00:00



## 'We do not recognise ad-hoc panel and ministry suspension'
 - [https://timesofindia.indiatimes.com/sports/more-sports/wrestling/we-do-not-recognise-ad-hoc-panel-and-ministry-suspension-will-organise-wrestling-nationals-sanjay-singh/articleshow/106456530.cms](https://timesofindia.indiatimes.com/sports/more-sports/wrestling/we-do-not-recognise-ad-hoc-panel-and-ministry-suspension-will-organise-wrestling-nationals-sanjay-singh/articleshow/106456530.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T13:32:47+00:00

Indian wrestling teetered on the edge of a deeper crisis with Sanjay Singh, president of the suspended WFI, on Monday declaring that they will soon organise the national championships and insisting that they neither recognise the suspension of their newly-elected body by Sports Ministry nor the ad-hoc panel. Three days after the Wrestling Federation of India (WFI) held its polls, the sports ministry suspended the sports body citing several violations of rules on December 24.

## 'Decision based on law': CJI on criticism over Article 370 verdict
 - [https://timesofindia.indiatimes.com/india/decision-based-on-law-cji-chandrachud-responds-to-criticism-over-judgment-on-scrapping-article-370/articleshow/106456171.cms](https://timesofindia.indiatimes.com/india/decision-based-on-law-cji-chandrachud-responds-to-criticism-over-judgment-on-scrapping-article-370/articleshow/106456171.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T13:17:19+00:00

Chief Justice of India DY Chandrachud chooses not to escalate the controversy surrounding the Supreme Court's unanimous decision on Article 370. He emphasizes that judges base their decisions on the Constitution and the law. Chandrachud refrains from responding to criticism and asserts that the rationale behind the decision is encapsulated in the signed judgment. He also addresses the ruling on same-sex marriages, highlighting the judicial detachment from case outcomes and expressing a lack of regret regarding being part of the majority or minority in various cases.

## What will happen to Aditya-L1 if final firing is not done?
 - [https://timesofindia.indiatimes.com/india/sun-mission-isro-chief-explains-what-will-happen-to-aditya-l1-if-final-firing-is-not-done-on-jan-6/articleshow/106455966.cms](https://timesofindia.indiatimes.com/india/sun-mission-isro-chief-explains-what-will-happen-to-aditya-l1-if-final-firing-is-not-done-on-jan-6/articleshow/106455966.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T12:54:24+00:00

Once it reaches its final destination, the spacecraft will be able to view the Sun without interruptions from any eclipses.

## 'I've got no regrets': Warner on ball-tampering scandal
 - [https://timesofindia.indiatimes.com/sports/cricket/news/ive-got-no-regrets-and-moved-on-from-lifetime-captaincy-ban-david-warner-on-ball-tampering-scandal/articleshow/106455720.cms](https://timesofindia.indiatimes.com/sports/cricket/news/ive-got-no-regrets-and-moved-on-from-lifetime-captaincy-ban-david-warner-on-ball-tampering-scandal/articleshow/106455720.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T12:40:39+00:00

The lifetime leadership ban was meted out to David Warner after his teammate Cameron Bancroft was found with sandpaper in his trouser pocket, leading to Australia's admission of ball-tampering during the Cape Town Test against South Africa in 2018. Notably, of the three cricketers penalised—captain Steve Smith and Bancroft being the other two—Warner received the most severe punishment. Warner also revealed that he was prepared to retire from Tests after 2nd match of 2023 Ashes series at Lord's if he had not scored runs.

## Printing 'date of mfg', 'unit sale price' on pkg items mandatory
 - [https://timesofindia.indiatimes.com/business/india-business/printing-date-of-manufacturing-unit-sale-price-on-packaged-items-becomes-mandatory-from-january-1/articleshow/106455240.cms](https://timesofindia.indiatimes.com/business/india-business/printing-date-of-manufacturing-unit-sale-price-on-packaged-items-becomes-mandatory-from-january-1/articleshow/106455240.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T12:10:44+00:00

Printing the 'date of manufacturing' and 'unit sale price' has become mandatory on all packaged commodities. Earlier, companies had the option to print the 'date of manufacturing' or 'date of import' or date of packaging. Now, companies must print only the 'date of manufacturing' and the 'unit sale price', as per the latest notification by the consumer affairs ministry. This helps consumers know the age of the item and make informed decisions. It also makes it easier for consumers to understand the cost per unit.

## Canada-based gangster Goldy Brar designated a terrorist
 - [https://timesofindia.indiatimes.com/india/goldy-brar-designated-terrorist-under-anti-terror-law-uapa-centre/articleshow/106455223.cms](https://timesofindia.indiatimes.com/india/goldy-brar-designated-terrorist-under-anti-terror-law-uapa-centre/articleshow/106455223.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T12:10:07+00:00



## 'If I was NZ, I wouldn't even...': Waugh slams SA for naming depleted squad
 - [https://timesofindia.indiatimes.com/sports/cricket/news/if-i-was-new-zealand-i-wouldnt-even-steve-waugh-slams-sa-for-naming-depleted-test-squad/articleshow/106454953.cms](https://timesofindia.indiatimes.com/sports/cricket/news/if-i-was-new-zealand-i-wouldnt-even-steve-waugh-slams-sa-for-naming-depleted-test-squad/articleshow/106454953.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T11:59:14+00:00

Former Australia skipper Steve Waugh has slammed the International Cricket Council and top cricket boards, including the BCCI, for not caring about Test cricket after South Africa named a depleted red-ball squad for the tour of New Zealand, prioritising its T20 league over the longest format.

## 'No confusion ... ': Supriya Sule on seat sharing between MVA partners
 - [https://timesofindia.indiatimes.com/india/no-confusion-ncps-supriya-sule-on-seat-sharing-between-mva-partners-in-maharashtra/articleshow/106454598.cms](https://timesofindia.indiatimes.com/india/no-confusion-ncps-supriya-sule-on-seat-sharing-between-mva-partners-in-maharashtra/articleshow/106454598.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T11:47:13+00:00

NCP MP Supriya Sule has said that the Maha Vikas Aghadi partners - the Congress, the Nationalist Congress Party, and the Shiv Sena (UBT) - have agreed upon a seat-sharing formula for the 2024 Lok Sabha elections in Maharashtra. Sule said that a meeting between Sonia Gandhi, Uddhav Thackeray, and Sharad Pawar was held last week in which a broad formula was agreed upon. There was unease among MVA partners after Shiv Sena (UBT) leader Sanjay Raut's remarks last week staked claim to 23 out of 48 Lok Sabha seats in the state.

## Nikhil: Know all about 2nd Indian-born cricketer to play in BBL
 - [https://timesofindia.indiatimes.com/sports/cricket/big-bash-league/nikhil-chaudhary-know-all-about-second-indian-born-cricketer-to-play-in-bbl/articleshow/106454771.cms](https://timesofindia.indiatimes.com/sports/cricket/big-bash-league/nikhil-chaudhary-know-all-about-second-indian-born-cricketer-to-play-in-bbl/articleshow/106454771.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T11:43:52+00:00

Indian-born all-rounder Nikhil Chaudhary has been creating a buzz in the ongoing Big Bash League (BBL) with his impressive performances with both bat and ball while representing the Hobart Hurricanes. Nikhil has made history as the second Indian-born cricketer to participate in the BBL, following in the footsteps of India U-19 World Cup-winning captain Unmukt Chand. In his debut match against the Perth Scorchers, the right-handed batter immediately captured the crowd's attention with a scintillating innings of 40 runs off 31 balls, only to be dismissed by the left-arm quick Jason Behrendorff.

## Watch: Kohli smashes R Ashwin as India go full throttle at nets
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/watch-virat-kohli-smashes-r-ashwin-for-a-big-hit-as-india-go-full-throttle-at-nets-on-new-years-day/articleshow/106453898.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/watch-virat-kohli-smashes-r-ashwin-for-a-big-hit-as-india-go-full-throttle-at-nets-on-new-years-day/articleshow/106453898.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T11:04:44+00:00

After experiencing a significant loss in the first Test at Centurion, Team India aggressively engaged in an optional training session at Newlands on New Year's Day. Their aim was to mount a strong comeback in the second and final Test in South Africa. Star India batter Virat Kohli, who played a brilliant knock of 76 in the second innings of the first Test, was seen batting aggressively in the nets. Kohli danced down the track to smash R Ashwin over his head.

## India, Pakistan exchange list of nuclear installations
 - [https://timesofindia.indiatimes.com/india/india-pakistan-exchange-list-of-nuclear-installations/articleshow/106452752.cms](https://timesofindia.indiatimes.com/india/india-pakistan-exchange-list-of-nuclear-installations/articleshow/106452752.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T10:14:37+00:00

Continuing with an over three-decade practice, India and Pakistan on Monday exchanged a list of their nuclear installations under a bilateral pact that prohibits the two sides from attacking each other's atomic facilities. The exchange of the list took place under the provisions of an agreement on the prohibition of attack against nuclear installations and facilities, the Ministry of External Affairs (MEA) said. It was done simultaneously through diplomatic channels in New Delhi and Islamabad.

## Indian embassy in Japan issues emergency contact numbers
 - [https://timesofindia.indiatimes.com/india/japan-earthquake-indian-embassy-issues-emergency-contact-numbers-for-its-citizen-amid-tsunami-alerts/articleshow/106452553.cms](https://timesofindia.indiatimes.com/india/japan-earthquake-indian-embassy-issues-emergency-contact-numbers-for-its-citizen-amid-tsunami-alerts/articleshow/106452553.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T10:03:02+00:00



## How to check Uber rating; why it can be important in booking cab
 - [https://timesofindia.indiatimes.com/gadgets-news/how-to-check-your-uber-rating-and-why-it-can-be-important-in-booking-a-cab/articleshow/106452259.cms](https://timesofindia.indiatimes.com/gadgets-news/how-to-check-your-uber-rating-and-why-it-can-be-important-in-booking-a-cab/articleshow/106452259.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T10:02:52+00:00

This article discusses how Uber users can check their passenger ratings in the app's Privacy Center. Users can view a breakdown of their average rating, including the number of 5-star and 1-star ratings. The article also mentions that drivers often check passenger ratings before accepting trips. It provides tips on how to improve your rating, such as taking your belongings with you, being ready to go when the driver arrives, and treating drivers with respect. The Privacy Center also allows users to review their past trip information, payment details, and control marketing preferences.

## Nobel prize winner convicted in Bangladesh labour law case
 - [https://timesofindia.indiatimes.com/world/south-asia/nobel-winner-muhammad-yunus-convicted-in-bangladesh-labour-law-case/articleshow/106450729.cms](https://timesofindia.indiatimes.com/world/south-asia/nobel-winner-muhammad-yunus-convicted-in-bangladesh-labour-law-case/articleshow/106450729.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T09:28:14+00:00

Bangladeshi Nobel peace laureate Muhammad Yunus and three of his Grameen Telecom colleagues have been convicted under labour laws and sentenced to six months in simple imprisonment. The case has been widely criticized as politically motivated. Yunus, known for his microfinance bank that lifted millions out of poverty, has been accused by prime minister Sheikh Hasina of exploiting the poor. Hasina is expected to win another term in the upcoming elections. In August, global figures including Barack Obama and Ban Ki-moon denounced the judicial harassment of Yunus.

## Shubman reveals his handwritten resolution note of 2023
 - [https://timesofindia.indiatimes.com/sports/cricket/news/shubman-gill-reveals-his-handwritten-resolution-list-of-2023/articleshow/106449695.cms](https://timesofindia.indiatimes.com/sports/cricket/news/shubman-gill-reveals-his-handwritten-resolution-list-of-2023/articleshow/106449695.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T09:17:11+00:00

Indian cricket prodigy Shubman Gill took a moment to contemplate his New Year's resolution from the onset of 2023, expressing how the year brought forth an array of new experiences, yet its conclusion unfolded differently than he had foreseen. Sharing his reflections on Instagram, Shubman opted to convey his thoughts through a handwritten note shared a day before the New Year. Alongside this introspective note, he curated a series of images capturing diverse moments from the year.

## Cricketing fraternity extends New Year wishes
 - [https://timesofindia.indiatimes.com/sports/cricket/news/cricketing-fraternity-extends-new-year-wishes/articleshow/106447350.cms](https://timesofindia.indiatimes.com/sports/cricket/news/cricketing-fraternity-extends-new-year-wishes/articleshow/106447350.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T08:40:32+00:00

Cricket legends Sachin Tendulkar, VVS Laxman, and former cricketers Yuvraj Singh, Wasim Akram, and Waqar Younis extended their New Year wishes. Indian cricketers Smriti Mandhana, Mohammed Shami, KL Rahul, Cheteshwar Pujara, and Ajinkya Rahane also shared their greetings. Former West Indies cricketer Ian Bishop and Australia's Travis Head joined the cricketing fraternity in wishing everyone a happy new year. Waqar Younis posted a New Year message with his family. Tendulkar and Laxman expressed hope and positivity for the upcoming year.

## Magnitude 7.6 earthquake strikes Japan, tsunami warning issued
 - [https://timesofindia.indiatimes.com/world/rest-of-world/powerful-earthquake-hits-japan-tsunami-warning-issued/articleshow/106443030.cms](https://timesofindia.indiatimes.com/world/rest-of-world/powerful-earthquake-hits-japan-tsunami-warning-issued/articleshow/106443030.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T07:23:53+00:00



## Mark Zuckerberg is building 'post-apocalyptic bunker' in Hawaii
 - [https://timesofindia.indiatimes.com/world/us/mark-zuckerberg-is-building-post-apocalyptic-bunker-in-hawaii-what-to-know/articleshow/106438843.cms](https://timesofindia.indiatimes.com/world/us/mark-zuckerberg-is-building-post-apocalyptic-bunker-in-hawaii-what-to-know/articleshow/106438843.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T06:23:34+00:00

Mark Zuckerberg and his wife Priscilla Chan are constructing an underground bunker on their Hawaii ranch. The bunker will be self-sufficient in energy and food. The compound, known as Koolau Ranch, spans 1,400 acres and includes over a dozen buildings. The project's total cost exceeds $270 million. The purpose of the underground shelter remains unclear, but Kauai County encourages homeowners to build hurricane-resistant safe rooms. Silicon Valley elites investing in property and constructing bunkers has become a trend.

## Irfan Pathan wants Rohit Sharma to replace Ashwin with this player
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/if-youre-rohit-sharma-and-irfan-pathan-wants-india-captain-to-go-for-this-player-in-place-of-r-ashwin-in-second-test/articleshow/106439165.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/if-youre-rohit-sharma-and-irfan-pathan-wants-india-captain-to-go-for-this-player-in-place-of-r-ashwin-in-second-test/articleshow/106439165.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T06:23:27+00:00

In the opening Test of the two-match series at Centurion's SuperSport Park, India faced a defeat by an innings and 32 runs, concluding within three days. Historically, India hasn't clinched a bi-lateral Test series win in South Africa, having made attempts on eight occasions, resulting in seven losses and one drawn series. Despite posting 245 in their first innings, India's batting lineup faltered, managing only 131 runs across 34.1 overs in the second innings. South Africa set a strong foundation with a commanding 408 in their initial outing.

## Isro’s XPoSat: India is 2nd country to launch sat to study X-ray polarisation
 - [https://timesofindia.indiatimes.com/india/isros-xposat-india-is-the-second-country-to-launch-satellite-to-study-x-ray-polarisation/articleshow/106437401.cms](https://timesofindia.indiatimes.com/india/isros-xposat-india-is-the-second-country-to-launch-satellite-to-study-x-ray-polarisation/articleshow/106437401.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T05:54:12+00:00

After the successful launch, Isro’s Liquid Propulsion Systems Centre director V Narayanan said XPoSat is the second satellite in the world launched to study X-ray polarisation. NASA’s Imaging X-ray Polarimetry Explorer (IXPE) is the first such satellite. It was launched on December 9, 2021.

## 6 killed, two critical after car rams divider in Jharkhand's Jamshedpur
 - [https://timesofindia.indiatimes.com/city/jamshedpur/six-killed-two-critical-after-car-rams-divider-in-jharkhands-jamshedpur/articleshow/106433722.cms](https://timesofindia.indiatimes.com/city/jamshedpur/six-killed-two-critical-after-car-rams-divider-in-jharkhands-jamshedpur/articleshow/106433722.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T04:47:43+00:00



## Will next gen of superstars repeat 2023 box office successes?
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/with-no-khan-movies-for-2024-will-next-gen-of-superstars-repeat-2023-box-office-successes/articleshow/106432894.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/with-no-khan-movies-for-2024-will-next-gen-of-superstars-repeat-2023-box-office-successes/articleshow/106432894.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T04:31:36+00:00

The absence of Shah Rukh Khan, Ranbir Kapoor, and Ranveer Singh in 2024 raises questions about the entertainment industry's trajectory. The responsibility to carry forward the success of 2023 now rests on Akshay Kumar, Ajay Devgn, and Hrithik Roshan. Exhibitor Akshaye Rathi believes it's time for the next generation of superstars to take over and ensure the Box Office continues to churn. While the Khans have no releases, the Telugu industry has big-ticket pan-India releases. 2024 might see Akshay Kumar taking the center stage with three significant releases, making it his year.

## Shahid Afridi wants Rizwan, not Shaheen, to lead Pakistan
 - [https://timesofindia.indiatimes.com/sports/cricket/news/shahid-afridi-wants-mohammad-rizwan-not-shaheen-afridi-to-lead-pakistan/articleshow/106432041.cms](https://timesofindia.indiatimes.com/sports/cricket/news/shahid-afridi-wants-mohammad-rizwan-not-shaheen-afridi-to-lead-pakistan/articleshow/106432041.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T04:19:31+00:00

Following Babar Azam's resignation from captaincy across all formats in November, Pakistan swiftly named Shaheen Shah Afridi as their new T20I captain and Shan Masood as their Test captain. Expressing his opinion, former Pakistan captain and dynamic batsman Shahid Afridi indicated his preference for wicketkeeper-batter Mohammad Rizwan over left-arm fast bowler Shaheen Shah Afridi for the T20I captaincy. Afridi praised Rizwan as a 'fighter' and advocated for him as the most suitable candidate to lead Pakistan in the shortest format of the game.

## New year, new mission: Isro successfully launches satellite to study black hole X-ray emissions
 - [https://timesofindia.indiatimes.com/india/isros-pslv-c58-xposat-mission-successful-satellite-set-to-study-x-ray-emissions-from-black-holes-and-other-celestial-objects/articleshow/106431920.cms](https://timesofindia.indiatimes.com/india/isros-pslv-c58-xposat-mission-successful-satellite-set-to-study-x-ray-emissions-from-black-holes-and-other-celestial-objects/articleshow/106431920.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T04:02:19+00:00

Indian Space Research Organisation successfully launches PSLV-C58 carrying XPoSat and 10 other payloads. XPoSat is India's first scientific satellite for polarisation measurements of X-ray emissions from celestial objects. The launch took place at Satish Dhawan Space Centre in Sriharikota. XPoSat was placed in a 650km orbit and later reduced to a 350km circular orbit for orbital platform experiments. The mission aims to measure polarisation of X-rays from cosmic sources and improve scientists' understanding of black holes and other celestial objects. The launch also carried 10 other payloads from various organizations.

## Google celebrates New Year with vibrant animated doodle
 - [https://timesofindia.indiatimes.com/world/rest-of-world/google-celebrates-new-year-2024-with-vibrant-doodle-featuring-colours-and-confetti/articleshow/106430916.cms](https://timesofindia.indiatimes.com/world/rest-of-world/google-celebrates-new-year-2024-with-vibrant-doodle-featuring-colours-and-confetti/articleshow/106430916.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T03:22:20+00:00



## AI, Apple VisionPro and more: What to expect in 2024
 - [https://timesofindia.indiatimes.com/gadgets-news/ai-apple-visionpro-and-more-what-to-expect-in-2024/articleshow/106430999.cms](https://timesofindia.indiatimes.com/gadgets-news/ai-apple-visionpro-and-more-what-to-expect-in-2024/articleshow/106430999.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T03:18:12+00:00

Big tech companies have loaded their arsenal with AI tools and will unleash them in 2024. But it won’t be restricted to AI only.

## US sinks 3 ships, kills 10 after Houthi Red Sea attack
 - [https://timesofindia.indiatimes.com/world/us/us-sinks-3-ships-kills-10-after-houthi-red-sea-attack/articleshow/106430170.cms](https://timesofindia.indiatimes.com/world/us/us-sinks-3-ships-kills-10-after-houthi-red-sea-attack/articleshow/106430170.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T03:15:46+00:00

US helicopters successfully thwarted an attack by Iran-aligned Houthi rebels on the Singapore-flagged Maersk Hangzhou in the Red Sea, resulting in the sinking of three rebel ships and the death of 10 militants, as confirmed by American, Maersk, and Houthi representatives on Sunday. The maritime clash took place when the Houthis attempted to board the Maersk Hangzhou. In response to a distress call, helicopters from the USS Eisenhower and USS Gravely, along with the vessel's security team, repulsed the attackers. The incident led to the suspension of Maersk's Red Sea operations.

## Is 2024 a leap year and what is a leap day?
 - [https://timesofindia.indiatimes.com/india/is-2024-a-leap-year-and-what-is-a-leap-day/articleshow/106430137.cms](https://timesofindia.indiatimes.com/india/is-2024-a-leap-year-and-what-is-a-leap-day/articleshow/106430137.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T03:03:12+00:00

2024 is a leap year with 366 days. Leap day is added to the end of February every four years, making it 29 days long. Leap years and days keep the calendar in sync with the seasons as the Earth takes about 365.2422 days to orbit the Sun. The rule to determine a leap year is that it should be divisible by four, except if it is divisible by 100, unless it is also divisible by 400. February was chosen as the month for leap day due to Julius Caesar's reforms.

## Man, 20, arrested for raping 65-yr-old in Andhra
 - [https://timesofindia.indiatimes.com/city/vijayawada/inebriated-youth-arrested-for-raping-65-year-old-woman-in-prakasam-district/articleshow/106430148.cms](https://timesofindia.indiatimes.com/city/vijayawada/inebriated-youth-arrested-for-raping-65-year-old-woman-in-prakasam-district/articleshow/106430148.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T02:56:17+00:00



## David Warner retires from ODIs ahead of Test farewell
 - [https://timesofindia.indiatimes.com/sports/cricket/news/david-warner-retires-from-one-day-cricket-ahead-of-test-farewell/articleshow/106430037.cms](https://timesofindia.indiatimes.com/sports/cricket/news/david-warner-retires-from-one-day-cricket-ahead-of-test-farewell/articleshow/106430037.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T02:53:21+00:00

Australian opener David Warner has officially retired from one-day international cricket before his farewell Test against Pakistan this week. However, he has left the possibility open to participate in the 2025 Champions Trophy if the need arises. In his upcoming 112th and final Test match, taking place in his hometown of Sydney this Wednesday, the 37-year-old batsman has amassed an impressive record of 8,695 runs at an average of 44.58. Throughout his career, Warner has scored 26 centuries and 36 half-centuries.

## A ray of hope for terminally ill cancer patients
 - [https://timesofindia.indiatimes.com/city/delhi/theranostics-treatment-for-terminally-ill-cancer-patients/articleshow/106429676.cms](https://timesofindia.indiatimes.com/city/delhi/theranostics-treatment-for-terminally-ill-cancer-patients/articleshow/106429676.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T02:40:08+00:00

AIIMS has been offering theranostics, a treatment using a combination of radioactive drugs, to treat terminally-ill cancer patients for 15 years. This treatment has resulted in increased longevity by at least two years and improved the quality of life for patients. Theranostics delivers targeted doses to cancer-affected cells while sparing healthy tissues, unlike external radiation. It is used when traditional cancer treatments fail. The therapy has shown positive results in various types of cancer, but challenges remain due to the non-availability and cost of certain drugs in India.

## 2023: A year of what could have been for Indian cricket
 - [https://timesofindia.indiatimes.com/sports/cricket/news/2023-a-year-of-what-could-have-been-for-indian-cricket/articleshow/106429565.cms](https://timesofindia.indiatimes.com/sports/cricket/news/2023-a-year-of-what-could-have-been-for-indian-cricket/articleshow/106429565.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T02:35:48+00:00

Indian men's cricket team fell short in the ICC Trophy, losing in the WTC final to Australia and the ODI World Cup final; Ashwin and Travis Head's performances were crucial factors. The changing room was scarred by the loss in Motera on a curiously prepared pitch. In the white-ball format, captain Rohit Sharma led a feverish World Cup campaign, supported by Kohli, Rahul, and Iyer. The bowlers, including Arshdeep Singh, Mohammed Shami, Kuldeep Yadav, Mohammed Siraj, and Ravindra Jadeja, had impressive performances.

## 'Donkey flights'? India has nearly 3,000 illegal agencies
 - [https://timesofindia.indiatimes.com/city/bengaluru/donkey-flights-india-has-nearly-3k-illegal-agencies-680-cases-since-2020/articleshow/106429371.cms](https://timesofindia.indiatimes.com/city/bengaluru/donkey-flights-india-has-nearly-3k-illegal-agencies-680-cases-since-2020/articleshow/106429371.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T02:09:01+00:00



## 'Rahul ordinary MP, should not be highlighted much'
 - [https://timesofindia.indiatimes.com/city/bhopal/rahul-gandhi-ordinary-mp-should-not-be-highlighted-much-digvijaya-singhs-brother/articleshow/106429366.cms](https://timesofindia.indiatimes.com/city/bhopal/rahul-gandhi-ordinary-mp-should-not-be-highlighted-much-digvijaya-singhs-brother/articleshow/106429366.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T02:08:18+00:00

Lakshman Singh, brother of Digvijaya Singh, stated that Rahul Gandhi is an ordinary Congress worker and MP, not the party president. He emphasized that one's importance is determined by their actions, not birthright. Singh expressed his personal view that Rahul Gandhi should not be considered a significant leader within the party. He clarified that Rahul Gandhi himself has referred to himself as a party worker. Singh recently lost the Madhya Pradesh polls to BJP's Priyanka Penchi in the Chachoura Assembly seat.

## John Abraham acquires bungalow in prime Mumbai for ₹75cr
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/big-ticket-buy-actor-abraham-acquires-bungalow-in-prime-mumbai-area-for-75crore/articleshow/106428930.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/big-ticket-buy-actor-abraham-acquires-bungalow-in-prime-mumbai-area-for-75crore/articleshow/106428930.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T01:08:58+00:00

In another big ticket property purchase involving a Bollywood personality, actor John Abraham has sealed a deal to buy a bungalow on Linking Road, Khar. The cost: Rs 75 crore. The property, 372 Nirmal Bhavan, is a ground-plus-two storey structure which belonged to Pravin Nathalal Shah and family. According to IndexTap.com, the deal with the actor was signed on December 27 for an agreement value ofRs 70.8 crore. An additional Rs 4.25 crore was paid as stamp duty. The land area is 7,722 sq ft while the bungalow's area is 5,416 sq ft.

## Hospitals see 15x surge in PE-VC funds in 4 years
 - [https://timesofindia.indiatimes.com/business/india-business/hospitals-see-15x-surge-in-private-equity-venture-capital-funds-in-4-years/articleshow/106428793.cms](https://timesofindia.indiatimes.com/business/india-business/hospitals-see-15x-surge-in-private-equity-venture-capital-funds-in-4-years/articleshow/106428793.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T00:46:34+00:00

Investor interest in hospitals peaked this year with investments by private equity (PE) and venture capital (VC) firms rising by over 15 times to cross Rs 30,000 crore over a 4-year period from Rs 1,921 crore in pre-Covid 2019. This comes even as there is a slowdown in overall funding globally, with PE and VC investments declining 38% in India in 2023, the latest data from research firm Venture Intelligence showed. The hospital sector was red hot this year, with large hospital chains such as Manipal and Max attracting bulge-bracket investment firms as demand for private healthcare surged post the pandemic.

## After 25 yrs, Bengal gets a woman home secy
 - [https://timesofindia.indiatimes.com/city/kolkata/after-25-yrs-bengal-gets-a-woman-home-secy/articleshow/106428754.cms](https://timesofindia.indiatimes.com/city/kolkata/after-25-yrs-bengal-gets-a-woman-home-secy/articleshow/106428754.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T00:38:43+00:00

After 25 years, Bengal appoints Nandini Chakravorty as the new home secretary, succeeding B P Gopalika who becomes the state chief secretary. H K Dwivedi is appointed as CM Mamata Banerjee's chief advisor (finance). Chakravorty, a geography graduate, is also the state tourism and parliamentary affairs secretary. Raj Bhavan's previous removal of Chakravorty is referred to by Trinamool Congress. With Chakravorty and Rajeev Kumar as the new leadership team, the state police directorate undergoes a complete change before the 2024 Lok Sabha polls.

## Niti Aayog's 1st VC Panagariya to head 16th Finance Commission
 - [https://timesofindia.indiatimes.com/business/india-business/niti-aayogs-1st-vice-chairman-panagariya-to-head-16th-finance-commission/articleshow/106428751.cms](https://timesofindia.indiatimes.com/business/india-business/niti-aayogs-1st-vice-chairman-panagariya-to-head-16th-finance-commission/articleshow/106428751.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T00:36:49+00:00

Columbia University professor and the first vice chairman of Niti Aayog Arvind Panagariya has been appointed the chairman of the 16th Finance Commission. The government is, however, yet to name the other members of the panel, which has an open mandate unlike finance commissions in recent years, where the Centre provided a large set of terms of reference. For many, Panagariya's appointment came as a surprise since the last four commissions were headed by those who had long stints either in the finance ministry or RBI.

## Focus on innovative deposits for low-cost funds: FM to PSBs
 - [https://timesofindia.indiatimes.com/business/india-business/focus-on-innovative-deposits-for-low-cost-funds-fm-to-psbs/articleshow/106428716.cms](https://timesofindia.indiatimes.com/business/india-business/focus-on-innovative-deposits-for-low-cost-funds-fm-to-psbs/articleshow/106428716.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T00:30:16+00:00

With public sector banks losing share of current and savings account business, finance minister Nirmala Sitharaman has asked state-run bank chiefs to focus on innovative deposit instruments so that they can raise lower-cost resources to meet their financing requirements.  The minister once again flagged the issue at a meeting with public sector bank chiefs on Saturday with sources saying that she wanted the lenders to focus on their "core activity". Some of the new generation private banks, for instance, are offering over 9% on certain tenures of term deposits.

## Happy New Year 2024: Images, quotes, wishes, messages
 - [https://timesofindia.indiatimes.com/life-style/events/happy-new-year-2024-images-quotes-wishes-messages-cards-greetings-pictures-and-gifs/articleshow/106317779.cms](https://timesofindia.indiatimes.com/life-style/events/happy-new-year-2024-images-quotes-wishes-messages-cards-greetings-pictures-and-gifs/articleshow/106317779.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T00:30:00+00:00

As it is almost time to bid farewell to 2023 and ring in the start of 2024, mark the occasion with deep meaning author quotes, jolly wishes and messages, and attractive New Year greeting pictures and gifs to drop the ball on New Year’s Eve.

## PM's visit to mark BJP's launch of campaign in TN
 - [https://timesofindia.indiatimes.com/city/chennai/modis-visit-to-mark-bjps-launch-of-campaign-in-tamil-nadu/articleshow/106428709.cms](https://timesofindia.indiatimes.com/city/chennai/modis-visit-to-mark-bjps-launch-of-campaign-in-tamil-nadu/articleshow/106428709.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-01T00:28:37+00:00

Prime Minister Narendra Modi's visit to Tamil Nadu for project inaugurations is expected to launch BJP's campaign for Lok Sabha elections in the state. This visit comes after AIADMK's departure from the NDA alliance. Modi's visit will shed light on BJP's future plans in Tamil Nadu and whether they will seek a patch-up with AIADMK or form their own front. While the visit may not include a stop at DMDK leader Vijayakant's memorial, Modi will inaugurate and dedicate projects in various sectors including aviation, rail, road, oil and gas, shipping, and higher education.

