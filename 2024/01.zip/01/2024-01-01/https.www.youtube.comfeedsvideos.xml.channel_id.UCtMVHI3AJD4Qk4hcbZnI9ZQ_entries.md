# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## Mickey Mouse Is Finally Free...
 - [https://www.youtube.com/watch?v=O5SmgdRGwUs](https://www.youtube.com/watch?v=O5SmgdRGwUs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2024-01-01T21:49:02+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at how after 90 years the original Mickey Mouse and Minnie Mouse are finally free from Disney's legal shackles. Public domain has stepped in and you can finally do whatever it is you want with these original designs. Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the newest podcast episode: https://youtu.be/o_m7Zk7UONE

