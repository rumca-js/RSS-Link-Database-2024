# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Where does your mind go when it wanders?
 - [https://seths.blog/2024/01/where-does-your-mind-go-when-it-wanders](https://seths.blog/2024/01/where-does-your-mind-go-when-it-wanders)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-01-01T09:36:00+00:00

My friend Jason points out that this might be where your heart is. What would have to change for you to actually follow the wandering and make it real? Or for your mind to choose to wander somewhere else? Somewhere you&#8217;re already going.

