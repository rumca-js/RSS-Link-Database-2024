# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## How Much of Your Body Is New Every Year? | Compilation
 - [https://www.youtube.com/watch?v=A4ZcDt1OWKU](https://www.youtube.com/watch?v=A4ZcDt1OWKU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2024-01-01T22:00:06+00:00

Certain parts of you continue to regenerate. You can regrow your liver, for instance. But why not your lungs or legs? Scientists are getting closer to solving that mystery. 

Hosted by: Stefan Chin
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Adam Brainard, Alex Hackman, Ash, Bryan Cloer, charles george, Chris Mackey, Chris Peters, Christoph Schwanke, Christopher R Boucher, Eric Jensen, Harrison Mills, Jaap Westera, Jason A, Saslow, Jeffrey Mckishen, Jeremy Mattern, Kevin Bealer, Matt Curls, Michelle Dove, Piya Shedden, Rizwan Kassim, Sam Lutfi
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
TikTok: https://www.tiktok.com/@scishow 
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
Facebook: http://www.facebook.com/

