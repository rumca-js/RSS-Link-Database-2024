# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Dominik Piechota żegna się z Kanałem Sportowym
 - [https://www.wirtualnemedia.pl/artykul/dominik-piechota-kanal-sportowy-koniec-kanal-zero](https://www.wirtualnemedia.pl/artykul/dominik-piechota-kanal-sportowy-koniec-kanal-zero)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-01T02:02:01.417496+00:00

Dziennikarz piłkarski Dominik Piechota po ponad trzech latach współpracy odchodzi z Kanału Sportowego. Wcześniej pracował m.in. w Newonce i „Przeglądzie Sportowym”.

