# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## Study: the best free-throw shooters share these biomechanical traits
 - [https://arstechnica.com/?p=1993101](https://arstechnica.com/?p=1993101)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-01-01T21:39:51+00:00

Best shooters have greater control over release point height, trunk lean in particular.

