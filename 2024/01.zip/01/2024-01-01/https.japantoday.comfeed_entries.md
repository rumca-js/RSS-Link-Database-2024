# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## Woman dies after being found beaten on street in Kitakyushu
 - [https://japantoday.com/category/crime/woman-dies-after-being-found-beaten-on-street-in-kitakyushu](https://japantoday.com/category/crime/woman-dies-after-being-found-beaten-on-street-in-kitakyushu)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T21:01:56+00:00

A woman died Monday morning after she was found collapsed on a street in Kitakyushu on Sunday night.
A passerby called 110 at around 9:55 p.m. Sunday and…

## Mayor says buses of migrants bound for NY are being dropped off at NJ train stations
 - [https://japantoday.com/category/world/nj-mayor-says-buses-of-migrants-bound-for-ny-are-being-dropped-off-at-nj-train-stations](https://japantoday.com/category/world/nj-mayor-says-buses-of-migrants-bound-for-ny-are-being-dropped-off-at-nj-train-stations)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T21:00:42+00:00

A New Jersey mayor says buses of migrants bound for New York City have been stopping at the train station in his town and others in an apparent…

## Bangladesh court sentences Nobel laureate Yunus to 6 months in jail for violating labor laws
 - [https://japantoday.com/category/world/bangladesh-court-sentences-nobel-laureate-yunus-to-6-months-in-jail-for-violating-labor-laws](https://japantoday.com/category/world/bangladesh-court-sentences-nobel-laureate-yunus-to-6-months-in-jail-for-violating-labor-laws)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T21:00:36+00:00

A labor court in Bangladesh’s capital sentenced Monday Nobel Peace Prize winner Muhammad Yunus to six months in jail for violating the country’s labor laws.
Yunus, who pioneered…

## 3 killed, several wounded in separate shootings early on New Year's Day in Los Angeles area
 - [https://japantoday.com/category/world/early-morning-shooting-kills-woman-and-wounds-4-others-in-los-angeles-county](https://japantoday.com/category/world/early-morning-shooting-kills-woman-and-wounds-4-others-in-los-angeles-county)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T21:00:28+00:00

A woman was killed and four people were wounded in a Los Angeles County shooting shortly after the arrival of the new year, police said.
Officers from the…

## Russia launches record number of drones in Ukraine, as Putin says Moscow will intensify its attacks
 - [https://japantoday.com/category/world/russia-launches-record-number-of-drones-across-ukraine-as-moscow-and-kyiv-continue-aerial-attacks](https://japantoday.com/category/world/russia-launches-record-number-of-drones-across-ukraine-as-moscow-and-kyiv-continue-aerial-attacks)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T21:00:16+00:00

Russia launched a record 90 Shahed-type drones across Ukraine during the early hours of the new year, and Russian President Vladimir Putin said his country would “intensify” its…

## Israel pulling thousands of troops from Gaza as combat focuses on enclave's main southern city
 - [https://japantoday.com/category/world/israel-is-pulling-thousands-of-troops-from-gaza-as-combat-focuses-on-enclave%27s-main-southern-city](https://japantoday.com/category/world/israel-is-pulling-thousands-of-troops-from-gaza-as-combat-focuses-on-enclave%27s-main-southern-city)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T21:00:01+00:00

Thousands of Israeli soldiers are being shifted out of the Gaza Strip, the military said Monday, in the first significant drawdown of troops since the war began as…

## Countdown begins on PSG star Kylian Mbappé's future. Real Madrid and Liverpool possible destinations
 - [https://japantoday.com/category/sports/countdown-begins-on-psg-star-kylian-mbappe%27s-future.-real-madrid-and-liverpool-possible-destinations](https://japantoday.com/category/sports/countdown-begins-on-psg-star-kylian-mbappe%27s-future.-real-madrid-and-liverpool-possible-destinations)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T20:59:42+00:00

As the New Year begins, so does the countdown on Kylian Mbappé's future.
It promises to be a nervous start to 2024 for Paris Saint-Germain and its fans…

## Poland is into the United Cup quarterfinals; Norway beats Croatia but playoff chances uncertain
 - [https://japantoday.com/category/sports/poland-is-into-the-united-cup-quarterfinals-norway-beats-croatia-but-playoff-chances-uncertain](https://japantoday.com/category/sports/poland-is-into-the-united-cup-quarterfinals-norway-beats-croatia-but-playoff-chances-uncertain)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T20:59:34+00:00

No. 1-ranked Iga Swiatek led Poland into the quarterfinals of the United Cup mixed teams tennis tournament on Monday, winning both her singles and doubles matches.
Swiatek took…

## Japan call on Mitoma to help erase Asian Cup 'frustration'
 - [https://japantoday.com/category/sports/japan-call-on-mitoma-to-help-erase-asian-cup-%27frustration%27](https://japantoday.com/category/sports/japan-call-on-mitoma-to-help-erase-asian-cup-%27frustration%27)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T20:59:22+00:00

Brighton winger Kaoru Mitoma was named in Japan's Asian Cup squad on Monday despite an ankle injury, as coach Hajime Moriyasu looks to erase the &quot;frustration&quot; of their…

## China's manufacturing activity slows in December in latest sign the economy is still struggling
 - [https://japantoday.com/category/business/china%27s-manufacturing-activity-slows-in-december-in-latest-sign-the-economy-is-still-struggling](https://japantoday.com/category/business/china%27s-manufacturing-activity-slows-in-december-in-latest-sign-the-economy-is-still-struggling)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T20:58:39+00:00

A survey of factory managers in China shows that manufacturing contracted in December in the latest sign the world’s No. 2 economy remains sluggish. 
The official purchasing managers…

## Emperor's New Year greeting event canceled due to quake
 - [https://japantoday.com/category/national/japan-emperor%27s-new-year-greeting-event-canceled-due-to-quake](https://japantoday.com/category/national/japan-emperor%27s-new-year-greeting-event-canceled-due-to-quake)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T20:56:14+00:00

The Japanese Imperial Household Agency has canceled a public New Year greeting event planned for Tuesday to be attended by Emperor Naruhito and his family members in the…

## 4 dead, others trapped in collapsed houses after M7.6 quake rocks central Japan
 - [https://japantoday.com/category/national/update6-m7.6-quake-rocks-central-japan-killing-4-triggering-tsunami](https://japantoday.com/category/national/update6-m7.6-quake-rocks-central-japan-killing-4-triggering-tsunami)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T20:55:57+00:00

An earthquake with a preliminary magnitude of 7.6 rocked a wide area on the Sea of Japan coast Monday, killing at least four people and triggering tsunami and…

## Special delivery
 - [https://japantoday.com/category/picture-of-the-day/special-delivery-4](https://japantoday.com/category/picture-of-the-day/special-delivery-4)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T20:54:29+00:00

A postal worker, left, in a uniform worn by Meiji-era mailmen delivers New Year's greeting cards in Tokyo on Monday.

## M7.4 quake strikes central Japan; tsunami warning issued
 - [https://japantoday.com/category/national/magnitude-7.4-earthquake-strikes-japan-tsunami-warning-issued](https://japantoday.com/category/national/magnitude-7.4-earthquake-strikes-japan-tsunami-warning-issued)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T07:47:59+00:00

An earthquake with a preliminary magnitude of 7.4 hit north central Japan at 4:10 p.m. on Monday, public broadcaster NHK said.
The Japan Meteorological Agency issued a tsunami warning along…

## Crowds flock to shrines across Japan to celebrate New Year
 - [https://japantoday.com/category/national/Crowds-flock-to-shrines-across-Japan-to-celebrate-New-Year](https://japantoday.com/category/national/Crowds-flock-to-shrines-across-Japan-to-celebrate-New-Year)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T07:39:05+00:00

Hundreds of thousands of people visited shrines across Japan to welcome the new year on Monday. It was the first time since 2019 that no COVID restrictions were…

## Kishida says Japan will play leading diplomatic role in 'tense' 2024
 - [https://japantoday.com/category/politics/pm-kishida-says-japan-to-play-leading-diplomatic-role-in-tense-2024](https://japantoday.com/category/politics/pm-kishida-says-japan-to-play-leading-diplomatic-role-in-tense-2024)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T07:37:00+00:00

Japanese Prime Minister Fumio Kishida vowed Monday to put Japan at the forefront of global affairs in a &quot;tense&quot; 2024 that will see several important events, including the…

## Emperor hopes for compassion in 2024 amid wars, disasters
 - [https://japantoday.com/category/national/japan-emperor-hopes-for-compassion-in-2024-amid-wars-disasters](https://japantoday.com/category/national/japan-emperor-hopes-for-compassion-in-2024-amid-wars-disasters)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T07:36:39+00:00

Emperor Naruhito in his New Year address released Monday expressed hope that people will continue to support each other with compassion in the coming year, while noting how…

## Heavy rains in Australia's east bring more pain to storm-hit residents
 - [https://japantoday.com/category/world/heavy-rains-in-australia%27s-east-bring-more-pain-to-storm-hit-residents](https://japantoday.com/category/world/heavy-rains-in-australia%27s-east-bring-more-pain-to-storm-hit-residents)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T07:08:00+00:00

Heavy rains lashed parts of Australia's east on Monday, triggering flash flooding, inundating roads and bringing more pain for some residents reeling after the intense thunderstorms that hit…

## N Korean leader Kim says military should 'thoroughly annihilate' U.S., S Korea if provoked
 - [https://japantoday.com/category/world/north-korea%27s-kim-orders-military-to-%27thoroughly-annihilate%27-us-south-korea-if-provoked](https://japantoday.com/category/world/north-korea%27s-kim-orders-military-to-%27thoroughly-annihilate%27-us-south-korea-if-provoked)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T07:05:03+00:00

North Korean leader Kim Jong Un said his military should “thoroughly annihilate” the United States and South Korea if provoked, state media reported Monday, after he vowed to…

## Naomi Osaka wins her opening match on return to elite tennis at Brisbane International
 - [https://japantoday.com/category/sports/naomi-osaka-wins-her-opening-match-on-return-to-elite-tennis-at-the-brisbane-international](https://japantoday.com/category/sports/naomi-osaka-wins-her-opening-match-on-return-to-elite-tennis-at-the-brisbane-international)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T03:58:16+00:00

Naomi Osaka’s first win at the elite level since becoming a mother didn’t come easily. It did come on Day 1 of the year, though. So that was…

## New Year's Eve sweeps across the globe, but wars cast a shadow on 2024
 - [https://japantoday.com/category/world/New-Year%27s-Eve-sweeps-across-the-globe-but-wars-cast-a-shadow-on-2024](https://japantoday.com/category/world/New-Year%27s-Eve-sweeps-across-the-globe-but-wars-cast-a-shadow-on-2024)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-01T01:50:04+00:00

Revelers counted down to midnight on New Year's Eve across the globe Sunday as fireworks and festive lights offered a hopeful start to 2024 for some, even as…

