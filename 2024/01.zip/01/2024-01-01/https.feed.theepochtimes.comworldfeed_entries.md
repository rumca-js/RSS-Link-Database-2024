# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## Pro-Palestine Protesters Bring War to Attention Amid New Year’s Eve Celebrations
 - [https://www.theepochtimes.com/world/pro-palestine-protesters-demands-ceasefire-amid-new-years-eve-celebrations-5556223](https://www.theepochtimes.com/world/pro-palestine-protesters-demands-ceasefire-amid-new-years-eve-celebrations-5556223)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T23:23:22+00:00

Pro-Palestine protesters interrupt the Carols by Candlelight concert in Melbourne, Australia, on Dec. 24, 2023. (AAP Image/Diego Fedele)

## Detector Dogs Could Help Sniff out More Fentanyl, Firearms at Border, Review Suggests
 - [https://www.theepochtimes.com/world/detector-dogs-could-help-sniff-out-more-fentanyl-firearms-at-border-review-suggests-5556437](https://www.theepochtimes.com/world/detector-dogs-could-help-sniff-out-more-fentanyl-firearms-at-border-review-suggests-5556437)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T22:30:21+00:00

Detector dogs who work at Canada's border agency could play a bigger role in sniffing out deadly fentanyl and illicit firearms, suggests an internal evaluation that found room to boost enforcement measures.  (The Canadian Press/Paul Chiasson)

## Company Issues National Recall for Hypoallergenic Infant Formula
 - [https://www.theepochtimes.com/world/company-issues-national-recall-for-hypoallergenic-infant-formula-5556434](https://www.theepochtimes.com/world/company-issues-national-recall-for-hypoallergenic-infant-formula-5556434)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T22:24:55+00:00

A national recall has been issued for a brand of hypoalergectic infant formula over concerns it may be contaminated with a bacteria. (The Canadian Press/HO-Health Canada)

## Three Injured in Electric Bike Fire on Toronto Subway Car
 - [https://www.theepochtimes.com/world/three-injured-in-electric-bike-fire-on-toronto-subway-car-ttc-5556400](https://www.theepochtimes.com/world/three-injured-in-electric-bike-fire-on-toronto-subway-car-ttc-5556400)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T21:56:00+00:00

A Toronto Transit Commission sign is shown at a downtown Toronto subway in a file photo. (Graeme Roy/The Canadian Press)

## Cycling Community Mourns the Loss of Olympic Champion’s Life Cut Short
 - [https://www.theepochtimes.com/world/cycling-community-mourns-the-loss-of-olympic-champions-life-cut-short-5556406](https://www.theepochtimes.com/world/cycling-community-mourns-the-loss-of-olympic-champions-life-cut-short-5556406)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T21:04:31+00:00

(L-R) Annette Edmondson, Melissa Hoskins and Amy Cure of Australia after the Womens 10km Scratch finals during the Glasgow 2014 Commonwealth Games in the United Kingdom on July 26, 2014. (Mark Kolbe/Getty Images)

## Israel’s Supreme Court Pushes Back Netanyahu’s Judicial Reform
 - [https://www.theepochtimes.com/world/israels-supreme-court-pushes-back-netanyahus-judicial-reform-5556351](https://www.theepochtimes.com/world/israels-supreme-court-pushes-back-netanyahus-judicial-reform-5556351)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T20:49:54+00:00

President of the Supreme Court of Israel Esther Hayut and all fifteen justices assemble to hear petitions against the reasonableness standard law in the High Court in Jerusalem on Sept. 12, 2023. (Debbie Hill/Pool via Reuters)

## Australia’s Princess Mary to Take the Crown as Queen of Denmark
 - [https://www.theepochtimes.com/world/australias-princess-mary-to-take-the-crown-as-queen-of-denmark-5556241](https://www.theepochtimes.com/world/australias-princess-mary-to-take-the-crown-as-queen-of-denmark-5556241)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T20:21:59+00:00

Crown Prince Frederik kisses his wife Crown Princess Mary Of Denmark as they arrive at a furniture shop during their visit to Munich, Germany on May 21, 2015. (Lennart Preiss/Getty Images)

## ‘I Am Done’: Amid Rider Woes, Is Ottawa’s Transit System a Victim of Its Own Success?
 - [https://www.theepochtimes.com/world/i-am-done-amid-rider-woes-is-ottawas-transit-system-a-victim-of-its-own-success-5556359](https://www.theepochtimes.com/world/i-am-done-amid-rider-woes-is-ottawas-transit-system-a-victim-of-its-own-success-5556359)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T18:27:21+00:00

Cities from all over North America once looked to Canada’s capital as a beacon of transit success and innovation, and ridership climbed steadily for the first 10 years of the millennium. (The Canadian Press)

## Ashes of Vancouver Star Trek Fan Set to Go to Space Alongside Famous Stars
 - [https://www.theepochtimes.com/world/ashes-of-vancouver-star-trek-fan-set-to-go-to-space-alongside-famous-stars-5556357](https://www.theepochtimes.com/world/ashes-of-vancouver-star-trek-fan-set-to-go-to-space-alongside-famous-stars-5556357)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T18:22:39+00:00

Gloria Knowlan in a handout photo. (The Canadian Press/HO, Knowlan Family)

## Gas Tax Paused in Manitoba, Returns in Alberta at a Lower Rate
 - [https://www.theepochtimes.com/world/gas-tax-paused-in-manitoba-returns-in-alberta-at-a-lower-rate-5556356](https://www.theepochtimes.com/world/gas-tax-paused-in-manitoba-returns-in-alberta-at-a-lower-rate-5556356)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T18:19:21+00:00

The Manitoba government says that starting Jan. 1, motorists won’t have to pay 14 cents per litre in fuel tax for the next six months. (The Canadian Press/Paul Chiasson)

## John Robson: 5 Key Policy Improvements Ottawa Should Make in 2024
 - [https://www.theepochtimes.com/opinion/john-robson-5-key-policy-improvements-ottawa-should-make-in-2024-post-5555201](https://www.theepochtimes.com/opinion/john-robson-5-key-policy-improvements-ottawa-should-make-in-2024-post-5555201)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T17:52:47+00:00

Security comes first because if you cannot protect your citizens and your political system, nothing else matters, writes John Robson. (The Canadian Press/Graham Hughes)

## Sask. Premier Moe Reminds Province of No More Federal Carbon Tax on Home Heating Starting Jan. 1
 - [https://www.theepochtimes.com/world/sask-premier-moe-reminds-province-of-no-more-federal-carbon-tax-on-home-heating-starting-jan-1-post-5556323](https://www.theepochtimes.com/world/sask-premier-moe-reminds-province-of-no-more-federal-carbon-tax-on-home-heating-starting-jan-1-post-5556323)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T17:36:44+00:00

Saskatchewan Premier Scott Moe speaks to reporters at the Saskatchewan legislature in Regina on Oct. 10, 2023. (The Canadian Press/Heywood Yu)

## USS Gerald R. Ford Aircraft Carrier Is Returning Home After Extended Deployment Defending Israel
 - [https://www.theepochtimes.com/world/the-uss-gerald-r-ford-aircraft-carrier-is-returning-home-after-extended-deployment-defending-israel-5556331](https://www.theepochtimes.com/world/the-uss-gerald-r-ford-aircraft-carrier-is-returning-home-after-extended-deployment-defending-israel-5556331)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T17:18:27+00:00

Defense Secretary Lloyd Austin, (2nd R), talks with the commanding officer of the USS Gerald R. Ford, Navy Capt. (Tara Copp/AP Photo)

## Colorado Mother Suspected of Killing 2 of Her Children Makes Court Appearance in London
 - [https://www.theepochtimes.com/world/colorado-mother-suspected-of-killing-2-of-her-children-makes-court-appearance-in-london-5556312](https://www.theepochtimes.com/world/colorado-mother-suspected-of-killing-2-of-her-children-makes-court-appearance-in-london-5556312)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T15:54:29+00:00

Police tape marks a crime scene where police found children dead inside a condo of the Palomino Ranch Point complex, on Dec. 19, 2023, in Colorado Springs, Colo. (Parker Seibold/The Gazette via AP)

## Fire at Bar in Austria Kills 1 and Injures 21 New Year’s Party Revelers
 - [https://www.theepochtimes.com/world/fire-at-bar-in-austria-kills-1-and-injures-21-new-years-party-revelers-5556305](https://www.theepochtimes.com/world/fire-at-bar-in-austria-kills-1-and-injures-21-new-years-party-revelers-5556305)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T15:30:04+00:00

Firemen are seen in front of a restaurant in Graz, Austria, on Jan. 1, 2024, after a fatal fire broke out on New Year's Eve. (Erwin Scheriau/APA/AFP via Getty Images)

## Iranian Warship Alborz Enters the Red Sea: Tasnim
 - [https://www.theepochtimes.com/world/iranian-warship-alborz-enters-the-red-sea-tasnim-5556290](https://www.theepochtimes.com/world/iranian-warship-alborz-enters-the-red-sea-tasnim-5556290)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T15:17:56+00:00

A container ship crosses an oil platform at the Gulf of Suez towards the Red Sea before entering the Suez Canal, outside of Cairo, Egypt, on Sept. 1, 2020. (Amr Abdallah Dalsh/Reuters)

## Canadians Across Country Expected to Celebrate New Year’s Day With Polar Bear Swim
 - [https://www.theepochtimes.com/world/canadians-across-country-expected-to-celebrate-new-years-day-with-polar-bear-swim-5556299](https://www.theepochtimes.com/world/canadians-across-country-expected-to-celebrate-new-years-day-with-polar-bear-swim-5556299)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T14:59:46+00:00

The tradition of swimming in lakes, oceans and other bodies of water made chilly by January’s Canadian temperatures dates back more than a century. (The Canadian Press)

## ‘No Quick Answer’ to Fire Danger Posed by Electric Vehicles on Ferries, Says Expert
 - [https://www.theepochtimes.com/world/no-quick-answer-to-fire-danger-posed-by-electric-vehicles-on-ferries-says-expert-5556269](https://www.theepochtimes.com/world/no-quick-answer-to-fire-danger-posed-by-electric-vehicles-on-ferries-says-expert-5556269)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T14:21:05+00:00

The Felicity Ace—which caught fire while en route from Germany to Rhode Island with a cargo of electric vehicles—in the Atlantic Ocean in Feb. 2022. (Marinha Portuguesa)

## Dancing With Bears Lives on as Unique Custom in Romania
 - [https://www.theepochtimes.com/bright/dancing-with-bears-lives-on-as-unique-custom-in-romania-5556280](https://www.theepochtimes.com/bright/dancing-with-bears-lives-on-as-unique-custom-in-romania-5556280)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T13:29:47+00:00

Amalia poses for a portrait in Comanesti, northern Romania, on Dec. 27, 2023. (Andreea Alexandru/AP Photo)

## Dancing With Bears Lives on as Unique Custom in Romania
 - [https://www.theepochtimes.com/world/dancing-with-bears-lives-on-as-unique-custom-in-romania-5556280](https://www.theepochtimes.com/world/dancing-with-bears-lives-on-as-unique-custom-in-romania-5556280)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T13:29:47+00:00

Amalia poses for a portrait in Comanesti, northern Romania, on Dec. 27, 2023. (Andreea Alexandru/AP Photo)

## Total Migrant Channel Crossings Down a Third in 2023
 - [https://www.theepochtimes.com/world/total-migrant-channel-crossings-down-a-third-in-2023-post-5556281](https://www.theepochtimes.com/world/total-migrant-channel-crossings-down-a-third-in-2023-post-5556281)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T13:15:46+00:00

A group of people thought to be migrants crossing the Channel in a small boat traveling from the coast of France and heading in the direction of Dover, Kent on Aug. 29, 2023. (PA Media)

## Ex-Cycling World Champion Dennis Reportedly Charged After Olympian Wife Killed by Vehicle
 - [https://www.theepochtimes.com/world/ex-cycling-world-champion-dennis-reportedly-charged-after-olympian-wife-killed-by-vehicle-5556248](https://www.theepochtimes.com/world/ex-cycling-world-champion-dennis-reportedly-charged-after-olympian-wife-killed-by-vehicle-5556248)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T12:37:20+00:00

Gold medal winner Rohan Dennis of Australia poses with his medal after the men's cycling individual time trials at the Commonwealth Games in West Park, Wolverhampton, England, on Aug. 4, 2022. (Rui Vieira/AP Photo)

## Cleverly Bullish as Restrictions on Legal Migrants Bringing in Dependants Take Effect
 - [https://www.theepochtimes.com/world/cleverly-bullish-as-restrictions-on-legal-migrants-bringing-in-dependants-take-effect-5556249](https://www.theepochtimes.com/world/cleverly-bullish-as-restrictions-on-legal-migrants-bringing-in-dependants-take-effect-5556249)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T12:32:15+00:00

Home Secretary James Cleverly arrives in Downing Street, London, for a Cabinet meeting on December. 12, 2023. (Yui Mok/PA Wire)

## More Big Companies Set to Collapse in 2024, Industry Experts Warn
 - [https://www.theepochtimes.com/world/more-big-companies-set-to-collapse-in-2024-industry-experts-warn-5556262](https://www.theepochtimes.com/world/more-big-companies-set-to-collapse-in-2024-industry-experts-warn-5556262)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T12:21:20+00:00

A general view of the exterior of the PwC London offices on March 31, 2021. (Leon Neal/Getty Images)

## Ukraine, Russia Accuse Each Other of Early New Year’s Day Attacks
 - [https://www.theepochtimes.com/world/ukraine-russia-accuse-each-other-of-early-new-years-day-attacks-5556271](https://www.theepochtimes.com/world/ukraine-russia-accuse-each-other-of-early-new-years-day-attacks-5556271)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T11:45:17+00:00

The Russian head of Donetsk People's Republic Denis Pushilin speaks during a news conference in Donetsk, Ukraine, on Feb. 23, 2022. (Alexander Ermochenko/Reuters)

## Japan Issues Tsunami Warnings After Series of Very Strong Earthquakes Shook Its Western Coastline
 - [https://www.theepochtimes.com/world/japan-issues-tsunami-warnings-after-series-of-very-strong-earthquakes-shook-its-western-coastline-5556260](https://www.theepochtimes.com/world/japan-issues-tsunami-warnings-after-series-of-very-strong-earthquakes-shook-its-western-coastline-5556260)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T11:20:38+00:00

A house is damaged by an earthquake in Wajima, Ishikawa prefecture, Japan, on Jan. 1, 2024. (Kyodo News via AP)

## Being Consistently Inconsistent
 - [https://www.theepochtimes.com/opinion/being-consistently-inconsistent-5554341](https://www.theepochtimes.com/opinion/being-consistently-inconsistent-5554341)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T06:09:27+00:00

Pro-Palestinian  protesters held various signs aloft during their demonstration outside the Fox News building on 6th Ave in Midtown Manhattan on Nov. 29, 2023. (Richard Moore/The Epoch Times)

## Djokovic Reveals His Winning Mindset as He Sets Sights on Olympic Glory in 2024
 - [https://www.theepochtimes.com/world/novak-djokovic-sets-sights-on-olympic-glory-in-2024-post-5556198](https://www.theepochtimes.com/world/novak-djokovic-sets-sights-on-olympic-glory-in-2024-post-5556198)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T04:10:03+00:00

Novak Djokovic serves in his singles match against Zhang Zhizhen of Team China during day three of the 2024 United Cup at RAC Arena in Perth, Australia on Dec. 31, 2023. (Paul Kane/Getty Images)

## Maersk Pauses Red Sea Sailings After Houthi Attack on Container Ship
 - [https://www.theepochtimes.com/world/maersk-pauses-red-sea-sailings-after-houthi-attack-on-container-ship-5556192](https://www.theepochtimes.com/world/maersk-pauses-red-sea-sailings-after-houthi-attack-on-container-ship-5556192)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T03:37:16+00:00

CMA CGM Louis Bleriot and a Maersk Line container ship pass through the Suez Canal in Ismailia, Egypt, on July 7, 2021. (Amr Abdallah Dalsh/Reuters)

## IN-DEPTH: With Elections Looming, Taiwan Battles Massive Cyber Threat: Cybersecurity Expert
 - [https://www.theepochtimes.com/world/in-depth-with-elections-looming-taiwan-battles-massive-cyber-threat-cybersecurity-expert-5556005](https://www.theepochtimes.com/world/in-depth-with-elections-looming-taiwan-battles-massive-cyber-threat-cybersecurity-expert-5556005)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-01-01T03:32:24+00:00

A man votes in New Taipei City, Taiwan, on Nov. 26, 2022. (Annabelle Chih/Getty Images)

