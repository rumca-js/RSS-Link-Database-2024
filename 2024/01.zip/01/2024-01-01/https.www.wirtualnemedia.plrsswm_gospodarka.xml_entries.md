# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Zwolnione gwiazdy TVP brylują w TV Republika. Roman Giertych: TVP powinna ich pozwać
 - [https://www.wirtualnemedia.pl/artykul/jak-odbierac-tv-republika-gwiazdy-tvp-michal-rachon-danuta-holecka](https://www.wirtualnemedia.pl/artykul/jak-odbierac-tv-republika-gwiazdy-tvp-michal-rachon-danuta-holecka)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-01-01T03:09:42.623979+00:00

Po przejęciu przez nowe kierownictwo budynku TVP przy Woronicza 17 w Warszawie, gwiazdy “Wiadomości” i TVP Info nadawały relacje ze studia przy placu Powstańców Warszawy, a programy z ich udziałem były emitowane na antenie TV Republika. Ponadto byli pracownicy nie oddali nowym władzom profilu TVP.Info w mediach społecznościowych. - Od Telewizji Republika można żądać nawet 30 mln złotych, oczywiście solidarnie z osobami, które do tego doprowadziły, m.in. byłymi pracownikami TVP - mówi Roman Giertych portalowi Wirtualnemedia.pl.

## Krajowy Instytut Mediów z zyskiem dzięki dotacji od KRRiT. Wpływy czterokrotnie w górę
 - [https://www.wirtualnemedia.pl/artykul/krajowy-instytut-mediow-krrit-ile-zarabia](https://www.wirtualnemedia.pl/artykul/krajowy-instytut-mediow-krrit-ile-zarabia)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-01-01T02:02:00.729658+00:00

W 2022 roku Krajowy Instytut Mediów osiągnął przychody ze sprzedaży usług w wysokości 31,51 mln zł, zwiększając je rok do roku o 335 proc. Na podobnym poziomie wzrosły koszty usług obcych, co finalnie doprowadziło do tego, że KIM miał na koniec 2022 roku ponad 18 mln zł straty ze sprzedaży. Udało się jednak wypracować zysk netto, głównie dzięki “przychodom o charakterze dotacyjnym” z KRRiT.

