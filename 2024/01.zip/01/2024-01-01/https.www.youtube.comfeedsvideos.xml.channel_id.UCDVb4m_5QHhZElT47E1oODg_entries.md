# Source:The Dave Cullen Show, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg, language:en-US

## They Don’t Care What You Think
 - [https://www.youtube.com/watch?v=FV_P_U27FJM](https://www.youtube.com/watch?v=FV_P_U27FJM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDVb4m_5QHhZElT47E1oODg
 - date published: 2024-01-01T16:30:08+00:00

Support my work on Subscribe Star: https://www.subscribestar.com/dave-cullen
Follow me on Bitchute: https://www.bitchute.com/channel/hybM74uIHJKg/

Sources:  

https://cosmicbook.news/doctor-who-christmas-special-ratings-ncuti-gatwa

https://boundingintocomics.com/2023/12/29/new-doctor-who-companion-actress-millie-gibson-says-upcoming-episodes-will-attract-a-lot-of-gen-z-feature-many-controversial-elements/

KEEP UP ON SOCIAL MEDIA:
Gab: https://gab.ai/DaveCullen
Subscribe on Gab TV: https://tv.gab.com/channel/DaveCullen
Minds.com: https://www.minds.com/davecullen
Subscribe on Odysee: https://odysee.com/@TheDaveCullenShow:7

