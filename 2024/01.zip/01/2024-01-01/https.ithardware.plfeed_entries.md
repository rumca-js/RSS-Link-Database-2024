# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Honor X50 Pro oficjalnie. Smartfon z ex-flagowym procesorem na pokładzie
 - [https://ithardware.pl/aktualnosci/honor_x50_pro_oficjalnie_smartfon_z_ex_flagowym_procesorem_na_pokladzie-30921.html](https://ithardware.pl/aktualnosci/honor_x50_pro_oficjalnie_smartfon_z_ex_flagowym_procesorem_na_pokladzie-30921.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-01T22:14:00+00:00

<img src="https://ithardware.pl/artykuly/min/30921_1.jpg" />            Honor oficjalnie zaprezentował w piątek smartfon Honor X50 Pro, kt&oacute;ry jak na razie zadebiutował na rynku chińskim. Telefon wyposażono m.in. w wyświetlacz OLED i niestety starszy już procesor Qualcomma, kt&oacute;ry niegdyś zaliczano do...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/honor_x50_pro_oficjalnie_smartfon_z_ex_flagowym_procesorem_na_pokladzie-30921.html">https://ithardware.pl/aktualnosci/honor_x50_pro_oficjalnie_smartfon_z_ex_flagowym_procesorem_na_pokladzie-30921.html</a></p>

## Microsoft przygotowuje kontroler, który przypomina Joy-cony od Nintendo Switch
 - [https://ithardware.pl/aktualnosci/microsoft_przygotowuje_kontroler_ktory_przypomina_joy_cony_od_nintendo_switch-30920.html](https://ithardware.pl/aktualnosci/microsoft_przygotowuje_kontroler_ktory_przypomina_joy_cony_od_nintendo_switch-30920.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-01T19:01:06+00:00

<img src="https://ithardware.pl/artykuly/min/30920_1.jpg" />            Nintendo Switch posiada ciekawie przemyślany kontroler, kt&oacute;ry idealnie wsp&oacute;łgra z samą konsolą i zależnie od danej potrzeby może stanowić część sprzętu. Jak się okazuje patent japońskiego producenta może wykorzystać...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_przygotowuje_kontroler_ktory_przypomina_joy_cony_od_nintendo_switch-30920.html">https://ithardware.pl/aktualnosci/microsoft_przygotowuje_kontroler_ktory_przypomina_joy_cony_od_nintendo_switch-30920.html</a></p>

## Poznaliśmy kolejne hity, które Epic Games Store może rozdać
 - [https://ithardware.pl/aktualnosci/poznalismy_kolejne_hity_ktore_epic_games_store_moze_rozdac-30919.html](https://ithardware.pl/aktualnosci/poznalismy_kolejne_hity_ktore_epic_games_store_moze_rozdac-30919.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-01T15:26:13+00:00

<img src="https://ithardware.pl/artykuly/min/30919_1.jpg" />            Marvel's Guardians of the Galaxy wbrew wcześniejszym spekulacjom nie byłr rozdawany przez Epic Games Store w ostatni dzień 2023 roku. Nic straconego, bowiem w sieci udostępniono listę potencjalnych gier, kt&oacute;re będą dostępne bezpłatnie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/poznalismy_kolejne_hity_ktore_epic_games_store_moze_rozdac-30919.html">https://ithardware.pl/aktualnosci/poznalismy_kolejne_hity_ktore_epic_games_store_moze_rozdac-30919.html</a></p>

