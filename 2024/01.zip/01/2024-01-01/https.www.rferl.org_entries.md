## Tajik, Uzbek Nationals Among Those Arrested After Suspected Cologne Terrorist Threat
 - [https://www.rferl.org/a/germany-cologne-tajikistan-suspects-attack-threat/32754484.html](https://www.rferl.org/a/germany-cologne-tajikistan-suspects-attack-threat/32754484.html)
 - RSS feed: https://www.rferl.org
 - date published: 2024-01-01T21:36:56+00:00

Police in Germany on January 1 arrested another suspect in connection with a possible planned terrorist attack on Cologne Cathedral, saying it was a 41-year-old man with German and Turkish citizenship.

