# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## Gameplay Demo – Warhammer: The Old World
 - [https://www.youtube.com/watch?v=opn6rRUyjWk](https://www.youtube.com/watch?v=opn6rRUyjWk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2024-01-01T13:00:38+00:00

Get a feel for how Warhammer: The Old World plays! Learn more about the game here: https://ow.ly/EqRO50QlGA8

Follow for more Warhammer, more often:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/warhammer40000uk
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/

## Warhammer Store Anniversary Miniatures for 2024
 - [https://www.youtube.com/watch?v=kdHEiRuSTEI](https://www.youtube.com/watch?v=kdHEiRuSTEI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2024-01-01T12:00:30+00:00

There are new store anniversary miniatures coming for 2024! 

See how you can get your hands on them: https://ow.ly/206650QmuZk

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/ 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

