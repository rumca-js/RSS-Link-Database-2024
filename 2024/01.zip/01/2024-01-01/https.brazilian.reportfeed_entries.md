# Source:The Brazilian Report, URL:https://brazilian.report/feed/, language:en-US

## Scientists discover Amazonian fungi effective against Aedes aegypti mosquitoes
 - [https://brazilian.report/environment/2024/01/01/amazon-aedes-aegypti-mosquitoes](https://brazilian.report/environment/2024/01/01/amazon-aedes-aegypti-mosquitoes)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2024-01-01T22:43:15+00:00

<p>The post <a href="https://brazilian.report/environment/2024/01/01/amazon-aedes-aegypti-mosquitoes/">Scientists discover Amazonian fungi effective against Aedes aegypti mosquitoes</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

