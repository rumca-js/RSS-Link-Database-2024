# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Euro po 5,5 zł? Jest komentarz ministra finansów
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9393073,euro-po-55-zl-jest-komentarz-ministra-finansow.html](https://forsal.pl/finanse/aktualnosci/artykuly/9393073,euro-po-55-zl-jest-komentarz-ministra-finansow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T21:37:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6c7ktkuTURBXy81YWIyMTQ5Zi1iYjI5LTQ3NzQtYTEyMy1lMmI3ZDhjMWJjZDAuanBlZ5GTBc0BHcyg" />Ten kurs złotego, który sieje panikę to „fejk” (błąd źródła danych). Za chwilę otworzą się rynki w Azji i sytuacja wróci do normy - tak minister finansów Andrzej Domański skomentował w poniedziałek wieczorem na platformie X zmianę kursu złotego do euro i dolara.

## Wrocław: Zdewastowano słynną Synagogę Pod Białym Bocianem
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/9393071,wroclaw-zdewastowano-slynna-synagoge-pod-bialym-bocianem.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/9393071,wroclaw-zdewastowano-slynna-synagoge-pod-bialym-bocianem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T21:30:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/04XktkuTURBXy83ZGFjMDJkMi00YjUyLTQ2YTYtOGIyYi0yMmY3MmQ2MmRjZTQuanBlZ5GTBc0BHcyg" />Do wrocławskich policjantów trafiło zgłoszenie dotyczące aktu wandalizmu na fasadzie Synagogi Pod Białym Bocianem. Policjanci cały czas pracują nad tym, aby ustalić osobę odpowiedzialną za to przestępstwo - powiedział PAP kom. Wojciech Jabłoński z KMP we Wrocławiu.

## Komu Putin życzył szczęśliwego 2024? Tylko trzem przywódcom europejskim
 - [https://forsal.pl/swiat/rosja/artykuly/9393067,komu-putin-zyczyl-szczesliwego-2024-tylko-trzem-przywodcom-europejski.html](https://forsal.pl/swiat/rosja/artykuly/9393067,komu-putin-zyczyl-szczesliwego-2024-tylko-trzem-przywodcom-europejski.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T21:24:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/05-ktkuTURBXy81MzAxOWU2ZS01OWUwLTRkMTAtYmNiZS1lYWUzODViM2U0NjkuanBlZ5GTBc0BHcyg" />Tylko trzech europejskich przywódców dostało noworoczne życzenia od Władimira Putina - zauważył w poniedziałek węgierski portal Daily News Hungary. Życzeń nie dostali przywódcy czołowych państw UE i USA.

## Putin zapowiada zintensyfikowanie ataków na Ukrainę
 - [https://forsal.pl/swiat/rosja/artykuly/9393038,putin-zapowiada-zintensyfikowanie-atakow-na-ukraine.html](https://forsal.pl/swiat/rosja/artykuly/9393038,putin-zapowiada-zintensyfikowanie-atakow-na-ukraine.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T19:12:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5h3ktkuTURBXy83NzM4MTU5NC04MzlkLTQ5MjEtYWE1NS1hZTFiMDhiNGFjYmIuanBlZ5GTBc0BHcyg" />Rosyjski dyktator Władimir Putin zapowiedział w poniedziałek zintensyfikowanie ataków na Ukrainę - podała BBC. W trakcie wizyty w szpitalu wojskowym w Moskwie Putin oświadczył, że wojsko będzie nadal atakować ukraińskie &quot;instalacje wojskowe&quot;.

## Likwidacja lokalnych rozgłośni radiowych? Audytorium 17 zabrało głos
 - [https://forsal.pl/gospodarka/polityka/artykuly/9393037,likwidacja-lokalnych-rozglosni-radiowych-audytorium-17-zabralo-glos.html](https://forsal.pl/gospodarka/polityka/artykuly/9393037,likwidacja-lokalnych-rozglosni-radiowych-audytorium-17-zabralo-glos.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T19:06:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/L4tktkuTURBXy83NmYyZjdhZi0yMmJlLTRiMGUtYjFlNS1lYWVmZGRlY2ExNzkuanBlZ5GTBc0BHcyg" />Regionalne radiowe media publiczne nie powinny być zakładnikami kolejnej odsłony sporu politycznego - napisano w poniedziałkowym oświadczeniu dotychczasowych zarządów Rozgłośni Regionalnych Polskiego Radia, odnoszącym się do piątkowej decyzji ministra kultury o likwidacji 17 spółek regionalnych rozgłośni PR.

## W Szwecji tania benzyna wygrała z niską emisyjnością
 - [https://forsal.pl/transport/aktualnosci/artykuly/9392902,w-szwecji-tania-benzyna-wygrala-z-niska-emisyjnoscia.html](https://forsal.pl/transport/aktualnosci/artykuly/9392902,w-szwecji-tania-benzyna-wygrala-z-niska-emisyjnoscia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T16:39:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/otzktkuTURBXy85ODE1MjJlNy0zOTFmLTRkNjItYjU2MS05YzRkZjIzMGJiNTAuanBlZ5GTBc0BHcyg" />W Szwecji od poniedziałku weszły w życie przepisy znacznie obniżające normy zawartości biopaliw w benzynie i oleju napędowym. Reforma przyczyni się do wzrostu emisji CO2, co wzbudza kontrowersje, ale tankowanie na stacjach paliw już jest tańsze.

## Kiedy Czechy przyjmą euro? Petr Pavel: Pora zacząć podejmować konkretne kroki
 - [https://forsal.pl/finanse/waluty/artykuly/9392900,kiedy-czechy-przyjma-euro-petr-pavel-pora-zaczac-podejmowac-konkretn.html](https://forsal.pl/finanse/waluty/artykuly/9392900,kiedy-czechy-przyjma-euro-petr-pavel-pora-zaczac-podejmowac-konkretn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T16:32:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RZsktkuTURBXy9iMzFmYjYzMy0xMTVjLTRiMzktYjFkMy1jOTIwYjQ4MTgwYjIuanBlZ5GTBc0BHcyg" />Prezydent Czech Petr Pavel stwierdził w orędziu noworocznym, że pora zacząć podejmować konkretne kroki, które doprowadzą do przyjęcia euro. Pavel wspomniał też tragedię, do której doszło przed świętami na Uniwersytecie Karola w Pradze, i apelował o przezwyciężenie strachu.

## Jan Pietrzak w TV Republika: Mamy baraki dla imigrantów: w Auschwitz, Majdanku, Treblince
 - [https://forsal.pl/gospodarka/polityka/artykuly/9392892,jan-pietrzak-w-tv-republika-mamy-baraki-dla-imigrantow-w-auschwitz.html](https://forsal.pl/gospodarka/polityka/artykuly/9392892,jan-pietrzak-w-tv-republika-mamy-baraki-dla-imigrantow-w-auschwitz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T15:35:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yMTktkuTURBXy82MmJiYmJmMC0wZDQ3LTQwYWYtYTEwYS1jNTBiYWM4OWExOGEuanBlZ5GTBc0BHcyg" />Ośrodek Monitorowania Zachowań Rasistowskich i Ksenofobicznych złożył w poniedziałek zawiadomienie do prokuratury w związku z wypowiedzią satyryka Jana Pietrzaka - przekazał PAP w poniedziałek prezes OMZRiK Konrad Dulkowski. W niedzielę w TV Republika Pietrzak powiedział m.in., że &quot;mamy baraki dla imigrantów: w Auschwitz, Majdanku, Treblince, Stutthofie&quot;.

## Estonia zalegalizowała małżeństwa jednopłciowe
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9392753,estonia-zalegalizowala-malzenstwa-jednoplciowe.html](https://forsal.pl/swiat/aktualnosci/artykuly/9392753,estonia-zalegalizowala-malzenstwa-jednoplciowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T14:15:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/A0FktkuTURBXy82ODIzMTY3Zi00MmFkLTRhZGMtYWJhZC1iMTgxZDRmYzE5MzcuanBlZ5GTBc0BHcyg" />W Nowy Rok małżeństwa osób tej samej płci stały się w Estonii legalne. Prawo weszło w życie na mocy ustawy przyjętej przez estoński parlament 20 czerwca 2023 roku.

## Laureat pokojowej Nagrody Nobla Muhammad Yunus uznany za winnego złamania prawa pracy w Bangladeszu
 - [https://forsal.pl/praca/aktualnosci/artykuly/9392747,laureat-pokojowej-nagrody-nobla-muhammad-yunus-uznany-za-winnego-zlama.html](https://forsal.pl/praca/aktualnosci/artykuly/9392747,laureat-pokojowej-nagrody-nobla-muhammad-yunus-uznany-za-winnego-zlama.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T14:11:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/y3pktkuTURBXy9mN2U4NTM3OC1iNTRmLTRjMDQtOGY3Yi0wYjVlOWU5ZDQwMjIuanBlZ5GTBc0BHcyg" />Laureat pokojowej Nagrody Nobla Muhammad Yunus został w poniedziałek uznany za winnego złamania prawa pracy w Bangladeszu - poinformował prokurator agencję AFP. Zwolennicy skazanego uważają proces za umotywowany politycznie.

## Belgia: w Antwerpii i Brukseli wybuchły zamieszki. Poszło o... fajerwerki
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9392745,belgia-w-antwerpii-i-brukseli-wybuchly-zamieszki-poszlo-o-fajerwe.html](https://forsal.pl/swiat/aktualnosci/artykuly/9392745,belgia-w-antwerpii-i-brukseli-wybuchly-zamieszki-poszlo-o-fajerwe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T14:04:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uiaktkuTURBXy8zMTc2NzZjMi1iODVlLTQzM2MtOTI3MS0wMzQxNGIxMzk4ZTguanBlZ5GTBc0BHcyg" />206 osób w Brukseli i 60 w Antwerpii trafiło do policyjnych aresztów w Nowy Rok z powodu łamania zakazu odpalania sztucznych ogni oraz starć z policją - podają tamtejsze media w poniedziałek. W Antwerpii ustawione zostały barykady na ulicach i podpalono policyjny radiowóz.

## Zmarła Iwona Śledzińska-Katarasińska
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/9392685,zmarla-iwona-sledzinska-katarasinska.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/9392685,zmarla-iwona-sledzinska-katarasinska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T08:45:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mpOktkuTURBXy9lNzBlMjEyMy0yNjA0LTQ4OTUtOGVhMS1hMjUyNjI1MGUxY2MuanBlZ5GTBc0BHcyg" />Iwona Śledzińska-Katarasińska zmarła dziś rano po walce z ciężką chorobą - poinformowała w poniedziałek marszałek Senatu Małgorzata Kidawa-Błońska. &quot;Znakomita Posłanka, najlepsza Przyjaciółka, która dzieliła się ze wszystkimi swoją wiedzą i doświadczeniem&quot; - napisała marszałek na platformie X.

## Droższy alkohol i papierosy. Od 1 stycznia akcyza w górę
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9392683,drozszy-alkohol-i-papierosy-od-1-stycznia-akcyza-w-gore.html](https://forsal.pl/finanse/aktualnosci/artykuly/9392683,drozszy-alkohol-i-papierosy-od-1-stycznia-akcyza-w-gore.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T08:42:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/D1UktkuTURBXy9kY2ZhNjA0Zi03ODM0LTQ0MWMtYmI3ZS1jYjM2NTI2MmZmMjkuanBlZ5GTBc0BHcyg" />Pierwszego stycznia wchodzi w życie podwyżka stawek akcyzy na alkohol i papierosy oraz na tytoń do palenia. Podwyżka wynika z przepisów, uchwalonych jeszcze w 2021 r.

## Weszła w życie ustawa utrzymująca zasady ochrony określonych odbiorców energii elektrycznej, gazu i ciepła
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9392681,weszla-w-zycie-ustawa-utrzymujaca-zasady-ochrony-okreslonych-odbiorcow.html](https://forsal.pl/finanse/aktualnosci/artykuly/9392681,weszla-w-zycie-ustawa-utrzymujaca-zasady-ochrony-okreslonych-odbiorcow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T08:36:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/z7xktkuTURBXy80YWIzZDc4Mi05NzZmLTRhYjQtYjQwNi01YjI1NzVjNTc2N2UuanBlZ5GTBc0BHcyg" />1 stycznia 2024 r. weszła w życie ustawa utrzymująca w I połowie 2024 r. dotychczasowe zasady ochrony określonych odbiorców energii elektrycznej, gazu i ciepła. Przepisy te przewidują m.in. maksymalne ceny prądu dla gospodarstw domowych oraz małych i średnich firm.

## Ukraińskie systemy obrony powietrznej odparły rosyjski atak dronów na Lwów
 - [https://forsal.pl/swiat/ukraina/artykuly/9392680,ukrainskie-systemy-obrony-powietrznej-odparly-rosyjski-atak-dronow-na.html](https://forsal.pl/swiat/ukraina/artykuly/9392680,ukrainskie-systemy-obrony-powietrznej-odparly-rosyjski-atak-dronow-na.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T08:32:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zTAktkuTURBXy9jNjc2OGI5OS0yMTczLTQ0NjMtYTA4OS0xOTBhZmY5MzRlYzguanBlZ5GTBc0BHcyg" />Ukraińskie systemy obrony powietrznej odparły rosyjski atak dronów na Lwów – poinformował w poniedziałek rano na Telegramie szef władz obwodu lwowskiego Maksym Kozycki.

## Wróciło Ministerstwo Nauki i Szkolnictwa Wyższego. Kto stanął na czele?
 - [https://forsal.pl/gospodarka/polityka/artykuly/9392679,wrocilo-ministerstwo-nauki-i-szkolnictwa-wyzszego-kto-stanal-na-czele.html](https://forsal.pl/gospodarka/polityka/artykuly/9392679,wrocilo-ministerstwo-nauki-i-szkolnictwa-wyzszego-kto-stanal-na-czele.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T08:29:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Gc0ktkuTURBXy9hMDFkMDlkMS1iZGY2LTRkYzMtYjM3MS02NTk1ZWFlZDA1MjQuanBlZ5GTBc0BHcyg" />Od 1 stycznia wraca Ministerstwo Nauki i Szkolnictwa Wyższego. Zostanie ono wydzielone z dotychczasowego Ministerstwa Edukacji i Nauki. MNiSW kieruje dotychczasowy minister nauki Dariusz Wieczorek.

## Warszawa: "Spontaniczny sylwester" w obronie polskich mediów
 - [https://forsal.pl/gospodarka/polityka/artykuly/9392677,warszawa-spontaniczny-sylwester-w-obronie-polskich-mediow.html](https://forsal.pl/gospodarka/polityka/artykuly/9392677,warszawa-spontaniczny-sylwester-w-obronie-polskich-mediow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T08:23:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CIxktkuTURBXy84NDAzZGM1Mi00ZTU5LTRhOWMtODdhMi0yNjk1OTcwMTEwNTcuanBlZ5GTBc0BHcyg" />Pod hasłem &quot;spontaniczny Sylwester&quot; odbyła się w niedzielę wieczorem przed siedzibą TAI przy Placu Powstańców Warszawy manifestacja &quot;w obronie polskich mediów&quot;. &quot;Musimy pokazać, że jesteśmy siłą, że chcemy polskich wolnych mediów&quot; - powiedziała była wicemarszałek Sejmu Małgorzata Gosiewska (PiS).

## 2 stycznia 2024 r. Dla kogo w Polsce to dzień wolny od pracy?
 - [https://forsal.pl/praca/aktualnosci/artykuly/9392668,2-stycznia-2024-r-dla-kogo-w-polsce-to-dzien-wolny-od-pracy.html](https://forsal.pl/praca/aktualnosci/artykuly/9392668,2-stycznia-2024-r-dla-kogo-w-polsce-to-dzien-wolny-od-pracy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T07:37:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sqgktkuTURBXy9jYzkyMjRhNC0yYTA1LTQzYTEtOTViMy0wYmFiNjU2N2IyMTIuanBlZ5GTBc0BHcyg" />Dla wielu pracowników w Polsce 2 stycznia 2024 r. oznacza koniec przerwy świątecznej. Dla pewnej grupy będzie to jednak jeszcze dzień wolny od pracy.

## Nowy Rok, 1 stycznia 2024 r. Gdzie dziś można zrobić zakupy? Jakie sklepy są otwarte?
 - [https://forsal.pl/biznes/handel/artykuly/9392667,nowy-rok-1-stycznia-2024-r-gdzie-dzis-mozna-zrobic-zakupy-jakie-sklepy-sa-otwarte.html](https://forsal.pl/biznes/handel/artykuly/9392667,nowy-rok-1-stycznia-2024-r-gdzie-dzis-mozna-zrobic-zakupy-jakie-sklepy-sa-otwarte.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T06:53:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/t96ktkuTURBXy8xMDRiZmM0Zi1mZTlmLTRiNTctOWY2Yy02ZjAyODc5NzVhZWMuanBlZ5GTBc0BHcyg" />W poniedziałek (1 stycznia 2024 r.) większe sklepy (jak np. supermarkety) są jeszcze zamknięte. Zobacz, gdzie w Polsce można zrobić zakupy w Nowy Rok.

## AI stanie się powszechna jak telefon komórkowy. TOP 7 trendów w sztucznej inteligencji na 2024 r.
 - [https://forsal.pl/lifestyle/technologie/artykuly/9392022,ai-stanie-sie-powszechna-jak-telefon-komorkowy-top-7-trendow-w-sztucz.html](https://forsal.pl/lifestyle/technologie/artykuly/9392022,ai-stanie-sie-powszechna-jak-telefon-komorkowy-top-7-trendow-w-sztucz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/szkktkuTURBXy9jZjI3NjY4ZS04Njc1LTQ3NGMtYmIxNy1hNTU1ZThmYjkwMDUuanBlZ5GTBc0BHcyg" />Bernd Greifeneder, CTO i ekspert od AI z firmy Dynatrace, przewiduje top 7 trendów w dziedzinie sztucznej inteligencji na rok 2024. Mówi o generatywnej AI, cyfrowych systemach odpornościowych, zarządzaniu danymi i bezpieczeństwu cyfrowym.

## Chiński smok kontra amerykański bizon. Kto wygra w gospodarczym starciu?
 - [https://forsal.pl/swiat/chiny/artykuly/9391271,chinski-smok-kontra-amerykanski-bizon-kto-wygra-w-gospodarczym-starci.html](https://forsal.pl/swiat/chiny/artykuly/9391271,chinski-smok-kontra-amerykanski-bizon-kto-wygra-w-gospodarczym-starci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8SnktkuTURBXy9iNGJiMTA4Yi0xMTA1LTQ4YWQtYTlkYS00NjQzMDExNDI2NjkuanBlZ5GTBc0BHcyg" />2024 r. w kalendarzu chińskim będzie rokiem smoka – symbolu siły, mądrości i szczęścia. Każdy z tych elementów jest potrzebny gospodarce Państwa Środka, jeśli ma sobie poradzić z problemami, które coraz bardziej jej ciążą.

## Nie było podatkowego rollercoastera. I całe szczęście
 - [https://forsal.pl/gospodarka/prawo/artykuly/9391030,nie-bylo-podatkowego-rollercoastera-i-cale-szczescie.html](https://forsal.pl/gospodarka/prawo/artykuly/9391030,nie-bylo-podatkowego-rollercoastera-i-cale-szczescie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/g9qktkuTURBXy83YmUyM2JmYS1lNTYyLTQ0Y2UtOTUzMS1iMDA5YTk4NTgwMzQuanBlZ5GTBc0BHcyg" />Mijający rok z pewnością nie dostarczył nam tylu podatkowych emocji co jego poprzednik – rok 2022. Nie oznacza to, że zmian nie było (dość wspomnieć wprowadzony od lipca 2023 r. pakiet slim VAT 3), ale wszystkie one przebiegały spokojnie, z wyprzedzeniem, aż „nienaturalnie” - chciałoby się powiedzieć, mając w pamięci podatkowy rollercoaster, który zafundowali nam twórcy Polskiego (nie)Ładu.

## Nie ma miejsca na odwet [WYWIAD]
 - [https://forsal.pl/gospodarka/polityka/artykuly/9391321,nie-ma-miejsca-na-odwet-wywiad.html](https://forsal.pl/gospodarka/polityka/artykuly/9391321,nie-ma-miejsca-na-odwet-wywiad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kT1ktkuTURBXy84ZWRmZTk2ZC0wOWYzLTQ4MTItYTE4Yy1jNjM1NTZlYjFlZGIuanBlZ5GTBc0BHcyg" />Poza pojednaniem potrzebne jest realne wzmocnienie państwa polskiego. Z Katarzyną Pełczyńską-Nałęcz rozmawia Marek Tejchman.

## Obmyślić Unię na nowo. Europa coraz gorszym miejscem do życia?
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9391326,obmyslic-unie-na-nowo-europa-coraz-gorszym-miejscem-do-zycia.html](https://forsal.pl/swiat/unia-europejska/artykuly/9391326,obmyslic-unie-na-nowo-europa-coraz-gorszym-miejscem-do-zycia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4DOktkuTURBXy9hZmM4OGY2NS00NGFkLTRlMDMtOWJlMC0xM2QxYWQ3YTMwYzAuanBlZ5GTBc0BHcyg" />Europa konkurencyjna potrzebuje Europy socjalnej, podobnie jak ta druga nie może istnieć bez tej pierwszej.

## Sektor finansowy niknie w oczach. Jak mu pomóc?
 - [https://forsal.pl/biznes/bankowosc/artykuly/9391386,sektor-finansowy-niknie-w-oczach-jak-mu-pomoc.html](https://forsal.pl/biznes/bankowosc/artykuly/9391386,sektor-finansowy-niknie-w-oczach-jak-mu-pomoc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CVsktkuTURBXy82ZTA1MjRkNS0yYjdjLTQxN2QtYmRhNS1iYjU4YTM1OWRiZmMuanBlZ5GTBc0BHcyg" />Znaczenie tego sektora maleje, a jak argumentują finansiści, wsparcie dla niego byłoby z pożytkiem dla całej gospodarki.

## Świat o niezwykłej dynamice. Siedzimy na beczce prochu?
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9391276,swiat-o-niezwyklej-dynamice-siedzimy-na-beczce-prochu.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9391276,swiat-o-niezwyklej-dynamice-siedzimy-na-beczce-prochu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ijIktkuTURBXy9kYzVhMGVmNS01MWQxLTQzMmQtOWMyOS02NzA2OGMzODM1NGUuanBlZ5GTBc0BHcyg" />Minister obrony Niemiec, kraju od kilku dziesiątek lat gorąco miłującego pokój i najszczelniej okrytego amerykańskim płaszczem ochronnym (baza w Rammstein i inne), powiedział niedawno, że musimy być gotowi na wojnę w Europie. I wezwał do dalszej modernizacji Bundeswehry.

## 13. i 14. emerytura w 2024 roku. Komu przysługuje, ile wyniesie, kiedy będą pieniądze?
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9391219,13-i-14-emerytura-w-2024-roku-komu-przysluguje-ile-wyniesie-kiedy.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9391219,13-i-14-emerytura-w-2024-roku-komu-przysluguje-ile-wyniesie-kiedy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-01T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-1sktkuTURBXy9hNzQ1MzZiYS0yMzc1LTRhMDYtOTA5Yi05MTliZDRiM2Y0NWUuanBlZ5GTBc0BHcyg" />W 2024 roku emeryci i renciści mogą oczekiwać dwóch dodatkowych świadczeń, czyli trzynastej i czternastej emerytury. Te dodatkowe świadczenia są pewnym wsparciem finansowym dla seniorów, a ich wypłata jest już zaplanowana.

