# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Sąd Najwyższy uchylił ustawę kluczową dla reformy sądownictwa premiera Netanjahu
 - [https://tvn24.pl/swiat/izrael-sad-najwyzszy-uchylil-ustawe-kluczowa-dla-reformy-sadownictwa-premiera-benjamina-netanjahu-7664277?source=rss](https://tvn24.pl/swiat/izrael-sad-najwyzszy-uchylil-ustawe-kluczowa-dla-reformy-sadownictwa-premiera-benjamina-netanjahu-7664277?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T19:22:54+00:00

<img alt="Sąd Najwyższy uchylił ustawę kluczową dla reformy sądownictwa premiera Netanjahu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eraqrb-protesty-w-izraelu-przeciwko-zmianom-w-sadzie-najwyzszym-7664300/alternates/LANDSCAPE_1280" />
    Sąd Najwyższy w Izraelu uchylił w poniedziałek ustawę odbierającą mu prawo do wstrzymywania decyzji rządu, które uznał za "nieracjonalne". Uchylony akt był podstawą proponowanej przez gabinet premiera Benjamina Netanjahu reformy sądownictwa, która wywołała w kraju wielomiesięczne, masowe protesty.

## Od marca kierowcy będą tracić auta za jazdę pod wpływem alkoholu
 - [https://fakty.tvn24.pl/zobacz-fakty/od-marca-kierowcy-beda-tracic-auta-za-jazde-pod-wplywem-alkoholu-st7664293?source=rss](https://fakty.tvn24.pl/zobacz-fakty/od-marca-kierowcy-beda-tracic-auta-za-jazde-pod-wplywem-alkoholu-st7664293?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T19:19:02+00:00

<img alt="Od marca kierowcy będą tracić auta za jazdę pod wpływem alkoholu" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-40ezht-kostek-7664246/alternates/LANDSCAPE_1280" />
    Gdyby to nie był pierwszy stycznia, a 14 marca, to niemal 180 osób mogło stracić samochód, bo tylu właśnie zatrzymano w sylwestra pijanych kierowców. A od połowy marca nawet jeden promil będzie mógł prowadzić do odebrania auta.

## Od dziś rosną opłaty za usunięcie auta i jego "pobyt" na strzeżonym parkingu
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-od-dzis-rosna-oplaty-za-usuniecie-auta-i-jego-pobyt-na-na-strzezonym-parkingu-st7664287?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-od-dzis-rosna-oplaty-za-usuniecie-auta-i-jego-pobyt-na-na-strzezonym-parkingu-st7664287?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T18:24:40+00:00

<img alt="Od dziś rosną opłaty za usunięcie auta i jego " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-95w8ov-taka-niechciana-usluga-jest-od-1-stycznia-znacznie-drozsza-7664273/alternates/LANDSCAPE_1280" />
    Od 1 stycznia obowiązują wyższe opłaty za usunięcie z drogi pojazdu. Teraz trzeba za to zapłacić już 697 złotych. Więcej kosztuje także doba na strzeżonym parkingu.

## Izraelska armia: w nalocie zginął jeden z przywódców Hamasu, odpowiedzialny za masakrę w kibucach
 - [https://tvn24.pl/swiat/strefa-gazy-izraelska-armia-zginal-jeden-z-przywodcow-hamasu-odpowiedzialny-za-masakre-w-kibucach-7664234?source=rss](https://tvn24.pl/swiat/strefa-gazy-izraelska-armia-zginal-jeden-z-przywodcow-hamasu-odpowiedzialny-za-masakre-w-kibucach-7664234?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T18:14:22+00:00

<img alt="Izraelska armia: w nalocie zginął jeden z przywódców Hamasu, odpowiedzialny za masakrę w kibucach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-67s9wq-izraelskie-naloty-na-strefe-gazy-7664242/alternates/LANDSCAPE_1280" />
    Siły Obronne Izraela (IDF) poinformowały w poniedziałek, że w wyniku nalotu zginął jeden z przywódców Hamasu Adila Mismah. Był odpowiedzialny za masakrę w kibucach na początku października ubiegłego roku.

## Pogoda na jutro - wtorek 02.01. Noc z intensywnymi opadami śniegu w niektórych regionach
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-wtorek-0201-noc-z-intensywnymi-opadami-sniegu-w-niektorych-regionach-st7664244?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-wtorek-0201-noc-z-intensywnymi-opadami-sniegu-w-niektorych-regionach-st7664244?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T17:53:40+00:00

<img alt="Pogoda na jutro - wtorek 02.01. Noc z intensywnymi opadami śniegu w niektórych regionach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lz3hnp-intensywne-opady-sniegu-6227095/alternates/LANDSCAPE_1280" />
    W nocy z poniedziałku na wtorek na północnym wschodzie i częściowo na wschodzie Polski pojawią się obfite opady śniegu. Prószyć będzie też w ciągu dnia, a  w reszcie kraju spodziewany jest deszcz.

## Noworoczne powroty na drogach. Problemy na górskim odcinku zakopianki
 - [https://tvn24.pl/krakow/noworoczne-powroty-na-drogach-korki-na-zakopiance-7664204?source=rss](https://tvn24.pl/krakow/noworoczne-powroty-na-drogach-korki-na-zakopiance-7664204?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T16:02:49+00:00

<img alt="Noworoczne powroty na drogach. Problemy na górskim odcinku zakopianki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9v7wva-sznur-aut-na-zakopiance-7664202/alternates/LANDSCAPE_1280" />
    Kierowcy wyjeżdżający po sylwestrze z Zakopanego muszą uzbroić się w cierpliwość - na popularnej zakopiance od wczesnych godzin popołudniowych panuje bardzo duży ruch. Największe problemy są na górskiej części - przy wyjeździe z Zakopanego i na podjeździe między Nowym Targiem i Klikuszową.

## Będziemy mieli dwie pory roku jednocześnie. W części kraju chwyci tęgi mróz i sypnie śniegiem
 - [https://tvn24.pl/tvnmeteo/prognoza/zima-uderzy-w-polsce-srogi-mroz-snieg-i-zawieje-prognoza-pogody-na-poczatek-stycznia-2024-st7664171?source=rss](https://tvn24.pl/tvnmeteo/prognoza/zima-uderzy-w-polsce-srogi-mroz-snieg-i-zawieje-prognoza-pogody-na-poczatek-stycznia-2024-st7664171?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T15:57:39+00:00

<img alt="Będziemy mieli dwie pory roku jednocześnie. W części kraju chwyci tęgi mróz i sypnie śniegiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ieoho-snieg-zawieje-zamiecie-7664185/alternates/LANDSCAPE_1280" />
    Pogoda w pierwszym tygodniu stycznia podzieli Polskę - będziemy mieli dwie pory roku. Do niektórych regionów wróci zima, z opadami śniegu, zawiejami, zamieciami, i chwyci tam mróz. W części kraju temperatura wciąż wciąż będzie osiągać jesienne lub wiosenne wartości.

## "F-16 dostarczone na Ukrainę"? Ten film tego nie potwierdza
 - [https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-f-16-dostarczone-na-ukraine-ten-film-tego-nie-potwierdza-st7653059?source=rss](https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-f-16-dostarczone-na-ukraine-ten-film-tego-nie-potwierdza-st7653059?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T14:55:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k655a7-f-16-dostarczone-na-ukraine-to-wideo-tego-nie-dowodzi-7653675/alternates/LANDSCAPE_1280" />
    Według podawanych przez internautów informacji Ukraina otrzymała już z Zachodu samoloty F-16. Jednak nagranie, które rzekomo ma to potwierdzać, przedstawia co innego.

## Najbardziej zatłoczone turystyczne kierunki. Kiedy planować urlop, by uniknąć tłumów
 - [https://tvn24.pl/biznes/turystyka/turystyka-najbardziej-zatloczone-turystyczne-kierunki-kiedy-planowac-urlop-by-uniknac-tlumow-st7664150?source=rss](https://tvn24.pl/biznes/turystyka/turystyka-najbardziej-zatloczone-turystyczne-kierunki-kiedy-planowac-urlop-by-uniknac-tlumow-st7664150?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T14:54:37+00:00

<img alt="Najbardziej zatłoczone turystyczne kierunki. Kiedy planować urlop, by uniknąć tłumów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5bs75u-akropol-partenon-ateny-tlum-turysci-wakacje-grecja-starozytnosc-zwiedzanie-turystyka-zabytek-7664037/alternates/LANDSCAPE_1280" />
    Każdego roku odwiedzają je miliony gości, a miejscowe władze wdrażają środki, których celem jest zmniejszenie ruchu turystycznego. Portal CNN opracował zestawienie najpopularniejszych i najbardziej zatłoczonych celów turystów wraz ze wskazówkami, kiedy tam jechać, by uniknąć tłumów. Na liście znalazł się między innymi Paryż, Ateny, Amsterdam i Barcelona.

## Małżeństwa jednopłciowe stały się w Estonii legalne
 - [https://tvn24.pl/swiat/estonia-malzenstwa-jednoplciowe-staly-sie-legalne-7664115?source=rss](https://tvn24.pl/swiat/estonia-malzenstwa-jednoplciowe-staly-sie-legalne-7664115?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T14:49:29+00:00

<img alt="Małżeństwa jednopłciowe stały się w Estonii legalne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4z60am-zwiazki-partnerskie-7643171/alternates/LANDSCAPE_1280" />
    Małżeństwa osób tej samej płci wraz z Nowym Rokiem stały się legalne w Estonii. Dzięki wprowadzeniu równości małżeńskiej pary jednopłciowe mogą między innymi wspólnie adoptować dzieci.

## Kobieta zginęła pod kołami pociągu
 - [https://tvn24.pl/wroclaw/katy-wroclawskie-34-latka-zginela-pod-kolami-pociagu-7664106?source=rss](https://tvn24.pl/wroclaw/katy-wroclawskie-34-latka-zginela-pod-kolami-pociagu-7664106?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T14:35:01+00:00

<img alt="Kobieta zginęła pod kołami pociągu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1vr4hh-straznicy-miejscy-przekonywali-mezczyzne-do-zejscia-z-torow-zdjecie-ilustracyjne-7458927/alternates/LANDSCAPE_1280" />
    31 grudnia przed północą kobieta wpadła pod pociąg w Kątach Wrocławskich. Zginęła na miejscu. Policja wyjaśnia okoliczności tragedii. Ruch na torach wstrzymany był przez kilka godzin.

## Były podejrzenia i tropy, ale tych spraw śledczym wciąż nie udało się zamknąć
 - [https://tvn24.pl/tvnwarszawa/okolice/warszawa-kto-zabil-izabele-kim-sa-rodzice-noworodka-znalezionego-w-radzyminie-niewyjasnione-sprawy-st7653089?source=rss](https://tvn24.pl/tvnwarszawa/okolice/warszawa-kto-zabil-izabele-kim-sa-rodzice-noworodka-znalezionego-w-radzyminie-niewyjasnione-sprawy-st7653089?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T14:20:42+00:00

<img alt="Były podejrzenia i tropy, ale tych spraw śledczym wciąż nie udało się zamknąć" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-epl0k-do-zabojstwa-doszlo-przy-grzybowskiej-7401082/alternates/LANDSCAPE_1280" />
    Prokuratura nie ma wątpliwości, że do śmierci kobiety, której ciało znaleziono w październiku w warszawskim hotelu, przyczyniły się osoby trzecie. Sprawcy jednak wciąż nie zatrzymano. Śledczy wytypowali z kolei podejrzewanego o zabicie 20-letniej Ukrainki, ale postępowanie musieli zawiesić. Policjanci nie rozwiązali też sprawy śmierci kobiety z Mołdawii w Parku Praskim. Nie udało się również ustalić kim są rodzice noworodka znalezionego w Radzyminie.

## Nowa kładka połączy Ludwinów i Kazimierz. Budowa ma trwać dwa lata
 - [https://tvn24.pl/krakow/krakow-rozpoczecie-budowy-nowej-kladki-miedzy-kazimierzem-a-ludwinowem-7664091?source=rss](https://tvn24.pl/krakow/krakow-rozpoczecie-budowy-nowej-kladki-miedzy-kazimierzem-a-ludwinowem-7664091?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T13:59:50+00:00

<img alt="Nowa kładka połączy Ludwinów i Kazimierz. Budowa ma trwać dwa lata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vswz6y-tak-ma-wygladac-nowa-kladka-7664092/alternates/LANDSCAPE_1280" />
    W środę rozpocznie się budowa nowej kładki pieszo-rowerowej na Wiśle w Krakowie. Kładka znajdzie się w połowie drogi między mostem Dębnickim a mostem Piłsudskiego i połączy Podgórze i Ludwinów z Kazimierzem. Oznacza to czasową zmianę w organizacji ruchu w rejonie inwestycji.

## Wyprowadził miliony z ubóstwa. Teraz władze oskarżają noblistę o okradanie pracowników
 - [https://tvn24.pl/biznes/ze-swiata/noblista-muhammad-yunus-oskarzony-przez-wladze-o-lamanie-praw-pracownikow-st7664045?source=rss](https://tvn24.pl/biznes/ze-swiata/noblista-muhammad-yunus-oskarzony-przez-wladze-o-lamanie-praw-pracownikow-st7664045?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T13:36:04+00:00

<img alt="Wyprowadził miliony z ubóstwa. Teraz władze oskarżają noblistę o okradanie pracowników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kuts45-shutterstock_1983597785-7664043/alternates/LANDSCAPE_1280" />
    Laureat pokojowej Nagrody Nobla Muhammad Yunus został w poniedziałek uznany za winnego złamania prawa pracy w Bangladeszu - poinformował prokurator agencję AFP. Zwolennicy skazanego uważają proces za umotywowany politycznie.

## Izrael wycofuje część sił ze Strefy Gazy. Przechodzi do "trzeciego etapu"
 - [https://tvn24.pl/swiat/izrael-hamas-konflikt-w-strefie-gazy-izrael-wycofuje-czesc-sil-ze-strefy-gazy-przechodzi-do-trzeciego-etapu-7663925?source=rss](https://tvn24.pl/swiat/izrael-hamas-konflikt-w-strefie-gazy-izrael-wycofuje-czesc-sil-ze-strefy-gazy-przechodzi-do-trzeciego-etapu-7663925?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T12:49:33+00:00

<img alt="Izrael wycofuje część sił ze Strefy Gazy. Przechodzi do " src="https://tvn24.pl/najnowsze/cdn-zdjecie-g2t8a7-izraelscy-zolnierze-w-poblizu-granicy-ze-strefa-gazy-7664030/alternates/LANDSCAPE_1280" />
    Izrael zdecydował się wycofać część swoich wojsk ze Strefy Gazy i zwolnić ze służby część powołanych do walki rezerwistów - przekazał agencji Reuters izraelski urzędnik. Ruch ten ma służyć przejściu do bardziej ukierunkowanych operacji przeciwko Hamasowi oraz wspomóc izraelską gospodarkę. Urzędnik wyjaśnił, że wojsko przechodzi teraz do trzeciego etapu. - Zajmie to co najmniej sześć miesięcy i będzie wiązać się z intensywnymi misjami likwidowania terrorystów - przekazał.

## W tym roku polski odcinek międzynarodowej trasy ma być przejezdny
 - [https://tvn24.pl/biznes/z-kraju/via-baltica-w-2024-roku-przejezdna-bedzie-cala-droga-ekspresowa-s61-st7663955?source=rss](https://tvn24.pl/biznes/z-kraju/via-baltica-w-2024-roku-przejezdna-bedzie-cala-droga-ekspresowa-s61-st7663955?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T12:43:16+00:00

<img alt="W tym roku polski odcinek międzynarodowej trasy ma być przejezdny" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-2tfjwc-powstaja-kolejne-odcinki-via-baltica-4755362/alternates/LANDSCAPE_1280" />
    W 2024 roku kierowcy będą mogli jeździć całą trasą S61 Via Baltica, na ukończenie czeka jeszcze obwodnica Łomży z nowym mostem na rzece Narew (Podlaskie) - zapowiada Generalna Dyrekcja Dróg Krajowych i Autostrad w raporcie podsumowującym inwestycje z 2023 roku. Trwają także prace nad budową trzech pierwszych odcinków międzynarodowego korytarza transportowego Via Carpatia o łącznej długości 39,3 km.

## Sześciolatek wpadł w panikę. Jego mama leżała na trawie, pijana do nieprzytomności
 - [https://tvn24.pl/katowice/chorzow-impreza-plenerowa-w-sylwestra-pijana-kobieta-lezala-na-trawie-obok-stal-jej-szescioletni-syn-7663973?source=rss](https://tvn24.pl/katowice/chorzow-impreza-plenerowa-w-sylwestra-pijana-kobieta-lezala-na-trawie-obok-stal-jej-szescioletni-syn-7663973?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T12:35:28+00:00

<img alt="Sześciolatek wpadł w panikę. Jego mama leżała na trawie, pijana do nieprzytomności" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rk6t2y-szesciolatek-byl-z-pijana-mama-na-imprezie-sylwestrowej-7664006/alternates/LANDSCAPE_1280" />
    W Chorzowie trwała plenerowa impreza sylwestrowa. Sześcioletni chłopiec, zapłakany, wystraszony i zmarznięty, stał obok mamy, która leżała na trawie. Kobieta miała w organizmie 2,5 promila alkoholu. Chłopiec trafił pod opiekę cioci.

## Wibrująca kapsułka może pomóc w walce z otyłością. Jak działa?
 - [https://tvn24.pl/ciekawostki/otylosc-leczenie-wibrujaca-kapsulka-moze-pomoc-w-kontrolowaniu-wagi-7663910?source=rss](https://tvn24.pl/ciekawostki/otylosc-leczenie-wibrujaca-kapsulka-moze-pomoc-w-kontrolowaniu-wagi-7663910?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T12:18:42+00:00

<img alt="Wibrująca kapsułka może pomóc w walce z otyłością. Jak działa?  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-mkhic2-otylosc-zwieksza-ryzyko-ciezkiego-przebiegu-covid-19-5035069/alternates/LANDSCAPE_1280" />
    Amerykańscy naukowcy opracowali wibrującą kapsułkę, która, jak przekonują, może okazać się alternatywą dla obecnych metod leczenia otyłości. Badania na zwierzętach wykazały, że spożycie kapsułki przed posiłkiem sprawia, że spożywają one mniej pokarmu. Teraz naukowcy chcą przejść do etapu badań klinicznych na ludziach. - Ktoś, kto chce schudnąć lub kontrolować swój apetyt, mógłby przyjmować kapsułkę przed każdym posiłkiem - ocenia dr Shriya Srinivasan, główna autorka badania.

## Miał badać "zbrodnie kijowskiego reżimu". W ukraińskich atakach zginął oficer Komitetu Śledczego Rosji
 - [https://tvn24.pl/swiat/rosja-ataki-na-bieglorod-zginal-oficer-komitetu-sledczego-michail-konopicin-7663902?source=rss](https://tvn24.pl/swiat/rosja-ataki-na-bieglorod-zginal-oficer-komitetu-sledczego-michail-konopicin-7663902?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T11:42:09+00:00

<img alt="Miał badać " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9qpi2-zniszczenia-w-bielgorodzie-po-ataku-ukrainskich-dronow-7659246/alternates/LANDSCAPE_1280" />
    Wywiad wojskowy w Kijowie przekazał, że w ataku sił ukraińskich na miasto Biełgorod zginął oficer Komitetu Śledczego Rosji. Michaił Konopicin był dowódcą pododdziału, walczącego przeciwko Ukrainie.

## Spacerowicz zauważył w stawie ciało mężczyzny.  Mógł utonąć dobę wcześniej
 - [https://tvn24.pl/trojmiasto/wejherowo-strazacy-wylowili-zwloki-ze-stawu-przy-ulicy-strzeleckiej-7663943?source=rss](https://tvn24.pl/trojmiasto/wejherowo-strazacy-wylowili-zwloki-ze-stawu-przy-ulicy-strzeleckiej-7663943?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T11:38:13+00:00

<img alt="Spacerowicz zauważył w stawie ciało mężczyzny.  Mógł utonąć dobę wcześniej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xh0tm0-zwloki-zostaly-wylowione-ze-stawu-przy-ulicy-strzeleckiej-7663933/alternates/LANDSCAPE_1280" />
    W Nowy Rok strażacy z Wejherowa (woj. pomorskie) wyłowili zwłoki mężczyzny, które dryfowały w stawie przy ulicy Strzeleckiej. Pierwsze informacje o zdarzeniu dostaliśmy na Kontakt 24.

## Zderzenie na S8, dwie osoby zakleszczone we wraku auta, trasa zablokowana
 - [https://tvn24.pl/tvnwarszawa/najnowsze/mszczonow-zderzenie-na-s8-dwie-osoby-zakleszczone-trasa-zablokowana-st7663930?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/mszczonow-zderzenie-na-s8-dwie-osoby-zakleszczone-trasa-zablokowana-st7663930?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T11:26:18+00:00

<img alt="Zderzenie na S8, dwie osoby zakleszczone we wraku auta, trasa zablokowana " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-j07btk-wypadek-na-obwodnicy-mszczonowa-7663939/alternates/LANDSCAPE_1280" />
    Na obwodnicy Mszczonowa (powiat żyrardowski) w ciągu trasy S8 zderzyły się dwa auta. Są osoby poszkodowane. Droga jest zablokowana w obu kierunkach.

## Myszka Miki dla każdego. Od dziś można ją wykorzystać w swojej twórczości
 - [https://tvn24.pl/biznes/najnowsze/myszka-miki-disney-traci-prawa-autorskie-od-1-stycznia-2024-roku-st7663909?source=rss](https://tvn24.pl/biznes/najnowsze/myszka-miki-disney-traci-prawa-autorskie-od-1-stycznia-2024-roku-st7663909?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T11:24:30+00:00

<img alt="Myszka Miki dla każdego. Od dziś można ją wykorzystać w swojej twórczości" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b0t40m-gettyimages-1137227018-7663894/alternates/LANDSCAPE_1280" />
    Myszka Miki nie należy już tylko i wyłącznie do Disneya. Od 1 stycznia 2024 roku pierwsza wersja tej postaci, która pojawiła się w filmie animowanym z 1928 roku "Steamboat Willie" ("Parowiec Willie"), weszła do domeny publicznej. To oznacza, że od dziś każdy może wykorzystać ją w swojej twórczości.

## "Kilka zatrzymanych osób, blisko sto interwencji, pożar oraz zranienie nożem młodego turysty"
 - [https://tvn24.pl/krakow/zakopane-interwencje-policji-w-sylwestrowa-noc-7663917?source=rss](https://tvn24.pl/krakow/zakopane-interwencje-policji-w-sylwestrowa-noc-7663917?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T11:20:24+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7v38i4-tlum-na-krupowkach-w-zakopanem-7663918/alternates/LANDSCAPE_1280" />
    Policjanci interweniowali w sprawie sylwestrowych awantur, pomagali pijanym turystom znaleźć kwatery i zatrzymali dwóch mieszkańców Mazowsza, którzy mogą mieć związek z ugodzeniem nożem młodego mężczyzny.

## Dobra wiadomość dla osób z niepełnosprawnościami. Od dziś mogą złożyć wniosek o dodatkowe świadczenie
 - [https://tvn24.pl/biznes/prawo/swiadczenie-wspierajace-dla-osob-z-niepelnosprawnosciami-startuja-od-1-stycznia-2024-roku-st7663843?source=rss](https://tvn24.pl/biznes/prawo/swiadczenie-wspierajace-dla-osob-z-niepelnosprawnosciami-startuja-od-1-stycznia-2024-roku-st7663843?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T10:09:30+00:00

<img alt="Dobra wiadomość dla osób z niepełnosprawnościami. Od dziś mogą złożyć wniosek o dodatkowe świadczenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dql6xf-shutterstock_2304754665-7663883/alternates/LANDSCAPE_1280" />
    Od 1 stycznia dorosłe osoby z niepełnosprawnością mogą ubiegać się o świadczenie wspierające. Aby je otrzymać należy w pierwszej kolejności zgłosić się do wojewódzkiego zespołu do spraw orzekania o niepełnosprawności, by uzyskać decyzję dotyczącą poziomu potrzeby wsparcia.

## Wracają żółwie, małże, traszki, kumaki i bieliki. Zniszczona delta Nidy znów tętni życiem
 - [https://tvn24.pl/kielce/wracaja-zolwie-malze-traszki-kumaki-i-bieliki-zniszczona-delta-nidy-znow-tetni-zyciem-7663825?source=rss](https://tvn24.pl/kielce/wracaja-zolwie-malze-traszki-kumaki-i-bieliki-zniszczona-delta-nidy-znow-tetni-zyciem-7663825?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T09:13:12+00:00

<img alt="Wracają żółwie, małże, traszki, kumaki i bieliki. Zniszczona delta Nidy znów tętni życiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k4xtij-delta-nidy-7663836/alternates/LANDSCAPE_1280" />
    Żółwie wodne, małże i bieliki wracają do śródlądowej delty Nidy. To efekt wieloletniej pracy przyrodników i przywrócenia w tym miejscu unikalnych walorów hydrologicznych.

## Prezydent Chin w noworocznym orędziu przyznał, że chiński biznes przeżywa "trudne czasy"
 - [https://tvn24.pl/biznes/najnowsze/chiny-prezydent-xi-jinping-w-noworocznym-oswiadczeniu-przyznal-ze-gospodarka-przezywa-trudny-okres-st7663808?source=rss](https://tvn24.pl/biznes/najnowsze/chiny-prezydent-xi-jinping-w-noworocznym-oswiadczeniu-przyznal-ze-gospodarka-przezywa-trudny-okres-st7663808?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T09:11:12+00:00

<img alt="Prezydent Chin w noworocznym orędziu przyznał, że chiński biznes przeżywa " src="https://tvn24.pl/najnowsze/cdn-zdjecie-w29gx6-2023-12-31t130728z_2_lop901731122023rp1_rtrmadp_baseimage-960x540_new-year-china-xi-7663796/alternates/LANDSCAPE_1280" />
    Prezydent Chin Xi Jinping w swoim noworocznym orędziu przyznał, że "niektóre przedsiębiorstwa przeżywały trudne czasy" w 2023 roku, co wykazały dane - pogłębienie się w tym miesiącu osłabienia produkcji fabrycznej, ale zapowiedział przyspieszenie tempa ożywienia gospodarczego.

## Nie zatrzymał się do kontroli, podczas ucieczki uderzył w słup sygnalizacji
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-nie-zatrzymal-sie-do-kontroli-uciekal-przed-policja-i-staranowal-slup-sygnalizacji-st7663805?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-nie-zatrzymal-sie-do-kontroli-uciekal-przed-policja-i-staranowal-slup-sygnalizacji-st7663805?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T08:58:09+00:00

<img alt="Nie zatrzymał się do kontroli, podczas ucieczki uderzył w słup sygnalizacji" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-loqco6-pijany-kierowca-staranowal-slup-sygnalizacji-swietlnej-7663812/alternates/LANDSCAPE_1280" />
    W noworoczny poranek w okolicach mostu Gdańskiego kierowca samochodu osobowego nie zatrzymał się do policyjnej kontroli. Funkcjonariusze rozpoczęli pościg, który zakończył się kilkaset metrów dalej. Kierujący uderzył w słup sygnalizacji świetlnej. Był pijany.

## Jedną kobietę ewakuowali z płonącego domu, drugiej nie udało się uratować
 - [https://tvn24.pl/lodz/glowno-ulica-polna-pozar-domu-jednorodzinnego-nie-zyje-jedna-osoba-7663803?source=rss](https://tvn24.pl/lodz/glowno-ulica-polna-pozar-domu-jednorodzinnego-nie-zyje-jedna-osoba-7663803?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T08:46:11+00:00

<img alt="Jedną kobietę ewakuowali z płonącego domu, drugiej nie udało się uratować" src="https://tvn24.pl/najnowsze/cdn-zdjecie-exwx81-zgloszenie-o-pozarze-dotarlo-do-strazakow-o-137-7663804/alternates/LANDSCAPE_1280" />
    O godzinie 1:37 strażacy ze Zgierza zostali zaalarmowani o pożarze domu jednorodzinnego w Głownie (woj. łódzkie). Z budynku ewakuowana została kobieta w wieku około 90 lat. W środku została 69-latka, której życia nie udało się uratować.

## Samochód wjechał pod szynobus. Kierowca nie żyje
 - [https://tvn24.pl/tvnwarszawa/okolice/plonsk-samochod-wjechal-pod-szynobus-kierowca-nie-zyje-st7663776?source=rss](https://tvn24.pl/tvnwarszawa/okolice/plonsk-samochod-wjechal-pod-szynobus-kierowca-nie-zyje-st7663776?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T08:39:28+00:00

<img alt="Samochód wjechał pod szynobus. Kierowca nie żyje" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-nklef1-do-tragicznego-wypadku-doszlo-przy-ul-szkolnej-w-plonsku-zdjecie-ilustracyjne-7663799/alternates/LANDSCAPE_1280" />
    Do tragicznego w skutkach wypadku doszło w niedzielę wieczorem na przejeździe kolejowym w Płońsku. Kierowca samochodu osobowego wjechał pod szynobus Kolei Mazowieckich. Mężczyzna zginął na miejscu.

## Blisko 100 interwencji w sylwestrową noc
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-blisko-setka-interwencji-w-ciagu-doby-strazacy-podsumowuja-sylwestrowa-noc-st7663772?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-blisko-setka-interwencji-w-ciagu-doby-strazacy-podsumowuja-sylwestrowa-noc-st7663772?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T08:21:38+00:00

<img alt="Blisko 100 interwencji w sylwestrową noc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p809b1-straz-pozarna-zdjecie-ilustracyjne-7447389/alternates/LANDSCAPE_1280" />
    Podczas nocy sylwestrowej strażacy wyjeżdżali głównie do niegroźnych pożarów. Do najpoważniejszego doszło na Targówku, gdzie zapaliła się altana śmietnikowa oraz przyłącze gazu.

## 12-letni Rafał pojechał na ferie, nie żyje. Od siedmiu lat trwają procesy. "To niekończący się koszmar"
 - [https://tvn24.pl/lodz/rafal-mial-12-lat-pojechal-na-zimowisko-w-wisle-utonal-w-basenie-po-siedmiu-latach-jest-jeden-skazany-7607070?source=rss](https://tvn24.pl/lodz/rafal-mial-12-lat-pojechal-na-zimowisko-w-wisle-utonal-w-basenie-po-siedmiu-latach-jest-jeden-skazany-7607070?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T08:18:34+00:00

<img alt="12-letni Rafał pojechał na ferie, nie żyje. Od siedmiu lat trwają procesy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-eau9zd-rafal-nie-zyje-od-stycznia-2017-roku-7607117/alternates/LANDSCAPE_1280" />
    Miał być bezpieczny. Dwunastoletni Rafał w styczniu 2017 roku wraz z innymi dziećmi, które pojechały na ferie w Wiśle poszedł na basen. On utonął, a drugi chłopiec ledwie uszedł z życiem. Nad dziećmi mieli czuwać opiekunowie i ratownik. Po tragedii okazało się, że - jak wskazał łódzki sąd okręgowy - opiekunowie na basenie się "relaksowali", a ratownik nie tylko nie miał wymaganych uprawnień, ale w kluczowym momencie wyszedł z pływalni. Po siedmiu latach skazana jest jedna osoba, na karę więzienia w zawieszeniu. - To niekończący się koszmar - mówią rodzice Rafała.

## ISW: rosyjskie wojska powietrznodesantowe ponoszą ciężkie straty w Ukrainie
 - [https://tvn24.pl/swiat/instytut-studiow-nad-wojna-rosyjskie-sily-powietrznodesantowe-ponosza-ciezkie-straty-w-ukrainie-7663741?source=rss](https://tvn24.pl/swiat/instytut-studiow-nad-wojna-rosyjskie-sily-powietrznodesantowe-ponosza-ciezkie-straty-w-ukrainie-7663741?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T08:15:00+00:00

<img alt="ISW: rosyjskie wojska powietrznodesantowe ponoszą ciężkie straty w Ukrainie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-u60vil-rosja-wojsko-7663779/alternates/LANDSCAPE_1280" />
    Siły powietrznodesantowe Rosji ponoszą ciężkie straty prowadząc jednoczesne operacje ofensywne na kilku frontach w Ukrainie – ocenia w najnowszej analizie amerykański Instytut Studiów nad Wojną (ISW). Żołnierze tej formacji "nie mają możliwości, by odpocząć czy odzyskać siły".

## Aleje Jerozolimskie. Peryferyjna ulica wśród pól stała się elegancką, wielkomiejską arterią
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-aleje-jerozolimskie-skad-taka-nazwa-historia-ulicy-st7637494?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-aleje-jerozolimskie-skad-taka-nazwa-historia-ulicy-st7637494?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T07:51:00+00:00

<img alt="Aleje Jerozolimskie. Peryferyjna ulica wśród pól stała się elegancką, wielkomiejską arterią" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-itoso5-aleje-jerozolimskie-w-okolicach-brackiej-1959-rok-7641952/alternates/LANDSCAPE_1280" />
    Do połowy XIX wieku były ulicą peryferyjną, centrum Warszawy znajdowało się dalej na północ. Sytuację zmieniła budowa kolei, Aleje Jerozolimskie szybko stały się eleganckie - w kamieniach zainstalowały się firmy i sklepy, w restauracjach i kawiarniach tętniło życie towarzyskie. W czasie Powstania Warszawskiego znalazła się tu jedna z najważniejszych barykad. Po wojnie wybudowano reprezentacyjną siedzibę władz partii komunistycznej oraz Centralny Dom Towarowy.

## Budują tunele mające przeciwdziałać powodziom. To "najważniejsza w historii Lizbony" inwestycja
 - [https://tvn24.pl/tvnmeteo/ciekawostki/portugalii-lizbona-buduja-tunele-majace-przeciwdzialac-powodziom-to-najwazniejsza-w-historii-lizbony-inwestycja-st7663762?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/portugalii-lizbona-buduja-tunele-majace-przeciwdzialac-powodziom-to-najwazniejsza-w-historii-lizbony-inwestycja-st7663762?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T07:13:14+00:00

<img alt="Budują tunele mające przeciwdziałać powodziom. To " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kxlqxb-lizbona-portugalia-5548780/alternates/LANDSCAPE_1280" />
    W Lizbonie, stolicy Portugalii, rozpoczęto budowę dwóch podziemnych tuneli służących walce z powodziami, które regularnie nękają to miasto w okresie jesienno-zimowym. Jest to pierwsze takie przedsięwzięcie.

## 85 procent skuteczności. Dowódca raportuje o pracy obrony powietrznej w czasie rosyjskiej inwazji
 - [https://tvn24.pl/swiat/ukraina-dowodca-sil-powietrznych-mykola-oleszczuk-zestrzeliwanie-rosyjskich-rakiet-i-dronow-7663741?source=rss](https://tvn24.pl/swiat/ukraina-dowodca-sil-powietrznych-mykola-oleszczuk-zestrzeliwanie-rosyjskich-rakiet-i-dronow-7663741?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T06:07:09+00:00

<img alt="85 procent skuteczności. Dowódca raportuje o pracy obrony powietrznej w czasie rosyjskiej inwazji " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rs1tse-ukraina-wojsko-7663742/alternates/LANDSCAPE_1280" />
    Ukraińska obrona powietrzna zestrzeliwuje 85 procent rosyjskich rakiet i dronów - oznajmił dowódca sił powietrznych Mykoła Ołeszczuk. Od początku rosyjskiej inwazji zbrojnej w lutym 2022 roku zostało strąconych 1709 pocisków. Nie zawsze udaje się uniknąć ofiar, które mogą powodować spadające fragmenty zestrzelonych celów.

## Niezdrowa jakość powietrza o poranku. Sprawdź, gdzie jest smog
 - [https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-poniedzialek-1012024-sprawdz-jakosc-powietrza-w-swoim-miescie-niezdrowa-jakosc-powietrza-gdzie-jest-smog-st7663757?source=rss](https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-poniedzialek-1012024-sprawdz-jakosc-powietrza-w-swoim-miescie-niezdrowa-jakosc-powietrza-gdzie-jest-smog-st7663757?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T05:59:27+00:00

<img alt="Niezdrowa jakość powietrza o poranku. Sprawdź, gdzie jest smog" src="https://tvn24.pl/najnowsze/cdn-zdjecie-whopb3-smog-w-polsce-6629336/alternates/LANDSCAPE_1280" />
    Poniedziałkowy poranek przyniósł w niektórych regionach kraju smog. Gdzie powietrze ma złą średnią jakość? Sprawdź na mapie.

## Izrael zwolni część rezerwistów powołanych na wojnę z Hamasem. "Walka będzie trwała w przyszłym roku"
 - [https://tvn24.pl/swiat/izrael-zwolni-czesc-rezerwistow-powolanych-na-wojne-z-hamasem-7663645?source=rss](https://tvn24.pl/swiat/izrael-zwolni-czesc-rezerwistow-powolanych-na-wojne-z-hamasem-7663645?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T04:49:25+00:00

<img alt="Izrael zwolni część rezerwistów powołanych na wojnę z Hamasem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-e0p4ma-izraelscy-zolnierze-w-obozie-dla-uchodzcow-w-miescie-nablus-na-zachodnim-brzegu-7663668/alternates/LANDSCAPE_1280" />
    Izraelska armia zwolni w najbliższych dniach część rezerwistów powołanych na wojnę z Hamasem - poinformował w niedzielę rzecznik Sił Obronnych Izraela kontradmirał Daniel Hagari.

## Pogoda na dziś - poniedziałek 01.01. Pierwszy dzień roku pod znakiem opadów, na termometrach nawet 8 stopni
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-poniedzialek-0101-pierwszy-dzien-roku-pod-znakiem-opadow-na-termometrach-nawet-8-stopni-st7663624?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-poniedzialek-0101-pierwszy-dzien-roku-pod-znakiem-opadow-na-termometrach-nawet-8-stopni-st7663624?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T01:00:00+00:00

<img alt="Pogoda na dziś - poniedziałek 01.01. Pierwszy dzień roku pod znakiem opadów, na termometrach nawet 8 stopni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cgn47a-deszcz-5067709/alternates/LANDSCAPE_1280" />
    Poniedziałek, Nowy Rok, w niemal całej Polsce przyniesie opady deszczu. W niektórych regionach popada też deszcz ze śniegiem. Termometry wszędzie wskażą wartości powyżej zera.

## Papież podziękował za 2023 rok. Na placu Św. Piotra spotkał się z setkami wiernych
 - [https://tvn24.pl/swiat/watykan-papiez-franciszek-podziekowal-za-2023-rok-7663666?source=rss](https://tvn24.pl/swiat/watykan-papiez-franciszek-podziekowal-za-2023-rok-7663666?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-01T00:17:45+00:00

<img alt="Papież podziękował za 2023 rok. Na placu Św. Piotra spotkał się z setkami wiernych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bziot4-nieszpory-w-bazylice-watykanskiej-i-spotkanie-papieza-z-wiernymi-na-placu-sw-piotra-7663651/alternates/LANDSCAPE_1280" />
    Papież Franciszek podczas nieszporów odprawionych w bazylice watykańskiej w sylwestrowy wieczór podziękował za mijający 2023 rok. Po zakończeniu liturgii udał się na plac Świętego Piotra, gdzie obejrzał szopkę i pozdrowił kilkaset czekających tam na niego osób.

