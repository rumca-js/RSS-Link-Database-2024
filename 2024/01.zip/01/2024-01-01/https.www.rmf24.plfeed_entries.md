# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Kolejny europejski kraj zalegalizował małżeństwa jednopłciowe
 - [https://www.rmf24.pl/fakty/swiat/news-kolejny-europejski-kraj-zalegalizowal-malzenstwa-jednoplciow,nId,7243120](https://www.rmf24.pl/fakty/swiat/news-kolejny-europejski-kraj-zalegalizowal-malzenstwa-jednoplciow,nId,7243120)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T20:31:51+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-kolejny-europejski-kraj-zalegalizowal-malzenstwa-jednoplciow,nId,7243120"><img align="left" alt="Kolejny europejski kraj zalegalizował małżeństwa jednopłciowe" src="https://interia-s.pluscdn.pl/kolejny-europejski-kraj-zalegalizowal-malzenstwa-jednoplciow/000IBFNLTMND0T46-C307.jpg" /></a>​Nadejście nowego roku często oznacza zmiany. Takowa zaszła również w Estonii - od 1 stycznia małżeństwa osób tej samej płci stały się w tym kraju legalne. Prawo weszło w życie na mocy ustawy przyjętej przez estoński parlament 20 czerwca 2023 roku.</p><br clear="all" />

## Sąd Najwyższy uchylił kontrowersyjną ustawę Netanjahu
 - [https://www.rmf24.pl/fakty/swiat/news-izrael-sad-najwyzszy-uchylil-kontrowersyjna-ustawe-netanjahu,nId,7243096](https://www.rmf24.pl/fakty/swiat/news-izrael-sad-najwyzszy-uchylil-kontrowersyjna-ustawe-netanjahu,nId,7243096)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T18:43:35+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-izrael-sad-najwyzszy-uchylil-kontrowersyjna-ustawe-netanjahu,nId,7243096"><img align="left" alt="Sąd Najwyższy uchylił kontrowersyjną ustawę Netanjahu" src="https://interia-s.pluscdn.pl/sad-najwyzszy-uchylil-kontrowersyjna-ustawe-netanjahu/000IBFBU34A2F0QQ-C307.jpg" /></a>Kluczowa dla reformy sądownictwa ustawa, która spowodowała w Izraelu wielomiesięczne powszechne protesty, została uchylona przez izraelski Sąd Najwyższy. Forsowane przez rząd Benjamina Netanjahu prawo odbierało Sądowi Najwyższemu możliwość uchylania decyzji rządu, jeśli zostaną uznane one za &quot;nieracjonalne&quot;.</p><br clear="all" />

## Wojna prędko się nie skończy. A może to na rękę Ukraińcom?
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-wojna-predko-sie-nie-skonczy-a-moze-to-na-reke-ukraincom,nId,7243085](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-wojna-predko-sie-nie-skonczy-a-moze-to-na-reke-ukraincom,nId,7243085)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T18:25:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-wojna-predko-sie-nie-skonczy-a-moze-to-na-reke-ukraincom,nId,7243085"><img align="left" alt="Wojna prędko się nie skończy. A może to na rękę Ukraińcom?" src="https://interia-s.pluscdn.pl/wojna-predko-sie-nie-skonczy-a-moze-to-na-reke-ukraincom/000IBF8K2OBHKD7U-C307.jpg" /></a>Pełnoskalowa wojna w Ukrainie trwa już prawie dwa lata i końca nie widać. Jak przekonują brytyjskie źródła wywiadowcze, obie strony nie są w stanie dokonać istotnego przełomu na polu bitwy, dlatego nie spodziewajmy się rozstrzygnięć w 2024 roku. Rozwiązaniem może być jednak przeciągnięcie konfliktu do 2025 roku, ale i ten plan ma pewne wady.</p><br clear="all" />

## Skandaliczne słowa Pietrzaka. Reaguje Muzeum Auschwitz i minister sprawiedliwości
 - [https://www.rmf24.pl/fakty/polska/news-skandaliczne-slowa-jana-pietrzaka-reaguje-muzeum-auschwitz-i,nId,7243082](https://www.rmf24.pl/fakty/polska/news-skandaliczne-slowa-jana-pietrzaka-reaguje-muzeum-auschwitz-i,nId,7243082)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T17:23:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-skandaliczne-slowa-jana-pietrzaka-reaguje-muzeum-auschwitz-i,nId,7243082"><img align="left" alt="Skandaliczne słowa Pietrzaka. Reaguje Muzeum Auschwitz i minister sprawiedliwości" src="https://interia-s.pluscdn.pl/skandaliczne-slowa-pietrzaka-reaguje-muzeum-auschwitz-i-mini/000IBF143MTC5RGX-C307.jpg" /></a>&quot;Poprosiłem Prokuratora Krajowego Dariusza Barskiego o zajęcie się sprawą wypowiedzi Jana Pietrzaka na antenie Telewizji Republika oraz o wszczęcie śledztwa&quot; - poinformował minister sprawiedliwości Adam Bodnar. &quot;Mamy baraki dla imigrantów: w Auschwitz, w Majdanku, w Treblince, w Stutthofie&quot; - mówił satyryk, zastrzegając jednocześnie, że to &quot;okrutny żart&quot;. Muzeum Auschwitz uznało jego wypowiedź za &quot;zatrważający przejaw moralnego oraz intelektualnego zepsucia&quot;.</p><br clear="all" />

## Paweł Zalewski gościem Rozmowy o 7:00 w RMF FM i Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-pawel-zalewski-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf24,nId,7243076](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-pawel-zalewski-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf24,nId,7243076)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T16:32:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-pawel-zalewski-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf24,nId,7243076"><img align="left" alt="Paweł Zalewski gościem Rozmowy o 7:00 w RMF FM i Radiu RMF24" src="https://interia-s.pluscdn.pl/pawel-zalewski-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf24/000IBEYU9D5JC4JD-C307.jpg" /></a>Dlaczego rosyjska rakieta znalazła się nad Polską i przeleciała nad naszym terytorium 40 km? Skąd pewność, że opuściła nasze niebo? Czy wojsko i MON będą zawsze nas informować, kiedy dojdzie do takiego incydentu? Takie pytania padną w Rozmowie o 7:00 w RMF FM i internetowym Radiu RMF24. </p><br clear="all" />

## Putin grozi Ukraińcom. Zapowiedział nasilenie ataków
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-putin-grozi-ukraincom-zapowiedzial-nasilenie-atakow,nId,7243070](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-putin-grozi-ukraincom-zapowiedzial-nasilenie-atakow,nId,7243070)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T15:55:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-putin-grozi-ukraincom-zapowiedzial-nasilenie-atakow,nId,7243070"><img align="left" alt="Putin grozi Ukraińcom. Zapowiedział nasilenie ataków" src="https://interia-s.pluscdn.pl/putin-grozi-ukraincom-zapowiedzial-nasilenie-atakow/000IBERE73XFEM2B-C307.jpg" /></a>W sobotę siły ukraińskie ostrzelały przygraniczny Biełgorod; w ataku zginęło 20 osób, a ponad 100 zostało rannych. W poniedziałek do sprawy odniósł się Władimir Putin. Prezydent Rosji nazwał te wydarzenia &quot;aktem terroru&quot; i zapowiedział nasilenie ataków na ukraińskie cele.</p><br clear="all" />

## Prognoza pogody: Przed nami pochmurny i deszczowy tydzień
 - [https://www.rmf24.pl/pogoda/news-prognoza-pogody-przed-nami-pochmurny-i-deszczowy-tydzien,nId,7243055](https://www.rmf24.pl/pogoda/news-prognoza-pogody-przed-nami-pochmurny-i-deszczowy-tydzien,nId,7243055)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T14:54:00+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-prognoza-pogody-przed-nami-pochmurny-i-deszczowy-tydzien,nId,7243055"><img align="left" alt="Prognoza pogody: Przed nami pochmurny i deszczowy tydzień" src="https://interia-s.pluscdn.pl/prognoza-pogody-przed-nami-pochmurny-i-deszczowy-tydzien/000IBEND27TML4SN-C307.jpg" /></a>Pierwszy tydzień 2024 roku upłynie w Polsce pod znakiem chmur i deszczu oraz deszczu ze śniegiem. Na zachodzie i południu będzie dość ciepło – nawet do 10 stopni. W północno-wschodniej części kraju będzie chłodniej - termometry pokażą nawet -9 stopni. </p><br clear="all" />

## Rosjanie zniszczyli muzeum dowódcy UPA Romana Szuchewycza
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-rosjanie-zniszczyli-muzeum-dowodcy-upa-romana-szuchewycza,nId,7243053](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-rosjanie-zniszczyli-muzeum-dowodcy-upa-romana-szuchewycza,nId,7243053)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T14:43:13+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-rosjanie-zniszczyli-muzeum-dowodcy-upa-romana-szuchewycza,nId,7243053"><img align="left" alt="Rosjanie zniszczyli muzeum dowódcy UPA Romana Szuchewycza" src="https://interia-s.pluscdn.pl/rosjanie-zniszczyli-muzeum-dowodcy-upa-romana-szuchewycza/000IBDWSIDESW63Y-C307.jpg" /></a>Znów niespokojnie w Ukrainie. Rosjanie w noc sylwestrową użyli rekordowej liczby dronów szturmowych; nad Ukrainę nadleciało 90 dronów Shahed, 87 z nich udało się zestrzelić. Mer Lwowa Andrij Sadowy poinformował, że doszczętnie zniszczone zostało muzeum Romana Szuchewycza we Lwowie.</p><br clear="all" />

## Turniej Czterech Skoczni: Lanisek wygrał w Ga-Pa
 - [https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-turniej-czterech-skoczni-lanisek-wygral-w-ga-pa,nId,7243049](https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-turniej-czterech-skoczni-lanisek-wygral-w-ga-pa,nId,7243049)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T14:11:08+00:00

<p><a href="https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-turniej-czterech-skoczni-lanisek-wygral-w-ga-pa,nId,7243049"><img align="left" alt="Turniej Czterech Skoczni: Lanisek wygrał w Ga-Pa" src="https://interia-s.pluscdn.pl/turniej-czterech-skoczni-lanisek-wygral-w-ga-pa/000IBDV23A8APRQE-C307.jpg" /></a>Słoweniec Anze Lanisek wygrał konkurs skoków w Garmisch-Partenkirchen, drugi w 72. edycji narciarskiego Turnieju Czterech Skoczni. Najlepszy z Polaków - Aleksander Zniszczoł - zajął 21. miejsce. </p><br clear="all" />

## Turniej Czterech Skoczni: Trzech Polaków w drugiej serii w Ga-Pa
 - [https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-turniej-czterech-skoczni-trzech-polakow-w-drugiej-serii-w-ga,nId,7243049](https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-turniej-czterech-skoczni-trzech-polakow-w-drugiej-serii-w-ga,nId,7243049)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T14:11:08+00:00

<p><a href="https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-turniej-czterech-skoczni-trzech-polakow-w-drugiej-serii-w-ga,nId,7243049"><img align="left" alt="Turniej Czterech Skoczni: Trzech Polaków w drugiej serii w Ga-Pa" src="https://interia-s.pluscdn.pl/turniej-czterech-skoczni-trzech-polakow-w-drugiej-serii-w-ga/000IBDV23A8APRQE-C307.jpg" /></a>Trzech polskich skoczków awansowało do drugiej serii konkursu w Garmisch-Partenkirchen, drugiego w 72. edycji narciarskiego Turnieju Czterech Skoczni. To Piotr Żyła, Kamil Stoch i Aleksander Zniszczoł. Prowadzi Japończyk Ryoyu Kobayashi.</p><br clear="all" />

## Tragedia na Pomorzu. W mieszkaniu znaleziono ciało mężczyzny
 - [https://www.rmf24.pl/regiony/trojmiasto/news-tragedia-na-pomorzu-w-mieszkaniu-znaleziono-cialo-mezczyzny,nId,7243026](https://www.rmf24.pl/regiony/trojmiasto/news-tragedia-na-pomorzu-w-mieszkaniu-znaleziono-cialo-mezczyzny,nId,7243026)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T12:01:14+00:00

<p><a href="https://www.rmf24.pl/regiony/trojmiasto/news-tragedia-na-pomorzu-w-mieszkaniu-znaleziono-cialo-mezczyzny,nId,7243026"><img align="left" alt="Tragedia na Pomorzu. W mieszkaniu znaleziono ciało mężczyzny  " src="https://interia-s.pluscdn.pl/tragedia-na-pomorzu-w-mieszkaniu-znaleziono-cialo-mezczyzny/000IBDKACCPHC71K-C307.jpg" /></a>Policja pod nadzorem prokuratury wyjaśnia okoliczności tragedii w Miłocicach na Pomorzu. Nad ranem w jednym z mieszkań funkcjonariusze znaleźli ciało 30-letniego mężczyzny z ranami zadanymi nożem. Zatrzymana została była partnerka ofiary. </p><br clear="all" />

## Dwumiesięczna dziewczynka z pękniętą czaszką. Wszczęto śledztwo
 - [https://www.rmf24.pl/regiony/poznan/news-dwumiesieczna-dziewczynka-z-peknieta-czaszka-prokuratura-wsz,nId,7243025](https://www.rmf24.pl/regiony/poznan/news-dwumiesieczna-dziewczynka-z-peknieta-czaszka-prokuratura-wsz,nId,7243025)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T11:57:01+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-dwumiesieczna-dziewczynka-z-peknieta-czaszka-prokuratura-wsz,nId,7243025"><img align="left" alt="Dwumiesięczna dziewczynka z pękniętą czaszką. Wszczęto śledztwo" src="https://interia-s.pluscdn.pl/dwumiesieczna-dziewczynka-z-peknieta-czaszka-wszczeto-sledzt/000IBDJZ5QCGB73S-C307.jpg" /></a>Prokuratura Rejonowa w Kępnie wszczęła śledztwo w celu ustalenia przyczyny obrażeń powstałych u dwumiesięcznej dziewczynki. Trwają przesłuchania rodziców – poinformował rzecznik prasowy Prokuratury Okręgowej w Ostrowie Wlkp. Maciej Meler.</p><br clear="all" />

## Brytyjczycy rozważają ataki powietrzne na Huti
 - [https://www.rmf24.pl/fakty/swiat/news-brytyjczycy-rozwazaja-ataki-powietrzne-na-huti-w-tle-koszty-,nId,7243013](https://www.rmf24.pl/fakty/swiat/news-brytyjczycy-rozwazaja-ataki-powietrzne-na-huti-w-tle-koszty-,nId,7243013)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T11:26:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-brytyjczycy-rozwazaja-ataki-powietrzne-na-huti-w-tle-koszty-,nId,7243013"><img align="left" alt="Brytyjczycy rozważają ataki powietrzne na Huti" src="https://interia-s.pluscdn.pl/brytyjczycy-rozwazaja-ataki-powietrzne-na-huti/000IBDGJQ21112A8-C307.jpg" /></a>Wielka Brytania rozważa ataki powietrzne na powiązanych z Iranem bojowników Huti – wynika z artykułu opublikowanego przez brytyjskiego ministra obrony Granta Shappsa na łamach dziennika &quot;The Daily Telegraph&quot;. Brytyjczycy chcą w ten sposób odpowiedzieć na ostatnie akty terroru wobec statków handlowych na Morzu Czerwonym. Konflikt w tym regionie może okazać się jednak bardzo kosztowny, zwłaszcza dla Zachodu. </p><br clear="all" />

## Pożar domu w Głownie. Zginęła 69-letnia kobieta
 - [https://www.rmf24.pl/regiony/lodz/news-pozar-domu-w-glownie-zginela-69-letnia-kobieta,nId,7243007](https://www.rmf24.pl/regiony/lodz/news-pozar-domu-w-glownie-zginela-69-letnia-kobieta,nId,7243007)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T10:31:00+00:00

<p><a href="https://www.rmf24.pl/regiony/lodz/news-pozar-domu-w-glownie-zginela-69-letnia-kobieta,nId,7243007"><img align="left" alt="Pożar domu w Głownie. Zginęła 69-letnia kobieta" src="https://interia-s.pluscdn.pl/pozar-domu-w-glownie-zginela-69-letnia-kobieta/000IBDBWE91F33A3-C307.jpg" /></a>69-letnia kobieta zginęła w pożarze domu w Głownie w woj. łódzkim, który wybuchł w nocy z niedzieli na poniedziałek. Z płonącego budynku ewakuowała się 90-latka. Przyczyną pożaru była prawdopodobnie awaria elektrycznego urządzenia grzewczego.</p><br clear="all" />

## Gen. Pacek: Trzeci rok wojny będzie rokiem prawdy dla obu stron
 - [https://www.rmf24.pl/radio/news-gen-pacek-trzeci-rok-wojny-bedzie-rokiem-prawdy-dla-obu-stro,nId,7239855](https://www.rmf24.pl/radio/news-gen-pacek-trzeci-rok-wojny-bedzie-rokiem-prawdy-dla-obu-stro,nId,7239855)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T09:45:00+00:00

<p><a href="https://www.rmf24.pl/radio/news-gen-pacek-trzeci-rok-wojny-bedzie-rokiem-prawdy-dla-obu-stro,nId,7239855"><img align="left" alt="Gen. Pacek: Trzeci rok wojny będzie rokiem prawdy dla obu stron" src="https://interia-s.pluscdn.pl/gen-pacek-trzeci-rok-wojny-bedzie-rokiem-prawdy-dla-obu-stro/000IB5VUJ1IJ547N-C307.jpg" /></a>&quot;Rosja zakończyła rok 2023 ze sporą przewagą nad Ukrainą. Kijów wciąż stoi przed dużym wyzwaniem - jeżeli nie całkowitego pokonania przeciwnika, to przynajmniej zmuszenia go do przystąpienia do rozmów pokojowych na warunkach Kijowa, a nie Moskwy&quot; - mówił na antenie internetowego Radia RMF24 gen. Bogusław Pacek, podsumowując miniony rok na ukraińskim froncie.</p><br clear="all" />

## Mikst zapewnił wygraną z Hiszpanią. Polska w ćwierćfinale United Cup
 - [https://www.rmf24.pl/raporty/raport-tenis-na-rmf24/najnowszefakty/news-mikst-zapewnil-wygrana-z-hiszpania-polska-w-cwiercfinale-uni,nId,7242996](https://www.rmf24.pl/raporty/raport-tenis-na-rmf24/najnowszefakty/news-mikst-zapewnil-wygrana-z-hiszpania-polska-w-cwiercfinale-uni,nId,7242996)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T09:35:28+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-tenis-na-rmf24/najnowszefakty/news-mikst-zapewnil-wygrana-z-hiszpania-polska-w-cwiercfinale-uni,nId,7242996"><img align="left" alt="Mikst zapewnił wygraną z Hiszpanią. Polska w ćwierćfinale United Cup" src="https://interia-s.pluscdn.pl/mikst-zapewnil-wygrana-z-hiszpania-polska-w-cwiercfinale-uni/000IBD71HSMOKVOS-C307.jpg" /></a>Polska wygrała z Hiszpanią 2:1 w drugim meczu grupowym w Perth i awansowała do ćwierćfinału rozgrywanego w Australii tenisowego turnieju United Cup. Triumf zapewnił Biało-Czerwonym zwycięstwo miksta Iga Świątek - Hubert Hurkacz.</p><br clear="all" />

## ISW: Rosyjskie siły powietrznodesantowe ponoszą ciężkie straty na Ukrainie [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-isw-rosyjskie-sily-powietrznodesantowe-ponosza-ciezkie-strat,nId,7242988](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-isw-rosyjskie-sily-powietrznodesantowe-ponosza-ciezkie-strat,nId,7242988)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T08:59:48+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-isw-rosyjskie-sily-powietrznodesantowe-ponosza-ciezkie-strat,nId,7242988"><img align="left" alt="ISW: Rosyjskie siły powietrznodesantowe ponoszą ciężkie straty na Ukrainie [RELACJA]" src="https://interia-s.pluscdn.pl/isw-rosyjskie-sily-powietrznodesantowe-ponosza-ciezkie-strat/000IBD4B9PU3V69S-C307.jpg" /></a>Siły rosyjskie użyły w noc sylwestrową rekordowej liczby dronów szturmowych, a także atakowały Ukrainę rakietami S-300, Ch-31P i Ch-59 – poinformowały Siły Powietrzne Ukrainy. Nad Ukrainę nadleciało 90 dronów Shahed, zestrzelono 87 z nich. Prezydent Ukrainy Wołodymyr Zełenski w swoim orędziu noworocznym obiecał &quot;spustoszenie&quot; sił rosyjskich, które najechały jego kraj prawie dwa lata temu. Poniedziałek jest 677. dniem rosyjskiej agresji na Ukrainę. Najważniejsze informacje zbieramy w naszej relacji z 1.1.2024 r.</p><br clear="all" />

## Ministerstwo Edukacji i Nauki przestało istnieć. Są dwa nowe resorty
 - [https://www.rmf24.pl/polityka/news-ministerstwo-edukacji-i-nauki-przestalo-istniec-sa-dwa-nowe-,nId,7242989](https://www.rmf24.pl/polityka/news-ministerstwo-edukacji-i-nauki-przestalo-istniec-sa-dwa-nowe-,nId,7242989)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T08:59:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-ministerstwo-edukacji-i-nauki-przestalo-istniec-sa-dwa-nowe-,nId,7242989"><img align="left" alt="Ministerstwo Edukacji i Nauki przestało istnieć. Są dwa nowe resorty " src="https://interia-s.pluscdn.pl/ministerstwo-edukacji-i-nauki-przestalo-istniec-sa-dwa-nowe/000IBD46FMWMHH1P-C307.jpg" /></a>Dziś Ministerstwo Edukacji i Nauki przestało istnieć. W jego miejsce utworzono dwa resorty: Ministerstwo Edukacji Narodowej i Ministerstwo Nauki i Szkolnictwa Wyższego.</p><br clear="all" />

## Iwona Śledzińska-Katarasińska nie żyje. Była posłanka miała 82 lata
 - [https://www.rmf24.pl/polityka/news-iwona-sledzinska-katarasinska-nie-zyje-byla-poslanka-miala-8,nId,7242977](https://www.rmf24.pl/polityka/news-iwona-sledzinska-katarasinska-nie-zyje-byla-poslanka-miala-8,nId,7242977)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T08:27:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-iwona-sledzinska-katarasinska-nie-zyje-byla-poslanka-miala-8,nId,7242977"><img align="left" alt="Iwona Śledzińska-Katarasińska nie żyje. Była posłanka miała 82 lata" src="https://interia-s.pluscdn.pl/iwona-sledzinska-katarasinska-nie-zyje-byla-poslanka-miala-8/000IBD2DOSYFA4RI-C307.jpg" /></a>Zmarła Iwona Śledzińska-Katarasińska. Była posłanka Platformy Obywatelskiej miała 82 lata. Informację o jej śmierci podała marszałek Senatu Małgorzata Kidawa-Błońska.</p><br clear="all" />

## Pościg po ulicach Warszawy. Kierowca nie zatrzymał się do kontroli
 - [https://www.rmf24.pl/regiony/warszawa/news-poscig-po-ulicach-warszawy-kierowca-nie-zatrzymal-sie-do-kon,nId,7242973](https://www.rmf24.pl/regiony/warszawa/news-poscig-po-ulicach-warszawy-kierowca-nie-zatrzymal-sie-do-kon,nId,7242973)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T08:13:00+00:00

<p><a href="https://www.rmf24.pl/regiony/warszawa/news-poscig-po-ulicach-warszawy-kierowca-nie-zatrzymal-sie-do-kon,nId,7242973"><img align="left" alt="Pościg po ulicach Warszawy. Kierowca nie zatrzymał się do kontroli " src="https://interia-s.pluscdn.pl/poscig-po-ulicach-warszawy-kierowca-nie-zatrzymal-sie-do-kon/000IBD1M5SLJ0EYO-C307.jpg" /></a>Pościg po ulicach Warszawy za kierowcą, który nie zatrzymał się do kontroli. Mężczyzna miał półtora promila alkoholu w organizmie. </p><br clear="all" />

## Silne trzęsienie ziemi i tsunami w Japonii. Są zabici i ranni
 - [https://www.rmf24.pl/fakty/swiat/news-silne-trzesienie-ziemi-i-tsunami-w-japonii-sa-zabici-i-ranni,nId,7242968](https://www.rmf24.pl/fakty/swiat/news-silne-trzesienie-ziemi-i-tsunami-w-japonii-sa-zabici-i-ranni,nId,7242968)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T07:45:21+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-silne-trzesienie-ziemi-i-tsunami-w-japonii-sa-zabici-i-ranni,nId,7242968"><img align="left" alt="Silne trzęsienie ziemi i tsunami w Japonii. Są zabici i ranni" src="https://interia-s.pluscdn.pl/silne-trzesienie-ziemi-i-tsunami-w-japonii-sa-zabici-i-ranni/000IBFKWFV4WBR0M-C307.jpg" /></a>Środkową Japonię nawiedziło w poniedziałek silne trzęsienie ziemi o magnitudzie 7,5. Służby natychmiast wydały ostrzeżenie przed tsunami dla północno-zachodniego wybrzeża. Choć pierwotnie prognozowano wystąpienie fal o wysokości 5 m, to ostatecznie tsunami miało 1,2 m. W trzęsieniu ziemi życie straciło co najmniej 5 osób, a ponad 70 zostało rannych.</p><br clear="all" />

## Silne trzęsienie ziemi i tsunami w Japonii. Trwa szacowanie strat
 - [https://www.rmf24.pl/fakty/swiat/news-silne-trzesienie-ziemi-i-tsunami-w-japonii-trwa-szacowanie-s,nId,7242968](https://www.rmf24.pl/fakty/swiat/news-silne-trzesienie-ziemi-i-tsunami-w-japonii-trwa-szacowanie-s,nId,7242968)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T07:45:21+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-silne-trzesienie-ziemi-i-tsunami-w-japonii-trwa-szacowanie-s,nId,7242968"><img align="left" alt="Silne trzęsienie ziemi i tsunami w Japonii. Trwa szacowanie strat" src="https://interia-s.pluscdn.pl/silne-trzesienie-ziemi-i-tsunami-w-japonii-trwa-szacowanie-s/000IBD53T56HV1G9-C307.jpg" /></a>Środkową Japonię nawiedziło w poniedziałek silne trzęsienie ziemi o magnitudzie 7,5. Służby natychmiast wydały ostrzeżenie przed tsunami dla północno-zachodniego wybrzeża. Prognozowano wystąpienie fal o wysokości dochodzącej do 5 metrów. Takowych na szczęście nie zaobserwowano - najwyższa miała wysokość 1,2 m.</p><br clear="all" />

## Silne trzęsienie ziemi w Japonii. Ostrzeżenie przed tsunami: nawet 5-metrowe fale
 - [https://www.rmf24.pl/fakty/swiat/news-silne-trzesienie-ziemi-w-japonii-ostrzezenie-przed-tsunami-n,nId,7242968](https://www.rmf24.pl/fakty/swiat/news-silne-trzesienie-ziemi-w-japonii-ostrzezenie-przed-tsunami-n,nId,7242968)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T07:45:21+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-silne-trzesienie-ziemi-w-japonii-ostrzezenie-przed-tsunami-n,nId,7242968"><img align="left" alt="Silne trzęsienie ziemi w Japonii. Ostrzeżenie przed tsunami: nawet 5-metrowe fale" src="https://interia-s.pluscdn.pl/silne-trzesienie-ziemi-w-japonii-ostrzezenie-przed-tsunami-n/000IBD0NMVIX89ME-C307.jpg" /></a>Trzęsienie ziemi o magnitudzie 7,6 nawiedziło środkową Japonię. Na północno-zachodnim obszarze kraju wydano ostrzeżenie przed tsunami.</p><br clear="all" />

## Taylor Swift pobiła rekord Elvisa Presleya!
 - [https://www.rmf24.pl/kultura/news-taylor-swift-pobila-rekord-elvisa-presleya,nId,7242962](https://www.rmf24.pl/kultura/news-taylor-swift-pobila-rekord-elvisa-presleya,nId,7242962)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T07:45:00+00:00

<p><a href="https://www.rmf24.pl/kultura/news-taylor-swift-pobila-rekord-elvisa-presleya,nId,7242962"><img align="left" alt="Taylor Swift pobiła rekord Elvisa Presleya! " src="https://interia-s.pluscdn.pl/taylor-swift-pobila-rekord-elvisa-presleya/000IBD00QKPU3XGF-C307.jpg" /></a>Udało się! Taylor Swift oficjalnie pobiła rekord Elvisa Presleya! Ostatnia płyta amerykańskiej piosenkarki &quot;1989 (Taylor's Version)&quot; aż przez 68. tygodni znajdowała się na pierwszym miejscu listy Billboard 200. </p><br clear="all" />

## Sylwester w Zakopanem. Blisko 100 interwencji policji
 - [https://www.rmf24.pl/regiony/zakopane/news-sylwester-w-zakopanem-blisko-100-interwencji-policji,nId,7242956](https://www.rmf24.pl/regiony/zakopane/news-sylwester-w-zakopanem-blisko-100-interwencji-policji,nId,7242956)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T06:48:10+00:00

<p><a href="https://www.rmf24.pl/regiony/zakopane/news-sylwester-w-zakopanem-blisko-100-interwencji-policji,nId,7242956"><img align="left" alt="Sylwester w Zakopanem. Blisko 100 interwencji policji" src="https://interia-s.pluscdn.pl/sylwester-w-zakopanem-blisko-100-interwencji-policji/000IBCYBSKJ0E226-C307.jpg" /></a>Blisko sto razy interweniowali policjanci w sylwestrowa noc w Zakopanem i najbliższych miejscowościach. Jak mówi rzecznik tatrzańskich policjantów Roman Wieczorek, do największej liczby awantur doszło około godz. 1, kiedy zakończył się koncert w centrum miasta. Uczestniczyło w nim ok. 45 tysięcy osób. </p><br clear="all" />

## Liczba polskich miast przekroczyła tysiąc. Odwiedziliśmy jedno z nich
 - [https://www.rmf24.pl/regiony/news-liczba-polskich-miast-przekroczyla-tysiac-odwiedzilismy-jedn,nId,7241481](https://www.rmf24.pl/regiony/news-liczba-polskich-miast-przekroczyla-tysiac-odwiedzilismy-jedn,nId,7241481)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T06:00:37+00:00

<p><a href="https://www.rmf24.pl/regiony/news-liczba-polskich-miast-przekroczyla-tysiac-odwiedzilismy-jedn,nId,7241481"><img align="left" alt="Liczba polskich miast przekroczyła tysiąc. Odwiedziliśmy jedno z nich" src="https://interia-s.pluscdn.pl/liczba-polskich-miast-przekroczyla-tysiac-odwiedzilismy-jedn/000IBAC7HTRFRKK7-C307.jpg" /></a>Liczba miast w Polsce przekroczyła tysiąc. Od dziś na mapie naszego kraju jest ich dokładnie 1013. Wraz z początkiem 2024 r. prawa miejskie odzyskały 34 miejscowości. Wśród nich są między innymi Kikół w Kujawsko-Pomorskiem, Piszczac w Lubelskiem, Brody w Lubuskiem, Bogoria w Świętokrzyskiem i Osieck niedaleko Otwocka na Mazowszu.</p><br clear="all" />

## Niespokojna noc sylwestrowa w Ukrainie. Rosjanie zaatakowali dronami
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-niespokojna-noc-sylwestrowa-w-ukrainie-rosjanie-zaatakowali-,nId,7242953](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-niespokojna-noc-sylwestrowa-w-ukrainie-rosjanie-zaatakowali-,nId,7242953)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T05:52:25+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-niespokojna-noc-sylwestrowa-w-ukrainie-rosjanie-zaatakowali-,nId,7242953"><img align="left" alt="Niespokojna noc sylwestrowa w Ukrainie. Rosjanie zaatakowali dronami" src="https://interia-s.pluscdn.pl/niespokojna-noc-sylwestrowa-w-ukrainie-rosjanie-zaatakowali/000IBCWXDLVPVBVJ-C307.jpg" /></a>W noc sylwestrową Rosjanie zaatakowali południową Ukrainę kilkudziesięcioma dronami kamikadze. Jak przekazano, Ukraińcy zniszczyli ponad 50 z nich. W Odessie zginęła jedna osoba, a trzy zostały ranne.</p><br clear="all" />

## Ograniczenie sprzedaży energetyków i akcje szczepień. Co przyniesie 2024 rok w ochronie zdrowia?
 - [https://www.rmf24.pl/aktualnosci/news-ograniczenie-sprzedazy-energetykow-i-akcje-szczepien-co-przy,nId,7241415](https://www.rmf24.pl/aktualnosci/news-ograniczenie-sprzedazy-energetykow-i-akcje-szczepien-co-przy,nId,7241415)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T05:50:00+00:00

<p><a href="https://www.rmf24.pl/aktualnosci/news-ograniczenie-sprzedazy-energetykow-i-akcje-szczepien-co-przy,nId,7241415"><img align="left" alt="Ograniczenie sprzedaży energetyków i akcje szczepień. Co przyniesie 2024 rok w ochronie zdrowia?" src="https://interia-s.pluscdn.pl/ograniczenie-sprzedazy-energetykow-i-akcje-szczepien-co-przy/000IB9I0SP6RCF48-C307.jpg" /></a>Zapewnienie dostępu do szczepionek przeciwko koronawirusowi. Zakaz sprzedaży napojów energetycznych nieletnim. Poprawa sytuacji finansowej szpitali powiatowych. Te tematy mogą zdominować 2024 rok w polskim systemie ochrony zdrowia. Tak przewiduje dziennikarz RMF FM Michał Dobrołowicz.</p><br clear="all" />

## Intensywne opady śniegu w pierwszy dzień 2024 roku [PROGNOZA POGODY]
 - [https://www.rmf24.pl/pogoda/news-intensywne-opady-sniegu-w-pierwszy-dzien-2024-roku-prognoza-,nId,7242952](https://www.rmf24.pl/pogoda/news-intensywne-opady-sniegu-w-pierwszy-dzien-2024-roku-prognoza-,nId,7242952)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T05:46:00+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-intensywne-opady-sniegu-w-pierwszy-dzien-2024-roku-prognoza-,nId,7242952"><img align="left" alt="Intensywne opady śniegu w pierwszy dzień 2024 roku [PROGNOZA POGODY]  " src="https://interia-s.pluscdn.pl/intensywne-opady-sniegu-w-pierwszy-dzien-2024-roku-prognoza/000IBCWSGG0M4PBC-C307.jpg" /></a>&quot;Pierwszy dzień nowego roku będzie deszczowy. Spadnie też deszcz ze śniegiem i śnieg. Na termometrach będzie od 0 do 8 st. C&quot; - przekazała Agnieszka Prasek, synoptyk z Centralnego Biura Prognoz Instytutu Meteorologii i Gospodarki Wodnej. Dla części regionów wydano ostrzeżenia IMGW. </p><br clear="all" />

## TCS. Ciekawa rywalizacja w Ga-Pa, jak zaprezentują się Polacy?
 - [https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-tcs-ciekawa-rywalizacja-w-ga-pa-jak-zaprezentuja-sie-polacy,nId,7242951](https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-tcs-ciekawa-rywalizacja-w-ga-pa-jak-zaprezentuja-sie-polacy,nId,7242951)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T05:26:26+00:00

<p><a href="https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-tcs-ciekawa-rywalizacja-w-ga-pa-jak-zaprezentuja-sie-polacy,nId,7242951"><img align="left" alt="TCS. Ciekawa rywalizacja w Ga-Pa, jak zaprezentują się Polacy?" src="https://interia-s.pluscdn.pl/tcs-ciekawa-rywalizacja-w-ga-pa-jak-zaprezentuja-sie-polacy/000IBCWFNVHQA9FB-C307.jpg" /></a>Ciekawie zapowiada się rywalizacja w Garmisch-Partenkirchen w noworocznym konkursie 72. Turnieju Czterech Skoczni. Faworytów jest kilku, wśród nich lider po zawodach w Oberstdorfie Niemiec Andreas Wellinger. W pierwszej serii wystąpi czterech Polaków, ale wciąż nie zachwycają formą.</p><br clear="all" />

## Podatek od plastiku wchodzi w życie. Co to dla nas oznacza?
 - [https://www.rmf24.pl/fakty/polska/news-podatek-od-plastiku-wchodzi-w-zycie-co-to-dla-nas-oznacza,nId,7238441](https://www.rmf24.pl/fakty/polska/news-podatek-od-plastiku-wchodzi-w-zycie-co-to-dla-nas-oznacza,nId,7238441)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T05:09:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-podatek-od-plastiku-wchodzi-w-zycie-co-to-dla-nas-oznacza,nId,7238441"><img align="left" alt="Podatek od plastiku wchodzi w życie. Co to dla nas oznacza? " src="https://interia-s.pluscdn.pl/podatek-od-plastiku-wchodzi-w-zycie-co-to-dla-nas-oznacza/000IB48V3FW9MCT3-C307.jpg" /></a>Od dziś w Polsce obowiązuje podatek od plastiku. Nową daninę wprowadzono po to, aby ograniczyć zużycie tworzyw sztucznych, które w coraz większym stopniu zanieczyszczają środowisko. Za zakupy czy jedzenie na wynos możemy jednak zapłacić więcej – od 20 do 25 groszy za plastikowe opakowania. Właściciele biznesów będą z kolei musieli dbać o właściwy recykling. Maria Andrzejewska, dyrektor UNEP/GRID-Warszawa, biura programu ONZ ds. środowiska, z którą rozmawiał dziennikarz RMF FM Paweł Balinowski, uważa, że to ruch w dobrą stronę.</p><br clear="all" />

## Jakie mamy noworoczne postanowienia? Wyniki sondażu RMF FM
 - [https://www.rmf24.pl/fakty/polska/news-jakie-mamy-noworoczne-postanowienia-wyniki-sondazu-rmf-fm,nId,7241452](https://www.rmf24.pl/fakty/polska/news-jakie-mamy-noworoczne-postanowienia-wyniki-sondazu-rmf-fm,nId,7241452)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T05:07:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-jakie-mamy-noworoczne-postanowienia-wyniki-sondazu-rmf-fm,nId,7241452"><img align="left" alt="Jakie mamy noworoczne postanowienia? Wyniki sondażu RMF FM " src="https://interia-s.pluscdn.pl/jakie-mamy-noworoczne-postanowienia-wyniki-sondazu-rmf-fm/000IB9TS6MM8AR1S-C307.jpg" /></a>Ćwiczyć, schudnąć, zadbać o finanse i zdrowy styl życia - to najczęstsze postanowienia noworoczne słuchaczy RMF FM. W nowym, 2024 roku 24 proc. uczestników sondażu zrealizowanego przez Grupę RMF podejmie próbę realizacji postanowień. Aż 70 proc. osób nie ma tego w planach.  </p><br clear="all" />

## Atak rosyjskich dronów na Lwów
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-atak-rosyjskich-dronow-na-lwow,nId,7242948](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-atak-rosyjskich-dronow-na-lwow,nId,7242948)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T04:28:37+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-atak-rosyjskich-dronow-na-lwow,nId,7242948"><img align="left" alt="Atak rosyjskich dronów na Lwów" src="https://interia-s.pluscdn.pl/atak-rosyjskich-dronow-na-lwow/000IBCVDR49Y4N14-C307.jpg" /></a>Ukraińskie systemy obrony powietrznej odparły rosyjski atak dronów na Lwów – poinformował rano na Telegramie szef władz obwodu lwowskiego Maksym Kozycki.</p><br clear="all" />

## W noworocznym orędziu Zełenski obiecał "spustoszenie" sił rosyjskich
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-w-noworocznym-oredziu-zelenski-obiecal-spustoszenie-sil-rosy,nId,7241625](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-w-noworocznym-oredziu-zelenski-obiecal-spustoszenie-sil-rosy,nId,7241625)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-01T00:05:13+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-w-noworocznym-oredziu-zelenski-obiecal-spustoszenie-sil-rosy,nId,7241625"><img align="left" alt="W noworocznym orędziu Zełenski obiecał &quot;spustoszenie&quot; sił rosyjskich" src="https://interia-s.pluscdn.pl/w-noworocznym-oredziu-zelenski-obiecal-spustoszenie-sil-rosy/000IBC8OGVY9C0YT-C307.jpg" /></a>Prezydent Ukrainy Wołodymyr Zełenski w swoim orędziu noworocznym obiecał &quot;spustoszenie&quot; sił rosyjskich, które najechały jego kraj prawie dwa lata temu.</p><br clear="all" />

