# Source:CBC | Top Stories News, URL:https://www.cbc.ca/webfeed/rss/rss-topstories, language:en

## Israel's Supreme Court overturns polarizing law that limited judicial oversight of government
 - [https://www.cbc.ca/news/world/israel-supreme-court-overturns-netanyahu-overhaul-1.7072140?cmp=rss](https://www.cbc.ca/news/world/israel-supreme-court-overturns-netanyahu-overhaul-1.7072140?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T14:48:30+00:00

<img alt="A man speaks in front of flags of Israel." height="349" src="https://i.cbc.ca/1.7072153.1704135574!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/israel-politics.jpg" title="FILE - Israeli Prime Minister Benjamin Netanyahu chairs a cabinet meeting at the Kirya military base, which houses the Israeli Ministry of Defence, in Tel Aviv, Israel, Sunday, Dec . 24, 2023. Israel’s Supreme Court on Monday, Jan. 1, 2024, struck down a key component of Netanyahu’s contentious judicial overhaul, a decision that threatens to reopen the fissures in Israeli society that preceded the country’s ongoing war against Hamas.(AP Photo/Ohad Zwigenberg, Pool, File)" width="620" /><p>Israel's Supreme Court on Monday struck down a key component of Prime Minister Benjamin Netanyahu's contentious judicial overhaul, delivering a landmark decision that threatens to reopen the fissures in Israeli society that preceded the country's ongoing war against Hamas.</p>

## B.C. international student who helped thwart attempted Facebook Marketplace robbery urges public to be careful
 - [https://www.cbc.ca/news/canada/british-columbia/good-samaritan-who-helped-thwart-attempted-facebook-marketplace-robbery-urges-public-to-be-careful-1.7072037?cmp=rss](https://www.cbc.ca/news/canada/british-columbia/good-samaritan-who-helped-thwart-attempted-facebook-marketplace-robbery-urges-public-to-be-careful-1.7072037?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T13:15:25+00:00

<img alt="A man is pictured standing in front of a house with a cast over his hand and forearm. " height="349" src="https://i.cbc.ca/1.7072040.1704079899!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/meraj-ahmed.JPG" title="Meraj Ahmed was one of two bystanders who sprung into action when they witnessed a Facebook Marketplace sale-turned-robbery last Friday. " width="620" /><p>Meraj Ahmed, an international student from Bangladesh who works part time for a food delivery service, recounted the incident that resulted in a sliced tendon in his hand.</p>

## Russia and Ukraine report deaths in separate New Year's Day attacks
 - [https://www.cbc.ca/news/world/ukraine-russia-new-year-1.7072090?cmp=rss](https://www.cbc.ca/news/world/ukraine-russia-new-year-1.7072090?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T11:15:56+00:00

<img alt="A man cleans rubble and debris in the street." height="349" src="https://i.cbc.ca/1.7072098.1704124282!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/ukraine-crisis-shelling-attacks.JPG" title="A man removes debris in a street hit by overnight shelling in the course of Russia-Ukraine conflict in Donetsk, Russian-controlled Ukraine, January 1, 2024. " width="620" /><p>Ukrainian and Russian officials are both reporting deaths in separate attacks early in the new year. Ukraine’s shelling of the city of Donetsk on Monday killed four people, according to a Russian-installed official in the eastern region of Ukraine, while Russia’s air attacks killed a teenage boy, according to local officials. </p>

## These B.C. neuroscientists hope to help people with mental health challenges — using patients' own brainwaves
 - [https://www.cbc.ca/news/canada/british-columbia/neurofeedback-mental-health-experts-1.7061248?cmp=rss](https://www.cbc.ca/news/canada/british-columbia/neurofeedback-mental-health-experts-1.7061248?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T11:00:00+00:00

<img alt="A woman sits in an armchair watching a film with earphones on, as her head is connected to a set of cables behind her." height="349" src="https://i.cbc.ca/1.7061638.1702694913!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/woman-demonstrates-receiving-neurofeedback-therapy.jpg" title="A woman demonstrates a technique used in neurofeedback therapy. Wires connect points of her head to an electroencephalogram (EEG) monitor on a computer, as she watches a film on a screen." width="620" /><p>Neurofeedback therapy is more and more popular among people with mental health conditions from ADHD to PTSD and anxiety. But some researchers say more data is still needed.</p>

## Israel to pull some troops from Gaza as war against Hamas enters new phase
 - [https://www.cbc.ca/news/world/israel-hamas-war-day-87-1.7072063?cmp=rss](https://www.cbc.ca/news/world/israel-hamas-war-day-87-1.7072063?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T07:26:50+00:00

<img alt="Two Israeli soldiers walk with guns drawn." height="349" src="https://i.cbc.ca/1.7072064.1704110725!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/israel-palestinians-gaza.JPG" title="Israeli soldiers operate in the Gaza Strip amid the ongoing conflict between Israel and the Palestinian Islamist group Hamas, in this screen grab taken from a handout video released December 30, 2023. Israel Defense Forces/Handout via REUTERS    THIS IMAGE HAS BEEN SUPPLIED BY A THIRD PARTY" width="620" /><p>Israel is withdrawing some forces from Gaza to shift to more targeted operations against Hamas, and is partially returning reservists to civilian life to help the economy as the war looks set to last well into the new year, an Israeli official said.</p>

## Japan issues tsunami warnings after powerful earthquake, triggering evacuation warnings
 - [https://www.cbc.ca/news/world/japan-earthquake-1.7072055?cmp=rss](https://www.cbc.ca/news/world/japan-earthquake-1.7072055?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T05:58:35+00:00

<img alt="Cracks caused by an earthquake line pavement in front of buildings." height="349" src="https://i.cbc.ca/1.7072056.1704103932!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/japan-quake.JPG" title="Road cracks caused by an earthquake is seen in Wajima, Ishikawa prefecture, Japan January 1, 2024, in this photo released by Kyodo. Mandatory credit Kyodo via REUTERS ATTENTION EDITORS - THIS IMAGE WAS PROVIDED BY A THIRD PARTY. MANDATORY CREDIT. JAPAN OUT. NO COMMERCIAL OR EDITORIAL SALES IN JAPAN" width="620" /><p>Japan issued tsunami alerts and told people to evacuate seaside areas after a series of strong quakes on its western coastline Monday.</p>

## New Brunswick tenant wins 8-month fight to retrieve $850 security deposit
 - [https://www.cbc.ca/news/canada/new-brunswick/tenant-new-brunswick-landlord-damage-deposit-jaclyn-reinhart-1.7071258?cmp=rss](https://www.cbc.ca/news/canada/new-brunswick/tenant-new-brunswick-landlord-damage-deposit-jaclyn-reinhart-1.7071258?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T05:00:00+00:00

<img alt="woman in red sweater holding up document" height="349" src="https://i.cbc.ca/1.7071280.1703882149!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/jaclyn-reinhart.jpg" title="Jaclyn Reinhart in February 2023 holding up a termination-of-lease notice she received from her Coquitlam, B.C., landlord. Reinhart moved out of the apartment last spring and then spent months fighting to retrieve an $850 security deposit she paid on the unit in 2018." width="620" /><p>An $850 security deposit Jaclyn Reinhart paid back in 2018 to rent a Saint John apartment is finally being returned to her by the province but without interest and only after she spent months fighting the landlord to prove she was entitled to the money.</p>

## Loss of cooking skills has hurt our ability to adapt to rising food prices, experts say
 - [https://www.cbc.ca/radio/cooking-skills-decline-1.7064348?cmp=rss](https://www.cbc.ca/radio/cooking-skills-decline-1.7064348?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T04:00:00+00:00

<img alt="A young man in a baseball hat is seen from behind as he pours food from one bowl into another. A woman prepares food in the background." height="349" src="https://i.cbc.ca/1.7066329.1703214877!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/food-file-life-skills-20120123.jpg" title="A resident of a youth group home participates in a &quot;food literacy&quot; cooking class in London, Ontario, Tuesday, January 10, 2012. Although there is chatter all around them, the boys don&apos;t say much, intent on their tasks at the first of four life-skills cooking classes at Belton House" width="620" /><p>Skyrocketing prices have taken a big bite out of what Canadians are able to serve up for dinner but food economists say our ability to cope has been worsened by our collective decline in cooking skills.</p>

## New year, new tax measures — what to expect in 2024
 - [https://www.cbc.ca/news/politics/2024-federal-tax-changes-1.7067843?cmp=rss](https://www.cbc.ca/news/politics/2024-federal-tax-changes-1.7067843?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T04:00:00+00:00

<img alt="A sign indicating Airbnb rentals are not permitted is seen at the entrance to a condo tower, in Vancouver, on Thursday, November 23, 2023." height="349" src="https://i.cbc.ca/1.7053394.1702106634!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/housing-bc.JPG" title=" The provincial government last month introduced legislation to limit short-term rentals in many cities in British Columbia in an effort to put thousands of units back into the long-term rental pool, with the changes coming into effect in May. " width="620" /><p>New tax measures, and changes to existing ones, will begin affecting Canadians in 2024. But tax experts say the effects on most individuals are likely to be minor, unless they’re high-income earners.</p>

## They powered Montreal's garment industry. One woman is trying to honour them
 - [https://www.cbc.ca/news/canada/montreal/garment-industry-montreal-women-workers-1.7070893?cmp=rss](https://www.cbc.ca/news/canada/montreal/garment-industry-montreal-women-workers-1.7070893?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T04:00:00+00:00

<img alt="A senior woman in her friend&apos;s dining room resting her hands against the back of a chair. " height="349" src="https://i.cbc.ca/1.7070895.1703859851!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/ida-del-pinto-mosesso.JPG" title="Ida del Pinto Mosesso already had five years of experience as a seamstress in Italy when she started working at the Smart Brassieres Inc. manufacturing on Montreal’s Chabanel Street at 18-years-old in 1967." width="620" /><p>A Montreal woman is on a mission to honour the work done by immigrant women past and present in the city's clothing industry. At its peak in the 20th century, hundreds of companies were employing workers in the historic garment district.</p>

## What does 2024 have in store for the Canadian economy?
 - [https://www.cbc.ca/news/business/armstrong-inflation-economy-1.7066473?cmp=rss](https://www.cbc.ca/news/business/armstrong-inflation-economy-1.7066473?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T04:00:00+00:00

<img alt="Eggs in a grocery store fridge with a $4.99 price sign." height="349" src="https://i.cbc.ca/1.7066699.1704005559!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/soaring-egg-prices.jpg" title="A grocery store in Cheverly, Md., posts a sign to apologize for the increased price of their eggs, Tuesday, Jan. 10, 2023. (AP Photo/Susan Walsh)" width="620" /><p>Canadian consumers were clobbered by skyrocketing interest rates and stubbornly high price growth last year. They should see progress on both fronts in 2024. But the new year will also bring new challenges.</p>

## What's a coney dog and why is it so loved in Windsor?
 - [https://www.cbc.ca/news/canada/windsor/windsor-coney-dogs-history-1.7071227?cmp=rss](https://www.cbc.ca/news/canada/windsor/windsor-coney-dogs-history-1.7071227?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2024-01-01T04:00:00+00:00

<img alt="A box of two coney dogs" height="349" src="https://i.cbc.ca/1.7071979.1704056435!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/coney-dog.jpg" title="A coney dog is a hotdog topped with a chili-like sauce, yellow mustard and diced white onion. " width="620" /><p>It's a messy concoction of chili-like sauce, bright yellow mustard and finely diced white onion. It's best eaten with a napkin or five, and it'll probably end up spilled down your shirt. </p>

