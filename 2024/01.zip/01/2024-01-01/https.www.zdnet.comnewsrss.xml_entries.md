# Source:ZDNET, URL:https://www.zdnet.com/news/rss.xml, language:en-US

## Buy a Microsoft Office license for Mac or PC for just $40
 - [https://www.zdnet.com/article/buy-a-microsoft-office-license-for-mac-or-pc-for-just-40/#ftag=RSSbaffb68](https://www.zdnet.com/article/buy-a-microsoft-office-license-for-mac-or-pc-for-just-40/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-01-01T14:00:17+00:00

Access Microsoft Word, Excel, PowerPoint, and more with this deal for over 80% off Microsoft Office 2019.

## Join Sam's Club for just $25 right now
 - [https://www.zdnet.com/home-and-office/home-entertainment/join-sams-club-for-just-25-right-now/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/join-sams-club-for-just-25-right-now/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-01-01T13:00:17+00:00

Buy a one-year Sam's Club membership for half off right now, and save on everything from groceries to gadgets.

