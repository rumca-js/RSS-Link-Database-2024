# Source:Neowin, URL:https://www.neowin.net/news/rss/, language:en-us

## The Silicon Power 4TB UD90 internal SSD is back at its all time low price right now
 - [https://www.neowin.net/deals/the-silicon-power-4tb-ud90-internal-ssd-is-back-at-its-all-time-low-price-right-now](https://www.neowin.net/deals/the-silicon-power-4tb-ud90-internal-ssd-is-back-at-its-all-time-low-price-right-now)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T22:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1697490954_silicon-power-ssd_medium.jpg" /></div>The Silicon Power 4TB UD90 internal SSD offers read speeds of up to 5,000 MB per second and read speeds of up to 4,800 MB per second. It&#039;s currently at its all-time low price of $157.97. <a href="https://www.neowin.net/deals/the-silicon-power-4tb-ud90-internal-ssd-is-back-at-its-all-time-low-price-right-now">Read more...</a>

## Deal: Amazon Fire TV 40" 2-Series HD smart TV is currently at its lowest price
 - [https://www.neowin.net/deals/deal-amazon-fire-tv-40-2-series-hd-smart-tv-is-currently-at-its-lowest-price](https://www.neowin.net/deals/deal-amazon-fire-tv-40-2-series-hd-smart-tv-is-currently-at-its-lowest-price)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T18:46:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704132555_untitled_design_2_medium.jpg" /></div>Currently, the 40-inch Amazon Fire TV 2-Series HD smart TV with Alexa Voice Remote is available at its lowest price so get it for yourself while you can for an upgraded entertainment experience. <a href="https://www.neowin.net/deals/deal-amazon-fire-tv-40-2-series-hd-smart-tv-is-currently-at-its-lowest-price">Read more...</a>

## Microsoft President says the UK was "tough and fair" when it first blocked Activision deal
 - [https://www.neowin.net/news/microsoft-president-says-the-uk-was-tough-and-fair-when-it-first-blocked-activision-deal](https://www.neowin.net/news/microsoft-president-says-the-uk-was-tough-and-fair-when-it-first-blocked-activision-deal)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T18:30:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/03/1679079213_ms-bliz12_medium.jpg" /></div>Microsoft President Brad Smith said in a new interview that UK regulators were &quot;tough and fair&quot; when they initially blocked the company&#039;s deal to buy Activision Blizzard in April 2023. <a href="https://www.neowin.net/news/microsoft-president-says-the-uk-was-tough-and-fair-when-it-first-blocked-activision-deal">Read more...</a>

## Steam no longer supports Windows 7, 8, and 8.1
 - [https://www.neowin.net/news/steam-no-longer-supports-windows-7-8-and-81](https://www.neowin.net/news/steam-no-longer-supports-windows-7-8-and-81)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T18:16:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/03/1585594117_stim_medium.jpg" /></div>Customers sticking to the good-old (and dead) Windows 7 now have one more reason to ditch the operating system: as of January 1, 2023, Steam no longer supports Windows 7, 8, and 8.1. <a href="https://www.neowin.net/news/steam-no-longer-supports-windows-7-8-and-81">Read more...</a>

## Save 49% off lifetime upgrades to AOMEI Partition Assistant
 - [https://www.neowin.net/deals/save-49-off-lifetime-upgrades-to-aomei-partition-assistant](https://www.neowin.net/deals/save-49-off-lifetime-upgrades-to-aomei-partition-assistant)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T18:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/12/1639149503_aomei-partition-assistant_medium.jpg" /></div>Professional partition software for Windows — safely manage your disk partitions and protect system data for life! Or opt for the alternative deal and learn to play piano at 66% off! <a href="https://www.neowin.net/deals/save-49-off-lifetime-upgrades-to-aomei-partition-assistant">Read more...</a>

## You can snap up this Samsung 34-inch OLED PC monitor for a new all-time low price right now
 - [https://www.neowin.net/deals/you-can-snap-up-this-samsung-34-inch-oled-pc-monitor-for-a-new-all-time-low-price-right-now](https://www.neowin.net/deals/you-can-snap-up-this-samsung-34-inch-oled-pc-monitor-for-a-new-all-time-low-price-right-now)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T17:00:10+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/08/1661957272_odyssey_oled_pr_dl1_medium.jpg" /></div>The Samsung 34-inch Odyssey G8 QD-OLED WQHD curved gaming PC monitor is available now at Amazon for a new all-time low price of only $841.67, which gives you an over $600 discount off its MSRP. <a href="https://www.neowin.net/deals/you-can-snap-up-this-samsung-34-inch-oled-pc-monitor-for-a-new-all-time-low-price-right-now">Read more...</a>

## Python Real-World Projects ($36.99 Value) FREE eBook download offer ends Jan 2
 - [https://www.neowin.net/sponsored/python-real-world-projects-3699-value-free-ebook-download-offer-ends-jan-2](https://www.neowin.net/sponsored/python-real-world-projects-3699-value-free-ebook-download-offer-ends-jan-2)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T17:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/05/1557130260_python_medium.jpg" /></div>Tailored for beginners with a foundational understanding of class definitions, module creation, and Python&#039;s inherent data structures, this book is your gateway to programming excellence. <a href="https://www.neowin.net/sponsored/python-real-world-projects-3699-value-free-ebook-download-offer-ends-jan-2">Read more...</a>

## Escape Academy is free to claim on the Epic Games Store
 - [https://www.neowin.net/news/escape-academy-is-free-to-claim-on-the-epic-games-store](https://www.neowin.net/news/escape-academy-is-free-to-claim-on-the-epic-games-store)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T16:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704123311_escape_epic_medium.jpg" /></div>The Epic Games Store&#039;s first freebie of 2024 is Escape Academy. It is a puzzle game about solving various escape rooms as part of a special school for escapists. It offers both solo and co-op play. <a href="https://www.neowin.net/news/escape-academy-is-free-to-claim-on-the-epic-games-store">Read more...</a>

## Microsoft's Windows leader wants the dev team to fix a specific issue in the Start menu
 - [https://www.neowin.net/news/microsofts-windows-leader-wants-the-dev-team-to-fix-a-specific-issue-in-the-start-menu](https://www.neowin.net/news/microsofts-windows-leader-wants-the-dev-team-to-fix-a-specific-issue-in-the-start-menu)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T14:40:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1681312128_windows_11_start_menu_medium.jpg" /></div>Mikhail Parakhin, the recently named leader of Microsoft&#039;s Windows and Web Experiences team, admits that he wants the Windows dev team to deal with a specific issue in the Start menu. <a href="https://www.neowin.net/news/microsofts-windows-leader-wants-the-dev-team-to-fix-a-specific-issue-in-the-start-menu">Read more...</a>

## New report claims HBO's The Last of Us was the most BitTorrent-based pirated TV show of 2023
 - [https://www.neowin.net/news/new-report-claims-hbos-the-last-of-us-was-the-most-bittorrent-based-pirated-tv-show-of-2023](https://www.neowin.net/news/new-report-claims-hbos-the-last-of-us-was-the-most-bittorrent-based-pirated-tv-show-of-2023)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T14:12:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704116468_the-anarchists-s01-ka-1920_medium.jpg" /></div>A new report claims HBO&#039;s adaptation of the video game series The Last of Us was the most pirated television series online in 2023. The other top 9 most pirated shows came from streaming services <a href="https://www.neowin.net/news/new-report-claims-hbos-the-last-of-us-was-the-most-bittorrent-based-pirated-tv-show-of-2023">Read more...</a>

## Get this 2TB SK Hynix SDD for close to its all time low price with digital coupon
 - [https://www.neowin.net/deals/get-this-2tb-sk-hynix-sdd-for-close-to-its-all-time-low-price-with-digital-coupon](https://www.neowin.net/deals/get-this-2tb-sk-hynix-sdd-for-close-to-its-all-time-low-price-with-digital-coupon)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T13:34:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/05/1653383563_hynix_platinum_p41_(1)_medium.jpg" /></div>The 2TB SK Hynix Platinum P41 internal Gen4 SSD has read speeds of up to 7,000 MB per second. It&#039;s currently priced at $114.60 at Amazon if you use a digital coupon code for a limited time. <a href="https://www.neowin.net/deals/get-this-2tb-sk-hynix-sdd-for-close-to-its-all-time-low-price-with-digital-coupon">Read more...</a>

## Statcounter: No notable Windows 11 growth in December 2023 despite version 23H2 release
 - [https://www.neowin.net/news/statcounter-no-notable-windows-11-growth-in-december-2023-despite-version-23h2-release](https://www.neowin.net/news/statcounter-no-notable-windows-11-growth-in-december-2023-despite-version-23h2-release)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T11:26:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/04/1649144288_windows_logos_medium.jpg" /></div>According to the latest report from Statcounter, Windows 11&#039;s market share remains relatively unchanged despite the recent launch of version 23H2. Right now, the OS holds about 26.54% <a href="https://www.neowin.net/news/statcounter-no-notable-windows-11-growth-in-december-2023-despite-version-23h2-release">Read more...</a>

## Statcounter: Microsoft Edge edges near 12% market share for the first time
 - [https://www.neowin.net/news/statcounter-microsoft-edge-edges-near-12-market-share-for-the-first-time](https://www.neowin.net/news/statcounter-microsoft-edge-edges-near-12-market-share-for-the-first-time)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T10:24:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/03/1677666269_browsers_medium.jpg" /></div>The December 2023 report from Statcounter is out with new data about the most popular browsers. Microsoft Edge is getting closer to 12%, Safari takes a sudden dive, and Chrome fights back. <a href="https://www.neowin.net/news/statcounter-microsoft-edge-edges-near-12-market-share-for-the-first-time">Read more...</a>

## Larian offers another workaround for Baldur's Gate 3 Xbox players who are losing save games
 - [https://www.neowin.net/news/larian-offers-another-workaround-for-baldurs-gate-3-xbox-players-who-are-losing-save-games](https://www.neowin.net/news/larian-offers-another-workaround-for-baldurs-gate-3-xbox-players-who-are-losing-save-games)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-01T02:54:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1700081025_6_medium.jpg" /></div>The bug that is causing many Xbox players of Baldur&#039;s Gate 3 to lose their save games is still around, but developer Larian has posted a new workaround that could help some gamers. <a href="https://www.neowin.net/news/larian-offers-another-workaround-for-baldurs-gate-3-xbox-players-who-are-losing-save-games">Read more...</a>

