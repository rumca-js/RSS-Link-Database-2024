# Source:The Hill, URL:https://thehill.com/news/feed, language:en-US

## Harris: Rep. Johnson 'was a visionary, a pioneer, and a fighter'
 - [https://thehill.com/homenews/house/4384282-harris-rep-johnson-was-a-visionary-pioneer-fighter](https://thehill.com/homenews/house/4384282-harris-rep-johnson-was-a-visionary-pioneer-fighter)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-01-01T23:36:38+00:00

Vice President Harris lauded Texas Democrat Eddie Bernice Johnson Monday, the first registered nurse elected to the House of Representatives, who died Sunday at age 88. "Congresswoman Eddie Bernice Johnson was a visionary, a pioneer, and a fighter," Harris wrote in a statement. Harris — the first woman, first Black person and first Indian-American elected to...

## 'Strongest' solar flare since 2017 detected: Here's what to know
 - [https://thehill.com/homenews/nexstar_media_wire/4384088-strongest-solar-flare-since-2017-detected-heres-what-to-know](https://thehill.com/homenews/nexstar_media_wire/4384088-strongest-solar-flare-since-2017-detected-heres-what-to-know)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-01-01T20:39:56+00:00

NOAA's Space Weather Prediction Center shared an image of the solar flare, which peaked on New Year's Eve.

## Powerball jackpot reaches $810 million to start 2024: What to know ahead of next drawing
 - [https://thehill.com/homenews/nexstar_media_wire/4383988-powerball-jackpot-reaches-810-million-to-start-2024-what-to-know-ahead-of-next-drawing](https://thehill.com/homenews/nexstar_media_wire/4383988-powerball-jackpot-reaches-810-million-to-start-2024-what-to-know-ahead-of-next-drawing)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2024-01-01T16:50:47+00:00

A Powerball player (or players) could begin 2024 on a high note: the current jackpot has ballooned to an estimated $810 million ahead of Monday's drawing.

