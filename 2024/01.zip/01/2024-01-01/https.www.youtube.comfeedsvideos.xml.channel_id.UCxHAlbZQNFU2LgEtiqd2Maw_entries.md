# Source:C++ Weekly With Jason Turner, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw, language:en

## C++ Weekly - Ep 409 - How To 2x or 3x Your Developer Salary in 2024 (Plus Some Interviewing Tips!)
 - [https://www.youtube.com/watch?v=jWhFuK7J5HY](https://www.youtube.com/watch?v=jWhFuK7J5HY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCxHAlbZQNFU2LgEtiqd2Maw
 - date published: 2024-01-01T16:29:58+00:00

☟☟ Awesome T-Shirts! Sponsors! Books! ☟☟

This episode is sponsored by think-cell. https://think-cell.com/cppweekly

Episode Notes: https://github.com/lefticus/cpp_weekly/issues/194

T-SHIRTS AVAILABLE!

► The best C++ T-Shirts anywhere! https://my-store-d16a2f.creator-spring.com/


WANT MORE JASON?

► My Training Classes: http://emptycrate.com/training.html
► Follow me on twitter: https://twitter.com/lefticus


SUPPORT THE CHANNEL

► Patreon: https://www.patreon.com/lefticus 
► Github Sponsors: https://github.com/sponsors/lefticus
► Paypal Donation: https://www.paypal.com/donate/?hosted_button_id=PQ4A2V6ZZFQEU


GET INVOLVED

► Video Idea List: https://github.com/lefticus/cpp_weekly/issues


JASON'S BOOKS

► C++ Best Practices
  Amazon Paperback: https://amzn.to/3wpAU3Z
  Leanpub Ebook: https://leanpub.com/cppbestpractices


JASON'S PUZZLE BOOKS

► Object Lifetime Puzzlers Book 1
  Amazon Paperback: https://amzn.to/3g6Ervj
  Leanpub Ebook: https://leanpub.com/objectlifetimepuzzlers_

