# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Fireworks are probable cause of perchlorate contaminant in groundwater (2016)
 - [https://www.usgs.gov/news/national-news-release/fireworks-likely-caused-water-contamination-mount-rushmore](https://www.usgs.gov/news/national-news-release/fireworks-likely-caused-water-contamination-mount-rushmore)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T22:17:57+00:00

<p>Article URL: <a href="https://www.usgs.gov/news/national-news-release/fireworks-likely-caused-water-contamination-mount-rushmore">https://www.usgs.gov/news/national-news-release/fireworks-likely-caused-water-contamination-mount-rushmore</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38835845">https://news.ycombinator.com/item?id=38835845</a></p>
<p>Points: 91</p>
<p># Comments: 11</p>

## NERV Disaster Prevention
 - [https://nerv.app/en](https://nerv.app/en)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T21:16:27+00:00

<p>Article URL: <a href="https://nerv.app/en/">https://nerv.app/en/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38835419">https://news.ycombinator.com/item?id=38835419</a></p>
<p>Points: 7</p>
<p># Comments: 4</p>

## PyPy has moved to Git, GitHub
 - [https://www.pypy.org/posts/2023/12/pypy-moved-to-git-github.html](https://www.pypy.org/posts/2023/12/pypy-moved-to-git-github.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T20:06:42+00:00

<p>Article URL: <a href="https://www.pypy.org/posts/2023/12/pypy-moved-to-git-github.html">https://www.pypy.org/posts/2023/12/pypy-moved-to-git-github.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38834895">https://news.ycombinator.com/item?id=38834895</a></p>
<p>Points: 95</p>
<p># Comments: 25</p>

## Displaying Content as a Graph
 - [https://thisisimportant.net/posts/content-as-a-graph](https://thisisimportant.net/posts/content-as-a-graph)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T19:52:04+00:00

<p>Article URL: <a href="https://thisisimportant.net/posts/content-as-a-graph/">https://thisisimportant.net/posts/content-as-a-graph/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38834780">https://news.ycombinator.com/item?id=38834780</a></p>
<p>Points: 13</p>
<p># Comments: 3</p>

## Fail2ban Sucks
 - [https://j3s.sh/thought/fail2ban-sux.html](https://j3s.sh/thought/fail2ban-sux.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T19:32:54+00:00

<p>Article URL: <a href="https://j3s.sh/thought/fail2ban-sux.html">https://j3s.sh/thought/fail2ban-sux.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38834627">https://news.ycombinator.com/item?id=38834627</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## VW wouldn't help locate car with abducted child because GPS subscription expired
 - [https://arstechnica.com/tech-policy/2023/02/vw-wouldnt-help-locate-car-with-abducted-child-because-gps-subscription-expired](https://arstechnica.com/tech-policy/2023/02/vw-wouldnt-help-locate-car-with-abducted-child-because-gps-subscription-expired)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T19:13:41+00:00

<p>Article URL: <a href="https://arstechnica.com/tech-policy/2023/02/vw-wouldnt-help-locate-car-with-abducted-child-because-gps-subscription-expired/">https://arstechnica.com/tech-policy/2023/02/vw-wouldnt-help-locate-car-with-abducted-child-because-gps-subscription-expired/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38834460">https://news.ycombinator.com/item?id=38834460</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Mathematical Introduction to Deep Learning: Methods, Implementations, and Theory
 - [https://arxiv.org/abs/2310.20360](https://arxiv.org/abs/2310.20360)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T18:46:08+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2310.20360">https://arxiv.org/abs/2310.20360</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38834244">https://news.ycombinator.com/item?id=38834244</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Microdot: Yet Another Python Web Framework
 - [https://blog.miguelgrinberg.com/post/microdot-yet-another-python-web-framework](https://blog.miguelgrinberg.com/post/microdot-yet-another-python-web-framework)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T18:37:26+00:00

<p>Article URL: <a href="https://blog.miguelgrinberg.com/post/microdot-yet-another-python-web-framework">https://blog.miguelgrinberg.com/post/microdot-yet-another-python-web-framework</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38834156">https://news.ycombinator.com/item?id=38834156</a></p>
<p>Points: 45</p>
<p># Comments: 12</p>

## The changing economics of open-source software
 - [https://siliconangle.com/2023/12/31/changing-economics-open-source-software](https://siliconangle.com/2023/12/31/changing-economics-open-source-software)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T18:31:42+00:00

<p>Article URL: <a href="https://siliconangle.com/2023/12/31/changing-economics-open-source-software/">https://siliconangle.com/2023/12/31/changing-economics-open-source-software/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38834077">https://news.ycombinator.com/item?id=38834077</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Writing a TrueType font renderer
 - [https://axleos.com/writing-a-truetype-font-renderer](https://axleos.com/writing-a-truetype-font-renderer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T18:01:54+00:00

<p>Hi HN, happy new year!<p>TrueType is really a neat and fun format, packed with esoterica. This post gives some background on the problem of text rendering in general, explains how TrueType works under the hood, and contains lots of tidbits that I hope will be interesting.<p>There’s also a bunch of screenshots of the in-progress renderer stumbling over itself. I hope you enjoy the read!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833747">https://news.ycombinator.com/item?id=38833747</a></p>
<p>Points: 42</p>
<p># Comments: 4</p>

## A* Tricks for Videogame Path Finding
 - [https://timmastny.com/blog/a-star-tricks-for-videogame-path-finding](https://timmastny.com/blog/a-star-tricks-for-videogame-path-finding)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T17:52:21+00:00

<p>Article URL: <a href="https://timmastny.com/blog/a-star-tricks-for-videogame-path-finding/">https://timmastny.com/blog/a-star-tricks-for-videogame-path-finding/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833658">https://news.ycombinator.com/item?id=38833658</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## Fish shell 3.7.0 released, the last release branch before the full Rust rewrite
 - [https://github.com/fish-shell/fish-shell/releases/tag/3.7.0](https://github.com/fish-shell/fish-shell/releases/tag/3.7.0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T17:46:35+00:00

<p>Article URL: <a href="https://github.com/fish-shell/fish-shell/releases/tag/3.7.0">https://github.com/fish-shell/fish-shell/releases/tag/3.7.0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833609">https://news.ycombinator.com/item?id=38833609</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## 29 years ago today I went online. Netscape Navigator 1.0 was the tool I loved
 - [https://winworldpc.com/product/netscape-navigator/1x](https://winworldpc.com/product/netscape-navigator/1x)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T17:36:15+00:00

<p>Article URL: <a href="https://winworldpc.com/product/netscape-navigator/1x">https://winworldpc.com/product/netscape-navigator/1x</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833523">https://news.ycombinator.com/item?id=38833523</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## The quality of your life is the quality of the people you get to know
 - [https://jakeseliger.com/2023/11/28/the-quality-of-your-life-is-the-quality-of-the-people-you-get-to-know-illuminating-the-david-brooks-way](https://jakeseliger.com/2023/11/28/the-quality-of-your-life-is-the-quality-of-the-people-you-get-to-know-illuminating-the-david-brooks-way)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T17:33:40+00:00

<p>Article URL: <a href="https://jakeseliger.com/2023/11/28/the-quality-of-your-life-is-the-quality-of-the-people-you-get-to-know-illuminating-the-david-brooks-way/">https://jakeseliger.com/2023/11/28/the-quality-of-your-life-is-the-quality-of-the-people-you-get-to-know-illuminating-the-david-brooks-way/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833504">https://news.ycombinator.com/item?id=38833504</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Woman plugging in electric car (1912)
 - [https://nyheritage.contentdm.oclc.org/digital/collection/p16694coll20/id/35](https://nyheritage.contentdm.oclc.org/digital/collection/p16694coll20/id/35)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T17:33:11+00:00

<p>Article URL: <a href="https://nyheritage.contentdm.oclc.org/digital/collection/p16694coll20/id/35/">https://nyheritage.contentdm.oclc.org/digital/collection/p16694coll20/id/35/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833497">https://news.ycombinator.com/item?id=38833497</a></p>
<p>Points: 64</p>
<p># Comments: 12</p>

## The Procrastination Matrix (2015)
 - [https://waitbutwhy.com/2015/03/procrastination-matrix.html](https://waitbutwhy.com/2015/03/procrastination-matrix.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T17:24:00+00:00

<p>Article URL: <a href="https://waitbutwhy.com/2015/03/procrastination-matrix.html">https://waitbutwhy.com/2015/03/procrastination-matrix.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833440">https://news.ycombinator.com/item?id=38833440</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Ant Completes Process of Removing Jack Ma's Control
 - [https://www.bloomberg.com/news/articles/2023-12-30/ant-completes-process-of-removing-billionaire-jack-ma-s-control](https://www.bloomberg.com/news/articles/2023-12-30/ant-completes-process-of-removing-billionaire-jack-ma-s-control)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T17:23:42+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-12-30/ant-completes-process-of-removing-billionaire-jack-ma-s-control">https://www.bloomberg.com/news/articles/2023-12-30/ant-completes-process-of-removing-billionaire-jack-ma-s-control</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833434">https://news.ycombinator.com/item?id=38833434</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## DARPA Triage Challenge
 - [https://triagechallenge.darpa.mil](https://triagechallenge.darpa.mil)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T17:15:56+00:00

<p>Article URL: <a href="https://triagechallenge.darpa.mil/">https://triagechallenge.darpa.mil/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833381">https://news.ycombinator.com/item?id=38833381</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## All DMCA Notices Filed Against TorrentFreak in 2023 Were Bogus
 - [https://torrentfreak.com/all-dmca-notices-filed-against-torrentfreak-in-2023-were-bogus-240101](https://torrentfreak.com/all-dmca-notices-filed-against-torrentfreak-in-2023-were-bogus-240101)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T17:09:54+00:00

<p>Article URL: <a href="https://torrentfreak.com/all-dmca-notices-filed-against-torrentfreak-in-2023-were-bogus-240101/">https://torrentfreak.com/all-dmca-notices-filed-against-torrentfreak-in-2023-were-bogus-240101/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833325">https://news.ycombinator.com/item?id=38833325</a></p>
<p>Points: 67</p>
<p># Comments: 11</p>

## Happy Public Domain Day
 - [https://publicdomainreview.org/blog/2024/01/public-domain-day-2024](https://publicdomainreview.org/blog/2024/01/public-domain-day-2024)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T16:57:10+00:00

<p>Article URL: <a href="https://publicdomainreview.org/blog/2024/01/public-domain-day-2024/">https://publicdomainreview.org/blog/2024/01/public-domain-day-2024/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833208">https://news.ycombinator.com/item?id=38833208</a></p>
<p>Points: 18</p>
<p># Comments: 2</p>

## Show HN: DBChaos – A Database stress testing tool
 - [https://github.com/adaptive-scale/dbchaos](https://github.com/adaptive-scale/dbchaos)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T16:45:57+00:00

<p>Article URL: <a href="https://github.com/adaptive-scale/dbchaos">https://github.com/adaptive-scale/dbchaos</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38833113">https://news.ycombinator.com/item?id=38833113</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## What Happens When You Quit Sugar? [video]
 - [https://www.youtube.com/watch?v=86uC5fgraiI](https://www.youtube.com/watch?v=86uC5fgraiI)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T16:28:55+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=86uC5fgraiI">https://www.youtube.com/watch?v=86uC5fgraiI</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38832996">https://news.ycombinator.com/item?id=38832996</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## ChatGPT 3 validates misinformation, research finds
 - [https://uwaterloo.ca/news/media/large-language-models-validate-misinformation-research-finds](https://uwaterloo.ca/news/media/large-language-models-validate-misinformation-research-finds)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T15:23:32+00:00

<p>Article URL: <a href="https://uwaterloo.ca/news/media/large-language-models-validate-misinformation-research-finds">https://uwaterloo.ca/news/media/large-language-models-validate-misinformation-research-finds</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38832375">https://news.ycombinator.com/item?id=38832375</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Archaeologists reconstructed the burning of Jerusalem in 586 BCE
 - [https://arstechnica.com/science/2023/12/how-archaeologists-reconstructed-the-burning-of-jerusalem-in-586-bce](https://arstechnica.com/science/2023/12/how-archaeologists-reconstructed-the-burning-of-jerusalem-in-586-bce)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T15:18:47+00:00

<p>Article URL: <a href="https://arstechnica.com/science/2023/12/how-archaeologists-reconstructed-the-burning-of-jerusalem-in-586-bce/">https://arstechnica.com/science/2023/12/how-archaeologists-reconstructed-the-burning-of-jerusalem-in-586-bce/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38832336">https://news.ycombinator.com/item?id=38832336</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## OpenVoice: Versatile Instant Voice Cloning
 - [https://arxiv.org/abs/2312.01479](https://arxiv.org/abs/2312.01479)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T15:16:32+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2312.01479">https://arxiv.org/abs/2312.01479</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38832317">https://news.ycombinator.com/item?id=38832317</a></p>
<p>Points: 34</p>
<p># Comments: 6</p>

## Show HN: Page Replica – Tool for Web Scraping, Prerendering, and SEO Boost
 - [https://github.com/html5-ninja/page-replica](https://github.com/html5-ninja/page-replica)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T15:09:50+00:00

<p>Article URL: <a href="https://github.com/html5-ninja/page-replica">https://github.com/html5-ninja/page-replica</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38832257">https://news.ycombinator.com/item?id=38832257</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Generative AI flooding online crocheting spaces with unrealistic amigurumi pics
 - [https://twitter.com/LauraRbnsn/status/1741494511849578753](https://twitter.com/LauraRbnsn/status/1741494511849578753)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T14:48:43+00:00

<p>Article URL: <a href="https://twitter.com/LauraRbnsn/status/1741494511849578753">https://twitter.com/LauraRbnsn/status/1741494511849578753</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38832136">https://news.ycombinator.com/item?id=38832136</a></p>
<p>Points: 26</p>
<p># Comments: 11</p>

## Subject-First Commit Messages
 - [https://github.com/aaronjensen/software-development/blob/master/commit-messages.md](https://github.com/aaronjensen/software-development/blob/master/commit-messages.md)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T14:25:54+00:00

<p>Article URL: <a href="https://github.com/aaronjensen/software-development/blob/master/commit-messages.md">https://github.com/aaronjensen/software-development/blob/master/commit-messages.md</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38831991">https://news.ycombinator.com/item?id=38831991</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Writing Lesson, Comment on Friedman. Don't piss people off if you don't have to
 - [https://www.grumpy-economist.com/p/writing-lesson-comment-on-tom-friedman](https://www.grumpy-economist.com/p/writing-lesson-comment-on-tom-friedman)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T13:43:19+00:00

<p>Article URL: <a href="https://www.grumpy-economist.com/p/writing-lesson-comment-on-tom-friedman">https://www.grumpy-economist.com/p/writing-lesson-comment-on-tom-friedman</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38831710">https://news.ycombinator.com/item?id=38831710</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Show HN: I made TV Sort, a web-based game for ranking TV show episodes
 - [https://tvsort.com](https://tvsort.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T13:14:57+00:00

<p>Over this Christmas break, while discussing the best episodes of Frasier with my mother (as we tend to do when I get to see her), I thought about coming up with something that's less arbitrary than 1-10 ratings.<p>The result is TV Sort. It just uses a sorting algorithm, but... it's human powered. When the algorithm needs to compare two items, it asks you to compare them, and with that you end up with a full, thoroughly sorted episode list.<p>It uses TMDB, IMDB, and Wikipedia to extract episode information for any show, to help jog your memory when making episode comparisons.<p>It was a fun little experiment. And finally, I know -exactly- what I think the best and worst episodes are.[0]<p>Would love to hear your feedback, this is my first Show HN. ;)<p>Edit: I wrote a whole blog post about what went into making it, if anyone wants to read more of the technical detail behind it.[1]<p>[0]: <a href="https://tvsort.com/show/3452/matrix_01hjtxz2e1ewkrh44ja3mz0ss4" rel="nofollow">https:/

## Procrastination is connected to perfectionism
 - [https://solvingprocrastination.com/perfectionism](https://solvingprocrastination.com/perfectionism)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T12:42:01+00:00

<p>Article URL: <a href="https://solvingprocrastination.com/perfectionism/">https://solvingprocrastination.com/perfectionism/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38831446">https://news.ycombinator.com/item?id=38831446</a></p>
<p>Points: 28</p>
<p># Comments: 3</p>

## Oracle-samples/sd4j: Stable Diffusion pipeline in Java using ONNX Runtime
 - [https://github.com/oracle-samples/sd4j](https://github.com/oracle-samples/sd4j)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T12:30:14+00:00

<p>Article URL: <a href="https://github.com/oracle-samples/sd4j">https://github.com/oracle-samples/sd4j</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38831379">https://news.ycombinator.com/item?id=38831379</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Standard Ebooks
 - [https://standardebooks.org](https://standardebooks.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T11:51:35+00:00

<p>Article URL: <a href="https://standardebooks.org/">https://standardebooks.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38831219">https://news.ycombinator.com/item?id=38831219</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Orange Site Hit
 - [https://blog.davep.org/2024/01/01/oshit.html](https://blog.davep.org/2024/01/01/oshit.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T11:16:20+00:00

<p>Article URL: <a href="https://blog.davep.org/2024/01/01/oshit.html">https://blog.davep.org/2024/01/01/oshit.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38831083">https://news.ycombinator.com/item?id=38831083</a></p>
<p>Points: 39</p>
<p># Comments: 16</p>

## Welcome to the public domain, Steamboat Willie
 - [https://mastodon.archive.org/@internetarchive/111679346484777332](https://mastodon.archive.org/@internetarchive/111679346484777332)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T10:05:17+00:00

<p>Article URL: <a href="https://mastodon.archive.org/@internetarchive/111679346484777332">https://mastodon.archive.org/@internetarchive/111679346484777332</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830824">https://news.ycombinator.com/item?id=38830824</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Fixing Annoying Blue Standby Lights
 - [https://www.fullcircuit.com/blog/fixing-annoying-blue-standby-lights](https://www.fullcircuit.com/blog/fixing-annoying-blue-standby-lights)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T09:55:51+00:00

<p>Article URL: <a href="https://www.fullcircuit.com/blog/fixing-annoying-blue-standby-lights">https://www.fullcircuit.com/blog/fixing-annoying-blue-standby-lights</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830782">https://news.ycombinator.com/item?id=38830782</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Taligent's Guide to Designing Programs [pdf]
 - [https://bitsavers.org/pdf/apple/mac/pink/Taligent_-_Taligents_Guide_to_Designing_Programs_1994.pdf](https://bitsavers.org/pdf/apple/mac/pink/Taligent_-_Taligents_Guide_to_Designing_Programs_1994.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T09:52:52+00:00

<p>Article URL: <a href="https://bitsavers.org/pdf/apple/mac/pink/Taligent_-_Taligents_Guide_to_Designing_Programs_1994.pdf">https://bitsavers.org/pdf/apple/mac/pink/Taligent_-_Taligents_Guide_to_Designing_Programs_1994.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830767">https://news.ycombinator.com/item?id=38830767</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Show HN: Durdraw – a modern ANSI art editor for modern Unix terminals
 - [https://github.com/cmang/durdraw](https://github.com/cmang/durdraw)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T09:33:47+00:00

<p>I've been working on an ANSI art editor off and on for a while. It works like a traditional ANSI text editor, except it supports 256 colors, Unicode and CP437 encoding, frame-based animation, custom UI themes, terminal mouse input, HTML and IRC color output, and runs in Utf-8 terminals.<p>It's written in Python and curses, and is fairly portable across Unix systems. If you have ever used TheDraw or Aciddraw, the user interface is similar. It can also load/convert, view, edit and save most CP437 (MS-DOS style) ANSI art in a Utf-8 terminal, so you can view ANSI artscene packs in the comfort of your favorite terminal, and even convert them into 256 color Unicode ANSI.<p>I've been using it for my own ANSI and ASCII art for a number of years, and hope this will help artists work with less restrictions. I think there is a lot of opportunity for ANSI art beyond its dominant 16-color Code Page 437 format. We all have computers with amazing ANSI terminals with modern features. Shouldn't th

## Use any web browser as GUI, with Zig in the back end and HTML5 in the front end
 - [https://github.com/webui-dev/zig-webui](https://github.com/webui-dev/zig-webui)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T09:30:39+00:00

<p>Article URL: <a href="https://github.com/webui-dev/zig-webui">https://github.com/webui-dev/zig-webui</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830673">https://news.ycombinator.com/item?id=38830673</a></p>
<p>Points: 10</p>
<p># Comments: 6</p>

## Web browser as GUI, with your preferred language in the backend
 - [https://github.com/webui-dev/webui](https://github.com/webui-dev/webui)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T09:30:39+00:00

<p>Article URL: <a href="https://github.com/webui-dev/webui">https://github.com/webui-dev/webui</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830673">https://news.ycombinator.com/item?id=38830673</a></p>
<p>Points: 82</p>
<p># Comments: 75</p>

## Saxo Bank's Outrageous Predictions 2024
 - [https://www.home.saxo/insights/news-and-research/thought-leadership/outrageous-predictions](https://www.home.saxo/insights/news-and-research/thought-leadership/outrageous-predictions)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T08:45:34+00:00

<p>Article URL: <a href="https://www.home.saxo/insights/news-and-research/thought-leadership/outrageous-predictions">https://www.home.saxo/insights/news-and-research/thought-leadership/outrageous-predictions</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830484">https://news.ycombinator.com/item?id=38830484</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Show HN: Made some progress on character consistency for AI storytelling
 - [https://app.artflow.ai/character-builder?feature=characters](https://app.artflow.ai/character-builder?feature=characters)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T08:44:06+00:00

<p>It has been a major challenge for all AI storytellers to create images of a character with consistent face/hair/outfit/body type across different scenes. We took a stab at this problem at Artflow’s and we'd like to show it to you to gather some early feedback.<p>Please note that this is still an early version and we fully admit it's not perfect.<p>See a tutorial/sample here: <a href="https://app.artflow.ai/releases#release%203.5.1%202023-11-29" rel="nofollow">https://app.artflow.ai/releases#release%203.5.1%202023-11-29</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830482">https://news.ycombinator.com/item?id=38830482</a></p>
<p>Points: 13</p>
<p># Comments: 11</p>

## Magnitude 7.4 earthquake stikes Japan, major tsunami warning issued for Ishikawa
 - [https://www3.nhk.or.jp/nhkworld/en/news/20240101_15](https://www3.nhk.or.jp/nhkworld/en/news/20240101_15)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T07:41:22+00:00

<p>Article URL: <a href="https://www3.nhk.or.jp/nhkworld/en/news/20240101_15/">https://www3.nhk.or.jp/nhkworld/en/news/20240101_15/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830281">https://news.ycombinator.com/item?id=38830281</a></p>
<p>Points: 44</p>
<p># Comments: 11</p>

## Disney's Mickey Mouse enter public domain
 - [https://www.bbc.com/news/entertainment-arts-67833411](https://www.bbc.com/news/entertainment-arts-67833411)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T07:35:09+00:00

<p>Article URL: <a href="https://www.bbc.com/news/entertainment-arts-67833411">https://www.bbc.com/news/entertainment-arts-67833411</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830264">https://news.ycombinator.com/item?id=38830264</a></p>
<p>Points: 22</p>
<p># Comments: 6</p>

## Steamboat Willie [video]
 - [https://www.youtube.com/watch?v=hmzO--ox7X0](https://www.youtube.com/watch?v=hmzO--ox7X0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T07:20:44+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=hmzO--ox7X0">https://www.youtube.com/watch?v=hmzO--ox7X0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830223">https://news.ycombinator.com/item?id=38830223</a></p>
<p>Points: 28</p>
<p># Comments: 7</p>

## Git Things
 - [https://matklad.github.io/2023/12/31/git-things.html#Git-Things](https://matklad.github.io/2023/12/31/git-things.html#Git-Things)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T07:10:19+00:00

<p>Article URL: <a href="https://matklad.github.io/2023/12/31/git-things.html#Git-Things">https://matklad.github.io/2023/12/31/git-things.html#Git-Things</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830194">https://news.ycombinator.com/item?id=38830194</a></p>
<p>Points: 27</p>
<p># Comments: 4</p>

## Website Impersonating a Desktop Environment
 - [https://dustinbrett.com](https://dustinbrett.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T06:48:45+00:00

<p>Article URL: <a href="https://dustinbrett.com/">https://dustinbrett.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38830132">https://news.ycombinator.com/item?id=38830132</a></p>
<p>Points: 47</p>
<p># Comments: 14</p>

## 27 Years Ago, Steve Jobs Said the Best Employees Focus on Content, Not Process
 - [https://www.inc.com/jeff-haden/27-years-ago-steve-jobs-said-best-employees-focus-on-content-not-process-workplace-research-shows-he-was-right.html](https://www.inc.com/jeff-haden/27-years-ago-steve-jobs-said-best-employees-focus-on-content-not-process-workplace-research-shows-he-was-right.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T05:04:12+00:00

<p>Article URL: <a href="https://www.inc.com/jeff-haden/27-years-ago-steve-jobs-said-best-employees-focus-on-content-not-process-workplace-research-shows-he-was-right.html">https://www.inc.com/jeff-haden/27-years-ago-steve-jobs-said-best-employees-focus-on-content-not-process-workplace-research-shows-he-was-right.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38829845">https://news.ycombinator.com/item?id=38829845</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## Beginner dev looks at how YouTube sends videos
 - [https://vincentsg.dev/dec31?](https://vincentsg.dev/dec31?)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T04:45:13+00:00

<p>Article URL: <a href="https://vincentsg.dev/dec31?">https://vincentsg.dev/dec31?</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38829786">https://news.ycombinator.com/item?id=38829786</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## Using a Markov chain to generate readable nonsense with 20 lines of Python
 - [https://benhoyt.com/writings/markov-chain](https://benhoyt.com/writings/markov-chain)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T04:40:15+00:00

<p>Article URL: <a href="https://benhoyt.com/writings/markov-chain/">https://benhoyt.com/writings/markov-chain/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38829772">https://news.ycombinator.com/item?id=38829772</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Meshtastic: An open source, off-grid, decentralized, mesh network
 - [https://meshtastic.org](https://meshtastic.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T02:57:56+00:00

<p>Article URL: <a href="https://meshtastic.org/">https://meshtastic.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38829448">https://news.ycombinator.com/item?id=38829448</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Record Number of Tornadoes in the NWS Chicago Forecast Area in 2023
 - [https://www.weather.gov/lot/2023tornadoes](https://www.weather.gov/lot/2023tornadoes)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T02:33:52+00:00

<p>Article URL: <a href="https://www.weather.gov/lot/2023tornadoes">https://www.weather.gov/lot/2023tornadoes</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38829322">https://news.ycombinator.com/item?id=38829322</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Show HN: Pokemon prototype game made with JavaScript and p5.js
 - [https://github.com/JSLegendDev/Pokemon-p5js](https://github.com/JSLegendDev/Pokemon-p5js)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T02:30:59+00:00

<p>Article URL: <a href="https://github.com/JSLegendDev/Pokemon-p5js">https://github.com/JSLegendDev/Pokemon-p5js</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38829303">https://news.ycombinator.com/item?id=38829303</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## Merkle Town: Explore the certificate transparency ecosystem
 - [https://ct.cloudflare.com](https://ct.cloudflare.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T02:17:47+00:00

<p>Article URL: <a href="https://ct.cloudflare.com/">https://ct.cloudflare.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38829235">https://news.ycombinator.com/item?id=38829235</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Show HN: Raiseto – Discover and Share Ideas
 - [https://raiseto.com](https://raiseto.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T02:04:26+00:00

<p>Article URL: <a href="https://raiseto.com/">https://raiseto.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38829177">https://news.ycombinator.com/item?id=38829177</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Man Thrown Off Delta Flight for Offering to Fix Broken Inflight Entertainment
 - [https://www.paddleyourownkanoo.com/2023/12/30/man-says-he-was-thrown-off-delta-air-flight-because-he-offered-to-fix-broken-inflight-entertainment-system](https://www.paddleyourownkanoo.com/2023/12/30/man-says-he-was-thrown-off-delta-air-flight-because-he-offered-to-fix-broken-inflight-entertainment-system)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T01:27:18+00:00

<p>Article URL: <a href="https://www.paddleyourownkanoo.com/2023/12/30/man-says-he-was-thrown-off-delta-air-flight-because-he-offered-to-fix-broken-inflight-entertainment-system/">https://www.paddleyourownkanoo.com/2023/12/30/man-says-he-was-thrown-off-delta-air-flight-because-he-offered-to-fix-broken-inflight-entertainment-system/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38829005">https://news.ycombinator.com/item?id=38829005</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Ask HN: Is there a data set for GitHub repos associated with academic papers?
 - [https://news.ycombinator.com/item?id=38828739](https://news.ycombinator.com/item?id=38828739)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T00:38:45+00:00

<p>Codes are often included in academic publications however I haven't seen a list of repos anywhere that is connected to doi numbers from papers or zenodo. Does this already exist somewhere or should I need to create it?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38828739">https://news.ycombinator.com/item?id=38828739</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Ask HN: What software/tech blogs/magazines should I be reading in 2024?
 - [https://news.ycombinator.com/item?id=38828682](https://news.ycombinator.com/item?id=38828682)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T00:27:12+00:00

<p>Currently read the mainstream things: Stratechery, Wired, Verge, Arstechnica, etc. but looking to diversify my sources in 2024. Any recommendations?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38828682">https://news.ycombinator.com/item?id=38828682</a></p>
<p>Points: 23</p>
<p># Comments: 10</p>

## Major Alzheimer paper retracted by former Stanford president after a decade
 - [https://stanforddaily.com/2023/12/31/blockbuster-alzheimers-paper-retracted-by-former-stanford-president-after-a-decade-of-resistance](https://stanforddaily.com/2023/12/31/blockbuster-alzheimers-paper-retracted-by-former-stanford-president-after-a-decade-of-resistance)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T00:18:13+00:00

<p>Article URL: <a href="https://stanforddaily.com/2023/12/31/blockbuster-alzheimers-paper-retracted-by-former-stanford-president-after-a-decade-of-resistance/">https://stanforddaily.com/2023/12/31/blockbuster-alzheimers-paper-retracted-by-former-stanford-president-after-a-decade-of-resistance/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38828628">https://news.ycombinator.com/item?id=38828628</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Nim on a Real-Time Operating System: Apache NuttX RTOS and Ox64 BL808 SBC
 - [https://lupyuen.codeberg.page/articles/nim.html](https://lupyuen.codeberg.page/articles/nim.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T00:15:45+00:00

<p>Article URL: <a href="https://lupyuen.codeberg.page/articles/nim.html">https://lupyuen.codeberg.page/articles/nim.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38828619">https://news.ycombinator.com/item?id=38828619</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Stuff we figured out about AI in 2023
 - [https://simonwillison.net/2023/Dec/31/ai-in-2023](https://simonwillison.net/2023/Dec/31/ai-in-2023)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-01-01T00:08:38+00:00

<p>Article URL: <a href="https://simonwillison.net/2023/Dec/31/ai-in-2023/">https://simonwillison.net/2023/Dec/31/ai-in-2023/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=38828594">https://news.ycombinator.com/item?id=38828594</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

