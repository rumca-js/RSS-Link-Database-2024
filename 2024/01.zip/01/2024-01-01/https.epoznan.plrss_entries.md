# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Od dziś ważna zmiana dla właścicieli samochodów!
 - [https://epoznan.pl/news-news-146515-od_dzis_wazna_zmiana_dla_wlascicieli_samochodow?rss=1](https://epoznan.pl/news-news-146515-od_dzis_wazna_zmiana_dla_wlascicieli_samochodow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T17:00:00+00:00

Wraz z nowym rokiem weszło nowe prawo.

## Baza LPR z Poznania od dziś pełni dyżur całodobowy
 - [https://epoznan.pl/news-news-146514-baza_lpr_z_poznania_od_dzis_pelni_dyzur_calodobowy?rss=1](https://epoznan.pl/news-news-146514-baza_lpr_z_poznania_od_dzis_pelni_dyzur_calodobowy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T16:30:00+00:00

1 stycznia 2024 roku w Lotniczym Pogotowiu Ratunkowym został zrealizowany plan, który zakładał funkcjonowanie sześciu całodobowych baz HEMS.

## Szukają tego mężczyzny. Rozpoznajesz?
 - [https://epoznan.pl/news-news-146513-szukaja_tego_mezczyzny_rozpoznajesz?rss=1](https://epoznan.pl/news-news-146513-szukaja_tego_mezczyzny_rozpoznajesz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T16:00:00+00:00

Sprawa dotyczy kradzieży.

## Zamiast 500 plus jest 800 plus. Pierwsze przelewy są już na kontach
 - [https://epoznan.pl/news-news-146512-zamiast_500_plus_jest_800_plus_pierwsze_przelewy_sa_juz_na_kontach?rss=1](https://epoznan.pl/news-news-146512-zamiast_500_plus_jest_800_plus_pierwsze_przelewy_sa_juz_na_kontach?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T15:45:00+00:00

Od 1 stycznia 2024 roku kwota świadczenia wychowawczego zostanie podniesiona z 500 zł do 800 zł.

## Policjanci weszli do domu 74-latka. Podejrzenia się sprawdziły
 - [https://epoznan.pl/news-news-146511-policjanci_weszli_do_domu_74_latka_podejrzenia_sie_sprawdzily?rss=1](https://epoznan.pl/news-news-146511-policjanci_weszli_do_domu_74_latka_podejrzenia_sie_sprawdzily?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T15:30:00+00:00

Znaleziono nielegalny towar.

## Wyjątkowe propozycje za jedyną złotówkę w na obiektach POSiR. Niebawem ruszają zapisy!
 - [https://epoznan.pl/news-news-146510-wyjatkowe_propozycje_za_jedyna_zlotowke_w_na_obiektach_posir_niebawem_ruszaja_zapisy?rss=1](https://epoznan.pl/news-news-146510-wyjatkowe_propozycje_za_jedyna_zlotowke_w_na_obiektach_posir_niebawem_ruszaja_zapisy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T15:15:00+00:00

Część oferty skierowana jest nie tylko do poznanianek i poznaniaków 60+ , ale także do ich wnuków.

## Wyjątkowe propozycje za złotówkę w na obiektach POSiR. Niebawem ruszają zapisy!
 - [https://epoznan.pl/news-news-146510-wyjatkowe_propozycje_za_zlotowke_w_na_obiektach_posir_niebawem_ruszaja_zapisy?rss=1](https://epoznan.pl/news-news-146510-wyjatkowe_propozycje_za_zlotowke_w_na_obiektach_posir_niebawem_ruszaja_zapisy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T15:15:00+00:00

Część oferty skierowana jest nie tylko do poznanianek i poznaniaków 60+ , ale także do ich wnuków.

## Pierwszy długi weekend w 2024 roku nie tak szybko. Kiedy dni wolne?
 - [https://epoznan.pl/news-news-146509-pierwszy_dlugi_weekend_w_2024_roku_nie_tak_szybko_kiedy_dni_wolne?rss=1](https://epoznan.pl/news-news-146509-pierwszy_dlugi_weekend_w_2024_roku_nie_tak_szybko_kiedy_dni_wolne?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T15:00:00+00:00

Jeśli uda się wziąć kilka dodatkowych dni wolnych w tym roku, można zyskać sporo czasu na wypoczynek.

## Mieszkańcy podpoznańskiej gminy w poniedziałek efektownie powitają Nowy Rok
 - [https://epoznan.pl/news-news-146507-mieszkancy_podpoznanskiej_gminy_w_poniedzialek_efektownie_powitaja_nowy_rok?rss=1](https://epoznan.pl/news-news-146507-mieszkancy_podpoznanskiej_gminy_w_poniedzialek_efektownie_powitaja_nowy_rok?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T14:30:00+00:00

To już tradycja.

## Zaginął 20-latek!
 - [https://epoznan.pl/news-news-146508-zaginal_20_latek?rss=1](https://epoznan.pl/news-news-146508-zaginal_20_latek?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T14:00:00+00:00

Od nocy nie kontaktował się z bliskimi.

## Może być głośno w Poznaniu i okolicach. Również w nocy!
 - [https://epoznan.pl/news-news-146506-moze_byc_glosno_w_poznaniu_i_okolicach_rowniez_w_nocy?rss=1](https://epoznan.pl/news-news-146506-moze_byc_glosno_w_poznaniu_i_okolicach_rowniez_w_nocy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T13:30:00+00:00

Centrum Szkolenia Wojsk Lądowych w Poznaniu poinformowało o zaplanowanych ćwiczeniach na poligonie w Biedrusku.

## Przez miesiąc może być głośno w Poznaniu i okolicach. Również w nocy!
 - [https://epoznan.pl/news-news-146506-przez_miesiac_moze_byc_glosno_w_poznaniu_i_okolicach_rowniez_w_nocy?rss=1](https://epoznan.pl/news-news-146506-przez_miesiac_moze_byc_glosno_w_poznaniu_i_okolicach_rowniez_w_nocy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T13:30:00+00:00

Centrum Szkolenia Wojsk Lądowych w Poznaniu poinformowało o zaplanowanych ćwiczeniach na poligonie w Biedrusku.

## Pracowita noc. W Sylwestra poznańskie pogotowie wyjeżdżało ponad 140 razy
 - [https://epoznan.pl/news-news-146505-pracowita_noc_w_sylwestra_poznanskie_pogotowie_wyjezdzalo_ponad_140_razy?rss=1](https://epoznan.pl/news-news-146505-pracowita_noc_w_sylwestra_poznanskie_pogotowie_wyjezdzalo_ponad_140_razy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T13:00:00+00:00

Tradycyjnie w Sylwestrową noc o wiele więcej pracy mają zespoły ratownictwa medycznego.

## Niemowlę z pękniętą czaszką trafiło do poznańskiego szpitala. Dziś przesłuchiwani są rodzice
 - [https://epoznan.pl/news-news-146504-niemowle_z_peknieta_czaszka_trafilo_do_poznanskiego_szpitala_dzis_przesluchiwani_sa_rodzice?rss=1](https://epoznan.pl/news-news-146504-niemowle_z_peknieta_czaszka_trafilo_do_poznanskiego_szpitala_dzis_przesluchiwani_sa_rodzice?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T12:30:00+00:00

Jest prokuratorskie śledztwo.

## Niemowlę z pękniętą czaszką trafiło do poznańskiego szpitala. Jest prokuratorskie śledztwo
 - [https://epoznan.pl/news-news-146504-niemowle_z_peknieta_czaszka_trafilo_do_poznanskiego_szpitala_jest_prokuratorskie_sledztwo?rss=1](https://epoznan.pl/news-news-146504-niemowle_z_peknieta_czaszka_trafilo_do_poznanskiego_szpitala_jest_prokuratorskie_sledztwo?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T12:30:00+00:00

Przesłuchiwani są rodzice dziewczynki.

## Sieć popularnych supermarketów wycofuje dwa produkty. Można je przynosić do sklepów!
 - [https://epoznan.pl/news-news-146503-siec_popularnych_supermarketow_wycofuje_dwa_produkty_mozna_je_przynosic_do_sklepow?rss=1](https://epoznan.pl/news-news-146503-siec_popularnych_supermarketow_wycofuje_dwa_produkty_mozna_je_przynosic_do_sklepow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T11:30:00+00:00



## Pierwsi poznaniacy urodzeni w 2024 roku!
 - [https://epoznan.pl/news-news-146502-pierwsi_poznaniacy_urodzeni_w_2024_roku?rss=1](https://epoznan.pl/news-news-146502-pierwsi_poznaniacy_urodzeni_w_2024_roku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T11:00:00+00:00

Pierwsza urodziła się dziewczynka.

## Mężczyzna spadł z mostu Jordana
 - [https://epoznan.pl/news-news-146501-mezczyzna_spadl_z_mostu_jordana?rss=1](https://epoznan.pl/news-news-146501-mezczyzna_spadl_z_mostu_jordana?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T10:45:00+00:00

Został podjęty z wody.

## Od dziś zmieniły się nazwy przystanków. Dwa z nich znalazły się  innej strefie biletowej
 - [https://epoznan.pl/news-news-146500-od_dzis_zmienily_sie_nazwy_przystankow_dwa_z_nich_znalazly_sie_innej_strefie_biletowej?rss=1](https://epoznan.pl/news-news-146500-od_dzis_zmienily_sie_nazwy_przystankow_dwa_z_nich_znalazly_sie_innej_strefie_biletowej?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T10:30:00+00:00

10 przystanków w transporcie organizowanym przez ZTM Poznań od dziś będzie miało inne nazwy.

## Policjanci podsumowali sylwestrową noc
 - [https://epoznan.pl/news-news-146499-policjanci_podsumowali_sylwestrowa_noc?rss=1](https://epoznan.pl/news-news-146499-policjanci_podsumowali_sylwestrowa_noc?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T10:00:00+00:00

Na razie nie ma informacji, by w Poznaniu i województwie doszło do poważnych zdarzeń.

## Mieszkańcy dwóch wielkopolskich miejscowości obudzili się dziś w mieście
 - [https://epoznan.pl/news-news-146498-mieszkancy_dwoch_wielkopolskich_miejscowosci_obudzili_sie_dzis_w_miescie?rss=1](https://epoznan.pl/news-news-146498-mieszkancy_dwoch_wielkopolskich_miejscowosci_obudzili_sie_dzis_w_miescie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T09:30:00+00:00

Od Nowego Roku Polska będzie miała 1013 miast - o 34 więcej niż do tej pory. Wśród nich są dwie wielkopolskie miejscowości.

## Poznaniacy hucznie przywitali Nowy Rok. O północy tysiące fajerwerków rozświetliło niebo nad miastem.
 - [https://epoznan.pl/news-news-146496-poznaniacy_hucznie_przywitali_nowy_rok_o_polnocy_tysiace_fajerwerkow_rozswietlilo_niebo_nad_miastem?rss=1](https://epoznan.pl/news-news-146496-poznaniacy_hucznie_przywitali_nowy_rok_o_polnocy_tysiace_fajerwerkow_rozswietlilo_niebo_nad_miastem?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T09:00:00+00:00

O północy w każdej części miasta było głośno. Tłumy pojawiły się na Starym Rynku i placu Wolności.

## Tlenek węgla zaatakował w Poznaniu. Trwa reanimacja
 - [https://epoznan.pl/news-news-146497-tlenek_wegla_zaatakowal_w_poznaniu_trwa_reanimacja?rss=1](https://epoznan.pl/news-news-146497-tlenek_wegla_zaatakowal_w_poznaniu_trwa_reanimacja?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T08:45:00+00:00

Służby interweniują przy ul. Łukaszewicza.

## Strażacy podsumowują sylwestrową noc. Sporo zgłoszeń
 - [https://epoznan.pl/news-news-146495-strazacy_podsumowuja_sylwestrowa_noc_sporo_zgloszen?rss=1](https://epoznan.pl/news-news-146495-strazacy_podsumowuja_sylwestrowa_noc_sporo_zgloszen?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-01T08:30:00+00:00

Na szczęście nikomu nic poważnego się nie stało.

