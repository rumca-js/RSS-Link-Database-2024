# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Amazon's massive New Year's sale is live: here are the 29 best deals to shop right now
 - [https://www.techradar.com/seasonal-sales/amazons-massive-new-years-sale-is-live-here-are-the-29-best-deals-to-shop-right-now](https://www.techradar.com/seasonal-sales/amazons-massive-new-years-sale-is-live-here-are-the-29-best-deals-to-shop-right-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-01T20:11:47+00:00

Amazon just launched a massive New Year's sale, and I'm rounding up the 29 best deals from Apple, Fitbit, Ninja, and more.

## New year, new TV: LG's C2 OLED drops to an unbelievable price of $1,399 at Amazon
 - [https://www.techradar.com/seasonal-sales/new-year-new-tv-lgs-c2-oled-drops-to-an-unbelievable-price-of-dollar1399-at-amazon](https://www.techradar.com/seasonal-sales/new-year-new-tv-lgs-c2-oled-drops-to-an-unbelievable-price-of-dollar1399-at-amazon)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-01T18:55:22+00:00

Treat yourself to a new TV for the new year with this incredible deal on LG's 65-inch C2 OLED, which is on sale for $1,399 at Amazon.

## New Nothing Phone 2a leaks include images, prices, colors, and specs
 - [https://www.techradar.com/phones/nothing-phones/new-nothing-phone-2a-leaks-include-images-prices-colors-and-specs](https://www.techradar.com/phones/nothing-phones/new-nothing-phone-2a-leaks-include-images-prices-colors-and-specs)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-01T14:30:14+00:00

We've got a bit more information about the upcoming budget option from Nothing, including a price.

## The 12 most exciting cameras of 2024, from a Fujifilm X100V successor to the Samsung Galaxy S24 Ultra
 - [https://www.techradar.com/cameras/the-12-most-exciting-cameras-of-2024-from-a-fujifilm-x100v-successor-to-the-samsung-galaxy-s24-ultra](https://www.techradar.com/cameras/the-12-most-exciting-cameras-of-2024-from-a-fujifilm-x100v-successor-to-the-samsung-galaxy-s24-ultra)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-01T13:00:18+00:00

In the market for a new camera in 2024? We've rounded up all of the latest rumors to spotlight the most promising launches of the year.

## The Samsung Galaxy S24 Ultra could come with a big video recording upgrade
 - [https://www.techradar.com/phones/samsung-galaxy-phones/the-samsung-galaxy-s24-ultra-could-come-with-a-big-video-recording-upgrade](https://www.techradar.com/phones/samsung-galaxy-phones/the-samsung-galaxy-s24-ultra-could-come-with-a-big-video-recording-upgrade)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-01T10:30:36+00:00

The Galaxy S24 Ultra is being tipped to offer a video quality that beats current Samsung, Apple, and Google phones.

## Quordle today – hints and answers for Monday, January 1 (game #707)
 - [https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-1-january-2024](https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-1-january-2024)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-01T00:15:07+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

