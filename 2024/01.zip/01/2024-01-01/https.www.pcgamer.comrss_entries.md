# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## Our boldest predictions for PC gaming in 2024
 - [https://www.pcgamer.com/our-boldest-predictions-for-pc-gaming-in-2024](https://www.pcgamer.com/our-boldest-predictions-for-pc-gaming-in-2024)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-01T16:25:45+00:00

We're pondering our orbs again.

## Alan Wake 2 is so stuffed with jump scares it cheapens the good horror
 - [https://www.pcgamer.com/alan-wake-2-is-so-stuffed-with-jump-scares-it-cheapens-the-good-horror](https://www.pcgamer.com/alan-wake-2-is-so-stuffed-with-jump-scares-it-cheapens-the-good-horror)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-01T16:00:11+00:00

They alienate potential players without really adding anything.

## CES 2024 preview: The future of PC gaming hardware
 - [https://www.pcgamer.com/ces-2024-preview-the-future-of-pc-gaming-hardware](https://www.pcgamer.com/ces-2024-preview-the-future-of-pc-gaming-hardware)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-01T15:00:56+00:00

New graphics cards, all the screens, and more AI than you can eat.

## This year I'm finally going to tackle my gaming backlog—please take me seriously, I have a plan and everything
 - [https://www.pcgamer.com/this-year-im-finally-going-to-tackle-my-gaming-backlogseriously-i-have-a-plan](https://www.pcgamer.com/this-year-im-finally-going-to-tackle-my-gaming-backlogseriously-i-have-a-plan)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-01T13:00:46+00:00

Stop laughing at me.

## The PC Gamer tech team's New Year's resolutions
 - [https://www.pcgamer.com/the-pc-gamer-tech-teams-new-years-resolutions](https://www.pcgamer.com/the-pc-gamer-tech-teams-new-years-resolutions)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-01T13:00:16+00:00

What do you mean? Of course we'll stick to them!

## Wordle today: Hint and answer #926 for Monday, January 1
 - [https://www.pcgamer.com/wordle-today-answer-926-january-1](https://www.pcgamer.com/wordle-today-answer-926-january-1)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-01T04:01:56+00:00

Today's Wordle: Help with solving Monday's puzzle.

## Steam's Best of 2023 highlights top sellers, most played—apparently Steam Deck players really like Half-Life
 - [https://www.pcgamer.com/steams-best-of-2023-highlights-top-sellers-most-playedapparently-steam-deck-players-really-like-half-life](https://www.pcgamer.com/steams-best-of-2023-highlights-top-sellers-most-playedapparently-steam-deck-players-really-like-half-life)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-01T00:47:12+00:00

Seriously, Half-Life in the same tier as Baldur's Gate 3, Dave the Diver, and Vampire Survivors.

