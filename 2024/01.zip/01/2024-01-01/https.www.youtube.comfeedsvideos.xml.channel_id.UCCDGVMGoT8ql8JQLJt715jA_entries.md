# Source:emzdanowicz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA, language:pl

## 5 gier, na które czekam w 2024 roku
 - [https://www.youtube.com/watch?v=uXlZj5QjjrY](https://www.youtube.com/watch?v=uXlZj5QjjrY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA
 - date published: 2024-01-01T09:00:36+00:00

Moja skromna lista tytułów, których nie mogę się doczekać.

Możesz wesprzeć mnie na Patronite: https://patronite.pl/emzdanowicz 
W rozwoju kanału pomagają też lajki i suby ;)

Zobacz także: 

- Najlepsze gry indie 2023 roku (https://www.youtube.com/watch?v=EQN9-2HfXMo)
- Recenzja THE FINALS (https://www.youtube.com/watch?v=2GAXFH_MrSw)
- The Last of Us Online ANULOWANE (https://www.youtube.com/watch?v=r6IMTWxq67E)

#finalfantasy7 #hollowknight

