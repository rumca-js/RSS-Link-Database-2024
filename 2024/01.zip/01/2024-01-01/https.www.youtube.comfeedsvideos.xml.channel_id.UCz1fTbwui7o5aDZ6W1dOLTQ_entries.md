# Source:Literature Devil, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ, language:en-US

## Unstoppable Nightwatch Ep. 3: Not Home
 - [https://www.youtube.com/watch?v=DBlgxwHLD-U](https://www.youtube.com/watch?v=DBlgxwHLD-U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ
 - date published: 2024-01-01T20:00:07+00:00

Nightwatch asks to have an extra therapist session out of the blue. She claims nothing's wrong, but not everything is what it seems.

Art: Jeff Kraven
Written: Literature Devil
Voiced By: Apaniva (Fiverr)

Check out my main channel: https://www.youtube.com/channel/UCz1fTbwui7o5aDZ6W1dOLTQ

#voiceacting #comics #Storytelling #IndieComics #AudioDrama
#GraphicNovel
#comicbooks 
#Narration
#DigitalArt
#Art
#Superheroes

