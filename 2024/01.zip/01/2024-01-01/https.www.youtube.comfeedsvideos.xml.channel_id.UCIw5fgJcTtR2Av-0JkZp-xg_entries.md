# Source:Yuri Wong, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg, language:en-US

## "Do, or Do Not. There is No Try" // Remixing The Empire Strikes Back // Star Wars // Smpltrek
 - [https://www.youtube.com/watch?v=QSX1GsLZwIk](https://www.youtube.com/watch?v=QSX1GsLZwIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCIw5fgJcTtR2Av-0JkZp-xg
 - date published: 2024-01-01T12:00:17+00:00

Support my music on Patreon: https://patreon.com/yuriwong
SmplTrek Speak n' Spell skin by Cremacaffe: https://cremacaffe.shop
Remixed on the Sonicware SmplTrek with Korg Nanokey Studio
Completed in Logic Pro
0:00 Making-of
2:26 Let's Jam
3:04 Full Song

Luke: Master, moving stones around is one thing. This is totally different.
Yoda: No. No different. Only different in your mind. You must unlearn what you have learned.
Luke: All right, I'll give it a try.
Yoda: No. Try not. Do… or do not. There is no try.

