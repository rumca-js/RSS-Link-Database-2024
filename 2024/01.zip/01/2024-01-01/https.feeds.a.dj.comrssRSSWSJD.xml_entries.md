# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Baidu Terminates $3.6B Deal to Buy JOYY's China Live-Streaming Business
 - [https://www.wsj.com/articles/baidu-terminates-3-6b-deal-to-buy-joyys-china-live-streaming-business-d68f9d86?mod=rss_Technology](https://www.wsj.com/articles/baidu-terminates-3-6b-deal-to-buy-joyys-china-live-streaming-business-d68f9d86?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-01-01T23:44:00+00:00

Baidu has called off a $3.6 billion deal to buy JOYY’s video-based entertainment live-streaming business in China saying certain conditions were yet to be fully satisfied.

## Big Tech Braces for Wave of Antitrust Rulings in 2024
 - [https://www.wsj.com/articles/big-tech-braces-for-wave-of-antitrust-rulings-in-2024-860f0149?mod=rss_Technology](https://www.wsj.com/articles/big-tech-braces-for-wave-of-antitrust-rulings-in-2024-860f0149?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-01-01T15:01:00+00:00

U.S. antitrust cases against tech giants Google and Meta are expected to come to a head, likely producing long-awaited rulings that could shape the legacies of top Biden administration regulators.

