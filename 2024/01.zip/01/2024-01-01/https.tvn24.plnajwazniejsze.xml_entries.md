# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Brunatni tchórze zabrudzili elewację synagogi"
 - [https://tvn24.pl/polska/wroclaw-zdewastowano-fasade-synagogi-pod-bialym-bocianem-7664753?source=rss](https://tvn24.pl/polska/wroclaw-zdewastowano-fasade-synagogi-pod-bialym-bocianem-7664753?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T21:39:01+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xxopow-synagoga-pod-bialym-bocianem-we-wroclawiu-7665770/alternates/LANDSCAPE_1280" />
    Trwają poszukiwania osoby, która wykonała napis. Na monitoringu widać zamaskowaną postać.

## "Ten kurs złotego, który sieje panikę, to fejk, błąd źródła danych"
 - [https://tvn24.pl/biznes/rynki/kurs-zlotego-do-euro-zaskakujacy-wykres-minister-finansow-andrzej-domanski-komentuje-st7664754?source=rss](https://tvn24.pl/biznes/rynki/kurs-zlotego-do-euro-zaskakujacy-wykres-minister-finansow-andrzej-domanski-komentuje-st7664754?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T21:21:41+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5m5mim-andrzej-domanski-7537473/alternates/LANDSCAPE_1280" />
    Głos w mediach społecznościowych zabrał minister finansów Andrzej Domański.

## Dwie wojny i wybory, na które idzie "ponad połowa populacji świata"
 - [https://tvn24.pl/swiat/co-nas-czeka-w-polityce-miedzynarodowej-ponad-polowa-populacji-swiata-idzie-do-wyborow-7664314?source=rss](https://tvn24.pl/swiat/co-nas-czeka-w-polityce-miedzynarodowej-ponad-polowa-populacji-swiata-idzie-do-wyborow-7664314?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T20:29:25+00:00

<img alt="Dwie wojny i wybory, na które idzie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5qruuw-fakty-po-faktach-7664322/alternates/LANDSCAPE_1280" />
    Dziennikarze TVN i TVN24 rozmawiali w "Faktach po Faktach" o tym, co czeka nas w polityce międzynarodowej.

## Nie żyje trener Mariusz Karol. Miał 56 lat
 - [https://eurosport.tvn24.pl/koszykowka/nie-zyje-mariusz-karol.-trener-koszykowki-mial-56-lat_sto9941136/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/nie-zyje-mariusz-karol.-trener-koszykowki-mial-56-lat_sto9941136/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T20:07:47+00:00

<img alt="Nie żyje trener Mariusz Karol. Miał 56 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i5rzp4-mariusz-karol-nie-zyje-7664338/alternates/LANDSCAPE_1280" />
    W sobotę 30 grudnia po długiej chorobie zmarł znany trener Mariusz Karol - poinformował Polski Związek Koszykówki.

## "Wróciła zima". Robi się biało, śniegu będzie przybywać
 - [https://tvn24.pl/tvnmeteo/pogoda/zima-wraca-sypie-snieg-trudne-warunki-na-drogach-zdjecia-st7664323?source=rss](https://tvn24.pl/tvnmeteo/pogoda/zima-wraca-sypie-snieg-trudne-warunki-na-drogach-zdjecia-st7664323?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T19:47:40+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dgtpjy-snieg-w-siedlcach-7664330/alternates/LANDSCAPE_1280" />
    Na Kontakt 24 otrzymaliśmy zdjęcia.

## Kvitova podzieliła się radosną nowiną w Nowym Roku
 - [https://eurosport.tvn24.pl/tenis/petra-kvitova-oglosila-w-nowy-rok-ze-spodziewa-sie-dziecka-tenis_sto9940473/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/petra-kvitova-oglosila-w-nowy-rok-ze-spodziewa-sie-dziecka-tenis_sto9940473/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T19:23:50+00:00

<img alt="Kvitova podzieliła się radosną nowiną w Nowym Roku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fmld8e-petra-kvitova-7664319/alternates/LANDSCAPE_1280" />
    Czeska tenisistka opublikowała wpis w mediach społecznościowych.

## "Nieporozumienie, a właściwie pełna hipokryzja"
 - [https://fakty.tvn24.pl/zobacz-fakty/prezydent-przestrzegal-przed-lamaniem-konstytucji-to-pelna-hipokryzja-st7664289?source=rss](https://fakty.tvn24.pl/zobacz-fakty/prezydent-przestrzegal-przed-lamaniem-konstytucji-to-pelna-hipokryzja-st7664289?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T19:07:38+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-6utly7-zalewska-7664266/alternates/LANDSCAPE_1280" />
    Konsytucjonaliści i prawnicy komentują słowa prezydenta Andrzeja Dudy.

## Stoch podsumował konkurs w Ga-Pa. "Jest kiepsko, ale stabilnie"
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2024-kamil-stoch-po-noworocznym-konkursie-turnieju-czterech_sto9941018/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2024-kamil-stoch-po-noworocznym-konkursie-turnieju-czterech_sto9941018/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T19:05:14+00:00

<img alt="Stoch podsumował konkurs w Ga-Pa. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-crpyp7-kamil-stoch-7664312/alternates/LANDSCAPE_1280" />
    W rozmowie z Eurosportem.

## Świątek powiększyła przewagę nad Sabalenką. Nowy ranking WTA
 - [https://eurosport.tvn24.pl/tenis/iga-swiatek-powiekszyla-przewage-nad-aryna-sabalenka.-ranking-wta_sto9941057/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/iga-swiatek-powiekszyla-przewage-nad-aryna-sabalenka.-ranking-wta_sto9941057/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T18:01:00+00:00

<img alt="Świątek powiększyła przewagę nad Sabalenką. Nowy ranking WTA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q9ussq-iga-swiatek-najlepsza-tenisistka-2023-roku-7664278/alternates/LANDSCAPE_1280" />
    Poprawiły się też najlepsze inne Polki.

## "Efekt wczorajszej nocy"
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/efekt-wczorajszej-nocy.-zartobliwy-komentarz-zyly-po-nieudanym-ladowaniu_sto9941006/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/efekt-wczorajszej-nocy.-zartobliwy-komentarz-zyly-po-nieudanym-ladowaniu_sto9941006/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T16:53:16+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5h4dd4-nieudane-ladowanie-piotra-zyly-w-2-7664231/alternates/LANDSCAPE_1280" />
    Piotr Żyła po nieudanym lądowaniu.

## Na plażach, na ulicach czy w klubach. Tak Polacy powitali 2024 rok
 - [https://fakty.tvn24.pl/fakty-po-poludniu/na-plazach-na-ulicach-czy-w-klubach-tak-polacy-powitali-2024-rok-st7664225?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/na-plazach-na-ulicach-czy-w-klubach-tak-polacy-powitali-2024-rok-st7664225?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T16:51:06+00:00

<img alt="Na plażach, na ulicach czy w klubach. Tak Polacy powitali 2024 rok" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-g83ks6-0101n-x-f16-czuprynska-sylwester-002245-7664214/alternates/LANDSCAPE_1280" />
    Minimaliści mówią - oby nie był gorszy, ale optymiści liczą na lepsze.

## Pożar podczas zabawy sylwestrowej. Młoda kobieta nie żyje, 21 poszkodowanych
 - [https://tvn24.pl/swiat/austria-pozar-podczas-zabawy-sylwestrowej-ofiara-smiertelna-i-21-poszkodowanych-7664143?source=rss](https://tvn24.pl/swiat/austria-pozar-podczas-zabawy-sylwestrowej-ofiara-smiertelna-i-21-poszkodowanych-7664143?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T16:47:16+00:00

<img alt="Pożar podczas zabawy sylwestrowej. Młoda kobieta nie żyje, 21 poszkodowanych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-100o7d-graz-2-mapa-szablon-7664165/alternates/LANDSCAPE_1280" />
    W mieście Graz w Austrii.

## Dominacja faworytów w Tour de Ski
 - [https://eurosport.tvn24.pl/biegi-narciarskie/tour-de-ski/2023-2024/tour-de-ski.-biegi-na-dochodzenie-technika-dowolna-na-20-km-w-dobbiaco.-wyniki-i-relacja_sto9941000/story.shtml?source=rss](https://eurosport.tvn24.pl/biegi-narciarskie/tour-de-ski/2023-2024/tour-de-ski.-biegi-na-dochodzenie-technika-dowolna-na-20-km-w-dobbiaco.-wyniki-i-relacja_sto9941000/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T16:35:54+00:00

<img alt="Dominacja faworytów w Tour de Ski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xh5vyy-harald-oestberg-amundsen-triumfuje-7664223/alternates/LANDSCAPE_1280" />
    Polacy nadal daleko.

## Tak mieszkańcy Odessy odpowiedzieli na rosyjskie naloty
 - [https://fakty.tvn24.pl/fakty-po-poludniu/tak-mieszkancy-odessy-odpowiedzieli-na-rosyjskie-naloty-st7664221?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/tak-mieszkancy-odessy-odpowiedzieli-na-rosyjskie-naloty-st7664221?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T16:33:31+00:00

<img alt="Tak mieszkańcy Odessy odpowiedzieli na rosyjskie naloty" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-ilrtf1-pupiec-7664211/alternates/LANDSCAPE_1280" />
    W Odessie, która była głównym celem Rosjan w sylwestrową noc, rannych zostało dziewięć osób, a jedna zginęła.

## Zniszczoł pochwalił nowy sprzęt
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/aleksander-zniszczol-po-konkursie-w-garmisch-partenkirchen_sto9940975/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/aleksander-zniszczol-po-konkursie-w-garmisch-partenkirchen_sto9940975/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T16:10:20+00:00

<img alt="Zniszczoł pochwalił nowy sprzęt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ygpth-zniszczol-po-kwalifikacjach-w-garmisch-partenkirchen-7664209/alternates/LANDSCAPE_1280" />
    Skoczek został niespodziewanym bohaterem Polaków.

## Kubacki spóźniony w noworocznym konkursie
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2024-dawid-kubacki-po-noworocznym-konkursie-turnieju-cztere_sto9940697/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2024-dawid-kubacki-po-noworocznym-konkursie-turnieju-cztere_sto9940697/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T15:30:14+00:00

<img alt="Kubacki spóźniony w noworocznym konkursie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n1b7go-kubacki-po-konkursie-w-garmisch-partenkirchen-7664179/alternates/LANDSCAPE_1280" />
    "Czułem, że nogi spadły z progu".

## Emocje w Garmisch-Partenkirchen. Niespodziewany lider Polaków
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2024.-wyniki-i-relacja.-turniej-czterech-skoczni_sto9940441/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2024.-wyniki-i-relacja.-turniej-czterech-skoczni_sto9940441/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T15:18:48+00:00

<img alt="Emocje w Garmisch-Partenkirchen. Niespodziewany lider Polaków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pp7rsq-anze-laniszek-w-akcji-7664172/alternates/LANDSCAPE_1280" />
    Słoweniec Anże Laniszek wygrał w noworocznym konkursie.

## Minister sprawiedliwości reaguje na słowa Jana Pietrzaka o "barakach dla imigrantów"
 - [https://tvn24.pl/polska/slowa-jana-pietrzaka-o-migrantach-minister-sprawiedliwosci-adam-bodnar-reaguje-zwrocil-sie-do-prokuratora-krajowego-7664144?source=rss](https://tvn24.pl/polska/slowa-jana-pietrzaka-o-migrantach-minister-sprawiedliwosci-adam-bodnar-reaguje-zwrocil-sie-do-prokuratora-krajowego-7664144?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T15:17:32+00:00

<img alt="Minister sprawiedliwości reaguje na słowa Jana Pietrzaka o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tyufgk-minister-sprawiedliwosci-adam-bodnar-7546908/alternates/LANDSCAPE_1280" />
    Zwrócił się do prokuratora krajowego Dariusza Barskiego.

## Uderzył w bariery na autostradzie A4, nie żyje
 - [https://tvn24.pl/krakow/brzoskwinia-smiertelny-wypadek-na-autostradzie-a4-7664145?source=rss](https://tvn24.pl/krakow/brzoskwinia-smiertelny-wypadek-na-autostradzie-a4-7664145?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T15:14:21+00:00

<img alt="Uderzył w bariery na autostradzie A4, nie żyje " src="https://tvn24.pl/najnowsze/cdn-zdjecie-o3d81i-wypadek-na-autostradzie-w-miejscowosci-brzoskwinia-7664146/alternates/LANDSCAPE_1280" />
    W miejscowości Brzoskwinia (woj. małopolskie).

## Ciało w mieszkaniu, ranny mężczyzna na plaży, ataki "niebezpiecznym narzędziem", poszukiwania 13-latki...
 - [https://tvn24.pl/trojmiasto/noc-sylwestrowa-policja-o-incydentach-i-zatrzymaniach-zwloki-w-mlocinach-atak-niebezpiecznym-narzedziem-w-gdyni-zaginiona-nastolatka-w-lublinie-7664131?source=rss](https://tvn24.pl/trojmiasto/noc-sylwestrowa-policja-o-incydentach-i-zatrzymaniach-zwloki-w-mlocinach-atak-niebezpiecznym-narzedziem-w-gdyni-zaginiona-nastolatka-w-lublinie-7664131?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T15:09:01+00:00

<img alt="Ciało w mieszkaniu, ranny mężczyzna na plaży, ataki " src="https://tvn24.pl/najnowsze/cdn-zdjecie-oy8yvr-pieciu-mezczyzn-zatrzymanych-za-atak-na-przechodnia-wczesniej-zwrocil-im-uwage-zeby-nie-rzucali-fajerwerkami-7664142/alternates/LANDSCAPE_1280" />
    Policja podsumowuje, jak minęła sylwestrowa noc.

## Akrobacje uchroniły go przed upadkiem
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/problemy-philippa-raimunda-w-1.-serii-konkursu-w-ga-pa.-jakis-slalom-sie-pojawil_sto9940692/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/problemy-philippa-raimunda-w-1.-serii-konkursu-w-ga-pa.-jakis-slalom-sie-pojawil_sto9940692/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T14:53:43+00:00

<img alt="Akrobacje uchroniły go przed upadkiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4a69me-problemy-philippa-raimunda-podczas-ladowania-w-1-7664153/alternates/LANDSCAPE_1280" />
    "Należą mu się słowa uznania".

## Ranni policjanci, podpalone samochody. Fala zamieszek w sylwestrową noc
 - [https://tvn24.pl/swiat/belgia-i-holandia-sylwestrowa-noc-zatrzymania-po-zamieszkach-7664049?source=rss](https://tvn24.pl/swiat/belgia-i-holandia-sylwestrowa-noc-zatrzymania-po-zamieszkach-7664049?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T14:31:55+00:00

<img alt="Ranni policjanci, podpalone samochody. Fala zamieszek w sylwestrową noc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o4zjm5-pap_20231231_2o8-1-7664069/alternates/LANDSCAPE_1280" />
    W Belgii i Holandii.

## Przebudzenie polskiego skoczka
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/turniej-czterech-skoczni-garmisch-partenkirchen-2024-aleksander-zniszczol-z-pierwszymi-punktami-w-se_sto9940575/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/turniej-czterech-skoczni-garmisch-partenkirchen-2024-aleksander-zniszczol-z-pierwszymi-punktami-w-se_sto9940575/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T14:13:39+00:00

<img alt="Przebudzenie polskiego skoczka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n2ifq2-aleksander-zniszczol-7664110/alternates/LANDSCAPE_1280" />
    Pierwsze punkty w sezonie.

## "Przemoc i nienawiść zdają się wprost coraz bardziej dominować"
 - [https://tvn24.pl/poznan/gniezno-noworoczna-homilia-prymasa-polski-arcybiskup-wojciech-polak-o-potrzebie-przywrocenia-pokoju-7664048?source=rss](https://tvn24.pl/poznan/gniezno-noworoczna-homilia-prymasa-polski-arcybiskup-wojciech-polak-o-potrzebie-przywrocenia-pokoju-7664048?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T13:29:48+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mfs960-arcybiskup-wojciech-polak-mowil-w-swiatowy-dzien-pokoju-ze-dazenie-do-pokoju-jest-obowiazkiem-wszystkich-ludzi-7664067/alternates/LANDSCAPE_1280" />
    Noworoczna homilia Prymasa Polski.

## Ranni trafiają do szpitala, ale lekarze nie mogą dojechać
 - [https://tvn24.pl/swiat/japonia-trzesienie-ziemi-lekarze-w-suzu-nie-moga-odjechac-do-rannych-w-szpitalu-z-powodu-uszkodzonych-drog-7664034?source=rss](https://tvn24.pl/swiat/japonia-trzesienie-ziemi-lekarze-w-suzu-nie-moga-odjechac-do-rannych-w-szpitalu-z-powodu-uszkodzonych-drog-7664034?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T13:22:41+00:00

<img alt="Ranni trafiają do szpitala, ale lekarze nie mogą dojechać" src="https://tvn24.pl/najnowsze/cdn-zdjecie-islf0f-japonia-3-www-7664042/alternates/LANDSCAPE_1280" />
    Trudna sytuacja w japońskim mieście Suzu.

## Papryka może być "żeńska" lub "męska"? Wyjaśniamy "ogrodowy mit"
 - [https://konkret24.tvn24.pl/nauka/papryka-moze-byc-zenska-lub-meska-wyjasniamy-ogrodowy-mit-st7654285?source=rss](https://konkret24.tvn24.pl/nauka/papryka-moze-byc-zenska-lub-meska-wyjasniamy-ogrodowy-mit-st7654285?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T13:05:03+00:00

<img alt="Papryka może być " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ogwsvr-papryka-moze-byc-zenska-lub-meska-wyjasniamy-ogrodowy-mit-7654306/alternates/LANDSCAPE_1280" />
    Rozpowszechniana w sieci teza ani nie jest nowa, ani prawdziwa.

## Pędził przez miasto, zabił rodzeństwo. Po wyroku trafił do aresztu, bo "nie przestrzega norm i zasad"
 - [https://tvn24.pl/olsztyn/olsztyn-sad-wyznaczyl-termin-apelacji-w-sprawie-wypadku-w-ktorym-zginelo-rodzenstwo-7664044?source=rss](https://tvn24.pl/olsztyn/olsztyn-sad-wyznaczyl-termin-apelacji-w-sprawie-wypadku-w-ktorym-zginelo-rodzenstwo-7664044?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T13:02:55+00:00

<img alt="Pędził przez miasto, zabił rodzeństwo. Po wyroku trafił do aresztu, bo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2fewnn-do-wypadku-doszlo-na-ulicy-baltyckiej-w-olsztynie-7333204/alternates/LANDSCAPE_1280" />
    Będzie proces apelacyjny, pierwsza rozprawa 23 stycznia.

## "Nie zwalniamy tempa"
 - [https://tvn24.pl/polska/prezydent-andrzej-duda-podsumowuje-2023-rok-nie-zwalniamy-tempa-nadal-bede-zabiegal-o-polskie-sprawy-w-europie-i-na-swiecie-7664031?source=rss](https://tvn24.pl/polska/prezydent-andrzej-duda-podsumowuje-2023-rok-nie-zwalniamy-tempa-nadal-bede-zabiegal-o-polskie-sprawy-w-europie-i-na-swiecie-7664031?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T12:51:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f1lvpq-duda-7664033/alternates/LANDSCAPE_1280" />
    Andrzej Duda w nagraniu podsumowującym jego działalność w ubiegłym roku.

## Jedenaście nowych miast na Mazowszu
 - [https://tvn24.pl/tvnwarszawa/okolice/11-nowych-miast-na-mazowszu-st7663977?source=rss](https://tvn24.pl/tvnwarszawa/okolice/11-nowych-miast-na-mazowszu-st7663977?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T12:28:18+00:00

<img alt="Jedenaście nowych miast na Mazowszu " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-kc3aqg-11-miejscowosci-na-mazowszu-uzyskalo-prawa-miejskie-7664023/alternates/LANDSCAPE_1280" />
    Mieszkańcy niektórych już świętowali.

## Zniszczoł błysnął w serii próbnej
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/live-duza-skocznia-mezczyzni_mtc1474279/live.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/live-duza-skocznia-mezczyzni_mtc1474279/live.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T12:19:00+00:00

<img alt="Zniszczoł błysnął w serii próbnej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2y2cb2-aleksander-zniszczol-7546731/alternates/LANDSCAPE_1280" />
    Wyniki i relacja na żywo w Eurosport.pl.

## Poznali się w barze, zostanie królową
 - [https://tvn24.pl/swiat/dania-kim-jest-maria-zona-ksiecia-fryderyka-poznali-sie-podczas-imprezy-w-barze-7663791?source=rss](https://tvn24.pl/swiat/dania-kim-jest-maria-zona-ksiecia-fryderyka-poznali-sie-podczas-imprezy-w-barze-7663791?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T11:12:31+00:00

<img alt="Poznali się w barze, zostanie królową" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k8rpbe-ksiaze-fryderyk-i-ksiezna-maria-7663862/alternates/LANDSCAPE_1280" />
    Kim jest Maria, żona księcia Fryderyka.

## Iwona Śledzińska-Katarasińska nie żyje
 - [https://tvn24.pl/polska/iwona-sledzinska-katarasinska-nie-zyje-7663800?source=rss](https://tvn24.pl/polska/iwona-sledzinska-katarasinska-nie-zyje-7663800?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T10:35:00+00:00

<img alt="Iwona Śledzińska-Katarasińska nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-euhd6u-iwona-sledzinska-katarasinska-7663801/alternates/LANDSCAPE_1280" />
    Była posłanką Platformy Obywatelskiej i parlamentarzystką najdłużej zasiadającą nieprzerwanie w Sejmie

## Trener Polaków szykuje niespodziankę
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2023.-thomas-thurnbichler-po-kwalifikacjach-co-powiedzial-t_sto9940230/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/skoki-narciarskie-garmisch-partenkirchen-2023.-thomas-thurnbichler-po-kwalifikacjach-co-powiedzial-t_sto9940230/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T10:20:00+00:00

<img alt="Trener Polaków szykuje niespodziankę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7r051f-thurnbichler-po-kwalifikacjach-w-garmisch-partenkirchen-7663897/alternates/LANDSCAPE_1280" />
    "Czeka nas lepszy początek roku".

## Sylwestrowa noc gwiazd sportu
 - [https://eurosport.tvn24.pl/pilka-nozna/tak-sportowcy-witali-nowy-2024-rok-gdzie-spedzili-sylwestra_sto9940270/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/tak-sportowcy-witali-nowy-2024-rok-gdzie-spedzili-sylwestra_sto9940270/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T09:57:00+00:00

<img alt="Sylwestrowa noc gwiazd sportu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rgipct-polscy-sportowcy-przywitali-2024-rok-7663870/alternates/LANDSCAPE_1280" />
    Nie wszyscy mogli pozwolić sobie na huczną zabawę.

## Jak minęła sylwestrowa noc? "Było blisko 600 pożarów"
 - [https://tvn24.pl/polska/sylwester-2023-straz-pozarna-podsumowuje-noc-interwencje-i-pozary-7663785?source=rss](https://tvn24.pl/polska/sylwester-2023-straz-pozarna-podsumowuje-noc-interwencje-i-pozary-7663785?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T08:34:58+00:00

<img alt="Jak minęła sylwestrowa noc? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-y9vtc1-zdjecia-z-pozaru-otrzymane-na-kontakt24-7663828/alternates/LANDSCAPE_1280" />
    O interwencjach strażaków mówił starszy brygadier Karol Kierzkowski, rzecznik prasowy Komendanta Głównego PSP.

## "To może budzić obawy". Setki wyciętych drzew przy ścieżkach w Kampinoskim Parku Narodowym
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-kampinoski-park-narodowy-tlumaczy-dlaczego-wycina-drzewa-st7663175?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-kampinoski-park-narodowy-tlumaczy-dlaczego-wycina-drzewa-st7663175?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T08:32:31+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6mtg1j-wycinki-w-kampinoskim-parku-narodowym-7663247/alternates/LANDSCAPE_1280" />
    Władze parku tłumaczą, dlaczego tak się dzieje.

## "Agenda Bidena jest popularna, ale on sam nie jest". Czy 2024 będzie rokiem Trumpa?
 - [https://tvn24.pl/premium/agenda-bidena-jest-popularna-ale-on-sam-nie-jest-czy-2024-bedzie-rokiem-trumpa-7642735?source=rss](https://tvn24.pl/premium/agenda-bidena-jest-popularna-ale-on-sam-nie-jest-czy-2024-bedzie-rokiem-trumpa-7642735?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T08:30:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3l7xjr-gettyimages-1831280803-7652327/alternates/LANDSCAPE_1280" />
    Nie tylko dla Amerykanów będzie to kluczowe pytanie w 2024 roku: czy Donald Trump może wrócić do Białego Domu? Trudno w to uwierzyć, ale owszem, może. Wielu obserwatorów, zwłaszcza spoza Stanów Zjednoczonych, zastanawia się - jakim cudem.

## Silne trzęsienie ziemi i ostrzeżenia przed tsunami
 - [https://tvn24.pl/tvnmeteo/swiat/japonia-silne-trzesienie-ziemi-w-japonii-wydano-ostrzezenia-przed-tsunami-st7663780?source=rss](https://tvn24.pl/tvnmeteo/swiat/japonia-silne-trzesienie-ziemi-w-japonii-wydano-ostrzezenia-przed-tsunami-st7663780?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T08:05:30+00:00

<img alt="Silne trzęsienie ziemi i ostrzeżenia przed tsunami" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-yhrmyf-lokalizacja-trzesienia-ziemi-7663781/alternates/LANDSCAPE_1280" />
    Japonia.

## Zabici, zawalone budynki. Wysyłają wojsko na pomoc
 - [https://tvn24.pl/tvnmeteo/swiat/japonia-silne-trzesienie-ziemi-zabici-i-powazne-zniszczenia-pojawily-sie-fale-tsunami-st7663780?source=rss](https://tvn24.pl/tvnmeteo/swiat/japonia-silne-trzesienie-ziemi-zabici-i-powazne-zniszczenia-pojawily-sie-fale-tsunami-st7663780?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T08:05:30+00:00

<img alt="Zabici, zawalone budynki. Wysyłają wojsko na pomoc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8edf76-zniszczenia-po-trzesieniu-ziemi-w-japonii-7664205/alternates/LANDSCAPE_1280" />
    Silne trzęsienie ziemi w środkowej Japonii.

## Spektakularne zwycięstwo i awans Świątek i Hurkacza
 - [https://eurosport.tvn24.pl/tenis/united-cup-2/2024/polska-hiszpania-wynik-i-relacja.-rowerek-igi-swiatek-i-huberta-hurkacza_sto9940258/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/united-cup-2/2024/polska-hiszpania-wynik-i-relacja.-rowerek-igi-swiatek-i-huberta-hurkacza_sto9940258/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T07:56:00+00:00

<img alt="Spektakularne zwycięstwo i awans Świątek i Hurkacza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eeb16b-iga-swiatek-hubert-hurkacz-7663783/alternates/LANDSCAPE_1280" />
    W wielkim stylu w nowy rok weszli najlepsi polscy tenisiści.

## Od 1 stycznia drożeją alkohol i papierosy. O ile?
 - [https://tvn24.pl/biznes/z-kraju/podwyzka-cen-alkoholu-i-papierosow-to-wynik-wyzszej-akcyzy-od-1-stycznia-2024-roku-st7663778?source=rss](https://tvn24.pl/biznes/z-kraju/podwyzka-cen-alkoholu-i-papierosow-to-wynik-wyzszej-akcyzy-od-1-stycznia-2024-roku-st7663778?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T07:55:31+00:00

<img alt="Od 1 stycznia drożeją alkohol i papierosy. O ile?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z6nkv9-trzy-osoby-pily-razem-alkohol-zdjecie-ilustracyjne-7464798/alternates/LANDSCAPE_1280" />
    Wyższa akcyza.

## Zostawił sześć kotów w zamkniętym mieszkaniu. Na dziewięć miesięcy, żaden nie przeżył
 - [https://tvn24.pl/tvnwarszawa/okolice/radom-zostawil-szesc-kotow-w-zamknietym-mieszkaniu-na-dziewiec-miesiecy-zaden-nie-przezyl-co-mu-grozi-st7663578?source=rss](https://tvn24.pl/tvnwarszawa/okolice/radom-zostawil-szesc-kotow-w-zamknietym-mieszkaniu-na-dziewiec-miesiecy-zaden-nie-przezyl-co-mu-grozi-st7663578?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T07:51:00+00:00

<img alt="Zostawił sześć kotów w zamkniętym mieszkaniu. Na dziewięć miesięcy, żaden nie przeżył" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-3t4xvt-sledztwo-prowadzi-prokuratura-okregowa-w-radomiu-6624708/alternates/LANDSCAPE_1280" />
    44-latkowi grozi do pięciu lat więzienia.

## "Ostatnie godziny roku 2023". Jarosław Kaczyński w siedzibie TVP
 - [https://tvn24.pl/polska/zmiany-w-mediach-publicznych-jaroslaw-kaczynski-w-sylwestra-w-siedzibie-tvp-ryszard-czarnecki-opublikowal-zdjecie-7663765?source=rss](https://tvn24.pl/polska/zmiany-w-mediach-publicznych-jaroslaw-kaczynski-w-sylwestra-w-siedzibie-tvp-ryszard-czarnecki-opublikowal-zdjecie-7663765?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T07:40:25+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gn2c3a-fotografia-z-wpisu-ryszarda-czarneckiego-7663768/alternates/LANDSCAPE_1280" />
    Europoseł PiS Ryszard Czarnecki opublikował zdjęcie.

## Jednorazowe opakowania. Nowe opłaty weszły w życie
 - [https://tvn24.pl/biznes/z-kraju/oplaty-jednorazowe-za-plastik-wchodza-w-zycie-od-1-stycznia-2024-roku-st7663773?source=rss](https://tvn24.pl/biznes/z-kraju/oplaty-jednorazowe-za-plastik-wchodza-w-zycie-od-1-stycznia-2024-roku-st7663773?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T07:40:04+00:00

<img alt="Jednorazowe opakowania. Nowe opłaty weszły w życie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-18tswr-sztucce-taleze-kubki-kubek-opakowanie-opakowania-plastikowe-shutterstock1496093477-5201171/alternates/LANDSCAPE_1280" />
    W różnej wysokości.

## Atak dronów na Lwów
 - [https://tvn24.pl/swiat/drony-zaatakowaly-ukraine-w-sylwestrowa-noc-7663763?source=rss](https://tvn24.pl/swiat/drony-zaatakowaly-ukraine-w-sylwestrowa-noc-7663763?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T06:38:45+00:00

<img alt="Atak dronów na Lwów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8bzkfu-lwow-atak-dronow-7663760/alternates/LANDSCAPE_1280" />
    W Odessie zginęła jedna osoba.

## Idą duże opady śniegu. Alerty IMGW dla kilku województw
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-zima-wraca-do-polski-snieg-bedzie-padac-intensywnie-nawet-kilkanascie-centymetrow-st7663754?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-zima-wraca-do-polski-snieg-bedzie-padac-intensywnie-nawet-kilkanascie-centymetrow-st7663754?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T05:38:51+00:00

<img alt="Idą duże opady śniegu. Alerty IMGW dla kilku województw" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-pcavut-intensywne-opady-sniegu-7664076/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie będzie niebezpiecznie.

## Sypnie kilkanaście centymetrów śniegu. IMGW ostrzega
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-opady-sniegu-snieg-w-nowy-rok-zima-wraca-do-polski-prognoza-zagrozen-imgw-na-poczatek-stycznia-st7663754?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-opady-sniegu-snieg-w-nowy-rok-zima-wraca-do-polski-prognoza-zagrozen-imgw-na-poczatek-stycznia-st7663754?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T05:38:51+00:00

<img alt="Sypnie kilkanaście centymetrów śniegu. IMGW ostrzega" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-bhlcvw-snieg-wiatr-zawieje-zamiecie-6806411/alternates/LANDSCAPE_1280" />
    Obowiązują alerty i prognoza zagrożeń.

## "Powiedział, że ma granaty i groził wysadzeniem bloku"
 - [https://tvn24.pl/polska/lublin-poszukiwany-mezczyzna-grozil-wysadzeniem-bloku-interweniowali-kontrterrorysci-7663653?source=rss](https://tvn24.pl/polska/lublin-poszukiwany-mezczyzna-grozil-wysadzeniem-bloku-interweniowali-kontrterrorysci-7663653?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T05:32:19+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8dunyw-kontrterrorysci-7663738/alternates/LANDSCAPE_1280" />
    W Lublinie.

## "Cenna inwestycja" Zjednoczonej Prawicy. Do kieszeni o. Rydzyka z naszych pieniędzy trafiły ogromne sumy
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2489,S00E2489,1245357?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2489,S00E2489,1245357?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T04:20:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ixh17v-ojciec-rydzyk-7653807/alternates/LANDSCAPE_1280" />
    Oszacował to, na podstawie oficjalnych i jawnych źródeł, Łukasz Karusta z "Czarno na białym".

## Orędzie prezydenta, niespodziewana abdykacja, rosyjskie ataki
 - [https://tvn24.pl/polska/piec-rzeczy-ktore-warto-wiedziec-1-stycznia-7663726?source=rss](https://tvn24.pl/polska/piec-rzeczy-ktore-warto-wiedziec-1-stycznia-7663726?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T03:28:42+00:00

<img alt="Orędzie prezydenta, niespodziewana abdykacja, rosyjskie ataki " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gre35x-charkow-7662800/alternates/LANDSCAPE_1280" />
    Pięć rzeczy, które warto wiedzieć 1 stycznia.

## Dawny imprezowicz, który "nie chce się zamykać w fortecy". Zostanie królem
 - [https://tvn24.pl/swiat/dania-krolowa-malgorzata-ii-abdykuje-kim-jest-nastepca-tronu-fryderyk-7663716?source=rss](https://tvn24.pl/swiat/dania-krolowa-malgorzata-ii-abdykuje-kim-jest-nastepca-tronu-fryderyk-7663716?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T03:18:53+00:00

<img alt="Dawny imprezowicz, który " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yjnwbl-dunski-ksiaze-fryderyk-7663717/alternates/LANDSCAPE_1280" />
    Kim jest książę Fryderyk?

## Trzy scenariusze dla Ukrainy. "2024 rok będzie trudniejszy"
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-trzy-scenariusze-na-2024-rok-7663710?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-trzy-scenariusze-na-2024-rok-7663710?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T03:18:39+00:00

<img alt="Trzy scenariusze dla Ukrainy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fdi2jo-23c30025-7663720/alternates/LANDSCAPE_1280" />
    W lutym miną trzy lata od zbrojnego ataku Rosji na Ukrainę. W ostatnich tygodniach byliśmy świadkami impasu na froncie. Czy 2024 rok przyniesie przełom w wojnie toczącej się za naszą wschodnią granicą? Oto trzy scenariusze na najbliższe 12 miesięcy.

## Macron o "decydującym wyborze"
 - [https://tvn24.pl/swiat/francja-prezydent-emmanuel-macron-w-noworocznym-oredziu-7663737?source=rss](https://tvn24.pl/swiat/francja-prezydent-emmanuel-macron-w-noworocznym-oredziu-7663737?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T03:11:39+00:00

<img alt="Macron o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ao92lc-macron-2-7663712/alternates/LANDSCAPE_1280" />
    Noworoczne orędzie prezydenta Francji.

## Kim Dzong Un obiecuje zacieśnienie relacji z Chinami. Seulowi grozi atakiem
 - [https://tvn24.pl/swiat/korea-polnocna-chiny-kim-dzong-un-obiecuje-zaciesnienie-relacji-z-chinami-7663730?source=rss](https://tvn24.pl/swiat/korea-polnocna-chiny-kim-dzong-un-obiecuje-zaciesnienie-relacji-z-chinami-7663730?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T02:30:55+00:00

<img alt="Kim Dzong Un obiecuje zacieśnienie relacji z Chinami. Seulowi grozi atakiem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yrxvcu-kim-dzong-un-xi-jinping-7663713/alternates/LANDSCAPE_1280" />
    Noworoczne przesłanie od północnokoreańskiego przywódcy.

## Zełenski zapowiada: wróg poczuje naszą wściekłość
 - [https://tvn24.pl/swiat/oredzie-noworoczne-wolodymyra-zelenskiego-o-czym-mowil-7663699?source=rss](https://tvn24.pl/swiat/oredzie-noworoczne-wolodymyra-zelenskiego-o-czym-mowil-7663699?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-01T00:03:07+00:00

<img alt="Zełenski zapowiada: wróg poczuje naszą wściekłość" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rwh1xb-oredzie-wolodymyra-zelenskiego-7663703/alternates/LANDSCAPE_1280" />
    Orędzie noworoczne prezydenta Ukrainy.

