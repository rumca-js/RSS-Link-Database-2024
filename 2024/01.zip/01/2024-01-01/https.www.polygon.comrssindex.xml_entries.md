# Source:Polygon -  All, URL:https://www.polygon.com/rss/index.xml, language:en

## Netflix’s The Brothers Sun, the Golden Globes, and more new TV this week
 - [https://www.polygon.com/2024/1/1/23990872/new-tv-netflix-watch-golden-globes-michelle-yeoh-thriller](https://www.polygon.com/2024/1/1/23990872/new-tv-netflix-watch-golden-globes-michelle-yeoh-thriller)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2024-01-01T19:00:00+00:00

<figure>
      <img alt="Michelle Yeoh as Mama Sun drinking tea deep in thought" src="https://cdn.vox-cdn.com/thumbor/ZrfzU1o2a-3xPO2_sGAJnRAedzg=/0x0:3600x2025/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/73014628/BROSUN_105_Unit_01179RC.0.jpg" />
        <figcaption>Photo: Michael Desmond/Netflix</figcaption>
    </figure>

  <p>Michelle Yeoh’s Netflix action show is here</p>
  <p>
    <a href="https://www.polygon.com/2024/1/1/23990872/new-tv-netflix-watch-golden-globes-michelle-yeoh-thriller">Continue reading&hellip;</a>
  </p>

## The 50 most anticipated new movies of 2024
 - [https://www.polygon.com/24007773/best-new-movies-2024-release-calendar-schedule](https://www.polygon.com/24007773/best-new-movies-2024-release-calendar-schedule)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2024-01-01T15:00:00+00:00

<figure>
      <img alt="A collection of images from titles previewed in this story, collected in a grid format" src="https://cdn.vox-cdn.com/thumbor/cpDK1Apt4YN5BySZ3JnLWjFQS8I=/0x0:3390x1907/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/73014135/polygon_background.0.jpg" />
        <figcaption>Graphic: Pete Volk/Polygon | Source images: Various</figcaption>
    </figure>


  		<p>Buckle in for a big year at the movies</p>
  <p>
    <a href="https://www.polygon.com/24007773/best-new-movies-2024-release-calendar-schedule">Continue reading&hellip;</a>
  </p>

## The 50 most anticipated new games of 2024
 - [https://www.polygon.com/gaming/24007775/best-new-games-2024-release-calendar-schedule](https://www.polygon.com/gaming/24007775/best-new-games-2024-release-calendar-schedule)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2024-01-01T14:00:00+00:00

<figure>
      <img alt="A grid image of titles featured in this post" src="https://cdn.vox-cdn.com/thumbor/wyqVJuRiFwfBgfJQPOlBup4SOjo=/0x47:3390x1954/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/73014022/2024gamespreview__1_.0.jpg" />
        <figcaption>Graphic: Pete Volk/Polygon | Source images: Various</figcaption>
    </figure>


  		<p>2023 set a high bar for video game releases, and 2024 looks no different</p>
  <p>
    <a href="https://www.polygon.com/gaming/24007775/best-new-games-2024-release-calendar-schedule">Continue reading&hellip;</a>
  </p>

## Every movie and show coming to Netflix in January
 - [https://www.polygon.com/entertainment/2024/1/1/24012219/new-netflix-jan-2024-movies-tv-to-watch](https://www.polygon.com/entertainment/2024/1/1/24012219/new-netflix-jan-2024-movies-tv-to-watch)
 - RSS feed: https://www.polygon.com/rss/index.xml
 - date published: 2024-01-01T13:05:00+00:00

<figure>
      <img alt="Willem Dafoe stands between a man and woman in a purple doorway in The Florida Project" src="https://cdn.vox-cdn.com/thumbor/T-AZSovxJe3nKgugFigMuCP5PQw=/203x0:1803x900/640x360/cdn.vox-cdn.com/uploads/chorus_image/image/73013976/MCDFLPR_EC035.0.jpg" />
        <figcaption>Photo: A24/Everett Collection</figcaption>
    </figure>

  <p>2024 kicks off with Sonic, Love Is Blind, and Kevin Hart’s heist movie</p>
  <p>
    <a href="https://www.polygon.com/entertainment/2024/1/1/24012219/new-netflix-jan-2024-movies-tv-to-watch">Continue reading&hellip;</a>
  </p>

