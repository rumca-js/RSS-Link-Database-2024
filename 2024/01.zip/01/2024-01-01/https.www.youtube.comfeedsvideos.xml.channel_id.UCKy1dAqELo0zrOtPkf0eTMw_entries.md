# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## The Biggest Games Coming in 2024
 - [https://www.youtube.com/watch?v=7Bb_QpVUMJQ](https://www.youtube.com/watch?v=7Bb_QpVUMJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-01-01T18:00:03+00:00

2023 was a fantastic year for gaming thanks to so many wonderful titles launching, and 2024 is looking to be just as awesome!  Some of the biggest games coming in 2024 include Final Fantasy VII Rebirth, Hellblade 2, Tekken 8, and Star Wars Outlaws! Stick around to see a more comprehensive list of some of the biggest games coming in 2024!

Don’t forget, each month, we also break down the list of upcoming games to highlight the biggest ones launching that specific month! You can expect to see more content like this in the future! Check out The Biggest Game Releases of January 2024.

00:00 - Intro & Prince of Persia: The Lost Crown
00:00 - Tekken 8, Like a Dragon: Infinite Wealth, Suicide Squad Kills The Justice League
00:00 - Persona 3, Helldivers II, Skull & Bones, Final Fantasy VII: Rebirth
00:00 - Alone in the Dark, Dragon’s Dogma 2, Rise of the Ronin, Princess Peach: Showtime!
00:00 - Black Myth Wukong, Warhammer 40K: Space Marine 2, Senua's Saga: Hellblade II, STALKER 2: Heart of 

## Infestation 88 - Official Reveal Trailer
 - [https://www.youtube.com/watch?v=Qe85jZhSflk](https://www.youtube.com/watch?v=Qe85jZhSflk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-01-01T16:00:13+00:00

Nightmare Forge games has announced Infestation 88, a new horror game that aims to blend terror with nostalgia (in the vein of Winnie the Pooh: Blood and Honey) by twisting the now-in-the-public-domain Steamboat Willie into something much scarier.

#IGN #Gaming

## Alan Wake 2 - "Dark Ocean Summoning" Full Gameplay Sequence
 - [https://www.youtube.com/watch?v=aWdAVSRh_tU](https://www.youtube.com/watch?v=aWdAVSRh_tU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-01-01T16:00:01+00:00

The Old Gods of Asgard is a fictional band in the connected Remedy Universe, and they're a breakout hit in the Alan Wake franchise. After a Game Awards 2023 live performance, the Herald of Darkness song is on everyone's mind. But did you know that the Old Gods of Asgards give two performances in Alan Wake 2? In the video above, we'll show you the second performance and the battle that happens during it. Just be warned, this will contain some spoilers for Alan Wake 2's story, so if you haven't finished the game but plan to, then this video may not be for you!

#IGN #Gaming

