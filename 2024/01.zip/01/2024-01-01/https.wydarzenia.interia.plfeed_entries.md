# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Rozmowy pokojowe Ukraina - Rosja? Jasna deklaracja z Kijowa
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rozmowy-pokojowe-ukraina-rosja-jasna-deklaracja-z-kijowa,nId,7243126](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rozmowy-pokojowe-ukraina-rosja-jasna-deklaracja-z-kijowa,nId,7243126)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T21:24:43+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rozmowy-pokojowe-ukraina-rosja-jasna-deklaracja-z-kijowa,nId,7243126"><img align="left" alt="Rozmowy pokojowe Ukraina - Rosja? Jasna deklaracja z Kijowa" src="https://i.iplsc.com/rozmowy-pokojowe-ukraina-rosja-jasna-deklaracja-z-kijowa/000IBFTAT6CAE6OX-C321.jpg" /></a>Rosjanie potrzebują tej przerwy. Odzyskają wszystkie siły - stwierdził Wołodymyr Zełenski odnosząc się do rzekomych dążeń Rosji do przeprowadzenia rozmów pokojowych. Zdaniem prezydenta Ukrainy, nie ma obecnie możliwości zatrzymania działań wojennych.</p><br clear="all" />

## Polityk chciał wynagrodzić urzędniczki. Jako premię otrzymały jajka
 - [https://wydarzenia.interia.pl/zagranica/news-polityk-chcial-wynagrodzic-urzedniczki-jako-premie-otrzymaly,nId,7243118](https://wydarzenia.interia.pl/zagranica/news-polityk-chcial-wynagrodzic-urzedniczki-jako-premie-otrzymaly,nId,7243118)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T20:24:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polityk-chcial-wynagrodzic-urzedniczki-jako-premie-otrzymaly,nId,7243118"><img align="left" alt="Polityk chciał wynagrodzić urzędniczki. Jako premię otrzymały jajka" src="https://i.iplsc.com/polityk-chcial-wynagrodzic-urzedniczki-jako-premie-otrzymaly/000IBFNOH7GRH58R-C321.jpg" /></a>Oleksandr Gordeew jednym wpisem w mediach społecznościowych stał się absolutną gwiazdą rosyjskiego internetu. Poseł do rady obwodu Wołogdy w Federacji Rosyjskiej postanowił wynagrodzić miejscowe urzędniczki paczką kurzych jaj. </p><br clear="all" />

## Marcin Mastalerek o słowach Jana Pietrzaka. "Bezdennie głupia wypowiedź"
 - [https://wydarzenia.interia.pl/kraj/news-marcin-mastalerek-o-slowach-jana-pietrzaka-bezdennie-glupia-,nId,7243114](https://wydarzenia.interia.pl/kraj/news-marcin-mastalerek-o-slowach-jana-pietrzaka-bezdennie-glupia-,nId,7243114)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T19:58:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-marcin-mastalerek-o-slowach-jana-pietrzaka-bezdennie-glupia-,nId,7243114"><img align="left" alt="Marcin Mastalerek o słowach Jana Pietrzaka. &quot;Bezdennie głupia wypowiedź&quot;" src="https://i.iplsc.com/marcin-mastalerek-o-slowach-jana-pietrzaka-bezdennie-glupia/000IBFKUMWPV9OOD-C321.jpg" /></a>To była dla mnie bezdennie głupia wypowiedź, ja się na nią nie godzę i gdybym spotkał Jana Pietrzaka, to bym mu to powiedział - twierdzi Marcin Mastalerek. Szef gabinetu prezydenta odniósł się do słów wypowiedzianych przez satyryka w programie TV Republika.</p><br clear="all" />

## Czuła się samotna w sylwestra. Zadzwoniła po policję
 - [https://wydarzenia.interia.pl/zagranica/news-czula-sie-samotna-w-sylwestra-zadzwonila-po-policje,nId,7243112](https://wydarzenia.interia.pl/zagranica/news-czula-sie-samotna-w-sylwestra-zadzwonila-po-policje,nId,7243112)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T19:52:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czula-sie-samotna-w-sylwestra-zadzwonila-po-policje,nId,7243112"><img align="left" alt="Czuła się samotna w sylwestra. Zadzwoniła po policję" src="https://i.iplsc.com/czula-sie-samotna-w-sylwestra-zadzwonila-po-policje/000IBFJSEU56EJJ2-C321.jpg" /></a>94-letnia mieszkanka Piemontu we Włoszech poczuła się tak bardzo samotna w sylwestrowy wieczór, że zadzwoniła na policję, by z kimś porozmawiać i żeby ktoś złożył jej życzenia. Dwóch funkcjonariuszy postanowiło spędzić czas z seniorką.</p><br clear="all" />

## Kolejny dowódca Hamasu nie żyje. Kierował zamachem w październiku
 - [https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kolejny-dowodca-hamasu-nie-zyje-kierowal-zamachem-w-pazdzier,nId,7243110](https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kolejny-dowodca-hamasu-nie-zyje-kierowal-zamachem-w-pazdzier,nId,7243110)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T19:19:51+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wojna-w-izraelu/news-kolejny-dowodca-hamasu-nie-zyje-kierowal-zamachem-w-pazdzier,nId,7243110"><img align="left" alt="Kolejny dowódca Hamasu nie żyje. Kierował zamachem w październiku" src="https://i.iplsc.com/kolejny-dowodca-hamasu-nie-zyje-kierowal-zamachem-w-pazdzier/000IBFG4PEWAPRN0-C321.jpg" /></a>Siły Obronne Izraela poinformowały o zabiciu kolejnego wysokiego dowódcy Hamasu. Tym razem w nalocie zginął Adil Mismah dowódca sił specjalnych organizacji w mieście Dajr al-Balah. Według Izraelczyków mężczyzna odgrywał ważną rolę podczas ataku terrorystycznego 7 października.</p><br clear="all" />

## Nowy cel Rosjan. Ekspert: Planują desant w Odessie i zajęcie obwodu
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowy-cel-rosjan-ekspert-planuja-desant-w-odessie-i-zajecie-o,nId,7243108](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowy-cel-rosjan-ekspert-planuja-desant-w-odessie-i-zajecie-o,nId,7243108)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T19:14:32+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowy-cel-rosjan-ekspert-planuja-desant-w-odessie-i-zajecie-o,nId,7243108"><img align="left" alt="Nowy cel Rosjan. Ekspert: Planują desant w Odessie i zajęcie obwodu" src="https://i.iplsc.com/nowy-cel-rosjan-ekspert-planuja-desant-w-odessie-i-zajecie-o/000IBFF7P3CGA4O4-C321.jpg" /></a>Federacja Rosyjska planuje desant w Odessie, są plany zajęcia obwodów dnieprskiego i dniepropietrowskiego - twierdzi Iwan Stupak. Ekspert ukraińskiego Instytutu Przyszłości wskazał na konkretne cele rosyjskiej armii na najbliższe kilka miesięcy wojny.</p><br clear="all" />

## Białoruś: Hakerzy zaatakowali reżimową agencję. "Przywracamy wolność słowa"
 - [https://wydarzenia.interia.pl/zagranica/news-bialorus-hakerzy-zaatakowali-rezimowa-agencje-przywracamy-wo,nId,7243093](https://wydarzenia.interia.pl/zagranica/news-bialorus-hakerzy-zaatakowali-rezimowa-agencje-przywracamy-wo,nId,7243093)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T18:01:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialorus-hakerzy-zaatakowali-rezimowa-agencje-przywracamy-wo,nId,7243093"><img align="left" alt="Białoruś: Hakerzy zaatakowali reżimową agencję. &quot;Przywracamy wolność słowa&quot;" src="https://i.iplsc.com/bialorus-hakerzy-zaatakowali-rezimowa-agencje-przywracamy-wo/000IBF8XMBOHFNYY-C321.jpg" /></a>&quot;Przywracamy wolność słowa na Białorusi. Czytajcie wiadomości niezależnych mediów, a nie kłamstwa propagandy reżimu&quot; - napisali hakerzy z grupy &quot;Cyberpartyzanci&quot;, którzy dokonali udanego ataku na stronę internetową białoruskiej agencji BiełTa. Przejęcie serwisu nastąpiło kilka godzin przed emisją noworocznego orędzia Alaksandra Łukaszenki.</p><br clear="all" />

## Atak rekina na Hawajach. Nie żyje 39-letni mężczyzna
 - [https://wydarzenia.interia.pl/zagranica/news-atak-rekina-na-hawajach-nie-zyje-39-letni-mezczyzna,nId,7243089](https://wydarzenia.interia.pl/zagranica/news-atak-rekina-na-hawajach-nie-zyje-39-letni-mezczyzna,nId,7243089)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T17:49:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-atak-rekina-na-hawajach-nie-zyje-39-letni-mezczyzna,nId,7243089"><img align="left" alt="Atak rekina na Hawajach. Nie żyje 39-letni mężczyzna" src="https://i.iplsc.com/atak-rekina-na-hawajach-nie-zyje-39-letni-mezczyzna/000IBF6G3XFDLTEK-C321.jpg" /></a>Do tragicznego wypadku doszło na Hawajach. 39-latek został zaatakowany przez rekina. Mimo błyskawicznie udzielonej pomocy, mężczyzny nie udało się uratować. To pierwszy taki przypadek na archipelagu od ponad roku. </p><br clear="all" />

## To może zaboleć Putina. W życie weszły ważne sankcje
 - [https://wydarzenia.interia.pl/zagranica/news-to-moze-zabolec-putina-w-zycie-weszly-wazne-sankcje,nId,7243080](https://wydarzenia.interia.pl/zagranica/news-to-moze-zabolec-putina-w-zycie-weszly-wazne-sankcje,nId,7243080)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T16:56:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-to-moze-zabolec-putina-w-zycie-weszly-wazne-sankcje,nId,7243080"><img align="left" alt="To może zaboleć Putina. W życie weszły ważne sankcje" src="https://i.iplsc.com/to-moze-zabolec-putina-w-zycie-weszly-wazne-sankcje/000IBF1RMD3BCQPC-C321.jpg" /></a>Od 1 stycznia obowiązuje zakaz handlu diamentami pochodzącymi z Federacji Rosyjskiej. Embargo na kamienie to część 12. pakietu sankcji nałożonego na to państwo przez Radę Unii Europejskiej. Handel diamentami przynosi państwu Putina kilka miliardów euro rocznie.</p><br clear="all" />

## Generał Walerij Załużny przemówił do wojskowych. "Rok 2024 nie będzie łatwy"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-general-walerij-zaluzny-przemowil-do-wojskowych-rok-2024-nie,nId,7243078](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-general-walerij-zaluzny-przemowil-do-wojskowych-rok-2024-nie,nId,7243078)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T16:50:35+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-general-walerij-zaluzny-przemowil-do-wojskowych-rok-2024-nie,nId,7243078"><img align="left" alt="Generał Walerij Załużny przemówił do wojskowych. &quot;Rok 2024 nie będzie łatwy&quot;" src="https://i.iplsc.com/general-walerij-zaluzny-przemowil-do-wojskowych-rok-2024-nie/000IAD8OXTEIB4KL-C321.jpg" /></a>Rok 2024 nie będzie łatwy. Walka o wolność i przyszłość naszych dzieci trwa - pisze generał Walerij Załużny. Głównodowodzący Sił Zbrojnych Ukrainy zwrócił się do żołnierzy w noworocznym przemówieniu składając im życzenia i zachęcając do walki.</p><br clear="all" />

## Francuscy kucharze stworzyli rekordową pizzę. Ich wynik przejdzie do historii
 - [https://wydarzenia.interia.pl/zagranica/news-francuscy-kucharze-stworzyli-rekordowa-pizze-ich-wynik-przej,nId,7243069](https://wydarzenia.interia.pl/zagranica/news-francuscy-kucharze-stworzyli-rekordowa-pizze-ich-wynik-przej,nId,7243069)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T15:51:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-francuscy-kucharze-stworzyli-rekordowa-pizze-ich-wynik-przej,nId,7243069"><img align="left" alt="Francuscy kucharze stworzyli rekordową pizzę. Ich wynik przejdzie do historii" src="https://i.iplsc.com/francuscy-kucharze-stworzyli-rekordowa-pizze-ich-wynik-przej/000IBES34YIOU9PV-C321.jpg" /></a>1001 rodzajów sera położonych zostało na rekordowej pizzy stworzonej przez francuskich szefów Benoita Bruela i Fabiena Montellanico. Wyczyn kucharzy został wpisany do Księgi Rekordów Guinessa.</p><br clear="all" />

## Hiszpanów nie stać na ogrzewanie. Problem dotyka kilku milionów osób
 - [https://wydarzenia.interia.pl/zagranica/news-hiszpanow-nie-stac-na-ogrzewanie-problem-dotyka-kilku-milion,nId,7243060](https://wydarzenia.interia.pl/zagranica/news-hiszpanow-nie-stac-na-ogrzewanie-problem-dotyka-kilku-milion,nId,7243060)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T14:52:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-hiszpanow-nie-stac-na-ogrzewanie-problem-dotyka-kilku-milion,nId,7243060"><img align="left" alt="Hiszpanów nie stać na ogrzewanie. Problem dotyka kilku milionów osób" src="https://i.iplsc.com/hiszpanow-nie-stac-na-ogrzewanie-problem-dotyka-kilku-milion/000IBEO00RW8EDOC-C321.jpg" /></a>Rośnie liczba Hiszpanów, którzy mierzą się z kryzysem energetycznym. Już ponad 8 mln mieszkańców 48-milionowej Hiszpanii skarży się na brak środków na ogrzewanie domów. To o milion więcej niż w 2021 r. Ich sytuację ułatwia jednak wyjątkowo ciepła zima. </p><br clear="all" />

## "Okrutny żart" Jana Pietrzaka. Jest reakcja Prokuratora Generalnego Adama Bodnara
 - [https://wydarzenia.interia.pl/kraj/news-okrutny-zart-jana-pietrzaka-jest-reakcja-prokuratora-general,nId,7243058](https://wydarzenia.interia.pl/kraj/news-okrutny-zart-jana-pietrzaka-jest-reakcja-prokuratora-general,nId,7243058)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T14:41:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-okrutny-zart-jana-pietrzaka-jest-reakcja-prokuratora-general,nId,7243058"><img align="left" alt="&quot;Okrutny żart&quot; Jana Pietrzaka. Jest reakcja Prokuratora Generalnego Adama Bodnara" src="https://i.iplsc.com/okrutny-zart-jana-pietrzaka-jest-reakcja-prokuratora-general/000IBEN0AUDAD114-C321.jpg" /></a>Minister sprawiedliwości Adam Bodnar zareagował na słowa wypowiedziane przez Jana Pietrzaka na antenie Telewizji Republika odnoszące się do nielegalnych imigrantów. Polityk zapowiedział &quot;zajęcie się sprawą&quot; i wszczęcie śledztwa wobec satyryka.</p><br clear="all" />

## Skandaliczne słowa Jana Pietrzaka. Jest reakcja Prokuratora Generalnego Adama Bodnara
 - [https://wydarzenia.interia.pl/kraj/news-skandaliczne-slowa-jana-pietrzaka-jest-reakcja-prokuratora-g,nId,7243058](https://wydarzenia.interia.pl/kraj/news-skandaliczne-slowa-jana-pietrzaka-jest-reakcja-prokuratora-g,nId,7243058)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T14:41:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-skandaliczne-slowa-jana-pietrzaka-jest-reakcja-prokuratora-g,nId,7243058"><img align="left" alt="Skandaliczne słowa Jana Pietrzaka. Jest reakcja Prokuratora Generalnego Adama Bodnara" src="https://i.iplsc.com/skandaliczne-slowa-jana-pietrzaka-jest-reakcja-prokuratora-g/000IBEN0AUDAD114-C321.jpg" /></a>Minister sprawiedliwości Adam Bodnar zareagował na słowa wypowiedziane przez Jana Pietrzaka na antenie Telewizji Republika odnoszące się do nielegalnych imigrantów. Polityk zapowiedział &quot;zajęcie się sprawą&quot; i wszczęcie śledztwa wobec satyryka.</p><br clear="all" />

## Skandaliczny "żart" Jana Pietrzaka. Jest reakcja Prokuratora Generalnego Adama Bodnara
 - [https://wydarzenia.interia.pl/kraj/news-skandaliczny-zart-jana-pietrzaka-jest-reakcja-prokuratora-ge,nId,7243058](https://wydarzenia.interia.pl/kraj/news-skandaliczny-zart-jana-pietrzaka-jest-reakcja-prokuratora-ge,nId,7243058)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T14:41:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-skandaliczny-zart-jana-pietrzaka-jest-reakcja-prokuratora-ge,nId,7243058"><img align="left" alt="Skandaliczny &quot;żart&quot; Jana Pietrzaka. Jest reakcja Prokuratora Generalnego Adama Bodnara" src="https://i.iplsc.com/skandaliczny-zart-jana-pietrzaka-jest-reakcja-prokuratora-ge/000IBEN0AUDAD114-C321.jpg" /></a>Minister sprawiedliwości Adam Bodnar zareagował na słowa wypowiedziane przez Jana Pietrzaka na antenie Telewizji Republika odnoszące się do nielegalnych imigrantów. Polityk zapowiedział &quot;zajęcie się sprawą&quot; i wszczęcie śledztwa wobec satyryka.</p><br clear="all" />

## Ukraina wysłała drony przeciwko Rosji. Elon Musk wyłączył łączność
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-wyslala-drony-przeciwko-rosji-elon-musk-wylaczyl-lac,nId,7243046](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-wyslala-drony-przeciwko-rosji-elon-musk-wylaczyl-lac,nId,7243046)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T14:02:10+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-wyslala-drony-przeciwko-rosji-elon-musk-wylaczyl-lac,nId,7243046"><img align="left" alt="Ukraina wysłała drony przeciwko Rosji. Elon Musk wyłączył łączność" src="https://i.iplsc.com/ukraina-wyslala-drony-przeciwko-rosji-elon-musk-wylaczyl-lac/000IBDV0DLY04JEF-C321.jpg" /></a>Pierwszy atak dronami morskimi przeprowadzony przez Ukrainę został udaremniony przez Elona Muska. Ukraińcy chcieli uderzyć w okręty w Zatoce Sewastopolskiej u wybrzeży Krymu, jednak niedaleko od celu drony straciły połączenie z systemem Starlink dostarczanym przez kontrowersyjnego miliardera.</p><br clear="all" />

## Władimir Putin zapowiada zemstę. "Wszystko się we mnie gotuje"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wladimir-putin-zapowiada-zemste-wszystko-sie-we-mnie-gotuje,nId,7243037](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wladimir-putin-zapowiada-zemste-wszystko-sie-we-mnie-gotuje,nId,7243037)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T13:50:52+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wladimir-putin-zapowiada-zemste-wszystko-sie-we-mnie-gotuje,nId,7243037"><img align="left" alt="Władimir Putin zapowiada zemstę. &quot;Wszystko się we mnie gotuje&quot;" src="https://i.iplsc.com/wladimir-putin-zapowiada-zemste-wszystko-sie-we-mnie-gotuje/000IBDRU0JPXNF6M-C321.jpg" /></a>- Będziemy intensyfikować ataki - powiedział Władimir Putin, zapowiadając zemstę za eksplozje w Biełgorodzie. Zaznaczył jednak, że Rosja ma atakować cele wojskowe, nie cywilne. Dodał też, że &quot;wszystko się w nim gotuje&quot;.</p><br clear="all" />

## Wyjątkowe narodziny. Bliźniaczki dzieli "rok"
 - [https://wydarzenia.interia.pl/ciekawostki/news-wyjatkowe-narodziny-blizniaczki-dzieli-rok,nId,7243032](https://wydarzenia.interia.pl/ciekawostki/news-wyjatkowe-narodziny-blizniaczki-dzieli-rok,nId,7243032)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T13:45:09+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-wyjatkowe-narodziny-blizniaczki-dzieli-rok,nId,7243032"><img align="left" alt="Wyjątkowe narodziny. Bliźniaczki dzieli &quot;rok&quot;" src="https://i.iplsc.com/wyjatkowe-narodziny-blizniaczki-dzieli-rok/000IBDPYUEESUW1D-C321.jpg" /></a>W Chorwacji na świat przyszły bliźniaczki. Choć urodziły się tej samej nocy, dzieli je rok. Jedna z sióstr jest pierwszym urodzonym w tym kraju w 2024 roku dzieckiem. Druga przyszła na świat jeszcze w ubiegłym 2023 roku. - Nigdy czegoś takiego nie przeżyłem - skomentował niecodzienną sytuację jeden z lekarzy.</p><br clear="all" />

## Książe Chrystian będzie nowym następcą tronu Danii. Zostanie milionerem
 - [https://wydarzenia.interia.pl/zagranica/news-ksiaze-chrystian-bedzie-nowym-nastepca-tronu-danii-zostanie-,nId,7243033](https://wydarzenia.interia.pl/zagranica/news-ksiaze-chrystian-bedzie-nowym-nastepca-tronu-danii-zostanie-,nId,7243033)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T13:29:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ksiaze-chrystian-bedzie-nowym-nastepca-tronu-danii-zostanie-,nId,7243033"><img align="left" alt="Książe Chrystian będzie nowym następcą tronu Danii. Zostanie milionerem" src="https://i.iplsc.com/ksiaze-chrystian-bedzie-nowym-nastepca-tronu-danii-zostanie/000IBDOLEOBHH0KT-C321.jpg" /></a>Skończył osiemnaście lat i wkrótce może zostać milionerem. Z powodu decyzji królowej Małgorzaty II z Danii, która w sylwestra ogłosiła abdykację, jej wnuk książę Chrystian zostanie oficjalnym następcą tronu. Pozycja ta łączy się z otrzymywaniem sporych dochodów z budżetu Danii.</p><br clear="all" />

## Rośnie zagrożenie na Morzu Czerwonym. Stanowcza odpowiedź Londynu
 - [https://wydarzenia.interia.pl/zagranica/news-rosnie-zagrozenie-na-morzu-czerwonym-stanowcza-odpowiedz-lon,nId,7243022](https://wydarzenia.interia.pl/zagranica/news-rosnie-zagrozenie-na-morzu-czerwonym-stanowcza-odpowiedz-lon,nId,7243022)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T12:46:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosnie-zagrozenie-na-morzu-czerwonym-stanowcza-odpowiedz-lon,nId,7243022"><img align="left" alt="Rośnie zagrożenie na Morzu Czerwonym. Stanowcza odpowiedź Londynu" src="https://i.iplsc.com/rosnie-zagrozenie-na-morzu-czerwonym-stanowcza-odpowiedz-lon/000IBDLULD5NRWCY-C321.jpg" /></a>Minister obrony Wielkiej Brytanii Grant Shapps powiedział, że siły brytyjskie są gotowe do działania przeciwko rebeliantom Huti, którzy atakują statki towarowe na Morzu Czerwonym. Polityk podkreślił, że Londyn &quot;jest gotowy do podjęcia bezpośrednich działań w celu ochrony szlaku żeglugowego&quot;. - Huti nie powinno mieć złudzeń. Jesteśmy zobowiązani do pociągnięcia do odpowiedzialności za bezprawne przejęcia i ataki - powiedział szef brytyjskiego resortu obrony.</p><br clear="all" />

## Skandaliczny "żart" Jana Pietrzaka. Mówił o "barakach dla imigrantów"
 - [https://wydarzenia.interia.pl/kraj/news-skandaliczny-zart-jana-pietrzaka-mowil-o-barakach-dla-imigra,nId,7243021](https://wydarzenia.interia.pl/kraj/news-skandaliczny-zart-jana-pietrzaka-mowil-o-barakach-dla-imigra,nId,7243021)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T12:04:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-skandaliczny-zart-jana-pietrzaka-mowil-o-barakach-dla-imigra,nId,7243021"><img align="left" alt="Skandaliczny &quot;żart&quot; Jana Pietrzaka. Mówił o &quot;barakach dla imigrantów&quot;" src="https://i.iplsc.com/skandaliczny-zart-jana-pietrzaka-mowil-o-barakach-dla-imigra/000IBDH4RCCSW657-C321.jpg" /></a>Jan Pietrzak na antenie Republiki powiedział - jak sam to określił - &quot;okrutny żart&quot;. - Mamy baraki dla imigrantów - stwierdził, wskazując na byłe, niemieckie obozy koncentracyjne w Polsce. Prowadząca program Katarzyna Gójska oceniła, że ktoś kto ma osobiste, tragiczne doświadczenia związane z wojną, &quot;może sobie pozwolić na więcej&quot;. Ośrodek Monitorowania Zachowań Rasistowskich przekazał, że zawiadomi w tej sprawie prokuraturę.</p><br clear="all" />

## Specjalne zadanie człowieka Putina. Pojawił się w Ukrainie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-specjalne-zadanie-czlowieka-putina-pojawil-sie-w-ukrainie,nId,7243008](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-specjalne-zadanie-czlowieka-putina-pojawil-sie-w-ukrainie,nId,7243008)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T11:29:06+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-specjalne-zadanie-czlowieka-putina-pojawil-sie-w-ukrainie,nId,7243008"><img align="left" alt="Specjalne zadanie człowieka Putina. Pojawił się w Ukrainie" src="https://i.iplsc.com/specjalne-zadanie-czlowieka-putina-pojawil-sie-w-ukrainie/000IBDEI16RDKR6H-C321.jpg" /></a>Kreml mianował Siergieja Kirijenkę na stanowisko &quot;kuratora przestrzeni informacyjnej na terytoriach okupowanych&quot;. W kontrolowanej części obwodu zaporoskiego Moskwa planuje stworzyć koncern medialny &quot;Nowe Regiony&quot;. Dotychczas Kirijenko pełnił funkcję pierwszego zastępcy szefa administracji Władimira Putina.</p><br clear="all" />

## Strażacy podsumowali sylwestrową noc. Mniej pożarów niż rok temu
 - [https://wydarzenia.interia.pl/kraj/news-strazacy-podsumowali-sylwestrowa-noc-mniej-pozarow-niz-rok-t,nId,7242997](https://wydarzenia.interia.pl/kraj/news-strazacy-podsumowali-sylwestrowa-noc-mniej-pozarow-niz-rok-t,nId,7242997)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T10:55:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-strazacy-podsumowali-sylwestrowa-noc-mniej-pozarow-niz-rok-t,nId,7242997"><img align="left" alt="Strażacy podsumowali sylwestrową noc. Mniej pożarów niż rok temu" src="https://i.iplsc.com/strazacy-podsumowali-sylwestrowa-noc-mniej-pozarow-niz-rok-t/000IBD9XWR6KD5NU-C321.jpg" /></a>W sylwestrową noc straż pożarna wyjeżdżała do blisko 600 pożarów - poinformował Interię rzecznik PSP st. bryg. Karol Kierzkowski. Paliły się pozostałości po fajerwerkach, śmietniki, płoty, a także rośliny. Strażacy nie otrzymali informacji o osobach, które odniosły obrażenia przy odpalaniu petard. - Odnotowaliśmy o 300 mniej interwencji niż w ubiegłym roku. To dobry prognostyk na przyszłość - podkreślił Kierzkowski.</p><br clear="all" />

## Politycy wspominają Śledzińską-Katarasińską. "Koniec pewnej epoki"
 - [https://wydarzenia.interia.pl/kraj/news-politycy-wspominaja-sledzinska-katarasinska-koniec-pewnej-ep,nId,7242994](https://wydarzenia.interia.pl/kraj/news-politycy-wspominaja-sledzinska-katarasinska-koniec-pewnej-ep,nId,7242994)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T09:44:29+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-politycy-wspominaja-sledzinska-katarasinska-koniec-pewnej-ep,nId,7242994"><img align="left" alt="Politycy wspominają Śledzińską-Katarasińską. &quot;Koniec pewnej epoki&quot;" src="https://i.iplsc.com/politycy-wspominaja-sledzinska-katarasinska-koniec-pewnej-ep/000IBD69HGX9IUP2-C321.jpg" /></a>Politycy żegnają Iwonę Śledzińską-Katarasińską. Była posłanka zasiadała w Sejmie przez ponad 30 lat. To &quot;koniec pewnej epoki&quot; - podkreśliła Katarzyna Lubnauer. Politycy Koalicji Obywatelskiej wspominają jej patriotyzm, energię i kompetencje. Premier Donald Tusk podkreślił, że była jego przyjaciółką, &quot;mądrą i bardzo dzielną posłanką&quot;. O śmierci byłej parlamentarzystki napisał również Jacek Sasin.</p><br clear="all" />

## Pożar w sylwestrową noc. Zginęła 69-latka
 - [https://wydarzenia.interia.pl/lodzkie/news-pozar-w-sylwestrowa-noc-zginela-69-latka,nId,7243000](https://wydarzenia.interia.pl/lodzkie/news-pozar-w-sylwestrowa-noc-zginela-69-latka,nId,7243000)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T09:42:03+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-pozar-w-sylwestrowa-noc-zginela-69-latka,nId,7243000"><img align="left" alt="Pożar w sylwestrową noc. Zginęła 69-latka" src="https://i.iplsc.com/pozar-w-sylwestrowa-noc-zginela-69-latka/000IBD7DYF7Q6MK1-C321.jpg" /></a>W pożarze domu jednorodzinnego zginęła 69-letnia kobieta. Do tragedii doszło w nocy z niedzieli na poniedziałek. Z płonącego budynku udało się wydostać 90-latce.

</p><br clear="all" />

## Iwona Śledzińska-Katarasińska nie żyje. Była posłanka miała 82 lata
 - [https://wydarzenia.interia.pl/kraj/news-iwona-sledzinska-katarasinska-nie-zyje-byla-poslanka-miala-8,nId,7242979](https://wydarzenia.interia.pl/kraj/news-iwona-sledzinska-katarasinska-nie-zyje-byla-poslanka-miala-8,nId,7242979)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T08:33:03+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-iwona-sledzinska-katarasinska-nie-zyje-byla-poslanka-miala-8,nId,7242979"><img align="left" alt="Iwona Śledzińska-Katarasińska nie żyje. Była posłanka miała 82 lata" src="https://i.iplsc.com/iwona-sledzinska-katarasinska-nie-zyje-byla-poslanka-miala-8/000IBD2Q80BN9E92-C321.jpg" /></a>&quot;Iwona Śledzińska-Katarasińska zmarła dziś rano po walce z ciężką chorobą&quot; - przekazała w poniedziałek marszałek Senatu Małgorzata Kidawa-Błońska. Była posłanka Platformy Obywatelskiej miała 82 lata.</p><br clear="all" />

## Uderzenie prawdziwej zimy. Siarczysty mróz i dużo śniegu
 - [https://wydarzenia.interia.pl/kraj/news-uderzenie-prawdziwej-zimy-siarczysty-mroz-i-duzo-sniegu,nId,7242957](https://wydarzenia.interia.pl/kraj/news-uderzenie-prawdziwej-zimy-siarczysty-mroz-i-duzo-sniegu,nId,7242957)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T08:26:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-uderzenie-prawdziwej-zimy-siarczysty-mroz-i-duzo-sniegu,nId,7242957"><img align="left" alt="Uderzenie prawdziwej zimy. Siarczysty mróz i dużo śniegu" src="https://i.iplsc.com/uderzenie-prawdziwej-zimy-siarczysty-mroz-i-duzo-sniegu/000IBD0O1ACT7GQC-C321.jpg" /></a>Pogoda znów zaskoczy. W styczniu szykuje się powrót prawdziwej zimy. W Nowy Rok zacznie sypać na Podlasiu, Warmii i Mazurach oraz Lubelszczyźnie. W kolejnych dniach opady śniegu będą tak intensywne, że w niektórych miejscach zalegać będzie nawet 30 cm białego puchu. To jednak nie wszystko. Z prognoz wynika, że pojawi się też siarczysty mróz - do nawet minus 20 stopni Celsjusza.</p><br clear="all" />

## Potężne trzęsienie ziemi w Japonii. Fale zalewają ulice miast
 - [https://wydarzenia.interia.pl/zagranica/news-potezne-trzesienie-ziemi-w-japonii-fale-zalewaja-ulice-miast,nId,7242969](https://wydarzenia.interia.pl/zagranica/news-potezne-trzesienie-ziemi-w-japonii-fale-zalewaja-ulice-miast,nId,7242969)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T07:51:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-potezne-trzesienie-ziemi-w-japonii-fale-zalewaja-ulice-miast,nId,7242969"><img align="left" alt="Potężne trzęsienie ziemi w Japonii. Fale zalewają ulice miast" src="https://i.iplsc.com/potezne-trzesienie-ziemi-w-japonii-fale-zalewaja-ulice-miast/000IBD3NR37SB6X9-C321.jpg" /></a>W centralnej części Japonii zarejestrowano trzęsienie ziemi o magnitudzie 7,6. Wydano też ostrzeżenia o tsunami. Fale mogą być wyższe niż pięć metrów. &quot;Natychmiast ewakuuj się. Fale mogą uderzać wielokrotnie&quot; - podano w komunikacie. Ewakuację ogłoszono również na rosyjskim Sachalinie.</p><br clear="all" />

## Potężne trzęsienie ziemi w Japonii. Zbliża się tsunami
 - [https://wydarzenia.interia.pl/zagranica/news-potezne-trzesienie-ziemi-w-japonii-zbliza-sie-tsunami,nId,7242969](https://wydarzenia.interia.pl/zagranica/news-potezne-trzesienie-ziemi-w-japonii-zbliza-sie-tsunami,nId,7242969)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T07:51:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-potezne-trzesienie-ziemi-w-japonii-zbliza-sie-tsunami,nId,7242969"><img align="left" alt="Potężne trzęsienie ziemi w Japonii. Zbliża się tsunami" src="https://i.iplsc.com/potezne-trzesienie-ziemi-w-japonii-zbliza-sie-tsunami/000IBD20MQTW3QG3-C321.jpg" /></a>W centralnej części Japonii zarejestrowano trzęsienie ziemi o magnitudzie 7,6. Wydano też ostrzeżenia o zbliżającym się tsunami. Fale mogą być wyższe niż pięć metrów. &quot;Natychmiast ewakuuj się. Fale mogą uderzać wielokrotnie&quot; - podano w komunikacie.</p><br clear="all" />

## Gorący pocałunek na scenie i gorący czas Argentyny. Milei traci poparcie
 - [https://wydarzenia.interia.pl/zagranica/news-goracy-pocalunek-na-scenie-i-goracy-czas-argentyny-milei-tra,nId,7242960](https://wydarzenia.interia.pl/zagranica/news-goracy-pocalunek-na-scenie-i-goracy-czas-argentyny-milei-tra,nId,7242960)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T07:42:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-goracy-pocalunek-na-scenie-i-goracy-czas-argentyny-milei-tra,nId,7242960"><img align="left" alt="Gorący pocałunek na scenie i gorący czas Argentyny. Milei traci poparcie" src="https://i.iplsc.com/goracy-pocalunek-na-scenie-i-goracy-czas-argentyny-milei-tra/000IBCZE2KNM89L7-C321.jpg" /></a>Prezydent Argentyny zaskoczył widzów podczas koncertu, w trakcie którego namiętnie pocałował aktorkę i swoją dziewczynę na scenie. Zgromadzeni przyjęli to z entuzjazmem, ale Javier Milei zaczyna tracić w sondażach. Mimo niedawnej zmiany władzy, Argentyńczycy wciąż zmagają się ze skutkami kryzysu gospodarczego.</p><br clear="all" />

## Resort edukacji i nauki przestał istnieć. Wraca podział na dwa ministerstwa
 - [https://wydarzenia.interia.pl/kraj/news-resort-edukacji-i-nauki-przestal-istniec-wraca-podzial-na-dw,nId,7242954](https://wydarzenia.interia.pl/kraj/news-resort-edukacji-i-nauki-przestal-istniec-wraca-podzial-na-dw,nId,7242954)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T06:51:46+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-resort-edukacji-i-nauki-przestal-istniec-wraca-podzial-na-dw,nId,7242954"><img align="left" alt="Resort edukacji i nauki przestał istnieć. Wraca podział na dwa ministerstwa" src="https://i.iplsc.com/resort-edukacji-i-nauki-przestal-istniec-wraca-podzial-na-dw/000IBCY1NXOLY2F1-C321.jpg" /></a>Od 1 stycznia powróciło Ministerstwo Nauki i Szkolnictwa Wyższego. Zostało ono wydzielone z dotychczasowego Ministerstwa Edukacji i Nauki, które - zgodnie z przepisami - przestało istnieć. MNiSW kieruje dotychczasowy minister nauki Dariusz Wieczorek.</p><br clear="all" />

## Biden kontra Trump. To będzie brutalny rok w amerykańskiej polityce
 - [https://wydarzenia.interia.pl/zagranica/news-biden-kontra-trump-to-bedzie-brutalny-rok-w-amerykanskiej-po,nId,7240078](https://wydarzenia.interia.pl/zagranica/news-biden-kontra-trump-to-bedzie-brutalny-rok-w-amerykanskiej-po,nId,7240078)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T06:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-biden-kontra-trump-to-bedzie-brutalny-rok-w-amerykanskiej-po,nId,7240078"><img align="left" alt="Biden kontra Trump. To będzie brutalny rok w amerykańskiej polityce" src="https://i.iplsc.com/biden-kontra-trump-to-bedzie-brutalny-rok-w-amerykanskiej-po/000IB8JSP81G6I3X-C321.jpg" /></a>Gdy Joe Biden wygrał wybory prezydenckie w 2020 roku obiecał, że zjednoczy podzieloną Amerykę. Jeszcze mu się to nie udało, a w 2024 swojej obietnicy na pewno nie zrealizuje, bo to będzie czas, gdy podziały w USA już tylko się pogłębią. To będzie rok decydującego starcia, a droga do niego nie będzie przyjemna. Przed nami, niewykluczone, że najbardziej brutalna kampania wyborcza w historii Stanów Zjednoczonych. </p><br clear="all" />

## Rosjanie atakowali Ukrainę w sylwestra. Dron uderzył w wieżowiec
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-atakowali-ukraine-w-sylwestra-dron-uderzyl-w-wiezow,nId,7242950](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-atakowali-ukraine-w-sylwestra-dron-uderzyl-w-wiezow,nId,7242950)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-01-01T05:25:58+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-atakowali-ukraine-w-sylwestra-dron-uderzyl-w-wiezow,nId,7242950"><img align="left" alt="Rosjanie atakowali Ukrainę w sylwestra. Dron uderzył w wieżowiec" src="https://i.iplsc.com/rosjanie-atakowali-ukraine-w-sylwestra-dron-uderzyl-w-wiezow/000IBCWOV2N4MT9R-C321.jpg" /></a>W sylwestrową noc alarmy przeciwlotnicze ogłoszono w kilkunastu ukraińskich obwodach - w tym także w Kijowie. Rosjanie atakowali przy użyciu dronów kamikadze. W Odessie bezzałogowiec spadł na wieżowiec, zginęła jedna osoba. Eksplozje było także słychać w obwodach mikołajowskim i dniepropetrowskim. We Lwowie mieszkańcy ukryli się w schronach.</p><br clear="all" />

