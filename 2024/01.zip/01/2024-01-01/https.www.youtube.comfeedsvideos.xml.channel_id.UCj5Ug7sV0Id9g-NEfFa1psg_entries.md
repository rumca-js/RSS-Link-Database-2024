# Source:Tomasz Samołyk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg, language:pl-PL

## Gdzie szukać pokoju, pewności i oparcia w trudnych czasach? [DUŻO MEMÓW]
 - [https://www.youtube.com/watch?v=KeTNFvQF9aU](https://www.youtube.com/watch?v=KeTNFvQF9aU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg
 - date published: 2024-01-01T15:39:53+00:00

#nowyrok #polityka #kosciol 

Zapraszam na nowy odcinek, w którym opowiadam o tym gdzie szukam "pewności" i pokoju w tzw. "trudnych czasach". 

Jeśli chcecie wesprzeć moją pracę to można to zrobić na trzy sposoby:
👉 przez patronite: https://patronite.pl/Samolyk
👉przez przycisk "wesprzyj", który znajduje się tuż pod filmem
👉przez darowiznę wpłacaną na konto Bank Pekao SA 08 1240 2786 1111 0010 1984 8265 tytułem: "darowizna"

Z góry dziękuję za każdy wyraz wsparcia :)

