# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## DeSantis And Haley Both Say They’d Pardon Trump If He’s Convicted: ‘We Got To Move On’
 - [https://www.dailywire.com/news/desantis-and-haley-both-say-theyd-pardon-trump-if-hes-convicted-we-got-to-move-on](https://www.dailywire.com/news/desantis-and-haley-both-say-theyd-pardon-trump-if-hes-convicted-we-got-to-move-on)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-01T18:31:05+00:00

Both Governor Ron DeSantis (R-FL) and former Governor Nikki Haley (R-SC) said in the last week that they would pardon former President Donald Trump if he were to be convicted on any of the charges he&#8217;s facing across multiple jurisdictions. According to a report published on Sunday by The Washington Post, both DeSantis and Haley ...

## Critics Slammed Trump After Melania Missed Christmas Photo — He Just Confirmed The Reason Why
 - [https://www.dailywire.com/news/critics-slammed-trump-after-melania-missed-christmas-photo-he-just-confirmed-the-reason-why](https://www.dailywire.com/news/critics-slammed-trump-after-melania-missed-christmas-photo-he-just-confirmed-the-reason-why)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-01T16:55:46+00:00

Critics attacked former President Donald Trump when they noticed that former First Lady Melania Trump was missing from the family Christmas photo — but Trump confirmed the reason for her absence during his New Year&#8217;s Eve celebration at Mar-a-Lago. Taking the microphone and addressing party-goers, Trump announced that he had just gotten off the phone ...

## Rocker Changes Lyrics To Take Shot At Trump Supporters During New Year’s Eve Performance On ABC
 - [https://www.dailywire.com/news/rocker-changes-lyrics-to-take-shot-at-trump-supporters-during-new-years-eve-performance-on-abc](https://www.dailywire.com/news/rocker-changes-lyrics-to-take-shot-at-trump-supporters-during-new-years-eve-performance-on-abc)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-01T15:16:43+00:00

Green Day lead singer Billie Joe Armstrong, a vehement Donald Trump critic, changed the lyrics to one of the band’s most popular songs to take a shot at the former president and his supporters during a New Year’s Eve performance.  While performing the band’s 2004 hit song “American Idiot” Sunday night in Hollywood, Armstrong sang, ...

## Illegal Immigrants Take Trains Into NYC After Eric Adams Restricts Bus Arrivals
 - [https://www.dailywire.com/news/illegal-immigrants-take-trains-into-nyc-after-eric-adams-restricts-bus-arrivals](https://www.dailywire.com/news/illegal-immigrants-take-trains-into-nyc-after-eric-adams-restricts-bus-arrivals)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-01T13:02:37+00:00

Illegal immigrants bound for New York City are now taking trains into the Big Apple after Democratic Mayor Eric Adams issued an executive order last week seeking to curb the busloads of migrants that enter the city.  Adams’ executive order limits when migrant buses can come into the city and requires bus drivers who know ...

## ‘The Censorship Is Ramping Up’: Libs Of TikTok Says Account Was Suspended From Facebook
 - [https://www.dailywire.com/news/the-censorship-is-ramping-up-libs-of-tiktok-says-account-was-suspended-from-facebook](https://www.dailywire.com/news/the-censorship-is-ramping-up-libs-of-tiktok-says-account-was-suspended-from-facebook)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-01T11:37:35+00:00

According to Chaya Raichik, owner of the Libs of TikTok accounts on social media, her Facebook page was suspended on Saturday. Raichik posted a screenshot of an email from Facebook reading, “The page Libs of Tik Tok has been suspended for going against our Community Standards. You cannot visit the Page and you won’t be ...

## Japan Hit By 7.6 Magnitude Earthquake, Sparking Tsunami Warnings
 - [https://www.dailywire.com/news/japan-hit-by-7-6-magnitude-earthquake-sparking-tsunami-warnings](https://www.dailywire.com/news/japan-hit-by-7-6-magnitude-earthquake-sparking-tsunami-warnings)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-01T11:34:48+00:00

Residents of Japanese coastal areas were told to evacuate their homes Monday as the country braces for a tsunami after a 7.6 magnitude earthquake shook the country&#8217;s western coast.  More than a dozen earthquakes were reported in the Sea of Japan late Monday night local time, the largest of which collapsed buildings and started a ...

## Bill Clinton’s Name Mentioned Over 50 Times In Redacted Epstein Filings: Report
 - [https://www.dailywire.com/news/bill-clintons-name-mentioned-over-50-times-in-redacted-epstein-filings-report](https://www.dailywire.com/news/bill-clintons-name-mentioned-over-50-times-in-redacted-epstein-filings-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-01T11:23:50+00:00

As scores of previously sealed court filings regarding sex offender Jeffrey Epstein are about to be made public, a report states that former President Bill Clinton is mentioned in more than 50 of the redacted filings. In December, Manhattan federal Judge Loretta Preska ordered the release of sealed documents from a defamation suit Virginia Giuffre ...

## Weekend Media Wrap, Vol. 24: What You Missed If You Weren’t Glued To The Sunday Shows
 - [https://www.dailywire.com/news/weekend-media-wrap-vol-24-what-you-missed-if-you-werent-glued-to-the-sunday-shows](https://www.dailywire.com/news/weekend-media-wrap-vol-24-what-you-missed-if-you-werent-glued-to-the-sunday-shows)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-01T08:15:03+00:00

Every Sunday morning, legacy media outlets are taken over by elected officials, aspiring elected officials, administration insiders, and the usual collection of talking heads — all of whom are there to discuss specific policies, push talking points, or simply promote their own campaigns. For those who don&#8217;t spend their Sunday mornings glued to the television ...

