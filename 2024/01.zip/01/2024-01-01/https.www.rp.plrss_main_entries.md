# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Piotr Zieliński bliski odejścia z Napoli. Czy zagra w Interze Mediolan?
 - [https://www.rp.pl/pilka-nozna/art39643421-piotr-zielinski-bliski-odejscia-z-napoli-czy-zagra-w-interze-mediolan](https://www.rp.pl/pilka-nozna/art39643421-piotr-zielinski-bliski-odejscia-z-napoli-czy-zagra-w-interze-mediolan)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T22:47:00+00:00

Pomocnik reprezentacji Polski może za pół roku opuścić Napoli. Jeśli wierzyć w to, co piszą i mówią włoskie media, osiągnął już porozumienie z Interem.

## Zełenski: Zachód stracił poczucie pilności wojny, a Ukraińcy - poczucie zagrożenia
 - [https://www.rp.pl/konflikty-zbrojne/art39643391-zelenski-zachod-stracil-poczucie-pilnosci-wojny-a-ukraincy-poczucie-zagrozenia](https://www.rp.pl/konflikty-zbrojne/art39643391-zelenski-zachod-stracil-poczucie-pilnosci-wojny-a-ukraincy-poczucie-zagrozenia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T22:20:00+00:00

Putin czuje słabość jak zwierzę, bo jest zwierzęciem. Wyczuwa krew, wyczuwa swoją siłę. I zje was na obiad z całą waszą UE, NATO, wolnością i demokracją - mówił w rozmowie z "The Economist" prezydent Ukrainy Wołodymyr Zełenski.

## Niezbędnik przedsiębiorcy: Składki ZUS * Zdrowotna na ryczałcie * Amortyzacja szybciej, ale pod warunkiem * Mikrorachunek dla nowych podatków * Dotacja przychodem, amortyzacja kosztem * Kłopoty w logistyce i transporcie
 - [https://firma.rp.pl/niezbednik-przedsiebiorcy/art39643401-niezbednik-przedsiebiorcy-skladki-zus-zdrowotna-na-ryczalcie-amortyzacja-szybciej-ale-pod-warunkiem-mikrorachunek-dla-nowych-podatkow-dotacja-przychodem-amortyzacja-kosztem-klopoty-w-logistyce-i-transporcie](https://firma.rp.pl/niezbednik-przedsiebiorcy/art39643401-niezbednik-przedsiebiorcy-skladki-zus-zdrowotna-na-ryczalcie-amortyzacja-szybciej-ale-pod-warunkiem-mikrorachunek-dla-nowych-podatkow-dotacja-przychodem-amortyzacja-kosztem-klopoty-w-logistyce-i-transporcie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T22:05:25+00:00

• Preferencyjne składki ZUS w 2024 r.
• Składka zdrowotna na ryczałcie - sprawdź, czy musisz dopłacać
• Amortyzacja: opłaci się inwestycja w biedniejszej gminie
• Nowe funkcje mikrorachunku podatkowego
• Nowe zasady rozliczenia dotacji dla firmy
• Branża TSL nie ma powodów do radości
• Ważne terminy na ten tydzień i wskaźniki na styczeń

## Kurs euro wystrzelił powyżej 5 złotych? To błąd Google
 - [https://www.rp.pl/waluty/art39643341-kurs-euro-wystrzelil-powyzej-5-zlotych-to-blad-google](https://www.rp.pl/waluty/art39643341-kurs-euro-wystrzelil-powyzej-5-zlotych-to-blad-google)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T21:05:32+00:00

Internauci, którzy sprawdzili dziś wieczorem w wyszukiwarce Google kurs euro i dolara, przeżyli szok – euro miało gwałtownie zdrożeć do ponad 5 zł, a dolar do 4,87 zł. Uspokajamy – to błąd Google.

## Pietrzak się tłumaczy.  "Nikt mi nie zabroni pamiętać. Nie rozumiem tej burzy"
 - [https://www.rp.pl/polityka/art39643231-pietrzak-sie-tlumaczy-nikt-mi-nie-zabroni-pamietac-nie-rozumiem-tej-burzy](https://www.rp.pl/polityka/art39643231-pietrzak-sie-tlumaczy-nikt-mi-nie-zabroni-pamietac-nie-rozumiem-tej-burzy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T21:00:00+00:00

Przeczytałem gdzieś, że są takie plany, że będą obozy dla tych migrantów, których trzeba przysłać do Polski. To był mój stosunek do tej informacji - powiedział Jan Pietrzak w rozmowie z portalem gazeta.pl. Dodał że nie rozumie burzy, jaką wywołały jego słowa.

## Duda oburzony słowami Pietrzaka, a Mastalerek reakcją ministra sprawiedliwości
 - [https://www.rp.pl/polityka/art39643061-duda-oburzony-slowami-pietrzaka-a-mastalerek-reakcja-ministra-sprawiedliwosci](https://www.rp.pl/polityka/art39643061-duda-oburzony-slowami-pietrzaka-a-mastalerek-reakcja-ministra-sprawiedliwosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T19:34:00+00:00

Jeśli minister sprawiedliwości zajmuje się wypowiedzią publicysty i satyryka, to ja się zaczynam zastanawiać, czy chodzi mu o słowa publicysty i satyryka, czy o gigantyczny sukces Telewizji Republika - stwierdził w TV Republika szef gabinetu prezydenta Andrzeja Dudy Marcin Mastalerek.

## Odwet za odwet. Kijów zaczął odpowiadać na rosyjskie ataki na ukraińskie miasta - tym samym
 - [https://www.rp.pl/konflikty-zbrojne/art39642781-odwet-za-odwet-kijow-zaczal-odpowiadac-na-rosyjskie-ataki-na-ukrainskie-miasta-tym-samym](https://www.rp.pl/konflikty-zbrojne/art39642781-odwet-za-odwet-kijow-zaczal-odpowiadac-na-rosyjskie-ataki-na-ukrainskie-miasta-tym-samym)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T19:30:56+00:00

Po piątkowym, ogromnym nalocie rosyjskim Ukraińcy zaatakowali centrum Biełgorodu. W odwecie rosyjska armia w noworoczną noc uderzyła prawie setką dronów na ukraińskie miasta. A prezydent Władimir Putin zapowiedział, że jego wojska będą się mścić. Ukraińska armia natychmiast odpowiedziała na ataki, ostrzeliwując centrum Doniecka. Badania socjologiczne wskazują, że Ukraińcy domagają się rewanżu i ukarania Rosjan.

## Zmarł prokurator Aleksander Herzog. Jeden z najwybitniejszych polskich prokuratorów
 - [https://www.rp.pl/prawnicy/art39643031-zmarl-prokurator-aleksander-herzog-jeden-z-najwybitniejszych-polskich-prokuratorow](https://www.rp.pl/prawnicy/art39643031-zmarl-prokurator-aleksander-herzog-jeden-z-najwybitniejszych-polskich-prokuratorow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T19:21:51+00:00

Media społecznościowe obiegła smutna informacja - 1 stycznia 2024 roku zmarł prokurator Prokuratury Krajowej w stanie spoczynku, Aleksander Herzog.

## Gen. Waldemar Skrzypczak: Wołodymyr Zełenski czuje się coraz bardziej osamotniony
 - [https://www.rp.pl/konflikty-zbrojne/art39643011-gen-waldemar-skrzypczak-wolodymyr-zelenski-czuje-sie-coraz-bardziej-osamotniony](https://www.rp.pl/konflikty-zbrojne/art39643011-gen-waldemar-skrzypczak-wolodymyr-zelenski-czuje-sie-coraz-bardziej-osamotniony)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T19:11:41+00:00

Wołodymyr Zełenski musi zrobić porządek na scenie politycznej w Kijowie, jeżeli chce przetrwać w roli przywódcy - uważa gen. Waldemar Skrzypczak, były dowódca Wojsk Lądowych.

## Sąd Najwyższy w Izraelu odrzucił reformę sądownictwa premiera Netanjahu
 - [https://www.rp.pl/prawo-dla-ciebie/art39643001-sad-najwyzszy-w-izraelu-odrzucil-reforme-sadownictwa-premiera-netanjahu](https://www.rp.pl/prawo-dla-ciebie/art39643001-sad-najwyzszy-w-izraelu-odrzucil-reforme-sadownictwa-premiera-netanjahu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T18:47:00+00:00

Sąd Najwyższy w Izraelu odrzucił reformę wymiaru sądownictwa zapoczątkowaną przez rząd premiera Netanjahu. Działania premiera wywołały wielomiesięczne protesty obywateli, którzy sprzeciwiali się ograniczeniu niezależności Sądu Najwyższego.

## Zdobywca Pokojowej Nagrody Nobla skazany na karę więzienia
 - [https://www.rp.pl/prawo-dla-ciebie/art39642891-zdobywca-pokojowej-nagrody-nobla-skazany-na-kare-wiezienia](https://www.rp.pl/prawo-dla-ciebie/art39642891-zdobywca-pokojowej-nagrody-nobla-skazany-na-kare-wiezienia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T18:11:13+00:00

Sąd Pracy w Bangladeszu skazał Muhammada Yunusa na sześć miesięcy pozbawienia wolności za naruszenie krajowego prawa pracy. Yanus to laureat Pokojowej Nagrody Nobla z 2006 roku za opracowanie i wprowadzenie systemu mikrokredytów.

## 10 lat po Majdanie zbrodnie pozostają bez kary
 - [https://www.rp.pl/polityka/art39639731-10-lat-po-majdanie-zbrodnie-pozostaja-bez-kary](https://www.rp.pl/polityka/art39639731-10-lat-po-majdanie-zbrodnie-pozostaja-bez-kary)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T18:05:00+00:00

Zabójcy protestujących podczas rewolucji sprzed dziesięciu lat nie ponieśli odpowiedzialności. A sprawy umarzane są w ukraińskich sądach z powodu przedawnienia.

## Wiceprezes UODO: Rynek certyfikatów zgodności z RODO wzmocni ochronę danych
 - [https://www.rp.pl/dane-osobowe/art39641501-wiceprezes-uodo-rynek-certyfikatow-zgodnosci-z-rodo-wzmocni-ochrone-danych](https://www.rp.pl/dane-osobowe/art39641501-wiceprezes-uodo-rynek-certyfikatow-zgodnosci-z-rodo-wzmocni-ochrone-danych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T17:25:09+00:00

Certyfikat zgodności procesów przetwarzania danych administratora będzie sygnałem dla jego klientów i partnerów, że właściwie chroni dane. Jednak najpierw musi powstać rynek, który te certyfikaty będzie przyznawał - pisze Jakub Groszkowski, zastępca prezesa UODO.

## United Cup. Iga Świątek wciąż niepokonana w Perth
 - [https://www.rp.pl/tenis/art39642251-united-cup-iga-swiatek-wciaz-niepokonana-w-perth](https://www.rp.pl/tenis/art39642251-united-cup-iga-swiatek-wciaz-niepokonana-w-perth)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T17:19:20+00:00

Reprezentacja Polski wygrała z Hiszpanią 2:1 drugi mecz grupowy turnieju drużyn mieszanych w Australii i awansowała do ćwierćfinału. Iga na razie zagrała cztery mecze, dwa singlowe i dwa w mikście, wszystkie zwycięskie

## 72. TCS. Konkurs w Ga-Pa wygrał Lanisek, ale Wellinger i Kobayashi uciekają
 - [https://www.rp.pl/skoki-narciarskie/art39641671-72-tcs-konkurs-w-ga-pa-wygral-lanisek-ale-wellinger-i-kobayashi-uciekaja](https://www.rp.pl/skoki-narciarskie/art39641671-72-tcs-konkurs-w-ga-pa-wygral-lanisek-ale-wellinger-i-kobayashi-uciekaja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T16:30:00+00:00

Powitanie 2024 roku na Skoczni Olimpijskiej w Ga-Pa najlepiej udało się Anze Laniskowi. Słoweniec wygrał konkurs, przed Ryoyu Kobayashim i Andreasem Wellingerem, który pozostał liderem turnieju. Trzej Polacy – w trzeciej dziesiątce.

## Muzeum Auschwitz reaguje na skandaliczne słowa Jana Pietrzaka
 - [https://www.rp.pl/polityka/art39641651-muzeum-auschwitz-reaguje-na-skandaliczne-slowa-jana-pietrzaka](https://www.rp.pl/polityka/art39641651-muzeum-auschwitz-reaguje-na-skandaliczne-slowa-jana-pietrzaka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T16:19:00+00:00

Na karygodną wypowiedź na temat imigrantów autorstwa satyryka Jana Pietrzaka w TV Republika zareagowało Muzeum Auschwitz. Pisze o "nikczemnej retoryce antymigracyjnej".

## Carlo Ancelotti zostaje w Realu. Dlaczego nie poprowadzi reprezentacji Brazylii?
 - [https://www.rp.pl/pilka-nozna/art39641491-carlo-ancelotti-zostaje-w-realu-dlaczego-nie-poprowadzi-reprezentacji-brazylii](https://www.rp.pl/pilka-nozna/art39641491-carlo-ancelotti-zostaje-w-realu-dlaczego-nie-poprowadzi-reprezentacji-brazylii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T15:49:23+00:00

Włoski trener przedłużył kontrakt z Królewskimi do czerwca 2026 roku, choć latem miał objąć stanowisko selekcjonera Canarinhos.

## Jakie zmiany w prawie w 2024 r.? Wyższe wynagrodzenia i zakaz sprzedaży energetyków
 - [https://www.rp.pl/prawo-dla-ciebie/art39641341-jakie-zmiany-w-prawie-w-2024-r-wyzsze-wynagrodzenia-i-zakaz-sprzedazy-energetykow](https://www.rp.pl/prawo-dla-ciebie/art39641341-jakie-zmiany-w-prawie-w-2024-r-wyzsze-wynagrodzenia-i-zakaz-sprzedazy-energetykow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T15:47:00+00:00

Nowy Rok to nie tylko czas odpoczynku po sylwestrowej zabawie, to także dzień kiedy w życie wchodzi wiele przepisów i zmian w prawie. Warto zapoznać się z prawnymi nowościami przed rozpoczęciem 2024 roku na dobre.

## "Okrutny żart" Jana Pietrzaka o migrantach. Reaguje minister sprawiedliwości
 - [https://www.rp.pl/polityka/art39641441-okrutny-zart-jana-pietrzaka-o-migrantach-reaguje-minister-sprawiedliwosci](https://www.rp.pl/polityka/art39641441-okrutny-zart-jana-pietrzaka-o-migrantach-reaguje-minister-sprawiedliwosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T14:35:00+00:00

Satyryk Jan Pietrzak wywołał burzę wypowiedzią w TV Republika. Uważa, że miejsce dla imigrantów, których do Polski "wpychają Niemcy", jest w barakach po byłych obozach koncentracyjnych. Sprawą zajmie się prokurator.

## Od 1 stycznia w Estonii można zawierać małżeństwa jednopłciowe
 - [https://www.rp.pl/spoleczenstwo/art39641401-od-1-stycznia-w-estonii-mozna-zawierac-malzenstwa-jednoplciowe](https://www.rp.pl/spoleczenstwo/art39641401-od-1-stycznia-w-estonii-mozna-zawierac-malzenstwa-jednoplciowe)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T13:53:03+00:00

Pary jednopłciowe mogą od 1 stycznia w Estonii zawierać małżeństwa - przypomina "The Guardian".

## Mniej pieniędzy dla przedsiębiorców za terminowe płacenie pracowniczych podatków
 - [https://www.rp.pl/podatki/art39635521-mniej-pieniedzy-dla-przedsiebiorcow-za-terminowe-placenie-pracowniczych-podatkow](https://www.rp.pl/podatki/art39635521-mniej-pieniedzy-dla-przedsiebiorcow-za-terminowe-placenie-pracowniczych-podatkow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T13:45:00+00:00

Pracodawcy, który w terminie odprowadza pracownicze podatki, przysługuje wynagrodzenie. Jego stawka właśnie spadła o połowę.

## Od jutra zmiany w zasadach egzaminów na prawo jazdy
 - [https://moto.rp.pl/tu-i-teraz/art39641381-od-jutra-zmiany-w-zasadach-egzaminow-na-prawo-jazdy](https://moto.rp.pl/tu-i-teraz/art39641381-od-jutra-zmiany-w-zasadach-egzaminow-na-prawo-jazdy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T13:26:00+00:00

Od nowego roku wejdą w życie nowe zasady egzaminów na prawo jazdy. Zmiany dotyczą zarówno kandydatów na przyszłych kierowców pojazdów osobowych, jak też motocyklistów. Przewidywane są również podwyżki cen.

## Sylwester w Holandii: Ataki na policję, aresztowano co najmniej 200 osób
 - [https://www.rp.pl/przestepczosc/art39641331-sylwester-w-holandii-ataki-na-policje-aresztowano-co-najmniej-200-osob](https://www.rp.pl/przestepczosc/art39641331-sylwester-w-holandii-ataki-na-policje-aresztowano-co-najmniej-200-osob)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T13:12:10+00:00

Holenderska policja aresztowała co najmniej 200 osób w nocy z 31 grudnia na 1 stycznia. Kilku policjantów zostało rannych - głównie przez petardy - głosi komunikat holenderskiej policji.

## Kawa lub jedzenie na wynos? Klient ma zapłacić za opakowanie
 - [https://www.rp.pl/konsumenci/art39641101-kawa-lub-jedzenie-na-wynos-klient-ma-zaplacic-za-opakowanie](https://www.rp.pl/konsumenci/art39641101-kawa-lub-jedzenie-na-wynos-klient-ma-zaplacic-za-opakowanie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T12:38:52+00:00

Obowiązujące od poniedziałku regulacje to kolejny sposób na ograniczenie zużycia plastikowych jednorazówek.

## Władimir Putin wskazuje wroga Rosji. To nie Ukraina
 - [https://www.rp.pl/konflikty-zbrojne/art39641301-wladimir-putin-wskazuje-wroga-rosji-to-nie-ukraina](https://www.rp.pl/konflikty-zbrojne/art39641301-wladimir-putin-wskazuje-wroga-rosji-to-nie-ukraina)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T12:29:00+00:00

- Sama Ukraina nie jest wrogiem Rosji - mówił prezydent Rosji, Władimir Putin, w czasie spotkania z rannymi w walkach na Ukrainie rosyjskimi żołnierzami.

## Agnieszka Holland w TVP1. Powrót „Hali odlotów” 1 stycznia
 - [https://www.rp.pl/telewizja/art39641241-agnieszka-holland-w-tvp1-powrot-hali-odlotow-1-stycznia](https://www.rp.pl/telewizja/art39641241-agnieszka-holland-w-tvp1-powrot-hali-odlotow-1-stycznia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T12:08:12+00:00

W specjalnym wydaniu „Hali odlotów” zobaczymy Agnieszkę Holland, reżyserkę „Zielonej granicy”, Maję Kleczewską, reżyserkę głośnych „Dziadów”, Daniela Rycharskiego, Andrzeja Seweryna i dyrektora Piotra Bernatowicza. Program poprowadzi Katarzyna Janowska.

## Prezydent Chin Xi Jinping przyznaje: Nasza gospodarka ma trudności
 - [https://www.rp.pl/gospodarka/art39641211-prezydent-chin-xi-jinping-przyznaje-nasza-gospodarka-ma-trudnosci](https://www.rp.pl/gospodarka/art39641211-prezydent-chin-xi-jinping-przyznaje-nasza-gospodarka-ma-trudnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T12:05:00+00:00

Nie pomaga tania energia z Rosji ani jedna z najtańszych na świecie sił roboczych. Prezydent Xi Jinping przyznał, że chińskie przedsiębiorstwa borykają się z trudnościami.

## Po raz dziewiąty w historii funkcję prezydenta Szwajcarii pełni kobieta
 - [https://www.rp.pl/polityka/art39641261-po-raz-dziewiaty-w-historii-funkcje-prezydenta-szwajcarii-pelni-kobieta](https://www.rp.pl/polityka/art39641261-po-raz-dziewiaty-w-historii-funkcje-prezydenta-szwajcarii-pelni-kobieta)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T11:53:56+00:00

Viola Amherd, pierwsza w historii Szwajcarii kobieta, która stała na czele resortu obrony, przez najbliższy rok będzie pełnić rolę prezydenta Szwajcarii.

## Miniaturowe roboty z ludzkich komórek naprawią ciało i wyleczą choroby. To przełom
 - [https://cyfrowa.rp.pl/technologie/art39641181-miniaturowe-roboty-z-ludzkich-komorek-naprawia-cialo-i-wylecza-choroby-to-przelom](https://cyfrowa.rp.pl/technologie/art39641181-miniaturowe-roboty-z-ludzkich-komorek-naprawia-cialo-i-wylecza-choroby-to-przelom)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T11:06:00+00:00

Bioboty, nie większe od główki zaostrzonego ołówka, mają wypełnić niszę pomiędzy nanotechnologią a tradycyjnymi urządzeniami medycznymi. Na razie kojarzą się z filmami fantastyczno-naukowymi. Jednak naukowcy mogą to szybko zmienić.

## Były dowódca wojsk USA w Europie: NATO byłoby lepsze z Ukrainą
 - [https://www.rp.pl/dyplomacja/art39641201-byly-dowodca-wojsk-usa-w-europie-nato-byloby-lepsze-z-ukraina](https://www.rp.pl/dyplomacja/art39641201-byly-dowodca-wojsk-usa-w-europie-nato-byloby-lepsze-z-ukraina)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T11:05:17+00:00

Gen. Ben Hodges, były dowódca wojsk USA w Europie, w rozmowie z agencją Ukrinform mówił o tym czy możliwe jest, iż Ukraina zostanie oficjalnie zaproszona do Sojuszu na szczycie NATO w Waszyngtonie (lipiec 2024 roku).

## Zmiany w rozliczaniu nadgodzin urzędników od 2024 r.: albo wolne albo wynagrodzenie
 - [https://www.rp.pl/urzednicy/art39637701-zmiany-w-rozliczaniu-nadgodzin-urzednikow-od-2024-r-albo-wolne-albo-wynagrodzenie](https://www.rp.pl/urzednicy/art39637701-zmiany-w-rozliczaniu-nadgodzin-urzednikow-od-2024-r-albo-wolne-albo-wynagrodzenie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T10:36:00+00:00

Od 1 stycznia 2024 r. członkowie korpusu służby cywilnej będą mieli rekompensowaną pracę w godzinach nadliczbowych.

## Lotniskowiec USA wraca do bazy. "NYT": Napięte relacje USA-Izrael
 - [https://www.rp.pl/konflikty-zbrojne/art39641141-lotniskowiec-usa-wraca-do-bazy-nyt-napiete-relacje-usa-izrael](https://www.rp.pl/konflikty-zbrojne/art39641141-lotniskowiec-usa-wraca-do-bazy-nyt-napiete-relacje-usa-izrael)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T10:32:18+00:00

Grupa uderzeniowa lotniskowca USA USS Gerald Ford wraca do bazy w Norfolk, w Wirginii, po tym jak wcześniej ten największy amerykański lotniskowiec został wysłany w rejon wschodniego Morza Śródziemnego.

## Zmiana w PIT: inwestor samodzielnie rozliczy zyski z funduszy kapitałowych
 - [https://www.rp.pl/podatki/art39634871-zmiana-w-pit-inwestor-samodzielnie-rozliczy-zyski-z-funduszy-kapitalowych](https://www.rp.pl/podatki/art39634871-zmiana-w-pit-inwestor-samodzielnie-rozliczy-zyski-z-funduszy-kapitalowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T10:30:00+00:00

Można kompensować dochody i straty z inwestycji. Ale fundusze już nas nie wyręczą przy rozliczaniu podatku.

## 18 izraelskich żołnierzy zastrzelili w Strefie Gazy izraelscy żołnierze
 - [https://www.rp.pl/konflikty-zbrojne/art39641111-18-izraelskich-zolnierzy-zastrzelili-w-strefie-gazy-izraelscy-zolnierze](https://www.rp.pl/konflikty-zbrojne/art39641111-18-izraelskich-zolnierzy-zastrzelili-w-strefie-gazy-izraelscy-zolnierze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T09:45:48+00:00

Izraelskie Siły Obronne podały w poniedziałek, że ok. 17 proc. żołnierzy, którzy zginęli w czasie walk, do jakich doszło w Strefie Gazy po 7 października, to żołnierze, którzy zginęli wskutek wypadków, m.in. ofiary innych izraelskich żołnierzy.

## Amerykanin Joshua Bell zagra w Warszawie dla Ukrainy
 - [https://www.rp.pl/muzyka-klasyczna/art39641051-amerykanin-joshua-bell-zagra-w-warszawie-dla-ukrainy](https://www.rp.pl/muzyka-klasyczna/art39641051-amerykanin-joshua-bell-zagra-w-warszawie-dla-ukrainy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T09:03:53+00:00

Skrzypek Joshua Bell i właściciel legendarnego Stradivariusa, kupionego za 4 mln dolarów, wystąpi w Filharmonii Narodowej 10 stycznia z orkiestrą ze Lwowa na koncercie charytatywnym dla Ukrainy.

## Nie żyje Iwona Śledzińska-Katarasińska, była posłanka PO
 - [https://www.rp.pl/polityka/art39641081-nie-zyje-iwona-sledzinska-katarasinska-byla-poslanka-po](https://www.rp.pl/polityka/art39641081-nie-zyje-iwona-sledzinska-katarasinska-byla-poslanka-po)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T08:27:00+00:00

Rankiem 1 stycznia zmarła Iwona Śledzińska-Katarasińska - poinformowała marszałek Senatu, Małgorzata Kidawa-Błońska.

## Wyższe wynagrodzenia dla pracowników to wyższe składki dla przedsiębiorców
 - [https://www.rp.pl/zus/art39635611-wyzsze-wynagrodzenia-dla-pracownikow-to-wyzsze-skladki-dla-przedsiebiorcow](https://www.rp.pl/zus/art39635611-wyzsze-wynagrodzenia-dla-pracownikow-to-wyzsze-skladki-dla-przedsiebiorcow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T08:07:00+00:00

Od poniedziałku 1 stycznia wynagrodzenie minimalne wynosi 4242 zł, a przedsiębiorcy niekorzystający z żadnych preferencji zapłacą 1600,32 zł z tytułu składek.

## Silne trzęsienie ziemi w Japonii. Ostrzeżenie przed tsunami
 - [https://www.rp.pl/kleski-zywiolowe/art39641041-silne-trzesienie-ziemi-w-japonii-ostrzezenie-przed-tsunami](https://www.rp.pl/kleski-zywiolowe/art39641041-silne-trzesienie-ziemi-w-japonii-ostrzezenie-przed-tsunami)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T07:58:52+00:00

Trzęsienie ziemi o magnitudzie 7,4 nawiedziło północną Japonię - informuje japoński nadawca publiczny, NHK.

## Senator z USA o napływie imigrantów: Stany Zjednoczone są pełne
 - [https://www.rp.pl/polityka/art39641021-senator-z-usa-o-naplywie-imigrantow-stany-zjednoczone-sa-pelne](https://www.rp.pl/polityka/art39641021-senator-z-usa-o-naplywie-imigrantow-stany-zjednoczone-sa-pelne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T07:47:39+00:00

Lindsey Graham, amerykański senator z Partii Republikańskiej, w rozmowie z CBS News przekonywał, że Stany Zjednoczone są "pełne" i że nie ma już w nich miejsca dla imigrantów.

## Mark Bryan – inżynier robotyki, od którego kobiety mogą się uczyć... chodzenia w szpilkach
 - [https://kobieta.rp.pl/ludzie/art39630271-mark-bryan-inzynier-robotyki-od-ktorego-kobiety-moga-sie-uczyc-chodzenia-w-szpilkach](https://kobieta.rp.pl/ludzie/art39630271-mark-bryan-inzynier-robotyki-od-ktorego-kobiety-moga-sie-uczyc-chodzenia-w-szpilkach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T07:00:00+00:00

Kiedy zobaczysz mężczyznę w marynarce, koszuli i krawacie, wysiadającego ze swojego Porshe w… spódnicy i szpilkach od Louboutine’a, nie zdziw się. To Mark Bryan, mąż i ojciec trojga dzieci, człowiek udowadniający, że ubrania i buty nie są przypisane do orientacji seksualnej ani płci.

## Wielka Brytania będzie atakować cele w Jemenie?
 - [https://www.rp.pl/konflikty-zbrojne/art39641001-wielka-brytania-bedzie-atakowac-cele-w-jemenie](https://www.rp.pl/konflikty-zbrojne/art39641001-wielka-brytania-bedzie-atakowac-cele-w-jemenie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T06:44:09+00:00

Wielka Brytania rozważa ataki powietrzne na rebeliantów Huti, biorących udział w wojnie domowej w Jemenie - wynika z artykułu opublikowanego przez ministra obrony Wielkiej Brytanii, Granta Shappsa, na łamach "Daily Telegraph".

## Strefa Gazy: Izrael przegrupowuje siły i zapowiada "walkę przez cały 2024 r."
 - [https://www.rp.pl/konflikty-zbrojne/art39640971-strefa-gazy-izrael-przegrupowuje-sily-i-zapowiada-walke-przez-caly-2024-r](https://www.rp.pl/konflikty-zbrojne/art39640971-strefa-gazy-izrael-przegrupowuje-sily-i-zapowiada-walke-przez-caly-2024-r)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T06:06:40+00:00

Rzecznik izraelskiej armii, adm. Daniel Hagari oświadczył, że izraelska armia planuje swoje działania zakładając, że walki w Strefie Gazy będą trwać przez cały 2024 rok.

## Strefa Gazy: Izraelska przegrupowuje siły i zapowiada "walkę przez cały 2024 r."
 - [https://www.rp.pl/konflikty-zbrojne/art39640971-strefa-gazy-izraelska-przegrupowuje-sily-i-zapowiada-walke-przez-caly-2024-r](https://www.rp.pl/konflikty-zbrojne/art39640971-strefa-gazy-izraelska-przegrupowuje-sily-i-zapowiada-walke-przez-caly-2024-r)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T06:06:40+00:00

Rzecznik izraelskiej armii, adm. Daniel Hagari oświadczył, że izraelska armia planuje swoje działania zakładając, że walki w Strefie Gazy będą trwać przez cały 2024 rok.

## Sondaż: Jakie postanowienia noworoczne podejmują Polacy? "Więcej się ruszać, schudnąć"
 - [https://www.rp.pl/spoleczenstwo/art39640951-sondaz-jakie-postanowienia-noworoczne-podejmuja-polacy-wiecej-sie-ruszac-schudnac](https://www.rp.pl/spoleczenstwo/art39640951-sondaz-jakie-postanowienia-noworoczne-podejmuja-polacy-wiecej-sie-ruszac-schudnac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T05:28:04+00:00

Z sondażu przeprowadzonego przez RMF FM wynika, że 24 proc. Polaków będzie próbowało realizować w 2024 roku postanowienia noworoczne.

## Tobias Torgensen znów buduje polski biatlon. "Wprowadził więcej spokoju"
 - [https://www.rp.pl/sporty-zimowe/art39638481-tobias-torgensen-znow-buduje-polski-biatlon-wprowadzil-wiecej-spokoju](https://www.rp.pl/sporty-zimowe/art39638481-tobias-torgensen-znow-buduje-polski-biatlon-wprowadzil-wiecej-spokoju)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T05:07:11+00:00

Joanna Jakieła sezon rozpoczęła od mocnego uderzenia, bo 11. miejsce w biegu indywidualnym było jej życiowym sukcesem. To wynik, za którym stoi Tobias Torgensen. Norweg wrócił w tym roku do pracy z polską kadrą.

## W nocnym ataku Rosji na Ukrainę zniszczone zostało muzeum dowódcy UPA we Lwowie
 - [https://www.rp.pl/konflikty-zbrojne/art39640921-w-nocnym-ataku-rosji-na-ukraine-zniszczone-zostalo-muzeum-dowodcy-upa-we-lwowie](https://www.rp.pl/konflikty-zbrojne/art39640921-w-nocnym-ataku-rosji-na-ukraine-zniszczone-zostalo-muzeum-dowodcy-upa-we-lwowie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T04:55:27+00:00

Mer Lwowa, Andrij Sadowy, poinformował o zniszczeniu Muzeum Romana Szuchewycza, dowódcy UPA, w nocnym ataku dronów-kamikadze na obwód lwowski.

## Wołodymyr Zełenski w noworocznym orędziu mówi o Unii Europejskiej "od Lizbony po Ługańsk"
 - [https://www.rp.pl/konflikty-zbrojne/art39640901-wolodymyr-zelenski-w-noworocznym-oredziu-mowi-o-unii-europejskiej-od-lizbony-po-lugansk](https://www.rp.pl/konflikty-zbrojne/art39640901-wolodymyr-zelenski-w-noworocznym-oredziu-mowi-o-unii-europejskiej-od-lizbony-po-lugansk)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T04:38:01+00:00

- Rok 2023 dobiega końca. Kolejny rok naszej niepodległości. Kolejny rok naszej walki o niepodległość. Kolejny rok wojny - mówił w noworocznym orędziu prezydent Ukrainy, Wołodymyr Zełenski.

## Kim Dzong Un ostrzega przed wojną na Półwyspie Koreańskim
 - [https://www.rp.pl/dyplomacja/art39640881-kim-dzong-un-ostrzega-przed-wojna-na-polwyspie-koreanskim](https://www.rp.pl/dyplomacja/art39640881-kim-dzong-un-ostrzega-przed-wojna-na-polwyspie-koreanskim)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T04:08:01+00:00

Przywódca Korei Północnej, Kim Dzong Un, zwracając się do dowódców północnokoreańskiej armii, mówił o konieczności zmobilizowania "najtwardszych środków", by zniszczyć siły USA i Korei Południowej, jeśli państwa te zdecydują się na starcie militarne z Koreą Północną.

## Wojna Rosji z Ukrainą. Dzień 677
 - [https://www.rp.pl/swiat/art39640861-wojna-rosji-z-ukraina-dzien-677](https://www.rp.pl/swiat/art39640861-wojna-rosji-z-ukraina-dzien-677)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-01T03:45:52+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. Wołodymyr Zełenski w noworocznym orędziu mówił, że "ten, kto sprowadza piekło na ukraińską ziemię, pewnego dnia zobaczy je z własnego okna".

