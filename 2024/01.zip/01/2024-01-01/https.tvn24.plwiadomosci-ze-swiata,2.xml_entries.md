# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Nie wszystkie kładki czy przejścia podziemne znikną. "Do każdego przypadku podchodzimy indywidualnie"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dyrektor-zdm-chcemy-poprawiac-warunki-ruchu-pieszego-st7663846?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dyrektor-zdm-chcemy-poprawiac-warunki-ruchu-pieszego-st7663846?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-01-01T10:38:20+00:00

<img alt="Nie wszystkie kładki czy przejścia podziemne znikną. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-kxb3zl-nowe-przejscia-naziemne-przy-rondzie-dmowskiego-5707874/alternates/LANDSCAPE_1280" />
    Dyrektor stołecznego Zarządu Dróg Miejskich Łukasz Puchalski przekazał, że w celu poprawy warunków ruchu pieszego będą wyznaczane kolejne naziemne przejścia. - Co nie oznacza jednocześnie rozebrania kładek. Do każdego przypadku podchodzimy indywidualnie - zaznaczył.

