# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Games With The BEST STORIES You Can Still Play
 - [https://www.youtube.com/watch?v=uT6AeLfgpgI](https://www.youtube.com/watch?v=uT6AeLfgpgI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-01-01T16:00:27+00:00

For the most part, video game stories fair a lot better than a lot of other mediums. Here's a list of the ten best story games in video games.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1    


0:00 Intro
0:52 Number 10
2:48 Number 9
4:56 Number 8
6:42 Number 7
8:32 Number 6
9:56 Number 5
11:40 Number 4
12:59 Number 3 
14:27 Number 2 
16:09 Number 1

