# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Władimir Putin zagroził Ukraińcom. Zapowiedział więcej ataków
 - [https://www.polsatnews.pl/wiadomosc/2024-01-01/wojna-w-ukrainie-wsciekly-putin-zagrozil-ukraincom-bedzie-wiecej-atakow](https://www.polsatnews.pl/wiadomosc/2024-01-01/wojna-w-ukrainie-wsciekly-putin-zagrozil-ukraincom-bedzie-wiecej-atakow)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-01T19:12:00+00:00

Prezydent Rosji Władimir Putin nazwał serię ukraińskich ataków rakietowych na rosyjskie miasto Biełgorod atakiem terrorystycznym. W ostrzale zginęło 21 osób, a ponad setka została rannych. Polityk zapowiedział, że w odwecie będzie więcej uderzeń w cele na Ukrainie.

## Chorwacja. Bliźniaczki przyszły na świat w różnych latach. "Noworoczny cud"
 - [https://www.polsatnews.pl/wiadomosc/2024-01-01/chorwacja-blizniaczki-przyszly-na-swiat-w-roznych-latach-noworoczny-cud](https://www.polsatnews.pl/wiadomosc/2024-01-01/chorwacja-blizniaczki-przyszly-na-swiat-w-roznych-latach-noworoczny-cud)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-01T15:26:00+00:00

W Splicie (Chorwacja) na świat przyszły wyjątkowe bliźniaczki. Jedna z dziewczynek urodziła się jeszcze w 2023 roku, a druga już w 2024. - Ten przypadek z pewnością przejdzie do historii - powiedział dr Damir Roje.

## Estonia. Od 1 stycznia małżeństwa jednopłciowe są w kraju legalne
 - [https://www.polsatnews.pl/wiadomosc/2024-01-01/estonia-od-1-stycznia-malzenstwa-jednoplciowe-sa-w-kraju-legalne](https://www.polsatnews.pl/wiadomosc/2024-01-01/estonia-od-1-stycznia-malzenstwa-jednoplciowe-sa-w-kraju-legalne)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-01T15:13:00+00:00

Od 1 stycznia 2024 roku małżeństwa osób tej samej płci są w Estonii legalne. Nowe prawo weszło w życie na mocy ustawy przyjętej przez estoński parlament 20 czerwca 2023 roku. Jestem dumna z mojego kraju - przekazała premier Estonii Kaja Kallas. To drugi kraj w Europie Środkowowschodniej z takim prawem.

## Orędzie papieża Franciszka. Apel o budowę społeczeństwa "sprawiedliwego i pokojowego"
 - [https://www.polsatnews.pl/wiadomosc/2024-01-01/papiez-franciszek-wyglosil-oredzie-apel-o-budowe-spoleczenstwa-sprawiedliwego-i-pokojowego](https://www.polsatnews.pl/wiadomosc/2024-01-01/papiez-franciszek-wyglosil-oredzie-apel-o-budowe-spoleczenstwa-sprawiedliwego-i-pokojowego)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-01T12:52:00+00:00

O budowę społeczeństw bardziej sprawiedliwych, ludzkich i pokojowych apelował w Nowy Rok papież Franciszek. Obchodzony pierwszego stycznia 57. Światowy Dzień Pokoju był okazją do spotkania się z wiernymi w Watykanie i wspólnej modlitwy o otwarcie ścieżek pokoju i pojednania.

## Japonia. Trzęsienie ziemi w centrum kraju. Ostrzeżenie o zbliżającym się tsunami
 - [https://www.polsatnews.pl/wiadomosc/2024-01-01/japonia-trzesienie-ziemi-w-centrum-kraju-ostrzezenie-o-zblizajacym-sie-tsunami](https://www.polsatnews.pl/wiadomosc/2024-01-01/japonia-trzesienie-ziemi-w-centrum-kraju-ostrzezenie-o-zblizajacym-sie-tsunami)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-01T08:16:00+00:00

W centralnej części Japonii zarejestrowano silne trzęsienie ziemi o magnitudzie 7,6. Wydano ostrzeżenie o zbliżającym się tsunami, którego fale mogą przekroczyć pięć metrów.

## Ukraina. Lwów zaatakowały drony Shahed. Spłonęło muzeum dowódcy UPA Romana Szuchewycza
 - [https://www.polsatnews.pl/wiadomosc/2024-01-01/ukraina-lwow-zaatakowaly-drony-shahed-splonelo-muzeum-dowodcy-upa-romana-szuchewycza](https://www.polsatnews.pl/wiadomosc/2024-01-01/ukraina-lwow-zaatakowaly-drony-shahed-splonelo-muzeum-dowodcy-upa-romana-szuchewycza)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-01T07:05:00+00:00

Lwów stał się jednym z głównych celów rosyjskiego ataku w sylwestrową noc. Z kolei w Odessie szczątki drona trafiły w wieżowiec. Zginęła jedna osoba.

