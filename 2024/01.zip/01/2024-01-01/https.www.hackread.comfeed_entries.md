# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## Researchers Crack Tesla Autopilot with ‘Elon Mode,’ Access Critical Data
 - [https://www.hackread.com/crack-tesla-autopilot-elon-mode-access-data](https://www.hackread.com/crack-tesla-autopilot-elon-mode-access-data)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2024-01-01T16:39:46+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>German cybersecurity researchers from Technische Universität Berlin employed a €600 (£520 - $660) tool to gain root access to the ARM64-based circuit board of Tesla's autopilot.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/crack-tesla-autopilot-elon-mode-access-data/" rel="nofollow">Researchers Crack Tesla Autopilot with &#8216;Elon Mode,&#8217; Access Critical Data</a></p>

