# Source:BGR, URL:https://bgr.com/feed, language:en-US

## George R.R. Martin has three animated Game of Thrones shows in the works – hooray, I guess
 - [https://bgr.com/entertainment/george-r-r-martin-has-three-animated-game-of-thrones-shows-in-the-works-hooray-i-guess](https://bgr.com/entertainment/george-r-r-martin-has-three-animated-game-of-thrones-shows-in-the-works-hooray-i-guess)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-01T21:11:00+00:00

<p>Blue Eye Samurai, a Netflix animated series about a revenge quest set in 17th-century Japan, was unquestionably one of the streamer&#8217;s best TV shows of &#8230;</p>
<p>The post <a href="https://bgr.com/entertainment/george-r-r-martin-has-three-animated-game-of-thrones-shows-in-the-works-hooray-i-guess/">George R.R. Martin has three animated Game of Thrones shows in the works &#8211; hooray, I guess</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Nintendo Switch 2 might get a remaster of a popular game trilogy
 - [https://bgr.com/entertainment/nintendo-switch-2-might-get-a-remaster-of-a-popular-game-trilogy](https://bgr.com/entertainment/nintendo-switch-2-might-get-a-remaster-of-a-popular-game-trilogy)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-01T19:56:00+00:00

<p>2024 has dawned, and if the rumors are to be believed, Nintendo will launch its latest console before the end of the year. If you &#8230;</p>
<p>The post <a href="https://bgr.com/entertainment/nintendo-switch-2-might-get-a-remaster-of-a-popular-game-trilogy/">Nintendo Switch 2 might get a remaster of a popular game trilogy</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Bitconned is the first must-watch Netflix documentary of 2024
 - [https://bgr.com/entertainment/bitconned-is-the-first-must-watch-netflix-documentary-of-2024](https://bgr.com/entertainment/bitconned-is-the-first-must-watch-netflix-documentary-of-2024)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-01T18:41:00+00:00

<p>Ray Trapani flashes a devil-may-care smile in the new Netflix documentary Bitconned when he reminisces about his childhood. Raised in Atlantic Beach, New York, by &#8230;</p>
<p>The post <a href="https://bgr.com/entertainment/bitconned-is-the-first-must-watch-netflix-documentary-of-2024/">Bitconned is the first must-watch Netflix documentary of 2024</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## iPhone 16’s Capture button might be a bigger upgrade than USB-C and the Action button for me
 - [https://bgr.com/tech/iphone-16s-capture-button-might-be-a-bigger-upgrade-than-usb-c-and-the-action-button-for-me](https://bgr.com/tech/iphone-16s-capture-button-might-be-a-bigger-upgrade-than-usb-c-and-the-action-button-for-me)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-01T17:26:00+00:00

<p>It&#8217;s not that I didn&#8217;t know the iPhone&#8217;s Camera app is one of the apps I use most, but the holidays just made me realize &#8230;</p>
<p>The post <a href="https://bgr.com/tech/iphone-16s-capture-button-might-be-a-bigger-upgrade-than-usb-c-and-the-action-button-for-me/">iPhone 16’s Capture button might be a bigger upgrade than USB-C and the Action button for me</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Epic Games Store free games: What’s free this week?
 - [https://bgr.com/entertainment/epic-games-store-free-games-whats-free-this-week](https://bgr.com/entertainment/epic-games-store-free-games-whats-free-this-week)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-01T16:11:24+00:00

<p>For the past five years, the Epic Games Store has been giving away free PC games each and every week. If you&#8217;re looking to boost your &#8230;</p>
<p>The post <a href="https://bgr.com/entertainment/epic-games-store-free-games-whats-free-this-week/">Epic Games Store free games: What&#8217;s free this week?</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Microsoft Copilot: The first four things you should now that it’s available on iPhone
 - [https://bgr.com/tech/microsoft-copilot-the-first-four-things-you-should-now-that-its-available-on-iphone](https://bgr.com/tech/microsoft-copilot-the-first-four-things-you-should-now-that-its-available-on-iphone)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-01T14:01:00+00:00

<p>Unlike OpenAI, Microsoft released its newest generative AI app on Android before bringing it to the iPhone. That&#8217;s Microsoft Copilot, which landed on Android a &#8230;</p>
<p>The post <a href="https://bgr.com/tech/microsoft-copilot-the-first-four-things-you-should-now-that-its-available-on-iphone/">Microsoft Copilot: The first four things you should now that it&#8217;s available on iPhone</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Walmart leaked the Galaxy S24 Plus’s big AI features
 - [https://bgr.com/tech/walmart-leaked-the-galaxy-s24-pluss-big-ai-features](https://bgr.com/tech/walmart-leaked-the-galaxy-s24-pluss-big-ai-features)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-01T12:30:00+00:00

<p>There&#8217;s no better way to confirm that Samsung is getting ready to unveil the Galaxy S24 series than having a big retailer leak one of &#8230;</p>
<p>The post <a href="https://bgr.com/tech/walmart-leaked-the-galaxy-s24-pluss-big-ai-features/">Walmart leaked the Galaxy S24 Plus&#8217;s big AI features</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

