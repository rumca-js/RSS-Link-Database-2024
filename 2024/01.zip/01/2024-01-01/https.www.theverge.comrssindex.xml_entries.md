# Source:The Verge, URL:https://www.theverge.com/rss/index.xml, language:en-US

## Alamo Drafthouse blames ‘nationwide’ theater outage on Sony projector fail
 - [https://www.theverge.com/2024/1/1/24021915/alamo-drafthouse-outage-sony-projector](https://www.theverge.com/2024/1/1/24021915/alamo-drafthouse-outage-sony-projector)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-01-01T23:29:45+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/aTezACEhhYVJ_VS7URTfn9Vd-6o=/0x0:1974x1316/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73015099/alamo_drafthouse_outage_3nu_reddit.0.jpg" />
        <figcaption><em>A sign reportedly placed at Alamo Drafthouse’s Minnesota location informing patrons that no films will be shown that day.</em> | Photo: <a class="ql-link" href="https://www.reddit.com/r/AlamoDrafthouse/comments/18vcjvh/comment/kfqn64n/?utm_source=share&amp;utm_medium=web2x&amp;context=3" target="_blank">3NU (Reddit)</a></figcaption>
    </figure>

  <p id="J3bAxG">“Sorry everyone! Sony is having issues with their projectors that is preventing us from being able to project movies at some of our theaters today.” </p>
<p id="CLj8fV">That’s what theater chain Alamo Drafthouse <a href="https://twitter.com/alamodrafthouse/status/1741552392766714199">posted</a> <a href="https://www.instagram.com/p/C1h9DaTN8Ft/?hl=en">to</a> social media sites on New Year’s E

## Welcome to the public domain, Mickey Mouse
 - [https://www.theverge.com/24006670/mickey-mouse-steamboat-willie-enters-copyright-public-domain-2024](https://www.theverge.com/24006670/mickey-mouse-steamboat-willie-enters-copyright-public-domain-2024)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-01-01T12:00:00+00:00

<figure>
      <img alt="A screenshot of Mickey Mouse in Steamboat Willie from 1928." src="https://cdn.vox-cdn.com/thumbor/eBbammHe5W3333HbhP42XmeibGE=/0x12:720x492/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73013853/1920_51_107_720.0.jpg" />
        <figcaption>Just be careful not to let major elements from later designs slip in. | Disney</figcaption>
    </figure>

  <p id="xjmDiw">It’s finally happened: after nearly a century, Mickey Mouse has slipped off Disney’s copyright leash. The first versions of the iconic cartoon character, seen in <em>Steamboat Willie </em>and a silent version of <em>Plane Crazy</em>, enter the public domain in the US on January 1st, 2024. (An early version of Minnie Mouse is also fortunately included.) There’s still a complicated mess of protections around Mickey, but today is a moment public domain advocates have awaited for decades — and there are plenty of other exciting new entries as well.</p>
<p id="dCtRlv">Duke Law School’s Center for the

