# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## Made a Shoji Lamp to house a lithophane.
 - [https://www.reddit.com/r/3Dprinting/comments/18wa4o6/made_a_shoji_lamp_to_house_a_lithophane](https://www.reddit.com/r/3Dprinting/comments/18wa4o6/made_a_shoji_lamp_to_house_a_lithophane)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T23:29:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wa4o6/made_a_shoji_lamp_to_house_a_lithophane/"> <img alt="Made a Shoji Lamp to house a lithophane." src="https://a.thumbs.redditmedia.com/XHlRqzrTuwqCDmWO9PdmX6pOZNOfK0Bnexu7QWxA624.jpg" title="Made a Shoji Lamp to house a lithophane." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Gifted this to my cousin who recently had to put his dog down. 17 hour print, 0.12mm layer height, on an Elegoo Neptune 3 Max using Eryone white PLA. Used walnut for the frame and basswood and mulberry paper for the kumiko panels. Wired a simple E26 lamp base to fit a bright T10 LED bulb. Overall a very satisfying and fun build.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Lesar7"> /u/Lesar7 </a> <br /> <span><a href="https://www.reddit.com/gallery/18wa4o6">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wa4o6/made_a_shoji_lamp_to_house_a_lithophane/

## Most organized my Christmas lights have ever been
 - [https://www.reddit.com/r/3Dprinting/comments/18w7cx3/most_organized_my_christmas_lights_have_ever_been](https://www.reddit.com/r/3Dprinting/comments/18w7cx3/most_organized_my_christmas_lights_have_ever_been)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T21:32:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w7cx3/most_organized_my_christmas_lights_have_ever_been/"> <img alt="Most organized my Christmas lights have ever been" src="https://preview.redd.it/uhzdm3madw9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2565b69d1a1099cda68a94dad8b491904041809b" title="Most organized my Christmas lights have ever been" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Had some extra spools I hadn’t thrown out yet and ended up repurposing them</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NarrowHamster7879"> /u/NarrowHamster7879 </a> <br /> <span><a href="https://i.redd.it/uhzdm3madw9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w7cx3/most_organized_my_christmas_lights_have_ever_been/">[comments]</a></span> </td></tr></table>

## Incredible difference in slicers
 - [https://www.reddit.com/r/3Dprinting/comments/18w4ahr/incredible_difference_in_slicers](https://www.reddit.com/r/3Dprinting/comments/18w4ahr/incredible_difference_in_slicers)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T19:24:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w4ahr/incredible_difference_in_slicers/"> <img alt="Incredible difference in slicers" src="https://preview.redd.it/kxcobbwfqv9c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=3b3fead669560595d11b9c4c1a838059b3521a2a" title="Incredible difference in slicers" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I'm new to printing and been struggling with quality using the MingDa-Cura that came with my printer, Mingda Magician X2, beyond the test print file, all of my prints were crap, no matter the settings, so I tried PrusaSlicer and the difference using default settings is huge.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Zero_Divided"> /u/Zero_Divided </a> <br /> <span><a href="https://i.redd.it/kxcobbwfqv9c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w4ahr/incredible_difference_in_slicers/">[comments]</a></span> </td>

## Wife wanted $150 West Elm table lamp.. Close enough ¯\_(ツ)_/¯
 - [https://www.reddit.com/r/3Dprinting/comments/18w3gtl/wife_wanted_150_west_elm_table_lamp_close_enough_ツ](https://www.reddit.com/r/3Dprinting/comments/18w3gtl/wife_wanted_150_west_elm_table_lamp_close_enough_ツ)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T18:50:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w3gtl/wife_wanted_150_west_elm_table_lamp_close_enough_ツ/"> <img alt="Wife wanted $150 West Elm table lamp.. Close enough ¯\_(ツ)_/¯" src="https://preview.redd.it/vszbcbz4kv9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=cb23fc49fd695418018fd013bd1c09b9e3b7a814" title="Wife wanted $150 West Elm table lamp.. Close enough ¯\_(ツ)_/¯" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/frenchtoas30"> /u/frenchtoas30 </a> <br /> <span><a href="https://i.redd.it/vszbcbz4kv9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w3gtl/wife_wanted_150_west_elm_table_lamp_close_enough_ツ/">[comments]</a></span> </td></tr></table>

## 3D printed a trilobite beetle I made
 - [https://www.reddit.com/r/3Dprinting/comments/18w3eqh/3d_printed_a_trilobite_beetle_i_made](https://www.reddit.com/r/3Dprinting/comments/18w3eqh/3d_printed_a_trilobite_beetle_i_made)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T18:47:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w3eqh/3d_printed_a_trilobite_beetle_i_made/"> <img alt="3D printed a trilobite beetle I made" src="https://b.thumbs.redditmedia.com/AHnQvU3JfpKrkV56UVn-6hgaMmm2TNgfGpyO_44O2dA.jpg" title="3D printed a trilobite beetle I made" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/flampydampybampy"> /u/flampydampybampy </a> <br /> <span><a href="https://www.reddit.com/gallery/18w3eqh">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w3eqh/3d_printed_a_trilobite_beetle_i_made/">[comments]</a></span> </td></tr></table>

## Wood PLA came out nice!
 - [https://www.reddit.com/r/3Dprinting/comments/18w329u/wood_pla_came_out_nice](https://www.reddit.com/r/3Dprinting/comments/18w329u/wood_pla_came_out_nice)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T18:33:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w329u/wood_pla_came_out_nice/"> <img alt="Wood PLA came out nice!" src="https://b.thumbs.redditmedia.com/_Xx84jymg37v8o2pU8_8OptOR6ejKDwzoeUTDlRDjfk.jpg" title="Wood PLA came out nice!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/user183739"> /u/user183739 </a> <br /> <span><a href="https://www.reddit.com/gallery/18w329u">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w329u/wood_pla_came_out_nice/">[comments]</a></span> </td></tr></table>

## Baby bender (replacement)
 - [https://www.reddit.com/r/3Dprinting/comments/18w2pz8/baby_bender_replacement](https://www.reddit.com/r/3Dprinting/comments/18w2pz8/baby_bender_replacement)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T18:18:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w2pz8/baby_bender_replacement/"> <img alt="Baby bender (replacement)" src="https://preview.redd.it/nmzhx6xoev9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4c966d561f3393216086955f662c6f0a8df074c9" title="Baby bender (replacement)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>My wife’s best friend has the last name Bender. So a few years ago I made them a Baby Bender print. Unfortunately after a while it was dropped and broke. So now I have made them a replacement, 30% bigger and with an extra wall for strength!</p> <p>Long live Baby Bender!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/wentworthm"> /u/wentworthm </a> <br /> <span><a href="https://i.redd.it/nmzhx6xoev9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w2pz8/baby_bender_replacement/">[comments]</a></span> </td></tr></table>

## First time printing a benchy, what caused that line? it's on back side, the front side is good
 - [https://www.reddit.com/r/3Dprinting/comments/18w2fkn/first_time_printing_a_benchy_what_caused_that](https://www.reddit.com/r/3Dprinting/comments/18w2fkn/first_time_printing_a_benchy_what_caused_that)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T18:05:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w2fkn/first_time_printing_a_benchy_what_caused_that/"> <img alt="First time printing a benchy, what caused that line? it's on back side, the front side is good" src="https://preview.redd.it/i1uf90eecv9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=75fbee1407e99837368935d8f62e89cd1431f194" title="First time printing a benchy, what caused that line? it's on back side, the front side is good" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>i never printed a benchy before and decided to give a try to print one and noticed this</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jembrik"> /u/jembrik </a> <br /> <span><a href="https://i.redd.it/i1uf90eecv9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w2fkn/first_time_printing_a_benchy_what_caused_that/">[comments]</a></span> </td></tr></table>

## I designed and printed an articulated skeleton! So shiny...
 - [https://www.reddit.com/r/3Dprinting/comments/18w15xq/i_designed_and_printed_an_articulated_skeleton_so](https://www.reddit.com/r/3Dprinting/comments/18w15xq/i_designed_and_printed_an_articulated_skeleton_so)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T17:10:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w15xq/i_designed_and_printed_an_articulated_skeleton_so/"> <img alt="I designed and printed an articulated skeleton! So shiny..." src="https://external-preview.redd.it/ZXE4OW8wNmYydjljMUhRAd1h5xqJpFyVN1-pEx82jzlNf7w27XCjVfoK-Jwd.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=693398b7dd8c65bab35bf4cdb0050f75e16801a3" title="I designed and printed an articulated skeleton! So shiny..." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>He is so shiny...</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/beep_beep1"> /u/beep_beep1 </a> <br /> <span><a href="https://v.redd.it/bv595ccf2v9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w15xq/i_designed_and_printed_an_articulated_skeleton_so/">[comments]</a></span> </td></tr></table>

## As someone not especially tech savvy, I’m blown away by practically every print my little printer does. This really blows me away though!
 - [https://www.reddit.com/r/3Dprinting/comments/18w10sp/as_someone_not_especially_tech_savvy_im_blown](https://www.reddit.com/r/3Dprinting/comments/18w10sp/as_someone_not_especially_tech_savvy_im_blown)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T17:03:32+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w10sp/as_someone_not_especially_tech_savvy_im_blown/"> <img alt="As someone not especially tech savvy, I’m blown away by practically every print my little printer does. This really blows me away though!" src="https://external-preview.redd.it/M2dqaHRtejgxdjljMQeTOEgysk9Wzw1XCdcj5SCqfZaF51Q5Ney1OVnR04tx.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=53ae91c1b69f09cb170f27de8160b9f9ca65474a" title="As someone not especially tech savvy, I’m blown away by practically every print my little printer does. This really blows me away though!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Difficult-Thought-61"> /u/Difficult-Thought-61 </a> <br /> <span><a href="https://v.redd.it/6mkvux791v9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w10sp/as_someone_not_especially_tech_savvy_im_blown/">[comments]</a></span> </td></tr></table>

## Speaker holder for shower
 - [https://www.reddit.com/r/3Dprinting/comments/18w05x4/speaker_holder_for_shower](https://www.reddit.com/r/3Dprinting/comments/18w05x4/speaker_holder_for_shower)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T16:24:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18w05x4/speaker_holder_for_shower/"> <img alt="Speaker holder for shower" src="https://a.thumbs.redditmedia.com/0KbNElUn3rj6jXGv3tgiqaDC9Q9uIKkesZcHruN--u8.jpg" title="Speaker holder for shower" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I recently got a JBL Clip 4 for Christmas, a fully water and dust proof speaker which is great for the shower. Since I had nowhere to put it, I made a little hook that sits on the 3/8inch glass. It’s sized perfectly to clear all the door mechanisms</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AlbertoIsExpired"> /u/AlbertoIsExpired </a> <br /> <span><a href="https://www.reddit.com/gallery/18w05x4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18w05x4/speaker_holder_for_shower/">[comments]</a></span> </td></tr></table>

## I recreated a DNA pen holder so no one would have to buy it.
 - [https://www.reddit.com/r/3Dprinting/comments/18vzndm/i_recreated_a_dna_pen_holder_so_no_one_would_have](https://www.reddit.com/r/3Dprinting/comments/18vzndm/i_recreated_a_dna_pen_holder_so_no_one_would_have)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T16:01:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vzndm/i_recreated_a_dna_pen_holder_so_no_one_would_have/"> <img alt="I recreated a DNA pen holder so no one would have to buy it." src="https://preview.redd.it/9wwrjr57qu9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=fc4cb6ff7a5bd3cb0b5ea8194fae161a2becff76" title="I recreated a DNA pen holder so no one would have to buy it." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FartsMcPoptarts"> /u/FartsMcPoptarts </a> <br /> <span><a href="https://i.redd.it/9wwrjr57qu9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vzndm/i_recreated_a_dna_pen_holder_so_no_one_would_have/">[comments]</a></span> </td></tr></table>

## NES Tissue Kleenex Box Cover
 - [https://www.reddit.com/r/3Dprinting/comments/18vyijs/nes_tissue_kleenex_box_cover](https://www.reddit.com/r/3Dprinting/comments/18vyijs/nes_tissue_kleenex_box_cover)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T15:05:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vyijs/nes_tissue_kleenex_box_cover/"> <img alt="NES Tissue Kleenex Box Cover" src="https://preview.redd.it/e5ynjs9bgu9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6aa0228d22701cc18b9c08374fc71ef9155c5f33" title="NES Tissue Kleenex Box Cover" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Functional and fun!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/chomdh"> /u/chomdh </a> <br /> <span><a href="https://i.redd.it/e5ynjs9bgu9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vyijs/nes_tissue_kleenex_box_cover/">[comments]</a></span> </td></tr></table>

## I just got into printing and have been printing benchys too often so my buddy sent me the design for this
 - [https://www.reddit.com/r/3Dprinting/comments/18vy9gw/i_just_got_into_printing_and_have_been_printing](https://www.reddit.com/r/3Dprinting/comments/18vy9gw/i_just_got_into_printing_and_have_been_printing)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T14:53:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vy9gw/i_just_got_into_printing_and_have_been_printing/"> <img alt="I just got into printing and have been printing benchys too often so my buddy sent me the design for this" src="https://preview.redd.it/fub9eni0eu9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b9962676734e381e9285cf23b5fe6b5443ffb934" title="I just got into printing and have been printing benchys too often so my buddy sent me the design for this" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>It’s also my best benchy to date lol</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mcgnarles"> /u/mcgnarles </a> <br /> <span><a href="https://i.redd.it/fub9eni0eu9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vy9gw/i_just_got_into_printing_and_have_been_printing/">[comments]</a></span> </td></tr></table>

## Happy new year to all you talented people!
 - [https://www.reddit.com/r/3Dprinting/comments/18vxqsf/happy_new_year_to_all_you_talented_people](https://www.reddit.com/r/3Dprinting/comments/18vxqsf/happy_new_year_to_all_you_talented_people)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T14:24:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vxqsf/happy_new_year_to_all_you_talented_people/"> <img alt="Happy new year to all you talented people!" src="https://preview.redd.it/9re48x2z8u9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f446ff06dbf9bc8f3ee502a35acc17d5dffff65d" title="Happy new year to all you talented people!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>3D printers test even the most level headed of us 😂</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/_NovaLabs_"> /u/_NovaLabs_ </a> <br /> <span><a href="https://i.redd.it/9re48x2z8u9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vxqsf/happy_new_year_to_all_you_talented_people/">[comments]</a></span> </td></tr></table>

## Company like Shapeways that will do larger 100mm+ brass prints/castings?
 - [https://www.reddit.com/r/3Dprinting/comments/18vxf93/company_like_shapeways_that_will_do_larger_100mm](https://www.reddit.com/r/3Dprinting/comments/18vxf93/company_like_shapeways_that_will_do_larger_100mm)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T14:06:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vxf93/company_like_shapeways_that_will_do_larger_100mm/"> <img alt="Company like Shapeways that will do larger 100mm+ brass prints/castings?" src="https://preview.redd.it/kxc9f0at4u9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0d8d5d5ebb17d3fca702002a0777bdda28ed6982" title="Company like Shapeways that will do larger 100mm+ brass prints/castings?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JAbassplayer"> /u/JAbassplayer </a> <br /> <span><a href="https://i.redd.it/kxc9f0at4u9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vxf93/company_like_shapeways_that_will_do_larger_100mm/">[comments]</a></span> </td></tr></table>

## Game Boy Remote Holder
 - [https://www.reddit.com/r/3Dprinting/comments/18vx898/game_boy_remote_holder](https://www.reddit.com/r/3Dprinting/comments/18vx898/game_boy_remote_holder)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T13:56:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vx898/game_boy_remote_holder/"> <img alt="Game Boy Remote Holder" src="https://external-preview.redd.it/Z2cwbDdpeHUzdTljMfihdqfPTALwDmsafFVeB5X5L7uVlvbO2hCEK8LYReKK.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=f29bd2e857fe4c1bd49e584e6ff919faef39e90d" title="Game Boy Remote Holder" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>One of my best prints is my design of the Game Boy Remote Holder. Happy New Year! 🤗</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/magnuspsa"> /u/magnuspsa </a> <br /> <span><a href="https://v.redd.it/33xy4p1v3u9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vx898/game_boy_remote_holder/">[comments]</a></span> </td></tr></table>

## Am I good enough?
 - [https://www.reddit.com/r/3Dprinting/comments/18vx5xb/am_i_good_enough](https://www.reddit.com/r/3Dprinting/comments/18vx5xb/am_i_good_enough)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T13:52:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vx5xb/am_i_good_enough/"> <img alt="Am I good enough?" src="https://b.thumbs.redditmedia.com/mWWiDzzr-XukuClPEK9WZUI0JAlLd7WQykvveZRdhyE.jpg" title="Am I good enough?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Revolutionary_Owl203"> /u/Revolutionary_Owl203 </a> <br /> <span><a href="https://www.reddit.com/gallery/18vx5xb">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vx5xb/am_i_good_enough/">[comments]</a></span> </td></tr></table>

## PSA maybe the errors in your printing might be you
 - [https://www.reddit.com/r/3Dprinting/comments/18vww3c/psa_maybe_the_errors_in_your_printing_might_be_you](https://www.reddit.com/r/3Dprinting/comments/18vww3c/psa_maybe_the_errors_in_your_printing_might_be_you)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T13:35:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vww3c/psa_maybe_the_errors_in_your_printing_might_be_you/"> <img alt="PSA maybe the errors in your printing might be you" src="https://preview.redd.it/ts1r2ko80u9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=876363a5b3ea107a7089a1c383a433c7498d6578" title="PSA maybe the errors in your printing might be you" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Have just been giving PrusaSlicer a look (not a fan yet) and was told just print the Cali Dragon with default settings, I put in the retraction distance from my cura settings just incase. And it's night and day differences. </p> <p>I've been chasing quality issues for the last few weeks with my cura profile and clearly I'm chasing my own tail at some point.</p> <p>Left is my settings I've been tweaking for about a month and a half from a new profile, right is just default bar from setting row height and retraction distance.</p> <p>So if you find yours

## Best way to remove support material from bolt threads?
 - [https://www.reddit.com/r/3Dprinting/comments/18vwtly/best_way_to_remove_support_material_from_bolt](https://www.reddit.com/r/3Dprinting/comments/18vwtly/best_way_to_remove_support_material_from_bolt)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T13:31:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vwtly/best_way_to_remove_support_material_from_bolt/"> <img alt="Best way to remove support material from bolt threads?" src="https://b.thumbs.redditmedia.com/8B-k0z_WAH-NNANHtdM_4W49z_fLNhHTWiyd2iXB0Us.jpg" title="Best way to remove support material from bolt threads?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Just started 3D printing and am curious to know what some of your best practices are for removing support material from small areas such as bolt threads. I've tried using a plastic pick tool but can't seem to get it to budge without fear of breaking the thread. </p> <p>Print info: Printer - Entina Tina2, Material - purefil PLA, Infill - 50%, High Quality</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DraymindGreen"> /u/DraymindGreen </a> <br /> <span><a href="https://www.reddit.com/gallery/18vwtly">[link]</a></span> &#32; <span><a href="https://www.reddit.

## Relatively cleaner prints today
 - [https://www.reddit.com/r/3Dprinting/comments/18vwl6l/relatively_cleaner_prints_today](https://www.reddit.com/r/3Dprinting/comments/18vwl6l/relatively_cleaner_prints_today)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T13:18:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vwl6l/relatively_cleaner_prints_today/"> <img alt="Relatively cleaner prints today" src="https://b.thumbs.redditmedia.com/h7lzyhsNSLeQbK1wRBvS28shMIGVqgEApM_glZyZlLg.jpg" title="Relatively cleaner prints today" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Thank you for guiding regarding what step to check next after the temp tower. </p> <p>I did change my retraction down, based on the calibration print to .6 from .8 (default).</p> <p>There still few here and there but thats to be expected as I was told. What disappear are fuzz like things and alot of threading that appears in hole. </p> <p>I dont have dryer and was nervous this morning because I forgot to take out the spool but i do have ziplock with silica over it on the handle...</p> <p>Current humidty here is 88% ;A; i guess I can pass on getting a dryer till its the moonsoon season. All I plan to print is PLA.</p> </div><!-- SC_ON --> &#32; submitted 

## Designed this mount to hide my Steam Deck +Dock behind my corner mounted TV
 - [https://www.reddit.com/r/3Dprinting/comments/18vwks8/designed_this_mount_to_hide_my_steam_deck_dock](https://www.reddit.com/r/3Dprinting/comments/18vwks8/designed_this_mount_to_hide_my_steam_deck_dock)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T13:17:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vwks8/designed_this_mount_to_hide_my_steam_deck_dock/"> <img alt="Designed this mount to hide my Steam Deck +Dock behind my corner mounted TV" src="https://b.thumbs.redditmedia.com/mZnYPu_RAypwoqiYN1jg57ppycq2MlDNy0fMv6HIz0g.jpg" title="Designed this mount to hide my Steam Deck +Dock behind my corner mounted TV" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheGreatMonk"> /u/TheGreatMonk </a> <br /> <span><a href="https://www.reddit.com/gallery/18vwks8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vwks8/designed_this_mount_to_hide_my_steam_deck_dock/">[comments]</a></span> </td></tr></table>

## Worst first layer ever
 - [https://www.reddit.com/r/3Dprinting/comments/18vwegk/worst_first_layer_ever](https://www.reddit.com/r/3Dprinting/comments/18vwegk/worst_first_layer_ever)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T13:06:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vwegk/worst_first_layer_ever/"> <img alt="Worst first layer ever" src="https://b.thumbs.redditmedia.com/MsrlT2Yuue-Cg0L_sU_r0haPXvsvbmbZMMcMFK1ZfJw.jpg" title="Worst first layer ever" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I've been having trouble with my first prints, and they only seem to worsen.</p> <p>First, the Teflon tube was obstructed and prevented any filament from being extruded. I removed the plastic piece causing the problem and was able to start printing, but then the nozzle got clogged. I tried cleaning it, but as the problem persisted, I ultimately had to replace it.</p> <p>By this point, I somehow managed to get the first layers of my prints right, but never the whole thing, so I figured it had to be due to the bed. I tried leveling it several times, but now, as you can see in the pictures, the very first layer is wrong. If I don't stop the printer, the entire thing unsticks from the

## Can somebody explain to me, why my PLA keeps "shrinking"?
 - [https://www.reddit.com/r/3Dprinting/comments/18vwams/can_somebody_explain_to_me_why_my_pla_keeps](https://www.reddit.com/r/3Dprinting/comments/18vwams/can_somebody_explain_to_me_why_my_pla_keeps)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T13:00:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vwams/can_somebody_explain_to_me_why_my_pla_keeps/"> <img alt="Can somebody explain to me, why my PLA keeps &quot;shrinking&quot;?" src="https://external-preview.redd.it/dHlsMmg0enl0dDljMauwTZDIgDPKGwXV8vsVv1dvKRa4dxEjOly3ZIdMuiSE.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=4032157a6d7fbdece9c88f139f9b247ad46f767f" title="Can somebody explain to me, why my PLA keeps &quot;shrinking&quot;?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>As you can see in the video, as soon as the muzzle stops extruding the PLA, it kind of shrinks back together. I only have that problem with this silver PLA. I already dried it and put it in an airsealed container with one of these anti-moisture-bags. Also everytime i use this PLA the layers of my print don't stick together well and fall apart if minimal pressure is applied. Thx in advance! </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com

## Most suspenseful 10% of my life 😬
 - [https://www.reddit.com/r/3Dprinting/comments/18vv81e/most_suspenseful_10_of_my_life](https://www.reddit.com/r/3Dprinting/comments/18vv81e/most_suspenseful_10_of_my_life)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T11:48:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vv81e/most_suspenseful_10_of_my_life/"> <img alt="Most suspenseful 10% of my life 😬" src="https://external-preview.redd.it/YTg1aWRrbzVodDljMQ4jJfzelIjoz4c7YvNRezEF3toK3cl9vMYTsuWboJva.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=043eda0fbbda90063f5d69556fc620b4dc34e031" title="Most suspenseful 10% of my life 😬" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Tiskfully"> /u/Tiskfully </a> <br /> <span><a href="https://v.redd.it/nnjjswq5ht9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vv81e/most_suspenseful_10_of_my_life/">[comments]</a></span> </td></tr></table>

## Thank you gold PEI for exposing my fingers as the grubby meatsticks they truly are. I promise i wash my hands
 - [https://www.reddit.com/r/3Dprinting/comments/18vv0rp/thank_you_gold_pei_for_exposing_my_fingers_as_the](https://www.reddit.com/r/3Dprinting/comments/18vv0rp/thank_you_gold_pei_for_exposing_my_fingers_as_the)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T11:34:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vv0rp/thank_you_gold_pei_for_exposing_my_fingers_as_the/"> <img alt="Thank you gold PEI for exposing my fingers as the grubby meatsticks they truly are. I promise i wash my hands" src="https://external-preview.redd.it/ho2O3RBN19TdGIpa4Ri7PfcvsK15VyVkIjmtB5uXKbo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=98e4efa126703a8bd78b20dbd7ecf78411891c7b" title="Thank you gold PEI for exposing my fingers as the grubby meatsticks they truly are. I promise i wash my hands" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MooneBoy"> /u/MooneBoy </a> <br /> <span><a href="https://i.imgur.com/V25YB96.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vv0rp/thank_you_gold_pei_for_exposing_my_fingers_as_the/">[comments]</a></span> </td></tr></table>

## Modular Organic Skeletonized Light Column
 - [https://www.reddit.com/r/3Dprinting/comments/18vudrb/modular_organic_skeletonized_light_column](https://www.reddit.com/r/3Dprinting/comments/18vudrb/modular_organic_skeletonized_light_column)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T10:48:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vudrb/modular_organic_skeletonized_light_column/"> <img alt="Modular Organic Skeletonized Light Column" src="https://external-preview.redd.it/a3ZhZmhwNWU2dDljMcc7bi9FAi_c_E4bLoJISfA4I1lNylOiGhrD9-F1OCrZ.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=2cbc39b108a40b10ed146b7541a55c38a79facea" title="Modular Organic Skeletonized Light Column" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/b3p4u"> /u/b3p4u </a> <br /> <span><a href="https://v.redd.it/u872y87e6t9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vudrb/modular_organic_skeletonized_light_column/">[comments]</a></span> </td></tr></table>

## Designed some 3d printed navigation light LED diffusers for my Mini 2, 3 LEDS, 1.5 g printed, under 6g all in.
 - [https://www.reddit.com/r/3Dprinting/comments/18vu94x/designed_some_3d_printed_navigation_light_led](https://www.reddit.com/r/3Dprinting/comments/18vu94x/designed_some_3d_printed_navigation_light_led)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T10:39:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vu94x/designed_some_3d_printed_navigation_light_led/"> <img alt="Designed some 3d printed navigation light LED diffusers for my Mini 2, 3 LEDS, 1.5 g printed, under 6g all in." src="https://preview.redd.it/9nguw5cj4t9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bd0d65bee01ea17f697e125c51d07bd3130d2651" title="Designed some 3d printed navigation light LED diffusers for my Mini 2, 3 LEDS, 1.5 g printed, under 6g all in." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ThargUK"> /u/ThargUK </a> <br /> <span><a href="https://i.redd.it/9nguw5cj4t9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vu94x/designed_some_3d_printed_navigation_light_led/">[comments]</a></span> </td></tr></table>

## My new favorite print
 - [https://www.reddit.com/r/3Dprinting/comments/18vt901/my_new_favorite_print](https://www.reddit.com/r/3Dprinting/comments/18vt901/my_new_favorite_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T09:25:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vt901/my_new_favorite_print/"> <img alt="My new favorite print" src="https://preview.redd.it/rlypax1lrs9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8a5d513a247422541481eb5ded7426a774c71170" title="My new favorite print" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Impressive_Load1615"> /u/Impressive_Load1615 </a> <br /> <span><a href="https://i.redd.it/rlypax1lrs9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vt901/my_new_favorite_print/">[comments]</a></span> </td></tr></table>

## String Art Prints Are Dope
 - [https://www.reddit.com/r/3Dprinting/comments/18vs7k8/string_art_prints_are_dope](https://www.reddit.com/r/3Dprinting/comments/18vs7k8/string_art_prints_are_dope)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T08:08:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vs7k8/string_art_prints_are_dope/"> <img alt="String Art Prints Are Dope" src="https://preview.redd.it/846z1husds9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c3049ee939b3ce33944a428ec9e24c9cced091d5" title="String Art Prints Are Dope" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><a href="https://www.printables.com/model/563912-safe-from-the-rain/">https://www.printables.com/model/563912-safe-from-the-rain/</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bjamesk4"> /u/bjamesk4 </a> <br /> <span><a href="https://i.redd.it/846z1husds9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vs7k8/string_art_prints_are_dope/">[comments]</a></span> </td></tr></table>

## Wolverine Mask is FINALLY FINISHED!!
 - [https://www.reddit.com/r/3Dprinting/comments/18vrzv2/wolverine_mask_is_finally_finished](https://www.reddit.com/r/3Dprinting/comments/18vrzv2/wolverine_mask_is_finally_finished)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T07:53:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vrzv2/wolverine_mask_is_finally_finished/"> <img alt="Wolverine Mask is FINALLY FINISHED!!" src="https://b.thumbs.redditmedia.com/tZI-IEIga6Wl45VT-brsK2e1G76pby02hBJ-B6b3EIw.jpg" title="Wolverine Mask is FINALLY FINISHED!!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I made this for my Uncle for Christmas! Lmk your thoughts!!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Grexify"> /u/Grexify </a> <br /> <span><a href="https://www.reddit.com/gallery/18vrzv2">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vrzv2/wolverine_mask_is_finally_finished/">[comments]</a></span> </td></tr></table>

## First project in my new A1. Light Saber for my brother’s birthday.
 - [https://www.reddit.com/r/3Dprinting/comments/18vrngz/first_project_in_my_new_a1_light_saber_for_my](https://www.reddit.com/r/3Dprinting/comments/18vrngz/first_project_in_my_new_a1_light_saber_for_my)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T07:29:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vrngz/first_project_in_my_new_a1_light_saber_for_my/"> <img alt="First project in my new A1. Light Saber for my brother’s birthday." src="https://b.thumbs.redditmedia.com/dHkEIdBKEs-PD7yYg0nDRJpq6AuyK5DOuv-MsTgmmUE.jpg" title="First project in my new A1. Light Saber for my brother’s birthday." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Got a Bambu Lab A1 + AMS lite for Christmas to replace my well used Ender 3 pro. Decided to make a lightsaber and box for my brother for his Birthday. Have to say knocking out the printing in a single day was super cool. Gave it to him tonight and he loved it. Let me know what you think.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ireverent87"> /u/ireverent87 </a> <br /> <span><a href="https://www.reddit.com/gallery/18vrngz">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vrngz/first_project_

## Spidey senses tingling
 - [https://www.reddit.com/r/3Dprinting/comments/18vr15g/spidey_senses_tingling](https://www.reddit.com/r/3Dprinting/comments/18vr15g/spidey_senses_tingling)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T06:46:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vr15g/spidey_senses_tingling/"> <img alt="Spidey senses tingling" src="https://preview.redd.it/dpe1gdz4zr9c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=4c05f68b7ffde531369391736b03f5ccb693026d" title="Spidey senses tingling" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>First mask printed on my N3Plus</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Goodnight_Gromit"> /u/Goodnight_Gromit </a> <br /> <span><a href="https://i.redd.it/dpe1gdz4zr9c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vr15g/spidey_senses_tingling/">[comments]</a></span> </td></tr></table>

## Purchase Advice Megathread - January 2024
 - [https://www.reddit.com/r/3Dprinting/comments/18vpg8p/purchase_advice_megathread_january_2024](https://www.reddit.com/r/3Dprinting/comments/18vpg8p/purchase_advice_megathread_january_2024)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T05:01:37+00:00

<!-- SC_OFF --><div class="md"><p>Welcome back to another purchase megathread!</p> <p>This thread is meant to conglomerate purchase advice for both newcomers and people looking for additional machines. Keeping this discussion to one thread means less searching should anyone have questions that may already have been answered here, as well as more visibility to inquiries in general, as comments made here will be visible for the entire month stuck to the top of the sub, and then added to the Purchase Advice Collection (Reddit Collections are still broken on mobile view, enable &quot;view in desktop mode&quot;).</p> <p><strong>Please be sure to skim through this thread</strong> for posts with similar requirements to your own first, as recommendations relevant to your situation may have already been posted, and may even include answers to follow up questions you might have wished to ask. </p> <p>If you are new to 3D printing, and are unsure of what to ask, try to include the following in 

## I just printed my first ever thing and I'm so excited to make all the minis for our DnD campaign!
 - [https://www.reddit.com/r/3Dprinting/comments/18vpf4h/i_just_printed_my_first_ever_thing_and_im_so](https://www.reddit.com/r/3Dprinting/comments/18vpf4h/i_just_printed_my_first_ever_thing_and_im_so)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T05:00:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vpf4h/i_just_printed_my_first_ever_thing_and_im_so/"> <img alt="I just printed my first ever thing and I'm so excited to make all the minis for our DnD campaign!" src="https://preview.redd.it/rgtkgpu7gr9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=bff9e1bed2c6b290d93a554f633411c68d7ce401" title="I just printed my first ever thing and I'm so excited to make all the minis for our DnD campaign!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Box-Weasel"> /u/Box-Weasel </a> <br /> <span><a href="https://i.redd.it/rgtkgpu7gr9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vpf4h/i_just_printed_my_first_ever_thing_and_im_so/">[comments]</a></span> </td></tr></table>

## I love being able to make useful prints.
 - [https://www.reddit.com/r/3Dprinting/comments/18vnurj/i_love_being_able_to_make_useful_prints](https://www.reddit.com/r/3Dprinting/comments/18vnurj/i_love_being_able_to_make_useful_prints)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T03:17:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vnurj/i_love_being_able_to_make_useful_prints/"> <img alt="I love being able to make useful prints." src="https://preview.redd.it/xcixquokxq9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b9aed52717e3f191ef233c19a15ba00112bc897d" title="I love being able to make useful prints." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BurritoSandwich"> /u/BurritoSandwich </a> <br /> <span><a href="https://i.redd.it/xcixquokxq9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vnurj/i_love_being_able_to_make_useful_prints/">[comments]</a></span> </td></tr></table>

## Surprise guest? No problem.
 - [https://www.reddit.com/r/3Dprinting/comments/18vm14x/surprise_guest_no_problem](https://www.reddit.com/r/3Dprinting/comments/18vm14x/surprise_guest_no_problem)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T01:26:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vm14x/surprise_guest_no_problem/"> <img alt="Surprise guest? No problem. " src="https://external-preview.redd.it/MzZxa2xrMDZlcTljMYW48sYU4wkmoNiTrCDo3fXbjrZwjdyPasjFG5kjDFej.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=05dd0a3b0492a69132b9a5359ad965c3fbc2e2a2" title="Surprise guest? No problem. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DaveMakesStuffBC"> /u/DaveMakesStuffBC </a> <br /> <span><a href="https://v.redd.it/e6005256eq9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vm14x/surprise_guest_no_problem/">[comments]</a></span> </td></tr></table>

## 3D printed Deadpool from Do3D 🫢
 - [https://www.reddit.com/r/3Dprinting/comments/18vlsgs/3d_printed_deadpool_from_do3d](https://www.reddit.com/r/3Dprinting/comments/18vlsgs/3d_printed_deadpool_from_do3d)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T01:13:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vlsgs/3d_printed_deadpool_from_do3d/"> <img alt="3D printed Deadpool from Do3D 🫢" src="https://external-preview.redd.it/aTY0OHgzc2dicTljMTWRk_gnNi39lmAi9FSHkzSBWvF1feP0R_uGPTFU5lNH.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=c9bc9c069c6a65cb3b43bfb18c509de8e0afad3b" title="3D printed Deadpool from Do3D 🫢" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Cargy3D"> /u/Cargy3D </a> <br /> <span><a href="https://v.redd.it/9e95471hbq9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vlsgs/3d_printed_deadpool_from_do3d/">[comments]</a></span> </td></tr></table>

## 6 x HDD holder for my home server
 - [https://www.reddit.com/r/3Dprinting/comments/18vloe4/6_x_hdd_holder_for_my_home_server](https://www.reddit.com/r/3Dprinting/comments/18vloe4/6_x_hdd_holder_for_my_home_server)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T01:06:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vloe4/6_x_hdd_holder_for_my_home_server/"> <img alt="6 x HDD holder for my home server" src="https://b.thumbs.redditmedia.com/lrcLJeeOVvxv5V039RkK3WhxvVp52Z5cuwVHXJJzhMk.jpg" title="6 x HDD holder for my home server" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/popson"> /u/popson </a> <br /> <span><a href="https://www.printables.com/model/701526-35-hdd-rack-caddy-holder-6-drives">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vloe4/6_x_hdd_holder_for_my_home_server/">[comments]</a></span> </td></tr></table>

## Cool print idea
 - [https://www.reddit.com/r/3Dprinting/comments/18vlbic/cool_print_idea](https://www.reddit.com/r/3Dprinting/comments/18vlbic/cool_print_idea)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T00:47:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vlbic/cool_print_idea/"> <img alt="Cool print idea" src="https://external-preview.redd.it/MHg1c29oMnd6ajljMYWtob0LZ0B8DhdTg7gA5Pf5CGddpRy7Y9SsECJomlyd.png?width=140&amp;height=140&amp;crop=140:140,smart&amp;format=jpg&amp;v=enabled&amp;lthumb=true&amp;s=401b100bf47bae5bfca55ff39f701c6d4f57905a" title="Cool print idea" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/That0neGuy96"> /u/That0neGuy96 </a> <br /> <span><a href="https://v.redd.it/o728875wzj9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vlbic/cool_print_idea/">[comments]</a></span> </td></tr></table>

## 3d knitted grogu gifts for the families new years resolutions. Mine Is simple I will print MORE!!!!
 - [https://www.reddit.com/r/3Dprinting/comments/18vl2r7/3d_knitted_grogu_gifts_for_the_families_new_years](https://www.reddit.com/r/3Dprinting/comments/18vl2r7/3d_knitted_grogu_gifts_for_the_families_new_years)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-01T00:33:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18vl2r7/3d_knitted_grogu_gifts_for_the_families_new_years/"> <img alt="3d knitted grogu gifts for the families new years resolutions. Mine Is simple I will print MORE!!!! " src="https://external-preview.redd.it/cDZpNXVscWU0cTljMU6vTlyoIDCddWM0ynQ6TjykkTZmDVhb_fm4syG7Fi1N.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=1ea5c94805aa79c398346e82d7644c873276ce43" title="3d knitted grogu gifts for the families new years resolutions. Mine Is simple I will print MORE!!!! " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Russell_Sin"> /u/Russell_Sin </a> <br /> <span><a href="https://v.redd.it/tpnzpoye4q9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18vl2r7/3d_knitted_grogu_gifts_for_the_families_new_years/">[comments]</a></span> </td></tr></table>

