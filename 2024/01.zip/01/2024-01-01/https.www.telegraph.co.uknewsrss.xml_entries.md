# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Record number of excess deaths amid NHS strikes
 - [https://www.telegraph.co.uk/news/2024/01/01/nhs-strikes-fuel-record-number-excess-deaths](https://www.telegraph.co.uk/news/2024/01/01/nhs-strikes-fuel-record-number-excess-deaths)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2024-01-01T21:35:19+00:00



## American mother suspected of killing two of her children arrested in Britain, US police say
 - [https://www.telegraph.co.uk/news/2024/01/01/colorado-mother-kimberlee-springler-arrested-uk-police](https://www.telegraph.co.uk/news/2024/01/01/colorado-mother-kimberlee-springler-arrested-uk-police)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2024-01-01T08:57:34+00:00



## The best pictures of New Year’s Eve fireworks in London and Edinburgh
 - [https://www.telegraph.co.uk/news/2024/01/01/new-years-eve-fireworks-london-edinburgh](https://www.telegraph.co.uk/news/2024/01/01/new-years-eve-fireworks-london-edinburgh)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2024-01-01T01:22:24+00:00



## Man arrested after two women found dead in Staffordshire home
 - [https://www.telegraph.co.uk/news/2024/01/01/cheadle-man-arrested-two-women-found-dead-staffordshire](https://www.telegraph.co.uk/news/2024/01/01/cheadle-man-arrested-two-women-found-dead-staffordshire)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2024-01-01T01:06:00+00:00



