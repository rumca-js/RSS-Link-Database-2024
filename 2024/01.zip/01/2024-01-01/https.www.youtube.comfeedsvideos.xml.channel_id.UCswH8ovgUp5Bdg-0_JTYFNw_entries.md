# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Is THIS Why Young People Are COLLAPSING?!
 - [https://www.youtube.com/watch?v=Q0dznt5yegc](https://www.youtube.com/watch?v=Q0dznt5yegc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-01-01T18:00:21+00:00

As excess deaths in the US soar since the pandemic, why are so many young people collapsing? 

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

