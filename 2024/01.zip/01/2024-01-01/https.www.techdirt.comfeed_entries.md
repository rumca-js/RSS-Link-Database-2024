# Source:Techdirt, URL:https://www.techdirt.com/feed/, language:en-US

## And We’re Off! Time To Get Started On This Year’s Public Domain Game Jam
 - [https://www.techdirt.com/2024/01/01/and-were-off-time-to-get-started-on-this-years-public-domain-game-jam](https://www.techdirt.com/2024/01/01/and-were-off-time-to-get-started-on-this-years-public-domain-game-jam)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2024-01-01T17:00:00+00:00

Join our public domain game jam, Gaming Like It&#8217;s 1928! » Happy new year, everyone — and happy public domain day! That&#8217;s right: today&#8217;s the day that works from 1928 exit copyright protection and become public domain in the US, and that means it&#8217;s time for the latest edition of our annual public domain game [&#8230;]

