# Source:Eli the Computer Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ, language:en-US

## Anti Rossmann Robot Learns Lawn Care…
 - [https://www.youtube.com/watch?v=Him5pf-eXrk](https://www.youtube.com/watch?v=Him5pf-eXrk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ
 - date published: 2024-01-01T23:47:52+00:00

Bot goes to Boot Camp!

