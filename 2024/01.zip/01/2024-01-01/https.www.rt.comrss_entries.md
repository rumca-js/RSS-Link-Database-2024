# Source:RT - Daily news, URL:https://www.rt.com/rss/, language:en

## First ex-Soviet state legalizes gay marriage
 - [https://www.rt.com/russia/590017-estonia-legalizes-gay-marriage/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590017-estonia-legalizes-gay-marriage/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T23:09:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659345f985f54067630ab371.jpg" style="margin-right: 10px;" /> Same-sex couples in Estonia may legally marry in a regional first, though the practice remains controversial <br /><a href="https://www.rt.com/russia/590017-estonia-legalizes-gay-marriage/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Another child dies in Ukrainian attack on Russian city
 - [https://www.rt.com/russia/590014-belgorod-death-toll-ukraine-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590014-belgorod-death-toll-ukraine-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T22:11:06+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659332922030271bcf41c9f4.jpg" style="margin-right: 10px;" /> The death toll in Ukraine’s attack on the Russian city of Belgorod climbed to 25, while some 109 civilians were injured <br /><a href="https://www.rt.com/russia/590014-belgorod-death-toll-ukraine-attack/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Explosion destroys museum honoring Nazi collaborator in Ukraine
 - [https://www.rt.com/russia/590013-ukraine-explosion-museum-destroyed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590013-ukraine-explosion-museum-destroyed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T21:50:13+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65932aca85f540795049c701.png" style="margin-right: 10px;" /> Two sites linked to Ukrainian national ‘heroes’ and WW2-era Nazi collaborators were damaged in the city of Lviv <br /><a href="https://www.rt.com/russia/590013-ukraine-explosion-museum-destroyed/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel strikes down judicial overhaul
 - [https://www.rt.com/news/590015-israel-cancels-judicial-reform-court/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590015-israel-cancels-judicial-reform-court/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T21:49:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65932b34203027113119cb65.jpeg" style="margin-right: 10px;" /> Israel’s Supreme Court has canceled a key piece of the Netanyahu government’s controversial judicial reforms <br /><a href="https://www.rt.com/news/590015-israel-cancels-judicial-reform-court/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Sergey Karaganov: Russians are the real Europeans, the West of the continent has lost its way
 - [https://www.rt.com/news/590016-sergey-karaganov-russia-west/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590016-sergey-karaganov-russia-west/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T21:40:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65932fa885f54001690d1e7f.jpg" style="margin-right: 10px;" /> In terms of being a global power, the Old World is finished. Moscow realized it, but our former partners remain in denial <br /><a href="https://www.rt.com/news/590016-sergey-karaganov-russia-west/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Bill Clinton to be named in Epstein files – media
 - [https://www.rt.com/news/590011-clinton-named-epstein-files/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590011-clinton-named-epstein-files/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T18:37:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659303e120302731bd747e36.jpg" style="margin-right: 10px;" /> Former US President Bill Clinton will be named in court documents concerning deceased pedophile Jeffrey Epstein, ABC News has reported <br /><a href="https://www.rt.com/news/590011-clinton-named-epstein-files/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## War in Gaza won’t end in 2024 - Israel
 - [https://www.rt.com/news/590012-israel-war-all-year-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590012-israel-war-all-year-gaza/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T18:32:38+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6593051a85f54067630ab36a.jpeg" style="margin-right: 10px;" /> Israel’s war in Gaza will likely last all year, a spokesman for the Israel Defense Forces has said <br /><a href="https://www.rt.com/news/590012-israel-war-all-year-gaza/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Britain’s arms stockpile reduced to ‘nothing’ – The Times
 - [https://www.rt.com/news/590010-times-uk-arms-stocks-reduced-nothing/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590010-times-uk-arms-stocks-reduced-nothing/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T17:49:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592e46e2030274332288801.jpg" style="margin-right: 10px;" /> The Times, citing anonymous sources, has claimed that weapons deliveries to Ukraine have reduced UK stockpiles to “nothing”  <br /><a href="https://www.rt.com/news/590010-times-uk-arms-stocks-reduced-nothing/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia to ramp up attacks on Ukraine – Putin
 - [https://www.rt.com/russia/590009-putin-belgorod-ukraine-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590009-putin-belgorod-ukraine-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T17:43:53+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592f37a20302728cb78e9e8.jpg" style="margin-right: 10px;" /> Russia will not carpet bomb Ukrainian cities in retaliation for Kiev’s terrorist attack on civilians, President Vladimir Putin has said <br /><a href="https://www.rt.com/russia/590009-putin-belgorod-ukraine-attack/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Building a just world order: How Russia and the Arab world defied Western pressure in 2023
 - [https://www.rt.com/russia/589973-putin-middle-east-north-africa/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589973-putin-middle-east-north-africa/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T15:34:33+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592d90720302721da3550d5.jpg" style="margin-right: 10px;" /> By putting their own national interests first, Moscow and its partners work towards a more balanced multipolar reality <br /><a href="https://www.rt.com/russia/589973-putin-middle-east-north-africa/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Hundreds arrested in French and German New Year anarchy (VIDEOS)
 - [https://www.rt.com/news/590008-paris-berlin-new-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590008-paris-berlin-new-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T14:40:17+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592c91a20302721da3550ce.jpg" style="margin-right: 10px;" /> Police in France and Germany made hundreds of arrests after a spate of firework attacks and vehicle burnings <br /><a href="https://www.rt.com/news/590008-paris-berlin-new-year/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky is ‘scum’ – ex-Russian president
 - [https://www.rt.com/russia/590005-ex-president-medvedev-zelensky-scum/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590005-ex-president-medvedev-zelensky-scum/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T14:27:35+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592b81585f54001690d1e6a.jpg" style="margin-right: 10px;" /> Ex-Russian President Dmitry Medvedev brands Ukraine’s Vladimir Zelensky “scum” over Kiev’s strike on Belgorod on Saturday <br /><a href="https://www.rt.com/russia/590005-ex-president-medvedev-zelensky-scum/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia vows to fight ‘cancel culture’ as CIS chair
 - [https://www.rt.com/russia/590007-russia-fight-cancel-culture/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590007-russia-fight-cancel-culture/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T14:07:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592c23920302731bd747e2e.jpg" style="margin-right: 10px;" /> Russia will resist “cancel culture” attempts as CIS chair, the Kremlin has said <br /><a href="https://www.rt.com/russia/590007-russia-fight-cancel-culture/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia scraps import duty on eggs
 - [https://www.rt.com/business/589996-russia-eggs-import-duty/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589996-russia-eggs-import-duty/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T13:51:21+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592b79a85f54019e54a8ebe.jpg" style="margin-right: 10px;" /> The Russian government has allowed duty-free imports of eggs in the first half of the year in a bid to stop the surge in prices <br /><a href="https://www.rt.com/business/589996-russia-eggs-import-duty/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian economy is in a ‘structural shift’ – Putin
 - [https://www.rt.com/business/590006-russia-economy-shift-putin/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/590006-russia-economy-shift-putin/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T13:16:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592b6da20302726fb778d1b.jpg" style="margin-right: 10px;" /> The Russian economy is in good shape and is rapidly expanding despite pressure from Western sanctions, President Vladimir Putin says <br /><a href="https://www.rt.com/business/590006-russia-economy-shift-putin/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin names Russia’s real enemies
 - [https://www.rt.com/russia/590003-putin-names-russia-real-enemies/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590003-putin-names-russia-real-enemies/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T12:27:52+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592b1fd85f5407b33109552.jpg" style="margin-right: 10px;" /> The collective West is the true enemy of Russia rather than Ukraine itself, Russian President Vladimir Putin has said <br /><a href="https://www.rt.com/russia/590003-putin-names-russia-real-enemies/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin outlines objectives for Russia’s BRICS presidency
 - [https://www.rt.com/russia/590002-putin-russia-objectives-brics-presidency/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590002-putin-russia-objectives-brics-presidency/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T12:16:46+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6592a48d85f540696551b1c6.jpg" style="margin-right: 10px;" /> Vladimir Putin has vowed to promote internal cooperation within BRICS as Russia assumes the bloc’s presidency <br /><a href="https://www.rt.com/russia/590002-putin-russia-objectives-brics-presidency/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Tsunami warning issued after powerful earthquake strikes Japan (VIDEOS)
 - [https://www.rt.com/news/590000-japan-quake-tsunami-nuclear-power-plants/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590000-japan-quake-tsunami-nuclear-power-plants/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T11:02:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659292222030272df02f0e5e.jpg" style="margin-right: 10px;" /> Japanese authorities have reported that several nuclear power plants have been slightly damaged amid a powerful earthquake and tsunami <br /><a href="https://www.rt.com/news/590000-japan-quake-tsunami-nuclear-power-plants/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Baltic state becomes leading sparkling wine supplier to Russia – media
 - [https://www.rt.com/business/589995-latvia-sparkling-wine-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589995-latvia-sparkling-wine-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T10:56:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65929a0b2030272b5325c16f.jpg" style="margin-right: 10px;" /> Latvia has emerged as Russia’s largest sparkling wine supplier in the first nine months of 2023, RIA Novosti reports, citing trade data <br /><a href="https://www.rt.com/business/589995-latvia-sparkling-wine-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Moscow slams Ukraine’s ‘terrorist brutes’ over New Year attack
 - [https://www.rt.com/russia/589999-ukraine-terrorist-brutes-donetsk-shelling/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589999-ukraine-terrorist-brutes-donetsk-shelling/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T10:24:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65928a0b203027296a224254.png" style="margin-right: 10px;" /> Only “terrorist brutes” could have staged a deadly Ukrainian attack on civilians in Donetsk on New Year’s night, Moscow has said <br /><a href="https://www.rt.com/russia/589999-ukraine-terrorist-brutes-donetsk-shelling/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian diamond ban comes into force
 - [https://www.rt.com/business/589994-russian-diamond-ban-g7-eu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589994-russian-diamond-ban-g7-eu/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T08:46:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65927b80203027296a224248.jpg" style="margin-right: 10px;" /> The first phase of the G7 and EU ban on imports of Russian diamonds has come into effect <br /><a href="https://www.rt.com/business/589994-russian-diamond-ban-g7-eu/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin was right about economy in 2023 – ex-Austrian FM
 - [https://www.rt.com/russia/589993-putin-right-economy-russia-germany/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589993-putin-right-economy-russia-germany/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T08:38:01+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659271fe85f5400497451052.jpg" style="margin-right: 10px;" /> Vladimir Putin correctly predicted in 2023 that Russia’s economy would overtake Germany’s, an ex-Austrian foreign minister has said <br /><a href="https://www.rt.com/russia/589993-putin-right-economy-russia-germany/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Last UN troops leave African country after decade-long presence
 - [https://www.rt.com/africa/589992-last-un-troops-leave-mali/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/589992-last-un-troops-leave-mali/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T05:55:44+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65923f2f20302721da3550a2.jpeg" style="margin-right: 10px;" /> The UN has finished withdrawing its peacekeeping force from Mali <br /><a href="https://www.rt.com/africa/589992-last-un-troops-leave-mali/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Frozen fortune: Where is Russia’s $300 billion?
 - [https://www.rt.com/business/589874-russian-assets-frozen-west/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589874-russian-assets-frozen-west/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T05:06:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65911cf585f54038096e8ff9.jpg" style="margin-right: 10px;" /> Moscow has warned of a tit-for-tat response to the seizure of the country’s central bank assets by the West <br /><a href="https://www.rt.com/business/589874-russian-assets-frozen-west/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Eurozone economy faces bleak 2024 – FT
 - [https://www.rt.com/business/589757-eurozone-economy-low-growth-inflation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589757-eurozone-economy-low-growth-inflation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T05:06:21+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/658c225720302709cc19baad.jpg" style="margin-right: 10px;" /> Analysts expect the Eurozone to see only modest growth in 2024 despite wages rising faster than inflation for the first time in three years <br /><a href="https://www.rt.com/business/589757-eurozone-economy-low-growth-inflation/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israeli minister makes case for depopulation of Gaza
 - [https://www.rt.com/news/589991-smotrich-depopulate-gaza-plan/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/589991-smotrich-depopulate-gaza-plan/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T02:50:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659227c285f5406866414966.jpg" style="margin-right: 10px;" /> Israeli Finance Minister Bezalel Smotrich has suggested that Arabs should be encouraged to leave Gaza for good <br /><a href="https://www.rt.com/news/589991-smotrich-depopulate-gaza-plan/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Panda unpacks New Year gifts in Moscow Zoo (VIDEO)
 - [https://www.rt.com/russia/589990-moscow-zoo-panda-unpacks-gifts/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/589990-moscow-zoo-panda-unpacks-gifts/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-01T00:42:02+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/6591ffa585f54071890e7667.jpeg" style="margin-right: 10px;" /> The Moscow zoo has released a video of its giant panda inspecting presents before New Year’s Day <br /><a href="https://www.rt.com/russia/589990-moscow-zoo-panda-unpacks-gifts/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

