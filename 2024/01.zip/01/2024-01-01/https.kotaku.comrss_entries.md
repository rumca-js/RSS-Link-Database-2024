# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## Tips For 2023's Biggest Games And What To Watch Out For In Early 2024
 - [https://kotaku.com/tips-for-2023s-biggest-games-and-what-to-watch-out-for-1851129067](https://kotaku.com/tips-for-2023s-biggest-games-and-what-to-watch-out-for-1851129067)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-01T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/44edef0470fc9f5ee6d702f76fc63e46.jpg" /><p>Maybe you finally got Baldur’s Gate 3 this past week after pining for it for months and want some help tackling its tactical battles, or maybe you’re more interested in looking ahead to what early 2024 has to offer. Whatever the case, our roundup of tips and informative posts likely has something for you.</p><p><a href="https://kotaku.com/tips-for-2023s-biggest-games-and-what-to-watch-out-for-1851129067">Read more...</a></p>

