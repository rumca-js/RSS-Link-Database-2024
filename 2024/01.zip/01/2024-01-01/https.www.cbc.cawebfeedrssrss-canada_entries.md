# Source:CBC | Canada News, URL:https://www.cbc.ca/webfeed/rss/rss-canada, language:en

## Why more Canadians are delaying parenthood by freezing their eggs
 - [https://www.cbc.ca/news/canada/british-columbia/canadians-delaying-parenthood-egg-freezing-1.7067522?cmp=rss](https://www.cbc.ca/news/canada/british-columbia/canadians-delaying-parenthood-egg-freezing-1.7067522?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-01-01T13:00:00+00:00

<img alt="Medical worker is freezing eggs" height="349" src="https://i.cbc.ca/1.7067535.1703286733!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/egg-freezing.jpg" title="A lab technician is freezing human eggs, a procedure which can help delay parenthood until people are ready to have a child. " width="620" /><p>Data shows egg freezing treatments in Canada have soared in the last decade. For some, freezing their eggs helps buy time before they can find a partner. For others, it keeps open the option to reconsider parenthood in the future.</p>

## A Glace Bay man knocked on a famous photographer's door. It led him to a whole new world
 - [https://www.cbc.ca/news/canada/nova-scotia/robert-frank-famous-photographer-brian-graham-friend-book-1.7049508?cmp=rss](https://www.cbc.ca/news/canada/nova-scotia/robert-frank-famous-photographer-brian-graham-friend-book-1.7049508?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-01-01T05:00:00+00:00

<img alt="A man (right) is seen sitting down with his gaze towards the floor. He wears a t-shirt and has curly hair. On his left, is another man sitting, but facing the opposite direction. This man has long hair and a moustache. The image has been defaced by scratches on the negative, which appear throughout the frame." height="349" src="https://i.cbc.ca/1.7053409.1702055657!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/brian-graham-and-robert-frank.jpg" title="A self-portrait Brian Graham (left) took with Robert Frank that’s included in his new book. Frank wasn’t happy with it, so he later scratched the negative" width="620" /><p>Brian Graham’s new book, Goin’ Down the Road with Robert Frank, documents their 40-year-long friendship and unlikely working relationship, which began in Mabou, N.S., and continued in New York City after Frank sent Graham a postcard in the mail.</p>

## Teen who died in Ottawa river was 'going to do good things,' ski coach says
 - [https://www.cbc.ca/news/canada/ottawa/riley-cotter-teen-rideau-river-rememberance-friends-family-december-2023-1.7071861?cmp=rss](https://www.cbc.ca/news/canada/ottawa/riley-cotter-teen-rideau-river-rememberance-friends-family-december-2023-1.7071861?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-01-01T04:00:00+00:00

<img alt="A split shot of a skier racing on a course at left, and a front-facing picture of that same skier without his visor on at the right." height="349" src="https://i.cbc.ca/1.7071960.1704054296!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/riley-cotter-skier-teen-rideau-river-drowning-tragedy-ice-ottawa.jpg" title="Riley Cotter was one of two Ottawa teens who died after falling into the Rideau River on Dec. 27, 2023. The 17-year-old student at John McCrae Secondary School was a promising competitive skier, according to his coach." width="620" /><p>Riley Cotter, the 17-year-old who died in the Rideau River in south Ottawa last week alongside another teen, is being remembered as a skilled, promising athlete whose passing has shaken members of the competitive skiing community.</p>

