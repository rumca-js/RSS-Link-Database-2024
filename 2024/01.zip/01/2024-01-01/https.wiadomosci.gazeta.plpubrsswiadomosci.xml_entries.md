# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Kwaśniewski o otoczeniu Dudy: MĂłwią mu, że czas Kaczyńskiego zbliża się do końca
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554534,kwasniewski-o-otoczeniu-dudy-mowia-mu-ze-czas-kaczynskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554534,kwasniewski-o-otoczeniu-dudy-mowia-mu-ze-czas-kaczynskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T21:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b9/23/1d/z30554553M,Andrzej-Duda.jpg" vspace="2" />Andrzej Duda po zakończeniu prezydentury zawalczy o przywĂłdztwo na prawicy - uważa były prezydent Aleksander Kwaśniewski. Jak mĂłwił polityk w Polsat News, Duda "musi pokazać swoją twardość, musi pokazać się dobrze wobec wyborcĂłw PiS-owskich".

## Mroźne prognozy na wtorek to zaledwie preludium. "SpĂłjrzcie na sobotę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554497,synoptycy-prognoza-na-wtorek-do-dopiero-preludium-spojrzcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554497,synoptycy-prognoza-na-wtorek-do-dopiero-preludium-spojrzcie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T20:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/23/1d/z30554513M,Zdjecie-ilustracyjne.jpg" vspace="2" />We wtorkowy poranek temperatura odczuwalna w Suwałkach może spaść nawet do -10 stopni. Jak zapowiadają jednak synoptycy IMGW, to dopiero wstęp do tego, co nadejdzie w kolejnych dniach. Sobotnie prognozy wskazują na jeszcze większe ochłodzenie.

## Japonia. Pierwsze ofiary śmiertelne trzęsienia ziemi. Są też ranni
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554494,japonia-pierwsze-ofiary-smiertelne-trzesienia-ziemi-sa-tez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554494,japonia-pierwsze-ofiary-smiertelne-trzesienia-ziemi-sa-tez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T20:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/32/23/1d/z30553650M,Trzesienie-ziemi-w-Japonii--zdjecie-ilustracyjne-.jpg" vspace="2" />W wyniku trzęsienia ziemi w Japonii zginęły 4 osoby. Poinformowała o tym agencja informacyjna Kyodo, powołując się na władze prefektury Ishikawa. Są też ranni. To głĂłwnie osoby, ktĂłre zostały uderzone przez spadające przedmioty. Odnotowano wiele złamań.

## Mastalerek wietrzy spisek ws. afery po słowach Pietrzaka. "Czy ktoś uwierzy, że to o niego tutaj chodzi?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554464,mastalerek-wietrzy-spisek-ws-afery-po-slowach-pietrzaka-czy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554464,mastalerek-wietrzy-spisek-ws-afery-po-slowach-pietrzaka-czy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T19:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6a/23/1d/z30554474M,Marcin-Mastalerek.jpg" vspace="2" />- Prezydentowi się te słowa nie podobały. Był nimi oburzony - tak głośną niedzielną wypowiedź satyryka Jana Pietrzaka skomentował w TV Republika szef Gabinetu Prezydenta RP Marcin Mastalerek. - Jeśli minister sprawiedliwości zajmuje się wypowiedzią publicysty i satyryka, to ja się zaczynam zastanawiać, czy chodzi mu właśnie o publicystę i satyryka, czy o gigantyczny sukces Telewizji Republika - dodał.

## Rosjanie zbierają w Ukrainie podpisy pod kandydaturą Putina. Ale coś im nie idzie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554358,rosjanie-zbieraja-w-ukrainie-podpisy-pod-kandydatura-putina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554358,rosjanie-zbieraja-w-ukrainie-podpisy-pod-kandydatura-putina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T19:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4c/23/1d/z30554444M,Wladimir-Putin.jpg" vspace="2" />Rosjanie zbierają na okupowanych ukraińskich terenach podpisy popierające kandydaturę Władimira Putina w tegorocznych wyborach prezydenckich - podało w poniedziałek Centrum Narodowego Oporu. Z informacji podanych przez UkraińcĂłw wynika, że akcja Rosjan nie okazała się sukcesem. Zaapelowano, by "w dalszym ciągu ignorować inicjatywy okupantĂłw i nie brać udziału w "wyborach".

## Izrael. Sąd najwyższy uchylił kontrowersyjne prawo Netanjahu. "Nieracjonalne"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554429,izrael-sad-najwyzszy-uchylil-kontrowersyjne-prawo-netanjahu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554429,izrael-sad-najwyzszy-uchylil-kontrowersyjne-prawo-netanjahu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T18:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/50/23/1d/z30554448M,Binjamin-Netanjahu.jpg" vspace="2" />Sąd Najwyższy Izraela odrzucił zmiany w sądownictwie. Chodzi o przepisy uchwalone w lipcu 2023 roku ograniczające uprawnienia Sądu Najwyższego. Wcześniej mĂłgł on uchylać decyzje rządu, gdy doszedł do wniosku, że są one "nieracjonalne", czyli skupiają się na interesach partii politycznych, a nie uwzględniają dobra społecznego. Przepisy zostały odrzucone głosami ośmiu spośrĂłd piętnastu sędziĂłw.

## Duda w krĂłtkim nagraniu podsumował swĂłj rok. Niechcący (?) ujawnił, co czyta
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554274,duda-w-krotkim-nagraniu-podsumowal-swoj-rok-niechcacy-ujawnil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554274,duda-w-krotkim-nagraniu-podsumowal-swoj-rok-niechcacy-ujawnil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T18:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c9/23/1d/z30554313M,Andrzej-Duda.jpg" vspace="2" />- Nie zwalniamy tempa! Nadal będę z determinacją zabiegał o polskie sprawy w Europie i na świecie, zwłaszcza jeśli chodzi o bezpieczeństwo - zapewnił prezydent Andrzej Duda w nagraniu podsumowującym swoje działania w kontekście polityki zagranicznej. W pewnym momencie na krĂłtkim filmie można zobaczyć, jakie pismo czyta obecnie prezydent.

## Skandaliczne słowa Jana Pietrzaka. Muzeum Auschwitz reaguje: Przejaw moralnego zepsucia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554185,skandaliczne-slowa-jana-pietrzaka-muzeum-auschwitz-reaguje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554185,skandaliczne-slowa-jana-pietrzaka-muzeum-auschwitz-reaguje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T16:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/58/c6/1c/z30172760M,Auschwitz-Birkenau.jpg" vspace="2" />"Instrumentalizacja losĂłw ludzi, ktĂłrzy ginęli w niemieckich obozach, w nikczemnej retoryce antymigracyjnej to haniebny i zatrważający przejaw moralnego oraz intelektualnego zepsucia" - czytamy w oświadczeniu opublikowanym przez Muzeum Auschwitz. Jest to reakcja na skandaliczne słowa Jana Pietrzaka, ktĂłre padły na antenie Telewizji Republika.

## Sześciolatek wpadł w panikę. Jego matka leżała na ziemi kompletnie pijana podczas imprezy plenerowej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554051,szesciolatek-wpadl-w-panike-jego-matka-lezala-na-ziemi-kompletnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554051,szesciolatek-wpadl-w-panike-jego-matka-lezala-na-ziemi-kompletnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T15:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/23/1d/z30554087M,Policjanci-zaopiekowali-sie-przerazonym-chlopcem--.jpg" vspace="2" />Przerażony i zmarznięty chłopiec przebywał z matką podczas sylwestrowej imprezy plenerowej w Chorzowie. Kompletnie pijana 39-latka leżała na ziemi bez kontaktu. "Maluch był kompletnie przerażony zaistniałą sytuacją, (...) wpadł w panikę" - przytacza policja.

## Ozdoba zapewnia, że za rządĂłw PiS walczył o pluralizm w Polskim Radiu. Walczył, ale o coś innego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554011,ozdoba-zapewnia-ze-walczyl-o-pluralizm-w-polskim-radiu-walczyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554011,ozdoba-zapewnia-ze-walczyl-o-pluralizm-w-polskim-radiu-walczyl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T15:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/23/1d/z30554103M,Jacek-Ozdoba.jpg" vspace="2" />Poseł Suwerennej Polski Jacek Ozdoba przypomniał w Radiu ZET, że jeszcze za rządĂłw Prawa i Sprawiedliwości wysłał skargę do KRRiT na brak pluralizmu w Polskim Radiu. - Widzę, że pana zaskoczyłem! - stwierdził, zwracając się do prowadzącego. W rzeczywistości celem skargi było zwiększenie obecności politykĂłw ugrupowania Ozdoby, ktĂłrzy do stacji PR byli zapraszani, w porĂłwnaniu do PiS-u, wyjątkowo rzadko.

## Skutki trzęsienia ziemi w Japonii. Ewakuacja mieszkańcĂłw, zawalone budynki, zerwane linie elektryczne
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554050,skutki-trzesienia-ziemi-w-japonii-ewakuacja-mieszkancow-zawalone.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554050,skutki-trzesienia-ziemi-w-japonii-ewakuacja-mieszkancow-zawalone.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T15:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d1/23/1d/z30554065M,JAPAN-QUAKE-.jpg" vspace="2" />Ponad 3 tysiące osĂłb ewakuowanych, zawalone domy, przerwane linie wodociągowe i elektryczne - to wstępne podsumowanie skutkĂłw trzęsienia ziemi o magnitudzie 7.4, do ktĂłrego doszło w prefekturze Ishikawa w zachodniej Japonii.

## Jan Pietrzak i skandaliczna wypowiedź o imigrantach. Jest reakcja Bodnara
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554012,jan-pietrzak-i-wypowiedz-o-imigrantach-jest-reakcja-bodnara.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30554012,jan-pietrzak-i-wypowiedz-o-imigrantach-jest-reakcja-bodnara.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T14:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ad/23/1d/z30554029M,Jan-Pietrzak.jpg" vspace="2" />Minister sprawiedliwości, prokurator generalny Adam Bodnar zwrĂłcił się do prokuratora krajowego Dariusza Barskiego o wszczęcie śledztwa ws. niedzielnej wypowiedzi Jana Pietrzaka. Piosenkarz mĂłwił w TV Republika, że "mamy baraki dla imigrantĂłw, w Auschwitz, w Majdanku, w Treblince".

## Tragedia w Miłocicach. Śmiertelny cios nożem. Nie żyje 30-letni mężczyzna
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553968,tragedia-w-milocicach-smiertelny-cios-nozem-nie-zyje-30-letni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553968,tragedia-w-milocicach-smiertelny-cios-nozem-nie-zyje-30-letni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T14:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/94/23/1d/z30554004M,Zdjecie-ilustracyjne.jpg" vspace="2" />Trwa wyjaśnianie okoliczności tragedii, do ktĂłrej doszło w poniedziałek nad ranem w Miłocicach w woj. pomorskim. Jak podaje RMF FM, w trakcie rodzinnej awantury zginął 30-letni mężczyzna. Śmiertelny cios nożem miała zadać jego partnerka.

## 13-latek rozbił auto na słupie. Chłopak zabrał matce klucze, by jechać do swojej dziewczyny
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553916,13-latek-rozbil-auto-na-slupie-chlopiec-zabral-matce-klucze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553916,13-latek-rozbil-auto-na-slupie-chlopiec-zabral-matce-klucze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T14:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6e/23/1d/z30553966M,13-latek-rozbil-sie-na-slupie--Chcial-jechac-do-dz.jpg" vspace="2" />13-letni chłopiec zabrał matce klucze do samochodu bez jej wiedzy, by pojechać do dziewczyny. PodrĂłż zakończył jednak na słupie. Teraz sprawą zajmie się sąd rodzinny.

## Putin zapowiada wzmocnienie atakĂłw. "Sama Ukraina nie jest naszym wrogiem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30553879,putin-zapowiada-wzmocnienie-atakow-sama-ukraina-nie-jest-naszym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30553879,putin-zapowiada-wzmocnienie-atakow-sama-ukraina-nie-jest-naszym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T14:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cf/13/1d/z30488527M,Wladimir-Putin.jpg" vspace="2" />Prezydent Rosji nawiązał do ukraińskiego ataku na Biełgorod i zapowiedział zintensyfikowanie ostrzału. W czasie wizyty w szpitalu wojskowym mĂłwił rĂłwnież o głĂłwnym wrogu Moskwy. - Sama Ukraina nie jest naszym wrogiem - przekonywał.

## Nowy rząd powinien wypowiedzieć Konkordat z Kościołem? Polacy odpowiedzieli [SONDAŻ]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553784,nowy-rzad-powinien-wypowiedziec-konkordat-z-kosciolem-polacy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553784,nowy-rzad-powinien-wypowiedziec-konkordat-z-kosciolem-polacy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T13:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8b/cf/1c/z30210187M,Ksieza--zdjecie-ilustracyjne-.jpg" vspace="2" />Nowy rząd powinien wypowiedzieć dotychczasowy Konkordat z Kościołem i negocjować zasady na linii państwo - KościĂłł na nowo? Takie pytanie zostało zadane Polakom w najnowszym sondażu przeprowadzonym przez United Surveys. Prawie połowa PolakĂłw uważa, że zmiany faktycznie są potrzebne.

## Chwile grozy w Legnicy. Biegał z zakrwawionym nożem po klatce schodowej i dobijał się do mieszkań
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553791,chwile-grozy-w-legnicy-biegal-z-zakrwawionym-nozem-po-klatce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553791,chwile-grozy-w-legnicy-biegal-z-zakrwawionym-nozem-po-klatce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T13:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f0/23/1d/z30553840M,Atak-nozownika-w-Legnicy.jpg" vspace="2" />30-letni mieszkaniec Legnicy "wbiegł na dach budynku, gdzie przez balkon dostał się do jednego z mieszkań, a następnie wyszedł na klatkę schodową, gdzie prĂłbował dostać się do innych mieszkań" - podaje policja. Mężczyzna jest podejrzewany o zaatakowanie nożem dwĂłch osĂłb. Stan jednej z nich określany jest jako ciężki.

## Niespokojny sylwester w Zakopanem. Liczne awantury, bĂłjki turystĂłw i atak z użyciem noża
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553843,niespokojny-sylwester-w-zakopanem-liczne-awantury-bojki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553843,niespokojny-sylwester-w-zakopanem-liczne-awantury-bojki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T13:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/23/1d/z30553143M.jpg" vspace="2" />W czasie sylwestra w Zakopanem doszło do licznych awantur i bĂłjek z udziałem pijanych i agresywnych turystĂłw. Jeden z mężczyzn został raniony nożem i trafił do szpitala. - W powiecie tatrzańskim od 18.00 do 4.00 odnotowaliśmy aż 83 rĂłżnego typu interwencje - przekazał asp. sztab. Roman Wieczorek w rozmowie z "Tygodnikiem Podhalańskim".

## Skandaliczne słowa Jana Pietrzaka w Telewizji Republika. Chce wysyłać migrantĂłw do "barakĂłw Auschwitz"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553767,skandaliczne-slowa-jana-pietrzaka-w-telewizji-republika-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553767,skandaliczne-slowa-jana-pietrzaka-w-telewizji-republika-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T11:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b3/23/1d/z30553779M,Jan-Pietrzak.jpg" vspace="2" />Jan Pietrzak na antenie Telewizji Republika w skandalicznych słowach opowiadał na wizji o unijnej polityce dotyczącej migrantĂłw. - Mamy baraki dla imigrantĂłw, w Auschwitz, w Majdanku, w Treblince. Mamy dużo barakĂłw zbudowanych przez NiemcĂłw - mĂłwił publicysta.

## Premier o zmarłej Iwonie Śledzińskiej-Katarasińskiej: Nie byłoby tego zwycięstwa bez Ciebie, Iwonko
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553696,premier-o-zmarlej-iwonie-sledzinskiej-katarasinskiej-nie-byloby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553696,premier-o-zmarlej-iwonie-sledzinskiej-katarasinskiej-nie-byloby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T11:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/35/21/1d/z30543925M,Donald-Tusk.jpg" vspace="2" />"Nie byłoby tego zwycięstwa bez Ciebie, Iwonko" - napisał premier Donald Tusk w mediach społecznościowych, odnosząc się do śmierci byłej posłanki Platformy Obywatelskiej Iwony Śledzińskiej-Katarasińskiej.

## Koniec z Ministerstwem Edukacji i Nauki. Wraca podział na dwa odrębne resorty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553667,koniec-z-ministerstwem-edukacji-i-nauki-wraca-podzial-na-dwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553667,koniec-z-ministerstwem-edukacji-i-nauki-wraca-podzial-na-dwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T10:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/61/a9/1c/z30056289M,Ministerstwo-Edukacji-i-Nauki.jpg" vspace="2" />Ministerstwo Edukacji i Nauki przestało istnieć po dwĂłch latach funkcjonowania. Wraz z początkiem nowego roku przywrĂłcony został podział na dwa odrębne resorty - Ministerstwo Edukacji Narodowej oraz Ministerstwo Nauki i Szkolnictwa Wyższego.

## Niespokojny sylwester w Lublinie. Poszukiwany 30-latek groził wysadzeniem bloku. Wkroczyli negocjatorzy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553636,niespokojny-sylwester-w-lublinie-poszukiwany-30-latek-grozil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553636,niespokojny-sylwester-w-lublinie-poszukiwany-30-latek-grozil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T10:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/40/23/1d/z30553664M,Niespokojny-sylwester-w-Lublinie--Mezczyzna-grozil.jpg" vspace="2" />Sylwester mieszkańcĂłw jednego z blokĂłw w Lublinie przebiegł wyjątkowo niespokojnie. Po południu poszukiwany mężczyzna zabarykadował się w jednym z mieszkań i groził wysadzeniem budynku. Do sprawy zostali zaangażowani negocjatorzy oraz kontrterroryści.

## Jarosław Kaczyński spędził Sylwestra w siedzibie TVP. "Jesteśmy w trakcie walki"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553612,jaroslaw-kaczynski-spedzil-sylwestra-w-siedzibie-tvp-jestesmy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553612,jaroslaw-kaczynski-spedzil-sylwestra-w-siedzibie-tvp-jestesmy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T09:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/92/1f/1d/z30535826M,Jaroslaw-Kaczynski.jpg" vspace="2" />- Jesteśmy w trakcie walki. Nie jest to moment szczegĂłlnie łatwy, ale ta walka w ogĂłle z natury trudna, bo działamy w konfrontacji z przeciwnikiem, ktĂłry po prostu nie przestrzega żadnych reguł - mĂłwił Jarosław Kaczyński w rozmowie z portalem wPolityce.pl. Prezes PiS spędził Sylwestra w siedzibie TVP.

## Noworoczne postanowienia PolakĂłw. Co chcemy zmienić? Schudnąć, czytać, stronić od polityki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553605,noworoczne-postanowienia-polakow-co-chcemy-zmienic-schudnac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553605,noworoczne-postanowienia-polakow-co-chcemy-zmienic-schudnac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T09:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/18/83/1a/z27799576M,Silownia--zdjecie-ilustracyjne-.jpg" vspace="2" />Wraz z nadejściem nowego roku wiele osĂłb postanawia wprowadzić w swoje życie zmiany. Według najnowszego sondażu w 2024 roku zamierza zrobić je co czwarty Polak. Na czym zależy nam najbardziej?

## Nie żyje Iwona Śledzińska-Katarasińska. Była posłanką PO
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553595,nie-zyje-iwona-sledzinska-katarasinska-byla-poslanka-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553595,nie-zyje-iwona-sledzinska-katarasinska-byla-poslanka-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T08:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e6/23/1d/z30553574M,Iwona-Sledzinska-Katarasinska.jpg" vspace="2" />Nad ranem 1 stycznia zmarła Iwona Śledzińska-Katarasińska, była posłanka Platformy Obywatelskiej - poinformowała marszałek Senatu, Małgorzata Kidawa-Błońska.

## Wielki powrĂłt zimy. IMGW ostrzega przed załamaniem pogody. Pojawią się ulewy i śnieżyce
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553564,wielki-powrot-zimy-imgw-ostrzega-przed-zalamaniem-pogody-pojawia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30553564,wielki-powrot-zimy-imgw-ostrzega-przed-zalamaniem-pogody-pojawia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T08:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f8/23/1d/z30553592M,Zima-wroci-do-Polski.jpg" vspace="2" />Nowy rok przyniesie załamanie pogody. W pierwszym dniu 2024 roku w Polsce dominować będzie zachmurzenie, ulewy i śnieżyce, a już niedługo zrobi się naprawdę mroźno.

## Komentarze po orędziu Andrzeja Dudy. Sienkiewicz kpiąco: "Dziękuję za zaufanie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553549,komentarze-po-oredziu-andrzeja-dudy-sienkiewicz-kpiaco-dziekuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30553549,komentarze-po-oredziu-andrzeja-dudy-sienkiewicz-kpiaco-dziekuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T08:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0b/23/1d/z30552843M,Andrzej-Duda.jpg" vspace="2" />Politycy, publicyści i dziennikarze komentują noworoczne prezydenckie orędzie. Do komentujących dołączył minister kultury. Bartłomiej Sienkiewicz przesłał prezydentowi "podziękowania za zaufanie".

## Japonia. Silne trzęsienie ziemi. Władze ostrzegają przed pięciometrowymi falami tsunami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30553581,japonia-silne-trzesienie-ziemi-wladze-ostrzegaja-przed-pieciometrowymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30553581,japonia-silne-trzesienie-ziemi-wladze-ostrzegaja-przed-pieciometrowymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T08:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/58/82/1b/z28845912M,Pilne.jpg" vspace="2" />W pierwszy dzień nowego roku 2024 Japonię nawiedziło trzęsienie ziemi o magnitudzie 7,4. Na razie nie ma informacji o ewentualnych ofiarach ani stratach materialnych.

## Rosja. Noworoczne orędzie Putina inne niż zwykle. "Nie ma siły, ktĂłra mogłaby nas zatrzymać"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30553507,rosja-noworoczne-oredzie-putina-inne-niz-zwykle-nie-ma-sily.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30553507,rosja-noworoczne-oredzie-putina-inne-niz-zwykle-nie-ma-sily.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T07:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a6/23/1d/z30553510M,Wladimir-Putin-w-oredziu.jpg" vspace="2" />Prezydent Rosji Władimir Putin wygłosił orędzie, ktĂłre jaskrawo kontrastuje z zeszłorocznym przemĂłwieniem. Rosyjski przywĂłdca chwalił swoich żołnierzy za odwagę, ale nie odniĂłsł się do sytuacji na froncie i całkowicie pominął "specjalną operację wojskową". Tymczasem Wołodymyr Zełenski w noworocznym przemĂłwieniu skupił się na wojnie, lecz nie skomentował impasu na linii frontu, z ktĂłrym ukraińskie wojska mierzą się w ostatnich tygodniach.

## Nocny atak na LwĂłw. Rosjanie zaatakowali dronami Shahed
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30553492,nocny-atak-na-lwow-rosjanie-zaatakowali-dronami-shahed.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30553492,nocny-atak-na-lwow-rosjanie-zaatakowali-dronami-shahed.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T06:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9d/23/1d/z30553501M,Atak-dronow-Shahid-na-Lwow.jpg" vspace="2" />Rosjanie zaatakowali w nocy LwĂłw dronami typu Shahed. Ostatniej doby Rosjanie wystrzelili w sumie 13 rakiet manewrujących i przeprowadzili 127 nalotĂłw oraz 181 ostrzałĂłw z systemĂłw artyleryjskich.

## Ekspert: Polityka niemiecka wobec muzułmanĂłw zawiodła. "Kluczowe są meczety"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30553498,ekspert-polityka-niemiecka-wobec-muzulmanow-zawiodla-kluczowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30553498,ekspert-polityka-niemiecka-wobec-muzulmanow-zawiodla-kluczowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T06:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9f/23/1d/z30553503M,Islam--zdjecie-ilustracyjne-.jpg" vspace="2" />Murat Kayman skrytykował podejście do islamu w Niemczech. "Polityka wobec islamu w ostatnich 10-15 latach poniosła klęskę" - powiedział w niedzielę dziennikowi "Die Welt".

## Horoskop dzienny - poniedziałek 1 stycznia [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30425408,horoskop-dzienny-poniedzialek-1-stycznia-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30425408,horoskop-dzienny-poniedzialek-1-stycznia-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T04:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8d/ec/1c/z30327949M,Horoskop-dzienny--zdjecie-ilustracyjne-.jpg" vspace="2" />Horoskop dzienny na poniedziałek 1 stycznia 2024 roku. Raki wejdą w nowy rok z zupełnie nową energią, czym przyciągną do siebie mnĂłstwo dobrego. Na nieco mniej szczęśliwy czas muszą przygotować się Ryby. Co przydarzy się pozostałym znakom zodiaku? Już dziś przygotuj się na to, co niesie ci przyszłość.

## Dni wolne w 2024 roku. Zaplanuj urlop na te dni, aby cieszyć się dłuższym wolnym [KALENDARZ]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30474198,dni-wolne-w-2024-roku-zaplanuj-urlop-na-te-dni-aby-cieszyc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30474198,dni-wolne-w-2024-roku-zaplanuj-urlop-na-te-dni-aby-cieszyc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T04:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/05/10/1d/z30474501M,Kalendarz--zdjecie-ilustracyjne-.jpg" vspace="2" />Wraz z rozpoczęciem się nowego roku, zaczyna się wstępne planowanie urlopu. Podpowiadamy, jak wypadają dni wolne w 2024 roku. Kiedy wypadają święta, ile czeka na długich weekendĂłw?

## Horoskop dzienny - poniedziałek 1 stycznia 2024 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30552158,horoskop-dzienny-poniedzialek-1-stycznia-2024-baran-byk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30552158,horoskop-dzienny-poniedzialek-1-stycznia-2024-baran-byk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-01T04:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/ba/1c/z30124487M,Horoskop-dzienny---poniedzialek.jpg" vspace="2" />Horoskop dzienny - poniedziałek 1 stycznia 2024. Pierwszy dzień nowego roku będzie zaskakujący dla BaranĂłw, BykĂłw i WodnikĂłw. Wagi i Koziorożce będą pod wrażeniem tego, co stanie się tego dnia. Co czeka pozostałe znaki zodiaku?

