# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## The Verbiage of the Next Generation
 - [https://www.youtube.com/watch?v=zUM9TH-SJPk](https://www.youtube.com/watch?v=zUM9TH-SJPk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-01-01T20:00:21+00:00



## Man Uses Traffic Hack
 - [https://www.youtube.com/watch?v=P3ziATX2o94](https://www.youtube.com/watch?v=P3ziATX2o94)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2024-01-01T18:00:16+00:00



