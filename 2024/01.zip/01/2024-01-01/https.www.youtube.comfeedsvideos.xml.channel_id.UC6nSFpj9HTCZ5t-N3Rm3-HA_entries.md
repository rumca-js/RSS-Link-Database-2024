# Source:Vsauce, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA, language:en-US

## Okay, Here's The 'Reindeer'
 - [https://www.youtube.com/watch?v=ynGb9FcH5ME](https://www.youtube.com/watch?v=ynGb9FcH5ME)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA
 - date published: 2024-01-01T14:41:41+00:00



