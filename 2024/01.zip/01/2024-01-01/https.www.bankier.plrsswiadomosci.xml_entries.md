# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Kosmiczne kursy złotego w Google. Minister finansów reaguje
 - [https://www.bankier.pl/wiadomosc/Kosmiczne-kursy-zlotego-w-Google-Minister-finansow-reaguje-8672049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kosmiczne-kursy-zlotego-w-Google-Minister-finansow-reaguje-8672049.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T23:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/f8be50974dda10-948-568-54-0-1269-761.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Noworoczny wieczór, kiedy rynki finansowe znajdują się jeszcze w uśpieniu, nie powinien wzbudzać sensacji wśród obserwatorów tematyki rynków i gospodarki. 1 stycznia 2024 roku okazał się jednak wyjątkiem, zagregował nawet minister finansów Andrzej Domański. Wszystko przez sensacyjnie wysokie kursy złotego na rynku forex pokazywane przez wyszukiwarkę Google.</p>

## Putin zapowiedział zintensyfikowanie ataków na Ukrainę
 - [https://www.bankier.pl/wiadomosc/Putin-zapowiedzial-zintensyfikowanie-atakow-na-Ukraine-8672028.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Putin-zapowiedzial-zintensyfikowanie-atakow-na-Ukraine-8672028.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T18:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/b/36fb8440de51a9-948-568-1210-340-2790-1673.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosyjski dyktator Władimir Putin zapowiedział w poniedziałek zintensyfikowanie ataków na Ukrainę - podała BBC. W trakcie wizyty w szpitalu wojskowym w Moskwie Putin oświadczył, że wojsko będzie nadal atakować ukraińskie "instalacje wojskowe".</p>

## Nie będzie reformy sądownictwa w Izraelu. Sąd Najwyższy uciął marzenia premiera Netanjahu
 - [https://www.bankier.pl/wiadomosc/Nie-bedzie-reformy-sadownictwa-w-Izraelu-Sad-Najwyzszy-ucial-marzenia-premiera-Netanjahu-8672026.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-bedzie-reformy-sadownictwa-w-Izraelu-Sad-Najwyzszy-ucial-marzenia-premiera-Netanjahu-8672026.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T17:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/8/2656017b3a32b5-948-568-15-30-3056-1833.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ta ustawa zachwiałaby trójpodziałem władzy w Izraelu. Sąd Najwyższy uchylił kluczowe rozwiązanie dla reformy sądownictwa, która spowodowało wielomiesięczne powszechne protesty. Ustawa odbierała Sądowi Najwyższemu prawo do uchylania decyzji rządu, jeśli zostaną uznane za "nieracjonalne", tj. nieproporcjonalnie skoncentrowane na interesie politycznym bez wystarczającego uwzględnienia interesu publicznego.</p>

## Czechy przymierzają się do euro. Prezydent: Trzeba podjąć konkretne kroki
 - [https://www.bankier.pl/wiadomosc/Czechy-przymierzaja-sie-do-euro-Prezydent-Trzeba-podjac-konkretne-kroki-8672019.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czechy-przymierzaja-sie-do-euro-Prezydent-Trzeba-podjac-konkretne-kroki-8672019.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T16:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/f/b4f8b73843d94c-948-568-0-82-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Czech Petr Pavel stwierdził w orędziu noworocznym, że pora zacząć podejmować konkretne kroki, które doprowadzą do przyjęcia euro. Pavel wspomniał też tragedię, do której doszło przed świętami na Uniwersytecie Karola w Pradze, i apelował o przezwyciężenie strachu.</p>

## Książę Harry i Meghan Markle. Ze szczytów w odmęty, czyli jak unicestwić miliardową markę
 - [https://www.bankier.pl/wiadomosc/Ksiaze-Harry-i-Meghan-Markle-Ze-szczytow-w-odmety-czyli-jak-unicestwic-miliardowa-marke-8667059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ksiaze-Harry-i-Meghan-Markle-Ze-szczytow-w-odmety-czyli-jak-unicestwic-miliardowa-marke-8667059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T15:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/03cb23bd64a8fc-948-568-0-87-2688-1612.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do kurczącej się listy tytułów, którymi mogą się posługiwać (w 2020 roku wykreślono np. Jego/Jej Wysokość), można jeden dopisać, ale akurat taki, którego by posiadać nie chcieli. Książę Harry i Meghan Markle zostali uznani za największych nieudaczników 2023 roku w Hollywood. To oficjalny koniec marki pary książęcej Sussex?</p>

## Jan Pietrzak skandalicznie o imigrantach w TV Republika. Sprawą zajął się resort sprawiedliwości
 - [https://www.bankier.pl/wiadomosc/Jan-Pietrzak-skandalicznie-o-imigrantach-w-TV-Republika-Sprawa-zajal-sie-resort-sprawiedliwosci-8672006.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jan-Pietrzak-skandalicznie-o-imigrantach-w-TV-Republika-Sprawa-zajal-sie-resort-sprawiedliwosci-8672006.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T14:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/237b31ea472097-948-568-0-20-1477-886.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W TV Republika Pietrzak powiedział m.in., że "mamy baraki dla imigrantów: w Auschwitz, Majdanku, Treblince, Stutthofie" w kontekście nielegalnych imigrantów. Ośrodek Monitorowania Zachowań Rasistowskich i Ksenofobicznych złożył w poniedziałek zawiadomienie do prokuratury w związku z wypowiedzią satyryka Jana Pietrzaka, a Adam Bodnar poprosił Prokuratora Krajowego o zajęcie się sprawą wypowiedzi. </p>

## Coraz biedniejsza Hiszpania. Miliony mieszkańców nie stać na ogrzewanie
 - [https://www.bankier.pl/wiadomosc/Coraz-biedniejsza-Hiszpania-Miliony-mieszkancow-nie-stac-na-ogrzewanie-8672002.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-biedniejsza-Hiszpania-Miliony-mieszkancow-nie-stac-na-ogrzewanie-8672002.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T13:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/9ad0323db5b2b1-948-568-50-125-1916-1150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na szczęście dla Hiszpanów tegoroczna zima jest wyjątkowo ciepła. Już ponad 8 mln mieszkańców z 48-milionowego społeczeństwa skarży się bowiem na brak środków na ogrzewanie domów w związku z kryzysem energetycznym. </p>

## Bangladesz "ściga" noblistę. Zdaniem sądu złamał prawo pracy
 - [https://www.bankier.pl/wiadomosc/Bangladesz-sciga-nobliste-Zdaniem-sadu-zlamal-prawo-pracy-8671987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bangladesz-sciga-nobliste-Zdaniem-sadu-zlamal-prawo-pracy-8671987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T12:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/5/3a0a277a704ac6-948-568-0-116-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Laureat pokojowej Nagrody Nobla Muhammad Yunus został w poniedziałek uznany za winnego złamania prawa pracy w Bangladeszu - poinformował  prokurator agencję AFP. Zwolennicy skazanego uważają proces za umotywowany politycznie.</p>

## Nie żyje posłanka Iwona Śledzińska-Katarasińska
 - [https://www.bankier.pl/wiadomosc/Nie-zyje-poslanka-Iwona-Sledzinska-Katarasinska-8671971.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-zyje-poslanka-Iwona-Sledzinska-Katarasinska-8671971.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T11:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/2/deffc0a6b6d377-948-567-0-126-1080-647.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W poniedziałek w wieku 82 lat zmarła posłanka wielu kadencji Iwona Śledzińska-Katarasińska (PO). O jej śmierci poinformowała marszałek Senatu Małgorzata Kidawa-Błońska.</p>

## Niebezpieczny sylwester w Niemczech. Ponad 230 zatrzymań, kilkunastu rannych policjantów
 - [https://www.bankier.pl/wiadomosc/Niebezpieczny-sylwester-w-Niemczech-Ponad-230-zatrzyman-kilkunastu-rannych-policjantow-8671972.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niebezpieczny-sylwester-w-Niemczech-Ponad-230-zatrzyman-kilkunastu-rannych-policjantow-8671972.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T11:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/8c97828986843f-945-560-0-54-2719-1631.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 230 osób zostało zatrzymanych i około 15 policjantów odniosło obrażenia w noc sylwestrową w Berlinie – poinformowała w poniedziałek miejscowa policja na platformie X. Zatrzymano kolejnych podejrzanych o terroryzm w Kolonii. </p>

## Nałogowe palenie w domu może być formą przemocy
 - [https://www.bankier.pl/wiadomosc/Nalogowe-palenie-w-domu-moze-byc-forma-przemocy-8669879.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nalogowe-palenie-w-domu-moze-byc-forma-przemocy-8669879.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/4/0c56a997683f37-948-568-0-30-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Domownicy mają prawne możliwości ochrony swojego zdrowia i życia, jeśli nałogowy palacz odmawia wychodzenia na zewnątrz. Opieka społeczna może założyć mu Niebieską Kartę - przestrzega Prawo.pl.</p>

## Rok 2024 będzie kluczowym okresem w rozwoju sztucznej inteligencji
 - [https://www.bankier.pl/wiadomosc/Rok-2024-bedzie-kluczowym-okresem-w-rozwoju-sztucznej-inteligencji-8667153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rok-2024-bedzie-kluczowym-okresem-w-rozwoju-sztucznej-inteligencji-8667153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/5a3064c2e6707a-948-568-0-143-2495-1496.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nadchodzący rok będzie niezwykle ważnym okresem w rozwoju sztucznej inteligencji (AI). AI pokaże nowe możliwości i wyzwania, wykraczające poza technologię i obejmujące kwestie prawne, etyczne i społeczne; zaawansowane algorytmy osiągną nowy poziom możliwości, dostępności i skalowalności - przewiduje magazyn "Forbes".</p>

## GDDKiA się pochwaliła. W 2024 r. kierowcy przejadą całą trasą S61 Via Baltica
 - [https://www.bankier.pl/wiadomosc/GDDKiA-sie-pochwalila-W-2024-r-kierowcy-przejada-cala-trasa-S61-Via-Baltica-8671952.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/GDDKiA-sie-pochwalila-W-2024-r-kierowcy-przejada-cala-trasa-S61-Via-Baltica-8671952.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T09:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/7b5e80d145a82c-948-568-0-46-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na ukończenie czeka jeszcze obwodnica Łomży z nowym mostem na rzece Narew (Podlaskie) - zapowiada Generalna Dyrekcja Dróg Krajowych i Autostrad w raporcie podsumowującym inwestycje z 2023 r.</p>

## Leasing samochodu - nie zawsze można odstąpić od umowy. TSUE tłumaczy
 - [https://www.bankier.pl/wiadomosc/Leasing-samochodu-nie-zawsze-mozna-odstapic-od-umowy-TSUE-tlumaczy-8667865.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Leasing-samochodu-nie-zawsze-mozna-odstapic-od-umowy-TSUE-tlumaczy-8667865.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/d77a996d773685-948-568-0-260-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Konsumentowi, który zawiera umowę leasingu samochodu bez obowiązku jego wykupu, nie przysługuje prawo do odstąpienia od umowy; jednak konsument, który zawarł umowę o kredyt w celu nabycia samochodu, lecz nie został należycie poinformowany o swoich prawach i obowiązkach, może odstąpić od umowy w każdej chwili, dopóki nie zostaną mu przekazane pełne i dokładne informacje, o ile odstąpienie nastąpi przed całkowitym wykonaniem umowy - orzekł Trybunał Sprawiedliwości UE w Luksemburgu.</p>

## Największa sieć supermarketów w Holandii przestaje sprzedawać papierosy i inne wyroby tytoniowe
 - [https://www.bankier.pl/wiadomosc/Najwieksza-siec-supermarketow-w-Holandii-przestaje-sprzedawac-papierosy-i-inne-wyroby-tytoniowe-8670683.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najwieksza-siec-supermarketow-w-Holandii-przestaje-sprzedawac-papierosy-i-inne-wyroby-tytoniowe-8670683.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/00dfd03a8afa59-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Albert Heijn, największa sieć supermarketów w 
Holandii, wstrzymuje sprzedaż papierosów i innych wyrobów tytoniowych z 
końcem 2023 roku - poinformowała firma w komunikacie prasowym.</p>

## Ożywienie i optymizm na rynku pracy. Powrót na ścieżkę wzrostu w 2024 roku
 - [https://www.bankier.pl/wiadomosc/Ozywienie-i-optymizm-na-rynku-pracy-Powrot-na-sciezke-wzrostu-w-2024-roku-8670904.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ozywienie-i-optymizm-na-rynku-pracy-Powrot-na-sciezke-wzrostu-w-2024-roku-8670904.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/a/f0052ddfcc26bc-948-568-0-1020-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sytuacja na rynku pracy z punktu widzenia pracodawcy jest trudna i nie uniknie się presji płacowej, ale widać pewne ożywienie i optymizm - wskazali  eksperci w raporcie o rynku pracy. Ocenili, że 2024 zapowiada się jako rok powrotu na ścieżkę wzrostu.</p>

## Władza się zmienia, ale podatki ciągle rosną. 10 wyższych danin na 2024 rok
 - [https://www.bankier.pl/wiadomosc/Podwyzki-podatkow-w-2024-roku-Wladza-sie-zmienia-ale-daniny-ciagle-rosna-8670988.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podwyzki-podatkow-w-2024-roku-Wladza-sie-zmienia-ale-daniny-ciagle-rosna-8670988.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/a11ee0df6cad4a-945-567-105-87-3398-2039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rok temu rząd Mateusza Morawieckie zafundował nam 10
wyższych podatków. 12 miesięcy później
rząd Donalda Tuska funduje nam kolejne podwyżki. Nie ma to jak przewidywalność
i ciągłość władzy.</p>

## Prof. Mączyńska: Zmniejszamy dystans majątkowy do bogatych państw UE, ale jesteśmy bardziej zmęczeni
 - [https://www.bankier.pl/wiadomosc/Prof-Maczynska-Zmniejszamy-dystans-majatkowy-do-bogatych-panstw-UE-8671947.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prof-Maczynska-Zmniejszamy-dystans-majatkowy-do-bogatych-panstw-UE-8671947.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T08:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/1e24c92425f52b-945-560-38-0-3849-2309.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Cóż nam z bogactwa materialnego, jeżeli będziemy chorować lub umierać z powodu piekielnego gorąca? Po co materialne bogactwo, jeśli przypłacamy je notorycznym zmęczeniem, brakiem czasu na należyte relacje rodzinne, towarzyskie? - pytała rof. Elżbieta Mączyńska, ekonomistka z SGH, honorowa prezes PTE. Jej zdaniem, za paradoks można uznać to, że w erze robotyzacji i sztucznej inteligencji jesteśmy coraz bardziej zapracowani i zmęczeni.</p>

## Japonia wydała ostrzeżenie o tsunami po trzęsieniu ziemi
 - [https://www.bankier.pl/wiadomosc/Japonia-wydala-ostrzezenie-o-tsunami-po-trzesieniu-ziemi-8671936.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Japonia-wydala-ostrzezenie-o-tsunami-po-trzesieniu-ziemi-8671936.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T07:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/5/691a51787919ce-945-560-69-9-1781-1068.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />U północno-zachodnich wybrzeży Japonii doszło do trzęsienia ziemi o magnitudzie 7,6. Możliwe jest wystąpienie tsunami o wysokości 5 metrów - poinformowała publiczna stacja HNK.</p>

## Sylwestrowe ataki Rosji na Ukrainie. Zełenski obiecuje "spustoszenie"
 - [https://www.bankier.pl/wiadomosc/Sylwestrowe-ataki-Rosji-na-Ukrainie-Zelenski-obiecuje-spustoszenie-8671928.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sylwestrowe-ataki-Rosji-na-Ukrainie-Zelenski-obiecuje-spustoszenie-8671928.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T07:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/6/7c6bd5e55b59b8-948-568-98-484-3856-2313.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Siły rosyjskie użyły w noc sylwestrową rekordowej liczby dronów szturmowych, a także atakowały Ukrainę rakietami S-300, Ch-31P i Ch-59 – poinformowały Siły Powietrzne Ukrainy w poniedziałek. Nad Ukrainę nadleciało 90 dronów Shahed, zestrzelono 87 z nich.</p>

## Szefowa Parlamentu Europejskiego: Będziemy wspierać Ukrainę aż będzie wolna. Jak poradzi sobie z vetem Węgier?
 - [https://www.bankier.pl/wiadomosc/Szefowa-Parlamentu-Europejskiego-Bedziemy-wspierac-Ukraine-az-bedzie-wolna-Jak-poradzi-sobie-z-vetem-Wegier-8671913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szefowa-Parlamentu-Europejskiego-Bedziemy-wspierac-Ukraine-az-bedzie-wolna-Jak-poradzi-sobie-z-vetem-Wegier-8671913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T06:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/8/cd989b067f5ad7-948-568-0-56-3753-2251.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będziemy kontynuować wsparcie dla Ukrainy, dopóki znów nie będzie wolna. Polacy przyjęli miliony Ukraińców, którzy uciekli ze swojego kraju z powodu wojny. Europa nigdy tego nie zapomni - mówi w rozmowie z PAP przewodnicząca Parlamentu Europejskiego Roberta Metsola.</p>

## Co czeka przedsiębiorców w 2024 roku? Oto największe wyzwania dla firm
 - [https://www.bankier.pl/wiadomosc/Co-czeka-przedsiebiorcow-w-2024-roku-Oto-najwieksze-wyzwania-dla-firm-8665535.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Co-czeka-przedsiebiorcow-w-2024-roku-Oto-najwieksze-wyzwania-dla-firm-8665535.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T05:17:03.780477+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/dbe6b4d9674893-948-568-0-380-4205-2523.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przedsiębiorcy z optymizmem patrzą w przyszłość, choć miejsc pracy będzie mniej - wskazują eksperci Personnel Service. W 2024 r. wyzwaniami będą m.in. sztuczna inteligencja i automatyzacja oraz polityka migracyjna.</p>

## ChatGPT kłamie i oszukuje, gdy jest pod presją zarabiania pieniędzy
 - [https://www.bankier.pl/wiadomosc/ChatGPT-klamie-i-oszukuje-gdy-jest-pod-presja-zarabiania-pieniedzy-8671899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ChatGPT-klamie-i-oszukuje-gdy-jest-pod-presja-zarabiania-pieniedzy-8671899.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T05:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/f75cab7b09f342-948-568-0-0-2559-1535.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sztuczna inteligencja oszukiwała i wykorzystywała niedozwolone poufne informacje, żeby zarabiać dla fikcyjnej instytucji finansowej. Podobnie jak ludzie, ChatGPT w „stresie” kłamie częściej.</p>

## Jak dobrze rozplanować urlop i wydłużyć sobie wolne? Oto długie weekendy w 2024 roku
 - [https://www.bankier.pl/wiadomosc/Jak-wydluzyc-urlop-w-2024-roku-i-zyskac-dodatkowe-dni-wolne-8670422.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jak-wydluzyc-urlop-w-2024-roku-i-zyskac-dodatkowe-dni-wolne-8670422.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/a7ce91ec3709c8-948-568-8-110-1623-974.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />11 dni wolnego za 5 dni urlopu - wystarczy dokładniej przyjrzeć się kalendarzowi, by zobaczyć, że 2024 roku jest łaskawy pod kątem przedłużonych weekendów. Pierwszy już za rogiem dzięki Trzem Królom. Następne w kwietniu, maju, sierpniu, listopadzie i standardowo grudniu. </p>

## Klęskę noworocznych postanowień lepiej usprawiedliwiać brakiem pieniędzy niż czasu
 - [https://www.bankier.pl/wiadomosc/Kleske-noworocznych-postanowien-lepiej-usprawiedliwiac-brakiem-pieniedzy-niz-czasu-8665344.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kleske-noworocznych-postanowien-lepiej-usprawiedliwiac-brakiem-pieniedzy-niz-czasu-8665344.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/4/1f585d23faee37-948-568-0-303-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Aby lepiej wyglądać w oczach innych, lepiej usprawiedliwiać porzucenie noworocznych zobowiązań brakiem pieniędzy niż brakiem czasu - informuje „European Journal of Social Psychology”.</p>

## Od dziś 500+ wzrasta do 800 złotych. Nie trzeba składać wniosku, by dostać wyższe świadczenie
 - [https://www.bankier.pl/wiadomosc/Podwyzka-500-plus-na-800-plus-Czy-trzeba-skladac-wniosek-8671034.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podwyzka-500-plus-na-800-plus-Czy-trzeba-skladac-wniosek-8671034.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/a860bb8d495cf5-948-568-760-540-1833-1100.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 1 stycznia 2024 r. wysokość świadczenia 
wychowawczego 500+ wzrośnie do 800 zł. Zmiana ta  nastąpi z urzędu – 
przypomina Ministerstwo Rodziny, Pracy i Polityki Społecznej.</p>

## "Nowy rok, ten sam terroryzm". Pracowita noc Żelaznej Kopuły w Izraelu
 - [https://www.bankier.pl/wiadomosc/Nowy-rok-ten-sam-terroryzm-Pracowita-noc-Zelaznej-Kopuly-w-Izraelu-8671891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowy-rok-ten-sam-terroryzm-Pracowita-noc-Zelaznej-Kopuly-w-Izraelu-8671891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-01T03:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/4/8dece746f58314-948-568-0-202-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Izrael przechwycił co najmniej 12 rakiet wystrzelonych zaledwie kilka minut po północy przez Hamas - podała amerykańska telewizja CNN.</p>

