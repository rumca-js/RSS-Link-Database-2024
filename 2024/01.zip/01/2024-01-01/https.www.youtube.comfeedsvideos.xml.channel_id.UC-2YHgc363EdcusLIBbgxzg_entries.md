# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## The Biggest Science Discoveries of 2023
 - [https://www.youtube.com/watch?v=SeKyOiphy3o](https://www.youtube.com/watch?v=SeKyOiphy3o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2024-01-01T16:23:15+00:00

Visit http://www.brilliant.org/answerswithjoe to start your 30-day free trial, and the first 200 people will get 20% off their annual premium subscription.

Lots of things happened in 2023, some you may remember, some you may have missed, but today we’re going to talk about some of the most consequential science stories that happened and how they’ll affect the years going forward. Happy new year!

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can listen to my podcast, Conversations With Joe on Spotify, Apple Podcasts, Google Podcasts, or wherever you get your podcasts.
Spotify 👉 https://spoti.fi/37iPG

