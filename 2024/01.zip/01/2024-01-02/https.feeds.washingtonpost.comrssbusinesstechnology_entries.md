# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Trying to break a phone habit in 2024? Skip the life hacks.
 - [https://www.washingtonpost.com/technology/2024/01/02/technology-habits-to-break-2024](https://www.washingtonpost.com/technology/2024/01/02/technology-habits-to-break-2024)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-01-02T17:30:00+00:00

Time-management expert Oliver Burkeman doesn’t do New Year’s resolutions. But he wants us to understand why our phones are so alluring.

## Missing Chinese student was victim of ‘cyber kidnapping’ scam, Utah police say
 - [https://www.washingtonpost.com/nation/2024/01/02/missing-utah-student-kai-zhuang-found-cyber-kidnapping](https://www.washingtonpost.com/nation/2024/01/02/missing-utah-student-kai-zhuang-found-cyber-kidnapping)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-01-02T14:55:20+00:00

Police said Kai Zhuang, 17, was coerced by scammers into going into isolation, while his family was extorted into paying $80,000. He was later found unharmed.

## States looking to 2024 to pass revised kids’ online safety bills
 - [https://www.washingtonpost.com/technology/2024/01/02/children-safety-social-media-california](https://www.washingtonpost.com/technology/2024/01/02/children-safety-social-media-california)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-01-02T13:00:46+00:00

State legislators and children’s safety advocates have revised legislation after a federal judge blocked a new law in California.

