# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Duża czystka w ambasadach. "Brak doświadczenia, wiedzy, znajomości języków"
 - [https://www.bankier.pl/wiadomosc/Duza-czystka-w-ambasadach-Brak-doswiadczenia-wiedzy-znajomosci-jezykow-8672508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Duza-czystka-w-ambasadach-Brak-doswiadczenia-wiedzy-znajomosci-jezykow-8672508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T19:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/7/25c43f79370063-948-568-71-85-2782-1669.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Część ambasadorów RP ewidentnie nie nadaje się na te stanowiska z rozmaitych powodów i zostanie odwołana - powiedział we wtorek w Polsat News wiceszef MSZ Władysław Teofil Bartoszewski, podkreślając, że to nie będzie proces nagły. Trzeba będzie przeglądać placówka po placówce - zaznaczył.</p>

## Tak Francja chce walczyć ze "shrinkflacją". Na horyzoncie rewolucyjne zmiany
 - [https://www.bankier.pl/wiadomosc/Tak-Francja-chce-walczyc-ze-shrinkflacja-Na-horyzoncie-rewolucyjne-zmiany-8672504.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-Francja-chce-walczyc-ze-shrinkflacja-Na-horyzoncie-rewolucyjne-zmiany-8672504.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T18:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/f/f2705a0f40c59c-948-568-0-202-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Francuskie władze chcą zobowiązać sprzedawców i producentów, by informowali konsumentów o tym, że pomimo tej samej ceny ilość danego produktu się zmniejszyła - poinformował we wtorek portal Just Food.</p>

## Turcja nie pozwala na pomoc wojskową dla Ukrainy. Okręty nie mogą przepłynąć
 - [https://www.bankier.pl/wiadomosc/Turcja-nie-pozwala-na-pomoc-wojskowa-dla-Ukrainy-Okrety-nie-moga-przeplynac-8672495.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Turcja-nie-pozwala-na-pomoc-wojskowa-dla-Ukrainy-Okrety-nie-moga-przeplynac-8672495.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T17:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/a/9b708d0ef9fb1e-948-568-0-127-4236-2541.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze Turcji oświadczyły we wtorek, że nie zezwolą dwóm trałowcom przekazanym Ukrainie przez Wielką Brytanię na przepłynięcie przez jej wody w drodze na Morze Czarne, ponieważ naruszyłoby to międzynarodową konwencję dotyczącą ruchu jednostek przez tureckie cieśniny w czasie wojny - poinformowała agencja Reutera.</p>

## Rolnicy ponownie zablokują przejście w Medyce? Postawili warunek
 - [https://www.bankier.pl/wiadomosc/Rolnicy-ponownie-zablokuja-przejscie-w-Medyce-Postawili-warunek-8672492.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rolnicy-ponownie-zablokuja-przejscie-w-Medyce-Postawili-warunek-8672492.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T17:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/cab59132cf770d-948-568-30-127-2970-1781.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rolnicy z „Podkarpackiej oszukanej wsi” w środę zdecydują, czy będą kontynuować swój protest i blokować przejście graniczne w Medyce. „Jeśli nie dostaniemy na piśmie potwierdzenie, że nasze postulaty będą spełnione, wrócimy na blokadę” – powiedział PAP we wtorek lider organizacji Roman Kondrów.</p>

## Google odpowiada na zarzuty ws. nieprawdziwego kursu złotego
 - [https://www.bankier.pl/wiadomosc/Google-odpowiada-na-zarzuty-ws-nieprawdziwego-kursu-zlotego-8672482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Google-odpowiada-na-zarzuty-ws-nieprawdziwego-kursu-zlotego-8672482.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T17:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/83a4f09f2a18cb-948-568-0-194-2880-1727.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Cyfryzacji zwróciło się do Google Polska o przedstawienie wyjaśnień w związku z pojawieniem się nieprawdziwej informacji dotyczącej kursu złotego - poinformował we wtorek resort na platformie X (dawniej Twitter).</p>

## 88 proc. mieszkańców Kuby żyje w skrajnym ubóstwie. Problem ma się jeszcze nasilić
 - [https://www.bankier.pl/wiadomosc/88-proc-mieszkancow-Kuby-zyje-w-skrajnym-ubostwie-Problem-ma-sie-jeszcze-nasilic-8672467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/88-proc-mieszkancow-Kuby-zyje-w-skrajnym-ubostwie-Problem-ma-sie-jeszcze-nasilic-8672467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T16:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/a37acd57cb2497-948-568-0-320-4752-2851.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na zamieszkałej przez ponad 11 mln osób Kubie 88 proc. obywateli żyje w skrajnym ubóstwie, wynika z raportu niezależnego Kubańskiego Obserwatorium Praw Człowieka (OCDH).</p>

## Spadkowy początek roku na giełdowym parkiecie
 - [https://www.bankier.pl/wiadomosc/Spadkowy-poczatek-roku-na-gieldowym-parkiecie-8672426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spadkowy-poczatek-roku-na-gieldowym-parkiecie-8672426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T16:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/9564969c98db60-937-562-0-60-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwsza giełdowa sesja A.D. 2024 przyniosła przewagę
spadków na warszawskim parkiecie.</p>

## Chciał zainwestować w kryptowaluty. Stracił dostęp do konta i 22 tys zł.
 - [https://www.bankier.pl/wiadomosc/Chcial-zainwestowac-w-kryptowaluty-Stracil-dostep-do-konta-i-22-tys-zl-8672388.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chcial-zainwestowac-w-kryptowaluty-Stracil-dostep-do-konta-i-22-tys-zl-8672388.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T14:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/b/ac972fd359114a-948-568-0-42-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />22 tys. zł stracił 22-latek z pow. przasnyskiego (Mazowieckie), który chcąc zarobić na kryptowalutach, padł ofiarą oszustwa – poinformowała we wtorek rzeczniczka policji w Przasnyszu mł. asp. Ilona Cichocka.</p>

## Wszczęto postępowanie ws. wypowiedzi w Telewizji Republika
 - [https://www.bankier.pl/wiadomosc/Wszczeto-postepowanie-ws-wypowiedzi-w-Telewizji-Republika-8672371.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wszczeto-postepowanie-ws-wypowiedzi-w-Telewizji-Republika-8672371.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T14:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/237b31ea472097-948-568-0-20-1477-886.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wszczęto postępowanie dotyczące wypowiedzi w Telewizji Republika. Chodzi o program wyemitowany 31 grudnia ub.r. Postępowanie prowadzone jest w sprawie co oznacza, że nikomu nie przedstawiono zarzutów – poinformował PAP we wtorek rzecznik prasowy Prokuratury Okręgowej w Warszawie Szymon Banna.</p>

## Najstarsza Myszka Miki nie jest już chroniona. Prawa Disneya wygasły, ale firma ostrzega
 - [https://www.bankier.pl/wiadomosc/Najstarsza-Myszka-Miki-nie-jest-juz-chroniona-Prawa-Disneya-wygasly-ale-firma-ostrzega-8672363.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najstarsza-Myszka-Miki-nie-jest-juz-chroniona-Prawa-Disneya-wygasly-ale-firma-ostrzega-8672363.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T13:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/3/884011e38ffd91-948-568-1204-821-1858-1114.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />1 stycznia wygasły prawa Disneya do najstarszych wersji wizerunku sławnej mysiej pary: Micky Mouse i Minnie Mouse. Oznacza to, że twórcy mogą bez pozwolenia i bez opłat wykorzystywać je i przerabiać.</p>

## Exodus z TVP Info do TV Republika. Sakiewicz: Potrzeby są duże
 - [https://www.bankier.pl/wiadomosc/Exodus-z-TVP-Info-do-TV-Republika-Sakiewicz-Potrzeby-sa-duze-8672350.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Exodus-z-TVP-Info-do-TV-Republika-Sakiewicz-Potrzeby-sa-duze-8672350.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T13:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/c/77197c593ffee6-948-568-0-0-4444-2666.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W mediach publicznych trwa kadrowa czystka. Wielu byłych pracowników TVP Info może liczyć na zatrudnienie w TV Republika, a prezes stacji Tomasz Sakiewicz mówi wprost: potrzeby są duże.</p>

## Przyszłość prezesa NBP a rating Polski. "Nie byłoby automatycznego obniżenia"
 - [https://www.bankier.pl/wiadomosc/Przyszlosc-prezesa-NBP-a-rating-Polski-Nie-byloby-automatycznego-obnizenia-8672336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przyszlosc-prezesa-NBP-a-rating-Polski-Nie-byloby-automatycznego-obnizenia-8672336.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T13:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/4/0020905ca110f3-948-568-0-112-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Scenariusz zawieszenia w obowiązkach prezesa NBP po postawieniu go przed Trybunałem Stanu jest hipotetyczny, ale gdyby tak się stało, to potencjalne implikacje dotyczące ratingu Polski nie byłyby automatyczne - poinformował PAP Biznes główny analityk agencji S&amp;P Global Ratings odpowiedzialny za rating Polski Ludwig Heinz.</p>

## "AAA udział w mieszkaniu kupię". Fliperzy działają w nowy (bezlitosny) sposób
 - [https://www.bankier.pl/wiadomosc/AAA-udzial-w-mieszkaniu-kupie-Fliperzy-dzialaja-w-nowy-bezlitosny-sposob-8672305.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/AAA-udzial-w-mieszkaniu-kupie-Fliperzy-dzialaja-w-nowy-bezlitosny-sposob-8672305.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/7d8e823eb5b13a-948-568-0-295-4381-2628.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie jest tajemnicą, że ceny nieruchomości szaleją. Na rynku coraz trudniej o łatwy flip, ale znaleziono inny sposób, by zarabiać na mieszkaniach. "Inwestorzy" nie mają litości dla najemców, a takich sytuacji będzie coraz więcej.</p>

## Najlepsze lokaty miesięczne. W nowy rok z 8 proc. w skali roku
 - [https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-1-miesiac-styczen-2024-Ranking-Bankier-pl-8672313.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-lokaty-bankowe-na-1-miesiac-styczen-2024-Ranking-Bankier-pl-8672313.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T12:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/0a258ce36350d9-948-569-0-75-1891-1135.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najwyżej oprocentowana lokata miesięczna na początku stycznia jest objęta stawką w wysokości 8 proc. rocznie. Depozyt ma kilka ograniczeń, a jednym z nich jest niska kwota maksymalna.</p>

## Rewolucja w ważnym świadczeniu. Będzie można łączyć je z pracą
 - [https://www.bankier.pl/wiadomosc/Rewolucja-w-swiadczeniu-pielegnacyjnym-Bedzie-mozna-laczyc-je-z-praca-8672245.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rewolucja-w-swiadczeniu-pielegnacyjnym-Bedzie-mozna-laczyc-je-z-praca-8672245.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T11:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/b/a9335b8bd32c80-948-568-10-10-3990-2393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z początkiem nowego roku weszły w życie duże zmiany w sposobie 
przyznawania świadczenia pielęgnacyjnego - można je określić mianem 
rewolucyjnych. Zniesiono między innymi zakaz pracy dla rodziców, którzy 
to świadczenie pobierają. To efekt pracy wielu środowisk i aktywistów.</p>

## NBP zapłacił za wysokie stopy procentowe. Strata nie tylko przez umocnienie złotego
 - [https://www.bankier.pl/wiadomosc/NBP-zaplacil-za-wysokie-stopy-procentowe-Strata-nie-tylko-przez-umocnienie-zlotego-8672244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-zaplacil-za-wysokie-stopy-procentowe-Strata-nie-tylko-przez-umocnienie-zlotego-8672244.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T11:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/0/6337d364ec2c76-948-568-0-9-3868-2320.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Narodowy Bank Polski zapłacił za wysokie stopy procentowe. Do rekordowej straty przyczyniła się nie tylko aprecjacja złotego, ale też rekordowe koszty prowadzenia operacji otwartego rynku. </p>

## Zmiany w BGK. Premier odwołał dwóch członków rady nadzorczej
 - [https://www.bankier.pl/wiadomosc/BGK-premier-odwolal-Piotra-Kielocha-i-Joanne-Strzesak-Rochewicz-z-rady-nadzorczej-8672260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/BGK-premier-odwolal-Piotra-Kielocha-i-Joanne-Strzesak-Rochewicz-z-rady-nadzorczej-8672260.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T11:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/a/1f401dd0bd0aa3-948-568-0-388-3691-2215.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Premier Donald Tusk odwołał Piotra Kielocha i Joannę Strzesak-Rochewicz z rady nadzorczej Bank Gospodarstwa Krajowego - poinformował we wtorek w komunikacie bank.</p>

## Holandia wycofała zezwolenie na eksport do Chin niektórych maszyn do produkcji czipów
 - [https://www.bankier.pl/wiadomosc/Holandia-wycofala-zezwolenie-na-eksport-do-Chin-niektorych-maszyn-do-produkcji-czipow-8672252.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Holandia-wycofala-zezwolenie-na-eksport-do-Chin-niektorych-maszyn-do-produkcji-czipow-8672252.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T11:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/11e03ff82a7f2a-948-568-0-120-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Holenderski rząd zakazał producentowi maszyn do produkcji czipów firmie ASML eksportowania do Chin niektórych urządzeń pracujących w głębokim ultrafiolecie (DUV) - poinformowała firma w poniedziałek w komunikacie prasowym. Decyzja została podjęta pod naciskiem USA - komentują media.</p>

## Koniec zniżki za płatności automatyczne na autostradzie A4 Katowice-Kraków
 - [https://www.bankier.pl/wiadomosc/Koniec-znizki-za-platnosci-automatyczne-na-autostradzie-A4-Katowice-Krakow-8672253.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-znizki-za-platnosci-automatyczne-na-autostradzie-A4-Katowice-Krakow-8672253.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T11:03:00+00:00

<p>Zarządca płatnej autostrady A4 Katowice-Kraków 16 stycznia br. zniesie zniżkę za przejazd z wykorzystaniem płatności automatycznych. Oznacza to, że cena na każdej bramce dla kierowców samochodów osobowych wyniesie 15 zł (dotąd ze zniżką jest to 13 zł).</p>

## Odwołano kolejne posiedzenie Rady Mediów Narodowych
 - [https://www.bankier.pl/wiadomosc/Odwolano-kolejne-posiedzenie-Rady-Mediow-Narodowych-8672247.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Odwolano-kolejne-posiedzenie-Rady-Mediow-Narodowych-8672247.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T10:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/8/f3476c7ae7cda2-948-568-0-296-1604-962.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dziś miało odbyć się kolejne posiedzenie Rady Mediów Narodowych. Właśnie zostało odwołane, standardowo bez podania przyczyny - poinformował we wtorek członek Rady Mediów Narodowych Marek Rutka w mediach społecznościowych.</p>

## Duże zmiany na stacjach. Czy paliwem E10 da się zatankować kosiarkę ?
 - [https://www.bankier.pl/wiadomosc/Duze-zmiany-na-stacjach-Czy-paliwem-E10-da-sie-zatankowac-kosiarke-8672229.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Duze-zmiany-na-stacjach-Czy-paliwem-E10-da-sie-zatankowac-kosiarke-8672229.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T10:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/3/505172136bc41d-945-560-0-39-1763-1057.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2024 roku kierowców czeka wiele zmian. Jedną z najistotniejszych jest zmiana paliwa na stacjach benzynowych. Nie każdy samochód jest do niego przystosowany, co więcej paliwo stosuje się też do wielu urządzeń używanych w domach. Zatem czy paliwem E10 zatankujemy kosiarkę?</p>

## Energetyki nie dla dzieci. Ale branża już ma pomysł, jak obejść zakaz
 - [https://www.bankier.pl/wiadomosc/Energetyki-nie-dla-dzieci-Ale-branza-juz-ma-pomysl-jak-obejsc-zakaz-8672223.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Energetyki-nie-dla-dzieci-Ale-branza-juz-ma-pomysl-jak-obejsc-zakaz-8672223.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T10:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/e016b67be82cec-948-568-17-0-3525-2115.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Napoje energetyczne od 1 stycznia 2024 roku są traktowane na równi z 
alkoholem i papierosami - nie kupią ich osoby poniżej 18 roku życia. 
Producenci szukają sposobów, aby ów zakaz obejść.</p>

## Atak na klientów jednego z największych banków. CSIRT KNF ostrzega
 - [https://www.bankier.pl/wiadomosc/Przestepcy-podszywaja-sie-pod-ING-Polska-i-wyludzaja-dane-8672238.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przestepcy-podszywaja-sie-pod-ING-Polska-i-wyludzaja-dane-8672238.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T10:36:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/178ce631e0df4f-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Cyberprzestępcy przygotowali strony podszywające się pod ING Polska, gdzie wyłudzają dane uwierzytelniające do bankowości elektronicznej – ostrzegł we wtorek CSIRT KNF.</p>

## Obiecywał zysk z kryptowalut, wyłudził 60 tys. złotych
 - [https://www.bankier.pl/wiadomosc/Obiecywal-zysk-z-kryptowalut-wyludzil-60-tys-zlotych-8672207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Obiecywal-zysk-z-kryptowalut-wyludzil-60-tys-zlotych-8672207.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T09:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/2a9464a9ed0338-948-568-0-195-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />26-letni obywatel Ukrainy obiecywał szybki zysk przy inwestycjach w kryptowaluty. Wyłudził w ten sposób 60 tys. zł. Wpadł jednak w ręce policji. Trafił na 3 miesiące do aresztu. Teraz grozi mu do 8 lat więzienia – poinformował we wtorek oficer prasowy z Komendy Powiatowej Policji w Otwocku sierż. szt. Patryk Domarecki.</p>

## Duże zmiany dla kierowców. Tak wysokich kar za brak OC jeszcze nie było
 - [https://www.bankier.pl/wiadomosc/Duze-zmiany-dla-kierowcow-Tak-wysokich-kar-za-brak-OC-jeszcze-nie-bylo-8672205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Duze-zmiany-dla-kierowcow-Tak-wysokich-kar-za-brak-OC-jeszcze-nie-bylo-8672205.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T09:56:00+00:00

<p>W tym roku kierowcy
muszą się przygotować na znacznie wyższe kary za brak ważnego OC - tym razem ich stawki są
rekordowe. W dodatku w 2024 r. planowana jest jeszcze jedna podwyżka.</p>

## Kurs euro bez większych zmian. Frank niemal rekordowo mocny
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-Frank-niemal-rekordowo-mocny-8672196.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-Frank-niemal-rekordowo-mocny-8672196.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T09:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/3ffee66aa690d3-948-568-193-250-4355-2613.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wbrew temu, co pokazywała wyszukiwarka Google, kursy euro i
dolara w relacji do złotego pozostały stabilne. Za to notowania franka szwajcarskiego względem euro
znalazły się na historycznie mocnych poziomach.</p>

## Mieszkaniec Michigan wygrał ponad 842 miliony dolarów na loterii
 - [https://www.bankier.pl/wiadomosc/Mieszkaniec-Michigan-wygral-ponad-842-miliony-dolarow-na-loterii-8672180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mieszkaniec-Michigan-wygral-ponad-842-miliony-dolarow-na-loterii-8672180.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T09:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/86072d524784dc-945-560-0-0-1498-898.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Los loterii Powerball kupiony w amerykańskim stanie Michigan w poniedziałek przyniósł szczęśliwemu nabywcy główną wygraną wynosząca 842,5 miliona dolarów.</p>

## Wiceminister edukacji: Chcemy odchudzić podstawę programową i ograniczyć liczbę lektur
 - [https://www.bankier.pl/wiadomosc/Wiceminister-edukacji-Chcemy-odchudzic-podstawe-programowa-i-ograniczyc-liczbe-lektur-8672154.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiceminister-edukacji-Chcemy-odchudzic-podstawe-programowa-i-ograniczyc-liczbe-lektur-8672154.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T08:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/6/b04a2ec79def7b-948-568-37-60-962-577.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chcemy odchudzić podstawę programową od 1 września b.r. od 5 proc. do 20 proc. treści, w zależności od poszczególnych przedmiotów - powiedziała we wtorek w Radiu Zet wiceminister edukacji Katarzyna Lubnauer. Dodała, że zostanie także ograniczona liczba lektur.</p>

## Zmiana pracy i podwyżka na noworocznej liście postanowień wielu Polaków
 - [https://www.bankier.pl/wiadomosc/Zmiana-pracy-i-podwyzka-na-noworocznej-liscie-postanowien-wielu-Polakow-8672144.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zmiana-pracy-i-podwyzka-na-noworocznej-liscie-postanowien-wielu-Polakow-8672144.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T08:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/b/5e28f9fdaf620e-948-568-22-1207-2977-1786.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />73 proc. respondentów na noworocznej liście postanowień wpisało zmianę pracy - wynika z opublikowanego we wtorek badania Pracuj.pl. Dodano, że staranie się o podwyżkę znajduje się na czwartym miejscu.</p>

## "GPW powinna nadganiać świat, można postawić na obligacje zagraniczne"
 - [https://www.bankier.pl/wiadomosc/GPW-powinna-nadganiac-swiat-mozna-postawic-na-obligacje-zagraniczne-8672136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/GPW-powinna-nadganiac-swiat-mozna-postawic-na-obligacje-zagraniczne-8672136.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T08:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/b8d2b31ce008e0-948-568-133-257-3980-2388.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Warszawska giełda w 2024 r. powinna nadganiać wieloletnie opóźnienia we wzrostach, natomiast potencjał w przypadku polskich obligacji skarbowych już się wyczerpuje. Jarosław Leśniczak, dyrektor Biura Alokacji i Instrumentów Dłużnych TFI PZU, poleca obligacje zagraniczne, a z surowców stawia na miedź i złoto.</p>

## Bez poprawy w sektorze wytwórczym. Negatywna niespodzianka z polskiego przemysłu
 - [https://www.bankier.pl/wiadomosc/PMI-Polska-grudzien-2023-8672132.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PMI-Polska-grudzien-2023-8672132.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T08:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/0/170b9e2dff5f2e-948-568-81-52-1838-1103.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Grudzień przyniósł nieoczekiwanie głęboki regres aktywności ekonomicznej
w polskim sektorze wytwórczym. Było to spore zaskoczenie dla ekonomistów.</p>

## Zandberg o pseudokatastrofie złotego: NBP nie jest mistrzem świata, jeżeli chodzi o komunikacje
 - [https://www.bankier.pl/wiadomosc/Zandberg-o-pseudokatastrofie-zlotego-NBP-nie-jest-mistrzem-swiata-jezeli-chodzi-o-komunikacje-8672124.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zandberg-o-pseudokatastrofie-zlotego-NBP-nie-jest-mistrzem-swiata-jezeli-chodzi-o-komunikacje-8672124.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T07:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/21bfbe8037dfee-948-568-52-262-3441-2065.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dobrze, że minister finansów wystosował szybki komunikat dot. poniedziałkowego kursu złotego, bo pewnie trzeba było uspokajać nastroje zanim się rozhulały. Zabrakło mi komunikatu NBP, który nie jest mistrzem świata, jeżeli chodzi o komunikacje - mówił we wtorek w Polsat News poseł Lewicy Adrian Zandberg.</p>

## Redan ma warunkową umowę sprzedaży znaków towarowych za 10,5-13,5 mln zł
 - [https://www.bankier.pl/wiadomosc/Redan-ma-warunkowa-umowe-sprzedazy-znakow-towarowych-za-10-5-13-5-mln-zl-8672119.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Redan-ma-warunkowa-umowe-sprzedazy-znakow-towarowych-za-10-5-13-5-mln-zl-8672119.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T07:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/b/6cfef87aeab5dc-945-560-0-56-1600-959.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Redan podpisał z krakowską spółką Greenpoint warunkową umowę sprzedaży praw do znaków towarowych Top Secret i DryWash i umowę licencyjną - poinformował Redan w komunikacie. Łączna cena sprzedaży wyniesie od 10,5 do 13,5 mln zł.</p>

## Rakieta, która w piątek naruszyła polską przestrzeń, opuściła terytorium kraju. MON zapewnia
 - [https://www.bankier.pl/wiadomosc/Rakieta-ktora-w-piatek-naruszyla-polska-przestrzen-opuscila-terytorium-kraju-MON-zapewnia-8672116.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rakieta-ktora-w-piatek-naruszyla-polska-przestrzen-opuscila-terytorium-kraju-MON-zapewnia-8672116.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T07:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/29e395c1853cf3-948-568-0-48-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mamy pewność, że rosyjska rakieta, która w piątek naruszyła polską przestrzeń powietrzną, opuściła terytorium naszego kraju; mamy potwierdzenie z radarów polskich i sojuszniczych, skierowaliśmy też żołnierzy do poszukiwań na lądzie - powiedział we wtorek w RMF FM wiceszef MON Paweł Zalewski.</p>

## Finlandia chce ograniczyć prawa Rosjan do fińskiego obywatelstwa
 - [https://www.bankier.pl/wiadomosc/Finlandia-chce-ograniczyc-prawa-Rosjan-do-finskiego-obywatelstwa-8672091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Finlandia-chce-ograniczyc-prawa-Rosjan-do-finskiego-obywatelstwa-8672091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T06:21:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/42edad34fa2248-948-568-0-104-1672-1003.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Finlandii żyje niemal 100 tys. osób rosyjskojęzycznych, a blisko 40 tys. ma podwójne, rosyjskie i fińskie obywatelstwo. Najbardziej radykalni politycy chcą, by Rosjanom nie przyznawano fińskiego paszportu; uważają, że mogą oni stanowić zagrożenie dla bezpieczeństwa narodowego i w sposób nieuzasadniony korzystać z przywilejów mieszkańców UE.</p>

## Ekonomiści: Każdy rok bez euro przynosi Polsce straty
 - [https://www.bankier.pl/wiadomosc/Ekonomisci-Kazdy-rok-bez-euro-przynosi-Polsce-straty-8672088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ekonomisci-Kazdy-rok-bez-euro-przynosi-Polsce-straty-8672088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T06:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/ee99d0175e07dd-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polski rząd powinien obrać kurs na euro. Korzyści przewyższają koszty – mówią ekonomiści - pisze wtorkowa "Rzeczpospolita".</p>

## Bodnar: Wszystkie sprawy dot. ludzi PiS będą konsekwentnie rozliczone
 - [https://www.bankier.pl/wiadomosc/Bodnar-Wszystkie-sprawy-dot-ludzi-PiS-beda-konsekwentnie-rozliczone-8672082.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bodnar-Wszystkie-sprawy-dot-ludzi-PiS-beda-konsekwentnie-rozliczone-8672082.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T06:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/9a7730bbb13af6-948-568-0-185-4366-2619.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wszystko zostanie dokładnie sprawdzone i konsekwentnie rozliczone – zapowiada w tygodniku "Newsweek" minister sprawiedliwości Adam Bodnar.</p>

## Kto zapłaci za szybki wzrost płacy minimalnej? Finalnie wszyscy
 - [https://www.bankier.pl/wiadomosc/Kto-zaplaci-za-szybki-wzrost-placy-minimalnej-Finalnie-wszyscy-8672081.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kto-zaplaci-za-szybki-wzrost-placy-minimalnej-Finalnie-wszyscy-8672081.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T05:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/e/049536be1fbf01-948-568-10-0-4189-2513.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kolejny rok dwucyfrowych podwyżek najniższego wynagrodzenia to wyzwanie dla wielu firm i branż, w tym szczególnie dla sektora MSP i małych rynków pracy - czytamy we wtorkowej "Rzeczpospolitej".</p>

## Pesymistyczne perspektywy dla szpitali na 2024 rok. Wzrost pensji personelu medycznego dużym problemem
 - [https://www.bankier.pl/wiadomosc/Pesymistyczne-perspektywy-dla-szpitali-na-2024-rok-Wzrost-pensji-personelu-medycznego-duzym-problemem-8672071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pesymistyczne-perspektywy-dla-szpitali-na-2024-rok-Wzrost-pensji-personelu-medycznego-duzym-problemem-8672071.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/5/9ff77fa55b69a6-948-568-22-0-4405-2643.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kondycja finansowa szpitali powiatowych jest bardzo zła, czego przejawem są coraz większe straty w działalności i rosnące długi. Sytuację pogorszyła reforma systemu wynagrodzeń pracowników zatrudnionych w podmiotach...</p>

## Najważniejsze zmiany dla klientów banków w 2024 r.
 - [https://www.bankier.pl/wiadomosc/Najwazniejsze-zmiany-dla-klientow-bankow-w-2024-r-8671961.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najwazniejsze-zmiany-dla-klientow-bankow-w-2024-r-8671961.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/d66382eb6baa54-937-562-62-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wielkie hity mają zwykle swoje kontynuacje. W 2024 r. czekają nas zapewne sequele dwóch „przebojów finansowych regulacji” – hipotek z dopłatami i wakacji kredytowych. Nie zabraknie jednak także innych zmian, zwłaszcza dotykających okolic bankowego rynku.</p>

## Rynek najmu hamuje. Stawki spadają, ale wciąż drożej niż przed rokiem
 - [https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-grudzien-2023-Raport-Bankier-pl-8671039.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-grudzien-2023-Raport-Bankier-pl-8671039.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/c90e021d230be5-948-568-82-195-2865-1718.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Listopad był trzecim miesiącem z rzędu, w którym dominowały spadki średnich cen ofertowych najmu – wynika z danych Otodom Analytics. Najmocniejsza przecena dotknęła najpopularniejsze metraże, jednak wynajmujący wciąż oczekują więcej niż przed rokiem.
</p>

## Sankcja darmowego kredytu, czyli na czym polega „konsumencki bezpiecznik”?
 - [https://www.bankier.pl/wiadomosc/Sankcja-kredytu-darmowego-najwazniejsze-informacje-8671997.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sankcja-kredytu-darmowego-najwazniejsze-informacje-8671997.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/6/f5810ec5481d51-948-568-225-20-3553-2131.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ustawie o kredycie konsumenckim wbudowano mechanizm, który miał skłonić kredytodawców do uważnej realizacji narzuconych przez prawo obowiązków. Konsumenci coraz częściej sięgają po ten „bezpiecznik”. Przypominamy, na czym polega sankcja darmowego kredytu.</p>

## Kolejny atak na Ukrainę. Alarm powietrzny na terenie całego kraju
 - [https://www.bankier.pl/wiadomosc/Kolejny-atak-na-Ukraine-Alarm-powietrzny-na-terenie-calego-kraju-8672055.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejny-atak-na-Ukraine-Alarm-powietrzny-na-terenie-calego-kraju-8672055.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T03:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/9/897a7c746a0698-948-568-0-350-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />We wtorek w Kijowie słychać eksplozje, Ukraina próbuje  odeprzeć atak rosyjskich dronów na swoją stolicę – podają władze miasta. Alarmy lotnicze zostały ogłoszone również  w innych miastach w całym kraju, poinformowała AFP.</p>

## Kobiety głównymi kandydatkami w wyborach prezydenckich w Meksyku. "Społeczeństwo jest do tego od dawna przygotowane"
 - [https://www.bankier.pl/wiadomosc/Kobiety-glownymi-kandydatkami-w-wyborach-prezydenckich-w-Meksyku-Spoleczenstwo-jest-do-tego-od-dawna-przygotowane-8672051.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kobiety-glownymi-kandydatkami-w-wyborach-prezydenckich-w-Meksyku-Spoleczenstwo-jest-do-tego-od-dawna-przygotowane-8672051.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-01-02T01:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/9/1d91546b9e0740-948-568-130-0-3533-2120.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po raz pierwszy w historii Meksyku prezydentem kraju może zostać kobieta. Do głównych kandydatek w wyborach prezydenckich  w czerwcu 2024 roku analitycy zaliczają  Claudię Sheinbaum Pardo  i Xochitlę Galvez.</p>

