# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Death Stranding 2 raczej nie zadebiutuje w 2024 roku
 - [https://ithardware.pl/aktualnosci/death_stranding_2_raczej_nie_zadebiutuje_w_2024_roku-30942.html](https://ithardware.pl/aktualnosci/death_stranding_2_raczej_nie_zadebiutuje_w_2024_roku-30942.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T21:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/30942_1.jpg" />            Hideo Kojima pracuje nad Death Stranding 2. Deweloper podzielił się planami wydawniczymi na ten rok i niestety raczej nie powinniśmy oczekiwać premiery produkcji w 2024 r.

Hideo Kojima zdradził swoje plany na 2024 rok i jak wynika z tego co...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/death_stranding_2_raczej_nie_zadebiutuje_w_2024_roku-30942.html">https://ithardware.pl/aktualnosci/death_stranding_2_raczej_nie_zadebiutuje_w_2024_roku-30942.html</a></p>

## Square Enix zamierza "agresywnie" korzystać ze sztuchnej inteligencji do tworzenia gier
 - [https://ithardware.pl/aktualnosci/square_enix_zamierza_agresywnie_korzystac_ze_sztuchnej_inteligencji_do_tworzenia_gier-30940.html](https://ithardware.pl/aktualnosci/square_enix_zamierza_agresywnie_korzystac_ze_sztuchnej_inteligencji_do_tworzenia_gier-30940.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T19:28:50+00:00

<img src="https://ithardware.pl/artykuly/min/30940_1.jpg" />            Sztuczna inteligencja jest obecnie szeroko stosowana także w branży gier. Square Enix zapowiedziało wykorzystanie tej technologii w swoich przyszłych projektach. Ma to być agresywna strategia.

Square Enix postawi na sztuczną...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/square_enix_zamierza_agresywnie_korzystac_ze_sztuchnej_inteligencji_do_tworzenia_gier-30940.html">https://ithardware.pl/aktualnosci/square_enix_zamierza_agresywnie_korzystac_ze_sztuchnej_inteligencji_do_tworzenia_gier-30940.html</a></p>

## Apple boi się oskarżeń o łamanie praw autorskich przy szkoleniu sztucznej inteligencji
 - [https://ithardware.pl/aktualnosci/apple_boi_sie_oskarzen_o_lamanie_praw_autorskich_przy_szkoleniu_sztucznej_inteligencji-30934.html](https://ithardware.pl/aktualnosci/apple_boi_sie_oskarzen_o_lamanie_praw_autorskich_przy_szkoleniu_sztucznej_inteligencji-30934.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T17:22:30+00:00

<img src="https://ithardware.pl/artykuly/min/30934_1.jpg" />            Szkolenie sztucznej inteligencji może prowadzić do problem&oacute;w związanych z prawami autorskimi, jak miało to miejsce ostatnio w przypadku OpenAI i New York Timesa.&nbsp;Apple chce temu zapobiec, zabezpieczając licencje na treści tekstowe od...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_boi_sie_oskarzen_o_lamanie_praw_autorskich_przy_szkoleniu_sztucznej_inteligencji-30934.html">https://ithardware.pl/aktualnosci/apple_boi_sie_oskarzen_o_lamanie_praw_autorskich_przy_szkoleniu_sztucznej_inteligencji-30934.html</a></p>

## Xiaomi przedstawia elektryka, który ma rywalizować z Teslą i Porsche. Firma chce wstrząśnąć branżą
 - [https://ithardware.pl/aktualnosci/xiaomi_przedstawia_elektryka_ktory_ma_rywalizowac_z_tesla_i_porsche_firma_chce_wstrzasnac_branza-30936.html](https://ithardware.pl/aktualnosci/xiaomi_przedstawia_elektryka_ktory_ma_rywalizowac_z_tesla_i_porsche_firma_chce_wstrzasnac_branza-30936.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T17:22:30+00:00

<img src="https://ithardware.pl/artykuly/min/30936_1.jpg" />            Podczas uroczystej imprezy inauguracyjnej w Pekinie, chiński gigant smartfon&oacute;w Xiaomi oficjalnie wprowadził&nbsp;sw&oacute;j pierwszy samoch&oacute;d elektryczny, jednocześnie wyrażając ambitne cele dor&oacute;wnania Tesli i Porsche,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/xiaomi_przedstawia_elektryka_ktory_ma_rywalizowac_z_tesla_i_porsche_firma_chce_wstrzasnac_branza-30936.html">https://ithardware.pl/aktualnosci/xiaomi_przedstawia_elektryka_ktory_ma_rywalizowac_z_tesla_i_porsche_firma_chce_wstrzasnac_branza-30936.html</a></p>

## Francja nałożyła na Sony karę finansową. Chodzi o kontrolery zewnętrznych producentów
 - [https://ithardware.pl/aktualnosci/francja_nalozyla_na_sony_kare_finansowa_chodzi_o_kontrolery_zewnetrznych_producentow-30939.html](https://ithardware.pl/aktualnosci/francja_nalozyla_na_sony_kare_finansowa_chodzi_o_kontrolery_zewnetrznych_producentow-30939.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T16:58:37+00:00

<img src="https://ithardware.pl/artykuly/min/30939_1.jpg" />            Sony ma problem we Francji. Tamtejszy regulator rynku ukarał producenta PlayStation karą za wykorzystywanie swojej pozycji związanej z kontrolerami do konsol. Firma będzie musiała zapłacić dość sporą karę.

Franuski&nbsp;organ antymonopolowy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/francja_nalozyla_na_sony_kare_finansowa_chodzi_o_kontrolery_zewnetrznych_producentow-30939.html">https://ithardware.pl/aktualnosci/francja_nalozyla_na_sony_kare_finansowa_chodzi_o_kontrolery_zewnetrznych_producentow-30939.html</a></p>

## W 2023 roku do Game Passa trafiły gry o ogromnej wartości
 - [https://ithardware.pl/aktualnosci/w_2023_roku_do_game_passa_trafily_gry_o_ogromnej_wartosci-30938.html](https://ithardware.pl/aktualnosci/w_2023_roku_do_game_passa_trafily_gry_o_ogromnej_wartosci-30938.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T15:45:23+00:00

<img src="https://ithardware.pl/artykuly/min/30938_1.jpg" />            2023 rok był niezwykle intensywny dla Microsoftu, kt&oacute;ry sfinalizował przejęcie Activision Blizzard. Opr&oacute;cz tego firma rozwijała usługę Game Pass dodając nowe gry, ale także zabierając inne produkcje. Wiemy, o jakiej wartości...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/w_2023_roku_do_game_passa_trafily_gry_o_ogromnej_wartosci-30938.html">https://ithardware.pl/aktualnosci/w_2023_roku_do_game_passa_trafily_gry_o_ogromnej_wartosci-30938.html</a></p>

## Steam bez wsparcia dla Windowsa 7, Windowsa 8 i Windowsa 8.1
 - [https://ithardware.pl/aktualnosci/steam_bez_wsparcia_dla_windowsa_7_windowsa_8_i_windowsa_8_1-30937.html](https://ithardware.pl/aktualnosci/steam_bez_wsparcia_dla_windowsa_7_windowsa_8_i_windowsa_8_1-30937.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T14:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/30937_1.jpg" />            Początek roku to zmiany także dla użytkownik&oacute;w Steam korzystających ze starszych wersji systemu Windows. Zgodnie z zapowiedzią Valve wycofało wsparcie dla takiego oprogramowania.

Od 1 stycznia 2024 roku zgodnie z wcześniejszą...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/steam_bez_wsparcia_dla_windowsa_7_windowsa_8_i_windowsa_8_1-30937.html">https://ithardware.pl/aktualnosci/steam_bez_wsparcia_dla_windowsa_7_windowsa_8_i_windowsa_8_1-30937.html</a></p>

## Nubia wypuszcza RedMagic 9 Pro. To potężny smartfon do gier z aparatem 50 MPx i aktywnym chłodzeniem
 - [https://ithardware.pl/aktualnosci/nubia_wypuscila_redmagic_9_pro_potezny_smartfon_z_aparatem_50_mpx_i_aktywnym_chlodzeniem-30932.html](https://ithardware.pl/aktualnosci/nubia_wypuscila_redmagic_9_pro_potezny_smartfon_z_aparatem_50_mpx_i_aktywnym_chlodzeniem-30932.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T12:55:50+00:00

<img src="https://ithardware.pl/artykuly/min/30932_1.jpg" />            Nubia wypuszcza nowy model 9 Pro pod marką RedMagic.&nbsp;Z tyłu otrzyma parę aparat&oacute;w 50 MPx i jeden moduł 2 MPx.&nbsp;Nie zabrakło też dużego wyświetlacza AMOLED o przekątnej 6,8&rdquo; i wysokiej jasności wynoszącej 1600...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nubia_wypuscila_redmagic_9_pro_potezny_smartfon_z_aparatem_50_mpx_i_aktywnym_chlodzeniem-30932.html">https://ithardware.pl/aktualnosci/nubia_wypuscila_redmagic_9_pro_potezny_smartfon_z_aparatem_50_mpx_i_aktywnym_chlodzeniem-30932.html</a></p>

## Tesla oskarża Reutersa o kłamstwa i sfabrykowanie artykułu
 - [https://ithardware.pl/aktualnosci/tesla_oskarza_reutersa_o_klamstwa_i_sfabrykowanie_artykulu-30935.html](https://ithardware.pl/aktualnosci/tesla_oskarza_reutersa_o_klamstwa_i_sfabrykowanie_artykulu-30935.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T12:33:10+00:00

<img src="https://ithardware.pl/artykuly/min/30935_1.jpg" />            Tesla oskarżyła Reutersa o &quot;fabrykowanie&quot; historii o producencie samochod&oacute;w. Agencja sugeruje, że firma celowo wprowadza klient&oacute;w w błąd, żądając napraw poza gwarancją.

Reuters miał przekazywać nieprawdziwe...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tesla_oskarza_reutersa_o_klamstwa_i_sfabrykowanie_artykulu-30935.html">https://ithardware.pl/aktualnosci/tesla_oskarza_reutersa_o_klamstwa_i_sfabrykowanie_artykulu-30935.html</a></p>

## Samsung Galaxy S24, S24+ i S23 Ultra - specyfikacja, ceny i rendery
 - [https://ithardware.pl/aktualnosci/samsung_galaxy_s24_s24_i_s23_ultra_specyfikacja_ceny_i_rendery-30929.html](https://ithardware.pl/aktualnosci/samsung_galaxy_s24_s24_i_s23_ultra_specyfikacja_ceny_i_rendery-30929.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T12:21:01+00:00

<img src="https://ithardware.pl/artykuly/min/30929_1.jpg" />            Oczekuje się, że Samsung zaprezentuje trzy smartfony ze swojej tegorocznej flagowej serii Galaxy S24 już 17 stycznia. Z racji tego, że wyciekło już prawie wszystko na ich temat, w tym specyfikacja, rendery, kolory i ceny w Europie, postanowiliśmy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_galaxy_s24_s24_i_s23_ultra_specyfikacja_ceny_i_rendery-30929.html">https://ithardware.pl/aktualnosci/samsung_galaxy_s24_s24_i_s23_ultra_specyfikacja_ceny_i_rendery-30929.html</a></p>

## Sony ma szykować MMO w świecie Horizon. Premiera jest jednak odległa
 - [https://ithardware.pl/aktualnosci/sony_ma_szykowac_mmo_w_swiecie_horizon_premiera_jest_jednak_odlegla-30928.html](https://ithardware.pl/aktualnosci/sony_ma_szykowac_mmo_w_swiecie_horizon_premiera_jest_jednak_odlegla-30928.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T11:38:01+00:00

<img src="https://ithardware.pl/artykuly/min/30928_1.jpg" />            W 2022 roku wiele źr&oacute;deł zaczęło donosić, że Sony wsp&oacute;łpracuje z wydawcą gier MMO NCSoft w zakresie przyszłych projekt&oacute;w online, w tym nowej gry MMO opartej na uniwersum Horizon. Sony potwierdziło wsp&oacute;łpracę z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sony_ma_szykowac_mmo_w_swiecie_horizon_premiera_jest_jednak_odlegla-30928.html">https://ithardware.pl/aktualnosci/sony_ma_szykowac_mmo_w_swiecie_horizon_premiera_jest_jednak_odlegla-30928.html</a></p>

## Galaxy S24 Ultra może znacząco poprawić jakość nagrań wideo
 - [https://ithardware.pl/aktualnosci/galaxy_s24_ultra_moze_znaczaco_poprawic_jakosc_nagran_wideo-30933.html](https://ithardware.pl/aktualnosci/galaxy_s24_ultra_moze_znaczaco_poprawic_jakosc_nagran_wideo-30933.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T11:02:10+00:00

<img src="https://ithardware.pl/artykuly/min/30933_1.jpg" />            Samsung podobno testuje nowy tryb nagrywania wideo w smartfonie Galaxy S24 Ultra. Nadchodzący flagowiec marki może zaoferować opcję nagrywania w rozdzielczości 4K przy 120 FPS.

4K 120 FPS

Jeśli wierzyć dotychczasowym doniesieniom to premiera...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/galaxy_s24_ultra_moze_znaczaco_poprawic_jakosc_nagran_wideo-30933.html">https://ithardware.pl/aktualnosci/galaxy_s24_ultra_moze_znaczaco_poprawic_jakosc_nagran_wideo-30933.html</a></p>

## Dokumentacja ujawnia potencjalnego Radeona RX 7800M i inne niewydane karty AMD
 - [https://ithardware.pl/aktualnosci/dokumentacja_ujawniaja_potencjalnego_radeona_rx_7800m_i_innych_niewydanych_kart_amd-30927.html](https://ithardware.pl/aktualnosci/dokumentacja_ujawniaja_potencjalnego_radeona_rx_7800m_i_innych_niewydanych_kart_amd-30927.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T10:06:01+00:00

<img src="https://ithardware.pl/artykuly/min/30927_1.jpg" />            43 procesory graficzne AMD Navi pojawiły się pod nazwami kodowymi &bdquo;Cuarzo (Quartz)&rdquo;w trzech odmianach &bdquo;Cuarzo Rojo&rdquo;, &bdquo;Cuarzo Verde&rdquo; i &bdquo;Cuarzo Azul&rdquo;.

Uznany informator, znany na platformie X jako...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dokumentacja_ujawniaja_potencjalnego_radeona_rx_7800m_i_innych_niewydanych_kart_amd-30927.html">https://ithardware.pl/aktualnosci/dokumentacja_ujawniaja_potencjalnego_radeona_rx_7800m_i_innych_niewydanych_kart_amd-30927.html</a></p>

## Sztuczna inteligencja przynosi ogromne pieniądze. Prognozy dla ChatGPT znacznie powyżej oczekiwań
 - [https://ithardware.pl/aktualnosci/sztuczna_inteligencja_przynosi_ogromne_pieniadze_prognozy_dla_chatgpt_znacznie_powyzej_oczekiwan-30930.html](https://ithardware.pl/aktualnosci/sztuczna_inteligencja_przynosi_ogromne_pieniadze_prognozy_dla_chatgpt_znacznie_powyzej_oczekiwan-30930.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T09:52:30+00:00

<img src="https://ithardware.pl/artykuly/min/30930_1.jpg" />            Po szaleństwie na ChatGPT sztuczna inteligencja była postrzegana jako boom, kt&oacute;ry minie jak wiele technologii. Zainteresowanie wcale jednak nie spada, a technologia rozwija się i przynosi coraz więcej pieniędzy.

Na sztuczną inteligencję...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sztuczna_inteligencja_przynosi_ogromne_pieniadze_prognozy_dla_chatgpt_znacznie_powyzej_oczekiwan-30930.html">https://ithardware.pl/aktualnosci/sztuczna_inteligencja_przynosi_ogromne_pieniadze_prognozy_dla_chatgpt_znacznie_powyzej_oczekiwan-30930.html</a></p>

## GeForce RTX 3050 z 6 GB coraz bliżej. Palit szykuje nawet pasywnie chłodzony wariant
 - [https://ithardware.pl/aktualnosci/geforce_rtx_3050_z_6_gb_coraz_blizej_palit_szykuje_nawet_pasywnie_chlodzony_wariant-30926.html](https://ithardware.pl/aktualnosci/geforce_rtx_3050_z_6_gb_coraz_blizej_palit_szykuje_nawet_pasywnie_chlodzony_wariant-30926.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T09:25:02+00:00

<img src="https://ithardware.pl/artykuly/min/30926_1.jpg" />            Palit przygotowuje trzy karty GeForce RTX 3050 z 6 GB pamięci VRAM na pokładzie, zamiast standardowych 8 GB. Dwa modele należą do serii StormX, a jeden do KalmX. Co ciekawe, jedna z grafik jest chłodzona pasywnie.

GeForce RTX 3050 z 6 GB...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_3050_z_6_gb_coraz_blizej_palit_szykuje_nawet_pasywnie_chlodzony_wariant-30926.html">https://ithardware.pl/aktualnosci/geforce_rtx_3050_z_6_gb_coraz_blizej_palit_szykuje_nawet_pasywnie_chlodzony_wariant-30926.html</a></p>

## Spieszcie się z zakupem. Ceny dysków SSD mogą szybko podrożeć
 - [https://ithardware.pl/aktualnosci/spieszcie_sie_z_zakupem_ceny_dyskow_ssd_moga_szybko_podrozec-30924.html](https://ithardware.pl/aktualnosci/spieszcie_sie_z_zakupem_ceny_dyskow_ssd_moga_szybko_podrozec-30924.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T08:53:50+00:00

<img src="https://ithardware.pl/artykuly/min/30924_1.jpg" />            Oczekuje się, że ceny pamięci NAND flash wzrosną w kr&oacute;tkim okresie nawet o 50 procent, co ostatecznie przełoży się na droższe dyski p&oacute;łprzewodnikowe. Jeśli więc myślicie nad zakupem nowego dysku SSD, to nie warto już odkładać...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/spieszcie_sie_z_zakupem_ceny_dyskow_ssd_moga_szybko_podrozec-30924.html">https://ithardware.pl/aktualnosci/spieszcie_sie_z_zakupem_ceny_dyskow_ssd_moga_szybko_podrozec-30924.html</a></p>

## Rockstar planował osiem singlowych dodatków do GTA V. Kilka zapowiadało się naprawdę ciekawie
 - [https://ithardware.pl/aktualnosci/rockstar_planowal_osiem_singlowych_dodatkow_do_gta_v_kilka_zapowiadala_sie_naprawde_ciekawie-30923.html](https://ithardware.pl/aktualnosci/rockstar_planowal_osiem_singlowych_dodatkow_do_gta_v_kilka_zapowiadala_sie_naprawde_ciekawie-30923.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T08:22:50+00:00

<img src="https://ithardware.pl/artykuly/min/30923_1.jpg" />            Niedawno, zaledwie kilka tygodni po ogłoszeniu Grand Theft Auto VI, w sieci opublikowano pliki wykradzione z serwer&oacute;w Rockstara, w tym kod źr&oacute;dłowy Grand Theft Auto V. Analitycy danych przeczesywali kod, znajdując odniesienia do DLC...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rockstar_planowal_osiem_singlowych_dodatkow_do_gta_v_kilka_zapowiadala_sie_naprawde_ciekawie-30923.html">https://ithardware.pl/aktualnosci/rockstar_planowal_osiem_singlowych_dodatkow_do_gta_v_kilka_zapowiadala_sie_naprawde_ciekawie-30923.html</a></p>

## Rosja pokazuje pogromcę Tesli. Takiego elektryka jeszcze nie widzieliście
 - [https://ithardware.pl/aktualnosci/rosja_pokazuje_pogromce_tesli_takiego_elektryka_jeszcze_nie_widzieliscie-30925.html](https://ithardware.pl/aktualnosci/rosja_pokazuje_pogromce_tesli_takiego_elektryka_jeszcze_nie_widzieliscie-30925.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T08:19:50+00:00

<img src="https://ithardware.pl/artykuly/min/30925_1.jpg" />            Po rosyjskiej inwazji na Ukrainę, większość producent&oacute;w samochod&oacute;w wycofała swoje operacje z Rosji, co pozostawiło puste fabryki. Jednak Politechnika Moskiewska zaproponowała&nbsp;rozwiązanie: własny&nbsp;samoch&oacute;d...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rosja_pokazuje_pogromce_tesli_takiego_elektryka_jeszcze_nie_widzieliscie-30925.html">https://ithardware.pl/aktualnosci/rosja_pokazuje_pogromce_tesli_takiego_elektryka_jeszcze_nie_widzieliscie-30925.html</a></p>

## Steam nie wspiera już starszych edycji systemu Windows. Potrzeba Windows 10 lub 11
 - [https://ithardware.pl/aktualnosci/steam_nie_wspiera_juz_starszych_edycji_systemu_windows_potrzeba_windows_10_lub_11-30922.html](https://ithardware.pl/aktualnosci/steam_nie_wspiera_juz_starszych_edycji_systemu_windows_potrzeba_windows_10_lub_11-30922.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-01-02T07:21:28+00:00

<img src="https://ithardware.pl/artykuly/min/30922_1.jpg" />            Valve w końcu porzuca systemy operacyjne Windows 7, 8 i 8.1. Od 1 stycznia 2024 r. wcześniejsze edycje OS Microsoftu niż Windows 10 nie są już wspierane. Jeśli więc nadal chcecie otrzymywać aktualizacje Steam (w tym poprawki zabezpieczeń) i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/steam_nie_wspiera_juz_starszych_edycji_systemu_windows_potrzeba_windows_10_lub_11-30922.html">https://ithardware.pl/aktualnosci/steam_nie_wspiera_juz_starszych_edycji_systemu_windows_potrzeba_windows_10_lub_11-30922.html</a></p>

