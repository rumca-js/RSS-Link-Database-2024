# Source:Techdirt, URL:https://www.techdirt.com/feed/, language:en-US

## FTC Continues To Wade Into Copyright Issues In AI Without Understanding Anything
 - [https://www.techdirt.com/2024/01/02/ftc-continues-to-wade-into-copyright-issues-in-ai-without-understanding-anything](https://www.techdirt.com/2024/01/02/ftc-continues-to-wade-into-copyright-issues-in-ai-without-understanding-anything)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2024-01-02T23:05:42+00:00

Last year we were dismayed (and somewhat annoyed) to see the FTC step way beyond its bounds and expertise by issuing a ridiculous comment to the US Copyright Office regarding questions around AI and copyright. In it, the FTC (which has no authority — or expertise — regarding copyright law) argued that fair use was [&#8230;]

## The Unperson Of 2023
 - [https://www.techdirt.com/2024/01/02/the-unperson-of-2023](https://www.techdirt.com/2024/01/02/the-unperson-of-2023)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2024-01-02T20:45:28+00:00

2023 is over. Taylor Swift was Time’s Person of the Year, beating out candidates like Jerome Powell, who may have stuck the economic soft-landing, but can’t hit the high notes. Only a fool would challenge the decision, but I would like to nominate 2023’s Unperson of the year – ChatGPT; the neural-network based, Large Language [&#8230;]

## FTC Hits Pharmacy Retail Chain Rite Aid With A Five-Year Facial Recognition Tech Ban
 - [https://www.techdirt.com/2024/01/02/ftc-hits-pharmacy-retail-chain-rite-aid-with-a-five-year-facial-recognition-tech-ban](https://www.techdirt.com/2024/01/02/ftc-hits-pharmacy-retail-chain-rite-aid-with-a-five-year-facial-recognition-tech-ban)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2024-01-02T18:50:00+00:00

Facial recognition tech works best on white, male faces. White males have historically been the immediate beneficiaries of public policy, as well as those put in place by private companies. I say &#8220;historically,&#8221; but this advantageous situation has mostly proven incapable of being disrupted by tech advances. Facial recognition tech has taken an existing problem [&#8230;]

## ExTwitter Unfortunately Loses Round One In Challenging Problematic Content Moderation Law
 - [https://www.techdirt.com/2024/01/02/extwitter-unfortunately-loses-round-one-in-challenging-problematic-content-moderation-law](https://www.techdirt.com/2024/01/02/extwitter-unfortunately-loses-round-one-in-challenging-problematic-content-moderation-law)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2024-01-02T17:23:46+00:00

Back in September we praised Elon Musk for deciding to challenge California’s new social media transparency law, AB 587. As we had discussed while the bill was being debated, while it’s framed as a transparency bill, it has all sorts of problems. It would (1) enable the California government officials (including local officials) to effectively [&#8230;]

## Cox Distances Itself From Claim It Spies On Users Via Phones, Cable Box Mics
 - [https://www.techdirt.com/2024/01/02/cox-distances-itself-from-claim-it-spies-on-users-via-phones-cable-box-mics](https://www.techdirt.com/2024/01/02/cox-distances-itself-from-claim-it-spies-on-users-via-phones-cable-box-mics)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2024-01-02T13:26:20+00:00

For years, the cable industry has dreamed of a future where they could use your cable box to actively track your every behavior using cameras and microphones and then monetize the data. At one point way back in 2009, Comcast made it clear they were even interested in using embedded microphones and cameras to monitor [&#8230;]

