# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Hawaii man accused of attempted murder steals car at gunpoint, dies after firefight with police
 - [https://www.foxnews.com/us/hawaii-man-accused-attempted-murder-steals-car-gunpoint-dies-firefight-police](https://www.foxnews.com/us/hawaii-man-accused-attempted-murder-steals-car-gunpoint-dies-firefight-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T23:29:17+00:00

A Hawaii man wanted for attempted murder was fatally shot Monday by police after stealing a car at gunpoint and opening fire on officers.

## State employees get reprieve from Nebraska Gov. Pillen's return-to-office order
 - [https://www.foxnews.com/politics/state-employees-reprieve-nebraska-gov-pillens-return-to-office-order](https://www.foxnews.com/politics/state-employees-reprieve-nebraska-gov-pillens-return-to-office-order)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T23:27:50+00:00

Nebraska state government employees have been granted a temporary reprieve from Republican Gov. Jim Pillen&apos;s order unilaterally ending remote work.

## Victims of Michigan home explosion identified as 4 Arkansans visiting family
 - [https://www.foxnews.com/us/victims-michigan-home-explosion-identified-4-arkansans-visiting-family](https://www.foxnews.com/us/victims-michigan-home-explosion-identified-4-arkansans-visiting-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T23:25:49+00:00

The four people killed in a weekend explosion at a Michigan home have been identified as members of the Bragg family of Monticello, Arkansas.

## Colorado gun group sues state over 'ghost gun' ban
 - [https://www.foxnews.com/politics/colorado-gun-group-sues-state-ghost-gun-ban](https://www.foxnews.com/politics/colorado-gun-group-sues-state-ghost-gun-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T23:10:11+00:00

A Colorado gun advocacy group, the Rocky Mountain Gun Owners, announced a lawsuit against the state, challenging a law that bans ghost guns from being possessed.

## Chris Rufo responds to Harvard president's resignation: 'Glad she's gone'
 - [https://www.foxnews.com/media/chris-rufo-responds-harvard-presidents-resignation-glad-shes-gone](https://www.foxnews.com/media/chris-rufo-responds-harvard-presidents-resignation-glad-shes-gone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T23:00:16+00:00

Critical race theory critic Christopher Rufo blasted Harvard President Claudine Gay’s resignation letter on Tuesday for referencing “racial animus&quot; as a factor.

## Super Bowl champ Odell Beckham Jr makes bold statement about surging Ravens: 'Best team I've been on'
 - [https://www.foxnews.com/sports/super-bowl-champ-odell-beckham-jr-makes-bold-statement-about-surging-ravens-best-team](https://www.foxnews.com/sports/super-bowl-champ-odell-beckham-jr-makes-bold-statement-about-surging-ravens-best-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:54:55+00:00

The Ravens locker room was in a celebratory mood on Sunday. Baltimore earned the conference&apos;s top seed, but Odell Beckham Jr. still managed to surprise some of his teammates.

## Appeals court delivers fatal blow to California city pushing natural gas ban
 - [https://www.foxnews.com/politics/appeals-court-delivers-fatal-blow-california-city-pushing-natural-gas-ban](https://www.foxnews.com/politics/appeals-court-delivers-fatal-blow-california-city-pushing-natural-gas-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:50:09+00:00

A federal appeals panel handed a fatal blow to an ordinance passed by the City of Berkeley, California, that would have banned new natural gas hookups in buildings.

## Judge dismisses three civil counts against Trump, others over death of Jan. 6 Officer Brian Sicknick
 - [https://www.foxnews.com/politics/judge-dismisses-three-civil-counts-against-trump-others-over-death-jan-6-officer-brian-sicknick](https://www.foxnews.com/politics/judge-dismisses-three-civil-counts-against-trump-others-over-death-jan-6-officer-brian-sicknick)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:28:53+00:00

A federal judge on Tuesday dismissed most counts in a civil suit against Donald Trump and two other men in connection with the death of U.S. Capitol Police Officer Brian Sicknick.

## New ordinance makes stopping, standing on Las Vegas Strip pedestrian bridges a potential misdemeanor
 - [https://www.foxnews.com/politics/new-ordinance-makes-stopping-standing-las-vegas-strip-pedestrian-bridges-potential-misdemeanor](https://www.foxnews.com/politics/new-ordinance-makes-stopping-standing-las-vegas-strip-pedestrian-bridges-potential-misdemeanor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:20:44+00:00

Stopping or standing on the Las Vegas Strip&apos;s crowded pedestrian bridges can now amount to a misdemeanor under a newly-approved ordinance.

## Trump appeals decision to ban him from Maine ballot
 - [https://www.foxnews.com/politics/trump-appeals-decision-ban-him-maine-ballot](https://www.foxnews.com/politics/trump-appeals-decision-ban-him-maine-ballot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:18:06+00:00

Former President Donald Trump appealed a decision in Maine that prohibited him from appearing on the ballot later this year because of his alleged role on Jan. 6, 2021.

## Kansas City closes 2023 with record homicide count; St. Louis reports about 20% reduction
 - [https://www.foxnews.com/us/kansas-city-closes-2023-record-homicide-count-st-louis-reports-20-reduction](https://www.foxnews.com/us/kansas-city-closes-2023-record-homicide-count-st-louis-reports-20-reduction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:16:43+00:00

Kansas City, Missouri, reported a record homicide tally in 2023, while a significant drop was reported in St. Louis on the opposite end of the Show-Me State.

## Federal appeals court denies Michael Cohen's attempt to revive lawsuit against Trump
 - [https://www.foxnews.com/politics/federal-appeals-court-denies-michael-cohens-attempt-revive-lawsuit-against-trump](https://www.foxnews.com/politics/federal-appeals-court-denies-michael-cohens-attempt-revive-lawsuit-against-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:14:20+00:00

A federal appeals court on Tuesday denied Michael Cohen’s attempt to revive his lawsuit against former President Trump in which he claimed he was jailed in retaliation for writing a tell-all book.

## Texas toddler helps feed family dogs, asks them to ‘say grace’ before releasing them with ‘amen’
 - [https://www.foxnews.com/lifestyle/texas-toddler-helps-feed-family-dogs-asks-them-say-grace-before-releasing-them-amen](https://www.foxnews.com/lifestyle/texas-toddler-helps-feed-family-dogs-asks-them-say-grace-before-releasing-them-amen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:05:00+00:00

A Texas toddler went viral on Instagram for telling her three family dogs to &apos;say grace&apos; before letting them eat dinner. Watch her feed the pups after &apos;Amen!&apos;

## Federal inmate dies after 'perceived altercation' at West Virginia prison
 - [https://www.foxnews.com/us/federal-inmate-dies-perceived-altercation-west-virginia-prison](https://www.foxnews.com/us/federal-inmate-dies-perceived-altercation-west-virginia-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:03:31+00:00

Andrew Davis, a 39-year-old inmate at FCI Beckley in West Virginia, has been reported dead following an altercation with another prisoner.

## North Carolina presidential primary candidates have been finalized; a Trump challenge is on appeal
 - [https://www.foxnews.com/politics/north-carolina-presidential-primary-candidates-finalized-trump-challenge-appeal](https://www.foxnews.com/politics/north-carolina-presidential-primary-candidates-finalized-trump-challenge-appeal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T22:01:12+00:00

Unanimous vote by the NC State Board of Elections keeps the three major parties&apos; candidate lists intact; leaves Joe Biden as the lone Democrat.

## Singer-songwriter Ciara, wife of Russell Wilson, finds out she's related to Derek Jeter: 'You are kidding me'
 - [https://www.foxnews.com/sports/singer-songwriter-ciara-wife-russell-wilson-related-derek-jeter-you-are-kidding-me](https://www.foxnews.com/sports/singer-songwriter-ciara-wife-russell-wilson-related-derek-jeter-you-are-kidding-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:58:21+00:00

Singer-songwriter Ciara found out on a recent episode of PBS&apos; &quot;Finding Your Roots&quot; that she is a distant relative of MLB legend Derek Jeter.

## Democrat Sen. Bob Menendez accused of accepting bribes to benefit Qatar in superseding federal indictment
 - [https://www.foxnews.com/politics/democrat-sen-bob-menendez-charged-accepting-bribes-benefit-qatar-superseding-federal-indictment](https://www.foxnews.com/politics/democrat-sen-bob-menendez-charged-accepting-bribes-benefit-qatar-superseding-federal-indictment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:58:05+00:00

U.S. Sen. Robert Menendez, D-New Jersey, is facing additional accusations, the Justice Department said Tuesday.

## Tom Girardi, ex ‘Housewives’ husband and disgraced lawyer, declared competent to stand trial
 - [https://www.foxnews.com/entertainment/tom-girardi-ex-housewives-husband-disgraced-lawyer-declared-competent-stand-trial](https://www.foxnews.com/entertainment/tom-girardi-ex-housewives-husband-disgraced-lawyer-declared-competent-stand-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:55:30+00:00

A federal judge in Los Angeles has found Thomas Girardi, the disgraced attorney and former &apos;Real Housewives of Beverly Hills&apos; husband, competent to stand trial.

## Heading to Iowa, Noem says she'll do 'whatever I can' to help Trump get 'across finish line'
 - [https://www.foxnews.com/politics/heading-iowa-noem-says-shell-do-whatever-i-can-help-trump-get-across-finish-line](https://www.foxnews.com/politics/heading-iowa-noem-says-shell-do-whatever-i-can-help-trump-get-across-finish-line)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:55:27+00:00

South Dakota Gov. Kristi Noem to campaign for former President Donald Trump Wednesday in Iowa. Noem reiterates that she&apos;ll &apos;consider&apos; an offer to serve as the 2024 GOP running mate.

## Titans coach Mike Vrabel gives fiery response to reporter's question: 'It f---ing sucks losing'
 - [https://www.foxnews.com/sports/titans-coach-mike-vrabel-fiery-response-reporters-question](https://www.foxnews.com/sports/titans-coach-mike-vrabel-fiery-response-reporters-question)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:50:26+00:00

Tennessee Titans head coach Mike Vrabel was asked why he wants to win Sunday&apos;s regular season finale despite no playoffs in sight, and he gave a passionate response.

## Steelers' Kenny Pickett denies report he 'refused' to be backup, says rumor was 'attacking my character'
 - [https://www.foxnews.com/sports/steelers-kenny-pickett-denies-report-refused-backup-says-rumor-was-attacking-my-character](https://www.foxnews.com/sports/steelers-kenny-pickett-denies-report-refused-backup-says-rumor-was-attacking-my-character)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:43:34+00:00

Kenny Pickett was medically cleared to return just prior to the Steelers&apos; Week 17 game, but he did not play, which sparked a rumor that he &quot;refused&quot; to back up Mason Rudolph.

## Biden DOJ seeks Supreme Court intervention over Texas razor wire at southern border
 - [https://www.foxnews.com/politics/biden-doj-seeks-supreme-court-intervention-over-texas-razor-wire-at-southern-border](https://www.foxnews.com/politics/biden-doj-seeks-supreme-court-intervention-over-texas-razor-wire-at-southern-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:43:11+00:00

The Department of Justice on Tuesday asked the Supreme Court to intervene in its dispute with Texas over the construction of razor wire at the southern border.

## Republican WV delegate Caleb Hanna resigns to focus on state auditor campaign
 - [https://www.foxnews.com/politics/republican-wv-delegate-caleb-hanna-resigns-focus-state-auditor-campaign](https://www.foxnews.com/politics/republican-wv-delegate-caleb-hanna-resigns-focus-state-auditor-campaign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:36:11+00:00

Republican West Virginia Del. Caleb Hanna, who made headlines after being elected at 19 as America&apos;s youngest Black state officeholder, is resigning to pursue his state auditor bid.

## China floats plan to foster economic ties with Democrat-led cities: report
 - [https://www.foxnews.com/world/china-floats-plan-to-foster-economic-ties-democrat-led-cities](https://www.foxnews.com/world/china-floats-plan-to-foster-economic-ties-democrat-led-cities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:32:34+00:00

China wants to bolster economic ties with two American Democra-led cities -- New York and San Francisco -- according to Chinese media reports.

## Indiana man breaks silence after being trapped in truck for nearly a week and rescued by good Samaritans
 - [https://www.foxnews.com/us/indiana-man-breaks-silence-being-trapped-truck-week-rescued-good-samaritans](https://www.foxnews.com/us/indiana-man-breaks-silence-being-trapped-truck-week-rescued-good-samaritans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:09:48+00:00

Indiana man who was trapped in crashed truck for nearly a week before getting rescued, broke his silence on Sunday to say thanks to everyone for their support.

## Former bridesmaid asks if she would be wrong to skip bridal shower after she's disinvited from wedding
 - [https://www.foxnews.com/lifestyle/former-bridesmaid-asks-she-wrong-skip-bridal-shower-disinvited-wedding](https://www.foxnews.com/lifestyle/former-bridesmaid-asks-she-wrong-skip-bridal-shower-disinvited-wedding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T21:01:51+00:00

A Reddit user was reassured that she was not in the wrong for not wanting to attend a bridal shower after being uninvited to the wedding and removed from the bridal party.

## Off-duty Arkansas officer kills shoplifting suspect who attacked him with a knife, police say
 - [https://www.foxnews.com/us/off-duty-arkansas-officer-kills-shoplifting-suspect-attacked-knife-police-say](https://www.foxnews.com/us/off-duty-arkansas-officer-kills-shoplifting-suspect-attacked-knife-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:57:52+00:00

An Arkansas shoplifting suspect was fatally shot on New Year&apos;s Eve, following an incident in which he pulled out a knife and stabbed an officer in the hand.

## Jets release Dalvin Cook after signing him as highest-paid free agent running back this offseason
 - [https://www.foxnews.com/sports/jets-release-dalvin-cook-signing-him-highest-paid-free-agent-running-back-offseason](https://www.foxnews.com/sports/jets-release-dalvin-cook-signing-him-highest-paid-free-agent-running-back-offseason)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:45:02+00:00

The New York Jets are releasing running back Dalvin Cook after signing him to the most lucrative free agent contract at the position this offseason.

## Temps plummet to 40 below zero amid bitter Scandinavian cold spell
 - [https://www.foxnews.com/world/temps-plummet-40-below-zero-bitter-scandinavian-cold-spell](https://www.foxnews.com/world/temps-plummet-40-below-zero-bitter-scandinavian-cold-spell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:37:35+00:00

Temperatures as low as minus 40 Fahrenheit were reported in parts of Sweden and Finland on Tuesday as the Arctic North grapples with an intense cold spell.

## Is buying art a good investment? A guide to what makes art valuable and where to buy
 - [https://www.foxnews.com/lifestyle/invest-collectable-art](https://www.foxnews.com/lifestyle/invest-collectable-art)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:25:40+00:00

Collecting artwork can be a great way to decorate your home and potentially make you money down the road. This guide will help you better understand how to buy artwork.

## Small earthquake hits NYC causing buildings to shake
 - [https://www.foxnews.com/us/small-earthquake-hits-nyc-causing-buildings-shake](https://www.foxnews.com/us/small-earthquake-hits-nyc-causing-buildings-shake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:20:47+00:00

A 1.7 magnitude earthquake struck New York City Tuesday morning with residents on the East River&apos;s Roosevelt Island reporting hearing a loud explosion and buildings shaking.

## Tom Brady agrees with Jim Harbaugh calling JJ McCarthy Michigan’s greatest quarterback: ‘No doubt!!!’
 - [https://www.foxnews.com/sports/tom-brady-agrees-jim-harbaugh-calling-jj-mccarthy-michigan-greatest-quarterback](https://www.foxnews.com/sports/tom-brady-agrees-jim-harbaugh-calling-jj-mccarthy-michigan-greatest-quarterback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:18:57+00:00

Tom Brady approved of Michigan head coach Jim Harbaugh calling J.J. McCarthy the &quot;greatest&quot; quarterback in Wolverines history following his Rose Bowl win over Alabama.

## Somali president rejects land deal granting Ethiopia coastal access
 - [https://www.foxnews.com/world/somali-president-rejects-land-deal-granting-ethiopia-coastal-access](https://www.foxnews.com/world/somali-president-rejects-land-deal-granting-ethiopia-coastal-access)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:15:09+00:00

Somali President Hassan Sheikh Mohamud on Tuesday rejected an agreement that would have granted landlocked Ethiopia access to the coast of breakaway Somaliland.

## MLB legend David Ortiz whiffs during gender reveal
 - [https://www.foxnews.com/sports/mlb-legend-david-ortiz-whiffs-gender-reveal](https://www.foxnews.com/sports/mlb-legend-david-ortiz-whiffs-gender-reveal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:06:52+00:00

Red Sox legend David Ortiz may be a Hall of Famer, but he didn&apos;t exactly put his skills to use during a recent gender reveal of his fifth child.

## Fox News Politics: Gay resignation
 - [https://www.foxnews.com/politics/fox-news-politics-gay-resignation](https://www.foxnews.com/politics/fox-news-politics-gay-resignation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:01:54+00:00

The latest updates from the 2024 campaign trail, exclusive interviews and more Fox News politics content

## Sen. Ron Johnson warns 'the radical left has infiltrated every institution in this country'
 - [https://www.foxnews.com/media/ron-johnson-warns-radical-left-infiltrated-every-institution-country](https://www.foxnews.com/media/ron-johnson-warns-radical-left-infiltrated-every-institution-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T20:00:26+00:00

Sen. Ron Johnson believes the effort to remove former President Trump from states&apos; ballots is further evidence of the left trying to &quot;tear this country apart.&quot;

## Ruby-red Kentucky begins new legislative session with budget talks, policy clashes on horizon
 - [https://www.foxnews.com/politics/ruby-red-kentucky-begins-new-legislative-session-budget-talks-policy-clashes-horizon](https://www.foxnews.com/politics/ruby-red-kentucky-begins-new-legislative-session-budget-talks-policy-clashes-horizon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:59:23+00:00

Kentucky lawmakers returned to Frankfort on Tuesday for a 60-day legislative session, where a two-year budget proposal is set to be drafted.

## Suburban DC jolted by small earthquake
 - [https://www.foxnews.com/us/suburban-dc-jolted-small-earthquake](https://www.foxnews.com/us/suburban-dc-jolted-small-earthquake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:57:48+00:00

A small earthquake rattled Washington, D.C.&apos;s eastern suburbs early Tuesday, centered near Rockville, Maryland, and clocking in at 2.3 on the Richter Scale.

## Taylor Swift, Travis Kelce's best moments; Billy Joel says ‘nobody’ wants to purchase $49 million mansion
 - [https://www.foxnews.com/entertainment/taylor-swift-travis-kelces-billy-joel-49-million-mansion](https://www.foxnews.com/entertainment/taylor-swift-travis-kelces-billy-joel-49-million-mansion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:57:16+00:00

The Fox News Entertainment newsletter brings you the latest Hollywood headlines, celebrity interviews and stories from Los Angeles and beyond.

## 3 dead after fleeing suspect crashes near Wisconsin's capital
 - [https://www.foxnews.com/us/3-dead-fleeing-suspect-crashes-wisconsin-capital](https://www.foxnews.com/us/3-dead-fleeing-suspect-crashes-wisconsin-capital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:54:51+00:00

A suspect fleeing a Monona, Wisconsin, traffic stop crashed Monday night following a police chase, killing all three people in their vehicle.

## 'View' host says Democrats taking Trump off state ballots will create appearance of 'a rigged election'
 - [https://www.foxnews.com/media/view-host-democrats-taking-trump-state-ballots-create-appearance-rigged-election](https://www.foxnews.com/media/view-host-democrats-taking-trump-state-ballots-create-appearance-rigged-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:51:42+00:00

&quot;The View&quot; co-host Sara Haines argued that by states taking Donald Trump off their state ballots they were creating the appearance of a &quot;rigged election.&quot;

## Texas supporter 'Mattress Mack' loses big after Longhorns fall to Washington in CFP semifinal game
 - [https://www.foxnews.com/sports/texas-supporter-mattress-mack-loses-big-after-longhorns-fall-washington-cfp-semifinal-game](https://www.foxnews.com/sports/texas-supporter-mattress-mack-loses-big-after-longhorns-fall-washington-cfp-semifinal-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:40:45+00:00

Houston furniture store magnate Jim Mattress Mack&quot; McIngvale once again placed a sizable bet on a Texas sports team to win the championship. This time he bet big on the Longhorns.

## Critics cheer resignation of 'antisemitic plagiarist' Harvard president Claudine Gay: 'Bye Felicia'
 - [https://www.foxnews.com/politics/critics-cheer-resignation-antisemitic-plagiarist-harvard-president-claudine-gay](https://www.foxnews.com/politics/critics-cheer-resignation-antisemitic-plagiarist-harvard-president-claudine-gay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:35:13+00:00

Critics celebrated Harvard president Claudine Gay&apos;s announcement that she would resign amid allegations of plagiarism and a sharp backlash against her response to antisemitism.

## Karine Jean-Pierre claims Americans need to give 'Bidenomics' more 'time,' blames lack of support on pandemic
 - [https://www.foxnews.com/media/karine-jean-pierre-claims-americans-need-give-bidenomics-time-blames-lack-support-pandemic](https://www.foxnews.com/media/karine-jean-pierre-claims-americans-need-give-bidenomics-time-blames-lack-support-pandemic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:30:00+00:00

White House Press Secretary Karine Jean-Pierre said Tuesday that President Biden&apos;s economic policies still needed more time to take effect, three years into his presidency.

## Judge rules former clerk who refused to issue same-sex marriage licenses must pay $260,000 legal expenses
 - [https://www.foxnews.com/politics/judge-rules-former-clerk-refused-issue-same-sex-marriage-licenses-pay-260000-legal-expenses](https://www.foxnews.com/politics/judge-rules-former-clerk-refused-issue-same-sex-marriage-licenses-pay-260000-legal-expenses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:28:08+00:00

Former Kentucky clerk Kim Davis must pay over $260,000 in attorneys fees and expenses after she refused to certify a same-sex couple&apos;s marriage.

## Vivek Ramaswamy blasts CNN debate over exclusion, says only ‘establishment insiders’ will be on stage
 - [https://www.foxnews.com/media/vivek-ramaswamy-blasts-cnn-debate-over-exclusion-only-establishment-insiders-stage](https://www.foxnews.com/media/vivek-ramaswamy-blasts-cnn-debate-over-exclusion-only-establishment-insiders-stage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:28:08+00:00

Vivek Ramaswamy will participate in his own town hall event next week the same night that CNN is set to host a Republican presidential primary debate in Iowa.

## Israel defense minister says several thousand Hamas fighters remain in Gaza
 - [https://www.foxnews.com/world/israel-defense-minister-says-several-thousand-hamas-fighters-remain-gaza](https://www.foxnews.com/world/israel-defense-minister-says-several-thousand-hamas-fighters-remain-gaza)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:24:27+00:00

Israel Defense Minister Yoav Gallant says Hamas still has several thousand fighters left in Gaza, but the terrorist group’s capabilities are diminished.

## Dancing Bears Festival in Romania draws global tourism each year
 - [https://www.foxnews.com/world/dancing-bears-festival-romania-draws-global-tourism-year](https://www.foxnews.com/world/dancing-bears-festival-romania-draws-global-tourism-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:10:57+00:00

The Dancing Bears Festival in Comanesti, a small town in northeast Romania, attracts visitors from around the world. The annual event is rooted in a centuries-old tradition.

## Climate activists who chased Buttigieg, Powell off stages rewarded with private White House meeting
 - [https://www.foxnews.com/politics/climate-activists-who-chased-buttigieg-powell-off-stages-rewarded-private-white-house-meeting](https://www.foxnews.com/politics/climate-activists-who-chased-buttigieg-powell-off-stages-rewarded-private-white-house-meeting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:07:37+00:00

A growing climate protest group that opposes all fossil fuel development was given a private meeting with John Podesta, President Biden&apos;s top clean energy adviser, last month.

## 2 dead, including robbery suspect, in Missouri wrong-way crash
 - [https://www.foxnews.com/us/2-dead-robbery-suspect-missouri-wrong-way-crash](https://www.foxnews.com/us/2-dead-robbery-suspect-missouri-wrong-way-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:04:31+00:00

Two people, including a suspect wanted in connection with up to three robberies, were killed in a wrong-way vehicle collision in Kansas City, Missouri.

## Chip Roy to skip House GOP border trip, says Texas is 'tired' of 'press conferences'
 - [https://www.foxnews.com/politics/chip-roy-to-skip-house-gop-border-trip-says-texas-is-tired-of-press-conferences](https://www.foxnews.com/politics/chip-roy-to-skip-house-gop-border-trip-says-texas-is-tired-of-press-conferences)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T19:00:56+00:00

Rep. Chip Roy, R-Texas, announced Tuesday that he will not join fellow House Republicans in a planned trip to the southern border.

## Washington players get into heated confrontation with Texas fans after Sugar Bowl win
 - [https://www.foxnews.com/sports/washington-players-get-heated-confrontation-texas-fans-sugar-bowl-win](https://www.foxnews.com/sports/washington-players-get-heated-confrontation-texas-fans-sugar-bowl-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:58:53+00:00

Washington Huskies players were seen getting into a tiff with Texas Longhorns fans after their Sugar Bowl win on Monday night. Washington will play for a national title.

## New COVID variant JN.1 now comprises up to 30% of US cases: CDC
 - [https://www.foxnews.com/health/new-covid-variant-jn1-comprises-us-cases-cdc](https://www.foxnews.com/health/new-covid-variant-jn1-comprises-us-cases-cdc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:56:28+00:00

The latest variant of the COVID-19 virus, JN.1, is now responsible for an estimated 15% to 29% of U.S. cases as of Dec. 8, according to the CDC. Here&apos;s what you need to know.

## Indiana woman saved after being trapped in car that flipped over in crash on dark, quiet road
 - [https://www.foxnews.com/us/indiana-woman-saved-trapped-car-flipped-crash-dark-quiet-road](https://www.foxnews.com/us/indiana-woman-saved-trapped-car-flipped-crash-dark-quiet-road)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:54:40+00:00

Mechanic Greg Zellers, who was headed into work early on New Year’s Day, reportedly helped police find the site of a car crash in Gary, Indiana.

## WWII-era unexploded bomb washed ashore on Santa Cruz beach by powerful storms
 - [https://www.foxnews.com/us/wwii-era-unexploded-bomb-washed-ashore-santa-cruz-beach-powerful-storms](https://www.foxnews.com/us/wwii-era-unexploded-bomb-washed-ashore-santa-cruz-beach-powerful-storms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:53:15+00:00

The Santa Cruz County Sherriff&apos;s office said authorities recovered an unexploded bomb from the beach in Parajo Dunes on New Year&apos;s Eve.

## Man found dead at Salt Lake City International Airport after climbing into plane engine
 - [https://www.foxnews.com/us/man-found-dead-salt-lake-city-international-airport-climbing-plane-engine](https://www.foxnews.com/us/man-found-dead-salt-lake-city-international-airport-climbing-plane-engine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:43:55+00:00

Police in Salt Lake City are investigating the death of a 30-year-old man who climbed inside the engine of a plane on the airport&apos;s deicing pad.

## Michigan university faces discrimination lawsuit from student pursuing gym-teaching career
 - [https://www.foxnews.com/sports/michigan-university-faces-discrimination-lawsuit-student-pursuing-gym-teaching-career](https://www.foxnews.com/sports/michigan-university-faces-discrimination-lawsuit-student-pursuing-gym-teaching-career)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:36:57+00:00

A former college student filed a lawsuit against a Michigan university alleging weight discrimination as he pursued a career as a gym teacher.

## US health advocate and reformist Dr. Sidney Wolfe dies at 86
 - [https://www.foxnews.com/us/us-health-advocate-reformist-dr-sidney-wolfe-dies-86](https://www.foxnews.com/us/us-health-advocate-reformist-dr-sidney-wolfe-dies-86)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:21:43+00:00

Dr. Sidney Wolfe, an advocate for healthcare reform and increased oversight in the U.S. health system, has died at the age of 86. He battled brain cancer, his wife said.

## Harvard president Claudine Gay resigns amid antisemitism, plagiarism controversies
 - [https://www.foxnews.com/politics/harvard-president-claudine-gay-resign-antisemitism-plagiarism-controversies-reports-say](https://www.foxnews.com/politics/harvard-president-claudine-gay-resign-antisemitism-plagiarism-controversies-reports-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:19:37+00:00

Harvard President Claudine Gay stepped down Tuesday after strong backlash for failing to directly condemn calls for the genocide of Jews on campus.

## 12 hours on Mars: What NASA cameras captured during a search mission on the red planet
 - [https://www.foxnews.com/us/12-hours-mars-nasa-cameras-captured-during-search-mission-red-planet](https://www.foxnews.com/us/12-hours-mars-nasa-cameras-captured-during-search-mission-red-planet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:19:00+00:00

The NASA Curiosity Mars rover captured images of the red planet from sunrise to sunset. Scientists hoped that the images would reveal more about weather patterns on Mars.

## Gunman arrested after breaching Colorado Supreme Court, holding guard at gunpoint: cops
 - [https://www.foxnews.com/politics/gunman-breaches-colorado-supreme-court-holds-guard-gunpoint-cops](https://www.foxnews.com/politics/gunman-breaches-colorado-supreme-court-holds-guard-gunpoint-cops)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:09:27+00:00

The Colorado Supreme Court building in Denver was breached by an armed intruder who shot out windows and held a security guard hostage, state police say.

## Biden's Hispanic support plummets with voters disgruntled over economy, immigration: We're 'struggling'
 - [https://www.foxnews.com/media/biden-hispanic-support-plummets-voters-disgruntled-economy-immigration-struggling](https://www.foxnews.com/media/biden-hispanic-support-plummets-voters-disgruntled-economy-immigration-struggling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T18:00:17+00:00

Campus Reform correspondent Pedro Rodriguez and LIBRE Initiative strategic director Monet Flores-Bacs explained Biden&apos;s slipping support among Hispanics during &apos;Fox &amp; Friends&apos; Tuesday.

## DC's first homicide of 2024 reported just an hour after midnight
 - [https://www.foxnews.com/us/dcs-first-homicide-2024-reported-hour-after-midnight](https://www.foxnews.com/us/dcs-first-homicide-2024-reported-hour-after-midnight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:54:21+00:00

Washington, D.C., recorded its first homicide of 2024 just an hour after midnight on New Year&apos;s Day, following the worst year for homicides in more than 20 years.

## Former Mossad head Zvi Zamir, who warned of 1973 attack on Israel, dies at 98
 - [https://www.foxnews.com/world/former-mossad-head-zvi-zamir-warned-1973-attack-israel-dies-98](https://www.foxnews.com/world/former-mossad-head-zvi-zamir-warned-1973-attack-israel-dies-98)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:42:25+00:00

Zvi Zamir, the former head of Israeli intelligence agency Mossad, has died at 98. Zamir led Mossad from 1968 to 1974 and warned the government about an imminent attack.

## Top Hamas official killed in Beirut explosion, Hezbollah media says
 - [https://www.foxnews.com/world/top-hamas-official-killed-beirut-explosion-hezbollah-media-says](https://www.foxnews.com/world/top-hamas-official-killed-beirut-explosion-hezbollah-media-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:37:17+00:00

Hezbollah-linked news outlets are reporting that deputy Hamas leader Saleh Arouri was killed by an Israeli air strike

## Former 'Jeopardy!' host Mayim Bialik hopes for a 'brighter 2024' after game show exit
 - [https://www.foxnews.com/entertainment/former-jeopardy-host-mayim-bialik-hopes-brighter-2024-game-show-exit](https://www.foxnews.com/entertainment/former-jeopardy-host-mayim-bialik-hopes-brighter-2024-game-show-exit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:35:19+00:00

Mayim Bialik is looking forward to better days after announcing last month that she would no longer be hosting syndicated episodes of &quot;Jeopardy!&quot;

## Hispanic leaders see 'red flag' for Biden, warn of 'tone-deaf' White House messaging
 - [https://www.foxnews.com/media/hispanic-leaders-see-red-flag-biden-warn-tone-deaf-white-house-messaging](https://www.foxnews.com/media/hispanic-leaders-see-red-flag-biden-warn-tone-deaf-white-house-messaging)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:33:53+00:00

Hispanic leaders are concerned about President Biden&apos;s sinking support among Hispanic voters, with some blaming the campaign team for being &quot;tone-deaf.&quot;

## Israeli man who battled Hamas in Gaza accused of impersonating soldier, stealing weapons
 - [https://www.foxnews.com/world/israeli-man-battled-hamas-gaza-accused-impersonating-soldier-stealing-weapons](https://www.foxnews.com/world/israeli-man-battled-hamas-gaza-accused-impersonating-soldier-stealing-weapons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:29:33+00:00

An Israeli man who is facing charges of impersonating a soldier and stealing weapons following fighting against Hamas in Gaza.

## 'Wheel of Fortune' host Pat Sajak fumbles during awkward on-air mistake: ‘I just messed up’
 - [https://www.foxnews.com/entertainment/wheel-of-fortune-pat-sajak-fumbles-awkward-on-air-mistake](https://www.foxnews.com/entertainment/wheel-of-fortune-pat-sajak-fumbles-awkward-on-air-mistake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:19:25+00:00

Pat Sajak, the 77-year-old game show host, apologized for a mistake during a recent &quot;Wheel of Fortune&quot; episode after he mixed up a contestant&apos;s personal life on air.

## Chinese exchange student found: Police reveal devious cyberscheme kidnappers used to extort family
 - [https://www.foxnews.com/us/chinese-exchange-student-found-police-reveal-devious-cyberscheme-kidnappers-used-to-extort-family](https://www.foxnews.com/us/chinese-exchange-student-found-police-reveal-devious-cyberscheme-kidnappers-used-to-extort-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:11:09+00:00

The scammers tried to convince both Chinese exchange student Kai Zhuang and his family that they were each in danger in order to extort money from the Zhuang family.

## Sugar Bowl broadcast catches woman flashing chest on Bourbon Street
 - [https://www.foxnews.com/sports/sugar-bowl-broadcast-catches-woman-flashing-chest-bourbon-street](https://www.foxnews.com/sports/sugar-bowl-broadcast-catches-woman-flashing-chest-bourbon-street)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:10:30+00:00

A woman flashed her breasts to the cameras during ESPN&apos;s broadcast of the College Football Playoff semifinals between Washington and Texas in New Orleans.

## California woman brought guns and 'down payment' to meet 'hitman,' have husband killed in bitter divorce
 - [https://www.foxnews.com/us/california-equestrian-brought-guns-down-payment-meet-hitman-have-husband-killed-bitter-divorce](https://www.foxnews.com/us/california-equestrian-brought-guns-down-payment-meet-hitman-have-husband-killed-bitter-divorce)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T17:03:01+00:00

A California equestrian whose divorce would end her lavish lifestyle pleaded guilty to a failed murder-for-hire plot targeting her husband Mark Remley.

## Trump starts 2024 in ‘strongest possible position’ in Republican presidential primary race
 - [https://www.foxnews.com/politics/trump-starts-2024-in-strongest-possible-position-republican-presidential-primary-race](https://www.foxnews.com/politics/trump-starts-2024-in-strongest-possible-position-republican-presidential-primary-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:56:11+00:00

For former President Trump, a year makes a big difference. The former president went from political vulnerability to dominance in the race for the 2024 Republican nomination

## Most Israelis oppose US push for Israel to scale back Hamas war: poll
 - [https://www.foxnews.com/world/most-israelis-oppose-us-push-israel-scale-back-hamas-war-poll](https://www.foxnews.com/world/most-israelis-oppose-us-push-israel-scale-back-hamas-war-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:44:10+00:00

Israeli citizens continue to support the war against Hamas in Gaza and largely oppose U.S. calls to ramp down the conflict, a new poll shows.

## The Rock cuts patriotic promo, teases major match in WWE return
 - [https://www.foxnews.com/sports/the-rock-cuts-patriotic-promo-teases-major-match-wwe-return](https://www.foxnews.com/sports/the-rock-cuts-patriotic-promo-teases-major-match-wwe-return)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:39:45+00:00

Dwayne &quot;The Rock&quot; Johnson returned to WWE on Monday night to confront Jinder Mahal and then teased a possible match with Roman Reigns.

## Jim Harbaugh's daughter blitzes critics after Michigan's Rose Bowl win
 - [https://www.foxnews.com/sports/jim-harbaughs-daughter-blitzes-critics-michigans-rose-bowl-win](https://www.foxnews.com/sports/jim-harbaughs-daughter-blitzes-critics-michigans-rose-bowl-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:37:08+00:00

Michigan head coach Jim Harbaugh&apos;s daughter, Grace, fired off a message to critics following the Wolverines&apos; win over Alabama on Monday night.

## Refugees in Sri Lanka rally against planned closure of United Nations office
 - [https://www.foxnews.com/world/refugees-sri-lanka-rally-against-planned-closure-united-nations-office](https://www.foxnews.com/world/refugees-sri-lanka-rally-against-planned-closure-united-nations-office)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:28:51+00:00

Refugees in Sri Lanka protested outside the U.N. refugee agency&apos;s office, expressing concerns about losing their living allowance when the office closes at the end of the year.

## New York AG case against NRA leader faces trial after court again rejects gun group's claim of political probe
 - [https://www.foxnews.com/politics/new-york-ag-case-against-nra-leader-faces-trial-court-again-rejects-gun-groups-claim-political-probe](https://www.foxnews.com/politics/new-york-ag-case-against-nra-leader-faces-trial-court-again-rejects-gun-groups-claim-political-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:28:06+00:00

Jury selection in New York Attorney General Letitia James&apos; corruption case against Wayne LaPierre and other National Rifle Association begins Tuesday.

## Fox News to host Trump town hall with Bret Baier, Martha MacCallum ahead of Iowa caucuses
 - [https://www.foxnews.com/media/fox-news-host-trump-town-hall-bret-baier-martha-maccallum-ahead-of-iowa-caucus](https://www.foxnews.com/media/fox-news-host-trump-town-hall-bret-baier-martha-maccallum-ahead-of-iowa-caucus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:27:27+00:00

Former President Donald Trump will join Bret Baier and Martha MacCallum for a live Fox News Channel town hall event on January 10 in Des Moines, Iowa.

## Biden continues bleeding support from key voter groups as Dems sound alarm over 2024: poll
 - [https://www.foxnews.com/politics/biden-continues-bleeding-support-key-voter-groups-dems-sound-alarm-2024-poll](https://www.foxnews.com/politics/biden-continues-bleeding-support-key-voter-groups-dems-sound-alarm-2024-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:25:22+00:00

Black, Hispanic and young voters, which traditionally lean Democrat, have shifted support away from President Biden and toward third-party candidates.

## Missing Madeleine McCann's parents say investigation into toddler's abduction 'will eventually yield results'
 - [https://www.foxnews.com/world/missing-madeleine-mccann-parents-say-investigation-toddlers-abduction-eventually-yield-results](https://www.foxnews.com/world/missing-madeleine-mccann-parents-say-investigation-toddlers-abduction-eventually-yield-results)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:22:26+00:00

The parents of abducted British toddler Madeleine McCann released a new statement on New Year&apos;s Day, expressing hope that the investigation &quot;will eventually yield results.&quot;

## House GOP majority officially whittles down to 3 seats after McCarthy resignation
 - [https://www.foxnews.com/politics/house-gop-majority-officially-whittles-down-three-seats-mccarthy-resignation](https://www.foxnews.com/politics/house-gop-majority-officially-whittles-down-three-seats-mccarthy-resignation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:17:41+00:00

The House Republican majority slimmed down even further, dropping from four seats to three with the retirement of former House Speaker Kevin McCarthy.

## China tells Taiwan to vote on 'right side of history' in election that could determine cross-strait relations
 - [https://www.foxnews.com/world/china-tells-taiwan-vote-right-side-history-election-could-determine-cross-strait-relations](https://www.foxnews.com/world/china-tells-taiwan-vote-right-side-history-election-could-determine-cross-strait-relations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:14:54+00:00

The Chinese Communist Party is urging the Taiwanese public to vote &quot;on the right side of history&quot; in its presidential election, hoping to negotiate the reintegration of the island.

## Mayoral candidate shot dead with AR-15 by brother-in-law in likely self-defense case: police
 - [https://www.foxnews.com/us/mayoral-candidate-shot-dead-ar-15-exs-brother-likely-self-defense-case-police](https://www.foxnews.com/us/mayoral-candidate-shot-dead-ar-15-exs-brother-likely-self-defense-case-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:08:30+00:00

A recent mayoral candidate in Soso, Mississippi, Jason Marshall, was fatally shot when he showed up before dawn at his estranged wife&apos;s home, breaking a court order, police say.

## Basdeo Panday, first person of Indian descent to lead Trinidad and Tobago, dies at 90
 - [https://www.foxnews.com/world/basdeo-panday-first-person-indian-descent-lead-trinidad-tobago-dies-90](https://www.foxnews.com/world/basdeo-panday-first-person-indian-descent-lead-trinidad-tobago-dies-90)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T16:06:52+00:00

Basdeo Panday, the first person of Indian descent to serve as the Prime Minister of Trinidad and Tobago, has passed away at the age of 90. He served two terms from 1995 to 2001.

## Spanish man returns home to Madrid after spending 15 months in Iranian prison
 - [https://www.foxnews.com/world/spanish-man-returns-home-madrid-spending-15-months-iranian-prison](https://www.foxnews.com/world/spanish-man-returns-home-madrid-spending-15-months-iranian-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T15:51:05+00:00

Santiago Sánchez Cogedor, a Spanish man who spent 15 months in an Iranian prison after visiting the tomb of Mahsa Amini, has returned to his home in Madrid.

## Dave Chappelle's Netflix special goes viral for blunt transgender comments: 'Telling the truth'
 - [https://www.foxnews.com/media/dave-chappelles-netflix-special-goes-viral-blunt-transgender-comments-telling-truth](https://www.foxnews.com/media/dave-chappelles-netflix-special-goes-viral-blunt-transgender-comments-telling-truth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T15:49:32+00:00

Comedian Dave Chappelle revisited the hot button topic of transgenderism and gender identity in his latest Netflix special, &quot;The Dreamer,&quot; earning him praise and backlash.

## Charlamagne Tha God regrets backing Kamala Harris for VP, says she 'disappeared' in Biden administration
 - [https://www.foxnews.com/media/charlamagne-tha-god-regrets-backing-kamala-harris-vp-she-disappeared-biden-administration](https://www.foxnews.com/media/charlamagne-tha-god-regrets-backing-kamala-harris-vp-she-disappeared-biden-administration)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T15:37:39+00:00

&quot;Breakfast Club&quot; host Charlamagne Tha God told Politico he regretted backing Kamala Harris for vice president in 2020 and said she &quot;disappeared&quot; in the White House.

## Germany's smallest governing party votes to stay in Chancellor Scholz's coalition
 - [https://www.foxnews.com/world/germanys-smallest-governing-party-votes-stay-chancellor-scholzs-coalition](https://www.foxnews.com/world/germanys-smallest-governing-party-votes-stay-chancellor-scholzs-coalition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T15:35:14+00:00

Members of the Free Democrats, the smallest party in German Chancellor Olaf Scholz&apos;s coalition, voted to remain in the government despite its low popularity.

## Maine secretary of state denies politics played role in decision to kick Trump off ballot
 - [https://www.foxnews.com/politics/maine-secretary-state-denies-politics-played-role-decision-kick-trump-off-ballot](https://www.foxnews.com/politics/maine-secretary-state-denies-politics-played-role-decision-kick-trump-off-ballot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T15:20:52+00:00

Maine Secretary of State Shenna Bellows, a Democrat, said politics played no role in her decision to bar former President Trump from Maine&apos;s primary election ballot.

## Texas border officers discover $10.2M in drugs inside refrigerated trailer hauling roses, officials say
 - [https://www.foxnews.com/us/texas-border-officers-discover-10-2m-drugs-inside-refrigerated-trailer-hauling-roses-officials-say](https://www.foxnews.com/us/texas-border-officers-discover-10-2m-drugs-inside-refrigerated-trailer-hauling-roses-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T15:15:14+00:00

Border officers in Laredo, Texas, discovered that a shipment of flowers was hiding over 1,100 pounds of meth and cocaine valued at $10.2 million.

## Russia accidentally drops bombs on own village as missiles continue to bombard Ukraine
 - [https://www.foxnews.com/world/russia-accidentally-drops-bombs-own-village-missiles-continue-bombard-ukraine](https://www.foxnews.com/world/russia-accidentally-drops-bombs-own-village-missiles-continue-bombard-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T15:05:20+00:00

A Russian warplane accidentally dropped bombs on the Russian village of Petropavlovka during an &quot;emergency release,&quot; according to reports from the Ministry of Defense.

## 'Beverly Hills, 90210' star Ian Ziering calls on law enforcement to take action after biker attack
 - [https://www.foxnews.com/entertainment/beverly-hills-90210-ian-ziering-law-enforcement-action-biker-attack](https://www.foxnews.com/entertainment/beverly-hills-90210-ian-ziering-law-enforcement-action-biker-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T15:01:37+00:00

Actor Ian Ziering updated his fans about he and his daughter being &quot;aggressively&quot; attacked on New Year&apos;s Eve by bikers on Hollywood Boulevard.

## First 10 things to do if you got a new PC
 - [https://www.foxnews.com/tech/first-10-things-to-do-if-you-got-a-new-pc](https://www.foxnews.com/tech/first-10-things-to-do-if-you-got-a-new-pc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T15:00:19+00:00

Got a new PC? Kurt “CyberGuy&quot; Knutsson is here with some suggestions to help you get things set up on your new device.

## Star Trek superfan's ashes to be sent into space along with those of TV series' stars
 - [https://www.foxnews.com/entertainment/star-trek-superfans-ashes-sent-space-tv-series-stars](https://www.foxnews.com/entertainment/star-trek-superfans-ashes-sent-space-tv-series-stars)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:57:40+00:00

The family of an avid &quot;Star Trek&quot; fan who passed away 12 years ago has arranged for a portion of her ashes to be sent into space alongside those of the TV series&apos; stars.

## Ex-gang leader suspected of Tupac Shakur murder seeks house arrest prior to trial
 - [https://www.foxnews.com/us/ex-gang-leader-suspected-tupac-shakur-murder-seeks-house-arrest-prior-trial](https://www.foxnews.com/us/ex-gang-leader-suspected-tupac-shakur-murder-seeks-house-arrest-prior-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:52:59+00:00

A former Los Angeles-area gang leader charged with the 1996 killing of hip-hop icon Tupac Shakur is seeking release to house arrest due to poor health before the June trial.

## Lions' Dan Campbell admits trying to confuse Cowboys defense before controversial penalty
 - [https://www.foxnews.com/sports/lions-dan-campbell-admits-trying-confuse-cowboys-defense-controversial-penalty](https://www.foxnews.com/sports/lions-dan-campbell-admits-trying-confuse-cowboys-defense-controversial-penalty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:51:27+00:00

Detroit Lions head coach Dan Campbell admits he was trying to fool the Dallas Cowboys defense ahead of the controversial penalty in their game Saturday.

## Rochester fatal car explosion investigated as possible terror attack
 - [https://www.foxnews.com/us/rochester-fatal-car-explosion-investigated-possible-terror-attack](https://www.foxnews.com/us/rochester-fatal-car-explosion-investigated-possible-terror-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:51:07+00:00

A car explosion that killed two people and injured at least five others in Rochester, New York, is being investigated as a possible terrorist attack.

## Jazz pioneer Les McCann, known for 'Compared to What,' dies at 88
 - [https://www.foxnews.com/entertainment/jazz-pioneer-les-mccann-known-compared-what-dies-88](https://www.foxnews.com/entertainment/jazz-pioneer-les-mccann-known-compared-what-dies-88)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:50:03+00:00

Les McCann, a musician and recording artist known for his contributions to the soul-jazz genre and influential collaborations in the music industry, has died at 88.

## Uganda's beloved alcoholic beverage threatened as authorities move to curb home brewing
 - [https://www.foxnews.com/world/ugandas-beloved-alcoholic-beverage-threatened-authorities-move-curb-home-brewing](https://www.foxnews.com/world/ugandas-beloved-alcoholic-beverage-threatened-authorities-move-curb-home-brewing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:44:35+00:00

In Uganda, the popular traditional beverage tonto is facing legal challenges. Government efforts to regulate illicit home brews are posing threats to tonto production.

## Israel to defend itself against genocide accusations filed by South Africa at international court
 - [https://www.foxnews.com/world/israel-defend-itself-genocide-accusations-filed-south-africa-international-court](https://www.foxnews.com/world/israel-defend-itself-genocide-accusations-filed-south-africa-international-court)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:43:48+00:00

Israel will defend itself against genocide accusations filed by South Africa, an official said. South Africa has accused Israel of genocide against Palestinians in Gaza.

## Trump wins endorsement from House Majority Leader Steve Scalise
 - [https://www.foxnews.com/politics/trump-wins-endorsement-house-majority-leader-steve-scalise](https://www.foxnews.com/politics/trump-wins-endorsement-house-majority-leader-steve-scalise)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:30:08+00:00

House Majority Leader Steve Scalise is endorsing former President Trump in the 2024 race for the White House, Fox News Digital has learned.

## Shirtless Tom Brady goes wild for Michigan's Rose Bowl win: 'OMFG'
 - [https://www.foxnews.com/sports/shirtless-tom-brady-goes-wild-michigans-rose-bowl-win-omfg](https://www.foxnews.com/sports/shirtless-tom-brady-goes-wild-michigans-rose-bowl-win-omfg)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:17:36+00:00

Tom Brady went wild on Monday night as he watched his Michigan Wolverines defeat the Alabama Crimson Tide in the College Football Playoff semifinals.

## 16 items you can find on Amazon to pamper yourself this New Year
 - [https://www.foxnews.com/lifestyle/amazon-pamper-essentials-new-year](https://www.foxnews.com/lifestyle/amazon-pamper-essentials-new-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:09:34+00:00

End-of-year celebration may have you feeling run down, but these 16 pampering essentials you find on Amazon will help shift your mindset and deliver some much-needed TLC.

## Hamas waives ‘totally off base’ demand for monthslong cease-fire in Israeli hostage negotiation: Report
 - [https://www.foxnews.com/world/hamas-waives-totally-base-demand-months-long-cease-fire-israeli-hostage-negotiation-report](https://www.foxnews.com/world/hamas-waives-totally-base-demand-months-long-cease-fire-israeli-hostage-negotiation-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:07:04+00:00

Israel has rejected a second proposal from Hamas calling for the release of 120 Palestinian prisoners in exchange for 40 Israelis and a 40-day cease-fire.

## 'United as one': Americans in several cities hope for more peace, less division in new year
 - [https://www.foxnews.com/media/united-one-americans-several-cities-hope-more-peace-less-division-new-year](https://www.foxnews.com/media/united-one-americans-several-cities-hope-more-peace-less-division-new-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:00:52+00:00

Americans in several cities across the country shared their New Year&apos;s resolutions for America in 2024, with many hoping for more peace and less division.

## Man found dead following suspected lion attack while riding motorcycle
 - [https://www.foxnews.com/world/man-found-dead-following-suspected-lion-attack-riding-motorcycle](https://www.foxnews.com/world/man-found-dead-following-suspected-lion-attack-riding-motorcycle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T14:00:19+00:00

Police in Kenya recovered the remains of an adult male who is believed to have been mauled to death by a lion while riding a motorcycle, reports say.

## Turkey detains 33 accused of spying for Israel's Mossad: report
 - [https://www.foxnews.com/world/turkey-detains-33-accused-spying-israels-mossad-report](https://www.foxnews.com/world/turkey-detains-33-accused-spying-israels-mossad-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T13:15:55+00:00

Turkey is claiming to have arrested 33 people accused of spying for Israel’s Mossad as part of an investigation called “Operation Mole,&quot; reports say.

## Passengers of Japanese plane speak out after fiery collision leaves 5 dead: 'It was hell'
 - [https://www.foxnews.com/world/passengers-japanese-plane-speak-out-fiery-collision-leaves-dead-it-was-hell](https://www.foxnews.com/world/passengers-japanese-plane-speak-out-fiery-collision-leaves-dead-it-was-hell)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T13:06:33+00:00

Survivors of a Japan Airlines aircraft collision described the fear and panic that passengers experienced as smoke filled the cabin after the aircraft hit a coast guard plane.

## Harvard President Claudine Gay faces six new plagiarism charges: Report
 - [https://www.foxnews.com/media/harvard-president-claudine-gay-faces-six-new-plagiarism-charges-report](https://www.foxnews.com/media/harvard-president-claudine-gay-faces-six-new-plagiarism-charges-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T13:05:53+00:00

Harvard President Claudine Gay is facing six new plagiarism charges amid an ongoing academic scandal and increasing calls for her resignation.

## Stop taxpayer funding of the 'rights for migrants' legal scam
 - [https://www.foxnews.com/opinion/stop-taxpayer-funding-rights-migrants-legal-scam](https://www.foxnews.com/opinion/stop-taxpayer-funding-rights-migrants-legal-scam)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T13:00:23+00:00

Taxpayers are paying to be legally coerced into providing more for migrants, even at the cost of cutting vital city services – kind of like hiring your own assassin.

## Chicago cold case cracked, revealing identity of Army veteran missing since 1970s
 - [https://www.foxnews.com/us/chicago-cold-case-cracked-revealing-identity-army-veteran-missing-1970s](https://www.foxnews.com/us/chicago-cold-case-cracked-revealing-identity-army-veteran-missing-1970s)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:58:16+00:00

An Illinois sheriff’s office has identified the remains of an unidentified person as Reba C. Bailey, a Women’s Army Corps veteran missing since the 1970s.

## Alabama star Dallas Turner plots NFL future immediately after Rose Bowl loss: 'I'm gone'
 - [https://www.foxnews.com/sports/alabama-star-dallas-turner-plots-nfl-future-rose-bowl-loss-gone](https://www.foxnews.com/sports/alabama-star-dallas-turner-plots-nfl-future-rose-bowl-loss-gone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:54:24+00:00

Alabama edge rusher Dallas Turner revealed his intention to turn pro after the Crimson Tide lost to the Michigan Wolverines on Monday night in the Rose Bowl.

## Earthquakes in Japan kill at least 48 as officials race to save people trapped in homes
 - [https://www.foxnews.com/world/earthquakes-japan-kill-officials-race-save-people-trapped-homes](https://www.foxnews.com/world/earthquakes-japan-kill-officials-race-save-people-trapped-homes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:49:44+00:00

At least 48 people have been killed and 16 inured following a series of earthquakes on the western coast of Japan, according to emergency response officials.

## New Jersey used as 'transit point' for migrant buses headed for NYC after new executive order, governor says
 - [https://www.foxnews.com/politics/new-jersey-used-transit-point-migrant-buses-headed-nyc-new-executive-order-governor-says](https://www.foxnews.com/politics/new-jersey-used-transit-point-migrant-buses-headed-nyc-new-executive-order-governor-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:47:19+00:00

Gov. Phil Murphy&apos;s office says migrant buses are using NJ train stations as &quot;transit point&quot; in response to New York City Mayor Eric Adams&apos; executive order.

## US water utilities targeted by foreign hackers, prompting calls for cybersecurity overhaul
 - [https://www.foxnews.com/us/us-water-utilities-targeted-foreign-hackers-prompting-calls-cybersecurity-overhaul](https://www.foxnews.com/us/us-water-utilities-targeted-foreign-hackers-prompting-calls-cybersecurity-overhaul)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:38:35+00:00

The Municipal Water Authority of Aliquippa in western Pennsylvania, along with other water utilities, have fallen victim to an international cyberattack by foreign hackers.

## San Francisco train derails and catches fire, causing minor injuries and service disruptions
 - [https://www.foxnews.com/us/san-francisco-train-derails-catches-fire-causing-minor-injuries-service-disruptions](https://www.foxnews.com/us/san-francisco-train-derails-catches-fire-causing-minor-injuries-service-disruptions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:31:35+00:00

On New Year&apos;s Day, a commuter train derailed and caught fire near Orinda in the San Francisco Bay Area. The incident occurred as the train was traveling to Lafayette.

## Michigan players troll Alabama following thrilling Rose Bowl win
 - [https://www.foxnews.com/sports/michigan-players-troll-alabama-thrilling-rose-bowl-win](https://www.foxnews.com/sports/michigan-players-troll-alabama-thrilling-rose-bowl-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:20:00+00:00

Michigan players trolled Alabama on Monday night following their Rose Bowl win. The Wolverines will play for a national championship against Washington.

## Pennsylvania travel guide: 6 family-friendly destinations for your vacation
 - [https://www.foxnews.com/lifestyle/pennsylvania-travel-guide](https://www.foxnews.com/lifestyle/pennsylvania-travel-guide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:15:41+00:00

Pennsylvania is a state full of history. It is also a state home to a popular United States theme park, Hersheypark, that provides loads of fun for families.

## Hong Kong media mogul Jimmy Lai pleads not guilty to sedition and collusion charges
 - [https://www.foxnews.com/world/hong-kong-media-mogul-jimmy-lai-pleads-not-guilty-sedition-collusion-charges](https://www.foxnews.com/world/hong-kong-media-mogul-jimmy-lai-pleads-not-guilty-sedition-collusion-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:12:39+00:00

Hong Kong pro-democracy activist and media mogul Jimmy Lai pleaded not guilty to charges of sedition and collusion with foreign countries.

## Fiery New York crash kills 2, injures 5 following concert in Rochester
 - [https://www.foxnews.com/us/fiery-new-york-crash-kills-2-injures-5-concert-rochester](https://www.foxnews.com/us/fiery-new-york-crash-kills-2-injures-5-concert-rochester)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T12:07:46+00:00

A two-vehicle collision in Rochester, New York, on New Year&apos;s Day resulted in two deaths and five injuries. The incident occurred around 1 a.m. as police were directing traffic.

## Over 50 members of Utah Mormon congregations suffer carbon monoxide poisoning during service
 - [https://www.foxnews.com/us/50-members-utah-mormon-congregations-suffer-carbon-monoxide-poisoning-service](https://www.foxnews.com/us/50-members-utah-mormon-congregations-suffer-carbon-monoxide-poisoning-service)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T11:59:38+00:00

First responders treated nearly 50 members of a Utah Mormon church after congregants reported symptoms of carbon monoxide poising on Sunday.

## 2 killed and 8 injured in shooting at Los Angeles area New Year's party
 - [https://www.foxnews.com/us/2-killed-8-injured-shooting-los-angeles-area-new-years-party](https://www.foxnews.com/us/2-killed-8-injured-shooting-los-angeles-area-new-years-party)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T11:46:32+00:00

Two people were killed and eight others injured in a shooting at a New Year&apos;s Day party in downtown Los Angeles on Monday. Police responded to the shooting around 1 a.m.

## Packed airliner bursts into flames, ex-CIA analyst's election warning and more top headlines
 - [https://www.foxnews.com/us/packed-airliner-bursts-into-flames-ex-cia-analyst-election-warning](https://www.foxnews.com/us/packed-airliner-bursts-into-flames-ex-cia-analyst-election-warning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T11:15:49+00:00

Get all the stories you need-to-know from the most powerful name in news delivered first thing every morning to your inbox.

## ‘Golden Bachelor’ Gerry Turner and Theresa Nist share wedding details, admit ‘Fantasy Suite was everything’
 - [https://www.foxnews.com/entertainment/golden-bachelor-gerry-turner-theresa-nist-share-wedding-details-admit-fantasy-suite-everything](https://www.foxnews.com/entertainment/golden-bachelor-gerry-turner-theresa-nist-share-wedding-details-admit-fantasy-suite-everything)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T11:15:04+00:00

&quot;The Golden Bachelor&quot; star Gerry Turner and his fiancee Theresa Nist shared details about their upcoming wedding, which will be televised on Jan. 4.

## David Beckham roasts wife Victoria about elitism again at Ritz Carlton lunch: 'Very working class'
 - [https://www.foxnews.com/media/david-beckham-roasts-wife-victoria-elitism-again-ritz-carlton-lunch-very-working-class](https://www.foxnews.com/media/david-beckham-roasts-wife-victoria-elitism-again-ritz-carlton-lunch-very-working-class)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T11:00:55+00:00

David Beckham jokingly mocked his wife Victoria again in an Instagram post on Sunday, referencing her earlier claim that she came from a &quot;working class&quot; family.

## How hackers can send text messages from your phone without you knowing
 - [https://www.foxnews.com/tech/how-hackers-can-send-text-messages-from-your-phone-without-you-knowing](https://www.foxnews.com/tech/how-hackers-can-send-text-messages-from-your-phone-without-you-knowing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T11:00:20+00:00

Kurt “CyberGuy&quot; Knutsson discusses how hackers can send text messages (spoofing) from your phone without you knowing about it.

## Japan Airlines passenger plane burst into flames after possible collision at Tokyo's Haneda airport
 - [https://www.foxnews.com/world/japan-airlines-passenger-plane-burst-flames-tokyos-haneda-airport](https://www.foxnews.com/world/japan-airlines-passenger-plane-burst-flames-tokyos-haneda-airport)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T10:33:53+00:00

A possible collision between two planes on a runway at Tokyo&apos;s Haneda airport in Japan resulted in a Japan Airlines passenger plane bursting into flames.

## Taylor Swift and Travis Kelce, Kevin Costner and Jewel will grow stronger in 2024: Celebrity astrologer
 - [https://www.foxnews.com/entertainment/taylor-swift-travis-kelce-kevin-costner-jewel-grow-stronger-2024-celebrity-astrologer](https://www.foxnews.com/entertainment/taylor-swift-travis-kelce-kevin-costner-jewel-grow-stronger-2024-celebrity-astrologer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T10:00:48+00:00

Taylor Swift and Travis Kelce&apos;s future in 2024 is bright, according to a celebrity astrologist. Here&apos;s a look at love predictions for celebrity couples in 2024.

## Non-Jews should lead the fight against Jew hatred
 - [https://www.foxnews.com/opinion/non-jews-should-lead-fight-against-jew-hatred](https://www.foxnews.com/opinion/non-jews-should-lead-fight-against-jew-hatred)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T10:00:36+00:00

Jews keep debating how to fight antisemitism. Yet, all Americans should confront this evil. Jew-hatred is not a Jewish disease – it’s a non-Jewish one.

## Rob Lowe shares hardest part of new role as game show host: 'It kills me'
 - [https://www.foxnews.com/entertainment/rob-lowe-shares-hardest-part-role-game-host-it-kills-me](https://www.foxnews.com/entertainment/rob-lowe-shares-hardest-part-role-game-host-it-kills-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T10:00:10+00:00

Rob Lowe is the host of Fox&apos;s new game show, &quot;The Floor,&quot; and he said it &quot;kills me&quot; when the contestants aren&apos;t doing well because he&apos;s rooting for them to succeed.

## Biden administration takes aim at popular childcare program
 - [https://www.foxnews.com/opinion/biden-administration-takes-popular-childcare-program](https://www.foxnews.com/opinion/biden-administration-takes-popular-childcare-program)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T10:00:08+00:00

This international childcare program is an amazing cultural exchange that is a win-win for both parents and au pairs. Naturally, the Biden administration wants to change it.

## Disastrous polls prove Democrats need a backup plan for 2024
 - [https://www.foxnews.com/opinion/disastrous-polls-prove-democrats-need-backup-plan-2024](https://www.foxnews.com/opinion/disastrous-polls-prove-democrats-need-backup-plan-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T10:00:03+00:00

The aging and unpopular president puts Democrat 2024 election hopes in jeopardy and polls prove it. Party needs a backup plan and there are a few candidates on the short list.

## Cameron Diaz, Dean McDermott: Stars admit to unconventional living situations with their partners
 - [https://www.foxnews.com/entertainment/cameron-diaz-dean-mcdermott-stars-admit-unconventional-living-situations](https://www.foxnews.com/entertainment/cameron-diaz-dean-mcdermott-stars-admit-unconventional-living-situations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:30:07+00:00

Cameron Diaz announced her desire to &quot;normalize separate bedrooms&quot; for spouses. Fox News Digital looks back at other celebrity couples with unconventional living situations.

## Thousands of doses of childhood vaccines reportedly transported into Gaza Strip through Rafah crossing
 - [https://www.foxnews.com/health/thousands-doses-childhood-vaccines-reportedly-transported-gaza-strip-through-rafah-crossing](https://www.foxnews.com/health/thousands-doses-childhood-vaccines-reportedly-transported-gaza-strip-through-rafah-crossing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:25:15+00:00

Thousands of doses of vaccines against childhood diseases are being delivered into Gaza to support a growing health emergency in the region, officials said.

## In a New Year, pastor reveals how to get back to church every Sunday: 'A prayerful decision'
 - [https://www.foxnews.com/lifestyle/new-year-pastor-how-get-back-church-every-sunday-prayerful-decision](https://www.foxnews.com/lifestyle/new-year-pastor-how-get-back-church-every-sunday-prayerful-decision)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:15:59+00:00

As the New Year gets underway, a deeper faith is a priority for many people — and a pastor in Washington state shares advice for getting back into the routine of regular church attendance.

## Amnesty remains priority for Biden admin, Democrats even amid record border numbers
 - [https://www.foxnews.com/politics/amnesty-remains-priority-biden-admin-democrats-even-amid-record-border-numbers](https://www.foxnews.com/politics/amnesty-remains-priority-biden-admin-democrats-even-amid-record-border-numbers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:08:53+00:00

Amnesty for millions of illegal immigrants already in the U.S. remains a key issue for Democrats and the Biden administration, even as the border sees record numbers.

## 5 social media celebrities who made waves into the mainstream in 2023
 - [https://www.foxnews.com/us/5-social-media-celebrities-who-made-waves-2023](https://www.foxnews.com/us/5-social-media-celebrities-who-made-waves-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:05:57+00:00

A comedian battling cancel culture, a transgender influencer, and a red-bearded musician were among some TikTok celebrities who crossed into the mainstream this year.

## Smoking shrinks the brain and drives up Alzheimer’s risk, new study finds
 - [https://www.foxnews.com/health/smoking-shrinks-brain-drives-alzheimers-risk-study-finds](https://www.foxnews.com/health/smoking-shrinks-brain-drives-alzheimers-risk-study-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:05:49+00:00

Smoking is notorious for causing damage to the lungs, but recent research confirmed that it’s also harmful to the brain. We explore a new study and gather expert input.

## Handwriting exposed Oba Chandler’s horrific Florida murders of woman, daughters found floating in Tampa Bay
 - [https://www.foxnews.com/us/handwriting-exposed-oba-chandler-horrific-florida-murders-woman-daughters-found-floating-tampa-bay](https://www.foxnews.com/us/handwriting-exposed-oba-chandler-horrific-florida-murders-woman-daughters-found-floating-tampa-bay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:00:59+00:00

Oba Chandler was arrested for the 1989 murders of Joan Rogers and her teen daughters after one the contractor&apos;s customers recognized his handwriting posted on Florida billboards.

## Jan 6 rioters, abortion, gun rights: A look ahead at landmark cases SCOTUS will hear in 2024
 - [https://www.foxnews.com/us/jan-6-rioters-abortion-gun-rights-look-ahead-landmark-cases-scotus-will-hear-2024](https://www.foxnews.com/us/jan-6-rioters-abortion-gun-rights-look-ahead-landmark-cases-scotus-will-hear-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:00:58+00:00

A look ahead at the second half of the 2023-24 Supreme Court&apos;s term set to deal with blockbuster issues like the abortion pill, Jan. 6 rioters and First Amendment rights.

## Biden allies turn against key part of his climate agenda
 - [https://www.foxnews.com/politics/biden-allies-turn-against-key-part-his-climate-agenda](https://www.foxnews.com/politics/biden-allies-turn-against-key-part-his-climate-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:00:54+00:00

Lawmakers and green groups often allied with the Biden administration are taking aim at a recent White House proposal dictating future green energy tax credits.

## Ex-CIA analyst says intel agencies to be politically active again in 2024 election: 'Significant problem'
 - [https://www.foxnews.com/politics/ex-cia-analyst-says-intel-agencies-politically-active-again-2024-election-significant-problem](https://www.foxnews.com/politics/ex-cia-analyst-says-intel-agencies-politically-active-again-2024-election-significant-problem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:00:46+00:00

A former CIA analyst is sounding the alarm about DEI and polarization within the intel community and says he expects them to actively work against the GOP candidate in 2024.

## Casey Anthony’s parents take lie detector test about granddaughter’s death: ‘Some wounds are just too deep’
 - [https://www.foxnews.com/us/casey-anthony-parents-take-lie-detector-test-granddaughters-death](https://www.foxnews.com/us/casey-anthony-parents-take-lie-detector-test-granddaughters-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:00:38+00:00

Florida woman Casey Anthony was acquitted of murder in connection with daughter Caylee&apos;s death. She appeared in the 2022 series, “Casey Anthony: Where the Truth Lies.&quot;

## Boston mayor's party that excluded White officials didn't violate law: AG
 - [https://www.foxnews.com/us/boston-mayors-party-that-excluded-white-officials-didnt-violate-law-ag](https://www.foxnews.com/us/boston-mayors-party-that-excluded-white-officials-didnt-violate-law-ag)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:00:35+00:00

Massachusetts Democratic Attorney General Andrea Campbell will not open an investigation into complaints against Boston mayor&apos;s controversial &quot;electeds of color&quot; holiday party.

## Texas man wants exoneration in college student's 1991 murder while victim's family denounces 'agenda'
 - [https://www.foxnews.com/us/texas-man-wants-exoneration-college-students-1991-murder-victims-family-denounces-agenda](https://www.foxnews.com/us/texas-man-wants-exoneration-college-students-1991-murder-victims-family-denounces-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T09:00:00+00:00

Anita Byington, a 21-year-old Texas college student, was murdered in 1991. Allen Andre Causey, who was convicted in her murder, is seeking exoneration after being paroled.

## Terror attack coming when we 'least expect it' as migrant encounters shatter records, expert warns
 - [https://www.foxnews.com/media/terror-attack-coming-least-expect-migrant-encounters-shatter-records-expert-warns](https://www.foxnews.com/media/terror-attack-coming-least-expect-migrant-encounters-shatter-records-expert-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T08:00:00+00:00

Border security experts are sounding the alarm on public safety concerns as the number of migrant encounters surpasses previous monthly and quarterly records.

## Washington fends off Texas in thrilling half, advances to CFP National Championship
 - [https://www.foxnews.com/sports/washington-fends-off-texas-thrilling-half-advances-cfp-national-championship](https://www.foxnews.com/sports/washington-fends-off-texas-thrilling-half-advances-cfp-national-championship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T05:54:39+00:00

The Washington Huskies defeated the Texas Longhorns 37-31 on Monday night to advance to the CFP National Championship on Jan. 8.

## On this day in history, January 2, 1920, thousands detained by DOJ in nationwide 'Palmer Raids'
 - [https://www.foxnews.com/lifestyle/on-this-day-history-jan-2-1920-thousands-detained-doj-nationwide-palmer-raids](https://www.foxnews.com/lifestyle/on-this-day-history-jan-2-1920-thousands-detained-doj-nationwide-palmer-raids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T05:02:10+00:00

Attorney General A. Mitchell Palmer launched the greatest of his infamous raids on this day in history, Jan. 2, 1920. They employed illegal tactics and marked height of the Red Scare.

## Rays' Wander Franco arrested amid investigation into alleged relationships with minors: reports
 - [https://www.foxnews.com/sports/rays-wander-franco-arrested-amid-investigation-alleged-relationships-minors-reports](https://www.foxnews.com/sports/rays-wander-franco-arrested-amid-investigation-alleged-relationships-minors-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T04:34:36+00:00

Tampa Bay Rays shortstop Wander Franco was arrested in the Dominican Republic Monday amid allegations that the All-Star had inappropriate relationships with minors, according to reports.

## South Korea opposition leader stabbed in neck during visit to Busan
 - [https://www.foxnews.com/world/south-korea-opposition-leader-stabbed-neck-during-visit-busan](https://www.foxnews.com/world/south-korea-opposition-leader-stabbed-neck-during-visit-busan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T04:05:07+00:00

South Korea&apos;s opposition leader Lee Jae-myung was stabbed in the neck during a visit to the southern port city of Busan and has been airlifted to a hospital for treatment.

## Florida man caught on video making 'dirt angels' while running from deputies on Christmas Eve
 - [https://www.foxnews.com/us/florida-man-caught-video-making-dirt-angels-running-deputies-christmas-eve](https://www.foxnews.com/us/florida-man-caught-video-making-dirt-angels-running-deputies-christmas-eve)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T02:39:25+00:00

A Florida man has been charged with leaving the scene of an accident, driving with a canceled, suspended, or revoked license, and trespassing on a construction site, among others.

## Maryland county claims school board can create seat only illegal immigrants can vote on: reports
 - [https://www.foxnews.com/politics/maryland-county-claims-school-board-create-seat-only-illegal-immigrants-vote-reports](https://www.foxnews.com/politics/maryland-county-claims-school-board-create-seat-only-illegal-immigrants-vote-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T02:37:10+00:00

Howard County, Maryland officials claim under the 14th Amendment, they have the ability to create a school board position to represent immigrants that only immigrants can vote on.

## Iranian warship enters Red Sea amid Houthis’ ongoing attacks on commercial vessels
 - [https://www.foxnews.com/world/iranian-warship-enters-red-sea-houthis-ongoing-attacks-commercial-vessels](https://www.foxnews.com/world/iranian-warship-enters-red-sea-houthis-ongoing-attacks-commercial-vessels)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T02:34:41+00:00

The Iranian warship, the Alborz, has entered the Red Sea at a time of ongoing attacks on commercial vessels by Houthi militants in Yemen.

## Mayor Sadiq Khan ridiculed for blaming cell phones when challenged on knife crimes in London
 - [https://www.foxnews.com/media/mayor-sadiq-khan-ridiculed-blaming-cell-phones-challenged-knife-crimes-london](https://www.foxnews.com/media/mayor-sadiq-khan-ridiculed-blaming-cell-phones-challenged-knife-crimes-london)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T02:00:50+00:00

London Mayor Sadiq Khan was ridiculed on social media after insisting that thefts of mobile phones are the main drivers behind knife crimes in his city.

## Michigan rallies back, advances to CFP National Championship with overtime victory over Alabama
 - [https://www.foxnews.com/sports/michigan-rallies-back-advances-cfp-national-championship-overtime-victory-alabama](https://www.foxnews.com/sports/michigan-rallies-back-advances-cfp-national-championship-overtime-victory-alabama)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T01:48:43+00:00

Michigan defeated Alabama in the College Football Playoff semifinals on Monday to advance to the CFP National Championship on January 8.

## Dallas Zoo euthanized 15-year-old giraffe over injuries from 'unexpected fall'
 - [https://www.foxnews.com/us/dallas-zoo-euthanized-15-year-old-giraffe-injuries-unexpected-fall](https://www.foxnews.com/us/dallas-zoo-euthanized-15-year-old-giraffe-injuries-unexpected-fall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T01:05:10+00:00

The Dallas Zoo announced on social media that one of its giraffes, a 15-year-old named Ferrell, had to be euthanized following an unexpected fall.

## Soros' Southampton, NY estate latest to fall victim to fake 911 'swatting' call
 - [https://www.foxnews.com/us/soros-southampton-ny-estate-latest-fall-victim-fake-swatting-call](https://www.foxnews.com/us/soros-southampton-ny-estate-latest-fall-victim-fake-swatting-call)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T01:05:05+00:00

Billionaire George Soros became the latest victim of a swatting attempt after a prank caller called 911 in Southampton, New York, prompting officers to go to the large estate.

## Some Israelis allowed to return to border communities near Gaza Strip, military says
 - [https://www.foxnews.com/world/some-israelis-allowed-return-border-communities-gaza-strip-military-says](https://www.foxnews.com/world/some-israelis-allowed-return-border-communities-gaza-strip-military-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T01:02:13+00:00

Israel&apos;s Home Front Command said Monday that some Israelis who fled their communities near the Gaza border after Oct. 7 can start to return to their homes.

## Chicago crime crisis: First homicide of 2024 happens mere moments into New Year's Day
 - [https://www.foxnews.com/us/chicago-crime-crisis-first-homicide-2024-happens-moments-new-years-day](https://www.foxnews.com/us/chicago-crime-crisis-first-homicide-2024-happens-moments-new-years-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T00:40:09+00:00

The Chicago Police Department reported that the Windy City&apos;s first homicide of 2024 took place soon after midnight on Monday, taking the life of a 53-year-old man.

## New Year's Eve in Times Square rings in over 100,000 pounds of confetti in clean up efforts
 - [https://www.foxnews.com/us/new-years-eve-times-square-rings-100000-pounds-confetti-in-clean-up-efforts](https://www.foxnews.com/us/new-years-eve-times-square-rings-100000-pounds-confetti-in-clean-up-efforts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T00:33:04+00:00

The 2024 New Year&apos;s Eve celebration inside Times Square produced 100,000 pounds of confetti as a massive cleaning crew cleared the streets before daybreak.

## Grenade found inside walls of home during renovation project in Dallas-area town
 - [https://www.foxnews.com/us/grenade-found-inside-walls-home-during-renovation-project-dallas-area-town](https://www.foxnews.com/us/grenade-found-inside-walls-home-during-renovation-project-dallas-area-town)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-01-02T00:26:05+00:00

A home renovator found a grenade inside the walls of a home in White Settlement, TX during a home renovation project, according to police.

