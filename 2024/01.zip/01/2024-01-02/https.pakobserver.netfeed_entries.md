# Source:Pakistan Observer, URL:https://pakobserver.net/feed/, language:en-US

## Sartaj Aziz: Ex-finance minister, PML-N stalwart passes away at 95
 - [https://pakobserver.net/sartaj-aziz-ex-finance-minister-pml-n-stalwart-passes-away-at-95](https://pakobserver.net/sartaj-aziz-ex-finance-minister-pml-n-stalwart-passes-away-at-95)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T17:57:40+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/54b3770c2639c-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Sartaj Aziz, Pakistani economist and Sartaj Aziz strategist who served as finance minister has passed away at the age of 95, Ahsan Iqbal announced Tuesday. Several key leaders including caretaker foreign minister Jalil Abbas Jilani, mounted the demise of Mr Aziz. The prominent figure in country&#8217;s politics had a glittering career, which spanned academia, civil [&#8230;]

## iPhone 14 PTA Tax, Custom Duty in Pakistan January 2024 update
 - [https://pakobserver.net/iphone-14-pta-tax-custom-duty-in-pakistan-january-2024-update](https://pakobserver.net/iphone-14-pta-tax-custom-duty-in-pakistan-january-2024-update)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T17:47:20+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/443-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Apple devices are known for their smooth performance, top hardware and high tag price and iPhone 14 is not cheap as compared to other phones of this generation. The company designs its own hardware and software and sets the price above other brands which is influenced by cost of materials, manufacturing, research and development, marketing, [&#8230;]

## UK tightens visa restrictions on foreign students; Here’s new update for Pakistanis
 - [https://pakobserver.net/uk-tightens-visa-restrictions-on-foreign-students-heres-new-update-for-pakistanis](https://pakobserver.net/uk-tightens-visa-restrictions-on-foreign-students-heres-new-update-for-pakistanis)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T17:34:03+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/ee444-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />United Kingdom is known for its diverse culture and ethnic diversity, and the multicultural society is home to people across the globe. The UK remained welcoming for foreign students, and it typically offers various visa options for international students who are seeking to advance their education in Britain. Amid a huge influx of applicants, the [&#8230;]

## Honda CD 70 interest free installment plans in Pakistan Jan 2024
 - [https://pakobserver.net/honda-cd-70-interest-free-installment-plans-in-pakistan-jan-2024](https://pakobserver.net/honda-cd-70-interest-free-installment-plans-in-pakistan-jan-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T17:12:12+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/honda-cd-70-2024-latest-price-in-pakistan-1692257260-2695-150x150.jpeg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Motorbikes rule Pakistani streets and the king of the two wheelers is Honda CD 70, that is famous for its durability, fuel efficiency, and affordability, making it a hot choice for many riders, especially those who are getting it for daily commute. Despite the presence of a lot of Chinese rides, bikers are preferring CD-70 [&#8230;]

## Army Chief all praise for PAF’s preparedness at Induction, Operationalization Ceremony
 - [https://pakobserver.net/army-chief-all-praise-for-pafs-at-induction-operationalization-ceremony](https://pakobserver.net/army-chief-all-praise-for-pafs-at-induction-operationalization-ceremony)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T16:23:27+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/gg3333-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />RAWALPINDI &#8211; Pakistan Air Force organised Induction and Operationalization Ceremony at its operational base on Tuesday which was attended by Chief of Army Staff General Asim Munir. COAS attended the distinguished ceremony as the Chief Guest. Upon his arrival at the base, the Chief of Army Staff was received by Air Chief Marshal Zaheer Ahmed [&#8230;]

## Four terrorists including a suicide bomber killed in Waziristan operation: ISPR
 - [https://pakobserver.net/four-terrorists-including-a-suicide-bomber-killed-in-waziristan-operation-ispr](https://pakobserver.net/four-terrorists-including-a-suicide-bomber-killed-in-waziristan-operation-ispr)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T15:46:03+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/hh3-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />RAWALPINDI &#8211; At least four terrorists of a banned outfit including a suicide bomber were killed in an intelligence-based operation (IBO) in Khyber Pakhtunkhwa (KP), ISPR said. A statement issued by the military&#8217;s media wing said security forces conducted an Intelligence Based Operation (IBO) in North Waziristan District on Jan 2nd after the reported presence [&#8230;]

## NADRA smart NICOP fee for Saudi Arabia January 2024 update
 - [https://pakobserver.net/nadra-smart-nicop-fee-for-saudi-arabia-january-2024-update](https://pakobserver.net/nadra-smart-nicop-fee-for-saudi-arabia-january-2024-update)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T14:42:25+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/CNIC-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />NICOP card is the ID document of Pakistanis diaspora across the world that keeps them registered in their homeland. The registration document has been issued to all eligible citizens of Pakistan who live outside the country. With NICOP, Pakistanis living in foreign nations can have visa free entry, protection of rights, and full recognition as [&#8230;]

## Pakistan gear up for Sydney Test
 - [https://pakobserver.net/pakistan-gear-up-for-sydney-test](https://pakobserver.net/pakistan-gear-up-for-sydney-test)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T14:29:39+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/GS-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />SYDNEY &#8211; Pakistan are set to play the last match of the Benaud-Qadir Trophy at Sydney Cricket Ground (SCG) from 3 to 7 January. Shan Masood-led side will be looking to avoid a whitewash after the hosts took an unassailable lead by winning the Boxing Day Test at Melbourne. After their 360-run defeat at Perth [&#8230;]

## Abrar Ahmed ruled out of T20I series in New Zealand
 - [https://pakobserver.net/abrar-ahmed-ruled-out-of-t20i-series-in-new-zealand](https://pakobserver.net/abrar-ahmed-ruled-out-of-t20i-series-in-new-zealand)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T14:14:33+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Abrar-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />SYDNEY &#8211; Spinner Abrar Ahmed has been released from the Pakistan squad for the five-match T20I series against New Zealand owing to fitness concerns. He will be returning to Pakistan for his rehabilitation, which will take place at the National Cricket Academy. Left-arm spinner Mohammad Nawaz, who has been released from the Test squad, has [&#8230;]

## Pakistan weather; more hardships for motorists as fog intensifies
 - [https://pakobserver.net/pakistan-weather-more-hardships-for-motorists-as-fog-intensifies](https://pakobserver.net/pakistan-weather-more-hardships-for-motorists-as-fog-intensifies)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T14:06:46+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/KCHP-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – The Pakistan Meteorological Department (PMD) has predicted mainly cold and dry weather for Islamabad, Rawalpindi and most parts of Pakistan during the current week. As per the synoptic situation, continental air prevails over most parts of Pakistan. A shallow westerly wave prevails over western Balochistan. Under these conditions, mainly cold and dry weather [&#8230;]

## iPhone 13 PTA Tax Easy Installments plans in Pakistan
 - [https://pakobserver.net/iphone-13-pta-tax-easy-installments-plans-in-pakistan](https://pakobserver.net/iphone-13-pta-tax-easy-installments-plans-in-pakistan)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T13:35:18+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/3-3-1024x640-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Apple iPhones are exorbitantly expensive in parts of the world, including in Pakistan, and the pricing of these devices is influenced by massive import duties, taxes, and exchange rates. The registration of imported mobile devices remains cumbersome and can make a hole in your pocket, especially for high-end devices like iPhone 13. As Pakistanis are [&#8230;]

## iPhone 13 PTA Tax Easy Installments plans in Pakistan
 - [https://pakobserver.net/iphone-13-pta-tax-easy-installments-plans-in-pakistan-2024](https://pakobserver.net/iphone-13-pta-tax-easy-installments-plans-in-pakistan-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T13:35:18+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/3-3-1024x640-1-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Apple iPhones are exorbitantly expensive in parts of the world, including in Pakistan, and the pricing of these devices is influenced by massive import duties, taxes, and exchange rates. The registration of imported mobile devices remains cumbersome and can make a hole in your pocket, especially for high-end devices like iPhone 13. As Pakistanis are [&#8230;]

## LDA razes/seals several illegal buildings in Lahore
 - [https://pakobserver.net/lda-razes-seals-several-illegal-buildings-in-lahore](https://pakobserver.net/lda-razes-seals-several-illegal-buildings-in-lahore)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T13:09:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/LDA1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – The Lahore Development Authority (LDA) continued operation against illegal constructions/commercial activities in the provincial metropolis. On Tuesday, LDA teams demolished several buildings and sealed another over four dozens during operation in Johar Town, PIA Society and Gul Daman Society. LDA Chief Town Planner-II Azhar Ali supervised the operation carried out with the help [&#8230;]

## Honda City Price in Pakistan January 2024 update
 - [https://pakobserver.net/honda-city-price-in-pakistan-january-2024-update](https://pakobserver.net/honda-city-price-in-pakistan-january-2024-update)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T12:59:24+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Honda-City-2023-Price-in-Pakistan-jpg-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />City has remained Honda&#8217;s front-runner for decades as the car holds a reputation of being a reliable pick for buyers. The car’s USPs include decent fuel efficiency, its comfort, and a spacious interior. Backed by range of modern tech and features, Honda is loaded with infotainment systems and connectivity options. Its resale value also makes [&#8230;]

## Lahore sees no sunshine as fog intensifies in plains
 - [https://pakobserver.net/lahore-sees-no-sunshine-as-fog-intensifies-in-plains](https://pakobserver.net/lahore-sees-no-sunshine-as-fog-intensifies-in-plains)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T12:56:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/fogy-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Blanketed by fog, Lahore and plains of Punjab remained in the grip of cold wave on Tuesday with experts predicting the prevailing weather conditions to persist during the next two days. Lahore hardly saw any sunshine as fog started falling again in the evening before lifting of the existing mass. Biting cold and [&#8230;]

## Rain likely in Karachi, fog to persist in plains of Sindh
 - [https://pakobserver.net/rain-likely-in-karachi-fog-to-persist-in-plains-of-sindh](https://pakobserver.net/rain-likely-in-karachi-fog-to-persist-in-plains-of-sindh)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T12:04:37+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/PE-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The Pakistan Meteorological Department (PMD) has predicted mainly cold and dry weather for most parts of Sindh during the next two days. As per the synoptic situation, continental air prevails over most parts of Pakistan. A shallow westerly wave is affecting western Balochistan. Under these conditions, mainly cold and dry weather is expected [&#8230;]

## Rupee starts 2024 with negative sentiment, moving down against dollar in first trading session
 - [https://pakobserver.net/rupee-starts-2024-with-negative-sentiment-moving-down-against-dollar-in-first-trading-session](https://pakobserver.net/rupee-starts-2024-with-negative-sentiment-moving-down-against-dollar-in-first-trading-session)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T11:59:04+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/g445-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; Pakistani rupee kickstarted its appreciation run against the US dollar, moving down marginally inter-bank market the first trading session of 2024. Data shared by the central bank shows 281.89 after a drop of Rs0.03. In the year 2023, the rupee witnessed a depreciation of 20pc to settle at 281.86. The drop in rupee’s [&#8230;]

## Actor Shaan asks caretakers in Punjab to take notice of load-shedding
 - [https://pakobserver.net/actor-shaan-asks-caretakers-in-punjab-to-take-notice-of-load-shedding](https://pakobserver.net/actor-shaan-asks-caretakers-in-punjab-to-take-notice-of-load-shedding)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T10:22:13+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Shaan-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE &#8211; Acclaimed Lollywood actor Shaan Shahid on Tuesday expressed serious concerns over the prevalent issue of unscheduled load shedding in Punjab, specifically in Lahore. Shaan emphasized the environmental repercussions of generators contributing to the smog in Lahore, particularly during the winter season. The actor drew attention to the financial burden on residents, highlighting the [&#8230;]

## Gold prices go up by Rs1600 per tola in Pakistan
 - [https://pakobserver.net/gold-prices-go-up-by-rs1600-per-tola-in-pakistan](https://pakobserver.net/gold-prices-go-up-by-rs1600-per-tola-in-pakistan)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T10:10:56+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Gold-price-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211;  The local gold market witnessed a significant rise as the per tola rate of 24-karat gold surged by Rs 1600, the All Sindh Sarafa Jewellers Association said on Tuesday. The price for 10 grams of 24-karat gold reached Rs 221,300 in the domestic market, marking a notable increase. Silver prices, concurrently, also experienced [&#8230;]

## Six barbers shot dead in Mir Ali area of North Wazirstan
 - [https://pakobserver.net/six-barbers-shot-dead-in-mir-ali-area-of-north-wazirstan](https://pakobserver.net/six-barbers-shot-dead-in-mir-ali-area-of-north-wazirstan)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T09:45:53+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Six-barbers-killed-in-NW-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Mir Ali:  Some unknown assailants shot six barbers dead in the Mir Ali area of North Waziristan district, Khyber Pakhtunkhwa, the local police said. The victim had their shops and saloons in the local market. The police said that the victims were abducted by unknown culprits to some undisclosed place just a day before, and [&#8230;]

## Artificial rain to be showered again in Lahore to fight smog: CM Naqvi
 - [https://pakobserver.net/artificial-rain-to-be-showered-again-in-lahore-to-fight-smog-cm-naqvi](https://pakobserver.net/artificial-rain-to-be-showered-again-in-lahore-to-fight-smog-cm-naqvi)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T09:14:08+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/CM-Mohsin-Naqvi-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE- Caretaker Punjab Chief Minister Mohsin Naqvi said that they would conduct artificial rain once again to tackle the issue of smog in the provincial capital. The chief minister acknowledged the collaboration of the United Arab Emirates and expressed special gratitude for the authorities for their cooperation for artificial rain in Lahore. He expressed these [&#8230;]

## Nimra Mehra embraces comparison to ‘Pakistani Neha Kakkar’
 - [https://pakobserver.net/nimra-mehra-embraces-comparison-to-pakistani-neha-kakkar](https://pakobserver.net/nimra-mehra-embraces-comparison-to-pakistani-neha-kakkar)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T08:16:51+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Nimra-Mehra-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Emerging Pakistani singer Nimra Mehra expressed her openness to being referred to as the “Pakistani Neha Kakkar” if such a comparison is made. Nimra Mehra, who has been gaining attention for her soulful vocals, shared her thoughts on various aspects of her singing career during a recent appearance on a comedy show. Responding [&#8230;]

## Swat DPO directs police officials to salute teachers
 - [https://pakobserver.net/swat-dpo-directs-police-officials-to-salute-teachers](https://pakobserver.net/swat-dpo-directs-police-officials-to-salute-teachers)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T07:57:19+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Salam-Ustad-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />SWAT &#8211; Swat District Police Officer (DPO) Shafiullah Gandapur on Tuesday issued directives for all police officials across the district to salute and show respect to teachers. DPO Swat, while issuing these directives to all police officers, emphasized the crucial role of educators in fostering a civilized society. He asserted that the denial of the [&#8230;]

## Pakistan issues ‘Letter of Intent’ to IMF for second tranche approval
 - [https://pakobserver.net/pakistan-issues-letter-of-intent-to-imf-for-second-tranche-approval](https://pakobserver.net/pakistan-issues-letter-of-intent-to-imf-for-second-tranche-approval)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T07:42:13+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/IMF-and-Pakistan-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; Caretaker Finance Minister Dr. Shamshad Akhtar and State Bank have jointly issued a Letter of Intent to the International Monetary Fund (IMF) for approval of second tranche worth $70 million. Pakistan through the letter expressed commitment to fulfill all the decided conditions for the second tranche, saying that This letter underscores Pakistan&#8217;s commitment [&#8230;]

## It seems tactics being used against upcoming elections: CJP Isa
 - [https://pakobserver.net/it-seems-tactics-being-used-against-upcoming-elections-cjp-isa](https://pakobserver.net/it-seems-tactics-being-used-against-upcoming-elections-cjp-isa)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T07:08:19+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/10/SC-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; Chief Justice of Pakistan Qazi Faez Isa remarked that some tactics are being used apparently, so the elections could not be held in the country. The top judge gave these remarks while hearing appeal of the Election Commission of Pakistan against verdict of the Peshawar High Court single bench in which the appointment [&#8230;]

## Pakistan unveils 11-player squad for Sydney Test match against Australia
 - [https://pakobserver.net/pakistan-unveils-11-player-squad-for-sydney-test-match-against-australia](https://pakobserver.net/pakistan-unveils-11-player-squad-for-sydney-test-match-against-australia)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T06:31:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/australia-vs-Pakistan-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />SYDNEY &#8211; Pakistan on Tuesday unveiled 11-player squad for the upcoming Sydney Test against Australia, set to commence on Wednesday (tomorrow). In a significant lineup change, the debutant left-handed batsman Saim Ayub will replace Imam-ul-Haq as the opening batter. Besides it, Spinner Sajid Khan has been included while Shaheen Shah Afridi has been rested for [&#8230;]

## Currency exchange rates in Pakistan today – January 2, 2024
 - [https://pakobserver.net/currency-exchange-rates-in-pakistan-today-january-2-2024](https://pakobserver.net/currency-exchange-rates-in-pakistan-today-january-2-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T05:28:19+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/curreny-rate-today-15-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The exchange rate for one US Dollar against Pakistani Rupees was recorded at Rs 281.4 in the local and open market, with a selling rate of Rs 283.9 on Tuesday, January 2, 2024. Note: Exchange rates can vary based on the location and the Exchange Company or bank involved in the transaction. Below are [&#8230;]

## Gold rate in Pakistan today – 2 January, 2024
 - [https://pakobserver.net/gold-rate-in-pakistan-today-2-january-2024](https://pakobserver.net/gold-rate-in-pakistan-today-2-january-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T05:23:49+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/gold-rate-in-pakistan-today-24-March-2023-1-1024x576-4-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The gold rate of 24-karat is being traded at PKR 219,400 on Tuesday, January 2, 2024. Similarly, the gold price for 24-karat was recorded at Rs 188,100 per 10g as per the bullion market. Gold Price in Pakistan’s different cities. City Gold Silver Karachi PKR 219,400 PKR 2,450 Lahore PKR 219,400 PKR 2,450 [&#8230;]

## PM for enhanced Afghan Transit Trade tracking system
 - [https://pakobserver.net/pm-for-enhanced-afghan-transit-trade-tracking-system](https://pakobserver.net/pm-for-enhanced-afghan-transit-trade-tracking-system)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:22:04+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/INP-01-14-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; Caretaker Prime Minister Anwaar-ul-Haq Kakar on Monday directed to take additional steps for enhancement of foolproof tracking system concerning Afghan Transit Trade. Chairing a review meeting over Afghan Transit Trade and anti-smuggling measures, he also asked for the formulation of an immediate mechanism for the establishment of an integrated transit trade management system. The [&#8230;]

## Baloch protesters’ issue ‘blown out of proportion’: PM Kakar
 - [https://pakobserver.net/baloch-protesters-issue-blown-out-of-proportion-pm-kakar](https://pakobserver.net/baloch-protesters-issue-blown-out-of-proportion-pm-kakar)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:22:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/10/kakar-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; Caretaker Prime Minister Anwaarul Haq Kakar on Monday stated that the issue of Baloch families was being “negatively projected”, saying that it was in sharp contrast to the reality as Balochs were standing with the state of Pakistan In response to media queries, during his visit to the Business Facilitation Centre in Lahore, PM [&#8230;]

## Pakistan review on IMF Board agenda on Jan 11
 - [https://pakobserver.net/pakistan-review-on-imf-board-agenda-on-jan-11](https://pakobserver.net/pakistan-review-on-imf-board-agenda-on-jan-11)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:22:01+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/02/pakistan-accepts-imf-demand-to-make-assets-of-bureaucrats-public-1675446699-9759-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The International Monetary Fund is scheduled to consider the first review of Pakistan’s $3 billion stand-by arrangement on January 11. The executive board of the International Monetary Fund will meet on January 11 to consider the final approval to disburse the next $700 million tranche from its current loan programme with Pakistan. According to the [&#8230;]

## PSX begins new year on positive note, gains 2,024 points
 - [https://pakobserver.net/psx-begins-new-year-on-positive-note-gains-2024-points](https://pakobserver.net/psx-begins-new-year-on-positive-note-gains-2024-points)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:22:00+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/psx-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Pakistan Stock Exchange began the new year by crossing the 64,000 barrier on Monday during the intraday trading. The benchmark KSE-100 index, in its first trading session of 2024, reached 64,475.21 points, up by 2,024.17 or 3.24% from the previous close of 62,451.04 points. The latest surge was on the back of buyers’ interest [&#8230;]

## PPP summons CEC emergency meeting over elections
 - [https://pakobserver.net/ppp-summons-cec-emergency-meeting-over-elections](https://pakobserver.net/ppp-summons-cec-emergency-meeting-over-elections)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:21:58+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Bilawal-Bhutto-Zardari-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Fida Hussnain Lahore The Pakistan People’s Party has summoned the Chief Executive Committee meeting on January 3 (Wednesday) to discuss crucial matters related to the upcoming general election in 2024, the sources privy to the development said on Monday. The PPP’s top decision-making body is expected to hold deliberations on significant decisions concerning the party’s [&#8230;]

## Murad says delay in elections could prove ominous
 - [https://pakobserver.net/murad-says-delay-in-elections-could-prove-ominous](https://pakobserver.net/murad-says-delay-in-elections-could-prove-ominous)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:17:49+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2021/02/murad-ali-shah-2-2-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Former Sindh chief minister Murad Ali Shah says delay in elections will be a bad omen as it will embolden terrorists to silence the people. He told media on Monday that the Pakistan Peoples Party (PPP) would emerge victorious in the Feb 8 elections. He said Bilawal Bhutto would become the prime minister as the [&#8230;]

## Major Japan quake prompts tsunami warning, residents told to run
 - [https://pakobserver.net/major-japan-quake-prompts-tsunami-warning-residents-told-to-run](https://pakobserver.net/major-japan-quake-prompts-tsunami-warning-residents-told-to-run)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:17:36+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/GCvYxlsXAAAqfnO-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />A powerful 7.5 earthquake hit central Japan on Monday, the USGS said, prompting tsunami warnings and authorities to urge people in the area to move to higher ground. “All residents must evacuate immediately to higher ground,” national broadcaster NHK said after the quake hit the Noto region in Ishikawa prefecture around 4:10pm (7:10am GMT). Hazardous [&#8230;]

## Pak sends more relief goods to Gaza people
 - [https://pakobserver.net/pak-sends-more-relief-goods-to-gaza-people](https://pakobserver.net/pak-sends-more-relief-goods-to-gaza-people)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:17:25+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/top-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Government of Pakistan has dispatched third consignment of 20 tons of relief goods for the war-ravaged people in Gaza. The consignment of relief goods was sent from Nur Khan Airbase by a special flight of Pakistan Air Force.

## Latif Khosa’s son arrested for ‘assaulting policemen
 - [https://pakobserver.net/latif-khosas-son-arrested-for-assaulting-policemen](https://pakobserver.net/latif-khosas-son-arrested-for-assaulting-policemen)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:17:21+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/top-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Police on Monday said Pakistan Tehreek-e-Insaf leader Latif Khosa’s son, Khurram Latif Khosa, was arrested for assaulting cops along with a group of lawyers in Lahore by Mozang police station personnel. He said Khurram was nabbed from his office near the high court, claiming that they were being targeted for their association with the embattled [&#8230;]

## 5 countries join BRICS
 - [https://pakobserver.net/5-countries-join-brics](https://pakobserver.net/5-countries-join-brics)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T03:17:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/top-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The BRICS memberships of Saudi Arabia, Egypt, the United Arab Emirates, Iran and Ethiopia officially took effect on Monday. The countries were invited to join the group in August 2023 after the 15th BRICS Summit in Johannesburg, South Africa, CGTN reported. Originally comprising Brazil, Russia, India, China, and South Africa, BRICS, an important platform for [&#8230;]

## Mainly cold, dry weather expected
 - [https://pakobserver.net/mainly-cold-dry-weather-expected-21](https://pakobserver.net/mainly-cold-dry-weather-expected-21)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:55+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/met-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; Mainly cold and dry weather is expected in most parts of the country, while very cold in northern parts and north Balochistan during next twenty-four hours. Dense fog and smog is likely to persist in plain areas of Punjab. Fog and smog is likely in upper Sindh, Pothohar region and plain areas of Khyber-Pakhtunkhwa [&#8230;]

## Operation against encroachments continues
 - [https://pakobserver.net/operation-against-encroachments-continues-2](https://pakobserver.net/operation-against-encroachments-continues-2)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:51+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/Screeen-7-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Deputy Commissioner Hafizabad Sundas Irshad has directed the officers of District Administration, Municipal Committees and Markets Committees to continue operation cleanup against encroachment indiscriminately and to improve cleanliness in streets and bazaars of the city whereas anti-encroachments teams be appointed in two shifts so that encroachments be removed from congested areas of the city for [&#8230;]

## 2 tons drugs seized in ten operations
 - [https://pakobserver.net/2-tons-drugs-seized-in-ten-operations](https://pakobserver.net/2-tons-drugs-seized-in-ten-operations)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:48+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/ANF-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Anti-Narcotics Force (ANF), while conducting 10 operations across the country, managed to recover over 2 tons of drugs and arrest three accused, including a woman, said an ANF Headquarters spokesman here on Monday. He said that 1.5 kg of ice was recovered from a Bahrain-bound passenger on Flight No. GF-0791 at Faisalabad Airport. 100 [&#8230;]

## Sanjrani refers 22 private members’ bills to committees
 - [https://pakobserver.net/sanjrani-refers-22-private-members-bills-to-committees](https://pakobserver.net/sanjrani-refers-22-private-members-bills-to-committees)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:40+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Chairman Senate Muhammad Sadiq Sanjran on Monday referred 22 private members’ bills to the relevant committees for further deliberation and consultation. The Chairman Senate’s referred bills included, “The Prevention of Electronic Crimes (Amendment) Bill, 2023”, “The Criminal Laws (Amendment) Bill, 2023”, “The Constitution (Amendment) Bill, 2024”, “The Pakistan Medical and Dental Council (Amendment) Bill, 2023”, [&#8230;]

## Scholarships of Rs3.7m awarded to IUB students
 - [https://pakobserver.net/scholarships-of-rs3-7m-awarded-to-iub-students](https://pakobserver.net/scholarships-of-rs3-7m-awarded-to-iub-students)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:39+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Scholarships worth 7.3 million rupees were distributed among deserving students in the Islamia University of Bahawalpur Bahawalnagar Campus. Director Campus Dr. Rafaqat Ali, Deputy Director of Student Affairs Aurangzeb Watto, Dr. Misbah Akhtar, Representative of Directorate of Financial Institutions Umeer Mukhtar, in-charges of various departments and committee members interviewed about 1300 students for five days [&#8230;]

## Universities committed to comply with 2 % quota for minorities in KP
 - [https://pakobserver.net/universities-committed-to-comply-with-2-quota-for-minorities-in-kp](https://pakobserver.net/universities-committed-to-comply-with-2-quota-for-minorities-in-kp)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:35+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Khyber Pakhtunkhwa, in a collaborative effort, a local NGO Blue Veins, and the National Commission for Human Rights (NCHR) successfully hosted a Provincial Consultative Workshop with Public Sector Universities of Khyber Pakhtunkhwa, focusing on the effective implementation of the 2 percent education quota for minorities in Higher Education. This event, attended by dignitaries from 23 [&#8230;]

## Farmers advised to start sunflower cultivation
 - [https://pakobserver.net/farmers-advised-to-start-sunflower-cultivation-2](https://pakobserver.net/farmers-advised-to-start-sunflower-cultivation-2)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:33+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Agriculture experts have advised farmers to start sunflower cultivation and complete it up to mid of February to get bumper crop. A spokesman for the Agriculture Extension Department told APP here on Monday that sunflower is an important edible oil producing crop which could help Pakistan to trim its import bill of edible bill. He [&#8230;]

## 22,711 candidates enter fray for NA, PAs elections
 - [https://pakobserver.net/22711-candidates-enter-fray-for-na-pas-elections](https://pakobserver.net/22711-candidates-enter-fray-for-na-pas-elections)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; A total of 25,951 candidates have submitted their nomination papers for the forthcoming elections of national and four provincial assembly seats, with 22,711 nomination papers, including 21,684 male and 1,027 female candidates, declared valid for contesting polls. As per the initial candidate roster for the national and all four provincial assemblies released by the [&#8230;]

## BNP-M being kept away from elections under conspiracy: Mengal
 - [https://pakobserver.net/bnp-m-being-kept-away-from-elections-under-conspiracy-mengal](https://pakobserver.net/bnp-m-being-kept-away-from-elections-under-conspiracy-mengal)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:29+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/120x5-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Balochistan National Party-Mengal (BNP-M) Chief Sardar Akhtar Mengal has said that his party is being kept away from elections under a conspiracy. Addressing a press conference in Quetta on Monday, Akhtar Mengal said that 2018 election was ‘Faizabadi’ while 2024 election would be ‘Faisalabadi’. He said that the BNP was being kept away from elections [&#8230;]

## 30,677 criminals arrested
 - [https://pakobserver.net/30677-criminals-arrested](https://pakobserver.net/30677-criminals-arrested)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:59:27+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2021/02/arrest-22-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The police claimed to have arrested 30,677 criminals including 5,945 proclaimed offenders (POs) and 3,556 court absconders from various parts of Faisalabad in 2023. Giving the details, police spokesman Muhammad Nawaz said here on Monday that the police had nabbed 5945 illicit weapon holders and recovered 3340 pistols, 163 rifles, 129 guns, 82 repeaters, 72 [&#8230;]

## Reimagining global economic power dynamics today
 - [https://pakobserver.net/reimagining-global-economic-power-dynamics-today](https://pakobserver.net/reimagining-global-economic-power-dynamics-today)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:36:39+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/05/Rimsha-Malik-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />IN the 1970s and 1980s, individuals from various nations sought the &#8220;American Dream&#8221; in the United States, attracted by the promise of economic opportunity and social mobility. The U.S. stood as a symbol of prosperity, particularly for those escaping economic hardships and political turbulence in their homelands. Today, the world has witnessed a shift in [&#8230;]

## Why your vote matters: Choosing the right candidate
 - [https://pakobserver.net/why-your-vote-matters-choosing-the-right-candidate](https://pakobserver.net/why-your-vote-matters-choosing-the-right-candidate)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:35:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/article-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />THE right to vote is of fundamental importance in democratic societies as it holds the potential to bring about positive change in a nation&#8217;s life. A prominent debate among political scientists revolves around whether people should cast their vote for a political party or a candidate. This question gained renewed attention amid protests over the [&#8230;]

## Artificial intelligence — a futuristic scenario
 - [https://pakobserver.net/artificial-intelligence-a-futuristic-scenario](https://pakobserver.net/artificial-intelligence-a-futuristic-scenario)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:34:26+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/07/Waqar-Hassan-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />SINCE the dawn of humanity, technological progress has been the bedrock of our evolution, ushering in a constant stream of advancements that shape the course of our existence. Every technological innovation has brought with it a mix of trepidation and hope and the emergence of artificial intelligence is no exception. Signifying a monumental leap forward [&#8230;]

## World forum for peace & justice
 - [https://pakobserver.net/world-forum-for-peace-justice](https://pakobserver.net/world-forum-for-peace-justice)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:33:07+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/04/Dr-Ghulam-Nabi-Fai-2-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />INTERNATIONAL Court of Justice in its unofficial press release, issued on December 29, 2023, states, “South Africa today filed an application instituting proceeding against Israel before the International Court of Justice (ICJ), the principal judicial organ of the United Nations, concerning alleged violations by Israel of its obligations under the Convention on the Prevention and [&#8230;]

## Afghanistan must act
 - [https://pakobserver.net/afghanistan-must-act](https://pakobserver.net/afghanistan-must-act)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:31:17+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/editorial-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />TERRORISM emanating from Afghanistan continues to hurt Pakistan. Despite continuous pleas and diplomatic efforts urging Afghan authorities to curb the use of their territory for nefarious activities against Pakistan, recent incidents in the Batwar area of Bajaur district and the Spinwam area of North Waziristan district underscore the unyielding nature of this challenge. In the [&#8230;]

## Third phase of elections
 - [https://pakobserver.net/third-phase-of-elections](https://pakobserver.net/third-phase-of-elections)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:31:14+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/editorial-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; THE third phase of the general election began on Sunday with the filing of appeals against rejection or acceptance of nomination papers by the returning officers (ROs) of the contesting candidates. This is a crucial stage as decisions on appeals would determine the fate of over three thousand two hundred candidates whose nomination papers [&#8230;]

## Hard work by FBR
 - [https://pakobserver.net/hard-work-by-fbr](https://pakobserver.net/hard-work-by-fbr)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:31:11+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/editorial-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; THE Federal Board of Revenue (FBR) surely deserves appreciation for its record tax collection during a month (December 2023) despite various odds and challenges. According to the Board, it collected Rs 1,021 billion during the month and reached a net collection of Rs 984 billion after adjusting refunds of Rs 38 billion. Targets for [&#8230;]

## IGP determined to enhance force capacity building
 - [https://pakobserver.net/igp-determined-to-enhance-force-capacity-building](https://pakobserver.net/igp-determined-to-enhance-force-capacity-building)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:28:42+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/IGP-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Inspector General Police Punjab Dr. Usman Anwar has said that concrete steps have been ensured in the Punjab Police for infrastructure development, upgrading the training modules increasing the capacity building of the force and crime fighting. IG Punjab said that more than 250 crores are being spent on the welfare of the force promotion structure [&#8230;]

## 70-KW solar system installed at WASA office
 - [https://pakobserver.net/70-kw-solar-system-installed-at-wasa-office](https://pakobserver.net/70-kw-solar-system-installed-at-wasa-office)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:28:41+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/lahore-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Punjab Secretary Housing Sajid Zafar Dall on Monday in-augurated a 70-kilowatt solar system at the Water and Sanitation Agency (WASA) head office, with the aim to save Rs1.5 to 2 million on electricity bills monthly. A simple but impressive ceremony was held here at the WASA head office, which witnessed participation of Managing Director WASA [&#8230;]

## PSCA’s helpline receives over 27.5m calls in 2023
 - [https://pakobserver.net/pscas-helpline-receives-over-27-5m-calls-in-2023](https://pakobserver.net/pscas-helpline-receives-over-27-5m-calls-in-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:28:40+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/lahore-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Punjab Safe Cities Authority (PSCA) issued annual per-formance statistics for 2023. The 15 Emergency Helpline received more than 27.5 million calls, and 2.5 million cases with genuine concerns, and the dispatch control centre generated cases for further action. Some 20 million calls were considered irrelevant. Employees of the PSCA worked in the operation room in [&#8230;]

## Enough urea fertilizer available in country to meet requirement: PM
 - [https://pakobserver.net/enough-urea-fertilizer-available-in-country-to-meet-requirement-pm](https://pakobserver.net/enough-urea-fertilizer-available-in-country-to-meet-requirement-pm)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:55+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/1.PM-Caption-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Enough urea fertilizer was available in the country to meet requirements, Caretaker Prime Minister Anwaar-ul-Haq Kakar said this while presiding over the meeting of availability of urea fertilizer in country and directed for initiation of legal proceedings against those involved in its hoarding and illegal profiteering. He said that those exploiting farmers by urea fertilizer [&#8230;]

## Fawad lauds interest of Chinese companies for investment in Pakistan
 - [https://pakobserver.net/fawad-lauds-interest-of-chinese-companies-for-investment-in-pakistan](https://pakobserver.net/fawad-lauds-interest-of-chinese-companies-for-investment-in-pakistan)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:53+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/3.Fawad-Meeting-news-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />A delegation of Chinese Companies and Investors called on the Caretaker Federal Minister for Privatisation, Mr. Fawad Hasan Fawad on Monday at Privatisation Division. The Federal Minister appreciated the interest of the Chinese companies and briefed them regarding investment opportunities in Pakistan. He observed that the true potential of the partnership between the two countries [&#8230;]

## Pakistan earns $372.930m by exporting transport services
 - [https://pakobserver.net/pakistan-earns-372-930m-by-exporting-transport-services](https://pakobserver.net/pakistan-earns-372-930m-by-exporting-transport-services)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:52+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/08/Export-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Pakistan earned US $372.930 million by providing different transport services in various countries during the first four months of the current fiscal year (2023-24) as compared to the corresponding period of last year. This shows an increase of 26.01 percent as compared to $295.959 million earned through the provision of services during the corresponding months [&#8230;]

## Super Asia signs MOU with University of Engineering & Technology
 - [https://pakobserver.net/super-asia-signs-mou-with-university-of-engineering-technology](https://pakobserver.net/super-asia-signs-mou-with-university-of-engineering-technology)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:51+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/New-Asia-news-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Super Asia, a renowned Home Appliances brand and exporter, takes a great initiative towards fostering collaboration between industry and academia by signing an MOU with the University of Engineering &#38; Technology (UET). It is an excellent step that opens the door for many opportunities and growth for UET students by participating in joint R&#38;D in [&#8230;]

## Gold rates decline by Rs.300  per tola
 - [https://pakobserver.net/gold-rates-decline-by-rs-300-per-tola](https://pakobserver.net/gold-rates-decline-by-rs-300-per-tola)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:50+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/gold-rate-in-pakistan-today-24-March-2023-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The per tola price of 24 karat gold decreased by Rs.300 and was sold at Rs.219,700 on Monday compared to its sale at Rs.220,000 on the last trading day. The price of 10 grams of 24 karat gold also decreased by Rs.258 to Rs.188,357 from Rs. 188,615 whereas the price of 10 grams 22 karat [&#8230;]

## Sri Lanka receives over 1.48m tourists in 2023
 - [https://pakobserver.net/sri-lanka-receives-over-1-48m-tourists-in-2023](https://pakobserver.net/sri-lanka-receives-over-1-48m-tourists-in-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:48+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/encomey-watch-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Sri Lanka received 1,487,303 tourists in 2023, an increase of 106.6 percent from 2022, the latest statistics released by the Sri Lanka Tourism Development Authority (SLTDA) showed. Up to 210,352 tourists arrived in December, the data showed. India, Russia, Britain, Germany, Australia, and China were among the top source markets in December. In 2022, Sri [&#8230;]

## Pakistan saw over 115% increase in tourism in 2023: Minister
 - [https://pakobserver.net/pakistan-saw-over-115-increase-in-tourism-in-2023-minister](https://pakobserver.net/pakistan-saw-over-115-increase-in-tourism-in-2023-minister)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:47+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/Wasi-Shah-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Caretaker Minister of State for Tourism Wasi Shah Monday said that in the year 2023 Pakistan saw a 115% increase in foreign tourism which has helped the country earn $1.3 billion in foreign exchange revenue. In an exclusive talk with a private news channel, minister mentioned that according to the ‘World Tourism Barometer’ published by [&#8230;]

## Vietnam records 12.6m int’l visitor arrivals in 2023
 - [https://pakobserver.net/vietnam-records-12-6m-intl-visitor-arrivals-in-2023](https://pakobserver.net/vietnam-records-12-6m-intl-visitor-arrivals-in-2023)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:45+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/encomey-watch-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Vietnam recorded 12.6 million international visitor arrivals in 2023, a 3.4-fold rise from 2022, according to the latest data released by the country’s General Statistics Office. The number far exceeded the target of 8 million foreign tourists set for the year, but was equivalent to only 70 percent of the pre-pandemic level in 2019, said [&#8230;]

## China’s bond market issuances hit 6.53tr yuan in November
 - [https://pakobserver.net/chinas-bond-market-issuances-hit-6-53tr-yuan-in-november](https://pakobserver.net/chinas-bond-market-issuances-hit-6-53tr-yuan-in-november)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/encomey-watch-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Bond issuances in China totaled 6.53 trillion yuan (about 921 billion U.S. dollars) in November 2023, data from China’s central bank showed. Specifically, issuances of treasury bonds came in at over 1.22 trillion yuan, while local government bond issuances amounted to 667.21 billion yuan, according to the People’s Bank of China. In November, financial bond [&#8230;]

## Myanmar’s gold products export booming with zero tariffs
 - [https://pakobserver.net/myanmars-gold-products-export-booming-with-zero-tariffs](https://pakobserver.net/myanmars-gold-products-export-booming-with-zero-tariffs)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-01-02T02:04:43+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/encomey-watch-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; Myanmar’s gold products export is booming with the help of zero tariff on gold export, U Myo Myint, chairman of the Yangon Region Gold Entrepreneurs Association told Xinhua on Monday. Due to market fluctuations, Myanmar’s finished gold products export used to be weak. After the Ministry of Commerce established a new policy of zero [&#8230;]

