# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## New Laws Needed to Prevent Radicalising AI Chatbots, Says Terrorism Legislation Reviewer
 - [https://www.theepochtimes.com/world/new-laws-needed-to-prevent-radicalising-ai-chatbots-says-terrorism-legislation-reviewer-5556590](https://www.theepochtimes.com/world/new-laws-needed-to-prevent-radicalising-ai-chatbots-says-terrorism-legislation-reviewer-5556590)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-01-02T16:26:24+00:00

A person uses an AI chatbot. (Tero Vesalainen/Shutterstock)

## Social Media Companies Made $11 Billion From Ads Served to Minors in US: Harvard Study
 - [https://www.theepochtimes.com/tech/social-media-companies-made-11-billion-from-ads-served-to-minors-in-us-harvard-study-5556558](https://www.theepochtimes.com/tech/social-media-companies-made-11-billion-from-ads-served-to-minors-in-us-harvard-study-5556558)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-01-02T11:45:12+00:00

A young girl looking at social media apps, including TikTok, Instagram, Snapchat, and WhatsApp, on a smartphone on Nov. 12, 2019. (Peter Byrne/PA)

## Cyber Attackers Target Victoria’s Court System
 - [https://www.theepochtimes.com/world/cyber-attackers-target-victorias-court-system-5556458](https://www.theepochtimes.com/world/cyber-attackers-target-victorias-court-system-5556458)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-01-02T01:59:53+00:00

(Color4260/Shutterstock)

