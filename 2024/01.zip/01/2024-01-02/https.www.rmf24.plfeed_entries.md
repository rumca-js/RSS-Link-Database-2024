# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Dramat w Zgorzelcu. Pies zagryzł 2-miesięczną dziewczynkę
 - [https://www.rmf24.pl/fakty/polska/news-dramat-w-zgorzelcu-pies-zagryzl-2-miesieczna-dziewczynke,nId,7245041](https://www.rmf24.pl/fakty/polska/news-dramat-w-zgorzelcu-pies-zagryzl-2-miesieczna-dziewczynke,nId,7245041)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T20:48:52+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-dramat-w-zgorzelcu-pies-zagryzl-2-miesieczna-dziewczynke,nId,7245041"><img align="left" alt="Dramat w Zgorzelcu. Pies zagryzł 2-miesięczną dziewczynkę" src="https://interia-s.pluscdn.pl/dramat-w-zgorzelcu-pies-zagryzl-2-miesieczna-dziewczynke/000IBKBUCJQ5FQER-C307.jpg" /></a>Tragedia w Zgorzelcu na Dolnym Śląsku. Pies pogryzł tam niespełna dwumiesięczną dziewczynkę. Dziecko zmarło. </p><br clear="all" />

## Grupa BRICS mocniejsza. Pięciu nowych członków
 - [https://www.rmf24.pl/ekonomia/news-grupa-brics-mocniejsza-pieciu-nowych-czlonkow,nId,7245037](https://www.rmf24.pl/ekonomia/news-grupa-brics-mocniejsza-pieciu-nowych-czlonkow,nId,7245037)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T20:40:19+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-grupa-brics-mocniejsza-pieciu-nowych-czlonkow,nId,7245037"><img align="left" alt="Grupa BRICS mocniejsza. Pięciu nowych członków" src="https://interia-s.pluscdn.pl/grupa-brics-mocniejsza-pieciu-nowych-czlonkow/000IBK9GAON5SLK1-C307.jpg" /></a>Arabia Saudyjska stała się w poniedziałek członkiem bloku państw znanego jako BRICS - poinformowała we wtorek agencja Reutera, cytując saudyjską telewizję i dodając, że grupa rozszerzyła się także o cztery inne kraje - Zjednoczone Emiraty Arabskie, Egipt, Iran i Etiopię.</p><br clear="all" />

## Prof. Marian Noga gościem Rozmowy o 7:00 w RMF FM i Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-prof-marian-noga-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf,nId,7245024](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-prof-marian-noga-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf,nId,7245024)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T20:33:01+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-prof-marian-noga-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf,nId,7245024"><img align="left" alt="Prof. Marian Noga gościem Rozmowy o 7:00 w RMF FM i Radiu RMF24" src="https://interia-s.pluscdn.pl/prof-marian-noga-gosciem-rozmowy-o-7-00-w-rmf-fm-i-radiu-rmf/000IBK66K8D81F37-C307.jpg" /></a>Jak powinno się wspierać kredytobiorców, którzy chcieliby kupić mieszkanie na własny użytek? Czy zakończony już program kredytu dwa procent był odpowiednim wsparciem dla najbardziej potrzebujących mieszkania, czy raczej dla popularności rządzących, zysków deweloperów i tych, którzy sprawnie potrafili wykorzystać tę możliwość, by się wzbogacić? Czy w obliczu zagrożenia ze Wschodu, niedozbrojenia naszej armii i ogromnego wzrostu wydatków na zbrojenia, w ogóle stać nas na politykę rozszerzania wydatków społecznych? O to między innymi będziemy...</p><br clear="all" />

## Czystki w dyplomacji? „Część ambasadorów nie nadaje się na stanowiska”
 - [https://www.rmf24.pl/polityka/news-czystki-w-dyplomacji-czesc-ambasadorow-nie-nadaje-sie-na-sta,nId,7245019](https://www.rmf24.pl/polityka/news-czystki-w-dyplomacji-czesc-ambasadorow-nie-nadaje-sie-na-sta,nId,7245019)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T19:42:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-czystki-w-dyplomacji-czesc-ambasadorow-nie-nadaje-sie-na-sta,nId,7245019"><img align="left" alt="Czystki w dyplomacji? „Część ambasadorów nie nadaje się na stanowiska”" src="https://interia-s.pluscdn.pl/czystki-w-dyplomacji-czesc-ambasadorow-nie-nadaje-sie-na-sta/000IBK36F1VAUGQB-C307.jpg" /></a>„Część ambasadorów RP ewidentnie nie nadaje się na te stanowiska z rozmaitych powodów i zostanie odwołana” - powiedział we wtorek w Polsat News wiceszef MSZ Władysław Teofil Bartoszewski, podkreślając, że to nie będzie proces nagły. &quot;Trzeba będzie przeglądać placówkę po placówce&quot; - zaznaczył.</p><br clear="all" />

## Blokada przejścia w Medyce. Jutro decyzja
 - [https://www.rmf24.pl/fakty/polska/news-blokada-przejscia-w-medyce-jutro-decyzja,nId,7245020](https://www.rmf24.pl/fakty/polska/news-blokada-przejscia-w-medyce-jutro-decyzja,nId,7245020)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T19:41:21+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-blokada-przejscia-w-medyce-jutro-decyzja,nId,7245020"><img align="left" alt="Blokada przejścia w Medyce. Jutro decyzja" src="https://interia-s.pluscdn.pl/blokada-przejscia-w-medyce-jutro-decyzja/000IBK3XNBM9D3CH-C307.jpg" /></a>Rolnicy z „Podkarpackiej oszukanej wsi” w środę zdecydują, czy będą kontynuować swój protest i blokować przejście graniczne w Medyce. „Jeśli nie dostaniemy na piśmie potwierdzenie, że nasze postulaty będą spełnione, wrócimy na blokadę” – powiedział lider organizacji Roman Kondrów.</p><br clear="all" />

## Cena ta sama, produktu mniej. Francuzi wypowiadają wojnę „shrinkflacji”
 - [https://www.rmf24.pl/ekonomia/news-cena-ta-sama-produktu-mniej-francuzi-wypowiadaja-wojne-shrin,nId,7245003](https://www.rmf24.pl/ekonomia/news-cena-ta-sama-produktu-mniej-francuzi-wypowiadaja-wojne-shrin,nId,7245003)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T18:55:31+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-cena-ta-sama-produktu-mniej-francuzi-wypowiadaja-wojne-shrin,nId,7245003"><img align="left" alt="Cena ta sama, produktu mniej. Francuzi wypowiadają wojnę „shrinkflacji”" src="https://interia-s.pluscdn.pl/cena-ta-sama-produktu-mniej-francuzi-wypowiadaja-wojne-shrin/000IBK06X2FYM88J-C307.jpg" /></a>Francuskie władze chcą walczyć z praktyką polegającą na sprzedawaniu w tej samej cenie zmniejszonej ilości produktu. Rząd chce, by producenci i sprzedawcy zostali zobowiązani do informowania o takich działaniach – poinformował we wtorek portal Just Food. </p><br clear="all" />

## Nazwał papieża Franciszka "uzurpatorem". Ksiądz ukarany ekskomuniką
 - [https://www.rmf24.pl/fakty/swiat/news-nazwal-papieza-franciszka-uzurpatorem-ksiadz-ukarany-ekskomu,nId,7244997](https://www.rmf24.pl/fakty/swiat/news-nazwal-papieza-franciszka-uzurpatorem-ksiadz-ukarany-ekskomu,nId,7244997)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T18:23:45+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-nazwal-papieza-franciszka-uzurpatorem-ksiadz-ukarany-ekskomu,nId,7244997"><img align="left" alt="Nazwał papieża Franciszka &quot;uzurpatorem&quot;. Ksiądz ukarany ekskomuniką" src="https://interia-s.pluscdn.pl/nazwal-papieza-franciszka-uzurpatorem-ksiadz-ukarany-ekskomu/000IBJWBEG30T6B2-C307.jpg" /></a>Włoski ksiądz został ekskomunikowany za to, że nazwał papieża Franciszka &quot;uzurpatorem&quot; - podały media. Decyzję podjął biskup diecezji Livorno w Toskanii, Simone Giusti, wydając specjalny dekret w tej sprawie.</p><br clear="all" />

## Nieprawdziwe kursy walut. Google odpowiada
 - [https://www.rmf24.pl/ekonomia/news-nieprawdziwe-kursy-walut-google-odpowiada,nId,7244996](https://www.rmf24.pl/ekonomia/news-nieprawdziwe-kursy-walut-google-odpowiada,nId,7244996)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T18:23:33+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-nieprawdziwe-kursy-walut-google-odpowiada,nId,7244996"><img align="left" alt="Nieprawdziwe kursy walut. Google odpowiada" src="https://interia-s.pluscdn.pl/nieprawdziwe-kursy-walut-google-odpowiada/000IBJWDFFTUVTHY-C307.jpg" /></a>„Tymczasowo wyłączyliśmy funkcję wyświetlania kursów walut. Przepraszamy za tę sytuację” – tak koncern Google odpowiada resortom finansów i cyfryzacji na ich pytania o przyczyny nieprawdziwej publikacji dotyczącej kursu złotego. Rząd chciał ustalić, dlaczego doszło do tak poważnego błędu, który mógł wywołać panikę na rynku.</p><br clear="all" />

## Izrael zaatakował biuro Hamasu w Libanie. Zginął jeden z liderów
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-izrael-zaatakowal-biuro-hamasu-w-libanie-zginal-jeden-z-lide,nId,7244982](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-izrael-zaatakowal-biuro-hamasu-w-libanie-zginal-jeden-z-lide,nId,7244982)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T17:33:26+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-izrael-zaatakowal-biuro-hamasu-w-libanie-zginal-jeden-z-lide,nId,7244982"><img align="left" alt="Izrael zaatakował biuro Hamasu w Libanie. Zginął jeden z liderów " src="https://interia-s.pluscdn.pl/izrael-zaatakowal-biuro-hamasu-w-libanie-zginal-jeden-z-lide/000IBJR8L5XAOILH-C307.jpg" /></a>Jeden z liderów palestyńskiego Hamasu Saleh al-Arouri zginął w ataku, jaki armia Izraela przeprowadziła przy pomocy drona na biuro Hamasu znajdujące się na przedmieściach libańskiej stolicy, Bejrutu. Zginęły też trzy inne osoby - poinformowała agencja Reutera, powołując się na libańskie media.</p><br clear="all" />

## Przydacz: Prezydent wyciągnął wnioski z historii. Pamięta, jak było za czasów Lecha Kaczyńskiego
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-przydacz-prezydent-wyciagnal-wnioski-z-historii-pamieta-jak-,nId,7244764](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-przydacz-prezydent-wyciagnal-wnioski-z-historii-pamieta-jak-,nId,7244764)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T17:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-przydacz-prezydent-wyciagnal-wnioski-z-historii-pamieta-jak-,nId,7244764"><img align="left" alt="Przydacz: Prezydent wyciągnął wnioski z historii. Pamięta, jak było za czasów Lecha Kaczyńskiego" src="https://interia-s.pluscdn.pl/przydacz-prezydent-wyciagnal-wnioski-z-historii-pamieta-jak/000IBIZZOQMWQ0RU-C307.jpg" /></a>„Prezydent wysyła sygnały otwartości na współpracę. Nie są to pierwsze sygnały, bo nie tylko w orędziu noworocznym mówił o tym, że jest gotów do współpracy. Ale wyciągnął także wnioski z historii. Pamięta dokładnie, jak to było za czasów prezydenta Lecha Kaczyńskiego - bo był wówczas jego ministrem - jak agresywnie miejscami ówczesny rząd Donalda Tuska traktował prezydenta. Prezydent mówi: znam tę historię, jestem przygotowany na brak gotowości do współpracy” – tak noworoczne orędzie prezydenta skomentował w Popołudniowej rozmowie w RMF FM...</p><br clear="all" />

## Pijany rozpędzonym audi wjechał w dom [ZDJĘCIA]
 - [https://www.rmf24.pl/regiony/rzeszow/news-pijany-rozpedzonym-audi-wjechal-w-dom-zdjecia,nId,7244823](https://www.rmf24.pl/regiony/rzeszow/news-pijany-rozpedzonym-audi-wjechal-w-dom-zdjecia,nId,7244823)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T16:51:50+00:00

<p><a href="https://www.rmf24.pl/regiony/rzeszow/news-pijany-rozpedzonym-audi-wjechal-w-dom-zdjecia,nId,7244823"><img align="left" alt="Pijany rozpędzonym audi wjechał w dom [ZDJĘCIA]" src="https://interia-s.pluscdn.pl/pijany-rozpedzonym-audi-wjechal-w-dom-zdjecia/000IBJE5RA756EIF-C307.jpg" /></a>Policja z Krosna w woj. podkarpackim opublikowała zdjęcia z wypadku, do którego doszło noc wcześniej. Rozpędzone audi uderzyło w dom. Na szczęście nikomu nic poważnego się nie stało. </p><br clear="all" />

## Krzysztof Głowacki zdyskwalifikowany. Boksera przyłapano na dopingu
 - [https://www.rmf24.pl/sport/news-krzysztof-glowacki-zdyskwalifikowany-boksera-przylapano-na-d,nId,7244821](https://www.rmf24.pl/sport/news-krzysztof-glowacki-zdyskwalifikowany-boksera-przylapano-na-d,nId,7244821)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T16:50:20+00:00

<p><a href="https://www.rmf24.pl/sport/news-krzysztof-glowacki-zdyskwalifikowany-boksera-przylapano-na-d,nId,7244821"><img align="left" alt="Krzysztof Głowacki zdyskwalifikowany. Boksera przyłapano na dopingu" src="https://interia-s.pluscdn.pl/krzysztof-glowacki-zdyskwalifikowany-boksera-przylapano-na-d/000IBJEL5EIDFYL4-C307.jpg" /></a>Były mistrz świata WBO w wadze junior ciężkiej Krzysztof Głowacki zdyskwalifikowany. Jak podaje Reuters, dziś zawodnik MMA, a do grudnia 2023 roku bokser, nie będzie mógł występować w zawodach pieściarskich przez cztery lata za wykrycie w jego organizmie sterydu nowej generacji.</p><br clear="all" />

## Marcin Przydacz gościem Popołudniowej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-marcin-przydacz-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7244764](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-marcin-przydacz-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7244764)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T16:19:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-marcin-przydacz-gosciem-popoludniowej-rozmowy-w-rmf-fm,nId,7244764"><img align="left" alt="Marcin Przydacz gościem Popołudniowej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/marcin-przydacz-gosciem-popoludniowej-rozmowy-w-rmf-fm/000IBIZZOQMWQ0RU-C307.jpg" /></a>Gościem Popołudniowej rozmowy w RMF FM będzie Marcin Przydacz, poseł PiS. Porozmawiamy o orędziu noworocznym prezydenta Dudy – czy to zapowiedź wojny z rządem Donalda Tuska czy walka o przywództwo na prawicy? </p><br clear="all" />

## Akcja słowackich ratowników. Polacy utknęli w Dolinie Wielickiej
 - [https://www.rmf24.pl/fakty/swiat/news-akcja-slowackich-ratownikow-polacy-utkneli-w-dolinie-wielick,nId,7244795](https://www.rmf24.pl/fakty/swiat/news-akcja-slowackich-ratownikow-polacy-utkneli-w-dolinie-wielick,nId,7244795)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T16:00:05+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-akcja-slowackich-ratownikow-polacy-utkneli-w-dolinie-wielick,nId,7244795"><img align="left" alt="Akcja słowackich ratowników. Polacy utknęli w Dolinie Wielickiej" src="https://interia-s.pluscdn.pl/akcja-slowackich-ratownikow-polacy-utkneli-w-dolinie-wielick/000IBJ87MR0RSO3B-C307.jpg" /></a>Słowaccy ratownicy górscy ewakuowali na pokładzie śmigłowca dwoje polskich turystów, którzy utknęli w Dolinie Wielickiej. Para nie miała odpowiedniego zimowego sprzętu turystycznego.</p><br clear="all" />

## Skandal we Włoszech. Na imprezie sylwestrowej polityków wystrzeliła broń
 - [https://www.rmf24.pl/fakty/swiat/news-skandal-we-wloszech-na-imprezie-sylwestrowej-politykow-wystr,nId,7244791](https://www.rmf24.pl/fakty/swiat/news-skandal-we-wloszech-na-imprezie-sylwestrowej-politykow-wystr,nId,7244791)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T15:45:27+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-skandal-we-wloszech-na-imprezie-sylwestrowej-politykow-wystr,nId,7244791"><img align="left" alt="Skandal we Włoszech. Na imprezie sylwestrowej polityków wystrzeliła broń" src="https://interia-s.pluscdn.pl/skandal-we-wloszech-na-imprezie-sylwestrowej-politykow-wystr/000IBJ697WWWS9VQ-C307.jpg" /></a>2024 rok nie zaczyna się najlepiej dla partii Giorgii Meloni. Na imprezie sylwestrowej z udziałem polityków jej partii wystrzeliła broń. Jedna osoba trafiła do szpitala.</p><br clear="all" />

## Z pubu w Sydney na tron w Kopenhadze, czyli Australijka duńską królową
 - [https://www.rmf24.pl/ciekawostki/news-z-pubu-w-sydney-na-tron-w-kopenhadze-czyli-australijka-dunsk,nId,7244775](https://www.rmf24.pl/ciekawostki/news-z-pubu-w-sydney-na-tron-w-kopenhadze-czyli-australijka-dunsk,nId,7244775)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T15:12:33+00:00

<p><a href="https://www.rmf24.pl/ciekawostki/news-z-pubu-w-sydney-na-tron-w-kopenhadze-czyli-australijka-dunsk,nId,7244775"><img align="left" alt="Z pubu w Sydney na tron w Kopenhadze, czyli Australijka duńską królową " src="https://interia-s.pluscdn.pl/z-pubu-w-sydney-na-tron-w-kopenhadze-czyli-australijka-dunsk/000IBJ4LOWJ1JNNB-C307.jpg" /></a>14 stycznia na duńskim tronie zasiądzie 55-letni książę Fryderyk, a obok niego jako królowa Danii jego małżonka – Mary z Australii. W Sylwestra nieoczekiwanie swoją abdykację ogłosiła 83-letnia królowa Małgorzata II.</p><br clear="all" />

## Skatował mężczyznę podczas libacji. Napastnikowi grozi dożywocie
 - [https://www.rmf24.pl/regiony/krakow/news-skatowal-mezczyzne-podczas-libacji-napastnikowi-grozi-dozywo,nId,7244772](https://www.rmf24.pl/regiony/krakow/news-skatowal-mezczyzne-podczas-libacji-napastnikowi-grozi-dozywo,nId,7244772)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T15:08:22+00:00

<p><a href="https://www.rmf24.pl/regiony/krakow/news-skatowal-mezczyzne-podczas-libacji-napastnikowi-grozi-dozywo,nId,7244772"><img align="left" alt="Skatował mężczyznę podczas libacji. Napastnikowi grozi dożywocie" src="https://interia-s.pluscdn.pl/skatowal-mezczyzne-podczas-libacji-napastnikowi-grozi-dozywo/000IBJ6GGV2MYY18-C307.jpg" /></a>O włos od tragedii podczas libacji na terenie gminy Wolbrom w Małopolsce. 27-latek bił i kopał po twarzy 51-latka, a na koniec zaatakował go nożem - teraz młodemu mężczyźnie grozi 25 lat więzienia albo nawet dożywocie.</p><br clear="all" />

## Denerwował ich płacz niemowlęcia. Rodzice z zarzutami
 - [https://www.rmf24.pl/regiony/poznan/news-denerwowal-ich-placz-niemowlecia-rodzice-z-zarzutami,nId,7244717](https://www.rmf24.pl/regiony/poznan/news-denerwowal-ich-placz-niemowlecia-rodzice-z-zarzutami,nId,7244717)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T14:56:31+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-denerwowal-ich-placz-niemowlecia-rodzice-z-zarzutami,nId,7244717"><img align="left" alt="Denerwował ich płacz niemowlęcia. Rodzice z zarzutami " src="https://interia-s.pluscdn.pl/denerwowal-ich-placz-niemowlecia-rodzice-z-zarzutami/000IBI055FQESUW2-C307.jpg" /></a>Para z okolic Kępna w Wielkopolsce usłyszała zarzuty fizycznego i psychicznego znęcania się nad dwumiesięczną córką. &quot;Denerwował ich płacz dziecka&quot; - poinformował we wtorek PAP rzecznik prasowy Prokuratury okręgowej w Ostrowie Wlk. Maciej Meler.</p><br clear="all" />

## Ewakuacja turysty w Tatrach. Nie był przygotowany na zimowe warunki
 - [https://www.rmf24.pl/regiony/zakopane/news-ewakuacja-turysty-w-tatrach-nie-byl-przygotowany-na-zimowe-w,nId,7244756](https://www.rmf24.pl/regiony/zakopane/news-ewakuacja-turysty-w-tatrach-nie-byl-przygotowany-na-zimowe-w,nId,7244756)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T14:39:59+00:00

<p><a href="https://www.rmf24.pl/regiony/zakopane/news-ewakuacja-turysty-w-tatrach-nie-byl-przygotowany-na-zimowe-w,nId,7244756"><img align="left" alt="Ewakuacja turysty w Tatrach. Nie był przygotowany na zimowe warunki" src="https://interia-s.pluscdn.pl/ewakuacja-turysty-w-tatrach-nie-byl-przygotowany-na-zimowe-w/000IBITYLBPPEU42-C307.jpg" /></a>Ratownicy TOPR ewakuowali turystę, który utknął w rejonie Kobylarzowego Żlebu i nie był w stanie samodzielnie kontynuować wycieczki – poinformował ratownik dyżurny.</p><br clear="all" />

## Śląskie: Strzały w czasie policyjnego pościgu
 - [https://www.rmf24.pl/regiony/slaskie/news-slaskie-strzaly-w-czasie-policyjnego-poscigu,nId,7244742](https://www.rmf24.pl/regiony/slaskie/news-slaskie-strzaly-w-czasie-policyjnego-poscigu,nId,7244742)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T14:29:00+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-slaskie-strzaly-w-czasie-policyjnego-poscigu,nId,7244742"><img align="left" alt="Śląskie: Strzały w czasie policyjnego pościgu" src="https://interia-s.pluscdn.pl/slaskie-strzaly-w-czasie-policyjnego-poscigu/000IBI31XAJY74YK-C307.jpg" /></a>Policyjny pościg odbył się między Suszcem i Kobiórem na Śląsku. W czasie akcji padły strzały ostrzegawcze. </p><br clear="all" />

## Turniej Czterech Skoczni. Ilu Polaków wystąpi w Innsbrucku?
 - [https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-turniej-czterech-skoczni-ilu-polakow-wystapi-w-innsbrucku,nId,7244726](https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-turniej-czterech-skoczni-ilu-polakow-wystapi-w-innsbrucku,nId,7244726)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T14:03:05+00:00

<p><a href="https://www.rmf24.pl/raport-skoki-narciarskie-2023-2024/news-turniej-czterech-skoczni-ilu-polakow-wystapi-w-innsbrucku,nId,7244726"><img align="left" alt="Turniej Czterech Skoczni. Ilu Polaków wystąpi w Innsbrucku?" src="https://interia-s.pluscdn.pl/turniej-czterech-skoczni-ilu-polakow-wystapi-w-innsbrucku/000IBI26FPA9ECII-C307.jpg" /></a>Zakończyły się kwalifikacje do jutrzejszego konkursu w Innsbrucku w Turnieju Czterech Skoczni. W zawodach wystąpi pięciu Polaków.  </p><br clear="all" />

## Jest śledztwo ws. skandalicznych słów Jana Pietrzaka
 - [https://www.rmf24.pl/fakty/polska/news-jest-sledztwo-ws-skandalicznych-slow-jana-pietrzaka,nId,7244711](https://www.rmf24.pl/fakty/polska/news-jest-sledztwo-ws-skandalicznych-slow-jana-pietrzaka,nId,7244711)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T13:58:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-jest-sledztwo-ws-skandalicznych-slow-jana-pietrzaka,nId,7244711"><img align="left" alt="Jest śledztwo ws. skandalicznych słów Jana Pietrzaka" src="https://interia-s.pluscdn.pl/jest-sledztwo-ws-skandalicznych-slow-jana-pietrzaka/000IBHYZG46ML5V1-C307.jpg" /></a>Prokuratura Okręgowa w Warszawie wszczęła śledztwo ws. skandalicznej wypowiedzi Jana Pietrzaka - dowiedział się reporter RMF FM Krzysztof Zasada. &quot;Mamy baraki dla imigrantów: w Auschwitz, w Majdanku, w Treblince, w Stutthofie&quot; - mówił satyryk w Telewizji Republika, zastrzegając jednocześnie, że to &quot;okrutny żart&quot;. </p><br clear="all" />

## Zniszczony dom ukraińskiej posłanki. Opublikowała zdjęcia
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zniszczony-dom-ukrainskiej-poslanki-opublikowala-zdjecia,nId,7244691](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zniszczony-dom-ukrainskiej-poslanki-opublikowala-zdjecia,nId,7244691)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T13:19:51+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zniszczony-dom-ukrainskiej-poslanki-opublikowala-zdjecia,nId,7244691"><img align="left" alt="Zniszczony dom ukraińskiej posłanki. Opublikowała zdjęcia" src="https://interia-s.pluscdn.pl/zniszczony-dom-ukrainskiej-poslanki-opublikowala-zdjecia/000IBHWC5EN198BV-C307.jpg" /></a>Kijów, obwód kijowski i Charków były głównym celem dzisiejszego zmasowanego ataku na Ukrainę. Rosyjska rakieta uderzyła obok domu ukraińskiej posłanki. Kira Rudyk opublikowała zdjęcia zniszczonego mieszkania. </p><br clear="all" />

## Wjechał autem w pole koło Zimnej Wódki. Na alkomacie zabrakło skali
 - [https://www.rmf24.pl/fakty/polska/news-wjechal-autem-w-pole-kolo-zimnej-wodki-na-alkomacie-zabraklo,nId,7244668](https://www.rmf24.pl/fakty/polska/news-wjechal-autem-w-pole-kolo-zimnej-wodki-na-alkomacie-zabraklo,nId,7244668)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T12:28:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-wjechal-autem-w-pole-kolo-zimnej-wodki-na-alkomacie-zabraklo,nId,7244668"><img align="left" alt="Wjechał autem w pole koło Zimnej Wódki. Na alkomacie zabrakło skali " src="https://interia-s.pluscdn.pl/wjechal-autem-w-pole-kolo-zimnej-wodki-na-alkomacie-zabraklo/000IBHPOLGH3YNE1-C307.jpg" /></a>Policjanci ze Strzelec Opolskich zatrzymali 23-latka, który po pijanemu wjechał autem w pole koło Zimnej Wódki. W momencie zatrzymania nie można było określić ilości alkoholu w organizmie kierującego, bo na alkomacie skończyła się skala.</p><br clear="all" />

## Pożar domu w Stalowej Woli. Nie żyje jedna osoba
 - [https://www.rmf24.pl/regiony/rzeszow/news-pozar-domu-w-stalowej-woli-nie-zyje-jedna-osoba,nId,7244665](https://www.rmf24.pl/regiony/rzeszow/news-pozar-domu-w-stalowej-woli-nie-zyje-jedna-osoba,nId,7244665)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T12:21:47+00:00

<p><a href="https://www.rmf24.pl/regiony/rzeszow/news-pozar-domu-w-stalowej-woli-nie-zyje-jedna-osoba,nId,7244665"><img align="left" alt="Pożar domu w Stalowej Woli. Nie żyje jedna osoba" src="https://interia-s.pluscdn.pl/pozar-domu-w-stalowej-woli-nie-zyje-jedna-osoba/000IBHQ4V3TUTLKY-C307.jpg" /></a>Jedna osoba zginęła w pożarze domu w Stalowej Woli na Podkarpaciu. Dwie osoby zdążyły się ewakuować przed przyjazdem straży pożarnej.</p><br clear="all" />

## Minus 40 stopni! Rekordowy mróz w Szwecji
 - [https://www.rmf24.pl/pogoda/news-minus-40-stopni-rekordowy-mroz-w-szwecji,nId,7244662](https://www.rmf24.pl/pogoda/news-minus-40-stopni-rekordowy-mroz-w-szwecji,nId,7244662)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T12:19:37+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-minus-40-stopni-rekordowy-mroz-w-szwecji,nId,7244662"><img align="left" alt="Minus 40 stopni! Rekordowy mróz w Szwecji" src="https://interia-s.pluscdn.pl/minus-40-stopni-rekordowy-mroz-w-szwecji/000IBHON7547ML2J-C307.jpg" /></a>Na północy Szwecji w nocy w trzech miejscowościach padł rekord zimna, temperatura spadła poniżej minus 40 stopni. Śnieżyce nawiedziły południową Norwegię, gdzie zamknięto szkoły. Nad Skandynawię nadciąga kolejny niż, przed którym synoptycy już teraz ostrzegają. Z powodu złych warunków atmosferycznych nie wypłynęły promy kursujące między Polską a Szwecją.</p><br clear="all" />

## Zełenski: Putin pożre was z waszym NATO, UE i demokracją
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zelenski-putin-pozre-was-z-waszym-nato-ue-i-demokracja,nId,7244535](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zelenski-putin-pozre-was-z-waszym-nato-ue-i-demokracja,nId,7244535)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T11:30:25+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zelenski-putin-pozre-was-z-waszym-nato-ue-i-demokracja,nId,7244535"><img align="left" alt="Zełenski: Putin pożre was z waszym NATO, UE i demokracją" src="https://interia-s.pluscdn.pl/zelenski-putin-pozre-was-z-waszym-nato-ue-i-demokracja/000IBHJTMKX2G7J5-C307.jpg" /></a>Wołodymyr Zełenski jest wściekły. W noworocznym wywiadzie dla brytyjskiego &quot;The Economist&quot; ukraiński prezydent nie ukrywa swojej irytacji postawą Zachodu, a także niektórych krajanów - za bardzo, jak uważa, zdystansowanych wobec sytuacji Ukrainy. &quot;Być może nie udało nam się tak, jak chciałby tego świat. Nie wszystko dzieje się tak, jak niektórzy sobie wyobrażali&quot; - przyznaje Zełenski, ale podkreśla, że sytuacja cały czas jest pod kontrolą Kijowa.</p><br clear="all" />

## Koniec zniżki za płatności automatyczne na autostradzie A4 Katowice-Kraków
 - [https://www.rmf24.pl/fakty/polska/news-koniec-znizki-za-platnosci-automatyczne-na-autostradzie-a4-k,nId,7244634](https://www.rmf24.pl/fakty/polska/news-koniec-znizki-za-platnosci-automatyczne-na-autostradzie-a4-k,nId,7244634)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T11:22:27+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-koniec-znizki-za-platnosci-automatyczne-na-autostradzie-a4-k,nId,7244634"><img align="left" alt="Koniec zniżki za płatności automatyczne na autostradzie A4 Katowice-Kraków" src="https://interia-s.pluscdn.pl/koniec-znizki-za-platnosci-automatyczne-na-autostradzie-a4-k/000IBHJWL77DAE26-C307.jpg" /></a>Zarządca płatnej autostrady A4 Katowice-Kraków 16 stycznia br. zniesie zniżkę za przejazd z wykorzystaniem płatności automatycznych. Oznacza to, że cena na każdej bramce dla kierowców samochodów osobowych wyniesie 15 zł (dotąd ze zniżką było to 13 zł).</p><br clear="all" />

## Policja poszukuje kierowcy, który potrącił 67-latkę na pasach w Ostrowie Wielkopolskim
 - [https://www.rmf24.pl/regiony/poznan/news-policja-poszukuje-kierowcy-ktory-potracil-67-latke-na-pasach,nId,7244618](https://www.rmf24.pl/regiony/poznan/news-policja-poszukuje-kierowcy-ktory-potracil-67-latke-na-pasach,nId,7244618)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T11:07:00+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-policja-poszukuje-kierowcy-ktory-potracil-67-latke-na-pasach,nId,7244618"><img align="left" alt="Policja poszukuje kierowcy, który potrącił 67-latkę na pasach w Ostrowie Wielkopolskim " src="https://interia-s.pluscdn.pl/policja-poszukuje-kierowcy-ktory-potracil-67-latke-na-pasach/000IBHHKVY60ILE7-C307.jpg" /></a>Policja poszukuje sprawcy potrącenia 67-letniej kobiety na przejściu dla pieszych – poinformowała oficer prasowy ostrowskiej policji podkom. Małgorzata Michaś. Do zdarzenia doszło w poniedziałek o godz. 17.30 przy Al. Wojska Polskiego w Ostrowie Wielkopolskim.</p><br clear="all" />

## Dlaczego poderwano F-16? Gen. Rajchel tłumaczy
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-dlaczego-poderwano-f-16-gen-rajchel-tlumaczy,nId,7244560](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-dlaczego-poderwano-f-16-gen-rajchel-tlumaczy,nId,7244560)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T11:00:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-dlaczego-poderwano-f-16-gen-rajchel-tlumaczy,nId,7244560"><img align="left" alt="Dlaczego poderwano F-16? Gen. Rajchel tłumaczy" src="https://interia-s.pluscdn.pl/dlaczego-poderwano-f-16-gen-rajchel-tlumaczy/000IBH7AK7C2CLWU-C307.jpg" /></a>&quot;W trakcie intensywnych nalotów dochodzi do zamierzonego bądź niezamierzonego przelotu przez naszą granicę rosyjskich rakiet. Jedynym sposobem zniszczenia rakiety, która wleci w naszą przestrzeń powietrzną, jest użycie lotnictwa myśliwskiego&quot; - tak gen. Jan Rajchel tłumaczył w Rozmowie w południe w RMF FM i Radiu RMF24, dlaczego rano poderwane zostały dwie pary - polska i amerykańska - myśliwców F-16. </p><br clear="all" />

## Koniec Bezpiecznego Kredytu 2 Procent
 - [https://www.rmf24.pl/ekonomia/news-koniec-bezpiecznego-kredytu-2-procent,nId,7244606](https://www.rmf24.pl/ekonomia/news-koniec-bezpiecznego-kredytu-2-procent,nId,7244606)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T10:51:14+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-koniec-bezpiecznego-kredytu-2-procent,nId,7244606"><img align="left" alt="Koniec Bezpiecznego Kredytu 2 Procent" src="https://interia-s.pluscdn.pl/koniec-bezpiecznego-kredytu-2-procent/000IBHGLKWY2G59Y-C307.jpg" /></a>Kto nie skorzystał do tej pory z Bezpiecznego Kredytu 2 Procent, ten już może o tym zapomnieć. Bank Gospodarstwa Krajowego wstrzymał przyjmowanie wniosków. Ministerstwo Rozwoju i Technologii zapowiada, że program będzie wygaszany.</p><br clear="all" />

## Ciało mężczyzny znaleziono w szkole w Gorzowie Wielkopolskim
 - [https://www.rmf24.pl/regiony/news-cialo-mezczyzny-znaleziono-w-szkole-w-gorzowie-wielkopolskim,nId,7244603](https://www.rmf24.pl/regiony/news-cialo-mezczyzny-znaleziono-w-szkole-w-gorzowie-wielkopolskim,nId,7244603)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T10:31:00+00:00

<p><a href="https://www.rmf24.pl/regiony/news-cialo-mezczyzny-znaleziono-w-szkole-w-gorzowie-wielkopolskim,nId,7244603"><img align="left" alt="Ciało mężczyzny znaleziono w szkole w Gorzowie Wielkopolskim " src="https://interia-s.pluscdn.pl/cialo-mezczyzny-znaleziono-w-szkole-w-gorzowie-wielkopolskim/000IBHED1950JQ4B-C307.jpg" /></a>Ciało około 50-letniego mężczyzny znaleziono w Szkole Podstawowej numer 2 w Gorzowie Wielkopolskim. Trwa ustalanie przyczyn jego śmierci, a lekcje w placówce zostały zawieszone. </p><br clear="all" />

## Prawie tydzień bez jedzenia i ogrzewania. Seniorka zatrzasnęła się na strychu
 - [https://www.rmf24.pl/regiony/lublin/news-prawie-tydzien-bez-jedzenia-i-ogrzewania-seniorka-zatrzasnel,nId,7244595](https://www.rmf24.pl/regiony/lublin/news-prawie-tydzien-bez-jedzenia-i-ogrzewania-seniorka-zatrzasnel,nId,7244595)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T10:21:00+00:00

<p><a href="https://www.rmf24.pl/regiony/lublin/news-prawie-tydzien-bez-jedzenia-i-ogrzewania-seniorka-zatrzasnel,nId,7244595"><img align="left" alt="Prawie tydzień bez jedzenia i ogrzewania. Seniorka zatrzasnęła się na strychu " src="https://interia-s.pluscdn.pl/prawie-tydzien-bez-jedzenia-i-ogrzewania-seniorka-zatrzasnel/000IBHDMWIQ8VQ4B-C307.jpg" /></a>Sześć dni - bez ogrzewania i jedzenia - spędziła na strychu 72-letnia kobieta, która zatrzasnęła się w pomieszczeniu. Seniorka z Lubyczy Królewskiej (Lubelskie) trafiła do szpitala. Powoli wraca do zdrowia.</p><br clear="all" />

## Mariusz Kamiński i Maciej Wąsik walczą o utrzymanie mandatów poselskich
 - [https://www.rmf24.pl/polityka/news-mariusz-kaminski-i-maciej-wasik-walcza-o-utrzymanie-mandatow,nId,7244588](https://www.rmf24.pl/polityka/news-mariusz-kaminski-i-maciej-wasik-walcza-o-utrzymanie-mandatow,nId,7244588)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T10:15:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-mariusz-kaminski-i-maciej-wasik-walcza-o-utrzymanie-mandatow,nId,7244588"><img align="left" alt="Mariusz Kamiński i Maciej Wąsik walczą o utrzymanie mandatów poselskich" src="https://interia-s.pluscdn.pl/mariusz-kaminski-i-maciej-wasik-walcza-o-utrzymanie-mandatow/000IBHBOOYWLAOJN-C307.jpg" /></a>Mimo wygaszenia mandatów poselskich Mariusz Kamiński i Maciej Wąsik prawdopodobnie wezmą udział w przyszłotygodniowym posiedzeniu Sejmu. Postanowienie marszałka Sejmu w tej sprawie zaskarżone przez posłów do Sądu Najwyższego powinno być rozpatrzone w ciągu 7 dni. Na razie jednak procedura nie została jeszcze wszczęta.</p><br clear="all" />

## Nie żyje "Profesor Zdrówko" - Małgorzata Kozłowska-Wojciechowska
 - [https://www.rmf24.pl/aktualnosci/news-nie-zyje-profesor-zdrowko-malgorzata-kozlowska-wojciechowska,nId,7244573](https://www.rmf24.pl/aktualnosci/news-nie-zyje-profesor-zdrowko-malgorzata-kozlowska-wojciechowska,nId,7244573)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T09:58:00+00:00

<p><a href="https://www.rmf24.pl/aktualnosci/news-nie-zyje-profesor-zdrowko-malgorzata-kozlowska-wojciechowska,nId,7244573"><img align="left" alt="Nie żyje &quot;Profesor Zdrówko&quot; - Małgorzata Kozłowska-Wojciechowska" src="https://interia-s.pluscdn.pl/nie-zyje-profesor-zdrowko-malgorzata-kozlowska-wojciechowska/000IBHAL9K3SQAAJ-C307.jpg" /></a>W wieku 72 lat zmarła prof. Małgorzata Kozłowska-Wojciechowska, znana jako &quot;Profesor Zdrówko&quot;. O jej śmierci poinformowała dziennikarka Katarzyna Bosacka.</p><br clear="all" />

## Ministerstwo Finansów wezwie Google do złożenia wyjaśnień
 - [https://www.rmf24.pl/ekonomia/news-ministerstwo-finansow-wezwie-google-do-zlozenia-wyjasnien,nId,7244571](https://www.rmf24.pl/ekonomia/news-ministerstwo-finansow-wezwie-google-do-zlozenia-wyjasnien,nId,7244571)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T09:50:48+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-ministerstwo-finansow-wezwie-google-do-zlozenia-wyjasnien,nId,7244571"><img align="left" alt="Ministerstwo Finansów wezwie Google do złożenia wyjaśnień" src="https://interia-s.pluscdn.pl/ministerstwo-finansow-wezwie-google-do-zlozenia-wyjasnien/000IBHB2QXJX0851-C307.jpg" /></a>Ministerstwo Finansów wezwie amerykański koncern Google do złożenia wyjaśnień w sprawie fałszywego podawania kursów walut. Ustalili to dziennikarze RMF FM. Pojawia się kilka hipotez dotyczących przyczyn awarii. W grę wchodzić może atak hakerski, celowa manipulacja, albo działanie sztucznej inteligencji.</p><br clear="all" />

## Ministerstwo Finansów wzywa Google do złożenia wyjaśnień
 - [https://www.rmf24.pl/ekonomia/news-ministerstwo-finansow-wzywa-google-do-zlozenia-wyjasnien,nId,7244571](https://www.rmf24.pl/ekonomia/news-ministerstwo-finansow-wzywa-google-do-zlozenia-wyjasnien,nId,7244571)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T09:50:48+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-ministerstwo-finansow-wzywa-google-do-zlozenia-wyjasnien,nId,7244571"><img align="left" alt="Ministerstwo Finansów wzywa Google do złożenia wyjaśnień" src="https://interia-s.pluscdn.pl/ministerstwo-finansow-wzywa-google-do-zlozenia-wyjasnien/000IBHB2QXJX0851-C307.jpg" /></a>Ministerstwo Finansów wezwało amerykański koncern Google do złożenia wyjaśnień w sprawie fałszywego podawania kursów walut. Ustalili to dziennikarze RMF FM. Pojawia się kilka hipotez dotyczących przyczyn awarii. W grę wchodzić może atak hakerski, celowa manipulacja, albo działanie sztucznej inteligencji.</p><br clear="all" />

## Katastrofa na lotnisku w Tokio. Zderzyły się dwa samoloty [WIDEO]
 - [https://www.rmf24.pl/fakty/swiat/news-katastrofa-na-lotnisku-w-tokio-zderzyly-sie-dwa-samoloty-wid,nId,7244575](https://www.rmf24.pl/fakty/swiat/news-katastrofa-na-lotnisku-w-tokio-zderzyly-sie-dwa-samoloty-wid,nId,7244575)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T09:47:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-katastrofa-na-lotnisku-w-tokio-zderzyly-sie-dwa-samoloty-wid,nId,7244575"><img align="left" alt="Katastrofa na lotnisku w Tokio. Zderzyły się dwa samoloty [WIDEO]" src="https://interia-s.pluscdn.pl/katastrofa-na-lotnisku-w-tokio-zderzyly-sie-dwa-samoloty-wid/000IBHFFL77EFWC0-C307.jpg" /></a>Pięciu członków załogi samolotu należącego do straży przybrzeżnej zginęło w wypadku, do którego doszło na pasie startowym na lotnisku Haneda w Tokio - podają lokalne media. Maszyna zderzyła się z samolotem linii Japan Airlines - z 379 osobami na pokładzie.</p><br clear="all" />

## Samolot stanął w płomieniach. Dramatyczne nagranie z Tokio [WIDEO]
 - [https://www.rmf24.pl/fakty/swiat/news-samolot-stanal-w-plomieniach-dramatyczne-nagranie-z-tokio-wi,nId,7244575](https://www.rmf24.pl/fakty/swiat/news-samolot-stanal-w-plomieniach-dramatyczne-nagranie-z-tokio-wi,nId,7244575)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T09:47:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-samolot-stanal-w-plomieniach-dramatyczne-nagranie-z-tokio-wi,nId,7244575"><img align="left" alt="Samolot stanął w płomieniach. Dramatyczne nagranie z Tokio [WIDEO]" src="https://interia-s.pluscdn.pl/samolot-stanal-w-plomieniach-dramatyczne-nagranie-z-tokio-wi/000IBHAAOACXPPHC-C307.jpg" /></a>Samolot linii Japan Airlines stanął w ogniu na pasie startowym na lotnisku Haneda w Tokio. Na pokładzie było 379 osób. Wszyscy zostali ewakuowani. </p><br clear="all" />

## Gen. Jan Rajchel gościem Rozmowy w południe w RMF FM i Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-gen-jan-rajchel-gosciem-rozmowy-w-poludnie-w-rmf-fm-i-radiu-,nId,7244560](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-gen-jan-rajchel-gosciem-rozmowy-w-poludnie-w-rmf-fm-i-radiu-,nId,7244560)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T09:19:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-gen-jan-rajchel-gosciem-rozmowy-w-poludnie-w-rmf-fm-i-radiu-,nId,7244560"><img align="left" alt="Gen. Jan Rajchel gościem Rozmowy w południe w RMF FM i Radiu RMF24" src="https://interia-s.pluscdn.pl/gen-jan-rajchel-gosciem-rozmowy-w-poludnie-w-rmf-fm-i-radiu/000IBH7AK7C2CLWU-C307.jpg" /></a>Gościem Piotra Salaka w Rozmowie w południe w RMF FM i Radiu RMF24 będzie gen. Jan Rajchel – pilot wojskowy. Porozmawiamy o kolejnym już w ostatnich dniach zmasowanym ataku Rosji na Ukrainę. </p><br clear="all" />

## Odpalili fajerwerki w Dolinie Pięciu Stawów. Wyznaczono nagrodę za wskazanie osób
 - [https://www.rmf24.pl/regiony/zakopane/news-odpalili-fajerwerki-w-dolinie-pieciu-stawow-wyznaczono-nagro,nId,7244550](https://www.rmf24.pl/regiony/zakopane/news-odpalili-fajerwerki-w-dolinie-pieciu-stawow-wyznaczono-nagro,nId,7244550)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T09:10:00+00:00

<p><a href="https://www.rmf24.pl/regiony/zakopane/news-odpalili-fajerwerki-w-dolinie-pieciu-stawow-wyznaczono-nagro,nId,7244550"><img align="left" alt="Odpalili fajerwerki w Dolinie Pięciu Stawów. Wyznaczono nagrodę za wskazanie osób " src="https://interia-s.pluscdn.pl/odpalili-fajerwerki-w-dolinie-pieciu-stawow-wyznaczono-nagro/000IBH6P6QA5W5YF-C307.jpg" /></a>W sylwestrową noc ktoś urządził sobie pokaz sztucznych ogni w Dolinie Pięciu Stawów Polskich. Nagranie szybko trafiło do sieci, a internauci wezwali do wskazania osób odpowiedzialnych za ten incydent. Zaoferowano nawet wysoką nagrodę za podanie nazwisk. </p><br clear="all" />

## Przełom roku na polskich drogach. Policja podała statystyki
 - [https://www.rmf24.pl/fakty/polska/news-przelom-roku-na-polskich-drogach-policja-podala-statystyki,nId,7244545](https://www.rmf24.pl/fakty/polska/news-przelom-roku-na-polskich-drogach-policja-podala-statystyki,nId,7244545)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T09:04:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-przelom-roku-na-polskich-drogach-policja-podala-statystyki,nId,7244545"><img align="left" alt="Przełom roku na polskich drogach. Policja podała statystyki" src="https://interia-s.pluscdn.pl/przelom-roku-na-polskich-drogach-policja-podala-statystyki/000IBH622XJUQ38Y-C307.jpg" /></a>Od 29 grudnia do 1 stycznia na polskich drogach doszło do 160 wypadków. Zginęło 18 osób, a 181 zostało rannych. </p><br clear="all" />

## Polska będzie kupować uzbrojenie od nowych dostawców?
 - [https://www.rmf24.pl/fakty/polska/news-polska-bedzie-kupowac-uzbrojenie-od-nowych-dostawcow,nId,7244552](https://www.rmf24.pl/fakty/polska/news-polska-bedzie-kupowac-uzbrojenie-od-nowych-dostawcow,nId,7244552)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T09:03:33+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-polska-bedzie-kupowac-uzbrojenie-od-nowych-dostawcow,nId,7244552"><img align="left" alt="Polska będzie kupować uzbrojenie od nowych dostawców? " src="https://interia-s.pluscdn.pl/polska-bedzie-kupowac-uzbrojenie-od-nowych-dostawcow/000IBH6LSSLMAMBM-C307.jpg" /></a>Nowy rząd nie wyklucza zakupów uzbrojenia od nowych dostawców. Wiceminister obrony Paweł Zalewski – w Rozmowie o 7:00 w RMF i Radiu RMF24 - zadeklarował, że wstępne umowy z Koreańczykami - chodzi o opiewające na kilka miliardów dolarów dostawy czołgów, armatohaubic czy wyrzutni - pozostają na stole. </p><br clear="all" />

## Lawinowa dwójka w Tatrach. Na Kasprowym prawie 70 cm śniegu
 - [https://www.rmf24.pl/regiony/zakopane/news-lawinowa-dwojka-w-tatrach-na-kasprowym-prawie-70-cm-sniegu,nId,7244534](https://www.rmf24.pl/regiony/zakopane/news-lawinowa-dwojka-w-tatrach-na-kasprowym-prawie-70-cm-sniegu,nId,7244534)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T08:37:00+00:00

<p><a href="https://www.rmf24.pl/regiony/zakopane/news-lawinowa-dwojka-w-tatrach-na-kasprowym-prawie-70-cm-sniegu,nId,7244534"><img align="left" alt="Lawinowa dwójka w Tatrach. Na Kasprowym prawie 70 cm śniegu " src="https://interia-s.pluscdn.pl/lawinowa-dwojka-w-tatrach-na-kasprowym-prawie-70-cm-sniegu/000IBH38QQESTRFS-C307.jpg" /></a>W Tatrach panują trudne warunki do uprawiania turystyki. Szlaki w wielu miejscach są mocno oblodzone i bardzo śliskie – informuje Tatrzański Park Narodowy (TPN). Zagrożenie lawinowe wzrosło do drugiego stopnia.</p><br clear="all" />

## Ogień w mieszkaniu w Ostródzie. Do szpitala zabrano matkę i dwójkę dzieci
 - [https://www.rmf24.pl/regiony/olsztyn/news-ogien-w-mieszkaniu-w-ostrodzie-do-szpitala-zabrano-matke-i-d,nId,7244509](https://www.rmf24.pl/regiony/olsztyn/news-ogien-w-mieszkaniu-w-ostrodzie-do-szpitala-zabrano-matke-i-d,nId,7244509)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T07:57:00+00:00

<p><a href="https://www.rmf24.pl/regiony/olsztyn/news-ogien-w-mieszkaniu-w-ostrodzie-do-szpitala-zabrano-matke-i-d,nId,7244509"><img align="left" alt="Ogień w mieszkaniu w Ostródzie. Do szpitala zabrano matkę i dwójkę dzieci  " src="https://interia-s.pluscdn.pl/ogien-w-mieszkaniu-w-ostrodzie-do-szpitala-zabrano-matke-i-d/000IBH04LBT58PYP-C307.jpg" /></a>Pożar mieszkania w budynku wielorodzinnym w Ostródzie. Do szpitala zabrano kobietę i dwójkę jej dzieci – przekazała straż pożarna.  </p><br clear="all" />

## Matka leżała pijana na trawniku. Obok stał przerażony chłopiec
 - [https://www.rmf24.pl/regiony/slaskie/news-matka-lezala-pijana-na-trawniku-obok-stal-przerazony-chlopie,nId,7244504](https://www.rmf24.pl/regiony/slaskie/news-matka-lezala-pijana-na-trawniku-obok-stal-przerazony-chlopie,nId,7244504)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T07:43:00+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-matka-lezala-pijana-na-trawniku-obok-stal-przerazony-chlopie,nId,7244504"><img align="left" alt="Matka leżała pijana na trawniku. Obok stał przerażony chłopiec " src="https://interia-s.pluscdn.pl/matka-lezala-pijana-na-trawniku-obok-stal-przerazony-chlopie/000IBGYV5FQDN5SL-C307.jpg" /></a>Kompletnie pijana kobieta leżała na trawniku podczas plenerowej imprezy sylwestrowej w Chorzowie. Obok stał zapłakany i zmarznięty 6-letni chłopiec. Dzieckiem zajęli się policjanci. </p><br clear="all" />

## Polska reaguje na rosyjski atak na Kijów. Poderwano F-16
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-polska-reaguje-na-rosyjski-atak-na-kijow-poderwano-f-16,nId,7244494](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-polska-reaguje-na-rosyjski-atak-na-kijow-poderwano-f-16,nId,7244494)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T07:06:37+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-polska-reaguje-na-rosyjski-atak-na-kijow-poderwano-f-16,nId,7244494"><img align="left" alt="Polska reaguje na rosyjski atak na Kijów. Poderwano F-16" src="https://interia-s.pluscdn.pl/polska-reaguje-na-rosyjski-atak-na-kijow-poderwano-f-16/000IBGWXC14H45FP-C307.jpg" /></a>&quot;W celu zapewnienia bezpieczeństwa polskiej przestrzeni powietrznej aktywowano dwie pary myśliwców F-16 oraz sojuszniczy tankowiec powietrzny&quot; - poinformowało na platformie X polskie Dowództwo Operacyjne. Jest to spowodowane porannym rosyjskim atakiem na Ukrainę.</p><br clear="all" />

## Lider południowokoreańskiej opozycji dźgnięty nożem
 - [https://www.rmf24.pl/fakty/swiat/news-lider-poludniowokoreanskiej-opozycji-dzgniety-nozem,nId,7244490](https://www.rmf24.pl/fakty/swiat/news-lider-poludniowokoreanskiej-opozycji-dzgniety-nozem,nId,7244490)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T07:00:01+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-lider-poludniowokoreanskiej-opozycji-dzgniety-nozem,nId,7244490"><img align="left" alt="Lider południowokoreańskiej opozycji dźgnięty nożem" src="https://interia-s.pluscdn.pl/lider-poludniowokoreanskiej-opozycji-dzgniety-nozem/000IBGWKEWGG0NAF-C307.jpg" /></a>Lider opozycyjnej Partii Demokratycznej Korei Południowej Lee Jae-myung został we wtorek dźgnięty nożem w szyję podczas rozmowy z reporterami w południowo-wschodnim mieście portowym Busan. Jak poinformował szpital, jego życiu nie zagraża niebezpieczeństwo. Sprawca został zatrzymany. </p><br clear="all" />

## Pobili przechodnia, bo zwrócił im uwagę. Pięciu mężczyzn z zarzutami
 - [https://www.rmf24.pl/regiony/lublin/news-pobili-przechodnia-bo-zwrocil-im-uwage-pieciu-mezczyzn-z-zar,nId,7244486](https://www.rmf24.pl/regiony/lublin/news-pobili-przechodnia-bo-zwrocil-im-uwage-pieciu-mezczyzn-z-zar,nId,7244486)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T06:54:00+00:00

<p><a href="https://www.rmf24.pl/regiony/lublin/news-pobili-przechodnia-bo-zwrocil-im-uwage-pieciu-mezczyzn-z-zar,nId,7244486"><img align="left" alt="Pobili przechodnia, bo zwrócił im uwagę. Pięciu mężczyzn z zarzutami " src="https://interia-s.pluscdn.pl/pobili-przechodnia-bo-zwrocil-im-uwage-pieciu-mezczyzn-z-zar/000IBGW3WFDLVNM8-C307.jpg" /></a>Pięciu pijanych mężczyzn pobiło we Włodawie przechodnia, kiedy ten zwrócił im uwagę, by nie rzucali petardami. Wszyscy zostali zatrzymani i usłyszeli zarzuty. </p><br clear="all" />

## Rok 2024 na rynku mieszkaniowym. Co może nas czekać?
 - [https://www.rmf24.pl/ekonomia/news-rok-2024-na-rynku-mieszkaniowym-co-moze-nas-czekac,nId,7238482](https://www.rmf24.pl/ekonomia/news-rok-2024-na-rynku-mieszkaniowym-co-moze-nas-czekac,nId,7238482)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T06:00:00+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-rok-2024-na-rynku-mieszkaniowym-co-moze-nas-czekac,nId,7238482"><img align="left" alt="Rok 2024 na rynku mieszkaniowym. Co może nas czekać?" src="https://interia-s.pluscdn.pl/rok-2024-na-rynku-mieszkaniowym-co-moze-nas-czekac/000IB4JU9XXXTB6U-C307.jpg" /></a>Rok 2024 może przynieść na rynku mieszkaniowym uspokojenie i stabilizację, a nawet i delikatną obniżkę cen. Wiele zależy od sytuacji gospodarczej, która wpłynie na rynek kredytowy, ale też od decyzji politycznych, jakie wkrótce zapadną. </p><br clear="all" />

## Zalewski: Mamy pewność, że rosyjska rakieta opuściła terytorium Polski
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-zalewski-mamy-pewnosc-ze-rosyjska-rakieta-opuscila-terytoriu,nId,7243076](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-zalewski-mamy-pewnosc-ze-rosyjska-rakieta-opuscila-terytoriu,nId,7243076)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T06:00:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-zalewski-mamy-pewnosc-ze-rosyjska-rakieta-opuscila-terytoriu,nId,7243076"><img align="left" alt="Zalewski: Mamy pewność, że rosyjska rakieta opuściła terytorium Polski" src="https://interia-s.pluscdn.pl/zalewski-mamy-pewnosc-ze-rosyjska-rakieta-opuscila-terytoriu/000IBEYU9D5JC4JD-C307.jpg" /></a>&quot;Mamy pewność, że rosyjska rakieta, która w piątek naruszyła polską przestrzeń powietrzną, opuściła terytorium naszego kraju. Po pierwsze – mamy potwierdzenie z radarów polskich i sojuszniczych, ale ponieważ czasami technika jest zawodna, żeby mieć 100-procentową pewność, skierowaliśmy około 500 żołnierzy WOT, którzy przeczesywali tamte tereny i nie znaleźli żadnych szczątków&quot; – mówił w Rozmowie o 7:00 w RMF FM i internetowym Radiu RMF24 wiceminister obrony Paweł Zalewski. </p><br clear="all" />

## Nie załatwicie dzisiaj ważnych spraw w urzędach
 - [https://www.rmf24.pl/fakty/polska/news-nie-zalatwicie-dzisiaj-waznych-spraw-w-urzedach,nId,7244476](https://www.rmf24.pl/fakty/polska/news-nie-zalatwicie-dzisiaj-waznych-spraw-w-urzedach,nId,7244476)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T05:49:43+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-nie-zalatwicie-dzisiaj-waznych-spraw-w-urzedach,nId,7244476"><img align="left" alt="Nie załatwicie dzisiaj ważnych spraw w urzędach" src="https://interia-s.pluscdn.pl/nie-zalatwicie-dzisiaj-waznych-spraw-w-urzedach/000IBGTJK4XD27UN-C307.jpg" /></a>W pierwszy wtorek nowego roku nie załatwicie ważnych spraw w wielu urzędach. Pracownicy, a wśród nich przede wszystkim członkowie korpusu służby cywilnej, odbierają dzień wolny za Święto Trzech Króli.</p><br clear="all" />

## Potężne trzęsienie ziemi w Japonii. Zginęło co najmniej 30 osób
 - [https://www.rmf24.pl/fakty/swiat/news-potezne-trzesienie-ziemi-w-japonii-zginelo-co-najmniej-30-os,nId,7244474](https://www.rmf24.pl/fakty/swiat/news-potezne-trzesienie-ziemi-w-japonii-zginelo-co-najmniej-30-os,nId,7244474)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T05:41:27+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-potezne-trzesienie-ziemi-w-japonii-zginelo-co-najmniej-30-os,nId,7244474"><img align="left" alt="Potężne trzęsienie ziemi w Japonii. Zginęło co najmniej 30 osób" src="https://interia-s.pluscdn.pl/potezne-trzesienie-ziemi-w-japonii-zginelo-co-najmniej-30-os/000IBGT79AOM1BHI-C307.jpg" /></a>Liczba ofiar śmiertelnych potężnego trzęsienia ziemi, które miało miejsce w poniedziałek w środkowej Japonii, wzrosła do co namniej 30 osób. Ogłosiły to władze departamentu Ishikawa, będącego epicentrum trzęsienia ziemi. W kraju odwołano już zagrożenie tsunami na całym zachodnim wybrzeżu.</p><br clear="all" />

## Potężne trzęsienie ziemi w Japonii. Zginęło co najmniej 48 osób
 - [https://www.rmf24.pl/fakty/swiat/news-potezne-trzesienie-ziemi-w-japonii-zginelo-co-najmniej-48-os,nId,7244474](https://www.rmf24.pl/fakty/swiat/news-potezne-trzesienie-ziemi-w-japonii-zginelo-co-najmniej-48-os,nId,7244474)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T05:41:27+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-potezne-trzesienie-ziemi-w-japonii-zginelo-co-najmniej-48-os,nId,7244474"><img align="left" alt="Potężne trzęsienie ziemi w Japonii. Zginęło co najmniej 48 osób" src="https://interia-s.pluscdn.pl/potezne-trzesienie-ziemi-w-japonii-zginelo-co-najmniej-48-os/000IBGT79AOM1BHI-C307.jpg" /></a>Do 48 osób wzrósł bilans potwierdzonych ofiar śmiertelnych silnego trzęsienia ziemi, które nawiedziło w Nowy Rok półwysep Noto w japońskiej prefekturze Ishikawa. W wyniku kataklizmu waliły się budynki, a tysiące domów zostały bez prądu. Poprzednio informowano o 30 ofiarach śmiertelnych.</p><br clear="all" />

## Zamieszanie z kursem złotego. Jest reakcja ministra finansów
 - [https://www.rmf24.pl/ekonomia/news-zamieszanie-z-kursem-zlotego-jest-reakcja-ministra-finansow,nId,7244472](https://www.rmf24.pl/ekonomia/news-zamieszanie-z-kursem-zlotego-jest-reakcja-ministra-finansow,nId,7244472)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T05:22:24+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-zamieszanie-z-kursem-zlotego-jest-reakcja-ministra-finansow,nId,7244472"><img align="left" alt="Zamieszanie z kursem złotego. Jest reakcja ministra finansów" src="https://interia-s.pluscdn.pl/zamieszanie-z-kursem-zlotego-jest-reakcja-ministra-finansow/000IBGSJISH1QN18-C307.jpg" /></a>Ten kurs złotego, który sieje panikę to „fejk” (błąd źródła danych). Za chwilę otworzą się rynki w Azji i sytuacja wróci do normy - tak minister finansów Andrzej Domański skomentował na platformie X zmianę kursu złotego do euro i dolara. Dane Google mówiły o wzroście notowań dolara i euro wobec złotego w granicach 23 proc. Teraz wszystko wróciło już do normy.</p><br clear="all" />

## Kot o spotkaniu z Fronczewskim: Zaszczyt i stres
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-kot-o-spotkaniu-z-fronczewskim-zaszczyt-i-stres,nId,7243047](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-kot-o-spotkaniu-z-fronczewskim-zaszczyt-i-stres,nId,7243047)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T05:15:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-kot-o-spotkaniu-z-fronczewskim-zaszczyt-i-stres,nId,7243047"><img align="left" alt="Kot o spotkaniu z Fronczewskim: Zaszczyt i stres" src="https://interia-s.pluscdn.pl/kot-o-spotkaniu-z-fronczewskim-zaszczyt-i-stres/000IBDU66VUPWJX2-C307.jpg" /></a>&quot;Kiedy na samym początku tam dołączyłem, pojawił się Piotr Fronczewski, uścisnął mi dłoń powiedział ‘cześć’, tym swoim przepięknym aksamitem, to było dla mnie bardzo zaszczytne, bardzo podniosłe i bardzo się zestresowałem, ale to jest potrzebny stres w tej robocie – bo mamy do czynienia z wyzwaniem&quot; - tak Tomasz Kot wspominał w Porannej rozmowie w RMF FM pierwsze próby na planie &quot;Akademii Pana Kleksa&quot;.</p><br clear="all" />

## Tomasz Kot gościem Porannej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-tomasz-kot-gosciem-porannej-rozmowy-w-rmf-fm,nId,7243047](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-tomasz-kot-gosciem-porannej-rozmowy-w-rmf-fm,nId,7243047)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T05:15:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-tomasz-kot-gosciem-porannej-rozmowy-w-rmf-fm,nId,7243047"><img align="left" alt="Tomasz Kot gościem Porannej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/tomasz-kot-gosciem-porannej-rozmowy-w-rmf-fm/000IBDU66VUPWJX2-C307.jpg" /></a>Gościem Porannej rozmowy w RMF FM będzie aktor Tomasz Kot. W piątek do kin wchodzi ekranizacja powieści Jana Brzechwy &quot;Akademia pana Kleksa&quot;, w której Tomasz Kot zagra właśnie rolę Ambrożego Kleksa. Aktor miał 6 lat, gdy popularny film dla dzieci miał swoją premierę. Zapytamy go o wspomnienia, wrażenia i poprosimy o porównanie tych dwóch filmów.</p><br clear="all" />

## 16 rosyjskich Tu-95 wystrzeliło pociski. Alarm w całej Ukrainie [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-16-rosyjskich-tu-95-wystrzelilo-pociski-alarm-w-calej-ukrain,nId,7244470](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-16-rosyjskich-tu-95-wystrzelilo-pociski-alarm-w-calej-ukrain,nId,7244470)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T04:53:10+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-16-rosyjskich-tu-95-wystrzelilo-pociski-alarm-w-calej-ukrain,nId,7244470"><img align="left" alt="16 rosyjskich Tu-95 wystrzeliło pociski. Alarm w całej Ukrainie [RELACJA]" src="https://interia-s.pluscdn.pl/16-rosyjskich-tu-95-wystrzelilo-pociski-alarm-w-calej-ukrain/000IBGSBN6VX084U-C307.jpg" /></a>Poranny atak lotniczy w Ukrainie. Rosyjskie bombowce Tu-95MS wystartowały i wystrzeliły już pierwsze pociski manewrujące. Najważniejsze informacje związane z sytuacją za naszą wschodnią granicą zbieramy w naszej relacji z 2 stycznia 2024 roku.</p><br clear="all" />

## 21 rosyjskich bombowców strategicznych w powietrzu. Alarm w całej Ukrainie
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-21-rosyjskich-bombowcow-strategicznych-w-powietrzu-alarm-w-c,nId,7244470](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-21-rosyjskich-bombowcow-strategicznych-w-powietrzu-alarm-w-c,nId,7244470)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T04:53:10+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-21-rosyjskich-bombowcow-strategicznych-w-powietrzu-alarm-w-c,nId,7244470"><img align="left" alt="21 rosyjskich bombowców strategicznych w powietrzu. Alarm w całej Ukrainie" src="https://interia-s.pluscdn.pl/21-rosyjskich-bombowcow-strategicznych-w-powietrzu-alarm-w-c/000IBGSBN6VX084U-C307.jpg" /></a>Poranny atak lotniczy w Ukrainie. Rosyjskie bombowce Tu-95MS wystartowały i wystrzeliły już pierwsze pociski manewrujące. Najważniejsze informacje związane z sytuacją za naszą wschodnią granicą zbieramy w naszej relacji z 2 stycznia 2024 roku.</p><br clear="all" />

## Alarm w całej Ukrainie. 10 rannych w ostrzale bloku w Kijowie [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarm-w-calej-ukrainie-10-rannych-w-ostrzale-bloku-w-kijowie,nId,7244470](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarm-w-calej-ukrainie-10-rannych-w-ostrzale-bloku-w-kijowie,nId,7244470)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T04:53:10+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarm-w-calej-ukrainie-10-rannych-w-ostrzale-bloku-w-kijowie,nId,7244470"><img align="left" alt="Alarm w całej Ukrainie. 10 rannych w ostrzale bloku w Kijowie [RELACJA]" src="https://interia-s.pluscdn.pl/alarm-w-calej-ukrainie-10-rannych-w-ostrzale-bloku-w-kijowie/000IBGSBN6VX084U-C307.jpg" /></a>Na całej Ukrainie trwa alarm przeciwlotniczy. 10 osób zostało rannych w rosyjskim ataku rakietowym na budynek mieszkalny w Kijowie. &quot;W celu zapewnienia bezpieczeństwa polskiej przestrzeni powietrznej aktywowano dwie pary myśliwców F-16 oraz sojuszniczy tankowiec powietrzny&quot; - poinformowało polskie Dowództwo Operacyjne. Najważniejsze informacje związane z sytuacją za naszą wschodnią granicą zbieramy w naszej relacji z 2 stycznia 2024 roku.</p><br clear="all" />

## Alarm w całej Ukrainie. 20 rannych w ostrzale bloku w Kijowie [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarm-w-calej-ukrainie-20-rannych-w-ostrzale-bloku-w-kijowie,nId,7244470](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarm-w-calej-ukrainie-20-rannych-w-ostrzale-bloku-w-kijowie,nId,7244470)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T04:53:10+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarm-w-calej-ukrainie-20-rannych-w-ostrzale-bloku-w-kijowie,nId,7244470"><img align="left" alt="Alarm w całej Ukrainie. 20 rannych w ostrzale bloku w Kijowie [RELACJA]" src="https://interia-s.pluscdn.pl/alarm-w-calej-ukrainie-20-rannych-w-ostrzale-bloku-w-kijowie/000IBH1W5C98D80E-C307.jpg" /></a>Jedna osoba nie żyje, a kilkadziesiąt jest rannych - to wstępny bilans rosyjskiego, zmasowanego ataku rakietowego na Ukrainę. Alarm powietrzny trwa w całym kraju. &quot;W celu zapewnienia bezpieczeństwa polskiej przestrzeni powietrznej aktywowano dwie pary myśliwców F-16 oraz sojuszniczy tankowiec powietrzny&quot; - poinformowało polskie Dowództwo Operacyjne. Najważniejsze informacje związane z sytuacją za naszą wschodnią granicą zbieramy w naszej relacji z 2 stycznia 2024 roku.</p><br clear="all" />

## Alarm w całej Ukrainie. Zmasowany ostrzał, ofiary w Kijowie i dziesiątki rannych [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarm-w-calej-ukrainie-zmasowany-ostrzal-ofiary-w-kijowie-i-,nId,7244470](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarm-w-calej-ukrainie-zmasowany-ostrzal-ofiary-w-kijowie-i-,nId,7244470)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T04:53:10+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-alarm-w-calej-ukrainie-zmasowany-ostrzal-ofiary-w-kijowie-i-,nId,7244470"><img align="left" alt="Alarm w całej Ukrainie. Zmasowany ostrzał, ofiary w Kijowie i dziesiątki rannych [RELACJA]" src="https://interia-s.pluscdn.pl/alarm-w-calej-ukrainie-zmasowany-ostrzal-ofiary-w-kijowie-i/000IBH1W5C98D80E-C307.jpg" /></a>Trzy osoby zginęły w obwodzie kijowskim, a kilkadziesiąt jest rannych - to wstępny bilans rosyjskiego, zmasowanego ataku rakietowego na Ukrainę. Alarm powietrzny trwa w całym kraju. &quot;W celu zapewnienia bezpieczeństwa polskiej przestrzeni powietrznej aktywowano dwie pary myśliwców F-16 oraz sojuszniczy tankowiec powietrzny&quot; - poinformowało polskie Dowództwo Operacyjne. Najważniejsze informacje związane z sytuacją za naszą wschodnią granicą zbieramy w naszej relacji z 2 stycznia 2024 roku.</p><br clear="all" />

## Zmasowany ostrzał, ofiary w Kijowie i Charkowie [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zmasowany-ostrzal-ofiary-w-kijowie-i-charkowie-relacja,nId,7244470](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zmasowany-ostrzal-ofiary-w-kijowie-i-charkowie-relacja,nId,7244470)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-01-02T04:53:10+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-zmasowany-ostrzal-ofiary-w-kijowie-i-charkowie-relacja,nId,7244470"><img align="left" alt="Zmasowany ostrzał, ofiary w Kijowie i Charkowie [RELACJA]" src="https://interia-s.pluscdn.pl/zmasowany-ostrzal-ofiary-w-kijowie-i-charkowie-relacja/000IBHK7YJTI68OP-C307.jpg" /></a>Pięć osób zginęło, a dziesiątki zostały ranne po dzisiejszych rosyjskich atakach na Ukrainę. Rakiety spadły na Kijów i Charków. W związku z ostrzałem &quot;w celu zapewnienia bezpieczeństwa polskiej przestrzeni powietrznej aktywowano dwie pary myśliwców F-16 oraz sojuszniczy tankowiec powietrzny&quot; - poinformowało polskie Dowództwo Operacyjne. Najważniejsze informacje związane z sytuacją za naszą wschodnią granicą zbieramy w naszej relacji z 2 stycznia 2024 roku.</p><br clear="all" />

