# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Krosno: pijany 25-latek wjechał autem w dom. WiĂłzł 17-latkę. Też pijaną
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556988,krosno-pijany-25-latek-wjechal-autem-w-dom-wiozl-17-latke.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556988,krosno-pijany-25-latek-wjechal-autem-w-dom-wiozl-17-latke.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T21:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/24/1d/z30556995M,Kierowca-auta-wjechal-w-dom.jpg" vspace="2" />Trwa wyjaśnianie okoliczności incydentu, do ktĂłrego doszło w nocy z 31 grudnia na 1 stycznia w Krośnie. Kierowca rozpędzonego auta uderzył w dom. ZarĂłwno 25-latek, jak i jego 17-letnia pasażerka byli pijani.

## Bartoszewski o kulisach spotkania z rosyjskim dyplomatą. "Ze zbrodniarzami się nie witam"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556943,bartoszewski-o-kulisach-spotkania-z-rosyjskim-dyplomata-ze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556943,bartoszewski-o-kulisach-spotkania-z-rosyjskim-dyplomata-ze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T20:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1e/24/1d/z30556958M,Wladyslaw-Teofil-Bartoszewski.jpg" vspace="2" />- Nie jest w naszym interesie, żeby przymilać się do zbrodniarzy - stwierdził w Polsat News wiceszef MSZ Władysław Teofil Bartoszewski (PSL), mĂłwiąc o rozmowie z chargĂŠ d'affaires Federacji Rosyjskiej. Polityk podkreślił, że nie podał ręki dyplomacie. Spotkanie dotyczyło rakiety, ktĂłra w piątek nad ranem naruszyła polską przestrzeń powietrzną.

## Zasnął za kierownicą w pobliżu Zimnej WĂłdki. Policja: "Na alkomacie zabrakło skali"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556882,zasnal-za-kierownica-w-poblizu-zimnej-wodki-policja-na-alkomacie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556882,zasnal-za-kierownica-w-poblizu-zimnej-wodki-policja-na-alkomacie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T20:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/02/24/1d/z30556930M,Alkomat---zdj--ilustr-.jpg" vspace="2" />W okolicach Zimnej WĂłdki (woj. opolskie) policjanci zatrzymali mężczyznę, ktĂłry zasnął za kierownicą. Podczas badania alkomatem dla 23-latka "zabrakło skali". Funkcjonariusze podejrzewają, że był on także pod wpływem substancji odurzających.

## 23-latek trafił na komendę, zmarł kilkadziesiąt godzin pĂłźniej. "Był strasznie pobity na twarzy i głowie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556910,23-latek-trafil-na-komende-zmarl-kilkadziesiat-godzin-pozniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556910,23-latek-trafil-na-komende-zmarl-kilkadziesiat-godzin-pozniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T20:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/07/24/1d/z30556935M,Zdjecie-ilustracyjne.jpg" vspace="2" />Prokuratura wyjaśnia okoliczności śmierci 23-latka z Marek. Mężczyzna 22 grudnia trafił na komendę w Wołominie. Po wyjściu miał powiedzieć bliskim, że był bity i przypalany papierosami przez funkcjonariuszy. "Komendant Powiatowy Policji w Wołominie niezwłocznie zlecił czynności kontrolne" - przekazała rzeczniczka tamtejszej komendy. Sekcja zwłok nie wykazała urazĂłw, ktĂłre mogłyby mieć wpływ na śmierć 23-latka.

## "To dlatego prezes jest w takim dobrym nastroju". Nieoczekiwane skutki walki o TVP
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556841,to-dlatego-prezes-jest-w-takim-dobrym-nastroju-nieoczekiwane.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556841,to-dlatego-prezes-jest-w-takim-dobrym-nastroju-nieoczekiwane.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T20:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/de/24/1d/z30556894M,Jaroslaw-Kaczynski--prezes-Prawa-i-Sprawiedliwosci.jpg" vspace="2" />Protesty przeciwko zmianom w mediach publicznych pomogły zmobilizować politykĂłw w szeregach Zjednoczonej Prawicy, oceniają związani z partią rozmĂłwcy portalu Interia. - To dlatego prezes jest w takim dobrym nastroju ostatnio, bo wie, że ma zwarty i zdeterminowany klub z posłami, ktĂłrym zaczęło się chcieć - stwierdził jeden z politykĂłw PiS. - Tusk dokonał cudu - dodał kolejny.

## Skandal w partii Giorgii Meloni. Polityk na imprezę przyniĂłsł broń. Padł strzał
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30556732,skandal-w-partii-giorgii-meloni-wloscy-politycy-przekazywali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30556732,skandal-w-partii-giorgii-meloni-wloscy-politycy-przekazywali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T20:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f0/24/1d/z30556912M,Giorgia-Meloni.jpg" vspace="2" />Od początku roku włoskie media żyją sprawą niebezpiecznego incydentu z udziałem politykĂłw. Podczas imprezy sylwestrowej przedstawicieli partii rządzącej wystrzeliła broń. "Ci niekompetentni ludzie stanowią zagrożenie dla bezpieczeństwa" - komentuje opozycja.

## Ukraina. Tragiczny bilans po ataku Rosjan. 130 rannych i 5 zabitych cywilĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30556896,ukraina-tragiczny-bilans-po-ataku-rosjan-130-rannych-i-5-zabitych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30556896,ukraina-tragiczny-bilans-po-ataku-rosjan-130-rannych-i-5-zabitych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T19:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e6/24/1d/z30556902M,UKRAINE-CRISIS-ATTACK-KYIV.jpg" vspace="2" />5 zabitych cywilĂłw i ponad 130 rannych - to bilans dzisiejszego ataku rakietowego Rosjan na Ukrainę. Najbardziej ucierpiały KijĂłw oraz CharkĂłw. Agresor użył niemal stu rakiet, w tym pociskĂłw hipersonicznych, ale też kilkudziesięciu dronĂłw Shahed.

## Wypadek przy moście w Krakowie. Wciąż brak zeznań kluczowego świadka. Brytyjczycy milczą
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556844,wypadek-przy-moscie-w-krakowie-wciaz-brak-zeznan-kluczowego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556844,wypadek-przy-moscie-w-krakowie-wciaz-brak-zeznan-kluczowego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T19:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/be/24/1d/z30556862M,Moment-przed-wypadkiem-przy-moscie-Debnickim.jpg" vspace="2" />Trwa wyjaśnianie okoliczności wypadku, do ktĂłrego doszło w lipcu przy moście Dębnicim w Krakowie. Zginęło czterech mężczyzn, jadących rozpędzonym Renault Megane. Jak podaje tvn24.pl, do tej pory nie został przesłuchany jeden z kluczowych świadkĂłw. To brytyjski turysta, ktĂłry był bliski potrącenia przez kierowcę auta.

## Horoskop tygodniowy 3-10 stycznia 2024 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30555942,horoskop-tygodniowy-3-10-stycznia-2024-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30555942,horoskop-tygodniowy-3-10-stycznia-2024-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T19:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/45/1f/1d/z30538053M,Horoskop--zdjecie-ilustracyjne-.jpg" vspace="2" />Horoskop tygodniowy od 3 do 10 stycznia. Czego mogą spodziewać się osoby urodzone pod znakiem Strzelca, Panny czy Koziorożca? Nie czekaj, znajdź swĂłj znak zodiaku i sprawdź, co cię czeka.

## TVP Olsztyn ma nowego dyrektora. Poprzedni nazwał Tuska "zwyrodnialcem", a Sienkiewicza "rympałem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556676,tvp-olsztyn-ma-nowego-dyrektora-poprzedni-nazwal-tuska-zwyrodnialcem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556676,tvp-olsztyn-ma-nowego-dyrektora-poprzedni-nazwal-tuska-zwyrodnialcem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T18:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/81/24/1d/z30556801M,Pawel-Warot--byly-dyrektor-TVP-Olsztyn.jpg" vspace="2" />Paweł Warot, pełniący obowiązki dyrektora TVP Olsztyn, w ostatnim czasie otwarcie angażował się w protesty przeciwko zmianom w mediach publicznych. "Tusk likwiduje Polskę. Pułkownik Rympał Sienkiewicz bezprawnie podjął decyzję o likwidacji polskich mediĂłw narodowych" - pisał na Facebooku. Jak poinformowała "Gazeta Wyborcza", pod koniec ubiegłego roku Warot został odwołany ze stanowiska.

## Przydacz o relacjach Dudy z Tuskiem. "Pamięta, jak to było za czasĂłw Lecha Kaczyńskiego"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556782,przydacz-o-relacjach-dudy-z-tuskiem-pamieta-jak-to-bylo-za.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556782,przydacz-o-relacjach-dudy-z-tuskiem-pamieta-jak-to-bylo-za.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T18:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/24/1d/z30556821M,Marcin-Przydacz.jpg" vspace="2" />- Widzimy gotowość prezydenta do wspĂłłpracy, nie wiem, czy widzimy gotowość strony rządowej - stwierdził w RMF FM poseł PiS Marcin Przydacz, były bliski wspĂłłpracownik Andrzeja Dudy. Według Przydacza "sytuacja w mediach publicznych pokazuje, że rząd raczej działa poprzez siłowe rozwiązania niż formułę dialogu".

## Orędzie Andrzeja Dudy to "sylwester marzeń". Były promotor prezydenta: Hipokryzja i nieporozumienie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556651,oredzie-andrzeja-dudy-to-sylwester-marzen-byly-promotor-prezydenta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556651,oredzie-andrzeja-dudy-to-sylwester-marzen-byly-promotor-prezydenta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T18:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5a/22/1d/z30548314M,Andrzej-Duda.jpg" vspace="2" />Profesor Jan Zimmermann, promotor pracy doktorskiej Andrzeja Dudy, skomentował jego noworoczne orędzie do narodu. Nazwał je "nieporozumieniem". Politycy z kolei ocenili, czy istnieją szanse na ich wspĂłłpracę z prezydentem. - Mimo deklaracji staje w roli działacza partyjnego swojej macierzystej partii - stwierdził poseł PSL Krzysztof Paszyk.

## Zarezerwowali nocleg w Zakopanem, okazało się, że obiekt nie istnieje. Policja o pladze oszustw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556749,zarezerwowali-nocleg-w-zakopanem-okazalo-sie-ze-obiekt-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556749,zarezerwowali-nocleg-w-zakopanem-okazalo-sie-ze-obiekt-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T17:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/63/24/1d/z30556771M,Policja-w-Zakopanem--Zdjecie-ilustracyjne.jpg" vspace="2" />Conajmniej kilkadziesiąt osĂłb zostało oszukanych w ostatnich dniach ubiegłego roku na tzw. wirtualne kwatery w Zakopanem. Ofiary tego przestępstwa zapłaciły za rezerwację pokojĂłw, po czym na miejscu okazywało się, że miejsca noclegowe nie istnieją.

## "60 proc. społeczeństwa chciałoby przywrĂłcenia kary śmierci". Ekspert komentuje wyniki badań
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556675,60-proc-spoleczenstwa-chcialoby-przywrocenia-kary-smierci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556675,60-proc-spoleczenstwa-chcialoby-przywrocenia-kary-smierci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T17:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/24/1d/z30556690M,Zbigniew-Nowak.jpg" vspace="2" />- Uważamy się za społeczeństwo rozwinięte i cywilizowane. Ale z badań wynika, że ponad połowa młodych ludzi chciałaby powrotu kary śmierci dla sprawcĂłw najokrutniejszych zbrodni. Są też tacy, ktĂłrym nie przeszkadzałoby, żeby wrĂłciła inspirowana średniowieczem kara publicznej chłosty - mĂłwi w rozmowie z Gazeta.pl dr nauk prawnych Zbigniew Nowak.

## "Gdybym miał dzień na wolności, wykąpałbym się w wannie i nażarł kurczaka"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556713,gdybym-mial-dzien-na-wolnosci-wykapalbym-sie-w-wannie-i-nazarl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556713,gdybym-mial-dzien-na-wolnosci-wykapalbym-sie-w-wannie-i-nazarl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T17:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/38/24/1d/z30556728M,Krzysztof-Pankow-w-rejestrze.jpg" vspace="2" />Zbigniew Brzoskowski miał zostać powieszony za brutalną zbrodnię popełnioną w 1993 roku w Elblągu. Jednak dzięki złagodzeniu prawa karnego stryczek zamieniono na dożywocie. Brzoskowski - ostatni Polak skazany na karę śmierci - ma nadzieję na wolność, chce wyjść i założyć rodzinę. Tylko nikt na razie nie planuje go wypuścić.

## Zapijali ich na śmierć i przejmowali mieszkania. Na ławie oskarżonych gang naganiaczy i notariuszka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555669,zapijali-ich-na-smierc-i-przejmowali-mieszkania-na-lawie-oskarzonych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555669,zapijali-ich-na-smierc-i-przejmowali-mieszkania-na-lawie-oskarzonych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T17:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/5f/1c/z29751304M,Jeden-z-czlonkow--gangu-Trucicieli.jpg" vspace="2" />Polowali na zadłużonych, niezaradnych właścicieli mieszkań, chcąc notarialnie przejąć ich majątek. Aby przyspieszyć zgon oszukanych, truli ich izopropanolem.

## Liban: Izrael uderzył w siedzibę Hamasu. Są ofiary śmiertelne
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30556707,liban-izrael-uderzyl-w-siedzibe-hamasu-sa-ofiary-smiertelne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30556707,liban-izrael-uderzyl-w-siedzibe-hamasu-sa-ofiary-smiertelne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T17:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2c/24/1d/z30556716M,Miejsce--w-ktorym-doszlo-do-ataku.jpg" vspace="2" />Izraelski dron zaatakował jedną z siedzib Hamasu na przedmieściach stolicy Libanu, Bejrutu - podają tamtejsze media. W ataku miał zginąć wiceszef biura politycznego organizacji, Saleh Al-Arouri, oraz trzy inne osoby.

## Ewakuacja pasażerĂłw pociągu i interwencja straży pożarnej. W wagonie pojawił się dym
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556520,ewakuacja-pasazerow-pociagu-i-interwencja-strazy-pozarnej-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556520,ewakuacja-pasazerow-pociagu-i-interwencja-strazy-pozarnej-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T16:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2a/24/1d/z30556714M,Pruszcz-Gdanski--Awaria-pociagu-Polregio.jpg" vspace="2" />Około 80 osĂłb ewakuowało się z pociągu na stacji Pruszcz Gdański (woj. pomorskie). Przyczyną była awaria szafy wysokiego napięcia, ktĂłra doprowadziła do zadymienia jednego z wagonĂłw. Na miejscu interweniowały trzy zastępy straży pożarnej.

## Adamczyk, Pereira i Tulicki z kolejnym listem. ws. TVP. "Plac zostanie wygaszony i sprzedany"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556387,adamczyk-pereira-i-tulicki-z-kolejnym-listem-dochodza-do.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556387,adamczyk-pereira-i-tulicki-z-kolejnym-listem-dochodza-do.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T16:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/33/24/1d/z30556467M,Marcin-Tulicki--Samuel-Pereira--Michal-Adamczyk.jpg" vspace="2" />Byli pracownicy TVP - Michał Adamczyk, Samuel Pereira i Marcin Tulicki - w kolejnym piśmie do "koleżanek i kolegĂłw" z Telewizji Polskiej ostrzegają przed planami "nielegalnych likwidatorĂłw". Według autorĂłw listu siedziba TVP na placu PowstańcĂłw ma zostać sprzedana, a część wspĂłłpracownikĂłw może mieć problemy z otrzymaniem wynagrodzenia za ubiegły miesiąc.

## Turystka na skuterze śnieżnym uderzyła w drzewo. Ratownicy ruszyli na pomoc
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556645,turystka-na-skuterze-snieznym-uderzyla-w-drzewo-ratownicy-ruszyli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556645,turystka-na-skuterze-snieznym-uderzyla-w-drzewo-ratownicy-ruszyli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T16:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f6/24/1d/z30556662M,Zdjecie-ilustracyjne.jpg" vspace="2" />Trwa wyjaśnianie okoliczności wypadku, do ktĂłrego doszło we wtorek w rejonie Bachledzkiego Wierchu. Kobieta jadąca na skuterze śnieżnym uderzyła w drzewo. Straciła przytomność.

## Zmiany w mediach publicznych. Co Polacy sądzą na temat działań Sienkiewicza? Jest sondaż
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556511,zmiany-w-mediach-publicznych-co-polacy-sadza-na-temat-dzialan.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30556511,zmiany-w-mediach-publicznych-co-polacy-sadza-na-temat-dzialan.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T16:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/24/1d/z30556565M,TVP.jpg" vspace="2" />Blisko 53 proc. badanych popiera sposĂłb, w jaki nowe władze dokonały w ostatnich tygodniach zmian w mediach publicznych - wynika z badania UCE Research dla Onet.pl. Najmniej krytyczni są w tej kwestii wyborcy Koalicji Obywatelskiej, najbardziej - Prawa i Sprawiedliwości.

## Batalia o media publiczne. Streszczenie drugiego sezonu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555253,batalia-o-media-publiczne-streszczenie-drugiego-sezonu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555253,batalia-o-media-publiczne-streszczenie-drugiego-sezonu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T16:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4a/24/1d/z30556490M,Donald-Tusk.jpg" vspace="2" />Trzęsienie ziemi w mediach publicznych - tak najdelikatniej można określić, co się dzieje w ostatnich dniach w TVP, Polskim Radiu i PAP. Dla tych, ktĂłrzy woleli żegnać stary rok i witać nowy, zamiast śledzić kolejne przepychanki o media publiczne, przygotowaliśmy wygodne podsumowanie kolejnego sezonu tego serialu.

## Eksperci o rokowaniach wojny w Ukrainie. Wskazują trzy najważniejsze czynniki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30556322,eksperci-o-rokowaniach-wojny-w-ukrainie-wskazuja-trzy-najwazniejsze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30556322,eksperci-o-rokowaniach-wojny-w-ukrainie-wskazuja-trzy-najwazniejsze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T15:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/53/24/1d/z30556499M,Ostrzal-Ukrainy.jpg" vspace="2" />Niedawne nasilenie atakĂłw Rosji na Ukrainę wzbudziło wiele pytań o przyszłość trwającej od niemal dwĂłch lat wojny. Eksperci w rozmowie z Onetem jako najistotniejsze czynniki mające wpływ na dalszy rozwĂłj konfliktu wskazują polityczną sytuację Rosji, decyzję Zachodu o dalszym wsparciu broniącej się Ukrainy oraz wolę walki samych UkraińcĂłw.

## Rodzice bili i podduszali 2-miesięczne niemowlę, bo płakało. W więzieniu mogą spędzić nawet 20 lat
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556365,rodzice-bili-i-podduszali-2-miesieczne-niemowle-bo-plakalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556365,rodzice-bili-i-podduszali-2-miesieczne-niemowle-bo-plakalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T15:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2f/24/1d/z30556463M,Dziecko---zdj--ilustr-.jpg" vspace="2" />Rodzice z Kępna (woj. wielkopolskie), ktĂłrzy znęcali się nad dwumiesięcznym niemowlęciem, usłyszeli już zarzuty. Swoje zachowanie para usprawiedliwiała płaczem dziecka. Za popełnione przestępstwa grozi im nawet do 20 lat więzienia.

## Posłanka KO o słowach Pietrzaka. "Złom moralny". Inne zdanie ma polityk Suwerennej Polski
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556096,poslanka-ko-o-slowach-pietrzaka-zlom-moralny-inne-zdanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556096,poslanka-ko-o-slowach-pietrzaka-zlom-moralny-inne-zdanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T15:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c2/23/1d/z30554306M,Jan-Pietrzak-z-prezydentem.jpg" vspace="2" />Na antenie Polsat News doszło do starcia między politykami. Poszło o wypowiedź Jana Pietrzaka o "barakach w Auschwitz dla imigrantĂłw". - To jest złom moralny. Mam nadzieję, że tą sprawą zajmie się prokuratura - skomentowała posłanka KO Katarzyna Maria Piekarska. - Czyli czego oczekujemy, że pĂłjdzie do więzienia za te słowa? - wtrącił Jacek Ozdoba z Suwerennej Polski i podkreślił, że Pietrzak ma "gigantyczny dorobek historyczny".

## Rosyjski ostrzał trwa. Ukraińska polityczka opublikowała zdjęcia swego zniszczonego domu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555944,rosyjski-ostrzal-trwa-ukrainska-polityczka-opublikowala-zdjecia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555944,rosyjski-ostrzal-trwa-ukrainska-polityczka-opublikowala-zdjecia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T14:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/71/24/1d/z30556273M,Rosyjski-ostrzal-Ukrainy--2-stycznia-2024-r-.jpg" vspace="2" />Rosja kontynuuje zmasowany ostrzał ukraińskich miast. We wtorek rakiety spadły na KijĂłw i CharkĂłw. Zniszczone zostały zabudowania cywilne, a śmierć poniosło co najmniej pięć osĂłb. Sieć obiegają nagrania i zdjęcia przedstawiające zdemolowane budynki mieszkalne oraz pożary wywołane przez eksplozje. Zdjęcie swojego zniszczonego domu opublikowała rĂłwnież ukraińska parlamentarzystka.

## Wypowiedź Jana Pietrzaka o imigrantach. Jest postępowanie prokuratury
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556259,wypowiedz-jana-pietrzaka-o-imigrantach-jest-postepowanie-prokuratury.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30556259,wypowiedz-jana-pietrzaka-o-imigrantach-jest-postepowanie-prokuratury.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T14:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8a/24/1d/z30556298M,Jan-Pietrzak.jpg" vspace="2" />Prokuratura Okręgowa w Warszawie wszczęła postępowanie dotyczące wypowiedzi Jana Pietrzaka na antenie Telewizji Republika. Dochodzenie ma dotyczyć publicznego znieważenia grupy ludności z powodu ich przynależności narodowej i etniczej. Rzecznik Prokuratury Okręgowej Szymon Banna wyjaśnił, że postępowanie jest prowadzone w sprawie, co oznacza, że nikomu nie przedstawiono zarzutĂłw.

## Uwaga za nie zapłacenie składki na akcję charytatywną? Interweniowała ministerka edukacji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555949,uwaga-za-nie-zaplacenie-skladki-na-akcje-charytatywna-interweniowala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555949,uwaga-za-nie-zaplacenie-skladki-na-akcje-charytatywna-interweniowala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T14:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/56/23/1d/z30555990M,Barbara-Nowacka.jpg" vspace="2" />Ministerka edukacji Barbara Nowacka zareagowała na wpis uczennicy opublikowany w mediach społecznościowych. Miała ona otrzymać uwagę za nie zapłacenie składki na akcję charytatywną. "Nie można oceniać aktywności w zależności od możliwości finansowych" - stwierdziła szefowa resortu edukacji.

## SpĂłr w nowej TVP. Pracownicy są niezadowoleni z decyzji przełożonych. Władze stacji odpierają zarzuty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555877,spor-w-nowej-tvp-pracownicy-sa-niezadowoleni-z-decyzji-przelozonych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555877,spor-w-nowej-tvp-pracownicy-sa-niezadowoleni-z-decyzji-przelozonych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T14:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d6/23/1d/z30556118M,Siedziba-TVP.jpg" vspace="2" />Część nowych pracownikĂłw Telewizji Polskiej jest niezadowolona, ponieważ niektĂłrzy członkowie dawnej redakcji TVP Info oraz "Wiadomości" zachowali swoje stanowiska. Szef TAI oraz dyrektor generalny TVP tłumaczą, że nie chcą stosować odpowiedzialności zbiorowej. Zamiast tego zamierzają "dać szansę" osobom pracującym w TVP pod rządami PiS.

## Zima nadciąga do Polski. Wraz z nią może pojawić się potencjalnie niebezpieczna okiść
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555909,zimowa-pogoda-nadciaga-do-polski-wraz-z-nia-moze-pojawic-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555909,zimowa-pogoda-nadciaga-do-polski-wraz-z-nia-moze-pojawic-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T13:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/90/23/1d/z30556048M,Zimowa-pogoda-nadciaga-do-Polski--Wraz-z-nia-moze-.jpg" vspace="2" />Synoptycy zapowiadają intensywne opady śniegu w Polsce, a wraz z nimi mogą pojawić się potencjalnie niebezpieczne zjawiska. Jednym z nich jest okiść śnieżna. Eksperci zalecili, aby zachować szczegĂłlną ostrożność.

## Starcie Sikorskiego z Szydło. "Po byłej premier spodziewałbym się elementarnej wiedzy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30555923,starcie-sikorskiego-z-szydlo-po-bylej-premier-spodziewalbym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30555923,starcie-sikorskiego-z-szydlo-po-bylej-premier-spodziewalbym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T13:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/09/21/1d/z30544393M,Radoslaw-Sikorski.jpg" vspace="2" />Beata Szydło w najnowszym poście zarzuciła Donaldowi Tuskowi doprowadzenie do konfliktu z USA, ktĂłry w jej ocenie wpłynął na "zerwanie projektu amerykańskiej tarczy antyrakietowej". Na te słowa zareagował Radosław Sikorski. - Po byłej premier spodziewałbym się elementarnej wiedzy - stwierdził szef MSZ.

## "Luksusowa" premia świąteczna w Rosji. Polityk dał pracownikom jajka. Pozowali z nimi do zdjęcia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555429,luksusowa-premia-swiateczna-w-rosji-polityk-dal-pracownikom.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555429,luksusowa-premia-swiateczna-w-rosji-polityk-dal-pracownikom.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T13:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f0/23/1d/z30555632M,Rosja--Pracownicy-dostali-jajka-w-ramach-premii-sw.jpg" vspace="2" />Rosyjski polityk Oleksandr Gordiejew podarował pracownicom premię świąteczną w postaci jajek. Zdjęcie, na ktĂłrym kobiety pozują z niecodziennym prezentem, przedstawia problem z dostępnością tego towaru w Rosji.

## Członek KRRiT o spotkaniu z Andrzejem Dudą. "Padła propozycja, żeby zrobić krok wstecz"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30555600,czlonek-krrit-o-spotkaniu-z-andrzejem-duda-padla-propozycja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30555600,czlonek-krrit-o-spotkaniu-z-andrzejem-duda-padla-propozycja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T13:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/23/1d/z30555847M,Czlonek-KRRiT-o-spotkaniu-z-Andrzejem-Duda---Padla.jpg" vspace="2" />Andrzej Duda spotkał się w piątek (29 grudnia) z członkami Krajowej Rady Radiofonii i Telewizji. Tematem rozmowy były ostatnie decyzje ministra kultury Bartłomieja Sienkiewicza w sprawie mediĂłw publicznych. Tadeusz Kowalski z KRRiT zdradził, jak przebiegało spotkanie. - Poddał krytyce stan mediĂłw publicznych, zarĂłwno przed 2015, jak i po 2015 roku - mĂłwił o wypowiedzi prezydenta.

## Fajerwerki w sylwestra w Dolinie Pięciu StawĂłw. Wyznaczono nagrodę za wskazanie, kto je odpalił
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554820,fajerwerki-w-sylwestra-w-dolinie-pieciu-stawow-wyznaczono-nagrode.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554820,fajerwerki-w-sylwestra-w-dolinie-pieciu-stawow-wyznaczono-nagrode.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T13:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/18/23/1d/z30554904M,Tatry--W-Dolinie-Pieciu-Stawow-Polskich-odpalono-f.jpg" vspace="2" />Sylwester w Tatrach doprowadził do huku i możliwego wypłoszenia zwierząt. Wszystko przez osobę, ktĂłra odpaliła fajerwerki w Dolinie Pięciu StawĂłw Polskich. Portal Tatromaniak przekazał, że za informacje, kto wystrzelił fajerwerki, wyznaczono 5 tys. zł nagrody.

## Japonia. Jest nagranie z wnętrza płonącego samolotu. "To było piekło". Pięć osĂłb zginęło [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555592,japonia-jest-nagranie-z-wnetrza-plonacego-samolotu-to-bylo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555592,japonia-jest-nagranie-z-wnetrza-plonacego-samolotu-to-bylo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T13:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8c/23/1d/z30555788M,379-osob-ewakuowano-z-plonacego-samolotu-w-Tokio--.jpg" vspace="2" />Pięciu członkĂłw załogi samolotu japońskiej straży przybrzeżnej zginęło w zderzeniu z samolotem pasażerskim, ktĂłry zapalił się po wylądowaniu na lotnisku w Tokio. Uczestnicy zdarzenia opowiedzieli o wypadku i sprawnej ewakuacji, dzięki ktĂłrej uratowano 379 osĂłb. Opublikowano też nagranie z wnętrza płonącego samolotu.

## 10-latek zabił rĂłwieśnika w Kalifornii. Wcześniej się chwalił, że ma broń palną
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555335,10-latek-smiertelnie-postrzelil-rowiesnika-w-kalifornii-wczesniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555335,10-latek-smiertelnie-postrzelil-rowiesnika-w-kalifornii-wczesniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T13:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cb/23/1d/z30555595M,Policja--Kalifornia--zdjecie-ilustracyjne-.jpg" vspace="2" />W Kalifornii w hrabstwie Sacramento 10-latek śmiertelnie postrzelił swojego rĂłwieśnika. Przed zdarzeniem chłopiec miał się chwalić, że zabrał broń ojcu, ktĂłry - jak się pĂłźniej okazało - ukradł ją kilka lat wcześniej i prĂłbował ukryć. Po zdarzeniu ojciec i syn trafili do aresztu.

## Posłanka PiS z pretensjami do Donalda Tuska. "Jest moją mamą, więc musiała być odwołana"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30555336,poslanka-pis-z-pretensjami-do-donalda-tuska-jest-moja-mama.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30555336,poslanka-pis-z-pretensjami-do-donalda-tuska-jest-moja-mama.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T13:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0f/10/1d/z30475791M,Poslanka-PiS-Joanna-Lichocka.jpg" vspace="2" />Premier Donald Tusk jeszcze przed końcem roku odwołał członkĂłw rad kilku instytutĂłw podległych Prezesowi Rady MinistrĂłw. WśrĂłd kilkudziesięciu osĂłb, ktĂłre straciły w związku z tym pracę, znalazła się prof. Halina Lichocka, matka posłanki PiS. Joanna Lichocka skomentowała tę sprawę w mediach społecznościowych.

## Były pracownik TVP Info zdobył się na wyznanie. "Nie zawsze pracowałem w zgodzie z sumieniem". Fala komentarzy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30555646,byly-pracownik-tvp-info-zdobyl-sie-na-wyznanie-nie-zawsze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30555646,byly-pracownik-tvp-info-zdobyl-sie-na-wyznanie-nie-zawsze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T12:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/88/23/1d/z30555272M,Bartlomiej-Graczak-w-programie--Minela-20---TVP-In.jpg" vspace="2" />Bartłomiej Graczak po prawie ośmiu latach odszedł z TVP, poinformował, że otworzy teraz własny kanał na YouTube, na ktĂłrym będzie tworzył "rzetelne media". Decyzja wywołała szereg komentarzy dziennikarzy i publicystĂłw. "Graczak 'tylko wykonywał rozkazy'. Tak kończą funkcjonariusze propagandy, ale te żale nie pomogą" - ocenił Patryk Michalski z WP.

## "Bestia ze wschodu" powrĂłci? Nagłe ocieplenie stratosfery może spowodować uderzenie zimy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555151,bestia-ze-wschodu-powroci-nagle-ocieplenie-stratosfery-moze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555151,bestia-ze-wschodu-powroci-nagle-ocieplenie-stratosfery-moze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T12:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/23/1d/z30555287M,Nagle-ocieplenie-stratosfery-spowoduje-uderzenie-z.jpg" vspace="2" />Jedno z ekstremalnych zjawisk atmosferycznych, jakim jest nagłe ocieplenie stratosfery, może spowodować atak zimy w Europie. Synoptycy wskazali, kiedy można się spodziewać gwałtownego spadku temperatury. Czy powrĂłci "bestia ze wschodu"?

## Rosjanie zrzucili pocisk na własną wieś. "Podczas lotu zakrzyknął 'Slawa Ukrainu!'"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555425,rosjanie-zrzucili-pocisk-na-wlasna-wies-podczas-lotu-zakrzyknal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555425,rosjanie-zrzucili-pocisk-na-wlasna-wies-podczas-lotu-zakrzyknal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T12:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d3/23/1d/z30555603M,Zniszczenia-we-wsi-Pietropawlowka.jpg" vspace="2" />W sieci pojawiły się nagrania zniszczeń, do ktĂłrych doszłow we wtorek we wsi Pietropawłowka, leżącej w graniczącym z Ukrainą obwodzie woroneskim. Interfax informuje, że w okolicy spadł pocisk przenoszony przez samolot rosyjskiej armii.

## W szkole znaleziono zwłoki mężczyzny. Czuć było spaleniznę. Policja ujawniła wstępne ustalenia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555213,w-szkole-znaleziono-zwloki-mezczyzny-czuc-bylo-spalenizne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555213,w-szkole-znaleziono-zwloki-mezczyzny-czuc-bylo-spalenizne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T12:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ed/23/1d/z30555373M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />W szkole na terenie Gorzowa Wielkopolskiego znaleziono zwłoki mężczyzny. Część rzeczy znajdujących się przy ciele była nadpalona. Policja przekazała pierwsze informacje dotyczące zmarłego.

## Nowy komunikat dowĂłdztwa operacyjnego ws. patroli przestrzeni powietrznej. Wojsko w gotowości
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555117,nowy-komunikat-dowodztwa-operacyjnego-ws-patroli-przestrzeni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30555117,nowy-komunikat-dowodztwa-operacyjnego-ws-patroli-przestrzeni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T10:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e9/c9/1c/z30185961M,Mysliwiec-F-16.jpg" vspace="2" />Po kilku godzinach od rozpoczęcia obserwacji polskiej przestrzeni powietrznej DowĂłdztwo Operacyjne RodzajĂłw Sił Zbrojnych poinformowało o zakończeniu działań. "Ze względu na zmniejszenie poziomu zagrożenia, operowanie par dyżurnych polskiego i sojuszniczego lotnictwa w naszej przestrzeni powietrznej zostało zakończone" - przekazano w komunikacie.

## KijĂłw w ogniu po rosyjskim ostrzale. Zełenski pokazał poruszające nagranie. "Piekło"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555161,kijow-w-ogniu-po-rosyjskim-ostrzale-zelenski-pokazal-poruszajace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555161,kijow-w-ogniu-po-rosyjskim-ostrzale-zelenski-pokazal-poruszajace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T10:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/23/1d/z30554711M,Atak-rakietowy.jpg" vspace="2" />Kilkadziesiąt osĂłb zostało rannych, a co najmniej cztery zginęły w wtorkowym rosyjskim ataku rakietowym na Ukrainę. Liczba ofiar może się zwiększyć. Wołodymyr Zełenski opublikował w mediach społecznościowych poruszające nagranie. To kolejny zmasowany atak rosyjskiej armii w ostatnich dniach.

## PorĂłwnał dwa zdjęcia Władimira Putina. "Co się z nim stało w ciągu nocy?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554993,zaskakujaca-transformacja-wladimira-putina-opublikowano-zdjecia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554993,zaskakujaca-transformacja-wladimira-putina-opublikowano-zdjecia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T10:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2e/23/1d/z30555182M,Zdjecie-Wladimira-Putina-z-31-grudnia-2023-r--i-1-.jpg" vspace="2" />W mediach społecznościowych pojawiło się zdjęcie Władimira Putina z 1 stycznia. Prezydent Rosji wygląda na nim zupełnie inaczej niż na fotografii wykonanej dzień wcześniej, podczas wygłaszania noworocznego orędzia. Doradca szefa MSW Ukrainy zastanawia się, co mogło być przyczyną tych rĂłżnic.

## Pożar mieszkania w OstrĂłdzie. Matka dwĂłjki dzieci trafiła do szpitala z poparzeniami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554956,pozar-mieszkania-w-ostrodzie-matka-dwojki-dzieci-trafila-do.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554956,pozar-mieszkania-w-ostrodzie-matka-dwojki-dzieci-trafila-do.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T10:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d4/23/1d/z30555092M,Ostroda--Pozar-mieszkania.jpg" vspace="2" />Pożar jednego z mieszkań w OstrĂłdzie spowodował obrażenia u matki dwĂłjki dzieci i ewakuację pozostałych mieszkańcĂłw. Kobieta została zabrana do szpitala. Ogień został zauważony przez jednego z sąsiadĂłw, ktĂłry podjął prĂłbę jego ugaszenia.

## Ile dać księdzu po kolędzie? Duchowny z nietypową wskazĂłwką. "Proponuję przygotować trzy koperty"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554890,ile-dac-do-koperty-na-koledzie-ksiadz-dal-wiernym-wytyczne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554890,ile-dac-do-koperty-na-koledzie-ksiadz-dal-wiernym-wytyczne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T10:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c3/23/1d/z30555075M,Ksiadz-przekazal-wytyczne-ws--kopert-na-kolede.jpg" vspace="2" />Popularny na TikToku ksiądz Sebastian Picur opublikował film, w ktĂłrym wyjaśnia, co może się znaleźć w kopercie, ktĂłrą wierni ofiarują księdzu podczas kolędy. - Proponuję przygotować trzy koperty: dużą, średnią i małą - zalecił duchowny.

## Awantura z udziałem syna Zenka Martyniuka w zakopiańskim hotelu. "Darł się we wniebogłosy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554789,awantura-z-udzialem-syna-zenka-martyniuka-w-zakopianskim-hotelu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554789,awantura-z-udzialem-syna-zenka-martyniuka-w-zakopianskim-hotelu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T10:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e5/23/1d/z30554853M,Awantura-z-udzialem-syna-Zenka-Martyniuka-w-zakopi.jpg" vspace="2" />Daniela Martyniuka, syna Zenka policja zatrzymała w noc sylwestrową w Zakopanem. 34-letni mężczyzna miał wszcząć awanturę w hotelu Belvedere i zachowywać się agresywnie wobec swojej żony. - Cały czas wyzywał ją od ku***. Ta dziewczyna strasznie płakała. Prosiła go, by się uspokoił. On darł się jednak we wniebogłosy przed wyjściem. To jak on traktował tę dziewczynę to koszmar - opisywał gość obiektu.

## Sprawa fikcyjnego etatu Anny Morawieckiej. Prokuratura umorzyła śledztwo wobec dziennikarzy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554922,sprawa-fikcyjnego-etatu-anny-morawieckiej-prokuratura-umorzyla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554922,sprawa-fikcyjnego-etatu-anny-morawieckiej-prokuratura-umorzyla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T09:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/86/8d/1c/z29941126M,Anna-Morawiecka.jpg" vspace="2" />Prokuratura umorzyła śledztwo ws. dziennikarzy "Wyborczej" i "Nowej Gazety Trzebnickiej" wszczęte przez Annę Morawiecką. Dotyczyło dziennikarzy, ktĂłrzy na łamach obu tytułĂłw donosili, że siostra byłego premiera miała być fikcyjnie zatrudniona w Urzędzie Miasta w Trzebnicy.

## Katastrofa w Japonii. Samolot zapalił się podczas lądowania na lotnisku w Tokio
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555043,katastrofa-w-japonii-samolot-zapalil-sie-podczas-ladowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30555043,katastrofa-w-japonii-samolot-zapalil-sie-podczas-ladowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T09:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b1/23/1d/z30555057M,Samolot-stanal-w-plomieniach.jpg" vspace="2" />Samolot linii Japan Airlines zapalił się zaraz po wylądowaniu na pasie lotniska Haneda w Tokio. Maszyna leciała z Sapporo na pĂłłnocy kraju. Trwa akcja gaśnicza - informuje BBC.

## "Odwoływanie się do konstytucji wygląda żałośnie". Były prezes SN skrytykował orędzie Andrzeja Dudy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554757,odwolywanie-sie-do-konstytucji-wyglada-zalosnie-byly-prezes.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554757,odwolywanie-sie-do-konstytucji-wyglada-zalosnie-byly-prezes.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T08:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f0/23/1d/z30554864M,Prof--Adam-Strzembosz.jpg" vspace="2" />Były prezes Sądu Najwyższego prof. Adam Strzembosz odniĂłsł się do noworocznego orędzia Andrzeja Dudy. - W tej chwili odwoływanie się do konstytucji, do jego funkcji strażniczych, wygląda dość żałośnie. Praworządność w Polsce była zagrożona, ponieważ zmian poza wszelkimi formami prawnymi chcieli większość parlamentarna, rząd i prezydent - ocenił profesor.

## Skarga do KRRiT na skandaliczną wypowiedź Jana Pietrzaka o imigrantach. "Drastyczne naruszenie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554724,skarga-do-krrit-na-skandaliczna-wypowiedz-jana-pietrzaka-o-imigrantach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554724,skarga-do-krrit-na-skandaliczna-wypowiedz-jana-pietrzaka-o-imigrantach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T08:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b8/23/1d/z30554808M,Jan-Pietrzak.jpg" vspace="2" />Krajowa Rada Radiofonii i Telewizji otrzymała skargę "w związku z haniebną wypowiedzią Jana Pietrzaka na antenie Telewizji Republika". Skarga dotyczy "okrutnego żartu" satyryka, ktĂłry mĂłwił o "barakach dla imigrantĂłw w Auschwitz".

## Żaryn przekonywał, że ten raport nie istnieje. "GW" ujawnia dane o szczelności zapory na granicy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554718,zaryn-przekonywal-ze-ten-raport-nie-istnieje-gw-ujawnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554718,zaryn-przekonywal-ze-ten-raport-nie-istnieje-gw-ujawnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T08:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8d/23/1d/z30553741M,Nomiki-kolo-Sokolki-i-Kuznicy--Granica-polsko-bial.jpg" vspace="2" />"Gazeta Wyborcza" opublikowała raport Straży Granicznej, z ktĂłrego wynikało, że zapora na polsko-białoruskiej granicy jest nieszczelna. Tylko przez pierwszych dziewięć miesięcy 2023 r. zaporę pokonało i zostało złapanych 17 tys. 488 migrantĂłw. Stanisław Żaryn i inni politycy PiS przekonywali, że taki dokument nie istnieje.

## Śnieżyce i mrĂłz nadciągają. IMGW z najwyższymi alertami. Nagła zmiana pogody w Polsce
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554681,nagla-zmiana-pogody-w-calej-polsce-nadciagaja-sniezyce-i-mroz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554681,nagla-zmiana-pogody-w-calej-polsce-nadciagaja-sniezyce-i-mroz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T07:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c1/1f/1d/z30536129M.jpg" vspace="2" />Pogoda w najbliższych dniach bardzo się zmieni. W Polsce pojawią się opady śniegu, oblodzenie, a temperatura znacznie spadnie. Synoptycy wydali już ostrzeżenia meteorologiczne dla kilku wojewĂłdztw.

## Aleksander Herzog nie żyje. "Straciliśmy mentora", "jeden z najwybitniejszych polskich prokuratorĂłw"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554676,nie-zyje-aleksander-herzog-jeden-z-najwybitniejszych-polskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554676,nie-zyje-aleksander-herzog-jeden-z-najwybitniejszych-polskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T07:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/23/1d/z30554713M,Nie-zyje-Aleksander-Herzog.jpg" vspace="2" />Aleksander Herzog nie żyje. Był prokuratorem w stanie spoczynku, opozycjonistą z czasĂłw PRL i autorem tekstĂłw prawniczych. Członkowie stowarzyszenia prokuratorĂłw "Lex Super Omnia" stwierdzili, że Aleksander Herzog był "orędownikiem niezależności prokuratury".

## DowĂłdztwo operacyjne: Rozpoczęły się patrole polskiej przestrzeni powietrznej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554745,dowodztwo-operacyjne-rozpoczeto-patrole-polskiej-przestrzeni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554745,dowodztwo-operacyjne-rozpoczeto-patrole-polskiej-przestrzeni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T07:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />DowĂłdztwo Operacyjne RodzajĂłw Sił Zbrojnych poinformowało, że w celu zapewnienia bezpieczeństwa polskiej przestrzeni powietrznej aktywowano dwie pary myśliwcĂłw F-16 oraz sojuszniczy tankowiec powietrzny. Decyzję podjęto w związku z kolejnym zmasowanym ostrzałem Ukrainy.

## Alarm powietrzny w całej Ukrainie. Rosja wystrzeliła rakiety. "Nie ignoruj alarmu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554675,alarm-powietrzny-w-calej-ukrainie-rosja-wystrzelila-rakiety.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554675,alarm-powietrzny-w-calej-ukrainie-rosja-wystrzelila-rakiety.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T07:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/56/23/1d/z30554710M,Atak-rakietowy--zdjecie-ilustracyjne-.jpg" vspace="2" />Nowy rok rozpoczął się w Ukrainie kolejnym odpieraniem atakĂłw rosyjskiego wojska. ZarĂłwno w poniedziałek, jak i we wtorek rano alarm powietrzny obowiązywał w całym kraju. Doszło nie tylko do ataku rakietami, ale rĂłwnież dronami.

## Rosyjska rakieta nad Polską. Wiceszef MON: Opuściła terytorium Polski. Mamy pewność z dwĂłch źrĂłdeł
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554695,rosyjska-rakieta-nad-polska-wiceszef-mon-mamy-pewnosc-opuscila.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30554695,rosyjska-rakieta-nad-polska-wiceszef-mon-mamy-pewnosc-opuscila.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T06:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d7/22/1d/z30551255M,Zakonczono-poszukiwania-elementow-rakiety--ktora-w.jpg" vspace="2" />Paweł Zalewski, sekretarz stanu w Ministerstwie Obrony Narodowej, był gościem programu "Poranna rozmowa w RMF FM". W rozmowie z dziennikarzem potwierdził, że rosyjska rakieta, ktĂłra 29 grudnia naruszyła polską przestrzeń powietrzną, nie spadła nigdzie na terytorium naszego kraju. - Mamy pewność, że rakieta opuściła terytorium Polski, z dwĂłch źrĂłdeł: z radarĂłw polskich i sojuszniczych i po przeczesaniu tamtych terenĂłw - mĂłwił.

## Kto nowym szefem NATO? Wyłania się faworyt. Trump: Zaprzyjaźniliśmy się
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30554680,kto-nowym-szefem-nato-wylania-sie-faworyt-trump-zaprzyjaznilismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30554680,kto-nowym-szefem-nato-wylania-sie-faworyt-trump-zaprzyjaznilismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T06:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/49/23/1d/z30554697M,Mark-Rutte-i-Olaf-Scholz.jpg" vspace="2" />W 2024 roku rozwiąże się jedna z największych zagadek w Brukseli: kto zastąpi Jensa Stoltenberga na stanowisku szefa NATO.

## Korea Południowa. Lider opozycji dźgnięty nożem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554671,korea-poludniowa-lider-opozycji-dzgniety-nozem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30554671,korea-poludniowa-lider-opozycji-dzgniety-nozem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T06:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3d/23/1d/z30554685M,Korea-Poludniowa--Lider-opozycji-dzgniety-nozem.jpg" vspace="2" />PrzywĂłdca południowokoreańskiej opozycji Lee Jae-myung został we wtorek dźgnięty nożem w szyję podczas rozmowy z reporterami w południowo-wschodnim mieście portowym Busan. Napastnik został już zatrzymany.

## Horoskop dzienny - wtorek 2 stycznia 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30523780,horoskop-dzienny-wtorek-2-stycznia-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30523780,horoskop-dzienny-wtorek-2-stycznia-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-01-02T04:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/70/fd/1c/z30396528M,Horoskop-dzienny---wtorek.jpg" vspace="2" />Znaki zodiaku przeżyją dziś lekkie zmiany. Będą one dotyczyły zarĂłwno codzienności, jak i relacji z otoczeniem. Horoskop dzienny na 2 stycznia podpowiada, na co warto zwrĂłcić uwagę.

