# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 Hardest Bosses in Recent Games That BROKE US
 - [https://www.youtube.com/watch?v=RDEijQeaN4I](https://www.youtube.com/watch?v=RDEijQeaN4I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-01-02T15:20:17+00:00

Here are some of the most challenging bosses from 2023.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1    

0:00 Intro
0:41 Number 10
2:42 Number 9
4:29 Number 8
6:21 Number 7
8:13 Number 6
10:30 Number 5
12:34 Number 4
14:13 Number 3 
16:41 Number 2 
18:03 Number 1

