# Source:Neowin, URL:https://www.neowin.net/news/rss/, language:en-us

## Baldur's Gate 3, Starfield, and Sifu are among the winners of the 2023 Steam Awards
 - [https://www.neowin.net/news/baldurs-gate-3-starfield-and-sifu-are-among-the-winners-of-the-2023-steam-awards](https://www.neowin.net/news/baldurs-gate-3-starfield-and-sifu-are-among-the-winners-of-the-2023-steam-awards)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T21:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/08/1693508191_baldurs-gate-3_medium.jpg" /></div>Baldur&#039;s Gate 3 was voted Game of the Year by Steam players as part of the 2023 Steam Awards, while Starfield won for Most Innovative Gameplay and Sifu won for Best Game You Suck At. <a href="https://www.neowin.net/news/baldurs-gate-3-starfield-and-sifu-are-among-the-winners-of-the-2023-steam-awards">Read more...</a>

## 1TB Crucial T500 Gen4 NVMe SSD with headsink for Sony PS5 available at a great discount
 - [https://www.neowin.net/deals/1tb-crucial-t500-gen4-nvme-ssd-with-headsink-for-sony-ps5-available-at-a-great-discount](https://www.neowin.net/deals/1tb-crucial-t500-gen4-nvme-ssd-with-headsink-for-sony-ps5-available-at-a-great-discount)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T20:40:11+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1698774450_crucial-t500_medium.jpg" /></div>The 1TB Crucial T500 Gen4 NVMe M.2 internal gaming SSD with heatsink is currently available at a great deal so, grab it right away. Or, check out other SSD deals on Silicone Power and SanDisk. <a href="https://www.neowin.net/deals/1tb-crucial-t500-gen4-nvme-ssd-with-headsink-for-sony-ps5-available-at-a-great-discount">Read more...</a>

## Samsung confirms Unpacked event for January 17 with "Galaxy AI"; Galaxy S24 launch expected
 - [https://www.neowin.net/news/samsung-confirms-unpacked-event-for-january-17-with-galaxy-ai-galaxy-s24-launch-expected](https://www.neowin.net/news/samsung-confirms-unpacked-event-for-january-17-with-galaxy-ai-galaxy-s24-launch-expected)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T20:14:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2017/07/1500948588_samsung_logo_medium.jpg" /></div>Samsung Australia&#039;s X account has confirmed the company will hold a new Galaxy Unpacked event on January 17. The Galaxy S24 smartphone lineup is expected to be revealed, with &quot;Galaxy AI&quot; as well. <a href="https://www.neowin.net/news/samsung-confirms-unpacked-event-for-january-17-with-galaxy-ai-galaxy-s24-launch-expected">Read more...</a>

## Jack Black will join another video game movie adaptation with a role in the Minecraft film
 - [https://www.neowin.net/news/jack-black-will-join-another-video-game-movie-adaptation-with-a-role-in-the-minecraft-film](https://www.neowin.net/news/jack-black-will-join-another-video-game-movie-adaptation-with-a-role-in-the-minecraft-film)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T19:56:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704222768_jack-black_medium.jpg" /></div>Jack Black, actor, musician, and sometimes gamer, will join the cast of the upcoming film adaptation of Mojang and Microsoft&#039;s Minecraft game. The movie is about to start production soon. <a href="https://www.neowin.net/news/jack-black-will-join-another-video-game-movie-adaptation-with-a-role-in-the-minecraft-film">Read more...</a>

## NVIDIA teases CES 2024 RTX 40 Super launch: RTX 4080,  4070 Ti, and 4070 Super incoming
 - [https://www.neowin.net/news/nvidia-teases-ces-2024-rtx-40-super-launch-rtx-4080-4070-ti-and-4070-super-incoming](https://www.neowin.net/news/nvidia-teases-ces-2024-rtx-40-super-launch-rtx-4080-4070-ti-and-4070-super-incoming)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T18:16:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704217672_nvidia_rtx_4000_super_nvidia_geforce_cover_photo_medium.jpg" /></div>NVIDIA was heavily criticised by the tech press including Neowin about the lacking VRAM buffer on its RTX 4000 series GPUs. The company is soon expected to unveil new Super series GPUs that fix this. <a href="https://www.neowin.net/news/nvidia-teases-ces-2024-rtx-40-super-launch-rtx-4080-4070-ti-and-4070-super-incoming">Read more...</a>

## Save 82% on a Price Dropped lifetime subscription to OysterVPN
 - [https://www.neowin.net/deals/save-82-on-a-price-dropped-lifetime-subscription-to-oystervpn](https://www.neowin.net/deals/save-82-on-a-price-dropped-lifetime-subscription-to-oystervpn)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T18:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704211032_product_339882_product_shots1_medium.jpg" /></div>Thanks to fast global VPN servers, freedom on the internet is now a reality. Moreover, OysterVPN follows a zero-logs policy - even they don&#039;t know what you do on the internet! Grab this deal today! <a href="https://www.neowin.net/deals/save-82-on-a-price-dropped-lifetime-subscription-to-oystervpn">Read more...</a>

## Star Wars Outlaws is now set for release in late 2024, according to new Disney blog post
 - [https://www.neowin.net/news/star-wars-outlaws-is-now-set-for-release-in-late-2024-according-to-new-disney-blog-post](https://www.neowin.net/news/star-wars-outlaws-is-now-set-for-release-in-late-2024-according-to-new-disney-blog-post)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T17:16:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/06/1686594487_star-wars-outlaws-art_medium.jpg" /></div>A post on the Disney Park blog claims that Star Wars Outlaws, the open world game set in the Star Wars universe from developer Massive and publisher Ubisoft, is due for release in late 2024. <a href="https://www.neowin.net/news/star-wars-outlaws-is-now-set-for-release-in-late-2024-according-to-new-disney-blog-post">Read more...</a>

## Investing in Stocks for Dummies (worth $11) free eBook
 - [https://www.neowin.net/sponsored/investing-in-stocks-for-dummies-worth-11-free-ebook](https://www.neowin.net/sponsored/investing-in-stocks-for-dummies-worth-11-free-ebook)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T17:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704211701_w_wile486c82_medium.jpg" /></div>Yes, you can make money in the stock market--this guide shows you how. The expert info in this book will start you off on the right foot as you begin your journey down Wall Street. Grab it today! <a href="https://www.neowin.net/sponsored/investing-in-stocks-for-dummies-worth-11-free-ebook">Read more...</a>

## 20 Minutes Till Dawn is free to claim today on the Epic Games Store
 - [https://www.neowin.net/news/20-minutes-till-dawn-is-free-to-claim-today-on-the-epic-games-store](https://www.neowin.net/news/20-minutes-till-dawn-is-free-to-claim-today-on-the-epic-games-store)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T16:08:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704192481_20_medium.jpg" /></div>Another 24-hour giveaway has kicked off on the Epic Games Store, and this time it&#039;s a copy of 20 Minutes Till Dawn that&#039;s being offered. It is a Vampire Survivors-like that released in 2023. <a href="https://www.neowin.net/news/20-minutes-till-dawn-is-free-to-claim-today-on-the-epic-games-store">Read more...</a>

## You can save $500 on the Razer Blade 14 (2023) gaming laptop
 - [https://www.neowin.net/deals/you-can-save-500-on-the-razer-blade-14-2023-gaming-laptop](https://www.neowin.net/deals/you-can-save-500-on-the-razer-blade-14-2023-gaming-laptop)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T15:22:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704208613_81byv-m8ltl._ac_sl1500__medium.jpg" /></div>You can currently pick up the Razer Blade 14 (2023) gaming laptop up on Amazon for $2,199.99. If you buy now you&#039;ll be saving a considerable $500 off of the list price which is $2,699.99. <a href="https://www.neowin.net/deals/you-can-save-500-on-the-razer-blade-14-2023-gaming-laptop">Read more...</a>

## The Meta Quest 2 headset gets a permanent price cut to $250 as VR gaming's future looks grim
 - [https://www.neowin.net/news/the-meta-quest-2-headset-gets-a-permanent-price-cut-to-250-as-vr-gamings-future-looks-grim](https://www.neowin.net/news/the-meta-quest-2-headset-gets-a-permanent-price-cut-to-250-as-vr-gamings-future-looks-grim)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T15:10:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/07/1658860130_275812444_2294118730728867_5377134401450206700_n_medium.jpg" /></div>The price of the Meta Quest 2 VR headset is now permanently set at $249.99, but the future of VR gaming looks dim after a major VR-only game developer announced it is closing its doors. <a href="https://www.neowin.net/news/the-meta-quest-2-headset-gets-a-permanent-price-cut-to-250-as-vr-gamings-future-looks-grim">Read more...</a>

## Get this ASUS ROG wireless gaming mouse with charging stand for an all time low price now
 - [https://www.neowin.net/deals/get-this-asus-rog-wireless-gaming-mouse-with-charging-stand-for-an-all-time-low-price-now](https://www.neowin.net/deals/get-this-asus-rog-wireless-gaming-mouse-with-charging-stand-for-an-all-time-low-price-now)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T15:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704201406_asus-rog-mouse_medium.jpg" /></div>The ASUS ROG Spatha X wireless PC gaming mouse has 12 buttons, RGB lighting, and comes with its own magnetic charging stand. It&#039;s now available on Amazon for an all-time low price of $99.99. <a href="https://www.neowin.net/deals/get-this-asus-rog-wireless-gaming-mouse-with-charging-stand-for-an-all-time-low-price-now">Read more...</a>

## Android users will soon have to sacrifice Google Drive storage to keep WhatsApp Chat backups
 - [https://www.neowin.net/news/android-users-will-soon-have-to-sacrifice-google-drive-storage-to-keep-whatsapp-chat-backups](https://www.neowin.net/news/android-users-will-soon-have-to-sacrifice-google-drive-storage-to-keep-whatsapp-chat-backups)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T14:46:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/11/1698815489_whatsapp-2453592_1920_medium.jpg" /></div>Previously, Android users got a free-of-cost storage space on Google Drive specifically for their WhatsApp chat storage. However soon, these chats will consume storage from their own Drive accounts. <a href="https://www.neowin.net/news/android-users-will-soon-have-to-sacrifice-google-drive-storage-to-keep-whatsapp-chat-backups">Read more...</a>

## Save a massive 41% on the Samsung Galaxy Book2 Pro
 - [https://www.neowin.net/deals/save-a-massive-41-on-the-samsung-galaxy-book2-pro](https://www.neowin.net/deals/save-a-massive-41-on-the-samsung-galaxy-book2-pro)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T14:28:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704203281_81hjwhnexxl._ac_sl1500__medium.jpg" /></div>You can currently buy the Samsung Galaxy Book2 Pro on Amazon with a 41% discount. This laptop has been available on Amazon for just over a year but the big price drop makes it worth considering. <a href="https://www.neowin.net/deals/save-a-massive-41-on-the-samsung-galaxy-book2-pro">Read more...</a>

## Microsoft renamed Edge on Android and iOS to 'Microsoft Edge: AI Browser'
 - [https://www.neowin.net/news/microsoft-renamed-edge-on-android-and-ios-to-microsoft-edge-ai-browser](https://www.neowin.net/news/microsoft-renamed-edge-on-android-and-ios-to-microsoft-edge-ai-browser)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T14:14:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704204256_microsoft_edge_medium.jpg" /></div>The mobile version of the Microsoft Edge browser now has a new name. The company recently renamed it to put more emphasis on built-in AI features. It is now &quot;Microsoft Edge: AI browser&quot;.  <a href="https://www.neowin.net/news/microsoft-renamed-edge-on-android-and-ios-to-microsoft-edge-ai-browser">Read more...</a>

## The Apple Watch Series 9 is available with a $100 discount on Amazon
 - [https://www.neowin.net/deals/the-apple-watch-series-9-is-available-with-a-100-discount-on-amazon](https://www.neowin.net/deals/the-apple-watch-series-9-is-available-with-a-100-discount-on-amazon)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T13:26:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704200389_81ty7x9cjzl._ac_sl1500__medium.jpg" /></div>You can get the Apple Watch Series 9 on Amazon now for just $399, down from the $499 list price. The product seems to be well regarded as it scores 4.5 stars overall based on 385 reviews. <a href="https://www.neowin.net/deals/the-apple-watch-series-9-is-available-with-a-100-discount-on-amazon">Read more...</a>

## Telegram rolls out improved calls, big upgrade for bots, new UI effects and more
 - [https://www.neowin.net/news/telegram-rolls-out-improved-calls-big-upgrade-for-bots-new-ui-effects-and-more](https://www.neowin.net/news/telegram-rolls-out-improved-calls-big-upgrade-for-bots-new-ui-effects-and-more)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T13:10:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704200318_telegram_update_medium.jpg" /></div>Telegram is entering 2024 with improved calls, a big upgrade for bots, UI improvements, and more. In addition, developers promise to deliver even more calling-related enhancements in 2024. <a href="https://www.neowin.net/news/telegram-rolls-out-improved-calls-big-upgrade-for-bots-new-ui-effects-and-more">Read more...</a>

## Get the waterproof GoPro HERO12 now for just $349
 - [https://www.neowin.net/deals/get-the-waterproof-gopro-hero12-now-for-just-349](https://www.neowin.net/deals/get-the-waterproof-gopro-hero12-now-for-just-349)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T12:44:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1704198274_81rrx9yfal._ac_sl1500__medium.jpg" /></div>You can now get the GoPro HERO12 camera on Amazon for just $349. It only came out in September so to get a $50 discount this early on isn&#039;t bad. It has a 4.3 star rating based on hundreds of reviews. <a href="https://www.neowin.net/deals/get-the-waterproof-gopro-hero12-now-for-just-349">Read more...</a>

## PowerToys will soon get a redesigned Keyboard Manager with new features
 - [https://www.neowin.net/news/powertoys-will-soon-get-a-redesigned-keyboard-manager-with-new-features](https://www.neowin.net/news/powertoys-will-soon-get-a-redesigned-keyboard-manager-with-new-features)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T12:28:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/06/1685715444_14_medium.jpg" /></div>PowerToys will soon get a redesigned Keyboard Manager that lets you customize and re-assign global or per-app keyboard shortcuts. Here is an early look at the upcoming facelift and new features. <a href="https://www.neowin.net/news/powertoys-will-soon-get-a-redesigned-keyboard-manager-with-new-features">Read more...</a>

## ASML halts shipments of chipmaking equipment to China under US pressure
 - [https://www.neowin.net/news/asml-halts-shipments-of-chipmaking-equipment-to-china-under-us-pressure](https://www.neowin.net/news/asml-halts-shipments-of-chipmaking-equipment-to-china-under-us-pressure)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T11:04:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/07/1658762546_enterprise-aerial-factory-view-2x1_medium.jpg" /></div>The US government contacted Dutch company ASML to cancel shipments of certain machines to Chinese customers. ASML is now suspending shipments of advanced lithography machines to the country. <a href="https://www.neowin.net/news/asml-halts-shipments-of-chipmaking-equipment-to-china-under-us-pressure">Read more...</a>

## Valve: Windows 11's market share on Steam decreased in December 2023
 - [https://www.neowin.net/news/valve-windows-11s-market-share-on-steam-decreased-in-december-2023](https://www.neowin.net/news/valve-windows-11s-market-share-on-steam-decreased-in-december-2023)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T10:24:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/03/1646733087_steam_windows_11_logo_medium.jpg" /></div>Valve has released the December 2023 Hardware &amp; Software Survey results, showing a slight decrease in Windows 11&#039;s market share. In total, less than 42% of all Steam users run Windows 11. <a href="https://www.neowin.net/news/valve-windows-11s-market-share-on-steam-decreased-in-december-2023">Read more...</a>

## Unofficial app conjures Windows Bob's spirit despite Microsoft wanting you to forget it
 - [https://www.neowin.net/news/unofficial-app-conjures-windows-bobs-spirit-despite-microsoft-wanting-you-to-forget-it](https://www.neowin.net/news/unofficial-app-conjures-windows-bobs-spirit-despite-microsoft-wanting-you-to-forget-it)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T08:26:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/07/1688231991_microsoft-bob-screenshot_medium.jpg" /></div>Even though Microsoft Bob was killed off almost as soon as it was unveiled back in 1995-96, a dev has taken inspiration and has now built a new unofficial app for Windows 11 with the same intention. <a href="https://www.neowin.net/news/unofficial-app-conjures-windows-bobs-spirit-despite-microsoft-wanting-you-to-forget-it">Read more...</a>

## Galaxy S24 Ultra may support 4K video up to 120fps, multiple pre-order offers planned
 - [https://www.neowin.net/news/galaxy-s24-ultra-may-support-4k-video-up-to-120fps-multiple-pre-order-offers-planned](https://www.neowin.net/news/galaxy-s24-ultra-may-support-4k-video-up-to-120fps-multiple-pre-order-offers-planned)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-01-02T05:06:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/02/1676013862_galaxy_unpacked_2023_first_main3_medium.jpg" /></div>Samsung is rumored to launch the Galaxy S24 series soon. Ahead of the launch leaks have confirmed that the company may include support for 4K recording at 120fps as well as multiple pre-order bonuses. <a href="https://www.neowin.net/news/galaxy-s24-ultra-may-support-4k-video-up-to-120fps-multiple-pre-order-offers-planned">Read more...</a>

