# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Kryzys w sądach. Minister sprawiedliwości o możliwych ruchach
 - [https://businessinsider.com.pl/wiadomosci/kryzys-w-sadach-minister-sprawiedliwosci-o-mozliwych-ruchach/gdr2ecg](https://businessinsider.com.pl/wiadomosci/kryzys-w-sadach-minister-sprawiedliwosci-o-mozliwych-ruchach/gdr2ecg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T20:52:00+00:00

Mogę wstrzymać ogłoszenia o nowych konkursach na stanowiska sędziowskie. Na skutek wstrzymania nie będą przeprowadzane kolejne konkursy i kolejne osoby nie będą powoływane przez wadliwie działającą Krajową Radę Sądownictwa — powiedział minister sprawiedliwości Adam Bodnar.

## Cena ta sama, produkt mniejszy. Francja wydaje wojnę shrinkflacji
 - [https://businessinsider.com.pl/wiadomosci/cena-ta-sama-produkt-mniejszy-francja-wydaje-wojne-shrinkflacji/jpg8dfj](https://businessinsider.com.pl/wiadomosci/cena-ta-sama-produkt-mniejszy-francja-wydaje-wojne-shrinkflacji/jpg8dfj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T20:04:00+00:00

Francuskie władze chcą zobowiązać sprzedawców i producentów, by informowali konsumentów o tym, że pomimo tej samej ceny ilość danego produktu się zmniejszyła — poinformował we wtorek portal Just Food.

## Konflikt na Bliskim Wschodzie się rozszerza. Pierwszy taki atak
 - [https://businessinsider.com.pl/wiadomosci/konflikt-na-bliskim-wschodzie-sie-rozszerza-pierwszy-taki-atak/2dg95z3](https://businessinsider.com.pl/wiadomosci/konflikt-na-bliskim-wschodzie-sie-rozszerza-pierwszy-taki-atak/2dg95z3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T19:05:00+00:00

Izrael zaatakował z wykorzystaniem drona biuro Hamasu w stolicy Libanu Bejrucie — donoszą lokalne media. W nalocie zginęły przynajmniej trzy osoby, w tym m.in. zastępca przywódcy politycznego Hamasu Saleh al-Arouri.

## Zakaz płatności gotówką w 2024. Jakie są limity?
 - [https://businessinsider.com.pl/firmy/przepisy/zakaz-platnosci-gotowka-2024-dla-przedsiebiorcow-co-z-transakcjami-prywatnymi/99ens9b](https://businessinsider.com.pl/firmy/przepisy/zakaz-platnosci-gotowka-2024-dla-przedsiebiorcow-co-z-transakcjami-prywatnymi/99ens9b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T19:04:20+00:00

Polski Ład wprowadził nowe zasady dotyczące płatności gotówką, które miały wejść w życie od 2024 r., jednak Sejm wykreślił te przepisy. Przypomnijmy, jaki limit płatności gotówką obowiązuje przedsiębiorców.

## Turcja blokuje pomoc wojskową dla Ukrainy. Okręty nie mogą wpłynąć na Morze Czarne
 - [https://businessinsider.com.pl/wiadomosci/turcja-blokuje-pomoc-wojskowa-dla-ukrainy/pqscpbr](https://businessinsider.com.pl/wiadomosci/turcja-blokuje-pomoc-wojskowa-dla-ukrainy/pqscpbr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T18:53:00+00:00

Władze Turcji odmówiły możliwości przepłynięcia przez przez jej wody w drodze na Morze Czarne dwóm okrętom, które Wielka Brytania przekazała Ukrainie. Ankara powołuje się przy tym na międzynarodową konwencję dotyczącą ruchu jednostek przez tureckie cieśniny w czasie wojny.

## Zgłosiła oszustwo na policji. Wychodząc, znów dała się nabrać
 - [https://businessinsider.com.pl/lifestyle/podroze/zglosila-oszustwo-na-policji-wychodzac-znow-dala-sie-nabrac-to-plaga-w-zakopanem/xqvtebj](https://businessinsider.com.pl/lifestyle/podroze/zglosila-oszustwo-na-policji-wychodzac-znow-dala-sie-nabrac-to-plaga-w-zakopanem/xqvtebj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T17:53:45+00:00

Turyści znajdują w internecie atrakcyjną ofertę noclegu, ale kiedy przyjeżdżają do Zakopanego, okazuje się, że pensjonat nie istnieje. W tym sezonie oszustwa na tzw. wirtualne kwatery przybrały na sile. Jedna z oszukanych, wychodząc z komendy po takim zgłoszeniu, ponownie dała się nabrać oszustom.

## Żona Jacka Kurskiego mówi o dewastacji TVP i klęsce oglądalności. "Jestem zszokowana"
 - [https://businessinsider.com.pl/media/zona-jacka-kurskiego-mowi-o-dewastacji-tvp-i-klesce-ogladalnosci/7w5c2m7](https://businessinsider.com.pl/media/zona-jacka-kurskiego-mowi-o-dewastacji-tvp-i-klesce-ogladalnosci/7w5c2m7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T17:46:11+00:00

Joanna Kurska w nowy rok weszła z mocnym komentarzem do sytuacji w polskiej polityce, a w szczególności w telewizji. Żona byłego prezesa TVP wskazała na "postępującą dewastację TVP przez uzurpatorów podpułkownika Sienkiewicza", ale przyznała też, że "zabijanie siły TVP" rozpoczęło się ponad rok temu.

## Adam Glapiński przed Trybunał Stanu? Wiadomo, co stałoby się z ratingiem
 - [https://businessinsider.com.pl/wiadomosci/adam-glapinski-przed-trybunal-stanu-wiadomo-co-staloby-sie-z-ratingiem/4cmk30m](https://businessinsider.com.pl/wiadomosci/adam-glapinski-przed-trybunal-stanu-wiadomo-co-staloby-sie-z-ratingiem/4cmk30m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T17:40:52+00:00

Nowa większość parlamentarna nie musi bać się automatycznego spadku wiarygodności polskiej gospodarki w oczach agencji ratingowych, jeśli zdecydowałaby się postawić przed Trybunałem Stanu prezesa NBP. Jak wyjaśnia przedstawiciel S&amp;P, w takiej sytuacji nie było "automatycznych" działań ze strony agencji.

## Iga Świątek rozstała się z kluczowym sponsorem. Z dnia na dzień zniknęło logo
 - [https://businessinsider.com.pl/sport/iga-swiatek-i-pzu-koncza-wieloletnia-wspolprace-zdradzila-to-koszulka/737sl48](https://businessinsider.com.pl/sport/iga-swiatek-i-pzu-koncza-wieloletnia-wspolprace-zdradzila-to-koszulka/737sl48)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T16:58:14+00:00

Tenisistka Iga Świątek w nowy rok weszła bez ważnego sponsora. Zdradziła ją koszulka, na której zabrakło charakterystycznego logo największego polskiego ubezpieczyciela.

## Chińska gospodarka jest w tak złym stanie, że przyznał to nawet sam prezydent
 - [https://businessinsider.com.pl/gospodarka/chinska-gospodarka-jest-w-tak-zlym-stanie-ze-przyznal-to-nawet-prezydent-xi-jinping/cs0ft1n](https://businessinsider.com.pl/gospodarka/chinska-gospodarka-jest-w-tak-zlym-stanie-ze-przyznal-to-nawet-prezydent-xi-jinping/cs0ft1n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T16:10:27+00:00

Chińska gospodarka złote czasy ma już za sobą. Co więcej, jest w tak złym stanie, że nawet prezydent Chin Xi Jinping przyznaje, że firmy przeżywają "ciężkie chwile". W orędziu noworocznym takiego narzekania nie było przez wiele lat.

## To będzie ciekawe starcie. Izrael odpowie przed MTS na zarzuty o dokonywanie ludobójstwa
 - [https://businessinsider.com.pl/wiadomosci/to-bedzie-ciekawe-starcie-izrael-odpowie-przed-mts-na-zarzuty-o-dokonywanie/qz0vn7p](https://businessinsider.com.pl/wiadomosci/to-bedzie-ciekawe-starcie-izrael-odpowie-przed-mts-na-zarzuty-o-dokonywanie/qz0vn7p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T15:55:00+00:00

Rząd Izraela zgodził się stanąć przed Międzynarodowym Trybunałem Sprawiedliwości w Hadze. To odpowiedź na oskarżenia ze strony władz Republiki Południowej Afryki o dokonywanie "ludobójstwa Palestyńczyków" w Palestynie.

## Chciał zamrozić raty kredytów. Teraz będzie nadzorował banki
 - [https://businessinsider.com.pl/gospodarka/nowy-czlowiek-rzadu-bedzie-nadzorowal-banki-chcial-zamrozic-raty-kredytow/9hvr453](https://businessinsider.com.pl/gospodarka/nowy-czlowiek-rzadu-bedzie-nadzorowal-banki-chcial-zamrozic-raty-kredytow/9hvr453)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T15:49:39+00:00

Kluczowy organ nadzoru nad rynkiem finansowym w Polsce nabiera nowych kadrowych kształtów. Do KNF trafił Marcin Wroński. Ekonomista zasłynął pomysłami na ulżenie kredytobiorcom, co wielu ekspertów ostro krytykowało.

## Odkryj Francję: Paryż, Burgundię, Prowansję, Bretanię i Normandię. Polecamy cztery wycieczki
 - [https://businessinsider.com.pl/lifestyle/podroze/odkryj-francje-paryz-burgundie-prowansje-bretanie-i-normandie-polecamy-cztery/zv8cgb8](https://businessinsider.com.pl/lifestyle/podroze/odkryj-francje-paryz-burgundie-prowansje-bretanie-i-normandie-polecamy-cztery/zv8cgb8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T15:00:00+00:00

Jeśli jesteś miłośnikiem architektury, spokojnych, sielankowych krajobrazów, wina i wyśmienitej kuchni, to urlop we Francji na pewno cię zachwyci. W artykule prezentujemy wycieczki po najpiękniejszych miastach i regionach Francji, przez Paryż, Burgundię, Prowansję i Normandię. Polecane rejsy prowadzone są najpiękniejszymi rzekami Francji i Europy — po Sekwanie, Mozeli i Renie. W artykule polecamy sprawdzone i docenione przez klientów wycieczki od biura podróży Albatros. Zapraszamy!

## Postanowienia noworoczne są trudne do utrzymania. Ułatw sobie zadanie z tymi narzędziami
 - [https://businessinsider.com.pl/technologie/nowe-technologie/postanowienia-noworoczne-sa-trudne-do-utrzymania-oto-jak-zbudowac-nowe-nawyki/9pmby1y](https://businessinsider.com.pl/technologie/nowe-technologie/postanowienia-noworoczne-sa-trudne-do-utrzymania-oto-jak-zbudowac-nowe-nawyki/9pmby1y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T14:46:34+00:00

Styczeń to dla wielu z nas czas wyznaczania noworocznych postanowień. Ruszymy do siłowni, zaczniemy częściej jeść brokuły czy brukselki, albo po imprezie sylwestrowej stwierdzimy, że już więcej nie sięgniemy po alkohol lub papierosa. Dotrzymanie postanowień to oczywiście duże wyzwanie, ale pomagają w tym wiedza i technologia. Przedstawiamy sposoby na utrzymanie nowych, zdrowszych nawyków, a także polecane narzędzia.

## Nowe świadczenie wypłacane przez ZUS. Uwaga na kolejność wniosków
 - [https://businessinsider.com.pl/poradnik-finansowy/nowe-swiadczenie-wyplacane-przez-zus-uwaga-na-kolejnosc-wnioskow/e5vrtmb](https://businessinsider.com.pl/poradnik-finansowy/nowe-swiadczenie-wyplacane-przez-zus-uwaga-na-kolejnosc-wnioskow/e5vrtmb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T14:28:58+00:00

Zakład Ubezpieczeń Społecznych przypomina, że od 1 stycznia 2024 r. można składać wnioski o nowe świadczenie. Zastrzega przy tym, że najpierw wojewódzkie zespoły ds. orzekania o niepełnosprawności muszą ustalić poziom potrzeby wsparcia. Z tego powodu wszystkie 150 złożonych dotychczas wniosków były niekompletne.

## Złoto na światowych rynkach najdroższe w historii. W Polsce niekoniecznie
 - [https://businessinsider.com.pl/gielda/wiadomosci/zloto-na-swiatowych-rynkach-najdrozsze-w-historii-w-polsce-niekoniecznie/kp1pvjf](https://businessinsider.com.pl/gielda/wiadomosci/zloto-na-swiatowych-rynkach-najdrozsze-w-historii-w-polsce-niekoniecznie/kp1pvjf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T14:25:45+00:00

Notowania złotego kruszcu znowu ustanowiły nowy rekord wszech czasów. Przynajmniej w dolarze amerykańskim, bo w polskiej walucie — ze względu na jej umocnienie w ubiegłym roku — rekordów nie ma.

## Detronizacja Tesli. Jest nowy lider rynku samochodów elektrycznych
 - [https://businessinsider.com.pl/technologie/motoryzacja/tesla-nie-jest-juz-numerem-jeden-to-nowy-lider-elektrykow/z8bz20p](https://businessinsider.com.pl/technologie/motoryzacja/tesla-nie-jest-juz-numerem-jeden-to-nowy-lider-elektrykow/z8bz20p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T14:21:12+00:00

Tesla straciła pozycję najpopularniejszego na świecie producenta pojazdów elektrycznych na rzecz chińskiego rywala BYD — informuje "Financial Times". Stało się to pomimo kwartalnej sprzedaży Tesli, która przekroczyła oczekiwania analityków.

## Rozpad Belgii? Czy państwo w środku Unii Europejskiej przestanie istnieć?
 - [https://businessinsider.com.pl/wiadomosci/upadek-belgii-czy-panstwo-w-srodku-unii-europejskiej-przestanie-istniec/e8refr5](https://businessinsider.com.pl/wiadomosci/upadek-belgii-czy-panstwo-w-srodku-unii-europejskiej-przestanie-istniec/e8refr5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T14:18:06+00:00

Plan, który jeszcze niedawno wydawał się czystą fantazją, już nią nie jest. Czy Belgii grozi rozpad? Taki scenariusz może zmaterializować się za kilka miesięcy.

## Kraków przed Warszawą pod względem podwyżek cen mieszkań. To był rollercoaster
 - [https://businessinsider.com.pl/nieruchomosci/ceny-mieszkan-w-2023-r-krakow-przed-warszawa-pod-wzgledem-podwyzek/224xqz7](https://businessinsider.com.pl/nieruchomosci/ceny-mieszkan-w-2023-r-krakow-przed-warszawa-pod-wzgledem-podwyzek/224xqz7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T14:17:21+00:00

Przez 11 miesięcy 2023 r. ceny nowych mieszkań wzrosły w Polsce przeciętnie o 13 proc. Dużo? Jest jedno miasto, gdzie skala podwyżek była dwukrotnie większa. I nie chodzi o stolicę. "Po tak znaczących wzrostach, jakie widzieliśmy w ostatnich miesiącach, spadek cen wydaje się naturalny" — sugerują eksperci.

## Mazda CX-5. Do zatłoczonego miasta i na trudniejsze drogi poza nim
 - [https://businessinsider.com.pl/technologie/motoryzacja/mazda-cx-5-jeszcze-atrakcyjniejsza/qbt740r](https://businessinsider.com.pl/technologie/motoryzacja/mazda-cx-5-jeszcze-atrakcyjniejsza/qbt740r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T13:50:00+00:00

Mazda CX-5 to modny SUV, który nadaje się do zatłoczonego miasta, a jednocześnie na węższe wyboiste drogi poza aglomeracjami. Ciekawe udogodnienia przekładają się na poczucie atrakcyjności, komfort i kontrolę nad autem.

## Wartość spółki spadła o 71 proc.  odkąd przejął ją Elon Musk
 - [https://businessinsider.com.pl/technologie/mija-rok-odkad-elon-musk-przejal-twittera-wartosc-portalu-spadla-o-71-proc/9e2jyzv](https://businessinsider.com.pl/technologie/mija-rok-odkad-elon-musk-przejal-twittera-wartosc-portalu-spadla-o-71-proc/9e2jyzv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T13:42:42+00:00

Według zarządzającej aktywami firmy Fidelity, X, czyli dawny Twitter, stracił na wartości ponad 71 proc., od czasu nabycia spółki przez Elona Muska w październiku 2022 r. Firma jest obecnie warta 71,5 proc. mniej niż w momencie zakupu przez Muska. Miliarder zapłacił 44 mld dol. za przejęcie platformy.

## AI zabiera zwierzętom w Hollywood pracę
 - [https://businessinsider.com.pl/technologie/ai-zabiera-zwierzetom-w-hollywood-prace/22qtj8h](https://businessinsider.com.pl/technologie/ai-zabiera-zwierzetom-w-hollywood-prace/22qtj8h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T13:26:14+00:00

Sztuczna inteligencja wkracza w wiele obszarów naszego życia, a w niektórych branżach powoduje obawę o utratę pracy. Takie obawy nie omijają Hollywood. Wszystko wskazuje, że pierwsi aktorzy, którzy stracą pracę na rzecz sztucznej inteligencji, mają cztery łapy.

## Ranking najpopularniejszych prostowników samochodowych
 - [https://businessinsider.com.pl/technologie/ranking-najpopularniejszych-prostownikow-samochodowych/0h0252g](https://businessinsider.com.pl/technologie/ranking-najpopularniejszych-prostownikow-samochodowych/0h0252g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T13:09:40+00:00

Prostowniki cieszą się ogromną popularnością szczególnie w miesiącach zimowych. Warto mieć go w pobliżu i regularnie używać np. raz w roku, by uniknąć przykrej niespodzianki, gdy okaże się, że akumulator jest już całkowicie rozładowany.

## Tragedia na pokładzie samolotu TUI. U Brytyjki doszło do zatrzymania akcji serca
 - [https://businessinsider.com.pl/wiadomosci/tragedia-na-pokladzie-samolotu-tui-u-brytyjki-doszlo-do-zatrzymania-akcji-serca/kttgq38](https://businessinsider.com.pl/wiadomosci/tragedia-na-pokladzie-samolotu-tui-u-brytyjki-doszlo-do-zatrzymania-akcji-serca/kttgq38)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T12:53:02+00:00

Do dramatycznej i tragicznej w skutkach sytuacji doszło na pokładzie jednego z samolotów lecących z Teneryfy do Glasgow. Maszyna musiała lądować kilkanaście minut po starcie, jako że u jednej z pasażerek doszło do zatrzymania akcji serca. Mimo usilnych prób służb życia pasażerki nie udało się uratować.

## Tragedia na pokładzie samolotu. U pasażerki doszło do zatrzymania akcji serca
 - [https://businessinsider.com.pl/wiadomosci/tragedia-na-pokladzie-samolotu-u-pasazerki-doszlo-do-zatrzymania-akcji-serca/kttgq38](https://businessinsider.com.pl/wiadomosci/tragedia-na-pokladzie-samolotu-u-pasazerki-doszlo-do-zatrzymania-akcji-serca/kttgq38)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T12:53:02+00:00

Do dramatycznej i tragicznej w skutkach sytuacji doszło na pokładzie jednego z samolotów. Maszyna musiała lądować kilkanaście minut po starcie, jako że u jednej z pasażerek doszło do zatrzymania akcji serca. Mimo usilnych prób służb życia pasażerki nie udało się uratować.

## Wchodzi w życie podatek dla gigantów. "Historyczna reforma w Europie"
 - [https://businessinsider.com.pl/biznes/wchodzi-w-zycie-podatek-dla-gigantow-historyczna-reforma-w-europie/mbsrh9d](https://businessinsider.com.pl/biznes/wchodzi-w-zycie-podatek-dla-gigantow-historyczna-reforma-w-europie/mbsrh9d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T12:42:31+00:00

Od nowego roku w Unii Europejskiej weszły w życie nowe przepisy wprowadzające minimalną stawkę w wysokości 15 proc. efektywnego opodatkowania wielonarodowych przedsiębiorstw prowadzących działalność w państwach członkowskich i uzyskujących ponad 750 mln euro przychodów rocznie.

## Matka Lichockiej odwołana z Instytutu De Republica. Instytucja dysponuje milionami
 - [https://businessinsider.com.pl/wiadomosci/instytut-de-republica-wydawal-miliony-i-zarabial-tysiace-co-o-nim-wiemy/0xd91qp](https://businessinsider.com.pl/wiadomosci/instytut-de-republica-wydawal-miliony-i-zarabial-tysiace-co-o-nim-wiemy/0xd91qp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T12:31:50+00:00

Za czasów PiS powstało wiele instytutów, które bez państwowej kroplówki nie mogłoby funkcjonować. Do nich należy Instytut De Republica, z którego rady została odwołana m.in. matka posłanki PiS Joanny Lichockiej. Planowane wydatki budżetu państwa na 2023 r. na ten instytut wynosiły 19 mln zł przy spodziewanych dochodach na poziomie ułamka procenta tej kwoty.

## Gigantyczna wygrana mieszkańca Michigan na loterii
 - [https://businessinsider.com.pl/wiadomosci/gigantyczna-wygrana-mieszkanca-michigan-na-loterii-zdobyl-ponad-800-mln-dol/l1mt92y](https://businessinsider.com.pl/wiadomosci/gigantyczna-wygrana-mieszkanca-michigan-na-loterii-zdobyl-ponad-800-mln-dol/l1mt92y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T12:31:41+00:00

Los loterii Powerball kupiony w amerykańskim stanie Michigan w poniedziałek przyniósł szczęśliwemu nabywcy główną wygraną wynosząca 842,5 mln dol.

## Wystrzał cen mieszkań. Eksperci wskazują na źródła problemu
 - [https://businessinsider.com.pl/biznes/wystrzal-cen-mieszkan-eksperci-wskazuja-na-zrodla-problemu/5wccj5s](https://businessinsider.com.pl/biznes/wystrzal-cen-mieszkan-eksperci-wskazuja-na-zrodla-problemu/5wccj5s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T12:01:41+00:00

Program Bezpieczny kredyt nie tylko pomógł klientom uzyskać subsydiowaną przez państwo tanią hipotekę. Ma też bardziej ponure skutki: skokowy wzrost cen mieszkań. Pogorszyła się też dostępność, szczególnie lokali kwalifikujących się do programu. Do wzrostu cen przyczyniła się także ograniczona aktywność deweloperów i podaż mieszkań.

## Cztery powody, dla których napoje energetyzujące są szkodliwe. Są zdrowsze sposoby na dodanie sobie energii
 - [https://businessinsider.com.pl/rozwoj-osobisty/zdrowie/cztery-powody-dla-ktorych-napoje-energetyzujace-sa-szkodliwe-sa-zdrowsze-sposoby-na/yf4nqz0](https://businessinsider.com.pl/rozwoj-osobisty/zdrowie/cztery-powody-dla-ktorych-napoje-energetyzujace-sa-szkodliwe-sa-zdrowsze-sposoby-na/yf4nqz0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T11:43:49+00:00

Napoje energetyczne w założeniu mają poprawiać koncentrację i zwiększać skupienie, ale zawarte w nich składniki mogą mieć negatywny wpływ na zdrowie. Oto co należy wiedzieć o napojach energetycznych i ich wpływie na zdrowie.

## Poznaj sekret włoskiego dolce vita, spróbuj win w lokalnych winiarniach — wycieczki do czarującej Wenecji
 - [https://businessinsider.com.pl/lifestyle/podroze/poznaj-sekret-wloskiego-dolce-vita-sprobuj-win-w-lokalnych-winiarniach-wycieczki-do/f1d4es9](https://businessinsider.com.pl/lifestyle/podroze/poznaj-sekret-wloskiego-dolce-vita-sprobuj-win-w-lokalnych-winiarniach-wycieczki-do/f1d4es9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T11:35:58+00:00

Wenecja, słynne miasto na wodzie zna każdy. Pierwsze skojarzenie z nim to gondole i kanały pełne wody. Miasto to kryje w sobie jednak wiele więcej urokliwych zakątków, romantycznych scenerii, pięknych budowli, kawiarenek, restauracji i winiarni. Tutaj smaki, zapachy i widoki cię oczarują! Wybraliśmy 3 wycieczki, które pozwolą odkryć sekret włoskiego dolce vita i zasmakować win w lokalnych winiarniach. Sprawdź!

## Poznaj sekret włoskiego dolce vita, wybierz się w podróż do czarującej Wenecji
 - [https://businessinsider.com.pl/lifestyle/podroze/poznaj-sekret-wloskiego-dolce-vita-wycieczki-do-czarujacej-wenecji/f1d4es9](https://businessinsider.com.pl/lifestyle/podroze/poznaj-sekret-wloskiego-dolce-vita-wycieczki-do-czarujacej-wenecji/f1d4es9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T11:35:58+00:00

Wenecja, słynne miasto na wodzie zna każdy. Pierwsze skojarzenie z nim to gondole i kanały pełne wody. Miasto to kryje w sobie jednak wiele więcej urokliwych zakątków, romantycznych scenerii, pięknych budowli, kawiarenek, restauracji i winiarni. Tutaj smaki, zapachy i widoki cię oczarują! Wybraliśmy 3 wycieczki, które pozwolą odkryć sekret włoskiego dolce vita. Sprawdź!

## Nowy model oszustwa przez WhatsAppa: "na ofertę pracy"
 - [https://businessinsider.com.pl/praca/nowy-model-oszustwa-przez-whatsappa-na-oferte-pracy/bvry2jj](https://businessinsider.com.pl/praca/nowy-model-oszustwa-przez-whatsappa-na-oferte-pracy/bvry2jj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T11:30:12+00:00

Od pewnego czasu użytkownicy aplikacji WhatsApp dostają zastanawiające oferty pracy. Propozycja wygląda na bardzo atrakcyjną, ale w rzeczywistości jest oszustwem, na które może dać się złapać niejedna osoba, która poszukuje nowego zatrudnienia.

## Kurs złotego oszalał. Wiemy, co było przyczyną
 - [https://businessinsider.com.pl/finanse/kurs-zlotego-oszalal-wiemy-co-bylo-przyczyna/bcxn55k](https://businessinsider.com.pl/finanse/kurs-zlotego-oszalal-wiemy-co-bylo-przyczyna/bcxn55k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T11:15:00+00:00

W pierwszy dzień roku Google pokazywał, że za euro trzeba zapłacić ponad 5 zł. Zareagować musiał sam minister finansów. Jak nieoficjalnie dowiaduje się Business Insider Polska, przyczyną zamieszania był błąd dostawcy danych, czyli źródła, z którego wyszukiwarka zaciąga kursy.

## 300 tys. okupu za syna. Chłopak przebywał w namiocie poza miastem. "Cyberporwanie" to kolejny trik oszustów
 - [https://businessinsider.com.pl/wiadomosci/300-tys-okupu-za-syna-chlopak-przebywal-w-namiocie-poza-miastem-cyberporwanie-to/wf67ew4](https://businessinsider.com.pl/wiadomosci/300-tys-okupu-za-syna-chlopak-przebywal-w-namiocie-poza-miastem-cyberporwanie-to/wf67ew4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T11:13:23+00:00

Para zapłaciła 80 tys. dol. (ponad 300 tys. zł) po tym, jak dowiedziała się, że ich nastoletni syn został porwany. Według policji znaleziono go w namiocie poza Salt Lake City. "Cyberporwanie" to kolejny trik oszustów.

## Pokaz fajerwerków w Dolinie Pięciu Stawów. 5 tys. za imię i nazwisko osoby odpowiedzialnej
 - [https://businessinsider.com.pl/wiadomosci/pokaz-fajerwerkow-w-dolinie-pieciu-stawow-skandal-i-nagroda/ktysq9h](https://businessinsider.com.pl/wiadomosci/pokaz-fajerwerkow-w-dolinie-pieciu-stawow-skandal-i-nagroda/ktysq9h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T10:49:40+00:00

W internecie zostało opublikowane nagranie, na którym widać nielegalny pokaz fajerwerków w Dolinie Pięciu Stawów. Materiał zaszokował wielu internautów i szereg organizacji górskich. Sprawa stała się głośna, a anonimowa osoba zaoferowała wysoką nagrodę pieniężną za wskazanie organizatora nielegalnego pokazu fajerwerków w Tatrach.

## Myśliwce wróciły do bazy. "Zmniejszenie poziomu zagrożenia"
 - [https://businessinsider.com.pl/wiadomosci/mysliwce-wrocily-do-bazy-zmniejszenie-poziomu-zagrozenia/n3vx1ml](https://businessinsider.com.pl/wiadomosci/mysliwce-wrocily-do-bazy-zmniejszenie-poziomu-zagrozenia/n3vx1ml)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T10:41:49+00:00

Ze względu na zmniejszenie poziomu zagrożenia, operowanie par dyżurnych polskiego i sojuszniczego lotnictwa w naszej przestrzeni powietrznej zostało zakończone — poinformowało Dowództwo Operacyjne Rodzajów Sił Zbrojnych (DORSZ).

## Ministerstwo Finansów chce wyjaśnień od Google
 - [https://businessinsider.com.pl/finanse/ministerstwo-finansow-chce-wyjasnien-od-google/s4h5mjm](https://businessinsider.com.pl/finanse/ministerstwo-finansow-chce-wyjasnien-od-google/s4h5mjm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T10:23:47+00:00

Ministerstwo Finansów wezwie amerykański koncern Google do złożenia wyjaśnień w sprawie fałszywego podawania kursów walut — informuje RMF FM. Możliwych powodów jest kilka.

## Energetyki tylko na dowód. To może uszczuplić rynek warty miliardy złotych
 - [https://businessinsider.com.pl/biznes/energetyki-tylko-na-dowod-to-moze-uszczuplic-rynek-warty-miliardy-zlotych/4s9vprz](https://businessinsider.com.pl/biznes/energetyki-tylko-na-dowod-to-moze-uszczuplic-rynek-warty-miliardy-zlotych/4s9vprz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T10:22:57+00:00

Od początku 2024 roku zakup napojów energetycznych jest mocno utrudniony. Aby kupić energetyki, trzeba być pełnoletnim. To może być cios w branżę, której roczna sprzedaż liczona jest w miliardach złotych.

## Tusk robi porządki w państwowym banku. Odwołał dwie osoby z rady nadzorczej
 - [https://businessinsider.com.pl/wiadomosci/tusk-robi-porzadki-w-panstwowym-banku-odwolal-dwie-osoby-z-rady-nadzorczej/ez203pc](https://businessinsider.com.pl/wiadomosci/tusk-robi-porzadki-w-panstwowym-banku-odwolal-dwie-osoby-z-rady-nadzorczej/ez203pc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T10:22:17+00:00

W nowy rok wchodzimy z pierwszymi błyskawicznymi zmianami w państwowych instytucjach. Ruszyła karuzela kadrowa w Banku Gospodarstwa Krajowego.

## Tusk robi porządki w państwowym banku. Odwołał dwie osoby z rady nadzorczej
 - [https://businessinsider.com.pl/wiadomosci/donald-tusk-robi-porzadki-w-panstwowym-banku-odwolal-dwie-osoby/ez203pc](https://businessinsider.com.pl/wiadomosci/donald-tusk-robi-porzadki-w-panstwowym-banku-odwolal-dwie-osoby/ez203pc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T10:22:17+00:00

W nowy rok wchodzimy z pierwszymi błyskawicznymi zmianami w państwowych instytucjach. Ruszyła karuzela kadrowa w Banku Gospodarstwa Krajowego. Z radą nadzorczą pożegnały się dwie osoby powołane niecały rok temu przez Mateusza Morawieckiego.

## Polski milioner sprzedaje znaną sieć sklepów
 - [https://businessinsider.com.pl/gielda/polski-milioner-sprzedaje-znana-siec-sklepow-co-dalej-z-marka/7qksx9p](https://businessinsider.com.pl/gielda/polski-milioner-sprzedaje-znana-siec-sklepow-co-dalej-z-marka/7qksx9p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T10:20:23+00:00

Popularna sieć odzieżowa Top Secret zmienia właściciela. Do tej pory należała do spółki Redan, kontrolowanej przez Radosława Wiśniewskiego, prywatnie ojca Aleksandry Wiśniewskiej, posłanki KO.

## Uczennica dostała uwagę, bo nie dała 10 zł na Szlachetną Paczkę. Ministra Nowacka reaguje
 - [https://businessinsider.com.pl/wiadomosci/uczennica-dostala-uwage-bo-nie-wplacila-10-zl-ministra-nowacka-reaguje/qbdmwxc](https://businessinsider.com.pl/wiadomosci/uczennica-dostala-uwage-bo-nie-wplacila-10-zl-ministra-nowacka-reaguje/qbdmwxc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T10:11:20+00:00

Ministra edukacji publicznie interweniowała w sprawie uczennicy, która dostała uwagę za to, że nie miała 10 zł. Te pieniądze miały wesprzeć Szlachetną Paczkę, ale uczennica miała bardzo trudną sytuację materialną. Barbara Nowacka oburzyła się zachowaniem nauczycielki, a reakcja szefowej resortu wywołała dużo kontrowersji.

## Skarbówka zajęła 20 mln za niezapłacone abonamenty rtv
 - [https://businessinsider.com.pl/media/skarbowka-zajela-20-mln-za-niezaplacone-abonamenty-rtv/gh4tnxd](https://businessinsider.com.pl/media/skarbowka-zajela-20-mln-za-niezaplacone-abonamenty-rtv/gh4tnxd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T10:07:54+00:00

Od stycznia do listopada 2023 r. Urzędy Skarbowe w całej Polsce wyegzekwowały 20,03 mln zł nieuregulowanego abonamentu radiowo-telewizyjnego — informują Wirtualnemedia.pl.

## Przemysłowa stagnacja w strefie euro. W Polsce nieprzyjemna niespodzianka
 - [https://businessinsider.com.pl/gospodarka/przemyslowa-stagnacja-w-strefie-euro-w-polsce-nieprzyjemna-niespodzianka/5sdqyd3](https://businessinsider.com.pl/gospodarka/przemyslowa-stagnacja-w-strefie-euro-w-polsce-nieprzyjemna-niespodzianka/5sdqyd3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T09:57:24+00:00

Najnowsze odczyty indeksów PMI nie wskazują, aby sektor przemysłowy strefy euro był na drodze do wyczekiwanego wygrzebania się z recesji. Nadal kiepsko wypadły Niemcy i Francja, największe gospodarki unii walutowej.

## Wymarzone zmiany w kodeksie pracy? Prof. Gładoch studzi entuzjazm
 - [https://businessinsider.com.pl/prawo/praca/wymarzone-zmiany-w-kodeksie-pracy-prof-gladoch-studzi-entuzjazm/qj7kpnk](https://businessinsider.com.pl/prawo/praca/wymarzone-zmiany-w-kodeksie-pracy-prof-gladoch-studzi-entuzjazm/qj7kpnk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T09:56:28+00:00

Mijający rok był rekordowy pod względem zmian w kodeksie pracy. Uregulowano m.in. pracę zdalną i badanie trzeźwości pracowników, wprowadzono lepszą ochronę przed zwolnieniem. Te na pozór bardzo korzystne rozwiązania mają drugie dno. — Wnikliwa analiza nowych przepisów studzi entuzjazm. Nie wszystkie zmiany zostały wdrożone zgodnie z założeniem — podkreśla prof. Monika Gładoch.

## Japonia: pożar samolotu na pasie startowym. Kilkaset osób na pokładzie
 - [https://businessinsider.com.pl/wiadomosci/japonia-pozar-samolotu-na-pasie-startowym-kilkaset-osob-na-pokladzie/l4z015l](https://businessinsider.com.pl/wiadomosci/japonia-pozar-samolotu-na-pasie-startowym-kilkaset-osob-na-pokladzie/l4z015l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T09:50:07+00:00

W samolocie na pasie startowym lotniska Haneda w Tokio wybuchł pożar — podała Sky News, powołując się na nagrania lokalnych mediów.

## Rynek kredytów hipotecznych w 2023[EBOOK BUSINESS INSIDER I LENDI]
 - [https://businessinsider.com.pl/poradnik-finansowy/kredyty/rynek-kredytow-hipotecznych-w-2023ebook-business-insider-i-lendi/dkjbxb7](https://businessinsider.com.pl/poradnik-finansowy/kredyty/rynek-kredytow-hipotecznych-w-2023ebook-business-insider-i-lendi/dkjbxb7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T09:19:32+00:00

Ostatnie dwa lata przyniosły wielkie zmiany na rynku kredytów mieszkaniowych. Najpierw doszło do mocnego hamowania z rekordowego tempa, a później mozolne odbicie, które napędzone dodatkowo programem Bezpieczny kredyt 2 proc. doprowadziło rynek do nowych rekordów. Rok 2024 zapowiada się emocjonująco. Przedstawiamy ebook "Rynek kredytów hipotecznych w 2023."

## Polska traci miliardy na pozostawaniu poza strefą euro. Ekonomiści szacują
 - [https://businessinsider.com.pl/gospodarka/polska-traci-miliardy-na-pozostawaniu-poza-strefa-euro-ekonomisci-szacuja/6gmjc2y](https://businessinsider.com.pl/gospodarka/polska-traci-miliardy-na-pozostawaniu-poza-strefa-euro-ekonomisci-szacuja/6gmjc2y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T09:09:24+00:00

Brak euro w Polsce przynosi straty. Przystąpienie do tej unii walutowej wpłynęłoby pozytywnie na naszą gospodarkę - oceniają ekonomiści. Stracone możliwości wzrostu związane z brakiem euro w Polsce wedle różnych wyliczeń wahają się od 2,5 do 7,5 proc. PKB.

## 1000 zł więcej za m kw., a mieszkań coraz mniej. Oto dane z rynku
 - [https://businessinsider.com.pl/poradnik-finansowy/kredyty/wzrost-cen-mieszkan-przyspieszyl-1000-zl-wiecej-za-m-kw/8rjr6cv](https://businessinsider.com.pl/poradnik-finansowy/kredyty/wzrost-cen-mieszkan-przyspieszyl-1000-zl-wiecej-za-m-kw/8rjr6cv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T09:00:00+00:00

W 2023 r. na rynku pierwotnym i wtórnym średnie ceny nowych ofert wzrosły o ponad 1000 zł za m kw. w skali kraju. Jednocześnie w tym roku do użytku oddano znacznie mniej mieszkań — wynika z analizy Polskiego Instytutu Ekonomicznego.

## Jak zmieniały się ceny metrów na rynku wtórnym? "Rok niespotykanych wzrostów"
 - [https://businessinsider.com.pl/poradnik-finansowy/kredyty/tak-wygladaly-ceny-mieszkan-na-rynku-wtornym-od-lat-widac-wzrost/0275l53](https://businessinsider.com.pl/poradnik-finansowy/kredyty/tak-wygladaly-ceny-mieszkan-na-rynku-wtornym-od-lat-widac-wzrost/0275l53)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T09:00:00+00:00

Ostatnie lata na rynku nieruchomości upłynęły pod znakiem wzrostu cen za m kw. Jak pokazują dane z 2023 r., w niektórych miastach w ciągu kilku lat ceny mieszkań poszły w górę nawet o 31 proc. Gdzie wzrosły najbardziej?

## Zakup pierwszego mieszkania. Rząd kończy program "Bezpieczny kredyt 2 proc."
 - [https://businessinsider.com.pl/poradnik-finansowy/kredyty/rzad-konczy-program-bezpieczny-kredyt-2-proc/rtxsp0p](https://businessinsider.com.pl/poradnik-finansowy/kredyty/rzad-konczy-program-bezpieczny-kredyt-2-proc/rtxsp0p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T09:00:00+00:00

"Bezpieczny kredyt 2 proc." w obecnej formule zostanie zastąpiony inną, korzystną dla kredytobiorców ofertą – informuje Ministerstwo Rozwoju i Technologii. Pomoc państwa ma być "precyzyjne adresowana", a resort chce ograniczyć nadużywanie nowego instrumentu przez osoby o wyższych dochodach.

## Gorąco na Morzu Czerwonym, ropa mocno drożeje
 - [https://businessinsider.com.pl/gielda/wiadomosci/goraco-na-morzu-czerwonym-ropa-mocno-drozeje/mr29v1j](https://businessinsider.com.pl/gielda/wiadomosci/goraco-na-morzu-czerwonym-ropa-mocno-drozeje/mr29v1j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T08:56:19+00:00

Ceny ropy na giełdzie paliw w Nowym Jorku mocno rosną w reakcji na wysłanie przez Iran statku wojennego na Morze Czerwone — podają maklerzy.

## Kierowca z Niemiec wjechał na szlak parku narodowego w Karkonoszach i zawisł nad rowem. Zaufał nawigacji
 - [https://businessinsider.com.pl/wiadomosci/kierowca-z-niemiec-zaufal-nawigacji-i-wjechal-na-szlak-parku-narodowego/nqwj2mg](https://businessinsider.com.pl/wiadomosci/kierowca-z-niemiec-zaufal-nawigacji-i-wjechal-na-szlak-parku-narodowego/nqwj2mg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T08:40:16+00:00

Zgubne może być całkowite zawierzenie nawigacji samochodowej. Bardzo boleśnie przekonał się o tym pewien kierowca z Niemiec, który wjechał autem do parku narodowego i utknął na szlaku. Za swoją lekkomyślność dostał jeszcze mandat i musiał ponieść koszty podstawienia lawety.

## Tym razem rozczarowanie. Gorsza końcówka roku dla polskiego przemysłu
 - [https://businessinsider.com.pl/gospodarka/tym-razem-rozczarowanie-gorsza-koncowka-roku-dla-polskiego-przemyslu/hdesb64](https://businessinsider.com.pl/gospodarka/tym-razem-rozczarowanie-gorsza-koncowka-roku-dla-polskiego-przemyslu/hdesb64)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T08:39:57+00:00

O ile listopadowe odczyty wskaźnika PMI dla polskiego przemysłu okazały się nadzwyczaj wysokie i sugerowały tak wyczekiwane odbicie tej ważnej gałęzi gospodarki, to grudzień przyniósł spadek i wyniki słabsze od prognoz. Kiepsko wypadły dane dotyczące nowych zamówień eksportowych, co jest wynikiem słabości gospodarki strefy euro. To kolejne rozczarowujące dane z polskiego przemysłu w ostatnich dniach.

## F-16 poderwane. Każda godzina lotu to mała fortuna
 - [https://businessinsider.com.pl/wiadomosci/f-16-poderwane-kazda-godzina-lotu-to-mala-fortuna/3rnqxwe](https://businessinsider.com.pl/wiadomosci/f-16-poderwane-kazda-godzina-lotu-to-mala-fortuna/3rnqxwe)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T08:21:47+00:00

Trwa kolejny już zmasowany atak rakietowy na Ukrainę. Polska była zmuszona poderwać dwie pary myśliwców F-16. Sprawdzamy, ile kosztuje każdy taki lot.

## Polska marka odzieżowa idzie pod młotek. Drugie podejście do sprzedaży
 - [https://businessinsider.com.pl/gielda/wiadomosci/polska-marka-odziezowa-idzie-pod-mlotek-kolejna-proba-sprzedazy/m7ncelb](https://businessinsider.com.pl/gielda/wiadomosci/polska-marka-odziezowa-idzie-pod-mlotek-kolejna-proba-sprzedazy/m7ncelb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T08:08:27+00:00

Łódzka grupa odzieżowa Redan podpisała z krakowską spółką Greenpoint warunkową umowę sprzedaży praw do znaków towarowych Top Secret i DryWash i umowę licencyjną — poinformowała giełdowa firma w raporcie bieżącym.

## Kurs USD/PLN 2 stycznia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-2-stycznia-2024-r/f84cpl6](https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-2-stycznia-2024-r/f84cpl6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:32:53+00:00

Zobacz aktualne notowania waluty USD oraz zmiany kursu w odniesieniu tygodniowym oraz dzień po dniu na 2 stycznia 2024. Pokazujemy, jak zmienia się kurs amerykańskiej waluty w stosunku do polskiej złotówki. Czy PLN umacnia się czy słabnie? Wczoraj kurs USD wynosił 5,29535 zł.

## Kurs GBP/PLN 2 stycznia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-2-stycznia-2024-r/h78r5g9](https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-2-stycznia-2024-r/h78r5g9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:32:11+00:00

W tym artykule znajduje się bieżący kurs funta brytyjskiego na dzień 2 stycznia 2024. To może zainteresować osoby pracujące na co dzień w Wielkiej Brytanii. Czy kurs waluty jest dynamiczny? Wczorajszy 5,0073 zł, jak zmienił się dziś? Sprawdzisz poniżej.

## Kurs CHF/PLN 2 stycznia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-2-stycznia-2024-r/byspy1n](https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-2-stycznia-2024-r/byspy1n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:31:23+00:00

Poznaj bieżący kurs franka szwajcarskiego na dzień 2 stycznia 2024. CHF to waluta, która przede wszystkim interesuje osoby mające kredyt we frankach. Czy polska waluta wzmocniła się, czy osłabła? Wczoraj kurs szwajcarskiej waluty wynosił 6,304 zł. Jak wygląda dzisiejszy  kurs CHF/PLN, sprawdzisz w tym artykule.

## Kurs CZK/PLN 2 stycznia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-czkpln-2-stycznia-2024-r/kybhece](https://businessinsider.com.pl/gielda/kursy-walut/kurs-czkpln-2-stycznia-2024-r/kybhece)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:30:45+00:00

Zgodnie ze standardem ISO 4217, korona czeska jest oznaczona międzynarodowym symbolem CZK. W Czechach, jej ojczyźnie, powszechnie używany jest również skrót Kč, pochodzący od słów "koruna česká". Niektórzy Czesi wciąż pamiętają "h", odnoszące się do halerza, który stanowi setną część korony, jednak halerz nie funkcjonuje już w codziennym użytku. W tym momencie najmniejszą częścią waluty naszych południowych sąsiadów jest „korona”. Waluta ta obowiązuje od lat 90. XX wieku.

## Kurs SEK/PLN 2 stycznia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-sekpln-2-stycznia-2024-r/hhez42m](https://businessinsider.com.pl/gielda/kursy-walut/kurs-sekpln-2-stycznia-2024-r/hhez42m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:29:23+00:00

Przedstawiamy bieżące notowania kursu waluty SEK oraz zmiany w ujęciu tygodniowym i dzień po dniu na 2 stycznia 2024. Pokazujemy, jak zmienia się kurs korony szwedzkiej w stosunku do polskiego złotego. Czy nasza waluta obecnie traci? Wczoraj kurs SEK wynosił: 0,3907 zł.

## Kurs DKK/PLN 2 stycznia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dkkpln-2-stycznia-2024-r/8q16dzc](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dkkpln-2-stycznia-2024-r/8q16dzc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:28:00+00:00

Jeśli potrzebujesz informacji o kursie korony duńskiej, przedstawiamy bieżące notowania. Wczorajszy kurs wynosił 0,78475 zł. Zobacz, jak sytuacja kształtuje się dziś: 2 stycznia 2024.

## Kurs HUF/PLN 2 stycznia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-hufpln-2-stycznia-2024-r/hg6mn8l](https://businessinsider.com.pl/gielda/kursy-walut/kurs-hufpln-2-stycznia-2024-r/hg6mn8l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:27:26+00:00

Poznaj zmiany kursu HUF/PLN 2 stycznia 2024 r. Jak dziś wygląda siła węgierskiej waluty względem złotego? Czy jadąc np. na urlop na Węgry, opłaca się dziś wymienić pieniądze? Bieżący kurs forinta sprawdzisz w tym artykule.

## Energetyki jak alkohol. By kupić, trzeba być pełnoletnim
 - [https://businessinsider.com.pl/prawo/sprzedaz-energetykow-tylko-dla-doroslych-sklepy-musza-uwazac/eekrx57](https://businessinsider.com.pl/prawo/sprzedaz-energetykow-tylko-dla-doroslych-sklepy-musza-uwazac/eekrx57)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:24:17+00:00

Od 1 stycznia obowiązuje zakaz sprzedaży energetyków, czyli napojów z dodatkiem tauryny i kofeiny, osobom poniżej 18. roku życia. Sprzedawcy powinni żądać okazania dowodu osobistego oraz potwierdza ich zakup w kasach samoobsługowych. Za nieprzestrzeganie przepisów grożą wysokie kary.

## Polacy rzucili się na podróże. Prezes TUI Poland: w rok zarobiliśmy za dwa-trzy lata
 - [https://businessinsider.com.pl/wiadomosci/wakacje-2024-polacy-rzucili-sie-na-podroze-najwieksze-biuro-podrozy-w-rok-zarobilo-za/c7cnm94](https://businessinsider.com.pl/wiadomosci/wakacje-2024-polacy-rzucili-sie-na-podroze-najwieksze-biuro-podrozy-w-rok-zarobilo-za/c7cnm94)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:22:00+00:00

Mamy do czynienia z boomem na podróżowanie. Popyt jest ogromny, większy niż się spodziewaliśmy— przyznaje Marcin Dymnicki, prezes TUI Poland. Prezes największego biura podroży w Polsce w analizie dla Business Insider Polska przyznaje, że touroperator ma za sobą najlepszy rok w historii — w rok zarobił za dwa-trzy lata.

## Poderwano myśliwce F-16. Dowództwo Operacyjne alarmuje
 - [https://businessinsider.com.pl/wiadomosci/poderwano-mysliwce-f-16-dowodztwo-operacyjne-alarmuje/9bnkzdg](https://businessinsider.com.pl/wiadomosci/poderwano-mysliwce-f-16-dowodztwo-operacyjne-alarmuje/9bnkzdg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:12:11+00:00

Informujemy, że obserwowana jest intensywna aktywność lotnictwa dalekiego zasięgu Federacji Rosyjskiej, która związana jest z wykonywaniem uderzeń na terytorium Ukrainy — poinformowało Dowództwo Operacyjne Rodzajów Sił Zbrojnych (DORSZ) na platformie X.

## Właścicieli aut czekają nowe podatki? Ekspert wyjaśnia
 - [https://businessinsider.com.pl/poradnik-finansowy/wlascicieli-aut-czekaja-nowe-podatki-ekspert-wyjasnia/2k8fn5j](https://businessinsider.com.pl/poradnik-finansowy/wlascicieli-aut-czekaja-nowe-podatki-ekspert-wyjasnia/2k8fn5j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T07:08:06+00:00

Wraz z Krajowym Planem Odbudowy pojawią się nowe podatki dla właścicieli samochodów — ostrzega Jakub Faryś, prezes Polskiego Związku Przemysłu Motoryzacyjnego, w rozmowie z portalem wnp.pl.

## Był twarzą TVP, dziś przyznaje: nie zawsze pracowałem w zgodzie z sumieniem
 - [https://businessinsider.com.pl/media/bartlomiej-graczak-byl-twarza-tvp-dzis-przyznaje-nie-zawsze-pracowalem-w-zgodzie-z/zwtdwz6](https://businessinsider.com.pl/media/bartlomiej-graczak-byl-twarza-tvp-dzis-przyznaje-nie-zawsze-pracowalem-w-zgodzie-z/zwtdwz6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T06:44:05+00:00

Jeszcze do niedawna pracował w TVP, teraz tłumaczy dlaczego. — Nie zawsze pracowałem w zgodzie z własnym sumieniem, ale wiedziałem, że jak odejdę nic się nie zmieni — tłumaczy Bartłomiej Graczak.

## Wzrost płacy minimalnej. Oto jak wpłynie na kondycję firm
 - [https://businessinsider.com.pl/gospodarka/wzrost-placy-minimalnej-oto-jak-wplynie-na-kondycje-firm/6crv0e0](https://businessinsider.com.pl/gospodarka/wzrost-placy-minimalnej-oto-jak-wplynie-na-kondycje-firm/6crv0e0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T06:23:33+00:00

Kolejny rok dwucyfrowych podwyżek najniższego wynagrodzenia to wyzwanie dla wielu firm i branż, w tym szczególnie dla sektora małych i średnich przedsiębiorstw oraz małych rynków pracy — czytamy we wtorkowej Rzeczpospolitej.

## Kurs EUR/PLN 2 stycznia 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-2-stycznia-2024-r/csc4l10](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-2-stycznia-2024-r/csc4l10)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T06:18:22+00:00

Oto bieżący kurs waluty euro na dzień 2 stycznia 2024. Euro to obecnie najważniejsza waluta w Unii Europejskiej, a od kursu euro uzależniona jest cena wielu importowanych i eksportowanych towarów i produktów. Jak wyglądają jej aktualne notowania oraz ile wynosi wartość względem złotówki? Wczoraj kurs euro wynosił: 5,8486 zł.

## Zmiany w Trybunale Konstytucyjnym. Jest głos ministra sprawiedliwości
 - [https://businessinsider.com.pl/wiadomosci/zmiany-w-trybunale-konstytucyjnym-jest-glos-ministra-sprawiedliwosci/kbw9tnr](https://businessinsider.com.pl/wiadomosci/zmiany-w-trybunale-konstytucyjnym-jest-glos-ministra-sprawiedliwosci/kbw9tnr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T06:05:09+00:00

Minister sprawiedliwości Adam Bodnar zapytany o zmiany w Trybunale Konstytucyjnym powiedział we wtorkowym tygodniku Newsweek, że uważa, że uchwała w tej sprawie jest niewystarczająca.

## Odkryj zimowe piękno Mierzei Wiślanej. Wypocznij w luksusowym hotelu
 - [https://businessinsider.com.pl/lifestyle/podroze/odkryj-zimowe-piekno-mierzei-wislanej-wypocznij-w-luksusowym-hotelu/zcxx7j6](https://businessinsider.com.pl/lifestyle/podroze/odkryj-zimowe-piekno-mierzei-wislanej-wypocznij-w-luksusowym-hotelu/zcxx7j6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T06:00:00+00:00

W zimowej scenerii Mierzei Wiślanej, gdzie chłodne fale Bałtyku spotykają się z malowniczymi krajobrazami, czeka na gości luksusowy Tristan Hotel &amp; Spa****. Położony w urokliwych Kątach Rybackich, ten czterogwiazdkowy hotel stanowi idealne miejsce na zimowe ferie, łącząc komfortowe zakwaterowanie z bogatą ofertą atrakcji. Co więcej? Tristan Hotel &amp; Spa**** wraz z serwisem Triverna.pl oferuje specjalne ceny rezerwacji dla osób, które zdecydują się jej dokonać za pośrednictwem linków w poniższym artykule. Zapraszamy!

## Rekordowe koszty rynkowych operacji NBP. Zamiast zysku będzie strata
 - [https://businessinsider.com.pl/gospodarka/rekordowe-koszty-dzialan-nbp-zamiast-zysku-bedzie-strata/fg7l3x7](https://businessinsider.com.pl/gospodarka/rekordowe-koszty-dzialan-nbp-zamiast-zysku-bedzie-strata/fg7l3x7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T05:49:08+00:00

Rekordowe 17,6 mld zł wyniosły w minionym roku koszty przeprowadzonych przez NBP rynkowych operacji, które miały na celu ściąganie nadmiarowej płynności z systemu bankowego — wynika z obliczeń "Dziennika Gazety Prawnej". Dziennik podaje, że ponad 4 mld zł kosztowało bank centralny oprocentowanie rezerwy obowiązkowej.

## Tego najbardziej boją się podatnicy w 2024 r. Ekspert nie ma wątpliwości [OPINIA]
 - [https://businessinsider.com.pl/prawo/podatki/ksef-to-bedzie-najwieksze-wyzwanie-podatkowe-w-2024-r/q91lh6l](https://businessinsider.com.pl/prawo/podatki/ksef-to-bedzie-najwieksze-wyzwanie-podatkowe-w-2024-r/q91lh6l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T05:45:30+00:00

Największym wyzwaniem podatkowym 2024 r. będzie obowiązkowy KSeF, nie mam co do tego żadnych wątpliwości. To nie tylko zmiana przepisów podatkowych. To zmiana fundamentalna w zakresie wystawiania faktur, a więc i sposobu funkcjonowania przedsiębiorców — pisze Małgorzata Samborska, doradca podatkowy i partner w Grant Thornton specjalnie dla Business Insidera.

## Zmiany w prawie od 2024 r. Dotkną miliony Polaków
 - [https://businessinsider.com.pl/prawo/zmiany-w-prawie-od-2024-r-dotkna-miliony-polakow-i-nie-chodzi-o-800-plus/3d2xfgz](https://businessinsider.com.pl/prawo/zmiany-w-prawie-od-2024-r-dotkna-miliony-polakow-i-nie-chodzi-o-800-plus/3d2xfgz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T05:34:54+00:00

Nowy rok oznacza zwykle wiele zmian w prawie. Wzrost świadczenia 500 plus o 300 zł to jedna z wielu nowości. Dotyczą one milionów Polaków. Chodzi bowiem o zmiany wysokości pensji minimalnej, cen alkoholi, zasad sprzedaży energetyków, podatku od nieruchomości, ale też prowadzenia lombardów. Część obowiązuje już od 1 stycznia, niektóre wejdą w życie nieco późnej. Oto najważniejsze przepisy, które warto znać.

## Zamieszanie z kursem złotego. Minister finansów: to "fejk"
 - [https://businessinsider.com.pl/gielda/wiadomosci/zamieszanie-z-kursem-zlotego-minister-finansow-to-fejk/wtgemsk](https://businessinsider.com.pl/gielda/wiadomosci/zamieszanie-z-kursem-zlotego-minister-finansow-to-fejk/wtgemsk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T05:24:45+00:00

W poniedziałek 1 stycznia ogromne zamieszanie wywołały notowania złotego publikowane przez Google. Według tych danych kurs przebił 5 zł za jedno euro. Oznaczałoby to wzrost notowań o ponad 20 proc. Emocje szybko ostudził minister finansów Andrzej Domański.

## Kontrowersyjny projekt nowych wakacji kredytowych. Rząd Tuska stawia warunek
 - [https://businessinsider.com.pl/gospodarka/kontrowersyjny-projekt-nowych-wakacji-kredytowych-rzad-tuska-stawia-warunek/fsdn6y2](https://businessinsider.com.pl/gospodarka/kontrowersyjny-projekt-nowych-wakacji-kredytowych-rzad-tuska-stawia-warunek/fsdn6y2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T05:21:06+00:00

Choć spłacalność kredytów mieszkaniowych pozostaje bardzo dobra, to stopy procentowe wciąż są podwyższone i politycy starają się przypodobać kredytobiorcom, wprowadzając wakacje kredytowe. Prawdopodobnie klienci będą mogli zawiesić cztery raty w 2024 r. Choć nie wszyscy, bo rząd planuje wprowadzenie kryterium dochodowego. To generalnie dobry ruch, ale jest ono daleki od ideału.

## Uwolnienie cen prądu i nowe taryfy dla klientów. Tak E.ON widzi rynek energii w Polsce
 - [https://businessinsider.com.pl/biznes/uwolnienie-cen-pradu-i-nowe-taryfy-dla-klientow-tak-eon-widzi-rynek-energii-w-polsce/sswe793](https://businessinsider.com.pl/biznes/uwolnienie-cen-pradu-i-nowe-taryfy-dla-klientow-tak-eon-widzi-rynek-energii-w-polsce/sswe793)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T05:17:32+00:00

Nie możemy blokować rozwoju OZE, tym bardziej że już nie tylko Unia Europejska, ale także społeczeństwo wymaga od nas transformacji, odchodzenia od węgla — przekonuje Andrzej Modzelewski, prezes E.ON Polska, w rozmowie z Business Insiderem. — Drugim krokiem będzie zaoferowanie klientom nowych produktów, nowych taryf. Bo zamrażanie cen wkrótce się skończy i nie może być tak, że klienci zostaną z drogą energią — podkreśla Modzelewski.

## Gdzie najlepiej inwestować w nieruchomości? Eksperci wskazują miejsca bezpieczne, ryzykowne i bardzo ryzykowne [MAPA]
 - [https://businessinsider.com.pl/poradnik-finansowy/gdzie-najlepiej-inwestowac-w-nieruchomosci-eksperci-wskazuja-miejsca-bezpieczne/szg50rz](https://businessinsider.com.pl/poradnik-finansowy/gdzie-najlepiej-inwestowac-w-nieruchomosci-eksperci-wskazuja-miejsca-bezpieczne/szg50rz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T05:07:00+00:00

Boom na inwestowanie w nieruchomości trwa w najlepsze. Choć eksperci uważają, że coraz trudniej będzie o gigantyczne zyski, to wciąż ustawiają się kolejki chętnych na zakupy. Pytanie jednak, gdzie inwestować – czy lepsza będzie Warszawa, czy może większe zyski zapewni malownicza górska wieś na Dolnym Śląsku? Wraz z ekspertami i pośrednikami stworzyliśmy mapę najlepszych miejsc, w których zakup nieruchomości wydaje się wciąż dobrym pomysłem.

## Raty kredytów mocno nie spadną, ale inflacja odpuści. Analitycy kreślą scenariusze na 2024 r.
 - [https://businessinsider.com.pl/gospodarka/makroekonomia/prognozy-na-2024-r-raty-kredytow-mocno-nie-spadna-ale-inflacja-odpusci/deswspm](https://businessinsider.com.pl/gospodarka/makroekonomia/prognozy-na-2024-r-raty-kredytow-mocno-nie-spadna-ale-inflacja-odpusci/deswspm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-01-02T05:00:00+00:00

Rada Polityki Pieniężnej nie będzie rozpieszczała kredytobiorców w tym roku, a na silny spadek rat hipotek nie ma co liczyć – wynika z prognoz przygotowanych dla Business Insider Polska przez ekonomistów. Dobrą wiadomością jest za to wyraźny spadek inflacji, który może przynieść 2024 r. Dynamika cen towarów i usług konsumpcyjnych może być niższa, niż oczekuje rząd, a największych niespodzianek można się spodziewać już wiosną. Swoją siłę w tym roku będzie miała szansę pokazać także nasze waluta.

