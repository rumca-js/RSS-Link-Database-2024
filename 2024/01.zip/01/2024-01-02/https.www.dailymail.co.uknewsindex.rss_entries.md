# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Bunnings Warehouse rule divides Australia
 - [https://www.dailymail.co.uk/news/article-12920241/Bunnings-Warehouse-rule-divides-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920241/Bunnings-Warehouse-rule-divides-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T23:22:04+00:00

A divisive policy at Bunnings Warehouse is causing a nationwide rift. As Australians weigh in, the question lingers: Should this rule stay or gor?

## Mayor Eric Adams admits NYC is not allowed to turn migrants over to ICE agents as he warns 'people are going to be sleeping on the streets'
 - [https://www.dailymail.co.uk/news/article-12920337/Mayor-Eric-Adams-admits-NYC-migrants-ice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920337/Mayor-Eric-Adams-admits-NYC-migrants-ice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T23:21:57+00:00

The mayor made the assertion during a sitdown with Fox 5's Rosanna Scotto , where he revealed the city's 'sanctuary' has hindered his ability to handle the crisis.

## Survivor of Sea World helicopter crash speaks for the first time after report found dead pilot had cocaine in his system
 - [https://www.dailymail.co.uk/news/article-12920447/Sea-World-helicopter-crash-aircraft-pilot-drug-survivor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920447/Sea-World-helicopter-crash-aircraft-pilot-drug-survivor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T23:17:48+00:00

A woman who was badly injured in the Sea World disaster has expressed her anger at the revelation the pilot flying the helicopter she was in had cocaine in his system.

## Back to work Joe: Biden leaves Caribbean after weeklong beach vacation as border crisis, possible government shutdown and Ukraine funding row await him in Washington
 - [https://www.dailymail.co.uk/news/article-12919263/Biden-vacation-virgin-islands-Joe-Jill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919263/Biden-vacation-virgin-islands-Joe-Jill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T23:15:13+00:00

President Joe Biden, first lady Jill Biden and granddaughter Natalie departed St. Croix on Tuesday, leaving the sunny skies of the Caribbean for the political storms of Washington D.C.

## American tourist reveals why she did not like Australia - labelling her experience as bland, underwhelming and inconvenient
 - [https://www.dailymail.co.uk/news/article-12920215/American-tourist-reveals-did-not-like-Australia-labelling-experience-bland-underwhelming-inconvenient.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920215/American-tourist-reveals-did-not-like-Australia-labelling-experience-bland-underwhelming-inconvenient.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T23:03:14+00:00

American travel blogger Grace Cheng sparks controversy after labelling her two-week Australian adventure 'bland'. Here's why.

## Jewish family targeted by anti-Semitic abuse in New Jersey's American Dream Mall over teen daughter's IDF jacket say 'dozens' of bystanders stood by just WATCHING as they were attacked
 - [https://www.dailymail.co.uk/news/article-12920501/antisemitism-Jewish-American-Dream-Mall-New-Jersey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920501/antisemitism-Jewish-American-Dream-Mall-New-Jersey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:59:32+00:00

The Jewish family who was targeted with foul-mouthed harassment in a New Jersey mall has spoken out in an exclusive interview with DailyMail.com after video went viral.

## Police launch urgent search for missing teenage girl, 14, last seen on Boxing Day
 - [https://www.dailymail.co.uk/news/article-12920671/Police-search-missing-girl-14-Boxing-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920671/Police-search-missing-girl-14-Boxing-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:56:19+00:00

Police are growing increasingly concerned for the welfare of a 14-year-old girl who has been missing since Boxing Day. Kya Harris was last seen at her home in Plymouth, Devon at around 11am.

## Sean Hannity is leaving New York for good to live in Florida as he slams 'high taxes, burdernsome regulation, crime and horrible schools'
 - [https://www.dailymail.co.uk/news/article-12920269/Fox-News-Sean-Hannity-leaves-New-York-Florida-Ainsley-Earhardt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920269/Fox-News-Sean-Hannity-leaves-New-York-Florida-Ainsley-Earhardt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:45:05+00:00

Fox News host Sean Hannity has permanently relocated from New York to Florida, where he already owns a $5.3 million home - and given the Empire State a parting shot.

## What the most narcissistic resignation letter of all REALLY reveals: MAUREEN CALLAHAN mercilessly skewers Claudine Gay's self-pitying farewell to Harvard... where hilariously, she's the REAL victim cruelly dethroned by bigots
 - [https://www.dailymail.co.uk/news/article-12920131/claudine-gay-harvard-resignation-maureen-callahan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920131/claudine-gay-harvard-resignation-maureen-callahan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:34:02+00:00

Claudine Gay's resignation letter is a doozy. Truly, it's one for the books, lengthy and self-pitying and utterly shameless, signed by Gay herself - sans irony - as the sole author!

## 'The whole house shook': Maryland and DC residents rocked by 2.3-magnitude earthquake - hours before tremors struck NYC and Roosevelt Island residents reported loud booms
 - [https://www.dailymail.co.uk/news/article-12920091/Maryland-DC-earthquake-tremors-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920091/Maryland-DC-earthquake-tremors-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:33:23+00:00

A 2.3 earthquake hit  Rockville, Maryland, at 12.51am on Tuesday. Later, a 1.7 earthquake with an epicenter in Astoria passed through New York at 5.45am.

## 'Gold Bars' Democrat Bob Menendez accused AGAIN by federal prosecutors this time for accepting fancy wrist watches and other lavish gifts from Qatar in alleged corruption scheme
 - [https://www.dailymail.co.uk/news/article-12920547/Gold-Bars-Democrat-Bob-Menendez-indicted-fancy-wrist-watches-lavish-gifts-Qatar-alleged-corruption-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920547/Gold-Bars-Democrat-Bob-Menendez-indicted-fancy-wrist-watches-lavish-gifts-Qatar-alleged-corruption-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:31:54+00:00

Sen. Bob Menendez has been hit with new accusations in his years-long alleged corruption scheme, this time for allegedly accepting gifts from the Qataris.

## First major winter storm of 2024 could bring heaviest snowfall in TWO YEARS from New York to Washington this weekend - and floods in the South
 - [https://www.dailymail.co.uk/news/article-12920331/First-major-winter-storm-2024-heaviest-snowfall-East-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920331/First-major-winter-storm-2024-heaviest-snowfall-East-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:31:22+00:00

The East Coast is bracing for the possibility of the heaviest snowfall in two years as a massive winter storm sweeps in, bringing deluges for the south.

## Dramatic moment hero NYC cops rescue man who fell onto subway track - a month after they saved woman trapped under Brooklyn pier
 - [https://www.dailymail.co.uk/news/article-12920061/dramatic-moment-nyc-cops-rescue-man-subway-track.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920061/dramatic-moment-nyc-cops-rescue-man-subway-track.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:18:34+00:00

Two NYPD officers made two incredible saves during the last three months of 2023.

## 'Gold Bars' Democrat Bob Menendez indicted AGAIN this time for accepting fancy wrist watches and other lavish gifts from Qatar in alleged corruption scheme
 - [https://www.dailymail.co.uk/news/article-12920547/Gold-Bars-Democrat-Bob-Menendez-charged-fancy-wrist-watches-lavish-gifts-Qatar-alleged-corruption-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920547/Gold-Bars-Democrat-Bob-Menendez-charged-fancy-wrist-watches-lavish-gifts-Qatar-alleged-corruption-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:18:32+00:00

Sen. Bob Menendez has been hit with another charge in his years-long alleged corruption scheme, this time accused of accepting gifts from the Qataris.

## Missing Florida woman's son confirms human remains found in pond near Disney World are hers after cops gave team of divers her last cell phone ping from night she disappeared 12 years ago
 - [https://www.dailymail.co.uk/news/article-12920227/missing-woman-remains-confirmed-son-walt-disney-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920227/missing-woman-remains-confirmed-son-walt-disney-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:17:48+00:00

The son of a missing Florida woman has confirmed that the remains found in a pond near Disney World are his mother's after she mysteriously vanished twelve years ago.

## Charlamagne Tha God will NOT endorse Biden again in 2024 as influential radio host slams Kamala Harris for 'disappearing' once she got to the White House and president's support among black voters collapses
 - [https://www.dailymail.co.uk/news/article-12920219/Charlamagne-tha-god-Biden-2024-harris-endorse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920219/Charlamagne-tha-god-Biden-2024-harris-endorse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:16:12+00:00

Charlamagne Tha God says he has learned his lesson from 2020 and will not be endorsing Joe Biden and Kamala Harris this time around.

## Disgraced attorney Tom Girardi, 84, is deemed fit to stand trial for stealing $18M from clients despite Alzheimer's diagnosis - paving way of ex of RHOBH star Erika Jayne to face jury this year
 - [https://www.dailymail.co.uk/news/article-12920319/Disgraced-attorney-Tom-Girardi-fit-stand-trial-RHOBH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920319/Disgraced-attorney-Tom-Girardi-fit-stand-trial-RHOBH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:14:06+00:00

Disgraced attorney Tom Girardi - the estranged husband of RHOBH star Erika Jayne - has been cleared to stand trial for allegedly embezzling $18 million from clients.

## The Forsyte Saga star Susan Hampshire joins Dame Esther Rantzen's calls for a review of assisted dying
 - [https://www.dailymail.co.uk/news/article-12920355/The-Forsyte-Saga-star-Susan-Hampshire-joins-Dame-Esther-Rantzens-calls-review-assisted-dying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920355/The-Forsyte-Saga-star-Susan-Hampshire-joins-Dame-Esther-Rantzens-calls-review-assisted-dying.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:11:28+00:00

Ms Hampshire, 86 - best known for starring in BBC drama The Forsyte Saga - said a democratic and civilised country 'should surely be able to rethink the current law'.

## Desperate search for two missing western Sydney sisters after pair mysteriously vanished from Tregear
 - [https://www.dailymail.co.uk/news/article-12920421/Desperate-search-two-missing-western-Sydney-sisters-pair-mysteriously-vanished-Tregear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920421/Desperate-search-two-missing-western-Sydney-sisters-pair-mysteriously-vanished-Tregear.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:08:38+00:00

Amber Bagust-King, 14 and her sister Laura Bagust-King, 13, were last seen at a home on Luxford Road, Tregear in Sydney's west about 1.30pm Tuesday.

## Camden Council vets businesses seeking contracts over their commitment to 'LGBTQ+ values'
 - [https://www.dailymail.co.uk/news/article-12920539/Camden-Council-vets-businesses-seeking-contracts-commitment-LGBTQ-values.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920539/Camden-Council-vets-businesses-seeking-contracts-commitment-LGBTQ-values.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:07:59+00:00

The Labour-run council will now only work 'with businesses whose values align with our own' and which 'positively influence' social attitudes within its electoral wards.

## Congress members will receive secret UFO briefing next week from top spy chief amid growing demands for greater transparency
 - [https://www.dailymail.co.uk/news/article-12920237/Congress-members-receive-secret-UFO-briefing-week-spy-chief-amid-growing-demands-greater-transparency.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920237/Congress-members-receive-secret-UFO-briefing-week-spy-chief-amid-growing-demands-greater-transparency.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:06:02+00:00

Members of the House Oversight Committee are scheduled to undergo a classified briefing next week on Unidentified Anomalous Phenomena (UAP).

## Donald Trump APPEALS case after Maine tries to dump him from the ballot
 - [https://www.dailymail.co.uk/news/article-12920473/Donald-Trump-appeals-case-Maine-ballot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920473/Donald-Trump-appeals-case-Maine-ballot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:05:56+00:00

Attorneys for Donald Trump have appealed a decision by Maine 's secretary of state after disqualifying him from the primary ballot

## Children as young as TEN years old could face £500 'Asbo' fines for breaching 'busybody orders' that can be used to ban playing football
 - [https://www.dailymail.co.uk/news/article-12920335/children-aged-10-asbos-breaching-busybody-orders-banned-playing-football.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920335/children-aged-10-asbos-breaching-busybody-orders-banned-playing-football.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:05:36+00:00

Under a new law, the minimum age for getting a Community Protection Notice (CPN) is being lowered from 16 to cover primary school pupils.

## Arizona man is shot at SIXTEEN times while driving home from Mexico on Christmas Eve after taking different route to avoid roadblock caused by migrant crisis that left him in at mercy of rival smuggling gangs
 - [https://www.dailymail.co.uk/news/article-12920073/Arizona-man-shot-driving-home-Mexico-Christmas-Eve-migrant-roadblock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920073/Arizona-man-shot-driving-home-Mexico-Christmas-Eve-migrant-roadblock.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:02:47+00:00

Craig Ricketts, 68, was shot at over a dozen times as he traversed a section of the U.S.-Mexico border plagued by gang violence.

## Japan airlines fire: Twelve Australians on board passenger jet that collided with coast guard plane
 - [https://www.dailymail.co.uk/news/article-12920493/Japan-airlines-fire-twelve-Australians-coast-guard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920493/Japan-airlines-fire-twelve-Australians-coast-guard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:01:11+00:00

Emergency Management Minister Murray Watt revealed at least a dozen of the 379 people caught up in the collision were from home soil.

## Revealed: The NHS fat cats pocketing up to £300,000 a year while running floundering trusts as the longest doctors' strike in history begins
 - [https://www.dailymail.co.uk/news/article-12920445/NHS-bosses-paid-300k-year-running-trusts-junior-doctors-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920445/NHS-bosses-paid-300k-year-running-trusts-junior-doctors-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:01:06+00:00

While the row over pay and conditions shows little sign of a conclusion, a Mail investigation found bosses of the 11 trusts with the longest referral waiting times all earn more than the Prime Minister.

## Kentucky law clerk Kim Davis who refused to issue marriage licenses to gay couples is ordered to pay $260,000 in legal fees in addition to $100,000 of previous damages
 - [https://www.dailymail.co.uk/news/article-12920443/Kentucky-law-clerk-Kim-Davis-pay-expenses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920443/Kentucky-law-clerk-Kim-Davis-pay-expenses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T22:01:01+00:00

Kim Davis will have to pay $260,000 to the lawyers of David Ermold and David Moore for their fees and expenses after the couple successfully sued the county clerk who denied them a marriage licence.

## Pictured: Man, 29, stabbed to death near Abbey Road leaving his family 'starting their New Year devastated'
 - [https://www.dailymail.co.uk/news/article-12920439/Pictured-Man-29-stabbed-death-near-Abbey-Road-leaving-family-starting-New-Year-devastated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920439/Pictured-Man-29-stabbed-death-near-Abbey-Road-leaving-family-starting-New-Year-devastated.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T21:58:01+00:00

Ahmed Jama, 29, was found with multiple stab wounds in on the Abbey Wood estate near St John's Wood just after 7.30pm on Friday.

## Sweet Lady Jane bakery in Los Angeles - backed with $2M by Mary-Kate and Ashley Olsen and famed for its yummy Triple Berry Cake  - announces it's closing all locations after 35 years
 - [https://www.dailymail.co.uk/news/article-12919833/Los-Angeles-Sweet-Lady-Jane-bakeshop-celebrity-Olsen-twins-closes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919833/Los-Angeles-Sweet-Lady-Jane-bakeshop-celebrity-Olsen-twins-closes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T21:50:42+00:00

One of LA's most beloved bakeries, popularized by its celebrity clientele, has become the latest victim of California's soaring cost of living and inflation rates, suddenly closing its doors just before the New Year.

## Woman dies of Legionnaires' disease a week after staying at $200-per-night New Hampshire spa hotel as resort's hot tub has been shut down
 - [https://www.dailymail.co.uk/news/article-12919955/Woman-dies-Legionnaires-disease-new-hampshire-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919955/Woman-dies-Legionnaires-disease-new-hampshire-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T21:14:39+00:00

A 71-year-old woman died of Legionnaires' disease one week after staying at a pricey New Hampshire spa hotel and the resort's hot tub has been shut down.

## Dramatic helicopter footage shows the moment missing Chinese exchange student, 17, was rescued on Utah mountainside after 'cyber kidnapping'
 - [https://www.dailymail.co.uk/news/article-12920027/missing-chinese-exchange-student-utah-rescue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920027/missing-chinese-exchange-student-utah-rescue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T21:10:40+00:00

Kai Zhuang, 17, was discovered in the Brigham City Canyon area Sunday night, after cops said he fell victim to a sordid 'cyber-kidnapping' scam Thursday.

## Donald Trump to SKIP Republican presidential debate in Iowa on CNN and hold dueling town hall on Fox News at exactly the same time
 - [https://www.dailymail.co.uk/news/article-12920101/Trump-SKIPS-Republican-Iowa-debate-town-hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920101/Trump-SKIPS-Republican-Iowa-debate-town-hall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T21:08:09+00:00

Trump will not break with his pattern of skipping Republican presidential primary debates and during the last face-off before Iowa caucuses will run counter programming with a Fox News town hall.

## Revealed: Darts sensation Luke Littler's victory meal is £7.99 mixed meat wrap from German Doner Kebab - as manager says they are 'proud to be helping power him'
 - [https://www.dailymail.co.uk/news/article-12920191/Luke-Littlers-victory-meal-revealed-German-Doner-Kebab.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920191/Luke-Littlers-victory-meal-revealed-German-Doner-Kebab.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T21:06:21+00:00

EXCLUSIVE: The 16-year-old, who has taken the sport by storm with his run at the World Darts Championship, is believed to be a fan of the mixed meat doner wrap from German Doner Kebab.

## Furious villagers hold tractor protest over plans to build 28,000-seat rugby stadium and housing estate on greenbelt land
 - [https://www.dailymail.co.uk/news/article-12920153/villagers-protest-rugby-stadium-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920153/villagers-protest-rugby-stadium-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:59:04+00:00

Rugby club Wasps RFC, which crashed out of domestic competition after going bust last year, wants to revive its fortunes with a 28,000-seat complex close to the tiny village of Crockenhill in Kent.

## Terrorist who plotted to blow up MCG on AFL grand final day issues a message to Aussies after being released from jail
 - [https://www.dailymail.co.uk/news/article-12920025/Terrorist-plotted-blow-MCG-AFL-grand-final-day-issues-message-Aussies-released-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920025/Terrorist-plotted-blow-MCG-AFL-grand-final-day-issues-message-Aussies-released-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:53:02+00:00

Abdul Nacer Benbrika has broken his silence since his release from high risk and maximum security centre Barwon Prison two weeks ago.

## Colombian councilman 'shot dead by 17-year-old gangster' near his home on New Year's Eve - just one day before he was set to be sworn in
 - [https://www.dailymail.co.uk/news/article-12919713/Colombian-councilman-Eliecid-vila-shot-dead-New-Year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919713/Colombian-councilman-Eliecid-vila-shot-dead-New-Year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:51:07+00:00

Police in western Colombia are searching for a 17-year-old boy who allegedly shot councilman Eliecid Ávila on Sunday. Ávila's family said he died early Tuesday morning.

## Speaker Mike Johnson heads to the southern border in Texas alongside 60 Republicans just days after HISTORIC 302,000 illegal migrants crossed into the US in December
 - [https://www.dailymail.co.uk/news/article-12919947/Speaker-Mike-Johnson-heads-southern-border-Texas-alongside-60-Republicans-just-days-HISTORIC-302-000-illegal-migrants-crossed-December.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919947/Speaker-Mike-Johnson-heads-southern-border-Texas-alongside-60-Republicans-just-days-HISTORIC-302-000-illegal-migrants-crossed-December.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:50:02+00:00

The group, hosted by Rep. Tony Gonzales who represents the area, will hear from Border Patrol, Texas Department of Public Safety and other stakeholders and tour the region.

## Killers of the Flower Moon actress Lily Gladstone uses she/they pronouns as a way of 'decolonizing gender' and claims her male cousins were 'teased' for their long hair
 - [https://www.dailymail.co.uk/news/article-12920103/Killers-Flower-Moon-Lily-Gladstone-pronouns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920103/Killers-Flower-Moon-Lily-Gladstone-pronouns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:44:43+00:00

Lily Gladstone, 37, revealed how her childhood growing up on the Blackfeet reservation in Montana led her to be comfortable with gender fluidity.

## Horror as woman dies after she and a child caught in a rip at Park Beach in Coffs Harbour, NSW
 - [https://www.dailymail.co.uk/news/article-12920159/Horror-woman-dies-child-caught-rip-Park-Beach-Coffs-Harbour-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920159/Horror-woman-dies-child-caught-rip-Park-Beach-Coffs-Harbour-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:36:51+00:00

Woman drowns, child rescued from deadly rip on the NSW coast

## 'Highly talented' lawyer, 40, who studied at Harvard died after becoming addicted to cocktail of prescription-only medicines she repeatedly bought from illicit websites, inquest hears
 - [https://www.dailymail.co.uk/news/article-12920065/Highly-talented-lawyer-40-studied-Harvard-died-addicted-cocktail-prescription-medicines-repeatedly-bought-illicit-websites-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920065/Highly-talented-lawyer-40-studied-Harvard-died-addicted-cocktail-prescription-medicines-repeatedly-bought-illicit-websites-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:30:20+00:00

Dr Kimberly Liu, 40, had been repeatedly buying sedatives online for four years before her death and had become addicted to sleeping pills and painkillers, some of which she sought on the internet.

## Paedophile, 37, who arranged to meet an 11-year-girl after being caught contacting police officer posing as a child for sex is jailed for 14 years
 - [https://www.dailymail.co.uk/news/article-12920067/abuser-meet-girl-police-officer-posing-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920067/abuser-meet-girl-police-officer-posing-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:26:04+00:00

Amanuel Ehdego, 37, of Enfield, north London, planned to meet two 'girls' who both happened to be undercover adults, while also arranging live streams of children being sexually abused in the Philippines.

## Founder Camila Batmanghelidjh of scandal-hit charity Kids Company dies aged 61
 - [https://www.dailymail.co.uk/news/article-12920173/Founder-Camila-Batmanghelidjh-scandal-hit-charity-Kids-Company-dies-aged-61.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920173/Founder-Camila-Batmanghelidjh-scandal-hit-charity-Kids-Company-dies-aged-61.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:10:14+00:00

Kids Company founder Camila Batmanghelidjh had died aged 61.

## Ransomware hit 2,200 US hospitals, schools and governments last year and is killing about one Medicare patient each month - as calls grow to outlaw extortion payments to hackers
 - [https://www.dailymail.co.uk/news/article-12919799/Ransomware-statistics-schools-hospitals-hackers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919799/Ransomware-statistics-schools-hospitals-hackers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:09:15+00:00

While major ransomware attacks on private firms such as MGM Resorts dominated headlines, a rising number of schools, hospitals and local governments were also hit by hackers.

## Harvard appoints Alan Garber as new interim president after he was seen nodding in approval during Claudine Gay's anti-Semitism testimony that led to her ousting
 - [https://www.dailymail.co.uk/news/article-12920063/harvard-alan-garber-new-president-claudine-gay-resignation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920063/harvard-alan-garber-new-president-claudine-gay-resignation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:08:28+00:00

Harvard named Alan M. Garber as interim president after Claudine Gay announced her resignation following anti-Semitic remarks made during testimony and accusations of plagiarism.

## How Claudine Gay clung to power for 28 days after billionaire donors withdrew funding and Harvard board repeatedly supported her despite several plagiarism claims and anti-Semitism scandal
 - [https://www.dailymail.co.uk/news/article-12920113/How-Claudine-Gay-Harvard-stayed-power-resignation-anti-Semitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920113/How-Claudine-Gay-Harvard-stayed-power-resignation-anti-Semitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:07:37+00:00

Claudine Gay managed to hold on for 28 days before announcing earlier today that she would step down after a disastrous, brief tenure as head of the prestigious university.

## Tragic twist after young Aussie boy died alongside his cousin while on holiday
 - [https://www.dailymail.co.uk/news/article-12918787/Tragic-twist-Aussie-boy-died-alongside-cousin-holiday-New-Zealand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918787/Tragic-twist-Aussie-boy-died-alongside-cousin-holiday-New-Zealand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T20:07:14+00:00

Sonny Skrzypek and his cousin Eddie Lawrence, four, from Auckland, were holidaying with family at a farm in Peria, in far north New Zealand when they died.

## Homicide investigation launched after man vanishes without a trace in tiny mining town south of Perth
 - [https://www.dailymail.co.uk/news/article-12920137/Homicide-investigation-launched-man-vanishes-without-trace-tiny-mining-town-south-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920137/Homicide-investigation-launched-man-vanishes-without-trace-tiny-mining-town-south-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T19:55:01+00:00

The disappearance of a man in a tiny mining town is being treated as suspicious, with homicide detectives called in to investigate.

## Donald Trump rails against Liz Cheney accusing her of 'extreme sabotage' and calls for Special Counsel Jack Smith's latest January 6 legal filing to be 'terminated' as she fires back, calling the former president 'hangry'
 - [https://www.dailymail.co.uk/news/article-12919963/Trump-Liz-Cheney-sabotage-Jack-Smith.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919963/Trump-Liz-Cheney-sabotage-Jack-Smith.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T19:52:00+00:00

Donald Trump used social media to falsely accuse Liz Cheney of destroying evidence gathered by the congressional January 6 investigation, saying she was guilty of 'extreme sabotage.'

## Monkey business: Furious neighbors slam plans for research center housing 43,000 primates next to their Texas properties
 - [https://www.dailymail.co.uk/news/article-12919837/Monkey-business-Furious-neighbors-slam-plans-research-center-housing-43-000-primates-Texas-properties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919837/Monkey-business-Furious-neighbors-slam-plans-research-center-housing-43-000-primates-Texas-properties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T19:51:08+00:00

Texans living in Brazoria County, south of Houston, are opposing a $12 billion construction by Charles River Laboratories, a biomedical research firm which planned to house 43,200 monkeys.

## Ex-CIA analyst John Gentry warns DEI push and 'significant' politicization of intelligence services threatens 2024 election
 - [https://www.dailymail.co.uk/news/article-12919419/ex-CIA-analyst-DEI-2024-election-john-gentry-trump-biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919419/ex-CIA-analyst-DEI-2024-election-john-gentry-trump-biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T19:42:46+00:00

Dr. John Gentry who spent 12 years in the CIA as an analyst said that the DEI policy notable politicization in intelligence services will threaten the 2024 presidential election.

## Heartbreaking images show painfully thin lions feeding on scraps and the body of an emaciated monkey at zoo in bomb-ravaged Gaza
 - [https://www.dailymail.co.uk/news/article-12920079/Heartbreaking-images-painfully-lions-feeding-scraps-body-emaciated-monkey-zoo-bomb-ravaged-Gaza.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12920079/Heartbreaking-images-painfully-lions-feeding-scraps-body-emaciated-monkey-zoo-bomb-ravaged-Gaza.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T19:37:07+00:00

Lions, monkeys and parrots have been struggling to find food and medical treatment at the zoo in Rafah, Gaza, 12 weeks into Israel 's offense on the region.

## Steve Bannon warns of 'big fight' in Republican party if Trump chooses 'viper' Nikki Haley as his running mate because she will 'run it as prime minister like Dick Cheney'
 - [https://www.dailymail.co.uk/news/article-12919745/Steve-Bannon-warns-big-fight-Republican-party-Trump-chooses-viper-Nikki-Haley-running-mate-run-prime-minister-like-Dick-Cheney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919745/Steve-Bannon-warns-big-fight-Republican-party-Trump-chooses-viper-Nikki-Haley-running-mate-run-prime-minister-like-Dick-Cheney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T19:20:57+00:00

The Republican Party might fracture even further if former President Donald Trump ends up running on the same ticket with Nikki Haley, Steve Bannon warned.

## The Navy's biggest, fastest and most decorated battleship will sail in Spring for the first time in more than 20 years - moving from New Jersey to Philadelphia for $10 million refurb project
 - [https://www.dailymail.co.uk/news/article-12919517/Navy-biggest-fastest-battleship-set-sail-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919517/Navy-biggest-fastest-battleship-set-sail-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T19:16:35+00:00

USS New Jersey, a highly decorated battleship and Guinness World Record holder, will embark on a historic journey to the Philadelphia Navy Yard for  much-needed repairs.

## Claudine Gay QUITS as Harvard President but fails to mention antisemitism testimony OR plagiarism claims in sour resignation letter where she says she's been victim of racism
 - [https://www.dailymail.co.uk/news/article-12919893/Harvard-President-Claudine-Gay-resign-plagiarism-claims-disastrous-antisemitism-testimony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919893/Harvard-President-Claudine-Gay-resign-plagiarism-claims-disastrous-antisemitism-testimony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T19:01:25+00:00

Harvard President Claudine Gay resigned today after a disastrous, brief tenure at as head of the university.

## Top Republican Elise Stefanik cheers 'long overdue' and 'forced' resignation of embattled Harvard President Claudine Gay over antisemitic testimony and plagiarism allegations
 - [https://www.dailymail.co.uk/news/article-12919903/republican-elise-stefanik-firing-claudine-gay-harvard-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919903/republican-elise-stefanik-firing-claudine-gay-harvard-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T18:48:22+00:00

Top Republican Elise Stefanik cheered the 'forced resignation' of embattled Harvard President Claudine Gay first reported by Harvard's student newspaper The Crimson on Tuesday.

## READ: Claudine Gay's resignation letter in full where she bitterly claims she was the VICTIM of 'threats fueled by racial animus' and urges Harvard not to be 'undermined by rancor and vituperation'
 - [https://www.dailymail.co.uk/news/article-12919983/READ-Claudine-Gays-resignation-letter-bitterly-claims-VICTIM-threats-fueled-racial-animus-urges-Harvard-not-undermined-rancor-vituperation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919983/READ-Claudine-Gays-resignation-letter-bitterly-claims-VICTIM-threats-fueled-racial-animus-urges-Harvard-not-undermined-rancor-vituperation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T18:46:45+00:00

Read Claudine Gay's resignation letter in full.

## Teen who fled Ukraine to escape horrors of Russia war is crowned homecoming queen at North Carolina high school
 - [https://www.dailymail.co.uk/news/article-12919647/Teen-homecoming-queen-North-Carolina-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919647/Teen-homecoming-queen-North-Carolina-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T18:29:06+00:00

A teen who fled her native Ukraine in order to escape the horrors of the war with Russia has been crowned homecoming queen at her North Carolina high school.

## Heartbreaking photo of Oklahoma business owner standing in empty restaurant and looking sadly out the window for customers goes viral - and brings in a week's worth of business in just one day
 - [https://www.dailymail.co.uk/news/article-12919585/viral-photo-spirals-hot-dogs-norman-oklahoma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919585/viral-photo-spirals-hot-dogs-norman-oklahoma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T18:19:52+00:00

A viral photo helped business owner Scott Hosek get a big boost in business at his hot dog restaurant in Norman, Oklahoma .

## New Year, New Baby! New Jersey parents welcome twin boys born on different days in different YEARS after mother went into labor on New Year's Eve
 - [https://www.dailymail.co.uk/news/article-12919547/New-Jersey-twins-born-different-years-Eve-Billy-Humphrey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919547/New-Jersey-twins-born-different-years-Eve-Billy-Humphrey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T18:12:59+00:00

Eve and Billy Humphrey welcomed twins Ezra on December 31, 2023 and younger brother Ezekiel on January 1, 2024. Ezra now also shares his birthday with his father

## Mississippi mayoral candidate is shot dead by brother-in-law armed with AR-15 after showing up to estranged wife's home brandishing a pistol while their three kids were inside
 - [https://www.dailymail.co.uk/news/article-12919683/Mississippi-mayoral-candidate-shot-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919683/Mississippi-mayoral-candidate-shot-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T18:09:15+00:00

Jason Adam Marshall, left, was pronounced dead at South Central Regional Medical Center last week after allegedly being gunned down by Christopher Davis, his brother-in-law.

## Amy Robach throws shade at ex-husband Andrew Shue as she tells TJ Holmes 'you don't really know someone until you divorce them' in the couple's latest podcast episode
 - [https://www.dailymail.co.uk/news/article-12919565/Amy-Robach-shade-ex-husband-Andrew-Shue-TJ-Holmes-divorce-podcast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919565/Amy-Robach-shade-ex-husband-Andrew-Shue-TJ-Holmes-divorce-podcast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T18:00:47+00:00

Amy Robach threw major shade toward her ex-husband Andrew Shue in the couple's latest podcast episode.

## Magnitude 1.7 earthquake strikes Queens before tremors and blasts felt on Roosevelt Island in New York
 - [https://www.dailymail.co.uk/news/article-12919701/earthquake-astoria-queens-tremors-roosevelt-island-nyc.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919701/earthquake-astoria-queens-tremors-roosevelt-island-nyc.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T17:58:13+00:00

New York was struck by a 1.7 magnitude earthquake on Tuesday, the United States Geological Survey has confirmed.

## Partying with her fiancé just hours before brutal car ram murder: Moment killer Alice Wood cosied up to her partner at bash before drunkenly running him over after accusing him of 'clicking' with another woman
 - [https://www.dailymail.co.uk/news/article-12919743/moment-killer-alice-wood-cosied-partner-ryan-watson-running-over.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919743/moment-killer-alice-wood-cosied-partner-ryan-watson-running-over.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T17:57:05+00:00

Footage released by Cheshire Police showed Ryan Watson, a charity worker, arriving at the party with Wood and the pair of them laughing together before she killed him with her car.

## Elon Musk's X is now worth 71 percent less than what Tesla CEO bought app for in 2022, according to Fidelity - as confrontation with advertisers grows
 - [https://www.dailymail.co.uk/news/article-12919409/Elon-Musk-X-value-percent-advertisers-leaving.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919409/Elon-Musk-X-value-percent-advertisers-leaving.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T17:54:45+00:00

Investment group Fidelity estimates that the value of Elon Musk's X, formerly Twitter, has plunged a massive 71 percent since he purchase the platform in April 2022.

## Violent trans sex-offender who has admitted raping children sues jail for denying her 'gender affirming' items including women's underwear and sues for damages exceeding $14M
 - [https://www.dailymail.co.uk/news/article-12919609/Violent-trans-sex-offender-admitted-raping-children-sues-Missouri-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919609/Violent-trans-sex-offender-admitted-raping-children-sues-Missouri-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T17:52:57+00:00

Kelly McSean, born Larry Bemboon, is suing Missouri 's St. Francois County Jail and South Missouri Mental Health Center for alleged mistreatment.

## Why homebuyers are flocking to THIS small Texas town that's one of the fastest growing cities in the US due to booming jobs market and affordability - but angry locals say transplants are driving up prices
 - [https://www.dailymail.co.uk/news/article-12919377/New-Braunfels-texas-town-growing-transplants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919377/New-Braunfels-texas-town-growing-transplants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T17:46:23+00:00

The small city, founded in 1845, is also home to a world-famous waterpark, and the Lone Star State's oldest bakery.

## Heart-stopping moment North Carolina scientist Fred Boyce almost loses an arm while trying to wrestle 250lb gator with a TOWEL goes viral again - as social media jokes man looks like BIDEN
 - [https://www.dailymail.co.uk/news/article-12919489/North-Carolina-scientist-Fred-Boyce-wrestle-alligator-towel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919489/North-Carolina-scientist-Fred-Boyce-wrestle-alligator-towel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T17:27:45+00:00

North Carolina herpetologist Fred Boyce almost loses his arm after the gator snaps its jaws in response to his cautious attempt to wrestle it.

## Gender-neutral toy aisles, increased birth control pill access and stricter background checks for gun buyers - all the new laws taking effect in 2024
 - [https://www.dailymail.co.uk/news/article-12919465/some-new-laws-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919465/some-new-laws-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T17:23:49+00:00

Californian shops will have to curate gender-neutral toy aisles, New Yorkers can no longer buy dogs or cats in pet stores, and birth control is easier to get than ever in some of 2024's new laws.

## Retired Oakland judge pushes wild new theory about infamous Lindbergh baby kidnapping claiming abduction was a HOAX and the wrong man was executed
 - [https://www.dailymail.co.uk/news/article-12919347/Retired-Oakland-judge-pushes-wild-new-theory-infamous-Lindbergh-baby-kidnapping-claiming-abduction-HOAX-wrong-man-executed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919347/Retired-Oakland-judge-pushes-wild-new-theory-infamous-Lindbergh-baby-kidnapping-claiming-abduction-HOAX-wrong-man-executed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T17:22:42+00:00

A retired California judge has suggested Charles Lindbergh may have offered his child for medical experiments faking the 1932 kidnapping to cover up the death.

## Republican impeachment inquiry into Joe and Hunter's business ties enters second year as White House maintains there is 'no evidence': Trusted Biden associate Michael Lewitt who has been SUED by the SEC for fraud is called up to testify
 - [https://www.dailymail.co.uk/news/article-12919581/republican-impeachment-joe-biden-hunter-white-house-michael-lewitt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919581/republican-impeachment-joe-biden-hunter-white-house-michael-lewitt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T17:06:50+00:00

Republicans are charging ahead with their impeachment inquiry into Joe Biden in 2024 despite the White House's insistence they have 'no evidence.'

## Gunman raids Colorado Supreme Court building after judges voted to kick Trump off ballot: Intruder held security guard hostage, shot out a window and set building on fire before surrendering to cops
 - [https://www.dailymail.co.uk/news/article-12919605/Gunman-Colorado-Supreme-Court-building-judges-Trump-ballot-security-guard-hostage-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919605/Gunman-Colorado-Supreme-Court-building-judges-Trump-ballot-security-guard-hostage-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:53:08+00:00

A gunman raided the Colorado Supreme Court firing shots, lighting a fire and holding a security guard at gunpoint on Tuesday morning.

## Israeli drone strike kills four Hamas members at terror group's Beirut office - including founder of their military wing, who Netanyahu had vowed to kill
 - [https://www.dailymail.co.uk/news/article-12919625/Israeli-drone-strike-kills-four-Hamas-members-terror-groups-Beirut-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919625/Israeli-drone-strike-kills-four-Hamas-members-terror-groups-Beirut-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:52:43+00:00

An Israeli drone strike on Hamas' office in Beirut has killed four people, local media has reported.

## Just 1 percent of migrants in Chicago have work permits as Democrat 'sanctuary city' buckles under strain of 26,000 arrivals in 18 months
 - [https://www.dailymail.co.uk/news/article-12919279/migrants-Chicago-26-000-arrivals-1-percent-work-permit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919279/migrants-Chicago-26-000-arrivals-1-percent-work-permit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:52:24+00:00

Only one percent of migrants in Chicago have work permits as the Democrat 'sanctuary city' buckles under strain of the 26,000 arrivals in 18 months.

## Parents of darts prodigy Luke Littler's girlfriend blast cruel trolls over mean online jibes and say their daughter is 'a lovely young girl in a new relationship'
 - [https://www.dailymail.co.uk/news/article-12919631/Parents-darts-prodigy-Luke-Littlers-girlfriend-blast-cruel-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919631/Parents-darts-prodigy-Luke-Littlers-girlfriend-blast-cruel-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:50:57+00:00

Luke, 16, has been dating Eloise Milburn, 21, for six weeks after the pair met playing FIFA on the Xbox.

## Brazilian YouTube star Carlos Medeiros, 26,  is found dead in shallow grave at childhood friend's home after vanishing on Christmas Day
 - [https://www.dailymail.co.uk/news/article-12919207/Missing-Brazilian-YouTube-star-Carlos-Medeiros-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919207/Missing-Brazilian-YouTube-star-Carlos-Medeiros-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:50:24+00:00

Brazilian influencer Carlos Medeiros, who had been missing since Christmas, was found buried at his childhood friend's home on New Year's Eve.

## US Border Patrol agent under investigation after he was caught returning migrants to Mexico after they had already crossed into the US near El Paso, Texas, federal government confirms
 - [https://www.dailymail.co.uk/news/texas/article-12919353/US-Border-Patrol-agent-investigation-caught-returning-migrants-Mexico-crossed-near-El-Paso-Texas-federal-government-confirms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/texas/article-12919353/US-Border-Patrol-agent-investigation-caught-returning-migrants-Mexico-crossed-near-El-Paso-Texas-federal-government-confirms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:48:14+00:00

A US Border Patrol agent is under investigation after he ordered a family of Venezuelan asylum-seekers who were in already in the US and tying to surrender to authorities back to Mexico.

## Republicans candidates spend over $100 million on TV ads in Iowa with 13 days until caucuses as Nikki Haley accuses Ron DeSantis of being a pro-China 'phony'
 - [https://www.dailymail.co.uk/news/article-12919285/Republicans-candidates-spend-100-million-TV-ads-Iowa-13-days-caucuses-Nikki-Haley-accuses-Ron-DeSantis-pro-China-phony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919285/Republicans-candidates-spend-100-million-TV-ads-Iowa-13-days-caucuses-Nikki-Haley-accuses-Ron-DeSantis-pro-China-phony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:45:01+00:00

Republicans have flooded money into Iowa this election cycle with the must-win state seeing approximately $105 million spent in television and radio ads in 2023.

## How tiny footbridge at the Middletons' local railway station has taken 10 YEARS to build at ballooning £9.5m cost - longer than Blackpool Tower and Tower Bridge... and it's STILL not expected to open until Spring
 - [https://www.dailymail.co.uk/news/article-12918727/footbridge-middletons-railway-station-takes-10-years-build.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918727/footbridge-middletons-railway-station-takes-10-years-build.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:43:06+00:00

Passengers have been left frustrated by the unbearably slow building pace on the bridge at Theale station near Reading in Berkshire.

## Five victims of horrific New Year's Day car crash are identified after 24-year-old driver flipped car at a 'high rate of speed' before collision
 - [https://www.dailymail.co.uk/news/article-12919299/New-York-New-Years-Day-crash-Queens-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919299/New-York-New-Years-Day-crash-Queens-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:32:38+00:00

Police have identified the driver of the Mazda as Kazeem Ramasahai, and the occupants as Mario Ocampo, 30, Dayanara Benitez-Ocampo, 19, Salma Garcia-Diaz, 23, and Jordy Bentances, 20.

## Two thugs 'brutally assault Manhattan store employee, 40, while stealing 20 bags of HARIBO' from Duane Reade at ground floor of luxury NYC apartment complex
 - [https://www.dailymail.co.uk/news/article-12919127/thugs-assault-manhattan-store-employee-steal-bags-haribo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919127/thugs-assault-manhattan-store-employee-steal-bags-haribo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:28:59+00:00

The NYPD is seeking the public's help to identify two men wanted for robbery.

## Baby formula recalled after samples test positive for bacteria that causes brain swelling and seizures in infants
 - [https://www.dailymail.co.uk/health/article-12919257/baby-formula-recalled-testing-positive-bacteria-seizures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-12919257/baby-formula-recalled-testing-positive-bacteria-seizures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:27:14+00:00

More than 675,000 cans of baby formula are being recalled over concerns they've been contaminated with a bacteria that could cause life-threatening health complications in infants.

## Gas prices are set to FALL in 2024 - but will remain almost 50% higher than when Trump was president as Biden faces brutal reelection battle
 - [https://www.dailymail.co.uk/news/article-12919139/Gas-prices-fall-prediction-2024-Biden-Trump-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919139/Gas-prices-fall-prediction-2024-Biden-Trump-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T16:18:31+00:00

Gas prices will fall in 2024 for the second year in a row, according to new predictions.

## Mystery as airport workers find passenger's BODY inside plane engine at Salt Lake City airport after he used a de-icing pad to climb inside opening by the fans
 - [https://www.dailymail.co.uk/news/article-12919163/mystery-dead-body-salt-lake-city-airport-plane-engine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919163/mystery-dead-body-salt-lake-city-airport-plane-engine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T15:38:46+00:00

A 30-year-old passenger wound up dead on New Year's Day after he climbed into the engine of a plane at Salt Lake City International Airport.

## Jewish family is subjected to anti-Semitic abuse in New Jersey's American Dream Mall after their 16-year-old daughter was spotted wearing an IDF sweatshirt
 - [https://www.dailymail.co.uk/news/article-12919141/Jewish-Palestinian-American-Dream-Mall-Jersey-harassment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919141/Jewish-Palestinian-American-Dream-Mall-Jersey-harassment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T15:37:44+00:00

A Jewish family of four was subjected to foul-mouthed harassment at the American Dream Mall in New Jersey, according to video of the incident shared by a watchdog group.

## Michigan Powerball winner bought $842M ticket at convenience store outside of Flint - with owner set to scoop $1M for selling lucky ticket
 - [https://www.dailymail.co.uk/news/article-12919105/powerball-drawing-winner-flint-michigan-convenience-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919105/powerball-drawing-winner-flint-michigan-convenience-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T15:32:25+00:00

The $842.4million Powerball ticket was sold at a Food Castle in Grand Blanc, Michigan. The lucky winner has not contacted the store or the lottery

## Teen Iowa fire cadet, 18, is hit with SEVEN terrorism charges after 'keeping hit list of people she wanted to hurt in arson attacks'
 - [https://www.dailymail.co.uk/news/article-12919201/kaelyn-alexis-surrell-terrorism-charges-arson-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919201/kaelyn-alexis-surrell-terrorism-charges-arson-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T15:29:43+00:00

Kaelyn Alexis Surrell, pictured left, is accused of creating the list of targets against students and staff at Sidney High School, where she is currently a student.

## New Year horror as San Francisco teen, 18, is killed after being hit on the head by a rogue firework - as his distraught mom is heard screaming 'where's my baby' at scene of tragedy
 - [https://www.dailymail.co.uk/news/article-12919123/fireworks-san-francisco-man-killed-new-year-treasure-island.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919123/fireworks-san-francisco-man-killed-new-year-treasure-island.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T15:28:09+00:00

An unidentified male, 18, was killed after a firework struck him in the head on Monday morning, just after ringing in the new year. The victim was given first aid, but died at the scene.

## Bodybuilder Joe Ladnier dead at 60: Powerlifter's body is found near truck that contained empty pistol holder after Christmas Eve disappearance as mystery around his vanishing grows
 - [https://www.dailymail.co.uk/news/article-12919085/bodybuilder-joe-ladnier-dead-60-body-christmas-eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919085/bodybuilder-joe-ladnier-dead-60-body-christmas-eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T15:20:37+00:00

The body of renowned powerlifter Joe Ladnier, 60, was discovered yards from his parked truck on an abandoned driveway in Chunchula, Alabama on Friday.

## Boston Mayor Michelle Wu's 'whites only' party did not violate law, Massachusetts AG's office says
 - [https://www.dailymail.co.uk/news/article-12919191/Boston-Mayor-Michelle-Wus-whites-party-did-not-violate-law-Massachusetts-AGs-office-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919191/Boston-Mayor-Michelle-Wus-whites-party-did-not-violate-law-Massachusetts-AGs-office-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T15:18:55+00:00

Democrat Wu hosted the controversial event in December for 'electeds of color'. Her aides were only supposed to invite her six city council members 'of color'.

## More than FIFTY people are struck down by carbon monoxide poisoning at Mormon Church in Utah - with 22 victims hospitalized and several placed in hyperbaric chambers
 - [https://www.dailymail.co.uk/news/article-12919165/carbon-monoxide-poisoning-mormon-church-utah.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919165/carbon-monoxide-poisoning-mormon-church-utah.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T15:17:29+00:00

Nearly fifty people were struck down by carbon monoxide poisoning at a Mormon Church in Utah - with 22 victims in hyperbaric chambers

## Minimum wage is increased across nearly half of the US in 2024 - find out how YOUR state's basic pay compares
 - [https://www.dailymail.co.uk/news/article-12919111/minimum-wage-increase-2024-new-pay-states.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919111/minimum-wage-increase-2024-new-pay-states.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T14:47:23+00:00

Twenty-two states have increased their minimum wages from January 1. Nine states as well as DC now have minimum wages of at least $15.

## Gypsy Rose Blanchard shares midnight New Year's Eve kiss with husband Ryan Scott Anderson and says it's 'really awesome to have family time' after prison release
 - [https://www.dailymail.co.uk/news/article-12919079/gypsy-rose-blanchard-kiss-husband-ryan-scott-anderson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919079/gypsy-rose-blanchard-kiss-husband-ryan-scott-anderson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T14:37:39+00:00

The 32-year-old ex con has been on a social media posting spree since being released from prison Thursday, and it continued for her first holiday as a free woman.

## Burger King chef Kevin Ford who was given measly gift after never taking a sick day in 27 years buys first home after fundraising campaign raised more than $400,000
 - [https://www.dailymail.co.uk/news/article-12919125/Burger-King-cook-Kevin-Ford-buys-house-fundraiser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919125/Burger-King-cook-Kevin-Ford-buys-house-fundraiser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T14:36:58+00:00

Kevin Ford, 56, went viral in June, 2022 after he received the backpack with movie tickets, a few pens, and a bag of Reese's Pieces from the store in Las Vegas - before his daughter intervened.

## Republicans who believe Joe Biden was legitimately elected in 2020 DROPS to less than one-third and only 14% say Trump was responsible for January 6, new poll shows
 - [https://www.dailymail.co.uk/news/article-12919041/14-perent-voters-think-Trump-responsible-January-6.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919041/14-perent-voters-think-Trump-responsible-January-6.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T14:36:51+00:00

American voters have decreasing belief that Biden legitimately won the 2020 election - while only 14 percent of Republicans say Trump is responsible for the January 6, 2021 Capitol riot.

## Police release CCTV stills of masked thugs who broke into pensioner's home on her 77th birthday on Christmas Eve and ransacked her house while she was held prisoner in kitchen
 - [https://www.dailymail.co.uk/news/article-12919055/manchester-pensioner-captive-gang-raids-home-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12919055/manchester-pensioner-captive-gang-raids-home-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T13:40:08+00:00

The terrifying raid took place at 6pm in Saxon Street, north east Manchester. Masked thugs smashed into the elderly victim's home and held her captive as they ransacked it..

## Brisbane dance instructor is stabbed and forced to undergo open heart surgery after cruel Christmas Eve attack
 - [https://www.dailymail.co.uk/news/article-12905851/Brisbane-dance-instructor-stabbed-forced-undergo-open-heart-surgery-cruel-Christmas-Eve-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12905851/Brisbane-dance-instructor-stabbed-forced-undergo-open-heart-surgery-cruel-Christmas-Eve-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T13:35:57+00:00

A Spanish expat living in Queensland has been forced to undergo open heart surgery after he was viciously stabbed while on an overseas holiday in a cruel Christmas Eve attack.

## Woman, 62, wins legal battle in Western Australia to remove her dead husband's sperm in bid to have another baby
 - [https://www.dailymail.co.uk/news/article-12918843/Woman-62-wins-legal-battle-Western-Australia-dead-husbands-sperm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918843/Woman-62-wins-legal-battle-Western-Australia-dead-husbands-sperm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T13:23:39+00:00

A woman who suddenly lost her husband and two children has won a landmark legal battle to have her husband's sperm posthumously removed in a desperate final attempt to have a child.

## Lake's Entrance: Teenage girl is raped in New Year's Eve beach party horror
 - [https://www.dailymail.co.uk/news/article-12918593/Lakes-Entrance-Teenage-girl-raped-New-Years-Eve-beach-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918593/Lakes-Entrance-Teenage-girl-raped-New-Years-Eve-beach-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T12:59:24+00:00

The girl reported that she was raped on a sand dune at Main Beach in Lake's Entrance, Victoria's Gippsland region, at 10:35pm on Sunday.

## Emergency response swings into action after reports of 'three booms and shakes' on New York City's Roosevelt Island
 - [https://www.dailymail.co.uk/news/article-12918859/Emergency-response-reports-explosions-Roosevelt-Island.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918859/Emergency-response-reports-explosions-Roosevelt-Island.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T12:34:43+00:00

Firefighters have initiated an emergency response protocol after 'three booms and shakes' were felt on Roosevelt Island in Manhattan, New York, according to multiple reports.

## Love match for darts hero Luke Littler and girlfriend Eloise Milburn after they met playing FIFA on Xbox over the internet
 - [https://www.dailymail.co.uk/news/article-12918811/love-match-luke-littler-girlfriend-eloise-milburn-fifa-xbox-internet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918811/love-match-luke-littler-girlfriend-eloise-milburn-fifa-xbox-internet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T12:31:39+00:00

EXCLUSIVE: The teenage darts sensation began speaking to Eloise Milburn, 21 around four months ago with the two becoming close as they shared their love of darts and the football video game.

## Darts hero Luke Littler's gran Carol WILL be able to watch him if he reaches World Championship final after council bosses say she can have day off
 - [https://www.dailymail.co.uk/news/article-12918899/darts-luke-littler-gran-carol-able-watch-world-championship-final-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918899/darts-luke-littler-gran-carol-able-watch-world-championship-final-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T12:28:23+00:00

Carol Littler is planning on making the 200 mile trip to London from her Runcorn home, in Cheshire, with her husband, Phil, on Wednesday if the 16-year-old wins his semi-final tonight.

## Rohan Dennis and Melissa Hoskins had it all, with their Olympic dreams fulfilled, world championship medals secured and a young family bursting with love. Then something went terribly, terribly wrong outside their $2.45million mansion
 - [https://www.dailymail.co.uk/news/article-12918297/cycling-stars-Melissa-Hoskins-Rohan-Dennis-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918297/cycling-stars-Melissa-Hoskins-Rohan-Dennis-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T12:26:45+00:00

They were trackside sweethearts, the girl with the freewheeling spirit and the moody but brilliant cyclist who you always wanted in your team. They built a great life together - what happened?

## Fears for Gazza as former England star is found 'battered and bruised' outside Bournemouth Travelodge after argument with two people
 - [https://www.dailymail.co.uk/news/article-12918633/gazza-former-england-star-battered-bournemouth-travelodge-argument.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918633/gazza-former-england-star-battered-bournemouth-travelodge-argument.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T12:20:44+00:00

The legendary England midfielder - also affectionately known as Gazza - could 'barely string a sentence together' when he was spotted outside the Bournemouth budget hotel.

## 'Vigilante' motorist, 51, who posed as a traffic cop, put blue lights on his car and hunted for speeding drivers is convicted of impersonating police - after HE was pulled over by an officer
 - [https://www.dailymail.co.uk/news/article-12918703/Vigilante-motorist-51-posed-traffic-cop-blue-lights-car-hunted-speeding-drivers-convicted-impersonating-police-pulled-officer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918703/Vigilante-motorist-51-posed-traffic-cop-blue-lights-car-hunted-speeding-drivers-convicted-impersonating-police-pulled-officer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T11:28:47+00:00

Martin Goodall, 51, has been found guilty following a series of bogus traffic stops in his home town of Poole, Dorset.

## Extraordinary moment BBC's Mishal Husain says 's**t' SEVEN times live on air as she grills Home Secretary James Cleverly over his language
 - [https://www.dailymail.co.uk/news/article-12918487/bbc-mishal-husain-grills-james-cleverly-home-secretary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918487/bbc-mishal-husain-grills-james-cleverly-home-secretary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T10:23:27+00:00

During a segment on Radio 4's Today programme, Ms Husain began questioning the UK Home Secretary about a series of recent comments.

## Pyramid Video and Spice: Moment allegedly drunk driver smashes through Homebush West shop in Sydney pinning a worker against the wall
 - [https://www.dailymail.co.uk/news/article-12918231/Pyramid-Video-Spice-van-crashes-shop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918231/Pyramid-Video-Spice-van-crashes-shop.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T10:16:23+00:00

The van struck a 27-year-old female pedestrian and launched her into the store, Pyramid Video and Spice, and trapping her between the car and a wall.

## War over taxes as Rishi Sunak vows to put 'more money in people's pockets' while Labour creates new online 'calculator' to show cost of Tory hikes - and two-thirds of voters want election by the summer
 - [https://www.dailymail.co.uk/news/article-12918493/War-taxes-Rishi-Sunak-vows-money-peoples-pockets-Labour-online-calculator-summer-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918493/War-taxes-Rishi-Sunak-vows-money-peoples-pockets-Labour-online-calculator-summer-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T10:11:40+00:00

Rishi Sunak is expected to start trying to woo voters later this week with a pledge to put more cash back in their pockets.

## It can't be that bad! Workers heading back to the office today manifest Sonia from EastEnders and a disappointed Mo Salah for memes bemoaning the end of the festive break
 - [https://www.dailymail.co.uk/news/article-12918395/Workers-heading-office-Sonia-EastEnders-Mo-Salah-memes-festive-break.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918395/Workers-heading-office-Sonia-EastEnders-Mo-Salah-memes-festive-break.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T09:20:51+00:00

Taking to social media platform 'X' this morning, users posted in solidarity with sufferers of the back to work blues, sharing hilarious memes to help kickstart the New Year.

## Japan airliner inferno: Flames engulf jet plane at Tokyo international airport
 - [https://www.dailymail.co.uk/news/article-12918477/Jet-plane-seen-fire-runway-international-airport-Japan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918477/Jet-plane-seen-fire-runway-international-airport-Japan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T09:20:45+00:00

Shocking footage showed the jet engulfed in a raging inferno as it sat on the runway at Haneda Airport, in Ota City, Tokyo, with gouts of flame seen pouring out of the passenger windows

## Gunman 'lay in wait' for Brit EuroMillions winner Jane Park's gangster ex before horror Hogmanay shooting outside Edinburgh pub - as cops hunt attacker
 - [https://www.dailymail.co.uk/news/article-12918337/gunman-lay-waiting-euromillions-winner-gangster-ex-edinburgh-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918337/gunman-lay-waiting-euromillions-winner-gangster-ex-edinburgh-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T09:15:05+00:00

Armed police raced to the Anchor Inn in Edinburgh 's Granton area after shocked revellers saw Marc Webley gunned down in the street outside ten minutes before 12am.

## Moment one of Britain's most prolific shoplifting couples brazenly steal bottles of Irish Country Cream Liqueur on crime spree where they pinched hundreds of pounds worth of booze and hair straighteners
 - [https://www.dailymail.co.uk/news/article-12918311/Moment-one-Britains-prolific-shoplifting-couples-brazenly-steal-bottles-Irish-Country-Cream-Liqueur-crime-spree-pinched-hundreds-pounds-worth-booze-hair-straighteners.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918311/Moment-one-Britains-prolific-shoplifting-couples-brazenly-steal-bottles-Irish-Country-Cream-Liqueur-crime-spree-pinched-hundreds-pounds-worth-booze-hair-straighteners.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T09:11:31+00:00

CCTV footage shows Scott McSpadden, 39, brazenly walk into the supermarket in Cambridgeshire and load four bottles of the liqueur into a shopping bag just feet from the entrance.

## Passengers seen taking selfies while hanging out of a window of a car being driven by an L-plater
 - [https://www.dailymail.co.uk/news/article-12918175/L-Plate-passengers-taking-selfies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918175/L-Plate-passengers-taking-selfies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T08:42:37+00:00

Two passengers travelling in a car allegedly driven by an unaccompanied L-plater have been caught hanging out the windows of the vehicle and filming on their mobile phones at at Tidbinbilla in the ACT.

## The 6ft chain-smoking, hotdog-eating Tolkien-loving 'fashion icon' monarch who wept at her cousin Elizabeth II's funeral - and whose shock abdication has rocked Denmark: Inside the colourful life of 'Ashtray Queen' Margrethe
 - [https://www.dailymail.co.uk/news/article-12918233/Queen-Margrethe-Frederik-Mary-Denmark-abdication.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918233/Queen-Margrethe-Frederik-Mary-Denmark-abdication.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T08:12:44+00:00

Queen Margrethe II of Denmark shocked her nation and royal watchers worldwide by announcing her decision to abdicate. From January 14, her son Crown Prince Frederik will be King.

## Hampton East, Melbourne: Man is stabbed to death on a suburban street as major manhunt launched to find the killer
 - [https://www.dailymail.co.uk/news/article-12918269/Hampton-East-Melbourne-man-dead-stabbing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918269/Hampton-East-Melbourne-man-dead-stabbing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T08:11:33+00:00

A 46-year-old Melbourne man was on Tuesday found stabbed to death at the corner of Little Avenue and Widdop Crescent, in Hampton East, south east of Melbourne, with police launching an investigation.

## Black ESPN journalist says he was racially profiled by California home decor store employees who told him to use restroom in nearby police station because 'it's okay, they won't arrest you'
 - [https://www.dailymail.co.uk/news/article-12917821/Black-ESPN-Marc-J-Spears-Anthem-Janelle-Loevner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917821/Black-ESPN-Marc-J-Spears-Anthem-Janelle-Loevner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T06:59:10+00:00

Marc J Spears, 51, said he felt a depressing familiarity when he entered the store in Healdsburg, California, with his five friends during a dinner and wine tasting evening on Saturday.

## The Mighty Ducks star Brock Pierce, 43, sues his family friend for $80million after claiming he STOLE his beachfront Puerto Rico resort
 - [https://www.dailymail.co.uk/news/article-12918021/Brock-Pierce-Puerto-Rico-Resort-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918021/Brock-Pierce-Puerto-Rico-Resort-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T06:58:37+00:00

Former Disney child actor turned-crypto-billionaire Brock Pierce (left) is suing a family friend Joseph Lipsey III (right) who he claims stole his beach-front resort property on the island of Vieques.

## Royal Navy sailor is sacked for taking raunchy OnlyFans porn pics onboard HMS Prince of Wales aircraft carrier in '£20k-a-month side hussle' (and claims he's now a millionaire)
 - [https://www.dailymail.co.uk/news/article-12918185/Royal-Navy-sailor-sacked-taking-raunchy-OnlyFans-porn-pics-onboard-HMS-Prince-Wales-aircraft-carrier-20k-month-hussle-claims-hes-millionaire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918185/Royal-Navy-sailor-sacked-taking-raunchy-OnlyFans-porn-pics-onboard-HMS-Prince-Wales-aircraft-carrier-20k-month-hussle-claims-hes-millionaire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T06:58:12+00:00

The 21-year-old, who was paid £1,500-a-month as an able seaman, is now claiming that he's a millionaire thanks to his sex pics - and insists that his firing is actually the 'best thing'.

## Moment over SIXTY Miami cop cars swarm marketplace after brawl broke out between unruly youngsters armed with sticks and 'throwing fireworks'
 - [https://www.dailymail.co.uk/news/article-12918077/Moment-SIXTY-Miami-cop-cars-swarm-marketplace-brawl-broke-unruly-youngsters-armed-sticks-throwing-fireworks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918077/Moment-SIXTY-Miami-cop-cars-swarm-marketplace-brawl-broke-unruly-youngsters-armed-sticks-throwing-fireworks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T06:54:23+00:00

A video showed around 60 police vehicles swarming toward a marketplace in Miami Monday night after what police said was a gathering of juveniles who were armed with sticks.

## Mayor says NYE fireworks show in Sydney Harbour was about 'Blak power'
 - [https://www.dailymail.co.uk/news/article-12917709/Clover-Moore-NYE-fireworks-Blak-power-referendum-Voice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917709/Clover-Moore-NYE-fireworks-Blak-power-referendum-Voice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T06:49:37+00:00

Melbourne singer Angie McMahon took to the stage wearing a 'raise the age' t-shirt in reference to a campaign to increase the age of criminal responsibility in Australia, which is currently 10.

## I found £2million in gold bars hidden inside Iraqi tank that I bought on eBay- but I wish I had never handed them because it didn't earn me a penny
 - [https://www.dailymail.co.uk/news/article-12907325/I-2million-gold-bars-hidden-inside-Iraqi-tank-bought-eBay-wish-never-handed-didnt-earn-penny.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12907325/I-2million-gold-bars-hidden-inside-Iraqi-tank-bought-eBay-wish-never-handed-didnt-earn-penny.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T06:46:10+00:00

EXCLUSIVE: Nick Mead discovered the five gold bars stashed inside the diesel tank of the ex-Iraqi Army Type 69, a Chinese copy of the Soviet T-55, back in 2017.

## Ofsted inspections set to be paused in wake of Ruth Perry's suicide - as new chief Sir Martyn Oliver says watchdog could have been 'far more empathetic' in wake of headteacher's death
 - [https://www.dailymail.co.uk/news/article-12918151/Ofsted-inspections-set-paused-wake-Ruth-Perrys-suicide-new-chief-Sir-Martyn-Oliver-says-watchdog-far-empathetic-wake-headteachers-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918151/Ofsted-inspections-set-paused-wake-Ruth-Perrys-suicide-new-chief-Sir-Martyn-Oliver-says-watchdog-far-empathetic-wake-headteachers-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T06:25:56+00:00

Ruth Perry took her own life last January after an Ofsted report downgraded the school she led for more than a decade, Caversham Primary in Reading, from the highest grade to the lowest.

## Winner's response to winning $2.5million or a brand new house from The Block leaves Mr Lambo in disbelief
 - [https://www.dailymail.co.uk/news/article-12917893/Adrian-Portelli-Block-winner-millions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917893/Adrian-Portelli-Block-winner-millions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T05:59:43+00:00

Adrian Portelli, 34, was left shocked when he called Sydney woman Michelle to tell her that she had won her choice of $2.5million in cash or a $5million home.

## Secret hack to turn 23 days of annual leave to almost 50 days off
 - [https://www.dailymail.co.uk/news/article-12917881/Secret-hack-turn-23-days-annual-leave-50-days-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917881/Secret-hack-turn-23-days-annual-leave-50-days-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T05:59:06+00:00

Aussie workers can maximise their time off over the coming year by following some little-known hacks that involve planning annual leave days around public holiday dates throughout 2024.

## Body of teenager found on remote road in the Northern Territory
 - [https://www.dailymail.co.uk/news/article-12918125/Body-teenager-remote-road-Northern-Territory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918125/Body-teenager-remote-road-Northern-Territory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T05:54:46+00:00

The 19-year-old was discovered lying about 4km from sealed road on Undoolya Road, east of Alice Springs, at about 12:30pm on Monday.

## Rare 50c coin found in spare change leaves Aussies stunned
 - [https://www.dailymail.co.uk/news/article-12917609/Rare-50c-coin-worth-15.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917609/Rare-50c-coin-worth-15.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T05:15:33+00:00

An Aussie has shared a rare 50 cent coin they found in their spare change believed to be worth at least $15.

## Laverton North factory fire: Massive blaze erupts as firefighters race to the scene in Melbourne
 - [https://www.dailymail.co.uk/news/article-12918003/Factory-fire-Massive-blaze-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918003/Factory-fire-Massive-blaze-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T04:57:51+00:00

Firefighters have rushed to a factory to battle a massive blaze after the fire engulfed the facility in terrifying scenes.

## Olympic cyclist Rohan Dennis breaks his silence over the horror death of his wife - as the couple's two children are heard crying
 - [https://www.dailymail.co.uk/news/article-12918017/Cyclists-Rohan-Dennis-Melissa-Hoskins-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12918017/Cyclists-Rohan-Dennis-Melissa-Hoskins-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T04:53:47+00:00

Before walking out of the $2.45million Adelaide mansion just on Tuesday afternoon, Dennis pleaded for privacy and time for his two children to grieve for their mother Melissa Hoskins.

## Why a Harry Potter event has sparked fury among Aussies before it has even started
 - [https://www.dailymail.co.uk/news/article-12917681/Why-Harry-Potter-event-sparked-fury-Aussies-started.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917681/Why-Harry-Potter-event-sparked-fury-Aussies-started.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T04:52:05+00:00

The Mornington Peninsula Shire Council, southeast of Melbourne, is set to host the Harry Potter: A Forbidden Forest Experience at the Briars nature reserve in Mount Martha.

## Chicago mom, 34, is shot dead in front of her two children just HOURS before a court extended protection order against ex-boyfriend - who is charged with first-degree murder
 - [https://www.dailymail.co.uk/news/article-12917889/Chicago-mom-shot-dead-boyfriend-charged-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917889/Chicago-mom-shot-dead-boyfriend-charged-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T04:48:48+00:00

A Chicago woman was shot and killed in front of her two children just hours before her ex-boyfriend - who is now charged with murder - was set to be served with a protection order.

## Glamorous 'murder-for-hire' equestrian Tatyana Remley, 43, is sentenced to almost four years in prison in shock plea deal after hiring hitman to kill estranged husband for $2 million
 - [https://www.dailymail.co.uk/news/article-12917783/equestrian-Tatyana-Remley-sentenced-hitman-husband-mark-remley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917783/equestrian-Tatyana-Remley-sentenced-hitman-husband-mark-remley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T04:41:48+00:00

She denied solicitation to commit murder until Thursday when she cut a deal with the San Diego DA's office and was handed her sentence at Vista Superior Court

## Adelaide man scores $2.3m windfall in Saturday Lotto Megadraw after trip to Bunnings
 - [https://www.dailymail.co.uk/news/article-12917923/Bunnings-trip-man-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917923/Bunnings-trip-man-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T04:38:57+00:00

A 'spur-of-the-moment' decision during a standard Bunnings trip has made an Adelaide man an instant millionaire, winning more than $2.3m from Saturday's lottery draw.

## Wild footage captures New Year's Day nightmare at a popular beach in South Australia
 - [https://www.dailymail.co.uk/news/article-12917579/Wild-footage-captures-New-Years-Day-nightmare-popular-beach-South-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917579/Wild-footage-captures-New-Years-Day-nightmare-popular-beach-South-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T04:30:55+00:00

Access to Goolwa Beach came to a standstill for hours on Monday when there was a minor collision on the busy beach in South Australia .

## Wild moment driver is hauled out of her car after leading police on 100km chase and damaging eight cars
 - [https://www.dailymail.co.uk/news/article-12917839/Woman-driver-police-100km-chase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917839/Woman-driver-police-100km-chase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T04:26:23+00:00

Police allege the driver  refused to get out of her grey Mazda3 when she was first caught speeding at Pheasants Nest on the Hume Highway, in NSW, at about 10.30am on Monday.

## Bombshell twist in Sea World helicopter crash that killed four people and injured nine others - as report makes dramatic drug find
 - [https://www.dailymail.co.uk/news/article-12917831/Bombshell-twist-report-Sea-World-helicopter-crash-handed-one-year-devastating-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917831/Bombshell-twist-report-Sea-World-helicopter-crash-handed-one-year-devastating-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T03:48:18+00:00

The pilot who died in the horror Sea World helicopter crash had possible traces of cocaine in his system, a report has found exactly 12 months after the devastating tragedy.

## Detroit synagogue leader Samantha Woll was stabbed EIGHT times in the face and neck as she slept in her living room after a wedding - as new evidence suggests murder suspect's coat was stained with her blood
 - [https://www.dailymail.co.uk/news/article-12917901/Detroit-Samantha-Woll-stabbed-EIGHT-times-face-neck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917901/Detroit-Samantha-Woll-stabbed-EIGHT-times-face-neck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T03:42:52+00:00

Prosecutors said suspect Michael Jackson-Bolanos allegedly stabbed Jewish leader Samantha Woll eight times in the face and neck on the night of her murder.

## Harvard president Claudine Gay is hit with SIX NEW plagiarism claims- bringing the total number of accusations to nearly FIFTY
 - [https://www.dailymail.co.uk/news/article-12917891/Harvard-Claudine-Gay-NEW-plagiarism-accusations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917891/Harvard-Claudine-Gay-NEW-plagiarism-accusations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T03:31:21+00:00

Harvard University's embattled president has been hit with a further six accusations of plagiarism, bringing the total number of copying claims to nearly 50.

## Waikāinga Stream drowning: Perth boy and his cousin from Auckland are pictured for the first time after tragic drowning on NZ property
 - [https://www.dailymail.co.uk/news/article-12917807/Cousins-killed-drowning-tragedy-New-Zealand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917807/Cousins-killed-drowning-tragedy-New-Zealand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T03:31:06+00:00

Cousins Sonny, six, and Eddie, four, were killed when they fell off a UTV and drowned in the swollen Waikāinga Stream at a property in Peria on New Zealand's North Island.

## Aussie dad and Israeli Defence Force soldier Captain Lior Sivan killed by Hamas
 - [https://www.dailymail.co.uk/news/article-12917437/Aussie-dad-Israeli-Defence-Force-soldier-Captain-Lior-Sivan-killed-Hamas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917437/Aussie-dad-Israeli-Defence-Force-soldier-Captain-Lior-Sivan-killed-Hamas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T03:01:47+00:00

An Aussie dad serving with the Israeli Defence Force has been killed by Hamas militants in Gaza while awaiting leave to be with his wife for the birth of their second child.

## Prisoner found naked in his girlfriend's cell after scaling two fences at maximum security prison
 - [https://www.dailymail.co.uk/news/article-12917689/Prisoner-naked-cell-female-lover-Clarence-Correctional-Centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917689/Prisoner-naked-cell-female-lover-Clarence-Correctional-Centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T02:49:06+00:00

An inmate managed to leave his unit at Clarence Correctional Centre near Grafton in northern NSW on Saturday and get into his girlfriend's cell for an end-of-year tryst.

## Grim discovery at Lowood after man's body is found inside his home
 - [https://www.dailymail.co.uk/news/article-12917827/Grim-discovery-Lowood-mans-body-inside-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917827/Grim-discovery-Lowood-mans-body-inside-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T02:46:54+00:00

A murder investigation has been launched following the discovery of a man's body at a home in Lowood, west of Brisbane, on Tuesday morning.

## Mum was raised by monkeys in the Colombian jungle... now I'm leaving Bradford to follow in her footsteps
 - [https://www.dailymail.co.uk/news/article-12917733/Mum-raised-monkeys-Colombian-jungle-vanessa-forero-marina-chapman-ben-fogle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917733/Mum-raised-monkeys-Colombian-jungle-vanessa-forero-marina-chapman-ben-fogle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T02:25:32+00:00

Marina Chapman claimed she grew up in the company of white-faced capuchins in the wilds of Colombia after being kidnapped and abandoned by people traffickers when she was four years old.

## German shepherd leads woman to body of his DEAD owner who had been deceased for a WEEK before neighborhood rallies to catch the distressed pet and find him a new home
 - [https://www.dailymail.co.uk/news/article-12917619/German-shepherd-leads-woman-body-DEAD-owner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917619/German-shepherd-leads-woman-body-DEAD-owner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T02:19:30+00:00

Catherine DeFazio had seen online warnings about a German shepherd that had been appearing unleashed around her Sacramento neighborhood.

## The centre of the Roman Empire was once in... Carlisle! Archaeologists make fascinating discovery following six years of excavation
 - [https://www.dailymail.co.uk/news/article-12917799/The-centre-Roman-Empire-Carlisle-Archaeologists-make-fascinating-discovery-following-six-years-excavation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917799/The-centre-Roman-Empire-Carlisle-Archaeologists-make-fascinating-discovery-following-six-years-excavation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T02:09:05+00:00

Following six years of excavation, experts have concluded that a 160ft bath house discovered in a cricket club in the Cumbrian city in 2017 may have been built for a Roman emperor.

## Aussie collectable coin featuring highly anticipated new feature is released
 - [https://www.dailymail.co.uk/news/article-12917187/Aussie-collectable-coin-King-Charles-III-printed-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917187/Aussie-collectable-coin-King-Charles-III-printed-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T02:05:22+00:00

The 'Out Of This World' coin pays homage to Australia's contribution to space exploration and includes references to the first satellite launch and Apollo 11 moon landing.

## Public defender pleads for $41,720 to pay off her five credit cards, buy a house and retire after breast cancer diagnosis, divorce and a failed law firm but admits she does NOT deserve sympathy
 - [https://www.dailymail.co.uk/news/article-12917555/beth-bourdon-public-defender-gofundme-house-orlando.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917555/beth-bourdon-public-defender-gofundme-house-orlando.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:46:31+00:00

Beth Bourdon, an Orlando-based public defender known for her FOIA work assisting journalists, has launched a GoFundMe campaign to enable her to buy a house and retire amid her cancer battle.

## British doctor calls for rules of war to be re-drawn to 'stop horrors of Gaza ever happening again'
 - [https://www.dailymail.co.uk/news/article-12917669/British-doctor-spent-48-nights-drowning-sea-casualties-Gaza-describes-horror-war-including-injuries-scale-not-seen-previous-wars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917669/British-doctor-spent-48-nights-drowning-sea-casualties-Gaza-describes-horror-war-including-injuries-scale-not-seen-previous-wars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:39:55+00:00

Dr Ghassan Abu-Sittah returned from the Palestinian enclave to east London almost a month ago and now is collaborating with the International Criminal Court investigation.

## Single mom's concrete DRIVEWAY is stolen by scamming thieves after she put Florida home on the market - leaving her with dirt track and $10k bill to replace it
 - [https://www.dailymail.co.uk/news/article-12917643/Florida-woman-driveway-stolen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917643/Florida-woman-driveway-stolen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:38:42+00:00

Amanda Brochu said shortly after she listed her home for sale, people started showing up trying to measure her driveway. Then one day her doorbell camera showed crews ripping out the concrete.

## Aboriginal land claim rocks one of Australia's wealthiest suburbs as Indigenous group lobbies for a massive chunk of prime parkland
 - [https://www.dailymail.co.uk/news/article-12917503/Aboriginal-land-claim-Hunters-Hill-prime-parkland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917503/Aboriginal-land-claim-Hunters-Hill-prime-parkland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:36:42+00:00

A Sydney council has flagged it will fight a claim of a piece of prime inner city foreshore parkland by an Indigenous Land Council.

## No-nonsense driver's bold act after woman tries to reserve a parking spot in Victoria by standing in it
 - [https://www.dailymail.co.uk/news/article-12917499/woman-tries-reserve-parking-spot-standing-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917499/woman-tries-reserve-parking-spot-standing-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:23:53+00:00

An Aussie driver has been praised online for taking direct action - caught on dashcam - on a woman who tried to hold a car park spot by standing in the space.

## More than 270,000 divorces are delayed because of the cost of living crisis with a fifth being held up by financial pressures, service providers claim
 - [https://www.dailymail.co.uk/news/article-12917737/More-270-000-divorces-delayed-cost-living-crisis-fifth-held-financial-pressures-service-providers-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917737/More-270-000-divorces-delayed-cost-living-crisis-fifth-held-financial-pressures-service-providers-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:18:06+00:00

Financial pressures delayed 19% of divorces, with marital break-ups particularly affected since 2020, researchers at Legal and General found.

## Mill Park explosion: Cause of massive fire that left 15 New Year's Eve revellers injured is revealed
 - [https://www.dailymail.co.uk/news/article-12917625/Mill-Park-explosion-Cause-massive-fire-left-15-New-Years-Eve-revellers-injured-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917625/Mill-Park-explosion-Cause-massive-fire-left-15-New-Years-Eve-revellers-injured-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:12:21+00:00

Fifteen people were injured and eight were left with serious burns after the blaze erupted in the backyard of a property in Mill Park, in Melbourne's north-east, at about 11.10pm on Sunday night.

## Corking time in the House of Lords as its champagne sales rise to the highest level in five years to £90,000
 - [https://www.dailymail.co.uk/news/article-12917699/Corking-time-House-Lords-champagne-sales-rise-highest-level-five-years-90-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917699/Corking-time-House-Lords-champagne-sales-rise-highest-level-five-years-90-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:07:03+00:00

The cost is up slightly from the 2022 total, when 1,580 bottles were sold at a cost of £85,462.51. In 2020, the year Covid-19 hit the UK, sales of champagne in the House of Lords amounted to just £8,982.

## Bike theft in the UK has been effectively 'decriminalised' after more than 365,000 cases go unsolved over the past five years, the Lib Dems claim
 - [https://www.dailymail.co.uk/news/article-12917707/Bike-theft-UK-effectively-decriminalised-365-000-cases-unsolved-past-five-years-Lib-Dems-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917707/Bike-theft-UK-effectively-decriminalised-365-000-cases-unsolved-past-five-years-Lib-Dems-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:06:42+00:00

The 365,706 unsolved crimes since 2019 amounted to 89 per cent of all bike thefts over the period. Only two per cent of cases - 8,437 incidents - led to a suspect being charged.

## Couple slammed for taking an inflatable raft out onto Sydney Harbour for NYE fireworks
 - [https://www.dailymail.co.uk/news/article-12917471/Couple-slammed-taking-inflatable-raft-Sydney-Harbour-NYE-fireworks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917471/Couple-slammed-taking-inflatable-raft-Sydney-Harbour-NYE-fireworks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T01:02:47+00:00

Daya Medina and her husband decided to take matters into their own hands after discovering it would cost them $700 each to watch the New Year's Eve fireworks in Sydney from a boat.

## DAILY MAIL COMMENT: Should virtual 'crime' be a police matter?
 - [https://www.dailymail.co.uk/news/article-12917695/DAILY-MAIL-COMMENT-virtual-crime-police-matter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917695/DAILY-MAIL-COMMENT-virtual-crime-police-matter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T00:54:56+00:00

DAILY MAIL COMMENT: Treating this as a criminal case raises a huge question for the police. Once they start investigating imaginary crimes, however realistic, where do they stop?

## Pastor is arrested for attempting to shove wife's co-worker's head into a McDonald's deep fryer in North Carolina after she called him claiming colleagues were 'disrespecting' her
 - [https://www.dailymail.co.uk/news/article-12917425/paster-dwayne-wayden-deep-fryer-mcdonalds-high-point.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917425/paster-dwayne-wayden-deep-fryer-mcdonalds-high-point.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T00:50:12+00:00

High Point pastor Dwayne Wayden grabbed the cook and started shoving his head towards one of the fryers where temperatures reach up to 400 degrees, police reported.

## Northbridge arrest: WA cops repeatedly punch NYE reveller during dramatic arrest in Perth
 - [https://www.dailymail.co.uk/news/article-12917257/Wild-cops-punch-NYE-reveller.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917257/Wild-cops-punch-NYE-reveller.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T00:36:09+00:00

The dramatic arrest unfolded outside The Brass Monkey Hotel in Northbridge in Perth just minutes after revellers rang in 2024.

## Brett and Belinda lost their 17-year-old boy after he was stabbed during a brawl four years ago. The devastated parents have been left 'sick to their guts' after learning their son's killer will be freed in days
 - [https://www.dailymail.co.uk/news/article-12917335/Jack-Beasley-parents-sick-guts-killer-freed-Surfers-Paradise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917335/Jack-Beasley-parents-sick-guts-killer-freed-Surfers-Paradise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T00:35:46+00:00

The parents of murdered teen Jack Beasley say they were given less only three days to object to one of their son's killers being let out of jail after he spent just four years inside.

## Rishi Sunak faces calls for an inquiry into his 'secret' meetings with Dominic Cummings after the PM met with the former Boris Johnson adviser to discuss bringing him back to run the Tories' election campaign
 - [https://www.dailymail.co.uk/news/article-12917661/Rishi-Sunak-faces-calls-inquiry-secret-meetings-Dominic-Cummings-PM-met-former-Boris-Johnson-adviser-discuss-bringing-run-Tories-election-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917661/Rishi-Sunak-faces-calls-inquiry-secret-meetings-Dominic-Cummings-PM-met-former-Boris-Johnson-adviser-discuss-bringing-run-Tories-election-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T00:35:17+00:00

Mr Cummings confirmed the meetings took place in December 2022 and July 2023 in a blog post, claiming he had turned down an offer to 'work secretly' for Mr Sunak.

## Olympic cyclist Melissa Hoskins was 'planning a new life' with her husband Rohan Dennis before he allegedly killed her outside their $2.45m home
 - [https://www.dailymail.co.uk/news/article-12917323/Cyclists-Rohan-Dennis-Melissa-Hoskins-Adelaide-plans-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917323/Cyclists-Rohan-Dennis-Melissa-Hoskins-Adelaide-plans-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T00:29:45+00:00

World champion cyclists Melissa Hoskins and Rohan Dennis were reportedly planning a new life together in South Australia 's Adelaide Hills before he allegedly killed her on Saturday night.

## Border Patrol agent illegally turns away asylum-seeking migrants who had already made it into Texas
 - [https://www.dailymail.co.uk/news/article-12915159/Border-Patrol-agent-illegally-turns-away-asylum-seeking-migrants-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12915159/Border-Patrol-agent-illegally-turns-away-asylum-seeking-migrants-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T00:16:08+00:00

A US Border Patrol agent sent a family of asylum-seekers back to Mexico after they had reached US soil-- a violation of US law and Border Patrol policy.

## Jersey Shore star Angelina Pivarnick, 37, puts on sultry show at New Jersey strip club as she dances around pole
 - [https://www.dailymail.co.uk/news/article-12917563/Jersey-Shore-star-Angelina-Pivarnick-37-puts-sultry-New-Jersey-strip-club-dances-pole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12917563/Jersey-Shore-star-Angelina-Pivarnick-37-puts-sultry-New-Jersey-strip-club-dances-pole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-01-02T00:14:02+00:00

Original Jersey Shore cast member Angelina Pivarnick was seen wrapping up her 2023 by putting on an adults-only show for the holidays at a Garden State strip club.

