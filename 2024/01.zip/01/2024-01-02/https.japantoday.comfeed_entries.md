# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## Earthquake shatters New Year calm in Japan
 - [https://japantoday.com/category/national/Earthquake-shatters-New-Year-calm-in-Japan](https://japantoday.com/category/national/Earthquake-shatters-New-Year-calm-in-Japan)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:24:06+00:00

Waiting in the cold, hundreds of residents of the earthquake-hit Ishikawa town of Shika stood in a queue to get rations of a suddenly scarce, but vital, commodity:…

## Rooney hit hard by 'setback' after Birmingham City sacking
 - [https://japantoday.com/category/sports/rooney-hit-hard-by-%27setback%27-after-birmingham-city-sacking](https://japantoday.com/category/sports/rooney-hit-hard-by-%27setback%27-after-birmingham-city-sacking)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:22:53+00:00

Wayne Rooney said it would &quot;take some time to get over this setback&quot; after he was sacked as manager of Championship side Birmingham City on Tuesday following a…

## Nadal roars back with 'emotional and important' win over Thiem
 - [https://japantoday.com/category/sports/nadal-roars-back-with-%27emotional-and-important%27-win-over-thiem](https://japantoday.com/category/sports/nadal-roars-back-with-%27emotional-and-important%27-win-over-thiem)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:22:44+00:00

Rafael Nadal won his first match back from a year-long injury layoff when he beat former U.S. Open champion Dominic Thiem at the Brisbane International on Tuesday, calling…

## Djokovic and his sore right wrist help Serbia reach United Cup quarters
 - [https://japantoday.com/category/sports/djokovic-and-his-sore-right-wrist-advance-serbia-to-the-united-cup-quarterfinals-in-perth](https://japantoday.com/category/sports/djokovic-and-his-sore-right-wrist-advance-serbia-to-the-united-cup-quarterfinals-in-perth)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:22:35+00:00

Novak Djokovic endured a wrist injury to lead Serbia into a United Cup mixed teams quarterfinal showdown against host Australia.
The world No. 1 was troubled by his…

## China's Baidu cancels $3.6 bil purchase of livestreaming site
 - [https://japantoday.com/category/tech/china%27s-baidu-cancels-3.6-bn-purchase-of-livestreaming-site](https://japantoday.com/category/tech/china%27s-baidu-cancels-3.6-bn-purchase-of-livestreaming-site)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:22:02+00:00

Chinese internet giant Baidu has said it was cancelling the planned multi-billion-dollar purchase of livestreaming platform YY Live, partly blaming its inability to get government approval.
Baidu, the…

## Mickey Mouse horror films announced as Disney copyright expires
 - [https://japantoday.com/category/entertainment/mickey-mouse-horror-films-announced-as-disney-copyright-expires](https://japantoday.com/category/entertainment/mickey-mouse-horror-films-announced-as-disney-copyright-expires)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:21:33+00:00

Oh boy! Barely 24 hours after Disney's initial copyright on Mickey Mouse expired, two new indie horror films starring the beloved character have been announced.
&quot;Steamboat Willie,&quot; the…

## Heart stimulants saw biggest Japan sales rise in 2023 on tourist demand
 - [https://japantoday.com/category/business/heart-stimulants-saw-biggest-2023-japan-sales-rise-on-tourist-demand](https://japantoday.com/category/business/heart-stimulants-saw-biggest-2023-japan-sales-rise-on-tourist-demand)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:20:56+00:00

Products popular with tourists saw big sales increases in Japan in 2023, with heart stimulants seeing the largest year-on-year rise among daily consumer goods, reflecting growing demand amid…

## Man arrested after assaulting father with sake bottle
 - [https://japantoday.com/category/crime/man-arrested-after-assaulting-father-with-sake-bottle](https://japantoday.com/category/crime/man-arrested-after-assaulting-father-with-sake-bottle)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:20:10+00:00

Police in Asahikawa, Hokkaido, said Tuesday they have arrested a 28-year-old man on suspicion of assaulting his 50-year-old father by hitting him on the head with a sake…

## France to send forensic experts to Tokyo after airport collision
 - [https://japantoday.com/category/national/france-to-send-forensic-experts-to-tokyo-after-airport-collision1](https://japantoday.com/category/national/france-to-send-forensic-experts-to-tokyo-after-airport-collision1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:19:30+00:00

A team of forensic experts from planemaker Airbus and French state agency BAE will arrive in Japan on Wednesday to help authorities investigate the deadly accident involving a…

## Death toll reaches 57 in Ishikawa quake
 - [https://japantoday.com/category/national/Death-toll-reaches-57-in-Ishikawa-quake](https://japantoday.com/category/national/Death-toll-reaches-57-in-Ishikawa-quake)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:18:38+00:00

A series of powerful earthquakes that hit western Japan have left at least 57 people dead and damaged thousands of buildings, vehicles and boats. Officials warned Tuesday that…

## Escaped passengers recall tense moments in Japan Airlines jet blaze
 - [https://japantoday.com/category/national/escaped-passengers-recall-tense-moments-in-japan-airlines-jet-blaze](https://japantoday.com/category/national/escaped-passengers-recall-tense-moments-in-japan-airlines-jet-blaze)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:18:16+00:00

Passengers expressed their relief and recalled tense moments following their narrow escape from a Japan Airlines jet that caught fire after colliding with a Japan Coast Guard airplane…

## Gunman breaks into Colorado Supreme Court building
 - [https://japantoday.com/category/world/gunman-breaks-into-colorado-supreme-court-building-intrusion-unrelated-to-trump-case-police-say](https://japantoday.com/category/world/gunman-breaks-into-colorado-supreme-court-building-intrusion-unrelated-to-trump-case-police-say)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:13:43+00:00

A man leaving the scene of a car wreck Tuesday shot his way into the Colorado Supreme Court building and inflicted “extensive damage” to the building before being…

## Sister of North Korean leader derides South Korea's president but praises his predecessor
 - [https://japantoday.com/category/world/sister-of-north-korean-leader-derides-south-korea%27s-president-but-praises-his-predecessor](https://japantoday.com/category/world/sister-of-north-korean-leader-derides-south-korea%27s-president-but-praises-his-predecessor)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:13:34+00:00

The powerful sister of North Korean leader Kim Jong Un has derided South Korea’s conservative president for being “foolishly brave” but called his liberal predecessor “smart&quot; — rhetoric…

## Brother of powerful Colombian senator pleads guilty in New York to narcotics smuggling charge
 - [https://japantoday.com/category/world/brother-of-powerful-colombian-senator-pleads-guilty-in-new-york-to-narcotics-smuggling-charge](https://japantoday.com/category/world/brother-of-powerful-colombian-senator-pleads-guilty-in-new-york-to-narcotics-smuggling-charge)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:13:22+00:00

The brother of a powerful leftist senator in Colombia pleaded guilty Tuesday to federal narcotics charges as part of a sting in which he offered to introduce U.S.…

## Biden administration asks Supreme Court to allow border agents to cut razor wire installed by Texas
 - [https://japantoday.com/category/world/biden-administration-asks-supreme-court-to-allow-border-agents-to-cut-razor-wire-installed-by-texas](https://japantoday.com/category/world/biden-administration-asks-supreme-court-to-allow-border-agents-to-cut-razor-wire-installed-by-texas)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:13:13+00:00

The Biden administration is asking the Supreme Court to allow Border Patrol agents to cut razor wire that Texas installed on the U.S.-Mexico border, while a lawsuit over…

## Turkey detains 34 suspected of spying for Israel
 - [https://japantoday.com/category/world/turkey-detains-33-accused-of-spying-for-israel](https://japantoday.com/category/world/turkey-detains-33-accused-of-spying-for-israel)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:13:03+00:00

Turkey announced on Tuesday it had detained 34 people suspected of planning abductions and spying on behalf of Israel's Mossad intelligence service.
The raids came just weeks after…

## Russian missiles hit Ukrainian cities, killing 5 and injuring at least 130, Kyiv officials say
 - [https://japantoday.com/category/world/heavy-russian-missile-attacks-hit-ukraine%27s-2-largest-cities](https://japantoday.com/category/world/heavy-russian-missile-attacks-hit-ukraine%27s-2-largest-cities)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:12:53+00:00

Ukraine's two largest cities came under attack early Tuesday from Russian missiles that killed five people and injured as many as 130, officials said, as the war approached…

## S Africa's genocide case against Israel sets up high-stakes legal battle at U.N.'s top court
 - [https://japantoday.com/category/world/south-africa%27s-genocide-case-against-israel-sets-up-a-high-stakes-legal-battle-at-the-un%27s-top-court](https://japantoday.com/category/world/south-africa%27s-genocide-case-against-israel-sets-up-a-high-stakes-legal-battle-at-the-un%27s-top-court)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:12:26+00:00

South Africa has launched a case at the United Nations' top court alleging that Israel's military campaign in Gaza amounts to genocide.
The filing and Israel's decision to…

## Apparent Israeli strike kills senior Hamas figure in Beirut and raises fears conflict could expand
 - [https://japantoday.com/category/world/fighting-in-southern-gaza-city-after-israel-says-it-is-pulling-thousands-of-troops-from-other-areas](https://japantoday.com/category/world/fighting-in-southern-gaza-city-after-israel-says-it-is-pulling-thousands-of-troops-from-other-areas)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T21:12:17+00:00

An apparent Israeli strike in the Lebanese capital of Beirut killed Hamas' No. 2 political leader Tuesday, marking a potentially significant escalation of Israel's war against the militant…

## Wajima quake damage
 - [https://japantoday.com/category/picture-of-the-day/wajima-quake-damage](https://japantoday.com/category/picture-of-the-day/wajima-quake-damage)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T20:57:27+00:00

This satellite image provided by Maxar Technologies shows a damaged neighborhood in Wajima, Prefecture, on Tuesday. A series of powerful earthquakes that hit western Japan have left at…

## JAL plane on fire after collision with coast guard aircraft at Haneda
 - [https://japantoday.com/category/national/JAL-plane-on-fire-after-collision-with-coast-guard-aircraft-at-Haneda](https://japantoday.com/category/national/JAL-plane-on-fire-after-collision-with-coast-guard-aircraft-at-Haneda)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T10:21:32+00:00

A Japan Airlines aircraft with 379 passengers and crew on board burst into flames on a runway at Tokyo's Haneda airport on Tuesday night after a collision with…

## JAL plane on fire after collision with coast guard aircraft at Haneda
 - [https://japantoday.com/category/national/japan-airlines-plane-on-fire-after-possible-crash-with-coast-guard-aircraft-media](https://japantoday.com/category/national/japan-airlines-plane-on-fire-after-possible-crash-with-coast-guard-aircraft-media)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T09:49:27+00:00

A Japan Airlines aircraft with 379 passengers and crew still on board was on fire on a runway at Tokyo's Haneda airport on Tuesday night after a collision…

## Man arrested for assaulting mother after she intervened in fight with his wife
 - [https://japantoday.com/category/crime/man-arrested-for-assaulting-mother-after-she-intervened-in-fight-with-his-wife](https://japantoday.com/category/crime/man-arrested-for-assaulting-mother-after-she-intervened-in-fight-with-his-wife)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T06:40:29+00:00

Police in Hakodate, Hokkaido, have arrested a 43-year-old man on suspicion of assaulting his mother who is in her 70s on Monday night.
According to police, the incident…

## Revamped NISA program launched to spur investment wave in Japan
 - [https://japantoday.com/category/business/revamped-nisa-program-launched-to-spur-investment-wave-in-japan](https://japantoday.com/category/business/revamped-nisa-program-launched-to-spur-investment-wave-in-japan)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T06:39:37+00:00

Japan revamped its NISA tax-free stock investment program for individuals on Monday, reinforcing the country's efforts to encourage a shift from savings to investments in the equities market.…

## Rescue teams search for quake survivors as death toll reaches 30
 - [https://japantoday.com/category/national/japan-races-to-find-new-year%27s-day-quake-survivors](https://japantoday.com/category/national/japan-races-to-find-new-year%27s-day-quake-survivors)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T06:38:29+00:00

At least 30 people were killed after a powerful earthquake hit Ishikawa Prefecture on New Year's Day, with rescue teams on Tuesday struggling to reach isolated areas where buildings…

## South Korean opposition leader attacked by unidentified man
 - [https://japantoday.com/category/world/south-korean-opposition-leader-is-attacked-and-injured-by-an-unidentified-man-officials-say](https://japantoday.com/category/world/south-korean-opposition-leader-is-attacked-and-injured-by-an-unidentified-man-officials-say)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T02:49:54+00:00

South Korean opposition leader Lee Jae-myung was attacked and injured by an unidentified man during a visit Tuesday to the southeastern city of Busan, emergency officials said.
Busan’s…

## China sees robust travel, tourism demand during New Year's Day holiday
 - [https://japantoday.com/category/world/china-sees-robust-travel-tourism-demand-during-new-year%27s-day-holiday](https://japantoday.com/category/world/china-sees-robust-travel-tourism-demand-during-new-year%27s-day-holiday)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T01:28:11+00:00

Travel in China flourished over the three-day New Year's holiday, with 135 million domestic tourist trips, up 155% from last year, while domestic tourism revenue rose to 79.73…

## New women's North American hockey league launches
 - [https://japantoday.com/category/sports/new-women%27s-north-american-hockey-league-launches](https://japantoday.com/category/sports/new-women%27s-north-american-hockey-league-launches)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T00:38:27+00:00

Women's ice hockey kicked off the new year with the launch of a new professional league, which debuted Monday with the very first match between the Toronto and…

## Salah scores twice to send Liverpool clear
 - [https://japantoday.com/category/sports/salah-swaps-out-unlucky-boots-to-send-liverpool-clear](https://japantoday.com/category/sports/salah-swaps-out-unlucky-boots-to-send-liverpool-clear)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T00:37:57+00:00

Mohamed Salah credited a half-time change of boots after scoring twice to send Liverpool three points clear at the top of the Premier League with a 4-2 win…

## Russia rounds up thousands of migrants at New Year's Eve festivities
 - [https://japantoday.com/category/world/russia-rounds-up-thousands-of-migrants-at-new-year%27s-eve-festivities-reports](https://japantoday.com/category/world/russia-rounds-up-thousands-of-migrants-at-new-year%27s-eve-festivities-reports)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-01-02T00:36:47+00:00

Russia's police have detained thousands of migrants across the country in New Year's Eve raids with scores of them facing deportation, Russian media reported on Monday.
About 3,000…

