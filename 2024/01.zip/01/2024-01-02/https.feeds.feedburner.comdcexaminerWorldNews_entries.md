# Source:Washington Examiner - world, URL:https://feeds.feedburner.com/dcexaminer/WorldNews, language:en-US

## South Korean opposition leader stabbed in the neck in Busan
 - [https://www.washingtonexaminer.com/news/south-korean-opposition-leader-stabbed-in-busan](https://www.washingtonexaminer.com/news/south-korean-opposition-leader-stabbed-in-busan)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/WorldNews
 - date published: 2024-01-02T03:11:52+00:00

South Korean opposition leader Lee Jae-myung was stabbed by a man while attending an event in the city of Busan at around 10:30 a.m. Tuesday, local time.

