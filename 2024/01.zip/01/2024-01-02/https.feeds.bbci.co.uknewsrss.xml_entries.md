# Source:BBC, URL:https://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The Traitors: Welshman spurred by near-fatal crash
 - [https://www.bbc.co.uk/news/uk-wales-67863730?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-67863730?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T22:58:45+00:00

Andrew Jenkins hopes surviving a car crash will help inspire others that they can fight and win.

## Scammer told bank fraud victim 'you're so thick'
 - [https://www.bbc.co.uk/news/uk-wales-67865410?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-67865410?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T22:58:35+00:00

Wendy Falconer says she was verbally abused by the man who pretended to be calling from her bank.

## Trump challenges his 'arbitrary' removal from Maine's ballot
 - [https://www.bbc.co.uk/news/world-us-canada-67869363?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67869363?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T22:50:42+00:00

The court filing accuses Maine's top electoral official of being a "biased decision maker".

## West Ham 0-0 Brighton: Journalists are happy that we kept a clean sheet - De Zerbi
 - [https://www.bbc.co.uk/sport/av/football/67868591?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67868591?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T22:33:43+00:00

Brighton boss Roberto de Zerbi jokes the media will be "happy" after Brighton keep their first Premier League clean sheet of the season in their 0-0 draw at West Ham.

## Garth Crooks' Team of the Week: Turner, Kilman, Palmer, Salah
 - [https://www.bbc.co.uk/sport/football/67865895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67865895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T22:29:58+00:00

Which players impressed our football pundit Garth Crooks enough to make his latest Team of the Week?

## Police investigate virtual sex assault on girl's avatar
 - [https://www.bbc.co.uk/news/technology-67865327?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67865327?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T22:08:22+00:00

The incident in a virtual world reportedly left the under-16-year-old traumatised.

## Littler, 16, beats Cross to storm into darts World final
 - [https://www.bbc.co.uk/sport/darts/67868664?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/darts/67868664?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T22:01:11+00:00

Teenager Luke Littler beats 2018 champion Rob Cross to storm into the final of PDC World Darts Championship.

## West Ham United 0-0 Brighton & Hove Albion: Dour goalless draw at London Stadium
 - [https://www.bbc.co.uk/sport/football/67821084?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67821084?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T21:32:18+00:00

West Ham and Brighton share the points in a dour Premier League goalless draw at London Stadium, with both sides now in European qualification places.

## Who was Hamas leader Saleh al-Arouri killed in Beirut?
 - [https://www.bbc.co.uk/news/world-67868754?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-67868754?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T21:30:03+00:00

The 57-year-old was deputy head of Hamas's political bureau and helped establish the group's military wing.

## Kids Company founder Camila Batmanghelidjh dies
 - [https://www.bbc.co.uk/news/uk-67868843?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67868843?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T20:57:32+00:00

The social justice campaigner died on her birthday, aged 61, after being ill for sometime.

## Hamas deputy leader Saleh al-Arouri killed in Beirut blast
 - [https://www.bbc.co.uk/news/world-middle-east-67866346?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67866346?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T20:42:42+00:00

Saleh al-Arouri is the most senior Hamas figure killed since the Israel-Hamas war began in October.

## Storm Henk: Parts of southern England battered in high winds
 - [https://www.bbc.co.uk/news/uk-67868616?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67868616?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T19:54:46+00:00

Trees have damaged cars, scaffolding has been blown down and rail lines have been disrupted across the south of England.

## Japan Airlines: How the passenger plane burst into flames
 - [https://www.bbc.co.uk/news/world-asia-67868143?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67868143?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T19:18:03+00:00

A professor in investigating accidents tells the BBC what might have caused the plane to burst into flames.

## Simon Rimmer's vegetarian restaurant in Didsbury shuts after 33 years
 - [https://www.bbc.co.uk/news/uk-england-manchester-67864511?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-67864511?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T18:56:21+00:00

Simon Rimmer blames a 35% rent rise and increased costs for the closure of Greens in Didsbury.

## Claudine Gay resigns as Harvard University president
 - [https://www.bbc.co.uk/news/world-us-canada-67868280?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67868280?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T18:55:37+00:00

The university's top official resigns after facing allegations of plagiarism and criticism over her comments on antisemitism.

## St Mirren 0-3 Celtic: Maeda, O'Riley & Taylor score in comfortable win
 - [https://www.bbc.co.uk/sport/football/67821042?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67821042?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T18:54:17+00:00

Celtic score twice in the opening six minutes on the way to beating St Mirren and maintaining their eight-point lead at the summit of the Scottish Premiership.

## Hundreds turn out in Salford for Joe Wicks 5k
 - [https://www.bbc.co.uk/news/uk-england-manchester-67868430?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-67868430?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T18:39:45+00:00

The Body Coach helped the people of Salford kick off some new year goals with a 5k run, jog or walk.

## Jadon Sancho: Manchester United winger might rejoin Borussia Dortmund on loan
 - [https://www.bbc.co.uk/sport/football/67866001?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67866001?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T18:20:34+00:00

Manchester United outcast Jadon Sancho might kickstart his career with a January loan move to former club Borussia Dortmund.

## Israel to fight South Africa's Gaza genocide claim in court
 - [https://www.bbc.co.uk/news/world-middle-east-67866342?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67866342?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T18:02:44+00:00

South Africa accused Israel of committing genocide in Gaza, triggering Israeli outrage.

## Japan jet crash: Passengers describe chaos inside flight 516
 - [https://www.bbc.co.uk/news/world-asia-67865132?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67865132?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T17:37:03+00:00

Nearly 400 people were trapped inside a burning JAL 516. What happened next has been described as a miracle.

## Livingston 1-2 Hearts: Hearts five clear in third as Livi woes continue
 - [https://www.bbc.co.uk/sport/football/67821046?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67821046?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T17:32:58+00:00

Hearts move five points clear in third place in the Scottish Premiership as they pile the misery on Livingston, who have now lost 11 of their last 13 games.

## Rangers 3-1 Kilmarnock: Abdallah Sima stunner as hosts get back to winning ways
 - [https://www.bbc.co.uk/sport/football/67821045?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67821045?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T16:57:44+00:00

Abdallah Sima scores a stunning volley as Rangers return to winning ways in the Scottish Premiership against Kilmarnock.

## Sunderland footballer Jack Diamond 'raped woman in his home'
 - [https://www.bbc.co.uk/news/uk-england-wear-67861047?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-wear-67861047?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T16:43:45+00:00

Jack Diamond denies raping and sexual assaulting a woman he met on a dating app.

## London New Year fireworks: Fake tickets to blame for issues says City Hall
 - [https://www.bbc.co.uk/news/uk-england-london-67862825?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67862825?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T16:09:36+00:00

City Hall made the comments as people took to social media to complain about the event's organisation.

## What is behind Turkey's staunch support for Hamas in Gaza?
 - [https://www.bbc.co.uk/news/world-europe-67861266?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67861266?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T15:50:59+00:00

Turkey has vociferously criticised Israel during the Gaza war, risking recently rebuilt relations.

## Nandre Burger: The smiling South African quick defying calls for more menace
 - [https://www.bbc.co.uk/sport/cricket/67866212?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67866212?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T15:39:39+00:00

Nandre Burger laughs off criticism from Kevin Pietersen that he is too smiley on the cricket pitch.

## UK weather: 2023 was second warmest year ever, says Met Office
 - [https://www.bbc.co.uk/news/science-environment-67845671?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67845671?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T15:26:02+00:00

The 10 warmest years in the UK have all occurred since 2003 according to provisional Met Office data.

## Ex-husband of mother accused of children's Colorado deaths 'devastated'
 - [https://www.bbc.co.uk/news/world-us-canada-67863711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67863711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T15:19:29+00:00

Kevin Wentz says he and Kimberlee Singler, awaiting extradition to the US, had a contentious divorce.

## Japan earthquake: Rescue effort under way after quake kills 48
 - [https://www.bbc.co.uk/news/world-asia-67865502?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67865502?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T14:58:20+00:00

A day after the powerful quake, the Japanese government has warned of the risk of strong aftershocks.

## Luke Littler - the 16-year-old who is changing darts at PDC World Championship
 - [https://www.bbc.co.uk/sport/darts/67861277?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/darts/67861277?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T14:53:55+00:00

Teenager Luke Littler is two victories away from winning the PDC Darts World Championship and has already pocketed £100,000 for his fairytale run at Alexandra Palace.

## Jonathan Morgan returns to work at Sheffield United
 - [https://www.bbc.co.uk/sport/football/67863185?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67863185?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T14:43:16+00:00

Jonathan Morgan returns to work as Sheffield United manager after an investigation into his conduct and behaviour.

## Spain's Hermoso testifies World Cup kiss was not consensual
 - [https://www.bbc.co.uk/news/world-europe-67861492?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67861492?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T14:25:54+00:00

A Spanish judge will decide whether ex-football boss Luis Rubiales should go on trial for assault.

## How Japan’s powerful earthquakes have shifted the land
 - [https://www.bbc.co.uk/news/world-asia-67862306?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67862306?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T14:06:03+00:00

The country has shifted more than a metre to the west following the earthquake this week.

## BBC Verify: Government's asylum figures show uncleared backlog
 - [https://www.bbc.co.uk/news/uk-politics-67863380?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67863380?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T13:57:08+00:00

Thousands of asylum applications made before June 2022 have still not received initial decisions.

## Sheffield Eagles player Quentin Laulu-Togaga'e suffers heart attack after training
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-67863562?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-south-yorkshire-67863562?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T13:50:52+00:00

Sheffield Eagles full-back Quentin Laulu-Togaga'e says he is "grateful" to still be alive after suffering a heart attack after training.

## Ukraine war: Grim new year for Ukrainians under shadow of Russian attack
 - [https://www.bbc.co.uk/news/world-europe-67861379?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67861379?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T13:49:47+00:00

Ukrainians see in a second new year under some of the heaviest aerial bombardment since Russia's war began.

## Alice Wood who dragged partner under car in Rode Heath guilty
 - [https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-67862292?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-67862292?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T12:28:23+00:00

Alice Wood, 23, killed partner Ryan Watson by running him over with her car.

## Mickey Mouse horror film unveiled as copyright ends
 - [https://www.bbc.co.uk/news/entertainment-arts-67861538?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67861538?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T12:24:51+00:00

The trailer for the slasher movie was released as the cartoon character entered the public domain.

## Passengers clamber down emergency slide after Japan plane fire
 - [https://www.bbc.co.uk/news/world-asia-67861082?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67861082?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T12:08:15+00:00

The Japan Airlines plane was engulfed in flames after it landed at Haneda Airport.

## Wayne Rooney: Birmingham City sack manager after just 15 games in charge
 - [https://www.bbc.co.uk/sport/football/67858866?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67858866?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T11:21:01+00:00

Birmingham City sack manager Wayne Rooney after just 15 games in charge, with Blues 20th in the Championship.

## Rafael Nadal wins at Brisbane International on long-awaited return from injury
 - [https://www.bbc.co.uk/sport/tennis/67861406?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67861406?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T11:18:39+00:00

Rafael Nadal makes a winning return after almost a year out with injury with a straight-set win over Dominic Thiem at the Brisbane International.

## Kai Zhuang: Chinese teen found alive in US after 'cyber kidnapping'
 - [https://www.bbc.co.uk/news/world-us-canada-67861852?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67861852?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T11:04:09+00:00

Exchange student Kai Zhuang is discovered freezing in the Utah mountains after parents pay ransom.

## Luke Littler plays darts as a toddler in home video footage
 - [https://www.bbc.co.uk/news/uk-67861077?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67861077?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T10:27:20+00:00

The 16-year-old is on a strong run at the PDC World Darts Championship, where he has reached the semi-finals.

## Strong winds from Storm Henk to batter parts of UK
 - [https://www.bbc.co.uk/news/uk-67861206?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67861206?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T10:12:34+00:00

Forecasters are warning of travel disruption, roof damage and power cuts in southern England and Wales.

## Watch: First footage of plane in flames after it lands at airport
 - [https://www.bbc.co.uk/news/world-asia-67862154?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67862154?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T09:32:17+00:00

The Japan Airlines plane was in flames as it landed on a runway at Haneda airport.

## Japan Airlines plane in flames on the runway at Tokyo's Haneda Airport
 - [https://www.bbc.co.uk/news/world-67862011?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-67862011?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T09:14:28+00:00

Pictures show the aircraft on fire while it is travelling along the runway at the busy airport.

## Aldi and Lidl hail Christmas boost from bargain hunters
 - [https://www.bbc.co.uk/news/business-67861354?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67861354?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T09:03:20+00:00

The discount supermarkets say they were helped by shoppers looking to cut the cost of celebrations.

## Watch: BBC visits earthquake epicentre in Japan
 - [https://www.bbc.co.uk/news/world-asia-67861078?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67861078?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T09:01:39+00:00

Jean Mackenzie assesses the damage in Ishikawa prefecture battling against cut off roads.

## Emma Raducanu battles to victory at Auckland Classic in first match in eight months
 - [https://www.bbc.co.uk/sport/tennis/67860956?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67860956?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T09:01:16+00:00

Emma Raducanu makes a winning return to tennis in her first match for eight months against Elena-Gabriela Ruse at the Auckland Classic.

## Ethiopia signs agreement with Somaliland paving way to sea access
 - [https://www.bbc.co.uk/news/world-africa-67858566?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-67858566?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T08:15:44+00:00

The prime minister of the landlocked country has said that sea access was an existential question.

## The Troubles: Payments proposed for relatives of those killed
 - [https://www.bbc.co.uk/news/uk-northern-ireland-67771246?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-67771246?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T08:05:28+00:00

The victims' commissioner suggests payments would apply to anyone killed - including paramilitaries.

## Melissa Hoskins' family 'utterly devastated' by death of Olympic cyclist
 - [https://www.bbc.co.uk/sport/cycling/67860897?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/67860897?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T07:38:06+00:00

The family of Melissa Hoskins say they are "utterly devastated" following the death of the Olympic cyclist, who was hit by a car in Adelaide on Saturday.

## David Warner pleads for return of Australian 'baggy green' cap after revealing it was stolen
 - [https://www.bbc.co.uk/sport/cricket/67860959?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67860959?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T07:29:46+00:00

Australia opener David Warner pleads for his "baggy green" cap to be returned after revealing it has been stolen from his luggage.

## Motorway electric car charge point target missed, says RAC
 - [https://www.bbc.co.uk/news/business-67858961?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67858961?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T07:26:37+00:00

The RAC motoring organisation says the government has missed its target for installing charging points.

## Primrose Hill: Met appeals for help after fatal stabbing
 - [https://www.bbc.co.uk/news/uk-england-london-67858737?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67858737?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T07:23:35+00:00

Harry Pitman, 16, was killed just before midnight on New Year's Eve in a north London park.

## Poem for lost WW2 airmen shared with their relatives
 - [https://www.bbc.co.uk/news/uk-england-hereford-worcester-67835310?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hereford-worcester-67835310?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T07:19:52+00:00

The verse is discovered more than 80 years after being written.

## Why the tax office will now know more about your Depop and Vinted sales
 - [https://www.bbc.co.uk/news/business-67855872?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67855872?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T07:07:23+00:00

New rules mean online retail platforms including Airbnb and eBay will share more information with HMRC.

## 'She's ready to conquer again' - the return of Osaka
 - [https://www.bbc.co.uk/sport/tennis/67772432?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67772432?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T07:00:22+00:00

Naomi Osaka has returned to tennis after 15 months out, with one new family member and a fresh outlook on life and sport.

## Walt Disney - how Ireland shaped an American icon
 - [https://www.bbc.co.uk/news/articles/c6p4x6644q5o?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/c6p4x6644q5o?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T06:34:57+00:00

Walt Disney is known as 'an American Original' but his Irish roots are a tale as old as time.

## Ukraine warns of Russian missile strikes as it repels drones
 - [https://www.bbc.co.uk/news/world-europe-67860016?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67860016?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T06:18:12+00:00

The air force says numerous missiles were being fired from Russia towards Ukraine on Tuesday morning.

## Alexandra Palace: Working to restore a north London icon
 - [https://www.bbc.co.uk/news/uk-england-london-67826799?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67826799?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T05:59:09+00:00

Following a £550,000 grant from Historic England, work to make much-needed repairs can begin.

## China’s BYD closer to taking Tesla's electric car top spot
 - [https://www.bbc.co.uk/news/business-67860232?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67860232?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T05:24:29+00:00

Elon Musk's Tesla is due to release quarterly production and delivery figures on Tuesday.

## Jimmy Lai: Hong Kong mogul pleads not guilty to national security crimes
 - [https://www.bbc.co.uk/news/world-asia-china-67860502?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-67860502?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T05:10:30+00:00

Jimmy Lai pleads not guilty to breaching national security and colluding with foreign forces.

## UK asylum backlog cleared, says PM, but critics disagree
 - [https://www.bbc.co.uk/news/uk-politics-67860254?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67860254?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T04:10:24+00:00

Rishi Sunak says he has met a pledge made a year ago, but Labour accuse the government of massaging the figures.

## How Japan learned to live with earthquakes
 - [https://www.bbc.co.uk/news/world-asia-67860334?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67860334?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T03:44:42+00:00

Monday's quake renewed Japan's collective trauma - but it's also a story of engineering success.

## Lee Jae-myung: South Korea opposition leader stabbed in Busan.
 - [https://www.bbc.co.uk/news/world-asia-67860330?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67860330?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T02:35:46+00:00

Lee Jae-myung was stabbed on the left side of his neck during a news conference during a visit to Busan.

## Will hotter heat pumps win over homeowners?
 - [https://www.bbc.co.uk/news/business-67511954?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67511954?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T01:41:07+00:00

Could a new generation of heat pumps overcome British fears that they can't heat a home.

## Junior doctors: NHS chief warns of tough new year as fresh strike looms
 - [https://www.bbc.co.uk/news/health-67858854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-67858854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T01:37:11+00:00

A planned six-day junior doctors' strike will have a big impact on routine care, a health chief says.

## Cambridge University trademarks spark rows with firms
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-67628318?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-67628318?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T01:11:30+00:00

Firms are spending thousands registering trademarks after University of Cambridge opposition.

## The Scottish prisoners making hip-hop behind bars
 - [https://www.bbc.co.uk/news/entertainment-arts-67694205?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67694205?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T01:04:30+00:00

Barlinnie Prison in Glasgow has been giving inmates the chance to make their own hip-hop tracks.

## When will the 15 free hours of childcare for two-year-olds begin?
 - [https://www.bbc.co.uk/news/education-62036045?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-62036045?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T01:02:54+00:00

All children of working parents in England will get 30 hours of funded childcare by September 2025.

## BBC Sound of 2024: South Africa's Tyla says 'people are not ready' for debut album
 - [https://www.bbc.co.uk/news/entertainment-arts-67747565?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67747565?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T01:02:31+00:00

After scoring a global hit with her summer anthem Water, Tyla comes fourth in the BBC Sound of 2024.

## The Traitors: Claudia Winkleman says contestants are more brutal
 - [https://www.bbc.co.uk/news/entertainment-arts-67758541?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67758541?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T01:01:35+00:00

Claudia Winkleman says players are cannier in the second series of the popular reality TV show.

## Colossal pliosaur sea monster skull on display in Dorset
 - [https://www.bbc.co.uk/news/science-environment-67782416?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67782416?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T00:43:06+00:00

Members of the public get a chance to see the 2m-long pliosaur fossil at a museum in Dorset.

## Ruth Perry: Ofsted needs more empathy, says Sir Martyn Oliver as he starts new role
 - [https://www.bbc.co.uk/news/education-67840212?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-67840212?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-01-02T00:34:31+00:00

Sir Martyn Oliver says Ofsted must listen to criticism after the suicide of head teacher Ruth Perry.

