# Source:TIME, URL:https://time.com/feed, language:en-UK

## Why a 9-Month-Long World Cruise Is TikTok’s Latest Obsession
 - [https://time.com/6551552/nine-month-ultimate-world-cruise-tiktok](https://time.com/6551552/nine-month-ultimate-world-cruise-tiktok)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T21:48:03+00:00

On Dec. 10, Royal Caribbean embarked on a nine-month long world-spanning cruise. TikTok users are following along, hoping for drama.

## Harvard President Claudine Gay Resigns
 - [https://time.com/6551609/harvard-president-resigns](https://time.com/6551609/harvard-president-resigns)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T21:45:03+00:00

The news follows backlash over a congressional hearing about antisemitism on campus and allegations of plagiarism

## How to Reduce Food Waste and Save Money
 - [https://time.com/6344758/how-to-reduce-food-waste-budget](https://time.com/6344758/how-to-reduce-food-waste-budget)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T20:55:31+00:00

Cutting down on food you waste is good for the environment—and your wallet.

## The Food Trends to Get Excited About in 2024, According to Experts
 - [https://time.com/6344783/food-drink-trends-2024](https://time.com/6344783/food-drink-trends-2024)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T20:05:46+00:00

From global flavors to alternative chocolates.

## Top Hamas Official Saleh Arouri Killed in Beirut Blast
 - [https://time.com/6551540/saleh-arouri-hamas-official-killed-beirut](https://time.com/6551540/saleh-arouri-hamas-official-killed-beirut)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T18:50:59+00:00

Lebanon’s state-run National News Agency said the blast killed four people and was carried out by an Israeli drone.

## Mickey Mouse Is Now in the Public Domain After 95 Years of Disney Copyright
 - [https://time.com/6551496/mickey-mouse-public-domain-steamboat-willie](https://time.com/6551496/mickey-mouse-public-domain-steamboat-willie)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T17:22:17+00:00

Disney desire to prevent the copyright on the character from expiring has shaped American copyright law.

## Your New Year’s Resolution to Carry a Water Bottle Has a History
 - [https://time.com/6548310/new-years-water-bottles](https://time.com/6548310/new-years-water-bottles)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T14:00:00+00:00

Our water bottle obsession speaks to deeper historical trends.

## 5 People Killed as Planes Collide and Catch Fire at Tokyo Airport
 - [https://time.com/6551411/plane-fire-japan-haneda-tokyo](https://time.com/6551411/plane-fire-japan-haneda-tokyo)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T12:18:52+00:00

A passenger plane and a Japanese coast guard aircraft collided at Tokyo's Haneda Airport

## Nobel Prize Winner Cautions on Rush Into STEM After Rise of AI
 - [https://time.com/6551407/ai-stem-jobs-pissarides](https://time.com/6551407/ai-stem-jobs-pissarides)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T12:01:12+00:00

A Nobel Prize-winning economist has cautioned against studying STEM subjects, saying “empathetic” skills may thrive in a world dominated by AI

## Failure Is a Privilege
 - [https://time.com/6549815/failure-privilege-essay](https://time.com/6549815/failure-privilege-essay)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T12:00:00+00:00

'Intelligent failures illuminate the pathway toward success,' writes Amy Edmondson.

## Teachers Wrestle With How to Discuss January 6 With Students
 - [https://time.com/6548722/teachers-january-6-insurrection-students](https://time.com/6548722/teachers-january-6-insurrection-students)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T12:00:00+00:00

Some link it to the nation's founding era, others to Reconstruction, and some don't discuss it at all.

## ‘The Donald Trump Revenge Show’: House GOP Moves Toward Impeaching Biden
 - [https://time.com/6550679/biden-impeachment-trump-revenge-show](https://time.com/6550679/biden-impeachment-trump-revenge-show)
 - RSS feed: https://time.com/feed
 - date published: 2024-01-02T12:00:00+00:00

Key House Republicans are ready to impeach the President, despite no evidence of an impeachable offense.

