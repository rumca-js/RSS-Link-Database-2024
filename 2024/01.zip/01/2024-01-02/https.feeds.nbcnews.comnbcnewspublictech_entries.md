# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## Mickey Mouse copyright expiration inspires horror movies, video games and memes
 - [https://www.nbcnews.com/tech/internet/mickey-mouse-horror-movie-slasher-trap-public-domain-rcna131897](https://www.nbcnews.com/tech/internet/mickey-mouse-horror-movie-slasher-trap-public-domain-rcna131897)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-01-02T21:59:08+00:00

Mickey Mouse will appear in non-Disney works after copyright protection over the character expired, putting the character in the public domain.

## Sen. Robert Menendez hit with new indictment
 - [https://www.nbcnews.com/politics/congress/robert-menendez-hit-new-indictment-rcna131980](https://www.nbcnews.com/politics/congress/robert-menendez-hit-new-indictment-rcna131980)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-01-02T21:57:27+00:00

A federal grand jury has filed a second superseding indictment against Sen.

## Russia bombards Ukraine's largest cities after Putin vows intensified attacks
 - [https://www.nbcnews.com/news/world/russia-attacks-ukraine-kyiv-kharkiv-putin-intensified-strikes-rcna131824](https://www.nbcnews.com/news/world/russia-attacks-ukraine-kyiv-kharkiv-putin-intensified-strikes-rcna131824)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-01-02T13:24:22+00:00

Ukraine’s two largest cities were hit by a new wave of deadly Russian attacks Tuesday, after President Vladimir Putin began the New Year with a vow to intensify the most aggressive campaign of strikes since the war began nearly two years ago.

## 'Beverly Hills, 90210' actor Ian Ziering describes attack by biker gang
 - [https://www.nbcnews.com/news/us-news/beverly-hills-90210-actor-ian-ziering-describes-attack-biker-gang-rcna131833](https://www.nbcnews.com/news/us-news/beverly-hills-90210-actor-ian-ziering-describes-attack-biker-gang-rcna131833)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-01-02T12:39:20+00:00

Ian Ziering, who starred as Steve Sanders in "Beverly Hills, 90210" in the 1990s, said he faced an "alarming incident" on New Year's Eve involving a gang on mini-bikes, leading to what he called an "unsettling confrontation" and a physical fight.

## ESPN apologizes for showing clip of woman flashing her breast during the Sugar Bowl
 - [https://www.nbcnews.com/news/sports/espn-apologizes-showing-clip-woman-flashing-breast-sugar-bowl-rcna131835](https://www.nbcnews.com/news/sports/espn-apologizes-showing-clip-woman-flashing-breast-sugar-bowl-rcna131835)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-01-02T12:34:16+00:00

ESPN apologized Monday night for a video clip of a woman baring her breast that was shown during the broadcast of the Sugar Bowl in New Orleans.

## Republicans spend over $100 million on Iowa ads, with more to come
 - [https://www.nbcnews.com/politics/2024-election/republicans-spend-100-million-iowa-ads-come-rcna130856](https://www.nbcnews.com/politics/2024-election/republicans-spend-100-million-iowa-ads-come-rcna130856)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-01-02T11:00:00+00:00

Republican presidential candidates and outside groups have blanketed the Iowa airwaves with more than $105 million in ads ahead of the Jan. 15 caucuses.

## South Korean opposition leader Lee Jae-myung attacked, injured by unidentified man, officials say
 - [https://www.nbcnews.com/news/world/man-attacks-injures-south-korean-opposition-leader-lee-jae-myung-rcna131818](https://www.nbcnews.com/news/world/man-attacks-injures-south-korean-opposition-leader-lee-jae-myung-rcna131818)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2024-01-02T02:47:49+00:00

South Korean opposition leader Lee Jae-myung was attacked and injured by an unidentified man during a visit Tuesday to the southeastern city of Busan, emergency officials said.

