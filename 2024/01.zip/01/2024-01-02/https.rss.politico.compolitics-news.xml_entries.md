# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Rep. Tony Gonzales previews border trip with Johnson
 - [https://www.politico.com/video/2024/01/02/rep-tony-gonzales-previews-border-trip-with-johnson-1178954](https://www.politico.com/video/2024/01/02/rep-tony-gonzales-previews-border-trip-with-johnson-1178954)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-01-02T12:06:37+00:00



## Trouble with tha God
 - [https://www.politico.com/news/2024/01/02/biden-charlamagne-tha-god-00132784](https://www.politico.com/news/2024/01/02/biden-charlamagne-tha-god-00132784)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-01-02T05:00:00+00:00

The influential radio host of “The Breakfast Club” is a thorn in the side of Democrats — but he’s also representative of one of their biggest problems.

