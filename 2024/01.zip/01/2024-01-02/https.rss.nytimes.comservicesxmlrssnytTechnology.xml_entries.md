# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## A Stunning Eclipse, a Moon Race and Other Space Events in 2024
 - [https://www.nytimes.com/2024/01/02/science/space-astronomy-events-2024.html](https://www.nytimes.com/2024/01/02/science/space-astronomy-events-2024.html)
 - RSS feed: https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2024-01-02T07:59:16+00:00

In April, people across North America will be able to gaze at a stunning total eclipse. And astronauts may get closer to that promised moon landing.

