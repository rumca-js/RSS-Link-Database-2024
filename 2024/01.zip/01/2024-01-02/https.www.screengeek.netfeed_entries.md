# Source:ScreenGeek, URL:https://www.screengeek.net/feed/, language:en-US

## First Trailer For Mickey Mouse Horror Movie ‘Mickey’s Mouse Trap’ Released
 - [https://www.screengeek.net/2024/01/02/mickeys-mouse-trap-trailer](https://www.screengeek.net/2024/01/02/mickeys-mouse-trap-trailer)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2024-01-02T16:21:29+00:00

<p>Mickey Mouse, the beloved Disney character, has taken an unexpected and chilling turn. With the entry of the iconic short film Steamboat Willie into the public domain, Mickey Mouse has found himself starring in his own (unofficial) horror movie, Mickey&#8217;s Mouse Trap. This low-budget production, directed by Jamie Bailey, is set to give its own [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/01/02/mickeys-mouse-trap-trailer/">First Trailer For Mickey Mouse Horror Movie &#8216;Mickey&#8217;s Mouse Trap&#8217; Released</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

