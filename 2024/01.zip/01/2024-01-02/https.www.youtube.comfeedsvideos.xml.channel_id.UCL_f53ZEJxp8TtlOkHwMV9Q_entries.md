# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## No Policy That Requires Compulsion Is Optimized
 - [https://www.youtube.com/watch?v=Bs3NiK3nnWc](https://www.youtube.com/watch?v=Bs3NiK3nnWc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q
 - date published: 2024-01-02T21:30:01+00:00

Dr. Peterson's extensive catalog is available now on DailyWire+: https://bit.ly/3KrWbS8

// LINKS //
All links: https://linktr.ee/drjordanbpeterson
Website: https://jordanbpeterson.com
Tour Locations: https://jordanbpeterson.com/events
X: https://twitter.com/jordanbpeterson
Instagram: https://instagram.com/jordan.b.peterson
Facebook: https://facebook.com/drjordanpeterson
Telegram: https://t.me/DrJordanPeterson
Newsletter: https://mailchi.mp/jordanbpeterson.com/youtubesignup

// COURSES //
Discovering Personality: https://jordanbpeterson.com/personality
Self Authoring Suite: https://selfauthoring.com
Understand Myself (personality test): https://understandmyself.com

// BOOKS //
Beyond Order: 12 More Rules for Life: https://jordanbpeterson.com/Beyond-Order
12 Rules for Life: An Antidote to Chaos: https://jordanbpeterson.com/12-rules-for-life
Maps of Meaning: The Architecture of Belief: https://jordanbpeterson.com/maps-of-meaning

#JordanPeterson #JordanBPeterson #DrJordanPeterson #DrJ

