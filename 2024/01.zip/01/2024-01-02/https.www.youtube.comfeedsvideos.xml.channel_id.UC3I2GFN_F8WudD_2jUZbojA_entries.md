# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Ratboys - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=RZROSwijkFI](https://www.youtube.com/watch?v=RZROSwijkFI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-01-02T16:00:14+00:00

http://KEXP.ORG presents Ratboys performing live in the KEXP studio. Recorded October 24, 2023.

Songs:
Morning Zoo
It's Alive!
The Window
Black Earth, WI

Julia Steiner - Vocals, Guitar
Sean Neumann - Bass, Vocals
Dave Sagan - Guitar
Marcus Nuccio - Drums

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Jonathan Jacobson
Editor: Jim Beckmann

https://www.ratboysband.com/
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Ratboys - The Window (Live on KEXP)
 - [https://www.youtube.com/watch?v=ft22DTIvw48](https://www.youtube.com/watch?v=ft22DTIvw48)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-01-02T12:00:25+00:00

http://KEXP.ORG presents Ratboys performing “The Window” live in the KEXP studio. Recorded October 24, 2023.

Julia Steiner - Vocals, Guitar
Sean Neumann - Bass, Vocals
Dave Sagan - Guitar
Marcus Nuccio - Drums

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Jonathan Jacobson
Editor: Jim Beckmann

https://www.ratboysband.com/
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Ratboys - Black Earth, WI (Live on KEXP)
 - [https://www.youtube.com/watch?v=Nip7nRINk68](https://www.youtube.com/watch?v=Nip7nRINk68)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-01-02T12:00:23+00:00

http://KEXP.ORG presents Ratboys performing “Black Earth, WI” live in the KEXP studio. Recorded October 24, 2023.

Julia Steiner - Vocals, Guitar
Sean Neumann - Bass, Vocals
Dave Sagan - Guitar
Marcus Nuccio - Drums

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Jonathan Jacobson
Editor: Jim Beckmann

https://www.ratboysband.com/
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Ratboys - Morning Zoo (Live on KEXP)
 - [https://www.youtube.com/watch?v=V4J_KSQ2trU](https://www.youtube.com/watch?v=V4J_KSQ2trU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-01-02T12:00:23+00:00

http://KEXP.ORG presents Ratboys performing “Morning Zoo” live in the KEXP studio. Recorded October 24, 2023.

Julia Steiner - Vocals, Guitar
Sean Neumann - Bass, Vocals
Dave Sagan - Guitar
Marcus Nuccio - Drums

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Jonathan Jacobson
Editor: Jim Beckmann

https://www.ratboysband.com/
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Ratboys - It's Alive (Live on KEXP)
 - [https://www.youtube.com/watch?v=Fuvt8gqcE-Q](https://www.youtube.com/watch?v=Fuvt8gqcE-Q)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-01-02T12:00:09+00:00

http://KEXP.ORG presents Ratboys performing “It's Alive” live in the KEXP studio. Recorded October 24, 2023.

Julia Steiner - Vocals, Guitar
Sean Neumann - Bass, Vocals
Dave Sagan - Guitar
Marcus Nuccio - Drums

Host: Cheryl Waters
Audio Engineers: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Alaia D’Alessandro, Jonathan Jacobson
Editor: Jim Beckmann

https://www.ratboysband.com/
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

