# Source:Times of India, URL:https://timesofindia.indiatimes.com/rssfeedstopstories.cms, language:en-gb

## Rahul, Priyanka unlikely to be invited to Ram temple event
 - [https://timesofindia.indiatimes.com/india/rahul-gandhi-priyanka-gandhi-vadra-unlikely-to-be-invited-to-ram-temple-event/articleshow/106495367.cms](https://timesofindia.indiatimes.com/india/rahul-gandhi-priyanka-gandhi-vadra-unlikely-to-be-invited-to-ram-temple-event/articleshow/106495367.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T22:05:54+00:00

Sources said Sonia Gandhi was invited by temple construction committee chairperson Nripendra Mishra in her capacity as chief of the Congress Parliamentary Party. The trust is sending out invitations to three categories of political guests - presidents of the mainstream parties, leaders of the opposition in the Lok Sabha and Rajya Sabha, and those who participated in the Ram temple movement between 1984 and 1992. The special guests for whom the trust is rolling out the red carpet include seers, industrialists, artists and sportspeople.

## TN got 2.5x central funds from BJP govt than in UPA era: PM
 - [https://timesofindia.indiatimes.com/india/tamil-nadu-got-2-5x-central-funds-from-bjp-govt-than-in-upa-era-pm-modi/articleshow/106495308.cms](https://timesofindia.indiatimes.com/india/tamil-nadu-got-2-5x-central-funds-from-bjp-govt-than-in-upa-era-pm-modi/articleshow/106495308.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:47:35+00:00

Continuing the comparison, PM Modi said the BJP government spent more than three times on national highway construction in Tamil Nadu and 2.5 times more on the railways in the state. "Lakhs of families in the state are getting free ration, medical treatment, and facilities like pucca houses, toilets, and piped water,'' he said. PPM Modi underscored the significance of Tamil Nadu to the central government, revealing that 40 Union ministers have toured the state over 400 times in the past year alone.

## Desi anti-drone system to be installed along Pak border in 6 mths
 - [https://timesofindia.indiatimes.com/india/desi-anti-drone-system-to-be-installed-along-pakistan-border-in-6-months/articleshow/106495305.cms](https://timesofindia.indiatimes.com/india/desi-anti-drone-system-to-be-installed-along-pakistan-border-in-6-months/articleshow/106495305.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:46:37+00:00

A fully-indigenous anti-drone system is set to be installed across the country's western border in six months to block drones being used by elements in Pakistan to smuggle arms and narcotics into India, particularly Punjab. A senior government functionary said trials of the anti-drone technology were going on, with three options being tested. "The anti-drone system to be put in place across the entire western border will either be one of the three systems or a combination of two or more technologies," the functionary said.

## India-UAE joint military exercise 'Desert Cyclone' commences in Raj
 - [https://timesofindia.indiatimes.com/india/india-uae-joint-military-exercise-desert-cyclone-commences-in-rajasthan/articleshow/106495303.cms](https://timesofindia.indiatimes.com/india/india-uae-joint-military-exercise-desert-cyclone-commences-in-rajasthan/articleshow/106495303.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:46:19+00:00

The two-week-long India-UAE joint military exercise 'Desert Cyclone' commenced in Rajasthan, with 45 personnel representing each of the forces. The UAE Land Forces contingent arrived to participate in the 1st edition of the India-UAE Joint Military Exercise 'Desert Cyclone', read a press statement from the Ministry of Defence. The exercise that will run till January 15 is happening in Mahajan, Rajasthan. The Indian Army contingent comprising 45 personnel is being represented mainly by a battalion from the Mechanised Infantry Regiment.

## Shah urges security forces in J&K to scale up counter-terror ops
 - [https://timesofindia.indiatimes.com/india/amit-shah-urges-security-forces-in-jk-to-scale-up-counter-terror-operations/articleshow/106495302.cms](https://timesofindia.indiatimes.com/india/amit-shah-urges-security-forces-in-jk-to-scale-up-counter-terror-operations/articleshow/106495302.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:46:10+00:00

Home minister Amit Shah, who reviewed the security situation in Jammu &amp; Kashmir here on Tuesday, instructed all arms of the security establishment in the Union Territory to scale up counter-terrorism operations and fully dismantle the terror ecosystem, but stressed on the need to follow due procedures while doing so. While reviewing the area domination plan of the security agencies in J&amp;K during the meeting attended by J&amp;K LG Manoj Sinha, NSA Ajit Doval, Chief of Army Staff, Intelligence Bureau director, heads of various central armed police forces and J&amp;K's administration and police .

## UP cops to take over Ayodhya Ram temple security from CRPF
 - [https://timesofindia.indiatimes.com/india/up-cops-to-take-over-ayodhya-ram-temple-security-from-crpf/articleshow/106495044.cms](https://timesofindia.indiatimes.com/india/up-cops-to-take-over-ayodhya-ram-temple-security-from-crpf/articleshow/106495044.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:24:56+00:00

A special task force of the Uttar Pradesh police will be fully in charge of security of the Ram temple complex coming up at Ayodhya, taking over from CRPF that has been protecting the site on the directions of the Supreme Court. A senior government functionary said since CRPF was deployed at the Ram Janambhoomi site as per the orders of the Supreme Court following the demolition of the Babri structure in 1992 and that with January 22 set as the date for 'pran pratishtha' , or consecration ceremony of the Ram Lalla idol, the UP Special Security Force (SSF) will start providing comprehensive security cover at the temple.

## 'Ab ki baar char sau paar': BJP sets itself Lok Sabha target
 - [https://timesofindia.indiatimes.com/india/ab-ki-baar-char-sau-paar-bjp-sets-itself-lok-sabha-target/articleshow/106495043.cms](https://timesofindia.indiatimes.com/india/ab-ki-baar-char-sau-paar-bjp-sets-itself-lok-sabha-target/articleshow/106495043.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:24:32+00:00

Confident of a better performance in the 2024 Lok Sabha polls, BJP has set itself a stiff target and coined a slogan, 'Teesri Baar Modi Sarkar, Ab Ki Baar Char Sau Paar' (Modi government for the third time with over 400 seats). In the 2019 elections, BJP secured 303 seats on its own and, along with its NDA allies, had 353 seats. In the 2014 polls, BJP won 282 seats and the NDA had 336. A party functionary said the slogan was finalised in a meeting on Tuesday.

## 1st woman IPL auctioneer hammers home art of selling sports stars
 - [https://timesofindia.indiatimes.com/india/1st-woman-ipl-auctioneer-hammers-home-art-of-selling-sports-stars/articleshow/106495040.cms](https://timesofindia.indiatimes.com/india/1st-woman-ipl-auctioneer-hammers-home-art-of-selling-sports-stars/articleshow/106495040.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:23:41+00:00

For the first time in her two-decade career, Mallika Sagar wore sneakers to work on December 19 last year. Apart from helping her fill the large shoes of British auctioneer Hugh Edmeades, the pair of kicks kept her going during her seven-hour, headline-grabbing debut selling 72 male cricketers for over Rs 200 crore in a large arena in Dubai as the IPL's first woman auctioneer. The stint came 22 years after she sold baseball memorabilia to a roomful of well-heeled Americans as the first Indian woman auctioneer at Christie's in NY.

## Missing teens case: CBI files chargesheets against five
 - [https://timesofindia.indiatimes.com/india/missing-teens-case-cbi-files-chargesheets-against-five/articleshow/106494998.cms](https://timesofindia.indiatimes.com/india/missing-teens-case-cbi-files-chargesheets-against-five/articleshow/106494998.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:09:42+00:00

Central Bureau of Investigation (CBI) has filed separate chargesheets against five accused persons in two inter-related cases of Manipur violence pertaining to the disappearance and subsequent killings of two students in July. The CBI had taken over investigation in August and their probe has revealed that the boy and the girl were intercepted and held captive by a group of men who had forcibly put the victims in a vehicle. They were taken to an undisclosed location and killed later.

## Who should take care of special children after they turn 18: SC
 - [https://timesofindia.indiatimes.com/india/who-should-take-care-of-special-children-after-they-turn-18-supreme-court/articleshow/106494993.cms](https://timesofindia.indiatimes.com/india/who-should-take-care-of-special-children-after-they-turn-18-supreme-court/articleshow/106494993.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:06:02+00:00

The Supreme Court on Tuesday noticed legislative silence on who should take care of children with special needs after they become 18-year-olds - a time triggered event that disentitles them from residing in state-run childcare homes and sought the Union government's response to a PIL seeking life-long governmental care for this category of persons.Appearing for petitioner and veteran journalist K S R Menon, advocate Abir Phukan told a bench of CJI D Y Chandrachud, Justices J B Pardiwala and Manoj Misra that though the Juvenile Justice (Care and Protection of Children) Act, 2015.

## Railway official who gave PM selfie booths' cost info shunted
 - [https://timesofindia.indiatimes.com/india/railway-official-who-gave-pm-selfie-booths-cost-info-shunted/articleshow/106494991.cms](https://timesofindia.indiatimes.com/india/railway-official-who-gave-pm-selfie-booths-cost-info-shunted/articleshow/106494991.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:05:51+00:00

Seven months after taking charge, Central Railway's chief public relations officer (CPRO) Shivraj Manaspure was unexpectedly transferred on December 29, allegedly without being given a reason for it or being told where his new posting is. He had last month, in response to an RTI plea, disclosed the cost of 3D selfie booths featuring PM Modi at stations. Manaspure has been replaced by Swapnil D Nila.

## Space given to Khalistanis in Canada politics core issue: EAM
 - [https://timesofindia.indiatimes.com/india/space-given-to-khalistanis-in-canada-politics-core-issue-eam/articleshow/106494990.cms](https://timesofindia.indiatimes.com/india/space-given-to-khalistanis-in-canada-politics-core-issue-eam/articleshow/106494990.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:05:42+00:00

Foreign minister S Jaishankar reiterated on Tuesday that India's core issue with Canada was the space given to Khalistani forces in Canadian politics, allowing them to indulge in activities that damage the relationship with India. "The issue at heart is the fact that in Canadian politics, these Khalistani forces have been given a lot of space and have been allowed to indulge in activities which I think are damaging to the relationship, clearly not in India's interest, and not in Canada's interest either.

## Militants fire grenades at patrol party in Manipur, five wounded
 - [https://timesofindia.indiatimes.com/india/militants-fire-grenades-at-patrol-party-in-manipur-five-wounded/articleshow/106494989.cms](https://timesofindia.indiatimes.com/india/militants-fire-grenades-at-patrol-party-in-manipur-five-wounded/articleshow/106494989.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T21:05:32+00:00

Four police commandos and a BSF trooper were wounded on Tuesday when militants suspected to be from a Myanmar-based outfit fired rocket-propelled grenades at a joint patrol in the border town of Moreh in Manipur's Tengnoupal district, making this the fourth consecutive day of violence in the state. Chief minister N Biren Singh accused "foreign mercenaries" of trying to stoke a conflict that was dying out, identifying the perpetrators as being possibly from the Kuki National Army, Burma (KNA-B). "Multiple sources have told us this," he said.

## Woman can seek divorce over sexual perversion: Kerala HC
 - [https://timesofindia.indiatimes.com/india/woman-can-seek-divorce-over-sexual-perversion-kerala-hc/articleshow/106494934.cms](https://timesofindia.indiatimes.com/india/woman-can-seek-divorce-over-sexual-perversion-kerala-hc/articleshow/106494934.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:47:39+00:00

The court said that different people may define sexually perverse acts differently, but if one of the parties engaging in sex objects to the same but the other person continues, that would amount to cruelty. A division bench of Justices Amit Rawal and CS Sudha said that if the conduct and character of a person causes misery and agony to the spouse, the said conduct would certainly be an act of cruelty to the spouse, justifying the grant of divorce.

## CJI assures help as trans woman denied teacher's job moves SC
 - [https://timesofindia.indiatimes.com/india/cji-assures-help-as-trans-woman-denied-teachers-job-moves-supreme-court/articleshow/106494905.cms](https://timesofindia.indiatimes.com/india/cji-assures-help-as-trans-woman-denied-teachers-job-moves-supreme-court/articleshow/106494905.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:33:17+00:00



## Truckers' strike set to end after govt assurance on accident law
 - [https://timesofindia.indiatimes.com/india/truckers-strike-set-to-end-after-government-assurance-on-accident-law/articleshow/106494883.cms](https://timesofindia.indiatimes.com/india/truckers-strike-set-to-end-after-government-assurance-on-accident-law/articleshow/106494883.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:25:10+00:00

Stepping in to defuse the situation, the home ministry enlisted the support of the All India Motor Transport Congress (AIMTC), and jointly appealed to truckers to end their strike. Truck drivers are now expected to be back on the roads from Wednesday, ending a potential crisis in transport of essential goods. “The provisions of the Bharatiya Nyaya Sanhita have not been implemented so far. We will consult AIMTC whenever we implement Section 106 (2) of the law (which deals with higher penalty in hit-and-run cases),” home secretary Ajay Bhalla said after a meeting with representatives of the lobby group representing transporters.

## Can't deny job over trivial mistake while filling up form: SC
 - [https://timesofindia.indiatimes.com/india/cant-deny-job-over-trivial-mistake-while-filling-up-form-supreme-court/articleshow/106494877.cms](https://timesofindia.indiatimes.com/india/cant-deny-job-over-trivial-mistake-while-filling-up-form-supreme-court/articleshow/106494877.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:24:14+00:00



## Truck drivers' strike disrupts supply chain across states
 - [https://timesofindia.indiatimes.com/india/truck-drivers-strike-disrupts-supply-chain-across-states/articleshow/106494875.cms](https://timesofindia.indiatimes.com/india/truck-drivers-strike-disrupts-supply-chain-across-states/articleshow/106494875.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:23:35+00:00

A nationwide strike by truckers and transporters demanding withdrawal of stringent penalties for hit-and-run cases has caused disruptions in public services and the supply chain across various states. The strike, ongoing since Monday, has led to traffic disruptions, shortages in LPG cylinders, increased vegetable prices, and delays in public transport, affecting fuel and essential commodities. Several states are grappling with the consequences of the ongoing protest, raising concerns about the potential escalation of the situation.

## JEE rule: Biometric and frisking even after toilet break
 - [https://timesofindia.indiatimes.com/india/jee-rule-biometric-and-frisking-even-after-toilet-break/articleshow/106494874.cms](https://timesofindia.indiatimes.com/india/jee-rule-biometric-and-frisking-even-after-toilet-break/articleshow/106494874.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:23:16+00:00

Candidates appearing for JEE-Main will be subjected to frisking and biometric attendance after a toilet break too. The National Testing Agency (NTA) is introducing stricter guidelines during the tests slated this month which will include frisking and biometric identification process also for officials from the agency. The Joint Entrance Examination (Main) will also be conducted in centres in Bastar in Chhattisgarh and Tura in Meghalaya for the first time.

## Govt: Women can now nominate kids over husband for pension
 - [https://timesofindia.indiatimes.com/india/goverment-women-can-now-nominate-kids-over-husband-for-pension/articleshow/106494873.cms](https://timesofindia.indiatimes.com/india/goverment-women-can-now-nominate-kids-over-husband-for-pension/articleshow/106494873.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:23:00+00:00

A woman employee can now nominate her child or children for family pension in precedence over her husband in case of marital discord, the Centre said on Tuesday. Rule 50 of the Central Civil Services (Pension) Rules, 2021 allows the grant of family pension following the death of a government servant or retired government servant. If a deceased government servant or pensioner is survived by a spouse, family pension is first granted to the spouse.

## IIT-Guwahati student from Telangana dies after NY party
 - [https://timesofindia.indiatimes.com/india/iit-guwahati-student-from-telangana-dies-after-ny-party/articleshow/106494872.cms](https://timesofindia.indiatimes.com/india/iit-guwahati-student-from-telangana-dies-after-ny-party/articleshow/106494872.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:22:43+00:00

A female student of IIT Guwahati from Telangana was declared dead in hospital after being rushed there unconscious on Monday following a New Year's party outside the campus, police said Tuesday. Pulluri Aishwarya (21), a fourth-year student of electronics and communication engineering, had partied late Sunday at a pub in Guwahati with three friends from the institute, hours after having returned from hometown Karimnagar, the police said.

## Mahua Moitra faces charge of snooping on 'ex-BF'
 - [https://timesofindia.indiatimes.com/india/mahua-moitra-faces-charge-of-snooping-on-ex-bf/articleshow/106494871.cms](https://timesofindia.indiatimes.com/india/mahua-moitra-faces-charge-of-snooping-on-ex-bf/articleshow/106494871.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:22:26+00:00

Advocate Jai Anant Dehadrai, whose 'cash-for questions' complaint against Mahua Moitra led to her expulsion from Lok Sabha, has accused the Trinamool Congress leader of carrying out "illegal surveillance on her ex-boyfriend" with help from senior cops in West Bengal. In a complaint filed with the CBI and the home ministry, the Supreme Court lawyer alleged that Moitra had illegally obtained call detail records (CDR) of her ex-boyfriend after getting suspicious that he was having an affair with a German woman, a senior functionary of a social media giant.

## Strong buzz of Nitish as INDIA convener before virtual meet
 - [https://timesofindia.indiatimes.com/india/strong-buzz-of-nitish-as-india-convener-before-virtual-meet/articleshow/106494870.cms](https://timesofindia.indiatimes.com/india/strong-buzz-of-nitish-as-india-convener-before-virtual-meet/articleshow/106494870.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:22:13+00:00

As the INDIA bloc partners gear up for seat-sharing talks, there was a strong buzz in Bihar's political circles Tuesday that CM and JD(U) chief Nitish Kumar could be declared convener of the opposition alliance at a virtual meeting Wednesday, reports Madan Kumar. Congress president Mallikarjun Kharge might be appointed chairperson of the grouping, sources said.

## Notice to police over bail plea in Parliament breach case
 - [https://timesofindia.indiatimes.com/india/notice-to-police-over-bail-plea-in-parliament-breach-case/articleshow/106494861.cms](https://timesofindia.indiatimes.com/india/notice-to-police-over-bail-plea-in-parliament-breach-case/articleshow/106494861.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:15:00+00:00



## Gym trainer kills man to claim ₹1cr insurance money, arrested
 - [https://timesofindia.indiatimes.com/india/gym-trainer-kills-man-to-claim-1-crore-insurance-money-arrested/articleshow/106494855.cms](https://timesofindia.indiatimes.com/india/gym-trainer-kills-man-to-claim-1-crore-insurance-money-arrested/articleshow/106494855.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T20:12:13+00:00

Police have arrested a gym trainer on suspicion that he faked his own death by murdering a man who matched his description to claim an insurance payout. Two of the gym trainer's friends have also been arrested as cops believe they participated in the murder plot. In September 2023, Ayanavaram-based gym trainer Suresh (38) hatched a plan to fake his own death and claim Rs 1 crore in life insurance that would come to his family in case of his death, as per the cops.

## Bihar should make caste survey data break-up public: SC
 - [https://timesofindia.indiatimes.com/india/supreme-court-bihar-should-make-caste-survey-data-break-up-public/articleshow/106494832.cms](https://timesofindia.indiatimes.com/india/supreme-court-bihar-should-make-caste-survey-data-break-up-public/articleshow/106494832.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T19:59:48+00:00

​Supreme Court on Tuesday said Bihar should make the data public to allow people to challenge a particular inference reached by the state and expressed reservation in passing an interim order to restrain the government. A bench of Justices Sanjiv Khanna and Dipankar Dutta said the main concern was about the extent to which the breakup of data collected by the government could be put in the public domain so that it did not lead to violation of the right to privacy of citizens.

## Harvard prez resigns after rows over plagiarism, anti-Semitism
 - [https://timesofindia.indiatimes.com/world/us/harvard-president-resigns-after-rows-over-plagiarism-anti-semitism/articleshow/106494800.cms](https://timesofindia.indiatimes.com/world/us/harvard-president-resigns-after-rows-over-plagiarism-anti-semitism/articleshow/106494800.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T19:48:40+00:00

The president of Harvard University resigned Tuesday after coming under ferocious attack for her handling of anti-Semitism during protests over Gaza, as well as allegations that she had plagiarized in her academic work. In the United States, the anti-Semitism on campus controversy came amid a rise in attacks and violent rhetoric targeting Jews and Muslims, including at universities, since the Israel-Hamas war erupted.

## CAA rules ready, set to be notified before Lok Sabha elections
 - [https://timesofindia.indiatimes.com/india/caa-rules-ready-set-to-be-notified-before-lok-sabha-elections/articleshow/106494794.cms](https://timesofindia.indiatimes.com/india/caa-rules-ready-set-to-be-notified-before-lok-sabha-elections/articleshow/106494794.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T19:46:43+00:00

An online system for application, processing &amp; grant of citizenship under CAA is being explored by home ministry, a senior government functionary said. CAA was enacted in December 2019 and came into force on January 10, 2020. However, CAA rules are yet to be notified, which is why the Act hasn't been implemented or process started for grant of citizenship to nationals from Pakistan, Bangladesh and Afghanistan belonging to Hindu, Sikh, Jain, Christian, Buddhist &amp; Parsi communities, who had migrated to India before December 31, 2014.

## Space PSU NSIL to launch GSAT-20 on SpaceX’s Falcon 9 this year
 - [https://timesofindia.indiatimes.com/india/space-psu-nsil-to-launch-gsat-20-on-spacexs-falcon-9-this-year/articleshow/106494677.cms](https://timesofindia.indiatimes.com/india/space-psu-nsil-to-launch-gsat-20-on-spacexs-falcon-9-this-year/articleshow/106494677.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T19:11:10+00:00

India’s Space PSU NewSpace India Limited (NSIL), the commercial arm of the Indian Space Research Organisation (Isro), will launch a high-throughput satellite on Elon Musk’s SpaceX rocket — the Falcon 9 — later this year. NSIL plans to launch its second demand-driven communications satellite, the GSAT-20 (renamed GSAT-N2), in the second quarter of 2024. The satellite will be a high-throughput Ka-band satellite primarily aimed at meeting India’s growing broadband connectivity needs.

## 'A miracle': How flyers escaped Japanese plane fireball
 - [https://timesofindia.indiatimes.com/world/rest-of-world/it-was-a-miracle-how-passengers-escaped-a-japan-airlines-fireball-in-tokyo/articleshow/106493924.cms](https://timesofindia.indiatimes.com/world/rest-of-world/it-was-a-miracle-how-passengers-escaped-a-japan-airlines-fireball-in-tokyo/articleshow/106493924.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T17:55:37+00:00



## Top Hamas leader killed in Israel strike on Beirut
 - [https://timesofindia.indiatimes.com/world/middle-east/hamas-says-israel-strike-on-beirut-kills-its-deputy-chief/articleshow/106493832.cms](https://timesofindia.indiatimes.com/world/middle-east/hamas-says-israel-strike-on-beirut-kills-its-deputy-chief/articleshow/106493832.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T17:46:43+00:00

Israel's war against Palestinian militants reached into the Lebanese capital Beirut on Tuesday, where an Israeli strike killed Hamas's deputy leader, the group and security officials in Lebanon said.A high-level security official told AFP that Saleh al-Aruri was killed along with his bodyguards in the strike by Israel, which vowed to destroy Hamas after the movement's unprecedented attacks on Israel on October 7.A second security official confirmed the information, adding two floors of the targeted building and one car were damaged.

## Trivial genuine errors in applying for job can't be ground for disqualification: SC
 - [https://timesofindia.indiatimes.com/india/trivial-genuine-errors-in-applying-for-job-cannot-be-ground-for-disqualification-sc/articleshow/106493477.cms](https://timesofindia.indiatimes.com/india/trivial-genuine-errors-in-applying-for-job-cannot-be-ground-for-disqualification-sc/articleshow/106493477.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T17:21:43+00:00

The Supreme Court ruled that trivial errors should not be used to deny a job to a successful candidate. The court directed the state government to appoint a village boy from Bihar as a police constable, despite a mistake in his date of birth. The petitioner had sought help from an internet cafe owner and made an inadvertent error in the online form. The court emphasized that justice should not be forsaken due to technicalities and that the error was insignificant and should not be penalized.

## Soren denies reports he is planning to do a Lalu in Jharkhand
 - [https://timesofindia.indiatimes.com/india/bjp-weaving-false-narrative-hemant-soren-denies-reports-he-is-planning-to-do-a-lalu-in-jharkhand/articleshow/106493338.cms](https://timesofindia.indiatimes.com/india/bjp-weaving-false-narrative-hemant-soren-denies-reports-he-is-planning-to-do-a-lalu-in-jharkhand/articleshow/106493338.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T16:59:06+00:00



## Exclusive: Basketball players took a legal route against BFI's diktat
 - [https://timesofindia.indiatimes.com/sports/more-sports/others/exclusive-everyone-should-be-free-to-play-basketball-players-took-a-legal-route-against-bfis-diktat/articleshow/106492290.cms](https://timesofindia.indiatimes.com/sports/more-sports/others/exclusive-everyone-should-be-free-to-play-basketball-players-took-a-legal-route-against-bfis-diktat/articleshow/106492290.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T15:30:05+00:00

A circular cautioning players against participating in private basketball tournaments has sparked a legal battle initiated by affected basketball players. The players argue that the circular is illegal and infringes upon their fundamental rights. They seek to have the circular quashed. The athletes express scepticism towards the justification provided by the federation for preventing them from playing in private leagues.

## 2nd Test: Skipper Rohit wants young guns to step up
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/performing-in-these-conditions-rohit-sharma-wants-young-guns-to-step-up-as-india-look-to-draw-level-against-south-africa/articleshow/106492395.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/performing-in-these-conditions-rohit-sharma-wants-young-guns-to-step-up-as-india-look-to-draw-level-against-south-africa/articleshow/106492395.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T15:23:13+00:00

With India looking to draw level in the two-Test series, skipper Rohit Sharma on Tuesday said he wants the young batters to apply themselves and perform and raise their game to the next level. The second Test begins in Cape Town from Wednesday.

## Changing face of war: Israel's partial pullback & its implications
 - [https://timesofindia.indiatimes.com/world/middle-east/the-changing-face-of-gaza-war-israels-partial-pullback-and-its-implications/articleshow/106492188.cms](https://timesofindia.indiatimes.com/world/middle-east/the-changing-face-of-gaza-war-israels-partial-pullback-and-its-implications/articleshow/106492188.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T15:06:28+00:00

Israel is redeploying its troops in Gaza, targeting Hamas and addressing the economic impact of the war. This marks the largest troop withdrawal since the October 7 attack by Hamas. The military is moving to the third stage of the war, involving intense operations against terrorists, while also preparing for potential conflicts with Hezbollah. The strategic pivot is in response to US pressure for a more civilian-protective approach and the need to balance military operations and economic functionality. The war's new phase brings uncertainty and elusive prospects of a lasting ceasefire or political solution.

## BJP's Ram temple push leaves oppn in Catch-22 situation
 - [https://timesofindia.indiatimes.com/india/to-attend-or-not-to-attend-bjps-big-push-on-ram-temple-ceremony-leaves-opposition-in-catch-22-situation/articleshow/106491882.cms](https://timesofindia.indiatimes.com/india/to-attend-or-not-to-attend-bjps-big-push-on-ram-temple-ceremony-leaves-opposition-in-catch-22-situation/articleshow/106491882.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T14:57:11+00:00



## 'Teesri baar...': BJP's new slogan for Lok Sabha polls
 - [https://timesofindia.indiatimes.com/india/teesri-baar-modi-sarkar-ab-ki-baar-400-paar-bjps-new-slogan-for-lok-sabha-2024-polls/articleshow/106491597.cms](https://timesofindia.indiatimes.com/india/teesri-baar-modi-sarkar-ab-ki-baar-400-paar-bjps-new-slogan-for-lok-sabha-2024-polls/articleshow/106491597.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T14:52:45+00:00

BJP sets high target for Lok Sabha elections with a new slogan: 'Teesri baar Modi Sarkar, ab ki baar 400 paar'. The party aims to win 400 plus seats in the polls. The announcement was made in a meeting chaired by national president JP Nadda and attended by prominent party members. The meeting also discussed organizational strategies and appointed convenors and co-convenors at the State Assembly and Lok Sabha levels. The party plans to intensify its campaign efforts with tours by prominent leaders in Lok Sabha clusters.

## Why almost 150 earthquakes struck Japan in less than a day
 - [https://timesofindia.indiatimes.com/world/rest-of-world/why-almost-150-earthquakes-struck-japan-in-less-than-a-day/articleshow/106491970.cms](https://timesofindia.indiatimes.com/world/rest-of-world/why-almost-150-earthquakes-struck-japan-in-less-than-a-day/articleshow/106491970.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T14:47:13+00:00

A magnitude 7.6 earthquake struck Japan's northwest coast, killing dozens. The quake triggered a tsunami warning, but alerts were lifted after a wave of at least 1.2 meters. There is a 20% risk of another quake of the same size. Frequent aftershocks are putting structures at risk. Japan has an earthquake early warning system that has sent false alarms.

## Watch: Bumrah imitates Ashwin's action to perfection at nets
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/watch-jasprit-bumrah-imitates-r-ashwins-action-to-perfection-at-nets/articleshow/106491774.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/watch-jasprit-bumrah-imitates-r-ashwins-action-to-perfection-at-nets/articleshow/106491774.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T14:33:58+00:00

India's pace spearhead Jasprit Bumrah's action grabbed eyeballs as he imitated teammate off-spinner Ravichandran Ashwin's action to perfection during the team's practice session ahead of the second and final Test against South Africa at Newlands in Cape Town on Tuesday. After succumbing to an innings defeat in Centurion in the first Test, Team India is currently toiling hard in the nets for the final Test, commencing on Wednesday. The team is aiming for a victory in this match to salvage a draw against their opponents.

## Sagar Parekh on Jhalak Dikhhla Jaa 11: 'last wildcard contestant cast'
 - [https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-sagar-parekh-on-entering-jhalak-dikhhla-jaa-11-i-was-the-last-wildcard-contestant-to-get-cast-so-i-got-only-4-5-days-to-prepare/articleshow/106491585.cms](https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-sagar-parekh-on-entering-jhalak-dikhhla-jaa-11-i-was-the-last-wildcard-contestant-to-get-cast-so-i-got-only-4-5-days-to-prepare/articleshow/106491585.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T14:25:36+00:00

Sagar Parekh, known for his role as Samar in Anupamaa, is excited to join Jhalak Dikhhla Jaa 11 as a wildcard contestant. Despite being a non-dancer, Sagar is challenging himself and pushing his limits on the dance show. He acknowledges the tough journey, with bruises and body aches, but he is enjoying the process. Sagar is not focused on competition but wants to prove his worth and transform into a dancer through hard work and dedication. He had limited time for preparation compared to other contestants. Sagar introduced his mother on the show and praised her dancing skills.

## Terrifying video from inside burning Japanese plane
 - [https://timesofindia.indiatimes.com/world/rest-of-world/though-i-was-going-to-die-terrifying-video-from-inside-burning-japanese-plane/articleshow/106491463.cms](https://timesofindia.indiatimes.com/world/rest-of-world/though-i-was-going-to-die-terrifying-video-from-inside-burning-japanese-plane/articleshow/106491463.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T14:20:29+00:00

A major tragedy was averted on Tuesday when a Japan Airlines flight carrying 367 passengers and 12 crew members caught fire after colliding with a Coast Guard plane on the Haneda airport runway in Tokyo. All 379 people on board were safely evacuated from the plane after the collision and the pilot of the Coast Guard plane also managed to escape. However, five other crew members aboard the Coast Guard aircraft were killed in the accident.

## Rohit expects 'challenging' Newlands as India look to level series
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/rohit-sharma-expects-challenging-newlands-as-india-look-to-level-series/articleshow/106491384.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/rohit-sharma-expects-challenging-newlands-as-india-look-to-level-series/articleshow/106491384.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T14:09:48+00:00

India's young batsmen will simply have to find a way to cope with South Africa's "challenging" conditions, Indian captain Rohit Sharma said on Tuesday. Sharma said he did not expect conditions for the second Test, starting at Newlands on Wednesday, to be much different from those at Centurion, where India were beaten by an innings in the first Test last week.

## 5 biggest changes in new Hyundai Creta explained
 - [https://timesofindia.indiatimes.com/auto/cars/five-biggest-changes-in-the-new-hyundai-creta-expected-price-launch-date-and-more/articleshow/106487530.cms](https://timesofindia.indiatimes.com/auto/cars/five-biggest-changes-in-the-new-hyundai-creta-expected-price-launch-date-and-more/articleshow/106487530.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T13:38:48+00:00

The new Creta will continue with the 115hp, 1.5-litre NA petrol and 1.5-litre turbo diesel engines, with a manual gearbox as standard and CVT and torque converter gearboxes as options, respectively. It will now get a new 1.5-litre turbocharged petrol engine with 160 hp of power and little over 250 Nm torque. Gearbox options will include a 7-speed DCT and iMT.

## T20 World Cup: Agarkar likely to speak to Rohit and Kohli
 - [https://timesofindia.indiatimes.com/sports/cricket/news/t20-world-cup-ajit-agarkar-likely-to-speak-to-rohit-sharma-and-virat-kohli-30-odd-players-could-be-monitored-during-ipl/articleshow/106490559.cms](https://timesofindia.indiatimes.com/sports/cricket/news/t20-world-cup-ajit-agarkar-likely-to-speak-to-rohit-sharma-and-virat-kohli-30-odd-players-could-be-monitored-during-ipl/articleshow/106490559.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T13:24:57+00:00

Both Rohit Sharma and Virat Kohli have not played in the shortest format for India since the T20 World Cup semi-final against England in November 2022. The two national selectors, Shiv Sunder Das and Salil Ankola are both in South Africa and will be joined by their chairman Ajit Agarkar during the course of the second Test at Newlands. It is expected that Agarkar and Co will speak to head coach Rahul Dravid along with Test and ODI skipper Rohit, star batter Kohli before announcing the squad against Afghanistan.

## Ira Khan and Nupur Shikhare's wedding: Amir Khan's sisters' perform
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/ira-khan-and-nupur-shikhares-wedding-we-are-preparing-songs-to-perform-on-dhol-says-aamir-khans-sister-nikhat-khan-hegde-exclusive/articleshow/106489644.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/ira-khan-and-nupur-shikhares-wedding-we-are-preparing-songs-to-perform-on-dhol-says-aamir-khans-sister-nikhat-khan-hegde-exclusive/articleshow/106489644.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T13:00:19+00:00

Aamir Khan and Reena Dutta's daughter, Ira Khan, is set to marry fitness coach Nupur Shikhare in a registered marriage. The pre-wedding celebrations included a mehendi function at the groom's house, where everyone dressed in traditional Maharashtrian sarees. The family has been practicing songs on the dhol for a casual sangeet ceremony, with Aamir Khan himself learning to sing. The wedding will take place in Udaipur, featuring a sangeet and mehendi, but not a traditional Maharashtrian-style wedding.

## Hit-and-run law: What change triggered nationwide protests
 - [https://timesofindia.indiatimes.com/auto/policy-and-industry/hit-and-run-law-backlash-what-change-triggered-nationwide-protests/articleshow/106489572.cms](https://timesofindia.indiatimes.com/auto/policy-and-industry/hit-and-run-law-backlash-what-change-triggered-nationwide-protests/articleshow/106489572.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T12:53:42+00:00

India's hit-and-run law, which sparked nationwide protests, has led to fear of supply shortages. The law, part of the Bharatiya Nyay Sanhita, imposes up to 10 years in jail and a fine of Rs 7 lakh for leaving the scene of an accident. Previously, Section 304 A of the IPC governed hit-and-run incidents with a maximum jail term of two years. The backlash stems from the tougher penalties and the risk of mob violence faced by truck drivers. Stay tuned for updates on the automotive sector.

## 'China First' policy: Jaishankar slams Nehru's 'romanticism'
 - [https://timesofindia.indiatimes.com/india/jaishankar-modi-govt-follows-sardar-patels-realism-not-nehrus-romanticism-while-dealing-with-china/articleshow/106484242.cms](https://timesofindia.indiatimes.com/india/jaishankar-modi-govt-follows-sardar-patels-realism-not-nehrus-romanticism-while-dealing-with-china/articleshow/106484242.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T12:35:44+00:00

External affairs minister Jaishankar emphasized the importance of a "realistic approach" in dealing with China, criticizing India's past "romanticism". He highlighted the contrast between Nehru's idealistic friendship and Patel's realist approach. Jaishankar argued for a realism that aligns with the Modi government and allows for a certain approach towards China. He mentioned the fundamental difference between Nehru and Patel's response to China. Jaishankar also discussed the Chindia policy and the recent tensions between India and China, including the Galwan Valley clash.

## Ira Khan-Nupur Shikhare wedding: Bride to don lehenga, groom tux
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/ira-khan-nupur-shikhare-wedding-bride-to-don-a-lehenga-the-groom-will-wear-a-tuxedo-exclusive/articleshow/106487995.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/news/ira-khan-nupur-shikhare-wedding-bride-to-don-a-lehenga-the-groom-will-wear-a-tuxedo-exclusive/articleshow/106487995.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T11:59:53+00:00

Currently, the pre-wedding celebrations of the occasion are in full swing, marked by the Haldi ceremony, which witnessed the elegant arrival of Kiran Rao and Reena Dutta in style. The presence of Kiran Rao and Reena Dutta, exuding grace and elegance, added to the joyous ambiance of the festivities, marking a heartwarming union of families in celebration of love and togetherness

## 'If something happens to Bumrah...': Pathan wants bigger fast bowling pool
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/if-something-happens-to-bumrah-irfan-pathan-wants-india-to-focus-on-building-bigger-fast-bowling-pool-in-2024/articleshow/106487780.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/if-something-happens-to-bumrah-irfan-pathan-wants-india-to-focus-on-building-bigger-fast-bowling-pool-in-2024/articleshow/106487780.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T11:53:58+00:00

India must focus on increasing the bench strength of their pace attack in 2024 as the Centurion Test exposed chinks in that department, reckons former pacer Irfan Pathan.

## 'India were outstanding in Tests under Kohli's captaincy'
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/having-overrated-cricketers-kris-srikkanth-feels-after-virat-kohlis-test-captaincy-era-team-has-underperformed/articleshow/106487066.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/having-overrated-cricketers-kris-srikkanth-feels-after-virat-kohlis-test-captaincy-era-team-has-underperformed/articleshow/106487066.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T11:31:34+00:00

Former Indian captain Kris Srikkanth remarked that India showcased strength in Test cricket during the 2-4 years of Virat Kohli's captaincy. However, he went on to suggest that the team has been relying solely on the reputation of past achievements since then. India fell to an innings defeat in Centurion in the first Test and are playing their second and final Test of the South Africa series starting Wednesday, hoping to win it so they can eke out a draw against their opponents.

## Here's how Samantha Ruth Prabhu looked two decades ago
 - [https://timesofindia.indiatimes.com/entertainment/tamil/movies/news/heres-how-samantha-ruth-prabhu-looked-two-decades-ago/articleshow/106487104.cms](https://timesofindia.indiatimes.com/entertainment/tamil/movies/news/heres-how-samantha-ruth-prabhu-looked-two-decades-ago/articleshow/106487104.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T11:29:50+00:00

Samantha Ruth Prabhu, known for her role in 'Kushi', is currently on a sabbatical due to her autoimmune disease myositis. She recently shared a stunning monochrome photo of herself at 16, reminiscent of her early days as a model. Samantha is expected to make a comeback with the film 'Citadel' alongside Varun Dhawan. Additionally, she announced her new production house, Tralala, where she will take on the role of a producer. Fans are eagerly awaiting the first announcement from her production house.

## Kumkum Bhagya actor Zuber K Khan ties the knot
 - [https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-kumkum-bhagya-actor-zuber-k-khan-ties-the-knot-says-im-looking-forward-to-celebrating-the-joys-of-marriage/articleshow/106487043.cms](https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-kumkum-bhagya-actor-zuber-k-khan-ties-the-knot-says-im-looking-forward-to-celebrating-the-joys-of-marriage/articleshow/106487043.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T11:29:16+00:00

Zuber K Khan, known for his roles in TV shows like Manmohini and Naagin 3, recently got married. He tied the knot with Marhaba Khan on December 25 in an arranged marriage.

## Gavaskar weighs in on Team India changes for second Test
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/he-was-hardly-used-sunil-gavaskar-weighs-in-team-indias-changes-for-second-test/articleshow/106486406.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/he-was-hardly-used-sunil-gavaskar-weighs-in-team-indias-changes-for-second-test/articleshow/106486406.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T11:08:14+00:00

With another green top set to be used for the second Test, legendary Sunil Gavaskar weighed in on the team combination, pointing out he sees a couple of changes in the Indian XI for the game.

## Chartreuse: The liqueur by monks; why it's facing global shortage
 - [https://timesofindia.indiatimes.com/life-style/food-news/chartreuse-the-liqueur-made-by-monks-and-why-it-is-facing-a-global-shortage/articleshow/106485509.cms](https://timesofindia.indiatimes.com/life-style/food-news/chartreuse-the-liqueur-made-by-monks-and-why-it-is-facing-a-global-shortage/articleshow/106485509.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T10:42:13+00:00

Chartreuse is a French liqueur that has a distinctive green color and a complex flavor profile. It is made by monks of the Carthusian Order in the Chartreuse Mountains of France, using a closely guarded recipe of 130 herbs, plants, and botanicals. The liqueur is named after the monks' Grande Chartreuse monastery, where it was originally produced in the 18th century. There are two main types of Chartreuse: Green and Yellow. Scroll down to learn more details about this unique drink

## Hair braids Orry flaunts have history with links to African slavery
 - [https://timesofindia.indiatimes.com/life-style/fashion/buzz/the-hair-braids-orry-flaunts-have-a-fascinating-history-with-a-painful-link-to-african-slavery/articleshow/106484814.cms](https://timesofindia.indiatimes.com/life-style/fashion/buzz/the-hair-braids-orry-flaunts-have-a-fascinating-history-with-a-painful-link-to-african-slavery/articleshow/106484814.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T10:26:25+00:00

The popular African braids can be traced back to the times of slavery and were symbols of resilience.

## 1cr+ screened under National Sickle Cell Anaemia Elimination Mission
 - [https://timesofindia.indiatimes.com/life-style/health-fitness/health-news/over-1-crore-people-have-been-screened-under-national-sickle-cell-anaemia-elimination-mission-health-ministry/articleshow/106483719.cms](https://timesofindia.indiatimes.com/life-style/health-fitness/health-news/over-1-crore-people-have-been-screened-under-national-sickle-cell-anaemia-elimination-mission-health-ministry/articleshow/106483719.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T09:51:39+00:00

The Union Health Ministry has screened more than one crore people for sickle cell anemia under the government's Sickle Cell Anemia Elimination Mission. The Mission aims to screen 7 crore population in 3 years. Launched by the Prime Minister in July 2023, the program focuses on 278 districts of 17 states with higher prevalence of SCD. Sickle cell disease is a genetic blood disorder characterized by abnormal hemoglobin, leading to vaso-occlusive events, chronic pain, anemia, and organ damage. While there is no cure, various treatments aim to manage symptoms and improve quality of life.

## Japan Airlines plane carrying nearly 400 passengers catches fire on runway at Tokyo airport
 - [https://timesofindia.indiatimes.com/world/rest-of-world/fire-breaks-out-in-plane-on-runway-of-japans-tokyo-haneda-airport-report/articleshow/106482695.cms](https://timesofindia.indiatimes.com/world/rest-of-world/fire-breaks-out-in-plane-on-runway-of-japans-tokyo-haneda-airport-report/articleshow/106482695.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T09:17:17+00:00



## Fresh gunfight breaks out in Manipur's Moreh
 - [https://timesofindia.indiatimes.com/india/fresh-gunfight-breaks-out-in-manipurs-moreh/articleshow/106482126.cms](https://timesofindia.indiatimes.com/india/fresh-gunfight-breaks-out-in-manipurs-moreh/articleshow/106482126.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T08:58:53+00:00

Fresh gunfight in Moreh town, Manipur's Tengnoupal district between security forces and suspected militants. Gunbattle started in Chavangphai area after two persons involved in an attack on police personnel were picked up. Local women attempted to secure their release. Four police personnel and a Border Security Force constable, injured in a previous gunfight, were airlifted to the state capital for treatment. Moreh town near India-Myanmar border has witnessed gunfights since December 30. Chief Minister expresses concern over attacks.

## David Warner bows out of Test cricket on his own terms
 - [https://timesofindia.indiatimes.com/sports/cricket/news/david-warner-bows-out-of-test-cricket-on-his-own-terms/articleshow/106481977.cms](https://timesofindia.indiatimes.com/sports/cricket/news/david-warner-bows-out-of-test-cricket-on-his-own-terms/articleshow/106481977.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T08:58:51+00:00

David Warner is set to leave Test cricket at the iconic Sydney Cricket Ground after a 12-year career. Known for his limited-overs shot-making prowess and aggressive style, Warner revolutionized the role of an explosive opener in Test cricket, setting new standards for quick scoring and aggressive play. Despite the ball-tampering scandal in 2018, Warner's cricketing feats, particularly in India, have established him as a revered figure. His legacy is one of authenticity, honesty, and a relentless pursuit of success.

## SS Rajamouli disturbed by the earthquakes in Japan
 - [https://timesofindia.indiatimes.com/entertainment/telugu/movies/news/ss-rajamouli-is-disturbed-by-the-earthquakes-in-japan-says-the-country-holds-a-strong-place-in-our-hearts/articleshow/106481545.cms](https://timesofindia.indiatimes.com/entertainment/telugu/movies/news/ss-rajamouli-is-disturbed-by-the-earthquakes-in-japan-says-the-country-holds-a-strong-place-in-our-hearts/articleshow/106481545.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T08:38:32+00:00

Japan faced a major 7.5 magnitude earthquake, resulting in a tsunami, according to MEDA reports. Nearly 30 people lost their lives in the earthquake. Director SS Rajamouli expressed his concern for Japan, a country that holds a special place in his heart. His movie 'RRR' grossed the second highest in Japan, following India, and set a new box office record of Rs 80 crore. Tollywood actor Jr. NTR, who recently visited Japan, expressed his shock and support for the affected people.

## 'How leptospirosis spread': Dr shares video of rats around food
 - [https://timesofindia.indiatimes.com/life-style/health-fitness/health-news/how-leptospirosis-is-spread-doctor-shares-video-of-rats-around-food-netizens-react/articleshow/106476668.cms](https://timesofindia.indiatimes.com/life-style/health-fitness/health-news/how-leptospirosis-is-spread-doctor-shares-video-of-rats-around-food-netizens-react/articleshow/106476668.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T08:30:00+00:00

A viral video shows rats jumping around in a food-preparation room, shared by 'FearBuck' on X. The video conveys the spread of leptospirosis, a bacterial infection caused by the Leptospira genus. This disease is transmitted through contact with urine-contaminated water or soil, mainly from infected rodents. Leptospirosis symptoms include fever, headache, and muscle aches, progressing to organ failure. It is prevalent in tropical climates, during floods. Prevention involves avoiding contaminated water, wearing protective clothing, and controlling rodents. Timely treatment is crucial. Leptospirosis affects humans and animals, emphasizing public health measures and veterinary care.

## Truckers' protest: Long queues at Mahrashtra petrol pumps
 - [https://timesofindia.indiatimes.com/india/truck-drivers-protest-against-new-hit-and-run-law-long-queues-at-petrol-pumps/articleshow/106481093.cms](https://timesofindia.indiatimes.com/india/truck-drivers-protest-against-new-hit-and-run-law-long-queues-at-petrol-pumps/articleshow/106481093.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T08:28:35+00:00

Long queues at petrol pumps in India as people rush to fill their tanks amid fears of a fuel shortage. The queues are a result of truck drivers protesting against the new penal law on hit-and-run accidents, which is part of the Bharatiya Nyay Sanhita. The law stipulates up to 10 years imprisonment or a fine of Rs 7 lakh for drivers causing serious road accidents and fleeing the scene. Protests have erupted across the country, with private bus and truck drivers enforcing 'chakka jams'.

## PM Modi extends support to flood-hit Tamil Nadu
 - [https://timesofindia.indiatimes.com/city/trichy/pm-narendra-modi-says-centre-stands-with-tamil-nadu-people-extends-all-possible-support-to-flood-hit-state/articleshow/106480118.cms](https://timesofindia.indiatimes.com/city/trichy/pm-narendra-modi-says-centre-stands-with-tamil-nadu-people-extends-all-possible-support-to-flood-hit-state/articleshow/106480118.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T08:10:42+00:00

Modi was speaking after inaugurating the new terminus at Trichy international airport.

## 2nd Test: Rohit faces critical decisions as India aim to bounce back
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/india-vs-south-africa-2nd-test-rohit-sharma-faces-critical-decisions-as-team-india-aims-to-bounce-back-against-south-africa/articleshow/106480225.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/india-vs-south-africa-2nd-test-rohit-sharma-faces-critical-decisions-as-team-india-aims-to-bounce-back-against-south-africa/articleshow/106480225.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T08:02:45+00:00

Team India captain Rohit Sharma faces a crucial decision in the second Test against South Africa, starting on Wednesday. After a disappointing defeat at Centurion, Sharma must select his bowling options and address batting vulnerabilities exposed by the South African pace attack. Ravindra Jadeja is expected to provide balance to the middle-order batting. Sharma must also select the third and fourth fast bowlers, Prasidh Krishna and Shardul Thakur, who may not be sufficient on most days.

## 2024 Hyundai Creta's unique & new design revealed
 - [https://timesofindia.indiatimes.com/auto/cars/2024-hyundai-cretas-unique-and-new-design-revealed-cabin-gets-stunning-look/articleshow/106479662.cms](https://timesofindia.indiatimes.com/auto/cars/2024-hyundai-cretas-unique-and-new-design-revealed-cabin-gets-stunning-look/articleshow/106479662.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T07:55:48+00:00

Hyundai Motor India is set to launch the facelifted Creta SUV on January 16, 2024. Bookings for the updated model have already started, with customers able to book the SUV through the company's official website or dealerships by paying a nominal token amount of Rs 25,000. The new Creta features a redesigned front fascia, including a wide three-row radiator grille and revised headlights. Inside, it offers hi-tech features and a comprehensive display. The SUV will be available with three engine options and four transmission choices. It will also come in several mono-tone and dual-tone color options.

## No scheme of Shivraj govt will stop: MP CM
 - [https://timesofindia.indiatimes.com/city/bhopal/cm-vows-continuity-says-no-scheme-of-shivraj-govt-will-stop/articleshow/106480063.cms](https://timesofindia.indiatimes.com/city/bhopal/cm-vows-continuity-says-no-scheme-of-shivraj-govt-will-stop/articleshow/106480063.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T07:52:42+00:00

Madhya Pradesh CM assures continuation of Shivraj and Modi government schemes; funds to be arranged. Revolutionaries' sacrifices acknowledged. Congress blamed for centralizing power to a single family. New education policy implemented. Agriculture College to be established in Khargone. Government plans to be implemented with determination. Guna incident cited to show government's capability of taking strict action.

## Bigg Boss 17: Elvish reacts to Anurag's sudden eviction
 - [https://timesofindia.indiatimes.com/tv/news/hindi/bigg-boss-17-elvish-yadav-reacts-to-anurag-dobhals-sudden-eviction-says-i-criticise-this-unfair-eviction-i-was-going-to-join-the-meet-ups-to-support-him/articleshow/106479390.cms](https://timesofindia.indiatimes.com/tv/news/hindi/bigg-boss-17-elvish-yadav-reacts-to-anurag-dobhals-sudden-eviction-says-i-criticise-this-unfair-eviction-i-was-going-to-join-the-meet-ups-to-support-him/articleshow/106479390.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T07:43:12+00:00

Elvish Yadav reacts to Anurag Dobhal's eviction from Bigg Boss 17, calling it completely wrong and unfair. He believes that Bigg Boss wanted to remove Anurag for a while and that the eviction was not based on public voting. Elvish shares his disbelief and mentions that he had earlier tweeted about Bigg Boss's intentions. He also criticizes the show for losing viewers who were watching for Anurag and questions the fairness of the eviction process. Take a look at what Elvish had to say:

## TCS gets notice from Maharashtra labour ministry
 - [https://timesofindia.indiatimes.com/gadgets-news/tcs-gets-notice-from-maharashtra-labour-ministry-over-forced-transfers-what-the-complaint-claims/articleshow/106478524.cms](https://timesofindia.indiatimes.com/gadgets-news/tcs-gets-notice-from-maharashtra-labour-ministry-over-forced-transfers-what-the-complaint-claims/articleshow/106478524.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T07:15:14+00:00

The Maharashtra government's labour department has issued a notice to Tata Consultancy Services (TCS) over alleged forced transfers. The complaint, filed by labour union NITES, claims that TCS transferred over 2,000 employees without sufficient lead time or consultation. TCS reportedly threatened employees with disciplinary actions for non-compliance. NITES has asked the labour department to investigate TCS' transfer practices for potential violations of state labour laws.

## Rlys to launch 'super app' for IRCTC booking & train tracking
 - [https://timesofindia.indiatimes.com/business/india-business/soon-indian-railways-to-launch-one-super-app-for-irctc-train-ticket-booking-tracking-trains-more/articleshow/106474526.cms](https://timesofindia.indiatimes.com/business/india-business/soon-indian-railways-to-launch-one-super-app-for-irctc-train-ticket-booking-tracking-trains-more/articleshow/106474526.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T06:49:44+00:00

The Super App intends to combine the functionalities of existing apps like Rail Madad, UTS, and National Train Enquiry System. It also aims to incorporate services such as PortRead, Satark, TMS-Nirikshan for operations, and well-known standalone apps like IRCTC Rail Connect.

## Watch: 'Dejected' Virat Kohli's unseen video after World Cup final
 - [https://timesofindia.indiatimes.com/sports/cricket/news/virat-kohlis-unseen-video-after-odi-world-cup-final-defeat-goes-viral/articleshow/106475229.cms](https://timesofindia.indiatimes.com/sports/cricket/news/virat-kohlis-unseen-video-after-odi-world-cup-final-defeat-goes-viral/articleshow/106475229.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T06:45:45+00:00

Throughout the ICC ODI World Cup, the Indian team dominated every match until they reached the final showdown against Australia at Ahmedabad's Narendra Modi Stadium. Despite their earlier victories, the title slipped from India's grasp as they faced Pat Cummins' formidable side. Playing on their home ground, India, considered top contenders, triumphed against Australia, Afghanistan, Pakistan, Bangladesh, New Zealand, England, Sri Lanka, South Africa, and the Netherlands, securing their spot in the semifinals. Despite their prior victory over Australia in the group stage, India faced a disappointing six-wicket defeat in the grand finale.

## Change this iPhone setting to stop apps from tracking you
 - [https://timesofindia.indiatimes.com/gadgets-news/change-this-one-apple-iphone-setting-to-stop-apps-from-tracking-you/articleshow/106474539.cms](https://timesofindia.indiatimes.com/gadgets-news/change-this-one-apple-iphone-setting-to-stop-apps-from-tracking-you/articleshow/106474539.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T06:29:13+00:00

Apple announced App tracking features in June 2020 while unveiling iOS14. In iOS 14, users can choose whether to allow apps to track their activity. Apple also requires app developers to self-report permissions their apps request, improving transparency. Users can turn off app tracking for new apps by selecting 'Ask App Not to Track' or 'Allow'. They can also make this change default for all apps in Settings. Existing apps can have their tracking permissions turned on or off individually in Settings. Apple enforces tracking permission and warns developers against tracking users who opt out.

## Manipur firing: Situation tense, toll rises to 4
 - [https://timesofindia.indiatimes.com/india/manipur-firing-incident-situation-tense-in-lilong-chingjao-toll-rises-to-4/articleshow/106474480.cms](https://timesofindia.indiatimes.com/india/manipur-firing-incident-situation-tense-in-lilong-chingjao-toll-rises-to-4/articleshow/106474480.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T06:27:23+00:00

The situation in minority-dominated Lilong Chingjao area in Manipur's Thoubal district remained tense after four villagers were gunned down. Additional security forces were deployed and an inter-faith meeting was held to defuse the situation. Curfew was imposed in five districts of Imphal Valley. The bodies of the deceased were brought to Jawaharlal Nehru Institute of Medical Sciences. The Chief Minister condemned the violence and assured that the culprits will be arrested.

## Jaishankar on how Modi govt made Pak's terror policy irrelevant
 - [https://timesofindia.indiatimes.com/india/s-jaishankars-key-insights-on-pakistans-terrorism-tactics-indias-global-diplomacy/articleshow/106473288.cms](https://timesofindia.indiatimes.com/india/s-jaishankars-key-insights-on-pakistans-terrorism-tactics-indias-global-diplomacy/articleshow/106473288.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T06:12:11+00:00

External Affairs Minister S Jaishankar sheds light on India's global diplomatic strategies under the Modi government, emphasizing the country's approach to dealing with Pakistan. He highlights India's success in neutralizing Pakistan's policy of using cross-border terrorism as leverage in diplomatic dialogues. Jaishankar states that India is open to dealing with Pakistan but not under conditions where terrorism is seen as a legitimate tool for diplomacy. He also discusses India's foreign policy in relation to the United States, criticisms about India's democracy, and the evolving relationship with Gulf countries.

## 'They don't care': Waugh expresses concerns over Test's future
 - [https://timesofindia.indiatimes.com/sports/cricket/news/obviously-they-dont-care-steve-waugh-expresses-concerns-over-test-crickets-future/articleshow/106470924.cms](https://timesofindia.indiatimes.com/sports/cricket/news/obviously-they-dont-care-steve-waugh-expresses-concerns-over-test-crickets-future/articleshow/106470924.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T05:46:10+00:00

Former Australia captain Steve Waugh has expressed concern over the future of Test cricket, expressing dismay at Cricket South Africa's decision to send a shadow side to New Zealand for a Test tour. CSA has named seven uncapped players, including skipper Neil Brand, for the two-Test tour of New Zealand, which coincides with the second edition of the SA20 T20 tournament starting on January 10. Waugh urged the ICC and other administrators to intervene and safeguard the longest format of the game.

## Setback for Indians after UK's new rule for foreign students
 - [https://timesofindia.indiatimes.com/world/uk/setback-for-indians-as-britain-bans-foreign-students-from-bringing-families-into-uk/articleshow/106471185.cms](https://timesofindia.indiatimes.com/world/uk/setback-for-indians-as-britain-bans-foreign-students-from-bringing-families-into-uk/articleshow/106471185.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T05:45:53+00:00

The UK government, led by British home secretary James Cleverly, has implemented new visa restrictions that effectively prohibit most international students from bringing their family members to the UK. This change, which took effect on Monday, applies to all foreign students except those enrolled in postgraduate research courses or government-funded scholarship programs. Cleverly described the previous allowance for overseas students to bring their families as an “unreasonable practice.” The measures, initially announced in May by his predecessor Suella Braverman, come in the wake of net migration figures reaching 672,000.

## Suspecting fidelity, Chhattisgarh man kills wife, 3 children
 - [https://timesofindia.indiatimes.com/city/raipur/man-kills-wife-3-minor-children-over-suspicion-of-her-affair-in-chhattisgarh/articleshow/106470251.cms](https://timesofindia.indiatimes.com/city/raipur/man-kills-wife-3-minor-children-over-suspicion-of-her-affair-in-chhattisgarh/articleshow/106470251.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T05:41:15+00:00



## Banking & IT stocks drag Sensex 500 points lower
 - [https://timesofindia.indiatimes.com/business/markets/sensex/sensex-nifty-down-amid-selling-pressure-in-financials-it/articleshow/106470241.cms](https://timesofindia.indiatimes.com/business/markets/sensex/sensex-nifty-down-amid-selling-pressure-in-financials-it/articleshow/106470241.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T05:29:53+00:00



## WhatsApp banned 71 lakh accounts in Nov 2023: All details
 - [https://timesofindia.indiatimes.com/gadgets-news/whatsapp-banned-71-lakh-accounts-in-november-2023-why-whatsapp-bans-accounts-and-more/articleshow/106470207.cms](https://timesofindia.indiatimes.com/gadgets-news/whatsapp-banned-71-lakh-accounts-in-november-2023-why-whatsapp-bans-accounts-and-more/articleshow/106470207.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T05:28:43+00:00

WhatsApp banned over 71 lakh accounts in India in November 2023, in compliance with the new IT Rules 2021. About 19,54,000 accounts were proactively banned. WhatsApp received 8,841 complaint reports in India, and only six were actioned. The company also implemented preventive actions to combat abuse on its platform.

## GRAP III no longer active: What it means for vehicle owners
 - [https://timesofindia.indiatimes.com/auto/policy-and-industry/grap-stage-iii-revoked-in-delhi-ncr-what-does-it-mean-for-bs-iii-petrol-bs-iv-diesel-vehicle-owners/articleshow/106466943.cms](https://timesofindia.indiatimes.com/auto/policy-and-industry/grap-stage-iii-revoked-in-delhi-ncr-what-does-it-mean-for-bs-iii-petrol-bs-iv-diesel-vehicle-owners/articleshow/106466943.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T04:57:14+00:00

The central government has lifted the restrictions imposed under Stage-III of the Graded Response Action Plan (GRAP) in Delhi-NCR. The Central Pollution Control Board (CPCB) reported Delhi's average AQI at 346, below the Stage III-mark of the GRAP, leading to the lifting of the ban on BS-III petrol and BS-IV diesel vehicles. However, the measures outlined in Stage-I to Stage-II of the GRAP would continue to be enforced, monitored, and reviewed by all relevant agencies throughout the entire NCR.

## How a Delhi Capitals' IPL auction goof-up led to embarrassment
 - [https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/how-a-delhi-capitals-ipl-auction-goof-up-led-to-embarrassment-all-around-sumit-kumar-ipl-2024/articleshow/106467217.cms](https://timesofindia.indiatimes.com/sports/cricket/ipl/top-stories/how-a-delhi-capitals-ipl-auction-goof-up-led-to-embarrassment-all-around-sumit-kumar-ipl-2024/articleshow/106467217.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T04:49:35+00:00

Sumit Kumar's name and image were prominently displayed on television, igniting the curiosity of numerous bidders for the talented young wicketkeeper-batsman. Beginning at a modest Rs. 20 lakh, the bidding swiftly escalated to a staggering Rs. 1 crore before the Delhi Capitals secured the cricketer. Tears of elation streamed down Sumit's family's faces as they celebrated. However, both Sumit and his family remained unaware that their jubilation would be short-lived, as the entire scenario suddenly took a distressing turn. Their joy swiftly gave way to heartbreak.

## Darjeeling toy train carrying tourists goes off tracks
 - [https://timesofindia.indiatimes.com/city/kolkata/darj-toy-train-carrying-tourists-goes-off-tracks/articleshow/106466086.cms](https://timesofindia.indiatimes.com/city/kolkata/darj-toy-train-carrying-tourists-goes-off-tracks/articleshow/106466086.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T04:09:59+00:00

A steam loco of the Darjeeling Himalayan Railways (DHR) was derailed at Mary Villa Kakjhora in Darjeeling. This is the third time that a DHR loco went off the tracks, officials said. CPRO Northeast Frontier Railways Sabyasachi De confirmed that there was no casualty. The derailed steam engine was part of the joy ride services between Darjeeling and Ghum. There were 59 passengers on board the two coaches, but none were injured. The recovery van has reached the spot. The DHR operates 12 joy ride services, which will be reduced by January 5 as tourist numbers decrease. Among the eight services, four will be hauled by diesel engines and four by steam. Apu Roy, a tourist from Burdwan, expressed being shaken by the sudden derailment, but confirmed that his family is fine.

## 'Arunachal highly prone to seismic trigger'
 - [https://timesofindia.indiatimes.com/city/hyderabad/arunachal-highly-prone-to-seismic-trigger-ngri-study/articleshow/106465674.cms](https://timesofindia.indiatimes.com/city/hyderabad/arunachal-highly-prone-to-seismic-trigger-ngri-study/articleshow/106465674.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T03:50:31+00:00



## Xi makes rare admission about 'tough time' in China
 - [https://timesofindia.indiatimes.com/world/china/xi-jinping-chinas-economy-china-and-taiwan/articleshow/106465653.cms](https://timesofindia.indiatimes.com/world/china/xi-jinping-chinas-economy-china-and-taiwan/articleshow/106465653.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T03:49:30+00:00

President Xi Jinping vows to strengthen economic momentum and job creation amid domestic headwinds in China. He acknowledges the challenges faced by enterprises and citizens in 2023 and emphasizes the need for economic recovery and development. Xi pledges to improve education, career opportunities, and healthcare, especially for the youth and elderly. China's youth unemployment and property market crisis are pressing concerns. The government aims to avoid deflation and achieve a growth goal of around 5%. Confidence in China's policymaking and stability is crucial after concerns and capital outflows in 2023.

## Punjab DSP found dead under mysterious circumstances
 - [https://timesofindia.indiatimes.com/city/chandigarh/punjab-armed-police-dsp-found-dead-under-mysterious-circumstances-in-jalandhar/articleshow/106464692.cms](https://timesofindia.indiatimes.com/city/chandigarh/punjab-armed-police-dsp-found-dead-under-mysterious-circumstances-in-jalandhar/articleshow/106464692.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T03:13:34+00:00



## Watch: Warner appeals for return of stolen baggy green cap
 - [https://timesofindia.indiatimes.com/sports/cricket/news/watch-david-warner-appeals-for-return-of-stolen-baggy-green-cap-ahead-of-farewell-test/articleshow/106464282.cms](https://timesofindia.indiatimes.com/sports/cricket/news/watch-david-warner-appeals-for-return-of-stolen-baggy-green-cap-ahead-of-farewell-test/articleshow/106464282.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T03:08:03+00:00

David Warner has appealed for the return of his baggy green cap, which went missing on a flight from Melbourne to Sydney. The cap, traditionally presented to Australian internationals on the morning of their Test debut, holds immense significance for players, symbolizing pride and dedication throughout their Test careers. Warner, who is set to conclude his 12-year Test career in the upcoming third Test against Pakistan at the Sydney Cricket Ground, shared his distress on Instagram.

## South Korean opposition leader stabbed in neck
 - [https://timesofindia.indiatimes.com/world/rest-of-world/lee-jae-myung-south-korean-opposition-leader-stabbed-in-neck-during-public-appearance-in-busan/articleshow/106464024.cms](https://timesofindia.indiatimes.com/world/rest-of-world/lee-jae-myung-south-korean-opposition-leader-stabbed-in-neck-during-public-appearance-in-busan/articleshow/106464024.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T03:00:36+00:00

South Korean opposition leader Lee Jae-myung was stabbed in the neck during a visit to Busan. The incident occurred while Lee was touring a site proposed for a new airport. Lee, who narrowly missed the presidency in the 2022 election, was immediately rushed to a local university hospital. The assailant, described as a man in his 50s or 60s wearing a paper crown with Lee's name on it, approached Lee under the guise of asking for an autograph before launching the attack. This attack comes ahead of South Korea's parliamentary elections scheduled for April.

## Nairs, Hoysalas genetically closer to Gujjars
 - [https://timesofindia.indiatimes.com/city/hyderabad/nairs-and-hoysalas-genetic-ancestry-revealed/articleshow/106463573.cms](https://timesofindia.indiatimes.com/city/hyderabad/nairs-and-hoysalas-genetic-ancestry-revealed/articleshow/106463573.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T02:47:25+00:00



## 'Jobless barber': K'taka BJP chief Annamalai flays DMK's Maran
 - [https://timesofindia.indiatimes.com/city/chennai/annamalai-criticizes-maran-for-degrading-someone-by-profession-or-language/articleshow/106463526.cms](https://timesofindia.indiatimes.com/city/chennai/annamalai-criticizes-maran-for-degrading-someone-by-profession-or-language/articleshow/106463526.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T02:46:00+00:00

DMK MP Dayanidhi Maran and BJP state president K Annamalai engage in a war of words, with Maran calling the BJP IT wing a 'jobless barber'. Maran's old speech about job-seeking individuals from Hindi speaking states in Tamil Nadu resurfaces on social media. Congress MP Karti Chidambaram criticizes the BJP IT wing for selectively editing his interview. PM Modi's visit to Tamil Nadu marks the launch of BJP's campaign for the Lok Sabha elections and sheds light on their future plans in the state.

## To get community service for theft, now fulfil 3 conditions
 - [https://timesofindia.indiatimes.com/city/delhi/3-conditions-now-must-to-get-community-service-for-theft/articleshow/106463282.cms](https://timesofindia.indiatimes.com/city/delhi/3-conditions-now-must-to-get-community-service-for-theft/articleshow/106463282.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T02:39:56+00:00



## 2nd Test: SA aim for Elgar's Test farewell victory against India
 - [https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/south-africa-aim-for-dean-elgars-test-farewell-victory-against-india-in-series-decider/articleshow/106463083.cms](https://timesofindia.indiatimes.com/sports/cricket/india-in-south-africa/south-africa-aim-for-dean-elgars-test-farewell-victory-against-india-in-series-decider/articleshow/106463083.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T02:31:47+00:00

South Africa are set to face India in their final Test at Newlands, with captain Dean Elgar biding farewell to his Test career. Elgar has been in prime form in the first Test. India, on the other hand, are expected to make changes to their bowling attack after a comprehensive defeat in the opening Test. Ravindra Jadeja is likely to return, adding depth to India's batting lineup. The Indian bowling lineup may see at least one more change, with Avesh Khan or Mukesh Kumar in contention.

## South Korean opposition leader stabbed in neck
 - [https://timesofindia.indiatimes.com/world/rest-of-world/south-korean-opposition-party-leader-lee-jae-myung-stabbed-in-neck-during-visit-to-busan/articleshow/106462941.cms](https://timesofindia.indiatimes.com/world/rest-of-world/south-korean-opposition-party-leader-lee-jae-myung-stabbed-in-neck-during-visit-to-busan/articleshow/106462941.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T02:17:09+00:00



## Microsoft Edge Recap 2023: How it fared in browser 'war'
 - [https://timesofindia.indiatimes.com/gadgets-news/microsoft-edge-recap-2023-how-it-fared-in-browser-war/articleshow/106459369.cms](https://timesofindia.indiatimes.com/gadgets-news/microsoft-edge-recap-2023-how-it-fared-in-browser-war/articleshow/106459369.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T02:12:28+00:00

Microsoft Edge had a groundbreaking year in 2023, with numerous achievements and milestones that revolutionised browsing. The company released a list of its accomplishments, highlighting the innovative features and advancements. AI played a significant role, with over 1.9 billion Copilot chats and 1.8 billion AI-generated images created. Edge also prioritized user safety, thwarting 127 million phishing attacks and helping users save an average of $400 annually.

## 1st Sainik school for girls opens in Vrindavan
 - [https://timesofindia.indiatimes.com/city/lucknow/countrys-1st-sainik-school-for-girls-opens-in-vrindavan/articleshow/106462816.cms](https://timesofindia.indiatimes.com/city/lucknow/countrys-1st-sainik-school-for-girls-opens-in-vrindavan/articleshow/106462816.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T02:00:27+00:00

The country's first Sainik school for girls has been inaugurated in Vrindavan. Chief Minister Yogi Adityanath and defence minister Rajnath Singh dedicated the Samvid Gurukulam Balika Sainya Vidyalaya to all girls in the country. The school is located in the Vatsalya Gram Parisar founded by Sadhvi Ritambhara. Along with a CBSE curriculum, military training will also be provided to students. The Sainik school will have 120 seats.

## Big Boss 17: Ankita reveals she was numb after Sushant's demise
 - [https://timesofindia.indiatimes.com/tv/news/hindi/bigg-boss-17-ankita-lokhande-reveals-she-was-angered-and-numb-seeing-the-heartbreaking-picture-of-sushant-singh-rajput-after-his-demise-says-mere-haath-paaon-thande-pad-rahe-the/articleshow/106462660.cms](https://timesofindia.indiatimes.com/tv/news/hindi/bigg-boss-17-ankita-lokhande-reveals-she-was-angered-and-numb-seeing-the-heartbreaking-picture-of-sushant-singh-rajput-after-his-demise-says-mere-haath-paaon-thande-pad-rahe-the/articleshow/106462660.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T01:43:46+00:00

Ankita discussed Sushant Singh Rajput's intelligence and his achievements. She mentioned that he was highly intelligent, an IIT student, and even achieved 7th rank in IIT. Ankita also talked about the heartbreaking photos of Sushant after his death and how it affected her. She praised Sushant and his family, mentioning that they were highly educated and intelligent. Ankita shared that Sushant's family members were in the USA, Chandigarh, Patna, and Delhi.

## Ayodhya: Mysuru sculptor's Ram idol frontrunner; BJP posts praise
 - [https://timesofindia.indiatimes.com/city/bengaluru/mysuru-sculptors-ram-idol-frontrunner-bjp-posts-praise/articleshow/106462610.cms](https://timesofindia.indiatimes.com/city/bengaluru/mysuru-sculptors-ram-idol-frontrunner-bjp-posts-praise/articleshow/106462610.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T01:35:33+00:00



## Box office report 2024: 'Dunki' & 'Salaar' ensure fantastic start
 - [https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/box-office/box-office-report-2024-dunki-and-salaar-ensure-fantastic-start-at-the-indian-box-office-with-rs-30-crore-haul/articleshow/106462434.cms](https://timesofindia.indiatimes.com/entertainment/hindi/bollywood/box-office/box-office-report-2024-dunki-and-salaar-ensure-fantastic-start-at-the-indian-box-office-with-rs-30-crore-haul/articleshow/106462434.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T01:16:12+00:00

Shah Rukh Khan's 'Dunki' and Prabhas' 'Salaar Cease Fire - Part 1' had a fantastic start at the Indian box office, earning a total collection of Rs 30 crores. 'Salaar Cease Fire - Part 1' earned around Rs 15.50 Crore on its eleventh day, while 'Dunki' earned around Rs 9.25 Crore net on its twelfth day for all languages. The audience's enthusiasm and positive word-of-mouth propelled these movies to unprecedented heights. 'Animal' and 'Sam Bahadur' also sustained their momentum, while regional films like 'Neru', 'Kaatera', and 'HiNanna' captivated audiences and contributed to the overall triumph at the box office.

## Uttarakhand bans agri land purchase by 'outsiders'
 - [https://timesofindia.indiatimes.com/city/dehradun/ukhand-bans-agri-land-purchase-by-outsiders/articleshow/106462357.cms](https://timesofindia.indiatimes.com/city/dehradun/ukhand-bans-agri-land-purchase-by-outsiders/articleshow/106462357.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T00:55:51+00:00

The Uttarakhand government has banned the purchase of agricultural and horticulture land by people of other states till the five-member committee submits its final report on new land laws. The committee, headed by additional chief secretary Radha Raturi, was tasked to review the draft submitted by former chief secretary Subhash Kumar in 2022. The ban includes a restriction on granting permission to 'outsiders' to purchase land for agricultural and horticulture purposes. The government aims to work in accordance with the sentiments of the people of Uttarakhand.

## GST kitty grows 10% in Dec on strong domestic sources
 - [https://timesofindia.indiatimes.com/business/india-business/gst-kitty-grows-10-in-december-on-strong-domestic-sources/articleshow/106462163.cms](https://timesofindia.indiatimes.com/business/india-business/gst-kitty-grows-10-in-december-on-strong-domestic-sources/articleshow/106462163.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T00:23:59+00:00

Goods and services tax (GST) collections rose 10.3% to Rs 1,64,882 crore during December, driven by domestic sources, while the rise in mop-up from imported goods lagged. Latest data released by the finance ministry pegged collections from domestic sources to have increased 13% in December (for transactions in November). While Central and State GST rose by around 14% each, integrated GST - levied on inter-state sales and imports - grew 7.4%, pulled down by imports. IGST on imports is estimated to have increased 3.2%, indicating that the value of shipments into the country remained muted during November.

## 4 properties of Dawood kin to be auctioned in Mumbai
 - [https://timesofindia.indiatimes.com/city/mumbai/four-properties-of-dawood-kin-to-be-auctioned-in-mumbai-on-friday/articleshow/106462162.cms](https://timesofindia.indiatimes.com/city/mumbai/four-properties-of-dawood-kin-to-be-auctioned-in-mumbai-on-friday/articleshow/106462162.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T00:23:45+00:00

Four properties in Khed taluka, Ratnagiri district, belonging to fugitive terrorist Dawood Ibrahim's mother Amina Bi, will be auctioned by the competent authority and administrator of the Smugglers and Foreign Exchange Manipulators (Forfeiture of Property) Act. The properties, located in Mumbake village, have a total reserve price of Rs 19.2 lakh. The auction will be held through e-auction, public auction, and tender in sealed envelope. This marks the 12th auction of properties belonging to Dawood or his kin in the past nine years.

## Now, Pannun threatens to target BSE, NSE on March 12
 - [https://timesofindia.indiatimes.com/india/now-pannun-threatens-to-target-bse-nse-on-march-12/articleshow/106462088.cms](https://timesofindia.indiatimes.com/india/now-pannun-threatens-to-target-bse-nse-on-march-12/articleshow/106462088.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-01-02T00:11:56+00:00



