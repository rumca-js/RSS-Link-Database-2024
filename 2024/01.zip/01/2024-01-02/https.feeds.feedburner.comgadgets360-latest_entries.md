# Source:Gadgets 360, URL:https://feeds.feedburner.com/gadgets360-latest, language:en

## Indian Railways Working on 'Super App' With Features Offered by Multiple Apps: Report
 - [https://www.gadgets360.com/apps/news/indian-railways-single-app-ticket-booking-train-tracking-4787639](https://www.gadgets360.com/apps/news/indian-railways-single-app-ticket-booking-train-tracking-4787639)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T14:50:30+00:00

There's no word on when the new app will be released by CRIS

## Poco M6 Pro 4G Global Launch Date Set for January 11; Price, Specifications Leaked Via Online Listing
 - [https://www.gadgets360.com/mobiles/news/poco-m6-pro-4g-launch-date-global-confirmed-specifications-price-expected-4786963](https://www.gadgets360.com/mobiles/news/poco-m6-pro-4g-launch-date-global-confirmed-specifications-price-expected-4786963)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T13:03:02+00:00

Poco M6 Pro 4G is expected to join Poco M6 Pro 5G (pictured) in the lineup

## Moto G34 5G Tipped to Launch in India on January 9
 - [https://www.gadgets360.com/mobiles/news/moto-g34-5g-india-launch-january-9-leak-4787008](https://www.gadgets360.com/mobiles/news/moto-g34-5g-india-launch-january-9-leak-4787008)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T12:38:07+00:00

Moto G34 5G was launched in Sea Blue and Star Black colours

## WhatsApp Drops Support for Unlimited Chat Backups on Google Drive With Latest Beta Update: Report
 - [https://www.gadgets360.com/apps/news/whatsapp-beta-android-unlimited-google-drive-chat-backups-discontinued-4786945](https://www.gadgets360.com/apps/news/whatsapp-beta-android-unlimited-google-drive-chat-backups-discontinued-4786945)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T12:16:38+00:00

WhatsApp users have enjoyed access to unlimited chat backups on Android since 2018

## Oppo Find X7 Leaks in New Hands-on Video Ahead of January 8 Launch
 - [https://www.gadgets360.com/mobiles/news/oppo-find-x7-hands-on-video-design-launch-january-8-specifications-4786670](https://www.gadgets360.com/mobiles/news/oppo-find-x7-hands-on-video-design-launch-january-8-specifications-4786670)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T11:50:31+00:00

Oppo Find X7 is confirmed to come in four RAM and storage configurations

## Poco X6 Pro Price, Specifications Leaked Via Online Listing Ahead of India Launch
 - [https://www.gadgets360.com/mobiles/news/poco-x6-pro-price-leak-specifications-expected-amazon-uae-listing-india-launch-january-11-4786515](https://www.gadgets360.com/mobiles/news/poco-x6-pro-price-leak-specifications-expected-amazon-uae-listing-india-launch-january-11-4786515)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T11:38:45+00:00

Poco X6 Pro is said to succeed the Poco X5 Pro (pictured)

## Oppo Reno 11 Series Confirmed to Launch in India Soon; Rear Panel Design Teased Ahead of Debut
 - [https://www.gadgets360.com/mobiles/news/oppo-reno-11-series-india-launch-confirmed-design-teaser-4786135](https://www.gadgets360.com/mobiles/news/oppo-reno-11-series-india-launch-confirmed-design-teaser-4786135)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T11:22:17+00:00

Oppo Reno 11 series was launched in China in November 2023

## Telegram Update Brings Redesigned Calls, Thanos Snap-Style Animation for Deleted Messages, More
 - [https://www.gadgets360.com/apps/news/telegram-update-ios-android-call-redesign-delete-message-animation-bots-4786122](https://www.gadgets360.com/apps/news/telegram-update-ios-android-call-redesign-delete-message-animation-bots-4786122)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T11:18:28+00:00

The Thanos Snap effect was first introduced for auto-deleted messages only on iOS

## Realme Note 50 4G Said to Launch in India Soon; Price, Specifications Tipped
 - [https://www.gadgets360.com/mobiles/news/realme-note-50-4g-price-india-leak-specifications-report-4786119](https://www.gadgets360.com/mobiles/news/realme-note-50-4g-price-india-leak-specifications-report-4786119)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T10:53:06+00:00

Realme C67 5G (pictured) was launched in India in December

## OnePlus Ace 3 Confirmed to Run on Snapdragon 8 Gen 2 SoC; Ace 3 Pro Specifications Tipped
 - [https://www.gadgets360.com/mobiles/news/oneplus-ace-3-pro-specifications-teaser-weibo-leak-4786013](https://www.gadgets360.com/mobiles/news/oneplus-ace-3-pro-specifications-teaser-weibo-leak-4786013)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T10:38:16+00:00

OnePlus Ace 3 is confirmed to come in black, blue, and gold colour options

## Honor Magic 6 Series Design Revealed; Colours, Storage Options Listed Online Ahead of Launch
 - [https://www.gadgets360.com/mobiles/news/honor-magic-6-pro-series-design-colour-options-storage-variants-china-launch-january-10-11-4785623](https://www.gadgets360.com/mobiles/news/honor-magic-6-pro-series-design-colour-options-storage-variants-china-launch-january-10-11-4785623)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T10:32:56+00:00

Honor Magic 6 series model seen in a green colour option

## Nothing CEO Carl Pei Teases Launch of Upcoming Smartphone; Purported Nothing Phone 2a Could Debut Soon
 - [https://www.gadgets360.com/mobiles/news/nothing-phone-2a-confirmed-ceo-carl-pei-2024-launch-4785678](https://www.gadgets360.com/mobiles/news/nothing-phone-2a-confirmed-ceo-carl-pei-2024-launch-4785678)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T09:05:40+00:00

Nothing Phone 2 (pictured) could be followed by a cheaper Nothing Phone 2a

## iPhone 15 Price in India Discounted to as Low as Rs. 69,999 on Flipkart
 - [https://www.gadgets360.com/mobiles/news/iphone-15-price-in-india-discount-128gb-price-cut-flipkart-4785584](https://www.gadgets360.com/mobiles/news/iphone-15-price-in-india-discount-128gb-price-cut-flipkart-4785584)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T09:02:41+00:00

iPhone 15 sports a 6.1-inch Super Retina XDR OLED display

## Google Maps Brings Real-Time Location Sharing on Android, iOS: Here's How to Enable the Feature
 - [https://www.gadgets360.com/apps/news/google-maps-real-time-location-sharing-feature-android-ios-whatsapp-imessage-4785480](https://www.gadgets360.com/apps/news/google-maps-real-time-location-sharing-feature-android-ios-whatsapp-imessage-4785480)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T08:06:19+00:00

You can also share your estimated time of arrival if you’re navigating to a destination

## Moto G Play (2024) Price, Design, Specifications Leak Online; 50-Megapixel Triple Rear Cameras Tipped
 - [https://www.gadgets360.com/mobiles/news/moto-g-play-2024-price-design-renders-specification-leak-4785057](https://www.gadgets360.com/mobiles/news/moto-g-play-2024-price-design-renders-specification-leak-4785057)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T06:31:22+00:00

Moto G Play (2024) is expected to launch this month

## WhatsApp Policy Violations Led to Over 71 Lakh Account Bans in India in November
 - [https://www.gadgets360.com/apps/news/whatsapp-banned-71-lakh-accounts-india-november-2023-4785060](https://www.gadgets360.com/apps/news/whatsapp-banned-71-lakh-accounts-india-november-2023-4785060)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T06:23:37+00:00

WhatsApp receives grievances from users via post and emails sent to the India Grievance Officer

## Xiaomi HyperOS India Release Confirmed; Rollout to Start With Xiaomi 13 Pro, Pad 6
 - [https://www.gadgets360.com/mobiles/news/xiaomi-hyperos-india-release-january-2024-xiaomi-13-pro-pad-6-4785007](https://www.gadgets360.com/mobiles/news/xiaomi-hyperos-india-release-january-2024-xiaomi-13-pro-pad-6-4785007)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T06:21:10+00:00

Xiaomi announced its HyperOS UI in October 2023

## Samsung Galaxy S24 Series Pre-Order Details Leak Out; Galaxy S24+ Spotted on Walmart Listing
 - [https://www.gadgets360.com/mobiles/news/samsung-s24-plus-ultra-price-preorder-bonuses-4k-video-120-fps-galaxy-leaks-4784675](https://www.gadgets360.com/mobiles/news/samsung-s24-plus-ultra-price-preorder-bonuses-4k-video-120-fps-galaxy-leaks-4784675)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T04:33:03+00:00

Samsung might give buyers double the storage for free if they pre-order Galaxy S24 Ultra

## Poco X6 Series Confirmed to Launch in India on January 11
 - [https://www.gadgets360.com/mobiles/news/poco-x6-pro-series-india-launch-date-january-11-flipkart-4784493](https://www.gadgets360.com/mobiles/news/poco-x6-pro-series-india-launch-date-january-11-flipkart-4784493)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-01-02T04:24:34+00:00

Poco X6 Pro is said to succeed the Poco X5 Pro (pictured)

