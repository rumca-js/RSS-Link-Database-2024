# Source:RT - Daily news, URL:https://www.rt.com/rss/, language:en

## US rejects Gaza ethnic cleansing proposal
 - [https://www.rt.com/news/590052-gaza-ethnic-cleansing-state-department/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590052-gaza-ethnic-cleansing-state-department/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T22:36:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65948a3f85f540084f0d074c.jpeg" style="margin-right: 10px;" /> US State Department spokesman Matthew Miller condemned Israeli ministers’ calls to remove Palestinians from Gaza <br /><a href="https://www.rt.com/news/590052-gaza-ethnic-cleansing-state-department/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia intercepts missiles aimed at Belgorod – military
 - [https://www.rt.com/russia/590051-belgorod-missiles-strike-intercepted/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590051-belgorod-missiles-strike-intercepted/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T22:15:32+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65948ad02030271dc259db06.jpg" style="margin-right: 10px;" /> Two Ukrainian Tochka-U ballistic missiles and seven more ‘Olkha’ MLRS rockets were reportedly shot down on Tuesday evening <br /><a href="https://www.rt.com/russia/590051-belgorod-missiles-strike-intercepted/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Chinese company surpasses Tesla
 - [https://www.rt.com/business/590050-byd-electric-vehicles-surpasses-tesla/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/590050-byd-electric-vehicles-surpasses-tesla/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T21:52:05+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6594852785f5407f4304aee8.jpg" style="margin-right: 10px;" /> Chinese carmaker BYD has surpassed Tesla as world’s largest seller of electric vehicles in 2023’s fourth quarter <br /><a href="https://www.rt.com/business/590050-byd-electric-vehicles-surpasses-tesla/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Hamas deputy killed in Beirut blast
 - [https://www.rt.com/news/590049-hamas-deputy-killed-beirut/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590049-hamas-deputy-killed-beirut/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T21:06:29+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6594755285f54001690d1eb6.jpg" style="margin-right: 10px;" /> Saleh al-Arouri, the deputy head of Hamas’ political wing, has been killed in an apparent Israeli drone strike in Lebanon <br /><a href="https://www.rt.com/news/590049-hamas-deputy-killed-beirut/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO member ‘hoped for different result’ in Ukraine – PM
 - [https://www.rt.com/russia/590044-lithuania-ukraine-offensive-disappointed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590044-lithuania-ukraine-offensive-disappointed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T20:39:52+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65945d1f85f5401b7a194341.jpg" style="margin-right: 10px;" /> Failure of Kiev’s summer offensive means a difficult 2024, Lithuanian PM Ingrida Simonyte told the state broadcaster LRT <br /><a href="https://www.rt.com/russia/590044-lithuania-ukraine-offensive-disappointed/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Saudi Arabia officially joins BRICS – state media
 - [https://www.rt.com/news/590048-saudi-arabia-joins-brics/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590048-saudi-arabia-joins-brics/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T20:32:59+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65947293203027079122260f.jpg" style="margin-right: 10px;" /> BRICS has welcomed five new members into its ranks, with the group expected to grow even larger later this year <br /><a href="https://www.rt.com/news/590048-saudi-arabia-joins-brics/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Doubts rise over Biden’s 2020 election victory – poll
 - [https://www.rt.com/news/590047-biden-poll-voters-doubt-legitimacy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590047-biden-poll-voters-doubt-legitimacy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T20:01:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6594680e85f54071890e76ea.jpg" style="margin-right: 10px;" /> US voters increasingly doubt the legitimacy of Joe Biden’s victory in the 2020 presidential election, poll shows <br /><a href="https://www.rt.com/news/590047-biden-poll-voters-doubt-legitimacy/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Harvard president resigns amid plagiarism scandal
 - [https://www.rt.com/news/590045-harvard-president-resigns-plagiarism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590045-harvard-president-resigns-plagiarism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T19:35:34+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65945e4e85f54068664149c9.jpg" style="margin-right: 10px;" /> Harvard University President Claudine Gay has resigned amid mounting accusations of academic plagiarism <br /><a href="https://www.rt.com/news/590045-harvard-president-resigns-plagiarism/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Police called to Soros home in prank
 - [https://www.rt.com/news/590046-george-soros-swatted-politicians-christmas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590046-george-soros-swatted-politicians-christmas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T19:25:17+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6594625285f5404b2b65142e.jpeg" style="margin-right: 10px;" /> Southampton police were called to billionaire currency speculator George Soros’ home over the weekend <br /><a href="https://www.rt.com/news/590046-george-soros-swatted-politicians-christmas/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Instagram influencer under investigation for burning Russian passport (VIDEO)
 - [https://www.rt.com/russia/590042-instagram-blogger-passport-burning/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590042-instagram-blogger-passport-burning/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T18:24:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659450e62030277bc906c4fe.png" style="margin-right: 10px;" /> A smalltime Russian Instagram influencer has ended up in legal trouble after burning her passport <br /><a href="https://www.rt.com/russia/590042-instagram-blogger-passport-burning/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## France to ‘change approach’ to Ukraine – ambassador
 - [https://www.rt.com/news/590043-france-ukraine-change-approach/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590043-france-ukraine-change-approach/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T18:08:01+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6594439085f540696551b248.jpg" style="margin-right: 10px;" /> Paris wants to support Kiev’s domestic weapons production rather than continuing to send donations, Ambassador Gael Veyssiere has said <br /><a href="https://www.rt.com/news/590043-france-ukraine-change-approach/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO state won't let UK send minesweepers to Ukraine
 - [https://www.rt.com/news/590041-turkiye-blocks-ships-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590041-turkiye-blocks-ships-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T17:03:57+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65943c3785f5404b2b651426.jpg" style="margin-right: 10px;" /> Türkiye says it will not allow two British minesweeping ships donated to Ukraine to enter the Black Sea <br /><a href="https://www.rt.com/news/590041-turkiye-blocks-ships-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## WATCH Russian military take out Leopard tanks in Ukraine
 - [https://www.rt.com/russia/590033-russia-ukraine-leopard-tanks-destroy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590033-russia-ukraine-leopard-tanks-destroy/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T16:22:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6594082185f540049745109e.png" style="margin-right: 10px;" /> The Russian military has taken out two of Ukraine’s German-made Leopard 2 tanks in the Donetsk region <br /><a href="https://www.rt.com/russia/590033-russia-ukraine-leopard-tanks-destroy/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Türkiye arrests suspected Israeli spies
 - [https://www.rt.com/news/590040-turkiye-arrests-israeli-spying-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590040-turkiye-arrests-israeli-spying-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T16:21:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659436f4203027046e5153c5.jpg" style="margin-right: 10px;" /> Türkiye has detained 33 people for allegedly plotting to trail, attack and kidnap foreign nationals on Israel’s behalf <br /><a href="https://www.rt.com/news/590040-turkiye-arrests-israeli-spying-hamas/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ex-Ukrainian president promises to pay for restoration of Nazi museum
 - [https://www.rt.com/russia/590039-poroshenko-nazi-museum-restoration/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590039-poroshenko-nazi-museum-restoration/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T16:09:33+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659427f085f54001690d1ea3.png" style="margin-right: 10px;" /> Former Ukrainian president Pyotr Poroshenko has vowed to restore a museum dedicated to World War II Nazi collaborator Roman Shukhevich <br /><a href="https://www.rt.com/russia/590039-poroshenko-nazi-museum-restoration/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Most German tanks given to Ukraine no longer working – lawmaker
 - [https://www.rt.com/news/590037-germany-tanks-ukraine-broken/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590037-germany-tanks-ukraine-broken/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T15:44:16+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6594232785f54067630ab390.jpg" style="margin-right: 10px;" /> Only a “small number” of the Leopard 2A6 tanks given to Ukraine by Germany are still working, German politician Sebastian Schafer said <br /><a href="https://www.rt.com/news/590037-germany-tanks-ukraine-broken/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Tiger blocks road in remote Russian region (VIDEO)
 - [https://www.rt.com/russia/590038-injured-amur-tiger-blocks-road-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590038-injured-amur-tiger-blocks-road-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T15:15:44+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6594251185f54001690d1e9e.jpg" style="margin-right: 10px;" /> An Amur tiger that had blocked a road in Russia’s far-eastern Khabarovsk Region turned out to have been seriously injured by a car <br /><a href="https://www.rt.com/russia/590038-injured-amur-tiger-blocks-road-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## BRICS represents ‘future of humanity’ – Venezuelan president
 - [https://www.rt.com/news/590035-venezuela-maduro-brics-argentina/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590035-venezuela-maduro-brics-argentina/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T14:50:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65940e2f85f5407f4304aece.jpg" style="margin-right: 10px;" /> Venezuelan President Nicolas Maduro has criticized his Argentinian counterpart Javier Milei for rejecting an invitation to join BRICS <br /><a href="https://www.rt.com/news/590035-venezuela-maduro-brics-argentina/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Africa’s Che Guevara: How France pulled off the ‘dirtiest trick’ to assassinate a popular reformer
 - [https://www.rt.com/africa/589422-africa-burkina-faso-france/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/589422-africa-burkina-faso-france/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T14:30:02+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/658447f320302717383a34e2.jpg" style="margin-right: 10px;" /> Over 30 years after the assassination of the president of Burkina Faso, some of those responsible for his death have not been punished <br /><a href="https://www.rt.com/africa/589422-africa-burkina-faso-france/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## 2024 is going to be ‘even more crazy’ – Elon Musk
 - [https://www.rt.com/news/590034-elon-musk-new-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590034-elon-musk-new-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T13:44:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65940bd7203027158e1a5c79.jpg" style="margin-right: 10px;" /> SpaceX CEO Elon Musk has predicted that 2024 will be “even more crazy” than the last four years <br /><a href="https://www.rt.com/news/590034-elon-musk-new-year/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia’s rich get richer – Bloomberg
 - [https://www.rt.com/business/590030-russia-billionaires-rich-bloomberg/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/590030-russia-billionaires-rich-bloomberg/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T13:36:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65941080203027180d178c5b.jpg" style="margin-right: 10px;" /> Top Russian billionaires have amassed an additional $50 billion in 2023, according to Bloomberg data <br /><a href="https://www.rt.com/business/590030-russia-billionaires-rich-bloomberg/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Three more Ukrainian ‘terrorist strikes’ on Belgorod repelled – Moscow
 - [https://www.rt.com/russia/590032-belgorod-three-ukrainian-strikes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590032-belgorod-three-ukrainian-strikes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T13:35:42+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6594059785f54067630ab389.jpg" style="margin-right: 10px;" /> The Russian military has prevented three Ukrainian attacks on Belgorod Region, shooting down 17 missiles <br /><a href="https://www.rt.com/russia/590032-belgorod-three-ukrainian-strikes/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ghanaian breaks world record, singing for more than five days straight
 - [https://www.rt.com/africa/589893-ghana-asantewaa-world-record-singing-marathon/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/589893-ghana-asantewaa-world-record-singing-marathon/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T13:02:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659406c3203027137a683034.jpg" style="margin-right: 10px;" /> A Ghanaian lady has unofficially broken the Guinness World Record for non-stop singing after performing for over 126 hours <br /><a href="https://www.rt.com/africa/589893-ghana-asantewaa-world-record-singing-marathon/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ex-US envoy grilled for questioning India-Russia ties
 - [https://www.rt.com/india/590031-ex-us-envoy-grilled-india-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/590031-ex-us-envoy-grilled-india-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T12:45:13+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/659403d1203027158e1a5c6c.jpg" style="margin-right: 10px;" /> Former US diplomat Michael McFaul has come under fire on social media for questioning the Indian foreign minister’s visit to Moscow <br /><a href="https://www.rt.com/india/590031-ex-us-envoy-grilled-india-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia explains target selection in new strikes on Ukraine
 - [https://www.rt.com/russia/590029-russia-strikes-ukraine-defense-industry/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590029-russia-strikes-ukraine-defense-industry/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T11:32:00+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6593ec00203027137a68302e.jpg" style="margin-right: 10px;" /> Russia has conducted a series of strikes on Ukrainian military-industrial facilities, its defense ministry has said <br /><a href="https://www.rt.com/russia/590029-russia-strikes-ukraine-defense-industry/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian neighbor hikes oil transit levy
 - [https://www.rt.com/business/590021-russia-kazakhstan-oil-transit/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/590021-russia-kazakhstan-oil-transit/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T10:57:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6593eb962030270c2e2ad40a.jpg" style="margin-right: 10px;" /> Kazakhstan has raised the tariff on transporting Russian oil through its territory by some 20% <br /><a href="https://www.rt.com/business/590021-russia-kazakhstan-oil-transit/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Mickey Mouse enters public domain
 - [https://www.rt.com/business/589643-mickey-mouse-public-domain-disney/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589643-mickey-mouse-public-domain-disney/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T09:45:39+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/65896a7885f5404a6641b584.jpg" style="margin-right: 10px;" /> The Walt Disney Company no longer has exclusive rights for its iconic Mickey and Minnie Mouse characters <br /><a href="https://www.rt.com/business/589643-mickey-mouse-public-domain-disney/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Powerful blasts reported in Ukrainian cities
 - [https://www.rt.com/russia/590027-powerful-blasts-ukrainian-cities/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590027-powerful-blasts-ukrainian-cities/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T09:42:00+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6593da0585f54071890e76c9.jpg" style="margin-right: 10px;" /> A series of blasts have rocked Kiev and Kharkov, according to local officials, after Moscow accused Ukraine of deadly “terrorist attacks” <br /><a href="https://www.rt.com/russia/590027-powerful-blasts-ukrainian-cities/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Passenger jet catches fire in Tokyo (VIDEOS)
 - [https://www.rt.com/news/590028-passenger-jet-catches-fire-tokyo/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590028-passenger-jet-catches-fire-tokyo/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T09:36:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/static.en/thumbnail/breaking.jpg" style="margin-right: 10px;" /> A passenger jet has caught fire at Tokyo’s Haneda Airport, with media reports alleging it may have collided with a coast guard aircraft <br /><a href="https://www.rt.com/news/590028-passenger-jet-catches-fire-tokyo/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Iran deploys navy to Red Sea – state media
 - [https://www.rt.com/news/590026-iran-deploys-navy-red-sea-us-houthis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590026-iran-deploys-navy-red-sea-us-houthis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T09:01:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6593c64585f54071890e76c2.jpg" style="margin-right: 10px;" /> Iran has deployed its Alborz destroyer to the Red Sea amid a US-led navy operation against Yemen’s Houthi militants <br /><a href="https://www.rt.com/news/590026-iran-deploys-navy-red-sea-us-houthis/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian oil refinery in EU state raided by authorities
 - [https://www.rt.com/business/590022-neftohim-russia-bulgaria-raid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/590022-neftohim-russia-bulgaria-raid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T08:37:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6593cab385f540795049c726.jpg" style="margin-right: 10px;" /> Bulgarian customs officials have inspected Lukoil’s Neftohim refinery to inventory oil stocks in view of a ban on Russian crude <br /><a href="https://www.rt.com/business/590022-neftohim-russia-bulgaria-raid/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel rejects hostage deal with Hamas – media
 - [https://www.rt.com/news/590025-israel-rejects-hostage-deal-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590025-israel-rejects-hostage-deal-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T08:13:13+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/6593c54085f54071890e76bf.jpg" style="margin-right: 10px;" /> Israel has rejected a prisoner swap deal with Hamas that could have brought a sustainable end to the hostilities, Axios reports <br /><a href="https://www.rt.com/news/590025-israel-rejects-hostage-deal-hamas/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Brits stealing food to sell on black market – report
 - [https://www.rt.com/business/589775-brits-stealing-food-black-market/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/589775-brits-stealing-food-black-market/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T05:10:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.12/thumbnail/658d502b2030275530342738.jpg" style="margin-right: 10px;" /> The UK experienced an unprecedented wave of retail crime in 2023 amid the worsening cost-of-living crisis <br /><a href="https://www.rt.com/business/589775-brits-stealing-food-black-market/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky unveils Ukrainian military goals for 2024
 - [https://www.rt.com/russia/590020-zelensky-crimea-attack-isolate/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590020-zelensky-crimea-attack-isolate/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T04:20:02+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65938cec203027180d178c45.png" style="margin-right: 10px;" /> President Vladimir Zelensky has shared fresh insight on Kiev’s top priorities, claiming that isolating Crimea was “extremely important” <br /><a href="https://www.rt.com/russia/590020-zelensky-crimea-attack-isolate/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## South Korean opposition leader stabbed in the neck
 - [https://www.rt.com/news/590019-south-korean-politician-stabbed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/590019-south-korean-politician-stabbed/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T02:10:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/static.en/thumbnail/breaking.jpg" style="margin-right: 10px;" />  <br /><a href="https://www.rt.com/news/590019-south-korean-politician-stabbed/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Thousands of migrants arrested in New Year raids – media
 - [https://www.rt.com/russia/590018-migrants-detained-petersburg-new-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/590018-migrants-detained-petersburg-new-year/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-01-02T00:24:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65935757203027111d004b3b.jpg" style="margin-right: 10px;" /> Some 3,000 foreign citizens were apprehended by police in St. Petersburg on New Year's Eve, with at least 100 of them now facing deportation <br /><a href="https://www.rt.com/russia/590018-migrants-detained-petersburg-new-year/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

