# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Paulina Smaszcz odpowiada na akt oskarżenia: nie mam sobie nic do zarzucenia
 - [https://www.wirtualnemedia.pl/artykul/paulina-smaszcz-oskrazona-zarzuty-prokuratura](https://www.wirtualnemedia.pl/artykul/paulina-smaszcz-oskrazona-zarzuty-prokuratura)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T18:28:19.798984+00:00

- Jestem zaskoczona decyzją prokuratury. W związku z tym, że nie mam sobie nic do zarzucenia, bardzo proszę o podawanie moich pełnych danych oraz publikację wizerunku - przekazała PAP we wtorek Paulina Smaszcz.

## Paulina Smaszcz odpowiada na akt oskarżenia: nie mam sobie nic do zarzucenia
 - [https://www.wirtualnemedia.pl/artykul/paulina-smaszcz-oskrazona-zarzuty-prokuratura-komentarz](https://www.wirtualnemedia.pl/artykul/paulina-smaszcz-oskrazona-zarzuty-prokuratura-komentarz)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T17:19:03.241799+00:00

- Jestem zaskoczona decyzją prokuratury. W związku z tym, że nie mam sobie nic do zarzucenia, bardzo proszę o podawanie moich pełnych danych oraz publikację wizerunku - przekazała PAP we wtorek Paulina Smaszcz.

## Andrzej Stec redaktorem naczelnym Bankier.pl
 - [https://www.wirtualnemedia.pl/artykul/andrzej-stec-redaktor-naczelny-bankier-pl](https://www.wirtualnemedia.pl/artykul/andrzej-stec-redaktor-naczelny-bankier-pl)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T17:19:03.239649+00:00

Stanowisko redaktora naczelnego portalu Bankier.pl (Bonnier Business Polska) objął Andrzej Stec. Poprzednio kierował redakcją „Parkietu”, a wcześniej pracował m.in. w „Pulsie Biznesu” i „Gazecie Wyborczej”.

## Paulina Smaszcz z zarzutami prokuratorskimi. Zgadza się na publikację danych i wizerunku
 - [https://www.wirtualnemedia.pl/artykul/paulina-smaszcz-z-zarzutami-prokuratorskimi-zgadza-sie-na-publikacje-danych-i-wizerunku](https://www.wirtualnemedia.pl/artykul/paulina-smaszcz-z-zarzutami-prokuratorskimi-zgadza-sie-na-publikacje-danych-i-wizerunku)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T15:07:43.844766+00:00

- Jestem zaskoczona decyzją prokuratury. W związku z tym, że nie mam sobie nic do zarzucenia, bardzo proszę o podawanie moich pełnych danych oraz publikację wizerunku - przekazała PAP we wtorek Paulina Smaszcz.

## Netflix zapowiada drugi sezon „Love Never Lies. Polska”
 - [https://www.wirtualnemedia.pl/artykul/netflix-drugi-sezon-love-never-lies-polska-premiera-gdzie-ogladac](https://www.wirtualnemedia.pl/artykul/netflix-drugi-sezon-love-never-lies-polska-premiera-gdzie-ogladac)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T14:02:40.833982+00:00

Platforma Netflix w najbliższym czasie pokaże drugi sezon reality-show „Love Never Lies. Polska”, który prowadzi Maja Bohosiewicz. Produkcja ponownie zrealizowana została w Grecji, za produkcję odpowiadała firma FremantleMedia Polska.

## Nie żyje dziennikarz sportowy Wojciech Bąkowicz. Miał 24 lata
 - [https://www.wirtualnemedia.pl/artykul/wojciech-bakowicz-zmarl-choroba-dziennikarz](https://www.wirtualnemedia.pl/artykul/wojciech-bakowicz-zmarl-choroba-dziennikarz)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T12:57:47.816226+00:00

W wieku 24 lat zmarł dziennikarz sportowy Wojciech Bąkowicz, związany m.in. z serwisem Łódzki Sport. Zmagał się z poważną niepełnosprawnością.

## Krzysztof Stanowski najczęściej czytanym dziennikarzem w X (Twitterze) w 2023 roku. Na podium Lis i Bok
 - [https://www.wirtualnemedia.pl/artykul/krzysztof-stanowski-najczesciej-czytanym-dziennikarzem-tomasz-lis-lukasz-bok-lista-top30](https://www.wirtualnemedia.pl/artykul/krzysztof-stanowski-najczesciej-czytanym-dziennikarzem-tomasz-lis-lukasz-bok-lista-top30)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T07:30:45.643508+00:00

Były współtwórca Kanału Sportowego Krzysztof Stanowski był w ubiegłym roku dziennikarzem z największymi zasięgami w serwisie X (Twitter) – wynika z danych PSMM Monitoring & More.

## Wysłano zawiadomienie do prokuratury ws. Moniki Jaruzelskiej. Będzie też wniosek do YouTube. "Nie żałuje, że zaprosiłam Brauna"
 - [https://www.wirtualnemedia.pl/artykul/monika-jaruzelska-grzegorz-braun-youtube-kanal-program-zawiadomienie-prokuratura-omzirk](https://www.wirtualnemedia.pl/artykul/monika-jaruzelska-grzegorz-braun-youtube-kanal-program-zawiadomienie-prokuratura-omzirk)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T03:08:10.960382+00:00

Ośrodek Monitorowania Zachowań Rasistowskich i Ksenofobicznych złożył zawiadomienie do prokuratury po emisji programu z udziałem posła Grzegorza Brauna, jaki pojawił się na kanale Moniki Jaruzelskiej. - Pan poseł nie powiedział u mnie niczego nowego ani zaskakującego. Nie żałuję, że go zaprosiłam - mówi dziennikarka w rozmowie z Wirtualnemedia.pl. OMZRIK zgłosi sprawę także do YouTube.

## Były dziennikarz TVP Info szykuje kanał youtube’owy. „Nie zawsze pracowałem w zgodzie z sumieniem”
 - [https://www.wirtualnemedia.pl/artykul/bartlomiej-graczak-tvp-info-youtube](https://www.wirtualnemedia.pl/artykul/bartlomiej-graczak-tvp-info-youtube)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T03:08:10.959295+00:00

Bartłomiej Graczak, przez ostatnie osiem lat dziennikarz „Wiadomości” i TVP Info, po odejściu z publicznego nadawcy przygotowuje własny kanał youtube’wy o tematyce społeczno-politycznej - dowiedział się portal Wirtualnemedia.pl. - Chcę pokazywać to, co interesujące i ważne dla widzów, a nie elit czy politycznych decydentów - zapowiada Graczak.

## Dominik Piechota: z Kanału Sportowego do Weszło.com
 - [https://www.wirtualnemedia.pl/artykul/dominik-piechota-weszlo-com-kanal-zero](https://www.wirtualnemedia.pl/artykul/dominik-piechota-weszlo-com-kanal-zero)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T02:03:14.013446+00:00

Dziennikarz piłkarski, Dominik Piłkarski, ostatnio związany z Kanałem Sportowym dołączył do zespołu portalu Weszło.com Krzysztofa Stanowskiego - dowiedział się serwis Wirtualnemedia.pl.

## Warner Bros przejęło platformę BluTV
 - [https://www.wirtualnemedia.pl/artykul/blutv-co-to-jest-jak-odbierac](https://www.wirtualnemedia.pl/artykul/blutv-co-to-jest-jak-odbierac)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T02:03:14.012919+00:00

Warner Bros Discovery sfinalizowało przejęcie tureckiej platformy streamingowej BluTV, w której udziały miało od 2021 roku.

## Zmiana w zarządzie Allegro. Nowym członkiem były menedżer Netii
 - [https://www.wirtualnemedia.pl/artykul/allegro-zarzad-david-roberts](https://www.wirtualnemedia.pl/artykul/allegro-zarzad-david-roberts)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T02:03:14.012386+00:00

Z zasiadania w zarządzie Allegro zrezygnował David Roberts, pozostaje w spółce jako dyrektor ds. technologii i produktu. Od kwietnia nowym członkiem zarządu firmy będzie Tom Ruhan.

## Jest nowy naczelny serwisów internetowych Grupy Infor. To były szef portalu Interia.pl
 - [https://www.wirtualnemedia.pl/artykul/infor-ryszard-pienkowski-krzysztof-fijalek](https://www.wirtualnemedia.pl/artykul/infor-ryszard-pienkowski-krzysztof-fijalek)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-01-02T02:03:14.011820+00:00

Krzysztof Fijałek został redaktorem naczelnym serwisów internetowych Grupy Infor - dowiedział się portal Wirtualnemedia.pl. To były redaktor naczelny portalu Interia.pl, a potem jego dyrektor wydawniczy.

