# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Oil prices rise amid escalating tensions in the Red Sea - latest updates
 - [https://www.telegraph.co.uk/business/2024/01/02/ftse-100-markets-latest-brent-crude-oil-prices-china-stock](https://www.telegraph.co.uk/business/2024/01/02/ftse-100-markets-latest-brent-crude-oil-prices-china-stock)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2024-01-02T07:11:44+00:00



