# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## Mickey Mouse Game Changes Name After Antisemitic Accusations
 - [https://kotaku.com/mickey-mouse-infestation-88-origins-horror-game-1851134630](https://kotaku.com/mickey-mouse-infestation-88-origins-horror-game-1851134630)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T21:17:11+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/cdcc47c0e7bfa3e7046b0c7eea745571.jpg" /><p>If you haven’t heard, the Steamboat Willie version of Mickey Mouse is officially in the public domain, and Nightmare Forge Games wasted no time announcing a horror game starring that version of Disney’s mascot called <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/mickey-mouse-disney-steamboat-willie-infestation-88-1851133439">Infestation 88</a>. However, upon announcement, the team was met with <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://x.com/oneirossandman/status/1741972491151593810?s=20" rel="noopener noreferrer" target="_blank">immediate pushback regarding the…</a></p><p><a href="https://kotaku.com/mickey-mouse-infestation-88-origins-horror-game-1851134630">Read more...</a></p>

## Jujutsu Kaisen Season 3 Will Kick Off A Bloody Tournament Arc
 - [https://kotaku.com/jujutsu-kaisen-season-3-teaser-culling-game-1851134414](https://kotaku.com/jujutsu-kaisen-season-3-teaser-culling-game-1851134414)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/3601c09fdd8281473cdfcee095639c41.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/jujutsu-kaisen-season-2-trailer-2023-1850459383">Jujutsu Kaisen</a> wrapped up earlier this week after a long and fairly grim season. You won’t be surprised to learn that it’s got another season in the works, once again courtesy of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/mappa-jujutsu-kaisen-crunch-allegations-1851034576">MAPPA</a>.<br /></p><p><a href="https://kotaku.com/jujutsu-kaisen-season-3-teaser-culling-game-1851134414">Read more...</a></p>

## Call Of Duty Ghost Thirst Propels Character To Top Of Fanfic Site
 - [https://kotaku.com/call-of-duty-ghost-soap-ship-ao3-gay-1851134343](https://kotaku.com/call-of-duty-ghost-soap-ship-ao3-gay-1851134343)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/9682953bb1d610423b31ae3c7e7c9f99.jpg" /><p>Some of you may be surprised that a gay Call of Duty ship is in the top ten of fanfiction site <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://archiveofourown.org/works/52723351" rel="noopener noreferrer" target="_blank">Archive Of Our Own’s annual, unofficial roundup</a>, but I’m not. Not long after the 2022 release of Modern Warfare II, a bevy of TikToks <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/call-of-duty-mw2-ghost-hot-tiktok-bimbo-thirst-trap-1849762466">bimbofied Call of Duty character Simon “Ghost” Riley</a>, who is only ever shown in-game…</p><p><a href="https://kotaku.com/call-of-duty-ghost-soap-ship-ao3-gay-1851134343">Read more...</a></p>

## Ubisoft Swiftly Corrects Star Wars Outlaws ‘Late 2024’ Release Window
 - [https://kotaku.com/star-wars-outlaws-late-2024-release-window-ubisoft-1851134277](https://kotaku.com/star-wars-outlaws-late-2024-release-window-ubisoft-1851134277)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T19:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/c5239373c7e35cd5da99ecdfcff4df18.jpg" /><p>Star Wars Outlaws, Ubisoft’s upcoming action-adventure game that follows scoundrel Kay Vess between The Empire Strikes Back and Return of the Jedi, previously had no release date beyond a very broad “2024” window. Today, however, a Disney Parks blog post quietly announced that it would launch in “late 2024.” This…</p><p><a href="https://kotaku.com/star-wars-outlaws-late-2024-release-window-ubisoft-1851134277">Read more...</a></p>

## The 26 Best Games For The Nintendo Switch
 - [https://kotaku.com/the-21-best-games-for-the-nintendo-switch-1794881447](https://kotaku.com/the-21-best-games-for-the-nintendo-switch-1794881447)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T19:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/stlvo07qxddvmw32usdl.png" /><div class="sc-1tkg6fj-0 cAhKLk"><div class="sc-1tkg6fj-1 dfxPHX"><span>Some of our posts include links to retailers. If you buy something from clicking on one, G/O Media may earn a commission. Because editorial staff is independent of commerce, affiliate linking does not influence our editorial content.</span></div></div><p>More than six years after its release, the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/11-things-every-new-nintendo-switch-owner-should-try-or-1848266762">Nintendo Switch</a> is still dutifully chugging along, and still without the long-rumored Switch Pro. Compared to its supercomputer competitors, Microsoft’s Xbox Series X and Sony’s PlayStation 5, it’s by no means the most powerful place to play games today. But it’s still the…</p><p><a href="https://kotaku.com/the-21-best-games-for-the-nintendo-switch-179

## Three Decades Later, Someone Has Finally Beaten Tetris On NES
 - [https://kotaku.com/twitch-youtube-blue-scuti-tetris-kill-screen-nes-1851134043](https://kotaku.com/twitch-youtube-blue-scuti-tetris-kill-screen-nes-1851134043)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/9971b74c14c112aadcb966f6cacb4348.jpg" /><p>Classic puzzle game Tetris has been around for over three decades, and in that time, plenty of people have<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.youtube.com/watch?v=k_O3Oaz2bos&amp;ab_channel=CleverUsername42" rel="noopener noreferrer" target="_blank"> reached its various endings</a>, usually by<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.vintageisthenewold.com/game-pedia/how-do-you-beat-tetris" rel="noopener noreferrer" target="_blank"> clearing four rows of bricks at once</a> like a digital demolitioner. That’s a challenge in and of itself, but now, someone has taken the concept of “beating Tetris” to the…</p><p><a href="https://kotaku.com/twitch-youtube-blue-scuti-tetris-kill-screen-nes-1851134043">Read more...</a></p>

## Sony Fined For Playing Hardball Against Third-Party Controllers
 - [https://kotaku.com/sony-ps4-dualshock-4-controller-gamepad-1851134003](https://kotaku.com/sony-ps4-dualshock-4-controller-gamepad-1851134003)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T18:33:07+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/0ffd0320aaa2b26ce1f1f76075db06f6.jpg" /><p>According to France’s Autorité de la concurrence, a government body responsible for regulating competition, Sony hasn’t been playing nice with third-party controllers on PS4. The regulatory body has fined Sony 13.5 million euros (roughly 14.8 million USD) for deploying “technical countermeasures [...] which affected…</p><p><a href="https://kotaku.com/sony-ps4-dualshock-4-controller-gamepad-1851134003">Read more...</a></p>

## Way Too Many Games Were Released On Steam In 2023
 - [https://kotaku.com/steam-pc-new-releases-valve-2023-1851133788](https://kotaku.com/steam-pc-new-releases-valve-2023-1851133788)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T17:15:52+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/0e46869eb0e65d32e5659b0cfd77dd7e.jpg" /><p>Steam is by far the most peculiar of online storefronts. Built on top of itself for the last twenty years, Valve’s behemothic PC game distributor is a clusterfuck of overlapping design choices, where algorithms rule over coherence, with 2023 seeing over 14,500 games released into the mayhem. Which is too many games.<br /></p><p><a href="https://kotaku.com/steam-pc-new-releases-valve-2023-1851133788">Read more...</a></p>

## Former ActiBlizz Employees Weigh In On Bobby Kotick’s Legacy
 - [https://kotaku.com/activision-blizzard-bobby-kotick-xbox-controversy-1851133675](https://kotaku.com/activision-blizzard-bobby-kotick-xbox-controversy-1851133675)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/14a3cc2e8873d460484791112593fd83.jpg" /><p>2024 is starting off strong: The controversial Bobby Kotick, former CEO of Activision Blizzard King, is no longer heading up the Call of Duty, World of Warcraft, and Overwatch 2 publisher. We knew this was going to happen—shortly after <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/microsoft-activision-blizzard-acquisition-game-pass-1850923561">Microsoft completed its massive $68 billion purchase</a> of ActiBlizz, the company…</p><p><a href="https://kotaku.com/activision-blizzard-bobby-kotick-xbox-controversy-1851133675">Read more...</a></p>

## These Incredible Cyberpunk 2077 Mods Will Make You Question Reality
 - [https://kotaku.com/cyberpunk-2077-graphics-mods-pc-rtx-4090-1851133618](https://kotaku.com/cyberpunk-2077-graphics-mods-pc-rtx-4090-1851133618)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T16:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/13b0a921ca56eb0c0e27809ba30820ff.jpg" /><p>Leave it to modders to push the boundaries of what was once (and arguably still is) one of the most impressive visual showcases of modern gaming: Cyberpunk 2077. A <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.reddit.com/r/cyberpunkgame/comments/18w8p6e/its_incredible_modders_were_able_to_achieve/" rel="noopener noreferrer" target="_blank">skyrocketing post on Reddit</a> shows off some pretty remarkable graphical feats that one enterprising player has achieved. Featuring a handful of mods that…</p><p><a href="https://kotaku.com/cyberpunk-2077-graphics-mods-pc-rtx-4090-1851133618">Read more...</a></p>

## Square Enix Will Be ‘Aggressive’ With Using AI For Development, CEO Says
 - [https://kotaku.com/square-enix-president-artificial-intelligence-ai-games-1851133573](https://kotaku.com/square-enix-president-artificial-intelligence-ai-games-1851133573)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/684bd9c105197efe08b8ad971b0adea5.jpg" /><p>It’s just two days into 2024 and a major video game company is already talking about its big AI plans. If you thought we were leaving AI discourse behind in 2023, I’m sorry to tell you that you were very, very wrong. A New Year’s letter from the current Square Enix president details the Final Fantasy VII Rebirth…</p><p><a href="https://kotaku.com/square-enix-president-artificial-intelligence-ai-games-1851133573">Read more...</a></p>

## Baldur’s Gate 3 Nude Scenes Are Getting Xbox Players Banned
 - [https://kotaku.com/baldurs-gate-3-xbox-series-x-s-nude-sex-scene-ban-1851133578](https://kotaku.com/baldurs-gate-3-xbox-series-x-s-nude-sex-scene-ban-1851133578)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a3398686295001ec0100fc4930d9601b.jpg" /><p>Baldur’s Gate 3 has been on Xbox Series X/S for <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/baldurs-gate-3-xbox-release-date-bg3-game-awards-1851081734">just under a month</a>, and while there have been <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/baldurs-gate-3-xbox-series-save-lost-crash-update-1851089258">a few technical issues with the RPG since arriving on the platform</a>, none has been more far-reaching than one that sprouted up over the weekend banning Xbox accounts that record and upload clips of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/baldurs-gate-3-sex-scene-romance-intimacy-halsin-gale-1850865892">sex scenes</a> or any moments…</p><p><a href="https://kotaku.com/baldurs-gate-3-xbox-series-x-s-nude-sex-scene-ban-1851133578

## Mickey Mouse Is Out Of Copyright And Straight Into Horror
 - [https://kotaku.com/mickey-mouse-disney-steamboat-willie-infestation-88-1851133439](https://kotaku.com/mickey-mouse-disney-steamboat-willie-infestation-88-1851133439)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/20bd8092597bf44b483a9256b6b3e4c5.jpg" /><p>The New Year brought the excellent news that Steamboat Willie-era <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/disney-illusion-island-coop-multiplayer-nintendo-switch-1850544876">Mickey Mouse</a> has finally entered the public domain, after decades of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/disney-world-land-tickets-2023-design-lines-mickey-park-1850046765">Disney</a>, er, convincing Congress to keep extending its copyrights. With that, derivative works that don’t directly contravene Disney’s trademarks are now allowed by law, and with that,…</p><p><a href="https://kotaku.com/mickey-mouse-disney-steamboat-willie-infestation-88-1851133439">Read more...</a></p>

## Meta’s Quest 2 VR Headset Is Cheaper Than Ever
 - [https://kotaku.com/meta-quest-2-price-decrease-vr-headset-1851133448](https://kotaku.com/meta-quest-2-price-decrease-vr-headset-1851133448)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-01-02T15:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/598495ed81144e7ff0dfa17168f62d4e.jpg" /><p>First <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/facebook-meta-quest-2-price-tiktok-mark-zuckerberg-1849333729">the price went up</a>, and now, following the release of a newer headset from Meta, the very popular Meta Quest 2 has dropped to a new low of $250, making it a much easier buy for the VR-curious. </p><p><a href="https://kotaku.com/meta-quest-2-price-decrease-vr-headset-1851133448">Read more...</a></p>

