# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## Automatic planted bowl water top up
 - [https://www.reddit.com/r/3Dprinting/comments/18x2n3w/automatic_planted_bowl_water_top_up](https://www.reddit.com/r/3Dprinting/comments/18x2n3w/automatic_planted_bowl_water_top_up)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T22:37:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18x2n3w/automatic_planted_bowl_water_top_up/"> <img alt="Automatic planted bowl water top up " src="https://external-preview.redd.it/N3loNmJjNW10M2FjMVE-U0NexA1hY8nRCy7g3yIGKBtn0xrmKSrwTd7PTJY1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=1c8967ac48953fb6007ef46f0853bdff5367916d" title="Automatic planted bowl water top up " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This is a quick design I made to keep my planted bowl topped up with water. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sebadria"> /u/Sebadria </a> <br /> <span><a href="https://v.redd.it/wh6ca8dot3ac1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18x2n3w/automatic_planted_bowl_water_top_up/">[comments]</a></span> </td></tr></table>

## Amiibo Potion Stand (by Holoprops)
 - [https://www.reddit.com/r/3Dprinting/comments/18x0w60/amiibo_potion_stand_by_holoprops](https://www.reddit.com/r/3Dprinting/comments/18x0w60/amiibo_potion_stand_by_holoprops)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T21:28:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18x0w60/amiibo_potion_stand_by_holoprops/"> <img alt="Amiibo Potion Stand (by Holoprops)" src="https://b.thumbs.redditmedia.com/Z16HtE5eBZMEJB7-me7Kv7cpWPwgVJbOGee8NXy14jA.jpg" title="Amiibo Potion Stand (by Holoprops)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/awyeahmuffins"> /u/awyeahmuffins </a> <br /> <span><a href="https://www.reddit.com/gallery/18x0w60">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18x0w60/amiibo_potion_stand_by_holoprops/">[comments]</a></span> </td></tr></table>

## My newest free and open-source handwired keyboard, the ScottoKatana
 - [https://www.reddit.com/r/3Dprinting/comments/18x0lbm/my_newest_free_and_opensource_handwired_keyboard](https://www.reddit.com/r/3Dprinting/comments/18x0lbm/my_newest_free_and_opensource_handwired_keyboard)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T21:16:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18x0lbm/my_newest_free_and_opensource_handwired_keyboard/"> <img alt="My newest free and open-source handwired keyboard, the ScottoKatana" src="https://b.thumbs.redditmedia.com/4EreY6uqT79rKd9IJaeMPYka2m7fryJwcgkhsRodQiQ.jpg" title="My newest free and open-source handwired keyboard, the ScottoKatana" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Joe_Scotto"> /u/Joe_Scotto </a> <br /> <span><a href="https://scottokeebs.com/blogs/keyboards/scottokatana-handwired-keyboard">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18x0lbm/my_newest_free_and_opensource_handwired_keyboard/">[comments]</a></span> </td></tr></table>

## New 3D print setup (Ikea)
 - [https://www.reddit.com/r/3Dprinting/comments/18x0fdv/new_3d_print_setup_ikea](https://www.reddit.com/r/3Dprinting/comments/18x0fdv/new_3d_print_setup_ikea)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T21:09:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18x0fdv/new_3d_print_setup_ikea/"> <img alt="New 3D print setup (Ikea)" src="https://b.thumbs.redditmedia.com/pWEXPYsEEx14FGcD9JhMqspYzssAtSrB85kHmZFRvRA.jpg" title="New 3D print setup (Ikea)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I desperately needed to re do my 3D print space as my current setup was just kinda “for now”. I spent about $300 bucks at my local ikea and created this setup. Swipe to see the original setup 😬(Dont judge me 🥺) </p> <p>Just waiting on more RGB LEDs because you can never have enough RGB ☝🏾</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GalaxyGoddess27"> /u/GalaxyGoddess27 </a> <br /> <span><a href="https://www.reddit.com/gallery/18x0fdv">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18x0fdv/new_3d_print_setup_ikea/">[comments]</a></span> </td></tr></table>

## New printer. Beer for scale.
 - [https://www.reddit.com/r/3Dprinting/comments/18wz47o/new_printer_beer_for_scale](https://www.reddit.com/r/3Dprinting/comments/18wz47o/new_printer_beer_for_scale)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T20:17:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wz47o/new_printer_beer_for_scale/"> <img alt="New printer. Beer for scale." src="https://preview.redd.it/2joijgso43ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6c9e865ab41b0a77303112f90702aede31e26f82" title="New printer. Beer for scale." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FallaciousAnemia"> /u/FallaciousAnemia </a> <br /> <span><a href="https://i.redd.it/2joijgso43ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wz47o/new_printer_beer_for_scale/">[comments]</a></span> </td></tr></table>

## My first ever blender model has come to life! Meet Stella, the Guitar Pick Stegosaurus
 - [https://www.reddit.com/r/3Dprinting/comments/18wywb0/my_first_ever_blender_model_has_come_to_life_meet](https://www.reddit.com/r/3Dprinting/comments/18wywb0/my_first_ever_blender_model_has_come_to_life_meet)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T20:08:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wywb0/my_first_ever_blender_model_has_come_to_life_meet/"> <img alt="My first ever blender model has come to life! Meet Stella, the Guitar Pick Stegosaurus" src="https://a.thumbs.redditmedia.com/jLK3G8SXH_OyNqLekaDB2ffzbbnNCy168NeHvsNAH18.jpg" title="My first ever blender model has come to life! Meet Stella, the Guitar Pick Stegosaurus" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Meet Stella, the sleeping stegosaurus / guitar pick holder! This is my first attempt at both 1. Modeling in Blender, and 2. Printing an original piece. It is definitely a bit rough around the edges (and MUCH bigger than I was initially intending!), but I am super happy with how it turned out. If anyone wants to optimize or adjust the model on their own, feel free. </p> <p>Here's a link to the model: printables.com/model/704100-stella-the-guitar-pick-stegosaurus.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://

## I designed and 3D printed a 1/12 scale Millennium Falcon diorama.
 - [https://www.reddit.com/r/3Dprinting/comments/18wyvpm/i_designed_and_3d_printed_a_112_scale_millennium](https://www.reddit.com/r/3Dprinting/comments/18wyvpm/i_designed_and_3d_printed_a_112_scale_millennium)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T20:07:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wyvpm/i_designed_and_3d_printed_a_112_scale_millennium/"> <img alt="I designed and 3D printed a 1/12 scale Millennium Falcon diorama." src="https://b.thumbs.redditmedia.com/Mzldj6yQTkuVcMEJYE6AGFXqpyEiaVU3gIxKFvGf1iM.jpg" title="I designed and 3D printed a 1/12 scale Millennium Falcon diorama." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/landspeederluke"> /u/landspeederluke </a> <br /> <span><a href="https://www.reddit.com/gallery/18wyvpm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wyvpm/i_designed_and_3d_printed_a_112_scale_millennium/">[comments]</a></span> </td></tr></table>

## I've built an Alien Stasis tank !
 - [https://www.reddit.com/r/3Dprinting/comments/18wyr5b/ive_built_an_alien_stasis_tank](https://www.reddit.com/r/3Dprinting/comments/18wyr5b/ive_built_an_alien_stasis_tank)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T20:02:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wyr5b/ive_built_an_alien_stasis_tank/"> <img alt="I've built an Alien Stasis tank !" src="https://b.thumbs.redditmedia.com/cxMp2_9hNoWEiuzuqpLY7zm2s3uLA5DefG1SJPeB83o.jpg" title="I've built an Alien Stasis tank !" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rmcv02"> /u/rmcv02 </a> <br /> <span><a href="https://www.reddit.com/gallery/18wyr5b">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wyr5b/ive_built_an_alien_stasis_tank/">[comments]</a></span> </td></tr></table>

## Forgot to add Supports. Pleasantly surprised
 - [https://www.reddit.com/r/3Dprinting/comments/18wy7hj/forgot_to_add_supports_pleasantly_surprised](https://www.reddit.com/r/3Dprinting/comments/18wy7hj/forgot_to_add_supports_pleasantly_surprised)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T19:41:26+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wy7hj/forgot_to_add_supports_pleasantly_surprised/"> <img alt="Forgot to add Supports. Pleasantly surprised" src="https://preview.redd.it/r4f8tmhdy2ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a5829548f070cacaa942409c08dbf10ec0016a6b" title="Forgot to add Supports. Pleasantly surprised" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Anycubic Kobra with eSun PLA+</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/leoncon99"> /u/leoncon99 </a> <br /> <span><a href="https://i.redd.it/r4f8tmhdy2ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wy7hj/forgot_to_add_supports_pleasantly_surprised/">[comments]</a></span> </td></tr></table>

## Slicer Question
 - [https://www.reddit.com/r/3Dprinting/comments/18wxee0/slicer_question](https://www.reddit.com/r/3Dprinting/comments/18wxee0/slicer_question)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T19:09:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wxee0/slicer_question/"> <img alt="Slicer Question" src="https://preview.redd.it/cxhr1s8ms2ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1cea669be1af5356893e616ad8f6683b77a8b349" title="Slicer Question" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hi! We are new to the world of 3D printing and my son got a Flashforge Finder 3 for Christmas. He fell in love with 3D printing and shortly thereafter received a used Ender 3 And Creality CR-10. </p> <p>My question is this, do I have to download Creality’s slicer as well, since we use Flashprint for the Flashforge? Or is there one that will work for them all? </p> <p>Again, we are noobs so no hate please. Pictures of a recent print he did for attention</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Faete13"> /u/Faete13 </a> <br /> <span><a href="https://i.redd.it/cxhr1s8ms2ac1.jpeg">[link]</a></span> &#32; <span><a

## Jabba the Butt came out pretty good
 - [https://www.reddit.com/r/3Dprinting/comments/18wwqkx/jabba_the_butt_came_out_pretty_good](https://www.reddit.com/r/3Dprinting/comments/18wwqkx/jabba_the_butt_came_out_pretty_good)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T18:42:44+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Archlinder"> /u/Archlinder </a> <br /> <span><a href="https://www.reddit.com/gallery/18wwqkx">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wwqkx/jabba_the_butt_came_out_pretty_good/">[comments]</a></span>

## Ok Sunlu what the freak
 - [https://www.reddit.com/r/3Dprinting/comments/18wun4n/ok_sunlu_what_the_freak](https://www.reddit.com/r/3Dprinting/comments/18wun4n/ok_sunlu_what_the_freak)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T17:19:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wun4n/ok_sunlu_what_the_freak/"> <img alt="Ok Sunlu what the freak" src="https://preview.redd.it/gdtmyjf292ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=75286e4a7bcc6202fa74dccc900f92d77481722c" title="Ok Sunlu what the freak" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Sunlu White high speed pla, caused a clog on my K1 Max. This filament has a lot of issues not only this, although seems to have no tangles. For anyone who wants to buy this, don’t, but if u do, make sure to set nozzle temperature to 200c, no higher, and bed to 65c. Defo has some quality issues. Btw this is 1.75mm filament</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DHAMak"> /u/DHAMak </a> <br /> <span><a href="https://i.redd.it/gdtmyjf292ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wun4n/ok_sunlu_what_the_freak/">[comments]</a></span> </t

## Mew-Two Incubator
 - [https://www.reddit.com/r/3Dprinting/comments/18wuevw/mewtwo_incubator](https://www.reddit.com/r/3Dprinting/comments/18wuevw/mewtwo_incubator)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T17:10:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wuevw/mewtwo_incubator/"> <img alt="Mew-Two Incubator " src="https://external-preview.redd.it/YWJqdmIydGQ3MmFjMUWAXeAYPt8gEF4qkzB-9b4x2_uIY9nkbRhSp37oOCLc.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=72251303e97afa0521447be4311a483f75f6363f" title="Mew-Two Incubator " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Just a quick one day project. Getting that water to stay in was a challenge 😤</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SubZeroX29"> /u/SubZeroX29 </a> <br /> <span><a href="https://v.redd.it/9z2xckvd72ac1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wuevw/mewtwo_incubator/">[comments]</a></span> </td></tr></table>

## It didn’t tip over!
 - [https://www.reddit.com/r/3Dprinting/comments/18wtjeg/it_didnt_tip_over](https://www.reddit.com/r/3Dprinting/comments/18wtjeg/it_didnt_tip_over)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T16:34:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wtjeg/it_didnt_tip_over/"> <img alt="It didn’t tip over!" src="https://preview.redd.it/1g98tnuz02ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=519ad4a0c4913051a338402881143ddb47abee74" title="It didn’t tip over!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>200 mm tall by 13mm diameter. I can’t believe it adhered. The layers got a touch shifty towards the top. I presume because it was wobbling a bit. PEI bed with a little glue stick.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/i_eat_the_fat"> /u/i_eat_the_fat </a> <br /> <span><a href="https://i.redd.it/1g98tnuz02ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wtjeg/it_didnt_tip_over/">[comments]</a></span> </td></tr></table>

## PLA wont stick to PEI board
 - [https://www.reddit.com/r/3Dprinting/comments/18wt4t2/pla_wont_stick_to_pei_board](https://www.reddit.com/r/3Dprinting/comments/18wt4t2/pla_wont_stick_to_pei_board)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T16:17:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wt4t2/pla_wont_stick_to_pei_board/"> <img alt="PLA wont stick to PEI board" src="https://b.thumbs.redditmedia.com/HVrOvMaAM8bjVXsDRYtmobd5Y3-QwHgvMg5O8jJpafo.jpg" title="PLA wont stick to PEI board" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Basically title. I have tried for two days to figure out why my PLA isn’t sticking to this PEI board I got. Im new to 3D printing and got the Ender 3 V2 for Christmas. Ive leveled the bed 1000 times, tried changing the heat settings, but nothing seems to be working.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/cptbigb1"> /u/cptbigb1 </a> <br /> <span><a href="https://www.reddit.com/gallery/18wt4t2">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wt4t2/pla_wont_stick_to_pei_board/">[comments]</a></span> </td></tr></table>

## My first self designed functional print
 - [https://www.reddit.com/r/3Dprinting/comments/18wsnk8/my_first_self_designed_functional_print](https://www.reddit.com/r/3Dprinting/comments/18wsnk8/my_first_self_designed_functional_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T15:57:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wsnk8/my_first_self_designed_functional_print/"> <img alt="My first self designed functional print" src="https://preview.redd.it/c4ngu39fu1ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b70d9d58bc971d2f2bcd89305417e3cb4f11feb6" title="My first self designed functional print" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Needed to put a piece of furniture up against the wall where my Ethernet port was. I took somebody else’s design for the actual interface with the keystone jack after losing patience trying to size it myself but otherwise it’s all me! </p> <p><a href="https://www.printables.com/model/701626-angled-keystone-plate">https://www.printables.com/model/701626-angled-keystone-plate</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Johnny_Thunder314"> /u/Johnny_Thunder314 </a> <br /> <span><a href="https://i.redd.it/c4ngu39fu1ac1.jpeg">[link]</a></span

## Is this z wobble?
 - [https://www.reddit.com/r/3Dprinting/comments/18wshr4/is_this_z_wobble](https://www.reddit.com/r/3Dprinting/comments/18wshr4/is_this_z_wobble)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T15:50:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wshr4/is_this_z_wobble/"> <img alt="Is this z wobble?" src="https://preview.redd.it/v3rbrju4t1ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5da88548b89afd17235a35a3c991fa0f56db53ac" title="Is this z wobble?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This is my first time printing in ultra detail on my prussaon Mark 3s+ printed over night so temps might have changed in this room. I'm waiting on some aluminum extrusion to build my enclosure.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NegligentShotz"> /u/NegligentShotz </a> <br /> <span><a href="https://i.redd.it/v3rbrju4t1ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wshr4/is_this_z_wobble/">[comments]</a></span> </td></tr></table>

## Did an experiment just for the hell of it
 - [https://www.reddit.com/r/3Dprinting/comments/18ws837/did_an_experiment_just_for_the_hell_of_it](https://www.reddit.com/r/3Dprinting/comments/18ws837/did_an_experiment_just_for_the_hell_of_it)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T15:38:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18ws837/did_an_experiment_just_for_the_hell_of_it/"> <img alt="Did an experiment just for the hell of it" src="https://preview.redd.it/dacyv0v1r1ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5e47d1f69711b11636f65df36b7bdd93ca5d6a80" title="Did an experiment just for the hell of it" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Apparently TPU doesn't print well as chainmail. I know it's redundant since TPU is flexible anyway, but it ended up being a flexible mat</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/pandabatallion"> /u/pandabatallion </a> <br /> <span><a href="https://i.redd.it/dacyv0v1r1ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18ws837/did_an_experiment_just_for_the_hell_of_it/">[comments]</a></span> </td></tr></table>

## Most slicers are working on pc
 - [https://www.reddit.com/r/3Dprinting/comments/18ws2n3/most_slicers_are_working_on_pc](https://www.reddit.com/r/3Dprinting/comments/18ws2n3/most_slicers_are_working_on_pc)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T15:31:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18ws2n3/most_slicers_are_working_on_pc/"> <img alt="Most slicers are working on pc" src="https://preview.redd.it/8s0jp0hup1ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=56026c0af857ff04de17c21b40693fcd43bbaba5" title="Most slicers are working on pc" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I have been having problems with many slicers for some reason orca slicer, Prusa slicer and bambulab slicer they all stay on the loading configurations screen on startup. The only slicers that do work are Creality print and cura slicer. I have tried uninstalling and reinstalling and restarting my pc</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Icy_Wolf_6940"> /u/Icy_Wolf_6940 </a> <br /> <span><a href="https://i.redd.it/8s0jp0hup1ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18ws2n3/most_slicers_are_working_on_pc/">[comme

## Created these handles for the small jewellers files that are hard to grip!
 - [https://www.reddit.com/r/3Dprinting/comments/18wrx1a/created_these_handles_for_the_small_jewellers](https://www.reddit.com/r/3Dprinting/comments/18wrx1a/created_these_handles_for_the_small_jewellers)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T15:25:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wrx1a/created_these_handles_for_the_small_jewellers/"> <img alt="Created these handles for the small jewellers files that are hard to grip!" src="https://preview.redd.it/0ztppu3ko1ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=224185c7bdfccd319f54be8a570aa7a4a3ee9c62" title="Created these handles for the small jewellers files that are hard to grip!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/obscuresausage"> /u/obscuresausage </a> <br /> <span><a href="https://i.redd.it/0ztppu3ko1ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wrx1a/created_these_handles_for_the_small_jewellers/">[comments]</a></span> </td></tr></table>

## Action Cam Tether Car
 - [https://www.reddit.com/r/3Dprinting/comments/18wqp8s/action_cam_tether_car](https://www.reddit.com/r/3Dprinting/comments/18wqp8s/action_cam_tether_car)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T14:29:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wqp8s/action_cam_tether_car/"> <img alt="Action Cam Tether Car" src="https://preview.redd.it/prtah7wqe1ac1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=2e52eef18f4f80a1029e9c1b80f3b096c9b48531" title="Action Cam Tether Car" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I made this to get stable footage where you can't fly a drone or walk easily</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Anyhting_But_Stock"> /u/Anyhting_But_Stock </a> <br /> <span><a href="https://i.redd.it/prtah7wqe1ac1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wqp8s/action_cam_tether_car/">[comments]</a></span> </td></tr></table>

## Rest in peace Aiko🕊
 - [https://www.reddit.com/r/3Dprinting/comments/18wqh5j/rest_in_peace_aiko](https://www.reddit.com/r/3Dprinting/comments/18wqh5j/rest_in_peace_aiko)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T14:19:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wqh5j/rest_in_peace_aiko/"> <img alt="Rest in peace Aiko🕊" src="https://b.thumbs.redditmedia.com/hOTzCaoIXwjJ5lBJCmepa363hEW_Khsf3ciRZwGnmQg.jpg" title="Rest in peace Aiko🕊" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheFrogWithAHat"> /u/TheFrogWithAHat </a> <br /> <span><a href="https://www.reddit.com/gallery/18wqgov">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wqh5j/rest_in_peace_aiko/">[comments]</a></span> </td></tr></table>

## Just made this full size Witherhoard from Destiny 2!!!!!!!
 - [https://www.reddit.com/r/3Dprinting/comments/18wnpnt/just_made_this_full_size_witherhoard_from_destiny](https://www.reddit.com/r/3Dprinting/comments/18wnpnt/just_made_this_full_size_witherhoard_from_destiny)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T11:54:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wnpnt/just_made_this_full_size_witherhoard_from_destiny/"> <img alt="Just made this full size Witherhoard from Destiny 2!!!!!!!" src="https://b.thumbs.redditmedia.com/-UET6JlnttMmjbufvci3CBJkxOqJxLdQqs6Kx6qsLNo.jpg" title="Just made this full size Witherhoard from Destiny 2!!!!!!!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Angels3DCustoms"> /u/Angels3DCustoms </a> <br /> <span><a href="https://www.reddit.com/gallery/18wnpnt">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wnpnt/just_made_this_full_size_witherhoard_from_destiny/">[comments]</a></span> </td></tr></table>

## Frequent clogs for a new printer
 - [https://www.reddit.com/r/3Dprinting/comments/18wneek/frequent_clogs_for_a_new_printer](https://www.reddit.com/r/3Dprinting/comments/18wneek/frequent_clogs_for_a_new_printer)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T11:34:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wneek/frequent_clogs_for_a_new_printer/"> <img alt="Frequent clogs for a new printer" src="https://b.thumbs.redditmedia.com/fNEhY5YOy-SpTx_OSW-3zOCh_2VEIcjPCefbQ4GTNmI.jpg" title="Frequent clogs for a new printer" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hey all.</p> <p>I’m brand new to 3d printing, as I just got one for Christmas. I’ve discovered there’s a huge learning curve with these machines and it seems every time I print I run into a snag. </p> <p>I’m having trouble with my nozzle clogging mid-print. I’ve watched dozens of YouTube videos and read a ton of Reddit posts, but all the tips and tricks I’ve learned haven’t helped this nozzle clogging issue. Twice now I’ve left something to print overnight only to wake up to the print only to have stopped in the exact same place. The first time I caught the printer going in midair, and I can only assume it happened again. </p> <p>What am I doing wrong

## Diorama elements coming together.🤙🏾
 - [https://www.reddit.com/r/3Dprinting/comments/18wna99/diorama_elements_coming_together](https://www.reddit.com/r/3Dprinting/comments/18wna99/diorama_elements_coming_together)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T11:26:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wna99/diorama_elements_coming_together/"> <img alt="Diorama elements coming together.🤙🏾" src="https://preview.redd.it/491rurq4i0ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8a8d741307fbe84d08de212556186c16e72848dd" title="Diorama elements coming together.🤙🏾" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Over2023"> /u/Over2023 </a> <br /> <span><a href="https://i.redd.it/491rurq4i0ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wna99/diorama_elements_coming_together/">[comments]</a></span> </td></tr></table>

## The desktop mini toolbox. Inspired by Snapon.
 - [https://www.reddit.com/r/3Dprinting/comments/18wn129/the_desktop_mini_toolbox_inspired_by_snapon](https://www.reddit.com/r/3Dprinting/comments/18wn129/the_desktop_mini_toolbox_inspired_by_snapon)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T11:11:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wn129/the_desktop_mini_toolbox_inspired_by_snapon/"> <img alt="The desktop mini toolbox. Inspired by Snapon." src="https://b.thumbs.redditmedia.com/aaFvo5eMxUqCU_rTfkkT3UGYaGBBEAUvO3yy0sIpXoc.jpg" title="The desktop mini toolbox. Inspired by Snapon." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><a href="https://www.printables.com/model/702916-desktop-mini-toolbox">https://www.printables.com/model/702916-desktop-mini-toolbox</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DogetheWow2"> /u/DogetheWow2 </a> <br /> <span><a href="https://www.reddit.com/gallery/18wn129">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wn129/the_desktop_mini_toolbox_inspired_by_snapon/">[comments]</a></span> </td></tr></table>

## The first thing I modelled and printed by myself.
 - [https://www.reddit.com/r/3Dprinting/comments/18wmn0a/the_first_thing_i_modelled_and_printed_by_myself](https://www.reddit.com/r/3Dprinting/comments/18wmn0a/the_first_thing_i_modelled_and_printed_by_myself)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T10:46:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wmn0a/the_first_thing_i_modelled_and_printed_by_myself/"> <img alt="The first thing I modelled and printed by myself." src="https://b.thumbs.redditmedia.com/gSB3X72_Fj_DiAas3iPrOA86PZMuhhisfvjusGvc63E.jpg" title="The first thing I modelled and printed by myself." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I spent a lot of plastic on supports and, due to my lack of patience, I made a couple of chips. I couldn't remove the support inside.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NewWritterKir"> /u/NewWritterKir </a> <br /> <span><a href="https://www.reddit.com/gallery/18wmn0a">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wmn0a/the_first_thing_i_modelled_and_printed_by_myself/">[comments]</a></span> </td></tr></table>

## Bottom of prints look terrible
 - [https://www.reddit.com/r/3Dprinting/comments/18wmj76/bottom_of_prints_look_terrible](https://www.reddit.com/r/3Dprinting/comments/18wmj76/bottom_of_prints_look_terrible)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T10:39:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wmj76/bottom_of_prints_look_terrible/"> <img alt="Bottom of prints look terrible" src="https://b.thumbs.redditmedia.com/RmIbmWNmvQJW7sgczrNGzG37x00zSZ9ZeCsyp5PQxuY.jpg" title="Bottom of prints look terrible" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I'm still trying to get the settings on my ender 3 v2 dialed in, and I'm not sure what I'm even doing wrong at this point.</p> <p>I don't even have the slightest idea of what's wrong so I'll just tell you what's going on and maybe someone can help.</p> <p>I have and ender 3 v2, I'm printing with Polylite ABS, My initial layer temperature is 240° and my normal temp is 235, and the bed is at 110. I'm printing using a raft. My initial layer speed is set to 20mm/s, but I'm not sure if the initial layer affects this because of the raft, but I may be wrong I'm very very new to 3d printing. I leveled the plate directly before printing because I saw that that could

## Tolerancje
 - [https://www.reddit.com/r/3Dprinting/comments/18wmidi/tolerancje](https://www.reddit.com/r/3Dprinting/comments/18wmidi/tolerancje)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T10:38:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wmidi/tolerancje/"> <img alt="Tolerancje" src="https://preview.redd.it/fbkbueve90ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0cffd30b98340d56c96c0810972156b19e3d436d" title="Tolerancje" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Tas667"> /u/Tas667 </a> <br /> <span><a href="https://i.redd.it/fbkbueve90ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wmidi/tolerancje/">[comments]</a></span> </td></tr></table>

## SCX-24 Axial Crawler Body
 - [https://www.reddit.com/r/3Dprinting/comments/18wm2r0/scx24_axial_crawler_body](https://www.reddit.com/r/3Dprinting/comments/18wm2r0/scx24_axial_crawler_body)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T10:09:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wm2r0/scx24_axial_crawler_body/"> <img alt="SCX-24 Axial Crawler Body" src="https://preview.redd.it/2stvg81d40ac1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=44f98d320e9b6a10ab9a0444cc80ab275685fef9" title="SCX-24 Axial Crawler Body" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Found a file online for a Dodge Power Ram and modified or to have a custom bed and custom bull bar. It also has some custom vinyl decals I printed. Might try vacuum forming to decrease the weight</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Medical_Secretary184"> /u/Medical_Secretary184 </a> <br /> <span><a href="https://i.redd.it/2stvg81d40ac1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wm2r0/scx24_axial_crawler_body/">[comments]</a></span> </td></tr></table>

## Can I return a 2 week used 3d printer to Amazon? Ender 3. Hate the damn thing. Tried and tried. I’m just not skilled enough. Any idea? I imagine I can’t because it’s been used.
 - [https://www.reddit.com/r/3Dprinting/comments/18wlyq0/can_i_return_a_2_week_used_3d_printer_to_amazon](https://www.reddit.com/r/3Dprinting/comments/18wlyq0/can_i_return_a_2_week_used_3d_printer_to_amazon)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T10:02:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wlyq0/can_i_return_a_2_week_used_3d_printer_to_amazon/"> <img alt="Can I return a 2 week used 3d printer to Amazon? Ender 3. Hate the damn thing. Tried and tried. I’m just not skilled enough. Any idea? I imagine I can’t because it’s been used." src="https://a.thumbs.redditmedia.com/ZYR1hVt8Po-2mDAUs8e_WrxFIVaJ6hxTlovWuSUvNV4.jpg" title="Can I return a 2 week used 3d printer to Amazon? Ender 3. Hate the damn thing. Tried and tried. I’m just not skilled enough. Any idea? I imagine I can’t because it’s been used." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Pretty sure I still have the box. But I mean there’s no customer service that you can call. Anybody know? Or have done this? I’m bummed because I could actually afford it.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/VoodooZephyr"> /u/VoodooZephyr </a> <br /> <span><a href="https://www.reddit.com/gallery/18wlyq0"

## My first print design from scratch.
 - [https://www.reddit.com/r/3Dprinting/comments/18wlqf8/my_first_print_design_from_scratch](https://www.reddit.com/r/3Dprinting/comments/18wlqf8/my_first_print_design_from_scratch)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T09:46:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wlqf8/my_first_print_design_from_scratch/"> <img alt="My first print design from scratch." src="https://a.thumbs.redditmedia.com/ZG5LXQsRCww-3gpMwnudG9CmgpHdAuhkFNTFEjvY3g8.jpg" title="My first print design from scratch." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>My first 3D print using a design I made from scratch. Really happy with how it turned out just a few size issues with holes but nothing that can’t be improved on. Just gotta learn how to make more complex shapes on blender now.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Buckupbuckeroo"> /u/Buckupbuckeroo </a> <br /> <span><a href="https://www.reddit.com/gallery/18wlqf8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wlqf8/my_first_print_design_from_scratch/">[comments]</a></span> </td></tr></table>

## de_dust 2 in a frame
 - [https://www.reddit.com/r/3Dprinting/comments/18wkz01/de_dust_2_in_a_frame](https://www.reddit.com/r/3Dprinting/comments/18wkz01/de_dust_2_in_a_frame)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T08:54:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wkz01/de_dust_2_in_a_frame/"> <img alt="de_dust 2 in a frame" src="https://external-preview.redd.it/cmF0NWs3MHpxejljMWC_jyJ0qh3faDPzdWQtSun_2gDR660Sgjiw257qPuwV.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=905ccf749ce608a01adc7f4d97c779e2d5e7ccc2" title="de_dust 2 in a frame" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Aser1079"> /u/Aser1079 </a> <br /> <span><a href="https://v.redd.it/tsagom9zqz9c1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wkz01/de_dust_2_in_a_frame/">[comments]</a></span> </td></tr></table>

## 1st functional print! And I need suggestions as well.
 - [https://www.reddit.com/r/3Dprinting/comments/18wkg58/1st_functional_print_and_i_need_suggestions_as](https://www.reddit.com/r/3Dprinting/comments/18wkg58/1st_functional_print_and_i_need_suggestions_as)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T08:18:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wkg58/1st_functional_print_and_i_need_suggestions_as/"> <img alt="1st functional print! And I need suggestions as well." src="https://a.thumbs.redditmedia.com/VIKgx8qN-4kWqAKOe7cwOCe_QpZKXgBcZMKy-s8Uyp8.jpg" title="1st functional print! And I need suggestions as well." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Speakers stands with removable end pieces so I can make attachments for height and angle.</p> <p>1st design and print of a functional thing (aside from personalized keychain and toys, hehe). Really glad I got into 3D printing, I've had this idea for quite some time already, but didnt have a reasonable way to make it a reality. </p> <p>I'm thinking of using TPU filament for the end caps. Does TPU have some grip? I was hoping it help in keeping the speaker and stand stable without me having to use those stick on rubber pads.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.red

## I recycled some old filament into keychains
 - [https://www.reddit.com/r/3Dprinting/comments/18wiryj/i_recycled_some_old_filament_into_keychains](https://www.reddit.com/r/3Dprinting/comments/18wiryj/i_recycled_some_old_filament_into_keychains)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T06:31:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wiryj/i_recycled_some_old_filament_into_keychains/"> <img alt="I recycled some old filament into keychains" src="https://b.thumbs.redditmedia.com/Jkpq7bWOqH6mFJEBtYlz7nkdjDVxW9EvTX7jRc1f4VQ.jpg" title="I recycled some old filament into keychains" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LevySkulk"> /u/LevySkulk </a> <br /> <span><a href="https://www.reddit.com/gallery/18wiryj">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wiryj/i_recycled_some_old_filament_into_keychains/">[comments]</a></span> </td></tr></table>

## I found this awesome tool that lets you automatically generate STL prints for words that change when viewed at different angles (called ambigrams)
 - [https://www.reddit.com/r/3Dprinting/comments/18wi7yk/i_found_this_awesome_tool_that_lets_you](https://www.reddit.com/r/3Dprinting/comments/18wi7yk/i_found_this_awesome_tool_that_lets_you)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T06:00:27+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/projectdate"> /u/projectdate </a> <br /> <span><a href="https://2catteam.github.io/AmbigramGenerator/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wi7yk/i_found_this_awesome_tool_that_lets_you/">[comments]</a></span>

## I accidentally ordered 600 3mm ball bearings on Aliexpress. Anyone have any cool functional prints I could use some of them in?
 - [https://www.reddit.com/r/3Dprinting/comments/18wh9dp/i_accidentally_ordered_600_3mm_ball_bearings_on](https://www.reddit.com/r/3Dprinting/comments/18wh9dp/i_accidentally_ordered_600_3mm_ball_bearings_on)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T05:07:36+00:00

<!-- SC_OFF --><div class="md"><p>I accidentally ordered 3mm ball bearings instead of 3mm ball magnets, and only realized my mistake when they arrived. Any ideas or links to neat (preferably functional) prints that use them?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Thumb4kill"> /u/Thumb4kill </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wh9dp/i_accidentally_ordered_600_3mm_ball_bearings_on/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wh9dp/i_accidentally_ordered_600_3mm_ball_bearings_on/">[comments]</a></span>

## Just got my first 3D printer :) Elegoo Neptune 4
 - [https://www.reddit.com/r/3Dprinting/comments/18wg46s/just_got_my_first_3d_printer_elegoo_neptune_4](https://www.reddit.com/r/3Dprinting/comments/18wg46s/just_got_my_first_3d_printer_elegoo_neptune_4)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T04:07:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wg46s/just_got_my_first_3d_printer_elegoo_neptune_4/"> <img alt="Just got my first 3D printer :) Elegoo Neptune 4" src="https://preview.redd.it/4hsamcoqby9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=47a2129f858a43471c3ef6dcf81e68bc26b1f5ef" title="Just got my first 3D printer :) Elegoo Neptune 4" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Besides running out of sample filament when printing the tool holder, haven't had any issues with setup and leveling :) Excited to get started 🎉</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/segFault_0_o"> /u/segFault_0_o </a> <br /> <span><a href="https://i.redd.it/4hsamcoqby9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wg46s/just_got_my_first_3d_printer_elegoo_neptune_4/">[comments]</a></span> </td></tr></table>

## How did I do?
 - [https://www.reddit.com/r/3Dprinting/comments/18wfxl1/how_did_i_do](https://www.reddit.com/r/3Dprinting/comments/18wfxl1/how_did_i_do)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T03:58:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wfxl1/how_did_i_do/"> <img alt="How did I do?" src="https://preview.redd.it/swljm674ay9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2254f741fd7ac344e2d9330fd2379766173d32b4" title="How did I do?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TigBurdus"> /u/TigBurdus </a> <br /> <span><a href="https://i.redd.it/swljm674ay9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wfxl1/how_did_i_do/">[comments]</a></span> </td></tr></table>

## 3d modeled my dnd character and my buddy printed it. Super impressed with the tiny details!
 - [https://www.reddit.com/r/3Dprinting/comments/18wekx0/3d_modeled_my_dnd_character_and_my_buddy_printed](https://www.reddit.com/r/3Dprinting/comments/18wekx0/3d_modeled_my_dnd_character_and_my_buddy_printed)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T02:51:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wekx0/3d_modeled_my_dnd_character_and_my_buddy_printed/"> <img alt="3d modeled my dnd character and my buddy printed it. Super impressed with the tiny details!" src="https://preview.redd.it/8v1dxru9yx9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c9dce2e87a88a80717d0d9354112120f49a7ea80" title="3d modeled my dnd character and my buddy printed it. Super impressed with the tiny details!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TorvundArt"> /u/TorvundArt </a> <br /> <span><a href="https://i.redd.it/8v1dxru9yx9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wekx0/3d_modeled_my_dnd_character_and_my_buddy_printed/">[comments]</a></span> </td></tr></table>

## Building heat is out and I got a bad ribbon cable. So here I sit proofing bread. 2024 winning.
 - [https://www.reddit.com/r/3Dprinting/comments/18wd04c/building_heat_is_out_and_i_got_a_bad_ribbon_cable](https://www.reddit.com/r/3Dprinting/comments/18wd04c/building_heat_is_out_and_i_got_a_bad_ribbon_cable)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T01:38:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wd04c/building_heat_is_out_and_i_got_a_bad_ribbon_cable/"> <img alt="Building heat is out and I got a bad ribbon cable. So here I sit proofing bread. 2024 winning." src="https://preview.redd.it/sxhuir8ukx9c1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=9af33a33cb276d193f3b6a9776ac7893cd29f6a6" title="Building heat is out and I got a bad ribbon cable. So here I sit proofing bread. 2024 winning." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/stillcantpickaname"> /u/stillcantpickaname </a> <br /> <span><a href="https://i.redd.it/sxhuir8ukx9c1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wd04c/building_heat_is_out_and_i_got_a_bad_ribbon_cable/">[comments]</a></span> </td></tr></table>

## First prints! I’m super excited to keep doing more and getting better. But I want to know something first. Where do you get your sick colored filaments?
 - [https://www.reddit.com/r/3Dprinting/comments/18wbfu1/first_prints_im_super_excited_to_keep_doing_more](https://www.reddit.com/r/3Dprinting/comments/18wbfu1/first_prints_im_super_excited_to_keep_doing_more)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T00:26:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wbfu1/first_prints_im_super_excited_to_keep_doing_more/"> <img alt="First prints! I’m super excited to keep doing more and getting better. But I want to know something first. Where do you get your sick colored filaments?" src="https://preview.redd.it/4cv5fk2e8x9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=829b10b7990b1d103ad0d7a7d606153e590986e3" title="First prints! I’m super excited to keep doing more and getting better. But I want to know something first. Where do you get your sick colored filaments?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/brownsorcery"> /u/brownsorcery </a> <br /> <span><a href="https://i.redd.it/4cv5fk2e8x9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wbfu1/first_prints_im_super_excited_to_keep_doing_more/">[comments]</a></span> </td></tr></table>

## Added a 1:16 vacuum optimized Raptor to my collection and a 1:16 sea level to go with it
 - [https://www.reddit.com/r/3Dprinting/comments/18wb29h/added_a_116_vacuum_optimized_raptor_to_my](https://www.reddit.com/r/3Dprinting/comments/18wb29h/added_a_116_vacuum_optimized_raptor_to_my)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-01-02T00:10:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/18wb29h/added_a_116_vacuum_optimized_raptor_to_my/"> <img alt="Added a 1:16 vacuum optimized Raptor to my collection and a 1:16 sea level to go with it" src="https://preview.redd.it/lzxxpdgf5x9c1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=95da403d6952ab29b1a0523f7f18cdcedd71cf61" title="Added a 1:16 vacuum optimized Raptor to my collection and a 1:16 sea level to go with it" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BDady"> /u/BDady </a> <br /> <span><a href="https://i.redd.it/lzxxpdgf5x9c1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/18wb29h/added_a_116_vacuum_optimized_raptor_to_my/">[comments]</a></span> </td></tr></table>

