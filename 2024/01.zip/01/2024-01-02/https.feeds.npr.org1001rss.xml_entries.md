# Source:Npr, URL:https://feeds.npr.org/1001/rss.xml, language:en-US

## Threats to abortion access drive demand for abortion pills, analysis suggests
 - [https://www.npr.org/2024/01/02/1220733428/medication-abortion-advance-provision](https://www.npr.org/2024/01/02/1220733428/medication-abortion-advance-provision)
 - RSS feed: https://feeds.npr.org/1001/rss.xml
 - date published: 2024-01-02T16:02:11+00:00

Requests for abortion pills from people who were not yet pregnant spiked when patients appeared to perceive threats to abortion access, new research has found.

## Russia strikes residences and a supermarket in Ukraine's capital and other cities
 - [https://www.npr.org/2024/01/02/1222474414/russia-strikes-ukraine-cities-kyiv-kharkiv](https://www.npr.org/2024/01/02/1222474414/russia-strikes-ukraine-cities-kyiv-kharkiv)
 - RSS feed: https://feeds.npr.org/1001/rss.xml
 - date published: 2024-01-02T15:58:25+00:00

Russia launched dozens of attack drones and missiles — including its advanced Kinzhal hypersonic missile — according to Ukrainian officials.

## Up First briefing: Israel Supreme Court ruling; South Korean opposition leader stabbed
 - [https://www.npr.org/2024/01/02/1222448442/up-first-briefing-israel-supreme-court-ruling-south-korean-leader-stabbed](https://www.npr.org/2024/01/02/1222448442/up-first-briefing-israel-supreme-court-ruling-south-korean-leader-stabbed)
 - RSS feed: https://feeds.npr.org/1001/rss.xml
 - date published: 2024-01-02T12:34:04+00:00

Israel's Supreme Court rejects right-wing changes to the judiciary. South Korea's Democratic Party leader Lee Jae-myung was stabbed in the neck during a visit to the city of Busan.

## Powerful earthquakes along Japan's western coast leave multiple people dead
 - [https://www.npr.org/2024/01/01/1222428476/japan-earthquakes-people-dead](https://www.npr.org/2024/01/01/1222428476/japan-earthquakes-people-dead)
 - RSS feed: https://feeds.npr.org/1001/rss.xml
 - date published: 2024-01-02T03:59:10+00:00

Aftershocks continued to shake Ishikawa prefecture and nearby areas on Tuesday, a day after a magnitude 7.6 temblor slammed the region on Monday afternoon.

