# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Bill Gates, Big Pharma and the Global War
 - [https://www.youtube.com/watch?v=ZjsN7E80Ckw](https://www.youtube.com/watch?v=ZjsN7E80Ckw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-01-02T20:59:23+00:00

John has been reading 'The Real Anthony Fauci, Bill Gates, Big Pharma and the Global War on Democracy and Public Health by Fobert F. Kennedy Jr.

## New anti cancer 'vaccine'
 - [https://www.youtube.com/watch?v=4HCSxRxGYQ4](https://www.youtube.com/watch?v=4HCSxRxGYQ4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2024-01-02T09:24:22+00:00

Professor Angus Dalgleish, physician, oncologist, pathologist, medical researcher and author. Get your copy of The Death of Science, 
https://gazellebookservices.co.uk/pro...

Also by Professor Dalgleish, The Origin of the Virus: The hidden truths behind the microbe that killed millions of people, https://www.amazon.co.uk/dp/185457106...

