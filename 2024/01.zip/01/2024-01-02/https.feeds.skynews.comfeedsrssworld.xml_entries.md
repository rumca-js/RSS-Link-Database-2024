# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Jenni Hermoso testifies in court over Rubiales kiss
 - [https://news.sky.com/story/jenni-hermoso-testifies-in-madrid-court-over-rubiales-kiss-13041086](https://news.sky.com/story/jenni-hermoso-testifies-in-madrid-court-over-rubiales-kiss-13041086)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T18:19:00+00:00

Spanish footballer Jenni Hermoso has testified in court over the kiss she claims ex-football federation chief Luis Rubiales gave without her consent after Spain's victory in the Women's World Cup last summer.

## Hamas deputy head killed in explosion in Beirut, says Hezbollah
 - [https://news.sky.com/story/hamas-deputy-head-saleh-arouri-killed-in-an-explosion-south-of-beirut-according-to-hezbollah-tv-13041022](https://news.sky.com/story/hamas-deputy-head-saleh-arouri-killed-in-an-explosion-south-of-beirut-according-to-hezbollah-tv-13041022)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T16:03:00+00:00

Hamas has said one of its top officials, Saleh al Arouri, has been killed - with Hezbollah media saying he died in an explosion in Beirut.

## Eurovision teases Caribbean announcement for 2024
 - [https://news.sky.com/story/eurovision-teases-caribbean-announcement-for-this-years-contest-13040987](https://news.sky.com/story/eurovision-teases-caribbean-announcement-for-this-years-contest-13040987)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T15:08:00+00:00

Eurovision organisers have teased an apparent Caribbean appearance at this year's contest.

## It's minus 40C in Sweden and Finland as Nordic cold snap brings winter's coldest temperatures
 - [https://news.sky.com/story/sweden-and-finland-are-freezing-in-minus-40c-as-the-nordic-cold-snap-brings-winters-coldest-temperatures-13040925](https://news.sky.com/story/sweden-and-finland-are-freezing-in-minus-40c-as-the-nordic-cold-snap-brings-winters-coldest-temperatures-13040925)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T14:30:00+00:00

Finland and Sweden have recorded the coldest temperatures of the winter so far with thermometers falling to minus 40C (minus 40F), or even lower, as the countries remained in the grip of the Nordic cold snap.

## Oil prices volatile after latest attack on shipping container in the Red Sea
 - [https://news.sky.com/story/global-oil-costs-volatile-as-red-sea-shipping-attack-weighs-13040949](https://news.sky.com/story/global-oil-costs-volatile-as-red-sea-shipping-attack-weighs-13040949)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T13:57:00+00:00

Two of the world's largest container ship operators have extended diversions from the Red Sea following an attack on a vessel at the weekend that has been blamed for renewed oil price volatility.

## 'I thought I was going to die': Japan residents recall terrifying moment earthquake hit
 - [https://news.sky.com/story/japan-residents-recall-moment-earthquake-levelled-houses-and-crushed-cars-13040942](https://news.sky.com/story/japan-residents-recall-moment-earthquake-levelled-houses-and-crushed-cars-13040942)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T13:34:00+00:00

In a small suburb just outside the city of Kanazawa the houses sit largely dark and still.

## 'It was hell': Passengers describe horror on board burning plane
 - [https://news.sky.com/story/japan-plane-fire-passengers-describe-horror-on-board-burning-aircraft-13040923](https://news.sky.com/story/japan-plane-fire-passengers-describe-horror-on-board-burning-aircraft-13040923)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T12:48:00+00:00

Passengers on a plane that burst into flames after it collided with a coast guard aircraft in Tokyo have been describing the horror that unfolded.

## Japan plane fire: Everything we know so far
 - [https://news.sky.com/story/japan-plane-fire-everything-we-know-so-far-13040894](https://news.sky.com/story/japan-plane-fire-everything-we-know-so-far-13040894)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T11:42:00+00:00

As firefighters and rescue crews work on the ground following a huge plane fire at Tokyo's Haneda airport in Japan, investigators behind the scenes will try to piece together how it happened.

## 'Amazing to be back': Raducanu makes winning return in first match since April
 - [https://news.sky.com/story/tennis-star-emma-raducanu-wins-her-first-match-since-april-after-wrist-and-ankle-operations-13040817](https://news.sky.com/story/tennis-star-emma-raducanu-wins-her-first-match-since-april-after-wrist-and-ankle-operations-13040817)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T10:40:00+00:00

British tennis star Emma Raducanu has won her first match since April following a lengthy injury lay-off.

## Plane in flames on runway of Tokyo airport
 - [https://news.sky.com/story/plane-in-flames-on-runway-of-tokyo-airport-13040799](https://news.sky.com/story/plane-in-flames-on-runway-of-tokyo-airport-13040799)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T09:15:00+00:00

A fire has broken out in a plane on a runway at Tokyo Haneda airport, footage from local media shows.

## Japan quake death toll rises amid 'battle against time' to help survivors
 - [https://news.sky.com/story/japan-earthquake-death-toll-rises-as-pm-warns-of-battle-against-time-to-rescue-survivors-13040712](https://news.sky.com/story/japan-earthquake-death-toll-rises-as-pm-warns-of-battle-against-time-to-rescue-survivors-13040712)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T04:16:00+00:00

The number of people killed after a 7.6-magnitude earthquake hit Japan has risen to at least 30.

## South Korean opposition leader 'stabbed in neck' during visit
 - [https://news.sky.com/story/lee-jae-myung-south-korean-opposition-leader-attacked-and-injured-by-unidentified-man-officials-say-13040705](https://news.sky.com/story/lee-jae-myung-south-korean-opposition-leader-attacked-and-injured-by-unidentified-man-officials-say-13040705)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T02:19:00+00:00

South Korea's opposition leader Lee Jae-myung has been stabbed in the neck during a visit to Busan, according to local media.

## South Korean opposition leader stabbed in neck during visit
 - [https://news.sky.com/story/lee-jae-myung-south-korean-opposition-leader-stabbed-in-neck-during-busan-visit-13040705](https://news.sky.com/story/lee-jae-myung-south-korean-opposition-leader-stabbed-in-neck-during-busan-visit-13040705)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-01-02T02:19:00+00:00

South Korea's opposition leader Lee Jae-myung has been stabbed in the neck during a visit to Busan, police have said.

