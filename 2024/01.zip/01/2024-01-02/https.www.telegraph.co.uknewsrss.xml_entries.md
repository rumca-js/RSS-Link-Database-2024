# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Tuesday evening news briefing: More than 33,000 migrants face deportation to Rwanda if flights start
 - [https://www.telegraph.co.uk/news/2024/01/02/tuesday-evening-news-briefing-33000-migrants-deportation](https://www.telegraph.co.uk/news/2024/01/02/tuesday-evening-news-briefing-33000-migrants-deportation)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2024-01-02T17:52:02+00:00



