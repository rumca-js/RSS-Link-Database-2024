# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Atak w Bejrucie. Wśród ofiar jeden z liderów Hamasu i dwaj jego dowódcy
 - [https://tvn24.pl/swiat/bejrut-liban-eksplozja-w-bejrucie-izraelski-dron-uderzyl-w-budynek-hamasu-wsrod-ofiar-jeden-z-liderow-hamasu-7683625?source=rss](https://tvn24.pl/swiat/bejrut-liban-eksplozja-w-bejrucie-izraelski-dron-uderzyl-w-budynek-hamasu-wsrod-ofiar-jeden-z-liderow-hamasu-7683625?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T21:33:52+00:00

<img alt="Atak w Bejrucie. Wśród ofiar jeden z liderów Hamasu i dwaj jego dowódcy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7tq4ya-libanscy-zolnierze-stoja-na-szczycie-pojazdu-opancerzonego-w-miejscu-eksplozji-w-poludniowej-dzielnicy-bejrutu-2-stycznia-7683895/alternates/LANDSCAPE_1280" />
    Izraelski dron uderzył w budynek Hamasu na południowych przedmieściach stolicy Libanu, Bejrutu, zabijając sześć osób - poinformował Reuters. Wśród zabitych jest jeden z liderów Hamasu Saleh al-Arouri oraz dwóch dowódców jego zbrojnego skrzydła - brygad Al-Kassam - przekazała agencja w oparciu o informacje hamasowskiej telewizji Al Aqsa. Hezbollah oświadczył, że w odpowiedzi wystrzelił rakiety, których celem jest grupa izraelskich żołnierzy. - Rzecznik izraelskiej armii Daniel Hagari poinformował o podwyższonej gotowości wojskowych.

## Chciał uniknąć kolizji, wjechał w latarnię, ta przewróciła się i zniszczyła inne auto
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-na-jagiellonskiej-przewrocona-latarnia-st7683808?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-na-jagiellonskiej-przewrocona-latarnia-st7683808?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T20:57:44+00:00

<img alt="Chciał uniknąć kolizji, wjechał w latarnię, ta przewróciła się i zniszczyła inne auto " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1y5den-zderzenie-na-jagiellonskiej-7683823/alternates/LANDSCAPE_1280" />
    Wieczorem na warszawskiej Pradze doszło do nietypowej kolizji. W jej wyniku uszkodzone są dwa auta i latarnia.

## "Wyścig z czasem" po kataklizmach. "Dostęp do północnej części półwyspu jest niezwykle trudny"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/japonia-wyscig-z-czasem-po-kataklizmach-dostep-do-polnocnej-czesci-polwyspu-jest-niezwykle-trudny-st7683882?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/japonia-wyscig-z-czasem-po-kataklizmach-dostep-do-polnocnej-czesci-polwyspu-jest-niezwykle-trudny-st7683882?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T20:50:19+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-di3xnm-maj-7683888/alternates/LANDSCAPE_1280" />
    Środkową Japonię nawiedziło w poniedziałek silne trzęsienie ziemi. Miało magnitudę 7,6. Zginęło co najmniej 57 osób. Zniszczone zostały drogi, domy i linie energetyczne. W akcji ratunkowej biorą udział tysiące osób. Ich głównym zadaniem jest dotarcie do ludzi, których żywioł odciął od świata. Dodatkowo wstrząsy wywołały też fale tsunami, które zagrażały też Korei Południowej, Korei Północnej, a nawet Rosji.

## Przekroczone normy jakości powietrza. Sprawdź, gdzie jest smog
 - [https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-sroda-0301-sprawdz-jakosc-powietrza-w-swoim-miescie-st7683887?source=rss](https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-sroda-0301-sprawdz-jakosc-powietrza-w-swoim-miescie-st7683887?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T20:47:23+00:00

<img alt="Przekroczone normy jakości powietrza. Sprawdź, gdzie jest smog" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xv9bjn-smog-zima-6729601/alternates/LANDSCAPE_1280" />
    W środowy wieczór w niektórych częściach Polski pogorszyła się jakość powietrza. Sprawdź sytuację w swojej okolicy.

## Wyniki Eurojackpot z 02 grudnia 2023. Jakie liczby padły podczas ostatniego losowania?
 - [https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia02012024-liczby-z-ostatniego-losowania-duza-wygrana-w-polsce-st7683817?source=rss](https://tvn24.pl/biznes/z-kraju/eurojackpot-wyniki-z-dnia02012024-liczby-z-ostatniego-losowania-duza-wygrana-w-polsce-st7683817?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T20:31:47+00:00

<img alt="Wyniki Eurojackpot z 02 grudnia 2023. Jakie liczby padły podczas ostatniego losowania?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m1rom0-eurojackpot-s-shutterstock_743570785-4780960/alternates/LANDSCAPE_1280" />
    We wtorkowym losowaniu Eurojackpot nie padła główna wygrana. W Polsce odnotowano nagrodę drugiego stopnia w wysokości 4 451 674,50 złotych. Podobnie jak w Niemczech, gdzie padły kolejne dwie takie wygrane. Do najbliższym losowaniu będzie można wygrać pięćset milionów złotych.

## Opłaty za jednorazowe opakowania już obowiązują. "Plastik jest zabójcą dla otaczającego nas świata"
 - [https://fakty.tvn24.pl/zobacz-fakty/oplaty-za-jednorazowe-opakowania-juzobowiazuja-plastik-jest-zabojca-dla-otaczajacego-nas-swiata-st7683820?source=rss](https://fakty.tvn24.pl/zobacz-fakty/oplaty-za-jednorazowe-opakowania-juzobowiazuja-plastik-jest-zabojca-dla-otaczajacego-nas-swiata-st7683820?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T20:22:44+00:00

<img alt="Opłaty za jednorazowe opakowania już obowiązują. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-97uoma-zielinska-7683821/alternates/LANDSCAPE_1280" />
    Od 1 stycznia w życie weszły przepisy, zgodnie z którymi do jednorazowych opakowań plastiku doliczana będzie dodatkowa opłata. Mają one związek z unijnym prawem. Według ekspertów nowe przepisy mogą wpłynąć na zachowania konsumentów i zredukowanie liczby śmieci.

## Wiceszef MON: zakładamy również to, że Rosjanie po prostu testują naszą czujność
 - [https://tvn24.pl/polska/rosyjska-rakieta-na-terytorium-polski-wiceminister-obrony-narodowej-pawel-bejda-komentuje-7683767?source=rss](https://tvn24.pl/polska/rosyjska-rakieta-na-terytorium-polski-wiceminister-obrony-narodowej-pawel-bejda-komentuje-7683767?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T19:59:57+00:00

<img alt="Wiceszef MON: zakładamy również to, że Rosjanie po prostu testują naszą czujność" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3zdbxt-02-1930-fpf-cl-0003-7683770/alternates/LANDSCAPE_1280" />
    Wiceminister obrony narodowej Paweł Bejda w "Faktach po Faktach" powiedział, że najprawdopodobniej rosyjska rakieta wleciała na teren Polski w ubiegłym tygodniu przez błąd, ale niewykluczone jest, że Rosjanie "testują, czy nasze procedury działają i czy w odpowiednim momencie jest reakcja ze strony Polski". - Jest to też okazja, żeby pokazać Zachodowi, żeby ludzie nie przyzwyczajali się do tej wojny - stwierdził Bejda, odnosząc się do działań wojennych w Ukrainie.

## Tej nocy Ziemia znajdzie się najbliżej Słońca
 - [https://tvn24.pl/tvnmeteo/ciekawostki/w-srode-ziemia-znajdzie-sie-najblizej-slonca-peryhelium-w-2024-kiedy-wypada-co-to-za-zjawisko-st7683636?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/w-srode-ziemia-znajdzie-sie-najblizej-slonca-peryhelium-w-2024-kiedy-wypada-co-to-za-zjawisko-st7683636?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T19:22:01+00:00

<img alt="Tej nocy Ziemia znajdzie się najbliżej Słońca" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hl91xv-ziemia-slonce-7683639/alternates/LANDSCAPE_1280" />
    W nocy z wtorku na środę Ziemia przejdzie przez punkt nazywany peryhelium. Oznacza to, że znajdzie się możliwie najbliżej naszej dziennej gwiazdy. Od Słońca będzie dzielił nas dystans 147,1 milionów kilometrów.

## Nowy rok na polskich drogach. Drogowcy ujawniają plany
 - [https://tvn24.pl/biznes/moto/drogi-w-polsce-rok-2024-lista-planowanych-przetargow-gddkia-st7683731?source=rss](https://tvn24.pl/biznes/moto/drogi-w-polsce-rok-2024-lista-planowanych-przetargow-gddkia-st7683731?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T19:10:08+00:00

<img alt="Nowy rok na polskich drogach. Drogowcy ujawniają plany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lvc52j-droga-budowa-5519861/alternates/LANDSCAPE_1280" />
    Blisko 215 km wyniesie łączna długość odcinków dróg, na jakie w 2024 roku zostaną ogłoszone przetargi - informuje Generalna Dyrekcja Dróg Krajowych i Autostrad (GDDKiA). Postępowania obejmą między innymi budowę przedłużenia autostrady A2, ogłoszonych zostanie także kilkanaście przetargów na budowę obwodnic.

## Pogoda na jutro - środa 03.01. Opady w części kraju będą obfite
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sroda-0301-opady-w-czesci-kraju-beda-obfite-st7683765?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sroda-0301-opady-w-czesci-kraju-beda-obfite-st7683765?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T18:52:00+00:00

<img alt="Pogoda na jutro - środa 03.01. Opady w części kraju będą obfite" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vwdyfd-snieg-wiatr-zawieje-zamiecie-6806411/alternates/LANDSCAPE_1280" />
    W środę na przeważającym terenie Polski będą występować opady deszczu, ale w części kraju spadnie dużo śniegu. Czeka nas bardzo duża różnica temperatury między najchłodniejszym a najcieplejszym miejscem.

## "Trudno przecenić, jak ważny to moment dla projektowania nowoczesnych samolotów"
 - [https://tvn24.pl/swiat/japonia-pozar-samolotu-na-lotnisku-w-tokio-pierwszy-powazny-wypadek-airbusa-a350-7683370?source=rss](https://tvn24.pl/swiat/japonia-pozar-samolotu-na-lotnisku-w-tokio-pierwszy-powazny-wypadek-airbusa-a350-7683370?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T18:11:56+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uq6gtd-airbus-a350-w-ogniu-na-lotnisku-haneda-7683651/alternates/LANDSCAPE_1280" />
    Nowoczesne samoloty pasażerskie są zaprojektowane tak, by w razie ewentualnego wypadku zapewniały wysoką przeżywalność pasażerów na pokładzie. Tak było w trakcie wtorkowej katastrofy na japońskim lotnisku Haneda, gdzie dwie maszyny zderzyły się i stanęły w płomieniach. Szczególne znaczenie miały tu ognioodporne materiały, z których zbudowany był model Airbusa.

## Tragiczny wypadek na torach. Opóźnione i odwołane pociągi
 - [https://tvn24.pl/tvnwarszawa/najnowsze/legionowo-wypadek-na-torach-pociag-potracil-czlowieka-st7683670?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/legionowo-wypadek-na-torach-pociag-potracil-czlowieka-st7683670?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T18:05:11+00:00

<img alt="Tragiczny wypadek na torach. Opóźnione i odwołane pociągi" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-mao2yy-tragiczny-wypadek-na-torach-7683684/alternates/LANDSCAPE_1280" />
    Wypadek w okolicy stacji Legionowo. Pociąg Kolei Mazowieckich śmiertelnie potrącił pieszego. Na miejscu pracują służby. Są opóźnienia w rozkładach.

## Wielka kumulacja w loterii rozbita
 - [https://tvn24.pl/biznes/ze-swiata/powerball-wyniki-duza-wygrana-w-amerykanskiej-loterii-st7683626?source=rss](https://tvn24.pl/biznes/ze-swiata/powerball-wyniki-duza-wygrana-w-amerykanskiej-loterii-st7683626?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T17:24:42+00:00

<img alt="Wielka kumulacja w loterii rozbita" src="https://tvn24.pl/najnowsze/cdn-zdjecie-43vwke-shutterstock_1935859393-7683640/alternates/LANDSCAPE_1280" />
    Los loterii Powerball kupiony w amerykańskim stanie Michigan przyniósł w poniedziałek szczęśliwemu nabywcy główną wygraną wynoszącą 842,5 miliona dolarów (około 3,3 miliarda złotych).

## Sylwester i Nowy Rok na drogach Mazowsza. 18 wypadków, 87 pijanych kierowców
 - [https://tvn24.pl/tvnwarszawa/najnowsze/mazowieckie-sylwester-i-nowy-rok-na-drogach-dane-st7683567?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/mazowieckie-sylwester-i-nowy-rok-na-drogach-dane-st7683567?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T17:16:11+00:00

<img alt="Sylwester i Nowy Rok na drogach Mazowsza. 18 wypadków, 87 pijanych kierowców" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-sztwpv-wypadek-na-obwodnicy-mszczonowa-7664028/alternates/LANDSCAPE_1280" />
    Komenda Stołeczna Policji oraz Komenda Wojewódzka Policji w Radomiu podsumowały Sylwestra i Nowy Rok na drogach. W 18 wypadkach zginęły dwie osoby, a 21 zostało rannych. Zatrzymano też 87 nietrzeźwych kierowców.

## Otworzył ogień do funkcjonariuszy. Podejrzany o włamanie do budynku Sądu Najwyższego stanu Kolorado w rękach policji
 - [https://tvn24.pl/swiat/usa-podejrzany-o-wlamanie-do-budynku-sadu-najwyzszego-stanu-kolorado-zatrzymany-7683631?source=rss](https://tvn24.pl/swiat/usa-podejrzany-o-wlamanie-do-budynku-sadu-najwyzszego-stanu-kolorado-zatrzymany-7683631?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T17:08:02+00:00

<img alt="Otworzył ogień do funkcjonariuszy. Podejrzany o włamanie do budynku Sądu Najwyższego stanu Kolorado w rękach policji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p5woae-sad-najwyzszy-stanu-kolorado-7683630/alternates/LANDSCAPE_1280" />
    W budynku Sądu Najwyższego stanu Kolorado aresztowano podejrzanego, który otworzył ogień do funkcjonariuszy policji. Sąd ten w grudniu orzekł, że Donald Trump nie będzie mógł znaleźć się na kartach wyborczych w tym stanie. Władze nie potwierdziły dotąd związku między wydarzeniami.

## Odsłonięte okna, zgaszone światła. Eksperci o tym, co i w jaki sposób ratuje życie pasażerów samolotu
 - [https://tvn24.pl/swiat/japonia-pozar-samolotu-w-tokio-eksperci-o-ewakuacji-pasazerow-7683159?source=rss](https://tvn24.pl/swiat/japonia-pozar-samolotu-w-tokio-eksperci-o-ewakuacji-pasazerow-7683159?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T14:56:55+00:00

<img alt="Odsłonięte okna, zgaszone światła. Eksperci o tym, co i w jaki sposób ratuje życie pasażerów samolotu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3sgi1l-samolot-pasazerski-linii-lotniczych-japan-airlines-stanal-w-plomieniach-7683316/alternates/LANDSCAPE_1280" />
    Sprawna ewakuacja sprawiła, że niemal 400 osób podróżujących samolotem Japan Airlines - czyli wszyscy pasażerowie i członkowie załogi - przeżyli pożar, który wybuchł podczas lądowania maszyny. Eksperci analizują dla nas nagrania z ewakuacji płonącego samolotu i wskazują na wymogi bezpieczeństwa, z istnienia których często nie zdajemy sobie sprawy. Co zatem może uratować nam życie?

## Zderzenie kilku aut na S8. Korek. Jedna osoba trafiła do szpitala
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-aut-na-s8-korek-st7683399?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-aut-na-s8-korek-st7683399?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T14:15:06+00:00

<img alt="Zderzenie kilku aut na S8. Korek. Jedna osoba trafiła do szpitala" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8rl42d-zderzenie-czterech-aut-na-s8-7683472/alternates/LANDSCAPE_1280" />
    Samochody zderzyły się na jezdni w kierunku Marek. Jak informuje policja, jedna osoba została zabrana do szpitala. Kierowcy utknęli w kilkukilometrowym zatorze.

## Wyprzedził i pojechał pod prąd, omijając dwie wysepki. Nagranie
 - [https://tvn24.pl/szczecin/koszalin-wyprzedzil-i-pojechal-pod-prad-omijajac-dwie-wysepki-nagranie-7683362?source=rss](https://tvn24.pl/szczecin/koszalin-wyprzedzil-i-pojechal-pod-prad-omijajac-dwie-wysepki-nagranie-7683362?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T14:08:02+00:00

<img alt="Wyprzedził i pojechał pod prąd, omijając dwie wysepki. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yfab9l-niebezpieczne-zachowanie-kierowcy-w-koszalinie-7683247/alternates/LANDSCAPE_1280" />
    Niebezpieczne zachowanie na jednej z ulic w Koszalinie (woj. zachodniopomorskie). Na nagraniu, które otrzymaliśmy na Kontakt 24 widać, jak kierowca samochodu osobowego wyprzedza inny pojazd z lewej strony, omijając dwie wysepki.

## Kompletnie pijany wsiadł za kółko. Staranował ogrodzenie i wjechał w dom. Wiózł pijaną 17-latkę
 - [https://tvn24.pl/najnowsze/krosno-25-latek-wypadl-z-drogi-staranowal-ogrodzenie-i-wjechal-w-dom-wydmuchal-okolo-25-promila-alkoholu-7683258?source=rss](https://tvn24.pl/najnowsze/krosno-25-latek-wypadl-z-drogi-staranowal-ogrodzenie-i-wjechal-w-dom-wydmuchal-okolo-25-promila-alkoholu-7683258?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T14:04:46+00:00

<img alt="Kompletnie pijany wsiadł za kółko. Staranował ogrodzenie i wjechał w dom. Wiózł pijaną 17-latkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tv17pd-pijany-kierowca-wjechal-w-dom-7683272/alternates/LANDSCAPE_1280" />
    Około 2,5 promila alkoholu w organizmie miał 25-latek, który w Krośnie (woj. podkarpackie) jadąc osobowym audi wypadł z drogi, staranował ogrodzenie i wjechał w dom. Jadąca z nim 17-latka wydmuchała prawie dwa promile. Oboje trafili do aresztu.

## W pociągu pojawił się dym. Ewakuowało się 80 pasażerów
 - [https://tvn24.pl/trojmiasto/pruszcz-gdanski-w-pociagu-pojawil-sie-dym-ewakuowalo-sie-80-pasazerow-7683289?source=rss](https://tvn24.pl/trojmiasto/pruszcz-gdanski-w-pociagu-pojawil-sie-dym-ewakuowalo-sie-80-pasazerow-7683289?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T13:55:08+00:00

<img alt="W pociągu pojawił się dym. Ewakuowało się 80 pasażerów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7a3dsm-stacja-kolejowa-w-pruszczu-gdanskim-7683375/alternates/LANDSCAPE_1280" />
    Do awarii pociągu na stacji kolejowej w Pruszczu Gdańskim doszło we wtorek w samo południe. Około 80 pasażerów ewakuowało się przed przybyciem straży pożarnej. Nikt nie został poszkodowany.

## To pierwsi obrońcy polskiego nieba, choć rozkazy... mogą przyjść z Niemiec
 - [https://tvn24.pl/polska/mysliwce-f-16-poderwane-pary-dyzurne-w-polsce-ile-ich-mamy-jak-dzialaja-czy-polskiego-nieba-strzega-tez-sojusznicy-7683064?source=rss](https://tvn24.pl/polska/mysliwce-f-16-poderwane-pary-dyzurne-w-polsce-ile-ich-mamy-jak-dzialaja-czy-polskiego-nieba-strzega-tez-sojusznicy-7683064?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T13:52:48+00:00

<img alt="To pierwsi obrońcy polskiego nieba, choć rozkazy... mogą przyjść z Niemiec" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s7fjmi-shutterstock_2353323615-7683299/alternates/LANDSCAPE_1280" />
    We wtorek rano, w reakcji na dużą aktywność rosyjskiego lotnictwa, poderwane zostały w Polsce cztery myśliwce F-16. To tak zwane pary dyżurne - gotowe do natychmiastowego startu o każdej porze dnia i nocy. Jak działają takie pary? Ile myśliwców jest w Polsce w stałej gotowości? I skąd na polskim niebie pojawiły się maszyny amerykańskie?

## "1500 nielegalnych imigrantów przybędzie do Katowic"? To nieprawda
 - [https://konkret24.tvn24.pl/polska/relokacja-migrantow-1500-nielegalnych-imigrantow-przybedzie-do-katowic-to-nieprawda-st7682776?source=rss](https://konkret24.tvn24.pl/polska/relokacja-migrantow-1500-nielegalnych-imigrantow-przybedzie-do-katowic-to-nieprawda-st7682776?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T13:49:05+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-koweui-1500-nielegalnych-imigrantow-przybedzie-do-katowic-fake-news-7683196/alternates/LANDSCAPE_1280" />
    Setki tysięcy wyświetleń w polskich mediach społecznościowych osiągają posty z informacją, jakoby w najbliższych dniach do Katowic miała dotrzeć "pierwsza transza 1500 nielegalnych imigrantów z obowiązkowej solidarności podpisanej w tajemnicy przez Tuska". To fałszywy przekaz, a cała akcja wygląda na skoordynowaną. Urzędy miejski i wojewódzki w Katowicach zaprzeczają tym doniesieniom.

## Autokar na boku. Jechało nim 21 pasażerów
 - [https://tvn24.pl/tvnwarszawa/ulice/jablonna-autokar-na-boku-w-rowie-zderzenie-z-autem-osobowym-st7683333?source=rss](https://tvn24.pl/tvnwarszawa/ulice/jablonna-autokar-na-boku-w-rowie-zderzenie-z-autem-osobowym-st7683333?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T13:48:49+00:00

<img alt="Autokar na boku. Jechało nim 21 pasażerów " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dk5tp6-zderzenie-w-jablonnie-7683352/alternates/LANDSCAPE_1280" />
    Do poważnie wyglądającej kraksy doszło we wtorek w Jabłonnie pod Warszawie. Autokar wiozący ponad 20 osób zjechał do rowu. Prawdopodobnie żaden z pasażerów nie odniósł poważniejszych obrażeń.

## "Dzisiaj cała Dania płacze". Duńczycy w szoku po decyzji Małgorzaty II o abdykacji
 - [https://tvn24.pl/swiat/dania-abdykacja-malgorzaty-ii-dunczycy-w-szoku-po-decyzji-krolowej-7683152?source=rss](https://tvn24.pl/swiat/dania-abdykacja-malgorzaty-ii-dunczycy-w-szoku-po-decyzji-krolowej-7683152?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T13:44:49+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8jxexq-krolowa-malgorzata-ii-7663573/alternates/LANDSCAPE_1280" />
    Duńczycy bardzo emocjonalnie potraktowali wiadomość o niespodziewanej abdykacji królowej Małgorzaty II. Wielu z nich przyznaje, że był to dla nich "prawdziwy szok". - Była tu odkąd byłam mała. Dzisiaj cała Dania płacze - mówi jedna z obywatelek, cytowana przez brytyjskiego "Guardiana".

## Miał biegać z nożem i atakować przechodniów. Usłyszał zarzuty
 - [https://tvn24.pl/wroclaw/legnica-zarzuty-dla-30-latka-mial-biegac-z-nozem-i-atakowac-przechodniow-7683151?source=rss](https://tvn24.pl/wroclaw/legnica-zarzuty-dla-30-latka-mial-biegac-z-nozem-i-atakowac-przechodniow-7683151?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T13:41:57+00:00

<img alt="Miał biegać z nożem i atakować przechodniów. Usłyszał zarzuty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5as8a7-mezczyzna-zaatakowal-dwie-osoby-i-uszkodzil-piec-aut-7663297/alternates/LANDSCAPE_1280" />
    30-latek, który w Legnicy (woj. dolnośląskie) miał zaatakować nożem przypadkowego mężczyznę i kobietę, usłyszał cztery zarzuty, w tym usiłowania zabójstwa. Dzisiaj sąd zdecyduje, czy trafi do aresztu.

## Powikłania po COVID-19 "przypominają pole bitwy". WOŚP pomoże tym, którzy "tę walkę jeszcze toczą"
 - [https://tvn24.pl/wosp-2024/wosp-2024-dr-tomasz-karauda-o-powiklaniach-po-covid-19-i-potrzebach-polskiej-pulmonologii-7682601?source=rss](https://tvn24.pl/wosp-2024/wosp-2024-dr-tomasz-karauda-o-powiklaniach-po-covid-19-i-potrzebach-polskiej-pulmonologii-7682601?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T13:13:41+00:00

<img alt="Powikłania po COVID-19 " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7yls5u-gosc-0006-7682558/alternates/LANDSCAPE_1280" />
    Cieszę się, że Fundacja Wielkiej Orkiestry Świątecznej Pomocy jest tak wrażliwa i na ten rok wybrała temat płuc po pandemii, żeby pomóc tym, którzy tę walkę jeszcze toczą - powiedział w programie "Wstajesz i wiesz" w TVN24 pulmonolog dr Tomasz Karauda. Podkreślił, że w wielu przypadkach powikłania po COVID-19 "przypominają pole bitwy".

## Pijana 36-latka uderzyła autem w sygnalizator. Za kierownicą zastąpił ją równie pijany mąż
 - [https://tvn24.pl/szczecin/koszalin-pijana-kierujaca-uderzyla-w-sygnalizator-swietlny-za-kierownica-zastapil-ja-bardziej-pijany-maz-7683091?source=rss](https://tvn24.pl/szczecin/koszalin-pijana-kierujaca-uderzyla-w-sygnalizator-swietlny-za-kierownica-zastapil-ja-bardziej-pijany-maz-7683091?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T12:39:26+00:00

<img alt="Pijana 36-latka uderzyła autem w sygnalizator. Za kierownicą zastąpił ją równie pijany mąż" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fael3-policja-zatrzymala-pijanych-kierowcow-6725912/alternates/LANDSCAPE_1280" />
    Pijane małżeństwo 36-latków z Koszalina w sylwestrową noc zostało zatrzymane przez policję po interwencji przypadkowego świadka. Widział, jak kierująca renault z dużą siłą uderzyła w sygnalizator świetlny przy przejściu dla pieszych. Następnie za kierownicą zastąpił ją mąż. Obojgu grożą teraz poważne konsekwencje.

## Koniec zniżek na autostradzie. Zarządca wyjaśnia
 - [https://tvn24.pl/biznes/moto/autostrada-a4-zmiany-w-stawkach-od-16-stycznia-2024-roku-st7683174?source=rss](https://tvn24.pl/biznes/moto/autostrada-a4-zmiany-w-stawkach-od-16-stycznia-2024-roku-st7683174?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T12:32:01+00:00

<img alt="Koniec zniżek na autostradzie. Zarządca wyjaśnia" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie437c3ebd681c63549410a52f81a5d5d2-stalexport-podwyzsza-ceny-za-przejazd-autostrada-a4-katowice-krakow-4799382/alternates/LANDSCAPE_1280" />
    Już za kilka dni zarządca płatnej autostrady A4 Katowice-Kraków zniesie zniżkę za przejazd z wykorzystaniem płatności automatycznych. W związku z tym cena na każdej bramce dla kierowców samochodów osobowych wyniesie 15 złotych (ze zniżką jest 13 złotych).

## Księżyc "nadziewany" wulkanami. Nowe zdjęcia Io
 - [https://tvn24.pl/tvnmeteo/nauka/nasa-misja-juno-ksiezyc-nadziewany-wulkanami-nowe-zdjecia-io-ksiezyca-jowisza-st7683082?source=rss](https://tvn24.pl/tvnmeteo/nauka/nasa-misja-juno-ksiezyc-nadziewany-wulkanami-nowe-zdjecia-io-ksiezyca-jowisza-st7683082?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T12:29:38+00:00

<img alt="Księżyc " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-w7vswt-io-w-obiektywie-sondy-juno-7683126/alternates/LANDSCAPE_1280" />
    NASA zaprezentowała nowe zdjęcia Io, wulkanicznego księżyca Jowisza. Pod koniec 2023 roku sonda Juno zbliżyła się do powierzchni ciała niebieskiego na odległość zaledwie 1500 kilometrów. Zdjęcia pozwalają zajrzeć również na "ciemną stronę" obiektu.

## "Operacja Kret". Turecka policja zatrzymała kilkadziesiąt osób podejrzanych o szpiegowanie dla Mosadu
 - [https://tvn24.pl/swiat/turcja-policja-zatrzymala-kilkadziesiat-osob-podejrzanych-o-szpiegowanie-dla-izraelskiego-mosadu-7683076?source=rss](https://tvn24.pl/swiat/turcja-policja-zatrzymala-kilkadziesiat-osob-podejrzanych-o-szpiegowanie-dla-izraelskiego-mosadu-7683076?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T12:29:04+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fhfwll-turkey-0016-7683133/alternates/LANDSCAPE_1280" />
    Turecka policja zatrzymała ponad 30 osób, podejrzanych o działania szpiegowskie prowadzone na zlecenie izraelskiego Mosadu - poinformowała we wtorek agencja Reutera, powołując się na ministra spraw wewnętrznych Turcji.

## Napadli ich na ulicy i okradli. Wśród zatrzymanych 13-latka
 - [https://tvn24.pl/lublin/lublin-napadli-ich-i-pobili-na-ulicy-wsrod-zatrzymanych-13-latka-7683080?source=rss](https://tvn24.pl/lublin/lublin-napadli-ich-i-pobili-na-ulicy-wsrod-zatrzymanych-13-latka-7683080?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T12:24:22+00:00

<img alt="Napadli ich na ulicy i okradli. Wśród zatrzymanych 13-latka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1qwvwv-19-latek-uslyszal-zarzut-rozboju-7683016/alternates/LANDSCAPE_1280" />
    Policja weszła do mieszkania 19-latka, który miał ze swoją 13-letnią koleżanką napaść i pobić na jednej z ulic w Lublinie 43-latka i jego 39-letnią znajomą. Zaczęło się od prośby o papierosa. 19-latek trafił do aresztu. 13-latka stanie przed sądem dla nieletnich.

## Pożar w domu jednorodzinnym. Nie żyje mężczyzna, dwie osoby zdołały się ewakuować
 - [https://tvn24.pl/rzeszow/stalowa-wola-pozar-w-domu-jednorodzinnym-nie-zyje-mezczyzna-7683096?source=rss](https://tvn24.pl/rzeszow/stalowa-wola-pozar-w-domu-jednorodzinnym-nie-zyje-mezczyzna-7683096?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T12:17:03+00:00

<img alt="Pożar w domu jednorodzinnym. Nie żyje mężczyzna, dwie osoby zdołały się ewakuować" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yrbbm0-zycia-mezczyzny-nie-udalo-sie-uratowac-7683104/alternates/LANDSCAPE_1280" />
    Jedna osoba zginęła w pożarze domu w Stalowej Woli (woj. podkarpackie). Dwóch mężczyzn ewakuowało się z budynku przed przyjazdem straży pożarnej, nic im się nie stało. Przyczyny wybuchu ognia nie są na razie znane.

## „Zabiliście koziołka, tego, który miał iść na wolność”. Zwierzę nie przeżyło sylwestra
 - [https://tvn24.pl/wroclaw/wyszonowice-zwierzeta-nie-przezyly-sylwestera-zabiliscie-koziolka-tego-ktory-mial-isc-na-wolnosc-7682726?source=rss](https://tvn24.pl/wroclaw/wyszonowice-zwierzeta-nie-przezyly-sylwestera-zabiliscie-koziolka-tego-ktory-mial-isc-na-wolnosc-7682726?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T11:41:44+00:00

<img alt="„Zabiliście koziołka, tego, który miał iść na wolność”. Zwierzę nie przeżyło sylwestra" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5ruqt3-zwierzeta-z-fundacji-osrodek-leczenia-i-rehabilitacji-dzikich-zwierzat-puchaczowka-7682898/alternates/LANDSCAPE_1280" />
    Z konsekwencjami sylwestrowych fajerwerków mierzą się właściciele Fundacji Puchaczówka w miejscowości Wyszonowice (woj. dolnośląskie). Z powodu huku wystrzałów w schronisku padły zwierzęta: koziołek i dwa ptaki.

## Zmarł Aleksander Herzog, opozycjonista i prokurator w stanie spoczynku
 - [https://tvn24.pl/polska/aleksander-herzog-opozycjonista-i-prokurator-w-stanie-spoczynku-nie-zyje-7682937?source=rss](https://tvn24.pl/polska/aleksander-herzog-opozycjonista-i-prokurator-w-stanie-spoczynku-nie-zyje-7682937?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T11:35:45+00:00

<img alt="Zmarł Aleksander Herzog, opozycjonista i prokurator w stanie spoczynku " src="https://tvn24.pl/najnowsze/cdn-zdjecie-d4aum7-pap_20170119_1pd-7682963/alternates/LANDSCAPE_1280" />
    Aleksander Herzog, prokurator Prokuratury Krajowej w stanie spoczynku, w latach 80. wydalony z pracy za działalność opozycyjną, zmarł w wieku 72 lat - poinformowało Stowarzyszenie Prokuratorów Lex Super Omnia.

## Zima powróciła do części Polski. Miejscami leży ponad 10 cm śniegu
 - [https://tvn24.pl/tvnmeteo/polska/snieg-w-bialymstoku-zima-powrocila-na-wschod-polski-st7682838?source=rss](https://tvn24.pl/tvnmeteo/polska/snieg-w-bialymstoku-zima-powrocila-na-wschod-polski-st7682838?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T11:25:11+00:00

<img alt="Zima powróciła do części Polski. Miejscami leży ponad 10 cm śniegu" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-nm5kcm-zimowa-aura-w-bialymstoku-7682910/alternates/LANDSCAPE_1280" />
    Zimowo zrobiło się we wtorek w części Polski. Na Podlasiu, Warmii i Mazurach oraz Lubelszczyźnie o poranku zanotowano śnieżną pokrywę o grubości sięgającej nawet 11 centymetrów. W Białymstoku zapanowała prawdziwie zimowa aura, chociaż mieszkańcy narzekali na konieczność odśnieżania aut.

## 85-latka przechodziła w niedozwolonym miejscu przez tory. Potrącił ją pociąg
 - [https://tvn24.pl/lodz/myslakow-85-latka-przechodzila-w-niedozwolonym-miejscu-przez-tory-smiertelnie-potracil-ja-pociag-7682857?source=rss](https://tvn24.pl/lodz/myslakow-85-latka-przechodzila-w-niedozwolonym-miejscu-przez-tory-smiertelnie-potracil-ja-pociag-7682857?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T11:22:24+00:00

<img alt="85-latka przechodziła w niedozwolonym miejscu przez tory. Potrącił ją pociąg" src="https://tvn24.pl/najnowsze/cdn-zdjecie-88g3cj-pociag-smiertelnie-potracila-70-letnie-kobiete-7682859/alternates/LANDSCAPE_1280" />
    W Mysłakowie (woj. łódzkie) pociąg osobowy śmiertelnie potrącił starszą kobietę. 85-latka przechodziła w niedozwolonym miejscu przez tory. Zginęła na miejscu w wyniku odniesionych obrażeń. Policja pod nadzorem prokuratora wyjaśnia szczegółowe okoliczności wypadku.

## Zderzenie trzech aut, sprawca ukarany wysokim mandatem
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-trzech-aut-sprawca-ukarany-mandatem-st7682982?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-zderzenie-trzech-aut-sprawca-ukarany-mandatem-st7682982?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T11:06:56+00:00

<img alt="Zderzenie trzech aut, sprawca ukarany wysokim mandatem " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-j1b6x2-zderzyly-sie-trzy-auta-7682985/alternates/LANDSCAPE_1280" />
    Na skrzyżowaniu ulic Żwirki i Wigury z 1 Sierpnia doszło we wtorek przed południem do kolizji trzech aut. Policja podała, że nie ma osób poszkodowanych. Jeden z kierowców został ukarany mandatem.

## "Opuściłem szybę i otrzymałem potężny cios prosto w łuk brwiowy". Miejski radny ofiarą drogowej agresji
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-miejski-radny-pobity-przez-rowerzyste-st7682805?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-miejski-radny-pobity-przez-rowerzyste-st7682805?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T11:04:14+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n802lw-miejski-radny-pobity-przez-rowerzyste-7682878/alternates/LANDSCAPE_1280" />
    Radny Warszawy Piotr Żbikowski (KO) został zaatakowany kilka dni temu w rejonie ronda "Radosława". Jak relacjonuje samorządowiec, podczas wjazdu autem na parking centrum handlowego najechał na niego rowerzysta. To on miał uderzyć radnego i odjechać. Sprawą zajmuje się policja.

## Tak wyglądał praprzodek człowieka. Lucy żyła 3,2 miliona lat temu
 - [https://tvn24.pl/krakow/krakow-rekonstrukcja-praczlowieka-lucy-na-wystawie-centrum-edukacji-przyrodniczej-uj-7682685?source=rss](https://tvn24.pl/krakow/krakow-rekonstrukcja-praczlowieka-lucy-na-wystawie-centrum-edukacji-przyrodniczej-uj-7682685?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T10:57:14+00:00

<img alt="Tak wyglądał praprzodek człowieka. Lucy żyła 3,2 miliona lat temu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k4lutf-rekonstrukcja-praczlowieka-lucy-w-centrum-edukacji-przyrodniczej-uj-7682698/alternates/LANDSCAPE_1280" />
    Mierzyła 110 centymetrów wzrostu, ważyła 28 kilogramów i miała mózg o pojemności zbliżonej do współczesnego szympansa. Na wystawie w Centrum Edukacji Przyrodniczej Uniwersytetu Jagiellońskiego w Krakowie można oglądać rekonstrukcję Lucy - praczłowieka sprzed 3,2 miliona lat. Podobiznę stworzono na podstawie "niezwykle dobrze zachowanego" szkieletu odnalezionego w Etiopii.

## "Opłata paliwowa w górę". PiS wini rząd Tuska. Czego nie mówi?
 - [https://konkret24.tvn24.pl/polska/ceny-benzyny-oplata-paliwowa-w-gore-pis-wini-rzad-tuska-czego-nie-mowi-st7663267?source=rss](https://konkret24.tvn24.pl/polska/ceny-benzyny-oplata-paliwowa-w-gore-pis-wini-rzad-tuska-czego-nie-mowi-st7663267?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T10:53:19+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kflkko-oplata-paliwowa-do-gory-pis-wini-ministra-czego-nie-mowi-7663431/alternates/LANDSCAPE_1280" />
    Politycy Prawa i Sprawiedliwości wytykają obecnemu rządowi, że od stycznia podniósł opłatę paliwową, więc ceny paliw na stacjach wzrosną. Jednak nie wyjaśniali, że ta decyzja ministra infrastruktury wynika ze stosownej ustawy i jest skutkiem wzrostu cen rok do roku. Oraz że tak samo robił szef resortu infrastruktury w rządzie Zjednoczonej Prawicy

## Zamówili kurs, a potem ukradli taksówkę. "Zagrozili kierowcy nożem"
 - [https://tvn24.pl/katowice/ustron-zatrzymani-dwaj-mezczyzni-podejrzani-o-kradziez-taksowki-7682885?source=rss](https://tvn24.pl/katowice/ustron-zatrzymani-dwaj-mezczyzni-podejrzani-o-kradziez-taksowki-7682885?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T10:42:33+00:00

<img alt="Zamówili kurs, a potem ukradli taksówkę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sxzwr6-policja-zatrzymala-dwoch-mezczyzn-podejrzanych-o-kradziez-taksowki-7682845/alternates/LANDSCAPE_1280" />
    Policja zatrzymała dwóch mężczyzn podejrzanych o kradzież taksówki. Zatrzymani mieli zamówić kurs z Czeskiego Cieszyna do Ustronia (woj. śląskie), a po przyjeździe na miejsce sterroryzować kierowcę nożem. Zostali zatrzymani kilka dni po zdarzeniu.

## Oszuści podszywają się pod duży bank. "Niebezpieczne strony"
 - [https://tvn24.pl/biznes/z-kraju/oszusci-podszywaja-sie-pod-ing-bank-slaski-ostrzezenie-przed-nowym-oszustwem-niebezpieczne-strony-st7682683?source=rss](https://tvn24.pl/biznes/z-kraju/oszusci-podszywaja-sie-pod-ing-bank-slaski-ostrzezenie-przed-nowym-oszustwem-niebezpieczne-strony-st7682683?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T10:40:22+00:00

<img alt="Oszuści podszywają się pod duży bank. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wlop0k-shutterstock_2081074822-7371795/alternates/LANDSCAPE_1280" />
    Zespół cyberbezpieczeństwa w Komisji Nadzoru Finansowego (CSIRT KNF) ostrzega w komunikacie przed oszustami, którzy podszywają się pod ING Bank Śląski. Cyberprzestępcy poprzez fałszywe strony próbują wyłudzić dane do bankowości elektronicznej.

## Dwucyfrowy wzrost cen mieszkań. Kraków przed Warszawą
 - [https://tvn24.pl/biznes/nieruchomosci/mieszkania-na-sprzedaz-ceny-ofertowe-krakow-i-warszawa-z-najwiekszymi-wzrostami-raport-expandera-i-rentierio-st7682705?source=rss](https://tvn24.pl/biznes/nieruchomosci/mieszkania-na-sprzedaz-ceny-ofertowe-krakow-i-warszawa-z-najwiekszymi-wzrostami-raport-expandera-i-rentierio-st7682705?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T10:34:46+00:00

<img alt="Dwucyfrowy wzrost cen mieszkań. Kraków przed Warszawą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gofq5m-krakow-mieszkania-7682794/alternates/LANDSCAPE_1280" />
    Ceny ofertowe mieszkań w ostatnich miesiącach wzrosły przeciętnie o 13 procent - wynika z raportu Expandera i Rentier.io. Największe podwyżki dotyczą Krakowa i Warszawy. Eksperci w pierwszej połowie 2024 roku spodziewają "stabilizacji poziomu cen lub minimalnego spadku".

## Styczniowa premiera w TVN. Nowy program z Joanną Krupą i Ewą Chodakowską
 - [https://tvn24.pl/kultura-i-styl/joanna-krupa-i-ewa-chodakowska-maja-nowy-program-w-tvn-o-czym-jest-razem-odnowa-7682775?source=rss](https://tvn24.pl/kultura-i-styl/joanna-krupa-i-ewa-chodakowska-maja-nowy-program-w-tvn-o-czym-jest-razem-odnowa-7682775?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T10:33:19+00:00

<img alt="Styczniowa premiera w TVN. Nowy program z Joanną Krupą i Ewą Chodakowską " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rph4iv-15071269_razem-odnowa-pierwsze-zdjecia-z-planu_original-1-1-7682650/alternates/LANDSCAPE_1280" />
    3 stycznia pierwszy odcinek nowego programu "Razem odNowa". Ewa Chodakowska i Joanna Krupa pomogą małżeństwom, które po wielu latach bycia razem wpadły w rutynę. "Razem odNowa" w środę o godz. 21.35 na antenie TVN i w Playerze.

## Prawie tydzień bez jedzenia i ogrzewania. 72-latka zatrzasnęła się na strychu
 - [https://tvn24.pl/lublin/lubycza-krolewska-policjanci-uratowali-seniorke-ktora-zatrzasnela-sie-na-strychu-7682799?source=rss](https://tvn24.pl/lublin/lubycza-krolewska-policjanci-uratowali-seniorke-ktora-zatrzasnela-sie-na-strychu-7682799?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T10:28:49+00:00

<img alt="Prawie tydzień bez jedzenia i ogrzewania. 72-latka zatrzasnęła się na strychu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-muk5f9-policjanci-uratowali-seniorke-ktora-zatrzasnela-sie-na-strychu-7682802/alternates/LANDSCAPE_1280" />
    Sześć dni spędziła zamknięta na strychu 72-letnia kobieta, która zatrzasnęła się w pomieszczeniu. Nie miała ogrzewania ani jedzenia. Policję powiadomił syn kobiety zaniepokojony brakiem kontaktu z matką. Mundurowi siłowo weszli do domu w Lubyczy Królewskiej (woj. lubelskie), gdzie na strychu znaleźli wyczerpaną kobietę. Seniorka trafiła do szpitala. Powoli wraca do zdrowia.

## Szlaki w górach mogą być zdradliwie śliskie, rośnie zagrożenie lawinowe
 - [https://tvn24.pl/tvnmeteo/polska/tatry-karkonosze-beskidy-sliskie-szlaki-i-zagrozenie-lawinowe-w-polskich-gorach-st7682640?source=rss](https://tvn24.pl/tvnmeteo/polska/tatry-karkonosze-beskidy-sliskie-szlaki-i-zagrozenie-lawinowe-w-polskich-gorach-st7682640?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T10:20:28+00:00

<img alt="Szlaki w górach mogą być zdradliwie śliskie, rośnie zagrożenie lawinowe" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-r9tmed-dolina-chocholowska-widok-na-kominiarski-wierch-02012024-7682800/alternates/LANDSCAPE_1280" />
    Trudne warunki turystyczne zapanowały w polskich górach. W Tatrach zagrożenie lawinowe ponownie wzrosło do drugiego stopnia, szlaki są śliskie i pokryte zaspami śnieżnymi. Ostrożność powinni zachować również turyści wybierający się w wyższe partie Beskidów i Karkonoszy.

## Przyleciał z Tirany i trafił do aresztu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/nowy-dwor-mazowiecki-byl-poszukiwany-za-przestepstwa-narkotykowe-zatrzymali-go-pogranicznicy-w-modlinie-st7682627?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/nowy-dwor-mazowiecki-byl-poszukiwany-za-przestepstwa-narkotykowe-zatrzymali-go-pogranicznicy-w-modlinie-st7682627?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T09:48:54+00:00

<img alt="Przyleciał z Tirany i trafił do aresztu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-z5enci-do-zatrzymania-doszlo-podczas-odprawy-paszportowej-zdjecie-ilustracyjne-7399567/alternates/LANDSCAPE_1280" />
    Podczas kontroli na lotnisku w Modlinie funkcjonariusze Straży Granicznej zatrzymali 30-letniego Albańczyka. Mężczyzna był poszukiwany przez włoski wymiar sprawiedliwości za przestępstwa narkotykowe.

## Pożar samolotu na lotnisku w Tokio
 - [https://tvn24.pl/swiat/japonia-pozar-samolotu-na-lotnisku-w-tokio-7682717?source=rss](https://tvn24.pl/swiat/japonia-pozar-samolotu-na-lotnisku-w-tokio-7682717?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T09:30:49+00:00

<img alt="Pożar samolotu na lotnisku w Tokio " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-0esms1-pilna-wiadomosc-6147821/alternates/LANDSCAPE_1280" />

## Tyle trzeba zapłacić za euro i dolara
 - [https://tvn24.pl/biznes/rynki/euro-dolar-frank-funt-notowania-020124-kurs-zlotego-stabilny-st7682592?source=rss](https://tvn24.pl/biznes/rynki/euro-dolar-frank-funt-notowania-020124-kurs-zlotego-stabilny-st7682592?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T09:26:29+00:00

<img alt="Tyle trzeba zapłacić za euro i dolara" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r1lrvx-shutterstock_2148330929-7375090/alternates/LANDSCAPE_1280" />
    Kurs złotego we wtorek o poranku pozostaje stabilny. Za euro trzeba zapłacić 4,34 zł, a dolara amerykańskiego 3,94 zł. Ekonomiści prognozują, że w pierwszych miesiącach tego roku krajowa waluta ma szanse na umocnienie.

## Skusił ją szybkim zyskiem z inwestycji w kryptowaluty
 - [https://tvn24.pl/tvnwarszawa/okolice/otwock-chciala-zainwestowac-w-kryptowaluty-stracila-60-tysiecy-zlotych-st7682572?source=rss](https://tvn24.pl/tvnwarszawa/okolice/otwock-chciala-zainwestowac-w-kryptowaluty-stracila-60-tysiecy-zlotych-st7682572?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T09:17:00+00:00

<img alt="Skusił ją szybkim zyskiem z inwestycji w kryptowaluty" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-y3cu2-policjanci-z-otwocka-zatrzymali-26-latka-podejrzanego-o-oszustwo-7682606/alternates/LANDSCAPE_1280" />
    Policjanci z Otwocka zatrzymali 26-latka podejrzanego o oszustwo. Obiecał pokrzywdzonej szybki zysk w kryptowalutach. Kobieta straciła 60 tysięcy złotych.

## Koniec przyjmowania wniosków o "bezpieczny kredyt"
 - [https://tvn24.pl/biznes/pieniadze/kredyty-mieszkaniowe-bezpieczny-kredyt-2-procent-bank-gospodarstwa-krajowego-o-zakonczeniu-przyjmowania-wnioskow-przez-banki-komunikaty-bgk-st7682504?source=rss](https://tvn24.pl/biznes/pieniadze/kredyty-mieszkaniowe-bezpieczny-kredyt-2-procent-bank-gospodarstwa-krajowego-o-zakonczeniu-przyjmowania-wnioskow-przez-banki-komunikaty-bgk-st7682504?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T09:09:10+00:00

<img alt="Koniec przyjmowania wniosków o " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9kncfx-podejrzani-o-oszustwo-wynajmowali-mieszkania-ktorych-nie-mieli-zdjecie-ilustracyjne-6899769/alternates/LANDSCAPE_1280" />
    Banki od wtorku wstrzymały przyjmowanie wniosków o udzielenie kredytów mieszkaniowych w ramach programu Bezpieczny kredyt 2 procent. Tak wynika z komunikatu opublikowanego przez Bank Gospodarstwa Krajowego. Ministerstwo Rozwoju i Technologii pracuje nad nowym programem mieszkaniowym.

## Rosyjska rakieta wleciała do Polski. Wiceszef MON: mamy pewność, że opuściła terytorium kraju
 - [https://tvn24.pl/polska/rosyjska-rakieta-nad-polska-wiceszef-mon-pawel-zalewski-mamy-pewnosc-ze-opuscila-terytorium-kraju-7682603?source=rss](https://tvn24.pl/polska/rosyjska-rakieta-nad-polska-wiceszef-mon-pawel-zalewski-mamy-pewnosc-ze-opuscila-terytorium-kraju-7682603?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T09:07:23+00:00

<img alt="Rosyjska rakieta wleciała do Polski. Wiceszef MON: mamy pewność, że opuściła terytorium kraju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a0a09h-poszukiwania-ewentualnych-elementow-obiektu-ktory-naruszyl-polska-przestrzen-powietrzna-w-okolicach-wozuczyna-7682632/alternates/LANDSCAPE_1280" />
    Mamy pewność, że rakieta, która w piątek naruszyła polską przestrzeń powietrzną, opuściła terytorium kraju. Mamy potwierdzenie z radarów polskich, ale także sojuszniczych. Żeby mieć stuprocentową pewność skierowaliśmy około 500 żołnierzy Wojsk Obrony Terytorialnej, którzy przeczesywali tamte tereny i nie znaleźli żadnych szczątków - powiedział w RMF FM wiceminister obrony narodowej Paweł Zalewski.

## Tańsze dla drogowców, wygodniejsze dla kierowców. Płatności mobilne wypierają gotówkę
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-bedzie-wiecej-platnosci-mobilnych-za-parkowanie-w-sppn-st7682553?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-bedzie-wiecej-platnosci-mobilnych-za-parkowanie-w-sppn-st7682553?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T08:49:27+00:00

<img alt="Tańsze dla drogowców, wygodniejsze dla kierowców. Płatności mobilne wypierają gotówkę" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-7t0n2q-sppn-w-srodmiesciu-zdjecie-ilustracyjne-5014884/alternates/LANDSCAPE_1280" />
    Będzie więcej kanałów płatności mobilnych za parkowanie w Strefie Płatnego Parkowania Niestrzeżonego na stołecznych ulicach. - To tańsze rozwiązanie dla drogowców i wygodniejsze dla mieszkańców - przyznaje dyrektor ZDM Łukasz Puchalski.

## W dobę spadło tyle deszczu, co zazwyczaj przez cały miesiąc
 - [https://tvn24.pl/tvnmeteo/swiat/australia-w-dobe-spadlo-tyle-deszczu-co-przez-caly-miesiac-st7682436?source=rss](https://tvn24.pl/tvnmeteo/swiat/australia-w-dobe-spadlo-tyle-deszczu-co-przez-caly-miesiac-st7682436?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T08:44:56+00:00

<img alt="W dobę spadło tyle deszczu, co zazwyczaj przez cały miesiąc" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ylb77z-wezbrana-rzeka-coomera-w-queensland-australia-7682521/alternates/LANDSCAPE_1280" />
    Powodzie nawiedziły we wtorek wschodnią Australię. Miejscami w dobę spadło ponad 300 litrów deszczu na metr kwadratowy - tyle, co przeważnie pada tam przez cały styczeń - a prognozowane są dalsze ulewy. W walce ze skutkami podtopień pomaga wojsko.

## Pożar mieszkania, kobieta z dwójką dzieci w szpitalu
 - [https://tvn24.pl/olsztyn/ostroda-pozar-mieszkania-kobieta-z-dwojka-dzieci-w-szpitalu-7682510?source=rss](https://tvn24.pl/olsztyn/ostroda-pozar-mieszkania-kobieta-z-dwojka-dzieci-w-szpitalu-7682510?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T08:12:24+00:00

<img alt="Pożar mieszkania, kobieta z dwójką dzieci w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7w453g-pozar-budynku-wielorodzinnego-w-ostrodzie-7682513/alternates/LANDSCAPE_1280" />
    Pożar mieszkania w budynku wielorodzinnym w Ostródzie (woj. warmińsko-mazurskie). Trzy osoby zostały poszkodowane. To kobieta z dwójką dzieci.

## Przybywa nietoperzy w stołecznych parkach. "To nasi sprzymierzeńcy w walce z uciążliwymi owadami"
 - [https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-policzyli-nietoperze-w-parkach-jest-ich-coraz-wiecej-st7682499?source=rss](https://tvn24.pl/tvnwarszawa/zoliborz/warszawa-policzyli-nietoperze-w-parkach-jest-ich-coraz-wiecej-st7682499?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T08:04:07+00:00

<img alt="Przybywa nietoperzy w stołecznych parkach. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4srdct-wsrod-odlowionych-nietoperzy-najliczniej-wystepuje-borowiec-wielki-7682492/alternates/LANDSCAPE_1280" />
    Z badań przeprowadzonych na zlecenie Zarządu Zieleni Warszawy wynika, że populacja nietoperzy w stolicy wzrasta. - W lipcu i sierpniu 2023 roku odłowiono 479 nietoperzy z dziewięciu gatunków. Liczba tych ssaków w stolicy zaskoczyła chiropterologów. - W tym roku zamontowaliśmy testowo 20 budek szczelinowych dla nietoperzy - wyliczają miejscy ogrodnicy.

## Tir z pieluchami stanął w płomieniach. Kierowca zasnął za kierownicą
 - [https://tvn24.pl/wroclaw/dolny-slask-a4-tir-z-pieluchami-przewrocil-sie-na-bok-i-zaczal-sie-palic-kierowca-zasnal-za-kierownica-7682497?source=rss](https://tvn24.pl/wroclaw/dolny-slask-a4-tir-z-pieluchami-przewrocil-sie-na-bok-i-zaczal-sie-palic-kierowca-zasnal-za-kierownica-7682497?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T07:56:54+00:00

<img alt="Tir z pieluchami stanął w płomieniach. Kierowca zasnął za kierownicą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vcb6b3-pozar-ciezarowki-na-autostradzie-a4-7682484/alternates/LANDSCAPE_1280" />
    Pożar ciężarówki na autostradzie A4 niedaleko Legnicy (woj. dolnośląskie). Kierowca zasnął za kierownicą, uderzył w bariery, w wyniku czego doszło do zapalenia się pojazdu. W samochodzie znajdowały się dwie osoby. Nic im się nie stało.

## Irański okręt wojenny Alborz wpłynął na Morze Czerwone
 - [https://tvn24.pl/swiat/jemen-iranski-okret-wojenny-alborz-wplynal-na-morze-czerwone-7667507?source=rss](https://tvn24.pl/swiat/jemen-iranski-okret-wojenny-alborz-wplynal-na-morze-czerwone-7667507?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T07:32:17+00:00

<img alt="Irański okręt wojenny Alborz wpłynął na Morze Czerwone" src="https://tvn24.pl/najnowsze/cdn-zdjecie-weqsf1-iranski-okret-wojenny-alborz-3141925/alternates/LANDSCAPE_1280" />
    Irański okręt wojenny wpłynął na Morze Czerwone przez strategiczną cieśninę Bab el-Mandeb - przekazała agencja Tasnim. W niedzielę helikoptery amerykańskie z grupy uderzeniowej lotniskowca USS Eisenhower ostrzelały rebeliantów Huti, którzy usiłowali wejść na pokład kontenerowca firmy Maersk.

## Najniższa krajowa w 2024 roku. Ile na rękę przy umowie o pracę?
 - [https://tvn24.pl/biznes/pieniadze/najnizsza-krajowa-2024-netto-brutto-ile-na-reke-przy-umowie-o-prace-st7682429?source=rss](https://tvn24.pl/biznes/pieniadze/najnizsza-krajowa-2024-netto-brutto-ile-na-reke-przy-umowie-o-prace-st7682429?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T07:01:11+00:00

<img alt="Najniższa krajowa w 2024 roku. Ile na rękę przy umowie o pracę?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-whkore-pln-pieniadze-monety-shutterstock_1189131874-7403768/alternates/LANDSCAPE_1280" />
    Ile wynosi najniższa krajowa w 2024 roku? Od 1 stycznia minimalne wynagrodzenie za pracę to 4242 złote brutto, a stawka godzinowa - 27,70 złotego brutto. Z początkiem roku miała miejsce pierwsza podwyżka płacy minimalnej. Kolejną zaplanowano na lipiec. Najniższa krajowa wzrośnie wówczas do 4300 złotych brutto, a minimalna stawka godzinowa do 28,10 złotego brutto.

## Stajenka, wielbłądy i pastuszkowie. Tegoroczne Orszaki Trzech Króli pod hasłem "W jasełkach leży!"
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-orszak-trzech-kroli-2024-trasa-godzina-rozpoczecia-atrakcje-st7682420?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-orszak-trzech-kroli-2024-trasa-godzina-rozpoczecia-atrakcje-st7682420?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T05:55:08+00:00

<img alt="Stajenka, wielbłądy i pastuszkowie. Tegoroczne Orszaki Trzech Króli pod hasłem " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecied41d8cd98f00b204e9800998ecf8427e-orszaki-trzech-kroli-przeszly-ulicami-polskich-miast-5370864/alternates/LANDSCAPE_1280" />
    W sobotę, 6 stycznia, ulicami 800 polskich miast przejdą Orszaki Trzech Króli. W tym roku wydarzeniom towarzyszy hasło "W jasełkach leży!". W Warszawie wędrówka Maryi i Józefa rozpocznie się spod pomnika Kopernika.

## Pogoda na dziś - wtorek 02.01. Deszcz i śnieg, od -5 do 7 stopni
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-wtorek-0201-deszcz-i-snieg-od-5-do-7-stopni-st7664332?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-wtorek-0201-deszcz-i-snieg-od-5-do-7-stopni-st7664332?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-01-02T01:00:00+00:00

<img alt="Pogoda na dziś - wtorek 02.01. Deszcz i śnieg, od -5 do 7 stopni " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-87bydn-snieg-7522500/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Wtorek 02.01 w całym kraju upłynie pod znakiem opadów. W niektórych regionach temperatura będzie ujemna i tam należy spodziewać się śniegu.

