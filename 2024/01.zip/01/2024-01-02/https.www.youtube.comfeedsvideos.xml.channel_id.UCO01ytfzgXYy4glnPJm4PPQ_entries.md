# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## The Greatest Gift of 2023
 - [https://www.youtube.com/watch?v=v88Q4GDbcbw](https://www.youtube.com/watch?v=v88Q4GDbcbw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-01-02T23:00:35+00:00



## The Reason You Don't Want Flaccid Fries
 - [https://www.youtube.com/watch?v=6eucYCjBANE](https://www.youtube.com/watch?v=6eucYCjBANE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2024-01-02T19:00:05+00:00



