# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Marvel Studios' Echo - Official Prey Trailer (2024) Alaqua Cox, Vincent D'Onofrio
 - [https://www.youtube.com/watch?v=nksYgSdl0rU](https://www.youtube.com/watch?v=nksYgSdl0rU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-01-02T20:39:43+00:00

Check out the latest trailer for Marvel Studios' Echo as we get more glimpses at whats in store for the 5-episode series event alongside Wilson Fisk comparing Echo to a tiger stalking in silence for their prey.

Marvel Studios' Echo stars Alaqua Cox, Zahn McClarnon, Vincent D'Onofrio, Charlie Cox, Devery Jacobs, Dannie McCallum, Alejandra Jaime, Alexis Capozzi, and more. The series is directed by Catriona McKenzie and Sydney Freeland alongside Kevin Feige, Amy Rardin, Brad Winderbaum, and Etan Cohen as producers. 

All 5 episodes of Marvel Studios’ Echo start streaming on January 9, 2024, at 6 PM PT exclusively on Disney Plus and Hulu.

