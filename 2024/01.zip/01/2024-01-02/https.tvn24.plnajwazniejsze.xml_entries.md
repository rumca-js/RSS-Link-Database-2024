# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Nie żyje jeden z liderów Hamasu. Hezbollah o "karze", wojsko Izraela "w gotowości"
 - [https://tvn24.pl/swiat/eksplozja-w-bejrucie-izraelski-dron-uderzyl-w-budynek-hamasu-wsrod-ofiar-jeden-z-liderow-hamasu-7683625?source=rss](https://tvn24.pl/swiat/eksplozja-w-bejrucie-izraelski-dron-uderzyl-w-budynek-hamasu-wsrod-ofiar-jeden-z-liderow-hamasu-7683625?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T21:33:52+00:00

<img alt="Nie żyje jeden z liderów Hamasu. Hezbollah o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7tq4ya-libanscy-zolnierze-stoja-na-szczycie-pojazdu-opancerzonego-w-miejscu-eksplozji-w-poludniowej-dzielnicy-bejrutu-2-stycznia-7683895/alternates/LANDSCAPE_1280" />
    Hezbollah zapowiada odwet.

## Ukraina zrezygnowała z finansowej pomocy. "Brać od was pieniądze? To będzie nieuczciwe"
 - [https://eurosport.tvn24.pl/igrzyska-olimpijskie/paryz-2024/2024/ukraina-odrzucila-finansowa-pomoc-mkol.-brac-od-was-pieniadze-to-bedzie-nieuczciwe_sto9941764/story.shtml?source=rss](https://eurosport.tvn24.pl/igrzyska-olimpijskie/paryz-2024/2024/ukraina-odrzucila-finansowa-pomoc-mkol.-brac-od-was-pieniadze-to-bedzie-nieuczciwe_sto9941764/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T21:01:34+00:00

<img alt="Ukraina zrezygnowała z finansowej pomocy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-33a87q-igrzyska-olimpijskie-w-paryzu-rozpoczna-sie-26-lipca-7683899/alternates/LANDSCAPE_1280" />
    Powód? MKOl dopuścił rosyjskich i białoruskich sportowców do startu w igrzyskach olimpijskich w Paryżu.

## Bodnar zapowiada ustawę w sprawie wyboru członków KRS i "kompleksowe rozwiązania" w sprawie TK
 - [https://tvn24.pl/polska/krajowa-rada-sadownictwa-planowane-zmiany-adam-bodnar-minister-sprawiedliwosci-i-prokurator-generalny-komentuje-7683733?source=rss](https://tvn24.pl/polska/krajowa-rada-sadownictwa-planowane-zmiany-adam-bodnar-minister-sprawiedliwosci-i-prokurator-generalny-komentuje-7683733?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T19:49:21+00:00

<img alt="Bodnar zapowiada ustawę w sprawie wyboru członków KRS i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1qok7y-adam-bodnar-7683786/alternates/LANDSCAPE_1280" />
    Minister sprawiedliwości i prokurator generalny w "Kropce nad i".

## Rekordowa liczba przeszczepów płuc w Polsce. "Sukces jest tym bardziej cenny, że wcale nie przybyło dawców"
 - [https://fakty.tvn24.pl/zobacz-fakty/rekordowa-liczba-przeszczepow-pluc-w-polsce-sukces-jest-tym-bardziej-cenny-ze-wcale-nie-przybylo-dawcow-st7683792?source=rss](https://fakty.tvn24.pl/zobacz-fakty/rekordowa-liczba-przeszczepow-pluc-w-polsce-sukces-jest-tym-bardziej-cenny-ze-wcale-nie-przybylo-dawcow-st7683792?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T19:42:11+00:00

<img alt="Rekordowa liczba przeszczepów płuc w Polsce. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-35qwdu-nowicki-7683797/alternates/LANDSCAPE_1280" />
    W ubiegłym roku udało się wykonać 98 przeszczepów płuc.

## Z wypowiedzi prezydenta "niewiele wynika"
 - [https://tvn24.pl/polska/oredzie-prezydenta-andrzej-duda-o-lamaniu-konstytucji-byly-prezes-tk-jerzy-stepien-komentuje-7683791?source=rss](https://tvn24.pl/polska/oredzie-prezydenta-andrzej-duda-o-lamaniu-konstytucji-byly-prezes-tk-jerzy-stepien-komentuje-7683791?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T19:26:53+00:00

<img alt="Z wypowiedzi prezydenta " src="https://tvn24.pl/najnowsze/cdn-zdjecie-osxpir-andrzej-duda-7663598/alternates/LANDSCAPE_1280" />
    Były prezes Trybunału Konstytucyjnego Jerzy Stępień był gościem "Faktów po Faktach".

## Mysz się nie prześlizgnie. Skazanych pilnują gęsi
 - [https://fakty.tvn24.pl/zobacz-fakty/wiezienie-zastapilo-psy-gesiami-to-o-wiele-bardziej-skuteczne-i-oplacalne-st7683756?source=rss](https://fakty.tvn24.pl/zobacz-fakty/wiezienie-zastapilo-psy-gesiami-to-o-wiele-bardziej-skuteczne-i-oplacalne-st7683756?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T19:14:49+00:00

<img alt="Mysz się nie prześlizgnie. Skazanych pilnują gęsi" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-295zao-abramowicz-7683761/alternates/LANDSCAPE_1280" />
    Nowe patrolowe zwyczaje w Brazylii.

## Nie pozwolili na przepłynięcie okrętów podarowanych Ukrainie
 - [https://tvn24.pl/swiat/ukraina-turcja-nie-zezwolila-na-wplyniecie-dwoch-brytyjskich-tralowcow-podarowanych-ukrainie-7683688?source=rss](https://tvn24.pl/swiat/ukraina-turcja-nie-zezwolila-na-wplyniecie-dwoch-brytyjskich-tralowcow-podarowanych-ukrainie-7683688?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T18:31:59+00:00

<img alt="Nie pozwolili na przepłynięcie okrętów podarowanych Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m312wt-forum-0443700946-1-7683704/alternates/LANDSCAPE_1280" />
    Powołano się na międzynarodową konwencję.

## Plaga oszustw na wirtualne kwatery. "Jedna pani została w ten sposób oszukana dwukrotnie"
 - [https://tvn24.pl/biznes/z-kraju/zakopane-plaga-oszustw-na-tzw-wirtualne-kwatery-st7683730?source=rss](https://tvn24.pl/biznes/z-kraju/zakopane-plaga-oszustw-na-tzw-wirtualne-kwatery-st7683730?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T18:28:13+00:00

<img alt="Plaga oszustw na wirtualne kwatery. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-935dls-pap_20231231_0t9-7683750/alternates/LANDSCAPE_1280" />
    Poinformował rzecznik zakopiańskiej policji.

## Atak drona w Bejrucie. Media: nie żyje ważny przywódca Hamasu
 - [https://tvn24.pl/swiat/bejrut-liban-eksplozja-w-bejrucie-izraelski-dron-uderzyl-w-budynek-hamasu-sa-ofiary-smiertelne-7683625?source=rss](https://tvn24.pl/swiat/bejrut-liban-eksplozja-w-bejrucie-izraelski-dron-uderzyl-w-budynek-hamasu-sa-ofiary-smiertelne-7683625?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T17:26:35+00:00

<img alt="Atak drona w Bejrucie. Media: nie żyje ważny przywódca Hamasu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qqzdmq-izraelski-dron-uderzyl-w-budynek-hamasu-w-bejrucie-7683673/alternates/LANDSCAPE_1280" />
    Izraelskie wojsko jak dotąd nie potwierdziło tych doniesień.

## -40 stopni, 70 centymetrów śniegu. Przestały jeździć pociągi, zamknięto szkoły
 - [https://tvn24.pl/tvnmeteo/swiat/atak-zimy-w-skandynawii-40-stopni-w-szwecji-70-cm-sniegu-w-norwegii-zamknieto-szkoly-przestaly-jezdzic-pociagi-st7683633?source=rss](https://tvn24.pl/tvnmeteo/swiat/atak-zimy-w-skandynawii-40-stopni-w-szwecji-70-cm-sniegu-w-norwegii-zamknieto-szkoly-przestaly-jezdzic-pociagi-st7683633?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T17:22:36+00:00

<img alt="-40 stopni, 70 centymetrów śniegu. Przestały jeździć pociągi, zamknięto szkoły" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-hg8h15-sparalizowany-ruch-pociagow-w-szwedzkim-miescie-lulea-7683655/alternates/LANDSCAPE_1280" />
    Atak zimy w Skandynawii.

## Były polski mistrz świata złapany na dopingu. Wieloletnia dyskwalifikacja
 - [https://eurosport.tvn24.pl/boks/byly-piesciarz-krzysztof-glowacki-zdyskwalifikowany-na-cztery-lata-z-powodu-dopingu_sto9941727/story.shtml?source=rss](https://eurosport.tvn24.pl/boks/byly-piesciarz-krzysztof-glowacki-zdyskwalifikowany-na-cztery-lata-z-powodu-dopingu_sto9941727/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T17:14:58+00:00

<img alt="Były polski mistrz świata złapany na dopingu. Wieloletnia dyskwalifikacja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4o6yk7-krzysztof-glowacki-7683658/alternates/LANDSCAPE_1280" />
    Pięściarz posiadał tytuł federacji WBO w wadzie junior ciężkiej.

## "Dania płacze" po decyzji królowej. Ale nie wszędzie w Europie monarchowie są tak lubiani
 - [https://tvn24.pl/ciekawostki/dania-abdykacja-krolowej-malgorzaty-ii-jak-wyglada-poparcie-dla-monarchii-w-europie-7683500?source=rss](https://tvn24.pl/ciekawostki/dania-abdykacja-krolowej-malgorzaty-ii-jak-wyglada-poparcie-dla-monarchii-w-europie-7683500?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T16:50:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6bt6r1-ksiezna-maria-i-ksiaze-fryderyk-7683532/alternates/LANDSCAPE_1280" />
    Małgorzata II jest najpopularniejszym członkiem duńskiej rodziny królewskiej.

## Policja podsumowała sylwestrowy weekend na drogach
 - [https://fakty.tvn24.pl/fakty-po-poludniu/sylwestrowy-weekend-na-drogach-policja-przedstawila-statystyki-st7683613?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/sylwestrowy-weekend-na-drogach-policja-przedstawila-statystyki-st7683613?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T16:37:11+00:00

<img alt="Policja podsumowała sylwestrowy weekend na drogach" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-bihlaz-czuprynska-7683614/alternates/LANDSCAPE_1280" />
    Policja wstępnie podsumowała też cały 2023 rok na drogach.

## Nastolatek odnaleziony zmarznięty i przerażony. Padł ofiarą "cyberporwania"
 - [https://tvn24.pl/swiat/usa-kai-zhuang-odnaleziony-po-dwoch-dniach-czym-jest-cyberporwanie-7683346?source=rss](https://tvn24.pl/swiat/usa-kai-zhuang-odnaleziony-po-dwoch-dniach-czym-jest-cyberporwanie-7683346?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T16:33:41+00:00

<img alt="Nastolatek odnaleziony zmarznięty i przerażony. Padł ofiarą " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ry51cf-kai-zhuang-padl-ofiara-cyberporwania-7683332/alternates/LANDSCAPE_1280" />
    Chciał porozmawiać z rodzicami, poprosił o "ciepłego cheeseburgera".

## 10-latek zabrał skradzioną broń z samochodu ojca i zastrzelił rówieśnika
 - [https://tvn24.pl/swiat/usa-10-latek-zabral-skradziona-bron-z-samochodu-ojca-i-zastrzelil-rowiesnika-twierdzi-policja-w-sacramento-7683609?source=rss](https://tvn24.pl/swiat/usa-10-latek-zabral-skradziona-bron-z-samochodu-ojca-i-zastrzelil-rowiesnika-twierdzi-policja-w-sacramento-7683609?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T16:20:32+00:00

<img alt="10-latek zabrał skradzioną broń z samochodu ojca i zastrzelił rówieśnika" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cz5u1z-policja-usa-6743069/alternates/LANDSCAPE_1280" />
    Twierdzi policja.

## Zmarł profesor Wojciech Łączkowski
 - [https://tvn24.pl/polska/wojciech-laczkowski-nie-zyje-byl-sedzia-trybunalu-konstytucyjnego-i-przewodniczacym-pkw-7683584?source=rss](https://tvn24.pl/polska/wojciech-laczkowski-nie-zyje-byl-sedzia-trybunalu-konstytucyjnego-i-przewodniczacym-pkw-7683584?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T16:12:51+00:00

<img alt="Zmarł profesor Wojciech Łączkowski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xhf1n6-wojciech-laczkowski-7683592/alternates/LANDSCAPE_1280" />
    Był sędzią Trybunału Konstytucyjnego i przewodniczącym PKW.

## Ile za euro w 2024 roku? Nowe prognozy
 - [https://tvn24.pl/biznes/rynki/kurs-euro-do-zlotego-2024-ile-bedzie-kosztowac-euro-prognoza-ing-st7683558?source=rss](https://tvn24.pl/biznes/rynki/kurs-euro-do-zlotego-2024-ile-bedzie-kosztowac-euro-prognoza-ing-st7683558?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T16:11:43+00:00

<img alt="Ile za euro w 2024 roku? Nowe prognozy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o3ggu3-shutterstock_2093442703-7683594/alternates/LANDSCAPE_1280" />
    Głos zabrali ekonomiści ING.

## "Staje w roli działacza partyjnego swojej macierzystej partii"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/koniec-nadziei-na-wspolprace-prezydenta-z-nowym-rzadem-staje-w-roli-dzialacza-partyjnego-swojej-macierzystej-partii-st7683579?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/koniec-nadziei-na-wspolprace-prezydenta-z-nowym-rzadem-staje-w-roli-dzialacza-partyjnego-swojej-macierzystej-partii-st7683579?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T16:07:15+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-gr4vg-kowalska-7683583/alternates/LANDSCAPE_1280" />
    Czy w polskich realiach kohabitacja oznacza pat i spór?

## Nowe świadczenie z ZUS. "Ważne jest, żeby zachować właściwą kolejność"
 - [https://tvn24.pl/biznes/z-kraju/nowe-swiadczenie-od-zus-swiadczenie-wspierajace-2024-zus-o-pierwszych-wnioskach-st7683452?source=rss](https://tvn24.pl/biznes/z-kraju/nowe-swiadczenie-od-zus-swiadczenie-wspierajace-2024-zus-o-pierwszych-wnioskach-st7683452?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T15:25:11+00:00

<img alt="Nowe świadczenie z ZUS. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jxtbsw-zus-szczecin-grand-warszawski-shutterstock_2360135365-7375977/alternates/LANDSCAPE_1280" />
    Zakład Ubezpieczeń Społecznych wyjaśnia.

## 23-latek zmarł po zatrzymaniu przez policję. "Mamie powiedział, że policjanci go pobili"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wolomin-smierc-mlodego-mezczyzny-wczesniej-byl-zatrzymany-przez-policje-st7683434?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wolomin-smierc-mlodego-mezczyzny-wczesniej-byl-zatrzymany-przez-policje-st7683434?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T15:24:03+00:00

<img alt="23-latek zmarł po zatrzymaniu przez policję. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nhxmi9-kpp-wolomin-7683519/alternates/LANDSCAPE_1280" />
    Sprawę bada prokuratura.

## Polski arcymistrz nie podał ręki Rosjaninowi
 - [https://eurosport.tvn24.pl/szachy/jan-krzysztof-duda-nie-podal-reki-rosjaninowi-denisowi-chismatullinowi-na-mistrzostwach-swiata-w-sam_sto9941665/story.shtml?source=rss](https://eurosport.tvn24.pl/szachy/jan-krzysztof-duda-nie-podal-reki-rosjaninowi-denisowi-chismatullinowi-na-mistrzostwach-swiata-w-sam_sto9941665/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T15:21:22+00:00

<img alt="Polski arcymistrz nie podał ręki Rosjaninowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-op75ax-jan-krzysztof-duda-7683570/alternates/LANDSCAPE_1280" />
    Głośno o zachowaniu polskiego szachisty na mistrzostwach świata.

## Zasnął w aucie pod Zimną Wódką. Był tak pijany, że w alkomacie zabrakło skali
 - [https://tvn24.pl/opole/lesnica-kierowca-byl-tak-pijany-ze-w-alkomacie-zabraklo-skali-zasnal-w-aucie-pod-zimna-wodka-7683377?source=rss](https://tvn24.pl/opole/lesnica-kierowca-byl-tak-pijany-ze-w-alkomacie-zabraklo-skali-zasnal-w-aucie-pod-zimna-wodka-7683377?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T15:05:07+00:00

<img alt="Zasnął w aucie pod Zimną Wódką. Był tak pijany, że w alkomacie zabrakło skali" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dcvf4p-23-latek-wydmuchal-4-promila-7683470/alternates/LANDSCAPE_1280" />
    23-latek stracił prawo jazdy.

## Stoch podjął ważną decyzję. "On mi już nie pomoże"
 - [https://eurosport.tvn24.pl/skoki-narciarskie/innsbruck/2023-2024/co-powiedzial-kamil-stoch-po-kwalifikacjach-do-konkursu-tcs-w-innsbrucku_sto9941635/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/innsbruck/2023-2024/co-powiedzial-kamil-stoch-po-kwalifikacjach-do-konkursu-tcs-w-innsbrucku_sto9941635/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T14:58:55+00:00

<img alt="Stoch podjął ważną decyzję. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-eogk2h-kamil-stoch-po-kwalifikacjach-do-konkursu-w-innsbrucku-7683539/alternates/LANDSCAPE_1280" />
    Kwalifikacje do trzeciej odsłony Turnieju Czterech Skoczni w Innsbrucku zakończył na 13. miejscu.

## Wielka agencja ratingowa o "hipotetycznym" scenariuszu w sprawie Adama Glapińskiego
 - [https://tvn24.pl/biznes/z-kraju/prezes-nbp-adam-glapinski-a-trybunal-stanu-rating-polski-komentuje-analityk-agencji-sandp-global-ratings-st7683400?source=rss](https://tvn24.pl/biznes/z-kraju/prezes-nbp-adam-glapinski-a-trybunal-stanu-rating-polski-komentuje-analityk-agencji-sandp-global-ratings-st7683400?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T14:44:11+00:00

<img alt="Wielka agencja ratingowa o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-r9r02d-adam-glapinski-7629680/alternates/LANDSCAPE_1280" />
    Główny analityk agencji S&amp;P Global Ratings komentuje.

## Mróz będzie wdzierać się coraz śmielej, śnieg spadnie w całym kraju
 - [https://tvn24.pl/tvnmeteo/prognoza/zima-bedzie-sie-rozkrecac-powrot-zimy-mroz-i-snieg-w-calej-polsce-pogoda-na-kolejne-dni-st7683369?source=rss](https://tvn24.pl/tvnmeteo/prognoza/zima-bedzie-sie-rozkrecac-powrot-zimy-mroz-i-snieg-w-calej-polsce-pogoda-na-kolejne-dni-st7683369?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T14:36:44+00:00

<img alt="Mróz będzie wdzierać się coraz śmielej, śnieg spadnie w całym kraju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jaouwu-zima-wraca-7683395/alternates/LANDSCAPE_1280" />
    Co czeka nas w pogodzie do końca tygodnia.

## Wyłącznie na smyczy i w kagańcu. Brytyjczycy próbują wyeliminować rasę psów
 - [https://tvn24.pl/swiat/wielka-brytania-psy-rasy-american-bully-xl-wkrotce-zakazane-od-31-grudnia-tylko-na-smyczy-i-w-kagancu-7682582?source=rss](https://tvn24.pl/swiat/wielka-brytania-psy-rasy-american-bully-xl-wkrotce-zakazane-od-31-grudnia-tylko-na-smyczy-i-w-kagancu-7682582?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T14:25:57+00:00

<img alt="Wyłącznie na smyczy i w kagańcu. Brytyjczycy próbują wyeliminować rasę psów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ijxq8h-psy-rasy-american-bully-xl-7338448/alternates/LANDSCAPE_1280" />
    Po serii śmiertelnych pogryzień.

## Słowa Pietrzaka o migrantach. Prokuratura wszczyna postępowanie
 - [https://tvn24.pl/polska/slowa-jana-pietrzaka-o-migrantach-prokuratura-wszczeto-postepowanie-dotyczace-tej-wypowiedzi-7683426?source=rss](https://tvn24.pl/polska/slowa-jana-pietrzaka-o-migrantach-prokuratura-wszczeto-postepowanie-dotyczace-tej-wypowiedzi-7683426?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T14:23:36+00:00

<img alt="Słowa Pietrzaka o migrantach. Prokuratura wszczyna postępowanie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2wjbdt-jan-pietrzak-7683439/alternates/LANDSCAPE_1280" />
    Poinformował rzecznik prasowy Prokuratury Okręgowej w Warszawie Szymon Banna.

## Syn Zenka Martyniuka miał awanturować się w hotelu w Zakopanem. Interweniowała policja
 - [https://tvn24.pl/krakow/zakopane-syn-zenka-martyniuka-mial-awanturowac-sie-w-hotelu-dwie-interwencje-policji-7683380?source=rss](https://tvn24.pl/krakow/zakopane-syn-zenka-martyniuka-mial-awanturowac-sie-w-hotelu-dwie-interwencje-policji-7683380?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T14:20:59+00:00

<img alt="Syn Zenka Martyniuka miał awanturować się w hotelu w Zakopanem. Interweniowała policja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-btscia-zenek-martyniuk-7683366/alternates/LANDSCAPE_1280" />
    "Obie interwencje były związane z zakłóceniem porządku przez tę samą osobę".

## Gdzie jechać na wakacje? 24 najlepsze kierunki w 2024 roku
 - [https://tvn24.pl/ciekawostki/podroze-najciekawsze-kierunki-na-2024-rok-gdzie-jechac-na-wakacje-7683141?source=rss](https://tvn24.pl/ciekawostki/podroze-najciekawsze-kierunki-na-2024-rok-gdzie-jechac-na-wakacje-7683141?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T14:16:13+00:00

<img alt="Gdzie jechać na wakacje? 24 najlepsze kierunki w 2024 roku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5694zb-24-destynacje-podroznicze-na-2024-rok-gdzie-jechac-na-wakacje-7683221/alternates/LANDSCAPE_1280" />
    Ranking CNN.

## Katastrofa Kubackiego. Laniszek poza konkurencją
 - [https://eurosport.tvn24.pl/skoki-narciarskie/innsbruck/2023-2024/skoki-narciarskie-innsbruck-2024-wyniki-kwalifikacji-i-relacja-turniej-czterech-skoczni_sto9941439/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/innsbruck/2023-2024/skoki-narciarskie-innsbruck-2024-wyniki-kwalifikacji-i-relacja-turniej-czterech-skoczni_sto9941439/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T14:08:26+00:00

<img alt="Katastrofa Kubackiego. Laniszek poza konkurencją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4lhk3k-dawid-kubacki-7683417/alternates/LANDSCAPE_1280" />
    Kamil Stoch najlepszy z Polaków w kwalifikacjach w Innsbrucku.

## Autobus na boku. Jechało nim 21 pasażerów
 - [https://tvn24.pl/tvnwarszawa/ulice/jablonna-autobus-na-boku-w-rowie-zderzenie-z-autem-osobowym-st7683333?source=rss](https://tvn24.pl/tvnwarszawa/ulice/jablonna-autobus-na-boku-w-rowie-zderzenie-z-autem-osobowym-st7683333?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T13:48:49+00:00

<img alt="Autobus na boku. Jechało nim 21 pasażerów " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dk5tp6-zderzenie-w-jablonnie-7683352/alternates/LANDSCAPE_1280" />
    Podróż skończył w rowie.

## Bili niemowlę, bo denerwował ich płacz. Rodzice usłyszeli zarzuty
 - [https://tvn24.pl/poznan/kepno-niemowle-z-obrazeniami-glowy-trafilo-do-szpitala-rodzice-uslyszeli-zarzuty-7682801?source=rss](https://tvn24.pl/poznan/kepno-niemowle-z-obrazeniami-glowy-trafilo-do-szpitala-rodzice-uslyszeli-zarzuty-7682801?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T13:46:26+00:00

<img alt="Bili niemowlę, bo denerwował ich płacz. Rodzice usłyszeli zarzuty " src="https://tvn24.pl/najnowsze/cdn-zdjecie-iqqdij-kepno-rodzice-niemowlecia-z-zarzutami-7683334/alternates/LANDSCAPE_1280" />
    Grozi im od 3 do 20 lat pozbawienia wolności.

## "Natychmiastowa karma". Rosyjski pocisk nie doleciał do Ukrainy
 - [https://tvn24.pl/swiat/rosja-rosyjski-pocisk-nie-dolecial-na-ukraine-spadl-w-obwodzie-woroneskim-7683222?source=rss](https://tvn24.pl/swiat/rosja-rosyjski-pocisk-nie-dolecial-na-ukraine-spadl-w-obwodzie-woroneskim-7683222?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T13:36:40+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-chs8y5-cue-16-fhd_nie-7683249/alternates/LANDSCAPE_1280" />
    Spadł na wieś w rosyjskim obwodzie woroneskim.

## Atak rekina na Hawajach. Nie żyje 39-latek
 - [https://tvn24.pl/tvnmeteo/swiat/hawaje-usa-smiertelny-atak-rekina-zmarl-39-letni-mezczyzna-st7683199?source=rss](https://tvn24.pl/tvnmeteo/swiat/hawaje-usa-smiertelny-atak-rekina-zmarl-39-letni-mezczyzna-st7683199?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T13:23:52+00:00

<img alt="Atak rekina na Hawajach. Nie żyje 39-latek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m4eger-rekin-zdjecie-pogladowe-6025238/alternates/LANDSCAPE_1280" />
    To pierwszy taki przypadek od ponad roku.

## Potężne zamieszanie wokół kursów walut. Mamy stanowisko Google
 - [https://tvn24.pl/biznes/rynki/kurs-euro-do-zlotego-eurpln-bledne-kursy-walut-odpowiedz-google-st7683307?source=rss](https://tvn24.pl/biznes/rynki/kurs-euro-do-zlotego-eurpln-bledne-kursy-walut-odpowiedz-google-st7683307?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T13:22:32+00:00

<img alt="Potężne zamieszanie wokół kursów walut. Mamy stanowisko Google" src="https://tvn24.pl/najnowsze/cdn-zdjecie-duiod9-untitled-1-7683321/alternates/LANDSCAPE_1280" />
    Przekazane w odpowiedzi na pytania redakcji biznesowej tvn24.pl .

## Zmarł dziennikarz sportowy Wojciech Bąkowicz
 - [https://eurosport.tvn24.pl/pilka-nozna/wojciech-bakowicz-dziennikarz-sportowy-nie-zyje_sto9941454/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/wojciech-bakowicz-dziennikarz-sportowy-nie-zyje_sto9941454/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T13:02:24+00:00

<img alt="Zmarł dziennikarz sportowy Wojciech Bąkowicz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r2kw29-wojtek-bakowicz-mial-24-lata-7683297/alternates/LANDSCAPE_1280" />
    Miał 24 lata.

## Mozolne śledztwo po wypadku renault w Krakowie. "Nie otrzymaliśmy żadnej odpowiedzi"
 - [https://tvn24.pl/krakow/krakow-sledztwo-po-wypadku-renault-przy-moscie-debnickim-prokuratura-czeka-na-zeznania-pieszego-7683170?source=rss](https://tvn24.pl/krakow/krakow-sledztwo-po-wypadku-renault-przy-moscie-debnickim-prokuratura-czeka-na-zeznania-pieszego-7683170?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T13:00:11+00:00

<img alt="Mozolne śledztwo po wypadku renault w Krakowie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-oydyaf-wypadek-w-krakowie-7228532/alternates/LANDSCAPE_1280" />
    Prokuratura czeka na ważne zeznania.

## Schneidemühl przed wojną, potem stolica województwa, a dziś już tylko powiatu. Czy to miasto ma serce?
 - [https://tvn24.pl/premium/pila-przed-wojna-schneidemuhl-potem-stolica-wojewodztwa-a-dzis-juz-tylko-powiatu-czy-to-miasto-ma-serce-7651653?source=rss](https://tvn24.pl/premium/pila-przed-wojna-schneidemuhl-potem-stolica-wojewodztwa-a-dzis-juz-tylko-powiatu-czy-to-miasto-ma-serce-7651653?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T12:49:05+00:00

<img alt="Schneidemühl przed wojną, potem stolica województwa, a dziś już tylko powiatu. Czy to miasto ma serce?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m422ii-laweczka-stanislawa-staszica-i-pomnik-tysiaclecia-panstwa-polskiego-7592967/alternates/LANDSCAPE_1280" />
    Jest większa niż Barcelona i tylko nieco mniejsza niż Paryż. Ale nie ma Zamku Królewskiego ani Wawelu. To miasto zielone za sprawą lasów i płotów. Jego mieszkańcy na pytanie, co ma do zaoferowania turystom, odpowiadają szczerze: nic. Piła wita.

## Rok po wypadku Jeremy Renner pokazał "powód numer jeden powrotu do zdrowia"
 - [https://tvn24.pl/kultura-i-styl/jeremy-renner-rok-po-wypadku-o-powodzie-numer-jeden-do-powrotu-do-zdrowia-7682856?source=rss](https://tvn24.pl/kultura-i-styl/jeremy-renner-rok-po-wypadku-o-powodzie-numer-jeden-do-powrotu-do-zdrowia-7682856?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T12:48:38+00:00

<img alt="Rok po wypadku Jeremy Renner pokazał " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1zq1mg-jeremy-renner-rok-po-wypadku-wpis-na-instagramie-7683233/alternates/LANDSCAPE_1280" />
    Aktor trafił do szpitala w stanie krytycznym.

## Lista 200 nazwisk powiązanych ze sprawą Epsteina może zostać odtajniona w każdej chwili
 - [https://tvn24.pl/swiat/usa-sprawa-epsteina-lista-200-nazwisk-powiazanych-ze-sprawa-moze-zostac-odtajniona-7682586?source=rss](https://tvn24.pl/swiat/usa-sprawa-epsteina-lista-200-nazwisk-powiazanych-ze-sprawa-moze-zostac-odtajniona-7682586?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T12:29:22+00:00

<img alt="Lista 200 nazwisk powiązanych ze sprawą Epsteina może zostać odtajniona w każdej chwili" src="https://tvn24.pl/najnowsze/cdn-zdjecied41d8cd98f00b204e9800998ecf8427e-epstein-oskarzony-o-naklanianie-do-prostytucji-i-wykorzystywanie-seksualne-nieletnich-dziewczat-zmarl-w-sobote-10-sierpnia-4989477/alternates/LANDSCAPE_1280" />
    Media spekulują o znanych osobach.

## "Nie został wpuszczony przez ochronę, wrócił z siekierą"
 - [https://tvn24.pl/krakow/zakopane-atak-siekiera-na-ochroniarzy-na-dyskotece-areszt-dla-podejrzanego-7683142?source=rss](https://tvn24.pl/krakow/zakopane-atak-siekiera-na-ochroniarzy-na-dyskotece-areszt-dla-podejrzanego-7683142?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T12:25:57+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-f3dyfy-mezczyzna-zostal-zatrzymany-7663212/alternates/LANDSCAPE_1280" />
    Mężczyzna trafił do aresztu.

## "Nigdy nie myślałam, że znajdę się obok Rihanny czy Taylor Swift"
 - [https://tvn24.pl/kultura-i-styl/martyna-wojciechowska-na-prestizowej-liscie-nigdy-nie-myslalam-ze-znajde-sie-obok-rihanny-czy-taylor-swift-7683066?source=rss](https://tvn24.pl/kultura-i-styl/martyna-wojciechowska-na-prestizowej-liscie-nigdy-nie-myslalam-ze-znajde-sie-obok-rihanny-czy-taylor-swift-7683066?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T12:24:11+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5behcp-martyna-wojciechowska-7683092/alternates/LANDSCAPE_1280" />
    Martyna Wojciechowska o wyróżnieniu w dwóch prestiżowych rankingach.

## Pistolet deputowanego wystrzelił w trakcie zabawy sylwestrowej. Jedna osoba została ranna
 - [https://tvn24.pl/swiat/wlochy-pistolet-deputowanego-partii-bracia-wlosi-wystrzelil-w-trakcie-zabawy-sylwestrowej-jedna-osoba-zostala-ranna-7683102?source=rss](https://tvn24.pl/swiat/wlochy-pistolet-deputowanego-partii-bracia-wlosi-wystrzelil-w-trakcie-zabawy-sylwestrowej-jedna-osoba-zostala-ranna-7683102?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T12:15:06+00:00

<img alt="Pistolet deputowanego wystrzelił w trakcie zabawy sylwestrowej. Jedna osoba została ranna" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gzylev-forum-0833700391-7683098/alternates/LANDSCAPE_1280" />
    Prokuratura wszczęła śledztwo.

## Rekordowe wyniki oglądalności. Dziękujemy widzom TVN24 i "Faktów" TVN
 - [https://tvn24.pl/biznes/z-kraju/tvn24-fakty-tvn-wyniki-ogladalnosci-w-grudniu-2023-st7683084?source=rss](https://tvn24.pl/biznes/z-kraju/tvn24-fakty-tvn-wyniki-ogladalnosci-w-grudniu-2023-st7683084?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T12:13:19+00:00

<img alt="Rekordowe wyniki oglądalności. Dziękujemy widzom TVN24 i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lqtuje-tvn-5510678/alternates/LANDSCAPE_1280" />
    Dane za grudzień 2023.

## Zamieszanie wokół kursu złotego. Jest interwencja Ministerstwa Finansów
 - [https://tvn24.pl/biznes/z-kraju/ministerstwo-finansow-i-narodowy-bank-polski-o-kursie-zlotego-jest-pismo-do-google-polska-st7683121?source=rss](https://tvn24.pl/biznes/z-kraju/ministerstwo-finansow-i-narodowy-bank-polski-o-kursie-zlotego-jest-pismo-do-google-polska-st7683121?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T12:00:37+00:00

<img alt="Zamieszanie wokół kursu złotego. Jest interwencja Ministerstwa Finansów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fdzr1m-ministerstwo-finansow-shutterstock1074556148s-5557353/alternates/LANDSCAPE_1280" />
    Resort zwrócił się do Google Polska.

## Jajka w prezencie noworocznym
 - [https://tvn24.pl/swiat/rosja-polityk-partii-wladimira-putina-sprezentowal-urzedniczkom-jajka-7682990?source=rss](https://tvn24.pl/swiat/rosja-polityk-partii-wladimira-putina-sprezentowal-urzedniczkom-jajka-7682990?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T11:56:37+00:00

<img alt="Jajka w prezencie noworocznym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ywwr8p-radny-jajka-7683065/alternates/LANDSCAPE_1280" />
    Aleksandr Gordiejew dowodził, że zrobił to dla "poprawy nastroju".

## Zwłoki mężczyzny w szkole. Dyrekcja zawiesiła zajęcia
 - [https://tvn24.pl/lubuskie/gorzow-wielkopolski-zwloki-mezczyzny-w-szkole-dyrekcja-zawiesila-zajecia-7683074?source=rss](https://tvn24.pl/lubuskie/gorzow-wielkopolski-zwloki-mezczyzny-w-szkole-dyrekcja-zawiesila-zajecia-7683074?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T11:49:16+00:00

<img alt="Zwłoki mężczyzny w szkole. Dyrekcja zawiesiła zajęcia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aotmbp-cialo-mezczyzny-znaleziono-w-szkole-7683078/alternates/LANDSCAPE_1280" />
    Sprawę bada prokuratura.

## Kamiński i Wąsik "zawsze uważali, że są ponad prawem"
 - [https://tvn24.pl/polska/mariusz-kaminski-i-maciej-wasik-odwolali-sie-od-decyzji-marszalka-sejmu-o-wygasnieciu-mandatow-poselskich-komentarze-7682780?source=rss](https://tvn24.pl/polska/mariusz-kaminski-i-maciej-wasik-odwolali-sie-od-decyzji-marszalka-sejmu-o-wygasnieciu-mandatow-poselskich-komentarze-7682780?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T11:20:37+00:00

<img alt="Kamiński i Wąsik " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xqpsra-wasik-kaminski-7637889/alternates/LANDSCAPE_1280" />
    Reakcje polityczne na odwołanie się Kamińskiego i Wąsika od decyzji marszałka Sejmu.

## Nagrania z płonącego samolotu. "Myślałem, że umrę"
 - [https://tvn24.pl/najnowsze/japonia-pozar-samolotu-na-lotnisku-w-tokio-nagrania-z-plonacej-maszyny-7683057?source=rss](https://tvn24.pl/najnowsze/japonia-pozar-samolotu-na-lotnisku-w-tokio-nagrania-z-plonacej-maszyny-7683057?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T11:16:02+00:00

<img alt="Nagrania z płonącego samolotu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-il6mdh-pozar-samolotu-w-tokio-zdjecia-pasazerow-7682991/alternates/LANDSCAPE_1280" />
    Co działo się we wnętrzu płonącej maszyny.

## "Czasy się zmieniają". Wymowne zdjęcie Graneruda z Kubackim
 - [https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/czasy-sie-zmieniaja.-wymowne-zdjecie-graneruda-z-kubackim_sto9941302/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/garmisch-partenkirchen/2023-2024/czasy-sie-zmieniaja.-wymowne-zdjecie-graneruda-z-kubackim_sto9941302/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T11:13:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8qpbm1-dawid-kubacki-halvor-egner-granerud-zakopane-2023-7683062/alternates/LANDSCAPE_1280" />
    Raz na wozie, raz pod wozem.

## Zmiany w państwowym banku. Dwie osoby odwołane przez premiera
 - [https://tvn24.pl/biznes/z-kraju/premier-donald-tusk-dokonal-zmian-w-radzie-nadzorczej-banku-gospodarstwa-krajowego-piotr-kieloch-oraz-joanna-strzesak-rochewicz-odwolani-st7682813?source=rss](https://tvn24.pl/biznes/z-kraju/premier-donald-tusk-dokonal-zmian-w-radzie-nadzorczej-banku-gospodarstwa-krajowego-piotr-kieloch-oraz-joanna-strzesak-rochewicz-odwolani-st7682813?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T11:08:20+00:00

<img alt="Zmiany w państwowym banku. Dwie osoby odwołane przez premiera " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xv9r31-bgk-bank-gospodarstwa-krajowego-7682891/alternates/LANDSCAPE_1280" />
    Komunikat giełdowy.

## Ktoś odpalił fajerwerki w Dolinie Pięciu Stawów
 - [https://tvn24.pl/krakow/tatry-szukaja-osoby-ktora-odpalila-fajerwerki-w-dolinie-pieciu-stawow-7682824?source=rss](https://tvn24.pl/krakow/tatry-szukaja-osoby-ktora-odpalila-fajerwerki-w-dolinie-pieciu-stawow-7682824?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T11:03:41+00:00

<img alt="Ktoś odpalił fajerwerki w Dolinie Pięciu Stawów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jm7zy-fajerwerki-w-tatrach-7682869/alternates/LANDSCAPE_1280" />
    Wandal może zapłacić nawet 1500 złotych mandatu.

## Stado zwierząt na drodze. Uciekły z zagrody wystraszone hukiem fajerwerków
 - [https://tvn24.pl/olsztyn/powiat-dzialdowski-stado-zwierzat-na-drodze-uciekly-z-zagrody-wystraszone-hukiem-fajerwerkow-7682746?source=rss](https://tvn24.pl/olsztyn/powiat-dzialdowski-stado-zwierzat-na-drodze-uciekly-z-zagrody-wystraszone-hukiem-fajerwerkow-7682746?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T10:48:01+00:00

<img alt="Stado zwierząt na drodze. Uciekły z zagrody wystraszone hukiem fajerwerków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h5m2t-zwierzeta-uciekly-wystraszone-w-sylwestrowa-noc-7682729/alternates/LANDSCAPE_1280" />
    Udało się je wyłapać i bezpiecznie odprowadzić do gospodarstwa.

## Austria wita skoczków. Treningi i kwalifikacje w Innsbrucku
 - [https://eurosport.tvn24.pl/skoki-narciarskie/innsbruck/2023-2024/liveevent.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/innsbruck/2023-2024/liveevent.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T10:44:00+00:00

<img alt="Austria wita skoczków. Treningi i kwalifikacje w Innsbrucku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-denlk9-innsbruck-7682938/alternates/LANDSCAPE_1280" />
    Relacja eurosport.pl

## Wjechała w dzieci, 11-letni Paweł nie żyje. Jest opinia biegłych
 - [https://tvn24.pl/rzeszow/humniska-wjechala-w-dzieci-11-letni-pawel-zmarl-biegli-jechala-za-szybko-i-nieostroznie-7682580?source=rss](https://tvn24.pl/rzeszow/humniska-wjechala-w-dzieci-11-letni-pawel-zmarl-biegli-jechala-za-szybko-i-nieostroznie-7682580?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T10:00:52+00:00

<img alt="Wjechała w dzieci, 11-letni Paweł nie żyje. Jest opinia biegłych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jkgd4y-w-wypadku-zginal-11-latek-jego-rowiesnik-trafil-do-szpitala-7386980/alternates/LANDSCAPE_1280" />
    Kobiecie grozi do ośmiu lat więzienia.

## Śmierć byłej mistrzyni, podejrzenia padają na męża. "Prawdopodobnie była ciągnięta po drodze"
 - [https://eurosport.tvn24.pl/kolarstwo/rohan-dennis-zwolniony-z-aresztu.-szczegoly-wypadku-w-ktorym-zginela-jego-zona.-co-ustalila-policja-_sto9941186/story.shtml?source=rss](https://eurosport.tvn24.pl/kolarstwo/rohan-dennis-zwolniony-z-aresztu.-szczegoly-wypadku-w-ktorym-zginela-jego-zona.-co-ustalila-policja-_sto9941186/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T09:54:00+00:00

<img alt="Śmierć byłej mistrzyni, podejrzenia padają na męża. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kvt7ad-hoskins-7682826/alternates/LANDSCAPE_1280" />
    "Zdarzenie miały zarejestrować kamery monitoringu" - piszą media.

## Zniszczony dom znanej posłanki. "Dzisiaj wydarzył się mój osobisty horror"
 - [https://tvn24.pl/swiat/ukraina-zniszczony-dom-kiry-rudyk-zdjecia-7682681?source=rss](https://tvn24.pl/swiat/ukraina-zniszczony-dom-kiry-rudyk-zdjecia-7682681?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T09:51:26+00:00

<img alt="Zniszczony dom znanej posłanki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ihfrt2-kira-rudyk-zdjecia-7682631/alternates/LANDSCAPE_1280" />
    Rosjanie przypuścili we wtorek kolejny zmasowany atak rakietowy na Ukrainę.

## Dziewięć zakazów prowadzenia aut to było jeszcze za mało
 - [https://tvn24.pl/tvnwarszawa/okolice/ciechanow-dziewiec-zakazow-prowadzenia-aut-to-bylo-jeszcze-za-malo-st7682753?source=rss](https://tvn24.pl/tvnwarszawa/okolice/ciechanow-dziewiec-zakazow-prowadzenia-aut-to-bylo-jeszcze-za-malo-st7682753?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T09:47:07+00:00

<img alt="Dziewięć zakazów prowadzenia aut to było jeszcze za mało" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uc2kf0-kontrola-drogowa-policja-zdjecie-ilustracyjne-6218727/alternates/LANDSCAPE_1280" />
    Teraz grozi mu ponad siedem lat więzienia.

## Zmarła prof. Małgorzata Kozłowska-Wojciechowska. Widzowie znali ją jako Profesor Zdrówko
 - [https://tvn24.pl/polska/prof-malgorzata-kozlowska-wojciechowska-nie-zyje-pani-profesor-zdrowko-miala-72-lata-7682703?source=rss](https://tvn24.pl/polska/prof-malgorzata-kozlowska-wojciechowska-nie-zyje-pani-profesor-zdrowko-miala-72-lata-7682703?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T09:44:43+00:00

<img alt="Zmarła prof. Małgorzata Kozłowska-Wojciechowska. Widzowie znali ją jako Profesor Zdrówko" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f8aw4m-zmarla-prof-malgorzata-kozlowska-wojciechowska-7682734/alternates/LANDSCAPE_1280" />
    Miała 72 lata.

## Zderzenie samolotów na lotnisku. Pod lupą praca kontrolerów
 - [https://tvn24.pl/swiat/japonia-pozar-samolotu-na-lotnisku-w-tokio-sledczy-badaja-sprawe-7682717?source=rss](https://tvn24.pl/swiat/japonia-pozar-samolotu-na-lotnisku-w-tokio-sledczy-badaja-sprawe-7682717?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T09:30:49+00:00

<img alt="Zderzenie samolotów na lotnisku. Pod lupą praca kontrolerów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uvg5by-japonia-zderzenie-samolotow-7683721/alternates/LANDSCAPE_1280" />
    Na pokładzie samolotu pasażerskiego znajdowało się blisko 400 osób.

## Chcieli "cofnąć się w czasie" i dwa razy świętować Nowy Rok. Ich samolot się spóźnił
 - [https://tvn24.pl/swiat/nowy-rok-chcieli-swietowac-dwa-razy-lot-united-airlines-spoznil-sie-na-podroz-w-czasie-w-sylwestra-7682475?source=rss](https://tvn24.pl/swiat/nowy-rok-chcieli-swietowac-dwa-razy-lot-united-airlines-spoznil-sie-na-podroz-w-czasie-w-sylwestra-7682475?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T09:09:11+00:00

<img alt="Chcieli " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n9u11y-united-airlines-7682512/alternates/LANDSCAPE_1280" />
    Pasażerowie nie kryli rozczarowania.

## Z powodu "żartu" nie poleciał do Dominikany
 - [https://tvn24.pl/tvnwarszawa/wlochy/warszawa-podroz-na-dominikane-pokrzyzowal-mu-nieprzemyslany-zart-o-bombie-w-bagazu-st7682630?source=rss](https://tvn24.pl/tvnwarszawa/wlochy/warszawa-podroz-na-dominikane-pokrzyzowal-mu-nieprzemyslany-zart-o-bombie-w-bagazu-st7682630?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T09:07:13+00:00

<img alt="Z powodu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-tp4v6t-boeing-787-dreamliner-7420300/alternates/LANDSCAPE_1280" />
    Przeprosił, ale było już na to za późno.

## "Silnik i skrzynia biegów upadły 30 metrów od miejsca wypadku". Siedem osób, w tym dwoje dzieci, w szpitalu
 - [https://tvn24.pl/lublin/debowica-siedem-osob-w-szpitalu-po-zderzeniu-dwoch-samochodow-7682533?source=rss](https://tvn24.pl/lublin/debowica-siedem-osob-w-szpitalu-po-zderzeniu-dwoch-samochodow-7682533?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T08:54:22+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-63p395-siedem-osob-w-szpitalu-po-zderzeniu-dwoch-samochodow-7682600/alternates/LANDSCAPE_1280" />
    W Dębowicy (woj. lubelskie).

## Klopp tuż po meczu najadł się strachu. "Wiszę operatorowi mnóstwo kolejek"
 - [https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/juergen-klopp-zgubil-obraczke-po-meczu-z-newcastle-united_sto9941191/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/juergen-klopp-zgubil-obraczke-po-meczu-z-newcastle-united_sto9941191/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T08:35:05+00:00

<img alt="Klopp tuż po meczu najadł się strachu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ch8pqv-juergen-klopp-7682593/alternates/LANDSCAPE_1280" />
    Zabawne sceny po meczu Liverpoolu.

## Najnowsze dane z przemysłu. "Zaskoczył wynikami"
 - [https://tvn24.pl/biznes/z-kraju/wskaznik-pmi-grudzien-2023-najnowsze-dane-z-przemyslu-st7682507?source=rss](https://tvn24.pl/biznes/z-kraju/wskaznik-pmi-grudzien-2023-najnowsze-dane-z-przemyslu-st7682507?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T08:07:53+00:00

<img alt="Najnowsze dane z przemysłu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-388kzq-fabryka-przemysl-shutterstock761907061-5772063/alternates/LANDSCAPE_1280" />
    Wskaźnik PMI dla przemysłu w Polsce.

## Tragedia w Nowy Rok. Z zalewu wyłowiono zwłoki 25-latka
 - [https://tvn24.pl/rzeszow/radawa-z-zalewu-wylowiono-zwloki-25-latka-7682481?source=rss](https://tvn24.pl/rzeszow/radawa-z-zalewu-wylowiono-zwloki-25-latka-7682481?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T08:04:58+00:00

<img alt="Tragedia w Nowy Rok. Z zalewu wyłowiono zwłoki 25-latka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3lq6yk-25-latek-utonal-w-zalewie-w-radawie-woj-podkarpackie-7682482/alternates/LANDSCAPE_1280" />
    W Radawie (woj. podkarpackie).

## Gigant zamyka fabrykę w Polsce. "Został zmontowany ostatni autobus"
 - [https://tvn24.pl/biznes/z-kraju/slupsk-scania-zamyka-fabryke-w-slupsku-zostal-zmontowany-ostatni-autobus-st7682426?source=rss](https://tvn24.pl/biznes/z-kraju/slupsk-scania-zamyka-fabryke-w-slupsku-zostal-zmontowany-ostatni-autobus-st7682426?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T07:53:52+00:00

<img alt="Gigant zamyka fabrykę w Polsce. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wrruh6-shutterstock_1158770821-7150862/alternates/LANDSCAPE_1280" />
    Wpis w mediach społecznościowych.

## Zatrzęsły się samochody i latarnie uliczne. Nagranie
 - [https://tvn24.pl/tvnmeteo/swiat/trzesienie-ziemi-w-japonii-zatrzesly-sie-samochody-i-latarnie-uliczne-nagranie-st7682455?source=rss](https://tvn24.pl/tvnmeteo/swiat/trzesienie-ziemi-w-japonii-zatrzesly-sie-samochody-i-latarnie-uliczne-nagranie-st7682455?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T07:39:13+00:00

<img alt="Zatrzęsły się samochody i latarnie uliczne. Nagranie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ex04dv-moment-trzesienia-uchwycony-w-miescie-toyama-7682495/alternates/LANDSCAPE_1280" />
    Wstrząsy odczuwalne były w wielu prefekturach Japonii.

## Z polskich lotnisk wystartowały dwie pary F-16. Powodem "intensywna aktywność" rosyjskiego lotnictwa
 - [https://tvn24.pl/polska/poderwano-dwie-pary-f-16-powodem-intensywna-aktywnosc-rosyjskiego-lotnictwa-7682472?source=rss](https://tvn24.pl/polska/poderwano-dwie-pary-f-16-powodem-intensywna-aktywnosc-rosyjskiego-lotnictwa-7682472?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T07:25:21+00:00

<img alt="Z polskich lotnisk wystartowały dwie pary F-16. Powodem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kn8fjn-f16-7682471/alternates/LANDSCAPE_1280" />
    Poinformowało we wtorek rano polskie Dowództwo Operacyjne Sił Zbrojnych.

## Co powiedział prezydent na spotkaniu z KRRiT? "Padła propozycja, żeby zrobić krok wstecz"
 - [https://tvn24.pl/polska/zmiany-w-mediach-publicznych-czlonek-krrit-tadeusz-kowalski-o-spotkaniu-z-prezydentem-7682454?source=rss](https://tvn24.pl/polska/zmiany-w-mediach-publicznych-czlonek-krrit-tadeusz-kowalski-o-spotkaniu-z-prezydentem-7682454?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T07:11:30+00:00

<img alt="Co powiedział prezydent na spotkaniu z KRRiT? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bg971w-prezydent1-7653726/alternates/LANDSCAPE_1280" />
    Członek Krajowej Rady Radiofonii i Telewizji Tadeusz Kowalski w "Rozmowie Piaseckiego".

## Dwie osoby aresztowane w związku ze śmiercią lekkoatlety
 - [https://eurosport.tvn24.pl/lekkoatletyka/dwie-osoby-aresztowane-w-zwiazku-ze-smiercia-lekkoatlety_sto9941119/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/dwie-osoby-aresztowane-w-zwiazku-ze-smiercia-lekkoatlety_sto9941119/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T07:04:00+00:00

<img alt="Dwie osoby aresztowane w związku ze śmiercią lekkoatlety" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p2wfp2-benjamin-kiplagat-7682457/alternates/LANDSCAPE_1280" />
    Prawdopodobnie wpadł w zasadzkę.

## Jedna ładowarka do wszystkich telefonów. "Wreszcie się doczekaliśmy"
 - [https://tvn24.pl/biznes/tech/unia-europejska-jedna-ladowarka-do-wszystkich-urzadzen-mobilnych-pierwsze-zmiany-w-2024-roku-st7682416?source=rss](https://tvn24.pl/biznes/tech/unia-europejska-jedna-ladowarka-do-wszystkich-urzadzen-mobilnych-pierwsze-zmiany-w-2024-roku-st7682416?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T06:24:10+00:00

<img alt="Jedna ładowarka do wszystkich telefonów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6v0we4-ladowarka-telefon-prad-4300957/alternates/LANDSCAPE_1280" />
    Zmiany coraz bliżej.

## Zrobi się bardzo niebezpiecznie. Wydano pomarańczowe alerty
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-sniezyce-gololedz-zima-atakuje-w-polsce-gdzie-spadnie-snieg-st7682425?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-sniezyce-gololedz-zima-atakuje-w-polsce-gdzie-spadnie-snieg-st7682425?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T06:15:56+00:00

<img alt="Zrobi się bardzo niebezpiecznie. Wydano pomarańczowe alerty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q2g2ue-intensywne-opady-sniegu-zawieje-zamiecie-7683514/alternates/LANDSCAPE_1280" />
    IMGW ostrzega kilka województw.

## Śnieżyce w czterech województwach, ulewy w części kraju
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-deszczu-roztopy-ostrzezenia-meteorologiczne-st7682425?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-deszczu-roztopy-ostrzezenia-meteorologiczne-st7682425?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T06:15:56+00:00

<img alt="Śnieżyce w czterech województwach, ulewy w części kraju" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8opp2q-intensywne-opady-sniegu-5624324/alternates/LANDSCAPE_1280" />
    IMGW ostrzega.

## Wstrząsy tak silne, że przesunęły ziemię o ponad metr. Rośnie liczba ofiar
 - [https://tvn24.pl/tvnmeteo/swiat/trzesienie-ziemi-w-japonii-rosnie-bilans-ofiar-ogromne-zniszczenia-st7682413?source=rss](https://tvn24.pl/tvnmeteo/swiat/trzesienie-ziemi-w-japonii-rosnie-bilans-ofiar-ogromne-zniszczenia-st7682413?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T05:34:59+00:00

<img alt="Wstrząsy tak silne, że przesunęły ziemię o ponad metr. Rośnie liczba ofiar" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-cahdjx-zniszczenia-po-trzesieniu-ziemi-w-prefekturze-ishikawa-7682412/alternates/LANDSCAPE_1280" />
    Doszło do niego w poniedziałek w Japonii.

## Świątek dogryzła Hurkaczowi. Zabawna sytuacja na konferencji
 - [https://eurosport.tvn24.pl/tenis/united-cup-3/2024/iga-swiatek-i-hubert-hurkacz-na-konferencji-po-meczu-z-hiszpania-w-united-cup-2024-tenis_sto9941137/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/united-cup-3/2024/iga-swiatek-i-hubert-hurkacz-na-konferencji-po-meczu-z-hiszpania-w-united-cup-2024-tenis_sto9941137/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T05:27:54+00:00

<img alt="Świątek dogryzła Hurkaczowi. Zabawna sytuacja na konferencji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gzub5u-hubert-hurkacz-i-iga-swiatek-7682414/alternates/LANDSCAPE_1280" />
    Podczas turnieju w Australii.

## Putin przesłał noworoczne życzenia. Na liście tylko czterech europejskich przywódców
 - [https://tvn24.pl/swiat/tylko-czterech-europejskich-przywodcow-dostalo-noworoczne-zyczenia-od-putina-prezydenci-serbii-i-turcji-papiez-i-premier-wegier-7671360?source=rss](https://tvn24.pl/swiat/tylko-czterech-europejskich-przywodcow-dostalo-noworoczne-zyczenia-od-putina-prezydenci-serbii-i-turcji-papiez-i-premier-wegier-7671360?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T05:25:44+00:00

<img alt="Putin przesłał noworoczne życzenia. Na liście tylko czterech europejskich przywódców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-73osix-wladimir-putin-7670339/alternates/LANDSCAPE_1280" />
    Życzeń nie dostali przywódcy czołowych państw Unii Europejskiej i USA.

## "W 2024 roku środkiem ciężkości wojny będą Krym i Morze Czarne"
 - [https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-w-2024-roku-srodkiem-ciezkosci-wojny-beda-krym-i-morze-czarne-7676201?source=rss](https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-w-2024-roku-srodkiem-ciezkosci-wojny-beda-krym-i-morze-czarne-7676201?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T05:21:06+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dxo7f5-wolodymyr-zelenski-w-kupiansku-w-obwodzie-charkowskim-7462779/alternates/LANDSCAPE_1280" />
    Według Wołodomyra Zełenskiego szybkość osiągnięcia przez Ukrainę sukcesu będzie zależała od pomocy wojskowej.

## Zmasowany ostrzał. W kierunku Kijowa lecą Kindżały
 - [https://tvn24.pl/swiat/ukraina-alarm-powietrzny-na-terenie-calego-kraju-rosyjskie-rakiety-nad-kijowem-7682405?source=rss](https://tvn24.pl/swiat/ukraina-alarm-powietrzny-na-terenie-calego-kraju-rosyjskie-rakiety-nad-kijowem-7682405?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T05:09:13+00:00

<img alt="Zmasowany ostrzał. W kierunku Kijowa lecą Kindżały " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5wchx6-atak-na-kijow-7316647/alternates/LANDSCAPE_1280" />
    Trwa kolejny atak na Ukrainę, alarm w całym kraju.

## O której godzinie kwalifikacje w Innsbrucku?
 - [https://eurosport.tvn24.pl/skoki-narciarskie/innsbruck/2023-2024/skoki-narciarskie-innsbruck-2024-o-ktorej-godzinie-wtorkowe-kwalifikacje-gdzie-ogladac-transmisje_sto9941097/story.shtml?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie/innsbruck/2023-2024/skoki-narciarskie-innsbruck-2024-o-ktorej-godzinie-wtorkowe-kwalifikacje-gdzie-ogladac-transmisje_sto9941097/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T05:04:38+00:00

<img alt="O której godzinie kwalifikacje w Innsbrucku?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eeutj1-kamil-stoch-w-innsbrucku-7682407/alternates/LANDSCAPE_1280" />
    Turniej Czterech Skoczni przenosi się do Austrii.

## Opóźniony dworzec, tramwaj do Wilanowa, zmiany w centrum i plany drogowców
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-opozniony-dworzec-tramwaj-do-wilanowa-zmiany-w-centrum-i-plany-drogowcow-st7654259?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-opozniony-dworzec-tramwaj-do-wilanowa-zmiany-w-centrum-i-plany-drogowcow-st7654259?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T05:00:00+00:00

<img alt="Opóźniony dworzec, tramwaj do Wilanowa, zmiany w centrum i plany drogowców" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-w615se-wizualizacja-mostu-pieszo-rowerowego-5041124/alternates/LANDSCAPE_1280" />
    Planowane jest ukończenie wielu kluczowych inwestycji.

## Izrael przechwytuje rakiety Hamasu. "Nowy rok, ten sam terroryzm"
 - [https://tvn24.pl/swiat/izrael-przechwytuje-rakiety-hamasu-wystrzelone-ze-strefy-gazy-7679001?source=rss](https://tvn24.pl/swiat/izrael-przechwytuje-rakiety-hamasu-wystrzelone-ze-strefy-gazy-7679001?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T04:56:30+00:00

<img alt="Izrael przechwytuje rakiety Hamasu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie22844b477b5305616da98ca093388a72-system-zelazna-kopula-jest-podstawa-izraelskiej-obrony-przeciwrakietowej-3808476/alternates/LANDSCAPE_1280" />
    Wojna pomiędzy Izraelem a Hamasem trwa od 88 dni.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-7677730?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-7677730?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T04:43:32+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jr28x9-szczatki-zniszczonego-drona-7676961/alternates/LANDSCAPE_1280" />
    Rosyjska pełnoskalowa inwazja na Ukrainę trwa od 678 dni.

## Atak nożem na polityka, uchylona ustawa Netanjahu, zamieszki w Belgii i Holandii
 - [https://tvn24.pl/swiat/szesc-rzeczy-ktore-warto-wiedziec-2-stycznia-2024-roku-7682391?source=rss](https://tvn24.pl/swiat/szesc-rzeczy-ktore-warto-wiedziec-2-stycznia-2024-roku-7682391?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T04:41:04+00:00

<img alt="Atak nożem na polityka, uchylona ustawa Netanjahu, zamieszki w Belgii i Holandii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-li9d84-spalone-samochody-w-holandii-7681785/alternates/LANDSCAPE_1280" />
    Sześć rzeczy, które warto wiedzieć 2 stycznia.

## Putin zapowiedział zintensyfikowanie ataków na Ukrainę. Wskazał "główny cel"
 - [https://tvn24.pl/swiat/rosja-wladimir-putin-zapowiedzial-zintensyfikowanie-atakow-na-ukraine-7664961?source=rss](https://tvn24.pl/swiat/rosja-wladimir-putin-zapowiedzial-zintensyfikowanie-atakow-na-ukraine-7664961?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T04:15:26+00:00

<img alt="Putin zapowiedział zintensyfikowanie ataków na Ukrainę. Wskazał " src="https://tvn24.pl/najnowsze/cdn-zdjecie-id1787-wladimir-putin-podczas-wizyty-w-szpitalu-wojskowym-w-moskwie-7664779/alternates/LANDSCAPE_1280" />
    Według prezydenta Rosji sytuacja obraca się na korzyść Moskwy.

## Atak nożownika na lidera południowokoreańskiej opozycji
 - [https://tvn24.pl/swiat/korea-poludniowa-pusan-lider-opozycji-lee-jae-myung-zostal-dzgniety-nozem-w-szyje-7682390?source=rss](https://tvn24.pl/swiat/korea-poludniowa-pusan-lider-opozycji-lee-jae-myung-zostal-dzgniety-nozem-w-szyje-7682390?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-01-02T04:03:57+00:00

<img alt="Atak nożownika na lidera południowokoreańskiej opozycji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x5ojh-lee-jae-myung-zostal-zaatakowany-podczas-konferencji-w-busan-7682398/alternates/LANDSCAPE_1280" />
    Prezydent kraju zapowiedział pilne śledztwo w sprawie zajścia w Busan.

