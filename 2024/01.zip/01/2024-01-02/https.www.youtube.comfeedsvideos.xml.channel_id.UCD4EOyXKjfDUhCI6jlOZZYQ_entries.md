# Source:Eli the Computer Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ, language:en-US

## Training the ANTI LOUIS Robot…
 - [https://www.youtube.com/watch?v=QexxsYrzorc](https://www.youtube.com/watch?v=QexxsYrzorc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ
 - date published: 2024-01-02T15:22:33+00:00



