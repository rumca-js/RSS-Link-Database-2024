# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## PW1: Two hats for productivity
 - [https://seths.blog/2024/01/pw1-two-hats-for-productivity](https://seths.blog/2024/01/pw1-two-hats-for-productivity)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-01-02T09:54:00+00:00

Welcome to 2024. Back to work, here we go. So it&#8217;s Productivity Week on the blog. Productivity is the measure of the output (value) we get for the time or money we spend. Two hats for productivity: When I&#8217;m clearing my inbox, responding to comments in a doc, cooking lunch&#8211;these are chores. Chores are the [&#8230;]

