# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## USA Boxing Allows Men To Fight Women With New Transgender Guidelines
 - [https://www.dailywire.com/news/usa-boxing-allows-men-to-fight-women-with-new-transgender-guidelines](https://www.dailywire.com/news/usa-boxing-allows-men-to-fight-women-with-new-transgender-guidelines)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T18:23:57+00:00

USA Boxing on Friday officially adopted a new transgender policy, which will permit males who identify as female to compete against females if they meet certain qualifications. The new policy was first proposed in August 2022, as highlighted by National Review, and outlines that male athletes, in addition to claiming to be female, must complete ...

## ‘Sound of Freedom’ Beats Taylor Swift To Finish In Top Ten At 2023 Domestic Box Office
 - [https://www.dailywire.com/news/sound-of-freedom-beats-taylor-swift-to-finish-in-top-ten-at-2023-domestic-box-office](https://www.dailywire.com/news/sound-of-freedom-beats-taylor-swift-to-finish-in-top-ten-at-2023-domestic-box-office)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T18:13:19+00:00

&#8220;Sound of Freedom&#8221; beat out Taylor Swift&#8217;s &#8220;The Eras Tour&#8221; movie to finish in the top ten of 2023 box office tallies domestically. The independent film from Angel Studios, which deals with the horrors of human trafficking, made it into the top ten grossing films of the year domestically after earning $184,177,725 by the end ...

## Dem Senator Stalls Bill Sanctioning Iranian Regime
 - [https://www.dailywire.com/news/dem-senator-stalls-bill-sanctioning-iranian-regime](https://www.dailywire.com/news/dem-senator-stalls-bill-sanctioning-iranian-regime)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T18:09:30+00:00

A Maryland Democrat senator prompted anger from Iranian dissidents opposed to the theocratic despotic Iranian regime when he informed them he would stall a bill sanctioning the leaders of the Iranian government for decades of human rights abuses. Senator Ben Cardin (D-MD), who chairs the Senate Foreign Relations Committee, sent a December 21 email saying ...

## Freed Israeli Hostage Says There Is Only One Reason Her Hamas Captor Did Not Rape Her
 - [https://www.dailywire.com/news/freed-israeli-hostage-says-there-is-only-one-reason-her-hamas-captor-did-not-rape-her](https://www.dailywire.com/news/freed-israeli-hostage-says-there-is-only-one-reason-her-hamas-captor-did-not-rape-her)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T18:03:19+00:00

Recently-freed French-Israeli hostage Mia Schem said after her release that she only survived 54 days without being raped by her Hamas captor because his wife and children were in the same house, often just outside the room where she was kept. Schem, a tattoo artist who holds dual citizenship in both France and Israel, was ...

## Kentucky Clerk Who Refused To Issue Licenses Following SCOTUS Gay Marriage Ruling Must Pay Over $260K In Fees, Judge Rules
 - [https://www.dailywire.com/news/kentucky-clerk-who-refused-to-issue-licenses-following-scotus-gay-marriage-ruling-must-pay-over-260k-in-fees-judge-rules](https://www.dailywire.com/news/kentucky-clerk-who-refused-to-issue-licenses-following-scotus-gay-marriage-ruling-must-pay-over-260k-in-fees-judge-rules)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T17:42:47+00:00

Kim Davis, the former Kentucky clerk who refused to issue marriage licenses after the Supreme Court&#8217;s landmark decision in 2015 on gay marriage, must pay $260,104 in fees to attorneys who represented a couple, a federal judge ruled Tuesday. Despite Davis’ attorneys arguing that the fee request by the same-sex couple’s lawyers was excessive, U.S. ...

## Karine Jean-Pierre Says It’s ‘Shameful’ To Send Illegal Immigrants To Self-Described ‘Sanctuary Cities’
 - [https://www.dailywire.com/news/karine-jean-pierre-says-its-shameful-to-send-illegal-immigrants-to-self-described-sanctuary-cities](https://www.dailywire.com/news/karine-jean-pierre-says-its-shameful-to-send-illegal-immigrants-to-self-described-sanctuary-cities)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T17:25:19+00:00

White House Press Secretary Karine Jean-Pierre complained on Tuesday that it was &#8220;shameful&#8221; for the governors of border states to transport illegal immigrants to cities and states that have declared themselves &#8220;sanctuary&#8221; jurisdictions. Jean-Pierre made the comments during an appearance on CNN as she kicked off 2024 from the White House: &#8220;The busing of migrants, ...

## Charlamagne Tha God Taps Out After Kamala Harris ‘Kind Of Disappeared’
 - [https://www.dailywire.com/news/charlamagne-tha-god-taps-out-after-kamala-harris-kind-of-disappeared](https://www.dailywire.com/news/charlamagne-tha-god-taps-out-after-kamala-harris-kind-of-disappeared)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T17:16:31+00:00

A prominent black radio show personality reportedly feels &#8220;burned&#8221; over his past support of Vice President Kamala Harris. Charlamagne tha God, the co-host of &#8220;The Breakfast Club&#8221; who was born Lenard Larry McKelvey, spoke to POLITICO about his break with Harris after her nearly three years in the White House. &#8220;I’ve learned my lesson from ...

## Another Cowardly Republican Governor Caves To The Trans Agenda
 - [https://www.dailywire.com/news/another-cowardly-republican-governor-caves-to-the-trans-agenda](https://www.dailywire.com/news/another-cowardly-republican-governor-caves-to-the-trans-agenda)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T17:15:47+00:00

It used to be that senior officers in the U.S. military made a point of staying out of politics. At least in public, they focused their attention solely on foreign enemies who could threaten the United States. George Marshall, the Army officer who became secretary of defense under Truman, famously refused to vote in any ...

## New York Man Drove Car Containing Gasoline Canisters Into Uber At Concert Killing Two, Left Suicide Note
 - [https://www.dailywire.com/news/new-york-man-drove-car-containing-gasoline-canisters-into-uber-at-concert-killing-two-left-suicide-note](https://www.dailywire.com/news/new-york-man-drove-car-containing-gasoline-canisters-into-uber-at-concert-killing-two-left-suicide-note)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T17:14:40+00:00

A suspected &#8220;emotionally disturbed&#8221; New York man crashed a car into an Uber leaving a concert in Rochester on New Year&#8217;s Eve, leaving two dead and more injured. At around 12:50 a.m., Michael Avery, 35, from Syracuse, drove a rented Ford Expedition, a large SUV, toward a crowd leaving a rock concert by the band ...

## ‘Aquaman’ Sequel Continues To Flail At Box Office; ‘Wonka’ Wins
 - [https://www.dailywire.com/news/aquaman-sequel-continues-to-flail-at-box-office-wonka-wins](https://www.dailywire.com/news/aquaman-sequel-continues-to-flail-at-box-office-wonka-wins)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T17:12:25+00:00

The &#8220;Aquaman&#8220; sequel continues to struggle as Warner Bros. &#8220;Wonka&#8221; has not only dominated the Christmas box office, but now the New Year weekend as well. &#8220;Aquaman and the Lost Kingdom&#8221; has earned, as of New Year&#8217;s Day, $81.8 million. The original 2018 film made $215.4 million over the same time period as it was ...

## ‘Clearly A Witch Hunt’: Lefties Blame ‘Racism’ For Ouster Of Allegedly Plagiarizing Harvard Prez
 - [https://www.dailywire.com/news/clearly-a-witch-hunt-lefties-blame-racism-for-ouster-of-allegedly-plagiarizing-harvard-prez](https://www.dailywire.com/news/clearly-a-witch-hunt-lefties-blame-racism-for-ouster-of-allegedly-plagiarizing-harvard-prez)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T16:51:45+00:00

Embattled Harvard President Claudine Gay resigned on Tuesday, and many on the Left were quick to claim that her abrupt exit was clearly the result of racism. Gay&#8217;s resignation came after she faced multiple accusations of plagiarism — and in the wake of her disastrous Capitol Hill testimony on campus anti-Semitism — which led to ...

## Hundreds More Migrants Dropped Off In Chicago, New Jersey, Denver As Year Ended
 - [https://www.dailywire.com/news/hundreds-more-migrants-dropped-off-in-chicago-new-jersey-denver-as-year-ended](https://www.dailywire.com/news/hundreds-more-migrants-dropped-off-in-chicago-new-jersey-denver-as-year-ended)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T16:26:48+00:00

Hundreds of new migrants were dropped off near major cities as the year came to a close this week, a symptom of the ongoing migrant crisis at the border. In New Jersey, some bus operators figured out a &#8220;loophole&#8221; in New York City&#8217;s new migrant restrictions and started dropping migrants off at New Jersey train ...

## Biden Fiddles While The World Burns
 - [https://www.dailywire.com/news/biden-fiddles-while-the-world-burns](https://www.dailywire.com/news/biden-fiddles-while-the-world-burns)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T16:19:06+00:00

Historian Niall Ferguson says, “It will seem obvious that by 2033, if not sooner, that the pax americana—” the idea of an American hegemony dominating the globe — “faced a well-coordinated challenge from China, Russia, Iran and North Korea in the early 2020s.” Future historians will marvel at all this. It will seem obvious by ...

## ESPN Issues Apology After Showing Woman’s Bare Breast During Football Broadcast
 - [https://www.dailywire.com/news/espn-issues-apology-after-showing-womans-bare-breast-during-football-broadcast](https://www.dailywire.com/news/espn-issues-apology-after-showing-womans-bare-breast-during-football-broadcast)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T15:42:02+00:00

ESPN has issued an apology after showing a woman who flashed her bare right breast during coverage of the Sugar Bowl on Monday night in New Orleans. It happened during the broadcast of the college football semifinals between the Washington Huskies and Texas Longhorns when the network went to a shot from Bourbon Street. In ...

## Major Players In Harvard Controversy Sound Off On Gay’s Resignation
 - [https://www.dailywire.com/news/major-players-in-harvard-controversy-sound-off-on-gays-resignation](https://www.dailywire.com/news/major-players-in-harvard-controversy-sound-off-on-gays-resignation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T15:35:29+00:00

Harvard University President Claudine Gay&#8217;s resignation on Tuesday prompted a wave of approving statements from people who figured prominently in the uproar that led to her exit. After weeks of backlash over her testimony to Congress regarding anti-Semitism on campus and plagiarism allegations levied at her academic work, Gay announced her decision to step down ...

## Michigan And Washington Set The Stage For An Epic CFP National Championship Showdown
 - [https://www.dailywire.com/news/michigan-and-washington-set-the-stage-for-an-epic-cfp-national-championship-showdown](https://www.dailywire.com/news/michigan-and-washington-set-the-stage-for-an-epic-cfp-national-championship-showdown)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T15:35:26+00:00

The following is adapted from “Crain &amp; Co.,”  January 2, 2024.  Jake Crain: As the final play ended in the Alabama/Michigan game last night in overtime, Wolverine fans rejoiced at finally winning a playoff game, albeit in a fashion that definitely took some years off their lives. But make no mistake, this core in-group did ...

## Top Hamas Leader Killed In Lebanon Blast
 - [https://www.dailywire.com/news/top-hamas-leader-killed-in-lebanon-blast](https://www.dailywire.com/news/top-hamas-leader-killed-in-lebanon-blast)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T14:14:55+00:00

Senior Hamas leader Saleh Arouri was killed by a strike in Beirut on Tuesday, an attack that Lebanese officials pinned on Israel. Lebanese state media claimed several people perished in the blast carried out by an Israeli drone, The Associated Press reported. Officials with Hamas and Hezbollah said Arouri was among the dead. Israel had ...

## A Chinese Foreign Exchange Student Disappeared. He Was Just Found In A ‘Cyber Kidnapping’
 - [https://www.dailywire.com/news/a-chinese-foreign-exchange-student-disappeared-he-was-just-found-in-a-cyber-kidnapping](https://www.dailywire.com/news/a-chinese-foreign-exchange-student-disappeared-he-was-just-found-in-a-cyber-kidnapping)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T14:09:17+00:00

A 17-year-old Chinese foreign exchange student who was reported missing last week has been found alive, with police saying he was the victim of a “cyber kidnapping.” Kai Zhuang had been staying with a host family in Riverdale, Utah, when he disappeared last week, ABC4 reported. The host family reportedly told police that Zhuang had ...

## Trump To Skip CNN GOP Debate, Participate In Fox News Town Hall Scheduled For Same Time
 - [https://www.dailywire.com/news/trump-to-skip-cnn-gop-debate-participate-in-fox-news-town-hall-scheduled-for-same-time](https://www.dailywire.com/news/trump-to-skip-cnn-gop-debate-participate-in-fox-news-town-hall-scheduled-for-same-time)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T13:46:37+00:00

Former President Donald Trump, the frontrunner for the GOP presidential nomination, will skip a fifth Republican primary debate, opting to participate in a Fox News town hall scheduled for the same time on January 10.  The Fox News town hall, moderated by hosts Bret Baier and Martha MacCallum, will take place in Des Moines, Iowa, ...

## Marvel Actress Struck By Car In NYC, Family Shares Graphic Photos Of Injuries
 - [https://www.dailywire.com/news/marvel-actress-struck-by-car-in-nyc-family-shares-graphic-photos-of-injuries](https://www.dailywire.com/news/marvel-actress-struck-by-car-in-nyc-family-shares-graphic-photos-of-injuries)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T13:42:20+00:00

Actress Carrie Bernans’ family shared graphic photos of injuries she sustained from a mass casualty incident while celebrating New Year’s Eve in Midtown Manhattan. The 29-year-old was walking with a friend near West 34th Street and 9th Avenue following the ball drop in Times Square when a man in a car rammed into a food ...

## WATCH: Anti-Israel Customer Freaks Out At Blue And White McDonalds Wrapper; Gets Dragged Online
 - [https://www.dailywire.com/news/watch-anti-israel-customer-freaks-out-at-blue-and-white-mcdonalds-wrapper-gets-dragged-online](https://www.dailywire.com/news/watch-anti-israel-customer-freaks-out-at-blue-and-white-mcdonalds-wrapper-gets-dragged-online)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T13:35:10+00:00

In a video that is making the rounds on social media, a customer videotaped herself harassing a McDonald’s employee after her sandwich came in a blue and white wrapper, accusing McDonald’s of supporting Israel and calling it “disgusting.” “So I was starving, so I had to get one quick sandwich from here, and I thought ...

## Claudine Gay Resigns As Harvard President, Claims ‘Racial Animus’ Fueled Criticism
 - [https://www.dailywire.com/news/claudine-gay-to-resign-as-harvard-president-report](https://www.dailywire.com/news/claudine-gay-to-resign-as-harvard-president-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T13:24:45+00:00

Claudine Gay resigned as president of Harvard University on Tuesday in a letter to the university community, as first reported by the Harvard Crimson. Gay&#8217;s reported resignation comes in the wake of numerous plagiarism allegations as well as her controversial congressional testimony on what Harvard is doing to combat anti-Semitism on campus after Hamas&#8217; attack ...

## An Olympic Cyclist Died, And Now Her Husband Has Been Charged With Her Death
 - [https://www.dailywire.com/news/an-olympic-cyclist-died-and-now-her-husband-has-been-charged-with-her-death](https://www.dailywire.com/news/an-olympic-cyclist-died-and-now-her-husband-has-been-charged-with-her-death)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T12:43:20+00:00

An Australian former Olympic track cyclist died just before the new year after being hit by a vehicle driven by her husband, who has now been charged in connection to her death. Melissa Hoskins, 32, died Saturday in Adelaide, Australia, after she reportedly jumped onto the hood of a $50,000 Volkswagen driven by her husband, ...

## Death Toll Rises After Japan Earthquake As Rescuers Rush To Find Survivors
 - [https://www.dailywire.com/news/death-toll-rises-after-japan-earthquake-as-rescuers-rush-to-find-survivors](https://www.dailywire.com/news/death-toll-rises-after-japan-earthquake-as-rescuers-rush-to-find-survivors)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T12:38:02+00:00

Dozens of people have been confirmed dead in Japan as rescuers continue to search for survivors after a 7.6 magnitude earthquake rocked Japan on New Year’s Day.  Authorities in Japan’s Ishikawa Prefecture, the nearest region to the quake’s epicenter, confirmed that at least 48 people had died in the disaster, Tokyo-based news outlet NHK reported. ...

## Shipping Giant Maersk Suspends Red Sea Transits ‘Until Further Notice’ After Houthi Attack
 - [https://www.dailywire.com/news/shipping-giant-maersk-suspends-red-sea-transits-until-further-notice-after-houthi-attack](https://www.dailywire.com/news/shipping-giant-maersk-suspends-red-sea-transits-until-further-notice-after-houthi-attack)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T12:36:48+00:00

Cargo shipping giant Maersk announced on Tuesday a pause of transits through the Red Sea &#8220;until further notice&#8221; after one of its container vessels got attacked over the weekend by what the United States identified as Iranian-backed Houthi boats. In a statement, the Danish company noted trips through the nearby Gulf of Aden would also ...

## Iran Warship Enters Red Sea After U.S. Sinks Attempted Houthi Hijackers: Report
 - [https://www.dailywire.com/news/iran-warship-enters-red-sea-after-u-s-sinks-attempted-houthi-hijackers-report](https://www.dailywire.com/news/iran-warship-enters-red-sea-after-u-s-sinks-attempted-houthi-hijackers-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T12:17:32+00:00

Iran moved a warship into the Red Sea after the U.S. military destroyed three boats belonging to the Iran-backed Houthi militant group, according to Iranian state media. The Houthis have launched dozens of drones and missiles above the Red Sea near the Bab El-Mandeb strait in recent weeks. The militant group, formerly recognized by the ...

## ‘Beverly Hills, 90210’ Actor Details ‘Alarming’ Road Rage Attack In LA, Begs For ‘Law Enforcement Response’
 - [https://www.dailywire.com/news/beverly-hills-90210-actor-details-alarming-road-rage-attack-in-la-begs-for-law-enforcement-response](https://www.dailywire.com/news/beverly-hills-90210-actor-details-alarming-road-rage-attack-in-la-begs-for-law-enforcement-response)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T12:04:10+00:00

“Beverly Hills, 90210” actor Ian Ziering said an “alarming” incident which he said occurred in downtown Los Angeles on New Year’s Day had him wishing for increased law enforcement protection in the area. “Yesterday, I experienced an alarming incident involving a group of individuals on mini bikes. While stuck in traffic, my car was approached ...

## Anti-Israel Protesters Create Chaos, Delay Flights At JFK Airport On New Year’s Day
 - [https://www.dailywire.com/news/anti-israel-protesters-create-chaos-delay-flights-at-jfk-airport-on-new-years-day](https://www.dailywire.com/news/anti-israel-protesters-create-chaos-delay-flights-at-jfk-airport-on-new-years-day)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T12:02:44+00:00

Dozens of anti-Israel protesters wrought havoc at one of the busiest airports in the U.S. on Monday, blocking traffic and chanting anti-Israel slogans from their vehicles. The anti-Israeli demonstrators launched their “Flood JFK For Gaza” demonstration, forcing police to temporarily block off the Belt Parkway, a prime route to JFK. On Monday, 60 flights were ...

## No. 2 House Republican Scalise Endorses Trump
 - [https://www.dailywire.com/news/no-2-house-republican-scalise-endorses-trump](https://www.dailywire.com/news/no-2-house-republican-scalise-endorses-trump)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T11:35:24+00:00

Starting the new year, the second-ranked Republican in the House endorsed former President Donald Trump in the 2024 election. House Majority Leader Steve Scalise (R-LA) announced his stance on Tuesday, two weeks before Iowa GOP caucuses kick off the primary season, as Trump continues to dominate in the polls. &#8220;I am proud to endorse Donald ...

## Mickey Mouse Horror Film Announced As ‘Steamboat Willie’ Enters Public Domain
 - [https://www.dailywire.com/news/mickey-mouse-horror-film-announced-as-steamboat-willie-enters-public-domain](https://www.dailywire.com/news/mickey-mouse-horror-film-announced-as-steamboat-willie-enters-public-domain)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T11:33:19+00:00

A new horror movie featuring the “Steamboat Willie” version of Mickey Mouse is currently in the works, per a Variety report. Disney&#8217;s copyright to “Steamboat Willie” expired Monday, along with its right to the original versions of Mickey and Minnie Mouse, though the company still holds copyrights for more modern versions of these iconic characters. ...

## Elon Musk Mocks Green Day For Anti-MAGA Lyrics During NYE Performance
 - [https://www.dailywire.com/news/elon-musk-mocks-green-day-for-anti-maga-lyrics-during-nye-performance](https://www.dailywire.com/news/elon-musk-mocks-green-day-for-anti-maga-lyrics-during-nye-performance)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T10:41:04+00:00

Alternative rock band Green Day faced backlash for their anti-MAGA lyrics change during a New Year’s Eve performance, and now Tesla CEO Elon Musk is weighing in on the debate. &#8220;Green Day goes from raging against the machine to milquetoastedly raging for it,&#8221; the billionaire entrepreneur shared in an X post on Sunday evening, adding ...

## Harvard’s Gay Accused Of 6 More Instances Of Plagiarism In New Complaint
 - [https://www.dailywire.com/news/harvards-gay-accused-of-6-more-instances-of-plagiarism-in-new-complaint](https://www.dailywire.com/news/harvards-gay-accused-of-6-more-instances-of-plagiarism-in-new-complaint)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T10:38:20+00:00

The number of plagiarism accusations facing Harvard President Claudine Gay rose to nearly 50 on Monday after six more examples of alleged lifted and uncited content were brought to light. In an amended complaint filed with the university, another of Gay’s past works, previously thought to be free of controversy, was allegedly found to include ...

## South Korean Opposition Leader Stabbed In The Neck
 - [https://www.dailywire.com/news/south-korean-opposition-leader-stabbed-in-the-neck](https://www.dailywire.com/news/south-korean-opposition-leader-stabbed-in-the-neck)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T10:19:06+00:00

The leader of the South Korean liberal Democratic Party, who lost in the country’s last presidential election, was stabbed in the neck while walking through a crowd Tuesday morning.  Lee Jae-myung, 59, had just toured the site of a planned airport and finished taking questions from journalists when a man approached him and asked for ...

## 5 Detained In Suspected Islamic Terror Plot To Blow Up Cathedral
 - [https://www.dailywire.com/news/5-detained-in-suspected-islamic-terror-plot-to-blow-up-cathedral](https://www.dailywire.com/news/5-detained-in-suspected-islamic-terror-plot-to-blow-up-cathedral)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T10:17:27+00:00

German authorities have detained five individuals over a suspected Islamic terror plot to blow up the Cologne Cathedral on New Year’s Eve.  Police detained a 30-year-old Tajik man in connection with the alleged plan last week, which authorities say was going to involve an attack on the historic church involving car bombs. On Sunday, police ...

## Plane Carrying 379 People Catches On Fire After Runway Crash In Tokyo
 - [https://www.dailywire.com/news/plane-carrying-379-people-catches-on-fire-after-runway-crash-in-tokyo](https://www.dailywire.com/news/plane-carrying-379-people-catches-on-fire-after-runway-crash-in-tokyo)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T08:27:37+00:00

A passenger plane carrying nearly 400 people burst into flames after a suspected collision with a Japanese Coast Guard plane in Tokyo on Tuesday.   All 379 passengers and crew onboard the passenger plane were able to evacuate safely as the plane burned, but five of the six passengers onboard the Coast Guard plane died ...

## California Schools Push Kids To Watch Films On Transgenderism That Showcase Puberty Blockers
 - [https://www.dailywire.com/news/california-schools-push-kids-to-watch-films-on-transgenderism-that-showcase-puberty-blockers](https://www.dailywire.com/news/california-schools-push-kids-to-watch-films-on-transgenderism-that-showcase-puberty-blockers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2024-01-02T08:25:51+00:00

A California school district that serves thousands of students from preschool through high school created elaborate lesson plans and resource lists aimed at pushing gender theory and normalizing child transgenderism, according to documents reviewed by The Daily Wire. Hayward Unified School District (HUSD), which is located in California’s Bay Area and serves over 19,000 students ...

