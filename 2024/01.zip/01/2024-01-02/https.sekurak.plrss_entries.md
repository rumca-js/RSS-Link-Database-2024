# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Grupa Helion podsumowuje topowe ebooki i kursy o bezpieczeństwie w roku 2023
 - [https://sekurak.pl/grupa-helion-podsumowuje-topowe-ebooki-i-kursy-o-bezpieczenstwie-w-roku-2023](https://sekurak.pl/grupa-helion-podsumowuje-topowe-ebooki-i-kursy-o-bezpieczenstwie-w-roku-2023)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2024-01-02T22:31:37+00:00

<p>Koniec starego roku i początek nowego, to zazwyczaj czas na podsumowania. Nie da się ukryć, że w ostatnim czasie temat cyberbezpieczeństwa staje się coraz bardziej popularny, i jest to istotny aspekt życia dla coraz większej liczby ludzi. Są to zarówno prywatni użytkownicy, szukający praktycznych informacji o tym, jak skutecznie chronić...</p>
<p>Artykuł <a href="https://sekurak.pl/grupa-helion-podsumowuje-topowe-ebooki-i-kursy-o-bezpieczenstwie-w-roku-2023/" rel="nofollow">Grupa Helion podsumowuje topowe ebooki i kursy o bezpieczeństwie w roku 2023</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Ukraińska policja najechała ukraińskie centra telefoniczne. Podszywali się m.in. pod konsultantów z banku.
 - [https://sekurak.pl/ukrainska-policja-najechala-ukrainskie-centra-telefoniczne-podszywali-sie-m-in-pod-konsultantow-z-banku](https://sekurak.pl/ukrainska-policja-najechala-ukrainskie-centra-telefoniczne-podszywali-sie-m-in-pod-konsultantow-z-banku)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2024-01-02T08:42:09+00:00

<p>W wyniku działań policji namierzone zostały scam-centra aż w 16 regionach Ukrainy: W ramach operacji wykonano około 150 przeszukań i skonfiskowano ~4000 jednostek rozmaitego sprzętu IT/telefonów. Służby szacują że w scam-procederze brało udział około 2500 osób &#8211; 50-200 per dana regionalna jednostka&#8230; Film z akcji: ~ms</p>
<p>Artykuł <a href="https://sekurak.pl/ukrainska-policja-najechala-ukrainskie-centra-telefoniczne-podszywali-sie-m-in-pod-konsultantow-z-banku/" rel="nofollow">Ukraińska policja najechała ukraińskie centra telefoniczne. Podszywali się m.in. pod konsultantów z banku.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

