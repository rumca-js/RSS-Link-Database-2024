# Source:Colombia News | Colombia Reports, URL:https://colombiareports.com/feed/, language:en-US

## Deadly violence against Colombia’s leaders remained high in 2023
 - [https://colombiareports.com/deadly-violence-against-colombias-leaders-remained-high-in-2023](https://colombiareports.com/deadly-violence-against-colombias-leaders-remained-high-in-2023)
 - RSS feed: https://colombiareports.com/feed/
 - date published: 2024-01-02T14:31:38+00:00

<p>Deadly violence targeting Colombia&#8217;s human rights defenders and community leaders maintained in 2023, according to data by think tank Indepaz. According to the non-governmental organization, 188 social leaders were assassinated&#8230;</p>
<p>The post <a href="https://colombiareports.com/deadly-violence-against-colombias-leaders-remained-high-in-2023/" rel="nofollow">Deadly violence against Colombia&#8217;s leaders remained high in 2023</a> appeared first on <a href="https://colombiareports.com" rel="nofollow">Colombia News | Colombia Reports</a>.</p>

