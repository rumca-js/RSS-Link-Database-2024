# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## The state of WoW going into 2024: Blizzard had to deliver the best year ever for World of Warcraft, and it did
 - [https://www.pcgamer.com/state-of-wow-2024-world-of-warcrafts-best-year-ever](https://www.pcgamer.com/state-of-wow-2024-world-of-warcrafts-best-year-ever)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T22:35:34+00:00

Dragonflight’s roaring success (and Classic's staying power) saved the 20-year-old MMO.

## Baldur's Gate 3 completes its Game of the Year sweep with top honor in the 2023 Steam Awards
 - [https://www.pcgamer.com/baldurs-gate-3-completes-its-game-of-the-year-sweep-with-top-honor-in-the-2023-steam-awards](https://www.pcgamer.com/baldurs-gate-3-completes-its-game-of-the-year-sweep-with-top-honor-in-the-2023-steam-awards)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T22:31:17+00:00

Larian's monster RPG wins again.

## Disney says Star Wars Outlaws coming 'late this year,' then quickly takes it back
 - [https://www.pcgamer.com/disney-says-star-wars-outlaws-coming-late-this-year-then-quickly-takes-it-back](https://www.pcgamer.com/disney-says-star-wars-outlaws-coming-late-this-year-then-quickly-takes-it-back)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T22:05:35+00:00

Ubisoft says the blog post calling for a late 2024 arrival for its Star Wars heist game was a mistake.

## Mickey Mouse has been in the public domain for under 48 hours and there's already a horror game and 2 horror movies on the way
 - [https://www.pcgamer.com/mickey-mouse-horror-game-public-domain](https://www.pcgamer.com/mickey-mouse-horror-game-public-domain)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T21:34:33+00:00

The Steamboat Willie version of Mickey Mouse has finally escaped copyright protection—so here come the horror adaptations.

## The Sinking City legal battle ends with victory for Frogwares, new version of the game 'coming soon'
 - [https://www.pcgamer.com/the-sinking-city-legal-battle-ends-with-victory-for-frogwares-new-version-of-the-game-coming-soon](https://www.pcgamer.com/the-sinking-city-legal-battle-ends-with-victory-for-frogwares-new-version-of-the-game-coming-soon)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T19:57:31+00:00

After a long battle with Nacon, Frogwares is now "the sole publisher" of the 2019 Lovecraft-inspired adventure.

## 20 hidden gems from 2023 to grab before the end of the Steam Winter Sale
 - [https://www.pcgamer.com/steam-winter-sale-2023-hidden-gems](https://www.pcgamer.com/steam-winter-sale-2023-hidden-gems)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T19:46:55+00:00

Underrated, under played games from 2023 that are at least 20% off in Steam's biggest sale of the year.

## 'If [money] is an issue, pirate it and buy a copy later': the devs of our favourite surprise horror hit want you to play it spoiler free—by any means necessary
 - [https://www.pcgamer.com/if-money-is-an-issue-pirate-it-and-buy-a-copy-later-the-devs-of-our-favourite-surprise-horror-hit-want-you-to-play-it-spoiler-freeby-any-means-necessary](https://www.pcgamer.com/if-money-is-an-issue-pirate-it-and-buy-a-copy-later-the-devs-of-our-favourite-surprise-horror-hit-want-you-to-play-it-spoiler-freeby-any-means-necessary)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T18:14:53+00:00

Slay, don't stream, the Princess.

## Popular Slay the Spire mod hacked to deliver malware on Christmas Day
 - [https://www.pcgamer.com/popular-slay-the-spire-mod-hacked-to-deliver-malware-on-christmas-day](https://www.pcgamer.com/popular-slay-the-spire-mod-hacked-to-deliver-malware-on-christmas-day)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T18:13:33+00:00

Get on the naughty list.

## LG is set to unveil a tube-driven transparent OLED 'DukeBox' at CES and be still my beating heart
 - [https://www.pcgamer.com/lg-is-set-to-unveil-a-tube-driven-transparent-oled-dukebox-at-ces-and-be-still-my-beating-heart](https://www.pcgamer.com/lg-is-set-to-unveil-a-tube-driven-transparent-oled-dukebox-at-ces-and-be-still-my-beating-heart)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T17:35:43+00:00

It sure is purty, but given all that glass practicality may stand in the way of beauty.

## OBSBot Tiny 2 review
 - [https://www.pcgamer.com/obsbot-tiny-2-webcam-review](https://www.pcgamer.com/obsbot-tiny-2-webcam-review)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T17:29:22+00:00

The rise of the machines is here with this powerful AI powered webcam that follows you around.

## AI chatbots trained to jailbreak other chatbots, as the AI war slowly but surely begins
 - [https://www.pcgamer.com/ai-chatbots-trained-to-jailbreak-other-chatbots-as-the-ai-war-slowly-but-surely-begins](https://www.pcgamer.com/ai-chatbots-trained-to-jailbreak-other-chatbots-as-the-ai-war-slowly-but-surely-begins)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T17:15:42+00:00

Yep, it sure is turtles all the way down.

## All the movies and TV shows based on videogames coming in 2024
 - [https://www.pcgamer.com/video-game-movies-tv-shows-2024](https://www.pcgamer.com/video-game-movies-tv-shows-2024)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T16:13:37+00:00

Fallout, Borderlands, Tomb Raider, Halo, an Ark cartoon, and Sonic (times two) will hit screens big and small this year.

## Matt Colville's indie RPG, a direct challenge to D&D's jack-of-all-trades fumbling, has earned nearly $4 million on Kickstarter
 - [https://www.pcgamer.com/matt-colvilles-indie-rpg-a-direct-challenge-to-dandds-jack-of-all-trades-fumbling-has-earned-nearly-dollar4-million-on-kickstarter](https://www.pcgamer.com/matt-colvilles-indie-rpg-a-direct-challenge-to-dandds-jack-of-all-trades-fumbling-has-earned-nearly-dollar4-million-on-kickstarter)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T16:07:10+00:00

The MCDM RPG wants to be "unburdened by sacred cows from the 1970s".

## Steam's 2023 GOTY nominations are extremely weird, and I guess that's your fault
 - [https://www.pcgamer.com/steams-2023-goty-nominations-are-extremely-weird-and-i-guess-thats-your-fault](https://www.pcgamer.com/steams-2023-goty-nominations-are-extremely-weird-and-i-guess-thats-your-fault)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T15:47:02+00:00

Maybe democracy doesn't work after all.

## I am begging Discord to stop bombarding me with pointless new features
 - [https://www.pcgamer.com/i-am-begging-discord-to-stop-bombarding-me-with-pointless-new-features](https://www.pcgamer.com/i-am-begging-discord-to-stop-bombarding-me-with-pointless-new-features)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T15:00:06+00:00

2023 has really strained my relationship with my favourite social platform.

## Square Enix's new years resolution is to become 'aggressive in applying AI', and I'm very tired
 - [https://www.pcgamer.com/square-enixs-new-years-resolution-is-to-become-aggressive-in-applying-ai-and-im-very-tired](https://www.pcgamer.com/square-enixs-new-years-resolution-is-to-become-aggressive-in-applying-ai-and-im-very-tired)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T14:33:55+00:00

The focus on the controversial tech was outlined in a letter from company president Takashi Kiryu.

## Monster Hunter: World just hit its highest concurrent player count in over 3 years
 - [https://www.pcgamer.com/monster-hunter-world-just-hit-its-highest-concurrent-player-count-in-over-3-years](https://www.pcgamer.com/monster-hunter-world-just-hit-its-highest-concurrent-player-count-in-over-3-years)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T12:16:47+00:00

Returning to the hunt.

## Starfield enters 2024 with 'Mostly Negative' recent reviews on Steam
 - [https://www.pcgamer.com/starfield-enters-2024-with-mostly-negative-recent-reviews-on-steam](https://www.pcgamer.com/starfield-enters-2024-with-mostly-negative-recent-reviews-on-steam)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T12:06:18+00:00

Something's gotta give.

## Wordle today: Hint and answer #927 for Tuesday, January 2
 - [https://www.pcgamer.com/wordle-today-answer-927-january-2](https://www.pcgamer.com/wordle-today-answer-927-january-2)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-01-02T03:57:44+00:00

Trouble solving today's Wordle? Here's the help you need.

