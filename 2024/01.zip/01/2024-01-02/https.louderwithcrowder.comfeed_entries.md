# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed/, language:en-US

## Violent Trans Inmate Sues Jail Because He Was Denied A Sex Change... And Access To Women's Panties
 - [https://www.louderwithcrowder.com/missouri-violent-inmate](https://www.louderwithcrowder.com/missouri-violent-inmate)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-01-02T21:16:09+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.webp?id=50976650&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Remember that time when a woman who had a history of violence got placed in a man's prison because of “trans rights” or something? I don’t remember that either. That is because that statement never happened. It never happened because there is a reason why we never see women begging to run to the men's prison because of <em>their truth. </em></p><p>More often than not, we see men being afforded insane special treatment that would otherwise be condemned if it were not under the guise of trans rights. Even though the status quo is leaning towards men invading women-only spaces, sometimes a state or county refuses to go along with this nonsense.</p><p>Missouri did not acquiesce to this crap. Now, they are getting sued by a man with a history of violence because he was not given women's panties to correctly affirm <em>his truth. </e

## Methodist Church Declares Terms Like 'Husband' And 'Wife' Are Now  Offensive
 - [https://www.louderwithcrowder.com/uk-church-language](https://www.louderwithcrowder.com/uk-church-language)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-01-02T21:12:29+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=50976229&amp;width=1245&amp;height=700&amp;coordinates=0%2C312%2C0%2C313" /><br /><br /><p>You don't have to be Christian to know that marriage is essential to God's plan. It is so important that He made it the bedrock of creation. “Male and female He created them,” God said. But for some reason, this very clear and straightforward message has the Methodist Church in Great Britain very, very confused. </p><p><br /></p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/ChristianPost/status/1741489540920234128"></a>
</blockquote>
<p><a href="https://www.christianpost.com/news/uk-based-methodist-church-advises-against-husband-and-wife.html#:~:text=The%20Methodist%20Church%20in%20Great,the%20reality%20for%20many%20people.%22" rel="noopener noreferrer" target="_blank">According to the <em>Christian Post: </em></a></p><blockquote>“The Methodist Chur

## Hot Mic Catches ABC Anchor Saying Higher Ups Made Her Ditch the Epstein Story: "Clinton? We Had Everything"
 - [https://www.louderwithcrowder.com/epstein-associates-unsealed-bill-clinton](https://www.louderwithcrowder.com/epstein-associates-unsealed-bill-clinton)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-01-02T18:39:17+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50975543&amp;width=2000&amp;height=1500&amp;coordinates=320%2C0%2C0%2C0" /><br /><br /><p>ABC News is reporting hundreds of <a href="https://abcnews.go.com/US/court-documents-naming-jeffrey-epsteins-associates-unsealed/story?id=105993160" target="_blank">sealed court filings pertaining to the late sex-offender Jeffrey Epstein</a> are set to be made public this week, including prominent names like Prince Andrew and Bill Clinton. What's funny is when you remember that the network HAD this story back in 2016 but squashed it. Which we know thanks to James O'Keefe and his leaked video of ABC's Amy Robach.</p><blockquote>This batch will involve the names of additional Epstein associates, alleged perpetrators, alleged co-conspirators, alleged victims, witnesses and former Epstein employees. Several of the "Does" mentioned in the documents are now deceased. Former President Clinton, who ABC News has learned is identified 

## Watch: Biden Admin Space Force Lt. Colonel Claims Inclusion Is Totally A "National Security Imperative"
 - [https://www.louderwithcrowder.com/space-force-inclusion](https://www.louderwithcrowder.com/space-force-inclusion)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-01-02T17:34:28+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50975185&amp;width=980" /><br /><br /><p>I am sure it is clear to most people reading this that “inclusion” is a delusion. Since when do we have to include all people, in all things? However, if you ask high-ranking trans Space Force Lt. Colonel Bree Fram, he will tell you, and I quote, that "inclusion is a national security imperative." </p><p>In other news, we have a high-ranking trans Space Force Lt. Colonel in the USA. </p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/libbyemmons/status/1741459230886957392"></a>
</blockquote>
<p><a href="https://thepostmillennial.com/highest-ranking-trans-member-of-us-space-force-says-inclusion-is-a-national-security-imperative" rel="noopener noreferrer" target="_blank">According to <em>The Post Millennial: </em></a></p><blockquote>“Space Force Lt. Colonel Bree Fram, 43, claims that ‘inclusion is a na

## That "GOP" Gov Who Vetoed A Ban On Genital Mutilations For Kids? He Took Over $40,000 From Hospitals That Perform Them
 - [https://www.louderwithcrowder.com/ohio-veto-bill](https://www.louderwithcrowder.com/ohio-veto-bill)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-01-02T17:20:21+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50975236&amp;width=980" /><br /><br /><p>There is a saying that claims everyone has a price. This typically is meant to refer to something immoral. The Ohio Gov. does have a price. And for the amount of evil he is willing to condone and enable, let's just say he is not very expensive to buy.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/TPostMillennial/status/1741992750705168636"></a>
</blockquote>
<p><a href="https://thepostmillennial.com/mike-dewine-took-40300-from-ohio-hospitals-that-perform-child-sex-changes-before-vetoing-bill-to-protect-kids-from-the-practice" rel="noopener noreferrer" target="_blank">According to <em>The Post Millennial: </em></a></p><blockquote>“After Ohio Governor Mike DeWine vetoed legislation that would have banned sex changes for minors, a new report revealed that he has received thousands in campaign donat

## Watch: Bills fan forgets "stop, drop, and roll" as he crashes through a flaming table... wait, a flaming table?!
 - [https://www.louderwithcrowder.com/buffalo-bills-mafia-flaming-table](https://www.louderwithcrowder.com/buffalo-bills-mafia-flaming-table)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-01-02T15:24:04+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50974181&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p>I know public schools stopped teaching things like history or civics or math. But I'd like to think we were still teaching kids that, should you find yourself on fire, to "stop, drop, and roll." For two <a href="https://www.louderwithcrowder.com/buffalo-bills-ken-dorsey-josh-allen" target="_blank">Buffalo Bills fans</a>, they must have skipped school that day.<br /></p><p>Before we get to the video, I need to explain what's going on. Every team has their own tailgating tradition. For Bills Mafia, it's crashing Labatt Blue's a jumping through tables. However, during important games, things can get a little out of hand. You need a little extra something something. Like setting the table on fire.</p><p>Before Sunday's must-win game against the Patriots, one mafia member, it his overzealousness, did not account for wind. He then r

## Beverly Hills 90210 star speaks out after being assaulted in front of his 10-year-old: "Hooliganism on our streets"
 - [https://www.louderwithcrowder.com/beverly-hills-90210-star-assaulted](https://www.louderwithcrowder.com/beverly-hills-90210-star-assaulted)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-01-02T14:44:08+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=50974003&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Seeing someone get assaulted on the streets of Los Angeles is, unfortunately, <a href="https://www.louderwithcrowder.com/kim-glass-assaulted-homeless" target="_blank">nothing we haven't seen before</a>. Los Angelinos have spent generations voting for progressive politicians who value criminals over people who are an asset to society. However, it is rare to see the victim be a 90s TV icon. It happened to Ian Ziering, star of <em>Beverly Hills 90210</em>. Those of you of a certain age immediately have the theme stuck in your head.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="b0a9c" src="https://www.louderwithcrowder.com/media-library/image.gif?id=50974057&amp;width=980" />
</p><p>The video is wild. Ziering got out of his car and was SWARMED by bikers. Urban bikers. Not real b

## Elon Musk ROASTS Green Day's embarrassing anti-MAGA pandering with "American Idiot" performance
 - [https://www.louderwithcrowder.com/green-day-american-idiot-maga](https://www.louderwithcrowder.com/green-day-american-idiot-maga)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-01-02T13:55:09+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50973624&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Part of the New Year's Eve tradition is for networks to collect a bunch of artists who aren't quite in their prime anymore to perform until the ball drops at midnight. We were watching what's left of Lynyrd Skynyrd. Some of you caught Green Day reliving 2004, only with MAGA as their new boogieman. It was the latter one that Elon Musk had bars for on X-Twitter.</p><p>Green Day performed "American Idiot." The original lyrics are "Well, maybe I'm the f*ggot, America, I'm not a part of a redneck agenda." Rednecks were who the Left blamed for not getting their way. Now instead of blaming half the states, they blame half the American people.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/TheTNHoller/status/1741653416013688834"></a>
</blockquote>
<p>Some of 

## Dave Chappelle drops brilliant trans joke on new Netflix special "The Dreamer," but the handicapped get it worse
 - [https://www.louderwithcrowder.com/dave-chappelle-the-dreamer-backlash](https://www.louderwithcrowder.com/dave-chappelle-the-dreamer-backlash)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-01-02T12:42:22+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50973057&amp;width=1200&amp;height=800&amp;coordinates=93%2C0%2C107%2C0" /><br /><br /><p>After receiving harsh criticism for his JOKES (not "remarks," <a href="https://deadline.com/2023/12/dave-chappelle-trans-disabled-people-the-dreamer-netflix-special-1235683999/" target="_blank">as Deadline claims</a>) about transgender and LGBTQ+ communities in his <a href="https://deadline.com/2023/12/dave-chappelle-trans-disabled-people-the-dreamer-netflix-special-1235683999/" target="_blank">previous Netflix special, <em>The Closer</em></a>, Dave Chappelle again decided he didn't give a f*ck and had fresh new material in his latest Netflix special, <em>The Dreamer</em>. It wasn't just trans people, this time. The handicapped got it too.</p><p>I have not had an opportunity to watch myself. I just went through a thing where I canceled a bunch of subscriptions I don't use anymore. When the last season of <em>Cobra Kai</em> dr

