# Source:Insight News Media, URL:https://insightnews.media/feed/, language:en-US

## Russia intends to use Uzbekistan for new sanctions evasion
 - [https://insightnews.media/russia-intends-to-use-uzbekistan-for-sanctions-evasion](https://insightnews.media/russia-intends-to-use-uzbekistan-for-sanctions-evasion)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2024-01-02T20:10:43+00:00

<p>The Russian government intends to fund the setting up of front firms to purchase electronics for combat drones. During the summit of CIS leaders on &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/russia-intends-to-use-uzbekistan-for-sanctions-evasion/"> <span class="screen-reader-text">Russia intends to use Uzbekistan for new sanctions evasion</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/russia-intends-to-use-uzbekistan-for-sanctions-evasion/">Russia intends to use Uzbekistan for new sanctions evasion</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

## Companies supplying components for Russian weapons exposed in Germany
 - [https://insightnews.media/companies-supplying-components-for-russian-weapons-exposed-in-germany](https://insightnews.media/companies-supplying-components-for-russian-weapons-exposed-in-germany)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2024-01-02T14:01:32+00:00

<p>An investigation by the German organization ARD Monitor, the Dutch program Nieuwsuur, and the British think tank RUSI has shown that the Russian military sector &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/companies-supplying-components-for-russian-weapons-exposed-in-germany/"> <span class="screen-reader-text">Companies supplying components for Russian weapons exposed in Germany</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/companies-supplying-components-for-russian-weapons-exposed-in-germany/">Companies supplying components for Russian weapons exposed in Germany</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

## Russian army poured a massive missile attack on Kyiv and Kharkiv
 - [https://insightnews.media/russian-army-poured-a-massive-missile-attack-on-kyiv-and-kharkiv](https://insightnews.media/russian-army-poured-a-massive-missile-attack-on-kyiv-and-kharkiv)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2024-01-02T11:13:11+00:00

<p>The Russian army continues to terrorize Ukraine&#8217;s civilian population. On January 2, the Russians conducted a huge missile attack on various Ukrainian regions. Russia&#8217;s massive &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/russian-army-poured-a-massive-missile-attack-on-kyiv-and-kharkiv/"> <span class="screen-reader-text">Russian army poured a massive missile attack on Kyiv and Kharkiv</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/russian-army-poured-a-massive-missile-attack-on-kyiv-and-kharkiv/">Russian army poured a massive missile attack on Kyiv and Kharkiv</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

## Ban on Russian diamond imports to the EU came into effect
 - [https://insightnews.media/ban-on-russian-diamond-imports-to-the-eu-came-into-effect](https://insightnews.media/ban-on-russian-diamond-imports-to-the-eu-came-into-effect)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2024-01-02T09:17:11+00:00

<p>As part of the 12th package of sanctions against Russia, the restriction on trade in diamonds originating from the Russian Federation took effect on Monday, &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/ban-on-russian-diamond-imports-to-the-eu-came-into-effect/"> <span class="screen-reader-text">Ban on Russian diamond imports to the EU came into effect</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/ban-on-russian-diamond-imports-to-the-eu-came-into-effect/">Ban on Russian diamond imports to the EU came into effect</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

