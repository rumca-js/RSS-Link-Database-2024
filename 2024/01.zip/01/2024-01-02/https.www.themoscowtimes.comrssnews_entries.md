# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Half of Putin's Decrees Classified in 2023 – Mediazona
 - [https://www.themoscowtimes.com/2024/01/02/half-of-putins-decrees-classified-in-2023-mediazona-a83631](https://www.themoscowtimes.com/2024/01/02/half-of-putins-decrees-classified-in-2023-mediazona-a83631)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-02T14:51:46+00:00

The share of classified presidential decrees jumped following Russia's invasion of Ukraine in 2022.

## 2 Injured in Rocket Attacks on Russia’s Belgorod Region
 - [https://www.themoscowtimes.com/2024/01/02/2-injured-in-rocket-attacks-on-russias-belgorod-region-a83628](https://www.themoscowtimes.com/2024/01/02/2-injured-in-rocket-attacks-on-russias-belgorod-region-a83628)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-02T12:33:03+00:00

The air strikes prompted authorities in the Belgorod region to issue three separate alerts on Tuesday.

## 1 Killed in Rocket Attacks on Russia’s Belgorod Region
 - [https://www.themoscowtimes.com/2024/01/02/1-killed-in-rocket-attacks-on-russias-belgorod-region-a83628](https://www.themoscowtimes.com/2024/01/02/1-killed-in-rocket-attacks-on-russias-belgorod-region-a83628)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-02T12:33:00+00:00

Russia’s Defense Ministry claimed it downed multiple “Olkha” missiles over the region on Tuesday.

## Russian Warplane Makes 'Emergency' Munitions Release Over Village, Destroys Homes
 - [https://www.themoscowtimes.com/2024/01/02/russian-warplane-makes-emergency-munitions-release-over-village-destroys-homes-a83626](https://www.themoscowtimes.com/2024/01/02/russian-warplane-makes-emergency-munitions-release-over-village-destroys-homes-a83626)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-02T09:46:17+00:00

Authorities said no one was killed or injured by the blast in western Russia's Voronezh region, but several buildings were destroyed.

## Russia Accidentally Bombs Own Village
 - [https://www.themoscowtimes.com/2024/01/02/russia-accidentally-bombs-own-village-a83626](https://www.themoscowtimes.com/2024/01/02/russia-accidentally-bombs-own-village-a83626)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-02T09:46:00+00:00

Authorities said no one was killed or injured by the blast in western Russia's Voronezh region, but several buildings were destroyed.

## One killed, Dozens Injured in Russian Missile Attacks on Ukraine
 - [https://www.themoscowtimes.com/2024/01/02/one-killed-dozens-injured-in-russian-missile-attacks-on-ukraine-a83625](https://www.themoscowtimes.com/2024/01/02/one-killed-dozens-injured-in-russian-missile-attacks-on-ukraine-a83625)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-02T08:33:32+00:00

Tuesday's attacks came a day after Russian President Vladimir Putin said his forces would intensify strikes on "military targets."

## Four killed, Dozens Injured in Russian Missile Attacks on Ukraine
 - [https://www.themoscowtimes.com/2024/01/02/four-killed-dozens-injured-in-russian-missile-attacks-on-ukraine-a83625](https://www.themoscowtimes.com/2024/01/02/four-killed-dozens-injured-in-russian-missile-attacks-on-ukraine-a83625)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-01-02T08:33:00+00:00

Tuesday's attacks came a day after Russian President Vladimir Putin said his forces would intensify strikes on "military targets."

