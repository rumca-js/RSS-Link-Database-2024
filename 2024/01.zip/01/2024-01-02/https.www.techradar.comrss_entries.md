# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## You'll be paying much more for SSD cards this year - here's why
 - [https://www.techradar.com/computing/computing-components/youll-be-paying-much-more-for-ssd-cards-this-year-heres-why](https://www.techradar.com/computing/computing-components/youll-be-paying-much-more-for-ssd-cards-this-year-heres-why)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T22:56:17+00:00

Sorry buyers, but SSD prices will be skyrocketing this year thanks to manufacturers increasing market prices for its components.

## Tunefab music piracy tool leaked hundreds of gigabytes of user data over 24 hours last year
 - [https://www.techradar.com/pro/security/tunefab-music-piracy-tool-leaked-hundreds-of-gigabytes-of-user-data-over-24-hours-last-year](https://www.techradar.com/pro/security/tunefab-music-piracy-tool-leaked-hundreds-of-gigabytes-of-user-data-over-24-hours-last-year)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T21:28:15+00:00

DVDfab’s dedicated audio conversion tool has been confirmed to be involved in a data breach dating back to September 2023.

## PC gamers will finally lose support for Windows 7, 8, and 8.1 thanks to Valve dropping them
 - [https://www.techradar.com/computing/windows/pc-gamers-will-finally-lose-support-for-windows-7-8-and-81-thanks-to-valve-dropping-them](https://www.techradar.com/computing/windows/pc-gamers-will-finally-lose-support-for-windows-7-8-and-81-thanks-to-valve-dropping-them)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T20:47:56+00:00

Valve announced that as of now Steam will no longer support several Windows operating systems, meaning no more security updates or general user support.

## Report: Microsoft's Surface Laptop 6 may have striking design changes and a power boost
 - [https://www.techradar.com/computing/laptops/report-microsofts-surface-laptop-6-may-have-striking-design-changes-and-a-power-boost](https://www.techradar.com/computing/laptops/report-microsofts-surface-laptop-6-may-have-striking-design-changes-and-a-power-boost)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T20:27:25+00:00

New leaks state the model's custom Snapdragon X CPU will utilize Microsoft's upcoming AI-powered features.

## This new Mini workstation really is small but mighty – it boasts an ultra-fast Intel processor that can tackle intensive tasks with ease, and offers ample storage possibilities, making it ideal for even the most demanding user
 - [https://www.techradar.com/pro/this-new-mini-workstation-really-is-small-but-mighty-it-boasts-an-ultra-fast-intel-processor-that-can-tackle-intensive-tasks-with-ease-and-offers-ample-storage-possibilities-making-it-ideal-for-even-the-most-demanding-user](https://www.techradar.com/pro/this-new-mini-workstation-really-is-small-but-mighty-it-boasts-an-ultra-fast-intel-processor-that-can-tackle-intensive-tasks-with-ease-and-offers-ample-storage-possibilities-making-it-ideal-for-even-the-most-demanding-user)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T20:10:31+00:00

Minisforum's new MiniWorkStation, the MS-01, is a tiny powerhouse and comes in a choice of configurations.

## Chatbot vs chatbot - researchers train AI chatbots to hack each other, and they can even do it automatically
 - [https://www.techradar.com/pro/chatbot-vs-chatbot-researchers-train-ai-chatbots-to-hack-each-other-and-they-can-even-do-it-automatically](https://www.techradar.com/pro/chatbot-vs-chatbot-researchers-train-ai-chatbots-to-hack-each-other-and-they-can-even-do-it-automatically)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T18:25:59+00:00

Researchers have developed a method to bypass LLM safeguarding.

## We may finally know when Apple’s Vision Pro will launch – but big questions remain
 - [https://www.techradar.com/computing/virtual-reality-augmented-reality/we-may-finally-know-when-apples-vision-pro-will-launch-but-big-questions-remain](https://www.techradar.com/computing/virtual-reality-augmented-reality/we-may-finally-know-when-apples-vision-pro-will-launch-but-big-questions-remain)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T17:27:11+00:00

A report out of China has floated a release date for the Vision Pro, but it raises some thorny questions.

## This dangerous malware is able to hijack your Google Account by reviving cookies
 - [https://www.techradar.com/pro/security/this-dangerous-malware-is-able-to-hijack-your-google-account-by-reviving-cookies](https://www.techradar.com/pro/security/this-dangerous-malware-is-able-to-hijack-your-google-account-by-reviving-cookies)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T17:25:36+00:00

Malware is now spreading “rapidly” and reinstating cookies to get access to your Google Accounts.

## Star Wars Outlaws arrives in 'late' 2024, according to Disney
 - [https://www.techradar.com/gaming/consoles-pc/star-wars-outlaws-arrives-in-late-2024-according-to-disney](https://www.techradar.com/gaming/consoles-pc/star-wars-outlaws-arrives-in-late-2024-according-to-disney)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T17:24:59+00:00

Star Wars Outlaws has a new release window of "late" 2024.

## Apple TV Plus green lights Slow Horses season 5 as hit spy show sets new record for the streamer
 - [https://www.techradar.com/streaming/apple-tv-plus/apple-tv-plus-green-lights-slow-horses-season-5-as-hit-spy-show-sets-new-record-for-the-streamer](https://www.techradar.com/streaming/apple-tv-plus/apple-tv-plus-green-lights-slow-horses-season-5-as-hit-spy-show-sets-new-record-for-the-streamer)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T17:23:22+00:00

The hit UK-set espionage thriller series is coming back for a fifth season – and set a new record in the process.

## No, Tekken 8 isn’t releasing early, Bandai Namco confirms
 - [https://www.techradar.com/gaming/consoles-pc/no-tekken-8-isnt-releasing-early-bandai-namco-confirms](https://www.techradar.com/gaming/consoles-pc/no-tekken-8-isnt-releasing-early-bandai-namco-confirms)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T17:18:35+00:00

Tekken 8 is still set to release on January 26 on all platforms, Bandai Namco has reconfirmed after recent confusion online.

## New Year's TV sales from Best Buy, Amazon and Walmart - $800 off 4K and OLED TVs
 - [https://www.techradar.com/televisions/new-years-tv-sales-from-best-buy-amazon-and-walmart-dollar800-off-4k-and-oled-tvs](https://www.techradar.com/televisions/new-years-tv-sales-from-best-buy-amazon-and-walmart-dollar800-off-4k-and-oled-tvs)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T16:32:03+00:00

Your guide to the best New Year's TV sales from Best Buy, Amazon, and Walmart with clearance prices on 4K and OLED displays.

## CS:GO support has officially ended after 10 years
 - [https://www.techradar.com/gaming/consoles-pc/csgo-support-has-officially-ended-after-10-years](https://www.techradar.com/gaming/consoles-pc/csgo-support-has-officially-ended-after-10-years)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T16:16:33+00:00

Support for the legacy version of Counter-Strike: Global Offensive has officially ended.

## These Audio eyeglasses may be the perfect solution for my admittedly awful hearing
 - [https://www.techradar.com/audio/these-audio-eyeglasses-may-be-the-perfect-solution-for-my-admittedly-awful-hearing](https://www.techradar.com/audio/these-audio-eyeglasses-may-be-the-perfect-solution-for-my-admittedly-awful-hearing)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T16:08:29+00:00

Nuance Audio glasses direct their microphones in the direction of your view.

## Massive Fitbit sale is live - shop the 4 best deals available today
 - [https://www.techradar.com/health-fitness/fitness-trackers/massive-fitbit-sale-is-live-shop-the-4-best-deals-available-today](https://www.techradar.com/health-fitness/fitness-trackers/massive-fitbit-sale-is-live-shop-the-4-best-deals-available-today)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T15:53:16+00:00

Several Fitbit deals have launched at the start of the new year with offers across the manufacturer's top smartwatches and fitness trackers.

## Chief Technology Officer or Constantly Toughing (it) Out?
 - [https://www.techradar.com/pro/chief-technology-officer-or-constantly-toughing-it-out](https://www.techradar.com/pro/chief-technology-officer-or-constantly-toughing-it-out)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T15:16:39+00:00

The role of Chief Technology Officers (CTOs) has transformed significantly over the last two decades.

## Hospitals ask cloud storage company to hand over stolen data hosted on its servers
 - [https://www.techradar.com/pro/hospitals-ask-cloud-storage-company-to-hand-over-stolen-data-hosted-on-its-servers](https://www.techradar.com/pro/hospitals-ask-cloud-storage-company-to-hand-over-stolen-data-hosted-on-its-servers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T15:09:38+00:00

The hospitals may have found where the data was stored, but it may not be the only copy.

## How to future-proof your workplace
 - [https://www.techradar.com/pro/how-to-future-proof-your-workplace](https://www.techradar.com/pro/how-to-future-proof-your-workplace)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T15:08:44+00:00

Outdated workforce technology takes a toll on employees by increasing burnout and turnover, driving up operational costs, and reducing competitiveness.

## LG aims for Samsung's portable projector crown with its stylish new 4K projector
 - [https://www.techradar.com/televisions/projectors/lg-aims-for-samsungs-portable-projector-crown-with-its-stylish-new-4k-projector](https://www.techradar.com/televisions/projectors/lg-aims-for-samsungs-portable-projector-crown-with-its-stylish-new-4k-projector)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T15:05:26+00:00

LG has revealed a new portable 4K projector, the CineBeam Qube, that not only promises a compact home theater solution, but also has an appealing, modern design meaning it can also be used as an ‘art object’.

## Xiaomi reveals more about its debut SU7 EV – including the HyperOS IoT ecosystem
 - [https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/xiaomi-reveals-more-about-its-debut-su7-ev-including-the-hyperos-iot-ecosystem](https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/xiaomi-reveals-more-about-its-debut-su7-ev-including-the-hyperos-iot-ecosystem)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T14:41:24+00:00

Xiaomi held a conference where it revealed more important details about its debut SU7 electric vehicle.

## Amazon Drive cloud storage for Prime users ends - here's what you need to know
 - [https://www.techradar.com/pro/amazon-drive-cloud-storage-for-prime-users-ends-heres-what-you-need-to-know](https://www.techradar.com/pro/amazon-drive-cloud-storage-for-prime-users-ends-heres-what-you-need-to-know)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T14:26:08+00:00

After almost 13 years, Amazon Drive is being replaced with a more consumer-focussed storage service for videos and photos. We’ve got all the details, and what you should probably be doing with your data next.

## LG DukeBox is the OLED TV-toting jukebox with valve amp fireside visuals nobody asked for
 - [https://www.techradar.com/audio/lg-dukebox-is-the-oled-tv-toting-jukebox-with-valve-amp-fireside-visuals-nobody-asked-for](https://www.techradar.com/audio/lg-dukebox-is-the-oled-tv-toting-jukebox-with-valve-amp-fireside-visuals-nobody-asked-for)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T14:02:25+00:00

LG’s DukeBox looks like a vacuum tube sound system in a glass box, but it’s also an OLED TV screen – and it's coming to CES 2024.

## Owner of the world's first speedrunning Shiba Inu reveals how the best boy achieves success
 - [https://www.techradar.com/gaming/consoles-pc/owner-of-the-worlds-first-speedrunning-shiba-inu-reveals-how-the-best-boy-achieves-success](https://www.techradar.com/gaming/consoles-pc/owner-of-the-worlds-first-speedrunning-shiba-inu-reveals-how-the-best-boy-achieves-success)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T13:52:31+00:00

The owner of the speedrunning Shiba Inu, Peanut Butter, has revealed the secret behind the good boy's success.

## Leaked Galaxy S24 pre-order bonuses sound genuinely tempting
 - [https://www.techradar.com/phones/samsung-galaxy-phones/leaked-galaxy-s24-pre-order-bonuses-sound-genuinely-tempting](https://www.techradar.com/phones/samsung-galaxy-phones/leaked-galaxy-s24-pre-order-bonuses-sound-genuinely-tempting)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T13:16:20+00:00

A leak suggests Galaxy S24 pre-order bonuses will include extra storage, plus discounts on the Galaxy Watch and Galaxy Buds.

## Huawei says hardware and cloud will be its big focus in 2024
 - [https://www.techradar.com/pro/huawei-says-hardware-and-cloud-will-be-its-big-focus-in-2024](https://www.techradar.com/pro/huawei-says-hardware-and-cloud-will-be-its-big-focus-in-2024)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T13:02:12+00:00

ICT, hardware, and cloud are Huawei’s 2024 New Year’s resolutions, in light of huge AI growth.

## Innocent players are getting banned as The Finals takes the war to cheaters
 - [https://www.techradar.com/gaming/consoles-pc/innocent-players-are-getting-banned-as-the-finals-takes-the-war-to-cheaters](https://www.techradar.com/gaming/consoles-pc/innocent-players-are-getting-banned-as-the-finals-takes-the-war-to-cheaters)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T12:38:35+00:00

Embark Studios may have incorrectly banned a selection of The Finals players during the game's first ban wave.

## The Oculus Quest 2 gets another price cut, and it’s the beginning of the end for the Meta VR headset
 - [https://www.techradar.com/computing/virtual-reality-augmented-reality/the-oculus-quest-2-gets-another-price-cut-and-its-the-beginning-of-the-end-for-the-meta-vr-headset](https://www.techradar.com/computing/virtual-reality-augmented-reality/the-oculus-quest-2-gets-another-price-cut-and-its-the-beginning-of-the-end-for-the-meta-vr-headset)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T12:31:55+00:00

The Oculus Quest 2 just got a $50 / £50 / AU$70 price cut, suggesting that the VR headset's days are numbered.

## Leaked Samsung Galaxy S24 Ultra poster teases a formidable iPhone 15 Pro rival
 - [https://www.techradar.com/phones/samsung-galaxy-phones/leaked-samsung-galaxy-s24-ultra-poster-teases-a-formidable-iphone-15-pro-rival](https://www.techradar.com/phones/samsung-galaxy-phones/leaked-samsung-galaxy-s24-ultra-poster-teases-a-formidable-iphone-15-pro-rival)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T12:26:46+00:00

Marketing material for the Samsung Galaxy S24 Ultra has leaked, revealing the phone's new and improved design.

## Football Manager 2024 players are concerned about attributes ‘not mattering enough’, saying it ‘makes the game a joke’
 - [https://www.techradar.com/gaming/consoles-pc/football-manager-2024-players-are-concerned-about-attributes-not-mattering-enough-saying-it-makes-the-game-a-joke](https://www.techradar.com/gaming/consoles-pc/football-manager-2024-players-are-concerned-about-attributes-not-mattering-enough-saying-it-makes-the-game-a-joke)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T12:24:05+00:00

Football Manager 2024 players are concerned that footballers' attributes don't matter enough when it comes to determining their performance.

## The Netvue Birdfy is our favorite bird feeder camera, and it's now over 30% off
 - [https://www.techradar.com/cameras/the-netvue-birdfy-is-our-favorite-bird-feeder-camera-and-its-now-over-30-off](https://www.techradar.com/cameras/the-netvue-birdfy-is-our-favorite-bird-feeder-camera-and-its-now-over-30-off)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T12:11:13+00:00

Want to feed and film your local birds this winter? We've found great deals on the Netvue Birdfy bird feeder camera.

## Copilot Chat will let developers ask whatever questions they like about GitHub code
 - [https://www.techradar.com/pro/copilot-chat-will-let-developers-ask-whatever-questions-they-like-about-github-code](https://www.techradar.com/pro/copilot-chat-will-let-developers-ask-whatever-questions-they-like-about-github-code)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T12:00:11+00:00

GPT-4-powered GitHub Copilot Chat answers all of your coding questions, and now in more places.

## Reminder: Amazon Prime Video is about to start inserting ads unless you pay more
 - [https://www.techradar.com/streaming/amazon-prime-video/reminder-amazon-prime-video-is-about-to-start-inserting-ads-unless-you-pay-more](https://www.techradar.com/streaming/amazon-prime-video/reminder-amazon-prime-video-is-about-to-start-inserting-ads-unless-you-pay-more)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T11:51:24+00:00

The service you currently pay for is about to get more annoying – here's what you need to know.

## 4 new movies on Netflix in January 2024 with over 90% on Rotten Tomatoes
 - [https://www.techradar.com/streaming/netflix/4-new-movies-on-netflix-in-january-2024-with-over-90-on-rotten-tomatoes](https://www.techradar.com/streaming/netflix/4-new-movies-on-netflix-in-january-2024-with-over-90-on-rotten-tomatoes)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T11:45:17+00:00

From a new Oscar hopeful to a Spielberg classic, start your month with these acclaimed movies.

## Microsoft Teams is rolling out an incredibly useful messaging tweak we can't belive wasn't already a thing
 - [https://www.techradar.com/pro/microsoft-teams-is-rolling-out-an-incredibly-useful-messaging-tweak-we-cant-belive-wasnt-already-a-thing](https://www.techradar.com/pro/microsoft-teams-is-rolling-out-an-incredibly-useful-messaging-tweak-we-cant-belive-wasnt-already-a-thing)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T11:23:10+00:00

Forwarding a message from one Microsoft Teams chat to another is finally getting a lot simpler.

## Escape from Tarkov players complain of long loading times after recent wipe
 - [https://www.techradar.com/gaming/pc-gaming/escape-from-tarkov-players-complain-of-long-loading-times-after-recent-wipe](https://www.techradar.com/gaming/pc-gaming/escape-from-tarkov-players-complain-of-long-loading-times-after-recent-wipe)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T11:08:50+00:00

Some Escape from Tarkov players are experiencing increased loading times following the most recent game wipe.

## This company made a significant Google Drive security error that could put a million users at risk
 - [https://www.techradar.com/pro/security/this-company-made-a-significant-google-drive-security-error-that-could-put-a-million-users-at-risk](https://www.techradar.com/pro/security/this-company-made-a-significant-google-drive-security-error-that-could-put-a-million-users-at-risk)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T10:56:41+00:00

Simple misconfiguration blunder saw Ateam’s Google Drive (slightly) exposed for more than six years.

## Final Fantasy 7 Rebirth features a scene that makes the creative director want to cry
 - [https://www.techradar.com/gaming/consoles-pc/final-fantasy-7-rebirth-features-a-scene-that-makes-the-creative-director-want-to-cry](https://www.techradar.com/gaming/consoles-pc/final-fantasy-7-rebirth-features-a-scene-that-makes-the-creative-director-want-to-cry)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T10:43:10+00:00

Final Fantasy 7 Rebirth creative director Tetsuya Nomura has revealed that there's one particular scene that makes him want to cry.

## Baldur’s Gate 3 player’s honor mode run ends abruptly after a disastrous game of fetch with Scratch
 - [https://www.techradar.com/gaming/consoles-pc/baldurs-gate-3-players-honor-mode-run-ends-abruptly-after-a-disastrous-game-of-fetch-with-scratch](https://www.techradar.com/gaming/consoles-pc/baldurs-gate-3-players-honor-mode-run-ends-abruptly-after-a-disastrous-game-of-fetch-with-scratch)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T10:31:41+00:00

A Baldur's Gate 3 player has warned others to be careful when playing fetch with Scratch in Honor Mode.

## 'I don't think of myself as a game designer', says Mario and Zelda creator Shigeru Miyamoto
 - [https://www.techradar.com/gaming/consoles-pc/i-dont-think-of-myself-as-a-game-designer-says-mario-and-zelda-creator-shigeru-miyamoto](https://www.techradar.com/gaming/consoles-pc/i-dont-think-of-myself-as-a-game-designer-says-mario-and-zelda-creator-shigeru-miyamoto)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T10:30:56+00:00

Nintendo legend Shigeru Miyamoto opens up about his industry-changing career in new interview.

## Mickey Mouse has only been in the public domain for a day, and there's already a horror game in the works
 - [https://www.techradar.com/gaming/pc-gaming/mickey-mouse-has-only-been-in-the-public-domain-for-a-day-and-theres-already-a-horror-game-in-the-works](https://www.techradar.com/gaming/pc-gaming/mickey-mouse-has-only-been-in-the-public-domain-for-a-day-and-theres-already-a-horror-game-in-the-works)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T10:25:06+00:00

Mickey Mouse is getting a horror game makeover in Infestation 88.

## Square Enix president believes "aggressive" approach to AI will improve game development
 - [https://www.techradar.com/gaming/square-enix-president-believes-aggressive-approach-to-ai-will-improve-game-development](https://www.techradar.com/gaming/square-enix-president-believes-aggressive-approach-to-ai-will-improve-game-development)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T10:20:39+00:00

Takashi Kiryu, president of Square Enix, has reaffirmed the company's desire to chase AI technology in his New Year's letter.

## Meta Quest headsets are losing one of their most useful features
 - [https://www.techradar.com/computing/virtual-reality-augmented-reality/meta-quest-headsets-are-losing-one-of-their-most-useful-features](https://www.techradar.com/computing/virtual-reality-augmented-reality/meta-quest-headsets-are-losing-one-of-their-most-useful-features)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T10:13:23+00:00

The latest v60 update for Meta Quest headsets apparently removes the ability to connect to a Chromecast.

## Baldur's Gate 3 is still suffering from its deleted save bug, but Larian has shared a workaround
 - [https://www.techradar.com/gaming/baldurs-gate-3-is-still-suffering-from-its-deleted-save-bug-but-larian-has-shared-a-workaround](https://www.techradar.com/gaming/baldurs-gate-3-is-still-suffering-from-its-deleted-save-bug-but-larian-has-shared-a-workaround)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T09:50:18+00:00

A workaround has been shared by Larian Studios for players still struggling with Baldur's Gate 3's deleted save bug.

## Quordle today – hints and answers for Tuesday, January 2 (game #708)
 - [https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-2-january-2024](https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-2-january-2024)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-01-02T00:15:07+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

