# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Tylko 80 osób zginęło w ubiegłym roku w katastrofach samolotów pasażerskich. To wcale nie jest najniższa liczba
 - [https://forsal.pl/transport/lotnictwo/artykuly/9393867,tylko-80-osob-zginelo-w-ubieglym-roku-w-katastrofach-samolotow-pasazer.html](https://forsal.pl/transport/lotnictwo/artykuly/9393867,tylko-80-osob-zginelo-w-ubieglym-roku-w-katastrofach-samolotow-pasazer.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T20:43:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kC6ktkuTURBXy9mZGVjNTk3MC0xNDUyLTQxY2MtOTMyNy1hOTliYjMxMjlmNzguanBlZ5GTBc0BHcyg" />W ubiegłym roku w wypadkach liniowych samolotów pasażerskich na całym świecie zginęło zaledwie 80 osób - podało we wtorek niemieckie stowarzyszenie przemysłu lotniczego. W latach 90. roczna liczba ofiar śmiertelnych często przekraczała tysiąc.

## Francuskie władze na ścieżce wojennej ze sklepami. Chodzi o shrinkflację
 - [https://forsal.pl/artykuly/9393845,francuskie-wladze-na-sciezce-wojennej-ze-sklepami-chodzi-o-shrinkflac.html](https://forsal.pl/artykuly/9393845,francuskie-wladze-na-sciezce-wojennej-ze-sklepami-chodzi-o-shrinkflac.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T19:08:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sMtktkuTURBXy9kODYwNDJhMS03ZDUzLTQwYjktOGUyMy1mYThmOWNlMTkyNGYuanBlZ5GTBc0BHcyg" />Francuskie władze chcą zobowiązać sprzedawców i producentów, by informowali konsumentów o tym, że pomimo tej samej ceny ilość danego produktu się zmniejszyła - poinformował we wtorek portal Just Food.

## Zawieszenie Glapińskiego nie obniży ratingu Polski? S&amp;P: Potencjalne implikacje nie byłyby automatyczne
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9393603,zawieszenie-glapinskiego-nie-obnizy-ratingu-polski-sp-potencjalne-i.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9393603,zawieszenie-glapinskiego-nie-obnizy-ratingu-polski-sp-potencjalne-i.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T17:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/p5CktkuTURBXy80ZjQ4NGM3Zi03MjcyLTQ3YTYtYjNkMi1hYTRkZjlkNDc5MzEuanBlZ5GTBc0BHcyg" />Scenariusz zawieszenia w obowiązkach prezesa NBP po postawieniu go przed Trybunałem Stanu jest hipotetyczny, ale gdyby tak się stało, to potencjalne implikacje dotyczące ratingu Polski nie byłyby automatyczne - poinformował PAP Biznes główny analityk agencji S&amp;amp;P Global Ratings odpowiedzialny za rating Polski Ludwig Heinz.

## 88 proc. mieszkańców Kuby żyje w skrajnym ubóstwie [RAPORT]
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9393598,88-proc-mieszkancow-kuby-zyje-w-skrajnym-ubostwie-raport.html](https://forsal.pl/swiat/aktualnosci/artykuly/9393598,88-proc-mieszkancow-kuby-zyje-w-skrajnym-ubostwie-raport.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T17:07:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zBCktkuTURBXy83MGJjOGYwNS1iMjFhLTQwYWQtYWY5OC1hNmQwYjUyODQyNjMuanBlZ5GTBc0BHcyg" />Na zamieszkałej przez ponad 11 mln osób Kubie 88 proc. obywateli żyje w skrajnym ubóstwie, wynika z raportu niezależnego Kubańskiego Obserwatorium Praw Człowieka (OCDH).

## W co inwestowaliśmy najchętniej w 2023 roku? Wcale nie w kryptowaluty [SONDAŻ]
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9393575,w-co-inwestowalismy-najchetniej-w-2023-roku-wcale-nie-w-kryptowaluty.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9393575,w-co-inwestowalismy-najchetniej-w-2023-roku-wcale-nie-w-kryptowaluty.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T16:25:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LMzktkuTURBXy85MzhkNDMzMS00ZTBjLTRhMWYtODgyYy0xNzJjMDU0MzA4MWEuanBlZ5GTBc0BHcyg" />Polacy kładą nacisk na spokojne, wyważone inwestycje – m.in. w kruszce, obligacje i nieruchomości. Jednak nasza wiedza w tym zakresie wciąż jest zbyt niska.

## Wygasły prawa Disneya do najstarszych wizerunków Mickey Mouse
 - [https://forsal.pl/lifestyle/rozrywka/artykuly/9393488,wygasly-prawa-disneya-do-najstarszych-wizerunkow-mickey-mouse.html](https://forsal.pl/lifestyle/rozrywka/artykuly/9393488,wygasly-prawa-disneya-do-najstarszych-wizerunkow-mickey-mouse.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T15:01:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/O5bktkuTURBXy8wZTMwZjA4OS00NGQxLTQzMWYtYTdhYi1jMmI0ZmNlMjdhNjQuanBlZ5GTBc0BHcyg" />1 stycznia wygasły prawa Disneya do najstarszych wersji wizerunku sławnej mysiej pary: Mickey Mouse i Minnie Mouse. Oznacza to, że twórcy mogą bez pozwolenia i bez opłat wykorzystywać je i przerabiać.

## Jan Pietrzak bez zarzutów za nieprzyzwoitą wypowiedź o barakach w Polsce? Jednak postępowanie w sprawie wszczęte
 - [https://forsal.pl/lifestyle/rozrywka/artykuly/9393473,jan-pietrzak-bez-zarzutow-za-nieprzyzwoita-wypowiedz-o-barakach-w-pols.html](https://forsal.pl/lifestyle/rozrywka/artykuly/9393473,jan-pietrzak-bez-zarzutow-za-nieprzyzwoita-wypowiedz-o-barakach-w-pols.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T14:48:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yMTktkuTURBXy82MmJiYmJmMC0wZDQ3LTQwYWYtYTEwYS1jNTBiYWM4OWExOGEuanBlZ5GTBc0BHcyg" />Wszczęto postępowanie dotyczące wypowiedzi w Telewizji Republika. Chodzi o program wyemitowany 31 grudnia ub.r. Postępowanie prowadzone jest w sprawie co oznacza, że nikomu nie przedstawiono zarzutów – poinformował PAP we wtorek rzecznik prasowy Prokuratury Okręgowej w Warszawie Szymon Banna.

## PKP Intercity: Blisko 2,5 mln pasażerów w okresie świąteczno-noworocznym
 - [https://forsal.pl/transport/kolej/artykuly/9393460,pkp-intercity-blisko-25-mln-pasazerow-w-okresie-swiateczno-noworoczn.html](https://forsal.pl/transport/kolej/artykuly/9393460,pkp-intercity-blisko-25-mln-pasazerow-w-okresie-swiateczno-noworoczn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T14:42:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0ZVktkuTURBXy8wMTc2MDcwZC1iNWI5LTQxMTQtOGIyNC1mMzYyNTQ5N2Q5NzMuanBlZ5GTBc0BHcyg" />PKP Intercity w okresie świąt Bożego Narodzenia i Sylwestra przewiozło prawie 2,5 mln pasażerów - poinformował we wtorek przewoźnik. Najwięcej osób podróżowało w piątek, 22 grudnia – dodano.

## Zmarł prof. dr hab. Wojciech Łączkowski. Był sędzią Trybunału Konstytucyjnego i szefem Państwowej Komisji Wyborczej
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9393452,zmarl-prof-dr-hab-wojciech-laczkowski-byl-sedzia-trybunalu-konstytu.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9393452,zmarl-prof-dr-hab-wojciech-laczkowski-byl-sedzia-trybunalu-konstytu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T14:24:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/n0YktkuTURBXy9kNTk0ZjRhMi1mZGUwLTQxNmYtOWJmMS1jM2E0YWViYTNlZTguanBlZ5GTBc0BHcyg" />W wieku 90 lat zmarł prof. dr hab. Wojciech Łączkowski, były sędzia Trybunału Konstytucyjnego, przewodniczący Państwowej Komisji Wyborczej w latach 1994-97, autorytet w dziedzinie prawa finansowego i administracyjnego - poinformował we wtorek Uniwersytet im. Adama Mickiewicza w Poznaniu.

## Błędne kursy złotego w Google. Skutek? Obwinianie Glapińskiego i spekulacje
 - [https://forsal.pl/finanse/waluty/artykuly/9393418,bledne-kursy-zlotego-w-google-skutek-obwinianie-glapinskiego-i-speku.html](https://forsal.pl/finanse/waluty/artykuly/9393418,bledne-kursy-zlotego-w-google-skutek-obwinianie-glapinskiego-i-speku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T14:09:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EaOktkuTURBXy8zMzExZTYyZi0zYzhmLTRjMjEtOWJjYy0xYzkzMmNjNDMzMTUuanBlZ5GTBc0BHcyg" />Spekulacja i komentarze wymierzone w prezesa NBP – to główne konsekwencje błędnych kursów polskiej waluty, które podawała w poniedziałek wyszukiwarka Google.

## ING ma dobre wieści dla polskiej gospodarki. Co z PKB?
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9393399,ing-ma-dobre-wiesci-dla-polskiej-gospodarki-co-z-pkb.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9393399,ing-ma-dobre-wiesci-dla-polskiej-gospodarki-co-z-pkb.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T13:48:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Cc_ktkuTURBXy9kZDI0OGU1Yi0wZDZlLTQ5MGItOThiNi1jYTI2MzI3ZTMxYWEuanBlZ5GTBc0BHcyg" />Wzrost polskiej gospodarki w 2024 r. przyspieszy, PKB wzrośnie o ok. 3 proc. r/r; nie poprawi się dostępność pracy, wzrosnąć może za to konkurencja o pracownika - prognozuje we wtorek ING. Bank oczekuje też kontynuacji dezinflacji.

## Szalone kursy złotego w Google. To ważny test dla państwa
 - [https://forsal.pl/finanse/waluty/artykuly/9393377,szalone-kursy-zlotego-w-google-to-wazny-test-dla-panstwa.html](https://forsal.pl/finanse/waluty/artykuly/9393377,szalone-kursy-zlotego-w-google-to-wazny-test-dla-panstwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T13:41:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4LyktkuTURBXy9iYTUzYjkwZi1kNWQ1LTQ4MGQtOTEyMy04ZTIxOGM1MDkxOWIuanBlZ5GTBc0BHcyg" />Nowy Rok zaczął się niespodzianką. Wieczorem pierwszego dnia roku nagle zaczął rosnąć kurs wymiany EUR/PLN. A przynajmniej było to widoczne w danych wyszukiwarki Google. Z niejasnych powodów wpisując w wyszukiwarce Google „1 eur&quot;, „kurs euro&quot; itd. zamiast typowego wyniku kursowego (ceny i wykresu) mieliśmy wręcz finansowy thriller, roller-coaster.

## Radar w Antwerpii postrachem tamtejszych kierowców. Ile mandatów wystawił w pierwszym półroczu?
 - [https://forsal.pl/transport/aktualnosci/artykuly/9393355,radar-w-antwerpii-postrachem-tamtejszych-kierowcow-ile-mandatow-wysta.html](https://forsal.pl/transport/aktualnosci/artykuly/9393355,radar-w-antwerpii-postrachem-tamtejszych-kierowcow-ile-mandatow-wysta.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T13:15:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NdzktkuTURBXy9jNTRmNzc1MS1mNDY3LTQ3YWEtOGIyMy1lNWJiYTQ4YjA4ZDEuanBlZ5GTBc0BHcyg" />Fotoradar w Antwerpii w północnej Belgii złapał na przekroczeniu prędkości 65 tys. kierowców w pierwszym półroczu 2023 r. i wystawiał mandaty średnio co cztery minuty - informuje we wtorek dziennik „Gazet Van Antwerpen”.

## 2023 rok był świadkiem iście kopernikańskiego przewrotu dla technologii kosmicznych w Polsce
 - [https://forsal.pl/lifestyle/technologie/artykuly/9393344,2023-rok-byl-swiadkiem-iscie-kopernikanskiego-przewrotu-dla-technologi.html](https://forsal.pl/lifestyle/technologie/artykuly/9393344,2023-rok-byl-swiadkiem-iscie-kopernikanskiego-przewrotu-dla-technologi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T12:55:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YYIktkuTURBXy84MzMyNjI2ZC02MDMzLTRkNTItODRhYi02NTJkNDBjODhjY2EuanBlZ5GTBc0BHcyg" />Rok 2023 nie tylko spełnił marzenia o polskim kosmosie, ale znacznie je przekroczył. Był świadkiem iście kopernikańskiego przewrotu dla technologii kosmicznych w Polsce - czytamy we wtorkowym komunikacie Polskiej Agencji Kosmicznej.

## Izrael zaatakował przedmieścia Damaszku, powodując "straty materialne"
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9393342,izrael-zaatakowal-przedmiescia-damaszku-powodujac-straty-materialne.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9393342,izrael-zaatakowal-przedmiescia-damaszku-powodujac-straty-materialne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T12:51:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eM-ktkuTURBXy82YjA3NWI3My04YTFiLTRhOTYtYmMxYS1hMDQ3OGJmMWM2MjcuanBlZ5GTBc0BHcyg" />Armia syryjska przekazała, że atak Izraela &quot;na przedmieścia Damaszku&quot; spowodował we wtorek rano &quot;straty materialne&quot; - podała rządowa agencja SANA. Natomiast wojsko izraelskie powiadomiło, że w odpowiedzi na wcześniejszy syryjski ostrzał rakietowy północnego Izraela przeprowadziło atak na &quot;infrastrukturę armii syryjskiej&quot;.

## O ile wzrosły ceny mieszkań w czwartym kwartale 2023 roku?
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9393303,o-ile-wzrosly-ceny-mieszkan-w-czwartym-kwartale-2023-roku.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9393303,o-ile-wzrosly-ceny-mieszkan-w-czwartym-kwartale-2023-roku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T11:56:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vftktkuTURBXy9iYjBhOGQwMy0yYWVkLTRkYzktYTgwOS0zMmRhZTA0NGY0MzMuanBlZ5GTBc0BHcyg" />W IV kwartale 2023 r. średnia cena mieszkań w ofercie deweloperów wzrosła o 2 proc., najbardziej - o 10 proc. w Trójmieście - wynika z opublikowanych we wtorek raportu portalu RynekPierwotny.pl.

## Holandia wycofała zezwolenie na eksport do Chin niektórych maszyn do produkcji czipów
 - [https://forsal.pl/lifestyle/technologie/artykuly/9393281,holandia-wycofala-zezwolenie-na-eksport-do-chin-niektorych-maszyn-do-p.html](https://forsal.pl/lifestyle/technologie/artykuly/9393281,holandia-wycofala-zezwolenie-na-eksport-do-chin-niektorych-maszyn-do-p.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T11:24:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jjZktkuTURBXy9hZGUxNWRjZC0wNTAzLTRlZmEtYTE2OC0yOGZkNzM2NDYxZmQuanBlZ5GTBc0BHcyg" />Holenderski rząd zakazał producentowi maszyn do produkcji czipów firmie ASML eksportowania do Chin niektórych urządzeń pracujących w głębokim ultrafiolecie (DUV) - poinformowała firma w poniedziałek w komunikacie prasowym. Decyzja została podjęta pod naciskiem USA - komentują media.

## Zełenski: W rosyjskim ataku zginęły cztery osoby, a 92 zostały ranne
 - [https://forsal.pl/swiat/ukraina/artykuly/9393262,zelenski-w-rosyjskim-ataku-zginely-cztery-osoby-a-92-zostaly-ranne.html](https://forsal.pl/swiat/ukraina/artykuly/9393262,zelenski-w-rosyjskim-ataku-zginely-cztery-osoby-a-92-zostaly-ranne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T10:53:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KF-ktkuTURBXy8wZTc5ZjUzMy1iZjBkLTQ1ZDYtYjMxNy01ZDkzMjFlMmE5ZGIuanBlZ5GTBc0BHcyg" />Cztery osoby zginęły, a 92 zostały ranne we wtorek w rosyjskim ataku na Ukrainę: Kijów, obwód kijowski i Charków - poinformował we wtorek ukraiński prezydent Wołodymyr Zełenski.

## Bank Handlowy ma zgodę KNF na buy-back, program skupu potrwa do 29 grudnia 2024 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9393259,bank-handlowy-ma-zgode-knf-na-buy-back-program-skupu-potrwa-do-29-gru.html](https://forsal.pl/finanse/gielda/artykuly/9393259,bank-handlowy-ma-zgode-knf-na-buy-back-program-skupu-potrwa-do-29-gru.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T10:49:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IwNktkuTURBXy9iODY2ZWM0NC0xZmY1LTQ4MzctYTZiYS0wYzU1OTViNDM4NDYuanBlZ5GTBc0BHcyg" />undefined

## KNF zatwierdziła prospekt Bloober Team w zw. z przeniesieniem notowań na rynek główny GPW
 - [https://forsal.pl/finanse/gielda/artykuly/9393255,knf-zatwierdzila-prospekt-bloober-team-w-zw-z-przeniesieniem-notowan.html](https://forsal.pl/finanse/gielda/artykuly/9393255,knf-zatwierdzila-prospekt-bloober-team-w-zw-z-przeniesieniem-notowan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T10:41:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fhiktkuTURBXy9kNzM5MjRmZi00MGMyLTQ2ODUtOWI3YS0wNzg5ODIwMzZiMzUuanBlZ5GTBc0BHcyg" />undefined

## AC SA miało wstępnie 68,67 mln zł przychodów w IV kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9393247,ac-sa-mialo-wstepnie-6867-mln-zl-przychodow-w-iv-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/9393247,ac-sa-mialo-wstepnie-6867-mln-zl-przychodow-w-iv-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T10:19:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hZ5ktkuTURBXy85ZDYyNDNjYi1mMTQzLTQzZGUtYTQyMS0xNGQ2YWVhNmQ3MTcuanBlZ5GTBc0BHcyg" />undefined

## PIE: Kolejne kwartały przyniosą odbicie aktywności przemysłu
 - [https://forsal.pl/gospodarka/artykuly/9393237,pie-kolejne-kwartaly-przyniosa-odbicie-aktywnosci-przemyslu.html](https://forsal.pl/gospodarka/artykuly/9393237,pie-kolejne-kwartaly-przyniosa-odbicie-aktywnosci-przemyslu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T10:08:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/z2QktkuTURBXy85ZjRjYzFiMi1iNTQxLTQ4OTUtYmEyNi1iNDZkY2M4YTBjYzkuanBlZ5GTBc0BHcyg" />Nadchodzące miesiące przyniosą odbicie aktywności przemysłu oraz poprawę wyników badań koniunktury - ocenił we wtorek Jakub Rybacki z Polskiego Instytutu Ekonomicznego w komentarzu do danych o PMI. Motorem przemysłu będzie produkcja dóbr konsumpcyjnych np. mebli - dodał.

## Walka o dane, regulacje i personalizacja. Najważniejsze trendy AI w 2024 roku
 - [https://forsal.pl/lifestyle/technologie/artykuly/9393235,walka-o-dane-regulacje-i-personalizacja-najwazniejsze-trendy-ai-w-20.html](https://forsal.pl/lifestyle/technologie/artykuly/9393235,walka-o-dane-regulacje-i-personalizacja-najwazniejsze-trendy-ai-w-20.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T10:06:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LcQktkuTURBXy9lN2M1NzFmYi05MmE4LTQ1ZjgtODYwMy1kNmM3MDJmMjFhZjEuanBlZ5GTBc0BHcyg" />Jednym z najważniejszych trendów ubiegłego roku była sztuczna inteligencja. Po tym jak OpenAI wypuściło do powszechnego użytku ChatGPT, technologia trafiła pod strzechy przeciętnych użytkowników internetu. Ten ruch zmusił wszystkie firmy, które do tej pory pracowały nad AI do wyłożenia kart na stół. Dlatego niemal każdy tydzień 2023 przynosił informacje o przełomowych produktach.

## Koronawirus w Polsce: 69 zakażeń, nie było przypadków śmiertelnych [DANE Z 2.01]
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-69-zakazen-nie-bylo-przypadkow-smiertelnych-da.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-69-zakazen-nie-bylo-przypadkow-smiertelnych-da.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T09:39:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 69 zakażeń koronawirusem, w tym 13 ponownych. Z powodu COVID-19 nie zmarł żaden pacjent – poinformowano we wtorek na stronach rządowych. Wykonano 635 testy w kierunku SARS-CoV-2.

## W jakiej kondycji jest polski przemysł? Mamy odczyt ważnego wskaźnika
 - [https://forsal.pl/gospodarka/artykuly/9393184,w-jakiej-kondycji-jest-polski-przemysl-mamy-odczyt-waznego-wskaznika.html](https://forsal.pl/gospodarka/artykuly/9393184,w-jakiej-kondycji-jest-polski-przemysl-mamy-odczyt-waznego-wskaznika.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T08:31:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/plTktkuTURBXy9kYWQxZGM2My1lZjAyLTQxODctODYxMi03ZTYzZGMzY2JjMmYuanBlZ5GTBc0BHcyg" />Wskaźnik PMI dla przemysłu w Polsce w grudniu 2023 r. wyniósł 47,4 pkt. wobec 48,7 pkt. w listopadzie - podał S&amp;amp;P Global.

## Adam Bodnar ws. zmian w Trybunale Konstytucyjnym: Uważam, że uchwała jest niewystarczająca
 - [https://forsal.pl/gospodarka/polityka/artykuly/9393165,adam-bodnar-ws-zmian-w-trybunale-konstytucyjnym-uwazam-ze-uchwala-j.html](https://forsal.pl/gospodarka/polityka/artykuly/9393165,adam-bodnar-ws-zmian-w-trybunale-konstytucyjnym-uwazam-ze-uchwala-j.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T08:13:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wV4ktkuTURBXy8xMTk1YThmZC05ZDIwLTRjNzAtOTMyNC0wOWExMzNjOGNjN2QuanBlZ5GTBc0BHcyg" />Minister sprawiedliwości Adam Bodnar zapytany o zmiany w Trybunale Konstytucyjnym powiedział we wtorkowym tygodniku Newsweek, że uważa, że uchwała w tej sprawie jest niewystarczająca.

## Świat koreańskiej polityki wstrzymał oddech. Lider opozycji dźgnięty nożem
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9393155,swiat-koreanskiej-polityki-wstrzymal-oddech-lider-opozycji-dzgniety-n.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9393155,swiat-koreanskiej-polityki-wstrzymal-oddech-lider-opozycji-dzgniety-n.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T07:52:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ACfktkuTURBXy81YTEyMDA1OS1hZTA4LTQ5MTItYWFhNy04YTFiYjQzYTNkMWEuanBlZ5GTBc0BHcyg" />Lider opozycyjnej Partii Demokratycznej Korei Południowej Lee Jae-myung, który we wtorek został dźgnięty nożem w szyję podczas konferencji prasowej w Busan, nie jest w stanie zagrażającym jego życiu – poinformował szpital w Busan.

## Trwa rosyjski nalot na Kijów. Miasto opanowały eksplozje i pożary
 - [https://forsal.pl/swiat/ukraina/artykuly/9393147,trwa-rosyjski-nalot-na-kijow-miasto-opanowaly-eksplozje-i-pozary.html](https://forsal.pl/swiat/ukraina/artykuly/9393147,trwa-rosyjski-nalot-na-kijow-miasto-opanowaly-eksplozje-i-pozary.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T07:47:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZcZktkuTURBXy82MzEwMWNkZC1jZGE1LTRlZmUtYjg0MS00ZDJiNzMxM2JkYzAuanBlZ5GTBc0BHcyg" />Na całej Ukrainie we wtorek rano trwa alarm przeciwlotniczy, wojsko rosyjskie zaatakowało m.in. Kijów, w którym słychać eksplozje - informują media i lokalne władze. W Kijowie doszło do pożarów, w kilku dzielnicach spadły odłamki rakiet - przekazał mer ukraińskiej stolicy Witalij Kliczko.

## Atak na lidera opozycji w Korei Południowej
 - [https://forsal.pl/swiat/artykuly/9393146,atak-na-lidera-opozycji-w-korei-poludniowej.html](https://forsal.pl/swiat/artykuly/9393146,atak-na-lidera-opozycji-w-korei-poludniowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T07:45:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ACfktkuTURBXy81YTEyMDA1OS1hZTA4LTQ5MTItYWFhNy04YTFiYjQzYTNkMWEuanBlZ5GTBc0BHcyg" />Lider opozycyjnej Partii Demokratycznej Korei Południowej Lee Jae-myung, który we wtorek został dźgnięty nożem w szyję podczas konferencji prasowej w Busan, nie jest w stanie zagrażającym jego życiu – poinformował szpital w Busan.

## MON: Mamy pewność, że rakieta, która w piątek naruszyła polską przestrzeń, opuściła terytorium kraju
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9393141,mon-mamy-pewnosc-ze-rakieta-ktora-w-piatek-naruszyla-polska-przestr.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9393141,mon-mamy-pewnosc-ze-rakieta-ktora-w-piatek-naruszyla-polska-przestr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T07:41:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fshktkuTURBXy80ODRmNzFmYy04ZmU5LTQyMjctODYxZi03Mjg0ZDI3ZmMzODAuanBlZ5GTBc0BHcyg" />Mamy pewność, że rosyjska rakieta, która w piątek naruszyła polską przestrzeń powietrzną, opuściła terytorium naszego kraju; mamy potwierdzenie z radarów polskich i sojuszniczych, skierowaliśmy też żołnierzy do poszukiwań na lądzie - powiedział we wtorek w RMF FM wiceszef MON Paweł Zalewski.

## Wybory prezydenckie w 2024 r. w Meksyku po raz pierwszy może wygrać kobieta
 - [https://forsal.pl/swiat/artykuly/9393137,wybory-prezydenckie-w-2024-r-w-meksyku-po-raz-pierwszy-moze-wygrac-ko.html](https://forsal.pl/swiat/artykuly/9393137,wybory-prezydenckie-w-2024-r-w-meksyku-po-raz-pierwszy-moze-wygrac-ko.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T07:35:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bLCktkuTURBXy8zYzEzZTY5MS1hMDM1LTRlN2MtOGJjYy0zNjZkZTVhYjA5NGIuanBlZ5GTBc0BHcyg" />Po raz pierwszy w historii Meksyku prezydentem kraju może zostać kobieta. Do głównych kandydatek w wyborach prezydenckich w czerwcu 2024 roku analitycy zaliczają Claudię Sheinbaum Pardo i Xochitlę Galvez.

## 30 ofiar poniedziałkowego trzęsienia ziemi w Japonii. W żadnej elektrowni atomowej nie doszło do awarii [AKTUALIZACJA]
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9393134,5-ofiar-poniedzialkowego-trzesienia-ziemi-w-japonii-w-zadnej-elektrow.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9393134,5-ofiar-poniedzialkowego-trzesienia-ziemi-w-japonii-w-zadnej-elektrow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T07:24:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0vaktkuTURBXy9iNTZkNWFiNy1kZmM1LTQ5ZTktOWNkMy1hM2EzZmY0ODc4ODQuanBlZ5GTBc0BHcyg" />W potężnym trzęsieniu ziemi, które nawiedziło środkową Japonię w Nowy Rok, znaleziono ciała 30 osób, poinformowały we wtorek rano policja i władze lokalne prowadzące akcje ratownicze w gruzach zawalonych budynków.

## Wysokie stopy procentowe i kłopoty na rynku kredytowym. NBP boryka się z wysokimi kosztami działalności
 - [https://forsal.pl/gospodarka/stopy-procentowe/artykuly/9393113,wysokie-stopy-procentowe-i-klopoty-na-rynku-kredytowym-nbp-boryka-sie.html](https://forsal.pl/gospodarka/stopy-procentowe/artykuly/9393113,wysokie-stopy-procentowe-i-klopoty-na-rynku-kredytowym-nbp-boryka-sie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T07:05:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kOWktkuTURBXy85Y2ZjYjNmOS02MDZlLTQwMjktYWVmNC1kNGFmYzA3ZWUyNmUuanBlZ5GTBc0BHcyg" />Do straty za 2023 r. przyczyniły się nie tylko aprecjacja złotego, lecz także wysokie koszty operacji otwartego rynku

## Nowy wiceminister i pieniądze z UE, czyli szansa na kolejowe przyspieszenie
 - [https://forsal.pl/transport/kolej/artykul-prasowy/9393106,nowy-wiceminister-i-pieniadze-z-ue-czyli-szansa-na-kolejowe-przyspies.html](https://forsal.pl/transport/kolej/artykul-prasowy/9393106,nowy-wiceminister-i-pieniadze-z-ue-czyli-szansa-na-kolejowe-przyspies.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T06:58:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/g9XktkuTURBXy84ZWRmMTcwYi02NzIyLTRhNzYtYWY5Mi1hZWFiNzNiMDVlZmEuanBlZ5GTBc0BHcyg" />20 mld zł mają być warte przetargi na modernizację torów, które w 2024 r. ogłosi PKP PLK. Inwestycje będzie nadzorował nowy wiceminister infrastruktury Piotr Malepszak

## Czarta władza odbita z rąk PiS. Platforma domyka przejęcie mediów
 - [https://forsal.pl/biznes/media/artykuly/9392954,czarta-wladza-odbita-z-rak-pis-platforma-domyka-przejecie-mediow.html](https://forsal.pl/biznes/media/artykuly/9392954,czarta-wladza-odbita-z-rak-pis-platforma-domyka-przejecie-mediow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T06:53:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Na_ktkuTURBXy9hZDkyYjc5OC0wY2RkLTRkYTAtYmU4OC1hYzBmNjc4ZjNiMTkuanBlZ5GTBc0BHcyg" />Minister kultury stawia w stan likwidacji kolejne spółki. Opozycja przyznaje, że ujawnienie zarobków byłych dziennikarzy TVP nie ułatwia organizacji protestów

## Czwarta władza odbita z rąk PiS. Platforma domyka przejęcie mediów
 - [https://forsal.pl/biznes/media/artykuly/9392954,czwarta-wladza-odbita-z-rak-pis-platforma-domyka-przejecie-mediow.html](https://forsal.pl/biznes/media/artykuly/9392954,czwarta-wladza-odbita-z-rak-pis-platforma-domyka-przejecie-mediow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T06:53:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Na_ktkuTURBXy9hZDkyYjc5OC0wY2RkLTRkYTAtYmU4OC1hYzBmNjc4ZjNiMTkuanBlZ5GTBc0BHcyg" />Minister kultury stawia w stan likwidacji kolejne spółki. Opozycja przyznaje, że ujawnienie zarobków byłych dziennikarzy TVP nie ułatwia organizacji protestów

## Wojczal: Ukraińcy są bez szans. Wcześniej czy później przegrają
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9392934,wojczal-ukraincy-sa-bez-szans-wczesniej-czy-pozniej-przegraja.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9392934,wojczal-ukraincy-sa-bez-szans-wczesniej-czy-pozniej-przegraja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T06:44:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4j3ktkuTURBXy84NDc1NDI4YS0xYzY0LTRlMDYtOGUxZS1mZjFjYTM1NTY3MTcuanBlZ5GTBc0BHcyg" />Nawet przy założeniu, że Donald Tusk jest zakładnikiem swojej wdzięczności za niemieckie poparcie dla jego kandydatury na szefa Rady Europejskiej, to w jego własnym interesie i ambicjach będzie zmniejszanie własnej zależności od zachodnich polityków oraz dotychczasowych powiązań – mówi DGP Krzysztof Wojczal

## Ciemna strona wzrostu płacy minimalnej. Trudniej będzie odzyskać dług
 - [https://forsal.pl/gospodarka/prawo/artykuly/9392780,ciemna-strona-wzrostu-placy-minimalnej-trudniej-bedzie-odzyskac-dlug.html](https://forsal.pl/gospodarka/prawo/artykuly/9392780,ciemna-strona-wzrostu-placy-minimalnej-trudniej-bedzie-odzyskac-dlug.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T06:37:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JMbktkuTURBXy8xYjYwYTlkYi1mMzc3LTQwMDAtOTUwNy0wNThhNDQxMjhjYzAuanBlZ5GTBc0BHcyg" />Od Nowego Roku kwota wolna od zajęcia przy egzekucji z wynagrodzenia za pracę wzrosła z 2700 zł do 3181,5 zł. Przepisy nie tylko faworyzują dłużników względem wierzycieli, lecz także stawiają w gorszej pozycji dłużników będących emerytami

## Walka z wiatrakami. Jak sprawić, żeby dekarbonizacja nie budziła takich kontrowersji?
 - [https://forsal.pl/biznes/ekologia/artykuly/9391206,walka-z-wiatrakami-jak-sprawic-zeby-dekarbonizacja-nie-budzila-takic.html](https://forsal.pl/biznes/ekologia/artykuly/9391206,walka-z-wiatrakami-jak-sprawic-zeby-dekarbonizacja-nie-budzila-takic.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T06:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/un6ktkuTURBXy9lOWIwN2FlYy1jZmMxLTQyZmYtOTFmNy0wYmZlZDZhOTY4MWYuanBlZ5GTBc0BHcyg" />Premier Donald Tusk odniósł się w exposé do nieudanej próby liberalizacji przepisów o wiatrakach. Prezentując nowych ministrów, starał się odpierać oskarżenia o wywłaszczenia, lobbing i płatną protekcję. Podkreślał wagę sprawiedliwej transformacji i dialogu społecznego jako priorytetów nowego rządu. Jak sprawić, żeby te deklaracje nie stały się słowami rzucanymi na wiatr? Piszą Jakub Sokołowski i Jan Frankowski z Instytutu Badań Strukturalnych.

## Dlaczego Polki nie chcą rodzić? Czynniki ekonomiczne są drugorzędne
 - [https://forsal.pl/gospodarka/demografia/artykuly/9391821,dlaczego-polki-nie-chca-rodzic-czynniki-ekonomiczne-sa-drugorzedne.html](https://forsal.pl/gospodarka/demografia/artykuly/9391821,dlaczego-polki-nie-chca-rodzic-czynniki-ekonomiczne-sa-drugorzedne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wTZktkuTURBXy9hZGVmYmY2MS02ZDJmLTQzNDgtYjU4Ny1kZDgxNDhiMTk4ZmIuanBlZ5GTBc0BHcyg" />Nowy raport Instytutu Pokolenia przybliża nam sytuację demograficzną Polski. Badacz dr Karol Leszczyński przygląda się bezdzietnym kobietom w Polsce. Wnioski? Czynniki ekonomiczne grają rolę drugorzędną. Nie ma jednak jednego konkretnego powodu — rosnąca bezdzietność to wynik wielu czynników. W raporcie wskazano ich kilkanaście.

## Polityczna bezalternatywa w USA. O prezydenturę zawalczą zapewne Trump z Bidenem
 - [https://forsal.pl/swiat/usa/artykuly/9391046,polityczna-bezalternatywa-w-usa-o-prezydenture-zawalcza-zapewne-trump.html](https://forsal.pl/swiat/usa/artykuly/9391046,polityczna-bezalternatywa-w-usa-o-prezydenture-zawalcza-zapewne-trump.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AxqktkuTURBXy8zYzIwYzJhMi1iNjQxLTRmYzItYjNmOC1jMWZjOGZiYTNmYjQuanBlZ5GTBc0BHcyg" />Minął rok, a w USA nie zmieniło się za wiele. Ani 81-letni Joe Biden ani 77-letni Donald Trump wciąż nie mają w swoich partiach wielkiej konkurencji i mimo że obaj mają pokaźny negatywny elektorat, to nie widać alternatywy dla tych wiekowych już polityków. Ich ponowne wyborcze starcie o Biały Dom jest w listopadzie coraz bardziej prawdopodobne.

## Wielkanoc. Kiedy w 2024 r. wypada to święto?
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/9388783,wielkanoc-kiedy-w-2024-r-wypada-to-swieto.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/9388783,wielkanoc-kiedy-w-2024-r-wypada-to-swieto.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-01-02T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hR5ktkuTURBXy80ZWIzOTJiYi0yYjg1LTRhMmItYmMwZC1kMGZjNjEwNjQ2ZmMuanBlZ5GTBc0BHcyg" />Wielkanoc, będąca najstarszym i najważniejszym świętem chrześcijańskim, upamiętnia zmartwychwstanie Jezusa Chrystusa. W Polsce tradycje wielkanocne są głęboko zakorzenione w kulturze i obejmują zarówno aspekty religijne, jak i społeczne.

