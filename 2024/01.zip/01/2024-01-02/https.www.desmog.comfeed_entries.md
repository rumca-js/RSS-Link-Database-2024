# Source:DeSmog, URL:https://www.desmog.com/feed/, language:en-US

## Dark Money, CCS Bonanza, Corporate Comms Offensives: What to Watch in 2024
 - [https://www.desmog.com/2024/01/02/dark-money-ccs-corporate-pr-issues-2024](https://www.desmog.com/2024/01/02/dark-money-ccs-corporate-pr-issues-2024)
 - RSS feed: https://www.desmog.com/feed/
 - date published: 2024-01-02T09:00:00+00:00

<p>If you care about maintaining a livable climate, stay tuned for a big 2024. Major elections are coming in both the UK and U.S., and expect corporate money, and talking points, to be flowing. Global climate leadership is on the line, and we’ll be reporting whether it’s also for sale.&#160; On the heels of COP28, [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2024/01/02/dark-money-ccs-corporate-pr-issues-2024/">Dark Money, CCS Bonanza, Corporate Comms Offensives: What to Watch in 2024</a> appeared first on <a href="https://www.desmog.com">DeSmog</a>.</p>

