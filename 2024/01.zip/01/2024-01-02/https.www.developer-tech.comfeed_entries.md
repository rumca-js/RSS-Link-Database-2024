# Source:Developer Tech News, URL:https://www.developer-tech.com/feed/, language:en-GB

## App Store antitrust case is ‘firing on all cylinders’
 - [https://www.developer-tech.com/news/2024/jan/02/app-store-antitrust-case-firing-on-all-cylinders](https://www.developer-tech.com/news/2024/jan/02/app-store-antitrust-case-firing-on-all-cylinders)
 - RSS feed: https://www.developer-tech.com/feed/
 - date published: 2024-01-02T15:18:57+00:00

<p>Jonathan Kanter, the head of the Department of Justice&#8217;s antitrust unit, is intensifying the case against Apple over its App Store policies. According to the Financial Times, Kanter – who assumed the role in November 2021 – has stated that the investigation is now &#8220;firing on all cylinders.&#8221; For years, regulators, businesses, and enforcers have<a class="excerpt-read-more" href="https://www.developer-tech.com/news/2024/jan/02/app-store-antitrust-case-firing-on-all-cylinders/" title="ReadApp Store antitrust case is &#8216;firing on all cylinders&#8217;">... Read more &#187;</a></p>
<p>The post <a href="https://www.developer-tech.com/news/2024/jan/02/app-store-antitrust-case-firing-on-all-cylinders/">App Store antitrust case is &#8216;firing on all cylinders&#8217;</a> appeared first on <a href="https://www.developer-tech.com">Developer Tech News</a>.</p>

