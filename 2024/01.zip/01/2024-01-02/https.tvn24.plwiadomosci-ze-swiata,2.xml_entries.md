# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Samolot pasażerski w ogniu. Moment katastrofy na nagraniu
 - [https://tvn24.pl/swiat/japonia-samolot-pasazerski-w-ogniu-moment-katastrofy-na-nagraniu-7682889?source=rss](https://tvn24.pl/swiat/japonia-samolot-pasazerski-w-ogniu-moment-katastrofy-na-nagraniu-7682889?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-01-02T10:37:47+00:00

<img alt="Samolot pasażerski w ogniu. Moment katastrofy na nagraniu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gx2a8p-japonia-4-7682880/alternates/LANDSCAPE_1280" />
    Japońskie media pokazały nagranie ukazujące moment wybuchu pożaru samolotu japońskich linii lotniczych. Na zdjęciach widać maszynę z blisko 400 osobami na pokładzie, która chwilę po lądowaniu zamienia się w sunącą po pasie startowym kulę ognia.

## IMGW ostrzega. Śnieżyce w czterech województwach, ulewy w części kraju
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-sniegu-ulewy-zima-wraca-do-polski-st7682425?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-intensywne-opady-sniegu-ulewy-zima-wraca-do-polski-st7682425?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-01-02T06:15:56+00:00

<img alt="IMGW ostrzega. Śnieżyce w czterech województwach, ulewy w części kraju" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8opp2q-intensywne-opady-sniegu-5624324/alternates/LANDSCAPE_1280" />
    IMGW wydał alerty meteorologiczne. We wschodniej Polsce obowiązuje ostrzeżenie przed intensywnymi opadami śniegu - może spaść go nawet do 15 centymetrów. Na południowym zachodzie kraju zagrożenie stanowić będą natomiast ulewy i roztopy.

## Alarm powietrzny na terenie całej Ukrainy. "Szczątki dronów płoną"
 - [https://tvn24.pl/swiat/ukraina-alarm-powietrzny-na-terenie-calego-kraju-7682405?source=rss](https://tvn24.pl/swiat/ukraina-alarm-powietrzny-na-terenie-calego-kraju-7682405?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2024-01-02T05:09:13+00:00

<img alt="Alarm powietrzny na terenie całej Ukrainy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3d6pec-atak-na-kijow-7316647/alternates/LANDSCAPE_1280" />
    W Kijowie słychać eksplozje, Ukraina próbuje odeprzeć atak rosyjskich dronów na swoją stolicę – podały we wtorek rano władze miasta. Ukraińskie wojsko ogłosiło alarm powietrzny na terenie całego kraju i ostrzegło, że istnieje ryzyko wystrzelenia rosyjskich rakiet ze zbliżających się do Ukrainy rosyjskich bombowców.

