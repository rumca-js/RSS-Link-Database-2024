# Source:GeekWire, URL:https://www.geekwire.com/feed/, language:en-US

## Tech investors give their top predictions for 2024
 - [https://www.geekwire.com/2024/tech-investors-give-their-top-predictions-for-2024](https://www.geekwire.com/2024/tech-investors-give-their-top-predictions-for-2024)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2024-01-02T16:11:12+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="1214" src="https://cdn.geekwire.com/wp-content/uploads/2024/01/Screen-Shot-2024-01-01-at-6.36.54-PM.png" width="1214" /><br />The pace of AI-related innovation accelerated, to say the least, in 2023. Expect the same this year — or even more. That&#8217;s the word from a group of Seattle-area tech investors who shared their top prediction for the new year. Read on for their takes. Madin Akpo-Esambe, investor at Tacoma Venture Fund &#8220;Next year will bring an unprecedented wave of startup acquisitions and wind downs, but we&#8217;ll start to see the early innings of the next wave of future unicorns with proven applied AI innovations emerge. The genie is certainly out of the bottle on AI as a fundamental platform shift and it&#8217;s here to stay. Similar&#8230; <a href="https://www.geekwire.com/2024/tech-investors-give-their-top-predictions-for-2024/">Read More</a>

