# Source:Engadget, URL:https://www.engadget.com/rss.xml, language:en-US

## Samsung's first Unpacked event of 2024 will take place on January 17
 - [https://www.engadget.com/samsungs-first-unpacked-event-of-2024-will-take-place-on-january-17-230040664.html?src=rss](https://www.engadget.com/samsungs-first-unpacked-event-of-2024-will-take-place-on-january-17-230040664.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T23:00:40+00:00

<p>Samsung’s Unpacked event is coming early this year, so set your calendar for January 17 at 1PM ET. Typically, these events drop the first week of February, so this is an interesting switch-up, given the proximity to CES 2024. This will be an in-person event, at the SAP Center in San Jose, but will also be live streamed across Samsung’s various channels, <a href="https://www.youtube.com/channel/UCWwgaK7x0_FR1goeSRazfsQ"><ins>including YouTube.</ins></a></p>
<p>This is Samsung, so it’s not advertising any details regarding this year’s Unpacked. We do, however, have some ideas. It’s highly likely the company will not only announce the arrival of the Galaxy S24 flagship smartphone series, but will open up pre-orders immediately following the event. To that end, the company has already started a “pre-reserve” program in which you plop down your name and email address to pre-order, well, something.</p>
<span id="end-legacy-contents"></span><p>You won’t know what you’ve pre-ordered until

## Samsung reveals three anti-glare Odyssey OLED gaming monitors ahead of CES 2024
 - [https://www.engadget.com/samsung-reveals-three-anti-glare-odyssey-oled-gaming-monitors-ahead-of-ces-2024-230028536.html?src=rss](https://www.engadget.com/samsung-reveals-three-anti-glare-odyssey-oled-gaming-monitors-ahead-of-ces-2024-230028536.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T23:00:28+00:00

<p>Samsung has released some details regarding a trio of forthcoming Odyssey gaming monitors, just ahead of CES 2024. These are all OLED displays with AMD FreeSync Premium Pro and VESA DisplayHDR True Black 400. Each monitor also features the company’s proprietary anti-glare technology that minimizes daylight and ambient light reflections.</p>
<p>First up, there’s the 49-inch Samsung Odyssey OLED G95SD curved ultra-wide monitor. The screen offers DQHD (5120x1440) resolution, a 0.03ms response time, a 240Hz refresh rate, a 32:9 aspect ratio and access to both Samsung’s smart TV platform and the company’s cloud-based Gaming Hub. The aesthetics are on point, with a slim form factor and a slightly smaller size <a href="https://www.engadget.com/samsung-odyssey-ark-review-55-inch-gaming-monitor-160004552.html">than the mammoth Odyssey Ark.</a></p>
<span id="end-legacy-contents"></span><figure><img alt="Monitor on white background." src="https://s.yimg.com/os/creatr-uploaded-images/2024-01/

## Apple's AirPods Pro with USB-C are back down to $190 right now
 - [https://www.engadget.com/apples-airpods-pro-with-usb-c-are-back-down-to-190-right-now-153404826.html?src=rss](https://www.engadget.com/apples-airpods-pro-with-usb-c-are-back-down-to-190-right-now-153404826.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T15:34:04+00:00

<p>If you've got some gift card money to spend after the holidays and are looking to grab a new pair of wireless earphones, here's a deal worth noting: <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hbWF6b24uY29tL2RwL0IwQ0hXUlhIOEI_dGFnPWdkZ3QwYy1wLW8tNWFmLTIwIiwiY29udGVudFV1aWQiOiI5NWI3ODhjZC0zMTU1LTQ0ODMtOTMwYi0xNDE1Y2FjZjFjZDQifQ&amp;signature=AQAAAf-R_en0r9xeKYzPV5rC3P9fFBhlSRZo6TCwIOzwHnDK&amp;gcReferrer=https%3A%2F%2Fwww.amazon.com%2Fdp%2FB0CHWRXH8B">Apple's AirPods Pro</a> are back on sale for $190 at Amazon, <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=827d7835-78d6-4491-ae04-c042cab1d6e7&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Target&amp;cus

## Square Enix plans 'aggressive' use of AI to create new forms of content
 - [https://www.engadget.com/square-enix-plans-aggressive-use-of-ai-to-create-new-forms-of-content-141602313.html?src=rss](https://www.engadget.com/square-enix-plans-aggressive-use-of-ai-to-create-new-forms-of-content-141602313.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T14:16:02+00:00

<p>Generative AI provoked a lot of discussion last year around <a href="https://www.engadget.com/the-morning-after-the-cost-of-generating-ai-images-121549213.html">images</a>, text and <a href="https://www.engadget.com/the-ai-startup-behind-stable-diffusion-is-now-testing-generative-video-105519658.html">video</a>, but it may soon affect the gaming industry as well. Square Enix said it plans to be &quot;aggressively applying&quot; AI and other cutting-edge tech in 2024 to &quot;create new forms of content,&quot; according to president Takashi Kiryu's <a href="https://www.hd.square-enix.com/eng/news/2024/html/a_new_years_letter_from_the_president_4.html">New Year's letter</a>.&nbsp;</p>
<p>&quot;Artificial intelligence (AI) and its potential implications had for some time largely been subjects of academic debate,&quot; he said. &quot;However, the introduction of ChatGPT, which allows anyone to easily produce writing or translations or to engage in text-based dialogue, sparked the rapi

## LG's DukeBox puts vacuum tube audio behind a transparent OLED display
 - [https://www.engadget.com/lgs-dukebox-puts-vacuum-tube-audio-behind-a-transparent-oled-display-125526158.html?src=rss](https://www.engadget.com/lgs-dukebox-puts-vacuum-tube-audio-behind-a-transparent-oled-display-125526158.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T12:55:26+00:00

<p><a href="https://www.engadget.com/ces-2024-what-we-expect-in-las-vegas-this-year-140040145.html">CES 2024</a> is just around the corner and tech companies are already providing sneak peeks of what we can expect to see on the ground in Las Vegas. LG is bringing a range of wonderful, weird gadgets to the showcase, including the newly announced <a href="https://www.lgnewsroom.com/2024/01/lg-unveils-a-spectrum-of-cutting-edge-solutions-showcasing-its-creative-essence/">DukeBox by LG Labs</a>. The audio device marries old and new with vacuum tube audio working alongside transparent OLED panel technology.&nbsp;</p>
<p>Vacuum tube audio has been around for over 100 years and is beloved for its ability to produce a warm sound quality that highlights each instrument — almost creating the sense that musicians are playing the music live. The DukeBox utilizes this technology alongside front-facing bottom speakers and 360-degree speakers on top. The vacuum pipes remain visible for an extra ret

## The Morning After: Tech to help stick to your New Year’s resolutions
 - [https://www.engadget.com/the-morning-after-tech-to-help-stick-to-your-new-years-resolutions-121518831.html?src=rss](https://www.engadget.com/the-morning-after-tech-to-help-stick-to-your-new-years-resolutions-121518831.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T12:15:18+00:00

<p>New Year’s <a href="https://www.engadget.com/tech-to-help-you-stick-to-new-years-resolutions-150034002.html">resolutions</a> are usually set with the best <em>intentions</em> – I may have already failed at one of mine already —  but the right tools (and resolution, if I’m honest) can make achieving those goals easier.</p>
<p>Naturally, with all the wearables and smartwatches around, there’s a fitness theme to half of our guide, but smartwatches can help nudge you into better habits and even remind you to meditate, which is something I’ve set up on my Apple Watch this week.</p>
<p>We’ve also got to-do list app recommendations, cable organizing advice (that is a weak-ass New Year resolution) and help on how to cultivate a new reading habit in 2024.</p>
<p>What are your <a href="https://www.engadget.com/tech-to-help-you-stick-to-new-years-resolutions-150034002.html">resolutions</a> for the coming year? And what will you do (or buy) to achieve them?</p>
<p>– Mat Smith</p>
<p>​​<em>You

## The Morning After: Tech to help you stick to your New Year’s resolutions
 - [https://www.engadget.com/the-morning-after-tech-to-help-you-stick-to-your-new-years-resolutions-121518467.html?src=rss](https://www.engadget.com/the-morning-after-tech-to-help-you-stick-to-your-new-years-resolutions-121518467.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T12:15:18+00:00

<p>New Year’s <a href="https://www.engadget.com/tech-to-help-you-stick-to-new-years-resolutions-150034002.html">resolutions</a> are usually set with the best <em>intentions</em> – I may have already failed at one of mine already —  but the right tools (and resolutions, if I’m honest) can make achieving those goals easier.</p>
<p>Naturally, with all the wearables and smartwatches around, there’s a fitness theme to half of our guide, but smartwatches can help nudge you into better habits and even remind you to meditate, which is something I’ve set up on my Apple Watch this week.</p>
<p>We’ve also got to-do list app recommendations, cable organizing advice (that is a weak-ass New Year resolution) and help on how to cultivate a new reading habit in 2024.</p>
<p>What are your <a href="https://www.engadget.com/tech-to-help-you-stick-to-new-years-resolutions-150034002.html">resolutions</a> for the coming year? And what will you do (or buy) to achieve them?</p>
<p>– Mat Smith</p>
<p>​​<em>Yo

## A jarring Tekken 8 colorblind filter is concerning accessibility experts
 - [https://www.engadget.com/a-jarring-tekken-8-colorblind-filter-is-concerning-accessibility-experts-111534565.html?src=rss](https://www.engadget.com/a-jarring-tekken-8-colorblind-filter-is-concerning-accessibility-experts-111534565.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T11:15:34+00:00

<p>The developers of <a href="https://www.engadget.com/tekken-8-will-arrive-on-january-26th-2024-191513374.html"><em>Tekken 8</em></a> are boosting the upcoming game's accessibility with color blind options, but some experts and users say some of the settings may cause more harm than good. One filter in particular that displays horizontal and vertical black and white lines appears to be causing headaches and vertigo, and may even &quot;hospitalize players (or worse), in the same way as the infamous Pokémon episode,&quot; said gaming accessibility specialist Ian Hamilton in a <a href="https://twitter.com/ianhamilton_/status/1740035387991720260">post on X</a>. (We have embedded a still from the game at the bottom of the article. Viewer discretion is advised.)</p>
<p>The various filters were posted by X user @itwhiffed, who said &quot;why is no one talking about the color blind accessibility of Tekken 8.&quot; His post thread shows multiple filters for red, green and blue blindness, wit

## Apple's 10th-gen iPad falls back to a low of $349
 - [https://www.engadget.com/apples-10th-gen-ipad-falls-back-to-a-low-of-349-102057197.html?src=rss](https://www.engadget.com/apples-10th-gen-ipad-falls-back-to-a-low-of-349-102057197.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T10:20:57+00:00

<p>It's a new year and you're going to need fresh tools to accomplish all those goals for 2024. A <a href="https://www.engadget.com/best-ipads-how-to-pick-the-best-apple-tablet-for-you-150054066.html">new iPad</a> is a great way to keep track of and produce lots of tasks, especially when touting a 22 percent discount. That's right, the <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hbWF6b24uY29tL2dwL2F3L2QvQjBCSkxDV0ZOTS8_dGFnPWdkZ3QwYy1wLW8tNWFkLTIwIiwiY29udGVudFV1aWQiOiIxNWIwYjBlMC1kM2Q0LTQxMDEtODIyYi02Y2Y3Y2FmMmZiNmIifQ&amp;signature=AQAAAc7ByOmW9-LGld208Lh78VY9wh4V53TGouJfmpIE1DIm&amp;gcReferrer=https%3A%2F%2Fwww.amazon.com%2Fgp%2Faw%2Fd%2FB0BJLCWFNM%2F">10th-generation Apple iPad 64GB model</a> is back down to its <a href="h

## Meta's Quest 2 headset is about to get even cheaper
 - [https://www.engadget.com/metas-quest-2-headset-is-about-to-get-even-cheaper-090433083.html?src=rss](https://www.engadget.com/metas-quest-2-headset-is-about-to-get-even-cheaper-090433083.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T09:04:33+00:00

<p>Meta is permanently cutting the price of its Quest 2 VR headset to $250 following the launch of the Quest 3, according to a <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5tZXRhLmNvbS9ibG9nL3F1ZXN0L3ByaWNlLWRyb3AtbmV3cy1tZXRhLXF1ZXN0LTIiLCJjb250ZW50VXVpZCI6IjQ4N2M5OGIyLTVkM2ItNGVlYi05M2Y5LTY2NjVkZjVkZDQyOCJ9&amp;signature=AQAAAd1-HOFoFFWpVc0Vd28myqiLcmm7jAeczPrkZNiZlKfK&amp;gcReferrer=https%3A%2F%2Fwww.meta.com%2Fblog%2Fquest%2Fprice-drop-news-meta-quest-2">Quest Blog update</a> spotted by <a href="https://techcrunch.com/2024/01/01/meta-cuts-prices-for-quest-2-headset-and-accessories"><em>TechCrunch</em></a>. The Quest 2 has been on sale at that price since Black Friday anyway, but the new retail price might spell even better deals for the previous-gen model.&nbsp;</p>
<p>"We knew we could do even more

## US reportedly halted ASML's chipmaking machine shipments to China weeks before ban
 - [https://www.engadget.com/us-reportedly-halted-asmls-chipmaking-machine-shipments-to-china-weeks-before-ban-075407978.html?src=rss](https://www.engadget.com/us-reportedly-halted-asmls-chipmaking-machine-shipments-to-china-weeks-before-ban-075407978.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2024-01-02T07:54:07+00:00

<p>NVIDIA may have figured out a way to <a href="https://www.engadget.com/nvidia-nerfed-its-rtx-4090-graphics-card-for-chinese-buyers-thanks-to-us-export-rules-190621145.html">go around the US export restrictions on China</a>, but apparently ASML, the Dutch firm behind the key chipmaking equipment, isn't having much say on this end. According to <a href="https://www.bloomberg.com/news/articles/2024-01-01/us-pushed-asml-to-block-chinese-sales-before-january-deadline"><em>Bloomberg</em></a>, Biden's administration reportedly reached out to ASML &quot;weeks before&quot; the January 1, 2024 export ban deadline, requesting the firm to halt some pre-scheduled shipments of its deep ultraviolet lithography (DUV) machines to its Chinese customers. This came after the <a href="https://www.bloomberg.com/news/articles/2023-10-25/controversial-chip-in-huawei-phone-was-produced-on-asml-machine">revelation</a> that SMIC used ASML tech to manufacture Huawei's latest flagship processor, the 7nm <a hr

