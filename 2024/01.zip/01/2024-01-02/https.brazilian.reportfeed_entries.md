# Source:The Brazilian Report, URL:https://brazilian.report/feed/, language:en-US

## Will Brazil bring back daylight saving time?
 - [https://brazilian.report/society/2024/01/02/lula-daylight-saving-time](https://brazilian.report/society/2024/01/02/lula-daylight-saving-time)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2024-01-02T21:22:09+00:00

<p>The post <a href="https://brazilian.report/society/2024/01/02/lula-daylight-saving-time/">Will Brazil bring back daylight saving time?</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

