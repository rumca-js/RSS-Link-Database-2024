# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Scribus 1.6.0 Release is a Massive Upgrade With New Features
 - [https://news.itsfoss.com/scribus-1-6-release](https://news.itsfoss.com/scribus-1-6-release)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2024-01-02T11:24:02+00:00

Scribus 1.6.0 update is a good way to start the new year!

## 6 Predictions for Linux and Open Source in 2024
 - [https://news.itsfoss.com/predictions-linux-open-source-2024](https://news.itsfoss.com/predictions-linux-open-source-2024)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2024-01-02T10:31:08+00:00

Let's try our hands on fortune-telling!

