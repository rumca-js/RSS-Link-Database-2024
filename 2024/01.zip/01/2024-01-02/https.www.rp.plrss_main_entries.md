# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Sztuka'2023: bezpieczniej było rozmawiać o renesansie niż o polityce
 - [https://www.rp.pl/kultura/art39645481-sztuka-2023-bezpieczniej-bylo-rozmawiac-o-renesansie-niz-o-polityce](https://www.rp.pl/kultura/art39645481-sztuka-2023-bezpieczniej-bylo-rozmawiac-o-renesansie-niz-o-polityce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T19:55:03+00:00

Miniony rok w sztuce nie był tylko czasem afer. Mieliśmy dużych dobrych wystaw.

## Gianluigi Buffon chce zmian w futbolu. Rewolucyjny pomysł wybitnego bramkarza
 - [https://www.rp.pl/pilka-nozna/art39647941-gianluigi-buffon-chce-zmian-w-futbolu-rewolucyjny-pomysl-wybitnego-bramkarza](https://www.rp.pl/pilka-nozna/art39647941-gianluigi-buffon-chce-zmian-w-futbolu-rewolucyjny-pomysl-wybitnego-bramkarza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T19:42:08+00:00

Włoch proponuje zwiększenie wymiarów bramek. Uważa, że dzięki temu będziemy oglądać więcej goli, co wpłynie na atrakcyjność meczów.

## Zadanie Putina wykonane. „Wspaniałe wyniki” rosyjskich linii lotniczych
 - [https://www.rp.pl/transport/art39647921-zadanie-putina-wykonane-wspaniale-wyniki-rosyjskich-linii-lotniczych](https://www.rp.pl/transport/art39647921-zadanie-putina-wykonane-wspaniale-wyniki-rosyjskich-linii-lotniczych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T18:33:00+00:00

Po ogłoszonych przez Kreml sukcesach gospodarki Rosji, także rosyjskie linie lotnicze odcięte od połowy świata przez rozpętaną przez Rosję wojnę, pochwaliły się wzrostem liczby pasażerów i połączeń zagranicznych. Tych danych nie można sprawdzić.

## Eksperci: Monika Jaruzelska nie powinna odpowiadać za słowa Grzegorza Brauna
 - [https://www.rp.pl/prawo-dla-ciebie/art39645531-eksperci-monika-jaruzelska-nie-powinna-odpowiadac-za-slowa-grzegorza-brauna](https://www.rp.pl/prawo-dla-ciebie/art39645531-eksperci-monika-jaruzelska-nie-powinna-odpowiadac-za-slowa-grzegorza-brauna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T18:19:10+00:00

Nawet, jeśli Monika Jaruzelska nie kontrowała niedopuszczalnych zdaniem wielu wypowiedzi posła Grzegorza Brauna, zdaniem ekspertów nie nie można pociągnąć jej do odpowiedzialności za słowa wypowiedziane w wywiadzie.

## W Krakowie wypożyczą e-rowery mieszkańcom. Można już składać wnioski
 - [https://regiony.rp.pl/transport/art39647021-w-krakowie-wypozycza-e-rowery-mieszkancom-mozna-juz-skladac-wnioski](https://regiony.rp.pl/transport/art39647021-w-krakowie-wypozycza-e-rowery-mieszkancom-mozna-juz-skladac-wnioski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T17:31:08+00:00

Od 2 stycznia 2024 roku mieszkańcy Krakowa mogą przesyłać wnioski w sprawie długoterminowego wynajmu rowerów elektrycznych. Do tej pory można było wypożyczać w ten sposób tylko rowery tradycyjne.

## Piraci drogowi lekko wyhamowali
 - [https://www.rp.pl/wypadki/art39646181-piraci-drogowi-lekko-wyhamowali](https://www.rp.pl/wypadki/art39646181-piraci-drogowi-lekko-wyhamowali)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T17:30:13+00:00

Rzadziej do wypadków dochodziło przez prędkość, nieco częściej z powodu wymuszenia pierwszeństwa przejazdu – wskazuje wstępne policyjne podsumowanie roku na drogach.

## Dziennik Ustaw z 2 stycznia 2024 (1-4)
 - [https://www.rp.pl/akty-prawne/art39647191-dziennik-ustaw-z-2-stycznia-2024-1-4](https://www.rp.pl/akty-prawne/art39647191-dziennik-ustaw-z-2-stycznia-2024-1-4)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T17:27:58+00:00



## Monitor Polski z 2 stycznia 2024 (1-5)
 - [https://www.rp.pl/akty-prawne/art39647181-monitor-polski-z-2-stycznia-2024-1-5](https://www.rp.pl/akty-prawne/art39647181-monitor-polski-z-2-stycznia-2024-1-5)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T17:26:08+00:00



## Znany polski bokser przyłapany na dopingu. Jest wieloletnia dyskwalifikacja
 - [https://www.rp.pl/boks/art39646341-znany-polski-bokser-przylapany-na-dopingu-jest-wieloletnia-dyskwalifikacja](https://www.rp.pl/boks/art39646341-znany-polski-bokser-przylapany-na-dopingu-jest-wieloletnia-dyskwalifikacja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T17:19:12+00:00

Jak poinformowała brytyjska organizacja antydopingowa, Krzysztof Głowacki, były mistrz świata WBO w wadze junior ciężkiej, obecnie zawodnik MMA, został przyłapany na dopingu, za co otrzymał czteroletnią dyskwalifikację.

## W Warszawie żyje się najlepiej? Nowe dane GUS
 - [https://regiony.rp.pl/finanse-w-regionach/art39646861-w-warszawie-zyje-sie-najlepiej-nowe-dane-gus](https://regiony.rp.pl/finanse-w-regionach/art39646861-w-warszawie-zyje-sie-najlepiej-nowe-dane-gus)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T17:09:44+00:00

Stolica i okoliczne gminy nie dość, że są najbogatsze, to rozwijają się najszybciej, zwiększając dystans w porównaniu do innych regionów kraju.

## 2024: Zmiany w muzeach i galeriach
 - [https://www.rp.pl/kultura/art39645941-2024-zmiany-w-muzeach-i-galeriach](https://www.rp.pl/kultura/art39645941-2024-zmiany-w-muzeach-i-galeriach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T17:06:50+00:00

Były już rząd kończył wielkie inwestycje w politykę historyczną, nowy zaczął zmiany personalne.

## 2 stycznia to Dzień Introwertyka. Najwięcej jest ich wśród prawników jednej specjalizacji
 - [https://kobieta.rp.pl/psychologia/art39646381-2-stycznia-to-dzien-introwertyka-najwiecej-jest-ich-wsrod-prawnikow-jednej-specjalizacji](https://kobieta.rp.pl/psychologia/art39646381-2-stycznia-to-dzien-introwertyka-najwiecej-jest-ich-wsrod-prawnikow-jednej-specjalizacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T16:41:50+00:00

Kultury Zachodu, nagradzające zachowania ekstrawertyczne, zmuszają do przełamywania introwersji i ćwiczą w byciu bardziej otwartym, a nie każdy jest do tego predysponowany - mówi psycholożka dr Beata Rajba.

## Zmarł były sędzia Trybunału Konstytucyjnego, prof. dr hab. Wojciech Łączkowski
 - [https://www.rp.pl/prawnicy/art39646431-zmarl-byly-sedzia-trybunalu-konstytucyjnego-prof-dr-hab-wojciech-laczkowski](https://www.rp.pl/prawnicy/art39646431-zmarl-byly-sedzia-trybunalu-konstytucyjnego-prof-dr-hab-wojciech-laczkowski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T16:39:45+00:00

30 grudnia 2023 roku w wieku 90 lat zmarł wybitny, polski prawnik prof. dr hab. Wojciech Łączkowski. Profesor był sędzią Trybunału Konstytucyjnego oraz przewodniczącym Państwowej Komisji Wyborczej. O jego śmierci poinformował Uniwersytet im. Adama Mickiewicza w Poznaniu.

## Rusza postępowanie prokuratury po wypowiedzi Jana Pietrzaka
 - [https://www.rp.pl/polityka/art39645921-rusza-postepowanie-prokuratury-po-wypowiedzi-jana-pietrzaka](https://www.rp.pl/polityka/art39645921-rusza-postepowanie-prokuratury-po-wypowiedzi-jana-pietrzaka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T16:07:10+00:00

Publiczne znieważenie grupy ludności z powodu ich przynależności narodowej i etnicznej – pod tym kątem warszawska prokuratura wszczęła dochodzenie dotyczące wypowiedzi Jana Pietrzaka.

## Co czeka bitcoina w 2024 roku?
 - [https://pieniadze.rp.pl/kryptowaluty/art39646091-co-czeka-bitcoina-w-2024-roku](https://pieniadze.rp.pl/kryptowaluty/art39646091-co-czeka-bitcoina-w-2024-roku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T15:36:17+00:00

Bitcoin zaczął 2024 rok od wejścia na najwyższy od 21 miesięcy poziom. Najbardziej optymistyczna prognoza mówi o jego zwyżce nawet do 500 tys. dolarów.

## Nowa królowa Danii zdobyła serca przyszłych podwładnych jeszcze przed ślubem z księciem Fryderykiem
 - [https://kobieta.rp.pl/ludzie/art39645451-nowa-krolowa-danii-zdobyla-serca-przyszlych-podwladnych-jeszcze-przed-slubem-z-ksieciem-fryderykiem](https://kobieta.rp.pl/ludzie/art39645451-nowa-krolowa-danii-zdobyla-serca-przyszlych-podwladnych-jeszcze-przed-slubem-z-ksieciem-fryderykiem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T15:28:28+00:00

Podczas gdy media zagraniczne przybliżają sylwetkę ustępującej królowej i następcy tronu, oczy świata skierowane są też na jego małżonkę, która jako pierwsza Australijka otrzyma tytuł królowej Danii. Kim jest księżna Mary i czym zyskała przychylność Duńczyków?

## Pozew przeciwko sztucznej inteligencji. Czy byłby możliwy w Polsce?
 - [https://www.rp.pl/internet-i-prawo-autorskie/art39646041-pozew-przeciwko-sztucznej-inteligencji-czy-bylby-mozliwy-w-polsce](https://www.rp.pl/internet-i-prawo-autorskie/art39646041-pozew-przeciwko-sztucznej-inteligencji-czy-bylby-mozliwy-w-polsce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T15:27:12+00:00

New York Times pozwał twórców sztucznej inteligencji, „uczącej się” na tekstach publikowanych na łamach dziennika, o naruszenie praw autorskich. Czy w Polsce takie działanie uznane byłoby za niezgodne z prawem?

## Stina Seger: Moje zapachy są efektem historii, które widzę w trakcie medytacji
 - [https://kobieta.rp.pl/wywiad/art39576491-stina-seger-moje-zapachy-sa-efektem-historii-ktore-widze-w-trakcie-medytacji](https://kobieta.rp.pl/wywiad/art39576491-stina-seger-moje-zapachy-sa-efektem-historii-ktore-widze-w-trakcie-medytacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T15:21:36+00:00

“Kobiety są ważne” – podkreśla właścicielka marki perfumeryjnej Bibbi Parfum. Każdy stworzony przez nią zapach to "tłumaczenie" osobistych duchowych doświadczeń.

## Polski trotyl wystrzelił. Zakłady „Nitro-Chemu” pracują 24 godziny na dobę
 - [https://radar.rp.pl/przemysl-obronny/art39645891-polski-trotyl-wystrzelil-zaklady-nitro-chemu-pracuja-24-godziny-na-dobe](https://radar.rp.pl/przemysl-obronny/art39645891-polski-trotyl-wystrzelil-zaklady-nitro-chemu-pracuja-24-godziny-na-dobe)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T15:16:09+00:00

Bydgoski „Nitro-Chem” największy w Europie i jeden z czołowych w świecie producentów trotylu, lider eksportu rodzimej zbrojeniówki w minionym roku włączył wyższy bieg. Inwestuje też w ekologię by spróbować wyrównać rachunki firmy ze środowiskiem.

## Trotyl z „Nitro-Chemu” 24 godziny na dobę
 - [https://radar.rp.pl/przemysl-obronny/art39645891-trotyl-z-nitro-chemu-24-godziny-na-dobe](https://radar.rp.pl/przemysl-obronny/art39645891-trotyl-z-nitro-chemu-24-godziny-na-dobe)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T15:16:09+00:00

Bydgoski „Nitro-Chem” największy w Europie i jeden z czołowych w świecie producentów trotylu, lider eksportu rodzimej zbrojeniówki w minionym roku włączył wyższy bieg. Inwestuje też w ekologię by spróbować wyrównać rachunki firmy ze środowiskiem.

## Iga Świątek bez logo PZU. Koniec współpracy z największym sponsorem?
 - [https://www.rp.pl/biznes/art39645961-iga-swiatek-bez-logo-pzu-koniec-wspolpracy-z-najwiekszym-sponsorem](https://www.rp.pl/biznes/art39645961-iga-swiatek-bez-logo-pzu-koniec-wspolpracy-z-najwiekszym-sponsorem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T15:08:54+00:00

Ze stroju naszej najlepszej tenisistki zniknęło logo jej największego dotychczasowego sponsora. - Kontrakt nie został przedłużony - mówi nasz informator.

## Marek Kozubal: Wojsko informuje i już się nie ukrywa
 - [https://www.rp.pl/wojsko/art39645871-marek-kozubal-wojsko-informuje-i-juz-sie-nie-ukrywa](https://www.rp.pl/wojsko/art39645871-marek-kozubal-wojsko-informuje-i-juz-sie-nie-ukrywa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T15:06:00+00:00

Małymi kroczkami zmienia się sposób komunikacji strategicznej armii. W ten sposób budowane są fundamenty odporności społeczeństwa.

## Zuzanna Dąbrowska: Jan Pietrzak - czy te oczy mogły kłamać?
 - [https://www.rp.pl/komentarze/art39645541-zuzanna-dabrowska-jan-pietrzak-czy-te-oczy-mogly-klamac](https://www.rp.pl/komentarze/art39645541-zuzanna-dabrowska-jan-pietrzak-czy-te-oczy-mogly-klamac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T15:00:00+00:00

Zamiast zostać narodowym bardem, Jan Pietrzak z całym swoim życiowym rozczarowaniem i goryczą sam zamknął się w marginalnej prawicowej grupie nienawistników. Ordery od władz dostał, ale do uwielbienia tłumów daleko. To go boli i przepełnia jadem.

## Uczennica dostała uwagę, bo nie miała 10 zł na Szlachetną Paczkę. Jest reakcja
 - [https://kobieta.rp.pl/prawo/art39645201-uczennica-dostala-uwage-bo-nie-miala-10-zl-na-szlachetna-paczke-jest-reakcja](https://kobieta.rp.pl/prawo/art39645201-uczennica-dostala-uwage-bo-nie-miala-10-zl-na-szlachetna-paczke-jest-reakcja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T14:59:25+00:00

Czy należy karać złą oceną z zachowania osoby z neuroróżnorodnością a nagradzać dobrą tych uczniów, których rodzice pieką ciasta na szkolną zabawę?

## Tabor-Olszewska: W edukacji potrzebny jest remont generalny, a nie szpachlowanie pęknięć
 - [https://edukacja.rp.pl/oswiata/art39646081-tabor-olszewska-w-edukacji-potrzebny-jest-remont-generalny-a-nie-szpachlowanie-pekniec](https://edukacja.rp.pl/oswiata/art39646081-tabor-olszewska-w-edukacji-potrzebny-jest-remont-generalny-a-nie-szpachlowanie-pekniec)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T14:56:49+00:00

Czytam o pomysłach na zmiany w szkołach pojawiające się w przestrzeni publicznej oraz padające z ust decydentek. Czytam, patrzę i znów włos mi się na głowie jeży.

## Polska w Europie, Europa w Polsce: Niskoemisyjna Europa
 - [https://www.rp.pl/polityka/art39645971-polska-w-europie-europa-w-polsce-niskoemisyjna-europa](https://www.rp.pl/polityka/art39645971-polska-w-europie-europa-w-polsce-niskoemisyjna-europa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T14:51:46+00:00

Niskoemisyjność i ograniczenie samochodów spalinowych to jeden z celów polityki Europarlamentu. Regulacje rozpoczynające proces dekarbonizacji pojazdów samochodowych zacznie się od 2035 roku. Temu tematowi poświęcony był kolejny odcinek podcastu "Polska w Europie, Europa w Polsce".

## 72. TCS. W kwalifikacjach na Bergisel najlepszy Anze Lanisek
 - [https://www.rp.pl/skoki-narciarskie/art39645931-72-tcs-w-kwalifikacjach-na-bergisel-najlepszy-anze-lanisek](https://www.rp.pl/skoki-narciarskie/art39645931-72-tcs-w-kwalifikacjach-na-bergisel-najlepszy-anze-lanisek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T14:48:36+00:00

Słoweński skoczek powtórzył sukces kwalifikacyjny z Ga-Pa, wyprzedził w Innsbrucku Stefana Krafta i Ryoyu Kobayashiego. Polacy jak nigdy wcześniej – awansowało pięciu, ale czterech już w drugiej dziesiątce.

## Przejęcie mediów przez nowy rząd. Większość Polaków popiera przyjęte metody
 - [https://www.rp.pl/polityka/art39645901-przejecie-mediow-przez-nowy-rzad-wiekszosc-polakow-popiera-przyjete-metody](https://www.rp.pl/polityka/art39645901-przejecie-mediow-przez-nowy-rzad-wiekszosc-polakow-popiera-przyjete-metody)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T14:38:00+00:00

Większość Polaków akceptuje metody przyjęte przez nową władzę w zakresie przejęcia mediów publicznych. Za przyjętymi rozwiązaniami opowiedziała się nawet część wyborców PiS.

## Dwa domy z Polski wśród najlepszych na świecie w 2023 roku. Sukces Polaków
 - [https://sukces.rp.pl/architektura/art39645471-dwa-domy-z-polski-wsrod-najlepszych-na-swiecie-w-2023-roku-sukces-polakow](https://sukces.rp.pl/architektura/art39645471-dwa-domy-z-polski-wsrod-najlepszych-na-swiecie-w-2023-roku-sukces-polakow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T14:10:31+00:00

Dwa domy projektu polskich architektów znalazły się w zestawieniu 50 najlepszych projektów 2023 roku przygotowanym przez ceniony serwis architektoniczny ArchDaily.

## Pijana Rosjanka spaliła paszport. Teraz tłumaczy, że nie zrobiła tego dla Ukrainy
 - [https://www.rp.pl/konflikty-zbrojne/art39645591-pijana-rosjanka-spalila-paszport-teraz-tlumaczy-ze-nie-zrobila-tego-dla-ukrainy](https://www.rp.pl/konflikty-zbrojne/art39645591-pijana-rosjanka-spalila-paszport-teraz-tlumaczy-ze-nie-zrobila-tego-dla-ukrainy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:57:12+00:00

Rosyjski Komitet Śledczy wszczął postępowanie kryminalne przeciwko 22-letniej mieszkance Moskwy, po tym jak w sieci opublikowano nagranie, na którym widać jak kobieta spaliła paszport przed jednym z nocnych klubów w Briańsku, w noc sylwestrową.

## Wozy dowodzenia dla Abramsów zamówione
 - [https://radar.rp.pl/modernizacja-sil-zbrojnych/art39645511-wozy-dowodzenia-dla-abramsow-zamowione](https://radar.rp.pl/modernizacja-sil-zbrojnych/art39645511-wozy-dowodzenia-dla-abramsow-zamowione)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:45:49+00:00

Agencja Uzbrojenia podpisała umowę na dostawę 12 Wozów Dowodzenia na platformie Kołowego Transportera Opancerzonego (KTO).

## Paweł Rożyński: Błąd Google w kursie euro, to przygrywka do większych problemów
 - [https://www.rp.pl/opinie-ekonomiczne/art39645341-pawel-rozynski-blad-google-w-kursie-euro-to-przygrywka-do-wiekszych-problemow](https://www.rp.pl/opinie-ekonomiczne/art39645341-pawel-rozynski-blad-google-w-kursie-euro-to-przygrywka-do-wiekszych-problemow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:42:46+00:00

Noworoczny wirtualny krach na złotym to zapowiedź kłopotów, które czekają nas za sprawą coraz bardziej skomplikowanych i mogących wyrwać się spod kontroli człowieka nowych technologii.

## Dlaczego Jan-Krzysztof Duda nie podał ręki Rosjaninowi i czy może za to zapłacić
 - [https://www.rp.pl/inne-sporty/art39645271-dlaczego-jan-krzysztof-duda-nie-podal-reki-rosjaninowi-i-czy-moze-za-to-zaplacic](https://www.rp.pl/inne-sporty/art39645271-dlaczego-jan-krzysztof-duda-nie-podal-reki-rosjaninowi-i-czy-moze-za-to-zaplacic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:34:29+00:00

Jan-Krzysztof Duda nie podał ręki Denisowi Chismatułlinowi podczas meczu szachowych mistrzostw świata. Rosjanin to putinista i zwolennik wojny w Ukrainie, ale w największych imprezach wciąż gra.

## Koniec bezpiecznego kredytu, będzie inny program wsparcia
 - [https://www.rp.pl/konsumenci/art39645381-koniec-bezpiecznego-kredytu-bedzie-inny-program-wsparcia](https://www.rp.pl/konsumenci/art39645381-koniec-bezpiecznego-kredytu-bedzie-inny-program-wsparcia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:28:11+00:00

Od 2 stycznia 2024 roku banki nie przyjmują wniosków o udzielenie "Bezpiecznego kredytu 2 proc.", gdyż nie ma już na niego pieniędzy. Jak informuje Ministerstwo Rozwoju i Technologii informuje, trwają "intensywne prace nad nową formułą wsparcia kredytobiorców.

## Pierwsza transza JLTV już na Litwie
 - [https://radar.rp.pl/nato/art39645401-pierwsza-transza-jltv-juz-na-litwie](https://radar.rp.pl/nato/art39645401-pierwsza-transza-jltv-juz-na-litwie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:24:35+00:00

Na Litwę dotarła kolejna partia 50 opancerzonych samochodów Oshkosh JLTV.

## McDonald’s pozywa bojkotujących Izrael. Żąda ponad milion dolarów odszkodowania
 - [https://www.rp.pl/gastronomia/art39645131-mcdonald-s-pozywa-bojkotujacych-izrael-zada-ponad-milion-dolarow-odszkodowania](https://www.rp.pl/gastronomia/art39645131-mcdonald-s-pozywa-bojkotujacych-izrael-zada-ponad-milion-dolarow-odszkodowania)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:24:19+00:00

Malezyjski McDonald’s nie jest zachwycony uwagami pod swoim adresem od ruchu wzywającego do bojkotu Izraela. Za szkody „dla biznesu” domaga się więc odszkodowania.

## Badania dowodzą, że regularne jedzenie jogurtu greckiego pozwala zmniejszyć obwód talii. Pod jednym warunkiem
 - [https://kobieta.rp.pl/zdrowie/art39629471-badania-dowodza-ze-regularne-jedzenie-jogurtu-greckiego-pozwala-zmniejszyc-obwod-talii-pod-jednym-warunkiem](https://kobieta.rp.pl/zdrowie/art39629471-badania-dowodza-ze-regularne-jedzenie-jogurtu-greckiego-pozwala-zmniejszyc-obwod-talii-pod-jednym-warunkiem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:23:19+00:00

Odkryto, że jedzenie jogurtu greckiego pomaga pozbyć się otyłości brzusznej. Ten produkt nie tylko poprawia zdrowie jelit, ale także przyśpiesza metabolizm. Jest jednak grupa osób, która powinna go unikać.

## Sondaż: Izraelczycy popierają wojnę, ale nie chcą Netanjahu po wojnie
 - [https://www.rp.pl/konflikty-zbrojne/art39645321-sondaz-izraelczycy-popieraja-wojne-ale-nie-chca-netanjahu-po-wojnie](https://www.rp.pl/konflikty-zbrojne/art39645321-sondaz-izraelczycy-popieraja-wojne-ale-nie-chca-netanjahu-po-wojnie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:19:39+00:00

Z sondażu przeprowadzonego przez Izraelski Instytut Demokracji (IDI) wynika, że 56 proc. badanych w Izraelu uważa, iż ofensywa wojskowa w Strefie Gazy jest najlepszym sposobem na ocalenie zakładników, którzy nadal są przetrzymywani przez Hamas.

## „Królowa śmieci” w areszcie. Największy skandal ekologiczny w historii Szwecji
 - [https://klimat.rp.pl/planeta/art39645261-krolowa-smieci-w-areszcie-najwiekszy-skandal-ekologiczny-w-historii-szwecji](https://klimat.rp.pl/planeta/art39645261-krolowa-smieci-w-areszcie-najwiekszy-skandal-ekologiczny-w-historii-szwecji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:16:57+00:00

11 osób z zarzutami prokuratorskimi – to efekt wielkiego skandalu, który od kilku miesięcy bulwersuje Szwedów – pisze „Guardian”. Sprawa dotyczy co najmniej dziesiątków tysięcy ton odpadów. Za skandalem stoi szwedzka „królowa śmieci”, która trafiła do aresztu.

## Gdzie zagra Kylian Mbappe? Może już negocjować z każdym klubem
 - [https://www.rp.pl/pilka-nozna/art39645311-gdzie-zagra-kylian-mbappe-moze-juz-negocjowac-z-kazdym-klubem](https://www.rp.pl/pilka-nozna/art39645311-gdzie-zagra-kylian-mbappe-moze-juz-negocjowac-z-kazdym-klubem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:05:00+00:00

Gwiazdor reprezentacji Francji wciąż nie przedłużył kontraktu z Paris Saint-Germain i za pół roku będzie wolnym zawodnikiem. Do walki o jego podpis włącza się Liverpool.

## Mec. Włodzimierz Chróścik: z reformami nie ma co czekać
 - [https://www.rp.pl/prawnicy/art39645191-mec-wlodzimierz-chroscik-z-reformami-nie-ma-co-czekac](https://www.rp.pl/prawnicy/art39645191-mec-wlodzimierz-chroscik-z-reformami-nie-ma-co-czekac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T13:00:00+00:00

Obrona praworządności wymaga, by nie czekać już z reformami wymiaru sprawiedliwości i nie oglądać się na prezydenta. Parlament ma projekty, powinien zacząć nad nimi prace – uważa Włodzimierz Chróścik, prezes Krajowej Rady Radców Prawnych.

## Zmasowany atak rakietowy Rosji. Ukraina mówi o pięciu krokach dla Zachodu
 - [https://www.rp.pl/konflikty-zbrojne/art39645251-zmasowany-atak-rakietowy-rosji-ukraina-mowi-o-pieciu-krokach-dla-zachodu](https://www.rp.pl/konflikty-zbrojne/art39645251-zmasowany-atak-rakietowy-rosji-ukraina-mowi-o-pieciu-krokach-dla-zachodu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T12:48:13+00:00

Minister spraw zagranicznych Ukrainy Dmytro Kułeba podsumował kolejny w ostatnich dniach zmasowany atak rakietowy Rosjan. Wymienił pięć kroków, które mogą podjąć zachodni sojusznicy Kijowa, by zareagować na terror Władimira Putina.

## Pracowity styczeń Trybunału. Szybka ścieżka dla wniosków PiS
 - [https://www.rp.pl/sady-i-trybunaly/art39644291-pracowity-styczen-trybunalu-szybka-sciezka-dla-wnioskow-pis](https://www.rp.pl/sady-i-trybunaly/art39644291-pracowity-styczen-trybunalu-szybka-sciezka-dla-wnioskow-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T12:46:15+00:00

Aż pięć rozpraw znalazło się na styczniowej wokandzie Trybunału Konstytucyjnego. Trzy z nich dotyczą wniosków złożonych w ostatnich tygodniach roku 2023, więc tempo pracy TK nad nimi można uznać za rekordowe.

## Iustitia o projekcie Bodnara: nie można nadużywać regulaminu urzędowania sądów
 - [https://www.rp.pl/sady-i-trybunaly/art39645241-iustitia-o-projekcie-bodnara-nie-mozna-naduzywac-regulaminu-urzedowania-sadow](https://www.rp.pl/sady-i-trybunaly/art39645241-iustitia-o-projekcie-bodnara-nie-mozna-naduzywac-regulaminu-urzedowania-sadow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T12:43:53+00:00

Stowarzyszenie Sędziów Polskich "Iustitia" przedstawiło swoją opinię do projektu rozporządzenia ministra sprawiedliwości zmieniającego Regulamin urzędowania sądów powszechnych.

## W rosyjskim Biełgorodzie alarm powietrzny za alarmem
 - [https://www.rp.pl/konflikty-zbrojne/art39645181-w-rosyjskim-bielgorodzie-alarm-powietrzny-za-alarmem](https://www.rp.pl/konflikty-zbrojne/art39645181-w-rosyjskim-bielgorodzie-alarm-powietrzny-za-alarmem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T12:22:42+00:00

W rosyjskim Biełgorodzie trzy razy ogłaszany był we wtorek alarm powietrzny.

## Kreml znalazł nowych donatorów. Klienci banków dofinansują rosyjską wojnę
 - [https://www.rp.pl/banki/art39644861-kreml-znalazl-nowych-donatorow-klienci-bankow-dofinansuja-rosyjska-wojne](https://www.rp.pl/banki/art39644861-kreml-znalazl-nowych-donatorow-klienci-bankow-dofinansuja-rosyjska-wojne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:59:19+00:00

Kreml znalazł nowe źródło finansowania swojej zbrodniczej wojny. Po raz pierwszy w historii Rosjanie zapłacą podatek od lokat bankowych. Reżim chce ściągnąć z rynku co najmniej równowartość 14 mld zł.

## Od 1 stycznia 2024 roku minimalne wynagrodzenie i składki ZUS poszły w górę
 - [https://firma.rp.pl/prawo-i-podatki/art39645011-od-1-stycznia-2024-roku-minimalne-wynagrodzenie-i-skladki-zus-poszly-w-gore](https://firma.rp.pl/prawo-i-podatki/art39645011-od-1-stycznia-2024-roku-minimalne-wynagrodzenie-i-skladki-zus-poszly-w-gore)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:57:12+00:00

Wraz z nowym rokiem wzrastają: minimalne wynagrodzenie dla pracowników, składki na ubezpieczenia społeczne dla przedsiębiorców, a także inne świadczenia.

## Strefa Gazy: Izraelskie czołgi ostrzelały m.in. obóz dla uchodźców. 207 ofiar w ciągu doby
 - [https://www.rp.pl/konflikty-zbrojne/art39644841-strefa-gazy-izraelskie-czolgi-ostrzelaly-m-in-oboz-dla-uchodzcow-207-ofiar-w-ciagu-doby](https://www.rp.pl/konflikty-zbrojne/art39644841-strefa-gazy-izraelskie-czolgi-ostrzelaly-m-in-oboz-dla-uchodzcow-207-ofiar-w-ciagu-doby)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:49:51+00:00

Izrael informuje o zabiciu kilkudziesięciu bojowników w północnej części Strefy Gazy w ciągu ostatniej doby. Tymczasem izraelskie czołgi i samoloty intensyfikują ataki na południu enklawy, gdzie schroniło się wielu cywilów uciekających z północy.

## Słynny producent „szpilek” oszukany. Nielegalna sprzedaż na Facebooku
 - [https://sukces.rp.pl/moda/art39644381-slynny-producent-szpilek-oszukany-nielegalna-sprzedaz-na-facebooku](https://sukces.rp.pl/moda/art39644381-slynny-producent-szpilek-oszukany-nielegalna-sprzedaz-na-facebooku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:48:51+00:00

Christian Louboutin, najsłynniejszy na świecie producent szpilek, pozwał swojego byłego pracownika. Słynna francuska marka zarzuca mu kradzież i nielegalną sprzedaż swoich produktów.

## Toksyczna produktywność. Niepokojące zjawisko dotyka coraz więcej pracowników
 - [https://kobieta.rp.pl/biznes-i-prawo/art39630791-toksyczna-produktywnosc-niepokojace-zjawisko-dotyka-coraz-wiecej-pracownikow](https://kobieta.rp.pl/biznes-i-prawo/art39630791-toksyczna-produktywnosc-niepokojace-zjawisko-dotyka-coraz-wiecej-pracownikow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:48:49+00:00

Dynamika obecnych czasów, oczekiwania nieustannej dyspozycyjności i opracowywania projektów na czas lub wcześniej, sprawiają, że łatwo wpaść w pułapkę toksycznej produktywności.

## Koniec roku przyniósł kolejne wzrosty cen nowych mieszkań
 - [https://www.rp.pl/nieruchomosci/art39644871-koniec-roku-przyniosl-kolejne-wzrosty-cen-nowych-mieszkan](https://www.rp.pl/nieruchomosci/art39644871-koniec-roku-przyniosl-kolejne-wzrosty-cen-nowych-mieszkan)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:46:50+00:00

Średnie ceny nowych mieszkań w Trójmieście w IV kwartale roku wzrosły aż o 10 proc. W Warszawie – o 4 proc. – wynika ze wstępnych danych BIG DATA RynekPierwotny.pl.

## Zmiany w zasadach egzaminów na prawo jazdy
 - [https://moto.rp.pl/tu-i-teraz/art39641381-zmiany-w-zasadach-egzaminow-na-prawo-jazdy](https://moto.rp.pl/tu-i-teraz/art39641381-zmiany-w-zasadach-egzaminow-na-prawo-jazdy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:40:00+00:00

Od nowego roku wejdą w życie nowe zasady egzaminów na prawo jazdy. Zmiany dotyczą zarówno kandydatów na przyszłych kierowców pojazdów osobowych, jak też motocyklistów. Przewidywane są również podwyżki cen.

## Pakistan: Zastrzelono sześciu fryzjerów. Powodem strzyżenie w stylu zachodnim?
 - [https://www.rp.pl/spoleczenstwo/art39644821-pakistan-zastrzelono-szesciu-fryzjerow-powodem-strzyzenie-w-stylu-zachodnim](https://www.rp.pl/spoleczenstwo/art39644821-pakistan-zastrzelono-szesciu-fryzjerow-powodem-strzyzenie-w-stylu-zachodnim)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:27:00+00:00

Jak poinformowała agencja Associated Press, w dawnej twierdzy pakistańskich talibów, Mir Ali, zastrzelono sześciu fryzjerów. Media donoszą, że mężczyźni mogli złamać jeden z lokalnych obyczajów – wykonywać strzyżenia w stylu zachodnim.

## „Dziecko Nirvany” chce odszkodowania za zdjęcie na płycie „Nevermind”
 - [https://www.rp.pl/dobra-osobiste/art39634771-dziecko-nirvany-chce-odszkodowania-za-zdjecie-na-plycie-nevermind](https://www.rp.pl/dobra-osobiste/art39634771-dziecko-nirvany-chce-odszkodowania-za-zdjecie-na-plycie-nevermind)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:21:35+00:00

Spencer Elden, znany jako nagi niemowlak z okładki słynnej płyty „Nevermind” Nirvany, domaga się odszkodowanie za wykorzystanie seksualne. Sąd uznał, że mimo upływu 30 lat sprawa się nie przedawniła. W Polsce szanse na odszkodowanie byłyby mniejsze.

## Chory Piotr Beczała nie zaśpiewał w sylwestrowej premierze w Nowym Jorku
 - [https://www.rp.pl/muzyka-klasyczna/art39644501-chory-piotr-beczala-nie-zaspiewal-w-sylwestrowej-premierze-w-nowym-jorku](https://www.rp.pl/muzyka-klasyczna/art39644501-chory-piotr-beczala-nie-zaspiewal-w-sylwestrowej-premierze-w-nowym-jorku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:14:55+00:00

Zaledwie kilka godzin przed galową premierą „Carmen” w Metropolitan Opera Piotr Beczała odwołał w niej swój udział. Miał wystąpić w jednej głównych ról.

## Matka posłanki PiS Joanny Lichockiej straciła pracę. "Musiano ją odwołać, bo jestem jej córką"
 - [https://www.rp.pl/polityka/art39644631-matka-poslanki-pis-joanny-lichockiej-stracila-prace-musiano-ja-odwolac-bo-jestem-jej-corka](https://www.rp.pl/polityka/art39644631-matka-poslanki-pis-joanny-lichockiej-stracila-prace-musiano-ja-odwolac-bo-jestem-jej-corka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T11:01:00+00:00

W wyniku decyzji premiera Donalda Tuska odwołani zostali członkowie rady Instytutu De Republica. Jednym z nich była matka posłanki PiS Joanny Lichockiej. "Jest moją mamą, więc musiała być odwołana" - napisała w sieci polityk.

## Lofty w łódzkiej Fuzji
 - [https://www.rp.pl/nieruchomosci/art39644581-lofty-w-lodzkiej-fuzji](https://www.rp.pl/nieruchomosci/art39644581-lofty-w-lodzkiej-fuzji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T10:55:56+00:00

Drukarnię dawnego kompleksu Scheiblera w klimatyczne mieszkania zmienia Archicom. Sprzedaż loftów już się rozpoczęła.

## Magazyny gazu w Unii Europejskiej wciąż pełne dzięki Ukrainie
 - [https://energia.rp.pl/gaz/art39644211-magazyny-gazu-w-unii-europejskiej-wciaz-pelne-dzieki-ukrainie](https://energia.rp.pl/gaz/art39644211-magazyny-gazu-w-unii-europejskiej-wciaz-pelne-dzieki-ukrainie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T10:41:08+00:00

Unijne firmy przyspieszyły zatłaczanie gazu gromadzonego w podziemnych magazynach na Ukrainie. Pozwoliło to wykorzystać jedynie niewielkie ilości paliwa z magazynów na terenie Unii, a tym samym obniżyć ceny surowca na rynku spotowym.

## Turcja poinformowała o rozbiciu siatki izraelskiego wywiadu
 - [https://www.rp.pl/przestepczosc/art39644281-turcja-poinformowala-o-rozbiciu-siatki-izraelskiego-wywiadu](https://www.rp.pl/przestepczosc/art39644281-turcja-poinformowala-o-rozbiciu-siatki-izraelskiego-wywiadu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T10:37:20+00:00

33 osoby podejrzane o współpracę z izraelskim Mosadem zostały aresztowane w całej Turcji - poinformował szef MSW Turcji, Ali Yerlikaya.

## Polscy fizycy w gronie najlepszych naukowców z całego świata
 - [https://www.rp.pl/nauka/art39644321-polscy-fizycy-w-gronie-najlepszych-naukowcow-z-calego-swiata](https://www.rp.pl/nauka/art39644321-polscy-fizycy-w-gronie-najlepszych-naukowcow-z-calego-swiata)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T10:36:45+00:00

Uniwersytet Stanforda zaktualizował listę najczęściej cytowanych naukowców z całego świata na której znaleźli się polscy fizycy.

## Balkonowe elektrownie solarne spowodowały rozkwit niemieckiej fotowoltaiki
 - [https://energia.rp.pl/oze/art39644301-balkonowe-elektrownie-solarne-spowodowaly-rozkwit-niemieckiej-fotowoltaiki](https://energia.rp.pl/oze/art39644301-balkonowe-elektrownie-solarne-spowodowaly-rozkwit-niemieckiej-fotowoltaiki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T10:32:06+00:00

Niemcy od dawna są pionierami w dziedzinie energii słonecznej. Szczególnie popularne są elektrownie balkonowe. W 2023 roku branża przeżyła prawdziwą eksplozję.

## Rzecznik pacjentów zmienił adres
 - [https://www.rp.pl/zdrowie/art39644171-rzecznik-pacjentow-zmienil-adres](https://www.rp.pl/zdrowie/art39644171-rzecznik-pacjentow-zmienil-adres)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T10:10:59+00:00

1 stycznia 2024 r. Rzecznik Praw Pacjenta przeprowadził się do nowej siedziby w Warszawie.

## Japonia: Podczas lądowania na lotnisku w Tokio zapalił się samolot
 - [https://www.rp.pl/spoleczenstwo/art39644191-japonia-podczas-ladowania-na-lotnisku-w-tokio-zapalil-sie-samolot](https://www.rp.pl/spoleczenstwo/art39644191-japonia-podczas-ladowania-na-lotnisku-w-tokio-zapalil-sie-samolot)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T10:04:00+00:00

Jak poinformowała we wtorek Nippon TV, samolot linii lotniczych Japan Airlines, na którego pokładzie znajdowało się ponad 300 pasażerów, zapalił się w momencie lądowania.

## Japonia: Podczas lądowania na lotnisku w Tokio zapalił się samolot. Nie żyje 5 osób
 - [https://www.rp.pl/spoleczenstwo/art39644191-japonia-podczas-ladowania-na-lotnisku-w-tokio-zapalil-sie-samolot-nie-zyje-5-osob](https://www.rp.pl/spoleczenstwo/art39644191-japonia-podczas-ladowania-na-lotnisku-w-tokio-zapalil-sie-samolot-nie-zyje-5-osob)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T10:04:00+00:00

Jak poinformowała we wtorek Nippon TV, samolot linii lotniczych Japan Airlines, na którego pokładzie znajdowało się ponad 300 pasażerów, zapalił się w momencie lądowania.

## Pokaz fajerwerków w Dolinie Pięciu Stawów. Nagroda za wskazanie sprawcy
 - [https://www.rp.pl/spoleczenstwo/art39644111-pokaz-fajerwerkow-w-dolinie-pieciu-stawow-nagroda-za-wskazanie-sprawcy](https://www.rp.pl/spoleczenstwo/art39644111-pokaz-fajerwerkow-w-dolinie-pieciu-stawow-nagroda-za-wskazanie-sprawcy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T09:58:26+00:00

Do sieci trafiło nagranie, na którym widać sztuczne ognie odpalone na terenie Tatrzańskiego Parku Narodowego - w Dolinie Pięciu Stawów Polskich. Za ustalenie tożsamości osoby, która odpaliła fajerwerki wyznaczono nagrodę.

## Czy w 2024 roku mieszkania stanieją
 - [https://www.rp.pl/nieruchomosci/art39644081-czy-w-2024-roku-mieszkania-stanieja](https://www.rp.pl/nieruchomosci/art39644081-czy-w-2024-roku-mieszkania-stanieja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T09:47:28+00:00

Od grudnia 2022 r. do listopada 2023 r. ceny mieszkań wzrosły średnio o 13 proc. Największe podwyżki – o 29 proc. – odnotowano w Krakowie – wynika z raportu Expandera i Rentier.io. Co nas czeka w 2024 roku?

## Rosyjska wioska zaatakowana przez rosyjski samolot. Resort obrony się przyznaje
 - [https://www.rp.pl/konflikty-zbrojne/art39644001-rosyjska-wioska-zaatakowana-przez-rosyjski-samolot-resort-obrony-sie-przyznaje](https://www.rp.pl/konflikty-zbrojne/art39644001-rosyjska-wioska-zaatakowana-przez-rosyjski-samolot-resort-obrony-sie-przyznaje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T09:31:13+00:00

Ok. 9 rano czasu moskiewskiego samolot Sił Powietrzno-Kosmicznych Federacji Rosyjskiej dokonał "nieprawidłowego zrzutu amunicji" na wieś Pietropawłowka w obwodzie woroneskim.

## Paweł Kowal o wojnie na Ukrainie: Władimir Putin się rozzuchwalił. Myśli, że Trump wygrał
 - [https://www.rp.pl/polityka/art39644031-pawel-kowal-o-wojnie-na-ukrainie-wladimir-putin-sie-rozzuchwalil-mysli-ze-trump-wygral](https://www.rp.pl/polityka/art39644031-pawel-kowal-o-wojnie-na-ukrainie-wladimir-putin-sie-rozzuchwalil-mysli-ze-trump-wygral)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T09:30:00+00:00

Rosja się rozzuchwaliła, Putin się rozzuchwalił. Jemu się wydaje, że Trump już wygrał w USA i zdecydował się na wstrzymanie wsparcia dla Ukrainy. A jeszcze się to nie wydarzyło - powiedział w programie #RZECZoPOLITYCE prof. Paweł Kowal, poseł KO, szef komisji spraw zagranicznych. - Putin szuka rozwiązania, żeby odsapnąć – przeczekać, dozbroić się, przegrupować siły. A Zachód nie może mu na to pozwolić - dodał.

## Paweł Kowal: W ostatnich latach wprowadzono w Polsce realny autorytaryzm. Objawiał się cenzurą faktyczną
 - [https://www.rp.pl/polityka/art39644031-pawel-kowal-w-ostatnich-latach-wprowadzono-w-polsce-realny-autorytaryzm-objawial-sie-cenzura-faktyczna](https://www.rp.pl/polityka/art39644031-pawel-kowal-w-ostatnich-latach-wprowadzono-w-polsce-realny-autorytaryzm-objawial-sie-cenzura-faktyczna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T09:30:00+00:00

Jeżeli coś było zagrożeniem dla bezpieczeństwa Polski, to zagrożeniem był właśnie system medialny, w którym duża część Polaków miała dostęp tylko do fałszywych informacji i opinii. I całkowicie była odgrodzona murem informacyjnym od tego, co się faktycznie dzieje - powiedział w programie #RZECZoPOLITYCE prof. Paweł Kowal, poseł KO, szef komisji spraw zagranicznych.

## Polacy na ostatniej prostej przed imprezą roku, ale zagrają bez gwiazdy
 - [https://www.rp.pl/pilka-reczna/art39643981-polacy-na-ostatniej-prostej-przed-impreza-roku-ale-zagraja-bez-gwiazdy](https://www.rp.pl/pilka-reczna/art39643981-polacy-na-ostatniej-prostej-przed-impreza-roku-ale-zagraja-bez-gwiazdy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T09:28:05+00:00

Reprezentacja Polski w piłce ręcznej 11 stycznia rozpocznie mistrzostwa Europy, czyli najważniejszą imprezę sezonu i ostatnią szansę, aby przedłużyć nadzieje na igrzyska w Paryżu. Drużyna ma jednak problem, bo kontuzjowany jest Arkadiusz Moryto.

## Co rząd Tuska zrobi ws. Trybunału Konstytucyjnego? Bodnar zabrał głos
 - [https://www.rp.pl/sady-i-trybunaly/art39643881-co-rzad-tuska-zrobi-ws-trybunalu-konstytucyjnego-bodnar-zabral-glos](https://www.rp.pl/sady-i-trybunaly/art39643881-co-rzad-tuska-zrobi-ws-trybunalu-konstytucyjnego-bodnar-zabral-glos)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T09:07:44+00:00

Uchwała Sejmu może być niewystarczająca do przeprowadzenia zmian w Trybunale Konstytucyjnym - przyznał minister sprawiedliwości Adam Bodnar.

## Oszałamiająca wygrana w loterii. Zwycięzca będzie bardzo bogaty
 - [https://www.rp.pl/biznes/art39643851-oszalamiajaca-wygrana-w-loterii-zwyciezca-bedzie-bardzo-bogaty](https://www.rp.pl/biznes/art39643851-oszalamiajaca-wygrana-w-loterii-zwyciezca-bedzie-bardzo-bogaty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T09:06:34+00:00

Los sprzedany w stanie Michigan zgarnął główną nagrodę noworocznym głosowaniu amerykańskiej loterii Powerball. Szacowana wygrana to 842,2 miliona dolarów, czyli około 3,3 mld złotych.

## Władze Kijowa podsumowują atak powietrzny: Nad stolicą Ukrainy zestrzelono 10 pocisków hipersonicznych
 - [https://www.rp.pl/konflikty-zbrojne/art39643871-wladze-kijowa-podsumowuja-atak-powietrzny-nad-stolica-ukrainy-zestrzelono-10-pociskow-hipersonicznych](https://www.rp.pl/konflikty-zbrojne/art39643871-wladze-kijowa-podsumowuja-atak-powietrzny-nad-stolica-ukrainy-zestrzelono-10-pociskow-hipersonicznych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T09:03:10+00:00

W nocy z 1 na 2 stycznia nad Kijowem zestrzelono wszystkie drony-kamikadze, ponad 60 pocisków manewrujących Ch-101/Ch-555/Ch-55 i 10 pocisków hipersonicznych Kindżał.

## Andrzej Duda spotkał się z członkami KRRiT. Propozycja "kroku wstecz"
 - [https://www.rp.pl/polityka/art39643821-andrzej-duda-spotkal-sie-z-czlonkami-krrit-propozycja-kroku-wstecz](https://www.rp.pl/polityka/art39643821-andrzej-duda-spotkal-sie-z-czlonkami-krrit-propozycja-kroku-wstecz)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T08:49:44+00:00

W piątek prezydent Andrzej Duda spotkał się z członkami Krajowej Rady Radiofonii i Telewizji. Rozmowa dotyczyła zmian w mediach publicznych. Jak relacjonuje jeden Tadeusz Kowalski, padła propozycja, żeby "zrobić krok wstecz".

## Po noworocznym zamieszaniu złoty lekko traci względem euro i dolara
 - [https://www.rp.pl/waluty/art39643841-po-noworocznym-zamieszaniu-zloty-lekko-traci-wzgledem-euro-i-dolara](https://www.rp.pl/waluty/art39643841-po-noworocznym-zamieszaniu-zloty-lekko-traci-wzgledem-euro-i-dolara)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T08:40:32+00:00

Wtorkowy poranek przynosi lekkie osłabienie złotego względem najważniejszych walut, który tym samym odreagowuje po efektownym rajdzie z końcówki 2023 roku.

## Problem z ławnikami sądowymi. Tylko w Gdańsku brakuje 100 osób
 - [https://www.rp.pl/sady-i-trybunaly/art39643831-problem-z-lawnikami-sadowymi-tylko-w-gdansku-brakuje-100-osob](https://www.rp.pl/sady-i-trybunaly/art39643831-problem-z-lawnikami-sadowymi-tylko-w-gdansku-brakuje-100-osob)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T08:37:00+00:00

Nowy rok to zarazem początek nowej kadencji ławników sądowych na lata 2024 - 2027. W całym kraju jest zbyt mało chętnych do tej pracy, w samym Gdańsku potrzeba jeszcze prawie 100 sędziów społecznych - informuje oficjalny portal miasta.

## Ten rok będzie należał do tej technologii. Wszystko ma być „smart” i w zasięgu
 - [https://cyfrowa.rp.pl/technologie/art39642261-ten-rok-bedzie-nalezal-do-tej-technologii-wszystko-ma-byc-smart-i-w-zasiegu](https://cyfrowa.rp.pl/technologie/art39642261-ten-rok-bedzie-nalezal-do-tej-technologii-wszystko-ma-byc-smart-i-w-zasiegu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T08:25:00+00:00

Biznes pójdzie w ślady konsumentów, którzy już zaczęli doceniać rozwiązania „smart home” – przewidują eksperci. Ale Rynek Internetu Rzeczy to coś więcej - teraz ma szybko rosnąć i objąć nowe dziedziny i urządzenia.

## Nastroje w gospodarce coraz gorsze. Ciągły spadek PMI od 20 miesięcy
 - [https://www.rp.pl/dane-gospodarcze/art39643811-nastroje-w-gospodarce-coraz-gorsze-ciagly-spadek-pmi-od-20-miesiecy](https://www.rp.pl/dane-gospodarcze/art39643811-nastroje-w-gospodarce-coraz-gorsze-ciagly-spadek-pmi-od-20-miesiecy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T08:15:03+00:00

Wskaźnik PMI dla przemysłu w Polsce w grudniu 2023 r. wyniósł 47,4 pkt. wobec 48,7 pkt. w listopadzie - podał S&amp;P Global.

## Nie żyje prof. Małgorzata Kozłowska-Wojciechowska. Znana Profesor Zdrówko miała 72 lata
 - [https://www.rp.pl/kraj/art39643751-nie-zyje-prof-malgorzata-kozlowska-wojciechowska-znana-profesor-zdrowko-miala-72-lata](https://www.rp.pl/kraj/art39643751-nie-zyje-prof-malgorzata-kozlowska-wojciechowska-znana-profesor-zdrowko-miala-72-lata)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T07:57:15+00:00

W wieku 72 lat zmarła Małgorzata Kozłowska-Wojciechowska, profesorka nauk medycznych, specjalizująca się w chorobach wewnętrznych i gastroenterologii. Była telewizyjną ekspertką ds. zdrowego odżywiania.

## Rosja wysłała bombowce do atakowania Ukrainy. Polska poderwała myśliwce F-16
 - [https://www.rp.pl/wojsko/art39643731-rosja-wyslala-bombowce-do-atakowania-ukrainy-polska-poderwala-mysliwce-f-16](https://www.rp.pl/wojsko/art39643731-rosja-wyslala-bombowce-do-atakowania-ukrainy-polska-poderwala-mysliwce-f-16)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T07:32:47+00:00

Dowództwo Operacyjne Rodzajów Sił Zbrojnych poinformowało o poderwaniu myśliwców F-16 oraz sojuszniczego tankowca powietrznego w związku ze zmasowanym atakiem powietrznym Rosji na Ukrainę.

## Adrian Zandberg o kursie złotego w Google: Tylko Suwerenna Polska tak wierzy międzynarodowej korporacji
 - [https://www.rp.pl/polityka/art39643681-adrian-zandberg-o-kursie-zlotego-w-google-tylko-suwerenna-polska-tak-wierzy-miedzynarodowej-korporacji](https://www.rp.pl/polityka/art39643681-adrian-zandberg-o-kursie-zlotego-w-google-tylko-suwerenna-polska-tak-wierzy-miedzynarodowej-korporacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T07:07:24+00:00

Dobrze, że był szybki komunikat ministra (finansów Andrzeja) Domańskiego. Tyle. Tu chyba wielkiej historii nie ma - mówił w rozmowie z Polsat News lider Razem Adrian Zandberg, pytany o wieczorne zamieszanie z kursem złotego w wyszukiwarce Google.

## Wraca afera SKOK Wołomin. Finalny akt oskarżenia już w sądzie
 - [https://www.rp.pl/prawo-karne/art39641621-wraca-afera-skok-wolomin-finalny-akt-oskarzenia-juz-w-sadzie](https://www.rp.pl/prawo-karne/art39641621-wraca-afera-skok-wolomin-finalny-akt-oskarzenia-juz-w-sadzie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T07:00:00+00:00

Po niemal 10 latach śledztwa Prokuratura Okręgowa w Gorzowie Wielkopolskim skierowała do sądu akt oskarżenia przeciwko 62 osobom w związku z aferą SKOK Wołomin. Według śledczych mieli oni doprowadzić do niekorzystnego rozporządzenia mieniem w kwocie ponad 3 mld zł - ustaliła „Rzeczpospolita” .

## Dzisiaj nie załatwimy wielu spraw. Które urzędy są zamknięte
 - [https://www.rp.pl/w-sadzie-i-w-urzedzie/art39643671-dzisiaj-nie-zalatwimy-wielu-spraw-ktore-urzedy-sa-zamkniete](https://www.rp.pl/w-sadzie-i-w-urzedzie/art39643671-dzisiaj-nie-zalatwimy-wielu-spraw-ktore-urzedy-sa-zamkniete)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T06:44:08+00:00

W związku z decyzją premiera Donalda Tuska we wtorek 2 stycznia większość urzędów jest nieczynna.

## Syryjska armia: Izrael zaatakował cele w rejonie Damaszku
 - [https://www.rp.pl/konflikty-zbrojne/art39643641-syryjska-armia-izrael-zaatakowal-cele-w-rejonie-damaszku](https://www.rp.pl/konflikty-zbrojne/art39643641-syryjska-armia-izrael-zaatakowal-cele-w-rejonie-damaszku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T06:20:26+00:00

Izrael miał przeprowadzić atak na cele na przedmieściach Damaszku z rejonu Wzgórz Golan - informuje syryjska armia.

## Izrael: Sędziowie uderzają w Beniamina Netanjahu w czasie wojny
 - [https://www.rp.pl/polityka/art39643541-izrael-sedziowie-uderzaja-w-beniamina-netanjahu-w-czasie-wojny](https://www.rp.pl/polityka/art39643541-izrael-sedziowie-uderzaja-w-beniamina-netanjahu-w-czasie-wojny)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T05:47:38+00:00

Historyczny wyrok Sądu Konstytucyjnego przypomniał o politycznym rozdarciu Izraela, przez ostatnie miesiące skupionego na wojnie z Hamasem.

## Kolejna niespokojna noc na Ukrainie. Najpierw drony-kamikadze, potem atak rakietowy
 - [https://www.rp.pl/konflikty-zbrojne/art39643611-kolejna-niespokojna-noc-na-ukrainie-najpierw-drony-kamikadze-potem-atak-rakietowy](https://www.rp.pl/konflikty-zbrojne/art39643611-kolejna-niespokojna-noc-na-ukrainie-najpierw-drony-kamikadze-potem-atak-rakietowy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T04:59:00+00:00

W nocy z 1 na 2 stycznia Rosja atakowała cele na Ukrainie dronami-kamikadze, po czym bombowce strategiczne Tu-95MS wystrzeliły rakiety w stronę celów na Ukrainie.

## Kolejna niespokojna noc na Ukrainie. Zmasowany atak rakietowy na Kijów
 - [https://www.rp.pl/konflikty-zbrojne/art39643611-kolejna-niespokojna-noc-na-ukrainie-zmasowany-atak-rakietowy-na-kijow](https://www.rp.pl/konflikty-zbrojne/art39643611-kolejna-niespokojna-noc-na-ukrainie-zmasowany-atak-rakietowy-na-kijow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T04:59:00+00:00

W nocy z 1 na 2 stycznia Rosja atakowała cele na Ukrainie dronami-kamikadze, po czym bombowce strategiczne Tu-95MS wystrzeliły rakiety w stronę celów na Ukrainie.

## Japonia: 30 ofiar śmiertelnych trzęsienia ziemi
 - [https://www.rp.pl/kleski-zywiolowe/art39643591-japonia-30-ofiar-smiertelnych-trzesienia-ziemi](https://www.rp.pl/kleski-zywiolowe/art39643591-japonia-30-ofiar-smiertelnych-trzesienia-ziemi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T04:43:54+00:00

Zespoły ratunkowe starają się dotrzeć do terenów najciężej dotkniętych przez silne trzęsienie ziemi, które nawiedziło Japonię 1 stycznia. Władze Japonii informują o 30 ofiarach śmiertelnych.

## Japonia: Ponad 20 ofiar śmiertelnych trzęsienia ziemi
 - [https://www.rp.pl/kleski-zywiolowe/art39643591-japonia-ponad-20-ofiar-smiertelnych-trzesienia-ziemi](https://www.rp.pl/kleski-zywiolowe/art39643591-japonia-ponad-20-ofiar-smiertelnych-trzesienia-ziemi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T04:43:54+00:00

Zespoły ratunkowe starają się dotrzeć do terenów najciężej dotkniętych przez silne trzęsienie ziemi, które nawiedziło Japonię 1 stycznia. Reuters informuje o ponad 20 ofiarach śmiertelnych wstrząsów.

## Korea Południowa: Lider opozycji zaatakowany przez nożownika. Jest w szpitalu
 - [https://www.rp.pl/przestepczosc/art39643571-korea-poludniowa-lider-opozycji-zaatakowany-przez-nozownika-jest-w-szpitalu](https://www.rp.pl/przestepczosc/art39643571-korea-poludniowa-lider-opozycji-zaatakowany-przez-nozownika-jest-w-szpitalu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T04:20:42+00:00

Południowokoreański polityk, lider opozycyjnej Partii Demokratycznej, Lee Jae-myung, został zaatakowany przez nożownika w czasie wizyty w Busan.

## Wojna Rosji z Ukrainą. Dzień 678
 - [https://www.rp.pl/swiat/art39643551-wojna-rosji-z-ukraina-dzien-678](https://www.rp.pl/swiat/art39643551-wojna-rosji-z-ukraina-dzien-678)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T03:52:47+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. W nocy z 1 na 2 stycznia spadające szczątki drona-kamikadze wywołały pożar w Kijowie.

## Agonia królestwa w sercu Unii Europejskiej. Czy Belgia przestanie istnieć?
 - [https://www.rp.pl/swiat/art39642811-agonia-krolestwa-w-sercu-unii-europejskiej-czy-belgia-przestanie-istniec](https://www.rp.pl/swiat/art39642811-agonia-krolestwa-w-sercu-unii-europejskiej-czy-belgia-przestanie-istniec)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Coraz więcej wskazuje na to, że 1 stycznia kraj przejął przewodnictwo w Unii po raz ostatni. Potem przestanie istnieć.

## Bogusław Chrabota: Czy to już czas na wprowadzenie w Polsce euro
 - [https://www.rp.pl/opinie-ekonomiczne/art39643301-boguslaw-chrabota-czy-to-juz-czas-na-wprowadzenie-w-polsce-euro](https://www.rp.pl/opinie-ekonomiczne/art39643301-boguslaw-chrabota-czy-to-juz-czas-na-wprowadzenie-w-polsce-euro)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Potrzebny jest powrót do poważnej dyskusji o wspólnej walucie. Czy jako Polacy bez euro zyskujemy, czy tracimy? Jakie przywileje daje nam wspólna waluta? Jakie drzwi otwiera, jakie zamyka? Czy euro rozwój naszego kraju przyspieszy, czy spowolni?

## Co czeka GPW w 2024 roku? Większość ekspertów jest zgodna
 - [https://www.rp.pl/gielda/art39643151-co-czeka-gpw-w-2024-roku-wiekszosc-ekspertow-jest-zgodna](https://www.rp.pl/gielda/art39643151-co-czeka-gpw-w-2024-roku-wiekszosc-ekspertow-jest-zgodna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Eksperci raczej z optymizmem spoglądają w przyszłość. Ich zdaniem nie powinno zabraknąć paliwa do kontynuacji hossy na krajowym rynku akcji, choć nie nastawiają się na efektowne zwyżki indeksów.

## Co zastąpi „Bezpieczny kredyt 2 proc.”? Będą ograniczenia
 - [https://www.rp.pl/banki/art39643161-co-zastapi-bezpieczny-kredyt-2-proc-beda-ograniczenia](https://www.rp.pl/banki/art39643161-co-zastapi-bezpieczny-kredyt-2-proc-beda-ograniczenia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Resort rozwoju pracuje nad reformą programu wsparcia Polaków w zakupie pierwszego mieszkania. Efekty mamy poznać na początku 2024 r., ale zdaniem ekspertów pojawić się może kryterium dochodowe.

## Euro, nowa Liga Mistrzów. To będzie rok kolejnej futbolowej ekspansji
 - [https://www.rp.pl/pilka-nozna/art39642921-euro-nowa-liga-mistrzow-to-bedzie-rok-kolejnej-futbolowej-ekspansji](https://www.rp.pl/pilka-nozna/art39642921-euro-nowa-liga-mistrzow-to-bedzie-rok-kolejnej-futbolowej-ekspansji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

W 2024 roku rozrośnie się i zmieni nie do poznania Liga Mistrzów. Wcześniej będziemy żyć jednak barażami o Euro i samymi mistrzostwami w Niemczech.

## Ile Polska traci na tym, że nie jest w strefie euro?
 - [https://www.rp.pl/waluty/art39643191-ile-polska-traci-na-tym-ze-nie-jest-w-strefie-euro](https://www.rp.pl/waluty/art39643191-ile-polska-traci-na-tym-ze-nie-jest-w-strefie-euro)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Polski rząd powinien obrać kurs na euro. Korzyści przewyższają koszty – mówią ekonomiści.

## Jak sądy i sędziowie przetrwają "zamrożenie" i naprawę Krajowej Rady Sądownictwa
 - [https://www.rp.pl/sady-i-trybunaly/art39643091-jak-sady-i-sedziowie-przetrwaja-zamrozenie-i-naprawe-krajowej-rady-sadownictwa](https://www.rp.pl/sady-i-trybunaly/art39643091-jak-sady-i-sedziowie-przetrwaja-zamrozenie-i-naprawe-krajowej-rady-sadownictwa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Zapaści nie będzie, bo sądownictwo od lat musi sobie radzić z permanentnym kryzysem – uważają sami sędziowie.

## Jerzy Surdykowski: Czy obecna władza musiała „jechać po bandzie” z TVP?
 - [https://www.rp.pl/felietony/art39642091-jerzy-surdykowski-czy-obecna-wladza-musiala-jechac-po-bandzie-z-tvp](https://www.rp.pl/felietony/art39642091-jerzy-surdykowski-czy-obecna-wladza-musiala-jechac-po-bandzie-z-tvp)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Najbardziej bezczelni kłamcy z uciszonej właśnie TVP okupują jakieś przedpokoje i wznoszą okrzyki w obronie wolności słowa, ratowania pluralizmu oraz prawdomówności. Są przy tym tragiczni, bo – z prezesem Jarosławem Kaczyńskim na czele – uwierzyli we własną niewinność.

## Karuzela z przejęciami może przyspieszyć. Króluje jedna branża
 - [https://www.rp.pl/biznes/art39643171-karuzela-z-przejeciami-moze-przyspieszyc-kroluje-jedna-branza](https://www.rp.pl/biznes/art39643171-karuzela-z-przejeciami-moze-przyspieszyc-kroluje-jedna-branza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

W ostatnich kwartałach mimo trudnych warunków rynkowych transakcji nie brakowało. W tym roku może być jeszcze ciekawiej.

## Kolejny rok z wyborami. „Polaryzacja ma też zatrzymać impet Trzeciej Drogi”
 - [https://www.rp.pl/polityka/art39642721-kolejny-rok-z-wyborami-polaryzacja-ma-tez-zatrzymac-impet-trzeciej-drogi](https://www.rp.pl/polityka/art39642721-kolejny-rok-z-wyborami-polaryzacja-ma-tez-zatrzymac-impet-trzeciej-drogi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Kampanie samorządowa i europejska będą pierwszymi sprawdzianami jedności koalicji rządowej, będzie to także test dla opozycyjnego PiS.

## Krzysztof A. Kowalczyk: Kosztowne przywiązanie do złotego
 - [https://www.rp.pl/opinie-ekonomiczne/art39643321-krzysztof-a-kowalczyk-kosztowne-przywiazanie-do-zlotego](https://www.rp.pl/opinie-ekonomiczne/art39643321-krzysztof-a-kowalczyk-kosztowne-przywiazanie-do-zlotego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

W kwestii przyjęcia przez Polskę euro gorszy pieniądz niestety nadal wypiera lepszy – przynajmniej w głowach polityków. W rezultacie ich zaniechań podatny na kaprysy walutowej koniunktury i spekulantów złoty nadal wypełnia nasze portfele, nie pozwalając zagościć tam stabilniejszemu euro, do którego przyjęcia zobowiązaliśmy się w traktacie akcesyjnym.

## Kto zapłaci za szybki wzrost płacy minimalnej
 - [https://www.rp.pl/wynagrodzenia/art39643141-kto-zaplaci-za-szybki-wzrost-placy-minimalnej](https://www.rp.pl/wynagrodzenia/art39643141-kto-zaplaci-za-szybki-wzrost-placy-minimalnej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Kolejny rok dwucyfrowych podwyżek najniższego wynagrodzenia to wyzwanie dla wielu firm i branż, w tym szczególnie dla sektora MSP i małych rynków pracy.

## Mateusz Chołodecki: Czy ratunek dla Poczty Polskiej jest jeszcze możliwy
 - [https://www.rp.pl/opinie-ekonomiczne/art39643111-mateusz-cholodecki-czy-ratunek-dla-poczty-polskiej-jest-jeszcze-mozliwy](https://www.rp.pl/opinie-ekonomiczne/art39643111-mateusz-cholodecki-czy-ratunek-dla-poczty-polskiej-jest-jeszcze-mozliwy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Problem narodowego operatora jest jednym z wyzwań dla nowego rządu. Już za chwilę może się okazać, że sytuacja Poczty jest dramatyczna, a jej ratowane będzie szczególnie trudne dla rządzących.

## Nadal mało zachęt dla inwestorów spółek giełdowych
 - [https://www.rp.pl/gielda/art39643121-nadal-malo-zachet-dla-inwestorow-spolek-gieldowych](https://www.rp.pl/gielda/art39643121-nadal-malo-zachet-dla-inwestorow-spolek-gieldowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Dziś tylko sześć spółek z GPW oferuje swoim akcjonariuszom programy lojalnościowe i nie zanosi się na szybką zmianę. Bariery od lat są te same. Chodzi m.in. o wymogi regulacyjno-prawne i koszty.

## Produkcja prawa w 2023 r. bliska rekordu. 25 888 stron aktów prawnych
 - [https://www.rp.pl/prawo-dla-ciebie/art39643071-produkcja-prawa-w-2023-r-bliska-rekordu-25-888-stron-aktow-prawnych](https://www.rp.pl/prawo-dla-ciebie/art39643071-produkcja-prawa-w-2023-r-bliska-rekordu-25-888-stron-aktow-prawnych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

W 2023 r. powstało w Polsce blisko 3 tys. aktów prawnych. To jeden z najwyższych wyników w historii.

## Pół wieku stabilności. Królowa Danii Małgorzata II oddaje tron
 - [https://www.rp.pl/polityka/art39642791-pol-wieku-stabilnosci-krolowa-danii-malgorzata-ii-oddaje-tron](https://www.rp.pl/polityka/art39642791-pol-wieku-stabilnosci-krolowa-danii-malgorzata-ii-oddaje-tron)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Duńczycy nie wyobrażają sobie życia bez Małgorzaty II. W noworocznym przemówieniu zaskoczyła poddanych zapowiedzią abdykacji.

## Sondaż: Ponad połowa Polaków uważa, że Donald Tusk nie spełnił jeszcze obietnicy ws. KPO
 - [https://www.rp.pl/polityka/art39642771-sondaz-ponad-polowa-polakow-uwaza-ze-donald-tusk-nie-spelnil-jeszcze-obietnicy-ws-kpo](https://www.rp.pl/polityka/art39642771-sondaz-ponad-polowa-polakow-uwaza-ze-donald-tusk-nie-spelnil-jeszcze-obietnicy-ws-kpo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Ponad połowa badanych przez IBRiS uważa, że premier Donald Tusk nie wypełnił jeszcze swojej przedwyborczej obietnicy zapewnienia napływu środków z Krajowego Planu Odbudowy.

## Szybujące ceny biletów na koncerty są faktem. Ile trzeba zapłacić?
 - [https://www.rp.pl/muzyka-popularna/art39642821-szybujace-ceny-biletow-na-koncerty-sa-faktem-ile-trzeba-zaplacic](https://www.rp.pl/muzyka-popularna/art39642821-szybujace-ceny-biletow-na-koncerty-sa-faktem-ile-trzeba-zaplacic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Taylor Swift, Dua Lipa, Metallica, Depeche Mode, Foo Fighters zagrają w Polsce w tym roku. Koncerty, niestety, drożeją.

## Wszystkie polskie rządy powinny obierać kurs na euro
 - [https://www.rp.pl/waluty/art39643181-wszystkie-polskie-rzady-powinny-obierac-kurs-na-euro](https://www.rp.pl/waluty/art39643181-wszystkie-polskie-rzady-powinny-obierac-kurs-na-euro)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Niezależnie od wszystkiego, przygotowywanie gospodarki do wejścia do strefy euro jest czymś szalenie ważnym, jest wartością dodaną. I absolutnie warto podjąć ten wysiłek – mówią ekonomiści.

## Światowe giełdy w 2024 roku. Inwestorzy spodziewają się zwyżek
 - [https://www.rp.pl/gielda/art39643101-swiatowe-gieldy-w-2024-roku-inwestorzy-spodziewaja-sie-zwyzek](https://www.rp.pl/gielda/art39643101-swiatowe-gieldy-w-2024-roku-inwestorzy-spodziewaja-sie-zwyzek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T02:00:00+00:00

Nadzieje na luzowanie polityki pieniężnej przez Fed oraz na „miękkie lądowanie” gospodarki globalnej sprawiają, że inwestorzy spodziewają się zwyżek.

## Magazyny energii na Śląsku z unijnym dofinansowaniem
 - [https://www.rp.pl/finanse/art39635781-magazyny-energii-na-slasku-z-unijnym-dofinansowaniem](https://www.rp.pl/finanse/art39635781-magazyny-energii-na-slasku-z-unijnym-dofinansowaniem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T01:00:00+00:00

Jednostki samorządu terytorialnego oraz ich związki i stowarzyszenia mogą wystąpić o środki z działania 2.6 „Odnawialne źródła energii” programu regionalnego.

## Opieka nad dorosłymi osobami niepełnosprawnymi
 - [https://www.rp.pl/zadania/art39635721-opieka-nad-doroslymi-osobami-niepelnosprawnymi](https://www.rp.pl/zadania/art39635721-opieka-nad-doroslymi-osobami-niepelnosprawnymi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T01:00:00+00:00

Praktyka stosowania przepisów przez organy administracji o zasiłku pielęgnacyjnym wobec opiekunów osób dorosłych z niepełnosprawnością jest niezgodna z orzecznictwem Trybunału Konstytucyjnego (TK).

## Opłata za zezwolenie na sprzedaż trunków
 - [https://www.rp.pl/finanse/art39635751-oplata-za-zezwolenie-na-sprzedaz-trunkow](https://www.rp.pl/finanse/art39635751-oplata-za-zezwolenie-na-sprzedaz-trunkow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T01:00:00+00:00

Przedsiębiorca nie wpłacił terminowo opłaty za zezwolenie na sprzedaż napojów alkoholowych. Czy w tej sytuacji wójt musi wydać decyzję stwierdzającą wygaśnięcie zezwolenia? Po pierwsze jest to tylko decyzja deklaratywna, po drugie z punktu widzenia interesów gminy to potencjalna strata, bo przedsiębiorca może zapłacić, gdy odzyska płynność finansową – pyta radna.

## Plan nie może wykluczać stawiania masztów
 - [https://www.rp.pl/ustroj-i-kompetencje/art39635741-plan-nie-moze-wykluczac-stawiania-masztow](https://www.rp.pl/ustroj-i-kompetencje/art39635741-plan-nie-moze-wykluczac-stawiania-masztow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T01:00:00+00:00

Przepisy planu miejscowego nie mogą faktycznie uniemożliwiać zlokalizowania naziemnych stacji bazowych telefonii komórkowej.

## Prywatne auto na służbowe cele
 - [https://www.rp.pl/praca-w-samorzadzie/art39635761-prywatne-auto-na-sluzbowe-cele](https://www.rp.pl/praca-w-samorzadzie/art39635761-prywatne-auto-na-sluzbowe-cele)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-01-02T01:00:00+00:00

RIO zakwestionowała zawarcie umowy na używanie samochodu prywatnego do celów służbowych pomiędzy wójtem a przewodniczącym rady gminy. W okresie, kiedy zawierano umowę był wakat na stanowisku sekretarza, stąd takie rozwiązanie przyjęto. Czy powoduje to nielegalność wydatku dla wójta z tytułu zwrotu dla niego kosztów używania jego pojazdu – pyta radny.

