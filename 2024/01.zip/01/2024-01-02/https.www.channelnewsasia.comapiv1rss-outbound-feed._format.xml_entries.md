# Source:Channel Asia Latest News, URL:https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml, language:en

## Why do women get more headaches than men? Here's what we know
 - [https://www.channelnewsasia.com/women/headaches-women-causes-4016966](https://www.channelnewsasia.com/women/headaches-women-causes-4016966)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T23:24:07+00:00

Hormones may be the most obvious culprit, but other factors can be at play.

## Choo Yilin, the Singaporean jeweller who made jade cool, is back after a 3-year hiatus
 - [https://www.channelnewsasia.com/style-beauty/choo-yilin-jade-jewellery-designer-singapore-3998626](https://www.channelnewsasia.com/style-beauty/choo-yilin-jade-jewellery-designer-singapore-3998626)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T23:19:25+00:00

CNA Lifestyle catches up with the entrepreneur to learn more about “Choo Yilin v2.0” and its focus on heritage and storytelling.

## 'It was a miracle': How passengers escaped a JAL fireball in Tokyo
 - [https://www.channelnewsasia.com/asia/miracle-how-passengers-escaped-fireball-airplane-tokyo-japan-4021541](https://www.channelnewsasia.com/asia/miracle-how-passengers-escaped-fireball-airplane-tokyo-japan-4021541)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T22:21:36+00:00



## Marketmind- Don't look to US kickoff for positive 2024 signal
 - [https://www.channelnewsasia.com/business/marketmind-dont-look-us-kickoff-positive-2024-signal-4021861](https://www.channelnewsasia.com/business/marketmind-dont-look-us-kickoff-positive-2024-signal-4021861)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T22:18:06+00:00



## Despite some misbehaving customers, Singapore’s heartland shops warm to CDC vouchers as scheme enters 5th year
 - [https://www.channelnewsasia.com/singapore/cdc-vouchers-heartland-merchants-hawkers-hiccups-4021076](https://www.channelnewsasia.com/singapore/cdc-vouchers-heartland-merchants-hawkers-hiccups-4021076)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T22:09:47+00:00

Merchants and hawkers tell CNA the cash has generally helped their business, with some patrons spending more on things like hair perms and even mobile phones.

## Commentary: Dads, please take your increased paternity leave if you can
 - [https://www.channelnewsasia.com/commentary/paternity-leave-four-weeks-employers-support-fathers-4020906](https://www.channelnewsasia.com/commentary/paternity-leave-four-weeks-employers-support-fathers-4020906)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T22:00:00+00:00

Not all employees may feel supported to fully use their four weeks of government-paid paternity leave. Those who do can help normalise that behaviour, says new father Bernard Aw.

## Commentary: Neon still has a hold on the hearts of Hongkongers
 - [https://www.channelnewsasia.com/commentary/hong-kong-hk-night-life-neon-lights-wong-kar-wai-4020856](https://www.channelnewsasia.com/commentary/hong-kong-hk-night-life-neon-lights-wong-kar-wai-4020856)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T22:00:00+00:00

There may be fewer brightly lit signs in the city but for many they offer a reminder of a more freewheeling era, says the Financial Times’ Orla Ryan.

## Commentary: Your ability to multi-task changes with age
 - [https://www.channelnewsasia.com/commentary/multi-task-productivity-focus-brain-health-age-4020901](https://www.channelnewsasia.com/commentary/multi-task-productivity-focus-brain-health-age-4020901)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T22:00:00+00:00

It’s possible to practise and improve your multi-tasking skills, says this Australian Catholic University professor.

## Taiwan Votes 2024: A hung parliament could emerge for the first time since 2008, and why it matters
 - [https://www.channelnewsasia.com/asia/taiwan-elections-hung-parliament-legislature-4017276](https://www.channelnewsasia.com/asia/taiwan-elections-hung-parliament-legislature-4017276)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T22:00:00+00:00

After the legislative election, Taiwan’s parliament is likely to hold crucial debates on labour insurance reform, as well as pick up on election promises ranging from education to youth housing.

## Darts-Sixteen-year-old Littler crushes Cross to reach World Championship final
 - [https://www.channelnewsasia.com/sport/darts-sixteen-year-old-littler-crushes-cross-reach-world-championship-final-4021801](https://www.channelnewsasia.com/sport/darts-sixteen-year-old-littler-crushes-cross-reach-world-championship-final-4021801)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T21:46:29+00:00



## West Ham held to drab 0-0 draw by Brighton
 - [https://www.channelnewsasia.com/sport/west-ham-held-drab-0-0-draw-brighton-4021766](https://www.channelnewsasia.com/sport/west-ham-held-drab-0-0-draw-brighton-4021766)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T21:33:19+00:00



## Harvard president resigns after rows over plagiarism, anti-Semitism
 - [https://www.channelnewsasia.com/world/harvard-president-resigns-after-rows-over-plagiarism-anti-semitism-4021616](https://www.channelnewsasia.com/world/harvard-president-resigns-after-rows-over-plagiarism-anti-semitism-4021616)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T20:40:21+00:00



## Driving into 2024: COE, EV and other automotive trends ahead in Singapore
 - [https://www.channelnewsasia.com/people/automotive-car-trends-2024-singapore-4020111](https://www.channelnewsasia.com/people/automotive-car-trends-2024-singapore-4020111)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T20:37:05+00:00

Luxury car brand executives weigh in on what to expect in the automotive industry.

## Martinez era begins at Boca Juniors
 - [https://www.channelnewsasia.com/sport/martinez-era-begins-boca-juniors-4021631](https://www.channelnewsasia.com/sport/martinez-era-begins-boca-juniors-4021631)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T19:03:08+00:00



## Israeli strike in Lebanon kills senior Hamas official Saleh al-Arouri: Security sources
 - [https://www.channelnewsasia.com/world/hamas-senior-official-saleh-al-arouri-killed-israeli-strike-lebanon-4021461](https://www.channelnewsasia.com/world/hamas-senior-official-saleh-al-arouri-killed-israeli-strike-lebanon-4021461)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T17:49:07+00:00



## Atalanta sign Sweden defender Hien from Verona
 - [https://www.channelnewsasia.com/sport/atalanta-sign-sweden-defender-hien-verona-4021536](https://www.channelnewsasia.com/sport/atalanta-sign-sweden-defender-hien-verona-4021536)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T17:40:13+00:00



## Algeria’s injured Gouiri out of African Cup of Nations
 - [https://www.channelnewsasia.com/sport/algerias-injured-gouiri-out-african-cup-nations-4021526](https://www.channelnewsasia.com/sport/algerias-injured-gouiri-out-african-cup-nations-4021526)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T17:37:20+00:00



## BYD overtakes Tesla as world's top EV maker
 - [https://www.channelnewsasia.com/business/byd-overtakes-tesla-worlds-top-ev-maker-4021516](https://www.channelnewsasia.com/business/byd-overtakes-tesla-worlds-top-ev-maker-4021516)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T17:33:20+00:00



## Apple hits seven-week low after Barclays downgrade
 - [https://www.channelnewsasia.com/business/apple-hits-seven-week-low-after-barclays-downgrade-4021496](https://www.channelnewsasia.com/business/apple-hits-seven-week-low-after-barclays-downgrade-4021496)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T17:21:49+00:00



## Apple hits seven-week low after Barclays downgrade on demand concerns
 - [https://www.channelnewsasia.com/business/apple-hits-seven-week-low-after-barclays-downgrade-demand-concerns-4021496](https://www.channelnewsasia.com/business/apple-hits-seven-week-low-after-barclays-downgrade-demand-concerns-4021496)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T17:21:49+00:00



## Tesla deliveries beat estimates as year-end sales push pays off
 - [https://www.channelnewsasia.com/business/tesla-deliveries-beat-estimates-year-end-sales-push-pays-4021501](https://www.channelnewsasia.com/business/tesla-deliveries-beat-estimates-year-end-sales-push-pays-4021501)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T17:20:39+00:00



## Tesla deliveries beat estimates as year-end sales push pays off
 - [https://www.channelnewsasia.com/business/elon-musk-tesla-electric-vehicles-deliveries-beat-estimates-year-end-sales-push-pays-4021501](https://www.channelnewsasia.com/business/elon-musk-tesla-electric-vehicles-deliveries-beat-estimates-year-end-sales-push-pays-4021501)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T17:20:00+00:00



## South Africa defend weakened test squad for New Zealand series
 - [https://www.channelnewsasia.com/sport/south-africa-defend-weakened-test-squad-new-zealand-series-4021456](https://www.channelnewsasia.com/sport/south-africa-defend-weakened-test-squad-new-zealand-series-4021456)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T16:52:30+00:00



## Former WBO champion Glowacki gets four-year ban for doping offence
 - [https://www.channelnewsasia.com/sport/former-wbo-champion-glowacki-gets-four-year-ban-doping-offence-4021451](https://www.channelnewsasia.com/sport/former-wbo-champion-glowacki-gets-four-year-ban-doping-offence-4021451)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T16:37:39+00:00



## India back to full strength as Jadeja returns for Newlands test
 - [https://www.channelnewsasia.com/sport/india-back-full-strength-jadeja-returns-newlands-test-4021406](https://www.channelnewsasia.com/sport/india-back-full-strength-jadeja-returns-newlands-test-4021406)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T15:42:19+00:00



## Delta Air sees some flight delays after closure of Tokyo's Haneda Airport
 - [https://www.channelnewsasia.com/business/delta-air-sees-some-flight-delays-after-closure-tokyos-haneda-airport-4021386](https://www.channelnewsasia.com/business/delta-air-sees-some-flight-delays-after-closure-tokyos-haneda-airport-4021386)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T15:12:20+00:00



## 5 coast guard crew killed after plane collides with Japan Airlines jet in Tokyo's Haneda airport
 - [https://www.channelnewsasia.com/asia/japan-airlines-haneda-airport-fire-collision-coast-guard-crew-killed-4021321](https://www.channelnewsasia.com/asia/japan-airlines-haneda-airport-fire-collision-coast-guard-crew-killed-4021321)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T15:11:00+00:00

All 379 people on the JAL flight escaped as the Airbus A350 burst into flames on the tarmac.

## France's CMA CGM hikes shipping rates between Asia and Mediterranean
 - [https://www.channelnewsasia.com/business/frances-cma-cgm-hikes-shipping-rates-between-asia-and-mediterranean-4021346](https://www.channelnewsasia.com/business/frances-cma-cgm-hikes-shipping-rates-between-asia-and-mediterranean-4021346)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T14:48:16+00:00



## Israel says it will appear before ICJ to counter South Africa's Gaza case
 - [https://www.channelnewsasia.com/world/israel-says-it-will-appear-icj-counter-south-africas-gaza-case-4021251](https://www.channelnewsasia.com/world/israel-says-it-will-appear-icj-counter-south-africas-gaza-case-4021251)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T14:42:00+00:00



## Nadal happy to overcome fear after surgery with victory in comeback match
 - [https://www.channelnewsasia.com/sport/nadal-happy-overcome-fear-after-surgery-victory-comeback-match-4021286](https://www.channelnewsasia.com/sport/nadal-happy-overcome-fear-after-surgery-victory-comeback-match-4021286)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T14:03:06+00:00



## Türkiye detains 33 accused of spying for Israel
 - [https://www.channelnewsasia.com/world/turkiye-detains-33-accused-spying-israel-4020996](https://www.channelnewsasia.com/world/turkiye-detains-33-accused-spying-israel-4020996)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T13:55:54+00:00



## Business as usual for departing South Africa captain Elgar
 - [https://www.channelnewsasia.com/sport/business-usual-departing-south-africa-captain-elgar-4021281](https://www.channelnewsasia.com/sport/business-usual-departing-south-africa-captain-elgar-4021281)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T13:55:53+00:00



## Jubilant Spanish soccer fan returns home after being freed by Iran
 - [https://www.channelnewsasia.com/sport/jubilant-spanish-soccer-fan-returns-home-after-being-freed-iran-4021266](https://www.channelnewsasia.com/sport/jubilant-spanish-soccer-fan-returns-home-after-being-freed-iran-4021266)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T13:43:03+00:00



## Jubilant Spanish football fan returns home after being freed by Iran
 - [https://www.channelnewsasia.com/sport/jubilant-spanish-football-fan-returns-home-after-being-freed-iran-4021266](https://www.channelnewsasia.com/sport/jubilant-spanish-football-fan-returns-home-after-being-freed-iran-4021266)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T13:43:00+00:00



## Man gets jail after hitting elderly man's head with metal tongs in fight; victim died 9 days later
 - [https://www.channelnewsasia.com/singapore/man-jail-hit-elderly-man-head-metal-tongs-hawker-centre-fight-death-4021231](https://www.channelnewsasia.com/singapore/man-jail-hit-elderly-man-head-metal-tongs-hawker-centre-fight-death-4021231)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T13:39:00+00:00



## UK's Blair denies link to role in 'resettlement' of Gazans
 - [https://www.channelnewsasia.com/world/uks-blair-denies-link-role-resettlement-gazans-4021101](https://www.channelnewsasia.com/world/uks-blair-denies-link-role-resettlement-gazans-4021101)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T13:35:29+00:00



## Spanish soccer player Hermoso testifies about Rubiales World Cup kiss
 - [https://www.channelnewsasia.com/sport/spanish-soccer-player-hermoso-testifies-about-rubiales-world-cup-kiss-4021236](https://www.channelnewsasia.com/sport/spanish-soccer-player-hermoso-testifies-about-rubiales-world-cup-kiss-4021236)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T13:18:11+00:00



## Spanish football player Hermoso testifies about Rubiales World Cup kiss
 - [https://www.channelnewsasia.com/world/spanish-football-player-hermoso-testifies-about-rubiales-world-cup-kiss-4021236](https://www.channelnewsasia.com/world/spanish-football-player-hermoso-testifies-about-rubiales-world-cup-kiss-4021236)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T13:18:00+00:00



## Thailand, China to waive visas for each other's citizens from March
 - [https://www.channelnewsasia.com/asia/thailand-china-waive-visas-each-others-citizens-march-4020446](https://www.channelnewsasia.com/asia/thailand-china-waive-visas-each-others-citizens-march-4020446)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T13:05:44+00:00



## Advantage Man City as title rivals prepare to lose key players
 - [https://www.channelnewsasia.com/sport/advantage-man-city-title-rivals-prepare-lose-key-players-4021146](https://www.channelnewsasia.com/sport/advantage-man-city-title-rivals-prepare-lose-key-players-4021146)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T12:18:35+00:00



## Woman pleads guilty to flipping pot of boiling soup onto man in dispute, causing burns to 29% of his body
 - [https://www.channelnewsasia.com/singapore/woman-pleads-guilty-flipping-pot-boiling-soup-man-dispute-4021091](https://www.channelnewsasia.com/singapore/woman-pleads-guilty-flipping-pot-boiling-soup-man-dispute-4021091)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T12:11:08+00:00



## Ex-Reform Party member issues public apology for spreading false statements about Shanmugam
 - [https://www.channelnewsasia.com/singapore/law-home-affairs-minister-k-shanmugam-former-reform-party-thaddeus-thomas-apology-false-statements-4021116](https://www.channelnewsasia.com/singapore/law-home-affairs-minister-k-shanmugam-former-reform-party-thaddeus-thomas-apology-false-statements-4021116)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T12:09:23+00:00



## China saw hottest recorded year in 2023
 - [https://www.channelnewsasia.com/asia/china-hottest-year-recorded-weather-2023-4021106](https://www.channelnewsasia.com/asia/china-hottest-year-recorded-weather-2023-4021106)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T11:44:00+00:00



## Analysis:US fintechs push into fixed-income trading as retail investor interest grows
 - [https://www.channelnewsasia.com/business/analysisus-fintechs-push-fixed-income-trading-retail-investor-interest-grows-4021086](https://www.channelnewsasia.com/business/analysisus-fintechs-push-fixed-income-trading-retail-investor-interest-grows-4021086)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T11:24:23+00:00



## Tesla extends lead in Norway as EVs take record 82% market share
 - [https://www.channelnewsasia.com/business/tesla-extends-lead-norway-evs-take-record-82-market-share-4021056](https://www.channelnewsasia.com/business/tesla-extends-lead-norway-evs-take-record-82-market-share-4021056)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T11:23:41+00:00



## Tesla extends lead in Norway sales, EVs take 82% market share
 - [https://www.channelnewsasia.com/business/tesla-extends-lead-norway-sales-evs-take-82-market-share-4021056](https://www.channelnewsasia.com/business/tesla-extends-lead-norway-sales-evs-take-82-market-share-4021056)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T11:23:41+00:00



## Alibaba Group says repurchased $9.5 billion worth shares in 2023
 - [https://www.channelnewsasia.com/business/alibaba-group-says-repurchased-95-billion-worth-shares-2023-4021066](https://www.channelnewsasia.com/business/alibaba-group-says-repurchased-95-billion-worth-shares-2023-4021066)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T11:20:21+00:00



## Birmingham City sack manager Rooney amid winless run
 - [https://www.channelnewsasia.com/sport/birmingham-city-sack-manager-rooney-amid-winless-run-4021041](https://www.channelnewsasia.com/sport/birmingham-city-sack-manager-rooney-amid-winless-run-4021041)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T11:09:34+00:00



## For investors, 2024 is year of transition to a new economic order
 - [https://www.channelnewsasia.com/business/investors-2024-year-transition-new-economic-order-4021036](https://www.channelnewsasia.com/business/investors-2024-year-transition-new-economic-order-4021036)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T11:07:41+00:00



## Nadal roars to victory over Thiem in Brisbane singles comeback
 - [https://www.channelnewsasia.com/sport/nadal-roars-victory-over-thiem-brisbane-singles-comeback-4021016](https://www.channelnewsasia.com/sport/nadal-roars-victory-over-thiem-brisbane-singles-comeback-4021016)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:59:19+00:00



## Mega-cap companies saw strong gains in 2023 amid tech optimism
 - [https://www.channelnewsasia.com/business/mega-cap-companies-saw-strong-gains-2023-amid-tech-optimism-4021011](https://www.channelnewsasia.com/business/mega-cap-companies-saw-strong-gains-2023-amid-tech-optimism-4021011)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:54:16+00:00



## Thousands evacuated following Indonesia volcano eruption
 - [https://www.channelnewsasia.com/asia/thousands-evacuated-following-indonesia-volcano-eruption-4020986](https://www.channelnewsasia.com/asia/thousands-evacuated-following-indonesia-volcano-eruption-4020986)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:52:28+00:00



## No reports of Singaporeans affected by Japan earthquake: MFA
 - [https://www.channelnewsasia.com/asia/singaporeans-japan-earthquake-defer-travel-mfa-4020886](https://www.channelnewsasia.com/asia/singaporeans-japan-earthquake-defer-travel-mfa-4020886)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:51:47+00:00



## Fighting between Hamas and Israel rages on despite partial troop withdrawal
 - [https://www.channelnewsasia.com/world/fighting-between-hamas-and-israel-rages-despite-partial-troop-withdrawal-4020481](https://www.channelnewsasia.com/world/fighting-between-hamas-and-israel-rages-despite-partial-troop-withdrawal-4020481)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:33:51+00:00



## Fighting between Hamas and Israel rages on, Palestinian death toll passes 22,000
 - [https://www.channelnewsasia.com/world/fighting-between-hamas-and-israel-rages-palestinian-death-toll-passes-22000-4020481](https://www.channelnewsasia.com/world/fighting-between-hamas-and-israel-rages-palestinian-death-toll-passes-22000-4020481)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:33:00+00:00



## China's Rongsheng, Saudi Aramco in talks to buy stake in each other's units
 - [https://www.channelnewsasia.com/business/chinas-rongsheng-saudi-aramco-talks-buy-stake-each-others-units-4020966](https://www.channelnewsasia.com/business/chinas-rongsheng-saudi-aramco-talks-buy-stake-each-others-units-4020966)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:27:12+00:00



## Rongsheng Petrochemical, Aramco in talks to buy stake in each other's units
 - [https://www.channelnewsasia.com/business/rongsheng-petrochemical-aramco-talks-buy-stake-each-others-units-4020966](https://www.channelnewsasia.com/business/rongsheng-petrochemical-aramco-talks-buy-stake-each-others-units-4020966)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:27:12+00:00



## China boosts policy bank loans amid expectations of housing support
 - [https://www.channelnewsasia.com/business/china-boosts-policy-bank-loans-amid-expectations-housing-support-4020951](https://www.channelnewsasia.com/business/china-boosts-policy-bank-loans-amid-expectations-housing-support-4020951)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:12:32+00:00



## China lifts policy bank loans, raising housing support expectations
 - [https://www.channelnewsasia.com/business/china-lifts-policy-bank-loans-raising-housing-support-expectations-4020951](https://www.channelnewsasia.com/business/china-lifts-policy-bank-loans-raising-housing-support-expectations-4020951)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T10:12:32+00:00



## Budget accommodation options on the rise in Singapore, surpassing pre-pandemic levels
 - [https://www.channelnewsasia.com/singapore/budget-accommodation-hostels-hotels-options-rise-singapore-surpassing-pre-pandemic-levels-covid-19-travel-4020841](https://www.channelnewsasia.com/singapore/budget-accommodation-hostels-hotels-options-rise-singapore-surpassing-pre-pandemic-levels-covid-19-travel-4020841)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T09:51:00+00:00

Just 110 licensed economy-tiered accommodation operators remained when Singapore's borders were reopened in April 2022, but the total number has since grown to 132.

## Azarenka wins but Kenin bundled out in Brisbane
 - [https://www.channelnewsasia.com/sport/azarenka-wins-kenin-bundled-out-brisbane-4020816](https://www.channelnewsasia.com/sport/azarenka-wins-kenin-bundled-out-brisbane-4020816)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T09:33:23+00:00



## Japan Airlines plane on fire at Tokyo's Haneda airport
 - [https://www.channelnewsasia.com/asia/japan-airlines-fire-tokyo-haneda-airport-4020876](https://www.channelnewsasia.com/asia/japan-airlines-fire-tokyo-haneda-airport-4020876)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T09:33:00+00:00



## Amid cybersecurity concerns, Malaysia launches central database aimed at refining targeted subsidy handouts
 - [https://www.channelnewsasia.com/asia/malaysia-padu-database-information-cybersecurity-government-subsidies-4020801](https://www.channelnewsasia.com/asia/malaysia-padu-database-information-cybersecurity-government-subsidies-4020801)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T09:22:20+00:00

The Central Database Hub (PADU) will house comprehensive information on Malaysians and permanent residents which can then be accessed by all government agencies.

## ASML shares dip after Netherlands pulls licence for some China exports
 - [https://www.channelnewsasia.com/business/asml-shares-dip-after-netherlands-pulls-licence-some-china-exports-4020851](https://www.channelnewsasia.com/business/asml-shares-dip-after-netherlands-pulls-licence-some-china-exports-4020851)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T09:13:00+00:00



## ASML shares dip after Netherlands revokes licence for some China exports
 - [https://www.channelnewsasia.com/business/asml-shares-dip-after-netherlands-revokes-licence-some-china-exports-4020851](https://www.channelnewsasia.com/business/asml-shares-dip-after-netherlands-revokes-licence-some-china-exports-4020851)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T09:13:00+00:00



## Lee Jae-myung: From factory worker to South Korean presidential contender
 - [https://www.channelnewsasia.com/asia/south-korea-lee-jae-myung-factory-worker-opposition-leader-working-class-roots-4020726](https://www.channelnewsasia.com/asia/south-korea-lee-jae-myung-factory-worker-opposition-leader-working-class-roots-4020726)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T09:07:31+00:00



## China's state-owned developers dominate sales, land markets in 2023 - surveys
 - [https://www.channelnewsasia.com/business/chinas-state-owned-developers-dominate-sales-land-markets-2023-surveys-4020831](https://www.channelnewsasia.com/business/chinas-state-owned-developers-dominate-sales-land-markets-2023-surveys-4020831)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T09:05:19+00:00



## Active ageing centre operators plan to double pool of workers, offer more services for seniors
 - [https://www.channelnewsasia.com/singapore/active-ageing-centre-operators-plan-double-pool-workers-offer-more-services-seniors-4020596](https://www.channelnewsasia.com/singapore/active-ageing-centre-operators-plan-double-pool-workers-offer-more-services-seniors-4020596)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:58:36+00:00

Some centres have urged volunteers, including seniors, to step forward.

## South Korea protests to Japan about tsunami alerts showing disputed islets
 - [https://www.channelnewsasia.com/asia/south-korea-protest-japan-earthquake-tsunami-alert-map-disputed-islands-dokdo-takeshima-4020786](https://www.channelnewsasia.com/asia/south-korea-protest-japan-earthquake-tsunami-alert-map-disputed-islands-dokdo-takeshima-4020786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:58:33+00:00



## Mould-breaker Warner bows out on his own terms
 - [https://www.channelnewsasia.com/sport/mould-breaker-warner-bows-out-his-own-terms-4020811](https://www.channelnewsasia.com/sport/mould-breaker-warner-bows-out-his-own-terms-4020811)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:49:48+00:00



## Britain's Anunoby helps new NBA club upset high-flying T-Wolves
 - [https://www.channelnewsasia.com/sport/britains-anunoby-helps-new-nba-club-upset-high-flying-t-wolves-4020646](https://www.channelnewsasia.com/sport/britains-anunoby-helps-new-nba-club-upset-high-flying-t-wolves-4020646)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:25:50+00:00



## Indonesia books 2023 fiscal deficit of 1.65%, smaller than plan
 - [https://www.channelnewsasia.com/business/indonesia-books-2023-fiscal-deficit-165-smaller-plan-4020761](https://www.channelnewsasia.com/business/indonesia-books-2023-fiscal-deficit-165-smaller-plan-4020761)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:16:05+00:00



## Indonesia books smallest fiscal deficit in 12 years in 2023
 - [https://www.channelnewsasia.com/business/indonesia-books-smallest-fiscal-deficit-12-years-2023-4020761](https://www.channelnewsasia.com/business/indonesia-books-smallest-fiscal-deficit-12-years-2023-4020761)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:16:05+00:00



## AstraZeneca, Sanofi's RSV infant shots approved in China
 - [https://www.channelnewsasia.com/asia/astrazeneca-sanofi-infant-shots-china-approved-4020686](https://www.channelnewsasia.com/asia/astrazeneca-sanofi-infant-shots-china-approved-4020686)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:15:15+00:00



## 'Helpless': Japan earthquake shatters New Year calm
 - [https://www.channelnewsasia.com/asia/japan-earthquake-new-year-residents-ishikawa-shika-rations-water-4020716](https://www.channelnewsasia.com/asia/japan-earthquake-new-year-residents-ishikawa-shika-rations-water-4020716)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:14:00+00:00



## China's home sales during New Year holiday fall 26% compared with 2023
 - [https://www.channelnewsasia.com/business/chinas-home-sales-during-new-year-holiday-fall-26-compared-2023-4020756](https://www.channelnewsasia.com/business/chinas-home-sales-during-new-year-holiday-fall-26-compared-2023-4020756)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:11:03+00:00



## Russia pounds Ukrainian cities after Putin vows revenge
 - [https://www.channelnewsasia.com/world/russia-pounds-ukrainian-cities-after-putin-vows-revenge-4020386](https://www.channelnewsasia.com/world/russia-pounds-ukrainian-cities-after-putin-vows-revenge-4020386)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T08:08:41+00:00



## Djokovic hampered by wrist issue at United Cup
 - [https://www.channelnewsasia.com/sport/djokovic-hampered-wrist-issue-united-cup-4020706](https://www.channelnewsasia.com/sport/djokovic-hampered-wrist-issue-united-cup-4020706)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T07:34:33+00:00



## Djokovic hampered by wrist issue at United Cup as Serbia reach quarters
 - [https://www.channelnewsasia.com/sport/djokovic-hampered-wrist-issue-united-cup-serbia-reach-quarters-4020706](https://www.channelnewsasia.com/sport/djokovic-hampered-wrist-issue-united-cup-serbia-reach-quarters-4020706)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T07:34:33+00:00



## Thailand approves tax cuts on alcoholic beverages, entertainment venues to boost tourism
 - [https://www.channelnewsasia.com/business/thailand-approves-tax-cuts-alcoholic-beverages-entertainment-venues-boost-tourism-4020711](https://www.channelnewsasia.com/business/thailand-approves-tax-cuts-alcoholic-beverages-entertainment-venues-boost-tourism-4020711)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T07:34:15+00:00



## Thailand approves tax cuts on booze and night clubs to boost tourism
 - [https://www.channelnewsasia.com/business/thailand-approves-tax-cuts-booze-and-night-clubs-boost-tourism-4020711](https://www.channelnewsasia.com/business/thailand-approves-tax-cuts-booze-and-night-clubs-boost-tourism-4020711)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T07:34:00+00:00



## Vietnam central bank sets 2024 credit growth cap for banking system at 15%
 - [https://www.channelnewsasia.com/business/vietnam-central-bank-sets-2024-credit-growth-cap-banking-system-15-4020701](https://www.channelnewsasia.com/business/vietnam-central-bank-sets-2024-credit-growth-cap-banking-system-15-4020701)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T07:31:31+00:00



## Save this list: 11 cafes and restaurants in Singapore with no extra GST charge in 2024
 - [https://www.channelnewsasia.com/dining/restaurants-cafes-singapore-no-extra-gst-charge-4020651](https://www.channelnewsasia.com/dining/restaurants-cafes-singapore-no-extra-gst-charge-4020651)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T07:30:20+00:00

Singapore’s GST rate has been raised from 8 per cent to 9 per cent on Jan 1, 2024, but you don’t have to worry about calculating the tax at these eateries.

## Indonesia's December inflation eases more than expected
 - [https://www.channelnewsasia.com/business/indonesias-december-inflation-eases-more-expected-4020676](https://www.channelnewsasia.com/business/indonesias-december-inflation-eases-more-expected-4020676)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T07:03:00+00:00



## Singaporean actress Celest Chong says her co-stars overseas would stir up trouble when she was cast as lead
 - [https://www.channelnewsasia.com/entertainment/celest-chong-actress-singaporean-working-overseas-4020556](https://www.channelnewsasia.com/entertainment/celest-chong-actress-singaporean-working-overseas-4020556)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T07:00:45+00:00

The 44-year-old, who recently moved back to Singapore after 13 years in Toronto, spoke to #JustSwipeLah about her showbiz journey.

## Relentless rains wreak havoc across Australia's east
 - [https://www.channelnewsasia.com/sustainability/relentless-rains-wreak-havoc-across-australias-east-4020536](https://www.channelnewsasia.com/sustainability/relentless-rains-wreak-havoc-across-australias-east-4020536)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T06:34:23+00:00



## Trott to continue as Afghanistan head coach for 2024
 - [https://www.channelnewsasia.com/sport/trott-continue-afghanistan-head-coach-2024-4020641](https://www.channelnewsasia.com/sport/trott-continue-afghanistan-head-coach-2024-4020641)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T06:21:48+00:00



## Chinese student found in US woods after 'cyber kidnapping' scam
 - [https://www.channelnewsasia.com/asia/china-student-kidnapping-scam-us-utah-woods-4020266](https://www.channelnewsasia.com/asia/china-student-kidnapping-scam-us-utah-woods-4020266)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T05:45:03+00:00

The 17-year-old boy's parents in China were extorted of US$80,000.

## Waugh slams S Africa for prioritising domestic T20 tournament over NZ tests
 - [https://www.channelnewsasia.com/sport/waugh-slams-s-africa-prioritising-domestic-t20-tournament-over-nz-tests-4020586](https://www.channelnewsasia.com/sport/waugh-slams-s-africa-prioritising-domestic-t20-tournament-over-nz-tests-4020586)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T05:28:03+00:00



## Australia out for Pakistan sweep in Warner Week
 - [https://www.channelnewsasia.com/sport/australia-out-pakistan-sweep-warner-week-4020526](https://www.channelnewsasia.com/sport/australia-out-pakistan-sweep-warner-week-4020526)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T04:46:27+00:00



## China's yuan down on first trading day of 2024, policy easing eyed
 - [https://www.channelnewsasia.com/business/chinas-yuan-down-first-trading-day-2024-policy-easing-eyed-4020496](https://www.channelnewsasia.com/business/chinas-yuan-down-first-trading-day-2024-policy-easing-eyed-4020496)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T04:32:29+00:00



## Bentancur's return a huge lift for Spurs squad: Postecoglou
 - [https://www.channelnewsasia.com/sport/bentancurs-return-huge-lift-spurs-squad-postecoglou-4020486](https://www.channelnewsasia.com/sport/bentancurs-return-huge-lift-spurs-squad-postecoglou-4020486)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T04:25:00+00:00



## Singapore private home prices rose at slower pace of 6.7% in 2023
 - [https://www.channelnewsasia.com/singapore/singapore-private-home-prices-increased-slower-pace-2023-ura-flash-estimates-4020396](https://www.channelnewsasia.com/singapore/singapore-private-home-prices-increased-slower-pace-2023-ura-flash-estimates-4020396)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T04:15:03+00:00

Private home prices rose at a slower pace for the second consecutive year in 2023.

## Hong Kong tycoon Jimmy Lai pleads not guilty in national security trial
 - [https://www.channelnewsasia.com/asia/hong-kong-jimmy-lai-trial-sedition-national-security-conspiracy-jail-4020451](https://www.channelnewsasia.com/asia/hong-kong-jimmy-lai-trial-sedition-national-security-conspiracy-jail-4020451)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T04:11:00+00:00



## YG Entertainment's BabyMonster will release new song titled Stuck In The Middle on Feb 1
 - [https://www.channelnewsasia.com/entertainment/babymonster-new-song-stuck-middle-4020466](https://www.channelnewsasia.com/entertainment/babymonster-new-song-stuck-middle-4020466)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T04:08:27+00:00

In a video detailing the future plans of BabyMonster, YG Entertainment founder Yang Hyun-suk said that the new song is "not a hip-hop track" and "feels fresh" to him.

## China calls on Taiwan's people to promote 'peaceful reunification'
 - [https://www.channelnewsasia.com/asia/china-calls-taiwans-people-promote-peaceful-reunification-4020431](https://www.channelnewsasia.com/asia/china-calls-taiwans-people-promote-peaceful-reunification-4020431)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T04:00:16+00:00



## LV Remix: Louis Vuitton brings back old favourites with a new twist
 - [https://www.channelnewsasia.com/style-beauty/louis-vuitton-lv-remix-monogram-vernis-4020371](https://www.channelnewsasia.com/style-beauty/louis-vuitton-lv-remix-monogram-vernis-4020371)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T03:54:20+00:00

The much-loved Monogram Vernis and Monogram Denim collections make a return with new colours and silhouettes.

## State Street makes first foreign dollar/won trade under new plan - sources
 - [https://www.channelnewsasia.com/business/state-street-makes-first-foreign-dollar-won-trade-under-new-plan-sources-4020456](https://www.channelnewsasia.com/business/state-street-makes-first-foreign-dollar-won-trade-under-new-plan-sources-4020456)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T03:44:41+00:00



## Resale flat prices for 2023 rose 4.8%, less than half of 2022's increase
 - [https://www.channelnewsasia.com/singapore/hdb-resale-flat-prices-2023-increase-bto-supply-4020341](https://www.channelnewsasia.com/singapore/hdb-resale-flat-prices-2023-increase-bto-supply-4020341)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T03:28:00+00:00

A strong pipeline of supply and the introduction of cooling measures have continued to moderate the rate of increase in resale prices, says HDB.

## Asia's factories end 2023 on soft note amid fragile China recovery
 - [https://www.channelnewsasia.com/business/asias-factories-end-2023-soft-note-amid-fragile-china-recovery-4020426](https://www.channelnewsasia.com/business/asias-factories-end-2023-soft-note-amid-fragile-china-recovery-4020426)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T03:23:04+00:00



## ‘Jangan gunakan kami’: Pengendali rumah tumpangan kanak-kanak merungut ibu bapa abaikan anak-anak
 - [https://www.channelnewsasia.com/malaysia/rumah-tumpangan-merungut-ibu-bapa-abaikan-anak-anak-4001731](https://www.channelnewsasia.com/malaysia/rumah-tumpangan-merungut-ibu-bapa-abaikan-anak-anak-4001731)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T03:22:59+00:00

Kanak-kanak harus membesar dalam suasana kekeluargaan kerana kehidupan di rumah tumpangan boleh menjejaskan perkembangan dan kesejahteraan mereka, kata pakar.

## Bitcoin climbs above $45,000 for first time since April 2022
 - [https://www.channelnewsasia.com/business/bitcoin-climbs-above-45000-first-time-april-2022-4020421](https://www.channelnewsasia.com/business/bitcoin-climbs-above-45000-first-time-april-2022-4020421)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T03:19:39+00:00



## Bitcoin climbs above US$45,000 for first time since April 2022
 - [https://www.channelnewsasia.com/business/bitcoin-climbs-above-us45000-first-time-april-2022-4020421](https://www.channelnewsasia.com/business/bitcoin-climbs-above-us45000-first-time-april-2022-4020421)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T03:19:00+00:00



## Brighton manager surprised by injured Mitoma's Asian Cup call-up
 - [https://www.channelnewsasia.com/sport/brighton-manager-surprised-injured-mitomas-asian-cup-call-4020416](https://www.channelnewsasia.com/sport/brighton-manager-surprised-injured-mitomas-asian-cup-call-4020416)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T03:09:35+00:00



## Young boy from Singapore cries after meeting lifeguard from Australian show Bondi Rescue
 - [https://www.channelnewsasia.com/trending/singapore-boy-cries-meeting-bondi-rescue-lifeguard-4020366](https://www.channelnewsasia.com/trending/singapore-boy-cries-meeting-bondi-rescue-lifeguard-4020366)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T02:58:44+00:00

"He just gave me the biggest hug and started bawling his eyes out," said lifeguard Harrison Reid in a TikTok video capturing the moment.

## Oil jumps 1% in New Year after US forces repel Houthis in Red Sea
 - [https://www.channelnewsasia.com/business/oil-jumps-1-new-year-after-us-forces-repel-houthis-red-sea-4020391](https://www.channelnewsasia.com/business/oil-jumps-1-new-year-after-us-forces-repel-houthis-red-sea-4020391)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T02:43:34+00:00



## Oil jumps 1.5% in New Year after US forces repel Houthis in Red Sea
 - [https://www.channelnewsasia.com/business/oil-jumps-15-new-year-after-us-forces-repel-houthis-red-sea-4020391](https://www.channelnewsasia.com/business/oil-jumps-15-new-year-after-us-forces-repel-houthis-red-sea-4020391)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T02:43:34+00:00



## Asia shares get 2024 to steady start with busy data calendar in focus
 - [https://www.channelnewsasia.com/business/asia-shares-get-2024-steady-start-busy-data-calendar-focus-4020381](https://www.channelnewsasia.com/business/asia-shares-get-2024-steady-start-busy-data-calendar-focus-4020381)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T02:37:01+00:00



## South Korea opposition chief stabbed during visit to Busan: Report
 - [https://www.channelnewsasia.com/asia/south-korea-opposition-chief-stabbed-busan-lee-jae-myung-4020321](https://www.channelnewsasia.com/asia/south-korea-opposition-chief-stabbed-busan-lee-jae-myung-4020321)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T02:01:29+00:00



## South Korea opposition chief conscious after stabbing in Busan
 - [https://www.channelnewsasia.com/asia/south-korea-opposition-chief-stabbed-neck-busan-lee-jae-myung-4020321](https://www.channelnewsasia.com/asia/south-korea-opposition-chief-stabbed-neck-busan-lee-jae-myung-4020321)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T02:01:00+00:00

Lee Jae-myung was visiting the site of a proposed airport when he was approached by a man asking for his autograph.

## China factory activity growth accelerates in Dec - Caixin PMI
 - [https://www.channelnewsasia.com/business/china-factory-activity-growth-accelerates-dec-caixin-pmi-4020331](https://www.channelnewsasia.com/business/china-factory-activity-growth-accelerates-dec-caixin-pmi-4020331)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T01:48:25+00:00



## China factory activity growth accelerates in December: Caixin PMI
 - [https://www.channelnewsasia.com/business/china-factory-activity-growth-accelerates-december-caixin-pmi-4020331](https://www.channelnewsasia.com/business/china-factory-activity-growth-accelerates-december-caixin-pmi-4020331)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T01:48:00+00:00



## Brooklyn Beckham became a ‘watch guy’ after getting US$152,700 timepiece from dad David Beckham on his birthday
 - [https://www.channelnewsasia.com/style-beauty/brooklyn-beckham-watch-guy-patek-philippe-nautilus-rolex-4020291](https://www.channelnewsasia.com/style-beauty/brooklyn-beckham-watch-guy-patek-philippe-nautilus-rolex-4020291)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T01:40:02+00:00

Opening up about his growing collection of eye-wateringly pricey watches, Brooklyn Beckham said he became a “watch guy” when his dad, David Beckham, gave him a rare timepiece for his 21st birthday.

## Warner appeals for return of missing baggy green on eve of final test
 - [https://www.channelnewsasia.com/sport/warner-appeals-return-missing-baggy-green-eve-final-test-4020326](https://www.channelnewsasia.com/sport/warner-appeals-return-missing-baggy-green-eve-final-test-4020326)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T01:39:23+00:00



## Dollar starts 2024 steady, focus switches to data
 - [https://www.channelnewsasia.com/business/dollar-starts-2024-steady-focus-switches-data-4020311](https://www.channelnewsasia.com/business/dollar-starts-2024-steady-focus-switches-data-4020311)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T01:23:59+00:00



## Singapore’s economy grew 2.8% in Q4 as manufacturing sector rebounds: Advance estimates
 - [https://www.channelnewsasia.com/singapore/singapore-q4-2023-gdp-advance-estimates-mti-economy-4020241](https://www.channelnewsasia.com/singapore/singapore-q4-2023-gdp-advance-estimates-mti-economy-4020241)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T00:53:01+00:00

Singapore's economy expanded 2.8 per cent in the fourth quarter of 2023, faster than the 1 per cent growth in the previous quarter, according to MTI's advance estimates.

## Mexican actress Ana Ofelia Murguia, who voiced Mama Coco in Disney's Coco, dies at 90
 - [https://www.channelnewsasia.com/entertainment/ana-ofelia-murguia-coco-death-4020061](https://www.channelnewsasia.com/entertainment/ana-ofelia-murguia-coco-death-4020061)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T00:52:00+00:00

Her cause of death was not revealed.

## Mexican actress Ana Ofelia Murguia, who voiced Mama Coco in Disney's Coco, dies at 90
 - [https://www.channelnewsasia.com/entertainment/ana-ofelia-murguia-mama-coco-death-4020061](https://www.channelnewsasia.com/entertainment/ana-ofelia-murguia-mama-coco-death-4020061)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T00:52:00+00:00

Coco, which was released in 2017, brought Murguia to an international audience late in life.

## S Korea factory activity contracts on cooling new orders -PMI
 - [https://www.channelnewsasia.com/business/s-korea-factory-activity-contracts-cooling-new-orders-pmi-4020256](https://www.channelnewsasia.com/business/s-korea-factory-activity-contracts-cooling-new-orders-pmi-4020256)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T00:35:09+00:00



## South Korea factory activity contracts on cooling new orders
 - [https://www.channelnewsasia.com/business/south-korea-factory-activity-contracts-cooling-new-orders-4020256](https://www.channelnewsasia.com/business/south-korea-factory-activity-contracts-cooling-new-orders-4020256)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-01-02T00:35:00+00:00



