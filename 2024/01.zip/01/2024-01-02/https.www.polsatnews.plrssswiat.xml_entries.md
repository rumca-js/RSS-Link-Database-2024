# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## USA. Rektor Uniwersytetu Harvarda złożyła rezygnację. W tle antysemityzm
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/harvardddd](https://www.polsatnews.pl/wiadomosc/2024-01-02/harvardddd)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T21:23:00+00:00

Rektor amerykańskiego Uniwersytetu Harvarda, Claudine Gay złożyła rezygnację w związku z oskarżeniami dotyczącymi antysemityzmu i plagiatu - podały amerykańskie media. Gay, która była drugą kobietą w historii na tym stanowisku, pełniła je zaledwie pół roku.

## Włochy. Ksiądz obraził papieża Franciszka. Dzień później został ekskomunikowany
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/wlochy-ksiadz-obrazil-papieza-franciszka-dzien-pozniej-zostal-ekskomunikowany](https://www.polsatnews.pl/wiadomosc/2024-01-02/wlochy-ksiadz-obrazil-papieza-franciszka-dzien-pozniej-zostal-ekskomunikowany)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T20:57:00+00:00

Ksiądz Ramon Guidetti został ekskomunikowany przez biskupa Livorno Simone Giustiego. Decyzja zapadła po słowach duchownego pod adresem papieża Franciszka. Guidetti powiedział podczas mszy, że przywódca Kościoła jest uzurpatorem i masonem.

## Marzyli o "podróży w czasie". Pasażerowie samolotu wylądowali w złym roku
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/marzyli-o-podrozy-w-czasie-pasazerowie-samolotu-wyladowali-w-zlym-roku](https://www.polsatnews.pl/wiadomosc/2024-01-02/marzyli-o-podrozy-w-czasie-pasazerowie-samolotu-wyladowali-w-zlym-roku)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T20:41:00+00:00

Pasażerowie samolotu United Airlines chcieli przeżyć dwie noce sylwestrowe, odbywając podróż w czasie dzięki lotowi z wyspy Guam do stolicy Hawajów. Opóźnienie samolotu spowodowało jednak, że wylądowali w złym, już nowym roku i ominęło ich noworoczne odliczanie. Część z nich nie ukrywa rozczarowania.

## Atak zimy w Skandynawii. W Szwecji rekordowe mrozy, Norwegia zasypana śniegiem
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/atak-zimy-w-skandynawii-w-szwecji-rekordowe-mrozy-norwegia-zasypana-sniegiem](https://www.polsatnews.pl/wiadomosc/2024-01-02/atak-zimy-w-skandynawii-w-szwecji-rekordowe-mrozy-norwegia-zasypana-sniegiem)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T19:29:00+00:00

W Szwecji odnotowano rekordowo niskie temperatury, a Norwegię nawiedziły silne śnieżyce. Mróz sięga nawet minus 40 stopni. W rezultacie zamknięto część szkół, sparaliżowana jest również komunikacja kolejowa. Ponadto zawieszono kursowanie promów łączących Szwecję z Polską.

## Eksplozja w Libanie. Zginął ważny członek Hamasu
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/eksplozja-w-libanie-zginal-wazny-czlonek-hamasu](https://www.polsatnews.pl/wiadomosc/2024-01-02/eksplozja-w-libanie-zginal-wazny-czlonek-hamasu)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T18:11:00+00:00

Potężny wybuch na przedmieściach Bejrutu, stolicy Libanu. Zginęły cztery osoby, w tym wysoki rangą członek Hamasu - Saleh al-Arouri. Według doniesień medialnych jego śmierć to skutek ataku izraelskiego drona, a fakt, że stało się to poza granicami Izraela może wskazywać na eskalację konfliktu na Bliskim Wschodzie.

## Turcja. Masowe aresztowania "szpiegów". Mieli działać na rzecz Izraela
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/turcja-masowe-aresztowania-szpiegow-mieli-dzialac-na-rzecz-izraela](https://www.polsatnews.pl/wiadomosc/2024-01-02/turcja-masowe-aresztowania-szpiegow-mieli-dzialac-na-rzecz-izraela)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T17:20:00+00:00

Decyzją władz Turcji aresztowane zostały 33 osoby, którym zarzucono szpiegostwo na korzyść Izraela. Kilka tygodni temu izraelskie służby specjalne zapowiadały, że są gotowe zniszczyć Hamas w każdym miejscu, w tym Libanie, Katarze i właśnie Turcji. Relacje Ankary i Tel Awiwu pozostają napięte od dłuższego czasu.

## Mistrzostwa świata w szachach. Jan-Krzysztof Duda odmówił podania ręki Rosjaninowi
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/mistrzostwa-swiata-w-szachach-jan-krzysztof-duda-odmowil-podania-reki-rosjaninowi](https://www.polsatnews.pl/wiadomosc/2024-01-02/mistrzostwa-swiata-w-szachach-jan-krzysztof-duda-odmowil-podania-reki-rosjaninowi)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T16:38:00+00:00

Jan-Krzysztof Duda zajął 45. miejsce na mistrzostwach świata w szachach szybkich oraz 10. miejsce w szachach błyskawicznych. Więcej niż o sportowym osiągnięciu polskiego arcymistrza mówi się jednak o jego zachowaniu wobec rosyjskiego szachisty. Polak odmówił mu podania ręki.

## Wielka Brytania. Afera w Izbie Lordów. Kupili szampany za 90 tysięcy funtów
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/wielka-brytania-afera-w-izbie-lordow-kupili-szampany-za-90-tysiecy-funtow](https://www.polsatnews.pl/wiadomosc/2024-01-02/wielka-brytania-afera-w-izbie-lordow-kupili-szampany-za-90-tysiecy-funtow)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T16:04:00+00:00

Izba wyższa brytyjskiego parlamentu znalazła się w ogniu krytyki z powodu wydatków. Według polityków Szkockiej Partii Narodowej lordowie zakupili w zeszłym roku blisko 1600 butelek szampana za prawie 90 tys. funtów. Ich zdaniem pokazuje to, że Izba Lordów jest archaiczna i oderwana od rzeczywistości, gdy coraz więcej osób ma problem z utrzymaniem swoich rodzin.

## Korea Północna. Kim Dzong Un ostatecznie zdecydował. Nie będzie pojednania z Południem
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/korea-polnocna-kim-dzong-un-ostatecznie-zdecydowal-nie-bedzie-pojednania-z-poludniem](https://www.polsatnews.pl/wiadomosc/2024-01-02/korea-polnocna-kim-dzong-un-ostatecznie-zdecydowal-nie-bedzie-pojednania-z-poludniem)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T15:39:00+00:00

Rośnie napięcie między Koreą Północną a Południową. Kim Dzong Un podczas noworocznego przemówienia oświadczył, że Pjongjang nie będzie już dążyć do zjednoczenia i pojednania z Koreą Południową. Zapowiedział również wystrzelenie nowych satelitów szpiegowskich.

## Prawdziwy rarytas na aukcji. Auto Michaela Jordana może mieć każdy
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/prawdziwy-rarytas-na-aukcji-teraz-auto-michaela-jordana-moze-miec-kazdy](https://www.polsatnews.pl/wiadomosc/2024-01-02/prawdziwy-rarytas-na-aukcji-teraz-auto-michaela-jordana-moze-miec-kazdy)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T14:25:00+00:00

Należało do Michaela Jordana, była ikoną lat 90. podobnie jak Chicago Bulls. Dodatkowo ma stosunkowo niski przebieg, a cena jest kusząco przystępna. W ten sposób organizator aukcji chce sprzedać oldtimer z fabryki bmw z wyposażeniem, które przed trzema dekadami było nieosiągalne dla zwykłego śmiertelnika.

## Rosja: Tajne dekrety Władimira Putina. W 2023 roku podpisał ich więcej niż kiedykolwiek
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/rosja-tajne-dekrety-wladimira-putina-w-2023-roku-podpisal-ich-wiecej-niz-kiedykolwiek](https://www.polsatnews.pl/wiadomosc/2024-01-02/rosja-tajne-dekrety-wladimira-putina-w-2023-roku-podpisal-ich-wiecej-niz-kiedykolwiek)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T14:08:00+00:00

Władimir Putin poszedł na rekord. W ubiegłym roku, co drugi podpisany przez niego dokument miał status tajnego. Wzrost tej liczby najpewniej ma związek z toczącą się wojną w Ukrainie.

## USA. Gigantyczna wygrana w loterii Powerball. Padła w Nowy Rok
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/usa-gigantyczna-wygrana-w-loterii-powerball-padla-w-nowy-rok](https://www.polsatnews.pl/wiadomosc/2024-01-02/usa-gigantyczna-wygrana-w-loterii-powerball-padla-w-nowy-rok)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T13:45:00+00:00

Ktoś w amerykańskim stanie Michigan wygrał 842,4 miliona dolarów. Co więcej, po raz pierwszy w historii loterii Powerball szczęśliwe liczby zostały wylosowane w Nowy Rok. To dziesiąta największa wygrana, jaką odnotowano w tej grze w USA. Zwycięzca lub zwyciężczyni nie otrzyma jednak od razu pełnej sumy.

## Wołodymyr Zełenski nie gryzł się w język. "Putin was pożre, NATO, UE i demokrację"
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/wolodymyr-zelenski-nie-gryzie-sie-w-jezyk-putin-was-pozre-nato-ue-i-demokracje](https://www.polsatnews.pl/wiadomosc/2024-01-02/wolodymyr-zelenski-nie-gryzie-sie-w-jezyk-putin-was-pozre-nato-ue-i-demokracje)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T12:56:00+00:00

Ukraiński prezydent po raz kolejny od wybuchu wojny udzielił szczerego wywiadu The Economist. W rozmowie z prestiżowym tygodnikiem przyznaje, że kontrofensywa nie poszła po myśli Kijowa, jednak nie rezygnuje z odbicia Krymu. Ostrzega także Zachód przed wstrzymaniem pomocy Ukrainie. - Putin wyczuwa krew, swoją siłę. I pożre was na kolację - mówi Wołodymyr Zełenski.

## Rosjanie zaatakowali własną wioskę. Bomby spadły 150 km od granicy z Ukrainą
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/rosjanie-zaatakowali-wlasna-wioske-bomby-spadly-150-km-od-granicy-z-ukraina](https://www.polsatnews.pl/wiadomosc/2024-01-02/rosjanie-zaatakowali-wlasna-wioske-bomby-spadly-150-km-od-granicy-z-ukraina)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T12:10:00+00:00

Rosyjskie władze przyznały się do omyłkowego ostrzału własnej wioski. W trakcie zmasowanego ataku powietrznego na Ukrainę pociski spadły również na domy we wsi Pietropawłowka w regionie Woroneża. Siedem budynków w oddalonej o około 150 kilometrów od granic z Ukrainą miejscowości zostało zniszczonych, a ich lokatorzy musieli przenieść się do tymczasowych kwater.

## Posłuchał nawigacji w telefonie. Noc spędził w rzece pełnej krokodyli
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/posluchal-nawigacji-w-telefonie-noc-spedzil-w-rzece-pelnej-krokodyli](https://www.polsatnews.pl/wiadomosc/2024-01-02/posluchal-nawigacji-w-telefonie-noc-spedzil-w-rzece-pelnej-krokodyli)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T11:30:00+00:00

Brytyjskie media opisują losy przewodnika safari, który korzystając z dobrodziejstw nowoczesnej technologii zapomniał o zdrowym rozsądku. Słuchanie nawigacji w telefonie poskutkowało nocą spędzoną w rzece pełnej krokodyli. Wycieńczonego Michaela Turnera po 15 godzinach walki o życie uratowali ratownicy.

## Belgia. Kraj w sercu Unii Europejskiej może niedługo się rozpaść
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/belgia-kraj-w-sercu-unii-europejskiej-moze-niedlugo-sie-rozpasc](https://www.polsatnews.pl/wiadomosc/2024-01-02/belgia-kraj-w-sercu-unii-europejskiej-moze-niedlugo-sie-rozpasc)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T10:31:00+00:00

Belgia, kraj w środku Unii Europejskiej, może zniknąć. Skrajnie prawicowe ugrupowanie Vlaams Belang zyskuje poparcie. Jeśli zdoła uzyskać dobry wynik w czerwcowych wyborach, to może doprowadzić do deklaracji niepodległości przez Flandrię i rozpadu Belgii.

## Japonia. Rośnie liczba ofiar trzęsienia ziemi. Ogromne zniszczenia na ulicach miast
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/japonia-rosnie-liczba-ofiar-trzesienia-ziemi-ogromne-zniszczenia-na-ulicach](https://www.polsatnews.pl/wiadomosc/2024-01-02/japonia-rosnie-liczba-ofiar-trzesienia-ziemi-ogromne-zniszczenia-na-ulicach)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T09:36:00+00:00

Kilkadziesiąt osób zginęło, a ponad 100 wciąż czeka na pomoc w gruzach budynków - to efekt silnego trzęsienia ziemi w Japonii. Na półwyspie Noto w prefekturze Ishikawa pracują tysiące ratowników. Wcześniej rząd z obawy przed groźbą tsunami nakazał ewakuację 100 tysięcy mieszkańcom. Część z nich powróciła już do odciętych od wody i prądu domów. W następnych dniach może dojść do kolejnych wstrząsów.

## Japonia: Pożar samolotu na pasie startowym. Ogień wydobywał się z okien
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/japonia-pozar-samolotu-na-pasie-startowym-ogien-wydobywal-sie-z-okien](https://www.polsatnews.pl/wiadomosc/2024-01-02/japonia-pozar-samolotu-na-pasie-startowym-ogien-wydobywal-sie-z-okien)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T09:08:00+00:00

Do sieci trafiło nagranie z lotniska w Japonii, na którym widać, jak stojący w ogniu samolot toczy się po pasie startowym. Nagranie pokazuje, jak płomienie wydostają się przez okna maszyny.

## Sześciu fryzjerów zabitych. Mieli złamać lokalny obyczaj
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/pakistan-szesciu-fryzjerow-zastrzelonych-przy-granicy-z-afganistanem](https://www.polsatnews.pl/wiadomosc/2024-01-02/pakistan-szesciu-fryzjerow-zastrzelonych-przy-granicy-z-afganistanem)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T08:49:00+00:00

Associated Press informuje o zbrodni, do której doszło w Mir Ali - dawnej twierdzy pakistańskich talibów. Niezidentyfikowani napastnicy zastrzelili sześciu fryzjerów. Incydent zszokował miejscową ludność.

## Laureat pokojowej Nagrody Nobla Muhammad Yunus skazany za złamanie prawa
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/bangladesz-noblista-z-ekonomii-muhammad-yunus-skazany-za-zlamanie-prawa-zaprzecza-zarzutom](https://www.polsatnews.pl/wiadomosc/2024-01-02/bangladesz-noblista-z-ekonomii-muhammad-yunus-skazany-za-zlamanie-prawa-zaprzecza-zarzutom)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T08:35:00+00:00

Laureat pokojowej Nagrody Nobla Muhammad Yunus został skazany za złamanie prawa pracy w Bangladeszu. Jego zwolennicy uważają proces za element walki politycznej. - Zostałem ukarany za przestępstwo, którego nie popełniłem - skomentował Yunus wyrok.

## Kijów: Ostrzał przerwał rozmowę w Polsat News. "Będziemy uciekać"
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/kijow-mowil-o-zyciu-pod-ostrzalem-przerwal-transmisje-by-schronic-sie-przed-rosyjskim-atakiem](https://www.polsatnews.pl/wiadomosc/2024-01-02/kijow-mowil-o-zyciu-pod-ostrzalem-przerwal-transmisje-by-schronic-sie-przed-rosyjskim-atakiem)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T07:47:00+00:00

Rosjanie nieprzerwanie od kilku godzin ostrzeliwują Kijów. O obecnej sytuacji wprost z ukraińskiej stolicy opowiadał na antenie Polsat News Marian Prysiażniuk, dziennikarz i wolontariusz w armii ukraińskiej. Rozmowa została jednak przerwana przez zbliżający się nalot. - Będziemy uciekać do metra - zakończył Prysiażniuk.

## Alarm powietrzny w całej Ukrainie. Rosyjskie uderzenie w stolicę
 - [https://www.polsatnews.pl/wiadomosc/2024-01-02/alarm-powietrzny-w-calej-ukrainie-rosyjskie-uderzenie-w-stolice](https://www.polsatnews.pl/wiadomosc/2024-01-02/alarm-powietrzny-w-calej-ukrainie-rosyjskie-uderzenie-w-stolice)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-01-02T05:58:00+00:00

Nocny atak dronów obudził obronę powietrzną Kijowa. Ukraińskie wojsko ogłosiło alarm powietrzny na terenie całego kraju - do granic zbliżają się rosyjskie bombowce Tu-95MS, ukraińskie siły informują również o zbliżających się do stolicy kraju Kindżałach. Władimir Putin w noworocznym przemówienie zapowiedział wzmożone ataki rakietowe na Ukraińców.

