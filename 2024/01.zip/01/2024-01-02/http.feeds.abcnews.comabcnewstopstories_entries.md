# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## WATCH:  Passengers capture footage inside burning Japan Airlines plane
 - [https://abcnews.go.com/Travel/video/passengers-capture-footage-inside-burning-japan-airlines-plane-106057811](https://abcnews.go.com/Travel/video/passengers-capture-footage-inside-burning-japan-airlines-plane-106057811)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T22:27:44+00:00

A Japan Airlines plane was engulfed in flames after landing at Haneda Airport in Tokyo on Tuesday.

## WATCH:  The Chester Zoo welcomes baby lemur
 - [https://abcnews.go.com/US/video/chester-zoo-welcomes-baby-lemur-106057889](https://abcnews.go.com/US/video/chester-zoo-welcomes-baby-lemur-106057889)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T22:27:28+00:00

The Chester Zoo welcomed a critically endangered baby coquerel’s sifaka lemur. The new baby marked three months in December, and is already “full of personality,” the zoo said.

## Sen. Bob Menendez facing even more allegations in new superseding indictment
 - [https://abcnews.go.com/Politics/sen-bob-menendez-facing-charges-new-superseding-indictment/story?id=106056419](https://abcnews.go.com/Politics/sen-bob-menendez-facing-charges-new-superseding-indictment/story?id=106056419)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T22:03:11+00:00

Sen. Robert Menendez, D-N.J., faces additional allegations of wrongdoing contained in a superseding indictment returned Tuesday in New York.

## Trump appeals Maine 14th Amendment election disqualification to state Superior Court
 - [https://abcnews.go.com/Politics/trump-appeals-maine-14th-amendment-election-disqualification-state/story?id=106051232](https://abcnews.go.com/Politics/trump-appeals-maine-14th-amendment-election-disqualification-state/story?id=106051232)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T21:45:12+00:00

A decision from Maine’s Superior Court could then be appealed to the Maine Supreme Judicial Court or the U.S. Supreme Court.

## 'Black Panther' actress Carrie Bernans pinned under food truck in NYC crash
 - [https://abcnews.go.com/Entertainment/wireStory/black-panther-performer-carrie-bernans-identified-pedestrian-hurt-106054949](https://abcnews.go.com/Entertainment/wireStory/black-panther-performer-carrie-bernans-identified-pedestrian-hurt-106054949)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T21:13:23+00:00

The woman who was pinned under a food truck when a driver fleeing police plowed into pedestrians in midtown Manhattan has been identified as an actor who has appeared in films such as &ldquo;Black Panther&rdquo; and &ldquo;The Color Purple.&rdquo;

## WATCH:  103-year-old woman meeting her great-granddaughter will melt your heart
 - [https://abcnews.go.com/GMA/Family/video/103-year-woman-meeting-great-granddaughter-melt-heart-106052706](https://abcnews.go.com/GMA/Family/video/103-year-woman-meeting-great-granddaughter-melt-heart-106052706)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T19:16:12+00:00

Sydney Mittelstadt and her husband took their daughter Margot to Des Moines, Iowa, to meet her Nannie on her 103rd birthday.

## Harvard President Claudine Gay announces resignation
 - [https://abcnews.go.com/US/harvard-president-claudine-gay-resignation/story?id=106050710](https://abcnews.go.com/US/harvard-president-claudine-gay-resignation/story?id=106050710)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T19:11:19+00:00

Embattled Harvard University President Claudine Gay has resigned, she announced on Tuesday.

## Man found dead at Salt Lake City airport after climbing inside jet engine
 - [https://abcnews.go.com/US/wireStory/man-found-dead-salt-lake-city-airport-after-106051366](https://abcnews.go.com/US/wireStory/man-found-dead-salt-lake-city-airport-after-106051366)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T18:54:17+00:00

A man has been found dead at Salt Lake City International Airport after police say he breached an emergency exit door and climbed inside a jet engine

## Rare earthquake rattles Queens, Roosevelt Island
 - [https://abcnews.go.com/US/rare-earthquake-rattles-queens-roosevelt-island/story?id=106050726](https://abcnews.go.com/US/rare-earthquake-rattles-queens-roosevelt-island/story?id=106050726)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T18:14:42+00:00

Residents of Queens were awakened by a rare earthquake in New York City on Tuesday morning.

## Israel-Gaza live updates: Top Hamas leader killed in Beirut strike, group says
 - [https://abcnews.go.com/International/live-updates/israel-hamas-war-2024/?id=106026146](https://abcnews.go.com/International/live-updates/israel-hamas-war-2024/?id=106026146)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T17:55:39+00:00

Live updates on the Israel-Hamas war.

## 22 hospitalized with carbon monoxide poisoning after attending LDS church in Utah
 - [https://abcnews.go.com/Health/22-hospitalized-carbon-monoxide-poisoning-after-attending-utah/story?id=106043245](https://abcnews.go.com/Health/22-hospitalized-carbon-monoxide-poisoning-after-attending-utah/story?id=106043245)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T17:12:48+00:00

At least 22 people were hospitalized with carbon monoxide poisoning at a Church of Jesus Christ of Latter-day Saints building in Utah on New Year's Eve.

## Gunman breaks into Colo. Supreme Court building; intrusion unrelated to Trump: Police
 - [https://abcnews.go.com/US/wireStory/gunman-breaks-colorado-supreme-court-building-intrusion-unrelated-106047705](https://abcnews.go.com/US/wireStory/gunman-breaks-colorado-supreme-court-building-intrusion-unrelated-106047705)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T16:46:18+00:00

Authorities say a gunman inflicted &ldquo;extensive damage&rdquo; to the building housing the Colorado Supreme Court

## Basdeo Panday, Trinidad and Tobago's first prime minister of Indian descent, dies
 - [https://abcnews.go.com/International/wireStory/basdeo-panday-trinidad-tobagos-prime-minister-indian-descent-106046829](https://abcnews.go.com/International/wireStory/basdeo-panday-trinidad-tobagos-prime-minister-indian-descent-106046829)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T16:11:51+00:00

Basdeo Panday, a former prime minister of Trinidad and Tobago who was the first person of Indian descent to hold that position, has died

## Trump set to appeal Colorado 14th Amendment ballot disqualification case
 - [https://abcnews.go.com/Politics/trump-set-appeal-colorado-14th-amendment-ballot-disqualification/story?id=106032844](https://abcnews.go.com/Politics/trump-set-appeal-colorado-14th-amendment-ballot-disqualification/story?id=106032844)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T15:15:12+00:00

Donald Trump's legal team as early as Tuesday could appeal to the U.S. Supreme Court the Colorado Supreme Court decision barring him from the GOP primary ballot.

## WATCH:  Plane engulfed in flames on runway at Tokyo airport
 - [https://abcnews.go.com/International/video/plane-engulfed-flames-runway-tokyo-airport-106042787](https://abcnews.go.com/International/video/plane-engulfed-flames-runway-tokyo-airport-106042787)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T13:01:07+00:00

A Japan Airlines jet was engulfed in flames at Tokyo's Haneda Airport after a possible collision with a Coast Guard aircraft.

## 'Loud explosions' in Kyiv as Russia again strikes capital, US ambassador says
 - [https://abcnews.go.com/International/loud-explosions-kyiv-russia-strikes-capital-us-ambassador/story?id=106040939](https://abcnews.go.com/International/loud-explosions-kyiv-russia-strikes-capital-us-ambassador/story?id=106040939)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T12:22:56+00:00

At least four people were killed and 92 were injured in Tuesday's attacks, Ukrainian President Volodymyr Zelenskyy said.

## Japan Airlines plane on fire on runway at Tokyo airport
 - [https://abcnews.go.com/International/plane-fire-lands-japanese-airport/story?id=106040352](https://abcnews.go.com/International/plane-fire-lands-japanese-airport/story?id=106040352)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T10:22:34+00:00

A Japan Airlines plane landed while on fire at Haneda Airport on Tuesday.

## South Korean opposition leader stabbed, rushed to hospital
 - [https://abcnews.go.com/International/south-korean-opposition-leader-stabbed-rushed-hospital/story?id=106038456](https://abcnews.go.com/International/south-korean-opposition-leader-stabbed-rushed-hospital/story?id=106038456)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T08:22:29+00:00

South Korean Democratic Party Leader Lee Jae-myung was hospitalized after being attacked during a press conference in Busan, South Korea, state media reported.

## ESPN apologizes for showing video of woman flashing breast during Sugar Bowl
 - [https://abcnews.go.com/Sports/wireStory/espn-apologizes-showing-video-woman-flashing-breast-sugar-106039569](https://abcnews.go.com/Sports/wireStory/espn-apologizes-showing-video-woman-flashing-breast-sugar-106039569)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T07:18:30+00:00

ESPN has apologized for a video clip of a woman bearing her breast that was shown during the broadcast of the Sugar Bowl in New Orleans

## A boozy banana drink in Uganda is under threat as authorities restrict home brewers
 - [https://abcnews.go.com/Business/wireStory/boozy-banana-drink-uganda-threat-authorities-move-restrict-106039382](https://abcnews.go.com/Business/wireStory/boozy-banana-drink-uganda-threat-authorities-move-restrict-106039382)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T07:10:28+00:00

Tonto is a legendary traditional drink in Uganda

## South Korean opposition leader is attacked and injured by an unidentified man
 - [https://abcnews.go.com/International/wireStory/south-korean-opposition-leader-attacked-injured-unidentified-man-106037986](https://abcnews.go.com/International/wireStory/south-korean-opposition-leader-attacked-injured-unidentified-man-106037986)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T02:54:55+00:00

South Korean emergency officials say opposition leader Lee Jae-myung has been attacked and injured by an unidentified man during a visit to the southeastern city of Busan

## Train derails and catches fire near San Francisco, causing minor injuries
 - [https://abcnews.go.com/Technology/wireStory/train-derails-catches-fire-san-francisco-causing-minor-106036797](https://abcnews.go.com/Technology/wireStory/train-derails-catches-fire-san-francisco-causing-minor-106036797)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T01:50:19+00:00

Officials say several people suffered minor injuries and service was disrupted when a train derailed and caught fire on New Year&rsquo;s Day in the San Francisco Bay Area

## Navajo advocate for Indigenous people and environmental causes, dies in Phoenix
 - [https://abcnews.go.com/US/wireStory/klee-benally-navajo-advocate-indigenous-people-environmental-causes-106036785](https://abcnews.go.com/US/wireStory/klee-benally-navajo-advocate-indigenous-people-environmental-causes-106036785)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-01-02T01:42:14+00:00

Klee Benally, a Navajo man who advocated on behalf of Indigenous people and environmental causes, has died

