# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## AI-created “virtual influencers” are stealing business from humans
 - [https://arstechnica.com/ai/2023/12/ai-created-virtual-influencers-are-stealing-business-from-humans](https://arstechnica.com/ai/2023/12/ai-created-virtual-influencers-are-stealing-business-from-humans)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

The replaced influencers have my AI-generated sympathy

## An excellent specimen
 - [https://www.codeproject.com/Messages/5979981/an-excellent-specimen](https://www.codeproject.com/Messages/5979981/an-excellent-specimen)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

My apartment doesn't allow any pet peeves

## Dad Jokes
 - [https://fatherhood.gov/for-dads/dad-jokes](https://fatherhood.gov/for-dads/dad-jokes)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

Of course the US Government has a repository of bad jokes

## Developer touts the benefits of 'diagonal mode' Linux desktop
 - [https://www.extremetech.com/computing/developer-touts-the-benefits-of-diagonal-mode-linux-desktop](https://www.extremetech.com/computing/developer-touts-the-benefits-of-diagonal-mode-linux-desktop)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

I am askew

## GitHub makes Copilot Chat generally available, letting devs ask questions about code
 - [https://techcrunch.com/2023/12/29/github-makes-copilot-chat-generally-available-letting-devs-ask-questions-about-code](https://techcrunch.com/2023/12/29/github-makes-copilot-chat-generally-available-letting-devs-ask-questions-about-code)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

In case you need someone to take the blame for your code

## HTML, The Programming Language
 - [https://html-lang.org](https://html-lang.org)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

HTML, the programming language, is a practical, turing-complete[1], stack-based programming language based on HTML, the markup language.

## How (and Why) to Optimize jQuery Code Performance for Large-Scale Application Development
 - [https://www.telerik.com/blogs/how-why-optimize-jquery-code-performance-large-scale-application-development](https://www.telerik.com/blogs/how-why-optimize-jquery-code-performance-large-scale-application-development)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

Optimizing jQuery code performance is crucial for large-scale application development. Learn why and what strategies to implement.

## Making Sense Of “Senseless” JavaScript Features
 - [https://www.smashingmagazine.com/2023/12/making-sense-of-senseless-javascript-features](https://www.smashingmagazine.com/2023/12/making-sense-of-senseless-javascript-features)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

JavaScript may be the most popular client-side language in the world, but it’s far from perfect and not without its quirks.

## Researchers use AI chatbots against themselves to 'jailbreak' each other
 - [https://techxplore.com/news/2023-12-ai-chatbots-jailbreak.html](https://techxplore.com/news/2023-12-ai-chatbots-jailbreak.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

Oh great - get them all plotting together now

## Self-healing code is the future of software development
 - [https://stackoverflow.blog/2023/12/28/self-healing-code-is-the-future-of-software-development](https://stackoverflow.blog/2023/12/28/self-healing-code-is-the-future-of-software-development)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

Code, heal thyself

## Soon, every employee will be both AI builder and AI consumer
 - [https://www.zdnet.com/article/soon-every-employee-will-be-both-ai-builder-and-ai-consumer](https://www.zdnet.com/article/soon-every-employee-will-be-both-ai-builder-and-ai-consumer)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

All we are saying, is give AI a chance

## Try this brand new analog computer
 - [https://spectrum.ieee.org/try-this-new-analog-computer](https://spectrum.ieee.org/try-this-new-analog-computer)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

Sometimes 0 and 1 just aren't enough

## Why you should only use TypeScript
 - [https://blog.disane.dev/en/why-you-should-only-use-typescript](https://blog.disane.dev/en/why-you-should-only-use-typescript)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-01-02T05:00:00+00:00

JavaScript is dead, long live TypeScript! I explain how TypeScript actively supports you in writing better and more reliable code in this article

