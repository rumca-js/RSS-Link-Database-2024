# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Names linked to Jeffrey Epstein set to be made public: All you need to know
 - [https://www.aljazeera.com/news/2024/1/2/names-linked-to-jeffrey-epstein-set-to-be-made-public-all-you-need-to-know?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/names-linked-to-jeffrey-epstein-set-to-be-made-public-all-you-need-to-know?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T20:56:13+00:00

Previously sealed court documents are expected to include names of more than 150 people linked to disgraced financier.

## Harvard president resigns amid controversy over anti-Semitisim hearing
 - [https://www.aljazeera.com/news/2024/1/2/harvard-president-resigns-amid-controversy-over-anti-semitisim-hearing?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/harvard-president-resigns-amid-controversy-over-anti-semitisim-hearing?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T20:27:46+00:00

Claudine Gay came under fire last month for her answers to a question on anti-Semitism on campus.

## Biden under pressure to act amid new fears of ‘ethnic cleansing’ in Gaza
 - [https://www.aljazeera.com/news/2024/1/2/biden-under-pressure-to-act-amid-new-fears-of-ethnic-cleansing-in-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/biden-under-pressure-to-act-amid-new-fears-of-ethnic-cleansing-in-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T20:17:38+00:00

Remarks from far-right ministers renew concerns that Israel aims to force Palestinians out of Gaza amid ongoing war.

## Hamas leader killed in Beirut explosion
 - [https://www.aljazeera.com/program/newsfeed/2024/1/2/hamas-leader-killed-in-beirut-explosion?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/2/hamas-leader-killed-in-beirut-explosion?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T20:14:01+00:00

Senior Hamas official Saleh al-Arouri has been killed in an Israeli drone strike in Beirut’s southern suburb of Dahiyeh.

## Israeli Cabinet members call for emigration of Palestinians from Gaza
 - [https://www.aljazeera.com/program/newsfeed/2024/1/2/israeli-cabinet-members-call-for-emigration-of-palestinians-from-gaza?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/2/israeli-cabinet-members-call-for-emigration-of-palestinians-from-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T19:07:12+00:00

Israeli Cabinet members call for emigration of Palestinians from Gaza

## What does a ‘new phase’ in Israel’s war on Gaza entail?
 - [https://www.aljazeera.com/program/inside-story/2024/1/2/what-does-a-new-phase-in-israels-war-on-gaza-entail?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/1/2/what-does-a-new-phase-in-israels-war-on-gaza-entail?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T18:43:09+00:00

Israel says it will withdraw some troops from the besieged Gaza Strip.

## Top Hamas official Saleh al-Arouri killed in Beirut suburb
 - [https://www.aljazeera.com/news/2024/1/2/top-hamas-official-saleh-al-arouri-killed-in-beirut-suburb?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/top-hamas-official-saleh-al-arouri-killed-in-beirut-suburb?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T17:50:06+00:00

At least six people killed in Israeli drone strike on Lebanese capital, state media report.

## Israel promises to fight genocide accusation at ICJ
 - [https://www.aljazeera.com/news/2024/1/2/israel-promises-to-defend-itself-against-genocide-accusation-at-icj?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/israel-promises-to-defend-itself-against-genocide-accusation-at-icj?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T17:42:18+00:00

South Africa says magnitude of death and destruction in Gaza meets the threshold of the 1948 Genocide Convention.

## Rubiales kiss not consensual, Spain’s Jenni Hermoso tells court
 - [https://www.aljazeera.com/sports/2024/1/2/jenni-hermoso-kiss-scandal-luis-rubiales-womens-world-cup-scandal?traffic_source=rss](https://www.aljazeera.com/sports/2024/1/2/jenni-hermoso-kiss-scandal-luis-rubiales-womens-world-cup-scandal?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T17:24:30+00:00

Hermoso appeared at a court in Madrid to give her version of the kiss by Rubiales following Spain&#039;s World Cup win.

## Palestinian shopkeeper describes ‘daily’ abuse by Israeli soldiers
 - [https://www.aljazeera.com/program/newsfeed/2024/1/2/palestinian-shopkeeper-describes-daily-abuse-by-israeli-soldiers?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/2/palestinian-shopkeeper-describes-daily-abuse-by-israeli-soldiers?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T15:58:42+00:00

A Palestinian petrol station attendant was kicked and stepped on by Israeli soldiers in the occupied West Bank.

## Israeli army launches attacks on targets in Syria and Lebanon
 - [https://www.aljazeera.com/news/2024/1/2/israeli-army-launches-attacks-on-targets-in-syria-and-lebanon?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/israeli-army-launches-attacks-on-targets-in-syria-and-lebanon?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T14:48:58+00:00

As war in Gaza rages, Israel is continuing its campaign against Syrian military and Hezbollah targets.

## Photos: Russian missiles pound Kyiv after Putin vows to intensify attacks
 - [https://www.aljazeera.com/gallery/2024/1/2/photos-russian-missiles-pound-kyiv-after-putin-vows-to-intensify-attacks?traffic_source=rss](https://www.aljazeera.com/gallery/2024/1/2/photos-russian-missiles-pound-kyiv-after-putin-vows-to-intensify-attacks?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T14:33:44+00:00

Four civilians were killed and 92 injured in an attack on the Ukrainian capital, President Volodymyr Zelenskyy said.

## Israeli soldier ‘brought baby back to Israel’ from Gaza
 - [https://www.aljazeera.com/program/newsfeed/2024/1/2/israeli-soldier-brought-baby-back-to-israel-from-gaza?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/2/israeli-soldier-brought-baby-back-to-israel-from-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T14:22:21+00:00

An Israeli army captain took a Palestinian baby girl from her home in Gaza back with him to Israel, says his friend.

## Dozens killed as extent of Japan earthquake damage becomes clear
 - [https://www.aljazeera.com/program/newsfeed/2024/1/2/dozens-killed-as-extent-of-japan-earthquake-damage-becomes-clear?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/2/dozens-killed-as-extent-of-japan-earthquake-damage-becomes-clear?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T14:14:40+00:00

Earthquakes that struck Japan on New Year’s Day have killed dozens of people and caused widespread damage.

## It is time to tax the rich… and their foundations
 - [https://www.aljazeera.com/opinions/2024/1/2/it-is-time-to-tax-the-rich-and-their-foundations?traffic_source=rss](https://www.aljazeera.com/opinions/2024/1/2/it-is-time-to-tax-the-rich-and-their-foundations?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T14:13:43+00:00

Philanthropic endowments are designed to protect the financial interests of the 1 percent. They should be taxed.

## Israel maintains onslaught as Gaza death toll tops 22,000
 - [https://www.aljazeera.com/news/2024/1/2/israeli-bombardment-ongoing-as-death-toll-surpasses-22000?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/israeli-bombardment-ongoing-as-death-toll-surpasses-22000?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T13:44:10+00:00

Gaza&#039;s health ministry says 22,185 Palestinians have now been killed in Gaza since October 7.

## Turkey arrests dozens suspected of spying for Israel
 - [https://www.aljazeera.com/news/2024/1/2/turkey-detains-33-people-suspected-of-spying-on-behalf-of-israel?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/turkey-detains-33-people-suspected-of-spying-on-behalf-of-israel?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T13:12:33+00:00

Ankara has previously warned that it will not allow Israel to strike at Hamas inside Turkey&#039;s borders.

## How devastating was Monday’s earthquake in Japan?
 - [https://www.aljazeera.com/news/2024/1/2/how-devastating-was-mondays-earthquake-in-japan?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/how-devastating-was-mondays-earthquake-in-japan?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T13:05:23+00:00

At least 30 people have been killed in Ishikawa while many people are believed to be trapped under rubble.

## What’s next for Netanyahu after top court ruling against judicial overhaul?
 - [https://www.aljazeera.com/news/2024/1/2/whats-next-for-netanyahu-after-top-court-ruling-against-judicial-overhaul?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/whats-next-for-netanyahu-after-top-court-ruling-against-judicial-overhaul?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T12:51:45+00:00

After months of protests, the Supreme Court nullifies a law that aimed to curb its powers and give parliament more sway.

## Bangladesh cricket star Shakib Al Hasan’s election run divides hometown
 - [https://www.aljazeera.com/sports/2024/1/2/bangladesh-cricket-star-shakib-al-hasans-election-run-divides-hometown?traffic_source=rss](https://www.aljazeera.com/sports/2024/1/2/bangladesh-cricket-star-shakib-al-hasans-election-run-divides-hometown?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T12:17:29+00:00

The country&#039;s biggest sporting icon is fighting for the ruling party in the January 7 vote, boycotted by the opposition.

## Survivors of Israel’s siege of Beirut see history repeating itself in Gaza
 - [https://www.aljazeera.com/features/2024/1/2/survivors-of-israels-siege-of-beirut-see-history-repeating-itself-in-gaza?traffic_source=rss](https://www.aljazeera.com/features/2024/1/2/survivors-of-israels-siege-of-beirut-see-history-repeating-itself-in-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T11:54:06+00:00

Residents of Beirut see parallels with Israel&#039;s tactics 42 years ago and today&#039;s campaign on the Palestinian enclave.

## Israeli raids kill five as lethal operations persist in occupied West Bank
 - [https://www.aljazeera.com/news/2024/1/2/five-palestinians-killed-in-israeli-raids-in-occupied-west-bank?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/five-palestinians-killed-in-israeli-raids-in-occupied-west-bank?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T11:52:36+00:00

The Israeli military says four Palestinians were killed in Azzun, while a fifth was shot dead in Qalqilya.

## People flee burning plane at Tokyo airport
 - [https://www.aljazeera.com/program/newsfeed/2024/1/2/people-flee-burning-plane-at-tokyo-airport?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/2/people-flee-burning-plane-at-tokyo-airport?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T10:29:11+00:00

Video shows the moment passengers flee a burning Japan Airlines plane on the runway of Tokyo&#039;s Haneda Airport.

## Collision leaves Japan Airlines plane in flames on Tokyo runway
 - [https://www.aljazeera.com/news/2024/1/2/plane-catches-fire-on-runway-at-japans-haneda-airport?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/plane-catches-fire-on-runway-at-japans-haneda-airport?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T10:28:36+00:00

Close to 400 passengers were evacuated to safety after the plane collided with another aircraft and caught fire.

## Russia continues to step up assault on Ukraine with massive missile barrage
 - [https://www.aljazeera.com/news/2024/1/2/russia-unleashes-barrage-of-missiles-on-ukraine?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/russia-unleashes-barrage-of-missiles-on-ukraine?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T10:27:25+00:00

Russia has escalated its attacks on Ukraine as its invasion enters a third calendar year.

## Sudan’s feared paramilitary leader signals ambition to rule the country
 - [https://www.aljazeera.com/news/2024/1/2/sudans-feared-paramilitary-leader-signals-ambition-to-rule-the-country?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/sudans-feared-paramilitary-leader-signals-ambition-to-rule-the-country?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T08:52:12+00:00

Mohamed Hamdan &#039;Hemedti&#039; Dagalo goes on an African tour to secure regional support and political legitimacy.

## What’s really at stake in the US moves to target TikTok?
 - [https://www.aljazeera.com/features/2024/1/2/whats-really-at-stake-in-the-us-moves-to-ban-tiktok?traffic_source=rss](https://www.aljazeera.com/features/2024/1/2/whats-really-at-stake-in-the-us-moves-to-ban-tiktok?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T07:59:42+00:00

Analysts say it is less about privacy concerns and more about narrative control.

## Somalia calls emergency cabinet meeting on Ethiopia-Somaliland port deal
 - [https://www.aljazeera.com/news/2024/1/2/somalias-cabinet-calls-emergency-meet-on-ethiopia-somaliland-port-deal?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/somalias-cabinet-calls-emergency-meet-on-ethiopia-somaliland-port-deal?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T07:57:38+00:00

Somalia to discuss pact allowing landlocked Ethiopia to use Red Sea port of Berbera, state news agency reports.

## Photos: In Colombia, illegally felled timber repurposed to help bees
 - [https://www.aljazeera.com/gallery/2024/1/2/photos-in-colombia-illegally-felled-timber-repurposed-to-help-bees?traffic_source=rss](https://www.aljazeera.com/gallery/2024/1/2/photos-in-colombia-illegally-felled-timber-repurposed-to-help-bees?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T07:51:55+00:00

The project has seen about 7,060 cubic feet of wood transformed into 1,000 bee hives.

## Israel’s war on Gaza: List of key events, day 88
 - [https://www.aljazeera.com/news/2024/1/2/israels-war-on-gaza-list-of-key-events-day-88?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/israels-war-on-gaza-list-of-key-events-day-88?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T07:49:46+00:00

The bombardment of Gaza and raids on the West Bank have intensified - here is the latest.

## More money, more problems: Debate on Black Tax in African football returns
 - [https://www.aljazeera.com/features/2024/1/2/more-money-more-problems-debate-on-black-tax-in-african-football-returns?traffic_source=rss](https://www.aljazeera.com/features/2024/1/2/more-money-more-problems-debate-on-black-tax-in-african-football-returns?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T07:12:26+00:00

For footballers, &#039;Black Tax&#039; has become endemic but the matter has usually been discussed in hushed tones or privately.

## South Korean opposition leader stabbed in the neck
 - [https://www.aljazeera.com/program/newsfeed/2024/1/2/south-korean-opposition-leader-stabbed-in-the-neck?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/1/2/south-korean-opposition-leader-stabbed-in-the-neck?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T06:58:32+00:00

This is the moment South Korea&#039;s political opposition, Lee Jae-myung, was stabbed in the neck.

## Jimmy Lai pleads not guilty to national security, sedition charges
 - [https://www.aljazeera.com/news/2024/1/2/jimmy-lai-pleads-not-guilty-to-national-security-sedition-charges?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/jimmy-lai-pleads-not-guilty-to-national-security-sedition-charges?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T05:05:51+00:00

Media tycoon is the most prominent individual to face trial under the law imposed by China in 2020.

## Japan lifts tsunami warnings but warns quake damage ‘widespread’
 - [https://www.aljazeera.com/news/2024/1/2/japan-lifts-tsunami-warnings-but-warns-quake-damage-widespread?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/japan-lifts-tsunami-warnings-but-warns-quake-damage-widespread?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T03:42:56+00:00

At least eight people have been confirmed dead since the 7.6 magnitude quake struck the west coast on New Year&#039;s Day.

## South Korean opposition leader stabbed in neck, rushed to hospital
 - [https://www.aljazeera.com/news/2024/1/2/south-korean-opposition-leader-stabbed-in-neck-rushed-to-hospital?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/south-korean-opposition-leader-stabbed-in-neck-rushed-to-hospital?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T01:56:58+00:00

Lee Jae-myung was attacked as he spoke to reporters during a visit to the southeastern port city of Busan

## Russia-Ukraine war: List of key events, day 678
 - [https://www.aljazeera.com/news/2024/1/2/russia-ukraine-war-list-of-key-events-day-678?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/russia-ukraine-war-list-of-key-events-day-678?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T01:28:52+00:00

As the war enters its 678th day, these are the main developments.

## US watching Taiwan elections closely as China reiterates claim to island
 - [https://www.aljazeera.com/news/2024/1/2/us-watching-taiwan-elections-closely-as-beijing-reiterates-claim-to-island?traffic_source=rss](https://www.aljazeera.com/news/2024/1/2/us-watching-taiwan-elections-closely-as-beijing-reiterates-claim-to-island?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-01-02T00:45:06+00:00

Poll outcome will help set the tone for Washington-Beijing relations amid slight easing of tensions.

