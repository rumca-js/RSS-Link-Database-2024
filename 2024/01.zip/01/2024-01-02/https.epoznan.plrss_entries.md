# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Policjanci szukają tych mężczyzn. Rozpoznajesz?
 - [https://epoznan.pl/news-news-146549-policjanci_szukaja_tych_mezczyzn_rozpoznajesz?rss=1](https://epoznan.pl/news-news-146549-policjanci_szukaja_tych_mezczyzn_rozpoznajesz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T21:30:00+00:00

Sprawa dotyczy kradzieży.

## &quot;Obserwujemy coraz więcej fałszywych wydarzeń na Facebooku&quot;. Jest apel organizatorów podniebnych spektakli
 - [https://epoznan.pl/news-news-146548-obserwujemy_coraz_wiecej_falszywych_wydarzen_na_facebooku_jest_apel_organizatorow_podniebnych_spektakli?rss=1](https://epoznan.pl/news-news-146548-obserwujemy_coraz_wiecej_falszywych_wydarzen_na_facebooku_jest_apel_organizatorow_podniebnych_spektakli?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T21:15:00+00:00

Pokazy w Lesznie to wydarzenie, które na stałe wpisało się do kalendarza najciekawszych imprez lotniczych w Polsce i w Europie.

## Budynek przy Drodze Dębińskiej zrównywany jest z ziemią
 - [https://epoznan.pl/news-news-146547-budynek_przy_drodze_debinskiej_zrownywany_jest_z_ziemia?rss=1](https://epoznan.pl/news-news-146547-budynek_przy_drodze_debinskiej_zrownywany_jest_z_ziemia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T21:03:00+00:00

Miejsce przeznaczone jest na nowe inwestycje.

## Po kontroli dyrektor Wojewódzkiej Stacji Pogotowia w Poznaniu stracił stanowisko
 - [https://epoznan.pl/news-news-146546-po_kontroli_dyrektor_wojewodzkiej_stacji_pogotowia_w_poznaniu_stracil_stanowisko?rss=1](https://epoznan.pl/news-news-146546-po_kontroli_dyrektor_wojewodzkiej_stacji_pogotowia_w_poznaniu_stracil_stanowisko?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T20:45:00+00:00



## Zatrzymała samochód i biegła do radiowozu. Policjanci bez wahania włączyli sygnały świetlne i dźwiękowe
 - [https://epoznan.pl/news-news-146545-zatrzymala_samochod_i_biegla_do_radiowozu_policjanci_bez_wahania_wlaczyli_sygnaly_swietlne_i_dzwiekowe?rss=1](https://epoznan.pl/news-news-146545-zatrzymala_samochod_i_biegla_do_radiowozu_policjanci_bez_wahania_wlaczyli_sygnaly_swietlne_i_dzwiekowe?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T20:30:00+00:00

Liczył się czas.

## Rekordowe Betlejem Poznańskie wciąż przyciąga tłumy. Przed nami ostatnia szansa, by się wybrać
 - [https://epoznan.pl/news-news-146544-rekordowe_betlejem_poznanskie_wciaz_przyciaga_tlumy_przed_nami_ostatnia_szansa_by_sie_wybrac?rss=1](https://epoznan.pl/news-news-146544-rekordowe_betlejem_poznanskie_wciaz_przyciaga_tlumy_przed_nami_ostatnia_szansa_by_sie_wybrac?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T20:15:00+00:00

W weekend pojawiło się tu wiele osób.

## 19-latek zakończył podróż na ścianie budynku. Myślał, że go nie znajdą... bo zabrał tablice rejestracyjne
 - [https://epoznan.pl/news-news-146543-19_latek_zakonczyl_podroz_na_scianie_budynku_myslal_ze_go_nie_znajda_bo_zabral_tablice_rejestracyjne?rss=1](https://epoznan.pl/news-news-146543-19_latek_zakonczyl_podroz_na_scianie_budynku_myslal_ze_go_nie_znajda_bo_zabral_tablice_rejestracyjne?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T19:45:00+00:00

Już wiadomo, dlaczego uciekał.

## Tragedia na drodze. Nie żyje kobieta
 - [https://epoznan.pl/news-news-146542-tragedia_na_drodze_nie_zyje_kobieta?rss=1](https://epoznan.pl/news-news-146542-tragedia_na_drodze_nie_zyje_kobieta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T19:15:00+00:00

Do zdarzenia doszło w powiecie wrzesińskim.

## IMGW znów ostrzega!
 - [https://epoznan.pl/news-news-146541-imgw_znow_ostrzega?rss=1](https://epoznan.pl/news-news-146541-imgw_znow_ostrzega?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T19:00:00+00:00

To ostrzeżenie hydrologiczne.

## Niebezpieczna sytuacja - kierowca miał broń. &quot;Padł strzał&quot;
 - [https://epoznan.pl/news-news-146540-niebezpieczna_sytuacja_kierowca_mial_bron_padl_strzal?rss=1](https://epoznan.pl/news-news-146540-niebezpieczna_sytuacja_kierowca_mial_bron_padl_strzal?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T18:30:00+00:00

Nikt nie został poszkodowany.

## Zapowiedzieli awaryjne prace w rejonie Żegrza. Tramwaje zmienią trasy!
 - [https://epoznan.pl/news-news-146539-zapowiedzieli_awaryjne_prace_w_rejonie_zegrza_tramwaje_zmienia_trasy?rss=1](https://epoznan.pl/news-news-146539-zapowiedzieli_awaryjne_prace_w_rejonie_zegrza_tramwaje_zmienia_trasy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T18:00:00+00:00



## Dwóch pijanych kierowców... w jednym samochodzie
 - [https://epoznan.pl/news-news-146538-dwoch_pijanych_kierowcow_w_jednym_samochodzie?rss=1](https://epoznan.pl/news-news-146538-dwoch_pijanych_kierowcow_w_jednym_samochodzie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T17:30:00+00:00

Do nietypowego zdarzenia doszło w Sylwestra.

## Można już składać wnioski o dofinansowanie dla osób z niepełnosprawnością
 - [https://epoznan.pl/news-news-146536-mozna_juz_skladac_wnioski_o_dofinansowanie_dla_osob_z_niepelnosprawnoscia?rss=1](https://epoznan.pl/news-news-146536-mozna_juz_skladac_wnioski_o_dofinansowanie_dla_osob_z_niepelnosprawnoscia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T16:30:00+00:00

Osoby z niepełnosprawnością mogą dostać dofinansowanie pobytu na turnusie rehabilitacyjnym, likwidacji barier technicznych, architektonicznych, zakupu przedmiotów ortopedycznych i środków pomocniczych oraz sprzętu rehabilitacyjnego.

## Nietypowa interwencja. Citroen na dwa dni ugrzązł w kanale
 - [https://epoznan.pl/news-news-146535-nietypowa_interwencja_citroen_na_dwa_dni_ugrzazl_w_kanale?rss=1](https://epoznan.pl/news-news-146535-nietypowa_interwencja_citroen_na_dwa_dni_ugrzazl_w_kanale?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T16:00:00+00:00

Kierowcy nic się nie stało.

## Wstrzymanie ruchu tramwajowego na Królowej Jadwigi. &quot;Z obawy, że ktoś może znajdować się pod tramwajem&quot;
 - [https://epoznan.pl/news-news-146534-wstrzymanie_ruchu_tramwajowego_na_krolowej_jadwigi_z_obawy_ze_ktos_moze_znajdowac_sie_pod_tramwajem?rss=1](https://epoznan.pl/news-news-146534-wstrzymanie_ruchu_tramwajowego_na_krolowej_jadwigi_z_obawy_ze_ktos_moze_znajdowac_sie_pod_tramwajem?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T15:30:00+00:00

Na szczęście nikomu nic się nie stało.

## Policyjna obława na Antoninku. Szukają mężczyzny z tasakiem, który miał dokonać rozboju na 16-latku
 - [https://epoznan.pl/news-news-146533-policyjna_oblawa_na_antoninku_szukaja_mezczyzny_z_tasakiem_ktory_mial_dokonac_rozboju_na_16_latku?rss=1](https://epoznan.pl/news-news-146533-policyjna_oblawa_na_antoninku_szukaja_mezczyzny_z_tasakiem_ktory_mial_dokonac_rozboju_na_16_latku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T15:00:00+00:00

Nastolatkowi nic się nie stało.

## Nie żyje poznański profesor i były sędzia TK. &quot;Odszedł od nas Człowiek ogromnej wiedzy i kultury&quot;
 - [https://epoznan.pl/news-news-146532-nie_zyje_poznanski_profesor_i_byly_sedzia_tk_odszedl_od_nas_czlowiek_ogromnej_wiedzy_i_kultury?rss=1](https://epoznan.pl/news-news-146532-nie_zyje_poznanski_profesor_i_byly_sedzia_tk_odszedl_od_nas_czlowiek_ogromnej_wiedzy_i_kultury?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T14:45:00+00:00

Prof. dr hab. Wojciech Łączkowski miał 90 lat.

## Zapowiedziano utrudnienia na dwóch poznańskich ulicach!
 - [https://epoznan.pl/news-news-146531-zapowiedziano_utrudnienia_na_dwoch_poznanskich_ulicach?rss=1](https://epoznan.pl/news-news-146531-zapowiedziano_utrudnienia_na_dwoch_poznanskich_ulicach?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T14:30:00+00:00

Mowa o Głogowskiej i Hallera.

## Policjanci szukają mężczyzny
 - [https://epoznan.pl/news-news-146529-policjanci_szukaja_mezczyzny?rss=1](https://epoznan.pl/news-news-146529-policjanci_szukaja_mezczyzny?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T13:55:00+00:00

Chodzi o kradzież roweru.

## Są zarzuty dla rodziców 2-miesięcznej dziewczynki z pękniętą czaszką. Bili ją po głowie i nią rzucali, gdy płakała
 - [https://epoznan.pl/news-news-146530-sa_zarzuty_dla_rodzicow_2_miesiecznej_dziewczynki_z_peknieta_czaszka_bili_ja_po_glowie_i_nia_rzucali_gdy_plakala?rss=1](https://epoznan.pl/news-news-146530-sa_zarzuty_dla_rodzicow_2_miesiecznej_dziewczynki_z_peknieta_czaszka_bili_ja_po_glowie_i_nia_rzucali_gdy_plakala?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T13:44:00+00:00

Wracamy do sprawy.

## Zaatakował syna nożem, będzie odpowiadać za usiłowanie zabójstwa
 - [https://epoznan.pl/news-news-146528-zaatakowal_syna_nozem_bedzie_odpowiadac_za_usilowanie_zabojstwa?rss=1](https://epoznan.pl/news-news-146528-zaatakowal_syna_nozem_bedzie_odpowiadac_za_usilowanie_zabojstwa?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T13:35:00+00:00

Do rodzinnej awantury doszło w sobotę w Ostrowie Wielkopolskim.

## Potrącił kobietę autem, pomógł jej wstać i odjechał. Ranna musiała trafić do szpitala. Szuka go policja
 - [https://epoznan.pl/news-news-146527-potracil_kobiete_autem_pomogl_jej_wstac_i_odjechal_ranna_musiala_trafic_do_szpitala_szuka_go_policja?rss=1](https://epoznan.pl/news-news-146527-potracil_kobiete_autem_pomogl_jej_wstac_i_odjechal_ranna_musiala_trafic_do_szpitala_szuka_go_policja?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T13:15:00+00:00

Do zdarzenia doszło w Nowy Rok w godzinach popołudniowych w Ostrowie Wielkopolskim.

## Nawet 5 tysięcy złotych kary dla posiadaczy &quot;kopciuchów&quot;. Właśnie ruszył nabór do miejskiego programu. Można dostać duże dofinansowanie
 - [https://epoznan.pl/news-news-146524-nawet_5_tysiecy_zlotych_kary_dla_posiadaczy_kopciuchow_wlasnie_ruszyl_nabor_do_miejskiego_programu_mozna_dostac_duze_dofinansowanie?rss=1](https://epoznan.pl/news-news-146524-nawet_5_tysiecy_zlotych_kary_dla_posiadaczy_kopciuchow_wlasnie_ruszyl_nabor_do_miejskiego_programu_mozna_dostac_duze_dofinansowanie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T12:50:00+00:00

Wnioski w ramach Kawka Bis można składać od wtorku do końca lipca.

## Psy terroryzują poznańskie osiedle. Dwa czworonogi nie żyją, pogryziona kobieta i obawa, że dojdzie do większej tragedii
 - [https://epoznan.pl/news-news-146526-psy_terroryzuja_poznanskie_osiedle_dwa_czworonogi_nie_zyja_pogryziona_kobieta_i_obawa_ze_dojdzie_do_wiekszej_tragedii?rss=1](https://epoznan.pl/news-news-146526-psy_terroryzuja_poznanskie_osiedle_dwa_czworonogi_nie_zyja_pogryziona_kobieta_i_obawa_ze_dojdzie_do_wiekszej_tragedii?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T12:05:00+00:00

Sprawa dotyczy Głuszyny.

## Rekordowe kontrole nośników reklamowych w Poznaniu w 2023 roku
 - [https://epoznan.pl/news-news-146523-rekordowe_kontrole_nosnikow_reklamowych_w_poznaniu_w_2023_roku?rss=1](https://epoznan.pl/news-news-146523-rekordowe_kontrole_nosnikow_reklamowych_w_poznaniu_w_2023_roku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T11:20:00+00:00

W całym ubiegłym roku było ich 340, a we wcześniejszych latach średnio 130.

## Jedna z największych firm w regionie zwalnia pracowników. Z powodów ekonomicznych
 - [https://epoznan.pl/news-news-146522-jedna_z_najwiekszych_firm_w_regionie_zwalnia_pracownikow_z_powodow_ekonomicznych?rss=1](https://epoznan.pl/news-news-146522-jedna_z_najwiekszych_firm_w_regionie_zwalnia_pracownikow_z_powodow_ekonomicznych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T10:35:00+00:00

Jak podaje wlkp24.info, chodzi o firmę COM40 z Ociąża.

## Poznań ma swoją kartę mieszkańca. Wiemy, ile osób z niej korzysta. Wielkiego zainteresowania nie ma
 - [https://epoznan.pl/news-news-146521-poznan_ma_swoja_karte_mieszkanca_wiemy_ile_osob_z_niej_korzysta_wielkiego_zainteresowania_nie_ma?rss=1](https://epoznan.pl/news-news-146521-poznan_ma_swoja_karte_mieszkanca_wiemy_ile_osob_z_niej_korzysta_wielkiego_zainteresowania_nie_ma?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T09:50:00+00:00

OK Poznań działa od prawie dwóch lat.

## Pijana jechała autem w Sylwestra m.in. po chodniku. Wkrótce za taki wyczyn stracimy auto
 - [https://epoznan.pl/news-news-146518-pijana_jechala_autem_w_sylwestra_min_po_chodniku_wkrotce_za_taki_wyczyn_stracimy_auto?rss=1](https://epoznan.pl/news-news-146518-pijana_jechala_autem_w_sylwestra_min_po_chodniku_wkrotce_za_taki_wyczyn_stracimy_auto?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T09:05:00+00:00

Mieszkanka powiatu leszczyńskiego wcześnie zaczęła świętowanie Nowego Roku i już o 19.00 w Sylwestra została zatrzymana przez policjantów.

## Pijana jechała autem w Sylwestra po chodniku. Wkrótce za taki wyczyn stracimy auto
 - [https://epoznan.pl/news-news-146518-pijana_jechala_autem_w_sylwestra_po_chodniku_wkrotce_za_taki_wyczyn_stracimy_auto?rss=1](https://epoznan.pl/news-news-146518-pijana_jechala_autem_w_sylwestra_po_chodniku_wkrotce_za_taki_wyczyn_stracimy_auto?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T09:05:00+00:00

Mieszkanka powiatu leszczyńskiego wcześnie zaczęła świętowanie Nowego Roku i już o 19.00 w Sylwestra została zatrzymana przez policjantów.

## Poznanianka przeszła wszystkie ulice w Poznaniu! Zajęło jej to dwa lata
 - [https://epoznan.pl/news-news-146516-poznanianka_przeszla_wszystkie_ulice_w_poznaniu_zajelo_jej_to_dwa_lata?rss=1](https://epoznan.pl/news-news-146516-poznanianka_przeszla_wszystkie_ulice_w_poznaniu_zajelo_jej_to_dwa_lata?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T08:25:00+00:00

Swoją misję skończyła tuż po świętach.

## Zmasowany atak Rosji na Ukrainę. Poderwano polskie F-16, także z Krzesin. &quot;Może występować podwyższony poziom hałasu&quot;
 - [https://epoznan.pl/news-news-146520-zmasowany_atak_rosji_na_ukraine_poderwano_polskie_f_16_takze_z_krzesin_moze_wystepowac_podwyzszony_poziom_halasu?rss=1](https://epoznan.pl/news-news-146520-zmasowany_atak_rosji_na_ukraine_poderwano_polskie_f_16_takze_z_krzesin_moze_wystepowac_podwyzszony_poziom_halasu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T07:45:00+00:00

O poderwaniu polskich myśliwców poinformowało Dowództwo Operacyjne Sił Zbrojnych.

## Nocny pożar w bazie PKS. Spłonęły autobusy
 - [https://epoznan.pl/news-news-146519-nocny_pozar_w_bazie_pks_splonely_autobusy?rss=1](https://epoznan.pl/news-news-146519-nocny_pozar_w_bazie_pks_splonely_autobusy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T07:10:00+00:00

Do zdarzenia doszło w Wolsztynie.

## Dwie osoby ranne w noworocznym dachowaniu
 - [https://epoznan.pl/news-news-146517-dwie_osoby_ranne_w_noworocznym_dachowaniu?rss=1](https://epoznan.pl/news-news-146517-dwie_osoby_ranne_w_noworocznym_dachowaniu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-01-02T06:35:00+00:00

Do zdarzenia doszło w powiecie krotoszyńskim.

