# Source:tyler fischer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3Y_HaUqzTYABL2whcwGOKA, language:en

## Celebs make 2024 resolutions (Impressions!)
 - [https://www.youtube.com/watch?v=ugsfreZMkhE](https://www.youtube.com/watch?v=ugsfreZMkhE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3Y_HaUqzTYABL2whcwGOKA
 - date published: 2024-01-02T03:07:20+00:00

See me on tour: https://www.tylerfischer.com
Join my channel to get access to perks like Bonus vids/Early access:
https://www.youtube.com/channel/UC3Y_HaUqzTYABL2whcwGOKA/join
Follow on all socials: @TyTheFisch

