# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## Systemd-Free Distro Nitrux Kicks Off 2024 with New ISO Release
 - [https://9to5linux.com/systemd-free-distro-nitrux-kicks-off-2024-with-new-iso-release](https://9to5linux.com/systemd-free-distro-nitrux-kicks-off-2024-with-new-iso-release)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-01-02T13:19:55+00:00

<p>Nitrux 3.2.1 is available for download powered by Linux kernel 6.6.9 LTS and the KDE Plasma 5.27.10 LTS desktop environment. Here's what's new!</p>
<p>The post <a href="https://9to5linux.com/systemd-free-distro-nitrux-kicks-off-2024-with-new-iso-release">Systemd-Free Distro Nitrux Kicks Off 2024 with New ISO Release</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

