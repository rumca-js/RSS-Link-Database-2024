# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Urzędy Skarbowe zajęły ponad 20 mln zł na kontach niepłacących abonamentu RTV
 - [https://www.wirtualnemedia.pl/artykul/abonament-rtv-wezwanie-dluznicy-pensja-zajecie-sciagniecie-odwolanie-zadluzenie](https://www.wirtualnemedia.pl/artykul/abonament-rtv-wezwanie-dluznicy-pensja-zajecie-sciagniecie-odwolanie-zadluzenie)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-01-02T18:28:18.954260+00:00

Od stycznia do listopada 2023 roku Urzędy Skarbowe w całej Polsce wyegzekwowały 20,03 mln zł nieuregulowanego abonamentu radiowo-telewizyjnego - dowiedział się portal Wirtualnemedia.pl.

## TV Republika zwiększa oglądalność. "Może reklamowo zyskać, ale stanowi niewielką część większych kampanii"
 - [https://www.wirtualnemedia.pl/artykul/tv-republika-reklamy-jak-odbierac-mux-upc-play-vectra-inea-canal-polsat](https://www.wirtualnemedia.pl/artykul/tv-republika-reklamy-jak-odbierac-mux-upc-play-vectra-inea-canal-polsat)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-01-02T18:28:18.953703+00:00

TV Republika, do której przeszli z TVP m.in. Michał Rachoń i Danuta Holecka zyskuje widzów. W ostatnim czasie wyprzedziła Polsat News. Czy stacji uda się zmonetyzować rosnącą oglądalność? - Patrząc na to co się dzieje teraz, wydaje się, że reklamowo ta stacja może zyskać długofalowo, szczególnie, że baza była niewielka, a udziały stacji rynkowe nikłe - uważa Maciej Rzeżuchowski z Media Context.

## Rośnie liczba producentów i powierzchnia upraw ekologicznych
 - [https://www.wirtualnemedia.pl/artykul/rosnie-liczba-producentow-i-powierzchnia-upraw-ekologicznych](https://www.wirtualnemedia.pl/artykul/rosnie-liczba-producentow-i-powierzchnia-upraw-ekologicznych)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-01-02T04:12:36.980120+00:00

Rośnie liczba producentów ekologicznych oraz powierzchni takich upraw w Polsce. Na koniec 2022 r. ekologiczną produkcją zajmowało się ponad 22,8 tys. rolników tj. o 5 proc. więcej niż rok wcześniej - informuje IJHARS. Według szacunków Inspektoratu w 2023 r. liczba producentów ekologicznych może przekroczyć 24 tys.

