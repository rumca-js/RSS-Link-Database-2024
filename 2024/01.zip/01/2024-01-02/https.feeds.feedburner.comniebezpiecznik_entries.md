# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik/, language:pl-PL

## Dane z ALAB znów w darknecie. Uporządkowane numerami PESEL
 - [https://niebezpiecznik.pl/post/dane-z-alab-znow-w-darknecie-uporzadkowane-numerami-pesel](https://niebezpiecznik.pl/post/dane-z-alab-znow-w-darknecie-uporzadkowane-numerami-pesel)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2024-01-02T14:57:31+00:00

<a href="https://niebezpiecznik.pl/post/dane-z-alab-znow-w-darknecie-uporzadkowane-numerami-pesel/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2024/01/pesel-2-150x150.png" width="100" /></a>Pliki z danymi pacjentów, którzy korzystali z usług diagnostycznych ALAB, znów pojawiły się w darknecie. Tym razem zestaw danych ma bardziej dotkliwy charakter bo łatwiej w nim odnaleźć informacje dotyczące konkretnej osoby. Jak dotąd dwukrotnie pisaliśmy o wycieku z firmy z ALAB, prawdopodobnie jednym z najgorszych incydentów tego typu w branży medycznej w ostatnich latach. [&#8230;]

