# Source:Gulf Insider, URL:https://www.gulf-insider.com/feed, language:en-US

## Israel Assassinates Deputy Head Of Hamas In Drone Attack On Beirut Suburb
 - [https://www.gulf-insider.com/israel-assassinates-deputy-head-of-hamas-in-drone-attack-on-beirut-suburb](https://www.gulf-insider.com/israel-assassinates-deputy-head-of-hamas-in-drone-attack-on-beirut-suburb)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T17:25:01+00:00

<p>Hamas has confirmed the death of high-ranking political official Seleh al-Arouri. There&#8217;s been confirmation through various sources, including in Israeli media, yet the IDF has yet to take responsibility for the attack: Hamas’s deputy leader abroad Saleh al-Arouri was killed in an Israeli strike in the Beirut suburb of Dahiyeh, the Hezbollah-linked al-Mayadeen reports. …Based &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/israel-assassinates-deputy-head-of-hamas-in-drone-attack-on-beirut-suburb/">Israel Assassinates Deputy Head Of Hamas In Drone Attack On Beirut Suburb</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi Arabia Launches Campaign to Promote Local Poultry Products Consumption
 - [https://www.gulf-insider.com/saudi-arabia-launches-campaign-to-promote-local-poultry-products-consumption](https://www.gulf-insider.com/saudi-arabia-launches-campaign-to-promote-local-poultry-products-consumption)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T14:36:48+00:00

<p>Saudi Arabia launched a campaign to promote the consumption of local poultry products, a move seen as a reflection of the growing trend around the world to support domestic sectors and products. The new campaign, titled “A Taste of Saudi Arabia”, is part of the national programme for the development of the livestock and fisheries &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-arabia-launches-campaign-to-promote-local-poultry-products-consumption/">Saudi Arabia Launches Campaign to Promote Local Poultry Products Consumption</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Pilot Removed From Duties After Indian Aircraft Makes Hard Landing in Dubai
 - [https://www.gulf-insider.com/pilot-removed-from-duties-after-indian-aircraft-makes-hard-landing-in-dubai](https://www.gulf-insider.com/pilot-removed-from-duties-after-indian-aircraft-makes-hard-landing-in-dubai)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T14:01:28+00:00

<p>An Air India pilot has been derostered after a heavy landing in Dubai, according to Indian media reports. The Times of India says that the flight, which was travelling from Kochi, made the landing on December 20. The aircraft came to a stop safely despite the less-than-smooth landing. An Air India spokesperson reportedly said that &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/pilot-removed-from-duties-after-indian-aircraft-makes-hard-landing-in-dubai/">Pilot Removed From Duties After Indian Aircraft Makes Hard Landing in Dubai</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## January 2023
 - [https://www.gulf-insider.com/january-2023](https://www.gulf-insider.com/january-2023)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T13:53:04+00:00

<p>The post <a href="https://www.gulf-insider.com/january-2023/">January 2023</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Dubai Skies’ First Meteor Shower of 2024 Beckons on January 4
 - [https://www.gulf-insider.com/dubai-skies-first-meteor-shower-of-2024-beckons-on-january-4](https://www.gulf-insider.com/dubai-skies-first-meteor-shower-of-2024-beckons-on-january-4)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T13:39:31+00:00

<p>Dubai residents and visitors can witness the spectacular Quadrantids Meteor Shower on January 4 from a special setting at the Al Qudra&#160;Desert, thanks to the Dubai Astronomy Group. The Quadrantids Meteor Shower, named after the defunct constellation Quadrans Muralis, is an annual treat known for its intense bursts of meteor activity. As the first meteor &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/dubai-skies-first-meteor-shower-of-2024-beckons-on-january-4/">Dubai Skies’ First Meteor Shower of 2024 Beckons on January 4</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi: Riyadh Season Attracts a Whopping 12mn Visitors in the Last 60 Days
 - [https://www.gulf-insider.com/saudi-riyadh-season-attracts-a-whopping-12mn-visitors-in-the-last-60-days](https://www.gulf-insider.com/saudi-riyadh-season-attracts-a-whopping-12mn-visitors-in-the-last-60-days)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T13:25:44+00:00

<p>The ongoing ‘Riyadh Season’, featuring a series of entertainment, fashion, technology and gaming events, attracted a whopping 12 million visitors in the last 60 days, the organizers said. The popular event, which opened in October 2023, targeted 12 million visitor participation during the entire event period, but achieved the target in the middle of the &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-riyadh-season-attracts-a-whopping-12mn-visitors-in-the-last-60-days/">Saudi: Riyadh Season Attracts a Whopping 12mn Visitors in the Last 60 Days</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## UAE Tells Smaller Firms to Hire Emiratis or Face $26,100 Fine
 - [https://www.gulf-insider.com/uae-tells-smaller-firms-to-hire-emiratis-or-face-26100-fine](https://www.gulf-insider.com/uae-tells-smaller-firms-to-hire-emiratis-or-face-26100-fine)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T13:24:47+00:00

<p>UAE introduces new targets for medium-sized firms to hire Emirati talent or face fines. The Ministry of Human Resources and Emiratisation (MoHRE) has started implementing the Cabinet Decision to expand the scope of companies subject to Emiratisation targets, where more than 12,000 companies with 20-49 employees, are required to hire at least one UAE citizen in 2024 and another &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/uae-tells-smaller-firms-to-hire-emiratis-or-face-26100-fine/">UAE Tells Smaller Firms to Hire Emiratis or Face $26,100 Fine</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## “No Stomach” in US to Keep Funding Ukraine as ‘War Is Over’: Ex-pentagon Official
 - [https://www.gulf-insider.com/no-stomach-in-us-to-keep-funding-ukraine-as-war-is-over-ex-pentagon-official](https://www.gulf-insider.com/no-stomach-in-us-to-keep-funding-ukraine-as-war-is-over-ex-pentagon-official)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T13:17:09+00:00

<p>Former Pentagon official Michael Maloof is predicting that Congress and the Pentagon are in for a &#8220;tumultuous&#8221; start of 2024, as the ongoing standoff over Biden&#8217;s billions more in Ukraine defense aid highlights the reality that there&#8217;s &#8220;no stomach&#8221; any longer to fund Ukraine.  The ex-senior security policy analyst in the Office of the Secretary of &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/no-stomach-in-us-to-keep-funding-ukraine-as-war-is-over-ex-pentagon-official/">“No Stomach” in US to Keep Funding Ukraine as ‘War Is Over’: Ex-pentagon Official</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Diamond Prices Are Going To Collapse
 - [https://www.gulf-insider.com/diamond-prices-are-going-to-collapse](https://www.gulf-insider.com/diamond-prices-are-going-to-collapse)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T13:11:42+00:00

<p>What is the modern world’s most powerful and successful industrial cartel? You could say it is pharma today but there are too many competitors in the realm of drug production to qualify as a cartel Until fairly recently, there was one institution that qualified: diamonds as produced and distributed mainly by DeBeers Consolidated Mines in &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/diamond-prices-are-going-to-collapse/">Diamond Prices Are Going To Collapse</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Germany Detains Fifth Suspect in Alleged Plot to Attack Cologne Cathedral Over the Holidays
 - [https://www.gulf-insider.com/germany-detains-fifth-suspect-in-alleged-plot-to-attack-cologne-cathedral-over-the-holidays](https://www.gulf-insider.com/germany-detains-fifth-suspect-in-alleged-plot-to-attack-cologne-cathedral-over-the-holidays)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T13:04:42+00:00

<p>German authorities said Monday they detained another suspect in connection with an alleged threat of an attack on the world-famous Cologne Cathedral over the holidays, bringing the overall number of people detained in connection with the alleged plot to five. The latest suspect, a 41-year-old German-Turkish man, was detained Sunday night in the western city of &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/germany-detains-fifth-suspect-in-alleged-plot-to-attack-cologne-cathedral-over-the-holidays/">Germany Detains Fifth Suspect in Alleged Plot to Attack Cologne Cathedral Over the Holidays</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Britain Prepares to Strike Houthi Following Attacks on Ships
 - [https://www.gulf-insider.com/britain-prepares-to-strike-houthi-following-attacks-on-ships](https://www.gulf-insider.com/britain-prepares-to-strike-houthi-following-attacks-on-ships)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T12:58:23+00:00

<p>British jets are reportedly gearing up to launch a series of air strikes against Iranian-backed Houthi rebels in the wake of recent attacks on shipping in the Red Sea. Britain plans to coordinate with Western allies, including the United States and possibly another European nation, to execute targeted missile strikes. The potential targets include locations &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/britain-prepares-to-strike-houthi-following-attacks-on-ships/">Britain Prepares to Strike Houthi Following Attacks on Ships</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Anti-aging Discovery May Pave the Way to Treatments for Longer Life
 - [https://www.gulf-insider.com/anti-aging-discovery-may-pave-the-way-to-treatments-for-longer-life](https://www.gulf-insider.com/anti-aging-discovery-may-pave-the-way-to-treatments-for-longer-life)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T12:52:52+00:00

<p>Why do we age? It&#8217;s a simple question with a not-so-simple answer. But with the help of modern biotechnology, scientists have been able to slowly piece together the biochemical basis of this long-held mystery. Our cells are like tiny molecular factories, working to carry out all of the essential processes our bodies need to survive. &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/anti-aging-discovery-may-pave-the-way-to-treatments-for-longer-life/">Anti-aging Discovery May Pave the Way to Treatments for Longer Life</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## South Korea Opposition Leader Stabbed in Neck, Attacker Arrested
 - [https://www.gulf-insider.com/south-korea-opposition-leader-stabbed-in-neck-attacker-arrested](https://www.gulf-insider.com/south-korea-opposition-leader-stabbed-in-neck-attacker-arrested)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T12:38:26+00:00

<p>South Korea’s main opposition party leader Lee Jae-myung was attacked by an unidentified assailant during a visit to the southern coastal city of Busan and rushed to a hospital after he was bleeding from his neck. GRAPHIC &#x26a0;&#xfe0f;South Korean opposition leader, Lee Jae-Myung, was stabbed in the neck during a press conference in Busan, South Korea.https://t.co/DukBBKouKg&#8212; Citizen Free Press &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/south-korea-opposition-leader-stabbed-in-neck-attacker-arrested/">South Korea Opposition Leader Stabbed in Neck, Attacker Arrested</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Iran Dispatches Warship to Red Sea, Houthis Warn of “Repercussions” After US Forces Kill Rebels During Maersk Ship Attack
 - [https://www.gulf-insider.com/iran-dispatches-warship-to-red-sea-houthis-warn-of-repercussions-after-us-forces-kill-rebels-during-maersk-ship-attack](https://www.gulf-insider.com/iran-dispatches-warship-to-red-sea-houthis-warn-of-repercussions-after-us-forces-kill-rebels-during-maersk-ship-attack)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T12:30:22+00:00

<p>Regional instability risks mount in the Red Sea following the Iran-backed Houthi attack on a Maersk container ship on Sunday. US Forces responded with attack helicopters that eliminated three small boats and ten rebels. After the skirmish, a spokesperson for the Yemeni militia group warned of &#8220;consequences and repercussions&#8221; for the US aggression.  Houthi military spokesman Yahya Sarea &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/iran-dispatches-warship-to-red-sea-houthis-warn-of-repercussions-after-us-forces-kill-rebels-during-maersk-ship-attack/">Iran Dispatches Warship to Red Sea, Houthis Warn of “Repercussions” After US Forces Kill Rebels During Maersk Ship Attack</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Regular Exercise Is Linked to Larger Brain Volume in Memory and Learning Regions
 - [https://www.gulf-insider.com/regular-exercise-is-linked-to-larger-brain-volume-in-memory-and-learning-regions](https://www.gulf-insider.com/regular-exercise-is-linked-to-larger-brain-volume-in-memory-and-learning-regions)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T12:14:54+00:00

<p>The list of health benefits that come along with regular exercise may have grown with a new study uncovering a link between staying active and the size of parts of the brain responsible for memory and learning capabilities. The exercise doesn&#8217;t have to be overly intense or prolonged to have brain boosting effects, according to the experts behind the &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/regular-exercise-is-linked-to-larger-brain-volume-in-memory-and-learning-regions/">Regular Exercise Is Linked to Larger Brain Volume in Memory and Learning Regions</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Bedlam in Berlin as Immigrants Bring in the New Year
 - [https://www.gulf-insider.com/bedlam-in-berlin-as-immigrants-bring-in-the-new-year](https://www.gulf-insider.com/bedlam-in-berlin-as-immigrants-bring-in-the-new-year)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T11:07:37+00:00

<p>Migrants in Berlin performed their annual act of New Year’s Eve cultural enrichment by setting fire to cars and attacking police and firefighters with projectiles, leading to 15 officers being injured. Major cities in Germany routinely welcome in the new year by witnessing the assembly of thousands of migrants, most of them from the Middle &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/bedlam-in-berlin-as-immigrants-bring-in-the-new-year/">Bedlam in Berlin as Immigrants Bring in the New Year</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Putin Vows Russia “Will Never Back Down” in Year-End Speech
 - [https://www.gulf-insider.com/putin-vows-russia-will-never-back-down-in-year-end-speech](https://www.gulf-insider.com/putin-vows-russia-will-never-back-down-in-year-end-speech)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T10:56:36+00:00

<p>Russian President&#160;Vladimir Putin in his year-end speech, an annual tradition, was widely reported to be somewhat muted in intensity this year (given also it was much shorter than usual, at under four minutes), coming the day after the Russian city of Belgorod suffered its single worst day of attack from Ukraine forces since the war &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/putin-vows-russia-will-never-back-down-in-year-end-speech/">Putin Vows Russia “Will Never Back Down” in Year-End Speech</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## 9 Signs You’re in a Truly Happy Relationship, According to Psychology
 - [https://www.gulf-insider.com/9-signs-youre-in-a-truly-happy-relationship-according-to-psychology](https://www.gulf-insider.com/9-signs-youre-in-a-truly-happy-relationship-according-to-psychology)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T08:39:47+00:00

<p>Happiness is not so easy to define. And this makes it extra challenging to define what a happy relationship is (or isn’t).  Some relationships seem happy, but they actually aren’t. And some SEEM boring and toxic, but are actually, well, happy. No wonder many of us are stuck in unfulfilling relationships or are hopping from one partner &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/9-signs-youre-in-a-truly-happy-relationship-according-to-psychology/">9 Signs You’re in a Truly Happy Relationship, According to Psychology</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Smartphone Manufacturers Still Want To Make Foldables a Thing
 - [https://www.gulf-insider.com/smartphone-manufacturers-still-want-to-make-foldables-a-thing](https://www.gulf-insider.com/smartphone-manufacturers-still-want-to-make-foldables-a-thing)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T08:08:38+00:00

<p>Every large smartphone maker except Apple is betting that “foldable” phones will help revive a lacklustre mobile market, despite the devices still largely failing to attract mainstream consumers. Foldables, which have a screen that opens like a book or compact mirror, barely exceed a 1 percent market share of all smartphones sold globally, almost five &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/smartphone-manufacturers-still-want-to-make-foldables-a-thing/">Smartphone Manufacturers Still Want To Make Foldables a Thing</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Beer Drinking in America Falls to the Lowest Level in a Generation
 - [https://www.gulf-insider.com/beer-drinking-in-america-falls-to-the-lowest-level-in-a-generation](https://www.gulf-insider.com/beer-drinking-in-america-falls-to-the-lowest-level-in-a-generation)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T08:02:19+00:00

<p>It wasn&#8217;t just Bud Light. The past year saw the lowest level of beer consumed in the U.S. in a generation, according to industry group Beer Marketer&#8217;s Insights, as consumers shifted away from traditional favourites to other forms of alcohol—and in a growing number of cases, avoiding alcoholic beverages altogether. &#8220;It was a tough year &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/beer-drinking-in-america-falls-to-the-lowest-level-in-a-generation/">Beer Drinking in America Falls to the Lowest Level in a Generation</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## I Ditched My Android for an iPhone 15 for a Week – And Apple Has Some Work To Do
 - [https://www.gulf-insider.com/i-ditched-my-android-for-an-iphone-15-for-a-week-and-apple-has-some-work-to-do](https://www.gulf-insider.com/i-ditched-my-android-for-an-iphone-15-for-a-week-and-apple-has-some-work-to-do)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T07:56:48+00:00

<p>Although I&#8217;ve tested iPhones for review—most recently with my iPhone 15 Plus review and iPhone 15 Pro review—outside of reviewing, my personal usage predominantly takes place on Android phones and has done so for years. I like the flexibility and customizability of the platform and the ability to address shortcomings or personalise with third-party apps &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/i-ditched-my-android-for-an-iphone-15-for-a-week-and-apple-has-some-work-to-do/">I Ditched My Android for an iPhone 15 for a Week – And Apple Has Some Work To Do</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi Arabia: Customs Foil Smuggling of Huge Cache of Drugs Through Empty Quarter
 - [https://www.gulf-insider.com/saudi-arabia-customs-foil-smuggling-of-huge-cache-of-drugs-through-empty-quarter](https://www.gulf-insider.com/saudi-arabia-customs-foil-smuggling-of-huge-cache-of-drugs-through-empty-quarter)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T06:24:29+00:00

<p>The Zakat, Tax, and Customs Authority at the Empty Quarter (Rub’ al-Khali) border crossing was able to foil an attempt to smuggle 43 kilogrammes of drugs into the Kingdom. The crude form of the drug shabu (methamphetamine) was found hidden in one of the vehicles coming to Saudi Arabia through the port. The authority stated &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-arabia-customs-foil-smuggling-of-huge-cache-of-drugs-through-empty-quarter/">Saudi Arabia: Customs Foil Smuggling of Huge Cache of Drugs Through Empty Quarter</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi Arabia: 141 Ministry Employees Arrested Over Corruption Charges
 - [https://www.gulf-insider.com/saudi-arabia-141-ministry-employees-arrested-over-corruption-charges](https://www.gulf-insider.com/saudi-arabia-141-ministry-employees-arrested-over-corruption-charges)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T06:20:12+00:00

<p>The Saudi Oversight and Anti-Corruption Authority (Nazaha) revealed that a total of 141 ministry employees were arrested over corruption. These employees were working in the Ministry of Interior, Ministry of National Guard, Ministry of Justice, Ministry of Health, Ministry of Education, and Ministry of Municipal and Rural Affairs and Housing. The authority said Monday that &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-arabia-141-ministry-employees-arrested-over-corruption-charges/">Saudi Arabia: 141 Ministry Employees Arrested Over Corruption Charges</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Etihad Announces New Flights to India in 2024
 - [https://www.gulf-insider.com/etihad-announces-new-flights-to-india-in-2024](https://www.gulf-insider.com/etihad-announces-new-flights-to-india-in-2024)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T06:16:51+00:00

<p>Etihad Airways has kicked off 2024 by introducing two new services to India. Daily flights from Abu Dhabi to Kozhikode (CCJ) and Thiruvananthapuram (TRV) in the Kerala region of India commenced on New Year’s Day. These non-stop services to each destination bring the total number of Indian gateways served by Etihad to 10, underscoring the airline’s &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/etihad-announces-new-flights-to-india-in-2024/">Etihad Announces New Flights to India in 2024</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi Arabia Launches Job Skills Tests in Egypt After Success of India, Pakistan and Sri Lanka Schemes
 - [https://www.gulf-insider.com/saudi-arabia-launches-job-skills-tests-in-egypt-after-success-of-india-pakistan-and-sri-lanka-schemes](https://www.gulf-insider.com/saudi-arabia-launches-job-skills-tests-in-egypt-after-success-of-india-pakistan-and-sri-lanka-schemes)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T06:11:20+00:00

<p>Saudi Arabia will test the skills of workers coming from Egypt as it looks to boost the labour force in the Kingdom. The Ministry of Human Resources and Social Development started the first phase of the Professional Verification program in Egypt in cooperation with the Egyptian Ministry of Manpower.  The programme entails twinning the skill-inspection systems in the two &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-arabia-launches-job-skills-tests-in-egypt-after-success-of-india-pakistan-and-sri-lanka-schemes/">Saudi Arabia Launches Job Skills Tests in Egypt After Success of India, Pakistan and Sri Lanka Schemes</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi Tourism Spending Reaches Record $26.7 Billion in Nine Months
 - [https://www.gulf-insider.com/saudi-tourism-spending-reaches-record-26-7-billion-in-nine-months](https://www.gulf-insider.com/saudi-tourism-spending-reaches-record-26-7-billion-in-nine-months)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T06:06:07+00:00

<p>Saudi Arabia saw a record $26.7 billion spent by foreign tourists in the Kingdom in the first nine months of last year, according to government data. The Ministry of Tourism announced the foreign visitors spending record based on data from the Saudi Central Bank (SAMA). Total spending during the first three quarters of 2023 surpassed SR100bn ($26.7bn). By the &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-tourism-spending-reaches-record-26-7-billion-in-nine-months/">Saudi Tourism Spending Reaches Record $26.7 Billion in Nine Months</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Dubai Financial Market Records Over 57,000 New Investors in 2023
 - [https://www.gulf-insider.com/dubai-financial-market-records-over-57000-new-investors-in-2023](https://www.gulf-insider.com/dubai-financial-market-records-over-57000-new-investors-in-2023)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T06:01:51+00:00

<p>Dubai Financial Market saw significant growth in 2023, according to newly published figures. Brokerage firms at the Dubai Financial Market (DFM) opened 57,054 new investor accounts in 2023, marking a significant increase of 12.5 percent over the previous year. The growth was driven by a number of factors, including the strong momentum in the market since the &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/dubai-financial-market-records-over-57000-new-investors-in-2023/">Dubai Financial Market Records Over 57,000 New Investors in 2023</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Qatar Welcomed 4 Million Visitors in 2023, Announces Calendar Including Asian Cup, Doha Expo, F1, Web Summit and More
 - [https://www.gulf-insider.com/qatar-welcomed-4-million-visitors-in-2023-announces-calendar-including-asian-cup-doha-expo-f1-web-summit-and-more](https://www.gulf-insider.com/qatar-welcomed-4-million-visitors-in-2023-announces-calendar-including-asian-cup-doha-expo-f1-web-summit-and-more)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T05:58:49+00:00

<p>Qatar Tourism announced that Qatar received more than 4 million visitors in 2023 and unveiled the 2024 Qatar Calendar. Qatar Tourism launched a full-year calendar for 2024, showcasing more than 80 unique events for the year. From works of art only ever exclusively displayed at New York’s The Met to the world’s largest technology conference, Web &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/qatar-welcomed-4-million-visitors-in-2023-announces-calendar-including-asian-cup-doha-expo-f1-web-summit-and-more/">Qatar Welcomed 4 Million Visitors in 2023, Announces Calendar Including Asian Cup, Doha Expo, F1, Web Summit and More</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Abu Dhabi Breaks Records With New Year 2024 Firework Display
 - [https://www.gulf-insider.com/abu-dhabi-breaks-records-with-new-year-2024-firework-display](https://www.gulf-insider.com/abu-dhabi-breaks-records-with-new-year-2024-firework-display)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-01-02T05:37:05+00:00

<p>Abu Dhabi set four world records with a spectacular firework and drone show to welcome the new year. The&#160;Sheikh Zayed Festival&#160;in Abu Dhabi’s Al Wathba area celebrated New Year 2024 with exceptional shows and features. The shows included a spectacular fireworks display and a 60-minute drone show, along with international performances and programmes. The festival &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/abu-dhabi-breaks-records-with-new-year-2024-firework-display/">Abu Dhabi Breaks Records With New Year 2024 Firework Display</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

