# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## W Szwecji padł rekord. Tak źle nie było od lat 90.
 - [https://www.money.pl/gospodarka/w-szwecji-padl-rekord-tak-zle-nie-bylo-od-lat-90-6980506602396640a.html](https://www.money.pl/gospodarka/w-szwecji-padl-rekord-tak-zle-nie-bylo-od-lat-90-6980506602396640a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T20:17:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/75d2ed21-a495-4f01-bc87-9bf4363bf3ba" width="308" /> Liczba bankructw w Szwecji osiągnęła najwyższy poziom od lat 90. - donosi agencja Bloomberg. Eksperci twierdzą, że w obliczu utrzymującej się wysokiej inflacji mowa jest jedynie o wierzchołku góry lodowej.

## Nawet 8 tys. zł mandatu. Ważna zmiana w nowym roku
 - [https://www.money.pl/ubezpieczenia/nawet-8-tys-zl-mandatu-wazna-zmiana-w-nowym-roku-6980487164508672a.html](https://www.money.pl/ubezpieczenia/nawet-8-tys-zl-mandatu-wazna-zmiana-w-nowym-roku-6980487164508672a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T19:33:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7905a66a-ff22-4250-b98b-d8d248ba9790" width="308" /> Nowy rok przyniósł szereg zmian dla milionów Polaków. Jedna z nich dotyczy podniesienia płacy minimalnej. Wzrost niesie za sobą konsekwencje, a jedną z nich jest wysokość mandatu za brak ubezpieczenia OC, który w 2024 r. będzie rekordowy i sięgnie nawet 8 tys. zł.

## Ponad 6 mln zł na medale. Andrzej Duda szykuje się na odznaczeniowy boom
 - [https://www.money.pl/pieniadze/ponad-6-mln-zl-na-medale-andrzej-duda-szykuje-sie-na-odznaczeniowy-boom-6980484346522592a.html](https://www.money.pl/pieniadze/ponad-6-mln-zl-na-medale-andrzej-duda-szykuje-sie-na-odznaczeniowy-boom-6980484346522592a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T19:09:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/38e975e5-860d-4191-85d0-620d2cead51a" width="308" /> W tym roku Kancelaria Prezydenta RP chce wydać 6,5 mln zł na medale i odznaczenia - wylicza "Fakt". Dużą część tych kosztów mają pochłonąć ordery wręczane małżeństwom z długim stażem.

## Błąd Google pokazał szerszy problem. Minister ujawnia zamiary rządu
 - [https://www.money.pl/pieniadze/blad-google-pokazal-szerszy-problem-minister-ujawnia-zamiary-rzadu-6980407509334528a.html](https://www.money.pl/pieniadze/blad-google-pokazal-szerszy-problem-minister-ujawnia-zamiary-rzadu-6980407509334528a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T17:13:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7144ea41-dae5-4f9a-a833-9b76b4f4074e" width="308" /> Kwestia fake newsów zostanie porządnie uregulowana w taki sposób, żeby na tych, którzy je publikują, ciążyła większa odpowiedzialność - mówi money.pl minister cyfryzacji Krzysztof Gawkowski, w odpowiedzi na pytanie o noworoczne zamieszanie wokół kursów walut na platformie Google.

## Zamieszanie z walutami. Wiadomo, kim jest tajemniczy dostawca Google
 - [https://www.money.pl/pieniadze/zamieszanie-z-walutami-wiadomo-kim-jest-tajemniczy-dostawca-google-6980453693721568a.html](https://www.money.pl/pieniadze/zamieszanie-z-walutami-wiadomo-kim-jest-tajemniczy-dostawca-google-6980453693721568a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T16:37:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a229d741-c8aa-4a30-94d2-75685bdb4cdd" width="308" /> "Ceny na koniec dnia są dostarczane przez Morningstar" - wskazuje Google w informacji dotyczącej zamieszania wokół poniedziałkowych notowań walut na swojej platformie.

## Politycy żerowali na aferze wokół złotego. "Co najmniej pięciu posłów" [OPINIA]
 - [https://www.money.pl/pieniadze/politycy-zerowali-na-aferze-wokol-zlotego-co-najmniej-pieciu-poslow-opinia-6980405676005888a.html](https://www.money.pl/pieniadze/politycy-zerowali-na-aferze-wokol-zlotego-co-najmniej-pieciu-poslow-opinia-6980405676005888a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T14:35:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7432bf95-1ca9-48cc-bed4-cf949f658531" width="308" /> Historia z "błędem Google", wskutek którego niektórzy zaczęli zwiastować już udział Polski w wojnie, pokazuje dwie rzeczy. Tzw. big techy bardzo dużo mogą i za nic nie odpowiadają. Ponadto, w dobie "szybkich" mediów łatwiej o szybką panikę, którą podsycają politycy - pisze dla money.pl dziennikarz WP Patryk Słowik.

## Afera z kursem złotego. Google się tłumaczy
 - [https://www.money.pl/pieniadze/afera-z-kursem-zlotego-google-sie-tlumaczy-6980418413681632a.html](https://www.money.pl/pieniadze/afera-z-kursem-zlotego-google-sie-tlumaczy-6980418413681632a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T14:07:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/db942129-4727-4419-a756-bcf0c391c7fd" width="308" /> Google Polska przekazało redakcji money.pl komunikat, w którym tłumaczy się z zamieszania wokół poniedziałkowych notowań walut na swojej platformie. "Funkcje wyszukiwania, takie jak wyświetlanie kursu wymiany walut, opierają się na danych z zewnętrznych źródeł" - wskazuje spółka.

## Miotła ruszyła. Premier odwołuje dwie osoby z rady nadzorczej BGK
 - [https://www.money.pl/banki/miotla-ruszyla-premier-odwoluje-dwie-osoby-z-rady-nadzorczej-bgk-6980392088128000a.html](https://www.money.pl/banki/miotla-ruszyla-premier-odwoluje-dwie-osoby-z-rady-nadzorczej-bgk-6980392088128000a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T13:06:56+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6a959517-bad1-474a-afb6-c5019d3c4e77" width="308" /> Piotr Kieloch i Joanna Strzesak-Rochewicz nie zasiadają już w radzie nadzorczej Banku Gospodarstwa Krajowego. Decyzję o ich odwołaniu podjął premier Donald Tusk – poinformował BGK w komunikacie.

## Polacy ruszyli po nowe świadczenie z ZUS. "Wszystkie wnioski niekompletne"
 - [https://www.money.pl/pieniadze/polacy-ruszyli-po-nowe-swiadczenie-z-zus-wszystkie-wnioski-niekompletne-6980401247209984a.html](https://www.money.pl/pieniadze/polacy-ruszyli-po-nowe-swiadczenie-z-zus-wszystkie-wnioski-niekompletne-6980401247209984a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T12:52:14+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/86e1e9f0-eb96-42dc-a20e-e56ffdf922ac" width="308" /> Od 1 stycznia można składać wnioski o świadczenie wspierające. Rzecznik ZUS Paweł Zebrowski powiedział, że na 150 wniosków złożonych dotąd do Zakładu Ubezpieczeń Społecznych, wszystkie były niekompletne.

## Te wybory mogą wstrząsnąć gospodarką. Chiny nazywają je "wyborem między pokojem a wojną"
 - [https://www.money.pl/gospodarka/te-wybory-moga-wstrzasnac-gospodarka-chiny-nazywaja-je-wyborem-miedzy-pokojem-a-wojna-6980386745580032a.html](https://www.money.pl/gospodarka/te-wybory-moga-wstrzasnac-gospodarka-chiny-nazywaja-je-wyborem-miedzy-pokojem-a-wojna-6980386745580032a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T12:18:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/720d4d8f-0bfc-45f1-842f-ac1dd830170b" width="308" /> Tajwan w połowie stycznia wybierze swojego prezydenta. Chiny już grożą, że nadchodzące wybory to "wybór między pokojem a wojną". - Jakiekolwiek działania wojenne na Tajwanie doprowadziłyby do kryzysu technologicznego, który prawdopodobnie wpłynąłby na totalną zapaść gospodarczą na całym świecie - piszą w swojej analizie eksperci XTB.

## Zażartował, że ma bombę w bagażu. Nie poleciał na wakacje i dostał mandat
 - [https://www.money.pl/gospodarka/zazartowal-ze-ma-bombe-w-bagazu-nie-polecial-na-wakacje-i-dostal-mandat-6980373579348960a.html](https://www.money.pl/gospodarka/zazartowal-ze-ma-bombe-w-bagazu-nie-polecial-na-wakacje-i-dostal-mandat-6980373579348960a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T11:54:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b901eae8-ba31-4aa1-8e32-da91bf95c0de" width="308" /> 30 grudnia, a więc tuż przed sylwestrem, 36-latek wybierał się na Dominikanę. W trakcie odprawy dla żartu rzucił, że w jego bagażu znajduje się bomba. W efekcie nie poleciał do Puerto Plata i skończył z mandatem. A to i tak łagodny wymiar kary, gdyż prawo za taki "żart" przewiduje nawet więzienie.

## "Zawirowanie" z kursem złotego w Google. Jest reakcja NBP
 - [https://www.money.pl/pieniadze/zawirowanie-z-kursem-zlotego-w-google-jest-reakcja-nbp-6980378738973184a.html](https://www.money.pl/pieniadze/zawirowanie-z-kursem-zlotego-w-google-jest-reakcja-nbp-6980378738973184a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T11:19:57+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7b129501-0153-4084-8e64-9862f9591c62" width="308" /> Narodowy Bank Polski zareagował na nieprawidłowy kurs złotego, jaki w Nowy Rok wyświetlał Google. Pisze o "zawirowaniu dotyczącym fikcyjnego kursu PLN".

## Rośnie napięcie w Afryce. Ogłosili historyczne porozumienie
 - [https://www.money.pl/gospodarka/rosnie-napiecie-w-afryce-oglosili-historyczne-porozumienie-6980356642245120a.html](https://www.money.pl/gospodarka/rosnie-napiecie-w-afryce-oglosili-historyczne-porozumienie-6980356642245120a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T10:36:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/973df997-0d4b-4d8c-85b9-e5c1607b31d2" width="308" /> Somaliland, separatystyczna republika, która odłączyła się od Somalii, ogłosiła porozumienie z Etiopią w sprawie użytkowania portu w Berberze na Morzu Czerwonym. Wywołało to reakcję somalijskiego rządu, który zwołał nadzwyczajne posiedzenie, na którym ma omówić wspomniane porozumienie.

## Kurs złotego w Google "zwariował". Ministerstwo Finansów żąda wyjaśnień
 - [https://www.money.pl/pieniadze/kurs-zlotego-w-google-oszalal-ministerstwo-finansow-bedzie-zadac-wyjasnien-6980368896256512a.html](https://www.money.pl/pieniadze/kurs-zlotego-w-google-oszalal-ministerstwo-finansow-bedzie-zadac-wyjasnien-6980368896256512a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T10:34:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/21d3adf6-0af8-44ff-ae96-011f1d1f2192" width="308" /> Ministerstwo Finansów wzywa amerykański koncern Google do złożenia wyjaśnień w sprawie fałszywego podawania kursów walut - podał resort w serwisie X. Według dziennikarzy w tej sprawie pojawia się&nbsp;kilka hipotez, z atakiem hakerskim włącznie.

## Skończyły się pieniądze w rządowym programie. Przestali przyjmować wnioski
 - [https://www.money.pl/pieniadze/skonczyly-sie-pieniadze-w-rzadowym-programie-przestali-przyjmowac-wnioski-6980357223164896a.html](https://www.money.pl/pieniadze/skonczyly-sie-pieniadze-w-rzadowym-programie-przestali-przyjmowac-wnioski-6980357223164896a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T10:24:43+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bdf598e2-2e8f-4f19-9672-d380a2069666" width="308" /> Od wtorku 2 stycznia 2024 r. banki nie przyjmują&nbsp;już wniosków o udzielenie "Bezpiecznego kredytu 2 proc.". Komunikat w tej sprawie opublikował Bank Gospodarstwa Krajowego.

## Zamieszanie z kursem złotego. Adrian Zandberg uderza w NBP
 - [https://www.money.pl/pieniadze/zamieszanie-z-kursem-zlotego-adrian-zandberg-uderza-w-nbp-6980334316739552a.html](https://www.money.pl/pieniadze/zamieszanie-z-kursem-zlotego-adrian-zandberg-uderza-w-nbp-6980334316739552a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T09:08:59+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6bf6d421-8674-4bd3-9766-8c876dad6335" width="308" /> Nie milkną echa błędu Google'a, który wskazywał nieprawidłowe kursy walut. Szybko zareagował minister finansów i uspokoił, że to "fejk". Milczał (i milczy nadal) natomiast Narodowy Bank Polski. – Zabrakło mi komunikatu NBP, który nie jest mistrzem świata, jeżeli chodzi o komunikację – stwierdził Adrian Zandberg.

## Ani śladu po wieczornym zamieszaniu. Oto prawdziwe kursy walut
 - [https://www.money.pl/pieniadze/ani-sladu-po-wieczornym-zamieszaniu-oto-prawdziwe-kursy-walut-6980337870379520a.html](https://www.money.pl/pieniadze/ani-sladu-po-wieczornym-zamieszaniu-oto-prawdziwe-kursy-walut-6980337870379520a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T08:46:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a18eed6c-f0f3-4d2e-9942-d55eba97a9b2" width="308" /> W poniedziałek wieczorem część serwisów publikujących kursy walut zaliczyła dziwną awarię. Notowania euro, dolara, funta i franka m.in. na stronie Google były wyższe o kilkadziesiąt procent od kursów sprzed weekendu. Jak prezentują się prawdziwe wykresy?

## Polska gospodarka wysyła sygnał. Są nowe dane z przemysłu
 - [https://www.money.pl/gospodarka/polska-gospodarka-wysyla-sygnal-sa-nowe-dane-z-przemyslu-6980328596003328a.html](https://www.money.pl/gospodarka/polska-gospodarka-wysyla-sygnal-sa-nowe-dane-z-przemyslu-6980328596003328a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T08:10:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/001bee66-d11f-472c-8776-1df3ad22f2d9" width="308" /> Wskaźnik PMI dla przemysłu wyniósł w grudniu 47,4 pkt - podała agencja S&amp;P. To wynik gorszy od prognoz. - W grudniu wskaźnik PMI spadł po raz pierwszy od czterech miesięcy, wydłużając obecne osłabienie koniunktury do 20 miesięcy - pisze w komentarzu Trevor Balchin, dyrektor ekonomiczny S&amp;P Global Market Intelligence.

## Rewolucja związana z licznikami prądu. Nie będzie można odmówić
 - [https://www.money.pl/gospodarka/rewolucja-zwiazana-z-licznikami-pradu-nie-bedzie-mozna-odmowic-6980316685077472a.html](https://www.money.pl/gospodarka/rewolucja-zwiazana-z-licznikami-pradu-nie-bedzie-mozna-odmowic-6980316685077472a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T08:07:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0129fec1-671b-4389-920b-4b002caee8b0" width="308" /> Trwa procedura wymiany tradycyjnych liczników prądu na tzw. inteligentne. Firmy dokonują go na podstawie ustawy licznikowej przyjętej jeszcze w 2021 r. Do końca 2030 r. wymienione będzie 17 mln urządzeń. Jest to zmiana, której mieszkający w Polsce nie mogą odmówić ani zablokować.

## Nie licz na wysoki zwrot podatku. Ten z 2023 r. był "incydentalny"
 - [https://www.money.pl/podatki/nie-licz-na-wysoki-zwrot-podatku-ten-z-2023-r-byl-incydentalny-6980305738251232a.html](https://www.money.pl/podatki/nie-licz-na-wysoki-zwrot-podatku-ten-z-2023-r-byl-incydentalny-6980305738251232a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T06:53:58+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4e6cf93a-65a9-4bdf-861e-31dcde126f91" width="308" /> W 2023 r. Polacy otrzymywali rekordowe zwroty podatku dochodowego. W ramach zwrotów za nadpłatę PIT-u Ministerstwo Finansów "oddało" Polakom aż 27 mld zł. Jednak w tym roku nie ma co liczyć na tak duże zwroty. Zeszłoroczne miały związek z korektami reform podatkowych rządu Mateusza Morawieckiego.

## Zmiany dla milionów emerytów. Oto najważniejsza jaką wprowadzi rząd Donalda Tuska
 - [https://www.money.pl/emerytury/zmiany-dla-milionow-emerytow-oto-najwazniejsza-jaka-wprowadzi-rzad-donalda-tuska-6980300087053280a.html](https://www.money.pl/emerytury/zmiany-dla-milionow-emerytow-oto-najwazniejsza-jaka-wprowadzi-rzad-donalda-tuska-6980300087053280a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T06:07:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3ee1edab-1386-4040-b9d4-a089f74b0d89" width="308" /> Nowy rząd przeprowadzi zmiany ważne dla 10 mln emerytów i rencistów. Będzie można sporo zyskać m.in. na podwójnej waloryzacji - pisze Wyborcza.biz .

## Wysokie stopy procentowe odbijają się czkawką NBP. Rosną koszty
 - [https://www.money.pl/pieniadze/wysokie-stopy-procentowe-odbijaja-sie-czkawka-nbp-rosna-koszty-6980295077432288a.html](https://www.money.pl/pieniadze/wysokie-stopy-procentowe-odbijaja-sie-czkawka-nbp-rosna-koszty-6980295077432288a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T06:05:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2fb276a6-f43c-40ed-8021-ffecea4c70b4" width="308" /> Narodowy Bank Polski odnotował w 2023 r. potężną stratę rzędu kilkudziesięciu mld zł. Przyczynił się do tego wzmacniający się na rynkach złoty, ale nie tylko. Wpływ na to miały też wysokie koszty operacji otwartego rynku – pisze we wtorek "Dziennik Gazeta Prawna".

## Kursy walut 2.01.2024. Wtorkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-2-01-2024-wtorkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6980295635651072a.html](https://www.money.pl/pieniadze/kursy-walut-2-01-2024-wtorkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6980295635651072a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-01-02T05:41:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b72a8fd5-fadc-4cba-b377-82b6949d33ce" width="308" /> Kursy walut - 2.01.2024. We wtorek za jednego dolara (USD) zapłacimy 3,9166 zł. Cena jednego funta szterlinga (GBP) to 5,0000 zł, a franka szwajcarskiego (CHF) 4,6482 zł. Z kolei euro (EUR) możemy zakupić za 4,3354 zł.

