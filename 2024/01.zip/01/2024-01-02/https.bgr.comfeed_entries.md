# Source:BGR, URL:https://bgr.com/feed, language:en-US

## First meteor shower of the year will peak this week
 - [https://bgr.com/science/first-meteor-shower-of-the-year-will-peak-this-week](https://bgr.com/science/first-meteor-shower-of-the-year-will-peak-this-week)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T23:53:00+00:00

<p>Stargazers will have quite a treat to look forward to this month as the first meteor shower of 2024, the Quadrantids, will peak on Thursday, &#8230;</p>
<p>The post <a href="https://bgr.com/science/first-meteor-shower-of-the-year-will-peak-this-week/">First meteor shower of the year will peak this week</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Galaxy S24 Unpacked event takes place on January 17: Here are all the details
 - [https://bgr.com/tech/galaxy-s24-unpacked-event-takes-place-on-january-17-here-are-all-the-details](https://bgr.com/tech/galaxy-s24-unpacked-event-takes-place-on-january-17-here-are-all-the-details)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T23:00:00+00:00

<p>Rumors claimed Samsung would unveil the Galaxy S24 on January 17th at a US-based press conference, and it looks like they were correct. Samsung isn&#8217;t &#8230;</p>
<p>The post <a href="https://bgr.com/tech/galaxy-s24-unpacked-event-takes-place-on-january-17-here-are-all-the-details/">Galaxy S24 Unpacked event takes place on January 17: Here are all the details</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## My favorite quotes from Lost, in honor of the beloved ABC series returning to Netflix
 - [https://bgr.com/entertainment/my-favorite-quotes-from-lost-in-honor-of-the-beloved-abc-series-returning-to-netflix](https://bgr.com/entertainment/my-favorite-quotes-from-lost-in-honor-of-the-beloved-abc-series-returning-to-netflix)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T22:15:00+00:00

<p>All six seasons of Lost are coming to Netflix in just a few months&#8217; time, thanks to an agreement reached between Disney and Netflix back &#8230;</p>
<p>The post <a href="https://bgr.com/entertainment/my-favorite-quotes-from-lost-in-honor-of-the-beloved-abc-series-returning-to-netflix/">My favorite quotes from Lost, in honor of the beloved ABC series returning to Netflix</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Barely any EVs qualify for the $7,500 tax credit now – here’s the full list
 - [https://bgr.com/lifestyle/barely-any-evs-qualify-for-the-7500-tax-credit-now-heres-the-full-list](https://bgr.com/lifestyle/barely-any-evs-qualify-for-the-7500-tax-credit-now-heres-the-full-list)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T21:30:00+00:00

<p>Happy New Year! And with a new year now upon us, say goodbye to a ton of vehicles that had qualified for the $7,500 federal &#8230;</p>
<p>The post <a href="https://bgr.com/lifestyle/barely-any-evs-qualify-for-the-7500-tax-credit-now-heres-the-full-list/">Barely any EVs qualify for the $7,500 tax credit now &#8211; here&#8217;s the full list</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## How to watch the last total solar eclipse in the US until 2045
 - [https://bgr.com/science/heres-when-you-can-see-the-last-total-solar-eclipse-in-the-us-until-2045](https://bgr.com/science/heres-when-you-can-see-the-last-total-solar-eclipse-in-the-us-until-2045)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T21:07:11+00:00

<p>The last total solar eclipse in the US until 2045 will happen this year. Set to fill the sky across portions of the country in &#8230;</p>
<p>The post <a href="https://bgr.com/science/heres-when-you-can-see-the-last-total-solar-eclipse-in-the-us-until-2045/">How to watch the last total solar eclipse in the US until 2045</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Booking, Expedia, or Priceline: Where to get the cheapest hotel rates
 - [https://bgr.com/lifestyle/booking-expedia-or-priceline-where-to-get-the-cheapest-hotel-rates](https://bgr.com/lifestyle/booking-expedia-or-priceline-where-to-get-the-cheapest-hotel-rates)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T20:14:00+00:00

<p>One of your New Year&#8217;s resolutions might be to travel more in 2024, which will involve booking more hotel stays. If you are trying to &#8230;</p>
<p>The post <a href="https://bgr.com/lifestyle/booking-expedia-or-priceline-where-to-get-the-cheapest-hotel-rates/">Booking, Expedia, or Priceline: Where to get the cheapest hotel rates</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Avengers 5 team might have leaked, and it’s full of surprises
 - [https://bgr.com/entertainment/avengers-5-team-might-have-leaked-and-its-full-of-surprises](https://bgr.com/entertainment/avengers-5-team-might-have-leaked-and-its-full-of-surprises)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T19:21:00+00:00

<p>It&#8217;s time to forget all about 2023&#8217;s mediocre MCU releases and look forward to what&#8217;s coming soon. On that note, Echo is about to premiere &#8230;</p>
<p>The post <a href="https://bgr.com/entertainment/avengers-5-team-might-have-leaked-and-its-full-of-surprises/">Avengers 5 team might have leaked, and it&#8217;s full of surprises</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Slow Horses on Apple TV+, one of the best spy series of all time, just got renewed for Season 5
 - [https://bgr.com/entertainment/slow-horses-on-apple-tv-one-of-the-best-spy-series-of-all-time-just-got-renewed-for-season-5](https://bgr.com/entertainment/slow-horses-on-apple-tv-one-of-the-best-spy-series-of-all-time-just-got-renewed-for-season-5)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T18:28:00+00:00

<p>Slow Horses, one of the best and now longest-running dramas on Apple TV+, is coming back for a fifth season. Apple announced the news on &#8230;</p>
<p>The post <a href="https://bgr.com/entertainment/slow-horses-on-apple-tv-one-of-the-best-spy-series-of-all-time-just-got-renewed-for-season-5/">Slow Horses on Apple TV+, one of the best spy series of all time, just got renewed for Season 5</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Tesla broke another record, delivering over 1.8 million vehicles in 2023
 - [https://bgr.com/business/tesla-broke-another-record-delivering-over-1-8-million-vehicles-in-2023](https://bgr.com/business/tesla-broke-another-record-delivering-over-1-8-million-vehicles-in-2023)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T16:52:23+00:00

<p>Tesla has released its production and delivery results for both the fourth quarter and the total for 2023, and the company has broken yet another &#8230;</p>
<p>The post <a href="https://bgr.com/business/tesla-broke-another-record-delivering-over-1-8-million-vehicles-in-2023/">Tesla broke another record, delivering over 1.8 million vehicles in 2023</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Apple’s USB-C AirPods Pro 2 drop to $189.99 for the first time since Black Friday
 - [https://bgr.com/deals/usb-c-airpods-pro-2-sale](https://bgr.com/deals/usb-c-airpods-pro-2-sale)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T16:15:00+00:00

<p>Apple&#8217;s iPhone 15 series was the biggest launch of the fall last year. Of course, new iPhones aren&#8217;t the only gadgets Apple showed off during &#8230;</p>
<p>The post <a href="https://bgr.com/deals/usb-c-airpods-pro-2-sale/">Apple&#8217;s USB-C AirPods Pro 2 drop to $189.99 for the first time since Black Friday</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Apple might be forced to allow iPhone sideloading in the US
 - [https://bgr.com/tech/apple-might-be-forced-to-allow-iphone-sideloading-in-the-us](https://bgr.com/tech/apple-might-be-forced-to-allow-iphone-sideloading-in-the-us)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T15:22:00+00:00

<p>I recently managed to anger both the iPhone users who are in favor of sideloading and the ones who aren&#8217;t. I explained several times that &#8230;</p>
<p>The post <a href="https://bgr.com/tech/apple-might-be-forced-to-allow-iphone-sideloading-in-the-us/">Apple might be forced to allow iPhone sideloading in the US</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Today’s deals: $3.50 Alexa smart plugs, Fitbit smartwatches, HP laptops, home gym equipment, more
 - [https://bgr.com/deals/todays-deals-3-50-alexa-smart-plugs-fitbit-smartwatches-hp-laptops-home-gym-equipment-more](https://bgr.com/deals/todays-deals-3-50-alexa-smart-plugs-fitbit-smartwatches-hp-laptops-home-gym-equipment-more)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T14:29:00+00:00

<p>New year, new you, new deals! 2024 is finally here, and it brought so many great deals on popular products with it. Our readers&#8217; favorite &#8230;</p>
<p>The post <a href="https://bgr.com/deals/todays-deals-3-50-alexa-smart-plugs-fitbit-smartwatches-hp-laptops-home-gym-equipment-more/">Today&#8217;s deals: $3.50 Alexa smart plugs, Fitbit smartwatches, HP laptops, home gym equipment, more</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## PSA: WhatsApp backups won’t be free anymore on Android
 - [https://bgr.com/tech/psa-whatsapp-backups-wont-be-free-anymore-on-android](https://bgr.com/tech/psa-whatsapp-backups-wont-be-free-anymore-on-android)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T13:36:00+00:00

<p>Most people are still recovering after their New Year&#8217;s celebrations, but there is one piece of tech news you shouldn&#8217;t ignore in early 2024. If &#8230;</p>
<p>The post <a href="https://bgr.com/tech/psa-whatsapp-backups-wont-be-free-anymore-on-android/">PSA: WhatsApp backups won&#8217;t be free anymore on Android</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

## Galaxy S24 preorder deals might have leaked, and I’d start planning if I were you
 - [https://bgr.com/tech/galaxy-s24-preorder-perks-might-have-leaked-and-id-start-planning-if-i-were-you](https://bgr.com/tech/galaxy-s24-preorder-perks-might-have-leaked-and-id-start-planning-if-i-were-you)
 - RSS feed: https://bgr.com/feed
 - date published: 2024-01-02T11:50:00+00:00

<p>Even without the rumored generative AI features coming to the Galaxy S24 series, there&#8217;s no doubt that Samsung&#8217;s 2024 flagship will be one of the &#8230;</p>
<p>The post <a href="https://bgr.com/tech/galaxy-s24-preorder-perks-might-have-leaked-and-id-start-planning-if-i-were-you/">Galaxy S24 preorder deals might have leaked, and I&#8217;d start planning if I were you</a> appeared first on <a href="https://bgr.com">BGR</a>.</p>

