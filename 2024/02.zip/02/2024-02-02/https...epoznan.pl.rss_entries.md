# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Z pubu zniknęła kurtka z 1000 zł w kieszeni. Policja szuka sprawcy
 - [https://epoznan.pl/news-news-147531-z_pubu_zniknela_kurtka_z_1000_zl_w_kieszeni_policja_szuka_sprawcy?rss=1](https://epoznan.pl/news-news-147531-z_pubu_zniknela_kurtka_z_1000_zl_w_kieszeni_policja_szuka_sprawcy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T21:30:00+00:00

Rozpoznajesz osobę ze zdjęć?

## Episkopat zabrał głos w sprawie pigułki &quot;dzień po&quot;: &quot;to niemoralne&quot;
 - [https://epoznan.pl/news-news-147532-episkopat_zabral_glos_w_sprawie_pigulki_dzien_po_to_niemoralne?rss=1](https://epoznan.pl/news-news-147532-episkopat_zabral_glos_w_sprawie_pigulki_dzien_po_to_niemoralne?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T21:00:00+00:00

Rząd Donalda Tuska zapowiedział, że pigułka wkrótce będzie dostępna bez recepty.

## W Poznaniu odkryto jedną z najstarszych w Polsce kuchni królewskich!
 - [https://epoznan.pl/news-news-147530-w_poznaniu_odkryto_jedna_z_najstarszych_w_polsce_kuchni_krolewskich?rss=1](https://epoznan.pl/news-news-147530-w_poznaniu_odkryto_jedna_z_najstarszych_w_polsce_kuchni_krolewskich?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T20:30:00+00:00

Spektakularne odkrycie w trakcie prac archeologicznych.

## Centralny Zintegrowany Szpital Kliniczny coraz bliżej! Poznań wkrótce zyska nowy Szpitalny Oddział Ratunkowy
 - [https://epoznan.pl/news-news-147529-centralny_zintegrowany_szpital_kliniczny_coraz_blizej_poznan_wkrotce_zyska_nowy_szpitalny_oddzial_ratunkowy?rss=1](https://epoznan.pl/news-news-147529-centralny_zintegrowany_szpital_kliniczny_coraz_blizej_poznan_wkrotce_zyska_nowy_szpitalny_oddzial_ratunkowy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T20:00:00+00:00

Wiosną ma się rozpocząć wielka przeprowadzka.

## Odcinkowy pomiar prędkości na A2 w Poznaniu działa. I jest pierwszy efekt!
 - [https://epoznan.pl/news-news-147535-odcinkowy_pomiar_predkosci_na_a2_w_poznaniu_dziala_i_jest_pierwszy_efekt?rss=1](https://epoznan.pl/news-news-147535-odcinkowy_pomiar_predkosci_na_a2_w_poznaniu_dziala_i_jest_pierwszy_efekt?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T19:45:00+00:00

Kierowcy zwolnili.

## Pies z oskalpowaną łapą trafił do schroniska. Prawdopodobnie wpadł we wnyki
 - [https://epoznan.pl/news-news-147528-pies_z_oskalpowana_lapa_trafil_do_schroniska_prawdopodobnie_wpadl_we_wnyki?rss=1](https://epoznan.pl/news-news-147528-pies_z_oskalpowana_lapa_trafil_do_schroniska_prawdopodobnie_wpadl_we_wnyki?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T19:30:00+00:00

Psa znaleziono w niewielkiej miejscowości na terenie powiatu ostrowskiego.

## Kiedy tramwaj dojedzie do stacji Poznań Wschód?
 - [https://epoznan.pl/news-news-147534-kiedy_tramwaj_dojedzie_do_stacji_poznan_wschod?rss=1](https://epoznan.pl/news-news-147534-kiedy_tramwaj_dojedzie_do_stacji_poznan_wschod?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T19:10:00+00:00

Interpelację w tej sprawie przygotował radny Andrzej Rataj.

## Senior zgubił się w lesie, wpadł do rowu i pokaleczył twarz. Odnaleźli go policjanci
 - [https://epoznan.pl/news-news-147527-senior_zgubil_sie_w_lesie_wpadl_do_rowu_i_pokaleczyl_twarz_odnalezli_go_policjanci?rss=1](https://epoznan.pl/news-news-147527-senior_zgubil_sie_w_lesie_wpadl_do_rowu_i_pokaleczyl_twarz_odnalezli_go_policjanci?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T18:50:00+00:00

Do niebezpiecznej sytuacji doszło w Lesznie.

## Od poniedziałku utrudnienia komunikacyjne w centrum. Powstaną przejazdy rowerowe
 - [https://epoznan.pl/news-news-147533-od_poniedzialku_utrudnienia_komunikacyjne_w_centrum_powstana_przejazdy_rowerowe?rss=1](https://epoznan.pl/news-news-147533-od_poniedzialku_utrudnienia_komunikacyjne_w_centrum_powstana_przejazdy_rowerowe?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T18:30:00+00:00

W rejonie Młyńskiej.

## Wiemy, kiedy zamkną stację benzynową na Jeżycach. W jej miejscu ma powstać zieleniec i miejsce rekreacji
 - [https://epoznan.pl/news-news-147526-wiemy_kiedy_zamkna_stacje_benzynowa_na_jezycach_w_jej_miejscu_ma_powstac_zieleniec_i_miejsce_rekreacji?rss=1](https://epoznan.pl/news-news-147526-wiemy_kiedy_zamkna_stacje_benzynowa_na_jezycach_w_jej_miejscu_ma_powstac_zieleniec_i_miejsce_rekreacji?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T18:10:00+00:00

Chodzi o stację Orlen przy ulicy Kościelnej.

## Pracownik placówki znanego banku w regionie na celowniku prokuratury. Jest podejrzewany o oszukanie klientów na setki tysięcy złotych
 - [https://epoznan.pl/news-news-147525-pracownik_placowki_znanego_banku_w_regionie_na_celowniku_prokuratury_jest_podejrzewany_o_oszukanie_klientow_na_setki_tysiecy_zlotych?rss=1](https://epoznan.pl/news-news-147525-pracownik_placowki_znanego_banku_w_regionie_na_celowniku_prokuratury_jest_podejrzewany_o_oszukanie_klientow_na_setki_tysiecy_zlotych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T17:30:00+00:00

Sytuacja miała miejsce w Grodzisku Wielkopolskim.

## Odwołano prezesa poznańskiego giganta. Nowy ma być wybrany w konkursie
 - [https://epoznan.pl/news-news-147524-odwolano_prezesa_poznanskiego_giganta_nowy_ma_byc_wybrany_w_konkursie?rss=1](https://epoznan.pl/news-news-147524-odwolano_prezesa_poznanskiego_giganta_nowy_ma_byc_wybrany_w_konkursie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T16:30:00+00:00

Zmiany w Enei.

## Złota Pieczęć Poznania dla wybitnego przedsiębiorcy i filantropa
 - [https://epoznan.pl/news-news-147523-zlota_pieczec_poznania_dla_wybitnego_przedsiebiorcy_i_filantropa?rss=1](https://epoznan.pl/news-news-147523-zlota_pieczec_poznania_dla_wybitnego_przedsiebiorcy_i_filantropa?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T15:50:00+00:00

W tym roku wyróżnienie trafiło do Wojciecha Pawłowskiego.

## 48-latka handlowała podrabianymi ubraniami w mediach społecznościowych. W mieszkaniu znaleziono towar &quot;warty&quot; milion złotych
 - [https://epoznan.pl/news-news-147522-48_latka_handlowala_podrabianymi_ubraniami_w_mediach_spolecznosciowych_w_mieszkaniu_znaleziono_towar_warty_milion_zlotych?rss=1](https://epoznan.pl/news-news-147522-48_latka_handlowala_podrabianymi_ubraniami_w_mediach_spolecznosciowych_w_mieszkaniu_znaleziono_towar_warty_milion_zlotych?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T15:10:00+00:00

Kobieta handlowała podróbkami od dwóch lat.

## Jest wyrok w sprawie policjanta, który śmiertelnie postrzelił 21-latka w Koninie
 - [https://epoznan.pl/news-news-147521-jest_wyrok_w_sprawie_policjanta_ktory_smiertelnie_postrzelil_21_latka_w_koninie?rss=1](https://epoznan.pl/news-news-147521-jest_wyrok_w_sprawie_policjanta_ktory_smiertelnie_postrzelil_21_latka_w_koninie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T14:30:00+00:00

Funkcjonariusz został skazany na więzienie.

## Jest wyrok w sprawie policjanta, który śmiertelnie postrzelił 21-latka w Koninie. Ma trafić za kraty
 - [https://epoznan.pl/news-news-147521-jest_wyrok_w_sprawie_policjanta_ktory_smiertelnie_postrzelil_21_latka_w_koninie_ma_trafic_za_kraty?rss=1](https://epoznan.pl/news-news-147521-jest_wyrok_w_sprawie_policjanta_ktory_smiertelnie_postrzelil_21_latka_w_koninie_ma_trafic_za_kraty?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T14:30:00+00:00



## Złożyli zawiadomienie obywatelskie o nieprawidłowościach podczas działań rozbiórkowych przy dachu Synagogi na Starym Mieście
 - [https://epoznan.pl/news-news-147520-zlozyli_zawiadomienie_obywatelskie_o_nieprawidlowosciach_podczas_dzialan_rozbiorkowych_przy_dachu_synagogi_na_starym_miescie?rss=1](https://epoznan.pl/news-news-147520-zlozyli_zawiadomienie_obywatelskie_o_nieprawidlowosciach_podczas_dzialan_rozbiorkowych_przy_dachu_synagogi_na_starym_miescie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T13:30:00+00:00

Stowarzyszenie &quot;Łazęga&quot; złożyło w piątek oficjalne pismo w urzędzie Powiatowego Inspektoratu Nadzoru Budowlanego.

## PKS Poznań odwołuje kursy i przeprasza pasażerów
 - [https://epoznan.pl/news-news-147518-pks_poznan_odwoluje_kursy_i_przeprasza_pasazerow?rss=1](https://epoznan.pl/news-news-147518-pks_poznan_odwoluje_kursy_i_przeprasza_pasazerow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T13:00:00+00:00

Opublikowano listę odwołanych kursów.

## Plaga włamań do mieszkań na Winogradach. Rada osiedla wydała ważny komunikat w tej sprawie
 - [https://epoznan.pl/news-news-147517-plaga_wlaman_do_mieszkan_na_winogradach_rada_osiedla_wydala_wazny_komunikat_w_tej_sprawie?rss=1](https://epoznan.pl/news-news-147517-plaga_wlaman_do_mieszkan_na_winogradach_rada_osiedla_wydala_wazny_komunikat_w_tej_sprawie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T12:53:00+00:00

W tej okolicy coraz częściej dochodzi do włamań i niebezpiecznych sytuacji.

## Mieszkańcy Poznania mogą znowu korzystać z gratowiska na Dębcu. Można oddać przedmioty, które posłużą innym
 - [https://epoznan.pl/news-news-147516-mieszkancy_poznania_moga_znowu_korzystac_z_gratowiska_na_debcu_mozna_oddac_przedmioty_ktore_posluza_innym?rss=1](https://epoznan.pl/news-news-147516-mieszkancy_poznania_moga_znowu_korzystac_z_gratowiska_na_debcu_mozna_oddac_przedmioty_ktore_posluza_innym?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T12:22:00+00:00

Pojawiły się wiaty nad kontenerami.

## &quot;Po-Dzielnia&quot; zaapelowała do ludzi, żeby nie zostawiali ubrań i innych przedmiotów pod drzwiami, gdy akurat nie urzędują
 - [https://epoznan.pl/news-news-147515-po_dzielnia_zaapelowala_do_ludzi_zeby_nie_zostawiali_ubran_i_innych_przedmiotow_pod_drzwiami_gdy_akurat_nie_urzeduja?rss=1](https://epoznan.pl/news-news-147515-po_dzielnia_zaapelowala_do_ludzi_zeby_nie_zostawiali_ubran_i_innych_przedmiotow_pod_drzwiami_gdy_akurat_nie_urzeduja?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T11:59:00+00:00

Ten widok zaskoczył ich w piątek od rana.

## Rektorka UAM prof. Bogumiła Kaniewska weszła w skład Zespołu Ekspertów do spraw Krajowej Strategii Umiędzynarodowienia
 - [https://epoznan.pl/news-news-147514-rektorka_uam_prof_bogumila_kaniewska_weszla_w_sklad_zespolu_ekspertow_do_spraw_krajowej_strategii_umiedzynarodowienia?rss=1](https://epoznan.pl/news-news-147514-rektorka_uam_prof_bogumila_kaniewska_weszla_w_sklad_zespolu_ekspertow_do_spraw_krajowej_strategii_umiedzynarodowienia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T11:41:00+00:00

Zespół będzie głosem doradczym w zakresie tworzenia Krajowej Strategii Umiędzynarodowienia.

## Od piątku działa już odcinkowy pomiar prędkości na A2 w Poznaniu. Internet huczy od ostrzeżeń, które wysyłają sobie kierowcy
 - [https://epoznan.pl/news-news-147513-od_piatku_dziala_juz_odcinkowy_pomiar_predkosci_na_a2_w_poznaniu_internet_huczy_od_ostrzezen_ktore_wysylaja_sobie_kierowcy?rss=1](https://epoznan.pl/news-news-147513-od_piatku_dziala_juz_odcinkowy_pomiar_predkosci_na_a2_w_poznaniu_internet_huczy_od_ostrzezen_ktore_wysylaja_sobie_kierowcy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T09:45:00+00:00

Wracamy do tematu uruchomienia urządzenia do pomiaru prędkości.

## W sobotę znowu część mieszkańców Poznania będzie od rana bez prądu. Enea planuje wyłączenia
 - [https://epoznan.pl/news-news-147511-w_sobote_znowu_czesc_mieszkancow_poznania_bedzie_od_rana_bez_pradu_enea_planuje_wylaczenia?rss=1](https://epoznan.pl/news-news-147511-w_sobote_znowu_czesc_mieszkancow_poznania_bedzie_od_rana_bez_pradu_enea_planuje_wylaczenia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T09:20:00+00:00

Dotyczy obszaru Poznań Stare Miasto.

## CBA wkroczyło do urzędu powiatowego w Poznaniu, zatrzymali pracownika. Miał przyjmować łapówki od biznesmenów
 - [https://epoznan.pl/news-news-147510-cba_wkroczylo_do_urzedu_powiatowego_w_poznaniu_zatrzymali_pracownika_mial_przyjmowac_lapowki_od_biznesmenow?rss=1](https://epoznan.pl/news-news-147510-cba_wkroczylo_do_urzedu_powiatowego_w_poznaniu_zatrzymali_pracownika_mial_przyjmowac_lapowki_od_biznesmenow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T09:10:00+00:00

Chodzi o Powiatowy Ośrodek Dokumentacji Geodezyjnej i Kartograficznej.

## CBA wkroczyło do urzędu w Poznaniu, zatrzymali pracownika. Miał przyjmować łapówki od biznesmenów
 - [https://epoznan.pl/news-news-147510-cba_wkroczylo_do_urzedu_w_poznaniu_zatrzymali_pracownika_mial_przyjmowac_lapowki_od_biznesmenow?rss=1](https://epoznan.pl/news-news-147510-cba_wkroczylo_do_urzedu_w_poznaniu_zatrzymali_pracownika_mial_przyjmowac_lapowki_od_biznesmenow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T09:10:00+00:00

Chodzi o Ośrodek Dokumentacji Geodezyjnej i Kartograficznej.

## Ruszyły zapisy na poznański maraton. Zobacz ile trzeba zapłacić
 - [https://epoznan.pl/news-news-147509-ruszyly_zapisy_na_poznanski_maraton_zobacz_ile_trzeba_zaplacic?rss=1](https://epoznan.pl/news-news-147509-ruszyly_zapisy_na_poznanski_maraton_zobacz_ile_trzeba_zaplacic?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T08:30:00+00:00

Od środy można zapisywać się przez formularz na 23. Poznań Maraton.

## Sąd chce chronić przed stresem księdza oskarżonego o pedofilię i utajnia proces
 - [https://epoznan.pl/news-news-147508-sad_chce_chronic_przed_stresem_ksiedza_oskarzonego_o_pedofilie_i_utajnia_proces?rss=1](https://epoznan.pl/news-news-147508-sad_chce_chronic_przed_stresem_ksiedza_oskarzonego_o_pedofilie_i_utajnia_proces?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T08:02:00+00:00

W środę ruszył w sądzie we Wrześni proces 40-letniego duchownego.

## Miejski Ośrodek Pomocy Rodzinie szuka pracownika. Zobacz, jakie wymogi trzeba spełniać i do kiedy można składać oferty
 - [https://epoznan.pl/news-news-147507-miejski_osrodek_pomocy_rodzinie_szuka_pracownika_zobacz_jakie_wymogi_trzeba_spelniac_i_do_kiedy_mozna_skladac_oferty?rss=1](https://epoznan.pl/news-news-147507-miejski_osrodek_pomocy_rodzinie_szuka_pracownika_zobacz_jakie_wymogi_trzeba_spelniac_i_do_kiedy_mozna_skladac_oferty?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T07:46:00+00:00

Chodzi o osobę na stanowisku do spraw planowania i realizacji budżetu.

## Wyjątkowo łagodny luty. Optymistyczna prognoza pogody na weekend. Powieje jedynie wiatr
 - [https://epoznan.pl/news-news-147506-wyjatkowo_lagodny_luty_optymistyczna_prognoza_pogody_na_weekend_powieje_jedynie_wiatr?rss=1](https://epoznan.pl/news-news-147506-wyjatkowo_lagodny_luty_optymistyczna_prognoza_pogody_na_weekend_powieje_jedynie_wiatr?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T07:24:00+00:00

IMGW zapowiada dla Poznania ocieplenie.

## Pasażerka zasłabła w tramwaju, wezwano karetkę. Ruch przez chwilę został wstrzymany.
 - [https://epoznan.pl/news-news-147505-pasazerka_zaslabla_w_tramwaju_wezwano_karetke_ruch_przez_chwile_zostal_wstrzymany?rss=1](https://epoznan.pl/news-news-147505-pasazerka_zaslabla_w_tramwaju_wezwano_karetke_ruch_przez_chwile_zostal_wstrzymany?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T07:06:00+00:00

Do zdarzenia doszło w piątek o godzinie 7:34.

## Nastolatek chorował na raka żołądka. Był pasjonatem samochodów. Zanim odszedł, udało się spełnić jego największe marzenie
 - [https://epoznan.pl/news-news-147504-nastolatek_chorowal_na_raka_zoladka_byl_pasjonatem_samochodow_zanim_odszedl_udalo_sie_spelnic_jego_najwieksze_marzenie?rss=1](https://epoznan.pl/news-news-147504-nastolatek_chorowal_na_raka_zoladka_byl_pasjonatem_samochodow_zanim_odszedl_udalo_sie_spelnic_jego_najwieksze_marzenie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-02T06:53:00+00:00

Mateusz nie spodziewał się, że wizyta w szpitalu odmieni całe jego życie.

