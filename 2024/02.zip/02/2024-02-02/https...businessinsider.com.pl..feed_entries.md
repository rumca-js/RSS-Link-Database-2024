# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Prezydent: tylko jeden podmiot w Polsce jest w stanie rozstrzygnąć problem konstytucyjny
 - [https://businessinsider.com.pl/polityka/andrzej-duda-w-kanale-zero-tylko-jeden-podmiot-moze-rozstrzygnac-problem/t4gdt51](https://businessinsider.com.pl/polityka/andrzej-duda-w-kanale-zero-tylko-jeden-podmiot-moze-rozstrzygnac-problem/t4gdt51)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T20:48:12+00:00

Prezydent Andrzej Duda przyznaje, że mamy bardzo poważny konflikt prawny w Polsce. Jego zdaniem Trybunał Konstytucyjny jest jedynym podmiotem, który może rozwiązać problem. Zapewnia, że jest gotowy usiąść i rozmawiać o "resecie konstytucyjnym".

## Członek zarządu Orlenu rezygnuje. Odpowiadał za handel i logistykę
 - [https://businessinsider.com.pl/biznes/kadrowa-miotla-w-orlenie-czlonek-zarzadu-rezygnuje/216nb75](https://businessinsider.com.pl/biznes/kadrowa-miotla-w-orlenie-czlonek-zarzadu-rezygnuje/216nb75)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T19:40:35+00:00

Michał Róg złożył rezygnację z funkcji członka zarządu spółki — poinformował w piątek Orlen w komunikacie. Tego samego dnia prezesem przestanie być prezes Daniel Obajtek.

## Poznaliśmy nazwiska kandydatów do nowej rady nadzorczej Orlenu
 - [https://businessinsider.com.pl/biznes/poznalismy-nazwiska-kandydatow-do-nowej-rady-nadzorczej-orlenu/1d8jqbm](https://businessinsider.com.pl/biznes/poznalismy-nazwiska-kandydatow-do-nowej-rady-nadzorczej-orlenu/1d8jqbm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T19:12:19+00:00

Akcjonariusze Orlenu, w tym głównie Skarb Państwa, odsłaniają karty. Spółka ujawniła, kto kandyduje do składu rady nadzorczej w nowym rozdaniu.

## Poznaliśmy nazwiska kandydatów do nowej rady nadzorczej Orlenu. Wybiorą następcę Obajtka
 - [https://businessinsider.com.pl/biznes/oni-wybiora-nowego-prezesa-orlenu-oto-kandydaci-do-rady-nadzorczej/1d8jqbm](https://businessinsider.com.pl/biznes/oni-wybiora-nowego-prezesa-orlenu-oto-kandydaci-do-rady-nadzorczej/1d8jqbm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T19:12:19+00:00

Akcjonariusze Orlenu, w tym głównie Skarb Państwa, odsłaniają karty. Spółka ujawniła, kto kandyduje do składu rady nadzorczej w nowym rozdaniu. To oni prawdopodobnie wybiorą m.in. nowego prezesa, który zastąpi Daniela Obajtka.

## Sąd oddalił wniosek o otwarcie likwidacji regionalnej rozgłośni Polskiego Radia
 - [https://businessinsider.com.pl/prawo/sad-wbrew-woli-ministra-kultury-oddalil-wniosek-o-likwidacje/c2nexxp](https://businessinsider.com.pl/prawo/sad-wbrew-woli-ministra-kultury-oddalil-wniosek-o-likwidacje/c2nexxp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T18:43:18+00:00

Decydują się losy kolejnych regionalnych rozgłośni Polskiego Radia. W przypadku Radia Lublin sąd wydał decyzję, która nie jest po myśli ministra kultury Bartłomieja Sienkiewicza. W uzasadnieniu sporo miejsca jest poświęcone Trybunałowi Konstytucyjnemu.

## Prezydent ma dwóch nowych doradców z rządu PiS
 - [https://businessinsider.com.pl/polityka/prezydent-andrzej-duda-ma-dwoch-nowych-doradcow-z-rzadu-pis/dyrvqv5](https://businessinsider.com.pl/polityka/prezydent-andrzej-duda-ma-dwoch-nowych-doradcow-z-rzadu-pis/dyrvqv5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T18:07:56+00:00

Powiększa się grono zaufanych doradców społecznych podpowiadających prezydentowi. Andrzej Duda w piątek powołał byłego ministra infrastruktury i byłego podsekretarza w resorcie środowiska z rządu PiS.

## Gęstnieje paliwo, walą się dachy. Takiej zimy Alaska nie widziała od lat
 - [https://businessinsider.com.pl/wiadomosci/gestnieje-paliwo-wala-sie-dachy-takiej-zimy-alaska-nie-widziala-od-15-lat/8ggbyhn](https://businessinsider.com.pl/wiadomosci/gestnieje-paliwo-wala-sie-dachy-takiej-zimy-alaska-nie-widziala-od-15-lat/8ggbyhn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T17:39:47+00:00

Na Alasce jest tak zimno i śnieżnie, że olej opałowy gęstnieje, a setki firm muszą opuścić swoje siedziby. Takiej zimy nie widziano tam od wielu lat — w niektórych miejscach termometry pokazują minus 40 st. Celsjusza. "Czasem trudno mi znaleźć mój biały samochód w śniegu" — mówi jeden z mieszkańców.

## Niemiecki rząd też miał problem z budżetem i trybunałem. Jest ważny krok
 - [https://businessinsider.com.pl/gospodarka/niemiecki-rzad-tez-mial-problem-z-budzetem-i-trybunalem-jest-wazny-krok/qks53mg](https://businessinsider.com.pl/gospodarka/niemiecki-rzad-tez-mial-problem-z-budzetem-i-trybunalem-jest-wazny-krok/qks53mg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T17:32:39+00:00

Nie tylko w Polsce rząd walczył z czasem, by uchwalić budżet. Problemy mieli też Niemcy. Bundestag zatwierdził tę kluczową ustawę w piątek 2 lutego, choć miała zostać przyjęta w grudniu. To nie kończy jednak całej procedury.

## Złoto "konstrukcyjnie odporne". Dwa źródła popytu według bankowego giganta
 - [https://businessinsider.com.pl/gielda/wiadomosci/zloto-konstrukcyjnie-odporne-dwa-zrodla-popytu-wedlug-bankowego-giganta/rntzppy](https://businessinsider.com.pl/gielda/wiadomosci/zloto-konstrukcyjnie-odporne-dwa-zrodla-popytu-wedlug-bankowego-giganta/rntzppy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T17:30:44+00:00

Złoto jest "konstrukcyjnie odporne" — stwierdzili analitycy banku Goldman Sachs w swojej najnowszej analizie. Sprzyjają temu oczekiwane obniżki stóp procentowych w USA, choć po ostatniej wypowiedzi szefa Fed wydaje się, że się przesunęły. Analitycy zauważyli, że są obecnie dwa źródła silnego popytu dla złota, ale i trzecie powinno się wkrótce uaktywnić.

## Wojna w sądownictwie. KRS mówi o rażącym naruszeniu prawa
 - [https://businessinsider.com.pl/prawo/wojna-w-sadownictwie-krs-mowi-o-razacym-naruszeniu-prawa/8f2bnlk](https://businessinsider.com.pl/prawo/wojna-w-sadownictwie-krs-mowi-o-razacym-naruszeniu-prawa/8f2bnlk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T16:53:33+00:00

Sprawa Mariusza Kamińskiego i Macieja Wąsika podzieliła środowisko sędziowskie. KRS w uchwale wskazuje na "rażące naruszenie prawa" i "efekt mrożący", który — jej zdaniem — nie jest akceptowany w demokratycznym państwie prawa.

## Czy w wyborach samorządowych 2024 można głosować za granicą?
 - [https://businessinsider.com.pl/wiadomosci/wybory-samorzadowe-2024-czy-mozna-glosowac-za-granica/g1e2mdb](https://businessinsider.com.pl/wiadomosci/wybory-samorzadowe-2024-czy-mozna-glosowac-za-granica/g1e2mdb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T16:44:45+00:00

Wybory samorządowe odbędą się w kwietniu 2024 r. Polacy zadecydują wtedy, kto będzie rządził na szczeblu im najbliższym. Czy można głosować poza miejscem zamieszkania? Czy możliwe będzie oddanie głosu poza granicami Polski?

## Akcje Marka Zuckerberga poszybowały. Biznes jeszcze nigdy nie był wyceniany tak wysoko
 - [https://businessinsider.com.pl/gielda/wiadomosci/rekord-meta-platforms-na-gieldzie-akcje-marka-zuckerberga-wystrzelily/mqklywn](https://businessinsider.com.pl/gielda/wiadomosci/rekord-meta-platforms-na-gieldzie-akcje-marka-zuckerberga-wystrzelily/mqklywn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T16:29:17+00:00

Biznes m.in. Facebooka i Instagrama w ramach grupy Meta jest wyceniany przez inwestorów najwyżej w historii. Ta pisze się na naszych oczach, po tym, jak notowania akcji spółki na giełdzie w USA wystrzeliły o ponad 20 proc. Złożyło się na to kilka bardzo dobrych informacji.

## Ubóstwo energetyczne może dotyczyć aż 40 proc. osób. Zostało pięć miesięcy
 - [https://businessinsider.com.pl/poradnik-finansowy/ubostwo-energetyczne-moze-dotyczyc-az-40-proc-osob-zostalo-piec-miesiecy/fnhlsfc](https://businessinsider.com.pl/poradnik-finansowy/ubostwo-energetyczne-moze-dotyczyc-az-40-proc-osob-zostalo-piec-miesiecy/fnhlsfc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T16:18:23+00:00

Mimo Tarczy Solidarnościowej średnioroczny wzrost cen energii elektrycznej na rynku detalicznym wyniósł 21,4 proc. — wynika z danych GUS. Według danych największych dystrybutorów energii elektrycznej w Polsce, średnia stawka za 1 kWh w najbardziej popularnej taryfie G11 w pierwszej połowie roku wynosić będzie około 90 gr brutto, a po przekroczeniu zużycia 1500 kWh (lub 2000 kWh) już około 1,3 zł brutto. Jeśli Tarcza przestanie obowiązywać od połowy roku, w "ubóstwo energetyczne" wpaść może nawet 40 proc. osób.

## Poznaliśmy listę zawodów, które dadzą pracę w przyszłości. Jest nowość
 - [https://businessinsider.com.pl/praca/gdzie-bedzie-praca-lista-zawodow-przyszlosci-jest-jedna-nowosc/7zcm1j6](https://businessinsider.com.pl/praca/gdzie-bedzie-praca-lista-zawodow-przyszlosci-jest-jedna-nowosc/7zcm1j6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T15:58:17+00:00

Dokładnie 34 zawody znalazły się na nowej liście opracowanej przez Ministerstwo Edukacji Narodowej (MEN). Dla nich jest prognozowane szczególne zapotrzebowanie na krajowym rynku pracy. Nowością w zestawieniu jest technik elektromobilności.

## Urlop z powodu siły wyższej. Kto może go wziąć? Od stycznia nowe limity
 - [https://businessinsider.com.pl/prawo/praca/urlop-z-powodu-sily-wyzszej-2024-kto-moze-go-wziac-od-stycznia-nowe-limity/qk9w5qh](https://businessinsider.com.pl/prawo/praca/urlop-z-powodu-sily-wyzszej-2024-kto-moze-go-wziac-od-stycznia-nowe-limity/qk9w5qh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T15:40:00+00:00

Urlop z powodu działania siły wyższej wszedł w życie w 2023 r. Jeśli pracownik w ubiegłym roku z niego nie skorzystał, urlop przepadł, ponieważ nie podlega przeniesieniu na kolejny rok. Jednak od stycznia taki urlop znów jest dostępny do wykorzystania. Dla kogo i na jakich zasadach? Czy jest płatny?

## Tankowanie będzie droższe. Eksperci prognozują ceny i komentują efekt Obajtka
 - [https://businessinsider.com.pl/wiadomosci/co-z-cenami-paliw-eksperci-komentuja-efekt-obajtka/qphqgqw](https://businessinsider.com.pl/wiadomosci/co-z-cenami-paliw-eksperci-komentuja-efekt-obajtka/qphqgqw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T15:39:49+00:00

W najbliższych dniach kierowcy nie powinni odczuć skutków dymisji prezesa Orlenu Daniela Obajtka, choć eksperci nie mają dobrych informacji. Mimo spadku cen w hurcie, na stacjach będzie drożej.

## Taka mogła być polska inflacja w styczniu. Kolejny spadek
 - [https://businessinsider.com.pl/gospodarka/taka-mogla-byc-polska-inflacja-w-styczniu-kolejny-spadek/lf07s6k](https://businessinsider.com.pl/gospodarka/taka-mogla-byc-polska-inflacja-w-styczniu-kolejny-spadek/lf07s6k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T15:24:15+00:00

Zwykle Główny Urząd Statystyczny publikuje szacunki inflacji konsumenckiej już ostatniego dnia danego miesiąca (tzw. flash). Ale jak co roku w styczniu nie ma tej publikacji ze względu na przebudowę koszyka inflacyjnego. Ekonomiści oszacowali, jaka mogła być inflacja w styczniu 2024 r.

## Kolejna firma wychodzi z Rosji. To był długotrwały i kosztowny proces
 - [https://businessinsider.com.pl/biznes/kolejna-firma-wychodzi-z-rosji-to-byl-dlugotrwaly-i-kosztowny-proces/z386tsb](https://businessinsider.com.pl/biznes/kolejna-firma-wychodzi-z-rosji-to-byl-dlugotrwaly-i-kosztowny-proces/z386tsb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T15:03:14+00:00

Asbis, dystrybutor, deweloper i dostawca produktów, rozwiązań i usług IT, sprzedał spółki zależne w Rosji i całkowicie zaprzestał działalności w tym kraju. Zarejestrowana na Cyprze i notowana na GPW spółka szacuje spadek zysku netto za 2023 r. na około 25 mln dol.

## Bardziej niż imprezy cenią sen. 20-latkowie są w łóżkach o 21
 - [https://businessinsider.com.pl/lifestyle/sen-ponad-imprezowanie-20-latkowie-sa-w-lozkach-o-21/f5kkpfx](https://businessinsider.com.pl/lifestyle/sen-ponad-imprezowanie-20-latkowie-sa-w-lozkach-o-21/f5kkpfx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T14:33:22+00:00

Zapomnij o chodzeniu do barów czy kolacji na mieście późno wieczorem. Najgorętsza nowa pora snu dla 20-latków to godz. 21.00. Również biznes w USA widzi tę zmianę — bary dodają poranne imprezy taneczne i inne wydarzenia w ciągu dnia.

## Prezydent o wyroku TK w sprawie budżetu. "Będzie wiążący dla marszałka Sejmu"
 - [https://businessinsider.com.pl/prawo/prezydent-o-wyroku-tk-w-sprawie-budzetu-bedzie-wiazacy-dla-marszalka-sejmu/vq3nze4](https://businessinsider.com.pl/prawo/prezydent-o-wyroku-tk-w-sprawie-budzetu-bedzie-wiazacy-dla-marszalka-sejmu/vq3nze4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T14:26:47+00:00

Wyrok Trybunału Konstytucyjnego w sprawie ustawy budżetowej na 2024 r. będzie dotyczył funkcjonowania Sejmu w przyszłości i będzie wiążący dla marszałka Sejmu — ocenił prezydent Andrzej Duda w wypowiedzi dla Interii. Zapowiedział, że każdą kolejną ustawę prezydent będzie kierować do TK, jeśli marszałek będzie uniemożliwiał udział w głosowaniach Mariuszowi Kamińskiemu i Maciejowi Wąsikowi.

## Koniec z ukrywaniem podatków przez duże firmy. Jest projekt
 - [https://businessinsider.com.pl/prawo/podatki/koniec-z-ukrywaniem-podatkow-przez-duze-firmy-zobacz-co-sie-zmieni/d2ky2lr](https://businessinsider.com.pl/prawo/podatki/koniec-z-ukrywaniem-podatkow-przez-duze-firmy-zobacz-co-sie-zmieni/d2ky2lr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T14:24:20+00:00

Resort finansów przygotował projekt, który ma wprowadzić do polskiego porządku prawnego przepisy unijne. Chodzi o ujawnianie podatków płaconych przed duże firmy w innych krajach Europejskiego Obszaru Gospodarczego.

## New York, San Francisco i Las Vegas — wyjedź w podróż marzeń
 - [https://businessinsider.com.pl/lifestyle/podroze/new-york-san-francisco-i-las-vegas-wyjedz-w-podroz-marzen/xs83tbw](https://businessinsider.com.pl/lifestyle/podroze/new-york-san-francisco-i-las-vegas-wyjedz-w-podroz-marzen/xs83tbw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T14:00:00+00:00

Zwiedzanie Stanów Zjednoczonych jest marzeniem większości pasjonatów podróży. Kto nie chciałby poczuć wiatru we włosach, jadąc słynną Route 66, zgubić się wśród drapaczy chmur na Manhattanie, podziwiać niesamowity Park Yellowstone, czy poczuć atmosferę Hollywood. To właśnie w USA pospacerujesz wśród uliczek nowojorskiego Central Parku, zwiedzisz pięknie położone San Francisco i poznasz kulturę kreolską w Nowym Orleanie. Brzmi zachęcająco, a to tylko wierzchołek tego, co możesz zobaczyć i poczuć w Ameryce. W artykule polecamy sprawdzone i doceniane przez uczestników wycieczki objazdowe po USA od biura podróży Albatros. Zapraszamy!

## "Ale urwał". Spektakularne dane z amerykańskiego rynku pracy. Paliwo dla dolara
 - [https://businessinsider.com.pl/gospodarka/ale-urwal-spektakularne-dane-z-amerykanskiego-rynku-pracy-paliwo-dla-dolara/9kv4bsj](https://businessinsider.com.pl/gospodarka/ale-urwal-spektakularne-dane-z-amerykanskiego-rynku-pracy-paliwo-dla-dolara/9kv4bsj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T13:53:29+00:00

Jak w każdy pierwszy piątek miesiąca rynek wyczekiwał na dane z amerykańskiego rynku pracy. Tym razem okazały się zaskakująco mocne, wpisując się w ostatnie dobre dane, potwierdzające siłę amerykańskiej gospodarki mimo wysokich stóp procentowych.

## Trzęsienie ziemi w Enei. Prezes energetycznego koncernu odwołany
 - [https://businessinsider.com.pl/biznes/trzesienie-ziemi-w-enei-prezes-energetycznego-koncernu-odwolany/zzb2n7m](https://businessinsider.com.pl/biznes/trzesienie-ziemi-w-enei-prezes-energetycznego-koncernu-odwolany/zzb2n7m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T13:51:41+00:00

Rada nadzorcza Enei odwołała w piątek Pawła Majewskiego ze stanowiska prezesa spółki. Tym samym potwierdziły się wcześniejsze informacje Business Insidera.

## Były prezes TK: wszyscy członkowie trybunału powinni zakończyć kadencję. Ma sposób
 - [https://businessinsider.com.pl/prawo/wszyscy-czlonkowie-trybunalu-powinni-zakonczyc-kadencje-prof-zoll-ma-sposob/g85200w](https://businessinsider.com.pl/prawo/wszyscy-czlonkowie-trybunalu-powinni-zakonczyc-kadencje-prof-zoll-ma-sposob/g85200w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T13:47:21+00:00

Pod adresem prezydenta Andrzeja Dudy padły poważne zarzuty ze strony byłego prezesa Trybunału Konstytucyjnego. Wymienił trzy przykłady łamania przez niego konstytucji.  Wskazał też sposób, w który można rozwiązać problem z aktualnym składem TK.

## Rząd Tuska wycofa pozew przeciw polityce klimatycznej Unii. Godzimy się na wszystko
 - [https://businessinsider.com.pl/gospodarka/rzad-tuska-wycofa-pozew-przeciw-polityce-klimatycznej-unii-godzimy-sie-na-wszystko/z2r7l2d](https://businessinsider.com.pl/gospodarka/rzad-tuska-wycofa-pozew-przeciw-polityce-klimatycznej-unii-godzimy-sie-na-wszystko/z2r7l2d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T13:47:12+00:00

Ta decyzja oznacza, że nie protestujemy już przeciw propozycjom klimatycznym Unii. Rząd Donalda Tuska wycofał pozwy z TSUE. Na to wskazują przynajmniej informacje z kilku źródeł rządowych i unijnych, pozyskane przez Reutersa. Polską gospodarkę czeka wielki wysiłek, posiadaczy domów duże wydatki, a posiadaczy samochodów spalinowych zmusi do przejścia na elektryki, ceny prądu i ogrzewania pójdą w górę. Trudniejszy czas będzie miała też branża meblarska.

## Rząd wycofa pozew przeciw polityce klimatycznej Unii. Godzimy się na wszystko
 - [https://businessinsider.com.pl/gospodarka/rzad-wycofa-pozew-przeciw-polityce-klimatycznej-unii-godzimy-sie-na-wszystko/z2r7l2d](https://businessinsider.com.pl/gospodarka/rzad-wycofa-pozew-przeciw-polityce-klimatycznej-unii-godzimy-sie-na-wszystko/z2r7l2d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T13:47:12+00:00

Ta decyzja oznacza, że nie protestujemy już przeciw propozycjom klimatycznym Unii. Rząd Donalda Tuska wycofał pozwy z TSUE. Polską gospodarkę czeka wielki wysiłek, posiadaczy domów duże wydatki, a posiadaczy samochodów spalinowych zmusi do przejścia na elektryki, ceny prądu pójdą w górę. Trudniejszy czas będzie miała też branża meblarska.

## Umowa z Polską na 90 mld zł nie trafi do kosza? Korea ingeruje
 - [https://businessinsider.com.pl/finanse/umowa-z-polska-na-90-mld-zl-nie-trafi-do-kosza-korea-ingeruje/rppsfhw](https://businessinsider.com.pl/finanse/umowa-z-polska-na-90-mld-zl-nie-trafi-do-kosza-korea-ingeruje/rppsfhw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T13:07:10+00:00

Jest szansa, że umowa zbrojeniowa Polski z Koreą Południową wartości 30 bln wonów (ok. 90 mld zł) nie trafi do kosza. Po tym, gdy jej finansowanie utknęło w martwym punkcie, do akcji wkroczył koreański rząd.

## Znamy wysokość składki zdrowotnej. Oficjalny komunikat ZUS
 - [https://businessinsider.com.pl/wiadomosci/znamy-wysokosc-skladki-zdrowotnej-oficjalny-komunikat-zus/8me7ews](https://businessinsider.com.pl/wiadomosci/znamy-wysokosc-skladki-zdrowotnej-oficjalny-komunikat-zus/8me7ews)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T13:06:30+00:00

ZUS w najnowszym komunikacie podał wysokość składki zdrowotnej dla poszczególnych grup przedsiębiorców. Potwierdził tym samym to, co w Business Insider Polska pisaliśmy w ubiegłym tygodniu.

## Finowie protestują: zamknęli sklepy i przedszkola. "Kto pierwszy, ten lepszy"
 - [https://businessinsider.com.pl/wiadomosci/finowie-protestuja-zamkneli-przedszkola-kto-pierwszy-ten-lepszy/7jqsjl7](https://businessinsider.com.pl/wiadomosci/finowie-protestuja-zamkneli-przedszkola-kto-pierwszy-ten-lepszy/7jqsjl7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:54:16+00:00

W Finlandii rozpoczął się w środę ogólnokrajowy strajk. Jako pierwsi do protestu przystąpili pracowniczy przedszkoli. Z uwagi na duże braki kadrowe, dzieci były przyjmowane na zasadzie "kto pierwszy ten lepszy". Fiński przewoźnik odwołał ponad 500 lotów zaplanowanych na czwartek i piątek. Protest może kosztować fińską gospodarkę setki milionów euro.

## Dwa kraje wyprzedzą polską gospodarkę, Europa daleko w tyle. Nowe prognozy
 - [https://businessinsider.com.pl/gospodarka/dwa-kraje-wyprzedza-polska-gospodarke-europa-daleko-w-tyle-nowe-prognozy/gb99xve](https://businessinsider.com.pl/gospodarka/dwa-kraje-wyprzedza-polska-gospodarke-europa-daleko-w-tyle-nowe-prognozy/gb99xve)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:53:55+00:00

Prognoza dla Polski na ten rok jest optymistyczna. Renomowany koncern doradczy i audytorski EY uważa, że nasza gospodarka będzie rosła w tempie nieosiągalnym dla innych krajów Europy. I na świecie nie będzie mieć zresztą wielu konkurentów do miana najszybciej rozwijającego się kraju.

## Coraz bliżej pierwszych pieniędzy z Krajowego Planu Odbudowy
 - [https://businessinsider.com.pl/gospodarka/coraz-blizej-pierwszych-pieniedzy-z-krajowego-planu-odbudowy/nz1h6e0](https://businessinsider.com.pl/gospodarka/coraz-blizej-pierwszych-pieniedzy-z-krajowego-planu-odbudowy/nz1h6e0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:51:32+00:00

Oczekuję, że na początku kwietnia Polska otrzyma blisko 7 mld euro z Krajowego Planu Odbudowy – przekazała w piątek Katarzyna Pełczyńska-Nałęcz, minister funduszy i polityki regionalnej. Dodała, że w lutym ma zakończyć się audyt programów w ramach KPO.

## Tyle wyniesie waloryzacja emerytur. Rząd podał kluczowy wskaźnik
 - [https://businessinsider.com.pl/praca/emerytury/tyle-wyniesie-waloryzacja-emerytur-rzad-podal-kluczowy-wskaznik/9ltctxx](https://businessinsider.com.pl/praca/emerytury/tyle-wyniesie-waloryzacja-emerytur-rzad-podal-kluczowy-wskaznik/9ltctxx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:43:38+00:00

Prognozuje się, że wskaźnik waloryzacji emerytur i rent w 2024 r. wyniesie nie mniej niż 12,3 proc. — poinformowała ministra rodziny, pracy i polityki społecznej Agnieszka Dziemianowicz-Bąk. Przy takiej wartości wskaźnika całkowity koszt waloryzacji świadczeń wyniesie ok. 43,6 mld zł.

## Rządowe dopalacze odstawione. Popyt na kredyty spada
 - [https://businessinsider.com.pl/nieruchomosci/rzadowe-dopalacze-odstawione-popyt-na-kredyty-spada/g65ypr0](https://businessinsider.com.pl/nieruchomosci/rzadowe-dopalacze-odstawione-popyt-na-kredyty-spada/g65ypr0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:36:14+00:00

Popyt na kredyty hipoteczny po wygaszeniu programu "bezpieczny kredyt' spada. Jednak — jak wynika z analizy HREIT — chętnych na kredyty jest więcej niż przed wprowadzeniem rządowego programu dopłat. To efekt łatwiejszego dostępu do kredytów i rosnących wynagrodzeń.

## Polska będzie miała pływający gazoport. Dostawca technologii wybrany
 - [https://businessinsider.com.pl/biznes/gazoport-na-wodzie-polska-bedzie-miala-plywajacy-gazoport/dcxws4s](https://businessinsider.com.pl/biznes/gazoport-na-wodzie-polska-bedzie-miala-plywajacy-gazoport/dcxws4s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:30:00+00:00

Gaz-System podjął decyzję o wyborze dostawcy i operatora pływającego terminalu LNG w Zatoce Gdańskiej, który będzie mógł obsługiwać statki tankowce przewożące skroplony gaz ziemny. Przetarg na realizację tego projektu zwyciężyła firma Mitsui O.S.K. Lines, dysponująca największą flotą metanowców na świecie. Dzięki tej inwestycji wzrośnie potencjał importowy gazu ziemnego do Polski przez morze.

## TOP 5 hoteli z basenem i SPA. Wyjątkowe miejsca na relaks w otoczeniu natury
 - [https://businessinsider.com.pl/lifestyle/podroze/top-5-hoteli-z-basenem-i-spa-wyjatkowe-miejsca-na-relaks-w-otoczeniu-natury/qwwq1zy](https://businessinsider.com.pl/lifestyle/podroze/top-5-hoteli-z-basenem-i-spa-wyjatkowe-miejsca-na-relaks-w-otoczeniu-natury/qwwq1zy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:30:00+00:00

Chwile temu rozpoczął się luty, a większość z nas już z niecierpliwością oczekuje pierwszych oznak wiosny. Jest to idealny moment, by znaleźć miejsce, w którym możemy się zrelaksować i naładować baterie po mroźnych miesiącach. Polska, ze swoimi malowniczymi zakątkami, kusi obietnicą wyjątkowego wypoczynku. Oto pięć luksusowych obiektów z basenami i SPA, zlokalizowanych w pięknych regionach kraju, które oferują nie tylko odprężenie w komfortowych warunkach, ale również szansę na regenerację w pierwszych promieniach słońca. Czy to w otoczeniu górskich szczytów, czy nad brzegami Bałtyku, każdy z tych hoteli zapewni wyjątkową atmosferę i regenerację. Zarezerwuj swój pobyt przez Triverna.pl, korzystając z atrakcyjnych rabatów. Zachęcamy do skorzystania z tej niepowtarzalnej oferty, by już teraz poczuć zbliżającą się wiosnę w otoczeniu luksusu i piękna. Zapraszamy!

## Tesla ma duży problem z 2 mln aut. "Usterka zwiększa ryzyko wypadku"
 - [https://businessinsider.com.pl/biznes/tesla-ma-duzy-problem-z-2-mln-aut-usterka-zwieksza-ryzyko-wypadku/80z3nvk](https://businessinsider.com.pl/biznes/tesla-ma-duzy-problem-z-2-mln-aut-usterka-zwieksza-ryzyko-wypadku/80z3nvk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:24:48+00:00

Tesla musi naprawić praktycznie wszystkie swoje pojazdy na amerykańskim rynku. Wszystko przez usterkę świateł, która "może zwiększać ryzyko wypadku". Problem ma dotyczyć nawet 2,2 mln aut — informuje Reuters.

## Czarne złoto daje zarobić. Gigantyczne zyski kolosów
 - [https://businessinsider.com.pl/biznes/czarne-zloto-daje-zarobic-gigantyczne-zyski-kolosow/gv3bmkr](https://businessinsider.com.pl/biznes/czarne-zloto-daje-zarobic-gigantyczne-zyski-kolosow/gv3bmkr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:23:54+00:00

Rosnąca produkcja ropy w USA pomogła ExxonMobil i Chevron osiągnąć drugie co do wielkości roczne zyski od dekady pomimo spadku cen, który uniemożliwił pobicie rekordów zanotowanych w 2022 r. — donosi "Financial Times".

## Dlaczego Polki nie rodzą? PiS w rok wydał 10 mln zł, a odpowiedzi brak
 - [https://businessinsider.com.pl/wiadomosci/dlaczego-polki-nie-rodza-pis-wydal-10-mln-zl-w-rok-a-odpowiedzi-brak/cd7n8n1](https://businessinsider.com.pl/wiadomosci/dlaczego-polki-nie-rodza-pis-wydal-10-mln-zl-w-rok-a-odpowiedzi-brak/cd7n8n1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T12:18:12+00:00

Dlaczego w Polsce rodzi się mało dzieci? Badał to powołany przez rząd PiS instytut, którego roczny budżet wyniósł 10 mln zł. Wydatki Instytutu Pokolenia wzięła pod lupę Najwyższa Izba Kontroli. Ma szereg zastrzeżeń, w tym dotyczących wynagrodzeń dla pracowników.

## Meksyk czeka! Wybraliśmy 3 bestsellerowe oferty. Rozchodzą się jak świeże bułeczki
 - [https://businessinsider.com.pl/lifestyle/podroze/meksyk-czeka-wybralismy-3-bestsellerowe-oferty-rozchodza-sie-jak-swieze-buleczki/qmw5dh4](https://businessinsider.com.pl/lifestyle/podroze/meksyk-czeka-wybralismy-3-bestsellerowe-oferty-rozchodza-sie-jak-swieze-buleczki/qmw5dh4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T11:57:37+00:00

Meksyk to niesamowity, egzotyczny kierunek podróży. W ostatnich latach zyskuje ogromną popularność wśród turystów z Europy. Co sprawia, że warto wybrać się na urlop do tego fascynującego kraju? Krajobrazy, nieograniczone słońce, zachwycająca architektura i świetne jedzenie! Poznaj więcej atrakcji. Znaleźliśmy 3 bestsellerowe oferty.

## Pierwsza Prezes Sądu Najwyższego nie zejdzie z pola bitwy. "Chyba że mnie z niego zniosą"
 - [https://businessinsider.com.pl/wiadomosci/i-prezes-sadu-najwyzszego-nie-zejde-z-pola-bitwy-chyba-ze-mnie-zniosa/d1bgjhs](https://businessinsider.com.pl/wiadomosci/i-prezes-sadu-najwyzszego-nie-zejde-z-pola-bitwy-chyba-ze-mnie-zniosa/d1bgjhs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T11:05:42+00:00

Pierwsza Prezes Sądu Najwyższego przyznaje, że obawia się "wariantu tureckiego". "Stoimy na skraju przepaści. Naprawdę z dużą grozą patrzę na to, co może się zadziać w przyszłości" — mówi w rozmowie z Onetem prof. Małgorzata Manowska. Ocenia, że wszyscy z obu stron doprowadzili do groźnej dla Polski sytuacji.

## Znamy wielkość dziury budżetowej. Resort finansów podał dane
 - [https://businessinsider.com.pl/gospodarka/znamy-wielkosc-dziury-budzetowej-resort-finansow-podal-dane/tx31222](https://businessinsider.com.pl/gospodarka/znamy-wielkosc-dziury-budzetowej-resort-finansow-podal-dane/tx31222)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T10:56:50+00:00

Deficyt budżetu państwa na koniec grudnia 2023 r. wyniósł niespełna 85,6 mld zł — podało Ministerstwo Finansów. To spory wzrost wobec poprzedniego roku. Dochody i wydatki okazały się nieco niższe od planu.

## Król otwiera budowę wielkiej fabryki w Szczecinie
 - [https://businessinsider.com.pl/gospodarka/krol-otwiera-budowe-wielkiej-fabryki-w-szczecinie/wfy6qh9](https://businessinsider.com.pl/gospodarka/krol-otwiera-budowe-wielkiej-fabryki-w-szczecinie/wfy6qh9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T09:11:17+00:00

Król Danii Fryderyk X uroczyście otworzył w Szczecinie budowę fabryki komponentów turbin wiatrowych do morskich farm wiatrowych. To pierwszy zakład firmy Vestas w Polsce.

## Flixbus pojechał z dzieckiem. O matce zapomniał
 - [https://businessinsider.com.pl/wiadomosci/flixbus-pojechal-z-dzieckiem-o-matce-zapomnial/0h1gm6t](https://businessinsider.com.pl/wiadomosci/flixbus-pojechal-z-dzieckiem-o-matce-zapomnial/0h1gm6t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T08:54:27+00:00

Tej podróży do końca życia nie zapomną pewne pasażerki autobusu: Flixbus pojechał z dzieckiem jednej z podróżujących, a kobieta została na postoju. I kierowca, i przewoźnik zasłaniają się przepisami, które nie pozwoliły na powrót na miejsce postoju. Dramatyczna sytuacja wywołała potężny stres u nastoletniego dziecka.

## Hamilton już pomaga. Ferrari bije rekord na giełdzie
 - [https://businessinsider.com.pl/gielda/wiadomosci/lewis-hamilton-juz-pomaga-ferrari-rekord-akcji-na-gieldzie/cwlh4fw](https://businessinsider.com.pl/gielda/wiadomosci/lewis-hamilton-juz-pomaga-ferrari-rekord-akcji-na-gieldzie/cwlh4fw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T08:52:38+00:00

Informacja o przejściu Lewisa Hamiltona, siedmiokrotnego mistrza świata Formuły 1, z Mercedesa do Ferrari zelektryzowała nie tylko kibiców królowej sportów motorowych, ale także inwestorów. Akcje włoskiego producenta samochodów wzrosły do rekordowych poziomów.

## W tym mieście ceny mieszkań wzrosły o 4 proc. w miesiąc
 - [https://businessinsider.com.pl/wiadomosci/w-tym-miescie-ceny-mieszkan-wzrosly-o-4-proc-w-miesiac/wfcwf2p](https://businessinsider.com.pl/wiadomosci/w-tym-miescie-ceny-mieszkan-wzrosly-o-4-proc-w-miesiac/wfcwf2p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T08:44:03+00:00

Średnie ceny metra kwadratowego nowych mieszkań wzrosły w styczniu o 1-4 proc. w ujęciu miesiąc do miesiąca. Drożej jest w czterech największych aglomeracjach w Polsce. W jednej z nich ceny pozostały bez zmian, zaś w dwóch spadły. Tak mówią wstępne dane Rynku Pierwotnego. W Warszawie średnia cena mieszkania przebiła 17 tys. zł za metr.

## Polski produkt podbija Koreę. Jesteśmy tam gigantem
 - [https://businessinsider.com.pl/finanse/handel/polski-produkt-podbija-koree-jestesmy-tam-gigantem/fq8z8jy](https://businessinsider.com.pl/finanse/handel/polski-produkt-podbija-koree-jestesmy-tam-gigantem/fq8z8jy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T08:42:45+00:00

Mieszkańcy Korei Południowej kochają nie tylko kimchi, ale i... polskie mleko. Najnowsze dane pokazują, że 90 proc. importowanego mleka do Korei pochodzi właśnie z naszego kraju.

## Bezpieczny kredyt wygasł, popyt na hipoteki tąpnął
 - [https://businessinsider.com.pl/poradnik-finansowy/kredyty/bezpieczny-kredyt-wygasl-popyt-na-hipoteki-tapnal/877zyzp](https://businessinsider.com.pl/poradnik-finansowy/kredyty/bezpieczny-kredyt-wygasl-popyt-na-hipoteki-tapnal/877zyzp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T08:15:25+00:00

Koniec programu państwowych dopłat do rat spowodował, że w styczniu klienci złożyli dużo mniej wniosków o nowy kredyt mieszkaniowy. Także z tego powodu średnia wartość wnioskowanego kredytu zmalała.

## W jakiej walucie trzymać oszczędności?
 - [https://businessinsider.com.pl/poradnik-finansowy/w-jakiej-walucie-trzymac-oszczednosci/b9h0lcs](https://businessinsider.com.pl/poradnik-finansowy/w-jakiej-walucie-trzymac-oszczednosci/b9h0lcs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T08:00:00+00:00

W kontekście zarządzania osobistymi oszczędnościami często pojawia się pytanie o najbardziej efektywne walutowe strategie przechowywania kapitału. Dotychczas powszechnym zwyczajem było lokowanie nadwyżek finansowych w nisko oprocentowanych depozytach lub na kontach oszczędnościowych w złotówkach. Jeszcze kilka lat temu była to standardowa praktyka. Jednakże zmieniające się realia po 2020 roku, takie jak międzynarodowe wyzwania spowodowane pandemią czy konflikty za wschodnią granicą Polski, znacząco wpłynęły na kurs złotego, nadając słowu „inflacja” nowego, globalnego wymiaru. W rezultacie, wielu Polaków zaczęło rewidować swoje podejście do przyszłości finansowej, rozważając przechowywanie oszczędności w innych walutach. W niniejszym artykule skupimy się na rosnącej popularności oszczędzania w walutach obcych.

## W jakiej walucie trzymać oszczędności?
 - [https://businessinsider.com.pl/gielda/w-jakiej-walucie-trzymac-oszczednosci/k72xddw](https://businessinsider.com.pl/gielda/w-jakiej-walucie-trzymac-oszczednosci/k72xddw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T08:00:00+00:00

W kontekście zarządzania osobistymi oszczędnościami często pojawia się pytanie o najbardziej efektywne walutowe strategie przechowywania kapitału. Dotychczas powszechnym zwyczajem było lokowanie nadwyżek finansowych w nisko oprocentowanych depozytach lub na kontach oszczędnościowych w złotówkach. Jeszcze kilka lat temu była to standardowa praktyka. Jednakże zmieniające się realia po 2020 roku, takie jak międzynarodowe wyzwania spowodowane pandemią czy konflikty za wschodnią granicą Polski, znacząco wpłynęły na kurs złotego, nadając słowu „inflacja” nowego, globalnego wymiaru. W rezultacie, wielu Polaków zaczęło rewidować swoje podejście do przyszłości finansowej, rozważając przechowywanie oszczędności w innych walutach. W niniejszym artykule skupimy się na rosnącej popularności oszczędzania w walutach obcych.

## Przekopali ogródki wpływowych oficerów. Tak kradła grupa w polskich służbach
 - [https://businessinsider.com.pl/wiadomosci/w-ogrodkach-znalezli-dolary-i-kilogramy-bizuterii-zakopaly-je-polskie-sluzby/gnswszs](https://businessinsider.com.pl/wiadomosci/w-ogrodkach-znalezli-dolary-i-kilogramy-bizuterii-zakopaly-je-polskie-sluzby/gnswszs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T07:34:07+00:00

Za nic mieli sobie prawo i to, że pluli w twarz społeczeństwu żyjącemu w smutnych realiach PRL-u. Od końca lat 60. do 1971 r. grupa funkcjonariuszy MSW pod wodzą generała Ryszarda Matejewskiego przemycała z Zachodu dewizy, złoto i dzieła sztuki. Wszystko działo się pod pretekstem przeprowadzania tajnych operacji służb specjalnych — zdobyte środki miały iść na działalność operacyjną MSW. Zamiast tego wylądowały w ogródkach na ich działkach nad Zalewem Zegrzyńskim.

## Korea Północna wystrzeliła kolejne pociski. Sytuacja się zaognia
 - [https://businessinsider.com.pl/wiadomosci/korea-polnocna-znowu-prowokuje-wystrzelila-kolejne-pociski/wy18m47](https://businessinsider.com.pl/wiadomosci/korea-polnocna-znowu-prowokuje-wystrzelila-kolejne-pociski/wy18m47)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T07:19:10+00:00

Korea Północna wystrzeliła w piątek kilka pocisków manewrujących w pobliżu zachodnich wybrzeży Korei Południowej – poinformowało Kolegium Połączonych Szefów Sztabów (JCS) w Seulu. To czwarta taka seria w tym roku.

## Bloomberg pisze o odwołaniu Daniela Obajtka. "Rozkosz dla inwestorów"
 - [https://businessinsider.com.pl/biznes/bloomberg-pisze-o-odwolaniu-daniela-obajtka-bardzo-ostra-ocena/e4ecedt](https://businessinsider.com.pl/biznes/bloomberg-pisze-o-odwolaniu-daniela-obajtka-bardzo-ostra-ocena/e4ecedt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T06:58:06+00:00

Odwołanie Daniela Obajtka ze stanowiska prezesa Orlenu odbiło się szerokim echem również w kluczowych światowych mediach. Dymisję odnotował m.in. Bloomberg, który przy okazji bardzo ostro ocenił prezesurę byłego wójta Pcimia. Zdaniem amerykańskiej agencji odejście Obajtka to "rozkosz dla inwestorów".

## Kadrowa miotła wejdzie dziś do największego banku w Polska
 - [https://businessinsider.com.pl/finanse/kadrowa-miotla-wejdzie-dzis-do-najwiekszego-banku-w-polska/2bbtn76](https://businessinsider.com.pl/finanse/kadrowa-miotla-wejdzie-dzis-do-najwiekszego-banku-w-polska/2bbtn76)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T06:19:57+00:00

W piątek 2 lutego dojdzie do zmian we władzach w największym banku w Polsce. Na dziś zaplanowane jest walne posiedzenie PKO BP, na którym dojdzie do zmian w nadzorze banku. To otworzy drzwi do zmiany prezesa.

## Największy bank w Polsce czeka kadrowa rewolucja
 - [https://businessinsider.com.pl/finanse/kadrowa-miotla-wejdzie-dzis-do-najwiekszego-banku-w-polsce/2bbtn76](https://businessinsider.com.pl/finanse/kadrowa-miotla-wejdzie-dzis-do-najwiekszego-banku-w-polsce/2bbtn76)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T06:19:57+00:00

W piątek 2 lutego dojdzie do zmian we władzach w największym banku w Polsce. Na dziś zaplanowane jest walne posiedzenie PKO BP, na którym dojdzie do zmian w nadzorze banku. To otworzy drzwi do zmiany prezesa.

## Wreszcie poznamy prawdę o wyborach kopertowych. Dokumenty odtajnione
 - [https://businessinsider.com.pl/wiadomosci/komisja-odtajnila-kluczowe-dokumenty-chodzi-o-wybory-kopertowe/3lwl6bw](https://businessinsider.com.pl/wiadomosci/komisja-odtajnila-kluczowe-dokumenty-chodzi-o-wybory-kopertowe/3lwl6bw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T06:18:51+00:00

Komisja śledcza ds. wyborów korespondencyjnych odtajniła część dokumentów, które otrzymała z Poczty Polskiej, KPRM, MSWiA, NIK, MAP, PWPW. "Dokumenty odtajnione mogą być przytaczane w jawnej części obrad komisji" - powiedział PAP prawnik, dr Tomasz Szewc z Politechniki Śląskiej.

## Inwestorzy zachwyceni wynikami Facebooka i Instagrama. Apple za to rozczarował
 - [https://businessinsider.com.pl/gospodarka/inwestorzy-zachwyceni-wynikami-facebooka-i-instagrama-apple-za-to-rozczarowal/y00dddg](https://businessinsider.com.pl/gospodarka/inwestorzy-zachwyceni-wynikami-facebooka-i-instagrama-apple-za-to-rozczarowal/y00dddg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T06:00:31+00:00

Apple rozczarowuje, za to Meta Marka Zuckerberga zachwyca inwestorów swoimi wynikami i rośnie o blisko 15 proc. Największe spółki świata właśnie podały swoje wyniki finansowe. Największa spółka w Polsce, czyli Orlen straciła swojego prezesa, a jej kurs poszedł w reakcji w górę. Drożeją też wciąż mieszkania, w styczniu na tym rynku widać było te same trendy, co w poprzednim roku. Nie zmienia się też trend w polskim przemyśle, który wg badania PMI, nadal wygląda słabo. Miłą niespodziankę mamy za to na unijnym szczycie, który zdołał zatwierdzić pomoc finansową dla Ukrainy. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Nocne zmiany w państwowej spółce. Prezes zawieszony "z ważnych powodów"
 - [https://businessinsider.com.pl/biznes/prezes-pkp-cargo-odwolany-z-waznych-powodow-nocny-komunikat/w0kw955](https://businessinsider.com.pl/biznes/prezes-pkp-cargo-odwolany-z-waznych-powodow-nocny-komunikat/w0kw955)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:49:04+00:00

W czwartek przed północą PKP Cargo opublikowało komunikat, w którym poinformowało o zawieszeniu prezesa Dariusza Seligi (byłego wieloletniego posła PiS) oraz członka zarządu Marka Olkiewicza. Spółka poinformowała, że nastąpiło to "z ważnych powodów". Obowiązki prezesa przejął Maciej Jankiewicz.

## Wiceprezes MOL-a o "cudzie" na stacjach i paliwowej fuzji. "Trudno za tym nadążyć" [WYWIAD]
 - [https://businessinsider.com.pl/biznes/wiceprezes-mol-a-o-cudzie-na-stacjach-i-paliwowej-fuzji-trudno-za-tym-nadazyc-wywiad/wnk8gw2](https://businessinsider.com.pl/biznes/wiceprezes-mol-a-o-cudzie-na-stacjach-i-paliwowej-fuzji-trudno-za-tym-nadazyc-wywiad/wnk8gw2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:45:19+00:00

Ne mamy czego się obawiać. Skupiamy się na naszym biznesie. Politycy niech robią politykę, a sprzedawcy paliw niech sprzedają paliwa — tak Peter Ratatics, wiceprezes węgierskiego koncernu paliwowego MOL, odpowiedział na nasze pytanie, czy obawia się śledztwa w sprawie fuzji Orlenu z Lotosem. Elementem tego paliwowego mariażu była sprzedaż Węgrom ponad 400 stacji paliw, działających pod marką Lotosu. Wiceszef MOL-a skomentował też "cud paliwowy" na stacjach i opowiedział o planach rozwoju sieci na polskim rynku.

## Czy fakturę za przedszkole można wrzucić w koszty? Jest wyrok NSA
 - [https://businessinsider.com.pl/prawo/podatki/czy-fakture-za-przedszkole-mozna-zaliczyc-do-kosztow-podatkowych/4s1gkxb](https://businessinsider.com.pl/prawo/podatki/czy-fakture-za-przedszkole-mozna-zaliczyc-do-kosztow-podatkowych/4s1gkxb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:37:41+00:00

Czy przedsiębiorca, który musi opłacić przedszkole dla swoich dzieci, może zaliczyć ten wydatek do kosztów podatkowych — zapytał jeden z podatników fiskusa. Dzięki temu, że dziecko chodzi do przedszkola, może bowiem pracować, osiągać przychody i płacić podatki — argumentował. Co na to fiskus i sądy?

## Wielkie obniżki cen w dyskontach. Biedronka i Lidl zdetronizowane
 - [https://businessinsider.com.pl/wiadomosci/wielkie-obnizki-cen-w-dyskontach-biedronka-i-lidl-zdetronizowane/ywhvcwv](https://businessinsider.com.pl/wiadomosci/wielkie-obnizki-cen-w-dyskontach-biedronka-i-lidl-zdetronizowane/ywhvcwv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:36:29+00:00

Działające w Polsce dyskonty ruszyły z gigantyczną kampanią obniżek cen. Promocje zapowiedziały już Biedronka i Lidl, ale pod względem liczby przecenionych produktów wygrywa Aldi.

## "Jestem zmęczony tym wielkim logo". Inwestorzy pokochali cichy luksus
 - [https://businessinsider.com.pl/gielda/jestem-zmeczony-tym-wielkim-logo-inwestorzy-pokochali-cichy-luksus/xrt61lp](https://businessinsider.com.pl/gielda/jestem-zmeczony-tym-wielkim-logo-inwestorzy-pokochali-cichy-luksus/xrt61lp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:30:00+00:00

Serial HBO "Sukcesja" przyczynił się do zwiększenia popularności "cichego luksusu". Trend ten zyskał nie tylko w świecie mody — subtelnie przejmuje też portfele inwestorów.

## Amortyzacja mieszkań. Stracili głównie najemcy. Lewiatan i eksperci postulują zniesienie zakazu
 - [https://businessinsider.com.pl/prawo/podatki/zakaz-amortyzacji-mieszkan-lewiatan-i-eksperci-domagaja-sie-zmiany/jesvjll](https://businessinsider.com.pl/prawo/podatki/zakaz-amortyzacji-mieszkan-lewiatan-i-eksperci-domagaja-sie-zmiany/jesvjll)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:21:50+00:00

Lewiatan i eksperci podatkowi domagają się likwidacji zakazu amortyzacji domów i mieszkań. Zakaz wprowadził Polski Ład. Zdaniem ekspertów i przedsiębiorców jest on niezgodny z konstytucyjnymi zasadami praw nabytych i interesów w toku. Zakaz podbił też czynsze za najem nieruchomości, a więc uderzył w najemców.

## Nie będzie wyższego wieku emerytalnego. Potwierdza ministra pracy
 - [https://businessinsider.com.pl/prawo/praca/nie-bedzie-wyzszego-wieku-emerytalnego-plany-resortu-pracy/ve3jhyw](https://businessinsider.com.pl/prawo/praca/nie-bedzie-wyzszego-wieku-emerytalnego-plany-resortu-pracy/ve3jhyw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:11:00+00:00

Nie ma planów podwyższenia wieku emerytalnego. Seniorzy dostaną w tym roku trzynastki i czternastki. Resort pracy chce poprawić sytuację osób otrzymujących tzw. emerytury groszowe. Takie zapowiedzi złożyła Agnieszka Dziemianowicz-Bąk, ministra rodziny, pracy i polityki społecznej.

## Rozwody z pandemii są ważne. Jest jednak jeden haczyk
 - [https://businessinsider.com.pl/prawo/skutki-uchwaly-sn-co-dalej-z-rozwodami-z-czasow-pandemii/y5zmjy3](https://businessinsider.com.pl/prawo/skutki-uchwaly-sn-co-dalej-z-rozwodami-z-czasow-pandemii/y5zmjy3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:04:00+00:00

Nie jest prawdą, że jakikolwiek prawomocny rozwód orzeczony w czasie pandemii przez jednego sędziego i dwóch ławników jest nieważny — zapewnia sędzia Marcin Łochowski. Jest on jednym z trzech sędziów Sądu Najwyższego, którzy wydali głośną i kontrowersyjną uchwałę. Za jej sprawą jedynie część postępowań może być przeprowadzonych na nowo. Co nie oznacza, że wnioski o wznowienie się nie pojawią. Jak to wszystko się skończy, zależy teraz już tylko od sędziów.

## Kto może startować w wyborach samorządowych? Oto długa lista ograniczeń
 - [https://businessinsider.com.pl/wiadomosci/kto-moze-startowac-w-wyborach-samorzadowych-oto-lista-ograniczen/yev7z11](https://businessinsider.com.pl/wiadomosci/kto-moze-startowac-w-wyborach-samorzadowych-oto-lista-ograniczen/yev7z11)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:03:00+00:00

Tegoroczne wybory samorządowe pozwolą Polakom wyłonić nowych przedstawicieli jednostek samorządu terytorialnego. W odróżnieniu od głosowania, którego finałem jest wybór posłów, kandydaci na różnych szczeblach samorządu muszą spełnić różne wymagania.

## Znany komik chce kupić Paramount. Dlaczego chce wydać za dużo?
 - [https://businessinsider.com.pl/gospodarka/znany-komik-chce-kupic-paramount-dlaczego-chce-wydac-za-duzo/0vy2yzk](https://businessinsider.com.pl/gospodarka/znany-komik-chce-kupic-paramount-dlaczego-chce-wydac-za-duzo/0vy2yzk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:02:00+00:00

Allen Media Group zapowiada, że chce kupić Paramount, konglomerat medialny, który jest właścicielem CBS, kanałów takich jak MTV i Comedy Central oraz legendarnego studia filmowego stojącego za takimi hitami jak "Top Gun". Allen chce na ten cel przeznaczyć 14 mld 300 mln dol. Na Wall Street nikt w to nie wierzy.

## Kurs TRY/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-trypln-2-lutego-2024-r/yg55728](https://businessinsider.com.pl/gielda/kursy-walut/kurs-trypln-2-lutego-2024-r/yg55728)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:51+00:00

Lira to jedna z walut, której kurs ulega w ostatnich latach największym zmianom. Poznaj bieżący kurs tureckiej waluty (TRY). Przedstawiamy zmianę notowań w ujęciu tygodniowym, a także dziennym.

## Kurs HUF/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-hufpln-2-lutego-2024-r/n2hrn1g](https://businessinsider.com.pl/gielda/kursy-walut/kurs-hufpln-2-lutego-2024-r/n2hrn1g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:46+00:00

Poznaj zmiany kursu HUF/PLN 2 lutego 2024. Jak dziś wygląda siła węgierskiej waluty względem złotego? Czy jadąc np. na urlop na Węgry, opłaca się dziś wymienić pieniądze? Bieżący kurs forinta sprawdzisz w tym artykule.

## Kurs DKK/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dkkpln-2-lutego-2024-r/23nw9cq](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dkkpln-2-lutego-2024-r/23nw9cq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:41+00:00

Interesuje cię wymiana waluty i chcesz poznać bieżący kurs korony duńskiej? Tutaj znajdziesz aktualne notowania DKK i będziesz mógł sprawdzić, czy polski złoty umacnia się, czy słabnie względem tej waluty. Wczoraj kurs wynosił: 0,57915 zł.

## Kurs SEK/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-sekpln-2-lutego-2024-r/tyddnc5](https://businessinsider.com.pl/gielda/kursy-walut/kurs-sekpln-2-lutego-2024-r/tyddnc5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:35+00:00

Jeśli chcesz poznać aktualny kurs korony szwedzkiej, to jesteś we właściwym miejscu. Tutaj znajdziesz bieżące notowania SEK i sprawdzisz, czy polski złoty umacnia się, czy słabnie względem szwedzkiej waluty. Wczorajszy kurs wynosił 0,38225 zł.

## Kurs NOK/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-nokpln-2-lutego-2024-r/qvez4pm](https://businessinsider.com.pl/gielda/kursy-walut/kurs-nokpln-2-lutego-2024-r/qvez4pm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:25+00:00

Sprawdź, jak zmienia się kurs korony norweskiej. Wczoraj wynosił 0,3805 zł. Jeśli chcesz dowiedzieć się, ile za koronę norweską trzeba zapłacić w tej chwili, przeczytaj poniższy artykuł.

## Kurs CZK/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-czkpln-2-lutego-2024-r/cbtnwcg](https://businessinsider.com.pl/gielda/kursy-walut/kurs-czkpln-2-lutego-2024-r/cbtnwcg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:21+00:00

Przedstawiamy notowania aktualnego kursu waluty CZK z dnia 2 lutego 2024. Wczoraj wynosił 0,1737 zł.

## Kurs GBP/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-2-lutego-2024-r/fwbn8p9](https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-2-lutego-2024-r/fwbn8p9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:16+00:00

Czy kurs funta brytyjskiego zmienił się od wczoraj? Wczorajsza cena waluty to 5,06025 zł. Czy złoty słabnie, czy może jednak umacnia się względem funta brytyjskiego? To ważna informacja dla wszystkich, którzy pracują aktualnie na Wyspach Brytyjskich.

## Kurs CHF/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-2-lutego-2024-r/ffgn5hh](https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-2-lutego-2024-r/ffgn5hh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:11+00:00

Poznaj bieżący kurs franka szwajcarskiego oraz zmianę wartości CHF dzień do dnia, a także tydzień do tygodnia. Jakim zmianom uległ frank w tym okresie? Czy opłaca się dziś wymienić franki na złotówki? Ten artykuł pomoże Ci podjąć decyzję. Wczorajszy kurs CHF/PLN to 4,6292 zł.

## Kurs USD/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-2-lutego-2024-r/jnzbdvt](https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-2-lutego-2024-r/jnzbdvt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:06+00:00

Zobacz aktualne notowania waluty USD. Pokazujemy, jak zmienia się kurs amerykańskiej waluty w stosunku do polskiej złotówki. Czy PLN umacnia się, czy słabnie? Wczoraj kurs USD wynosił 3,9706 zł.

## Kurs EUR/PLN 2 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-2-lutego-2024-r/kwp332m](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-2-lutego-2024-r/kwp332m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:02+00:00

Przedstawiamy bieżące notowania kursu waluty EUR oraz zmiany w ujęciu tygodniowym i dzień po dniu na 2 lutego 2024. Pokazujemy, jak zmienia się kurs euro w stosunku do polskiego złotego. Czy nasza waluta obecnie traci? Wczoraj kurs EUR wynosił: 4,3172 zł. Wszystkiego dowiesz się z poniższego artykułu.

## Duży operator nie zgadza się z zarzutami UOKiK. Chodzi o podwyżki opłat
 - [https://businessinsider.com.pl/wiadomosci/duzy-operator-odpiera-zarzuty-uokik-chodzi-o-podwyzki-oplat/wf1xjzs](https://businessinsider.com.pl/wiadomosci/duzy-operator-odpiera-zarzuty-uokik-chodzi-o-podwyzki-oplat/wf1xjzs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:00+00:00

Operator telekomunikacyjny Vectra nie zgadza się z zarzutami, jakie firmie postawił UOKiK. Chodzi o jednostronne zmiany w umowach z klientami — wprowadzenie podwyżek, a także nowych, nieprzewidzianych opłat.

## Kolejne miliony nagród od PiS na odchodne. Mamy nowe dane
 - [https://businessinsider.com.pl/gospodarka/kolejne-miliony-nagrod-od-pis-na-odchodne-mamy-nowe-dane/e0zs7sg](https://businessinsider.com.pl/gospodarka/kolejne-miliony-nagrod-od-pis-na-odchodne-mamy-nowe-dane/e0zs7sg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-02T05:00:00+00:00

Ministrowie odchodzącego rządu PiS w 2023 r. wydali miliony złotych na nagrody dla swoich współpracowników. Business Insider Polska poznał konkretne kwoty. Jak się dowiadujemy, w resorcie klimatu wypłacono w roku wyborczym blisko dwukrotnie więcej bonusów niż w 2022 r. A jeszcze hojniejszy był Mariusz Kamiński, były minister spraw wewnętrznych. Jego współpracownicy otrzymali w ubiegłym roku ponad 10 mln zł.

