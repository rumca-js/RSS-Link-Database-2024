# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Fury 'devastated' after 'freak' sparring injury forces postponement of Usyk fight
 - [https://news.sky.com/story/tyson-fury-v-oleksandr-usyk-british-boxer-devastated-after-freak-sparring-injury-forces-fight-postponement-13062437](https://news.sky.com/story/tyson-fury-v-oleksandr-usyk-british-boxer-devastated-after-freak-sparring-injury-forces-fight-postponement-13062437)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-02-02T18:54:00+00:00

Tyson Fury has said he is "absolutely devastated" after a "freak" sparring injury forced him to postpone his fight against Oleksandr Usyk, the winner of which will be crowned undisputed heavyweight champion.

## US launches retaliatory strikes in response to Jordan attack
 - [https://news.sky.com/story/us-launches-retaliatory-strikes-in-response-to-jordan-attack-13062379](https://news.sky.com/story/us-launches-retaliatory-strikes-in-response-to-jordan-attack-13062379)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-02-02T17:56:00+00:00

The US has launched strikes against targets in Syria and Iraq a week after three troops were killed and dozens were wounded in a drone attack on a military base in Jordan.

## Mercedes boss says timing of Hamilton's Ferrari decision 'bit us' - but insists he holds 'no grudge'
 - [https://news.sky.com/story/lewis-hamilton-mercedes-boss-toto-wolff-says-timing-of-f1-stars-ferrari-decision-bit-us-but-insists-he-holds-no-grudge-13062174](https://news.sky.com/story/lewis-hamilton-mercedes-boss-toto-wolff-says-timing-of-f1-stars-ferrari-decision-bit-us-but-insists-he-holds-no-grudge-13062174)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-02-02T13:39:00+00:00

Mercedes team principal Toto Wolff has said the timing of Lewis Hamilton's decision to leave for Ferrari "bit us a bit" - but insists there is "no grudge" between them.

## Groundhog Punxsutawney Phil gives weather prediction for 2024
 - [https://news.sky.com/story/groundhog-day-punxsutawney-phil-gives-weather-prediction-for-2024-13062160](https://news.sky.com/story/groundhog-day-punxsutawney-phil-gives-weather-prediction-for-2024-13062160)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-02-02T13:31:00+00:00

Punxsutawney Phil has revealed his annual weather prediction on Groundhog Day in a tongue-in-cheek ritual in Pennsylvania.

## Footage shows moment cruise ship flooded during storm
 - [https://news.sky.com/story/footage-shows-moment-royal-caribbean-cruise-ship-was-flooded-during-storm-in-the-gulf-of-mexico-13062036](https://news.sky.com/story/footage-shows-moment-royal-caribbean-cruise-ship-was-flooded-during-storm-in-the-gulf-of-mexico-13062036)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-02-02T10:45:00+00:00

Footage has emerged of a cruise ship being flooded during a storm in the Gulf of Mexico - causing water to flow into people's cabins.

## Asteroid the size of a skyscraper to pass close to Earth today
 - [https://news.sky.com/story/asteroid-the-size-of-a-skyscraper-to-pass-close-to-earth-today-13062015](https://news.sky.com/story/asteroid-the-size-of-a-skyscraper-to-pass-close-to-earth-today-13062015)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-02-02T10:22:00+00:00

An asteroid the size of a skyscraper will pass close to the Earth today - cosmically speaking.

## Meta and Amazon values surge as Huawei and folding phones take a bite out of Apple's stock
 - [https://news.sky.com/story/meta-and-amazon-values-surge-as-huawei-and-folding-phones-take-a-bite-out-of-apples-stock-13061894](https://news.sky.com/story/meta-and-amazon-values-surge-as-huawei-and-folding-phones-take-a-bite-out-of-apples-stock-13061894)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-02-02T04:20:00+00:00

Meta Platforms and Amazon.com added a combined $280bn in stock market value after the tech giants reported impressive quarterly results.

## At least two people dead and 29 injured in Nairobi blast, reports
 - [https://news.sky.com/story/kenya-at-least-two-people-dead-and-165-injured-in-nairobi-blast-reports-13061888](https://news.sky.com/story/kenya-at-least-two-people-dead-and-165-injured-in-nairobi-blast-reports-13061888)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-02-02T02:32:00+00:00

At least two people have been killed and 29 injured after gas explosion in Nairobi, according to reports.

## 'Abandon Biden': Democrats turn on president over support for Israel
 - [https://news.sky.com/story/abandon-biden-democrats-turn-on-president-over-support-for-israel-13061884](https://news.sky.com/story/abandon-biden-democrats-turn-on-president-over-support-for-israel-13061884)
 - RSS feed: https://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2024-02-02T00:57:00+00:00

There was a time when he'd have jumped at the chance - not today, not with this president.

