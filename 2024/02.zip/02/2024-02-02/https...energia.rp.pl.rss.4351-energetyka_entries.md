# Source:Energetyka, URL:https://energia.rp.pl/rss/4351-energetyka, language:pl-PL

## Wiele energochłonnych firm nie otrzyma pomocy
 - [https://energia.rp.pl/energetyka-zawodowa/art39776811-wiele-energochlonnych-firm-nie-otrzyma-pomocy](https://energia.rp.pl/energetyka-zawodowa/art39776811-wiele-energochlonnych-firm-nie-otrzyma-pomocy)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-02-02T02:00:00+00:00

Rząd uruchamia kolejną rundę wsparcia dla firm energochłonnych. Pula środków to 3,3 mld zł, ale całej puli raczej nie uda się wykorzystać. Branża narzeka na bariery.

