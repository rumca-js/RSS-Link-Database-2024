# Source:Gizmodo, URL:https://gizmodo.com/feed, language:en

## Longlegs' Long-Awaited Teaser Oozes Slow-Burn Horror Mystery
 - [https://gizmodo.com/longlegs-neon-nicolas-cage-maika-monroe-oz-perkins-1851221334](https://gizmodo.com/longlegs-neon-nicolas-cage-maika-monroe-oz-perkins-1851221334)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T22:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/af1df9623c844118c6f48500c2731797.png" /><p>Filmmaker Osgood Perkins (<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/a-new-gretel-hansel-trailer-promises-a-delectable-din-1840773433">Gretel & Hansel</a>) teams up with Neon for Longlegs, which has <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/longlegs-nicolas-cage-neon-teasers-1851183814">created hype using creepy teases of the horror thriller</a> to lead up to its first trailer. The film stars Maika Monroe (It Follows) as an FBI agent tracking down a serial killer played by <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/dream-scenario-interview-nicolas-cage-dreams-borgli-1850974771">Nicolas Cage (Dream Scenario)</a> whose crimes…</p><p><a href="https://gizmodo.com/longlegs-neon-nicolas-cage-maika-monroe-oz-perkins-1851221334"

## Congress Might Actually Do Something About AI, Thanks to Taylor Swift
 - [https://gizmodo.com/congress-might-actually-do-something-about-ai-thanks-t-1851216427](https://gizmodo.com/congress-might-actually-do-something-about-ai-thanks-t-1851216427)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T21:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/367f8c879c6e7af75c2f84b156f95253.jpg" /><p>Welcome to AI This Week, Gizmodo’s weekly deep dive on what’s been happening in artificial intelligence.</p><p><a href="https://gizmodo.com/congress-might-actually-do-something-about-ai-thanks-t-1851216427">Read more...</a></p>

## Put Natalie Portman on Your Shelf With Padmé Amidala's New Star Wars Figure
 - [https://gizmodo.com/padme-amidala-hot-toys-star-wars-attack-of-the-clones-1851221051](https://gizmodo.com/padme-amidala-hot-toys-star-wars-attack-of-the-clones-1851221051)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a1fb23d25e2e11134bd587a203687a3f.jpg" /><p>She was the Queen of Naboo, a Galactic Senate member, a warrior, and a mother. Now, you can <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/padme-amidalas-literary-star-wars-trilogy-will-conclude-1846300799">bring Padmé Amidala home</a> and make her a part of your Star Wars collection. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/hot-toys-morbius-price-release-date-pictures-marvel-mcu-1851162284">Hot Toys</a> just revealed its 1/6th scale Padmé figure from <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/star-wars-attack-of-the-clones-anniversary-anakin-episo-1848916710">Star Wars Episode II: Attack of the Clones</a> and it captures <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/celebrate-the-61-l

## Meta Warns Investors That Mark Zuckerberg Is So Good at Fighting He Might Die
 - [https://gizmodo.com/meta-warns-mark-zuckerberg-good-fighting-he-might-die-1851221827](https://gizmodo.com/meta-warns-mark-zuckerberg-good-fighting-he-might-die-1851221827)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T21:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/594d80628608de9b929cc0deb693e0db.jpg" /><p>The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/mark-zuckerberg-meta-earnings-congress-child-harm-1851219577">CEO of Meta</a> may seem like a mild-mannered man. He’s soft-spoken, the corners of his mouth often turn upwards into something resembling a smile, and he’s polite. But it’s all a disguise – <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/zuckerberg-just-had-the-most-humiliating-day-of-his-lif-1851214229">Mark Zuckerberg lives life on the edge</a>. Meta even said in its <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.sec.gov/ixviewer/ix.html?doc=/Archives/edgar/data/0001326801/000132680124000012/meta-20231231.htm" rel="noopener noreferrer" target="_blank">latest annual report</a> that its CEO could die because of his…</p><p><a href=

## Joe Rogan and Spotify Agree to an Open Relationship
 - [https://gizmodo.com/spotify-doubles-down-misinformation-joe-rogan-extension-1851221193](https://gizmodo.com/spotify-doubles-down-misinformation-joe-rogan-extension-1851221193)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T21:00:51+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/51e8ab4eb5e0022e0bffcb47783041ab.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/musk-tells-rogan-he-s-still-down-to-kick-zuck-s-ass-1850978367">The Joe Rogan Experience</a> is one of the biggest podcasts around thanks to a steady stream of conspiracy theories, right-wing talking points, and the occasional funny comedian. Spotify wants to stay in the Rogan business as it renewed its contract for rights to the podcast.<br /></p><p><a href="https://gizmodo.com/spotify-doubles-down-misinformation-joe-rogan-extension-1851221193">Read more...</a></p>

## How to Know Which Phone You Have: A Guide for Fellow Idiots
 - [https://gizmodo.com/how-to-know-which-phone-you-have-a-guide-for-fellow-id-1851221598](https://gizmodo.com/how-to-know-which-phone-you-have-a-guide-for-fellow-id-1851221598)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T20:55:00+00:00

<video loop="" poster="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/fd55903e1c477be1c8889a3df3939353.jpg"><source src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/fd55903e1c477be1c8889a3df3939353.mp4" type="video/mp4" /></video><p>Have you ever wondered <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/how-buy-smartphone-chose-ios-android-samsung-phone-mode-1850078990">what kind of phone you have</a>? No, seriously. Have you held a phone in your hand that has no identifying marks on it and asked yourself “what the hell is this?” before slamming it against the table like the meme of Patrick Star in the Spongebob Squarepants season 3 episode “Wet Painters?”</p><p><a href="https://gizmodo.com/how-to-know-which-phone-you-have-a-guide-for-fellow-id-1851221598">Read more...</a></p>

## In a Medical First, a French Bulldog Puppy Spontaneously Regrew His Lower Jaw
 - [https://gizmodo.com/in-a-medical-first-a-french-bulldog-puppy-spontaneousl-1851221496](https://gizmodo.com/in-a-medical-first-a-french-bulldog-puppy-spontaneousl-1851221496)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T20:50:30+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/ea90e0d1b73014c144127f56816e2f68.jpg" /><p>A 3-month-old French bulldog named Tyson seems to have pulled off the miraculous. In a recent case report, Cornell University veterinarians describe how the pup spontaneously regrew most of his lower left jaw after it had to be removed to treat his cancer—the first time something like this has ever been documented in…</p><p><a href="https://gizmodo.com/in-a-medical-first-a-french-bulldog-puppy-spontaneousl-1851221496">Read more...</a></p>

## Shop for Your Geeky Sweetie With io9's Valentine's Day Gift Guide
 - [https://gizmodo.com/valentines-day-nerdy-gift-guide-disney-star-wars-shrek-1851218684](https://gizmodo.com/valentines-day-nerdy-gift-guide-disney-star-wars-shrek-1851218684)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4961188625b63db950eea6beac5994c2.jpg" /><p>Valentine’s Day is on the horizon! So whether you’re partnered up or celebrating with friends, here are some fun <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/best-horror-movies-streaming-february-2024-sci-fi-genre-1851209283">fandom picks</a> for gift-giving and beyond.Celebrate with ideas inspired by Lore Olympus, Shrek, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/daisy-ridley-reylo-kiss-star-wars-rise-of-skywalker-1851205699">Star Wars</a>, Studio Ghibli, and more pop culture that evokes the bonds of both romantic and platonic…</p><p><a href="https://gizmodo.com/valentines-day-nerdy-gift-guide-disney-star-wars-shrek-1851218684">Read more...</a></p>

## NASA’s Next-Generation ISS Spacesuit Passes Zero-Gravity Test
 - [https://gizmodo.com/nasa-s-next-generation-iss-spacesuit-passes-zero-gravit-1851220352](https://gizmodo.com/nasa-s-next-generation-iss-spacesuit-passes-zero-gravit-1851220352)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T20:17:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4b1cae8ad06d4ab34aab0fcfc9f4e306.jpg" /><p>NASA’s current batch of ISS spacesuits are getting long in the tooth, having been in service for over four decades. The space agency is keen to acquire spacesuits fit for the 21st century, and recent zero-gravity tests performed by Collins Aerospace are a step in the right direction.<br /></p><p><a href="https://gizmodo.com/nasa-s-next-generation-iss-spacesuit-passes-zero-gravit-1851220352">Read more...</a></p>

## The AI Industry Has a Not So Secret Weapon: Lobbyists
 - [https://gizmodo.com/the-ai-industry-has-a-not-so-secret-weapon-lobbyists-1851218837](https://gizmodo.com/the-ai-industry-has-a-not-so-secret-weapon-lobbyists-1851218837)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/8610af33f4d4dbc54500f9e950a1a938.jpg" /><p>A <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.cnbc.com/2024/02/02/ai-lobbying-spikes-nearly-200percent-as-calls-for-regulation-surge.html" rel="noopener noreferrer" target="_blank">new report</a> from CNBC shows that lobbyists connected to the AI industry were quite busy last year. Indeed, in 2023, AI lobbying efforts  shot up 185 percent from the previous year. The analysis, which is based on disclosures provided to the non-profit OpenSecrets, shows that the long list of companies that tried to…</p><p><a href="https://gizmodo.com/the-ai-industry-has-a-not-so-secret-weapon-lobbyists-1851218837">Read more...</a></p>

## Tesla Recalling Almost Every Car It's Sold In The US
 - [https://gizmodo.com/tesla-recalling-almost-every-car-its-sold-in-the-us-1851221497](https://gizmodo.com/tesla-recalling-almost-every-car-its-sold-in-the-us-1851221497)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T19:56:59+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/12b3ea5c0fa987b4e608ada5b1bf2f16.jpg" /><p>Tesla has <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://jalopnik.com/tesla-recalls-millions-of-vehicles-over-autopilot-safet-1851095340">issued a recall</a> for almost every car it sold in the U.S. because of illegible warning lights. The massive recall <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://jalopnik.com/tesla-squeezes-in-one-more-recall-before-the-end-of-202-1851123954">affects more than 2 million cars</a> and follows a similarly huge recall that hit almost every <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://jalopnik.com/tesla-recalls-1-6-million-cars-in-china-over-autopilot-1851143066">car Tesla has sold in China</a>.<br /></p><p><a href="https://gizmodo.com/tesla-recalling-almost-every-car-its-sold-in-the-us-1851221497">Read more...</a></p>

## Star Wars, Predator, and Rocky Star Carl Weathers Has Died
 - [https://gizmodo.com/carl-weathers-star-wars-predator-rocky-star-dead-at-76-1851221423](https://gizmodo.com/carl-weathers-star-wars-predator-rocky-star-dead-at-76-1851221423)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T19:46:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/2fe7d87bdd38ee63702576712899127e.jpg" /><p>It’s a sad day in the galaxy far, far away: Carl Weathers, who brought a gruff dignity (with a hint of mischief) to his role as <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/the-mandalorian-cast-has-officially-been-announced-1831051252">The Mandalorian’s Greef Karga</a>, has died at the age of 76. Weathers was also much-beloved for his portrayals of Apollo Creed in the Rocky films and Col. Al Dillon—opposite <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/arnold-schwarzenegger-terminator-return-t2-dark-fate-t3-1850442299">Arnold Schwarzenegger</a></p><p><a href="https://gizmodo.com/carl-weathers-star-wars-predator-rocky-star-dead-at-76-1851221423">Read more...</a></p>

## True Detective: Night Country's Chilling First Episode Is Streaming Free on YouTube
 - [https://gizmodo.com/true-detective-night-country-first-episode-free-youtube-1851220608](https://gizmodo.com/true-detective-night-country-first-episode-free-youtube-1851220608)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/22cafd754c920c600c72758d2a5b3d3c.jpg" /><p>If you’ve been curious about True Detective: Night Country, but don’t have an HBO or Max subscription, prepare to be further tempted: episode one is now streaming free on YouTube. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/issa-lopez-on-the-horrors-of-tigers-are-not-afraid-her-1837182376">Writer-director Issa López</a>’s (<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/tigers-are-not-afraid-is-the-best-guillermo-del-toro-mo-1818852207">Tigers Are Not Afraid</a>) new installment of the anthology series is an Alaska-set tale that tips its fur-lined…</p><p><a href="https://gizmodo.com/true-detective-night-country-first-episode-free-youtube-1851220608">Read more...</a></p>

## Banning Private Jets and Going to a 4-Day Work Week Are Radical—and Popular
 - [https://gizmodo.com/banning-private-jets-and-going-to-a-4-day-work-week-are-1851221050](https://gizmodo.com/banning-private-jets-and-going-to-a-4-day-work-week-are-1851221050)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T18:27:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/6e6552e124397b65dcf874b1f4d51048.jpg" /><p>This story was originally published by <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://grist.org" rel="noopener noreferrer" target="_blank">Grist</a>. Sign up for Grist’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://go.grist.org/signup/weekly/partner?utm_campaign=republish-content&amp;utm_medium=syndication&amp;utm_source=partner" rel="noopener noreferrer" target="_blank">weekly newsletter here</a>.<br /></p><p><a href="https://gizmodo.com/banning-private-jets-and-going-to-a-4-day-work-week-are-1851221050">Read more...</a></p>

## Tim Cook Teases Big AI Announcement for Apple Later This Year
 - [https://gizmodo.com/tim-cook-apple-ai-announcement-wwdc-1851220219](https://gizmodo.com/tim-cook-apple-ai-announcement-wwdc-1851220219)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T18:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/9554b1fc588b084f972d3c84fb3251cf.jpg" /><p>I’m pretty sure we all saw this coming. Why would Apple, out of all companies, not participate in, as Gizmodo reporter Kyle Barr puts it, the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/microsoft-edge-ai-browser-windows-1851135866">AI-ification of everything</a>? During an earnings call, Apple CEO Tim Cook said he thinks there is a “huge opportunity for Apple with generative AI and AI,” hinting that the…</p><p><a href="https://gizmodo.com/tim-cook-apple-ai-announcement-wwdc-1851220219">Read more...</a></p>

## Sonic the Hedgehog 3 Just Got a Major Update and a First Teaser
 - [https://gizmodo.com/sonic-3-teaser-jim-carrey-robotnik-shadow-the-hedgehog-1851220552](https://gizmodo.com/sonic-3-teaser-jim-carrey-robotnik-shadow-the-hedgehog-1851220552)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/fc6d595ead2ec7046ab1b72821aab9d5.jpg" /><p>Before <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/super-mario-movie-review-nintendo-illumination-luigi-pe-1850285728">The Super Mario Bros. Movie</a> was a global sensation, Sonic the Hedgehog had already done it twice. The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/my-favorite-part-of-the-sonic-movie-actually-had-very-l-1841771435">first two Sonic movies grossed</a> almost $900 million globally so, of course, a third one is on the way. But will the main villain return? The answer is yes.</p><p><a href="https://gizmodo.com/sonic-3-teaser-jim-carrey-robotnik-shadow-the-hedgehog-1851220552">Read more...</a></p>

## NASA Needs Ideas to Study Potentially Hazardous Asteroid Apophis
 - [https://gizmodo.com/nasa-apophis-potentially-hazardous-asteroid-janus-probe-1851217709](https://gizmodo.com/nasa-apophis-potentially-hazardous-asteroid-janus-probe-1851217709)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/3305d905b0b4bdc681db8209f6545e14.jpg" /><p>Asteroid 99942 Apophis is fast approaching our home planet for an uncomfortably close encounter in 2029. In order to prepare for the rare event, NASA is calling for ideas for low cost missions to rendezvous with Apophis, but the space agency already has a pair of asteroid probes ready to take on the task.<br /></p><p><a href="https://gizmodo.com/nasa-apophis-potentially-hazardous-asteroid-janus-probe-1851217709">Read more...</a></p>

## Meta Quest 3 Steals the Apple Vision Pro's Thunder by Adding Spatial Video Support
 - [https://gizmodo.com/meta-quest-3-spatial-video-apple-vision-pro-vr-1851220481](https://gizmodo.com/meta-quest-3-spatial-video-apple-vision-pro-vr-1851220481)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T17:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4f604ca75ed2284741e12512615e6c21.jpg" /><p>Meta’s official <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/mark-zuckerberg-meta-earnings-congress-child-harm-1851219577">mother-in-chief, Mark Zuckerberg</a>, swung his head toward the minivan’s back seat to tell all his Apple-obsessed Meta Quest 3 customers, “<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/apple-vision-pro-pricing-release-date-specs-1851205316">We have Vision Pro at home</a>.” The company is planning to facilitate Apple’s own “spatial video” within the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/hands-on-meta-quest-3-is-the-apple-vision-pro-for-the-1850928775">Meta Quest 3</a> in hopes that even more augmented reality…</p><p><a href="https://gizmodo.com/meta-quest-3-spatial-video-apple-vision-pro-vr-1851220481

## This is the Coolest Galaxy S24 AI Feature That Few Are Talking About
 - [https://gizmodo.com/this-is-the-coolest-galaxy-s24-ai-feature-that-few-are-1851220470](https://gizmodo.com/this-is-the-coolest-galaxy-s24-ai-feature-that-few-are-1851220470)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T17:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/75ffb4c42950d66c585ccabed9eebc7d.jpg" /><p><a href="https://gizmodo.com/this-is-the-coolest-galaxy-s24-ai-feature-that-few-are-1851220470">Read more...</a></p>

## Google Has Officially Killed Cache Links
 - [https://gizmodo.com/google-has-officially-killed-cache-links-1851220408](https://gizmodo.com/google-has-officially-killed-cache-links-1851220408)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/59d820a68c778f791aa891d387d22725.jpg" /><p>25 years ago, the internet was kludged together with duct tape and a dream. Sometimes typing in a URL brought up a website. Sometimes things were just broken. Google, then just a bizarrely named startup, would soon offer a solution. The company added “cache” links to its search results, which brought up a previously…</p><p><a href="https://gizmodo.com/google-has-officially-killed-cache-links-1851220408">Read more...</a></p>

## Tim Burton Will Direct Gillian Flynn-Penned Attack of the 50 Foot Woman
 - [https://gizmodo.com/morning-spoilers-tim-burton-taika-waititi-daredevil-1851216288](https://gizmodo.com/morning-spoilers-tim-burton-taika-waititi-daredevil-1851216288)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4e3e1db8c4ef20d5e4625f9634c62f46.png" /><p>Netflix has a teaser for Family Pack, the board game-based film starring Jean Reno. Taika Waititi is adapting Kazuo Ishiguro’s novelKlara and the Sun with Jenna Ortega and Amy Adams set to star, and there’s a new poster for murderous teddy bear movie Imaginary. It’s spoilerin’ time!</p><p><a href="https://gizmodo.com/morning-spoilers-tim-burton-taika-waititi-daredevil-1851216288">Read more...</a></p>

## Star Trek's John de Lancie Says That Picard Post-Credits Scene Could Have Signaled a Spin-Off
 - [https://gizmodo.com/star-trek-picard-john-de-lancie-q-spin-off-potential-1851218611](https://gizmodo.com/star-trek-picard-john-de-lancie-q-spin-off-potential-1851218611)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/ec866da8b4cdc1543d2a46b023fb0784.jpg" /><p>Prolific actor John de Lancie—currently voicing Granamyr on Netflix’s Masters of the Universe: Revolution—<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/star-trek-star-wars-de-aging-vfx-picard-luke-skywalker-1848624587">will always be Q</a> <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/the-a-to-z-of-star-treks-q-1846685232">to Star Trek fans</a>, who welcomed <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/star-trek-picard-easter-egg-q-phone-number-1848737355">the delightfully antagonistic character</a>’s return on <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/john-de-lancie-will-return-as-q-in-star-trek-picard-se-1846621828">Star Trek: Picard</a>. In a new interview, he gave some insight into t

## Alien-Looking Fossil Trees Uncovered in Canada: 'Unlike Any of Those That Live at the Present'
 - [https://gizmodo.com/alien-looking-fossil-trees-uncovered-in-canada-unlike-1851218709](https://gizmodo.com/alien-looking-fossil-trees-uncovered-in-canada-unlike-1851218709)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T16:21:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/5fdabbd19e0a658e88825dd34ebd5905.png" /><p>You won’t be-leaf the shape of this ancient tree. A team of researchers found a 350-million-year-old fossilized tree species that looks like something out of Dr. Seuss.<br /></p><p><a href="https://gizmodo.com/alien-looking-fossil-trees-uncovered-in-canada-unlike-1851218709">Read more...</a></p>

## Nintendo Turned Gary Bowser Into a Real-Life Villain
 - [https://gizmodo.com/how-nintendo-turned-gary-bowser-into-real-life-villain-1851220075](https://gizmodo.com/how-nintendo-turned-gary-bowser-into-real-life-villain-1851220075)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T15:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a9be3c9f9394e233616aa5e08518460e.jpg" /><p>Gary Bowser loves video games, but <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/nintendo-switch-2-8inch-display-lcd-console-1851200285">Nintendo</a> turned him into a villain. No, not just because he shares a name with Bowser, the actual villain of the Mario franchise. The human <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/nintendo-hacker-gary-bowser-soon-to-be-released-prison-1850344573">Bowser helped mod Nintendo’s gaming consoles</a> so people could play free, pirated versions of its video games. Then one day, he woke up with three…</p><p><a href="https://gizmodo.com/how-nintendo-turned-gary-bowser-into-real-life-villain-1851220075">Read more...</a></p>

## Dying Moon Lander Sends Back Final Image Before the Long Lunar Night
 - [https://gizmodo.com/japan-slim-moon-lander-last-image-lunar-night-1851219866](https://gizmodo.com/japan-slim-moon-lander-last-image-lunar-night-1851219866)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/71b4f5d90c345e8ae8625d98ebd347d1.png" /><p>Japan’s SLIM, the Smart Lander for Investigation Moon, has entered a dormant mode on the Moon’s Shioli Crater, facing a 14-day lunar night with temperatures dropping below -200 degrees Fahrenheit.<br /></p><p><a href="https://gizmodo.com/japan-slim-moon-lander-last-image-lunar-night-1851219866">Read more...</a></p>

## Arc’s New AI Browser Features Are an Act of War Against Google Search
 - [https://gizmodo.com/arc-ai-browser-google-search-new-features-instant-links-1851219967](https://gizmodo.com/arc-ai-browser-google-search-new-features-instant-links-1851219967)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T15:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e7038b3e94b7ed0df0bd3e06e6cf4a47.png" /><p>The Browser Company makes no effort to hide its gleeful disdain for the reigning King of Search, also known as Google. It is openly taking aim at the tech giant’s advertising business with new features for <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/arc-search-iphone-ai-browser-safari-1851209004">Arc, its AI-powered web browser</a>. </p><p><a href="https://gizmodo.com/arc-ai-browser-google-search-new-features-instant-links-1851219967">Read more...</a></p>

## Bitcoin Wears a Patagonia Vest Now, but Is It Still Crypto?
 - [https://gizmodo.com/bitcoin-wears-patagonia-vest-now-is-it-still-crypto-1851216868](https://gizmodo.com/bitcoin-wears-patagonia-vest-now-is-it-still-crypto-1851216868)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/5cf152d4aa3e03d74ce08b74ea03e1a3.png" /><p>Cryptocurrency cleaned up its act this week as spot Bitcoin ETFs made their Wall Street debut in January. The digital tokens are looking almost unrecognizable from what the industry represented just a few years ago, leading to the question, is Bitcoin still crypto?<br /></p><p><a href="https://gizmodo.com/bitcoin-wears-patagonia-vest-now-is-it-still-crypto-1851216868">Read more...</a></p>

## Who Else Remembers the Great Ape Escape of 2019?
 - [https://gizmodo.com/who-else-remembers-the-great-ape-escape-of-2019-1851198647](https://gizmodo.com/who-else-remembers-the-great-ape-escape-of-2019-1851198647)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T12:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/649ff050618c75d05273d3ffd93b8de2.jpg" /><p>Welcome to another installment of Gizmodo’s Animal Crime of the Week, an exploration of animals and their <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/trash-stealing-cockatoos-parrots-australia-1851179761">mischievous</a> <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/heres-why-you-shouldnt-mess-with-a-wild-iguana-that-wan-1851197132">behavior</a>. Let’s talk about the Great Ape Escape of 2019, when a band of chimpanzees at the Belfast Zoo in Northern Ireland brazenly scampered to the edge of freedom.<br /></p><p><a href="https://gizmodo.com/who-else-remembers-the-great-ape-escape-of-2019-1851198647">Read more...</a></p>

## Mark Zuckerberg Is Feeling Himself
 - [https://gizmodo.com/mark-zuckerberg-meta-earnings-congress-child-harm-1851219577](https://gizmodo.com/mark-zuckerberg-meta-earnings-congress-child-harm-1851219577)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-02T12:09:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/828a327d582be33833cad4fd9ecbd73a.png" /><p>Meta CEO Mark Zuckerberg is feeling pretty philosophical about his roller coaster of a week, which saw him berated by Congress over the harmful content on his products one day and celebrated by investors for delivering buckets of dough the next.</p><p><a href="https://gizmodo.com/mark-zuckerberg-meta-earnings-congress-child-harm-1851219577">Read more...</a></p>

