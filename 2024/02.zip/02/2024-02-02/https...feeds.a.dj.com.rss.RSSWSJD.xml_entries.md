# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## The People Buying the $3,500 Apple Vision Pro
 - [https://www.wsj.com/articles/apple-vision-pro-headset-launches-e19bca6c?mod=rss_Technology](https://www.wsj.com/articles/apple-vision-pro-headset-launches-e19bca6c?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-02-02T22:45:00+00:00

A crowd of mostly die-hard Apple fans waited outside the Fifth Avenue store in New York, looking to be among the first to get their hands on the company’s new virtual-reality headset.

## Tesla to Recall More Than Two Million Vehicles for Software Fix
 - [https://www.wsj.com/articles/tesla-to-recall-more-than-two-million-vehicles-for-software-fix-a5fb3626?mod=rss_Technology](https://www.wsj.com/articles/tesla-to-recall-more-than-two-million-vehicles-for-software-fix-a5fb3626?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2024-02-02T11:51:00+00:00

The affected vehicles will receive an over-the-air software remedy, Tesla said, the latest in a series of setbacks to hit the automaker.

