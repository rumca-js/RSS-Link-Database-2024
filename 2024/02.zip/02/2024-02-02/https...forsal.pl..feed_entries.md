# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Andrzej Duda o Donaldzie Tusku i Jarosławie Kaczyńskim: Myślę, że mnie nie lubią
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423779,andrzej-duda-o-donaldzie-tusku-i-jaroslawie-kaczynskim-mysle-ze-mnie-nie-lubia.html](https://forsal.pl/gospodarka/polityka/artykuly/9423779,andrzej-duda-o-donaldzie-tusku-i-jaroslawie-kaczynskim-mysle-ze-mnie-nie-lubia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T22:57:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vjYktkuTURBXy9iM2RiMWZiMS1mNzU2LTQ4ZGItOTcxNC1jNDk0ZjEwZTgzYmQuanBlZ5GTBc0BHcyg" />Andrzej Duda w wywiadzie na Kanale Zero opowiedział o relacji z Jarosławem Kaczyńskim i Donaldem Tuskiem. „Nie lubią, jak ktokolwiek im się sprzeciwia” – zaznaczył prezydent.

## Początek odwetu. USA rozpoczęły uderzenia na związane z Iranem cele w Syrii i Iraku
 - [https://forsal.pl/swiat/usa/artykuly/9423772,poczatek-odwetu-usa-rozpoczely-uderzenia-na-zwiazane-z-iranem-cele-w-syrii-i-iraku.html](https://forsal.pl/swiat/usa/artykuly/9423772,poczatek-odwetu-usa-rozpoczely-uderzenia-na-zwiazane-z-iranem-cele-w-syrii-i-iraku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T21:29:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/S_lktkuTURBXy9mZWJiYzc5OS1mNTdjLTRlYjEtYTNmMy0xNGUxMGNjYmU4MGUuanBlZ5GTBc0BHcyg" />Siły USA rozpoczęły w piątek uderzenia na związane z Iranem cele w Syrii i Iraku - podały amerykańskie media, powołując się na przedstawicieli Pentagonu. Jest to początek odwetu USA za zabicie przez wspierane przez Teheran bojówki trojga amerykańskich żołnierzy w bazie w Jordanii.

## "Washington Post": Władze Ukrainy poinformowały Biały Dom o zamiarze zwolnienia Załużnego
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9423770,washington-post-wladze-ukrainy-poinformowaly-bialy-dom-o-zamiarze-zwolnienia-zaluznego.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9423770,washington-post-wladze-ukrainy-poinformowaly-bialy-dom-o-zamiarze-zwolnienia-zaluznego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T21:14:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gH1ktkuTURBXy8yZTlhYzExMS0wNDU2LTQ0YmEtOTdjOS01YmQ2M2NhZDVkM2MuanBlZ5GTBc0BHcyg" />Ukraińskie władze poinformowały Biały Dom o zamiarze zwolnienia naczelnego dowódcy Sił Zbrojnych Ukrainy gen. Wałerija Załużnego - donosi w piątek &quot;Washington Post&quot;. Waszyngton miał - według gazety - powstrzymać się od prób wpływania na decyzję prezydenta Wołodymyra Zełenskiego.

## Duda o Trumpie: On uważa, że Ameryka powinna być imperium
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423769,duda-o-trumpie-on-uwaza-ze-ameryka-powinna-byc-imperium.html](https://forsal.pl/gospodarka/polityka/artykuly/9423769,duda-o-trumpie-on-uwaza-ze-ameryka-powinna-byc-imperium.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T21:10:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/V6SktkuTURBXy84MTVmZTg0Mi0wYjlhLTQzNDMtOWJjNy0yYzFkYTM1MDIzOGMuanBlZ5GTBc0BHcyg" />Nie wierzę w to, by Rosja odważyła się zaatakować państwo NATO, zwłaszcza takie, które ma silny potencjał militarny, silną obronę rakietową, która ma liczną i dobrze wyposażoną armię, i chcę, żeby Polska takim państwem NATO się stała - powiedział w piątek prezydent Andrzej Duda.

## Rosyjskie służby poprzez posła AfD usiłowały sabotować pomoc dla Ukrainy
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9423766,rosyjskie-sluzby-poprzez-posla-afd-usilowaly-sabotowac-pomoc-dla-ukrainy.html](https://forsal.pl/swiat/aktualnosci/artykuly/9423766,rosyjskie-sluzby-poprzez-posla-afd-usilowaly-sabotowac-pomoc-dla-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T20:49:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2D0ktkuTURBXy8zNGFiNjIxMS1lMzg0LTQyNGUtOWNmYS03ZmEzZmRlNTRlMjAuanBlZ5GTBc0BHcyg" />Pracownik parlamentarzysty AfD Eugena Schmidta, Władimir Sergijenko, był powiązany z rosyjskim wywiadem FSB i rozmawiał o możliwym sabotowaniu niemieckiej pomocy dla Ukrainy z „osobą kontaktową w Rosji” – ustalił portal „Spiegel”.

## Reset konstytucyjny? Andrzej Duda: Jestem gotowy, proszę przyjść z konkretnymi propozycjami
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423764,reset-konstytucyjny-andrzej-duda-jestem-gotowy-prosze-przyjsc-z-konkretnymi-propozycjami.html](https://forsal.pl/gospodarka/polityka/artykuly/9423764,reset-konstytucyjny-andrzej-duda-jestem-gotowy-prosze-przyjsc-z-konkretnymi-propozycjami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T20:29:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yAJktkuTURBXy9jZThjMGMyOS1lNjE3LTQyNDYtYjlmNy0wOTMyYWU0MjBlNGIuanBlZ5GTBc0BHcyg" />Jestem gotowy na rozmowę o &quot;resecie konstytucyjnym&quot;, proszę przyjść z konkretnymi propozycjami. Porozmawiajmy. Są problemy, które w inny sposób są de facto nierozwiązywalne - powiedział prezydent Andrzej Duda w piątek w wywiadzie na Kanale Zero.

## Rada nadzorcza Orlenu. Skarb Państwa i Nationale-Nederlanden OFE zgłosili kandydatów
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9423762,rada-nadzorcza-orlenu-skarb-panstwa-i-nationale-nederlanden-ofe-zglosili-kandydatow.html](https://forsal.pl/biznes/aktualnosci/artykuly/9423762,rada-nadzorcza-orlenu-skarb-panstwa-i-nationale-nederlanden-ofe-zglosili-kandydatow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T20:04:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fkuktkuTURBXy85YjYxZDg1Mi04ZTNkLTRkZWMtOWQ5OS1mNzU1MDA1ZDAyY2EuanBlZ5GTBc0BHcyg" />Skarb Państwa i Nationale-Nederlanden OFE zgłosili kandydatów do rady nadzorczej Orlenu - poinformowała w piątek spółka w komunikacie

## Orlen: Michał Róg złożył rezygnację z funkcji członka zarządu spółki
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9423758,orlen-michal-rog-zlozyl-rezygnacje-z-funkcji-czlonka-zarzadu-spolki.html](https://forsal.pl/biznes/aktualnosci/artykuly/9423758,orlen-michal-rog-zlozyl-rezygnacje-z-funkcji-czlonka-zarzadu-spolki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T19:44:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gbGktkuTURBXy9hOTgzY2NhZi0yNGI5LTRjOTktODlkOC05ODI2ZWMxODNjN2MuanBlZ5GTBc0BHcyg" />Michał Róg złożył rezygnację z funkcji członka zarządu spółki - poinformował w piątek Orlen w komunikacie.

## Donald Trump wygra wybory w USA? "Foreign Affairs": Europa musi stać się "Trumpo-odporna"
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9423757,donald-trump-wygra-wybory-w-usa-foreign-affairs-europa-musi-stac-sie-trumpo-odporna.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9423757,donald-trump-wygra-wybory-w-usa-foreign-affairs-europa-musi-stac-sie-trumpo-odporna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T19:38:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_-QktkuTURBXy82YzM0ZjhmNC0xNTVlLTRhNzQtYmIyYi1kMzBkODUxMjUxMjMuanBlZ5GTBc0BHcyg" />Powrót Donalda Trumpa do Białego Domu oznaczałby dla UE ograniczenie bezpieczeństwa gospodarczego i bezpieczeństwa w ogóle, byłby też zagrożeniem dla spójności Unii - ocenia magazyn &quot;Foreign Affaires&quot; w tekście pt. &quot;Trumpo-odporność Europy&quot;.

## ZUS. Kto stanie na czele Zakładu Ubezpieczeń Społecznych?
 - [https://forsal.pl/gospodarka/prawo/artykuly/9423755,zus-kto-stanie-na-czele-zakladu-ubezpieczen-spolecznych.html](https://forsal.pl/gospodarka/prawo/artykuly/9423755,zus-kto-stanie-na-czele-zakladu-ubezpieczen-spolecznych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T19:29:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/I2iktkuTURBXy85MTE1YmI4NS01ZGVlLTQ2OGUtYWI1YS02MjUzOWRmNWI4MDEuanBlZ5GTBc0BHcyg" />Myślę, że jeszcze w lutym powinniśmy znać osobę, która stanie na czele Zakładu Ubezpieczeń Społecznych - powiedziała w piątek ministra rodziny, pracy i polityki społecznej Agnieszka Dziemianowicz-Bąk. Podała, że procedura już została rozpoczęta.

## Makejew: Niemcy odgrywają wiodącą rolę we wspieraniu Ukrainy
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9423751,makejew-niemcy-odgrywaja-wiodaca-role-we-wspieraniu-ukrainy.html](https://forsal.pl/swiat/aktualnosci/artykuly/9423751,makejew-niemcy-odgrywaja-wiodaca-role-we-wspieraniu-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T18:45:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1ddktkuTURBXy9jMDBjZDdjOS05MWEwLTQ1NzQtOGE2Mi0wZTE3NDc2OTk4OWUuanBlZ5GTBc0BHcyg" />Po decyzji UE o udzieleniu Ukrainie pomocy finansowej w wysokości 50 miliardów euro ambasador Ukrainy w Niemczech Ołeksij Makejew pochwalił niemiecki rząd i kanclerza Olafa Scholza. Niemcy odgrywają &quot;wiodącą rolę&quot; we wspieraniu Ukrainy w Europie, stwierdził dyplomata.

## Rzeszów. Zarejestrowano pierwszy komitet wyborczy
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423750,rzeszow-zarejestrowano-pierwszy-komitet-wyborczy.html](https://forsal.pl/gospodarka/polityka/artykuly/9423750,rzeszow-zarejestrowano-pierwszy-komitet-wyborczy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T18:42:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/amLktkuTURBXy81MjRmZGNiMy0wMmNhLTQ2YTMtOGUyOC03MzA0YzE2OTdjYTkuanBlZ5GTBc0BHcyg" />W rzeszowskiej delegaturze Krajowego Biura Wyborczego zarejestrował się pierwszy komitet wyborczy: obecnie urzędującego prezydenta Rzeszowa Konrada Fijołka.

## Ustawa o pomocy Ukrainie i reformy imigracyjne. Murphy: Mamy porozumienie w Senacie
 - [https://forsal.pl/swiat/usa/artykuly/9423747,ustawa-o-pomocy-ukrainie-i-reformy-imigracyjne-murphy-mamy-porozumienie-w-senacie.html](https://forsal.pl/swiat/usa/artykuly/9423747,ustawa-o-pomocy-ukrainie-i-reformy-imigracyjne-murphy-mamy-porozumienie-w-senacie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T18:23:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PrPktkuTURBXy9hZGY4OGI2Yy1jZjc1LTRlYjYtOGJlMy1lZWRjYWFhM2Y3YTkuanBlZ5GTBc0BHcyg" />Główny negocjator demokratów senator Chris Murphy ogłosił w piątek, że obie partie w Senacie zawarły porozumienie w sprawie projektu ustawy łączącego środki na pomoc Ukrainie z reformami imigracyjnymi. Tekst projektu ma zostać opublikowany w weekend, zaś głosowanie odbędzie się w przyszłym tygodniu. Sukces nie jest jednak pewny ze względu na możliwe odrzucenie projektu przez Izbę Reprezentantów

## Sikorski do Blinkena: Powodzenia w pilnej misji na Bliskim Wschodzie
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423742,sikorski-do-blinkena-powodzenia-w-pilnej-misji-na-bliskim-wschodzie.html](https://forsal.pl/gospodarka/polityka/artykuly/9423742,sikorski-do-blinkena-powodzenia-w-pilnej-misji-na-bliskim-wschodzie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T17:57:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1KIktkuTURBXy85MTkyZDcyZC05MmNhLTQ4MjEtOGJjZi1jNTU0MTAyN2U0MTYuanBlZ5GTBc0BHcyg" />Powodzenia w pilnej misji na Bliskim Wschodzie w przyszłym tygodniu - napisał w piątek szef MSZ Radosław Sikorski zwracając się do sekretarza stanu USA Antonego Blinkena. Mam nadzieję, że spotkamy się w Waszyngtonie, gdy sytuacja się uspokoi - dodał.

## Chirurg onkologiczny: Liczba nowotworów złośliwych rośnie
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9423741,chirurg-onkologiczny-liczba-nowotworow-zlosliwych-rosnie.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9423741,chirurg-onkologiczny-liczba-nowotworow-zlosliwych-rosnie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T17:44:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SnJktkuTURBXy9kMDY3MTJhNy1kNjUxLTQ1NTItYjZiMy04NGMyZTg1M2FlOTMuanBlZ5GTBc0BHcyg" />Liczba nowotworów złośliwych tylko rośnie, więc potrzeby będą jeszcze większe - powiedział w piątek kierownik Kliniki Chirurgii Onkologicznej USK1 w Lublinie prof. dr hab. n. med. Wojciech Polkowski. Jego zdaniem, w leczeniu części chorób onkologicznych zauważyć można istotne postępy.

## Nowa forma oszustwa w sieci. Policja ostrzega. 27-latek stracił ponad 20 tys. zł
 - [https://forsal.pl/praca/aktualnosci/artykuly/9423740,nowa-forma-oszustwa-w-sieci-policja-ostrzega-27-latek-stracil-ponad-20-tys-zl.html](https://forsal.pl/praca/aktualnosci/artykuly/9423740,nowa-forma-oszustwa-w-sieci-policja-ostrzega-27-latek-stracil-ponad-20-tys-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T17:30:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bmektkuTURBXy9hN2FlOWZjYy0wNjE4LTQyYTgtYjEyNS00NGZjYWVjNjMwNGQuanBlZ5GTBc0BHcyg" />Gdańszczanin zatrudnił się w wirtualnym biurze i na zlecenie oszustów wykonywał prace w sieci. Pokrzywdzony widział zyski na swoim wirtualnym portfelu, ale aby otrzymywać kolejne zlecenia, musiał realizować prawdziwe przelewy. Stracił ponad 20 tys. zł.

## Sprawa Grety Thunberg. Jest wyrok sądu
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9423736,sprawa-grety-thunberg-jest-wyrok-sadu.html](https://forsal.pl/swiat/aktualnosci/artykuly/9423736,sprawa-grety-thunberg-jest-wyrok-sadu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T17:23:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/R_2ktkuTURBXy9mYWY2YTZjMy01YzI0LTQ1ZTAtODVhMS1lOTQ3YjliOTYwOGMuanBlZ5GTBc0BHcyg" />Szwedzka aktywistka klimatyczna Greta Thunberg została w piątek oczyszczona przez sąd w Londynie z zarzutu naruszenia porządku publicznego w związku z protestem przed konferencją naftowo-gazową w ubiegłym roku.

## Adam Bodnar odwołał Kamila Zaradkiewicza z funkcji dyrektora KSSiP
 - [https://forsal.pl/gospodarka/prawo/artykuly/9423733,adam-bodnar-odwolal-kamila-zaradkiewicza-z-funkcji-dyrektora-kssip.html](https://forsal.pl/gospodarka/prawo/artykuly/9423733,adam-bodnar-odwolal-kamila-zaradkiewicza-z-funkcji-dyrektora-kssip.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T17:11:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CWIktkuTURBXy85MGM2NTU0MC05MzhkLTQ5NzUtOTA1Zi03MWFiZDMwYjgzYTUuanBlZ5GTBc0BHcyg" />Minister sprawiedliwości Adam Bodnar odwołał w piątek sędziego Kamila Zaradkiewicza z funkcji dyrektora Krajowej Szkoły Sądownictwa i Prokuratury. Na p.o. dyrektora powołał sędziego Ryszarda Sadlika - poinformowało MS. W przyszłym tygodniu będzie ogłoszony konkurs na nowego szefa KSSiP.

## 74-latek wrzucił do morza ok. 900 kg ulotek, które miał rozdawać
 - [https://forsal.pl/praca/artykuly/9423732,74-latek-wrzucil-do-morza-ok-900-kg-ulotek-ktore-mial-rozdawac.html](https://forsal.pl/praca/artykuly/9423732,74-latek-wrzucil-do-morza-ok-900-kg-ulotek-ktore-mial-rozdawac.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T17:06:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HlektkuTURBXy84NWQ3Y2QwMS0xNjIyLTRjNjItYTJjZC1jYzQ4ZGFhOGZmMWUuanBlZ5GTBc0BHcyg" />Biuro Straży Przybrzeżnej w Moji zatrzymało 74-latka pod zarzutem wyrzucenia ok. 900 kg ulotek reklamowych do cieśniny Kanmon w zachodniej Japonii – podał w piątek portal Mainichi.

## Reparacji nie będzie. Jak Niemcy mogą zadośćuczynić za straty wojenne?
 - [https://forsal.pl/gospodarka/polityka/artykuly/9422614,reparacje-wojenne-niemcy-polska-jakie-kiedy.html](https://forsal.pl/gospodarka/polityka/artykuly/9422614,reparacje-wojenne-niemcy-polska-jakie-kiedy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T16:53:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Jc3ktktTURBXy9kZjY0OGFjNy0zNTY4LTRiYTktOGQ0MC0wMGNjMWE4NjNmNDcucG5nkZMFzQEdzKA" />O tym, że temat reparacji dla Berlina jest zamknięty, przedstawiciele niemieckiego rządu mówili już wielokrotnie. W takim tonie była utrzymana m.in. odpowiedź na polską notę dyplomatyczną dotyczącą odszkodowań za straty poniesione w czasie II Wojny Światowej.

## Co dalej z KSeF? Ministerstwo Finansów podaje termin
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9423724,co-dalej-z-ksef-ministerstwo-finansow-podaje-termin.html](https://forsal.pl/finanse/aktualnosci/artykuly/9423724,co-dalej-z-ksef-ministerstwo-finansow-podaje-termin.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T16:29:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/B6rktkuTURBXy8xNjQ0ZDIyYS1mZTYyLTQwNmItODUzMi00NmFkYjM1NmJlMDkuanBlZ5GTBc0BHcyg" />undefined

## Praca w Polsce. Oto zawody, na które będzie szczególne zapotrzebowanie [LISTA]
 - [https://forsal.pl/praca/aktualnosci/artykuly/9423720,praca-w-polsce-oto-zawody-na-ktore-bedzie-szczegolne-zapotrzebowanie-lista.html](https://forsal.pl/praca/aktualnosci/artykuly/9423720,praca-w-polsce-oto-zawody-na-ktore-bedzie-szczegolne-zapotrzebowanie-lista.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T16:20:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/z3JktkuTURBXy83Y2IzOWUwMi02ZGU3LTQ3MmItYmUyOC03N2RkNTVlMzk4MGMuanBlZ5GTBc0BHcyg" />34 pozycje znalazły się na nowej liście zawodów, dla których jest prognozowane szczególne zapotrzebowanie na krajowym rynku pracy. Wśród nich jest jeden nowy: technik elektromobilności – podało w piątek Ministerstwo Edukacji Narodowej.

## Pesa wjeżdża do Afryki. Pierwszy pociąg dla Ghany już gotowy
 - [https://forsal.pl/transport/kolej/artykuly/9423708,pesa-wjezdza-do-afryki-pierwszy-pociag-dla-ghany-juz-gotowy.html](https://forsal.pl/transport/kolej/artykuly/9423708,pesa-wjezdza-do-afryki-pierwszy-pociag-dla-ghany-juz-gotowy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T15:55:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Oh4ktkuTURBXy9kZTdlNmU2My1lODUyLTRiNzUtYWI5NS0xODExM2ZiZTFjMGUuanBlZ5GTBc0BHcyg" />Bydgoski producent zaprezentował pierwszy skład wyprodukowany dla kolei w Ghanie. Podpisana przez Pesę umowa ramowa zakłada dostawę do 12 pojazdów.

## Niemiecki Bundestag zatwierdził budżet na bieżący rok
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9423701,niemiecki-bundestag-zatwierdzil-budzet-na-biezacy-rok.html](https://forsal.pl/finanse/aktualnosci/artykuly/9423701,niemiecki-bundestag-zatwierdzil-budzet-na-biezacy-rok.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T15:23:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/245ktkuTURBXy8yNGEyNzE4NS02MDBiLTQ4NDMtYjFmOS1jNDU5ZDAxODU5MmMuanBlZ5GTBc0BHcyg" />Niemiecki Bundestag zatwierdził w piątek budżet na 2024 rok. Pierwotnie budżet miał zostać przyjęty w grudniu 2023 roku. Jednak orzeczenie Federalnego Trybunału Konstytucyjnego pokrzyżowało plany rządu SPD, Zielonych i FDP.

## Wizyta Sikorskiego w Stanach Zjednoczonych przesunięta. MSZ podało powód
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9423681,wizyta-sikorskiego-w-stanach-zjednoczonych-przesunieta-msz-podalo-powod.html](https://forsal.pl/swiat/aktualnosci/artykuly/9423681,wizyta-sikorskiego-w-stanach-zjednoczonych-przesunieta-msz-podalo-powod.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T14:37:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1KIktkuTURBXy85MTkyZDcyZC05MmNhLTQ4MjEtOGJjZi1jNTU0MTAyN2U0MTYuanBlZ5GTBc0BHcyg" />Zaplanowana na przyszły tydzień wizyta ministra spraw zagranicznych Radosława Sikorskiego w USA została przesunięta z uwagi na pilne obowiązki sekretarza stanu USA Antonego Blinkena - podało w piątek MSZ.

## Rada Nadzorcza Enei odwołała prezesa Pawła Majewskiego
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9423653,rada-nadzorcza-enei-odwolala-prezesa-pawla-majewskiego.html](https://forsal.pl/biznes/aktualnosci/artykuly/9423653,rada-nadzorcza-enei-odwolala-prezesa-pawla-majewskiego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T14:16:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HnQktkuTURBXy9kZTcyMDUwMi00MzEwLTRjNDMtOTEyOC01YmI3MDg2ZDNlZjguanBlZ5GTBc0BHcyg" />Rada Nadzorcza Enei odwołała w piątek prezesa Pawła Majewskiego i czasowo powierzyła wykonywanie czynności prezesa zarządu Monice Stareckiej, zasiadającej w radzie nadzorczej - poinformowała spółka.

## WIOŚ zawiadomił prokuraturę. Chodzi o teren toruńskiej Winnicy, gdzie ma powstać "drapacz chmur"
 - [https://forsal.pl/gospodarka/prawo/artykuly/9423650,wios-zawiadomil-prokurature-chodzi-o-teren-torunskiej-winnicy-gdzie-ma-powstac-drapacz-chmur.html](https://forsal.pl/gospodarka/prawo/artykuly/9423650,wios-zawiadomil-prokurature-chodzi-o-teren-torunskiej-winnicy-gdzie-ma-powstac-drapacz-chmur.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T14:10:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u3mktkuTURBXy9lZTc4YmRlMy01NGM1LTQ0MDUtOGQ4Yi05Mzg1NDEwNjY2M2IuanBlZ5GTBc0BHcyg" />Wojewódzki Inspektorat Ochrony Środowiska w Bydgoszczy złożył w piątek do Prokuratury Rejonowej Toruń-Wschód zawiadomienie o podejrzeniu popełnienia przestępstwa po nawiezieniu ziemi i gruzu w obszarze Natura 2000. Chodzi o teren toruńskiej Winnicy, gdzie ma powstać &quot;drapacz chmur&quot;.

## Metaverse mocno zawodzi. Konsumenci nie chcą wejść do wirtualnej gospodarki
 - [https://forsal.pl/lifestyle/technologie/artykuly/9414289,metaverse-mocno-zawodzi-konsumenci-nie-chca-wejsc-do-wirtualnej-gospo.html](https://forsal.pl/lifestyle/technologie/artykuly/9414289,metaverse-mocno-zawodzi-konsumenci-nie-chca-wejsc-do-wirtualnej-gospo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T14:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xEkktktTURBXy84MDhhODk0Mi01ODk5LTQ4NGYtOTcyMi0yMTU3ZjAyZjE1OWIucG5nkZMFzQEdzKA" />Jeszcze niedawno trójwymiarowy świat awatarów rozpalał oczekiwania firm technologicznych i inwestorów. Miała powstać bliźniacza do tradycyjnej wirtualna gospodarka. Po dwóch latach okazuje się, że do nowych wirtualnych możliwości z dystansem podchodzą konsumenci, którzy mieli być siłą napędzająca metaverse.

## Polityka ws. Ukrainy. Duda: W tej kwestii nie ma między mną a Donaldem Tuskiem różnic
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423633,polityka-ws-ukrainy-duda-w-tej-kwestii-nie-ma-miedzy-mna-a-donaldem-tuskiem-roznic.html](https://forsal.pl/gospodarka/polityka/artykuly/9423633,polityka-ws-ukrainy-duda-w-tej-kwestii-nie-ma-miedzy-mna-a-donaldem-tuskiem-roznic.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T13:46:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4VpktkuTURBXy8wNWMzNjI4Yi0xNmRhLTRmZDEtYTViNi1kNTk3YjlmM2E1MTIuanBlZ5GTBc0BHcyg" />Zwołanie Rady Gabinetowej jest spojrzeniem w przyszłość. Nie chciałbym, aby nasze codzienne spory polityczno-prawne przesłoniły to, że są też inne cele, bardziej długofalowe i strategiczne, w których możemy się porozumieć - powiedział w piątek Interii prezydent Andrzej Duda.

## Tabletka "dzień po". Arłukowicz: Komisja Zdrowia w środę zajmie się projektem noweli
 - [https://forsal.pl/gospodarka/prawo/artykuly/9423626,tabletka-dzien-po-arlukowicz-komisja-zdrowia-w-srode-zajmie-sie-projektem-noweli.html](https://forsal.pl/gospodarka/prawo/artykuly/9423626,tabletka-dzien-po-arlukowicz-komisja-zdrowia-w-srode-zajmie-sie-projektem-noweli.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T13:37:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DWWktkuTURBXy9mZWIxYTY3Ni0yOTQwLTRjYzYtYmZmZi02MDA0OWUyNTUyNDYuanBlZ5GTBc0BHcyg" />Jedziemy w Komisji Zdrowia z tabletką &quot;dzień po&quot; tak szybko, jak się da. Posiedzenie w tej sprawie w najbliższą środę – przekazał w piątek przewodniczący sejmowej Komisji Zdrowia Bartosz Arłukowicz.

## Pełczyńska-Nałęcz: Na początku wpłyną do Polski pierwsze pieniądze z KPO
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9423623,pelczynska-nalecz-na-poczatku-wplyna-do-polski-pierwsze-pieniadze-z-k.html](https://forsal.pl/swiat/unia-europejska/artykuly/9423623,pelczynska-nalecz-na-poczatku-wplyna-do-polski-pierwsze-pieniadze-z-k.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T13:35:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kT1ktkuTURBXy84ZWRmZTk2ZC0wOWYzLTQ4MTItYTE4Yy1jNjM1NTZlYjFlZGIuanBlZ5GTBc0BHcyg" />Oczekuję, że na początku kwietnia br. Polska otrzyma blisko 7 mld euro z Krajowego Planu Odbudowy (KPO) – przekazała w piątek podczas konferencji prasowej minister funduszy i polityki regionalnej Katarzyna Pełczyńska-Nałęcz. Dodała, że w lutym ma zakończyć się audyt programów w ramach KPO.

## MRPiPS podał prognozowany wskaźnik waloryzacji emerytur w 2024 r.
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9423613,mrpips-podal-prognozowany-wskaznik-waloryzacji-emerytur-w-2024-r.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9423613,mrpips-podal-prognozowany-wskaznik-waloryzacji-emerytur-w-2024-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T13:30:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9PhktkuTURBXy8yYjE4MDk4NC1jNTI5LTRlNDctODg0ZC0yNjg0MWRlOTk3ZjQuanBlZ5GTBc0BHcyg" />Prognozuje się, że wskaźnik waloryzacji emerytur i rent w 2024 r. wyniesie nie mniej niż 12,3 proc. - poinformowała ministra rodziny, pracy i polityki społecznej Agnieszka Dziemianowicz-Bąk. Przy takiej wartości wskaźnika całkowity koszt waloryzacji świadczeń wyniesie ok. 43,6 mld zł.

## Dzisiejsze dane o rynku pracy w USA mogą mieć negatywny wpływ na wycenę złotówki
 - [https://forsal.pl/swiat/usa/artykuly/9423608,dzisiejsze-dane-o-rynku-pracy-w-usa-moga-miec-negatywny-wplyw-na-wycen.html](https://forsal.pl/swiat/usa/artykuly/9423608,dzisiejsze-dane-o-rynku-pracy-w-usa-moga-miec-negatywny-wplyw-na-wycen.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T13:19:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AsRktkuTURBXy81MjRlZjk2OC0xMTFmLTRjNDUtYTI1Ni1lNDYzYTBkMjlhMzIuanBlZ5GTBc0BHcyg" />undefined

## Reuters: Polska planuje wycofać z TSUE pozwy ws. polityki klimatycznej Unii
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423602,polska-planuje-wycofac-z-tsue-pozwy-ws-polityki-klimatycznej-unii.html](https://forsal.pl/gospodarka/polityka/artykuly/9423602,polska-planuje-wycofac-z-tsue-pozwy-ws-polityki-klimatycznej-unii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T13:11:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XwOktkuTURBXy9lNzIyMjM1OC1jNTE2LTQxMDItYTk4Yy0wOWNjMzQ5ODJjNDcuanBlZ5GTBc0BHcyg" />Polska planuje wycofać z Trybunału Sprawiedliwości UE w Luksemburgu pozwy (złożone tam przez poprzedni rząd przeciwko niektórym aspektom polityki klimatycznej Unii) - poinformowała w piątek agencja informacyjna Reutera.

## Nowy sposób leczenia ostrej białaczki szpikowej. Leczenie dwoma lekami znacząco wydłuża życie pacjentom
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9423551,nowy-sposob-leczenia-ostrej-bialaczki-szpikowej-leczenie-dwoma-lekami.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9423551,nowy-sposob-leczenia-ostrej-bialaczki-szpikowej-leczenie-dwoma-lekami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T12:53:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dMrktkuTURBXy80YWMxYTBkOS1hOTg2LTQ4MzgtYjM2NC1lMTkxYjc3ZjI2M2YuanBlZ5GTBc0BHcyg" />Skojarzenie dwóch leków w leczeniu dorosłych pacjentów z nowo rozpoznaną ostrą białaczką szpikową z mutacją IDH1 dało 3-krotne wydłużenie czasu przeżycia - poinformowała prof. Agnieszka Wierzbowska z Kliniki Hematologii Medycznego w Łodzi. Jej zdaniem to znaczny postęp i dotyczy najtrudniejszej do leczenia grupy pacjentów.

## Jest megawat do produkcji czekolady. Czy będą gigawaty dla przemysłu ciężkiego?
 - [https://forsal.pl/biznes/energetyka/artykuly/9417265,jest-megawat-do-produkcji-czekolady-czy-beda-gigawaty-dla-przemyslu-c.html](https://forsal.pl/biznes/energetyka/artykuly/9417265,jest-megawat-do-produkcji-czekolady-czy-beda-gigawaty-dla-przemyslu-c.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T12:14:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IIUktkuTURBXy8yMWZmOTY1Yy1hMDU3LTRiNDktOTYxNi0yODMyNzEwZDc5OTcuanBlZ5GTBc0BHcyg" />Niespełna 1 MW mocy w fotowoltaice dla producenta słodyczy - to dotychczasowe efekty legislacyjnego &quot;uwolnienia&quot; linii bezpośrednich. Na bardziej spektakularne inwestycje na razie się nie zanosi.

## Mimo wcześniejszych protestów rolników Bundestag zadecydował o zniesieniu ulg podatkowych
 - [https://forsal.pl/biznes/rolnictwo/artykuly/9423515,mimo-wczesniejszych-protestow-rolnikow-bundestag-zadecydowal-o-zniesie.html](https://forsal.pl/biznes/rolnictwo/artykuly/9423515,mimo-wczesniejszych-protestow-rolnikow-bundestag-zadecydowal-o-zniesie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T11:55:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/245ktkuTURBXy8yNGEyNzE4NS02MDBiLTQ4NDMtYjFmOS1jNDU5ZDAxODU5MmMuanBlZ5GTBc0BHcyg" />Bundestag zatwierdził budzącą kontrowersje likwidację ulgi podatkowej na olej napędowy dla branży rolniczej. W przyjętej w piątek przez parlament ustawie budżetowej przewidziano stopniowe zniesienie tej ulgi – poinformowała dpa.

## Miliony na odchodne: Nowe dane o nagrodach w resortach PiS
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423513,miliony-na-odchodne-nowe-dane-o-nagrodach-w-resortach-pis.html](https://forsal.pl/gospodarka/polityka/artykuly/9423513,miliony-na-odchodne-nowe-dane-o-nagrodach-w-resortach-pis.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T11:51:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/e6EktkuTURBXy84NTJjNWU5Mi0zZGNlLTQ2ODgtYjYyZi1hMzgwMTk2YWUyNTUuanBlZ5GTBc0BHcyg" />W 2023 roku, w atmosferze zbliżających się wyborów parlamentarnych, ministrowie odchodzącego rządu PiS hojnie obdarowali swoich współpracowników nagrodami. Business Insider Polska, wnikliwie analizując dane z kolejnych ministerstw, ujawnia skalę tego zjawiska, rzucając światło na niepokojące trendy.

## Paweł Graś został szefem gabinetu politycznego premiera Donalda Tuska
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423500,pawel-gras-zostal-szefem-gabinetu-politycznego-premiera-donalda-tuska.html](https://forsal.pl/gospodarka/polityka/artykuly/9423500,pawel-gras-zostal-szefem-gabinetu-politycznego-premiera-donalda-tuska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T11:32:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qqsktkuTURBXy8wMGM0OTYzZC1kNmJmLTRlMzItODFmOS1kOGU3YjFhNzY0YWEuanBlZ5GTBc0BHcyg" />Szef KPRM Jan Grabiec przekazał w piątek, że Paweł Graś pełni już funkcję szefa gabinetu politycznego premiera Donalda Tuska. Graś to jeden z bardziej doświadczonych polityków, a jego doświadczenie na pewno bardzo się przyda - podkreślił Grabiec.

## 4 lutego – czy sklepy tego dnia są otwarte? Niedziele handlowe w 2024 roku
 - [https://forsal.pl/biznes/handel/artykuly/9396847,4-lutego-czy-sklepy-tego-dnia-sa-otwarte-niedziele-handlowe-w-2024-roku.html](https://forsal.pl/biznes/handel/artykuly/9396847,4-lutego-czy-sklepy-tego-dnia-sa-otwarte-niedziele-handlowe-w-2024-roku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T11:27:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/t96ktkuTURBXy8xMDRiZmM0Zi1mZTlmLTRiNTctOWY2Yy02ZjAyODc5NzVhZWMuanBlZ5GTBc0BHcyg" />Czy w niedzielę (4 lutego 2024 r.) zrobimy zakupy w Polsce? Sprawdź harmonogram niedziel handlowych.

## Szacunkowa wartość deficytu budżetowego na koniec 2023 r. okazała się niższa niż pierwotnie zakładano
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9423486,szacunkowa-wartosc-deficytu-budzetowego-na-koniec-2023-r-okazala-sie.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9423486,szacunkowa-wartosc-deficytu-budzetowego-na-koniec-2023-r-okazala-sie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T11:19:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kJWktkuTURBXy85NmJlYTkxNy04M2NiLTQ5ZmMtOGE5NC1lNDIxYjZkMjYxYTAuanBlZ5GTBc0BHcyg" />Deficyt budżetu państwa na koniec grudnia 2023 r. wyniósł 85 mld 565,6 mln zł – wynika z opublikowanych w piątek przez MF szacunkowych danych. Zaplanowany w budżecie deficyt na koniec ubiegłego roku miał wynieść 92 mld zł.

## Słowackie media wytykają niekompetencję ministrom w nowym rządzie Fica. "Legitymacja partyjna ważniejsza"
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9423482,slowackie-media-wytykaja-niekompetencje-ministrom-w-nowym-rzadzie-fica.html](https://forsal.pl/swiat/unia-europejska/artykuly/9423482,slowackie-media-wytykaja-niekompetencje-ministrom-w-nowym-rzadzie-fica.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T11:07:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-1mktkuTURBXy9lOGJjNDBlMS1mNGUxLTQ2ZWMtOGUzMC1jNzgxMDY0ZDJiOGUuanBlZ5GTBc0BHcyg" />Energia nowego słowackiego rządu zaskakuje, ale legitymacja partyjna jest tam ważniejsza niż wiedza, umiejętności i kompetencje - ocenił słowacki dziennik &quot;Pravda&quot; pierwsze 100 dni czwartego już gabinetu premiera Roberta Ficy. Sam premier uważa, że w tym czasie gabinet zrobił więcej, niż inne w ciągu trzech lat.

## 80 niemieckich miast sparaliżowanych przez strajk pracowników branży transportu publicznego
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9423473,80-niemieckich-miast-sparalizowanych-przez-strajk-pracownikow-branzy-t.html](https://forsal.pl/swiat/unia-europejska/artykuly/9423473,80-niemieckich-miast-sparalizowanych-przez-strajk-pracownikow-branzy-t.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T10:54:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/M37ktkuTURBXy8xZmYzMzM3OS1kOTM5LTRmZmItODJhMC03Y2E2MjU4NmU2ZGQuanBlZ5GTBc0BHcyg" />W piątek od wczesnego rana prawie w całych Niemczech trwają strajki ostrzegawcze komunikacji publicznej. Protesty objęły ponad 80 miast w 15 krajach związkowych. Strajk ma potrwać dobę. Drugi dzień nie działa także lotnisko w Hamburgu – poinformowała dpa.

## Grabiec o sytuacji w TK: Jeśli jakieś decyzje sędziów będą niezgodne z prawem nie będziemy ich respektować
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9423443,grabiec-o-sytuacji-w-tk-jesli-jakies-decyzje-sedziow-beda-niezgodne-z.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9423443,grabiec-o-sytuacji-w-tk-jesli-jakies-decyzje-sedziow-beda-niezgodne-z.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T10:29:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UU5ktkuTURBXy9hNTU3Mzg0Ny0wNDIwLTQ2NDQtYmExMi1jODg4NjJhODgzZDMuanBlZ5GTBc0BHcyg" />Jeśli jakieś decyzje TK będą niezgodne z prawem to trudno, żeby władze publiczne odpowiadały za współudział w tych nielegalnych działaniach i trudno, żebyśmy je respektowali - powiedział w piątek szef KPRM Jan Grabiec. Dodał, że &quot;jest powszechne przekonanie&quot;, że obecna sytuacja w TK jest bezprawna.

## Zmiana rady nadzorczej w PKO BP. Skarb Państwa mianował nową przewodniczącą rady
 - [https://forsal.pl/biznes/bankowosc/artykuly/9423386,zmiana-rady-nadzorczej-w-pko-bp-skarb-panstwa-mianowal-nowa-przewodni.html](https://forsal.pl/biznes/bankowosc/artykuly/9423386,zmiana-rady-nadzorczej-w-pko-bp-skarb-panstwa-mianowal-nowa-przewodni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T10:07:45+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/s-2ktkuTURBXy83YzcyM2IzNy1lZmZmLTQ4MTAtYmRjYi01ZjdjODBkMzYyZTMuanBlZ5GTBc0BHcyg" />W piątek Nadzwyczajne Walne Zgromadzenie Akcjonariuszy PKO BP zmieniło skład razy nadzorczej banku. Nowych członków rady wskazał Skarb Państwa, który także wyznaczył Katarzynę Zimnicką-Jankowską na przewodniczącą rady.

## Banaś: Wartość Lotosu w trakcie fuzji z Orlenem została zaniżona o 5 mld zł. Czy to ostateczna kwota?
 - [https://forsal.pl/gospodarka/prawo/artykuly/9423378,banas-wartosc-lotosu-w-trakcie-fuzji-z-orlenem-zostala-zanizona-o-5-m.html](https://forsal.pl/gospodarka/prawo/artykuly/9423378,banas-wartosc-lotosu-w-trakcie-fuzji-z-orlenem-zostala-zanizona-o-5-m.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T10:03:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/izpktkuTURBXy80ZGYyYWIwNy00NzBkLTQyYzMtYWQ1OC0wMDY4ZDBmMTVlYWEuanBlZ5GTBc0BHcyg" />Kontrolerzy Najwyższej Izby Kontroli, na podstawie dokumentów m.in. w Ministerstwie Aktywów Państwowych oraz resorcie klimatu i środowiska, ustalili, że zaniżenie ceny Lotosu było na kwotę około 5 mld zł - powiedział w piątek prezes NIK Marian Banaś w TVP Info pytany o fuzję Orlenu z Lotosem.

## Koronawirus w Polsce - statystyki z 2.02.2024
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-statystyki-z-2022024.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-statystyki-z-2022024.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T09:43:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 392 zakażenia koronawirusem, w tym 86 ponownych. Z powodu COVID-19 zmarło 11 pacjentów – poinformowano w piątek na stronach rządowych. Wykonano ponad 3,7 tys. testów w kierunku SARS-CoV-2.

## Dziemianowicz-Bąk: Nie podwyższymy ustawowego wieku emerytalnego
 - [https://forsal.pl/praca/kariera/artykuly/9423367,dziemianowicz-bak-nie-podwyzszymy-ustawowego-wieku-emerytalnego.html](https://forsal.pl/praca/kariera/artykuly/9423367,dziemianowicz-bak-nie-podwyzszymy-ustawowego-wieku-emerytalnego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T09:42:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LYzktkuTURBXy81OTE4YWE4ZS01MDYxLTQ1ZDUtOWY0MS0xNDA2MzQ1YjYyNzcuanBlZ5GTBc0BHcyg" />undefined

## Wielkie zwolnienia w branży meblarskiej. Biznes apeluje o zmiany w Lasach Państwowych
 - [https://forsal.pl/biznes/artykuly/9423342,wielkie-zwolnienia-w-branzy-meblarskiej-biznes-apeluje-o-zmiany-w-las.html](https://forsal.pl/biznes/artykuly/9423342,wielkie-zwolnienia-w-branzy-meblarskiej-biznes-apeluje-o-zmiany-w-las.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T09:10:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3TektkuTURBXy8zMjlmYmVkOS0yNjQ0LTRmOWUtYTIzYi1jYTNkOThkMGU2YzcuanBlZ5GTBc0BHcyg" />18 tys. etatów – o tyle zmniejszyło się zatrudnienie w branży meblarskiej w półtora roku. Przedsiębiorcy apelują o zmiany w Lasach Państwowych

## Węgierskie media o ustępstwach Orbana na szczycie UE. Jedne chwalą nieprzejednaną postawę, inne wytykają słabość
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9423338,wegierskie-media-o-ustepstwach-orbana-na-szczycie-ue-jedne-chwala-nie.html](https://forsal.pl/swiat/unia-europejska/artykuly/9423338,wegierskie-media-o-ustepstwach-orbana-na-szczycie-ue-jedne-chwala-nie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T09:07:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Fb1ktkuTURBXy80M2E5ZTliMC0xZTAwLTQyOTgtYTFmNS1jMWIzY2Y4N2I3YTkuanBlZ5GTBc0BHcyg" />Premier Węgier Viktor Orban znalazł się pod ogromną presją podczas unijnego szczytu i zgodził się na unijną pomoc finansową dla Ukrainy w wysokości 50 mld euro – piszą węgierskie media po czwartkowym szczycie UE ws. Ukrainy.

## Kursy walut. Ile zapłacimy za dolara, euro i franka szwajcarskiego? [02. 02. 2024 r.]
 - [https://forsal.pl/finanse/waluty/artykuly/9423287,kursy-walut-ile-zaplacimy-za-dolara-euro-i-franka-szwajcarskiego-0.html](https://forsal.pl/finanse/waluty/artykuly/9423287,kursy-walut-ile-zaplacimy-za-dolara-euro-i-franka-szwajcarskiego-0.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T08:36:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/17sktkuTURBXy9hNmY4MGYzNC1kNDlhLTQwNmUtYTk4My1jZjJjYzUxYjA1NmEuanBlZ5GTBc0BHcyg" />Złoty w piątek rano stracił do euro, a w stosunku do dolara i franka pozostał stabilny. Euro ok. godz. 9 w piątek kosztowało prawie 4,32 zł, dolar 3,97 a frank 4,62 zł.

## Bonikowska: UE postawiła twarde warunki Orbanowi. Węgry mogą realnie stracić głos w Radzie Europejskiej
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9423245,bonikowska-ue-postawila-twarde-warunki-orbanowi-wegry-moga-realnie-s.html](https://forsal.pl/swiat/unia-europejska/artykuly/9423245,bonikowska-ue-postawila-twarde-warunki-orbanowi-wegry-moga-realnie-s.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T08:28:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/R6xktkuTURBXy84ZjdhNGYyMy0xMTVhLTQ0ZDgtODk2NS1lZThhNDc0ZjE0ZjUuanBlZ5GTBc0BHcyg" />Groźba pozbawienia Węgier głosu w Radzie Europejskiej jest realna – powiedziała w rozmowie z PAP dr Małgorzata Bonikowska, prezes Centrum Stosunków Międzynarodowych (CSM) i ekspertka ds. unijnych. Według niej Unia Europejska zmieniła strategię i postawiła się Węgrom w sprawie Ukrainy.

## Przychody TIM spadły wstępnie o 11 proc. r/r do 104,1 mln zł w styczniu
 - [https://forsal.pl/finanse/gielda/artykuly/9423142,przychody-tim-spadly-wstepnie-o-11-proc-rr-do-1041-mln-zl-w-styczni.html](https://forsal.pl/finanse/gielda/artykuly/9423142,przychody-tim-spadly-wstepnie-o-11-proc-rr-do-1041-mln-zl-w-styczni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T08:11:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fBMktkuTURBXy81ZTVlNDFlNy1hMzE1LTRlMGMtYmRjZS02NDlhZGZmZTk3NWIuanBlZ5GTBc0BHcyg" />undefined

## Sygnity zamknęło transakcję nabycia 100 proc. Edrana Baltic UAB
 - [https://forsal.pl/finanse/gielda/artykuly/9423129,sygnity-zamknelo-transakcje-nabycia-100-proc-edrana-baltic-uab.html](https://forsal.pl/finanse/gielda/artykuly/9423129,sygnity-zamknelo-transakcje-nabycia-100-proc-edrana-baltic-uab.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T08:09:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fOzktkuTURBXy85MjNlMTUxMy03YjVmLTRmMDEtYWQxYS1lN2IzZDQ5Nzc2OWQuanBlZ5GTBc0BHcyg" />undefined

## Grabiec o Danielu Obajtku: To nie był prezes spółki, a funkcjonariusz partyjny
 - [https://forsal.pl/gospodarka/polityka/artykuly/9423042,grabiec-o-danielu-obajtku-to-nie-byl-prezes-spolki-a-funkcjonariusz.html](https://forsal.pl/gospodarka/polityka/artykuly/9423042,grabiec-o-danielu-obajtku-to-nie-byl-prezes-spolki-a-funkcjonariusz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T07:55:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DlQktkuTURBXy81ODZkMWJkOC1hNGNiLTQzNGUtYjFlNC05MGVlNTc0NTRjOWIuanBlZ5GTBc0BHcyg" />Daniel Obajtek był nie tyle prezesem Orlenu, co funkcjonariuszem PiS - powiedział w piątek szef KPRM Jan Grabiec. W rozmowie z RMF24 zapewnił, że prezesem Orlenu zostanie fachowiec, którego pierwszym zadaniem będzie &quot;uporządkowanie spraw w spółce, ustalenie, kto odpowiada za to, co tam się działo&quot;.

## Kanadyjki rodzą coraz mniej dzieci? Najniższe statystyki od ponad wieku
 - [https://forsal.pl/gospodarka/demografia/artykuly/9423002,kanadyjki-rodza-coraz-mniej-dzieci-najnizsze-statystyki-od-ponad-wiek.html](https://forsal.pl/gospodarka/demografia/artykuly/9423002,kanadyjki-rodza-coraz-mniej-dzieci-najnizsze-statystyki-od-ponad-wiek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T07:46:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1KgktkuTURBXy8xMDY4ZDlhMC0zYmRkLTQxYmMtOWM5NC1iYmQyNjRlMzgyMzMuanBlZ5GTBc0BHcyg" />Kanadyjki mają coraz mniej dzieci; dane za 2022 r. wskazują, że statystycznie na każdą kobietę w wieku reprodukcyjnym przypadało 1,33 dziecka. To najmniej od ponad wieku – podał Statistics Canada, kanadyjski urząd statystyczny.

## Dokumenty z PWPW, Poczty Polskiej i NIK odtajnione. Co dalej na komisji ds. wyborów korespondencyjnych?
 - [https://forsal.pl/gospodarka/polityka/artykuly/9422924,dokumenty-z-pwpw-poczty-polskiej-i-nik-odtajnione-co-dalej-na-komisj.html](https://forsal.pl/gospodarka/polityka/artykuly/9422924,dokumenty-z-pwpw-poczty-polskiej-i-nik-odtajnione-co-dalej-na-komisj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T07:32:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ax5ktkuTURBXy84MjBhNDU4My1lNGM5LTQ0ZmEtYTFhNy1kNmU0NmMzM2FmMWYuanBlZ5GTBc0BHcyg" />Komisja śledcza ds. wyborów korespondencyjnych odtajniła część dokumentów, które otrzymała z Poczty Polskiej, KPRM, MSWiA, NIK, MAP, PWPW. &quot;Dokumenty odtajnione mogą być przytaczane w jawnej części obrad komisji&quot; - powiedział PAP prawnik, dr Tomasz Szewc z Politechniki Śląskiej.

## Sejmowa komisja ds. wyborów korespondencyjnych chce odtajnić część dokumentów z MAP, Poczty Polskiej i innych zaangażowanych w sprawę instytucji
 - [https://forsal.pl/gospodarka/polityka/artykuly/9422900,sejmowa-komisja-ds-wyborow-korespondencyjnych-chce-odtajnic-czesc-dok.html](https://forsal.pl/gospodarka/polityka/artykuly/9422900,sejmowa-komisja-ds-wyborow-korespondencyjnych-chce-odtajnic-czesc-dok.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T07:24:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2gsktkuTURBXy84NmI4MzBiNy1lNzhlLTQxNGUtODY0Yi04NmM0NGY2NmEyN2EuanBlZ5GTBc0BHcyg" />Komisja śledcza ds. wyborów korespondencyjnych odtajniła część dokumentów, które otrzymała z Poczty Polskiej, KPRM, MSWiA, NIK, MAP, PWPW. &quot;Dokumenty odtajnione mogą być przytaczane w jawnej części obrad komisji&quot; - powiedział PAP prawnik, dr Tomasz Szewc z Politechniki Śląskiej.

## Niemieckie ministerstwo obrony: Polska jest niezbędnym sojusznikiem
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9422897,niemieckie-ministerstwo-obrony-polska-jest-niezbednym-sojusznikiem.html](https://forsal.pl/swiat/aktualnosci/artykuly/9422897,niemieckie-ministerstwo-obrony-polska-jest-niezbednym-sojusznikiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T07:16:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/34UktkuTURBXy9hNTEyYmJiZC05M2E1LTQ2MmEtOGM2MS02NGUxODllYTk5NmMuanBlZ5GTBc0BHcyg" />Polska jest niezbędnym sojusznikiem dla bezpiecznej Europy, silnej wschodniej flanki NATO i niezachwianego wsparcia dla Ukrainy - napisało w czwartek na platformie X niemieckie ministerstwo obrony.

## Drony i technologia. Tak Ukraina może przełamać liczbową przewagę Rosjan?
 - [https://forsal.pl/swiat/ukraina/artykuly/9422893,drony-i-technologia-tak-ukraina-moze-przelamac-liczbowa-przewage-rosj.html](https://forsal.pl/swiat/ukraina/artykuly/9422893,drony-i-technologia-tak-ukraina-moze-przelamac-liczbowa-przewage-rosj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T07:07:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/G-FktkuTURBXy83Y2RlOTU1OC00OWY5LTQ4YjMtOGFmMi0xOGE3MmU3NWY4NTYuanBlZ5GTBc0BHcyg" />Rosja ma znaczącą przewagę jeśli chodzi o możliwości mobilizacji zasobów ludzkich, a Ukraina musi mierzyć się ze zmniejszeniem pomocy zagranicznej i kurczącymi się zapasami amunicji - napisał na łamach portalu CNN gen. Wałerij Załużny, naczelny dowódca Sił Zbrojnych Ukrainy. Stwierdził przy tym, że najlepszą szansą na uniknięcie wojny pozycyjnej i przewagi Rosjan są drony.

## Największy problem polskiej gospodarki? Wysoki dług zagraniczny
 - [https://forsal.pl/gospodarka/artykuly/9422887,najwiekszy-problem-polskiej-gospodarki-wysoki-dlug-zagraniczny.html](https://forsal.pl/gospodarka/artykuly/9422887,najwiekszy-problem-polskiej-gospodarki-wysoki-dlug-zagraniczny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T07:05:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DJzktkuTURBXy9mOThjOWNjNi03NmJjLTQ3MjMtOGRhYS0yYTc5MGJjYjBmOTcuanBlZ5GTBc0BHcyg" />Polska znalazła się w gronie raczej bezpiecznych i stabilnych krajów w globalnym badaniu ryzyka finansowego 83 gospodarek świata, przeprowadzonym przez Allianz Trade. Pozytywnie na ocenę dla naszej gospodarki wpływa m.in. popyt krajowy i przynależność do UE, zaś negatywnie – wysoki dług zagraniczny.

## Kryzys demograficzny w Kanadzie. Tak źle nie było od ponad 100 lat
 - [https://forsal.pl/gospodarka/demografia/artykuly/9422874,kryzys-demograficzny-w-kanadzie-tak-zle-nie-bylo-od-ponad-100-lat.html](https://forsal.pl/gospodarka/demografia/artykuly/9422874,kryzys-demograficzny-w-kanadzie-tak-zle-nie-bylo-od-ponad-100-lat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T06:57:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DP2ktkuTURBXy9hNDdmYzQyYi01MzM4LTQxYzMtYjcyNC1hZWVjZGQ5M2RjZjMuanBlZ5GTBc0BHcyg" />Kanadyjki mają coraz mniej dzieci. Dane za 2022 rok wskazują, że statystycznie na każdą kobietę w wieku reprodukcyjnym przypadało 1,33 dziecka. To najmniej od ponad wieku – zauważył kanadyjski urząd statystyczny Statistics Canada.

## Biden dzwonił do von der Leyen. Dziękował za pakiet dla Ukrainy
 - [https://forsal.pl/swiat/ukraina/artykuly/9422865,biden-dzwonil-do-von-der-leyen-dziekowal-za-pakiet-dla-ukrainy.html](https://forsal.pl/swiat/ukraina/artykuly/9422865,biden-dzwonil-do-von-der-leyen-dziekowal-za-pakiet-dla-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T06:37:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5RJktkuTURBXy83NGVmOGVmMC1kYjBiLTQwMDUtOTRhYy1iMTgyZDZmZTZiZTEuanBlZ5GTBc0BHcyg" />Prezydent USA Joe Biden podziękował w czwartek szefowej KE Ursuli von der Leyen za przyjęcie przez UE pakietu dla Kijowa. Waszyngton zaznacza jednak, że konieczne jest też zatwierdzenie przez Kongres pomocy z USA. &quot;Zarówno ekonomiczne, jak i wojskowe komponenty tego pakietu środków są niezbędne&quot; - powiedział rzecznik Departamentu Stanu Matthew Miller, odpowiadając na pytanie PAP.

## Wenecja jak muzeum? Jednodniowi turyści będą musieli kupić bilet wstępu
 - [https://forsal.pl/lifestyle/turystyka/artykuly/9422864,wenecja-jak-muzeum-jednodniowi-turysci-beda-musieli-kupic-bilet-wstep.html](https://forsal.pl/lifestyle/turystyka/artykuly/9422864,wenecja-jak-muzeum-jednodniowi-turysci-beda-musieli-kupic-bilet-wstep.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T06:35:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tG0ktkuTURBXy9kMjRjZTQzMy1hNGYwLTRmYjQtYTA2Ni0zYzFhNjE3NzhiZTYuanBlZ5GTBc0BHcyg" />Wprowadzenie od 25 kwietnia w wybrane dni biletu wstępu do Wenecji dla tych, którzy przyjadą tam tylko na kilka godzin bez noclegu, nie oznacza, że miasto będzie zamknięte i niegościnne - zapewnił w czwartek burmistrz Luigi Brugnaro.

## Kryzys w branży meblarskiej się pogłębia. Spada eksport, a firmy redukują zatrudnienie
 - [https://forsal.pl/biznes/przemysl/artykuly/9422857,kryzys-w-branzy-meblarskiej-spada-eksport-firmy-redukuja-zatrudnienie.html](https://forsal.pl/biznes/przemysl/artykuly/9422857,kryzys-w-branzy-meblarskiej-spada-eksport-firmy-redukuja-zatrudnienie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T06:23:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rknktkuTURBXy8zMWJkZWRiNy04MWVlLTQ1NDYtYjEwNS05N2RkZjk2NDZkZjMuanBlZ5GTBc0BHcyg" />Wartość sprzedaży polskiej branży meblowej spadła w zeszłym roku do 64 mld zł, a eksportu do 62,3 mld zł. W tym roku nie będzie lepiej - pisze piątkowy &quot;Puls Biznesu&quot;.

## Praca za granicą. Kiedy ZUS może zawiesić wypłatę renty i emerytury?
 - [https://forsal.pl/praca/praca-za-granica/artykuly/9419390,praca-za-granica-kiedy-zus-moze-zawiesic-wyplate-renty-i-emerytury.html](https://forsal.pl/praca/praca-za-granica/artykuly/9419390,praca-za-granica-kiedy-zus-moze-zawiesic-wyplate-renty-i-emerytury.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T05:51:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AKJktkuTURBXy9jNDBmMjZiMS0wMTc0LTQ4OTMtOWU1ZC00ZThmMWFlNjhkMDcuanBlZ5GTBc0BHcyg" />Pobierasz rentę lub emeryturę i pracujesz za granicą? Sprawdź, jakie informacje musisz podać do Zakładu Ubezpieczeń Społecznych i kiedy możesz stracić prawo do świadczenia.

## Pracujesz za granicą i pobierasz rentę lub emeryturę? Sprawdź, kiedy ZUS może zawiesić wypłatę pieniędzy
 - [https://forsal.pl/praca/praca-za-granica/artykuly/9419390,pracujesz-za-granica-i-pobierasz-rente-lub-emeryture-sprawdz-kiedy-zus-moze-zawiesic-wyplate-pieniedzy.html](https://forsal.pl/praca/praca-za-granica/artykuly/9419390,pracujesz-za-granica-i-pobierasz-rente-lub-emeryture-sprawdz-kiedy-zus-moze-zawiesic-wyplate-pieniedzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T05:50:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XcGktkuTURBXy9jZmRjZGNjYi0zMTgyLTQ0MTMtOWVjMi0wYWE1MjhiNmIzMjAuanBlZ5GTBc0BHcyg" />Pobierasz rentę lub emeryturę i pracujesz za granicą? Sprawdź, jakie informacje musisz podać do Zakładu Ubezpieczeń Społecznych i kiedy możesz stracić prawo do świadczenia.

## Ile kosztuje przegląd samochodu w 2024 roku? Duże zmiany
 - [https://forsal.pl/motoforsal/artykuly/9419972,ile-kosztuje-przeglad-samochodu-w-2024-roku-duze-zmiany.html](https://forsal.pl/motoforsal/artykuly/9419972,ile-kosztuje-przeglad-samochodu-w-2024-roku-duze-zmiany.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T05:39:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/l2mktkuTURBXy83M2ExNTA4Ny1iNDUxLTRmNmUtYmM1ZS1lN2IwYjZkOGU0YjguanBlZ5GTBc0BHcyg" />W 2024 roku właściciele samochodów w Polsce mogą spodziewać się zmian w cenniku oraz procedurze przeprowadzania przeglądu technicznego pojazdów. Po dwudziestu latach od ostatniej aktualizacji Ministerstwo Infrastruktury planuje znaczące zmiany, które wpłyną na koszty oraz sposób realizacji przeglądów.

## Zmiany w L4 - czy to dobra decyzja? Wiążą się z pewnym… ryzykiem
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9418544,zmiany-w-l4-czy-to-dobra-decyzja-wiaza-sie-z-pewnym-ryzykiem.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9418544,zmiany-w-l4-czy-to-dobra-decyzja-wiaza-sie-z-pewnym-ryzykiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T05:35:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NLrktkuTURBXy83NDMwYjgyNC0zMDNiLTQzODUtYWYwMi05YjExOTg1Y2NlNzkuanBlZ5GTBc0BHcyg" />Rządzący zapowiadają, że ZUS będzie wypłacał wynagrodzenie pracownikom od pierwszego dnia na zwolnieniu chorobowym. To dobra wiadomość dla firm, które będą mogły &quot;odciążyć&quot; swoje budżety. Jednak zmiana ta może mieć też negatywne konsekwencje dla niektórych przedsiębiorców.

## Muhammad nie wynajmie mieszkania w Austrii? To temat głośny także w innych krajach
 - [https://forsal.pl/nieruchomosci/artykuly/9416214,muhammad-nie-wynajmie-mieszkania-w-austrii-to-temat-glosny-takze-w-in.html](https://forsal.pl/nieruchomosci/artykuly/9416214,muhammad-nie-wynajmie-mieszkania-w-austrii-to-temat-glosny-takze-w-in.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T05:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sfWktkuTURBXy82MzllNDFiOS1iOTczLTRkNzQtYmM0ZC0wZTBhYTRkYTYwZjkuanBlZ5GTBc0BHcyg" />W Austrii od pewnego czasu mówi się o niechętnym wynajmowaniu lokali obcokrajowcom. To zjawisko widoczne też w kilku innych krajach Starego Kontynentu.

## Chiny mierzą się z bezrobociem wśród młodych. A ten problem napędzi kolejne
 - [https://forsal.pl/gospodarka/bezrobocie/artykuly/9414438,chiny-mierza-sie-z-bezrobociem-wsrod-mlodych-a-ten-problem-napedzi-ko.html](https://forsal.pl/gospodarka/bezrobocie/artykuly/9414438,chiny-mierza-sie-z-bezrobociem-wsrod-mlodych-a-ten-problem-napedzi-ko.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T05:20:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EsNktktTURBXy82ZWI0NWQ2ZC01YzNjLTQzZDYtOTAyMC02MWQxZDhkYjI4MDQucG5nkZMFzQEdzKA" />Chiński smok musi stawić czoła wielu wyzwaniom, przy czym zadanie jest o tyle trudniejsze, że w tym kraju jeden problem napędza drugi. Obecnie wielu młodych Chińczyków bez skutku szuka dla siebie miejsca na rynku pracy, dla którego, jak się okazuje, są przekwalifikowani. Ekonomiści przewidują, że chińskie bezrobocie będzie oliwą do ognia innych kryzysów; w tym – demograficznego.

## Wyborca AfD: „Polska urosła dwucyfrowo, a Niemcy się zwijają. Dlaczego mamy to finansować?”
 - [https://forsal.pl/gospodarka/polityka/artykuly/9421749,wyborca-afd-polska-urosla-dwucyfrowo-a-niemcy-sie-zwijaja-dlaczego.html](https://forsal.pl/gospodarka/polityka/artykuly/9421749,wyborca-afd-polska-urosla-dwucyfrowo-a-niemcy-sie-zwijaja-dlaczego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T05:10:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Hm3ktktTURBXy9kNGFmYjI0Yi1iM2RkLTQxY2MtOThiMi1lZTRlODQ0YzVmNDYucG5nkZMFzQEdzKA" />Pierwszy raz w historii przeciętne wynagrodzenie w Polsce przekroczyło 2 tysiące dolarów, minimalne – tysiąc, a politycy partii, która rządziła przez ostatnich osiem lat, robią z nas niezmiennie ofiarę dziejów. Tymczasem mój znajomy z Bawarii usłyszał od sąsiada - zwolennika Alternatywy dla Niemiec (AfD): „Polska urosła dwucyfrowo, a Niemcy się zwijają. Dlaczego mamy to finansować?” Świetne pytanie do Jarosława Kaczyńskiego.

## Nie tylko mBank podnosi opłaty, czyli jak drożeją usługi bankowe
 - [https://forsal.pl/biznes/bankowosc/artykuly/9422821,mbank-podnosi-oplaty-ile-od-kiedy.html](https://forsal.pl/biznes/bankowosc/artykuly/9422821,mbank-podnosi-oplaty-ile-od-kiedy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/m_ektkuTURBXy9kN2ViY2NkMi0zZmYxLTQ2YmQtOTZhYy0wNGRiODZkMGQ2MzMuanBlZ5GTBc0BHcyg" />W tym roku już dwa duże banki zapowiedziały podwyższenie prowizji i opłat. W ubiegłym wzrost cen usług finansowych należał u nas do najwyższych w UE. Obniżki stóp procentowych mogą skłonić do podnoszenia prowizji kolejnych rynkowych graczy.

## Niemcy - unijny antyprzykład odchodzenia od paliw kopalnych
 - [https://forsal.pl/biznes/energetyka/artykuly/9421547,niemcy-unijny-antyprzyklad-odchodzenia-od-paliw-kopalnych.html](https://forsal.pl/biznes/energetyka/artykuly/9421547,niemcy-unijny-antyprzyklad-odchodzenia-od-paliw-kopalnych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-02T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/N_1ktkuTURBXy83YWNhNDQ1OC0xZGI2LTRiZjktOWU2MC1lNGQ2NTY5YWQzNmYuanBlZ5GTBc0BHcyg" />Pozyskiwanie energii z paliw kopalnych jest związane z dużymi kosztami społecznymi. Z tego powodu UE zamierza ograniczyć uzależnienie od nich. Niektórym państwom udaje się to. Są jednak także takie, gdzie idzie to bardzo wolno. Jednym z takich antyprzykładów są Niemcy. Jak na tle UE wypada Polska?

