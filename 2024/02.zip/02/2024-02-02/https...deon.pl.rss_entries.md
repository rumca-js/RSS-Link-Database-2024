# Source:DEON.pl, URL:https://deon.pl/rss, language:pl

## Nie jesteś sam! Bądź w dialogu z Jezusem i braćmi
 - [https://deon.pl/wiara/komentarze-do-ewangelii/nie-jestes-sam-badz-w-dialogu-z-jezusem-i-bracmi,2732540](https://deon.pl/wiara/komentarze-do-ewangelii/nie-jestes-sam-badz-w-dialogu-z-jezusem-i-bracmi,2732540)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T23:00:00+00:00



## Zrobić, co trzeba, żeby wszyscy czuli się w Kościele bezpiecznie
 - [https://deon.pl/kosciol/komentarze/zrobic-co-trzeba-zeby-wszyscy-czuli-sie-w-kosciele-bezpiecznie,2732588](https://deon.pl/kosciol/komentarze/zrobic-co-trzeba-zeby-wszyscy-czuli-sie-w-kosciele-bezpiecznie,2732588)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T18:19:38+00:00



## USA: Papież Franciszek postrzegany najmniej przychylnie w historii
 - [https://deon.pl/kosciol/usa-papiez-franciszek-postrzegany-najmniej-przychylnie-w-historii,2732549](https://deon.pl/kosciol/usa-papiez-franciszek-postrzegany-najmniej-przychylnie-w-historii,2732549)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T15:55:00+00:00



## Jak będzie wyglądało ponowne otwarcie katedry Notre-Dame?
 - [https://deon.pl/swiat/wiadomosci-ze-swiata/jak-bedzie-wygladalo-ponowne-otwarcie-katedry-notre-dame,2732426](https://deon.pl/swiat/wiadomosci-ze-swiata/jak-bedzie-wygladalo-ponowne-otwarcie-katedry-notre-dame,2732426)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T15:40:00+00:00



## Alkohol, hazard, gry, zaburzenia osobowości. 700 spraw o stwierdzenie nieważności małżeństwa w Tarnowie
 - [https://deon.pl/kosciol/alkohol-hazard-gry-zaburzenia-osobowosci-700-spraw-o-stwierdzenie-niewaznosci-malzenstwa-w-tarnowie,2732528](https://deon.pl/kosciol/alkohol-hazard-gry-zaburzenia-osobowosci-700-spraw-o-stwierdzenie-niewaznosci-malzenstwa-w-tarnowie,2732528)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T15:17:47+00:00



## Gen. Załużny w CNN: Drony i technologia są najlepszym sposobem na pokonanie liczbowej przewagi Rosjan
 - [https://deon.pl/swiat/genzaluznyw-cnn-drony-i-technologia-sa-najlepszym-sposobem-na-pokonanie-liczbowej-przewagi-rosjan,2732345](https://deon.pl/swiat/genzaluznyw-cnn-drony-i-technologia-sa-najlepszym-sposobem-na-pokonanie-liczbowej-przewagi-rosjan,2732345)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T14:40:00+00:00



## Modlitwa o wyzwolenie od lęków
 - [https://deon.pl/wiara/duchowosc/modlitwa-o-wyzwolenie-od-lekow,2732387](https://deon.pl/wiara/duchowosc/modlitwa-o-wyzwolenie-od-lekow,2732387)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T14:31:08+00:00



## Synoptyk IMGW: Piątek pochmurny, wieczorem opady deszczu
 - [https://deon.pl/swiat/synoptyk-imgw-piatek-pochmurny-wieczorem-opady-deszczu,2732336](https://deon.pl/swiat/synoptyk-imgw-piatek-pochmurny-wieczorem-opady-deszczu,2732336)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T13:53:19+00:00



## Papież na dzień misyjny: Zaprośmy wszystkich na ucztę Pana
 - [https://deon.pl/kosciol/papiez-na-dzien-misyjny-zaprosmy-wszystkich-na-uczte-pana,2732303](https://deon.pl/kosciol/papiez-na-dzien-misyjny-zaprosmy-wszystkich-na-uczte-pana,2732303)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T13:35:00+00:00



## Czy można jeść mięso na studniówce, która wypada w piątek? Ksiądz z osiedla stawia warunek
 - [https://deon.pl/kosciol/czy-mozna-jesc-mieso-na-studniowce-ktora-wypada-w-piatek-ksiadz-z-osiedla-stawia-warunek,2732306](https://deon.pl/kosciol/czy-mozna-jesc-mieso-na-studniowce-ktora-wypada-w-piatek-ksiadz-z-osiedla-stawia-warunek,2732306)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T13:24:57+00:00



## Białoruś: Kościół przeciw błogosławieniu „związków nieregularnych” i par tej samej płci
 - [https://deon.pl/kosciol/bialorus-kosciol-przeciw-blogoslawieniu-zwiazkow-nieregularnych-i-par-tej-samej-plci-,2732294](https://deon.pl/kosciol/bialorus-kosciol-przeciw-blogoslawieniu-zwiazkow-nieregularnych-i-par-tej-samej-plci-,2732294)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T12:55:00+00:00



## Abp Galbas do konsekrowanych: Dawajmy przykład, ale umiejmy się też odezwać
 - [https://deon.pl/kosciol/abp-galbas-do-konsekrowanych-dawajmy-przyklad-ale-umiejmy-sie-tez-odezwac,2732288](https://deon.pl/kosciol/abp-galbas-do-konsekrowanych-dawajmy-przyklad-ale-umiejmy-sie-tez-odezwac,2732288)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T12:13:07+00:00



## Potężna asteroida minie w piątek Ziemię. To obiekt należący do "potencjalnie niebezpiecznych"
 - [https://deon.pl/swiat/potezna-asteroida-minie-w-piatek-ziemie-to-obiekt-nalezacy-do-potencjalnie-niebezpiecznych,2732117](https://deon.pl/swiat/potezna-asteroida-minie-w-piatek-ziemie-to-obiekt-nalezacy-do-potencjalnie-niebezpiecznych,2732117)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T11:28:56+00:00



## Życie konsekrowane na świecie: Prawie 180 tys. zakonników i ponad 600 tys. zakonnic
 - [https://deon.pl/kosciol/zycie-konsekrowane-na-swiecie-prawie-180-tys-zakonnikow-i-ponad-600-tys-zakonnic,2732108](https://deon.pl/kosciol/zycie-konsekrowane-na-swiecie-prawie-180-tys-zakonnikow-i-ponad-600-tys-zakonnic,2732108)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T09:31:57+00:00



## Zespół Ekspertów KEP ds. Bioetycznych: Stosowanie tabletek „po” jest z punktu widzenia etycznego niemoralne
 - [https://deon.pl/kosciol/zespol-ekspertow-kep-ds-bioetycznych-stosowanie-tabletek-po-jest-z-punktu-widzenia-etycznego-niemoralne,2732102](https://deon.pl/kosciol/zespol-ekspertow-kep-ds-bioetycznych-stosowanie-tabletek-po-jest-z-punktu-widzenia-etycznego-niemoralne,2732102)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T09:15:43+00:00



## Nie żyje ksiądz z archidiecezji krakowskiej. Został znaleziony nieprzytomny w swoim mieszkaniu
 - [https://deon.pl/kosciol/nie-zyje-ksiadz-z-archidiecezji-krakowskiej-zostal-znaleziony-nieprzytomny-w-swoim-mieszkaniu,2732030](https://deon.pl/kosciol/nie-zyje-ksiadz-z-archidiecezji-krakowskiej-zostal-znaleziony-nieprzytomny-w-swoim-mieszkaniu,2732030)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T09:04:32+00:00



## Elizabeth Tabish o roli Marii Magdaleny: Zmieniła moje życie w wielu aspektach [WIDEO]
 - [https://deon.pl/po-godzinach/elizabeth-tabish-o-roli-marii-magdaleny-zmienila-moje-zycie-w-wielu-aspektach-wideo,2731949](https://deon.pl/po-godzinach/elizabeth-tabish-o-roli-marii-magdaleny-zmienila-moje-zycie-w-wielu-aspektach-wideo,2731949)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T08:46:56+00:00



## Podcast Tomasza Terlikowskiego | Tak myślę | Odcinek 124
 - [https://deon.pl/wiara/podcast-tomasza-terlikowskiego--tak-mysle--odcinek-124,2731931](https://deon.pl/wiara/podcast-tomasza-terlikowskiego--tak-mysle--odcinek-124,2731931)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T07:56:43+00:00



## Film na weekend: "Cudowny chłopak. Biały ptak". Przesłanie miłości jest wciąż aktualne
 - [https://deon.pl/po-godzinach/film-na-weekend-cudowny-chlopak-bialy-ptak-przeslanie-milosci-jest-wciaz-aktualne,2729057](https://deon.pl/po-godzinach/film-na-weekend-cudowny-chlopak-bialy-ptak-przeslanie-milosci-jest-wciaz-aktualne,2729057)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T07:30:00+00:00



## Nawrócony Żyd: Jezus jest Mesjaszem. Sięgnąłem do głębokiej żydowskiej prawdy, która jest mocą
 - [https://deon.pl/wiara/nawrocony-zyd-jezus-jest-mesjaszem-siegnalem-do-glebokiej-zydowskiej-prawdy-ktora-jest-moca,2718524](https://deon.pl/wiara/nawrocony-zyd-jezus-jest-mesjaszem-siegnalem-do-glebokiej-zydowskiej-prawdy-ktora-jest-moca,2718524)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T05:00:00+00:00



## Jaki był Franciszek Pieczka, że każdy chciał się z nim zaprzyjaźnić?
 - [https://deon.pl/czytelnia/jaki-byl-franciszek-pieczka-ze-kazdy-chcial-sie-z-nim-zaprzyjaznic,2729438](https://deon.pl/czytelnia/jaki-byl-franciszek-pieczka-ze-kazdy-chcial-sie-z-nim-zaprzyjaznic,2729438)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-02T03:00:00+00:00



