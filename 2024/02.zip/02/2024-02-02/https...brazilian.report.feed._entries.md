# Source:The Brazilian Report, URL:https://brazilian.report/feed/, language:en-US

## Tax cases to take center stage in Supreme Court 2024 term
 - [https://brazilian.report/power/2024/02/02/supreme-court-government-tax-cases](https://brazilian.report/power/2024/02/02/supreme-court-government-tax-cases)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2024-02-02T17:33:34+00:00

<p>The post <a href="https://brazilian.report/power/2024/02/02/supreme-court-government-tax-cases/">Tax cases to take center stage in Supreme Court 2024 term</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## São Paulo mayor goes after maligned energy supplier
 - [https://brazilian.report/power/2024/02/02/sao-paulo-enel-mayor](https://brazilian.report/power/2024/02/02/sao-paulo-enel-mayor)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2024-02-02T16:38:06+00:00

<p>The post <a href="https://brazilian.report/power/2024/02/02/sao-paulo-enel-mayor/">São Paulo mayor goes after maligned energy supplier</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

## Single-dose Brazilian dengue vaccine hits almost 80 percent efficacy
 - [https://brazilian.report/liveblog/politics-insider/2024/02/02/brazilian-dengue-vaccine-80-percent-efficacy](https://brazilian.report/liveblog/politics-insider/2024/02/02/brazilian-dengue-vaccine-80-percent-efficacy)
 - RSS feed: https://brazilian.report/feed/
 - date published: 2024-02-02T14:23:50+00:00

<p>A dengue vaccine being developed by the Butantan Institute, a major research facility owned by the São Paulo state government and the largest vaccine manufacturer in Latin America, had an efficacy of 79.6 percent in clinical trials, according to results published Thursday in The New England Journal of Medicine. Butantan conducted a three-year clinical trial [&#8230;]</p>
<p>The post <a href="https://brazilian.report/liveblog/politics-insider/2024/02/02/brazilian-dengue-vaccine-80-percent-efficacy/">Single-dose Brazilian dengue vaccine hits almost 80 percent efficacy</a> appeared first on <a href="https://brazilian.report">The Brazilian Report</a>.</p>

