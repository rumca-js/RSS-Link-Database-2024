# Source:BBC, URL:https://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Six Nations highlights: France 17-38 Ireland
 - [https://www.bbc.co.uk/sport/av/rugby-union/68189491?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/rugby-union/68189491?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T22:53:52+00:00

Watch highlights as Ireland record their biggest ever away win in France, beating the 14-man home side 38-17, to begin the defence of their Six Nations crown.

## Six Nations: Ireland claim biggest ever away win over France
 - [https://www.bbc.co.uk/sport/rugby-union/68182019?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/68182019?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T22:00:55+00:00

Ireland begin their Six Nations title defence in momentous fashion with a rare bonus-point away win over 14-man France in Marseille.

## Bristol City 0-1 Leeds United: Wilfried Gnonto scores as Leeds go second in Championship
 - [https://www.bbc.co.uk/sport/football/68102462?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68102462?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T22:00:03+00:00

Leeds United move up to second in the Championship as they continue their fine form with victory at Bristol City.

## Afcon 2023: DR Congo 3-1 Guinea - Leopards come from behind to make last four
 - [https://www.bbc.co.uk/sport/football/68102469?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68102469?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T21:58:11+00:00

Yoane Wissa scores a penalty as DR Congo come from behind to beat Guinea 3-1 in the quarter-finals at the 2023 Africa Cup of Nations.

## Carl Weathers, Apollo Creed from Rocky movies, dies aged 76
 - [https://www.bbc.co.uk/news/world-us-canada-68188746?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68188746?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T20:56:14+00:00

Carl Weathers, former NFL player turned Hollywood actor who starred in the Rocky movies, dies aged 76

## Car boss hits back at Range Rover theft 'myth'
 - [https://www.bbc.co.uk/news/business-68188064?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-68188064?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T20:39:44+00:00

The boss of JLR says there is misinformation about Range Rover vulnerability to theft.

## Fani Willis: Georgia prosecutors in Trump election case admit relationship
 - [https://www.bbc.co.uk/news/world-us-canada-68188400?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68188400?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T19:52:08+00:00

But Fulton County District Attorney Fani Willis says conflict of interest claims are in "bad faith".

## Jonathan Morgan: Sheffield United Women sack head coach
 - [https://www.bbc.co.uk/sport/football/68186853?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68186853?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T19:42:37+00:00

Sheffield United sack Jonathan Morgan as head coach of the women's team after his position became "no longer tenable".

## Jonnie Irwin: Escape to the Country and A Place in the Sun host dies aged 50
 - [https://www.bbc.co.uk/news/entertainment-arts-63760036?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-63760036?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T19:36:29+00:00

The TV host was diagnosed with terminal cancer in 2020 after the disease had spread from his lungs.

## Clapham alkali attack suspect Abdul Shokoor Ezedi last seen at King's Cross
 - [https://www.bbc.co.uk/news/uk-68186427?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68186427?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T19:03:06+00:00

Police issue new images of Abdul Shokoor Ezedi as a nationwide manhunt continues.

## Tyson Fury v Oleksandr Usyk undisputed heavyweight title fight off after Briton sustains cut
 - [https://www.bbc.co.uk/sport/boxing/68187055?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/68187055?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T18:43:53+00:00

Tyson Fury's undisputed heavyweight title fight against Oleksandr Usyk is postponed after the Briton sustains a cut in training.

## Six Nations 2024: England captain Jamie George wants 'intensity' in curtain-raiser against Italy
 - [https://www.bbc.co.uk/sport/rugby-union/68180191?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/68180191?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T18:23:50+00:00

England are favourites to extend their perfect record against the Azzurri in Rome, but captain Jamie George wants a performance fitting of the travelling "white wall" of English fans.

## UK universities to review international student admissions
 - [https://www.bbc.co.uk/news/education-68186670?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-68186670?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T18:14:14+00:00

Universities UK says students must have confidence that the system is 'fair, transparent and robust'.

## Italian mafia boss who escaped from prison using bed sheets recaptured in France
 - [https://www.bbc.co.uk/news/world-europe-68186499?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-68186499?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T18:08:52+00:00

Marco Raduano had been on the run for a year before he was tracked down in Corsica, France.

## Captain Tom spa pool in Marston Moretaine demolished
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-68181128?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-68181128?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T17:47:04+00:00

A hot tub is seen being hoisted away from the complex at the army veteran's former home.

## Said Benrahma: West Ham confirm winger has joined Lyon on loan
 - [https://www.bbc.co.uk/sport/football/68187050?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68187050?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T17:32:58+00:00

West Ham confirm Algerian winger Said Benrahma has joined Lyon on loan for the remainder of the season.

## Jodie Burrage: British number two beaten by Jelena Ostapenko at Linz Open
 - [https://www.bbc.co.uk/sport/tennis/68186855?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/68186855?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T17:26:29+00:00

British number two Jodie Burrage is knocked out in the quarter-finals of the Linz Open by Jelena Ostapenko of Latvia.

## Misinformation spreads in China on ‘civil war’ in Texas
 - [https://www.bbc.co.uk/news/world-us-canada-68185317?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68185317?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T17:15:36+00:00

Chinese social media cheers intensifying standoff between Texas and the White House over illegal migrants.

## Segun Aremu: Nigerian traditional monarch shot dead and wife kidnapped
 - [https://www.bbc.co.uk/news/world-africa-68179807?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-68179807?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T17:07:30+00:00

Gunmen stormed the palace of traditional ruler Segun Aremu amid concern about a wave of abductions.

## Sick Devon donkey saved by being given 24 litres of cola
 - [https://www.bbc.co.uk/news/uk-england-devon-68172871?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-devon-68172871?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T16:37:23+00:00

Joey's condition was so bad he could not eat or drink anything before the fizzy drink treatment.

## Stormont: Party leaders discuss priorities for new executive
 - [https://www.bbc.co.uk/news/uk-northern-ireland-68174458?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-68174458?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T16:26:54+00:00

Northern Ireland's assembly will meet on Saturday, two years after power-sharing collapsed in 2022.

## MPs back plans to tackle dog attacks on livestock
 - [https://www.bbc.co.uk/news/uk-politics-68185433?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-68185433?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T16:24:14+00:00

Proposed legislation would give police greater powers to prosecute dog owners for attacks on farm animals.

## Greta Thunberg: Case thrown because of 'no evidence'
 - [https://www.bbc.co.uk/news/uk-england-london-68180317?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-68180317?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T16:08:16+00:00

She was arrested at a demonstration in October, with the judge concluding that the law was unclear.

## Sutton's Premier League predictions v Ski Sunday presenter Leigh
 - [https://www.bbc.co.uk/sport/football/68159282?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68159282?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:57:49+00:00

BBC Sport football expert Chris Sutton takes on Ski Sunday presenter Ed Leigh for this weekend's Premier League predictions.

## The teenagers who tried to get away with murdering Brianna Ghey
 - [https://www.bbc.co.uk/news/uk-england-manchester-67727331?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-67727331?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:56:33+00:00

The pair who killed Brianna Ghey in broad daylight arrogantly thought they were too clever to be caught.

## Erling Haaland: Pep Guardiola insists striker is happy at Manchester City
 - [https://www.bbc.co.uk/sport/football/68184616?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68184616?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:42:00+00:00

Manchester City boss Pep Guardiola dismisses claims by Spanish media that Erling Haaland is unhappy at the club.

## Woman arrested over Daniel Khalife alleged prison escape
 - [https://www.bbc.co.uk/news/uk-68183355?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68183355?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:35:19+00:00

A 25-year-old woman is arrested on suspicion of assisting an offender, police say.

## Pair given life sentences for 'brutal and planned' murder
 - [https://www.bbc.co.uk/news/uk-england-manchester-68184224?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-68184224?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:34:51+00:00

Scarlett Jenkinson is given a 22-year minimum sentence while Eddie Ratcliffe is detained for 20 years.

## Brianna Ghey: Watch as judge sentences killers Jenkinson and Ratcliffe
 - [https://www.bbc.co.uk/news/uk-68178356?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68178356?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:34:37+00:00

Mrs Justice Yip passes sentence to Scarlett Jenkinson and Eddie Ratcliffe for the teenager's murder.

## Groundhog Day: Did Punxsutawney Phil see his shadow?
 - [https://www.bbc.co.uk/news/world-us-canada-68172216?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68172216?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:34:34+00:00

America's favourite groundhog - and meteorologist - predicted an early spring at this year's ceremony.

## Queen Camilla taps into her inner Strictly fan
 - [https://www.bbc.co.uk/news/uk-68182921?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68182921?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:33:13+00:00

The Queen "adores" Strictly Come Dancing and meets Johannes, but does not tune into Love Island.

## Arsenal v Liverpool: Is Sunday's Premier League game 'must-win' for Gunners?
 - [https://www.bbc.co.uk/sport/football/68172904?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68172904?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:28:52+00:00

Sunday's Premier League meeting between Arsenal and Liverpool at Emirates Stadium could be key in deciding where the title ends up this season.

## Manchester United: Erik ten Hag to get 'creative' after failing to sign striker
 - [https://www.bbc.co.uk/sport/football/68182143?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68182143?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:19:41+00:00

Manchester United manager Erik ten Hag says he will get "creative" with his team selections after failing to sign a striker in January.

## Tate Modern: Man dies after falling from London gallery
 - [https://www.bbc.co.uk/news/uk-england-london-68180323?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-68180323?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:09:40+00:00

Inquiries are under way to identify the man and notify his family, the Met Police say.

## Alkali attack suspect Abdul-Shokoor Ezedi was not eligible for asylum
 - [https://www.bbc.co.uk/news/uk-68181899?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68181899?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:07:49+00:00

Home Office rules suggest Abdul-Shokoor Ezedi's criminal record should have stopped him being granted asylum.

## Post Office victims had lives 'utterly destroyed'
 - [https://www.bbc.co.uk/news/business-68160711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-68160711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:04:29+00:00

Lawyers representing sub-postmasters say their physical and mental health was damaged by the Horizon IT scandal.

## Ukraine war: Two French volunteers killed in Russian drone strike - Macron confirms
 - [https://www.bbc.co.uk/news/world-europe-68182613?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-68182613?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:02:37+00:00

President Emmanuel Macron condemns as "cowardly" Thursday's Russian drone attack in southern Ukraine.

## England name two T20 squads for New Zealand tour
 - [https://www.bbc.co.uk/sport/cricket/68182141?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/68182141?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T15:00:41+00:00

Nat Sciver-Brunt, Sophie Ecclestone, Alice Capsey and Danni Wyatt will miss England's first three T20 matches against New Zealand.

## Lewis Hamilton: Toto Wolff 'surprised' by Ferrari decision but 'holds no grudge'
 - [https://www.bbc.co.uk/sport/formula1/68181535?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/68181535?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T14:58:48+00:00

Mercedes team principal Toto Wolff describes Lewis Hamilton's decision to join Ferrari in 2025 as a "surprise" but says it could provide the opportunity to "do something bold".

## Yorkshire: Colin Graves-led takeover approved by county members
 - [https://www.bbc.co.uk/sport/cricket/68179607?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/68179607?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T14:26:57+00:00

Yorkshire's members approve a controversial takeover bid of the cash-strapped club by a consortium led by former chairman Colin Graves.

## Bristol Light festival launches to brighten up city
 - [https://www.bbc.co.uk/news/uk-england-bristol-68180569?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-68180569?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T14:24:01+00:00

Bristol Light Festival has begun and will bring everything from penguins to astronauts to the city.

## Alice Wood jailed for running over and killing her fiance in Cheshire
 - [https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-68180241?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-stoke-staffordshire-68180241?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T14:00:25+00:00

Alice Wood, 24, "used her car as a weapon" on Ryan Watson after the pair rowed at a party.

## India v England: Shoaib Bashir says visa delay makes debut more memorable
 - [https://www.bbc.co.uk/sport/cricket/68181425?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/68181425?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T13:54:33+00:00

Spinner Shaoib Bashir says the two wickets he took on his England debut will be more memorable because of his problems getting into India.

## The CCTV that helped convict Brianna Ghey's killers
 - [https://www.bbc.co.uk/news/uk-68178354?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68178354?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T13:43:18+00:00

Brianna Ghey and her murderers were seen on camera multiple times the day she was killed.

## I’ve never felt such grief, says Brianna's mother
 - [https://www.bbc.co.uk/news/uk-england-manchester-68145441?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-68145441?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T13:40:59+00:00

Scarlett Jenkinson and Eddie Ratcliffe murdered the 16-year-old schoolgirl in a park in Cheshire.

## Abdul Shokoor Ezedi: What do we know of Clapham attack suspect?
 - [https://www.bbc.co.uk/news/uk-68179839?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68179839?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T13:30:37+00:00

The 35-year-old convicted sex offender is believed to live in Newcastle and had been granted asylum.

## Derek Draper: Elton John and Tony Blair attend funeral service
 - [https://www.bbc.co.uk/news/entertainment-arts-68179439?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-68179439?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T13:13:49+00:00

Stars and politicians gather to mourn Kate Garraway's husband at a private ceremony in London.

## Can Atlantic storms affect the colour of sunrise?
 - [https://www.bbc.co.uk/weather/features/68180401?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/weather/features/68180401?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T13:07:45+00:00

BBC Weather Watchers have been sending in their captivating sunrise photos.

## Western officials in protest over Israel Gaza policy
 - [https://www.bbc.co.uk/news/world-us-canada-68177357?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68177357?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T12:56:13+00:00

More than 800 officials in the US and Europe have penned a letter calling for more pressure on Israel.

## Killer was moved to Brianna Ghey's school after spiking younger girl
 - [https://www.bbc.co.uk/news/uk-68153179?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68153179?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T12:30:54+00:00

Scarlett Jenkinson was moved after drugging a younger pupil with a cannabis sweet, BBC News finds.

## India v England: Yashasvi Jaiswal hundred keeps tourists at bay
 - [https://www.bbc.co.uk/sport/cricket/68171306?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/68171306?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T11:38:31+00:00

England admirably cling on to India, despite Yashasvi Jaiswal making a sublime century on the opening day of the second Test in Visakhapatnam.

## Footage of Brianna Ghey's killers being arrested
 - [https://www.bbc.co.uk/news/uk-68178352?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68178352?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T11:12:35+00:00

Scarlett Jenkinson and Eddie Ratcliffe stabbed Brianna to death in a park in Cheshire in 2023.

## UCI Track Nations Cup 2024: Great Britain win two golds among five medals on day one
 - [https://www.bbc.co.uk/sport/cycling/68177881?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cycling/68177881?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T10:55:57+00:00

Great Britain win women's team sprint and men's team pursuit golds among five medals on day one at the UCI Track Nations Cup in Adelaide.

## Suicide Squad game makers accused of holding up reviews
 - [https://www.bbc.co.uk/news/newsbeat-68173718?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-68173718?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T09:16:48+00:00

Kill the Justice League's release arrives as a debate over review copies rages online.

## Armando Broja: Why clubs are selling homegrown academy players for profit
 - [https://www.bbc.co.uk/sport/football/68171022?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68171022?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T09:04:10+00:00

Chelsea and Manchester City are among the best in Europe at profiting from academy player sales.

## Premier League fantasy football tips: Erling Haaland, Julian Alvarez, Darwin Nunez, Ollie Watkins
 - [https://www.bbc.co.uk/sport/football/68172891?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68172891?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T07:37:03+00:00

Should Haaland return for Manchester City? Alistair Bruce-Ball previews gameweek 23.

## Six Nations 2024: Italy chasing first win over England say physicality key
 - [https://www.bbc.co.uk/sport/rugby-union/68171620?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/68171620?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T07:08:38+00:00

Perennial underdogs Italy are targeting their best ever Six Nations and a first victory over England in this year's opening match, says Azurri scrum-half Stephen Varney.

## Fawlty Towers stage show heads to London's West End
 - [https://www.bbc.co.uk/news/entertainment-arts-68171380?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-68171380?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T07:02:15+00:00

Three episodes of the TV series have been combined to create the plot of the stage adaptation.

## Joshua Buatsi v Dan Azeez: Anthony Yarde preview British light-heavyweight fight
 - [https://www.bbc.co.uk/sport/boxing/68068603?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/68068603?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T06:24:17+00:00

In his BBC Sport column, light-heavyweight Anthony Yarde previews Joshua Buatsi v Dan Azeez on Saturday and says the time is now for him to fight the winner.

## Ukraine war: How Russia's war is changing childhood in Ukraine
 - [https://www.bbc.co.uk/news/world-europe-68170396?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-68170396?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T06:17:30+00:00

In Ukraine, six-year-old Nika now attends classes in a subway station to avoid Russian bombardment.

## New planets have flattened shapes like Smarties say scientists
 - [https://www.bbc.co.uk/news/uk-england-lancashire-68173794?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-68173794?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T06:17:28+00:00

University of Central Lancashire scientists used computer simulations to model the formation of planets.

## ‘They’re climbing on my car’: Alaskan bears spotted in Florida
 - [https://www.bbc.co.uk/news/world-us-canada-68177127?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68177127?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T06:13:56+00:00

Two kodiak bear cubs were spotted wandering more than 3,600 miles (5,800 km) from their usual habitat.

## Lincoln guinea pigs' 'luxury hotel' TikTok hit
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-68171016?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lincolnshire-68171016?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T06:12:47+00:00

More than 140 of the animals live in the air-conditioned shed - dubbed "the Ritz".

## UFC: Molly McCann says she considered retirement before dropping to strawweight
 - [https://www.bbc.co.uk/sport/mixed-martial-arts/68155372?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/mixed-martial-arts/68155372?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T06:10:35+00:00

Molly McCann, who makes her UFC strawweight debut against Diana Belbita on Saturday, says she considered retirement after July's defeat by Julija Stoliarenko in London.

## Brianna Ghey: Why teenagers who killed her can be named
 - [https://www.bbc.co.uk/news/uk-england-manchester-68145426?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-68145426?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T05:59:06+00:00

A ban on naming the two 16-year-olds who murdered Brianna Ghey will be lifted at their sentencing.

## Everything we know about the search for the Clapham attacker
 - [https://www.bbc.co.uk/news/uk-68176858?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68176858?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T04:42:33+00:00

Police have warned Abdul Shokoor Ezedi should not be approached as the search for him continues.

## No ordinary backyards... the best garden photos of year
 - [https://www.bbc.co.uk/news/in-pictures-68127991?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/in-pictures-68127991?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T03:46:05+00:00

The winning images of this year's International Garden Photographer of the Year competition.

## 'Poison seller' linked to 90 UK deaths to stand trial
 - [https://www.bbc.co.uk/news/world-us-canada-68176391?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68176391?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T02:27:25+00:00

Prosecutors have also upgraded charges against him from second-degree to first-degree murder.

## 'We're not playing by the same rules': French farmers on protests
 - [https://www.bbc.co.uk/news/world-europe-68173000?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-68173000?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T02:07:06+00:00

Farmers like Yves Coppé are concerned about the future of farming and the government's policies.

## Nairobi fire: At least 29 injured in Kenya gas plant explosion
 - [https://www.bbc.co.uk/news/world-africa-68176857?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-68176857?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T01:48:31+00:00

Witnesses described feeling tremors immediately after the blast in south-east Nairobi.

## Transfer deadline day 2024: Premier League January spending falls to 12-year low
 - [https://www.bbc.co.uk/sport/football/68174872?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68174872?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T01:48:13+00:00

Spending by Premier League clubs in January dips to a 12-year low after three successive record-breaking windows.

## Mother of US school shooter takes the stand
 - [https://www.bbc.co.uk/news/world-us-canada-68176413?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68176413?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T01:38:07+00:00

The mother of Ethan Crumbley said she was unaware he had serious mental health issues despite warnings, ahead of the 2021 school shooting.

## Watch: Tesla Norway fjord crash passengers saved by floating sauna users
 - [https://www.bbc.co.uk/news/world-europe-68177125?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-68177125?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T01:05:26+00:00

The users of a sauna boat came to the rescue of two people who crashed into a fjord in Oslo.

## Quiz of the week: Who led the Vikings in Shetland’s Up Helly Aa fire festival?
 - [https://www.bbc.co.uk/news/world-68168938?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-68168938?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T00:24:47+00:00

How closely have you been paying attention to what has been going on over the past seven days?

## 'A dream come true' - Man Utd matchwinner Mainoo 'gives Seedorf vibes'
 - [https://www.bbc.co.uk/sport/football/68176430?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68176430?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T00:12:20+00:00

After his dramatic late winner against Wolves, BBC Sport charts the rise of Manchester United youngster Kobbie Mainoo.

## Toxic run-off from roads not monitored, BBC finds
 - [https://www.bbc.co.uk/news/science-environment-68130715?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-68130715?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T00:11:43+00:00

River flowing past the white 'Bake Off' tent is among those polluted by chemicals and tyre particles.

## Should more British homes be built using straw?
 - [https://www.bbc.co.uk/news/business-68005481?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-68005481?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T00:09:14+00:00

Cheap, highly insulating and sustainable, straw has a lot of potential for the building industry.

## Improvements in cancer survival rates slowing down
 - [https://www.bbc.co.uk/news/health-68170218?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-68170218?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T00:03:24+00:00

The number of people beating the disease was rising five times faster in the 2000s.

## Cash offer for new childcare workers amid shortage
 - [https://www.bbc.co.uk/news/education-68128705?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-68128705?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T00:03:22+00:00

A £1,000 cash payment will be offered to thousands of workers joining the early-years sector in England.

## Patient 'reborn' after Royal Papworth Hospital lung transplant
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-68166422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-68166422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T00:03:22+00:00

Georgie Cooper says: "It was amazing to feel the air in my lungs after my transplant."

## Water bills to rise above inflation in April
 - [https://www.bbc.co.uk/news/business-68172008?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-68172008?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T00:03:21+00:00

Water companies in England and Wales expect an increase of 6%, with an 8.8% rise in Scotland.

## AI will not be the destroyer of jobs - Bank chief
 - [https://www.bbc.co.uk/news/technology-68170068?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-68170068?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-02T00:03:18+00:00

Bank of England governor says AI has "great potential" after Lords report urged UK to embrace AI.

