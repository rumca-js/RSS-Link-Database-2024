# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## Argylle Author Revealed
 - [https://bookriot.com/argylle-author-revealed](https://bookriot.com/argylle-author-revealed)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-02T23:07:55+00:00

Are you surprised by who the real author is?

## Book Riot’s Deals of the Day for February 2, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-february-2-2024](https://bookriot.com/book-riots-deals-of-the-day-for-february-2-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-02T16:18:11+00:00

Dragons, spy cats, sharks, Pompeii, and even some Ancient Egypt, all in today's best book deals!

## American Intolerance and Book Bans: Book Censorship News, February 2, 2024
 - [https://bookriot.com/american-intolerance-and-book-bans](https://bookriot.com/american-intolerance-and-book-bans)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-02T13:00:00+00:00

Seventy-five percent of parents do not believe in the necessity of diverse books. But why? That, plus this week's book censorship news.

## 9 Of The Best New Children’s Books Out February 2024
 - [https://bookriot.com/february-2024-new-childrens-books](https://bookriot.com/february-2024-new-childrens-books)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-02T12:30:00+00:00

All of the new February children's book releases you'll want on your TBR.

## 10 New Nonfiction Book Releases of February 2024
 - [https://bookriot.com/new-nonfiction-books-february-2024](https://bookriot.com/new-nonfiction-books-february-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-02T12:00:00+00:00

New nonfiction books hitting shelves in February 2024 include memoirs, food stories, ex-wives, and more.

## Great Adult Books with YA Appeal
 - [https://bookriot.com/adult-books-with-ya-appeal](https://bookriot.com/adult-books-with-ya-appeal)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-02T11:30:00+00:00

YA reader looking for some great adult books? We've got you—or your favorite teen readers—covered.

## Just How Much Has LGBTQ+ Representation Grown in Middle Grade In The Last Half Decade?
 - [https://bookriot.com/lgbtq-representation-in-middle-grade](https://bookriot.com/lgbtq-representation-in-middle-grade)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-02T11:00:00+00:00

LGBTQ+ books have grown in number over the last 5 years, offering a range of stories beyond that of coming out.

