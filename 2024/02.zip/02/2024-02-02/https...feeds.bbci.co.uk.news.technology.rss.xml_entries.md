# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Suicide Squad makers accused of holding up reviews
 - [https://www.bbc.co.uk/news/newsbeat-68173718](https://www.bbc.co.uk/news/newsbeat-68173718)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-02-02T09:16:48+00:00

Kill the Justice League's release arrives as a debate over review copies rages online.

## Guinea pigs in luxury shed become TikTok hit
 - [https://www.bbc.co.uk/news/uk-england-lincolnshire-68171016](https://www.bbc.co.uk/news/uk-england-lincolnshire-68171016)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-02-02T06:12:47+00:00

More than 140 of the animals live in the air-conditioned shed - dubbed "the Ritz".

## AI will not be the destroyer of jobs, says Bank chief
 - [https://www.bbc.co.uk/news/technology-68170068](https://www.bbc.co.uk/news/technology-68170068)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-02-02T00:03:18+00:00

Bank of England governor says AI has "great potential" as Lords report urges UK to embrace AI.

