# Source:Colombia News | Colombia Reports, URL:https://colombiareports.com/feed/, language:en-US

## Ecuador vows to repatriate 1,500 convicts to Colombia
 - [https://colombiareports.com/ecuador-vows-to-repatriate-1500-convicts-to-colombia](https://colombiareports.com/ecuador-vows-to-repatriate-1500-convicts-to-colombia)
 - RSS feed: https://colombiareports.com/feed/
 - date published: 2024-02-02T14:56:14+00:00

<p>Ecuador&#8217;s government will repatriate some 1,500 Colombian prisoners in an attempt to combat organized crime. The mass deportation of convicts follows an outburst of violence by illegal armed groups in&#8230;</p>
<p>The post <a href="https://colombiareports.com/ecuador-vows-to-repatriate-1500-convicts-to-colombia/" rel="nofollow">Ecuador vows to repatriate 1,500 convicts to Colombia</a> appeared first on <a href="https://colombiareports.com" rel="nofollow">Colombia News | Colombia Reports</a>.</p>

