# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## KaOS Linux 2024.01 Released with a Pure KDE Plasma 6-Based Environment
 - [https://9to5linux.com/kaos-linux-2024-01-released-with-a-pure-kde-plasma-6-based-environment](https://9to5linux.com/kaos-linux-2024-01-released-with-a-pure-kde-plasma-6-based-environment)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-02-02T21:44:42+00:00

<p>KaOS Linux 2024.01 independent distribution inspired by Arch Linux is now available for download with a pure KDE Plasma 6-based environment.</p>
<p>The post <a href="https://9to5linux.com/kaos-linux-2024-01-released-with-a-pure-kde-plasma-6-based-environment">KaOS Linux 2024.01 Released with a Pure KDE Plasma 6-Based Environment</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Clonezilla Live 3.1.2 Released with Linux Kernel 6.6 LTS and Memtest86+ 7.00
 - [https://9to5linux.com/clonezilla-live-3-1-2-released-with-linux-kernel-6-6-lts-and-memtest86-7-00](https://9to5linux.com/clonezilla-live-3-1-2-released-with-linux-kernel-6-6-lts-and-memtest86-7-00)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-02-02T10:04:23+00:00

<p>Clonezilla Live 3.1.2 live system for disk cloning and imaging is now available for download powered by Linux kernel 6.6 LTS and featuring updated components and various enhancements.</p>
<p>The post <a href="https://9to5linux.com/clonezilla-live-3-1-2-released-with-linux-kernel-6-6-lts-and-memtest86-7-00">Clonezilla Live 3.1.2 Released with Linux Kernel 6.6 LTS and Memtest86+ 7.00</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Immutable Distro Nitrux 3.3 Is Out Now Powered by Linux Kernel 6.7
 - [https://9to5linux.com/immutable-distro-nitrux-3-3-is-out-now-powered-by-linux-kernel-6-7](https://9to5linux.com/immutable-distro-nitrux-3-3-is-out-now-powered-by-linux-kernel-6-7)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-02-02T09:12:55+00:00

<p>Nitrux 3.3 systemd-free and immutable distribution is now available for download powered by the latest Linux 6.7 kernel series. Here's what's new!</p>
<p>The post <a href="https://9to5linux.com/immutable-distro-nitrux-3-3-is-out-now-powered-by-linux-kernel-6-7">Immutable Distro Nitrux 3.3 Is Out Now Powered by Linux Kernel 6.7</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## OBS Studio 30.1 Beta Adds AV1 Support for VA-API, PipeWire Camera Source
 - [https://9to5linux.com/obs-studio-30-1-beta-adds-av1-support-for-va-api-pipewire-camera-source](https://9to5linux.com/obs-studio-30-1-beta-adds-av1-support-for-va-api-pipewire-camera-source)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-02-02T08:25:27+00:00

<p>OBS Studio 30.1 is now available for public beta testing with AV1 support for VA-API, PipeWire Camera source, HDR for HEVC over RTMP, and many other new features.</p>
<p>The post <a href="https://9to5linux.com/obs-studio-30-1-beta-adds-av1-support-for-va-api-pipewire-camera-source">OBS Studio 30.1 Beta Adds AV1 Support for VA-API, PipeWire Camera Source</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

