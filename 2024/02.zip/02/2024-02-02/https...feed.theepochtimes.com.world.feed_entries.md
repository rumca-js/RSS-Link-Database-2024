# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## David Krayden: There Should be No Meddling With Canada’s Election Laws
 - [https://www.theepochtimes.com/opinion/david-krayden-there-should-be-no-meddling-with-canadas-election-laws-5579225](https://www.theepochtimes.com/opinion/david-krayden-there-should-be-no-meddling-with-canadas-election-laws-5579225)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T23:12:22+00:00

Elections Canada workers place signage at the Halifax Convention Centre in Halifax as they prepare for the polls to open in the federal election on Sept. 20, 2021. (Andrew Vaughan/The Canadian Press)

## Ontario Health Minister Says Province Not Following Alberta in Restricting Child Transition
 - [https://www.theepochtimes.com/world/ontario-health-minister-says-province-not-following-alberta-in-restricting-child-transition-5579535](https://www.theepochtimes.com/world/ontario-health-minister-says-province-not-following-alberta-in-restricting-child-transition-5579535)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T23:09:49+00:00

Ontario Health Minister Sylvia Jones makes an announcement at Toronto’s Sunnybrook Hospital on Aug. 18, 2022. (The Canadian Press/Chris Young)

## Politics Trumped Legal Advice in Decision Not to Revoke Citizenship of Nazi in 1960s
 - [https://www.theepochtimes.com/world/politics-trumped-legal-advice-in-decision-not-to-revoke-citizenship-of-nazi-in-1960s-5579554](https://www.theepochtimes.com/world/politics-trumped-legal-advice-in-decision-not-to-revoke-citizenship-of-nazi-in-1960s-5579554)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T23:07:46+00:00

Reporters swarm around Pierre Trudeau after he was sworn-in as justice minister in Ottawa on April 4, 1967. (The Canadian Press/Chuck Mitchell)

## Landholders Deserve Better Consultation on Renewables
 - [https://www.theepochtimes.com/world/landholders-deserve-better-consultation-on-renewables-5579103](https://www.theepochtimes.com/world/landholders-deserve-better-consultation-on-renewables-5579103)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T23:00:01+00:00

A supplied image obtained on Nov. 27, 2020, of a wind farm at Granville Harbour in Tasmania, Australia. (AAP Image/Courtesy of Granville Harbour Wind Farm)

## Trudeau Calls Alberta’s New Child Transition Restrictions ‘Fight Against LGBT Youth’
 - [https://www.theepochtimes.com/world/trudeau-calls-albertas-new-child-transition-restrictions-fight-against-lgbt-youth-5579529](https://www.theepochtimes.com/world/trudeau-calls-albertas-new-child-transition-restrictions-fight-against-lgbt-youth-5579529)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T22:42:33+00:00

Prime Minister Justin Trudeau speaks to members of the Chamber of Commerce of Metropolitan Montreal, in Montreal, on Jan. 16, 2024. (The Canadian Press/Christinne Muschi)

## US Launches Retaliatory Strikes on Iran-Linked Targets in Iraq, Syria
 - [https://www.theepochtimes.com/world/us-launches-retaliatory-strikes-on-iran-linked-targets-in-iraq-syria-5579531](https://www.theepochtimes.com/world/us-launches-retaliatory-strikes-on-iran-linked-targets-in-iraq-syria-5579531)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T22:11:04+00:00

A Royal Air Force Typhoon FGR4 taking off from an unidentified base for attacks on Houthi targets in Yemen on Jan. 22, 2023. (Ministry of Defence)

## Lawyer for Father of Murdered BC Girl Denies Client Brought Gun to Ali Verdict
 - [https://www.theepochtimes.com/world/lawyer-for-father-of-murdered-bc-girl-denies-client-brought-gun-to-ali-verdict-5579533](https://www.theepochtimes.com/world/lawyer-for-father-of-murdered-bc-girl-denies-client-brought-gun-to-ali-verdict-5579533)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T22:11:02+00:00

The Law Courts building, which is home to B.C. Supreme Court and the Court of Appeal, is seen in Vancouver, on Nov. 23, 2023. (The Canadian Press/Darryl Dyck)

## Charges Dropped Against Freedom Convoy’s ‘Peace Man’
 - [https://www.theepochtimes.com/world/charges-dropped-against-freedom-convoys-peace-man-5579474](https://www.theepochtimes.com/world/charges-dropped-against-freedom-convoys-peace-man-5579474)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T22:10:10+00:00

Protester Dana-Lee Melfi says the truckers and their supporters in central Ottawa are peaceful. (Richard Moore/The Epoch Times)

## Meta Reveals Plans to Launch AI Services in Australia
 - [https://www.theepochtimes.com/world/meta-reveals-plans-to-launch-ai-services-in-australia-5579095](https://www.theepochtimes.com/world/meta-reveals-plans-to-launch-ai-services-in-australia-5579095)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T22:00:45+00:00

Meta Founder and CEO Mark Zuckerberg testifies before the Senate Judiciary Committee in Washington on Jan. 31, 2024. (Madalina Vasiliu/The Epoch Times)

## Despite Talk of Parental Rights, Ontario Schools Still Keep Gender Changes Secret
 - [https://www.theepochtimes.com/world/despite-talk-of-parental-rights-ontario-schools-still-keep-gender-changes-secret-5577794](https://www.theepochtimes.com/world/despite-talk-of-parental-rights-ontario-schools-still-keep-gender-changes-secret-5577794)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T21:53:56+00:00

A grade six classroom in Scarborough, Ont., in a file photo. (Nathan Denette/The Canadian Press)

## Catherine Tait Says CBC Needs New Financial Model, Not New Mandate
 - [https://www.theepochtimes.com/world/catherine-tait-says-cbc-needs-new-financial-model-not-new-mandate-5579519](https://www.theepochtimes.com/world/catherine-tait-says-cbc-needs-new-financial-model-not-new-mandate-5579519)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T21:42:20+00:00

CBC president and chief executive Catherine Tait waits to appear before the Heritage committee in Ottawa on Jan. 30, 2024. (The Canadian Press/Adrian Wyld)

## Bidens Attend Dignified Transfer of US Troops Killed in Jordan Drone Attack
 - [https://www.theepochtimes.com/us/bidens-attend-dignified-transfer-of-us-troops-killed-in-jordan-drone-attack-5579402](https://www.theepochtimes.com/us/bidens-attend-dignified-transfer-of-us-troops-killed-in-jordan-drone-attack-5579402)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T21:37:09+00:00

This combination of photos provided by Shawn Sanders (left), and the U.S. Army (center and right), shows, from left to right, Spc. Kennedy Sanders, Sgt. William Jerome Rivers, and Spc. Breonna Alexsondria Moffett. The three U.S. Army Reserve soldiers from Georgia were killed by a drone strike in Jordan on Jan. 28, 2024. (Shawn Sanders and U.S. Army via AP)

## Lawmaker Urges State Department to Make Forced Organ Harvesting Part of Any US–China Talks
 - [https://www.theepochtimes.com/china/lawmaker-urges-state-department-to-make-forced-organ-harvesting-part-of-any-us-china-talks-5579239](https://www.theepochtimes.com/china/lawmaker-urges-state-department-to-make-forced-organ-harvesting-part-of-any-us-china-talks-5579239)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T20:59:40+00:00

Then-Secretary of the Interior Ryan Zinke speaks to reporters outside the West Wing of the White House in Washington on Aug. 16, 2018. (Samira Bouaou/The Epoch Times)

## Lawmaker Urges State Department to Make Forced Organ Harvesting Part of US–China Talks
 - [https://www.theepochtimes.com/china/lawmaker-urges-state-department-to-make-forced-organ-harvesting-part-of-us-china-talks-5579239](https://www.theepochtimes.com/china/lawmaker-urges-state-department-to-make-forced-organ-harvesting-part-of-us-china-talks-5579239)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T20:59:40+00:00

Then-Secretary of the Interior Ryan Zinke speaks to reporters outside the West Wing of the White House in Washington on Aug. 16, 2018. (Samira Bouaou/The Epoch Times)

## Cory Morgan: Calgary’s Single-Use Bylaw Debacle Shows Why Municipal Politics Shouldn’t Be Ignored
 - [https://www.theepochtimes.com/opinion/cory-morgan-single-use-bylaw-debacle-in-calgary-shows-why-municipal-politics-shouldnt-be-ignored-5579178](https://www.theepochtimes.com/opinion/cory-morgan-single-use-bylaw-debacle-in-calgary-shows-why-municipal-politics-shouldnt-be-ignored-5579178)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T20:39:26+00:00

Under Calgary's single-use bylaw, restaurants have to charge customers for getting plastic or paper bags.  (Tim Boyle/Getty Images)

## LeBlanc Promises ‘Robust’ Transparency Effort at Inquiry as AG Warns Redaction Process Unsustainable
 - [https://www.theepochtimes.com/world/leblanc-promises-robust-transparency-effort-at-inquiry-as-ag-warns-redaction-process-unsustainable-5579432](https://www.theepochtimes.com/world/leblanc-promises-robust-transparency-effort-at-inquiry-as-ag-warns-redaction-process-unsustainable-5579432)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T20:33:02+00:00

Minister of Public Safety, Democratic Institutions and Intergovernmental Affairs Dominic LeBlanc scans the room as he appears as a witness at the Public Inquiry Into Foreign Interference in Federal Election Processes and Democratic Institutions in Ottawa on Feb. 2, 2024. (Adrian Wyld/The Canadian Press)

## Shots Fired at BC Home of Sikh Activist, an Associate of Slain Nijjar, Group Says
 - [https://www.theepochtimes.com/world/shots-fired-at-bc-home-of-sikh-activist-an-associate-of-slain-nijjar-group-says-5579403](https://www.theepochtimes.com/world/shots-fired-at-bc-home-of-sikh-activist-an-associate-of-slain-nijjar-group-says-5579403)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T19:18:19+00:00

A photograph of late temple president Hardeep Singh Nijjar is seen on a banner outside the Guru Nanak Sikh Gurdwara Sahib, in Surrey, B.C., on Sept. 18, 2023. (The Canadian Press/Darryl Dyck)

## Germany’s Former Spy Chief Now Being Monitored as Extremist
 - [https://www.theepochtimes.com/world/germanys-former-spy-chief-now-being-monitored-as-extremist-5578789](https://www.theepochtimes.com/world/germanys-former-spy-chief-now-being-monitored-as-extremist-5578789)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T19:03:59+00:00

Hans-Georg Maassen, former head of the Germany domestic intelligence service in Benshausen, Germany on Sept. 5, 2021. 

 (Photo by Jens SCHLUTER / AFP) (Photo by JENS SCHLUTER/AFP via Getty Images)

## Man Has Died After Falling From Tate Modern Art Gallery in London
 - [https://www.theepochtimes.com/world/man-has-died-after-falling-from-tate-modern-art-gallery-in-london-5579235](https://www.theepochtimes.com/world/man-has-died-after-falling-from-tate-modern-art-gallery-in-london-5579235)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T18:16:13+00:00

A view of the viewing gallery at the Tate Modern art gallery in south London, on Feb. 2, 2024. (Yui Mok/PA via AP)

## Cineplex to Offer $5 Movie Tickets and $5 Popcorn on Tuesdays in February
 - [https://www.theepochtimes.com/world/cineplex-to-offer-5-movie-tickets-and-5-popcorn-on-tuesdays-in-february-5579334](https://www.theepochtimes.com/world/cineplex-to-offer-5-movie-tickets-and-5-popcorn-on-tuesdays-in-february-5579334)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T18:05:39+00:00

Customers buy popcorn at a Cineplex theatre in downtown Toronto on Aug. 26, 2020. (The Canadian Press/Christopher Katsarov)

## Turning Rideau Cottage Into Prime Minister’s Permanent Home Comes With Cost: Docs
 - [https://www.theepochtimes.com/world/turning-rideau-cottage-into-prime-ministers-permanent-home-comes-with-cost-docs-5579343](https://www.theepochtimes.com/world/turning-rideau-cottage-into-prime-ministers-permanent-home-comes-with-cost-docs-5579343)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T18:05:01+00:00

A gardener works on the grounds at the Prime Minister's residence at 24 Sussex Drive in Ottawa, on May 6, 2008. (The Canadian Press/Tom Hanson)

## Israel and Allies Want ‘Regime Change’ in South Africa, Says ANC
 - [https://www.theepochtimes.com/world/israel-and-allies-want-regime-change-in-south-africa-says-anc-5579172](https://www.theepochtimes.com/world/israel-and-allies-want-regime-change-in-south-africa-says-anc-5579172)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T17:46:32+00:00

A session of the International Court of Justice (ICJ) deliberating on emergency measures against Israel following accusations by South Africa that the military operation in Gaza is a state-led genocide, in The Hague, Netherlands, on Jan. 26, 2024. (Piroschka van de Wouw/Reuters)

## Business, Consumer Insolvencies Rise in December as Higher Rates Bite
 - [https://www.theepochtimes.com/world/business-consumer-insolvencies-rise-in-december-as-higher-rates-bite-5579315](https://www.theepochtimes.com/world/business-consumer-insolvencies-rise-in-december-as-higher-rates-bite-5579315)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T17:25:43+00:00

A sign on a shop window indicates the store is closed in Ottawa, on March 23, 2020. (The Canadian Press/Adrian Wyld)

## EU Agrees to Provide Ukraine With New $54 Billion Aid Package
 - [https://www.theepochtimes.com/world/eu-agrees-to-provide-ukraine-with-new-54-billion-aid-package-5579148](https://www.theepochtimes.com/world/eu-agrees-to-provide-ukraine-with-new-54-billion-aid-package-5579148)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T17:08:06+00:00

Ukraine's President Volodymyr Zelenskyy welcomes European Commission President Ursula von der Leyen, as Russia's attack on Ukraine continues, ahead of EU summit in Kyiv, Ukraine, on Feb. 2, 2023. (Ukrainian Presidential Press Service/Handout via Reuters)

## Quebec Cold Case Murder Trial: Prosecutors Complete Evidence, Defence Granted Delay
 - [https://www.theepochtimes.com/world/quebec-cold-case-murder-trial-prosecutors-complete-evidence-defence-granted-delay-5579305](https://www.theepochtimes.com/world/quebec-cold-case-murder-trial-prosecutors-complete-evidence-defence-granted-delay-5579305)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T17:07:00+00:00

Guylaine Potvin,  shown in a police handout photo, was found dead in her apartment in Jonquière, Que., on April 28, 2000. (The Canadian Press/HO-Surete du Quebec )

## Fire Set Off by Gas Explosion in Kenya Kills at Least 3 People and Injures 280 Others
 - [https://www.theepochtimes.com/world/fire-set-off-by-gas-explosion-in-kenya-kills-at-least-3-people-and-injures-280-others-5579261](https://www.theepochtimes.com/world/fire-set-off-by-gas-explosion-in-kenya-kills-at-least-3-people-and-injures-280-others-5579261)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T17:04:05+00:00

Firefighters put off a fire caused by an explosion at an industrial building in Nairobi, Kenya, on Feb. 2, 2024. (AP Photo)

## Nova Scotia’s Lucy the Lobster Disagrees With Groundhogs’ Prediction of Early Spring
 - [https://www.theepochtimes.com/world/nova-scotias-lucy-the-lobster-disagrees-with-groundhogs-about-early-spring-5579243](https://www.theepochtimes.com/world/nova-scotias-lucy-the-lobster-disagrees-with-groundhogs-about-early-spring-5579243)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T16:53:31+00:00

Nova Scotia's Lucy the Lobster. (Courtesy of Visit Barrington)

## Ottawa Considering Rebrand of Carbon Tax Rebate Program to Address Canadians’ ‘Confusion’
 - [https://www.theepochtimes.com/world/ottawa-considering-rebrand-of-carbon-tax-rebate-program-to-address-canadians-confusion-5579197](https://www.theepochtimes.com/world/ottawa-considering-rebrand-of-carbon-tax-rebate-program-to-address-canadians-confusion-5579197)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T16:43:48+00:00

Prime Minister Justin Trudeau speaks to the media and students regarding his government's new federally imposed carbon tax at Humber College in Toronto on Oct. 23, 2018. (The Canadian Press/Nathan Denette)

## Canada Should Be Vigilant About China’s Untoward Goals in International Organizations: Professor
 - [https://www.theepochtimes.com/world/canada-should-be-vigilant-about-chinas-untoward-goals-in-international-organizations-professor-5578954](https://www.theepochtimes.com/world/canada-should-be-vigilant-about-chinas-untoward-goals-in-international-organizations-professor-5578954)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T16:38:03+00:00

Conservative MP Kyle Seeback rises during question period in the House of Commons on Parliament Hill in Ottawa, on Jan. 30, 2024. (The Canadian Press/Adrian Wyld)

## Met Police Backtracks Decision to Ban Pro-Palestine March in Whitehall
 - [https://www.theepochtimes.com/world/met-police-backtracks-decision-to-ban-pro-palestine-march-in-whitehall-5579151](https://www.theepochtimes.com/world/met-police-backtracks-decision-to-ban-pro-palestine-march-in-whitehall-5579151)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T16:35:16+00:00

Protesters in Trafalgar Square, central London, during a pro-Palestine march organised by Stop the War Coalition and Palestine Solidarity Campaign on Oct. 21, 2023. (Stefan Rousseau/PA)

## ANALYSIS: Leaked CSIS Doc That Spurred Interference Inquiry Has Now Been Disclosed (In Part)
 - [https://www.theepochtimes.com/world/analysis-leaked-csis-doc-that-spurred-interference-inquiry-is-now-disclosed-in-part-5579205](https://www.theepochtimes.com/world/analysis-leaked-csis-doc-that-spurred-interference-inquiry-is-now-disclosed-in-part-5579205)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T15:58:38+00:00

The Chinese Embassy in Ottawa in a file photo. (Sean Kilpatrick/The Canadian Press)

## Ukraine’s Top General Lays out Strategy Amid Rumored ‘Power Struggle’ in Kyiv
 - [https://www.theepochtimes.com/world/ukraines-top-general-lays-out-strategy-amid-rumored-power-struggle-in-kyiv-5579182](https://www.theepochtimes.com/world/ukraines-top-general-lays-out-strategy-amid-rumored-power-struggle-in-kyiv-5579182)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T15:56:27+00:00

An armed man stands  in the center of Kyiv, Ukraine, on March 2, 2022.  (Efrem Lukatsky/AP Photo)

## Feds Should Boost Grocery Competition at Home, Not Seek Outsider: Experts
 - [https://www.theepochtimes.com/world/feds-should-boost-grocery-competition-at-home-not-seek-outsider-experts-5579226](https://www.theepochtimes.com/world/feds-should-boost-grocery-competition-at-home-not-seek-outsider-experts-5579226)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T15:48:12+00:00

Produce is shown at a west-end Toronto Sobeys grocery store, on June 26, 2023. (The Canadian  Press/Graeme Roy)

## Cross-Border Repression Is ‘Everyday Threat’ on US Campuses: Report
 - [https://www.theepochtimes.com/china/cross-border-repression-is-everyday-threat-on-us-campuses-report-5579146](https://www.theepochtimes.com/china/cross-border-repression-is-everyday-threat-on-us-campuses-report-5579146)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T15:30:05+00:00

Chinese students at the University of Southern California gather in support of demonstrations held in China calling for an end to COVID-19 lockdowns, in Los Angeles, Calif., on Nov. 29, 2022. (Emma Hsu/The Epoch Times)

## Groundhog Day: Canada’s Famous Furry Forecasters Predict Early Spring
 - [https://www.theepochtimes.com/world/groundhog-day-canadas-famous-furry-forecasters-predict-early-spring-5579171](https://www.theepochtimes.com/world/groundhog-day-canadas-famous-furry-forecasters-predict-early-spring-5579171)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T14:45:48+00:00

Shubenacadie Sam looks around after emerging from his burrow at the wildlife park in Shubenacadie, N.S. on Groundhog Day, Feb. 2, 2018. (The Canadian Press/Andrew Vaughan)

## Farmers’ Protests Escalate Ahead of EU Summit Amid Growing Discontent
 - [https://www.theepochtimes.com/world/farmers-protests-escalate-ahead-of-eu-summit-amid-growing-discontent-5578567](https://www.theepochtimes.com/world/farmers-protests-escalate-ahead-of-eu-summit-amid-growing-discontent-5578567)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T14:36:48+00:00

A French farmer takes part in a road block protest on the A4 highway next to a tractor with a placard reading "Death is in the field" near Jossigny, east of Paris, on Jan. 29, 2024, amid nationwide protests called by several farmers unions on pay, tax and regulations. (Bertrand Guay/AFP via Getty Images)

## Raccoon Blamed for Power Outage That Left Downtown Toronto in the Dark
 - [https://www.theepochtimes.com/world/hydro-one-blames-raccoon-for-power-outage-that-left-downtown-toronto-in-the-dark-5579136](https://www.theepochtimes.com/world/hydro-one-blames-raccoon-for-power-outage-that-left-downtown-toronto-in-the-dark-5579136)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T14:30:38+00:00

A hydro tower is seen with the CN Tower as a backdrop in downtown Toronto Monday Nov. 11, 2002.  
(Kevin Frayer /CP PHOTO)

## Peter Whittle: British Self-Deprecating Has Turned Into Self-Annihilation
 - [https://www.theepochtimes.com/world/peter-whittle-british-self-deprecating-has-turned-into-self-annihilation-5578224](https://www.theepochtimes.com/world/peter-whittle-british-self-deprecating-has-turned-into-self-annihilation-5578224)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T14:27:58+00:00

Peter Whittle, founder and director of the New Culture Forum, speaking to NTD's 'British Thought Leaders' programme. (NTD)

## The Former Canadian Governor General Who Dared to Advocate Peace Amid WW1
 - [https://www.theepochtimes.com/opinion/the-former-canadian-governor-general-who-dared-to-advocate-peace-amid-ww1-5575421](https://www.theepochtimes.com/opinion/the-former-canadian-governor-general-who-dared-to-advocate-peace-amid-ww1-5575421)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T14:25:35+00:00

A portrait of Henry Charles Keith Petty-Fitzmaurice, 5th Marquess of Lansdowne, by Philip Alexius de László. (Public Domain)

## Mélanie Joly in Kyiv to Launch Global Push to Get Russia to Return Ukrainian Children
 - [https://www.theepochtimes.com/world/melanie-joly-in-kyiv-to-launch-global-push-to-get-russia-to-return-ukrainian-children-5579156](https://www.theepochtimes.com/world/melanie-joly-in-kyiv-to-launch-global-push-to-get-russia-to-return-ukrainian-children-5579156)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T14:18:32+00:00

Minister of Foreign Affairs Melanie Joly speaks at an event to mark Ukraine Independence Day in Ottawa on Aug. 24, 2023. (The Canadian Press/Patrick Doyle)

## Beijing Warns New Zealand to ‘Think Twice’ Before Joining AUKUS
 - [https://www.theepochtimes.com/world/beijing-warns-new-zealand-to-think-twice-before-joining-aukus-5579064](https://www.theepochtimes.com/world/beijing-warns-new-zealand-to-think-twice-before-joining-aukus-5579064)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T13:28:28+00:00

ANZMIN Meeting on Feb. 1, 2024. In attendance were Australian Deputy Prime Minister Richard Marles, and Foreign Minister Penny Wong, along with Deputy Prime Minister of New Zealand Winston Peters, and Minister for Defence Judith Collins. (Courtesy of Sarah Hodges/Australian Department of Foreign Affairs and Trade)

## Brianna Ghey’s Killers Identified After Judge Lifts Restrictions
 - [https://www.theepochtimes.com/world/brianna-gheys-killers-identified-after-judge-lifts-restrictions-5579105](https://www.theepochtimes.com/world/brianna-gheys-killers-identified-after-judge-lifts-restrictions-5579105)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T13:07:30+00:00

Undated images of Scarlett Jenkinson (L) and Eddie Ratcliffe (R), who were convicted of the murder of Brianna Ghey in Culcheth Linear Park, near Warrington, England on Feb. 11, 2023. (Cheshire Police)

## ‘Renewables-Only Policy’ Driving up Electricity Prices: Australian Opposition
 - [https://www.theepochtimes.com/world/renewables-only-policy-driving-up-electricity-prices-australian-opposition-5579031](https://www.theepochtimes.com/world/renewables-only-policy-driving-up-electricity-prices-australian-opposition-5579031)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T13:07:29+00:00

Wind turbines at Albany Wind Farm at sunset in Albany, Western Australia, on Jan. 22, 2024. (Susan Mortimer/The Epoch Times)

## Cyclone Set for ‘Last Hurrah’ in Queensland as Another Threat Looms
 - [https://www.theepochtimes.com/world/cyclone-set-for-last-hurrah-in-queensland-as-another-threat-looms-5579118](https://www.theepochtimes.com/world/cyclone-set-for-last-hurrah-in-queensland-as-another-threat-looms-5579118)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T12:15:36+00:00

Worst flooding in decades  
in the wake of tropical cyclone Tasha covered the town of Dalby in Queensland in floodwaters on Dec. 28, 2010. (JEFF CAMDEN/AFP via Getty Images)

## Western Australia Bakes as Scorching Heatwave Continues
 - [https://www.theepochtimes.com/world/western-australia-bakes-as-scorching-heatwave-continues-5579119](https://www.theepochtimes.com/world/western-australia-bakes-as-scorching-heatwave-continues-5579119)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T12:12:53+00:00

Kites and people are seen at a beach in Albany, Western Australia, on Jan. 26, 2024. (Susan Mortimer/The Epoch Times)

## Mother Lashes out During Jumping Castle Court Hearing
 - [https://www.theepochtimes.com/world/mother-lashes-out-during-jumping-castle-court-hearing-5579120](https://www.theepochtimes.com/world/mother-lashes-out-during-jumping-castle-court-hearing-5579120)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T12:12:17+00:00

Police attend the scene of a multiple stabbing in Cairns, Australia, on Dec. 19, 2014. (Ian Hitchcock/Getty Images)

## Clapham Chemical Attack Suspect Is Afghan Immigrant With Conviction Sexual Assault
 - [https://www.theepochtimes.com/world/clapham-chemical-attack-suspect-is-afghan-immigrant-with-conviction-sexual-assault-5579091](https://www.theepochtimes.com/world/clapham-chemical-attack-suspect-is-afghan-immigrant-with-conviction-sexual-assault-5579091)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T12:04:13+00:00

An undated image of Abdul Ezedi (L) who was caught on CCTV at a supermarket in Caledonian Road, north London on Jan. 31, 2024. (Metropolitan Police)

## Alzheimer’s Passed From Corpses to Humans Through Extracted Hormones Contaminated With Toxic Proteins
 - [https://www.theepochtimes.com/world/alzheimers-passed-from-corpses-to-humans-through-extracted-hormones-contaminated-with-toxic-proteins-5576725](https://www.theepochtimes.com/world/alzheimers-passed-from-corpses-to-humans-through-extracted-hormones-contaminated-with-toxic-proteins-5576725)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T11:47:41+00:00

A woman with Alzheimer's disease looks on during lunch in the refectory of a retirement home  in Saint Quirin, eastern France on Oct. 18, 2016. (Patrick Hertzog/AFP via Getty Images)

## UN Calls for Multinational Security Support as Killings, Kidnappings Spike in Haiti
 - [https://www.theepochtimes.com/world/un-calls-for-multinational-security-support-as-killings-kidnappings-spike-in-haiti-5579006](https://www.theepochtimes.com/world/un-calls-for-multinational-security-support-as-killings-kidnappings-spike-in-haiti-5579006)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T10:56:59+00:00

People walk past a street market in Port-au-Prince, Haiti, on June 28, 2023. (Richard Pierrin/AFP via Getty Images)

## Australia’s Drowning Toll Increased by 24 Percent From Last Summer
 - [https://www.theepochtimes.com/world/australias-drowning-toll-increased-24-percent-from-last-summer-5579058](https://www.theepochtimes.com/world/australias-drowning-toll-increased-24-percent-from-last-summer-5579058)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T07:55:42+00:00

Beachgoers swim on a hot summer day at Bondi Beach in Sydney, Australia, on Dec. 9, 2023. (David Gray/AFP via Getty Images)

## Opposition Yet to Show Hand on Tax Cut Support, But Calls for ‘Lower Taxes’ for Australians
 - [https://www.theepochtimes.com/world/opposition-yet-to-show-hand-on-tax-cut-support-but-calls-for-lower-taxes-for-australians-5579062](https://www.theepochtimes.com/world/opposition-yet-to-show-hand-on-tax-cut-support-but-calls-for-lower-taxes-for-australians-5579062)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T06:54:35+00:00

Leader of the Opposition Peter Dutton speaks to media in Melbourne, Australia on Dec. 12, 2023. (AAP Image/Joel Carrett)

## Activists Exploiting Indigenous Communities to Further Their Own Agenda: Senator
 - [https://www.theepochtimes.com/world/activists-exploiting-indigenous-communities-to-further-their-own-agenda-senator-5579051](https://www.theepochtimes.com/world/activists-exploiting-indigenous-communities-to-further-their-own-agenda-senator-5579051)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T06:34:20+00:00

Senator and Shadow Indigenous Minister Jacinta Price speaks at CPAC Australia in Sydney, Australia, on Aug. 19, 2023. (Wade Zhong/The Epoch Times)

## ANALYSIS: One-Quarter of Political Donations Untraceable
 - [https://www.theepochtimes.com/world/analysis-one-quarter-of-political-donations-untraceable-5579013](https://www.theepochtimes.com/world/analysis-one-quarter-of-political-donations-untraceable-5579013)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T06:18:39+00:00

An abundance of Liberal Party signage at the Strathfield North Public School polling booth on Federal Election day, in the seat of Reid, in Sydney, Australia, on May 21, 2022. (AAP Image/Dean Lewins)

## Crucial Player Safety: Kids Must Wait 21 Days Before Returning to Sports After Concussion
 - [https://www.theepochtimes.com/world/crucial-player-safety-kids-must-wait-21-days-before-returning-to-sports-after-concussion-5579053](https://www.theepochtimes.com/world/crucial-player-safety-kids-must-wait-21-days-before-returning-to-sports-after-concussion-5579053)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T06:05:04+00:00

Encouraging young people to participate in multiple sports can help prevent bone stress injuries and boost bone structure. (Debra Brewster/Unsplash)

## Lower Government Spending Would Decrease Inflation Faster, Bank of Canada Governor Says
 - [https://www.theepochtimes.com/world/lower-government-spending-would-decrease-inflation-faster-bank-of-canada-governor-says-5579014](https://www.theepochtimes.com/world/lower-government-spending-would-decrease-inflation-faster-bank-of-canada-governor-says-5579014)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T06:04:45+00:00

Bank of Canada Governor Tiff Macklem ponders a question at a press conference in Ottawa on June 9, 2022. (The Canadian Press/ Patrick Doyle)

## Australian Employer Ordered to Pay Compensation for Vaccine Injured in ‘Significant Precedent’
 - [https://www.theepochtimes.com/world/australian-employer-ordered-to-pay-compensation-for-vaccine-injured-in-significant-precedent-5579036](https://www.theepochtimes.com/world/australian-employer-ordered-to-pay-compensation-for-vaccine-injured-in-significant-precedent-5579036)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T05:29:56+00:00

A nurse prepares a Pfizer vaccine overseen by a doctor in Sydney, Australia, on Oct. 3, 2021. (Lisa Maree Williams/Getty Images)

## Australian Cities Should Adopt Trackless Trams to Improve Sustainability and Efficiency: Urban Planner
 - [https://www.theepochtimes.com/world/australian-cities-should-adopt-trackless-trams-to-improve-sustainability-and-efficiency-urban-planner-5579023](https://www.theepochtimes.com/world/australian-cities-should-adopt-trackless-trams-to-improve-sustainability-and-efficiency-urban-planner-5579023)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T05:27:56+00:00

A tram is seen in Melbourne, Australia, on Oct. 28, 2023. (Susan Mortimer/The Epoch Times)

## Russian Court Extends Detention of Russian–US Journalist
 - [https://www.theepochtimes.com/world/russian-court-extends-detention-of-russian-us-journalist-5578508](https://www.theepochtimes.com/world/russian-court-extends-detention-of-russian-us-journalist-5578508)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T05:12:06+00:00

Radio Free Europe-Radio Liberty's editor Alsu Kurmasheva stands in a glass cage in a courtroom in Kazan, Russia, on Feb. 1, 2024. (Vladislav Mikhnevskii/AP Photo)

## Ottawa Declassifies More Details From Rodal Report on Nazi War Criminals in Canada
 - [https://www.theepochtimes.com/world/ottawa-declassifies-more-details-from-rodal-report-on-nazi-war-criminals-in-canada-5579028](https://www.theepochtimes.com/world/ottawa-declassifies-more-details-from-rodal-report-on-nazi-war-criminals-in-canada-5579028)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T03:51:24+00:00

The Peace Tower is pictured on Parliament Hill in Ottawa on Dec. 19, 2023. (The Canadian Press/Sean Kilpatrick)

## Australia’s eSafety Commissioner Calls Big Tech Senate Hearing ‘Disappointing’
 - [https://www.theepochtimes.com/world/australias-esafety-commissioner-calls-big-tech-senate-hearing-disappointing-5579000](https://www.theepochtimes.com/world/australias-esafety-commissioner-calls-big-tech-senate-hearing-disappointing-5579000)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T03:48:23+00:00

Mark Zuckerberg (R), CEO of Meta testifies before the Senate Judiciary Committee at the Dirksen Senate Office Building in Washington, D.C. on Jan. 31, 2024. (Anna Moneymaker/Getty Images)

## Increase in US Softwood Lumber Duties ‘Entirely Unwarranted,’ Trade Minister Says
 - [https://www.theepochtimes.com/world/increase-in-us-softwood-lumber-duties-entirely-unwarranted-trade-minister-says-5579022](https://www.theepochtimes.com/world/increase-in-us-softwood-lumber-duties-entirely-unwarranted-trade-minister-says-5579022)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T03:41:23+00:00

An employee walks across the lumber yard at Ledwidge Lumber Co. in Halifax on May 10, 2017. (The Canadian Press/Darren Calabrese)

## Public Schools in Australia’s Largest State on Track to Receive Full Government Funding
 - [https://www.theepochtimes.com/world/public-schools-in-australias-largest-state-on-track-to-receive-full-government-funding-5579009](https://www.theepochtimes.com/world/public-schools-in-australias-largest-state-on-track-to-receive-full-government-funding-5579009)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T03:32:26+00:00

Bob Hawke College, a public co-educational senior high school, in Perth, Australia, on  Jan. 31, 2020. (AAP Image/Supplied by the WA Department of Education)

## Parents Struggling to Pay for School Lunches, Equipment: Charity
 - [https://www.theepochtimes.com/world/parents-struggling-to-pay-for-school-lunches-equipment-charity-5578700](https://www.theepochtimes.com/world/parents-struggling-to-pay-for-school-lunches-equipment-charity-5578700)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T03:14:07+00:00

A customer looks at the price of limes at a fruit stand in the central business district in Sydney, Australia, on Aug. 16, 2022. (Lisa Maree Williams/Getty Images)

## American Airlines Launches Its Longest Non-Step Flight Between Dallas and Brisbane
 - [https://www.theepochtimes.com/world/american-airlines-launches-its-longest-non-step-flight-between-dallas-and-brisbane-5578920](https://www.theepochtimes.com/world/american-airlines-launches-its-longest-non-step-flight-between-dallas-and-brisbane-5578920)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T03:13:47+00:00

An American Airlines Boeing 787-9 Dreamliner lands at the Miami International Airport on Dec. 10, 2021 in Miami, Florida. (Photo by Joe Raedle/Getty Images)

## Parental Groups Praise Alberta’s Child Transition Restrictions, as Several Politicians and Teachers Association Denounce the Change
 - [https://www.theepochtimes.com/world/parental-groups-praise-albertas-new-child-transition-policies-as-several-politicians-and-teachers-association-denounce-the-change-5578846](https://www.theepochtimes.com/world/parental-groups-praise-albertas-new-child-transition-policies-as-several-politicians-and-teachers-association-denounce-the-change-5578846)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T03:01:10+00:00

Health Minister Mark Holland (L) looks on as Justice Minister and Attorney General of Canada Arif Virani speaks at a press conference in Ottawa on Feb. 1, 2024. (The Canadian Press/Adrian Wyld)

## How Alberta’s Child Gender Transition Restrictions Compare to US States’, Europe
 - [https://www.theepochtimes.com/world/how-albertas-child-gender-transition-restrictions-compare-to-us-states-5578634](https://www.theepochtimes.com/world/how-albertas-child-gender-transition-restrictions-compare-to-us-states-5578634)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T02:52:05+00:00

Pro-transgender protesters in Montreal, Canada, on March 17, 2023. (Andrej Ivanov/AFP via Getty Images)

## Police Find ‘No Evidence’ of Anti-Semitic Chants Used at Sydney Opera House
 - [https://www.theepochtimes.com/world/police-find-no-evidence-of-anti-semitic-chants-used-at-sydney-opera-house-5578916](https://www.theepochtimes.com/world/police-find-no-evidence-of-anti-semitic-chants-used-at-sydney-opera-house-5578916)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T01:06:11+00:00

SYDNEY, AUSTRALIA - OCTOBER 09: Palestine supporters rally outside the Sydney Opera House on October 09, 2023 in Sydney, Australia. The Palestinian militant group Hamas launched a surprise attack on Israel from Gaza by land, sea, and air, over the weekend, killing over 600 people and wounding more than 2000, agency reports said. Reports also said Israeli soldiers and civilians have been kidnapped by Hamas and taken into Gaza. The attack prompted a declaration of war by Israeli Prime Minister Benjamin Netanyahu, and ongoing retaliatory strikes by Israel on Gaza killing hundreds in the aftermath. (Photo by Lisa Maree Williams/Getty Images)

## ‘40,000 Palestinians Are Starving’: Foreign Minister Weighs in on UN Funding Pause in Gaza
 - [https://www.theepochtimes.com/world/40000-palestinians-are-starving-foreign-minister-weighs-in-on-un-funding-pause-in-gaza-5578747](https://www.theepochtimes.com/world/40000-palestinians-are-starving-foreign-minister-weighs-in-on-un-funding-pause-in-gaza-5578747)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-02T00:55:45+00:00

Armed supporters of Yemen's Huthi rebels attend a rally in solidarity with the Palestinian Hamas movement's armed resistance against Israel in the capital Sanaa on Jan. 29, 2024, amid the continuing battles between Israeli forces and Hamas in Gaza. Since shortly after the Israel-Hamas war in Gaza broke out on Oct. 7, the Huthis have launched a spate of missile and drone attacks on passing commercial ships in the Red Sea which they say are linked to Israel. (Mohammed Huwais/AFP via Getty Images)

