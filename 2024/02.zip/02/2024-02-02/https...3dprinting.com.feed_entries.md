# Source:3DPrinting.com, URL:https://3dprinting.com/feed, language:en-US

## Scientists Advance Neurological Research with 3D Printed Brain Tissue - 3DPrinting.com
 - [https://3dprinting.com/news/scientists-advance-neurological-research-with-3d-printed-brain-tissue](https://3dprinting.com/news/scientists-advance-neurological-research-with-3d-printed-brain-tissue)
 - RSS feed: https://3dprinting.com/feed
 - date published: 2024-02-02T19:30:31+00:00

<div style="display: flex;"><div><h2><a href="https://3dprinting.com/news/scientists-advance-neurological-research-with-3d-printed-brain-tissue/" target="_blank">Scientists Advance Neurological Research with 3D Printed Brain Tissue</a></h2><span style="color: #777; font-size: 14px; margin-top: auto;">February 2</span></div><div><img alt="Scientists Advance Neurological Research with 3D Printed Brain Tissue" class="attachment-singular-featured-thumb size-singular-featured-thumb wp-post-image" height="500" src="https://3dprinting.com/wp-content/uploads/image2-98-500x500.jpg" style="border-radius: 10px; overflow: hidden;" width="500" /></div></div>

## Aerosol Jet Printing Transforms Microfluidic Device Fabrication - 3DPrinting.com
 - [https://3dprinting.com/news/aerosol-jet-printing-transforms-microfluidic-device-fabrication](https://3dprinting.com/news/aerosol-jet-printing-transforms-microfluidic-device-fabrication)
 - RSS feed: https://3dprinting.com/feed
 - date published: 2024-02-02T18:17:45+00:00

<div style="display: flex;"><div><h2><a href="https://3dprinting.com/news/aerosol-jet-printing-transforms-microfluidic-device-fabrication/" target="_blank">Aerosol Jet Printing Transforms Microfluidic Device Fabrication</a></h2><span style="color: #777; font-size: 14px; margin-top: auto;">February 2</span></div><div><img alt="Aerosol Jet Printing Transforms Microfluidic Device Fabrication" class="attachment-singular-featured-thumb size-singular-featured-thumb wp-post-image" height="500" src="https://3dprinting.com/wp-content/uploads/image5-25-500x500.jpg" style="border-radius: 10px; overflow: hidden;" width="500" /></div></div>

## University of Sheffield Adopts Freemelt ONE for Tungsten Component Research - 3DPrinting.com
 - [https://3dprinting.com/news/university-of-sheffield-adopts-freemelt-one-for-tungsten-component-research](https://3dprinting.com/news/university-of-sheffield-adopts-freemelt-one-for-tungsten-component-research)
 - RSS feed: https://3dprinting.com/feed
 - date published: 2024-02-02T07:00:37+00:00

<div style="display: flex;"><div><h2><a href="https://3dprinting.com/news/university-of-sheffield-adopts-freemelt-one-for-tungsten-component-research/" target="_blank">University of Sheffield Adopts Freemelt ONE for Tungsten Component Research</a></h2><span style="color: #777; font-size: 14px; margin-top: auto;">February 2</span></div><div><img alt="University of Sheffield Adopts Freemelt ONE for Tungsten Component Research" class="attachment-singular-featured-thumb size-singular-featured-thumb wp-post-image" height="309" src="https://3dprinting.com/wp-content/uploads/image2-97-500x309.jpg" style="border-radius: 10px; overflow: hidden;" width="500" /></div></div>

