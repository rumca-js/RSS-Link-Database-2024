# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## Google will no longer back up the Internet: Cached webpages are dead
 - [https://arstechnica.com/?p=2000802](https://arstechnica.com/?p=2000802)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T21:09:05+00:00

Google Search will no longer make site backups while crawling the web.

## Our oldest microbial ancestors were way ahead of their time
 - [https://arstechnica.com/?p=2000903](https://arstechnica.com/?p=2000903)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T20:46:06+00:00

Specialized internal structures were present over 1.5 billion years ago.

## “Rasti Computer” is a detailed GRiD Compass tribute made from Framework innards
 - [https://arstechnica.com/?p=2000774](https://arstechnica.com/?p=2000774)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T20:34:58+00:00

It's a custom keyboard, an artfully dinged-up case, and a wonderful throwback.

## Republicans in Congress try to kill FCC’s broadband discrimination rules
 - [https://arstechnica.com/?p=2000890](https://arstechnica.com/?p=2000890)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T19:54:31+00:00

Over 65 Republicans file resolution of disapproval, while lobby groups sue FCC.

## New 6GB version of the RTX 3050 may be Nvidia’s first sub-$200 GPU in over 4 years
 - [https://arstechnica.com/?p=2000798](https://arstechnica.com/?p=2000798)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T19:34:15+00:00

Exciting? No. New technology? Also no. But it ought to be better than a 1650.

## A startup allegedly “hacked the world.” Then came the censorship—and now the backlash.
 - [https://arstechnica.com/?p=2000875](https://arstechnica.com/?p=2000875)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T19:26:43+00:00

Anti-censorship voices are working to highlight reports of one Indian company’s hacker past.

## Over 2 percent of the US’s electricity generation now goes to bitcoin
 - [https://arstechnica.com/?p=2000859](https://arstechnica.com/?p=2000859)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T18:52:23+00:00

US government tracking the energy implications of booming bitcoin mining in US.

## Mathematicians finally solved Feynman’s “reverse sprinkler” problem
 - [https://arstechnica.com/?p=2000600](https://arstechnica.com/?p=2000600)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T18:27:24+00:00

We might not need to "unwater" our lawns, but results could help control fluid flows.

## Fans preserve and emulate Sega’s extremely rare ‘80s “AI computer”
 - [https://arstechnica.com/?p=2000820](https://arstechnica.com/?p=2000820)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T18:00:32+00:00

Prolog-based Japanese education hardware sported an early touch-panel, speech synthesizer.

## YouTube Premium announces 100 million subscribers
 - [https://arstechnica.com/?p=2000791](https://arstechnica.com/?p=2000791)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T17:07:08+00:00

Ad-free videos and YouTube Music access hits a major milestone.

## Tesla’s week gets worse: Fines, safety investigation, and massive recall
 - [https://arstechnica.com/?p=2000770](https://arstechnica.com/?p=2000770)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T15:35:53+00:00

There have been 2,388 complaints about steering failure in the Model 3 and Model Y.

## Daily Telescope: A Wolf-Rayet star puts on a howling light show
 - [https://arstechnica.com/?p=2000699](https://arstechnica.com/?p=2000699)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T13:00:28+00:00

I'd like to see it go boom.

## Why interstellar objects like ‘Oumuamua and Borisov may hold clues to exoplanets
 - [https://arstechnica.com/?p=2000730](https://arstechnica.com/?p=2000730)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T12:15:24+00:00

Two celestial interlopers in Solar System have scientists eagerly anticipating more.

## Rocket Report: SpaceX at the service of a rival; Endeavour goes vertical
 - [https://arstechnica.com/?p=2000721](https://arstechnica.com/?p=2000721)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-02T12:00:25+00:00

The US military appears interested in owning and operating its own fleet of Starships.

