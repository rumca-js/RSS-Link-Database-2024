# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Companies’ hard-line stance on returning to the office is backfiring
 - [https://www.washingtonpost.com/technology/2024/02/02/return-to-office-punishments-remote-hybrid-work](https://www.washingtonpost.com/technology/2024/02/02/return-to-office-punishments-remote-hybrid-work)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-02-02T22:35:28+00:00

Employers are losing patience with remote work, but they’re facing an uphill battle in getting workers back in person.

## Apple’s Vision Pro is ‘spatial computing.’ Nobody knows what it means.
 - [https://www.washingtonpost.com/technology/2024/02/02/apple-vision-pro-what-is-spatial-computing-ar-vr](https://www.washingtonpost.com/technology/2024/02/02/apple-vision-pro-what-is-spatial-computing-ar-vr)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-02-02T17:30:48+00:00

Do you want a technology that can’t define itself?

## Elon Musk is unfathomably rich. Here’s where his money is stashed.
 - [https://www.washingtonpost.com/technology/2024/02/01/elon-musk-wealth-net-worth-companies](https://www.washingtonpost.com/technology/2024/02/01/elon-musk-wealth-net-worth-companies)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2024-02-02T00:07:20+00:00

Musk lacks significant tranches of cash; his money is largely tied up in ownership stakes of his companies.

