# Source:RMF24.pl, URL:https://www.rmf24.pl/feed, language:pl

## Śmierć dwumiesięcznego dziecka w Sokółce. Zatrzymano rodziców
 - [https://www.rmf24.pl/regiony/bialystok/news-smierc-dwumiesiecznego-dziecka-w-sokolce-zatrzymano-rodzicow,nId,7306127](https://www.rmf24.pl/regiony/bialystok/news-smierc-dwumiesiecznego-dziecka-w-sokolce-zatrzymano-rodzicow,nId,7306127)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T21:35:51+00:00

<p><a href="https://www.rmf24.pl/regiony/bialystok/news-smierc-dwumiesiecznego-dziecka-w-sokolce-zatrzymano-rodzicow,nId,7306127"><img align="left" alt="Śmierć dwumiesięcznego dziecka w Sokółce. Zatrzymano rodziców" src="https://interia-s.pluscdn.pl/smierc-dwumiesiecznego-dziecka-w-sokolce-zatrzymano-rodzicow/000IIO8R4EPCM2H9-C307.jpg" /></a>Policja pod nadzorem prokuratury wyjaśnia okoliczności śmieci dwumiesięcznej dziewczynki w jednym z domów w Sokółce na Podlasiu. Zatrzymano rodziców dziecka.</p><br clear="all" />

## Bodnar: Przepraszam osoby LGBT+ za krzywdę, której doznali ze strony Państwa Polskiego
 - [https://www.rmf24.pl/fakty/polska/news-bodnar-przepraszam-osoby-lgbt-za-krzywde-ktorej-doznali-ze-s,nId,7306116](https://www.rmf24.pl/fakty/polska/news-bodnar-przepraszam-osoby-lgbt-za-krzywde-ktorej-doznali-ze-s,nId,7306116)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T20:36:55+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-bodnar-przepraszam-osoby-lgbt-za-krzywde-ktorej-doznali-ze-s,nId,7306116"><img align="left" alt="Bodnar: Przepraszam osoby LGBT+ za krzywdę, której doznali ze strony Państwa Polskiego" src="https://interia-s.pluscdn.pl/bodnar-przepraszam-osoby-lgbt-za-krzywde-ktorej-doznali-ze-s/000IIO3298AT9VKB-C307.jpg" /></a>&quot;Przepraszam za krzywdę, której doznaliście ze strony Państwa Polskiego&quot; - powiedział na spotkaniu z organizacjami działającymi na rzecz osób LGBT+ minister sprawiedliwości Adam Bodnar. Zapowiedział prace nad nowelą Kodeksu karnego w zakresie zwalczania nienawiści.</p><br clear="all" />

## Rafineria PCK Schwedt bez Rosjan? Do kogo trafią udziały?
 - [https://www.rmf24.pl/fakty/swiat/news-rafineria-pck-schwedt-bez-rosjan-do-kogo-trafia-udzialy,nId,7306110](https://www.rmf24.pl/fakty/swiat/news-rafineria-pck-schwedt-bez-rosjan-do-kogo-trafia-udzialy,nId,7306110)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T20:17:26+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-rafineria-pck-schwedt-bez-rosjan-do-kogo-trafia-udzialy,nId,7306110"><img align="left" alt="Rafineria PCK Schwedt bez Rosjan? Do kogo trafią udziały?" src="https://interia-s.pluscdn.pl/rafineria-pck-schwedt-bez-rosjan-do-kogo-trafia-udzialy/000IIO1911115KGK-C307.jpg" /></a>​Niemieckie ministerstwo gospodarki planuje do początku marca wywłaszczyć rosyjski koncern Rosnieft z rafinerii ropy naftowej PCK Schwedt i sprzedać udziały Polakom - napisał w czwartek niemiecki portal Business Insider (BI). </p><br clear="all" />

## Nerwowo w niebie. Mocarstwa przygotowują się do wojny w kosmosie
 - [https://www.rmf24.pl/fakty/swiat/news-nerwowo-w-niebie-mocarstwa-przygotowuja-sie-do-wojny-w-kosmo,nId,7306077](https://www.rmf24.pl/fakty/swiat/news-nerwowo-w-niebie-mocarstwa-przygotowuja-sie-do-wojny-w-kosmo,nId,7306077)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T19:52:27+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-nerwowo-w-niebie-mocarstwa-przygotowuja-sie-do-wojny-w-kosmo,nId,7306077"><img align="left" alt="Nerwowo w niebie. Mocarstwa przygotowują się do wojny w kosmosie" src="https://interia-s.pluscdn.pl/nerwowo-w-niebie-mocarstwa-przygotowuja-sie-do-wojny-w-kosmo/000IINXLUPYRYKWT-C307.jpg" /></a>Czołowe mocarstwa świata tworzą systemy bojowe do potencjalnego konfliktu w przestrzeni kosmicznej. Inwazja Rosji na Ukrainę otworzyła kolejny rozdział w kosmicznym wyścigu. Chiny próbują podważyć amerykański prymat na okołoziemskiej orbicie, a 28 stycznia Iran przekazał, że wystrzelił satelity, które - jak podejrzewają zachodni eksperci - mogą zostać wykorzystane do obsługi systemów pocisków balistycznych. Wiceprzewodniczący połączonych szefów sztabów USA stwierdza, cytowany przez &quot;The Economist&quot;: „Przestrzeń kosmiczna stała się naszą...</p><br clear="all" />

## Nowe gwiezdne wojny. Armie świata nerwowo patrzą w niebo
 - [https://www.rmf24.pl/fakty/swiat/news-nowe-gwiezdne-wojny-armie-swiata-nerwowo-patrza-w-niebo,nId,7306077](https://www.rmf24.pl/fakty/swiat/news-nowe-gwiezdne-wojny-armie-swiata-nerwowo-patrza-w-niebo,nId,7306077)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T19:52:27+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-nowe-gwiezdne-wojny-armie-swiata-nerwowo-patrza-w-niebo,nId,7306077"><img align="left" alt="Nowe gwiezdne wojny. Armie świata nerwowo patrzą w niebo" src="https://interia-s.pluscdn.pl/nowe-gwiezdne-wojny-armie-swiata-nerwowo-patrza-w-niebo/000IINW8WS9XVNL1-C307.jpg" /></a>Czołowe mocarstwa świata tworzą systemy bojowe do potencjalnego konfliktu w przestrzeni kosmicznej. Inwazja Rosji na Ukrainę otworzyła kolejny rozdział w kosmicznym wyścigu. Chiny próbują podważyć amerykański prymat na okołoziemskiej orbicie, a 28 stycznia Iran przekazał, że wystrzelił satelity, które - jak podejrzewają zachodni eksperci - mogą zostać wykorzystane do obsługi systemów pocisków balistycznych. Wiceprzewodniczący połączonych szefów sztabów USA stwierdza, cytowany przez &quot;The Economist&quot;: „Przestrzeń kosmiczna stała się naszą...</p><br clear="all" />

## Piłkarz Industrii Kielce opuścił areszt. Kounkoud podejrzewany o usiłowanie gwałtu
 - [https://www.rmf24.pl/sport/news-pilkarz-industrii-kielce-opuscil-areszt-kounkoud-podejrzewan,nId,7306106](https://www.rmf24.pl/sport/news-pilkarz-industrii-kielce-opuscil-areszt-kounkoud-podejrzewan,nId,7306106)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T19:47:21+00:00

<p><a href="https://www.rmf24.pl/sport/news-pilkarz-industrii-kielce-opuscil-areszt-kounkoud-podejrzewan,nId,7306106"><img align="left" alt="Piłkarz Industrii Kielce opuścił areszt. Kounkoud podejrzewany o usiłowanie gwałtu" src="https://interia-s.pluscdn.pl/pilkarz-industrii-kielce-opuscil-areszt-kounkoud-podejrzewan/000IINVYLGGW7C2D-C307.jpg" /></a>​Piłkarz ręczny reprezentacji Francji Benoit Kounkoud, oskarżony przez 20-letnią kobietę o próbę gwałtu, jest już na wolności. Zawodnik Industrii Kielce stanowczo zaprzecza tym oskarżeniom, powiedział w czwartek jego prawnik.</p><br clear="all" />

## Kuba zacieśnia współpracę wojskową z Białorusią
 - [https://www.rmf24.pl/fakty/swiat/news-kuba-zaciesnia-wspolprace-wojskowa-z-bialorusia,nId,7306102](https://www.rmf24.pl/fakty/swiat/news-kuba-zaciesnia-wspolprace-wojskowa-z-bialorusia,nId,7306102)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T19:33:27+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-kuba-zaciesnia-wspolprace-wojskowa-z-bialorusia,nId,7306102"><img align="left" alt="Kuba zacieśnia współpracę wojskową z Białorusią" src="https://interia-s.pluscdn.pl/kuba-zaciesnia-wspolprace-wojskowa-z-bialorusia/000IINU4ANJORV53-C307.jpg" /></a>Rząd Kuby zacieśnia współpracę w dziedzinie wojskowej z władzami Białorusi - podały niezależne kubańskie media, odnotowując kilkudniową wizytę na karaibskiej wyspie ministra obrony Wiktara Chrenina.</p><br clear="all" />

## Kaczyński: Niekompetencja Bodnara doprowadzi do uwolnienia tysięcy przestępców od odpowiedzialności
 - [https://www.rmf24.pl/polityka/news-kaczynski-niekompetencja-bodnara-doprowadzi-do-uwolnienia-ty,nId,7306091](https://www.rmf24.pl/polityka/news-kaczynski-niekompetencja-bodnara-doprowadzi-do-uwolnienia-ty,nId,7306091)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T19:30:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-kaczynski-niekompetencja-bodnara-doprowadzi-do-uwolnienia-ty,nId,7306091"><img align="left" alt="Kaczyński: Niekompetencja Bodnara doprowadzi do uwolnienia tysięcy przestępców od odpowiedzialności" src="https://interia-s.pluscdn.pl/kaczynski-niekompetencja-bodnara-doprowadzi-do-uwolnienia-ty/000IINP4879PTYE2-C307.jpg" /></a>&quot;Adam Bodnar, podporządkowując wszystko politycznemu celowi Donalda Tuska, doprowadził do sytuacji zagrażającej ofiarom przestępstw — i niezwykle korzystnej dla ich sprawców&quot; - ocenił w specjalnym oświadczeniu lider Prawa i Sprawiedliwości Jarosław Kaczyński. &quot;Zakwestionowanie przez Adama Bodnara umocowania Prokuratora Krajowego - będącego przełożonym wszystkich prokuratorów skutkuje wątpliwościami co do tego, czy jakikolwiek prokurator w Polsce jest uprawnionym oskarżycielem w postępowaniach karnych&quot; - dodał. Jego zdaniem &quot;niekompetencja...</p><br clear="all" />

## Orban: Dostaliśmy gwarancje, że węgierskie pieniądze nie trafią na Ukrainę
 - [https://www.rmf24.pl/fakty/swiat/news-orban-dostalismy-gwarancje-ze-wegierskie-pieniadze-nie-trafi,nId,7306078](https://www.rmf24.pl/fakty/swiat/news-orban-dostalismy-gwarancje-ze-wegierskie-pieniadze-nie-trafi,nId,7306078)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T18:23:16+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-orban-dostalismy-gwarancje-ze-wegierskie-pieniadze-nie-trafi,nId,7306078"><img align="left" alt="Orban: Dostaliśmy gwarancje, że węgierskie pieniądze nie trafią na Ukrainę" src="https://interia-s.pluscdn.pl/orban-dostalismy-gwarancje-ze-wegierskie-pieniadze-nie-trafi/000IINLDOWGJEFXE-C307.jpg" /></a>&quot;W końcu wynegocjowaliśmy mechanizm kontroli gwarantujący, że środki zostaną rozsądnie wykorzystane i węgierskie pieniądze nie zostaną wysłane na Ukrainę&quot; – powiedział premier Węgier Viktor Orban po czwartkowym szczycie Rady Europejskiej ws. pomocy finansowej dla Kijowa.</p><br clear="all" />

## USA uderzą na cele w Syrii i Iraku. Plany odwetu na Iranie zatwierdzone
 - [https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-usa-uderza-na-cele-w-syrii-i-iraku-plany-odwetu-na-iranie-za,nId,7306054](https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-usa-uderza-na-cele-w-syrii-i-iraku-plany-odwetu-na-iranie-za,nId,7306054)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T18:01:26+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-izrael-w-stanie-wojny/news-usa-uderza-na-cele-w-syrii-i-iraku-plany-odwetu-na-iranie-za,nId,7306054"><img align="left" alt="USA uderzą na cele w Syrii i Iraku. Plany odwetu na Iranie zatwierdzone" src="https://interia-s.pluscdn.pl/usa-uderza-na-cele-w-syrii-i-iraku-plany-odwetu-na-iranie-za/000IING3RDJKBS5C-C307.jpg" /></a>Waszyngton zatwierdził plany ataków odwetowych na powiązane z Iranem obiekty w Iraku i Syrii. Informację przekazali amerykańskiej stacji CBS News urzędnicy administracji USA. Uderzenia mają stanowić odpowiedź Stanów Zjednoczonych po niedzielnym ataku na amerykańskich żołnierzy w Jordanii.</p><br clear="all" />

## Nawalny nawołuje do protestów w Rosji. "Południe przeciwko Putinowi"
 - [https://www.rmf24.pl/fakty/swiat/news-nawalny-nawoluje-do-protestow-w-rosji-poludnie-przeciwko-put,nId,7305889](https://www.rmf24.pl/fakty/swiat/news-nawalny-nawoluje-do-protestow-w-rosji-poludnie-przeciwko-put,nId,7305889)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T17:12:49+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-nawalny-nawoluje-do-protestow-w-rosji-poludnie-przeciwko-put,nId,7305889"><img align="left" alt="Nawalny nawołuje do protestów w Rosji. &quot;Południe przeciwko Putinowi&quot;" src="https://interia-s.pluscdn.pl/nawalny-nawoluje-do-protestow-w-rosji-poludnie-przeciwko-put/000IIN5NQ20WJ2KR-C307.jpg" /></a>Polityczny rosyjski więzień nr 1 Aleksiej Nawalny wzywa do protestu przeciwko Władimirowi Putinowi i inwazji na Ukrainę. „Idźcie głosować przeciwko Putinowi i wojnie i namawiajcie wszystkich, aby zrobili to samo” - napisał zespół Nawalnego w mediach społecznościowych.</p><br clear="all" />

## Tragedia podczas prac ziemnych w Kostrzynie nad Odrą. Nie żyje jedna osoba
 - [https://www.rmf24.pl/regiony/news-tragedia-podczas-prac-ziemnych-w-kostrzynie-nad-odra-nie-zyj,nId,7305956](https://www.rmf24.pl/regiony/news-tragedia-podczas-prac-ziemnych-w-kostrzynie-nad-odra-nie-zyj,nId,7305956)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T17:03:56+00:00

<p><a href="https://www.rmf24.pl/regiony/news-tragedia-podczas-prac-ziemnych-w-kostrzynie-nad-odra-nie-zyj,nId,7305956"><img align="left" alt="Tragedia podczas prac ziemnych w Kostrzynie nad Odrą. Nie żyje jedna osoba" src="https://interia-s.pluscdn.pl/tragedia-podczas-prac-ziemnych-w-kostrzynie-nad-odra-nie-zyj/000IIN7PI7FKME4D-C307.jpg" /></a>Jedna osoba zginęła, a jedna trafiła do szpitala w wyniku wypadku w Kostrzynie nad Odrą - poinformowała &quot;Gazeta Lubuska&quot;. Podczas wykonywania prac ziemnych na pracowników osunęła się ziemia.</p><br clear="all" />

## Jan Grabiec gościem Rozmowy o 7:00 w Radiu RMF24
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-jan-grabiec-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7305895](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-jan-grabiec-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7305895)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T17:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-jan-grabiec-gosciem-rozmowy-o-7-00-w-radiu-rmf24,nId,7305895"><img align="left" alt="Jan Grabiec gościem Rozmowy o 7:00 w Radiu RMF24" src="https://interia-s.pluscdn.pl/jan-grabiec-gosciem-rozmowy-o-7-00-w-radiu-rmf24/000IIMWLKSC9CYRY-C307.jpg" /></a>Jan Grabiec, szef kancelarii premiera Donalda Tuska będzie gościem Rozmowy o 7:00 w Radiu RMF24. Paweł Balinowski porozmawia z nim o zmianach w najważniejszych spółkach Skarbu Państwa - przede wszystkim w Orlenie. </p><br clear="all" />

## Ryszard Schnepf: Europa się przestraszyła i chce pokazać, że jest zjednoczona
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-ryszard-schnepf-europa-sie-przestraszyla-i-chce-pokazac-ze-j,nId,7305810](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-ryszard-schnepf-europa-sie-przestraszyla-i-chce-pokazac-ze-j,nId,7305810)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T17:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-ryszard-schnepf-europa-sie-przestraszyla-i-chce-pokazac-ze-j,nId,7305810"><img align="left" alt="Ryszard Schnepf: Europa się przestraszyła i chce pokazać, że jest zjednoczona" src="https://interia-s.pluscdn.pl/ryszard-schnepf-europa-sie-przestraszyla-i-chce-pokazac-ze-j/000IINH6BAL3MWNJ-C307.jpg" /></a>&quot;Wróciłem do Ministerstwa Spraw Zagranicznych. Będę wspierał kolegów w przywracaniu w MSZ profesjonalizmu i bardzo się z tego cieszę&quot; - mówi w Popołudniowej rozmowie w RMF FM były ambasador RP w USA, były wiceminister spraw zagranicznych Ryszard Schnepf. Pytany o komentarz dotyczący osiągniętego porozumienia w UE ws. pomocy dla Ukrainy podkreślił: &quot;Myślę, że jest nowa sytuacja związana z postawą części elit politycznych w Stanach Zjednoczonych, która bardzo mocno popycha Unię do jedności i do większej stanowczości wobec Rosji. Europa się...</p><br clear="all" />

## Schnepf: Część ambasadorów powinna zostać odwołana
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-schnepf-czesc-ambasadorow-powinna-zostac-odwolana,nId,7305810](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-schnepf-czesc-ambasadorow-powinna-zostac-odwolana,nId,7305810)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T17:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-schnepf-czesc-ambasadorow-powinna-zostac-odwolana,nId,7305810"><img align="left" alt="Schnepf: Część ambasadorów powinna zostać odwołana" src="https://interia-s.pluscdn.pl/schnepf-czesc-ambasadorow-powinna-zostac-odwolana/000IINH6BAL3MWNJ-C307.jpg" /></a>&quot;Wróciłem do Ministerstwa Spraw Zagranicznych. Będę wspierał kolegów w przywracaniu w MSZ profesjonalizmu i bardzo się z tego cieszę&quot; - mówi w Popołudniowej rozmowie w RMF FM były ambasador RP w USA, były wiceminister spraw zagranicznych Ryszard Schnepf. Na pytanie, czy są ambasadorzy, których należałby odwołać, odpowiada: No to jest oczywiste&quot;. Proszony o komentarz dotyczący osiągniętego porozumienia w UE ws. pomocy dla Ukrainy podkreśla: &quot;Myślę, że jest nowa sytuacja związana z postawą części elit politycznych w Stanach Zjednoczonych,...</p><br clear="all" />

## Pogodowej huśtawki ciąg dalszy. Uwaga na oblodzenia!
 - [https://www.rmf24.pl/pogoda/news-pogodowej-hustawki-ciag-dalszy-uwaga-na-oblodzenia,nId,7305910](https://www.rmf24.pl/pogoda/news-pogodowej-hustawki-ciag-dalszy-uwaga-na-oblodzenia,nId,7305910)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T17:00:47+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-pogodowej-hustawki-ciag-dalszy-uwaga-na-oblodzenia,nId,7305910"><img align="left" alt="Pogodowej huśtawki ciąg dalszy. Uwaga na oblodzenia!" src="https://interia-s.pluscdn.pl/pogodowej-hustawki-ciag-dalszy-uwaga-na-oblodzenia/000IIN6MG7ORV65A-C307.jpg" /></a>​Piątek będzie pochmurny i deszczowy. Popada też deszcz ze śniegiem i śnieg. Wieczorem zacznie wiać silny wiatr. Termometry wskażą od -1 do 7 stopni C. - poinformował Michał Ogrodnik, synoptyk Centralnego Biura Prognoz Instytutu Meteorologii i Gospodarki Wodnej.</p><br clear="all" />

## Ubywa Polaków. Mamy poważny problem demograficzny
 - [https://www.rmf24.pl/fakty/polska/news-ubywa-polakow-mamy-powazny-problem-demograficzny,nId,7305860](https://www.rmf24.pl/fakty/polska/news-ubywa-polakow-mamy-powazny-problem-demograficzny,nId,7305860)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T16:08:02+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-ubywa-polakow-mamy-powazny-problem-demograficzny,nId,7305860"><img align="left" alt="Ubywa Polaków. Mamy poważny problem demograficzny" src="https://interia-s.pluscdn.pl/ubywa-polakow-mamy-powazny-problem-demograficzny/000IIMJT9AOLY3ID-C307.jpg" /></a>Ubyło 137 tysięcy Polaków - to tyle ile wynosi ludność Rybnika. W naszym kraju rodzi się mniej dzieci niż prognozowano. </p><br clear="all" />

## Tusk: Skończyła się epoka dwuznaczności i dziwnych gierek
 - [https://www.rmf24.pl/polityka/news-tusk-skonczyla-sie-epoka-dwuznacznosci-i-dziwnych-gierek,nId,7305814](https://www.rmf24.pl/polityka/news-tusk-skonczyla-sie-epoka-dwuznacznosci-i-dziwnych-gierek,nId,7305814)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T15:46:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-tusk-skonczyla-sie-epoka-dwuznacznosci-i-dziwnych-gierek,nId,7305814"><img align="left" alt="Tusk: Skończyła się epoka dwuznaczności i dziwnych gierek" src="https://interia-s.pluscdn.pl/tusk-skonczyla-sie-epoka-dwuznacznosci-i-dziwnych-gierek/000IIM79N70HEIFK-C307.jpg" /></a>&quot;Mamy w tej chwili pomoc dla Ukrainy na 4 lata, to jest więcej niż epoka&quot; – stwierdził po zakończonym szczycie Unii Europejskiej w Brukseli premier Donald Tusk. &quot;Skończyła się epoka dwuznaczności i dziwnych gierek. Jestem z tego bardzo dumny, że zobaczyłem znowu Europę z takimi wysokimi standardami i gotową do działania, do podejmowania decyzji&quot; – podkreślał. </p><br clear="all" />

## Ryszard Schnepf gościem w Popołudniowej rozmowie w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-ryszard-schnepf-gosciem-w-popoludniowej-rozmowie-w-rmf-fm,nId,7305810](https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-ryszard-schnepf-gosciem-w-popoludniowej-rozmowie-w-rmf-fm,nId,7305810)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T15:27:16+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/popoludniowa-rozmowa/news-ryszard-schnepf-gosciem-w-popoludniowej-rozmowie-w-rmf-fm,nId,7305810"><img align="left" alt="Ryszard Schnepf gościem w Popołudniowej rozmowie w RMF FM" src="https://interia-s.pluscdn.pl/ryszard-schnepf-gosciem-w-popoludniowej-rozmowie-w-rmf-fm/000IIM70CSYJQ38Y-C307.jpg" /></a>Gościem Marka Tejchmana w Popołudniowej rozmowie w RMF FM będzie były ambasador RP w USA, były wiceminister spraw zagranicznych Ryszard Schnepf. Porozmawiamy z nim m.in. o Polsce w Europie i na świecie, o Unii Europejskiej, Ukrainie, USA i Bliskim Wschodzie. </p><br clear="all" />

## Podczas kontroli drogowej policjant użył broni. We Wrocławiu trwa obława
 - [https://www.rmf24.pl/regiony/wroclaw/news-podczas-kontroli-drogowej-policjant-uzyl-broni-we-wroclawiu-,nId,7305802](https://www.rmf24.pl/regiony/wroclaw/news-podczas-kontroli-drogowej-policjant-uzyl-broni-we-wroclawiu-,nId,7305802)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T15:10:07+00:00

<p><a href="https://www.rmf24.pl/regiony/wroclaw/news-podczas-kontroli-drogowej-policjant-uzyl-broni-we-wroclawiu-,nId,7305802"><img align="left" alt="Podczas kontroli drogowej policjant użył broni. We Wrocławiu trwa obława" src="https://interia-s.pluscdn.pl/podczas-kontroli-drogowej-policjant-uzyl-broni-we-wroclawiu/000IIM0D3PCN87B0-C307.jpg" /></a>We Wrocławiu trwa obława na kierowcę volkswagena passata, który podczas kontroli drogowej ruszył swoim pojazdem w kierunku policjanta. Funkcjonariusz użył broni służbowej. Nikomu nic się nie stało.</p><br clear="all" />

## Ogromne protesty rolników w Belgii. "Elity chcą żebyśmy zniknęli"
 - [https://www.rmf24.pl/fakty/swiat/news-ogromne-protesty-rolnikow-w-belgii-elity-chca-zebysmy-znikne,nId,7305781](https://www.rmf24.pl/fakty/swiat/news-ogromne-protesty-rolnikow-w-belgii-elity-chca-zebysmy-znikne,nId,7305781)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T15:10:06+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-ogromne-protesty-rolnikow-w-belgii-elity-chca-zebysmy-znikne,nId,7305781"><img align="left" alt="Ogromne protesty rolników w Belgii. &quot;Elity chcą żebyśmy zniknęli&quot;" src="https://interia-s.pluscdn.pl/ogromne-protesty-rolnikow-w-belgii-elity-chca-zebysmy-znikne/000IILZJ98GLMDYT-C307.jpg" /></a>Od poniedziałku dziesiątki traktorów blokują ulice przy Placu Luksemburskim w Brukseli. Od środy wieczorem w Dzielnicy Europejskiej słychać już głównie klaksony. Unijni rolnicy protestują przeciwko wspólnotowej polityce rolnej. Demonstracje stają się coraz bardziej gwałtowne. Na brukselskich ulicach płoną opony, niszczone są zabytkowe pomniki. To będzie długi dzień w Brukseli, gdzie skończył się niedawno szczyt UE.</p><br clear="all" />

## Paraliż większości niemieckich lotnisk. Związkowcy chcą przedłużyć protest
 - [https://www.rmf24.pl/fakty/swiat/news-paraliz-wiekszosci-niemieckich-lotnisk-zwiazkowcy-chca-przed,nId,7305785](https://www.rmf24.pl/fakty/swiat/news-paraliz-wiekszosci-niemieckich-lotnisk-zwiazkowcy-chca-przed,nId,7305785)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T14:43:32+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-paraliz-wiekszosci-niemieckich-lotnisk-zwiazkowcy-chca-przed,nId,7305785"><img align="left" alt="Paraliż większości niemieckich lotnisk. Związkowcy chcą przedłużyć protest" src="https://interia-s.pluscdn.pl/paraliz-wiekszosci-niemieckich-lotnisk-zwiazkowcy-chca-przed/000IIM06BUDACS30-C307.jpg" /></a>Trwa strajk pracowników jedenastu największych niemieckich lotnisk. Akcja miała zakończyć się w czwartek wieczorem, ale związek zawodowy Verdi nawołuje pracowników z Hamburga do przedłużenia protestu o kolejną dobę - poinformowała dpa.</p><br clear="all" />

## 4-letnia Alicja i 3-letni Marcel poszukiwani przez policję
 - [https://www.rmf24.pl/regiony/krakow/news-4-letnia-alicja-i-3-letni-marcel-poszukiwani-przez-policje,nId,7305769](https://www.rmf24.pl/regiony/krakow/news-4-letnia-alicja-i-3-letni-marcel-poszukiwani-przez-policje,nId,7305769)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T14:23:57+00:00

<p><a href="https://www.rmf24.pl/regiony/krakow/news-4-letnia-alicja-i-3-letni-marcel-poszukiwani-przez-policje,nId,7305769"><img align="left" alt="4-letnia Alicja i 3-letni Marcel poszukiwani przez policję" src="https://interia-s.pluscdn.pl/4-letnia-alicja-i-3-letni-marcel-poszukiwani-przez-policje/000IIKPM7K9MCS3X-C307.jpg" /></a>Limanowska policja poszukuje 4-letniej Alicji i jej brata, 3-letniego Marcela. Ojciec wczoraj nie odwiózł dzieci do matki, która zgłosiła sprawę na policję.</p><br clear="all" />

## Limanowa: Szczęśliwy finał poszukiwań. Dzieci odnalezione przez policję
 - [https://www.rmf24.pl/regiony/krakow/news-limanowa-szczesliwy-final-poszukiwan-dzieci-odnalezione-prze,nId,7305769](https://www.rmf24.pl/regiony/krakow/news-limanowa-szczesliwy-final-poszukiwan-dzieci-odnalezione-prze,nId,7305769)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T14:23:57+00:00

<p><a href="https://www.rmf24.pl/regiony/krakow/news-limanowa-szczesliwy-final-poszukiwan-dzieci-odnalezione-prze,nId,7305769"><img align="left" alt="Limanowa: Szczęśliwy finał poszukiwań. Dzieci odnalezione przez policję" src="https://interia-s.pluscdn.pl/limanowa-szczesliwy-final-poszukiwan-dzieci-odnalezione-prze/000IIOETFQJEF0PI-C307.jpg" /></a>Limanowska policja poinformowała wieczorem o odnalezieniu 4-letniej Alicji i jej brata, 3-letniego Marcela. Podkreślono, że dzieci są całe i zdrowe.</p><br clear="all" />

## Prezydencki zawód
 - [https://www.rmf24.pl/polityka/news-prezydencki-zawod,nId,7305645](https://www.rmf24.pl/polityka/news-prezydencki-zawod,nId,7305645)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T12:06:00+00:00

<p><a href="https://www.rmf24.pl/polityka/news-prezydencki-zawod,nId,7305645"><img align="left" alt="Prezydencki zawód" src="https://interia-s.pluscdn.pl/prezydencki-zawod/000IIILXYAIQ7RBA-C307.jpg" /></a>Taki zawód czuje pewnie każdy, kto oczekiwał, że w oświadczeniu wygłoszonym dzień po decyzji o podpisaniu, ale i odesłaniu do Trybunału Konstytucyjnego ustawy budżetowej Andrzej Duda cokolwiek wyjaśni. Zapowiedziany wczoraj zamiar kierowania do Trybunału każdej ustawy uchwalonej bez udziału Mariusza Kamińskiego i Macieja Wąsika zostaje więc w mocy, a to upoważnia do przewidywań, czym się to może skończyć. Poza, oczywiście, demontażem autorytetu głowy państwa.</p><br clear="all" />

## Rosyjska rakieta nad Polską. Prokuratura wszczęła śledztwo
 - [https://www.rmf24.pl/fakty/polska/news-rosyjska-rakieta-nad-polska-prokuratura-wszczela-sledztwo,nId,7305642](https://www.rmf24.pl/fakty/polska/news-rosyjska-rakieta-nad-polska-prokuratura-wszczela-sledztwo,nId,7305642)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T12:01:11+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-rosyjska-rakieta-nad-polska-prokuratura-wszczela-sledztwo,nId,7305642"><img align="left" alt="Rosyjska rakieta nad Polską. Prokuratura wszczęła śledztwo" src="https://interia-s.pluscdn.pl/rosyjska-rakieta-nad-polska-prokuratura-wszczela-sledztwo/000IIIL1EBE24DIJ-C307.jpg" /></a>W związku z niepokojącym zdarzeniem, do którego doszło 29 grudnia 2023 roku, informuję, że Dział Wojskowy Prokuratury Rejonowej w Lublinie wszczął śledztwo w sprawie naruszenia przestrzeni powietrznej RP przez niezidentyfikowany obiekt latający - poinformował rzecznik Prokuratury Okręgowej w Warszawie prok. Szymon Banna.</p><br clear="all" />

## Auto jechało pod prąd, nie żyje jedna osoba. Tragiczny wypadek na S5
 - [https://www.rmf24.pl/regiony/poznan/news-auto-jechalo-pod-prad-nie-zyje-jedna-osoba-tragiczny-wypadek,nId,7305628](https://www.rmf24.pl/regiony/poznan/news-auto-jechalo-pod-prad-nie-zyje-jedna-osoba-tragiczny-wypadek,nId,7305628)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T11:51:20+00:00

<p><a href="https://www.rmf24.pl/regiony/poznan/news-auto-jechalo-pod-prad-nie-zyje-jedna-osoba-tragiczny-wypadek,nId,7305628"><img align="left" alt="Auto jechało pod prąd, nie żyje jedna osoba. Tragiczny wypadek na S5" src="https://interia-s.pluscdn.pl/auto-jechalo-pod-prad-nie-zyje-jedna-osoba-tragiczny-wypadek/000IIIEV000YVK7B-C307.jpg" /></a>Około południa na drodze ekspresowej S5, niedaleko wielkopolskiej miejscowości Kawczyn, doszło do poważnego wypadku z udziałem dwóch samochodów osobowych. Niestety, jedna osoba zginęła, a druga została ranna. Na miejsce zadysponowano śmigłowiec Lotniczego Pogotowia Ratunkowego; droga w kierunku Wrocławia była zablokowana.</p><br clear="all" />

## Tusk skomentował odwołanie Obajtka. "Dobry czwartek"
 - [https://www.rmf24.pl/polityka/news-tusk-skomentowal-odwolanie-obajtka-dobry-czwartek,nId,7305579](https://www.rmf24.pl/polityka/news-tusk-skomentowal-odwolanie-obajtka-dobry-czwartek,nId,7305579)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T11:32:42+00:00

<p><a href="https://www.rmf24.pl/polityka/news-tusk-skomentowal-odwolanie-obajtka-dobry-czwartek,nId,7305579"><img align="left" alt="Tusk skomentował odwołanie Obajtka. &quot;Dobry czwartek&quot; " src="https://interia-s.pluscdn.pl/tusk-skomentowal-odwolanie-obajtka-dobry-czwartek/000III6WD0WJYAJU-C307.jpg" /></a>Donald Tusk komentuje odwołanie Daniela Obajtka z zarządu Orlenu. &quot;Dobry czwartek. Wiktora Orbana dało się „przekonać”, Daniela Obajtka dało się odwołać. Jedziemy dalej&quot; – napisał na portalu X premier. </p><br clear="all" />

## 8-latka potrącona przez nauczycielkę. Nowe fakty ws. stanu zdrowia dziecka
 - [https://www.rmf24.pl/regiony/wroclaw/news-8-latka-potracona-przez-nauczycielke-nowe-fakty-ws-stanu-zdr,nId,7305585](https://www.rmf24.pl/regiony/wroclaw/news-8-latka-potracona-przez-nauczycielke-nowe-fakty-ws-stanu-zdr,nId,7305585)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T11:05:07+00:00

<p><a href="https://www.rmf24.pl/regiony/wroclaw/news-8-latka-potracona-przez-nauczycielke-nowe-fakty-ws-stanu-zdr,nId,7305585"><img align="left" alt="8-latka potrącona przez nauczycielkę. Nowe fakty ws. stanu zdrowia dziecka" src="https://interia-s.pluscdn.pl/8-latka-potracona-przez-nauczycielke-nowe-fakty-ws-stanu-zdr/000III3DT7KAOJPX-C307.jpg" /></a>Prokuratura Rejonowa w Dzierżoniowie na Dolnym Śląsku wszczęła śledztwo w sprawie nieumyślnego spowodowania wypadku drogowego z ciężko ranną ofiarą. Chodzi o wczorajsze potrącenie przez nauczycielkę ośmioletniej dziewczynki na przyszkolnym parkingu w Bielawie.</p><br clear="all" />

## Prezydent podjął decyzję o zwołaniu Rady Gabinetowej
 - [https://www.rmf24.pl/polityka/news-prezydent-podjal-decyzje-o-zwolaniu-rady-gabinetowej,nId,7305567](https://www.rmf24.pl/polityka/news-prezydent-podjal-decyzje-o-zwolaniu-rady-gabinetowej,nId,7305567)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T10:42:24+00:00

<p><a href="https://www.rmf24.pl/polityka/news-prezydent-podjal-decyzje-o-zwolaniu-rady-gabinetowej,nId,7305567"><img align="left" alt="Prezydent podjął decyzję o zwołaniu Rady Gabinetowej" src="https://interia-s.pluscdn.pl/prezydent-podjal-decyzje-o-zwolaniu-rady-gabinetowej/000III0WMAM9GKFE-C307.jpg" /></a>Wydam dzisiaj postanowienie o zwołaniu Rady Gabinetowej - poinformował prezydent Andrzej Duda, dodając, że posiedzenie odbędzie się 13 lutego o godz. 13:00. Tematem rozmów będzie realizacja inwestycji takich jak Centralny Port Komunikacyjny, kwestia energetyki jądrowej oraz modernizacja polskiej armii.</p><br clear="all" />

## Jest unijny pakiet wsparcia dla Ukrainy. Orban się ugiął
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-jest-unijny-pakiet-wsparcia-dla-ukrainy-orban-sie-ugial,nId,7305564](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-jest-unijny-pakiet-wsparcia-dla-ukrainy-orban-sie-ugial,nId,7305564)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T10:39:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-jest-unijny-pakiet-wsparcia-dla-ukrainy-orban-sie-ugial,nId,7305564"><img align="left" alt="Jest unijny pakiet wsparcia dla Ukrainy. Orban się ugiął" src="https://interia-s.pluscdn.pl/jest-unijny-pakiet-wsparcia-dla-ukrainy-orban-sie-ugial/000III39757I1N6V-C307.jpg" /></a>Wszystkich 27 przywódców zgodziło się na pakiet wsparcia dla Ukrainy w wysokości 50 mld euro w ramach budżetu UE - poinformował szef Rady Europejskiej Charles Michel. </p><br clear="all" />

## Szczęśliwy finał poszukiwań rodzeństwa. Dzieci odnalazły się w Niemczech
 - [https://www.rmf24.pl/regiony/news-szczesliwy-final-poszukiwan-rodzenstwa-dzieci-odnalazly-sie-,nId,7305554](https://www.rmf24.pl/regiony/news-szczesliwy-final-poszukiwan-rodzenstwa-dzieci-odnalazly-sie-,nId,7305554)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T10:27:10+00:00

<p><a href="https://www.rmf24.pl/regiony/news-szczesliwy-final-poszukiwan-rodzenstwa-dzieci-odnalazly-sie-,nId,7305554"><img align="left" alt="Szczęśliwy finał poszukiwań rodzeństwa. Dzieci odnalazły się w Niemczech " src="https://interia-s.pluscdn.pl/szczesliwy-final-poszukiwan-rodzenstwa-dzieci-odnalazly-sie/000IIHY4NT8MIQ39-C307.jpg" /></a>Szczęśliwy finał poszukiwań rodzeństwa z Nysy na Opolszczyźnie. Dzieci w wieku 14 i 10 lat były poszukiwane od wczorajszego popołudnia. Dzisiaj rano odnaleziono je po niemieckiej stronie granicy.</p><br clear="all" />

## Szefowie firm technologicznych przesłuchani. Zuckerberg: Przepraszam za wszystko
 - [https://www.rmf24.pl/fakty/swiat/news-szefowie-firm-technologicznych-przesluchani-zuckerberg-przep,nId,7305462](https://www.rmf24.pl/fakty/swiat/news-szefowie-firm-technologicznych-przesluchani-zuckerberg-przep,nId,7305462)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T10:03:55+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-szefowie-firm-technologicznych-przesluchani-zuckerberg-przep,nId,7305462"><img align="left" alt="Szefowie firm technologicznych przesłuchani. Zuckerberg: Przepraszam za wszystko" src="https://interia-s.pluscdn.pl/szefowie-firm-technologicznych-przesluchani-zuckerberg-przep/000IIHDZ2PG34B87-C307.jpg" /></a>W Senacie USA odbyły się przesłuchania szefów gigantów technologicznych, które dotyczyły bezpieczeństwa w internecie. Na pytania polityków odpowiadał m.in. Mark Zuckerberg. Biznesmen zwrócił się do rodzin, które twierdzą, że ich dzieci zostały skrzywdzone przez media społecznościowe. &quot;Przepraszam za wszystko, przez co musieliście przejść&quot; - mówił.</p><br clear="all" />

## Daniel Obajtek odwołany z zarządu Orlenu
 - [https://www.rmf24.pl/ekonomia/news-daniel-obajtek-odwolany-z-zarzadu-orlenu,nId,7305538](https://www.rmf24.pl/ekonomia/news-daniel-obajtek-odwolany-z-zarzadu-orlenu,nId,7305538)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T09:59:40+00:00

<p><a href="https://www.rmf24.pl/ekonomia/news-daniel-obajtek-odwolany-z-zarzadu-orlenu,nId,7305538"><img align="left" alt="Daniel Obajtek odwołany z zarządu Orlenu " src="https://interia-s.pluscdn.pl/daniel-obajtek-odwolany-z-zarzadu-orlenu/000IIHJDFI8PSUWY-C307.jpg" /></a>Daniel Obajtek został odwołany z zarządu Orlenu S.A. z upływem dnia 5 lutego 2024 roku. Taką informację przekazała paliwowa spółka. </p><br clear="all" />

## Komorowski o decyzji prezydenta: Stawia się w roli strażnika programu PiS
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-komorowski-o-decyzji-prezydenta-stawia-sie-w-roli-straznika-,nId,7305499](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-komorowski-o-decyzji-prezydenta-stawia-sie-w-roli-straznika-,nId,7305499)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T09:15:28+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-w-poludnie/news-komorowski-o-decyzji-prezydenta-stawia-sie-w-roli-straznika-,nId,7305499"><img align="left" alt="Komorowski o decyzji prezydenta: Stawia się w roli strażnika programu PiS" src="https://interia-s.pluscdn.pl/komorowski-o-decyzji-prezydenta-stawia-sie-w-roli-straznika/000IIGVQSSLMCVFI-C307.jpg" /></a>„Myślę, że należy to interpretować jako próbę wyjścia prezydenta z cienia i zaistnienia. Pan prezydent sam siebie ustawia, co wcześniej zapowiadał, w roli nie strażnika konstytucji – bo nie spełnił tych obowiązków - natomiast w roli strażnika programu Prawa i Sprawiedliwości” – tak Bronisław Komorowski w Rozmowie w południe w Radiu RMF24 skomentował zwołaniu przez prezydenta Andrzeja Dudę Rady Gabinetowej. </p><br clear="all" />

## Polscy kierowcy ciężarówek atakowani we Francji
 - [https://www.rmf24.pl/fakty/swiat/news-polscy-kierowcy-ciezarowek-atakowani-we-francji,nId,7305361](https://www.rmf24.pl/fakty/swiat/news-polscy-kierowcy-ciezarowek-atakowani-we-francji,nId,7305361)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T08:52:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-polscy-kierowcy-ciezarowek-atakowani-we-francji,nId,7305361"><img align="left" alt="Polscy kierowcy ciężarówek atakowani we Francji" src="https://interia-s.pluscdn.pl/polscy-kierowcy-ciezarowek-atakowani-we-francji/000IIEIAI6AXTCAF-C307.jpg" /></a>Co najmniej dwaj polscy kierowcy zostali zaatakowani we Francji przez blokujących drogi rolników. Ci ostatni zatrzymują zagraniczne ciężarówki - w tym z Polski, Litwy, Czech, Hiszpanii i Włoch - i niszczą transportowane z tych krajów produkty spożywcze, a czasami również pojazdy. Dochodzi do przemocy fizycznej.</p><br clear="all" />

## Całonocna akcja w Beskidach. Ratownicy poszukiwali snowboardzisty
 - [https://www.rmf24.pl/regiony/slaskie/news-calonocna-akcja-w-beskidach-ratownicy-poszukiwali-snowboardz,nId,7305414](https://www.rmf24.pl/regiony/slaskie/news-calonocna-akcja-w-beskidach-ratownicy-poszukiwali-snowboardz,nId,7305414)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T07:27:00+00:00

<p><a href="https://www.rmf24.pl/regiony/slaskie/news-calonocna-akcja-w-beskidach-ratownicy-poszukiwali-snowboardz,nId,7305414"><img align="left" alt="Całonocna akcja w Beskidach. Ratownicy poszukiwali snowboardzisty" src="https://interia-s.pluscdn.pl/calonocna-akcja-w-beskidach-ratownicy-poszukiwali-snowboardz/000IIF7UV9ME7PYT-C307.jpg" /></a>Całonocna akcja Horskiej Zachrannej Służby i polskiego GOPR w masywie Pilska w Beskidach. Ratownicy poszukiwali 46-letniego snowboardzisty. </p><br clear="all" />

## Przemycała 130 jadowitych żab. Brazylijka zatrzymana na lotnisku
 - [https://www.rmf24.pl/fakty/swiat/news-przemycala-130-jadowitych-zab-brazylijka-zatrzymana-na-lotni,nId,7305384](https://www.rmf24.pl/fakty/swiat/news-przemycala-130-jadowitych-zab-brazylijka-zatrzymana-na-lotni,nId,7305384)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T06:36:55+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-przemycala-130-jadowitych-zab-brazylijka-zatrzymana-na-lotni,nId,7305384"><img align="left" alt="Przemycała 130 jadowitych żab. Brazylijka zatrzymana na lotnisku" src="https://interia-s.pluscdn.pl/przemycala-130-jadowitych-zab-brazylijka-zatrzymana-na-lotni/000IIELPR5DIEHA1-C307.jpg" /></a>Nietypowe zatrzymanie na lotnisku w Bogocie. W bagażu kobiety, która zamierzała dotrzeć do Sao Paulo, policja znalazła 130 jadowitych żab. Drzewołaz wytworny to gatunek krytycznie zagrożony.</p><br clear="all" />

## Krzysztof Kukucki gościem Porannej rozmowy w RMF FM
 - [https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-krzysztof-kukucki-gosciem-porannej-rozmowy-w-rmf-fm,nId,7303947](https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-krzysztof-kukucki-gosciem-porannej-rozmowy-w-rmf-fm,nId,7303947)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T06:20:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/poranna-rozmowa/news-krzysztof-kukucki-gosciem-porannej-rozmowy-w-rmf-fm,nId,7303947"><img align="left" alt="Krzysztof Kukucki gościem Porannej rozmowy w RMF FM" src="https://interia-s.pluscdn.pl/krzysztof-kukucki-gosciem-porannej-rozmowy-w-rmf-fm/000IID1XOU8MFCE1-C307.jpg" /></a>Gościem Porannej rozmowy w RMF FM będzie wiceminister rozwoju i technologii, senator Lewicy Krzysztof Kukucki. Porozmawiamy z nim m.in. o nowym programie &quot;Mieszkanie na start&quot;, który - jak oceniają eksperci - zapowiada się mniej korzystnie niż wprowadzony w czasach PiS &quot;Bezpieczny kredyt 2%&quot;. A co z budową tanich mieszkań na wynajem, które Lewica obiecywała w kampanii?</p><br clear="all" />

## Nie milion, a 500 tys. UE nie wywiązała się z obietnicy złożonej Ukrainie
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-nie-milion-a-500-tys-ue-nie-wywiazala-sie-z-obietnicy-zlozon,nId,7305366](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-nie-milion-a-500-tys-ue-nie-wywiazala-sie-z-obietnicy-zlozon,nId,7305366)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T06:18:35+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/news-nie-milion-a-500-tys-ue-nie-wywiazala-sie-z-obietnicy-zlozon,nId,7305366"><img align="left" alt="Nie milion, a 500 tys. UE nie wywiązała się z obietnicy złożonej Ukrainie" src="https://interia-s.pluscdn.pl/nie-milion-a-500-tys-ue-nie-wywiazala-sie-z-obietnicy-zlozon/000IIEL3XXWQ1UAT-C307.jpg" /></a>Unia Europejska nie wywiązała się ze złożonej w ubiegłym roku Ukrainie obietnicy dotyczącej amunicji. Krajom Wspólnoty nie uda się dostarczyć do marca miliona pocisków artyleryjskich. Kijów otrzyma zaledwie połowę tej liczby.</p><br clear="all" />

## Polsko-ukraińskie fabryki amunicji. Kniażycki: Rozmawiamy z rządem Tuska
 - [https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-polsko-ukrainskie-fabryki-amunicji-kniazycki-rozmawiamy-z-rz,nId,7303701](https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-polsko-ukrainskie-fabryki-amunicji-kniazycki-rozmawiamy-z-rz,nId,7303701)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T06:02:00+00:00

<p><a href="https://www.rmf24.pl/tylko-w-rmf24/rozmowa-o-7/news-polsko-ukrainskie-fabryki-amunicji-kniazycki-rozmawiamy-z-rz,nId,7303701"><img align="left" alt="Polsko-ukraińskie fabryki amunicji. Kniażycki: Rozmawiamy z rządem Tuska " src="https://interia-s.pluscdn.pl/polsko-ukrainskie-fabryki-amunicji-kniazycki-rozmawiamy-z-rz/000IIC6OMIQ7Q5HY-C307.jpg" /></a>&quot;Prowadzimy rozmowy ze Stanami Zjednoczonymi, żeby przekazały nam technologię od producentów amunicji. Myślę, że to jest najlepszy sposób, aby produkować amunicję we wspólnych przedsiębiorstwach ukraińsko-polskich w Polsce&quot; – przekazał w Rozmowie o 7:00 w Radiu RMF24 Mykoła Kniażycki. |Na ten temat mówi nasze Ministerstwo Obrony i o tym rozmawiamy z rządem Tuska&quot; – powiedział deputowany opozycyjnej Europejskiej Solidarności w Radzie Najwyższej Ukrainy i współprzewodniczący ukraińsko-polskiej grupy parlamentarnej. </p><br clear="all" />

## Kara dyscyplinarna dla policjanta w związku ze śmiercią 14-latki z Andrychowa
 - [https://www.rmf24.pl/regiony/krakow/news-kara-dyscyplinarna-dla-policjanta-w-zwiazku-ze-smiercia-14-l,nId,7303169](https://www.rmf24.pl/regiony/krakow/news-kara-dyscyplinarna-dla-policjanta-w-zwiazku-ze-smiercia-14-l,nId,7303169)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T06:00:00+00:00

<p><a href="https://www.rmf24.pl/regiony/krakow/news-kara-dyscyplinarna-dla-policjanta-w-zwiazku-ze-smiercia-14-l,nId,7303169"><img align="left" alt="Kara dyscyplinarna dla policjanta w związku ze śmiercią 14-latki z Andrychowa " src="https://interia-s.pluscdn.pl/kara-dyscyplinarna-dla-policjanta-w-zwiazku-ze-smiercia-14-l/000II3EYQ39Y5TP3-C307.jpg" /></a>Jest pierwsza kara dyscyplinarna dla policjanta w związku ze śmiercią 14-letniej Natalii z Andrychowa - dowiedział się dziennikarz RMF FM Krzysztof Zasada. Dziewczyna była 28 listopada bezskutecznie poszukiwana przez funkcjonariuszy. Znaleziono ją koło jednego z andrychowskich sklepów, nieopodal siedziby policji. Dzień później nastolatka zmarła. </p><br clear="all" />

## Silny wiatr i śnieg. Sprawdź prognozę pogody na czwartek
 - [https://www.rmf24.pl/pogoda/news-silny-wiatr-i-snieg-sprawdz-prognoze-pogody-na-czwartek,nId,7305365](https://www.rmf24.pl/pogoda/news-silny-wiatr-i-snieg-sprawdz-prognoze-pogody-na-czwartek,nId,7305365)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T05:50:00+00:00

<p><a href="https://www.rmf24.pl/pogoda/news-silny-wiatr-i-snieg-sprawdz-prognoze-pogody-na-czwartek,nId,7305365"><img align="left" alt="Silny wiatr i śnieg. Sprawdź prognozę pogody na czwartek " src="https://interia-s.pluscdn.pl/silny-wiatr-i-snieg-sprawdz-prognoze-pogody-na-czwartek/000IIEJF7AVI0GCB-C307.jpg" /></a>Dziś w prognozach deszcz, deszcz ze śniegiem i śnieg. Wiatr najsilniej powieje na północy Polski. &quot;W całym kraju będzie dodatnia temperatura&quot; - przekazała Agnieszka Prasek, synoptyk z Centralnego Biura Prognoz Instytutu Meteorologii i Gospodarki Wodnej.</p><br clear="all" />

## Rosyjska bomba spadła na szpital w obwodzie charkowskim [RELACJA]
 - [https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-rosyjska-bomba-spadla-na-szpital-w-obwodzie-charkowskim-rela,nId,7305355](https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-rosyjska-bomba-spadla-na-szpital-w-obwodzie-charkowskim-rela,nId,7305355)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T05:05:00+00:00

<p><a href="https://www.rmf24.pl/raporty/raport-wojna-z-rosja/na-zywo/news-rosyjska-bomba-spadla-na-szpital-w-obwodzie-charkowskim-rela,nId,7305355"><img align="left" alt="Rosyjska bomba spadła na szpital w obwodzie charkowskim [RELACJA] " src="https://interia-s.pluscdn.pl/rosyjska-bomba-spadla-na-szpital-w-obwodzie-charkowskim-rela/000IIEHXVR5HYGDJ-C307.jpg" /></a>Rosyjska bomba uderzyła w budynek szpitala w miejscowości Welikij Burłuk położonej na północny wschód od Charkowa. 4 osoby zostały ranne, 38 osób ewakuowano. Sam Charków także znalazł się pod rosyjskim ostrzałem tej nocy. Czwartek jest 708. dniem rosyjskiej inwazji na Ukrainę. Najważniejsze informacje dotyczące sytuacji za naszą wschodnią granicą zbieramy w relacji.</p><br clear="all" />

## Od dzisiaj można składać wnioski o 800+ na kolejny sezon
 - [https://www.rmf24.pl/fakty/polska/news-wazna-data-dla-rodzicow-od-dzisiaj-mozna-skladac-wnioski-o-8,nId,7305357](https://www.rmf24.pl/fakty/polska/news-wazna-data-dla-rodzicow-od-dzisiaj-mozna-skladac-wnioski-o-8,nId,7305357)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T04:56:00+00:00

<p><a href="https://www.rmf24.pl/fakty/polska/news-wazna-data-dla-rodzicow-od-dzisiaj-mozna-skladac-wnioski-o-8,nId,7305357"><img align="left" alt="Od dzisiaj można składać wnioski o 800+ na kolejny sezon" src="https://interia-s.pluscdn.pl/od-dzisiaj-mozna-skladac-wnioski-o-800-na-kolejny-sezon/000IIEGKOABPM2CM-C307.jpg" /></a>Od dzisiaj możecie składać wnioski o 800+ na kolejny okres świadczeniowy, czyli od czerwca. Jeśli zrobicie to w ciągu trzech miesięcy, przelewy otrzymacie bez przerwy, z zachowaniem ciągłości wypłat.</p><br clear="all" />

## Jak Amerykanie mogą odpowiedzieć na atak na bazę w Jordanii? Media ujawniają
 - [https://www.rmf24.pl/fakty/swiat/news-jak-amerykanie-moga-odpowiedziec-na-atak-na-baze-w-jordanii-,nId,7305356](https://www.rmf24.pl/fakty/swiat/news-jak-amerykanie-moga-odpowiedziec-na-atak-na-baze-w-jordanii-,nId,7305356)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T04:35:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-jak-amerykanie-moga-odpowiedziec-na-atak-na-baze-w-jordanii-,nId,7305356"><img align="left" alt="Jak Amerykanie mogą odpowiedzieć na atak na bazę w Jordanii? Media ujawniają" src="https://interia-s.pluscdn.pl/jak-amerykanie-moga-odpowiedziec-na-atak-na-baze-w-jordanii/000IIEF72IFJIW09-C307.jpg" /></a>Odpowiedzią USA na zabójczy atak na żołnierzy USA w Jordanii będzie kilkutygodniową kampanią, która będzie polegać zarówno na atakach militarnych, jak i cybernetycznych – przekazała telewizja NBC News. Doniesienia zdaje się potwierdzać Biały Dom, który zapowiedział, że pierwsze uderzenie nie będzie ostatnim.</p><br clear="all" />

## Jak Amerykanie mogą odpowiedzieć za atak na bazę w Jordanii? Media ujawniają
 - [https://www.rmf24.pl/fakty/swiat/news-jak-amerykanie-moga-odpowiedziec-za-atak-na-baze-w-jordanii-,nId,7305356](https://www.rmf24.pl/fakty/swiat/news-jak-amerykanie-moga-odpowiedziec-za-atak-na-baze-w-jordanii-,nId,7305356)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T04:35:00+00:00

<p><a href="https://www.rmf24.pl/fakty/swiat/news-jak-amerykanie-moga-odpowiedziec-za-atak-na-baze-w-jordanii-,nId,7305356"><img align="left" alt="Jak Amerykanie mogą odpowiedzieć za atak na bazę w Jordanii? Media ujawniają" src="https://interia-s.pluscdn.pl/jak-amerykanie-moga-odpowiedziec-za-atak-na-baze-w-jordanii/000IIEF72IFJIW09-C307.jpg" /></a>Odpowiedzią USA na zabójczy atak na żołnierzy USA w Jordanii będzie kilkutygodniową kampanią, która będzie polegać zarówno na atakach militarnych, jak i cybernetycznych – przekazała telewizja NBC News. Doniesienia zdaje się potwierdzać Biały Dom, który zapowiedział, że pierwsze uderzenie nie będzie ostatnim.</p><br clear="all" />

## Tragedia na planie "Rust". Alec Baldwin nie przyznał się do winy
 - [https://www.rmf24.pl/kultura/news-tragedia-na-planie-rust-alec-baldwin-nie-przyznal-sie-do-win,nId,7305354](https://www.rmf24.pl/kultura/news-tragedia-na-planie-rust-alec-baldwin-nie-przyznal-sie-do-win,nId,7305354)
 - RSS feed: https://www.rmf24.pl/feed
 - date published: 2024-02-01T04:17:00+00:00

<p><a href="https://www.rmf24.pl/kultura/news-tragedia-na-planie-rust-alec-baldwin-nie-przyznal-sie-do-win,nId,7305354"><img align="left" alt="Tragedia na planie &quot;Rust&quot;. Alec Baldwin nie przyznał się do winy   " src="https://interia-s.pluscdn.pl/tragedia-na-planie-rust-alec-baldwin-nie-przyznal-sie-do-win/000IIEEY4BBJRA4Q-C307.jpg" /></a>Gwiazdor filmowy Alec Baldwin ponownie nie przyznał się do nieumyślnego spowodowania śmierci operatorki Halyny Hutchins. Kobieta zmarła w wyniku postrzelenia na planie filmu „Rust” kręconego w Nowym Meksyku.</p><br clear="all" />

