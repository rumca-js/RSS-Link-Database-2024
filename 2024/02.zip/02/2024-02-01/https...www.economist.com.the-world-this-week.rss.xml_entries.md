# Source:The Economist, URL:https://www.economist.com/the-world-this-week/rss.xml, language:en

## Business
 - [https://www.economist.com/the-world-this-week/2024/02/01/business](https://www.economist.com/the-world-this-week/2024/02/01/business)
 - RSS feed: https://www.economist.com/the-world-this-week/rss.xml
 - date published: 2024-02-01T14:28:43+00:00



## KAL’s cartoon
 - [https://www.economist.com/the-world-this-week/2024/02/01/kals-cartoon](https://www.economist.com/the-world-this-week/2024/02/01/kals-cartoon)
 - RSS feed: https://www.economist.com/the-world-this-week/rss.xml
 - date published: 2024-02-01T14:28:43+00:00



## Politics
 - [https://www.economist.com/the-world-this-week/2024/02/01/politics](https://www.economist.com/the-world-this-week/2024/02/01/politics)
 - RSS feed: https://www.economist.com/the-world-this-week/rss.xml
 - date published: 2024-02-01T14:28:43+00:00



## This week’s covers
 - [https://www.economist.com/the-world-this-week/2024/02/01/this-weeks-covers](https://www.economist.com/the-world-this-week/2024/02/01/this-weeks-covers)
 - RSS feed: https://www.economist.com/the-world-this-week/rss.xml
 - date published: 2024-02-01T13:42:54+00:00

How we saw the world

