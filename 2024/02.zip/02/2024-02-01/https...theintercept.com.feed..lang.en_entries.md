# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## AIPAC Is the Largest Donor, By Far, to Jamaal Bowman’s Primary Challenger
 - [https://theintercept.com/2024/02/01/george-latimer-aipac-donors-jamaal-bowman](https://theintercept.com/2024/02/01/george-latimer-aipac-donors-jamaal-bowman)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-02-01T20:21:00+00:00

<p>George Latimer was recruited by AIPAC to challenge Bowman, a member of the Squad who has called for a Gaza ceasefire.</p>
<p>The post <a href="https://theintercept.com/2024/02/01/george-latimer-aipac-donors-jamaal-bowman/">AIPAC Is the Largest Donor, By Far, to Jamaal Bowman’s Primary Challenger</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## After Historic Ruling, Lawyers Vow to Keep Fighting Biden Over Complicity in Gaza Genocide
 - [https://theintercept.com/2024/02/01/gaza-biden-genocide-lawsuit-ruling](https://theintercept.com/2024/02/01/gaza-biden-genocide-lawsuit-ruling)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-02-01T19:59:36+00:00

<p>A federal judge dismissed a lawsuit against Biden but implored his administration to reconsider its “unflagging support” for Israel’s war on Gaza.</p>
<p>The post <a href="https://theintercept.com/2024/02/01/gaza-biden-genocide-lawsuit-ruling/">After Historic Ruling, Lawyers Vow to Keep Fighting Biden Over Complicity in Gaza Genocide</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## Summer Lee's Primary Opponent Wants Pro-Israel and Hindu Supporters to Take Down the Squad
 - [https://theintercept.com/2024/02/01/summer-lee-primary-bhavini-patel-republican](https://theintercept.com/2024/02/01/summer-lee-primary-bhavini-patel-republican)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-02-01T16:27:01+00:00

<p>At a closed-door fundraiser, Bhavini Patel told donors she was strategizing to get Republicans to vote against Lee in the Democratic primary.</p>
<p>The post <a href="https://theintercept.com/2024/02/01/summer-lee-primary-bhavini-patel-republican/">Summer Lee&#8217;s Primary Opponent Wants Pro-Israel and Hindu Supporters to Take Down the Squad</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

## Rep. Dan Goldman’s “Disgust” at South Africa’s Genocide Case Is Costing Him Votes
 - [https://theintercept.com/2024/02/01/dan-goldman-icj-israel-genocide](https://theintercept.com/2024/02/01/dan-goldman-icj-israel-genocide)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2024-02-01T15:46:28+00:00

<p>In a letter, more than 1,000 of Goldman’s constituents condemned him for lambasting charges of genocide against Israel at the International Court of Justice.</p>
<p>The post <a href="https://theintercept.com/2024/02/01/dan-goldman-icj-israel-genocide/">Rep. Dan Goldman’s “Disgust” at South Africa’s Genocide Case Is Costing Him Votes</a> appeared first on <a href="https://theintercept.com">The Intercept</a>.</p>

