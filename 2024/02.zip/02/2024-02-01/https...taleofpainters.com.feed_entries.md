# Source:Tale of Painters, URL:https://taleofpainters.com/feed, language:en-GB

## Showcase: Tomb Kings of Khemri Chariots (inc. painting guide)
 - [https://taleofpainters.com/2024/02/showcase-tomb-kings-of-khemri-chariots-inc-painting-guide](https://taleofpainters.com/2024/02/showcase-tomb-kings-of-khemri-chariots-inc-painting-guide)
 - RSS feed: https://taleofpainters.com/feed
 - date published: 2024-02-01T17:00:00+00:00

<p>When I started painting my Tomb Kings of Khemri army I promised myself I would cut corners and use efficiencies to speed through the painting. One of those efficient ways of working is sub-assemblies. In today's post I want to talk about how you can save time painting with a little planning. </p>
<p>The post <a href="https://taleofpainters.com/2024/02/showcase-tomb-kings-of-khemri-chariots-inc-painting-guide/">Showcase: Tomb Kings of Khemri Chariots (inc. painting guide)</a> appeared first on <a href="https://taleofpainters.com">Tale of Painters</a>.</p>

