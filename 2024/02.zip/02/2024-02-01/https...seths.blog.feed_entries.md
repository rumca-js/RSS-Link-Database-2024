# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## What to do with firm footing
 - [https://seths.blog/2024/02/what-to-do-with-firm-footing](https://seths.blog/2024/02/what-to-do-with-firm-footing)
 - RSS feed: https://seths.blog/feed
 - date published: 2024-02-01T10:29:00+00:00

If we&#8217;ve got tenure, a lifetime appointment or simply a really secure gig, what should we do with it? One option is to race to the bottom, to chase short-term self-focused outcomes and to see how much we can get away with. (Probably, quite a bit). The other is to take this rare chance to [&#8230;]

