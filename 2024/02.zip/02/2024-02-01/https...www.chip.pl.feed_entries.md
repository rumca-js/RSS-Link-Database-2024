# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Niemcy sięgają do kieszeni. Chcą raz na zawsze uwolnić się od wrogich dronów i pocisków
 - [https://www.chip.pl/2024/02/niemcy-ochrona-przeciwlotnicza-lvs-nnbs](https://www.chip.pl/2024/02/niemcy-ochrona-przeciwlotnicza-lvs-nnbs)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T22:26:13+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/06/Roje-dronow-wojskowych-USA.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/Roje-dronow-wojskowych-USA.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Drony latające i pociski manewrujące stają się coraz większym zagrożeniem na froncie i dlatego Niemcy postanowiły wzmocnić swój potencjał obrony przed nimi. Wyłożą na to sporo kasy. Niemcy inwestują 1,2 miliarda euro na wzmocnienie przeciwlotniczych możliwości Niemieckie siły zbrojne mają wzmocnić swoje zdolności obrony przeciwlotniczej krótkiego zasięgu dzięki nowemu znacznemu kontraktowi o wartości 1,2 miliarda [&#8230;]</p>

## Pierwszy na świecie komputer kwantowy odporny na błędy
 - [https://www.chip.pl/2024/02/komputer-kwantowy-odporny-na-bledy-quera](https://www.chip.pl/2024/02/komputer-kwantowy-odporny-na-bledy-quera)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T21:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1313" src="https://konto.chip.pl/wp-content/uploads/2023/12/kwant.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/kwant.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Komputery kwantowe mają doprowadzić do technologicznego skoku w przyszłość, choć dotychczas zmagały się z poważnym problemem w postaci podatności na błędy. Nadchodząca maszyna ma to zmienić, a jej twórcy wyjaśniają, w jaki sposób chcą to osiągnąć.  Przełomowa maszyna, jak zapowiadają inżynierowie związani z QuEra, ma mieć pojemność opiewającą na nawet 10 000 kubitów. Jeśli zaś [&#8230;]</p>

## Najszybsza transmisja danych na świecie! Tak działa technologia, o której było zaskakująco cicho
 - [https://www.chip.pl/2024/02/najszybsza-transmisja-danych-rekord-w-skali-swiata](https://www.chip.pl/2024/02/najszybsza-transmisja-danych-rekord-w-skali-swiata)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T20:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="867" src="https://konto.chip.pl/wp-content/uploads/2022/11/dane.jpg" style="margin-bottom: 10px;" width="1300" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/dane.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Fotonika to jedna z gałęzi nauki łącząca w sobie optykę, elektronikę i informatykę. Wykorzystując zapewniane przez nią możliwości naukowcy ze Stanów Zjednoczonych i Japonii ustanowili niebywały rekord dotyczące szybkości transmisji danych. Za badaniami w tej sprawie stoją przedstawiciele Uniwersytetu w Osace oraz IMRA America. Poszukiwali oni sposobów na wykorzystanie kanałów bezprzewodowych pozwalających na osiąganie bardzo [&#8230;]</p>

## Rewolucyjny kryształ czasu. Przełom, na który czekaliśmy od lat
 - [https://www.chip.pl/2024/02/dlugotrwaly-krysztal-czasu](https://www.chip.pl/2024/02/dlugotrwaly-krysztal-czasu)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T18:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2024/02/krysztal.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/krysztal.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Kryształ czasu to teoretyczna struktura powtarzalna w czasie i przestrzeni. Inaczej mówiąc, jest to rozszerzenie pojęcia kryształu na wymiar czasowy. Struktura taka rotuje w taki sposób, aby co pełen obrót znajdowała się dokładnie w tym samym stanie w przestrzeni. Twór wymyślony niejako przez noblistę Franka Wilczka na początku XXI wieku był już obserwowany kilkukrotnie. Teraz [&#8230;]</p>

## Irytujące powiadomienia w przeglądarce Chrome? Google ułatwi ich wyłączenie
 - [https://www.chip.pl/2024/02/przegladarka-chrome-android-powiadomienia-z-witryn](https://www.chip.pl/2024/02/przegladarka-chrome-android-powiadomienia-z-witryn)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T17:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="854" src="https://konto.chip.pl/wp-content/uploads/2024/02/przegladarka-chrome.jpg" style="margin-bottom: 10px;" width="1280" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/przegladarka-chrome.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Korzystając z przeglądarki Chrome, często jesteśmy wręcz nagabywani przez witryny, wyświetlające prośby o zezwolenie na publikację powiadomień na naszym urządzeniu. To denerwująca funkcja, która potrafi być jeszcze gorsza, gdy przypadkowo (lub nie) wyrazimy zgodę na te powiadomienia, wówczas jesteśmy nimi zasypywani. Google pracuje teraz nad sposobem ich łatwego usunięcia. Przeglądarka Chrome pozwoli na łatwiejsze wyłączenie [&#8230;]</p>

## WhatsApp jeszcze bezpieczniejszy. Komunikator będzie strzeżony jak nigdy wcześniej
 - [https://www.chip.pl/2024/02/whatsapp-ios-klucze-dostepu](https://www.chip.pl/2024/02/whatsapp-ios-klucze-dostepu)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T17:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2021/11/cyberbezpieczenstwo-rola-bankow.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/11/cyberbezpieczenstwo-rola-bankow.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zabezpieczeń nigdy za wiele, zwłaszcza w aplikacjach, w których znaleźć można ogrom wrażliwych informacji na nasz temat. Do takich z pewnością zalicza się WhatsApp, dlatego Meta pracuje właśnie nad nowym sposobem logowania, lepiej chroniącym przed niepowołanym dostępem do aplikacji. Komunikator WhatsApp wciąż jest najpopularniejszą aplikacją tego typu na świecie. Meta stara się dostarczać użytkownikom regularnych [&#8230;]</p>

## iPhone 15 Pro miał być hitem. Klienci jednak sądzą inaczej
 - [https://www.chip.pl/2024/02/iphone-15-pro-mial-byc-hitem-klienci-jednak-sadza-inaczej](https://www.chip.pl/2024/02/iphone-15-pro-mial-byc-hitem-klienci-jednak-sadza-inaczej)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T16:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1600" src="https://konto.chip.pl/wp-content/uploads/2023/09/iphone-15-pro-max-wrazenia-opinie-cena-11.jpg" style="margin-bottom: 10px;" width="2400" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/09/iphone-15-pro-max-wrazenia-opinie-cena-11.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zaprezentowana jesienią ubiegłego roku seria iPhone 15 doczekała się wielu znaczących ulepszeń, zwłaszcza jeśli chodzi o modele Pro. Chociaż Apple pokładał ogromne nadzieje z tą serią, spodziewając się podbić w ten sposób serca klientów, nie każdy model podobał się tak samo. Tytanowy iPhone 15 Pro nie zdobył uznania fanów Apple’a. Dlaczego? Kiedy dostajemy jakieś dane [&#8230;]</p>

## Kumulacja gigabajtów w Plus na Kartę. Nawet 5200 GB do wykorzystania
 - [https://www.chip.pl/2024/02/kumulacja-gigabajtow-w-plus-na-karte-nawet-5200-gb-do-wykorzystania](https://www.chip.pl/2024/02/kumulacja-gigabajtow-w-plus-na-karte-nawet-5200-gb-do-wykorzystania)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T16:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2021/12/Plus-logo-nowe.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/12/Plus-logo-nowe.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Gigabajtów internetu nigdy za wiele. Z takiego założenia najwyraźniej wychodzi Plus na Kartę, wprowadzając dla swoich klientów nowe, atrakcyjne opcje. Tym razem użytkownicy mogą cieszyć się imponującą liczbą nawet 5200 GB do wykorzystania, a to nie koniec świetnych wiadomości. Plus na Kartę cały czas się zmienia, przynosząc użytkownikom nowe, atrakcyjne korzyści Obecnie korzystamy z internetu [&#8230;]</p>

## To nie koncert Daft Punk, tylko roboty wkraczają do fabryki BMW
 - [https://www.chip.pl/2024/02/roboty-figure-fabryka-bmw](https://www.chip.pl/2024/02/roboty-figure-fabryka-bmw)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T15:29:26+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1432" src="https://konto.chip.pl/wp-content/uploads/2024/01/robot-figure1.png" style="margin-bottom: 10px;" width="2240" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/01/robot-figure1.png" style="display: block; margin: 1em auto;" /></p>
<p>Firma Figure podpisała pierwszą komercyjną umowę i wysyła swoje humanoidalne roboty ogólnego przeznaczenia do pracy w fabryce BMW w Karolinie Południowej. Co dokładnie będą tam robiły? Czy zabiorą pracę ludziom? Nieco ponad tydzień temu firma Figure ogłosiła kolejny kamień milowy, publikując wideo przedstawiające robota Figure 01 autonomicznie przygotowującego kawę w odpowiedzi na polecenie słowne. Brett [&#8230;]</p>

## Mocarny materiał wytrzyma każdą siłę. USA mają teraz potężnego asa w rękawie
 - [https://www.chip.pl/2024/02/material-bombardowany-czastkami-z-predkoscia-naddzwiekowa](https://www.chip.pl/2024/02/material-bombardowany-czastkami-z-predkoscia-naddzwiekowa)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T14:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="852" src="https://konto.chip.pl/wp-content/uploads/2024/02/space-shuttle-774_1280.jpg" style="margin-bottom: 10px;" width="1280" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/space-shuttle-774_1280.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Amerykańscy naukowcy z Massachusetts Institute of Technology prowadzili badania nad ultra wytrzymałym metamateriałem, który będzie można zastosować w przemyśle lotniczym, kosmicznym lub w wojsku. Jedną z metod badawczych, jakie zastosowali, było „bombardowanie” materiału cząstkami z prędkością naddźwiękową. Jakie rezultaty to przyniosło? Na początek zastanówmy się nad tym, czym powinien się charakteryzować materiał o niezwykłej sile [&#8230;]</p>

## T-Mobile otwiera sieć 5G Bardziej na klientów i zdejmuje limity danych
 - [https://www.chip.pl/2024/02/t-mobile-nielimitowane-5g-bardziej-promocja](https://www.chip.pl/2024/02/t-mobile-nielimitowane-5g-bardziej-promocja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T12:19:04+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/10/t-mobile-5g-testing-lab-krakow-03.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/10/t-mobile-5g-testing-lab-krakow-03.jpg" style="display: block; margin: 1em auto;" /></p>
<p>T-Mobile szybko rozbudowuje swoją sieć 5G Bardziej i w krótkim czasie chce objąć zasięgiem ponad 1/4 populacji kraju. Aby pokazać użytkownikom możliwości nowej sieci operator udostępnia darmowe, testowe oferty i zdejmuje limity danych. Nowe 5G na 2 000 nadajników Nowa sieć 5G, prawdziwe 5G lub jak nazywa to T-Mobile 5G Bardziej, działa obecnie na prawie [&#8230;]</p>

## Po dwóch latach wróciłem do Night City. Cyberpunk 2077 w końcu dorównał do poziomu oczekiwań
 - [https://www.chip.pl/2024/02/cyberpunk-2077-czy-warto-opinia-recenzja-night-city](https://www.chip.pl/2024/02/cyberpunk-2077-czy-warto-opinia-recenzja-night-city)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T12:16:06+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/12/samsung-odyssey-neo-g9-08.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/12/samsung-odyssey-neo-g9-08.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Cyberpunk 2077 był jedną z najbardziej wyczekiwanych gier w historii i jednocześnie jednym z historycznych rozczarowań. Nie wiem, jakim cudem gra przetrwała kryzys, ale jej twórcy doprowadzili ją do poziomu, w którym w końcu możemy mówić o grze 10/10. No może 9.9/10. Przedpremierowe recenzje przebiły balonik Cyberpunka 2077 Takiego wyczekiwania na grę, jak w przypadku [&#8230;]</p>

## Wygląda jak wielki pocisk artyleryjski ze skrzydłami. Łowca zaskakuje możliwościami
 - [https://www.chip.pl/2024/02/odrzutowy-dron-pocisk-huntress-ii-waveaerospace](https://www.chip.pl/2024/02/odrzutowy-dron-pocisk-huntress-ii-waveaerospace)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T11:01:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/03/Armia-USA-pocisk-artyleryjski-ST-PGAR-2.jpg" style="margin-bottom: 10px;" width="1622" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/03/Armia-USA-pocisk-artyleryjski-ST-PGAR-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Drony latające są już zbyt dużym rynkiem, żeby rozwijały się w ewolucyjnym tempie. To, co obserwujemy od kilku lat, to wręcz dronowe rewolucje, czego najnowszym przykładem jest szalenie szybki Huntress II. Huntress II od WaveAerospace wygląda jak wojskowy dron, ale każdy będzie mógł go kupić Firma WaveAerospace z Connecticut ogłosiła niedawno przełom w technologii bezzałogowych [&#8230;]</p>

## OneDrive po liftingu. Ma dzięki niemu nie tylko lepiej wyglądać, ale również działać szybciej
 - [https://www.chip.pl/2024/02/microsoft-onedrive-aktualizacja-nowy-wyglad](https://www.chip.pl/2024/02/microsoft-onedrive-aktualizacja-nowy-wyglad)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T11:00:00+00:00

<img alt="OneDrive" class="attachment-full size-full wp-post-image" height="551" src="https://konto.chip.pl/wp-content/uploads/2024/02/OneDrive.jpg" style="margin-bottom: 10px;" width="991" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/OneDrive.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Microsoft postanowił wprowadzić do swojego sieciowego dysku szereg zmian, które mają wpływ zarówno na jego estetykę, jak i komfort użytkowania. Jeśli używasz OneDrive, z pewnością znajdziesz wiele powodów do zadowolenia. A co konkretnie zostało zmienione? Dysk Microsoftu to główny rywal dla dysku Google&#8217;a w chmurowym przechowywaniu danych. I jak to przy rywalizacji bywa, obie strony [&#8230;]</p>

## CHIMERA zaryczała i nie wzięła jeńców. Na poligonie USA zrobiło się gorąco
 - [https://www.chip.pl/2024/02/usa-drony-chimera-bron-mikrofalowa](https://www.chip.pl/2024/02/usa-drony-chimera-bron-mikrofalowa)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T10:01:00+00:00

<img alt="Wystrzeliwanie drona ALPAGU" class="attachment-full size-full wp-post-image" height="1432" src="https://konto.chip.pl/wp-content/uploads/2023/11/Nagranie-dron-ALPAGU.jpg" style="margin-bottom: 10px;" width="2559" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/11/Nagranie-dron-ALPAGU.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Firma Raytheon miała niedawno okazję do zaprezentowania możliwości swojego nowego systemu uzbrojenia CHIMERA, którym agencja badawcza lotnictwa USA szczególnie się zainteresowała, co potwierdziły aż trzytygodniowe testy. System mikrofalowy CHIMERA ma być postrachem dronów. Liczy na to lotnictwo USA Firma RTX pochwaliła się, jak to może przyczynić się ponownie do rozwinięcia możliwości lotnictwa USA, co tym [&#8230;]</p>

## AMD potwierdza &#8211; laptopowe procesory Strix Point w tym roku.
 - [https://www.chip.pl/2024/02/amd-strix-point-zen-5-premiera-mozliwosci](https://www.chip.pl/2024/02/amd-strix-point-zen-5-premiera-mozliwosci)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T09:00:00+00:00

<img alt="Strix Point" class="attachment-full size-full wp-post-image" height="766" src="https://konto.chip.pl/wp-content/uploads/2024/02/AMD-Ryzen.webp" style="margin-bottom: 10px;" width="1024" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/AMD-Ryzen.webp" style="display: block; margin: 1em auto;" /></p>
<p>Dr. Lisa Su, szefowa AMD, potwierdziła premierę wykonanych w architekturze Zen 5 chipów Strix Point podczas spotkania podsumowującego wyniki finansowe za ostatni kwartał 2023 roku. Będzie to znaczny skok jakościowy i wydajnościowy w stosunku do poprzedników. AMD ma powody do zadowolenia. Ostatnie trzy miesiące 2023 roku przyniosły jej dochód w wysokości 667 mln dolarów, co [&#8230;]</p>

## Promieniowanie gamma w rozdzielczości, jakiej jeszcze nie było. Co uwiecznili astronomowie?
 - [https://www.chip.pl/2024/02/promieniowanie-gamma-rekord-pulsar-vela](https://www.chip.pl/2024/02/promieniowanie-gamma-rekord-pulsar-vela)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T08:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1200" src="https://konto.chip.pl/wp-content/uploads/2024/01/balon.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/01/balon.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Promieniowanie gamma jest wysokoenergetyczną formą promieniowania elektromagnetycznego. Dzięki obrazowaniu w wysokiej rozdzielczości naukowcy byli w stanie pobić rekord, który ustanowili w czasie obserwacji jednego z pulsarów. Takim mianem określa się bardzo szybko obracające się gwiazdy neutronowe. Są to obiekty cechujące się silnym magnetyzmem i emitujące wiązki promieniowania elektromagnetycznego. Śledząc aktywność pulsara znanego jako Vela, naukowcy [&#8230;]</p>

## Kanały tematyczne nowej generacji – czyli kablówka 4.0
 - [https://www.chip.pl/2024/02/nowe-kanaly-tvn-lista-player](https://www.chip.pl/2024/02/nowe-kanaly-tvn-lista-player)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T07:18:07+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1536" src="https://konto.chip.pl/wp-content/uploads/2024/01/Hisense-65UXKG-pilot.jpg" style="margin-bottom: 10px;" width="2048" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/01/Hisense-65UXKG-pilot.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Pamiętacie zachwyty w „Kochaj albo rzuć” nad liczbą kanałów w amerykańskiej kablówce? A może licytację operatorów jak Cyfra+, Cyfrowy Polsat, Toya, Multimedia, UPC na liczbę kanałów tematycznych? W ostatnich dniach Player.pl dorzucił 15 nowych kanałów. Tak 15 nowych kanałów TVN. W tym kanał „TVN rajska miłość” i „TVN życie jak w bajce” – oto nowa [&#8230;]</p>

## Rosja ma nowy okręt podwodny. Rozpoczął nową erę i&#8230; przeraził historią
 - [https://www.chip.pl/2024/02/rosja-nowy-okret-podwodny-kronstadt](https://www.chip.pl/2024/02/rosja-nowy-okret-podwodny-kronstadt)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2024-02-01T04:36:10+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1440" src="https://konto.chip.pl/wp-content/uploads/2024/02/Okret-podwodny-typu-Lada-Rosja-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2024/02/Okret-podwodny-typu-Lada-Rosja-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jednego nie można odmówić Rosjanom &#8211; ich flota okrętów jest wręcz przeogromna, choć jednocześnie wiele z wykorzystywanych okrętów jest zwyczajnie przestarzałych i żadne modernizacje tego nie zmienią. Teraz jednak Rosja wkroczyła w nową erę wraz z wprowadzeniem na służbę pierwszego okrętu podwodnego konkretnego typu. Pierwszy okręt podwodny projektu 677 już na służbie. Jak wiele zmienia [&#8230;]</p>

