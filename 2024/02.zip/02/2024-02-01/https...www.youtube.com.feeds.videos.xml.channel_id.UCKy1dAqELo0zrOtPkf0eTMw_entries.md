# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Dragon's Dogma 2: Everything We Know After 10 Hours of Play - IGN First
 - [https://www.youtube.com/watch?v=WESHN48K1P8](https://www.youtube.com/watch?v=WESHN48K1P8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T22:00:29+00:00

To wrap up our IGN First coverage of Dragon's Dogma 2, Mitchell and Casey have an unscripted conversation going over everything they got to see and play during those 10 hours of playtime.

#IGN #Gaming #DragonsDogma2

## Jujutsu Kaisen Cursed Clash - Official Costumes Trailer
 - [https://www.youtube.com/watch?v=SC4-eRTmmVQ](https://www.youtube.com/watch?v=SC4-eRTmmVQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T21:00:13+00:00

Jujutsu Kaisen Cursed Clash is a 2v2 action fighting game developed by Byking Inc. Take a look at the latest trailer to see all of the different cosmetics players can attain for a plethora of different fighters across the game. Jujutsu Kaisen Cursed Clash is launching on February 2 for PlayStation 4, PlayStation 5, Xbox One, Xbox Series S|X, Nintendo Switch, and PC.

## Children of the Sun - Official Reveal Trailer
 - [https://www.youtube.com/watch?v=NX3b1V7De5Y](https://www.youtube.com/watch?v=NX3b1V7De5Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T20:30:04+00:00

Children of the Sun is a tactical third-person puzzle shooter developed by René Rother. Players will embark on a deadly road trip straight to vengeance as a young girl seeks payback from a Cult that ruined her whole life. Beat level after level by taking out multiple enemies with the use of a single bullet. Re-aim said bullet upon impact, take out armor, and guide the bullet around obstructions with style and speed. Children of the Sun is launching on PC at a later date.

#ign

## Palworld - How to Breed Anubis Early
 - [https://www.youtube.com/watch?v=1VXJyKcnEAQ](https://www.youtube.com/watch?v=1VXJyKcnEAQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T20:00:00+00:00

Wanna learn how to get Anubis, one of Palworld's strongest Pals, pretty dang early? We've got the tips on how to breed Anubis right here!

Creating an Anubis egg requires particular pals and conditions to pull off. We'll show you the locations, farming methods, and ways to speed up the process so you can get Anubis way earlier than you normally would. We hope you enjoy this Palworld Anubis breeding guide!

#IGN #Gaming #Palworld

## Banishers: Ghosts of New Eden - Official Gameplay Breakdown Trailer
 - [https://www.youtube.com/watch?v=2_v89N3el5c](https://www.youtube.com/watch?v=2_v89N3el5c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T19:00:03+00:00

Banishers: Ghosts of New Eden is a third-person action-adventure game by DON'T NOD. Players will embody the roles of Red and Antea as they protect the public from spirits that remain as opposed to passing on. Take a look at the latest trailer to get a full combat breakdown of the mechanics behind Red's gun-driven gameplay style and Antea's ethereal attacks and abilities. Banishers: Ghosts of New Eden is launching on February 13 for PlayStation 5, Xbox Series S|X, and PC.

#IGN #Gaming #Banishers

## Suicide Squad: Kill the Justice League Ending Cutscene (Spoilers!)
 - [https://www.youtube.com/watch?v=kR7hymDLbfE](https://www.youtube.com/watch?v=kR7hymDLbfE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T18:35:35+00:00

SPOILERS! This is the Suicide Squad: Kill the Justice League ending from the launch of the game. While there is planned seasonal content for Suicide Squad, this is how the story concludes from the base game.

#IGN #Gaming

## Resident Evil 4 Gold Edition - Official Launch Trailer
 - [https://www.youtube.com/watch?v=-avtOIRmhQs](https://www.youtube.com/watch?v=-avtOIRmhQs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T18:00:00+00:00

Check out the trailer for Resident Evil 4: Gold Edition to see what's available in this edition of the survival horror game, including the base game, the Separate Ways story DLC, and an Extra DLC pack. The Mercenaries mode is also available as a free DLC. Resident Evil 4: Gold Edition will be available on PlayStation 5, PlayStation 4, Xbox Series X/S, and Steam on February 9, 2024.

## Citadelum - Official Reveal Trailer
 - [https://www.youtube.com/watch?v=P1p8M-S0xRo](https://www.youtube.com/watch?v=P1p8M-S0xRo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T17:47:27+00:00

Watch the trailer for Citadelum to see gameplay and some of the features of the upcoming strategy/city-building game, including the auto-battle system, interactions with and between gods, and more. Citadelum is set in Ancient Rome, with a mythical twist. It will be available on PC in 2024.

#GameTrailers #Gaming #Citadelum

## Persona 3 Reload - Official Battle Strategy Trailer
 - [https://www.youtube.com/watch?v=_YkpEgLGP2g](https://www.youtube.com/watch?v=_YkpEgLGP2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T17:41:08+00:00

Get a deeper look at combat and strategies you can use in battle, like exploiting enemies' weaknesses and more, in this latest trailer for the upcoming RPG remake, Persona 3 Reload. Persona 3 Reload will be available on Xbox Series X/S, Xbox One, Windows, Xbox Game Pass, Steam, PlayStation 5, and PlayStation 4 on February 2, 2024.

#Persona #Persona3 #Gaming

## Jujutsu Kaisen Cursed Clash - Official Launch Trailer
 - [https://www.youtube.com/watch?v=pivoHJX0K2U](https://www.youtube.com/watch?v=pivoHJX0K2U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T17:00:43+00:00

Jujutsu Kaisen Cursed Clash is a 2v2 fighting game developed by Byking Inc. Players will fight to master the Jujutsu of their favorite Sorcerers and Cursed Spirits. Select a main fighter and partner to implement unique combinations to complement a desired play style. Strengthen cursed techniques through exhilarating battles, defeat opponents, and harness the power of the Jujutsu. Jujutsu Kaisen Cursed Clash is launching on February 2 for PlayStation 4, PlayStation 5, Xbox One, Xbox Series S|X, Nintendo Switch, and PC.

#IGN #Gaming #JujutsuKaisenCursedClash

## Silent Hill 2: Original VS. Remake Graphics Comparison
 - [https://www.youtube.com/watch?v=3mVLduRA03Y](https://www.youtube.com/watch?v=3mVLduRA03Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T16:46:16+00:00

Check out this graphics comparison between Silent Hill 2, developed by Team Silent back in 2001 for the PS2, and the Silent Hill 2 Remake, by Bloober Team, in development for the PlayStation 5 and PC.

How do you think the SH2 Remake stacks up compared to the original? Let us know with your IGN comments below, SH2 Remake VS Original, which one do you prefer?

#SilentHill2 #SilentHill2Remake #IGN

## Children of the Sun Is Like Sniper Elite Meets Superhot
 - [https://www.youtube.com/watch?v=z1j5yXjnYXM](https://www.youtube.com/watch?v=z1j5yXjnYXM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T16:00:42+00:00

We take our first test drive with Children of the Sun, a just-announced shooter/puzzle game that blends Sniper Elite and Superhot into one revenge-fueled package. Previewed on PC by Jeremy Smith.

## WWE 2K24: Full Ambulance Match Gameplay
 - [https://www.youtube.com/watch?v=wdd7izNIyoo](https://www.youtube.com/watch?v=wdd7izNIyoo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T15:00:46+00:00

Check out a full WWE 2K24 Ambulance Match, showcasing the brand-new mode coming to the new WWE game. We face WWE 2K24 Kevin Owens against WWE 2K24 The Undertaker in what turns out to be an all-time classic.

WWE 2K24 will be released on PlayStation 5 (PS5), Xbox Series X/S, PlayStation 4 (PS4), Xbox One, and PC via Steam on March 8, 2024. 

#WWE #Wrestling #Gaming

## WWE 2K24: The First Preview
 - [https://www.youtube.com/watch?v=KuNfCVX1Aw0](https://www.youtube.com/watch?v=KuNfCVX1Aw0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T15:00:22+00:00

Watch our IGN WWE 2K24 preview! From what I’ve played so far, WWE 2K24 has added enough exciting gameplay-focused innovations that it's definitely worth your attention. Let me talk to ya…

Check out the first hands-on preview for WWE 2K24 where we got to sample the new ambulance match, the updated Backstage Brawl and a bunch of new WWE 2K24 gameplay additions.

WWE 2K24 will be released on PlayStation 5 (PS5), Xbox Series X/S, PlayStation 4 (PS4), Xbox One, and PC via Steam on March 8, 2024. 

#WWE #Wrestling #Gaming

## WWE 2K24: Rhea Ripley Full Ring Entrance
 - [https://www.youtube.com/watch?v=KYc7pOhwn1E](https://www.youtube.com/watch?v=KYc7pOhwn1E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T15:00:14+00:00

Check out the WWE 2K24 Rhea Ripley full ring entrance! This video puts the spotlight on WWE Women's World Champion Rhea Ripley in WWE 2K24. Featuring The Eradicator carrying her women's world championship to the ring in the Smackdown arena.

WWE 2K24 will be released on PlayStation 5 (PS5), Xbox Series X/S, PlayStation 4 (PS4), Xbox One, and PC via Steam on March 8, 2024. 

#WWE #Wrestling #Gaming

## The Thaumaturge - Official Quest Trailer
 - [https://www.youtube.com/watch?v=3aD3sKYxGKE](https://www.youtube.com/watch?v=3aD3sKYxGKE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T15:00:07+00:00

Get a deep dive into gameplay, turn-based combat, skills, how your otherworldly beings called salutors can help in battle, and more in this latest trailer for The Thaumaturge, an upcoming isometric RPG from 11 bit studios and Fool’s Theory. The trailer showcases a quest where the protagonist Wiktor Szulski takes on the Russian Okhrana, explores the streets of 1905 Warsaw and helps a woman flee the country. We also get to see how to level up your thaumaturge skills, how your decisions may impact the story, a peek at public transportation, and more. 

The Thaumaturge will be available on PC on February 20, 2024, followed by PlayStation 5 (PS5) and Xbox Series X/S versions at a later date.

#TheThaumaturge #Gaming #IGN

## Street Fighter 6 - Official 'Ed Arrives!' Fighting Pass Trailer
 - [https://www.youtube.com/watch?v=XZFQ9iGyrdE](https://www.youtube.com/watch?v=XZFQ9iGyrdE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T14:44:49+00:00

Watch the latest trailer for Street Fighter 6 to see what to expect with the "Ed Arrives!" Fighting Pass, featuring cosmetic items themed off of the psycho-powered boxer, Captain Commando to play in the game center, and Fighter Coins. Ed is coming to Street Fighter 6 in February 2024.

#IGN #Gaming #StreetFighter6 #Ed

## TOP 5 flying Pals to get in Palworld! #palworld #pals #fly #flying
 - [https://www.youtube.com/watch?v=7cAoXcSAspc](https://www.youtube.com/watch?v=7cAoXcSAspc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T03:30:42+00:00



## Everything Announced at PlayStation State of Play - Jan 2024
 - [https://www.youtube.com/watch?v=phH269MzRqs](https://www.youtube.com/watch?v=phH269MzRqs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T02:10:28+00:00

Today, PlayStation fans received some incredibly exciting details on some new upcoming games during the January 2024 State of Play. This show lasted around 40 minutes, and covered updates and news for Death Stranding 2: On the Beach, Dragon's Dogma 2, Silent Hill 2, Helldivers 2, Sonic x Shadow Generations, Until Dawn, Legendary Tales, Rise of the Ronin, Godzilla DLC for Dave The Diver, as well as the announcement of the latest from Kojima Productions, Physint, and more!

If you could not watch the showcase live, well you're in luck, this quick roundup video goes over all of the announcements from the January 2024 PlayStation State of Play.

## The First 26 Minutes of Silent Hill: The Short Message Gameplay
 - [https://www.youtube.com/watch?v=JgSlF6OmgKc](https://www.youtube.com/watch?v=JgSlF6OmgKc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T02:02:22+00:00

Silent Hill: The Short Message features a young woman and tells a story about social media and how it can have devastating effects on the psyche. Created as a Silent Hill experiment by Konami to try different things per the PlayStation blog, they are using it to "Polish our horror game expertise."

## Granblue Fantasy: Relink Review
 - [https://www.youtube.com/watch?v=ur3HD5Qn1u4](https://www.youtube.com/watch?v=ur3HD5Qn1u4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T01:59:54+00:00

Granblue Fantasy: Relink reviewed by George Yang on PlayStation 5, also available on PlayStation 4 and PC.

"Granblue Fantasy: Relink bucks the RPG genre’s usual trend of long and slow-paced stories, but the relative brevity of its campaign doesn’t compromise on the quality of its storytelling. Its mobile game origins don’t always translate over well, feeling a little thin in some aspects, but questing with friends in multiplayer is very exciting, even if the lack of crossplay is disappointing. However, Relink’s fun action combat and interesting cast of characters are compelling enough to keep you playing long after you beat the final boss."

## PlayStation Plus Games for February 2024 Announced - IGN Daily Fix
 - [https://www.youtube.com/watch?v=gYS6jjCYrvQ](https://www.youtube.com/watch?v=gYS6jjCYrvQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T00:30:30+00:00

In today's Daily Fix:
A new month means a new crop of games coming to PlayStation Plus. For February, there's the multiplayer-centric Foamstars, the soulslike RPG Steelrising, and the roller derby-inspired Rollerdrome. There's also some fun cosmetics for Fall Guys. In other news, a new update is out for Alan Wake 2, and it comes with an option to make the game less scary for all you babies out there. And finally, Warner Bros. Games is trying to make good on the early access promise for Suicide Squad: Kill the Justice League's Deluxe Edition. The game was launched, and then pulled after bugs were discovered that negatively affected the experience. Owners of the deluxe edition will be getting some in-game currency, so that's something.

#IGN #Gaming #PS5

## “Death Stranding 2 On The Beach” comes out in 2025. This is only 40 secs of a crazy 10-min trailer!
 - [https://www.youtube.com/watch?v=V361MEg7jgQ](https://www.youtube.com/watch?v=V361MEg7jgQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T00:12:59+00:00



## X-Men: First Class Director Says Deadpool 3 Might ‘Save the MCU’ - IGN The Fix: Entertainment
 - [https://www.youtube.com/watch?v=tplHogM-JaI](https://www.youtube.com/watch?v=tplHogM-JaI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T00:02:03+00:00

X-Men: First Class director Matthew Vaughn thinks Deadpool and Wolverine can save the MCU. Speaking on BroBible’s Post-Credit podcast, he said, ““The few snippets that I know about Deadpool vs. Wolverine — or Wolverine vs. Deadpool, I’m sure that argument between Ryan and Hugh is happening as we speak — are unbelievable. That’s going to be the jolt... the Marvel universe is about to have a jolt of them and it’s going to bring that body back to life... I think Ryan Reynolds and Hugh Jackman are about to save the whole Marvel universe.” With #Deadpool3 the only Marvel Cinematic Universe set to release this year on July 26th, here’s hoping it’ll be the redemption Marvel fans have been looking forward to after an abysmal 2023 full of MCU-related projects that were just shy of hitting the mark at the box office. In other news, Kurt Russell spoke with GQ about why he didn’t take on the role of Snake in Kojima’s Metal Gear Solid series - a role he was apparently offered for MGS3: Sn

## Ghostbusters: Rise of the Ghost Lord - Official Slimer Hunt Trailer (ft. Dan Aykroyd)
 - [https://www.youtube.com/watch?v=VWrbPJxoAz0](https://www.youtube.com/watch?v=VWrbPJxoAz0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T00:00:21+00:00

Ghostbusters: Rise of the Ghost Lord is a VR action game developed by nDreams. The free Slimer Hunt update has arrived to the game bringing the return of Dan Aykroyd as he reprises his role as one of the original Ghostbusters Ray Stantz in Slimer Hunt. Slimer Hunt tasks players with dispatching the one and only Slimer as he wreaks havoc on the streets of San Francisco in a brand-new mission. The update is also fitted with the flight suits of the original Ghostbusters as an in-game cosmetic. Slimer Hunt in Ghostbusters: Rise of the Ghost Lord is available now for PlayStation VR2, Meta Quest 2, and Meta Quest 3.

#ign #ghostbusters

## Palworld: How to Find Resources | Pal Fluid, High Quality Pal Oil, Wheat Seeds
 - [https://www.youtube.com/watch?v=7A06AklbBpg](https://www.youtube.com/watch?v=7A06AklbBpg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2024-02-01T00:00:03+00:00

Palworld’s a survival game that keeps you invested thanks to a good pace of progression, but it’s common for that progression to come to a screeching halt when you’re confronted with a resource you’ve never seen before and you have no idea how to get. If you’re trying to figure out how to build certain structures to level up your base, or you want to put together your first firearm, this is the video for you.

#IGN #Gaming #Palworld

