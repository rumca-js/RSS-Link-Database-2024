# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Wielka płyta wraca do łask. Mieszkania znikają błyskawicznie
 - [https://www.money.pl/banki/wielka-plyta-wraca-do-lask-mieszkania-znikaja-blyskawicznie-6991133000973280a.html](https://www.money.pl/banki/wielka-plyta-wraca-do-lask-mieszkania-znikaja-blyskawicznie-6991133000973280a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T20:58:43+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2e66a108-8946-44a7-8eaa-ea0d61eb5016" width="308" /> Oferta kupna mieszkań w blokach z wielkiej płyty w ostatnim czasie znacząco się skurczyła. Zarazem ceny tych lokali wzrosły nawet o 50 proc. w ciągu roku. Skąd takie zainteresowanie? Eksperci wskazują na efekt działania rządowego programu "Bezpieczny kredyt 2 proc.".

## Jest dostawca pływającego terminala LNG. "Kamień milowy"
 - [https://www.money.pl/gielda/jest-dostawca-plywajacego-terminala-lng-kamien-milowy-6991115732925376a.html](https://www.money.pl/gielda/jest-dostawca-plywajacego-terminala-lng-kamien-milowy-6991115732925376a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T19:33:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6ba39395-159f-49b9-843c-a9488644ab61" width="308" /> Gaz-System dokonał wyboru najkorzystniejszej oferty na dostarczenie i obsługę jednostki FSRU, która ma pełnić funkcję terminalu regazyfikacyjnego LNG w Zatoce Gdańskiej - podała spółka w czwartkowym komunikacie.

## Banki na wojnie z gotówką. Podnoszą ceny
 - [https://www.money.pl/banki/banki-na-wojnie-z-gotowka-podnosza-ceny-6990764247960512a.html](https://www.money.pl/banki/banki-na-wojnie-z-gotowka-podnosza-ceny-6990764247960512a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T19:25:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f7c56e25-4098-4f66-be09-d87794979f90" width="308" /> W tym roku już trzy banki zdecydowały się zmienić cenniki: Credit Agricole, BNP Paribas i mBank, który zrobił rynkowy wyłom i każe klientom płacić za wypłaty z bankomatów BLIK-iem. Podwyżki tłumaczą rosnącymi kosztami. Według ekspertów sedno problemu tkwi w kosztownej gotówce.

## Ustawa budżetowa opublikowana w Dzienniku Ustaw. To jednak nie koniec sporu
 - [https://www.money.pl/pieniadze/ustawa-budzetowa-opublikowana-w-dzienniku-ustaw-to-jednak-nie-koniec-sporu-6991102102219744a.html](https://www.money.pl/pieniadze/ustawa-budzetowa-opublikowana-w-dzienniku-ustaw-to-jednak-nie-koniec-sporu-6991102102219744a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T18:31:14+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3c084837-3b8f-4c2a-9c1b-340da372cd29" width="308" /> W czwartek ustawa budżetowa została opublikowana w Dzienniku Ustaw i tym samym wchodzi w życie z mocą wsteczną od 1 stycznia. To jednak nie kończy politycznego sporu. Chociaż prezydent Andrzej Duda ją podpisał, to zdecydował się ją odesłać do Trybunału Konstytucyjnego w trybie następczym.

## Zaiskrzyło na linii Chiny-Ukraina. Sygnał ostrzegawczy
 - [https://www.money.pl/gospodarka/chiny-ostrzegaja-kijow-negatywny-wplyw-na-stosunki-obu-krajow-6991090791918560a.html](https://www.money.pl/gospodarka/chiny-ostrzegaja-kijow-negatywny-wplyw-na-stosunki-obu-krajow-6991090791918560a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T18:25:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/30a4c6c9-0f9b-445e-9663-520c32e28663" width="308" /> Władze Chin ostrzegły Ukrainę, że decyzja o uznaniu kilkunastu chińskich korporacji jako "międzynarodowych sponsorów wojny", może mieć negatywne skutki dla relacji obu krajów. Wśród firm, które trafiły na ukraińską listę, można znaleźć m.in. Xiaomi, CNPC, czy chińskiego producenta aut Geely.

## Jest reakcja PKO BP na wpis Szafarowicza. "Spekulacje nie mieszczą się w kanonie zachowań"
 - [https://www.money.pl/banki/jest-reakcja-pko-bp-na-wpis-szafarowicza-spekulacje-nie-mieszcza-sie-w-kanonie-zachowan-6991074782190528a.html](https://www.money.pl/banki/jest-reakcja-pko-bp-na-wpis-szafarowicza-spekulacje-nie-mieszcza-sie-w-kanonie-zachowan-6991074782190528a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T17:08:35+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fed1e5ee-5592-4ef0-abc5-c04c9dd0c359" width="308" /> We wtorek Oskar Szafarowicz w swoim wpisie zamieścił dane o zysku PKO BP za 2023 r. Wciąż jednak był jeszcze pracownikiem banku, więc powinien zachować wyjątkową ostrożności w tym zakresie. PKO stwierdziło, że "spekulacje nie mieszczą się w kanonie zachowań" przedstawicieli spółki giełdowej.

## Rajd złotego. Siódmy dzień z rzędu
 - [https://www.money.pl/pieniadze/rajd-zlotego-siodmy-dzien-z-rzedu-6991072622857184a.html](https://www.money.pl/pieniadze/rajd-zlotego-siodmy-dzien-z-rzedu-6991072622857184a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T17:06:51+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/76ed443c-837b-4dee-aa8f-4a7d1101845c" width="308" /> Już od tygodnia złoty ma dobrą passę. Polska waluta umacnia się względem euro, którego kurs dochodzi do 4,31 zł. "Nie tylko GPW pokazuje swoją siłę, ale też złoty" - napisali analitycy macroNEXT w serwisie społecznościowym X.

## Realizuje się czarny scenariusz. Rebelianci sparaliżowali międzynarodowy handel
 - [https://www.money.pl/gospodarka/realizuje-sie-czarny-scenariusz-huti-sparalizowali-miedzynarodowy-handel-6991043220384704a.html](https://www.money.pl/gospodarka/realizuje-sie-czarny-scenariusz-huti-sparalizowali-miedzynarodowy-handel-6991043220384704a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T16:24:02+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/498bb5fd-05df-4f45-b1fe-fbba2954835f" width="308" /> Ruch kontenerowców a Morzu Czerwonym zmniejszył się o niemal jedną trzecią (30 proc.) w stosunku do listopada 2023 r. – przekazał szef wydziału Bliskiego Wschodu i Azji Centralnej Międzynarodowego Funduszu Walutowego (MFW), Jihad Azour. Spadek liczby przewozów nasilił się szczególnie na początku stycznia.

## Ogromne wsparcie dla Ukrainy. Premier Tusk reaguje: skończyły się dziwne gierki
 - [https://www.money.pl/gospodarka/zdarzyly-sie-dwie-wazne-rzeczy-premier-tusk-po-szczycie-rady-europejskiej-6991048512052160a.html](https://www.money.pl/gospodarka/zdarzyly-sie-dwie-wazne-rzeczy-premier-tusk-po-szczycie-rady-europejskiej-6991048512052160a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T15:35:57+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0bc0e267-2a68-4dbe-9ba8-afe1ee6b5c7c" width="308" /> Po szczycie Rady Europejskiej premier Donald Tusk nie ukrywał zadowolenia z zatwierdzenia pakietu wsparcia dla Ukrainy. Szczególnie ucieszył go brak blokowania porozumienia przez Viktora Orbána. Odniósł się też do odwołania Daniela Obajtka.

## Mało kto pamięta o tej uldze w PIT. A odliczyć można sporo
 - [https://www.money.pl/podatki/malo-kto-pamieta-o-tej-uldze-w-pit-a-odliczyc-mozna-sporo-6991030574959584a.html](https://www.money.pl/podatki/malo-kto-pamieta-o-tej-uldze-w-pit-a-odliczyc-mozna-sporo-6991030574959584a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T14:57:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5e5a2f2e-c5e3-40d6-b89b-c0bc5e98481d" width="308" /> Od 15 lutego w usłudze Twój e-PIT będą dostępne wstępnie wypełnione deklaracje podatkowe. Wtedy też będzie można rozliczyć się ze skarbówką. Trzeba jednak pamiętać, że w przypadku części ulg musimy sami uzupełnić odpowiednie rubryki. A rozliczyć można m.in. wydatki na meble czy sprzęt AGD.

## Niemcy chcą zderusyfikować swoją rafinerię. Pomóc im w tym mają Polacy
 - [https://www.money.pl/gospodarka/niemcy-chca-zderusyfikowac-swoja-rafinerie-pomoc-im-w-tym-maja-polacy-6991029757750208a.html](https://www.money.pl/gospodarka/niemcy-chca-zderusyfikowac-swoja-rafinerie-pomoc-im-w-tym-maja-polacy-6991029757750208a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T14:10:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6f26dff1-576a-4dd3-b31a-b0752f3cfb23" width="308" /> Niemcy chcą do marca wywłaszczyć rosyjski koncern Rosnieft ze swojej rafinerii PCK Schwedt – podaje businessinsider.de. W grze o udziały Rosjan mają być dwa polskie podmioty – Orlen i Unimot. – To był temat omawiany przez nas, ale nie mogę za wiele powiedzieć – skomentował Daniel Obajtek.

## Kompan Kaczyńskiego zapytany o odwołanie Obajtka. Nie mógł znaleźć odpowiedzi
 - [https://www.money.pl/gospodarka/kompan-kaczynskiego-zapytany-o-odwolanie-obajtka-nie-mogl-znalezc-odpowiedzi-6990998403324896a.html](https://www.money.pl/gospodarka/kompan-kaczynskiego-zapytany-o-odwolanie-obajtka-nie-mogl-znalezc-odpowiedzi-6990998403324896a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T11:57:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e7aeb665-a1a8-489e-8ffb-a8278d8944b5" width="308" /> Dlaczego Daniel Obajtek stracił stanowisko "z rąk" Rady Nadzorczej wybranej  przez poprzedni rząd? Money.pl próbował to ustalić na konferencji prasowej. Wojciech Jasiński, szef Rady Nadzorczej, dawny szef spółki Orlen i polityk PiS, nie znalazł jednak zbyt wielu słów, by wyjaśnić powody decyzji.

## Jest unijne porozumienie w sprawie wsparcia dla Ukrainy
 - [https://www.money.pl/gospodarka/jest-unijne-porozumienie-w-sprawie-wsparcia-dla-ukrainy-6990991869762528a.html](https://www.money.pl/gospodarka/jest-unijne-porozumienie-w-sprawie-wsparcia-dla-ukrainy-6990991869762528a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T11:15:41+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0078094f-6a7a-4aac-9fe8-6a89b8f37188" width="308" /> Mamy porozumienie na szczycie UE. Wszystkich 27 przywódców zgodziło się na pakiet wsparcia dla Ukrainy w wysokości 50 miliardów euro w ramach budżetu UE - poinformował na platformie X szef Rady Europejskiej Charles Michel w czwartek.

## Odwołana z RN Orlenu Janina Goss na pożegnaniu Obajtka
 - [https://www.money.pl/gospodarka/odwolana-z-rn-orlenu-janina-goss-na-pozegnaniu-obajtka-6990985167633344a.html](https://www.money.pl/gospodarka/odwolana-z-rn-orlenu-janina-goss-na-pozegnaniu-obajtka-6990985167633344a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T10:44:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/00d2681e-7f33-43b4-b901-3f9034bdf2a2" width="308" /> Janina Goss, zaufana przyjaciółka prezesa PiS Jarosława Kaczyńskiego, która w grudniu została odwołana z Rady Nadzorczej Orlenu, pojawiła się na czwartkowej konferencji prasowej Daniela Obajtka, na której żegnał się z funkcją prezesa państwowego giganta.

## Daniel Obajtek odwołany. Jest reakcja inwestorów
 - [https://www.money.pl/gielda/daniel-obajtek-odwolany-jest-reakcja-inwestorow-6990982332255200a.html](https://www.money.pl/gielda/daniel-obajtek-odwolany-jest-reakcja-inwestorow-6990982332255200a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T10:39:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1e46795e-875d-4fc4-849e-735ebe2f2386" width="308" /> W czwartek Rada Nadzorcza spółki Orlen odwołała ze stanowiska prezesa. Jak inwestorzy zareagowali na wieść, że Daniel Obajtek nie jest już szefem jednej z największych polskich firm? Notowania jednej z najważniejszych spółek wyraźnie zmieniały się już od rana.

## Nabór wniosków o 800 plus ruszył. Tysiące wniosków na początek
 - [https://www.money.pl/gospodarka/nabor-wnioskow-o-800-plus-ruszyl-tysiace-wnioskow-na-poczatek-6990975100742592a.html](https://www.money.pl/gospodarka/nabor-wnioskow-o-800-plus-ruszyl-tysiace-wnioskow-na-poczatek-6990975100742592a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T10:28:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a037f306-0d42-4b87-bc3a-68606202695b" width="308" /> Nabór wniosków o przyznanie 800 plus na kolejny okres świadczeniowy ruszył bez problemu. W ciągu pierwszej godziny po północy przyjęliśmy prawie 5 tys. wniosków na blisko 8,5 tys. dzieci - przekazał  w czwartek rzecznik ZUS Paweł Żebrowski.

## Sprytny ruch Daniela Obajtka. Może chodzić o ogromną sumę
 - [https://www.money.pl/pieniadze/daniel-obajtek-moze-rozstac-sie-z-orlenem-i-zgarnac-fortune-dymisja-mu-sie-nie-oplaca-6990954607549408a.html](https://www.money.pl/pieniadze/daniel-obajtek-moze-rozstac-sie-z-orlenem-i-zgarnac-fortune-dymisja-mu-sie-nie-oplaca-6990954607549408a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T10:04:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a00e9363-32cd-4e2a-acdd-c9cde82e524e" width="308" /> Rada nadzorcza Orlenu odwołała ze stanowiska prezesa Daniela Obajtka. Ruch ten zapowiedział w czwartek rano sam szef Orlenu. Rozmówcy money.pl sugerują, że powodem decyzji Obajtka są wielkie pieniądze.

## Trzęsienie ziemi w Orlenie. Daniel Obajtek odwołany
 - [https://www.money.pl/gospodarka/trzesienie-ziemi-w-orlenie-daniel-obajtek-odchodzi-6990945533615040a.html](https://www.money.pl/gospodarka/trzesienie-ziemi-w-orlenie-daniel-obajtek-odchodzi-6990945533615040a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T09:52:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3bd7a998-7e43-4820-83bf-136ccdbaa2d0" width="308" /> Daniel Obajtek nie chciał czekać na dymisję dokonaną rękami nowej władzy i oddał się do dyspozycji Rady Nadzorczej Orlenu, która w czwartek 1 lutego zdecydowała o jego dymisji.

## Tusk stawia sprawę jasno. "Jeśli będą chcieli wcześniejszych wyborów, to je dostaną"
 - [https://www.money.pl/gospodarka/tusk-stawia-sprawe-jasno-jesli-beda-chcieli-wczesniejszych-wyborow-to-je-dostana-6990968860097472a.html](https://www.money.pl/gospodarka/tusk-stawia-sprawe-jasno-jesli-beda-chcieli-wczesniejszych-wyborow-to-je-dostana-6990968860097472a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T09:42:05+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4295c354-c1df-4eef-bc73-9b625531ee83" width="308" /> - Jeśli nie da się rządzić, bo prezydent Andrzej Duda będzie przeszkadzał i jeśli będą chcieli wcześniejszych wyborów, to je dostaną. Ale nie sądzę, by w PiS był entuzjazm do idei rozwiązania parlamentu i wcześniejszych wyborów - powiedział w czwartek w Brukseli premier Donald Tusk.

## Pierwsze takie dane. Co mówi o gospodarce PMI przemysłu za styczeń?
 - [https://www.money.pl/gospodarka/pierwsze-takie-dane-co-mowi-o-gospodarce-pmi-przemyslu-za-styczen-6990947891452864a.html](https://www.money.pl/gospodarka/pierwsze-takie-dane-co-mowi-o-gospodarce-pmi-przemyslu-za-styczen-6990947891452864a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T08:22:09+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/58cdf9bb-8ac6-457d-9ecc-ebf7fe2833f4" width="308" /> PMI dla przemysłu wyniósł w styczniu 47,1 pkt - informuje S&amp;P. To wynik gorszy od prognoz. A także gorszy niż przed miesiącem. I kolejny zły sygnał po środowych danych o mizernym wzroście PKB w roku 2023. Na słabe PMI wpłynęły "największe spadki produkcji i nowych zamówień od trzech miesięcy".

## "Sprawa honorowa". Obajtek zdradza, że dziś zapadnie decyzja w jego sprawie
 - [https://www.money.pl/gospodarka/sprawa-honorowa-obajtek-zdradza-ze-dzis-zapadnie-decyzja-w-jego-sprawie-6990933408005056a.html](https://www.money.pl/gospodarka/sprawa-honorowa-obajtek-zdradza-ze-dzis-zapadnie-decyzja-w-jego-sprawie-6990933408005056a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T07:12:54+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cffc5a49-34d4-4481-8fa1-5928a323396f" width="308" /> - Dziś jest Rada Nadzorcza. Oddałem się do dyspozycji Rady. Sądzę, że dziś pewne ustalenia będą w tym zakresie - powiedział na antenie Radia ZET Daniel Obajtek, prezes Orlenu. - To kwestia honoru - dodał.

## "Szybko poszło". Morawiecki chciał uderzyć w Tuska. Dostał rykoszetem
 - [https://www.money.pl/podatki/morawiecki-chcial-uderzyc-w-po-rykoszetem-trafil-w-byly-rzad-pis-6990928519551968a.html](https://www.money.pl/podatki/morawiecki-chcial-uderzyc-w-po-rykoszetem-trafil-w-byly-rzad-pis-6990928519551968a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T07:01:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7913f997-5d4f-4f02-bc04-69b13ff9331a" width="308" /> "Szybko poszło" - napisał Mateusz Morawiecki, wytykając Donaldowi Tuskowi zgodę na nowe podatki w Unii Europejskiej. Internauci na platformie X (dawniej Twitter) szybko zwrócili uwagę, że jako premier rządu PiS, Morawiecki sam postulował nowe daniny w UE.

## 50 dni rządu Tuska. Wyliczają, o jakich obietnicach na razie zapomniał
 - [https://www.money.pl/gospodarka/50-dni-rzadu-tuska-wyliczaja-o-jakich-obietnicach-na-razie-zapomnial-6990921294953408a.html](https://www.money.pl/gospodarka/50-dni-rzadu-tuska-wyliczaja-o-jakich-obietnicach-na-razie-zapomnial-6990921294953408a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T06:42:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/345706e2-2391-4655-8db9-726341da9f48" width="308" /> Dziennik "Fakt" po pierwszych 50 dniach rządu Donalda Tuska postanowił sprawdzić ile obietnic ze 100 konkretów, które Koalicja Obywatelska przedstawiła w kampanii obywatelskiej, udało się zrealizować lub chociaż rozpocząć przygotowania do realizacji.

## Kursy walut 1.02.2024. Czwartkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-1-02-2024-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6990924964629472a.html](https://www.money.pl/pieniadze/kursy-walut-1-02-2024-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6990924964629472a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T06:29:09+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7672915c-7ab0-4284-8e5d-e0c0dfdadecd" width="308" /> Kursy walut - 1.02.2024. W czwartek za jednego dolara (USD) zapłacimy 4,0203 zł. Cena jednego funta szterlinga (GBP) to 5,0969 zł, a franka szwajcarskiego (CHF) 4,6601 zł. Z kolei euro (EUR) możemy zakupić za 4,3511 zł.

## Rewolucja w emeryturach. Koalicjant pokazuje projekt. Jest już w Sejmie
 - [https://www.money.pl/emerytury/emerytury-stazowe-projekt-juz-w-sejmie-6990916879567808a.html](https://www.money.pl/emerytury/emerytury-stazowe-projekt-juz-w-sejmie-6990916879567808a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T06:06:36+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/663372b2-8dda-4344-8811-9671486657ad" width="308" /> Lewica złożyła do Sejmu projekt ws. emerytur stażowych. Poseł Tadeusz Tomaszewski informuje, że projekt przewiduje możliwość przejścia na emeryturę stażową z chwilą, gdy kobieta ma 35 lat składkowych i nieskładkowych, a mężczyzna 40 lat.

## Kto na czele PZU? Jest mocny kandydat
 - [https://www.money.pl/gospodarka/kto-na-czele-pzu-jest-mocny-kandydat-6990911920597984a.html](https://www.money.pl/gospodarka/kto-na-czele-pzu-jest-mocny-kandydat-6990911920597984a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T05:47:57+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6ed07607-68b4-4ddd-9c70-7c24e517c3dc" width="308" /> Jak wynika z informacji Wyborcza.biz, na prezesa PZU zostanie powołany Jakub Karnowski, to były prezes PKP.

## PIT za 2023 rok. Pieniądze jeszcze w tym miesiącu na koncie. Oto co trzeba zrobić
 - [https://www.money.pl/podatki/pit-za-2023-rok-pieniadze-jeszcze-w-tym-miesiacu-na-koncie-oto-co-trzeba-zrobic-6990905923238848a.html](https://www.money.pl/podatki/pit-za-2023-rok-pieniadze-jeszcze-w-tym-miesiacu-na-koncie-oto-co-trzeba-zrobic-6990905923238848a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2024-02-01T05:27:32+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a3620888-8399-4929-9ef2-1d5dd2d51b6e" width="308" /> Od 15 lutego można rozliczać PIT za 2023 r. Akcja składania zeznań podatkowych potrwa do końca kwietnia. Kto szybko się rozliczy, może liczyć na szybki zwrot nadpłaconego podatku - informuje "Fakt" i dodaje, że  chodzi przede wszystkim o emerytów i rencistów, a także o osoby pracujące na umowach zlecenie.

