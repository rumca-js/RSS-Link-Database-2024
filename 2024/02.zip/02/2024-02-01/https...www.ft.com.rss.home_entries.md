# Source:FT - International homepage, URL:https://www.ft.com/rss/home, language:en

## McKinsey and BCG accused of withholding information on Saudi ties
 - [https://www.ft.com/content/f2938a10-39bb-4040-a786-00bc98e03061](https://www.ft.com/content/f2938a10-39bb-4040-a786-00bc98e03061)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T22:52:04+00:00

Senator says consultancies have not complied with subpoena seeking details of their work for the kingdom

## Trump’s legal bill and Biden’s cash boost: inside the 2024 money race
 - [https://www.ft.com/content/3d743072-cfe2-40d4-919c-8b09f048df65](https://www.ft.com/content/3d743072-cfe2-40d4-919c-8b09f048df65)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T22:24:04+00:00

Federal data shows which Wall Street billionaire is funding who — and how much Ron DeSantis spent on jets

## Amazon’s cloud growth gains steam as earnings bounce back
 - [https://www.ft.com/content/3bd6c1fb-66f8-406a-873e-49659133e0db](https://www.ft.com/content/3bd6c1fb-66f8-406a-873e-49659133e0db)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T21:51:00+00:00

Shares up as after quarterly report comes in ahead of Wall Street expectations

## Apple revenue boosted by iPhone sales and record services growth
 - [https://www.ft.com/content/df857a23-cbd2-4ce3-947a-0efb86a09dc3](https://www.ft.com/content/df857a23-cbd2-4ce3-947a-0efb86a09dc3)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T21:35:02+00:00

Tech giant snaps streak of quarterly revenue declines in holiday period

## Meta shares jump as investors cheer dividend and $50bn buyback
 - [https://www.ft.com/content/6ff944b6-bae0-4253-85af-fcf9cd54987c](https://www.ft.com/content/6ff944b6-bae0-4253-85af-fcf9cd54987c)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T21:34:04+00:00

Facebook and Instagram-parent’s earnings come in ahead of expectations as cost-cutting yields results

## Formula One’s Lewis Hamilton to join Ferrari from Mercedes
 - [https://www.ft.com/content/b6c42a25-b658-4973-886b-42f84d7921a2](https://www.ft.com/content/b6c42a25-b658-4973-886b-42f84d7921a2)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T20:32:20+00:00

British driver switches from team that has powered record-breaking career

## German liberals pull plug on EU law to prevent supply chain abuses
 - [https://www.ft.com/content/298882d9-9e5d-4f93-9832-ecb3e463bd56](https://www.ft.com/content/298882d9-9e5d-4f93-9832-ecb3e463bd56)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T18:38:54+00:00

FDP says Brussels’ sweeping legislation on enviromental and rights misdeeds would place a huge burden on business

## Coinbase slashes trading fees for high-volume traders
 - [https://www.ft.com/content/94b04716-27a0-44d3-a86e-a382dacff6e9](https://www.ft.com/content/94b04716-27a0-44d3-a86e-a382dacff6e9)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T18:33:09+00:00

US cryptocurrency exchange in effort to grab market share from offshore rivals

## NYCB shows why US regional banks are not trouble-free yet
 - [https://www.ft.com/content/85fc36e2-35a2-481a-9163-d814c63406a1](https://www.ft.com/content/85fc36e2-35a2-481a-9163-d814c63406a1)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T18:15:35+00:00

A record amount of loans are maturing and need refinancing this year and next

## US to put sanctions on Israeli settlers responsible for West Bank violence
 - [https://www.ft.com/content/60bef982-1e5e-4e3c-a068-687294554365](https://www.ft.com/content/60bef982-1e5e-4e3c-a068-687294554365)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T17:56:59+00:00

Order comes amid White House frustration with Netanyahu government’s hostility to two-state peace deal

## EU leaders pledge more concessions to appease angry farmers
 - [https://www.ft.com/content/90a48881-db31-4132-8519-36c96ba7c513](https://www.ft.com/content/90a48881-db31-4132-8519-36c96ba7c513)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T17:42:36+00:00

Tractors rolled into Brussels on Thursday to block major roads and squares close to summit gathering

## EU carmakers’ strategic U-turns point them in the right direction
 - [https://www.ft.com/content/68feb5d2-2904-46c8-872b-7c7ad81cb00f](https://www.ft.com/content/68feb5d2-2904-46c8-872b-7c7ad81cb00f)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T17:41:01+00:00

The wheels have not come off the electric vehicle market entirely

## Tesla would be five times bigger than all the public companies in Texas
 - [https://www.ft.com/content/0dcf5137-524a-4ccf-9038-231f7cec7779](https://www.ft.com/content/0dcf5137-524a-4ccf-9038-231f7cec7779)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T17:36:22+00:00

And yet, we’re struggling to care

## Bank losses revive fears over US commercial property market
 - [https://www.ft.com/content/9199361a-06bd-4de2-8b57-f8cef7143dd3](https://www.ft.com/content/9199361a-06bd-4de2-8b57-f8cef7143dd3)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T16:14:25+00:00

Lenders in US, Asia and Europe hit by exposure to sector struggling with lower occupancy and higher interest rates

## Red Sea crisis pushes up delivery times for European manufacturers
 - [https://www.ft.com/content/6c114551-9689-4a3c-b1cc-71790853c636](https://www.ft.com/content/6c114551-9689-4a3c-b1cc-71790853c636)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T14:50:36+00:00

Freight rates and input prices rise as Houthi militants continue attacks on key maritime chokepoint

## Big tech killed the internet — blockchain can help revive it
 - [https://www.ft.com/content/775a9133-1367-42ed-b1a7-ba10b31229c8](https://www.ft.com/content/775a9133-1367-42ed-b1a7-ba10b31229c8)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T14:49:11+00:00

Unlike traditional computers, blockchains ensure that any code they run will continue to operate as designed

## Ferrari profits boosted by bespoke car sales
 - [https://www.ft.com/content/f554f53b-7841-45f6-aab5-b4e12e963933](https://www.ft.com/content/f554f53b-7841-45f6-aab5-b4e12e963933)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T13:56:41+00:00

Italian luxury house reports record earnings and expects further jump in profits in 2024

## BoE says ‘more evidence’ needed before cuts as it holds rates at 5.25%
 - [https://www.ft.com/content/6f6d7cf9-eeb9-45da-a677-39f94ed6ccd3](https://www.ft.com/content/6f6d7cf9-eeb9-45da-a677-39f94ed6ccd3)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T12:59:02+00:00

Decision to keep rates steady comes despite progress in reducing inflation

## Shell raises dividend after second-highest cash flow in its history
 - [https://www.ft.com/content/6318b455-499c-4b1e-97a1-aa60e48c8e7a](https://www.ft.com/content/6318b455-499c-4b1e-97a1-aa60e48c8e7a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T12:27:27+00:00

Oil major announces further $3.5bn of share buybacks as 2023 profits top $28bn

## Apple’s Vision Pro will test Tim Cook’s legacy as an innovator
 - [https://www.ft.com/content/b3278bab-271d-4c8c-a157-ffeed0ba454f](https://www.ft.com/content/b3278bab-271d-4c8c-a157-ffeed0ba454f)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T12:00:05+00:00

‘Mixed reality’ headset released in US on Friday will define chief executive’s ability to create products with mass appeal

## Volvo Cars to stop funding Polestar electric sports car business
 - [https://www.ft.com/content/05075dd8-aec9-453c-9f5d-a2b7a71c3f57](https://www.ft.com/content/05075dd8-aec9-453c-9f5d-a2b7a71c3f57)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T11:46:50+00:00

Swedish carmaker looking to sell stake in spun-out group to its Chinese parent Geely

## EU agrees €50bn support package for Ukraine
 - [https://www.ft.com/content/154564aa-6e16-480f-a42b-bbafb4227413](https://www.ft.com/content/154564aa-6e16-480f-a42b-bbafb4227413)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T11:44:53+00:00

Hungarian Prime Minister Viktor Orbán rescinds veto after weeks of pressure from fellow leaders

## Eurozone inflation slows to 2.8% in January
 - [https://www.ft.com/content/0c1f51ff-e42c-4bbc-938a-2cc97c73894a](https://www.ft.com/content/0c1f51ff-e42c-4bbc-938a-2cc97c73894a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T11:13:15+00:00

Unchanged rate of growth for services prices could make ECB rate-setters cautious about interest rate cuts

## Why are nuclear power projects so challenging?
 - [https://www.ft.com/content/6d371375-b7be-4228-a3d5-2ad74f91454a](https://www.ft.com/content/6d371375-b7be-4228-a3d5-2ad74f91454a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T11:00:51+00:00

Low-carbon energy is key to avoiding shortages and hitting climate targets but projects are fraught with delays and budget overruns

## ‘Netanyahu — yes or no?’: the looming choice for Israeli voters
 - [https://www.ft.com/content/d5693fc7-7c13-4509-a45d-db14423dfe77](https://www.ft.com/content/d5693fc7-7c13-4509-a45d-db14423dfe77)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T11:00:51+00:00

Political class positioning for an early election as the veneer of October 7 unity begins to fade

## Tesla shareholders to vote on moving incorporation to Texas, says Musk
 - [https://www.ft.com/content/e43d5886-1f65-466d-ba4b-9f7b242a2573](https://www.ft.com/content/e43d5886-1f65-466d-ba4b-9f7b242a2573)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T09:58:27+00:00

Move comes after chief executive’s record pay package was voided by a Delaware judge

## Modi government outlines record capex in pre-election budget
 - [https://www.ft.com/content/c668f539-1717-4c4b-b4d2-e0096ecef16e](https://www.ft.com/content/c668f539-1717-4c4b-b4d2-e0096ecef16e)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T09:53:22+00:00

New Delhi plans to raise infrastructure spending and trim fiscal deficit as it touts economic record

## Frozen Russian assets yielded €4.4bn in 2023, says Euroclear
 - [https://www.ft.com/content/f4c21b08-5f89-4abb-b72c-6f4b110c790b](https://www.ft.com/content/f4c21b08-5f89-4abb-b72c-6f4b110c790b)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T09:46:41+00:00

EU is moving to use profit from the €191bn in immobilised Russian assets to help Ukraine

## Julius Baer’s profits tumble 52% as Signa hit triggers CEO exit
 - [https://www.ft.com/content/7f779977-186c-4868-9a0b-44aed802b605](https://www.ft.com/content/7f779977-186c-4868-9a0b-44aed802b605)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T07:54:16+00:00

Philipp Rickenbacher will leave Swiss wealth manager after loans to troubled property group soured

## SK Hynix to build advanced plant in Indiana in boost to US chip self-sufficiency
 - [https://www.ft.com/content/080fb826-a966-44e7-bae5-7dbf525df1fb](https://www.ft.com/content/080fb826-a966-44e7-bae5-7dbf525df1fb)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T06:52:47+00:00

South Korean company’s memory chips will be packaged with Nvidia processors to create more powerful AI products

## The Fed won’t be rushed
 - [https://www.ft.com/content/775ad35c-dfa7-4628-8ff4-2889236b08c2](https://www.ft.com/content/775ad35c-dfa7-4628-8ff4-2889236b08c2)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T06:30:50+00:00

And the meaning of NYCB’s meltdown

## Trump’s court battles boost and drain campaign coffers
 - [https://www.ft.com/content/6383fe12-63db-4fb1-81dc-a4ccccda3dab](https://www.ft.com/content/6383fe12-63db-4fb1-81dc-a4ccccda3dab)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T06:00:44+00:00

Groups backing the former president spent more than $52mn on legal fees in 2023

## Tech bros want to live forever. They should be studying human ovaries
 - [https://www.ft.com/content/9599c28e-aa49-46fe-ace9-266bd4fe1023](https://www.ft.com/content/9599c28e-aa49-46fe-ace9-266bd4fe1023)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T05:38:27+00:00

Fundamental questions about ovaries may unlock longer human lifespan. Philanthropist Nicole Shanahan is spending to find answers

## China’s Xinjiang aluminium boom exposes global carmakers to forced labour
 - [https://www.ft.com/content/e06411d1-5237-414e-9dec-0ef908f40ca3](https://www.ft.com/content/e06411d1-5237-414e-9dec-0ef908f40ca3)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T05:30:29+00:00

Abuse of Uyghur Muslims in supply chain raises acute tensions with west, Human Rights Watch shows

## Alone in the Prado: behind the scenes in one of the world’s greatest museums
 - [https://www.ft.com/content/42582a60-61ad-48d6-afc1-0628e126abc9](https://www.ft.com/content/42582a60-61ad-48d6-afc1-0628e126abc9)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T05:00:51+00:00

One writer, two months and a feast of Spanish art

## Chevron loses shine with investors after bumpy year
 - [https://www.ft.com/content/845ffe89-fe71-477d-bcd2-0a45fdb15358](https://www.ft.com/content/845ffe89-fe71-477d-bcd2-0a45fdb15358)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T05:00:51+00:00

US oil major’s shares lag those of ExxonMobil as analysts question production and climate trends

## EU leaders gather for showdown with Orbán on Ukraine
 - [https://www.ft.com/content/d61ccd8c-42b5-4735-a206-64c29d4f80a7](https://www.ft.com/content/d61ccd8c-42b5-4735-a206-64c29d4f80a7)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T05:00:51+00:00

Summit in Brussels will be bloc’s last attempt to secure €50bn funding for Kyiv and prevent irreparable rift

## Jay Powell is willing to cut interest rates — but not yet
 - [https://www.ft.com/content/5a182f1b-695e-4a55-ba78-6b46b0658f91](https://www.ft.com/content/5a182f1b-695e-4a55-ba78-6b46b0658f91)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T05:00:51+00:00

The US Federal Reserve is set to err on the side of caution in its quest to bring inflation under control

## Sacked Endeavour Mining chief faced sexual misconduct claims
 - [https://www.ft.com/content/59f1e2b0-5b83-41ae-967a-aff60d677933](https://www.ft.com/content/59f1e2b0-5b83-41ae-967a-aff60d677933)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T05:00:51+00:00

Allegations are in addition to claims that Sébastien de Montessus instructed ‘irregular’ $5.9mn payment

## The Elon Musk pay dilemma
 - [https://www.ft.com/content/be79d91a-798c-489f-8cdc-2563719f2da1](https://www.ft.com/content/be79d91a-798c-489f-8cdc-2563719f2da1)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T05:00:51+00:00

Every tech company with a founder at the helm faces the ‘how much’ question — but there are many ways to answer

## Viktor Orbán: what is the endgame for Europe’s chief disrupter?
 - [https://www.ft.com/content/e158834e-1860-4dee-9d2f-3458ec71f287](https://www.ft.com/content/e158834e-1860-4dee-9d2f-3458ec71f287)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T05:00:51+00:00

The Hungarian prime minister has a long history of extracting EU concessions. He hopes a shift to the right could work in his favour

## China’s overcapacity a challenge that is ‘here to stay’, says US chamber
 - [https://www.ft.com/content/6bce03f5-bc7c-45df-9d86-363ade9ab47f](https://www.ft.com/content/6bce03f5-bc7c-45df-9d86-363ade9ab47f)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T04:56:43+00:00

AmCham warns that majority of companies are still unprofitable in a ‘wake-up call’ to Beijing

## Pokémon with guns and the democratisation of gaming
 - [https://www.ft.com/content/bf8f652d-5a8b-4a52-9f37-284d77b51e8f](https://www.ft.com/content/bf8f652d-5a8b-4a52-9f37-284d77b51e8f)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T02:14:11+00:00

As the use of generative AI spreads, it will be harder for the bigger studios to protect their market share

## Prisoner No. 804: Imran Khan turns to AI to fight Pakistan’s election from jail
 - [https://www.ft.com/content/7c3c5827-c965-453c-8bd1-d1312e90669a](https://www.ft.com/content/7c3c5827-c965-453c-8bd1-d1312e90669a)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T02:00:50+00:00

Barred from next week’s vote, former prime minister taps chatbots and TikTok to energise his party’s supporters

## KKR raises record $6.4bn for Asia fund in infrastructure rush
 - [https://www.ft.com/content/c25c33c7-f24c-4a1e-bce0-fa7dd8fc49fb](https://www.ft.com/content/c25c33c7-f24c-4a1e-bce0-fa7dd8fc49fb)
 - RSS feed: https://www.ft.com/rss/home
 - date published: 2024-02-01T01:00:50+00:00

US private equity group’s bet follows other firms’ moves into sector but largely avoids deals in China

