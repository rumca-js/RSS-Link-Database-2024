# Source:Gulf Insider, URL:https://www.gulf-insider.com/feed, language:en-US

## Bahrainis Can Fly Multiple Times in Two Years to UK for Just BD4.8 From Today
 - [https://www.gulf-insider.com/bahrainis-can-fly-multiple-times-in-two-years-to-uk-for-just-bd4-8-from-today](https://www.gulf-insider.com/bahrainis-can-fly-multiple-times-in-two-years-to-uk-for-just-bd4-8-from-today)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T12:13:22+00:00

<p>The new electronic permit system for travellers heading to the UK is set to take effect starting today (February 1). This was confirmed through an official statement from the UK Embassy in Bahrain to our sister newspaper, Al Ayam. The Electronic Travel Authorization (ETA) will allow Bahraini citizens to travel to the UK for multiple &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/bahrainis-can-fly-multiple-times-in-two-years-to-uk-for-just-bd4-8-from-today/">Bahrainis Can Fly Multiple Times in Two Years to UK for Just BD4.8 From Today</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## 4 Expats Executed for Killing Sudanese in Saudi Arabia
 - [https://www.gulf-insider.com/4-expats-executed-for-killing-sudanese-in-saudi-arabia](https://www.gulf-insider.com/4-expats-executed-for-killing-sudanese-in-saudi-arabia)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T12:08:37+00:00

<p>Saudi Arabia said it had executed four Ethiopian expatriates on charges of murdering a Sudanese national. The four were convicted of taking turns in fatally bludgeoning the victim and stabbing him after having tied his hands and feet, the Saudi Interior Ministry said. The motive for the murder was not given. The inmates were also &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/4-expats-executed-for-killing-sudanese-in-saudi-arabia/">4 Expats Executed for Killing Sudanese in Saudi Arabia</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Mandatory Insurance Rule for Domestic Workers Takes Effect in Saudi Arabia
 - [https://www.gulf-insider.com/mandatory-insurance-rule-for-domestic-workers-takes-effect-in-saudi-arabia](https://www.gulf-insider.com/mandatory-insurance-rule-for-domestic-workers-takes-effect-in-saudi-arabia)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T12:05:05+00:00

<p> Mandatory insurance on contracts of new domestic workers in Saudi Arabia has gone into effect on Thursday, as part of regulating the labour market in the kingdom. According to the Ministry of Human Resources, the service applies to the first two years of the domestic labour contracts. Insurance will be optional for the employer after &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/mandatory-insurance-rule-for-domestic-workers-takes-effect-in-saudi-arabia/">Mandatory Insurance Rule for Domestic Workers Takes Effect in Saudi Arabia</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Charity Says Egypt Intelligence-Linked Firm Charging $5,000 per Truck to Get Aid Into Gaza
 - [https://www.gulf-insider.com/charity-says-egypt-intelligence-linked-firm-charging-5000-per-truck-to-get-aid-into-gaza](https://www.gulf-insider.com/charity-says-egypt-intelligence-linked-firm-charging-5000-per-truck-to-get-aid-into-gaza)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T11:48:06+00:00

<p>An international charity with extensive experience in providing emergency aid in wars, famines and earthquakes throughout the Middle East and in Afghanistan is being forced to pay $5,000 a truck to a company linked to Egypt’s General Intelligence Service (GIS) to get aid into Gaza. The charity, which does not want to be named to avoid obstruction to its relief efforts in Gaza, spoke &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/charity-says-egypt-intelligence-linked-firm-charging-5000-per-truck-to-get-aid-into-gaza/">Charity Says Egypt Intelligence-Linked Firm Charging $5,000 per Truck to Get Aid Into Gaza</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## UK Law Could Ban Apple Security Updates Across the World in an ‘Unprecedented Overreach’
 - [https://www.gulf-insider.com/uk-law-could-ban-apple-security-updates-across-the-world-in-an-unprecedented-overreach](https://www.gulf-insider.com/uk-law-could-ban-apple-security-updates-across-the-world-in-an-unprecedented-overreach)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T11:39:34+00:00

<p>Apple is no stranger to controversy, especially involving government bodies. But a new proposal could aim to be “unprecedented” in its reach over the tech giant. Several amendments to the UK’s Investigatory Powers Act (IPA) have been proposed, one that would require Apple (and any other company) to “notify UK officials of any updates they planned &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/uk-law-could-ban-apple-security-updates-across-the-world-in-an-unprecedented-overreach/">UK Law Could Ban Apple Security Updates Across the World in an ‘Unprecedented Overreach&#8217;</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## The Days of $100 Oil Prices Are Over
 - [https://www.gulf-insider.com/the-days-of-100-oil-prices-are-over](https://www.gulf-insider.com/the-days-of-100-oil-prices-are-over)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T11:07:55+00:00

<p>Oil will be part of our lives for decades to come. But its value to the consumer has already topped out. Consider the long-term trend for oil prices. Futures markets hint at little concern about supply since the latest Middle East tension began in October. Even one of the world’s largest producers might be rethinking &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/the-days-of-100-oil-prices-are-over/">The Days of $100 Oil Prices Are Over</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Gut Inflammation Linked to Alzheimer’s Disease, Yet Again
 - [https://www.gulf-insider.com/gut-inflammation-linked-to-alzheimers-disease-yet-again](https://www.gulf-insider.com/gut-inflammation-linked-to-alzheimers-disease-yet-again)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T09:13:47+00:00

<p>Researchers connecting pieces of the massive Alzheimer&#8217;s puzzle are closer to slotting the next one in place, with yet another link between our guts and brain. Recent animal studies have demonstrated Alzheimer&#8217;s can be passed on to young mice through a transfer of gut microbes, confirming a link between the digestive system and the health of the brain. &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/gut-inflammation-linked-to-alzheimers-disease-yet-again/">Gut Inflammation Linked to Alzheimer’s Disease, Yet Again</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Updated COVID-19 Vaccines May Cause Heart Inflammation and Severe Allergic Shock, According to New FDA Study
 - [https://www.gulf-insider.com/updated-covid-19-vaccines-may-cause-heart-inflammation-and-severe-allergic-shock-according-to-new-fda-study](https://www.gulf-insider.com/updated-covid-19-vaccines-may-cause-heart-inflammation-and-severe-allergic-shock-according-to-new-fda-study)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T09:08:13+00:00

<p>Researchers with the FDA, the U.S. National Institutes of Health, and companies like CVS looked at health care databases to try to figure out if there were signs the Moderna and Pfizer bivalent COVID-19 vaccines might be linked to any health issues. They found several safety signals. One signal was for myocarditis, a form of &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/updated-covid-19-vaccines-may-cause-heart-inflammation-and-severe-allergic-shock-according-to-new-fda-study/">Updated COVID-19 Vaccines May Cause Heart Inflammation and Severe Allergic Shock, According to New FDA Study</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Optimistic Mindset Linked to Poor Decision Making
 - [https://www.gulf-insider.com/optimistic-mindset-linked-to-poor-decision-making](https://www.gulf-insider.com/optimistic-mindset-linked-to-poor-decision-making)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T09:03:56+00:00

<p>While a positive mindset is often associated with success, a new study suggests that optimism often leads to poor decision-making, especially when it come to finances. The study, conducted by the University of Bath in the UK and published in the Personality and Social Psychology Bulletin, sought to determine if people with an optimistic mindset had &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/optimistic-mindset-linked-to-poor-decision-making/">Optimistic Mindset Linked to Poor Decision Making</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## UAE Visa for Indians: Dubai’s Emirates Announces Pre-approved Visa on Arrival Service in New VFS Deal
 - [https://www.gulf-insider.com/uae-visa-for-indians-dubais-emirates-announces-pre-approved-visa-on-arrival-service-in-new-vfs-deal](https://www.gulf-insider.com/uae-visa-for-indians-dubais-emirates-announces-pre-approved-visa-on-arrival-service-in-new-vfs-deal)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T08:55:57+00:00

<p>Emirates Airline and VFS Global have partnered to introduce a convenient pre-approved visa-on-arrival service exclusively for Indian passport holders travelling to Dubai. This initiative aims to streamline the arrival process for Emirates customers, allowing them to bypass lengthy queues and swiftly navigate customs upon reaching their destination. Indian travellers who have booked their flights with Emirates can &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/uae-visa-for-indians-dubais-emirates-announces-pre-approved-visa-on-arrival-service-in-new-vfs-deal/">UAE Visa for Indians: Dubai’s Emirates Announces Pre-approved Visa on Arrival Service in New VFS Deal</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## US Kicks Off Domestic H-1B Visa Renewals
 - [https://www.gulf-insider.com/us-kicks-off-domestic-h-1b-visa-renewals](https://www.gulf-insider.com/us-kicks-off-domestic-h-1b-visa-renewals)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T05:29:29+00:00

<p>The US announced the commencement of a pilot programme to allow qualified nonimmigrant workers to renew their H-1B visas domestically. The facility is to be offered to 20,000 H-1B visa holders in the initial phase. The programme offers H-1B visa holders, including Indian nationals, to renew their visas without the need to leave the United &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/us-kicks-off-domestic-h-1b-visa-renewals/">US Kicks Off Domestic H-1B Visa Renewals</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## India Eyes $61BN Export Opportunity In UAE, Saudi, Qatar And Egypt
 - [https://www.gulf-insider.com/india-eyes-61bn-export-opportunity-in-uae-saudi-qatar-and-egypt](https://www.gulf-insider.com/india-eyes-61bn-export-opportunity-in-uae-saudi-qatar-and-egypt)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T05:28:42+00:00

<p>India has opportunities to boost trade to UAE, Saudi Arabia, Qatar and more countries in coming years, according to HSBC analysis. Investors and corporates in India and across the Middle East, North Africa and Türkiye (MENAT) are set for a decade of accelerated opportunity, according to a new report by HSBC. India-MENAT Corridor Outlook: Harnessing &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/india-eyes-61bn-export-opportunity-in-uae-saudi-qatar-and-egypt/">India Eyes $61BN Export Opportunity In UAE, Saudi, Qatar And Egypt</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Kerala Announces Incentive Plan, Targets UAE, Riyadh Firms With Low-Cost Back-End It Infrastructure
 - [https://www.gulf-insider.com/kerala-announces-incentive-plan-targets-uae-riyadh-firms-with-low-cost-back-end-it-infrastructure](https://www.gulf-insider.com/kerala-announces-incentive-plan-targets-uae-riyadh-firms-with-low-cost-back-end-it-infrastructure)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T05:25:54+00:00

<p>Kerala, the southern Indian state, is set to announce a set of attractive incentive packages, including reduced land lease charges and rental costs, to woo corporate biggies from the Middle East, especially from Dubai and Riyadh – the two emerging global hubs for businesses – to set up their technology centres or back up operations &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/kerala-announces-incentive-plan-targets-uae-riyadh-firms-with-low-cost-back-end-it-infrastructure/">Kerala Announces Incentive Plan, Targets UAE, Riyadh Firms With Low-Cost Back-End It Infrastructure</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Burj Al Arab And Emirates Palace ‘Most Recommended’ Hotels In UAE, Emirates Tops 2024 Airline Ranking
 - [https://www.gulf-insider.com/burj-al-arab-and-emirates-palace-most-recommended-hotels-in-uae-emirates-tops-2024-airline-ranking](https://www.gulf-insider.com/burj-al-arab-and-emirates-palace-most-recommended-hotels-in-uae-emirates-tops-2024-airline-ranking)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T05:24:31+00:00

<p>The UAE’s most loved hotels and airlines have been named in a survey of brand advocacy in the country. Burj Al Arab tops YouGov’s Hotel Advocacy Rankings 2024 in UAE, with a score of 76.5. It makes Dubai’s most iconic hotel the property most likely to be recommended in the UAE. The Hotel Advocacy rankings &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/burj-al-arab-and-emirates-palace-most-recommended-hotels-in-uae-emirates-tops-2024-airline-ranking/">Burj Al Arab And Emirates Palace ‘Most Recommended’ Hotels In UAE, Emirates Tops 2024 Airline Ranking</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## World’s Best Police Forces Head To Dubai For $260,000 UAE SWAT Challenge
 - [https://www.gulf-insider.com/worlds-best-police-forces-head-to-dubai-for-260000-uae-swat-challenge](https://www.gulf-insider.com/worlds-best-police-forces-head-to-dubai-for-260000-uae-swat-challenge)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T05:24:04+00:00

<p>Dubai Police will host leading international law enforcement agencies for the record-breaking UAE SWAT Challenge. Police forces will head to Dubai for a prize fund worth $260,000 in challenges including assault courses, sniping and tactical shooting. The Organising Committee of the UAE SWAT Challenge has released details of the fifth edition of the competition set &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/worlds-best-police-forces-head-to-dubai-for-260000-uae-swat-challenge/">World’s Best Police Forces Head To Dubai For $260,000 UAE SWAT Challenge</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Dubai, Abu Dhabi Rank Among Wealthiest Cities In BRICS Bloc
 - [https://www.gulf-insider.com/dubai-abu-dhabi-rank-among-wealthiest-cities-in-brics-bloc](https://www.gulf-insider.com/dubai-abu-dhabi-rank-among-wealthiest-cities-in-brics-bloc)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T05:19:50+00:00

<p>Beijing, Shanghai and Dubai are the top three richest cities in the newly expanded BRICS bloc based on the number of millionaires, centi-millionaires and billionaires in each city. Following the expansion earlier this month, the group now includes: Brazil, Russia, India, China, South Africa, Egypt, Ethiopia, Iran, Saudi Arabia and the UAE. The world’s wealthiest &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/dubai-abu-dhabi-rank-among-wealthiest-cities-in-brics-bloc/">Dubai, Abu Dhabi Rank Among Wealthiest Cities In BRICS Bloc</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi Arabia Mulls Selling Additional Shares In Aramco To Raise SR40 Billion-Reports
 - [https://www.gulf-insider.com/saudi-arabia-mulls-selling-additional-shares-in-aramco-to-raise-sr40-billion-bloomberg-reports](https://www.gulf-insider.com/saudi-arabia-mulls-selling-additional-shares-in-aramco-to-raise-sr40-billion-bloomberg-reports)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T05:19:00+00:00

<p>&#160;Saudi Arabia is considering reviving plans for a follow-on share offering in Saudi Aramco to raise at least SR40 billion ($10 billion) as early as February, Bloomberg News reported on Wednesday, citing sources familiar with the matter. The report follows the Saudi government’s directive on Tuesday to Aramco to halt its oil expansion plan. According &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-arabia-mulls-selling-additional-shares-in-aramco-to-raise-sr40-billion-bloomberg-reports/">Saudi Arabia Mulls Selling Additional Shares In Aramco To Raise SR40 Billion-Reports</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Rakitic Joins Al-Shabab As Clubs Make Last-minute Moves In Saudi Winter Transfer Window
 - [https://www.gulf-insider.com/rakitic-joins-al-shabab-as-clubs-make-last-minute-moves-in-saudi-winter-transfer-window](https://www.gulf-insider.com/rakitic-joins-al-shabab-as-clubs-make-last-minute-moves-in-saudi-winter-transfer-window)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T05:12:42+00:00

<p>&#160;In the final hours of the Saudi Arabian football winter transfer market, clubs made significant signings to strengthen their squads for upcoming competitions. One of the most prominent deals was the acquisition of the veteran Croatian player, Ivan Rakitić, aged 35, by Al-Shabab Saudi Club for a year and a half. Rakitić, who has a &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/rakitic-joins-al-shabab-as-clubs-make-last-minute-moves-in-saudi-winter-transfer-window/">Rakitic Joins Al-Shabab As Clubs Make Last-minute Moves In Saudi Winter Transfer Window</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

## Saudi: Weather Fluctuations To Continue Hitting Most Saudi Regions Until Friday
 - [https://www.gulf-insider.com/saudi-weather-fluctuations-to-continue-hitting-most-saudi-regions-until-friday](https://www.gulf-insider.com/saudi-weather-fluctuations-to-continue-hitting-most-saudi-regions-until-friday)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2024-02-01T05:12:08+00:00

<p>The National Center of Meteorology (NCM) predicted that weather fluctuations, featuring light and moderate rainfall, dusty surface wind, high waves, light snowfall, and low temperatures, would continue hitting most regions of the Kingdom until Friday. In a statement issued on Tuesday, the center said that the southern Asir region will witness light rain from Tuesday &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-weather-fluctuations-to-continue-hitting-most-saudi-regions-until-friday/">Saudi: Weather Fluctuations To Continue Hitting Most Saudi Regions Until Friday</a> appeared first on <a href="https://www.gulf-insider.com">Gulf Insider</a>.</p>

