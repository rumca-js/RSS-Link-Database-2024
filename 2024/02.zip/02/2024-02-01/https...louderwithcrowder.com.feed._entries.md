# Source:Louder With Crowder, URL:https://louderwithcrowder.com/feed/, language:en-US

## Residents Demand Action That Local Officials Stop Creepy “Diaper Spa.” For Adults. Who Like Dressing In Diapers.
 - [https://www.louderwithcrowder.com/atkinson-diaper-spa](https://www.louderwithcrowder.com/atkinson-diaper-spa)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-02-01T22:38:03+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.webp?id=51275218&amp;width=1245&amp;height=700&amp;coordinates=0%2C60%2C0%2C60" /><br /><br /><p>If you want to know what happens when you not only condone mental illness but go as far as to celebrate it, look no further. Because this is what happens. </p><p>Atkinson is a city in New Hampshire. It is now home to the “Diaper Spa”. This is a “spa” where “adults” wear diapers and pretend they are children.</p><p><a href="https://thepostmillennial.com/adult-diaper-therapy-spa-opens-in-new-hampshire-amid-community-backlash#google_vignette" rel="noopener noreferrer" target="_blank">According to The <em>Post Millennial</em></a><em>: </em></p><blockquote>“A bed and breakfast catering to so-called Adult Baby/Diaper Lovers (ABDL) in a small New Hampshire town has drawn criticism and backlash from the community.<br /><br />
The Diaper Spa, located at 23 Pope Road in Atkinson, NH, is advertised as being a ‘physician-run diap

## Blue State Calls For Ban Of Hostile Architecture That Prevents Homeless Encampments And... Wait, "Hostile Architecture?"
 - [https://www.louderwithcrowder.com/washington-hostile-architecture](https://www.louderwithcrowder.com/washington-hostile-architecture)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-02-01T22:33:31+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=51275903&amp;width=1245&amp;height=700&amp;coordinates=0%2C403%2C0%2C403" /><br /><br /><p>Progressives in Washington have decided that local officials have no right to come up with efficient ways to prevent homeless encampments. </p><p>A new bill would ban “hostile architecture” and make it illegal to set up boulders, structures, or other elements that are used to prevent homeless encampments.</p><p><a href="https://www.kiro7.com/news/local/bill-would-ban-cities-using-boulders-other-hostile-architecture-prevent-camping/6XNYYKNZLZFBFHVP2WYF2IRXAA/" rel="noopener noreferrer" target="_blank">According to KIRO7: </a></p><blockquote>“A new bill would make it illegal for a city to set up boulders, structures or design elements for the purpose of stopping homeless people from camping in a public space.<br /><br />
Senate Bill 6231 calls the obstacles ‘hostile architecture.’<br /><br />
‘Hostile architecture mean

## Woke High School Put Tampons In The Guys' Restroom, So A Group Of Dudes Destroyed The Dispenser Within Minutes
 - [https://www.louderwithcrowder.com/connecticut-tampons-male](https://www.louderwithcrowder.com/connecticut-tampons-male)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-02-01T22:29:32+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=51276255&amp;width=1245&amp;height=700&amp;coordinates=0%2C11%2C0%2C11" /><br /><br /><p>There is only one logical thing to do when you find a tampon dispenser in the boys' restroom. And some guys at a high school in Connecticut knew exactly what that logical thing was. </p><p>A new state law required menstrual products in at least one men’s bathroom. But you don’t need a high school diploma to know how incredibly asinine that is. So within minutes, a group of guys did what needed to be done. </p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/nypost/status/1752855129261261193"></a>
</blockquote>
<p><a href="https://nypost.com/2024/01/31/metro/new-tampon-dispenser-ripped-down-at-brookfield-hs-in-boys-bathroom/" rel="noopener noreferrer" target="_blank">According to The <em>New York Post: </em></a></p><blockquote>A state-mandated tam

## Here it is, the dumbest thing said by a crime-ridden progressive city official: "We can't prosecute or arrest our way..."
 - [https://www.louderwithcrowder.com/dc-ag-crime](https://www.louderwithcrowder.com/dc-ag-crime)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-02-01T18:50:34+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=51274608&amp;width=1200&amp;height=800&amp;coordinates=0%2C0%2C184%2C0" /><br /><br /><p>Our nation's capital is currently suffering a major crime wave that is very, very bad. <a href="https://www.heritage.org/crime-and-justice/commentary/blame-dc-city-council-the-crime-crisis-it-helped-create#:~:text=Key%20Takeaways,force%20short%20about%20500%20officers." rel="noopener noreferrer" target="_blank">Compared </a>to this time last year, homicides are up 37 percent. A<a href="https://www.louderwithcrowder.com/dc-cvs-theft" target="_self">uto thefts </a>are up 106 percent. Robberies are up 66 percent. And carjackings are up 108 percent. </p><p>On top of all that mess, just this week, a Trump official was shot during a carjacking that killed a second victim, and the city saw 60 car break-ins in 72 hours. </p><p>So what's the nation’s capital to do? </p><p>Well, you definitely cannot prosecute people for this. Y

## Watch: Squad member attacks Walgreens, calls it racist for them to close stores instead of letting people rob from them
 - [https://www.louderwithcrowder.com/ayanna-pressley-walgreens](https://www.louderwithcrowder.com/ayanna-pressley-walgreens)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-02-01T18:12:10+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=51272831&amp;width=1200&amp;height=400&amp;coordinates=0%2C0%2C0%2C244" /><br /><br /><p>Squad member Rep. Ayanna Pressley (D-MA), the one with a very bald and very shiny head, said that Walgreens is racist because of leaving crime-ridden neighborhoods. And yes, it is safe to assume this has nothing to do with the demographics of the area and nearly everything to do with unprecedented levels of theft. But of course, she can’t let those facts get in the way of her demands for attention that she so desperately craves.</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">'Stop Divesting From Black And Brown Communities': Ayanna Pressley Hammers Recent Walgreens Closures</small>
<small class="image-media media-photo-credit">
<a href="https://www.youtube.com/watch?v=D3vQyesjRZM" target="_bl

## Shocking New Documentary: Inside The China Plot to Destroy America From Within
 - [https://www.louderwithcrowder.com/crowder-china-documentary](https://www.louderwithcrowder.com/crowder-china-documentary)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-02-01T17:47:14+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=51271072&amp;width=1200&amp;height=400&amp;coordinates=0%2C0%2C0%2C294" /><br /><br /><p>Organized crime has taken over middle America. Our team went on the ground to find out exactly how the Chinese Communist Party (CCP) is propping up the trade of human trafficking and drugs to destabilize the nation. </p><p>Several years ago Oklahomo legalized marijuana. It is now the weed capital of the United States, possibly even the world. But despite hopes that this would destroy the black market, the exact opposite happened. And since <a href="https://www.oklahoman.com/story/news/crime/2023/11/28/oklahoma-medical-marijuana-authority-illegal-grows-wild-west-weed/71719054007/" rel="noopener noreferrer" target="_blank">2021</a>, agents have shut down more than 1,000 illegal marijuana farms. It currently has over double the amount of dispensaries in California, with over 2,300 <a href="https://www.dispenseapp.com/blog

## Inside The China Plot to Destroy America From Within: Triads, Drugs & Murder (A LWC Exclusive)
 - [https://www.louderwithcrowder.com/inside-the-china-plot-to-destroy-america-from-within-triads-drugs-murder-a-lwc-exclusive](https://www.louderwithcrowder.com/inside-the-china-plot-to-destroy-america-from-within-triads-drugs-murder-a-lwc-exclusive)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-02-01T15:06:30+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.webp?id=51256041&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C1" /><br /><br /><p>Our team went on the ground to find out exactly how the Chinese Communist Party is propping up the trade of illicit narcotics, human trafficking, and even murder, to destabilize the United States. What we found will send chills up your spine...</p><div class="rm-embed embed-media"></div><p><strong>SOURCES</strong><br /></p><ul><li><a href="https://www.okoha.com/OHA/OHA/Advocacy/State/SQ_788_Marijuana.aspx" rel="noopener noreferrer" target="_blank">State Question 788 - Marijuana</a></li><li><a href="https://www.okoha.com/OHA/OHA/Advocacy/State/SQ_788_Marijuana.aspx" rel="noopener noreferrer" target="_blank"></a><a href="https://vicentellp.com/img/content/downloads/An_Economic_Impact_and_Tax_Analysis_of_Oklahoma_State_Question_820.pdf" rel="noopener noreferrer" target="_blank">An Economic Impact and Tax Analysis of Oklaho

## Undercover footage exposes how little WH staff think of Joe Biden, Kamala Harris: "She hemorrhages black staff"
 - [https://www.louderwithcrowder.com/white-house-cybersecurity-analyst-exposed](https://www.louderwithcrowder.com/white-house-cybersecurity-analyst-exposed)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-02-01T13:52:53+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=51252507&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>It will never cease to amaze me how much Washington DC staffers don't know that the city has ears and eyes everywhere. Yet they still insist on badmouthing their powerful employees in social settings. Dinkuses such as  Top White House Cyber Security Official Charlie Kraiger. You know the polls that show you how little the American people think of Joe Biden and Kamala Harris? It appears people in the White House don't like them much either.</p><p>At least, according to Kraiger trying to impress his date. More on the date in a bit.</p><p>The people who work for Biden, much like all of us with functioning eyes, have noticed the president in OBVIOUS mental decline. But, “no one in modern history has ever said, like, ‘We're not going to renominate the president for a second term.’”</p><p>They hate Kamala too. Though, a certai

## Watch: Gavin Newsom asks to speak to a manager when Target employee blames "the governor" for shoplifting, thinks he's the hero
 - [https://www.louderwithcrowder.com/gavin-newsom-san-francisco-target](https://www.louderwithcrowder.com/gavin-newsom-san-francisco-target)
 - RSS feed: https://louderwithcrowder.com/feed/
 - date published: 2024-02-01T12:48:09+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=51251366&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>We here at the Louder with Crowder Dot Com website aren't ones for hyperbole, but this may be the most epic self-own in the history of politics. California Governor Gavin Newsom asked a Target employee why she didn't do anything about a shoplifter while he was their paying for stuff. Not knowing who her customer was, she said it was because of the Governor's policies.</p><p>So he asked to speak to a manager.</p><p>Newsom unintentionally played himself on a Zoom forum.</p><p>"We’re having a conversation, <strong>where’s your manager?</strong> How are you blaming the governor? And it was $380 later, and I was like ‘Why am I spending $380, everyone else can walk the hell right out?’”</p><div class="rm-embed embed-media"><blockquote class="twitter-tweet">California Gov. Gavin Newsom shares a story about being in a Target and

