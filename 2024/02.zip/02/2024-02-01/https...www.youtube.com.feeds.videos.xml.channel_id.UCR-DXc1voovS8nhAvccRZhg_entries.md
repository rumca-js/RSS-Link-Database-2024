# Source:Jeff Geerling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg, language:en-US

## This doorbell is the most dangerous thing at my studio (moving 12)
 - [https://www.youtube.com/watch?v=sxA4zKwHHgY](https://www.youtube.com/watch?v=sxA4zKwHHgY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCR-DXc1voovS8nhAvccRZhg
 - date published: 2024-02-01T15:00:48+00:00

SimpliSafe Video Doorbell Pro: Caught fire, would not recommend!

Mentioned in this video (some links are affiliate links):

  - SimpliSafe Video Doorbell Pro: https://simplisafe.com/video-doorbell-pro
  - Wayback Machine entry: https://web.archive.org/web/20231204135842/https://simplisafe.com/video-doorbell-pro
  - My blog post about it: https://www.jeffgeerling.com/blog/2023/my-simplisafe-doorbell-lit-its-own-fire-winter
  - My Tweet about it: https://twitter.com/geerlingguy/status/1737256067510177793
  - Jameco Reliapro 24v Transformer: https://amzn.to/3OEKkl9
  - OhmKat SimpliSafe Power Supply: https://amzn.to/3UiYDiQ
  - OptoMOS Relay specs: https://ixapps.ixys.com/DataSheet/LCB710.pdf
  - The Sound of Dial-up Poster: https://www.redbubble.com/i/poster/The-Sound-of-the-Dialup-Explained-by-windytan/31262230.LVTDI
  - Fedmax Metal Storage cabinets: https://amzn.to/3Sk00ep
  - Flexispot 40x24 Height Adjustable desk: https://amzn.to/3Sl80f4
  - QNAP QSW-3216R-8S8T-US Switch:

