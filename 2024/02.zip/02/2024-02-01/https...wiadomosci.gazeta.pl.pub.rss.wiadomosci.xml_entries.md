# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Adam Bodnar przeprosił osoby LGBT+ za krzywdy ze strony państwa polskiego. "Czujemy się zobowiązani"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30658051,adam-bodnar-przeprosil-osoby-lgbt-za-krzywdy-ze-strony-panstwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30658051,adam-bodnar-przeprosil-osoby-lgbt-za-krzywdy-ze-strony-panstwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T21:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/41/3c/1d/z30658113M,Adam-Bodnar-i-Krzysztof-Smiszek-podczas-spotkania-.jpg" vspace="2" />Minister Adam Bodnar przeprosił organizacje działające na rzecz osĂłb LGBT+ za krzywdę, jaką doznały ze strony polskiego państwa. Szef resortu mĂłwił podczas spotkania w ministerstwie sprawiedliwości o spoczywającej na nim "gigantycznej odpowiedzialności" oraz odniĂłsł się do nowelizacji Kodeksu karnego w zakresie walki z nienawiścią. - Myślę, że nam wszystkim ostatnich osiem lat dało do myślenia - zaznaczał minister Adam Bodnar.

## Kto najwięcej stracił na sprawie Kamińskiego i Wąsika? Padają trzy kluczowe nazwiska [SONDAŻ]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657973,kto-najwiecej-stracil-na-sprawie-kaminskiego-i-wasika-padaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657973,kto-najwiecej-stracil-na-sprawie-kaminskiego-i-wasika-padaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T21:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fb/3c/1d/z30658043M,Andrzej-Duda.jpg" vspace="2" />Sprawą skazanych Mariusza Kamińskiego i Macieja Wąsika żyła cała Polska. Obaj zostali ułaskawieni przez prezydenta Andrzeja Dudę. Co wywołało wiele emocji w całym kraju. Czyj wizerunek najbardziej ucierpiał na zamieszaniu wokĂłł politykĂłw?

## Była wspĂłłpracowniczka Kuchcińskiego usłyszała zarzuty. Chodzi o przywłaszczenie niemal 700 tys. złotych
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657927,byla-wspolpracowniczka-kuchcinskiego-uslyszala-zarzuty-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657927,byla-wspolpracowniczka-kuchcinskiego-uslyszala-zarzuty-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T20:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/db/3c/1d/z30658011M,Lucyna-P--z-dziesiecioma-zarzutami.jpg" vspace="2" />Była wicewojewodzina i była wspĂłłpracowniczka Marka Kuchcińskiego Lucyna P., usłyszała dziesięć zarzutĂłw - poinfomowało w czwartek Radio Lublin. Chodzi między innymi o przywłaszczenie ponad pĂłł miliona złotych.

## "Krzysztof Stanowski ma rozmach". Andrzej Duda w Kanale Zero. "Kryzys politycznej tożsamości"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30657888,krzysztof-stanowski-ma-rozmach-andrzej-duda-w-kanale-zero.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30657888,krzysztof-stanowski-ma-rozmach-andrzej-duda-w-kanale-zero.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T20:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/50/3c/1d/z30657872M,Krzysztof-Stanowski-i-Przemyslaw-Rudzki.jpg" vspace="2" />Krzysztof Stanowski zapowiedział, że pierwszym gościem Kanału Zero będzie Andrzej Duda. "To gruba rzecz, ale i dobry komentarz do kryzysu politycznej tożsamości prezydenta" - skomentował na X redaktor naczelny Gazeta.pl, Rafał Madajczak.

## Grzegorz Braun odzyskał prawa członka Konfederacji. Wipler: To jest trudny związek partnerski
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657873,grzegorz-braun-odzyskal-prawa-czlonka-konfederacji-wipler.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657873,grzegorz-braun-odzyskal-prawa-czlonka-konfederacji-wipler.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T20:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8d/0b/1d/z30453901M,Pierwsze-posiedzenie-Sejmu-X-kadencji.jpg" vspace="2" />Przemysław Wipler poinformował, że Grzegorz Braun odzyskał prawa członka klubu Konfederacji. - Został odwieszony, jest jednym z członkĂłw Rady LiderĂłw Konfederacji. Koniec rozmowy - powiedział zdecydowanie Wipler.

## Jarosław Kaczyński wydał oświadczenie ws. rządĂłw Tuska. "Systemowe bezprawie i destrukcja państwa"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657902,jaroslaw-kaczynski-wydal-oswiadczenie-ws-rzadow-tuska-systemowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657902,jaroslaw-kaczynski-wydal-oswiadczenie-ws-rzadow-tuska-systemowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T19:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/77/3c/1d/z30657911M,Jaroslaw-Kaczynski.jpg" vspace="2" />Jarosław Kaczyński wydał oficjalne oświadczenie ws. "kolejnych krokĂłw rządu Donalda Tuska w kierunku systemowego bezprawia". Prezes PiS oskarża rządzących m.in. o "zamach na media publiczne i atak na niezależną prokuraturę".

## Andrzej Duda udzieli wywiadu Stanowskiemu. "Rozmawiamy z nim, bo jest prezydentem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657881,andrzej-duda-udzieli-wywiadu-stanowskiemu-rozmawiamy-z-nim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657881,andrzej-duda-udzieli-wywiadu-stanowskiemu-rozmawiamy-z-nim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T19:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1a/3b/1d/z30653978M,Andrzej-Duda.jpg" vspace="2" />Prezydent Andrzej Duda udzieli wywiadu Krzysztofowi Stanowskiemu i Robertowi Mazurkowi na start Kanału Zero - poinformował w czwartek wieczorem na YouTubie Stanowski. Wywiad będzie puszczony z odtworzenia.

## Bodnar powołał radę ds. Funduszu Sprawiedliwości. Są znane nazwiska. "Istotny element naprawy państwa"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657746,bodnar-powolal-rade-ds-funduszu-sprawiedliwosci-sa-znane-nazwiska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657746,bodnar-powolal-rade-ds-funduszu-sprawiedliwosci-sa-znane-nazwiska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T19:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/30/3c/1d/z30657840M,Adam-Bodnar-i-Jerzy-Stepien-podczas-uroczystosci-p.jpg" vspace="2" />Minister sprawiedliwości Adam Bodnar powołał Społeczną Radę ds. Funduszu Sprawiedliwości. Bodnar powiedział, że pierwszym zadaniem tego zespołu będzie rozliczenie działalności funduszu w czasie rządĂłw PiS. Wiemy już, kto wszedł w skład rady.

## Węgry w końcu się ugięły ws. Ukrainy. Ekspert: Tym razem Unia Europejska zaszantażowała Orbana
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30657660,wegry-w-koncu-sie-ugiely-ws-ukrainy-ekspert-tym-razem-unia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30657660,wegry-w-koncu-sie-ugiely-ws-ukrainy-ekspert-tym-razem-unia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T19:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9b/3c/1d/z30657691M,Viktor-Orban.jpg" vspace="2" />- Jeśli chodzi o Viktora Orbana, to on długo szantażował. Na poprzednim szczycie UE udało mu się zawetować i zgarnąć sumę ponad 10 mld euro. Tym razem zaszantażowała go Unia Europejska - skomentował czwartkową decyzję UE prof. Bogdan GĂłralczyk w rozmowie Gazeta.pl.

## Anna Maria Wesołowska czuje się "winna dzisiejszej sytuacji" w sądach. ZwrĂłciła się do Barskiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657714,anna-maria-wesolowska-czuje-sie-troche-winna-dzisiejszej-sytuacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657714,anna-maria-wesolowska-czuje-sie-troche-winna-dzisiejszej-sytuacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T19:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/06/3c/1d/z30657798M,Anna-Maria-Wesolowska.jpg" vspace="2" />Anna Maria Wesołowska zabrała głos w sprawie obecnych zmian w polskim sądownictwie. Wspomniała rĂłwnież swoje spotkanie ze Zbigniewem Ziobro i wspĂłłpracę z Dariuszem Barskim. "Stał się pan politykiem, trochę z mojej winy (...). Jeżeli nie jest Pan już prawdziwym prokuratorem, niech pan będzie przynajmniej prawdziwym politykiem" - zwrĂłciła się do Barskiego.

## EURACTIV.pl: Żona Ziobry zatrudniona w Parlamencie Europejskim?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657749,euractiv-pl-zona-ziobry-zatrudniona-w-parlamencie-europejskim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657749,euractiv-pl-zona-ziobry-zatrudniona-w-parlamencie-europejskim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T18:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/64/54/1a/z27607908M,Zbigniew-Ziobro-oraz-Patrycja-Kotecka.jpg" vspace="2" />Patrycja Kotecka-Ziobro będzie doradczynią europosłĂłw z grupy EKR w Parlamencie Europejskim, piszą prawicowe media. Służby prasowe grupy mĂłwią EURACTIV.pl, że nie jest ona zatrudniona w EKR.

## Morawiecki ujawnił zdjęcie z Brukseli i wywołał burzę w sieci. "W jakiej roli pan tam pojechał?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657608,morawiecki-ujawnil-zdjecie-z-brukseli-i-wywolal-burze-w-sieci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657608,morawiecki-ujawnil-zdjecie-z-brukseli-i-wywolal-burze-w-sieci.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T18:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/3c/1d/z30657687M,Mateusz-Morawiecki.jpg" vspace="2" />Mateusz Morawiecki pojawił się w Brukseli w przeddzień nadzwyczajnego szczytu Rady Europejskiej. Spotkał się tam m.in. z premierką Włoch Georgią Meloni, czy szefem węgierskiego rządu Victorem Orbanem. Wiele osĂłb zastanawia się jednak "w jakiej roli" się tam pojawił.

## Obława we Wrocławiu. Policjant użył broni podczas kontroli drogowej "z uwagi na zagrożenie życia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30657443,oblawa-we-wroclawiu-policjant-uzyl-broni-podczas-kontroli-drogowej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30657443,oblawa-we-wroclawiu-policjant-uzyl-broni-podczas-kontroli-drogowej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T16:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/17/3c/1d/z30657559M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Podczas kontroli drogowej we Wrocławiu policjant użył broni służbowej. Poinformowano, że kierowca, ktĂłry został zatrzymany, nagle ruszył w kierunku funkcjonariusza. Mężczyzna uciekł z miejsca zdarzenia, więc mundurowi zorganizowali obławę.

## Obajtek odwołany z Orlenu. PiS ma dla niego nowe stanowisko? "Był wĂłjtem, w tej roli się sprawdził"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657356,obajtek-odwolany-z-orlenu-pis-ma-dla-niego-nowe-stanowisko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657356,obajtek-odwolany-z-orlenu-pis-ma-dla-niego-nowe-stanowisko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T16:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a5/3c/1d/z30657189M,Daniel-Obajtek.jpg" vspace="2" />Zgodnie z komunikatem giełdowym Orlenu Daniel Obajtek został odwołany ze stanowiska prezesa przez radę nadzorczą spĂłłki. Politycy Prawa i Sprawiedliwości zastanawiają się, czym teraz zajmie się Obajtek. - W jakimś sensie był politykiem. Myślę, że by sprawdził się w europarlamencie - stwierdził Bolesław Piecha.

## Donald Tusk komentuje odwołanie Daniela Obajtka. MĂłwi o "pseudopotędze" i "serialu sensacyjnym"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657422,donald-tusk-komentuje-odwolanie-daniela-obajtka-mowi-o-pseudopotedze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657422,donald-tusk-komentuje-odwolanie-daniela-obajtka-mowi-o-pseudopotedze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T16:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/62/3c/1d/z30657378M,Premier-Donald-Tusk-podczas-szczytu-UE-w-Brukseli-.jpg" vspace="2" />Donald Tusk odniĂłsł się do odwołania Daniela Obajtka z funkcji prezesa Orlenu. - Mieliśmy do czynienia z człowiekiem, ktĂłry miał dojścia do władzy, do samego prezesa Kaczyńskiego i dostawał wszystko, co chciał - ocenił premier. Jak dodał, ujawnione w najbliższych dniach informacje, będą "pouczającą lekcją".

## Abp Gądecki spędzi emeryturę w zabytkowym budynku. "Rząd PiS na jego remont dał miliony złotych"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30657105,abp-gadecki-spedzi-emeryture-w-zabytkowym-budynku-rzad-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30657105,abp-gadecki-spedzi-emeryture-w-zabytkowym-budynku-rzad-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T16:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f9/3c/1d/z30657273M,Abp-Stanislaw-Gadecki--metropolita-poznanski.jpg" vspace="2" />Abp Stanisław Gądecki ma spędzić emeryturę w zabytkowej kanonii na poznańskim Ostrowie Tumskim. Budynek ten jest obecnie poddawany remontowi dzięki dotacji z publicznego budżetu - ustaliła "Gazeta Wyborcza". Lokalni duchowni są niezadowoleni, że pieniądze przeznaczono na odnowę budynku dla arcybiskupa, gdy mniejsze parafie mierzą się z poważnymi problemami. - Szkoda, że nawet w Kościele są rĂłwni i rĂłwniejsi - mĂłwił z rozgoryczeniem jeden z proboszczĂłw.

## Turcja. Media: Terrorysta wziął zakładnikĂłw w fabryce pod Stambułem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30657462,turcja-terrorysci-wzieli-zakladnikow-w-fabryce-pod-stambulem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30657462,turcja-terrorysci-wzieli-zakladnikow-w-fabryce-pod-stambulem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T16:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0e/3c/1d/z30657550M,Atak-na-fabryke-Procter-and-Gamble-w-Turcji.jpg" vspace="2" />W Turcji niezidentyfikowany mężczyzna wziął kilku zakładnikĂłw w fabryce amerykańskiego koncernu Procter&amp;Gamble koło Stambułu. "Policja prĂłbuje nakłonić napastnika do uwolnienia zakładnikĂłw" - przekazał turecki oddział BBC.

## Tusk złożył propozycję Dudzie. Chce transmisji Rady Gabinetowej w telewizji, "żeby nie było domysłĂłw"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657310,tusk-zlozyl-propozycje-dudzie-chce-transmisji-rady-gabinetowej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657310,tusk-zlozyl-propozycje-dudzie-chce-transmisji-rady-gabinetowej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T15:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/77/3c/1d/z30657399M,Donald-Tusk.jpg" vspace="2" />- Byłbym usatysfakcjonowany, jakby Rada Gabinetowa była transmitowana we wszystkich telewizjach - powiedział Donald Tusk. Premier podkreślił, że dzięki relacji na żywo "byłoby jasne, kto, o czym debatuje". Decyzja w tej sprawie należy do Andrzeja Dudy.

## Władysław Kosiniak-Kamysz odgryza się za "tygryska". Nie poleca prezesowi PiS "rumakować"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657047,wladyslaw-kosiniak-kamysz-odgryza-sie-za-tygryska-nie-poleca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30657047,wladyslaw-kosiniak-kamysz-odgryza-sie-za-tygryska-nie-poleca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T15:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d6/3b/1d/z30653654M,Wladyslaw-Kosiniak-Kamysz.jpg" vspace="2" />Jarosław Kaczyński na spotkaniu z sympatykami nazwał Władysława Kosiniaka-Kamysza "tygryskiem". Lider PSL po raz kolejny zareagował na słowa prezesa PiS. - Nie polecałbym tak ostro rumakować - ocenił.

## Trybunał Konstytucyjny zareagował na decyzję Bodnara ws. sędziego Schaba. "Stawię się w pracy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30656974,trybunal-konstytucyjny-zareagowal-na-decyzje-bodnara-ws-sedziego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30656974,trybunal-konstytucyjny-zareagowal-na-decyzje-bodnara-ws-sedziego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T15:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/23/3c/1d/z30657315M,Sedzia-Piotr-Schab.jpg" vspace="2" />Trybunał Konstytucyjny (TK) zawiesił tymczasowo decyzję Ministerstwa Sprawiedliwości dotyczącą zawieszenia prezesa Sądu Apelacyjnego w Warszawie Piotra Schaba. To postanowienie TK ma obowiązywać do wydania przez niego ostatecznej decyzji w tej sprawie.

## Wiceszef MON: Zwołanie Rady Gabinetowej to polityczna gra Andrzeja Dudy. "PrĂłba przetrwania PiS"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30656779,wiceszef-mon-zwolanie-rady-gabinetowej-to-polityczna-gra-andrzeja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30656779,wiceszef-mon-zwolanie-rady-gabinetowej-to-polityczna-gra-andrzeja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T14:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/85/3c/1d/z30657157M,Cezary-Tomczyk.jpg" vspace="2" />- Zwołanie Rady Gabinetowej to element gry politycznej, ktĂłrą prowadzi Andrzej Duda - twierdzi Cezary Tomczyk. Wiceszef MON uważa, że rozmowa prezydenta z członkami Rady MinistrĂłw ma służyć interesom PiS.

## Policja poszukuje 4-letniej Alicji i 3-letniego Marcela. Ojciec nie odwiĂłzł ich do matki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30657167,policja-poszukuje-4-letniej-alicji-i-3-letniego-marcela-ojciec.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30657167,policja-poszukuje-4-letniej-alicji-i-3-letniego-marcela-ojciec.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T14:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/92/3c/1d/z30657170M,4-letnia-Alicja-i-3-letni-Marcel-Watorscy.jpg" vspace="2" />Policja w Limanowej poszukuje rodzeństwa - 4-letniej Alicji i 3-letniego Marcela Wątorskich. Dzieci nie wrĂłciły z wizyty u ojca.

## Wybory prezydenckie 2025. Trzaskowski nadal liderem. Goni go dwĂłch kandydatĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30656413,trzaskowski-nadal-liderem-wyscigu-prezydenckiego-w-2025-r-goni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30656413,trzaskowski-nadal-liderem-wyscigu-prezydenckiego-w-2025-r-goni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T14:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/3c/1d/z30656601M,Wybory-parlamentarne-2023.jpg" vspace="2" />Nie dwĂłch, ale trzech politykĂłw powalczy o wejście do drugiej tury wyborĂłw prezydenckich w Polsce w 2025 roku - wynika z najnowszego sondażu IBRiS dla Onetu. Marszałek Sejmu Szymon Hołownia zyskuje poparcie kosztem prezydenta Warszawy Rafała Trzaskowskiego, a w stawce liczy się jeszcze kandydat prawicy.

## Spektakularny atak ukraińskich żołnierzy. Zniszczyli rosyjski okręt o wartości 70 mln dolarĂłw [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30656363,spektakularny-atak-ukrainskich-zolnierzy-zniszczyli-rosyjski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30656363,spektakularny-atak-ukrainskich-zolnierzy-zniszczyli-rosyjski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T14:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5c/3c/1d/z30656860M,Rosyjski-okret-o-wartosci-70-mln-dolarow-zniszczon.jpg" vspace="2" />Rosyjski okręt rakietowy "Iwanowiec" został zniszczony przez UkraińcĂłw. "Korweta została uszkodzona, przewrĂłcona na rufę i zatonęła" - poinformowało Ministerstwo Obrony Ukrainy. Wartość okrętu szacowana jest na 70 mln dolarĂłw.

## Chiny. Stracono parę za zabĂłjstwo dzieci. Wyrzucili je z 15. piętra
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30656219,chiny-stracono-pare-za-zabojstwo-dzieci-wyrzucili-je-z-15.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30656219,chiny-stracono-pare-za-zabojstwo-dzieci-wyrzucili-je-z-15.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T13:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/45/3c/1d/z30656581M,Chiny--zdjecie-ilustracyjne-.jpg" vspace="2" />Zhang Bo i jego partnerka Ye Chengchen zostali w środę (31 stycznia) straceni. W 2021 roku sąd wymierzył im najwyższą możliwą karę za zabĂłjstwo dwĂłjki małych dzieci z poprzedniego małżeństwa mężczyzny.

## Dziwny żart Obajtka. Prowadzący nie wierzył w to, co słyszy. "MĂłwi pan poważnie?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30656354,dziwny-zart-obajtka-prowadzacy-nie-wierzyl-w-to-co-slyszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30656354,dziwny-zart-obajtka-prowadzacy-nie-wierzyl-w-to-co-slyszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T13:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/36/3c/1d/z30656054M.jpg" vspace="2" />Co Daniel Obajtek będzie robił po tym, jak przestanie być prezesem Orlenu? - Będę robił montaż finansowy, by kupić TVN - powiedział na antenie Radia ZET. Dziennikarz nie mĂłgł w to uwierzyć, ale jego rozmĂłwca w końcu przyznał, że "żartuje".

## Justyna Dobrosz-Oracz wrĂłciła do TVP. Już na wstępie odgryzła się posłance PiS. "Kręgosłup nietknięty" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30655903,justyna-dobrosz-oracz-wrocila-do-tvp-juz-na-wstepie-odgryzla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30655903,justyna-dobrosz-oracz-wrocila-do-tvp-juz-na-wstepie-odgryzla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T13:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1d/22/1d/z30549789M,Justyna-Dobrosz-Oracz.jpg" vspace="2" />Justyna Dobrosz-Oracz po latach ponownie pojawiła się na antenie Telewizji Polskiej. Dziennikarka poprowadziła program "Gość poranka" w TVP Info. Prowadząca już na wstępie odgryzła się posłance PiS Teresie Pamuli, ktĂłra wcześniej skrytykowała Macieja Orłosia.

## Duda marionetką Kaczyńskiego? Dziennikarz Gazeta.pl: Oni nawet ze sobą nie rozmawiają
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30656129,duda-marionetka-kaczynskiego-dziennikarz-gazeta-pl-oni-nawet.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30656129,duda-marionetka-kaczynskiego-dziennikarz-gazeta-pl-oni-nawet.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T12:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/31/83/1c/z29898033M,Andrzej-Duda-i-Jaroslaw-Kaczynski.jpg" vspace="2" />"Widać koordynację prezydenta Andrzeja Dudy i byłego premiera Mateusza Morawieckiego" - stwierdził Jacek Gądek, odnosząc się do wygłoszonego w czwartek oświadczenia głowy państwa. "Nie ma za to koordynacji prezydenta z prezesem PiS Jarosławem Kaczyńskim" - komentuje dziennikarz Gazeta.pl.

## Nerwowo w Orlenie. PrzyjaciĂłłka Kaczyńskiego do dziennikarza: Odejdź młodzieńcze
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30655863,nerwowo-w-orlenie-przyjaciolka-kaczynskiego-do-dziennikarza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30655863,nerwowo-w-orlenie-przyjaciolka-kaczynskiego-do-dziennikarza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T12:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/41/3c/1d/z30656065M.jpg" vspace="2" />Janina Goss, zwana często "szarą eminencją PiS", uczestniczyła w spotkaniu w siedzibie Orlenu, podczas ktĂłrego ogłoszono odwołanie Daniela Obajtka. Nie była jednak skora do rozmowy z dziennikarzami. Zapytana o to, w jakim charakterze przyszła, odpowiedziała krĂłtko, ale stanowczo: "Gościa, a bo co?".

## Karnista wprost o decyzjach Andrzeja Dudy. "Prezydent się obraził i gra w jakąś grę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655249,karnista-wprost-o-decyzjach-andrzeja-dudy-prezydent-sie-obrazil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655249,karnista-wprost-o-decyzjach-andrzeja-dudy-prezydent-sie-obrazil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T11:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f3/3c/1d/z30655731M.jpg" vspace="2" />- Prezydent tutaj bez podstaw merytorycznych, wbrew orzeczeniom sądu, wbrew konstytucji zapowiada, że zamierza paraliżować proces legislacyjny w Polsce - ocenił karnista dr Mikołaj Małecki w rozmowie z Gazetą.pl. W ten sposĂłb ocenił decyzję prezydenta o skierowaniu ustawy budżetowej w trybie kontroli do Trybunału Konstytucyjnego po jej podpisaniu.

## Duda zwołuje Radę Gabinetową. "Prezydent będzie udawał, że to coś znaczy" [KOMENTARZE]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655779,duda-zwoluje-rade-gabinetowa-prezydent-bedzie-udawal-ze-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655779,duda-zwoluje-rade-gabinetowa-prezydent-bedzie-udawal-ze-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T11:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1a/3b/1d/z30653978M,Andrzej-Duda.jpg" vspace="2" />"Nie ma koordynacji prezydenta z prezesem PiS Jarosławem Kaczyńskim. Oni nawet ze sobą nie rozmawiają" - napisał Jacek Gądek z Gazeta.pl, komentując oświadczenie Andrzeja Dudy, podczas ktĂłrego polityk ogłosił zwołanie Rady Gabinetowej. "Prezydent będzie udawał, że to coś znaczy" - stwierdziła z kolei dziennikarka Dominika Długosz.

## Trzaskowski ma w Warszawie poważną rywalkę? Dotarliśmy do głośnego sondażu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655227,trzaskowski-ma-w-warszawie-powazna-rywalke-dotarlismy-do-glosnego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655227,trzaskowski-ma-w-warszawie-powazna-rywalke-dotarlismy-do-glosnego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T11:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/63/d9/1c/z30250851M,Donald-Tusk-i-Rafal-Trzaskowski-ma-scenie-na-Marsz.jpg" vspace="2" />Magdalena Biejat ma szansę na 11 proc. w wyborach prezydenckich w Warszawie - sugerowała w tym tygodniu posłanka Lewicy Anna Maria Żukowska. Gazeta.pl dotarła do szczegĂłłĂłw tego sondażu. Dotyczył on wyborĂłw do Rady Miasta, a wynik ten nie musi przełożyć się na wybory włodarza miasta.

## Pilne oświadczenie Dudy po podpisaniu ustawy budżetowej. Wezwał do siebie Tuska
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655281,oswiadczenie-prezydenta-andrzeja-dudy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655281,oswiadczenie-prezydenta-andrzeja-dudy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T10:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c0/3a/1d/z30649536M,Andrzej-Duda.jpg" vspace="2" />- Wczoraj podjąłem decyzję o podpisaniu ustawy budżetowej i przesłaniu jej do publikacji. Tak też się stało. Ustawa budżetowa niedługo wejdzie w życie. Chcę wyrazić satysfakcję, że rząd będzie mĂłgł realizować te zobowiązania, ktĂłre podjął i wpisał do ustaw- powiedział Andrzej Duda podczas swojego wtorkowego oświadczenia. Wcześniej o planowanym przemĂłwieniu informowała Kancelaria Prezydenta. Andrzej Duda przekazał także, że postanowił zwołać Radę Gabinetową w sprawie kontynuacji inwestycji, takich jak CPK czy elektrownia atomowa.

## Viktor Orban się ugiął. Jest przełomowe porozumienie Unii Europejskiej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30655528,orban-sie-ugial-jest-przelomowe-porozumienie-unii-europejskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30655528,orban-sie-ugial-jest-przelomowe-porozumienie-unii-europejskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T10:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/3c/1d/z30655845M,Viktor-Orban.jpg" vspace="2" />Jest porozumienie unijnych przywĂłdcĂłw w sprawie pomocy dla Ukrainy. Chodzi o 50 miliardĂłw euro do 2027 roku - poinformował szef Rady Europejskiej Charles Michel. Tę informację przekazała nam jako pierwsza Jowita Kiwnik Pargana z jedennewsdziennie.pl.

## Podtopienia na Mazowszu. Jak wygląda sytuacja na Bugu? Jest odpowiedź Straży Pożarnej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30655294,jak-wyglada-sytuacja-na-bugu-jest-odpowiedz-strazy-pozarnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30655294,jak-wyglada-sytuacja-na-bugu-jest-odpowiedz-strazy-pozarnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T10:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dd/3c/1d/z30655453M,Zalane-miejscowosci-w-powiecie-wyszkowskim.jpg" vspace="2" />W ostatnich dniach dramatycznie wzrĂłsł poziom wody na Bugu. Mieszkańcy okolicznych miejscowości zmagali się z zalaniami i podtopieniami. Teraz Straż Pożarna w Ostrowi Mazowieckiej uspokaja. - Jeżeli chodzi o poziom wody, to cały czas jest on monitorowany. Jest on poniżej stanu ostrzegawczego, co napawa optymizmem - przekazał nam t. kpt. Łukasz Jary.

## Sakiewicz przeprasza Budkę za manipulację "Gazety Polskiej". "Ależ to ich musi boleć!"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655066,sakiewicz-przeprasza-budke-za-manipulacje-gazety-polskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30655066,sakiewicz-przeprasza-budke-za-manipulacje-gazety-polskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T10:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/3a/1d/z30649399M,Minister-aktywow-panstwowych-Borys-Budka.jpg" vspace="2" />Tomasz Sakiewicz przeprosił Borysa Budkę za "nieprawdę i manipulację", ktĂłra została opublikowana na łamach "Gazety Polskiej". "Ależ to ich musi boleć!" - ucieszył się minister aktywĂłw państwowych.

## Wąsik grozi Hołowni i Tuskowi. "Przyjdzie kiedyś za to zapłacić"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654833,wasik-grozi-marszalkowi-sejmu-i-premierowi-przyjdzie-kiedys.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654833,wasik-grozi-marszalkowi-sejmu-i-premierowi-przyjdzie-kiedys.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T09:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/33/3c/1d/z30655027M,Wasik-grozi-marszalkowi-Sejmu-i-premierowi---Przyj.jpg" vspace="2" />Skazany i ułaskawiony Maciej Wąsik ciągle twierdzi, że jest posłem, powołując się na orzeczenie nieuznawanej Izby Kontroli Nadzwyczajnej i Spraw Publicznych Sądu Najwyższego. Ignoruje wyrok sądu i orzeczenie Izby Pracy i Ubezpieczeń Społecznych SN. I grozi marszałkowi Sejmu i premierowi.

## Tusk o decyzji Dudy ws. budżetu: Prezydent źle zaczął prezydenturę i źle ją kończy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654985,tusk-o-decyzji-dudy-ws-budzetu-prezydent-zle-zaczal-prezydenture.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654985,tusk-o-decyzji-dudy-ws-budzetu-prezydent-zle-zaczal-prezydenture.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T09:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/3b/1d/z30651426M,Konferencja-prasowa-premiera-Donalda-Tuska.jpg" vspace="2" />- Nie rozumiem postępowania prezydenta, bo ono przynosi same ryzyka. Dla prezydenta, ale i dla całej ojczyzny. Stawianie ponad interes państwa, ponad interes ludzi kwestię panĂłw Kamińskiego i Wąsika, kwestię rozstrzygnięcia, jest rzeczą absolutnie nie do zaakceptowania - stwierdził Donald Tusk podczas briefingu prasowego w Brukseli. OdniĂłsł się także do zapowiedzi Andrzeja Dudy o kierowaniu wszystkich ustaw w trybie kontroli następczej do Trybunału Konstytucyjnego.

## Mateusz Morawiecki o "starej" TVP: Telewizję publiczną można było prowadzić inaczej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654644,mateusz-morawiecki-o-starej-tvp-telewizje-publiczna-mozna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654644,mateusz-morawiecki-o-starej-tvp-telewizje-publiczna-mozna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T09:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c1/2c/1d/z30590145M,Mateusz-Morawiecki.jpg" vspace="2" />Mateusz Morawiecki w rozmowie z portalem Business Insider Polska stwierdził, że telewizję publiczną za czasĂłw Jacka Kurskiego można było prowadzić inaczej. Były premier skrytykował także politykę obecnie rządzących, ktĂłrą uznał za "destrukcyjną dla Polski". - To, co oni wyprawiają, to nie jest mĂłj styl, można powiedzieć, że brzydzę się takimi metodami uprawiania polityki - podkreślił.

## Nieoficjalnie: Rządzący mają plan na odbicie TK. Prezydent się nie zgodzi? "Nie ma problemu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654710,nieoficjalnie-rzadzacy-maja-plan-na-odbicie-tk-prezydent-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654710,nieoficjalnie-rzadzacy-maja-plan-na-odbicie-tk-prezydent-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T09:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/01/23/16/z23215873M,Prezydent-Andrzej-Duda-i-prezes-Trybunalu-Konstytu.jpg" vspace="2" />Rządzący mają plan na usunięcie z Trybunału Konstytucyjnego sędziĂłw-dublerĂłw oraz byłych parlamentarzystĂłw PiS - ustalił Onet. Mają już mieć gotowe ustawy. Co jeśli prezydent nie zgodzi się ich podpisać? - Nie ma problemu - podkreślił informator portalu.

## Tusk uderza w Orbana: Nie ma tu miejsca na kompromis. "Myślę, że nie ma planu B"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654904,tusk-uderza-w-orbana-nie-ma-tu-miejsca-na-kompromis-mysle.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654904,tusk-uderza-w-orbana-nie-ma-tu-miejsca-na-kompromis-mysle.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T08:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/3b/1d/z30651426M,Konferencja-prasowa-premiera-Donalda-Tuska.jpg" vspace="2" />- W Brukseli mamy zmęczenie Orbanem - powiedział Donald Tusk dziennikarzom. - Nie jestem w stanie pojąć tego bardzo dziwnego, egoistycznego sposobu rozgrywania gry przez Viktora Orbana. Nie ma tu miejsca na kompromis. Nie ma miejsca na kompromis, jeśli chodzi o Ukrainę - dodał.

## Duda ma wątpliwości do ustawy budżetowej, a Kamiński i Wąsik? Nieoficjalnie: Mają plan na obrady Sejmu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654600,duda-ma-watpliwosci-do-ustawy-budzetowej-a-kaminski-i-wasik.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654600,duda-ma-watpliwosci-do-ustawy-budzetowej-a-kaminski-i-wasik.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T08:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/33/32/1d/z30615859M,Mariusz-Kaminski-i-Maciej-Wasik.jpg" vspace="2" />Prezydent Andrzej Duda nadal uważa, że skazani prawomocnym wyrokiem i ułaskawieni przez niego Mariusz Kamiński i Maciej Wąsik są posłami. W związku z tym ustawę budżetową - przegłosowaną bez udziału byłych szefĂłw CBA - prezydent skierował do Trybunału Konstytucyjnego. Ta decyzja ma ośmielić politykĂłw PiS, ktĂłrzy mają już plan na następne posiedzenie Sejmu - wynika z nieoficjalnych doniesień medialnych.

## Wypadek "na dużą skalę" na lotnisku. Są zabici i ranni w stanie krytycznym
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30654632,wypadek-na-duza-skale-na-lotnisku-sa-zabici-i-ranni-w-stanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30654632,wypadek-na-duza-skale-na-lotnisku-sa-zabici-i-ranni-w-stanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T07:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f1/3c/1d/z30654705M,Wypadek--na-duza-skale--na-lotnisku--Sa-zabici-i-r.jpg" vspace="2" />Na lotnisku w Boise w stanie Idaho zawalił się hangar będący w budowie. Zginęły trzy osoby, a dziewięć zostało rannych. Stan pięciu poszkodowanych jest krytyczny.

## Orkan Igunn uderzył w pĂłłnocną Europę. Wiatr przekroczył 185 km/h. W Polsce pomarańczowe alerty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30654550,orkan-igunn-uderzyl-w-polnocna-europe-wiatr-przekroczyl-185.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30654550,orkan-igunn-uderzyl-w-polnocna-europe-wiatr-przekroczyl-185.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T07:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8d/3c/1d/z30654605M,Silne-wichury-na-wybrzezu--IMGW-wydal-pomaranczowe.jpg" vspace="2" />Mieszkańcy pĂłłnocnych krańcĂłw Polski odczują skutki potężnego orkanu Igunn, ktĂłry uderzył w Skandynawię. Miejscami wiatr zawieje z prędkością około 90 km/h. W związku z silnym wiatrem Instytut Meteorologii i Gospodarki wodnej wydał ostrzeżenia pierwszego i drugiego stopnia.

## BĂłj o Kamińskiego i Wąsika. Szef IBRiS o sprytnej operacji Kaczyńskiego: Postawił sobie cel
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654557,boj-o-kaminskiego-i-wasika-szef-ibris-o-sprytnej-operacji-kaczynskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654557,boj-o-kaminskiego-i-wasika-szef-ibris-o-sprytnej-operacji-kaczynskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T07:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4a/3c/1d/z30654538M,Prezes-PiS-Jaroslaw-Kaczynski-podczas-konwencji-wo.jpg" vspace="2" />- PiS się tego spokoju swojego elektoratu przestraszył. (...) Kaczyński postawił sobie cel: obudzić ich i sprawić, by zerwali się z foteli. - stwierdził szef IBRiS Marcin Duma w rozmowie z naTemat. Jak podkreślił, właśnie dlatego wybuchła awantura z "więźniami politycznymi" po aresztowaniu Mariusza Kamińskiego i Macieja Wąsika.

## Śmierć 14-latki z Andrychowa. Jest kara dla policjanta. W jednostce przeprowadzono kontrolę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30654566,smierc-14-latki-z-andrychowa-policjant-dostal-kare-dyscyplinarna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30654566,smierc-14-latki-z-andrychowa-policjant-dostal-kare-dyscyplinarna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T07:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/48/31/1d/z30610504M,Miejsce-odnalezienia-14-latki-w-Andrychowie.jpg" vspace="2" />Jeden z policjantĂłw związanych ze sprawą śmierci 14-letniej Natalii z Andrychowa został ukarany dyscyplinarnie - informuje RMF FM. W listopadzie media w całej Polsce pisały o tragicznej historii nastolatki, ktĂłra przez kilka godzin czekała na pomoc pod jednym ze sklepĂłw.

## Karnowski o decyzji Andrzeja Dudy: Prezydent jest w stanie podpalić to państwo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654326,poranna-rozmowa-gazeta-pl-gosciem-jacek-karnowski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654326,poranna-rozmowa-gazeta-pl-gosciem-jacek-karnowski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T07:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3d/3c/1d/z30654781M,Andrzej-Duda--zdjecie-ilustracyjne-.jpg" vspace="2" />- Prezydent jest w stanie podpalić to państwo, tylko po to, aby udowodnić, że miał rację w 2015 roku, ułaskawiając Mariusza Kamińskiego i Macieja Wąsika - mĂłwił w "Porannej rozmowie Gazeta.pl" Jacek Karnowski pytany o skierowanie przez Andrzeja Dudę ustawy budżetowej do Trybunału Konstytucyjnego. Polityk Koalicji Obywatelskiej podkreślił, że zachowanie Andrzeja Dudy może mieć niebezpieczne konsekwencje.

## Czy Polska powinna strzelać do rosyjskich dronĂłw i rakiet? Polacy odpowiedzieli [SONDAŻ]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30654553,czy-polska-powinna-strzelac-do-rosyjskich-dronow-i-rakiet-polacy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30654553,czy-polska-powinna-strzelac-do-rosyjskich-dronow-i-rakiet-polacy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T07:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/16/f8/1c/z30379030M,Prezentacja-systemu-Mala-Narew-w-Warszawie.jpg" vspace="2" />Czy Polska powinna uruchomić obronę powietrzną przy granicy z Ukrainą i strzelać do rosyjskich dronĂłw i rakiet? Takie pytanie zadano Polakom w najnowszym sondażu IBRiS dla "Rzeczpospolitej". Odpowiedź prawie 70 procent osĂłb nie pozostawia żadnych wątpliwości.

## Ruszyła kwalifikacja wojskowa. Armia zaprasza w swoje szeregi cytatem z filmowego hitu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30654539,ruszyla-kwalifikacja-wojskowa-armia-zaprasza-w-swoje-szeregi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30654539,ruszyla-kwalifikacja-wojskowa-armia-zaprasza-w-swoje-szeregi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T06:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/98/2d/1d/z30594712M,Wojsko--zdjecie-ilustracyjne-.jpg" vspace="2" />Zgodnie z zarządzeniem ministra obrony narodowej od 1 lutego do 30 kwietnia potrwa tegoroczna kwalifikacja wojskowa. Wezwanie do stawienia się przed komisją dostanie ok. 230 tysięcy PolakĂłw. Jak wygląda kwalifikacja wojskowa?

## Neo-sędzia związany z Ziobrą komentuje decyzję Andrzeja Dudy ws. budżetu. "Pocałunek śmierci"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654518,sedzia-sadu-najwyzszego-komentuje-decyzje-andrzeja-dudy-ws.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654518,sedzia-sadu-najwyzszego-komentuje-decyzje-andrzeja-dudy-ws.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T05:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/17/3b/1d/z30653975M,Andrzej-Duda.jpg" vspace="2" />"To pocałunek śmierci dla TK" - tak sędzia Sądu Najwyższego Kamil Zaradkiewicz skomentował decyzję Andrzeja Dudy ws. ustawy budżetowej. Prezydent podpisał ją i skierował do Trybunału Konstytucyjnego w trybie kontroli następczej.

## Roman Giertych o Funduszu Sprawiedliwości: "Ogromny przekręt". Poseł KO chce śledztwa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654149,roman-giertych-o-funduszu-sprawiedliwosci-to-jest-ogromny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30654149,roman-giertych-o-funduszu-sprawiedliwosci-to-jest-ogromny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T05:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6e/32/1d/z30615406M,Roman-Giertych.jpg" vspace="2" />Inspektorzy Najwyższej Izby Kontroli negatywnie ocenili działanie Funduszu Sprawiedliwości za czasĂłw ministra Zbigniewa Ziobry. - Wiele milionĂłw naszych pieniędzy zamiast na pomoc ofiarom przestępstwa poszły do jakichś lewych fundacji, ktĂłre są powiązane rodzinnie z tymi, ktĂłrzy je dawali. To jest po prostu gigantyczny skandal - skomentował wyniki kontroli Roman Giertych.

## Strzelanina w szpitalu na Zachodnim Brzegu. Izraelscy komandosi weszli do budynku w przebraniach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30654072,strzelanina-w-szpitalu-na-zachodnim-brzegu-izraelscy-komandosi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30654072,strzelanina-w-szpitalu-na-zachodnim-brzegu-izraelscy-komandosi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T04:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/29/3b/1d/z30654249M,Operacja-izraelskich-sluzb-w-szpitalu-na-Zachodnim.jpg" vspace="2" />Uzbrojeni izraelscy komandosi weszli do szpitala w Dżaninie w przebraniach lekarzy i osĂłb cywilnych, a następnie zastrzelili trzech PalestyńczykĂłw powiązanych z grupami terrorystycznymi. Siły Obronne Izraela przekazały mediom, że nie chcą dopuścić, by placĂłwki medyczne stały się kryjĂłwką dla terrorystĂłw. Operację potępiły władze szpitala oraz palestyński resort zdrowia.

## Horoskop dzienny - czwartek 1 lutego [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30652498,horoskop-dzienny-czwartek-1-lutego-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30652498,horoskop-dzienny-czwartek-1-lutego-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2024-02-01T04:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/75/3b/1d/z30650997M,Horoskop-na-czwartek.jpg" vspace="2" />Horoskop dzienny - 1 lutego - dla wszystkich znakĂłw zodiaku. Przed nami nowy miesiąc i kolejne wyzwania. Co przyniesie czwartek? Nie zwlekaj, sprawdź.

