# Source:Digital Trends, URL:https://www.digitaltrends.com/news/rss, language:en-US

## We have some good news about AMD’s next massive CPU launch
 - [https://www.digitaltrends.com/computing/amd-zen-5-coming-in-2024](https://www.digitaltrends.com/computing/amd-zen-5-coming-in-2024)
 - RSS feed: https://www.digitaltrends.com/news/rss
 - date published: 2024-02-01T13:27:00.798941+00:00

AMD has just confirmed that it's ready to launch Zen 5 processors this year. What can we expect, and how will it compare to Intel?

