# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## NFL's Kelce Brothers Want To Bring Back Your Fave Childhood Game
 - [https://kotaku.com/backyard-football-baseball-game-travis-jason-kelce-nfl-1851218390](https://kotaku.com/backyard-football-baseball-game-travis-jason-kelce-nfl-1851218390)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T22:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/e98e058b2e0ca69de878e8e9f79d5d1d.jpg" /><p>Omnipresent brothers, Travis and Jason <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/travis-kelce-tweets-gamer-goldeneye-taylor-swift-1851028994">Kelce</a> (who are NFL players, commercial stars, SNL hosts, podcasters, and members of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/how-warframe-players-got-taylor-swift-lyrics-etched-per-1821967690">Taylor Swift</a>’s inner circle) are looking to add a game development feather to their caps—specifically, they want to reboot ‘90s classics <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/five-strangest-football-games-1785820670">Backyard Football</a> and Backyard Baseball. Whether or not…</p><p><a href="https://kotaku.com/backyard-football-baseball-game-travis-jason-kelce-nfl-1851218390">Read

## I Will Be Love Bombing My Friends With Final Fantasy XIV’s New Emote
 - [https://kotaku.com/final-fantasy-xiv-valentiones-day-love-heart-emote-1851217811](https://kotaku.com/final-fantasy-xiv-valentiones-day-love-heart-emote-1851217811)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/8524051e540edf0a912c3599daa3a3cf.jpg" /><p>If there’s one thing I’m going to do in <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/final-fantasy-16-dawntrail-job-classes-free-trial-xbox-1850691863">Final Fantasy XIV</a>, it’s endlessly spam emotes at all of my friends while we stand around in the middle of the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/did-you-know-that-ffxiv-has-a-jail-for-very-bad-players-1786679403">Limsa Lominsa</a> Aetheryte Plaza. But there’s only so many times I can /pet, /cheer, or /lalihop before it gets old. Thankfully, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/square-enix-president-artificial-intelligence-ai-games-1851133573">Square Enix</a> is delivering unto players a…</p><p><a href="https://kotaku.com/final-fantasy-xiv-valentiones-day-love-

## The Best Early Pals In Palworld—And What To Do First
 - [https://kotaku.com/palworld-starting-best-pals-base-tutorial-1851217830](https://kotaku.com/palworld-starting-best-pals-base-tutorial-1851217830)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T21:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/68a3423de6404843103634cc63bf4fe4.jpg" /><p>Open-world survival game Palworld lets you explore the world and craft away at your own pace, tending to your survival needs and your crafting goals as you like. But of course, there are always some best practices. And when it comes to the game’s early moments, you’ll want to find the right Pals for the job and gather…</p><p><a href="https://kotaku.com/palworld-starting-best-pals-base-tutorial-1851217830">Read more...</a></p>

## Patrick Stewart Uses Hey Arnold Star As A Football In New Super Bowl Ad
 - [https://kotaku.com/paramount-super-bowl-ad-patrick-stewart-hey-arnold-toss-1851217677](https://kotaku.com/paramount-super-bowl-ad-patrick-stewart-hey-arnold-toss-1851217677)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T20:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/50a03c09f4ccc0de55f37060aeb2a121.jpg" /><p>I didn’t expect to check Twitter or X or whatever today and see a Super Bowl advertisement featuring Patrick Stewart, Master Chief, Arnold from Hey, Arnold!, the band Creed, Knuckles from the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/the-sonic-the-hedgehog-movie-is-a-little-weird-but-mos-1841623974">Sonic franchise</a>, and Survivor host Jeff Probst. Yet, folks, here we are. Welcome to 2024. It sucks. </p><p><a href="https://kotaku.com/paramount-super-bowl-ad-patrick-stewart-hey-arnold-toss-1851217677">Read more...</a></p>

## 23 Years Later, GTA III's Influence Is Still Inescapable
 - [https://kotaku.com/gta-3-rockstar-games-jak-ii-simpsons-hit-and-run-1851217338](https://kotaku.com/gta-3-rockstar-games-jak-ii-simpsons-hit-and-run-1851217338)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/854218c334ccffe01c40ab23bcb3dbca.jpg" /><p><a href="https://kotaku.com/gta-3-rockstar-games-jak-ii-simpsons-hit-and-run-1851217338">Read more...</a></p>

## Surprise: The Game Awards Breakout Metroidvania Zau Now Has A Demo
 - [https://kotaku.com/tales-kenzera-zau-pc-steam-free-surprise-demo-1851217538](https://kotaku.com/tales-kenzera-zau-pc-steam-free-surprise-demo-1851217538)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4bff9b65dc7ca6b434c38723373ff18a.jpg" /><p>It’s Black History Month, y’all, which means it’s time to uplift anything and everything connected to the African diaspora. And whoa, would you look at that! Coinciding with the first day of this celebratory and historic month is a free Steam demo for Tales of Kenzera: Zau, a stunning side-scrolling Metroidvania that…</p><p><a href="https://kotaku.com/tales-kenzera-zau-pc-steam-free-surprise-demo-1851217538">Read more...</a></p>

## Suicide Squad’s First 12 Hours Include Great Action, But A Lot Of Filler
 - [https://kotaku.com/suicide-squad-first-hours-impressions-review-is-it-good-1851217153](https://kotaku.com/suicide-squad-first-hours-impressions-review-is-it-good-1851217153)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T19:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/8903b7c3ca94cdd336fd6dbe06a8188f.jpg" /><p>Suicide Squad: Kill The Justice League isn’t the game a lot of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/batman-arkham-knight-the-kotaku-re-review-1791829083">Arkham</a> fans wanted. It’s also yet another live-service video game, something that folks are less and less excited about with each passing year. And it’s not had <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/suicide-squad-justice-league-preview-is-it-bad-gameplay-1851152615">great previews</a> or trailers. But, I’ve enjoyed <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/suicide-squad-game-alpha-test-nda-lifted-rocksteady-dc-1851160646">Rocksteady</a>’s past games a lot and the idea of…</p><p><a href="https://kotaku.com/suicide-squad-first-hours-impressions-review-is-it-go

## Sonic X Shadow Generations Is Beating Sonic Porn In SEO, For Now
 - [https://kotaku.com/sonic-x-shadow-generations-sonadow-ship-1851217156](https://kotaku.com/sonic-x-shadow-generations-sonadow-ship-1851217156)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/3fb8f53e043969bfec9e4d86fe74c1a2.jpg" /><p>Did you know there is a large portion of the Sonic the Hedgehog fandom that ships the blue blur with his black-and-red rival Shadow? The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.distractify.com/p/what-is-a-golden-retriever-boyfriend" rel="noopener noreferrer" target="_blank">golden retriever boyfriend and black cat boyfriend</a> dynamic apparently stirs something in people. If you weren’t aware of the Sonadow ship, you, and likely many others, are about to…</p><p><a href="https://kotaku.com/sonic-x-shadow-generations-sonadow-ship-1851217156">Read more...</a></p>

## ‘The Helmet’s Still Gonna Come Off’ In Halo Season 2, EP Says
 - [https://kotaku.com/halo-tv-series-season-2-interview-cast-show-paramount-1851216994](https://kotaku.com/halo-tv-series-season-2-interview-cast-show-paramount-1851216994)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T19:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/bcc7e08798ae409b864ca0d158cf1ae5.jpg" /><p>I might be in the minority, but I <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/halo-series-season-2-trailer-reach-review-show-1851160308">enjoyed</a> the first season of the Paramount+ <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/halo-show-season-2-1-free-paramount-plus-1851070370">Halo TV series</a>. Though it stumbled at times, I appreciated its attempts to flesh out characters like franchise lead Master Chief John-117, expand upon well-established Halo lore, and give us more than just a video game retrofitted into an…</p><p><a href="https://kotaku.com/halo-tv-series-season-2-interview-cast-show-paramount-1851216994">Read more...</a></p>

## Everything We Know About Zenless Zone Zero
 - [https://kotaku.com/zenless-zone-zero-release-date-trailer-platforms-story-1851216949](https://kotaku.com/zenless-zone-zero-release-date-trailer-platforms-story-1851216949)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T18:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/2d2e8be808fbdb6c64f6a1e523b25351.jpg" /><p>Ever since HoYoverse released <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/genshin-impact-hoyoverse-year-in-review-2022-1849905304">Genshin Impact</a> in 2020, the developer has been on a winning streak. Major updates of Genshin Impact have continuously delivered interesting story expansions and new characters. Then 2023’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/honkai-star-rail-rpg-genshin-impact-characters-tips-1850483026">Honkai: Star Rail</a> showed HoYoverse could replicate its success with a sci-fi turn-based RPG. Heading…</p><p><a href="https://kotaku.com/zenless-zone-zero-release-date-trailer-platforms-story-1851216949">Read more...</a></p>

## This Early Suicide Squad Sequence Is A Brilliant Nod To The Arkham Games
 - [https://kotaku.com/suicide-squad-batman-arkham-museum-scene-hunting-1851216708](https://kotaku.com/suicide-squad-batman-arkham-museum-scene-hunting-1851216708)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/9f3b9828c9ee843bd1347f0e18068713.jpg" /><p>Rocksteady’s new co-op looter-shooter, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/suicide-squad-kill-justice-league-preorder-servers-1851211653">Suicide Squad: Kill The Justice League</a>, might not be the Batman sequel many fans wanted, but an early section of the game does offer some Arkham-like action. But this time, you are the ones being hunted by a powerful superhero hiding in the shadows. </p><p><a href="https://kotaku.com/suicide-squad-batman-arkham-museum-scene-hunting-1851216708">Read more...</a></p>

## 26 Things To Know Before Starting Persona 3 Reload
 - [https://kotaku.com/persona-3-reload-tips-social-links-theurgy-builds-stats-1851216475](https://kotaku.com/persona-3-reload-tips-social-links-theurgy-builds-stats-1851216475)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T17:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/54dce28113dcccd1ab73fedf291d9d1c.jpg" /><p>It can be tough figuring out how to manage everything Persona 3 Reload throws at you. Between school life, social life, and fighting demonic shadows during the Dark Hour, your time in Gekkoukan High School is hectic, to say the least. So whether you’re returning to Persona 3 or playing it for the first time via the…</p><p><a href="https://kotaku.com/persona-3-reload-tips-social-links-theurgy-builds-stats-1851216475">Read more...</a></p>

## Kotaku’s Most Anticipated Games Of 2024
 - [https://kotaku.com/2024-video-games-release-ff7-rebirth-star-wars-ps5-xbox-1850972294](https://kotaku.com/2024-video-games-release-ff7-rebirth-star-wars-ps5-xbox-1850972294)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T17:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4a959bd574010e9326a2e38179bcb25f.jpg" /><p>This story is part of our new <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/report/future-of-gaming" target="_blank">Future of Gaming</a> series, a three-site look at gaming’s most pioneering technologies, players, and makers.</p><p><a href="https://kotaku.com/2024-video-games-release-ff7-rebirth-star-wars-ps5-xbox-1850972294">Read more...</a></p>

## Silent Hill: The Short Message Has Me Worried For The Franchise’s Future
 - [https://kotaku.com/silent-hill-the-short-message-playstation-is-a-bore-1851216442](https://kotaku.com/silent-hill-the-short-message-playstation-is-a-bore-1851216442)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/0d890e69fdc25abcd98aa891c68b7352.jpg" /><p>The announcement during last night’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/state-of-play-january-2024-death-stranding-silent-hill-1851214689">State of Play</a> that a new entry in the Silent Hill franchise was out now and available for free immediately brought to mind the legendary <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/p-t-hacker-is-still-finding-gruesome-secrets-1838489446">P.T.</a> demo. Sadly, the intrigue <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/silent-hill-short-message-free-on-ps5-now-1851214476">Silent Hill: The Short Message</a> stoked during its trailer never pays off after playing through the entirety of this…</p><p><a href="https://kotaku.com/silent-hill-the-short-message-playstation-is-a-bore-18512164

## The Absolute Best Fast-Food Movie Tie-Ins
 - [https://kotaku.com/fast-food-toys-glasses-retro-star-wars-pokemon-1851216074](https://kotaku.com/fast-food-toys-glasses-retro-star-wars-pokemon-1851216074)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T15:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/415a4fa51fed093d19c9bfb9069d338b.png" /><p>Remember fast-food kids meals with specially marketed pop culture toys? They just don’t make ‘em like they used to. In the 1990s, Taco Bell, KFC, Pizza Hut, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/loki-season-2-marvel-mcdonalds-ad-with-tom-hiddleston-1850735341">McDonald’s</a>, and Burger King often chose chaos with their tie-ins, like the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/tubi-warner-bros-dc-movies-series-streaming-free-ads-1851092801">Batman Forever</a> glass mugs or the Hercules plates. Heck, even when big event films like…</p><p><a href="https://kotaku.com/fast-food-toys-glasses-retro-star-wars-pokemon-1851216074">Read more...</a></p>

## Dune: Part Two Popcorn Bucket Is The Stuff Of Nightmares
 - [https://kotaku.com/dune-2-popcorn-bucket-sandworm-1851215982](https://kotaku.com/dune-2-popcorn-bucket-sandworm-1851215982)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T15:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/7727317e2533465aaab77ea256a52c83.png" /><p>Everything about the moviegoing experience <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/spirit-halloween-horror-decor-klowns-chainsaw-scream-1850719662">is merchandisable</a>, and long has been. But the rising trend of increasingly complex and elaborate collectible popcorn buckets might have finally reached the apex with <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/dune-2-trailer-timothee-chalamet-zendaya-warner-bros-1851092841">Dune: Part Two</a>, which invites you to place your hand in a very different kind of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/dunes-calculating-bene-gesserit-are-a-most-precious-res-1847938940">Gom Jabbar test</a>.</p><p><a href="https://kotaku.com/dune-2-popcorn-bucket-sandworm-1851215982">Read mor

## Death Stranding On The Beach In 16 Wild Images
 - [https://kotaku.com/death-stranding-2-on-the-beach-images-screenshots-1851214583](https://kotaku.com/death-stranding-2-on-the-beach-images-screenshots-1851214583)
 - RSS feed: https://kotaku.com/rss
 - date published: 2024-02-01T14:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/b518ff05c0f9e9d5cdf379a938fc6464.jpg" /><p>Sony’s January 31 <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/playstation-state-of-play-how-watch-expect-january-2024-1851206244">State of Play</a> gave hungry gamers a heaping helping of upcoming titles to drool over, including the long-awaited <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/silent-hill-2-remake-trailer-release-date-bloober-ps5-1850839903">Silent Hill 2</a> remake and deeper dives into <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/rise-of-the-ronin-release-date-game-awards-trailer-1851085777">Rise of the Ronin</a> and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/stellar-blade-release-date-bunny-outfit-1851214532">Stellar Blade</a>. But the biggest reveal of the evening came wit

