# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## So I Went On Tucker And This Happened...
 - [https://www.youtube.com/watch?v=3S4sxugBmA8](https://www.youtube.com/watch?v=3S4sxugBmA8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2024-02-01T18:29:50+00:00

I went to talk to Tucker Carlson about recent events and the media attacks against me. 

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

