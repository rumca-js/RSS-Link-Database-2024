# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## LibreOffice 24.2 is Here!
 - [https://news.itsfoss.com/libreoffice-24-2-is-here](https://news.itsfoss.com/libreoffice-24-2-is-here)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2024-02-01T12:53:06+00:00

A packed LibreOffice upgrade has arrived with a new version naming scheme.

