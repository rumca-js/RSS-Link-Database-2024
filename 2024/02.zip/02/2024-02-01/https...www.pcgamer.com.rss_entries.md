# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## The PC game releases we're most excited about in February
 - [https://www.pcgamer.com/february-2024-pc-game-release-dates](https://www.pcgamer.com/february-2024-pc-game-release-dates)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T22:38:46+00:00

Plus events, updates, and other PC gaming happenings to look out for this month.

## We thought Death Stranding was Peak Kojima, but Death Stranding 2 already looks like it's scaling new heights of his personal WTF mountain
 - [https://www.pcgamer.com/we-thought-death-stranding-was-peak-kojima-but-death-stranding-2-already-looks-like-its-scaling-new-heights-of-his-personal-wtf-mountain](https://www.pcgamer.com/we-thought-death-stranding-was-peak-kojima-but-death-stranding-2-already-looks-like-its-scaling-new-heights-of-his-personal-wtf-mountain)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T22:37:41+00:00

The new Kojima game looks mad as a hatter? You don't say.

## Inkle reveals a surprise collaboration with Google in The Forever Labyrinth, 'an art-filled quest through time and space'
 - [https://www.pcgamer.com/inkle-reveals-a-surprise-collaboration-with-google-in-the-forever-labyrinth-an-art-filled-quest-through-time-and-space](https://www.pcgamer.com/inkle-reveals-a-surprise-collaboration-with-google-in-the-forever-labyrinth-an-art-filled-quest-through-time-and-space)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T22:35:28+00:00

The new game is a free-to-play search for a missing professor (and a whole lot more) that runs in a browser.

## Devolver Digital's new CEO is its old CEO
 - [https://www.pcgamer.com/devolver-digitals-new-ceo-is-its-old-ceo](https://www.pcgamer.com/devolver-digitals-new-ceo-is-its-old-ceo)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T20:42:48+00:00

Douglas Morin, who took on the CEO role in 2021, will be replaced by Devolver co-founder and executive chairman Harry Miller.

## PC Gamer Chat Log Episode 46: The Steam Deck squad is here
 - [https://www.pcgamer.com/pc-gamer-chat-log-episode-46-the-steam-deck-squad-is-here](https://www.pcgamer.com/pc-gamer-chat-log-episode-46-the-steam-deck-squad-is-here)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T18:03:12+00:00

Tyler Colp joins Mollie and Lauren to talk all about the Steam Deck.

## Passively cooling an RTX 3080 FE with 10 CPU coolers makes it look like a steampunk spaceship, and I'm a fan
 - [https://www.pcgamer.com/passively-cooling-an-rtx-3080-fe-with-10-cpu-coolers-makes-it-look-like-a-steampunk-spaceship-and-im-a-fan](https://www.pcgamer.com/passively-cooling-an-rtx-3080-fe-with-10-cpu-coolers-makes-it-look-like-a-steampunk-spaceship-and-im-a-fan)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T17:38:06+00:00

Wildly impractical? Check. Fantastic to look at? Also check.

## Gary Bowser, charged with paying Nintendo a sum he'll never be able to afford, talks about his life after prison: 'The sentence was like a message to other people'
 - [https://www.pcgamer.com/gary-bowser-charged-with-paying-nintendo-a-sum-hell-never-be-able-to-afford-talks-about-his-life-after-prison-the-sentence-was-like-a-message-to-other-people](https://www.pcgamer.com/gary-bowser-charged-with-paying-nintendo-a-sum-hell-never-be-able-to-afford-talks-about-his-life-after-prison-the-sentence-was-like-a-message-to-other-people)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T17:28:51+00:00

"I’ll pay them what I can, which won’t be very much money, that’s for sure."

## Fake Palworld mobile apps could lead to data leaks or fraud, Pocketpair warns: 'There is no Palworld application for phones'
 - [https://www.pcgamer.com/fake-palworld-mobile-apps-could-lead-to-data-leaks-or-fraud-pocketpair-warns-there-is-no-palworld-application-for-phones](https://www.pcgamer.com/fake-palworld-mobile-apps-could-lead-to-data-leaks-or-fraud-pocketpair-warns-there-is-no-palworld-application-for-phones)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T17:16:34+00:00

It's no surprise that a number of mobile developers are looking to take advantage of the popularity of Palworld.

## Palworld has now sold a staggering 19 million copies, an unstoppable rise that means it's got a bigger population than the Netherlands
 - [https://www.pcgamer.com/palworld-has-now-sold-a-staggering-19-million-copies-an-unstoppable-rise-that-means-its-got-a-bigger-population-than-the-netherlands](https://www.pcgamer.com/palworld-has-now-sold-a-staggering-19-million-copies-an-unstoppable-rise-that-means-its-got-a-bigger-population-than-the-netherlands)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T17:15:30+00:00

But fewer Poffertjes.

## The Day Before was an even bigger disaster than you thought: devs reportedly made to pay fines for bad work, learned it was an MMO from the trailers, and no one's sure where the bosses are
 - [https://www.pcgamer.com/the-day-before-was-an-even-bigger-disaster-than-you-thought-devs-reportedly-made-to-pay-fines-for-bad-work-learned-it-was-an-mmo-from-the-trailers-and-no-ones-sure-where-the-bosses-are](https://www.pcgamer.com/the-day-before-was-an-even-bigger-disaster-than-you-thought-devs-reportedly-made-to-pay-fines-for-bad-work-learned-it-was-an-mmo-from-the-trailers-and-no-ones-sure-where-the-bosses-are)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T17:05:05+00:00

Less than Fntastic.

## Penny's Big Breakaway makes me wish I'd spent more time playing platformers before Penny's Big Breakaway
 - [https://www.pcgamer.com/pennys-big-breakaway-makes-me-wish-id-spent-more-time-playing-platformers-before-pennys-big-breakaway](https://www.pcgamer.com/pennys-big-breakaway-makes-me-wish-id-spent-more-time-playing-platformers-before-pennys-big-breakaway)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T17:00:32+00:00

I think this "going fast" thing is really going to catch on.

## Kill whole camps of cultists with a single bullet in this psychic and psychedelic puzzle shooter
 - [https://www.pcgamer.com/kill-whole-camps-of-cultists-with-a-single-bullet-in-this-psychic-and-psychedelic-puzzle-shooter](https://www.pcgamer.com/kill-whole-camps-of-cultists-with-a-single-bullet-in-this-psychic-and-psychedelic-puzzle-shooter)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T16:17:44+00:00

Children of the Sun is a mind-bending combo of action movie flash and backwoods madness.

## Dredge dev says a mechanic that killed NPCs without warning if you let them go hungry lasted for about 3 days after the game's launch before they patched it out, because 'people f*cking hated it'
 - [https://www.pcgamer.com/dredge-dev-says-a-mechanic-that-killed-npcs-without-warning-if-you-let-them-go-hungry-lasted-for-about-3-days-after-the-games-launch-before-they-patched-it-out-because-people-fcking-hated-it](https://www.pcgamer.com/dredge-dev-says-a-mechanic-that-killed-npcs-without-warning-if-you-let-them-go-hungry-lasted-for-about-3-days-after-the-games-launch-before-they-patched-it-out-because-people-fcking-hated-it)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T16:14:27+00:00

The background timer was "the number one source of negative Steam reviews."

## Avowed's game director says Obsidian's choice to limit players to just two races is partially down to its first-person camera
 - [https://www.pcgamer.com/avoweds-game-director-says-obsidians-choice-to-limit-players-to-just-two-races-is-partially-down-to-its-first-person-camera](https://www.pcgamer.com/avoweds-game-director-says-obsidians-choice-to-limit-players-to-just-two-races-is-partially-down-to-its-first-person-camera)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T16:02:04+00:00

"One of the things [that's] easier to account for in an isometric game is just the variation in sizes."

## City-wide Wi-Fi networks spanning literal miles could soon be possible thanks to 'HaLow' devices
 - [https://www.pcgamer.com/city-wide-wi-fi-networks-spanning-literal-miles-could-soon-be-possible-thanks-to-halow-devices](https://www.pcgamer.com/city-wide-wi-fi-networks-spanning-literal-miles-could-soon-be-possible-thanks-to-halow-devices)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T15:21:21+00:00

Long range Wi-Fi looks like it might be on its way, with some impressive interference rejection to boot.

## Palworld glitch lets you carry 9,999 of anything like a legally distinct Sisyphus hauling pal spheres up a mountain
 - [https://www.pcgamer.com/palworld-glitch-lets-you-carry-9999-of-anything-like-a-legally-distinct-sisyphus-hauling-pal-spheres-up-a-mountain](https://www.pcgamer.com/palworld-glitch-lets-you-carry-9999-of-anything-like-a-legally-distinct-sisyphus-hauling-pal-spheres-up-a-mountain)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T15:10:41+00:00

And it's still live after the latest patch.

## Ray tracing made possible on 42-year-old ZX Spectrum: 'reasonably fast, if you consider 17 hours per frame to be reasonably fast'
 - [https://www.pcgamer.com/ray-tracing-made-possible-on-42-year-old-zx-spectrum-reasonably-fast-if-you-consider-17-hours-per-frame-to-be-reasonably-fast](https://www.pcgamer.com/ray-tracing-made-possible-on-42-year-old-zx-spectrum-reasonably-fast-if-you-consider-17-hours-per-frame-to-be-reasonably-fast)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T14:26:30+00:00

The 1980s computer produces surprisingly gorgeous ray-traced results, but be prepared to measure performance by hour rather than second.

## Palworld update fixes save-bricking capture bug, permanently-nerfing respec juice, and Pals randomly levitating or dying to 'unexplained falling damage'
 - [https://www.pcgamer.com/palworld-update-fixes-save-bricking-capture-bug-permanently-nerfing-respec-juice-and-pals-randomly-levitating-or-dying-to-unexplained-falling-damage](https://www.pcgamer.com/palworld-update-fixes-save-bricking-capture-bug-permanently-nerfing-respec-juice-and-pals-randomly-levitating-or-dying-to-unexplained-falling-damage)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T13:04:08+00:00

Pocketpair's Pal patches are proceeding apace.

## Kurt Russell gives thoughtful and nuanced answer about why he wouldn't voice Snake in Metal Gear Solid 3, also seems to think the character is actually Snake Plissken
 - [https://www.pcgamer.com/kurt-russell-gives-thoughtful-and-nuanced-answer-about-why-he-wouldnt-voice-snake-in-metal-gear-solid-3-also-seems-to-think-the-character-is-actually-snake-plissken](https://www.pcgamer.com/kurt-russell-gives-thoughtful-and-nuanced-answer-about-why-he-wouldnt-voice-snake-in-metal-gear-solid-3-also-seems-to-think-the-character-is-actually-snake-plissken)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T12:58:15+00:00

"I'm a movie guy."

## Deep Rock Galactic and Dwarf Fortress call on their fans for a Steam revolution: a new dwarf tag to unite the games under one label
 - [https://www.pcgamer.com/deep-rock-galactic-and-dwarf-fortress-call-on-their-fans-for-a-steam-revolution-a-new-dwarf-tag-to-unite-the-games-under-one-label](https://www.pcgamer.com/deep-rock-galactic-and-dwarf-fortress-call-on-their-fans-for-a-steam-revolution-a-new-dwarf-tag-to-unite-the-games-under-one-label)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T12:27:34+00:00

"Strike the Earth! Rock and stone!"

## This 9.5g gaming mouse is so small I'd be worried about inhaling it, cable and all
 - [https://www.pcgamer.com/this-95g-gaming-mouse-is-so-small-id-be-worried-about-inhaling-it-cable-and-all](https://www.pcgamer.com/this-95g-gaming-mouse-is-so-small-id-be-worried-about-inhaling-it-cable-and-all)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T12:12:25+00:00

The smollest boi, a mini-meese, a tiny rodent of insignificant heft.

## Wizards of the Coast dispels rumours that Tencent wants to gobble up D&D like a tarrasque: 'To be clear: We are not looking to sell our D&D IP'
 - [https://www.pcgamer.com/wizards-of-the-coast-dispels-rumours-that-tencent-wants-to-gobble-up-dandd-like-a-tarrasque-to-be-clear-we-are-not-looking-to-sell-our-dandd-ip](https://www.pcgamer.com/wizards-of-the-coast-dispels-rumours-that-tencent-wants-to-gobble-up-dandd-like-a-tarrasque-to-be-clear-we-are-not-looking-to-sell-our-dandd-ip)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T12:12:05+00:00

5th-level Banish Rumour (Abjuration). Casting time: 1 Action. Components: Verbal, Material (A single public statement).

## Redditor who posts 'I've got everything I need' alongside bare room with mattress and gaming PC ends up on CBS panel show: 'Come on, we've all dated that guy'
 - [https://www.pcgamer.com/redditor-who-posts-ive-got-everything-i-need-alongside-bare-room-with-mattress-and-gaming-pc-ends-up-on-cbs-panel-show-come-on-weve-all-dated-that-guy](https://www.pcgamer.com/redditor-who-posts-ive-got-everything-i-need-alongside-bare-room-with-mattress-and-gaming-pc-ends-up-on-cbs-panel-show-come-on-weve-all-dated-that-guy)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T11:52:41+00:00

"What kind of neanderthal goes through life without a second monitor?!"

## Weird, niche mods make PC gaming great, and these ones prove it
 - [https://www.pcgamer.com/weird-niche-mods-make-pc-gaming-great-and-these-ones-prove-it](https://www.pcgamer.com/weird-niche-mods-make-pc-gaming-great-and-these-ones-prove-it)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T11:12:00+00:00

If I can't play Guitar Hero as Barack Obama what's even the point?

## PC Gamer magazine's new issue is on sale now: League of Legends
 - [https://www.pcgamer.com/pc-gamer-magazines-new-issue-is-on-sale-now-league-of-legends](https://www.pcgamer.com/pc-gamer-magazines-new-issue-is-on-sale-now-league-of-legends)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T10:10:11+00:00

Plus: Pacific Drive, Against the Storm, GTA, Escape from Tarkov: Arena, United 1944, Solium Infernum, Total War: Warhammer III, top new GPUs tested, and much more!

## Wordle today: Hint and answer #957 for Thursday, February 1
 - [https://www.pcgamer.com/wordle-today-answer-957-february-1](https://www.pcgamer.com/wordle-today-answer-957-february-1)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T04:04:07+00:00

Help with today's Wordle if you need it.

## Everything cool I noticed in the new Death Stranding 2 trailer after sinking 150 hours into the first Death Stranding
 - [https://www.pcgamer.com/everything-cool-i-noticed-in-the-new-death-stranding-2-trailer-after-sinking-150-hours-into-the-first-death-stranding](https://www.pcgamer.com/everything-cool-i-noticed-in-the-new-death-stranding-2-trailer-after-sinking-150-hours-into-the-first-death-stranding)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T01:49:06+00:00

Exciting news for backpack sickos ahead.

## Wayfinder studio Airship Syndicate says layoffs are necessary to ensure it 'can continue to operate and deliver great experiences'
 - [https://www.pcgamer.com/wayfinder-studio-airship-syndicate-says-layoffs-are-necessary-to-ensure-it-can-continue-to-operate-and-deliver-great-experiences](https://www.pcgamer.com/wayfinder-studio-airship-syndicate-says-layoffs-are-necessary-to-ensure-it-can-continue-to-operate-and-deliver-great-experiences)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T00:38:56+00:00

The studio confirmed that 12 developers have been let go, while the company president and CEO have taken pay cuts.

## Diablo 4's little robot spider is actually an apex predator who can solo bosses, and it's about to get even stronger
 - [https://www.pcgamer.com/diablo-4s-little-robot-spider-is-actually-an-apex-predator-who-can-solo-bosses-and-its-about-to-get-even-stronger](https://www.pcgamer.com/diablo-4s-little-robot-spider-is-actually-an-apex-predator-who-can-solo-bosses-and-its-about-to-get-even-stronger)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T00:24:58+00:00

Season 3's companion is much stronger than everyone thought.

## Pokimane's main reason for leaving Twitch: 'So much manosphere, red pill bull****'
 - [https://www.pcgamer.com/pokimane-leaving-twitch-podcast](https://www.pcgamer.com/pokimane-leaving-twitch-podcast)
 - RSS feed: https://www.pcgamer.com/rss
 - date published: 2024-02-01T00:09:02+00:00

The ex-Twitch star isn't going exclusive elsewhere, will instead stream all over the place.

