# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## I Will (Winter Serenade) The Piano Guys
 - [https://www.youtube.com/watch?v=dSv0g6hXfnE](https://www.youtube.com/watch?v=dSv0g6hXfnE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2024-02-01T13:00:36+00:00

Join us for a heartfelt performance of 'I Will,' a Beatles classic, featuring a piano cover by Jon and the sweet vocals of his daughter Annie. This live recording captures the simplicity and warmth of the song, reflecting a special father-daughter collaboration. We hope this rendition touches your heart as it did ours. Thank you for tuning in, and if you enjoy this unique cover, please feel free to subscribe and share your thoughts in the comments. Your support means a lot to us.

Download the Album "Winter Serenade" https://thepianoguys.com/products/winter-serenade

👉 Subscribe to our channel https://bit.ly/2XH4GCF for more heartwarming melodies that capture the spirit of the season. 

WE’RE ON TOUR: https://smarturl.it/the10tour 
Learn about our beliefs: https://smarturl.it/TPG_Beliefs

🌐 Connect with us:
📸 Instagram: https://instagram.com/thepianoguys
📘 Facebook: https://facebook.com/ThePianoGuys
🐦 Tiktok: https://tiktok.com/@thepianoguys 
🌟 Website: https://thepianoguys.c

