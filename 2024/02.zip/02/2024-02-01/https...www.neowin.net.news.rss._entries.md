# Source:Neowin, URL:https://www.neowin.net/news/rss/, language:en-us

## Amazon launches its AI-powered shopping assistant Rufus
 - [https://www.neowin.net/news/amazon-launches-its-ai-powered-shopping-assistant-rufus](https://www.neowin.net/news/amazon-launches-its-ai-powered-shopping-assistant-rufus)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T22:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706823884_unnamed_medium.jpg" /></div>Amazon has launched its AI assistant, Rufus, to help customers navigate the online shopping process. It has been trained on Amazon&#039;s product data to answer questions, make recommendations, and more. <a href="https://www.neowin.net/news/amazon-launches-its-ai-powered-shopping-assistant-rufus">Read more...</a>

## Call of Duty: Modern Warfare III and Warzone Season 2 details revealed; launching Feb. 7
 - [https://www.neowin.net/news/call-of-duty-modern-warfare-iii-and-warzone-season-2-details-revealed-launching-feb-7](https://www.neowin.net/news/call-of-duty-modern-warfare-iii-and-warzone-season-2-details-revealed-launching-feb-7)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T20:48:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706818664_mwiii-s2-announcement-001a_medium.jpg" /></div>Activision has revealed all the new content that will be added to Call of Duty: Modern Warfare III and Warzone as part of the Season 2 update on Feb. 7, with new maps, locations, and much more. <a href="https://www.neowin.net/news/call-of-duty-modern-warfare-iii-and-warzone-season-2-details-revealed-launching-feb-7">Read more...</a>

## Windows 10 users report broken apps on old computers
 - [https://www.neowin.net/news/windows-10-users-report-broken-apps-on-old-computers](https://www.neowin.net/news/windows-10-users-report-broken-apps-on-old-computers)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T20:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706819478_broken_windows_10_medium.jpg" /></div>It appears that Windows 10 users with older PC hardware are not having a good time running the latest updates. A lengthy thread on Microsoft forums reveals a number of customers with broken programs. <a href="https://www.neowin.net/news/windows-10-users-report-broken-apps-on-old-computers">Read more...</a>

## Microsoft launches preview of Intel Neural Processor Unit (NPU) support for its DirectML API
 - [https://www.neowin.net/news/microsoft-launches-preview-of-intel-neural-processor-unit-npu-support-for-its-directml-api](https://www.neowin.net/news/microsoft-launches-preview-of-intel-neural-processor-unit-npu-support-for-its-directml-api)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T19:08:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1702569943_intel_core_ultra_5_medium.jpg" /></div>Microsoft has released a developer preview of its DirectML 1.13.1 API. It adds Neural Processor Unit (NPU) support, specifically for Intel&#039;s Core Ultra  CPUs which have integrated NPU chips <a href="https://www.neowin.net/news/microsoft-launches-preview-of-intel-neural-processor-unit-npu-support-for-its-directml-api">Read more...</a>

## Google's YouTube Music and Premium services have now surpassed 100 million users
 - [https://www.neowin.net/news/googles-youtube-music-and-premium-services-have-now-surpassed-100-million-users](https://www.neowin.net/news/googles-youtube-music-and-premium-services-have-now-surpassed-100-million-users)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T18:26:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/03/1584987746_youtube_premium_medium.jpg" /></div>Google announced today that the total worldwide subscriber numbers for its YouTube Music and YouTube Premium services have surpassed the 100 million mark. That number does include free trials. <a href="https://www.neowin.net/news/googles-youtube-music-and-premium-services-have-now-surpassed-100-million-users">Read more...</a>

## Microsoft fixes DWM crash, makes Windows 11 more reliable with KB5034220 Beta build
 - [https://www.neowin.net/news/microsoft-fixes-dwm-crash-makes-windows-11-more-reliable-with-kb5034220-beta-build](https://www.neowin.net/news/microsoft-fixes-dwm-crash-makes-windows-11-more-reliable-with-kb5034220-beta-build)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T18:15:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701731494_windows_11_insider_preview_promo_5_medium.jpg" /></div>Microsoft has released a new Windows 11 Beta Build 22635.3139 under KB5034220 today for Insiders. With this new build, Microsoft brings general reliability improvements, DWM crash fix, and more. <a href="https://www.neowin.net/news/microsoft-fixes-dwm-crash-makes-windows-11-more-reliable-with-kb5034220-beta-build">Read more...</a>

## Apple announces over 600 apps and games for Vision Pro just before launch
 - [https://www.neowin.net/news/apple-announces-over-600-apps-and-games-for-vision-pro-just-before-launch](https://www.neowin.net/news/apple-announces-over-600-apps-and-games-for-vision-pro-just-before-launch)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T18:10:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706808073_apple-vision-pro-app-experiences-house-of-the-dragon_big.jpg.large_medium.jpg" /></div>Apple announced more than 600 new apps will be available when the Vision Pro is released on February 2. The headset features a 3D interface that can be accessed through eye tracking and gestures. <a href="https://www.neowin.net/news/apple-announces-over-600-apps-and-games-for-vision-pro-just-before-launch">Read more...</a>

## Microsoft Office 2019 for Windows or Mac Price Dropped to just $29.97
 - [https://www.neowin.net/deals/microsoft-office-home--business-2019-for-mac-price-dropped-to-just-2997](https://www.neowin.net/deals/microsoft-office-home--business-2019-for-mac-price-dropped-to-just-2997)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T18:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2018/09/1537811766_office2019-2_medium.jpg" /></div>Save big and pick up Word, Excel, PowerPoint, Outlook, Teams, and OneNote! Get all these essential Microsoft apps for Windows or Mac for next to nothing, just classic apps that don&#039;t expir <a href="https://www.neowin.net/deals/microsoft-office-home--business-2019-for-mac-price-dropped-to-just-2997">Read more...</a>

## Artificial Intelligence in Practice eBook (worth $24) free for your email
 - [https://www.neowin.net/sponsored/artificial-intelligence-in-practice-ebook-worth-24-free-for-your-email](https://www.neowin.net/sponsored/artificial-intelligence-in-practice-ebook-worth-24-free-for-your-email)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T17:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706796417_w_wile497c82_medium.jpg" /></div>An insightful and informative exploration of the transformative power of technology in 21st century commerce. This time-limited free to download offer expires, Feb 6. Grab it today for free. <a href="https://www.neowin.net/sponsored/artificial-intelligence-in-practice-ebook-worth-24-free-for-your-email">Read more...</a>

## Indie puzzle game 'Doors: Paradox' is free to claim on the Epic Games Store this week
 - [https://www.neowin.net/news/indie-puzzle-game-doors-paradox-is-free-to-claim-on-the-epic-games-store-this-week](https://www.neowin.net/news/indie-puzzle-game-doors-paradox-is-free-to-claim-on-the-epic-games-store-this-week)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T16:46:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706805030_doors_medium.jpg" /></div>Doors: Paradox is the latest free game to drop from the Epic Games Store, a puzzle game where you solve intricate 3D dioramas to continue your journey through time. It&#039;s free to claim for seven days. <a href="https://www.neowin.net/news/indie-puzzle-game-doors-paradox-is-free-to-claim-on-the-epic-games-store-this-week">Read more...</a>

## Age of Empires IV: Anniversary Edition is free-to-play this weekend for all Xbox members
 - [https://www.neowin.net/news/age-of-empires-iv-anniversary-edition-is-free-to-play-this-weekend-for-all-xbox-members](https://www.neowin.net/news/age-of-empires-iv-anniversary-edition-is-free-to-play-this-weekend-for-all-xbox-members)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T16:34:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/08/1692729746_maxresdefault_6_medium.jpg" /></div>Microsoft has announced that all Xbox members can play Age of Empires IV: Anniversary Edition for free, without the need for an Xbox Game Pass subscription, as part of Free Play Days. <a href="https://www.neowin.net/news/age-of-empires-iv-anniversary-edition-is-free-to-play-this-weekend-for-all-xbox-members">Read more...</a>

## Google launches new AI image-generation model ImageFX, brings updates to MusicFX and TextFX
 - [https://www.neowin.net/news/google-launches-new-ai-image-generation-model-imagefx-brings-updates-to-musicfx-and-textfx](https://www.neowin.net/news/google-launches-new-ai-image-generation-model-imagefx-brings-updates-to-musicfx-and-textfx)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T16:22:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706802703_imagefx2_medium.jpg" /></div>Google has introduced a new image-generation model called the ImageFX, powered by Imagen 2, which helps generate high-quality images using prompts. It also shared improvements to other AI tools. <a href="https://www.neowin.net/news/google-launches-new-ai-image-generation-model-imagefx-brings-updates-to-musicfx-and-textfx">Read more...</a>

## Bootable Windows on ReFS still not ready for prime time due to lack of wider compatibility
 - [https://www.neowin.net/news/bootable-windows-on-refs-still-not-ready-for-prime-time-due-to-lack-of-wider-compatibility](https://www.neowin.net/news/bootable-windows-on-refs-still-not-ready-for-prime-time-due-to-lack-of-wider-compatibility)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T16:14:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/12/1701875886_windows_medium.jpg" /></div>Microsoft began adding ReFS Windows bootability support early last year. While some progress was gradually being made over the course of the year, the needle hasn&#039;t moved much since around August. <a href="https://www.neowin.net/news/bootable-windows-on-refs-still-not-ready-for-prime-time-due-to-lack-of-wider-compatibility">Read more...</a>

## Save $1000 on the 55" Samsung Odyssey Ark 2nd Gen 4K UHD Curved Gaming Screen today
 - [https://www.neowin.net/deals/save-1000-on-the-55-samsung-odyssey-ark-2nd-gen-4k-uhd-curved-gaming-screen-today](https://www.neowin.net/deals/save-1000-on-the-55-samsung-odyssey-ark-2nd-gen-4k-uhd-curved-gaming-screen-today)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T16:04:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706795595_odyssey_ark_2nd_gen_medium.jpg" /></div>Today, you can get your hands on the Samsung 55-inch Odyssey Ark 2nd Gen 4K UHD 1000R Curved Gaming Screen, which is selling at its lowest price with a huge discount of $1000 on its original MSRP. <a href="https://www.neowin.net/deals/save-1000-on-the-55-samsung-odyssey-ark-2nd-gen-4k-uhd-curved-gaming-screen-today">Read more...</a>

## The Google Bard chatbot has Gemini Pro support worldwide and an updated Imagen 2 model
 - [https://www.neowin.net/news/the-google-bard-chatbot-has-gemini-pro-support-worldwide-and-an-updated-imagen-2-model](https://www.neowin.net/news/the-google-bard-chatbot-has-gemini-pro-support-worldwide-and-an-updated-imagen-2-model)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T15:52:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/05/1683741159_bard_medium.jpg" /></div>Google has announced some updates to its Bard AI chatbot, including support for the Gemini Pro large language model and an updated Imagen 2 model for more advanced image generation. <a href="https://www.neowin.net/news/the-google-bard-chatbot-has-gemini-pro-support-worldwide-and-an-updated-imagen-2-model">Read more...</a>

## Statcounter: Windows 11 market share jumps to 27.83%
 - [https://www.neowin.net/news/statcounter-windows-11-market-share-jumps-to-2783](https://www.neowin.net/news/statcounter-windows-11-market-share-jumps-to-2783)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T15:36:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1693596832_windows_logos_medium.jpg" /></div>Windows 11 increased its market share to nearly 28%, according to Statcounter. In January 2024, it continued its slow but steady climb, getting closer to Windows 10 with its 66% market share. <a href="https://www.neowin.net/news/statcounter-windows-11-market-share-jumps-to-2783">Read more...</a>

## Nvidia GeForce NOW adds Diablo IV, Overwatch 2, and Rage 1 and 2 this week
 - [https://www.neowin.net/news/nvidia-geforce-now-adds-diablo-iv-overwatch-2-and-rage-1-and-2-this-week](https://www.neowin.net/news/nvidia-geforce-now-adds-diablo-iv-overwatch-2-and-rage-1-and-2-this-week)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T14:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1682020010_2mkwhgk85roc1681773896705_medium.jpg" /></div>The Nvidia GeForce NOW cloud game streaming service adds five new games this week. They include Blizzard&#039;s Diablo IV and Overwatch 2 along with id Software&#039;s two Rage games, with more coming soon. <a href="https://www.neowin.net/news/nvidia-geforce-now-adds-diablo-iv-overwatch-2-and-rage-1-and-2-this-week">Read more...</a>

## Statcounter: Microsoft Edge reaches almost 13%, a new all-time high
 - [https://www.neowin.net/news/statcounter-microsoft-edge-reaches-almost-13-a-new-all-time-high](https://www.neowin.net/news/statcounter-microsoft-edge-reaches-almost-13-a-new-all-time-high)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T14:22:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706795785_browsers_medium.jpg" /></div>According to the latest data from Statcounter, the Microsoft Edge browser reached its new all-time high market share of 12.96%, gaining over one point in the first month of this year. <a href="https://www.neowin.net/news/statcounter-microsoft-edge-reaches-almost-13-a-new-all-time-high">Read more...</a>

## Get this TP-Link Wi-Fi extender for just $13.97 with digital coupon at Amazon right now
 - [https://www.neowin.net/deals/get-this-tp-link-wi-fi-extender-for-just-1397-with-digital-coupon-at-amazon-right-now](https://www.neowin.net/deals/get-this-tp-link-wi-fi-extender-for-just-1397-with-digital-coupon-at-amazon-right-now)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T12:30:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/07/1688990105_tp-link-wifi-extender_medium.jpg" /></div>If you have a large home, the TP-Link RE220 Wi-Fi extender boosts your Wi-Fi network signal by 1,200 square feet. You can get it now for just $13.97 at Amazon with a discount and a digital coupon. <a href="https://www.neowin.net/deals/get-this-tp-link-wi-fi-extender-for-just-1397-with-digital-coupon-at-amazon-right-now">Read more...</a>

## Calendar Flyout for Windows 11 gets big update with new features
 - [https://www.neowin.net/news/calendar-flyout-for-windows-11-gets-big-update-with-new-features](https://www.neowin.net/news/calendar-flyout-for-windows-11-gets-big-update-with-new-features)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T11:10:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706784956_calendar_flyout_2.0_3_medium.jpg" /></div>The Calendar Flyout app, a replacement for Windows 11&#039;s stock flyout, has been updated to version 2.0. The latest release adds many new features and improvements to help you keep track of your events. <a href="https://www.neowin.net/news/calendar-flyout-for-windows-11-gets-big-update-with-new-features">Read more...</a>

## Hulu to crack down on password sharing in March after Disney+
 - [https://www.neowin.net/news/hulu-to-crack-down-on-password-sharing-in-march-after-disney](https://www.neowin.net/news/hulu-to-crack-down-on-password-sharing-in-march-after-disney)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T08:50:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2018/11/1541790721_huludisney_medium.jpg" /></div>Hulu has updated its subscriber agreement to explicitly prohibit password sharing and access to accounts outside of a primary household, following similar moves by Disney+ and ESPN+. <a href="https://www.neowin.net/news/hulu-to-crack-down-on-password-sharing-in-march-after-disney">Read more...</a>

## AMD releases new Windows chipset drivers for Ryzen 8000, 7000, 5000, 4000, 3000, and more
 - [https://www.neowin.net/news/amd-releases-new-windows-chipset-drivers-for-ryzen-8000-7000-5000-4000-3000-and-more](https://www.neowin.net/news/amd-releases-new-windows-chipset-drivers-for-ryzen-8000-7000-5000-4000-3000-and-more)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T07:46:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/08/1661865536_amd_ryzen_medium.jpg" /></div>AMD is out with new chipset drivers for its Socket AM5 and AM4 platforms. The new chipset supports the recently released Ryzen 8000 series APUs, but there is likely more under the hood.  <a href="https://www.neowin.net/news/amd-releases-new-windows-chipset-drivers-for-ryzen-8000-7000-5000-4000-3000-and-more">Read more...</a>

## Telegram now lets you send one-time voice and video messages
 - [https://www.neowin.net/news/telegram-now-lets-you-send-one-time-voice-and-video-messages](https://www.neowin.net/news/telegram-now-lets-you-send-one-time-voice-and-video-messages)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T03:58:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706759580_c35128de12fc2055e8_medium.jpg" /></div>Telegram has just released another big update. It includes one-time audio and video messages and the ability to see what time your messages were read at. There are also new features for Premium users. <a href="https://www.neowin.net/news/telegram-now-lets-you-send-one-time-voice-and-video-messages">Read more...</a>

## Here's the Sony PS5 State of Play roundup; new Final Fantasy VII Rebirth event coming Feb 6
 - [https://www.neowin.net/news/heres-the-sony-ps5-state-of-play-roundup-new-final-fantasy-vii-rebirth-event-coming-feb-6](https://www.neowin.net/news/heres-the-sony-ps5-state-of-play-roundup-new-final-fantasy-vii-rebirth-event-coming-feb-6)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T02:22:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/10/1570538702_ps5_medium.jpg" /></div>Sony held its latest State of Play streaming even to promote upcoming PS5 and PSVR 2 titles. It will hold another State of Play event on Feb. 6 to promote the launch of Final Fantasy VII Rebirth. <a href="https://www.neowin.net/news/heres-the-sony-ps5-state-of-play-roundup-new-final-fantasy-vii-rebirth-event-coming-feb-6">Read more...</a>

## SpaceX Starship to launch the Starlab commercial space station
 - [https://www.neowin.net/news/spacex-starship-to-launch-the-starlab-commercial-space-station](https://www.neowin.net/news/spacex-starship-to-launch-the-starlab-commercial-space-station)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T02:06:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706752663_2028-01_medium.jpg" /></div>SpaceX has been tapped to launch the Starlab space station. According to the current timeline, Starlab should get into a low Earth orbit in 2028, as long as there are no delays, that is. <a href="https://www.neowin.net/news/spacex-starship-to-launch-the-starlab-commercial-space-station">Read more...</a>

## Metro Awakening is a prequel story coming to PC VR, Meta Quest, and PSVR
 - [https://www.neowin.net/news/metro-awakening-is-a-prequel-story-coming-to-pc-vr-meta-quest-and-psvr](https://www.neowin.net/news/metro-awakening-is-a-prequel-story-coming-to-pc-vr-meta-quest-and-psvr)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T00:40:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706747644_metro-awakening_key-art-16x9_png_jpgcopy_medium.jpg" /></div>Deep Silver has announced Metro Awakening, a brand-new prequel entry to Metro 2033 coming to PC VR, Meta Quest, and PSVR this year. Series author Glukhovsky is involved in the development as well.
 <a href="https://www.neowin.net/news/metro-awakening-is-a-prequel-story-coming-to-pc-vr-meta-quest-and-psvr">Read more...</a>

## Silent Hill: The Short Message is out for free on PS5 alongside new Silent Hill 2 trailer
 - [https://www.neowin.net/news/silent-hill-the-short-message-is-out-for-free-on-ps5-alongside-new-silent-hill-2-trailer](https://www.neowin.net/news/silent-hill-the-short-message-is-out-for-free-on-ps5-alongside-new-silent-hill-2-trailer)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T00:24:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/02/1706746385_ca2f94777c461764259af74d1c38c29fde7ebc8e-scaled_1_neowin_medium.jpg" /></div>Konami released a brand-new Silent Hill game for PlayStation 5 players today, with The Short Message available now as a free download. A brand-new trailer for Silent Hill 2 remake is here too. <a href="https://www.neowin.net/news/silent-hill-the-short-message-is-out-for-free-on-ps5-alongside-new-silent-hill-2-trailer">Read more...</a>

## Here's another look at Judas, the next game by BioShock creator Ken Levine
 - [https://www.neowin.net/news/heres-another-look-at-judas-the-next-game-by-bioshock-creator-ken-levine](https://www.neowin.net/news/heres-another-look-at-judas-the-next-game-by-bioshock-creator-ken-levine)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T00:06:27+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2024/01/1706745106_04dc8a941569c304b281141848e3ee65229c52ad_1080p_medium.jpg" /></div>Ken Levine dropped a surprise Judas trailer at the Sony State of Play presentation today, offering a glimpse at some of the gameplay involving elemental powers, robot overlords, and more. <a href="https://www.neowin.net/news/heres-another-look-at-judas-the-next-game-by-bioshock-creator-ken-levine">Read more...</a>

## Microsoft appears to add extension support for Edge on Android
 - [https://www.neowin.net/news/microsoft-appears-to-add-extension-support-for-edge-on-android](https://www.neowin.net/news/microsoft-appears-to-add-extension-support-for-edge-on-android)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2024-02-01T00:02:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1680778563_edge_heart_medium.jpg" /></div>Microsoft has added preliminary support for extensions in the latest version of Edge Canary on Android. Users can now access an Extensions Beta page in the browser to download popular extensions. <a href="https://www.neowin.net/news/microsoft-appears-to-add-extension-support-for-edge-on-android">Read more...</a>

