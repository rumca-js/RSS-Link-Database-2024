# Source:The Film Theorists, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3sznuotAs2ohg_U__Jzj_Q, language:en-US

## Godzilla's Size is a 'Giant' Problem 😱! #shorts
 - [https://www.youtube.com/watch?v=L1dosXFfIes](https://www.youtube.com/watch?v=L1dosXFfIes)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3sznuotAs2ohg_U__Jzj_Q
 - date published: 2024-02-01T22:05:00+00:00

Could Godzilla actually reach the colossal sizes depicted in movies? The answer lies in The Squad Cube Law, and it's a resounding NOPE!

‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐
*Credits:*
Writers: Matthew Patrick, Forrest Lee, and Bob Chipman
Editor: Dom Sealion
Sound Designer: Yosi Berman 
‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐‐
#Godzilla #GodzillaMinusOne #Kaiju #Monster #Titan #Giant #Colossal #Movie #KingoftheMonsters #Action #Theory #FilmTheory #Matpat #Trailer

