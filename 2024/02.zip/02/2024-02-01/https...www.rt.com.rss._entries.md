# Source:RT - Daily news, URL:https://www.rt.com/rss/, language:en

## Russia and China unite over US bioweapons
 - [https://www.rt.com/news/591678-china-russia-us-biological-activities/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591678-china-russia-us-biological-activities/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T23:25:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bc276c85f540062427561b.jpg" style="margin-right: 10px;" /> Russian and Chinese governments compare notes on addressing dangers caused by alleged US development of biological weapons <br /><a href="https://www.rt.com/news/591678-china-russia-us-biological-activities/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Biden tries to punish Israeli settlers
 - [https://www.rt.com/news/591677-biden-sanctions-violent-israeli-settlers/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591677-biden-sanctions-violent-israeli-settlers/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T21:33:29+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bc0a8120302710e77bb033.jpg" style="margin-right: 10px;" /> US President Joe Biden signs executive order calling for sanctions against Israeli settlers accused of violence in the West Bank <br /><a href="https://www.rt.com/news/591677-biden-sanctions-violent-israeli-settlers/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US believes base was hit by Iranian-made drone – Reuters
 - [https://www.rt.com/news/591675-iranian-drone-jordan-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591675-iranian-drone-jordan-attack/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T21:03:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bc01602030270ed332380c.jpg" style="margin-right: 10px;" /> The US has analyzed fragments from the drone used to attack a base in Jordan and concluded that it was Iranian-made, Reuters reported <br /><a href="https://www.rt.com/news/591675-iranian-drone-jordan-attack/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia changes mandatory Covid-19 vaccination rules
 - [https://www.rt.com/russia/591676-mandatory-covid-vaccination-rule-change/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591676-mandatory-covid-vaccination-rule-change/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T21:02:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bc068b2030270f3f74467d.jpg" style="margin-right: 10px;" /> The Russian Health Ministry has eased its requirements for mandatory vaccination against Covid-19 for most people <br /><a href="https://www.rt.com/russia/591676-mandatory-covid-vaccination-rule-change/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel accepts ceasefire deal – Al Jazeera
 - [https://www.rt.com/news/591674-israel-accepts-ceasefire-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591674-israel-accepts-ceasefire-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T20:18:07+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbf34f85f54004eb6d249c.jpg" style="margin-right: 10px;" /> Israel has accepted a Qatari-negotiated ceasefire plan as diplomats in Doha are waiting for a final verdict from Hamas, Al Jazeera reported <br /><a href="https://www.rt.com/news/591674-israel-accepts-ceasefire-hamas/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## No charges expected in US sex-tape scandal – Capitol Police
 - [https://www.rt.com/news/591673-senate-sex-tape-investigation-no-charges/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591673-senate-sex-tape-investigation-no-charges/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T19:33:04+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbeda62030270faa12b5a6.jpg" style="margin-right: 10px;" /> US Capitol Police close investigation of lewd video shot in Senate hearing room, decline to make any arrests <br /><a href="https://www.rt.com/news/591673-senate-sex-tape-investigation-no-charges/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky’s generals refuse to accept firing top commander – Bild
 - [https://www.rt.com/russia/591672-ukraine-general-successors-stop-zelensky/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591672-ukraine-general-successors-stop-zelensky/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T19:10:24+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbe8a12030270ed33237e9.jpg" style="margin-right: 10px;" /> Both potential replacements for Gen. Valery Zaluzhny have refused to take his place, preventing his firing, Bild has said <br /><a href="https://www.rt.com/russia/591672-ukraine-general-successors-stop-zelensky/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Men must work, women must give birth - Russian mayor
 - [https://www.rt.com/russia/591667-men-work-women-birth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591667-men-work-women-birth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T18:02:33+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbc23885f54078e567a151.jpg" style="margin-right: 10px;" /> Mikhail Minenkov warns that Russian cities could rot like their Western counterparts unless Russians start having more children <br /><a href="https://www.rt.com/russia/591667-men-work-women-birth/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Biden gets a major boost from female voters – poll
 - [https://www.rt.com/news/591671-biden-leads-trump-quinnipiac-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591671-biden-leads-trump-quinnipiac-poll/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T17:47:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbd15d20302756ff20d453.jpg" style="margin-right: 10px;" /> US President Joe Biden leads rival Donald Trump in 2024 race for the White House as more women flock to the incumbent’s side, poll shows <br /><a href="https://www.rt.com/news/591671-biden-leads-trump-quinnipiac-poll/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US approves strikes on ‘Iranian targets’ – media
 - [https://www.rt.com/news/591670-us-approves-iran-strikes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591670-us-approves-iran-strikes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T17:08:16+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbcbac85f54007af3cac19.jpg" style="margin-right: 10px;" /> US forces are preparing for several weeks of strikes against Iran-linked targets in Iraq and Syria, CBS and NBC News reported <br /><a href="https://www.rt.com/news/591670-us-approves-iran-strikes/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian tycoon loses $230 million art trial in US
 - [https://www.rt.com/business/591655-russian-tycoon-lawsuit-sothebys/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/591655-russian-tycoon-lawsuit-sothebys/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T15:54:58+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbbc4785f54078e567a148.jpg" style="margin-right: 10px;" /> Billionaire Dmitry Rybolovlev has lost a case against Sotheby’s in which he accused the auction house of aiding a fraudulent art dealer <br /><a href="https://www.rt.com/business/591655-russian-tycoon-lawsuit-sothebys/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Farmers set fires outside EU parliament (VIDEOS)
 - [https://www.rt.com/news/591666-brussels-eu-farmers-protest/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591666-brussels-eu-farmers-protest/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T15:20:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbb48585f540207518b256.jpg" style="margin-right: 10px;" /> Farmers burned manure and threw eggs at the European Parliament in Brussels, demanding an end to cheap imports and climate regulations <br /><a href="https://www.rt.com/news/591666-brussels-eu-farmers-protest/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Nuclear secret: India’s space program uses plutonium pellets to power missions
 - [https://www.rt.com/india/591138-india-space-program-plutonium-pellets/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/591138-india-space-program-plutonium-pellets/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T15:13:59+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbab1b20302710e77bb001.jpg" style="margin-right: 10px;" /> ISRO will use radioactive decay to combat temperatures that get colder than the Moon’s -170C to heat its equipment <br /><a href="https://www.rt.com/india/591138-india-space-program-plutonium-pellets/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Rupee payments boosting India’s exports to Russia – exporting group
 - [https://www.rt.com/india/591657-india-russia-rupee-trade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/591657-india-russia-rupee-trade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T15:10:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbab1220302756ff20d427.jpg" style="margin-right: 10px;" /> Indian exports of machinery, auto parts, and other equipment to Russia doubled in 2023, thanks in part to rupee settlements, the EEPC says  <br /><a href="https://www.rt.com/india/591657-india-russia-rupee-trade/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Rwanda discovers more mass graves 30 years after genocide
 - [https://www.rt.com/africa/591648-rwanda-genocide-mass-graves/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/591648-rwanda-genocide-mass-graves/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T15:05:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb99a32030270e6a32d7e4.jpg" style="margin-right: 10px;" /> Rwandan officials have said mass graves containing presumed victims of the country’s 1994 genocide have been found <br /><a href="https://www.rt.com/africa/591648-rwanda-genocide-mass-graves/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## West refusing to cooperate with Ukrainian POW plane crash investigation – Kremlin
 - [https://www.rt.com/russia/591665-west-refuse-ukrainian-pow-crash/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591665-west-refuse-ukrainian-pow-crash/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T14:49:00+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbaf0985f540133a1709dd.jpg" style="margin-right: 10px;" /> The West does not want an international probe into the Ukrainian POW plane crash in case it exposes its own involvement, Moscow has said <br /><a href="https://www.rt.com/russia/591665-west-refuse-ukrainian-pow-crash/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Modi government ramps up spending before 2024 national poll
 - [https://www.rt.com/india/591664-modi-government-ramps-up-spending/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/591664-modi-government-ramps-up-spending/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T14:44:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bbac042030270faa12b580.jpg" style="margin-right: 10px;" /> India’s last budget before the May general election is bullish on attracting investments, avoids populist measures <br /><a href="https://www.rt.com/india/591664-modi-government-ramps-up-spending/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## German spies tracking former boss – media
 - [https://www.rt.com/news/591659-german-spies-tracking-former-boss/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591659-german-spies-tracking-former-boss/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T13:58:07+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb9d112030270e6a32d7ec.jpg" style="margin-right: 10px;" /> Germany’s security agency BfV is monitoring Hans-Georg Maassen, suspecting him of “right-wing extremism,” local media reported <br /><a href="https://www.rt.com/news/591659-german-spies-tracking-former-boss/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Americans likely part of crew that shot down Ukrainian POWs – TASS
 - [https://www.rt.com/russia/591660-us-patriot-crew-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591660-us-patriot-crew-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T13:57:02+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb9fc22030270ed33237bf.jpg" style="margin-right: 10px;" /> Russia’s Investigative Committee previously concluded that the Il-76 aircraft was destroyed using a US-made Patriot missile system <br /><a href="https://www.rt.com/russia/591660-us-patriot-crew-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU approves €50 billion in Ukraine aid
 - [https://www.rt.com/news/591658-eu-approves-ukraine-aid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591658-eu-approves-ukraine-aid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T13:41:07+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb98d22030270e6b1ab3c7.jpg" style="margin-right: 10px;" /> The EU has pressured Hungarian Prime Minister Viktor Orban into approving a €50 billion aid package for Kiev <br /><a href="https://www.rt.com/news/591658-eu-approves-ukraine-aid/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Moscow court reduces suspended sentence of convicted US investor
 - [https://www.rt.com/business/591656-us-investor-calvey-russia-sentence-reduced/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/591656-us-investor-calvey-russia-sentence-reduced/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T13:03:54+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb8b5485f5407d1a032eb3.jpg" style="margin-right: 10px;" /> A Moscow appeals court has reduced the sentence of Baring Vostok founder Michael Calvey <br /><a href="https://www.rt.com/business/591656-us-investor-calvey-russia-sentence-reduced/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Berlusconi’s villa put on sale for over $500 million – FT
 - [https://www.rt.com/business/591645-berlusconi-villa-italy-sale/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/591645-berlusconi-villa-italy-sale/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T12:36:41+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb8f2c2030270faa12b56c.jpg" style="margin-right: 10px;" /> The family of Italy’s late former prime minister is reportedly selling his Sardinian beach estate, Villa Certosa <br /><a href="https://www.rt.com/business/591645-berlusconi-villa-italy-sale/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Biden has made Americans complicit in Ukrainian POW deaths – Moscow
 - [https://www.rt.com/russia/591653-us-complicit-downing/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591653-us-complicit-downing/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T12:03:54+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb878185f540133a1709b5.jpg" style="margin-right: 10px;" /> Russian Foreign Ministry spokeswoman Maria Zakharova says the use of Patriot missiles in the attack makes Americans complicit <br /><a href="https://www.rt.com/russia/591653-us-complicit-downing/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## How NATO brainwashes Western society with its anti-Russia wargames
 - [https://www.rt.com/news/591608-steadfast-defender-2024-nato/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591608-steadfast-defender-2024-nato/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T12:02:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65ba5d7785f5407d1a032e44.jpg" style="margin-right: 10px;" /> Steadfast Defender 2024, the bloc’s largest recent wargames, is not only about military cohesion; it’s about selling war to the people <br /><a href="https://www.rt.com/news/591608-steadfast-defender-2024-nato/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Corruption scandal in Ukraine sparks outrage in US Congress – media
 - [https://www.rt.com/russia/591647-us-congress-slams-ukraine-corruption/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591647-us-congress-slams-ukraine-corruption/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T12:02:44+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb6aab2030270f3f744613.jpg" style="margin-right: 10px;" /> US congresspeople say the money designated for Ukraine’s war effort is not going where it was intended and have called for a full audit  <br /><a href="https://www.rt.com/russia/591647-us-congress-slams-ukraine-corruption/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Investigators have identified everyone killed in plane carrying Ukrainian POWs
 - [https://www.rt.com/russia/591654-investigators-identified-killed-ukrainian-pows/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591654-investigators-identified-killed-ukrainian-pows/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T11:56:48+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb8b0b85f54003976b974d.png" style="margin-right: 10px;" /> All the remains of those killed in Kiev’s attack on a Russian Il-76 transporting Ukrainian POWs have been identified, Moscow has said <br /><a href="https://www.rt.com/russia/591654-investigators-identified-killed-ukrainian-pows/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Zelensky to fire top general this week – CNN
 - [https://www.rt.com/russia/591652-zelensky-to-fire-zaluzhny/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591652-zelensky-to-fire-zaluzhny/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T11:51:16+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb85842030270e6a32d7c7.jpg" style="margin-right: 10px;" /> Valery Zaluzhny, who has led Kiev’s forces since 2021, has reportedly refused an advisory position and intends to leave the military <br /><a href="https://www.rt.com/russia/591652-zelensky-to-fire-zaluzhny/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Pope wants to divide African church – Ugandan pastor
 - [https://www.rt.com/africa/591646-pope-francis-lgbt-uganda-pastor/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/591646-pope-francis-lgbt-uganda-pastor/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T10:40:11+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb68ca2030270faa12b546.jpg" style="margin-right: 10px;" /> The bible does not allow African nations to bless same-sex marriages, Martin Ssempa says <br /><a href="https://www.rt.com/africa/591646-pope-francis-lgbt-uganda-pastor/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Germany mulling sale of stake in top gas importer – Bloomberg
 - [https://www.rt.com/business/591615-germany-uniper-stake-sale/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/591615-germany-uniper-stake-sale/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T10:11:33+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65ba7d982030270e6b1ab321.jpg" style="margin-right: 10px;" /> The German government is reportedly considering selling part of its stake in major gas importer Uniper in a bid to plug a budget gap

  <br /><a href="https://www.rt.com/business/591615-germany-uniper-stake-sale/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian influence causing dilemma in Africa’s Sahel – EU foreign policy chief
 - [https://www.rt.com/africa/591644-eu-russian-africa-influence-criticism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/591644-eu-russian-africa-influence-criticism/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T10:05:55+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb6ae12030270e6a32d7b5.jpg" style="margin-right: 10px;" /> EU foreign policy chief Josep Borrell says Russia’s strong presence in Africa’s Sahel region is posing a challenge for the bloc <br /><a href="https://www.rt.com/africa/591644-eu-russian-africa-influence-criticism/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US-supplied missile shot down plane carrying Ukrainian POWs – investigators (VIDEO)
 - [https://www.rt.com/russia/591649-plane-ukrainian-pows-shot-patriot/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591649-plane-ukrainian-pows-shot-patriot/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T10:05:03+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb72c42030270faa12b558.png" style="margin-right: 10px;" /> Ukraine used a US-supplied Patriot air defense system to down a Russian plane carrying POWs, investigators have said <br /><a href="https://www.rt.com/russia/591649-plane-ukrainian-pows-shot-patriot/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US has built up military stash for potential Taiwan war – Reuters
 - [https://www.rt.com/news/591642-us-stash-australia-taiwan-war/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591642-us-stash-australia-taiwan-war/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T09:32:38+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb61472030270faa12b53d.jpg" style="margin-right: 10px;" /> The US has created a stockpile of hundreds of vehicles in Austria to prepare for a potential conflict with China, Reuters has reported <br /><a href="https://www.rt.com/news/591642-us-stash-australia-taiwan-war/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US reacts to reports of stalled drone deal with India
 - [https://www.rt.com/india/591641-us-india-drone-deal-stalled/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/591641-us-india-drone-deal-stalled/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T08:24:59+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb4f042030270e6a32d793.jpg" style="margin-right: 10px;" /> The $3bn Predator drone purchase by New Delhi could be facing hurdles over a Sikh activist murder plot, media claimed <br /><a href="https://www.rt.com/india/591641-us-india-drone-deal-stalled/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Man uses ChatGPT to find wife
 - [https://www.rt.com/russia/591635-man-uses-ai-to-find-love/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591635-man-uses-ai-to-find-love/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T08:07:57+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb42f620302753895785a8.jpg" style="margin-right: 10px;" /> A Russian computer nerd outsourced flirting on a dating app to ChatGPT <br /><a href="https://www.rt.com/russia/591635-man-uses-ai-to-find-love/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US encouraging Ukraine to commit new atrocities – Moscow
 - [https://www.rt.com/russia/591640-us-ukraine-new-atrocities-bombs/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/591640-us-ukraine-new-atrocities-bombs/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T07:57:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb45fe85f5400f68435f25.jpg" style="margin-right: 10px;" /> By supplying Ukraine with long-range GLSDB bombs, Washington is encouraging Kiev to commit new crimes, Moscow has said <br /><a href="https://www.rt.com/russia/591640-us-ukraine-new-atrocities-bombs/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Red Sea crisis exposing EU energy weakness – FT
 - [https://www.rt.com/business/591604-eu-diesel-prices-red-sea-crisis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/591604-eu-diesel-prices-red-sea-crisis/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T05:40:14+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65ba563d2030270ed3323720.jpg" style="margin-right: 10px;" /> Global diesel prices have hit a nearly three-month high adding pressure to a burgeoning cost-of-living crisis in the EU, the FT says

  <br /><a href="https://www.rt.com/business/591604-eu-diesel-prices-red-sea-crisis/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia overtakes US as Brazil’s top diesel supplier – data
 - [https://www.rt.com/business/591596-russia-brazil-diesel-exports-us/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/591596-russia-brazil-diesel-exports-us/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T05:39:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65ba436485f540773940baa5.jpg" style="margin-right: 10px;" /> Brazil has become a major buyer of Russian diesel and gasoil, with Brazilian imports seeing a three-digit surge, data shows <br /><a href="https://www.rt.com/business/591596-russia-brazil-diesel-exports-us/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Chinese defense chief promises Russia support on ‘Ukrainian issue’
 - [https://www.rt.com/news/591629-china-russia-military-cooperation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591629-china-russia-military-cooperation/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T03:37:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb101b85f54003e552171d.jpg" style="margin-right: 10px;" /> China’s defense minister Dong Jun discussed strategic cooperation with his Russian counterpart Sergey Shoigu in a video call on Wednesday <br /><a href="https://www.rt.com/news/591629-china-russia-military-cooperation/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## India’s opposition coalition crumbles, making Modi’s return to power a foregone conclusion
 - [https://www.rt.com/india/591618-indias-opposition-unity-crumbles-making/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/591618-indias-opposition-unity-crumbles-making/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T03:28:38+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bb0d692030275389578586.jpg" style="margin-right: 10px;" /> India’s opposition unity crumbles, making Modi’s return to power this year a foregone conclusion <br /><a href="https://www.rt.com/india/591618-indias-opposition-unity-crumbles-making/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## EU state could slash payments for all Ukrainians to just €38 per week – minister
 - [https://www.rt.com/news/591627-ireland-ukrainians-slash-payments/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591627-ireland-ukrainians-slash-payments/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T01:28:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.01/thumbnail/65badc3f2030270f3f7445be.jpg" style="margin-right: 10px;" /> Ireland may cut support to Ukrainians in state housing by almost six times, Dublin’s Social Protections Minister has told Irish Parliament <br /><a href="https://www.rt.com/news/591627-ireland-ukrainians-slash-payments/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## White House staffer unveils what Biden aides ‘can’t say publicly’
 - [https://www.rt.com/news/591628-biden-slowing-harris-unpopular/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/591628-biden-slowing-harris-unpopular/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2024-02-01T00:39:21+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2024.02/thumbnail/65bae74885f5400f68435f15.png" style="margin-right: 10px;" /> White House staffers are allegedly worried about President Joe Biden’s deteriorating cognitive skills and the unpopularity of Kamala Harris <br /><a href="https://www.rt.com/news/591628-biden-slowing-harris-unpopular/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

