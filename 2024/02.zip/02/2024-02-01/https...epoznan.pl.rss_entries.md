# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Szukają tej kobiety. Rozpoznajesz?
 - [https://epoznan.pl/news-news-147502-szukaja_tej_kobiety_rozpoznajesz?rss=1](https://epoznan.pl/news-news-147502-szukaja_tej_kobiety_rozpoznajesz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T21:30:00+00:00

Sprawa dotyczy kradzieży.

## Miasto nie zgodziło się na wycięcie 650 drzew w centrum Poznania
 - [https://epoznan.pl/news-news-147501-miasto_nie_zgodzilo_sie_na_wyciecie_650_drzew_w_centrum_poznania?rss=1](https://epoznan.pl/news-news-147501-miasto_nie_zgodzilo_sie_na_wyciecie_650_drzew_w_centrum_poznania?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T21:22:00+00:00

Drzewa mają zagrażać pociągom.

## W śmiertelnym wypadku na S5 zginął dziennikarz
 - [https://epoznan.pl/news-news-147500-w_smiertelnym_wypadku_na_s5_zginal_dziennikarz?rss=1](https://epoznan.pl/news-news-147500-w_smiertelnym_wypadku_na_s5_zginal_dziennikarz?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T21:15:00+00:00

Do zdarzenia doszło w czwartek rano.

## W Poznaniu powstanie nowy park. &quot;Jesteśmy zdeterminowani, żeby ten pomysł zrealizować&quot;
 - [https://epoznan.pl/news-news-147495-w_poznaniu_powstanie_nowy_park_jestesmy_zdeterminowani_zeby_ten_pomysl_zrealizowac?rss=1](https://epoznan.pl/news-news-147495-w_poznaniu_powstanie_nowy_park_jestesmy_zdeterminowani_zeby_ten_pomysl_zrealizowac?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T21:00:00+00:00

Ogłoszono konkurs dla studentów.

## Ogromny hotel nad Maltą może zostać otwarty w 2026 roku
 - [https://epoznan.pl/news-news-147499-ogromny_hotel_nad_malta_moze_zostac_otwarty_w_2026_roku?rss=1](https://epoznan.pl/news-news-147499-ogromny_hotel_nad_malta_moze_zostac_otwarty_w_2026_roku?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T20:45:00+00:00

Jest oficjalna zgodna na budowę.

## Ukradli ponad 200 sztuk zdrapek na stacji paliw w centrum miasta. Nie mieli szczęścia
 - [https://epoznan.pl/news-news-147497-ukradli_ponad_200_sztuk_zdrapek_na_stacji_paliw_w_centrum_miasta_nie_mieli_szczescia?rss=1](https://epoznan.pl/news-news-147497-ukradli_ponad_200_sztuk_zdrapek_na_stacji_paliw_w_centrum_miasta_nie_mieli_szczescia?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T20:30:00+00:00

Już wpadli.

## Potrącenie przez tramwaj na Franowie
 - [https://epoznan.pl/news-news-147498-potracenie_przez_tramwaj_na_franowie?rss=1](https://epoznan.pl/news-news-147498-potracenie_przez_tramwaj_na_franowie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T20:15:00+00:00

Ruch jest wstrzymany.

## Duża i popularna inwestycja pod Poznaniem z prestiżową nagrodą. &quot;Nowoczesny i innowacyjny obiekt&quot;
 - [https://epoznan.pl/news-news-147496-duza_i_popularna_inwestycja_pod_poznaniem_z_prestizowa_nagroda_nowoczesny_i_innowacyjny_obiekt?rss=1](https://epoznan.pl/news-news-147496-duza_i_popularna_inwestycja_pod_poznaniem_z_prestizowa_nagroda_nowoczesny_i_innowacyjny_obiekt?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T20:00:00+00:00

Kładka pieszo-rowerowa w Owińskach została nagrodzona w prestiżowym konkursie na &quot;Najlepiej zagospodarowaną przestrzeń publiczną w Wielkopolsce&quot;.

## Rozpoczyna się kolejna inwestycja - na południu Poznania. Dwie ulice będą wyłączone z ruchu!
 - [https://epoznan.pl/news-news-147494-rozpoczyna_sie_kolejna_inwestycja_na_poludniu_poznania_dwie_ulice_beda_wylaczone_z_ruchu?rss=1](https://epoznan.pl/news-news-147494-rozpoczyna_sie_kolejna_inwestycja_na_poludniu_poznania_dwie_ulice_beda_wylaczone_z_ruchu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T19:30:00+00:00

Ulice Walentego Stefańskiego i Eugeniusza Kwiatkowskiego na Świerczewie zostaną przebudowane.

## Chwile grozy w sklepie. 17-latek celował do kasjera z broni żądając pieniędzy
 - [https://epoznan.pl/news-news-147493-chwile_grozy_w_sklepie_17_latek_celowal_do_kasjera_z_broni_zadajac_pieniedzy?rss=1](https://epoznan.pl/news-news-147493-chwile_grozy_w_sklepie_17_latek_celowal_do_kasjera_z_broni_zadajac_pieniedzy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T19:00:00+00:00

Mówi, że dla żartu.

## Abp Gądecki wprowadza zmiany w Caritas. Jest nowy dyrektor
 - [https://epoznan.pl/news-news-147492-abp_gadecki_wprowadza_zmiany_w_caritas_jest_nowy_dyrektor?rss=1](https://epoznan.pl/news-news-147492-abp_gadecki_wprowadza_zmiany_w_caritas_jest_nowy_dyrektor?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T18:30:00+00:00

Od 1 lutego funkcję dyrektora Caritas Archidiecezji Poznańskiej pełnić będzie ks. Karol Maciejak.

## Woda nie będzie już zalewała szkolnego dziedzińca. Znaleźli na to sposób
 - [https://epoznan.pl/news-news-147491-woda_nie_bedzie_juz_zalewala_szkolnego_dziedzinca_znalezli_na_to_sposob?rss=1](https://epoznan.pl/news-news-147491-woda_nie_bedzie_juz_zalewala_szkolnego_dziedzinca_znalezli_na_to_sposob?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T18:00:00+00:00

Uczniowie mają nowe miejsce, gdzie mogą uprawiać sport.

## Oderwał się fragment balkonu i spadł na idącą chodnikiem kobietę
 - [https://epoznan.pl/news-news-147490-oderwal_sie_fragment_balkonu_i_spadl_na_idaca_chodnikiem_kobiete?rss=1](https://epoznan.pl/news-news-147490-oderwal_sie_fragment_balkonu_i_spadl_na_idaca_chodnikiem_kobiete?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T17:30:00+00:00

W Gnieźnie.

## 30 tys. zł strat. Mężczyzna wszedł na dach Mercedesa i zaczął po nim skakać
 - [https://epoznan.pl/news-news-147488-30_tys_zl_strat_mezczyzna_wszedl_na_dach_mercedesa_i_zaczal_po_nim_skakac?rss=1](https://epoznan.pl/news-news-147488-30_tys_zl_strat_mezczyzna_wszedl_na_dach_mercedesa_i_zaczal_po_nim_skakac?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T16:45:00+00:00

43-letni mieszkaniec powiatu poznańskiego może trafić do więzienia na 5 lat.

## Działania służb u zbiegu Głogowskiej i Śniadeckich. &quot;Nieprzytomny mężczyzna w samochodzie&quot;
 - [https://epoznan.pl/news-news-147489-dzialania_sluzb_u_zbiegu_glogowskiej_i_sniadeckich_nieprzytomny_mezczyzna_w_samochodzie?rss=1](https://epoznan.pl/news-news-147489-dzialania_sluzb_u_zbiegu_glogowskiej_i_sniadeckich_nieprzytomny_mezczyzna_w_samochodzie?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T16:15:00+00:00

Jest już pod opieką ratowników.

## W Poznaniu stanął ogromny kontener. Do piątku ma być wypełniony po brzegi
 - [https://epoznan.pl/news-news-147487-w_poznaniu_stanal_ogromny_kontener_do_piatku_ma_byc_wypelniony_po_brzegi?rss=1](https://epoznan.pl/news-news-147487-w_poznaniu_stanal_ogromny_kontener_do_piatku_ma_byc_wypelniony_po_brzegi?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T16:00:00+00:00

Później wyruszy do portu w Gdyni.

## Akcja policji w podpoznańskiej szkole. Zatrzymano nastolatka z narkotykami
 - [https://epoznan.pl/news-news-147486-akcja_policji_w_podpoznanskiej_szkole_zatrzymano_nastolatka_z_narkotykami?rss=1](https://epoznan.pl/news-news-147486-akcja_policji_w_podpoznanskiej_szkole_zatrzymano_nastolatka_z_narkotykami?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T15:30:00+00:00



## Podsumowują półroczną współpracę. &quot;Średni czas oczekiwania pacjenta na rozmowę wynosi 40 sekund&quot;
 - [https://epoznan.pl/news-news-147485-podsumowuja_polroczna_wspolprace_sredni_czas_oczekiwania_pacjenta_na_rozmowe_wynosi_40_sekund?rss=1](https://epoznan.pl/news-news-147485-podsumowuja_polroczna_wspolprace_sredni_czas_oczekiwania_pacjenta_na_rozmowe_wynosi_40_sekund?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T15:00:00+00:00

Od lipca 2023 r. miejska infolinia - Biuro Poznań Kontakt - wspiera POSUM w prowadzeniu rejestracji pacjentów do poradni specjalistycznych.

## Będzie zwężenie pod jednym z poznańskich wiaduktów. Ruch wahadłowy do końca maja!
 - [https://epoznan.pl/news-news-147484-bedzie_zwezenie_pod_jednym_z_poznanskich_wiaduktow_ruch_wahadlowy_do_konca_maja?rss=1](https://epoznan.pl/news-news-147484-bedzie_zwezenie_pod_jednym_z_poznanskich_wiaduktow_ruch_wahadlowy_do_konca_maja?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T14:30:00+00:00

Chodzi o wiadukt Narutowicza.

## Zuchwała kradzież w Poznaniu. Szuka go policja
 - [https://epoznan.pl/news-news-147478-zuchwala_kradziez_w_poznaniu_szuka_go_policja?rss=1](https://epoznan.pl/news-news-147478-zuchwala_kradziez_w_poznaniu_szuka_go_policja?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T13:55:00+00:00

Do zdarzenia doszło na osiedlu Przyjaźni.

## Rolnicy zapowiadają wielki protest w Poznaniu: nawet 1000 ciągników ma wjechać do miasta
 - [https://epoznan.pl/news-news-147482-rolnicy_zapowiadaja_wielki_protest_w_poznaniu_nawet_1000_ciagnikow_ma_wjechac_do_miasta?rss=1](https://epoznan.pl/news-news-147482-rolnicy_zapowiadaja_wielki_protest_w_poznaniu_nawet_1000_ciagnikow_ma_wjechac_do_miasta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T13:47:00+00:00

Rolnicy chcą pojawić się w przyszłym tygodniu przed Urzędem Wojewódzkim.

## Trasa PST wozi poznaniaków od 27 lat!
 - [https://epoznan.pl/news-news-147480-trasa_pst_wozi_poznaniakow_od_27_lat?rss=1](https://epoznan.pl/news-news-147480-trasa_pst_wozi_poznaniakow_od_27_lat?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T13:40:00+00:00

Regularne kursy zaczęły się na PST 1 lutego 1997 roku.

## Policja sprawdziła, jak wygląda sytuacja CH Posnania. W galerii pojawiali się nieumundurowani funkcjonariusze
 - [https://epoznan.pl/news-news-147479-policja_sprawdzila_jak_wyglada_sytuacja_ch_posnania_w_galerii_pojawiali_sie_nieumundurowani_funkcjonariusze?rss=1](https://epoznan.pl/news-news-147479-policja_sprawdzila_jak_wyglada_sytuacja_ch_posnania_w_galerii_pojawiali_sie_nieumundurowani_funkcjonariusze?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T13:20:00+00:00

Co odkryli?

## W Wielkopolsce ukończono nowoczesną fabrykę Samsunga. Ma zwiększyć wydajność produkcji
 - [https://epoznan.pl/news-news-147477-w_wielkopolsce_ukonczono_nowoczesna_fabryke_samsunga_ma_zwiekszyc_wydajnosc_produkcji?rss=1](https://epoznan.pl/news-news-147477-w_wielkopolsce_ukonczono_nowoczesna_fabryke_samsunga_ma_zwiekszyc_wydajnosc_produkcji?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T13:10:00+00:00

Za budowę odpowiadała firma Panattoni.

## Kury sąsiada wbiegały na jego posesję. Sąsiedzki konflikt zakończony wyrokiem sądu
 - [https://epoznan.pl/news-news-147474-kury_sasiada_wbiegaly_na_jego_posesje_sasiedzki_konflikt_zakonczony_wyrokiem_sadu?rss=1](https://epoznan.pl/news-news-147474-kury_sasiada_wbiegaly_na_jego_posesje_sasiedzki_konflikt_zakonczony_wyrokiem_sadu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T12:45:00+00:00



## MPK Poznań wciąż szuka pracowników. Nie tylko kierowców autobusów
 - [https://epoznan.pl/news-news-147472-mpk_poznan_wciaz_szuka_pracownikow_nie_tylko_kierowcow_autobusow?rss=1](https://epoznan.pl/news-news-147472-mpk_poznan_wciaz_szuka_pracownikow_nie_tylko_kierowcow_autobusow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T12:05:00+00:00

W marcu odbędzie się kurs prawa jazdy kategorii D i kwalifikacji wstępnej.

## Trasa S5 zablokowana po tragicznym wypadku. Kierowca jechał pod prąd!
 - [https://epoznan.pl/news-news-147475-trasa_s5_zablokowana_po_tragicznym_wypadku_kierowca_jechal_pod_prad?rss=1](https://epoznan.pl/news-news-147475-trasa_s5_zablokowana_po_tragicznym_wypadku_kierowca_jechal_pod_prad?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T11:34:00+00:00

Do zdarzenia doszło około 11.35 pod Kościanem.

## Stary Rynek jednego dnia bez trykających się koziołków. Przez... brak prądu
 - [https://epoznan.pl/news-news-147469-stary_rynek_jednego_dnia_bez_trykajacych_sie_koziolkow_przez_brak_pradu?rss=1](https://epoznan.pl/news-news-147469-stary_rynek_jednego_dnia_bez_trykajacych_sie_koziolkow_przez_brak_pradu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T11:31:00+00:00



## Korzystasz z hulajnogi lub roweru na minuty? Spore zmiany dla użytkowników w centrum miasta!
 - [https://epoznan.pl/news-news-147470-korzystasz_z_hulajnogi_lub_roweru_na_minuty_spore_zmiany_dla_uzytkownikow_w_centrum_miasta?rss=1](https://epoznan.pl/news-news-147470-korzystasz_z_hulajnogi_lub_roweru_na_minuty_spore_zmiany_dla_uzytkownikow_w_centrum_miasta?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T11:00:00+00:00

Wchodzą w życie już w czwartek, ale obecnie to okres przejściowy.

## Policjanci na jeziorze Maltańskim. Trwają poszukiwania człowieka
 - [https://epoznan.pl/news-news-147473-policjanci_na_jeziorze_maltanskim_trwaja_poszukiwania_czlowieka?rss=1](https://epoznan.pl/news-news-147473-policjanci_na_jeziorze_maltanskim_trwaja_poszukiwania_czlowieka?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T10:38:00+00:00

O sprawie poinformował nas Czytelnik.

## Jest drugi wicewojewoda! Kto nim został?
 - [https://epoznan.pl/news-news-147471-jest_drugi_wicewojewoda_kto_nim_zostal?rss=1](https://epoznan.pl/news-news-147471-jest_drugi_wicewojewoda_kto_nim_zostal?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T10:30:00+00:00

To Jarosław Maciejewski.

## Rozpoczyna się kwalifikacja wojskowa w regionie. Wezwanie dostanie ponad 20 tysięcy osób
 - [https://epoznan.pl/news-news-147467-rozpoczyna_sie_kwalifikacja_wojskowa_w_regionie_wezwanie_dostanie_ponad_20_tysiecy_osob?rss=1](https://epoznan.pl/news-news-147467-rozpoczyna_sie_kwalifikacja_wojskowa_w_regionie_wezwanie_dostanie_ponad_20_tysiecy_osob?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T10:00:00+00:00

Kto konkretnie?

## Mężczyzna poparzony w wyniku wybuchu w domu. Z okien wyleciały szyby
 - [https://epoznan.pl/news-news-147468-mezczyzna_poparzony_w_wyniku_wybuchu_w_domu_z_okien_wylecialy_szyby?rss=1](https://epoznan.pl/news-news-147468-mezczyzna_poparzony_w_wyniku_wybuchu_w_domu_z_okien_wylecialy_szyby?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T09:22:00+00:00

Niebezpiecznie w powiecie ostrowskim.

## Jest przetarg na wybudowanie nowej poznańskiej pływalni!
 - [https://epoznan.pl/news-news-147466-jest_przetarg_na_wybudowanie_nowej_poznanskiej_plywalni?rss=1](https://epoznan.pl/news-news-147466-jest_przetarg_na_wybudowanie_nowej_poznanskiej_plywalni?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T09:05:00+00:00

Kiedy ma powstać?

## 30 punktów karnych i 3000 złotych mandatu dla 25-latka z audi
 - [https://epoznan.pl/news-news-147465-30_punktow_karnych_i_3000_zlotych_mandatu_dla_25_latka_z_audi?rss=1](https://epoznan.pl/news-news-147465-30_punktow_karnych_i_3000_zlotych_mandatu_dla_25_latka_z_audi?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T08:20:00+00:00

Co zrobił?

## Od czwartku można składać wnioski o świadczenie na dziecko. Jak to zrobić?
 - [https://epoznan.pl/news-news-147464-od_czwartku_mozna_skladac_wnioski_o_swiadczenie_na_dziecko_jak_to_zrobic?rss=1](https://epoznan.pl/news-news-147464-od_czwartku_mozna_skladac_wnioski_o_swiadczenie_na_dziecko_jak_to_zrobic?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T07:45:00+00:00

Chodzi o 800+.

## Na Jeżycach powstał nowy skwer. Można z niego podziwiać pociągi i tramwaje!
 - [https://epoznan.pl/news-news-147463-na_jezycach_powstal_nowy_skwer_mozna_z_niego_podziwiac_pociagi_i_tramwaje?rss=1](https://epoznan.pl/news-news-147463-na_jezycach_powstal_nowy_skwer_mozna_z_niego_podziwiac_pociagi_i_tramwaje?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T07:10:00+00:00

Powstał przy ulicy Norwida.

## Rondo Kaponiera w brudzie i śmieciach? &quot;Chwasty, lepiące schody, od miesięcy nieruszone windy&quot;
 - [https://epoznan.pl/news-news-147462-rondo_kaponiera_w_brudzie_i_smieciach_chwasty_lepiace_schody_od_miesiecy_nieruszone_windy?rss=1](https://epoznan.pl/news-news-147462-rondo_kaponiera_w_brudzie_i_smieciach_chwasty_lepiace_schody_od_miesiecy_nieruszone_windy?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2024-02-01T06:35:00+00:00

Czytelnik skarży się, że rondo jest zapuszczone.

