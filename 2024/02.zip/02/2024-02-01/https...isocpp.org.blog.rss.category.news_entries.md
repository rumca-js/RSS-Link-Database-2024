# Source:Standard C++ | News, URL:https://isocpp.org/blog/rss/category/news, language:en

## SObjectizer Tales – 17. Limiting message flow--Marco Arena
 - [https://isocpp.org//blog/2024/02/sobjectizer-tales-17.-limiting-message-flow](https://isocpp.org//blog/2024/02/sobjectizer-tales-17.-limiting-message-flow)
 - RSS feed: https://isocpp.org/blog/rss/category/news
 - date published: 2024-02-01T07:58:35+00:00

<p>
	<img alt="" src="https://marcoarena.files.wordpress.com/2023/12/sobjectizer-tales_17.png" style="width: 300px; margin: 10px; float: right; height: 147px;" />A new episode of the series about SObjectizer and message passing:</p>
<blockquote>
	<h3>
		<a href="https://marcoarena.wordpress.com/2024/02/01/sobjectizer-tales-17/">SObjectizer Tales &ndash; 17. Limiting message flow</a></h3>
	<p>
		by Marco Arena</p>
</blockquote>
<p>
	From the article:</p>
<blockquote>
	<p>
		In this episode we implement strategies within agents to effectively control and manage message flow.</p>
</blockquote>

