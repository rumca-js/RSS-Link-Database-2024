# Source:Channel Asia Latest News, URL:https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml, language:en

## Intel delays $20 billion Ohio project, citing slow chip market - WSJ
 - [https://www.channelnewsasia.com/business/intel-delays-20-billion-ohio-project-citing-slow-chip-market-wsj-4093691](https://www.channelnewsasia.com/business/intel-delays-20-billion-ohio-project-citing-slow-chip-market-wsj-4093691)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:51:37+00:00



## Villa's Traore joins Villarreal on free transfer
 - [https://www.channelnewsasia.com/sport/villas-traore-joins-villarreal-free-transfer-4093661](https://www.channelnewsasia.com/sport/villas-traore-joins-villarreal-free-transfer-4093661)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:40:19+00:00



## Mainoo late show seals dramatic Man United win at Wolves
 - [https://www.channelnewsasia.com/sport/mainoo-late-show-seals-dramatic-man-united-win-wolves-4093626](https://www.channelnewsasia.com/sport/mainoo-late-show-seals-dramatic-man-united-win-wolves-4093626)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:29:03+00:00



## Mangala joins Lyon from Nottingham Forest on loan
 - [https://www.channelnewsasia.com/sport/mangala-joins-lyon-nottingham-forest-loan-4093561](https://www.channelnewsasia.com/sport/mangala-joins-lyon-nottingham-forest-loan-4093561)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:17:19+00:00



## Marketmind: Rocky week to end on tech-led bounce
 - [https://www.channelnewsasia.com/business/marketmind-rocky-week-end-tech-led-bounce-4093541](https://www.channelnewsasia.com/business/marketmind-rocky-week-end-tech-led-bounce-4093541)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:07:22+00:00



## Real Madrid reclaim top spot as Joselu seals win at Getafe
 - [https://www.channelnewsasia.com/sport/real-madrid-reclaim-top-spot-joselu-seals-win-getafe-4093531](https://www.channelnewsasia.com/sport/real-madrid-reclaim-top-spot-joselu-seals-win-getafe-4093531)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:01:55+00:00



## Commentary: Don't expect US Federal Reserve to cut interest rates just yet
 - [https://www.channelnewsasia.com/commentary/interest-rate-cut-when-us-fed-inflation-economy-4091501](https://www.channelnewsasia.com/commentary/interest-rate-cut-when-us-fed-inflation-economy-4091501)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:00:00+00:00

With the US economy looking bright enough, the Federal Reserve and its chairman Jerome Powell seem content to play the waiting game, says this economist from the University of Nebraska Omaha.

## Commentary: Klopp leaving Liverpool is a good thing
 - [https://www.channelnewsasia.com/commentary/jurgen-klopp-leaving-liverpool-burnout-running-out-energy-4091456](https://www.channelnewsasia.com/commentary/jurgen-klopp-leaving-liverpool-burnout-running-out-energy-4091456)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:00:00+00:00

Whoever next occupies the Anfield hotseat will inherit a very strong set-up at all levels, one that is much stronger than when Jurgen Klopp arrived in 2015, says sports writer John Duerden.

## Commentary: The Ukraine-born beauty queen and what it means to be Japanese
 - [https://www.channelnewsasia.com/commentary/miss-japan-beauty-contest-ukraine-born-winner-4091611](https://www.channelnewsasia.com/commentary/miss-japan-beauty-contest-ukraine-born-winner-4091611)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:00:00+00:00

The debate triggered by Karolina Shiino’s victory in a Miss Japan contest isn’t as simple as it seems, says Bloomberg Opinion’s Gearoid Reidy.

## Indonesia Elections 2024: Is President Jokowi adopting an ‘Obama-style’ strategy in campaigning for Prabowo?
 - [https://www.channelnewsasia.com/asia/indonesia-election-joko-widodo-jokowi-campaign-strategy-prabowo-obama-4084566](https://www.channelnewsasia.com/asia/indonesia-election-joko-widodo-jokowi-campaign-strategy-prabowo-obama-4084566)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T22:00:00+00:00

Analysts say the president’s support for frontrunner candidate Prabowo Subianto marks a first in Indonesian politics and could undermine public confidence over the presidency as an institution and the electoral process.

## Not just his or hers: 10 gender-neutral jewellery collections to match with your other half
 - [https://www.channelnewsasia.com/obsessions/genderless-jewellery-chanel-cartier-boucheron-hermes-lv-4081786](https://www.channelnewsasia.com/obsessions/genderless-jewellery-chanel-cartier-boucheron-hermes-lv-4081786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T21:40:50+00:00

In the jewellery world, genderless styles are growing in popularity. This Valentine’s Day, curate a shared jewellery box for you and your partner with our picks of unisex collections from brands such as Chanel, Cartier, Boucheron and more.

## West Ham fight back to draw with Bournemouth after Phillips debut blunder
 - [https://www.channelnewsasia.com/sport/west-ham-fight-back-draw-bournemouth-after-phillips-debut-blunder-4093466](https://www.channelnewsasia.com/sport/west-ham-fight-back-draw-bournemouth-after-phillips-debut-blunder-4093466)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T21:34:10+00:00



## Other Women's majors should match record US Open purse, says Vu
 - [https://www.channelnewsasia.com/sport/other-womens-majors-should-match-record-us-open-purse-says-vu-4093456](https://www.channelnewsasia.com/sport/other-womens-majors-should-match-record-us-open-purse-says-vu-4093456)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T21:32:14+00:00



## Apple quarterly profit, revenue top Wall Street targets but China lags
 - [https://www.channelnewsasia.com/business/apple-quarterly-profit-revenue-top-wall-street-targets-china-lags-4093451](https://www.channelnewsasia.com/business/apple-quarterly-profit-revenue-top-wall-street-targets-china-lags-4093451)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T21:30:25+00:00



## Cloudflare says state-backed hackers tried to burrow into its global network
 - [https://www.channelnewsasia.com/business/cloudflare-says-state-backed-hackers-tried-burrow-its-global-network-4093436](https://www.channelnewsasia.com/business/cloudflare-says-state-backed-hackers-tried-burrow-its-global-network-4093436)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T21:22:36+00:00



## Assailant takes hostages in Gaza protest near Istanbul
 - [https://www.channelnewsasia.com/world/assailant-takes-hostages-gaza-protest-near-istanbul-4092791](https://www.channelnewsasia.com/world/assailant-takes-hostages-gaza-protest-near-istanbul-4092791)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T21:19:46+00:00



## Facebook parent Meta declares first dividend, shares jump 12%
 - [https://www.channelnewsasia.com/business/facebook-parent-meta-declares-first-dividend-shares-jump-12-4093396](https://www.channelnewsasia.com/business/facebook-parent-meta-declares-first-dividend-shares-jump-12-4093396)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T21:07:00+00:00



## Genesis reaches $21 million SEC settlement in bankruptcy wind-down
 - [https://www.channelnewsasia.com/business/genesis-reaches-21-million-sec-settlement-bankruptcy-wind-down-4093371](https://www.channelnewsasia.com/business/genesis-reaches-21-million-sec-settlement-bankruptcy-wind-down-4093371)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T21:03:38+00:00



## Amazon beats sales estimates on cloud strength, shares rise
 - [https://www.channelnewsasia.com/business/amazon-beats-sales-estimates-cloud-strength-shares-rise-4093376](https://www.channelnewsasia.com/business/amazon-beats-sales-estimates-cloud-strength-shares-rise-4093376)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T21:03:06+00:00



## Climate activist Greta Thunberg defied police at protest, court hears
 - [https://www.channelnewsasia.com/world/climate-activist-greta-thunberg-defied-police-protest-court-hears-4092381](https://www.channelnewsasia.com/world/climate-activist-greta-thunberg-defied-police-protest-court-hears-4092381)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T20:33:00+00:00



## Hamilton's Ferrari move was always on the cards
 - [https://www.channelnewsasia.com/sport/hamiltons-ferrari-move-was-always-cards-4093321](https://www.channelnewsasia.com/sport/hamiltons-ferrari-move-was-always-cards-4093321)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T20:19:20+00:00



## Who might replace Hamilton at Mercedes?
 - [https://www.channelnewsasia.com/sport/who-might-replace-hamilton-mercedes-4093301](https://www.channelnewsasia.com/sport/who-might-replace-hamilton-mercedes-4093301)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T20:01:01+00:00



## Dutch software firm MessageBird rebrands as Bird, slashes prices
 - [https://www.channelnewsasia.com/business/dutch-software-firm-messagebird-rebrands-bird-slashes-prices-4093291](https://www.channelnewsasia.com/business/dutch-software-firm-messagebird-rebrands-bird-slashes-prices-4093291)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T19:56:22+00:00



## Biden imposes sanctions over 'intolerable' Israeli settler violence
 - [https://www.channelnewsasia.com/world/biden-imposes-sanctions-over-intolerable-israeli-settler-violence-4092941](https://www.channelnewsasia.com/world/biden-imposes-sanctions-over-intolerable-israeli-settler-violence-4092941)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T19:55:47+00:00



## Analysis:Shifting Tesla incorporation to Texas may not give Musk what he wants
 - [https://www.channelnewsasia.com/business/analysisshifting-tesla-incorporation-texas-may-not-give-musk-what-he-wants-4093206](https://www.channelnewsasia.com/business/analysisshifting-tesla-incorporation-texas-may-not-give-musk-what-he-wants-4093206)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T19:26:27+00:00



## Crystal Palace sign Wharton from Blackburn
 - [https://www.channelnewsasia.com/sport/crystal-palace-sign-wharton-blackburn-4093166](https://www.channelnewsasia.com/sport/crystal-palace-sign-wharton-blackburn-4093166)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T19:17:44+00:00



## Poland's Gaz-System chooses Mitsui O.S.K. Lines for floating unit
 - [https://www.channelnewsasia.com/business/polands-gaz-system-chooses-mitsui-osk-lines-floating-unit-4093171](https://www.channelnewsasia.com/business/polands-gaz-system-chooses-mitsui-osk-lines-floating-unit-4093171)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T19:17:27+00:00



## TikTok users losing access to Taylor Swift, Billie Eilish songs
 - [https://www.channelnewsasia.com/business/tiktok-users-losing-access-taylor-swift-billie-eilish-songs-4093161](https://www.channelnewsasia.com/business/tiktok-users-losing-access-taylor-swift-billie-eilish-songs-4093161)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T19:16:40+00:00



## Hamilton to leave Mercedes at end of 2024 F1 season
 - [https://www.channelnewsasia.com/sport/hamilton-leave-mercedes-end-2024-f1-season-4093141](https://www.channelnewsasia.com/sport/hamilton-leave-mercedes-end-2024-f1-season-4093141)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T19:12:54+00:00



## Messi on bench for Inter Miami v Al-Nassr
 - [https://www.channelnewsasia.com/sport/messi-bench-inter-miami-v-al-nassr-4093126](https://www.channelnewsasia.com/sport/messi-bench-inter-miami-v-al-nassr-4093126)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T19:05:31+00:00



## Japan's Ito leaves Asian Cup after sexual assault allegation
 - [https://www.channelnewsasia.com/world/japans-ito-leaves-asian-cup-after-sexual-assault-allegation-4093096](https://www.channelnewsasia.com/world/japans-ito-leaves-asian-cup-after-sexual-assault-allegation-4093096)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T19:03:35+00:00



## Messi late cameo as Ronaldoless Al-Nassr crush Inter Miami
 - [https://www.channelnewsasia.com/sport/messi-late-cameo-ronaldoless-al-nassr-crush-inter-miami-4093061](https://www.channelnewsasia.com/sport/messi-late-cameo-ronaldoless-al-nassr-crush-inter-miami-4093061)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T18:48:19+00:00



## Messi on bench for Inter Miami v Al-Nassr
 - [https://www.channelnewsasia.com/sport/messi-bench-inter-miami-v-al-nassr-4093061](https://www.channelnewsasia.com/sport/messi-bench-inter-miami-v-al-nassr-4093061)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T18:48:19+00:00



## US approves strikes against Iranian targets in Iraq, Syria: CBS News
 - [https://www.channelnewsasia.com/world/us-approves-strikes-against-iranian-targets-iraq-syria-cbs-news-4093001](https://www.channelnewsasia.com/world/us-approves-strikes-against-iranian-targets-iraq-syria-cbs-news-4093001)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T18:36:23+00:00

CBS News reports that the "multi-day strikes" in Iraq and Syria have been approved, targeting "Iranian personnel and facility".
The military operation is in response to strikes that killed US personnel at a base in Jordan.

## Songs by Taylor Swift, Drake and more are starting to disappear from TikTok. Here's why
 - [https://www.channelnewsasia.com/business/songs-taylor-swift-drake-and-more-are-starting-disappear-tiktok-heres-why-4092496](https://www.channelnewsasia.com/business/songs-taylor-swift-drake-and-more-are-starting-disappear-tiktok-heres-why-4092496)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T17:42:08+00:00



## Analysis:Volvo's Polestar troubles signal 'shakeout time' for EV industry
 - [https://www.channelnewsasia.com/business/analysisvolvos-polestar-troubles-signal-shakeout-time-ev-industry-4092901](https://www.channelnewsasia.com/business/analysisvolvos-polestar-troubles-signal-shakeout-time-ev-industry-4092901)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T17:25:25+00:00



## Elon Musk bashed by heavy metal drummer who cost him $56 billion
 - [https://www.channelnewsasia.com/business/elon-musk-bashed-heavy-metal-drummer-who-cost-him-56-billion-4092826](https://www.channelnewsasia.com/business/elon-musk-bashed-heavy-metal-drummer-who-cost-him-56-billion-4092826)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T17:08:06+00:00



## Botafogo sign Henrique from Betis for Brazilian record fee
 - [https://www.channelnewsasia.com/sport/botafogo-sign-henrique-betis-brazilian-record-fee-4092831](https://www.channelnewsasia.com/sport/botafogo-sign-henrique-betis-brazilian-record-fee-4092831)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T17:05:51+00:00



## Russian court fines Amazon 2 million roubles for failing to remove banned content -court
 - [https://www.channelnewsasia.com/business/russian-court-fines-amazon-2-million-roubles-failing-remove-banned-content-court-4092806](https://www.channelnewsasia.com/business/russian-court-fines-amazon-2-million-roubles-failing-remove-banned-content-court-4092806)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T16:53:08+00:00



## US defence chief apologises for concealing cancer hospitalisation
 - [https://www.channelnewsasia.com/world/us-defence-chief-apologises-concealing-cancer-hospitalisation-4092691](https://www.channelnewsasia.com/world/us-defence-chief-apologises-concealing-cancer-hospitalisation-4092691)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T16:39:07+00:00



## Italy's Allan aiming for first Rome win in Six Nations
 - [https://www.channelnewsasia.com/sport/italys-allan-aiming-first-rome-win-six-nations-4092786](https://www.channelnewsasia.com/sport/italys-allan-aiming-first-rome-win-six-nations-4092786)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T16:34:49+00:00



## Exclusive-Meta to deploy in-house custom chips this year to power AI drive - memo
 - [https://www.channelnewsasia.com/business/exclusive-meta-deploy-house-custom-chips-year-power-ai-drive-memo-4092731](https://www.channelnewsasia.com/business/exclusive-meta-deploy-house-custom-chips-year-power-ai-drive-memo-4092731)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T16:21:49+00:00



## Sorry no longer the hardest word at Cup of Nations
 - [https://www.channelnewsasia.com/sport/sorry-no-longer-hardest-word-cup-nations-4092671](https://www.channelnewsasia.com/sport/sorry-no-longer-hardest-word-cup-nations-4092671)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T15:58:42+00:00



## Activist investor Elliott gains board seat at Etsy
 - [https://www.channelnewsasia.com/business/activist-investor-elliott-gains-board-seat-etsy-4092666](https://www.channelnewsasia.com/business/activist-investor-elliott-gains-board-seat-etsy-4092666)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T15:54:43+00:00



## Activist investor Elliott gains seat at Etsy, has 13% economic stake in company
 - [https://www.channelnewsasia.com/business/activist-investor-elliott-gains-seat-etsy-has-13-economic-stake-company-4092666](https://www.channelnewsasia.com/business/activist-investor-elliott-gains-seat-etsy-has-13-economic-stake-company-4092666)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T15:54:43+00:00



## Big Tech move into finance to come under closer EU scrutiny
 - [https://www.channelnewsasia.com/business/big-tech-move-finance-come-under-closer-eu-scrutiny-4092576](https://www.channelnewsasia.com/business/big-tech-move-finance-come-under-closer-eu-scrutiny-4092576)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T15:25:10+00:00



## Tata, Pegatron in partnership talks for iPhone assembly in India's Tamil Nadu - sources
 - [https://www.channelnewsasia.com/business/tata-pegatron-partnership-talks-iphone-assembly-indias-tamil-nadu-sources-4092486](https://www.channelnewsasia.com/business/tata-pegatron-partnership-talks-iphone-assembly-indias-tamil-nadu-sources-4092486)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T14:40:17+00:00



## Russell leads Scotland against Wales as Darge misses out
 - [https://www.channelnewsasia.com/sport/russell-leads-scotland-against-wales-darge-misses-out-4092451](https://www.channelnewsasia.com/sport/russell-leads-scotland-against-wales-darge-misses-out-4092451)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T14:31:18+00:00



## Ford at flyhalf for England v Italy, debuts for Dingwall and Roots
 - [https://www.channelnewsasia.com/sport/ford-flyhalf-england-v-italy-debuts-dingwall-and-roots-4092371](https://www.channelnewsasia.com/sport/ford-flyhalf-england-v-italy-debuts-dingwall-and-roots-4092371)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T14:10:22+00:00



## Hamas unlikely to reject ceasefire but will demand Israeli withdrawal: Report
 - [https://www.channelnewsasia.com/world/hamas-unlikely-reject-ceasefire-will-demand-israeli-withdrawal-report-4092011](https://www.channelnewsasia.com/world/hamas-unlikely-reject-ceasefire-will-demand-israeli-withdrawal-report-4092011)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T13:49:00+00:00



## Financial rules keep teams like Newcastle quiet in January window
 - [https://www.channelnewsasia.com/sport/financial-rules-keep-teams-newcastle-quiet-january-window-4092311](https://www.channelnewsasia.com/sport/financial-rules-keep-teams-newcastle-quiet-january-window-4092311)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T13:46:30+00:00



## Orchard no-smoking zone expanded to include skate park outside Somerset MRT station
 - [https://www.channelnewsasia.com/singapore/orchard-road-no-smoking-zone-expanded-somerset-skate-part-trifecta-4092251](https://www.channelnewsasia.com/singapore/orchard-road-no-smoking-zone-expanded-somerset-skate-part-trifecta-4092251)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T13:38:56+00:00



## Alpine skiing-Kilde uncertain he can return to his best after horror crash
 - [https://www.channelnewsasia.com/sport/alpine-skiing-kilde-uncertain-he-can-return-his-best-after-horror-crash-4092261](https://www.channelnewsasia.com/sport/alpine-skiing-kilde-uncertain-he-can-return-his-best-after-horror-crash-4092261)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T13:16:22+00:00



## Neuralink rival Synchron takes stake in medical component maker Acquandas
 - [https://www.channelnewsasia.com/business/neuralink-rival-synchron-takes-stake-medical-component-maker-acquandas-4092241](https://www.channelnewsasia.com/business/neuralink-rival-synchron-takes-stake-medical-component-maker-acquandas-4092241)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T13:08:04+00:00



## Three Japanese hires in a row? 'No agenda', says FAS president Bernard Tan
 - [https://www.channelnewsasia.com/sport/football-lions-japanese-head-coach-tsutomo-ogura-fas-president-bernard-tan-4091711](https://www.channelnewsasia.com/sport/football-lions-japanese-head-coach-tsutomo-ogura-fas-president-bernard-tan-4091711)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T12:43:00+00:00

New Lions head coach Tsutomu Ogura, the third straight Japanese in the role, was unveiled on Thursday (Feb 1).

## Garbisi at scrumhalf for Italy against England
 - [https://www.channelnewsasia.com/sport/garbisi-scrumhalf-italy-against-england-4092146](https://www.channelnewsasia.com/sport/garbisi-scrumhalf-italy-against-england-4092146)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T12:40:25+00:00



## Russia says it has evidence US Patriot missiles downed its military transport plane
 - [https://www.channelnewsasia.com/world/russia-says-it-has-evidence-us-patriot-missiles-downed-its-military-transport-plane-4091856](https://www.channelnewsasia.com/world/russia-says-it-has-evidence-us-patriot-missiles-downed-its-military-transport-plane-4091856)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T12:31:00+00:00



## Winnett debuts at fullback for Wales against Scotland
 - [https://www.channelnewsasia.com/sport/winnett-debuts-fullback-wales-against-scotland-4092106](https://www.channelnewsasia.com/sport/winnett-debuts-fullback-wales-against-scotland-4092106)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T12:25:27+00:00



## EU strikes Ukraine aid deal, overcoming Hungary objections
 - [https://www.channelnewsasia.com/world/eu-strikes-ukraine-aid-deal-overcoming-hungary-objections-4090686](https://www.channelnewsasia.com/world/eu-strikes-ukraine-aid-deal-overcoming-hungary-objections-4090686)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T12:15:07+00:00



## Cadence to sell AI supercomputer for jet design software
 - [https://www.channelnewsasia.com/business/cadence-sell-ai-supercomputer-jet-design-software-4092046](https://www.channelnewsasia.com/business/cadence-sell-ai-supercomputer-jet-design-software-4092046)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T12:07:16+00:00



## Ice Hockey-Sport a balm for 91-yr-old analyst Fischler amid Gaza war
 - [https://www.channelnewsasia.com/sport/ice-hockey-sport-balm-91-yr-old-analyst-fischler-amid-gaza-war-4092051](https://www.channelnewsasia.com/sport/ice-hockey-sport-balm-91-yr-old-analyst-fischler-amid-gaza-war-4092051)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T12:05:56+00:00



## S.Africa's MultiChoice TV, NBCUniversal to invest $177 million in Showmax
 - [https://www.channelnewsasia.com/business/safricas-multichoice-tv-nbcuniversal-invest-177-million-showmax-4092026](https://www.channelnewsasia.com/business/safricas-multichoice-tv-nbcuniversal-invest-177-million-showmax-4092026)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T12:02:00+00:00



## Villa sign Rogers from Middlesbrough
 - [https://www.channelnewsasia.com/sport/villa-sign-rogers-middlesbrough-4091976](https://www.channelnewsasia.com/sport/villa-sign-rogers-middlesbrough-4091976)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T11:43:31+00:00



## Linde secures renewable energy from China for next 25 years
 - [https://www.channelnewsasia.com/business/linde-secures-renewable-energy-china-next-25-years-4091921](https://www.channelnewsasia.com/business/linde-secures-renewable-energy-china-next-25-years-4091921)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T11:16:50+00:00



## US, Japan conduct joint naval drills
 - [https://www.channelnewsasia.com/world/us-japan-conduct-joint-naval-drills-4091841](https://www.channelnewsasia.com/world/us-japan-conduct-joint-naval-drills-4091841)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T11:15:28+00:00



## CNA Explains: What’s happened since Myanmar’s coup 3 years ago?
 - [https://www.channelnewsasia.com/asia/myanmar-coup-3-years-anniversary-cna-explains-timeline-junta-4091861](https://www.channelnewsasia.com/asia/myanmar-coup-3-years-anniversary-cna-explains-timeline-junta-4091861)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T11:13:00+00:00

The turmoil of recent years has now culminated in contrasting fortunes for the junta and the resistance.

## Regulatory nod for US spot bitcoin ETF options may take months- sources
 - [https://www.channelnewsasia.com/business/regulatory-nod-us-spot-bitcoin-etf-options-may-take-months-sources-4091891](https://www.channelnewsasia.com/business/regulatory-nod-us-spot-bitcoin-etf-options-may-take-months-sources-4091891)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T11:04:34+00:00



## Hyundai Motor to supply Italy's Iveco with new electric van for Europe
 - [https://www.channelnewsasia.com/business/hyundai-motor-supply-italys-iveco-new-electric-van-europe-4091876](https://www.channelnewsasia.com/business/hyundai-motor-supply-italys-iveco-new-electric-van-europe-4091876)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T10:59:47+00:00



## Hamilton set for shock switch to Ferrari in 2025: Reports
 - [https://www.channelnewsasia.com/sport/lewis-hamilton-shock-switch-mercedes-ferrari-formula-one-4091871](https://www.channelnewsasia.com/sport/lewis-hamilton-shock-switch-mercedes-ferrari-formula-one-4091871)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T10:56:00+00:00



## Ex-PM Imran Khan's leak of secret cable hurt Pakistan: Court ruling
 - [https://www.channelnewsasia.com/asia/ex-pm-imran-khans-leak-secret-cable-hurt-pakistan-court-ruling-4091586](https://www.channelnewsasia.com/asia/ex-pm-imran-khans-leak-secret-cable-hurt-pakistan-court-ruling-4091586)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T10:53:14+00:00



## Maid jailed for spending over S$15,000 that was wrongly transferred to her by insurance company
 - [https://www.channelnewsasia.com/singapore/maid-spent-15k-wrongly-transferred-insurance-company-tokio-marine-4091806](https://www.channelnewsasia.com/singapore/maid-spent-15k-wrongly-transferred-insurance-company-tokio-marine-4091806)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T10:48:27+00:00

By the time DBS Bank contacted her to return the money, she had already spent most of it on her own expenses, including a trip to her hometown.

## Singapore Airlines ranks 29th on list of most admired companies in the world, is 2nd-highest placed Asian company
 - [https://www.channelnewsasia.com/travel/singapore-airlines-fortune-magazine-list-most-admired-companies-4091016](https://www.channelnewsasia.com/travel/singapore-airlines-fortune-magazine-list-most-admired-companies-4091016)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T05:53:56+00:00

Singapore Airlines is also the only Singapore-based company in Fortune magazine's top 50 list.

## Pakistan ex-PM Khan's wife back home after residence declared 'sub-jail'
 - [https://www.channelnewsasia.com/asia/pakistan-imran-khan-wife-bushra-bibi-serve-sentence-home-jail-4091176](https://www.channelnewsasia.com/asia/pakistan-imran-khan-wife-bushra-bibi-serve-sentence-home-jail-4091176)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T05:51:34+00:00



## Singapore visitor arrivals up 115% to 13.6 million in 2023
 - [https://www.channelnewsasia.com/singapore/singapore-tourism-increase-visitor-arrival-136-million-2023-stb-4091076](https://www.channelnewsasia.com/singapore/singapore-tourism-increase-visitor-arrival-136-million-2023-stb-4091076)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T05:45:00+00:00

The number of visitors to Singapore in 2023 is about 71 per cent of pre-pandemic levels.

## Human Rights Watch warns carmakers over China forced labour risk
 - [https://www.channelnewsasia.com/business/human-rights-watch-warns-carmakers-over-china-forced-labour-risk-4091171](https://www.channelnewsasia.com/business/human-rights-watch-warns-carmakers-over-china-forced-labour-risk-4091171)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T05:09:25+00:00



## Fake banknotes syndicate busted in Indonesia after S$10,000 notes presented at Singapore casino
 - [https://www.channelnewsasia.com/singapore/fake-banknotes-syndicate-indonesia-singapore-casino-10000-4090961](https://www.channelnewsasia.com/singapore/fake-banknotes-syndicate-indonesia-singapore-casino-10000-4090961)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T05:08:00+00:00

An Indonesian couple allegedly tried to exchange a S$10,000 note for casino chips while they were in Singapore.

## Football Australia investigating 'possible data breach'
 - [https://www.channelnewsasia.com/sport/football-australia-investigating-possible-data-breach-4091121](https://www.channelnewsasia.com/sport/football-australia-investigating-possible-data-breach-4091121)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T05:01:00+00:00



## Rebecca Lim gives birth to baby boy: 'This will be an unforgettable Lunar New Year'
 - [https://www.channelnewsasia.com/entertainment/rebecca-lim-gives-birth-baby-boy-4091096](https://www.channelnewsasia.com/entertainment/rebecca-lim-gives-birth-baby-boy-4091096)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T04:53:00+00:00

Rebecca shared that it was a natural birth and she experienced "14 hours of labour pain". The baby was born on Jan 30.

## Shopee sues ex-senior employee to stop him from working for 'competitor' ByteDance, citing non-compete clause
 - [https://www.channelnewsasia.com/singapore/court-dismiss-shopee-case-senior-employee-join-bytedance-non-compete-lim-teck-yong-4091011](https://www.channelnewsasia.com/singapore/court-dismiss-shopee-case-senior-employee-join-bytedance-non-compete-lim-teck-yong-4091011)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T04:33:19+00:00

Shopee sought to prevent Mr Lim Teck Yong from working for ByteDance, which owns TikTok and a related e-commerce platform, saying he had breached a non-competition clause.

## Indonesia Jan inflation eases to 2.57%, in line with forecast
 - [https://www.channelnewsasia.com/business/indonesia-jan-inflation-eases-257-line-forecast-4091091](https://www.channelnewsasia.com/business/indonesia-jan-inflation-eases-257-line-forecast-4091091)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T04:21:47+00:00



## ECB to set up three-tiered competition to boost women's game
 - [https://www.channelnewsasia.com/sport/ecb-set-three-tiered-competition-boost-womens-game-4091081](https://www.channelnewsasia.com/sport/ecb-set-three-tiered-competition-boost-womens-game-4091081)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T04:18:00+00:00



## US slashes estimates on Vietnam rare earths mining output
 - [https://www.channelnewsasia.com/business/us-slashes-estimates-vietnam-rare-earths-mining-output-4091056](https://www.channelnewsasia.com/business/us-slashes-estimates-vietnam-rare-earths-mining-output-4091056)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T04:01:12+00:00



## Official statement on ex-Malaysian PM Najib's pardon expected this week: Minister
 - [https://www.channelnewsasia.com/asia/former-malaysia-prime-minister-najib-razak-official-statement-royal-pardon-expected-4090991](https://www.channelnewsasia.com/asia/former-malaysia-prime-minister-najib-razak-official-statement-royal-pardon-expected-4090991)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T03:47:31+00:00



## Mighty Jaxx figurines in Argylle: How the Singapore company ended up in a Hollywood spy movie
 - [https://www.channelnewsasia.com/entertainment/argylle-mighty-jaxx-collectibles-figurines-matthew-vaughn-4090671](https://www.channelnewsasia.com/entertainment/argylle-mighty-jaxx-collectibles-figurines-matthew-vaughn-4090671)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T03:30:00+00:00

Mighty Jaxx’s Jackson Aw tells CNA Lifestyle how the company got involved in Matthew Vaughn’s new movie – and how their figurines got a lot of screen time.

## Elmo responds to angsty replies following viral wellness check post
 - [https://www.channelnewsasia.com/entertainment/elmo-wellness-check-post-responses-4090676](https://www.channelnewsasia.com/entertainment/elmo-wellness-check-post-responses-4090676)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T03:08:39+00:00

On Jan 29, Sesame Street character Elmo made a wellness check post on social media platform X – prompting tens of thousands of responses from users lamenting their lives.

## Asia's factories struggle for momentum amid soft Chinese demand
 - [https://www.channelnewsasia.com/business/asias-factories-struggle-momentum-amid-soft-chinese-demand-4090866](https://www.channelnewsasia.com/business/asias-factories-struggle-momentum-amid-soft-chinese-demand-4090866)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T03:02:00+00:00



## China's fiscal revenue growth picks up in 2023
 - [https://www.channelnewsasia.com/business/chinas-fiscal-revenue-growth-picks-2023-4090871](https://www.channelnewsasia.com/business/chinas-fiscal-revenue-growth-picks-2023-4090871)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:59:42+00:00



## Tesla China offers cash discounts for some Model Y types
 - [https://www.channelnewsasia.com/business/tesla-china-offers-cash-discounts-some-model-y-types-4090846](https://www.channelnewsasia.com/business/tesla-china-offers-cash-discounts-some-model-y-types-4090846)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:54:39+00:00



## Can Taylor Swift get to the Super Bowl for Travis Kelce? A timeline from the Grammys and beyond
 - [https://www.channelnewsasia.com/entertainment/can-taylor-swift-get-super-bowl-4090826](https://www.channelnewsasia.com/entertainment/can-taylor-swift-get-super-bowl-4090826)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:51:45+00:00

What does Swift's jet-set lifestyle look like for the next two weeks?

## Can Taylor Swift get to the Super Bowl for Travis Kelce? A timeline from the Grammys and beyond
 - [https://www.channelnewsasia.com/entertainment/taylor-swift-super-bowl-grammys-travis-kelce-can-she-make-it-4090826](https://www.channelnewsasia.com/entertainment/taylor-swift-super-bowl-grammys-travis-kelce-can-she-make-it-4090826)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:51:00+00:00

What does Swift's jet-set lifestyle look like for the next two weeks?

## China Jan new home prices rise at fastest pace since Aug 2021 -private survey
 - [https://www.channelnewsasia.com/business/china-jan-new-home-prices-rise-fastest-pace-aug-2021-private-survey-4090816](https://www.channelnewsasia.com/business/china-jan-new-home-prices-rise-fastest-pace-aug-2021-private-survey-4090816)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:39:45+00:00



## China new home prices rise at fastest pace in nearly 2-1/2 years -private survey
 - [https://www.channelnewsasia.com/business/china-new-home-prices-rise-fastest-pace-nearly-2-1-2-years-private-survey-4090816](https://www.channelnewsasia.com/business/china-new-home-prices-rise-fastest-pace-nearly-2-1-2-years-private-survey-4090816)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:39:45+00:00



## Popular hawker stall Zhang Ji Shanghai La Mian Xiao Long Bao opens mall outlet
 - [https://www.channelnewsasia.com/dining/zhang-ji-shanghai-la-mian-xiao-long-bao-new-alexandra-retail-centre-mall-outlet-4090621](https://www.channelnewsasia.com/dining/zhang-ji-shanghai-la-mian-xiao-long-bao-new-alexandra-retail-centre-mall-outlet-4090621)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:37:51+00:00

The new outlet is at Alexandra Retail Centre (ARC).

## Balloon businesses turn to alternative products as helium prices increase amid shortage
 - [https://www.channelnewsasia.com/singapore/why-helium-balloons-more-expensive-shortage-4090746](https://www.channelnewsasia.com/singapore/why-helium-balloons-more-expensive-shortage-4090746)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:34:30+00:00

The price of helium, a finite resource, has more than tripled, businesses said.

## Super Bowl-bound Chiefs tight end Travis Kelce to Taylor Swift: 'Thanks for joining the team'
 - [https://www.channelnewsasia.com/entertainment/travis-kelce-thanks-taylor-swift-4090766](https://www.channelnewsasia.com/entertainment/travis-kelce-thanks-taylor-swift-4090766)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:32:58+00:00

On the latest episode of their New Heights podcast, the Chiefs tight end and his brother, Eagles centre Jason Kelce, joked about how Swift has come along at just the right time.

## KKR raises $6.4 billion for biggest Asia Pacific infrastructure fund
 - [https://www.channelnewsasia.com/business/kkr-raises-64-billion-biggest-asia-pacific-infrastructure-fund-4090721](https://www.channelnewsasia.com/business/kkr-raises-64-billion-biggest-asia-pacific-infrastructure-fund-4090721)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:17:01+00:00



## KKR raises $6.4 billion for its Asian infrastructure fund
 - [https://www.channelnewsasia.com/business/kkr-raises-64-billion-its-asian-infrastructure-fund-4090721](https://www.channelnewsasia.com/business/kkr-raises-64-billion-its-asian-infrastructure-fund-4090721)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:17:01+00:00



## Conspiracy theories of Taylor Swift and Travis Kelce emerge following Kansas City Chiefs’ advancement to the Super Bowl
 - [https://www.channelnewsasia.com/entertainment/conspiracy-theories-taylor-swift-and-travis-kelce-emerge-following-kansas-city-chiefs-advancement-super-bowl-4090416](https://www.channelnewsasia.com/entertainment/conspiracy-theories-taylor-swift-and-travis-kelce-emerge-following-kansas-city-chiefs-advancement-super-bowl-4090416)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:12:38+00:00

Claims include Swift being part of a Pentagon psychological operation.

## Oil edges up on US Fed rate signals, China property sector support
 - [https://www.channelnewsasia.com/business/oil-edges-us-fed-rate-signals-china-property-sector-support-4090711](https://www.channelnewsasia.com/business/oil-edges-us-fed-rate-signals-china-property-sector-support-4090711)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T02:00:25+00:00



## Dollar hovers near 7-week high as Fed cut bets shift to May
 - [https://www.channelnewsasia.com/business/dollar-hovers-near-7-week-high-fed-cut-bets-shift-may-4090706](https://www.channelnewsasia.com/business/dollar-hovers-near-7-week-high-fed-cut-bets-shift-may-4090706)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T01:57:35+00:00



## China's factory activity expands on export order boost - Caixin PMI
 - [https://www.channelnewsasia.com/business/chinas-factory-activity-expands-export-order-boost-caixin-pmi-4090691](https://www.channelnewsasia.com/business/chinas-factory-activity-expands-export-order-boost-caixin-pmi-4090691)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T01:52:43+00:00



## Asia ponders Fed fallout, bonds still bullish on rate cuts
 - [https://www.channelnewsasia.com/business/asia-ponders-fed-fallout-bonds-still-bullish-rate-cuts-4090696](https://www.channelnewsasia.com/business/asia-ponders-fed-fallout-bonds-still-bullish-rate-cuts-4090696)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T01:49:00+00:00



## Indonesia's economy likely to have grown 5% in Q4: Reuters poll
 - [https://www.channelnewsasia.com/business/indonesias-economy-likely-have-grown-5-q4-reuters-poll-4090681](https://www.channelnewsasia.com/business/indonesias-economy-likely-have-grown-5-q4-reuters-poll-4090681)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T01:45:42+00:00



## Harnessing Slack’s intelligence to set a new standard for cross-functional teamwork
 - [https://www.channelnewsasia.com/advertorial/harnessing-slacks-intelligence-set-new-standard-cross-functional-teamwork-4048851](https://www.channelnewsasia.com/advertorial/harnessing-slacks-intelligence-set-new-standard-cross-functional-teamwork-4048851)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T01:28:32+00:00

Discover how ShopBack is leveraging the versatile capabilities of this productivity platform to streamline operations, foster transparent communication and drive innovation.

## TikTok's Singaporean CEO grilled by US senator about Chinese Communist Party links
 - [https://www.channelnewsasia.com/business/tiktok-singaporean-ceo-chew-shou-zi-grilled-us-senator-china-links-4090546](https://www.channelnewsasia.com/business/tiktok-singaporean-ceo-chew-shou-zi-grilled-us-senator-china-links-4090546)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T01:25:00+00:00

TikTok CEO Chew Shou Zi was testifying at the Big Tech and the Online Child Sexual Exploitation Crisis session convened by the US Senate.

## South Korea factory activity expands for first time in 19 months - PMI
 - [https://www.channelnewsasia.com/business/south-korea-factory-activity-expands-first-time-19-months-pmi-4090646](https://www.channelnewsasia.com/business/south-korea-factory-activity-expands-first-time-19-months-pmi-4090646)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T01:21:06+00:00



## Singapore's Keppel annual profit quadruples on marine unit sale
 - [https://www.channelnewsasia.com/business/singapore-keppel-annual-profit-quadruples-marine-unit-sale-4090511](https://www.channelnewsasia.com/business/singapore-keppel-annual-profit-quadruples-marine-unit-sale-4090511)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T01:20:00+00:00



## Year of the dragon: 5 artist-approved collaborations to add that proverbial stroke of luck
 - [https://www.channelnewsasia.com/style-beauty/chinese-new-year-dragon-art-fashion-bags-4088211](https://www.channelnewsasia.com/style-beauty/chinese-new-year-dragon-art-fashion-bags-4088211)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T01:01:00+00:00

After all, not just any old dragon will do.

## Japan Jan factory activity shrinks modestly on softer demand - PMI
 - [https://www.channelnewsasia.com/business/japan-jan-factory-activity-shrinks-modestly-softer-demand-pmi-4090601](https://www.channelnewsasia.com/business/japan-jan-factory-activity-shrinks-modestly-softer-demand-pmi-4090601)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T00:35:37+00:00



## S Korea exports rise for fourth month on surge in chip sales, China rebound
 - [https://www.channelnewsasia.com/business/s-korea-exports-rise-fourth-month-surge-chip-sales-china-rebound-4090591](https://www.channelnewsasia.com/business/s-korea-exports-rise-fourth-month-surge-chip-sales-china-rebound-4090591)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T00:25:49+00:00



## South Korea Jan exports rise for fourth month, chip sales surge
 - [https://www.channelnewsasia.com/business/south-korea-jan-exports-rise-fourth-month-chip-sales-surge-4090591](https://www.channelnewsasia.com/business/south-korea-jan-exports-rise-fourth-month-chip-sales-surge-4090591)
 - RSS feed: https://www.channelnewsasia.com/api/v1/rss-outbound-feed?_format=xml
 - date published: 2024-02-01T00:25:49+00:00



