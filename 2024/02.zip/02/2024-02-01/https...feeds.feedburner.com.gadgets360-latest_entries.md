# Source:Gadgets 360, URL:https://feeds.feedburner.com/gadgets360-latest, language:en

## Vivo Y200 5G Now Available in 256GB Storage Variant; Vivo Y27 4G, Vivo T2 5G Prices Cut in India
 - [https://www.gadgets360.com/mobiles/news/vivo-y200-5g-price-in-india-new-256gb-variant-y27-4g-t2-cut-4974117](https://www.gadgets360.com/mobiles/news/vivo-y200-5g-price-in-india-new-256gb-variant-y27-4g-t2-cut-4974117)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T13:45:24+00:00

Vivo Y200 5G is offered in India in Desert Gold and Jungle Green colourways

## Nothing Phone 2a Confirmed to Launch Soon in India; Teased to Offer Upgrades Over Phone 1
 - [https://www.gadgets360.com/mobiles/news/nothing-phone-2a-india-launch-teaser-announcement-specifications-4974086](https://www.gadgets360.com/mobiles/news/nothing-phone-2a-india-launch-teaser-announcement-specifications-4974086)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T12:12:23+00:00

Nothing has launched two phones so far — Nothing Phone 1 and Nothing Phone 2

## India’s Crypto Industry Misses Mention in FM’s Budget 2024 Speech, No Change in Taxes
 - [https://www.gadgets360.com/cryptocurrency/news/india-budget-2024-crypto-misses-mention-nirmala-sitharaman-no-tax-change-4974202](https://www.gadgets360.com/cryptocurrency/news/india-budget-2024-crypto-misses-mention-nirmala-sitharaman-no-tax-change-4974202)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T12:03:00+00:00

India reportedly houses over 19 million crypto investors

## India Smartphone Shipments Grew 25 Percent YoY in Q4 2023, Xiaomi Climbs to the Top: Counterpoint
 - [https://www.gadgets360.com/mobiles/news/india-smartphone-shipments-q4-2023-xiaomi-samsung-vivo-realme-oppo-counterpoint-4974137](https://www.gadgets360.com/mobiles/news/india-smartphone-shipments-q4-2023-xiaomi-samsung-vivo-realme-oppo-counterpoint-4974137)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T11:57:18+00:00

Despite 25 percent growth in Q4, Indian smartphone shipments remained flat in 2023 with 152 million units

## TRAI Aims to Tackle Call Drops Issue With Regulations; Improve Connectivity Inside Buildings
 - [https://www.gadgets360.com/telecom/news/trai-call-drops-issue-regulation-improve-qos-connectivity-4973816](https://www.gadgets360.com/telecom/news/trai-call-drops-issue-regulation-improve-qos-connectivity-4973816)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T11:42:58+00:00

Anil Kumar Lahoti (pictured) took over as TRAI Chairman on January 30

## Lava Yuva 3 Price in India, Design, Storage Details, Amazon Availability Confirmed
 - [https://www.gadgets360.com/mobiles/news/lava-yuva-3-india-price-launch-design-colour-option-storage-amazon-microsite-4973380](https://www.gadgets360.com/mobiles/news/lava-yuva-3-india-price-launch-design-colour-option-storage-amazon-microsite-4973380)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T11:29:16+00:00

Lava Yuva 3 seen in the teaser in a purple colour option

## Google Bard Advanced Confirmed to Get a Paid Subscription, to Be Powered by Gemini Ultra AI Model
 - [https://www.gadgets360.com/ai/news/google-bard-advanced-gemini-ultra-ai-model-paid-subscription-4973865](https://www.gadgets360.com/ai/news/google-bard-advanced-gemini-ultra-ai-model-paid-subscription-4973865)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T11:23:49+00:00

The details regarding the pricing and features of Google Bard Advanced have not been disclosed

## Xiaomi 14 Series May Soon Launch in India; Company Teases Leica Partnership
 - [https://www.gadgets360.com/mobiles/news/xiaomi-14-pro-ultra-india-launch-leica-partnership-teaser-specifications-4973698](https://www.gadgets360.com/mobiles/news/xiaomi-14-pro-ultra-india-launch-leica-partnership-teaser-specifications-4973698)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T11:12:03+00:00

Xiaomi 14 series runs on Snapdragon 8 Gen 3 SoC

## Reliance, Bodhi Tree Said to Take 60 Percent Stake in Disney India Merger
 - [https://www.gadgets360.com/entertainment/news/reliance-bodhi-tree-60-percent-stake-disney-india-operations-merger-4973748](https://www.gadgets360.com/entertainment/news/reliance-bodhi-tree-60-percent-stake-disney-india-operations-merger-4973748)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T10:56:23+00:00

Several top Disney India executives have joined Viacom18 in recent months

## Threads App Sees Rise in Downloads, Competitor X Falls in Top Downloaded Apps List: Report
 - [https://www.gadgets360.com/apps/news/threads-app-downloads-increase-instagram-adam-mosseri-meta-x-twitter-4972677](https://www.gadgets360.com/apps/news/threads-app-downloads-increase-instagram-adam-mosseri-meta-x-twitter-4972677)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T10:08:49+00:00

Meta's Instagram launched Threads in July 2023

## Rise of the Ronin, Stellar Blade, Death Stranding 2: Everything Announced at PlayStation's State of Play
 - [https://www.gadgets360.com/games/news/state-of-play-playstation-sony-rise-of-the-ronin-stellar-blade-death-stranding-2-judas-ps5-ps-vr2-4973218](https://www.gadgets360.com/games/news/state-of-play-playstation-sony-rise-of-the-ronin-stellar-blade-death-stranding-2-judas-ps5-ps-vr2-4973218)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T10:04:52+00:00

Death Stranding 2 brings back Norman Reedus as Sam Porter Bridges

## Android 15 Could Add Auracast Feature to 'Broadcast' Audio to Nearby Devices via Bluetooth LE: Report
 - [https://www.gadgets360.com/audio/news/android-15-bluetooth-le-auracast-feature-nearby-devices-4972822](https://www.gadgets360.com/audio/news/android-15-bluetooth-le-auracast-feature-nearby-devices-4972822)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T10:03:14+00:00

Google's future Pixel Buds models and other Android phones could offer Auracast support

## OnePlus Open Receiving Android 14-Based OxygenOS 14 Build in India
 - [https://www.gadgets360.com/mobiles/news/oneplus-open-android-14-oxygenos-update-india-changelog-4972917](https://www.gadgets360.com/mobiles/news/oneplus-open-android-14-oxygenos-update-india-changelog-4972917)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T09:01:50+00:00

OxygenOS 14 brings Aqua Dynamics with morphing forms for viewing up-to-date information

## WhatsApp Reportedly Working on a Chat Lock Feature for Web Users
 - [https://www.gadgets360.com/social-networking/news/whatsapp-web-chat-lock-feature-report-4972908](https://www.gadgets360.com/social-networking/news/whatsapp-web-chat-lock-feature-report-4972908)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T08:52:13+00:00

The WhatsApp Web Chat Lock feature is reportedly in development and could be available in a future update

## Xiaomi 14 Ultra Global Variant Reportedly Spotted on Geekbench; Key Details Tipped
 - [https://www.gadgets360.com/mobiles/news/xiaomi-14-ultra-geekbench-listing-specifications-report-4972079](https://www.gadgets360.com/mobiles/news/xiaomi-14-ultra-geekbench-listing-specifications-report-4972079)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T07:50:10+00:00

Xiaomi 14 Ultra is expected to succeed the Xiaomi 13 Ultra (pictured)

## Vivo X Fold 3 Series Tipped to Get OmniVision OV50H Main Camera
 - [https://www.gadgets360.com/mobiles/news/vivo-x-fold-3-pro-omnivision-ov50h-camera-unit-leak-weibo-4972324](https://www.gadgets360.com/mobiles/news/vivo-x-fold-3-pro-omnivision-ov50h-camera-unit-leak-weibo-4972324)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T07:42:16+00:00

Vivo X Fold 2 runs on Snapdragon 8 Gen 2 SoC

## Google Pixel 8, Pixel 8 Pro Get Circle to Search Feature Introduced on Samsung Galaxy S24 Series
 - [https://www.gadgets360.com/mobiles/news/google-pixel-8-pro-circle-to-search-feature-enabled-samsung-galaxy-s24-series-4972160](https://www.gadgets360.com/mobiles/news/google-pixel-8-pro-circle-to-search-feature-enabled-samsung-galaxy-s24-series-4972160)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T06:57:47+00:00

Google Pixel 8 series has gained the Circle to Search feature without an update

## Nothing Phone 1 Android 14-Based Nothing OS 2.5 Stable Update Rolling Out to Users
 - [https://www.gadgets360.com/mobiles/news/nothing-phone-1-android-14-os-2-5-stable-update-changelog-features-4971124](https://www.gadgets360.com/mobiles/news/nothing-phone-1-android-14-os-2-5-stable-update-changelog-features-4971124)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T06:15:45+00:00

Nothing Phone 1 launched in India in July 2022

## Crypto Price Today: Bitcoin, Ether See Losses as US Decides to Maintain Unchanged Interest Rates
 - [https://www.gadgets360.com/cryptocurrency/news/bitcoin-ether-price-today-usd-loss-cryptocurrency-solana-dogecoin-cardano-4971897](https://www.gadgets360.com/cryptocurrency/news/bitcoin-ether-price-today-usd-loss-cryptocurrency-solana-dogecoin-cardano-4971897)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T05:59:24+00:00

The overall crypto market cap stands at $1.51 trillion as of February 1

## Samsung Galaxy Z Fold 6 Early Renders Showcase Wider Displays and Slimmer Design
 - [https://www.gadgets360.com/mobiles/news/samsung-z-fold-6-renders-thin-wider-display-thin-build-patent-galaxy-leak-4971737](https://www.gadgets360.com/mobiles/news/samsung-z-fold-6-renders-thin-wider-display-thin-build-patent-galaxy-leak-4971737)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T05:45:47+00:00

Samsung Galaxy Z Fold 6 could offer a slimmer and wider design than the Galaxy Z Fold 5

## HMD Global Drops Nokia Branding From Official Website, X Account; Company Says HMD Devices Coming Soon
 - [https://www.gadgets360.com/mobiles/news/hmd-global-nokia-branding-rename-website-x-account-announcement-4971301](https://www.gadgets360.com/mobiles/news/hmd-global-nokia-branding-rename-website-x-account-announcement-4971301)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T04:22:05+00:00

Microsoft sold the rights to the Nokia brand to HMD Global in 2016 for ten years

## OnePlus 12 Receives First Software Update in India; Includes Master Mode With Hasselblad Colour Tuning
 - [https://www.gadgets360.com/mobiles/news/oneplus-12-update-oxygenos-changelog-camera-improvements-4971123](https://www.gadgets360.com/mobiles/news/oneplus-12-update-oxygenos-changelog-camera-improvements-4971123)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T04:05:31+00:00

OnePlus 12 seen in Flowy Emerald colourway

## OnePlus 12 Receives First Software Update in India; Gets Master Mode With Hasselblad Colour Tuning and More
 - [https://www.gadgets360.com/mobiles/news/oneplus-12-india-oxygenos-update-changelog-features-specifications-4971123](https://www.gadgets360.com/mobiles/news/oneplus-12-india-oxygenos-update-changelog-features-specifications-4971123)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2024-02-01T03:53:27+00:00

OnePlus 12 seen in Flowy Emerald colourway

