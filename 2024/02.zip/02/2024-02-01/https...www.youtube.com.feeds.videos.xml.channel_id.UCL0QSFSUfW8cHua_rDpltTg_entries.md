# Source:Call Me Chato, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg, language:en-US

## Disney movies WARNINGS.
 - [https://www.youtube.com/watch?v=A5eTdq1DI9k](https://www.youtube.com/watch?v=A5eTdq1DI9k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg
 - date published: 2024-02-01T21:05:57+00:00

#FormerNetworkExec #CallMeChato 
Thanks for watching my channel. Please subscribe, SHARE and touch yourselves.

Call Me Chato T-shirt
https://my-store-6121db.creator-spring.com/listing/ppc-cartoon-t-colour

https://twitter.com/PaulChato
http://www.paulchato.com

## Disney HATES its past!
 - [https://www.youtube.com/watch?v=58rGrqTFw04](https://www.youtube.com/watch?v=58rGrqTFw04)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg
 - date published: 2024-02-01T14:00:06+00:00

#FormerNetworkExec #CallMeChato #disney 
We know Disney hates Walt but now it looks like it hates all its classic original work, too.
Thanks for watching my channel. Please subscribe, SHARE and touch yourselves.

Call Me Chato T-shirt
https://my-store-6121db.creator-spring.com/listing/ppc-cartoon-t-colour

https://twitter.com/PaulChato
http://www.paulchato.com

