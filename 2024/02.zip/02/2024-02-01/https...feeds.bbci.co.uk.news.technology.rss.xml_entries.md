# Source:BBC tech, URL:https://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## TikTok pulls Taylor Swift and The Weeknd's music
 - [https://www.bbc.co.uk/news/technology-68166028](https://www.bbc.co.uk/news/technology-68166028)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-02-01T13:51:20+00:00

It comes after a licensing rights row between the platform and the artists' record label, Universal.

## Musk moves to shift Tesla's legal home to Texas
 - [https://www.bbc.co.uk/news/business-68163184](https://www.bbc.co.uk/news/business-68163184)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-02-01T10:20:02+00:00

The multi-billionaire says the electric car maker will move immediately to hold a shareholder vote on the matter.

## Zuckerberg apologises to families in fiery Senate hearing
 - [https://www.bbc.co.uk/news/technology-68161632](https://www.bbc.co.uk/news/technology-68161632)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-02-01T06:43:12+00:00

Bosses from five of the largest social media firms were grilled about how they are protecting children.

## Zuckerberg apologises as Senators grill tech CEOs
 - [https://www.bbc.co.uk/news/world-us-canada-68137080](https://www.bbc.co.uk/news/world-us-canada-68137080)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-02-01T00:15:07+00:00

The fiery hearing was about the protection of children from exploitation and abuse on social media platforms.

## Could AI 'trading bots' transform the world of investing?
 - [https://www.bbc.co.uk/news/business-68092814](https://www.bbc.co.uk/news/business-68092814)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-02-01T00:13:05+00:00

Artificial intelligence is increasing being used to guide investments but risks remain.

## Spotify's filter fails to block explicit lyrics
 - [https://www.bbc.co.uk/news/entertainment-arts-68126890](https://www.bbc.co.uk/news/entertainment-arts-68126890)
 - RSS feed: https://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2024-02-01T00:03:30+00:00

Fans are shown swear words and racial slurs in dozens of songs even when explicit content is blocked.

