# Source:AsapSCIENCE, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA, language:en-US

## This Mosquito Could Eradicate Human Disease
 - [https://www.youtube.com/watch?v=LIYEhcOn0a4](https://www.youtube.com/watch?v=LIYEhcOn0a4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCC552Sd-3nyi_tk2BudLUzA
 - date published: 2024-02-01T00:20:21+00:00

What would happen if mosquitoes went extinct? And could this new mosquito eradicate disease? Some brilliant scientists have made all of this possible.

Special thanks to Dr. Scott O'Neill and the World Mosquito Program for their help.

Written by: Mitchell Moffit 
Edited by: Luka Šarlija

FOLLOW US!
Instagram: https://instagram.com/asapscience​​
Facebook: https://facebook.com/asapscience​​
Twitter: https://twitter.com/asapscience​​
TikTok: @AsapSCIENCE

Sources and Further Reading:

https://www.worldmosquitoprogram.org/

https://www.nature.com/articles/d41586-023-01266-9

https://www.nature.com/articles/d41586-020-02492-1

https://www.worldmosquitoprogram.org/en/news-stories/stories/dengue-cases-drop-20-year-low-aburra-valley-colombia

https://www.nature.com/articles/466432a

