# Source:New Zealand Herald, URL:https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp, language:en

## Christchurch homicide: Man charged with murder of David Bridgwater
 - [https://www.nzherald.co.nz/nz/christchurch-homicide-man-charged-with-murder-of-david-bridgwater/6YYR27AI3JAIXEVV66F5ZM7C2Q](https://www.nzherald.co.nz/nz/christchurch-homicide-man-charged-with-murder-of-david-bridgwater/6YYR27AI3JAIXEVV66F5ZM7C2Q)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T22:30:00+00:00

The 38-year-old was found dead on a Christchurch street.

## Green Party MP Chlöe Swarbrick announces run for leadership after James Shaw resignation
 - [https://www.nzherald.co.nz/nz/politics/green-party-mp-chloe-swarbrick-expected-to-announce-run-for-leadership-after-james-shaw-resignation/NTFNGGL65FC7VJFZBXYZ44ZCZU](https://www.nzherald.co.nz/nz/politics/green-party-mp-chloe-swarbrick-expected-to-announce-run-for-leadership-after-james-shaw-resignation/NTFNGGL65FC7VJFZBXYZ44ZCZU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T22:00:01+00:00

Swarbrick will announce at 11am

## Bunnings or kids’ TV show Bluey? Why NZ Bunnings store has changed its name to Hammerbarn
 - [https://www.nzherald.co.nz/entertainment/bunnings-or-kids-tv-show-bluey-why-nz-bunnings-store-has-changed-its-name-to-hammerbarn/S4KAKEABNJDGPIMZP44VKEAAEU](https://www.nzherald.co.nz/entertainment/bunnings-or-kids-tv-show-bluey-why-nz-bunnings-store-has-changed-its-name-to-hammerbarn/S4KAKEABNJDGPIMZP44VKEAAEU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T21:54:32+00:00

A Bunnings store in NZ has suddenly changed its name, and parents are wild over it.

## Coalition Government has more clean-up to do after uncharacteristically sloppy week - Audrey Young
 - [https://www.nzherald.co.nz/nz/politics/coalition-government-has-more-clean-up-to-do-after-uncharacteristically-sloppy-week-audrey-young/TZCEHIHL5RB3XA5KD6L3G6ZVJI](https://www.nzherald.co.nz/nz/politics/coalition-government-has-more-clean-up-to-do-after-uncharacteristically-sloppy-week-audrey-young/TZCEHIHL5RB3XA5KD6L3G6ZVJI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T21:16:49+00:00

OPINION: Without a full reckoning, it'll be death by a thousand innuendos.

## One NZ fronts on decision to crimp working-from-home, EY NZ updates after EY UK adopts ‘turnstile monitoring’
 - [https://www.nzherald.co.nz/business/one-nz-fronts-on-decision-to-crimp-working-from-home-ey-nz-updates-after-ey-uk-adopts-turnstile-monitoring/U3ECGUNYVZB7ZIKLFX3S3XXD7U](https://www.nzherald.co.nz/business/one-nz-fronts-on-decision-to-crimp-working-from-home-ey-nz-updates-after-ey-uk-adopts-turnstile-monitoring/U3ECGUNYVZB7ZIKLFX3S3XXD7U)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T20:14:53+00:00

Plus: Remote workers bear the brunt of layoffs.

## Diabetic woman tearful at Auckland airport security officer’s dismissive attitude
 - [https://www.nzherald.co.nz/nz/diabetic-woman-tearful-at-auckland-airport-security-officers-dismissive-attitude/LEBOG3M5HFAHZARVEP6TCYQ27A](https://www.nzherald.co.nz/nz/diabetic-woman-tearful-at-auckland-airport-security-officers-dismissive-attitude/LEBOG3M5HFAHZARVEP6TCYQ27A)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T20:06:21+00:00

The traveller said she was scoffed at and ignored at the departure point.

## Advice: My brother-in-law gets free childcare from his parents. Why don’t we?
 - [https://www.nzherald.co.nz/lifestyle/advice-my-brother-in-law-gets-free-childcare-from-his-parents-why-dont-we/F7EPKCIHUFC6LEPHR6HWDJQKAQ](https://www.nzherald.co.nz/lifestyle/advice-my-brother-in-law-gets-free-childcare-from-his-parents-why-dont-we/F7EPKCIHUFC6LEPHR6HWDJQKAQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T19:21:27+00:00

New York Times: 'Meanwhile, my partner has been paying half his parents’ living expenses.'

## The New Zealand Beauty Industry Reacts To The EPA’s ‘Forever Chemicals’ Ban
 - [https://www.nzherald.co.nz/viva/beauty/the-new-zealand-beauty-industry-reacts-to-the-epas-forever-chemicals-ban/PFR5MPCTWJGDXHMCJ3QHN2TQBM](https://www.nzherald.co.nz/viva/beauty/the-new-zealand-beauty-industry-reacts-to-the-epas-forever-chemicals-ban/PFR5MPCTWJGDXHMCJ3QHN2TQBM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T19:00:00+00:00

And what the news means for the cosmetics already in your cupboard.

## Associate Health Minister Casey Costello fronts up over tobacco excise tax claims
 - [https://www.nzherald.co.nz/nz/associate-health-minister-casey-costello-fronts-up-over-tobacco-excise-tax-claims/2A7LJ5PCUBFOJFZOCZXA26JK5I](https://www.nzherald.co.nz/nz/associate-health-minister-casey-costello-fronts-up-over-tobacco-excise-tax-claims/2A7LJ5PCUBFOJFZOCZXA26JK5I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T18:06:00+00:00

Costello rejects claims she specifically sought out advice on freezing tobacco excise tax.

## Kiwi traveller allegedly removed from Delta Airlines flight for not wearing bra
 - [https://www.nzherald.co.nz/travel/kiwi-traveller-allegedly-removed-from-delta-airlines-flight-for-not-wearing-bra/57VO4PWEOZEGXJFGFQJ232GGSA](https://www.nzherald.co.nz/travel/kiwi-traveller-allegedly-removed-from-delta-airlines-flight-for-not-wearing-bra/57VO4PWEOZEGXJFGFQJ232GGSA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T18:00:00+00:00

The passenger says she was unfairly singled out over her choice to wear men's clothes.

## Auckland Light Rail ‘disestablishment’ to likely cost millions over six months - Cabinet paper release
 - [https://www.nzherald.co.nz/nz/auckland-light-rail-disestablishment-to-likely-cost-millions-over-six-months-cabinet-paper-release/DURFAAKNQ5GOHCDYIK2QBHTSZA](https://www.nzherald.co.nz/nz/auckland-light-rail-disestablishment-to-likely-cost-millions-over-six-months-cabinet-paper-release/DURFAAKNQ5GOHCDYIK2QBHTSZA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T17:51:34+00:00

A Cabinet paper has revealed it will take six months to wrap up Auckland Light Rail Ltd.

## Forty firefighters battle suspicious Hamilton fire, person rescued from top floor
 - [https://www.nzherald.co.nz/nz/forty-firefighters-battle-suspicious-hamilton-fire-person-rescued-from-top-floor/ZGNOHVA3EBDWDJ3NTFBX6HCVOU](https://www.nzherald.co.nz/nz/forty-firefighters-battle-suspicious-hamilton-fire-person-rescued-from-top-floor/ZGNOHVA3EBDWDJ3NTFBX6HCVOU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:59:47+00:00

The first emergency calls came in just after 1am.

## Media Insider: Where is Ryan Bridge’s new show? Piha Black Coast Vanishings - police miss a PR beat; One NZ, ad agency part ways; 64 tickets: Kiwi frenzy for Taylor Swift
 - [https://www.nzherald.co.nz/business/media-insider-where-is-ryan-bridges-new-show-piha-black-coast-vanishings-police-miss-a-pr-beat-one-nz-ad-agency-part-ways-64-tickets-kiwi-frenzy-for-taylor-swift/TJ7KHMV54ZHSFAPJZEHDQ4FYWQ](https://www.nzherald.co.nz/business/media-insider-where-is-ryan-bridges-new-show-piha-black-coast-vanishings-police-miss-a-pr-beat-one-nz-ad-agency-part-ways-64-tickets-kiwi-frenzy-for-taylor-swift/TJ7KHMV54ZHSFAPJZEHDQ4FYWQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:40:22+00:00

Media Insider: One NZ, ad agency part ways; Big changes loom for regional media.

## Lewis Hamilton may move from Mercedes to Ferrari in 2025, reports say
 - [https://www.nzherald.co.nz/sport/lewis-hamilton-may-move-from-mercedes-to-ferrari-in-2025-reports-say/U6UZKTT3V5ELZACOOZPXESABEE](https://www.nzherald.co.nz/sport/lewis-hamilton-may-move-from-mercedes-to-ferrari-in-2025-reports-say/U6UZKTT3V5ELZACOOZPXESABEE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:18:50+00:00

The Formula One great may be on the move again.

## Air New Zealand Rotorua to Auckland: Woman frustrated after airline cuts daily services
 - [https://www.nzherald.co.nz/bay-of-plenty-times/news/air-new-zealand-rotorua-to-auckland-woman-frustrated-after-airline-cuts-daily-services/ILYGD3ZZXRHFDBJGEKH6VXV6LY](https://www.nzherald.co.nz/bay-of-plenty-times/news/air-new-zealand-rotorua-to-auckland-woman-frustrated-after-airline-cuts-daily-services/ILYGD3ZZXRHFDBJGEKH6VXV6LY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:00:00+00:00

The lack of options impacts domestic and international connections, customer says.

## Christchurch mother’s heartbreak: Children killed in house fire after sheet near fan heater ignited
 - [https://www.nzherald.co.nz/nz/christchurch-mums-heartbreak-children-killed-in-house-fire-after-sheet-near-fan-heater-ignited/5E7F5SEOJFCJ7DVR6PSIYLZMEE](https://www.nzherald.co.nz/nz/christchurch-mums-heartbreak-children-killed-in-house-fire-after-sheet-near-fan-heater-ignited/5E7F5SEOJFCJ7DVR6PSIYLZMEE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:00:00+00:00

An 8-year-old boy and his 8-month-old sister died in the fire.

## Herald morning quiz: February 2
 - [https://www.nzherald.co.nz/nz/herald-morning-quiz-february-2/FSETKKWXQ5BETDPD5G2DUUBYUA](https://www.nzherald.co.nz/nz/herald-morning-quiz-february-2/FSETKKWXQ5BETDPD5G2DUUBYUA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:00:00+00:00

Test your brains with the Herald’s morning quiz.

## Matthew Hooton: Time for Christopher Luxon to take charge
 - [https://www.nzherald.co.nz/business/matthew-hooton-time-for-christopher-luxon-to-take-charge/ZDU6R47AFFGWHFU4AECRNTRW4Y](https://www.nzherald.co.nz/business/matthew-hooton-time-for-christopher-luxon-to-take-charge/ZDU6R47AFFGWHFU4AECRNTRW4Y)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:00:00+00:00

OPINION: The Prime Minister has yet to set the clear direction any government needs.

## Mechanic charged after tribunal finds couple ‘duped’ in alleged Range Rover trading scam
 - [https://www.nzherald.co.nz/nz/mechanic-charged-after-tribunal-finds-couple-duped-in-alleged-range-rover-trading-scam/YNTKFT42I5HVVIYAX4ONEH4VZA](https://www.nzherald.co.nz/nz/mechanic-charged-after-tribunal-finds-couple-duped-in-alleged-range-rover-trading-scam/YNTKFT42I5HVVIYAX4ONEH4VZA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:00:00+00:00

Couple took an SUV to him to have it repaired and then ended up carless.

## Pro Stock Picks 2024: Ryman, Sky TV are in as tech and health named trends to watch
 - [https://www.nzherald.co.nz/business/pro-stock-picks-2024-ryman-sky-tv-are-in-as-tech-and-health-named-trends-to-watch/NLEUYFMCAJHFXKWETQJZ3NCJ3Y](https://www.nzherald.co.nz/business/pro-stock-picks-2024-ryman-sky-tv-are-in-as-tech-and-health-named-trends-to-watch/NLEUYFMCAJHFXKWETQJZ3NCJ3Y)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:00:00+00:00

Sky TV, Summerset, Contact Energy and Infratil are favourites.

## Will the Government’s plans to tackle crime and justice work? - The Front Page
 - [https://www.nzherald.co.nz/nz/will-the-governments-plans-to-tackle-crime-and-justice-work-the-front-page/25BNQYAWIJAQJGP76I6EQHLNDY](https://www.nzherald.co.nz/nz/will-the-governments-plans-to-tackle-crime-and-justice-work-the-front-page/25BNQYAWIJAQJGP76I6EQHLNDY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:00:00+00:00

The Government has already stumbled regarding their police recruitment goal.

## ‘Gravely concerning’: Sir Ashley Bloomfield scam prompts Auckland University to call in lawyers
 - [https://www.nzherald.co.nz/nz/gravely-concerning-ashley-bloomfield-scam-prompts-auckland-university-to-call-in-lawyers/EHWZP7KFNFH75NMCTO2KLLOBVI](https://www.nzherald.co.nz/nz/gravely-concerning-ashley-bloomfield-scam-prompts-auckland-university-to-call-in-lawyers/EHWZP7KFNFH75NMCTO2KLLOBVI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T16:00:00+00:00

A scam used fake quotes from the former director-general of health to sell sham products.

## NZ tax system is fairer than you think despite big earners rorting top rate, rejected report finds
 - [https://www.nzherald.co.nz/nz/politics/nz-tax-system-is-fairer-than-widely-believed-despite-big-earners-rorting-top-rate-rejected-report-finds/E3TYHZRYYRFXFIXKHFR2IXBR7E](https://www.nzherald.co.nz/nz/politics/nz-tax-system-is-fairer-than-widely-believed-despite-big-earners-rorting-top-rate-rejected-report-finds/E3TYHZRYYRFXFIXKHFR2IXBR7E)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T07:15:01+00:00

A report binned by the Government actually backs what it has been saying.

## Changes to Auckland tsunami evacuation maps show risk of damage less than expected
 - [https://www.nzherald.co.nz/nz/changes-to-auckland-tsunami-evacuation-maps-show-risk-of-damage-less-than-expected/PHAJHZ2OGRDC7EQDI7L2WYZLVE](https://www.nzherald.co.nz/nz/changes-to-auckland-tsunami-evacuation-maps-show-risk-of-damage-less-than-expected/PHAJHZ2OGRDC7EQDI7L2WYZLVE)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T06:17:47+00:00

Auckland Emergency Management says the new maps are also easier to understand.

## Actor Niwa Whatuira on sexuality and his new gender-bending TV show
 - [https://www.nzherald.co.nz/lifestyle/actor-niwa-whatuira-on-sexuality-and-his-new-gender-bending-tv-show/WAGYXIX7IVGJ5EPP2YFCQ6CBHI](https://www.nzherald.co.nz/lifestyle/actor-niwa-whatuira-on-sexuality-and-his-new-gender-bending-tv-show/WAGYXIX7IVGJ5EPP2YFCQ6CBHI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T06:00:00+00:00

The ex-con son of a famous drag queen goes to work on K Rd.

## Mongrel Mob member jailed for fatal attack on Tāneatua man in his own home
 - [https://www.nzherald.co.nz/nz/mongrel-mob-member-jailed-for-fatal-attack-on-taneatua-man-in-his-own-home/WU4MHMKWUZBF7IKFS6AIJV7PAI](https://www.nzherald.co.nz/nz/mongrel-mob-member-jailed-for-fatal-attack-on-taneatua-man-in-his-own-home/WU4MHMKWUZBF7IKFS6AIJV7PAI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T06:00:00+00:00

The blows in the attack, which was over drugs, could be heard from the street.

## Flat Bush school refuses to enrol child without fixed tenancy agreement before Ministry of Education intervenes
 - [https://www.nzherald.co.nz/nz/ministry-of-education-intervention-needed-after-school-refuses-to-enrol-child-because-family-didnt-have-fixed-tenancy-agreement-of-at-least-a-year/3XTNBV4AGBGNTMR2L5KO6H4AMI](https://www.nzherald.co.nz/nz/ministry-of-education-intervention-needed-after-school-refuses-to-enrol-child-because-family-didnt-have-fixed-tenancy-agreement-of-at-least-a-year/3XTNBV4AGBGNTMR2L5KO6H4AMI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T05:47:00+00:00

Mother was told it was a requirement before school would accept her son.

## We’re the Perma-Singles - eligible, sexy and unattached
 - [https://www.nzherald.co.nz/lifestyle/were-the-perma-singles-eligible-sexy-and-unattached/QJEAO5V2SZAUDGNLPMQM4ICXH4](https://www.nzherald.co.nz/lifestyle/were-the-perma-singles-eligible-sexy-and-unattached/QJEAO5V2SZAUDGNLPMQM4ICXH4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T05:42:57+00:00

Times: Don't want to be tied down? Aversion to dating apps? Why people are remaining solo.

## A guide to the Seoul City Wall trail: what to expect
 - [https://www.nzherald.co.nz/travel/a-quick-guide-to-the-seoul-city-wall-trail-what-to-expect/62WNQPZ6URBIRDSEFDJV76YDUA](https://www.nzherald.co.nz/travel/a-quick-guide-to-the-seoul-city-wall-trail-what-to-expect/62WNQPZ6URBIRDSEFDJV76YDUA)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T05:00:00+00:00

To walk along the Seoul City Wall in South Korea is to walk through bygone centuries.

## Laneway festival 2024: Acts, how to get there, weather forecast, banned items
 - [https://www.nzherald.co.nz/entertainment/laneway-festival-2024-acts-how-to-get-there-weather-forecast-banned-items/5ZU2TPDUGZBKXOR3XFP2W4OYWU](https://www.nzherald.co.nz/entertainment/laneway-festival-2024-acts-how-to-get-there-weather-forecast-banned-items/5ZU2TPDUGZBKXOR3XFP2W4OYWU)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T05:00:00+00:00

Heading along to Auckland's longest-running festival? Here's how to get there for free.

## Taika Waititi’s new movie set to bring more big stars to NZ, Jenna Ortega rumoured - Spy
 - [https://www.nzherald.co.nz/entertainment/taika-waititis-new-movie-set-to-bring-more-big-stars-to-nz-jenna-ortega-rumoured-spy/FVLDXXDBHFCMRJM5J7MK35MXCQ](https://www.nzherald.co.nz/entertainment/taika-waititis-new-movie-set-to-bring-more-big-stars-to-nz-jenna-ortega-rumoured-spy/FVLDXXDBHFCMRJM5J7MK35MXCQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T04:49:51+00:00

Industry insiders tell Spy about Waititi’s new movie and the latest Minecraft news.

## Back-to-school grooming danger: Parents urged to do privacy checks before posting photos of children
 - [https://www.nzherald.co.nz/nz/back-to-school-grooming-danger-parents-urged-to-do-privacy-checks-before-posting-photos-of-children/YRR2I6M5G5AABL7K6WLW3T44XQ](https://www.nzherald.co.nz/nz/back-to-school-grooming-danger-parents-urged-to-do-privacy-checks-before-posting-photos-of-children/YRR2I6M5G5AABL7K6WLW3T44XQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T04:49:11+00:00

Netsafe says some photos could be used to collect personal information about young people.

## Inside Christchurch’s Mongols MC pad: How a drive-by shooting led to a cache of guns and drugs being found
 - [https://www.nzherald.co.nz/nz/inside-christchurchs-mongols-mc-pad-how-a-drive-by-shooting-led-to-a-cache-of-guns-and-drugs-being-found/76SES77QWZFTJK4I43IC3U4C6Q](https://www.nzherald.co.nz/nz/inside-christchurchs-mongols-mc-pad-how-a-drive-by-shooting-led-to-a-cache-of-guns-and-drugs-being-found/76SES77QWZFTJK4I43IC3U4C6Q)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T04:13:03+00:00

The gang's president and sergeant in arms have pleaded guilty after a bust at the pad.

## Judith Collins nearly runs over Australian Deputy Prime Minister with pink Mars rover
 - [https://www.nzherald.co.nz/nz/politics/judith-collins-nearly-runs-over-australian-deputy-prime-minister-with-pink-mars-rover/NCGG35K4CJHCVIK4GKALAKJXTM](https://www.nzherald.co.nz/nz/politics/judith-collins-nearly-runs-over-australian-deputy-prime-minister-with-pink-mars-rover/NCGG35K4CJHCVIK4GKALAKJXTM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T03:32:38+00:00

The four ministers have spent the day locked away talking about China and submarines.

## Auckland e-scooter death: Witness describes bid to save life after crash
 - [https://www.nzherald.co.nz/nz/auckland-e-scooter-death-witness-describes-bid-to-save-life-after-crash/7HTBLFDWLJHTFBF5JQYLHF5B3Y](https://www.nzherald.co.nz/nz/auckland-e-scooter-death-witness-describes-bid-to-save-life-after-crash/7HTBLFDWLJHTFBF5JQYLHF5B3Y)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T03:00:00+00:00

Dad-of-two 'so hurt and sad' young man couldn’t be saved.

## Escaped prisoner who raped woman fires lawyers, refuses to acknowledge court during sentencing
 - [https://www.nzherald.co.nz/nz/escaped-prisoner-who-raped-woman-fires-lawyers-refuses-to-acknowledge-court-during-sentencing/W2XZP4WIF5HYVOSHYXTR4KBUR4](https://www.nzherald.co.nz/nz/escaped-prisoner-who-raped-woman-fires-lawyers-refuses-to-acknowledge-court-during-sentencing/W2XZP4WIF5HYVOSHYXTR4KBUR4)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T02:53:19+00:00

Damon John Exley was convicted twice before for similar offences.

## No need to rummage through your recycling bins yet, says Auckland Council
 - [https://www.nzherald.co.nz/nz/no-need-to-rummage-through-your-recycling-bins-yet-says-auckland-council/M5QU4PMG4RFWLKERGJNFCZQM5E](https://www.nzherald.co.nz/nz/no-need-to-rummage-through-your-recycling-bins-yet-says-auckland-council/M5QU4PMG4RFWLKERGJNFCZQM5E)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T02:41:13+00:00

Officials want to get rid of gross contaminants from recycling bins.

## Norfolk Island murderer to be deported to Christchurch
 - [https://www.nzherald.co.nz/nz/norfolk-island-murderer-to-be-deported-to-christchurch/A6CPXLC4RRDP5MAHFOTI6ZNG6I](https://www.nzherald.co.nz/nz/norfolk-island-murderer-to-be-deported-to-christchurch/A6CPXLC4RRDP5MAHFOTI6ZNG6I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T02:09:27+00:00

Glenn McNeill murdered Sydney woman Janelle Patton over 20 years ago.

## Herald afternoon quiz: February 1
 - [https://www.nzherald.co.nz/nz/herald-afternoon-quiz-february-1/STCW7IXBFBAWLOQ3ORGPAW3ERQ](https://www.nzherald.co.nz/nz/herald-afternoon-quiz-february-1/STCW7IXBFBAWLOQ3ORGPAW3ERQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T02:00:00+00:00

Test your brains with the Herald’s afternoon quiz.

## David Seymour’s first outing as acting Prime Minister, Casey Costello faces Question Time scrutiny
 - [https://www.nzherald.co.nz/nz/david-seymours-first-outing-as-acting-prime-minister-casey-costello-faces-question-time-scrutiny/Z2UMPKPPTVFQPLY24I4KFIVL3Q](https://www.nzherald.co.nz/nz/david-seymours-first-outing-as-acting-prime-minister-casey-costello-faces-question-time-scrutiny/Z2UMPKPPTVFQPLY24I4KFIVL3Q)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T00:57:28+00:00

With Deputy Prime Minister Winston Peters in Australia, the honour falls to Act's leader.

## Creditor calls for money from Compass Homes (Franklin)
 - [https://www.nzherald.co.nz/business/creditor-calls-for-money-from-compass-homes-franklin/4D4RSHWDNBA5LDIGNCHFRZVTMQ](https://www.nzherald.co.nz/business/creditor-calls-for-money-from-compass-homes-franklin/4D4RSHWDNBA5LDIGNCHFRZVTMQ)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T00:55:58+00:00

A subcontractor complained he was owed more than $80,000.

## Dunedin death: Gurjit Singh died of multiple stab wounds, homicide investigation under way
 - [https://www.nzherald.co.nz/nz/dunedin-death-gurjit-singh-died-of-multiple-stab-wounds-homicide-investigation-underway/AKK7D4TR2FCVVNKUXJ2I2LODRI](https://www.nzherald.co.nz/nz/dunedin-death-gurjit-singh-died-of-multiple-stab-wounds-homicide-investigation-underway/AKK7D4TR2FCVVNKUXJ2I2LODRI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T00:45:11+00:00

Police have confirmed Gurjit Singh died as a result of multiple stab wounds.

## Camembert, Brie cheese face extinction after fungus fails
 - [https://www.nzherald.co.nz/lifestyle/camembert-brie-cheese-face-extinction-after-fungus-fails/BET4OLNIGNA4TONPIEJKRV37BM](https://www.nzherald.co.nz/lifestyle/camembert-brie-cheese-face-extinction-after-fungus-fails/BET4OLNIGNA4TONPIEJKRV37BM)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T00:45:02+00:00

Scientists have shared their concerns in a new report.

## Government warned of ‘catastrophic’ earthquake, natural disaster risks
 - [https://www.nzherald.co.nz/nz/politics/could-happen-tomorrow-government-warned-of-chances-of-catastrophic-earthquake/YEUALN5BOVGKNH7X7F3QC2D25I](https://www.nzherald.co.nz/nz/politics/could-happen-tomorrow-government-warned-of-chances-of-catastrophic-earthquake/YEUALN5BOVGKNH7X7F3QC2D25I)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T00:37:10+00:00

Staffing issues could compromise the Government's response to even small-scale events.

## NZ First Minister Casey Costello’s specific request on tobacco tax freeze
 - [https://www.nzherald.co.nz/nz/nz-first-minister-casey-costellos-specific-request-on-tobacco-tax-freeze/RUSP6ZJNGBHOHB7GXLC2J2X5PY](https://www.nzherald.co.nz/nz/nz-first-minister-casey-costellos-specific-request-on-tobacco-tax-freeze/RUSP6ZJNGBHOHB7GXLC2J2X5PY)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T00:33:20+00:00

Notes suggest NZ First Minister Casey Costello was responsible for the tobacco tax freeze.

## Eric Watson puts up a fight over bankruptcy
 - [https://www.nzherald.co.nz/business/eric-watson-puts-up-a-fight-over-bankruptcy/LNOR4QMNUJDW7OZ4HQNVK25EJI](https://www.nzherald.co.nz/business/eric-watson-puts-up-a-fight-over-bankruptcy/LNOR4QMNUJDW7OZ4HQNVK25EJI)
 - RSS feed: https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp
 - date published: 2024-02-01T00:15:00+00:00

Liquidators are chasing Watson for more than $50 million.

