# Source:Gizmodo, URL:https://gizmodo.com/feed, language:en

## Across the Spider-Verse Almost Had a Crazy Spider-Man Game Easter Egg
 - [https://gizmodo.com/spiderman-across-spider-verse-insomniac-miles-morales-1851218236](https://gizmodo.com/spiderman-across-spider-verse-insomniac-miles-morales-1851218236)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T22:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/9e39f00590a2d21facb040e1aa8e2582.jpg" /><p>Some of the best moments in both <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/spiderman-across-spider-verse-review-marvel-sony-animat-1850490027">Spider-Man: Across the Spider-Verse</a> and Marvel’s Spider-Man 2 are the cross-medium crossovers. In Spider-Verse, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/spider-man-across-the-spider-verse-spoilers-questions-1850496483">the game’s Spider-Man briefly appears</a> in Miguel O’Hara’s world. In Spider-Man 2, there’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/spider-man-2-ps5-spider-verse-crossover-sony-marvel-1850925251">a brief reference to Miguel and the movie’s multiverse</a> too. Considering both projects…</p><p><a href="https://gizmodo.com/spiderman-across-spider-verse-insomn

## Music Piracy Is Back, Baby
 - [https://gizmodo.com/music-piracy-is-back-baby-1851218401](https://gizmodo.com/music-piracy-is-back-baby-1851218401)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T22:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/6a4bb584d704297d79864bff9a17009a.jpg" /><p>“You wouldn’t steal a car. You wouldn’t steal a handbag,” said that infamous <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.youtube.com/watch?v=PLzy-IJg4_4&amp;t=25s" rel="noopener noreferrer" target="_blank">2000s anti-piracy commercial</a> from the Motion Picture Association. “Piracy is stealing.”</p><p><a href="https://gizmodo.com/music-piracy-is-back-baby-1851218401">Read more...</a></p>

## RFK Jr. Swears He Wasn’t Thirsty for Fitness Influencer on TikTok
 - [https://gizmodo.com/rfk-jr-swears-he-wasn-t-thirsty-for-fitness-influencer-1851217824](https://gizmodo.com/rfk-jr-swears-he-wasn-t-thirsty-for-fitness-influencer-1851217824)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T21:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/f2638a9f9f20495446dfc31ceb8291f5.jpg" /><p>Robert F. Kennedy Jr., infamous anti-vaxxer and 2024 presidential hopeful, says he wasn’t the one who posted a message on the TikTok page of a fitness influencer who was admiring her glutes after a workout. Sure, RFK Jr., we believe you as much as you believe Big Pharma. </p><p><a href="https://gizmodo.com/rfk-jr-swears-he-wasn-t-thirsty-for-fitness-influencer-1851217824">Read more...</a></p>

## Make Books Your Valentine With February's New Sci-Fi, Fantasy, and Horror Releases
 - [https://gizmodo.com/44-new-february-book-releases-scifi-fantasy-horror-1851134136](https://gizmodo.com/44-new-february-book-releases-scifi-fantasy-horror-1851134136)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/114e65dfa3ca1e499e2f2b0dbe4394d2.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/new-december-scifi-horror-fantasy-books-nnedi-okorafor-1850987424">December</a> and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/new-book-list-scifi-fantasy-horror-releases-jan-2024-1851075354">January</a> are traditionally lighter months for publishing, but February is ramping things back up again—just in time for picking out a book for your <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/nerdy-valentines-day-cards-2023-pedro-pascal-avatar-2-1850113567">Valentine</a> (or yourself)! <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/fantasy-love-throuples-shadow-and-bone-twilight-sandman-1850258351">Romance</a> is a theme this month—but you’ll also find

## Snap Recalls All of Its Selfie Drones Due to Fears They'll Become Flying Fireballs
 - [https://gizmodo.com/snap-selfie-drone-recall-fire-hazard-1851216678](https://gizmodo.com/snap-selfie-drone-recall-fire-hazard-1851216678)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T21:10:00+00:00

<video loop="" poster="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/9837953d8ac676f33a55a72efc5385a2.jpg"><source src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/9837953d8ac676f33a55a72efc5385a2.mp4" type="video/mp4" /></video><p>A couple of years ago, Snap (the company behind Snapchat) decided that the selfie production pipeline needed to be improved upon. Bathroom mirrors and selfie sticks were not cutting it. No, no, Snap decided that the next evolution in the art of taking pictures of yourself would involve a flying robot. </p><p><a href="https://gizmodo.com/snap-selfie-drone-recall-fire-hazard-1851216678">Read more...</a></p>

## Lego's February Releases Are All About That Desert Power
 - [https://gizmodo.com/lego-releases-february-2024-dune-ornithopter-ideas-1851213602](https://gizmodo.com/lego-releases-february-2024-dune-ornithopter-ideas-1851213602)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T20:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/12b30ff51e5c16f1886079d3c2a765e8.png" /><p>The <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/lego-releases-january-2024-marvel-star-wars-city-1851132796">start of the year</a> is always a huge time for Lego, so it’s not surprising that February is looking a little slim on releases compared to last month. But that doesn’t mean there aren’t <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/lego-star-wars-25th-anniversary-sets-malak-minifigure-1851208988">some very cool sets</a> dropping—including the long-awaited release of the Dune set, and its <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/lego-dune-ornithopter-price-release-date-pictures-1850953487">glorious, glorious Long Baron</a>.<br /></p><p><a href="https://gizmodo.com/lego-releases-february-2024-dune-ornithopter-ideas-18

## What Is 'Fried Rice Syndrome' and How Scared of Leftovers Should I Be?
 - [https://gizmodo.com/what-is-fried-rice-syndrome-reheat-leftovers-food-safe-1851213939](https://gizmodo.com/what-is-fried-rice-syndrome-reheat-leftovers-food-safe-1851213939)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T19:54:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/4dd10d675d5605f43ff5683f1e7f8d3b.jpg" /><p>Lurking inside your reheated fried rice is a dangerous bacterial killer—at least, that’s what you might think after watching one of the latest viral videos shared on TikTok and other social media platforms. There is a grain of truth to this claim, and you should try to properly store your leftovers, but the risks of…</p><p><a href="https://gizmodo.com/what-is-fried-rice-syndrome-reheat-leftovers-food-safe-1851213939">Read more...</a></p>

## Netflix's 2024 Previews Tease Squid Game Season 2, Avatar's Arrival, and More
 - [https://gizmodo.com/netflix-2024-slate-genre-movies-and-tv-squid-game-2-1851216811](https://gizmodo.com/netflix-2024-slate-genre-movies-and-tv-squid-game-2-1851216811)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T19:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/abaded781134d7681d31ca22be49a6b3.png" /><p>Action-packed adventures are coming toNetflix in 2024—including the return of  Squid Game, the debut of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/avatar-netflix-changes-sokka-sexist-airbender-ang-show-1851209079">Avatar: The Last Airbender</a>, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/zack-snyder-interview-rebel-moon-1-snyderverse-netflix-1851124345">Zack Snyder’s Rebel Moon: The Scargiver</a>, and fantasy epic Damsel with <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/stranger-things-season-5-production-january-2024-1851086569">Stranger Things</a>’ Millie Bobby Brown. Alas, there’s no tease of Stranger Things itself, or One Piece season two—but…</p><p><a href="https://gizmodo.com/netflix-2024-slate-genre-movies-and-tv-squ

## It's Finally Over for Aduhelm, the Sketchy Alzheimer's Drug Everyone Hated
 - [https://gizmodo.com/its-finally-over-for-aduhelm-the-sketchy-alzheimers-dr-1851217015](https://gizmodo.com/its-finally-over-for-aduhelm-the-sketchy-alzheimers-dr-1851217015)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T19:06:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/8b3b7fdd456c922a12531f1839294be2.jpg" /><p>Biogen is abandoning its lackluster Alzheimer’s disease drug, Aduhelm. The Massachusetts-based company announced Wednesday that it is pulling the medication from the market following poor sales and controversy over its approval by the Food and Drug Administration in 2021. The company says it is only doing so to…</p><p><a href="https://gizmodo.com/its-finally-over-for-aduhelm-the-sketchy-alzheimers-dr-1851217015">Read more...</a></p>

## The Best Horror, Sci-Fi, and Fantasy Streaming in February 2024
 - [https://gizmodo.com/best-horror-movies-streaming-february-2024-sci-fi-genre-1851209283](https://gizmodo.com/best-horror-movies-streaming-february-2024-sci-fi-genre-1851209283)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/17b79d0147f6fb36d05b533250e5adf3.jpg" /><p>February is here. Let’s watch some movies. Welcome to io9's latest edition of the Nerd’s Watch, where we pare down the enormous lists of new films and television shows arriving on all your favorite streaming services into the sci-fi, fantasy, and horror titles we think you’ll like most. (And sometimes, just the ones…</p><p><a href="https://gizmodo.com/best-horror-movies-streaming-february-2024-sci-fi-genre-1851209283">Read more...</a></p>

## Insects Aren’t Attracted to Artificial Lights. They’re Tortured by Them
 - [https://gizmodo.com/why-insects-bugs-fly-around-artificial-lights-1851216660](https://gizmodo.com/why-insects-bugs-fly-around-artificial-lights-1851216660)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T18:26:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/cc8845dad9aece1113ea09128ce069ee.jpg" /><p>Humans have used light to trap insects for at least 2,000 years (thanks, Romans). Now, a team of researchers says they know why the animals are apparently drawn to the light—and it’s not a happy tale. </p><p><a href="https://gizmodo.com/why-insects-bugs-fly-around-artificial-lights-1851216660">Read more...</a></p>

## I'm Obsessed With This Huge Smart Touchscreen Calendar
 - [https://gizmodo.com/skylight-touchscreen-smart-calender-organization-1851215964](https://gizmodo.com/skylight-touchscreen-smart-calender-organization-1851215964)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T18:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/a5aba7d33c3c2e32dde3bed947cdda82.jpg" /><p>Skylight recently <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.skylightframe.com/products/skylight-calendar-max/?sscid=11k8_1532tj&amp;utm_source=shareasale&amp;utm_medium=affiliate&amp;utm_campaign=314743" rel="noopener noreferrer" target="_blank">released</a> a 27-inch variant of its smart  calendar, which looks pretty promising.  It’s essentially a huge touchscreen display housed in an aluminum or plastic case that you put on your wall like a framed piece of art. It lets you add, remove, and edit upcoming events and looks great as an organizer…</p><p><a href="https://gizmodo.com/skylight-touchscreen-smart-calender-organization-1851215964">Read more...</a></p>

## Beetlejuice 2 Is Really Called Beetlejuice Beetlejuice
 - [https://gizmodo.com/beetlejuice-2-official-title-michael-keaton-jenna-orteg-1851216567](https://gizmodo.com/beetlejuice-2-official-title-michael-keaton-jenna-orteg-1851216567)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/2d4edafc2882517a62e833fbc0cc71d2.jpg" /><p>In 2024, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/beetlejuice-2-michael-keaton-jenna-ortega-2024-1850420519">the ghost with the most is back</a> and his new movie is one word short of total chaos. Warner Bros. released the first piece of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/beetlejuice-2-sequel-jenna-ortega-wednesday-tim-burton-1850211794">official marketing for Beetlejuice 2</a> on Thursday and with it, we now know that it’s not actually called “<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/you-can-now-put-the-beetlejuice-sequel-back-in-the-neth-1833891123">Beetlejuice 2</a>.” It’s called... Beetlejuice Beetlejuice.</p><p><a href="https://gizmodo.com/beetlejuice-2-official-title-michael-keaton-jenna-orteg-1851216567

## Tesla Lawyer Cried at a Deposition Because He Loves Elon So Much
 - [https://gizmodo.com/tesla-lawyer-cried-at-a-deposition-because-he-loves-elo-1851216401](https://gizmodo.com/tesla-lawyer-cried-at-a-deposition-because-he-loves-elo-1851216401)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T17:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/b7997faa17a68ab30d2c30361ab9f379.jpg" /><p>You want your lawyer to be on your side. The more passionate they are, the better. If they’re so passionate they can’t control their emotions, though, you might be in trouble. That’s exactly what happened to Elon Musk in a recent court case. Todd Maron, former General Counsel for Tesla and the billionaire’s former…</p><p><a href="https://gizmodo.com/tesla-lawyer-cried-at-a-deposition-because-he-loves-elo-1851216401">Read more...</a></p>

## Pentagon Seeks Direct Control Over Elon’s Big Rocket for Select Missions
 - [https://gizmodo.com/spacex-starship-pentagon-elon-musk-classified-missions-1851216022](https://gizmodo.com/spacex-starship-pentagon-elon-musk-classified-missions-1851216022)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T17:09:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/ac46b6bdfd5a76d060ba64e138a64cab.jpg" /><p>SpaceX’s Starship is poised to be the most coveted launch vehicle in the world once it’s finally up and running, but the Pentagon is hoping to take things a step further by grabbing full control of the megarocket for critically important missions.<br /></p><p><a href="https://gizmodo.com/spacex-starship-pentagon-elon-musk-classified-missions-1851216022">Read more...</a></p>

## NASA's Mars Helicopter Will Do a 'Wiggle' Test After Fatal Malfunction
 - [https://gizmodo.com/nasa-ingenuity-helicopter-mars-wiggle-test-malfunction-1851216299](https://gizmodo.com/nasa-ingenuity-helicopter-mars-wiggle-test-malfunction-1851216299)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T16:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/eae2b1dc2baf1e8844b8022f26e22e6a.jpg" /><p>It’s been a week since NASA announced the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/nasa-mars-helicopter-ingenuity-breaks-blade-mission-end-1851198338">end of its Mars helicopter mission</a>, and we’re still not over losing our beloved Ginny. But apparently, neither is NASA, as the space agency is still trying to figure out what happened during Ingenuity’s last flight on Mars.</p><p><a href="https://gizmodo.com/nasa-ingenuity-helicopter-mars-wiggle-test-malfunction-1851216299">Read more...</a></p>

## Lisa Frankenstein's Crew on Casting the Right Stars
 - [https://gizmodo.com/lisa-frankensteins-crew-on-casting-the-right-stars-1851216076](https://gizmodo.com/lisa-frankensteins-crew-on-casting-the-right-stars-1851216076)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/17a14e0b5e9624294a05a6762d5cb715.jpg" /><p><a href="https://gizmodo.com/lisa-frankensteins-crew-on-casting-the-right-stars-1851216076">Read more...</a></p>

## Disney+, Hulu, and ESPN+ Set to Crackdown on Password Sharing
 - [https://gizmodo.com/disney-hulu-espn-crack-down-on-password-sharing-1851215807](https://gizmodo.com/disney-hulu-espn-crack-down-on-password-sharing-1851215807)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T15:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/fd50de88bfe5b4348d8ce3970ba0d499.jpg" /><p>Time to alert your friends and family members who have access to your <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/hulu-disney-plus-merging-into-one-app-beta-test-live-1851077451">Disney+, Hulu, and ESPN+ accounts</a>. The House of Mouse is officially putting those dastardly U.S.-based customers who dare share their passwords on notice. Netflix already started cracking down on <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/netflix-password-sharing-streaming-1850466800">password sharing</a> last year, so it was only a matter…</p><p><a href="https://gizmodo.com/disney-hulu-espn-crack-down-on-password-sharing-1851215807">Read more...</a></p>

## James Gunn Talks Casting House of the Dragon's Milly Alcock as the New Supergirl
 - [https://gizmodo.com/james-gunn-supergirl-milly-alcock-update-dc-warner-bros-1851212853](https://gizmodo.com/james-gunn-supergirl-milly-alcock-update-dc-warner-bros-1851212853)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T15:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/3368bc58d7d028566842de2cda0c7900.png" /><p>Luke Cage showrunner Cheo Hodari Coker looks back on what could’ve been for season 3. La Brea teases its series finale. Netflix has iced Black Summer. Plus, what to expect on Quantum Leap. Spoilers, away!<br /></p><p><a href="https://gizmodo.com/james-gunn-supergirl-milly-alcock-update-dc-warner-bros-1851212853">Read more...</a></p>

## Feds Want to Outlaw AI Robocalls After Fake Biden Called New Hampshire Voters
 - [https://gizmodo.com/feds-outlaw-ai-robocalls-after-fake-biden-called-voters-1851215878](https://gizmodo.com/feds-outlaw-ai-robocalls-after-fake-biden-called-voters-1851215878)
 - RSS feed: https://gizmodo.com/feed
 - date published: 2024-02-01T15:05:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/155a8f92815354a3110ee6933a9a2d5f.jpg" /><p>A federal agency is pushing to outlaw AI-generated robocalls after criminals tried to disrupt New Hampshire’s Democratic primary with a <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/deepfake-biden-robocall-new-hampshire-dems-primary-1851185529">deepfake phone call from President Biden</a>. The phone call from our sitting President told voters to stay home last weekend in an “unlawful” attempt at voter suppression, according to…</p><p><a href="https://gizmodo.com/feds-outlaw-ai-robocalls-after-fake-biden-called-voters-1851215878">Read more...</a></p>

