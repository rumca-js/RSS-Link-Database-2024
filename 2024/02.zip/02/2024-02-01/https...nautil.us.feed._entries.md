# Source:Nautilus, URL:https://nautil.us/feed/, language:en-US

## My 3 Greatest Revelations
 - [https://nautil.us/my-3-greatest-revelations-8-505168](https://nautil.us/my-3-greatest-revelations-8-505168)
 - RSS feed: https://nautil.us/feed/
 - date published: 2024-02-01T16:51:05+00:00

<p>The author on writing her book, <i>Our Moon</i>, about the power of our satellite to guide evolution and human curiosity. </p>
<p>The post <a href="https://nautil.us/my-3-greatest-revelations-8-505168/">My 3 Greatest Revelations</a> appeared first on <a href="https://nautil.us">Nautilus</a>.</p>

## The Violent Birth of the Moon
 - [https://nautil.us/the-violent-birth-of-the-moon-505044](https://nautil.us/the-violent-birth-of-the-moon-505044)
 - RSS feed: https://nautil.us/feed/
 - date published: 2024-02-01T16:51:04+00:00

<p>Did a colossal collision with a doomed planet give us our satellite? </p>
<p>The post <a href="https://nautil.us/the-violent-birth-of-the-moon-505044/">The Violent Birth of the Moon</a> appeared first on <a href="https://nautil.us">Nautilus</a>.</p>

