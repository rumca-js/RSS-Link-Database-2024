# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## Anonymous Sudan Claims DDOS Attacks on UAE’s Flydubai Airline
 - [https://www.hackread.com/anonymous-sudan-ddos-attacks-uae-flydubai-airline](https://www.hackread.com/anonymous-sudan-ddos-attacks-uae-flydubai-airline)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2024-02-01T22:18:24+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>Anonymous Sudan alleges that the cyber attack they conducted has crippled the reservation system and other online assets of the targeted entity.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/anonymous-sudan-ddos-attacks-uae-flydubai-airline/" rel="nofollow">Anonymous Sudan Claims DDOS Attacks on UAE&#8217;s Flydubai Airline</a></p>

## FBI Disrupts Chinese State-Backed Volt Typhoon’s KV Botnet
 - [https://www.hackread.com/fbi-disrupts-china-volt-typhoon-kv-botnet](https://www.hackread.com/fbi-disrupts-china-volt-typhoon-kv-botnet)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2024-02-01T20:23:00+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>The KV Botnet, a Chinese state-sponsored threat actor group gained widespread attention for compromising hundreds of U.S.-based small office/home office (SOHO) routers.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/fbi-disrupts-china-volt-typhoon-kv-botnet/" rel="nofollow">FBI Disrupts Chinese State-Backed Volt Typhoon&#8217;s KV Botnet</a></p>

## Hackers Uncover Airbus EFB App Vulnerability, Risking Aircraft Data
 - [https://www.hackread.com/hackers-airbus-efb-app-vulnerability-aircraft-data](https://www.hackread.com/hackers-airbus-efb-app-vulnerability-aircraft-data)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2024-02-01T18:11:18+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>In this instance, the hackers were white hat; otherwise, things could have gone awry.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/hackers-airbus-efb-app-vulnerability-aircraft-data/" rel="nofollow">Hackers Uncover Airbus EFB App Vulnerability, Risking Aircraft Data</a></p>

## Ripple Co-Founder’s Personal XRP Wallet Breached in $112 Million Hack
 - [https://www.hackread.com/ripple-co-founders-xrp-wallet-breached-hack](https://www.hackread.com/ripple-co-founders-xrp-wallet-breached-hack)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2024-02-01T12:24:44+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>Ripple’s co-founder Chris Larsen has acknowledged that his personal XRP wallet was hacked.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/ripple-co-founders-xrp-wallet-breached-hack/" rel="nofollow">Ripple Co-Founder&#8217;s Personal XRP Wallet Breached in $112 Million Hack</a></p>

