# Source:LonTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg, language:en-US

## Mouse pad promises a salary increase ? #advertising #marketing
 - [https://www.youtube.com/watch?v=SNXlC6OuJ5o](https://www.youtube.com/watch?v=SNXlC6OuJ5o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg
 - date published: 2024-02-01T18:42:13+00:00



