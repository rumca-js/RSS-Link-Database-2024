# Source:IGN All, URL:https://feeds.feedburner.com/ign/all, language:en

## Dragon's Dogma 2: Everything We Know After 10 Hours of Play - IGN First
 - [https://www.ign.com/articles/dragons-dogma-2-everything-we-know-after-10-hours-of-play-ign-first](https://www.ign.com/articles/dragons-dogma-2-everything-we-know-after-10-hours-of-play-ign-first)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T22:00:00+00:00

Mitchell and Casey sit down to discuss the experience of playing 10 hours of Dragon's Dogma 2 at Capcom in Japan.

## Percy Jackson and the Olympians Season 1 Review
 - [https://www.ign.com/articles/percy-jackson-and-the-olympians-season-1-review](https://www.ign.com/articles/percy-jackson-and-the-olympians-season-1-review)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T21:47:21+00:00

A new addition to the pantheon of YA adaptations.

## How to Watch Argylle – Showtimes and Streaming Status
 - [https://www.ign.com/articles/how-to-watch-argylle](https://www.ign.com/articles/how-to-watch-argylle)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T21:30:00+00:00

Wondering how to watch Argylle? We have all the information on the spy thriller, from showtimes to streaming status.

## SpongeBob Squarepants Will 'Perform' Sweet Victory to Kick Off Nickelodeon Broadcast of Super Bowl
 - [https://www.ign.com/articles/spongebob-squarepants-will-perform-sweet-victory-super-bowl](https://www.ign.com/articles/spongebob-squarepants-will-perform-sweet-victory-super-bowl)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T21:20:25+00:00

CBS has confirmed that SpongeBob Squarepants will "perform" Sweet Victory before Super Bowl LVIII.

## More Details on The Day's Before Collapse Emerge, And They Aren't Pretty
 - [https://www.ign.com/articles/more-details-on-the-days-before-collapse-emerge-and-they-arent-pretty](https://www.ign.com/articles/more-details-on-the-days-before-collapse-emerge-and-they-arent-pretty)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T21:14:05+00:00

The information surrounding developer Fntastic’s December game release, The Day Before, just got a lot worse, according to reports from German game outlets GameStar and Game Two.

## This 4TB PS5 SSD with Heatsink Is Only $178.14
 - [https://www.ign.com/articles/this-is-the-best-ssd-deal-so-far-this-year-4tb-ps5-ssd-with-heatsink](https://www.ign.com/articles/this-is-the-best-ssd-deal-so-far-this-year-4tb-ps5-ssd-with-heatsink)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T21:08:00+00:00

Best PS5 SSD deal of the year?

## Tim Burton Reportedly Directing Attack of the Fifty Foot Woman Remake
 - [https://www.ign.com/articles/tim-burton-reportedly-directing-attack-of-the-fifty-foot-woman-remake](https://www.ign.com/articles/tim-burton-reportedly-directing-attack-of-the-fifty-foot-woman-remake)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T20:49:31+00:00

Tim Burton is reportedly attached to direct an Attack of the Fifty Foot Woman remake, with Gone Girl author Gillian Flynn on board to write the script.

## Skip and Loafer Is More Than Just an Adorable Anime; It'll Benefit Victims of the Noto Earthquake, Too
 - [https://www.ign.com/articles/skip-and-loafer-is-more-than-just-an-adorable-anime-itll-benefit-victims-of-the-noto-earthquake-too](https://www.ign.com/articles/skip-and-loafer-is-more-than-just-an-adorable-anime-itll-benefit-victims-of-the-noto-earthquake-too)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T20:21:12+00:00

Skip and Loafer is more than just an adorable anime; it'll air 12 episodes on YouTube and donate proceeds to victims of the 2024 Noto earthquake in Ishikawa Prefecture, too.

## The 13 Best Board Games for Couples to Play in 2024
 - [https://www.ign.com/articles/best-board-games-for-couples](https://www.ign.com/articles/best-board-games-for-couples)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T20:08:00+00:00

These board games are a blast to play with two players -- especially between you and your significant others.

## Claim a Key for Hellcard, the Turn-Based Deckbuilding Rogue-Lite From Book of Demons Developer
 - [https://www.ign.com/articles/claim-a-key-for-hellcard-the-turn-based-deckbuilding-rogue-lite-from-book-of-demons-developer](https://www.ign.com/articles/claim-a-key-for-hellcard-the-turn-based-deckbuilding-rogue-lite-from-book-of-demons-developer)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T20:00:00+00:00



## Aussie Streaming Guide: The Best TV & Movies for February 2024
 - [https://www.ign.com/articles/aussie-streaming-guide-the-best-tv-movies-for-february-2024](https://www.ign.com/articles/aussie-streaming-guide-the-best-tv-movies-for-february-2024)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T19:46:58+00:00

Nothing but the finest content to binge stream. All the best TV series, movies, comedy specials, docos, and more!

## Score a Romoss 231Wh Lithium Power Station with AC and USB PD for Under $100
 - [https://www.ign.com/articles/best-lithium-power-station-deal-2024-romoss-thunder](https://www.ign.com/articles/best-lithium-power-station-deal-2024-romoss-thunder)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T19:45:00+00:00

Amazon Prime member exclusive deal

## The Powerful Lenovo Legion Pro 7i 16" RTX 4090 Gaming Laptop Is Down to $2700
 - [https://www.ign.com/articles/best-gaming-laptop-deal-2024-lenovo-legion-pro-rtx-4090](https://www.ign.com/articles/best-gaming-laptop-deal-2024-lenovo-legion-pro-rtx-4090)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T19:45:00+00:00

Lenovo's highest end gaming laptop

## Score a Lenovo Legion Pro 5 16" RTX 4070 Gaming Laptop for Only $1310.99
 - [https://www.ign.com/articles/best-gaming-laptop-deal-2024-lenovo-legion-pro-5-rtx-4070](https://www.ign.com/articles/best-gaming-laptop-deal-2024-lenovo-legion-pro-5-rtx-4070)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T19:40:00+00:00

Double your memory for only $38 more

## Resident Evil 4 Gold Edition Will Only Have a Physical Release in Europe
 - [https://www.ign.com/articles/resident-evil-4-gold-edition-will-only-have-a-physical-release-in-europe](https://www.ign.com/articles/resident-evil-4-gold-edition-will-only-have-a-physical-release-in-europe)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T19:31:06+00:00

Capcom has officially confirmed that Europe will be the only region receiving a physical release for Resident Evil 4 Gold Edition.

## Megamind's New Film, TV Series Both Reveal First Trailer
 - [https://www.ign.com/articles/megaminds-new-film-tv-series-both-reveal-first-trailer](https://www.ign.com/articles/megaminds-new-film-tv-series-both-reveal-first-trailer)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T19:25:41+00:00

Dreamworks Animation revealed today the first look at the new Megamind film and TV series, both arriving next month.

## Game of Thrones Creators Set New Netflix Series With Michael Shannon, Matthew Macfadyen
 - [https://www.ign.com/articles/game-of-thrones-creators-set-new-netflix-series-with-michael-shannon-matthew-macfadyen](https://www.ign.com/articles/game-of-thrones-creators-set-new-netflix-series-with-michael-shannon-matthew-macfadyen)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T19:12:58+00:00

Netflix has revealed a new drama series from Game of Thrones creators David Benioff and D.B. Weiss: Death by Lightning, focused on President James Garfield and starring Michael Shannon and Matthew Macfadyen.

## Netflix's Avatar: The Last Airbender: Why Azula and the Fire Nation Play a Bigger Role in Season 1
 - [https://www.ign.com/articles/netflixs-avatar-the-last-airbender-why-azula-and-the-fire-nation-play-a-bigger-role-in-season-1](https://www.ign.com/articles/netflixs-avatar-the-last-airbender-why-azula-and-the-fire-nation-play-a-bigger-role-in-season-1)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T19:00:00+00:00

Netflix's Avatar: The Last Airbender showrunner Albert Kim explains why Azula, Fire Lord Ozai, and the rest of the Fire Nation play a larger role in Season 1 - and why we'll see the Agni Kai between Ozai and Zuko.

## Beetlejuice 2 Gets a Clever New Title and First Poster
 - [https://www.ign.com/articles/beetlejuice-2-gets-a-clever-new-title-and-first-poster](https://www.ign.com/articles/beetlejuice-2-gets-a-clever-new-title-and-first-poster)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T18:58:53+00:00

The Beetlejuice sequel has unveiled its first poster, as well as a pretty clever official title: Beetlejuice Beetlejuice.

## Why I Hope Physint is Kojima’s New Metal Gear Solid
 - [https://www.ign.com/articles/why-i-hope-physint-is-kojimas-new-metal-gear-solid](https://www.ign.com/articles/why-i-hope-physint-is-kojimas-new-metal-gear-solid)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T18:40:46+00:00

Hideo Kojima is returning to the spy espionage genre with PhysInt and will finally pick up where he left off, even if it's not going to be Metal Gear Solid 6.

## The Big Netflix Avatar: The Last Airbender Producer Interview: 'This Is a Remix, Not a Cover'
 - [https://www.ign.com/articles/the-big-netflix-avatar-the-last-airbender-producer-interview-this-is-a-remix-not-a-cover](https://www.ign.com/articles/the-big-netflix-avatar-the-last-airbender-producer-interview-this-is-a-remix-not-a-cover)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T18:30:00+00:00

IGN sits down with Netflix's Avatar: The Last Airbender showrunner and executive producer for a wide-ranging interview about the changes they're making, the cast, the pressures of taking on ALTA, and a lot more.

## With CM Punk Out, Who Should Seth Rollins Face at WrestleMania?
 - [https://www.ign.com/articles/with-cm-punk-out-who-should-seth-rollins-face-at-wrestlemania](https://www.ign.com/articles/with-cm-punk-out-who-should-seth-rollins-face-at-wrestlemania)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T18:30:00+00:00

With CM Punk out, who should Seth Rollins face at WrestleMania? We have some ideas.

## Get an Alienware GeForce RTX 4090 Liquid Cooled Gaming PC for as Low as $2880
 - [https://www.ign.com/articles/get-an-alienware-geforce-rtx-4090-liquid-cooled-gaming-pc-for-as-low-as-2880](https://www.ign.com/articles/get-an-alienware-geforce-rtx-4090-liquid-cooled-gaming-pc-for-as-low-as-2880)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T18:15:00+00:00

GeForce RTX 4090 GPUs are selling for $500-$700 above MSRP

## Buy a Nintendo Switch OLED, Get $50 Dell Gift Card
 - [https://www.ign.com/articles/best-nintendo-switch-oled-deal-2024-dell-and-amazon](https://www.ign.com/articles/best-nintendo-switch-oled-deal-2024-dell-and-amazon)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T18:05:00+00:00

Or get a Nintendo Switch for $269

## IGN Fan Fest Returns with Avatar: The Last Airbender, Dune: Part Two, WWE 2K24, and More
 - [https://www.ign.com/articles/ign-fan-fest-returns-with-avatar-the-last-airbender-dune-part-2-wwe-2k24-and-more](https://www.ign.com/articles/ign-fan-fest-returns-with-avatar-the-last-airbender-dune-part-2-wwe-2k24-and-more)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T18:00:00+00:00

IGN Fan Fest returns this February with a lineup filled with the biggest properties in games and entertainment.

## Resident Evil 4 Gold Edition Arrives Next Week
 - [https://www.ign.com/articles/resident-evil-4-gold-edition-arrives-next-week](https://www.ign.com/articles/resident-evil-4-gold-edition-arrives-next-week)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T17:50:07+00:00

Capcom has announced a Resident Evil 4 Gold Edition with a trailer and a release date.

## Super Mario Wonder Is on Sale for $50
 - [https://www.ign.com/articles/super-mario-wonder-on-sale-nintendo-switch](https://www.ign.com/articles/super-mario-wonder-on-sale-nintendo-switch)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T17:49:30+00:00



## Preorder the Dream Vapor Special Edition Xbox Wireless Controller
 - [https://www.ign.com/articles/preorder-dream-vapor-special-edition-xbox-wireless-controller](https://www.ign.com/articles/preorder-dream-vapor-special-edition-xbox-wireless-controller)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T17:16:08+00:00

The Dream Vapor Special Edition Xbox Wireless Controller if officially up for preorder at select retailers.

## Chainsaw Man Vinyl Now Available for Pre-Order in the IGN Store
 - [https://www.ign.com/articles/chainsaw-man-vinyl-now-available-for-pre-order-in-the-ign-store](https://www.ign.com/articles/chainsaw-man-vinyl-now-available-for-pre-order-in-the-ign-store)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T17:00:00+00:00



## Scott Pilgrim Graphic Novels to Be Remastered for 20th Anniversary
 - [https://www.ign.com/articles/scott-pilgrim-20th-anniversary-box-set-comic](https://www.ign.com/articles/scott-pilgrim-20th-anniversary-box-set-comic)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T17:00:00+00:00

The Scott Pilgrim franchise turns 20 in August 2024, and to celebrate, Oni Press is releasing a new box set featuring remastered graphic novels and cool bonus swag.

## Silent Hill 2 Remake Vs Original Scene Comparison
 - [https://www.ign.com/articles/silent-hill-2-remake-vs-original-comparison](https://www.ign.com/articles/silent-hill-2-remake-vs-original-comparison)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T17:00:00+00:00

We pored over the new Silent Hill 2 trailer to see what's the same and what's different from the original.

## NFL Star Jason Kelce Wants to Bring Back Backyard Football and Baseball
 - [https://www.ign.com/articles/nfl-star-jason-kelce-wants-to-bring-back-backyard-football-and-baseball](https://www.ign.com/articles/nfl-star-jason-kelce-wants-to-bring-back-backyard-football-and-baseball)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T16:52:44+00:00

During a recent episode of his podcast, NFL star Jason Kelce revealed he wants to buy the rights to Backyard Sports and revive the series.

## Donald Glover Says Community Movie Script Is Finished
 - [https://www.ign.com/articles/donald-glover-says-community-movie-script-is-finished](https://www.ign.com/articles/donald-glover-says-community-movie-script-is-finished)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T16:46:25+00:00

Star Wars and The Lion King star Donald Glover has said the Community movie has a finished script.

## Get 20% off Selected LEGO Sets in the UK From John Lewis
 - [https://www.ign.com/articles/get-20-off-selected-lego-sets-in-the-uk-from-john-lewis](https://www.ign.com/articles/get-20-off-selected-lego-sets-in-the-uk-from-john-lewis)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T16:33:27+00:00

UK retailer John Lewis is offering 20% off of a range of selected LEGO sets in the second big LEGO sale this year.

## Hulu the Latest Streaming Service To Crack Down on Password Sharing
 - [https://www.ign.com/articles/hulu-the-latest-streaming-service-to-crack-down-on-password-sharing](https://www.ign.com/articles/hulu-the-latest-streaming-service-to-crack-down-on-password-sharing)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T16:04:01+00:00

Hulu recently updated its subscriber agreement forbidding account holders from sharing their login info with anyone who does not live in their household.

## Children of the Sun: The First Preview – Like Sniper Elite Meets Superhot
 - [https://www.ign.com/articles/children-of-the-sun-the-first-preview-like-sniper-elite-meets-superhot](https://www.ign.com/articles/children-of-the-sun-the-first-preview-like-sniper-elite-meets-superhot)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T16:00:00+00:00

We take our first test drive with Children of the Sun, a just-announced shooter/puzzle game that blends Sniper Elite and Superhot into one revenge-fueled package.

## Video Game Release Dates: The Biggest Games of February 2024 and Beyond
 - [https://www.ign.com/articles/video-game-release-dates-ps4-ps5-xbox-one-series-x-nintendo-switch](https://www.ign.com/articles/video-game-release-dates-ps4-ps5-xbox-one-series-x-nintendo-switch)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T15:55:21+00:00

An updated list of release dates for PS5, Xbox Series X|S, Nintendo Switch, and PC games.

## James Bond Director Apparently 'Preferred' Henry Cavill Over Daniel Craig at Auditions
 - [https://www.ign.com/articles/james-bond-director-apparently-preferred-henry-cavill-over-daniel-craig-auditions](https://www.ign.com/articles/james-bond-director-apparently-preferred-henry-cavill-over-daniel-craig-auditions)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T15:50:20+00:00

Argylle director Matthew Vaughn has let slip how close Henry Cavill was to being cast as James Bond before Daniel Craig ultimately got the part.

## Best Xbox One Controller 2024
 - [https://www.ign.com/articles/the-best-controllers-for-xbox-one](https://www.ign.com/articles/the-best-controllers-for-xbox-one)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T15:24:41+00:00

We love the standard Xbox controller, but there are a lot of excellent alternatives.

## Ghost Machine: Behind the Comic Industry's Biggest Shake-Up in Years
 - [https://www.ign.com/articles/ghost-machine-image-comics-interview-geoff-johns](https://www.ign.com/articles/ghost-machine-image-comics-interview-geoff-johns)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T15:18:09+00:00



## Cobra Kai's Sixth and Final Season Coming This Year, Here's a First Look
 - [https://www.ign.com/articles/cobra-kais-sixth-and-final-season-coming-this-year-heres-a-first-look](https://www.ign.com/articles/cobra-kais-sixth-and-final-season-coming-this-year-heres-a-first-look)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T15:17:45+00:00

The sixth and final season of Cobra Kai now has a release window, with the series set to release on Netflix sometime this year.

## The Best Hulu Deals and Bundles Right Now (February 2024)
 - [https://www.ign.com/articles/best-hulu-deals](https://www.ign.com/articles/best-hulu-deals)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T15:11:00+00:00

These are the best Hulu deals and bundles to check out so far in 2024.

## WWE 2K24 Hands-On Preview
 - [https://www.ign.com/articles/wwe-2k24-hands-on-preview](https://www.ign.com/articles/wwe-2k24-hands-on-preview)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T15:01:00+00:00

From what I’ve played so far, WWE 2K24 has added enough exciting gameplay-focused innovations that it's definitely worth your attention. Let me talk to ya…

## Netflix Shares First Teaser for Squid Game Season 2
 - [https://www.ign.com/articles/squid-game-season-2-first-teaser-clip](https://www.ign.com/articles/squid-game-season-2-first-teaser-clip)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T14:42:09+00:00

Netflix has released the first teaser for Squid Game Season 2.

## How to Choose the Best Gaming Console in 2024
 - [https://www.ign.com/articles/how-to-choose-the-best-video-game-console](https://www.ign.com/articles/how-to-choose-the-best-video-game-console)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T14:30:00+00:00

A guide for people who don't even know where to start.

## Superman: Legacy to Start Production Imminently as James Gunn Updates Fans on DCU 1 Year Later
 - [https://www.ign.com/articles/superman-legacy-to-start-production-imminently-as-james-gunn-updates-fans-on-dcu-1-year-later](https://www.ign.com/articles/superman-legacy-to-start-production-imminently-as-james-gunn-updates-fans-on-dcu-1-year-later)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T14:27:42+00:00

DC Studios co-CEO James Gunn has revealed Superman: Legacy will go into production imminently while sharing an update on the overall state of the DCU one year after its roadmap was announced.

## New LEGO Sets for February 2024 and Beyond
 - [https://www.ign.com/articles/new-lego-sets-for-february-2024-and-beyond](https://www.ign.com/articles/new-lego-sets-for-february-2024-and-beyond)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T14:03:00+00:00



## Mr. and Mrs. Smith Review
 - [https://www.ign.com/articles/mr-and-mrs-smith-review-donald-glover-maya-erskine-prime-video](https://www.ign.com/articles/mr-and-mrs-smith-review-donald-glover-maya-erskine-prime-video)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T14:00:00+00:00



## Krysten Ritter Fuels Speculation of Jessica Jones Return Ahead of Daredevil: Born Again
 - [https://www.ign.com/articles/krysten-ritter-speculation-jessica-jones-return-daredevil-born-again](https://www.ign.com/articles/krysten-ritter-speculation-jessica-jones-return-daredevil-born-again)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T13:47:22+00:00

Krysten Ritter recently posted an Instagram story seemingly teasing her return as Jessica Jones, fuelling speculation about her potential appearance in Daredevil: Born Again.

## Obsidian Explains Why Avowed Only Lets You Pick Human or Elf
 - [https://www.ign.com/articles/obsidian-explains-why-avowed-only-lets-you-pick-human-or-elf](https://www.ign.com/articles/obsidian-explains-why-avowed-only-lets-you-pick-human-or-elf)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T13:19:27+00:00

We've learned that Avowed player character creation is limited to making either a human or an elf. Developer Obsidian has now explained why.

## The Strange Saga of Jake Gyllenhaal, a French Director, and Their Indie Film That Wasn't
 - [https://www.ign.com/articles/the-strange-saga-of-jake-gyllenhaal-a-french-director-and-their-indie-film-that-wasnt](https://www.ign.com/articles/the-strange-saga-of-jake-gyllenhaal-a-french-director-and-their-indie-film-that-wasnt)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T13:12:47+00:00

What really happened between Jake Gyllenhaal, a French director who claimed he displayed erratic behavior, and their indie film that never was? We tried to track it all down as much as possible.

## The Internet Reacts to Hideo Kojima’s Brilliantly Bizarre Death Stranding 2 Trailer
 - [https://www.ign.com/articles/the-internet-reacts-to-hideo-kojimas-brilliantly-bizarre-death-stranding-2-trailer](https://www.ign.com/articles/the-internet-reacts-to-hideo-kojimas-brilliantly-bizarre-death-stranding-2-trailer)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T13:04:47+00:00

The new Death Stranding 2 trailer has sent the internet wild for its glam rock Joker, creepy hands, and a stop-motion puppet that looks like Alan Wake.

## Metro Developer Makes Clear PlayStation VR2 Game Awakening Isn't Next 'Mainline' Metro Game
 - [https://www.ign.com/articles/metro-developer-makes-clear-playstation-vr2-game-awakening-isnt-next-mainline-metro-game](https://www.ign.com/articles/metro-developer-makes-clear-playstation-vr2-game-awakening-isnt-next-mainline-metro-game)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T12:17:03+00:00

Developer 4A Games has made clear Metro Awakening, the PSVR2 game announced during the January 2024 PlayStation State of Play, is not the next mainline metro game but instead a spin-off.

## Could Hideo Kojima’s Return to Action Espionage Be One of the First PS6 Games?
 - [https://www.ign.com/articles/could-hideo-kojimas-return-to-action-espionage-be-one-of-the-first-ps6-games](https://www.ign.com/articles/could-hideo-kojimas-return-to-action-espionage-be-one-of-the-first-ps6-games)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T11:47:48+00:00

Metal Gear creator Hideo Kojima will return to action espionage with Physint, but could it also be one of the first PS6 games?

## Ewan McGregor on Obi-Wan Kenobi Season 2: 'No Talk of It Yet. There Is a Lot Going on at Disney'
 - [https://www.ign.com/articles/ewan-mcgregor-on-obi-wan-kenobi-season-2-no-talk-of-it-yet-there-is-a-lot-going-on-at-disney](https://www.ign.com/articles/ewan-mcgregor-on-obi-wan-kenobi-season-2-no-talk-of-it-yet-there-is-a-lot-going-on-at-disney)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T11:23:42+00:00

Star Wars star Ewan McGregor has given fans a disappointing update on Obi-Wan Kenobi, saying there's a lot happening at Disney but no talks of Season 2 yet.

## Marvel's Spider-Man 2 Getting Free Trial on PlayStation Plus Premium
 - [https://www.ign.com/articles/marvels-spider-man-2-getting-free-trial-on-playstation-plus-premium](https://www.ign.com/articles/marvels-spider-man-2-getting-free-trial-on-playstation-plus-premium)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T10:30:39+00:00

Sony is giving PlayStation Plus Premium members on PS5 a free trial of Marvel's Spider-Man 2 from Insomniac Games.

## Palworld Steam Patch v0.1.3.0 Makes Lots of Welcome Fixes
 - [https://www.ign.com/articles/palworld-steam-patch-v0130-makes-lots-of-welcome-fixes](https://www.ign.com/articles/palworld-steam-patch-v0130-makes-lots-of-welcome-fixes)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T09:48:28+00:00

Palworld developer Pocketpair has released Steam update v0.1.3.0. Check out the patch notes to find out what it does.

## Silent Hill: The Short Message – First Hands-On Impressions
 - [https://www.ign.com/articles/silent-hill-the-short-message-first-hands-on-impressions](https://www.ign.com/articles/silent-hill-the-short-message-first-hands-on-impressions)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T03:00:00+00:00



## Kung Fu Remake Will Star Donnie Yen in David Carradine's Role With Bullet Train Director at the Helm
 - [https://www.ign.com/articles/kung-fu-remake-donnie-yen-bullet-train](https://www.ign.com/articles/kung-fu-remake-donnie-yen-bullet-train)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T01:03:38+00:00

Donnie Yen, who starred in Ip Man and John Wick: Chapter 4 among other films, will now take on David Carradine's role in a remake of Kung Fu by the director of Bullet Train.

## The Lenovo Legion Tower 5i RTX 4070 Gaming PC Is Down to $1310.99
 - [https://www.ign.com/articles/the-lenovo-legion-tower-5i-rtx-4070-gaming-pc-is-down-to-131099](https://www.ign.com/articles/the-lenovo-legion-tower-5i-rtx-4070-gaming-pc-is-down-to-131099)
 - RSS feed: https://feeds.feedburner.com/ign/all
 - date published: 2024-02-01T00:15:00+00:00



