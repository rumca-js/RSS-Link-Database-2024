# Source:Pakistan Observer, URL:https://pakobserver.net/feed/, language:en-US

## iPhone 16: From new-gen AI features to price, and leaked pictures, Check all details here
 - [https://pakobserver.net/iphone-16-from-new-gen-ai-features-to-price-and-leaked-pictures-check-all-details-here](https://pakobserver.net/iphone-16-from-new-gen-ai-features-to-price-and-leaked-pictures-check-all-details-here)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T17:34:35+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/R230-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Tech giant Apple makes a variety of products like Macs, watches, and iPads, but the iPhone remains its front-runner product as the premium phones grab healthy share in global mobile market. iPhone contribute over 50percent of Apple sales in 2023, and the company is planning to introduce its next device iPhone 16, which will be [&#8230;]

## Suzuki GS 150 zero markup Installment Plan 2024
 - [https://pakobserver.net/suzuki-gs-150-zero-markup-installment-plan-2024](https://pakobserver.net/suzuki-gs-150-zero-markup-installment-plan-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T16:49:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/suzuki-gs-150-150x150.png" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Suzuki GS 150 Installment Plan: Suzuki remains the front-runner in Pakistani car market but in the wheeler segment, the company remains a mile behind Honda, Yamaha, and other companies. In contrast to cheap hatchbacks, Suzuki produces premium bikes. The company’s cheapest bike costs Rs335,000. The bikes are fuel efficient but are not the first pick [&#8230;]

## KP Schools Elections Holidays 2024
 - [https://pakobserver.net/kp-schools-elections-holidays-2024](https://pakobserver.net/kp-schools-elections-holidays-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T16:14:25+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/punjab-schools-winter-vacations-announced-1701404140-4289-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – The interim government in Khyber Pakhtunkhuwa on Thursday announced elections holidays in schools, colleges, and universities across the province from February 6-9. A notification issued by the KP Education Department said “The Competent Authority has been pleased to notify the vacations w.c.f 06.02.2024 to 09.02.2024 for all Public and Private Educational Institutions throughout [&#8230;]

## Ashfaque Satti serves defamation notice to Rabia Anum amid domestic violence allegations
 - [https://pakobserver.net/ashfaque-satti-serves-defamation-notice-to-rabia-anum-amid-domestic-violence-allegations](https://pakobserver.net/ashfaque-satti-serves-defamation-notice-to-rabia-anum-amid-domestic-violence-allegations)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T15:43:04+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/GDpAVKNbsAAXXUy-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; TV show host Ashfaque Ishaq Satti sent a defamation notice to famous news anchor Rabia Anum over the latter’s social media ranting related to domestic violence. Satti, who is facing a police complaint over the allegation of assaulting his third wife Nomaika, shared an update on the recent controversy as he sent a [&#8230;]

## Pakistan’s foreign reserves drop by $54mn
 - [https://pakobserver.net/pakistans-foreign-reserves-drop-by-54mn](https://pakobserver.net/pakistans-foreign-reserves-drop-by-54mn)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T15:29:05+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/SBP-res-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; Pakistan’s liquid foreign reserves reached $13,262.5 million as of January 26, 2024. As per the data released by the State Bank of Pakistan (SBP) on Thursday, central bank’s foreign reserves stood at $8,216.5 million. Net foreign reserves held by commercial banks stood at $5,046 million. During the week ended on January 26, 2024, [&#8230;]

## PTI’s Rehan Zeb laid to rest as thousands attend funeral prayers
 - [https://pakobserver.net/ptis-rehan-zeb-laid-to-rest-as-thousands-attend-funeral-prayer](https://pakobserver.net/ptis-rehan-zeb-laid-to-rest-as-thousands-attend-funeral-prayer)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T14:43:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/gg33-_1_-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />PESHAWAR &#8211; Rehan Zaib, a PTI-affiliated election candidate, was laid to rest on Thursday in his hometown Bajaur with thousands of people in attendance. A large number of Bajaur and KP residents attended his funeral prayers, social media users are also paying tribute and condolences to the deceased member who lost his life during political campaign. [&#8230;]

## SBP announces six-week summer internship program; check eligibility, application procedure
 - [https://pakobserver.net/sbp-announces-six-week-summer-internship-program-check-eligibility-application-procedure](https://pakobserver.net/sbp-announces-six-week-summer-internship-program-check-eligibility-application-procedure)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T14:36:45+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/SIP-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The State Bank of Pakistan (SBP) has announced six weeks Summer Internship Program (SIP) from June 24, 2024 to August 02, 2024 at SBP, Karachi. Pakistani/AJK nationals having CNIC/NICOP/valid Pakistani passport can participate in SIP as per the eligibility criteria and procedure detailed below. SBP Summer Internship 2024 Eligibility Criteria: Eligible students must [&#8230;]

## Islamabad announces nine school holidays for Elections 2024
 - [https://pakobserver.net/islamabad-announces-nine-school-holidays-for-elections-2024](https://pakobserver.net/islamabad-announces-nine-school-holidays-for-elections-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T14:05:03+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/BeFunky-collage-23-1024x512-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; The interim federal government has announced nine-day election holidays in all schools, colleges and higher educational institutions in Islamabad for general elections 2024. Following the announcement of Punjab and Sindh, the Ministry of Federal Education and Professional Training said schools will remain closed from February 6 to 9 for general elections. “In view [&#8230;]

## Punjab implements ‘Ab Gaon Chamkay Gy’ sanitation project
 - [https://pakobserver.net/punjab-implements-ab-gaon-chamkay-gy-sanitation-project](https://pakobserver.net/punjab-implements-ab-gaon-chamkay-gy-sanitation-project)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T13:57:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/sanit-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – Punjab government has successfully implemented “Ab Gaon Chamkay Gy” sanitation project across the province. As per details, a total of 11.6 million sanitation activities, of which 10.45 million were verified, have been performed in the 21,535 villages of 35 districts since its launch in August 2023. A total of 7,703 staffers have been [&#8230;]

## Weather outlook of Murree, Galyat, Pakistan’s other tourist destinations
 - [https://pakobserver.net/weather-outlook-of-murree-galyat-pakistans-other-tourist-destinations](https://pakobserver.net/weather-outlook-of-murree-galyat-pakistans-other-tourist-destinations)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T13:30:49+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/snoww-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD – The Pakistan Meteorological Department (PMD) has predicted more rain and snowfall in Murree, Galyat and other tourist destinations in Pakistan during this week. As per the synoptic situation, a westerly wave prevails over upper parts of Pakistan. It is likely to affect Pakistan&#8217;s southern and western parts from today evening/night. Under these conditions, [&#8230;]

## Pakistan Army leads efforts to rescue stranded tourists in Murree
 - [https://pakobserver.net/pakistan-army-leads-efforts-to-rescue-stranded-tourists-in-murree](https://pakobserver.net/pakistan-army-leads-efforts-to-rescue-stranded-tourists-in-murree)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T13:13:04+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/0200-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />RAWALPINDI &#8211; Pakistan Army personnel lead rescue operations to evacuate stranded tourists from Murree as heavy snowfall badly affected the traffic flow. The country’s most visited tourist site received the season’s first snowfall this week, blanketing the hill station with 10 inches of snow. The extreme snowfall resulted in traffic jams, with passenger cars breaking [&#8230;]

## Lahore, Punjab weather update; more rains expected
 - [https://pakobserver.net/lahore-punjab-weather-update-more-rains-expected](https://pakobserver.net/lahore-punjab-weather-update-more-rains-expected)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T12:46:28+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/08/LHR-3-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; LAHORE &#8211; The Pakistan Meteorological Department (PMD) has forecast partly cloudy weather with chances of rainfall of varying intensities for Lahore and parts of Punjab during the week. As per the synoptic situation, a westerly wave prevails over upper parts of Pakistan. It is likely to affect southern and western parts of the country [&#8230;]

## Rain likely in Karachi, Hyderabad, parts of Sindh
 - [https://pakobserver.net/rain-likely-in-karachi-hyderabad-parts-of-sindh](https://pakobserver.net/rain-likely-in-karachi-hyderabad-parts-of-sindh)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T12:23:02+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/08/rains-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; The Pakistan Meteorological Department (PMD) has forecast partly cloudy weather with chances of scattered rains for Karachi, Hyderabad and parts of Sindh on Friday and Saturday. As per the synoptic situation, a westerly wave prevails over upper parts of Pakistan. It is likely to affect southern and western parts of the country from [&#8230;]

## Kia Sportage price increased by Rs2.5 lacs; Check new rates here
 - [https://pakobserver.net/kia-sportage-price-increased-by-rs2-5-lacs-check-new-rates-here](https://pakobserver.net/kia-sportage-price-increased-by-rs2-5-lacs-check-new-rates-here)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T12:22:48+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/hh43-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; Lucky Motor Corporation (LMC), the maker of Kia cars in Pakistan, became the first auto company to announce its first price hike in 2024, as its famous small crossover SUV Sportage saw a price increase of Rs250,000. A new price notification by the company shows a price hike for Kia Picanto, and Sportage. [&#8230;]

## Peshawar, Khyber Pakhtunkhwa weather; wet spell continues
 - [https://pakobserver.net/peshawar-khyber-pakhtunkhwa-weather-wet-spell-continues](https://pakobserver.net/peshawar-khyber-pakhtunkhwa-weather-wet-spell-continues)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T11:51:55+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/KPW-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />PESHAWAR &#8211; The Pakistan Meteorological Department (PMD) has predicted more rains with snowfall over mountains for Peshawar and parts of Khyber Pakhtunkhwa during this week. As per the synoptic situation, a westerly wave prevails over upper parts of Pakistan. It is likely to affect southern and western parts of the country from today evening/night. Under [&#8230;]

## Islamabad, Pakistan weather update; more rains, snowfall expected
 - [https://pakobserver.net/islamabad-pakistan-weather-update-more-rains-snowfall-expected](https://pakobserver.net/islamabad-pakistan-weather-update-more-rains-snowfall-expected)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T11:31:54+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/ISD0-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ISLAMABAD &#8211; The Pakistan Meteorological Department (PMD) has predicted rainfall of varying intensities with snowfall over mountains for Islamabad and parts of Pakistan during this week. As per the synoptic situation, a westerly wave prevails over upper parts of Pakistan. It is likely to affect southern and western parts of the country from today evening/night. [&#8230;]

## Sindh govt announces week-long election holidays for schools
 - [https://pakobserver.net/sindh-announces-week-long-election-holidays-for-schools](https://pakobserver.net/sindh-announces-week-long-election-holidays-for-schools)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T11:29:59+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/punjab-announces-4-day-school-holiday-due-to-pink-eye-infection-1695813040-7798-150x150.jpeg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; The interim government in Sindh on Thursday announced five election holidays in all schools, and higher educational institutions across province. All government and private schools, colleges, and universities in Sindh will remain closed from February 5 to February 9 for the upcoming general election that is set to be held on February 8, [&#8230;]

## Gold rates in Saudi Arabia today – 01 February 2024
 - [https://pakobserver.net/gold-rates-in-saudi-arabia-today-01-february-2024](https://pakobserver.net/gold-rates-in-saudi-arabia-today-01-february-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T06:02:00+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/gold-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />LAHORE – The price of per tola price 24-karat gold in Saudi Arabia on Thursday surged to 2,880 Saudi Riyal (SAR), according to forex.pk. Furthermore, the 10 grams of 24-k gold is being sold for SAR 2,472 in the kingdom while the per ounce gold price stands at SAR 7,688. Note: The gold price across [&#8230;]

## UK Pound to PKR rate today – 01 Febryary 2024
 - [https://pakobserver.net/uk-pound-to-pkr-rate-today-01-febryary-2024](https://pakobserver.net/uk-pound-to-pkr-rate-today-01-febryary-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T05:56:29+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/pound-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI &#8211; The buying rate of the UK Pound Sterling declined to Rs354 in Pakistan while its selling rate stands at Rs357 on Thursday in open market of Pakistan. Data available on forex.pk showed that the Pound shed Rs1 against Pakistani rupee in open market. GBP to PKR Rate – 01 February 2024 Date  Latest [&#8230;]

## Saudi Riyal to PKR rate today – 01 February 2024
 - [https://pakobserver.net/saudi-riyal-to-pkr-rate-today-01-february-2024](https://pakobserver.net/saudi-riyal-to-pkr-rate-today-01-february-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T05:42:20+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/riyal-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The buying rate for Saudi Arabia Riyal in Pakistan stands at Rs74.5 while the selling rate stands at Rs75.5 on Thursday, according to forex.pk. Data available on the currency website showed no change in exchange rate of Saudi Riyal to Pakistani currency. SAR to PKR Rate – 01 February 2024 Date  Latest Exchange [&#8230;]

## Dirham to PKR rate today – 01 February 2024
 - [https://pakobserver.net/dirham-to-pkr-rate-today-01-february-2024](https://pakobserver.net/dirham-to-pkr-rate-today-01-february-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T05:29:05+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/09/dirham-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – United Arab Emirates (UAE) Dirham buying rate in open market of Pakistan slightly drops to Rs76.4 on Thursday while the selling rate is Rs77.3. The UAE Dirham dropped 20 paisas as compared to previous day&#8217;s closing of Rs76.6 in open market of the South Asian country. AED to PKR Rate – 01 February [&#8230;]

## Currency exchange rates in Pakistan today – February 1, 2024
 - [https://pakobserver.net/currency-exchange-rates-in-pakistan-today-february-1-2024](https://pakobserver.net/currency-exchange-rates-in-pakistan-today-february-1-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T04:16:08+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/curreny-rate-today-15-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The exchange rate for one US Dollar against Pakistani rupees was recorded at Rs 279.5 in the local and open market, with a selling rate of Rs 281.7 on Thursday, February 1, 2024. Note: Exchange rates can vary based on the location and the Exchange Company or bank involved in the transaction. Below are [&#8230;]

## Gold rate in Pakistan today – 1 February, 2024
 - [https://pakobserver.net/gold-rate-in-pakistan-today-1-february-2024](https://pakobserver.net/gold-rate-in-pakistan-today-1-february-2024)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T03:51:27+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/gold-rate-in-pakistan-today-24-March-2023-1-1024x576-4-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />KARACHI – The gold rate of 24-karat is traded at PKR 220,800 on Thursday, February 1, 2024. Similarly, the gold price for 24-karat was recorded at Rs 189,900 per 10g as per the bullion market. Gold Price in Pakistan’s different cities. City Gold Silver Karachi PKR 220,800 PKR 2,450 Lahore PKR 220,800 PKR 2,450 Islamabad [&#8230;]

## Voice of the people
 - [https://pakobserver.net/voice-of-the-people-1535](https://pakobserver.net/voice-of-the-people-1535)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T03:12:48+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/op-1-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Articles and letters may be edited for the purposes of clarity and space. &#160; Cypher case It was a Dooms Day when ex-Prime Minister Imran Khan and ex-Foreign Minister Shah Mahmood Qureshi handed a sentence of 10 years for flashing state secrets, after a lengthy trial in a Special Court. The tenacity of questions making [&#8230;]

## From sadness to strength..!
 - [https://pakobserver.net/from-sadness-to-strength](https://pakobserver.net/from-sadness-to-strength)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T03:11:52+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2021/02/rb-10-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />THIS happened many years ago. The old lady sat in the room sobbing. The old man, her husband, a retired army major, stared straight ahead. They had just lost their son in a motor- bike accident. I sat holding her hand, there was nothing I could say; the grief was intense, unbearable. Suddenly the lady [&#8230;]

## Unmasking India’s reign of terror
 - [https://pakobserver.net/unmasking-indias-reign-of-terror](https://pakobserver.net/unmasking-indias-reign-of-terror)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T03:10:17+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/04/Attiya-Munawer-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />THE Pakistani nation is not only fighting the scourge of terrorism with courage and bravery but also making eternal sacrifices. While the Pakistan Army is fighting a long war against terrorism with dedication and professionalism, India, as an enemy in the neighbourhood of Pakistan, keeps using new tactics to harm it. On one hand, India [&#8230;]

## Credibility of Gentleman’s game of cricket
 - [https://pakobserver.net/credibility-of-gentlemans-game-of-cricket](https://pakobserver.net/credibility-of-gentlemans-game-of-cricket)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T03:09:28+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/05/Malik-Tariq-Ali-1-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ICC had suspended Sri Lanka’s cricket board SLC, following a sequence of events involving their Minister for Sports, which point to government interference. The suspension was lifted on 28 January 2024 after the Sports Minister Roshan was sacked. In 2011 former CEO ICC, Haroon Lorgat (2008-2012), a businessman and chartered accountant from South Africa, who [&#8230;]

## Tripartite collaboration for economic growth
 - [https://pakobserver.net/tripartite-collaboration-for-economic-growth](https://pakobserver.net/tripartite-collaboration-for-economic-growth)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T03:08:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/12/Dr-Zafar-Khan-Safdar-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />AS an effective way to deepen the dynamic docking and advantage integration between market-technological entity and socio-economic growth, the joint establishment of scientific research bases plays an important role in promoting the long-term and stable cooperation between industry, university and the government. It is proven through research studies that the joint establishment of scientific research [&#8230;]

## Constitution, political party and election symbol
 - [https://pakobserver.net/constitution-political-party-and-election-symbol](https://pakobserver.net/constitution-political-party-and-election-symbol)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T03:07:14+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/05/hafiz-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />EVERYONE has the right to form groups or unions, as recognized by the Elections Act of 2017 and Article 17 of the Constitution (which has been amended four times since 1973), subject to any reasonable restrictions imposed by the law in the interest of public order, morality, or Pakistan&#8217;s sovereignty or integrity. Any Pakistani citizen [&#8230;]

## ICJ holds Israel accountable to CPPCG obligations
 - [https://pakobserver.net/icj-holds-israel-accountable-to-cppcg-obligations](https://pakobserver.net/icj-holds-israel-accountable-to-cppcg-obligations)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T03:06:04+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/Syed-Qamar-Rizvi-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />ON Friday, the voice of justice echoed in The Hague Peace Palace where The International Court of justice (ICJ) while issuing its interim order in the case South Africa v. Israel, with a majority opinion, upheld South Africa’s call for justice to prevent the ongoing Israeli acts of genocide in the Gaza Strip. The World [&#8230;]

## FBR Revamp: Path to Progress
 - [https://pakobserver.net/fbr-revamp-path-to-progress](https://pakobserver.net/fbr-revamp-path-to-progress)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T03:05:19+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/editorial-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />&#160; IN a significant move aimed at addressing declining tax-to-GDP ratio, the federal cabinet Tuesday approved a restructuring plan for the Federal Board of Revenue (FBR). It envisaged enhancing the efficiency and effectiveness of tax collection, digitizing processes and separate policy functions from operational tasks. However, the ECP intervened, restraining the caretaker government from implementing [&#8230;]

## Kazakhstan seeks broader cooperation with Pakistan in diverse areas: Ambassador Yerzhan
 - [https://pakobserver.net/kazakhstan-seeks-broader-cooperation-with-pakistan-in-diverse-areas-ambassador-yerzhan](https://pakobserver.net/kazakhstan-seeks-broader-cooperation-with-pakistan-in-diverse-areas-ambassador-yerzhan)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:45:55+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/80x4-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Ambassador of Kazakhstan Mr Yerzhan Kistafin and CEO &#38; Chairman of Pakistan Observer Mr Faisal Zahid Malik discuss matters of mutual interest between Pakistan and Kazakhstan.—PO photo by Sh Arif Kazakhstan and Pakistan enjoy a deep and strong bond of friendship based on mutual respect and understanding spanning over decades of bilateral cooperation. These views [&#8230;]

## 851 candidates to contest polls in Faisalabad
 - [https://pakobserver.net/851-candidates-to-contest-polls-in-faisalabad](https://pakobserver.net/851-candidates-to-contest-polls-in-faisalabad)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:45:54+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />In general elections being held on February 8, 2024, as many as 851 candidates would contest polls from 31 seats of Faisalabad, which is the third major metropolis of the country. A spokesman for the Election Commission of Pakistan (ECP) said on Wednesday that there were 10 National Assembly and 21 provincial assembly seats in [&#8230;]

## Provision of facilities to tourists reviewed
 - [https://pakobserver.net/provision-of-facilities-to-tourists-reviewed](https://pakobserver.net/provision-of-facilities-to-tourists-reviewed)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:45:53+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Kaghan Development Authority (KDA) meeting on Wednesday reviewed the provision of facilities to tourists visiting Kaghan valley during snowfall season. An important meeting of KDA chaired by its Director General (DG) Shabeer Khan was held at its head office and attended by Deputy Director KG and other officials concerned. The meeting had a detailed look [&#8230;]

## Sania Nishtar, Mushahid felicitated
 - [https://pakobserver.net/sania-nishtar-mushahid-felicitated](https://pakobserver.net/sania-nishtar-mushahid-felicitated)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:45:52+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2020/12/sania-nishtar-1-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Senate Standing Committee on Law and Justice has extended warm felicitations to Senator Sania Nishtar for her appointment as the CEO of GAVI and acknowledged and congratulated Senator Mushahid Hussain Sayyed on his election as the Vice President of IPU’s Human Rights Body. During the meeting of Senate Body held under the chair of [&#8230;]

## Rs60m allocated for Landikotal girls degree college
 - [https://pakobserver.net/rs60m-allocated-for-landikotal-girls-degree-college](https://pakobserver.net/rs60m-allocated-for-landikotal-girls-degree-college)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:45:51+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Nasib Shah Shinwari Landikotal Former MPA and Pakistan Muslim League (N) PK-69 candidate Shafiq Sher said the other day, that he has succeeded to allocate Rs.60 million rupees with 80 Kanals of Land for the first ever girls degree college in Landikotal tehsil of district Khyber. Shafiq Sher was speaking to meet the press program [&#8230;]

## Speakers agree for promoting gender equality to address poverty
 - [https://pakobserver.net/speakers-agree-for-promoting-gender-equality-to-address-poverty](https://pakobserver.net/speakers-agree-for-promoting-gender-equality-to-address-poverty)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:45:50+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The speakers in the consultation organized by the National Commission on the Status of Women (NCSW) on Wednesday agreed that promoting gender equality to address poverty, requires a multifaceted approach that tackles the root causes and empowers both men and women. The participants raised gender issues and poverty with a focus on the economic empowerment [&#8230;]

## CM KP directs to compliance with Urban Mobility Plan for Abbottabad
 - [https://pakobserver.net/cm-kp-directs-to-compliance-with-urban-mobility-plan-for-abbottabad](https://pakobserver.net/cm-kp-directs-to-compliance-with-urban-mobility-plan-for-abbottabad)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:45:48+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/11/Syed-Arshad-Hussain-Shah-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Caretaker Chief Minister Khyber Pakhtunkhwa, Justice (r) Syed Arshad Hussain Shah chaired a meeting in Islamabad to deliberate on the Urban Mobility Plan concerning divisional headquarter Abbottabad. In the meeting, senior officials from the National Highways Authority (NHA), Planning Commission, as well as pertinent federal and provincial officials were also present. The meeting focused on [&#8230;]

## Asad Qaiser terms Toshakhana sentence ‘murder of justice’
 - [https://pakobserver.net/asad-qaiser-terms-toshakhana-sentence-murder-of-justice](https://pakobserver.net/asad-qaiser-terms-toshakhana-sentence-murder-of-justice)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:42:36+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/10/asad-qasar-5-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Reacting to the sentence handed down to PTI founder Imran Khan and his wife Bushra Bib in Toshakhan reference Wednesday, former National Assembly speaker and party leader Asad Qaiser said that what is happening in courts, is a murder of justice. The former speaker said that they already knew what kind of decisions were coming. [&#8230;]

## Rain, snowfall over mountain expected in GB, KP, Kashmir
 - [https://pakobserver.net/rain-snowfall-over-mountain-expected-in-gb-kp-kashmir](https://pakobserver.net/rain-snowfall-over-mountain-expected-in-gb-kp-kashmir)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:42:35+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/met-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Rain and snowfall over mountain is expected in Gilgit Baltistan, Khyber Pakhtunkhwa, Potohar region, Islamabad, Upper Punjab and Kashmir during the next twelve hours. Fog is likely to prevail at few places in South Punjab and upper Sindh. Temperature of major cities recorded this morning. Islamabad ten degree centigrade, Lahore eleven, Karachi twenty-one, Peshawar eight, [&#8230;]

## Man kills sister in law over dispute
 - [https://pakobserver.net/man-kills-sister-in-law-over-dispute](https://pakobserver.net/man-kills-sister-in-law-over-dispute)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T02:42:32+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2022/11/pak-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Raza Naqvi Attock A man has shot dead his sister in law in day broad light assassination incident on a busy road in Fatehjang town of Attock on Wednesday, Police sources said. Hamamd Riffat has reported to Police that his sister contracted marriage with Haseeb Khan some years ago. On Wednesday, his sister was going [&#8230;]

## Kazakhstan movie “Kazakh Khanate: Diamond Sword” screened
 - [https://pakobserver.net/kazakhstan-movie-kazakh-khanate-diamond-sword-screened](https://pakobserver.net/kazakhstan-movie-kazakh-khanate-diamond-sword-screened)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:47:27+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/FF-1-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Ambassador of Kazakhstan Mr Yerzhan Kistafin briefing about paintings to Federal Minister for National Heritage and Culture, CEO and Chairman of Pakistan Observer Mr Faisal Zahid Malik during movie screening. PO photo Zubair Qureshi In a bid to further strengthen cultural relations, Pakistan National Council of the Arts (PNCA) and the Embassy of Kazakhstan organized [&#8230;]

## Call for joint efforts to reduce harmful emissions at sea
 - [https://pakobserver.net/call-for-joint-efforts-to-reduce-harmful-emissions-at-sea](https://pakobserver.net/call-for-joint-efforts-to-reduce-harmful-emissions-at-sea)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:47:17+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/3-x-50-NIMA-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The National Institute of Maritime Affairs (NIMA) organized a seminar on the International Maritime Organization’s (IMO) Obligations of Reducing Harmful Emissions at Sea and Pakistan’s Response and Challenges’ on Wednesday. The speakers while addressing the event called for joint efforts to ensure greener seas and reduce harmful emissions into their waters. Former DG NIMA, Vice [&#8230;]

## Minister assures CSOs measures to curb iTFAs in all dietary sources
 - [https://pakobserver.net/minister-assures-csos-measures-to-curb-itfas-in-all-dietary-sources](https://pakobserver.net/minister-assures-csos-measures-to-curb-itfas-in-all-dietary-sources)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:47:13+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/3-x-50-Health-Minister-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Caretaker Federal Minister for National Health Service, Regulation &#38; Coordination (NHSRC), Dr. Nadeem Jan has reiterated the health ministry’s commitment to take all possible measures to regulate industrially produced trans-fatty acids in all foods and reduce consumption of unhealthy diets to save precious lives. He expressed these views during his meeting with a coalition of [&#8230;]

## Education can help change country’s fate: President
 - [https://pakobserver.net/education-can-help-change-countrys-fate-president](https://pakobserver.net/education-can-help-change-countrys-fate-president)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:47:11+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/10/alvi-150x150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="150" />President Dr Arif Alvi on Wednesday said through the combination of education, intellect and morality, the youth could change the fate of the country. He said Pakistan needed leadership and proper use of intellect more than the solutions, which he believed the youth of the country was fully capable of playing this role. Addressing the [&#8230;]

## CDA launches cleanliness drive for markets
 - [https://pakobserver.net/cda-launches-cleanliness-drive-for-markets](https://pakobserver.net/cda-launches-cleanliness-drive-for-markets)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:47:05+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2023/03/cda-1-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The Capital Development Authority (CDA) on Wednesday launched special drive for cleaning of markets in the federal capital. The special cleanliness drive was kick started from Aabpara market and it will be extended rest of the commercial areas of the city. Various teams were formed by the Sanitation Directorate for said special campaign, which will [&#8230;]

## Bomb threat to Adiala Jail: DIG Jail seeks security enhancement
 - [https://pakobserver.net/bomb-threat-to-adiala-jail-dig-jail-seeks-security-enhancement](https://pakobserver.net/bomb-threat-to-adiala-jail-dig-jail-seeks-security-enhancement)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:47:03+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/ibd-11-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />The administration of Adiala Jail in Rawalpindi has received a bomb threat from an anonymous caller who claimed to be from Afghanistan. The caller warned that he would blow up the jail in three days and said that five terrorists had already attacked Machh Jail. The jail authorities informed the law enforcement agencies, the Rawalpindi [&#8230;]

## Operation conducted against unlawful incursions, double parking
 - [https://pakobserver.net/operation-conducted-against-unlawful-incursions-double-parking](https://pakobserver.net/operation-conducted-against-unlawful-incursions-double-parking)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:47:01+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/ibd-11-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Following the special instructions of the Islamabad Capital City Police Officer (ICCPO), Dr. Akbar Nasir Khan, under the supervision of CPO Safe City/Traffic, Islamabad Capital Police conducted a grand operation against unlawful incursions and double parking in the rural area, a public relations officer said. He said that the locations where actions were taken include [&#8230;]

## Pakistan attaches great importance to bilateral relations with Sri Lanka: President
 - [https://pakobserver.net/pakistan-attaches-great-importance-to-bilateral-relations-with-sri-lanka-president](https://pakobserver.net/pakistan-attaches-great-importance-to-bilateral-relations-with-sri-lanka-president)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:46:59+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/02/3-x-65-54669-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />President Dr Arif Alvi has said that Pakistan attached great importance to its bilateral relations with Sri Lanka, which spanned over seven decades of the strong bonds He stated this while talking to Pakistan’s High Commissioner-designate to Sri Lanka Major General (Retd) FaheemUl Aziz who called on him here on Wednesday, said a President House [&#8230;]

## IoT-fuel monitoring system opens
 - [https://pakobserver.net/iot-fuel-monitoring-system-opens](https://pakobserver.net/iot-fuel-monitoring-system-opens)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:46:57+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/ibd-11-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Caretaker Federal Minister for Railways, Communication and Maritime Affairs, Shahid Ashraf Tarar Wednesday inaugurated Internet of Things (IoT)-based Monitoring System in Pakistan Railways. The initiative is in line with the Ministry of Railways decision to equip the locomotives with latest gadgets to conduct online monitoring to enhance financial and operational efficiency.

## Speakers laud late Pervaiz Shaukat’s services for journalist community
 - [https://pakobserver.net/speakers-laud-late-pervaiz-shaukats-services-for-journalist-community](https://pakobserver.net/speakers-laud-late-pervaiz-shaukats-services-for-journalist-community)
 - RSS feed: https://pakobserver.net/feed/
 - date published: 2024-02-01T01:46:44+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="150" src="https://pakobserver.net/wp-content/uploads/2024/01/ibd-11-150x150.webp" style="display: block; margin-bottom: 5px; clear: both;" width="150" />Speakers at a condolence reference, organised to pay tributes to veteran journalist and trade union activist Pervaiz Shaukat, said that approval of new Wage Board Award and enactment and implementation of laws for the security and protection of journalists were the fruit of untiring struggle of the deceased. They termed Pervez Shaukat’s life a role [&#8230;]

