# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Apple Vision Pro Is Hiding a Little Secret: A Fat Lightning Cable
 - [https://gizmodo.com/apple-vision-pro-fat-lightning-cable-1851216230](https://gizmodo.com/apple-vision-pro-fat-lightning-cable-1851216230)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2024-02-01T16:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/b523ed45abcb342e4f767783817afe3e.png" /><p>Somehow, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://x.com/GregoryMcFadden/status/1752789854432190650?s=20" rel="noopener noreferrer" target="_blank">Lightning returned</a>. Apple’s $3,500 <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/apple-vision-pro-pricing-release-date-specs-1851205316">Vision Pro is going on sale</a> Friday, and unlike most other high-end VR headsets, it’s sporting an external battery pack. Little did we know, but that external battery with its supposedly non-detachable wire is actually easily removable so long as you have a SIM card removal…</p><p><a href="https://gizmodo.com/apple-vision-pro-fat-lightning-cable-1851216230">Read more...</a></p>

