# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Preview: Asian Cup 2023 quarterfinals
 - [https://www.aljazeera.com/sports/2024/2/1/titans-prepare-to-do-battle-as-the-asian-cup-hots-up-in-the-quarterfinals?traffic_source=rss](https://www.aljazeera.com/sports/2024/2/1/titans-prepare-to-do-battle-as-the-asian-cup-hots-up-in-the-quarterfinals?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T22:09:59+00:00

The Asian Cup quarterfinals pit regional giants against each other but also see underdogs take on the holders.

## US judge urges Biden to examine support for ‘plausible genocide’ in Gaza
 - [https://www.aljazeera.com/news/2024/2/1/us-judge-urges-biden-to-examine-support-for-plausible-genocide-in-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/us-judge-urges-biden-to-examine-support-for-plausible-genocide-in-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T21:03:02+00:00

Despite dismissal of a case accusing officials of complicity in Gaza &#039;genocide&#039;, advocates say ruling marks a victory.

## Israel is creating a ‘buffer zone’ around Gaza
 - [https://www.aljazeera.com/program/newsfeed/2024/2/1/israel-is-creating-a-buffer-zone-around-gaza?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/2/1/israel-is-creating-a-buffer-zone-around-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T20:32:09+00:00

Israel is creating a ‘buffer zone’ around Gaza, which Israeli media reports says will ‘prevent attackers’.

## US imposes sanctions on four Israeli settlers over West Bank violence
 - [https://www.aljazeera.com/news/2024/2/1/us-imposes-sanctions-on-four-israeli-settlers-over-west-bank?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/us-imposes-sanctions-on-four-israeli-settlers-over-west-bank?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T19:48:27+00:00

White House says settler violence in occupied West Bank threatens US &#039;national security and foreign policy interests&#039;.

## Preview: CAF AFCON 2023 quarterfinals
 - [https://www.aljazeera.com/sports/2024/2/1/how-the-caf-afcon-2023-quarterfinals-shape-up-africa-cup-of-nations-football-nigeria-ivory-coast?traffic_source=rss](https://www.aljazeera.com/sports/2024/2/1/how-the-caf-afcon-2023-quarterfinals-shape-up-africa-cup-of-nations-football-nigeria-ivory-coast?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T19:40:57+00:00

Al Jazeera previews the four Africa Cup of Nations quarterfinals that see a mix of favourites and minnows face off.

## In a sign of commitment, EU unlocks aid for Ukraine as it fights off Russia
 - [https://www.aljazeera.com/news/2024/2/1/in-a-sign-of-commitment-eu-unlocks-aid-for-ukraine-as-it-fights-off-russia?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/in-a-sign-of-commitment-eu-unlocks-aid-for-ukraine-as-it-fights-off-russia?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T19:36:39+00:00

Deal will help Ukraine cover its wartime deficit, but experts question what concessions were made to assure its passage.

## Formula One: Lewis Hamilton to leave Mercedes for Ferrari in 2025
 - [https://www.aljazeera.com/sports/2024/2/1/formula-one-lewis-hamilton-to-leave-mercedes-for-ferrari-in-2025?traffic_source=rss](https://www.aljazeera.com/sports/2024/2/1/formula-one-lewis-hamilton-to-leave-mercedes-for-ferrari-in-2025?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T19:33:40+00:00

Lewis Hamilton will leave Mercedes at the end of this year to join Ferrari, both F1 teams have confirmed.

## South Carolina primary set to test Biden’s support among Black voters
 - [https://www.aljazeera.com/news/2024/2/1/south-carolina-primary-set-to-test-bidens-support-among-black-voters?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/south-carolina-primary-set-to-test-bidens-support-among-black-voters?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T19:05:25+00:00

US president&#039;s campaign wants to show it can energise Black voters who were key to his narrow 2020 presidential victory.

## Could today’s global conflicts bring World War III closer?
 - [https://www.aljazeera.com/program/inside-story/2024/2/1/could-todays-global-conflicts-bring-world-war-iii-closer?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/2/1/could-todays-global-conflicts-bring-world-war-iii-closer?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T18:42:56+00:00

Global wars are raging with major powers in the East and West often arming opposing sides.

## French farmers unions call to end protests as PM unveils new measures
 - [https://www.aljazeera.com/news/2024/2/1/french-farmers-unions-call-to-end-protests-as-pm-unveils-new-measures?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/french-farmers-unions-call-to-end-protests-as-pm-unveils-new-measures?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T18:00:37+00:00

Gabriel Attal pledged a &#039;future&#039; for France&#039;s agriculture sector and promised solutions to combat bans and fraud.

## Tunisian opposition leader Rached Ghannouchi sentenced to three years
 - [https://www.aljazeera.com/news/2024/2/1/tunisian-opposition-leader-rached-ghannouchi-sentenced-to-three-years?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/tunisian-opposition-leader-rached-ghannouchi-sentenced-to-three-years?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T17:45:59+00:00

Ghannouchi&#039;s Ennahda Party accused of receiving foreign funds as President Kais Saied continues crackdown on opposition.

## New cancer cases to soar 77 percent by 2050, WHO predicts
 - [https://www.aljazeera.com/news/2024/2/1/new-cancer-cases-to-soar-77-percent-by-2050-who-predicts?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/new-cancer-cases-to-soar-77-percent-by-2050-who-predicts?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T16:08:49+00:00

There were an estimated 20 million new cancer cases in 2022, with more than 35 million new cases predicted by 2050.

## UN rights chief decries death of 50 people in Mali attacks
 - [https://www.aljazeera.com/news/2024/2/1/un-rights-chief-decries-death-of-50-people-in-mali-attacks?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/un-rights-chief-decries-death-of-50-people-in-mali-attacks?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T15:40:32+00:00

The UN official said he was &#039;appalled&#039; by the killings in central Mali.

## UN experts condemn ‘disturbing’ attacks on journalists in Gaza
 - [https://www.aljazeera.com/news/2024/2/1/un-experts-condemn-disturbing-attacks-on-journalists-in-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/un-experts-condemn-disturbing-attacks-on-journalists-in-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T15:34:37+00:00

Officials suggest the targeting of journalists may be a &#039;deliberate strategy by Israeli forces&#039; to silence reporting.

## Hezbollah explained | Start Here
 - [https://www.aljazeera.com/program/start-here/2024/2/1/hezbollah-explained-start-here?traffic_source=rss](https://www.aljazeera.com/program/start-here/2024/2/1/hezbollah-explained-start-here?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T15:31:50+00:00

What is Hezbollah, and how is it linked to the Israel-Gaza war?

## Why has a court blocked Elon Musk’s $56bn Tesla pay?
 - [https://www.aljazeera.com/news/2024/2/1/why-did-a-court-cancel-elon-musks-tesla-salary-package?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/why-did-a-court-cancel-elon-musks-tesla-salary-package?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T14:37:42+00:00

Judge calls Tesla boss&#039;s pay &#039;unfathomable&#039;. Ruling could affect his standing as the world&#039;s richest man.

## What is UNRWA and why it is important for Palestinians?
 - [https://www.aljazeera.com/news/2024/2/1/what-is-unrwa-and-why-it-is-important-for-palestinians?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/what-is-unrwa-and-why-it-is-important-for-palestinians?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T14:32:17+00:00

The UN agency, which supports 6 million Palestinian refugees, is the main aid provider in Gaza amid Israeli bombardment.

## Why did Mark Zuckerberg apologise at the US Senate?
 - [https://www.aljazeera.com/news/2024/2/1/why-did-mark-zuckerberg-apologise-at-the-us-senate?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/why-did-mark-zuckerberg-apologise-at-the-us-senate?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T14:29:23+00:00

Parents of affected children said the Meta CEO&#039;s apology was &#039;a bit too late&#039;.

## Tunisia’s Saied wants to make the central bank fill the budget deficit
 - [https://www.aljazeera.com/news/2024/2/1/tunisias-saied-wants-to-make-the-central-bank-fill-the-budget-deficit?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/tunisias-saied-wants-to-make-the-central-bank-fill-the-budget-deficit?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T14:09:21+00:00

By borrowing billions from the central bank to shore up budget, the president could well worsen Tunisia&#039;s economic woes.

## Mother of 6-year-old missing in Gaza recounts last phone calls
 - [https://www.aljazeera.com/program/newsfeed/2024/2/1/mother-of-6-year-old-missing-in-gaza-recounts-last-phone-calls?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/2/1/mother-of-6-year-old-missing-in-gaza-recounts-last-phone-calls?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T13:59:22+00:00

The mother of missing 6-year-old Hind Hamadeh from Gaza has told Al Jazeera about the last phone calls she had with her.

## Is South Africa’s foreign policy contradictory or a balancing act?
 - [https://www.aljazeera.com/features/2024/2/1/is-south-africas-foreign-policy-contradictory-or-a-balancing-act?traffic_source=rss](https://www.aljazeera.com/features/2024/2/1/is-south-africas-foreign-policy-contradictory-or-a-balancing-act?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T13:57:03+00:00

South Africa&#039;s stance on global issues in the last year has confounded many. Some analysts say it is a balancing act.

## The French Algerians moving to Algeria ‘seeking freedom, opportunity’
 - [https://www.aljazeera.com/features/2024/2/1/the-french-algerians-moving-to-algeria-seeking-freedom-opportunity?traffic_source=rss](https://www.aljazeera.com/features/2024/2/1/the-french-algerians-moving-to-algeria-seeking-freedom-opportunity?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T13:53:25+00:00

What was once a one-way street heading north is now a two-lane highway with some people heading south out of France.

## Russian court extends detention of US journalist Kurmasheva until April
 - [https://www.aljazeera.com/news/2024/2/1/russian-court-extends-detention-of-us-journalist-kurmasheva-until-april?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/russian-court-extends-detention-of-us-journalist-kurmasheva-until-april?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T13:38:36+00:00

Russian-American journalist is accused of failing to register as a ‘foreign agent’ and spreading ‘false information’.

## Bodies of ‘torture victims’ found at Gaza school
 - [https://www.aljazeera.com/program/newsfeed/2024/2/1/bodies-of-torture-victims-found-at-gaza-school?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/2/1/bodies-of-torture-victims-found-at-gaza-school?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T12:30:46+00:00

The killing of dozens of people whose bodies were found at a Gaza school was a clear war crime, says human rights lawyer

## Hindu prayers begin inside India’s Mughal-era mosque after court order
 - [https://www.aljazeera.com/news/2024/2/1/hindu-prayers-begin-inside-indias-mughal-era-mosque-after-court-order?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/hindu-prayers-begin-inside-indias-mughal-era-mosque-after-court-order?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T12:08:07+00:00

Worshippers are praying inside the 17th century mosque adjacent to a Hindu temple in Varanasi after the court order.

## Journalists, activists targeted in Jordan with Israeli-made Pegasus spyware
 - [https://www.aljazeera.com/news/2024/2/1/journalists-activists-targeted-in-jordan-with-israeli-made-pegasus-spyware?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/journalists-activists-targeted-in-jordan-with-israeli-made-pegasus-spyware?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T11:55:56+00:00

Report by Access Now says hackers used the malware to break into smartphones of dozens of people in Jordan.

## Magic mushroom therapy is booming in Jamaica
 - [https://www.aljazeera.com/program/mindset/2024/2/1/magic-mushroom-therapy-is-booming-in-jamaica?traffic_source=rss](https://www.aljazeera.com/program/mindset/2024/2/1/magic-mushroom-therapy-is-booming-in-jamaica?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T11:30:55+00:00

Mindset asks whether Jamaica’s psychedelic therapy retreats are a glimpse into the future of mental health treatment.

## India budget 2024: What does it say about the economy, elections?
 - [https://www.aljazeera.com/economy/2024/2/1/indias-2024-budget-what-does-it-say-about-the-economy-elections?traffic_source=rss](https://www.aljazeera.com/economy/2024/2/1/indias-2024-budget-what-does-it-say-about-the-economy-elections?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T11:25:49+00:00

The Modi government has snipped its food subsidy bill while also lowering its fiscal deficit target.

## Palestinians demand international inquiry after mass grave found in Gaza
 - [https://www.aljazeera.com/news/2024/2/1/palestinians-demand-international-inquiry-after-mass-grave-found-in-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/palestinians-demand-international-inquiry-after-mass-grave-found-in-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T11:04:16+00:00

Bodies of Palestinian detainees who were handcuffed, blindfolded discovered in plastic bags near northern Gaza school.

## The assassinations at Jenin hospital should not surprise anyone
 - [https://www.aljazeera.com/opinions/2024/2/1/the-assassinations-at-jenin-hospital-should-not-surprise-anyone?traffic_source=rss](https://www.aljazeera.com/opinions/2024/2/1/the-assassinations-at-jenin-hospital-should-not-surprise-anyone?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T10:52:06+00:00

Israeli forces have been targeting Palestinian healthcare in clear violation of international law for many years.

## European Union agrees on new $54bn aid package for Ukraine
 - [https://www.aljazeera.com/news/2024/2/1/european-union-agrees-on-new-54bn-aid-package-for-ukraine?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/european-union-agrees-on-new-54bn-aid-package-for-ukraine?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T10:42:41+00:00

Hungary previously vetoed the measure and criticised the bloc&#039;s military support for Ukraine.

## Zuckerberg apologises to families of children harmed by social media
 - [https://www.aljazeera.com/program/newsfeed/2024/2/1/zuckerberg-apologises-to-families-of-children-harmed-by-social-media?traffic_source=rss](https://www.aljazeera.com/program/newsfeed/2024/2/1/zuckerberg-apologises-to-families-of-children-harmed-by-social-media?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T10:32:40+00:00

Watch as the Meta CEO Mark Zuckerberg apologises to parents of children that have been harmed by social media.

## With UK PM under pressure, is Labour on track for a landslide election win?
 - [https://www.aljazeera.com/news/2024/2/1/uk-election-interview-tim-bale?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/uk-election-interview-tim-bale?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T09:36:58+00:00

Polling suggests a huge defeat for the Conservatives later this year. Professor Tim Bale says it&#039;s too early to predict.

## Ukraine, Russia fight from the skies as Kyiv’s EU aid hangs in the balance
 - [https://www.aljazeera.com/news/2024/2/1/vital-ukraine-aid-hangs-in-the-balance-as-eu-leaders-round-on-hungary?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/vital-ukraine-aid-hangs-in-the-balance-as-eu-leaders-round-on-hungary?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T09:25:29+00:00

A key summit focuses on aid as Russia says it will increase air defence missile production.

## Thailand deports dissident Russian rockers to Israel
 - [https://www.aljazeera.com/news/2024/2/1/thailand-deports-dissident-russian-rockers-to-israel?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/thailand-deports-dissident-russian-rockers-to-israel?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T09:00:40+00:00

Human rights advocates warned against sending Bi-2 to Russia where they could be persecuted for opposing Ukraine war.

## Israel’s war on Gaza: List of key events, day 118
 - [https://www.aljazeera.com/news/2024/2/1/israels-war-on-gaza-list-of-key-events-day-118?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/israels-war-on-gaza-list-of-key-events-day-118?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T08:45:23+00:00

Hospitals in Khan Younis remain under siege as Red Sea tensions rise.

## Chicago becomes latest US city to seek ceasefire in Israel’s war on Gaza
 - [https://www.aljazeera.com/news/2024/2/1/chicago-becomes-latest-us-city-to-seek-ceasefire-in-israels-war-on-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/chicago-becomes-latest-us-city-to-seek-ceasefire-in-israels-war-on-gaza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T08:11:54+00:00

City councillors narrowly approve nonbinding resolution that includes call for humanitarian aid and release of captives.

## US military targets 10 Houthi drones in new Yemen strikes
 - [https://www.aljazeera.com/news/2024/2/1/us-military-targets-10-houthi-drones-in-new-yemen-strikes?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/us-military-targets-10-houthi-drones-in-new-yemen-strikes?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T07:51:43+00:00

The Iran-aligned rebel group has warned of more attacks against US and British warships.

## US says it blocked China cyber-threat but warns hackers can ‘wreak havoc’
 - [https://www.aljazeera.com/news/2024/2/1/us-says-it-blocked-china-cyber-threat-but-warns-hackers-can-wreak-havoc?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/us-says-it-blocked-china-cyber-threat-but-warns-hackers-can-wreak-havoc?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T07:25:11+00:00

FBI says China state-sponsored hackers ramping up efforts to damage electric grid, transport systems, oil pipelines.

## ‘Dining table amputation’: How an Israeli bomb took Ahed Bseiso’s leg
 - [https://www.aljazeera.com/features/2024/2/1/dining-table-amputation-how-an-israeli-bomb-took-ahed-bseisos-leg?traffic_source=rss](https://www.aljazeera.com/features/2024/2/1/dining-table-amputation-how-an-israeli-bomb-took-ahed-bseisos-leg?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T07:05:32+00:00

Ahed Bseiso underwent a painful and traumatic procedure inside her besieged home following an Israeli shelling attack.

## In Pakistan’s elections, the Lord of the Rings is showing his wrath
 - [https://www.aljazeera.com/opinions/2024/2/1/in-pakistans-elections-the-lord-of-the-rings-is-showing-his-wrath?traffic_source=rss](https://www.aljazeera.com/opinions/2024/2/1/in-pakistans-elections-the-lord-of-the-rings-is-showing-his-wrath?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T06:49:22+00:00

He has decided to decimate the former governing party, Imran Khan&#039;s Pakistan Tehreek-e-Insaf. And no one will stop him.

## Pakistan’s Imran Khan is in political ruin. He’s partly to blame
 - [https://www.aljazeera.com/opinions/2024/2/1/pakistans-imran-khan-is-in-political-ruin-hes-partly-to-blame?traffic_source=rss](https://www.aljazeera.com/opinions/2024/2/1/pakistans-imran-khan-is-in-political-ruin-hes-partly-to-blame?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T06:32:38+00:00

The former PM&#039;s supporters portray him solely as the victim, but refuse to accept that he blundered too.

## Four found guilty of rioting over 2019 storming of Hong Kong legislature
 - [https://www.aljazeera.com/news/2024/2/1/four-found-guilty-of-rioting-over-2019-storming-of-hong-kong-legislature?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/four-found-guilty-of-rioting-over-2019-storming-of-hong-kong-legislature?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T04:14:39+00:00

The storming of the building marked an escalation in the 2019 mass protests that began over a China extradition bill.

## India’s Ayodhya wakes up to harsh realities after Modi’s Ram temple event
 - [https://www.aljazeera.com/features/2024/2/1/indias-ayodhya-wakes-up-to-harsh-realities-after-modis-ram-temple-event?traffic_source=rss](https://www.aljazeera.com/features/2024/2/1/indias-ayodhya-wakes-up-to-harsh-realities-after-modis-ram-temple-event?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T04:12:13+00:00

As devotees stream in, residents say small town in one of India&#039;s poorest states lacks infrastructure to host millions.

## Russia-Ukraine war: List of key events, day 708
 - [https://www.aljazeera.com/news/2024/2/1/russia-ukraine-war-list-of-key-events-day-708?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/russia-ukraine-war-list-of-key-events-day-708?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T01:41:33+00:00

As the war enters its 708th day, these are the main developments.

## ‘Blood and sweat’: Myanmar resistance fights to overturn military coup
 - [https://www.aljazeera.com/news/2024/2/1/blood-and-sweat-myanmar-resistance-fights-to-overturn-military-coup?traffic_source=rss](https://www.aljazeera.com/news/2024/2/1/blood-and-sweat-myanmar-resistance-fights-to-overturn-military-coup?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2024-02-01T01:02:40+00:00

Three years after the generals&#039; power grab, anti-coup fighters say they want them out of Myanmar&#039;s politics.

