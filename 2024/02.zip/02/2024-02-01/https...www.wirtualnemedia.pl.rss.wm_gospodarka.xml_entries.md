# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Kaufland też podnosi pensje. Wyda 110 mln zł
 - [https://www.wirtualnemedia.pl/artykul/kaufland-sklepy-ile-zarabia-kasjer-podwyzka](https://www.wirtualnemedia.pl/artykul/kaufland-sklepy-ile-zarabia-kasjer-podwyzka)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-02-01T15:02:51.656892+00:00

Z początkiem stycznia sieć handlowa Kaufland podniosła wynagrodzenia pracowników, a kolejną podwyżkę planuje w lipcu. Przeznaczy na to prawie 110 mln zł.

## Coca-Cola HBC wprowadza nową markę napojów Three Cents
 - [https://www.wirtualnemedia.pl/artykul/coca-cola-hbc-three-cents](https://www.wirtualnemedia.pl/artykul/coca-cola-hbc-three-cents)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-02-01T04:49:54.069714+00:00

Z myślą o branży HoReCa, Coca-Cola HBC rozbudowuje swoje portfolio o nowe koktajle Three Cents.

## Cyfrowy Polsat na giełdowym dnie. Fundusz gra na dalsze spadki
 - [https://www.wirtualnemedia.pl/artykul/cyfrowy-polsat-dno-kurs-akcji-spadek-gielda](https://www.wirtualnemedia.pl/artykul/cyfrowy-polsat-dno-kurs-akcji-spadek-gielda)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-02-01T04:49:51.190033+00:00

Fundusz Millennium International Management zajął tzw. krótką pozycję na akcjach stanowiących 0,51 proc. kapitału Cyfrowego Polsatu. Kurs spółki zmalał poniżej 11 zł, jest najniższy w ciągu 15 lat jej obecności na giełdzie. Akcje tanieją, odkąd holding inwestuje dużo w energetykę i nieruchomości oraz wydaje więcej na obsługę zadłużenia.

## Vectra nie zgadza się z zarzutami ws. podwyżek. Narzeka na UOKiK i rosnące koszty
 - [https://www.wirtualnemedia.pl/artykul/vectra-podwyzka-klauzule-inflacyjne-uokik](https://www.wirtualnemedia.pl/artykul/vectra-podwyzka-klauzule-inflacyjne-uokik)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2024-02-01T04:49:48.008798+00:00

Prezes Urzędu Ochrony Konkurencji i Konsumentów postawił zarzuty grupie Vectra dotyczące dodanych do umów tzw. klauzul inflacyjnych, na mocy których podwyższono ceny klientom. Firma nie zgadza się z zastrzeżeniami, podkreślając, że odczuwa duży wzrost kosztów, a UOKiK „od lat kwestionuje jakąkolwiek formę urealniania cen”.

