# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## WWE 2K24 - Rhodes Vs Rollins Ambulance Match Gameplay
 - [https://www.youtube.com/watch?v=B5r4vpcIrwI](https://www.youtube.com/watch?v=B5r4vpcIrwI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2024-02-01T15:00:08+00:00

Watch Cody "American Nightmare" Rhodes take on Seth "Freakin" Rollins in an ambulance match in the new WWE 2K24. The game is expected to release March 5, 2024 for current and past generation Xbox and PlayStation consoles, as well as PC.
#WWE2K24

