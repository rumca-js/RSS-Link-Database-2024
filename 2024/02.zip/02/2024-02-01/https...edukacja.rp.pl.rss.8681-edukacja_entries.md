# Source:RP - Edukacja, URL:https://edukacja.rp.pl/rss/8681-edukacja, language:pl-PL

## Szkoła zabroniła uczniom wychodzenia z domu po godzinie 22.00
 - [https://www.rp.pl/edukacja-i-wychowanie/art39772501-szkola-zabronila-uczniom-wychodzenia-z-domu-po-godzinie-22-00](https://www.rp.pl/edukacja-i-wychowanie/art39772501-szkola-zabronila-uczniom-wychodzenia-z-domu-po-godzinie-22-00)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-02-01T09:29:00+00:00

Zakaz przebywania uczniów poza domem bez opieki rodziców po godzinie 22.00 - taki zapis statutu Szkoły Podstawowej im. Jana Pawła II w Pępowie (woj. wielkopolskie) został uznały za statutowy absurd 2023 roku.

## Można zadawać uczniom do domu, byle z sensem. Szkoły i uczniowie potrzebują zmian
 - [https://www.rp.pl/prawo-dla-ciebie/art39770211-mozna-zadawac-uczniom-do-domu-byle-z-sensem-szkoly-i-uczniowie-potrzebuja-zmian](https://www.rp.pl/prawo-dla-ciebie/art39770211-mozna-zadawac-uczniom-do-domu-byle-z-sensem-szkoly-i-uczniowie-potrzebuja-zmian)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-02-01T02:00:00+00:00

Ograniczenia w zadaniach powinny zapoczątkować szersze zmiany w szkole – uważają eksperci.

## Szkoły z „zakazem” prac domowych? Eksperci nie mają wątpliwości
 - [https://www.rp.pl/prawo-dla-ciebie/art39770211-szkoly-z-zakazem-prac-domowych-eksperci-nie-maja-watpliwosci](https://www.rp.pl/prawo-dla-ciebie/art39770211-szkoly-z-zakazem-prac-domowych-eksperci-nie-maja-watpliwosci)
 - RSS feed: https://edukacja.rp.pl/rss/8681-edukacja
 - date published: 2024-02-01T02:00:00+00:00

Ograniczenia w zadaniach powinny zapoczątkować szersze zmiany w szkole – uważają eksperci.

