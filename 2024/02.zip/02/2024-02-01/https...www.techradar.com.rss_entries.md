# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Ninja’s new Double Stack Air Fryer lets you cook twice the food without eating all your kitchen worktop space
 - [https://www.techradar.com/home/small-appliances/ninjas-new-double-stack-air-fryer-lets-you-cook-twice-the-food-without-eating-all-your-kitchen-worktop-space](https://www.techradar.com/home/small-appliances/ninjas-new-double-stack-air-fryer-lets-you-cook-twice-the-food-without-eating-all-your-kitchen-worktop-space)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T22:14:00+00:00

A host of Ninja and Shark devices have just been revealed, including a combi multi-cooker, and a revamped steam mop.

## Google Bard finally gets a free AI image generator – here’s how to try it
 - [https://www.techradar.com/computing/artificial-intelligence/google-bard-finally-gets-a-free-ai-image-generator-heres-how-to-try-it](https://www.techradar.com/computing/artificial-intelligence/google-bard-finally-gets-a-free-ai-image-generator-heres-how-to-try-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T21:20:17+00:00

Google announced that Bard will be getting an AI image generator, and it's pretty simple to use.

## Microsoft Edge could soon get its own version of Google's Circle to Search feature
 - [https://www.techradar.com/computing/software/microsoft-edge-could-soon-get-its-own-version-of-googles-circle-to-search-feature](https://www.techradar.com/computing/software/microsoft-edge-could-soon-get-its-own-version-of-googles-circle-to-search-feature)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T20:31:52+00:00

Available on Edge Canary, Circle To Copilot lets you circle objects on-screen in order to find out what they are.

## Samsung to showcase record-smashing 280-layer QLC NAND flash memory chip — expect cheaper, large capacity SSDs but endurance remains an unknown
 - [https://www.techradar.com/pro/samsung-to-showcase-record-smashing-280-layer-qlc-nand-flash-memory-chip-expect-cheaper-large-capacity-ssds-but-endurance-remains-an-unknown](https://www.techradar.com/pro/samsung-to-showcase-record-smashing-280-layer-qlc-nand-flash-memory-chip-expect-cheaper-large-capacity-ssds-but-endurance-remains-an-unknown)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T20:13:19+00:00

Samsung's 280-layer QLC NAND flash memory chip could lead to larger SSDs.

## Google seemingly embraces AI dogfooding with gutso — cancels huge contract which could see thousands of quality rater jobs terminated and change SEO forever
 - [https://www.techradar.com/pro/google-seemingly-embraces-ai-dogfooding-with-gutso-cancels-huge-contract-which-could-see-thousands-of-quality-rater-jobs-terminated-and-change-seo-forever](https://www.techradar.com/pro/google-seemingly-embraces-ai-dogfooding-with-gutso-cancels-huge-contract-which-could-see-thousands-of-quality-rater-jobs-terminated-and-change-seo-forever)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T19:16:09+00:00

Google cancelled its contract with Appen, and might be turning to AI for rating its search results.

## OneDrive is getting a glow-up, promising an optimized interface and power-packed features to help you navigate your files
 - [https://www.techradar.com/computing/software/onedrive-is-getting-a-glow-up-promising-an-optimized-interface-and-power-packed-features-to-help-you-navigate-your-files](https://www.techradar.com/computing/software/onedrive-is-getting-a-glow-up-promising-an-optimized-interface-and-power-packed-features-to-help-you-navigate-your-files)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T19:07:19+00:00

Microsoft transforms OneDrive with a sleek makeover, enhanced functionality, and user-friendly features, promising a faster and more organized cloud storage experience.

## The Apple Vision Pro has already been hacked - Apple says there's nothing to worry about, but security experts disagree
 - [https://www.techradar.com/pro/security/the-apple-vision-pro-has-already-been-hacked-apple-says-theres-nothing-to-worry-about-but-security-experts-disagree](https://www.techradar.com/pro/security/the-apple-vision-pro-has-already-been-hacked-apple-says-theres-nothing-to-worry-about-but-security-experts-disagree)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T18:20:15+00:00

Apple has already given its Vision Pro headset a security update, and it pertains to a popular target - the WebKit engine.

## This clever Vision Pro app puts handy Shortcut buttons around your house
 - [https://www.techradar.com/computing/this-clever-vision-pro-app-puts-handy-shortcut-buttons-around-your-house](https://www.techradar.com/computing/this-clever-vision-pro-app-puts-handy-shortcut-buttons-around-your-house)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T17:52:25+00:00

The Vision Pro’s Shortcut Buttons app places shortcuts around your home for supremely easy access.

## Nothing Phone 2a has been confirmed – but it might fall short of expectations
 - [https://www.techradar.com/phones/nothing-phone-2a-has-been-confirmed-but-it-might-fall-short-of-expectations](https://www.techradar.com/phones/nothing-phone-2a-has-been-confirmed-but-it-might-fall-short-of-expectations)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T17:42:06+00:00

Nothing has finally confirmed the name of its next device the Nothing Phone 2a in a community post on YouTube.

## Need a budget tablet? This Samsung Galaxy Tab has dropped to a terrific new low price
 - [https://www.techradar.com/tablets/need-a-budget-tablet-this-samsung-galaxy-tab-has-dropped-to-a-terrific-new-low-price](https://www.techradar.com/tablets/need-a-budget-tablet-this-samsung-galaxy-tab-has-dropped-to-a-terrific-new-low-price)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T17:34:00+00:00

The entry-level Samsung Galaxy Tab A9 Plus has fallen in price for the first time since launch so snag this excellent budget tablet deal today.

## Google Pixel 8 phones now have access to AI-powered Circle to Search
 - [https://www.techradar.com/phones/google-pixel-8-phones-now-have-access-to-ai-powered-circle-to-search](https://www.techradar.com/phones/google-pixel-8-phones-now-have-access-to-ai-powered-circle-to-search)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T17:20:50+00:00

Google's new Circle to Search function has dropped Samsung Galaxy S24 exclusivity and is now on the Pixel 8 series.

## Metro Awakening is coming to VR platforms this year and will offer a ‘whole new angle for Metro fans’
 - [https://www.techradar.com/gaming/metro-awakening-is-coming-to-vr-platforms-this-year-and-will-offer-a-whole-new-angle-for-metro-fans](https://www.techradar.com/gaming/metro-awakening-is-coming-to-vr-platforms-this-year-and-will-offer-a-whole-new-angle-for-metro-fans)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T17:14:48+00:00

Metro Awakening has been announced for PS VR2, Steam VR, Meta Quest 2 and 3, and is planned to release this year.

## Don't believe everything you read - hackers are pushing malware via media, news sites
 - [https://www.techradar.com/pro/security/dont-believe-everything-you-read-hackers-are-pushing-malware-via-media-news-sites](https://www.techradar.com/pro/security/dont-believe-everything-you-read-hackers-are-pushing-malware-via-media-news-sites)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T17:03:31+00:00

Some hackers were hiding malicious code in video descriptions, forum profile pages, and more.

## New Netflix movies coming in 2024: here are 6 you won’t want to miss
 - [https://www.techradar.com/streaming/netflix/netflix-has-revealed-its-packed-movie-line-up-for-2024-here-are-6-were-most-excited-for](https://www.techradar.com/streaming/netflix/netflix-has-revealed-its-packed-movie-line-up-for-2024-here-are-6-were-most-excited-for)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T16:32:34+00:00

Action comedies, epic sci-fi and a mysterious new movie are getting us excited for Netflix's 2024 movie releases.

## Ivanti tried to patch its VPN security flaws — but just found more problems
 - [https://www.techradar.com/pro/security/ivanti-tried-to-patch-its-vpn-security-flaws-but-just-found-more-problems](https://www.techradar.com/pro/security/ivanti-tried-to-patch-its-vpn-security-flaws-but-just-found-more-problems)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T16:28:59+00:00

Two new Ivanti VPN flaws discovered, including a zero-day allegedly abused by Chinese hackers

## The Vision Pro's app problems could soon be over, though some hurdles remain
 - [https://www.techradar.com/computing/virtual-reality-augmented-reality/the-vision-pros-app-problems-could-soon-be-over-though-some-hurdles-remain](https://www.techradar.com/computing/virtual-reality-augmented-reality/the-vision-pros-app-problems-could-soon-be-over-though-some-hurdles-remain)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T16:17:26+00:00

600 new Vision Pro apps and Unity development tools could help to end the Apple headset's app problem.

## Another high severity security flaw has hit iOS and macOS devices - so update now
 - [https://www.techradar.com/pro/security/another-high-severity-security-flaw-has-hit-ios-and-macos-devices-so-update-now](https://www.techradar.com/pro/security/another-high-severity-security-flaw-has-hit-ios-and-macos-devices-so-update-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T16:09:08+00:00

CISA warns flaw is being abused in the wild, but won't say who is using it, or against whom.

## The Umbrella Academy season 4's first clip teases an intoxicating Netflix family reunion
 - [https://www.techradar.com/streaming/netflix/the-umbrella-academy-season-4s-first-clip-teases-an-intoxicating-netflix-family-reunion](https://www.techradar.com/streaming/netflix/the-umbrella-academy-season-4s-first-clip-teases-an-intoxicating-netflix-family-reunion)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T16:05:20+00:00

Netflix has debuted the first footage for The Umbrella Academy's final season, and it confirms the band is getting back together.

## The sound of bacon frying might help you sleep, according to an expert
 - [https://www.techradar.com/health-fitness/mattresses/the-sound-of-bacon-frying-might-help-you-sleep-according-to-an-expert](https://www.techradar.com/health-fitness/mattresses/the-sound-of-bacon-frying-might-help-you-sleep-according-to-an-expert)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T16:00:07+00:00

Struggling to drift off? We explore the benefits of ASMR, and why you might want to start listening to bacon in bed

## Ford EV owners will get free adaptors for Tesla's Supercharger network soon
 - [https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/ford-ev-owners-will-get-free-adaptors-for-teslas-supercharger-network-soon](https://www.techradar.com/vehicle-tech/hybrid-electric-vehicles/ford-ev-owners-will-get-free-adaptors-for-teslas-supercharger-network-soon)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T15:34:51+00:00

Ford is offering complimentary charging adaptors for existing F-150 Lightning and Mustang Mach-E customers, so they can begin using the Tesla Supercharger network.

## As Palworld exceeds 19 million players, Pocketpair rolls out a new update with an enormous amount of fixes
 - [https://www.techradar.com/gaming/consoles-pc/as-palworld-exceeds-19-million-players-pocketpair-rolls-out-a-new-update-with-an-enormous-amount-of-fixes](https://www.techradar.com/gaming/consoles-pc/as-palworld-exceeds-19-million-players-pocketpair-rolls-out-a-new-update-with-an-enormous-amount-of-fixes)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T15:30:11+00:00

Palworld has received a new update with fixes for a number of issues, including one which could result in corrupted saves.

## Out of time? Top watchmaker Timex hit in data breach — but it says customers shouldn't be worried
 - [https://www.techradar.com/pro/security/out-of-time-top-watchmaker-timex-hit-in-data-breach](https://www.techradar.com/pro/security/out-of-time-top-watchmaker-timex-hit-in-data-breach)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T15:27:17+00:00

Hackers stole Timex employee Social Security Numbers, but so far, there's no evidence of abuse.

## The new era of Conversational Internet
 - [https://www.techradar.com/pro/the-new-era-of-conversational-internet](https://www.techradar.com/pro/the-new-era-of-conversational-internet)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T15:24:25+00:00

In this new era of Conversational Internet, chatbot is the new website, and the messaging app the new browser.

## Super Bowl TV deals are live at Best Buy - save $1,000 on big-screen LG TVs
 - [https://www.techradar.com/televisions/super-bowl-tv-deals-are-live-at-best-buy-save-dollar1000-on-big-screen-lg-tvs](https://www.techradar.com/televisions/super-bowl-tv-deals-are-live-at-best-buy-save-dollar1000-on-big-screen-lg-tvs)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T15:22:57+00:00

Super Bowl TV deals are live at Best Buy and I'm rounding up the best deals from LG, with up to $1,000 off big-screen 4K and OLED TVs.

## Dynatrace's hypermodal business AI copilot for analytics and automation could boost your cloud security — and explain how every step of the way
 - [https://www.techradar.com/pro/dynatraces-hypermodal-business-ai-copilot-for-analytics-and-automation-could-boost-your-cloud-security-and-explain-how-every-step-of-the-way](https://www.techradar.com/pro/dynatraces-hypermodal-business-ai-copilot-for-analytics-and-automation-could-boost-your-cloud-security-and-explain-how-every-step-of-the-way)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T15:21:51+00:00

Dynatrace's Davis Copilot does the monotonous chores for you, boosting efficiency and productivity for your security

## The Samsung Galaxy Watch 4 could get a surprise reboot this year – here's why
 - [https://www.techradar.com/health-fitness/smartwatches/the-samsung-galaxy-watch-4-could-get-a-surprise-reboot-this-year-heres-why](https://www.techradar.com/health-fitness/smartwatches/the-samsung-galaxy-watch-4-could-get-a-surprise-reboot-this-year-heres-why)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T15:16:47+00:00

Samsung has been tipped to launch a refreshed version of its old Galaxy Watch 4 smartwatch soon.

## Why DNS protection should be the first step in hybrid cloud security
 - [https://www.techradar.com/pro/why-dns-protection-should-be-the-first-step-in-hybrid-cloud-security](https://www.techradar.com/pro/why-dns-protection-should-be-the-first-step-in-hybrid-cloud-security)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T15:12:11+00:00

Enterprises can and should detect and respond to threats earlier - here's how.

## Netflix debuts first clip of Squid Game season 2, and Gi-hun is on a John Wick-style quest for revenge
 - [https://www.techradar.com/streaming/netflix/netflix-debuts-first-clip-of-squid-game-season-2-and-gi-hun-is-on-a-john-wick-style-quest-for-revenge](https://www.techradar.com/streaming/netflix/netflix-debuts-first-clip-of-squid-game-season-2-and-gi-hun-is-on-a-john-wick-style-quest-for-revenge)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T15:05:32+00:00

The first clip from Squid Game season 2 has been released, and Gi-hun is done taking orders from anyone.

## Death Stranding: Directors Cut on iPhone 15 Pro allows you to carry the apocalypse in your pocket
 - [https://www.techradar.com/phones/iphone/death-stranding-directors-cut-on-iphone-15-pro-allows-you-to-carry-the-apocalypse-in-your-pocket](https://www.techradar.com/phones/iphone/death-stranding-directors-cut-on-iphone-15-pro-allows-you-to-carry-the-apocalypse-in-your-pocket)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T14:52:35+00:00

Death Stranding: Director’s Cut ports the atmospheric open-world game over to Mac, iPad, and iPhone.

## Good news, all your favorite Microsoft 365 apps are coming to Apple Vision Pro — Teams, Word, Excel and more are going virtual, and there's even Copilot
 - [https://www.techradar.com/pro/good-news-all-your-favorite-microsoft-365-apps-are-coming-to-apple-vision-pro-teams-word-excel-and-more-are-going-virtual-and-theres-even-copilot](https://www.techradar.com/pro/good-news-all-your-favorite-microsoft-365-apps-are-coming-to-apple-vision-pro-teams-word-excel-and-more-are-going-virtual-and-theres-even-copilot)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T14:19:44+00:00

The Apple Vision Pro wants to be the workplace assistant you never knew you needed.

## The Apple Vision Pro comes with a Guest Mode dilemma - you can share the love but can’t keep the settings
 - [https://www.techradar.com/computing/virtual-reality-augmented-reality/the-apple-vision-pro-comes-with-a-guest-mode-dilemma-you-can-share-the-love-but-cant-keep-the-settings](https://www.techradar.com/computing/virtual-reality-augmented-reality/the-apple-vision-pro-comes-with-a-guest-mode-dilemma-you-can-share-the-love-but-cant-keep-the-settings)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T14:18:06+00:00

Apple's Vision Pro introduces Guest Mode for sharing, but with limitations. Lost calibrations and limited settings raise eyebrows for the $3,500 price tag.

## These lovely 'Vapor' Xbox Wireless Controller colorways have just been added to Xbox Design Lab
 - [https://www.techradar.com/gaming/consoles-pc/these-lovely-vapor-xbox-wireless-controller-colorways-have-just-been-added-to-xbox-design-lab](https://www.techradar.com/gaming/consoles-pc/these-lovely-vapor-xbox-wireless-controller-colorways-have-just-been-added-to-xbox-design-lab)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T14:02:27+00:00

Xbox Design Lab has added 'Vapor' colorways for custom Xbox Wireless Controllers.

## Europcar denies data breach affecting 50 million customers — says ChatGPT is to blame in creating fake data
 - [https://www.techradar.com/pro/security/europcar-denies-data-breach-affecting-50-million-customers-says-chatgpt-is-to-blame-in-creating-fake-data](https://www.techradar.com/pro/security/europcar-denies-data-breach-affecting-50-million-customers-says-chatgpt-is-to-blame-in-creating-fake-data)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T13:54:28+00:00

Europcar says a data leak affecting its customers is fake, but was the data generated by AI?

## Startup claims to offer holy grail of remote connectivity — hybrid access that outperform VPN, SD-WAN and ZTNA solutions by 30x or more
 - [https://www.techradar.com/pro/security/startup-claims-to-offer-holy-grail-of-remote-connectivity-hybrid-access-that-outperform-vpn-sd-wan-and-ztna-solutions-by-30x-or-more](https://www.techradar.com/pro/security/startup-claims-to-offer-holy-grail-of-remote-connectivity-hybrid-access-that-outperform-vpn-sd-wan-and-ztna-solutions-by-30x-or-more)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T13:09:36+00:00

A hybrid access solution claims to offer speed without sacrificing security, but can it actually pull it off?

## Do you dread trying to change your router settings? Login problems could soon be a thing of the past
 - [https://www.techradar.com/computing/wi-fi-broadband/do-you-dread-trying-to-change-your-router-settings-login-problems-could-soon-be-a-thing-of-the-past](https://www.techradar.com/computing/wi-fi-broadband/do-you-dread-trying-to-change-your-router-settings-login-problems-could-soon-be-a-thing-of-the-past)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T12:44:47+00:00

Forget clumsy strings of numbers, you could have a simple word as the key to your router login portal.

## Not a typo: you can get an RTX 4070 gaming laptop for just $999 right now
 - [https://www.techradar.com/computing/gaming-laptops/not-a-typo-you-can-get-an-rtx-4070-gaming-laptop-for-just-dollar999-right-now](https://www.techradar.com/computing/gaming-laptops/not-a-typo-you-can-get-an-rtx-4070-gaming-laptop-for-just-dollar999-right-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T12:39:00+00:00

This RTX 4070 gaming laptop deal at Best Buy is cheaper than some RTX 4060 models thanks to a massive $400 discount.

## Samsung's Galaxy Ring is already appearing in Good Lock, which suggests it's ready to go
 - [https://www.techradar.com/health-fitness/samsungs-galaxy-ring-is-already-appearing-in-good-lock-which-suggests-its-ready-to-go](https://www.techradar.com/health-fitness/samsungs-galaxy-ring-is-already-appearing-in-good-lock-which-suggests-its-ready-to-go)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T12:35:52+00:00

An icon for the Samsung Galaxy Ring has been spotted in the Good Lock customization app.

## Bloober Team’s Silent Hill 2 remake has a new trailer, but still no release date
 - [https://www.techradar.com/gaming/consoles-pc/bloober-teams-silent-hill-2-remake-has-a-new-trailer-but-still-no-release-date](https://www.techradar.com/gaming/consoles-pc/bloober-teams-silent-hill-2-remake-has-a-new-trailer-but-still-no-release-date)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T12:34:31+00:00

Bloober Team's Silent Hill 2 remake has a new trailer, which has unveiled combat-focused in-game footage.

## Warning: the current fix for the Pixel phone storage issues isn’t simple
 - [https://www.techradar.com/phones/google-pixel-phones/warning-the-current-fix-for-the-pixel-phone-storage-issues-isnt-simple](https://www.techradar.com/phones/google-pixel-phones/warning-the-current-fix-for-the-pixel-phone-storage-issues-isnt-simple)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T12:29:16+00:00

Google has outlined a complicated workaround for the Pixel phone storage issues; here's our guide.

## Hulu joins Netflix and Disney Plus on the password crackdown train – here’s what you need to know
 - [https://www.techradar.com/streaming/hulu/hulu-joins-netflix-and-disney-plus-on-the-password-crackdown-train-heres-what-you-need-to-know](https://www.techradar.com/streaming/hulu/hulu-joins-netflix-and-disney-plus-on-the-password-crackdown-train-heres-what-you-need-to-know)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T12:21:45+00:00

Hulu joins Disney Plus with its new subscriber agreement: share outside your household and you could lose your account.

## Google wants to offset its data center pollution using wind power
 - [https://www.techradar.com/pro/google-wants-to-offset-its-data-center-pollution-using-wind-power](https://www.techradar.com/pro/google-wants-to-offset-its-data-center-pollution-using-wind-power)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T11:55:45+00:00

To power its data centers on renewable energy, Google is exploring an hourly purchasing plan as well as wind turbines.

## Multi-cloud is set to become the norm for businesses in the next few years
 - [https://www.techradar.com/pro/multi-cloud-is-set-to-become-the-norm-for-businesses-in-the-next-few-years](https://www.techradar.com/pro/multi-cloud-is-set-to-become-the-norm-for-businesses-in-the-next-few-years)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T11:43:59+00:00

The cloud provider behind a major antitrust case against Microsoft believes multi-cloud is the way forward.

## If you own the last MacBook to have a DVD drive we have some bad news...
 - [https://www.techradar.com/computing/macbooks/if-you-own-the-last-macbook-to-have-a-dvd-drive-we-have-some-bad-news](https://www.techradar.com/computing/macbooks/if-you-own-the-last-macbook-to-have-a-dvd-drive-we-have-some-bad-news)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T11:43:14+00:00

Apple’s MacBook Pro 13-inch from 2012 is officially obsolete – a laptop that was special for a shiny, silver reason...

## YouTube TV could soon get some big upgrades for sports fans
 - [https://www.techradar.com/computing/software/youtube-tv-could-soon-get-some-big-upgrades-for-sports-fans](https://www.techradar.com/computing/software/youtube-tv-could-soon-get-some-big-upgrades-for-sports-fans)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T06:00:22+00:00

YouTube is expanding Multiview by allowing users to choose to four sports games to watch at the same time.

## Quordle today – hints and answers for Thursday, February 1 (game #738)
 - [https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-1-february-2024](https://www.techradar.com/computing/websites-apps/quordle-today-answers-clues-1-february-2024)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T00:15:00+00:00

Looking for Quordle clues? We can help. Plus get the answers to Quordle today and past solutions.

## How to watch Feud: Capote vs The Swans online – stream Ryan Murphy’s starry anthology series
 - [https://www.techradar.com/streaming/entertainment/watch-feud-capote-vs-the-swans-online](https://www.techradar.com/streaming/entertainment/watch-feud-capote-vs-the-swans-online)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2024-02-01T00:02:39+00:00

Tom Hollander is Truman Capote in this account of high society friendships soured by betrayal. Read our guide for how to watch Feud: Capote vs. The Swans online from anywhere.

