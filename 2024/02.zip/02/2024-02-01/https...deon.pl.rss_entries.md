# Source:DEON.pl, URL:https://deon.pl/rss, language:pl

## Bóg nie wymaga ofiary dla swojego majestatu
 - [https://deon.pl/wiara/komentarze-do-ewangelii/bog-nie-wymaga-ofiary-dla-swojego-majestatu-,2729042](https://deon.pl/wiara/komentarze-do-ewangelii/bog-nie-wymaga-ofiary-dla-swojego-majestatu-,2729042)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T23:04:00+00:00



## Papież: W edukacji religia jest niezbędna. Pomaga budować lepszy świat
 - [https://deon.pl/kosciol/papiez-w-edukacji-religia-jest-niezbedna-pomaga-budowac-lepszy-swiat,2731916](https://deon.pl/kosciol/papiez-w-edukacji-religia-jest-niezbedna-pomaga-budowac-lepszy-swiat,2731916)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T15:38:12+00:00



## Polscy naukowcy odkryli w Górach Świętokrzyskich niezwykłą rybę sprzed 365 mln lat
 - [https://deon.pl/swiat/polscy-naukowcy-odkryli-w-gorach-swietokrzyskich-niezwykla-rybe-sprzed-365-mln-lat,2731898](https://deon.pl/swiat/polscy-naukowcy-odkryli-w-gorach-swietokrzyskich-niezwykla-rybe-sprzed-365-mln-lat,2731898)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T15:30:31+00:00



## Watykan: Nowy sekretarz Sekretariatu ds. Gospodarki
 - [https://deon.pl/kosciol/watykan-nowy-sekretarz-sekretariatu-ds-gospodarki,2731880](https://deon.pl/kosciol/watykan-nowy-sekretarz-sekretariatu-ds-gospodarki,2731880)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T14:55:33+00:00



## S. Maria Kasprzak: Żyjemy w kulturze jednorazówek
 - [https://deon.pl/kosciol/s-maria-kasprzak-zyjemy-w-kulturze-jednorazowek,2731688](https://deon.pl/kosciol/s-maria-kasprzak-zyjemy-w-kulturze-jednorazowek,2731688)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T14:00:47+00:00



## Indie: Oczyszczono z zarzutów podejrzanego o szpiegostwo chińskiego gołębia
 - [https://deon.pl/swiat/indie-oczyszczono-z-zarzutow-podejrzanego-o-szpiegostwo-chinskiego-golebia,2731856](https://deon.pl/swiat/indie-oczyszczono-z-zarzutow-podejrzanego-o-szpiegostwo-chinskiego-golebia,2731856)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T13:57:39+00:00



## Były proboszcz z Kostrzyna stanął przed sądem. Jest oskarżony o molestowanie 13-latka
 - [https://deon.pl/kosciol/byly-proboszcz-z-kostrzyna-stanal-przed-sadem-jest-oskarzony-o-molestowanie-13-latka,2731676](https://deon.pl/kosciol/byly-proboszcz-z-kostrzyna-stanal-przed-sadem-jest-oskarzony-o-molestowanie-13-latka,2731676)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T13:12:30+00:00



## [PILNE] Papież Franciszek nominowany do Pokojowej Nagrody Nobla
 - [https://deon.pl/swiat/pilne-papiez-franciszek-nominowany-do-pokojowej-nagrody-nobla,2731664](https://deon.pl/swiat/pilne-papiez-franciszek-nominowany-do-pokojowej-nagrody-nobla,2731664)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T12:49:46+00:00



## Lednica i Festiwal Życia łączą siły! Znamy wspólne plany obu spotkań
 - [https://deon.pl/kosciol/lednica-i-festiwal-zycia-lacza-sily-znamy-wspolne-plany-obu-spotkan,2731601](https://deon.pl/kosciol/lednica-i-festiwal-zycia-lacza-sily-znamy-wspolne-plany-obu-spotkan,2731601)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T12:04:21+00:00



## Katoliccy lekarze w liście do Tuska: Udostępnianie nastolatkom pigułki "dzień po" jest nieodpowiedzialne
 - [https://deon.pl/kosciol/katoliccy-lekarze-w-liscie-do-tuska-udostepnianie-nastolatkom-pigulki-dzien-po-jest-nieodpowiedzialne,2731571](https://deon.pl/kosciol/katoliccy-lekarze-w-liscie-do-tuska-udostepnianie-nastolatkom-pigulki-dzien-po-jest-nieodpowiedzialne,2731571)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T11:26:55+00:00



## Wieczorna modlitwa, która pomoże ci zapanować nad niepokojem
 - [https://deon.pl/wiara/wieczorna-modlitwa-ktora-pomoze-ci-zapanowac-nad-niepokojem,2731376](https://deon.pl/wiara/wieczorna-modlitwa-ktora-pomoze-ci-zapanowac-nad-niepokojem,2731376)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T11:04:09+00:00



## Papieskie orędzie na Wielki Post: Zagubiona ludzkość potrzebuje nawrócenia i błysku nowej nadziei
 - [https://deon.pl/kosciol/papieskie-oredzie-na-wielki-post-zagubiona-ludzkosc-potrzebuje-nawrocenia-i-blysku-nowej-nadziei,2731346](https://deon.pl/kosciol/papieskie-oredzie-na-wielki-post-zagubiona-ludzkosc-potrzebuje-nawrocenia-i-blysku-nowej-nadziei,2731346)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T10:46:46+00:00



## Biskupi spotkali się z Tośką Szewczyk. "Chcemy słuchać siebie nawzajem"
 - [https://deon.pl/kosciol/biskupi-spotkali-sie-z-toska-szewczyk-chcemy-sluchac-siebie-nawzajem-,2731124](https://deon.pl/kosciol/biskupi-spotkali-sie-z-toska-szewczyk-chcemy-sluchac-siebie-nawzajem-,2731124)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T10:32:14+00:00



## Powstanie niepodległe państwo palestyńskie? USA czynią krok w tym kierunku
 - [https://deon.pl/swiat/powstanie-niepodlegle-panstwo-palestynskie-usa-czynia-krok-w-tym-kierunku,2731319](https://deon.pl/swiat/powstanie-niepodlegle-panstwo-palestynskie-usa-czynia-krok-w-tym-kierunku,2731319)
 - RSS feed: https://deon.pl/rss
 - date published: 2024-02-01T10:20:57+00:00



