# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## Your Google Account Might Be In Danger...
 - [https://www.youtube.com/watch?v=q0tMFWfu4L4](https://www.youtube.com/watch?v=q0tMFWfu4L4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2024-02-01T00:39:24+00:00

Check out https://guard.io/sog for a 7 day trial and 20% off your subscription + the ability to protect 5 family members from hackers and scammers! 

Hello guys and gals, it's me Mutahar again! This time we take a look at what appears to be situation discovered earlier this month that seems to have allowed some to take over accounts on Google even well after what appeared to be a password reset. Is this true? Let's find out! Thanks for watching!
Like, Comment and Subscribe for more videos!

