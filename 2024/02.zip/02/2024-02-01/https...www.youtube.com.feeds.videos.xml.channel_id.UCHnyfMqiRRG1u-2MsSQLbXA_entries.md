# Source:Veritasium, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA, language:en-US

## I waterproofed myself with aerogel!
 - [https://www.youtube.com/watch?v=QAWnEVa9vmw](https://www.youtube.com/watch?v=QAWnEVa9vmw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHnyfMqiRRG1u-2MsSQLbXA
 - date published: 2024-02-01T14:58:13+00:00

Experiencing the extraordinary properties of aerogel first hand

