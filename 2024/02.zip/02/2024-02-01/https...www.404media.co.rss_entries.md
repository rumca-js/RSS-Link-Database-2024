# Source:404 Media, URL:https://www.404media.co/rss, language:en

## Fake Bill Ackman and Jim Cramer Instagram Ads are Trying to Take My Money
 - [https://www.404media.co/fake-bill-ackman-and-jim-cramer-instagram-ads-are-trying-to-take-my-money](https://www.404media.co/fake-bill-ackman-and-jim-cramer-instagram-ads-are-trying-to-take-my-money)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-02-01T15:17:40+00:00

Meta continues to profit by selling ads to scammers who are trying to fleece its users.

## Podcast: This is It. The Deepfake Reckoning
 - [https://www.404media.co/404-media-podcast-week-23-this-is-it-the-deepfake-reckoning](https://www.404media.co/404-media-podcast-week-23-this-is-it-the-deepfake-reckoning)
 - RSS feed: https://www.404media.co/rss
 - date published: 2024-02-01T14:00:50+00:00

This week we have a banger episode on AI and what the future holds in a potential overcorrection of the space. Then we talk about how an Iranian linked drug trafficker hired a Hells Angel member to perform a hit on U.S. soil. Yep.

