# Source:ScreenGeek, URL:https://www.screengeek.net/feed/, language:en-US

## ‘Suicide Squad: Kill The Justice League’ Batman Scene Causes Controversy
 - [https://www.screengeek.net/2024/02/01/suicide-squad-kill-the-justice-league-batman-scene-controversy](https://www.screengeek.net/2024/02/01/suicide-squad-kill-the-justice-league-batman-scene-controversy)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2024-02-01T21:55:32+00:00

<p>One of DC&#8216;s most popular projects has been the Arkham video game series. Now the popular video games have paved the way for the all-new title Suicide Squad: Kill the Justice League. However, a major controversial scene featuring Batman from the Suicide Squad game has now been released online. Obviously the game makes a drastic [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/02/01/suicide-squad-kill-the-justice-league-batman-scene-controversy/">&#8216;Suicide Squad: Kill The Justice League&#8217; Batman Scene Causes Controversy</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## Disney Cancels Beloved TV Series After Three Seasons
 - [https://www.screengeek.net/2024/02/01/disney-cancels-beloved-tv-series](https://www.screengeek.net/2024/02/01/disney-cancels-beloved-tv-series)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2024-02-01T20:20:49+00:00

<p>Disney seems to have no problem cancelling their television shows &#8211; even if they happen to be acclaimed by critics. As such, it might be disappointing for fans to hear that another Disney series has just been axed &#8211; after three such critically acclaimed seasons. The series was a Disney Channel adventure series. Unfortunately, it [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/02/01/disney-cancels-beloved-tv-series/">Disney Cancels Beloved TV Series After Three Seasons</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## Oscar-Winning Stephen King Movie Now Streaming On Max
 - [https://www.screengeek.net/2024/02/01/stephen-king-oscar-winning-movie-streaming-max](https://www.screengeek.net/2024/02/01/stephen-king-oscar-winning-movie-streaming-max)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2024-02-01T18:31:12+00:00

<p>Many Stephen King adaptations are quite popular in horror fandom. However, only one film based on one of his works has actually won an Oscar. Now this Oscar-winning Stephen King movie is finally available for streaming. The iconic author has given us such modern-day classics as Carrie, The Shining, Cujo, Pet Sematary, and more. Villains [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/02/01/stephen-king-oscar-winning-movie-streaming-max/">Oscar-Winning Stephen King Movie Now Streaming On Max</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## Cult Classic 1990s Movie To Receive R-Rated Remake
 - [https://www.screengeek.net/2024/02/01/cult-classic-movie-r-rated-remake](https://www.screengeek.net/2024/02/01/cult-classic-movie-r-rated-remake)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2024-02-01T17:03:11+00:00

<p>The 1990s ushered in plenty of massive hits and modern-day cult favorites. Now one such cult classic is set to receive an R-rated remake. Interestingly, this particular title was somewhat family-friendly in its first iteration, only receiving a PG-13 rating at the time. Now, an official MPAA listing has shared not only the film&#8217;s title [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/02/01/cult-classic-movie-r-rated-remake/">Cult Classic 1990s Movie To Receive R-Rated Remake</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## ‘Mr. & Mrs. Smith’ Review: The Spy And Love Life Succeeds
 - [https://www.screengeek.net/2024/02/01/mr-and-mrs-smith-review](https://www.screengeek.net/2024/02/01/mr-and-mrs-smith-review)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2024-02-01T15:00:56+00:00

<p>The mixture of romance, comedy, and action in film can work from time to time. Films like Romancing the Stone, Gross Pointe Blank, True Romance, and Smokey and the Bandit are just some of the projects that audiences have come to watch for a long time. 2005&#8217;s Mr. &#38; Mrs. Smith, Starring Brad Pitt and [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/02/01/mr-and-mrs-smith-review/">&#8216;Mr. &#038; Mrs. Smith&#8217; Review: The Spy And Love Life Succeeds</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

## ‘Law & Order: Special Victims Unit’ Scene Faces Backlash
 - [https://www.screengeek.net/2024/01/31/law-and-order-special-victims-unit-scene-backlash](https://www.screengeek.net/2024/01/31/law-and-order-special-victims-unit-scene-backlash)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2024-02-01T01:52:22+00:00

<p>Law &#38; Order: Special Victims Unit has returned for its 25th season. However, some viewers are quite upset by the latest episode at the time of this writing. Now the new Law &#38; Order episode is receiving backlash on social media as a result. The controversial episode, &#8220;Truth Embargo,&#8221; aired on January 25. The X [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/01/31/law-and-order-special-victims-unit-scene-backlash/">&#8216;Law &#038; Order: Special Victims Unit&#8217; Scene Faces Backlash</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

