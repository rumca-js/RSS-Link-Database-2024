# Source:Shut Up & Sit Down, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyRhIGDUKdIOw07Pd8pHxCw, language:en-US

## The Top 100 Board Games of All Time: Agricola
 - [https://www.youtube.com/watch?v=8ojqjk5k9sA](https://www.youtube.com/watch?v=8ojqjk5k9sA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyRhIGDUKdIOw07Pd8pHxCw
 - date published: 2024-02-01T14:27:13+00:00

0:00 It's happening, people! Top 100 Time. But what is this?
0:53 Episode 1: Agricola!
1:26 How to Play Agricola.
4:52 Let's do this!
5:31 Does Agricola belong in our Top 100?
8:35 A game that is mean and important.
10:24 A game that is funny.
15:14 A game where you make something.
16:21 A game with character.
17:23 Every worker placement is meaningful.
20:39 We really like these cards.
23:09 Is it in our collections?
23:58 Replayability.
26:52 The most beloved board game component of all time?
28:13 Conclusion.

Support the Show: https://bit.ly/SupportSUSD / https://www.patreon.com/shutupandsitdown

Buy This Game: https://bit.ly/SUSDAgricola In US: https://bit.ly/AgriUS In UK & Europe: https://bit.ly/AgriUK
Visit SU&amp;SD for more cardboard antics: http://www.shutupandsitdown.com/

~FOLLOW US AROUND, WHY DON'T YOU~
Podcast: https://anchor.fm/susd
Twitter: https://www.twitter.com/shutupshow
Instagram: https://www.instagram.com/shut.up.and.sit.down
Twitch: https://www.twitch.

