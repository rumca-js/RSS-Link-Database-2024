# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Oprogramowanie Mercedesa dostępne dla każdego przez pozostawiony w repozytorium token
 - [https://sekurak.pl/oprogramowanie-mercedesa-dostepne-dla-kazdego-przez-pozostawiony-w-repozytorium-token](https://sekurak.pl/oprogramowanie-mercedesa-dostepne-dla-kazdego-przez-pozostawiony-w-repozytorium-token)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2024-02-01T11:48:50+00:00

<p>To nie jest pierwsza (i pewnie nie ostatnia) wpadka związana z niewłaściwym zarządzaniem sekretami w kodzie źródłowym. Pracownik firmy pozostawił w publicznie dostępnym repozytorium token dostępowy do serwera GitHub Enterprise.  Uprawnienia dla tego tokenu pozwalały na nieograniczony, jak piszą badacze z redhuntlabs.com, dostęp do wewnętrznych zasobów firmy takich jak kod...</p>
<p>Artykuł <a href="https://sekurak.pl/oprogramowanie-mercedesa-dostepne-dla-kazdego-przez-pozostawiony-w-repozytorium-token/" rel="nofollow">Oprogramowanie Mercedesa dostępne dla każdego przez pozostawiony w repozytorium token</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## FBI ingeruje w zhackowane routery domowe. Powód? Urządzenia były wykorzystywane do atakowania infrastruktury krytycznej USA. W tle grupy hackerskie z Chin.
 - [https://sekurak.pl/fbi-przejmuje-zainfekowane-routery-amerykanow](https://sekurak.pl/fbi-przejmuje-zainfekowane-routery-amerykanow)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2024-02-01T11:43:59+00:00

<p>Wiadomości o kolejnych atakach chińskich grup APT to codzienność. Tym razem jednak operacje grupy Volt Typhoon, o której już pisaliśmy zostały w dość niekonwencjonalny sposób powstrzymane przez zatwierdzone sądowo działania Federalnego Biura Bezpieczeństwa.&#160; Urządzenia sieciowe, takie jak routery klasy SOHO (small office/home office) bywają zaniedbywane przez producentów. Wsparcie dla tego...</p>
<p>Artykuł <a href="https://sekurak.pl/fbi-przejmuje-zainfekowane-routery-amerykanow/" rel="nofollow">FBI ingeruje w zhackowane routery domowe. Powód? Urządzenia były wykorzystywane do atakowania infrastruktury krytycznej USA. W tle grupy hackerskie z Chin.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

