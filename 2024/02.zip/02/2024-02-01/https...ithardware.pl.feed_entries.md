# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Europejscy wydawcy rezygnują ze sprzedaży gier na Xboxa w pudełkach
 - [https://ithardware.pl/aktualnosci/europejscy_wydawcy_rezygnuja_ze_sprzedazy_gier_na_xboxa_w_pudelkach-31413.html](https://ithardware.pl/aktualnosci/europejscy_wydawcy_rezygnuja_ze_sprzedazy_gier_na_xboxa_w_pudelkach-31413.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T21:49:47+00:00

<img src="https://ithardware.pl/artykuly/min/31413_1.jpg" />            Nośniki danych zapisane fizycznie odchodzą do lamusa, a szczeg&oacute;lnie jest to zauważane w przypadku gier, kt&oacute;re na PC rzadko kiedy są wydawane na płytach, a najczęściej w opakowaniu znajdziemy kod do pobrania tytuły na daną...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/europejscy_wydawcy_rezygnuja_ze_sprzedazy_gier_na_xboxa_w_pudelkach-31413.html">https://ithardware.pl/aktualnosci/europejscy_wydawcy_rezygnuja_ze_sprzedazy_gier_na_xboxa_w_pudelkach-31413.html</a></p>

## Sony ma pracować nad PS Vita 2. Konsola może być powiązana z PlayStation 6
 - [https://ithardware.pl/aktualnosci/sony_ma_pracowac_nad_ps_vita_2_konsola_moze_byc_powiazana_z_playstation_6-31412.html](https://ithardware.pl/aktualnosci/sony_ma_pracowac_nad_ps_vita_2_konsola_moze_byc_powiazana_z_playstation_6-31412.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T16:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/31412_1.jpg" />            PlayStation Portable to konsola, kt&oacute;ra w swoim czasie&nbsp;była świetną konsolą do grania. Sukcesu nie powt&oacute;rzyła już PS Vita, ale to z tego powodu, że trafiła w okres popularyzacji&nbsp;smartfon&oacute;w, na kt&oacute;rych można...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sony_ma_pracowac_nad_ps_vita_2_konsola_moze_byc_powiazana_z_playstation_6-31412.html">https://ithardware.pl/aktualnosci/sony_ma_pracowac_nad_ps_vita_2_konsola_moze_byc_powiazana_z_playstation_6-31412.html</a></p>

## Alan Wake 2 będzie straszył mniej. Gra dostała nową aktualizację
 - [https://ithardware.pl/aktualnosci/alan_wake_2_bedzie_straszyl_mniej_gra_dostala_nowa_aktualizacje-31411.html](https://ithardware.pl/aktualnosci/alan_wake_2_bedzie_straszyl_mniej_gra_dostala_nowa_aktualizacje-31411.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T16:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/31411_1.jpg" />            Remedy Entertainment udostępniło aktualizację do gry Alan Wake 2, kt&oacute;ra nie tylko usprawnia działanie produkcji, ale r&oacute;wnież&nbsp;przynosi istotną nowość dla graczy, kt&oacute;rzy nie lubią się bać. Tak, teraz jest mniej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/alan_wake_2_bedzie_straszyl_mniej_gra_dostala_nowa_aktualizacje-31411.html">https://ithardware.pl/aktualnosci/alan_wake_2_bedzie_straszyl_mniej_gra_dostala_nowa_aktualizacje-31411.html</a></p>

## Chińczycy przyspieszają. BYD ogłasza zakup ziemi pod europejską fabrykę chińskich elektryków
 - [https://ithardware.pl/aktualnosci/chinczycy_przyspieszaja_byd_oglasza_zakup_ziemi_pod_europejska_fabryke_chinskich_elektrykow-31410.html](https://ithardware.pl/aktualnosci/chinczycy_przyspieszaja_byd_oglasza_zakup_ziemi_pod_europejska_fabryke_chinskich_elektrykow-31410.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T15:09:40+00:00

<img src="https://ithardware.pl/artykuly/min/31410_1.jpg" />            Dwa miesiące po wyborze Węgier&nbsp;jako pożądanej lokalizacji swojego pierwszego w Europie zakładu produkującego samochody osobowe, firma Build Your Dreams (BYD) sfinalizowała przedwstępną umowę sprzedaży węgierskiego gruntu, na...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chinczycy_przyspieszaja_byd_oglasza_zakup_ziemi_pod_europejska_fabryke_chinskich_elektrykow-31410.html">https://ithardware.pl/aktualnosci/chinczycy_przyspieszaja_byd_oglasza_zakup_ziemi_pod_europejska_fabryke_chinskich_elektrykow-31410.html</a></p>

## Polska premiera monitora LG UltraGear OLED 27GS95QE. Na start specjalny rabat
 - [https://ithardware.pl/aktualnosci/polska_premiera_monitora_lg_ultragear_oled_27gs95qe_na_start_specjalny_rabat-31409.html](https://ithardware.pl/aktualnosci/polska_premiera_monitora_lg_ultragear_oled_27gs95qe_na_start_specjalny_rabat-31409.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T14:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/31409_1.jpg" />            Do przedsprzedaży trafił monitor LG&nbsp;UltraGear 27GS95QE, kt&oacute;rego wyposażono w wyświetlacz OLED. Z tej okazji firma przygotowała specjalny rabat, a dodatkowo sprzęt można wypr&oacute;bować na targach&nbsp;Intel Extreme Masters 2024 w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/polska_premiera_monitora_lg_ultragear_oled_27gs95qe_na_start_specjalny_rabat-31409.html">https://ithardware.pl/aktualnosci/polska_premiera_monitora_lg_ultragear_oled_27gs95qe_na_start_specjalny_rabat-31409.html</a></p>

## AMD potwierdza plany. Stacjonarne, laptopowe i serwerowe procesory Zen 5 w drugiej połowie roku
 - [https://ithardware.pl/aktualnosci/amd_potwierdza_plany_stacjonarne_laptopowe_i_serwerowe_procesory_zen_5_w_drugiej_polowie_roku-31405.html](https://ithardware.pl/aktualnosci/amd_potwierdza_plany_stacjonarne_laptopowe_i_serwerowe_procesory_zen_5_w_drugiej_polowie_roku-31405.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T13:16:01+00:00

<img src="https://ithardware.pl/artykuly/min/31405_1.jpg" />            Szum wok&oacute;ł nadchodzącej architektury Zen 5 robi się coraz głośniejszy. AMD wydaje się nie przejmować tymi plotkami i potwierdza, że prace nad technologią przebiegają zgodnie z planem.&nbsp;

Konsumenckie procesory Zen 5

AMD...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_potwierdza_plany_stacjonarne_laptopowe_i_serwerowe_procesory_zen_5_w_drugiej_polowie_roku-31405.html">https://ithardware.pl/aktualnosci/amd_potwierdza_plany_stacjonarne_laptopowe_i_serwerowe_procesory_zen_5_w_drugiej_polowie_roku-31405.html</a></p>

## Lamptron ST060 - radiator CPU z wyświetlaczem FullHD, który może również służyć jako drugi ekran
 - [https://ithardware.pl/aktualnosci/lamptron_st060_radiator_cpu_z_wyswietlaczem_fullhd_ktory_moze_rowniez_sluzyc_jako_drugi_ekran-31408.html](https://ithardware.pl/aktualnosci/lamptron_st060_radiator_cpu_z_wyswietlaczem_fullhd_ktory_moze_rowniez_sluzyc_jako_drugi_ekran-31408.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T13:08:10+00:00

<img src="https://ithardware.pl/artykuly/min/31408_1.jpg" />            Zestawy chłodzenia procesor&oacute;w z wbudowanymi wyświetlaczami nie są niczym nowym, jednak większość z nich to część konfiguracji chłodzenia cieczą AIO. Lamptron ST060 to tradycyjny radiator, kt&oacute;ry posiada wyświetlacz Full HD o...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/lamptron_st060_radiator_cpu_z_wyswietlaczem_fullhd_ktory_moze_rowniez_sluzyc_jako_drugi_ekran-31408.html">https://ithardware.pl/aktualnosci/lamptron_st060_radiator_cpu_z_wyswietlaczem_fullhd_ktory_moze_rowniez_sluzyc_jako_drugi_ekran-31408.html</a></p>

## Szybsze pamięci DDR5 wyraźnie poprawią wydajność AI Ryzena 7 8700G
 - [https://ithardware.pl/aktualnosci/szybsze_pamieci_ddr5_wyraznie_poprawia_wydajnosc_ai_ryzena_7_8700g-31404.html](https://ithardware.pl/aktualnosci/szybsze_pamieci_ddr5_wyraznie_poprawia_wydajnosc_ai_ryzena_7_8700g-31404.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T12:40:02+00:00

<img src="https://ithardware.pl/artykuly/min/31404_1.jpg" />            Już przedpremierowe przecieki sugerowały, że nowe APU od AMD dobrze reagują na podkręcanie pamięci RAM, a teraz pierwsze recenzje procesora Ryzen 7 8700G wykazały korzyści graficzne wynikające z manipulacji &bdquo;zegarem silnika iGPU i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/szybsze_pamieci_ddr5_wyraznie_poprawia_wydajnosc_ai_ryzena_7_8700g-31404.html">https://ithardware.pl/aktualnosci/szybsze_pamieci_ddr5_wyraznie_poprawia_wydajnosc_ai_ryzena_7_8700g-31404.html</a></p>

## Samsung chwalił się nową funkcją w S24. Inni dostali ją teraz za darmo
 - [https://ithardware.pl/aktualnosci/samsung_chwalil_sie_nowa_funkcja_w_s24_inni_teraz_dostali_ja_teraz_za_darmo-31407.html](https://ithardware.pl/aktualnosci/samsung_chwalil_sie_nowa_funkcja_w_s24_inni_teraz_dostali_ja_teraz_za_darmo-31407.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T11:12:50+00:00

<img src="https://ithardware.pl/artykuly/min/31407_1.jpg" />            Niedawno Google Pixel 8 i Pixel 8 Pro otrzymały aktualizację, w ramach kt&oacute;rej dodano nowe funkcje, w tym Circle to Search, kt&oacute;rą zaprezentowano na wydarzeniu Galaxy Unpacked firmy Samsung.

Teraz właściciele&nbsp;smartfon&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/samsung_chwalil_sie_nowa_funkcja_w_s24_inni_teraz_dostali_ja_teraz_za_darmo-31407.html">https://ithardware.pl/aktualnosci/samsung_chwalil_sie_nowa_funkcja_w_s24_inni_teraz_dostali_ja_teraz_za_darmo-31407.html</a></p>

## Spotify krytykuje nowe zasady Apple App Store w UE, nazywa je „wymuszeniami”
 - [https://ithardware.pl/aktualnosci/spotify_krytykuje_nowe_zasady_apple_app_store_w_ue_nazywa_je_wymuszeniami-31403.html](https://ithardware.pl/aktualnosci/spotify_krytykuje_nowe_zasady_apple_app_store_w_ue_nazywa_je_wymuszeniami-31403.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T10:38:01+00:00

<img src="https://ithardware.pl/artykuly/min/31403_1.jpg" />            Dyrektor generalny Spotify, Daniel Ek, ostro skrytykował ostatnie zmiany w zasadach Apple App Store w Europie i oskarżył firmę o zejście do &bdquo;nowego dna&rdquo;. Gigant streamingowy określił nowe opłaty Apple jako &bdquo;wymuszenie&rdquo; i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/spotify_krytykuje_nowe_zasady_apple_app_store_w_ue_nazywa_je_wymuszeniami-31403.html">https://ithardware.pl/aktualnosci/spotify_krytykuje_nowe_zasady_apple_app_store_w_ue_nazywa_je_wymuszeniami-31403.html</a></p>

## Elon Musk: Chińskie auta to zagrożenie. Są zbyt... dobre
 - [https://ithardware.pl/aktualnosci/elon_musk_chinskie_auta_to_zagrozenie_sa_zbyt_dobre-31406.html](https://ithardware.pl/aktualnosci/elon_musk_chinskie_auta_to_zagrozenie_sa_zbyt_dobre-31406.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T10:30:10+00:00

<img src="https://ithardware.pl/artykuly/min/31406_1.jpg" />            Chińscy producenci samochod&oacute;w znacznie poprawili jakość swoich produkt&oacute;w&nbsp;i szybko zdobywają europejski rynek. Nawet Elon Musk, szef Tesli, wyraża obawy, twierdząc, że większość obecnych gigant&oacute;w motoryzacyjnych może...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/elon_musk_chinskie_auta_to_zagrozenie_sa_zbyt_dobre-31406.html">https://ithardware.pl/aktualnosci/elon_musk_chinskie_auta_to_zagrozenie_sa_zbyt_dobre-31406.html</a></p>

## Lubisz gry mobilne? Koniecznie sprawdź Hero Wars!
 - [https://ithardware.pl/artykuly/lubisz_gry_mobilne_koniecznie_sprawdz_hero_wars-31373.html](https://ithardware.pl/artykuly/lubisz_gry_mobilne_koniecznie_sprawdz_hero_wars-31373.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T10:25:20+00:00

<img src="https://ithardware.pl/artykuly/min/31373_1.jpg" />            Czy Ty też gubisz się w natłoku wydawanych tytuł&oacute;w? Szczeg&oacute;lnie teraz, gdy branża przeżywa rozkwit. Ubiegły rok był prawdziwą gratką dla wszystkich miłośnik&oacute;w gier: odrodzenie DnD na PC dzięki Baldur&rsquo;s Gate 3, nowa...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/lubisz_gry_mobilne_koniecznie_sprawdz_hero_wars-31373.html">https://ithardware.pl/artykuly/lubisz_gry_mobilne_koniecznie_sprawdz_hero_wars-31373.html</a></p>

## Ten standard Wi-Fi bije rekord zasięgu. 3 km stabilnego połączenia
 - [https://ithardware.pl/aktualnosci/ten_standard_wi_fi_bije_rekord_zasiegu_3_km_stabilnego_polaczenia-31402.html](https://ithardware.pl/aktualnosci/ten_standard_wi_fi_bije_rekord_zasiegu_3_km_stabilnego_polaczenia-31402.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T09:24:01+00:00

<img src="https://ithardware.pl/artykuly/min/31402_1.jpg" />            Osiem lat temu Wi-Fi Alliance zaprezentowało nowy standard przeznaczony do obsługi urządzeń o niskim poborze mocy i zasięgu znacznie większym niż typowe Wi-Fi. Ostatnie testy wykazały, że ten standard, choć nie jest zbyt szybki, może zapewnić...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ten_standard_wi_fi_bije_rekord_zasiegu_3_km_stabilnego_polaczenia-31402.html">https://ithardware.pl/aktualnosci/ten_standard_wi_fi_bije_rekord_zasiegu_3_km_stabilnego_polaczenia-31402.html</a></p>

## APU AMD Ryzen 8000G właśnie debiutują na rynku. Znamy polskie ceny
 - [https://ithardware.pl/aktualnosci/apu_amd_ryzen_8000g_wlasnie_debiutuja_na_rynku-31400.html](https://ithardware.pl/aktualnosci/apu_amd_ryzen_8000g_wlasnie_debiutuja_na_rynku-31400.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T08:15:10+00:00

<img src="https://ithardware.pl/artykuly/min/31400_1.png" />            AMD właśnie wprowadziło do sprzedaży swoje nowe APU AMD Ryzen serii 8000G, kt&oacute;re stanowią połączenie procesor&oacute;w Zen 4 oraz zintegrowanych kart graficznych RDNA 3. Dzięki temu stanowić mogą kuszącą opcję dla os&oacute;b,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apu_amd_ryzen_8000g_wlasnie_debiutuja_na_rynku-31400.html">https://ithardware.pl/aktualnosci/apu_amd_ryzen_8000g_wlasnie_debiutuja_na_rynku-31400.html</a></p>

## Silent Hill: The Short Message już dostępne i za darmo. Silent Hill 2 Remake na nowym zwiastunie
 - [https://ithardware.pl/aktualnosci/silent_hill_the_short_message_juz_dostepne_i_za_darmo_silent_hill_2_remake_na_nowym_zwiastunie-31401.html](https://ithardware.pl/aktualnosci/silent_hill_the_short_message_juz_dostepne_i_za_darmo_silent_hill_2_remake_na_nowym_zwiastunie-31401.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T08:12:50+00:00

<img src="https://ithardware.pl/artykuly/min/31401_1.jpg" />            Silent Hill powraca i to szybciej, niż można się było spodziewać. Sony i Konami połączyły siły, aby stworzyć zupełnie nowy tytuł z serii, dostępny wyłącznie na PlayStation 5. A co najlepsze, Silent Hill: The Short Message jest darmowe i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/silent_hill_the_short_message_juz_dostepne_i_za_darmo_silent_hill_2_remake_na_nowym_zwiastunie-31401.html">https://ithardware.pl/aktualnosci/silent_hill_the_short_message_juz_dostepne_i_za_darmo_silent_hill_2_remake_na_nowym_zwiastunie-31401.html</a></p>

## Death Stranding 2: On the Beach na 10-minutowym materiale. Jakie to jest... dziwne
 - [https://ithardware.pl/aktualnosci/death_stranding_2_on_the_beach_na_10_minutowym_materiale_jakie_to_jest_dziwne-31399.html](https://ithardware.pl/aktualnosci/death_stranding_2_on_the_beach_na_10_minutowym_materiale_jakie_to_jest_dziwne-31399.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2024-02-01T06:56:55+00:00

<img src="https://ithardware.pl/artykuly/min/31399_1.jpg" />            Zgodnie z oczekiwaniami, wczorajsze PlayStation State of Play przyniosło kilka ciekawych zapowiedzi, ale co z naszego punktu widzenia najważniejsze, pozwoliło r&oacute;wnież bliżej przyjrzeć się kilku nadchodzącym na PlayStation grom. Jedną z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/death_stranding_2_on_the_beach_na_10_minutowym_materiale_jakie_to_jest_dziwne-31399.html">https://ithardware.pl/aktualnosci/death_stranding_2_on_the_beach_na_10_minutowym_materiale_jakie_to_jest_dziwne-31399.html</a></p>

