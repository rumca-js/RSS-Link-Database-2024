# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Navalny Calls for Election Day Protest Against Putin, Ukraine Invasion
 - [https://www.themoscowtimes.com/2024/02/01/navalny-calls-for-election-day-protest-against-putin-ukraine-invasion-a83946](https://www.themoscowtimes.com/2024/02/01/navalny-calls-for-election-day-protest-against-putin-ukraine-invasion-a83946)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T16:10:00+00:00

“Go vote against Putin and the war, and urge everyone to do the same,” Navalny wrote on X.

## Russia Targets Exiled Celebrities Who Criticize War – Bloomberg
 - [https://www.themoscowtimes.com/2024/02/01/russia-targets-exiled-celebrities-who-criticize-war-bloomberg-a83945](https://www.themoscowtimes.com/2024/02/01/russia-targets-exiled-celebrities-who-criticize-war-bloomberg-a83945)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T15:20:33+00:00

Instructions were reportedly issued to diplomats posted in so-called “friendly” countries — those that have avoided taking sides over Russia’s invasion.

## Kremlin Hopes Armenia Joining ICC Will Not Affect Relations
 - [https://www.themoscowtimes.com/2024/02/01/kremlin-hopes-armenia-joining-icc-will-not-affect-relations-a83944](https://www.themoscowtimes.com/2024/02/01/kremlin-hopes-armenia-joining-icc-will-not-affect-relations-a83944)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T14:30:39+00:00

Yerevan is now required to arrest Vladimir Putin if he sets foot on Armenian territory, as the ICC issued an arrest warrant for the Russian leader last year.

## Russian Court Extends Detention of U.S.-Russian Journalist Kurmasheva
 - [https://www.themoscowtimes.com/2024/02/01/russian-court-extends-detention-of-us-russian-journalist-kurmasheva-2-a83943](https://www.themoscowtimes.com/2024/02/01/russian-court-extends-detention-of-us-russian-journalist-kurmasheva-2-a83943)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T14:07:00+00:00

A court in the city of Kazan ruled to keep Radio Free Europe/Radio Liberty journalist Alsu Kurmasheva in pre-trial detention until April 5.

## Russian Investigators Say Military Plane Shot Down by Patriot Missile System
 - [https://www.themoscowtimes.com/2024/02/01/russian-investigators-say-military-plane-shot-down-by-patriot-missile-system-a83941](https://www.themoscowtimes.com/2024/02/01/russian-investigators-say-military-plane-shot-down-by-patriot-missile-system-a83941)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T13:50:52+00:00

Russia's Investigative Committee said over 100 fragments of MIM-104A anti-aircraft missiles were recovered from the crash site in the Belgorod region.

## Ukraine Says Destroyed Russian Missile Boat Near Annexed Crimea
 - [https://www.themoscowtimes.com/2024/02/01/ukraine-says-destroyed-russian-missile-boat-near-annexed-crimea-a83942](https://www.themoscowtimes.com/2024/02/01/ukraine-says-destroyed-russian-missile-boat-near-annexed-crimea-a83942)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T12:14:00+00:00

“As a result of a number of direct hits to the hull, the Russian ship suffered damage incompatible with further movement,” Ukraine's GRU said.

## Russia Commutes U.S. Investor Calvey’s Fraud Sentence After Guilty Plea
 - [https://www.themoscowtimes.com/2024/02/01/russia-commutes-us-investor-calveys-fraud-sentence-after-guilty-plea-a83939](https://www.themoscowtimes.com/2024/02/01/russia-commutes-us-investor-calveys-fraud-sentence-after-guilty-plea-a83939)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T11:20:22+00:00

A Moscow court of cassation further commuted Michael Calvey’s suspended sentence to 4 years and 4 months given his "full confession of guilt."

## Russian Court Jails Woman for Wearing 'Extremist' Rainbow Earrings
 - [https://www.themoscowtimes.com/2024/02/01/russian-court-jails-woman-for-wearing-extremist-rainbow-earrings-a83938](https://www.themoscowtimes.com/2024/02/01/russian-court-jails-woman-for-wearing-extremist-rainbow-earrings-a83938)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T10:58:49+00:00

The court in Nizhny Novgorod found the woman guilty of publicly displaying symbols of an “extremist” organization and jailed her for five days.

## Exiled from Bashkortostan, Ex-Official Murzagulov Remains Hopeful for Its Future
 - [https://www.themoscowtimes.com/2024/02/01/exiled-from-bashkortostan-ex-official-murzagulov-remains-hopeful-for-its-future-a83911](https://www.themoscowtimes.com/2024/02/01/exiled-from-bashkortostan-ex-official-murzagulov-remains-hopeful-for-its-future-a83911)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T10:42:00+00:00

Rostislav Murzagulov once saw himself as a political mediator. Now the polarizing figure must watch the unrest in his home region from afar.

## Turkish Banks Close Russian Corporate Accounts Over Secondary Sanctions – Vedomosti
 - [https://www.themoscowtimes.com/2024/02/01/turkish-banks-close-russian-corporate-accounts-over-secondary-sanctions-vedomosti-a83935](https://www.themoscowtimes.com/2024/02/01/turkish-banks-close-russian-corporate-accounts-over-secondary-sanctions-vedomosti-a83935)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T09:39:00+00:00

At least two Turkish banks started closing the accounts of a “significant number” of Russian companies and banks after the U.S. threatened to blacklist them.

## Russia Says Downed 11 Ukrainian Drones Overnight
 - [https://www.themoscowtimes.com/2024/02/01/russia-says-downed-11-ukrainian-drones-overnight-a83936](https://www.themoscowtimes.com/2024/02/01/russia-says-downed-11-ukrainian-drones-overnight-a83936)
 - RSS feed: https://www.themoscowtimes.com/rss/news
 - date published: 2024-02-01T09:03:00+00:00

"Tonight, the Kyiv regime attempted to commit terrorist attacks against structures on Russian territory using drones," the Defense Ministry said.

