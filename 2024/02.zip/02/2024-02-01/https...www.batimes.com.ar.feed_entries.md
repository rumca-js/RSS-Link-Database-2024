# Source:Argentina - Buenos Aires Times, URL:https://www.batimes.com.ar/feed, language:en

## Four women arrested for peaceful protest outside Congress released after outcry
 - [https://www.batimes.com.ar/news/argentina/four-women-arrested-for-protesting-in-front-of-congress-are-released.phtml](https://www.batimes.com.ar/news/argentina/four-women-arrested-for-protesting-in-front-of-congress-are-released.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-02-01T22:01:46+00:00

<p><img alt="four women arrested" src="https://fotos.perfil.com/2024/02/01/trim/540/304/four-women-arrested-1748627.jpeg" /></p>Argentine federal police arrested and detained four women singing the national anthem on the curb in front of Congress Plaza. Following backlash from officials and political parties on social media, all were released this morning. <a href="https://www.batimes.com.ar/news/argentina/four-women-arrested-for-protesting-in-front-of-congress-are-released.phtml">Leer más</a>

## Argentina falls on annual corruption index
 - [https://www.batimes.com.ar/news/argentina/argentina-falls-on-annual-corruption-index.phtml](https://www.batimes.com.ar/news/argentina/argentina-falls-on-annual-corruption-index.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-02-01T20:28:32+00:00

<p><img alt="Argentina falls on annual corruption index" src="https://fotos.perfil.com/2024/02/01/trim/540/304/argentina-falls-on-annual-corruption-index-1748577.jpeg" /></p>The country scored 37 out of 100 total points and ranked 98th out of 180 surveyed countries <a href="https://www.batimes.com.ar/news/argentina/argentina-falls-on-annual-corruption-index.phtml">Leer más</a>

## Los Alerces National Park: Fire burns 2,300 hectares amid heat alert
 - [https://www.batimes.com.ar/news/argentina/fire-in-argentine-park-burns-2000-hectares-amid-heat-alert.phtml](https://www.batimes.com.ar/news/argentina/fire-in-argentine-park-burns-2000-hectares-amid-heat-alert.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-02-01T18:45:00+00:00

<p><img alt="fires, los alerces national park" src="https://fotos.perfil.com/2024/01/27/trim/540/304/fires-los-alerces-national-park-1745468.jpg" /></p>Firefighters still suppressing flames ravaging Patagonian national park; Chubut Province Governor Ignacio Torres alleges blaze was started by RAM Mapuche indigenous group. <a href="https://www.batimes.com.ar/news/argentina/fire-in-argentine-park-burns-2000-hectares-amid-heat-alert.phtml">Leer más</a>

## River’s youth production line keeps churning out quality
 - [https://www.batimes.com.ar/news/sports/rivers-youth-production-line-keeps-churning-out-quality.phtml](https://www.batimes.com.ar/news/sports/rivers-youth-production-line-keeps-churning-out-quality.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-02-01T15:43:35+00:00

<p><img alt="River Plate youngster Franco Mastontuano" src="https://fotos.perfil.com/2024/02/01/trim/540/304/river-plate-youngster-franco-mastontuano-1748251.jpg" /></p>River's pre-season was dominated by the Claudio Echeverri saga, but another few gems – Franco Mastontuano, Agustín Ruberto and Ian Subiabre – seem to have rolled off the famous Millo assembly line. <a href="https://www.batimes.com.ar/news/sports/rivers-youth-production-line-keeps-churning-out-quality.phtml">Leer más</a>

## Omnibus Law: What’s in and what’s out as bill goes to Congress?
 - [https://www.batimes.com.ar/news/argentina/omnibus-law-whats-in-and-whats-out-as-bill-goes-to-congress.phtml](https://www.batimes.com.ar/news/argentina/omnibus-law-whats-in-and-whats-out-as-bill-goes-to-congress.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-02-01T15:08:31+00:00

<p><img alt="omnibus protesters" src="https://fotos.perfil.com/2024/02/01/trim/540/304/omnibus-protesters-1748235.jpg" /></p>President Milei’s government had to make serious concessions and remove several points from the original text of its sweeping mega-reform bill, which is now slashed down to 386 articles from the original 664. <a href="https://www.batimes.com.ar/news/argentina/omnibus-law-whats-in-and-whats-out-as-bill-goes-to-congress.phtml">Leer más</a>

## Lawmakers debate President Milei's mega reform package
 - [https://www.batimes.com.ar/news/argentina/lawmakers-debate-president-mileis-mega-reform-package.phtml](https://www.batimes.com.ar/news/argentina/lawmakers-debate-president-mileis-mega-reform-package.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2024-02-01T03:39:56+00:00

<p><img alt="Demonstration Omnibus bill Congress" src="https://fotos.perfil.com/2024/02/01/trim/540/304/demonstration-omnibus-bill-congress-1748007.jpg" /></p>Lawmakers are prepared for a marathon session, with an initial 35 hours of debate planned over several days, and 200 speeches.
 <a href="https://www.batimes.com.ar/news/argentina/lawmakers-debate-president-mileis-mega-reform-package.phtml">Leer más</a>

