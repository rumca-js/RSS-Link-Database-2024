# Source:Wired Feed: All Latest, URL:https://www.wired.com/feed, language:en-US

## YouTube, Discord, and 'Lord of the Rings' Led Police to a Teen Accused of a US Swatting Spree
 - [https://www.wired.com/story/alan-filion-torswats-swatting-arrest](https://www.wired.com/story/alan-filion-torswats-swatting-arrest)
 - RSS feed: https://www.wired.com/feed
 - date published: 2024-02-01T01:28:52+00:00

For nearly two years, police have been tracking down the culprit behind a wave of hoax threats. A digital trail took them to the door of a 17-year-old in California.

## Linda Yaccarino Says X Needs More Moderators After All
 - [https://www.wired.com/story/linda-yaccarino-says-x-needs-more-moderators](https://www.wired.com/story/linda-yaccarino-says-x-needs-more-moderators)
 - RSS feed: https://www.wired.com/feed
 - date published: 2024-02-01T01:25:16+00:00

X CEO Linda Yaccarino told US senators she’s hiring more trust and safety staffers. She didn’t mention that Elon Musk fired most people policing content on the platform when he acquired it in 2022.

