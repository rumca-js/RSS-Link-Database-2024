# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## I Don’t Know What to Say… – Nvidia RTX 4070 Super, 4070 Ti Super, 4080 Super Review
 - [https://www.youtube.com/watch?v=UZ-hwlKmAPc](https://www.youtube.com/watch?v=UZ-hwlKmAPc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2024-02-01T19:40:40+00:00

Outsmart algorithms and optimize the way you read the news. Go to https://ground.news/linus to get 40% off the Ground News Vantage plan or subscribe to their Pro Plan for just $1/month.

Create your build at https://www.buildredux.com/linus

Nvidia has released 3 new GPUs this month, the 4070 Super, 4070 Ti Super and the 4080 Super. But are they worth the super name? Do they bring AMD to shame? How well do they game? 

Discuss on the forum: https://linustechtips.com/topic/1555856-nvidia-rtx-40-super-series-review/

Buy an NVIDIA RTX 4080 Super Graphics Card: https://lmg.gg/DWCW3 (Canada: https://lmg.gg/n8Es4 )
Buy an NVIDIA RTX 4070 Super Graphics Card: https://lmg.gg/TDHKK (Canada: https://lmg.gg/VX7Pd )
Buy an NVIDIA RTX 4070 Ti Super Graphics Card: https://lmg.gg/emPqZ (Canada: https://lmg.gg/Qlb38 )
Buy a XFX SPEEDSTER MERC310 Radeon RX 7900 XTX Graphics Card: https://geni.us/KZseocb
Buy an AMD Ryzen 7 7800X3D CPU: https://lmg.gg/s8Y1K (Canada: https://lmg.gg/yZnVo )
Buy 

