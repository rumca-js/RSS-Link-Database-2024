# Source:ZDNET, URL:https://www.zdnet.com/news/rss.xml, language:en-US

## Are your TikTok videos suddenly missing music tracks? Here's why
 - [https://www.zdnet.com/article/are-your-tiktok-videos-suddenly-missing-music-tracks-heres-why/#ftag=RSSbaffb68](https://www.zdnet.com/article/are-your-tiktok-videos-suddenly-missing-music-tracks-heres-why/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T21:33:35+00:00

Your TikTok experience might be a little weird for a while.

## The best blood pressure watches of 2024
 - [https://www.zdnet.com/article/best-blood-pressure-watch/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-blood-pressure-watch/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T21:09:29+00:00

ZDNET examined medical research and current FDA guidance to find the best blood pressure watches available on the market today, including options from Samsung and FitVII.

## Apple's Vision Pro will launch with 600 new apps built just for the headset
 - [https://www.zdnet.com/article/apples-vision-pro-will-launch-with-600-new-apps-built-just-for-the-headset/#ftag=RSSbaffb68](https://www.zdnet.com/article/apples-vision-pro-will-launch-with-600-new-apps-built-just-for-the-headset/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T19:59:00+00:00

In addition to a wide range of spatial applications - productivity tools, streaming services, education, and games - the Vision Pro will run 1 million compatible iOS and iPadOS apps.

## The best dating apps of 2024
 - [https://www.zdnet.com/article/best-dating-app/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-dating-app/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T19:55:36+00:00

Valentine's Day is just around the corner, and if you're wanting to find the perfect partner to take on a fun and romantic date, it's time to hit up the best dating apps.

## ChatGPT Enterprise vs. ChatGPT Team: Which is the best for your business?
 - [https://www.zdnet.com/article/chatgpt-enterprise-vs-chatgpt-team-which-is-the-best-for-your-business/#ftag=RSSbaffb68](https://www.zdnet.com/article/chatgpt-enterprise-vs-chatgpt-team-which-is-the-best-for-your-business/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T18:42:44+00:00

OpenAI recently released another business option - ChatGPT Team. Even though it may seem similar to ChatGPT Enterprise, there are some major differences.

## Get Microsoft Project 2021 Pro or Visio 2021 for $30 right now
 - [https://www.zdnet.com/home-and-office/get-microsoft-project-2021-pro-or-visio-2021-for-30-right-now/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/get-microsoft-project-2021-pro-or-visio-2021-for-30-right-now/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T18:00:18+00:00

Microsoft's project management solutions feature timesheet support, org charts, and more to help you stay organized -- and they're currently 88% off.

## How these $400 XR glasses cured my Apple Vision Pro FOMO
 - [https://www.zdnet.com/article/how-these-400-xr-glasses-cured-my-apple-vision-pro-fomo/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-these-400-xr-glasses-cured-my-apple-vision-pro-fomo/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T17:25:00+00:00

Viture's One XR glasses are a clever and portable way to work and play, and they somehow support Vision Pro's killer feature.

## Meta Quest headsets now support spatial video playback - ahead of Vision Pro launch
 - [https://www.zdnet.com/article/meta-quest-headsets-now-support-spatial-video-playback-ahead-of-vision-pro-launch/#ftag=RSSbaffb68](https://www.zdnet.com/article/meta-quest-headsets-now-support-spatial-video-playback-ahead-of-vision-pro-launch/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T17:23:00+00:00

The latest v62 software update includes the ability to upload and watch spatial videos on the latest Quest headsets.

## Google Maps is getting a generative AI boost. Here's what that will look like
 - [https://www.zdnet.com/article/google-maps-is-getting-a-generative-ai-boost-heres-what-that-will-look-like/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-maps-is-getting-a-generative-ai-boost-heres-what-that-will-look-like/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T17:00:19+00:00

Google Maps users will be able to easily find new places by using generative AI.

## Apple's Vision Pro to get Word, Excel, and other Microsoft 365 apps at launch
 - [https://www.zdnet.com/article/apples-vision-pro-to-get-word-excel-and-other-microsoft-365-apps-at-launch/#ftag=RSSbaffb68](https://www.zdnet.com/article/apples-vision-pro-to-get-word-excel-and-other-microsoft-365-apps-at-launch/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T17:00:12+00:00

Starting February 2, Vision Pro users can work with their Microsoft documents, spreadsheets, and other content in augmented reality.

## Buy Microsoft Office for PC or Mac for $30 right now
 - [https://www.zdnet.com/article/buy-microsoft-office-for-pc-or-mac-for-30-right-now/#ftag=RSSbaffb68](https://www.zdnet.com/article/buy-microsoft-office-for-pc-or-mac-for-30-right-now/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T16:59:03+00:00

This Microsoft Office deal gives you lifetime access to Microsoft Word, Excel, PowerPoint, and more, for over 80% off.

## My favorite hybrid smartwatch just got smarter, and its battery life is still incredible
 - [https://www.zdnet.com/article/my-favorite-hybrid-smartwatch-just-got-smarter-and-its-battery-life-is-still-incredible/#ftag=RSSbaffb68](https://www.zdnet.com/article/my-favorite-hybrid-smartwatch-just-got-smarter-and-its-battery-life-is-still-incredible/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T15:39:00+00:00

Withings' latest ScanWatch 2 embeds the company's best health-tracking technology into a high-end, hybrid wearable.

## Hulu begins password-sharing crackdown: What happens if you're caught
 - [https://www.zdnet.com/home-and-office/home-entertainment/hulu-begins-password-sharing-crackdown-what-happens-if-youre-caught/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/hulu-begins-password-sharing-crackdown-what-happens-if-youre-caught/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T15:13:51+00:00

Following Disney+ and Netflix, another streaming giant is cutting off freeloaders.

## This new rechargeable smart lock doesn't change your front door's exterior
 - [https://www.zdnet.com/home-and-office/smart-home/this-new-rechargeable-smart-lock-doesnt-change-your-front-doors-exterior/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/this-new-rechargeable-smart-lock-doesnt-change-your-front-doors-exterior/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T15:02:00+00:00

The Abode Lock retrofits to fit an existing deadbolt and features a large, 4,000mAh rechargeable battery for up to 12 months of use.

## Google's AI image generator finally rolls out to the public - here's how to try it
 - [https://www.zdnet.com/article/googles-ai-image-generator-finally-rolls-out-to-the-public-heres-how-to-try-it/#ftag=RSSbaffb68](https://www.zdnet.com/article/googles-ai-image-generator-finally-rolls-out-to-the-public-heres-how-to-try-it/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T15:00:19+00:00

The tech giant is entering the image generator scene in full swing with two new releases.

## The best Lenovo laptops of 2024: Expert tested and reviewed
 - [https://www.zdnet.com/article/best-lenovo-laptop/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-lenovo-laptop/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T15:00:03+00:00

ZDNET tested the best Lenovo laptops to help you choose which one to buy, whether you're looking for one for work, personal use, gaming, or a 2-in-1 device.

## Sick of mistaking legit calls for spam? This new AT&T wireless service might help
 - [https://www.zdnet.com/article/sick-of-mistaking-legit-calls-for-spam-this-new-at-t-wireless-service-might-help/#ftag=RSSbaffb68](https://www.zdnet.com/article/sick-of-mistaking-legit-calls-for-spam-this-new-at-t-wireless-service-might-help/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T08:50:27+00:00

Here's why you may soon see business logos on incoming calls.

## How to send feedback to help the ChromeOS developers (and why you should)
 - [https://www.zdnet.com/article/how-to-send-feedback-to-help-the-chromeos-developers-and-why-you-should/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-send-feedback-to-help-the-chromeos-developers-and-why-you-should/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T08:30:08+00:00

I've been using the beta channel of ChromeOS for some time now, and I often like to send in feedback to the developers. Here's why and how.

## Generative AI fails in this very common ability of human thought
 - [https://www.zdnet.com/article/generative-ai-fails-in-this-very-common-ability-of-human-thought/#ftag=RSSbaffb68](https://www.zdnet.com/article/generative-ai-fails-in-this-very-common-ability-of-human-thought/#ftag=RSSbaffb68)
 - RSS feed: https://www.zdnet.com/news/rss.xml
 - date published: 2024-02-01T01:01:00+00:00

OpenAI's GPT-3.5 and GPT-4 both fell down when challenged with greater and greater levels of this basic computer task, pointing to a fundamental omission in their design.

