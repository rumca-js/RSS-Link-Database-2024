# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Adam Bodnar: Przepraszam osoby LGBT+ za krzywdę ze strony państwa
 - [https://wydarzenia.interia.pl/kraj/news-adam-bodnar-przepraszam-osoby-lgbt-za-krzywde-ze-strony-pans,nId,7306129](https://wydarzenia.interia.pl/kraj/news-adam-bodnar-przepraszam-osoby-lgbt-za-krzywde-ze-strony-pans,nId,7306129)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T21:50:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-adam-bodnar-przepraszam-osoby-lgbt-za-krzywde-ze-strony-pans,nId,7306129"><img align="left" alt="Adam Bodnar: Przepraszam osoby LGBT+ za krzywdę ze strony państwa" src="https://i.iplsc.com/adam-bodnar-przepraszam-osoby-lgbt-za-krzywde-ze-strony-pans/000IIO8B69S9TGSL-C321.jpg" /></a>- Chciałbym was bardzo przeprosić za krzywdę, której doznaliście ze strony państwa polskiego - powiedział Adam Bodnar, podczas spotkania z organizacjami wspierającymi osoby LGBT+. Natomiast wiceminister sprawiedliwości Krzysztof Śmiszek zapowiedział zmiany w Kodeksie karnym.</p><br clear="all" />

## Niebezpiecznie na Mazowszu. Wypadek z udziałem cysterny
 - [https://wydarzenia.interia.pl/mazowieckie/news-niebezpiecznie-na-mazowszu-wypadek-z-udzialem-cysterny,nId,7306118](https://wydarzenia.interia.pl/mazowieckie/news-niebezpiecznie-na-mazowszu-wypadek-z-udzialem-cysterny,nId,7306118)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T21:29:11+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-niebezpiecznie-na-mazowszu-wypadek-z-udzialem-cysterny,nId,7306118"><img align="left" alt="Niebezpiecznie na Mazowszu. Wypadek z udziałem cysterny" src="https://i.iplsc.com/niebezpiecznie-na-mazowszu-wypadek-z-udzialem-cysterny/000IIO3XGEJJ52VA-C321.jpg" /></a>Groźne zdarzenie z udziałem cysterny koło Wyszkowa na Mazowszu. Pojazd przewrócił się na bok na trasie Leszczydół-Nowiny. Na miejscu pojawili się policjanci, którzy wyjaśniają przebieg i okoliczności zdarzenia. 

</p><br clear="all" />

## Niemcy chcą wywłaszczyć rosyjską rafinerię. Udziały mogą trafić do Polski
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-chca-wywlaszczyc-rosyjska-rafinerie-udzialy-moga-traf,nId,7306113](https://wydarzenia.interia.pl/zagranica/news-niemcy-chca-wywlaszczyc-rosyjska-rafinerie-udzialy-moga-traf,nId,7306113)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T21:15:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-chca-wywlaszczyc-rosyjska-rafinerie-udzialy-moga-traf,nId,7306113"><img align="left" alt="Niemcy chcą wywłaszczyć rosyjską rafinerię. Udziały mogą trafić do Polski" src="https://i.iplsc.com/niemcy-chca-wywlaszczyc-rosyjska-rafinerie-udzialy-moga-traf/000IIO16WSB6V0BN-C321.jpg" /></a>Niemieckie ministerstwo gospodarki ma plan na wywłaszczenie koncernu rosyjskiego Rosnieft w rafinerii PCK Schwedt. Według doniesień medialnych, Rosjanie mogą stracić udziały na rzecz Polaków.</p><br clear="all" />

## Wyjątkowe odkrycie Polaka. "Niepodobne do niczego innego"
 - [https://wydarzenia.interia.pl/kraj/news-wyjatkowe-odkrycie-polaka-niepodobne-do-niczego-innego,nId,7305893](https://wydarzenia.interia.pl/kraj/news-wyjatkowe-odkrycie-polaka-niepodobne-do-niczego-innego,nId,7305893)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T20:43:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wyjatkowe-odkrycie-polaka-niepodobne-do-niczego-innego,nId,7305893"><img align="left" alt="Wyjątkowe odkrycie Polaka. &quot;Niepodobne do niczego innego&quot;" src="https://i.iplsc.com/wyjatkowe-odkrycie-polaka-niepodobne-do-niczego-innego/000IINI7G0PJLC0X-C321.jpg" /></a>Polski naukowiec dr hab. Piotr Szrek - wraz z grupą międzynarodowego zespołu badaczy - odkrył wyjątkowy gatunek ryby pancernej znanej jako Alienacanthusem malkowskii. Niepodobne do żadnych innych szczątki znaleziono w Chęcinach (woj. świętokrzyskie), a ich wiek szacuje się na 365 mln lat.</p><br clear="all" />

## Deszcz, śnieg i zamiecie. Potężny wyż zmieni pogodę w Polsce
 - [https://wydarzenia.interia.pl/kraj/news-deszcz-snieg-i-zamiecie-potezny-wyz-zmieni-pogode-w-polsce,nId,7306095](https://wydarzenia.interia.pl/kraj/news-deszcz-snieg-i-zamiecie-potezny-wyz-zmieni-pogode-w-polsce,nId,7306095)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T20:36:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-deszcz-snieg-i-zamiecie-potezny-wyz-zmieni-pogode-w-polsce,nId,7306095"><img align="left" alt="Deszcz, śnieg i zamiecie. Potężny wyż zmieni pogodę w Polsce" src="https://i.iplsc.com/deszcz-snieg-i-zamiecie-potezny-wyz-zmieni-pogode-w-polsce/000IIO1YVIX8BWNK-C321.jpg" /></a>Pogoda w Polsce znajdzie się w piątek pod wpływem wyżu znad Zatoki Biskajskiej. Możemy spodziewać się opadów deszczu, deszczu ze śniegiem i śniegu. W części regionów przewidywany jest silny wiatr- nawet do 120 km/h, powodujący zawieje i zamiecie śnieżne.</p><br clear="all" />

## Policja w Brukseli użyła armatek. "Oberwała" polska europosłanka
 - [https://wydarzenia.interia.pl/tylko-w-interii/news-policja-w-brukseli-uzyla-armatek-oberwala-polska-europoslank,nId,7306104](https://wydarzenia.interia.pl/tylko-w-interii/news-policja-w-brukseli-uzyla-armatek-oberwala-polska-europoslank,nId,7306104)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T20:04:17+00:00

<p><a href="https://wydarzenia.interia.pl/tylko-w-interii/news-policja-w-brukseli-uzyla-armatek-oberwala-polska-europoslank,nId,7306104"><img align="left" alt="Policja w Brukseli użyła armatek. &quot;Oberwała&quot; polska europosłanka" src="https://i.iplsc.com/policja-w-brukseli-uzyla-armatek-oberwala-polska-europoslank/000IINV1BWMDYS33-C321.jpg" /></a>Podczas protestu rolników w Brukseli policja użyła wody, by poskromić demonstrantów. Oblana została również polska europarlamentarzystka. - Byliśmy tam w środku, w centrum wydarzeń. Było dość gorąco. Płonęły opony. W pewnym momencie policja zaczęła strzelać gazem łzawiącym, z armatek lała się woda. No i ja też, można powiedzieć, oberwałam - mówi Interii deputowana z PiS.</p><br clear="all" />

## Specjalny komunikat prezesa PiS. "Ryzyko uwolnienia tysięcy przestępców"
 - [https://wydarzenia.interia.pl/kraj/news-specjalny-komunikat-prezesa-pis-ryzyko-uwolnienia-tysiecy-pr,nId,7306088](https://wydarzenia.interia.pl/kraj/news-specjalny-komunikat-prezesa-pis-ryzyko-uwolnienia-tysiecy-pr,nId,7306088)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T18:48:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-specjalny-komunikat-prezesa-pis-ryzyko-uwolnienia-tysiecy-pr,nId,7306088"><img align="left" alt="Specjalny komunikat prezesa PiS. &quot;Ryzyko uwolnienia tysięcy przestępców&quot;" src="https://i.iplsc.com/specjalny-komunikat-prezesa-pis-ryzyko-uwolnienia-tysiecy-pr/000IBOVZ1LXWOQO6-C321.jpg" /></a>&quot;Atak na niezależną prokuraturę, przeprowadzany z rażącym naruszeniem prawa i - co gorsza - przy skrajnej niekompetencji jego autorów, skutkuje ryzykiem uwolnienia od odpowiedzialności karnej tysięcy przestępców&quot; - oświadczył Jarosław Kaczyński w imieniu Komitetu Politycznego PiS. Prezes ugrupowania wystosował &quot;sprzeciw wobec kolejnych kroków rządu Donalda Tuska w kierunku systemowego bezprawia&quot;.</p><br clear="all" />

## Ustawa budżetowa opublikowana w Dzienniku Ustaw
 - [https://wydarzenia.interia.pl/kraj/news-ustawa-budzetowa-opublikowana-w-dzienniku-ustaw,nId,7306086](https://wydarzenia.interia.pl/kraj/news-ustawa-budzetowa-opublikowana-w-dzienniku-ustaw,nId,7306086)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T18:41:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ustawa-budzetowa-opublikowana-w-dzienniku-ustaw,nId,7306086"><img align="left" alt="Ustawa budżetowa opublikowana w Dzienniku Ustaw" src="https://i.iplsc.com/ustawa-budzetowa-opublikowana-w-dzienniku-ustaw/000IINOSHP4I9PU5-C321.jpg" /></a>Ustawa budżetowa została opublikowana w Dzienniku Ustaw. Tym samym wchodzi w życie z mocą wsteczną od 1 stycznia. Prezydent podpisał ustawę w środę, ale zdecydował się odesłać ją do Trybunału Konstytucyjnego w trybie następczym.</p><br clear="all" />

## Viktor Orban ujawnił plany. Wśród partnerów PiS i Giorgia Meloni
 - [https://wydarzenia.interia.pl/zagranica/news-viktor-orban-ujawnil-plany-wsrod-partnerow-pis-i-giorgia-mel,nId,7306066](https://wydarzenia.interia.pl/zagranica/news-viktor-orban-ujawnil-plany-wsrod-partnerow-pis-i-giorgia-mel,nId,7306066)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T18:25:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-viktor-orban-ujawnil-plany-wsrod-partnerow-pis-i-giorgia-mel,nId,7306066"><img align="left" alt="Viktor Orban ujawnił plany. Wśród partnerów PiS i Giorgia Meloni" src="https://i.iplsc.com/viktor-orban-ujawnil-plany-wsrod-partnerow-pis-i-giorgia-mel/000IINJ0DHEG6HV0-C321.jpg" /></a>Premier Węgier Viktor Orban oznajmił, że jego partia Fidesz znalazła partnerów, z którymi chce współpracować po wyborach europejskich. Chodzi polityków z Włoch i Polski. Orban ujawnił też, jak wyglądały negocjacje ws. unijnego wsparcia dla Ukrainy. Przekazał, że pieniądze z Węgier nie trafią do Kijowa.</p><br clear="all" />

## Zaginęło dwoje dzieci. Policja szuka Alicji i Marcela
 - [https://wydarzenia.interia.pl/malopolskie/news-zaginelo-dwoje-dzieci-policja-szuka-alicji-i-marcela,nId,7306060](https://wydarzenia.interia.pl/malopolskie/news-zaginelo-dwoje-dzieci-policja-szuka-alicji-i-marcela,nId,7306060)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T18:17:28+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-zaginelo-dwoje-dzieci-policja-szuka-alicji-i-marcela,nId,7306060"><img align="left" alt="Zaginęło dwoje dzieci. Policja szuka Alicji i Marcela" src="https://i.iplsc.com/zaginelo-dwoje-dzieci-policja-szuka-alicji-i-marcela/000IINHKPLXUI1KT-C321.jpg" /></a>Policja w Limanowej poszukuje dwójki dzieci - czteroletniej Alicji i trzyletniego Marcela. Zaginięcie zgłosiła matka maluchów, kiedy ojciec nie przekazał ich pod jej opiekę. Funkcjonariusze apelują o pomoc.</p><br clear="all" />

## Zaginęło dwoje dzieci. Policja szuka czteroletniej Alicji i trzyletniego Marcela
 - [https://wydarzenia.interia.pl/malopolskie/news-zaginelo-dwoje-dzieci-policja-szuka-czteroletniej-alicji-i-t,nId,7306060](https://wydarzenia.interia.pl/malopolskie/news-zaginelo-dwoje-dzieci-policja-szuka-czteroletniej-alicji-i-t,nId,7306060)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T18:17:28+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-zaginelo-dwoje-dzieci-policja-szuka-czteroletniej-alicji-i-t,nId,7306060"><img align="left" alt="Zaginęło dwoje dzieci. Policja szuka czteroletniej Alicji i trzyletniego Marcela" src="https://i.iplsc.com/zaginelo-dwoje-dzieci-policja-szuka-czteroletniej-alicji-i-t/000IINHKPLXUI1KT-C321.jpg" /></a>Policja w Limanowej poszukuje dwójki dzieci - czteroletniej Alicji i trzyletniego Marcela. Zaginięcie zgłosiła matka maluchów, kiedy ojciec nie przekazał ich pod jej opiekę. Funkcjonariusze apelują o pomoc.</p><br clear="all" />

## Kłopoty wdowy po Grzegorzu Borysie. Straci mieszkanie
 - [https://wydarzenia.interia.pl/kraj/news-klopoty-wdowy-po-grzegorzu-borysie-straci-mieszkanie,nId,7306052](https://wydarzenia.interia.pl/kraj/news-klopoty-wdowy-po-grzegorzu-borysie-straci-mieszkanie,nId,7306052)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T18:10:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-klopoty-wdowy-po-grzegorzu-borysie-straci-mieszkanie,nId,7306052"><img align="left" alt="Kłopoty wdowy po Grzegorzu Borysie. Straci mieszkanie" src="https://i.iplsc.com/klopoty-wdowy-po-grzegorzu-borysie-straci-mieszkanie/000IIN9SO9BPOCOC-C321.jpg" /></a>Po śmierci Grzegorza Borysa w trudnej sytuacji znalazła się jego żona. Jak się okazuje, lokal który zajmowała, należy do Agencji Mienia Wojskowego. Kobieta musi go teraz opuścić.</p><br clear="all" />

## Wraca sprawa Grzegorza Borysa. Wdowa po mężczyźnie w tarapatach
 - [https://wydarzenia.interia.pl/kraj/news-wraca-sprawa-grzegorza-borysa-wdowa-po-mezczyznie-w-tarapata,nId,7306052](https://wydarzenia.interia.pl/kraj/news-wraca-sprawa-grzegorza-borysa-wdowa-po-mezczyznie-w-tarapata,nId,7306052)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T18:10:01+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wraca-sprawa-grzegorza-borysa-wdowa-po-mezczyznie-w-tarapata,nId,7306052"><img align="left" alt="Wraca sprawa Grzegorza Borysa. Wdowa po mężczyźnie w tarapatach" src="https://i.iplsc.com/wraca-sprawa-grzegorza-borysa-wdowa-po-mezczyznie-w-tarapata/000IIN9SO9BPOCOC-C321.jpg" /></a>Po śmierci Grzegorza Borysa w trudnej sytuacji znalazła się jego żona. Jak się okazuje, lokal który zajmowała, należy do Agencji Mienia Wojskowego. Kobieta musi go teraz opuścić.</p><br clear="all" />

## Była wicewojewoda z zarzutami. W tle ogromna kwota
 - [https://wydarzenia.interia.pl/podkarpackie/news-byla-wicewojewoda-z-zarzutami-w-tle-ogromna-kwota,nId,7305987](https://wydarzenia.interia.pl/podkarpackie/news-byla-wicewojewoda-z-zarzutami-w-tle-ogromna-kwota,nId,7305987)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T17:45:01+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-byla-wicewojewoda-z-zarzutami-w-tle-ogromna-kwota,nId,7305987"><img align="left" alt="Była wicewojewoda z zarzutami. W tle ogromna kwota" src="https://i.iplsc.com/byla-wicewojewoda-z-zarzutami-w-tle-ogromna-kwota/000IIN860PLUHUTN-C321.jpg" /></a>Była wicewojewoda podkarpacka Lucyna P. miała według śledczych przywłaszczyć kilkaset tysięcy złotych. W Lublinie usłyszała prokuratorskie zarzuty. Kobieta nie przyznała się do winy. Za zarzucane jej czyny grozi do 10 lat więzienia.

</p><br clear="all" />

## Przyjaciółka Kaczyńskiego na pożegnaniu Obajtka. "Odejdź, młodzieńcze"
 - [https://wydarzenia.interia.pl/kraj/news-przyjaciolka-kaczynskiego-na-pozegnaniu-obajtka-odejdz-mlodz,nId,7305819](https://wydarzenia.interia.pl/kraj/news-przyjaciolka-kaczynskiego-na-pozegnaniu-obajtka-odejdz-mlodz,nId,7305819)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T17:08:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-przyjaciolka-kaczynskiego-na-pozegnaniu-obajtka-odejdz-mlodz,nId,7305819"><img align="left" alt="Przyjaciółka Kaczyńskiego na pożegnaniu Obajtka. &quot;Odejdź, młodzieńcze&quot;" src="https://i.iplsc.com/przyjaciolka-kaczynskiego-na-pozegnaniu-obajtka-odejdz-mlodz/000IIMP34O4IAVJ4-C321.jpg" /></a>- Odejdź, młodzieńcze, zachowuj się jakoś - powiedziała Janina Goss dziennikarzowi po konferencji prasowej Daniela Obajtka, który żegnał się z funkcją prezesa państwowego giganta. Bliska przyjaciółka prezesa PiS Jarosława Kaczyńskiego nie chciała odpowiedzieć na pytanie o to, w jakiej roli stawiła się na czwartkowej konferencji. W grudniu została odwołana z Rady Nadzorczej paliwowej spółki.</p><br clear="all" />

## Wyszły ze szkoły, znalazły się w Niemczech. Wielka akcja służb
 - [https://wydarzenia.interia.pl/zagranica/news-wyszly-ze-szkoly-znalazly-sie-w-niemczech-wielka-akcja-sluzb,nId,7305776](https://wydarzenia.interia.pl/zagranica/news-wyszly-ze-szkoly-znalazly-sie-w-niemczech-wielka-akcja-sluzb,nId,7305776)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T17:04:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wyszly-ze-szkoly-znalazly-sie-w-niemczech-wielka-akcja-sluzb,nId,7305776"><img align="left" alt="Wyszły ze szkoły, znalazły się w Niemczech. Wielka akcja służb" src="https://i.iplsc.com/wyszly-ze-szkoly-znalazly-sie-w-niemczech-wielka-akcja-sluzb/000IIMUGXPOEWFFV-C321.jpg" /></a>Niemiecka policja odnalazła w Görlitz dzieci z Nysy, które w środę po szkole nie wróciły do domu. 14-latek i jego 10-letnia siostra jechali pociągami ze swojego miasta i stale zmierzali w kierunku granicy. W akcje poszukiwawczą zaangażowali się funkcjonariusze z dwóch województw i z Niemiec.</p><br clear="all" />

## Rolnicy ruszyli na Brukselę. Petardy, zniszczony pomnik, 1000 traktorów na ulicach
 - [https://wydarzenia.interia.pl/zagranica/news-rolnicy-ruszyli-na-bruksele-petardy-zniszczony-pomnik-1000-t,nId,7305865](https://wydarzenia.interia.pl/zagranica/news-rolnicy-ruszyli-na-bruksele-petardy-zniszczony-pomnik-1000-t,nId,7305865)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T16:44:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rolnicy-ruszyli-na-bruksele-petardy-zniszczony-pomnik-1000-t,nId,7305865"><img align="left" alt="Rolnicy ruszyli na Brukselę. Petardy, zniszczony pomnik, 1000 traktorów na ulicach" src="https://i.iplsc.com/rolnicy-ruszyli-na-bruksele-petardy-zniszczony-pomnik-1000-t/000IIMWFRV52WC3B-C321.jpg" /></a>Zniszczony pomnik, petardy i około tysiąca traktorów, które zablokowały centrum Brukseli. Tak wyglądał czwartkowy protest rolników w stolicy Unii Europejskiej. W dniu unijnego szczytu domagali się zmian podatkowych, protestowali przeciwko rosnącym kosztom produkcji oraz nieuczciwej konkurencji z zagranicy.</p><br clear="all" />

## Donald Tusk ogłasza triumf w UE. "Gra Viktora Orbana się zakończyła"
 - [https://wydarzenia.interia.pl/kraj/news-donald-tusk-oglasza-triumf-w-ue-gra-viktora-orbana-sie-zakon,nId,7305799](https://wydarzenia.interia.pl/kraj/news-donald-tusk-oglasza-triumf-w-ue-gra-viktora-orbana-sie-zakon,nId,7305799)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T15:44:30+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-donald-tusk-oglasza-triumf-w-ue-gra-viktora-orbana-sie-zakon,nId,7305799"><img align="left" alt="Donald Tusk ogłasza triumf w UE. &quot;Gra Viktora Orbana się zakończyła&quot;" src="https://i.iplsc.com/donald-tusk-oglasza-triumf-w-ue-gra-viktora-orbana-sie-zakon/000IIM8W5W3PERPB-C321.jpg" /></a>- Gra Viktora Orbana się zakończyła. Było to znacznie prostsze niż niektórzy się spodziewali - oznajmił Donald Tusk podczas konferencji po spotkaniu przywódców państw UE w ramach Rady Europejskiej. Premier poruszył też temat zwołanej przez prezydenta Rady Gabinetowej, którą nazwał &quot;nieformalnym spotkaniem&quot;. - Byłbym bardzo usatysfakcjonowany, żeby nie było żadnych domysłów, żeby ta Rada była tak &quot;live&quot; we wszystkich telewizjach - zaznaczył Tusk.</p><br clear="all" />

## Podwyżki dla nauczycieli opóźnione? Jest głos z ministerstwa
 - [https://wydarzenia.interia.pl/kraj/news-podwyzki-dla-nauczycieli-opoznione-jest-glos-z-ministerstwa,nId,7305719](https://wydarzenia.interia.pl/kraj/news-podwyzki-dla-nauczycieli-opoznione-jest-glos-z-ministerstwa,nId,7305719)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T15:33:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-podwyzki-dla-nauczycieli-opoznione-jest-glos-z-ministerstwa,nId,7305719"><img align="left" alt="Podwyżki dla nauczycieli opóźnione? Jest głos z ministerstwa" src="https://i.iplsc.com/podwyzki-dla-nauczycieli-opoznione-jest-glos-z-ministerstwa/000I7MV2T47NQN5R-C321.jpg" /></a>- Może się zdarzyć, że podwyżki wynagrodzeń dla nauczycieli będą wypłacane dopiero od kwietnia - powiedziała Barbara Nowacka po spotkaniu ze związkami zawodowymi. Minister edukacji przekazała, że fakt wiąże się z późnym złożeniem podpisu pod ustawą budżetową przez Andrzeja Dudę. - Jesteśmy zasmuceni, że pan prezydent dla gry politycznej poświęcił spokój oraz bezpieczeństwo nauczycielek i nauczycieli - dodała.</p><br clear="all" />

## Podwyżki dla nauczycieli. Minister o opóźnieniach
 - [https://wydarzenia.interia.pl/kraj/news-podwyzki-dla-nauczycieli-minister-o-opoznieniach,nId,7305719](https://wydarzenia.interia.pl/kraj/news-podwyzki-dla-nauczycieli-minister-o-opoznieniach,nId,7305719)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T15:33:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-podwyzki-dla-nauczycieli-minister-o-opoznieniach,nId,7305719"><img align="left" alt="Podwyżki dla nauczycieli. Minister o opóźnieniach" src="https://i.iplsc.com/podwyzki-dla-nauczycieli-minister-o-opoznieniach/000IIKMRT9VK7DA9-C321.jpg" /></a>- Może się zdarzyć, że podwyżki wynagrodzeń dla nauczycieli będą wypłacane dopiero od kwietnia - powiedziała Barbara Nowacka po spotkaniu ze związkami zawodowymi. Minister edukacji przekazała, że fakt wiąże się z późnym złożeniem podpisu pod ustawą budżetową przez Andrzeja Dudę. - Jesteśmy zasmuceni, że pan prezydent dla gry politycznej poświęcił spokój oraz bezpieczeństwo nauczycielek i nauczycieli - dodała.</p><br clear="all" />

## Podwyżki dla nauczycieli. Niepokojące słowa Barbary Nowackiej
 - [https://wydarzenia.interia.pl/kraj/news-podwyzki-dla-nauczycieli-niepokojace-slowa-barbary-nowackiej,nId,7305719](https://wydarzenia.interia.pl/kraj/news-podwyzki-dla-nauczycieli-niepokojace-slowa-barbary-nowackiej,nId,7305719)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T15:33:21+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-podwyzki-dla-nauczycieli-niepokojace-slowa-barbary-nowackiej,nId,7305719"><img align="left" alt="Podwyżki dla nauczycieli. Niepokojące słowa Barbary Nowackiej" src="https://i.iplsc.com/podwyzki-dla-nauczycieli-niepokojace-slowa-barbary-nowackiej/000IIKMRT9VK7DA9-C321.jpg" /></a>- Może się zdarzyć, że podwyżki wynagrodzeń dla nauczycieli będą wypłacane dopiero od kwietnia - powiedziała Barbara Nowacka po spotkaniu ze związkami zawodowymi. Minister edukacji przekazała, że fakt wiąże się z późnym złożeniem podpisu pod ustawą budżetową przez Andrzeja Dudę. - Jesteśmy zasmuceni, że pan prezydent dla gry politycznej poświęcił spokój oraz bezpieczeństwo nauczycielek i nauczycieli - dodała.</p><br clear="all" />

## Strzały we Wrocławiu. Trwa obława za kierowcą
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-strzaly-we-wroclawiu-trwa-oblawa-za-kierowca,nId,7305794](https://wydarzenia.interia.pl/dolnoslaskie/news-strzaly-we-wroclawiu-trwa-oblawa-za-kierowca,nId,7305794)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T15:11:32+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-strzaly-we-wroclawiu-trwa-oblawa-za-kierowca,nId,7305794"><img align="left" alt="Strzały we Wrocławiu. Trwa obława za kierowcą" src="https://i.iplsc.com/strzaly-we-wroclawiu-trwa-oblawa-za-kierowca/000IILXIC2BDXL9G-C321.jpg" /></a>Po godzinie 14 na Psim Polu we Wrocławiu padły strzały. W trakcie rutynowej kontroli kierowca nagle ruszył, uderzył w radiowóz, potrącił policjanta i zaczął uciekać. Trwa policyjna obława za granatowym passatem. </p><br clear="all" />

## Trzech liderów w walce o prezydencki fotel. Najnowszy sondaż
 - [https://wydarzenia.interia.pl/kraj/news-trzech-liderow-w-walce-o-prezydencki-fotel-najnowszy-sondaz,nId,7305743](https://wydarzenia.interia.pl/kraj/news-trzech-liderow-w-walce-o-prezydencki-fotel-najnowszy-sondaz,nId,7305743)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T14:57:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-trzech-liderow-w-walce-o-prezydencki-fotel-najnowszy-sondaz,nId,7305743"><img align="left" alt="Trzech liderów w walce o prezydencki fotel. Najnowszy sondaż" src="https://i.iplsc.com/trzech-liderow-w-walce-o-prezydencki-fotel-najnowszy-sondaz/000IIKOQG7PVE95W-C321.jpg" /></a>Chociaż wiceszef Platformy Obywatelskiej Rafał Trzaskowski może liczyć na największe poparcie w wyścigu o prezydencki fotel, to w porównaniu do poprzedniego badania przewaga nad innymi potencjalnymi kandydatami topnieje - wynika z  sondażu IBRIS. Duży wzrost poparcia zanotował z kolei marszałek Sejmu Szymon Hołownia. Oprócz nich w grze jest jeszcze jeden polityk, związany z Prawem i Sprawiedliwością. </p><br clear="all" />

## We trzech powalczą o Pałac. Lider z gigantyczną stratą
 - [https://wydarzenia.interia.pl/kraj/news-we-trzech-powalcza-o-palac-lider-z-gigantyczna-strata,nId,7305743](https://wydarzenia.interia.pl/kraj/news-we-trzech-powalcza-o-palac-lider-z-gigantyczna-strata,nId,7305743)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T14:57:38+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-we-trzech-powalcza-o-palac-lider-z-gigantyczna-strata,nId,7305743"><img align="left" alt="We trzech powalczą o Pałac. Lider z gigantyczną stratą" src="https://i.iplsc.com/we-trzech-powalcza-o-palac-lider-z-gigantyczna-strata/000IIMTY09C0VIX7-C321.jpg" /></a>Chociaż wiceszef Platformy Obywatelskiej Rafał Trzaskowski może liczyć na największe poparcie w wyścigu o prezydencki fotel, to w porównaniu do poprzedniego badania przewaga nad innymi potencjalnymi kandydatami topnieje - wynika z sondażu IBRIS. Duży wzrost poparcia zanotował z kolei marszałek Sejmu Szymon Hołownia. Oprócz nich w grze jest jeszcze jeden polityk - związany z Prawem i Sprawiedliwością. </p><br clear="all" />

## Trybunał Konstytucyjny zawiesza decyzję Bodnara. Chodzi o sędziego Schaba
 - [https://wydarzenia.interia.pl/kraj/news-trybunal-konstytucyjny-zawiesza-decyzje-bodnara-chodzi-o-sed,nId,7305714](https://wydarzenia.interia.pl/kraj/news-trybunal-konstytucyjny-zawiesza-decyzje-bodnara-chodzi-o-sed,nId,7305714)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T14:39:29+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-trybunal-konstytucyjny-zawiesza-decyzje-bodnara-chodzi-o-sed,nId,7305714"><img align="left" alt="Trybunał Konstytucyjny zawiesza decyzję Bodnara. Chodzi o sędziego Schaba" src="https://i.iplsc.com/trybunal-konstytucyjny-zawiesza-decyzje-bodnara-chodzi-o-sed/000IIJP65TP394PC-C321.jpg" /></a>Trybunał Konstytucyjny zdecydował o tymczasowym zawieszeniu obowiązywania decyzji ministra sprawiedliwości Adama Bodnara ws. odwołania prezesa Sądu Apelacyjnego w Warszawie Piotra Schaba. Decyzja obejmuje też zakaz wydawania takiej decyzji w przyszłości w oparciu o takie same podstawy prawne.</p><br clear="all" />

## Sieć wojskowych baz w Afryce. Rosja ma nowy plan dla kontynentu
 - [https://wydarzenia.interia.pl/zagranica/news-siec-wojskowych-baz-w-afryce-rosja-ma-nowy-plan-dla-kontynen,nId,7305707](https://wydarzenia.interia.pl/zagranica/news-siec-wojskowych-baz-w-afryce-rosja-ma-nowy-plan-dla-kontynen,nId,7305707)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T14:25:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-siec-wojskowych-baz-w-afryce-rosja-ma-nowy-plan-dla-kontynen,nId,7305707"><img align="left" alt="Sieć wojskowych baz w Afryce. Rosja ma nowy plan dla kontynentu " src="https://i.iplsc.com/siec-wojskowych-baz-w-afryce-rosja-ma-nowy-plan-dla-kontynen/000IIKOBIRA4SMQU-C321.jpg" /></a>Rosja tworzy nowy korpus najemników, który zastąpi grupę Wagnera. Ministerstwo Obrony Federacji Rosyjskiej chce zrekrutować 20 tysięcy osób, w tym część podwładnych nieżyjącego Jewgienija Prigożyna, którzy będą działać w pięciu afrykańskich krajach. Według najnowszych informacji brytyjskiego wywiadu niedobitki wagnerowców zostaną wcielone także w szeregi Gwardii Narodowej Rosji.</p><br clear="all" />

## Wybił szyby w hotelu, zepchnął autobus z drogi. Ingunn szaleje w Norwegii
 - [https://wydarzenia.interia.pl/zagranica/news-wybil-szyby-w-hotelu-zepchnal-autobus-z-drogi-ingunn-szaleje,nId,7305740](https://wydarzenia.interia.pl/zagranica/news-wybil-szyby-w-hotelu-zepchnal-autobus-z-drogi-ingunn-szaleje,nId,7305740)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T14:06:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wybil-szyby-w-hotelu-zepchnal-autobus-z-drogi-ingunn-szaleje,nId,7305740"><img align="left" alt="Wybił szyby w hotelu, zepchnął autobus z drogi. Ingunn szaleje w Norwegii" src="https://i.iplsc.com/wybil-szyby-w-hotelu-zepchnal-autobus-z-drogi-ingunn-szaleje/000IIKA2DRPCKVNN-C321.jpg" /></a>Potężny orkan Ingunn uderza w Skandynawię. Wiejący z prędkością 180 km/h wiatr wybijał szyby w hotelu, uniemożliwiał transport i zrywał linie energetyczne. Z powodu złych warunków zamknięto szkoły, a kilkadziesiąt tysięcy domów nie ma prądu. W jednym z norweskich miast wiatr zdmuchnął z drogi autobus z kilkunastoma pasażerami w środku. Policja zaleciła mieszkańcom wielu miejsc pozostanie w domach.</p><br clear="all" />

## Polityczne trzęsienie ziemi na Dolnym Śląsku. Zdecydowało tajne głosowanie
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-polityczne-trzesienie-ziemi-na-dolnym-slasku-zdecydowalo-taj,nId,7305706](https://wydarzenia.interia.pl/dolnoslaskie/news-polityczne-trzesienie-ziemi-na-dolnym-slasku-zdecydowalo-taj,nId,7305706)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T13:30:25+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-polityczne-trzesienie-ziemi-na-dolnym-slasku-zdecydowalo-taj,nId,7305706"><img align="left" alt="Polityczne trzęsienie ziemi na Dolnym Śląsku. Zdecydowało tajne głosowanie" src="https://i.iplsc.com/polityczne-trzesienie-ziemi-na-dolnym-slasku-zdecydowalo-taj/000IIJYZYCT2U40Q-C321.jpg" /></a>Andrzej Jaroch z PiS został odwołany z funkcji przewodniczącego Sejmiku Województwa Dolnośląskiego. Wniosek o odwołanie złożyli radni opozycji z Koalicji Obywatelskiej, Nowej PL oraz Koalicji Samorządowej. Decyzję podjęto w tajnym głosowaniu. Nowym przewodniczącym sejmiku został Jerzy Pokój z KO. </p><br clear="all" />

## Grupa Polsat-Interia numerem jeden w Polsce. Pierwszy raz w historii
 - [https://wydarzenia.interia.pl/kraj/news-grupa-polsat-interia-numerem-jeden-w-polsce-pierwszy-raz-w-h,nId,7305667](https://wydarzenia.interia.pl/kraj/news-grupa-polsat-interia-numerem-jeden-w-polsce-pierwszy-raz-w-h,nId,7305667)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T12:30:32+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-grupa-polsat-interia-numerem-jeden-w-polsce-pierwszy-raz-w-h,nId,7305667"><img align="left" alt="Grupa Polsat-Interia numerem jeden w Polsce. Pierwszy raz w historii" src="https://i.iplsc.com/grupa-polsat-interia-numerem-jeden-w-polsce-pierwszy-raz-w-h/000IIIQ1VMKVR9WV-C321.jpg" /></a>Grupa Polsat-Interia dzięki 21,11 mln użytkownikom (RU) po raz pierwszy w historii została numerem jeden wśród wydawców internetowych w Polsce. Wyprzedziła Grupę Wirtualna Polska (21,03 mln RU) oraz Grupę RAS Polska, wydawcę Onetu (20,97 mln RU). Dane według badań Mediapanelu (styczeń 2024). </p><br clear="all" />

## Zmiana po 50 latach zamrożonych relacji. Watykan zwraca się w nietypowym kierunku
 - [https://wydarzenia.interia.pl/zagranica/news-zmiana-po-50-latach-zamrozonych-relacji-watykan-zwraca-sie-w,nId,7305527](https://wydarzenia.interia.pl/zagranica/news-zmiana-po-50-latach-zamrozonych-relacji-watykan-zwraca-sie-w,nId,7305527)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T11:41:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zmiana-po-50-latach-zamrozonych-relacji-watykan-zwraca-sie-w,nId,7305527"><img align="left" alt="Zmiana po 50 latach zamrożonych relacji. Watykan zwraca się w nietypowym kierunku" src="https://i.iplsc.com/zmiana-po-50-latach-zamrozonych-relacji-watykan-zwraca-sie-w/000IIHV30EXJVR91-C321.jpg" /></a>Kościół katolicki staje się w Wietnamie bardziej widoczny i pozytywnie postrzegany - mówi w wywiadzie z Interią arcybiskup Marek Zalewski, stały papieski wysłannik w Hanoi, który właśnie rozpoczyna swoją misję w Wietnamie. Co Watykan chce załatwić z autorytarnymi władzami? Zalewski przyznaje, że stoi przed nie lada wyzwaniem.</p><br clear="all" />

## Pilne oświadczenie prezydenta. Zwołał Radę Gabinetową
 - [https://wydarzenia.interia.pl/kraj/news-pilne-oswiadczenie-prezydenta-zwolal-rade-gabinetowa,nId,7305419](https://wydarzenia.interia.pl/kraj/news-pilne-oswiadczenie-prezydenta-zwolal-rade-gabinetowa,nId,7305419)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T10:40:08+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pilne-oswiadczenie-prezydenta-zwolal-rade-gabinetowa,nId,7305419"><img align="left" alt="Pilne oświadczenie prezydenta. Zwołał Radę Gabinetową" src="https://i.iplsc.com/pilne-oswiadczenie-prezydenta-zwolal-rade-gabinetowa/000III2QMT8OQN5P-C321.jpg" /></a>- 13 lutego na godzinę 13 zwołuję Radę Gabinetową. To równo dwa miesiące od kiedy nowy rząd objął władzę - oświadczył prezydent. Andrzej Duda podczas dyskusji zamierza rozmawiać o kluczowych inwestycjach infrastrukturalnych &quot;od których zależy rozwój przyszłych pokoleń&quot;. Głowa państwa nawiązała także do swojego podpisu pod ustawą budżetową.</p><br clear="all" />

## Koniec impasu w Brukseli. Wszystkie państwa zgodne
 - [https://wydarzenia.interia.pl/zagranica/news-koniec-impasu-w-brukseli-wszystkie-panstwa-zgodne,nId,7305560](https://wydarzenia.interia.pl/zagranica/news-koniec-impasu-w-brukseli-wszystkie-panstwa-zgodne,nId,7305560)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T10:34:48+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-koniec-impasu-w-brukseli-wszystkie-panstwa-zgodne,nId,7305560"><img align="left" alt="Koniec impasu w Brukseli. Wszystkie państwa zgodne" src="https://i.iplsc.com/koniec-impasu-w-brukseli-wszystkie-panstwa-zgodne/000III1JANHFN4JE-C321.jpg" /></a>Wszystkich 27 przywódców zgodziło się na pakiet wsparcia dla Ukrainy w wysokości 50 mld euro w ramach budżetu UE. Decyzję przekazał szef Rady Europejskiej Charles Michel. &quot;Państwa członkowskie UE po raz kolejny pokazały swoją solidarność i jedność&quot; - przekazał za pośrednictwem mediów społecznościowych premier Ukrainy i podziękował za wsparcie.</p><br clear="all" />

## Deklaracja Donalda Tuska. "Jak PiS będzie chciało, to dostanie"
 - [https://wydarzenia.interia.pl/kraj/news-deklaracja-donalda-tuska-jak-pis-bedzie-chcialo-to-dostanie,nId,7305476](https://wydarzenia.interia.pl/kraj/news-deklaracja-donalda-tuska-jak-pis-bedzie-chcialo-to-dostanie,nId,7305476)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T09:02:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-deklaracja-donalda-tuska-jak-pis-bedzie-chcialo-to-dostanie,nId,7305476"><img align="left" alt="Deklaracja Donalda Tuska. &quot;Jak PiS będzie chciało, to dostanie&quot;" src="https://i.iplsc.com/deklaracja-donalda-tuska-jak-pis-bedzie-chcialo-to-dostanie/000IIGWWSI9OODSY-C321.jpg" /></a>- Nie chcę kilka miesięcy po wygranych wyborach po raz kolejny rozpoczynać wielkiej kampanii (...), ale jak chcą (PiS -red.) to dostaną - powiedział premier w Brukseli. Donald Tusk uznał także deklarację prezydenta o wetowaniu każdej ustawy za &quot;próbę przeszkadzania&quot;. - Źle zaczął swoją kadencję od dewastowania i źle ją kończy - powiedział lider PO. </p><br clear="all" />

## Rosja używa wadliwej broni. Szuka rozwiązania mimo sankcji
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-uzywa-wadliwej-broni-szuka-rozwiazania-mimo-sankcji,nId,7303700](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-uzywa-wadliwej-broni-szuka-rozwiazania-mimo-sankcji,nId,7303700)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T06:58:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-uzywa-wadliwej-broni-szuka-rozwiazania-mimo-sankcji,nId,7303700"><img align="left" alt="Rosja używa wadliwej broni. Szuka rozwiązania mimo sankcji" src="https://i.iplsc.com/rosja-uzywa-wadliwej-broni-szuka-rozwiazania-mimo-sankcji/000IICAB9ISJ9R0S-C321.jpg" /></a>Rosjanie &quot;nie potrafią&quot; w miniaturyzację układów elektronicznych. Problemem jest niska kultura pracy i wykonania, co przy delikatnych produktach mści się znacznie szybciej niż przy topornych urządzeniach mechanicznych. To dlatego ich rakiety są rosyjskie tylko z nazwy. I będą spadać na ukraińskie miasta tak długo, jak długo Zachód nie poradzi sobie z uszczelnieniem reżimu sankcyjnego.</p><br clear="all" />

## Amerykański gwiazdor w tarapatach. Alec Baldwin nie przyznaje się do winy
 - [https://wydarzenia.interia.pl/zagranica/news-amerykanski-gwiazdor-w-tarapatach-alec-baldwin-nie-przyznaje,nId,7305360](https://wydarzenia.interia.pl/zagranica/news-amerykanski-gwiazdor-w-tarapatach-alec-baldwin-nie-przyznaje,nId,7305360)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T06:09:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-amerykanski-gwiazdor-w-tarapatach-alec-baldwin-nie-przyznaje,nId,7305360"><img align="left" alt="Amerykański gwiazdor w tarapatach. Alec Baldwin nie przyznaje się do winy" src="https://i.iplsc.com/amerykanski-gwiazdor-w-tarapatach-alec-baldwin-nie-przyznaje/000IIEHZFTSKIUOW-C321.jpg" /></a>Amerykański aktor Alec Baldwin ponownie nie przyznał się do śmiertelnego postrzelenia operatorki Halyny Hutchins podczas kręcenia filmu &quot;Rust&quot;. Sprawa po kilku miesiącach znów może wrócić na wokandę. Najnowsza ekspertyza wykazała, że artysta musiał nacisnąć spust rewolweru, którego używał na planie, broń nie mogła wypalić samoczynnie.</p><br clear="all" />

## Atak na statek USA. Amerykańskie myśliwce w akcji
 - [https://wydarzenia.interia.pl/zagranica/news-atak-na-statek-usa-amerykanskie-mysliwce-w-akcji,nId,7305362](https://wydarzenia.interia.pl/zagranica/news-atak-na-statek-usa-amerykanskie-mysliwce-w-akcji,nId,7305362)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T06:01:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-atak-na-statek-usa-amerykanskie-mysliwce-w-akcji,nId,7305362"><img align="left" alt="Atak na statek USA. Amerykańskie myśliwce w akcji" src="https://i.iplsc.com/atak-na-statek-usa-amerykanskie-mysliwce-w-akcji/000IIELAHNXONAFA-C321.jpg" /></a>Amerykańskie myśłiwce F-18 zniszczyły w zachodnim Jemenie 10 przygotowywanych do wystrzelenia dronów. Wcześniej Huti zaatakowali rakietami amerykański statek handlowy. Jednostka płynęła w kierunku Izraela.  
</p><br clear="all" />

## Tłum przeciwko prezydentowi . "Maksymalnie napięta" sytuacja
 - [https://wydarzenia.interia.pl/zagranica/news-tlum-przeciwko-prezydentowi-maksymalnie-napieta-sytuacja,nId,7305358](https://wydarzenia.interia.pl/zagranica/news-tlum-przeciwko-prezydentowi-maksymalnie-napieta-sytuacja,nId,7305358)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T05:29:28+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tlum-przeciwko-prezydentowi-maksymalnie-napieta-sytuacja,nId,7305358"><img align="left" alt="Tłum przeciwko prezydentowi . &quot;Maksymalnie napięta&quot; sytuacja " src="https://i.iplsc.com/tlum-przeciwko-prezydentowi-maksymalnie-napieta-sytuacja/000IIEHF62TYBPOA-C321.jpg" /></a>Argentyński parlament proceduje radykalne reformy nowego prezydenta. Zapowiedź cięć świadczeń socjalnych oraz likwidacji dopłat do transportu i energii doprowadziła do protestów. Przeciwnicy zebrali się przed budynkiem Kongresu. Media piszą o &quot;maksymalnie napiętej sytuacji&quot; i użyciu gazu pieprzowego przeciw manifestantom. </p><br clear="all" />

## Chińscy hakerzy "znaczącym" zagrożeniem. Dyrektor FBI ostrzega
 - [https://wydarzenia.interia.pl/zagranica/news-chinscy-hakerzy-znaczacym-zagrozeniem-dyrektor-fbi-ostrzega,nId,7303977](https://wydarzenia.interia.pl/zagranica/news-chinscy-hakerzy-znaczacym-zagrozeniem-dyrektor-fbi-ostrzega,nId,7303977)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2024-02-01T04:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chinscy-hakerzy-znaczacym-zagrozeniem-dyrektor-fbi-ostrzega,nId,7303977"><img align="left" alt="Chińscy hakerzy &quot;znaczącym&quot; zagrożeniem. Dyrektor FBI ostrzega" src="https://i.iplsc.com/chinscy-hakerzy-znaczacym-zagrozeniem-dyrektor-fbi-ostrzega/000AI4QBL1BHI41T-C321.jpg" /></a>Przed chińskimi hakerami przestrzegał w środę w Kongresie dyrektor FBI Christopher Wray. Zgodnie z jego słowami, obierają oni za cel obiekty infrastruktury krytycznej, przygotowując się na to, aby w momencie ewentualnego konfliktu siać spustoszenie i szkodzić amerykańskiej ludności cywilnej. Wray zwracał też uwagę na zagrożenia związane z popularną aplikacją TikTok, wskazując na jej związki z chińskimi władzami.</p><br clear="all" />

