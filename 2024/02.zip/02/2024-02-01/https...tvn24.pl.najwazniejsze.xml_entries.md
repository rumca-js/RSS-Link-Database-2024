# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Biały Dom ogłasza sankcje przeciwko izraelskim osadnikom
 - [https://tvn24.pl/swiat/izrael-palestyna-sankcje-przeciwko-ekstremistycznym-izraelskim-osadnikom-na-zachodnim-brzegu-jest-odpowiedz-benjamina-netanjahu-7753375?source=rss](https://tvn24.pl/swiat/izrael-palestyna-sankcje-przeciwko-ekstremistycznym-izraelskim-osadnikom-na-zachodnim-brzegu-jest-odpowiedz-benjamina-netanjahu-7753375?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T21:57:22+00:00

<img alt="Biały Dom ogłasza sankcje przeciwko izraelskim osadnikom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oofftn-wojska-izraelskie-zajmuja-pozycje-nad-obozem-dla-uchodzcow-balata-na-zachodnim-brzegu-jordanu-7445686/alternates/LANDSCAPE_1280" />
    Objęto nimi czterech obywateli Izraela.

## "Chciałbym was bardzo przeprosić za krzywdę, której doznaliście ze strony państwa polskiego"
 - [https://tvn24.pl/polska/minister-sprawiedliwosci-adam-bodnar-do-osob-lgbt-przepraszam-was-za-krzywde-jakiej-doznaliscie-od-panstwa-polskiego-7753368?source=rss](https://tvn24.pl/polska/minister-sprawiedliwosci-adam-bodnar-do-osob-lgbt-przepraszam-was-za-krzywde-jakiej-doznaliscie-od-panstwa-polskiego-7753368?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T21:44:44+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i47nfd-adam-bodnar-na-spotkaniu-z-organizacjami-dzialajacymi-na-rzecz-osob-lgbt-7753378/alternates/LANDSCAPE_1280" />
    Minister sprawiedliwości Adam Bodnar spotkał się z organizacjami działającymi na rzecz osób LGBT+.

## Nie żyje dwumiesięczna dziewczynka. Zatrzymani rodzice
 - [https://tvn24.pl/bialystok/sokolka-podlaskie-nie-zyje-dwumiesieczne-dziecko-zatrzymano-rodzicow-po-smierci-dziecka-7753380?source=rss](https://tvn24.pl/bialystok/sokolka-podlaskie-nie-zyje-dwumiesieczne-dziecko-zatrzymano-rodzicow-po-smierci-dziecka-7753380?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T21:32:05+00:00

<img alt="Nie żyje dwumiesięczna dziewczynka. Zatrzymani rodzice " src="https://tvn24.pl/najnowsze/cdn-zdjecie-olv9r2-sokolka-7753379/alternates/LANDSCAPE_1280" />
    Policja nie podaje szczegółów.

## Dziesięć zarzutów dla byłej wicewojewody. Miała przywłaszczyć 700 tysięcy złotych
 - [https://tvn24.pl/rzeszow/przemysl-byla-wicewojewoda-podkarpacki-lucyna-p-z-zarzutami-miala-przywlaszczyc-700-tysiecy-zlotych-7753349?source=rss](https://tvn24.pl/rzeszow/przemysl-byla-wicewojewoda-podkarpacki-lucyna-p-z-zarzutami-miala-przywlaszczyc-700-tysiecy-zlotych-7753349?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T21:26:18+00:00

<img alt="Dziesięć zarzutów dla byłej wicewojewody. Miała przywłaszczyć 700 tysięcy złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jqnmoh-prokuratura-7753383/alternates/LANDSCAPE_1280" />
    Informacje o śledztwie przekazała w czwartek rzeczniczka Prokuratury Okręgowej.

## "Spotkaliśmy posłów PiS, którzy dosłownie powiedzieli: wypad stąd. Prezydent Duda wtedy nie protestował"
 - [https://tvn24.pl/go/programy,7/sejm-wita-odcinki,404598/odcinek-151,S00E151,1277867?source=rss](https://tvn24.pl/go/programy,7/sejm-wita-odcinki,404598/odcinek-151,S00E151,1277867?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T20:47:45+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-poh7zi-wit-i-pomaska-7753359/alternates/LANDSCAPE_1280" />
    Rok 2016 kontra 2024, rachunek sumienia oraz siła pytań i bezsilność odpowiedzi.

## Jeszcze nigdy nie widział tylu ofiar wśród cywilów. "Jest wiele sytuacji, gdzie jedynym ocalałym jest dziecko"
 - [https://tvn24.pl/go/programy,7/opinie-i-wydarzenia-odcinki,16593/odcinek-3919,S00E3919,1277860?source=rss](https://tvn24.pl/go/programy,7/opinie-i-wydarzenia-odcinki,16593/odcinek-3919,S00E3919,1277860?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T20:26:54+00:00

<img alt="Jeszcze nigdy nie widział tylu ofiar wśród cywilów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ytii1z-dziecko-w-strefie-gazy-7753325/alternates/LANDSCAPE_1280" />
    Aldo Rodriguez, lekarz z organizacji Lekarze bez Granic, o wojnie w Strefie Gazy.

## Zadzwonił telefon, pan Edward usłyszał, że ciężko chory syn potrzebuje pomocy
 - [https://fakty.tvn24.pl/zobacz-fakty/chcieli-wyludzic-pieniadze-metoda-na-covid-policja-publikuje-wizerunek-kobiety-i-prosi-o-pomoc-st7753280?source=rss](https://fakty.tvn24.pl/zobacz-fakty/chcieli-wyludzic-pieniadze-metoda-na-covid-policja-publikuje-wizerunek-kobiety-i-prosi-o-pomoc-st7753280?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T20:09:08+00:00

<img alt="Zadzwonił telefon, pan Edward usłyszał, że ciężko chory syn potrzebuje pomocy" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-vsp0sg-lapinski-7753284/alternates/LANDSCAPE_1280" />
    Policja ostrzega przez oszustami, którzy wyłudzają pieniądze "na COVID".

## Prezes PiS napisał oświadczenie. Chce "niezależnego od władzy Trybunału Konstytucyjnego"
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-prezes-pis-wydal-oswiadczenie-pisze-o-niezaleznym-trybunale-konstytucyjnym-i-prokuraturze-7753196?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-prezes-pis-wydal-oswiadczenie-pisze-o-niezaleznym-trybunale-konstytucyjnym-i-prokuraturze-7753196?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T20:08:02+00:00

<img alt="Prezes PiS napisał oświadczenie. Chce " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xi0ci7-pap_20240128_13n-1-7753246/alternates/LANDSCAPE_1280" />
    Polityk zarzuca koalicji rządzącej "demontaż niezależnych instytucji".

## "Czuję się trochę winna dzisiejszej sytuacji". Anna Maria Wesołowska pisze o Dariuszu Barskim
 - [https://tvn24.pl/polska/anna-maria-wesolowska-wpis-o-dariuszu-barskim-co-napisala-sedzia-w-stanie-spoczynku-7751714?source=rss](https://tvn24.pl/polska/anna-maria-wesolowska-wpis-o-dariuszu-barskim-co-napisala-sedzia-w-stanie-spoczynku-7751714?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T19:50:51+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j1ps1g-anna-maria-wesolowska-powraca-do-tvn-3154602/alternates/LANDSCAPE_1280" />
    Sędzia w stanie spoczynku opublikowała wpis w mediach społecznościowych.

## Exodus czołowych polityków PiS do Brukseli? "Nagła miłość do Parlamentu Europejskiego"
 - [https://fakty.tvn24.pl/zobacz-fakty/znani-dzialacze-pis-maja-kandydowac-w-eurowyborach-to-na-pewno-nie-zatrzyma-polskich-sluzb-st7753197?source=rss](https://fakty.tvn24.pl/zobacz-fakty/znani-dzialacze-pis-maja-kandydowac-w-eurowyborach-to-na-pewno-nie-zatrzyma-polskich-sluzb-st7753197?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T19:50:00+00:00

<img alt="Exodus czołowych polityków PiS do Brukseli? " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-kf8ere-tracz-7753235/alternates/LANDSCAPE_1280" />
    Według nieoficjalnych informacji kandydować mają między innymi Mariusz Kamiński, Maciej Wąsik, Przemysław Czarnek, Ryszard Terlecki czy Daniel Obajtek.

## Giertych poprosił o kartkę. "To ma taką samą wartość jak to, co napisał pan Święczkowski"
 - [https://tvn24.pl/polska/postanowienie-trybunalu-konstytucyjnego-ws-sedziego-piotra-schaba-roman-giertych-komentuje-7753158?source=rss](https://tvn24.pl/polska/postanowienie-trybunalu-konstytucyjnego-ws-sedziego-piotra-schaba-roman-giertych-komentuje-7753158?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T19:28:50+00:00

<img alt="Giertych poprosił o kartkę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ybhzfy-giertych-fpf-7753240/alternates/LANDSCAPE_1280" />
    Trybunał Konstytucyjny w jednoosobowym składzie wydał postanowienie ws. decyzji ministra sprawiedliwości.

## Transferowa bomba w Formule 1
 - [https://eurosport.tvn24.pl/formula-1/season-2024/2024/lewis-hamilton-w-ferrari.-oficjalne-komunikaty_sto10003881/story.shtml?source=rss](https://eurosport.tvn24.pl/formula-1/season-2024/2024/lewis-hamilton-w-ferrari.-oficjalne-komunikaty_sto10003881/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T19:18:17+00:00

<img alt="Transferowa bomba w Formule 1 " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ym0onn-lewis-hamilton-of-great-britain-and-mercedes-shake-hands-with-p1-during-previews-ahead-of-the-f1-grand-prix-of-saudi-arabia-at-jeddah-corniche-circuit-on-march-16-2023-in-jeddah-7753270/alternates/LANDSCAPE_1280" />
    Koniec plotek.

## Zamrożone rosyjskie aktywa generują miliardy zysków. Unia decyduje, co zrobić z tymi pieniędzmi
 - [https://tvn24.pl/biznes/najnowsze/zamrozone-rosyjskie-aktywa-moga-pomoc-odbudowac-ukraine-st7753167?source=rss](https://tvn24.pl/biznes/najnowsze/zamrozone-rosyjskie-aktywa-moga-pomoc-odbudowac-ukraine-st7753167?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T19:14:55+00:00

<img alt="Zamrożone rosyjskie aktywa generują miliardy zysków. Unia decyduje, co zrobić z tymi pieniędzmi" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-3498zn-ukraina-7752242/alternates/LANDSCAPE_1280" />
    Chodzi o około 300 miliardów euro.

## Zdjęcie, "które znajdzie się w podręcznikach"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2500,S00E2500,1277863?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2500,S00E2500,1277863?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T18:55:19+00:00

<img alt="Zdjęcie, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-70xsev-prezydent-andrzej-duda-w-towarzystwie-mariusza-kaminskiego-i-macieja-wasika-7739154/alternates/LANDSCAPE_1280" />
    Jak Andrzej Duda odnajduje się w nowej politycznej rzeczywistości?

## "Ruchy prezydenta co najmniej dziwne". Decyzja wywołuje "dwa skutki"
 - [https://tvn24.pl/polska/ustawa-budzetowa-2024-decyzja-prezydenta-andrzeja-dudy-przemyslaw-rosati-i-mikolaj-malecki-komentuja-7753049?source=rss](https://tvn24.pl/polska/ustawa-budzetowa-2024-decyzja-prezydenta-andrzeja-dudy-przemyslaw-rosati-i-mikolaj-malecki-komentuja-7753049?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T18:50:34+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2zwaaj-andrzej-duda-7752451/alternates/LANDSCAPE_1280" />
    Dyskusja w programie "Tak jest" po decyzji prezydenta w sprawie budżetu.

## Transfer reprezentanta Polski potwierdzony
 - [https://eurosport.tvn24.pl/pilka-nozna/serie-a/2023-2024/karol-swiderski-transfer.-reprezentant-polski-wraca-do-europy_sto10003806/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/serie-a/2023-2024/karol-swiderski-transfer.-reprezentant-polski-wraca-do-europy_sto10003806/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T18:32:00+00:00

<img alt="Transfer reprezentanta Polski potwierdzony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l4u2tt-karol-swiderski-zagra-w-serie-a-7753163/alternates/LANDSCAPE_1280" />
    Karol Świderski wraca do Europy.

## Nie żyje Maria Zającówna-Radwan
 - [https://tvn24.pl/polska/nie-zyje-maria-zajacowna-radwan-aktorka-starego-teatru-miala-90-lat-7753116?source=rss](https://tvn24.pl/polska/nie-zyje-maria-zajacowna-radwan-aktorka-starego-teatru-miala-90-lat-7753116?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T18:18:43+00:00

<img alt="Nie żyje Maria Zającówna-Radwan" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ysiply-zajac-7753124/alternates/LANDSCAPE_1280" />
    Aktorka Starego Teatru miała 90 lat.

## Miejsce schadzek księcia idzie do remontu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-remont-elizeum-pieniadze-pozwolenie-na-budowe-st7752684?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-remont-elizeum-pieniadze-pozwolenie-na-budowe-st7752684?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T18:15:54+00:00

<img alt="Miejsce schadzek księcia idzie do remontu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-kln6yr-sa-pieniadze-na-ratowanie-elizeum-7752744/alternates/LANDSCAPE_1280" />
    Pieniądze już są, urzędnicy czekają na ostatnią decyzję.

## Klopp: nie chcę odchodzić, ale muszę
 - [https://eurosport.tvn24.pl/pilka-nozna/juergen-klopp-o-swoim-odejsciu-z-liverpoolu_sto10003838/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/juergen-klopp-o-swoim-odejsciu-z-liverpoolu_sto10003838/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T18:15:00+00:00

<img alt="Klopp: nie chcę odchodzić, ale muszę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e4lb6p-juergen-klopp-chce-odejsc-z-liverpoolu-7753132/alternates/LANDSCAPE_1280" />
    Niemiec tłumaczy decyzję o rozstaniu z Liverpoolem.

## Nowacka kontra Tusk w sprawie religii w szkołach. Ministra tłumaczyła się na posiedzeniu rządu
 - [https://tvn24.pl/go/programy,7/wybory-kobiet-odcinki,1172124/odcinek-20,S00E20,1277834?source=rss](https://tvn24.pl/go/programy,7/wybory-kobiet-odcinki,1172124/odcinek-20,S00E20,1277834?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T18:01:00+00:00

<img alt="Nowacka kontra Tusk w sprawie religii w szkołach. Ministra tłumaczyła się na posiedzeniu rządu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ewu4wm-nowacka-i-tusk-dla-go-do-wyborow-kobiet-7752691/alternates/LANDSCAPE_1280" />
    Arleta Zalewska i Aleksandra Pawlicka komentują najnowsze wydarzenia w polityce i rozmawiają z Ewą Zajączkowską-Hernik, rzeczniczką Konfederacji.

## Austin o "diagnozie jak cios" i rozmowie z Bidenem. "Powiedziałem mu, że czuję się winny"
 - [https://tvn24.pl/swiat/usa-szef-pentagonu-trafil-do-szpitala-nie-powiadomil-jednak-prezydenta-lloyd-austin-przeprosil-joe-bidena-7752959?source=rss](https://tvn24.pl/swiat/usa-szef-pentagonu-trafil-do-szpitala-nie-powiadomil-jednak-prezydenta-lloyd-austin-przeprosil-joe-bidena-7752959?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T17:56:41+00:00

<img alt="Austin o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-iwc4a3-pap_20240129_144-7752961/alternates/LANDSCAPE_1280" />
    Sekretarz obrony USA Lloyd Austin na pierwszej konferencji prasowej po wyjściu ze szpitala.

## Polscy bohaterowie Australian Open walczą dla kadry
 - [https://eurosport.tvn24.pl/tenis/puchar-davisa-2024-uzbekistan-polska-plan-gier.-kiedy-i-o-ktorej-zagra-hurkacz-i-zielinski_sto10003438/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/puchar-davisa-2024-uzbekistan-polska-plan-gier.-kiedy-i-o-ktorej-zagra-hurkacz-i-zielinski_sto10003438/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T17:50:00+00:00

<img alt="Polscy bohaterowie Australian Open walczą dla kadry" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bauydd-hubert-hurkacz-chetnie-gra-w-kadrze-polski-7753105/alternates/LANDSCAPE_1280" />
    Hurkacz na pierwszy ogień.

## Wtargnął do fabryki, przetrzymuje zakładników. Policja otoczyła teren
 - [https://tvn24.pl/swiat/turcja-uzbrojony-mezczyzna-wzial-zakladnikow-w-ramach-protestu-przeciwko-atakom-na-gaze-7753058?source=rss](https://tvn24.pl/swiat/turcja-uzbrojony-mezczyzna-wzial-zakladnikow-w-ramach-protestu-przeciwko-atakom-na-gaze-7753058?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T17:42:25+00:00

<img alt="Wtargnął do fabryki, przetrzymuje zakładników. Policja otoczyła teren" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ft946p-turkish-police-surround-area-after-armed-man-takes-pampg-factory-staff-hostage-media-7753034/alternates/LANDSCAPE_1280" />
    Napastnik ma działać "w ramach jawnego protestu przeciwko izraelskim atakom na Gazę".

## Bodnar podjął decyzję w sprawie Schaba, teraz jednoosobowo "zawiesza" ją Trybunał Konstytucyjny
 - [https://tvn24.pl/polska/trybunal-konstytucyjny-wydal-decyzje-w-sprawie-zawieszenia-piotra-schaba-podjal-ja-bogdan-swieczkowski-7752931?source=rss](https://tvn24.pl/polska/trybunal-konstytucyjny-wydal-decyzje-w-sprawie-zawieszenia-piotra-schaba-podjal-ja-bogdan-swieczkowski-7752931?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T17:30:11+00:00

<img alt="Bodnar podjął decyzję w sprawie Schaba, teraz jednoosobowo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t1ed82-piotr-schab-7753037/alternates/LANDSCAPE_1280" />
    Decyzję w tej sprawie podjął Bogdan Święczkowski, były prokurator krajowy i bliski współpracownik Zbigniewa Ziobry.

## Obajtek: NIK nie ma kompetencji, by kontrolować Orlen. Prawnicy: "hazard moralny"
 - [https://konkret24.tvn24.pl/polska/daniel-obajtek-nik-nie-ma-kompetencji-by-kontrolowac-orlen-prawnicy-hazard-moralny-st7752314?source=rss](https://konkret24.tvn24.pl/polska/daniel-obajtek-nik-nie-ma-kompetencji-by-kontrolowac-orlen-prawnicy-hazard-moralny-st7752314?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T17:17:34+00:00

<img alt="Obajtek: NIK nie ma kompetencji, by kontrolować Orlen. Prawnicy: " src="https://tvn24.pl/najnowsze/cdn-zdjecie-w0v23-daniel-obajtek-7752978/alternates/LANDSCAPE_1280" />
    Eksperci tłumaczą, dlaczego Daniel Obajtek "jest w olbrzymim błędzie".

## Unia już zdecydowała. "Należy sobie życzyć, aby Amerykanie szybko się opamiętali"
 - [https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-100,S00E100,1277855?source=rss](https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-100,S00E100,1277855?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T17:11:37+00:00

<img alt="Unia już zdecydowała. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4uyp33-fico-i-orban-7753029/alternates/LANDSCAPE_1280" />
    Unia Europejska przekaże 50 miliardów euro pomocy Ukrainie. Na szczycie UE wszystkie 27 państw głosowało za.

## Nie żyje wicemistrz olimpijski Michel Jazy
 - [https://eurosport.tvn24.pl/lekkoatletyka/michel-jazy-nie-zyje.-francuski-lekkoatleta-polskiego-pochodzenia-mial-87-lat_sto10003512/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/michel-jazy-nie-zyje.-francuski-lekkoatleta-polskiego-pochodzenia-mial-87-lat_sto10003512/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T17:08:00+00:00

<img alt="Nie żyje wicemistrz olimpijski Michel Jazy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pg3l4k-michel-jazy-nie-zyje-7753038/alternates/LANDSCAPE_1280" />
    "Żegnamy wielkiego sportowca i wspaniałego człowieka".

## "Bruksela zdaje się bardzo poirytowana"
 - [https://tvn24.pl/swiat/bruksela-szczyt-rady-europejskiej-viktor-orban-zgodzil-sie-na-wsparcie-ukrainy-komentarz-analityczki-osw-7752950?source=rss](https://tvn24.pl/swiat/bruksela-szczyt-rady-europejskiej-viktor-orban-zgodzil-sie-na-wsparcie-ukrainy-komentarz-analityczki-osw-7752950?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T16:59:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w91m49-viktor-orban-7751728/alternates/LANDSCAPE_1280" />
    Politykom UE udało się przekonać premiera Węgier, by zgodził się na pakiet 50 mld euro wsparcia dla Ukrainy, finansowany z unijnego budżetu.

## Daniel Obajtek kontra ABW
 - [https://tvn24.pl/premium/fuzja-niekontrolowana-daniel-obajtek-kontra-abw-7752856?source=rss](https://tvn24.pl/premium/fuzja-niekontrolowana-daniel-obajtek-kontra-abw-7752856?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T16:53:01+00:00

<img alt="Daniel Obajtek kontra ABW" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yhbeul-pap_20231004_0hf-1-7752910/alternates/LANDSCAPE_1280" />
    W 2021 roku Agencja Bezpieczeństwa Wewnętrznego dwukrotnie składała pisemne uwagi i zastrzeżenia do planów Orlenu w sprawie przejęcia Lotosu i PGNiG. W tym samym roku ABW próbowała wymusić na prezesie PKN Orlen, by poddał się poszerzonej procedurze sprawdzenia pod kątem dostępu do tajemnic państwowych. Daniel Obajtek interweniował w tej sprawie na Nowogrodzkiej.

## Podwyżki pensji w dużej sieci handlowej. Podano wysokość zarobków
 - [https://tvn24.pl/biznes/dla-pracownika/kaufland-o-wzroscie-pensji-pracownikow-podano-wysokosc-zarobkow-na-stanowisku-sprzedawca-kasjer-st7752643?source=rss](https://tvn24.pl/biznes/dla-pracownika/kaufland-o-wzroscie-pensji-pracownikow-podano-wysokosc-zarobkow-na-stanowisku-sprzedawca-kasjer-st7752643?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T16:21:29+00:00

<img alt="Podwyżki pensji w dużej sieci handlowej. Podano wysokość zarobków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o1byi6-kaufland-5126749/alternates/LANDSCAPE_1280" />
    Komunikat.

## Media zapowiadają: wielkie przenosiny w Formule 1
 - [https://eurosport.tvn24.pl/formula-1/media-lewis-hamilton-moze-w-2025-roku-przejsc-z-mercedesa-do-ferrari.-formula-1_sto10003516/story.shtml?source=rss](https://eurosport.tvn24.pl/formula-1/media-lewis-hamilton-moze-w-2025-roku-przejsc-z-mercedesa-do-ferrari.-formula-1_sto10003516/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T15:52:00+00:00

<img alt="Media zapowiadają: wielkie przenosiny w Formule 1" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ondcn9-lewis-hamilton-7752921/alternates/LANDSCAPE_1280" />
    Lewis Hamilton ma odejść z Mercedesa.

## Nowa rzeczywistość medalisty olimpijskiego
 - [https://eurosport.tvn24.pl/narciarstwo-alpejskie/wengen/2023-2024/aleksander-aamodt-kilde-zapowiedzial-chec-powrotu-ale-ma-obawy-o-forme.-co-powiedzial_sto10003414/story.shtml?source=rss](https://eurosport.tvn24.pl/narciarstwo-alpejskie/wengen/2023-2024/aleksander-aamodt-kilde-zapowiedzial-chec-powrotu-ale-ma-obawy-o-forme.-co-powiedzial_sto10003414/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T15:33:00+00:00

<img alt="Nowa rzeczywistość medalisty olimpijskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p4g53w-kilde-ulegl-powaznemu-wypadkowi-7752890/alternates/LANDSCAPE_1280" />
    Po poważnym upadku.

## Prezydent chce Rady Gabinetowej. Tusk odpowiada
 - [https://tvn24.pl/polska/premier-donald-tusk-oczywiscie-przyjdziemy-na-zaproszenie-czy-na-wezwanie-pana-prezydenta-7752832?source=rss](https://tvn24.pl/polska/premier-donald-tusk-oczywiscie-przyjdziemy-na-zaproszenie-czy-na-wezwanie-pana-prezydenta-7752832?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T15:29:33+00:00

<img alt="Prezydent chce Rady Gabinetowej. Tusk odpowiada " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ulhusb-01-1435-tlumacz-zd-0009-7752826/alternates/LANDSCAPE_1280" />
    Andrzej Duda zapowiedział zwołanie Rady Gabinetowej.

## Tusk: zdarzyły się dwie bardzo ważne rzeczy
 - [https://tvn24.pl/polska/donald-tusk-po-nadzwyczajnym-szczycie-unii-europejskiej-o-wsparciu-dla-ukrainy-i-jednosci-ue-7752734?source=rss](https://tvn24.pl/polska/donald-tusk-po-nadzwyczajnym-szczycie-unii-europejskiej-o-wsparciu-dla-ukrainy-i-jednosci-ue-7752734?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T15:23:14+00:00

<img alt="Tusk: zdarzyły się dwie bardzo ważne rzeczy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3ev9f-donald-tusk-7752854/alternates/LANDSCAPE_1280" />
    Konferencja szefa rządu.

## "Psuedopotęga". Premier komentuje odwołanie Obajtka
 - [https://tvn24.pl/biznes/z-kraju/daniel-obajtek-odwolany-premier-donald-tusk-o-odwolaniu-prezesa-orlenu-st7752808?source=rss](https://tvn24.pl/biznes/z-kraju/daniel-obajtek-odwolany-premier-donald-tusk-o-odwolaniu-prezesa-orlenu-st7752808?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T15:16:13+00:00

<img alt="" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-2luwi0-daniel-obajtek-7752815/alternates/LANDSCAPE_1280" />
    Prezes Orlenu odchodzi ze spółki.

## Ciało Blanki znaleźli w łóżeczku, było owinięte w koc. Jej matka ponownie stanęła przed sądem
 - [https://tvn24.pl/bialystok/olecko-bialystok-cialo-blanki-znalezli-w-lozeczku-bylo-owiniete-w-koc-matka-uslyszala-zarzuty-i-zostala-skazana-ruszyl-proces-apelacyjny-7752766?source=rss](https://tvn24.pl/bialystok/olecko-bialystok-cialo-blanki-znalezli-w-lozeczku-bylo-owiniete-w-koc-matka-uslyszala-zarzuty-i-zostala-skazana-ruszyl-proces-apelacyjny-7752766?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T14:58:41+00:00

<img alt="Ciało Blanki znaleźli w łóżeczku, było owinięte w koc. Jej matka ponownie stanęła przed sądem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5xrvr8-oskarzona-anna-w-w-sadzie-okregowym-w-suwalkach-6805815/alternates/LANDSCAPE_1280" />
    Została skazana na 25 lat więzienia, ale prokurator chce dożywocia.

## "Wiecie, że wasz produkt jest katastrofą dla nastolatków"
 - [https://tvn24.pl/swiat/usa-przesluchanie-marka-zuckerberga-przed-senatem-usa-pytania-o-wewnetrzny-raport-mety-7752403?source=rss](https://tvn24.pl/swiat/usa-przesluchanie-marka-zuckerberga-przed-senatem-usa-pytania-o-wewnetrzny-raport-mety-7752403?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T14:57:01+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qtd831-mark-zuckerberg-w-senacie-usa-7752504/alternates/LANDSCAPE_1280" />
    Polityk przypomina Zuckerbergowi wewnętrzny raport dotyczący Instagrama.

## Przyszedł na działkę, w oczku wodnym znalazł ciało kolegi
 - [https://tvn24.pl/lodz/zdunska-wola-przyszedl-na-dzialke-w-oczku-wodnym-lezalo-cialo-jego-kolegi-7752804?source=rss](https://tvn24.pl/lodz/zdunska-wola-przyszedl-na-dzialke-w-oczku-wodnym-lezalo-cialo-jego-kolegi-7752804?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T14:53:45+00:00

<img alt="Przyszedł na działkę, w oczku wodnym znalazł ciało kolegi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8mopjm-74-latek-utopil-sie-w-oczku-wodnym-7752760/alternates/LANDSCAPE_1280" />
    W Zduńskiej Woli (woj. łódzkie).

## "Opcja atomowa" czy indywidualne lustracje? Problem ma ponad dwa tysiące osób
 - [https://tvn24.pl/premium/co-czeka-neosedziow-degradacja-z-automatu-czy-indywidualna-lustracja-7751810?source=rss](https://tvn24.pl/premium/co-czeka-neosedziow-degradacja-z-automatu-czy-indywidualna-lustracja-7751810?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T14:25:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uczs4d-adobestock_611102726-7752320/alternates/LANDSCAPE_1280" />
    Sędziowie kombatanci z "Iustitii" naciskają na ministra Adama Bodnara, żeby podjął problem ponad 2 tysięcy neosędziów. Na razie resort sprawiedliwości stara się nie antagonizować prezydenta Dudy, który zapowiedział, że nie pozwoli kwestionować ich statusu. Priorytetem jest odpolitycznienie KRS, "matki wszystkich grzechów" w sporze o praworządność. Ale w środowisku prawniczym mówi się też, że propozycje "Iustitii" są nierealne i nie do zaakceptowania przez Komisję Europejską. I że dobrego rozwiązania kwestii neosędziów nie ma.

## Reprezentacje tego kraju mają zakaz rywalizacji z Rosją i Białorusią
 - [https://eurosport.tvn24.pl/wszystkie-sporty/lotwa-zakazala-swoim-reprezentantom-rywalizacji-ze-sportowcami-z-rosji-i-bialorusi_sto10003253/story.shtml?source=rss](https://eurosport.tvn24.pl/wszystkie-sporty/lotwa-zakazala-swoim-reprezentantom-rywalizacji-ze-sportowcami-z-rosji-i-bialorusi_sto10003253/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T14:22:00+00:00

<img alt="Reprezentacje tego kraju mają zakaz rywalizacji z Rosją i Białorusią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u20vw7-russian-supporters-7752751/alternates/LANDSCAPE_1280" />
    W czwartek przyjęto nowelizację ustawy.

## Polsko-amerykańskie porozumienie w zakresie lotnictwa
 - [https://tvn24.pl/biznes/z-kraju/usa-polska-polsko-amerykanskie-porozumienie-w-zakresie-ochrony-lotnictwa-cywilnego-komunikat-urzedu-lotnictwa-cywilnego-st7752563?source=rss](https://tvn24.pl/biznes/z-kraju/usa-polska-polsko-amerykanskie-porozumienie-w-zakresie-ochrony-lotnictwa-cywilnego-komunikat-urzedu-lotnictwa-cywilnego-st7752563?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T14:10:29+00:00

<img alt="Polsko-amerykańskie porozumienie w zakresie lotnictwa" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-xqqajr-mark-brzezinski-piotr-samson-7752601/alternates/LANDSCAPE_1280" />
    Podpisano dokument.

## Dyrektor zwolniony przez prezesa tuż przed spotkaniem z posłem. Interwencja policji
 - [https://tvn24.pl/bialystok/suwalki-goraco-w-spolce-komunikacyjnej-podczas-interwencji-poselskiej-wezwana-zostala-policja-7752572?source=rss](https://tvn24.pl/bialystok/suwalki-goraco-w-spolce-komunikacyjnej-podczas-interwencji-poselskiej-wezwana-zostala-policja-7752572?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T14:07:45+00:00

<img alt="Dyrektor zwolniony przez prezesa tuż przed spotkaniem z posłem. Interwencja policji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s3oklx-posel-byl-tez-na-spotkaniu-z-pracownikami-7752119/alternates/LANDSCAPE_1280" />
    Poseł KO Jacek Niedźwiedzki wezwał policję do oddziału spółki PKS Nova w Suwałkach (woj. podlaskie).

## Sondaż prezydencki. Jeden polityk z rekordowym wzrostem poparcia
 - [https://tvn24.pl/polska/sondaz-prezydencki-jeden-polityk-z-rekordowym-wzrostem-poparcia-7752544?source=rss](https://tvn24.pl/polska/sondaz-prezydencki-jeden-polityk-z-rekordowym-wzrostem-poparcia-7752544?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T13:52:38+00:00

<img alt="Sondaż prezydencki. Jeden polityk z rekordowym wzrostem poparcia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t0lpuz-skl-7752575/alternates/LANDSCAPE_1280" />
    Badanie IBRIS.

## Zalane i odcięte od świata domy
 - [https://tvn24.pl/tvnwarszawa/okolice/mazowsze-wysoki-poziom-bugu-i-podtopienia-eksperci-tlumacza-jak-temu-zapobiegac-st7751920?source=rss](https://tvn24.pl/tvnwarszawa/okolice/mazowsze-wysoki-poziom-bugu-i-podtopienia-eksperci-tlumacza-jak-temu-zapobiegac-st7751920?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T13:45:17+00:00

<img alt="Zalane i odcięte od świata domy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mv6g57-wysoki-poziom-na-bugu-7751912/alternates/LANDSCAPE_1280" />
    Trudna sytuacja na Bugu. Część osób decyduje się na nocowanie u bliskich.

## W cienkiej bluzce, tunice i letnich butach błąkała się w nocy po mieście
 - [https://tvn24.pl/kujawsko-pomorskie/torun-76-latka-blakala-sie-po-miescie-miala-na-sobie-cienka-bluzke-tunike-i-letnie-buty-nagranie-7752551?source=rss](https://tvn24.pl/kujawsko-pomorskie/torun-76-latka-blakala-sie-po-miescie-miala-na-sobie-cienka-bluzke-tunike-i-letnie-buty-nagranie-7752551?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T13:40:01+00:00

<img alt="W cienkiej bluzce, tunice i letnich butach błąkała się w nocy po mieście" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5gidke-policjanci-odnalezli-zziebnieta-i-zdezorientowana-zaginiona-kobiete-7752538/alternates/LANDSCAPE_1280" />
    Gdy ją znaleźli, kobieta była zziębnięta i zdezorientowana.

## Oszczędności Orbana poniżej średniej? Media komentują
 - [https://tvn24.pl/biznes/ze-swiata/oszczednosci-premiera-viktora-orbana-wegierskie-media-komentuja-st7752073?source=rss](https://tvn24.pl/biznes/ze-swiata/oszczednosci-premiera-viktora-orbana-wegierskie-media-komentuja-st7752073?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T13:40:00+00:00

<img alt="Oszczędności Orbana poniżej średniej? Media komentują" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vbj4fr-pap_20231214_077-7746452/alternates/LANDSCAPE_1280" />
    Analiza oświadczenia majątkowego premiera Węgier.

## Podwyżki dla nauczycieli później niż zakładano? "Może się tak zdarzyć"
 - [https://tvn24.pl/polska/podwyzki-dla-nauczycieli-kiedy-barbara-nowacka-o-mozliwym-opoznieniu-7752516?source=rss](https://tvn24.pl/polska/podwyzki-dla-nauczycieli-kiedy-barbara-nowacka-o-mozliwym-opoznieniu-7752516?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T13:31:52+00:00

<img alt="Podwyżki dla nauczycieli później niż zakładano? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t88t92-barbara-nowacka-7752554/alternates/LANDSCAPE_1280" />
    Ministra Nowacka tłumaczy.

## "Dzisiaj chce wspierać, wczoraj chciał z prezesem Kaczyńskim podpalać"
 - [https://tvn24.pl/polska/prezydent-andrzej-duda-wydaje-oswiadczenie-rada-gabinetowa-13-lutego-komentarze-politykow-7752321?source=rss](https://tvn24.pl/polska/prezydent-andrzej-duda-wydaje-oswiadczenie-rada-gabinetowa-13-lutego-komentarze-politykow-7752321?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T13:25:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2zwaaj-andrzej-duda-7752451/alternates/LANDSCAPE_1280" />
    Komentarze polityków po zapowiedzi zwołania Rady Gabinetowej przez Andrzeja Dudę.

## Iwanowiec zatonął po "serii bezpośrednich trafień". Ukraińcy pokazują nagranie
 - [https://tvn24.pl/swiat/ukraina-rosyjska-korweta-rakietowa-iwanowiec-zatopiona-ukraincy-pokazali-nagranie-7752511?source=rss](https://tvn24.pl/swiat/ukraina-rosyjska-korweta-rakietowa-iwanowiec-zatopiona-ukraincy-pokazali-nagranie-7752511?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T13:19:13+00:00

<img alt="Iwanowiec zatonął po " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1z0see-iwanowiec-sklej-7752527/alternates/LANDSCAPE_1280" />
    "Wrogi okręt patrolował Morze Czarne".

## Rekordowe wyniki. Dziękujemy widzom TVN24 i "Faktów" TVN oraz czytelnikom tvn24.pl
 - [https://tvn24.pl/biznes/z-kraju/tvn24-fakty-tvn-tvn24pl-wyniki-ogladalnosci-w-styczniu-2024-st7752461?source=rss](https://tvn24.pl/biznes/z-kraju/tvn24-fakty-tvn-tvn24pl-wyniki-ogladalnosci-w-styczniu-2024-st7752461?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T13:14:29+00:00

<img alt="Rekordowe wyniki. Dziękujemy widzom TVN24 i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lqtuje-tvn-5510678/alternates/LANDSCAPE_1280" />
    Dane za styczeń 2024.

## Kierowca ciężarówki migał długimi światłami, tak wzywał pomocy
 - [https://tvn24.pl/kielce/kieleckie-kierowca-ciezarowki-swiatlami-wolal-o-pomoc-trafil-do-szpitala-z-podejrzeniem-zawalu-7752276?source=rss](https://tvn24.pl/kielce/kieleckie-kierowca-ciezarowki-swiatlami-wolal-o-pomoc-trafil-do-szpitala-z-podejrzeniem-zawalu-7752276?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T12:50:27+00:00

<img alt="Kierowca ciężarówki migał długimi światłami, tak wzywał pomocy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tg5oui-policja-7737650/alternates/LANDSCAPE_1280" />
    Trafił do szpitala z podejrzeniem zawału serca.

## "Koniec ery", "początek prawdziwych problemów"
 - [https://tvn24.pl/polska/daniel-obajtek-prezes-orlenu-odwolany-politycy-komentuja-7752427?source=rss](https://tvn24.pl/polska/daniel-obajtek-prezes-orlenu-odwolany-politycy-komentuja-7752427?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T12:43:16+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mqh8y0-daniel-obajtek-7752435/alternates/LANDSCAPE_1280" />
    Politycy o odwołaniu Obajtka.

## Goss na konferencji Orlenu. W jakim charakterze? "Gościa, a bo co? Odejdź młodzieńcze"
 - [https://tvn24.pl/biznes/z-kraju/daniel-obajtek-odwolany-ze-stanowiska-prezesa-orlenu-jasinski-i-waksmundzka-olejniczak-komentuja-st7752378?source=rss](https://tvn24.pl/biznes/z-kraju/daniel-obajtek-odwolany-ze-stanowiska-prezesa-orlenu-jasinski-i-waksmundzka-olejniczak-komentuja-st7752378?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T12:38:45+00:00

<img alt="Goss na konferencji Orlenu. W jakim charakterze? " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-77z9w3-daniel-obajtek-odwolany-z-zarzadu-orlenu-janina-goss-i-wojciech-jasinski-rozmawiaja-z-reporterem-tvn24-7752476/alternates/LANDSCAPE_1280" />
    Reporter TVN24 pyta, "szara eminencja" odpowiada.

## "Polityczna bomba". Ukryta kamera nagrała pierwszą damę
 - [https://tvn24.pl/swiat/korea-poludniowa-pierwsza-dama-przyjela-drogi-prezent-wywolala-skandal-7752047?source=rss](https://tvn24.pl/swiat/korea-poludniowa-pierwsza-dama-przyjela-drogi-prezent-wywolala-skandal-7752047?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T12:38:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yk0g6m-kim-keon-hee-7752401/alternates/LANDSCAPE_1280" />
    Sprawa torebki żony prezydenta może odbić się na wynikach wyborów parlamentarnych.

## Jazda pod prąd trasą S5 zakończona tragedią
 - [https://tvn24.pl/poznan/koscian-s5-czolowe-zderzenie-dwoch-samochodow-jedna-osoba-nie-zyje-7752455?source=rss](https://tvn24.pl/poznan/koscian-s5-czolowe-zderzenie-dwoch-samochodow-jedna-osoba-nie-zyje-7752455?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T12:33:57+00:00

<img alt="Jazda pod prąd trasą S5 zakończona tragedią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m0bmeu-w-wypadku-zginela-jedna-osoba-7752449/alternates/LANDSCAPE_1280" />
    Między węzłami Czempiń i Kościan Północ (Wielkopolskie).

## Adele wraca z koncertami. Pierwsze takie występy od ośmiu lat
 - [https://tvn24.pl/kultura-i-styl/adele-zagra-w-kontynentalnej-europie-cztery-koncerty-w-sierpniu-w-monachium-7752364?source=rss](https://tvn24.pl/kultura-i-styl/adele-zagra-w-kontynentalnej-europie-cztery-koncerty-w-sierpniu-w-monachium-7752364?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T12:21:15+00:00

<img alt="Adele wraca z koncertami. Pierwsze takie występy od ośmiu lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9l64dk-adele-na-rozdaniu-nagrod-brit-awards-2022-shutterstock2120521604-6184036/alternates/LANDSCAPE_1280" />
    "Nie grałam w Europie od 2016 roku!".

## Znany z krytyki Władimira Putina zespół uniknął deportacji do Rosji
 - [https://tvn24.pl/swiat/tajlandia-zatrzymanie-zespolu-bi-2-muzycy-polecieli-do-izraela-grozila-im-deportacja-do-rosji-7752191?source=rss](https://tvn24.pl/swiat/tajlandia-zatrzymanie-zespolu-bi-2-muzycy-polecieli-do-izraela-grozila-im-deportacja-do-rosji-7752191?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T11:56:57+00:00

<img alt="Znany z krytyki Władimira Putina zespół uniknął deportacji do Rosji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qnrvb9-czlonkowie-bi-2-aresztowani-w-tajlandii-grozi-im-deportacja-do-rosji-7749394/alternates/LANDSCAPE_1280" />
    Po tygodniu spędzonym w "potwornych" warunkach.

## 14-latek i jego 10-letnia siostra po szkole nie wrócili do domu. Znaleźli się w Niemczech
 - [https://tvn24.pl/opole/nysa-opole-wroclaw-dzieci-nie-wrocily-ze-szkoly-i-nie-odbieraly-telefonow-odnaleziono-je-na-terenie-niemiec-7752307?source=rss](https://tvn24.pl/opole/nysa-opole-wroclaw-dzieci-nie-wrocily-ze-szkoly-i-nie-odbieraly-telefonow-odnaleziono-je-na-terenie-niemiec-7752307?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T11:30:05+00:00

<img alt="14-latek i jego 10-letnia siostra po szkole nie wrócili do domu. Znaleźli się w Niemczech" src="https://tvn24.pl/najnowsze/cdn-zdjecie-plrvr2-dzieci-zostaly-odnalezione-w-niemieckim-gorlitz-7752289/alternates/LANDSCAPE_1280" />
    Akcję poszukiwawczą prowadzili funkcjonariusze z Nysy, Opola, Wrocławia i Görlitz.

## "Dobry czwartek". Tusk o dwóch sprawach naraz
 - [https://tvn24.pl/polska/donald-tusk-wpis-o-obajtku-i-orbanie-7752251?source=rss](https://tvn24.pl/polska/donald-tusk-wpis-o-obajtku-i-orbanie-7752251?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T11:09:21+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jc8i6b-tusk-7752257/alternates/LANDSCAPE_1280" />
    Premier pisze z Brukseli.

## Nowe informacje o stanie zdrowia Zbigniewa Ziobry. "Nie bagatelizujmy objawów"
 - [https://tvn24.pl/polska/zbigniew-ziobro-walczy-z-nowotworem-nowe-informacje-o-stanie-zdrowia-przekazal-michal-wojcik-7752023?source=rss](https://tvn24.pl/polska/zbigniew-ziobro-walczy-z-nowotworem-nowe-informacje-o-stanie-zdrowia-przekazal-michal-wojcik-7752023?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T10:55:05+00:00

<img alt="Nowe informacje o stanie zdrowia Zbigniewa Ziobry. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-36bk30-kampania-wyborcza-do-parlamentu-2023-minister-sprawiedliwosci-zbigniew-ziobro-w-toruniu-7682997/alternates/LANDSCAPE_1280" />
    Były minister sprawiedliwości od dwóch miesięcy nie pojawia się publicznie.

## 11-latka nie mogła wejść do domu, bała się o swoją mamę. Poprosiła o pomoc
 - [https://tvn24.pl/lubuskie/swiebodzin-11-latka-nie-mogla-wejsc-do-domu-i-bala-sie-o-swoja-mame-pomogla-policja-7752209?source=rss](https://tvn24.pl/lubuskie/swiebodzin-11-latka-nie-mogla-wejsc-do-domu-i-bala-sie-o-swoja-mame-pomogla-policja-7752209?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T10:48:08+00:00

<img alt="11-latka nie mogła wejść do domu, bała się o swoją mamę. Poprosiła o pomoc" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2vitdp-11-latka-poprosila-o-pomoc-policjantow-7752082/alternates/LANDSCAPE_1280" />
    W Świebodzinie (woj. lubuskie). Nagranie.

## Prezydent: Rada Gabinetowa 13 lutego
 - [https://tvn24.pl/polska/prezydent-andrzej-duda-zwolam-rade-gabinetowa-13-lutego-7752216?source=rss](https://tvn24.pl/polska/prezydent-andrzej-duda-zwolam-rade-gabinetowa-13-lutego-7752216?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T10:45:40+00:00

<img alt="Prezydent: Rada Gabinetowa 13 lutego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1or25u-01-1100-duda-0015-7752212/alternates/LANDSCAPE_1280" />
    Poinformował na konferencji prasowej.

## Gwałtowna reakcja giełdy na decyzję o odwołaniu Daniela Obajtka
 - [https://tvn24.pl/biznes/rynki/orlen-na-gpw-po-odwolaniu-daniela-obajtka-st7752136?source=rss](https://tvn24.pl/biznes/rynki/orlen-na-gpw-po-odwolaniu-daniela-obajtka-st7752136?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T10:30:47+00:00

<img alt="Gwałtowna reakcja giełdy na decyzję o odwołaniu Daniela Obajtka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-piq3nu-orlen-shutterstock717185098-6178601/alternates/LANDSCAPE_1280" />
    Zmiana kursu akcji Orlenu.

## Gwałtowna reakcja giełdy po odwołaniu Obajtka
 - [https://tvn24.pl/biznes/rynki/gpw-notowania-orlenu-po-odwolaniu-daniela-obajtka-st7752136?source=rss](https://tvn24.pl/biznes/rynki/gpw-notowania-orlenu-po-odwolaniu-daniela-obajtka-st7752136?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T10:30:47+00:00

<img alt="Gwałtowna reakcja giełdy po odwołaniu Obajtka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6sgd87-forum-0426938567-7753061/alternates/LANDSCAPE_1280" />
    Komentarz analityka.

## Hokeiści NHL oskarżeni o napaść na tle seksualnym. Niedługo wcześniej odebrali złote medale
 - [https://eurosport.tvn24.pl/hokej-na-lodzie/nhl/2023-2024/kanadyjscy-hokeisci-nhl-oskarzeni-o-zbiorowa-napasc-na-tle-seksualnym_sto10002013/story.shtml?source=rss](https://eurosport.tvn24.pl/hokej-na-lodzie/nhl/2023-2024/kanadyjscy-hokeisci-nhl-oskarzeni-o-zbiorowa-napasc-na-tle-seksualnym_sto10002013/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T10:13:37+00:00

<img alt="Hokeiści NHL oskarżeni o napaść na tle seksualnym. Niedługo wcześniej odebrali złote medale" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eil3vn-cal-foote-w-meczu-nhl-7752155/alternates/LANDSCAPE_1280" />
    Przebywali na mistrzostwach świata juniorów.

## F-18 w akcji. Jemeńscy rebelianci ponieśli duże straty
 - [https://tvn24.pl/swiat/udana-akcja-lotnictwa-usa-jemenscy-rebelianci-poniesli-duze-straty-7751785?source=rss](https://tvn24.pl/swiat/udana-akcja-lotnictwa-usa-jemenscy-rebelianci-poniesli-duze-straty-7751785?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T10:11:23+00:00

<img alt="F-18 w akcji. Jemeńscy rebelianci ponieśli duże straty" src="https://tvn24.pl/najnowsze/cdn-zdjecied41d8cd98f00b204e9800998ecf8427e-amerykanski-mysliwiec-wielozadaniowy-f-18-super-hornet-3883051/alternates/LANDSCAPE_1280" />
    Komunikat Centralnego Dowództwa sił USA.

## Jak "wójt czekoladka" zrobił zawrotną karierę
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-940,S00E940,461792?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-940,S00E940,461792?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T10:10:00+00:00

<img alt="Jak " src="https://tvn24.pl/najnowsze/cdn-zdjecie-h0yle4-daniel-obajtek-5024775/alternates/LANDSCAPE_1280" />
    Przypominamy reportaż Łukasza Karusty.

## Trener Barcelony wymaga więcej od Lewandowskiego
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/xavi-hernandez-o-robercie-lewandowskim-po-meczu-fc-barcelona-osasuna-la-liga_sto10002949/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/xavi-hernandez-o-robercie-lewandowskim-po-meczu-fc-barcelona-osasuna-la-liga_sto10002949/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T09:55:14+00:00

<img alt="Trener Barcelony wymaga więcej od Lewandowskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-snvuda-xavi-chce-wiecej-od-lewandowskiego-7752095/alternates/LANDSCAPE_1280" />
    Xavi Hernandez o polskim napastniku po meczu z Osasuną.

## 150 dni po wyborach? Niezwłocznie? Kiedy prezydent ma powołać nowych członków PKW
 - [https://konkret24.tvn24.pl/polityka/panstwowa-komisja-wyborcza-150-dni-po-wyborach-niezwlocznie-kiedy-prezydent-ma-powolac-nowych-czlonkow-st7750705?source=rss](https://konkret24.tvn24.pl/polityka/panstwowa-komisja-wyborcza-150-dni-po-wyborach-niezwlocznie-kiedy-prezydent-ma-powolac-nowych-czlonkow-st7750705?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T09:16:10+00:00

<img alt="150 dni po wyborach? Niezwłocznie? Kiedy prezydent ma powołać nowych członków PKW " src="https://konkret24.tvn24.pl/najnowsze/cdn-zdjecie-83qo2r-prezydent-andrzej-duda-31-stycznia-2024-7752018/alternates/LANDSCAPE_1280" />
    Sejm już wybrał nowych członków Państwowej Komisji Wyborczej, lecz prezydent ich wciąż nie powołał.

## "The Economist": co, u licha, dzieje się w Polsce?
 - [https://tvn24.pl/swiat/the-economist-o-sytuacji-w-polsce-co-sie-u-licha-dzieje-7751723?source=rss](https://tvn24.pl/swiat/the-economist-o-sytuacji-w-polsce-co-sie-u-licha-dzieje-7751723?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T08:25:19+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-el9d1t-poslowie-pis-oraz-czlonkowie-rzadu-na-sali-obrad-sejmu-w-warszawie-7726265/alternates/LANDSCAPE_1280" />
    Brytyjski dziennik komentuje sytuację nad Wisłą.

## Słabe dane z polskiego przemysłu. "Największe spadki produkcji i zamówień od trzech miesięcy"
 - [https://tvn24.pl/biznes/z-kraju/najnowsze-dane-z-przemyslu-wskaznik-pmi-styczen-2024-st7751861?source=rss](https://tvn24.pl/biznes/z-kraju/najnowsze-dane-z-przemyslu-wskaznik-pmi-styczen-2024-st7751861?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T08:22:25+00:00

<img alt="Słabe dane z polskiego przemysłu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-388kzq-fabryka-przemysl-shutterstock761907061-5772063/alternates/LANDSCAPE_1280" />
    Wskaźnik PMI dla przemysłu w Polsce w styczniu 2024 roku.

## Ewa Zajączkowska-Hernik w podcaście "Wybory kobiet". Kim jest rzeczniczka Konfederacji
 - [https://tvn24.pl/polska/ewa-zajaczkowska-hernik-kim-jest-rzeczniczka-konfederacji-gosciem-podcastu-wybory-kobiet-7750523?source=rss](https://tvn24.pl/polska/ewa-zajaczkowska-hernik-kim-jest-rzeczniczka-konfederacji-gosciem-podcastu-wybory-kobiet-7750523?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T08:01:31+00:00

<img alt="Ewa Zajączkowska-Hernik w podcaście " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2pwa1z-ewa-zajaczkowska-hernik-7750990/alternates/LANDSCAPE_1280" />
    W przeszłości nieraz było o niej głośno.

## Atak na ważne lotnisko Rosjan na Krymie. Nagranie
 - [https://tvn24.pl/swiat/ukraina-atak-na-lotnisko-belbek-na-krymie-mykola-oleszczuk-publikuje-nagranie-7751792?source=rss](https://tvn24.pl/swiat/ukraina-atak-na-lotnisko-belbek-na-krymie-mykola-oleszczuk-publikuje-nagranie-7751792?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T07:47:52+00:00

<img alt="Atak na ważne lotnisko Rosjan na Krymie. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ew925q-lotnisko-belbek-7751793/alternates/LANDSCAPE_1280" />
    "Ukraińscy lotnicy na pewno tam wrócą".

## Nowy nabytek Haalanda. Luksus za siedem milionów euro
 - [https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/erling-haaland-kupil-nowy-samolot.-luksusowa-maszyna-kosztowala-ok.-siedmiu-milionow-euro_sto10002920/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/premier-league/2023-2024/erling-haaland-kupil-nowy-samolot.-luksusowa-maszyna-kosztowala-ok.-siedmiu-milionow-euro_sto10002920/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T06:49:18+00:00

<img alt="Nowy nabytek Haalanda. Luksus za siedem milionów euro" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2p6mi9-erling-haaland-kupil-nowy-samolot-7751801/alternates/LANDSCAPE_1280" />
    Norweski napastnik postawił na wygodę.

## Obajtek o swojej przyszłości
 - [https://tvn24.pl/biznes/z-kraju/daniel-obajtek-daje-sobie-miesiac-na-zastanowienie-co-bede-robil-st7751770?source=rss](https://tvn24.pl/biznes/z-kraju/daniel-obajtek-daje-sobie-miesiac-na-zastanowienie-co-bede-robil-st7751770?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T06:30:27+00:00

<img alt="Obajtek o swojej przyszłości" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fkuati-daniel-obajtek-7750031/alternates/LANDSCAPE_1280" />
    W rozmowie z "Pulsem Biznesu".

## Rusza nabór wniosków o 800 plus
 - [https://tvn24.pl/biznes/pieniadze/800-plus-wnioski-o-swiadczenie-1-lutego-rusza-nabor-st7751736?source=rss](https://tvn24.pl/biznes/pieniadze/800-plus-wnioski-o-swiadczenie-1-lutego-rusza-nabor-st7751736?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T05:56:28+00:00

<img alt="Rusza nabór wniosków o 800 plus" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie095ad20619b952fe46641a3bdc8910f9-program-rodzina-500-plus-ruszyl-1-kwietnia-br-4263109/alternates/LANDSCAPE_1280" />
    Na nowy okres rozliczeniowy.

## ONZ: Strefa Gazy obecnie nie nadaje się do zamieszkania
 - [https://tvn24.pl/swiat/strefa-gazy-raport-onz-o-sytuacji-humanitarnej-7751707?source=rss](https://tvn24.pl/swiat/strefa-gazy-raport-onz-o-sytuacji-humanitarnej-7751707?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T05:54:30+00:00

<img alt="ONZ: Strefa Gazy obecnie nie nadaje się do zamieszkania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kd81pi-strefa-gazy-17012024-7751739/alternates/LANDSCAPE_1280" />
    Raport Konferencji Narodów Zjednoczonych ds. Handlu i Rozwoju (UNCTAD).

## Emerytury stażowe. Jest kolejny projekt w Sejmie
 - [https://tvn24.pl/biznes/dla-seniora/emerytury-stazowe-poselski-projekt-lewicy-w-sejmie-st7751738?source=rss](https://tvn24.pl/biznes/dla-seniora/emerytury-stazowe-poselski-projekt-lewicy-w-sejmie-st7751738?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T05:51:59+00:00

<img alt="Emerytury stażowe. Jest kolejny projekt w Sejmie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lzp7c9-15-latek-kradl-seniorkom-torebki-zdj-ilustracyjne-7450227/alternates/LANDSCAPE_1280" />
    Projekt Lewicy.

## Dziękował Ziobrze, gwarantował, że będzie "działał na rzecz wymiaru sprawiedliwości". Został zatrzymany
 - [https://tvn24.pl/premium/dziekowal-ziobrze-gwarantowal-ze-bedzie-dzialal-na-rzecz-wymiaru-sprawiedliwosci-zatrzymany-7749957?source=rss](https://tvn24.pl/premium/dziekowal-ziobrze-gwarantowal-ze-bedzie-dzialal-na-rzecz-wymiaru-sprawiedliwosci-zatrzymany-7749957?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T05:47:55+00:00

<img alt="Dziękował Ziobrze, gwarantował, że będzie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vahr94-19-latek-zostal-zatrzymany-przez-policje-znaleziono-przy-nim-czesc-skradzionej-gotowki-7743280/alternates/LANDSCAPE_1280" />
    Młody działacz Suwerennej Polski usłyszał zarzut kradzieży z włamaniem.

## Karetka grzęźnie w błocie. Droga pożarowa zastawiona słupkami i samochodami
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-karetka-grzeznie-w-blocie-droga-pozarowa-zastawiona-slupkami-i-samochodami-nagranie-st7750466?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-karetka-grzeznie-w-blocie-droga-pozarowa-zastawiona-slupkami-i-samochodami-nagranie-st7750466?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T05:36:16+00:00

<img alt="Karetka grzęźnie w błocie. Droga pożarowa zastawiona słupkami i samochodami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l3dyhs-ratownik-wypycha-karetke-z-blota-7750716/alternates/LANDSCAPE_1280" />
    Ratownik próbował wypchnąć pojazd.

## Białoruska skoczkini czeka na polskie obywatelstwo. "Ma potencjał na olimpijski finał"
 - [https://eurosport.tvn24.pl/lekkoatletyka/bialorusinka-maria-zodzik-czeka-na-polskie-obywatelstwo-i-igrzyska.-kim-jest_sto10002109/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/bialorusinka-maria-zodzik-czeka-na-polskie-obywatelstwo-i-igrzyska.-kim-jest_sto10002109/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T05:16:26+00:00

<img alt="Białoruska skoczkini czeka na polskie obywatelstwo. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v4vt5u-maria-zodzik-w-mityngu-orlen-cup-7751729/alternates/LANDSCAPE_1280" />
    Na początku łatwe nie było nic - po przyjeździe do Polski trenowała i pracowała w fast foodzie.

## Bodnar wycofał kolejny wniosek Ziobry. "Troska o wartości konstytucyjne"
 - [https://tvn24.pl/polska/adam-bodnar-wycofal-z-trybunalu-konstytucyjnego-wniosek-zbigniewa-ziobry-w-sprawie-jednego-samorzadu-lekarskiego-7751712?source=rss](https://tvn24.pl/polska/adam-bodnar-wycofal-z-trybunalu-konstytucyjnego-wniosek-zbigniewa-ziobry-w-sprawie-jednego-samorzadu-lekarskiego-7751712?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T05:05:53+00:00

<img alt="Bodnar wycofał kolejny wniosek Ziobry. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fe2196-adam-bodnar-7751713/alternates/LANDSCAPE_1280" />
    Tym razem z Trybunału Konstytucyjnego.

## Czy uda się przełamać weto Orbana?
 - [https://tvn24.pl/swiat/unia-europejska-szczyt-w-sprawie-pomocy-dla-ukrainy-co-z-wetem-wegier-i-viktora-orbana-7751721?source=rss](https://tvn24.pl/swiat/unia-europejska-szczyt-w-sprawie-pomocy-dla-ukrainy-co-z-wetem-wegier-i-viktora-orbana-7751721?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2024-02-01T04:43:06+00:00

<img alt="Czy uda się przełamać weto Orbana?  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-w91m49-viktor-orban-7751728/alternates/LANDSCAPE_1280" />
    Polskę na szczycie Rady Europejskiej będzie reprezentował premier Donald Tusk.

