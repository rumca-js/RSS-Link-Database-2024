# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Sondaż. Zamieszanie wokół Kamińskiego i Wąsika. Czyj wizerunek ucierpiał najbardziej?
 - [https://www.rp.pl/polityka/art39777121-sondaz-zamieszanie-wokol-kaminskiego-i-wasika-czyj-wizerunek-ucierpial-najbardziej](https://www.rp.pl/polityka/art39777121-sondaz-zamieszanie-wokol-kaminskiego-i-wasika-czyj-wizerunek-ucierpial-najbardziej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T21:36:00+00:00

Na zamieszaniu wokół skazanych prawomocnym wyrokiem, a potem drugi raz ułaskawionych polityków, najbardziej ucierpiał wizerunek samego prezydenta.  Uważa tak co piąty wyborca PiS i ponad 60 proc. ogółu badanych.

## Unijne miliardy dla Kijowa. Orbán musiał ustąpić
 - [https://www.rp.pl/polityka/art39776831-unijne-miliardy-dla-kijowa-orban-musial-ustapic](https://www.rp.pl/polityka/art39776831-unijne-miliardy-dla-kijowa-orban-musial-ustapic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T21:00:00+00:00

Ukraina dostała od UE stabilne finansowanie w wysokości 50 miliardów euro na najbliższe cztery lata. Viktor Orbán musiał ustąpić, nie uzyskując nic w zamian.

## Kaczyński wydał oświadczenie. Lista zarzutów wobec rządu i żądania
 - [https://www.rp.pl/polityka/art39776941-kaczynski-wydal-oswiadczenie-lista-zarzutow-wobec-rzadu-i-zadania](https://www.rp.pl/polityka/art39776941-kaczynski-wydal-oswiadczenie-lista-zarzutow-wobec-rzadu-i-zadania)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:41:00+00:00

"Pierwsze tygodnie rządów Donalda Tuska to czas demontażu niezależnych instytucji, na których opiera się polski porządek prawny" - czytamy w oświadczeniu prezesa PiS Jarosława Kaczyńskiego.

## KRS nie zgadza się z zawieszeniem prezesa Piotra Schaba
 - [https://www.rp.pl/sady-i-trybunaly/art39776431-krs-nie-zgadza-sie-z-zawieszeniem-prezesa-piotra-schaba](https://www.rp.pl/sady-i-trybunaly/art39776431-krs-nie-zgadza-sie-z-zawieszeniem-prezesa-piotra-schaba)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:09:50+00:00

Krajowa Rada Sądownictwa uważa, że zawieszenie prezesa sądu bezterminowo po negatywnej opinii kolegium jest niezgodne z przepisami. Powinno się skończyć, gdy wpłynął dokument.

## Lekkie odbicie po chudym roku
 - [https://www.rp.pl/nieruchomosci/art39772131-lekkie-odbicie-po-chudym-roku](https://www.rp.pl/nieruchomosci/art39772131-lekkie-odbicie-po-chudym-roku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:07:00+00:00

2023 r. na świecie przyniósł mocny spadek inwestycji w nieruchomości komercyjne. Kiedy trend się odwróci?

## Stawiamy na oryginalne koncepty, unikamy „sieciówek”
 - [https://www.rp.pl/nieruchomosci/art39772141-stawiamy-na-oryginalne-koncepty-unikamy-sieciowek](https://www.rp.pl/nieruchomosci/art39772141-stawiamy-na-oryginalne-koncepty-unikamy-sieciowek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:06:00+00:00

Miasta mają dziś zupełnie inne potrzeby niż jeszcze pięć lat temu. Przyszłością są inwestycje wielofunkcyjne – mówi Karolina Prędota-Krystek, szefowa działu food & beverage w spółce Echo Investment.

## Klienci rzucili się na wielką płytę
 - [https://www.rp.pl/nieruchomosci/art39772101-klienci-rzucili-sie-na-wielka-plyte](https://www.rp.pl/nieruchomosci/art39772101-klienci-rzucili-sie-na-wielka-plyte)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:05:00+00:00

Oferta mieszkań w budynkach z wielkiej płyty mocno zmalała. A ceny lokali poszły w górę, nawet o 50 proc. w ciągu roku.

## Czynniki ESG będą coraz istotniejsze przy wycenie budynków
 - [https://www.rp.pl/nieruchomosci/art39772071-czynniki-esg-beda-coraz-istotniejsze-przy-wycenie-budynkow](https://www.rp.pl/nieruchomosci/art39772071-czynniki-esg-beda-coraz-istotniejsze-przy-wycenie-budynkow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:04:00+00:00

Brak danych i standardów rynkowych ogranicza rzeczoznawcom możliwości wyzczania ryzyk i szans związanych z czynnikami ESG do wyceny nieruchomości – powiedziała w programie #RZECZoNIERUCHOMOŚCIACH Ilona Otoka, starsza konsultantka ds. ESG w Cushman&amp;Wakefield.

## Akademik prowadzony przez firmę z wyższą stawką
 - [https://www.rp.pl/nieruchomosci/art39772151-akademik-prowadzony-przez-firme-z-wyzsza-stawka](https://www.rp.pl/nieruchomosci/art39772151-akademik-prowadzony-przez-firme-z-wyzsza-stawka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:03:00+00:00

Budynek sklasyfikowany jako mieszkalny, ale zajęty na czasowe zakwaterowanie studenta na czas nauki i który jest wynajmowany na zasadach komercyjnych, nie korzysta z preferencyjnego opodatkowania podatkiem od nieruchomości.

## Czy to będzie rok budowy domów?
 - [https://www.rp.pl/nieruchomosci/art39772111-czy-to-bedzie-rok-budowy-domow](https://www.rp.pl/nieruchomosci/art39772111-czy-to-bedzie-rok-budowy-domow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:02:00+00:00

Statystyki GUS pokazują mocny spadek aktywności budowlanej Kowalskich w 2023 r., tymczasem analitycy PKO BP wskazują na czynniki mogące spowodować, że zainteresowanie domami wzrośnie.

## Wzbiera fala popytu na domy dla seniorów. Jest ich za mało
 - [https://www.rp.pl/nieruchomosci/art39772081-wzbiera-fala-popytu-na-domy-dla-seniorow-jest-ich-za-malo](https://www.rp.pl/nieruchomosci/art39772081-wzbiera-fala-popytu-na-domy-dla-seniorow-jest-ich-za-malo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:01:00+00:00

Pod względem dostępności miejsc w specjalistycznych placówkach dla seniorów Polska jest w ogonie Europy – wynika z raportu CBRE i Greenberg Traurig.

## Archeologiczna symfonia na bas, chór i orkiestrę
 - [https://www.rp.pl/historia-swiata/art39772641-archeologiczna-symfonia-na-bas-chor-i-orkiestre](https://www.rp.pl/historia-swiata/art39772641-archeologiczna-symfonia-na-bas-chor-i-orkiestre)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:00:00+00:00

Odkrycia w Banganarti zainteresowały znawców muzyki sakralnej i hymnografii bizantyjskiej. W Polsce te wielkopostne hymny zapisane po grecku na ścianach świątyni nad środkowym Nilem zafascynowały wybitnego kompozytora – prof. Pawła Łukaszewskiego z Uniwersytetu Muzycznego Fryderyka Chopina, znakomitego znawcę muzyki sakralnej.

## Dwaj bracia z Paryża
 - [https://www.rp.pl/historia-swiata/art39772651-dwaj-bracia-z-paryza](https://www.rp.pl/historia-swiata/art39772651-dwaj-bracia-z-paryza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:00:00+00:00

Józef i Henryk Babińscy, synowie polskich emigrantów z okresu Wiosny Ludów, przyczynili się do rozwoju nauk przyrodniczych. Młodszy z braci był pionierem neurochirurgii, a starszy – geologiem zatrudnianym przez francuski rząd.

## Jak Niemcy zabłądzili pod Stalingrad
 - [https://www.rp.pl/historia-swiata/art39772611-jak-niemcy-zabladzili-pod-stalingrad](https://www.rp.pl/historia-swiata/art39772611-jak-niemcy-zabladzili-pod-stalingrad)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:00:00+00:00

Bitwa stalingradzka była dla Niemców klęską poniesioną na własne życzenie, nie musieli bowiem wikłać się w wielomiesięczne walki o miasto nad Wołgą.

## Komunista, kapitalista, sekretarz, pozer
 - [https://www.rp.pl/historia-swiata/art39772631-komunista-kapitalista-sekretarz-pozer](https://www.rp.pl/historia-swiata/art39772631-komunista-kapitalista-sekretarz-pozer)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:00:00+00:00

Jego śmierć 30 listopada 2022 r. nie przyciągnęła wielkiej uwagi. Dziś wspomnienia o Jiangu Zeminie zbladły, zwłaszcza w obliczu tego, co z Chinami i posiadaną władzą robi Xi Jinping. A jednak to Jiang stworzył takie Państwo Środka, jakie Xi jedynie twórczo rozwija: hybrydę komunizmu z patologiami kapitalizmu, globalnymi ambicjami mocarstwowymi i namiastką igrzysk dla ludu.

## Kto naprawdę był autorem „Mein Kampf”?
 - [https://www.rp.pl/historia-swiata/art39772601-kto-naprawde-byl-autorem-mein-kampf](https://www.rp.pl/historia-swiata/art39772601-kto-naprawde-byl-autorem-mein-kampf)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T20:00:00+00:00

Sto lat temu, w lutym 1924 r., podczas odbywania kary w wojskowym więzieniu Landsberg, Adolf Hitler zaczął pisać swoją jedyną książkę, której pierwotnie nadał tytuł „Cztery i pół roku walki z kłamstwami, głupotą i tchórzostwem”. Później, prawdopodobnie za namową Rudolfa Hessa, niechętnie zmienił tytuł na: „Mein Kampf” (Moja walka).

## Serwisy Gremi Media: Ponad 7 mln RU oraz rekord wizyt i odsłon
 - [https://www.rp.pl/media/art39776851-serwisy-gremi-media-ponad-7-mln-ru-oraz-rekord-wizyt-i-odslon](https://www.rp.pl/media/art39776851-serwisy-gremi-media-ponad-7-mln-ru-oraz-rekord-wizyt-i-odslon)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T19:59:29+00:00

W styczniu Gremi Media odnotowała wzrostowe wyniki oraz rekordy online. Serwisy grupy osiągnęły ponad 7 mln realnych użytkowników, co stanowi wzrost o 59% w porównaniu do stycznia 2023. Ponadto z wynikiem 23,427 mln Gremi Media ustanowiła nowy rekord wizyt, notując wzrost o 100% w stosunku do wyniku z ubiegłego roku i przewyższając o 169 tys. wizyt wynik z grudnia 2023, który był dotychczas najlepszym osiągnięciem. Dodatkowo, liczba odsłon wzrosła do 38,536 mln, bijąc styczeń poprzedniego roku o 83% i przekraczając o 174 tys. odsłon rekordowy wynik z grudnia 2023.

## Rosja. Pięć dni aresztu za "ekstremistyczne" kolczyki
 - [https://www.rp.pl/przestepczosc/art39776681-rosja-piec-dni-aresztu-za-ekstremistyczne-kolczyki](https://www.rp.pl/przestepczosc/art39776681-rosja-piec-dni-aresztu-za-ekstremistyczne-kolczyki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T19:43:00+00:00

Sąd w Niżnym Nowogrodzie w środkowej Rosji skazał kobietę na areszt za noszenie tęczowych kolczyków – poinformowała w środę organizacja broniąca praw człowieka Egida.

## Sony zrywa transakcję wartą 10 mld dolarów z indyjską firmą. Powodem Rosja
 - [https://www.rp.pl/biznes/art39776611-sony-zrywa-transakcje-warta-10-mld-dolarow-z-indyjska-firma-powodem-rosja](https://www.rp.pl/biznes/art39776611-sony-zrywa-transakcje-warta-10-mld-dolarow-z-indyjska-firma-powodem-rosja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T19:22:04+00:00

Japoński koncern Sony zerwał transakcję zakupu indyjskiej spółki medialnej z powodu posiadania przez nią aktywów w Rosji. Wartość transakcji oceniana była na 10 mld dolarów.

## Gaz-System wybrał dostawcę pływającego gazoportu
 - [https://energia.rp.pl/gaz/art39776631-gaz-system-wybral-dostawce-plywajacego-gazoportu](https://energia.rp.pl/gaz/art39776631-gaz-system-wybral-dostawce-plywajacego-gazoportu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T18:59:37+00:00

Gaz-System wybrał armatora, z którym będzie uzgadniał warunki dostawy pierwszej w Polsce jednostki FSRU, a więc pływającego gazoportu w Gdańsku.

## Prezes Develii wejdzie do rady nadzorczej PKO BP
 - [https://www.rp.pl/banki/art39776601-prezes-develii-wejdzie-do-rady-nadzorczej-pko-bp](https://www.rp.pl/banki/art39776601-prezes-develii-wejdzie-do-rady-nadzorczej-pko-bp)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T18:51:40+00:00

Andrzej Oślizło został zgłoszony do nadzoru banku przez Skarb Państwa.

## Dziennik Ustaw z 1 lutego 2024 (121-127)
 - [https://www.rp.pl/akty-prawne/art39776511-dziennik-ustaw-z-1-lutego-2024-121-127](https://www.rp.pl/akty-prawne/art39776511-dziennik-ustaw-z-1-lutego-2024-121-127)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T18:25:24+00:00



## Prof. Kmieciak o decyzji Andrzeja Dudy: Czy przekroczyliśmy już granice śmieszności?
 - [https://www.rp.pl/opinie-prawne/art39776411-prof-kmieciak-o-decyzji-andrzeja-dudy-czy-przekroczylismy-juz-granice-smiesznosci](https://www.rp.pl/opinie-prawne/art39776411-prof-kmieciak-o-decyzji-andrzeja-dudy-czy-przekroczylismy-juz-granice-smiesznosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T18:18:39+00:00

Czasowe nieobsadzenie dwóch stanowisk poselskich z pewnością nie pozbawiło Sejmu zdolności do uchwalenia budżetu. Czy skierowanie do Trybunału Konstytucyjnego ustawy budżetowej było jedynie pretekstem do podjęcia gry politycznej?

## Atak na oddział Procter & Gamble w Turcji. Napastnik wziął zakładników
 - [https://www.rp.pl/handel/art39775461-atak-na-oddzial-procter-gamble-w-turcji-napastnik-wzial-zakladnikow](https://www.rp.pl/handel/art39775461-atak-na-oddzial-procter-gamble-w-turcji-napastnik-wzial-zakladnikow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T17:44:00+00:00

Uzbrojony mężczyzna wziął siedmiu zakładników w fabryce amerykańskiego giganta Procter & Gamble pod Stambułem. Napad ma być protestem przeciwko wojnie w Strefie Gazy – donoszą tureckie media.

## Rosja wzywa USA do zatrzymania „niekończącego się kręgu eskalacji”
 - [https://www.rp.pl/konflikty-zbrojne/art39774341-rosja-wzywa-usa-do-zatrzymania-niekonczacego-sie-kregu-eskalacji](https://www.rp.pl/konflikty-zbrojne/art39774341-rosja-wzywa-usa-do-zatrzymania-niekonczacego-sie-kregu-eskalacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T17:00:00+00:00

Rosja oskarżyła Stany Zjednoczone o planowanie rozmieszczenia broni nuklearnej w Wielkiej Brytanii w ramach „niekończącego się kręgu eskalacji”.

## WIG20 się przebudził, ale czy nie zaspał?
 - [https://www.rp.pl/gielda/art39774531-wig20-sie-przebudzil-ale-czy-nie-zaspal](https://www.rp.pl/gielda/art39774531-wig20-sie-przebudzil-ale-czy-nie-zaspal)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T16:59:19+00:00

Podczas trzech ostatnich sesji gra toczyła się praktycznie na połowie niedźwiedzi. W tym czasie WIG20 wzniósł się o ponad 93 pkt.

## Złoty wyraźnie silniejszy na koniec dnia
 - [https://www.rp.pl/waluty/art39774401-zloty-wyraznie-silniejszy-na-koniec-dnia](https://www.rp.pl/waluty/art39774401-zloty-wyraznie-silniejszy-na-koniec-dnia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T16:57:46+00:00

Kurs głównych walut zniżkują w czwartek po południu. Dolar kosztuje poniżej 4 zł.

## 100 obietnic Tuska. Krzysztof Bosak: Prawie nic nie jest spełnione
 - [https://www.rp.pl/polityka/art39774141-100-obietnic-tuska-krzysztof-bosak-prawie-nic-nie-jest-spelnione](https://www.rp.pl/polityka/art39774141-100-obietnic-tuska-krzysztof-bosak-prawie-nic-nie-jest-spelnione)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T16:31:13+00:00

Podczas pierwszych 100 dni rządzenia gabinet Donalda Tuska miał spełnić "100 konkretów", czyli obietnic wyborczych. - Po 50 dniach prawie nic nie zostało spełnione, a skala bezczelności i wycofywania się z obietnic wyborczych jest porażająca - ocenił lider Konfederacji Krzysztof Bosak.

## Bogdan Góralczyk: Viktor Orbán powołał nowy urząd, który ma bronić „suwerenności” Węgier. Świat protestuje
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39773861-bogdan-goralczyk-viktor-orban-powolal-nowy-urzad-ktory-ma-bronic-suwerennosci-wegier-swiat-protestuje](https://www.rp.pl/opinie-polityczno-spoleczne/art39773861-bogdan-goralczyk-viktor-orban-powolal-nowy-urzad-ktory-ma-bronic-suwerennosci-wegier-swiat-protestuje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T16:28:09+00:00

Z dniem 1 lutego na Węgrzech zaczął działać specjalny Urząd Ochrony Suwerenności. Ma „zapobiec ewentualnym manipulacjom lub dezinformacjom, które naruszałyby interesy suwerennego państwa”. Co to znaczy w praktyce?

## Nie tylko 800+ w bankowości elektronicznej
 - [https://pieniadze.rp.pl/budzet-rodzinny/art39774181-nie-tylko-800-w-bankowosci-elektronicznej](https://pieniadze.rp.pl/budzet-rodzinny/art39774181-nie-tylko-800-w-bankowosci-elektronicznej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T15:53:02+00:00

W bankowości elektronicznej uruchomione zostały wnioski o wypłatę świadczenia rodzinnego 800+ na nowy okres świadczeniowy 2023/2025. Banki po raz pierwszy umożliwiły też składanie wniosków o świadczenie wspierające dla osób z niepełnosprawnością.

## Historyczna zima w Ukrainie. Korzystali wyłącznie z własnego gazu
 - [https://energia.rp.pl/gaz/art39774231-historyczna-zima-w-ukrainie-korzystali-wylacznie-z-wlasnego-gazu](https://energia.rp.pl/gaz/art39774231-historyczna-zima-w-ukrainie-korzystali-wylacznie-z-wlasnego-gazu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T15:45:45+00:00

Po raz pierwszy w historii Ukraina przechodzi sezon grzewczy korzystając tylko z własnego, wydobytego w kraju surowca. Jest go dziś dość na zimę i wiosnę.

## Donald Tusk o pomocy dla Ukrainy. "Gra Orbána się zakończyła błyskawicznie"
 - [https://www.rp.pl/polityka/art39774191-donald-tusk-o-pomocy-dla-ukrainy-gra-orbana-sie-zakonczyla-blyskawicznie](https://www.rp.pl/polityka/art39774191-donald-tusk-o-pomocy-dla-ukrainy-gra-orbana-sie-zakonczyla-blyskawicznie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T15:38:41+00:00

- Chcemy wesprzeć Ukrainę w jej wysiłku wojennym przeciwko Rosji, ma być nas 27, cała Wspólnota i nikt nikomu za to nie będzie płacił żadnej nagrody - tak według premiera Donalda Tuska wyglądało stanowisko większości podczas rozmów w sprawie przyznania Ukrainie przez UE 50 mld euro pomocy.

## Streamingowy gigant zakazuje dzielenia kont w swoich serwisach. Zachęcił go Netflix
 - [https://cyfrowa.rp.pl/globalne-interesy/art39774171-streamingowy-gigant-zakazuje-dzielenia-kont-w-swoich-serwisach-zachecil-go-netflix](https://cyfrowa.rp.pl/globalne-interesy/art39774171-streamingowy-gigant-zakazuje-dzielenia-kont-w-swoich-serwisach-zachecil-go-netflix)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T15:17:00+00:00

Sukces platformy Netflix, która poszła na wojnę z użytkownikami dzielącymi się hasłami do konta i zanotowała  wzrost ich liczby, zachęcił konkurencję. Disney zaczął robić to samo w swoich serwisach Disney+, Hulu i ESPN+.

## Artur Bartkiewicz: Sondażowe sukcesy marszałka Sejmu. Plan Szymona Hołowni na razie działa
 - [https://www.rp.pl/publicystyka/art39774131-artur-bartkiewicz-sondazowe-sukcesy-marszalka-sejmu-plan-szymona-holowni-na-razie-dziala](https://www.rp.pl/publicystyka/art39774131-artur-bartkiewicz-sondazowe-sukcesy-marszalka-sejmu-plan-szymona-holowni-na-razie-dziala)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T15:06:10+00:00

Chińskie powiedzenie mówi, że zamiast walczyć z wrogami należy usiąść na brzegu rzeki i cierpliwie czekać, aż przypłyną nią ich trupy. Szymon Hołownia zdaje się realizować obecnie polityczny projekt tego właśnie rodzaju.

## Nowy lider wyścigu internetowych grup w Polsce. Przełomowy moment dla Polsatu
 - [https://cyfrowa.rp.pl/telekomunikacja/art39774151-nowy-lider-wyscigu-internetowych-grup-w-polsce-przelomowy-moment-dla-polsatu](https://cyfrowa.rp.pl/telekomunikacja/art39774151-nowy-lider-wyscigu-internetowych-grup-w-polsce-przelomowy-moment-dla-polsatu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T14:54:00+00:00

Grupa Zygmunta Solorza po raz pierwszy przegoniła pod względem liczby użytkowników serwisów internetowych największych krajowych konkurentów: Grupy Wirtualna Polska oraz RAS Polska.

## Estera Flieger: „Kos”, czyli historyczny film współczesny. Mówi nawet o wojnie w Ukrainie
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39774121-estera-flieger-kos-czyli-historyczny-film-wspolczesny-mowi-nawet-o-wojnie-w-ukrainie](https://www.rp.pl/opinie-polityczno-spoleczne/art39774121-estera-flieger-kos-czyli-historyczny-film-wspolczesny-mowi-nawet-o-wojnie-w-ukrainie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T14:44:13+00:00

Bardziej niż o Tadeuszu Kościuszce Paweł Maślona i Michał A. Zieliński opowiadają o znaczeniu jego powrotu z Ameryki dla ówczesnego społeczeństwa – we wszystkich jego warstwach. Ale dla mnie „Kos” jest najciekawszy, kiedy stanowi odniesienie do toczącej się za naszą wschodnią granicą wojny.

## „Inteligentny luksus” triumfuje. To trend, który może zdominować ten rok
 - [https://sukces.rp.pl/moda/art39774111-inteligentny-luksus-triumfuje-to-trend-ktory-moze-zdominowac-ten-rok](https://sukces.rp.pl/moda/art39774111-inteligentny-luksus-triumfuje-to-trend-ktory-moze-zdominowac-ten-rok)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T14:40:12+00:00

Miuccia Prada, Victoria Beckham i siostry Olsen są autorkami najbardziej pożądanych ubrań ostatnich miesięcy. Zdaniem obserwatorów mody ich marki promują tak zwany inteligentny luksus”.

## Filmowcy idą do prokuratury. W tle spotkanie Morawieckiego z szefem Netfliksa
 - [https://www.rp.pl/internet-i-prawo-autorskie/art39767951-filmowcy-ida-do-prokuratury-w-tle-spotkanie-morawieckiego-z-szefem-netfliksa](https://www.rp.pl/internet-i-prawo-autorskie/art39767951-filmowcy-ida-do-prokuratury-w-tle-spotkanie-morawieckiego-z-szefem-netfliksa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T14:28:00+00:00

Stowarzyszenie Filmowców Polskich zarzuca byłemu rządowi brak działania w sprawie dyrektywy o prawach autorskich. Twórcy dalej nie dostają tantiem i mają wątpliwości, co do spotkania byłego premiera z szefem Netfliksa.

## W Treblince powstanie mur pamięci
 - [https://www.rp.pl/historia/art39773741-w-treblince-powstanie-mur-pamieci](https://www.rp.pl/historia/art39773741-w-treblince-powstanie-mur-pamieci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T14:17:00+00:00

Obok byłego obozu zagłady w Treblince powstaje pawilon muzealny. Ekspozycję stałą stworzą naukowcy Żydowskiego Instytutu Historycznego. Nie wiadomo jednak kto sfinansuje jej powstanie. Może Niemcy?

## Aleksiej Nawalny proponuje Rosjanom nietypowy protest w dniu wyborów
 - [https://www.rp.pl/polityka/art39774051-aleksiej-nawalny-proponuje-rosjanom-nietypowy-protest-w-dniu-wyborow](https://www.rp.pl/polityka/art39774051-aleksiej-nawalny-proponuje-rosjanom-nietypowy-protest-w-dniu-wyborow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T14:03:29+00:00

Odsiadujący wyrok wieloletniego więzienia w kolonii karnej rosyjski opozycjonista Aleksiej Nawalny wezwał Rosjan, aby wyrazili protest wobec rządów Władimira Putina w dniu wyborów prezydenckich.

## Pierwszy kraj na świecie zakazuje „wiecznych chemikaliów” w kosmetykach
 - [https://klimat.rp.pl/klimat-i-ludzie/art39773081-pierwszy-kraj-na-swiecie-zakazuje-wiecznych-chemikaliow-w-kosmetykach](https://klimat.rp.pl/klimat-i-ludzie/art39773081-pierwszy-kraj-na-swiecie-zakazuje-wiecznych-chemikaliow-w-kosmetykach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T14:02:55+00:00

Nowa Zelandia to pierwszy kraj na świecie, który zdecydował o wprowadzeniu zakazu stosowania tzw. „wiecznych chemikaliów” w produktach kosmetycznych. Substancje te szkodliwe są zarówno dla środowiska naturalnego, jak i dla zdrowia człowieka.

## Zatrudniasz emerytów lub rencistów? Musisz wystawić zaświadczenie
 - [https://firma.rp.pl/zus/art39774061-zatrudniasz-emerytow-lub-rencistow-musisz-wystawic-zaswiadczenie](https://firma.rp.pl/zus/art39774061-zatrudniasz-emerytow-lub-rencistow-musisz-wystawic-zaswiadczenie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:56:53+00:00

Do 29 lutego pracujący emeryci i renciści oraz zatrudniające ich firmy muszą udokumentować w ZUS wysokość przychodów osiągniętych przez te osoby w 2023 r.

## Będą przedterminowe wybory? Donald Tusk: Jeśli PiS będzie chciał, to je dostanie
 - [https://www.rp.pl/polityka/art39773931-beda-przedterminowe-wybory-donald-tusk-jesli-pis-bedzie-chcial-to-je-dostanie](https://www.rp.pl/polityka/art39773931-beda-przedterminowe-wybory-donald-tusk-jesli-pis-bedzie-chcial-to-je-dostanie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:50:14+00:00

- Nie sądzę, żeby po stronie PiS-u był jakiś entuzjazm do idei rozwiązania parlamentu i wcześniejszych wyborów - ocenił premier Donald Tusk (PO), pytany o echa decyzji prezydenta Andrzeja Dudy ws. budżetu na 2024 rok.

## Puchar Davisa: Kamil Majchrzak wraca do reprezentacji Polski
 - [https://sport.rp.pl/tenis/art39767151-puchar-davisa-kamil-majchrzak-wraca-do-reprezentacji-polski](https://sport.rp.pl/tenis/art39767151-puchar-davisa-kamil-majchrzak-wraca-do-reprezentacji-polski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:45:55+00:00

Kamil Majchrzak wrócił w styczniu do międzynarodowego touru po 13-miesięcznej przerwie i wygrał turniej w Monastyrze, a teraz pomoże reprezentacji Polski w meczu Pucharu Davisa z Uzbekistanem.

## „Wiedzieli i skłamali”. Co branża paliwowa wolała przemilczeć w sprawie emisji?
 - [https://klimat.rp.pl/planeta/art39773971-wiedzieli-i-sklamali-co-branza-paliwowa-wolala-przemilczec-w-sprawie-emisji](https://klimat.rp.pl/planeta/art39773971-wiedzieli-i-sklamali-co-branza-paliwowa-wolala-przemilczec-w-sprawie-emisji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:45:04+00:00

Badania zlecone w 1954 roku przez przedstawicieli przemysłu wydobywczego i motoryzacyjnego w USA wykazały, jak poważne konsekwencje dla środowiska ma wykorzystywanie paliw kopalnych – pisze „Guardian” powołując się na ujawnione dokumenty.

## Bank Anglii otworzył drogę do cięcia stóp?
 - [https://www.rp.pl/banki/art39773781-bank-anglii-otworzyl-droge-do-ciecia-stop](https://www.rp.pl/banki/art39773781-bank-anglii-otworzyl-droge-do-ciecia-stop)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:40:43+00:00

Bank Anglii pozostawił główną stopę procentową na poziomie 5,25 proc. Zasygnalizował jednak, że dokonuje przeglądu swojej polityki pieniężnej.

## Protest rolników w Brukseli: Parlament Europejski obrzucony jajkami. Policja użyła gazu
 - [https://www.rp.pl/spoleczenstwo/art39773981-protest-rolnikow-w-brukseli-parlament-europejski-obrzucony-jajkami-policja-uzyla-gazu](https://www.rp.pl/spoleczenstwo/art39773981-protest-rolnikow-w-brukseli-parlament-europejski-obrzucony-jajkami-policja-uzyla-gazu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:37:58+00:00

Rolnicy protestujący w Brukseli w dniu, gdy w stolicy Belgii odbywa się szczyt Unii Europejskiej, obrzucali jajkami i kamieniami budynek Parlamentu Europejskiego - podaje Reuters.

## Adidas chce sprzedać zapasy butów Yeezy. Nawet po kosztach
 - [https://www.rp.pl/biznes/art39773821-adidas-chce-sprzedac-zapasy-butow-yeezy-nawet-po-kosztach](https://www.rp.pl/biznes/art39773821-adidas-chce-sprzedac-zapasy-butow-yeezy-nawet-po-kosztach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:37:12+00:00

Zerwana współpraca z Kanye Westem to wciąż problem dla Adidasa. Koncern myśli nawet o tym, by niesprzedanych butów pozbyć się po kosztach.

## Rząd zaproponował 3 mld zł na wsparcie elektrycznych ciężarówek
 - [https://logistyka.rp.pl/elektromobilnosc/art39773621-rzad-zaproponowal-3-mld-zl-na-wsparcie-elektrycznych-ciezarowek](https://logistyka.rp.pl/elektromobilnosc/art39773621-rzad-zaproponowal-3-mld-zl-na-wsparcie-elektrycznych-ciezarowek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:24:12+00:00

Do 2029 roku ma powstać sieć ładowarek i korzystająca z nich flota elektrycznych samochodów ciężarowych.

## Agnieszka Pomaska: Sprawdzimy nie tylko fuzję Orlenu z Lotosem, ale i z PGNiG i Energą
 - [https://energia.rp.pl/energetyka-zawodowa/art39773801-agnieszka-pomaska-sprawdzimy-nie-tylko-fuzje-orlenu-z-lotosem-ale-i-z-pgnig-i-energa](https://energia.rp.pl/energetyka-zawodowa/art39773801-agnieszka-pomaska-sprawdzimy-nie-tylko-fuzje-orlenu-z-lotosem-ale-i-z-pgnig-i-energa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:22:00+00:00

Nie jesteśmy przeciwko koncepcjom, planom, które mają chronić nasz majątek narodowy, wręcz przeciwnie. Ale musi się to zadziać drogą analiz, dyskusji. W przypadku fuzji Orlenu z Lotosem nie było nic – mówi posłanka KO Agnieszka Pomaska.

## Czas na finał Pucharu Świata. Polacy wciąż walczą o podium
 - [https://sport.rp.pl/sporty-zimowe/art39773331-czas-na-final-pucharu-swiata-polacy-wciaz-walcza-o-podium](https://sport.rp.pl/sporty-zimowe/art39773331-czas-na-final-pucharu-swiata-polacy-wciaz-walcza-o-podium)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:17:36+00:00

Ostatnie tej zimy zawody Pucharu Świata to dla panczenistów jednocześnie szansa, aby sprawdzić formę przed imprezą sezonu, czyli mistrzostwami świata w Calgary.

## Strajki na niemieckich lotniskach. Ponad tysiąc lotów opóźnionych lub odwołanych
 - [https://turystyka.rp.pl/lotniska/art39773831-strajki-na-niemieckich-lotniskach-ponad-tysiac-lotow-opoznionych-lub-odwolanych](https://turystyka.rp.pl/lotniska/art39773831-strajki-na-niemieckich-lotniskach-ponad-tysiac-lotow-opoznionych-lub-odwolanych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:08:37+00:00

Pracownicy kontroli bezpieczeństwa na 11 niemieckich lotniskach nie wykonują dziś swoich obowiązków. Ich strajk może dotknąć nawet 200 tysięcy pasażerów.

## Norbert Hubert bije rekordy. Jastrzębski Węgiel może go stracić
 - [https://sport.rp.pl/siatkowka/art39768751-norbert-hubert-bije-rekordy-jastrzebski-wegiel-moze-go-stracic](https://sport.rp.pl/siatkowka/art39768751-norbert-hubert-bije-rekordy-jastrzebski-wegiel-moze-go-stracic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:07:47+00:00

Norbert Huber rozgrywa świetny sezon i pojawiają się wątpliwości, czy w kolejnym wciąż będzie bronił barw Jastrzębskiego Węgla.

## Fed wzmocnił dolara
 - [https://www.rp.pl/waluty/art39773281-fed-wzmocnil-dolara](https://www.rp.pl/waluty/art39773281-fed-wzmocnil-dolara)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:06:19+00:00

Amerykańska waluta w czwartek przed południem zyskuje wobec euro i innych walut.

## Lewis Hamilton o krok od Ferrari. Sensacyjny transfer w Formule 1
 - [https://sport.rp.pl/formula-1/art39773171-lewis-hamilton-o-krok-od-ferrari-sensacyjny-transfer-w-formule-1](https://sport.rp.pl/formula-1/art39773171-lewis-hamilton-o-krok-od-ferrari-sensacyjny-transfer-w-formule-1)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T13:04:17+00:00

Lewis Hamilton prawdopodobnie opuści zespół Mercedesa i w 2025 roku zostanie kierowcą wyścigowym Ferrari. Transfer za przesądzony uznają największe brytyjskie media.

## Mściwy Kreml ściga opozycyjnych artystów. Nawet w Azji
 - [https://www.rp.pl/polityka/art39772671-msciwy-kreml-sciga-opozycyjnych-artystow-nawet-w-azji](https://www.rp.pl/polityka/art39772671-msciwy-kreml-sciga-opozycyjnych-artystow-nawet-w-azji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:58:00+00:00

Grupa rockowa Bi-2, która krytykowała wojnę Putina, a teraz chciała występować w Tajlandii, ledwo się z niej wydostała zagrożona deportacją do Rosji.

## Przemoc domowa w nowym ministerstwie
 - [https://www.rp.pl/prawo-dla-ciebie/art39766401-przemoc-domowa-w-nowym-ministerstwie](https://www.rp.pl/prawo-dla-ciebie/art39766401-przemoc-domowa-w-nowym-ministerstwie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:56:00+00:00

Nowy minister ds. równości zajmie się m.in. zwalczaniem przemocy domowej i koordynacją rządowego programu w tej kwestii. Dotychczas była to część kompetencji Ministerstwa Rodziny, Pracy i Polityki Społecznej.

## Czy prawnikowi wypada być aktywnym na TikToku? Radczyni Marta Kruk odpowiada
 - [https://kobieta.rp.pl/prawo/art39761011-czy-prawnikowi-wypada-byc-aktywnym-na-tiktoku-radczyni-marta-kruk-odpowiada](https://kobieta.rp.pl/prawo/art39761011-czy-prawnikowi-wypada-byc-aktywnym-na-tiktoku-radczyni-marta-kruk-odpowiada)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:52:22+00:00

Marta Kruk, partnerka w Kancelarii VenaGroup z Wrocławia, ekspertka prawa własności intelektualnej, mówi o tym, jak prawo i prawnicy mogą zaistnieć w świecie nowych technologii i nowych mediów.

## Trybunał Konstytucyjny wydał zakaz Bodnarowi. Chodzi o sędziego Schaba
 - [https://www.rp.pl/sady-i-trybunaly/art39773661-trybunal-konstytucyjny-wydal-zakaz-bodnarowi-chodzi-o-sedziego-schaba](https://www.rp.pl/sady-i-trybunaly/art39773661-trybunal-konstytucyjny-wydal-zakaz-bodnarowi-chodzi-o-sedziego-schaba)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:51:00+00:00

Trybunał Konstytucyjny wydał postanowienie tymczasowe w sprawie decyzji ministra sprawiedliwości Adama Bodnara o zawieszeniu prezesa Sądu Apelacyjnego w Warszawie, sędziego Piotra Schaba.

## Ukraina liczy na miliardy z USA. Kyryło Budanow: Donald Trump miłośnikiem Putina? Nonsens
 - [https://www.rp.pl/konflikty-zbrojne/art39772931-ukraina-liczy-na-miliardy-z-usa-kyrylo-budanow-donald-trump-milosnikiem-putina-nonsens](https://www.rp.pl/konflikty-zbrojne/art39772931-ukraina-liczy-na-miliardy-z-usa-kyrylo-budanow-donald-trump-milosnikiem-putina-nonsens)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:48:42+00:00

Ukraina liczy, że otrzyma od państw Zachodu kolejne haubice oraz amunicję. Kijów chciałby też dostać samoloty wsparcia sił lądowych, np. A-10 - powiedział w rozmowie z CNN szef ukraińskiego wywiadu wojskowego Kyryło Budanow.

## Ukraińcy zatopili jednostkę Floty Czarnomorskiej wartą nawet 70 mln dolarów
 - [https://www.rp.pl/konflikty-zbrojne/art39773631-ukraincy-zatopili-jednostke-floty-czarnomorskiej-warta-nawet-70-mln-dolarow](https://www.rp.pl/konflikty-zbrojne/art39773631-ukraincy-zatopili-jednostke-floty-czarnomorskiej-warta-nawet-70-mln-dolarow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:46:36+00:00

Główny Wydział Wywiadu Ministerstwa Obrony Ukrainy pochwalił się w serwisie Telegram swoim najnowszym sukcesem.

## Karolina Prędota-Krystek: Kobiety muszą się bardziej rozpychać, pokazywać, że mają odpowiednie kompetencje
 - [https://kobieta.rp.pl/nieruchomosci/art39772521-karolina-predota-krystek-kobiety-musza-sie-bardziej-rozpychac-pokazywac-ze-maja-odpowiednie-kompetencje](https://kobieta.rp.pl/nieruchomosci/art39772521-karolina-predota-krystek-kobiety-musza-sie-bardziej-rozpychac-pokazywac-ze-maja-odpowiednie-kompetencje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:45:52+00:00

- To dzięki własnej pracy jestem dziś w tym, a nie innym punkcie - mówi szefowa działu food & beverage w spółce Echo Investment.

## Strategia migracyjna Polski jeszcze w tym roku. Znamy harmonogram prac
 - [https://www.rp.pl/gospodarka/art39773411-strategia-migracyjna-polski-jeszcze-w-tym-roku-znamy-harmonogram-prac](https://www.rp.pl/gospodarka/art39773411-strategia-migracyjna-polski-jeszcze-w-tym-roku-znamy-harmonogram-prac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:41:44+00:00

Już we wrześniu tego roku ma być gotowy wstępny projekt strategii migracyjnej na lata 2025-2030.

## Nauka wpływa na kondycję i długość życia tak samo jak stosowanie zdrowej diety
 - [https://kobieta.rp.pl/styl-zycia/art39736901-nauka-wplywa-na-kondycje-i-dlugosc-zycia-tak-samo-jak-stosowanie-zdrowej-diety](https://kobieta.rp.pl/styl-zycia/art39736901-nauka-wplywa-na-kondycje-i-dlugosc-zycia-tak-samo-jak-stosowanie-zdrowej-diety)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:38:39+00:00

Są dowody na to, że nauka wydłuża życie. Badacze przyjrzeli się temu, jakie efekty dla zdrowia daje uczęszczanie do placówki oświatowej. Wyniki obserwacji zestawili z innymi czynnikami wpływającymi na długość życia, takimi jak zbilansowana dieta czy palenie papierosów.

## Jacek Nizinkiewicz: Dlaczego Andrzej Duda wzywa rząd na dywanik i chce mieć wpływ na pracę Donalda Tuska?
 - [https://www.rp.pl/publicystyka/art39773161-jacek-nizinkiewicz-dlaczego-andrzej-duda-wzywa-rzad-na-dywanik-i-chce-miec-wplyw-na-prace-donalda-tuska](https://www.rp.pl/publicystyka/art39773161-jacek-nizinkiewicz-dlaczego-andrzej-duda-wzywa-rzad-na-dywanik-i-chce-miec-wplyw-na-prace-donalda-tuska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:21:28+00:00

Prezydent zwołuje Radę Gabinetową podczas której chce rozmawiać o tematach wykraczających poza zakres jego kompetencji, a które są w interesie PiS. Nie przyznaje, że podpisał budżet, ale mówi, że skierował go do TK, którego władza nie uznaje. W co gra Andrzej Duda?

## Kraków Airport - prawie 700 tysięcy pasażerów w styczniu
 - [https://turystyka.rp.pl/lotniska/art39773581-krakow-airport-prawie-700-tysiecy-pasazerow-w-styczniu](https://turystyka.rp.pl/lotniska/art39773581-krakow-airport-prawie-700-tysiecy-pasazerow-w-styczniu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T12:19:45+00:00

W ubiegłym miesiącu z lotniska w Balicach odprawiło się 691,9 tysiąca pasażerów - więcej niż w tym samym czasie w 2019 roku. Władze portu spodziewają się przekroczenia w tym roku 10 milionów podróżnych.

## UE: Jest porozumienie ws. pomocy finansowej dla Ukrainy
 - [https://www.rp.pl/dyplomacja/art39773101-ue-jest-porozumienie-ws-pomocy-finansowej-dla-ukrainy](https://www.rp.pl/dyplomacja/art39773101-ue-jest-porozumienie-ws-pomocy-finansowej-dla-ukrainy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T10:33:00+00:00

Przywódcy państw UE porozumieli się w sprawie pomocy finansowej dla Ukrainy - poinformował przewodniczący Rady Europejskiej, Charles Michel.

## UE: Jest porozumienie ws. pomocy finansowej dla Ukrainy (WIDEO)
 - [https://www.rp.pl/dyplomacja/art39773101-ue-jest-porozumienie-ws-pomocy-finansowej-dla-ukrainy-wideo](https://www.rp.pl/dyplomacja/art39773101-ue-jest-porozumienie-ws-pomocy-finansowej-dla-ukrainy-wideo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T10:33:00+00:00

Przywódcy państw UE porozumieli się w sprawie pomocy finansowej dla Ukrainy - poinformował przewodniczący Rady Europejskiej, Charles Michel.

## Prezydent Andrzej Duda zwołuje Radę Gabinetową
 - [https://www.rp.pl/polityka/art39772221-oswiadczenie-andrzeja-dudy-o-czym-bedzie-mowil-prezydent](https://www.rp.pl/polityka/art39772221-oswiadczenie-andrzeja-dudy-o-czym-bedzie-mowil-prezydent)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T09:51:00+00:00

Prezydent Andrzej Duda powiedział wygłaszając oświadczenie, że ustawa budżetowa na rok 2024 "w niedługim czasie" wejdzie w życie. Wcześniej prezydent w trybie kontroli następczej skierował ustawę budżetową do Trybunału Konstytucyjnego. Andrzej Duda ogłosił też zwołanie Rady Gabinetowej.

## Morawiecki o TVP Jacka Kurskiego: Często źle mnie pokazywała. Nie była na usługach rządu
 - [https://www.rp.pl/polityka/art39771811-morawiecki-o-tvp-jacka-kurskiego-czesto-zle-mnie-pokazywala-nie-byla-na-uslugach-rzadu](https://www.rp.pl/polityka/art39771811-morawiecki-o-tvp-jacka-kurskiego-czesto-zle-mnie-pokazywala-nie-byla-na-uslugach-rzadu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T06:01:08+00:00

W rozmowie z "Business Insiderem" były premier, Mateusz Morawiecki odpowiada "nie" na pytanie czy będzie startował w wybroach do PE. Broni też "Polskiego Ładu" i fuzji Orlenu z Lotosem.

## Szczyt UE: W Brukseli 1 lutego ważyć się będą losy pomocy dla Ukrainy
 - [https://www.rp.pl/dyplomacja/art39771791-szczyt-ue-w-brukseli-1-lutego-wazyc-sie-beda-losy-pomocy-dla-ukrainy](https://www.rp.pl/dyplomacja/art39771791-szczyt-ue-w-brukseli-1-lutego-wazyc-sie-beda-losy-pomocy-dla-ukrainy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T04:48:34+00:00

Przywódcy państw UE spotykają się 1 lutego na szczycie UE w Brukseli, na którym będą chcieli osiągnąć porozumienie ws. pomocy finansowej w wysokości 50 mld euro, która ma być przekazana Ukrainie w latach 2024-2027.

## 14 tys. owiec utknęło na statku w Australii przez sytuację na Bliskim Wschodzie
 - [https://www.rp.pl/konflikty-zbrojne/art39771741-14-tys-owiec-utknelo-na-statku-w-australii-przez-sytuacje-na-bliskim-wschodzie](https://www.rp.pl/konflikty-zbrojne/art39771741-14-tys-owiec-utknelo-na-statku-w-australii-przez-sytuacje-na-bliskim-wschodzie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T04:26:45+00:00

14 tys. owiec i 2 tys. sztuk bydła od 5 stycznia znajduje się na pokładzie statku MV Bahijah, który obecnie stoi w australijskim porcie. Zwierzęta utknęły na statku przez ataki rebeliantów Huti na statki na Morzu Czerwonym.

## Oto Volkswagen Golf po modernizacji. Witamy generację osiem i pół
 - [https://moto.rp.pl/premiery/art39766411-oto-volkswagen-golf-po-modernizacji-witamy-generacje-osiem-i-pol](https://moto.rp.pl/premiery/art39766411-oto-volkswagen-golf-po-modernizacji-witamy-generacje-osiem-i-pol)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T04:11:00+00:00

Volkswagen Golf ósmej generacji po liftingu został już oficjalnie pokazany. Co się zmieniło? Modernizacje dotyczą głównie kwestii praktycznych, ale znajdzie się też coś dla estetów.

## USA ponownie zaatakowały cele w Jemenie. Okręt USA strącał drony nad Zatoką Adeńską
 - [https://www.rp.pl/konflikty-zbrojne/art39771691-usa-ponownie-zaatakowaly-cele-w-jemenie-okret-usa-stracal-drony-nad-zatoka-adenska](https://www.rp.pl/konflikty-zbrojne/art39771691-usa-ponownie-zaatakowaly-cele-w-jemenie-okret-usa-stracal-drony-nad-zatoka-adenska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T04:06:13+00:00

USA ostrzelały 10 dronów w Jemenie, które były przygotowywane do startu - poinformował w środę, późnym wieczorem, przedstawiciel amerykańskiej administracji.

## Morskie i ratownicze AW101 wdrażane do służby
 - [https://radar.rp.pl/modernizacja-sil-zbrojnych/art39771701-morskie-i-ratownicze-aw101-wdrazane-do-sluzby](https://radar.rp.pl/modernizacja-sil-zbrojnych/art39771701-morskie-i-ratownicze-aw101-wdrazane-do-sluzby)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T04:01:13+00:00

W 44 Bazie Lotnictwa Morskiego w Darłowie trwa intensywny proces włączania do służby śmigłowców AW101. Jeszcze w grudniu 2023 r. trafiły tam pierwsze 3 morskie maszyny Leonardo Helicopters. Ostatni z zamówionych wiropłatów kończy testy eksploatacyjne w świdnickich PZL.

## Mediolanu stanie się nazwą zastrzeżoną. Włosi podjęli decyzję
 - [https://sukces.rp.pl/miasta/art39765451-mediolanu-stanie-sie-nazwa-zastrzezona-wlosi-podjeli-decyzje](https://sukces.rp.pl/miasta/art39765451-mediolanu-stanie-sie-nazwa-zastrzezona-wlosi-podjeli-decyzje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T03:50:00+00:00

Być może niebawem Włosi będą mieli nowy znak towarowy. Ma być nim nazwa „Mediolan” w wersji włoskiej, a więc „Milano”.

## Wojna Rosji z Ukrainą. Dzień 708
 - [https://www.rp.pl/swiat/art39771661-wojna-rosji-z-ukraina-dzien-708](https://www.rp.pl/swiat/art39771661-wojna-rosji-z-ukraina-dzien-708)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T03:48:29+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. Wołodymyr Zełenski w wieczornym wystąpieniu podkreślał, że Ukraina skutecznie broni swojego systemu energetycznego przed atakami z powietrza.

## Dawid Szwarga, trener Rakowa: Stadion w Sosnowcu nigdy nie będzie naszym domem
 - [https://sport.rp.pl/pilka-nozna/art39770461-dawid-szwarga-trener-rakowa-stadion-w-sosnowcu-nigdy-nie-bedzie-naszym-domem](https://sport.rp.pl/pilka-nozna/art39770461-dawid-szwarga-trener-rakowa-stadion-w-sosnowcu-nigdy-nie-bedzie-naszym-domem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Grając częściej niż raz w tygodniu, nie nałożysz codziennie makijażu, bo nie masz na to czasu, i władze klubu to wiedzą – mówi „Rz” trener Rakowa Dawid Szwarga.

## Firma w domu, czynsz w podatkowych kosztach
 - [https://www.rp.pl/podatki/art39770251-firma-w-domu-czynsz-w-podatkowych-kosztach](https://www.rp.pl/podatki/art39770251-firma-w-domu-czynsz-w-podatkowych-kosztach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Przedsiębiorca prowadzący biznes w mieszkaniu rozliczy w podatkowych kosztach część wydatków na jego utrzymanie.

## Jacek Nizinkiewicz: Czy po Wąsiku, Kamińskim, Ogórek i Ziemkiewiczu prezydent ułaskawi Bąkiewicza?
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39770281-jacek-nizinkiewicz-czy-po-wasiku-kaminskim-ogorek-i-ziemkiewiczu-prezydent-ulaskawi-bakiewicza](https://www.rp.pl/opinie-polityczno-spoleczne/art39770281-jacek-nizinkiewicz-czy-po-wasiku-kaminskim-ogorek-i-ziemkiewiczu-prezydent-ulaskawi-bakiewicza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Andrzej Duda ułaskawia osoby wspierające PiS. Czy teraz okaże wsparcie narodowcowi skazanemu za naruszenie nietykalności cielesnej, który współpracuje ze Zbigniewem Ziobro? Suwerenna Polska na to czeka.

## KO i Lewica osobno w wyborach samorządowych. Oficjalnie wszystko jest w porządku
 - [https://www.rp.pl/polityka/art39770321-ko-i-lewica-osobno-w-wyborach-samorzadowych-oficjalnie-wszystko-jest-w-porzadku](https://www.rp.pl/polityka/art39770321-ko-i-lewica-osobno-w-wyborach-samorzadowych-oficjalnie-wszystko-jest-w-porzadku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Prezydent Andrzej Duda, podpisując budżet, wzmocnił rząd. Ale koalicjanci w wyborach samorządowych będą grać na siebie.

## Kijów ma już pomysł na mobilizację. „Ważny jest też moment demobilizacji”
 - [https://www.rp.pl/konflikty-zbrojne/art39770411-kijow-ma-juz-pomysl-na-mobilizacje-wazny-jest-tez-moment-demobilizacji](https://www.rp.pl/konflikty-zbrojne/art39770411-kijow-ma-juz-pomysl-na-mobilizacje-wazny-jest-tez-moment-demobilizacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Władze chcą zmobilizować setki tysięcy nowych żołnierzy metodą kija i marchewki. Ochotników wynagrodzą, a w ukrywających się przed wojskiem uderzą surowymi sankcjami.

## Kto może podważać postanowienie spadkowe. SN rozstrzygnął wątpliwości
 - [https://www.rp.pl/spadki-i-darowizny/art39770231-kto-moze-podwazac-postanowienie-spadkowe-sn-rozstrzygnal-watpliwosci](https://www.rp.pl/spadki-i-darowizny/art39770231-kto-moze-podwazac-postanowienie-spadkowe-sn-rozstrzygnal-watpliwosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

O wznowienie sprawy spadkowej może występować wiele osób, ale tylko te, na których prawa lub obowiązki dany spadek aktualnie wpływa.

## Kto zostanie nowym szefem PZU? Rusza kadrowa karuzela
 - [https://www.rp.pl/finanse/art39770221-kto-zostanie-nowym-szefem-pzu-rusza-kadrowa-karuzela](https://www.rp.pl/finanse/art39770221-kto-zostanie-nowym-szefem-pzu-rusza-kadrowa-karuzela)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Już za dwa tygodnie zacznie się wymiana władz PZU. Rozpocznie się od zmian w radzie nadzorczej, potem pracę stracą prezes i członkowie zarządu. Wśród kandydatów do objęcia steru spółki nieoficjalnie wymieniane są znane nazwiska

## Mało debiutów na giełdach w Europie
 - [https://www.rp.pl/gielda/art39770241-malo-debiutow-na-gieldach-w-europie](https://www.rp.pl/gielda/art39770241-malo-debiutow-na-gieldach-w-europie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Wartość ofert pierwotnych na kontynencie, zrealizowanych w 2023 r., była najniższa od ponad dekady – mimo iż giełdowe indeksy notowały zwyżki.

## Mirosław Oczkoś: Wybory samorządowe pokażą, jakie jest realne poparcie dla PiS
 - [https://www.rp.pl/polityka/art39770331-miroslaw-oczkos-wybory-samorzadowe-pokaza-jakie-jest-realne-poparcie-dla-pis](https://www.rp.pl/polityka/art39770331-miroslaw-oczkos-wybory-samorzadowe-pokaza-jakie-jest-realne-poparcie-dla-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Jarosław Kaczyński przegrzał sprawę Mariusza Kamińskiego i Macieja Wąsika – uważa dr Mirosław Oczkoś, ekspert ds. wizerunku politycznego.

## Najbogatsi wciąż ci sami. Rosyjscy miliarderzy bogacą się, nie zważając na zachodnie sankcje
 - [https://www.rp.pl/spoleczenstwo/art39770401-najbogatsi-wciaz-ci-sami-rosyjscy-miliarderzy-bogaca-sie-nie-zwazajac-na-zachodnie-sankcje](https://www.rp.pl/spoleczenstwo/art39770401-najbogatsi-wciaz-ci-sami-rosyjscy-miliarderzy-bogaca-sie-nie-zwazajac-na-zachodnie-sankcje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Mimo ponad 14 tys. różnego rodzaju sankcji, jakie demokratyczne kraje zastosowały przeciw Rosji po jej inwazji na Ukrainę, na liście najbogatszych Rosjan 90 proc. znajduje się tam od co najmniej dekady i nie zamierza jej opuszczać.

## Ożywienie polskiej gospodarki słabsze od oczekiwań. To nie jest zła wiadomość
 - [https://www.rp.pl/dane-gospodarcze/art39770081-ozywienie-polskiej-gospodarki-slabsze-od-oczekiwan-to-nie-jest-zla-wiadomosc](https://www.rp.pl/dane-gospodarcze/art39770081-ozywienie-polskiej-gospodarki-slabsze-od-oczekiwan-to-nie-jest-zla-wiadomosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Wstępny szacunek PKB w 2023 r. sugeruje, że w IV kwartale ożywienie było znacznie słabsze, niż można było oczekiwać. To nie jest wcale zła wiadomość.

## Ożywione obrazy Jacka Malczewskiego w Muzeum Narodowym w Poznaniu
 - [https://www.rp.pl/kultura/art39770451-ozywione-obrazy-jacka-malczewskiego-w-muzeum-narodowym-w-poznaniu](https://www.rp.pl/kultura/art39770451-ozywione-obrazy-jacka-malczewskiego-w-muzeum-narodowym-w-poznaniu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Dla Muzeum Narodowego w Poznaniu reżyser Lech Majewski tworzy projekt złożony z 12 wideo-artów odwołujący się do malarstwa Jacka Malczewskiego.

## Po ataku na amerykańską bazę na Bliskim Wschodzie. Nic nie powstrzyma USA przed odwetem
 - [https://www.rp.pl/konflikty-zbrojne/art39770391-po-ataku-na-amerykanska-baze-na-bliskim-wschodzie-nic-nie-powstrzyma-usa-przed-odwetem](https://www.rp.pl/konflikty-zbrojne/art39770391-po-ataku-na-amerykanska-baze-na-bliskim-wschodzie-nic-nie-powstrzyma-usa-przed-odwetem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Administracja Joe Bidena zastanawia się, jak militarnie odpowiedzieć na ataki na amerykańskich żołnierzy, by nie wywołać nowej wojny na Bliskim Wschodzie.

## Polska i Ukraina w impasie. Skarga za zakaz importu zboża nadal tkwi w WTO
 - [https://www.rp.pl/rolnictwo/art39770131-polska-i-ukraina-w-impasie-skarga-za-zakaz-importu-zboza-nadal-tkwi-w-wto](https://www.rp.pl/rolnictwo/art39770131-polska-i-ukraina-w-impasie-skarga-za-zakaz-importu-zboza-nadal-tkwi-w-wto)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Skarga Ukrainy na nasz kraj nadal tkwi w Światowej Organizacji Handlu, a polski zakaz importu zboża wciąż obowiązuje. Trwa impas, ale wyraźnie zmienił się ton Komisji Europejskiej, która nie krytykuje już Polski tak mocno jak wcześniej.

## Przybywa firm kurierskich, ale ich kondycja jest słaba
 - [https://www.rp.pl/transport/art39770201-przybywa-firm-kurierskich-ale-ich-kondycja-jest-slaba](https://www.rp.pl/transport/art39770201-przybywa-firm-kurierskich-ale-ich-kondycja-jest-slaba)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Rynek usług KEP (kurier, ekspres, paczka) nad Wisłą rośnie bez precedensu. Tylko w ostatnich 12 miesiącach liczba podmiotów z tej branży wzrosła o niemal 600. Nie jest jednak kolorowo.

## Rolnicy z UE drżą przed Ukrainą. KE zaciąga hamulec bezpieczeństwa na żywność
 - [https://www.rp.pl/rolnictwo/art39770071-rolnicy-z-ue-drza-przed-ukraina-ke-zaciaga-hamulec-bezpieczenstwa-na-zywnosc](https://www.rp.pl/rolnictwo/art39770071-rolnicy-z-ue-drza-przed-ukraina-ke-zaciaga-hamulec-bezpieczenstwa-na-zywnosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Zmiany we wspólnej polityce rolnej są nieuniknione. Europejscy farmerzy coraz bardziej obawiają się konkurencji ze strony rolników z Ukrainy, która stopniowo wprowadzana jest na wspólny rynek.

## Rząd w czasie pandemii COVID-19 w zinstrumentalizowany sposób posługiwali się lękiem
 - [https://www.rp.pl/polityka/art39766641-rzad-w-czasie-pandemii-covid-19-w-zinstrumentalizowany-sposob-poslugiwali-sie-lekiem](https://www.rp.pl/polityka/art39766641-rzad-w-czasie-pandemii-covid-19-w-zinstrumentalizowany-sposob-poslugiwali-sie-lekiem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Podczas walki z covidem rząd używał słownictwa rodem z armii i instytucjonalnie zarządzał strachem – wynika ze sprawozdania Rady Języka Polskiego.

## Rząd w czasie pandemii COVID-19 w zinstrumentalizowany sposób posługiwał się lękiem
 - [https://www.rp.pl/polityka/art39766641-rzad-w-czasie-pandemii-covid-19-w-zinstrumentalizowany-sposob-poslugiwal-sie-lekiem](https://www.rp.pl/polityka/art39766641-rzad-w-czasie-pandemii-covid-19-w-zinstrumentalizowany-sposob-poslugiwal-sie-lekiem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Podczas walki z covidem rząd używał słownictwa rodem z armii i instytucjonalnie zarządzał strachem – wynika ze sprawozdania Rady Języka Polskiego.

## Różycki, Slotboom: Poczta Polska– manewrowanie na krawędzi
 - [https://www.rp.pl/opinie-ekonomiczne/art39770271-rozycki-slotboom-poczta-polska-manewrowanie-na-krawedzi](https://www.rp.pl/opinie-ekonomiczne/art39770271-rozycki-slotboom-poczta-polska-manewrowanie-na-krawedzi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Czy nowy rząd jeszcze może uratować Pocztę Polską, która stoi na skraju przepaści?

## Sondaż: Czy Polska powinna strzelać do rosyjskich rakiet nad Ukrainą? Polacy są za
 - [https://www.rp.pl/konflikty-zbrojne/art39770341-sondaz-czy-polska-powinna-strzelac-do-rosyjskich-rakiet-nad-ukraina-polacy-sa-za](https://www.rp.pl/konflikty-zbrojne/art39770341-sondaz-czy-polska-powinna-strzelac-do-rosyjskich-rakiet-nad-ukraina-polacy-sa-za)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Polska powinna rozpocząć rozmowy z NATO i Ukrainą na temat objęcia obroną powietrzną terytorium przy granicy.

## Sędzia Piotr Schab: Nie warto straszyć mnie rozliczeniami
 - [https://www.rp.pl/sady-i-trybunaly/art39770441-sedzia-piotr-schab-nie-warto-straszyc-mnie-rozliczeniami](https://www.rp.pl/sady-i-trybunaly/art39770441-sedzia-piotr-schab-nie-warto-straszyc-mnie-rozliczeniami)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Ja prawa nie złamałem. Przestrzegam go – mówi „Rz” sędzia Piotr Schab, zawieszony prezes SA w Warszawie i rzecznik dyscyplinarny sędziów sądów powszechnych.

## Unia wprowadza klauzule bezpieczeństwa na żywność z Ukrainy
 - [https://www.rp.pl/rolnictwo/art39770161-unia-wprowadza-klauzule-bezpieczenstwa-na-zywnosc-z-ukrainy](https://www.rp.pl/rolnictwo/art39770161-unia-wprowadza-klauzule-bezpieczenstwa-na-zywnosc-z-ukrainy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T02:00:00+00:00

Bruksela chce przedłużenia bezcłowego dostępu ukraińskich produktów rolnych do unijnego rynku. Ale z hamulcami bezpieczeństwa dla cukru, drobiu i jaj.

## Złote Logo za promowanie Polski dla osobistości świata sportu, nauki, sztuki i biznesu
 - [https://turystyka.rp.pl/popularne-trendy/art39771641-zlote-logo-za-promowanie-polski-dla-osobistosci-swiata-sportu-nauki-sztuki-i-biznesu](https://turystyka.rp.pl/popularne-trendy/art39771641-zlote-logo-za-promowanie-polski-dla-osobistosci-swiata-sportu-nauki-sztuki-i-biznesu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:43:31+00:00

Jerzy Owsiak, Iga Świątek, Olga Tokarczuk, Omenaa Mensah – to tylko kilkoro z dwanaściorga wybitnych osób i instytucji, wyróżnionych w tym roku przez Polską Organizację Turystyczną Złotym Logo Polska.

## Aby uzupełnić roszczenie, trzeba się zmieścić w terminie
 - [https://www.rp.pl/prawo-pracy/art39767081-aby-uzupelnic-roszczenie-trzeba-sie-zmiescic-w-terminie](https://www.rp.pl/prawo-pracy/art39767081-aby-uzupelnic-roszczenie-trzeba-sie-zmiescic-w-terminie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Decydując się na dochodzenie roszczeń wynikających z rozwiązania umowy o pracę – tj. przywrócenia do pracy lub odszkodowania – pracownik musi zachować termin na wniesienie powództwa przewidziany w art. 264 kodeksu pracy. Nie jest zatem możliwe przyjęcie poglądu, że wytoczenie powództwa o odszkodowanie z art. 58 k.p. w terminie przewidzianym w art. 264 § 2 k.p. oznacza, iż dla dochodzenia pozostałej części tego odszkodowania nie jest już konieczne zachowanie terminu z art. 264 § 2 k.p., ale wystarczające jest zachowanie trzyletniego terminu z art. 291 § 1 k.p.

## Co z pobytem Ukraińców po 4 marca 2024 r.?
 - [https://www.rp.pl/prawo-pracy/art39767021-co-z-pobytem-ukraincow-po-4-marca-2024-r](https://www.rp.pl/prawo-pracy/art39767021-co-z-pobytem-ukraincow-po-4-marca-2024-r)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Choć europejska ochrona czasowa obywateli Ukrainy została przedłużona do 3 marca 2025 r., to polskie przepisy wciąż nie zostały zmienione. To problem także dla krajowych pracodawców, bo zatrudnianie cudzoziemca, który nie ma prawa pobytu, jest nielegalne.

## Czas na rozliczenie zarobków zatrudnionych emerytów i rencistów
 - [https://www.rp.pl/zus/art39771191-czas-na-rozliczenie-zarobkow-zatrudnionych-emerytow-i-rencistow](https://www.rp.pl/zus/art39771191-czas-na-rozliczenie-zarobkow-zatrudnionych-emerytow-i-rencistow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Pracujący emeryci i renciści oraz zatrudniające je firmy muszą do 29 lutego udokumentować w ZUS wysokość przychodów osiągniętych przez te osoby w 2023 r. Brak składania takich informacji może się wiązać z obowiązkiem zwrotu nienależnych wypłat za trzy lata wstecz.

## Czy szef musi oddać koszty odwołanych ferii?
 - [https://www.rp.pl/prawo-pracy/art39767111-czy-szef-musi-oddac-koszty-odwolanych-ferii](https://www.rp.pl/prawo-pracy/art39767111-czy-szef-musi-oddac-koszty-odwolanych-ferii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Pracownik ma prawo do zwrotu kosztów poniesionych w bezpośrednim związku z zaplanowanym urlopem zarówno wtedy, gdy przełożony odwołał go z wolnego, jak i w sytuacji, gdy przesunął mu termin wypoczynku.

## Podobne znaki towarowe mogą istnieć obok siebie
 - [https://www.rp.pl/abc-firmy/art39767061-podobne-znaki-towarowe-moga-istniec-obok-siebie](https://www.rp.pl/abc-firmy/art39767061-podobne-znaki-towarowe-moga-istniec-obok-siebie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Podobieństwo znaków towarowych nie musi wykluczać ich koegzystencji na tym samym rynku. Różnice mogą pozwolić utrzymać wystarczający dystans pomiędzy ogólnymi wrażeniami przekazywanymi przez oznaczenia.

## Pracownik zapłaci za szkalowanie szefa w sieci
 - [https://www.rp.pl/prawo-pracy/art39767041-pracownik-zaplaci-za-szkalowanie-szefa-w-sieci](https://www.rp.pl/prawo-pracy/art39767041-pracownik-zaplaci-za-szkalowanie-szefa-w-sieci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Uchwała Sądu Najwyższego otwiera drogę do wytaczania powództw o zadośćuczynienie przez pracodawców, których wizerunek i dobre imię zostały nadszarpnięte przez pracowników, w szczególności przez bezpodstawne opinie w internecie.

## Status wspólnika to niezależny tytuł do ubezpieczeń
 - [https://www.rp.pl/zus/art39767071-status-wspolnika-to-niezalezny-tytul-do-ubezpieczen](https://www.rp.pl/zus/art39767071-status-wspolnika-to-niezalezny-tytul-do-ubezpieczen)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Wspólnik spółki jawnej jako osoba prowadząca pozarolniczą działalność, zgodnie z art. 13 pkt 4 u.s.u.s. podlega obowiązkowym ubezpieczeniom społecznym od dnia rozpoczęcia wykonywania działalności do dnia zaprzestania wykonywania tej działalności, to jest od dnia uzyskania statusu wspólnika do dnia utraty takiego statusu. Wpis spółki jawnej do KRS i brak jej wykreślenia (mimo nieprowadzenia działalności gospodarczej przez wspólników) stanowi samodzielną podstawę podlegania ubezpieczeniom społecznym przez wspólników takiej spółki, co wynika wprost z jednoznacznego brzmienia stosownych przepisów.

## Ważne decyzje wymagają współpracy z przedstawicielami pracowników
 - [https://www.rp.pl/prawo-pracy/art39767091-wazne-decyzje-wymagaja-wspolpracy-z-przedstawicielami-pracownikow](https://www.rp.pl/prawo-pracy/art39767091-wazne-decyzje-wymagaja-wspolpracy-z-przedstawicielami-pracownikow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Brak związków zawodowych w zakładzie pracy nie zwalnia pracodawcy z obowiązku współdziałania z przedstawicielami pracowników. W kwestii ich wyboru i roli przepisy są jednak bardzo lakoniczne.

## Wypracowanie wszystkich godzin nie pozbawia prawa do zasiłku
 - [https://www.rp.pl/kadry-i-place/art39767101-wypracowanie-wszystkich-godzin-nie-pozbawia-prawa-do-zasilku](https://www.rp.pl/kadry-i-place/art39767101-wypracowanie-wszystkich-godzin-nie-pozbawia-prawa-do-zasilku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Czas choroby jest płatny także wówczas, gdy pracownik stał się niezdolny do pracy po przepracowaniu pełnego miesięcznego wymiaru czasu pracy.

## ZUS nie zwróci nadpłaconych składek nawet po wyroku
 - [https://www.rp.pl/zus/art39767031-zus-nie-zwroci-nadplaconych-skladek-nawet-po-wyroku](https://www.rp.pl/zus/art39767031-zus-nie-zwroci-nadplaconych-skladek-nawet-po-wyroku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2024-02-01T01:00:00+00:00

Na korektę danych na swoim koncie płatnicy mają tylko pięć lat. Nawet gdy powodem niedochowania terminu będzie sprawa w sądzie, zdaniem organu rentowego nie będą mogli odzyskać nadpłaty składek.

