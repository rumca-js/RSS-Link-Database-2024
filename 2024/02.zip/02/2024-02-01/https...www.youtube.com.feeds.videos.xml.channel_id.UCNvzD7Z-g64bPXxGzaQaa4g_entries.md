# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 BIG NEW PlayStation State of Play Announcements 2024
 - [https://www.youtube.com/watch?v=XcB2MXt7RQI](https://www.youtube.com/watch?v=XcB2MXt7RQI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-02-01T18:15:03+00:00

Sony's big PlayStation state of play just happened and there are some pretty big developments.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1    



0:00 Intro
0:14 SONIC X SHADOW GENERATIONS
1:26 Rise of the Ronin  
3:04 Until Dawn Remaster 
4:28 Stellar Blade  
5:46 Death Stranding 2: On the Beach   
7:02 Silent Hill 2  
8:24 Silent Hill: The Short Message 
8:59 V Rising 
9:35 Dave The Diver 
9:54 Zenless Zone Zero
10:31  Metro Awakening 
11:02 Legendary Tales 
11:46 Physint 


#10 SONIC X SHADOW GENERATIONS

Platform: PS5 PS4 Xbox One XSX|S PC Switch 

Release Date: 2024 



9 Rise of the Ronin  

Platform: PS5 

Release Date: March 22, 2024 



#8 Until Dawn Remaster 

Platform: PS5 PC 

Release Date: 2024 



#7 Stellar Blade  

Platform: PS5 

Release Date: April 26, 2024 



#6 Death Stranding 2: On the Beach   

Platform: PS5 

Release Date: TBA 



#5 Silent Hill 2  

Platform: PS5 

Release Date: TBA  



Silent Hill: The Short Message 

P

## 10 WEIRD Gaming Stories of January 2024
 - [https://www.youtube.com/watch?v=MI6YgBc7xfc](https://www.youtube.com/watch?v=MI6YgBc7xfc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2024-02-01T16:26:48+00:00

The first month of 2024 saw no shortage of weird and interesting headlines in the gaming news world.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1    


0:00 Intro
0:16 Number 10
1:18 Number 9
2:10 Number 8
3:16 Number 7
4:24 Number 6
5:24 Number 5
6:34 Number 4
7:50 Number 3 
9:21 Number 2 
11:00 Number 1

10
https://www.youtube.com/watch?v=W4PHhurAhwc&amp;t=941s&amp;pp=ygUScGxheXN0YXRpb24gdGFibGV0
----
9
https://www.youtube.com/watch?v=K0NKQAhIjKc&amp;ab_channel=JuliusZ
----
8
https://www.youtube.com/watch?v=68YMEmaF0rs
----
7
https://insider-gaming.com/valve-cs-cases-earnings/
----
6
https://www.pcgamer.com/like-a-dragon-infinite-wealth-is-making-the-utterly-bizarre-decision-to-lock-new-game-behind-a-dollar15-upgrade/
----
5
https://www.techspot.com/news/101383-13-year-old-first-human-beat-tetris.html
----
4
https://www.pcgamesn.com/gameshark-ai-game-controller

