# Source:Grimdark Magazine, URL:https://www.grimdarkmagazine.com/feed, language:en-AU

## REVIEW: Sunglasses After Dark by Nancy A. Collins
 - [https://www.grimdarkmagazine.com/review-sunglasses-after-dark-by-nancy-a-collins](https://www.grimdarkmagazine.com/review-sunglasses-after-dark-by-nancy-a-collins)
 - RSS feed: https://www.grimdarkmagazine.com/feed
 - date published: 2024-02-01T04:25:10+00:00

<p>Sunglasses After Dark by Nancy A. Collins is the first of the Sonja Blue novels that I have been recommended multiple times but haven&#8217;t gotten around to reading until now. I know Nancy Collins, first, from her Vampirella comics that were quite entertaining and sadly cut short. I also knew her to be an author who had briefly put her characters in the Vampire: The Masquerade universe but I had never read her signature Sonja Blue series. The premise of Sunglasses After Dark is Sonja Blue is the adopted persona of a young heiress who disappeared a couple of decades prior. Imprisoned inside a metal hospital, but only recently, she has a fascinating history the reader slowly discovers. Sonja is a &#8220;living&#8221; vampire who has managed to maintain most of her humanity upon her traumatic transition from rebellious teenage girl to vampire. Forced to work as a prostitute, eventually becoming a hunter of her own kind, Sonja must cope with the traumatic physical as well as

