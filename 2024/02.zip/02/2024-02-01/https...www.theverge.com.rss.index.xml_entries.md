# Source:The Verge, URL:https://www.theverge.com/rss/index.xml, language:en-US

## Tim Cook confirms Apple’s generative AI features are coming ‘later this year’
 - [https://www.theverge.com/2024/2/1/24058647/apple-ceo-tim-cook-teases-generative-ai-iphone](https://www.theverge.com/2024/2/1/24058647/apple-ceo-tim-cook-teases-generative-ai-iphone)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T23:20:50+00:00

<figure>
      <img alt="A photo of Apple CEO Tim Cook" src="https://cdn.vox-cdn.com/thumbor/QwO-x4Vz96qoOfjOH3phWFt1t6o=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73105165/DSCF8875_2.0.jpg" />
        <figcaption>Photo by Chris Welch / The Verge</figcaption>
    </figure>

  <p id="Ptu2d8">During Apple’s quarterly earnings call on Thursday afternoon, CEO Tim Cook mentioned that the company is working on generative AI software features that will make their way to customers “later this year.” That aligns with reporting from <a href="https://www.bloomberg.com/news/newsletters/2024-01-28/apple-eu-changes-sideloading-third-party-app-stores-are-future-of-the-iphone-lrxjzbg6"><em>Bloomberg’s</em> Mark Gurman</a>, who said recently that iOS 18 could be the “biggest” update in the operating system’s history. Cook’s teases — he mentioned generative AI several times, but never got specific — seem to confirm that we’re in for a big release this fall.</p>
<p id="L

## Toward a unified taxonomy of text-based social media use
 - [https://www.theverge.com/24058356/trolls-social-media-commenter-lurker-reply-guy-threads](https://www.theverge.com/24058356/trolls-social-media-commenter-lurker-reply-guy-threads)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T22:34:47+00:00

<figure>
      <img alt="Natural History Museum In London" src="https://cdn.vox-cdn.com/thumbor/Pc1_ygcTTgKxtZ8tiauGr86oGyA=/0x0:5123x3415/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73105042/1945372516.0.jpg" />
        <figcaption>Let’s check out the specimens! | photo by Mike Kemp/In Pictures via Getty Images</figcaption>
    </figure>

  <p id="YK2m5q">The most important thing to know about social media is this: Most people don’t post.</p>
<p id="xmE0LH">You know this. I know this. God knows this. I am going to limit my analysis to text-based sites because video sites such as TikTok, YouTube, and Instagram <a href="https://www.theverge.com/2022/7/26/23279815/instagram-feed-kardashians-criticism-fuck-it-im-out">are not my ministry</a>. This analysis may transfer in whole or in part to those platforms, for all I know. </p>
<p id="tC5VdP">The silent majority of every successful text-based social media site <a href="https://www.reddit.com/r/slatestarcodex/comments/9rv

## Hey Google, I was using that button!
 - [https://www.theverge.com/2024/2/1/24058092/android-google-assistant-voice-removed](https://www.theverge.com/2024/2/1/24058092/android-google-assistant-voice-removed)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T21:58:09+00:00

<figure>
      <img alt="Illustration of Google’s wordmark, written in red and pink on a dark blue background." src="https://cdn.vox-cdn.com/thumbor/SbDo_3vR1uwavwj6Ok41qBeXu4s=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73104864/STK093_Google_06.0.jpg" />
        <figcaption>Illustration: The Verge</figcaption>
    </figure>

  <p id="xBGfOO">Every time another Google app or feature bites the dust — even a small, relatively inconsequential one — I get annoyed. Really annoyed.</p>
<p id="vsYgFd">Here’s the thing: there are Google Assistant-equipped devices in three rooms of my relatively small house: living room, bedroom, and office. Which means, unfortunately, that when I say “Hey, Google” out loud to my phone, I am just as likely to get a reaction from one — or more — of those three devices. (Yes, I know that’s not supposed to happen and no, we haven’t been able to fix it yet.) And they sometimes offer different answers simultaneously, which makes thi

## Apple didn’t release new iPads last year, and now its sales are way down
 - [https://www.theverge.com/2024/2/1/24058442/apple-q1-2024-earnings-iphone](https://www.theverge.com/2024/2/1/24058442/apple-q1-2024-earnings-iphone)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T21:54:50+00:00

<figure>
      <img alt="12.9-inch iPad Pro running Final Cut Pro" src="https://cdn.vox-cdn.com/thumbor/PwBMTpuzeDpLxY8nWjJHKLKS_Mo=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73104845/DSCF4643.0.jpg" />
        <figcaption>Photo by Vjeran Pavic / The Verge</figcaption>
    </figure>

  <p id="QT5swv">Tomorrow, Apple will launch its <a href="https://www.theverge.com/24054862/apple-vision-pro-review-vr-ar-headset-features-price">Vision Pro headset</a>, marking the company’s most high-profile product launch since the original Apple Watch. And later this year, it will <a href="https://www.theverge.com/2024/1/25/24050200/apple-third-party-app-stores-allowed-iphone-ios-europe-digital-markets-act">open up the iPhone’s App Store</a> (at least in the EU) in new ways, offering developers more freedom — even if some of them are already displeased with <a href="https://www.theverge.com/2024/1/26/24051823/apple-third-party-app-stores-50-cent-fee">the approach Apple

## Here are the best Kindle deals right now
 - [https://www.theverge.com/21539047/best-amazon-kindle-deals](https://www.theverge.com/21539047/best-amazon-kindle-deals)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T21:54:18+00:00

<figure>
      <img alt="The Kindle Scribe against a background of yellow post-it notes." src="https://cdn.vox-cdn.com/thumbor/sy1qnQqBUeP0pqWBjyudXqnLBFY=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/67715739/226417__Amazon_Kindle_Scribe_AKrales_0197.35.jpg" />
        <figcaption><em>The Kindle Scribe is on sale as a part of a bundle.</em></figcaption>
    </figure>

  <p id="c0dokh">When it comes to finding a device to use to read your ebooks, you have a few options to choose from. You can always buy a tablet or use your phone, but those devices are multipurpose and can be used for a ton of things, like surfing the web or doom-scrolling on Twitter. If you are looking for something to strictly read books, e-readers, while niche, are designed to store all of your books in a virtual library with limited functionality. </p>
<div class="c-float-left c-float-hang"><aside id="slqpER"><div></div></aside></div>
<p id="pDKHVT">Amazon, one of the pioneers of the 

## OpenAI says there’s only a small chance ChatGPT will help create bioweapons
 - [https://www.theverge.com/2024/2/1/24058095/open-ai-bioweapon-study-preparedness-team](https://www.theverge.com/2024/2/1/24058095/open-ai-bioweapon-study-preparedness-team)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T21:13:58+00:00

<figure>
      <img alt="An image of OpenAI’s logo, which looks like a stylized and symmetrical braid." src="https://cdn.vox-cdn.com/thumbor/K5udACs-VorJkrx9vMKFH5ar1bM=/0x0:1820x1213/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73104707/lp_logo_3.0.0.jpg" />
        <figcaption>Image: OpenAI</figcaption>
    </figure>

  <p id="SLQPfx">OpenAI’s GPT-4 only gave people a slight advantage over the regular internet when it came to researching bioweapons, according to a study the company conducted itself. <em>Bloomberg</em> reported that the research was carried out by the <a href="https://www.bloomberg.com/news/articles/2024-01-31/openai-says-gpt-4-poses-limited-risk-of-helping-create-bioweapons">new preparedness team</a> at OpenAI, which was launched last fall in order to assess the <a href="https://www.theverge.com/2023/10/26/23933783/openai-preparedness-team-catastrophic-risks-ai">risks and potential misuses</a> of the company’s frontier AI models.</p>
<p id="UQQw0m">O

## Amazon made an AI bot to talk you through buying more stuff on Amazon
 - [https://www.theverge.com/2024/2/1/24058381/amazon-ai-shopping-assistant-rufus](https://www.theverge.com/2024/2/1/24058381/amazon-ai-shopping-assistant-rufus)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T21:10:02+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/AFHI5aRRpOmf34jyhWjNHalAtrc=/103x0:1218x743/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73104680/amazon_rufus_ai_assistant.0.jpg" />
        <figcaption>Image: Amazon</figcaption>
    </figure>

  <p id="iP0lp9"><a href="https://www.aboutamazon.com/news/retail/amazon-rufus">Amazon has taken the wraps</a> off of an AI shopping assistant, and it’s called Rufus — the same name as the <a href="https://www.amazon.com/gp/help/customer/display.html?nodeId=3711811">company’s corgi mascot</a>. The new chatbot is trained on Amazon’s product library and customer reviews, as well as information from the web, allowing it to answer questions about products, make comparisons, provide suggestions, and more.</p>
<p id="bn6Bnc">Rufus is still in beta and will only appear for “select customers” before rolling out to more users in the coming weeks. If you have access to the beta, you can open up a chat with Rufus by launchin

## YouTube now has more than 100 million Premium subscribers
 - [https://www.theverge.com/2024/2/1/24058265/youtube-premium-music-100-million-subscribers](https://www.theverge.com/2024/2/1/24058265/youtube-premium-music-100-million-subscribers)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T20:59:15+00:00

<figure>
      <img alt="YouTube’s logo with geometric design in the background" src="https://cdn.vox-cdn.com/thumbor/WwQ0hUKWuSheNnH9S61OFJbV9lY=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73104630/acastro_STK092_04.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="LH2d0l">YouTube reached an important milestone on Thursday for its paid music and video tiers, crossing the <a href="https://blog.youtube/news-and-events/youtube-music-premium-100-million-subscribers/">100 million subscriber</a> benchmark globally. That figure includes trial subscriptions, so the real number of paid subscribers is fewer. YouTube’s subscription tiers have been a <a href="https://www.theverge.com/2024/1/30/24056132/google-spent-two-billion-on-layoffs-severance-fourth-quarter-earnings-2023">primary revenue generator</a> for Google’s subscriptions services, which hit <a href="https://variety.com/2024/digital/news/youtube-g

## Chip race: Microsoft, Meta, Google, and Nvidia battle it out for AI chip supremacy
 - [https://www.theverge.com/2024/2/1/24058186/ai-chips-meta-microsoft-google-nvidia](https://www.theverge.com/2024/2/1/24058186/ai-chips-meta-microsoft-google-nvidia)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T20:20:35+00:00

<figure>
      <img alt="An illustration of a cartoon brain with a computer chip imposed on top." src="https://cdn.vox-cdn.com/thumbor/mPQvGtvu5QJ9aw_u5rGLfQH3wX4=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73104529/acastro_181017_1777_brain_ai_0002.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p>Tech companies want AI to grow. To do that, they need more and more powerful chips. </p>
  <p>
    <a href="https://www.theverge.com/2024/2/1/24058186/ai-chips-meta-microsoft-google-nvidia">Continue reading&hellip;</a>
  </p>

## Car-tech breakup fever is heating up
 - [https://www.theverge.com/2024/2/1/24058174/polestar-motional-break-up-interest-rate-ev-demand-av](https://www.theverge.com/2024/2/1/24058174/polestar-motional-break-up-interest-rate-ev-demand-av)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T19:28:37+00:00

<figure>
      <img alt="Polestar badge" src="https://cdn.vox-cdn.com/thumbor/nuacW87dIDqBSzGtfY70bIn04DE=/0x2:5846x3899/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73104354/1245969948.0.jpg" />
        <figcaption>Photo by Beata Zawrzel/NurPhoto via Getty Images</figcaption>
    </figure>

  <p id="PUeZLa">It’s not you, it’s the interest rates. </p>
<p id="LeMwcq">The reasons are probably more nuanced than that, but a number of prominent car tech companies are finding themselves in the unenviable position of being dumped by the bigger companies that they’ve relied on for funding. It’s especially harsh when you consider we’re a few weeks away from Valentine’s Day. </p>
<p id="57whEx">It started earlier this week, when auto parts giant Aptiv said it was <a href="https://www.reuters.com/business/autos-transportation/aptiv-beats-quarterly-profit-estimates-strong-demand-auto-parts-2024-01-31/">pulling funding from Motional</a>, the robotaxi joint venture it started with H

## Meta’s Quest headsets add spatial video and pinch controls to compete with Vision Pro
 - [https://www.theverge.com/2024/2/1/24058088/meta-quest-3-spatial-video-vision-pro](https://www.theverge.com/2024/2/1/24058088/meta-quest-3-spatial-video-vision-pro)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T18:17:59+00:00

<figure>
      <img alt="An image showing someone watching a spatial video on Quest 3" src="https://cdn.vox-cdn.com/thumbor/aNxXLIVP85X2VESCdJdWWiZtzLg=/61x0:720x439/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73104087/meta_spatial_vid.0.png" />
        <figcaption>Image: Meta</figcaption>
    </figure>

  <p id="gzM6W7">The Meta Quest 3 will soon give wearers the ability to easily view spatial videos as well as use new pinching gestures for control, features that are similar to what you’ll find in Apple’s much more expensive Vision Pro headset that launches this week. Both changes are starting to roll out gradually<a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.meta.com%2Fblog%2Fquest%2Fv62-software-update-spatial-video-playback-gamepad-support-browswer%2F&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2024%2F2%2F1%2F24058088%2Fmeta-quest-3-spatial-video-vision-pro" rel="sponsored nofollow noopener" targe

## The Nintendo Switch has received a rare discount at Amazon
 - [https://www.theverge.com/2024/2/1/24058134/nintendo-switch-deal-sale-amazon](https://www.theverge.com/2024/2/1/24058134/nintendo-switch-deal-sale-amazon)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T18:16:40+00:00

<figure>
      <img alt="Someone playing The Legend of Zelda: Breath of the Wild on a Nintendo Switch handheld console." src="https://cdn.vox-cdn.com/thumbor/5aK19hyskOGaP7xFZwNUSc_tqW4=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73104079/jbareham_1492_170228_0173.0.0.jpg" />
        <figcaption><em>The standard Nintendo Switch can be played on the go or while docked on a TV.</em> | Photo by James Bareham / The Verge</figcaption>
    </figure>

  <p id="OyWV9S">While the <a href="https://www.theverge.com/24051677/nintendo-switch-2-pro-rumors-news">Nintendo Switch 2 is widely expected</a> to drop this year, it’s anybody’s guess when. That means if you don’t want to wait to play games like the <a href="https://www.theverge.com/2024/1/31/24057632/the-mario-vs-donkey-kong-demo-just-hit-nintendo-switch"><em>Mario vs. Donkey Kong</em> demo</a> and <a href="https://www.theverge.com/23718926/zelda-tears-of-the-kingdom-review-nintendo-switch"><em>The Legend of Z

## The Arc browser is getting better bookmarks and search results, all thanks to AI
 - [https://www.theverge.com/2024/2/1/24058013/arc-browser-smart-folders-browse-for-me-ai](https://www.theverge.com/2024/2/1/24058013/arc-browser-smart-folders-browse-for-me-ai)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T17:54:12+00:00

<figure>
      <img alt="A screenshot showing someone searching in Arc." src="https://cdn.vox-cdn.com/thumbor/A1KP_Yf2AmJbcPwYX_Ex1aWdszU=/241x0:2317x1384/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103987/CleanShot_2024_02_01_at_12.50.41.0.png" />
        <figcaption>Arc’s new Smart Folders start with an AI query. | Image: The Browser Company</figcaption>
    </figure>

  <p id="Ft0d4I">Only a few days after releasing an AI-powered mobile app, <a href="https://www.theverge.com/2024/1/28/24053882/arc-search-browser-web-app-ios">called Arc Search</a>, The Browser Company is making some big (and of course AI-powered) changes to its desktop browser as well.</p>
<p id="1MyRs9">Unlike Arc Search, though, which is essentially a total rethink of how you use the web on your phone, the new stuff in Arc for Mac and Windows is more straightforward and practical. They turn search queries into bookmarks without needing a Google page, and they keep you up to date on stuff you car

## Snap is recalling and refunding every drone it ever sold
 - [https://www.theverge.com/2024/2/1/24058119/snap-recall-pixy-drone-refund](https://www.theverge.com/2024/2/1/24058119/snap-recall-pixy-drone-refund)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T16:57:53+00:00

<figure>
      <img alt="A yellow drone shaped like a rounded rectangle instead of exposed blades — it has translucent orange propellers within its boxy but thin frame." src="https://cdn.vox-cdn.com/thumbor/TulENKGj4HFI4INWYKG2ZYaD19o=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103812/vpavic_220418_5168_0124.0.jpg" />
        <figcaption><em>The Snap Pixy.</em> | Photo by Vjeran Pavic / The Verge</figcaption>
    </figure>

  <p id="Kqkg08">Snap gave up on its Pixy flying selfie camera drone <a href="https://www.theverge.com/2022/8/18/23311542/snap-pixy-drone-giving-up-four-months">after just four months</a>, but it turns out the company sold under 71,000 drones — and now the company is recalling every one of those drones because their batteries pose a fire hazard. Yes, the entire drone is being recalled, not just the removable battery, likely because Snap doesn’t make those batteries anymore.</p>
<div class="c-float-left c-float-hang"><aside id="E7Mr

## Anker’s workout-friendly Soundcore Sport X10 earbuds are a bargain at just $56
 - [https://www.theverge.com/2024/2/1/24057506/anker-soundcore-sport-x10-earbuds-amazon-fire-tv-soundbar-apple-watch-deal-sale](https://www.theverge.com/2024/2/1/24057506/anker-soundcore-sport-x10-earbuds-amazon-fire-tv-soundbar-apple-watch-deal-sale)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T16:34:28+00:00

<figure>
      <img alt="An image of Soundcore’s Sport X10 earbuds next to a weight." src="https://cdn.vox-cdn.com/thumbor/BoeARogOyr9dC2ue6_fKPy9uaeM=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103736/DSCF0068.0.jpg" />
        <figcaption><em>Anker’s Soundcore Sport X10 offers wraparound hooks and an IPX7 rating for water and sweat resistance for less than $60.</em> | Photo by Chris Welch / The Verge</figcaption>
    </figure>

  <p id="rEaZyk">If you’ve already broken your New Year’s health-related resolutions, today’s lead deal might get you back on track. Right now, <strong>Anker’s Soundcore Sport X10 </strong>— an <a href="https://www.theverge.com/23413809/best-workout-fitness-running-earbuds">excellent budget-friendly pair of workout earbuds</a> —<strong> </strong>are on sale at <a href="https://www.amazon.com/Soundcore-Bluetooth-Headphones-Waterproof-Sweatproof/dp/B09WMJCQRM?tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">

## Senators find tech CEOs’ responses hollow after four-hour hearing
 - [https://www.theverge.com/2024/2/1/24057460/senators-confront-meta-tiktok-snap-x-discord-ceos-kids-online-harm](https://www.theverge.com/2024/2/1/24057460/senators-confront-meta-tiktok-snap-x-discord-ceos-kids-online-harm)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T16:26:46+00:00

<figure>
      <img alt="Sen. Lindsey Graham (R-SC) speaks at a press conference following the Senate Judiciary Committee hearing with five tech CEOs." src="https://cdn.vox-cdn.com/thumbor/F4C-cWkuFHOMR7hvFAnsvVTr8jw=/0x168:4032x2856/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103704/IMG_9004.0.jpg" />
        <figcaption>Sen. Lindsey Graham (R-SC) speaks at a press conference following the Senate Judiciary Committee hearing with five tech CEOs. | Lauren Feiner</figcaption>
    </figure>

  <p id="9hTKWF">During an unusually emotional hearing on Wednesday, senators spent hours trying to get a group of five tech CEOs to confront the harms their platforms have caused and submit to more checks on their power.</p>
<p id="ZYNOzi">The Senate Judiciary Committee invited the CEOs of Meta, TikTok, Snap, X, and Discord to face the families of children who’d died following cyberbullying, sexual exploitation, or other harmful events on their platforms. They asked why Section 23

## Comcast is dropping its misleading Xfinity 10G network branding
 - [https://www.theverge.com/2024/2/1/24058006/comcast-xfinity-10g-network-branding-advertising-misleading](https://www.theverge.com/2024/2/1/24058006/comcast-xfinity-10g-network-branding-advertising-misleading)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T15:49:55+00:00

<figure>
      <img alt="A billboard advertising Comcast’s Xfinity 10G network." src="https://cdn.vox-cdn.com/thumbor/WaxMVF77YQh5h9Ff88BSP8L7mtc=/0x10:1920x1290/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103522/Comcast_Xfinity_10G_network.0.jpg" />
        <figcaption><em>Comcast can still use “10G” to describe products and services, so long as it’s being used accurately.</em> | Image: Xfinity Creative</figcaption>
    </figure>

  <p id="reUcQZ">Comcast has agreed to abandon its “Xfinity 10G network” product branding after advertising watchdogs concluded that it could cause consumers to think they will all experience “significantly faster speeds than are available on 5G networks,” which isn’t true.</p>
<p id="tZpmzB">On Wednesday, the <a href="https://bbbprograms.org/media-center/dd/comcast-10g-xfinity">National Advertising Review Board (NARB) ruled</a> that Comcast should discontinue the term “10G” both when describing the Xfinity network and within the name of 

## The Verge’s 2024 Valentine’s Day gift guide
 - [https://www.theverge.com/24048257/valentines-day-2024-gift-ideas-boyfriend-girlfriend-couples-husband-wife-partner](https://www.theverge.com/24048257/valentines-day-2024-gift-ideas-boyfriend-girlfriend-couples-husband-wife-partner)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T15:43:22+00:00

<figure>
      <img alt="Photo collage of Apple AirPods and a Polaroid camera in two bright red heart-shaped lollipops." src="https://cdn.vox-cdn.com/thumbor/nT0CmmzsxSkOrP-vY-jsIcd-JCg=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103497/246957_VDAY_GIFTGUIDE_CVirginia.0.jpg" />
        <figcaption>Cath Virginia / The Verge | Photos by Getty Images</figcaption>
    </figure>


  		 <p>We’re here to help you save time with an assortment of unique gifts that are sweeter than any candy bar.</p>
  <p>
    <a href="https://www.theverge.com/24048257/valentines-day-2024-gift-ideas-boyfriend-girlfriend-couples-husband-wife-partner">Continue reading&hellip;</a>
  </p>

## Bard generates photos now, finally
 - [https://www.theverge.com/2024/2/1/24057438/bard-gemini-imagen-google-ai-image-generation](https://www.theverge.com/2024/2/1/24057438/bard-gemini-imagen-google-ai-image-generation)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T15:00:00+00:00

<figure>
      <img alt="A graphic showing Bard’s logo with Gmail, Drive, Docs, and other apps" src="https://cdn.vox-cdn.com/thumbor/4QCLTu3NncNSmh1MThQ0Hz6FM8c=/129x0:1071x628/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103364/google_bard_extensions.0.png" />
        <figcaption>Image: Google</figcaption>
    </figure>

  <p id="LWIwbg">Google’s Bard chatbot is adding AI image generation, catching up on a feature that rival ChatGPT Plus has had for months. </p>
<p id="svaMiQ">Users can prompt Bard to generate photos using Google’s <a href="https://www.theverge.com/2023/12/13/23999988/google-cloud-debuts-its-latest-generative-ai-model">Imagen 2 text-to-image model</a>. Bard, now powered by Google’s <a href="https://www.theverge.com/2023/12/6/23989744/google-bard-gemini-model-chatbot-ai">Gemini Pro large language model</a>, was always going to have image generation. It was assumed the more powerful Gemini Ultra model would power it; however, that model remains in dev

## Hot Pod Summit returns at On Air Fest 2024
 - [https://www.theverge.com/2024/2/1/24057356/hot-pod-summit-brooklyn-2024-on-air-fest-work-x-work](https://www.theverge.com/2024/2/1/24057356/hot-pod-summit-brooklyn-2024-on-air-fest-work-x-work)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T15:00:00+00:00

<figure>
      <img alt="The logo for Hot Pod." src="https://cdn.vox-cdn.com/thumbor/lUVp-Q6MNGOiQEWiHC3xVL4dcrg=/0x0:2051x1367/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103354/Hot_Pod_Site_Post.0.jpeg" />
    </figure>

  <p id="pFCeLn"><em>The Verge</em> is delighted to announce that <a href="https://www.onairfest.com/brooklyn-2024-sessions/hot-pod-summit">Hot Pod Summit</a> is returning for another day of must-hear interviews, crucial panels, and intimate networking with leading creators and decision-makers from across the audio world. Now in its third year with <em>The Verge</em>, Hot Pod Summit has become the leading event for exploring the buzziest and most important topics in the podcasting industry.</p>
  <figure class="e-image">
        
  </figure>
<p id="tIwrmq">This year’s invite-only summit, presented by AdsWizz and Simplecast, will feature <em>This American Life</em> creator Ira Glass, <em>Throughline </em>hosts Rund Abdelfatah and Ramtin Arablouei, 

## This new retrofit door lock from Abode promises 12 months of battery life
 - [https://www.theverge.com/2024/2/1/24057581/abode-retrofit-smart-door-lock-price-release-date-features](https://www.theverge.com/2024/2/1/24057581/abode-retrofit-smart-door-lock-price-release-date-features)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T15:00:00+00:00

<figure>
      <img alt="A door lock and keypad on a kitchen counter." src="https://cdn.vox-cdn.com/thumbor/EKztdBHgo5R5cA1sjBe-pgscCXU=/850x167:3840x2160/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103377/Abode_Lock_Still_02.0.png" />
        <figcaption><em>The Abode Lock is a retrofit Wi-Fi smart door lock that comes with a Bluetooth keypad with a fingerprint reader.</em> | Image: Abode</figcaption>
    </figure>

  <p id="dIbDqk">Hot on the heels of launching <a href="https://www.theverge.com/2024/1/8/24030379/abode-edge-camera-long-range-facial-recognition-ai-ces-2024">the first Wi-Fi HaLow security camera</a>, DIY smart home security company Abode is leaning into Wi-Fi as its primary smart home protocol with the arrival of its first <a href="https://www.theverge.com/23393163/best-smart-door-lock">smart door lock</a>.</p>
<p id="LGayVB"><a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fgoabode.com%2Fproduct%2Fabode-lock&amp;r

## Apple reveals how many apps will work with the Vision Pro on day one
 - [https://www.theverge.com/2024/2/1/24057955/apple-vision-pro-apps-launch](https://www.theverge.com/2024/2/1/24057955/apple-vision-pro-apps-launch)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T14:50:58+00:00

<figure>
      <img alt="The Vision Pro sitting next to its battery." src="https://cdn.vox-cdn.com/thumbor/rMdRg3cR1F5N5wfzRVNzZ_Nmglw=/0x0:2700x1800/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103328/246965_vision_pro_VPavic_0034.0.jpg" />
        <figcaption>Photo by Vjeran Pavic / The Verge</figcaption>
    </figure>

  <p id="DRk7VQ">Apple has finally put a number on how many apps will work with the Vision Pro at launch. In an <a href="https://www.apple.com/newsroom/2024/02/apple-announces-more-than-600-new-apps-built-for-apple-vision-pro/">announcement on Thursday</a>, the company says more than 600 apps and games optimized for the <a href="https://www.theverge.com/24054862/apple-vision-pro-review-vr-ar-headset-features-price">Vision Pro</a> will be available starting on Friday.</p>
<p id="Igw5L9">In addition to the compatible <a href="https://www.theverge.com/2024/1/16/24039960/apple-vision-pro-3d-movies-disney-plus">streaming apps</a> Apple revealed last mont

## Netflix’s 2024 movie slate will put rebels on the moon and cops in Beverly Hills
 - [https://www.theverge.com/24057435/netflix-2024-movies-release-dates](https://www.theverge.com/24057435/netflix-2024-movies-release-dates)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T14:15:00+00:00

<figure>
      <img alt="A man wearing aviators and a letterman jacket leaning over to peer into the window of a parked car." src="https://cdn.vox-cdn.com/thumbor/JOennMDAHXiKCgQyu2ps4GUiODU=/644x0:5137x2995/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103224/BHCAF_Still_04_R7_MM_Edit.0.jpeg" />
        <figcaption>Image: Netflix</figcaption>
    </figure>

  <p id="jBcwNU">Though Netflix has had success in the past producing its own original feature-length projects, the streamer decided last year that it was high time to slow things down a bit and get back into the business of <a href="https://www.theverge.com/2023/11/1/23942338/netflix-asks-hey-you-wanna-see-a-dead-cinematic-universe">licensing popular movies created by other studios</a>. You can see that strategic pivot reflected pretty clearly in the lineup of new films Netflix has planned to debut through 2024. </p>
<p id="nIuuvO">But while there’s nothing quite as buzzy as, say, <a href="https://www.theverge.co

## Amazon’s Mr. & Mrs. Smith series is a clever interpolation of the classic spy fantasy
 - [https://www.theverge.com/24055841/amazon-mrs-and-mrs-smith-review-donald-glover-maya-erskine](https://www.theverge.com/24055841/amazon-mrs-and-mrs-smith-review-donald-glover-maya-erskine)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T14:00:00+00:00

<figure>
      <img alt="A woman wearing a low-cut brown dress and a gray collared shirt walking alonside a man in tan slacks and a short-sleeved blue shirt. The man and woman are walking through a park in spring. " src="https://cdn.vox-cdn.com/thumbor/GehB2OLns0fBWEGRQ1nRYPXxljQ=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103161/MAMS_S1_UT_1_220808_LEEDAV_00074RC_3000.0.jpeg" />
        <figcaption>Image: David Lee / Prime Video</figcaption>
    </figure>


  		 <p>The Mr. &amp; Mrs. Smith series starring Donald Glover and Maya Erskine cleverly reworks the original movie’s spy fantasy into a layered drama about relationships.</p>
  <p>
    <a href="https://www.theverge.com/24055841/amazon-mrs-and-mrs-smith-review-donald-glover-maya-erskine">Continue reading&hellip;</a>
  </p>

## Elgato’s new HDMI 2.1 capture cards are finally here for Xbox Series X and PS5 streaming
 - [https://www.theverge.com/2024/2/1/24056674/elgato-hdmi-2-1-capture-cards-usb-pci-e-xbox-series-x-ps5-streaming](https://www.theverge.com/2024/2/1/24056674/elgato-hdmi-2-1-capture-cards-usb-pci-e-xbox-series-x-ps5-streaming)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T14:00:00+00:00

<figure>
      <img alt="Elgato’s USB 4K X capture card" src="https://cdn.vox-cdn.com/thumbor/NS5HYQ_5GlHpbC1QfxqPCPtyoxY=/0x0:6000x4000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103181/Game_Capture_4K_X_Lifestyle_Shot_02.0.jpeg" />
        <figcaption>Image: Elgato</figcaption>
    </figure>

  <p id="7UlGZY">Elgato is finally ready to launch its HDMI 2.1 cards and on February 1st, or 2/1, no less. After <a href="https://www.theverge.com/2023/10/25/23931776/elgatos-hdmi-2-1-capture-cards-are-on-the-way">months of teasers</a>, there are now two options for gamers wanting to capture footage from the latest Xbox Series X and PS5 consoles at higher framerates and resolution. The $229.99 4K X is a new USB capture card that lets you capture at up to 4K / 144fps. If you have a full PC setup or you’re more interested in dual PC streaming, Elgato is also launching its $279.99 4K Pro, capable of supporting 8K / 60fps HDR passthrough, all while capturing at 4K / 60fps HDR.<

## Netflix’s 2024 TV lineup has more Squid Game, Arcane, and lots of reality shows
 - [https://www.theverge.com/2024/2/1/24056196/netflix-2024-tv-streaming-schedule-squid-game-arcane-3-body-problem](https://www.theverge.com/2024/2/1/24056196/netflix-2024-tv-streaming-schedule-squid-game-arcane-3-body-problem)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T14:00:00+00:00

<figure>
      <img alt="A still photo from the Netflix series Squid Game." src="https://cdn.vox-cdn.com/thumbor/StBUMlLcN-jQKUyx0ybWUZE9XvM=/0x2:4963x3311/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103153/SquidGame_Unit_102_787.0.jpg" />
        <figcaption><em>Squid Game.</em> | Image: Netflix</figcaption>
    </figure>

  <p id="s6BBOj">Things have been a little quiet for Netflix so far this year when it comes to television, but the streamer has at least a few heavy hitters in store. Today, it revealed its upcoming TV slate for 2024 — alongside <a href="https://www.theverge.com/e/23821476">similar lists for film</a> and games — and, while there aren’t a lot of surprises or new reveals, the lineup is shaping up pretty well.</p>
<p id="WviiFQ">In addition to soon-to-premiere series like <a href="https://www.theverge.com/24047888/avatar-the-last-airbender-trailer-netflix"><em>Avatar: The Last Airbender</em></a> and <a href="https://www.theverge.com/24030500/3-body-

## Lawmakers want to know how TurboTax used $94 million in tax breaks
 - [https://www.theverge.com/2024/2/1/24057309/turbotax-intuit-research-tax-credits-elizabeth-warren-letter](https://www.theverge.com/2024/2/1/24057309/turbotax-intuit-research-tax-credits-elizabeth-warren-letter)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T13:30:00+00:00

<figure>
      <img alt="A candid photo of Elizabeth Warren’s face." src="https://cdn.vox-cdn.com/thumbor/JppYjBPEVPrKwMQzyI5dcibo0_U=/1x0:6073x4048/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73103087/1948399396.0.jpg" />
        <figcaption><em>Sen. Elizabeth Warren, D-Mass., is seen after the senate luncheons in the U.S. Capitol on Tuesday, January 23, 2024.</em> | Tom Williams/CQ-Roll Call, Inc via Getty Images</figcaption>
    </figure>

  <p id="kQeGCk">Intuit, maker of TurboTax, is in another row with lawmakers — this time over how it spent $94 million in tax breaks. Senators Elizabeth Warren (D-MA), Bernie Sanders (I-VT), Richard Blumenthal (D-CT), and Representative Katie Porter (D-CA) sent a letter to Intuit yesterday blasting the company for not answering questions they have about how Intuit used the tax credits. </p>
<p id="xdIl7e">SEC <a href="https://www.sec.gov/ixviewer/ix.html?doc=/Archives/edgar/data/0000896878/000089687823000034/intu-20230731.htm">fi

## Nothing confirms Phone 2A after rumors of the affordable follow-up
 - [https://www.theverge.com/2024/2/1/24057890/nothing-phone-2a-pre-announced-smartphone-glyph](https://www.theverge.com/2024/2/1/24057890/nothing-phone-2a-pre-announced-smartphone-glyph)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T12:30:23+00:00

<figure>
      <img alt="Nothing Phone 2 sitting upright on a reflective black counter showing light strips illuminated." src="https://cdn.vox-cdn.com/thumbor/fZKxKYbUNqufQVR7oPs4fc5sRbQ=/0x0:2000x1333/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73102961/DSC05077_processed.0.jpeg" />
        <figcaption><em>The company’s pre-existing Phone 2.</em> | Photo by Allison Johnson / The Verge</figcaption>
    </figure>

  <p id="JAXIEE">The Nothing Phone 2A is official... sort of. The company confirmed the name of the upcoming device during its most recent <a href="https://youtu.be/KzhjD6B9Sk4?si=Q7Ird9XZoJONncNy&amp;t=340">community update YouTube video</a>, but that’s about all it announced. It didn’t show off much more about the phone, including its appearance, specs, or price. The name of the device was one of several announcements made in the video, which also included news of a new SDK to let third-party developers integrate with Nothing’s illuminated Glyph interface.<

## Gocycle’s CX lineup of electric cargo bikes are lightweight and foldable
 - [https://www.theverge.com/24054365/gocycle-f1-cargo-e-bike-cx-series-longtail-price](https://www.theverge.com/24054365/gocycle-f1-cargo-e-bike-cx-series-longtail-price)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T10:00:00+00:00

<figure>
      <img alt="Pictured is a very clean-looking cargo bike with relatively small wheels, no exposed cables, and long telescoping seat tube, handlebar, and tail where all the cargo accessories can be mounted." src="https://cdn.vox-cdn.com/thumbor/4e5-7-bIl-U7ua12ZqVivdxLX8M=/150x0:1770x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73102716/Gocycle_CX__White_Rear_Side.0.jpg" />
        <figcaption><em>The Gocycle CX+ cargo e-bike has a unique Flofit handlebar.</em> | Image: Gocycle</figcaption>
    </figure>

  <p id="J1mwmG">Gocycle, the British e-bike company founded by a former McLaren car designer, has just taken the wraps off an innovative new electric cargo bike for families. The <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fgocycle.com%2Fgocycle-fc%2F&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F24054365%2Fgocycle-f1-cargo-e-bike-cx-series-longtail-price" rel="sponsored nofollow noopener"

## TikTok loses Taylor Swift, Drake, and other major Universal Music artists
 - [https://www.theverge.com/2024/2/1/24057839/umg-pulls-tiktok-music-ai-contract-dispute](https://www.theverge.com/2024/2/1/24057839/umg-pulls-tiktok-music-ai-contract-dispute)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T08:29:09+00:00

<figure>
      <img alt="Taylor Swift | The Eras Tour - Sao Paulo, Brazil" src="https://cdn.vox-cdn.com/thumbor/yFCLjwUFipOuDkvkPXtsmivPs_s=/0x0:6000x4000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73102634/1801114790.0.jpg" />
        <figcaption><em>Major artists like Swift have been removed from TikTok.</em> | Photo by Buda Mendes/TAS23/Getty Images for TAS Rights Management</figcaption>
    </figure>

  <p id="UcKd8h">Universal Music Group (UMG) has started removing the music catalogs of <a href="https://www.umusicpub.com/hr/Artists.aspx">performers the label represents</a> — including Taylor Swift, Drake, and Olivia Rodrigo — from TikTok after negotiations to renew licensing agreements broke down this week. The previous licensing agreement between UMG and TikTok expired on January 31st. </p>
<p id="jFCsZq">On Tuesday, <a href="https://www.theverge.com/2024/1/31/24056727/universal-music-group-umg-tiktok-music-removal-ai-pay-negotiations">UMG accused the video pla

## Google inks major new offshore wind deal
 - [https://www.theverge.com/2024/2/1/24056819/google-offshore-wind-farms-data-centers-europe](https://www.theverge.com/2024/2/1/24056819/google-offshore-wind-farms-data-centers-europe)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T06:30:00+00:00

<figure>
      <img alt="Wind turbines stand behind a large complex of buildings." src="https://cdn.vox-cdn.com/thumbor/VYwfRY6h5bFoSo9liNHTB4FJlbM=/0x1:2000x1334/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73102574/Google_Data_Center_eemshaven_wind_turbines.0.jpg" />
        <figcaption><em>Google’s data center in Eemshaven, Netherlands.</em> | Image: Google</figcaption>
    </figure>

  <p id="t5O7GE">Google announced its biggest deal yet to purchase offshore wind energy for its data centers in Europe, signing power purchase agreements to support two new wind farms off the coast of the Netherlands. </p>
<p id="O9w3ez">It’s part of Google’s plan to match all of its data center electricity consumption with clean energy generation on a 24/7 basis by 2030. To do that, the company will need to help get more renewable energy, including offshore wind, pulsing through power grids where it operates. It shared “the next step” of that plan for Europe today, where it says it’s 

## Hulu is cracking down on password sharing, just like Disney Plus and Netflix
 - [https://www.theverge.com/2024/1/31/24057641/hulu-password-sharing-crackdown](https://www.theverge.com/2024/1/31/24057641/hulu-password-sharing-crackdown)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2024-02-01T01:46:06+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/49tXAEc49TY8YEoybsxeszQlqw4=/28x0:1177x766/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/73102124/Hulu_on_Disney_Beta_Hulu_Hub_1_1200x766.0.png" />
        <figcaption>Image: Disney</figcaption>
    </figure>

  <p id="voHnXY">Hulu has just laid the groundwork to kick friends, family, and freeloaders off its streaming service unless they pay for their own accounts. This week, the company <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.hulu.com%2Fsubscriber_agreement%23%3A%7E%3Atext%3Daccess%2520the%2520Content.-%2Cm.%2520Account%2520Sharing%2C-.Unless%2520otherwise&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2024%2F1%2F31%2F24057641%2Fhulu-password-sharing-crackdown" rel="sponsored nofollow noopener" target="_blank">revised its Terms of Service</a> to explicitly ban password sharing outside of “your primary personal residence,” and it’s begun

