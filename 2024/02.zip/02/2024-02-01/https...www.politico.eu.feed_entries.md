# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## We need to be ready for war with Putin, Romania’s top general says
 - [https://www.politico.eu/article/we-need-to-be-ready-for-war-with-putin-says-romanias-top-general/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/we-need-to-be-ready-for-war-with-putin-says-romanias-top-general/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T18:22:46+00:00

Gheorghiță Vlad issued a stark warning about the state of the nation's army, calling for immediate action.

## Protesting farmers share table with EU leaders
 - [https://www.politico.eu/article/protesting-farmers-sit-table-eu-leaders-von-der-leyen-de-croo-rutte/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/protesting-farmers-sit-table-eu-leaders-von-der-leyen-de-croo-rutte/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T17:52:31+00:00

Von der Leyen, Rutte and De Croo chat with farm lobbies after EU summit.

## Spain to France: Our tomatoes are better than yours
 - [https://www.politico.eu/article/spain-france-tomatoes-gabriel-attal-pedro-sanchez/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/spain-france-tomatoes-gabriel-attal-pedro-sanchez/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T17:37:05+00:00

PM Sánchez pulps his French rivals.

## How Giorgia Meloni and French hospitality got Orbán to OK Ukraine aid
 - [https://www.politico.eu/article/how-eu-leaders-pushed-hungary-orban-ukraine-aid-support-meloni-italy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/how-eu-leaders-pushed-hungary-orban-ukraine-aid-support-meloni-italy/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T17:08:36+00:00

EU leaders on Thursday reached a deal to provide €50 billion in aid to Ukraine — with even the Hungarian prime minister on board.

## Von der Leyen faces rebellion as her party seethes over 2040 climate goal
 - [https://www.politico.eu/article/ursula-von-der-leyen-faces-rebellion-party-2040-climate-eu/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/ursula-von-der-leyen-faces-rebellion-party-2040-climate-eu/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T16:08:19+00:00

At a Wednesday meeting conservative MEPs questioned why the EU is offering new targets as farmers protest and elections loom.

## Latvia bans its sports teams from playing Russian or Belarusian squads
 - [https://www.politico.eu/article/latvia-ban-sport-team-play-russian-belarusian-squad/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/latvia-ban-sport-team-play-russian-belarusian-squad/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T14:40:09+00:00

Riga's parliament wants "to block any Russian efforts to legitimize its war crimes through the sports industry.”

## AI choice should not be ‘American or American,’ EU antitrust chief warns
 - [https://www.politico.eu/article/ai-should-not-be-american-or-american-eu-antitrust-chief-warns/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/ai-should-not-be-american-or-american-eu-antitrust-chief-warns/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T14:22:00+00:00

Europe fears a repeat of how U.S. tech giants gobbled up social media, cloud markets.

## Restaurant review: To Meli Delicatessen
 - [https://www.politico.eu/article/brussels-restaurant-review-to-meli-delicatessen/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/brussels-restaurant-review-to-meli-delicatessen/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T13:08:27+00:00

A new top spot for EU bubble workers.

## Donald Trump’s Steele dossier lawsuit dismissed by London court
 - [https://www.politico.eu/article/donald-trump-steele-dossier-lawsuit-dismissed-london-court/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/donald-trump-steele-dossier-lawsuit-dismissed-london-court/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T12:49:59+00:00

Former US president's attorney argued his client 'suffered personal and reputational damage and distress' through the dossier's 2017 publication.

## Fires and a toppled statue: Farmers clash with police by EU Parliament
 - [https://www.politico.eu/article/fires-water-cannon-toppled-statue-farmers-clash-police-eu-parliament/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/fires-water-cannon-toppled-statue-farmers-clash-police-eu-parliament/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T11:27:17+00:00

Flemish farmers drink morning beers on Place du Luxembourg as food producers rage about green tape from Brussels.

## UK minister quits politics over death threats for pro-Israel views
 - [https://www.politico.eu/article/mike-freer-politics-pro-israel-united-kingdom/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/mike-freer-politics-pro-israel-united-kingdom/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T11:12:35+00:00

Mike Freer said he feels 'lucky to be alive.'

## EU approves €50B Ukraine aid as Viktor Orbán folds
 - [https://www.politico.eu/article/ukraine-gets-eu-aid-as-orban-folds/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/ukraine-gets-eu-aid-as-orban-folds/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T10:42:25+00:00

The deal on Ukraine aid comes after a small group of leaders persuaded Hungary's PM to drop his veto on the funding package.

## Eurozone inflation dips in January as investors eye early rate cut
 - [https://www.politico.eu/article/eurozone-inflation/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/eurozone-inflation/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T10:27:09+00:00

Tax rises and end of energy subsidies will affect inflation throughout the year.

## One-on-one with the EU’s chief tech regulator
 - [https://www.politico.com/podcasts/tech?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.com/podcasts/tech?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T10:11:32+00:00

Episode Summary Executive Vice President Margrethe Vestager, the EU’s top tech regulator, is busier than ever — contending with antitrust cases, internet regulations and, soon, artificial intelligence rules. And yet, her tenure is almost up. Unless she’s chosen for a third term, Vestager will leave the European Commission later this year just as its most […]

## Election 2024: Race for the White House
 - [https://www.politico.eu/podcast/election-2024-race-for-the-white-house/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/podcast/election-2024-race-for-the-white-house/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T05:00:00+00:00

As Donald Trump’s seemingly unstoppable campaign to win the Republican nomination gathers pace, most eyes in America and the world are moving to the more important contest — between him and Joe Biden.  Trump’s resurgence is causing jitters in the Biden camp. He has a small but consistent lead in national polls. Will Biden manage […]

## Connectivity can steer Europe back to competitiveness
 - [https://www.politico.eu/sponsored-content/connectivity-can-steer-europe-back-to-competitiveness/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/sponsored-content/connectivity-can-steer-europe-back-to-competitiveness/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T04:00:00+00:00

5G-connected technologies must be deployed at scale and at speed to improve lives, drive growth and compete with China and the U.S.

## Why Greta Thunberg is up in a London court
 - [https://www.politico.eu/article/greta-thunberg-climate-activist-london-court/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/greta-thunberg-climate-activist-london-court/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T03:31:43+00:00

The climate activist has been charged with a public order offense.

## How Britain learned to love Keir Starmer’s ‘boring, snoring’ right-hand woman
 - [https://www.politico.eu/article/britain-learned-love-keir-starmer-boring-snoring-right-hand-woman-rachel-reeves-labour-shadow-chancellor/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/britain-learned-love-keir-starmer-boring-snoring-right-hand-woman-rachel-reeves-labour-shadow-chancellor/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T03:00:00+00:00

Rachel Reeves' low key approach seems to be striking a chord with voters.

## In shadow of Trump, Putin and Orbán, EU struggles to get its act together on Ukraine
 - [https://www.politico.eu/article/donald-trump-vladimir-putin-viktor-orban-european-union-act-together-ukraine/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/donald-trump-vladimir-putin-viktor-orban-european-union-act-together-ukraine/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T03:00:00+00:00

It's time for EU leaders to strike a deal — with or without taciturn Hungarian leader — to send cash to Ukraine and a message to the world.

## Netanyahu’s deal with the devil
 - [https://www.politico.eu/article/israel-likud-party-benjamin-netanyahu-deal-devil-gaza-hamas-war/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/israel-likud-party-benjamin-netanyahu-deal-devil-gaza-hamas-war/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T03:00:00+00:00

Under the cover of war, Israel’s far right and ultra-Orthodox leaders are looking to turn Israel from a liberal, largely secular democracy into something more religious, nationalist and intolerant.

## The paradox of humanitarian aid to Gaza
 - [https://www.politico.eu/article/paradox-humanitarian-aid-gaza-israel-hamas-war/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/paradox-humanitarian-aid-gaza-israel-hamas-war/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T03:00:00+00:00

Israel should explore alternative channels for aid distribution that will reach the people of Gaza rather than directly feeding Hamas.

## Toilet diplomacy: How many bathroom breaks can the EU force Viktor Orbán to take?
 - [https://www.politico.eu/article/toilet-diplomacy-bathroom-breaks-force-viktor-orban-hungary-council-eu-budget/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/toilet-diplomacy-bathroom-breaks-force-viktor-orban-hungary-council-eu-budget/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: https://www.politico.eu/feed
 - date published: 2024-02-01T03:00:00+00:00

To get approval for its budget, EU leaders could ask the Hungarian leader to once again leave the room.

