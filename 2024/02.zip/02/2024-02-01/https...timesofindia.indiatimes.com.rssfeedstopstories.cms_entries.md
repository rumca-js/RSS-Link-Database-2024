# Source:Times of India, URL:https://timesofindia.indiatimes.com/rssfeedstopstories.cms, language:en-gb

## Defence budget: Budget artillery for deep tech, LAC roads
 - [https://timesofindia.indiatimes.com/business/budget/defence-budget-budget-artillery-for-deep-tech-lac-roads/articleshow/107338083.cms](https://timesofindia.indiatimes.com/business/budget/defence-budget-budget-artillery-for-deep-tech-lac-roads/articleshow/107338083.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T22:54:27+00:00



## Focus was on development & our track record, not revdi: FM
 - [https://timesofindia.indiatimes.com/business/budget/focus-was-on-development-our-track-record-not-revdi-fm-sitharaman/articleshow/107336779.cms](https://timesofindia.indiatimes.com/business/budget/focus-was-on-development-our-track-record-not-revdi-fm-sitharaman/articleshow/107336779.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T22:31:03+00:00

Finance Minister Nirmala Sitharaman emphasized that the Centre aimed to avoid any populist measures in the Budget, opting instead to showcase the government's 10-year track record of reforms and development to convey its message to the public. Sitharaman elaborated on the key messages in interviews with Doordarshan and during a press conference following the Budget announcement.

## After 3 calls on guv, Champai Soren invited to form govt
 - [https://timesofindia.indiatimes.com/india/after-3-calls-on-governor-in-48-hours-champai-invited-to-form-government/articleshow/107337084.cms](https://timesofindia.indiatimes.com/india/after-3-calls-on-governor-in-48-hours-champai-invited-to-form-government/articleshow/107337084.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T22:27:55+00:00

On Thursday night, Governor CP Radhakrishnan of Jharkhand extended an invitation to Champai Soren, the chosen candidate for Chief Minister from the JMM-Congress-RJD coalition, to establish a new government in the state. This development came after Hemant Soren's resignation from the position and his subsequent arrest by the ED in connection with a land scam case the previous night. A statement from Raj Bhavan officially confirmed the governor's decision.

## Investors want Byju out of Byju's, revamp of board
 - [https://timesofindia.indiatimes.com/business/india-business/investors-seek-revamp-of-byjus-board-want-ceo-byju-raveendran-out/articleshow/107336827.cms](https://timesofindia.indiatimes.com/business/india-business/investors-seek-revamp-of-byjus-board-want-ceo-byju-raveendran-out/articleshow/107336827.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T22:20:00+00:00

Prominent stakeholders in the educational technology startup Byju's are advocating for a change in leadership, expressing discontent with the current CEO and founder Byju Raveendran. The company's valuation has sharply declined from $22 billion to $250 million within a span of less than two years. In a notable development, a faction of the primary investors has formally requested an extraordinary general meeting (EGM) for Think &amp; Learn (T&amp;L), Byju's parent company, to discuss the restructuring of the board and a shift in the company's leadership.

## Shringar Gauri puja resumes in Gyanvapi cellar after 30 yrs
 - [https://timesofindia.indiatimes.com/india/shringar-gauri-puja-resumes-in-gyanvapi-cellar-after-30-years/articleshow/107336407.cms](https://timesofindia.indiatimes.com/india/shringar-gauri-puja-resumes-in-gyanvapi-cellar-after-30-years/articleshow/107336407.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T22:03:06+00:00

Vedic chants and the gentle sound of prayer bells echoed through the southern cellar of Gyanvapi Masjid for the initial time in three decades on Thursday morning. This followed Varanasi district judge Ajaya Krishna Vishvesha's decision to permit a family of priests to recommence the worship of Shringar Gauri and other Hindu deities in that section of the contested location.

## 1 crore taxpayers to get big relief from small & old tax disputes
 - [https://timesofindia.indiatimes.com/business/budget/1-crore-taxpayers-to-get-big-relief-from-small-old-tax-disputes/articleshow/107336390.cms](https://timesofindia.indiatimes.com/business/budget/1-crore-taxpayers-to-get-big-relief-from-small-old-tax-disputes/articleshow/107336390.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T22:01:01+00:00

An official announced on Thursday that the government plans to withdraw approximately 1.1 crore disputed tax demands, amounting to Rs 3,500 crore, for the period up to 2014-15, as part of a Budget relief measure aimed at small taxpayers. Currently, there are nearly 2.7 crore disputed tax demands pending at various levels, with 2.1 crore of them valued at less than Rs 25,000.

## Govt plans White Paper on UPA’s economy mismanagement
 - [https://timesofindia.indiatimes.com/business/budget/govt-plans-white-paper-on-upas-eco-mismanagement-latest-news/articleshow/107336376.cms](https://timesofindia.indiatimes.com/business/budget/govt-plans-white-paper-on-upas-eco-mismanagement-latest-news/articleshow/107336376.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T21:52:05+00:00

When the NDA government came into power in 2014, there was significant pressure to publish a White Paper detailing the state of the economy and the track record of the previous UPA administration. However, the government resisted this demand, showing restraint due to concerns that an official report highlighting the precarious state of the economy, particularly with public sector banks struggling with bad loans, would exacerbate international pessimism.

## Budget reflects govt’s belief in Bharat triumphing over India
 - [https://timesofindia.indiatimes.com/business/budget/budget-reflects-govts-belief-in-bharat-triumphing-over-india/articleshow/107336287.cms](https://timesofindia.indiatimes.com/business/budget/budget-reflects-govts-belief-in-bharat-triumphing-over-india/articleshow/107336287.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T21:43:44+00:00

The contrast couldn't have been more pronounced. Exactly five years later, the Modi government utilized Piyush Goyal's presentation of the Interim Budget to convey significant political gestures, including the introduction of the Kisan Samman Nidhi and the exemption of income up to Rs 5 lakh from taxes. FM Nirmala Sitharaman defied the expectation of a hike in Kisan Samman Nidhi.

## Maldives ties choppy, India doubles aid
 - [https://timesofindia.indiatimes.com/business/budget/maldives-ties-choppy-india-doubles-aid/articleshow/107336292.cms](https://timesofindia.indiatimes.com/business/budget/maldives-ties-choppy-india-doubles-aid/articleshow/107336292.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T21:43:39+00:00

Despite the challenges in the relationship with the Maldives, Delhi remains committed to emphasizing development initiatives in the Indian Ocean archipelago. In terms of aid to foreign governments, India adjusted its budget allocation for the Maldives in the fiscal year 2023-24, increasing it from Rs 400 crore to Rs 770 crore. Additionally, for the fiscal year 2024-25, India has allocated Rs 600 crore for the Maldives, making it the second-highest allocation after Bhutan and Nepal.

## Breakthrough IVF baby turns dad at same Mumbai hospital
 - [https://timesofindia.indiatimes.com/india/breakthrough-ivf-baby-turns-dad-at-same-mumbai-hospital/articleshow/107336118.cms](https://timesofindia.indiatimes.com/india/breakthrough-ivf-baby-turns-dad-at-same-mumbai-hospital/articleshow/107336118.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T21:35:57+00:00

Nearly three decades ago, a couple from Chembur celebrated the arrival of their only son, heralding a "scientific breakthrough" that addressed male infertility. The child, named Luv Singh, marked a significant milestone as India's first ICSI (intracytoplasmic sperm injection) baby, following the birth of a Belgian baby through a similar method two years prior and India's first test-tube baby, Harsha Chavda-Shah, nearly eight years earlier.

## Reduced deficit, lower debt set to push down interest rates
 - [https://timesofindia.indiatimes.com/business/budget/reduced-deficit-lower-government-debt-set-to-push-down-interest-rates/articleshow/107336114.cms](https://timesofindia.indiatimes.com/business/budget/reduced-deficit-lower-government-debt-set-to-push-down-interest-rates/articleshow/107336114.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T21:20:20+00:00

The provisional budget has set the stage for reduced home loan costs and lower interest rates overall, as indicated by financial institutions. The decrease in the fiscal deficit to 5.1% has resulted in borrowing being nearly Rs 1 lakh crore less than anticipated. Additionally, with a greater portion of government expenditure directed towards capital expenditure (capex), the move is expected to be non-inflationary, facilitating potential future rate reductions by the RBI.

## Indian-American student dies in Ohio, probe on
 - [https://timesofindia.indiatimes.com/nri/us-canada-news/indianamerican-student-dies-in-ohio-investigation-underway/articleshow/107336111.cms](https://timesofindia.indiatimes.com/nri/us-canada-news/indianamerican-student-dies-in-ohio-investigation-underway/articleshow/107336111.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T21:19:34+00:00

The Consulate General of India in New York stated that police are investigating the death of an Indian-American student in Ohio, emphasizing that foul play is not currently suspected in the case. Benigeri was a student of the Lindner School of Business, Cincinnati. The consulate continues to remain in touch with the family and is extending all possible assistance to them, it said.

## FM shuns sweeteners, focuses on fiscal fitness
 - [https://timesofindia.indiatimes.com/business/budget/nirmala-sitharamans-budget-signals-confidence-in-election-outcome/articleshow/107336084.cms](https://timesofindia.indiatimes.com/business/budget/nirmala-sitharamans-budget-signals-confidence-in-election-outcome/articleshow/107336084.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T21:01:00+00:00

The budget introduced by finance minister Nirmala Sitharaman sent out a strong message about the outcome of the 2024 Lok Sabha elections. It did not include any tax sweeteners or populist announcements and focused on showcasing the government's achievements, such as har ghar jal, electricity-for-all, and cooking gas-for-all schemes. It also highlighted the importance of social justice and fiscal discipline.

## Govt to set up panel to tackle population growth challenges
 - [https://timesofindia.indiatimes.com/business/budget/government-to-set-up-panel-to-tackle-challenges-of-population-growth/articleshow/107336069.cms](https://timesofindia.indiatimes.com/business/budget/government-to-set-up-panel-to-tackle-challenges-of-population-growth/articleshow/107336069.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T20:47:58+00:00

A "high-powered committee" will be established by the government to assess the "challenges posed by rapid population growth and demographic shifts." Finance Minister Nirmala Sitharaman, during her Interim Budget speech, emphasized that the committee's mandate would involve providing comprehensive recommendations to effectively tackle these challenges within the framework of the 'Viksit Bharat' goal.

## Risking life for Rs 1.4 lakh/month: Queue grows for Israel jobs
 - [https://timesofindia.indiatimes.com/india/us-beats-token-resistance-over-pannun-issue-approves-sale-of-drones-to-india/articleshow/107336065.cms](https://timesofindia.indiatimes.com/india/us-beats-token-resistance-over-pannun-issue-approves-sale-of-drones-to-india/articleshow/107336065.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T20:46:49+00:00

Ravindra Yadav, a 27-year-old iron bender from Uttar Pradesh's Lakhimpur Kheri, echoed the sentiments of many skilled laborers selected for jobs in Israel, seeing the opportunity as a means of improving their families' livelihoods. Israel's call for 10,000 temporary construction workers to address a labor shortage resulting from its conflict with Hamas prompted thousands of Indians to gather at a recruitment center in Rohtak.

## Gyanvapi case: SC refuses urgent hearing, tells mosque panel to move HC
 - [https://timesofindia.indiatimes.com/india/go-to-high-court-supreme-court-tells-mosque-panel-refuses-urgent-hearing/articleshow/107335995.cms](https://timesofindia.indiatimes.com/india/go-to-high-court-supreme-court-tells-mosque-panel-refuses-urgent-hearing/articleshow/107335995.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T20:35:34+00:00

Accusing the local authority of undue haste in implementing the lower court's order permitting puja in the southern cellar of the Gyanvapi mosque, its custodian, Anjuman Intezamia Masjid, approached the Supreme Court overnight for an urgent hearing. However, the SC registry rejected its plea and directed the committee to pursue recourse through the Allahabad High Court against the lower court's order.

## India expresses deep concern about UN relief workers' 'hand' in Hamas attack
 - [https://timesofindia.indiatimes.com/india/india-deeply-concerned-about-allegations-of-un-relief-workers-hand-in-hamas-attack/articleshow/107335977.cms](https://timesofindia.indiatimes.com/india/india-deeply-concerned-about-allegations-of-un-relief-workers-hand-in-hamas-attack/articleshow/107335977.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T20:22:39+00:00

The Indian government expressed deep concern on Thursday regarding Israel's allegations that UNRWA staff were involved in Hamas attacks on Israel. They welcomed a probe by the UN agency into the issue. Unlike some western countries, India has not announced any reduction in its funding of the UN agency. However, it has consistently condemned terrorist attacks by Hamas.

## After a dozen orders in Gyanvapi case, district judge retires
 - [https://timesofindia.indiatimes.com/india/after-a-dozen-orders-in-gyanvapi-case-district-judge-retires/articleshow/107335971.cms](https://timesofindia.indiatimes.com/india/after-a-dozen-orders-in-gyanvapi-case-district-judge-retires/articleshow/107335971.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T20:17:13+00:00

The court verdict allows worship of Shringar Gauri and other Hindu deities inside Gyanvapi Masjid. Varanasi district judge Ajaya Krishna Vishvesha, who handled the Shringar Gauri case, issued over a dozen orders related to the disputed site. Vishvesha directed ASI to survey the Gyanvapi compound, revealing that a Hindu temple existed where the masjid stands.

## Gyanvapi steel barricades cut for priest-access corridor
 - [https://timesofindia.indiatimes.com/india/gyanvapi-mosque-steel-barricades-cut-for-priestaccess-corridor/articleshow/107335963.cms](https://timesofindia.indiatimes.com/india/gyanvapi-mosque-steel-barricades-cut-for-priestaccess-corridor/articleshow/107335963.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T20:12:04+00:00

Late Wednesday, in compliance with the district judge's order, arrangements were made to create a passage for priests to enter the southern cellar of the Gyanvapi mosque. This involved cutting a section of the double-layered steel barricade, measuring 7 feet by 7 feet, to install a steel gate and facilitate access. Divisional commissioner Kaushal Raj Sharma confirmed that these measures were implemented.

## Cops bring back runaway groom in Uttar Pradesh's Prayagraj
 - [https://timesofindia.indiatimes.com/city/allahabad/cops-bring-back-runaway-groom-in-uttar-pradeshs-prayagraj/articleshow/107335890.cms](https://timesofindia.indiatimes.com/city/allahabad/cops-bring-back-runaway-groom-in-uttar-pradeshs-prayagraj/articleshow/107335890.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T20:09:18+00:00



## Only priest, not devotees, allowed into southern cellar: Divisional commissioner
 - [https://timesofindia.indiatimes.com/india/only-priest-not-devotees-allowed-into-southern-cellar-divisional-commissioner/articleshow/107335844.cms](https://timesofindia.indiatimes.com/india/only-priest-not-devotees-allowed-into-southern-cellar-divisional-commissioner/articleshow/107335844.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T19:54:43+00:00

Varanasi divisional commissioner Kaushal Raj Sharma on Thursday clarified that while a priest was granted access, devotees were not permitted inside the southern cellar of the Gyanvapi mosque, as per a court order. He refuted lawyer Vishnu Shankar Jain's claim that general devotees could enter the cellar to offer prayers, affirming that only the plaintiffs and the designated priest were allowed entry.

## Final year BArch student of IIT(BHU) found dead
 - [https://timesofindia.indiatimes.com/city/varanasi/final-year-barch-student-of-iitbhu-found-dead/articleshow/107335790.cms](https://timesofindia.indiatimes.com/city/varanasi/final-year-barch-student-of-iitbhu-found-dead/articleshow/107335790.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T19:44:29+00:00

Late Wednesday, authorities reported the tragic discovery of the body of Utkarsh Raj, a final-year BArch student at IIT (BHU) in Varanasi. Utkarsh, aged 23, was found in his hostel room. According to police sources on Thursday, Utkarsh had been battling depression and had been seeking support through counselling sessions.

## Shiva temple desecration sparks tension in MP town
 - [https://timesofindia.indiatimes.com/india/shiva-temple-desecration-sparks-tension-in-madhya-pradesh-town/articleshow/107335783.cms](https://timesofindia.indiatimes.com/india/shiva-temple-desecration-sparks-tension-in-madhya-pradesh-town/articleshow/107335783.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T19:43:30+00:00



## 15 get life term for razing Dalit homes, killing infant
 - [https://timesofindia.indiatimes.com/india/15-get-life-term-for-razing-dalit-homes-killing-infant/articleshow/107335712.cms](https://timesofindia.indiatimes.com/india/15-get-life-term-for-razing-dalit-homes-killing-infant/articleshow/107335712.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T19:33:32+00:00

A dedicated SC/ST court in Mathura has handed down life imprisonment to 15 individuals belonging to an upper caste community, marking the conclusion of a harrowing saga of caste-based violence that unfolded over two decades. The origins of this case trace back to January 23, 2001, when a group of men in Datiya village, Mathura, unleashed a barrage of gunfire on Dalit villagers and set ablaze their homes following a heated dispute over gram panchayat land.

## Indian student found dead in US, third incident in a week
 - [https://timesofindia.indiatimes.com/india/indian-student-found-dead-in-cincinnati-investigation-underway/articleshow/107335282.cms](https://timesofindia.indiatimes.com/india/indian-student-found-dead-in-cincinnati-investigation-underway/articleshow/107335282.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T18:50:26+00:00



## Champai Soren to be sworn in as Jharkhand CM today, gets governor's invite
 - [https://timesofindia.indiatimes.com/india/jharkhand-governor-invites-champai-soren-to-form-government-oathtaking-ceremony-likely-tomorrow/articleshow/107335051.cms](https://timesofindia.indiatimes.com/india/jharkhand-governor-invites-champai-soren-to-form-government-oathtaking-ceremony-likely-tomorrow/articleshow/107335051.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T18:05:02+00:00

On Thursday, Jharkhand Governor CP Radhakrishnan named Champai Soren, the JMM legislative leader, as the nominated chief minister and extended an invitation for him to take the oath to lead the state government. Champai Soren is scheduled to be sworn in as the Chief Minister of Jharkhand on Friday. In the 81-member Jharkhand assembly, the Jharkhand Mukti Morcha (JMM)-led alliance has 47 MLAs.

## US approves sale of 31 MQ-9B armed drones to India for $3.99 bn
 - [https://timesofindia.indiatimes.com/world/us/us-approves-drones-sales-to-india-overcoming-token-resistance-from-lawmakers-over-pannun-issue/articleshow/107334074.cms](https://timesofindia.indiatimes.com/world/us/us-approves-drones-sales-to-india-overcoming-token-resistance-from-lawmakers-over-pannun-issue/articleshow/107334074.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T16:37:16+00:00

US State Department notifies Congress of approval for the sale of 31 MQ-9B Drones worth $3.99 billion to India, overcoming resistance from lawmakers. Sale not halted by concerns over alleged plot to kill Khalistani separatist Gurpatwant Singh Pannu. Indian officials confident about sale going through; strategic objectives include countering China and ensuring safety of international shipping lanes.

## Jadeja, Shami set to miss remainder of England Test series
 - [https://timesofindia.indiatimes.com/sports/cricket/england-in-india/ravindra-jadeja-mohammed-shami-set-to-miss-remainder-of-test-series-against-england/articleshow/107333959.cms](https://timesofindia.indiatimes.com/sports/cricket/england-in-india/ravindra-jadeja-mohammed-shami-set-to-miss-remainder-of-test-series-against-england/articleshow/107333959.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T16:26:16+00:00

India all-rounder Ravindra Jadeja will need more time to recover from his hamstring injury and along with pacer Mohammed Shami could miss the remainder of the five-match Test series against England.

## US approves sale of 31 MQ-9B armed drones to India
 - [https://timesofindia.indiatimes.com/india/biden-administration-notifies-us-congress-of-mq-9b-drone-sale-to-india-for-3-99-billion/articleshow/107333367.cms](https://timesofindia.indiatimes.com/india/biden-administration-notifies-us-congress-of-mq-9b-drone-sale-to-india-for-3-99-billion/articleshow/107333367.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T15:50:06+00:00



## Close call: Wing tips of two Japanese planes 'scratch'
 - [https://timesofindia.indiatimes.com/world/rest-of-world/close-call-wing-tips-of-two-japanese-planes-scratch-all-passengers-safe/articleshow/107331801.cms](https://timesofindia.indiatimes.com/world/rest-of-world/close-call-wing-tips-of-two-japanese-planes-scratch-all-passengers-safe/articleshow/107331801.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T15:17:14+00:00

Two All Nippon Airways (ANA) aircraft had a minor incident at Osaka's Itami airport when their wing tips 'scratched' each other. Fortunately, no injuries were reported. This incident adds to a series of aviation mishaps in Japan, including a near-catastrophic collision at Haneda airport resulting in five deaths and a wing tip strike due to snowy conditions.

## Why PM Modi's election-year Budget makes a bold statement
 - [https://timesofindia.indiatimes.com/business/budget/budget-2024-pm-modis-focus-on-women-poor-youth-and-farmers/articleshow/107332821.cms](https://timesofindia.indiatimes.com/business/budget/budget-2024-pm-modis-focus-on-women-poor-youth-and-farmers/articleshow/107332821.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T15:10:50+00:00



## Can Taylor Swift help Biden beat Trump in US polls?
 - [https://timesofindia.indiatimes.com/world/us/taylor-swifts-romance-with-travis-kelce-sparks-political-conspiracy-theories-amid-us-election-season/articleshow/107332625.cms](https://timesofindia.indiatimes.com/world/us/taylor-swifts-romance-with-travis-kelce-sparks-political-conspiracy-theories-amid-us-election-season/articleshow/107332625.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T15:04:38+00:00

Conservatives speculate that Taylor Swift and Travis Kelce's relationship is a Pentagon psychological operation to influence the presidential election. Swift's massive fan base gives her a powerful voice in politics. Both Swift and Kelce have made public statements about politics and other issues that put them at odds with the far-right.

## Watch: Zuckerberg says sorry to parents at child safety hearing
 - [https://timesofindia.indiatimes.com/gadgets-news/watch-facebook-founder-mark-zuckerberg-says-sorry-to-parents-at-child-safety-hearing/articleshow/107332509.cms](https://timesofindia.indiatimes.com/gadgets-news/watch-facebook-founder-mark-zuckerberg-says-sorry-to-parents-at-child-safety-hearing/articleshow/107332509.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T14:45:40+00:00

Meta CEO Mark Zuckerberg testified in a US Senate hearing on safeguarding kids from sexual exploitation. He was grilled by Senator Josh Hawley, who questioned Zuckerberg about firing employees and compensating victims. Zuckerberg apologized to parents of victims and pledged to invest in industry-wide efforts to protect children. Evan Spiegel, CEO of Snap, also apologized to parents whose kids overdosed on drugs bought through Snapchat.

## Chinese couple executed for throwing 2 toddlers off 15th-floor balcony
 - [https://timesofindia.indiatimes.com/world/china/chinese-couple-executed-for-throwing-2-toddlers-off-15th-floor-balcony/articleshow/107332030.cms](https://timesofindia.indiatimes.com/world/china/chinese-couple-executed-for-throwing-2-toddlers-off-15th-floor-balcony/articleshow/107332030.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T14:30:25+00:00

A couple in China has been executed for throwing and killing their two toddlers off the 15th floor of a residential tower in southwest China's Chongqing. In 2020, Zhang Bo murdered his children by pushing them from the 15th floor. Zhang Bo and his girlfriend Ye Chengchen were sentenced to death in 2021, reported Daily Mirror.

## India cuts funds to Maldives amid diplomatic standoff
 - [https://timesofindia.indiatimes.com/india/indias-financial-assistance-to-the-maldives-set-to-drop-by-22-amid-diplomatic-standoff-bhutan-gets-lions-share/articleshow/107324609.cms](https://timesofindia.indiatimes.com/india/indias-financial-assistance-to-the-maldives-set-to-drop-by-22-amid-diplomatic-standoff-bhutan-gets-lions-share/articleshow/107324609.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T14:28:52+00:00

India's development assistance to the Maldives is set to decrease by Rs 170 crore to around Rs 600 crore in the next financial year amid the diplomatic standoff between the two countries. This represents a 22% drop in funding for developmental projects in the archipelago. India slips to 5th place on Maldives' tourism charts amid diplomatic tensions.

## Still no Jharkhand CM: Champai Soren fails to get guv's invite
 - [https://timesofindia.indiatimes.com/india/jharkhand-remains-without-chief-minister-champai-soren-releases-video-roll-call-of-43-mlas-but-fails-to-get-governors-invite-to-form-govt/articleshow/107331972.cms](https://timesofindia.indiatimes.com/india/jharkhand-remains-without-chief-minister-champai-soren-releases-video-roll-call-of-43-mlas-but-fails-to-get-governors-invite-to-form-govt/articleshow/107331972.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T14:24:55+00:00

Jharkhand remains without a chief minister as the state governor has still not invited Champai Soren of the Jharkhand Mukti Morcha (JMM) to form the government. Hemant Soren, the previous chief minister, was arrested by the Enforcement Directorate. Champai Soren claims the support of 43 MLAs and is seeking to form the government.

## What's next for Paytm after RBI's curbs on Paytm Payments Bank?
 - [https://timesofindia.indiatimes.com/business/india-business/whats-next-for-paytm-after-rbis-clampdown-on-paytm-payments-bank/articleshow/107327911.cms](https://timesofindia.indiatimes.com/business/india-business/whats-next-for-paytm-after-rbis-clampdown-on-paytm-payments-bank/articleshow/107327911.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T14:05:37+00:00



## Apple AirPods drops to lowest-ever price: How to get the deal
 - [https://timesofindia.indiatimes.com/gadgets-news/apple-airpods-lowestever-price-discounts-and-how-to-get-the-deals/articleshow/107331306.cms](https://timesofindia.indiatimes.com/gadgets-news/apple-airpods-lowestever-price-discounts-and-how-to-get-the-deals/articleshow/107331306.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T13:50:17+00:00

Flipkart is currently selling the 2nd-generation Apple AirPods at a massive discount. The AirPods 2nd-generation usually sells at around Rs 12,900, but it has received a flat discount of 34% which translates to Rs 4,400. After the listed discount, Flipkart is selling the AirPods 2nd-generation at Rs 8,490. Additionally, there is a bank discount of 10% (up to Rs 1,500) applicable on Canara Bank cards. After the bank discount, the AirPods can be purchased for Rs 7,641.

## 'Sachin meets Tendulkar': Legend's special meet with fan
 - [https://timesofindia.indiatimes.com/sports/cricket/news/watch-sachin-meets-tendulkar-indian-legend-has-a-special-encounter-with-long-time-fan/articleshow/107331609.cms](https://timesofindia.indiatimes.com/sports/cricket/news/watch-sachin-meets-tendulkar-indian-legend-has-a-special-encounter-with-long-time-fan/articleshow/107331609.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T13:49:58+00:00

Former India cricketer Sachin Tendulkar shared a special moment of his meeting with a fan. Sachin on Thursday posted a video on X, when he encountered a fan who wore a Mumbai Indians jersey with Tendulkar I miss you imprinted on the back.

## Budget: Corpus of Rs 1 lakh crore to be set up for tech & innovation
 - [https://timesofindia.indiatimes.com/business/budget/budget-2024-a-corpus-of-rs-1-lakh-crore-to-be-set-up-to-finance-technology-and-innovation/articleshow/107331414.cms](https://timesofindia.indiatimes.com/business/budget/budget-2024-a-corpus-of-rs-1-lakh-crore-to-be-set-up-to-finance-technology-and-innovation/articleshow/107331414.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T13:41:47+00:00

Leveraging technology for catalyzing growth, employment and development, the government will set up a corpus of Rs 1 lakh crore with 50-year interest free loan that will provide necessary long-term finance to tech savvy youth and private sector for research and innovation. In addition, a new scheme will be launched for strengthening deep-tech technologies for defence purposes and expediting self-reliance.

## Jharkhand: JMM releases video showing support of 43 MLAs
 - [https://timesofindia.indiatimes.com/india/jharkhand-political-crisis-jmm-releases-video-showing-support-of-43-mlas/articleshow/107330516.cms](https://timesofindia.indiatimes.com/india/jharkhand-political-crisis-jmm-releases-video-showing-support-of-43-mlas/articleshow/107330516.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T13:05:54+00:00

JMM has released a video showing support of 43 MLAs in Jharkhand having 81-member assembly amid political turmoil in the state. Meanwhile, JMM legislative party leader Champai Soren met governor CP Radhakrishnan and staked a claim to form government in the state. However, the governor has not yet extended an invitation to Soren to do so.

## Sports ministry gets Rs 45 crore boost in Union Budget
 - [https://timesofindia.indiatimes.com/sports/more-sports/others/sports-ministry-gets-rs-45-crore-boost-in-union-budget/articleshow/107330258.cms](https://timesofindia.indiatimes.com/sports/more-sports/others/sports-ministry-gets-rs-45-crore-boost-in-union-budget/articleshow/107330258.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T12:43:35+00:00

The Sports Ministry was on Thursday allocated Rs 3,442.32 crore, a hike of Rs 45.36 crore as compared to last year, in the interim Union Budget presented by Finance Minister Nirmala Sitharaman. In the previous budget, the Sports Ministry had got a revised allocation of Rs 3,396.96 crore.

## Zuckerberg wants Apple, Google to take age verification responsibility
 - [https://timesofindia.indiatimes.com/gadgets-news/facebook-founder-mark-zuckerberg-says-age-verification-not-its-responsibility-points-finger-at-apple-and-google/articleshow/107329889.cms](https://timesofindia.indiatimes.com/gadgets-news/facebook-founder-mark-zuckerberg-says-age-verification-not-its-responsibility-points-finger-at-apple-and-google/articleshow/107329889.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T12:33:43+00:00

Mark Zuckerberg, CEO of Meta, appeared before the US Senate for an online safety hearing. Zuckerberg argued that app store providers, like Apple and Google, should be responsible for managing parental consent systems. He specifically targeted Apple's payments feature that requires parental approval. Zuckerberg suggested that if Apple can be the payment processor for all iOS apps, it can also provide parental consent. Meta has previously floated this idea and believes that if parents give consent and verify their child's age, it will eliminate the need for multiple age verifications across apps.

## Devotees offer prayers in southern cellar of Gyanvapi mosque
 - [https://timesofindia.indiatimes.com/india/devotees-offer-prayers-in-southern-cellar-of-gyanvapi-mosque/articleshow/107329555.cms](https://timesofindia.indiatimes.com/india/devotees-offer-prayers-in-southern-cellar-of-gyanvapi-mosque/articleshow/107329555.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T12:28:08+00:00

Devotees on Thursday offered prayers to deities in the southern cellar of Gyanvapi mosque. The prayers took place following the Madhyan Aarti from outside the barricading. District judge Ajaya Krishna Vishvesha on Wednesday allowed regular worship of Shringar Gauri and other Hindu deities in the southern cellar of Varanasi's Gyanvapi Masjid by a family of priests that used to perform rituals there prior to 1993.

## Hemant Soren sent to one-day judicial custody
 - [https://timesofindia.indiatimes.com/india/oneday-judicial-custody-for-hemant-soren-court-order-on-eds-10day-remand-plea-tomorrow/articleshow/107329101.cms](https://timesofindia.indiatimes.com/india/oneday-judicial-custody-for-hemant-soren-court-order-on-eds-10day-remand-plea-tomorrow/articleshow/107329101.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T12:15:48+00:00

Former Jharkhand CM Hemant Soren was sent to one-day judicial custody after the court reserved the order on ED's demand for 10-day remand. Soren was arrested after resigning as CM, while Champai Soren's name was proposed as the next CM. The arrest came after a marathon seven hours of grilling by the Enforcement Directorate.

## Satya Nadella wants US, China, Russia to work to stop cyberattacks
 - [https://timesofindia.indiatimes.com/gadgets-news/satya-nadella-wants-us-china-russia-and-others-to-work-together-to-stop-dangerous-cyberattacks/articleshow/107329192.cms](https://timesofindia.indiatimes.com/gadgets-news/satya-nadella-wants-us-china-russia-and-others-to-work-together-to-stop-dangerous-cyberattacks/articleshow/107329192.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T12:14:47+00:00

"If this is about nation-states attacking each other, and especially civilian targets, then we are in a very new world order. And it's a breakdown of world order, which I think we have not seen before," said the Microsoft CEO.

## Complete guide to I-T slabs after Interim Budget 2024
 - [https://timesofindia.indiatimes.com/business/budget/income-tax-slabs-2024-2025-budget-latest-tax-rates-interim-budget-new-vs-old-tax-regime-income-tax-calculator-faqs-answered/articleshow/107327673.cms](https://timesofindia.indiatimes.com/business/budget/income-tax-slabs-2024-2025-budget-latest-tax-rates-interim-budget-new-vs-old-tax-regime-income-tax-calculator-faqs-answered/articleshow/107327673.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T12:13:36+00:00

Income Tax Slabs 2024-2025: Budget 2024, which was an Interim Budgext, did not see any changes in the income tax slabs or income tax rates by Finance Minister Nirmala Sitharaman. If you as the common man, individual or salaried taxpayer are wondering what the income tax slabs and income tax rates are for financial year 2024-25 (Assessment year 2025-26), we have you covered.

## Pant feared leg amputation after horrific car crash
 - [https://timesofindia.indiatimes.com/sports/cricket/news/rishabh-pant-reveals-he-feared-leg-amputation-after-life-threatening-car-crash/articleshow/107328955.cms](https://timesofindia.indiatimes.com/sports/cricket/news/rishabh-pant-reveals-he-feared-leg-amputation-after-life-threatening-car-crash/articleshow/107328955.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T12:04:51+00:00

India wicketkeeper-batter Rishabh Pant has revealed that he feared the amputation of his right leg in the aftermath of the horrific car crash which he survived 13 months ago.

## EU agrees on a new 50 billion-euro aid package for Ukraine
 - [https://timesofindia.indiatimes.com/world/europe/european-union-agrees-on-a-new-50-billion-euro-aid-package-for-ukraine/articleshow/107327230.cms](https://timesofindia.indiatimes.com/world/europe/european-union-agrees-on-a-new-50-billion-euro-aid-package-for-ukraine/articleshow/107327230.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T11:12:01+00:00



## Apple adds last MacBook Pro with CD drive to its obsolete list
 - [https://timesofindia.indiatimes.com/gadgets-news/apple-adds-the-last-macbook-with-a-cd-drive-to-its-obsolete-list/articleshow/107326867.cms](https://timesofindia.indiatimes.com/gadgets-news/apple-adds-the-last-macbook-with-a-cd-drive-to-its-obsolete-list/articleshow/107326867.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T11:03:45+00:00

Apple declares mid-2012 MacBook Pro obsolete globally, ending support for laptops with optical drives. macOS Big Sur no longer supports this model. External SuperDrive available but needs USB-A adapter. Removal of optical drives caused controversy. Last MacBook with CD/DVD drive marks end of physical media era.

## Sarfaraz hopes to join league of legends Richards, Kohli, Miandad
 - [https://timesofindia.indiatimes.com/sports/cricket/england-in-india/after-test-callup-sarfaraz-khan-hopes-to-join-league-of-legends-richards-kohli-miandad/articleshow/107325638.cms](https://timesofindia.indiatimes.com/sports/cricket/england-in-india/after-test-callup-sarfaraz-khan-hopes-to-join-league-of-legends-richards-kohli-miandad/articleshow/107325638.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T10:35:28+00:00

Recently called up to the Indian squad for the second Test against England in Visakhapatnam, stepping in for the injured KL Rahul and Ravindra Jadeja, Sarfaraz Khan shared his admiration for the learning journey he has embarked upon. His ambition extends beyond just making it to the national team; he aspires to stand shoulder to shoulder with cricket legends such as Virat Kohli.

## Actor Darshan Jariwala steps down as VP from CINTAA
 - [https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-actor-darshan-jariwala-steps-down-as-vice-president-and-other-posts-from-cintaa/articleshow/107324764.cms](https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-actor-darshan-jariwala-steps-down-as-vice-president-and-other-posts-from-cintaa/articleshow/107324764.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T10:15:33+00:00

Actor Darshan Jariwala resigns from CINTAA after a cheating complaint. He stepped down from all three positions to protect CINTAA's reputation. Jariwala's resignation aims to spare his colleagues from trouble and promises to clear his name. General Secretary Amit Behl said, "Since it was affecting the reputation of Cintaa he has resigned from all the three positions."

## Words mentioned most by FM Sitharaman in her speech
 - [https://timesofindia.indiatimes.com/business/budget/finance-minister-nirmala-sitharaman-delivers-shortest-budget-speech-focuses-on-viksit-bharat-2047-and-tax-benefits/articleshow/107321906.cms](https://timesofindia.indiatimes.com/business/budget/finance-minister-nirmala-sitharaman-delivers-shortest-budget-speech-focuses-on-viksit-bharat-2047-and-tax-benefits/articleshow/107321906.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T09:30:14+00:00



## Who gained and who lost in Modi govt's last Budget before Lok Sabha polls
 - [https://timesofindia.indiatimes.com/business/budget/union-budget-2024-who-gained-and-who-lost-in-modis-last-budget-before-lok-sabha-polls/articleshow/107322472.cms](https://timesofindia.indiatimes.com/business/budget/union-budget-2024-who-gained-and-who-lost-in-modis-last-budget-before-lok-sabha-polls/articleshow/107322472.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T09:14:49+00:00

India has planned to promote post-harvest activities and self-reliance on oilseeds. The government will develop dairy farmers and boost spending on fisheries. Tax rates for individuals will increase threshold limits. The government will provide interest-free loans to states for tourism. Viability gap funding for wind energy potential is announced. There will be wider adoption of electric public transport.

## India's oil imports from Russia at 12-month low as sanctions bite
 - [https://timesofindia.indiatimes.com/business/india-business/indias-oil-imports-from-russia-hit-12month-low-in-january-as-sanctions-bite/articleshow/107321742.cms](https://timesofindia.indiatimes.com/business/india-business/indias-oil-imports-from-russia-hit-12month-low-in-january-as-sanctions-bite/articleshow/107321742.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T08:50:00+00:00



## Shark Tank 3's AI appliance pitcher on not striking deal with Peyush
 - [https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-shark-tank-india-3s-ai-based-cooking-appliance-pitcher-mehak-mody-on-not-striking-a-deal-though-we-denied-peyush-bansals-offer-we-resonated-on-technology/articleshow/107320350.cms](https://timesofindia.indiatimes.com/tv/news/hindi/exclusive-shark-tank-india-3s-ai-based-cooking-appliance-pitcher-mehak-mody-on-not-striking-a-deal-though-we-denied-peyush-bansals-offer-we-resonated-on-technology/articleshow/107320350.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T08:09:16+00:00

In Shark Tank India 3, Mehak Mody pitches an AI-based cooking assistant appliance, but the sharks are unimpressed by the 30-minute cooking time for kadai paneer. Anupam mentions meeting Mehak before, and Peyush offers Rs 10 Lakhs at 0.5% equity and Rs 90 Lakhs debt at 14% interest. Mehak declines the offer, valuing their product at Rs 100 cr.

## More houses, more funds for infra; no change in tax rates: 10 takeaways from Union Budget
 - [https://timesofindia.indiatimes.com/business/budget/union-budget-2024-10-major-takeaways-from-modi-govts-pre-election-budget/articleshow/107320037.cms](https://timesofindia.indiatimes.com/business/budget/union-budget-2024-10-major-takeaways-from-modi-govts-pre-election-budget/articleshow/107320037.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T08:01:43+00:00



## Professional horoscope: Your monthly career forecast for Feb '24
 - [https://timesofindia.indiatimes.com/astrology/horoscope/professional-horoscope-your-monthly-career-forecast-for-february-2024/articleshow/107319416.cms](https://timesofindia.indiatimes.com/astrology/horoscope/professional-horoscope-your-monthly-career-forecast-for-february-2024/articleshow/107319416.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T07:45:45+00:00

Aries: Entrepreneurs succeed with collaborations. Artists profit from creative ventures. Jobseekers receive offers. Professionals gain promotions and recognition. Marketers rebrand for visibility. Taurus: Career changes expected. Management sets realistic timelines. Professionals receive recognition. Jobseekers find high-paying roles. Freelancers gain status. Entrepreneurs succeed in collaborations and startups hit milestones. Gemini: Work harder for career goals. Expect recognition and rewards. Freelancers grow.

## Budget 2024: Some relief for taxpayers
 - [https://timesofindia.indiatimes.com/business/budget/budget-2024-income-tax-some-relief-for-taxpayers-outstanding-personal-tax-demands-up-to-rs-25000-withdrawn/articleshow/107318865.cms](https://timesofindia.indiatimes.com/business/budget/budget-2024-income-tax-some-relief-for-taxpayers-outstanding-personal-tax-demands-up-to-rs-25000-withdrawn/articleshow/107318865.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T07:30:04+00:00

During the Budget 2024 speech, Finance Minister Nirmala Sitharaman announced the removal of disputed direct tax demands up to Rs 25,000, benefiting approximately 1 crore taxpayers. The proposal aims to address unresolved tax demands from FY 2009-10 and FY 2010-11 to 2014-15.

## Global air traffic reached 94 % of pre-pandemic level in 2023: IATA
 - [https://timesofindia.indiatimes.com/business/international-business/global-air-traffic-reached-94-of-pre-pandemic-level-in-2023-international-air-transport-association/articleshow/107317579.cms](https://timesofindia.indiatimes.com/business/international-business/global-air-traffic-reached-94-of-pre-pandemic-level-in-2023-international-air-transport-association/articleshow/107317579.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T06:58:23+00:00

December 2023 total traffic rose 25.3% compared to December 2022 and reached 97.5% of the December 2019 level. International traffic in 2023 climbed 41.6% versus 2022 and reached 88.6% of 2019 levels. The strong post-pandemic rebound continued in 2023, with air traffic growth and recovery in air travel showing positive signs.

## 'ED hatched conspiracy, planned my arrest': Hemant Soren
 - [https://timesofindia.indiatimes.com/india/ed-hatched-conspiracy-planned-my-arrest-ex-jharkhand-cm-hemant-soren-calls-for-war-against-feudal-system-that-oppresses-poor-tribals-dalits/articleshow/107316663.cms](https://timesofindia.indiatimes.com/india/ed-hatched-conspiracy-planned-my-arrest-ex-jharkhand-cm-hemant-soren-calls-for-war-against-feudal-system-that-oppresses-poor-tribals-dalits/articleshow/107316663.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T06:56:04+00:00



## 2nd Test: India aim to bounce back England's 'Bazball'
 - [https://timesofindia.indiatimes.com/sports/cricket/england-in-india/2nd-test-india-aim-to-bounce-back-englands-bazball/articleshow/107317026.cms](https://timesofindia.indiatimes.com/sports/cricket/england-in-india/2nd-test-india-aim-to-bounce-back-englands-bazball/articleshow/107317026.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T06:43:21+00:00

India face England in the second Test in Visakhapatnam. India, under pressure and missing key players Ravindra Jadeja and KL Rahul, need to be creative to beat England's strong team. After a shocking defeat in Hyderabad, India must strategize to overcome England's gutsy group of "Bazballers." India's deadly spinners were put to the test against Bazball, but their hitters' difficulties on turning wickets were also highlighted when left-arm spinner Tom Hartley turned an otherwise unremarkable debut into a game-winning one.

## Key announcements from Sitharaman's budget speech
 - [https://timesofindia.indiatimes.com/business/budget/union-budget-2024-key-announcements-in-nirmala-sitharamans-interim-budget-speech/articleshow/107315511.cms](https://timesofindia.indiatimes.com/business/budget/union-budget-2024-key-announcements-in-nirmala-sitharamans-interim-budget-speech/articleshow/107315511.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T06:11:48+00:00



## MLC: Ricky Ponting set to coach Washington Freedom
 - [https://timesofindia.indiatimes.com/major-league-cricket-ricky-ponting-set-to-coach-washington-freedom/articleshow/107315375.cms](https://timesofindia.indiatimes.com/major-league-cricket-ricky-ponting-set-to-coach-washington-freedom/articleshow/107315375.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T06:06:49+00:00

Ricky Ponting, former Australia captain, is considering coaching the Washington Freedom in Major League Cricket (MLC) after the ICC T20 World Cup. Ponting, who also coaches the Delhi Capitals in the Indian Premier League, will be a commentator for Channel 7 during the T20 World Cup.

## Govt focusses on poor, women & youth in pre-poll budget: Highlights
 - [https://timesofindia.indiatimes.com/business/budget/budget-2024-highlights-budget-tax-slab-railway-budget-fm-nirmala-sitharaman-budget-speech-union-budget-2024-live/articleshow/107313275.cms](https://timesofindia.indiatimes.com/business/budget/budget-2024-highlights-budget-tax-slab-railway-budget-fm-nirmala-sitharaman-budget-speech-union-budget-2024-live/articleshow/107313275.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T05:33:44+00:00

The Indian economy has witnessed a profound positive transformation in the last 10 years, finance minister Nirmala Sitharaman said on Thursday. Presenting the interim Budget 2024-25, Sitharaman said that the government is working to make India a developed country by 2047. Poor, women, youth and farmers are four castes for the government, she added. Here are the key Budget highlights:

## Railway Budget 2024: New trains & safety focus expected
 - [https://timesofindia.indiatimes.com/business/budget/railway-budget-2024-live-updates-new-indian-railways-trains-record-capex-safety-focus-expected/articleshow/107310520.cms](https://timesofindia.indiatimes.com/business/budget/railway-budget-2024-live-updates-new-indian-railways-trains-record-capex-safety-focus-expected/articleshow/107310520.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T04:44:42+00:00

Railway Budget 2024 Live Updates: Since the Railway Budget is no longer separately presented, any announcements on Indian railways will form a part of FM Sitharaman’s speech. Indian Railways is an important driver of economic growth and hence a record capital expenditure.

## Worship of deities inside cellar of Gyanvapi mosque begins
 - [https://timesofindia.indiatimes.com/city/varanasi/worship-of-deities-inside-southern-cellar-of-gyanvapi-mosque-begins/articleshow/107311661.cms](https://timesofindia.indiatimes.com/city/varanasi/worship-of-deities-inside-southern-cellar-of-gyanvapi-mosque-begins/articleshow/107311661.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T04:37:51+00:00

The district magistrate ensured compliance with the court order to begin worshiping in the southern cellar of Gyanvapi mosque. A priest arranged by the Kashi Vishwanath temple trust performed the Shayan Arti of the deities inside the southern cellar. A gate was installed after cutting steel grills near the southern cellar doors. The Mangla Arti ritual was also performed.

## Bachcha hai, says Nitish Kumar about Tejashwi Yadav
 - [https://timesofindia.indiatimes.com/city/patna/bachcha-hai-says-nitish-about-exdy-cm-tejashwi/articleshow/107309061.cms](https://timesofindia.indiatimes.com/city/patna/bachcha-hai-says-nitish-about-exdy-cm-tejashwi/articleshow/107309061.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T03:10:18+00:00

The fall of the Grand Alliance government in Bihar led to a poster war in Patna between Tejashwi Prasad Yadav and Nitish Kumar, with each trying to take credit for the achievements during their joint rule. RJD listed 18 achievements of Tejashwi, while Nitish called his former deputy a 'bachcha'. JD(U) countered RJD's claims with an advertisement listing Nitish's achievements.

## 'Even the super seniors made me...': Pant reflects on his debut in 2017
 - [https://timesofindia.indiatimes.com/sports/cricket/news/even-the-super-seniors-made-me-rishabh-pant-reflects-on-his-debut-in-2017/articleshow/107308043.cms](https://timesofindia.indiatimes.com/sports/cricket/news/even-the-super-seniors-made-me-rishabh-pant-reflects-on-his-debut-in-2017/articleshow/107308043.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T02:57:53+00:00

India star wicket-keeper batter Rishabh Pant shared reflections on his debut with the Indian Team and how the team made him feel welcome on his debut after an impressive run in the 2016 U-19 World Cup. Pant made his international debut against England back in 2017 in the third game of the three-match T20I series at the M Chinnaswamy Stadium in Bangalore.

## Jack Leach out of second India Test with knee injury
 - [https://timesofindia.indiatimes.com/sports/cricket/england-in-india/englands-jack-leach-out-of-second-test-against-india/articleshow/107307001.cms](https://timesofindia.indiatimes.com/sports/cricket/england-in-india/englands-jack-leach-out-of-second-test-against-india/articleshow/107307001.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T02:03:02+00:00

England's Jack Leach has been ruled out of the second Test against India through injury, with his Somerset team-mate Shoaib Bashir now nearer an international debut as a result. Left-arm spinner Leach, 32, played a limited role in England's stunning 28-run win in the series opener, where Ben Stokes's men overcame a first-innings deficit of 190 runs, following a problem with his left knee. "He's ruled out of the second Test. Unfortunately the knock he took resulted in a haematoma," Ben Stokes told British media.

## Indians help Apple reach another milestone in 2023
 - [https://timesofindia.indiatimes.com/gadgets-news/indias-love-affair-with-iphones-helps-apple-reach-another-milestone-in-2023/articleshow/107303052.cms](https://timesofindia.indiatimes.com/gadgets-news/indias-love-affair-with-iphones-helps-apple-reach-another-milestone-in-2023/articleshow/107303052.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T02:00:28+00:00

India's smartphone shipments remained flat at 152 million units in 2023, with Apple surpassing 10 million units and capturing the top revenue position. The premium segment and 5G upgrades drove the market growth, with 5G smartphone shipments reaching 52% share. Samsung led overall shipments, while Vivo dominated the affordable premium segment. Apple's focus on India and attractive trade-in values contributed to its growth. Other brands like OnePlus, Transsion, Google, Lava, and Motorola also experienced positive growth.

## Hackers using Microsoft Teams for phishing attacks to spread malware
 - [https://timesofindia.indiatimes.com/gadgets-news/hackers-using-microsoft-teams-for-phishing-attacks-to-spread-malware-report/articleshow/107301666.cms](https://timesofindia.indiatimes.com/gadgets-news/hackers-using-microsoft-teams-for-phishing-attacks-to-spread-malware-report/articleshow/107301666.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T01:59:31+00:00

Cybercriminals are leveraging Microsoft Teams for a new malware campaign, using group chat requests to push DarkGate malware payloads. The attackers may have exploited a compromised Teams user to send over 1,000 malicious invites. Once installed, the malware contacts its command-and-control server, identified as part of the DarkGate infrastructure by Palo Alto Networks. Disabling External Access in Teams is advisable, according to AT&amp;T Cybersecurity. DarkGate has various capabilities, including a VNC, Windows Defender bypass tools, a browser history theft tool, a reverse proxy, a file manager, and a Discord token stealer.

## ByteDance's chief warns against mediocrity as AI disrupts
 - [https://timesofindia.indiatimes.com/gadgets-news/tiktok-owner-bytedances-chief-warns-against-mediocrity-as-ai-disrupts/articleshow/107306997.cms](https://timesofindia.indiatimes.com/gadgets-news/tiktok-owner-bytedances-chief-warns-against-mediocrity-as-ai-disrupts/articleshow/107306997.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T01:57:57+00:00

ByteDance CEO warns employees about AI disruption and risks of complacency. The company is behind in AI race compared to startups with better models. ByteDance is increasing focus on AI and testing AI-powered chatbots. Baidu's Ernie Bot competes with OpenAI's GPT-4.

## Bharat Mobility Show: How to reach, entrance fee & more
 - [https://timesofindia.indiatimes.com/auto/news/bharat-mobility-show-how-to-reach-entrance-fee-cars-to-see-and-more/articleshow/107306819.cms](https://timesofindia.indiatimes.com/auto/news/bharat-mobility-show-how-to-reach-entrance-fee-cars-to-see-and-more/articleshow/107306819.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T01:49:06+00:00

The highly anticipated Bharat Mobility Show 2024, aimed at bringing together the entire automobile ecosystem and its future under one roof, is finally here. This mega event, held from February 1st to 3rd at the Bharat Mandapam in New Delhi, promises a glimpse into the future of transportation, showcasing cutting-edge technologies, innovative vehicles, and sustainable solutions.

## Team combination takes centrestage as India look to turn the tide
 - [https://timesofindia.indiatimes.com/sports/cricket/england-in-india/india-vs-england-2nd-test-indian-team-combination-takes-centre-stage-as-india-look-to-turn-the-tide-in-port-city/articleshow/107303169.cms](https://timesofindia.indiatimes.com/sports/cricket/england-in-india/india-vs-england-2nd-test-indian-team-combination-takes-centre-stage-as-india-look-to-turn-the-tide-in-port-city/articleshow/107303169.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T01:41:01+00:00

India's defeat to England in Hyderabad was a result of their own shortcomings. England's performance, especially from Ollie Pope and debutant Tom Hartley, was impressive. The second Test in Vizag will see KL Rahul and Ravindra Jadeja's absence. Rajat Patidar is likely to replace Kohli, while Kuleep Yadav may substitute Jadeja. South Africa found out in Cape Town how dangerous India can be when conditions suit them, and it could be England’s turn next on a surface that is unlikely to aid the attack mentality of the England batters.

## ‘I’m sorry for everything': Zuckerberg in US Senate hearing
 - [https://timesofindia.indiatimes.com/world/us/meta-ceo-mark-zuckerberg-apologizes-to-families-in-senate-hearing/articleshow/107306505.cms](https://timesofindia.indiatimes.com/world/us/meta-ceo-mark-zuckerberg-apologizes-to-families-in-senate-hearing/articleshow/107306505.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T01:13:00+00:00

Executives from social media giants faced tough questions from the Senate Judiciary Committee regarding child safety. Concerns raised included sexual predation, cyberbullying, and insufficient safety investments. Meta's CEO Mark Zuckerberg apologized, while Snapchat endorsed a federal bill. Several states have filed lawsuits against Meta. Former engineer Arturo Béjar criticized the company's lack of commitment to address teen harm.

## Man kills sister, beheads her lover & chops off mom's hand
 - [https://timesofindia.indiatimes.com/city/madurai/brother-kills-sister-beheads-her-lover-and-chops-off-moms-hand/articleshow/107306324.cms](https://timesofindia.indiatimes.com/city/madurai/brother-kills-sister-beheads-her-lover-and-chops-off-moms-hand/articleshow/107306324.cms)
 - RSS feed: https://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2024-02-01T00:34:41+00:00



