# Source:Home - CBSNews.com, URL:https://www.cbsnews.com/latest/rss/main, language:en

## A Hole in the System I Sunday on 60 Minutes
 - [https://www.cbsnews.com/video/a-hole-in-the-system-sunday-on-60-minutes](https://www.cbsnews.com/video/a-hole-in-the-system-sunday-on-60-minutes)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T22:03:38+00:00

What is the fastest-growing group attempting to cross into the U.S. from Mexico? Chinese migrants. Yes, you heard that right. Sharyn Alfonsi reports, Sunday.

## 4 asteroids will zoom past Earth Friday, including one as big as a skyscraper
 - [https://www.cbsnews.com/news/asteroids-will-pass-earth-friday-one-the-size-of-empire-state-building](https://www.cbsnews.com/news/asteroids-will-pass-earth-friday-one-the-size-of-empire-state-building)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:57:08+00:00

NASA estimates the biggest asteroid headed our way is between 690 feet and 1,575 feet across.

## A Hole in the System I Sunday on 60 Minutes
 - [https://www.cbsnews.com/video/a-hole-in-the-system-i-sunday-on-60-minutes](https://www.cbsnews.com/video/a-hole-in-the-system-i-sunday-on-60-minutes)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:45:53+00:00

What is the fastest-growing group attempting to cross into the U.S. from Mexico? Chinese migrants. Yes, you heard that right. Sharyn Alfonsi reports, Sunday.

## Your Delta SkyMiles American Express card is getting pricier
 - [https://www.cbsnews.com/news/delta-amex-credit-card-annual-fee-changes](https://www.cbsnews.com/news/delta-amex-credit-card-annual-fee-changes)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:30:26+00:00

The cards will cost more but also offer enhanced benefits, including restaurant and rideshare credits.

## 3 of the best side hustles to consider right now
 - [https://www.cbsnews.com/news/best-side-hustles-to-consider-right-now](https://www.cbsnews.com/news/best-side-hustles-to-consider-right-now)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:22:58+00:00

There are multiple side hustles that can make you extra cash right now. Here are three to consider.

## These February 2024 Dewalt deals are so good we had to look twice
 - [https://www.cbsnews.com/essentials/dewalt-tool-deals](https://www.cbsnews.com/essentials/dewalt-tool-deals)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:21:00+00:00

We found big discounts on best-selling Dewalt oscillating tools, saws, drill bits and more at Amazon.

## Officers rescue 3-year-old boy who got stuck in claw machine
 - [https://www.cbsnews.com/video/officers-rescue-3-year-old-boy-who-got-stuck-in-claw-machine](https://www.cbsnews.com/video/officers-rescue-3-year-old-boy-who-got-stuck-in-claw-machine)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:18:00+00:00

Officers in Brisbane, Australia, rescued a 3-year-old boy who found himself stuck in a claw machine. They broke the glass and pulled him out -- then offered him a prize from inside the machine.

## 6 reasons to buy 1-ounce gold coins
 - [https://www.cbsnews.com/news/6-reasons-to-buy-1-ounce-gold-coins](https://www.cbsnews.com/news/6-reasons-to-buy-1-ounce-gold-coins)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:12:31+00:00

Have you ever wondered why 1-ounce gold coins are a popular investment? Here are six reasons to buy them.

## 3 new coral bleaching alert levels created in wake of extreme heat
 - [https://www.cbsnews.com/news/marine-heat-wave-coral-bleaching-alert](https://www.cbsnews.com/news/marine-heat-wave-coral-bleaching-alert)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:10:36+00:00

The revised coral bleaching alert levels come in the wake of Florida experiencing hot tub-level sea temperatures and some reefs experiencing "100% mortality."

## U.S. plans to launch series of strikes in response to base attack in Jordan, officials say
 - [https://www.cbsnews.com/video/us-plans-to-launch-series-of-strikes-in-response-to-base-attack-jordan-officials-say](https://www.cbsnews.com/video/us-plans-to-launch-series-of-strikes-in-response-to-base-attack-jordan-officials-say)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:09:02+00:00

The White House has approved plans to respond to the Sunday base attack in Jordan that killed three American service members, U.S. officials tell CBS News. An expected series of strikes will target Iranian personnel and facilities inside Iraq and Syria, according to CBS News' David Martin, who reports from the Pentagon.

## Four kinds of space heaters and what they're good for
 - [https://www.cbsnews.com/essentials/best-space-heaters-for-small-and-large-spaces](https://www.cbsnews.com/essentials/best-space-heaters-for-small-and-large-spaces)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T21:00:16+00:00

The right space heater can take the chill out of cooler temperatures, but you'll need to know which kind is right for your space.

## Jennifer Crumbley, mother of Oxford High School shooter, takes the stand
 - [https://www.cbsnews.com/video/jennifer-crumbley-mother-of-oxford-high-school-shooter-takes-the-stand](https://www.cbsnews.com/video/jennifer-crumbley-mother-of-oxford-high-school-shooter-takes-the-stand)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T20:58:52+00:00

Jennifer Crumbley, the mother of the Michigan school shooter, took the stand in her criminal trial on Thursday. Crumbley is facing four counts of involuntary manslaughter in connection with the deadly 2021 shooting at Oxford High School that her son carried out. CBS News' Elaine Quijano reports on the testimony.

## Could Biden "shut down" the border now? What to know about the debate
 - [https://www.cbsnews.com/news/immigration-biden-border-authority](https://www.cbsnews.com/news/immigration-biden-border-authority)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T20:48:57+00:00

Here are the facts about what President Biden can do now legally at the border and what he can't do, at least without congressional intervention.

## 14 best high-yield savings account rates for February 2024 (up to 5.50% APY)
 - [https://www.cbsnews.com/news/best-high-yield-savings-account-rates-for-february-2024-up-to-5-50-apy](https://www.cbsnews.com/news/best-high-yield-savings-account-rates-for-february-2024-up-to-5-50-apy)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T20:34:37+00:00

A high-yield savings account can help you earn big returns on your money — and these options are some of the best.

## F1 champ Hamilton leaves Mercedes for Ferrari in surprise team switch
 - [https://www.cbsnews.com/news/lewis-hamilton-mercedes-ferrari-f1-racing-formula-one](https://www.cbsnews.com/news/lewis-hamilton-mercedes-ferrari-f1-racing-formula-one)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T20:33:00+00:00

The move by the 39-year-old to one of the most iconic teams in the history of motorsports marks the end of a remarkably successful partnership.

## The job market is strong. So why did layoffs double in January?
 - [https://www.cbsnews.com/news/layoffs-economy-2024-why-are-job-cuts-happening](https://www.cbsnews.com/news/layoffs-economy-2024-why-are-job-cuts-happening)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T20:26:49+00:00

Although U.S. unemployment remains near a 50-year low, job losses have surged this month. Here's what tells about the state of the labor market.

## Trump PACs spent nearly $50 million on legal bills in 2023
 - [https://www.cbsnews.com/news/trump-political-action-committees-2023-legal-bills](https://www.cbsnews.com/news/trump-political-action-committees-2023-legal-bills)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T20:23:00+00:00

Trump's PACs spent $50 million in donor money on attorneys, legal consulting and investigation-related fees across 2023, his latest campaign finance filings say.

## Senate close to unveiling immigration and national security bill, Schumer says
 - [https://www.cbsnews.com/news/senate-immigration-ukraine-bill-schumer](https://www.cbsnews.com/news/senate-immigration-ukraine-bill-schumer)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T20:21:25+00:00

Senate negotiators have been engaged in talks for months on border security components of the national security supplemental.

## New cancer cases to increase 77% by 2050, WHO predicts
 - [https://www.cbsnews.com/news/who-predicts-35-million-cancer-cases-2050-77-percent-increase](https://www.cbsnews.com/news/who-predicts-35-million-cancer-cases-2050-77-percent-increase)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T20:04:00+00:00

Ahead of World Cancer Day on Sunday, Feb. 4, new data from the World Health Organization highlights the impact worldwide.

## Hulu to enforce new restrictions on widespread subscription sharing
 - [https://www.cbsnews.com/news/hulu-password-sharing-crackdown-restrictions-netflix-streaming-disney](https://www.cbsnews.com/news/hulu-password-sharing-crackdown-restrictions-netflix-streaming-disney)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T19:52:00+00:00

The streaming service is following the lead of Netflix, which cracked down on the common practice last year.

## WHO releases broad study for World Cancer Day
 - [https://www.cbsnews.com/video/who-releases-broad-study-for-world-cancer-day](https://www.cbsnews.com/video/who-releases-broad-study-for-world-cancer-day)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T19:51:00+00:00

Ahead of World Cancer Day, a new study by the World Health Organization is shedding light on the far-reaching impact of the disease. CBS News' Ian Lee reports.

## Angry farmers protest outside European Union summit
 - [https://www.cbsnews.com/video/angry-farmers-protest-outside-european-union-summit](https://www.cbsnews.com/video/angry-farmers-protest-outside-european-union-summit)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T19:50:02+00:00

In Belgium, roads have been blocked as farmers protest outside the European Union summit over European agriculture policies and increased taxes in certain countries. In France, farming tractors blocked lanes or entire sections of highways for miles. CBS News' Elaine Cobbe reports.

## OxyContin marketer agrees to pay $350 million rather than face lawsuits
 - [https://www.cbsnews.com/news/oxycontin-publicis-health-350-million-settlement](https://www.cbsnews.com/news/oxycontin-publicis-health-350-million-settlement)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T19:42:00+00:00

A company that helped develop marketing campaigns for OxyContin and other opioids has agreed to a $350 million settlement.

## Baltimore Ravens tight end Mark Andrews helped save a woman's life on a Southwest Airlines flight
 - [https://www.cbsnews.com/news/mark-andrews-southwest-airlines-flight-emergency-baltimore-ravens-phoenix-arizona](https://www.cbsnews.com/news/mark-andrews-southwest-airlines-flight-emergency-baltimore-ravens-phoenix-arizona)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T19:31:00+00:00

Andrews helped a woman who was having a mid-flight emergency on a Southwest Airlines flight from Baltimore to Phoenix Thursday morning.

## Groundhog Day 2024 marks 10 years since Bill de Blasio dropped Staten Island Chuck
 - [https://www.cbsnews.com/news/staten-island-chuck-getting-ready-for-his-big-moment-friday](https://www.cbsnews.com/news/staten-island-chuck-getting-ready-for-his-big-moment-friday)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T19:10:00+00:00

Friday isn't just any old Groundhog Day. It will be 10 years since former NYC Mayor Bill de Blasio dropped the animal during the ceremony. It died a week later.

## Vet advocate says "smoking gun" records prove toxic exposure at military base
 - [https://www.cbsnews.com/news/veterans-advocate-claims-smoking-gun-records-prove-toxic-exposure-at-military-base](https://www.cbsnews.com/news/veterans-advocate-claims-smoking-gun-records-prove-toxic-exposure-at-military-base)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T19:05:00+00:00

Nearly two decades after U.S. troops left K2, the U.S. government has not confirmed that toxic material at the Uzbekistan base made service members sick.

## Child Tax Credit expansion faces uncertain path in Senate after House vote
 - [https://www.cbsnews.com/news/child-tax-credit-bill-senate-vote](https://www.cbsnews.com/news/child-tax-credit-bill-senate-vote)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T19:00:30+00:00

The legislation would bolster the Child Tax Credit, aiming to provide relief to lower-income families.

## 3 questions homebuyers should ask with interest rates paused
 - [https://www.cbsnews.com/news/questions-homebuyers-should-ask-with-interest-rates-paused](https://www.cbsnews.com/news/questions-homebuyers-should-ask-with-interest-rates-paused)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T18:56:34+00:00

The mortgage rate climate is evolving. Here are three questions homebuyers should ask with interest rates on hold.

## Al Qaeda setting up new training camps in Afghanistan, U.N. report says
 - [https://www.cbsnews.com/news/afghanistan-taliban-al-qaeda-growing](https://www.cbsnews.com/news/afghanistan-taliban-al-qaeda-growing)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T18:47:27+00:00

A report compiled for the U.N. Security Council says the Taliban has allowed al Qaeda to continue posing "a threat in the region and potentially beyond."

## European farmers rage at EU parliament as protests end in France
 - [https://www.cbsnews.com/news/european-farmers-france-protests-end-rage-brussels](https://www.cbsnews.com/news/european-farmers-france-protests-end-rage-brussels)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T18:44:13+00:00

European farmers have been dealing with ruined crops, loss of earnings and rising costs for the past few years.

## Taylor Swift's economic and political impact
 - [https://www.cbsnews.com/video/taylor-swifts-economic-and-political-impact](https://www.cbsnews.com/video/taylor-swifts-economic-and-political-impact)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T18:23:02+00:00

Taylor Swift has created a brand value equivalent to $331.5 million for the NFL and the Kansas City Chiefs, her boyfriend Travis Kelce's team, according to Apex Marketing Group. Mariana Alfaro, a breaking political news reporter for the Washington Post, joined CBS News to discuss how Swift is making waves in the sports world and  starting to have an effect on politics.

## Trump used $50 million in donor money for 2023 legal fees: FEC filing
 - [https://www.cbsnews.com/video/trump-used-50-million-in-donor-money-for-2023-legal-fees-fec-filing](https://www.cbsnews.com/video/trump-used-50-million-in-donor-money-for-2023-legal-fees-fec-filing)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T18:23:02+00:00

Donald Trump used about $50 million in donor money to help pay his legal fees in 2023, according to a new round of Federal Election Commission campaign disclosures. CBS News political reporter Hunter Woodall has more.

## Capitol Police close investigation into Senate sex tape without charges
 - [https://www.cbsnews.com/news/senate-sex-tape-capitol-police-investigation](https://www.cbsnews.com/news/senate-sex-tape-capitol-police-investigation)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:56:41+00:00

A Senate staffer was fired after parts of a sex tape filmed in a hearing room were published online.

## European farmers protest in Brussels as EU leaders meet about Ukraine aid
 - [https://www.cbsnews.com/video/european-farmers-protest-brussels-eu-ukraine-aid](https://www.cbsnews.com/video/european-farmers-protest-brussels-eu-ukraine-aid)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:53:02+00:00

Angry farmers hurled eggs and started fires Thursday outside the European Parliament in Brussels. The farmers, who come from countries across Europe, are pressing European Union leaders to do more about the low pay and red tape they're experiencing. Bethany Bell from the BBC has more.

## WHO reveals most countries don't adequately fund cancer services
 - [https://www.cbsnews.com/video/who-most-countries-dont-adequately-finance-cancer-services](https://www.cbsnews.com/video/who-most-countries-dont-adequately-finance-cancer-services)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:53:02+00:00

The World Health Organization has released new figures showing an alarming lack of funding for cancer care in most countries. Oncology hospitalist Dr. Tim Tiutan joined CBS News to discuss the findings.

## Some Iranians are anxious, but their leaders say the U.S. is "bluffing"
 - [https://www.cbsnews.com/news/iran-us-strikes-planned-iraq-syria-after-jordan-drone-attack-view-from-tehran](https://www.cbsnews.com/news/iran-us-strikes-planned-iraq-syria-after-jordan-drone-attack-view-from-tehran)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:48:27+00:00

The U.S. is planning to strike Iran-backed groups, and Iranian personnel, in Iraq and Syria, and while some Iranians are nervous, their leaders remain defiant.

## Biden approves sanctions for Israeli settlers who attack Palestinians in West Bank
 - [https://www.cbsnews.com/news/biden-executive-order-israeli-settlers-palestinians-west-bank](https://www.cbsnews.com/news/biden-executive-order-israeli-settlers-palestinians-west-bank)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:39:01+00:00

The order authorizes sanctions against those involved in acts of violence​, as well as threats and attempts to destroy or seize Palestinian property.

## Defense Secretary Austin says he didn't handle cancer diagnosis the right way
 - [https://www.cbsnews.com/video/defense-secretary-austin-says-he-didnt-handle-cancer-diagnosis-the-right-way](https://www.cbsnews.com/video/defense-secretary-austin-says-he-didnt-handle-cancer-diagnosis-the-right-way)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:37:54+00:00

Defense Secretary Lloyd Austin spoke to reporters Thursday for the first time since he was hospitalized for cancer treatment, something he didn't disclose to President Biden. Austin said, "We did not handle this right. I did not handle this right." CBS News national security correspondent David Martin has more.

## How the interest rate pause could help credit card users
 - [https://www.cbsnews.com/news/how-the-interest-rate-pause-could-help-credit-card-users](https://www.cbsnews.com/news/how-the-interest-rate-pause-could-help-credit-card-users)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:28:08+00:00

The recent Fed rate hike pause could be good news for credit card users. Find out more here.

## Senate border security deal stalled, Speaker Johnson calls it "dead on arrival" in House
 - [https://www.cbsnews.com/video/senate-border-security-deal-stalled-speaker-johnson-calls-it-dead-on-arrival-in-house](https://www.cbsnews.com/video/senate-border-security-deal-stalled-speaker-johnson-calls-it-dead-on-arrival-in-house)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:22:48+00:00

Republican infighting has stalled a bipartisan border deal that had looked sure to make it out of the Senate earlier this week. Even if the bill does pass the Senate, Republicans in the House are poised to block it. CBS News immigration reporter Camilo Montoya-Galvez has more.

## Atmospheric river wreaking havoc on California
 - [https://www.cbsnews.com/video/atmospheric-river-wreaking-havoc-on-california](https://www.cbsnews.com/video/atmospheric-river-wreaking-havoc-on-california)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:22:46+00:00

Parts of the Pacific Coast are dealing with an atmospheric river that's flooding roads, knocking down trees and causing power outages. CBS News correspondent Elise Preston has more.

## This standing desk exercise bike has gone viral on TikTok. And it's $120 off at Amazon
 - [https://www.cbsnews.com/essentials/flexispot-deskcise-pro-v9-exercise-standing-desk](https://www.cbsnews.com/essentials/flexispot-deskcise-pro-v9-exercise-standing-desk)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:11:00+00:00

Keep moving while you work with the FlexiSpot Deskcise Pro V9 exercise desk bike that has TikTok users talking.

## Online conspiracy theories create new age of unproven medical treatments
 - [https://www.cbsnews.com/news/online-conspiracy-theories-miracle-cures-unproven-medical-treatments](https://www.cbsnews.com/news/online-conspiracy-theories-miracle-cures-unproven-medical-treatments)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T17:05:00+00:00

As suspicion of traditional medicine, the media and the government has grown, more people are willing to put their faith in untested treatments​ and unproven claims.

## House approves Child Tax Credit expansion. Here's who could benefit.
 - [https://www.cbsnews.com/news/child-tax-credit-2024-who-qualifies](https://www.cbsnews.com/news/child-tax-credit-2024-who-qualifies)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T16:58:36+00:00

The Child Tax Credit is one step closer to getting a major expansion, potentially putting more money in parents' pockets.

## Trump lawsuit over "Steele dossier" dismissed by U.K. court
 - [https://www.cbsnews.com/video/trump-lawsuit-over-steele-dossier-dismissed-by-u-k-court](https://www.cbsnews.com/video/trump-lawsuit-over-steele-dossier-dismissed-by-u-k-court)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T16:47:00+00:00

The U.K.'s high court in London has thrown out a lawsuit by Donald Trump accusing a former British spy of making shocking and scandalous claims that harmed his reputation. CBS News foreign correspondent Imtiaz Tyab has more on the case.

## Satellite images show massive atmospheric river on West Coast
 - [https://www.cbsnews.com/news/satellite-images-atmospheric-river-california-west-coast-pineapple-express](https://www.cbsnews.com/news/satellite-images-atmospheric-river-california-west-coast-pineapple-express)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T16:29:14+00:00

Satellite images show the strong Pineapple Express atmospheric river as it barrels from the Pacific Ocean toward the West Coast.

## Virginia music teacher Annie Ray wins 2024 Grammy Music Educator Award
 - [https://www.cbsnews.com/news/virginia-music-teacher-annie-ray-wins-2024-grammy-music-educator-award](https://www.cbsnews.com/news/virginia-music-teacher-annie-ray-wins-2024-grammy-music-educator-award)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T16:07:41+00:00

This prestigious honor, presented by the Recording Academy and the Grammy Museum, recognizes Annie Ray's contribution to music education.

## Federal officials issue new guidelines on catchy highway signs
 - [https://www.cbsnews.com/news/federal-officials-issue-new-guidelines-in-an-effort-to-pump-the-brakes-on-catchy-highway-signs](https://www.cbsnews.com/news/federal-officials-issue-new-guidelines-in-an-effort-to-pump-the-brakes-on-catchy-highway-signs)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T16:06:00+00:00

Some states have been injecting pop culture references into traffic signs, but federal officials say they prefer a more serious approach.

## Camp Lejeune water contamination tied to range of cancers, study says
 - [https://www.cbsnews.com/news/camp-lejeune-water-contamination-cancers-cdc-study](https://www.cbsnews.com/news/camp-lejeune-water-contamination-cancers-cdc-study)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T16:04:47+00:00

Federal health officials called the research one the largest ever done in the United States to assess cancer risk by comparing a group who live and worked in a polluted environment to a similar group that did not.

## Woman's murder in Colorado finally solved — after 48 years
 - [https://www.cbsnews.com/news/colorado-cold-case-solved-half-century-teree-becker](https://www.cbsnews.com/news/colorado-cold-case-solved-half-century-teree-becker)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T15:50:00+00:00

Teree Becker, 20, was killed in 1975. It took 48 years for genetic genealogy to catch her killer.

## Israel trading fire with Hezbollah at border with Lebanon amid fears of wider war
 - [https://www.cbsnews.com/video/israel-hezbollah-lebanon-border-fears-wider-war](https://www.cbsnews.com/video/israel-hezbollah-lebanon-border-fears-wider-war)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T15:21:50+00:00

Iranian-backed Hezbollah fighters have been launching near daily attacks on Israel's northern border with Lebanon. CBS News foreign correspondent Debora Patta reports from an evacuated border town on the Israeli northern front.

## Watch Live: Austin holds first press conference since hospitalization
 - [https://www.cbsnews.com/news/defense-secretary-lloyd-austin-first-press-conference-since-hospitalization-watch-live-stream-today-2024-02-01](https://www.cbsnews.com/news/defense-secretary-lloyd-austin-first-press-conference-since-hospitalization-watch-live-stream-today-2024-02-01)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T15:17:53+00:00

This is the first time Defense Secretary Lloyd Austin is taking questions from the press since his secret hospitalization and since the drone attack that killed U.S. soldiers in Jordan.

## Aftermath of toxic East Palestine train derailment one year later
 - [https://www.cbsnews.com/video/aftermath-of-toxic-east-palestine-train-derailment-one-year-later](https://www.cbsnews.com/video/aftermath-of-toxic-east-palestine-train-derailment-one-year-later)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T15:07:02+00:00

One year ago, a Norfolk Southern freight train carrying hazardous materials derailed near East Palestine, Ohio, forcing hundreds to evacuate. At the time, local officials allowed the rail operator to conduct a "controlled release" of toxic chemicals into the air from five derailed tanker cars that were in danger of exploding. In a new CBS Reports documentary, CBS News' Roxana Saberi talks to a former Environmental Protection Agency official who is critical of that decision.

## K2 veteran claims military records prove toxic exposure at Uzbek base
 - [https://www.cbsnews.com/video/k2-veteran-claims-military-records-prove-toxic-exposure-at-uzbek-base](https://www.cbsnews.com/video/k2-veteran-claims-military-records-prove-toxic-exposure-at-uzbek-base)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T15:07:02+00:00

CBS News recently obtained military records that may explain why hundreds of service members reported getting rare cancers or other illnesses after being stationed at Karshi-Khanabad, or K2, a former Soviet base in Uzbekistan, after 9/11. CBS News' Catherine Herridge has the latest on our investigation.

## Virginia teacher wins 2024 Grammy Music Educator Award
 - [https://www.cbsnews.com/video/virginia-teacher-wins-2024-grammy-music-educator-award](https://www.cbsnews.com/video/virginia-teacher-wins-2024-grammy-music-educator-award)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T15:07:02+00:00

"CBS Mornings" reveals the 2024 Grammy Music Educator Award winner as Annie Ray, a music teacher and orchestra leader in Annandale, Virginia. CBS News' Jamie Wax shares how Ray's boundless energy and passion for music goes beyond the classroom.

## Strong storm causes floods, power outages in California
 - [https://www.cbsnews.com/video/strong-storm-causes-floods-power-outages-in-california](https://www.cbsnews.com/video/strong-storm-causes-floods-power-outages-in-california)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T14:51:47+00:00

A powerful storm battered the West Coast overnight, particularly impacting California with flooding and destructive winds. The severe weather flooded roads, toppled trees and caused widespread power outages. CBS News' Elise Preston reports.

## President Biden courts union voters in Michigan
 - [https://www.cbsnews.com/video/president-biden-courts-union-voters-in-michigan](https://www.cbsnews.com/video/president-biden-courts-union-voters-in-michigan)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T14:51:46+00:00

President Biden is visiting Michigan today in an effort to garner support from union workers in the swing state before the November presidential election. CBS News' Ed O'Keefe reports.

## Sneak peek: Who Took Our Dad? The Abduction of Ray Wright
 - [https://www.cbsnews.com/video/sneak-peek-who-took-our-dad-the-abduction-of-ray-wright](https://www.cbsnews.com/video/sneak-peek-who-took-our-dad-the-abduction-of-ray-wright)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T14:51:02+00:00

A family man abruptly vanishes. Police tie his disappearance to a monstrous plot for revenge. "48 Hours" correspondent Natalie Morales reports Saturday, Feb. 3 at 10/9c on CBS and streaming on Paramount+.

## These "bee bus stops" are looking to save pollinators
 - [https://www.cbsnews.com/news/bee-bus-stops-derby-england-help-save-pollinators-fight-climate-change-impacts](https://www.cbsnews.com/news/bee-bus-stops-derby-england-help-save-pollinators-fight-climate-change-impacts)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T14:46:00+00:00

Bus stop coverings are getting replaced with "living roofs" made with native plants to help provide food for dying species and help people stay cool amid rising temperatures.

## FDA says 561 deaths tied to recalled Philips sleep apnea machines
 - [https://www.cbsnews.com/news/fda-sleep-apnea-philips-recall-cpap](https://www.cbsnews.com/news/fda-sleep-apnea-philips-recall-cpap)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T14:43:00+00:00

Update from the Food and Drug Agency comes days after Philips said it would stop selling the devices in the U.S.

## Exclusive discounts from CBS Mornings Deals
 - [https://www.cbsnews.com/video/cbs-mornings-deals-020124](https://www.cbsnews.com/video/cbs-mornings-deals-020124)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T14:36:36+00:00

On CBS Mornings Deals, lifestyle host Gayle Bass shows us several items that might make your day a little brighter. Visit cbsdeals.com to take advantage of these exclusive deals today. CBS earns commissions on purchases made through cbsdeals.com.

## Teen falls to his death while taking photos at Utah canyon overlook
 - [https://www.cbsnews.com/news/jonathan-fielding-falls-death-taking-photos-utah-canyon-moonscape-overlook](https://www.cbsnews.com/news/jonathan-fielding-falls-death-taking-photos-utah-canyon-moonscape-overlook)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T14:27:00+00:00

Jonathan Fielding was hiking with friends at Utah's Moonscape Overlook when he fell.

## Plans approved for U.S. strikes against Iranian targets in Iraq, Syria
 - [https://www.cbsnews.com/news/us-strikes-iran-personnel-facilities-in-iraq-syria-approved-jordan-drone-attack](https://www.cbsnews.com/news/us-strikes-iran-personnel-facilities-in-iraq-syria-approved-jordan-drone-attack)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T14:13:00+00:00

The U.S. military plans to strike targets in Iraq and Syria, including Iranian personnel and facilities, in response to a drone attack that killed 3 U.S. troops.

## Former NFL running back turned chef serves up inspiration
 - [https://www.cbsnews.com/video/former-nfl-running-back-turned-chef-serves-up-inspiration](https://www.cbsnews.com/video/former-nfl-running-back-turned-chef-serves-up-inspiration)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:54:49+00:00

Former professional football player Tobias Dorzon discovered his true passion lies not on the gridiron, but in the kitchen. As part of our series “The Dish,” Dorzon tells "CBS Mornings" co-anchor Tony Dokoupil about his unique career change and how he hopes to inspire the next generation of diverse chefs to pursue their dreams.

## How to get your tax refund faster and other must-know filing tips
 - [https://www.cbsnews.com/video/how-to-get-your-tax-refund-faster-and-other-must-know-filing-tips](https://www.cbsnews.com/video/how-to-get-your-tax-refund-faster-and-other-must-know-filing-tips)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:50:38+00:00

Tax season is officially underway. The Internal Revenue Service says they’re anticipating more than 146 million individual tax returns to be filed by the April 15 deadline. CBS News business analyst Jill Schlesinger shares some useful tax tips for filers.

## Feds say humorous highway safety signs are no laughing matter
 - [https://www.cbsnews.com/video/feds-say-humorous-highway-safety-signs-are-no-laughing-matter](https://www.cbsnews.com/video/feds-say-humorous-highway-safety-signs-are-no-laughing-matter)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:47:57+00:00

Federal officials want to pump the brakes on catchy highway safety signs, issuing new guidelines that specify states should avoid "humor and pop culture references" because they may confuse or distract drivers. CBS News' Kris Van Cleave reports on the Federal Highway Administration's recommendations.

## Prosecutors release new video of Jennifer Crumbley's arrest
 - [https://www.cbsnews.com/video/prosecutors-release-new-video-of-jennifer-crumbleys-arrest](https://www.cbsnews.com/video/prosecutors-release-new-video-of-jennifer-crumbleys-arrest)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:45:33+00:00

The trial of Jennifer Crumbley, the mother of the Oxford High School shooter, continued Wednesday with the fifth day of testimony. Michigan prosecutors have released newly released video of her arrest.

## FBI director issues warning of Chinese government-led cyberattacks
 - [https://www.cbsnews.com/video/fbi-director-issues-warning-of-chinese-government-led-cyberattacks](https://www.cbsnews.com/video/fbi-director-issues-warning-of-chinese-government-led-cyberattacks)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:44:37+00:00

FBI Director Christopher Wray issued a serious warning on Capitol Hill about potential Chinese government hacking attacks that could target and damage U.S. infrastructure. CBS News' Nicole Sganga reports.

## Takeaways from heated Senate hearing with tech CEOs on child safety
 - [https://www.cbsnews.com/video/takeaways-from-heated-senate-hearing-with-tech-ceos-on-child-safety](https://www.cbsnews.com/video/takeaways-from-heated-senate-hearing-with-tech-ceos-on-child-safety)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:44:02+00:00

The CEOs of Meta, TikTok, Snap, Discord and X were grilled by lawmakers for hours on Wednesday during a Senate Judiciary Committee hearing about their child safety policies. CBS News' Jo Ling Kent reports on the fiery hearing and shares what the tech executives had to say.

## Rare look at how U.S. Navy ships defend the Red Sea from Houthi attacks
 - [https://www.cbsnews.com/video/rare-look-at-how-us-navy-ships-defend-the-red-sea-from-houthi-attacks](https://www.cbsnews.com/video/rare-look-at-how-us-navy-ships-defend-the-red-sea-from-houthi-attacks)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:43:43+00:00

"CBS Evening News" anchor and managing editor Norah O'Donnell gets a rare look at how U.S. Navy ships positioned in the Red Sea are combatting aggressive attacks by Houthi rebels and defending commercial ships. O'Donnell reports from the aircraft carrier USS Eisenhower and the missile destroyer USS Mason.

## Cygnus cargo ship attached to space station after smooth rendezvous
 - [https://www.cbsnews.com/news/northrop-grumman-cargo-ship-delivers-4-tons-of-supplies-and-equipment-to-space-station](https://www.cbsnews.com/news/northrop-grumman-cargo-ship-delivers-4-tons-of-supplies-and-equipment-to-space-station)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:28:29+00:00

Along with crew supplies, spare parts and science gear, the Cygnus cargo ship brought ice cream and other treats to the lab's crew.

## Bear cubs native to Alaska found on Florida road
 - [https://www.cbsnews.com/video/bear-cubs-native-to-alaska-found-on-florida-road](https://www.cbsnews.com/video/bear-cubs-native-to-alaska-found-on-florida-road)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:21:20+00:00

Officials say a pair of bear cubs found on a Florida road are native to Alaska and had escaped from a self-proclaimed "bear-trainer." Bodycam footage from a Florida sheriff's deputy shows the Kodiak bears were rather friendly.

## Video shows bears native to Alaska wandering on Florida road
 - [https://www.cbsnews.com/news/video-bear-cubs-native-to-alaska-found-florida](https://www.cbsnews.com/news/video-bear-cubs-native-to-alaska-found-florida)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:15:00+00:00

Video shows the bears approaching the humans near them and trying to climb on their cars.

## This year's best Super Bowl ad? It's Taylor Swift, of course.
 - [https://www.cbsnews.com/news/super-bowl-2024-taylor-swift-travis-kelce-super-bowl-ads](https://www.cbsnews.com/news/super-bowl-2024-taylor-swift-travis-kelce-super-bowl-ads)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:12:00+00:00

Taylor Swift is single-handedly reviving interest in pro football among younger U.S. adults, polling data shows.

## Toxic Fog: The Aftermath in East Palestine, Ohio | CBS Reports
 - [https://www.cbsnews.com/video/toxic-fog-the-aftermath-in-east-palestine-ohio-cbs-reports](https://www.cbsnews.com/video/toxic-fog-the-aftermath-in-east-palestine-ohio-cbs-reports)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:07:11+00:00

In February 2023, a quiet community in Ohio was blindsided by disaster when a train derailed and authorities decided to unleash a plume of toxic smoke in an attempt to avoid an explosion. Days later, residents and the media thought the story was over, but in fact it was just beginning. What unfolded in East Palestine is a cautionary tale for every town and city in America.

## Ground beef is up, shrimp is down. How to save on a Super Bowl party.
 - [https://www.cbsnews.com/news/super-bowl-2024-party-chicken-wings-shrimp-ways-to-save](https://www.cbsnews.com/news/super-bowl-2024-party-chicken-wings-shrimp-ways-to-save)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T13:00:00+00:00

Expect discounts on chicken wings, shrimp. On the flip side, burgers will cost more as record-low cattle numbers drive up prices.

## Australian police called in to rescue boy from a claw machine
 - [https://www.cbsnews.com/news/australia-boy-stuck-in-claw-machine-rescued-queensland-police-video](https://www.cbsnews.com/news/australia-boy-stuck-in-claw-machine-rescued-queensland-police-video)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T12:37:43+00:00

The Queensland Police say young Ethan climbed into the mall's claw machine "in pursuit of the ultimate prize." After a brief ordeal, he got one.

## Bones found in cave could rewrite history of humans and Neanderthals
 - [https://www.cbsnews.com/news/bones-tools-cave-could-rewrite-history-humans-neanderthals-europe](https://www.cbsnews.com/news/bones-tools-cave-could-rewrite-history-humans-neanderthals-europe)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T12:25:00+00:00

Researchers found human bones and tools hiding behind a massive rock in a German cave, the oldest traces of Homo sapiens ever discovered so far north.

## Video captures Indiana lawmaker flashing holstered gun at students
 - [https://www.cbsnews.com/news/jim-lucas-viral-video-indiana-lawmaker-holstered-gun-student-gun-control-advocates](https://www.cbsnews.com/news/jim-lucas-viral-video-indiana-lawmaker-holstered-gun-student-gun-control-advocates)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T12:05:38+00:00

A high school student captured Indiana state Rep. Jim Lucas on video flashing a holstered gun at students who were visiting the statehouse to push for gun control measures.

## Haley shifts focus in effort to close gap with Trump in South Carolina
 - [https://www.cbsnews.com/news/nikki-haley-2024-presidential-campaign-shift-trump-south-carolina](https://www.cbsnews.com/news/nikki-haley-2024-presidential-campaign-shift-trump-south-carolina)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T12:00:27+00:00

As Nikki Haley campaigns in her home state of South Carolina, she's highlighting her record as the state's twice-elected governor.

## Are you getting enough sleep? Three ways to know
 - [https://www.cbsnews.com/essentials/are-you-getting-enough-sleep](https://www.cbsnews.com/essentials/are-you-getting-enough-sleep)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T12:00:21+00:00

Not sure if you're getting enough sleep at night? Three ways to know if you need to change your sleep habits.

## Police want help finding 2 kids after remains found in storage unit
 - [https://www.cbsnews.com/news/child-encased-concrete-storage-unit-southern-colorado-pueblo-police-jesus-yesenia-dominguez](https://www.cbsnews.com/news/child-encased-concrete-storage-unit-southern-colorado-pueblo-police-jesus-yesenia-dominguez)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T11:43:00+00:00

A homicide investigation is underway in Pueblo after the remains of a child were found encased in concrete in a storage unit in Pueblo. Police say they want help locating two children who haven't been seen in 6 years.

## YouTube responds after beheading video posted on social media platform
 - [https://www.cbsnews.com/news/beheading-video-youtube-responds-justin-mohn-charged-murder](https://www.cbsnews.com/news/beheading-video-youtube-responds-justin-mohn-charged-murder)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T11:37:00+00:00

Justin Mohn, 32, was charged with first-degree murder after he allegedly beheaded his father and publicized it in a 14-minute YouTube video.

## U.K. judge dismisses Donald Trump's lawsuit over "Steele dossier"
 - [https://www.cbsnews.com/news/donald-trump-steele-dossier-uk-judge-dismisses-lawsuit-vs-orbis-business](https://www.cbsnews.com/news/donald-trump-steele-dossier-uk-judge-dismisses-lawsuit-vs-orbis-business)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T11:22:17+00:00

A London court has thrown out a lawsuit brought by Donald Trump accusing a British ex-spy of making "shocking and scandalous claims" that harmed his reputation.

## Taylor Swift, Travis Kelce conspiracy theories abound with Chiefs in Super Bowl
 - [https://www.cbsnews.com/news/taylor-swift-travis-kelce-conspiracy-theories-chiefs-super-bowl](https://www.cbsnews.com/news/taylor-swift-travis-kelce-conspiracy-theories-chiefs-super-bowl)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T11:15:00+00:00

The claims are ludicrous and may well reflect the fear on the political right that someone as famous as Swift could influence the presidential race if she urges her fans in one direction.

## Is Amazon Prime still worth it? All the pros and cons
 - [https://www.cbsnews.com/essentials/is-amazon-prime-worth-it](https://www.cbsnews.com/essentials/is-amazon-prime-worth-it)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T11:00:27+00:00

We've broken down the price increase to help you decide whether to keep or ditch the service.

## Colorado settlement would improve standards for trans women inmates
 - [https://www.cbsnews.com/news/colorado-lawsuit-settlement-trans-women-inmates](https://www.cbsnews.com/news/colorado-lawsuit-settlement-trans-women-inmates)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T10:00:06+00:00

A soon-to-be-finalized legal settlement in Colorado comes amid a growing number of lawsuits across the country aimed at improving health care access and safety for incarcerated trans people.

## U.K. bans "American XL bully" dogs after spate of deadly attacks
 - [https://www.cbsnews.com/news/american-xl-bully-dogs-uk-ban-spate-deadly-attacks](https://www.cbsnews.com/news/american-xl-bully-dogs-uk-ban-spate-deadly-attacks)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T09:28:00+00:00

Owners of American XL bully dogs can get exemptions from the U.K.'s new ban on them but still have to muzzle them and keep them on leashes in public.

## Man arrested for running onto LAX airfield
 - [https://www.cbsnews.com/news/man-arrested-for-running-onto-lax-airfield](https://www.cbsnews.com/news/man-arrested-for-running-onto-lax-airfield)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T06:07:00+00:00

Police arrested a man after he ran onto the LAX airfield Wednesday night.

## 1/31: CBS Evening News
 - [https://www.cbsnews.com/video/013124-cbs-evening-news](https://www.cbsnews.com/video/013124-cbs-evening-news)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T05:05:02+00:00

An inside look at U.S. Navy ships tasked with securing the Red Sea; Reporting on a new kind of naval warfare

## About a dozen people injured in hangar collapse at Boise airport
 - [https://www.cbsnews.com/news/hangar-collapse-boise-idaho-injuries](https://www.cbsnews.com/news/hangar-collapse-boise-idaho-injuries)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T03:06:01+00:00

Authorities say about a dozen people were hurt when a hanger under construction on the grounds of the airport in Boise, Idaho, collapsed.

## 1/31: Prime Time with John Dickerson
 - [https://www.cbsnews.com/video/013024-cbs-news-prime-time-1](https://www.cbsnews.com/video/013024-cbs-news-prime-time-1)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T02:30:03+00:00

John Dickerson reports on the U.S. Navy shooting down missiles in the Red Sea, a standstill over a possible Senate border deal, and a political divide between Gen Z men and women.

## Gen Z women more liberal than men, study finds
 - [https://www.cbsnews.com/video/why-gender-split-exists-gen-z-political-beliefs](https://www.cbsnews.com/video/why-gender-split-exists-gen-z-political-beliefs)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:46:00+00:00

Gen Z women in the U.S. are now 30 percentage points more liberal than their male counterparts, according to a Financial Times analysis of Gallup data. Stanford University visiting fellow Dr. Alice Evans joins CBS News to discuss what's fueling the gender divergence.

## Are meal kits worth it? The case for meal delivery in 2024
 - [https://www.cbsnews.com/essentials/are-meal-kits-worth-it](https://www.cbsnews.com/essentials/are-meal-kits-worth-it)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:37:00+00:00

Wondering if meal kits are worth it? Here's why meal delivery services are worth the investment in 2024.

## Atmospheric river brings rain, flood risk to California
 - [https://www.cbsnews.com/video/atmospheric-river-heavy-rain-flood-risk-california](https://www.cbsnews.com/video/atmospheric-river-heavy-rain-flood-risk-california)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:35:00+00:00

Another atmospheric river is bringing heavy rain, high winds and mountain snow to much of California this week. CBS News correspondent Elise Preston reports.

## When will the Federal Reserve start cutting interest rates?
 - [https://www.cbsnews.com/video/when-will-federal-reserve-cut-interest-rates](https://www.cbsnews.com/video/when-will-federal-reserve-cut-interest-rates)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:31:00+00:00

The Federal Reserve announced Wednesday it would leave interest rates unchanged. Martin Baccardax, senior editor and chief markets correspondent for TheStreet, joins CBS News to discuss what the central bank is looking for to start cutting interest rates.

## Breaking down Senate's tech CEO hearing on child safety
 - [https://www.cbsnews.com/video/breaking-down-senate-tech-ceo-hearing-child-safety](https://www.cbsnews.com/video/breaking-down-senate-tech-ceo-hearing-child-safety)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:27:00+00:00

Five of the most powerful tech CEOs faced intense questioning on Capitol Hill Wednesday over the risks their social media platforms pose to minors. CBS News senior business and tech correspondent Jo Ling Kent reports on what executives told senators.

## Senate border deal facing opposition, confusion before release
 - [https://www.cbsnews.com/video/senate-border-deal-opposition-confusion-before-release](https://www.cbsnews.com/video/senate-border-deal-opposition-confusion-before-release)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:23:00+00:00

Lawmakers say the Senate is "whisper close" to releasing its border deal after weeks of negotiations, but some Republican senators are suggesting ditching the plans altogether. CBS News immigration and politics reporter Camilo Montoya-Galvez explains what's known about the bill.

## U.S. downs Houthi missile, drones targeting American warship
 - [https://www.cbsnews.com/video/us-downs-houthi-missile-drones-targeting-american-warship](https://www.cbsnews.com/video/us-downs-houthi-missile-drones-targeting-american-warship)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:19:00+00:00

The USS Carney shot down a ballistic missile and several drones near Yemen on Wednesday, according to a U.S. official who blamed Iranian-backed Houthis for the strikes. CBS Evening News anchor and managing editor Norah O'Donnell reports from Bahrain. Then, CBS News national security correspondent David Martin joins to examine the U.S. retaliation strategy.

## Reporting on a new kind of naval warfare
 - [https://www.cbsnews.com/video/reporting-on-a-new-kind-of-naval-warfare](https://www.cbsnews.com/video/reporting-on-a-new-kind-of-naval-warfare)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:07:00+00:00

U.S. Navy commanders told CBS News that the Navy hasn't operated under fire in a weapons engagement zone, like it has in the Red Sea, since World War II. "CBS Evening News" anchor and managing editor Norah O'Donnell has more.

## High rents leave many financially stretched
 - [https://www.cbsnews.com/video/high-rents-leave-many-financially-stretched](https://www.cbsnews.com/video/high-rents-leave-many-financially-stretched)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:06:00+00:00

While rents have been easing for the past few months nationwide, prices are still up significantly compared to before the pandemic, largely due to inflation. Providence, Rhode Island, saw one of the highest rent increases in the U.S. last year, and according to researchers, you need a salary of close to $83,000 to afford a two-bedroom apartment there. Nancy Chen reports.

## Prosecutors make case against mother of Oxford school gunman
 - [https://www.cbsnews.com/video/prosecutors-make-case-against-mother-of-oxford-school-gunman](https://www.cbsnews.com/video/prosecutors-make-case-against-mother-of-oxford-school-gunman)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:03:00+00:00

The involuntary manslaughter trial of Jennifer Crumbley, the mother of the teen gunman who killed four people and wounded seven others at Michigan's Oxford High School in 2021, continued Wednesday, with prosecutors showing the jury bodycam video of how Crumbley and her husband, James Crumbley, were arrested in Detroit four days after the shooting. Elaine Quijano has more.

## Best mattresses in a box for 2024
 - [https://www.cbsnews.com/essentials/best-mattresses-in-a-box-for-2023](https://www.cbsnews.com/essentials/best-mattresses-in-a-box-for-2023)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T01:01:00+00:00

Shop the best boxed mattresses of 2024 from trusted brands like Casper​, Tuft & Needle, and more.

## An inside look at U.S. Navy ships tasked with securing the Red Sea
 - [https://www.cbsnews.com/video/an-inside-look-at-u-s-navy-ships-tasked-with-securing-the-red-sea](https://www.cbsnews.com/video/an-inside-look-at-u-s-navy-ships-tasked-with-securing-the-red-sea)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T00:58:00+00:00

"CBS Evening News" anchor and managing editor Norah O'Donnell was taken aboard the aircraft carrier USS Eisenhower for an exclusive look at night operations as it patrols the Red Sea amid dangerous attacks from Houthi militants on commercial vessels in the area. CBS News was also taken aboard the missile destroyer USS Mason.

## Israel-Hezbollah clashes force evacuations of Israeli border village
 - [https://www.cbsnews.com/video/israel-hezbollah-clashes-force-evacuations-of-israeli-border-village](https://www.cbsnews.com/video/israel-hezbollah-clashes-force-evacuations-of-israeli-border-village)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T00:55:00+00:00

Israeli troops are now trading fire daily with Hezbollah fighters along Israel's northern border with Lebanon. Debora Patta traveled to the Israeli border village of Margaliot, which has been nearly entirely evacuated on government orders because of the violence.

## Tech CEOs grilled in Senate hearing on online child exploitation
 - [https://www.cbsnews.com/video/tech-ceos-grilled-in-senate-hearing-on-online-child-exploitation](https://www.cbsnews.com/video/tech-ceos-grilled-in-senate-hearing-on-online-child-exploitation)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T00:55:00+00:00

Meta CEO Mark Zuckerberg, along with the heads of Snap, TikTok, X and Discord, testified in a tense Senate Judiciary Committee hearing Wednesday about online child exploitation. Senators focused much of their fire on Zuckerberg, who apologized directly to families who were in the audience and held up photos of children who had died by suicide due to online sexual exploitation. Jo Ling Kent was at the hearing and has the latest.

## "CBS Evening News" headlines for Wednesday, January 31, 2024
 - [https://www.cbsnews.com/video/cbs-evening-news-headlines-for-wednesday-january-31-2024](https://www.cbsnews.com/video/cbs-evening-news-headlines-for-wednesday-january-31-2024)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T00:50:00+00:00

Here's a look at the top stories making headlines on the "CBS Evening News with Norah O'Donnell."

## What to know about the Iran-backed groups operating in the Mideast
 - [https://www.cbsnews.com/news/iran-backed-groups-iraq-militias-middle-east](https://www.cbsnews.com/news/iran-backed-groups-iraq-militias-middle-east)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T00:36:00+00:00

There are about 40 militant groups backed by Iran in the region, including one that claimed the deadly drone strike on a U.S. base in Jordan.

## The 5 best portable SSDs in 2024
 - [https://www.cbsnews.com/essentials/best-portable-ssds](https://www.cbsnews.com/essentials/best-portable-ssds)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T00:33:30+00:00

Need more external storage for important data? Check out this roundup of the best portable SSD options.

## Alec Baldwin pleads not guilty to refiled manslaughter charge
 - [https://www.cbsnews.com/news/alec-baldwin-pleads-not-guilty-refiled-manslaughter-charge-rust-shooting](https://www.cbsnews.com/news/alec-baldwin-pleads-not-guilty-refiled-manslaughter-charge-rust-shooting)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T00:26:47+00:00

Alec Baldwin pleaded not guilty to a refiled manslaughter charge stemming from the fatal shooting of Halyna Hutchins on the set of his film "Rust."

## U.S. figure skating captains on winning gold for 2022 Beijing Winter Olympics
 - [https://www.cbsnews.com/video/us-figure-skating-captains-on-winning-gold-for-2022-beijing-winter-olympics](https://www.cbsnews.com/video/us-figure-skating-captains-on-winning-gold-for-2022-beijing-winter-olympics)
 - RSS feed: https://www.cbsnews.com/latest/rss/main
 - date published: 2024-02-01T00:14:19+00:00

After a long investigation, Russia was stripped of a gold medal from the 2022 Beijing Winter Olympics for doping. Two years later, the U.S. figure skating team has earned the winning title. Team captains Madison Chock and Evan Bates join CBS News with their reactions.

