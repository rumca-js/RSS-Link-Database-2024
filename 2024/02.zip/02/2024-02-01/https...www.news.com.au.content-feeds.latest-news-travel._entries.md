# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel/, language:en-au

## Aussie airline unveils popular new route
 - [https://www.news.com.au/travel/travel-advice/flights/bonza-adds-popular-new-route-to-network-starting-from-89/news-story/13a5d8284cd56292742555b5a42c4573?from=rss-basic](https://www.news.com.au/travel/travel-advice/flights/bonza-adds-popular-new-route-to-network-starting-from-89/news-story/13a5d8284cd56292742555b5a42c4573?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T23:44:55.870317+00:00

Budget carrier Bonza is offering travellers new direct flights to two of Australia’s most popular tourist destinations, for just $89.

## Terrifying moment teen slams onto ground after dangling from ski lift
 - [https://www.news.com.au/travel/travel-updates/incidents/terrifying-moment-teen-slams-onto-ground-after-dangling-from-ski-lift/news-story/0ed6faf9812d3f3e3e9f6e7e31bda55e?from=rss-basic](https://www.news.com.au/travel/travel-updates/incidents/terrifying-moment-teen-slams-onto-ground-after-dangling-from-ski-lift/news-story/0ed6faf9812d3f3e3e9f6e7e31bda55e?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T23:44:51.308364+00:00

This is the shocking moment a 16-year-old snowboarder slammed onto the ground after dangling from a ski lift in California.

## Drunk man held down by passengers
 - [https://www.news.com.au/travel/travel-updates/incidents/drunk-passenger-held-down-by-fellow-flyers-after-becoming-aggressive-as-girlfriend-begs-him-to-stop/news-story/6cae3d2f725b3833e578583b79088b65?from=rss-basic](https://www.news.com.au/travel/travel-updates/incidents/drunk-passenger-held-down-by-fellow-flyers-after-becoming-aggressive-as-girlfriend-begs-him-to-stop/news-story/6cae3d2f725b3833e578583b79088b65?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T22:40:23.246643+00:00

A group of passengers tried to hold down a drunk traveller after he became aggressive as his girlfriend begged him to stop fighting them.

## Australia ‘unfair’ to Alan Joyce, Emirates boss says
 - [https://www.news.com.au/travel/travel-advice/flights/sir-tim-clark-on-unfair-treatment-of-alan-joyce-and-qantas-postcovid/news-story/cd0920e15e0fde3dd1a1768fdb3c72cb?from=rss-basic](https://www.news.com.au/travel/travel-advice/flights/sir-tim-clark-on-unfair-treatment-of-alan-joyce-and-qantas-postcovid/news-story/cd0920e15e0fde3dd1a1768fdb3c72cb?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T20:30:35.861199+00:00

Emirates boss Sir Tim Clark has revealed what he really thinks about former Qantas boss Alan Joyce and the airline’s tumultuous year.

## Tourists spark fury wearing budgie smugglers at Thailand airport
 - [https://www.news.com.au/travel/travel-advice/airports/tourists-spark-fury-wearing-budgie-smugglers-at-thailand-airport/news-story/c244f16bd3dc81fe54e7cbb24e521dc0?from=rss-basic](https://www.news.com.au/travel/travel-advice/airports/tourists-spark-fury-wearing-budgie-smugglers-at-thailand-airport/news-story/c244f16bd3dc81fe54e7cbb24e521dc0?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T15:02:43.252401+00:00

Two tourists have caused uproar for their bizarre choice of outfits at a Thai airport, with one person saying they were “100% Aussie”.

## NSW offering $30,000 to ‘poach’ essential workers from other states
 - [https://www.news.com.au/travel/australian-holidays/nsw-act/nsw-offering-30000-to-poach-essential-workers-from-other-states/news-story/1aefcad364c6bc1240c4504ae19d3378?from=rss-basic](https://www.news.com.au/travel/australian-holidays/nsw-act/nsw-offering-30000-to-poach-essential-workers-from-other-states/news-story/1aefcad364c6bc1240c4504ae19d3378?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T15:02:39.097256+00:00

Aussies have been offered up to $30,000 to move to NSW — but the other states aren’t happy about what they say is “poaching”.

## Woman caught on film dropping pants on plane
 - [https://www.news.com.au/travel/travel-updates/incidents/woman-caught-on-film-dropping-pants-on-plane-faces-21-years-in-jail/news-story/94b989916d64629e4a686a89a0211f89?from=rss-basic](https://www.news.com.au/travel/travel-updates/incidents/woman-caught-on-film-dropping-pants-on-plane-faces-21-years-in-jail/news-story/94b989916d64629e4a686a89a0211f89?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T07:05:02.619326+00:00

Passengers were left horrified when a woman allegedly dropped her pants in the aisle of a plane that was about to land.

## Verdict of doctor accused of lewd act next to teen on plane
 - [https://www.news.com.au/travel/travel-updates/incidents/verdict-of-doctor-accused-of-masturbating-next-to-14yearold-on-plane/news-story/0de7ce5da00159f54dc3e49f98cf177a?from=rss-basic](https://www.news.com.au/travel/travel-updates/incidents/verdict-of-doctor-accused-of-masturbating-next-to-14yearold-on-plane/news-story/0de7ce5da00159f54dc3e49f98cf177a?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T05:55:25.143260+00:00

A judge has handed down their verdict in the case of a doctor who was accused of masturbating next to a 14-year-old girl on a plane.

## Plus-size influencer’s gripe with shower design at Sydney hotel
 - [https://www.news.com.au/travel/travel-advice/accommodation/plussize-influencers-gripe-with-frustrating-shower-design-at-sydney-hotel/news-story/3686062f5f0ca8d0f038c2e8b5793d87?from=rss-basic](https://www.news.com.au/travel/travel-advice/accommodation/plussize-influencers-gripe-with-frustrating-shower-design-at-sydney-hotel/news-story/3686062f5f0ca8d0f038c2e8b5793d87?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T05:55:19.362466+00:00

Australian influencer ‘CurvySam’ has shared a “frustrating design” problem she found at a Sydney hotel.

## ‘Huge’: Business class prices almost halved
 - [https://www.news.com.au/travel/travel-advice/flights/flight-prices-2024-flight-centre-reveals-airfares-have-dropped/news-story/d9b0b900f3287525b85c2b25d1903913?from=rss-basic](https://www.news.com.au/travel/travel-advice/flights/flight-prices-2024-flight-centre-reveals-airfares-have-dropped/news-story/d9b0b900f3287525b85c2b25d1903913?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T02:34:05.544265+00:00

Flight prices have “finally dropped”, with Aussies keen to head overseas this year urged to book their tickets quick smart.

## ‘Secret is out’: Aussie beach goes viral
 - [https://www.news.com.au/travel/travel-updates/travel-stories/kutti-beach-private-paradise-every-aussie-wants-to-visit/news-story/c998e2de98ced290cdd63592add49bbd?from=rss-basic](https://www.news.com.au/travel/travel-updates/travel-stories/kutti-beach-private-paradise-every-aussie-wants-to-visit/news-story/c998e2de98ced290cdd63592add49bbd?from=rss-basic)
 - RSS feed: https://www.news.com.au/content-feeds/latest-news-travel/
 - date published: 2024-02-01T01:31:32.406546+00:00

A tiny beach in Sydney has captivated locals and tourists with the “hidden gem” going viral online.

