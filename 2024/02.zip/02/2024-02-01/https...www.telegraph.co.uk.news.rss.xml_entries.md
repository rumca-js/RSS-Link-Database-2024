# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Police name man wanted over Clapham chemical attack - latest updates
 - [https://www.telegraph.co.uk/news/2024/02/01/clapham-acid-attack-live-latest-news-corrosive-substance](https://www.telegraph.co.uk/news/2024/02/01/clapham-acid-attack-live-latest-news-corrosive-substance)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2024-02-01T13:54:53+00:00



## Escaped Highland monkey ‘Kingussie Kong’ recaptured
 - [https://www.telegraph.co.uk/news/2024/02/01/escaped-monkey-scotland-highland-wildlife-park-recaptured](https://www.telegraph.co.uk/news/2024/02/01/escaped-monkey-scotland-highland-wildlife-park-recaptured)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2024-02-01T12:19:38+00:00



## Footage shows chemical attack unfolding in Clapham
 - [https://www.telegraph.co.uk/news/2024/02/01/footage-chemical-attack-clapham-london](https://www.telegraph.co.uk/news/2024/02/01/footage-chemical-attack-clapham-london)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2024-02-01T10:33:17+00:00



