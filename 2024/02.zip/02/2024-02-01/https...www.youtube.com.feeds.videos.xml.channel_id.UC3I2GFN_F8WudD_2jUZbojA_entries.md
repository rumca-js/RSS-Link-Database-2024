# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Angel Du$t - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=MZej4OsQm0A](https://www.youtube.com/watch?v=MZej4OsQm0A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-02-01T16:00:14+00:00

http://KEXP.ORG presents Angel Du$t performing live in the KEXP studio. Recorded November 17, 2023

Songs:
Brand New Soul
Love Slam
Space Jam
Toxic Boombox
Sippin’ Lysol

Justice Tripp - Vocals
Steve Marino - Guitar, Vocals
Daniel Cudney - Guitar, Vocals
Zech Ghostribe - Bass
Thomas Cantwell - Drums

Host: Larry Mizell Jr.
Audio Engineers: Jon Roberts
Audio Mixer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Alaia D'Alessandro, Carlos Cruz, Jonathan Jacobson
Editor: Jonathan Jacobson

https://www.angeldustmoney.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Angel Du$t - Brand New Soul (Live on KEXP)
 - [https://www.youtube.com/watch?v=cK72zi75adU](https://www.youtube.com/watch?v=cK72zi75adU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-02-01T12:00:37+00:00

http://KEXP.ORG presents Angel Du$t performing “Brand New Soul ” live in the KEXP studio. Recorded November 17, 2023

Justice Tripp - Vocals
Steve Marino - Guitar, Vocals
Daniel Cudney - Guitar, Vocals
Zech Ghostribe - Bass
Thomas Cantwell - Drums

Host: Larry Mizell Jr.
Audio Engineers: Jon Roberts
Audio Mixer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Alaia D'Alessandro, Carlos Cruz, Jonathan Jacobson
Editor: Jonathan Jacobson

https://www.angeldustmoney.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Angel Du$t - Love Slam (Live on KEXP)
 - [https://www.youtube.com/watch?v=XkmXecf3pXo](https://www.youtube.com/watch?v=XkmXecf3pXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-02-01T12:00:33+00:00

http://KEXP.ORG presents Angel Du$t performing “Love Slam ” live in the KEXP studio. Recorded November 17, 2023

Justice Tripp - Vocals
Steve Marino - Guitar, Vocals
Daniel Cudney - Guitar, Vocals
Zech Ghostribe - Bass
Thomas Cantwell - Drums

Host: Larry Mizell Jr.
Audio Engineers: Jon Roberts
Audio Mixer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Alaia D'Alessandro, Carlos Cruz, Jonathan Jacobson
Editor: Jonathan Jacobson

https://www.angeldustmoney.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Angel Du$t - Sippin' Lysol (Live on KEXP)
 - [https://www.youtube.com/watch?v=OZ6IdNT0-iI](https://www.youtube.com/watch?v=OZ6IdNT0-iI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-02-01T12:00:30+00:00

http://KEXP.ORG presents Angel Du$t performing “Sippin' Lysol ” live in the KEXP studio. Recorded November 17, 2023

Justice Tripp - Vocals
Steve Marino - Guitar, Vocals
Daniel Cudney - Guitar, Vocals
Zech Ghostribe - Bass
Thomas Cantwell - Drums

Host: Larry Mizell Jr.
Audio Engineers: Jon Roberts
Audio Mixer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Alaia D'Alessandro, Carlos Cruz, Jonathan Jacobson
Editor: Jonathan Jacobson

https://www.angeldustmoney.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Angel Du$t - Space Jam (Live on KEXP)
 - [https://www.youtube.com/watch?v=D96cDs9saYc](https://www.youtube.com/watch?v=D96cDs9saYc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-02-01T12:00:18+00:00

http://KEXP.ORG presents Angel Du$t performing “Space Jam” live in the KEXP studio. Recorded November 17, 2023

Justice Tripp - Vocals
Steve Marino - Guitar, Vocals
Daniel Cudney - Guitar, Vocals
Zech Ghostribe - Bass
Thomas Cantwell - Drums

Host: Larry Mizell Jr.
Audio Engineers: Jon Roberts
Audio Mixer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Alaia D'Alessandro, Carlos Cruz, Jonathan Jacobson
Editor: Jonathan Jacobson

https://www.angeldustmoney.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Angel Du$t - Toxic Boombox (Live on KEXP)
 - [https://www.youtube.com/watch?v=2HsPU_vIT3w](https://www.youtube.com/watch?v=2HsPU_vIT3w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2024-02-01T12:00:04+00:00

http://KEXP.ORG presents Angel Du$t performing “Toxic Boombox” live in the KEXP studio. Recorded November 17, 2023

Justice Tripp - Vocals
Steve Marino - Guitar, Vocals
Daniel Cudney - Guitar, Vocals
Zech Ghostribe - Bass
Thomas Cantwell - Drums

Host: Larry Mizell Jr.
Audio Engineers: Jon Roberts
Audio Mixer: Kevin Suggs
Mastering: Julian Martlew
Cameras: Jim Beckmann, Alaia D'Alessandro, Carlos Cruz, Jonathan Jacobson
Editor: Jonathan Jacobson

https://www.angeldustmoney.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

