# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Specjalny komunikat prezesa PiS. "Domagamy się"
 - [https://wydarzenia.interia.pl/kraj/news-specjalny-komunikat-prezesa-pis-domagamy-sie,nId,7306088](https://wydarzenia.interia.pl/kraj/news-specjalny-komunikat-prezesa-pis-domagamy-sie,nId,7306088)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-02-01T18:48:13+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-specjalny-komunikat-prezesa-pis-domagamy-sie,nId,7306088"><img align="left" alt="Specjalny komunikat prezesa PiS. &quot;Domagamy się&quot;" src="https://i.iplsc.com/specjalny-komunikat-prezesa-pis-domagamy-sie/000IBOVZ1LXWOQO6-C321.jpg" /></a>&quot;Atak na niezależną prokuraturę, przeprowadzany z rażącym naruszeniem prawa i - co gorsza - przy skrajnej niekompetencji jego autorów, skutkuje ryzykiem uwolnienia od odpowiedzialności karnej tysięcy przestępców&quot; - oświadczył Jarosław Kaczyński w imieniu Komitetu Politycznego PiS. Prezes ugrupowania wystosował &quot;sprzeciw wobec kolejnych kroków rządu Donalda Tuska w kierunku systemowego bezprawia&quot;.</p><br clear="all" />

## Akcja we Wrocławiu. Trwa obława za kierowcą
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-akcja-we-wroclawiu-trwa-oblawa-za-kierowca,nId,7305794](https://wydarzenia.interia.pl/dolnoslaskie/news-akcja-we-wroclawiu-trwa-oblawa-za-kierowca,nId,7305794)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-02-01T15:11:32+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-akcja-we-wroclawiu-trwa-oblawa-za-kierowca,nId,7305794"><img align="left" alt="Akcja we Wrocławiu. Trwa obława za kierowcą" src="https://i.iplsc.com/akcja-we-wroclawiu-trwa-oblawa-za-kierowca/000D5EFR2LTDCL3J-C321.jpg" /></a>Po godzinie 14 na Psim Polu we Wrocławiu padły strzały. W trakcie rutynowej kontroli kierowca nagle ruszył, uderzył w radiowóz, potrącił policjanta i zaczął uciekać. Trwa policyjna obława za granatowym passatem. </p><br clear="all" />

## Kolejne radio regionalne w stanie likwidacji. Komunikat ministerstwa
 - [https://wydarzenia.interia.pl/kraj/news-kolejne-radio-regionalne-w-stanie-likwidacji-komunikat-minis,nId,7305658](https://wydarzenia.interia.pl/kraj/news-kolejne-radio-regionalne-w-stanie-likwidacji-komunikat-minis,nId,7305658)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-02-01T13:06:09+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kolejne-radio-regionalne-w-stanie-likwidacji-komunikat-minis,nId,7305658"><img align="left" alt="Kolejne radio regionalne w stanie likwidacji. Komunikat ministerstwa" src="https://i.iplsc.com/kolejne-radio-regionalne-w-stanie-likwidacji-komunikat-minis/000ICLO7PQLQYL3P-C321.jpg" /></a>Sąd Rejonowy w Kielcach wpisał do Krajowego Rejestru Sądowego otwarcie likwidacji Radia Kielce - przekazało Ministerstwo Kultury i Dziedzictwa Narodowego. To kolejna rozgłośnia regionalna, wobec której podjęto taką decyzję.</p><br clear="all" />

## Rynna śmierci w Karkonoszach. Zagrożenie na Śnieżce
 - [https://wydarzenia.interia.pl/kraj/news-rynna-smierci-w-karkonoszach-zagrozenie-na-sniezce,nId,7305622](https://wydarzenia.interia.pl/kraj/news-rynna-smierci-w-karkonoszach-zagrozenie-na-sniezce,nId,7305622)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-02-01T12:33:20+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-rynna-smierci-w-karkonoszach-zagrozenie-na-sniezce,nId,7305622"><img align="left" alt="Rynna śmierci w Karkonoszach. Zagrożenie na Śnieżce" src="https://i.iplsc.com/rynna-smierci-w-karkonoszach-zagrozenie-na-sniezce/000IIINH7TKFGXD0-C321.jpg" /></a>Rynna śmierci na Śnieżce niedawno znów zebrała śmiertelne żniwo. To jedno z najniebezpieczniejszych miejsc w Karkonoszach. Prowadząca na szczyt Śnieżki Droga Jubileuszowa zimą może okazać się bardzo groźna. Dowiedz się, czemu północne zbocze najwyższego szczytu Karkonoszy zawdzięcza swoją ponurą nazwę.</p><br clear="all" />

## Uciekł przed reżimem, zmarł nagle. Białorusini w żałobie
 - [https://wydarzenia.interia.pl/kraj/news-uciekl-przed-rezimem-zmarl-nagle-bialorusini-w-zalobie,nId,7305392](https://wydarzenia.interia.pl/kraj/news-uciekl-przed-rezimem-zmarl-nagle-bialorusini-w-zalobie,nId,7305392)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-02-01T12:14:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-uciekl-przed-rezimem-zmarl-nagle-bialorusini-w-zalobie,nId,7305392"><img align="left" alt="Uciekł przed reżimem, zmarł nagle. Białorusini w żałobie" src="https://i.iplsc.com/uciekl-przed-rezimem-zmarl-nagle-bialorusini-w-zalobie/000IIINA31S1ODRQ-C321.jpg" /></a>Alaksandr Kuwannikau nie żyje. Białorusin był jednym z nielicznych protestujących w zakładach tytoniowych w Grodnie. Po demonstracji sprzeciwu wobec reżimu wyemigrował do Polski. Zmarł nagle, pozostawił żonę oraz osierocił czwórkę dzieci.</p><br clear="all" />

## Działacz partii Ziobry zatrzymany. Policja wkroczyła do szkoły
 - [https://wydarzenia.interia.pl/kraj/news-dzialacz-partii-ziobry-zatrzymany-policja-wkroczyla-do-szkol,nId,7305546](https://wydarzenia.interia.pl/kraj/news-dzialacz-partii-ziobry-zatrzymany-policja-wkroczyla-do-szkol,nId,7305546)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-02-01T12:09:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dzialacz-partii-ziobry-zatrzymany-policja-wkroczyla-do-szkol,nId,7305546"><img align="left" alt="Działacz partii Ziobry zatrzymany. Policja wkroczyła do szkoły" src="https://i.iplsc.com/dzialacz-partii-ziobry-zatrzymany-policja-wkroczyla-do-szkol/000IIIFF8VPWIUOX-C321.jpg" /></a>19-letni Klaudiusz B. został zatrzymany przez policję. Funkcjonariusze zabrali go ze szkoły. Lubelski działacz Suwerennej Polski jest podejrzany o kradzież ponad 40 tys. złotych.  &quot;Będę aktywnie działał na rzecz wymiaru sprawiedliwości&quot; - deklarował jeszcze we wrześniu. Grozi mu do 10 lat więzienia. </p><br clear="all" />

## To już piąty dzień. Straż Graniczna podała zaskakujące dane
 - [https://wydarzenia.interia.pl/kraj/news-to-juz-piaty-dzien-straz-graniczna-podala-zaskakujace-dane,nId,7305521](https://wydarzenia.interia.pl/kraj/news-to-juz-piaty-dzien-straz-graniczna-podala-zaskakujace-dane,nId,7305521)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2024-02-01T10:24:15+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-to-juz-piaty-dzien-straz-graniczna-podala-zaskakujace-dane,nId,7305521"><img align="left" alt="To już piąty dzień. Straż Graniczna podała zaskakujące dane" src="https://i.iplsc.com/to-juz-piaty-dzien-straz-graniczna-podala-zaskakujace-dane/000IIHXPCRSNYUEF-C321.jpg" /></a>Straż Graniczna opublikowała kolejny komunikat dotyczący nielegalnej migracji. Po raz kolejny nie odnotowano nielegalnych prób przekroczenia polsko-białoruskiej granicy. Ta sytuacja utrzymuje się już od pięciu dni. W apogeum kryzysu do Polski próbowały dostać się tysiące migrantów. </p><br clear="all" />

