# Source:Techlinked, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCeeFfhMcJa1kjtfZAGskOCA, language:en-US

## Is Apple Gonna Be Okay?
 - [https://www.youtube.com/watch?v=S3pdX6GVsIg](https://www.youtube.com/watch?v=S3pdX6GVsIg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCeeFfhMcJa1kjtfZAGskOCA
 - date published: 2024-02-01T02:34:27+00:00

Head on over to https://hostinger.com/techlinked and use code TECHLINKED to save 10% on Hostinger today.

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► LISTEN TO THE TECH NEWS: https://lmg.gg/TechLinkedPodcast
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR PODCAST GEAR: https://lmg.gg/podcastgear

NEWS SOURCES: https://lmg.gg/eSmfn
---------------------------------------------------
Timestamps:
0:00 just dabblin'
0:14 Apple Vision Pro reviews
1:53 Neuralink implanted in first human 
3:16 General Motors will make PHEVs again
5:29 QUICK BITS INTRO
5:36 Big Tech testifies to US govt
6:28 RTX 3050 6GB leak
7:16 NY AG sues Citibank
8:03 fintech layoffs
8:52 Europcar data leak is fake

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: http://twitter.com/TechLinkedYT
Instagram: http://instagram.com/TechLinkedYT
Facebook: http://facebook.com/TechLinked
TikTok: https://www.t

