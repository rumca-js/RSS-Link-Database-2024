# Source:Turystyka, URL:https://turystyka.rp.pl/rss/3351-turystyka, language:pl-PL

## Hotele w Turcji zdrożały o jedną piątą. Najwięcej te w Antalyi
 - [https://turystyka.rp.pl/hotele/art39774271-hotele-w-turcji-zdrozaly-o-jedna-piata-najwiecej-te-w-antalyi](https://turystyka.rp.pl/hotele/art39774271-hotele-w-turcji-zdrozaly-o-jedna-piata-najwiecej-te-w-antalyi)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-02-01T23:23:00+00:00

W zeszłym roku średnia stawka dzienna w hotelach w Antalyi wyniosła 172,1 euro, co oznaczało wzrost o 19,35 procent w porównaniu z rokiem poprzednim. Przychód na pokój zwiększył się o 8 procent, do 96,8 euro.

## Ranking gościnności. Prym wiedzie Hiszpania, na szarym końcu Szwajcaria
 - [https://turystyka.rp.pl/zanim-wyjedziesz/art39773461-ranking-goscinnosci-prym-wiedzie-hiszpania-na-szarym-koncu-szwajcaria](https://turystyka.rp.pl/zanim-wyjedziesz/art39773461-ranking-goscinnosci-prym-wiedzie-hiszpania-na-szarym-koncu-szwajcaria)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-02-01T11:54:38+00:00

Holidu, portal specjalizujący się w wynajmie apartamentów wakacyjnych, sprawdził, które kraje są przez turystów uznawane za najbardziej gościnne. Pod uwagę wziął siedem kryteriów, na podstawie których stwierdził, że najlepiej pod tym względem wypada Hiszpania, najsłabiej Szwajcaria.

## W Grecji brakuje przewodników turystycznych. Ministerstwo uruchamia szybkie kursy
 - [https://turystyka.rp.pl/nowe-trendy/art39766801-w-grecji-brakuje-przewodnikow-turystycznych-ministerstwo-uruchamia-szybkie-kursy](https://turystyka.rp.pl/nowe-trendy/art39766801-w-grecji-brakuje-przewodnikow-turystycznych-ministerstwo-uruchamia-szybkie-kursy)
 - RSS feed: https://turystyka.rp.pl/rss/3351-turystyka
 - date published: 2024-02-01T00:03:00+00:00

Nowy, szybki kurs dla przewodników turystycznych, rozpocznie się w marcu na Krecie. Potrwa dwa miesiące – zachęca Ministerstwo Turystyki Grecji.

