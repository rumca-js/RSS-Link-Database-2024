# Source:Road to VR, URL:https://www.roadtovr.com/feed, language:en-US

## Quest 3 Pushed Meta Reality Labs to Record Revenue in Q4, But Also Record Costs
 - [https://www.roadtovr.com/reality-labs-revenue-q4-2023](https://www.roadtovr.com/reality-labs-revenue-q4-2023)
 - RSS feed: https://www.roadtovr.com/feed
 - date published: 2024-02-01T22:36:06+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="361" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2023/06/zuckerberg-quest-3-640x361.jpg" style="display: block; margin-bottom: 10px; clear: both;" width="640" /><div style="margin: 5px 5% 10px 5%;"><img alt="" height="220" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2023/06/zuckerberg-quest-3-341x220.jpg" title="Meta CEO Mark Zuckerberg wearing Quest 3 | Image courtesy Meta" width="341" /></div>
<div>Meta today announced its fourth quarter earnings for 2023, revealing how Reality Labs has fared during the holiday season. It&#8217;s been a banner quarter for Meta&#8217;s XR division, with Reality Labs posting record revenue numbers, but also record costs. During its Q4 earnings call, Meta revealed its XR division had crossed over $1 billion in [&#8230;]</div>
<p>The post <a href="https://www.roadtovr.com/reality-labs-revenue-q4-2023/" rel="nofollow">Quest 3 Pushed Meta Reality Labs

## Vision Pro Preview: Early Thoughts on My Time Inside Apple’s First Headset
 - [https://www.roadtovr.com/apple-vision-pro-preview](https://www.roadtovr.com/apple-vision-pro-preview)
 - RSS feed: https://www.roadtovr.com/feed
 - date published: 2024-02-01T19:40:21+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="360" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/02/apple-vision-pro-preview-ben-lang-640x360.jpg" style="display: block; margin-bottom: 10px; clear: both;" width="640" /><div style="margin: 5px 5% 10px 5%;"><img alt="" height="220" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/02/apple-vision-pro-preview-ben-lang-341x220.jpg" title="" width="341" /></div>
<div>Over the last three weeks I’ve had the chance to spend significant time in Apple Vision Pro. While my full review is still marinating, I want to share some early thoughts I&#8217;ve had while using the headset and what it means overall for the XR industry. It has to be said that anyone who doesn’t [&#8230;]</div>
<p>The post <a href="https://www.roadtovr.com/apple-vision-pro-preview/" rel="nofollow">Vision Pro Preview: Early Thoughts on My Time Inside Apple&#8217;s First Headset</a> appeared first on <a href="https:

## ‘Stranger Things VR’ Coming Exclusively to Quest This Month
 - [https://www.roadtovr.com/stranger-things-vr-release-fall-2023-psvr-2-quest-steam](https://www.roadtovr.com/stranger-things-vr-release-fall-2023-psvr-2-quest-steam)
 - RSS feed: https://www.roadtovr.com/feed
 - date published: 2024-02-01T18:50:20+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="360" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2023/05/stranger-things-vrtitle-640x360.jpg" style="display: block; margin-bottom: 10px; clear: both;" width="640" /><div style="margin: 5px 5% 10px 5%;"><img alt="" height="220" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2023/05/stranger-things-vrtitle-341x220.jpg" title="Image courtesy Tender Claws" width="341" /></div>
<div>Stranger Things VR has been delayed past its original November 30th launch date. Now VR veteran studio Tender Claws says the psychological horror game is coming to Quest on February 22nd. Update (February 1st, 2024): Tender Claws announced that Stranger Things VR now has a new launch date, February 22nd. It&#8217;s slated to come to Quest [&#8230;]</div>
<p>The post <a href="https://www.roadtovr.com/stranger-things-vr-release-fall-2023-psvr-2-quest-steam/" rel="nofollow">&#8216;Stranger Things VR&#8217; Comin

## Unity Releases 1.0 Tools for Vision Pro App Development
 - [https://www.roadtovr.com/unity-releases-1-0-tools-for-vision-pro-app-development](https://www.roadtovr.com/unity-releases-1-0-tools-for-vision-pro-app-development)
 - RSS feed: https://www.roadtovr.com/feed
 - date published: 2024-02-01T13:02:03+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="360" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/02/unity-vision-pro-640x360.jpg" style="display: block; margin-bottom: 10px; clear: both;" width="640" /><div style="margin: 5px 5% 10px 5%;"><img alt="" height="220" src="https://roadtovrlive-5ea0.kxcdn.com/wp-content/uploads/2024/02/unity-vision-pro-341x220.jpg" title="Image courtesy Unity" width="341" /></div>
<div>Unity has officially launched 1.0 support for visionOS, making its now Vision Pro-compatible game engine available to all Unity Pro, Enterprise, and Industry subscribers. Unity announced in recent a blog post that support for visionOS is now out of beta, which lets paid users create three main types of XR experiences: mixed reality apps, fully-immersive virtual reality apps, [&#8230;]</div>
<p>The post <a href="https://www.roadtovr.com/unity-releases-1-0-tools-for-vision-pro-app-development/" rel="nofollow">Unity Releases 1.0 Too

