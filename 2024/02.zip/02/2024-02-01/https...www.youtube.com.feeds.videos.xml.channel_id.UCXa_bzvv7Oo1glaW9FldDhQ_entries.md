# Source:GamingBolt, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ, language:en-US

## What Did They Do to My Boy Batman?!
 - [https://www.youtube.com/watch?v=OWk2UlQWMBg](https://www.youtube.com/watch?v=OWk2UlQWMBg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2024-02-01T16:00:11+00:00

Suicide Squad: Kill the Justice League is currently in early access for Deluxe Edition owners, with the worldwide release set for February 2nd on Xbox Series X/S, PS5 and PC. Early impressions are a bit mixed, but there's been negative feedback concerning the fate of Batman.

As one of the members of the brainwashed Justice League that players must take down, Batman presents a unique challenge as a character. He's the greatest detective in DC Universe, capable of developing multiple counter-measures against forces beyond his reach. The fact that this is the same Batman from the Arkham games is also worth noting since fans are aware of his ingenuity and resolve.

The fact that he ends up this way has generated some backlash. Let's go over why and how the story doesn't help matters.

## 10 NEW PS5 State of Play Announcements You Likely Missed
 - [https://www.youtube.com/watch?v=TrEKYOiU7Qo](https://www.youtube.com/watch?v=TrEKYOiU7Qo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXa_bzvv7Oo1glaW9FldDhQ
 - date published: 2024-02-01T08:15:01+00:00

2024's first State of Play has concluded, and we got new impressions from several upcoming games. There were a few surprises too like Hideo Kojima's return to developing espionage games. 

In this video we take a look at 10 of the biggest announcements from State of Play.

