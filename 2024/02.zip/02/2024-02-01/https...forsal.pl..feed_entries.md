# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Lumiere od Google'a: sztuczna inteligencja zrewolucjonizuje kino?
 - [https://forsal.pl/lifestyle/technologie/artykuly/9413005,lumiere-od-googlea-sztuczna-inteligencja-zrewolucjonizuje-kino.html](https://forsal.pl/lifestyle/technologie/artykuly/9413005,lumiere-od-googlea-sztuczna-inteligencja-zrewolucjonizuje-kino.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T20:29:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-qhktkuTURBXy82NGY0ZmYwMS0zOWZmLTQ2MzktYjNmZi05NzVhYjMzOTMwYWUuanBlZ5GTBc0BHcyg" />Co by było, gdybyś mógł wyobrazić sobie film i zobaczyć go na ekranie w ciągu kilku sekund? To właśnie umożliwia nowy generator z tekstu na wideo o nazwie Lumiere, opracowany przez zespół badaczy AI z Google Research.

## Niemcy planują wywłaszczyć Rosjan z rafinerii w Schwedt.  Udziały trafią do Polski?
 - [https://forsal.pl/biznes/energetyka/artykuly/9422816,niemcy-planuja-wywlaszczyc-rosjan-z-rafinerii-w-schwedt-udzialy-traf.html](https://forsal.pl/biznes/energetyka/artykuly/9422816,niemcy-planuja-wywlaszczyc-rosjan-z-rafinerii-w-schwedt-udzialy-traf.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T20:07:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KCYktkuTURBXy8zYjBmMDAyOS04N2ZiLTQ5Y2EtOTJkMC1lOGNlYzdlYTNlMWYuanBlZ5GTBc0BHcyg" />Niemieckie ministerstwo gospodarki planuje do początku marca wywłaszczyć rosyjski koncern Rosnieft z rafinerii ropy naftowej PCK Schwedt i sprzedać udziały Polakom – napisał w czwartek niemiecki portal Business Insider (BI).

## Automotive: baterie przyszłości (powoli) nadchodzą
 - [https://forsal.pl/motoforsal/artykuly/9415230,automotive-baterie-przyszlosci-powoli-nadchodza.html](https://forsal.pl/motoforsal/artykuly/9415230,automotive-baterie-przyszlosci-powoli-nadchodza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T18:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0IOktkuTURBXy83YzgyMmY4ZC05NDVmLTQ5MWYtYTJiYy02YWIxYTQxMjkyNTcuanBlZ5GTBc0BHcyg" />Czym są baterie półprzewodnikowe i czym różnią się od tych stosowanych dziś w samochodach? Dlaczego wielu ekspertów uważa je za przełom w motoryzacji i rozwoju elektromobilności?

## Minister rolnictwa: Komisja Europejska zaczyna dostrzegać problemy rolników
 - [https://forsal.pl/biznes/rolnictwo/artykuly/9422718,minister-rolnictwa-komisja-europejska-zaczyna-dostrzegac-problemy-rol.html](https://forsal.pl/biznes/rolnictwo/artykuly/9422718,minister-rolnictwa-komisja-europejska-zaczyna-dostrzegac-problemy-rol.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T18:01:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FHTktkuTURBXy9mNDA4MjNkNy1hODM2LTQ2N2UtOTNhYy1hZGQyMDI3YzZlYTguanBlZ5GTBc0BHcyg" />Minister rolnictwa Czesława Siekierski ocenił w czwartek, że Komisja Europejska &quot;budzi się &quot;i zaczyna dostrzegać problemy rolników związane m.in. z napływem produktów z Ukrainy.

## Co czują Polacy na myśl o sytuacji w Polsce? Przeważają negatywne emocje [SONDAŻ]
 - [https://forsal.pl/artykuly/9422711,co-czuja-polacy-na-mysl-o-sytuacji-w-polsce-przewazaja-negatywne-emoc.html](https://forsal.pl/artykuly/9422711,co-czuja-polacy-na-mysl-o-sytuacji-w-polsce-przewazaja-negatywne-emoc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T17:40:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vUdktkuTURBXy8yNzNkNTU3Mi0yNTJlLTQwMWYtOGJmOS0xOTkzZGM5MGI1NjcuanBlZ5GTBc0BHcyg" />42 proc. Polaków odczuwa zdenerwowanie na myśl o sytuacji w Polsce. Najbardziej zadowoleni są wyborcy KO (37 proc.), najmniej – Konfederacji (5 proc.). Wyborcy Lewicy najczęściej czują zażenowanie (52 proc.) – wynika z sondażu CBOS &quot;Co teraz czują Polacy?&quot;.

## Podwyżki dla nauczycieli dopiero od kwietnia? Mogą być nawet później
 - [https://forsal.pl/lifestyle/edukacja/artykuly/9422703,podwyzki-dla-nauczycieli-dopiero-od-kwietnia-moga-byc-nawet-pozniej.html](https://forsal.pl/lifestyle/edukacja/artykuly/9422703,podwyzki-dla-nauczycieli-dopiero-od-kwietnia-moga-byc-nawet-pozniej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T17:03:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_5UktkuTURBXy9hODMxNmJiYi1hMmYyLTQzNTEtOWYzOS02N2EyZTUwMDU1MzguanBlZ5GTBc0BHcyg" />Może się zdarzyć, że podwyżki wynagrodzeń nauczycieli nie będą, jak zakładaliśmy, od marca, lecz dopiero od kwietnia z wyrównaniem od stycznia – poinformowała w czwartek po spotkaniu ze związkami zawodowymi minister edukacji Barbara Nowacka. Kolejne rozmowy 8 lutego.

## Mimo sankcji rosyjska ropa naftowa trafia do USA
 - [https://forsal.pl/swiat/usa/artykuly/9420436,mimo-sankcji-rosyjska-ropa-naftowa-trafia-do-usa.html](https://forsal.pl/swiat/usa/artykuly/9420436,mimo-sankcji-rosyjska-ropa-naftowa-trafia-do-usa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T17:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/57XktkuTURBXy8wMzEyZTI5Zi01NGFmLTRlODMtYmU3Yy0wNGFjNjcwODdiOWMuanBlZ5GTBc0BHcyg" />Mimo sankcji nałożonych na Rosję po ataku na Ukrainę amerykańska rafineria zaimportowała 10 tys. baryłek rosyjskiej ropy. Umożliwiła to luka w zakresie mieszania surowca w terminalach magazynowych na Bahamach.

## Notowania ropy w górę. Zarówno Brent, jak i WTI
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9422697,notowania-ropy-w-gore-zarowno-brent-jak-i-wti.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9422697,notowania-ropy-w-gore-zarowno-brent-jak-i-wti.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T16:35:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hCiktkuTURBXy8yOTE1ZTZjOC01OTc2LTRkNjEtOGE4Ni1kYWJkZWM0Njc3NDIuanBlZ5GTBc0BHcyg" />W czwartek po godz. 17 ceny ropy naftowej Brent na giełdzie w Londynie wzrosły o 0,73 proc., do 81,14 dol. za baryłkę. Notowania ropy WTI na giełdzie w Nowym Jorku również szły w górę - o 0,98 proc., do 76,59 dol. za baryłkę.

## UE coraz bardziej poirytowana polityką Węgier? Ale kompromis jest
 - [https://forsal.pl/artykuly/9422689,ue-coraz-bardziej-poirytowana-polityka-wegier-ale-kompromis-jest.html](https://forsal.pl/artykuly/9422689,ue-coraz-bardziej-poirytowana-polityka-wegier-ale-kompromis-jest.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T16:13:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/f4JktkuTURBXy81YTlkNWYyOC1mOTgzLTRlYjYtYjAyMS03NDRiMTU0MTdlZmMuanBlZ5GTBc0BHcyg" />Pomimo czwartkowego kompromisu w sprawie pomocy finansowej dla Ukrainy, Unia Europejska jest coraz bardziej poirytowana polityką premiera Węgier Viktora Orbana – oceniła w rozmowie z PAP Ilona Gizińska, analityczka ds. Węgier z warszawskiego Ośrodka Studiów Wschodnich (OSW).

## Niemiecki kryzys stawia Europę Środkową pod ścianą
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9415092,niemiecki-kryzys-stawia-europe-srodkowa-pod-sciana.html](https://forsal.pl/swiat/unia-europejska/artykuly/9415092,niemiecki-kryzys-stawia-europe-srodkowa-pod-sciana.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T15:14:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/d2bktkuTURBXy9iZmU5OTlkOC1lZmI3LTRiMTQtOWMxMC02MDBmMjJiZWVjODMuanBlZ5GTBc0BHcyg" />Niemiecka gospodarka zmierza w kierunku recesji, a to stawia Europę Środkową w obliczu poważnych zagrożeń. Region jest silnie uzależniony od niemieckiego eksportu, a w szczególności od sektora motoryzacyjnego. Jeśli gospodarka niemiecka załamie się, to będzie to oznaczało poważne problemy dla krajów Europy Środkowej.

## PMI dla przemysłu USA w górę do 50,7 pkt.
 - [https://forsal.pl/swiat/usa/artykuly/9422384,pmi-dla-przemyslu-usa-w-gore-do-507-pkt.html](https://forsal.pl/swiat/usa/artykuly/9422384,pmi-dla-przemyslu-usa-w-gore-do-507-pkt.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T15:11:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/V4yktkuTURBXy81YjE1N2E1NC0zY2JmLTQ4ZTUtYmYzMi04ZDNlMmMyMWI1NDUuanBlZ5GTBc0BHcyg" />undefined

## Dania chce wspierać Polskę w rozwoju energetyki odnawialnej
 - [https://forsal.pl/biznes/ekologia/artykuly/9422306,dania-chce-wspierac-polske-w-rozwoju-energetyki-odnawialnej.html](https://forsal.pl/biznes/ekologia/artykuly/9422306,dania-chce-wspierac-polske-w-rozwoju-energetyki-odnawialnej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T14:56:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0CpktkuTURBXy8xMTk3N2JiOS02ZWEwLTRlN2UtOTAxMi0zNmZhZTJiOTQyZTUuanBlZ5GTBc0BHcyg" />Rząd Danii i nasz sektor komercyjny gotów jest wspierać Polskę w rozwoju energetyki odnawialnej - wskazał w czwartek w Senacie duński minister ds. klimatu, energii i zaopatrzenia Lars Aagaard.

## Ekspert: Czy karanie za posiadanie marihuany faktycznie ma sens?
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/9422226,ekspert-czy-karanie-za-posiadanie-marihuany-faktycznie-ma-sens.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/9422226,ekspert-czy-karanie-za-posiadanie-marihuany-faktycznie-ma-sens.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T14:42:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SARktkuTURBXy8yZDZlMjY3My1lNjBmLTRiYWMtYWU4MC04ZTExOTY4NmM2ZTQuanBlZ5GTBc0BHcyg" />W Polsce dostępna jest medyczna marihuana, więc można dyskutować, czy karanie za posiadanie marihuany faktycznie ma sens – powiedział w rozmowie z PAP prof. Piotr Gałecki, krajowy konsultant w dziedzinie psychiatrii.

## Budimex planuje dalszą dywersyfikację i start działalności na Łotwie w 2024 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9422196,budimex-planuje-dalsza-dywersyfikacje-i-start-dzialalnosci-na-lotwie-w.html](https://forsal.pl/finanse/gielda/artykuly/9422196,budimex-planuje-dalsza-dywersyfikacje-i-start-dzialalnosci-na-lotwie-w.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T14:40:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sRPktkuTURBXy80ZTlmNDRjOS05M2Q5LTRkYzgtYmY4Yy1hN2FiZjJlZTAyNDcuanBlZ5GTBc0BHcyg" />undefined

## OT Logistics miało wstępnie ok. 160 mln zł zysku netto w 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9422164,ot-logistics-mialo-wstepnie-ok-160-mln-zl-zysku-netto-w-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/9422164,ot-logistics-mialo-wstepnie-ok-160-mln-zl-zysku-netto-w-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T14:34:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oYVktkuTURBXy8yMDI4MDJhYy02MGFjLTQyMDYtYTlhMC0yODQ2MjI0NTNiM2YuanBlZ5GTBc0BHcyg" />undefined

## Kernel: Postępowanie ws. wykluczenia spółki z GPW powinno zakończyć się w lutym 2024 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9422145,kernel-postepowanie-ws-wykluczenia-spolki-z-gpw-powinno-zakonczyc-si.html](https://forsal.pl/finanse/gielda/artykuly/9422145,kernel-postepowanie-ws-wykluczenia-spolki-z-gpw-powinno-zakonczyc-si.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T14:32:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cQZktkuTURBXy9kNDdjOWMxNS00ZDI3LTQ4ZjYtYTg1Yy1jYTRlYmZhM2Q5MDUuanBlZ5GTBc0BHcyg" />undefined

## Chiny ostrzegają Ukrainę. "Nasze firmy to nie sponsorzy wojny"
 - [https://forsal.pl/swiat/chiny/artykuly/9422133,chiny-ostrzegaja-ukraine-nasze-firmy-to-nie-sponsorzy-wojny.html](https://forsal.pl/swiat/chiny/artykuly/9422133,chiny-ostrzegaja-ukraine-nasze-firmy-to-nie-sponsorzy-wojny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T14:29:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ew1ktktTURBXy80ZjkwYzIxMS1jMTk4LTQwZTQtYmJmNi1iNjMzZWY5OGFlMTMucG5nkZMFzQEdzKA" />Chińskie władze przestrzegły Ukrainę, że uznanie przez Kijów kilkunastu chińskich firm za &quot;międzynarodowych sponsorów wojny&quot; może mieć negatywny wpływ na stosunki między państwami – informuje w czwartek agencja Reutera, powołując się na dwa ukraińskie źródła wysokiego szczebla.

## Euro oficjalnie jedyną walutą akceptowaną w Kosowie
 - [https://forsal.pl/finanse/waluty/artykuly/9421986,euro-oficjalnie-jedyna-waluta-akceptowana-w-kosowie.html](https://forsal.pl/finanse/waluty/artykuly/9421986,euro-oficjalnie-jedyna-waluta-akceptowana-w-kosowie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T14:04:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1-JktkuTURBXy9iNjIxZTY5ZS0xMjNjLTRmYmMtOWM3NS04ZDMyYTQyYzBhYzMuanBlZ5GTBc0BHcyg" />Euro jest od czwartku jedyną walutą oficjalnie akceptowaną w Kosowie. W okresie przejściowym w kraju będzie można jednak nadal płacić dinarami serbskimi, powszechnie używanymi w rejonach zamieszkiwanych przez Serbów.

## Polacy chętniej odwiedzali centra handlowe w 2023 r.? Inflacja nie przeszkodziła
 - [https://forsal.pl/biznes/handel/artykuly/9421984,polacy-chetniej-odwiedzali-centra-handlowe-w-2023-r-inflacja-nie-prz.html](https://forsal.pl/biznes/handel/artykuly/9421984,polacy-chetniej-odwiedzali-centra-handlowe-w-2023-r-inflacja-nie-prz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T14:00:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZdZktkuTURBXy9lM2NjNTc3Ni01ZTBmLTQxZTEtYTJlNS0zN2Q4NjNkY2E5YjguanBlZ5GTBc0BHcyg" />Pomimo trudnej sytuacji gospodarczej Polacy chętniej odwiedzali centra handlowe - w 2023 r. odwiedzalność galerii handlowych wzrosła o 4,6 proc. wobec roku 2022, do 10,8 osób miesięcznie na metr kwadratowy - wynika z badania przeprowadzonego na zlecenie Polskiej Rady Centrów Handlowych.

## Jaka będzie strategia migracyjna Polski na lata 2025-2030? MSWiA: Ruszają prace nad jej stworzeniem
 - [https://forsal.pl/gospodarka/polityka/artykuly/9421933,jaka-bedzie-strategia-migracyjna-polski-na-lata-2025-2030-mswia-ruszaja-prace-nad-jej-stworzeniem.html](https://forsal.pl/gospodarka/polityka/artykuly/9421933,jaka-bedzie-strategia-migracyjna-polski-na-lata-2025-2030-mswia-ruszaja-prace-nad-jej-stworzeniem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T13:56:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NiQktkuTURBXy83ZjYzNjIxYS04MmZmLTRiY2QtYmQ1NS00NzMwZTMzZDExMzMuanBlZ5GTBc0BHcyg" />W Ministerstwie Spraw Wewnętrznych i Administracji ruszają prace nad stworzeniem kompleksowej, odpowiedzialnej i bezpiecznej strategii migracyjnej Polski na lata 2025-2030. Proces wdrażania strategii zakończy się przed objęciem przez Polskę prezydencji w Radzie Unii Europejskiej - przekazało w czwartek MSWiA.

## PiS poprze zwiększenie renty socjalnej do kwoty minimalnego wynagrodzenia
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9421918,pis-poprze-zwiekszenie-renty-socjalnej-do-kwoty-minimalnego-wynagrodze.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9421918,pis-poprze-zwiekszenie-renty-socjalnej-do-kwoty-minimalnego-wynagrodze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T13:52:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uUdktktTURBXy9hYzVjOWJhOC04MTMwLTRhMmUtOWU4YS1kOTQ1NDdhZmM5ODkucG5nkZMFzQEdzKA" />Posłanka Marlena Maląg zapowiedziała, że PiS będzie popierać projekt zwiększenia renty socjalnej do kwoty minimalnego wynagrodzenia. &quot;Polityka społeczna jest w DNA Prawa i Sprawiedliwości&quot; - dodała.

## KO: Skończyła się era Daniela Obajtka, ale to dopiero początek jego problemów
 - [https://forsal.pl/gospodarka/polityka/artykuly/9421868,ko-skonczyla-sie-era-daniela-obajtka-ale-to-dopiero-poczatek-jego-problemow.html](https://forsal.pl/gospodarka/polityka/artykuly/9421868,ko-skonczyla-sie-era-daniela-obajtka-ale-to-dopiero-poczatek-jego-problemow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T13:45:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UWoktkuTURBXy8zOGFkM2IxZi05NjMzLTQ3MGItODc1OC04MDgzZmRjNzQwYzQuanBlZ5GTBc0BHcyg" />Skończyła się era Daniela Obajtka, choć to dopiero początek jego problemów. Teraz czas na audyty, pracę śledczych oraz kontrolerów NIK-u - mówili w czwartek Agnieszka Pomaska i Michał Szczerba (KO) komentując decyzję rady nadzorczej Orlenu o odwołaniu Daniela Obajtka z zarządu spółki.

## Bezpieczeństwo Ukrainy - bezpieczeństwem Europy: Roberta Metsola
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9421834,bezpieczenstwo-ukrainy-bezpieczenstwem-europy-roberta-metsola.html](https://forsal.pl/swiat/unia-europejska/artykuly/9421834,bezpieczenstwo-ukrainy-bezpieczenstwem-europy-roberta-metsola.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T13:39:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/82sktkuTURBXy85MGFiYWQ2Zi1iYmE5LTQ4MTYtOWQxOS1kODdlMDNkYjFjMjUuanBlZ5GTBc0BHcyg" />Wsparcie dla Ukrainy ostatecznie dotyczy także naszego własnego, europejskiego bezpieczeństwa – powiedziała przewodnicząca PE Roberta Metsola na odbywającym się w czwartek nadzwyczajnym szczycie UE. &quot;Jesteśmy to winni narodowi ukraińskiemu. Jesteśmy to także winni Europejczykom&quot; - zaznaczyła.

## MFW: Ruch kontenerowców na Morzu Czerwonym spada o jedną trzecią
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9421745,mfw-ruch-kontenerowcow-na-morzu-czerwonym-spada-o-jedna-trzecia.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9421745,mfw-ruch-kontenerowcow-na-morzu-czerwonym-spada-o-jedna-trzecia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T13:24:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6i_ktkuTURBXy9iZDU2ZTRiNy0wMDhjLTRmODYtOGY1ZC1jNGJmZjkyMjNmOWMuanBlZ5GTBc0BHcyg" />Ruch kontenerowców na Morzu Czerwonym zmniejszył się o 30 proc. w stosunku do listopada ubiegłego roku - poinformował szef wydziału Bliskiego Wschodu i Azji Centralnej Międzynarodowego Funduszu Walutowego (MFW), Jihad Azour, dodając, że liczba przewozów spadła szczególnie od początku stycznia.

## Nominowani do Pokojowej Nagrody Nobla. Na liście papież Franciszek i Jens Stoltenberg
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9421739,papiez-franciszek-i-jens-stoltenberg-wsrod-nominowanych-do-pokojowej-nagrody-nobla.html](https://forsal.pl/swiat/aktualnosci/artykuly/9421739,papiez-franciszek-i-jens-stoltenberg-wsrod-nominowanych-do-pokojowej-nagrody-nobla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T13:17:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zJjktkuTURBXy81MGZlOTM5Ni0wYzRmLTRkMDUtYWU2Zi1lY2UzZDk5ZmU4ZGQuanBlZ5GTBc0BHcyg" />Papież Franciszek i sekretarz generalny NATO Jens Stoltenberg są wśród osób nominowanych do tegorocznej Pokojowej Nagrody Nobla - wynika z deklaracji wnioskodawców. W środę minął termin zgłaszania kandydatur.

## Zełenski: Wsparcie finansowe od UE jest nie mniej istotne od pomocy wojskowej
 - [https://forsal.pl/swiat/ukraina/artykuly/9421735,zelenski-wsparcie-finansowe-od-ue-jest-nie-mniej-istotne-od-pomocy-wojskowej.html](https://forsal.pl/swiat/ukraina/artykuly/9421735,zelenski-wsparcie-finansowe-od-ue-jest-nie-mniej-istotne-od-pomocy-wojskowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T13:11:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xegktkuTURBXy9hMWQ5M2UyOC0xZmEwLTRmYjEtYjAwMS02MDRjODU3YzAzYWEuanBlZ5GTBc0BHcyg" />Kontynuacja wsparcia finansowego Unii Europejskiej dla Ukrainy wzmocni naszą stabilność finansową i jest nie mniej istotne od pomocy wojskowej; bardzo ważne, że pakiet pomocowy został uchwalony przez wszystkich przywódców unijnych – oświadczył w czwartek prezydent Ukrainy Wołodymyr Zełenski.

## Kto może zostać nowym prezydentem Polski? [SONDAŻ]
 - [https://forsal.pl/gospodarka/polityka/artykuly/9421672,kto-moze-zostac-nowym-prezydentem-polski-sondaz.html](https://forsal.pl/gospodarka/polityka/artykuly/9421672,kto-moze-zostac-nowym-prezydentem-polski-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T12:59:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/abwktkuTURBXy83NDcyNThkOC05NTJhLTRkMDYtOWI0My0wNTc5MDJmZmRlZWEuanBlZ5GTBc0BHcyg" />Poparcie w wyborach prezydenckim dla Rafała Trzaskowskiego deklaruje 25,8 proc. badanych, Mateusz Morawiecki może liczyć na 24,9 proc. głosów, a Szymon Hołownia na 24,6 proc. - wynika z sondażu IBRIS dla Onetu. Portal podaje, że Trzaskowski stracił 8,8 proc., a Hołownia zyskał 12,9 proc.

## Hołownia: Tłuste koty pakują kuwety; czas na konkursy i profesjonalne zarządzanie majątkiem
 - [https://forsal.pl/gospodarka/prawo/artykuly/9421648,holownia-tluste-koty-pakuja-kuwety-czas-na-konkursy-i-profesjonalne-zarzadzanie-majatkiem.html](https://forsal.pl/gospodarka/prawo/artykuly/9421648,holownia-tluste-koty-pakuja-kuwety-czas-na-konkursy-i-profesjonalne-zarzadzanie-majatkiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T12:55:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7tIktkuTURBXy81OTE2OGEyNy00ZDc3LTRjODUtODY2Mi0xYWRhMmVlNTJhZWUuanBlZ5GTBc0BHcyg" />Lider Polski 2050 Szymon Hołownia zapowiedział w czwartek, że jego formacja zaproponuje rozwiązanie ustawowe, które odpartyjni zarządy spółek. Według marszałka Sejmu &quot;czas na konkursy i profesjonalne zarządzanie naszym majątkiem&quot;.

## Twój e-PIT. Ministerstwo Finansów informuje o ważnym terminie
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9421486,twoj-e-pit-ministerstwo-finansow-informuje-o-waznym-terminie.html](https://forsal.pl/finanse/aktualnosci/artykuly/9421486,twoj-e-pit-ministerstwo-finansow-informuje-o-waznym-terminie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T12:28:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jsEktkuTURBXy8zODczMWE2NS0zYzc1LTQxMjUtOGY1Yi0wNTZhZTA4ZDU5MDAuanBlZ5GTBc0BHcyg" />Od 2 do 14 lutego Krajowa Administracja Skarbowa będzie zasilać system Twój e-PIT danymi z deklaracji podatkowych od pracodawców. Umożliwi to wygenerowanie wstępnie wypełnionych deklaracji PIT, które będą dostępne od 15 lutego – podało Ministerstwo Finansów w informacji przesłanej w czwartek PAP.

## Współpraca w dziedzinie bezpieczeństwa i obrony. Szefowie MON Polski i Danii podpisali porozumienie
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9421396,wspolpraca-w-dziedzinie-bezpieczenstwa-i-obrony-szefowie-mon-polski-i-danii-podpisali-porozumienie.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9421396,wspolpraca-w-dziedzinie-bezpieczenstwa-i-obrony-szefowie-mon-polski-i-danii-podpisali-porozumienie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T12:13:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OB9ktkuTURBXy81YTE1NzhkNC0yMTczLTQ0NDEtOTFmZC0wMGFiMzY5ZGMxODguanBlZ5GTBc0BHcyg" />Wicepremier, szef MON Władysław Kosiniak-Kamysz i wicepremier, minister obrony Danii Troels Lund Poulsen podpisali w czwartek porozumienie o współpracy między resortami w dziedzinie bezpieczeństwa i obrony. Kosiniak-Kamysz przekazał, że rozmawiał z Poulsenem m.in. o zacieśnianiu naszej współpracy.

## Wiceszefowa dyplomacji USA: Władimira Putina czekają "niespodzianki"
 - [https://forsal.pl/swiat/usa/artykuly/9421272,wiceszefowa-dyplomacji-usa-wladimira-putina-czekaja-niespodzianki.html](https://forsal.pl/swiat/usa/artykuly/9421272,wiceszefowa-dyplomacji-usa-wladimira-putina-czekaja-niespodzianki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T11:52:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2rxktkuTURBXy82MmU0MWQ1Yy02MWYxLTQ0ZDktOTk0OC00ZmM4MjdiNzllMGEuanBlZ5GTBc0BHcyg" />Wiceszefowa amerykańskiej dyplomacji Victoria Nuland oznajmiła w środę wieczorem w Kijowie, że pierwsza partia precyzyjnie naprowadzanych bomb Ground-Launched Small Diameter Bomb (GLSDB), przekazywanych Ukrainie przez USA, znajduje się już w drodze na front wojny z Rosją.

## Podwyżki opłat w mBanku. Czy wieloletni klienci są gotowi je zaakceptować?
 - [https://forsal.pl/biznes/bankowosc/artykuly/9421001,podwyzki-oplat-w-mbanku-czy-wieloletni-klienci-sa-gotowi-je-zaakcepto.html](https://forsal.pl/biznes/bankowosc/artykuly/9421001,podwyzki-oplat-w-mbanku-czy-wieloletni-klienci-sa-gotowi-je-zaakcepto.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T11:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/62dktkuTURBXy9kZmZkMGFmNS1kOWU2LTQ2YTMtOGIzMy0wZWUzZDIwNTYxYTIuanBlZ5GTBc0BHcyg" />Przed styczniowym Wielkim Finałem WOŚP mBank zachęcał swoich klientów do „klikania w serduszko” i zbierania w ten sposób pieniędzy, które instytucja finansowa zadeklarowała przekazać fundacji dowodzonej przez Jurka Owsiaka. Tuż po tym, jak umilkły ostatnie echa 32 Finału mBank ogłosił, że już wkrótce podwyższy niektóre opłaty i prowizje. Sprawdź, jakie i kiedy zmiany zostaną wprowadzone.

## Ustawa budżetowa. Jest oświadczenie Andrzeja Dudy
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9421059,ustawa-budzetowa-jest-oswiadczenie-andrzeja-dudy.html](https://forsal.pl/finanse/aktualnosci/artykuly/9421059,ustawa-budzetowa-jest-oswiadczenie-andrzeja-dudy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T11:17:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NmWktkuTURBXy9jMDRkYzI4MC03OTU0LTQyYTUtOTRhNC01ZmQ5MzY5MDRiNjIuanBlZ5GTBc0BHcyg" />Ustawa budżetowa niedługo wejdzie w życie; chcę wyrazić satysfakcję, że rząd będzie mógł realizować zobowiązania, które podjął i wpisał do ustawy - powiedział w czwartek prezydent Andrzej Duda. „To, co tu i teraz zostało zabezpieczone. To bardzo dobrze” – dodał.

## Tusk: Orbana dało się "przekonać", Obajtka dało się odwołać; dobry czwartek
 - [https://forsal.pl/gospodarka/polityka/artykuly/9421012,tusk-orbana-dalo-sie-przekonac-obajtka-dalo-sie-odwolac-dobry-czwartek.html](https://forsal.pl/gospodarka/polityka/artykuly/9421012,tusk-orbana-dalo-sie-przekonac-obajtka-dalo-sie-odwolac-dobry-czwartek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T11:08:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ACGktkuTURBXy8wNzU5ZmE3Mi03NjM0LTRhMzMtOTk1NC02ZmMwYWI2OTUzYjEuanBlZ5GTBc0BHcyg" />Dobry czwartek. Viktora Orbana dało się „przekonać”, Daniela Obajtka dało się odwołać. Jedziemy dalej - napisał premier Donald Tusk odnosząc sie do wydarzeń w Brukseli i w kraju.

## Prezes Orlenu: Synergie z fuzji w 2023 r. na poziomie 1,5 mld zł
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9422009,prezes-orlenu-synergie-z-fuzji-w-2023-r-na-poziomie-15-mld-zl.html](https://forsal.pl/biznes/aktualnosci/artykuly/9422009,prezes-orlenu-synergie-z-fuzji-w-2023-r-na-poziomie-15-mld-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T11:07:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4DSktkuTURBXy83OGZhZDFmMS01OThlLTQ0MTMtOTczYi0xZDFlMDlmNmI3NzAuanBlZ5GTBc0BHcyg" />W 2023 roku synergie z przeprowadzonych przez Orlen przejęć i fuzji wyniosły ok. 1,5 mld zł - poinformował w czwartek na konferencji prasowej prezes koncernu Daniel Obajtek.

## Prezydent: Wydam postanowienie o zwołaniu Rady Gabinetowej
 - [https://forsal.pl/gospodarka/polityka/artykuly/9420936,prezydent-wydam-postanowienie-o-zwolaniu-rady-gabinetowej.html](https://forsal.pl/gospodarka/polityka/artykuly/9420936,prezydent-wydam-postanowienie-o-zwolaniu-rady-gabinetowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:56:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yxlktkuTURBXy9iMDQ0MjZhYy1mZjUwLTQ2NTgtODFhNi05YTRhY2ZiZjY1MjEuanBlZ5GTBc0BHcyg" />W czwartek wydam postanowienie o zwołaniu Rady Gabinetowej na 13 lutego na godz. 13 - poinformował prezydent Andrzej Duda. Przekazał, że tematem rozmów będzie realizacja inwestycji takich jak Centralny Port Komunikacyjny, kwestia energetyki jądrowej oraz modernizacja polskiej armii.

## Pakiet wsparcia dla Ukrainy. Szef RE: Mamy porozumienie na szczycie UE
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9420872,pakiet-wsparcia-dla-ukrainy-szef-re-mamy-porozumienie-na-szczycie-ue.html](https://forsal.pl/swiat/unia-europejska/artykuly/9420872,pakiet-wsparcia-dla-ukrainy-szef-re-mamy-porozumienie-na-szczycie-ue.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:46:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Km2ktkuTURBXy85Mjg4NTBjNi0xMzhkLTQ0YzQtYjgwNS1hNDNjYzg4NzA5NzQuanBlZ5GTBc0BHcyg" />Mamy porozumienie na szczycie UE. Wszystkich 27 przywódców zgodziło się na pakiet wsparcia dla Ukrainy w wysokości 50 miliardów euro w ramach budżetu UE - poinformował na platformie X szef Rady Europejskiej Charles Michel w czwartek.

## Akcjonariusze One More Level zdecydują 28 II o buy-backu do 8,85 proc. akcji za max. 0,5 mln zł
 - [https://forsal.pl/finanse/gielda/artykuly/9420846,akcjonariusze-one-more-level-zdecyduja-28-ii-o-buy-backu-do-885-proc.html](https://forsal.pl/finanse/gielda/artykuly/9420846,akcjonariusze-one-more-level-zdecyduja-28-ii-o-buy-backu-do-885-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:41:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />undefined

## Inflacja HICP w strefie euro. Ile wyniosła w styczniu?
 - [https://forsal.pl/gospodarka/inflacja/artykuly/9420826,inflacja-hicp-w-strefie-euro-ile-wyniosla-w-styczniu.html](https://forsal.pl/gospodarka/inflacja/artykuly/9420826,inflacja-hicp-w-strefie-euro-ile-wyniosla-w-styczniu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:38:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GRYktktTURBXy80NDllNDA2My1mMzI5LTQ3MzYtODI5YS0zNTc2YTVlMGEyOWYucG5nkZMFzQEdzKA" />undefined

## Arctic Paper: Rottneros miało 48 mln zł zysku netto, 100 mln zł EBITDA w 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9420809,arctic-paper-rottneros-mialo-48-mln-zl-zysku-netto-100-mln-zl-ebitda.html](https://forsal.pl/finanse/gielda/artykuly/9420809,arctic-paper-rottneros-mialo-48-mln-zl-zysku-netto-100-mln-zl-ebitda.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:36:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oV6ktkuTURBXy9mYzg1ZjYwNi0xY2MyLTRiY2ItOTY4MS0wZWNmYWQyNzI0OTAuanBlZ5GTBc0BHcyg" />undefined

## Mex Polska ma nową umowę z Grupą Żywiec, spodziewa się 17,3 mln zł w ciągu 5 lat
 - [https://forsal.pl/artykuly/9420785,mex-polska-ma-nowa-umowe-z-grupa-zywiec-spodziewa-sie-173-mln-zl-w-c.html](https://forsal.pl/artykuly/9420785,mex-polska-ma-nowa-umowe-z-grupa-zywiec-spodziewa-sie-173-mln-zl-w-c.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:32:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/H_HktkuTURBXy8zNGY0NjIxMi03OWVlLTQ0MDQtODFkZi1hODBlZjhiYjQ0ZDAuanBlZ5GTBc0BHcyg" />undefined

## Oświadczenie prezydenta Andrzeja Dudy. Gdzie można obejrzeć transmisję?
 - [https://forsal.pl/gospodarka/polityka/artykuly/9420559,oswiadczenie-prezydenta-andrzeja-dudy-gdzie-mozna-obejrzec-transmisje.html](https://forsal.pl/gospodarka/polityka/artykuly/9420559,oswiadczenie-prezydenta-andrzeja-dudy-gdzie-mozna-obejrzec-transmisje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:31:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4VpktkuTURBXy8wNWMzNjI4Yi0xNmRhLTRmZDEtYTViNi1kNTk3YjlmM2E1MTIuanBlZ5GTBc0BHcyg" />Andrzej Duda wyda w czwartek o godz. 11.30 oświadczenie – poinformowała Kancelaria Prezydenta RP. Gdzie można obejrzeć transmisję?

## ING BSK chce rekomendować przeznaczenie 75 proc. zysku i 1 mld zł z kapitału rez. na dywidendę
 - [https://forsal.pl/finanse/gielda/artykuly/9420738,ing-bsk-chce-rekomendowac-przeznaczenie-75-proc-zysku-i-1-mld-zl-z-ka.html](https://forsal.pl/finanse/gielda/artykuly/9420738,ing-bsk-chce-rekomendowac-przeznaczenie-75-proc-zysku-i-1-mld-zl-z-ka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:27:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4lbktkuTURBXy84NDZmN2I4Zi01NzI3LTQxOWUtYmIzOC01ZTNhZDRiNzA1YjYuanBlZ5GTBc0BHcyg" />undefined

## Stopa bezrobocia w Polsce i strefie euro. Eurostat podał najnowsze dane
 - [https://forsal.pl/praca/artykuly/9420733,stopa-bezrobocia-w-polsce-i-strefie-euro-eurostat-podal-najnowsze-dane.html](https://forsal.pl/praca/artykuly/9420733,stopa-bezrobocia-w-polsce-i-strefie-euro-eurostat-podal-najnowsze-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:27:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/q3RktkuTURBXy80ODhkNjY3NS1iZDAyLTQxZjEtOWUyYy1kODU2YzQxODhiYzIuanBlZ5GTBc0BHcyg" />undefined

## ING BSK miał wstępnie 1,27 mld zł zysku netto w IV kw. 2023 r. ROE za ub.r. wyniosło 33,9 proc.
 - [https://forsal.pl/finanse/gielda/artykuly/9420706,ing-bsk-mial-wstepnie-127-mld-zl-zysku-netto-w-iv-kw-2023-r-roe-za.html](https://forsal.pl/finanse/gielda/artykuly/9420706,ing-bsk-mial-wstepnie-127-mld-zl-zysku-netto-w-iv-kw-2023-r-roe-za.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:23:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aUiktkuTURBXy83YWZlMGExZC05YjIwLTQ3ZjctYjU5NS1lMzliNGJiNDg4MDAuanBlZ5GTBc0BHcyg" />undefined

## RN Orlenu odwołała Daniela Obajtka z funkcji prezesa zarządu
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9420575,rn-orlenu-odwolala-daniela-obajtka-z-funkcji-prezesa-zarzadu.html](https://forsal.pl/biznes/aktualnosci/artykuly/9420575,rn-orlenu-odwolala-daniela-obajtka-z-funkcji-prezesa-zarzadu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T10:01:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gbGktkuTURBXy9hOTgzY2NhZi0yNGI5LTRjOTktODlkOC05ODI2ZWMxODNjN2MuanBlZ5GTBc0BHcyg" />undefined

## "Polskie przedsiębiorstwa mierzą się ze słabym popytem zagranicznym"
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9420532,polskie-przedsiebiorstwa-mierza-sie-ze-slabym-popytem-zagranicznym.html](https://forsal.pl/biznes/aktualnosci/artykuly/9420532,polskie-przedsiebiorstwa-mierza-sie-ze-slabym-popytem-zagranicznym.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T09:39:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tiRktkuTURBXy8zNzRmYjE2Yy0wZjMxLTQ5NzQtODZjMS1jYmFhNTY3ZmU3ZDQuanBlZ5GTBc0BHcyg" />Polskie firmy notują niską wartość nowych zamówień, mierzą się też ze słabym popytem zagranicznym – ocenił w czwartek analityk Polskiego Instytutu Ekonomicznego Dawid Sułkowski w komentarzu do danych o wskaźniku PMI.

## Koronawirus w Polsce - statystyki z 1.02.2024
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-statystyki-z-1022024.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-statystyki-z-1022024.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T09:38:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 429 zakażeń koronawirusem, w tym 106 ponownych. Z powodu COVID-19 zmarło 8 pacjentów – poinformowano w czwartek na stronach rządowych. Wykonano ponad 3,9 tys. testów w kierunku SARS-CoV-2.

## Tusk: Stanowisko Viktora Orbana jest zagrożeniem dla naszego bezpieczeństwa
 - [https://forsal.pl/gospodarka/polityka/artykuly/9420523,tusk-stanowisko-viktora-orbana-jest-zagrozeniem-dla-naszego-bezpieczenstwa.html](https://forsal.pl/gospodarka/polityka/artykuly/9420523,tusk-stanowisko-viktora-orbana-jest-zagrozeniem-dla-naszego-bezpieczenstwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T09:32:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DBGktkuTURBXy8yODMxM2Y3Yy0xYjE0LTQwODUtYjE2OC04OGZmM2U4OTlkOTYuanBlZ5GTBc0BHcyg" />Dziś potrzebne nam jest poczucie zjednoczenia w sprawie Ukrainy; stanowisko premiera Węgier Viktora Orbana jest zagrożeniem dla naszego bezpieczeństwa - powiedział premier Donald Tusk w Brukseli, przed rozpoczęciem Rady Europejskiej.

## Wskaźnik PMI dla przemysłu strefy euro wzrósł w styczniu
 - [https://forsal.pl/biznes/przemysl/artykuly/9420513,wskaznik-pmi-dla-przemyslu-strefy-euro-wzrosl-w-styczniu.html](https://forsal.pl/biznes/przemysl/artykuly/9420513,wskaznik-pmi-dla-przemyslu-strefy-euro-wzrosl-w-styczniu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T09:23:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1ADktkuTURBXy9hZGM5MmMwNy02MmRlLTQzODktYTU1NC0zYWQzZTIzOWVjNDMuanBlZ5GTBc0BHcyg" />undefined

## Wskaźnik PMI dla przemysłu Niemiec wzrósł w styczniu
 - [https://forsal.pl/biznes/przemysl/artykuly/9420508,wskaznik-pmi-dla-przemyslu-niemiec-wzrosl-w-styczniu.html](https://forsal.pl/biznes/przemysl/artykuly/9420508,wskaznik-pmi-dla-przemyslu-niemiec-wzrosl-w-styczniu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T09:19:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4BbktkuTURBXy81NGEwMjlkOC04NzI0LTQ2ZWQtYjQ5Ni05NDY4MThjODNlMWUuanBlZ5GTBc0BHcyg" />undefined

## Protest rolników przed PE w Brukseli. "To nie jest Europa, której chcemy"
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9420458,protest-rolnikow-przed-pe-w-brukseli-to-nie-jest-europa-ktorej-chcemy.html](https://forsal.pl/swiat/aktualnosci/artykuly/9420458,protest-rolnikow-przed-pe-w-brukseli-to-nie-jest-europa-ktorej-chcemy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T08:48:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MhlktkuTURBXy81NjhiMmNjMi0xNThlLTQwYWMtYWVhZi04MjA2OThhOTBmZWYuanBlZ5GTBc0BHcyg" />W Brukseli przed Parlamentem Europejskim trwa w czwartek rano duży protest rolników. Do miasta wjechało ponad 1000 ciągników belgijskich, które zablokowały Plac Luksemburski przed europarlamentem i drogi dojazdowe. O godz. 10 w pobliskim budynku Rady Europejskiej ma rozpocząć się unijny szczyt.

## MRiT: Mariusz Filipek został pełnomocnikiem ds. deregulacji i dialogu gospodarczego
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9420442,mariusz-filipek-zostal-pelnomocnikiem-ds-deregulacji-i-dialogu-gospodarczego.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9420442,mariusz-filipek-zostal-pelnomocnikiem-ds-deregulacji-i-dialogu-gospodarczego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T08:37:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ML8ktkuTURBXy82MWRhYTIxZi1jNTFkLTQyYWItOWU0MC02ZTU1ZTY2NGIwMGMuanBlZ5GTBc0BHcyg" />undefined

## Wskaźnik PMI dla Polski spadł m: m w styczniu. Oczekiwania ws. produkcji są najsilniejsze od lutego 2022 r.
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9420416,wskaznik-pmi-dla-polski-spadl-m-m-w-styczniu-oczekiwania-ws-produkcji-sa-najsilniejsze-od-lutego-2022-r.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9420416,wskaznik-pmi-dla-polski-spadl-m-m-w-styczniu-oczekiwania-ws-produkcji-sa-najsilniejsze-od-lutego-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T08:25:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MHmktkuTURBXy8xMWVlYTJkOS0xYWMyLTRlYTYtOTBjYy01MTAxZTQ2NDlmZDMuanBlZ5GTBc0BHcyg" />undefined

## Obajtek: Oddałem się do dyspozycji rady nadzorczej Orlenu
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9420369,obajtek-oddalem-sie-do-dyspozycji-rady-nadzorczej-orlenu.html](https://forsal.pl/biznes/aktualnosci/artykuly/9420369,obajtek-oddalem-sie-do-dyspozycji-rady-nadzorczej-orlenu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T08:07:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DizktkuTURBXy8yMWM1NmYyOS01Y2U0LTRmODQtODgzYi0wZDMzYjhiNGQyZmQuanBlZ5GTBc0BHcyg" />Oddałem się do dyspozycji rady nadzorczej - poinformował w czwartek w radiu ZET prezes Orlenu Daniel Obajtek. To jest sprawa honorowa i dziś będą podjęte decyzje - podkreślił. Rada zbierze się 1 lutego br.

## KPRP: Prezydent Andrzej Duda wyda w czwartek oświadczenie
 - [https://forsal.pl/gospodarka/polityka/artykuly/9420359,kprp-prezydent-andrzej-duda-wyda-w-czwartek-oswiadczenie.html](https://forsal.pl/gospodarka/polityka/artykuly/9420359,kprp-prezydent-andrzej-duda-wyda-w-czwartek-oswiadczenie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T08:03:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yAJktkuTURBXy9jZThjMGMyOS1lNjE3LTQyNDYtYjlmNy0wOTMyYWU0MjBlNGIuanBlZ5GTBc0BHcyg" />Prezydent RP Andrzej Duda wyda w czwartek o godz. 11.30 oświadczenie - powiadomiła Kancelaria Prezydenta RP.

## Rosja, katalońscy separatyści i gazociąg. Jak Kreml zablokował alternatywne źródła gazu dla Niemiec?
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9420357,rosja-katalonscy-separatysci-i-gazociag-jak-kreml-zablokowal-alterna.html](https://forsal.pl/swiat/unia-europejska/artykuly/9420357,rosja-katalonscy-separatysci-i-gazociag-jak-kreml-zablokowal-alterna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T08:03:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8qWktkuTURBXy9kMTNlNjBlYi02YTU3LTQ3ODYtOWEwMS1lMjU5MDE1Yzc1YTcuanBlZ5GTBc0BHcyg" />Władze Rosji poprzez środki finansowe kierowane na rzecz separatystów z Katalonii przeszkadzały w budowie planowanego w tym regionie gazociągu MidCat, który miał połączyć Hiszpanię z Francją - wynika ze śledztwa hiszpańskiego wymiaru sprawiedliwości, na które powołuje się w środę dziennik “Vozpopuli”.

## Co dalej planuje Władimir Putin? Próbuje "wykorzystać głosy na Zachodzie"
 - [https://forsal.pl/swiat/rosja/artykuly/9420348,co-dalej-planuje-wladimir-putin-probuje-wykorzystac-glosy-na-zachodzie.html](https://forsal.pl/swiat/rosja/artykuly/9420348,co-dalej-planuje-wladimir-putin-probuje-wykorzystac-glosy-na-zachodzie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T07:53:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-JJktkuTURBXy81ODg3NmJkNC1hZjBkLTQwMjYtOWQ0Ny0xZjNjMDI4ZmE3MjQuanBlZ5GTBc0BHcyg" />Wypowiedzi Władimira Putina o tym, że Rosja dąży do utworzenia na Ukrainie &quot;strefy zdemilitaryzowanej&quot; były powtórzeniem maksymalistycznych i rozmytych celów Rosji w wojnie; Putin próbuje też wykorzystać głosy na Zachodzie o wstrzymaniu pomocy dla Kijowa - ocenia Instytut Studiów nad Wojną (ISW).

## Strajk na niemieckich lotniskach. Które porty lotnicze nie przyjmują dziś pasażerów?
 - [https://forsal.pl/transport/lotnictwo/artykuly/9420340,strajk-na-niemieckich-lotniskach-ktore-porty-lotnicze-nie-przyjmuja-d.html](https://forsal.pl/transport/lotnictwo/artykuly/9420340,strajk-na-niemieckich-lotniskach-ktore-porty-lotnicze-nie-przyjmuja-d.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T07:48:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AauktkuTURBXy81YTc3ZjE3NS1lN2Q3LTQyNDUtOTQyYS1mMTA5NjQyZjc2OGUuanBlZ5GTBc0BHcyg" />Strajk ostrzegawczy pracowników ochrony na jedenastu niemieckich lotniskach rozpoczął się w nocy ze środy na czwartek, krótko przed północą. Z powodu strajku, który potrwa całą dobę, nie odbędzie się prawie tysiąc lotów – poinformowała w środę wieczorem dpa.

## Kowal: 50 mld euro dla Ukrainy na utrzymanie bieżącego funkcjonowania kraju
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9420337,kowal-50-mld-euro-dla-ukrainy-na-utrzymanie-biezacego-funkcjonowania-kraju.html](https://forsal.pl/finanse/aktualnosci/artykuly/9420337,kowal-50-mld-euro-dla-ukrainy-na-utrzymanie-biezacego-funkcjonowania-kraju.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T07:43:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gH1ktkuTURBXy8yZTlhYzExMS0wNDU2LTQ0YmEtOTdjOS01YmQ2M2NhZDVkM2MuanBlZ5GTBc0BHcyg" />Pełnomocnik Rady Ministrów ds. odbudowy Ukrainy Paweł Kowal zapowiedział, że 50 miliardów euro pomocy dla Ukrainy, o przeznaczeniu których prawdopodobnie zapadnie decyzja w Brukseli, w dużym stopniu będą przeznaczone na utrzymanie bieżącego funkcjonowania kraju.

## USA zapowiedziały odwet za śmierć swoich żołnierzy w Jordanii. Kampania uderzy w bojówki wpierane przez Iran
 - [https://forsal.pl/swiat/usa/artykuly/9420329,usa-zapowiedzialy-odwet-za-smierc-swoich-zolnierzy-w-jordanii-kampani.html](https://forsal.pl/swiat/usa/artykuly/9420329,usa-zapowiedzialy-odwet-za-smierc-swoich-zolnierzy-w-jordanii-kampani.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T07:37:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2wqktkuTURBXy8zZmY4OWY3Yy01NWIwLTQxYWUtODdjMS0wNGRkMDJkNjU1YjUuanBlZ5GTBc0BHcyg" />Odpowiedzią USA na zabójczy atak na żołnierzy USA w Jordanii będzie kilkutygodniową kampanią i będzie polegać zarówno na atakach militarnych, jak i cybernetycznych - podała w środę telewizja NBC News. Doniesienia zdaje się potwierdzać Biały Dom, który zapowiedział, że pierwsze uderzenie nie będzie ostatnim.

## Kosiniak-Kamysz o decyzji prezydenta ws budżetu: Niepodpisanie tego byłoby nierozsądne
 - [https://forsal.pl/gospodarka/polityka/artykuly/9420324,kosiniak-kamysz-o-decyzji-prezydenta-ws-budzetu-niepodpisanie-tego-byloby-nierozsadne.html](https://forsal.pl/gospodarka/polityka/artykuly/9420324,kosiniak-kamysz-o-decyzji-prezydenta-ws-budzetu-niepodpisanie-tego-byloby-nierozsadne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T07:32:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/h_bktkuTURBXy9mYjc0NTA3Ni1iOTcwLTRkZjEtOWEzNS0xN2M5YTdkMzc5ODAuanBlZ5GTBc0BHcyg" />Nie miałem wątpliwości, że na koniec drogi musi być akceptacja budżetu, niepodpisanie budżetu byłoby nierozsądne - powiedział wicepremier, szef MON Władysław Kosiniak-Kamysz, pytany o decyzję prezydenta Andrzeja Dudy ws. ustawy budżetowej.

## Fed nie obniży stóp w marcu. Wall Street zareagowała spadkami
 - [https://forsal.pl/finanse/gielda/artykuly/9420316,fed-nie-obnizy-stop-w-marcu-wall-street-zareagowala-spadkami.html](https://forsal.pl/finanse/gielda/artykuly/9420316,fed-nie-obnizy-stop-w-marcu-wall-street-zareagowala-spadkami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T07:23:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7rxktkuTURBXy81NmEwMjM5Yy1mMTVjLTQ3MTUtOTdjMy01Yjk3OGE3YTc3NmIuanBlZ5GTBc0BHcyg" />Środowa sesja na Wall Street zakończyła się mocnymi spadkami głównych indeksów. Inwestorzy negatywnie zareagowali na słowa prezesa Fed Jerome'a Powella, że Rezerwa Federalna nie obniży stóp proc. w marcu, co zakładała do tej pory większość analityków.

## Dlaczego zmniejsza się liczba urodzeń w Polsce? Ekspert: Dla pokolenia Z dzieci nie są wyznacznikiem sukcesu
 - [https://forsal.pl/gospodarka/demografia/artykuly/9420236,dlaczego-zmniejsza-sie-liczba-urodzen-w-polsce-ekspert-dla-pokolenia-z-dzieci-nie-sa-wyznacznikiem-sukcesu.html](https://forsal.pl/gospodarka/demografia/artykuly/9420236,dlaczego-zmniejsza-sie-liczba-urodzen-w-polsce-ekspert-dla-pokolenia-z-dzieci-nie-sa-wyznacznikiem-sukcesu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T06:24:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BpHktkuTURBXy8xYjAxMWQyMC1jOTgyLTQ0M2MtOTI3My1jZTIxZmZhMzc2YmIuanBlZ5GTBc0BHcyg" />Na naszych oczach dochodzą do dorosłości tzw. Zetki. Pokolenie, dla którego posiadanie życiowego partnera, dziecka, nie jest już wyznacznikiem dorosłości, sukcesu życiowego – powiedział w rozmowie z PAP prof. Piotr Szukalski z Uniwersytetu Łódzkiego, tłumacząc zmniejszającą się liczbę urodzeń.

## Starbucks: bojkoty i słabnąca gospodarka dają się we znaki
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9419413,starbucks-bojkoty-i-slabnaca-gospodarka-daja-sie-we-znaki.html](https://forsal.pl/biznes/aktualnosci/artykuly/9419413,starbucks-bojkoty-i-slabnaca-gospodarka-daja-sie-we-znaki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T05:40:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/b6OktkuTURBXy82MWIzNmEzMy0xMDhjLTQzMzQtOGIwNy1hMWZmY2FjYTA1ZWMuanBlZ5GTBc0BHcyg" />Starbucks, największa na świecie sieć kawiarni, obniżyła swoje roczne prognozy sprzedaży i nie spełniła oczekiwań rynkowych. Firma została dotknięta strajkami personelu i spadkiem liczby okazjonalnych odwiedzających w USA.

## Sztuczna inteligencja goni ludzką kreatywność
 - [https://forsal.pl/lifestyle/technologie/artykuly/9412850,sztuczna-inteligencja-goni-ludzka-kreatywnosc.html](https://forsal.pl/lifestyle/technologie/artykuly/9412850,sztuczna-inteligencja-goni-ludzka-kreatywnosc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T05:39:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MKYktktTURBXy83ZGU3NmViNy1hNmUzLTQ1MGUtYWViMi03Nzk3YTIzMDJhMjEucG5nkZMFzQEdzKA" />Już niedługo sztuczna inteligencja może dorównać ludzkiej kreatywności. Takie wnioski płyną z najnowszych badań przeprowadzonych przez Uniwersytet Montany.

## Gdzie wystrzeliła sprzedaż nowych mieszkań? Oto lista miast
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9418910,gdzie-wystrzelila-sprzedaz-nowych-mieszkan-oto-lista-miast.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9418910,gdzie-wystrzelila-sprzedaz-nowych-mieszkan-oto-lista-miast.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T05:38:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vftktkuTURBXy9iYjBhOGQwMy0yYWVkLTRkYzktYTgwOS0zMmRhZTA0NGY0MzMuanBlZ5GTBc0BHcyg" />W 2023 r. w największych miastach wystrzeliła sprzedaż nowych mieszkań. Eksperci portalu RynekPierwotny.pl zbadali, jakie kupowane były najchętniej i czy w ubiegłym roku zmieniły się preferencje nabywców.

## A może zrównoważony system żywnościowy? Ludzkość powinna przestać jeść na kredyt
 - [https://forsal.pl/biznes/ekologia/artykuly/9414357,a-moze-zrownowazony-system-zywnosciowy-ludzkosc-powinna-przestac-jesc.html](https://forsal.pl/biznes/ekologia/artykuly/9414357,a-moze-zrownowazony-system-zywnosciowy-ludzkosc-powinna-przestac-jesc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T05:34:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9mMktkuTURBXy8wM2NlY2VkYi1lZGYzLTQzYTItYTU3Yi1lNzgyYWIzOTJjNmUuanBlZ5GTBc0BHcyg" />Obecna produkcja jedzenia niszczy więcej wartości, niż tworzy, z powodu kosztów medycznych i środowiskowych, twierdzą badacze. Ich zdaniem, przejście na zrównoważone systemy żywnościowe mogłoby przynieść korzyści w wysokości 10 bilionów dolarów rocznie.

## Firmy technologiczne zwalniają na potęgę. Powód? Inwestorzy to lubią
 - [https://forsal.pl/lifestyle/technologie/artykuly/9418711,firmy-technologiczne-zwalniaja-na-potege-powod-inwestorzy-to-lubia.html](https://forsal.pl/lifestyle/technologie/artykuly/9418711,firmy-technologiczne-zwalniaja-na-potege-powod-inwestorzy-to-lubia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T05:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Nu8ktkuTURBXy9jZDIxNTY1Ny0yOGJkLTQ0ZmYtYTNkYS1lNWUyNzMzNjNlYTQuanBlZ5GTBc0BHcyg" />W pierwszych tygodniach tego roku pracę w firmach technologicznych straciło prawie 25 tys. osób. Zdaniem ekspertów to nie koniec cięć. Jakie są ich powody?

## GUS opublikował dane demograficzne za 2023 rok. Nie jest źle. Jest tragicznie
 - [https://forsal.pl/gospodarka/demografia/artykuly/9419396,gus-opublikowal-dane-demograficzne-za-2023-rok-nie-jest-zle-jest-tra.html](https://forsal.pl/gospodarka/demografia/artykuly/9419396,gus-opublikowal-dane-demograficzne-za-2023-rok-nie-jest-zle-jest-tra.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T05:05:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/POvktktTURBXy8zOWEzNjcyZi00ZDRjLTRlYzMtYTg0NC0yZWNjMmMxZGI0YzYucG5nkZMFzQEdzKA" />Główny Urząd Statystyczny pochwalił się najnowszymi szacunkami dotyczącymi demografii Polski. Dane nie napawają optymizmem. W 2023 roku urodziło się nas o 11 proc. mniej, a przyrost naturalny wyniósł -137 tys. To tak, jakby w ciągu roku zniknęła cała populacja Rybnika czy Zielonej Góry. Co dzieje się z naszym społeczeństwem?

## Duże zmiany w prawie jazdy. Taki plan ma Unia Europejska
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9416524,duze-zmiany-w-prawie-jazdy-taki-plan-ma-unia-europejska.html](https://forsal.pl/swiat/unia-europejska/artykuly/9416524,duze-zmiany-w-prawie-jazdy-taki-plan-ma-unia-europejska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T05:01:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/iVWktkuTURBXy82NzkyZDUzMi05NTMzLTRmZTYtYTM0Ny0zMTI5YmZlODA1ZWMuanBlZ5GTBc0BHcyg" />W obliczu rosnących wyzwań związanych z bezpieczeństwem drogowym, Unia Europejska dokonuje istotnych zmian w przepisach dotyczących prawa jazdy. Po intensywnych debatach i odrzuceniu pierwotnej propozycji skierowanej wyłącznie do seniorów, UE kieruje się ku nowemu podejściu, które zakłada wprowadzenie obowiązkowych badań lekarskich dla wszystkich kierowców, niezależnie od wieku.

## Kadrowe zmiany (na lepsze) w państwowych spółkach [OPINIA]
 - [https://forsal.pl/gospodarka/polityka/artykuly/9420100,daniel-obajtek-prezes-orlen-do-kiedy-scenariusze.html](https://forsal.pl/gospodarka/polityka/artykuly/9420100,daniel-obajtek-prezes-orlen-do-kiedy-scenariusze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ACQktkuTURBXy83NjllZmY3My0zYjZkLTQxNDctYWIzNC0zNjU4ZWYzYTI4MmEuanBlZ5GTBc0BHcyg" />Personalna rewolucja w największych, notowanych na warszawskiej giełdzie, spółkach kontrolowanych przez państwo – polegająca na odwołaniu ludzi nominowanych przez rząd Zjednoczonej Prawicy i powołanie osób, do których zaufanie ma koalicja „15 października” – zaczęła się od energetyki.

## „Panie Zuckerberg, ma pan krew na rękach”. Przywódcy big techów przesłuchiwani przez Senat USA
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9420187,panie-zuckerberg-ma-pan-krew-na-rekach-przywodcy-big-techow-przesl.html](https://forsal.pl/biznes/aktualnosci/artykuly/9420187,panie-zuckerberg-ma-pan-krew-na-rekach-przywodcy-big-techow-przesl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2024-02-01T05:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Z7uktkuTURBXy80M2YyMWYwYS0xNzVlLTQxM2QtOTcxZS1jMThmMDhhYjI2MjQuanBlZ5GTBc0BHcyg" />„Zostałam wykorzystana seksualnie na Facebooku” – dziecko, które wypowiada te słowa w filmie, ma twarz schowaną w cieniu. Materiał składa się z samych tego typu wyznań. W sali przesłuchań siedzą rodzice, trzymają w rękach zdjęcia swoich dzieci, które doznały krzywdy w internecie. Oprócz nich w pomieszczeniu jest także Mark Zuckerberg i inni liderzy big techów. W pewnym momencie senator Josh Hawley wzywa założyciela Facebooka, żeby osobiście przeprosił bliskich ofiar. Zuckeberg odwraca się do nich i wyraża ubolewanie.

