# Source:Developer Tech News, URL:https://www.developer-tech.com/feed/, language:en-GB

## Unity launches XR app building tools for Apple’s Vision Pro
 - [https://www.developer-tech.com/news/2024/feb/01/unity-launches-xr-app-building-tools-apple-vision-pro](https://www.developer-tech.com/news/2024/feb/01/unity-launches-xr-app-building-tools-apple-vision-pro)
 - RSS feed: https://www.developer-tech.com/feed/
 - date published: 2024-02-01T13:36:03+00:00

<p>Unity has officially launched tools for visionOS, Apple&#8217;s new operating system for its Vision Pro spatial computing headset. The support will allow developers to use Unity&#8217;s development tools and workflow to build immersive experiences for the Vision Pro. The announcement comes ahead of the Vision Pro headset&#8217;s launch on 2 February 2024. Unity&#8217;s templates, samples<a class="excerpt-read-more" href="https://www.developer-tech.com/news/2024/feb/01/unity-launches-xr-app-building-tools-apple-vision-pro/" title="ReadUnity launches XR app building tools for Apple&#8217;s Vision Pro">... Read more &#187;</a></p>
<p>The post <a href="https://www.developer-tech.com/news/2024/feb/01/unity-launches-xr-app-building-tools-apple-vision-pro/">Unity launches XR app building tools for Apple&#8217;s Vision Pro</a> appeared first on <a href="https://www.developer-tech.com">Developer Tech News</a>.</p>

