# Source:GameSpot, URL:https://www.gamespot.com/feeds/mashup, language:en-US

## Don't Sell Your Unused Diablo 4 Uber Uniques, Blizzard Promises They'll Be Useful Soon
 - [https://www.gamespot.com/articles/dont-sell-your-unused-diablo-4-uber-uniques-blizzard-promises-theyll-be-useful-soon/1100-6520798/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/dont-sell-your-unused-diablo-4-uber-uniques-blizzard-promises-theyll-be-useful-soon/1100-6520798/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T21:05:00+00:00

<p>Having a stash full of duplicate Uber Uniques in <a href="https://www.gamespot.com/games/diablo-iv/">Diablo 4</a> might actually be useful soon, as developer Blizzard is advising players to hold onto the unwanted items, citing "upcoming plans" that will be shared in the near future.</p><p dir="ltr">Uber Uniques are Diablo 4's rarest and most powerful items, but obtaining two of the same one, or one that isn't useful for your desired build, can feel a bit like winning the lottery, only to accidentally throw your winning ticket down the drain. <a href="https://www.gamespot.com/articles/diablo-4-ultra-rare-unique-items-are-so-rare-blizzard-had-to-confirm-they-actually-exist/1100-6515491/">Uber Uniques used to be extremely rare</a>, but have become a bit more obtainable nowadays thanks to Blizzard introducing farmable bosses, like Duriel, that have a small chance to drop specific Uber Uniques.</p><p dir="ltr">It's now much more common for players to have duplicate Uber Uniques

## PlayStation And Switch Ports Of An Xbox Exclusive May Have Leaked In A Bizarre Way
 - [https://www.gamespot.com/articles/playstation-and-switch-ports-of-an-xbox-exclusive-may-have-leaked-in-a-bizarre-way/1100-6520799/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/playstation-and-switch-ports-of-an-xbox-exclusive-may-have-leaked-in-a-bizarre-way/1100-6520799/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T21:04:00+00:00

<p>PlayStation and Nintendo Switch ports of Hi-Fi Rush may have been leaked through t-shirts datamined from the game's Anniversary Update.</p><p>A Reddit user named RamenMan22 <a href="https://www.reddit.com/r/HiFiRush/comments/1ag8xz7/yeaaaaaahhhh_this_just_confirms_that_were_getting/">posted</a> what looks to be t-shirt textures in Hi-Fi Rush's game files. In particular, there's a blue shirt that says, "I'm Here Baby," and a red shirt that says, "Rock Out Anywhere!" The phrases and designs indicate that Hi-Fi Rush could be coming to PlayStation and Nintendo Switch, respectively. The former phrase references the absurdity that a Microsoft exclusive would end up on PlayStation. The latter phrase references the Switch's portable nature.</p><div><blockquote align="center" class="twitter-tweet"><p dir="ltr">Hi-Fi Rush Anniversary Update t-shirt texture (platform exclusive designs) datamine seem to suggest that PlayStation/Switch port is happening <br />I'm Here Baby - PlayStatio

## Diablo 4 Season 3's Construct Companion Just Got Some Major Buffs
 - [https://www.gamespot.com/articles/diablo-4-season-3-construct-companion-just-got-some-major-buffs/1100-6520797/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/diablo-4-season-3-construct-companion-just-got-some-major-buffs/1100-6520797/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T20:09:00+00:00

<p><a href="https://www.gamespot.com/games/diablo-iv/">Diablo 4's</a> latest update is now live, and it takes aim at one of the main complaints players have with Season 3 so far--the Seneschal Construct and its perceived lack of power.</p><p dir="ltr"><a href="https://www.gamespot.com/articles/diablo-4-season-of-the-construct-will-let-players-customize-their-own-death-robot/1100-6520322/">Season 3 launched on January 23</a>, introducing a <a href="https://www.gamespot.com/articles/how-diablo-4-season-3s-new-trap-filled-vaults-encourage-players-to-take-their-time/1100-6520378/">new endgame activity, Vaults</a>, and a robotic companion players can customize with various abilities and modifiers. However, the <a href="https://www.gamespot.com/articles/diablo-4-season-3s-new-vaults-and-companion-are-leaving-many-players-underwhelmed/1100-6520584/">Seneschal Construct didn't make a strong first impression</a>, with players of Blizzard's ARPG being quick to complain the companion di

## Paramount+ Super Bowl Commercial Sees Patrick Stewart Throw Hey Arnold's Head, Creed Perform For Some Reason
 - [https://www.gamespot.com/articles/paramount-super-bowl-commercial-sees-patrick-stewart-throw-hey-arnolds-head-creed-perform-for-some-reason/1100-6520794/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/paramount-super-bowl-commercial-sees-patrick-stewart-throw-hey-arnolds-head-creed-perform-for-some-reason/1100-6520794/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T19:58:00+00:00

<p>This year's Super Bowl is on CBS, and the network is going all-out to promote its own Paramount+ streaming service during the big game with some outlandish advertisements.</p><p>In this newest "Paramount Mountain" TV spot, we see a bunch of familiar Paramount and Paramount-adjacent faces--including Sir Patrick Stewart, Arnold from Hey Arnold, Master Chief, Knuckles, Drew Barrymore, and Jeff Probst--doing whatever they can to sell you a Paramount+ subscription.</p><p>It's really an advertisement best seen without knowing too much, but know that Creed and their banger "Higher" make an appearance in a very delightful way. Take a look:</p><a href="https://www.gamespot.com/articles/paramount-super-bowl-commercial-sees-patrick-stewart-throw-hey-arnolds-head-creed-perform-for-some-reason/1100-6520794/?ftag=CAD-01-10abi2f/">Continue Reading at GameSpot</a>

## Game Of Thrones Creators Reveal Their Next Show, And It's Totally Different
 - [https://www.gamespot.com/articles/game-of-thrones-creators-reveal-their-next-show-and-its-totally-different/1100-6520792/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/game-of-thrones-creators-reveal-their-next-show-and-its-totally-different/1100-6520792/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T19:52:00+00:00

<p>Game of Thrones TV show creators D.B. Weiss and David Benioff have <a href="https://www.netflix.com/tudum/articles/death-by-lightning-tv-series-adaptation">revealed their next project with Netflix</a> as part of their <a href="https://www.gamespot.com/articles/game-of-thrones-creators-discuss-their-failed-star-wars-movie-and-what-went-wrong/1100-6520231/">$200 million deal</a> with the streaming giant.</p><p>The new show is called Death by Lightning, and it's an adaptation of Candice Millard's 2011 novel, Destiny of the Republic. The show is a drama about the 20th president of the United States, James Garfield, and the man who murdered him, Charles Guiteau.</p><p>Make Makowsky (Bad Education) is the creator of Death by Lightning, and the show will be directed by Matt Ross (28 Hotel Rooms). Weiss and Benioff are executive producers, along with another Game of Thrones veteran, Bernie Caulfield.</p><a href="https://www.gamespot.com/articles/game-of-thrones-creators-reveal-the

## COD's Newest BlackCell DLC Transforms Your Solider From Human To Zombie To Skeleton In Real Time Each Match
 - [https://www.gamespot.com/articles/cods-newest-blackcell-dlc-transforms-your-solider-from-human-to-zombie-to-skeleton-in-real-time-each-match/1100-6520795/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/cods-newest-blackcell-dlc-transforms-your-solider-from-human-to-zombie-to-skeleton-in-real-time-each-match/1100-6520795/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T19:42:00+00:00

<p><a href="https://www.gamespot.com/articles/cod-warzone-and-mw3-season-2-puts-rick-grimes-in-the-battle-pass-plus-new-mp-maps-and-modes/1100-6520790/">Call of Duty's big Season 2 update</a> arrives February 7 for Modern Warfare III and Warzone, and one of the most notable additions is the next BlackCell DLC bundle.</p><p>This newest BlackCell offering includes operator skins with an eerie gold and glowing purple hue. They don't just look snazzy, though, as some of the skins have "reactive decay." This means your soldier will morph from human to zombie and eventually to a skeleton as you rack up kills.</p><p>BlackCell DLC bundles normally go for around $30, so that's likely to be the price point for this one as well. In addition to the skins, players who buy the new BlackCell DLC get instant access to the BlackCell sector of the new battle pass map.</p><a href="https://www.gamespot.com/articles/cods-newest-blackcell-dlc-transforms-your-solider-from-human-to-zombie-to-skeleto

## 3 PC Games For $10 - Pick From Cool Metroidvanias, Roguelikes, And More
 - [https://www.gamespot.com/articles/3-pc-games-for-10-pick-from-cool-metroidvanias-roguelikes-and-more/1100-6520796/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/3-pc-games-for-10-pick-from-cool-metroidvanias-roguelikes-and-more/1100-6520796/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T19:34:00+00:00

<p dir="ltr">Fanatical's February 2024 edition of its <a href="https://www.tkqlhce.com/click-100770772-13797872?sid=subid_value&amp;url=https://www.fanatical.com/en/pick-and-mix/platinum-collection-build-your-own-bundle">monthly Platinum Collection bundle</a> is now live. The deal lets you select up to seven PC games from a list of 22 to create your own custom bundle in three price options, starting at $10 for three games. If you want more, you can up the price to $15 for five games, or $20 for seven.</p><div><div class="norewrite" title="">           <a href="https://www.tkqlhce.com/click-100770772-13797872?sid=subid_value&amp;url=https://www.fanatical.com/en/pick-and-mix/platinum-collection-build-your-own-bundle">Build your bundle at Fanatical</a> </div></div><p dir="ltr">This month's Platinum Collection selections feature several indie metroidvanias, including the bonkers cyberpunk brawler <a href="https://www.fanatical.com/en/game/cookie-cutter">Cookie Cutter</a> and the 

## Beetlejuice 2 Gets Official Title, Post-Labor Day Release Date
 - [https://www.gamespot.com/articles/beetlejuice-2-gets-official-title-post-labor-day-release-date/1100-6520793/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/beetlejuice-2-gets-official-title-post-labor-day-release-date/1100-6520793/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T19:17:00+00:00

<p>Warner Bros. has, at last, unveiled the name and release date for the highly anticipated sequel to Beetlejuice. The aptly named Beetlejuice Beetlejuice is set to hit theaters on September 6, confirming earlier speculations regarding its release month.</p><p dir="ltr">The official announcement was made through both the movie and studio's official social media channels, accompanied by a new poster you can check out below. The sequel brings back the original cast, including Michael Keaton, Winona Ryder, and Catherine O'Hara, while also introducing new additions to the ensemble including Jenna Ortega, Willem Dafoe, Monica Bellucci, and Justin Theroux.</p><div><blockquote align="center" class="twitter-tweet"><p dir="ltr">Dare you to say it again. <a href="https://twitter.com/hashtag/Beetlejuice?src=hash&amp;ref_src=twsrc^tfw">#Beetlejuice</a> <a href="https://twitter.com/hashtag/Beetlejuice?src=hash&amp;ref_src=twsrc^tfw">#Beetlejuice</a> - Only in theaters September 6. <a href

## Nintendo Pirate Gary Bowser Claims His Case Serves As "A Message" To Other Pirates
 - [https://www.gamespot.com/articles/nintendo-pirate-gary-bowser-claims-his-case-serves-as-a-message-to-other-pirates/1100-6520791/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/nintendo-pirate-gary-bowser-claims-his-case-serves-as-a-message-to-other-pirates/1100-6520791/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T18:57:00+00:00

<p>For the first time since his release from prison, Nintendo pirate Gary Bowser has gone into detail about his experience and his ongoing struggles to pay fines to the company.</p><p>In an interview with <a href="https://www.theguardian.com/games/2024/feb/01/the-man-who-owes-nintendo-14m-gary-bowser-and-gamings-most-infamous-piracy-case">The Guardian</a>, Bowser spoke to his life before, during, and after prison. Bowser first got involved with piracy in the late 2000s, when he began to work with Team Xecuter on bypassing anti-piracy measures. He was something of a "middleman" between the programmers breaking code and the testers who would troubleshoot devices.</p><p>He was arrested in September 2020, while living in the Dominican Republic. Bowser said, "The day that it happened, I was sleeping in my bed, it was four in the morning, I’d been drinking all night, and suddenly I wake up and see three people surrounding my bed with rifles aimed at my head … they dragged me out of

## CoD: Warzone And MW3 Season 2 Puts Rick Grimes In The Battle Pass, Plus New MP Maps And Modes
 - [https://www.gamespot.com/articles/cod-warzone-and-mw3-season-2-puts-rick-grimes-in-the-battle-pass-plus-new-mp-maps-and-modes/1100-6520790/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/cod-warzone-and-mw3-season-2-puts-rick-grimes-in-the-battle-pass-plus-new-mp-maps-and-modes/1100-6520790/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T18:55:00+00:00

<p dir="ltr">Season 2 of <a href="https://www.gamespot.com/games/call-of-duty-modern-warfare-iii/">Call of Duty: Modern Warfare 3</a> and <a href="https://www.gamespot.com/games/call-of-duty-warzone/">Warzone</a> arrives on February 7. Activision's <a href="https://www.callofduty.com/blog/2024/02/call-of-duty-modern-warfare-iii-warzone-season-2-announcement">latest blog</a> has revealed the content arriving with the big update, including a new battle pass, more weapons, and a crossover with The Walking Dead. Here are all the major announcements for Season 2.</p><p dir="ltr">This new season is themed around zombies and The Walking Dead. Later in the season, players can participate in the The Walking Dead: Fear the Living event to earn new cosmetic rewards. The event will run from February 28 to March 6.</p><p dir="ltr">Players who purchase the premium pass can instantly unlock the Rick Grimes operator skin, and Michonne arrives later in the season as a store bundle. Additional

## How To Fast-Travel In Suicide Squad: Kill The Justice League
 - [https://www.gamespot.com/articles/how-to-fast-travel-in-suicide-squad-kill-the-justice-league/1100-6520789/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/how-to-fast-travel-in-suicide-squad-kill-the-justice-league/1100-6520789/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T18:15:00+00:00

<p>In <a href="https://www.gamespot.com/games/suicide-squad-kill-the-justice-league/">Suicide Squad: Kill The Justice League</a>, fast travel is possible, but it's not immediately obvious how to do it. That's because it's also not immediately available, and even once it <em>is</em> available, it still has some limitations. So it's much less straightforward than your average open-world game. Here's how to fast-travel in Suicide Squad so you can kill the Justice League with record speed.</p><h2>Suicide Squad fast travel explained</h2><p>Fast travel isn't available in the story until midway through the game's third chapter, as shown in the Squad menu when paused. During this chapter, you'll be interacting with The Flash for several missions, though I won't say more so as not to spoil anything. After a particular mission in which you meet a new ally, you'll be shown a prompt that fast travel, called Rapid Transit, is available.</p><p>However, as the image below illustrates, you c

## Amid Reports Of An Office Spinoff, Bryan Cranston Pitches A Movie
 - [https://www.gamespot.com/articles/amid-reports-of-an-office-spinoff-bryan-cranston-pitches-a-movie/1100-6520788/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/amid-reports-of-an-office-spinoff-bryan-cranston-pitches-a-movie/1100-6520788/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T18:01:00+00:00

<p>There are rumors and reports regarding a revival of The Office, but that's not the only idea floating around out there. Bryan Cranston, who directed the Season 9 episode "Work Bus," said on the <a href="https://officeladies.com/episodes/2024/31/01/episode-194-interview-with-bryan-cranston">Office Ladies podcast</a> recently that he wants to see an Office movie.</p><p>A potential film could pick up after the events of The Office and reveal what happened to the show's characters after the series ended, he said.</p><p>"Let's say that there's not a reboot series, but what if there was a movie?" Cranston said (<a href="https://www.hollywoodreporter.com/tv/tv-news/bryan-cranston-the-office-the-movie-1235812463/">via The Hollywood Reporter</a>). "Something to where we can see where these people are. These people in the entire cast that we're curious about. We wondered at the end, where did they go? What did become of them?"</p><a href="https://www.gamespot.com/articles/amid-repor

## Silent Hill: The Short Message Full Playthrough Gameplay
 - [https://www.gamespot.com/videos/silent-hill-the-short-message-full-playthrough-gameplay/2300-6463328](https://www.gamespot.com/videos/silent-hill-the-short-message-full-playthrough-gameplay/2300-6463328)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T17:50:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4253985-maxresdefault.jpg" width="480" /> Watch a full playthrough of Silent Hill: The Short Message.

## Skull And Bones Open Beta Pre-Load And Start Times Announced
 - [https://www.gamespot.com/articles/skull-and-bones-open-beta-pre-load-and-start-times-announced/1100-6520785/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/skull-and-bones-open-beta-pre-load-and-start-times-announced/1100-6520785/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T17:39:00+00:00

<p>Ubisoft's swashbuckling pirate game Skull and Bones launches on February 16, but you won't have to wait that long to check it out. An open beta for the pirate game will run February 8-11, and now the exact launch times and pre-loading information have been announced.</p><p>Skull and Bones has been in development for numerous years and has undergone a number of changes, so it's nice that fans will be able to try the game before buying it. For those who decide to buy Skull and Bones after the open beta, players might be happy to learn that <a href="https://www.gamespot.com/articles/skull-and-bones-open-beta-progress-will-carry-forward-to-release-year-1-roadmap-detailed/1100-6520616/">all progress will carry forward.</a></p><p>Pre-loading for the Skull and Bones beta begins February 6 at 1 AM PT / 4 AM ET in North America, ahead of the beta product going live on February 7 at 6 PM PT / 9 PM ET. You can see the full beta pre-load and start time information in the graph below.<

## Star Wars Fans Can Preorder A Miniature Han Solo From Hot Toys Soon
 - [https://www.gamespot.com/articles/star-wars-fans-can-preorder-a-miniature-han-solo-from-hot-toys-soon/1100-6520782/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/star-wars-fans-can-preorder-a-miniature-han-solo-from-hot-toys-soon/1100-6520782/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T17:39:00+00:00

<p>Everyone's favorite Star Wars rogue is getting a new Hot Toys figure, straight out of his appearance in Return of the Jedi. This version of the smuggler-turned-Rebel Alliance hero comes with a camouflage coat, his trademark blaster, an Endor-themed environmental figure base, and several sets of hands. Pricing and a release window haven't been revealed yet, but we'll update this post once preorders are live.</p><figure style="width: 1666px;"><a href="https://www.gamespot.com/a/uploads/original/1601/16018044/4253948-htsolo%281%29.jpg"><img alt="No Caption Provided" src="https://www.gamespot.com/a/uploads/scale_super/1601/16018044/4253948-htsolo%281%29.jpg" /></a></figure><figure><div class="image-gallery__label">Gallery</div>   <div class="image-gallery__list hide-scrollbar">       <a href="https://www.gamespot.com/a/uploads/original/1601/16018044/4253949-htsolo%282%29.jpg">       <img alt="Gallery image 1" src="https://www.gamespot.com/a/uploads/square_medium/1601/16018044/

## CoD: Warzone's Fortune's Keep Map Returns For Ranked BR And Zombies Mode
 - [https://www.gamespot.com/articles/cod-warzones-fortunes-keep-map-returns-for-ranked-br-and-zombies-mode/1100-6520787/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/cod-warzones-fortunes-keep-map-returns-for-ranked-br-and-zombies-mode/1100-6520787/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T17:07:00+00:00

<p dir="ltr"><a href="https://www.gamespot.com/games/call-of-duty-warzone/">Call of Duty: Warzone</a>'s popular Fortune's Keep map returns in Season 2, and now a new map trailer reveals it's arriving with a Ranked Play Resurgence playlist for battle royale and serves as a new location for Modern Warfare 3's Zombies mode.</p><p dir="ltr">As seen in the trailer below, the island map returns with many similar points of interest, such as winery, castle, and more. Activision's trailer announcement says the map has "refreshed POIs," and some structural damage can be seen for the winery and other buildings. It's possible the damage is due to something related to Modern Warfare 3's Zombies storyline, as the trailer also shows cyst-like spores and Zombies gameplay featuring <a href="https://www.gamespot.com/articles/call-of-dutys-crossover-with-the-walking-dead-confirmed-for-season-2/1100-6520706/">Rick and Michonne from The Walking Dead</a>.</p><div>          </div><p dir="ltr"> </p>

## PUBG Publisher Krafton Sued For Alleged Wrongful Termination After Sexual Assualt
 - [https://www.gamespot.com/articles/pubg-publisher-krafton-sued-for-alleged-wrongful-termination-after-sexual-assualt/1100-6520786/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/pubg-publisher-krafton-sued-for-alleged-wrongful-termination-after-sexual-assualt/1100-6520786/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T16:57:00+00:00

<p>A former Krafton employee has sued the PUBG Battlegrounds publisher for wrongful termination, after the employee suffered a sexual assault, allegedly committed by former Krafton head of strategy and business Kevin Kimball.</p><p>According to a report from <a href="https://www.polygon.com/24051558/pubg-krafton-striking-distance-sexual-assault-termination-lawsuit">Polygon</a>, the <a href="https://www.scribd.com/document/701609630/Krafton-lawsuit-via-Polygon?irpid=10078&amp;utm_source=impact&amp;utm_medium=cpc&amp;utm_campaign=Scribd_affiliate_pdm_acquisition_Skimbit Ltd.&amp;sharedid=polygon.com&amp;irgwc=1">lawsuit</a> was filed in December 2023 with the Los Angeles Superior Court. During an alcohol-fueled party for Krafton subsidiary Striking Distance, Kimball allegedly subjected the plaintiff, a 31-year-old woman, to sexual abuse, harassment, and assault. The lawsuit also notes that many other executives and employees in the company were aware of Kimball's behavior and r

## Casino Royale Director Preferred Henry Cavill's James Bond Audition, Apparently
 - [https://www.gamespot.com/articles/casino-royale-director-preferred-henry-cavills-james-bond-audition-apparently/1100-6520783/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/casino-royale-director-preferred-henry-cavills-james-bond-audition-apparently/1100-6520783/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T16:20:00+00:00

<p>Before Daniel Craig was cast as James Bond, the producers considered a number of other actors, including Henry Cavill. According to Kingsman and Argylle director Matthew Vaughn, Casino Royale director Martin Campbell wanted Cavill over Craig, but 007 producer Barbara Broccoli ultimately went with Craig.</p><p>Appearing on <a href="https://www.youtube.com/watch?v=aFaDg9vjbb4">Sirius XM</a> (<a href="https://www.ign.com/articles/james-bond-director-apparently-preferred-henry-cavill-over-daniel-craig-auditions">via IGN</a>), Vaughn said he was at Pinewood Studios back in the day and saw Cavill and Craig come through for auditions for James Bond. Craig apparently told Vaughn that Cavill was testing for James Bond as well, and that's how Cavill would eventually get on Vaughn's radar and later star in his 2007 movie Stardust.</p><div>          </div><p>Vaughn went on to say he knew that Campbell "preferred" Cavill's audition for James Bond. But Broccoli was convinced to cast Cra

## Devolver Announces Children Of The Sun, A Sniper Game With A Cool Twist
 - [https://www.gamespot.com/articles/devolver-announces-children-of-the-sun-a-sniper-game-with-a-cool-twist/1100-6520724/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/devolver-announces-children-of-the-sun-a-sniper-game-with-a-cool-twist/1100-6520724/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T16:00:00+00:00

<p>Publisher Devolver Digital has announced a new game by developer René Rother, a stylish sniping adventure called Children of the Sun. Headed to PC later this year, Children of the Sun puts you in the boots of The Girl, a sniper looking to eliminate The Cult and its enigmatic leader. The twist here? The Girl only has a single bullet per level, but she's also armed with a few abilities to make that projectile more deadly than an entire warehouse of ammo.</p><div>          </div><p> </p><p>One shot is all you need, as the bullet can be re-aimed on impact, it can curve around obstacles, smashed through armor, and it can be used to perform other feats of gravity-defying ballistic trickery. Each level is a puzzle box of tactical sniping and stealth.</p><a href="https://www.gamespot.com/articles/devolver-announces-children-of-the-sun-a-sniper-game-with-a-cool-twist/1100-6520724/?ftag=CAD-01-10abi2f/">Continue Reading at GameSpot</a>

## Tales Of Kenzera: Zau's Tabletop Inspirations And Rhythmic Combat Are Making Me Excited
 - [https://www.gamespot.com/articles/tales-of-kenzera-zaus-tabletop-inspirations-and-rhythmic-combat-are-making-me-excited/1100-6520756/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/tales-of-kenzera-zaus-tabletop-inspirations-and-rhythmic-combat-are-making-me-excited/1100-6520756/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T16:00:00+00:00

<p>I do love me a good metroidvania game, especially those with a rhythmic tempo to combat (<a href="https://www.gamespot.com/articles/hollow-knight-silksong-love-letter/1100-6500662/">I'll love you always, Hollow Knight</a>) or an intriguingly unfamiliar world rich with story that I want to spend hours uncovering (looking at you, <a href="https://www.gamespot.com/games/iconoclasts/">Iconoclasts</a>). <a href="https://www.gamespot.com/games/tales-of-kenzera-zau/">Tales of Kenzera: Zau</a> may deliver on both fronts, with the demo of the first hour of the game hiding snippets of lore amongst its beautiful levels and offering a taste of the <a href="https://www.gamespot.com/articles/tales-of-kenzera-zau-tackles-grief-as-a-metroidvania-with-dance-like-combat-and-incredible-music/1100-6519777/">dance-like movements of its combo-focused combat</a>. It's still too early to say definitively, but I think there could be a great game here.</p><p dir="ltr">Tales of Kenzera is a 2.5D met

## This Stylish New Shooter Gives You A Single Bullet And A Dozen Targets
 - [https://www.gamespot.com/articles/this-stylish-new-shooter-gives-you-a-single-bullet-and-a-dozen-targets/1100-6520778/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/this-stylish-new-shooter-gives-you-a-single-bullet-and-a-dozen-targets/1100-6520778/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T16:00:00+00:00

<p dir="ltr">In most games, sniping enemy targets from long distance feels impersonal. Single-player campaigns that approximate the experience center it around high-value military targets, while multiplayer games make it only as intimate as your rivalry against a particular player. Children of the Sun, an indie game with a dark heart of vengeance at its core, makes it feel extremely personal. And after playing a segment of the game spanning about two hours, I'm curious where it all ends.</p><p dir="ltr">In Children of the Sun, your protagonist--simply called The Girl--is on a violent quest to kill her way through legions of cultists in search of their mysterious leader. The story is sparse, delivered through brief and often abstracted motion comics, as you get glimpses of the cult's abuses. If the point is to show them as both heartless and faceless, these accomplish the goal well and provide ample impetus to hunt them down.</p><p dir="ltr">The twist is that in each stage, yo

## Netflix 2024 Movies And TV Show Lineup Announced
 - [https://www.gamespot.com/articles/netflix-2024-movies-and-tv-show-lineup-announced/1100-6520784/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/netflix-2024-movies-and-tv-show-lineup-announced/1100-6520784/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T15:56:00+00:00

<p>As we take a step into February 2024, Netflix wants to show its subscribers what they plan on delivering this year. It's got new movies, new shows, and new events heading your way, and there's something for everyone.</p><p>In addition to the pile of new shows, it will also continue brand new chapters for Rebel Moon, Squid Game, Bridgeton, Emily in Paris, and the long-awaited <a href="https://www.gamespot.com/articles/eddie-murphy-returns-to-axel-foley-in-trailer-for-netflixs-beverly-hills-cop-sequel/1100-6519950/">Beverly Hills Cop 4</a>. Keep your eyes peeled for some links to bonus features like behind-the-scenes footage, first-look photos, and teasers.</p><div>          </div><p>Notably absent from the <a href="https://www.netflix.com/tudum/movies-shows-netflix-2024">announcements</a> are the Halle Berry-led Mothership and The Old Guard 2 with Charlize Theron. Both productions were announced around the same time as the Old Guard sequel was greenlit <a href="https://www.

## Palworld Patch For Steam Fixes Lots Of Issues, See All The Changes Here
 - [https://www.gamespot.com/articles/palworld-patch-for-steam-fixes-lots-of-issues-see-all-the-changes-here/1100-6520780/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/palworld-patch-for-steam-fixes-lots-of-issues-see-all-the-changes-here/1100-6520780/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T15:48:00+00:00

<p>A new patch is out now for Palworld on Steam, and it includes many fixes for issues that players have been experiencing since the game launched in January.</p><p>Version 0.1.4.0 is out now, and one of the top fixes is for crashing issues and an issue that could cause enemy pals to get stuck in walls. Previously, the game could crash if players captured more than 7,000 objects, but that's no longer the case.</p><p>The Palworld patch also fixes an issue that could cause players to receive damage twice in some scenarios. What's more, players should no longer clip through walls when dismounting, and the camera positions have been tweaked to help make certain pals easier to see.</p><a href="https://www.gamespot.com/articles/palworld-patch-for-steam-fixes-lots-of-issues-see-all-the-changes-here/1100-6520780/?ftag=CAD-01-10abi2f/">Continue Reading at GameSpot</a>

## Budget-Friendly Calvin And Hobbes Compendium Up For Preorder At Amazon
 - [https://www.gamespot.com/articles/budget-friendly-calvin-and-hobbes-compendium-up-for-preorder-at-amazon/1100-6520779/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/budget-friendly-calvin-and-hobbes-compendium-up-for-preorder-at-amazon/1100-6520779/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T15:33:00+00:00

<p>Calvin and Hobbes are two of the most iconic names in comics, and on March 5, more of the duo's adventures are being rereleased in a portable paperback set. <a href="https://www.amazon.com/Calvin-Hobbes-Portable-Compendium-Set/dp/1524888044?tag=gamespot-preorderguides-20">The Calvin and Hobbes Portable Compendium: Volume 2</a> is now up for preorder at Amazon--and there's a slight discount if you decide to reserve your copy prior to launch.</p><div class="norewrite" title="6520779 - Calvin Hobbes Portable Compendium Volume 2 Preorders">  <div class="buylink-container">                                                                     <div class="js-buylink-item-container buylink-item-container">             <h2 class="item-title">                    <a href="https://www.amazon.com/Calvin-Hobbes-Portable-Compendium-Set/dp/1524888044?tag=gamespot-preorderguides-20">The Calvin and Hobbes Portable Compendium: Volume 2</a>       </h2>                                   <h3 cla

## Amazon Prime Members Can Grab 8 Free Games This Month
 - [https://www.gamespot.com/articles/amazon-prime-gaming-february-2024-free-games/1100-6520769/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/amazon-prime-gaming-february-2024-free-games/1100-6520769/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T15:13:00+00:00

<p>Amazon Prime members have a diverse selection of retro-flavored games to look forward to in February, as nuclear wasteland exploration, space-blasting action, and an old-fashioned murder mystery will be available to claim for free through the <a href="https://gaming.amazon.com/home?filter=Game&amp;ref_=SM_FreeGameswithPrime2023_PRA&amp;signedIn=true">Prime Gaming hub</a>.</p><p>Fallout and Breakout: Recharged kick things off at the beginning of the month. The original Fallout is still a fascinating journey across a world left reeling from the effects of nuclear armageddon. In stark contrast to the modern games, this one is an old-school CRPG. Breakout: Recharged reimagines the original brick-breaking game with slick visuals, more challenging levels, and a catchy soundtrack to listen to, courtesy of award-winning video game composer Megan McDuffee.</p><h2>Prime Gaming lineup for January 2024</h2><h3>February 1</h3><ul><li>Fallout</li><li>Breakout: Recharged</li></ul><h3>Feb

## Squid Game Season 2 Gets First Teaser Trailer, And It Looks Mysterious
 - [https://www.gamespot.com/articles/squid-game-season-2-gets-first-teaser-trailer-and-it-looks-mysterious/1100-6520772/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/squid-game-season-2-gets-first-teaser-trailer-and-it-looks-mysterious/1100-6520772/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T15:13:00+00:00

<p>Netflix has released a sizzle reel for its TV shows and films coming in 2024, and this includes the first footage of the heavily anticipated Squid Game Season 2.</p><p>The teaser shows Lee Jung-jae's character, Seong Gi-hun, at the airport when he fields a call from a mysterious voice telling him, "You'll regret your decision." He replies, "I will find you. No matter what it takes." Here's the full teaser:</p><div><blockquote align="center" class="twitter-tweet"><p dir="ltr">Introducing the very first look at SQUID GAME SEASON 2. Coming this year. <a href="https://t.co/fzRzdtHRDY">pic.twitter.com/fzRzdtHRDY</a></p>  — Netflix (@netflix) <a href="https://twitter.com/netflix/status/1753056361166872823?ref_src=twsrc^tfw">February 1, 2024</a></blockquote>              </div><p>Squid Game premiered in 2021 and quickly became a huge success. The South Korean show's first season followed the participants of a kill-or-be-killed tournament where only one person would survive to cla

## Sonic Mania Devs' Next Game, Penny's Big Breakaway, Recaptures The Early 3D Platformer Era
 - [https://www.gamespot.com/articles/sonic-mania-devs-next-game-pennys-big-breakaway-recaptures-the-early-3d-platformer-era/1100-6520775/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/sonic-mania-devs-next-game-pennys-big-breakaway-recaptures-the-early-3d-platformer-era/1100-6520775/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T15:01:00+00:00

<p dir="ltr">The early days of 3D platformers were a Wild West of disparate ideas and mechanics as developers circled in on what worked, and different colorful mascots with their own hooks were introduced at a steady pace. Evening Star, a new studio formed by the developers of Sonic Mania, is looking to recapture that era with Penny's Big Breakaway, a throwback platformer to the N64, PlayStation, and Dreamcast. And based on my experience so far, it's recaptured that period in gaming history with aplomb.</p><p dir="ltr">This is most apparent in the visual style, which harkens back to a style of early 3D simplicity without looking quite as rudimentary as those older games. It leans heavily on simple shapes and saturated colors, but the designs of both characters and stages are a little more complex than you would actually see on those older platforms. It's a decent compromise, delivering a dose of nostalgia without being overly reliant on it. As someone who doesn't feel enamore

## WWE 2K24 - Rhodes Vs Rollins Ambulance Match Gameplay
 - [https://www.gamespot.com/videos/wwe-2k24-rhodes-vs-rollins-ambulance-match-gameplay/2300-6463305](https://www.gamespot.com/videos/wwe-2k24-rhodes-vs-rollins-ambulance-match-gameplay/2300-6463305)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T15:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1574/15746725/4253523-wwe_v0.jpg" width="480" /> Watch Cody "American Nightmare" Rhodes take on Seth "Freakin" Rollins in an ambulance match in the new WWE 2K24. The game is expected to release March 5, 2024 for current and past generation Xbox and PlayStation consoles, as well as PC.

## WWE 2K24 Adds Exciting New Features But Feels Dated In Other Ways
 - [https://www.gamespot.com/articles/wwe-2k24-adds-exciting-new-features-but-feels-dated-in-other-ways/1100-6520757/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/wwe-2k24-adds-exciting-new-features-but-feels-dated-in-other-ways/1100-6520757/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T15:00:00+00:00

<p dir="ltr">WWE and 2K are back with the newest installment of their annual wrestling title, WWE 2K24. After debuting the practically flawless War Games match in WWE 2K23, fans of the franchise have raised their expectations for what to expect from a new entry. Since playing a preview build of the game at a recent event, I can confidently say there are some major improvements in 2K24, but there are still some areas of the game that need serious attention.</p><p dir="ltr">The version I played included 10 playable wrestlers, a small selection of matches (Royal Rumble, basic bouts, backstage brawls, and the new Ambulance Match), as well as two matches in the new WWE 2K Showcase of the Immortals, which commemorates high-profile Wrestemania matches.</p><p dir="ltr">The addition of the Ambulance Match is a great one. While it's not the sort of game-changer that the six- or eight-person War Games matches were last year, these specialty bouts are easy to figure out how to play and a

## Netflix Cancels Halle Berry Movie That Was Nearly Complete, Citing "Lots Of Issues"
 - [https://www.gamespot.com/articles/netflix-cancels-halle-berry-movie-that-was-nearly-complete-citing-lots-of-issues/1100-6520776/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/netflix-cancels-halle-berry-movie-that-was-nearly-complete-citing-lots-of-issues/1100-6520776/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T14:58:00+00:00

<p>Netflix has confirmed it will not release the sci-fi movie The Mothership, which featured Oscar-winner Halle Berry in the lead role.</p><p>Filming was nearly completed, but "extensive reshoots" were required, and Netflix opted to cancel the release instead. <a href="https://www.theinsneider.com/p/halle-berry-mothership-netflix-not-moving-forward-oscar-nomination-reactions-snubs-surprises">Jeff Sneider originally broke the story last month</a>, which was later corroborated by <a href="https://www.ign.com/articles/netflix-scraps-halle-berry-sci-fi-film-the-mothership-despite-completing-filming">IGN</a> and now <a href="https://www.hollywoodreporter.com/movies/movie-news/netflix-shelves-halle-berry-the-mothership-1235806103/">The Hollywood Reporter.</a></p><p>Matthew Charman would have made his directorial debut with The Mothership, which he also wrote. Molly Parker, John Ortiz, and Omari Hardwick were due to star alongside Berry.</p><a href="https://www.gamespot.com/articles

## Classic Devil May Cry Games Have Been "Retired" On Steam
 - [https://www.gamespot.com/articles/classic-devil-may-cry-games-have-been-retired-on-steam/1100-6520774/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/classic-devil-may-cry-games-have-been-retired-on-steam/1100-6520774/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T14:44:00+00:00

<p>Devil May Cry fans looking to experience two of the older games in their original release format are out of luck, as Devil May Cry 3 and 4 have been removed from the Steam marketplace. Devil May Cry 3: Special Edition and Devil May Cry 4 are no longer available for purchase on the digital marketplace, but they are still available in other editions as the threequel is included in the HD Collection. Meanwhile, Devil May Cry 4: Special Edition is still up for sale, alongside Devil May Cry 5 and Ninja Theory's underrated DmC: Devil May Cry.</p><p>As for why Capcom has taken down the two DMC games, the <a href="https://steamdb.info/app/6550/">Steam Database</a> (via <a href="https://www.pcgamesn.com/devil-may-cry-steam-delisted-capcom">PCGamesN</a>) revealed that both games had been updated with a publisher request to be "retired" from the storefront. Other online sites like Green Man Gaming and Humble are still offering keys for these titles, although it's likely that they'll 

## Immortals Of Aveum Dev Says Game Might Have Done Better At Lower Price Point
 - [https://www.gamespot.com/articles/immortals-of-aveum-dev-says-game-might-have-done-better-at-lower-price-point/1100-6520777/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/immortals-of-aveum-dev-says-game-might-have-done-better-at-lower-price-point/1100-6520777/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T14:41:00+00:00

<p>Immortals of Aveum didn't light the sales charts on fire last year, and according to Ascendant Studios' CEO, a lower price and different release date could have helped.</p><p>In an interview with <a href="https://podcasts.apple.com/us/podcast/remap-radio/id1690437343?i=1000643374387">Remap Radio</a>, Ascendant Studios CEO Bret Robbins said, "Now the game is on sale, and sure enough, we've seen a huge uptick in sales because of the price. The price is interesting, there's an argument to be made that we should've come out at a lower price point."</p><p>At the moment this interview was recorded, Immortals of Aveum was on sale for half price. Robbins also mentioned that a different release window would've been better for the game. In particular, Robbins preferred a January 2024 release date, but there were financial considerations, such as the studio having enough revenue to survive a few months without funds from game sales coming in.</p><a href="https://www.gamespot.com/arti

## Dragon's Dogma 2 Trailer Introduces Warfarer Class, Mysterious Dragonplague
 - [https://www.gamespot.com/articles/dragons-dogma-2-trailer-introduces-warfarer-class-mysterious-dragonplague/1100-6520766/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/dragons-dogma-2-trailer-introduces-warfarer-class-mysterious-dragonplague/1100-6520766/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T14:28:00+00:00

<p>Capcom is still announcing new content for <a href="https://www.gamespot.com/articles/why-dragons-dogma-2-is-worth-getting-excited-about/1100-6504942/">Dragon's Dogma 2</a> two months before its release. At the latest State of Play, Capcom revealed the new Warfarer class as well as the dragonsplague and Vocational Mastery concepts.</p><p>Vocations are Dragon's Dogma's version of classes. Thanks to Vocational Mastery, you can bond with vocation maisters to unlock certain Vocations or learn high-level skills from them. The Warfarer Vocation, something exclusive to the player-character, lets you swap between a diverse arsenal of weapons and learn skills from multiple vocation maisters. It also empowers the player to create custom combos using skills from more than one Vocation.</p><p>One of Dragon's Dogma 2's famous features is the freedom to customize your playstyle. As seen in the latest trailer, you can attack enemies with weapons from standard swords to long-range magic. 

## Taylor Swift's Boyfriend And His Brother Want To Revive Backyard Football
 - [https://www.gamespot.com/articles/taylor-swifts-boyfriend-and-his-brother-want-to-revive-backyard-football/1100-6520773/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/taylor-swifts-boyfriend-and-his-brother-want-to-revive-backyard-football/1100-6520773/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T14:23:00+00:00

<p dir="ltr">Travis Kelce might be busy dating pop superstar Taylor Swift and preparing to play in the Super Bowl for the Kansas City Chiefs, but he's also interested in helping to revive the Backyard Sports franchise, spearheaded by his brother and fellow NFL star Jason Kelce.</p><p dir="ltr">Chatting on their podcast <a href="https://twitter.com/newheightshow/status/1752809588632830454?s=46&amp;t=XZzQ9Jl2WaMKwGNafwyYgQ">New Heights</a>, Travis Kelce asked his brother if he remembered Backyard Football on the PC--part of a sports franchise that started in 1997 with Backyard Baseball. Jason Kelce, (possibly former) center for the Philadelphia Eagles, replied that he not only recalls the game, but wants to bring it back.</p><p dir="ltr">"I don't know if I even want to mention this, because I've secretly been looking into seeing if anybody holds the rights to Backyard Football and Backyard Baseball," Jason Kelce said. "I want to buy it and get this thing going again. That was t

## 28 Weeks Sequel Will Be Two Movies, Lands At Sony
 - [https://www.gamespot.com/articles/28-weeks-sequel-will-be-two-movies-lands-at-sony/1100-6520764/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/28-weeks-sequel-will-be-two-movies-lands-at-sony/1100-6520764/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T14:22:00+00:00

<p>The director and writer for 28 Years Later, Danny Boyle and Alex Garland, have found a home for their new zombie movie with Sony. Not only that but the upcoming project will be told in two films.</p><p dir="ltr">Thanks to <a href="https://www.hollywoodreporter.com/movies/movie-news/28-years-later-lands-home-sony-1235804926/">The Hollywood Reporter</a>, we know that Boyle is set to direct the first film, and as of now, no director is tied to the second movie. In addition, it's being reported that Cillian Murphy is set to return as an executive producer, and it's currently unknown if he'll start in it, too.</p><p dir="ltr">Just a few weeks ago, both <a href="https://www.gamespot.com/app.php/articles/zombie-sequel-28-years-later-on-the-way-from-the-series-original-creators/1100-6520253/">Boyle and writer Garland went shopping around</a> to see which studios would be interested in the film, and it came down to Warners Bros. and Sony. The report goes on to explain that currentl

## Hulu Password-Sharing Crackdown Begins, Following Disney+
 - [https://www.gamespot.com/articles/hulu-password-sharing-crackdown-begins-following-disney/1100-6520771/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/hulu-password-sharing-crackdown-begins-following-disney/1100-6520771/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T14:02:00+00:00

<p>Disney-owned streaming service Hulu is cracking down on password-sharing. Notifications are being sent to subscribers notifying them of a new subscriber agreement that mentions how sharing accounts beyond the same household will soon be forbidden.</p><p>"Unless otherwise permitted by your Service Tier, you may not share your subscription outside of your household," the notice said (<a href="https://www.hollywoodreporter.com/business/digital/hulu-password-sharing-crackdown-begins-follows-disney-plus-1235811936/">via The Hollywood Reporter</a>). "'Household' means the collection of devices associated with your primary personal residence that are used by the individuals who reside therein."</p><p>These changes will go into effect on March 14. The notice also alerted subscribers to how Disney may "analyze the use of your account" to determine if any passwords are being shared.</p><a href="https://www.gamespot.com/articles/hulu-password-sharing-crackdown-begins-following-disney

## Mr. & Mrs. Smith Review - Relationship On Hard Mode
 - [https://www.gamespot.com/reviews/mr-mrs-smith-review-relationship-on-hard-mode/1900-6418172/?ftag=CAD-01-10abi2f](https://www.gamespot.com/reviews/mr-mrs-smith-review-relationship-on-hard-mode/1900-6418172/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T14:00:00+00:00

<p dir="ltr">Relationships are hard. They take communication, honesty with yourself and your partner, long-lasting chemistry, and, most importantly, not shooting each other. That's true in general, but it's at the very core of Prime Video's new series, Mr. &amp; Mrs. Smith, starring Donald Glover and Maya Erskine. The show is based on the Brad Pitt and Angelina Jolie movie of the same name, and has a similar premise, but it's anything but a retread.</p><p dir="ltr">In the 2005 film, John and Jane Smith are a married couple who are both, unbeknownst to one another, top-secret superspies. They're bored in their marriage, because it's really hard when two people are as legendarily gorgeous as they are. Things get wild when they discover their true identities, and we get everything you'd expect from a 2005 action movie, including tense dance scenes, Vince Vaughn looking like a mess and giving relationship advice, and an <a href="https://www.youtube.com/watch?v=CZ0B22z22pI">almost

## Penny's Big Breakaway Gameplay
 - [https://www.gamespot.com/videos/pennys-big-breakaway-gameplay/2300-6463320](https://www.gamespot.com/videos/pennys-big-breakaway-gameplay/2300-6463320)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T14:00:00+00:00

<img height="480" src="https://www.gamespot.com/a/uploads/square_medium/1823/18237460/4253764-gameplay_pennysbigbreakawayi_site.jpg" width="480" /> A 3D platformer from the developers of Sonic Mania!

## Day-One PS Plus Game Foamstars Gets Content Roadmap
 - [https://www.gamespot.com/articles/day-one-ps-plus-game-foamstars-reveals-roadmap/1100-6520767/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/day-one-ps-plus-game-foamstars-reveals-roadmap/1100-6520767/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T06:43:00+00:00

<p>Square Enix and Toylogic have revealed that their upcoming <a href="https://www.gamespot.com/articles/foamstars-looks-like-a-splatoon-clone-but-its-more-interesting-than-that/1100-6517568/">Splatoon-like PlayStation shooter</a> Foamstars will have ongoing seasonal content, with new seasons arriving roughly every five weeks. </p><p>Arriving on February 6 as a PlayStation Plus free game for all membership tiers, Foamstars will be kicking off its first season, Starry Pop, straight off the bat. The initial season will include two time-limited ranked party events--a solo mode called Lonestar, and a team-based event called Tribe-Vibe. In these events, players can spend Rank Points (RP) to play in a five-round match for the chance to win even more RP. Players can climb the ranks by earning enough RP to undertake a Rank-Up Trial in the hopes of reaching the next ranked tier.</p><p>Another limited-time event is Extreme Party, which this season will include two exclusive game modes-

## Suicide Squad Twitch Drops Are Available Now For A Limited Time
 - [https://www.gamespot.com/articles/suicide-squad-twitch-drops-are-available-now-for-a-limited-time/1100-6520765/?ftag=CAD-01-10abi2f](https://www.gamespot.com/articles/suicide-squad-twitch-drops-are-available-now-for-a-limited-time/1100-6520765/?ftag=CAD-01-10abi2f)
 - RSS feed: https://www.gamespot.com/feeds/mashup
 - date published: 2024-02-01T06:10:00+00:00

<p> Now that streamers are getting their hands on <a href="https://www.gamespot.com/games/suicide-squad-kill-the-justice-league/">Suicide Squad: Kill The Justice League</a>, the game's exclusive Twitch drops are now available for a limited time. The drops include four character packs in Twitch's iconic purple color scheme, with each pack available for one week only.</p><p>Coinciding with the game's release in early access, the first of the Twitch drops is now available, starting with the Harley Quinn pack. The pack includes a themed weapon trinket, weapon doll, and the purple-accented Cyber Crime Skin for Harley Quinn, and is available now until February 7.</p><p>To get the loot into your game, you have to link your Warner Bros Games account with Twitch, which you can find <a href="https://rewards.wbgames.com/games/suicide-squad/twitch-rewards/suicide-squad-twitch-drops">instructions for here</a>. Then you'll need to watch a Twitch streamer who has Twitch Drops enabled while 

