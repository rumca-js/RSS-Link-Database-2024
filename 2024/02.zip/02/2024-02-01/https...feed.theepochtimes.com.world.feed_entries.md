# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## Canada Knows About China’s Influence Attempts in Last 2 Federal Elections: CSIS Report
 - [https://www.theepochtimes.com/world/canada-knows-about-chinas-influence-attempts-in-last-2-federal-elections-csis-report-5578664](https://www.theepochtimes.com/world/canada-knows-about-chinas-influence-attempts-in-last-2-federal-elections-csis-report-5578664)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T22:46:57+00:00

People arrive to cast their ballot on federal election day in Montreal on Sept. 20, 2021. (Graham Hughes/The Canadian Press)

## The Opposite of Communism is Faith in God: Rep. Gallagher
 - [https://www.theepochtimes.com/china/the-opposite-of-communism-is-faith-in-god-rep-gallagher-5578804](https://www.theepochtimes.com/china/the-opposite-of-communism-is-faith-in-god-rep-gallagher-5578804)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T22:40:59+00:00

Chairman of the Select Committee on the Chinese Communist Party (CCP), Rep. Mike Gallagher (R-Wis.), speaks during a press conference unveiling the results of the Committee’s investigation into the biolab discovered in Reedley, Calif., in Washington on Nov. 15, 2023. (Madalina Vasiliu/The Epoch Times)

## US Warns Americans to Reconsider Travel Jamaica Amid Spate of Murders
 - [https://www.theepochtimes.com/world/us-warns-americans-to-reconsider-travel-jamaica-amid-spate-of-murders-5578718](https://www.theepochtimes.com/world/us-warns-americans-to-reconsider-travel-jamaica-amid-spate-of-murders-5578718)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T22:16:38+00:00

FILE PHOTO: A view of Cuban and U.S. flags beside the U.S. Embassy in Havana, Cuba, December 15, 2020. REUTERS/Alexandre Meneghini

## UK Judge Dismisses Trump’s Lawsuit Over Discredited Steele Dossier
 - [https://www.theepochtimes.com/us/uk-judge-dismisses-trumps-lawsuit-over-discredited-steele-dossier-5578534](https://www.theepochtimes.com/us/uk-judge-dismisses-trumps-lawsuit-over-discredited-steele-dossier-5578534)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T22:05:04+00:00

Christopher Steele, former British intelligence officer. in London, UK, on March 7, 2017. (Victoria Jones/PA via AP)

## ‘Tipflation’ Culture Putting Added Financial Pressure on Canadians: Survey
 - [https://www.theepochtimes.com/world/tipflation-culture-putting-added-financial-pressure-on-canadians-survey-5578631](https://www.theepochtimes.com/world/tipflation-culture-putting-added-financial-pressure-on-canadians-survey-5578631)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T21:52:09+00:00

A credit card is placed into a credit card machine for processing payments on September 11, 2023 in La Puente, California. (Photo by Frederic J. BROWN / AFP) (Photo by FREDERIC J. BROWN/AFP via Getty Images)

## BC Transit Providers Seek Essential Service Designation as Strike Threat Looms
 - [https://www.theepochtimes.com/world/bc-transit-providers-seek-essential-service-designation-as-strike-threat-looms-5578717](https://www.theepochtimes.com/world/bc-transit-providers-seek-essential-service-designation-as-strike-threat-looms-5578717)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T21:23:49+00:00

Buses line the Vancouver Transit Centre as transit workers from the Canadian Union of Public Employees Local 4500 strike in Vancouver on Jan. 22, 2024. (The Canadian Press/Ethan Cairns)

## 3 Federal Agencies Given ‘Award’ for ‘Most Absurd Regulations’
 - [https://www.theepochtimes.com/world/3-federal-agencies-given-award-for-most-absurd-regulations-5578652](https://www.theepochtimes.com/world/3-federal-agencies-given-award-for-most-absurd-regulations-5578652)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T20:57:34+00:00

A Canada Border Services Agency (CBSA) patch is seen on a CBSA officer’s uniform in Calgary, Alberta, on Aug. 1, 2019. (Jeff Mcintosh/The Canadian Press)

## Biden Admin Announces New Sanctions Targeting Israeli Settlers Accused of Fomenting West Bank Violence
 - [https://www.theepochtimes.com/us/biden-admin-announces-new-sanctions-targeting-israeli-settlers-accused-of-fomenting-west-bank-violence-5578621](https://www.theepochtimes.com/us/biden-admin-announces-new-sanctions-targeting-israeli-settlers-accused-of-fomenting-west-bank-violence-5578621)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T20:54:40+00:00

President Joe Biden speaks to the audience during the South Carolina Democratic Party First in the Nation Celebration dinner at the state fairgrounds in Columbia, S.C., on Jan. 27, 2024. (Sean Rayford/Getty Images)

## World Junior Hockey Players’ Sex Assault Case to Be Before London Court on Monday
 - [https://www.theepochtimes.com/world/world-junior-hockey-players-sex-assault-case-to-be-before-london-court-on-monday-5578690](https://www.theepochtimes.com/world/world-junior-hockey-players-sex-assault-case-to-be-before-london-court-on-monday-5578690)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T20:47:33+00:00

(L-R) Ottawa Senators' Alex Formenton, New Jersey Devils defenceman Cal Foote, New Jersey Devils' Michael McLeod, Calgary Flames centre Dillon Dube, and Philadelphia Flyers goaltender Carter Hart. (The Canadian Press/AP-Matt Slocum, Noah K. Murray, Matt Slocum, Paul Sancya, Corey Sipkin)

## Fundraising Scandal: Quebec Governing Party to Stop Collecting Political Donations
 - [https://www.theepochtimes.com/world/fundraising-scandal-quebec-governing-party-to-stop-collecting-political-donations-5578637](https://www.theepochtimes.com/world/fundraising-scandal-quebec-governing-party-to-stop-collecting-political-donations-5578637)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T20:08:13+00:00

Quebec Premier Francois Legault responds to the Opposition during question period at the legislature in Quebec City on Dec. 7, 2023  (The Canadian Press/Jacques Boissinot)

## Gaza Protesters Blockade Truck Access to Port of Vancouver
 - [https://www.theepochtimes.com/world/gaza-protesters-blockade-truck-access-to-port-of-vancouver-5578605](https://www.theepochtimes.com/world/gaza-protesters-blockade-truck-access-to-port-of-vancouver-5578605)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T19:27:48+00:00

Gantry cranes sit idle above stacks of cargo containers at port during a strike by International Longshore and Warehouse Union Canada workers in the province in Vancouver on July 12, 2023. (The Canadian Press/Darryl Dyck)

## Procurement Watchdog Says ArriveCan Development Had ‘Systemic Non-Compliance,’ Missing Files
 - [https://www.theepochtimes.com/world/procurement-watchdog-says-arrivecan-development-had-systemic-non-compliance-missing-files-5577483](https://www.theepochtimes.com/world/procurement-watchdog-says-arrivecan-development-had-systemic-non-compliance-missing-files-5577483)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T19:27:40+00:00

A smartphone set to the opening screen of the ArriveCan app is seen in a photo illustration made in Toronto on June 29, 2022. (The Canadian Press/Giordano Ciampini)

## US Victims and Families Assert Iranian Role in Oct. 7 Hamas Terrorist Attack on Israel in New Federal Lawsuit
 - [https://www.theepochtimes.com/us/us-victims-and-families-assert-iranian-role-in-oct-7-hamas-terrorist-attack-on-israel-in-new-federal-lawsuit-5578510](https://www.theepochtimes.com/us/us-victims-and-families-assert-iranian-role-in-oct-7-hamas-terrorist-attack-on-israel-in-new-federal-lawsuit-5578510)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T18:53:03+00:00

In this photo provided by the Government of Israel, Judith Raanan, right, and her 17-year-old daughter Natalie are escorted by Israeli soldiers and Gal Hirsch, Prime Minister Benjamin Netanyahu's special coordinator for returning the hostages, as they return to Israel from captivity in the Gaza Strip, on Oct. 20, 2023. (Government of Israel via AP Photo)

## Ontario Takes Good First Step Toward Restoring Foundational Blocks of Learning in Schools
 - [https://www.theepochtimes.com/opinion/ontario-takes-good-first-step-toward-restoring-foundational-blocks-of-learning-in-schools-5578525](https://www.theepochtimes.com/opinion/ontario-takes-good-first-step-toward-restoring-foundational-blocks-of-learning-in-schools-5578525)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T18:41:07+00:00

Ontario Minister of Education Stephen Lecce gives remarks at a press conference in Toronto on Aug. 22, 2019. (The Canadian Press/Christopher Katsarov)

## Planned Rollout of Dental Care Will Miss Deadline in Liberals’ Deal With the NDP
 - [https://www.theepochtimes.com/world/planned-rollout-of-dental-care-will-miss-deadline-in-liberals-deal-with-the-ndp-5578529](https://www.theepochtimes.com/world/planned-rollout-of-dental-care-will-miss-deadline-in-liberals-deal-with-the-ndp-5578529)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T18:33:15+00:00

Minister of Health Mark Holland speaks to the media during the federal cabinet retreat in Montreal, on Jan. 22, 2024. (The Canadian Press/Christinne Muschi)

## Two NB Men Waiting for Compensation a Month After Being Cleared of 1983 Murder
 - [https://www.theepochtimes.com/world/two-nb-men-waiting-for-compensation-a-month-after-being-cleared-of-1983-murder-5578530](https://www.theepochtimes.com/world/two-nb-men-waiting-for-compensation-a-month-after-being-cleared-of-1983-murder-5578530)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T18:27:05+00:00

Walter Gillespie (L) and Robert Mailman pose in the south-end neighbourhood where they grew up in Saint John, N.B., on Aug. 18, 2020. (The Canadian Press/Darren Calabrese)

## Norway’s Most Powerful Storm in Over 30 Years Rips Roofs Off Houses, Cuts Power
 - [https://www.theepochtimes.com/world/norways-most-powerful-storm-in-over-30-years-rips-roofs-off-houses-cuts-power-5578487](https://www.theepochtimes.com/world/norways-most-powerful-storm-in-over-30-years-rips-roofs-off-houses-cuts-power-5578487)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T18:21:49+00:00

A police officer in the center of Bodø, Northern Norway, on Feb. 1, 2024, during extreme weather. (Per-Inge Johnsen/NTB Scanpix via AP)

## 9 of Canada’s Top Winter Festivals
 - [https://www.theepochtimes.com/world/9-of-canadas-top-winter-festivals-5578378](https://www.theepochtimes.com/world/9-of-canadas-top-winter-festivals-5578378)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T18:08:01+00:00

A couple takes photos near the ice sculptures at the Carnaval de Quebec. (Photo courtesy of Audet Photo)

## Minister to Exit Politics Amid Death Threats and Arson Attack on Office
 - [https://www.theepochtimes.com/world/minister-to-exit-politics-amid-death-threats-and-arson-attack-on-office-5578489](https://www.theepochtimes.com/world/minister-to-exit-politics-amid-death-threats-and-arson-attack-on-office-5578489)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T17:54:08+00:00

MP Mike Freer talks with pupils in a year 10 art class in Wren academy school in Finchley, London, on Dec. 14, 2023. (Richard Pohle - WPA Pool/Getty Images)

## Met Police Denies Pro-Palestine March Extention Into Whitehall
 - [https://www.theepochtimes.com/world/met-police-denies-pro-palestine-march-extention-into-whitehall-5578380](https://www.theepochtimes.com/world/met-police-denies-pro-palestine-march-extention-into-whitehall-5578380)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T17:51:27+00:00

Protesters in Trafalgar Square, central London, during a pro-Palestine march organised by Stop the War Coalition and Palestine Solidarity Campaign on Oct. 21, 2023. (Stefan Rousseau/PA)

## Chinese Nationals Charged With Smuggling US Tech to Iran’s Military
 - [https://www.theepochtimes.com/us/chinese-nationals-charged-with-smuggling-us-tech-to-irans-military-5578492](https://www.theepochtimes.com/us/chinese-nationals-charged-with-smuggling-us-tech-to-irans-military-5578492)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T17:37:21+00:00

Missiles displayed in the Iranian capital Tehran in an undated file photo. (Atta Kenare/AFP/Getty Images)

## Bank of England Wary of Lowering Interest Rate, Holds It at 5.25 Percent
 - [https://www.theepochtimes.com/world/bank-of-england-wary-of-lowering-interest-rate-holds-it-at-5-25-percent-5578472](https://www.theepochtimes.com/world/bank-of-england-wary-of-lowering-interest-rate-holds-it-at-5-25-percent-5578472)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T17:34:21+00:00

Andrew Bailey, governor of the Bank of England, during the Bank of England Monetary Policy Report Press Conference, at the Bank of England, London, on Aug. 3, 2023. (Alistair Grant/PA)

## Rumors Abound of Looming Showdown between Ukraine’s Zelenskyy and Top Army Commander
 - [https://www.theepochtimes.com/world/rumors-abound-of-looming-showdown-between-ukraines-zelenskyy-and-top-army-commander-5578468](https://www.theepochtimes.com/world/rumors-abound-of-looming-showdown-between-ukraines-zelenskyy-and-top-army-commander-5578468)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T17:31:57+00:00

Commander-in-Chief of the Armed Forces of Ukraine Valeriy Zaluzhnyi waits before a meeting with U.S. Defense Secretary Lloyd Austin and other officials in Kyiv, Ukraine, on Oct. 19, 2021. (Gleb Garanich/Reuters)

## Evidence Suggests UK Businessman Was Held in Secret Beijing Facility
 - [https://www.theepochtimes.com/world/evidence-suggests-uk-businessman-was-held-in-secret-beijing-facility-5578238](https://www.theepochtimes.com/world/evidence-suggests-uk-businessman-was-held-in-secret-beijing-facility-5578238)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T17:21:27+00:00

British and Chinese flags are seen on display in front of the Tiananmen Gate in Beijing, on Jan. 17, 2008. (Andy Wong /AP Photo)

## Belgian Tractors Park in Front of the EU Parliament
 - [https://www.theepochtimes.com/epochtv/belgian-tractors-park-up-in-front-of-the-eu-parliament-5578479](https://www.theepochtimes.com/epochtv/belgian-tractors-park-up-in-front-of-the-eu-parliament-5578479)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T17:10:24+00:00

People take part in a protest outside of Danish Parliament building in Copenhagen, Denmark, on Feb. 5, 2023. (Johannes Birkebaek/Reuters)

## Cabinet Spent $199M to Enforce COVID Vaccine Mandates for Federal Employees
 - [https://www.theepochtimes.com/world/cabinet-spent-199m-to-enforce-covid-vaccine-mandates-for-federal-employees-5578363](https://www.theepochtimes.com/world/cabinet-spent-199m-to-enforce-covid-vaccine-mandates-for-federal-employees-5578363)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T17:03:55+00:00

Minister of Defence Anita Anand responds to a question during a news conference in Ottawa, May 8, 2023. (The Canadian Press/Adrian Wyld)

## China’s ‘Little Pinks’ Clash With British Pianist in Viral Video
 - [https://www.theepochtimes.com/china/chinas-little-pinks-clash-with-british-pianist-in-viral-video-5576395](https://www.theepochtimes.com/china/chinas-little-pinks-clash-with-british-pianist-in-viral-video-5576395)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T16:42:02+00:00

Pianist Brendan Kavanagh speaks to NTD, the sister media company of The Epoch Times, at St. Pancras International station, in London, on Jan. 26, 2024. (Jane Werrell/NTD)

## Auto Thieves Targeting Federal Fleet
 - [https://www.theepochtimes.com/world/auto-thieves-targeting-federal-fleet-5578433](https://www.theepochtimes.com/world/auto-thieves-targeting-federal-fleet-5578433)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T16:41:34+00:00

Minister of Justice and Attorney General of Canada Arif Virani speaks during a media availability after a cabinet swearing-in ceremony at Rideau Hall in Ottawa on July 26, 2023. (Justin Tang/The Canadian Press)

## Cameroon Rolls Out World’s First Malaria Vaccine as Fear Outweighs Hesitancy
 - [https://www.theepochtimes.com/world/cameroon-rolls-out-worlds-first-malaria-vaccine-as-fear-outweighs-hesitancy-5578333](https://www.theepochtimes.com/world/cameroon-rolls-out-worlds-first-malaria-vaccine-as-fear-outweighs-hesitancy-5578333)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T16:41:03+00:00

People show how to put a mosquito net on a bed during a free insecticide-treated mosquito nets distribution on April 24, 2015 at the town hall in the Port-Bouet popular district of Abidjan. (Sia Kambou/AFP/Getty Images)

## Preacher Who Held up Bible Verse First to Be Convicted of Breaching Buffer Zone Order
 - [https://www.theepochtimes.com/world/preacher-who-held-up-bible-verse-first-to-be-convicted-of-breaching-buffer-zone-order-5578239](https://www.theepochtimes.com/world/preacher-who-held-up-bible-verse-first-to-be-convicted-of-breaching-buffer-zone-order-5578239)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T16:39:35+00:00

Stephen Green, holding a Bible, stands outside Uxbridge Magistrates Court in Uxbridge, England on Oct. 17, 2023. (The Epoch Times)

## China Will Try to Hit US Critical Infrastructure When Attacking Taiwan: Lawmakers
 - [https://www.theepochtimes.com/china/china-will-try-to-hit-us-critical-infrastructure-when-attacking-taiwan-lawmakers-5578381](https://www.theepochtimes.com/china/china-will-try-to-hit-us-critical-infrastructure-when-attacking-taiwan-lawmakers-5578381)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T16:28:21+00:00

A hacker uses his computer in Dongguan, China's southern Guangdong Province, on Aug. 4, 2020. (Nicolas Asfouri/AFP via Getty Images)

## UK Farmers Rally in Growing Movement to Demand Action From Westminster
 - [https://www.theepochtimes.com/world/uk-farmers-rally-in-growing-movement-to-demand-action-from-westminster-5578310](https://www.theepochtimes.com/world/uk-farmers-rally-in-growing-movement-to-demand-action-from-westminster-5578310)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T16:19:33+00:00

Farmers from the group Save British Farming drive tractors across Westminster Bridge, backdropped by the Houses of Parliament and the scaffolded Big Ben tower in London, in a protest against cheaply produced lower standard food being imported from the U.S. after Brexit that will undercut them on July 8, 2020. (Matt Dunham/AP)

## Ottawa to Wait Until After Next Federal Election to Expand Assisted Dying Eligibility
 - [https://www.theepochtimes.com/world/liberal-government-delays-until-2027-planned-expansion-of-assisted-dying-eligibility-5578414](https://www.theepochtimes.com/world/liberal-government-delays-until-2027-planned-expansion-of-assisted-dying-eligibility-5578414)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T15:50:05+00:00

Federal Health Minister Mark Holland makes an announcement in Calgary on Dec. 21, 2023. (The Canadian Press/Todd Korol)

## Liberal Minister Knew About Conflict of Interest in Appointing Green Fund Board Chair, Says Ex-CEO
 - [https://www.theepochtimes.com/world/liberal-minister-knew-about-conflict-of-interest-in-appointing-green-fund-board-chair-says-ex-ceo-5578341](https://www.theepochtimes.com/world/liberal-minister-knew-about-conflict-of-interest-in-appointing-green-fund-board-chair-says-ex-ceo-5578341)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T15:29:01+00:00

Innovation, Science and Industry Minister Navdeep Bains responds to a question during a news conference in Ottawa on Aug. 25, 2020. (The Canadian Press/Adrian Wyld)

## LIVE 10:30 AM ET: Defense Secretary Austin Conducts Press Briefing
 - [https://www.theepochtimes.com/epochtv/defense-secretary-austin-conducts-press-briefing-5578342](https://www.theepochtimes.com/epochtv/defense-secretary-austin-conducts-press-briefing-5578342)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T15:18:26+00:00

Defense Secretary Lloyd Austin speaks at the Pentagon in Washington, on Nov. 22, 2023. (Anna Moneymaker/Getty Images)

## Uber Canada Drivers Will Now See Estimated Fare Before Accepting a Trip
 - [https://www.theepochtimes.com/world/uber-canada-drivers-will-now-see-estimated-fare-before-accepting-a-trip-5577773](https://www.theepochtimes.com/world/uber-canada-drivers-will-now-see-estimated-fare-before-accepting-a-trip-5577773)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T15:17:09+00:00

An Uber driver's vehicle is seen after the company launched service in Vancouver, Jan. 24, 2020. (The Canadian Press/Darryl Dyck)

## Bill to Update Impact Assessment Law Coming in Spring: Wilkinson
 - [https://www.theepochtimes.com/world/bill-to-update-impact-assessment-law-coming-in-spring-wilkinson-5578373](https://www.theepochtimes.com/world/bill-to-update-impact-assessment-law-coming-in-spring-wilkinson-5578373)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T15:14:30+00:00

Minister of Natural Resources Jonathan Wilkinson arrives to take part in a press conference on Parliament Hill in Ottawa on June 15, 2023. (The Canadian Press/Sean Kilpatrick)

## Labour’s Rail Renationalision Plans Exclude Compensation for Private Train Operators
 - [https://www.theepochtimes.com/world/labours-rail-renationalision-plans-exclude-compensation-for-private-train-operators-5578326](https://www.theepochtimes.com/world/labours-rail-renationalision-plans-exclude-compensation-for-private-train-operators-5578326)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T15:09:14+00:00

A Southeastern Highspeed Javelin train passes through Dover in Kent, England, on April 26, 2019. (Gareth Fuller/PA)

## Minister: No Legal Barrier for Khan to Send ULEZ Scrapped Vehicles to Ukraine
 - [https://www.theepochtimes.com/world/minister-no-legal-barrier-for-khan-to-send-ulez-scrapped-vehicles-to-ukraine-5578275](https://www.theepochtimes.com/world/minister-no-legal-barrier-for-khan-to-send-ulez-scrapped-vehicles-to-ukraine-5578275)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T15:00:31+00:00

Transport Secretary Mark Harper on April 30, 2023. (Lucy North/PA Wire)

## CSIS Director to Testify About Transparency at Foreign Interference Inquiry
 - [https://www.theepochtimes.com/world/csis-director-to-testify-about-transparency-at-foreign-interference-inquiry-5578339](https://www.theepochtimes.com/world/csis-director-to-testify-about-transparency-at-foreign-interference-inquiry-5578339)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T14:43:11+00:00

David Vigneault, Director of the Canadian Security Intelligence Service (CSIS), prepares to appear before the Standing Committee on Procedure and House Affairs on Parliament Hill in Ottawa, on June 13, 2023. (The Canadian Press/Justin Tang)

## What Provinces Have Achieved in 20 Years of Cutting Red Tape
 - [https://www.theepochtimes.com/world/what-provinces-have-achieved-in-20-years-of-cutting-red-tape-5576834](https://www.theepochtimes.com/world/what-provinces-have-achieved-in-20-years-of-cutting-red-tape-5576834)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T14:17:43+00:00

The legislature building in Victoria, B.C., on Sept. 25, 2023. British Columbia led the way with red tape reduction efforts starting in 2001. (The Canadian Press/Chad Hipolito)

## Toronto Police Seeking Suspect Tied to Long-Running Taxi Scam
 - [https://www.theepochtimes.com/world/toronto-police-seeking-suspect-tied-to-long-running-taxi-scam-5578298](https://www.theepochtimes.com/world/toronto-police-seeking-suspect-tied-to-long-running-taxi-scam-5578298)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T13:50:39+00:00

A logo at the Toronto Police Services headquarters, in Toronto, on Aug. 9, 2019. (Christopher Katsarov /The Canadian Press)

## Deutsche Bank to Cut 3,500 Jobs and Reward Shareholders
 - [https://www.theepochtimes.com/business/deutsche-bank-to-cut-3500-jobs-and-reward-shareholders-5578285](https://www.theepochtimes.com/business/deutsche-bank-to-cut-3500-jobs-and-reward-shareholders-5578285)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T13:33:12+00:00

The headquarters of Germany's Deutsche Bank in Frankfurt, Germany, on Sept. 21, 2020. (Ralph Orlowski/Reuters)

## Sturgeon Admits Deleting Messages But Denies Major Decisions Were Made Using WhatsApp
 - [https://www.theepochtimes.com/world/sturgeon-admits-deleting-messages-but-denies-major-decisions-were-made-using-whatsapp-5577489](https://www.theepochtimes.com/world/sturgeon-admits-deleting-messages-but-denies-major-decisions-were-made-using-whatsapp-5577489)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T13:05:42+00:00

Former First Minister of Scotland Nicola Sturgeon departs the UK COVID Inquiry at the Edinburgh International Conference Centre in Scotland on Jan. 31, 2024. (Jeff J Mitchell/Getty Images)

## Government Approves 24 New Oil and Gas Exploration Licences in North Sea
 - [https://www.theepochtimes.com/world/government-approves-24-new-oil-and-gas-exploration-licences-in-north-sea-5578270](https://www.theepochtimes.com/world/government-approves-24-new-oil-and-gas-exploration-licences-in-north-sea-5578270)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T12:02:41+00:00

A view of the Johan Sverdrup oilfield in the North Sea, on Jan. 7, 2020. (Carina Johansen/NTB Scanpix/via Reuters)

## Manhunt Under way After ‘Targeted’ Acid Attack on Woman and Children in London
 - [https://www.theepochtimes.com/world/manhunt-under-way-after-targeted-acid-attack-on-woman-and-children-in-london-5578240](https://www.theepochtimes.com/world/manhunt-under-way-after-targeted-acid-attack-on-woman-and-children-in-london-5578240)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T11:55:59+00:00

Forensics teams at the scene of an acid attack in Lessar Avenue, near Clapham Common in south London on Feb. 1, 2024. (PA)

## Chinese Counterfeits Exceed Carcinogen Limits by 930 Times, Posing Global Health Risk
 - [https://www.theepochtimes.com/china/chinese-counterfeits-exceed-carcinogen-limits-by-930-times-posing-global-health-risk-5578209](https://www.theepochtimes.com/china/chinese-counterfeits-exceed-carcinogen-limits-by-930-times-posing-global-health-risk-5578209)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T11:26:13+00:00

File photo shows workers assembling dolls at a production line in Guangdong, China, on Sept. 4, 2007 (Feng Li/Getty Images)

## In Seeking Reengagement, Report Reminds State Department That Taliban Grifted Billions
 - [https://www.theepochtimes.com/world/in-seeking-reengagement-report-reminds-state-department-that-taliban-grifted-billions-5578084](https://www.theepochtimes.com/world/in-seeking-reengagement-report-reminds-state-department-that-taliban-grifted-billions-5578084)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T10:34:37+00:00

Special Inspector General for Afghanistan Reconstruction (SIGAR) John Sopko testifies before the House Foreign Affairs Committee in Washington on Nov. 14, 2023, about how he is frustrated by a lack of cooperation from the Biden administration’s State Department in figuring out where $2.5 billon in United States humanitarian assistance has been spent since August 2021. (Madalina Vasiliu/The Epoch Times)

## CCP Accepts Afghan Taliban Envoy’s Diplomatic Credentials, Officially Recognizing Regime
 - [https://www.theepochtimes.com/china/ccp-accepts-afghan-taliban-envoys-diplomatic-credentials-officially-recognizing-regime-5578093](https://www.theepochtimes.com/china/ccp-accepts-afghan-taliban-envoys-diplomatic-credentials-officially-recognizing-regime-5578093)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T09:11:28+00:00

Chinese State Councilor and Foreign Minister Wang Yi meets with Mullah Abdul Ghani Baradar, political chief of Afghanistan's Taliban, in Tianjin, China, on July 28, 2021.  (Li Ran/Xinhua via Reuters)

## AUKUS 2.0: Australia, New Zealand Pledge Deeper Defence Ties
 - [https://www.theepochtimes.com/world/aukus-2-0-australia-new-zealand-pledge-deeper-defence-ties-5578180](https://www.theepochtimes.com/world/aukus-2-0-australia-new-zealand-pledge-deeper-defence-ties-5578180)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T07:40:49+00:00

Penny Wong, Richard Marles, Winston Peters and Judith Collins attend ANZMIN 2024 in Melbourne (Courtesy of Sarah Hodges/Department of Foreign Affairs and Trade)

## 1 in 5 Australian Smokers Unwilling to Quit
 - [https://www.theepochtimes.com/world/1-in-5-australian-smokers-unwilling-to-quit-5578161](https://www.theepochtimes.com/world/1-in-5-australian-smokers-unwilling-to-quit-5578161)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T06:43:46+00:00

Cigarette stubs are pictured in an ashtray in Frankfurt, Germany, on Dec. 13, 2006. (Ralph Orlowski/Getty Images)

## Police, Nurses, and Employers Among Critics of Australia’s COVID Response
 - [https://www.theepochtimes.com/world/police-nurses-and-employers-among-critics-of-australias-covid-response-5578155](https://www.theepochtimes.com/world/police-nurses-and-employers-among-critics-of-australias-covid-response-5578155)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T06:22:02+00:00

Nurses and members of the health sector rally outside Parliament House in Sydney, Australia, on Feb. 15, 2022. (Lisa Maree Williams/Getty Images)

## Australia Issues Further Sanctions on Businesses, Banks Linked to Burma Junta
 - [https://www.theepochtimes.com/world/australia-issues-further-sanctions-on-businesses-banks-linked-to-burma-junta-5578175](https://www.theepochtimes.com/world/australia-issues-further-sanctions-on-businesses-banks-linked-to-burma-junta-5578175)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T06:08:16+00:00

A protester holds a sign with an iamge of detained civilian leader Aung San Suu Kyi as they prepare to face off against security forces during a demonstration against the military coup in Yangon on March 5, 2021. (STR/AFP via Getty Images)

## Calls For Real-Time Disclosures of Political Donations to Improve Transparency
 - [https://www.theepochtimes.com/world/calls-for-real-time-disclosures-of-political-donations-to-improve-transparency-5578156](https://www.theepochtimes.com/world/calls-for-real-time-disclosures-of-political-donations-to-improve-transparency-5578156)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T05:18:36+00:00

People cast their votes in Melbourne, Australia, on May 21, 2022. (William West/AFP via Getty Images)

## Spare a Thought For Our Self-Made Energy Crisis
 - [https://www.theepochtimes.com/opinion/spare-a-thought-for-our-self-made-energy-crisis-5578032](https://www.theepochtimes.com/opinion/spare-a-thought-for-our-self-made-energy-crisis-5578032)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T05:07:24+00:00

Liddell Power Station in Muswellbrook, Australia, on April 27, 2023. (Roni Bintang/Getty Images)

## Vaping Retailers ‘Addicting’ a New Generation to Nicotine: Professor
 - [https://www.theepochtimes.com/world/vaping-retailers-addicting-a-new-generation-to-nicotine-professor-5578149](https://www.theepochtimes.com/world/vaping-retailers-addicting-a-new-generation-to-nicotine-professor-5578149)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T04:51:07+00:00

Illegal vapes are displayed during a press conference on illegal vape imports in Sydney, Australia, on Sept. 25, 2023. (AAP Image/Bianca De Marchi)

## Alberta on the Right Path With New Gender Reassignment Restrictions for Children
 - [https://www.theepochtimes.com/opinion/alberta-on-the-right-path-with-new-gender-re-assignment-restrictions-for-children-5578158](https://www.theepochtimes.com/opinion/alberta-on-the-right-path-with-new-gender-re-assignment-restrictions-for-children-5578158)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T04:19:10+00:00

Alberta Premier Danielle Smith speaks during an event in Calgary on Oct. 5, 2023. (The Canadian Press/Jeff McIntosh)

## NZ Minister Denies Asking Ministry About Lowering Tobacco Taxes
 - [https://www.theepochtimes.com/world/nz-minister-denies-asking-ministry-about-lowering-tobacco-taxes-5578080](https://www.theepochtimes.com/world/nz-minister-denies-asking-ministry-about-lowering-tobacco-taxes-5578080)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T04:16:00+00:00

Ministers Casey Costello (L) and Melissa Lee look on during a cabinet meeting at Parliament in Wellington, New Zealand on Nov. 28, 2023. (Hagen Hopkins/Getty Images)

## Australia’s COVID-19 Response ‘Worst Ever Public Health Failing’
 - [https://www.theepochtimes.com/world/australias-covid-19-response-worst-ever-public-health-failing-5578134](https://www.theepochtimes.com/world/australias-covid-19-response-worst-ever-public-health-failing-5578134)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T03:49:56+00:00

A closed sign is seen on a business at Newport beach, in Sydney, Australia on Dec. 18, 2020. (AAP Image/Dan Himbrechts)

## House Prices in Australia Rise at Nearly Double the Rate of the US
 - [https://www.theepochtimes.com/world/house-prices-in-australia-rise-at-nearly-double-the-rate-of-the-us-5578070](https://www.theepochtimes.com/world/house-prices-in-australia-rise-at-nearly-double-the-rate-of-the-us-5578070)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T03:33:08+00:00

A general view of residential housing in the suburb of Kirribilli in Sydney, Australia, on May 8, 2021. (Lisa Maree Williams/Getty Images)

## Alberta Plans for Possible Major Drought in 2024
 - [https://www.theepochtimes.com/world/alberta-plans-for-possible-major-drought-in-2024-post-5578079](https://www.theepochtimes.com/world/alberta-plans-for-possible-major-drought-in-2024-post-5578079)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T02:53:11+00:00

Cattle graze at sunset near Cochrane, Alta., on June 8, 2023. (The Canadian Press/Jeff McIntosh)

## Canada Announces $121 Million to Combat Rising Gun Violence, Gang Activity, and Auto Theft
 - [https://www.theepochtimes.com/world/canada-announces-121-million-to-combat-rising-gun-violence-gang-activity-and-auto-theft-5578063](https://www.theepochtimes.com/world/canada-announces-121-million-to-combat-rising-gun-violence-gang-activity-and-auto-theft-5578063)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T02:25:36+00:00

Minister of Public Safety Dominic LeBlanc speaks at a news conference on Parliament Hill in Ottawa, on Sept. 7, 2023. (The Canadian Press/Justin Tang)

## Progressives Call for Biden to Restore Funding for UN Agency Whose Employees Were Accused of Joining Hamas Attacks
 - [https://www.theepochtimes.com/us/progressives-call-for-biden-to-restore-funding-for-un-agency-whose-employees-were-accused-of-joining-hamas-attacks-5578056](https://www.theepochtimes.com/us/progressives-call-for-biden-to-restore-funding-for-un-agency-whose-employees-were-accused-of-joining-hamas-attacks-5578056)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T02:00:36+00:00

Rep. Alexandria Ocasio-Cortez (D-N.Y.) speaks during a hearing in Washington on Aug. 24, 2020. (Tom Williams/Pool via Reuters)

## Italian PM Unveils Plan to Curb Illegal African Immigration Through Economic Development
 - [https://www.theepochtimes.com/world/italian-pm-unveils-plan-to-curb-illegal-african-immigration-through-economic-development-5578046](https://www.theepochtimes.com/world/italian-pm-unveils-plan-to-curb-illegal-african-immigration-through-economic-development-5578046)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T01:21:56+00:00

Italian Premier Giorgia Meloni, center, speaks as she is flanked from left; Italian Foreign Minister Antonio Tajani, President of the European Commission Ursula von der Leyen, President of the European Parliament Roberta Metsola, African Union President Azali Assoumani, African Union Commission Chairperson Moussa Faki Mahamat, President of the European Council Charles Michel and UN Deputy Secretary-General Amina Mohammed, at the Senate for the start of an Italy - Africa summit, in Rome, Monday, Jan. 29, 2024 (Roberto Monaldo/LaPresse via AP)

## Jury, Coroner Make Recommendations in Saskatchewan Mass Killing Inquest
 - [https://www.theepochtimes.com/world/jury-coroner-make-recommendations-in-saskatchewan-mass-killing-inquest-5578072](https://www.theepochtimes.com/world/jury-coroner-make-recommendations-in-saskatchewan-mass-killing-inquest-5578072)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T01:08:13+00:00

Keith Brown, the lawyer representing the James Smith Cree Nation, speaks with people as they enter the public coroner's inquest into the mass stabbings that happened on James Smith Cree Nation in 2022 in Melfort, Sask., on Jan. 31, 2024. (The Canadian Press/Liam Richards)

## ‘Free’ Trips to the Doctor Increase by More Than 360,000 in Australia
 - [https://www.theepochtimes.com/world/free-trips-to-the-doctor-increase-by-more-than-360000-in-australia-5577898](https://www.theepochtimes.com/world/free-trips-to-the-doctor-increase-by-more-than-360000-in-australia-5577898)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T00:52:48+00:00

(Shutterstock)

## India & China: A Reversal of Economies?
 - [https://www.theepochtimes.com/us/india-china-a-reversal-of-economies-5577210](https://www.theepochtimes.com/us/india-china-a-reversal-of-economies-5577210)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2024-02-01T00:19:30+00:00

India's Prime Minister Narendra Modi (L) shakes hands with China's leader Xi Jinping before the G20 leaders' family photo in Hangzhou, China, on Sept. 4, 2016. (Greg Baker/AFP/Getty Images)

