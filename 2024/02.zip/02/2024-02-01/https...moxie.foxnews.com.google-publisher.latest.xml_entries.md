# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Fox News Poll: Biden and Trump tie in Wisconsin head-to-head matchup
 - [https://www.foxnews.com/official-polls/fox-news-poll-biden-trump-tie-wisconsin-head-to-head-matchup](https://www.foxnews.com/official-polls/fox-news-poll-biden-trump-tie-wisconsin-head-to-head-matchup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T23:00:08+00:00

Fox News poll reveals Wisconsin voters currently tied President Joe Biden and former President Donald Trump and who they would back between the two based on several key issues.

## Fox News Poll: Trump leads Biden in Georgia, receiving just over 50% support
 - [https://www.foxnews.com/politics/fox-news-poll-trump-leads-biden-georgia-receiving-just-over-50-support](https://www.foxnews.com/politics/fox-news-poll-trump-leads-biden-georgia-receiving-just-over-50-support)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T23:00:05+00:00

Former President Donald Trump leads President Joe Biden with just over 50% support in Georgia, a state Biden won by less than 1 point in 2020, in a new Fox News poll.

## Elmo's viral post attracts 'trauma dump,' plus a woman's plea to find trashed diamond
 - [https://www.foxnews.com/lifestyle/elmos-viral-post-attracts-trauma-dump-womans-plea-find-trashed-diamond](https://www.foxnews.com/lifestyle/elmos-viral-post-attracts-trauma-dump-womans-plea-find-trashed-diamond)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:51:10+00:00

The Fox News Lifestyle Newsletter brings you trending stories on family, travel, food, neighbors helping neighbors, pets, autos, military veterans, heroes, faith and American values.

## Panama's sole Catholic cardinal found alive after brief disappearance
 - [https://www.foxnews.com/world/panamas-sole-catholic-cardinal-found-alive-brief-disappearance](https://www.foxnews.com/world/panamas-sole-catholic-cardinal-found-alive-brief-disappearance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:45:37+00:00

Panamanian authorities have reportedly found 79-year-old Roman Catholic Cardinal José Luis Lacunza alive after he went missing near the Costa Rican border earlier this week.

## Small plane crashes in outer Philadelphia suburbs
 - [https://www.foxnews.com/us/small-plane-crashes-outer-philadelphia-suburbs](https://www.foxnews.com/us/small-plane-crashes-outer-philadelphia-suburbs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:44:16+00:00

A small aircraft reportedly crashed in West Caln, Pennsylvania, early Thursday afternoon, shortly after taking off from the nearby Chester County Airport.

## State Department imposes financial sanctions on Israeli nationals for threatening peace in West Bank
 - [https://www.foxnews.com/politics/state-department-imposes-financial-sanctions-israeli-nationals-threatening-peace-west-bank](https://www.foxnews.com/politics/state-department-imposes-financial-sanctions-israeli-nationals-threatening-peace-west-bank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:42:58+00:00

The State Department announced financial sanctions against four Israeli nationals who allegedly created instability and threatened peace in the West Bank.

## Fox News Politics: Haley's homecoming
 - [https://www.foxnews.com/politics/fox-news-politics-haley-homecoming](https://www.foxnews.com/politics/fox-news-politics-haley-homecoming)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:38:09+00:00

The latest updates from the 2024 campaign trail, exclusive interviews and more Fox News politics content

## Gov. Lee names successor to retiring Tennessee Supreme Court justice
 - [https://www.foxnews.com/politics/gov-lee-names-successor-retiring-tennessee-supreme-court-justice](https://www.foxnews.com/politics/gov-lee-names-successor-retiring-tennessee-supreme-court-justice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:29:15+00:00

Republican Tennessee Gov. Bill Lee announced Thursday his selection of Mary L. Wagner to fill retiring Justice Roger Page&apos;s seat on the state Supreme Court bench.

## Arkansas police chief fired, arrested for kidnapping
 - [https://www.foxnews.com/us/arkansas-police-chief-fired-arrested-kidnapping](https://www.foxnews.com/us/arkansas-police-chief-fired-arrested-kidnapping)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:27:40+00:00

Recently-terminated Eudora, Arkansas, Police Chief Michael Pitts has been arrested and charged with kidnapping after he allegedly assaulted and stranded a suspect in Chicot County.

## Bruce Springsteen’s mother Adele, dead at 98
 - [https://www.foxnews.com/entertainment/bruce-springsteens-mother-adele-dead-98](https://www.foxnews.com/entertainment/bruce-springsteens-mother-adele-dead-98)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:16:32+00:00

Bruce Springsteen’s mother, Adele Springsteen, died Wednesday at the age of 98, the musician confirmed in a social media post.

## Thousands rally in Slovakia against government's plan to close the special prosecutor's office
 - [https://www.foxnews.com/world/thousands-rally-slovakia-governments-plan-close-special-prosecutors-office](https://www.foxnews.com/world/thousands-rally-slovakia-governments-plan-close-special-prosecutors-office)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:15:11+00:00

Protests against Prime Minister Robert Fico&apos;s plan to amend the nation&apos;s penal code have now spread to 31 cities and towns, as public backlash grows.

## Maine man gets 48 years for killing girlfriend in hit-and-run, fleeing to Mexico
 - [https://www.foxnews.com/us/maine-man-gets-48-years-killing-girlfriend-hit-and-run-fleeing-mexico](https://www.foxnews.com/us/maine-man-gets-48-years-killing-girlfriend-hit-and-run-fleeing-mexico)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T22:08:54+00:00

Raymond Lester, 37, of Portland, Maine, has been sentenced to 48 years in prison for the 2022 hit-and-run death of his girlfriend, Nicole Mokeme.

## Suspected illegal migrants land boat on San Diego beach and flee into wealthy village
 - [https://www.foxnews.com/world/suspected-illegal-migrants-land-boat-san-diego-beach-flee-wealthy-village](https://www.foxnews.com/world/suspected-illegal-migrants-land-boat-san-diego-beach-flee-wealthy-village)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:58:25+00:00

A speedboat full of suspected illegal migrants was captured on video landing on a beach in California Tuesday and they then flee into a wealthy seaside village.

## Republicans raise alarm as Biden admin prepares plan to protect wolves nationwide
 - [https://www.foxnews.com/politics/republicans-raise-alarm-biden-admin-prepares-plan-protect-wolves-nationwide](https://www.foxnews.com/politics/republicans-raise-alarm-biden-admin-prepares-plan-protect-wolves-nationwide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:51:32+00:00

FIRST ON FOX: House Republicans on the Natural Resources Committee are probing the Biden administration over its efforts to protect the gray wolf species.

## Billy Baldwin ‘questioned’ whether Chyna Phillips’ marriage could survive after religion overtook her life
 - [https://www.foxnews.com/entertainment/billy-baldwin-questioned-whether-chyna-phillips-marriage-could-survive-after-religion-overtook-her-life](https://www.foxnews.com/entertainment/billy-baldwin-questioned-whether-chyna-phillips-marriage-could-survive-after-religion-overtook-her-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:50:26+00:00

Billy Baldwin and Chynna Phillips shared a video of a conversation the two had about religion after she claimed her relationship with Jesus led to &quot;ruptures&quot; in their marriage.

## Cowboys' Micah Parsons appears to take aim at team's defensive coaching staff just before Dan Quinn's exit
 - [https://www.foxnews.com/sports/cowboys-micah-parsons-appears-to-take-aim-at-teams-defensive-coaching-staff-just-before-dan-quinns-exit](https://www.foxnews.com/sports/cowboys-micah-parsons-appears-to-take-aim-at-teams-defensive-coaching-staff-just-before-dan-quinns-exit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:45:15+00:00

The Cowboys came up short once again in the playoffs. Micah Parsons finally gave his take on the postseason exit and seemed to point the finger at the coaching staff.

## California judge blocks gun control law requiring background checks for ammo purchases
 - [https://www.foxnews.com/politics/california-judge-blocks-gun-control-law-requiring-background-checks-ammo-purchases](https://www.foxnews.com/politics/california-judge-blocks-gun-control-law-requiring-background-checks-ammo-purchases)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:43:34+00:00

U.S. District Judge Roger Benitez in San Diego said a California law requiring gun owners to undergo a background check to buy ammo is unconstitutional.

## Terrorist who crossed border allowed to roam US for nearly a year, arrested only after ICE 'became aware'
 - [https://www.foxnews.com/politics/terrorist-crossed-border-allowed-roam-us-nearly-year-arrested-only-after-ice-became-aware](https://www.foxnews.com/politics/terrorist-crossed-border-allowed-roam-us-nearly-year-arrested-only-after-ice-became-aware)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:37:10+00:00

Biden&apos;s acting ICE director admitted that an al-Shabab terrorist was allowed to roam freely in the U.S. for nearly a year after he crossed the southern border illegally.

## Former Alabama baseball coach slapped with 15-year ban after sports betting scandal
 - [https://www.foxnews.com/sports/former-alabama-baseball-coach-slapped-15-year-ban-sports-betting-scandal](https://www.foxnews.com/sports/former-alabama-baseball-coach-slapped-15-year-ban-sports-betting-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:34:24+00:00

Former Alabama head baseball coach Brad Bohannon was hit with a 15-year ban from the NCAA after an investigation confirmed he provided inside information for a sports bettor.

## Beverly Hills police detain armed suspect at Waldorf Astoria hotel ahead of Grammys party
 - [https://www.foxnews.com/us/beverly-hills-police-detain-suspect-waldorf-astoria-hotel-ahead-clive-davis-grammy-party](https://www.foxnews.com/us/beverly-hills-police-detain-suspect-waldorf-astoria-hotel-ahead-clive-davis-grammy-party)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:31:16+00:00

Beverly Hills police say they have detained a suspect at the city’s famous Waldorf Astoria after responding to an active threat situation.

## Canadian Pizza Hut goes viral for hysterical typo about why dining room was closed
 - [https://www.foxnews.com/media/canadian-pizza-hut-goes-viral-for-hysterical-typo-about-why-dining-room-was-closed](https://www.foxnews.com/media/canadian-pizza-hut-goes-viral-for-hysterical-typo-about-why-dining-room-was-closed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:29:54+00:00

A Canadian Pizza Hut has gone viral after a hysterical typo left Fox News host Greg Gutfeld urging viewers not to order the sausage at this location.

## Gunmen take hostages at US company's Turkish factory in apparent protest of Gaza war
 - [https://www.foxnews.com/world/gunmen-take-hostages-us-companys-turkish-factory-apparent-protest-gaza-war](https://www.foxnews.com/world/gunmen-take-hostages-us-companys-turkish-factory-apparent-protest-gaza-war)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:28:40+00:00

Seven members of the staff of a Turkish factory are currently being held hostage by gunmen who are protesting the loss of life in the Gaza Strip.

## Hollywood moguls, billionaires flood Biden's victory fund with six-figure donations
 - [https://www.foxnews.com/politics/hollywood-moguls-billionaires-flood-bidens-victory-fund-with-six-figure-donations](https://www.foxnews.com/politics/hollywood-moguls-billionaires-flood-bidens-victory-fund-with-six-figure-donations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:16:34+00:00

President Biden&apos;s re-election efforts received a big boost from Hollywood tycoons and other billionaires during the last quarter, new filings show.

## GOP senators demand the FBI 'repair the damage' to it's credibility over anti-Catholic memo debacle
 - [https://www.foxnews.com/politics/gop-senators-demand-the-fbi-repair-the-damage-to-its-credibility-over-anti-catholic-memo-debacle](https://www.foxnews.com/politics/gop-senators-demand-the-fbi-repair-the-damage-to-its-credibility-over-anti-catholic-memo-debacle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:13:53+00:00

Republican senators are demanding that the FBI &quot;repair the damage&quot; to its credibility after a series of errors surrounding the origin of the anti-Catholic memo

## 19 people, mostly women, detained at Atlanta area home; sex trafficking probe ensues
 - [https://www.foxnews.com/us/19-people-mostly-women-detained-atlanta-area-home-sex-trafficking-probe-ensues](https://www.foxnews.com/us/19-people-mostly-women-detained-atlanta-area-home-sex-trafficking-probe-ensues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:12:47+00:00

Police in South Fulton, Georgia, detained 19 people Thursday following reports of shots fired at a &quot;problem residence&quot; where a &quot;sex party&quot; was reportedly being advertised.

## Tom Brady's dad reveals Bill Belichick's 'horrible' trait that ended Patriots' glory days
 - [https://www.foxnews.com/sports/tom-bradys-dad-reveals-bill-belichicks-horrible-trait-ended-patriots-glory-days](https://www.foxnews.com/sports/tom-bradys-dad-reveals-bill-belichicks-horrible-trait-ended-patriots-glory-days)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:09:15+00:00

Bill Belichick&apos;s take that Tom Brady was no longer an elite quarterback backfired almost immediately as Brady won a Super Bowl in his first season after his Patriots tenure.

## Billionaire Peter Thiel funding athletic event that will not test for PEDs: 'Olympics on steroids'
 - [https://www.foxnews.com/sports/billionaire-peter-thiel-funding-athletic-event-not-test-peds-olympics-steroids](https://www.foxnews.com/sports/billionaire-peter-thiel-funding-athletic-event-not-test-peds-olympics-steroids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:09:02+00:00

The &quot;Enhanced Games,&quot; an athletic event that will not have steroid testing, will be funded by PayPal and Founders Fund founder Peter Thiel.

## 'We need to rein them in': Lawmakers rail against social media CEOs, but is there any regulation in sight?
 - [https://www.foxnews.com/politics/rein-them-lawmakers-rail-social-media-ceos-regulation-sight](https://www.foxnews.com/politics/rein-them-lawmakers-rail-social-media-ceos-regulation-sight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:07:03+00:00

Lawmakers across the political aisle on Capitol Hill agreed that Big Tech CEOs have not enough to safeguard children on social media following Senate hearing.

## Lewis Hamilton to switch gear in 2025; will race for Ferrari in shock move
 - [https://www.foxnews.com/sports/lewis-hamilton-switch-gear-2025-race-ferrari-shock-move](https://www.foxnews.com/sports/lewis-hamilton-switch-gear-2025-race-ferrari-shock-move)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:06:00+00:00

Formula 1 star Lewis Hamilton shocked the racing world on Thursday when it was revealed he&apos;s leaving Mercedes at the end of the 2024 season.

## Retired public school employee, 79, behind bars for inappropriate messages to child: police
 - [https://www.foxnews.com/us/retired-public-school-employee-79-behind-bars-inappropriate-messages-kid-police](https://www.foxnews.com/us/retired-public-school-employee-79-behind-bars-inappropriate-messages-kid-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T21:05:03+00:00

Former Michigan school employee Sue Ann Asch, 79, was arrested this month after an investigation found she allegedly sent inappropriate messages to a minor, police say.

## Consumer group reveals left-wing groups increasingly using courts to push Green New Deal
 - [https://www.foxnews.com/politics/left-wing-groups-increasingly-using-courts-push-green-new-deal-report](https://www.foxnews.com/politics/left-wing-groups-increasingly-using-courts-push-green-new-deal-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:55:10+00:00

EXCLUSIVE: Left-wing interest groups and Democrats have launched a concerted effort in recent years to push climate policies through so-called public nuisance lawsuits.

## Colorado police find child's concrete-encased remains inside storage unit
 - [https://www.foxnews.com/us/colorado-police-find-childs-concrete-encased-remains-storage-unit](https://www.foxnews.com/us/colorado-police-find-childs-concrete-encased-remains-storage-unit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:49:11+00:00

Police in Pueblo, Colorado, have announced the discovery of a child&apos;s body encased in concrete inside a storage unit, as well as their pursuit of two other missing children.

## Authorities search for Roman Catholic cardinal missing in Panama
 - [https://www.foxnews.com/world/authorities-search-roman-catholic-cardinal-missing-panama](https://www.foxnews.com/world/authorities-search-roman-catholic-cardinal-missing-panama)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:44:48+00:00

José Luis Lacunza is the only Catholic cardinal in Panama, and his mysterious disappearance has triggered a national investigation.

## Arnold Schwarzenegger jokes grandchildren from Chris Pratt are 'a little spoiled'
 - [https://www.foxnews.com/entertainment/arnold-schwarzenegger-jokes-grandchildren-chris-pratt-little-spoiled](https://www.foxnews.com/entertainment/arnold-schwarzenegger-jokes-grandchildren-chris-pratt-little-spoiled)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:41:08+00:00

Arnold Schwarzenegger says his grandchildren from daughter Katherine and Chris Pratt are &quot;a little spoiled.&quot; He joked how they refused to shovel manure after playing with his animals.

## Ravens' Mark Andrews helps save woman’s life on flight
 - [https://www.foxnews.com/sports/ravens-mark-andrews-helps-save-womans-life-flight](https://www.foxnews.com/sports/ravens-mark-andrews-helps-save-womans-life-flight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:37:58+00:00

Baltimore Ravens tight end Mark Andrews reportedly sprung to action on a Southwest Airlines flight Thursday morning to help save a woman&apos;s life.

## Morocco arrests 30 in newborn trafficking bust
 - [https://www.foxnews.com/world/morocco-arrests-30-newborn-trafficking-bust](https://www.foxnews.com/world/morocco-arrests-30-newborn-trafficking-bust)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:33:23+00:00

Moroccan authorities have reportedly arrested some 30 people this week as part of a wide-ranging blackmail and human trafficking investigation.

## Former Oberlin College coach reaffirms stance on trans athletes after quitting: ‘The males are winning’
 - [https://www.foxnews.com/media/former-oberlin-college-coach-stance-trans-athletes-quitting-males-winning](https://www.foxnews.com/media/former-oberlin-college-coach-stance-trans-athletes-quitting-males-winning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:31:32+00:00

Former Oberlin College women&apos;s lacrosse coach Kim Russell reaffirmed her belief that &apos;natural-born&apos; males should not compete with biological females in sports.

## Ravens star throws cold water on Bill Belichick's legacy after he doesn't land coaching job
 - [https://www.foxnews.com/sports/ravens-star-throws-cold-water-bill-belichicks-legacy-doesnt-land-coaching-job](https://www.foxnews.com/sports/ravens-star-throws-cold-water-bill-belichicks-legacy-doesnt-land-coaching-job)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:31:04+00:00

It looks like for the first time since 1974, Bill Belichick will not be on an NFL sideline now that every open head-coaching job is filled.

## Elmo goes viral with innocent tweet attracting major 'trauma dump' from social media users: 'Help us, Elmo'
 - [https://www.foxnews.com/lifestyle/elmo-goes-viral-with-innocent-tweet-attracting-major-trauma-dump-from-social-media-users-help-us-elmo](https://www.foxnews.com/lifestyle/elmo-goes-viral-with-innocent-tweet-attracting-major-trauma-dump-from-social-media-users-help-us-elmo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:30:53+00:00

Elmo has taken the internet by storm after checking in with people on &quot;X&quot; to see how they&apos;re doing — leading to an explosive response from users on the social media platform.

## Iran-backed Houthi launch three attacks in Red Sea, Gulf of Aden as tensions escalate; US military responds
 - [https://www.foxnews.com/world/iran-backed-houthi-launch-three-attacks-red-sea-gulf-aden-tensions-escalate](https://www.foxnews.com/world/iran-backed-houthi-launch-three-attacks-red-sea-gulf-aden-tensions-escalate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:30:20+00:00

U.S. forces on Thursday thwarted three separate attacks by Iran-backed Houthi militants in Yemen aimed at vessels in the Gulf of Aden and the Red Sea.

## 'The View' co-hosts clash over whether America is a racist country: 'Can’t dismiss my lived experience'
 - [https://www.foxnews.com/media/the-view-co-hosts-clash-over-whether-america-racist-country-cant-dismiss-my-lived-experience](https://www.foxnews.com/media/the-view-co-hosts-clash-over-whether-america-racist-country-cant-dismiss-my-lived-experience)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:22:51+00:00

&quot;The View&quot; co-host Sunny Hostin declared a &quot;significant portion&quot; of Americans are racist as the co-hosts clashed over whether the U.S. is a racist country.

## Oregon Supreme Court stops 10 GOP lawmakers from running for re-election, siding with Democrat's ballot ban
 - [https://www.foxnews.com/politics/oregon-supreme-court-keeps-10-gop-lawmakers-running-reelection-siding-democrat-ballot-ban](https://www.foxnews.com/politics/oregon-supreme-court-keeps-10-gop-lawmakers-running-reelection-siding-democrat-ballot-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:21:42+00:00

The Oregon Supreme Court sided with the Democratic secretary of state&apos;s move banning 10 GOP senators from the ballot over a walkout last summer.

## Angel Reese, Caitlin Clark to face tough reality upon entering WNBA, basketball legend says
 - [https://www.foxnews.com/sports/angel-reese-caitlin-clark-will-face-tough-reality-upon-entering-wnba-basketball-legend-says](https://www.foxnews.com/sports/angel-reese-caitlin-clark-will-face-tough-reality-upon-entering-wnba-basketball-legend-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:20:15+00:00

WNBA legend Sheryl Swoopes predicted the trajectory of Angel Reese and Caitlin Clark as they get closer to the professional ranks after their collegiate careers.

## Kevin Costner welcomes 'newest addition' to family: 'Already in love'
 - [https://www.foxnews.com/entertainment/kevin-costner-welcomes-newest-addition-family-already-in-love](https://www.foxnews.com/entertainment/kevin-costner-welcomes-newest-addition-family-already-in-love)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:10:22+00:00

Kevin Costner admitted he was already &quot;in love&quot; with his new Labrador puppy when he introduced social media followers to his furry friend Thursday.

## Police, student protesters clash in Greek capital as university bill foments unrest
 - [https://www.foxnews.com/world/police-student-protesters-clash-greek-capital-university-bill-foments-unrest](https://www.foxnews.com/world/police-student-protesters-clash-greek-capital-university-bill-foments-unrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:04:59+00:00

Student protesters clashed with police in Athens, Greece, amid a demonstration against the center-right government&apos;s plan to legalize private universities.

## Prosecutors appeal decision to move 'monster,' who held daughter captive for 24 years, to regular prison
 - [https://www.foxnews.com/world/prosecutors-appeal-decision-move-monster-held-daughter-captive-24-years-regular-prison](https://www.foxnews.com/world/prosecutors-appeal-decision-move-monster-held-daughter-captive-24-years-regular-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T20:01:00+00:00

Prosecutors are appealing a decision to move Josef Fritzl, who held his daughter captive in a basement for 24 years and fathered seven children with her, to regular prison.

## Bull riding, cat skiing and more: A 2024 bucket list for the ultimate adventure seeker
 - [https://www.foxnews.com/lifestyle/bucket-list-adventure-seeker](https://www.foxnews.com/lifestyle/bucket-list-adventure-seeker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:57:35+00:00

Thrills can be found in a variety of activities, from skiing down the slopes to swimming with the fish. This guide provides activities fit for the adventure seeker.

## ATF whistleblowers sound alarm on Biden admin proposal that effectively bans private gun sales: report
 - [https://www.foxnews.com/politics/atf-whistleblowers-sound-alarm-biden-admin-proposal-effectively-bans-private-gun-sales-report](https://www.foxnews.com/politics/atf-whistleblowers-sound-alarm-biden-admin-proposal-effectively-bans-private-gun-sales-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:57:31+00:00

Bureau of Alcohol, Tobacco, Firearms and Explosives whistleblowers say the agency drafted a 1,300-page document that would effectively ban private gun sales.

## Climate activist Greta Thunberg goes on trial in London for blocking oil and gas conference
 - [https://www.foxnews.com/world/climate-activist-greta-thunberg-trial-london-blocking-oil-gas-conference](https://www.foxnews.com/world/climate-activist-greta-thunberg-trial-london-blocking-oil-gas-conference)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:53:25+00:00

Swedish climate activist Greta Thunberg was defiant outside British court as she defended her actions protesting an oil and gas industry conference last year in London.

## Taylor Swift, Drake and other megastar music pulled from TikTok
 - [https://www.foxnews.com/tech/taylor-swift-drake-other-megastar-music-pulled-from-tiktok](https://www.foxnews.com/tech/taylor-swift-drake-other-megastar-music-pulled-from-tiktok)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:52:17+00:00

Universal Music Group has removed its extensive music catalog, which includes superstars like Taylor Sift, Drake and Olivia Rodrigo, from TikTok.

## Redistricting reports due in case poised to reshape Wisconsin Legislature
 - [https://www.foxnews.com/politics/redistricting-reports-due-case-poised-reshape-wisconsin-legislature](https://www.foxnews.com/politics/redistricting-reports-due-case-poised-reshape-wisconsin-legislature)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:50:52+00:00

Redistricting reports, set to recommend new Wisconsin legislative maps less favorable to Republicans, are due to the state&apos;s majority-liberal Supreme Court on Thursday.

## Large majority of illegal border crossings shift to Arizona and California, pivoting away from Texas
 - [https://www.foxnews.com/politics/large-majority-illegal-border-crossings-shift-arizona-california-pivoting-away-texas](https://www.foxnews.com/politics/large-majority-illegal-border-crossings-shift-arizona-california-pivoting-away-texas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:43:04+00:00

More illegal migrant crossings are shifting from the Texas border to California and Arizona amid increased Mexican enforcement and Texas deterrence..

## VA sets record for most homeless veterans placed in housing: report
 - [https://www.foxnews.com/us/va-sets-record-most-homeless-veterans-placed-housing-report](https://www.foxnews.com/us/va-sets-record-most-homeless-veterans-placed-housing-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:41:38+00:00

The Department of Veterans Affairs put over 46,000 homeless former troops in permanent housing in 2023, beating the agency&apos;s goal and setting a new record in the process.

## Chiefs' Travis Kelce top voter-getter for favorite football star to have as a neighbor
 - [https://www.foxnews.com/sports/chiefs-travis-kelce-top-voter-getter-for-favorite-football-star-to-have-as-a-neighbor](https://www.foxnews.com/sports/chiefs-travis-kelce-top-voter-getter-for-favorite-football-star-to-have-as-a-neighbor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:39:26+00:00

Landing a great neighbor is something most Americans likely hope for, but having the opportunity to live next door to an NFL star is even more desirable.

## Anonymous NHL player poll reveals player with the most punchable face: ‘Always hated the guy’
 - [https://www.foxnews.com/sports/anonymous-nhl-player-poll-reveals-player-most-punchable-face-always-hated-guy](https://www.foxnews.com/sports/anonymous-nhl-player-poll-reveals-player-most-punchable-face-always-hated-guy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:30:53+00:00

Florida Panthers forward Nick Cousins was voted NHL player &quot;whose face you most want to punch,&quot; according to The Athletic&apos;s anonymous player poll.

## Biden sanctions Israeli settlers in West Bank after shooting of US teen
 - [https://www.foxnews.com/politics/biden-sanctions-israeli-settlers-west-bank-shooting-us-teen](https://www.foxnews.com/politics/biden-sanctions-israeli-settlers-west-bank-shooting-us-teen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:21:20+00:00

President Biden imposed sanctions on Israeli settlers in the West Bank after the fatal shooting of 17-year-old Abdel Jabbar, a U.S. citizen visiting the area.

## British lawmaker to step down over alleged abuse, death threats for pro-Israel rhetoric
 - [https://www.foxnews.com/world/british-lawmaker-step-down-alleged-abuse-death-threats-pro-israel-rhetoric](https://www.foxnews.com/world/british-lawmaker-step-down-alleged-abuse-death-threats-pro-israel-rhetoric)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:20:38+00:00

Conservative British lawmaker Mike Freer announced Thursday his plans to step down from Parliament when this year&apos;s election is called.

## Chinese father, mistress executed after throwing toddlers out of high-rise apartment window: report
 - [https://www.foxnews.com/world/chinese-father-mistress-executed-throwing-toddlers-high-rise-apartment-window-report](https://www.foxnews.com/world/chinese-father-mistress-executed-throwing-toddlers-high-rise-apartment-window-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:15:41+00:00

A Chinese couple have been executed after the father was found guilty of throwing his toddlers out of a high-rise apartment building, reports say.

## Curtis Sliwa slams NYC mayor for shocking migrant attack on NYPD
 - [https://www.foxnews.com/us/curtis-sliwa-slams-nyc-mayor-shocking-migrant-attack-nypd](https://www.foxnews.com/us/curtis-sliwa-slams-nyc-mayor-shocking-migrant-attack-nypd)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:09:20+00:00

Guardian Angels founder Curtis Sliwa has slammed NYC Mayor Eric Adams, saying his handling of the migrant crisis and his approach to policing led the NYPD being attacked Saturday

## Rep. Cori Bush defends hiring husband amid DOJ probe, says it was tough to find reliable security
 - [https://www.foxnews.com/media/rep-cori-bush-defends-hiring-husband-amid-doj-probe-says-tough-find-reliable-security](https://www.foxnews.com/media/rep-cori-bush-defends-hiring-husband-amid-doj-probe-says-tough-find-reliable-security)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T19:01:37+00:00

Rep. Cori Bush joined MSNBC’s “The ReidOut&quot; with Joy Reid on Wednesday for a friendly interview where she defended hiring her husband, Cortney Merritts, as security.

## US Army denies request to return remains of Native American boys who died at Pennsylvania boarding school
 - [https://www.foxnews.com/us/us-army-denies-request-return-remains-native-american-boys-died-pennsylvania-boarding-school](https://www.foxnews.com/us/us-army-denies-request-return-remains-native-american-boys-died-pennsylvania-boarding-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:55:31+00:00

Two Native American boys from Nebraska died at a Pennsylvania boarding school over a century ago. Their tribe is seeking the boys&apos; remains, but the Army has denied their request.

## Illinois police K-9 fatally shot while chasing fleeing suspect
 - [https://www.foxnews.com/us/illinois-police-k9-fatally-shot-while-chasing-fleeing-suspect](https://www.foxnews.com/us/illinois-police-k9-fatally-shot-while-chasing-fleeing-suspect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:52:35+00:00

Rockford police K-9 Nyx was shot and killed while chasing a suspect wanted in connection to a domestic situation on Sunday, authorities said.

## ICE arrests more than 100 illegal immigrants with child sex charges in 25 US cities
 - [https://www.foxnews.com/us/ice-arrests-more-than-100-illegal-immigrants-child-sex-charges-25-us-cities](https://www.foxnews.com/us/ice-arrests-more-than-100-illegal-immigrants-child-sex-charges-25-us-cities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:41:39+00:00

U.S. Immigration and Customs Enforcement agents arrested 171 unlawfully present noncitizens in a major enforcement action spanning 25 U.S. cities, officials said.

## Nikki Haley says Texas can secede from the United States: 'that's their decision to make'
 - [https://www.foxnews.com/politics/nikki-haley-says-texas-can-secede-from-the-united-states-thats-their-decision-to-make](https://www.foxnews.com/politics/nikki-haley-says-texas-can-secede-from-the-united-states-thats-their-decision-to-make)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:31:43+00:00

Former South Carolina Gov. Nikki Haley stumbled through a question about whether the state of Texas as a right to secede from the United States and claimed that it is &quot;their decision to make.&quot;

## Pepper spray used on Kentucky juveniles nearly 74 times more than in adult federal prisons, report finds
 - [https://www.foxnews.com/politics/pepper-spray-used-kentucky-juveniles-nearly-74-times-more-adult-federal-prisons-report-finds](https://www.foxnews.com/politics/pepper-spray-used-kentucky-juveniles-nearly-74-times-more-adult-federal-prisons-report-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:28:07+00:00

A report from Kentucky state Auditor Allison Ball found that the state&apos;s juvenile justice system lacks clear guidelines regarding the use of force, among other problems.

## 'Farmer Wants a Wife': New crop in search of love as hit reality show returns
 - [https://www.foxnews.com/media/farmer-wants-wife-new-crop-search-love-hit-reality-show-returns](https://www.foxnews.com/media/farmer-wants-wife-new-crop-search-love-hit-reality-show-returns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:25:42+00:00

Four farmers search for a city girl to ride off into the sunset with on season two of &quot;Farmer Wants a Wife,&quot; premiering Feb. 1 at 9 p.m. ET on FOX.

## Man dies after cooking and eating highly poisonous pufferfish
 - [https://www.foxnews.com/world/man-dies-cooking-eating-highly-poisonous-pufferfish](https://www.foxnews.com/world/man-dies-cooking-eating-highly-poisonous-pufferfish)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:23:37+00:00

A 46-year-old Brazilian man has died in agony after he failed to recover from eating a poisonous pufferfish over Christmas. The fish has enough poison to kill 30 humans.

## New Jersey denies beach town's request to build erosion protection structure
 - [https://www.foxnews.com/us/new-jersey-denies-beach-towns-request-build-erosion-protection-structure](https://www.foxnews.com/us/new-jersey-denies-beach-towns-request-build-erosion-protection-structure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:17:24+00:00

The state of New Jersey has refused permission for North Wildwood, a shore town whose sand dunes have been significantly eroded by storms, to build a bulkhead to protect itself.

## Kansas City Chiefs fans' deaths: John Walsh warns drug dealers 'putting fentanyl in everything'
 - [https://www.foxnews.com/us/kansas-city-chiefs-fans-deaths-john-walsh-warns-drug-dealers-putting-fentanyl-everything](https://www.foxnews.com/us/kansas-city-chiefs-fans-deaths-john-walsh-warns-drug-dealers-putting-fentanyl-everything)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:09:36+00:00

&quot;America&apos;s Most Wanted&quot; host John Walsh said the deaths of three Kansas City Chiefs fans were likely caused by &quot;party drugs&quot; but said police are “working to get the story straight.&quot;

## Indiana lawmakers forge ahead with plan to make child care more affordable
 - [https://www.foxnews.com/politics/indiana-lawmakers-forge-ahead-plan-make-child-care-more-affordable](https://www.foxnews.com/politics/indiana-lawmakers-forge-ahead-plan-make-child-care-more-affordable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:07:27+00:00

Indiana lawmakers are progressing with plans to address the availability and affordability of child care, with measures aimed at expanding access to subsidies.

## Record label plans to drop Pink Floyd co-founder Roger Waters following accusations of antisemitism: Report
 - [https://www.foxnews.com/media/record-label-drops-pink-floyd-co-founder-roger-water-anti-israel-rhetoric-recent-months-report](https://www.foxnews.com/media/record-label-drops-pink-floyd-co-founder-roger-water-anti-israel-rhetoric-recent-months-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T18:00:21+00:00

The musician has been accused of antisemitism in multiple instances in recent years and previously claimed Russia&apos;s invasion of Ukraine was &quot;not unprovoked.&quot;

## 'Squad' Democrat accuses Walgreens of racism for leaving Boston neighborhood: 'Shame on you'
 - [https://www.foxnews.com/media/squad-democrat-accuses-walgreens-racism-leaving-boston-neighborhood-shame](https://www.foxnews.com/media/squad-democrat-accuses-walgreens-racism-leaving-boston-neighborhood-shame)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:59:35+00:00

Rep. Ayanna Pressley, D-Mass., slammed pharmacy giant Walgreens for closing a store in a low-income minority neighborhood, accusing the retailer of racial discrimination.

## Maine lobsterman hears mysterious cries from the water that lead to miracle rescue
 - [https://www.foxnews.com/us/maine-lobsterman-hears-mysterious-cries-water-leads-miracle-rescue](https://www.foxnews.com/us/maine-lobsterman-hears-mysterious-cries-water-leads-miracle-rescue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:53:54+00:00

A small boat capsized off the coast of Maine, and a man&apos;s cries for help were heard by a lobsterman, who called for assistance in the search.

## Chiefs' Justin Reid argues Patrick Mahomes is league's GOAT: 'Probably the best player in NFL history'
 - [https://www.foxnews.com/sports/chiefs-justin-reid-argues-patrick-mahomes-leagues-goat-probably-best-player-nfl-history](https://www.foxnews.com/sports/chiefs-justin-reid-argues-patrick-mahomes-leagues-goat-probably-best-player-nfl-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:52:33+00:00

Chiefs safety Justin Reid recently prompted shirts lauding his defensive coordinator. He is now he is now directing praise toward Kansas City&apos;s star quarterback.

## California government introduces nation's first series of reparations bills, after years of deliberating
 - [https://www.foxnews.com/media/california-government-introduces-nations-first-series-reparations-bills-after-years-deliberating](https://www.foxnews.com/media/california-government-introduces-nations-first-series-reparations-bills-after-years-deliberating)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:52:21+00:00

California just became the first state in the nation to produce a legislative package seeking reparations for descendants of African Americans in the state.

## USWNT star Lindsey Horan takes issue with American fans' criticism over her play: 'Most of them aren't smart'
 - [https://www.foxnews.com/sports/uswnt-star-lindsey-horan-takes-issue-american-fans-criticism-her-play-most-them-arent-smart](https://www.foxnews.com/sports/uswnt-star-lindsey-horan-takes-issue-american-fans-criticism-her-play-most-them-arent-smart)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:49:01+00:00

Lindsey Horan, a captain for the U.S. women&apos;s soccer team, took issue with the scrutiny she receives from the American fan base about her style of play.

## Biden repeats dubious claim about son's death in call to fallen service member's family: 'The nerve'
 - [https://www.foxnews.com/politics/biden-repeats-claim-sons-death-call-fallen-service-members-family-nerve](https://www.foxnews.com/politics/biden-repeats-claim-sons-death-call-fallen-service-members-family-nerve)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:38:11+00:00

President Biden repeated a dubious claim about the death of his son during a call with the parents of a U.S. service member who was recently killed in an attack on a base in Jordan.

## Comedian Larry David crashes NBC'S 'Today' set to beat up Elmo: 'Somebody had to do it'
 - [https://www.foxnews.com/media/comedian-larry-david-walks-nbc-set-beat-up-elmo-somebody-had-do-it](https://www.foxnews.com/media/comedian-larry-david-walks-nbc-set-beat-up-elmo-somebody-had-do-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:36:45+00:00

Larry David made a surprise appearance during NBC&apos;s &quot;Today&quot; show segment with Elmo on Thursday to attack the Sesame Street character, shocking the co-anchors.

## Philadelphia police capture man accused of taking suspect's weapon after shooting
 - [https://www.foxnews.com/us/philadelphia-police-capture-man-accused-taking-suspects-weapon-shooting](https://www.foxnews.com/us/philadelphia-police-capture-man-accused-taking-suspects-weapon-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:36:24+00:00

A Philadelphia man has been arrested for allegedly tampering with evidence related to a shooting incident inside a store where a man was killed and a police officer injured.

## Maryland Gov. Moore and lawmakers propose more collaboration within juvenile justice system
 - [https://www.foxnews.com/politics/maryland-gov-moore-lawmakers-propose-more-collaboration-within-juvenile-justice-system](https://www.foxnews.com/politics/maryland-gov-moore-lawmakers-propose-more-collaboration-within-juvenile-justice-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:34:49+00:00

Key elements of Maryland lawmakers&apos; proposed juvenile justice system reforms are increased time on probation, new processes for cases involving firearms, and cooperation with police.

## UK citizen sentenced to prison for conspiring to procure high-powered microwave system from US for Iran
 - [https://www.foxnews.com/world/uk-citizen-sentenced-prison-conspiring-procure-high-powered-microwave-system-us-iran](https://www.foxnews.com/world/uk-citizen-sentenced-prison-conspiring-procure-high-powered-microwave-system-us-iran)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:34:15+00:00

Saber Fakih, 48, pleaded guilty to conspiring to procure high-powered microwave system and counter-drone system to Iran, the U.S. Attorney&apos;s Office announced Thursday.

## Social media erupts over Dem staffer not being charged for Capitol Hill sex tape scandal: 'Beyond parody'
 - [https://www.foxnews.com/politics/social-media-erupts-dem-staffer-not-being-charged-capitol-hill-sex-tape-scandal](https://www.foxnews.com/politics/social-media-erupts-dem-staffer-not-being-charged-capitol-hill-sex-tape-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:29:06+00:00

The decision announced on Thursday not to charge a Capitol Hill staffer who filmed a pornographic sex scene in a hearing room sparked outrage on social media.

## Stanley Aronoff, former Ohio Senate president, dies at 91
 - [https://www.foxnews.com/politics/stanley-aronoff-former-ohio-senate-president-dies-91](https://www.foxnews.com/politics/stanley-aronoff-former-ohio-senate-president-dies-91)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:21:03+00:00

Stanley Aronoff, a prominent Republican figure in Ohio politics, has died at 91. Aronoff served nearly four decades in the Ohio Legislature, officials say.

## Fatal Ohio crash prompts training, new safety features for school bus drivers
 - [https://www.foxnews.com/politics/fatal-ohio-crash-prompts-training-new-safety-features-school-bus-drivers](https://www.foxnews.com/politics/fatal-ohio-crash-prompts-training-new-safety-features-school-bus-drivers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:20:22+00:00

Republican Ohio Gov. Mike DeWine, responding to a fatal school bus crash, has presented recommendations from a task force aimed at enhancing school bus safety.

## Country star Chris Young addresses 'false accusations' following arrest at Nashville bar
 - [https://www.foxnews.com/entertainment/country-star-chris-young-addresses-false-accusations-following-arrest-nashville-bar](https://www.foxnews.com/entertainment/country-star-chris-young-addresses-false-accusations-following-arrest-nashville-bar)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:07:55+00:00

Chris Young addressed the &quot;false accusations&quot; he faced after being arrested at a Nashville bar. The charges brought against him were dismissed days later.

## Defense Sec. Austin apologized directly to Biden over hospitalization controversy: 'Did not handle this right'
 - [https://www.foxnews.com/politics/defense-sec-austin-apologized-directly-biden-hospitalization-controversy-did-not-handle-this-right](https://www.foxnews.com/politics/defense-sec-austin-apologized-directly-biden-hospitalization-controversy-did-not-handle-this-right)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T17:03:13+00:00

Defense Secretary Lloyd Austin said he apologized to President Biden for not notifying him right away about his prostate cancer diagnosis, treatment and hospitalization.

## 2 dead after boat carrying migrants capsizes near Puerto Rico
 - [https://www.foxnews.com/world/2-dead-boat-carrying-migrants-capsizes-puerto-rico](https://www.foxnews.com/world/2-dead-boat-carrying-migrants-capsizes-puerto-rico)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:53:21+00:00

Authorities are searching for potential survivors off Puerto Rico’s northwest coast after a crowded boat capsized, killing at least two people, officials say.

## UNRWA says it could shut down by end of February if funding 'remains suspended'
 - [https://www.foxnews.com/world/unrwa-could-shut-down-end-february-funding-remains-suspended](https://www.foxnews.com/world/unrwa-could-shut-down-end-february-funding-remains-suspended)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:50:04+00:00

The head of UNRWA announced the organization will “likely&quot; shut down by the end of February if funding remains suspended following terrorism allegations.

## Charlamagne presses Nikki Haley on slavery gaffe: ‘Did you feel stupid after?'
 - [https://www.foxnews.com/media/charlamagne-presses-nikki-haley-slavery-gaffe-did-you-feel-stupid-after](https://www.foxnews.com/media/charlamagne-presses-nikki-haley-slavery-gaffe-did-you-feel-stupid-after)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:47:46+00:00

Radio host Charlamagne Tha God called out GOP presidential candidate Nikki Haley for her statements on the history of slavery in an interview on his show.

## MLB great Gary Sheffield rips Hall of Fame voting process after missing out: 'A lot of it is politics'
 - [https://www.foxnews.com/sports/mlb-great-gary-sheffield-rips-hall-of-fame-voting-process-missing-out-politics](https://www.foxnews.com/sports/mlb-great-gary-sheffield-rips-hall-of-fame-voting-process-missing-out-politics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:42:44+00:00

Former MLB star outfielder Gary Sheffield ripped the Baseball Hall of Fame voting process a week after he missed out on making it to Cooperstown.

## Marijuana use linked to increased asthma risk in youth, says study: ‘Worrisome' health implications
 - [https://www.foxnews.com/health/marijuana-use-linked-increased-asthma-risk-youth-study-worrisome-health-implications](https://www.foxnews.com/health/marijuana-use-linked-increased-asthma-risk-youth-study-worrisome-health-implications)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:33:18+00:00

A new study published in the journal Preventive Medicine found that in states where marijuana is legal, the share of teens with asthma is slightly higher than in states where it remains illegal.

## Black faith leaders say Biden is bleeding Black votes over Israel-Hamas war: 'Administration has lost its way’
 - [https://www.foxnews.com/media/black-faith-leaders-biden-bleeding-black-votes-israel-hamas-war-administration-lost-way](https://www.foxnews.com/media/black-faith-leaders-biden-bleeding-black-votes-israel-hamas-war-administration-lost-way)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:32:12+00:00

Black faith leaders say young members of their parish may not vote for President Biden in the 2024 election because of his attitudes on the Israel-Hamas war.

## Brian Austin Green texted Luke Perry after his death: 'He's hiding somewhere'
 - [https://www.foxnews.com/entertainment/brian-austin-green-texted-luke-perry-after-death](https://www.foxnews.com/entertainment/brian-austin-green-texted-luke-perry-after-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:28:42+00:00

Brian Austin Green is admitting he texted late actor Luke Perry after his death, as he was in denial that his friend had passed away.

## Taylor Swift is the latest high-profile deepfake victim. Here's what lawmakers are doing to protect them.
 - [https://www.foxnews.com/us/what-lawmakers-doing-protect-deepfake-victims-taylor-swift](https://www.foxnews.com/us/what-lawmakers-doing-protect-deepfake-victims-taylor-swift)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:22:27+00:00

Lawmakers are trying to keep up with the evolving power of AI-generated content, like deepfakes. Taylor Swift is the latest person to fall victim to violent and pornographic deepfakes.

## Commanders to hire Dan Quinn as next head coach: reports
 - [https://www.foxnews.com/sports/commanders-hire-dan-quinn-next-head-coach](https://www.foxnews.com/sports/commanders-hire-dan-quinn-next-head-coach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:21:00+00:00

The Washington Commanders are reportedly set to hire Dan Quinn as their next head coach. He was the Dallas Cowboys&apos; defensive coordinator.

## Personnel at Camp Lejeune had 20% higher cancer risk than those elsewhere, study shows
 - [https://www.foxnews.com/us/personnel-camp-lejeune-had-20-higher-cancer-risk-than-those-elsewhere-study-shows](https://www.foxnews.com/us/personnel-camp-lejeune-had-20-higher-cancer-risk-than-those-elsewhere-study-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:20:12+00:00

One of the largest cancer risk research projects ever done has tied a 20% increase in risk of certain types of cancer to being stationed at Came Lejeune from 1975 to 1985.

## Texas police hunt woman accused of drugging, robbing men in string of incidents since 2022
 - [https://www.foxnews.com/us/texas-police-hunt-woman-accused-drugging-robbing-men-string-incidents-since-2022](https://www.foxnews.com/us/texas-police-hunt-woman-accused-drugging-robbing-men-string-incidents-since-2022)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:17:22+00:00

Austin, Texas, police are searching for a woman accused of drugging and robbing multiple men between January 2022 and December 2023. A reward is being offered for information.

## Australian police rescue 3-year-old stuck inside Hello Kitty claw machine
 - [https://www.foxnews.com/world/australian-police-rescue-3-year-old-stuck-hello-kitty-claw-machine](https://www.foxnews.com/world/australian-police-rescue-3-year-old-stuck-hello-kitty-claw-machine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:07:12+00:00

Police in Queensland, Australia, rescued a toddler who got stuck inside a claw machine full of toys at a shopping center over the weekend.

## Bryan Kohberger asks court for change of venue after delays in Idaho student murders trial
 - [https://www.foxnews.com/us/bryan-kohberger-asks-court-change-venue-after-delays-idaho-student-murders-trial](https://www.foxnews.com/us/bryan-kohberger-asks-court-change-venue-after-delays-idaho-student-murders-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T16:00:27+00:00

Bryan Kohberger&apos;s murder trial could be moved to another part of Idaho if Judge John Judge grants the defense&apos;s motion to change venue.

## Michael Jordan gifted NASCAR star Denny Hamlin's dad cigar with important message
 - [https://www.foxnews.com/sports/michael-jordan-gifted-nascar-star-denny-hamlins-dad-cigar-important-message](https://www.foxnews.com/sports/michael-jordan-gifted-nascar-star-denny-hamlins-dad-cigar-important-message)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:53:16+00:00

Denny Hamlin&apos;s father revealed in a Netflix episode that Michael Jordan gave him a cigar for when he and his son bring home a championship.

## US veteran seeks dismissal of criminal charge for subduing man who attacked Connecticut lawmaker
 - [https://www.foxnews.com/us/us-veteran-seeks-dismissal-criminal-charge-subduing-man-attacked-connecticut-lawmaker](https://www.foxnews.com/us/us-veteran-seeks-dismissal-criminal-charge-subduing-man-attacked-connecticut-lawmaker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:47:55+00:00

A military veteran who intervened to help Connecticut&apos;s first Muslim state representative, Maryam Khan, during an assault, is seeking to have his assault charge erased.

## Pro-Palestinian protesters disrupt traffic across DC
 - [https://www.foxnews.com/us/pro-palestinian-protesters-disrupt-traffic-dc](https://www.foxnews.com/us/pro-palestinian-protesters-disrupt-traffic-dc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:43:40+00:00

U.S. Capitol police blocked off streets to the Capitol in Washington, D.C., as pro-Palestinian protesters disrupted traffic during a march in the city.

## Tennessee Dem introduces bill for 'Thoughts and Prayers Tax' on firearm sales
 - [https://www.foxnews.com/politics/tennessee-dem-introduces-bill-thoughts-prayers-tax-firearm-sales](https://www.foxnews.com/politics/tennessee-dem-introduces-bill-thoughts-prayers-tax-firearm-sales)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:43:10+00:00

Democratic State Rep. Bo Mitchell proposed legislation that would impose a 15% &quot;thoughts and prayers&quot; tax on the retail sale of firearms in Tennessee.

## 59 Democrats vote with Republicans passing bill to deport illegal immigrants who committed DUIs
 - [https://www.foxnews.com/politics/59-democrats-vote-with-republicans-passing-bill-to-deport-illegal-immigrants-who-committed-duis](https://www.foxnews.com/politics/59-democrats-vote-with-republicans-passing-bill-to-deport-illegal-immigrants-who-committed-duis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:41:00+00:00

A bill to deport illegal immigrants found guilty of DUIs passed the House along bipartisan lines on Thursday.

## South Korea judge hands life sentence to 23-year-old man convicted of fatal rampage
 - [https://www.foxnews.com/world/south-korea-judge-hands-life-sentence-23-year-old-man-convicted-fatal-rampage](https://www.foxnews.com/world/south-korea-judge-hands-life-sentence-23-year-old-man-convicted-fatal-rampage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:40:49+00:00

A South Korean judge has convicted 23-year-old Choi Won-jong of murder for a stabbing rampage that killed two people and injured 12 others in Seongnam last year.

## Stacey Abrams' once-powerful voting rights group faces massive layoffs as it struggles with millions in debt
 - [https://www.foxnews.com/politics/stacey-abrams-voting-rights-group-massive-layoffs-struggles-millions-debt](https://www.foxnews.com/politics/stacey-abrams-voting-rights-group-massive-layoffs-struggles-millions-debt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:39:40+00:00

Stacey Abrams&apos; once-powerful voting rights group is being forced into massive layoffs after racking up millions in debt stemming from legal action.

## Lionel Messi's arrival in Miami proves MLS is no longer a 'retirement league,' star defender says
 - [https://www.foxnews.com/sports/lionel-messis-arrival-in-miami-proves-mls-no-longer-retirement-league-star-defender-says](https://www.foxnews.com/sports/lionel-messis-arrival-in-miami-proves-mls-no-longer-retirement-league-star-defender-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:38:33+00:00

Tim Parker, an MLS star on St. Louis City SC, believes the arrival of Lionel Messi and other international stars with Inter Miami proves it&apos;s no longer a &quot;retirement league&quot; to play in.

## Pro-life activist facing up to 11 years in prison: Peaceful protest 'makes you a felon' in Biden's DOJ
 - [https://www.foxnews.com/media/pro-life-activist-facing-11-years-prison-peaceful-protest-makes-felon-bidens-doj](https://www.foxnews.com/media/pro-life-activist-facing-11-years-prison-peaceful-protest-makes-felon-bidens-doj)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:38:01+00:00

A pro-life activist reacted to a jury finding him guilty of federal conspiracy and FACE Act violations for protesting at an abortion clinic entrance in 2021.

## Texas AG Ken Paxton sues 5 cities over marijuana amnesty policies, cites drug's reported links to 'psychosis'
 - [https://www.foxnews.com/politics/texas-ag-ken-paxton-sues-5-cities-marijuana-amnesty-policies-cites-drugs-reported-links-psychosis](https://www.foxnews.com/politics/texas-ag-ken-paxton-sues-5-cities-marijuana-amnesty-policies-cites-drugs-reported-links-psychosis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:37:24+00:00

Texas AG Ken Paxton is suing &quot;pro-crime extremists&quot; in Austin, Denton, San Marcos, Killeen and Elgin for enacting policies against marijuana enforcement.

## Meghan Markle, Prince Harry demand change to reduce cyberbullying: 'We all want to feel safe'
 - [https://www.foxnews.com/entertainment/meghan-markle-prince-harry-demand-change-reduce-cyberbullying](https://www.foxnews.com/entertainment/meghan-markle-prince-harry-demand-change-reduce-cyberbullying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:34:20+00:00

Prince Harry and Meghan Markle released a new video on their Archewell site, taking a stand in the fight against cyberbullying following a Senate hearing on the topic.

## Florida Gov. Ron DeSantis to send hundreds of National Guard troops to assist Gov. Abbott at southern border
 - [https://www.foxnews.com/politics/florida-gov-ron-desantis-to-send-hundreds-of-national-guard-troops-to-assist-gov-abbott-at-southern-border](https://www.foxnews.com/politics/florida-gov-ron-desantis-to-send-hundreds-of-national-guard-troops-to-assist-gov-abbott-at-southern-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:29:16+00:00

Florida Gov. Ron DeSantis announced on Thursday that he is sending hundreds of National Guard troops to the southern border to assist Texas Gov. Greg Abbott&apos;s efforts.

## Lionel Messi's arrival in Miami proves MLS is no longer a 'retirement league,' star goalie says
 - [https://www.foxnews.com/sports/lionel-messis-arrival-in-miami-proves-mls-is-no-longer-a-retirement-league-star-goalie-says](https://www.foxnews.com/sports/lionel-messis-arrival-in-miami-proves-mls-is-no-longer-a-retirement-league-star-goalie-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:27:40+00:00

Tim Parker, an MLS star on St. Louis City SC, believes the arrival of Lionel Messi and other international stars with Inter Miami proves it&apos;s no longer a &quot;retirement league&quot; to play in.

## Indonesia’s top security minister resigns from Cabinet before this month's election
 - [https://www.foxnews.com/world/indonesias-top-security-minister-resigns-cabinet-months-election](https://www.foxnews.com/world/indonesias-top-security-minister-resigns-cabinet-months-election)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:23:31+00:00

Indonesia&apos;s top security minister, Mohammad Mahfud M.D., has announced his resignation from the Cabinet to focus on his vice presidential bid in this month&apos;s election.

## Biden's top super PAC receives millions in new dark money funds, filings show
 - [https://www.foxnews.com/politics/bidens-top-super-pac-receives-millions-new-dark-money-funds-filings-show](https://www.foxnews.com/politics/bidens-top-super-pac-receives-millions-new-dark-money-funds-filings-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:21:16+00:00

President Biden&apos;s main outside super PAC, Future Forward, received an $8 million donation from its dark money nonprofit. Biden is set to benefit from much more in anonymous donations.

## Brittany Mahomes shares defiant message after latest scrutiny: 'Stay bothered'
 - [https://www.foxnews.com/sports/brittany-mahomes-shares-defiant-message-latest-scrutiny-stay-bothered](https://www.foxnews.com/sports/brittany-mahomes-shares-defiant-message-latest-scrutiny-stay-bothered)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:15:42+00:00

Brittany Mahomes, the wife of Kansas City Chiefs star Patrick Mahomes, came under fire over the weekend but she shared a defiant post on Wednesday.

## Virginia bill to expand revenge porn law advances
 - [https://www.foxnews.com/politics/virginia-bill-expand-revenge-porn-law-advances](https://www.foxnews.com/politics/virginia-bill-expand-revenge-porn-law-advances)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:12:38+00:00

A bill that would expand what type of material falls subject to Virginia&apos;s revenge porn law is making its way through the VA House, backed by former candidate Susanna Gibson.

## Iran manufactured the drone that killed 3 US soldiers in Jordan, US official says
 - [https://www.foxnews.com/world/iran-manufactured-the-drone-killed-3-us-soldiers-jordan-us-official-says](https://www.foxnews.com/world/iran-manufactured-the-drone-killed-3-us-soldiers-jordan-us-official-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:08:09+00:00

The drone used to kill three U.S. soldiers and injure 40 more at a U.S. military base in Jordan was manufactured by Iran, Fox News has confirmed.

## Haley trails Trump in home state of South Carolina ahead of state's primary election: poll
 - [https://www.foxnews.com/politics/haley-trails-trump-home-state-south-carolina-ahead-states-primary-election-poll](https://www.foxnews.com/politics/haley-trails-trump-home-state-south-carolina-ahead-states-primary-election-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T15:01:48+00:00

Former President Donald Trump leads former U.N. Ambassador Nikki Haley in her home state of South Carolina ahead of the state&apos;s priomary election on Feb. 24.

## Michigan Arabs and Muslim community work to beat Biden in 2024 race: Biden 'thinks we're bluffing'
 - [https://www.foxnews.com/media/michigan-arabs-muslim-community-work-beat-biden-2024-race-biden-thinks-were-bluffing](https://www.foxnews.com/media/michigan-arabs-muslim-community-work-beat-biden-2024-race-biden-thinks-were-bluffing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:59:13+00:00

Arabs and Muslims in Michigan are working to beat President Biden in one of the most important swing states in the country, per a recent report.

## Opossum 'porch pirate' steals box of 15-year-old's birthday cookies, video shows
 - [https://www.foxnews.com/us/opossum-porch-pirate-steals-box-15-year-olds-birthday-cookies-video-shows](https://www.foxnews.com/us/opossum-porch-pirate-steals-box-15-year-olds-birthday-cookies-video-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:41:32+00:00

Authorities in Texas have released a video showing an opossum “porch pirate&quot; stealing a box of birthday cookies from the front porch of a 15-year-old&apos;s home.

## Senate sex tape: Capitol Police decline to press charges
 - [https://www.foxnews.com/politics/senate-sex-tape-capitol-police-decline-press-charges](https://www.foxnews.com/politics/senate-sex-tape-capitol-police-decline-press-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:40:04+00:00

U.S. Capitol Police say they aren&apos;t filing charges after a sex video was filmed inside the Hart Senate Office Building in December 2023.

## NBA's 65-game rule comes under fire amid stars' injuries: 'Quite bulls---'
 - [https://www.foxnews.com/sports/nbas-65-game-rule-comes-under-fire-amid-stars-injuries-bullst](https://www.foxnews.com/sports/nbas-65-game-rule-comes-under-fire-amid-stars-injuries-bullst)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:38:51+00:00

The NBA&apos;s 65-game rule came under fire over the last few days as Philadelphia 76ers star Joel Embiid and Indiana Pacers guard Tyrese Haliburton suffered injuries.

## Illegal migrant flips middle fingers after being charged with attacking NYPD in Times Square
 - [https://www.foxnews.com/us/illegal-migrant-flips-middle-fingers-charged-attacking-nypd-times-square](https://www.foxnews.com/us/illegal-migrant-flips-middle-fingers-charged-attacking-nypd-times-square)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:34:42+00:00

An illegal immigrant who was arrested for taking part in a violent mob attack on two NYPD officers flipped the bird at awaiting reporters Wednesday.

## EU must do more to stop Red Sea attacks, says foreign minister: 'Just striking the Houthis won't do enough'
 - [https://www.foxnews.com/world/eu-must-do-more-stop-red-sea-attacks-foreign-minister-just-striking-houthis-wont-do-enough](https://www.foxnews.com/world/eu-must-do-more-stop-red-sea-attacks-foreign-minister-just-striking-houthis-wont-do-enough)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:33:42+00:00

Yemeni Foreign Minister Ahmed Awad bin Mubarak said the European Union&apos;s strategy has been &quot;wrong&quot; and that it needs to increase pressure to stop attacks in the Red Sea.

## Indiana lawmaker flashes holstered gun to students protesting for gun control in state Capitol
 - [https://www.foxnews.com/politics/indiana-lawmaker-flashes-holstered-gun-students-protesting-gun-control-state-capitol](https://www.foxnews.com/politics/indiana-lawmaker-flashes-holstered-gun-students-protesting-gun-control-state-capitol)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:29:41+00:00

Indiana State Rep. Jim Lucas revealed his holstered firearm to a group of students advocating for gun control in the state&apos;s Capitol this week.

## Drought emergency grips northeast Spain as water reservoirs plummet
 - [https://www.foxnews.com/world/drought-emergency-grips-northeast-spain-water-reservoirs-plummet](https://www.foxnews.com/world/drought-emergency-grips-northeast-spain-water-reservoirs-plummet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:27:45+00:00

In Spain, a severe drought has triggered an emergency declaration due to historically low reservoir levels, and smaller towns are facing significant challenges.

## Kentucky House clears measure for moment of silence at start of school day
 - [https://www.foxnews.com/politics/kentucky-house-clears-measure-moment-silence-start-school-day](https://www.foxnews.com/politics/kentucky-house-clears-measure-moment-silence-start-school-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:27:02+00:00

The Kentucky House easily passed a bill that would instruct public schools to begin the school day with a short period of silent reflection. The bill now moves to the Senate.

## Russia-friendly party calls for government resignation through protest in Moldova's capital
 - [https://www.foxnews.com/world/russia-friendly-party-calls-government-resignation-protest-moldovas-capital](https://www.foxnews.com/world/russia-friendly-party-calls-government-resignation-protest-moldovas-capital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:16:05+00:00

In Moldova, thousands affiliated with the Russia-friendly Revival Party protested outside the parliament on Thursday, demanding the resignation of the pro-Western government.

## Philadelphia DA accuses 3 retired police detectives of lying under oath in 1991 murder case
 - [https://www.foxnews.com/us/philadelphia-da-accuses-3-retired-police-detectives-lying-oath-1991-murder-case](https://www.foxnews.com/us/philadelphia-da-accuses-3-retired-police-detectives-lying-oath-1991-murder-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:15:04+00:00

Three retired Philadelphia police detectives are accused of fabricating evidence in a 1991 rape and murder case that led to the wrongful conviction of Anthony Wright.

## South Dakota man takes plea deal in 2013 death of girlfriend, avoiding murder charge
 - [https://www.foxnews.com/us/south-dakota-man-takes-plea-deal-2013-death-girlfriend-avoiding-murder-charge](https://www.foxnews.com/us/south-dakota-man-takes-plea-deal-2013-death-girlfriend-avoiding-murder-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:13:40+00:00

After more than a decade since Meshell Will was found dead in the Black Hills of South Dakota, her boyfriend, Richard Schmitz, accepted a plea deal a day before his trial.

## Judge dismisses Trump's lawsuit alleging infamous dossier and its 'scandalous claims' damaged his reputation
 - [https://www.foxnews.com/world/judge-dismisses-trumps-lawsuit-alleging-infamous-dossier-scandalous-claims-damaged-reputation](https://www.foxnews.com/world/judge-dismisses-trumps-lawsuit-alleging-infamous-dossier-scandalous-claims-damaged-reputation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:09:20+00:00

Judge Karen Steyn dismissed the lawsuit Trump filed against Orbis Business Intelligence, a company founded by Christopher Steele, the former British spy who created the dossier in 2016.

## 22 first-year essentials to grab during Amazon's February Baby Sale
 - [https://www.foxnews.com/lifestyle/amazon-baby-sale-february](https://www.foxnews.com/lifestyle/amazon-baby-sale-february)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T14:01:03+00:00

Amazon&apos;s Baby Sale will run from February 1 through the end of the month. It is a once-a-year opportunity to save and stock up on all things baby from top brands such as Graco, Owlet, Evenflo and more.

## Bankrupt West Virginia university closes, construction firm owner buys campus
 - [https://www.foxnews.com/us/bankrupt-west-virginia-university-closes-construction-firm-owner-buys-campus](https://www.foxnews.com/us/bankrupt-west-virginia-university-closes-construction-firm-owner-buys-campus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:56:37+00:00

Alderson Broaddus University closed after having its ability to award degrees revoked and declaring bankruptcy. Craig G. Phillips, owner of CGP Construction, bought the campus.

## Georgia Gov. Kemp signs bill officially defining antisemitism in state law
 - [https://www.foxnews.com/politics/georgia-gov-kemp-signs-bill-officially-defining-antisemitism-state-law](https://www.foxnews.com/politics/georgia-gov-kemp-signs-bill-officially-defining-antisemitism-state-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:56:34+00:00

Republican governor of Georgia Brian Kemp officially defined antisemitism in Georgia state law. The bill uses the International Holocaust Remembrance Alliance&apos;s definition.

## Kelly Clarkson's weight loss was motivated by being pre-diabetic: 'I was a tiny bit overweight'
 - [https://www.foxnews.com/entertainment/kelly-clarksons-weight-loss-motivated-being-pre-diabetic](https://www.foxnews.com/entertainment/kelly-clarksons-weight-loss-motivated-being-pre-diabetic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:48:45+00:00

Kelly Clarkson is not afraid to talk about her weight loss, admitting during a recent episode of &quot;The Kelly Clarkson Show&quot; that she was pre-diabetic before changing her lifestyle.

## Young, Black conservative draws critics for opposing DEI on popular podcast, quoting MLK: 'Neoracists'
 - [https://www.foxnews.com/media/young-black-conservative-draws-critics-opposing-dei-popular-podcast-quoting-mlk-neoracists](https://www.foxnews.com/media/young-black-conservative-draws-critics-opposing-dei-popular-podcast-quoting-mlk-neoracists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:41:51+00:00

Author Coleman Hughes, a rising Black conservative, has drawn critics for his support of a colorblind society and of Dr. Martin Luther King Jr.&apos;s vision of equality.

## Chiefs lose Charles Omenihu to torn ACL ahead of Super Bowl LVIII: reports
 - [https://www.foxnews.com/sports/chiefs-lose-charles-omenihu-torn-acl-ahead-super-bowl-lviii-reports](https://www.foxnews.com/sports/chiefs-lose-charles-omenihu-torn-acl-ahead-super-bowl-lviii-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:35:10+00:00

Kansas City Chiefs defensive end Charles Omenihu suffered a torn ACL in the AFC Championship and will be unable to play in Super Bowl LVIII, according to multiple reports.

## Biden is running out of time on taming Iran as failure to do so could prove catastrophic
 - [https://www.foxnews.com/opinion/biden-running-out-time-taming-iran-failure-could-prove-catastrophic](https://www.foxnews.com/opinion/biden-running-out-time-taming-iran-failure-could-prove-catastrophic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:24:36+00:00

Driven by confidence in its soon to become viable nuclear deterrent and substantial missile arsenal, Iran is postured to escalate war on the U.S. President Biden must act decisively now.

## Maine investigation commission to hear testimonies from family members of Lewiston mass shooting victims
 - [https://www.foxnews.com/us/maine-investigation-commission-hear-testimonies-family-members-lewiston-mass-shooting-victims](https://www.foxnews.com/us/maine-investigation-commission-hear-testimonies-family-members-lewiston-mass-shooting-victims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:23:35+00:00

An independent commission, formed to investigate the circumstances leading to Maine&apos;s deadliest mass shooting, is set to hear testimonies from family members of victims.

## Travis Kelce’s barber reveals what Taylor Swift thinks of Kansas City Chief boyfriend's electric haircut
 - [https://www.foxnews.com/lifestyle/travis-kelces-barber-taylor-swift-thinks-kansas-city-chiefs-electric-haircut](https://www.foxnews.com/lifestyle/travis-kelces-barber-taylor-swift-thinks-kansas-city-chiefs-electric-haircut)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:15:00+00:00

Taylor Swift has some thoughts about Travis Kelce&apos;s haircut. Patrick Regan, Kelce&apos;s barber, shared with Fox News Digital a step-by-step path for how to get Kelce&apos;s particular cut.

## Cori Bush's campaign pays $17,500 more to her husband, bringing his total to $120K, new filings show
 - [https://www.foxnews.com/politics/cori-bushs-campaign-pays-17500-more-to-her-husband-bringing-his-total-to-120k-new-filings-show](https://www.foxnews.com/politics/cori-bushs-campaign-pays-17500-more-to-her-husband-bringing-his-total-to-120k-new-filings-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:11:36+00:00

Cori Bush paid thousands of dollars more from her campaign&apos;s coffers to her husband in recent months, new filings show. The Justice Department is probing her campaign spending.

## 49ers' Brock Purdy '10th-best player on his team,' ex-NFL star Cam Newton says
 - [https://www.foxnews.com/sports/49ers-brock-purdy-10th-best-player-team-ex-nfl-star-cam-newton-says](https://www.foxnews.com/sports/49ers-brock-purdy-10th-best-player-team-ex-nfl-star-cam-newton-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:02:43+00:00

San Francisco 49ers quarterback Brock Purdy faced more &quot;game-manager&quot; slights from one-time NFL MVP Cam Newton ahead of the Super Bowl.

## European Union leaders seal $54 billion aid package for Ukraine after Hungary lifts veto threat
 - [https://www.foxnews.com/world/european-union-leaders-seal-54-billion-aid-package-ukraine-hungary-lifts-veto-threat](https://www.foxnews.com/world/european-union-leaders-seal-54-billion-aid-package-ukraine-hungary-lifts-veto-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T13:00:15+00:00

The leaders of the 27 European Union countries have reached a deal to provide Ukraine with a $54 billion support package, despite initial threats from Hungary to veto the move.

## India law enforcement clear suspected Chinese spy pigeon
 - [https://www.foxnews.com/world/india-law-enforcement-clear-suspected-chinese-spy-pigeon](https://www.foxnews.com/world/india-law-enforcement-clear-suspected-chinese-spy-pigeon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:59:35+00:00

An Indian police force detained a pigeon suspected of being a Chinese spy for eight months before finally releasing it into the wild. The bird was initially captured in Mumbai.

## Gianna Tulio, Ryan Blaney's fiancée, recalls NASCAR champ's massive Daytona wreck: 'I froze'
 - [https://www.foxnews.com/sports/gianna-tulio-ryan-blaneys-fiancee-recalls-nascar-champs-massive-daytona-wreck](https://www.foxnews.com/sports/gianna-tulio-ryan-blaneys-fiancee-recalls-nascar-champs-massive-daytona-wreck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:43:34+00:00

Ryan Blaney and his fiancée Gianna Tulio recalled the hard wreck he suffered in the Coke Zero Sugar 400 at Daytona in an episode of &quot;NASCAR: Full Speed.&quot;

## South Dakota Gov. Noem seeks to bolster Texas security efforts at US-Mexico border
 - [https://www.foxnews.com/politics/south-dakota-gov-noem-seeks-bolster-texas-security-efforts-us-mexico-border](https://www.foxnews.com/politics/south-dakota-gov-noem-seeks-bolster-texas-security-efforts-us-mexico-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:31:06+00:00

South Dakota Gov. Kristi Noem is considering increasing support for Texas&apos; efforts to address immigration at the U.S.-Mexico border, including sending razor wire.

## Netflix's live-action 'Last Airbender' showrunner explains rewriting character to be less 'sexist'
 - [https://www.foxnews.com/media/netflixs-live-action-last-airbender-showrunner-explains-rewriting-character-less-sexist](https://www.foxnews.com/media/netflixs-live-action-last-airbender-showrunner-explains-rewriting-character-less-sexist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:30:50+00:00

Netflix’s live-action “Avatar: The Last Airbender&quot; showrunner said that one of its characters was rewritten to be less “sexist&quot; than the portrayal in the animated series.

## Updated Kentucky budget with increased school bus funding advances to House
 - [https://www.foxnews.com/politics/updated-kentucky-budget-increased-school-bus-funding-advances-house](https://www.foxnews.com/politics/updated-kentucky-budget-increased-school-bus-funding-advances-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:27:39+00:00

Kentucky House Republicans have proposed an updated budget plan, one key provision of which is that the state would cover more of the costs of student transportation for K-12 schools.

## Nebraska lawmaker proposes bill aimed at simplifying process for removing names from referendum petitions
 - [https://www.foxnews.com/politics/nebraska-lawmaker-proposes-bill-aimed-simplifying-process-removing-names-referendum-petitions](https://www.foxnews.com/politics/nebraska-lawmaker-proposes-bill-aimed-simplifying-process-removing-names-referendum-petitions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:18:38+00:00

Nebraska Sen. Linehan, who pushed a law for private school scholarships, is now seeking to simplify the process of removing signatures from petitions against it.

## Rocky Mountain spotted fever (RMSF): Symptoms, treatment, and prevention
 - [https://www.foxnews.com/health/what-is-rocky-mountain-spotted-fever-signs-symptoms-and-treatment-for-the-tick-borne-disease](https://www.foxnews.com/health/what-is-rocky-mountain-spotted-fever-signs-symptoms-and-treatment-for-the-tick-borne-disease)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:17:26+00:00

Explore Rocky Mountain spotted fever&apos;s causes, treatment, symptoms, diagnostic challenges and effective prevention methods for this notable tick-borne illness.

## Judge refuses action against DeSantis over effort to remove Students for Justice in Palestine off campuses
 - [https://www.foxnews.com/politics/judge-refuses-action-desantis-effort-remove-students-justice-palestine-campuses](https://www.foxnews.com/politics/judge-refuses-action-desantis-effort-remove-students-justice-palestine-campuses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:15:26+00:00

A judge on Wednesday refused to take action against Florida Gov. Ron DeSantis over an order to remove Students for Justice in Palestine from campuses.

## Santa Clara's Jalen Benjamin ejected after striking Saint Mary's player in stomach
 - [https://www.foxnews.com/sports/santa-claras-jalen-benjamin-ejected-striking-saint-marys-player-stomach](https://www.foxnews.com/sports/santa-claras-jalen-benjamin-ejected-striking-saint-marys-player-stomach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:14:49+00:00

Santa Clara Broncos guard Jalen Benjamin was ejected from Wednesday night&apos;s game against Saint Mary&apos;s after striking a player in the stomach.

## EU agrees to new $54 billion aid package for Ukraine overcoming Hungary’s veto threat
 - [https://www.foxnews.com/world/eu-agrees-new-54-billion-aid-package-ukraine-overcoming-hungarys-veto-threat](https://www.foxnews.com/world/eu-agrees-new-54-billion-aid-package-ukraine-overcoming-hungarys-veto-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:12:19+00:00

The European Union has agreed on a €50 billion ($54 billion) financial aid package to Ukraine despite staunch objections from Hungary in December and in recent days

## 3 hospitalized, including children, in London 'corrosive substance' attack
 - [https://www.foxnews.com/world/3-hospitalized-including-children-london-corrosive-substance-attack](https://www.foxnews.com/world/3-hospitalized-including-children-london-corrosive-substance-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T12:09:56+00:00

Police in London have launched a manhunt for a male suspect behind a “corrosive substance&quot; attack that injured a woman and her daughters, ages 8 and 3.

## Oregon woman found guilty, insane after pushing 3-year-old child onto train tracks
 - [https://www.foxnews.com/us/oregon-woman-found-guilty-insane-pushing-3-year-old-child-train-tracks](https://www.foxnews.com/us/oregon-woman-found-guilty-insane-pushing-3-year-old-child-train-tracks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T11:54:04+00:00

Brianna Lace Workman will spend 10 years in psychiatric custody after being found guilty except for insanity in the shoving of a child onto train tracks.

## Louisiana Gov. Landry signals push for state to resume death row executions
 - [https://www.foxnews.com/politics/louisiana-gov-landry-signals-push-state-resume-death-row-executions](https://www.foxnews.com/politics/louisiana-gov-landry-signals-push-state-resume-death-row-executions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T11:53:14+00:00

Louisiana, having abstained from executions since 2010, faces a potential shift as a new conservative governor shows openness to resuming capital punishment.

## GREG GUTFELD: Havard's DEI chief has just been accused of 40 counts of plagiarism
 - [https://www.foxnews.com/opinion/greg-gutfeld-havard-dei-chief-40-counts-plagiarism](https://www.foxnews.com/opinion/greg-gutfeld-havard-dei-chief-40-counts-plagiarism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T04:27:09+00:00

&quot;Gutfeld!&quot; host Greg Gutfeld breaks down why DEI is &quot;illogical&quot; following another Harvard official facing accusations of plagiarism just after Harvard&apos;s former president Claudine Gay&apos;s resignation.

## White House does victory lap on its handling of East Palestine disaster despite never declaring emergency
 - [https://www.foxnews.com/politics/white-house-does-victory-lap-handling-east-palestine-disaster-despite-never-declaring-emergency](https://www.foxnews.com/politics/white-house-does-victory-lap-handling-east-palestine-disaster-despite-never-declaring-emergency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T04:10:07+00:00

The White House launched a media blitz Wednesday, touting its response to the February 2023 derailment of a train hauling toxic chemicals in East Palestine, Ohio.

## Colorado trans teen who plotted mass school shooting in violent 'schizophrenic' manifesto sentenced to 6 years
 - [https://www.foxnews.com/us/colorado-trans-teen-who-plotted-mass-school-shooting-violent-schizophrenic-manifesto-sentenced-years](https://www.foxnews.com/us/colorado-trans-teen-who-plotted-mass-school-shooting-violent-schizophrenic-manifesto-sentenced-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T04:01:18+00:00

A transgender student, William Whitworth, who identified as Lilly, has been sentenced to six years in prison for plotting school shootings last year in Colorado.

## JESSE WATTERS: Wake up and unshackle yourself from tech addiction
 - [https://www.foxnews.com/media/jesse-watters-wake-up-unshackle-yourself-tech-addiction](https://www.foxnews.com/media/jesse-watters-wake-up-unshackle-yourself-tech-addiction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T03:13:42+00:00

Fox News host Jesse Watters discusses a Senate hearing on the harms of social media on &apos;Jesse Watters Primetime.&apos;

## Federal court once again suspends bullfights in Mexico City, as activists and supporters lock horns
 - [https://www.foxnews.com/world/federal-court-suspends-bullfights-mexico-city-activists-supporters-lock-horns](https://www.foxnews.com/world/federal-court-suspends-bullfights-mexico-city-activists-supporters-lock-horns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T02:54:22+00:00

Bullfighting, only recently returned to Mexico City, was temporarily halted by a court injunction, as supporters and opponents clashed in the legal arena.

## SEAN HANNITY: The border crisis has reached every part of the country
 - [https://www.foxnews.com/media/sean-hannity-border-crisis-reached-every-part-country](https://www.foxnews.com/media/sean-hannity-border-crisis-reached-every-part-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T02:52:43+00:00

Fox News host Sean Hannity says the illegal immigrant crisis is &quot;wreaking havoc on our biggest cities and even small towns&quot; on &quot;Wednesday&apos;s &quot;Hannity.&quot;

## Two teens injured, 1 killed in shooting near Chicago high school
 - [https://www.foxnews.com/us/two-teens-injured-1-killed-shooting-near-chicago-high-school](https://www.foxnews.com/us/two-teens-injured-1-killed-shooting-near-chicago-high-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T02:34:09+00:00

Two teenagers were injured and one was killed in a shooting Wednesday afternoon outside a high school on Chicago&apos;s North Side, according to police.

## WATCH: New Jersey business owner saves nearly 100 cats by volunteering to climb up trees: 'Really touching'
 - [https://www.foxnews.com/lifestyle/watch-new-jersey-business-owner-saves-nearly-100-cats-volunteering-climb-trees-really-touching](https://www.foxnews.com/lifestyle/watch-new-jersey-business-owner-saves-nearly-100-cats-volunteering-climb-trees-really-touching)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T02:33:26+00:00

Tesla Tree Service owner Steven Murrow told Fox News Digital that he&apos;s saved nearly 100 cats since 2021 after he began offering to climb up trees to rescue them.

## ‘Squad’ Democrats Cori Bush and Rashida Tlaib vote against bill to ban Hamas terrorists from US
 - [https://www.foxnews.com/politics/squad-democrats-cori-bush-rashida-tlaib-vote-bill-ban-hamas-terrorists-us](https://www.foxnews.com/politics/squad-democrats-cori-bush-rashida-tlaib-vote-bill-ban-hamas-terrorists-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T02:13:35+00:00

Rep. Rashida Tlaib and Rep. Cori Bush voted against a bill barring additional Palestine Liberation Organization members from entering the U.S. on Wednesday.

## Danny Masterson incarcerated at maximum-security prison that housed Charles Manson
 - [https://www.foxnews.com/entertainment/danny-masterson-incarcerated-maximum-security-prison-housed-charles-manson](https://www.foxnews.com/entertainment/danny-masterson-incarcerated-maximum-security-prison-housed-charles-manson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T02:12:07+00:00

Danny Masterson was transferred to a maximum security facility in December after being found guilty of forcible rape in May. A jury was hung on a third charge.

## LAURA INGRAHAM: Trump remains the dominant figure in American politics
 - [https://www.foxnews.com/media/laura-ingraham-trump-dominant-figure-american-politics](https://www.foxnews.com/media/laura-ingraham-trump-dominant-figure-american-politics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T02:06:32+00:00

&quot;The Ingraham Angle&quot; host Laura Ingraham breaks down why former President Trump is leading President Biden after a new poll found the former president leading in seven key swing states.

## Flames face criticism over Dillon Dube statement citing mental health after sexual assault charge revelation
 - [https://www.foxnews.com/sports/flames-face-criticism-dillon-dube-statement-citing-mental-health-sexual-assault-charge-revelation](https://www.foxnews.com/sports/flames-face-criticism-dillon-dube-statement-citing-mental-health-sexual-assault-charge-revelation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T02:03:03+00:00

The Calgary Flames are facing intense criticism over their initial statement regarding Dillon Dube&apos;s leave of absence in which they cited mental health concerns.

## Idaho building collapses on Boise Airport property, 12 injured in 'catastrophic' incident
 - [https://www.foxnews.com/us/idaho-building-collapses-boise-airport-multiple-injuries-reported](https://www.foxnews.com/us/idaho-building-collapses-boise-airport-multiple-injuries-reported)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T02:01:33+00:00

A building reportedly collapsed in Boise, Idaho, on Wednesday, with multiple injuries reported.

## Tony Snell seeking return to NBA for ‘bigger purpose’: ‘It’s about my boys’
 - [https://www.foxnews.com/sports/tony-snell-seeking-return-nba-bigger-purpose-about-my-boys](https://www.foxnews.com/sports/tony-snell-seeking-return-nba-bigger-purpose-about-my-boys)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:58:22+00:00

NBA veteran Tony Snell is looking to join an NBA team&apos;s active roster by Friday and be signed for the rest of the season to be eligible for the union’s premium medical plan.

## Australian girl swings large snake several times to rescue pet guinea pig: video
 - [https://www.foxnews.com/lifestyle/australian-girl-swings-large-snake-several-times-rescue-pet-guinea-pig-video](https://www.foxnews.com/lifestyle/australian-girl-swings-large-snake-several-times-rescue-pet-guinea-pig-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:53:10+00:00

A 12-year-old girl from Australia rescued her pet guinea pig by grabbing hold of a snake looking to feast on the animal, and swinging it around several times.

## Heidi Klum's daughter found her 'sex closet' as a kid: 'I really had no idea what it was'
 - [https://www.foxnews.com/entertainment/heidi-klums-daughter-found-her-sex-closet-as-kid](https://www.foxnews.com/entertainment/heidi-klums-daughter-found-her-sex-closet-as-kid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:51:00+00:00

Heidi Klum&apos;s daughter explained that she found her supermodel mom&apos;s &quot;sex drawer&quot; when she was younger and went through it with her friends.

## Patrick Mahomes crashes Travis Kelce appearance on 'The Pat McAfee Show,' comments on Justin Tucker incident
 - [https://www.foxnews.com/sports/patrick-mahomes-crashes-travis-kelce-appearance-pat-mcafee-show-comments-justin-tucker-incident](https://www.foxnews.com/sports/patrick-mahomes-crashes-travis-kelce-appearance-pat-mcafee-show-comments-justin-tucker-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:50:22+00:00

Kansas City Chiefs quarterback Patrick Mahomes crashed Travis Kelce&apos;s interview on Wednesday and spoke on the Justin Tucker incident from last week&apos;s AFC Championship Game.

## Ravens' Odell Beckham Jr. told Lamar Jackson to run more in AFC title game: 'What the f--- goin’ on?'
 - [https://www.foxnews.com/sports/ravens-odell-beckham-jr-told-lamar-jackson-run-more-afc-title-game](https://www.foxnews.com/sports/ravens-odell-beckham-jr-told-lamar-jackson-run-more-afc-title-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:45:22+00:00

Baltimore Ravens wide receiver Odell Beckham Jr. was confused why quarterback Lamar Jackson didn&apos;t run more to start the AFC championship game and let him know it.

## California teen arrested in ‘swatting’ call on Florida mosque, may be connected to other incidents nationwide
 - [https://www.foxnews.com/us/california-teen-arrested-swatting-call-florida-mosque-may-be-connected-other-incidents-nationwide](https://www.foxnews.com/us/california-teen-arrested-swatting-call-florida-mosque-may-be-connected-other-incidents-nationwide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:42:05+00:00

A California teen was arrested in connection with a swatting call targeting a Florida mosque, and investigators believe he may be connected to more swatting incidents nationwide.

## Boston doctor found not guilty of lewd acts near 14-year-old on plane
 - [https://www.foxnews.com/us/boston-doctor-found-not-guilty-lewd-acts-14-year-old-plane](https://www.foxnews.com/us/boston-doctor-found-not-guilty-lewd-acts-14-year-old-plane)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:41:00+00:00

Dr. Sudipta Mohanty of Cambridge, Massachusetts, has been cleared of charges claiming he masturbated in the immediate vicinity of a 14-year-old girl on a 2022 Hawaiian Airlines flight.

## Pro-life protesters convicted of violating federal law for blocking abortion clinic door
 - [https://www.foxnews.com/us/pro-life-protesters-convicted-violating-federal-law-blocking-abortion-clinic-door](https://www.foxnews.com/us/pro-life-protesters-convicted-violating-federal-law-blocking-abortion-clinic-door)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:39:30+00:00

A Tennessee jury on Tuesday convicted six pro-life protesters of violating federal law by blocking the entrance to a Mt. Juliet abortion clinic during a 2021 demonstration.

## Tunisia wants to borrow billions from its central bank to address deficits. Experts call that risky
 - [https://www.foxnews.com/world/tunisia-wants-borrow-billions-central-bank-address-deficits-experts-call-risky](https://www.foxnews.com/world/tunisia-wants-borrow-billions-central-bank-address-deficits-experts-call-risky)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:36:27+00:00

Critics allege that Saied has sought to undermine Tunisia&apos;s institutions since assuming power, and argue that the move could hasten inflation.

## House passes $78 billion tax bill expanding child tax credit and boosting US manufacturing
 - [https://www.foxnews.com/politics/house-passes-78-billion-tax-bill-expanding-child-tax-credit-boosting-us-manufacturing](https://www.foxnews.com/politics/house-passes-78-billion-tax-bill-expanding-child-tax-credit-boosting-us-manufacturing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:33:42+00:00

The House of Representatives has passed a major bipartisan tax deal with new breaks for businesses as well as an expansion of the child tax credit.

## New Panthers coach Dave Canales details 'secret life' of pornography addiction, binge drinking in book
 - [https://www.foxnews.com/sports/new-panthers-coach-dave-canales-details-secret-life-pornography-addiction-binge-drinking-in-book](https://www.foxnews.com/sports/new-panthers-coach-dave-canales-details-secret-life-pornography-addiction-binge-drinking-in-book)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:33:27+00:00

Panthers new head coach Dave Canales had a &quot;secret life&quot; in his past that he and his wife wrote about in a co-authored book detailing pornography addiction, infidelity and more.

## Nevada and Colorado police solve 2 cold cases linked to the same man, 16 years apart
 - [https://www.foxnews.com/us/nevada-colorado-police-solve-cold-cases-linked-same-man-years-apart](https://www.foxnews.com/us/nevada-colorado-police-solve-cold-cases-linked-same-man-years-apart)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:29:53+00:00

The Las Vegas Metropolitan Police Department announced the closure of two cold cases after DNA advancements helped them and a Colorado agency link one man to both cases.

## Minnesota Supreme Court reverses conviction in real estate agent's 2019 killing
 - [https://www.foxnews.com/us/minnesota-supreme-court-reverses-conviction-real-estate-agents-2019-killing](https://www.foxnews.com/us/minnesota-supreme-court-reverses-conviction-real-estate-agents-2019-killing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:21:34+00:00

The Minnesota Supreme Court on Wednesday reversed murder and kidnapping convictions against Elsa Segura, who was charged in connection with the 2019 killing of Monique Baugh.

## Arizona launches partnership with PragerU to teach kids about America's 'rich history and values'
 - [https://www.foxnews.com/media/arizona-launches-partnership-prageru-teach-kids-americas-rich-history-values](https://www.foxnews.com/media/arizona-launches-partnership-prageru-teach-kids-americas-rich-history-values)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:21:12+00:00

Arizona’s Department of Education will partner with PragerU to use their materials about America’s “rich history and values&quot; in the classroom sof K-12 students.

## Denmark's Frederik X visits Poland in first trip abroad as king
 - [https://www.foxnews.com/world/denmarks-frederik-x-visits-poland-first-trip-abroad-king](https://www.foxnews.com/world/denmarks-frederik-x-visits-poland-first-trip-abroad-king)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:18:27+00:00

King Frederik X of Denmark made his first trip abroad Wednesday as the Scandinavian nation&apos;s monarch, arriving in Poland to discuss business and climate policy.

## Federal judge rejects Virginia school system's request to dismiss sex assault suit
 - [https://www.foxnews.com/us/federal-judge-rejects-virginia-school-systems-request-dismiss-sex-assault-suit](https://www.foxnews.com/us/federal-judge-rejects-virginia-school-systems-request-dismiss-sex-assault-suit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:16:53+00:00

A federal judge has rejected a request by Virginia&apos;s Fairfax County School Board to dismiss a lawsuit accusing it of indifference to a middle schooler&apos;s sexual abuse claims.

## Lions' Amon-Ra St. Brown says returning offensive coordinator Ben Johnson has 'unfinished business'
 - [https://www.foxnews.com/sports/lions-amon-ra-st-brown-says-returning-offensive-coordinator-ben-johnson-has-unfinished-business](https://www.foxnews.com/sports/lions-amon-ra-st-brown-says-returning-offensive-coordinator-ben-johnson-has-unfinished-business)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T01:02:09+00:00

After the Lions blew a 17-point led in the NFC title game, many assumed offensive coordinator Ben Johnson would leave Detroit to take a head coaching job.

## Newsom recalls seeing brazen theft, refuses photo and asks for manager when worker blames him: LEAKED VIDEO
 - [https://www.foxnews.com/politics/newsom-recalls-seeing-brazen-theft-refuses-photo-asks-manager-worker-blames-leaked-video](https://www.foxnews.com/politics/newsom-recalls-seeing-brazen-theft-refuses-photo-asks-manager-worker-blames-leaked-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T00:52:24+00:00

California Gov. Newsom said in a leaked video that his crime policies were blamed for a brazen shoplifting incident by a store employee

## Taylor Swift attending Grammy Awards without Travis Kelce
 - [https://www.foxnews.com/entertainment/taylor-swift-attending-grammy-awards-without-travis-kelce](https://www.foxnews.com/entertainment/taylor-swift-attending-grammy-awards-without-travis-kelce)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T00:48:23+00:00

Travis Kelce will not be joining Taylor Swift at the 2024 Grammy Awards this Sunday. The Kansas City Chiefs football star said he&apos;ll be traveling Feb. 4 for the Super Bowl.

## Ben Simmons injured in first game back from previous health issue
 - [https://www.foxnews.com/sports/ben-simmons-suffers-injury-first-game-back-previous-ailment](https://www.foxnews.com/sports/ben-simmons-suffers-injury-first-game-back-previous-ailment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T00:24:59+00:00

After missing the previous 38 games before his return Monday night, Ben Simmons left with another injury that will put him back on the bench.

## Ted Danson explains why a 'Cheers' reunion isn't likely despite a 'lovely' Emmy's bit
 - [https://www.foxnews.com/entertainment/ted-danson-explains-why-cheers-reunion-isnt-likely-despite-lovely-emmys-bit](https://www.foxnews.com/entertainment/ted-danson-explains-why-cheers-reunion-isnt-likely-despite-lovely-emmys-bit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T00:15:17+00:00

Ted Danson is explaining why he doesn&apos;t think a &quot;Cheers&quot; reunion would work, despite the cast recently reuniting at the Emmy Awards.

## US takes ‘self-defense’ strike against Houthi projectiles poised to launch at commercial ship in Red Sea
 - [https://www.foxnews.com/world/us-takes-self-defense-strike-houthi-projectiles-poised-launch-commercial-ship-red-sea](https://www.foxnews.com/world/us-takes-self-defense-strike-houthi-projectiles-poised-launch-commercial-ship-red-sea)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T00:09:01+00:00

The US has carried out a self-defense strike, targeting and destroying multiple projectiles that Houthi militants in Yemen were preparing to launch at commercial ships in the Red Sea.

## Chinese communists 'desperate to crush' religion, 'faith in God,' Republican representative warns
 - [https://www.foxnews.com/politics/chinese-communists-desperate-to-crush-religion-faith-in-god-republican-rep-warns](https://www.foxnews.com/politics/chinese-communists-desperate-to-crush-religion-faith-in-god-republican-rep-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2024-02-01T00:00:38+00:00

FIRST ON FOX: Rep. Mike Gallagher is expected to warn that the Chinese Communist Party is “desperate to crush religion&quot; and is using it “as a tool to control people&apos;s minds.&quot;

