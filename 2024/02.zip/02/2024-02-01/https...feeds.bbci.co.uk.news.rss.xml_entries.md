# Source:BBC, URL:https://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Hostages freed after being held for nine hours at P&G plant in Turkey
 - [https://www.bbc.co.uk/news/world-europe-68171878?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-68171878?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T22:41:44+00:00

An armed suspect is detained and seven people are freed from Proctor & Gamble's factory near Istanbul.

## Mainoo hits 97th-minute winner as Man Utd edge Wolves in classic
 - [https://www.bbc.co.uk/sport/football/68090233?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68090233?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T22:34:46+00:00

Kobbie Mainoo scores a sensational 97th-minute winner as Manchester United beat Wolverhampton Wanderers in a seven-goal thriller at Molineux

## West Ham United 1-1 Bournemouth: James Ward-Prowse rescues point after Kalvin Phillips error
 - [https://www.bbc.co.uk/sport/football/68090232?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68090232?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T21:48:53+00:00

James Ward-Prowse's second-half penalty spares Kalvin Phillips' blushes and rescues a Premier League point for West Ham against Bournemouth at London Stadium.

## Bristol stabbings: Four more charged over teenagers' deaths
 - [https://www.bbc.co.uk/news/uk-england-bristol-68175331?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-bristol-68175331?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T20:17:22+00:00

Two boys, aged 15 and 16, are charged with murder, and two men are charged with assisting an offender.

## Clapham attack: Police release image of suspect with 'significant injuries'
 - [https://www.bbc.co.uk/news/uk-68167793?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68167793?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T20:09:07+00:00

Abdul Shakoor Ezedi was last seen in north London, and police warn the public not to approach him.

## Lewis Hamilton: Mercedes driver will join Ferrari in 2025 on a multi-year deal
 - [https://www.bbc.co.uk/sport/formula1/68169534?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/68169534?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T19:39:56+00:00

Lewis Hamilton will leave Mercedes at the end of the 2024 season and join Ferrari on a multi-year deal in 2025.

## Palace sign teenage Blackburn midfielder Wharton for £18m
 - [https://www.bbc.co.uk/sport/football/68172882?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68172882?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T19:13:41+00:00

Crystal Palace sign midfielder Adam Wharton from Championship club Blackburn Rovers for an initial fee of £18m.

## US sanctions Israeli settlers over West Bank violence
 - [https://www.bbc.co.uk/news/world-us-canada-68173904?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68173904?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T18:36:31+00:00

The US president sanctions four Israeli settlers accused of attacking Palestinians.

## US and UK strikes fail to slow Houthi attacks
 - [https://www.bbc.co.uk/news/world-middle-east-68159939?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-68159939?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T18:16:26+00:00

BBC Verify analysis shows how Houthi tactics have changed, as commercial shipping traffic in the Red Sea halves.

## Stormont: Assembly to sit on Saturday as DUP boycott ends
 - [https://www.bbc.co.uk/news/uk-northern-ireland-68155422?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-68155422?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T18:10:36+00:00

Sir Jeffrey Donaldson has written to the speaker following the passage of legislation at Westminster.

## Armando Broja: Fulham close on loan deal for Chelsea striker
 - [https://www.bbc.co.uk/sport/football/68172542?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68172542?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T18:00:26+00:00

Fulham are on the verge of signing Chelsea striker Armando Broja on loan for the remainder of the season.

## Wilder criticises officials over perceived bias and 'eating a sandwich'
 - [https://www.bbc.co.uk/sport/football/68172818?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68172818?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T17:30:37+00:00

Sheffield United boss Chris Wilder says he has to speak up on behalf of the club about perceived bias against the Blades from match officials.

## West Ham transfer news: Pablo Fornals set to join Spanish side Real Betis for £6.8m
 - [https://www.bbc.co.uk/sport/football/68172772?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68172772?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T17:02:17+00:00

West Ham agree to sell Spanish midfielder Pablo Fornals to Real Betis for 8m euros (£6.8m) on transfer deadline day.

## On the trail of the escapee monkey in the Scottish Highlands
 - [https://www.bbc.co.uk/news/uk-scotland-68172696?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-68172696?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T16:45:51+00:00

A search involving drones has come to an end as Honshu the cheeky monkey is safely recaptured.

## 'France v Ireland the World Cup final everyone wanted' - Herring column
 - [https://www.bbc.co.uk/sport/rugby-union/68166214?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/68166214?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T16:18:46+00:00

In his first column for BBC Sport NI, Ireland hooker Rob Herring discusses missing the Six Nations opener with France, Antoine Dupont and doing the school run.

## Defence Secretary Lloyd Austin apologises for secretive hospital stay
 - [https://www.bbc.co.uk/news/world-us-canada-68171107?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68171107?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T16:08:23+00:00

"I should have told the President about my cancer diagnosis," says Lloyd Austin.

## India v England: 'Tourists have momentum - and expectation - before second Test'
 - [https://www.bbc.co.uk/sport/cricket/68159358?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/68159358?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T15:32:51+00:00

England are buoyant after their stunning win in the first Test in India, but success can bring its own dangers, writes Stephan Shemilt.

## US approves plan to strike Iranian targets in Syria and Iraq, officials say
 - [https://www.bbc.co.uk/news/world-us-canada-68171280?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68171280?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T15:22:17+00:00

The US is planning to strike Iranian targets in Syria and Iraq over a number of days, officials tell CBS News.

## Six Nations 2024: Ethan Roots and Fraser Dingwall to make England debuts against Italy
 - [https://www.bbc.co.uk/sport/rugby-union/68170248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/68170248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T15:19:09+00:00

Ethan Roots and Fraser Dingwall will make their England debuts against Italy in Rome on Saturday.

## Has Labour dropped its £28bn green investment plan?
 - [https://www.bbc.co.uk/news/uk-politics-68170566?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-68170566?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T15:16:48+00:00

The party's leadership is sending mixed messages on what was once their flagship election policy.

## Hate faced by MP Mike Freer is attack on democracy, says Downing Street
 - [https://www.bbc.co.uk/news/uk-politics-68167540?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-68167540?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T15:01:19+00:00

The justice minister is to stand down at the next election, saying he has had enough of threats to his safety.

## Six Nations 2024: Kyle Rowe starts for Scotland against Wales, with Blair Kinghorn injured
 - [https://www.bbc.co.uk/sport/rugby-union/68170556?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/68170556?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T14:32:02+00:00

Kyle Rowe makes his first Scotland start at full-back, with Blair Kinghorn missing through injury for the Six Nations opener in Wales.

## Catalonia: State of emergency declared as region faces worst ever drought
 - [https://www.bbc.co.uk/news/world-europe-68167942?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-68167942?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T14:24:30+00:00

Residents face a raft of restrictions on water use as the Spanish region faces its worst drought on record.

## Bank of England moving closer to interest rate cut
 - [https://www.bbc.co.uk/news/business-68164273?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-68164273?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T14:14:23+00:00

Rates are held at 5.25%, but the governor wants to see "more evidence" of a sustained fall in inflation.

## Greta Thunberg warned to move before arrest at protest, court told
 - [https://www.bbc.co.uk/news/uk-england-london-68166341?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-68166341?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T13:56:55+00:00

The Swedish climate activist appeared before magistrates in London after a protest in October.

## TikTok pulls Taylor Swift and The Weeknd's music
 - [https://www.bbc.co.uk/news/technology-68166028?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-68166028?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T13:51:20+00:00

It comes after a licensing rights row between the platform and the artists' record label, Universal.

## Lewis Hamilton on verge of shock Ferrari move
 - [https://www.bbc.co.uk/sport/formula1/68163799?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/68163799?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T13:50:53+00:00

Lewis Hamilton is poised for a shock move to Ferrari for the 2025 season, BBC Sport understands.

## Scottish secretary tells inquiry he deleted WhatsApps to 'free up storage'
 - [https://www.bbc.co.uk/news/uk-scotland-68165349?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-68165349?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T13:25:59+00:00

The Scottish secretary also claimed Nicola Sturgeon could "cry from one eye" in his evidence to the UK Covid Inquiry.

## Morgan Rogers: Aston Villa sign forward from Middlesbrough
 - [https://www.bbc.co.uk/sport/football/68154784?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68154784?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T13:11:50+00:00

Aston Villa complete the signing of forward Morgan Rogers from Championship club Middlesbrough in a deal reported to be about £15m.

## You Me At Six: Emo band to split after 20 years
 - [https://www.bbc.co.uk/news/newsbeat-68167150?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-68167150?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T12:52:32+00:00

Lead singer Josh Franceschi says their final tour will be a chance to "celebrate" with fans.

## Fireworks and egg throwing at EU farmer protest in Brussels
 - [https://www.bbc.co.uk/news/world-europe-68168498?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-68168498?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T12:43:18+00:00

Farmers from across the EU converge demand fewer regulations as European leaders meet for summit.

## Ukraine support package worth €50bn agreed by EU leaders
 - [https://www.bbc.co.uk/news/uk-68165971?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68165971?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T12:30:54+00:00

The agreement came earlier than expected, overcoming previous opposition from Hungary's Viktor Orban.

## Christopher Steele: UK High Court throws out Trump ex-spy dossier case
 - [https://www.bbc.co.uk/news/uk-68166050?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68166050?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T12:02:20+00:00

The former US president's lawsuit over salacious claims linking him to Moscow prostitutes fails in London.

## Six Nations 2023: Cameron Winnett wins first Wales cap against Scotland but George North out
 - [https://www.bbc.co.uk/sport/rugby-union/68081598?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/68081598?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T12:00:09+00:00

Cardiff full-back Cameron Winnett will make his Wales debut in the opening Six Nations game against Scotland on Saturday but centre George North misses out through injury.

## Escaped monkey caught after five days on loose
 - [https://www.bbc.co.uk/news/articles/cv2vp80k3n8o?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/cv2vp80k3n8o?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T11:51:22+00:00

The Japanese macaque got out of its enclosure on Sunday.

## Adidas says it plans to sell remaining Yeezy sneakers
 - [https://www.bbc.co.uk/news/business-68163180?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-68163180?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T11:50:51+00:00

The sportswear giant cut ties with Kanye West in 2022 after he made a series of antisemitic comments.

## Ex-Afghan special forces to have UK relocation claims re-examined
 - [https://www.bbc.co.uk/news/uk-68152923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68152923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T11:17:57+00:00

The elite unit was among those helping British citizens flee Afghanistan following the Taliban takeover in 2021.

## Conor Benn wants 'mega fight' with Devin Haney in UK
 - [https://www.bbc.co.uk/sport/boxing/68081148?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/68081148?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T10:58:16+00:00

Britain's Conor Benn wants a "mega fight" in the UK in April or May and has welcomed a bout against two-weight world champion Devin Haney.

## Could UK heatwaves be given names this summer?
 - [https://www.bbc.co.uk/weather/features/68160864?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/weather/features/68160864?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T10:42:21+00:00

With global temperatures rising and heatwaves becoming more intense, could naming them help awareness?

## Angiodema: Gene therapy blocks painful hereditary disorder
 - [https://www.bbc.co.uk/news/health-68164372?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-68164372?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T09:55:07+00:00

A single dose of gene therapy was enough to stop the painful swelling attacks caused by angiodema.

## 'I make less than minimum wage from running my post office'
 - [https://www.bbc.co.uk/news/business-68156239?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-68156239?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T09:45:35+00:00

Current postmasters tell the BBC of their daily struggles to keep their branches running.

## Rodrigo Ribeiro: Nottingham Forest sign Portugal U20 striker on loan from Sporting Lisbon
 - [https://www.bbc.co.uk/sport/football/68165634?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/68165634?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T09:44:55+00:00

Nottingham Forest sign Sporting Lisbon striker Rodrigo Ribeiro on loan for the rest of the season with the option to make the deal permanent.

## India v England: Shoaib Bashir and James Anderson named in squad for second Test
 - [https://www.bbc.co.uk/sport/cricket/68164293?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/68164293?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T08:57:30+00:00

Off-spinner Shoaib Bashir will make his England debut in the second Test against India in Visakhapatnam.

## Mike Freer: North London MP to step down over safety fears
 - [https://www.bbc.co.uk/news/uk-england-london-68163968?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-68163968?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T07:45:05+00:00

Mike Freer says threats against him had become too much, a month after his office was set alight.

## XL bully: Newport landowner welcomes owners as ban starts
 - [https://www.bbc.co.uk/news/uk-wales-68160152?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-68160152?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T07:07:51+00:00

The dogs must be on a lead and muzzled in public, but can be walked without either on private land.

## Post Office scandal: Alan Bates rejects "cruel" compensation offer
 - [https://www.bbc.co.uk/news/uk-england-london-68163288?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-68163288?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T04:57:35+00:00

Former Post Office operator who inspired ITV drama says sum is about a sixth of what he requested.

## Parents want answers after son's construction site death
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-68007763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-68007763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T04:48:42+00:00

James Rourke's parents ask if more could have been done to prevent his death on a building site.

## Houthis claim to have hit US merchant ship in Red Sea
 - [https://www.bbc.co.uk/news/world-middle-east-68162927?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-68162927?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T04:42:56+00:00

Meanwhile, the US has launched new air strikes in Yemen, targeting 10 drones reportedly being set up to launch.

## Watch: Police rescue toddler stuck inside claw machine
 - [https://www.bbc.co.uk/news/world-australia-68163418?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-68163418?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T04:20:18+00:00

Three-year-old Ethan had to be saved after crawling into a toy machine in Brisbane, Australia.

## FBI says Chinese state hacker group targeted US infrastructure
 - [https://www.bbc.co.uk/news/world-asia-68163172?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-68163172?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T03:41:33+00:00

China is targeting US infrastructure and laying the groundwork to wreak chaos, the FBI director warns.

## The Apprentice: Lord Sugar says influencers are weeded out in advance
 - [https://www.bbc.co.uk/news/entertainment-arts-68109354?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-68109354?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T01:51:42+00:00

Lord Sugar says his team help ensure fame-seekers are not cast in the business competition series.

## Alec Baldwin pleads not guilty to new involuntary manslaughter charge over Halyna Hutchins's Rust shooting
 - [https://www.bbc.co.uk/news/world-us-canada-68162923?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68162923?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:52:03+00:00

The actor is charged with the involuntary manslaughter of cinematographer Halyna Hutchins on a film set.

## Massive taxidermy polar bear stolen in bizarre Canadian heist
 - [https://www.bbc.co.uk/news/world-us-canada-68163036?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-68163036?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:51:03+00:00

The 12ft (3.6m) taxidermy bear was snatched from a Canadian resort during an opportune cold snap.

## Jamie Webster: The Liverpool hometown superstar fuelled by football and politics
 - [https://www.bbc.co.uk/news/entertainment-arts-68126892?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-68126892?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:41:26+00:00

Jamie Webster is playing a 40,000-capacity gig in Liverpool this summer and is aiming for number one.

## Could AI 'trading bots' transform the world of investing?
 - [https://www.bbc.co.uk/news/business-68092814?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-68092814?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:13:05+00:00

Artificial intelligence is increasing being used to guide investments but risks remain.

## Match of the Day analysis: Manchester City 'purr' on Kevin de Bruyne return
 - [https://www.bbc.co.uk/sport/av/football/68162795?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/68162795?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:10:13+00:00

Match of the Day pundit Ian Wright praises Kevin de Bruyne as he starts his first Premier League game since the opening day of the season in Manchester City's 3-1 win over Burnley.

## Match of the Day analysis: Liverpool's Conor Bradley an 'unbelievable find'
 - [https://www.bbc.co.uk/sport/av/football/68162792?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/68162792?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:10:07+00:00

Match of the Day pundit Ian Wright describes Liverpool's Conor Bradley as an "unbelievable find" after the 20-year-old's man-of-the-match performance in the 4-1 Premier League win over Chelsea.

## Cambodia: Fast fashion helps fuel blazing kilns where workers faint from heat
 - [https://www.bbc.co.uk/news/world-asia-68102771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-68102771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:06:58+00:00

How hot is too hot to work? The BBC visits Cambodia's sweltering brick kilns to find out.

## Council financial crisis 'out of control', MPs warn
 - [https://www.bbc.co.uk/news/uk-politics-68159001?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-68159001?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:03:33+00:00

More funding is needed to avoid a "severe impact" on services and more councils going bust, a report says.

## The legal scammer who cost vulnerable clients thousands
 - [https://www.bbc.co.uk/news/uk-68141649?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68141649?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:03:31+00:00

Non-existent court hearings, disappearing documents - BBC uncovers the man at the heart of a legal scam.

## Spotify's content filter fails to block explicit lyrics in dozens of hits
 - [https://www.bbc.co.uk/news/entertainment-arts-68126890?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-68126890?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:03:30+00:00

Fans are shown swear words and racial slurs in dozens of songs even when explicit content is blocked.

## BRCA tests to be offered to Jewish people to detect cancer risk
 - [https://www.bbc.co.uk/news/health-68157044?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-68157044?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:03:28+00:00

NHS England says it wants to test 30,000 Jewish people over the next two years for faulty BRCA genes.

## Bank of England expected to hold rates at 5.25%
 - [https://www.bbc.co.uk/news/business-57764601?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-57764601?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:03:26+00:00

Some economists expect hints about possible rate cuts later this year.

## XL bully ban: Police chief warns of 'challenges' in enforcing law
 - [https://www.bbc.co.uk/news/uk-68158501?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-68158501?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:03:24+00:00

The government says police will be supported in enforcing the new laws taking effect on 1 February.

## How surfing is challenging tradition in a Ghanaian town
 - [https://www.bbc.co.uk/sport/surfing/68127778?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/surfing/68127778?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: https://feeds.bbci.co.uk/news/rss.xml
 - date published: 2024-02-01T00:01:17+00:00

One man convinced parents to let their daughters surf. Now they are challenging and changing social stereotypes in rural Ghana.

