# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## System76 Refreshes Its Serval WS Linux Laptop with 14th Gen Intel CPU
 - [https://9to5linux.com/system76-refreshes-its-serval-ws-linux-laptop-with-14th-gen-intel-cpu](https://9to5linux.com/system76-refreshes-its-serval-ws-linux-laptop-with-14th-gen-intel-cpu)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-02-01T16:00:27+00:00

<p>System76 refreshes its powerful Serval WS Linux-powered laptop with a high-end 14th-generation Intel Core i9-14900HX CPU processor.</p>
<p>The post <a href="https://9to5linux.com/system76-refreshes-its-serval-ws-linux-laptop-with-14th-gen-intel-cpu">System76 Refreshes Its Serval WS Linux Laptop with 14th Gen Intel CPU</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Mesa 24.0 Linux Graphics Stack Released with NVK and RADV Driver Improvements
 - [https://9to5linux.com/mesa-24-0-linux-graphics-stack-released-with-nvk-and-radv-driver-improvements](https://9to5linux.com/mesa-24-0-linux-graphics-stack-released-with-nvk-and-radv-driver-improvements)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2024-02-01T05:06:11+00:00

<p>Mesa 24.0 open-source graphics stack is now available for download with numerous new features and improvements for existing graphics drivers, as well as for numerous video games.</p>
<p>The post <a href="https://9to5linux.com/mesa-24-0-linux-graphics-stack-released-with-nvk-and-radv-driver-improvements">Mesa 24.0 Linux Graphics Stack Released with NVK and RADV Driver Improvements</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

