# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The Zombie Planet at the Center of the Earth
 - [https://www.youtube.com/watch?v=PE4Vh-uPXCM](https://www.youtube.com/watch?v=PE4Vh-uPXCM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2024-02-01T22:00:11+00:00

For years, geologists have been searching for an explanation for two strange blobs of Earth's mantle that are denser than the rest. It turns out, they may not be original parts of Earth at all. 

Hosted by: Hank Green
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Adam Brainard, Alex Hackman, Ash, Bryan Cloer, charles george, Chris Mackey, Chris Peters, Christoph Schwanke, Christopher R Boucher, Eric Jensen, Harrison Mills, Jaap Westera, Jason A, Saslow, Jeffrey Mckishen, Jeremy Mattern, Kevin Bealer, Matt Curls, Michelle Dove, Piya Shedden, Rizwan Kassim, Sam Lutfi
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
TikTok: https://www.tiktok.com/@scishow 
Twitter: http://www.twitter.com/scishow
Instagram: http://instagram.com/thescishow
Facebo

