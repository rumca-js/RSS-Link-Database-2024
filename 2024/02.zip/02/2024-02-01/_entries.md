## Protesting farmers hurl eggs and clog streets with tractors as EU summit begins | CNN
 - [https://edition.cnn.com/2024/02/01/europe/farmers-protest-brussels-eu-summit-intl/index.html](https://edition.cnn.com/2024/02/01/europe/farmers-protest-brussels-eu-summit-intl/index.html)
 - RSS feed: 
 - date published: 2024-02-01T11:26:53+00:00

Protesting farmers have gathered at the heart of the European Union as leaders across the bloc hold a crucial meeting to discuss funding for Ukraine.

