# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## In a 'Dark Dimension,' Physicists Search for the Universe's Missing Matter
 - [https://www.quantamagazine.org/in-a-dark-dimension-physicists-search-for-missing-matter-20240201](https://www.quantamagazine.org/in-a-dark-dimension-physicists-search-for-missing-matter-20240201)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T22:01:10+00:00

<p>Article URL: <a href="https://www.quantamagazine.org/in-a-dark-dimension-physicists-search-for-missing-matter-20240201/">https://www.quantamagazine.org/in-a-dark-dimension-physicists-search-for-missing-matter-20240201/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39222066">https://news.ycombinator.com/item?id=39222066</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## We need motivation (good managers)
 - [https://www.ethanalter.com/blog/motivation](https://www.ethanalter.com/blog/motivation)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T21:45:50+00:00

<p>Article URL: <a href="https://www.ethanalter.com/blog/motivation">https://www.ethanalter.com/blog/motivation</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39221894">https://news.ycombinator.com/item?id=39221894</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Apple reports first quarter results
 - [https://www.apple.com/newsroom/2024/02/apple-reports-first-quarter-results](https://www.apple.com/newsroom/2024/02/apple-reports-first-quarter-results)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T21:31:43+00:00

<p>Article URL: <a href="https://www.apple.com/newsroom/2024/02/apple-reports-first-quarter-results/">https://www.apple.com/newsroom/2024/02/apple-reports-first-quarter-results/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39221738">https://news.ycombinator.com/item?id=39221738</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Show HN: The Super Programmer – A colorful introduction to engineering
 - [https://keyvan.me/tsp](https://keyvan.me/tsp)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T21:24:06+00:00

<p>I have started writing an unusual book discussing various topics in computer science by implementing them from scratch. I would like to know your opinion on it! WARNING: It's a very draft version of it!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39221661">https://news.ycombinator.com/item?id=39221661</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Meta Reports Fourth Quarter and Full Year 2023 Results
 - [https://investor.fb.com/investor-news/press-release-details/2024/Meta-Reports-Fourth-Quarter-and-Full-Year-2023-Results-Initiates-Quarterly-Dividend/default.aspx](https://investor.fb.com/investor-news/press-release-details/2024/Meta-Reports-Fourth-Quarter-and-Full-Year-2023-Results-Initiates-Quarterly-Dividend/default.aspx)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T21:07:49+00:00

<p>Article URL: <a href="https://investor.fb.com/investor-news/press-release-details/2024/Meta-Reports-Fourth-Quarter-and-Full-Year-2023-Results-Initiates-Quarterly-Dividend/default.aspx">https://investor.fb.com/investor-news/press-release-details/2024/Meta-Reports-Fourth-Quarter-and-Full-Year-2023-Results-Initiates-Quarterly-Dividend/default.aspx</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39221483">https://news.ycombinator.com/item?id=39221483</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Make Invalid States Unrepresentable
 - [https://www.awwsmm.com/blog/make-invalid-states-unrepresentable](https://www.awwsmm.com/blog/make-invalid-states-unrepresentable)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T20:49:16+00:00

<p>Article URL: <a href="https://www.awwsmm.com/blog/make-invalid-states-unrepresentable">https://www.awwsmm.com/blog/make-invalid-states-unrepresentable</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39221243">https://news.ycombinator.com/item?id=39221243</a></p>
<p>Points: 7</p>
<p># Comments: 4</p>

## Fixing a broken smart cat feeder with ESP32
 - [https://pdx.su/blog/2024-01-19-fixing-a-broken-smart-cat-feeder-with-esp32](https://pdx.su/blog/2024-01-19-fixing-a-broken-smart-cat-feeder-with-esp32)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T20:48:19+00:00

<p>Article URL: <a href="https://pdx.su/blog/2024-01-19-fixing-a-broken-smart-cat-feeder-with-esp32/">https://pdx.su/blog/2024-01-19-fixing-a-broken-smart-cat-feeder-with-esp32/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39221230">https://news.ycombinator.com/item?id=39221230</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Cloudflare Thanksgiving 2023 Security Incident
 - [https://blog.cloudflare.com/thanksgiving-2023-security-incident](https://blog.cloudflare.com/thanksgiving-2023-security-incident)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T19:59:24+00:00

<p>Article URL: <a href="https://blog.cloudflare.com/thanksgiving-2023-security-incident">https://blog.cloudflare.com/thanksgiving-2023-security-incident</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39220528">https://news.ycombinator.com/item?id=39220528</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## FOSDEM 2024 – NetBSD 10: Thirty years, still going strong [video]
 - [https://fosdem.org/2024/schedule/event/fosdem-2024-3508-netbsd-10-thirty-years-still-going-strong-](https://fosdem.org/2024/schedule/event/fosdem-2024-3508-netbsd-10-thirty-years-still-going-strong-)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T19:56:09+00:00

<p>Article URL: <a href="https://fosdem.org/2024/schedule/event/fosdem-2024-3508-netbsd-10-thirty-years-still-going-strong-/">https://fosdem.org/2024/schedule/event/fosdem-2024-3508-netbsd-10-thirty-years-still-going-strong-/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39220474">https://news.ycombinator.com/item?id=39220474</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Pooled number of deaths by age group in EU
 - [https://www.euromomo.eu/graphs-and-maps](https://www.euromomo.eu/graphs-and-maps)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T19:29:43+00:00

<p>Article URL: <a href="https://www.euromomo.eu/graphs-and-maps/">https://www.euromomo.eu/graphs-and-maps/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39220124">https://news.ycombinator.com/item?id=39220124</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## Nasopharyngeal Lymphatics Found to Be Crucial for Cerebrospinal Fluid Outflow
 - [https://www.ibs.re.kr/cop/bbs/BBSMSTR_000000000738/selectBoardArticle.do?nttId=24483&pageIndex=1&searchCnd=&searchWrd=](https://www.ibs.re.kr/cop/bbs/BBSMSTR_000000000738/selectBoardArticle.do?nttId=24483&pageIndex=1&searchCnd=&searchWrd=)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T19:17:16+00:00

<p>Article URL: <a href="https://www.ibs.re.kr/cop/bbs/BBSMSTR_000000000738/selectBoardArticle.do?nttId=24483&amp;pageIndex=1&amp;searchCnd=&amp;searchWrd=">https://www.ibs.re.kr/cop/bbs/BBSMSTR_000000000738/selectBoardArticle.do?nttId=24483&amp;pageIndex=1&amp;searchCnd=&amp;searchWrd=</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219953">https://news.ycombinator.com/item?id=39219953</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Large sequence models for software development activities
 - [https://blog.research.google/2023/05/large-sequence-models-for-software.html](https://blog.research.google/2023/05/large-sequence-models-for-software.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T19:13:50+00:00

<p>Article URL: <a href="https://blog.research.google/2023/05/large-sequence-models-for-software.html">https://blog.research.google/2023/05/large-sequence-models-for-software.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219903">https://news.ycombinator.com/item?id=39219903</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## What Is an Electronic Sackbut?
 - [https://spectrum.ieee.org/electronic-music](https://spectrum.ieee.org/electronic-music)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T19:08:27+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/electronic-music">https://spectrum.ieee.org/electronic-music</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219834">https://news.ycombinator.com/item?id=39219834</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## 240-Gbit/s sub-THz wireless communications using ultra-low phase noise receiver
 - [https://www.jstage.jst.go.jp/article/elex/advpub/0/advpub_20.20230584/_article](https://www.jstage.jst.go.jp/article/elex/advpub/0/advpub_20.20230584/_article)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T19:07:39+00:00

<p>Article URL: <a href="https://www.jstage.jst.go.jp/article/elex/advpub/0/advpub_20.20230584/_article">https://www.jstage.jst.go.jp/article/elex/advpub/0/advpub_20.20230584/_article</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219826">https://news.ycombinator.com/item?id=39219826</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## CyberChef from GCHQ: The Cyber Swiss Army Knife
 - [https://gchq.github.io/CyberChef](https://gchq.github.io/CyberChef)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T19:01:45+00:00

<p>Article URL: <a href="https://gchq.github.io/CyberChef/">https://gchq.github.io/CyberChef/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219761">https://news.ycombinator.com/item?id=39219761</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## A new way to discover places with generative AI in Maps
 - [https://blog.google/products/maps/google-maps-generative-ai-local-guides](https://blog.google/products/maps/google-maps-generative-ai-local-guides)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T18:47:27+00:00

<p>Article URL: <a href="https://blog.google/products/maps/google-maps-generative-ai-local-guides/">https://blog.google/products/maps/google-maps-generative-ai-local-guides/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219598">https://news.ycombinator.com/item?id=39219598</a></p>
<p>Points: 3</p>
<p># Comments: 68</p>

## Starlink's Laser System Is Beaming 42 Petabytes of Data per Day
 - [https://www.pcmag.com/news/starlinks-laser-system-is-beaming-42-million-gb-of-data-per-day](https://www.pcmag.com/news/starlinks-laser-system-is-beaming-42-million-gb-of-data-per-day)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T18:44:15+00:00

<p>Article URL: <a href="https://www.pcmag.com/news/starlinks-laser-system-is-beaming-42-million-gb-of-data-per-day">https://www.pcmag.com/news/starlinks-laser-system-is-beaming-42-million-gb-of-data-per-day</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219568">https://news.ycombinator.com/item?id=39219568</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Math Built the Modern World
 - [https://worksinprogress.co/issue/how-mathematics-built-the-modern-world](https://worksinprogress.co/issue/how-mathematics-built-the-modern-world)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T18:42:52+00:00

<p>Article URL: <a href="https://worksinprogress.co/issue/how-mathematics-built-the-modern-world/">https://worksinprogress.co/issue/how-mathematics-built-the-modern-world/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219553">https://news.ycombinator.com/item?id=39219553</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Watch a 7k-LB Rivian R1T Destroy a Guardrail in Eyebrow-Raising Test
 - [https://www.thedrive.com/news/rivian-r1t-destroys-guardrail-ev-safety-crash-test-video](https://www.thedrive.com/news/rivian-r1t-destroys-guardrail-ev-safety-crash-test-video)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T18:27:19+00:00

<p>Article URL: <a href="https://www.thedrive.com/news/rivian-r1t-destroys-guardrail-ev-safety-crash-test-video">https://www.thedrive.com/news/rivian-r1t-destroys-guardrail-ev-safety-crash-test-video</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219371">https://news.ycombinator.com/item?id=39219371</a></p>
<p>Points: 19</p>
<p># Comments: 9</p>

## A SQLite extension that brings column-oriented tables to SQLite
 - [https://github.com/dgllghr/stanchion](https://github.com/dgllghr/stanchion)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T18:25:37+00:00

<p>Article URL: <a href="https://github.com/dgllghr/stanchion">https://github.com/dgllghr/stanchion</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219349">https://news.ycombinator.com/item?id=39219349</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Germany explores 4-day workweek amid labor shortage
 - [https://www.dw.com/en/germany-tests-four-day-workweek-amid-labor-shortage/a-68125506](https://www.dw.com/en/germany-tests-four-day-workweek-amid-labor-shortage/a-68125506)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T18:25:14+00:00

<p>Article URL: <a href="https://www.dw.com/en/germany-tests-four-day-workweek-amid-labor-shortage/a-68125506">https://www.dw.com/en/germany-tests-four-day-workweek-amid-labor-shortage/a-68125506</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219344">https://news.ycombinator.com/item?id=39219344</a></p>
<p>Points: 21</p>
<p># Comments: 4</p>

## YouTube Says It Has More Than 100M Premium and Music Subscribers
 - [https://variety.com/2024/digital/news/youtube-100-million-premium-music-subscribers-1235894391](https://variety.com/2024/digital/news/youtube-100-million-premium-music-subscribers-1235894391)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T18:23:04+00:00

<p>Article URL: <a href="https://variety.com/2024/digital/news/youtube-100-million-premium-music-subscribers-1235894391/">https://variety.com/2024/digital/news/youtube-100-million-premium-music-subscribers-1235894391/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219308">https://news.ycombinator.com/item?id=39219308</a></p>
<p>Points: 12</p>
<p># Comments: 17</p>

## Analysts Estimate Nvidia Owns 98% of the Data Center GPU Market
 - [https://www.extremetech.com/computing/analysts-estimate-nvidia-owns-98-of-the-data-center-gpu-market](https://www.extremetech.com/computing/analysts-estimate-nvidia-owns-98-of-the-data-center-gpu-market)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T18:19:48+00:00

<p>Article URL: <a href="https://www.extremetech.com/computing/analysts-estimate-nvidia-owns-98-of-the-data-center-gpu-market">https://www.extremetech.com/computing/analysts-estimate-nvidia-owns-98-of-the-data-center-gpu-market</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39219258">https://news.ycombinator.com/item?id=39219258</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Artificial Intelligence and Peace – Pope Francis
 - [https://www.vatican.va/content/francesco/en/messages/peace/documents/20231208-messaggio-57giornatamondiale-pace2024.html](https://www.vatican.va/content/francesco/en/messages/peace/documents/20231208-messaggio-57giornatamondiale-pace2024.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T17:50:23+00:00

<p>Article URL: <a href="https://www.vatican.va/content/francesco/en/messages/peace/documents/20231208-messaggio-57giornatamondiale-pace2024.html">https://www.vatican.va/content/francesco/en/messages/peace/documents/20231208-messaggio-57giornatamondiale-pace2024.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39218867">https://news.ycombinator.com/item?id=39218867</a></p>
<p>Points: 18</p>
<p># Comments: 8</p>

## The web just gets better with Interop 2024
 - [https://webkit.org/blog/14955/the-web-just-gets-better-with-interop](https://webkit.org/blog/14955/the-web-just-gets-better-with-interop)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T17:33:33+00:00

<p>Article URL: <a href="https://webkit.org/blog/14955/the-web-just-gets-better-with-interop/">https://webkit.org/blog/14955/the-web-just-gets-better-with-interop/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39218638">https://news.ycombinator.com/item?id=39218638</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Corporations Openly Trying to Destroy Core Public Institutions. We Should Worry
 - [https://www.vice.com/en/article/v7bnyb/meta-spacex-lawsuits-declaring-ftc-nlrb-unconstitutional](https://www.vice.com/en/article/v7bnyb/meta-spacex-lawsuits-declaring-ftc-nlrb-unconstitutional)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T17:21:42+00:00

<p>Article URL: <a href="https://www.vice.com/en/article/v7bnyb/meta-spacex-lawsuits-declaring-ftc-nlrb-unconstitutional">https://www.vice.com/en/article/v7bnyb/meta-spacex-lawsuits-declaring-ftc-nlrb-unconstitutional</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39218463">https://news.ycombinator.com/item?id=39218463</a></p>
<p>Points: 24</p>
<p># Comments: 2</p>

## CISA directs federal agencies to disconnect Ivanti products by Friday midnight
 - [https://www.cisa.gov/news-events/directives/supplemental-direction-v1-ed-24-01-mitigate-ivanti-connect-secure-and-ivanti-policy-secure](https://www.cisa.gov/news-events/directives/supplemental-direction-v1-ed-24-01-mitigate-ivanti-connect-secure-and-ivanti-policy-secure)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T17:20:35+00:00

<p>Article URL: <a href="https://www.cisa.gov/news-events/directives/supplemental-direction-v1-ed-24-01-mitigate-ivanti-connect-secure-and-ivanti-policy-secure">https://www.cisa.gov/news-events/directives/supplemental-direction-v1-ed-24-01-mitigate-ivanti-connect-secure-and-ivanti-policy-secure</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39218446">https://news.ycombinator.com/item?id=39218446</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Nine Ugly Truths about Copyright and five predictions about its future
 - [https://www.honest-broker.com/p/nine-ugly-truths-about-copyright](https://www.honest-broker.com/p/nine-ugly-truths-about-copyright)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T17:18:17+00:00

<p>Article URL: <a href="https://www.honest-broker.com/p/nine-ugly-truths-about-copyright">https://www.honest-broker.com/p/nine-ugly-truths-about-copyright</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39218410">https://news.ycombinator.com/item?id=39218410</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## Google Maps is getting 'supercharged' with generative AI
 - [https://www.theverge.com/2024/2/1/24057994/google-maps-generative-ai-llm-local-guide-search](https://www.theverge.com/2024/2/1/24057994/google-maps-generative-ai-llm-local-guide-search)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T17:14:43+00:00

<p>Article URL: <a href="https://www.theverge.com/2024/2/1/24057994/google-maps-generative-ai-llm-local-guide-search">https://www.theverge.com/2024/2/1/24057994/google-maps-generative-ai-llm-local-guide-search</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39218367">https://news.ycombinator.com/item?id=39218367</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Solving SAT via Positive Supercompilation
 - [https://hirrolot.github.io/posts/sat-supercompilation.html](https://hirrolot.github.io/posts/sat-supercompilation.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T17:01:44+00:00

<p>Article URL: <a href="https://hirrolot.github.io/posts/sat-supercompilation.html">https://hirrolot.github.io/posts/sat-supercompilation.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39218173">https://news.ycombinator.com/item?id=39218173</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## HyperDX (YC S22) Is Hiring a Founding Engineer – Open-Source Observability (SF)
 - [https://www.ycombinator.com/companies/hyperdx/jobs/1Ja2psR-founding-software-engineer-backend](https://www.ycombinator.com/companies/hyperdx/jobs/1Ja2psR-founding-software-engineer-backend)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T17:00:23+00:00

<p>Article URL: <a href="https://www.ycombinator.com/companies/hyperdx/jobs/1Ja2psR-founding-software-engineer-backend">https://www.ycombinator.com/companies/hyperdx/jobs/1Ja2psR-founding-software-engineer-backend</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39218160">https://news.ycombinator.com/item?id=39218160</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## US designates more Chinese tech companies as military collaborators
 - [https://www.theregister.com/2024/02/01/us_china_military_collaborators](https://www.theregister.com/2024/02/01/us_china_military_collaborators)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T16:21:41+00:00

<p>Article URL: <a href="https://www.theregister.com/2024/02/01/us_china_military_collaborators/">https://www.theregister.com/2024/02/01/us_china_military_collaborators/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39217616">https://news.ycombinator.com/item?id=39217616</a></p>
<p>Points: 15</p>
<p># Comments: 0</p>

## Windows 10 users report app problems after Microsoft update
 - [https://www.theregister.com/2024/02/01/windows_10_users_errors_hardware](https://www.theregister.com/2024/02/01/windows_10_users_errors_hardware)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T16:20:28+00:00

<p>Article URL: <a href="https://www.theregister.com/2024/02/01/windows_10_users_errors_hardware/">https://www.theregister.com/2024/02/01/windows_10_users_errors_hardware/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39217608">https://news.ycombinator.com/item?id=39217608</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Show HN: ML Blocks – Deploy multimodal AI workflows without code
 - [https://www.mlblocks.com](https://www.mlblocks.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T16:15:21+00:00

<p>Hey everyone,<p>ML Blocks is a node-based workflow builder to create multi-modal AI workflows without writing any code.<p>You connect blocks that call various visual models like GPT4v, Segment Anything, Dino etc. along with basic image processing blocks like resize, invert color, blur, crop, and several others.<p>The idea is to make it easier to deploy multi-step image processing workflows, without needing to spin up endless custom OpenCV cloud functions to glue together AI models. Usually, even if you're using cloud inference servers like Replicate, you still need to write your own image processing code to pre and post-process images in your pipeline. When you're trying to move fast, that's just unnecessary overhead.<p>With ML Blocks, you can build a workflow and deploy the whole thing as a single API. AFAIK, ML Blocks is the only end-to-end workflow builder built specifically for image processing.<p>If you're curious, our models run on Replicate, HuggingFace & Modal Labs

## Quadratic – Open-Source Spreadsheet Is Now Multiplayer
 - [https://www.quadratichq.com/blog/2024-01-28-the-multiplayer-spreadsheet](https://www.quadratichq.com/blog/2024-01-28-the-multiplayer-spreadsheet)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T16:07:47+00:00

<p>Article URL: <a href="https://www.quadratichq.com/blog/2024-01-28-the-multiplayer-spreadsheet">https://www.quadratichq.com/blog/2024-01-28-the-multiplayer-spreadsheet</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39217440">https://news.ycombinator.com/item?id=39217440</a></p>
<p>Points: 9</p>
<p># Comments: 3</p>

## In China, clean energy is now THE driver of overall economic growth
 - [https://adamtooze.substack.com/p/chartbook-carbon-notes-10-in-china](https://adamtooze.substack.com/p/chartbook-carbon-notes-10-in-china)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T16:07:38+00:00

<p>Article URL: <a href="https://adamtooze.substack.com/p/chartbook-carbon-notes-10-in-china">https://adamtooze.substack.com/p/chartbook-carbon-notes-10-in-china</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39217436">https://news.ycombinator.com/item?id=39217436</a></p>
<p>Points: 11</p>
<p># Comments: 4</p>

## CheerpJ 3.0: A WebAssembly JVM to run real-world applications in the browser
 - [https://labs.leaningtech.com/blog/cheerpj-3.0](https://labs.leaningtech.com/blog/cheerpj-3.0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T16:05:19+00:00

<p>Article URL: <a href="https://labs.leaningtech.com/blog/cheerpj-3.0">https://labs.leaningtech.com/blog/cheerpj-3.0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39217395">https://news.ycombinator.com/item?id=39217395</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Ask HN: Who is hiring? (February 2024)
 - [https://news.ycombinator.com/item?id=39217310](https://news.ycombinator.com/item?id=39217310)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T16:00:08+00:00

<p>Please state the location and include REMOTE, INTERNS and/or VISA
when that sort of candidate is welcome. When remote work is <i>not</i> an option,
include ONSITE.<p>Please only post if you personally are part of the hiring company—no
recruiting firms or job boards. One post per company. If it isn't a household name,
explain what your company does.<p>Commenters: please don't reply to job posts to complain about
something. It's off topic here.<p>Readers: please only email if you are personally interested in the job.<p>Searchers: try <a href="https://www.remotenbs.com" rel="nofollow">https://www.remotenbs.com</a>, <a href="https://hnjobs.u-turn.dev" rel="nofollow">https://hnjobs.u-turn.dev</a>, <a href="https://hnresumetojobs.com" rel="nofollow">https://hnresumetojobs.com</a>,
<a href="https://hnhired.fly.dev" rel="nofollow">https://hnhired.fly.dev</a>, <a href="https://kennytilton.github.io/whoishiring/" rel="nofollow">https://kennytilton.github.io/whoishiring/</a>, <a href

## Ask HN: Who wants to be hired? (February 2024)
 - [https://news.ycombinator.com/item?id=39217308](https://news.ycombinator.com/item?id=39217308)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T16:00:06+00:00

<p>Share your information if you are looking for work. Please use this format:<p><pre><code>  Location:
  Remote:
  Willing to relocate:
  Technologies:
  Résumé/CV:
  Email:
</code></pre>
Readers: please only email these addresses to discuss work opportunities.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39217308">https://news.ycombinator.com/item?id=39217308</a></p>
<p>Points: 35</p>
<p># Comments: 101</p>

## Ask HN: Looking for a project to volunteer on? (February 2024)
 - [https://news.ycombinator.com/item?id=39217231](https://news.ycombinator.com/item?id=39217231)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T15:52:49+00:00

<p>This thread is open to anyone seeking for volunteer projects and anyone who is seeking volunteers for their projects.
SEEKING VOLUNTEERS: A good example would be to write the name of the project, and a short description. Also write down the project website and git forge URL, and write the programming languages it uses. Also, please don't forget to start your comment off with "SEEKING VOLUNTEERS" for people seeking projects to find your comment easier, and not get it mixed up with the "SEEKING PROJECTS" comments.<p>SEEKING PROJECTS: If comfortable doing so, write down your name, and programming languages that you know. Also don't forget to write down some of the projects that you have volunteered on, or some of the projects that you made, and what you are interested in working on. Optionally, you can write your email, if you want opportunities to be discussed privately. Also, please don't forget to start your comment off with "SEEKING PROJECTS" for people seeking volunteers

## Los Angeles Becomes First US City to Outlaw Digital Discrimination
 - [https://themarkup.org/still-loading/2024/02/01/los-angeles-becomes-first-us-city-to-outlaw-digital-discrimination](https://themarkup.org/still-loading/2024/02/01/los-angeles-becomes-first-us-city-to-outlaw-digital-discrimination)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T15:48:27+00:00

<p>Article URL: <a href="https://themarkup.org/still-loading/2024/02/01/los-angeles-becomes-first-us-city-to-outlaw-digital-discrimination">https://themarkup.org/still-loading/2024/02/01/los-angeles-becomes-first-us-city-to-outlaw-digital-discrimination</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39217174">https://news.ycombinator.com/item?id=39217174</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## My favourite Git commit (2019)
 - [https://dhwthompson.com/2019/my-favourite-git-commit](https://dhwthompson.com/2019/my-favourite-git-commit)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T15:46:15+00:00

<p>Article URL: <a href="https://dhwthompson.com/2019/my-favourite-git-commit">https://dhwthompson.com/2019/my-favourite-git-commit</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39217149">https://news.ycombinator.com/item?id=39217149</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Bard's latest updates: Access Gemini Pro globally and generate images
 - [https://blog.google/products/bard/google-bard-gemini-pro-image-generation](https://blog.google/products/bard/google-bard-gemini-pro-image-generation)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T15:36:51+00:00

<p>Article URL: <a href="https://blog.google/products/bard/google-bard-gemini-pro-image-generation/">https://blog.google/products/bard/google-bard-gemini-pro-image-generation/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39217046">https://news.ycombinator.com/item?id=39217046</a></p>
<p>Points: 17</p>
<p># Comments: 5</p>

## When the Mac Was a Munition
 - [https://newsletter.pessimistsarchive.org/p/when-the-mac-was-a-munition](https://newsletter.pessimistsarchive.org/p/when-the-mac-was-a-munition)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T15:25:20+00:00

<p>Article URL: <a href="https://newsletter.pessimistsarchive.org/p/when-the-mac-was-a-munition">https://newsletter.pessimistsarchive.org/p/when-the-mac-was-a-munition</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39216921">https://news.ycombinator.com/item?id=39216921</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Compiling a Lisp
 - [https://bernsteinbear.com/blog/compiling-a-lisp-0](https://bernsteinbear.com/blog/compiling-a-lisp-0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T15:23:27+00:00

<p>Article URL: <a href="https://bernsteinbear.com/blog/compiling-a-lisp-0/">https://bernsteinbear.com/blog/compiling-a-lisp-0/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39216904">https://news.ycombinator.com/item?id=39216904</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## What Makes for 'Good' Mathematics?
 - [https://www.quantamagazine.org/what-makes-for-good-mathematics-20240201](https://www.quantamagazine.org/what-makes-for-good-mathematics-20240201)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T15:11:59+00:00

<p>Article URL: <a href="https://www.quantamagazine.org/what-makes-for-good-mathematics-20240201/">https://www.quantamagazine.org/what-makes-for-good-mathematics-20240201/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39216790">https://news.ycombinator.com/item?id=39216790</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## This is the world’s rarest passport
 - [https://www.cnn.com/travel/worlds-rarest-passport-sovereign-order-malta/index.html](https://www.cnn.com/travel/worlds-rarest-passport-sovereign-order-malta/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T15:08:00+00:00

<p>Article URL: <a href="https://www.cnn.com/travel/worlds-rarest-passport-sovereign-order-malta/index.html">https://www.cnn.com/travel/worlds-rarest-passport-sovereign-order-malta/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39216761">https://news.ycombinator.com/item?id=39216761</a></p>
<p>Points: 11</p>
<p># Comments: 4</p>

## Lifestance: A mental health rollup headed for a breakdown
 - [https://hindenburgresearch.com/lifestance](https://hindenburgresearch.com/lifestance)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T14:13:20+00:00

<p>Article URL: <a href="https://hindenburgresearch.com/lifestance/">https://hindenburgresearch.com/lifestance/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39216110">https://news.ycombinator.com/item?id=39216110</a></p>
<p>Points: 9</p>
<p># Comments: 3</p>

## Show HN: Dera – A platform to manage chunks and embeddings for building RAG apps
 - [https://getdera.com](https://getdera.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T14:01:11+00:00

<p>Hi everyone,<p>my cofounder and I built Dera - a platform to help manage chunks and embeddings.<p>We built this because of the pain points we experienced while building RAG applications for side projects. The biggest pain point we encountered was that we were constantly trying out different chunking strategies, but there’s no easy way to check how the strategies are performing in terms of retrieval when given the same query.<p>We tried searching for a tool for this but couldn’t find any (most LLM dev tools focus on prompts management).<p>We hope this tool will be useful for people building RAG apps.<p>Thank you!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39215955">https://news.ycombinator.com/item?id=39215955</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Damn Small Linux 2024
 - [https://www.damnsmalllinux.org](https://www.damnsmalllinux.org)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T13:47:48+00:00

<p>Article URL: <a href="https://www.damnsmalllinux.org/">https://www.damnsmalllinux.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39215846">https://news.ycombinator.com/item?id=39215846</a></p>
<p>Points: 129</p>
<p># Comments: 46</p>

## Launch HN: Escape (YC W23) – Discover and secure all your APIs
 - [https://news.ycombinator.com/item?id=39215779](https://news.ycombinator.com/item?id=39215779)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T13:38:42+00:00

<p>Hey HN! We’re Tristan and Antoine, co-founders of Escape (<a href="https://escape.tech">https://escape.tech</a>). We use AI inspired by chess to help security engineers and developers discover and secure APIs created by their organizations.<p>Here is our demo: <a href="https://youtu.be/qcCaegVElTY" rel="nofollow">https://youtu.be/qcCaegVElTY</a><p>Typical modern large orgs have hundreds if not thousands of APIs, and many of those handle sensitive data or are critical to business operations. The development of those APIs is distributed across different development teams that don’t always have knowledge of API security best practices. API source codes are updated frequently, making it easy for new, easily exploitable security vulnerabilities to be introduced in production environments (think the 2018 FB 50M accounts data leak).<p>APIs make up 80% of global web traffic, and this share is growing. The responsibility for securing APIs is usually given to the organization's secu

## Apprise: Open-Source, Self-Hosted, Push Notifications
 - [https://github.com/caronc/apprise](https://github.com/caronc/apprise)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T13:35:00+00:00

<p>Article URL: <a href="https://github.com/caronc/apprise">https://github.com/caronc/apprise</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39215732">https://news.ycombinator.com/item?id=39215732</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Spider webs capture environmental DNA from terrestrial vertebrates
 - [https://www.cell.com/iscience/fulltext/S2589-0042(24)00125-1](https://www.cell.com/iscience/fulltext/S2589-0042(24)00125-1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T13:33:38+00:00

<p>Article URL: <a href="https://www.cell.com/iscience/fulltext/S2589-0042(24)00125-1">https://www.cell.com/iscience/fulltext/S2589-0042(24)00125-1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39215723">https://news.ycombinator.com/item?id=39215723</a></p>
<p>Points: 21</p>
<p># Comments: 6</p>

## Show HN: Don't Do It Bro: porn addiction peer-support
 - [https://dontdoitbro.com](https://dontdoitbro.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T12:45:08+00:00

<p>"Help and be helped" community for recovering addicts</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39215365">https://news.ycombinator.com/item?id=39215365</a></p>
<p>Points: 4</p>
<p># Comments: 4</p>

## FreeBSD 4 Bug may be present in Playstation 4/5
 - [https://wololo.net/2024/02/01/is-an-18-year-old-vulnerability-the-key-to-the-next-ps5-ps4-jailbreak](https://wololo.net/2024/02/01/is-an-18-year-old-vulnerability-the-key-to-the-next-ps5-ps4-jailbreak)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T12:36:15+00:00

<p>Article URL: <a href="https://wololo.net/2024/02/01/is-an-18-year-old-vulnerability-the-key-to-the-next-ps5-ps4-jailbreak/">https://wololo.net/2024/02/01/is-an-18-year-old-vulnerability-the-key-to-the-next-ps5-ps4-jailbreak/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39215309">https://news.ycombinator.com/item?id=39215309</a></p>
<p>Points: 62</p>
<p># Comments: 10</p>

## The VAE Used for Stable Diffusion Is Flawed
 - [https://old.reddit.com/r/StableDiffusion/comments/1ag5h5s/the_vae_used_for_stable_diffusion_1x2x_and_other](https://old.reddit.com/r/StableDiffusion/comments/1ag5h5s/the_vae_used_for_stable_diffusion_1x2x_and_other)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T12:25:48+00:00

<p>Article URL: <a href="https://old.reddit.com/r/StableDiffusion/comments/1ag5h5s/the_vae_used_for_stable_diffusion_1x2x_and_other/">https://old.reddit.com/r/StableDiffusion/comments/1ag5h5s/the_vae_used_for_stable_diffusion_1x2x_and_other/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39215242">https://news.ycombinator.com/item?id=39215242</a></p>
<p>Points: 149</p>
<p># Comments: 30</p>

## Vision Mamba: Efficient Visual Representation Learning with Bidirectional SSM
 - [https://arxiv.org/abs/2401.09417](https://arxiv.org/abs/2401.09417)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T11:46:28+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2401.09417">https://arxiv.org/abs/2401.09417</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39214939">https://news.ycombinator.com/item?id=39214939</a></p>
<p>Points: 20</p>
<p># Comments: 1</p>

## Show HN: filippo.io/mlkem768 – Post-Quantum Cryptography for the Go Ecosystem
 - [https://words.filippo.io/dispatches/mlkem768](https://words.filippo.io/dispatches/mlkem768)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T11:10:58+00:00

<p>Article URL: <a href="https://words.filippo.io/dispatches/mlkem768/">https://words.filippo.io/dispatches/mlkem768/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39214743">https://news.ycombinator.com/item?id=39214743</a></p>
<p>Points: 154</p>
<p># Comments: 46</p>

## Across the country, houses of worship are going solar
 - [https://grist.org/buildings/more-churches-plugging-solar-power](https://grist.org/buildings/more-churches-plugging-solar-power)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T11:04:04+00:00

<p>Article URL: <a href="https://grist.org/buildings/more-churches-plugging-solar-power/">https://grist.org/buildings/more-churches-plugging-solar-power/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39214701">https://news.ycombinator.com/item?id=39214701</a></p>
<p>Points: 18</p>
<p># Comments: 9</p>

## PhotoRoom (YC S20) Is Hiring an API Designer in Paris (Node, Rust)
 - [https://news.ycombinator.com/item?id=39213421](https://news.ycombinator.com/item?id=39213421)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T07:00:46+00:00

<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39213421">https://news.ycombinator.com/item?id=39213421</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## Markov Chains Are the Original Language Models
 - [https://elijahpotter.dev/articles/markov_chains_are_the_original_language_models](https://elijahpotter.dev/articles/markov_chains_are_the_original_language_models)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T06:59:11+00:00

<p>Article URL: <a href="https://elijahpotter.dev/articles/markov_chains_are_the_original_language_models">https://elijahpotter.dev/articles/markov_chains_are_the_original_language_models</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39213410">https://news.ycombinator.com/item?id=39213410</a></p>
<p>Points: 29</p>
<p># Comments: 6</p>

## EU chip goal 'unrealistic' says ASML CEO
 - [https://www.electronicsweekly.com/news/business/eu-chip-goal-totally-unrealistic-2024-01](https://www.electronicsweekly.com/news/business/eu-chip-goal-totally-unrealistic-2024-01)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T06:11:16+00:00

<p>Article URL: <a href="https://www.electronicsweekly.com/news/business/eu-chip-goal-totally-unrealistic-2024-01/">https://www.electronicsweekly.com/news/business/eu-chip-goal-totally-unrealistic-2024-01/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39213180">https://news.ycombinator.com/item?id=39213180</a></p>
<p>Points: 7</p>
<p># Comments: 3</p>

## Marlon Brando Was a Secret Tech Geek and Photoshop Ace
 - [https://www.yahoo.com/entertainment/marlon-brando-was-a-secret-tech-geek-and-photoshop-124061824672.html](https://www.yahoo.com/entertainment/marlon-brando-was-a-secret-tech-geek-and-photoshop-124061824672.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T06:04:41+00:00

<p>Article URL: <a href="https://www.yahoo.com/entertainment/marlon-brando-was-a-secret-tech-geek-and-photoshop-124061824672.html">https://www.yahoo.com/entertainment/marlon-brando-was-a-secret-tech-geek-and-photoshop-124061824672.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39213150">https://news.ycombinator.com/item?id=39213150</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## Matryoshka Representation Learning
 - [https://arxiv.org/abs/2205.13147](https://arxiv.org/abs/2205.13147)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T05:12:32+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2205.13147">https://arxiv.org/abs/2205.13147</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39212905">https://news.ycombinator.com/item?id=39212905</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The curious case of the disappearing Polish Ś (2015)
 - [https://medium.engineering/the-curious-case-of-disappearing-polish-s-fa398313d4df](https://medium.engineering/the-curious-case-of-disappearing-polish-s-fa398313d4df)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T04:53:54+00:00

<p>Article URL: <a href="https://medium.engineering/the-curious-case-of-disappearing-polish-s-fa398313d4df">https://medium.engineering/the-curious-case-of-disappearing-polish-s-fa398313d4df</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39212833">https://news.ycombinator.com/item?id=39212833</a></p>
<p>Points: 84</p>
<p># Comments: 16</p>

## Garry Tan's Tupac Reference Goes Wrong
 - [https://thiscrowd.com/y-combinator-president-garry-tans-tupac](https://thiscrowd.com/y-combinator-president-garry-tans-tupac)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T04:51:14+00:00

<p>Article URL: <a href="https://thiscrowd.com/y-combinator-president-garry-tans-tupac/">https://thiscrowd.com/y-combinator-president-garry-tans-tupac/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39212819">https://news.ycombinator.com/item?id=39212819</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Pivotal Mental States
 - [https://journals.sagepub.com/doi/full/10.1177/0269881120959637](https://journals.sagepub.com/doi/full/10.1177/0269881120959637)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T04:49:47+00:00

<p>Article URL: <a href="https://journals.sagepub.com/doi/full/10.1177/0269881120959637">https://journals.sagepub.com/doi/full/10.1177/0269881120959637</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39212813">https://news.ycombinator.com/item?id=39212813</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## How Boeing Put Profits over Planes
 - [https://www.vox.com/money/24052245/boeing-corporate-culture-737-airplane-safety-door-plug](https://www.vox.com/money/24052245/boeing-corporate-culture-737-airplane-safety-door-plug)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T04:39:06+00:00

<p>Article URL: <a href="https://www.vox.com/money/24052245/boeing-corporate-culture-737-airplane-safety-door-plug">https://www.vox.com/money/24052245/boeing-corporate-culture-737-airplane-safety-door-plug</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39212766">https://news.ycombinator.com/item?id=39212766</a></p>
<p>Points: 24</p>
<p># Comments: 0</p>

## How Ancient Roman Concrete Was Able to Last Thousands of Years
 - [https://www.sciencealert.com/we-finally-know-how-ancient-roman-concrete-was-able-to-last-thousands-of-yearsl](https://www.sciencealert.com/we-finally-know-how-ancient-roman-concrete-was-able-to-last-thousands-of-yearsl)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T04:26:36+00:00

<p>Article URL: <a href="https://www.sciencealert.com/we-finally-know-how-ancient-roman-concrete-was-able-to-last-thousands-of-yearsl">https://www.sciencealert.com/we-finally-know-how-ancient-roman-concrete-was-able-to-last-thousands-of-yearsl</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39212710">https://news.ycombinator.com/item?id=39212710</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Photoshop's "generative expand" tool may have expanded bust and exposed midriff
 - [https://www.abc.net.au/news/2024-02-01/georgie-purcell-ai-image-nine-news-apology-digital-ethics/103408440](https://www.abc.net.au/news/2024-02-01/georgie-purcell-ai-image-nine-news-apology-digital-ethics/103408440)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T02:46:37+00:00

<p>Article URL: <a href="https://www.abc.net.au/news/2024-02-01/georgie-purcell-ai-image-nine-news-apology-digital-ethics/103408440">https://www.abc.net.au/news/2024-02-01/georgie-purcell-ai-image-nine-news-apology-digital-ethics/103408440</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39212257">https://news.ycombinator.com/item?id=39212257</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## Show HN: Lockbox: forward proxy for making third party API calls
 - [https://github.com/mkjt2/lockbox](https://github.com/mkjt2/lockbox)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T01:26:55+00:00

<p>Article URL: <a href="https://github.com/mkjt2/lockbox">https://github.com/mkjt2/lockbox</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39211857">https://news.ycombinator.com/item?id=39211857</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## 'Black Swan' author Nassim Taleb says the U.S. is in a 'death spiral'
 - [https://fortune.com/2024/01/31/nassim-nicholas-taleb-black-swan-author-national-debt-death-spiral](https://fortune.com/2024/01/31/nassim-nicholas-taleb-black-swan-author-national-debt-death-spiral)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T00:30:03+00:00

<p>Article URL: <a href="https://fortune.com/2024/01/31/nassim-nicholas-taleb-black-swan-author-national-debt-death-spiral/">https://fortune.com/2024/01/31/nassim-nicholas-taleb-black-swan-author-national-debt-death-spiral/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39211473">https://news.ycombinator.com/item?id=39211473</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## The End of My Childhood
 - [https://vitalik.eth.limo/general/2024/01/31/end.html](https://vitalik.eth.limo/general/2024/01/31/end.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T00:12:11+00:00

<p>Article URL: <a href="https://vitalik.eth.limo/general/2024/01/31/end.html">https://vitalik.eth.limo/general/2024/01/31/end.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39211328">https://news.ycombinator.com/item?id=39211328</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Stop KOSA (Kids Online Safety Act)
 - [https://www.stopkosa.com](https://www.stopkosa.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T00:03:58+00:00

<p>Article URL: <a href="https://www.stopkosa.com/">https://www.stopkosa.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39211270">https://news.ycombinator.com/item?id=39211270</a></p>
<p>Points: 58</p>
<p># Comments: 17</p>

## Gnuplotlib: Non-Painful Plotting for NumPy
 - [https://github.com/dkogan/gnuplotlib](https://github.com/dkogan/gnuplotlib)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2024-02-01T00:02:38+00:00

<p>Article URL: <a href="https://github.com/dkogan/gnuplotlib">https://github.com/dkogan/gnuplotlib</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=39211263">https://news.ycombinator.com/item?id=39211263</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

