# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Znana sieć marketów podnosi pensje. Tyle zarobi kasjer
 - [https://businessinsider.com.pl/gospodarka/znana-siec-podnosi-pensje-tyle-zarobi-kasjer/t7v28kw](https://businessinsider.com.pl/gospodarka/znana-siec-podnosi-pensje-tyle-zarobi-kasjer/t7v28kw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T20:39:19+00:00

Sieć Kaufland poniosła pensje swoim pracownikom. Na podwyżki firma chce przeznaczyć w tym roku ok. 110 mln zł - przekazano w komunikacie prasowym.

## Polska będzie miała pływający gazoport. Dostawca technologii wybrany
 - [https://businessinsider.com.pl/biznes/polska-bedzie-miala-plywajacy-gazoport-jest-dostawca-technologii/dcxws4s](https://businessinsider.com.pl/biznes/polska-bedzie-miala-plywajacy-gazoport-jest-dostawca-technologii/dcxws4s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T19:55:28+00:00

Gaz-System wybrał firmę, która dostarczy i obsłuży pływający terminal w Zatoce Gdańskiej zdolny przyjmować tankowce ze skroplonym gazem (LNG). Przetarg wygrał Mitsui O.S.K. Lines, zarządzający największą na świecie flotą metanowców. Inwestycja zwiększy możliwości importu gazu ziemnego do Polski drogą morską.

## Lidl wprowadza różowe skrzynki. Ma to pomóc kobietom
 - [https://businessinsider.com.pl/wiadomosci/lidl-wprowadza-rozowe-skrzynki-ma-to-pomoc-kobietom/c9l5zsg](https://businessinsider.com.pl/wiadomosci/lidl-wprowadza-rozowe-skrzynki-ma-to-pomoc-kobietom/c9l5zsg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T19:54:50+00:00

Lidl Polska montuje w damskich łazienkach ok. 1 tys. różowych skrzyneczek, które wypełnione są niezbędnymi artykułami higienicznymi. Ma to ułatwić życie kobietom zatrudnionym w firmie.

## Wojna o TK może wrócić. Prezydencka minister komentuje
 - [https://businessinsider.com.pl/wiadomosci/wojna-o-tk-moze-wrocic-prezydencka-minister-komentuje/55p9l32](https://businessinsider.com.pl/wiadomosci/wojna-o-tk-moze-wrocic-prezydencka-minister-komentuje/55p9l32)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T19:42:00+00:00

Nielegalne działania, zamach na organ działający zgodnie z prawem, pogłębianie chaosu — w ten sposób prezydencka minister Małgorzata Paprocka skomentowała doniesienia medialne o pomysłach koalicji rządzącej na zmiany w Trybunale Konstytucyjnym.

## Słynny kierowca F1 zmienia zespół
 - [https://businessinsider.com.pl/wiadomosci/slynny-kierowca-f1-zmienia-zespol/w9c6jys](https://businessinsider.com.pl/wiadomosci/slynny-kierowca-f1-zmienia-zespol/w9c6jys)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T19:31:15+00:00

Siedmiokrotny mistrz świata Formuły 1 Brytyjczyk Lewis Hamilton po sezonie 2024 przejdzie z Mercedesa do Ferrari — potwierdziły oba zespoły.

## Wielki "owadowy" zakład niemal ukończony
 - [https://businessinsider.com.pl/gospodarka/wielki-owadowy-zaklad-niemal-ukonczony/z82ln69](https://businessinsider.com.pl/gospodarka/wielki-owadowy-zaklad-niemal-ukonczony/z82ln69)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T19:24:19+00:00

Już za kilka tygodni uruchomiona zostanie produkcja alternatywnego białka z owadów. To największa tego typu inwestycja w Polsce.

## Ustawa budżetowa już w Dzienniku Ustaw
 - [https://businessinsider.com.pl/wiadomosci/ustawa-budzetowa-juz-w-dzienniku-ustaw/nlky1w5](https://businessinsider.com.pl/wiadomosci/ustawa-budzetowa-juz-w-dzienniku-ustaw/nlky1w5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T18:58:07+00:00

Ustawa budżetowa została już opublikowana w Dzienniku Ustaw. To oznacza, że wchodzi w życie z mocą wsteczną od 1 stycznia bieżącego roku.

## Co z odprawą dla Daniela Obajtka? Oto odpowiedź Orlenu
 - [https://businessinsider.com.pl/gospodarka/co-z-odprawa-dla-daniela-obajtka-oto-odpowiedz-orlenu/r7cc5fm](https://businessinsider.com.pl/gospodarka/co-z-odprawa-dla-daniela-obajtka-oto-odpowiedz-orlenu/r7cc5fm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T18:37:24+00:00

Rada nadzorcza Orlenu nagle odwołała Daniela Obajtka z funkcji prezesa. Zapytaliśmy koncern, czy odchodzący szef może liczyć na odprawę czy odszkodowanie z tytułu zakazu konkurencji. Oto co ma do powiedzenia firma.

## Węgry nie będą wysyłać żadnych pieniędzy Ukrainie
 - [https://businessinsider.com.pl/wiadomosci/wegry-nie-beda-wysylac-zadnych-pieniedzy-ukrainie/5etndpk](https://businessinsider.com.pl/wiadomosci/wegry-nie-beda-wysylac-zadnych-pieniedzy-ukrainie/5etndpk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T17:49:28+00:00

W końcu wynegocjowaliśmy mechanizm kontroli gwarantujący, że środki zostaną rozsądnie wykorzystane i węgierskie pieniądze nie zostaną wysłane do Ukrainy – powiedział premier Węgier Viktor Orban po szczycie Rady Europejskiej.

## Mieszkania jeszcze droższe. W Warszawie pękła kolejna granica
 - [https://businessinsider.com.pl/gospodarka/mieszkania-jeszcze-drozsze-w-warszawie-pekla-kolejna-granica/rtv9pv2](https://businessinsider.com.pl/gospodarka/mieszkania-jeszcze-drozsze-w-warszawie-pekla-kolejna-granica/rtv9pv2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T17:28:00+00:00

Rynek nieruchomości ciągle jest rozgrzany do czerwoności. Z analizy Rynku Pierwotnego wynika, że we wszystkich największych aglomeracjach za m kw. mieszkania deweloperskiego musimy zapłacić średnio przynajmniej 10 tys. zł.

## Wyrzutnie rakiet pionowego startu dla fregat Miecznik. Jest porozumienie
 - [https://businessinsider.com.pl/wiadomosci/wyrzutnie-rakiet-pionowego-startu-dla-fregat-miecznik-jest-porozumienie/p9f2mc7](https://businessinsider.com.pl/wiadomosci/wyrzutnie-rakiet-pionowego-startu-dla-fregat-miecznik-jest-porozumienie/p9f2mc7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T17:03:09+00:00

Zawarliśmy dziś porozumienie z koncernem Lockheed Martin, od którego pozyskaliśmy dla trzech budowanych fregat Miecznik system pionowego startu VLS Mk 41 dla rodziny pocisków CAMM — poinformowała Polska Grupa Zbrojeniowa.

## Nieoficjalnie: będzie atak USA na cele w dwóch krajach
 - [https://businessinsider.com.pl/wiadomosci/nieoficjalnie-bedzie-atak-usa-na-cele-w-dwoch-krajach/sb8f45w](https://businessinsider.com.pl/wiadomosci/nieoficjalnie-bedzie-atak-usa-na-cele-w-dwoch-krajach/sb8f45w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T17:02:35+00:00

Zatwierdzono plany amerykańskich ataków na irańskie obiekty w Iraku i Syrii — potwierdzili anonimowo amerykańscy urzędnicy, cytowani przez stację CBS News.

## Światowa prasa o odejściu Daniela Obajtka. Wypominają jego "grzechy"
 - [https://businessinsider.com.pl/gospodarka/swiatowa-prasa-o-odejsciu-daniela-obajtka/36cx9b3](https://businessinsider.com.pl/gospodarka/swiatowa-prasa-o-odejsciu-daniela-obajtka/36cx9b3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T16:50:04+00:00

Czołowe media anglojęzyczne komentują odwołanie Daniela Obajtka ze stanowiska szefa Orlenu. Wspominają o jego bliskości z PiS oraz opisują najbardziej kontrowersyjne decyzje.

## Za chwilę rewolucja kadrowa w największym polskim banku. Kolejny kandydat
 - [https://businessinsider.com.pl/biznes/za-chwile-rewolucja-kadrowa-w-najwiekszym-polskim-banku-kolejny-kandydat/kd33s1m](https://businessinsider.com.pl/biznes/za-chwile-rewolucja-kadrowa-w-najwiekszym-polskim-banku-kolejny-kandydat/kd33s1m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T16:26:21+00:00

Andrzej Oślizło jest kolejnym kandydatem Skarbu Państwa do rady nadzorczej PKO BP. W przeszłości zasiadał on m.in. w zarządzie PLL LOT. Akcjonariusze banku zdecydują o zmianach w nadzorze w piątek 2 lutego.

## Inwestorzy nie płaczą po Danielu Obajtku. Wręcz przeciwnie, zarobili miliardy złotych
 - [https://businessinsider.com.pl/gielda/wiadomosci/dymisja-daniela-obajtka-wywolala-euforie-inwestorzy-na-gieldzie-zarobili-miliardy/888xrj8](https://businessinsider.com.pl/gielda/wiadomosci/dymisja-daniela-obajtka-wywolala-euforie-inwestorzy-na-gieldzie-zarobili-miliardy/888xrj8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T16:21:49+00:00

Inwestorzy świętują odejście prezesa Daniela Obajtka. Po tym, jak ogłoszono dymisję prezesa Orlenu, akcje spółki wystrzeliły. Na kontach akcjonariuszy w ciągu jednego dnia przybyło w sumie ponad 3 mld zł.

## Premier Tusk chce ostrzej uderzyć w putinowską Rosję
 - [https://businessinsider.com.pl/gospodarka/premier-tusk-chce-ostrzej-uderzyc-w-putinowska-rosje/0lvpb0d](https://businessinsider.com.pl/gospodarka/premier-tusk-chce-ostrzej-uderzyc-w-putinowska-rosje/0lvpb0d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T16:10:18+00:00

Polska na pewno będzie domagała się możliwie szerokiego zestawu w nowym pakiecie sankcji wobec Rosji — zapowiedział premier Donald Tusk. W Brukseli rozpoczynają się konsultacje w sprawie 13. pakietu sankcji.

## Były pierwszy żołnierz RP ma nową pracę u znanego dziennikarza
 - [https://businessinsider.com.pl/wiadomosci/byly-pierwszy-zolnierz-rp-ma-prace-u-znanego-dziennikarza/pd6k57e](https://businessinsider.com.pl/wiadomosci/byly-pierwszy-zolnierz-rp-ma-prace-u-znanego-dziennikarza/pd6k57e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T15:35:17+00:00

Przez pięć lat gen. Rajmund Andrzejczak był najważniejszym wojskowym w kraju, ale złożył wypowiedzenie tuż przed wyborami parlamentarnymi. Teraz dołączy do kanału Krzysztofa Stanowskiego.

## Premier o odwołaniu Daniela Obajtka. "Wystarczy spojrzeć"
 - [https://businessinsider.com.pl/gospodarka/premier-o-odwolaniu-daniela-obajtka-wystarczy-spojrzec/tdxj3dc](https://businessinsider.com.pl/gospodarka/premier-o-odwolaniu-daniela-obajtka-wystarczy-spojrzec/tdxj3dc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T15:09:24+00:00

Premier Tusk został zapytany w Brukseli o odwołanie Daniela Obajtka z funkcji szefa Orlenu. "Najlepiej o tym mówi to, co dzieje się na giełdzie" — stwierdził szef rządu.

## Trwa strajk na niemieckich lotniskach. Związkowcy chcą jego przedłużenia
 - [https://businessinsider.com.pl/biznes/trwa-strajk-na-niemieckich-lotniskach-zwiazkowcy-chca-jego-przedluzenia/k3m4zkm](https://businessinsider.com.pl/biznes/trwa-strajk-na-niemieckich-lotniskach-zwiazkowcy-chca-jego-przedluzenia/k3m4zkm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T14:59:25+00:00

W nocy ze środy na czwartek rozpoczął się strajk pracowników jedenastu największych niemieckich lotnisk. Akcja miała zakończyć się w czwartek wieczorem, ale związek zawodowy Verdi nawołuje pracowników z Hamburga do przedłużenia protestu o kolejną dobę – poinformowała dpa.

## Polska kontra Dania. Czego może nam zazdrościć król Fryderyk X?
 - [https://businessinsider.com.pl/gospodarka/polska-kontra-dania-czego-moze-nam-zazdroscic-krol-fryderyk-x/tx0fn4s](https://businessinsider.com.pl/gospodarka/polska-kontra-dania-czego-moze-nam-zazdroscic-krol-fryderyk-x/tx0fn4s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T14:58:43+00:00

Nowy duński król na pierwszą wizytę zagraniczną wybrał Polskę. Nasz gospodarka jest dużo większa od duńskiej, choć nie przekłada się to na zamożność mieszkańców. Średnie zarobki są tam 3-4 razy większe, ale też koszty życia nie są porównywalne. Przyjrzeliśmy się bliżej gospodarce, której agencje ratingowe dają najwyższe możliwe oceny.

## "Jestem zbudowany". Premier Tusk jest "miło zaskoczony" po szczycie
 - [https://businessinsider.com.pl/wiadomosci/jestem-zbudowany-premier-tusk-jest-milo-zaskoczony/0e7nq6x](https://businessinsider.com.pl/wiadomosci/jestem-zbudowany-premier-tusk-jest-milo-zaskoczony/0e7nq6x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T14:54:33+00:00

Wszyscy mają prawo czuć się mile zaskoczeni — stwierdził Donald Tusk po szczycie UE, na którym udało się uzgodnić pakiet dla Ukrainy. Węgry ostatecznie wycofały swój sprzeciw. Premier Tusk dodał, że "zakładano, iż przekonywanie Viktora Orbana będzie trwało dłużej".

## Przedwiośnie nad Jeziorem Wulpińskim. Luksusowy wypoczynek w specjalnych cenach
 - [https://businessinsider.com.pl/lifestyle/podroze/przedwiosnie-nad-jeziorem-wulpinskim-luksusowy-wypoczynek-w-specjalnych-cenach/bytrhzy](https://businessinsider.com.pl/lifestyle/podroze/przedwiosnie-nad-jeziorem-wulpinskim-luksusowy-wypoczynek-w-specjalnych-cenach/bytrhzy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T14:30:00+00:00

Styczeń minął, a wraz z nadejściem lutego, serca wielu z nas zaczynają bić w rytmie oczekiwania na pierwsze oznaki wiosny. Hotel Marina Club, pięknie położony na malowniczym półwyspie nad Jeziorem Wulpińskim, otwiera swoje podwoje dla tych, którzy pragną zaznać przedsmaków cieplejszych dni. Ten pięciogwiazdkowy obiekt to kwintesencja luksusu, stylu i wygody, idealna na wczesnowiosenny wypoczynek. W jego ekskluzywnym SPA, z widokami rozciągającymi się na spokojne wody jeziora, goście mogą odnaleźć ukojenie i relaks. Dodatkowo Hotel Marina Club wychodzi naprzeciw oczekiwaniom użytkowników Business Insider, oferując specjalne zniżki na pobyt. Możliwa jest rezerwacja w promocyjnej cenie poprzez linki zawarte w artykule. Zapraszamy do skorzystania z tej niepowtarzalnej oferty, by już teraz poczuć oddech nadchodzącej wiosny, ciesząc się relaksem i luksusem, które gwarantuje Hotel Marina Club. Zapraszamy!

## Polacy coraz chętniej odwiedzają centra handlowe
 - [https://businessinsider.com.pl/gospodarka/polacy-coraz-chetniej-odwiedzaja-centra-handlowe/sebzn1x](https://businessinsider.com.pl/gospodarka/polacy-coraz-chetniej-odwiedzaja-centra-handlowe/sebzn1x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T14:20:41+00:00

Pomimo trudnej sytuacji gospodarczej Polacy coraz częściej bywają w centrach handlowych. W 2023 r. odwiedzalność galerii handlowych wzrosła o 4,6 proc. wobec roku 2022, do 10,8 osób miesięcznie na metr kwadratowy — wynika z najnowszego badania.

## Posłanka KO: sprawdzimy także fuzje Orlenu z Energą i PGNiG
 - [https://businessinsider.com.pl/biznes/poslanka-ko-sprawdzimy-takze-fuzje-orlenu-z-energa-i-pgnig/gnh27z5](https://businessinsider.com.pl/biznes/poslanka-ko-sprawdzimy-takze-fuzje-orlenu-z-energa-i-pgnig/gnh27z5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T14:06:17+00:00

Czeka nas audyt tego, co działo się w Orlenie przez ostatnie osiem lat. Proces samej fuzji jest wielowątkowy i dotyczy przejęcia nie tylko Lotosu, ale i Energi oraz PGNiG. To także wymaga analizy — powiedziała posłanka KO Agnieszka Pomaska w rozmowie z "Rzeczpospolitą".

## Podwyżki dla nauczycieli z poślizgiem? "Może się zdarzyć"
 - [https://businessinsider.com.pl/wiadomosci/podwyzki-dla-nauczycieli-z-poslizgiem-moze-sie-zdarzyc/ps4g776](https://businessinsider.com.pl/wiadomosci/podwyzki-dla-nauczycieli-z-poslizgiem-moze-sie-zdarzyc/ps4g776)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T13:59:21+00:00

Podwyżki wynagrodzeń dla nauczycieli prawdopodobnie nie przyjdą tak, jak zakładaliśmy, od marca z wyrównaniem od stycznia. Może się tak zdarzyć, że to będzie dopiero od kwietnia — powiedziała ministra edukacji Barbara Nowacka po spotkaniu ze związkami zawodowymi.

## Niemcy chcą wywłaszczyć Rosjan z kluczowej rafinerii
 - [https://businessinsider.com.pl/gospodarka/niemcy-chca-wywlaszczyc-rosjan-z-kluczowej-rafinerii/z17pdd2](https://businessinsider.com.pl/gospodarka/niemcy-chca-wywlaszczyc-rosjan-z-kluczowej-rafinerii/z17pdd2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T13:48:30+00:00

Rząd w Berlinie jest bliski wywłaszczenia rosyjskiej spółki Rosnieft z jej udziałów w przygranicznej rafinerii PCK w Schwedt przy granicy z Polską — podaje niemiecki Business Insider. Ostateczna decyzja powinna zapaść w przeciągu kilku tygodni.

## Cios dla handlu. Ruch na Morzu Czerwonym spada dramatycznie
 - [https://businessinsider.com.pl/gospodarka/cios-dla-handlu-ruch-na-morzu-czerwonym-spada-dramatycznie/8lrr160](https://businessinsider.com.pl/gospodarka/cios-dla-handlu-ruch-na-morzu-czerwonym-spada-dramatycznie/8lrr160)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T13:21:12+00:00

Ruch kontenerowców na Morzu Czerwonym zmniejszył się o 30 proc. w stosunku do listopada ubiegłego roku — podał szef wydziału Bliskiego Wschodu i Azji Centralnej Międzynarodowego Funduszu Walutowego Jihad Azour. Dodał, że liczba przewozów spadła szczególnie od początku stycznia.

## Jak urodzenie dziecka wpływa na karierę? "Macierzyńska kara"
 - [https://businessinsider.com.pl/praca/jak-urodzenie-dziecka-wplywa-na-kariere-macierzynska-kara/2k3xbzg](https://businessinsider.com.pl/praca/jak-urodzenie-dziecka-wplywa-na-kariere-macierzynska-kara/2k3xbzg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T13:20:23+00:00

Jak macierzyństwo wpływa na karierę? W nowym badaniu zmierzono jego wpływ na zatrudnienie kobiet na całym świecie. Czym jest "kara za macierzyństwo"?

## Miał pozwolenie na wymianę okien. Dobudował dwa piętra w bloku
 - [https://businessinsider.com.pl/wiadomosci/mial-pozwolenie-na-wymiane-okien-dobudowal-dwa-pietra-w-bloku/e6rmh4g](https://businessinsider.com.pl/wiadomosci/mial-pozwolenie-na-wymiane-okien-dobudowal-dwa-pietra-w-bloku/e6rmh4g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T13:17:33+00:00

Miała być zwyczajna wymiana okien, a skończyło się na dobudowaniu dwóch pięter w bloku mieszkalnym. Tak właśnie postąpił jeden z mieszkańców Tomaszowa Mazowieckiego. Lokatorzy są wściekli, wspólnota zdziwiona, a urzędnicy rozkładają ręce.

## "Nie ma odwrotu". Daniel Obajtek publikuje raport
 - [https://businessinsider.com.pl/gospodarka/nie-ma-odwrotu-daniel-obajtek-publikuje-raport/pq2b58d](https://businessinsider.com.pl/gospodarka/nie-ma-odwrotu-daniel-obajtek-publikuje-raport/pq2b58d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T13:12:48+00:00

Zbudowaliśmy nie tylko jedną z największych firm w Europie — napisał Daniel Obajtek, odwołany już szef Orlenu. Jako "rozliczenie" ze swojej pracy przedstawił wielki "raport" za ostatnich siedem lat.

## Jest nowa wiceszefowa skarbówki
 - [https://businessinsider.com.pl/wiadomosci/jest-nowa-wiceszefowa-skarbowki/361k34p](https://businessinsider.com.pl/wiadomosci/jest-nowa-wiceszefowa-skarbowki/361k34p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T12:53:10+00:00

Jest nowa wiceszefowa skarbówki. Minister finansów wręczył dzisiaj powołanie na to stanowisko Małgorzacie Krok — ustalił Business Insider Polska.

## Były prezes Lotosu o odwołaniu Daniela Obajtka. "Dla mnie było jasne"
 - [https://businessinsider.com.pl/biznes/byly-prezes-lotosu-o-odwolaniu-daniela-obajtka-dla-mnie-bylo-jasne/8l69x3v](https://businessinsider.com.pl/biznes/byly-prezes-lotosu-o-odwolaniu-daniela-obajtka-dla-mnie-bylo-jasne/8l69x3v)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T12:44:23+00:00

Z wypowiedzi prezesa Orlenu Daniela Obajtka wynika, że zastał Polskę drewnianą, a zostawił murowaną. Tymczasem jego opinie nie mają potwierdzenia w rzeczywistości — komentuje dla Business Insider Polska Paweł Olechnowicz, były prezes Lotosu. — Dla mnie było jasne, że musi odejść — dodał.

## W urzędach pracy przybyło ludzi, ale faktycznie bezrobotnych ubyło. Jak to możliwe?
 - [https://businessinsider.com.pl/gospodarka/co-z-tym-bezrobociem-w-polsce-rosnie-czy-spada/771g144](https://businessinsider.com.pl/gospodarka/co-z-tym-bezrobociem-w-polsce-rosnie-czy-spada/771g144)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T12:35:45+00:00

Choć w zimie sezonowo bezrobocie zazwyczaj rośnie, w danych Eurostatu dla Polski nie widać tego efektu. Wyprzedziliśmy tym samym Czechy i tylko jeden kraj może się pochwalić mniejszą stopą bezrobocia w UE.

## Władimir Putin ma misję. Szuka zagranicznych nieruchomości z czasów Imperium Rosyjskiego
 - [https://businessinsider.com.pl/wiadomosci/rosyjski-prezydent-poszukuje-zagranicznych-nieruchomosci/h0tckdh](https://businessinsider.com.pl/wiadomosci/rosyjski-prezydent-poszukuje-zagranicznych-nieruchomosci/h0tckdh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T12:32:03+00:00

Putin chce odnaleźć i odzyskać zagraniczne nieruchomości Związku Radzieckiego. Dwoma dekretami zlecił sfinansowanie poszukiwań zagranicznych nieruchomości z czasów Związku Radzieckiego, a nawet Imperium Rosyjskiego.

## Zuckerberg znów stanął przed Kongresem USA. Tym razem może coś z tego wyniknąć
 - [https://businessinsider.com.pl/media/zuckerberg-znow-stanal-przed-kongresem-usa-tym-razem-moze-cos-z-tego-wyniknac/b1hgqdr](https://businessinsider.com.pl/media/zuckerberg-znow-stanal-przed-kongresem-usa-tym-razem-moze-cos-z-tego-wyniknac/b1hgqdr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T12:11:28+00:00

Prezesi Mety, TikToka, X, Snapa i Discorda zostali przesłuchani w Kongresie USA. Chodzi o wykorzystywania i krzywdzenia dzieci w mediach społecznościowych.

## Pięciolatka ścigana przez urząd skarbowy. Zajęli jej 500 plus
 - [https://businessinsider.com.pl/wiadomosci/pieciolatka-scigana-przez-urzad-skarbowy-zajeli-jej-500-plus/9gsefgx](https://businessinsider.com.pl/wiadomosci/pieciolatka-scigana-przez-urzad-skarbowy-zajeli-jej-500-plus/9gsefgx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T12:10:29+00:00

Urząd skarbowy nie ma litości i zdecydował się wziąć na celownik pięciolatkę. Fiskus nie tylko zajął przysługujące jej wypłaty z programu 500 plus, ale także zajął honorarium dziewczynki, która regularnie występuje w reklamach. Eksperci są oburzeni, a Rzeczniczka Praw Dziecka reaguje.

## Parlament Europejski obrzucony jajkami i kamieniami, w tle pożary. Rolnicy mają dość [WIDEO]
 - [https://businessinsider.com.pl/gospodarka/parlament-europejski-obrzucony-jajkami-i-kamieniami-rolnicy-maja-dosc/tpz3dd4](https://businessinsider.com.pl/gospodarka/parlament-europejski-obrzucony-jajkami-i-kamieniami-rolnicy-maja-dosc/tpz3dd4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T11:48:39+00:00

Zamieszki w Brukseli w trakcie protestu rolników. Uczestnicy zgromadzenia obrzucali jajkami i kamieniami Parlament Europejski, a także wzniecili pożary w pobliżu budynku. W ten sposób chcą wywrzeć presję na Unii Europejskiej, aby zrobiła więcej, by pomóc im wobec rosnących kosztów wynikających m.in. z Zielonego Ładu dla rolnictwa.

## Prezesi państwowych spółek odchodzą. Na pożegnanie zgarną fortunę z odpraw
 - [https://businessinsider.com.pl/gospodarka/prezesi-panstwowych-spolek-odchodza-na-pozegnanie-zgarna-fortune-z-odpraw/q01llgz](https://businessinsider.com.pl/gospodarka/prezesi-panstwowych-spolek-odchodza-na-pozegnanie-zgarna-fortune-z-odpraw/q01llgz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T07:01:37+00:00

Jak opisuje "Gazeta Wyborcza", odchodzący prezesi i członkowie zarządu kluczowych spółek skarbu państwa z nadania PiS mogą liczyć na sute odprawy. Niektórzy na pożegnanie otrzymają nawet milionowe kwoty.

## Polska powinna chronić przestrzeń powietrzną Ukrainy? Jednoznaczny sondaż
 - [https://businessinsider.com.pl/gospodarka/polska-powinna-chronic-przestrzen-powietrzna-ukrainy-jednoznaczny-sondaz/d7tn12y](https://businessinsider.com.pl/gospodarka/polska-powinna-chronic-przestrzen-powietrzna-ukrainy-jednoznaczny-sondaz/d7tn12y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T06:26:07+00:00

69,3 proc. badanych uważa, że powinniśmy rozpocząć rozmowy z NATO i Ukrainą na temat objęcia obroną powietrzną przygranicznego terytorium Ukrainy, aby móc zestrzelić rosyjskie rakiety lecące w kierunku Polski – wynika z badania IBRiS dla "Rzeczpospolitej".

## Nasz PKB w 2023 r. rósł najwolniej w tym stuleciu (nie licząc pandemii)
 - [https://businessinsider.com.pl/gospodarka/nasz-pkb-w-2023-r-rosl-najwolniej-w-tym-stuleciu-nie-liczac-pandemii/4esgt11](https://businessinsider.com.pl/gospodarka/nasz-pkb-w-2023-r-rosl-najwolniej-w-tym-stuleciu-nie-liczac-pandemii/4esgt11)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T06:15:12+00:00

Polska gospodarka jednak rośnie wolniej niż myśleliśmy i co ciekawe, pierwszy raz ma gorsze wyniki niż strefa euro. Fed nie chce obniżać stóp procentowych w marcu, a jeden z mniejszych banków w Stanach ma kłopoty, więc nastroje na giełdach się zepsuły. Ponad połowa Polaków nie oszczędza, aby zabezpieczyć się przed inflacją, za to GUS pracuje nad kalkulatorem, dzięki któremu każdy będzie mógł sobie policzyć swoją własną prywatną inflację. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Daniel Obajtek zabiera głos. "Daję sobie miesiąc"
 - [https://businessinsider.com.pl/wiadomosci/daniel-obajtek-zabiera-glos-daje-sobie-miesiac/84fdl1j](https://businessinsider.com.pl/wiadomosci/daniel-obajtek-zabiera-glos-daje-sobie-miesiac/84fdl1j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T06:08:59+00:00

— Daję sobie mniej więcej miesiąc na to, by się zastanowić, co będę robił — powiedział w rozmowie z "Pulsem Biznesu" prezes Orlenu Daniel Obajtek.

## NIK o kolejnych nieprawidłowościach. Prokuratura Zbigniewa Ziobry w ogniu krytyki
 - [https://businessinsider.com.pl/wiadomosci/nik-o-kolejnych-nieprawidlowosciach-prokuratura-ziobry-w-ogniu-krytyki/0vnghbm](https://businessinsider.com.pl/wiadomosci/nik-o-kolejnych-nieprawidlowosciach-prokuratura-ziobry-w-ogniu-krytyki/0vnghbm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T06:01:54+00:00

Prezes NIK Marian Banaś poinformował, że w sprawie zakupu i remontu budynku Prokuratury Krajowej są poważne ustalenia dotyczące niegospodarności.

## Co dalej ze skargą Ukrainy na Polskę do WTO? Spór o zboże wraca
 - [https://businessinsider.com.pl/wiadomosci/co-dalej-ze-skarga-ukrainy-na-polske-do-wto-spor-o-zboze-wraca/vtfnmx0](https://businessinsider.com.pl/wiadomosci/co-dalej-ze-skarga-ukrainy-na-polske-do-wto-spor-o-zboze-wraca/vtfnmx0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:44:52+00:00

Jak opisuje "Rzeczpospolita" ukraińska skarga do Światowej Organizacji Handlu w sprawie polskiego embarga na zboże nie została wycofana. Sprawa nadal jest w toku, a konflikt pozostaje nierozwiązany. Również po ostatniej decyzji Komisji Europejskiej pozwalającej na bezcłowy handel UE z Kijowem.

## Apple Vision Pro mają rozpocząć nową erę. Recenzenci radzą, aby po zakupie je zwrócić
 - [https://businessinsider.com.pl/technologie/nowe-technologie/apple-vision-pro-trafiaja-do-sklepow-recenzenci-radza-aby-po-zakupie-je-zwrocic/1t2jvze](https://businessinsider.com.pl/technologie/nowe-technologie/apple-vision-pro-trafiaja-do-sklepow-recenzenci-radza-aby-po-zakupie-je-zwrocic/1t2jvze)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:22:43+00:00

Do sprzedaży trafiają zapowiadane w zeszłym roku gogle Apple Vision Pro. Pod względem technologicznym to pierwsza liga, ale cena, jaką życzy sobie Apple, jest trudna do uzasadnienia. Zamożni fani marki się ucieszą, reszta raczej tylko wzruszy ramionami. Miała być rewolucja, niemniej "komputer przestrzenny" w pierwszej wersji nie zachwyca.

## Wybór formy opodatkowania na 2024 r. Zobacz, jakie masz możliwości [TABELA]
 - [https://businessinsider.com.pl/prawo/podatki/jaka-forme-opodatkowania-wybrac-na-2024-r-porownujemy-ryczalt-skale-i-liniowy-pit/8p0y9qd](https://businessinsider.com.pl/prawo/podatki/jaka-forme-opodatkowania-wybrac-na-2024-r-porownujemy-ryczalt-skale-i-liniowy-pit/8p0y9qd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:20:12+00:00

Prawie 880 tys. samozatrudnionych wybrało w zeszłym roku ryczałt jako formę opodatkowania. Ryczałt ma duże zalety, ale przedsiębiorcy, którzy wybrali tę formę, nie mogą korzystać z licznych ulg i preferencji, a przede wszystkim rozliczać kosztów podatkowych. Warto więc sprawdzić, jakie możliwości dają poszczególne formy opodatkowania: ryczałt, liniowy PIT i skala PIT.

## Ważne terminy i zmiany w prawie. Nie można ich przegapić
 - [https://businessinsider.com.pl/prawo/wazne-przepisy-i-terminy-na-co-uwazac-w-lutym/jbbmx6f](https://businessinsider.com.pl/prawo/wazne-przepisy-i-terminy-na-co-uwazac-w-lutym/jbbmx6f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:05:00+00:00

Luty to miesiąc ważnych terminów, ale też kilku zmian w prawie. Są one istotne dla podatników, rodziców, niepełnoletnich, pracowników socjalnych, pracodawców zatrudniających osoby do pracy z dziećmi, a także branżę internetową. Przegapienie niektórych może się wiązać ze stratami lub karami.

## Kurs TRY/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-trypln-1-lutego-2024-r/51v9xt3](https://businessinsider.com.pl/gielda/kursy-walut/kurs-trypln-1-lutego-2024-r/51v9xt3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:50+00:00

Przedstawiamy aktualne notowania kursu liry tureckiej. Oto jak zmienia się kurs liry do polskiego złotego. Warto zapoznać się ze zmianami, by podjąć decyzję, kiedy wymienić walutę, jeśli wybieramy się np na wakacje do tureckich kurortów.

## Kurs HUF/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-hufpln-1-lutego-2024-r/4032gbp](https://businessinsider.com.pl/gielda/kursy-walut/kurs-hufpln-1-lutego-2024-r/4032gbp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:46+00:00

Poznaj bieżące notowanie kursu węgierskiego forinta wraz ze zmianami w odniesieniu dziennym i tygodniowym. Poniższe dane dotyczą kursu HUF na dzień 1 lutego 2024. Czy złoty wzmacania się, czy traci? Pokazujemy to na wykresie i w danych poniższego artykułu.

## Kurs DKK/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dkkpln-1-lutego-2024-r/q1nbwg9](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dkkpln-1-lutego-2024-r/q1nbwg9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:41+00:00

Interesuje cię wymiana waluty i chcesz poznać bieżący kurs korony duńskiej? Tutaj znajdziesz aktualne notowania DKK i będziesz mógł sprawdzić, czy polski złoty umacnia się, czy słabnie względem tej waluty. Wczoraj kurs wynosił: 0,58055 zł.

## Kurs SEK/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-sekpln-1-lutego-2024-r/qn5xq4e](https://businessinsider.com.pl/gielda/kursy-walut/kurs-sekpln-1-lutego-2024-r/qn5xq4e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:36+00:00

Przedstawiamy bieżące notowania kursu waluty SEK do polskiego złotego oraz zmiany w ujęciu tygodniowym i dzień po dniu na 1 lutego 2024. Wczoraj kurs korony szwedzkiej wynosił: 0,38475 zł.

## Kurs NOK/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-nokpln-1-lutego-2024-r/5yq7bc7](https://businessinsider.com.pl/gielda/kursy-walut/kurs-nokpln-1-lutego-2024-r/5yq7bc7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:26+00:00

Sprawdź, jak zmienia się kurs korony norweskiej. Wczoraj wynosił 0,38055 zł. Jeśli chcesz dowiedzieć się, ile za koronę norweską trzeba zapłacić w tej chwili, przeczytaj poniższy artykuł.

## Kurs CZK/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-czkpln-1-lutego-2024-r/kzfb9qf](https://businessinsider.com.pl/gielda/kursy-walut/kurs-czkpln-1-lutego-2024-r/kzfb9qf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:21+00:00

Poznaj kurs korony czeskiej na dzień 1 lutego 2024. Jak wyglądają jej aktualne notowania oraz ile wynosi wartość korony względem złotego? Wczoraj kurs korony czeskiej wynosił: 0,1744 zł.

## Kurs GBP/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-1-lutego-2024-r/vb49mkj](https://businessinsider.com.pl/gielda/kursy-walut/kurs-gbppln-1-lutego-2024-r/vb49mkj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:16+00:00

W tym artykule znajdują się informacje o bieżącym kursie funta brytyjskiego 1 lutego 2024. Wczorajszy 5,0775 zł jak zmienił się dziś? Sprawdzisz poniżej.

## Kurs CHF/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-1-lutego-2024-r/t9br3tg](https://businessinsider.com.pl/gielda/kursy-walut/kurs-chfpln-1-lutego-2024-r/t9br3tg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:12+00:00

Poznaj bieżący kurs franka szwajcarskiego na dzień 1 lutego 2024. CHF to waluta, która przede wszystkim interesuje osoby mające kredyt we frankach. Czy polska waluta wzmocniła się, czy osłabła? Wczoraj kurs szwajcarskiej waluty wynosił 4,6423 zł. Jak wygląda dzisiejszy kurs CHF/PLN, sprawdzisz w tym artykule.

## Kurs USD/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-1-lutego-2024-r/84nw5ny](https://businessinsider.com.pl/gielda/kursy-walut/kurs-usdpln-1-lutego-2024-r/84nw5ny)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:06+00:00

Zobacz aktualne notowania waluty USD. Pokazujemy, jak zmienia się kurs amerykańskiej waluty w stosunku do polskiej złotówki. Czy PLN umacnia się, czy słabnie? Wczoraj kurs USD wynosił 4,00185 zł.

## Kurs EUR/PLN 1 lutego 2024 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-1-lutego-2024-r/k9ptthf](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-1-lutego-2024-r/k9ptthf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:02+00:00

Poznaj konwersje kursu EUR/PLN dla dnia 1 lutego 2024. Jak dziś wygląda euro względem złotego? Jak silna jest najważniejsza waluta w Unii Europejskiej? Czy aktualnie opłaca się wymieniać euro na polskie złotówki? Wczoraj wartość euro wyniosła: 4,3282 zł.

## TVP, fuzja Orlenu i Lotosu, Pegasus. Mateusz Morawiecki rozlicza się z rządów PiS [WYWIAD]
 - [https://businessinsider.com.pl/wiadomosci/cpk-fuzja-orlenu-i-lotosu-pegasus-mateusz-morawiecki-rozlicza-sie-z-rzadow-pis-wywiad/b0kx82y](https://businessinsider.com.pl/wiadomosci/cpk-fuzja-orlenu-i-lotosu-pegasus-mateusz-morawiecki-rozlicza-sie-z-rzadow-pis-wywiad/b0kx82y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:00+00:00

Kilkakrotnie upewniałem się u ministra koordynatora służb specjalnych i jego zastępcy, czy za każdym razem jest decyzja i zgoda sądu na użycie kontroli operacyjnej – mówi o Pegasusie w wywiadzie dla Business Insider Polska były premier Mateusz Morawiecki. Zapewnia, że jest gotów bronić kluczowych inwestycji swojego rządu. — Chcemy być opozycją z ofertą dla Polaków, z gotowymi programami i ustawami — zapowiada były szef rządu.

## W tym kwartale Google przeznaczy 700 mln dol. na odprawy
 - [https://businessinsider.com.pl/praca/google-przeznaczy-700-mln-dol-na-odprawy/bv27crj](https://businessinsider.com.pl/praca/google-przeznaczy-700-mln-dol-na-odprawy/bv27crj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2024-02-01T05:00:00+00:00

Miliardy dolarów wydała spółka Alphabet, właściciel Google, na odprawy wypłacane zwalnianym pracownikom w ubiegłym roku. W sumie zwolniono 12 tys. osób. Karuzela jeszcze się nie zatrzymała, bo w budżecie na 2024 r. firma zaplanowała 700 mln dol. na odprawy.

