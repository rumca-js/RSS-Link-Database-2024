# Source:Home RenoVision DIY, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnorhjQR4zJkT7AVNhu395Q, language:en

## 3 Ways to Set a Fence Post (+1 Bonus Method)
 - [https://www.youtube.com/watch?v=AFpYCU6Nvrs](https://www.youtube.com/watch?v=AFpYCU6Nvrs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnorhjQR4zJkT7AVNhu395Q
 - date published: 2024-02-01T22:00:04+00:00

Today I'm comparing four different ways to anchor a fence or deck post. Cheers!

Need Answers or Advice for your DIY Project?

BECOME A DIY MEMBER NOW! Click 👇🏼
https://www.youtube.com/c/HomeRenoVisionDIY/membership
► Get FULL access to me and my team for Q and A’s in the DIY Crew Forum
► Participate in LIVE streams for live consulting and Member support!

🔨 PRODUCTS IN THIS VIDEO 🔨


Shop Jeff’s favorite tools and great products and help support our next project!

► Shop Wayfair 🇨🇦: http://www.jdoqocy.com/click-9148559-14525657
► Shop Wayfair 🇺🇸: http://www.jdoqocy.com/click-9148559-14524913
► Shop Amazon 🇨🇦: https://amzn.to/3g5Wdyq
► Shop Amazon 🇺🇸: https://www.amazon.com/shop/homerenovisiondiy
► Shop Home Depot: https://homedepot.sjv.io/nBVOX
► For up to date discounts visit our website:  
 https://homerenovisiondiy.com

Power your handyman or home service business with Jobber👇🏼
Free 14-Day Trial + 20% off for 6 Months:  https://getjobber.com/homerenovisiondiy/

Sign up fo

