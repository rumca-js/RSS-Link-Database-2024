# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Three Kansas City Chiefs fans found frozen and dead outside HIV scientist's home had TRIPLE the amount of fentanyl needed to kill in their systems, as well as cocaine and THC, family source claims
 - [https://www.dailymail.co.uk/news/article-13035575/kansas-city-chiefs-fans-dead-cocaine-drugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035575/kansas-city-chiefs-fans-dead-cocaine-drugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:43:03+00:00

A toxicology report discovered the three Kansas City Chiefs fans and friends found dead at their HIV scientist friend's home had fentanyl, cocaine and other illegal drugs in their system.

## Cops reveal there is no evidence 'gas the jews' was shouted at pro-Palestine Sydney Opera House protest: This is the intimidating phrase yelled out instead
 - [https://www.dailymail.co.uk/news/article-13035697/gas-jews-comment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035697/gas-jews-comment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:42:51+00:00

The anti-Semitic phrase 'gas the Jews' was not said during the infamous protest at the Sydney Opera House, a NSW Police investigation has found.

## Nationwide hikes mortgage prices as interest rates put on hold - in wake of a similar move by rival Santander
 - [https://www.dailymail.co.uk/news/article-13035465/nationwide-mortgage-prices-rise-rates-hold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035465/nationwide-mortgage-prices-rise-rates-hold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:41:46+00:00

Nationwide said it would put up rates on some of its home loan products just a week after announcing cuts - and in the wake of a similar recent move by rival Santander.

## Teenage son of Israeli diplomat, 19, will NOT escape charges for 'intentionally driving motorcycle into Florida cop' after attempting to claim diplomatic immunity
 - [https://www.dailymail.co.uk/news/article-13035431/Teenage-son-Israeli-diplomat-charges-motorcycle-Florida-cop-diplomatic-immunity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035431/Teenage-son-Israeli-diplomat-charges-motorcycle-Florida-cop-diplomatic-immunity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:33:56+00:00

The teenage son of an Israeli diplomat will not escape charges for 'intentionally driving motorcycle into a Florida cop' after attempting to claim diplomatic immunity.

## Biden calls Trump a 'sick f***' and a 'f***ing a**hole' in private: Joe blasts his rival for celebrating the hammer attack on Paul Pelosi and others having misfortunes
 - [https://www.dailymail.co.uk/news/article-13035573/Biden-calls-Trump-sick-f-f-ing-hole-private-Joe-blasts-rival-celebrating-hammer-attack-Paul-Pelosi-having-misfortunes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035573/Biden-calls-Trump-sick-f-f-ing-hole-private-Joe-blasts-rival-celebrating-hammer-attack-Paul-Pelosi-having-misfortunes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:33:04+00:00

President Joe Biden has referred to predecessor Donald Trump as a 'sick f***' in private comments, according to a new report, with the president expressing revulsion at Trump's Paul Pelosi jokes.

## Pro-Palestinian protesters chant 'f*** Joe Biden' and accuse him of genocide as they are face off with riot cops in tense scenes in Michigan
 - [https://www.dailymail.co.uk/news/article-13035637/Pro-Palestinian-protesters-chant-f-Joe-Biden-accuse-genocide-face-riot-cops-tense-scenes-Michigan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035637/Pro-Palestinian-protesters-chant-f-Joe-Biden-accuse-genocide-face-riot-cops-tense-scenes-Michigan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:24:13+00:00

Demonstrators in Warren were surrounded by riot cops as they shouted 'Biden Biden can't you see, you are on a killing spree'.

## How Trump's mugshot and indictments led to enormous spikes in campaign fundraising that's been used to pay nearly $50M in legal fees
 - [https://www.dailymail.co.uk/news/article-13035251/trumps-mugshot-indictments-president-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035251/trumps-mugshot-indictments-president-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:20:59+00:00

Former President Donald Trump's legal woes, which have set him back nearly $50 million in legal fees, also led to enormous spikes in his campaign fundraising.

## Popular Big W product is pulled off the shelves by ACCC over bottle fears
 - [https://www.dailymail.co.uk/news/article-13035429/Big-W-product-recall-ACCC-Brilliant-Basics-Sipper-Drink-bottle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035429/Big-W-product-recall-ACCC-Brilliant-Basics-Sipper-Drink-bottle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:14:22+00:00

A popular drink bottle is being pulled from the shelves across Big W stores in Australia over fears it poses a health risk to young children.

## As I blunder into middle age, I cannot count myself among those men who feel modern life is easier for women
 - [https://www.dailymail.co.uk/news/article-13035187/As-blunder-middle-age-count-men-feel-modern-life-easier-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035187/As-blunder-middle-age-count-men-feel-modern-life-easier-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:00:44+00:00

In an early fact-finding exercise about my gender identity, I once asked my mother whether she regretted that neither of her children were girls.

## Grinning Blackford hand in hand with new lover after his marriage broke down
 - [https://www.dailymail.co.uk/news/article-13035177/Grinning-Blackford-hand-hand-new-lover-marriage-broke-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035177/Grinning-Blackford-hand-hand-new-lover-marriage-broke-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T23:00:20+00:00

Former SNP Westminster leader Ian Blackford has split from his wife and started a new relationship.

## My forefather owned the Titanic, now I'm fastest to row the Atlantic
 - [https://www.dailymail.co.uk/news/article-13035171/My-forefather-owned-Titanic-Im-fastest-row-Atlantic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035171/My-forefather-owned-Titanic-Im-fastest-row-Atlantic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:59:53+00:00

A descendent of the Titanic's owner has become the fastest Scot to row the Atlantic solo.

## Mayorkas impeachment in doubt as outgoing Republican Ken Buck says he will vote AGAINST it: GOP facing disaster if one more member rejects probe over border chaos
 - [https://www.dailymail.co.uk/news/article-13035291/ken-buck-no-vote-impeach-mayorkas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035291/ken-buck-no-vote-impeach-mayorkas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:35:45+00:00

Buck came out solidly against the effort to impeach Homeland Security Sec. Alejandro Mayorkas - a defection that could potentially kill the effort.

## Five teenagers hospitalised after car smashes into tree in Townsville
 - [https://www.dailymail.co.uk/news/article-13035293/Five-teenagers-hospitalised-car-smashes-tree-Townsville.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035293/Five-teenagers-hospitalised-car-smashes-tree-Townsville.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:35:08+00:00

Five teenagers have been rushed to hospital after a car, suspected to be stolen, collided with a tree.

## Arab and Muslim leaders slam Biden for refusing to meet them in Michigan to discuss a Gaza ceasefire and accuse him of keeping trip details 'secret' to avoid protesters as he takes selfies in a restaurant
 - [https://www.dailymail.co.uk/news/article-13035133/Arab-Muslim-leaders-slam-Biden-refusing-meet-Michigan-discuss-Gaza-ceasefire-accuse-keeping-trip-details-secret-avoid-protesters-takes-selfies-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035133/Arab-Muslim-leaders-slam-Biden-refusing-meet-Michigan-discuss-Gaza-ceasefire-accuse-keeping-trip-details-secret-avoid-protesters-takes-selfies-restaurant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:34:30+00:00

Arab and Muslim leaders in Michigan asked why Biden wasn't meeting with them on his campaign trip to the state Thursday. Biden went to a black-owned business and a UAW hall on his trip.

## Kathie Lee Giffords appeals to Sheikha Moza bint Nasser of Qatar to use her 'beautiful voice and heart' to help free Israeli hostages
 - [https://www.dailymail.co.uk/news/article-13035173/kathie-lee-gifford-appeals-sheikha-qatar-israeli-hostages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035173/kathie-lee-gifford-appeals-sheikha-qatar-israeli-hostages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:33:54+00:00

Kathie Lee Giffords called out Sheikha Moza bint Nasser of Qatar in a plea for her to use her 'beautiful voice and heart' to help free the Israeli hostages held in Gaza.

## Rust crew members raised concerns over armorer Hannah Gutierrez's 'drug and alcohol use' during filming of the doomed film, prosecutors say as her trial looms
 - [https://www.dailymail.co.uk/news/article-13035105/rust-shooting-crew-warnings-hannah-gutierrez-drug-alcohol-use-Alec-Baldwin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035105/rust-shooting-crew-warnings-hannah-gutierrez-drug-alcohol-use-Alec-Baldwin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:30:58+00:00

Rust crew members have raised concerns about the armorer, Hannah Gutierrez  over her 'drug and alcohol use,' prosecutors say. She faces trial over the movie-set shooting next month.

## Queen Camilla and Princess Anne are 'holding up the ceiling' while both King Charles and Kate Middleton are recuperating from surgery and Prince William is supporting the Princess of Wales
 - [https://www.dailymail.co.uk/news/article-13035451/queen-camilla-princess-anne-royal-duties-king-charles-kate-middleton-health-recovery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035451/queen-camilla-princess-anne-royal-duties-king-charles-kate-middleton-health-recovery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:29:26+00:00

Yesterday, Queen Camilla, 76, was cheered by around 1,000 excited, flag-waving schoolchildren in Bath as she completed her third engagement in as many days.

## Missouri cops say shooting death of fire chief's ex-fiancée WAS 'suspicious' and is still being probed - as lawmen wait for toxicology report in death of his current girlfriend
 - [https://www.dailymail.co.uk/news/article-13035075/Robert-Daus-fire-chief-fiancee-girlfriend-death-suspicious.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035075/Robert-Daus-fire-chief-fiancee-girlfriend-death-suspicious.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:28:41+00:00

Aired by the St. Louis cops Wednesday, the revelation comes days after the body of Sarah Sweeney was found in Robert Daus's home in suburban Maryland Heights.

## Brazilian soccer star, 18, is under investigation after over death of  nursing student, 19, who had FOUR 'heart attacks' after night of sex
 - [https://www.dailymail.co.uk/news/article-13033661/brazilian-soccer-star-investigation-student-dies-heart-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033661/brazilian-soccer-star-investigation-student-dies-heart-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:28:13+00:00

An aspiring nurse died after going into cardiac arrest four times following sex on her first date with a Brazilian soccer player in São Paulo on Tuesday evening.

## Ron DeSantis sends up to 1,000 Florida National Guard troops to the Texas-Mexico border to 'stop this invasion once and for all' because Biden doesn't have 'the will to get the job done'
 - [https://www.dailymail.co.uk/news/article-13035053/ron-desantis-border-national-guard-mexico-texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035053/ron-desantis-border-national-guard-mexico-texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:28:04+00:00

Florida Gov. Ron DeSantis announced Thursday that he will send up to a battalion of National Guardsmen to strengthen border security in Texas.

## Do groundhogs come out in February? Who is Punxsutawney Phil? What about its shadow? All the answers to your most confusing Groundhog Day questions
 - [https://www.dailymail.co.uk/news/article-13034887/groundhog-day-punxsutawney-phil-shadow-spring-winter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034887/groundhog-day-punxsutawney-phil-shadow-spring-winter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:22:46+00:00

It's almost time for everyone to find out if spring is on its way or if they need to prepare for six more weeks of winter.

## Clapham chemical attacker: Map shows suspect Abdul Ezedi's escape path across London as manhunt for sex offender that left mother and child with life changing injuries intensifies
 - [https://www.dailymail.co.uk/news/article-13035141/clapham-chemical-attack-abdul-ezedi-map-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035141/clapham-chemical-attack-abdul-ezedi-map-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:21:10+00:00

Convicted sex offender and asylum seeker Abdul Shokoor Ezedi, 35, attacked the family-of-three with an as-yet-unknown alkaline chemical at 7.25pm on Wednesday night.

## Melania's stylist has raked in more than $100,000 in 'consulting fees' from Trump Super PAC: New financial records show ex-president is bleeding money to his lawyers and former first lady's fashion guru
 - [https://www.dailymail.co.uk/news/article-13035145/melanias-stylist-consulting-fees-trump-super-pac.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035145/melanias-stylist-consulting-fees-trump-super-pac.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:20:21+00:00

Melania Trump's stylist raked in over $100,000 from Donald Trump's super PAC in the last six months of 2023 as the former president bled money in legal fees.

## Thug admits smashing glass into face of ex-Leeds Rhino star 'blinding him in both eyes' in horrific Boxing Day brawl - as victim's family demands attacker is jailed for life
 - [https://www.dailymail.co.uk/news/article-13035347/Thug-admits-smashing-glass-face-ex-Leeds-Rhino-star-blinding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035347/Thug-admits-smashing-glass-face-ex-Leeds-Rhino-star-blinding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:19:17+00:00

Gareth Dean, 37, attacked Matthew Syron as he walked back from the toilet at Revolución de Cuba in Leeds city centre on December 26.

## Mariella Frostrup blasts NHS 'ageism' as women are denied smear testing when they pass the age of 64
 - [https://www.dailymail.co.uk/news/article-13035261/Mariella-Frostrup-NHS-ageism-smear-test-64.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035261/Mariella-Frostrup-NHS-ageism-smear-test-64.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:17:08+00:00

Mariella Frostrup, 61,who founded the Menopause Mandate with Davina McCall and Penny Lancaster in 2022, said this is a 'further women's health outrage'.

## Kansas city says it WANTS migrants to move there with $15,000 'Choose Topeka' campaign to lure border crossers to the Dem-led city to fill 7,000 open jobs
 - [https://www.dailymail.co.uk/news/article-13034543/Kansas-city-says-WANTS-migrants-15-000-Choose-Topeka-campaign-lure-border-crossers-Dem-led-city-7-000-open-jobs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034543/Kansas-city-says-WANTS-migrants-15-000-Choose-Topeka-campaign-lure-border-crossers-Dem-led-city-7-000-open-jobs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:17:05+00:00

Cities like New York, Chicago , and Denver are struggling to care for 100,000 migrants bussed in from Texas as up to 10,000 cross the border every day - but Topeka, Kansas, wants more.

## Queenslander wins $200million Powerball prize: 'What a way to kick off 2024!'
 - [https://www.dailymail.co.uk/news/article-13035393/Queenslander-wins-100million-Powerball-prize-way-kick-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035393/Queenslander-wins-100million-Powerball-prize-way-kick-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:14:38+00:00

Officials from The Lott are on the hunt for the second division one winner in last night's $200 million record-breaking Powerball draw.

## Living up to its name! South Dakota burger joint Swamp Daddy's is closed after lime green slime turned kitchen into a quagmire due to a chemical spill
 - [https://www.dailymail.co.uk/news/article-13035065/South-Dakota-Swamp-Daddys-closed-glycol-slime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035065/South-Dakota-Swamp-Daddys-closed-glycol-slime.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T22:11:25+00:00

Swamp Daddy's in Sioux Falls was doused in lime green glycol slime after a HVAC company hit a pipe while moving the furnace in a condo.

## Atlanta actor LaKeith Stanfield is sued by $500-a-day nanny over 'harrowing' trip to NYC where she claims she endured sleepless nights and didn't have time to eat because of their 'constant demands' - and then failed to pay her
 - [https://www.dailymail.co.uk/news/article-13034937/LaKeith-Stanfield-sued-nanny-harrowing-trip-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034937/LaKeith-Stanfield-sued-nanny-harrowing-trip-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:58:53+00:00

Atlanta actor LaKeith Stanfield has been sued by his travel nanny over a 'harrowing' trip to New York City where she claims she endured sleepless nights because of his 'constant demands.'

## United Airlines hangar at Bush Intercontinental Airport is COVERED in fire suppression foam after it was accidentally triggered
 - [https://www.dailymail.co.uk/news/article-13035121/foam-United-Airlines-hangar-Bush-Intercontinental-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035121/foam-United-Airlines-hangar-Bush-Intercontinental-Airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:48:01+00:00

Biodegradable fire suppression foam blanketed a lot on Wright Road. The Houston airport said it would have no impact on flights - but it was unclear how long cleanup efforts would take.

## Killers of the Flower Moon producer Bradley Thomas' wife, 39, jumps to her death from Los Angeles hotel
 - [https://www.dailymail.co.uk/news/article-13034973/Killers-Flower-Moon-producer-Bradley-Thomas-wife-39-jumps-death-Los-Angeles-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034973/Killers-Flower-Moon-producer-Bradley-Thomas-wife-39-jumps-death-Los-Angeles-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:35:47+00:00

Bradley Thomas's wife Isabelle, 39, jumped to her death on Monday night at the Hotel Angeleno.

## Washington State girl, 14, who went missing with 'man she met on Discord' near notorious sex trafficking corridor has been FOUND: Michigan man arrested over kidnapping
 - [https://www.dailymail.co.uk/news/article-13034633/washington-state-girl-missing-discord-sex-trafficking-michigan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034633/washington-state-girl-missing-discord-sex-trafficking-michigan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:35:24+00:00

A 14-year-old teen from Washington State , who went missing with a 'man she met on Discord,' has been found and a Michigan man has been arrested over her kidnapping.

## Berowra train deaths: Man and woman are hit and killed as details are revealed of shocking incident
 - [https://www.dailymail.co.uk/news/article-13035253/berowra-train-man-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035253/berowra-train-man-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:34:41+00:00

Emergency services were called to Berowra Railway Station, in the city's north, after midnight on Friday following reports two people had been hit by a train.

## 'Get them all and send them back!' NY Gov. Kathy Hochul steps up her u-turn on welcoming migrants after shameful attack on NYPD cops in Times Square - with cops saying they have 'fled on bus to California'
 - [https://www.dailymail.co.uk/news/article-13035077/ny-governor-kathy-hochul-deport-migrants-nypd-assault-times-square.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035077/ny-governor-kathy-hochul-deport-migrants-nypd-assault-times-square.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:31:50+00:00

New York Governor Kathy Hochul repeated her comments that the migrants responsible for the brutal attack on two police officers in Times Square should be deported.

## Pouting OnlyFans model Courtney Clenney pleads not guilty to additional felony charge over stabbing her boyfriend to death
 - [https://www.dailymail.co.uk/news/article-13034823/courtney-clenney-onlyfans-model-pleads-not-guilty-new-felony-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034823/courtney-clenney-onlyfans-model-pleads-not-guilty-new-felony-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:29:21+00:00

Clenney, 27, appeared in court on Thursday to face a new charge of interception of wire communications.

## Retired cop who caused his wife of 45 years to fall down the stairs, breaking 19 ribs, her spine and rupturing her aorta, before leaving her to die jailed for nine years
 - [https://www.dailymail.co.uk/news/article-13035179/Retired-cop-wife-stairs-die-jailed-nine-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035179/Retired-cop-wife-stairs-die-jailed-nine-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:24:58+00:00

Alan Claxton caused fellow former Northumbria Police officer Wendy Claxton to fall down the stairs of their home in Gateshead with the kind of 'massive force' usually seen in car accidents.

## Trump leads Nikki Haley by 26 points in rare poll of her home state of South Carolina as 60 percent of Republicans say it doesn't matter if former president is convicted over 2020 election
 - [https://www.dailymail.co.uk/news/article-13034621/donald-trump-leads-nikki-haley-26-points-south-carolina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034621/donald-trump-leads-nikki-haley-26-points-south-carolina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:20:46+00:00

Former President Donald Trump is leading rival Nikki Haley by 26 points in a poll released Thursday of South Carolina's Republican voters.

## Republicans demand Biden donor who connected Hunter with his bong-smoking $6.5M 'sugar brother' to sit for interview: Hollywood producer Lanette Phillips is next up on witness list as impeachment inquiry picks up steam
 - [https://www.dailymail.co.uk/news/article-13034967/biden-donor-lanette-phillips-impeachment-inquiry-hunter-joe-biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034967/biden-donor-lanette-phillips-impeachment-inquiry-hunter-joe-biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:08:20+00:00

The Hollywood producer who introduced Hunter Biden to his 'sugar brother' Kevin Morris is next up to face questioning by Republicans leading the impeachment inquiry into Joe Biden.

## Georgia high school parking lot shooting: Two shot during fight between two gangs while students were in classes
 - [https://www.dailymail.co.uk/news/article-13035051/McEachern-high-school-georgia-shooting-gang-fight-two-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035051/McEachern-high-school-georgia-shooting-gang-fight-two-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:07:23+00:00

Two people were shot and sustained non-life-threatening injuries after the incident at McEachern High School, situated 22 miles northwest of Atlanta, according to authorities.

## Developers revive plans to build new homes on the site where vulnerable teenager Margaret Fleming was murdered by her carers
 - [https://www.dailymail.co.uk/news/article-13035059/developers-new-homes-teenager-Margaret-Fleming-Murdered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13035059/developers-new-homes-teenager-Margaret-Fleming-Murdered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T21:04:58+00:00

The plans would see the properties built on top of the now demolished cottage in Inverkip, Inverclyde, where police believe Miss Fleming was murdered by her carers.

## Revealed: Six people have died on TfL Tubes or buses in past six weeks including woman who fell down Piccadilly Circus stairs
 - [https://www.dailymail.co.uk/news/article-13034981/Six-people-died-TfL-Tubes-buses-six-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034981/Six-people-died-TfL-Tubes-buses-six-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:59:18+00:00

Four died after being hit by buses - including Catherine Finnegan, 56, who died following a fatal smash at London Victoria earlier this week.

## The cracks that slashed price of Grand Designs' 'saddest ever' house: Photos show damage to mansion's driveway after the property's asking price was cut from £10million to £5.25million
 - [https://www.dailymail.co.uk/news/article-13034527/grand-designs-saddest-house-photos-damage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034527/grand-designs-saddest-house-photos-damage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:52:41+00:00

Chesil Cliff House in Croyde, Devon became infamous after its construction left owner Edward Short £7million in debt. It took 12 years to build and went millions of pounds over budget.

## Man accused of murdering sex worker Emma Caldwell told police he tried to pick up alleged victim - and says he's used prostitutes for 12 years, court hears
 - [https://www.dailymail.co.uk/news/article-13034989/Man-accused-murdering-sex-worker-Emma-Caldwell-told-police-tried-pick-alleged-victim-says-hes-used-prostitutes-12-years-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034989/Man-accused-murdering-sex-worker-Emma-Caldwell-told-police-tried-pick-alleged-victim-says-hes-used-prostitutes-12-years-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:49:43+00:00

In an interview weeks after the body of Emma Caldwell was found, Iain Packer said there was one occasion when he had intended to pick her up but she had gone by the time he returned

## Christian preacher, 72, is convicted of breaching police order for protesting against abortion inside 'buffer zone' surrounding family planning clinic
 - [https://www.dailymail.co.uk/news/article-13034723/christian-preacher-convicted-breaching-police-order-abortion-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034723/christian-preacher-convicted-breaching-police-order-abortion-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:40:41+00:00

Stephen Green held a sign with a religious verse on it inside a zone near a family clinic which was covered by a Protection Order in west London in February last year.

## Two students are stabbed at Queens high school: Campus is on lockdown and kids are rushed to hospital with stomach and shoulder wounds
 - [https://www.dailymail.co.uk/news/article-13034863/Two-students-stabbed-Queens-high-school-Campus-lockdown-kids-rushed-hospital-stomach-shoulder-wounds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034863/Two-students-stabbed-Queens-high-school-Campus-lockdown-kids-rushed-hospital-stomach-shoulder-wounds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:29:37+00:00

The incident happened at Martin Van Buren High School in the Queens borough of the city just before 2pm. One student was stabbed in the stomach and the other in the shoulder.

## Armed man barricades himself in room in $900-a-night Waldorf Astoria in Beverly Hills
 - [https://www.dailymail.co.uk/news/article-13034935/armed-man-barricades-waldorf-astoria-beverly-hills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034935/armed-man-barricades-waldorf-astoria-beverly-hills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:28:26+00:00

An armed man has barricaded himself in a $900-a-night room in the Beverly Hills Waldorf Astoria.

## Bristol stabbing: Two boys, 15 and 16, are charged with murder of teenagers Mason Rist and Max Dixon
 - [https://www.dailymail.co.uk/news/article-13034913/Two-boys-15-16-charged-murder-teenagers-Mason-Rist-Max-Dixon-Bristol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034913/Two-boys-15-16-charged-murder-teenagers-Mason-Rist-Max-Dixon-Bristol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:23:07+00:00

Two boys, 15 and 16, have been charged with murder of teenagers Mason Rist and Max Dixon in Bristol.

## Killer builder bludgeoned customer to death on his FIRST job: Jehovah's Witness's wife says he was 'completely normal' for three days after attack - and claims she handed his bloodied work clothes to cops after finding them in a bin
 - [https://www.dailymail.co.uk/news/article-13034603/killer-cowboy-builder-wife-reveals-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034603/killer-cowboy-builder-wife-reveals-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:22:45+00:00

Peter Norgrove, 43, repeatedly beat customer Sharon Gordon, 58, over the head with a hammer at her home in Dudley, West Midlands last July.

## Seven-month pregnant Arkansas mom is pounced on by attempted kidnapper who broke into her car and waited for her before trying to rip her daughter out of her arms in Walmart parking lot
 - [https://www.dailymail.co.uk/news/article-13034707/Pregnant-Arkansas-mom-kidnapper-broke-car-daughter-Walmart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034707/Pregnant-Arkansas-mom-kidnapper-broke-car-daughter-Walmart.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:21:56+00:00

Timothy Caudle (right), 58, has been accused of attempting kidnap the toddler from the car of her mother Mikayla Ferguson (left) while it was parked outside a Walmart.

## Out CBS reporter says admins at his Louisiana Catholic school wanted to keep his interview with English teacher who helped him understand his sexuality and Tourette's in the closet so today's students 'didn't get the impression that being gay is OK'
 - [https://www.dailymail.co.uk/news/article-13034523/cbs-reporter-claims-banned-catholic-school-hes-gay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034523/cbs-reporter-claims-banned-catholic-school-hes-gay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:21:13+00:00

David Begnaud - the lead national correspondent for CBS Mornings - made the claim in an opinion piece published Wednesday, alleging anti-gay discrimination.

## Met Police chief Sir Mark Rowley DEFENDS special constable who told busker not to sing 'church songs' on Oxford Street - saying she was 'doing her best' when she got the law wrong then stuck her tongue out at the public
 - [https://www.dailymail.co.uk/news/article-13034729/Met-Police-chief-Sir-Mark-Rowley-says-special-constable-told-Christian-busker-not-sing-church-songs-Oxford-Street-mistake-trying-best-reveals-shes-suffered-massive-racist-abuse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034729/Met-Police-chief-Sir-Mark-Rowley-says-special-constable-told-Christian-busker-not-sing-church-songs-Oxford-Street-mistake-trying-best-reveals-shes-suffered-massive-racist-abuse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:20:51+00:00

The Met Commissioner, Sir Mark Rowley , said that special constable Maya Hadzhipetkova made a mistake when dealing a young Gospel singer on Oxford Street

## Billionaire investor says a 'Trump rally' is powering markets to record highs
 - [https://www.dailymail.co.uk/news/article-13034605/soros-market-donald-trump-rally-record-scott-bessent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034605/soros-market-donald-trump-rally-record-scott-bessent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:19:13+00:00

Billionaire investor Scott Bessent, a former Soros Fund Management chief, says rising markets are fueled by polls that show the former president can beat Joe Biden in November's election.

## The deadly Venezuelan gangster INVASION: Inside the chilling Miami 'honeytrap' murder plot by migrant mobsters that should finally wake up liberal America to Biden's broken border fiasco
 - [https://www.dailymail.co.uk/news/article-13004257/border-crisis-miami-murder-venezuela-gang-tren-aragua.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13004257/border-crisis-miami-murder-venezuela-gang-tren-aragua.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:18:52+00:00

The brutal murder had all the telltale signs of a street gang crime, and sure enough, a 23-year-old suspected member of Venezuela's notorious Tren de Aragua gang was arrested for the homicide.

## Two more migrants are arrested over Times Square attack on cops - as Governor Kathy Hochul finally U-turns on her pledge to keep NY a sanctuary state and threatens to DEPORT them
 - [https://www.dailymail.co.uk/news/article-13034013/migrants-arrested-times-square-assault-nypd-governor-hochul-threatens-deportation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034013/migrants-arrested-times-square-assault-nypd-governor-hochul-threatens-deportation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:18:01+00:00

Yohenry Brito, 24, and Jandry Barros, 21, were arrested and charged with Robbery and Felony Assault on Wednesday in connection to the Times Square attack on New York police officers.

## Shocking moment Indiana Rep Jim Lucas flashes a GUN at four students as young as 17 as they visited the statehouse to talk about weapons control
 - [https://www.dailymail.co.uk/news/article-13034781/Indiana-Rep-Jim-Lucas-flashes-gun-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034781/Indiana-Rep-Jim-Lucas-flashes-gun-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:08:56+00:00

Rep. Jim Lucas asked the group of kids from Burris Laboratory School in Muncie why they were at the Capitol - minutes before he decided to show them weapon.

## Disney appeals against judge slapping down its lawsuit against Ron DeSantis after Hollywood giant claimed he only took its special tax district because it criticized his 'Don't Say Gay' law
 - [https://www.dailymail.co.uk/news/article-13034615/disney-appeals-lawsuit-loss-ron-desantis-florida-tax-district.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034615/disney-appeals-lawsuit-loss-ron-desantis-florida-tax-district.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T20:00:11+00:00

Disney has filed a notice to appeal the dismissal of their lawsuit accusing Florida Governor Ron DeSantis of retaliation against the company for criticizing his so called 'Don't say gay' bill.

## Moment heroic LA cops climb onto roof of a burning building and pull woman to safety through window
 - [https://www.dailymail.co.uk/news/article-13034577/moment-la-cops-save-woman-burning-building-roof-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034577/moment-la-cops-save-woman-burning-building-roof-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:58:46+00:00

Bodycam video shows the heroic rescue of an elderly woman by Los Angeles County sheriff's deputies. One other occupant was rescued, but a 67-year-old man died at the scene.

## Police officer who had sex with 'drunk and vulnerable' woman on duty after she called 999 is found guilty of misconduct in public office - as judge warns him to expect a jail term
 - [https://www.dailymail.co.uk/news/article-13034819/police-officer-sex-drunk-vulnerable-woman-duty-guilty-misconduct.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034819/police-officer-sex-drunk-vulnerable-woman-duty-guilty-misconduct.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:58:31+00:00

Former police officer Jordan Masterson, 28, was stationed in Widnes, Cheshire when he received the 999 call. He said that 'there was no thought process' during the sexual encounter.

## Senate Republicans threaten to TANK House-passed $78BILLION tax deal over child tax credit expansion giving conservatives 'heartburn'
 - [https://www.dailymail.co.uk/news/article-13034753/Senate-Republicans-threaten-TANK-House-passed-78BILLION-tax-deal-child-tax-credit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034753/Senate-Republicans-threaten-TANK-House-passed-78BILLION-tax-deal-child-tax-credit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:54:11+00:00

Senate Republicans are threatening to tank a tax bill that passed through the House in rare bipartisan fashion.

## Hero elderly pastor, 85, is mauled to death by two stray pitbulls after he tried to chase them off his property to protect his wife
 - [https://www.dailymail.co.uk/news/article-13034673/Hero-elderly-pastor-85-mauled-death-two-stray-pitbulls-tried-chase-property-protect-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034673/Hero-elderly-pastor-85-mauled-death-two-stray-pitbulls-tried-chase-property-protect-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:51:07+00:00

William Mundine, 85, died on Tuesday after three dogs tried to attack his wife Betty at their home in Indianapolis, Indiana, after trying to protect his wife Betty.

## Idaho murders suspect Bryan Kohberger's lawyers ask judge to change court venue because he 'can't receive a fair trial in community' where the four students were massacred in their home
 - [https://www.dailymail.co.uk/news/article-13034607/bryan-kohberger-idaho-murders-suspect-lawyers-change-court-venue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034607/bryan-kohberger-idaho-murders-suspect-lawyers-change-court-venue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:25:35+00:00

The alleged killer's public defender asked Judge John Judge to schedule a hearing no earlier than the end of April to hear arguments on the potential move,

## Ron DeSantis blew through $160 million, including $3.3 million on private jets in one of most expensive ever Republican campaigns
 - [https://www.dailymail.co.uk/news/article-13033761/ron-desantis-campaign-money-private-jets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033761/ron-desantis-campaign-money-private-jets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:24:59+00:00

Ron DeSantis dropped out of the Republican presidential race after just one contest - but not before his campaign and supporters blew through $160 million.

## Just Stop Oil activist who staged protest at World Snooker Championship and disrupted his own graduation ceremony is banned from Exeter University campus as bosses say they have a 'duty of care' to other students
 - [https://www.dailymail.co.uk/news/article-13034681/just-stop-oil-activist-world-snooker-championship-protest-banned-exeter-university-campus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034681/just-stop-oil-activist-world-snooker-championship-protest-banned-exeter-university-campus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:24:44+00:00

Edred Whittingham,25,  who staged a protest at the World Snooker Championship and even disrupted his own graduation ceremony has now been banned from his old university.

## Shamed assistant headteacher sacked for stealing over £8,500 in free school meals scam to fund gambling addiction avoids jail after 'betraying' staff in 'egregious breach of trust'
 - [https://www.dailymail.co.uk/news/article-13034747/assistant-headteacher-sacked-stealing-free-school-meals-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034747/assistant-headteacher-sacked-stealing-free-school-meals-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:16:48+00:00

Daniel Reynolds, 36, pocketed the cash while being paid extra to run the Government's Holiday Activities and Food programme at his primary school.

## Vietnam war veteran, 75, dies after sheriff's deputy shocks him with TASER at his Minnesota home when he came at them with knife during attempted eviction over late rent
 - [https://www.dailymail.co.uk/news/article-13034043/minnesota-man-dies-sheriff-tasers-knife-attack-home-eviction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034043/minnesota-man-dies-sheriff-tasers-knife-attack-home-eviction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:14:08+00:00

Michael James Yanacheak, 75, died following the incident at his Willmar home on Monday. His niece said he had been suffering with mental health issues.

## Brother of Alabama prison inmate who died from fentanyl overdose retrieves his organs in plastic bag after they were 'harvested from his body without his permission'
 - [https://www.dailymail.co.uk/news/article-13034219/alabama-prison-organs-fentanyl-overdose-dead-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034219/alabama-prison-organs-fentanyl-overdose-dead-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:09:47+00:00

Kalvin Moore, 42, died at Alabama's Limestone Correctional Facility in July 2023 from a fentanyl overdose. His brother, Simone, picked up his organs in a red plastic bag after they were removed.

## Phillip Schofield sells his plush London flat where he enjoyed 'playtime' with his former 'younger' lover - after slashing the asking price
 - [https://www.dailymail.co.uk/news/article-13034505/Phillip-Schoefield-London-flat-sale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034505/Phillip-Schoefield-London-flat-sale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T19:00:01+00:00

The property was where Schofield would take his junior colleague for secret trysts before the studio runner left in a taxi paid for by ITV, his former colleague Eamonn Holmes claimed.

## House PASSES bill to deport illegal migrants arrested for driving drunk despite opposition from 150 Democrats
 - [https://www.dailymail.co.uk/news/article-13034535/house-bill-deport-illegal-migrants-driving-drunk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034535/house-bill-deport-illegal-migrants-driving-drunk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:59:16+00:00

The House passed a bill Thursday that will enable law enforcement to deport illegal migrants caught driving under the influence of drugs or alcohol.

## Hilarious moment possum porch pirate steals a bag of cookies meant as a gift for 15-year-old Texas teen
 - [https://www.dailymail.co.uk/news/article-13034383/Possum-Texas-steals-cookies-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034383/Possum-Texas-steals-cookies-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:58:49+00:00

The Southlake Police Department released a video of the hilarious moment a possum stole a 15-year-old's birthday cookies late in the night in Texas

## Captain Tom Moore's daughter looks downcast as she watches workmen remove the kitchen sink, toilet and a stereo from £200,000 spa complex after it was ordered to be torn down
 - [https://www.dailymail.co.uk/news/article-13034265/Captain-Tom-Moores-daughter-downcast-spa-complex-torn-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034265/Captain-Tom-Moores-daughter-downcast-spa-complex-torn-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:41:22+00:00

Bundled up in a black North Face coat and an orange hat, Hannah Ingram-Moore stood next to one of the workmen as builders dismantled the illegal building piece by piece.

## Columbia students boot LGBTQ group LionLez after leader said 'Holocaust wasn't special' and 'Israelites are the Nazis' in the wake of Hamas' October 7 attack
 - [https://www.dailymail.co.uk/news/article-13034011/columbia-derecognize-lgbtq-lionlez-group-antisemitic-comments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034011/columbia-derecognize-lgbtq-lionlez-group-antisemitic-comments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:35:44+00:00

The Columbia Student Governing Board (SGB) derecognized LionLez, a group for queer and non-binary students, following controversy over its leader's anti-Semitic comments.

## Police release new photo of Clapham chemical attacker with 'significant' injuries to his face: Image shows convicted sex offender buying water in Tesco in north London - after dousing mother and her two children with alkaline substance
 - [https://www.dailymail.co.uk/news/article-13034465/Fugitive-wanted-chemical-attack-mother-two-daughters-convicted-sex-offender-police-carry-nationwide-manhunt-flood-street-north-London-seen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034465/Fugitive-wanted-chemical-attack-mother-two-daughters-convicted-sex-offender-police-carry-nationwide-manhunt-flood-street-north-London-seen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:18:39+00:00

Police said that 35-year-old Abdul Shokoor Ezedi is a 'dangerous' fugitive from the Newcastle area and has 'significant injuries to the right side of his face'

## Two Brooklyn men wrongly jailed for decades for killing French tourist, 71, in brutal mugging in NYC on New Year's Day in 1987 leave court after judge exonerates them - and they tell him 'we never were' criminals
 - [https://www.dailymail.co.uk/news/article-13033971/eric-smokes-david-warren-exonerated-murder-new-york.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033971/eric-smokes-david-warren-exonerated-murder-new-york.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:18:36+00:00

Eric Smokes, who was 19 when he was arrested, and his best friend David Warren, who was 16, were accused of murdering 71-year-old Frenchman Jean Casse in 1987.

## Body of high-ranking Sinaloa Cartel is dumped on Mexico highway beside 310kg of drugs, including fentanyl and crystal meth: Killers hung 'narco sign' on overpass reading - 'We are not desperate enough to traffic this garbage'
 - [https://www.dailymail.co.uk/news/article-13029553/Sinaloa-Cartel-leader-dumped-road-fentanyl-drugs-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13029553/Sinaloa-Cartel-leader-dumped-road-fentanyl-drugs-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:17:23+00:00

José Carrera, a high-ranking Sinaloa Cartel who was kidnapped in August, was found dead Saturda on a highway in Parral, a city in the northern Mexico state of Chihuahua.

## Women who claim they met Gilgo Beach serial killer suspect Rex Heuermann speak out about terrifying encounters - and say they barely escaped with their lives
 - [https://www.dailymail.co.uk/news/article-13029469/woman-met-gilgo-beach-serial-killer-suspect-rex-heuermann.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13029469/woman-met-gilgo-beach-serial-killer-suspect-rex-heuermann.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:17:03+00:00

John Ray, the attorney for Shannan Gilbert's family, held a symposium on the Gilgo case at St. John's University where he introduced witnesses who have given sworn affidavits.

## Utah teenager, 19, dies after falling 1,400ft into popular canyon as he tried to take a photograph - as his family pays tribute
 - [https://www.dailymail.co.uk/news/article-13033801/utah-teenager-dies-taking-photograph-moonscape-overlook.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033801/utah-teenager-dies-taking-photograph-moonscape-overlook.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:14:44+00:00

A 19-year-old Utah teen tragically died after fallling 1,400 feet to his death at a popular canyon when he tried to to take a photograph as his devastated family pays tribute.

## PETA attacks Joe Biden's inauguration poet Amanda Gorman for backing milk-sponsored women's marathon - as it argued she should stop 'exploitation done to females of any species'
 - [https://www.dailymail.co.uk/news/article-13034301/PETA-attacks-poet-Amanda-Gorman-milk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034301/PETA-attacks-poet-Amanda-Gorman-milk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:14:18+00:00

Amanda Gorman, 25, recently joined forces with MilkPEP to advertise the inaugural Every Woman's Marathon - and she featured in a clip this week reciting a poem as women trained in the background.

## Michigan school shooter's mother Jennifer Crumbley takes the stand in her own defense after breaking down in tears when court read out his journal entries saying 'my parents won't listen to me'
 - [https://www.dailymail.co.uk/news/article-13034541/Michigan-school-shooter-ethan-jennifer-crumbley-testifies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034541/Michigan-school-shooter-ethan-jennifer-crumbley-testifies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:11:47+00:00

Jennifer Crumbley has taken the stand in her own defense in her blockbuster manslaughter trial, hours after breaking down in tears as her school shooter son's final diary entries were revealed.

## The gruesome true story behind Amityville: An Origin Story as new BBC Two drama airs
 - [https://www.dailymail.co.uk/news/article-13022607/The-gruesome-true-story-Amityville-Origin-Story-new-BBC-Two-drama-airs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13022607/The-gruesome-true-story-Amityville-Origin-Story-new-BBC-Two-drama-airs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:00:46+00:00

It has been nearly five decades since  the Lutz family ran away from their Amityville home in Long Island, after alleging it was plagued with evil spirits. But what's the real tale behind the horror house?

## Will Harry and Meghan continue cashing in on their royal connections, asks RICHARD EDEN? Their attempts to make films about OTHER people have had little success, so far...
 - [https://www.dailymail.co.uk/news/article-13032123/Harry-Meghan-making-money-royal-connections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032123/Harry-Meghan-making-money-royal-connections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T18:00:07+00:00

Harry and Meghan seem to face a growing dilemma as the end of their Netflix contract nears, says Richard Eden. Do they continue trying to prove themselves as independent film makers?

## Madeleine McCann suspect Christian Brueckner 'drew sketches of child rape and wrote about abducting a woman and a juvenile', German prosecutor reveals
 - [https://www.dailymail.co.uk/news/article-13034387/Madeleine-McCann-suspect-Christian-Brueckner-drew-sketches-child-rape-wrote-abducting-woman-juvenile-German-prosecutor-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034387/Madeleine-McCann-suspect-Christian-Brueckner-drew-sketches-child-rape-wrote-abducting-woman-juvenile-German-prosecutor-reveals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:55:16+00:00

German prosecutor Hans Christian Wolters said the evidence came via various sketchbooks and notebooks seized from the 47-year-old suspect, who is serving a seven-year prison sentence for rape.

## Sexting shame MP Simon Danczuk - who exited the Commons amid an explicit messages scandal - plots return to Parliament as Reform UK's candidate at Rochdale by-election
 - [https://www.dailymail.co.uk/news/article-13034479/Sexting-shame-MP-Simon-Danczuk-exited-Commons-amid-explicit-messages-scandal-plots-return-Parliament-Reform-UKs-candidate-Rochdale-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034479/Sexting-shame-MP-Simon-Danczuk-exited-Commons-amid-explicit-messages-scandal-plots-return-Parliament-Reform-UKs-candidate-Rochdale-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:52:45+00:00

The 57-year-old is hoping to be re-elected to the seat he held for Labour between 2010 and 2017 when local voters go to the polls at the end of this month.

## Neighbors of Justin Mohn, who beheaded his father, say he was 'acting strange' and smoking marijuana heavily before the gruesome murder
 - [https://www.dailymail.co.uk/news/article-13033819/justin-mohn-beheading-youtube-neighbors-acting-strange-unhinged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033819/justin-mohn-beheading-youtube-neighbors-acting-strange-unhinged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:49:36+00:00

Neighbors have described Mohn as 'weird' and 'unhinged' in the aftermath of his father's gruesome beheading death - with one man admitting to calling the police due to his past behavior.

## Biden and Trump go to war over GAFFES: Joe's campaign launches new ad saying ex-president is 'babbling' after he confused Nikki Haley with Nancy Pelosi
 - [https://www.dailymail.co.uk/news/article-13033877/joe-biden-campaign-launches-new-ad-donald-trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033877/joe-biden-campaign-launches-new-ad-donald-trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:49:04+00:00

President Joe Biden's campaign released a video Wednesday on former President Donald Trump's own Truth Social network showing him confusing Nikki Haley with Nancy Pelosi.

## Woke Squad member Ayanna Pressley claims Walgreens is RACIST for closing stores in crime-ridden areas because it is a 'disruptive, life-threatening act of racial and economic discrimination'
 - [https://www.dailymail.co.uk/news/article-13034023/ayanna-pressley-says-walgreens-racist-store-closures-high-crime-areas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034023/ayanna-pressley-says-walgreens-racist-store-closures-high-crime-areas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:47:58+00:00

The representative, who is a member of the Democrat 'Squad' said the chain was 'abandoning' low-income communities with the most recent closing in Roxbury on Wednesday.

## NYC Mayor Eric Adams' re-election bid was secretly bankrolled by business leaders in city's hotel and construction industries who reimbursed donors over $10,000, bombshell report claims
 - [https://www.dailymail.co.uk/news/article-13033919/nyc-mayor-eric-adams-reimbursed-hotel-construction-donors-funded-reelection-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033919/nyc-mayor-eric-adams-reimbursed-hotel-construction-donors-funded-reelection-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:40:12+00:00

It's another headache for Adams, whose tenure has been shadowed by the migrant crisis, investigations into his fundraising and allegations of straw-donor schemes.

## Alarm bells for Rishi Sunak as poll shows Reform UK hitting new high of 14% support in the Red Wall - and a FIFTH of 2019 Tory voters are backing the Nigel Farage-founded party
 - [https://www.dailymail.co.uk/news/article-13033977/Alarm-bells-Rishi-Sunak-poll-Reform-UK-new-high.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033977/Alarm-bells-Rishi-Sunak-poll-Reform-UK-new-high.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:31:39+00:00

Research by Redfield & Wilton Strategies suggested the Nigel Farage-founded party is picking up significant support in the crucial election battleground.

## It wasn't me! Married RFK Jr. blames social media manager after his verified TikTok account is linked to lusty comment on video of scantily-clad OnlyFans model flashing her curvaceous caboose
 - [https://www.dailymail.co.uk/news/article-13028427/RFK-Jr-comment-OnlyFans-model-Tiktok-Tyler-Idol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13028427/RFK-Jr-comment-OnlyFans-model-Tiktok-Tyler-Idol.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:24:22+00:00

Robert F. Kennedy Jr. appeared to have been browsing videos of scantily-clad young women on TikTok - and even left a comment on a video of one girl who works in porn.

## Northern Ireland Assembly set to restart after two years after DUP  agrees to resume power-sharing on Saturday
 - [https://www.dailymail.co.uk/news/article-13034333/Northern-Ireland-Assembly-set-restart-two-years-DUP-Saturday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034333/Northern-Ireland-Assembly-set-restart-two-years-DUP-Saturday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:16:00+00:00

Unionist leader Sir Jeffrey Donaldson said he has written to the Speaker of the Stormont Assembly Alex Maskey, paving the way for it to sit on Saturday.

## Pro-Hamas 'suicide bomber' storms US-owned factory in Turkey and poses with 'explosive vest' while holding hostages
 - [https://www.dailymail.co.uk/news/article-13034361/Pro-Hamas-suicide-bomber-storms-owned-factory-Turkey-poses-explosive-vest-holding-hostages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034361/Pro-Hamas-suicide-bomber-storms-owned-factory-Turkey-poses-explosive-vest-holding-hostages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:13:47+00:00

A pro-Hamas 'suicide bomber' has stormed a factory owned US cosmetics giant Procter & Gamble near Istanbul in protest at the war in Gaza, a police spokesman said.

## Britain will test fire Trident nuclear missile for the first time since 2016 as fears of World War Three grow
 - [https://www.dailymail.co.uk/news/article-13034029/Britain-test-fire-Trident-missile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034029/Britain-test-fire-Trident-missile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:13:35+00:00

Officials are said to have issued a warning to shipping in the region of the test as nuclear submarine HMS Vanguard sailed into the Atlantic earlier this week.

## Kidnapper who snatched toddler from her home while punching her grandfather in the face and saying 'that child belongs to jihad' is jailed for nearly four years
 - [https://www.dailymail.co.uk/news/article-13034129/Kidnapper-snatched-toddler-home-punching-grandfather-face-saying-child-belongs-jihad-jailed-nearly-four-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034129/Kidnapper-snatched-toddler-home-punching-grandfather-face-saying-child-belongs-jihad-jailed-nearly-four-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:12:49+00:00

Andrzej Jasinski, 38, walked into the home of a complete stranger on residential Thomson Street in Carlisle, at around 9am on September 9.

## Putin on a show: Cringeworthy footage shows Vladimir singing national anthem on stage alongside Russian youths
 - [https://www.dailymail.co.uk/news/article-13034259/Putin-Cringeworthy-footage-national-anthem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034259/Putin-Cringeworthy-footage-national-anthem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:12:16+00:00

The Russian leader can be seen standing on a stage surrounded by a choir in a new video taken in Moscow today. People on and off stage were shouting 'Russia' over and over again.

## Drill rappers boast about real-life murders, stabbings and gang wars. So why do Labour MPs claim it's 'racist' to use their lyrics as evidence in court?
 - [https://www.dailymail.co.uk/news/article-13033693/Drill-rappers-boast-real-life-murders-gang-feuds-Labour-MPs-want-limit-racist-use-evidence-trials.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033693/Drill-rappers-boast-real-life-murders-gang-feuds-Labour-MPs-want-limit-racist-use-evidence-trials.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:11:17+00:00

Rival gangs use the songs to goad each other - and this often escalates into real-world violence. As a result, the music has offered prosecutors the chance to link murderous thugs to their crimes.

## 'I didn't expect to be drawn into UK internal issues!': Anti-monarchy Jamaican PM Andrew Holness breaks silence on Harry and Meghan after their visit to the Caribbean country sparked royal row
 - [https://www.dailymail.co.uk/news/article-13033967/Anti-monarchy-Jamaican-PM-Andrew-Holness-breaks-silence-Harry-Meghan-visit-Caribbean-country-royal-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033967/Anti-monarchy-Jamaican-PM-Andrew-Holness-breaks-silence-Harry-Meghan-visit-Caribbean-country-royal-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:08:06+00:00

Prince Harry and Meghan met Prime Minister Andrew Holness who has previously said he intends to ditch the monarchy and warned Prince William and Kate they'd never rule the island.

## Brianna Ghey's parents need to see her killers' faces says James Bulger's mother: Denise Fergus believes it is right that teen murderers are identified
 - [https://www.dailymail.co.uk/news/article-13033729/Brianna-ghey-parents-killers-faces-james-bulger-denise-fergus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033729/Brianna-ghey-parents-killers-faces-james-bulger-denise-fergus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:07:28+00:00

The schoolgirl was stabbed with a hunting knife 28 times in the head, neck, chest and back after being lured to Linear Park, Culcheth, a village near Warrington, Cheshire.

## Montana's AirBnb wars explode as Bozeman city manager is caught on hot mic branding the mayor a 'small town ****' - after fighting over wealthy second home owners and rentals
 - [https://www.dailymail.co.uk/news/article-13033295/bozeman-montana-city-manager-criticizes-mayor-hot-mic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033295/bozeman-montana-city-manager-criticizes-mayor-hot-mic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:07:07+00:00

The idyllic town of Bozeman, Montana has been embroiled in a housing crisis since the pandemic, with local leaders now clashing over embracing the economic boom or banning rentals.

## Alec Baldwin looks glum as he's spotted in New York City after pleading not guilty to involuntary manslaughter as he's re-charged with Rust shooting
 - [https://www.dailymail.co.uk/news/article-13034007/alec-baldwin-glum-streets-new-york-manslaughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034007/alec-baldwin-glum-streets-new-york-manslaughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:05:26+00:00

The sour-faced actor, 65, wore gray trousers with a fleece-lined jacket and glasses as he strolled on his own around Manhattan this morning.

## Michigan school shooter Ethan Crumbley's twisted journal entries are shown at his mother's manslaughter trial - as she breaks down in court
 - [https://www.dailymail.co.uk/news/article-13034175/Michigan-school-shooter-Ethan-Crumbleys-twisted-journal-entries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034175/Michigan-school-shooter-Ethan-Crumbleys-twisted-journal-entries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:05:08+00:00

Oxford school shooter Ethan Crumbley warned that his parents were ignoring his pleas for help in the lead up to the 2021 massacre, shocking journal entries shown in court Thursday revealed.

## Lotto heiress who travelled the world with husband on back of her parents' £33m win ditches plans for Grand Designs-style modernist mansion and moves out after locals complained
 - [https://www.dailymail.co.uk/news/article-13033551/Lotto-heiress-travelled-world-husband-parents-33m-win-ditches-plans-Grand-Designs-style-modernist-mansion-moves-locals-complained.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033551/Lotto-heiress-travelled-world-husband-parents-33m-win-ditches-plans-Grand-Designs-style-modernist-mansion-moves-locals-complained.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:02:59+00:00

Lisa Charters, 34, and her husband Craig, 35, have put the house on the market, asking for offers of over £775,000 after they had a 'change of mind'.

## Pictured: Sisters, both in their 20s, who died in a horror flat fire in Aberdeen - as tributes pour in for 'beautiful and loving' pair
 - [https://www.dailymail.co.uk/news/article-13034071/pictured-sisters-flat-fire-Aberdeen-tributes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034071/pictured-sisters-flat-fire-Aberdeen-tributes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T17:02:07+00:00

Shikshya and Aanchal Subedi and their pet cat were killed in the blaze in Aberdeen on Monday evening. The siblings have been described as 'beautiful, kind and loving girls'.

## Ex-minister Sir Desmond Swayne suggests fly-tippers be 'garrotted with their own intestines' to cut down on waste dumping
 - [https://www.dailymail.co.uk/news/article-13034283/Desmond-Swayne-fly-tippers-garrotted-intestines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034283/Desmond-Swayne-fly-tippers-garrotted-intestines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:59:43+00:00

The New Forest West MP told the Common he was not satisfied with the range of financial penalties available and suggested something a little more direct.

## Blur star Alex James redoubles his efforts at the head of a very well-heeled revolt against 'cynical' holiday chalet park expansion near his own very big house in the country
 - [https://www.dailymail.co.uk/news/article-13033851/Blur-star-Alex-James-redoubles-efforts-head-heeled-revolt-against-cynical-holiday-chalet-park-expansion-near-big-house-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033851/Blur-star-Alex-James-redoubles-efforts-head-heeled-revolt-against-cynical-holiday-chalet-park-expansion-near-big-house-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:54:53+00:00

James claims the plans for a dozen, four-metre-tall wooden chalets would be 'a huge slap in the eye' for the 25,000 people who attend his Big Feastival event every year.

## Councillor's astonishingly foul-mouthed rant is viewed thousands of times after it is posted on TikTok: 'If you can't face me don't s*** me off, because I will come after you and I will take you down'
 - [https://www.dailymail.co.uk/news/article-13033765/Councillor-foul-mouthed-rant-viewed-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033765/Councillor-foul-mouthed-rant-viewed-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:54:32+00:00

Sue Malson, 60, from South wales posted a video of herself speaking directly to the camera and threatening unnamed men. She warns 'if you f*** with my family then you've got me to deal with.'

## Federal officers investigate border patrol officer amid claims he exposed himself to YouTuber Danny Mullen and his porn star friend Holly Day before kissing her on the lips while they filmed at Southern California border
 - [https://www.dailymail.co.uk/news/article-13033627/Federal-officers-investigate-border-patrol-officer-amid-claims-exposed-YouTuber-Danny-Mullen-porn-star-friend-Holly-Day-kissing-lips-filmed-Southern-California-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033627/Federal-officers-investigate-border-patrol-officer-amid-claims-exposed-YouTuber-Danny-Mullen-porn-star-friend-Holly-Day-kissing-lips-filmed-Southern-California-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:49:09+00:00

The clip shows the agent bragging about the size of his genitals as he tells porn star Holly Day that he's married before kissing her on the lips.

## Squad's Cori Bush explains how 'relentless threats' FORCED her to use campaign funds to pay her husband over $120K after previous security team was 'sleeping on the job'
 - [https://www.dailymail.co.uk/news/article-13033575/cori-bush-threats-forces-campaign-funds-pay-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033575/cori-bush-threats-forces-campaign-funds-pay-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:48:13+00:00

Democrat Rep. Cori Bush claimed Wednesday that constant threats to her safety and a security team that was 'sleeping on the job' forced her to hire her husband for protection.

## Marjorie Taylor Greene claims Ilhan Omar is a 'foreign agent' as she launches bid to censure Squad member over speech declaring she is 'Somalian first'
 - [https://www.dailymail.co.uk/news/article-13034035/marjorie-taylor-greene-ilhan-omar-foreign-agent-somalia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034035/marjorie-taylor-greene-ilhan-omar-foreign-agent-somalia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:47:24+00:00

Republican conspiracy theorist Rep. Marjorie Taylor Greene denounced hard-left Rep. Ilhan Omar as a 'foreign agent' Thursday, as she said she wanted to deport the congresswoman.

## Life in the F1 fast lane: How Lewis Hamilton went from growing up on a council estate to a knighthood and £250million fortune with business interests in fashion, music and movies and A-list pals - as he closes in on 'dream' £40million-a-year Ferrari seat
 - [https://www.dailymail.co.uk/news/article-13033507/lewis-hamilton-f1-council-estate-knighthood-business-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033507/lewis-hamilton-f1-council-estate-knighthood-business-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:47:07+00:00

Sir Lewis Hamilton had been expected to see out his glittering career with Mercedes but he is now rumoured to be on the verge of a seismic team move that will shake the sport.

## 'Startled' pilot and his passenger died when plane went into a spin which he could not correct before crash, report says
 - [https://www.dailymail.co.uk/news/article-13034109/Startled-pilot-passenger-died-plane-went-spin-not-correct-crash-report-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13034109/Startled-pilot-passenger-died-plane-went-spin-not-correct-crash-report-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:45:45+00:00

Christopher Ingle, 56, and Graham Jones, 63, were killed when their EV-97 Eurostar slammed into the ground at an airfield in Penkridge, Staffordshire.

## Hazmat cleanup crew arrives at Pennsylvania home two days after Army Corps engineer Michael Mohn's headless corpse was found in bathroom after being decapitated by son Justin
 - [https://www.dailymail.co.uk/news/article-13033921/Hazmat-cleanup-crew-arrives-Pennsylvania-home-two-days-Army-Corps-engineer-Michael-Mohns-headless-corpse-bathroom-decapitated-son-Justin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033921/Hazmat-cleanup-crew-arrives-Pennsylvania-home-two-days-Army-Corps-engineer-Michael-Mohns-headless-corpse-bathroom-decapitated-son-Justin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:37:18+00:00

Exclusive DailyMail.com photos show members of a private biohazard cleaning team was called to the Levittown property two days after Michael Mohn was beheaded at the home.

## Homeless Portland woman, 33, is found guilty of shoving girl, 3, onto train tracks in horrifying incident caught on video - where toddler was rescued and treated for multiple head injuries
 - [https://www.dailymail.co.uk/news/article-13033803/homeless-woman-portland-guilty-pushing-girl-train-tracks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033803/homeless-woman-portland-guilty-pushing-girl-train-tracks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:36:06+00:00

Brianna Lace Workman, 33, was found guilty on Wednesday after she shoved a three-year-old girl onto train tracks in Portland in December 2022. The child was saved with minor injuries.

## Biden sheds tears and calls for truce, telling Republican Speaker Mike Johnson 'We must not be enemies' as they listen to Andrea Bocelli sing 'Amazing Grace' at National Prayer Breakfast in Washington
 - [https://www.dailymail.co.uk/news/article-13033697/biden-mike-johnson-truce-national-prayer-breakfast-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033697/biden-mike-johnson-truce-national-prayer-breakfast-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:23:28+00:00

President Joe Biden said lawmakers 'must not be enemies' as he appeared in public for the first time with House Speaker Mike Johnson at the National Prayer Breakfast on Thursday.

## Stepmother of Kansas City Chiefs fan found dead alongside two others at HIV scientist friend's home says his body was 'FROZEN' and families were asked to wait for them to 'thaw out'
 - [https://www.dailymail.co.uk/news/article-13033611/chiefs-fan-dead-stepmother-says-body-frozen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033611/chiefs-fan-dead-stepmother-says-body-frozen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:18:53+00:00

Linda Johnson, the stepmother of Ricky Johnson Jr, 38, said cops told her the bodies needed to 'thaw out' and that they wouldn't need to go down to identify them.

## Lloyd Austin, 70, APOLOGIZES for secret hospital trip: Defense Secretary says he is still recovering from prostate cancer treatment and admits he was wrong for wanting to keep health battle private
 - [https://www.dailymail.co.uk/news/article-13033959/Lloyd-Austin-APOLOGIZES-secret-hospital-cancer-biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033959/Lloyd-Austin-APOLOGIZES-secret-hospital-cancer-biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:11:51+00:00

Defense Secretary Lloyd Austin on Thursday apologized for keeping his hospitalization a secret and said he is still in the process of recovering from his surgery for prostate cancer.

## The real estate 'Tinder Swindler': Glamorous Christie's agent claims her ex-boyfriend stole $70,000 off her and fled to Miami during their whirlwind romance after they met on Hinge app
 - [https://www.dailymail.co.uk/news/article-13033359/real-estate-agent-accuses-ex-boyfriend-stealing-tinder-swindler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033359/real-estate-agent-accuses-ex-boyfriend-stealing-tinder-swindler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:11:27+00:00

New Jersey-based Christina LaBarbiera met Rob Harris on Hinge last April and within a matter of months, the lovebirds had plans to move to Florida together.

## Target store clerk blames Gavin Newsom for shop staff being afraid to fight back against shoplifters as he's robbed - without realizing California Governor was in the line at checkout
 - [https://www.dailymail.co.uk/news/article-13033353/target-clerk-blames-gavin-newsom-shoplifters-california-governor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033353/target-clerk-blames-gavin-newsom-shoplifters-california-governor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:06:49+00:00

California Governor Gavin Newsom said a Target cashier blamed him as the reason staff cannot stop shoplifters from leaving the store.

## California lawmakers slammed for 'bait-and-switch' with reparations 'nothing-burger' - slavery redress bills ignore the $1.2M payouts black residents were promised
 - [https://www.dailymail.co.uk/news/article-13033503/California-lawmakers-slammed-bait-switch-reparations-burger-slavery-redress-bills-ignore-1-2M-payouts-black-residents-promised.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033503/California-lawmakers-slammed-bait-switch-reparations-burger-slavery-redress-bills-ignore-1-2M-payouts-black-residents-promised.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:06:05+00:00

Critics pounced on the lack of cash payments, and the $1.2 million sum that was floated last year by the state's Reparations Task Force for every black resident who could show they had suffered.

## Family of six dolphins gets stranded on Welsh beach before rescuers save them in seven-hour mission
 - [https://www.dailymail.co.uk/news/article-13033469/six-dolphins-stranded-Welsh-beach-rescuers-seven-hour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033469/six-dolphins-stranded-Welsh-beach-rescuers-seven-hour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:01:23+00:00

A team of volunteers, animal medics and coastguards spent seven hours keeping the dolphins alive before they could be floated back out into the sea.

## Bud Light U-turns on woke as it partners with comedian Shane Gillis who is notorious for foul-mouthed racist and homophobic jokes - after campaign starring trans influencer Dylan Mulvaney sparked boycott
 - [https://www.dailymail.co.uk/news/article-13033237/Bud-Light-U-turns-woke-partners-comedian-Shane-Gillis-notorious-foul-mouthed-racist-homophobic-jokes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033237/Bud-Light-U-turns-woke-partners-comedian-Shane-Gillis-notorious-foul-mouthed-racist-homophobic-jokes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T16:00:35+00:00

In a post the the brands Instagram account they confirmed that Gillis, 36, was now part of the team after a dismal for the year following their partnership with transgender influencer Dylan Mulvaney.

## Biden admin official accused of abandoning 150,000 US allies in bungled Afghanistan withdrawal is PROMOTED to US ambassador to Iraq
 - [https://www.dailymail.co.uk/news/article-13033415/tracey-jacobson-iraq-Afghanistan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033415/tracey-jacobson-iraq-Afghanistan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:55:36+00:00

Tracey Jacobson was in charge of helping America's Afghan allies get visas to flee to the US, but as many as 150,000 were left behind and are still waiting for their escape.

## Cori Bush has paid her security guard husband $120,000: Squad member gave spouse MORE money before DOJ launched criminal investigation into misuse of taxpayer funds
 - [https://www.dailymail.co.uk/news/article-13033483/cori-bush-husband-money-taxpayer-funds-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033483/cori-bush-husband-money-taxpayer-funds-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:55:17+00:00

Bush 's husband has collected $120,000 in campaign dollars to be her personal security guard - as the Department of Justice has launched a probe into alleged misuse of such funds.

## Wanted Denver pastor who raked in $1.3MILLION from his followers in crypto scam is spotted in Zambia teaching about God and finance
 - [https://www.dailymail.co.uk/news/article-13033363/Wanted-Denver-pastor-raked-1-3MILLION-followers-crypto-scam-spotted-Zambia-teaching-God-finance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033363/Wanted-Denver-pastor-raked-1-3MILLION-followers-crypto-scam-spotted-Zambia-teaching-God-finance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:54:59+00:00

A wanted Denver pastor who raked in $1.3 million from his followers in a crypto scam is spotted in Zambia teaching about God and finance.

## Pineapple Express lashes California as first wave of storms hits the state with heavy flooding prompting closure of Pacific Coast Highway in Huntington Beach: More than 20 million people under flood alerts
 - [https://www.dailymail.co.uk/news/article-13033813/Pineapple-Express-California-storms-Highway-Huntington-Beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033813/Pineapple-Express-California-storms-Highway-Huntington-Beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:54:44+00:00

On Thursday morning, a three-mile stretch of Pacific Coast Highway in the Huntington Beach area was closed due to pouring rains.

## The new prawn cocktail offensive? Keir Starmer makes another bid to jettison Corbyn era as he cosies up to businesses at £1,000-a-head Labour conference - with party ruling out corporation tax hike after U-turn on bankers' bonuses
 - [https://www.dailymail.co.uk/news/article-13033669/The-new-prawn-cocktail-offensive-Keir-Starmer-makes-bid-jettison-Corbyn-era-cosies-businesses-1-000-head-Labour-conference-party-ruling-corporation-tax-hike-U-turn-bankers-bonuses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033669/The-new-prawn-cocktail-offensive-Keir-Starmer-makes-bid-jettison-Corbyn-era-cosies-businesses-1-000-head-Labour-conference-party-ruling-corporation-tax-hike-U-turn-bankers-bonuses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:54:11+00:00

In an address to a room of 400 business bosses, Sir Keir suggested their attendance demonstrated the 'changes' he had made to Labour since taking charge in 2020.

## Inside China's execution conveyor belt: How 'mobile injection vans and firing squads are used to put thousands to death a year' - outstripping capital punishment figures for the rest of the world combined
 - [https://www.dailymail.co.uk/news/article-13033053/Inside-Chinas-execution-conveyor-belt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033053/Inside-Chinas-execution-conveyor-belt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:53:37+00:00

In 2022, the World Coalition Against the Death Penalty said that at least 8,000 people per year were executed in China from 2007 - more than all other countries combined by some margin.

## Schoolboy, eight, died after swallowing ten magnets following a TikTok craze after talking about how people boosted their social media profiles with daredevil stunts, coroner rules
 - [https://www.dailymail.co.uk/news/article-13033667/Schoolboy-eight-died-swallowing-ten-magnets-following-TikTok-craze-talking-people-boosted-social-media-profiles-daredevil-stunts-coroner-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033667/Schoolboy-eight-died-swallowing-ten-magnets-following-TikTok-craze-talking-people-boosted-social-media-profiles-daredevil-stunts-coroner-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:50:44+00:00

Rhys Millum, described as a 'live-wire' and 'dare devil', died after his small intestine was perforated by ten 3mm silver spherical magnets - which had all stuck together in a 30mm long row in his bowel.

## EU caves in to farmers: VICTORY for tractor protesters as Von der Leyen says Brussels will cut hated red tape 'burdens' that have pushed up prices following days of blockades across Europe
 - [https://www.dailymail.co.uk/news/article-13033827/eu-farmers-protest-tractor-brussels-victory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033827/eu-farmers-protest-tractor-brussels-victory.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:45:55+00:00

Ursula von der Leyen's concession came after days of tractor blockades across the continent which have caused chaos on the continent's roads and in cities.

## Vandals graffiti 27 floors of $1billion LA skyscraper that has been abandoned since 2019 after Chinese developers pulled the plug
 - [https://www.dailymail.co.uk/news/article-13033293/graffiti-Oceanview-Plaza-floors-Los-Angeles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033293/graffiti-Oceanview-Plaza-floors-Los-Angeles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:35:21+00:00

Artists have covered 27 floors of Oceanwide Plaza, a deserted three-building project owned by Oceanwide Holdings. No suspects have yet been identified

## Cancer-stricken MTV producer dies aged 28 just weeks after marrying his wife and raising $300,000 for fellow patients
 - [https://www.dailymail.co.uk/news/article-13033377/mtv-producer-jared-march-dies-cancer-weeks-marriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033377/mtv-producer-jared-march-dies-cancer-weeks-marriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:32:24+00:00

Jared March, 28, died on January 27 after fighting his battle with soft-tissue sarcoma for two-and-a-half years. He had just married his wife Brittany in December and raised $30,000 for other patients.

## Got anyone in mind, Sir Tony? Blair to pen guide to running a country 'for the busy, aspiring leader' that will be published just before Keir Starmer tries to seize keys to No10 at election
 - [https://www.dailymail.co.uk/news/article-13033885/Tony-Blair-guide-running-country-Keir-Starmer-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033885/Tony-Blair-guide-running-country-Keir-Starmer-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:31:30+00:00

On Leadership: A Practical Guide is due to come out in September and promises advice 'for the busy, aspiring leader'.

## Biden builds war chest of $117 million as Trump spends $50 million on legal fees: Democrats gloat Republican is 'lighting money on fire'
 - [https://www.dailymail.co.uk/news/article-13033629/Biden-builds-war-chest-117-million-Trump-spends-50-million-legal-fees-Democrats-gloat-Republican-lighting-money-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033629/Biden-builds-war-chest-117-million-Trump-spends-50-million-legal-fees-Democrats-gloat-Republican-lighting-money-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:25:03+00:00

President Biden further padded his $117 million war chest with money events in Florida this week. Trump's own efforts are being undercut by more than $50 million in legal fees.

## Will border stand off fan the flames of Texan secession? Independence leaders say row with federal government has sparked 'surge' in support for 'Texit', but experts say it is legally impossible
 - [https://www.dailymail.co.uk/news/article-13029321/Will-border-stand-fan-flames-Texan-secession-Independence-leaders-say-row-federal-government-sparked-surge-support-Texit-experts-say-legally-impossible.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13029321/Will-border-stand-fan-flames-Texan-secession-Independence-leaders-say-row-federal-government-sparked-surge-support-Texit-experts-say-legally-impossible.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:19:23+00:00

The dramatic border stand off between the Texas Governor and Joe Biden over illegal crossings will 'fan the flames' of independence in the Lone Star State, it has been claimed.

## Murder trial begins for white Ohio cop who shot black man Casey Goodson Jr five times in the back as prosecutors say he mistook a sandwich victim was holding for a gun
 - [https://www.dailymail.co.uk/news/article-13033385/Murder-trial-begins-white-Ohio-cop-shot-black-man-Casey-Goodson-Jr-five-times-prosecutors-say-mistook-sandwich-victim-holding-gun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033385/Murder-trial-begins-white-Ohio-cop-shot-black-man-Casey-Goodson-Jr-five-times-prosecutors-say-mistook-sandwich-victim-holding-gun.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:17:06+00:00

Jason Meade, a former sheriff's deputy in Franklin County, Ohio, is on trial accused of murdering  Casey Goodson Jr, 23, on December 4, 2020, as he opened the door of his grandmother's house.

## Delta Airlines pilot sues after his foot was 'SWALLOWED' by travelator at Denver airport leaving him in agony
 - [https://www.dailymail.co.uk/news/article-13033241/delta-airlines-pilot-sues-injured-foot-walkway-denver-airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033241/delta-airlines-pilot-sues-injured-foot-walkway-denver-airport.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:15:28+00:00

Kenneth Gow was left with 'mental anguish' and 'physical suffering' following the accident, according to the suit filed in December in the US District Court in Colorado.

## Target removes Black History Month book after incensed TikToker highlights mistakes where historic black leaders are misidentified including Carter G Woodson
 - [https://www.dailymail.co.uk/news/article-13033063/target-black-history-month-book-tiktok-mistakes-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033063/target-black-history-month-book-tiktok-mistakes-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T15:09:52+00:00

The product confused Carter G.Woodson, W.E.B. Du Bois and Booker T. Washington. US History teacher @issatete pointed out the errors on TikTok before the book was pulled.

## Capitol Police will NOT charge Democrat's aide who made viral gay sex tape in a Senate hearing room: Suspects 'refused' to speak with investigators despite there being 'no evidence' of a crime
 - [https://www.dailymail.co.uk/news/article-13033609/capitol-police-not-charge-democrat-aide-sex-tape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033609/capitol-police-not-charge-democrat-aide-sex-tape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:58:15+00:00

The U.S. Capitol Police announced it will not charge a Democrat congressional aide who was fired for filming a gay sex tape in the Senate.

## Harry and Meghan plan new Netflix film and TV series: Sussexes are working on a 'bunch' of new projects, with a movie and 'unscripted' shows in development, executive at streaming giant reveals
 - [https://www.dailymail.co.uk/news/article-13033585/Prince-Harry-Meghan-Markle-plan-Netflix-film-TV-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033585/Prince-Harry-Meghan-Markle-plan-Netflix-film-TV-series.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:56:23+00:00

The Duke and Duchess of Sussex signed a five-year agreement with Netflix in 2020, but there has been uncertainty over whether the £80million deal will be renewed next year.

## Canadian cops stumped after thieves steal 500lb taxidermized beast from Alberta wellness resort
 - [https://www.dailymail.co.uk/news/article-13033341/polar-bear-stolen-lily-lake-resort-edmonton-alberta-canada.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033341/polar-bear-stolen-lily-lake-resort-edmonton-alberta-canada.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:54:57+00:00

The thieves snatched Harry the polar bear, standing about 10 feet, during the coldest days at the former Lily Lake Resort, now known as the Lionsheart Wholeness Center in Alberta, Canada.

## HUNDREDS of protesters block five major roadways in Washington DC during rush hour over US support for Israel: Federal employees set to go on 'one day hunger strike' in support of Gaza
 - [https://www.dailymail.co.uk/news/article-13033501/protestors-block-washington-dc-roadways-israel-support-gaza.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033501/protestors-block-washington-dc-roadways-israel-support-gaza.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:53:33+00:00

Protestors can be heard chanting: 'Free Palestine , long live Palestine', as angered commuters can be heard continuously beeping their horns at them.

## Houthis claim they have hit US container ship in Red Sea as America carries out fresh strike on the rebel group's drones in Yemen and downs multiple Iranian unmanned aircraft
 - [https://www.dailymail.co.uk/news/article-13031993/houthis-container-red-sea-america-strike-yemen-drones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031993/houthis-container-red-sea-america-strike-yemen-drones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:44:58+00:00

Military spokesman Brig. Gen Yahya Saree claimed the US was unable to prevent one of his missiles from striking the Koi, a Liberian-flagged shipping vessel (pictured: strike on merchant vessel Sunday)

## Elon Musk vows Tesla shareholder vote on moving the company's corporate listing to Texas after Delaware court struck down his $55B pay package
 - [https://www.dailymail.co.uk/news/article-13033387/Elon-Musk-Tesla-shareholder-vote-Texas-Delaware.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033387/Elon-Musk-Tesla-shareholder-vote-Texas-Delaware.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:44:08+00:00

'Tesla will move immediately to hold a shareholder vote to transfer state of incorporation to Texas,' Musk posed on X early Thursday, citing a poll he posted on the platform.

## Big Lizzie gets ready for war: From stealth fighter jets to state-of-the-art helicopters and cannons that fire 4,000 times a minute - the firepower packed by £3bn HMS Queen Elizabeth if she takes up Red Sea fight against Houthi rebels
 - [https://www.dailymail.co.uk/news/article-13032521/queen-elizabeth-firepower-red-sea-war-houthi-rebels.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032521/queen-elizabeth-firepower-red-sea-war-houthi-rebels.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:43:49+00:00

The UK is set to send the £4billion aircraft is set to be deployed in the Red Sea to replace the USS Dwight D Eisenhower when it is returned to America

## Shocking video shows Chicago charter school teachers screaming at special education student and calling him 'dumb': 'They're the schoolyard bullies - not the kids'
 - [https://www.dailymail.co.uk/news/article-13029721/Shocking-video-shows-Chicago-charter-school-teachers-screaming-special-education-student-calling-dumb-Theyre-schoolyard-bullies-not-kids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13029721/Shocking-video-shows-Chicago-charter-school-teachers-screaming-special-education-student-calling-dumb-Theyre-schoolyard-bullies-not-kids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:41:21+00:00

Teachers Aaron Pennix and Latilda Sight were recorded screaming at the boy, who is understood to have learning difficulties, in a classroom at University of Chicago Charter School in December 2022.

## Hunt for fugitive Clapham chemical attacker: Police say 'dangerous' suspect, 35, who doused mother and two children in alkaline substance is from Newcastle area and has 'significant' injuries to his face - as video shows man fleeing scene after attack
 - [https://www.dailymail.co.uk/news/article-13033379/Police-say-Clapham-chemical-attacker-Newcastle-area-continue-hunt-run-suspect-mother-two-young-children-doused-corrosive-substance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033379/Police-say-Clapham-chemical-attacker-Newcastle-area-continue-hunt-run-suspect-mother-two-young-children-doused-corrosive-substance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:41:12+00:00

Police said the suspect, who is from Newcastle, is 'dangerous' and urged members of the public not to approach him and instead call 999.

## Mental health trust denied patients 'basic dignity and human rights', prioritised white people and fostered 'culture of fear and intimidation' despite extra scrutiny after being exposed by Panorama investigation in 2022
 - [https://www.dailymail.co.uk/news/article-13032547/Mental-health-trust-denied-patients-dignity-human-rights-prioritised-white-people-culture-fear-intimidation-scrutiny-exposed-Panorama-investigation-two-years-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032547/Mental-health-trust-denied-patients-dignity-human-rights-prioritised-white-people-culture-fear-intimidation-scrutiny-exposed-Panorama-investigation-two-years-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:35:24+00:00

The report into Edenfield Centre, near Manchester, also found that patients who were white were 'prioritised' and ethnic minority staff members felt there was 'no point' in applying for promotions.

## Fears millions of Brits face waiting until summer for mortgage relief after Bank of England HOLDS rates at 5.25% and warns there is not enough evidence inflation has been tamed to start cutting yet
 - [https://www.dailymail.co.uk/news/article-13033015/Bank-England-rates-mortgages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033015/Bank-England-rates-mortgages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:33:07+00:00

The Monetary Policy Committee left the based rate unchanged at 5.25 per cent in the latest decision announced at noon - the fourth pause in a row.

## Gen Z hairdresser wins payout for getting sacked after 'gossiping' to a client, using her phone at work and slamming her 'toxic' job on TikTok
 - [https://www.dailymail.co.uk/news/article-13031771/Gen-Z-hairdresser-payout-sacked-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031771/Gen-Z-hairdresser-payout-sacked-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:32:38+00:00

A young hairdresser has won a case taken against her former employer after she was sacked, with the Fair Work Commission finding she had not got 'procedural' fairness.

## Landowner offers XL Bully owners a 'lifeline' to walk their dogs without a lead or muzzles on private fields as ban comes into effect today
 - [https://www.dailymail.co.uk/news/article-13033001/xl-bully-owner-lifeline-walk-dogs-lead-muzzles-private-fields-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033001/xl-bully-owner-lifeline-walk-dogs-lead-muzzles-private-fields-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:31:24+00:00

Rebecca Harris owns Bassaleg Dog Walking Field in Newport, Wales, and is allowing XL Bullys to walk freely on her land, which is surrounded by secure fencing and several gates, with their owners.

## CMG Homes: Construction industry in chaos as firm of 25 years folds with $300,000 in debts in latest home builder collapse
 - [https://www.dailymail.co.uk/news/article-13031787/CMG-Homes-construction-company-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031787/CMG-Homes-construction-company-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:31:14+00:00

Brisbane based construction company, CMG Homes, on Wednesday appointed Lee Crosthwaite of Worrells as its liquidator.

## Cardiff pub is ordered to pay out to Irish Traveller father after refusing to host his daughter's christening - as staff are made to take equality and diversity training
 - [https://www.dailymail.co.uk/news/article-13032255/cardiff-pub-irish-traveller-father-pay-daughter-christening-staff-diversity-training.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032255/cardiff-pub-irish-traveller-father-pay-daughter-christening-staff-diversity-training.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:29:35+00:00

The Three Horseshoes in Whitchurch, Cardiff told the father that they would not hold the event as he was a member of the Irish Traveller community.

## When Mary-Anne the health minister held a press conference, she was surrounded by 10 'sick people'. There's just one big problem
 - [https://www.dailymail.co.uk/news/article-13032019/Victoria-health-minister-fake-hospital-patients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032019/Victoria-health-minister-fake-hospital-patients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:28:53+00:00

Staff and family members have been accused of posing as patients at a regional Victorian hospital's health clinic during a visit by the state Health Minister.

## Powerball jackpot: Mum who scooped $100million Powerball prize vows to quit work immediately - but the hunt is still on for winner who doesn't know they've scooped the huge sum
 - [https://www.dailymail.co.uk/news/article-13032399/Powerball-numbers-200-million-jackpot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032399/Powerball-numbers-200-million-jackpot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:23:57+00:00

A mum who will split a $100million prize from the Powerball jackpot with her partner  has pledged to quit her job and tour the world.

## Moment ambulance is blocked by low traffic neighbourhood planters from reaching 10-month-old baby as she suffers seizure
 - [https://www.dailymail.co.uk/news/article-13032841/Moment-ambulance-blocked-low-traffic-neighbourhood-planters-reaching-10-month-old-baby-suffers-seizure.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032841/Moment-ambulance-blocked-low-traffic-neighbourhood-planters-reaching-10-month-old-baby-suffers-seizure.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:22:56+00:00

Charli Panter, 34 has slammed a low-traffic neighbourhood scheme after an ambulance was blocked from reaching her  10-month-old daughter, who was having a seizure.

## Phillip Island mass drowning: Heartbreaking final moments of family wiped out in beach tragedy
 - [https://www.dailymail.co.uk/news/article-13032865/Phillip-Island-mass-drowning-final-moments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032865/Phillip-Island-mass-drowning-final-moments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:21:52+00:00

Ankur Chhabra attended the funeral for four family members who drowned at an unpatrolled area of Forrest Caves beach at Philip Island on January 24.

## 'Neighbour from hell', 59, set fire to her flat in plot to pin blame on man who lived a floor below after becoming fixated on the idea he was leaking fumes into her home, court hears
 - [https://www.dailymail.co.uk/news/article-13032915/Neighbour-hell-59-set-fire-flat-plot-pin-blame-man-lived-floor-fixated-idea-leaking-fumes-home-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032915/Neighbour-hell-59-set-fire-flat-plot-pin-blame-man-lived-floor-fixated-idea-leaking-fumes-home-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:20:23+00:00

Viola Lawrence, 59, put her neighbour, Ahmed Dahoum, through hassle and abuse between April 2020 and April 2021.

## The REAL story behind Guy Ritchie's Ministry of Ungentlemanly Warfare: Daring 'Operation Postmaster' mission saw troops led by swashbuckling commander steal German and Italian ships from Spanish island in 1942 - as trailer is released
 - [https://www.dailymail.co.uk/news/article-13032955/The-REAL-story-Guy-Ritchies-Ministry-Ungentlemanly-Warfare-Daring-Operation-Postmaster-mission-saw-troops-led-swashbuckling-commander-steal-German-Italian-ships-Spanish-island-1942-trailer-released.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032955/The-REAL-story-Guy-Ritchies-Ministry-Ungentlemanly-Warfare-Daring-Operation-Postmaster-mission-saw-troops-led-swashbuckling-commander-steal-German-Italian-ships-Spanish-island-1942-trailer-released.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:20:16+00:00

In January 1942, Gus March-Phillipps (depicted by Henry Cavill) and Anders Lassen played key roles in a mission that seemed more at home in a spy novel than reality.

## Benjamin Hickey: Man suddenly dies two days after his 31st birthday from a suspected heart condition - as his final words are revealed
 - [https://www.dailymail.co.uk/news/article-13033027/Benjamin-Hickey-suddenly-dies-final-words.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033027/Benjamin-Hickey-suddenly-dies-final-words.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:19:43+00:00

Benjamin Hickey, 31, passed away in his sleep on January 22 while lying next to his girlfriend in their home in Davoren Park, north Adelaide.

## Captain Tom Moore's daughter's illegal spa is stripped back to a shell after demolishers start ripping roof off £200,000 complex - leaving Hannah Ingram-Moore 'humiliated'
 - [https://www.dailymail.co.uk/news/article-13032657/captain-tom-moore-daughter-hannah-ingram-illegal-spa-stripped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032657/captain-tom-moore-daughter-hannah-ingram-illegal-spa-stripped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:17:14+00:00

New photos show a leg of the complex in Marston Moretaine, Bedfordshire, with no roof or flooring while building materials are piled up to one side of the building.

## Chilling moment victims are doused with corrosive liquid in 'targeted' Clapham attack that left 12 injured: Mother, 31, and daughter, three, suffer 'life changing injuries' and eight-year-old is hurt - as hunt continues for 'dangerous' suspect
 - [https://www.dailymail.co.uk/news/article-13032243/clapham-acid-attacker-car-woman-police-suspect-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032243/clapham-acid-attacker-car-woman-police-suspect-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:16:59+00:00

The disturbing footage shows a man running towards the driver's door in Lessar Avenue, opposite Clapham Common, and getting inside before ploughing the white car into a woman.

## Pub-goers are being automatically forced to pay American-style service charge on drinks bought at the bar in stealth tipping push
 - [https://www.dailymail.co.uk/news/article-13033339/Pub-goers-automatically-forced-pay-service-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033339/Pub-goers-automatically-forced-pay-service-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:15:25+00:00

The Scotsman Group, who own various bars and pubs in Scotland, have introduced a two per cent 'American-style' automatic charge on beverages.

## Are bigger families back? Average number of children for 1970s generation of mothers hits a 15-YEAR high... but women are waiting longer than ever to start
 - [https://www.dailymail.co.uk/news/article-13033517/Are-bigger-families-Average-number-children-1970s-generation-mothers-hits-15-YEAR-high-women-waiting-longer-start.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033517/Are-bigger-families-Average-number-children-1970s-generation-mothers-hits-15-YEAR-high-women-waiting-longer-start.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:11:15+00:00

Figures published today by the Office for National Statistics (ONS) showed the completed family size for women born in 1977 was, on average, 1.94 children.

## Pictured: Revellers accused of 'knife rampage' outside nightclub that left amateur rugby player dead and five others injured
 - [https://www.dailymail.co.uk/news/article-13033451/Pictured-Revellers-accused-knife-rampage-nightclub-killed-amateur-rugby-player.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033451/Pictured-Revellers-accused-knife-rampage-nightclub-killed-amateur-rugby-player.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:04:12+00:00

Jake Hill, 25, Tia Taylor, 22, and Chelsea Powell, 22, are seen on CCTV entering the Eclipse nightclub in Bodmin on April 29, last year, just hours before the deadly violence erupted outside.

## Premium Bonds saver scoops £50,000 prize with a £10 bond bought in 1990!
 - [https://www.dailymail.co.uk/money/saving/article-13032921/Premium-Bonds-saver-scoops-50-000-prize-10-bond-bought-1990.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/saving/article-13032921/Premium-Bonds-saver-scoops-50-000-prize-10-bond-bought-1990.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:03:50+00:00

A lucky winner has scooped the prize from a bond bought in June 1990, when Kylie Minogue (pictured) sang Better the Devil You Know.

## How Michael Mohn was a devoted father to honors student son Justin and took him back in when fell on hard times before his youngest 'beheaded him' in his own home: Grieving colleagues pay tribute to their 'teammate' of 20 years
 - [https://www.dailymail.co.uk/news/article-13032985/Michael-justin-mohn-federal-colleagues-friends-tributes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032985/Michael-justin-mohn-federal-colleagues-friends-tributes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T14:03:37+00:00

Michael Mohn, 68, was beheaded by his son, Justin, 32, on Tuesday inside of the home where the two lived along with Michael's wife, Denice, in a quiet Philadelphia suburb, police said.

## Teenage son of Israeli diplomat, 19, sobs in mugshot after 'driving motorcycle into Florida cop because he hates traffic' - as video shows him namedropping dad when police pulled him over just weeks earlier
 - [https://www.dailymail.co.uk/news/article-13033103/israeli-diplomat-son-cries-mugshot-hit-cop-motorcycle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033103/israeli-diplomat-son-cries-mugshot-hit-cop-motorcycle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:57:29+00:00

Avraham Gil, 19, was arrested on Saturday in Sunny Isles Beach, Florida - a suburb of Miami.

## Gap year students could be paid to join month-long military boot camp under plans to build up 'citizen army'
 - [https://www.dailymail.co.uk/news/article-13031879/Gap-year-students-military-boot-camp-citizen-army.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031879/Gap-year-students-military-boot-camp-citizen-army.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:54:56+00:00

Outgoing Chief of the General Staff General Sir Patrick Sanders (pictured) has reportedly suggested the idea of a course over the summer holidays which gives young adults a taste of serving.

## Got acne? TikTok says 'spearmint tea' will clear your spots... but the experts aren't convinced
 - [https://www.dailymail.co.uk/health/article-13028969/Got-acne-TikTok-spearmint-tea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13028969/Got-acne-TikTok-spearmint-tea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:54:34+00:00

TikTok users claim drinking spearmint tea can cure acne. But Holland & Barrett's retail health lead Dr Anojan Arulananthan urges people not to swap their acne treatment for herbal tea.

## Butlin's sacks vile paedophile lifeguard at its Minehead resort after discovering he groomed a 13-year-old boy for sex in Australia
 - [https://www.dailymail.co.uk/news/article-13033283/Butlins-sacks-vile-paedophile-lifeguard-Mineheard-resort-discovering-groomed-13-year-old-boy-sex-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033283/Butlins-sacks-vile-paedophile-lifeguard-Mineheard-resort-discovering-groomed-13-year-old-boy-sex-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:50:29+00:00

Dean Carelse, an ex-water polo and rugby coach, was sentenced to jail in Queensland in 2022 after pleading guilty to almost 20 charges.

## Family of Justin Mohn say they are in disbelief over beheading murder of his Army Corps of Engineers dad Michael after his headless corpse was found in bathroom of Levittown, Pennsylvania home
 - [https://www.dailymail.co.uk/news/article-13030005/Family-Justin-Mohn-say-disbelief-beheading-murder-Army-Corps-Engineers-dad-Michael-headless-corpse-bathroom-Levittown-Pennsylvania-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030005/Family-Justin-Mohn-say-disbelief-beheading-murder-Army-Corps-Engineers-dad-Michael-headless-corpse-bathroom-Levittown-Pennsylvania-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:49:53+00:00

Mary Jasch, the sister of victim Michael Mohn, 68, spoke to DailyMail.com a day after her nephew Justin Mohn, 32, allegedly beheaded his father at the family's Levittown home on Tuesday.

## Mother's horror as clip-on earrings from Claire's 'take chunks' out of her three-year-old daughter's ears to leave her scarred
 - [https://www.dailymail.co.uk/news/article-13032791/three-year-old-scarred-clipon-earrings-Claires.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032791/three-year-old-scarred-clipon-earrings-Claires.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:48:48+00:00

Jessica Byrne, 21, and her husband Nathan Byrne, 32, had bought their daughter Ava a pair of kitten-shaped clip-on earrings from Claire's in Gloucester City Centre in December.

## EU agrees £43billion Ukraine aid package after pressuring Hungary's Viktor Orban to drop his veto, in huge blow to Putin
 - [https://www.dailymail.co.uk/news/article-13032691/EU-agrees-43billion-Ukraine-aid-package.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032691/EU-agrees-43billion-Ukraine-aid-package.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:47:04+00:00

European Council President Charles Michel said the 27 EU countries sealed the deal just over an hour into a summit of the bloc's leaders, despite threats from Hungary to veto the deal.

## Fury as Welsh Labour claims taxpayers' money poured into £4.25million purchase of farm for Green Man festival 'hasn't been wasted' despite site being declared unusable due to nesting ospreys
 - [https://www.dailymail.co.uk/news/article-13032983/Welsh-government-farm-Green-Man-music-festival-rare-birds-prey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032983/Welsh-government-farm-Green-Man-music-festival-rare-birds-prey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:46:16+00:00

The Welsh Government shelled out for Gilestone Farm in Powys in 2022 to provide a permanent base and spin-off site for the Green Man festival - because organisers did not have the money.

## The punishing reality of working in a Post Office: 70 hour weeks alongside second jobs and offering everything from dry cleaning to knife sharpening just to make the 'Aladdin's Cave' at the centre of the community break even
 - [https://www.dailymail.co.uk/news/article-13032711/The-punishing-reality-working-Post-Office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032711/The-punishing-reality-working-Post-Office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:45:32+00:00

Barney, 47, has been running Chipping Campden Post Office for the last four years, ever since postmistress Tracy Churchill and her husband Neil, just couldn't face it anymore.

## The death of vegan fast food: Experts warn plant-based restaurants could be on their way out as one starts selling MEAT and chain backed by Lewis Hamilton and Leonardo DiCaprio closes half its branches
 - [https://www.dailymail.co.uk/news/article-13027949/vegan-fast-food-Experts-plant-based-restaurants-way-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13027949/vegan-fast-food-Experts-plant-based-restaurants-way-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:44:27+00:00

Experts have warned that the declining popularity of veganism could lead to more vegan restaurants going under in the next one or two years as they struggle to compete with larger meat-selling brands.

## Brit teacher, 38, is arrested over 'sexual assault of a 16-year-old foreign student ten years ago' in Thailand
 - [https://www.dailymail.co.uk/news/article-13032847/Brit-teacher-38-arrested-sexual-assault-16-year-old-foreign-student-ten-years-ago-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032847/Brit-teacher-38-arrested-sexual-assault-16-year-old-foreign-student-ten-years-ago-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:41:45+00:00

The suspect, 38, identified by police under the pseudonym 'Tyler', reportedly took a female foreign student, 16, to his house in Phuket to 'commit indecent acts' twice in 2014 and 2015.

## Lewis Hamilton set to move to Ferrari in bombshell switch, less than a year after he denied £40m talks, with an 'escape clause' in Mercedes contract allowing him to cut £100m deal short
 - [https://www.dailymail.co.uk/sport/formulaone/article-13032493/Lewis-Hamilton-Ferrari-Switch-Mercedes-Contract-Clause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/formulaone/article-13032493/Lewis-Hamilton-Ferrari-Switch-Mercedes-Contract-Clause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:38:44+00:00

JONATHAN MCEVOY: Mail Sport understands the seven-time world champion has secured a seat at the Scuderia, even for as early as the 2025 season.

## Inside Elon Musk's Neuralink lab where 1,500 animals have been killed and test monkeys were subjected to 'extreme suffering'
 - [https://www.dailymail.co.uk/news/article-13029175/Elon-Musks-Neuralink-lab-animals-killed-monkeys-extreme-suffering.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13029175/Elon-Musks-Neuralink-lab-animals-killed-monkeys-extreme-suffering.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:38:25+00:00

DailyMail.com can reveal that monkeys had operations on their skulls up to 10 times each before being put down during the testing phase.

## Family doctor, 47, is found guilty of sexually assaulting three female patients after telling one terminally ill cancer sufferer 'I'm helping you' as he groped her
 - [https://www.dailymail.co.uk/news/article-13032839/Family-doctor-47-guilty-sexually-assaulting-three-female-patients-telling-one-terminally-ill-cancer-sufferer-Im-helping-groped-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032839/Family-doctor-47-guilty-sexually-assaulting-three-female-patients-telling-one-terminally-ill-cancer-sufferer-Im-helping-groped-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:35:33+00:00

Dr Mohan Babu, 47, now faces jail after he ordered a patient who had terminal pancreatic cancer to take off her top before attacking her.

## Historic pier owner to pay £200,000 after daytripper, 94, who was 'full of energy' was killed on seafront walk by advertising board
 - [https://www.dailymail.co.uk/news/article-13033163/pier-owner-daytripper-94-killed-seafront-walk-advertising-board.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033163/pier-owner-daytripper-94-killed-seafront-walk-advertising-board.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:34:00+00:00

Margaret Carter, 94, travelled 40 miles from her home on the Welsh border to walk along the Grand Pier in Weston-super-Mare  when a board weighing more than 100kg was blown over by wind.

## Mother-of-two, 27, who had double mastectomy and breast reconstruction when she discovered she had cancer gene is left with breast 'the size of a watermelon' after contracting sepsis
 - [https://www.dailymail.co.uk/news/article-13033143/Mother-two-27-double-mastectomy-breast-reconstruction-discovered-cancer-gene-left-breast-size-watermelon-contracting-sepsis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13033143/Mother-two-27-double-mastectomy-breast-reconstruction-discovered-cancer-gene-left-breast-size-watermelon-contracting-sepsis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:32:11+00:00

Chloe Hughes had both her breasts removed after finding out she had the breast cancer gene 2 (BRCA2), which means she is more at risk of breast and ovarian cancer.

## Cancer deaths in the UK are set to rocket by over 50% by 2050 - with up to 625,000 Brits getting struck down every year
 - [https://www.dailymail.co.uk/health/article-13032739/Cancer-deaths-UK-set-rocket-50-CENT-2050-625-000-Brits-getting-struck-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13032739/Cancer-deaths-UK-set-rocket-50-CENT-2050-625-000-Brits-getting-struck-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:29:38+00:00

Researchers said there were 454,954 new cases of cancer in the UK in 2022, and this is expected to rise to 624,582 by 2050 - an increase of 37 per cent.

## The top 20 shows to watch on Amazon Prime Video right now: Our critics sift through hundreds of options to choose those worth watching
 - [https://www.dailymail.co.uk/tvshowbiz/article-13032275/The-20-shows-watch-Amazon-Prime-Video-right-critics-sift-hundreds-options-choose-worth-watching.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13032275/The-20-shows-watch-Amazon-Prime-Video-right-critics-sift-hundreds-options-choose-worth-watching.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:26:00+00:00

Nicole Kidman, James May and Saoirse Ronan - they all take a starring role in our pick of Amazon Prime shows available to watch now.

## Man is being chased by bailiffs for 100 unpaid driving fines... but has NEVER had a licence
 - [https://www.dailymail.co.uk/news/article-13032227/unpaid-driving-fines-bailiffs-never-licence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032227/unpaid-driving-fines-bailiffs-never-licence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:23:33+00:00

Rob Richards, from Birmingham, is being chased by debt collectors for 100 unpaid driving fines but does not have a driving licence.

## My husband resents me 'splashing out' from our joint account and it's making me miserable - what should I do? Money psychotherapist VICKY REYNAL replies
 - [https://www.dailymail.co.uk/money/saving/article-13032487/My-husband-resents-splashing-joint-account-making-miserable-Money-psychotherapist-VICKY-REYNAL-replies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/saving/article-13032487/My-husband-resents-splashing-joint-account-making-miserable-Money-psychotherapist-VICKY-REYNAL-replies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:23:24+00:00

It sounds to me as if you and your husband have opted for a joint bank account to simplify life admin but perhaps without a conversation about values and expectations.

## EU stink! Farmers throw manure and flaming missiles at riot cops outside European Union's Brussels HQ as Belgian shops admit they will have empty shelves due to protests demanding less red tape
 - [https://www.dailymail.co.uk/news/article-13032229/Furious-farmers-clash-riot-cops-surround-Brussels-HQ.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032229/Furious-farmers-clash-riot-cops-surround-Brussels-HQ.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:22:04+00:00

Convoys with hundreds of angry farmers driving heavy-duty tractors advanced toward the HQ, hell-bent on having their complaints about costs, rules and bureaucracy heard by the EU.

## 'I was raped by paedophile clown who was engaged to my sister': Brave victim reveals how children's entertainer groomed and sexually assaulted her when she was just 12
 - [https://www.dailymail.co.uk/news/article-13028629/I-raped-paedophile-clown-engaged-sister-Brave-victim-reveals-childrens-entertainer-groomed-sexually-assaulted-just-12.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13028629/I-raped-paedophile-clown-engaged-sister-Brave-victim-reveals-childrens-entertainer-groomed-sexually-assaulted-just-12.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:18:59+00:00

EXCLUSIVE: Robert Jamieson, known as 'Bobby Bubbles' was found guilty in December 2019 of 10 sexual offences against Chloe Birkin.

## Top England international polo player is facing a £2million lawsuit from groom, 20, whose 'Army career was ruined' when her pelvis was shattered by tumbling horse
 - [https://www.dailymail.co.uk/news/article-13032469/england-international-polo-player-lawsuit-groom-army-career.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032469/england-international-polo-player-lawsuit-groom-army-career.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T13:00:38+00:00

Catherine Lamacraft, top polo player, is facing a £2million lawsuit from a groom, Elena Thorman, who had her pelvis shattered aftera horse fell on her.

## Moment 'drunk and abusive' man is detained by four hero passengers after he kicks off on JetBlue flight from Gatwick Airport to New York JFK
 - [https://www.dailymail.co.uk/news/article-13032265/drunk-abusive-man-jetblue-flight-gatwick-airport-new-york-jfk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032265/drunk-abusive-man-jetblue-flight-gatwick-airport-new-york-jfk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T12:52:24+00:00

The incident happened on a JetBlue flight from Gatwick Airport to New York JFK on January 30.

## DR ELLIE CANNON: When to visit a pharmacy with an illness... and when you should visit a GP like me
 - [https://www.dailymail.co.uk/health/article-13032825/Are-pharmacists-really-good-doctors-treating-seven-key-illnesses-misdiagnose-new-health-service-launched-DR-ELLIE-CANNON-explains-pharmacy-illness-visit-GP.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-13032825/Are-pharmacists-really-good-doctors-treating-seven-key-illnesses-misdiagnose-new-health-service-launched-DR-ELLIE-CANNON-explains-pharmacy-illness-visit-GP.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T12:51:02+00:00

From today, high street pharmacists will get new powers to be the first port of call for seven common illnesses. The rules may cause worry, so I've tried to answer key questions.

## Inquest to probe whether seven-week-old baby who died of cardiac arrest following weeks of neglect at the hands of his 'cruel' drug addict parents would be alive today if he was rescued sooner
 - [https://www.dailymail.co.uk/news/article-13032951/inquest-probe-baby-cardiac-arrest-weeks-neglect-drug-addict-parents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032951/inquest-probe-baby-cardiac-arrest-weeks-neglect-drug-addict-parents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T12:49:04+00:00

Ronnie Rae Higginson died after he went into cardiac arrest at his home in Stoke-on-Trent on November, 26, 2019. He was seven-months-old at the time of his death.

## 'Nicola Sturgeon could cry from one eye if she wanted to': Scottish Secretary Alister Jack accuses of ex-FM of faking her tears at Covid inquiry - as bereaved families' rage at her for using pandemic to try to break up UK
 - [https://www.dailymail.co.uk/news/article-13032963/Nicola-Sturgeon-cry-one-eye-wanted-Ex-Minister-savaged-teary-performance-Covid-inquiry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032963/Nicola-Sturgeon-cry-one-eye-wanted-Ex-Minister-savaged-teary-performance-Covid-inquiry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T12:23:26+00:00

The former First Minister was berated by political opponents and the families of the bereaved after turning on the waterworks yesterday at the official Covid inquiry in Edinburgh.

## I've been forced to declare my Range Rover off road and sell it for a £15,000 loss after insurers quoted me £890 a MONTH - extortionate premiums are destroying lives
 - [https://www.dailymail.co.uk/news/article-13009601/Ive-forced-declare-Range-Rover-road-sell-15-000-loss-insurers-quoted-890-MONTH-extortionate-premiums-destroying-lives.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13009601/Ive-forced-declare-Range-Rover-road-sell-15-000-loss-insurers-quoted-890-MONTH-extortionate-premiums-destroying-lives.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T12:12:45+00:00

Kirsten Lijeskic, 38, says she got the £56,000 wheels in September 2022 and had been paying £130 a month insurance for her and her husband. But now the cheapest quote they can find is £890 a month.

## Why Harry Styles's friends are urging him to 'settle down, get married and have babies' on his 30th birthday today as he lives an incognito life in London with Canadian model Taylor Russell
 - [https://www.dailymail.co.uk/usshowbiz/article-13032513/Why-Harry-Styless-friends-urging-settle-married-babies-30th-birthday-today-lives-incognito-life-London-Canadian-model-Taylor-Russell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/usshowbiz/article-13032513/Why-Harry-Styless-friends-urging-settle-married-babies-30th-birthday-today-lives-incognito-life-London-Canadian-model-Taylor-Russell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T12:09:26+00:00

It's no great shock that Harry Styles, the pop colossus and former One Direction heart-throb, is planning celebrations for his 30th birthday today on both sides of the Atlantic.

## Metal detectorist, 54, strikes gold after digging up 3,000-year-old Bronze Age cloak fastener in 'one-in-a-billion' discovery
 - [https://www.dailymail.co.uk/news/article-13032613/Metal-detectorist-digs-Bronze-Age-cloak-fastener.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032613/Metal-detectorist-digs-Bronze-Age-cloak-fastener.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T12:03:46+00:00

Jonathan Needham, 54, found the 3,000-year-old cloak fastener on a patch of land in Ellastone, Staffordshire.

## 'How many more have to die?': Mother whose son, 15, killed himself after being cyber-bullied slams Mark Zuckerberg's 'not enough' apology because 'children are still being harmed and dying and all they care about is profits'
 - [https://www.dailymail.co.uk/news/article-13032481/rose-bronstein-son-nate-mark-zuckerberg-facebook-apology.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032481/rose-bronstein-son-nate-mark-zuckerberg-facebook-apology.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T11:58:41+00:00

Rose Bronstein lost her son Nate, 15, to suicide in January 2022 after he was brutally bullied on social media by his classmates in Chicago.

## NHS doctor who claimed her unproven IV drip treatments could help Covid sufferers and treat Parkinson's and Alzheimer's is suspended
 - [https://www.dailymail.co.uk/news/article-13032253/nhs-doctor-iv-drip-help-covid-parkinsons-alzheimers-suspended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032253/nhs-doctor-iv-drip-help-covid-parkinsons-alzheimers-suspended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T11:56:13+00:00

Dr Nimra Arshad, 29, branded herself as 'Dr Drips' offering IV infusions that she claimed she could 'tailor' to each customer 'to help with any medical condition'.

## Bride plans to start a GoFundMe to pay for her wedding: 'So tacky and inappropriate'
 - [https://www.dailymail.co.uk/femail/real-life/article-13031505/Bride-shocks-asking-start-GoFundMe-pay-wedding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/real-life/article-13031505/Bride-shocks-asking-start-GoFundMe-pay-wedding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T11:55:02+00:00

A bride-to-be has been slammed for asking if it's 'tacky' to start a GoFundMe page to help fund her wedding.

## 'I like playing Call of Duty...but I can't go to war': Residents of England's 'most patriotic estate' are split over conscription as some vow to 'be on the frontline' while younger locals say they would refuse to fight as a 'form of protest'
 - [https://www.dailymail.co.uk/news/article-13023935/Residents-Englands-patriotic-estate-conscription-locals-fight-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13023935/Residents-Englands-patriotic-estate-conscription-locals-fight-protest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T11:48:08+00:00

Residents in London 's 'most patriotic estate' are divided over whether they would join the army if the UK goes to war against Russia.

## Britain to start February warmer than Milan and San Francisco as the mercury hits 14C and conditions settle after weeks of storms and sub-zero temperatures
 - [https://www.dailymail.co.uk/news/article-13032145/UK-weather-mild-temperatures-February-storms-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032145/UK-weather-mild-temperatures-February-storms-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T10:52:15+00:00

Very mild air is moving into the UK from the Atlantic, bringing maximums of at least 13C (55F) to London for at least five days in a row from tomorrow until next Tuesday.

## Would YOU know what to do if hit by a chemical attack? Health experts reveal the quick steps you must take to save a victim
 - [https://www.dailymail.co.uk/news/article-13032191/acid-attack-health-experts-steps-save-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13032191/acid-attack-health-experts-steps-save-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T10:37:33+00:00

MailOnline has looked at what to do should you witness a chemical attack to help minimise damage. The main steps are - call 999, douse the victim in water and try and remove contaminated clothing.

## Vernon Kay treats glamorous daughter Phoebe, 19, to a night on the red carpet as they make rare public appearance together at the Vanity Fair Rising Star party
 - [https://www.dailymail.co.uk/tvshowbiz/article-13031111/Vernon-Kay-treats-glamorous-daughter-Phoebe-19-night-red-carpet-makes-rare-public-appearance-Vanity-Fair-Rising-Star-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-13031111/Vernon-Kay-treats-glamorous-daughter-Phoebe-19-night-red-carpet-makes-rare-public-appearance-Vanity-Fair-Rising-Star-party.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T08:53:13+00:00

Vernon Kay seemed in high spirits as he made a rare public appearance with stunning daughter Phoebe at the Vanity Fair EE Rising Star Party in London on Wednesday evening.

## Controversial new Boston migrant shelter is unveiled: Massachusetts' Dem. Governor seized cherished recreation center in deprived, majority-black neighborhood, infuriating locals
 - [https://www.dailymail.co.uk/news/article-13031807/roxbury-Melnea-Cass-Recreational-Center-migrants-boston.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031807/roxbury-Melnea-Cass-Recreational-Center-migrants-boston.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T06:58:55+00:00

The Melnea Cass Recreational Center in the Roxbury district of Boston has now been turned into a migrant shelter, to the anger of local residents.

## High-flying SEC director and her wealthy lawyer husband sue Google 'after its maps directed them to notorious South African road where they suffered horrific bloody attack by armed robbers'
 - [https://www.dailymail.co.uk/news/article-13031597/High-flying-SEC-director-wealthy-lawyer-husband-sue-Google-maps-directed-notorious-South-African-road-suffered-horrific-bloody-attack-armed-robbers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031597/High-flying-SEC-director-wealthy-lawyer-husband-sue-Google-maps-directed-notorious-South-African-road-suffered-horrific-bloody-attack-armed-robbers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T06:58:18+00:00

A wealthy Los Angeles couple are suing Google after they claim its Maps app led them down a notoriously dangerous road in South Africa where they were attacked.

## Lawless lawmaker! Arizona Dem. politician resigns in disgrace after she intimidated colleague with trance-like stare while rifling through purse 'for weapon,' threatened to hurl female official off balcony to kill her and meddled in child custody dispute
 - [https://www.dailymail.co.uk/news/article-13031579/Leezah-Sun-Arizona-Democrat-resigns-threats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031579/Leezah-Sun-Arizona-Democrat-resigns-threats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T06:58:12+00:00

A Democrat Arizona lawmaker resigned in disgrace amid claims she threatened to kill a female colleague, terrified another with a trance-like stare and meddled in a family's custody dispute.

## On this day - how sensational pictures of Princess Margaret in a swimsuit led the Queen to call her a 'GUTTERSNIPE'. And an enduring romance that changed royal marriages forever...
 - [https://www.dailymail.co.uk/news/article-13027177/Sensational-pictures-Margaret-Queen-GUTTERSNIPE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13027177/Sensational-pictures-Margaret-Queen-GUTTERSNIPE.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T06:57:45+00:00

The pictures, when they finally surfaced, rocked the nation. The apparently happily-married Princess Margaret, in figure-hugging corset-boned swimsuit, with a toyboy 18 years her junior.

## Shark attack photo leak twist: Identity of person who leaked picture of Sydney Harbour mauling victim in her hospital bed is revealed
 - [https://www.dailymail.co.uk/news/article-13031789/Shark-attack-photo-leak-twist-New-development-image-Sydney-Harbour-mauling-victim-St-Vincents-Hospital-bed-ended-social-media.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031789/Shark-attack-photo-leak-twist-New-development-image-Sydney-Harbour-mauling-victim-St-Vincents-Hospital-bed-ended-social-media.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T06:54:28+00:00

A photo of Sydney Harbour shark attack victim Lauren O'Neill appeared on social media after police officers provided images of her injuries to government scientists investigating the bite.

## All dressed up! Senator John Fetterman wears trademark hoodie with TUXEDO design as he steps out with Brazilian wife after denying their marriage is on the rocks
 - [https://www.dailymail.co.uk/news/article-13031741/Senator-John-Fetterman-wears-tuxedo-hoodie-Brazilian-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031741/Senator-John-Fetterman-wears-tuxedo-hoodie-Brazilian-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T06:53:09+00:00

John Fetterman is eager to prove that his marriage is going steady as he vehemently denies rumors that he and his Brazilian wife have separated and shares a picture of the happy couple dressed up.

## Oxford school shooter's married mom Jennifer Crumbley had AFFAIR with firefighter and texted him to say she'd 'failed miserably' as parent after son Ethan murdered four classmates
 - [https://www.dailymail.co.uk/news/article-13031671/Crumbley-mom-jennifer-firefighter-affair-ethan-oxford-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031671/Crumbley-mom-jennifer-firefighter-affair-ethan-oxford-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T06:24:09+00:00

'Be careful of anything you type on messenger or text,' firefighter Brian Meloche told her, 'The FBI is involved, they can access anything and everything'

## Denny's closes Oakland restaurant that's been open for 54 YEARS because California city is now so dangerous, weeks after In-N-Out shuttered nearby location over soaring crime
 - [https://www.dailymail.co.uk/news/article-13031399/oakland-crime-dennys-close-n-burger-robbery-car-theft.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031399/oakland-crime-dennys-close-n-burger-robbery-car-theft.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:52:07+00:00

The only branch of Denny's in Oakland closed its doors on Wednesday - just the latest establishment to close its doors amid soaring crime, with cars being regularly burgled.

## Three people are killed and nine are injured after under-construction private jet hangar COLLAPSES in Boise
 - [https://www.dailymail.co.uk/news/article-13031709/Boise-Idaho-private-jet-collapse-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031709/Boise-Idaho-private-jet-collapse-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:51:59+00:00

The private jet hangar under construction near the Boise Airport collapsed Wednesday evening.

## Uproar in Thailand as two men walk around Phuket Airport in Budgy Smuggler swimmers: '100 per cent chance they're Australian'
 - [https://www.dailymail.co.uk/news/article-13031041/Uproar-Thailand-two-men-walk-Phuket-Airport-Budgy-Smuggler-swimmers-100-cent-chance-theyre-Australian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031041/Uproar-Thailand-two-men-walk-Phuket-Airport-Budgy-Smuggler-swimmers-100-cent-chance-theyre-Australian.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:51:58+00:00

Two men in leopard print swimmers were captured outside Phuket airport, with the photo going viral on Thai social media this week.

## Biden has impressive SIX POINT lead over Trump in new Quinnipiac poll, with female voters and independents helping drive up support for 81 year-old Democrat president
 - [https://www.dailymail.co.uk/news/article-13031361/Biden-Trump-Quinnipiac-poll-2024-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031361/Biden-Trump-Quinnipiac-poll-2024-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:51:16+00:00

A poll boosts President Joe Biden's chances at re-election, showing him with a six-point lead over Donald Trump driven by huge leads with both women and independents.

## Eastgate Bondi Junction: Charity bin 'miner' caught red-handed by locals as he removes donated items
 - [https://www.dailymail.co.uk/news/article-13031289/Eastgate-Bondi-Junction-Make-Wish-charity-bin-miner-caught-red-handed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031289/Eastgate-Bondi-Junction-Make-Wish-charity-bin-miner-caught-red-handed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:47:14+00:00

Shocked shoppers at Eastgate Bondi Junction in Sydney's east were horrified to see the man's legs sticking out from the Make-A-Wish Foundation charity bin.

## Coles supermarket in Rose Bay Sydney under fire after recycling bin is found full of produce in 'excellent condition'
 - [https://www.dailymail.co.uk/news/article-13031527/Coles-Rose-Bay-recycling-bin-Sydney-produce-excellent-condition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031527/Coles-Rose-Bay-recycling-bin-Sydney-produce-excellent-condition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:47:09+00:00

A disgusted shopper has blasted Coles after he found a recycling bin out the back of one the supermarket's stores filled with discarded fruit and veg that was perfectly edible.

## How social media manager Leanne Casellas became a scam victim and was then locked out of her Facebook account - now she faces financial ruin
 - [https://www.dailymail.co.uk/news/article-13003399/Social-media-manager-Leanne-Casellas-scam-victim-locked-Facebook-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13003399/Social-media-manager-Leanne-Casellas-scam-victim-locked-Facebook-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:46:56+00:00

A social media manager who fell victim to a sophisticated hack has taken aim at Facebook for their inaction as she faces permanently losing her account.

## Anger over Anthony Albanese's refusal to hold a Covid royal commission: 'We need to know what really happened'
 - [https://www.dailymail.co.uk/news/article-13031547/Australia-Covid-inquiry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031547/Australia-Covid-inquiry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:36:22+00:00

Doctors have slammed the Labor Party for going back on its promise of a royal commission into Australia's response to the Covid pandemic.

## Aussie cities where house prices are booming again despite 13 interest rate rises - and they're not Sydney or Melbourne
 - [https://www.dailymail.co.uk/news/article-13031351/Perth-Brisbane-Sydney-Melbourne-house-prices-booming-consecutive-rate-rises.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031351/Perth-Brisbane-Sydney-Melbourne-house-prices-booming-consecutive-rate-rises.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:30:07+00:00

The Australian capital cities with the strongest house price growth get more new residents from other parts of the country instead of overseas immigration.

## Shane Drumgold described himself on LinkedIn with two defiant words... Until he suddenly DELETED them when Daily Mail Australia asked questions: Eye-opening insight into Bruce Lehrmann prosecutor
 - [https://www.dailymail.co.uk/news/article-13030501/Shane-Drumgold-DPP-Bruce-Lehrmann-inquiry-ACT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030501/Shane-Drumgold-DPP-Bruce-Lehrmann-inquiry-ACT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:27:28+00:00

Shane Drumgold was forced to step down as the ACT's Director of Public Prosecutions last year after a Board of Inquiry made a series of damning findings against him.

## Making herself at home! Adorable black footed cat called Gaia who's world's deadliest species is seen enjoying her new enclosure and chomping down on huge piece of meat at Utah zoo
 - [https://www.dailymail.co.uk/news/article-13031431/black-footed-cat-Gaia-deadliest-species-Utah-zoo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031431/black-footed-cat-Gaia-deadliest-species-Utah-zoo.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:18:28+00:00

The Hogle Zoo in Utah is welcoming a very cute kitty into its ranks, who is actually a killer in the wild.

## Breathtaking 1920s Spanish revival home that was one of the first properties to be constructed in California town of Pebble Beach lists for $22.75m
 - [https://www.dailymail.co.uk/news/article-13031517/1920s-Spanish-revival-home-California-Pebble-Beach-lists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031517/1920s-Spanish-revival-home-California-Pebble-Beach-lists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T05:17:39+00:00

A stunning mansion that is one of the oldest properties in the elegant coastal community of Pebble Beach has hit the market at $22.75 million.

## Iconic Australian dairy brand is saved by locals after Chinese buyer tried to shut down the business
 - [https://www.dailymail.co.uk/news/article-13031159/Iconic-Australian-dairy-brand-saved-locals-Chinese-buyer-tried-shut-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031159/Iconic-Australian-dairy-brand-saved-locals-Chinese-buyer-tried-shut-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T04:42:11+00:00

A popular Australian cheese and yoghurt brand has been saved from closure and is back in local hands after its Chinese owner shut down the business.

## The drinks are on her! E. Jean Carroll holds glitzy NYC party with liberal media friends who hailed her as an ICON after winning $83M defamation payout from Donald Trump over sex attack
 - [https://www.dailymail.co.uk/news/article-13031161/E-Jean-Carroll-NYC-party-liberal-media-trump-defamation-83m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031161/E-Jean-Carroll-NYC-party-liberal-media-trump-defamation-83m.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T04:42:04+00:00

The columnist was hailed as an 'icon' by a host of media power brokers at the exclusive Flower Shop bar in New York's Lower-East Side. 'She seemed delighted and vindicated,' one guest declared

## Alarming new detail after four Vietnamese exchange students vanished from their host families' homes in Adelaide
 - [https://www.dailymail.co.uk/news/article-13031463/vietnamese-students-missing-adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031463/vietnamese-students-missing-adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T04:41:49+00:00

Sunnie Nguyen, 17, had dinner with her host family at their South Plympton home, in Adelaide's inner-south, on the evening of January 8 before she was later discovered missing from her room.

## ABC finance guru Alan Kohler is forced to issue a statement confirming he is NOT dead: Here's why
 - [https://www.dailymail.co.uk/news/article-13030747/Alan-Kohler-ABC-finance-guru-tweets-not-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030747/Alan-Kohler-ABC-finance-guru-tweets-not-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T04:40:02+00:00

One of Australia's most trusted finance gurus has confirmed he is not dead.

## Revealed: The age when Aussies will earn the most money in their lifetime
 - [https://www.dailymail.co.uk/news/article-13030375/Treasury-figures-reveals-age-bracket-Aussies-earn-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030375/Treasury-figures-reveals-age-bracket-Aussies-earn-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:52:22+00:00

Australians typically remain on low salaries until they are well into their thirties. Treasury's Tax Expenditures and Insights Statement also revealed when workers are likely to see their salary peak.

## Chainsaw massacre: Century-old trees butchered for a better view in shocking act of vandalism
 - [https://www.dailymail.co.uk/news/article-13030421/Chainsaw-massacre-Century-old-trees-butchered-better-view-shocking-act-vandalism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030421/Chainsaw-massacre-Century-old-trees-butchered-better-view-shocking-act-vandalism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:49:58+00:00

A resident found four native coastal banksia trees hacked along a popular walking track on Tuesday morning in Swansea, 21kms north of Newcastle in NSW.

## Geoff swims every morning in Sydney Harbour just metres from where Lauren O'Neill was attacked by a shark. Here's why he has no plans to stop - and one thing he will never do
 - [https://www.dailymail.co.uk/news/article-13026263/Sydney-Harbour-shark-Lauren-ONeill-swim-Geoff-Petersson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13026263/Sydney-Harbour-shark-Lauren-ONeill-swim-Geoff-Petersson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:33:12+00:00

Potts Point retiree Geoff Petersson, 75, says the mauling swimmer Lauren O'Neill suffered will not stop him jumping into the water every morning at Elizabeth Bay.

## Conservative Canadian leader infuriates Trudeau officials by BANNING sex change procedures for children, trans women from female sports and teachers from hiding pronoun changes in Alberta province
 - [https://www.dailymail.co.uk/news/article-13031007/canada-alberta-trans-kids-Premier-Danielle-Smith-puberty-blockers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031007/canada-alberta-trans-kids-Premier-Danielle-Smith-puberty-blockers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:30:11+00:00

Danielle Smith, the premier of Alberta, on Wednesday announced a raft of policy changes she said were designed to protect young people from making life-altering gender decisions too young.

## Coolangatta: Construction worker's head sliced open when an object fell 4.5metres from above on a building site
 - [https://www.dailymail.co.uk/news/article-13031341/Coolangatta-Construction-workers-head-sliced-open-object-fell-2-5metres-building-site.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031341/Coolangatta-Construction-workers-head-sliced-open-object-fell-2-5metres-building-site.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:24:02+00:00

The man sliced his head open when he fell 4.5m after being struck by an object at a construction site in Coolangatta around 11am on Thursday.

## Powerball $250million: Four essential things you need to know about tonight's massive jackpot draw
 - [https://www.dailymail.co.uk/news/article-13030869/Powerball-200-million-Thursday-jackpot-draw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030869/Powerball-200-million-Thursday-jackpot-draw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:23:42+00:00

Millions of Aussies are gearing up for the massive $200million Powerball jackpot that will be drawn on Thursday night with around 50 per cent of the nation's adults expected to buy a ticket.

## Sisterhood café owner in Hobart breaks down exactly how much she makes from selling a small coffee
 - [https://www.dailymail.co.uk/news/article-13030809/Sisterhood-cafe-owner-Hobart-breaks-small-coffee-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030809/Sisterhood-cafe-owner-Hobart-breaks-small-coffee-costs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:13:14+00:00

The owner of Sisterhood café in Hobart broke down the exact figure that goes towards staff wages, electricity, rent and other business costs from every $4.80 small takeaway coffee sold.

## DC AG tells angry locals his department 'cannot prosecute and arrest our way out of' crime spiral that saw Trump official shot during carjacking that killed second victim, and 60 car break-ins in 72 hours
 - [https://www.dailymail.co.uk/news/article-13030911/dc-ag-department-prosecute-arrest-crime-trump-official-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030911/dc-ag-department-prosecute-arrest-crime-trump-official-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:05:58+00:00

The nation's capital is currently suffering a major crime wave, to which city officials have offered no adequate solution.

## Workplaces really ARE sexist: Women who try to network with their superiors to get ahead are belittled by colleagues, study shows - but no one minds when men do the same
 - [https://www.dailymail.co.uk/news/article-13031087/Workplaces-sexist-Women-network-belittled-colleagues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031087/Workplaces-sexist-Women-network-belittled-colleagues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:04:12+00:00

Women who network with 'high status' individuals at work end up being viewed negatively by their co-workers, a new study has found.

## Kristina Keneally's cop son Daniel, 35, sobs and heaves as he learns his fate for fabricating a statement that landed a man in jail
 - [https://www.dailymail.co.uk/news/article-13031251/Daniel-Keneally-spared-jail-police-officer-NSW-premier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031251/Daniel-Keneally-spared-jail-police-officer-NSW-premier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:04:10+00:00

Daniel Keneally, 35, was sentenced to a 15-month intensive correction order in Sydney 's Downing Centre Local Court on Thursday after earlier being convicted of fabricating evidence.

## 'Murderess' LA socialite Rebecca Grossman told cops she'd struck something with her Mercedes on night she killed two young brothers - despite trying to blame her secret lover, court hears
 - [https://www.dailymail.co.uk/news/article-13031129/LA-socialite-Rebecca-Grossman-blame-lover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031129/LA-socialite-Rebecca-Grossman-blame-lover.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:02:22+00:00

The LA socialite accused of killing two young brothers admitted to cops she'd struck something with her Mercedes SUV despite trying to blame the deaths on her baseball player lover in court.

## Another cyclone warning issued for Australia as heatwave strikes
 - [https://www.dailymail.co.uk/news/article-13030343/Cyclone-Queensland-forecast-Sydney-Brisbane-Melbourne-heatwave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030343/Cyclone-Queensland-forecast-Sydney-Brisbane-Melbourne-heatwave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T03:00:14+00:00

A widespread heatwave across Australia is forecast to bring temperatures reaching 40C this weekend while two storm systems rage in the east with the possibility of a third cyclone developing.

## Even 80 years on, there's no birdsong in Auschwitz. When she visited as a schoolgirl, Sabrina came away feeling its legacy was that such horrors would never happen again. But returning now, after October 7, she found it hard not to despair...
 - [https://www.dailymail.co.uk/news/article-13029955/Auschwitz-holocaust-October-7-Hamas-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13029955/Auschwitz-holocaust-October-7-Hamas-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:36:35+00:00

I visited Auschwitz (Sabrina pictured left) as part of a two-day conference organised by the European Jewish Association to coincide with last weekend's Holocaust Memorial Day.

## Mamta Dogra slammed a little boy's head into a sink. She didn't even call an ambulance as blood poured down his face. Now she has a staggering request
 - [https://www.dailymail.co.uk/news/article-13031051/Mamta-Dogra-slammed-little-boys-head-sink-blood-poured-face-didnt-call-ambulance-staggering-request.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031051/Mamta-Dogra-slammed-little-boys-head-sink-blood-poured-face-didnt-call-ambulance-staggering-request.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:31:47+00:00

Suburban mother Mamta Dogra found guilty of slamming a little boy's head into a sink wants to work with children at her Medibank job.

## Fake Uber driver is sent back to Pakistan after sexually assaulting a teenage girl in Melbourne
 - [https://www.dailymail.co.uk/news/article-13030191/Uber-driver-assault-woman-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030191/Uber-driver-assault-woman-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:31:14+00:00

Pakastani national Faizan Abdullah was posing as an Uber driver when he sexually assaulted a Melbourne teenager after she had ordered a car.

## Browns Plains: Six people injured and taken to hospital after four car pile-up
 - [https://www.dailymail.co.uk/news/article-13031163/Browns-Plains-Six-people-injured-taken-hospital-four-car-pile-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031163/Browns-Plains-Six-people-injured-taken-hospital-four-car-pile-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:27:18+00:00

Emergency services were called to  at a four-vehicle crash on Browns Plains Road in the Logan suburb of Browns Plains shortly after 9.30am on Thursday.

## Rick Thorburn, murderer who killed Tiahleigh Palmer to cover up his son's incestuous relationship, tries to take his own life in jail and is rushed to hospital
 - [https://www.dailymail.co.uk/news/article-13031171/rick-thorburn-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031171/rick-thorburn-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:22:55+00:00

Rick Thorburn has attempted to take his own life for the third time after being convicted of murdering 12-year-old schoolgirl Tiahleigh Palmer.

## I'm the secret granddaughter of the Lamborghini sports car founder... and his billions should be MINE: Glamorous Italian beautician, 35, hires private detective to collect heiress' SALIVA in bid to prove they're sisters amid bitter libel battle
 - [https://www.dailymail.co.uk/news/article-13030913/Im-secret-granddaughter-Lamborghini-sports-car-founder-Glamorous-Italian-beautician-35-hires-private-detective-collect-heiress-SALIVA-bid-prove-theyre-sisters-amid-bitter-libel-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030913/Im-secret-granddaughter-Lamborghini-sports-car-founder-Glamorous-Italian-beautician-35-hires-private-detective-collect-heiress-SALIVA-bid-prove-theyre-sisters-amid-bitter-libel-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:16:33+00:00

Flavia Borzone, 35, is being sued by the son of the founder of the legendary hyper-car manufacturer for defamation, after she publicly claimed he slept with her mother

## British forces in the Middle East 'on high alert' for Iranian attacks as America plans retaliation for killing of three US soldiers: 'Big Lizzie warship set to be deployed to Red Sea' as fears grow regional war could erupt
 - [https://www.dailymail.co.uk/news/article-13031209/British-Middle-East-high-alert-Iran-America-Red-Sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031209/British-Middle-East-high-alert-Iran-America-Red-Sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:15:27+00:00

The UK is reportedly poised to send £4billion aircraft carrier HMS Queen Elizabeth to the Red Sea this week after Iran-backed Houthis vowed to disrupt shipping 'for the long-term'.

## Bitter blow for beer drinkers as John Smith's Extra Smooth bitter becomes latest brew to have its alcohol strength slashed while its prices are HIKED - after Shepherd Neame, Carlsberg, Foster's and Old Speckled Hen all did same
 - [https://www.dailymail.co.uk/news/article-13031249/beer-John-Smiths-alcohol-strength-slashed-prices-Shepherd-Neame-Carlsberg-Fosters-Old-Speckled-Hen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031249/beer-John-Smiths-alcohol-strength-slashed-prices-Shepherd-Neame-Carlsberg-Fosters-Old-Speckled-Hen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:14:23+00:00

Heineken is cutting the alcohol by volume (ABV) in its John Smith's Extra Smooth from 3.6 per cent to 3.4 per cent.

## Trump leads Biden in ALL SEVEN key swing states but could lose almost HALF of voters if he is found guilty of a crime, new poll shows
 - [https://www.dailymail.co.uk/news/article-13030985/Trump-Biden-2024-poll-swing-states.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030985/Trump-Biden-2024-poll-swing-states.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:05:31+00:00

Former President Donald Trump leads his successor Joe Biden by six points in a head-to-head poll done entirely in the most important swing states.

## Japan's 83-year-old former Prime Minister Taro Aso sparks sexism storm by claiming female Foreign Minister is 'not that good looking' and getting her surname wrong TWICE in bizarre speech
 - [https://www.dailymail.co.uk/news/article-13031221/Japans-83-year-old-former-Prime-Minister-Taro-Aso-sparks-sexism-storm-claiming-female-Foreign-Minister-not-good-looking-getting-surname-wrong-TWICE-bizarre-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031221/Japans-83-year-old-former-Prime-Minister-Taro-Aso-sparks-sexism-storm-claiming-female-Foreign-Minister-not-good-looking-getting-surname-wrong-TWICE-bizarre-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:05:29+00:00

Taro Aso, 83, made the sexist remarks about Japan's Foreign Minister, Yoko Kamikawa, during a recent speech.

## James Cleverly urges police chiefs to 'get back to core policing' by keeping officers within communities
 - [https://www.dailymail.co.uk/news/article-13031089/James-Cleverly-urges-police-chiefs-core-policing-keeping-officers-communities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031089/James-Cleverly-urges-police-chiefs-core-policing-keeping-officers-communities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T02:01:16+00:00

In his first meeting with the National Policing Board, James Cleverly said that restoring the presence of officers in communities was a vital part of restoring trust in the police.

## Now striking train drivers' union demand ANOTHER pay rise so they can use iPad-style tablets at work instead of noticeboards
 - [https://www.dailymail.co.uk/news/article-13030987/strikes-train-drivers-union-pay-rise-iPads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030987/strikes-train-drivers-union-pay-rise-iPads.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:47:10+00:00

Britain's railways have been crippled by train driver strikes - causing misery for Brits across the country. Now the train drivers want another pay rise for the inconvenience of using iPad-style tablets.

## House passes sprawling $78BILLION tax bill that expands child tax credits and brings back business deductions: Deal passes despite some GOP opposition and now heads to the Senate
 - [https://www.dailymail.co.uk/news/article-13030019/house-passes-tax-bill-child-credit-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030019/house-passes-tax-bill-child-credit-business.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:45:51+00:00

The House passed a sprawling tax bill Wednesday evening in a rare showing of bipartisanship.

## The Ken Bruce backlash goes on... Radio 2 has lost 1.4 million listeners since the veteran broadcaster's shock departure, figures reveal
 - [https://www.dailymail.co.uk/news/article-13031151/Ken-Bruce-backlash-Radio-2-lost-million-listeners-veteran-broadcasters-shock-departure-figures-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031151/Ken-Bruce-backlash-Radio-2-lost-million-listeners-veteran-broadcasters-shock-departure-figures-reveal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:35:21+00:00

Some 1.4 million people have switched off since the veteran broadcaster's departure, with just 6.8 million tuning in weekly over the past three months compared to 8.2 million in the same period last year.

## Pedophile teacher Mary Kay Letourneau's daughter gives birth to baby boy three years after predator's death: Infant's grandpa was raped by Letourneau from the age of 12
 - [https://www.dailymail.co.uk/news/article-13030831/pedophile-teacher-mary-kay-letourneau-daughter-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030831/pedophile-teacher-mary-kay-letourneau-daughter-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:26:42+00:00

A source said that Georgia and her delivery driver boyfriend became parents earlier this month, making Letourneau's former victim a grandfather for the first time at the age of 40.

## The number of drivers caught using their phones at the wheel almost doubles in a year amid rise in citizen dashcam 'detectives', research finds
 - [https://www.dailymail.co.uk/news/article-13030301/The-number-drivers-caught-using-phones-wheel-doubles-year-amid-rise-citizen-dashcam-detectives-research-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030301/The-number-drivers-caught-using-phones-wheel-doubles-year-amid-rise-citizen-dashcam-detectives-research-finds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:24:12+00:00

The number of drivers caught using their phones at the wheel almost doubles in a year amid rise in citizen dashcam 'detectives', research finds

## Boris Johnson takes swipe at Rishi Sunak's post-Brexit Northern Ireland deal as he says the UK 'must retain the courage to diverge' from the European model
 - [https://www.dailymail.co.uk/news/article-13030963/Boris-Johnson-takes-swipe-Rishi-Sunaks-post-Brexit-Northern-Ireland-deal-says-UK-retain-courage-diverge-European-model.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030963/Boris-Johnson-takes-swipe-Rishi-Sunaks-post-Brexit-Northern-Ireland-deal-says-UK-retain-courage-diverge-European-model.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:15:56+00:00

The former prime minister suggested it could weaken the UK's ability to diverge from EU trading rules in future, saying that the country must 'retain the appetite' to break from the high-regulation EU model.

## Georges Hall, Sydney: Grim update to suburban row in Sydney's south-western suburbs after dog savagely attacked a man
 - [https://www.dailymail.co.uk/news/article-13030821/Georges-Hall-Sydney-dog-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030821/Georges-Hall-Sydney-dog-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:14:27+00:00

Alex the American Akita - a variation of the Japanese dog originally bred to hunt bears - badly mauled a man's arm and leg in the attack in Sydney's west in January.

## Childcare does not give youngsters the 'best start in life' with love and attachment absent from the discussion on what is best for children, report claims
 - [https://www.dailymail.co.uk/news/article-13030585/Childcare-does-not-youngsters-best-start-life-love-attachment-absent-discussion-best-children-report-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030585/Childcare-does-not-youngsters-best-start-life-love-attachment-absent-discussion-best-children-report-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:11:03+00:00

Universal childcare - where children are entitled to a free or cheap place at nursery or daycare - does not benefit the majority of youngsters, according to the report.

## Major development in investigation into William Tyrrell case as key deadline is blown
 - [https://www.dailymail.co.uk/news/article-13026901/William-Tyrrells-foster-mother-deadline-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13026901/William-Tyrrells-foster-mother-deadline-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:09:24+00:00

The deadline for charging William Tyrrell 's foster mother over the toddler's disappearance has arrived, but is likely to be pushed back to later in the year.

## Dramatic moment Oxford school shooter Ethan Crumbley's mom was arrested is seen for first time at her manslaughter trial
 - [https://www.dailymail.co.uk/news/article-13030617/michigan-school-shooter-ethan-crumbley-parents-cops-mother-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030617/michigan-school-shooter-ethan-crumbley-parents-cops-mother-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:05:44+00:00

The shocking moment the parents of Oxford school shooter Ethan Crumbley were arrested after going on the run was caught on police bodycam footage.

## New theory emerges about Woolworths' Australia Day snub
 - [https://www.dailymail.co.uk/news/article-13030299/woolworths-australia-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030299/woolworths-australia-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T01:04:51+00:00

Explosive comments from an Aboriginal lawyer unveil a startling theory behind Woolworths' Australia Day snub.

## BBC Dragons Den faces probe from ad watchdog over 'fakery storm' sparked by entrepreneur Giselle Boxer's 'unfounded' claims that ear seeds aided recovery from ME
 - [https://www.dailymail.co.uk/news/article-13030801/BBC-Dragons-Den-faces-probe-ad-watchdog-fakery-storm-sparked-entrepreneur-Giselle-Boxers-unfounded-claims-ear-seeds-aided-recovery-ME.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030801/BBC-Dragons-Den-faces-probe-ad-watchdog-fakery-storm-sparked-entrepreneur-Giselle-Boxers-unfounded-claims-ear-seeds-aided-recovery-ME.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:58:53+00:00

Giselle Boxer, 31, (pictured) said she had used 'diet, acupuncture, Chinese herbs and ear seeds' to aid her recovery from myalgic encephalomyelitis (ME).

## Killer builder's twisted 24 hours: How murderous Jehovah's Witness bludgeoned female customer with a hammer - then whistled as he packed up tools before leading a service for worshippers just hours later at the church where they met
 - [https://www.dailymail.co.uk/news/article-13030787/Killer-builders-twisted-24-hours-murderous-Jehovahs-Witness-bludgeoned-female-customer-hammer-whistled-packed-tools-leading-service-worshippers-just-hours-later-church-met.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030787/Killer-builders-twisted-24-hours-murderous-Jehovahs-Witness-bludgeoned-female-customer-hammer-whistled-packed-tools-leading-service-worshippers-just-hours-later-church-met.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:52:04+00:00

Cowboy builder Peter Norgrove, 43, was recorded whistling as he packed away his tools as victim Sharon Gordon, who he was doing work for, lay dying in her home

## You poor things! One in four men between 16 and 59 think women have it easier
 - [https://www.dailymail.co.uk/news/article-13030673/Men-women-easier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030673/Men-women-easier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:42:19+00:00

The finding comes in research from King's College London and the Global Institute for Women's Leadership. It looked at attitudes of the public to masculinity and women's equality.

## EV drivers are unhappy with the UK's charging network as 70% say they are dissatisfied with the availability of stations
 - [https://www.dailymail.co.uk/news/article-13030353/Electric-vehicles-drivers-UK-charging-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030353/Electric-vehicles-drivers-UK-charging-cars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:33:39+00:00

Around 70% of UK electric car owners are dissatisfied with the availability and operation of charging stations, a poll by Which? has found.

## No looking back! The Polestar 4 is set to be the first car on British roads with no rear window
 - [https://www.dailymail.co.uk/news/article-13031013/Polestar-4-British-roads-no-rear-window.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13031013/Polestar-4-British-roads-no-rear-window.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:32:16+00:00

The Swedish-made Polestar 4 will be fitted with a high-definition screen in place of a rear-view mirror, displaying a live feed from a camera fitted on the roof.

## Woman sues Bill Cosby claiming star raped her in Elvis Suite of Las Vegas Hilton in 1986 when she was 17-year-old virgin after giving her blue capsule he claimed would clear her sinuses
 - [https://www.dailymail.co.uk/news/article-13030695/woman-sues-bill-cosby-raping-las-vegas-hilton-Chelan-Lasha.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030695/woman-sues-bill-cosby-raping-las-vegas-hilton-Chelan-Lasha.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:18:49+00:00

A Californian woman has sued Bill Cosby in a Las Vegas court, accusing the disgraced comedian, now 86, of raping her in 1986 when she was 17. She said he lured her with the promise of modeling.

## Little boy trapped inside claw machine in Capalaba shopping centre, Brisbane
 - [https://www.dailymail.co.uk/news/article-13030891/boy-claw-machine-brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030891/boy-claw-machine-brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:18:28+00:00

Ethan, three, was with his family at the Capalaba shopping centre, south-east of Brisbane, on Saturday evening when he decided to climb into the machine.

## 'She was screaming, 'my eyes'': Acid attack thug targets mother and her two children in London's Clapham South before fleeing the scene - as nine including hero passers-by and police are rushed to hospital
 - [https://www.dailymail.co.uk/news/article-13030875/screaming-eyes-Acid-attack-mother-two-children-Londons-Clapham-South-fleeing-scene-nine-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030875/screaming-eyes-Acid-attack-mother-two-children-Londons-Clapham-South-fleeing-scene-nine-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:17:18+00:00

The three victims are among nine injured as eight have been rushed to hospital after the horror incident in south London , police said.

## Hamas placed booby-trap bombs on the bodies of women killed in their October 7 attack on Israel, inquiry hears
 - [https://www.dailymail.co.uk/news/article-13030969/Hamas-placed-booby-trap-bombs-bodies-women-killed-October-7-attack-Israel-inquiry-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030969/Hamas-placed-booby-trap-bombs-bodies-women-killed-October-7-attack-Israel-inquiry-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:14:11+00:00

Bodies of women killed by Hamas in its attack on Israel on October 7 were booby-trapped with grenades and beheaded, an inquiry at Westminster heard yesterday.

## Peta Credlin reveals how she was almost driven into the grave while chief of staff to Tony Abbott: 'Some days, I honestly don't know how I managed to survive, and I mean literally'
 - [https://www.dailymail.co.uk/news/article-13030529/Peta-Credlin-reveals-personal-toll-chief-staff-Tony-Abbott.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030529/Peta-Credlin-reveals-personal-toll-chief-staff-Tony-Abbott.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:12:16+00:00

Peta Credlin has revealed the devastating personal toll extracted by her time as chief of staff to former prime minister Tony Abbott.

## Jeremy Hunt reveals he won't be able to make substantial tax cuts in his Spring Budget
 - [https://www.dailymail.co.uk/news/article-13030943/Jeremy-Hunt-tax-cuts-Spring-budget.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030943/Jeremy-Hunt-tax-cuts-Spring-budget.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:11:40+00:00

Chancellor Jeremy Hunt has revealed that the Spring Budget will feature no substantial tax cuts when it is unveiled on March 6 after an International Monetary Fund warning.

## NY Gov. Kathy Hochul suggests DEPORTING migrants who were allowed to walk free on no bail after beating cops in NYC's Times Square
 - [https://www.dailymail.co.uk/news/article-13030497/ny-governor-kathy-hochul-deporting-migrants-times-square.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030497/ny-governor-kathy-hochul-deporting-migrants-times-square.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:10:32+00:00

New York Governor Kathy Hochul continued her U-turn on migrants as she said that the state should consider deporting a group of migrants who went free on bail after attacking two cops in Times Square.

## You cheeky monkey! Is macaque taunting his pursuers?
 - [https://www.dailymail.co.uk/news/article-13030329/You-cheeky-monkey-macaque-taunting-pursuers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030329/You-cheeky-monkey-macaque-taunting-pursuers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:05:24+00:00

The first drone images of Scotland's escaped Japanese snow monkey show the fugitive only 300 yards from home. He has spent four days on the run after getting out of his enclosure.

## JOHN MACLEOD: Sturgeon once almost walked on water - the speed and totality of her collapse is astonishing
 - [https://www.dailymail.co.uk/news/article-13030197/JOHN-MACLEOD-Sturgeon-walked-water-speed-totality-collapse-astonishing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030197/JOHN-MACLEOD-Sturgeon-walked-water-speed-totality-collapse-astonishing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:04:57+00:00

One would have to go back to Charles Haughey - perhaps even to the disgraced President Nixon - to recall a political reputation today in such rubble as that of Nicola Sturgeon.

## STEPHEN DAISLEY: His beak picked over her record with the scrupulous attention of a buzzard with some juicy carrion
 - [https://www.dailymail.co.uk/news/article-13030107/STEPHEN-DAISLEY-beak-picked-record-scrupulous-attention-buzzard-juicy-carrion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030107/STEPHEN-DAISLEY-beak-picked-record-scrupulous-attention-buzzard-juicy-carrion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:04:40+00:00

Her tone wavered, her voice softened, she grew quieter. She had tried, she said, to be the best First Minister she could be. 'It's for others to judge the extent to which I succeeded' .

## Rapist That 70s Show star Danny Masterson is moved to maximum security California State Prison that once held Charles Manson, where he will be under constant threat of attack
 - [https://www.dailymail.co.uk/news/article-13030567/70s-danny-masterson-california-state-prison-charles-manson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030567/70s-danny-masterson-california-state-prison-charles-manson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:04:35+00:00

Danny Masterson has been moved to a maximum-security California prison - the same one where Charles Manson was held for a decade.

## This sleekit and secretive performance leaves her reputation in tatters
 - [https://www.dailymail.co.uk/news/article-13030149/This-sleekit-secretive-performance-leaves-reputation-tatters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030149/This-sleekit-secretive-performance-leaves-reputation-tatters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:04:25+00:00

Yesterday was the moment at which Nicola Sturgeon had the opportunity to come clean with the Scottish public. Of course she didn't. Few will have expected full and frank answers.

## The humbling of Sturgeon
 - [https://www.dailymail.co.uk/news/article-13030047/The-humbling-Sturgeon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030047/The-humbling-Sturgeon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:04:05+00:00

Nicola Sturgeon's reputation lay in tatters last night after she apologised to bereaved families for the deaths of thousands of Scots during her handling of the pandemic.

## Cop assault thug walks free... after court told of his holiday plans and childcare problems
 - [https://www.dailymail.co.uk/news/article-13030321/Cop-assault-thug-walks-free-court-told-holiday-plans-childcare-problems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-13030321/Cop-assault-thug-walks-free-court-told-holiday-plans-childcare-problems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2024-02-01T00:03:46+00:00

A driver who reversed away at speed with a police officer trying to cling on to the vehicle has avoided a prison sentence. PC Paul Benson sustained injuries and was left with long-term problems.

