# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## I Hate Bad Texters
 - [https://www.youtube.com/watch?v=ielNHdQtzec](https://www.youtube.com/watch?v=ielNHdQtzec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2024-02-01T14:01:01+00:00

If you leave me on "read" you are dead to me... P.S. Sign up to my Patreon for behind the scenes bloopers and early access to videos here: https://www.patreon.com/julienolke

Actors: Julie Nolke
Writer: Julie Nolke
Camera: Sam Larson
Editor: Alec McKay
Production Assistant: Alexa MacKell

