# Source:The Joe Rogan Experience, URL:https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk, language:en

## #2096 - Josh Dubin & Sheldon Johnson
 - [https://open.spotify.com/episode/3nsOv2Bl6OVvTcjUrJ1GUa](https://open.spotify.com/episode/3nsOv2Bl6OVvTcjUrJ1GUa)
 - RSS feed: https://open.spotify.com/show/4rOoJ6Egrf8K2IrywzwOMk
 - date published: 2024-02-01T18:00:00+00:00

Listen to this episode from The Joe Rogan Experience on Spotify. Josh Dubin is the Executive Director of the Perlmutter Center for Legal Justice, a criminal justice reform advocate, and civil rights attorney. https://cardozo.yu.edu/directory/josh-dubin

