# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 💌 Zostań admin@microsoft.com! #37c3
 - [https://www.youtube.com/watch?v=mjER_k2_OgY](https://www.youtube.com/watch?v=mjER_k2_OgY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2024-02-01T05:30:13+00:00

Na tegorocznym Chaos Computer Club było trochę o serwerach pocztowych. Polecam wykład SMTP Smuggling – Spoofing E-Mails Worldwide!
 
Źródła:
http://tinyurl.com/28pz4p53

#email #Microsoft #postfix #smtp

