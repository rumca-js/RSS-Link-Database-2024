# Source:FlashGitz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA, language:en-US

## Aladdin BUT it's Historically Accurate!
 - [https://www.youtube.com/watch?v=EZasbWMuUzQ](https://www.youtube.com/watch?v=EZasbWMuUzQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNnKprAG-MWLsk-GsbsC2BA
 - date published: 2024-02-01T17:00:20+00:00

#flashgitz #animationmeme #disney #aladdin

