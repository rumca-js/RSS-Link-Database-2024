# Source:Board Game Quest, URL:https://www.boardgamequest.com/feed, language:en-US

## Inside Job Review
 - [https://www.boardgamequest.com/inside-job-review](https://www.boardgamequest.com/inside-job-review)
 - RSS feed: https://www.boardgamequest.com/feed
 - date published: 2024-02-01T14:09:46+00:00

<img alt="Inside Job" class="webfeedsFeaturedVisual not-transparent wp-post-image" height="888" src="https://www.boardgamequest.com/wp-content/uploads/2024/01/Inside-Job-738x1024.webp" width="640" />If you are a fan of trick taking games you very well may be familiar with The Crew. Released in 2020, the Crew was a fully cooperative trick taking game that had players trying to complete missions rather than just trying to win the most tricks. Many credit it with reigniting a lot of interest [&#8230;]
<p><a href="https://www.boardgamequest.com/inside-job-review/" rel="nofollow">Source</a></p>

