# Source:RP - Regiony, URL:https://regiony.rp.pl/rss/1441-regiony, language:pl-PL

## Miasta rozpoczynają budowy nowych dróg rowerowych. Pomoże porozumienie z PKP PLK
 - [https://regiony.rp.pl/inwestycje/art39774391-miasta-rozpoczynaja-budowy-nowych-drog-rowerowych-pomoze-porozumienie-z-pkp-plk](https://regiony.rp.pl/inwestycje/art39774391-miasta-rozpoczynaja-budowy-nowych-drog-rowerowych-pomoze-porozumienie-z-pkp-plk)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-02-01T16:41:29+00:00

W Katowicach rozkręcają się inwestycje w budowę dróg dla rowerów. Miasto właśnie wybrało wykonawcę pierwszej velostrady, która połączy dwie dzielnice – Brynów z Giszowcem.

## Stopy procentowe uderzają w samorządy. Co to oznacza dla mieszkańców?
 - [https://regiony.rp.pl/finanse-w-regionach/art39774011-stopy-procentowe-uderzaja-w-samorzady-co-to-oznacza-dla-mieszkancow](https://regiony.rp.pl/finanse-w-regionach/art39774011-stopy-procentowe-uderzaja-w-samorzady-co-to-oznacza-dla-mieszkancow)
 - RSS feed: https://regiony.rp.pl/rss/1441-regiony
 - date published: 2024-02-01T14:01:20+00:00

Koszty obsługi długu w lokalnych budżetach drastycznie wzrosły w ślad za drożejącym pieniądzem. To ogranicza przestrzeń na inne wydatki, w tym inwestycje samorządów.

