# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Kim Dzong Una zastąpi jego córka? "Władza zostanie utrzymana. Pozostanie w rękach jednej rodziny"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/kim-dzong-una-zastapi-jego-corkawladza-zostanie-utrzymana-pozostanie-w-rekach-jednej-rodziny-st7753323?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/kim-dzong-una-zastapi-jego-corkawladza-zostanie-utrzymana-pozostanie-w-rekach-jednej-rodziny-st7753323?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T20:52:11+00:00

<img alt="Kim Dzong Una zastąpi jego córka? " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-bnc6eb-cnn-7753330/alternates/LANDSCAPE_1280" />
    Kim Dzong Un od lat rządzi Koreą Północną. Okazuje się, że dyktator ma ogromne wsparcie w postaci siostry i córki. Ponadto koreański przywódca na stanowisko szefowej dyplomacji powołał kobietę. Dlatego padają pytania, czy po tylu latach władzę w kraju może objąć kobieta?

## "Najgorsza susza, jaką odnotowano". Restrykcje dla sześciu milionów ludzi
 - [https://tvn24.pl/tvnmeteo/swiat/hiszpania-katalonia-stan-nadzwyczajny-z-powodu-najgorszej-suszy-w-historii-st7753319?source=rss](https://tvn24.pl/tvnmeteo/swiat/hiszpania-katalonia-stan-nadzwyczajny-z-powodu-najgorszej-suszy-w-historii-st7753319?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T20:43:45+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-lgkj6m-susza-w-katalonii-7753352/alternates/LANDSCAPE_1280" />
    W hiszpańskim regionie Katalonii ogłoszono stan nadzwyczajny w związku z najgorszą w historii suszą. Wśród obowiązujących od czwartku środków mających na celu złagodzenie sytuacji są między innymi ograniczenia w myciu samochodów i napełnianiu basenów. Zabronione zostało używanie pryszniców na plażach, nie będą działać też fontanny.

## "Dla nowych pokoleń muzealna lekcja historii jest konieczna". W Treblince powstanie wystawa stała
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-w-muzeum-treblinka-powstanie-wystawa-stala-st7753103?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-w-muzeum-treblinka-powstanie-wystawa-stala-st7753103?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T20:10:51+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2liyaj-nowy-pawilon-w-muzeum-treblinka-wizualizacja-5638492/alternates/LANDSCAPE_1280" />
    W Żydowskim Instytucie Historycznym podpisano porozumienie w sprawie utworzenia wystawy stałej w Muzeum Treblinka. Ekspozycja powstanie w budowanym obecnie pawilonie. Obiekt będzie gotowy za dwa lata.

## Ustawa budżetowa opublikowana w Dzienniku Ustaw. Oto jej ostateczny kształt
 - [https://tvn24.pl/biznes/z-kraju/budzet-na-2024-rok-ustawa-opublikowana-w-dzienniku-ustaw-st7753307?source=rss](https://tvn24.pl/biznes/z-kraju/budzet-na-2024-rok-ustawa-opublikowana-w-dzienniku-ustaw-st7753307?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T20:04:02+00:00

<img alt="Ustawa budżetowa opublikowana w Dzienniku Ustaw. Oto jej ostateczny kształt" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2p5c8f-andrzej-domanski-na-sali-obrad-sejmu-7537241/alternates/LANDSCAPE_1280" />
    W czwartek w "Dzienniku Ustaw" opublikowano ustawę budżetową na 2024 rok oraz ustawę okołobudżetową. Zakładają one m.in. podwyżki dla budżetówki w tym dla nauczycieli o 30 proc. Przepisy przewidują również przeznaczenie 3 mld zł m.in. na leczenie chorób onkologicznych.

## "Trybunał Konstytucyjny postanowił pełnić rolę swojego rodzaju kotwicy autokracji"
 - [https://tvn24.pl/polska/dzialania-trybunalu-konstytucyjnego-decyzja-prezydenta-w-sprawie-ustawy-budzetowej-dariusz-mazur-i-michal-wojcik-komentuja-7753156?source=rss](https://tvn24.pl/polska/dzialania-trybunalu-konstytucyjnego-decyzja-prezydenta-w-sprawie-ustawy-budzetowej-dariusz-mazur-i-michal-wojcik-komentuja-7753156?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T20:00:35+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-trynq4-kropka-nad-i-7753260/alternates/LANDSCAPE_1280" />
    Nie jestem w stanie zrozumieć decyzji prezydenta, jej uzasadnienie prawne nie istnieje dla mnie - mówił w "Kropce nad i" w TVN24 wiceminister sprawiedliwości, sędzia Dariusz Mazur, odnosząc się do decyzji prezydenta w sprawie przekazania ustawy budżetowej w trybie kontroli następczej do Trybunału Konstytucyjnego. Natomiast były wiceszef tego resortu Michał Wójcik z Suwerennej Polski ocenił, że to "dobry ruch". Goście programu rozmawiali także o działaniach Trybunału Konstytucyjnego w sprawie decyzji ministra Adama Bodnara.

## Magdalena Biejat o starcie w wyborach na prezydenta Warszawy: moja kandydatura jest na stole
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-magdalena-biejat-o-wyborach-na-prezydenta-stolicy-moja-kandydatura-jest-na-stole-st7753222?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-magdalena-biejat-o-wyborach-na-prezydenta-stolicy-moja-kandydatura-jest-na-stole-st7753222?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T19:55:52+00:00

<img alt="Magdalena Biejat o starcie w wyborach na prezydenta Warszawy: moja kandydatura jest na stole" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b3nmen-magdalena-biejat-7753205/alternates/LANDSCAPE_1280" />
    - Jestem zainteresowana. Ta rozmowa jest na stole - powiedziała w "Faktach po Faktach" TVN24 wicemarszałkini Senatu Magdalena Biejat, pytana, czy będzie kandydatką Lewicy w wyborach na prezydenta Warszawy. Zapowiedziała, że decyzja w tej sprawie zostanie ogłoszona na początku przyszłego tygodnia.

## CBS: Waszyngton zatwierdził plany ataków na irańskie obiekty w Iraku i Syrii
 - [https://tvn24.pl/swiat/usa-bliski-wschod-cbs-waszyngton-zatwierdzil-plany-atakow-na-iranskie-obiekty-w-iraku-i-syrii-7753041?source=rss](https://tvn24.pl/swiat/usa-bliski-wschod-cbs-waszyngton-zatwierdzil-plany-atakow-na-iranskie-obiekty-w-iraku-i-syrii-7753041?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T18:57:14+00:00

<img alt="CBS: Waszyngton zatwierdził plany ataków na irańskie obiekty w Iraku i Syrii " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nn2e12-amerykanskie-mysliwce-f-16-7411572/alternates/LANDSCAPE_1280" />
    Plany amerykańskich ataków na irańskie obiekty w Iraku i Syrii zostały zatwierdzone przez Waszyngton - potwierdzili anonimowo amerykańscy urzędnicy, cytowani w czwartek przez CBS News. Ma to być odpowiedź na ataki dronów i rakiet wymierzone w siły USA w regionie.

## Mazała sprayem po ścianie bloku. Kiedy zobaczyła strażników, rzuciła się do ucieczki
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ochota-mazala-po-scianie-bloku-sprayem-kiedy-zobaczyla-straznikow-rzucila-sie-do-ucieczki-st7753082?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ochota-mazala-po-scianie-bloku-sprayem-kiedy-zobaczyla-straznikow-rzucila-sie-do-ucieczki-st7753082?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T18:40:07+00:00

<img alt="Mazała sprayem po ścianie bloku. Kiedy zobaczyła strażników, rzuciła się do ucieczki" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9l3op4-straznicy-miejscy-zatrzymali-24-latke-ktora-malowala-graffiti-na-scianie-bloku-7753091/alternates/LANDSCAPE_1280" />
    Strażnicy miejscy z Ochoty zatrzymali 24-latkę, która w środku nocy mazała sprayem po ścianie bloku. Kobieta została przekazana policjantom.

## Morawiecki w Brukseli. Spotkał się z premier Włoch Giorgią Meloni
 - [https://tvn24.pl/polska/mateusz-morawiecki-w-brukseli-byly-premier-spotkal-sie-z-premier-wloch-giorgia-meloni-7753096?source=rss](https://tvn24.pl/polska/mateusz-morawiecki-w-brukseli-byly-premier-spotkal-sie-z-premier-wloch-giorgia-meloni-7753096?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T18:32:34+00:00

<img alt="Morawiecki w Brukseli. Spotkał się z premier Włoch Giorgią Meloni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qyrr9t-mateusz-morawiecki-w-brukseli-spotkal-sie-z-giorgia-meloni-7753136/alternates/LANDSCAPE_1280" />
    Były premier Mateusz Morawiecki udał się w czwartek do Brukseli, gdzie spotkał się z szefową rządu Włoch Giorgią Meloni. Poseł PiS Piotr Mueller przekazał, że celem wizyty Morawieckiego było "zabieganie o polskie interesy". Tego samego dnia w belgijskiej stolicy odbył się nadzwyczajny szczyt Unii Europejskiej, na którym Polskę reprezentował premier Donald Tusk.

## Pogoda na jutro - piątek 02.02. Noc z mrozem, w dzień będzie padać i wiać
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-piatek-0202-noc-z-mrozem-w-dzien-bedzie-padac-i-wiac-st7753122?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-piatek-0202-noc-z-mrozem-w-dzien-bedzie-padac-i-wiac-st7753122?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T18:21:11+00:00

<img alt="Pogoda na jutro - piątek 02.02. Noc z mrozem, w dzień będzie padać i wiać" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8urd3h-snieg-5504338/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. W piątek 02.02 pojawią się opady deszczu, deszczu ze śniegiem i śniegu. Termometry wskażą od 2 do 7 stopni Celsjusza, ale porywisty wiatr obniży temperaturę odczuwalną.

## Od 15. lutego będą dostępne deklaracje PIT. Pierwszy raz dla przedsiębiorców
 - [https://tvn24.pl/biznes/z-kraju/twoj-e-pit-kas-od-2-lutego-zacznie-przesylac-dane-do-rozliczenia-pit-przez-internet-st7752923?source=rss](https://tvn24.pl/biznes/z-kraju/twoj-e-pit-kas-od-2-lutego-zacznie-przesylac-dane-do-rozliczenia-pit-przez-internet-st7752923?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T17:58:59+00:00

<img alt="Od 15. lutego będą dostępne deklaracje PIT. Pierwszy raz dla przedsiębiorców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wdn5c5-firma-podatek-podatki-pit-cit-vat-przedsiebiorcy-7742957/alternates/LANDSCAPE_1280" />
    Od 2 do 14 lutego Krajowa Administracja Skarbowa będzie zasilać system Twój e-PIT danymi z deklaracji podatkowych od pracodawców. Umożliwi to wygenerowanie wstępnie wypełnionych deklaracji PIT, które będą dostępne od 15 lutego – podało Ministerstwo Finansów w informacji przesłanej w czwartek Polskiej Agencji Prasowej.

## Niemal rok po trzęsieniu zawalił się dom. Są zabici i ranni
 - [https://tvn24.pl/tvnmeteo/swiat/turcja-niemal-rok-po-trzesieniu-ziemi-zawalil-sie-dom-zabici-i-ranni-st7752967?source=rss](https://tvn24.pl/tvnmeteo/swiat/turcja-niemal-rok-po-trzesieniu-ziemi-zawalil-sie-dom-zabici-i-ranni-st7752967?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T17:35:21+00:00

<img alt="Niemal rok po trzęsieniu zawalił się dom. Są zabici i ranni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-wzxmlg-zniszczone-budynki-w-tureckiej-prowincji-hatay-7752980/alternates/LANDSCAPE_1280" />
    Dwie osoby zginęły, a osiem kolejnych zostało rannych po tym, jak w prowincji Sanliurfa na południu Turcji zawalił się dom - poinformował w czwartek portal Duvar. Do jego uszkodzenia doszło podczas potężnego trzęsienia ziemi w lutym ubiegłego roku.

## Jest nowy kandydat Skarbu Państwa do rady nadzorczej PKO BP
 - [https://tvn24.pl/biznes/z-kraju/pko-bp-andrzej-oslizlo-kandydatem-skarbu-panstwa-do-rady-nadzorczej-pko-bp-st7752904?source=rss](https://tvn24.pl/biznes/z-kraju/pko-bp-andrzej-oslizlo-kandydatem-skarbu-panstwa-do-rady-nadzorczej-pko-bp-st7752904?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T17:20:55+00:00

<img alt="Jest nowy kandydat Skarbu Państwa do rady nadzorczej PKO BP" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-ihy5v3-pko-bp-7752933/alternates/LANDSCAPE_1280" />
    Andrzej Oślizło jest kolejnym kandydatem Skarbu Państwa do rady nadzorczej PKO Banku Polskiego. Informacje w tej sprawie przekazał zarząd największego banku w Polsce w raporcie giełdowym. W piątek odbędzie się nadzwyczajne walne zgromadzenie PKO BP. Jeden z punktów porządku obrad przewiduje zmiany w składzie rady nadzorczej spółki.

## Zabił żonę i teściową, a potem podpalił dom. Jest prawomocny wyrok
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wyszkow-zabil-zone-i-tesciowa-a-potem-podpalil-dom-jest-prawomocny-wyrok-st7752925?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wyszkow-zabil-zone-i-tesciowa-a-potem-podpalil-dom-jest-prawomocny-wyrok-st7752925?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T16:46:14+00:00

<img alt="Zabił żonę i teściową, a potem podpalił dom. Jest prawomocny wyrok " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-2ew0tx-pozar-domu-jednorodzinnego-w-wyszkowie-5704984/alternates/LANDSCAPE_1280" />
    W Sądzie Apelacyjnym w Białymstoku zapadł prawomocny wyrok w sprawie mężczyzny, który w maju 2022 roku w Wyszkowie zamordował swoją żonę i teściową, a następnie podpalił dom, w którym mieszkała rodzina. 59-latek spędzi resztę życia w więzieniu. Zdaniem sądu "skazany nie rokuje nawet najmniejszych nadziei na resocjalizację".

## Lasy Państwowe zmieniają zdanie w sprawie osieroconego rodzeństwa. "Możemy na chwilę spać spokojnie"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/lasy-panstwowe-zmieniaja-zdanie-w-sprawie-osieroconego-rodzenstwa-mozemy-na-chwile-spac-spokojnie-st7752789?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/lasy-panstwowe-zmieniaja-zdanie-w-sprawie-osieroconego-rodzenstwa-mozemy-na-chwile-spac-spokojnie-st7752789?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T16:41:26+00:00

<img alt="Lasy Państwowe zmieniają zdanie w sprawie osieroconego rodzeństwa. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-cpqlo4-czuprynska-7752970/alternates/LANDSCAPE_1280" />
    Historia trojga osieroconego rodzeństwa bardzo poruszyła widzów, czego dowodem są liczne deklaracje pomocy. Natalię, Michała i Olę wychowywał tata, który z zawodu był leśniczym. Mężczyzna zmarł kilka miesięcy temu, a dzieci zostały same i mały opuścić leśniczówkę, w której mieszkały. Po emisji materiału w TVN24 Lasy Państwowe zabrały głos i mają propozycję dla rodzeństwa.

## Od dziś psy tej rasy miały być usypiane. Tysiące zwierząt uniknie jednak śmierci
 - [https://tvn24.pl/swiat/wielka-brytania-zakaz-posiadania-psow-american-bully-xl-wszedl-w-zycie-7752966?source=rss](https://tvn24.pl/swiat/wielka-brytania-zakaz-posiadania-psow-american-bully-xl-wszedl-w-zycie-7752966?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T16:39:50+00:00

<img alt="Od dziś psy tej rasy miały być usypiane. Tysiące zwierząt uniknie jednak śmierci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ijxq8h-psy-rasy-american-bully-xl-7338448/alternates/LANDSCAPE_1280" />
    W Anglii i Walii wszedł w życie zakaz posiadania psów American Bully XL. Dziesiątki tysięcy psów tej rasy unikną jednak uśpienia, bo właściciele wystąpili o zwolnienie z zakazu albo go zignorowali.

## Z filmików na TikToku znika muzyka światowych gwiazd
 - [https://tvn24.pl/swiat/tiktok-znika-muzyka-znanych-artystow-wytworni-universal-7752759?source=rss](https://tvn24.pl/swiat/tiktok-znika-muzyka-znanych-artystow-wytworni-universal-7752759?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T16:30:28+00:00

<img alt="Z filmików na TikToku znika muzyka światowych gwiazd" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rkvu0p-tiktok-5453552/alternates/LANDSCAPE_1280" />
    Z TikToka znikają utwory światowych artystów - informuje "The New York Times" i inne media". To skutek wygaśnięcia umowy między wytwórnią Universal Music Group, a popularną platformą społecznościową.

## Jeden niż się odsuwa, ale kolejny w natarciu. Przed nami trudne dni
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-niz-nadine-w-natarciu-czeka-nas-deszcz-snieg-i-silny-wiatr-st7752834?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-niz-nadine-w-natarciu-czeka-nas-deszcz-snieg-i-silny-wiatr-st7752834?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T16:18:39+00:00

<img alt="Jeden niż się odsuwa, ale kolejny w natarciu. Przed nami trudne dni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nejpmd-met-7752876/alternates/LANDSCAPE_1280" />
    Końcówka tego i początek następnego tygodnia zapowiadają się mokro i wietrznie. Temperatura będzie osiągać wysokie wartości, dlatego spodziewamy się przede wszystkim deszczu, ale będą  miejsca, gdzie pojawi się i śnieg. Wiatr w porywach nad morzem ma osiągać nawet 100 kilometrów na godzinę.

## Ustawa budżetowa w Trybunale Konstytucyjnym w trybie następczym. Czym on jest i co oznacza
 - [https://konkret24.tvn24.pl/polska/ustawa-budzetowa-2024-w-trybunale-konstytucyjnym-co-oznacza-tryb-nastepczy-st7751817?source=rss](https://konkret24.tvn24.pl/polska/ustawa-budzetowa-2024-w-trybunale-konstytucyjnym-co-oznacza-tryb-nastepczy-st7751817?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T15:31:10+00:00

<img alt="Ustawa budżetowa w Trybunale Konstytucyjnym w trybie następczym. Czym on jest i co oznacza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j12lm0-ustawa-budzetowa-w-trybunale-konstytucyjnym-w-trybie-nastepczym-czym-on-jest-i-co-oznacza-7752612/alternates/LANDSCAPE_1280" />
    Prezydent Andrzej Duda podpisał ustawę budżetową, ale zapowiedział skierowanie jej do Trybunału Konstytucyjnego w trybie kontroli następczej. Według premiera jest to "bez znaczenia". Czy rzeczywiście? Czym jest tryb następczy i jakie są możliwe scenariusze, wyjaśniają eksperci.

## Złamali gangsterską zmowę milczenia. Ostateczny wyrok za brutalne zabójstwo "Maksa" i "Postka"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ostateczny-wyrok-za-brutalne-zabojstwo-maksa-i-postka-st7752783?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ostateczny-wyrok-za-brutalne-zabojstwo-maksa-i-postka-st7752783?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T15:26:23+00:00

<img alt="Złamali gangsterską zmowę milczenia. Ostateczny wyrok za brutalne zabójstwo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6e65yb-przywodca-grupy-obcinaczy-palcow-3617585/alternates/LANDSCAPE_1280" />
    Sąd Najwyższy orzekł w sprawie dożywotniego wyroku dla Wojciecha S. ps. Wojtas vel Kierownik z tak zwanej grupy mokotowskiej. Proces dotyczył zabójstwa w 2002 roku Tomasza M. ps. Maks oraz Jacka P. ps. Postek. Sąd oddalił kasacje obrony w tej sprawie.

## To rondo jest "z poprzedniej epoki". Będą zmiany, piesi i rowerzyści odetchną z ulgą
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-rondo-zeslancow-syberyjskich-zostanie-przebudowane-piesi-i-rowerzysci-odetchna-z-ulga-st7752588?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-rondo-zeslancow-syberyjskich-zostanie-przebudowane-piesi-i-rowerzysci-odetchna-z-ulga-st7752588?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T15:06:56+00:00

<img alt="To rondo jest " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6u81wr-beda-zmiany-na-rondzie-zeslancow-syberyjskich-7752722/alternates/LANDSCAPE_1280" />
    Rondo Zesłańców Syberyjskich jest jednym z najbardziej nieprzyjaznych pieszym i rowerzystom punktów w całej Warszawie. Głównymi mankamentami są podziemne przejścia, liczne schody, brak połączenia z innymi drogami rowerowymi. Zarząd Dróg Miejskich planuje zmiany. Właśnie ogłosił przetarg na projekt przebudowy skrzyżowania.

## Płonące opony, kamienie i okrzyki. Rolnicy protestują w Brukseli
 - [https://tvn24.pl/biznes/najnowsze/rolnicy-protestuja-w-brukseli-chca-zniesienia-restrykcyjnych-wymagan-st7752698?source=rss](https://tvn24.pl/biznes/najnowsze/rolnicy-protestuja-w-brukseli-chca-zniesienia-restrykcyjnych-wymagan-st7752698?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T14:51:24+00:00

<img alt="Płonące opony, kamienie i okrzyki. Rolnicy protestują w Brukseli" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-gmnbev-protest-rolnikow-w-brukseli-7752709/alternates/LANDSCAPE_1280" />
    W czasie gdy unijni przywódcy negocjowali rewizję wieloletnich ram unijnego budżetu, pod Parlamentem Europejskim w Brukseli trwał duży protest rolników. Do stolicy Belgii w czwartek wjechało co najmniej tysiąc ciągników, a pod PE zgromadziło się parę tysięcy osób. Rolnicy m.in. z Belgii i Włoch domagali się wyrzucenia do kosza unijnych regulacji nakładających restrykcyjne wymagania na ich gospodarstwa.

## Tak silnie w Norwegii jeszcze nigdy nie wiało
 - [https://tvn24.pl/tvnmeteo/swiat/norwegia-inguun-uderzyl-z-rekordowo-silnym-wiatrem-najsilniejsza-burza-od-30-lat-st7752647?source=rss](https://tvn24.pl/tvnmeteo/swiat/norwegia-inguun-uderzyl-z-rekordowo-silnym-wiatrem-najsilniejsza-burza-od-30-lat-st7752647?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T14:46:42+00:00

<img alt="Tak silnie w Norwegii jeszcze nigdy nie wiało" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-khvjt3-silny-wiatr-w-norwegii-7752778/alternates/LANDSCAPE_1280" />
    W Norwegię uderzyła najsilniejsza burza od ponad 30 lat. Nocą ze środy na czwartek wiało z  prędkością około 200 kilometrów na godzinę. Ingunn, bo tak został nazwany żywioł, spowodował przerwy w dostawie prądu w dziesiątkach tysięcy domów. Są utrudnienia w ruchu drogowym i kolejowym.

## Zwolnienia w Deutsche Bank. Pracę straci trzy i pół tysiąca pracowników
 - [https://tvn24.pl/biznes/ze-swiata/zwolnienia-w-deutsche-banku-prace-straci-4-procent-zatrudnionych-st7752675?source=rss](https://tvn24.pl/biznes/ze-swiata/zwolnienia-w-deutsche-banku-prace-straci-4-procent-zatrudnionych-st7752675?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T14:45:02+00:00

<img alt="Zwolnienia w Deutsche Bank. Pracę straci trzy i pół tysiąca pracowników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-39wq92-deutsche-bank-shutterstock1863845104-5631332/alternates/LANDSCAPE_1280" />
    Deutsche Bank zobowiązał się ograniczyć swoje koszty do poziomu 2,5 miliarda euro do 2025 roku. W czwartek firma zakomunikowała, że udało jej się podjąć pewne kroki w tym celu. Wciąż brakuje jednak oszczędności na poziomie 1,6 miliarda euro. Rozwiązaniem mają być zwolnienia 3,5 tysiąca pracowników. To około 4 procent globalnego zatrudnienia banku.

## Czy "feminizm przyniósł więcej szkody niż pożytku"? Zapytano mężczyzn z pokolenia Z
 - [https://tvn24.pl/swiat/pokolenie-z-spytano-czy-feminizm-przyniosl-wiecej-szkody-niz-pozytku-7752318?source=rss](https://tvn24.pl/swiat/pokolenie-z-spytano-czy-feminizm-przyniosl-wiecej-szkody-niz-pozytku-7752318?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T14:25:17+00:00

<img alt="Czy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k7h8l1-nastolatkowie-mlodziez-7317738/alternates/LANDSCAPE_1280" />
    Jak wynika z badań przeprowadzonych wśród młodych Brytyjczyków, 16 proc. mężczyzn z pokolenia Z uważa, że feminizm przyniósł więcej szkody niż pożytku, podczas gdy 35 proc. jest przeciwnego zdania. Zapytano ich również, czy współcześnie ​​trudniej być mężczyzną czy kobietą, a także o ich opinie na temat "toksycznej męskości".

## Tony odpadów wciąż zalegają w nieczynnych wyrobiskach, kilkaset metrów pod ziemią
 - [https://tvn24.pl/katowice/bierun-tony-odpadow-w-nieczynnych-wyrobiskach-po-kopalni-mimo-zalecen-nie-zostaly-usuniete-7752717?source=rss](https://tvn24.pl/katowice/bierun-tony-odpadow-w-nieczynnych-wyrobiskach-po-kopalni-mimo-zalecen-nie-zostaly-usuniete-7752717?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T14:20:46+00:00

<img alt="Tony odpadów wciąż zalegają w nieczynnych wyrobiskach, kilkaset metrów pod ziemią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h90c7i-odpady-w-bieruniu-7752714/alternates/LANDSCAPE_1280" />
    Ponad 80 dni minęło od ujawnienia przez reportera TVN24 Jerzego Korczyńskiego tematu śmieci magazynowanych pod ziemią w nieczynnych wyrobiskach kopalni Piast w Bieruniu. Okręgowy Urząd Górniczy po przeprowadzeniu kontroli nakazał bezzwłoczne usunięcie setek ton śmieci. Okazuje się, że od tego czasu pod ziemią zmieniło się niewiele.

## Pracowali w głębokim wykopie, przysypała ich ziemia. Nie żyje jedna osoba
 - [https://tvn24.pl/lubuskie/kostrzyn-nad-odra-pracowali-w-glebokim-wykopie-przysypala-ich-ziemia-nie-zyje-jedna-osoba-7752624?source=rss](https://tvn24.pl/lubuskie/kostrzyn-nad-odra-pracowali-w-glebokim-wykopie-przysypala-ich-ziemia-nie-zyje-jedna-osoba-7752624?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T14:09:03+00:00

<img alt="Pracowali w głębokim wykopie, przysypała ich ziemia. Nie żyje jedna osoba" src="https://tvn24.pl/najnowsze/cdn-zdjecie-31xqzg-ziemia-osunela-sie-na-pracownikow-7752685/alternates/LANDSCAPE_1280" />
    Tragiczny wypadek w Kostrzynie nad Odrą (woj. lubuskie). W głębokim wykopie doszło do osunięcia się ziemi, która przysypała dwóch pracowników. Jednego z mężczyzn nie udało się uratować, drugi trafił do szpitala.

## Zniszczył satanistyczny ołtarz, usłyszał zarzut przestępstwa z nienawiści
 - [https://tvn24.pl/ciekawostki/usa-polityk-zniszczyl-satanistyczny-oltarz-w-iowa-michael-cassidy-uslyszal-zarzut-przestepstwa-z-nienawisci-7752623?source=rss](https://tvn24.pl/ciekawostki/usa-polityk-zniszczyl-satanistyczny-oltarz-w-iowa-michael-cassidy-uslyszal-zarzut-przestepstwa-z-nienawisci-7752623?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T14:05:55+00:00

<img alt="Zniszczył satanistyczny ołtarz, usłyszał zarzut przestępstwa z nienawiści " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nxs2a2-zniszczono-oltarz-swiatyni-satanicznej-michael-cassidy-oskarzony-o-przestepstwo-z-nienawisci-7752621/alternates/LANDSCAPE_1280" />
    Michael Cassidy, amerykański polityk, który zniszczył satanistyczny ołtarz, został oskarżony o popełnienie przestępstwa z nienawiści. "Prawo stosuje się jednakowo do wszystkich", uzasadniła swoją decyzję lokalna prokuratura. Świątynia Sataniczna jest uznawana przez rząd USA za religię.

## Oblał żrącą substancją 31-latkę i jej córki. Trwa obława
 - [https://tvn24.pl/swiat/londyn-oblal-substancja-zraca-31-latke-i-jej-corki-trwa-oblawa-7752502?source=rss](https://tvn24.pl/swiat/londyn-oblal-substancja-zraca-31-latke-i-jej-corki-trwa-oblawa-7752502?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T14:05:23+00:00

<img alt="Oblał żrącą substancją 31-latkę i jej córki. Trwa obława" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lr3iut-wielka-brytania-policja-radiowoz-shutterstock2154138653-6155688/alternates/LANDSCAPE_1280" />
    Trwa obława na mężczyznę, który w Londynie oblał żrącą substancją 31-letnią kobietę i jej dwie nieletnie córki. Matka i młodsza córka trafiły do szpitala z "poważnymi obrażeniami", oprócz nich ranne zostały cztery osoby, które rzuciły się na pomoc rodzinie, a także pięciu funkcjonariuszy - informuje policja.

## Gdy zapukali do drzwi, ukryła się w szafie między ubraniami
 - [https://tvn24.pl/lublin/lukow-szukala-jej-policja-ukryla-sie-w-szafie-miedzy-ubraniami-7752553?source=rss](https://tvn24.pl/lublin/lukow-szukala-jej-policja-ukryla-sie-w-szafie-miedzy-ubraniami-7752553?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T13:50:35+00:00

<img alt="Gdy zapukali do drzwi, ukryła się w szafie między ubraniami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dgjdxs-53-latka-przed-policjantami-schowala-sie-w-szafie-7752651/alternates/LANDSCAPE_1280" />
    53-latka w zakładzie karnym spędzi najbliższe dni. Kobieta była poszukiwana przez policję, bo nie zapłaciła grzywny za liczne wykroczenia. Ukrywała się od kilku dni, a przed dzielnicowymi schowała się w szafie między ubraniami.

## Policja sprawdza, czy nauczyciel naruszył nietykalność dwóch 12-letnich uczennic
 - [https://tvn24.pl/lublin/lublin-policja-sprawdza-czy-nauczyciel-naruszyl-nietykalnosc-cielesna-dwoch-12-latek-7752596?source=rss](https://tvn24.pl/lublin/lublin-policja-sprawdza-czy-nauczyciel-naruszyl-nietykalnosc-cielesna-dwoch-12-latek-7752596?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T13:47:02+00:00

<img alt="Policja sprawdza, czy nauczyciel naruszył nietykalność dwóch 12-letnich uczennic" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3vxklm-sala-lekcyjna-3738350/alternates/LANDSCAPE_1280" />
    Lubelska policja sprawdza zawiadomienia o przypadkach naruszenia nietykalności cielesnej dwóch 12-letnich uczennic szkoły w jednej z lubelskich gmin. Zdaniem rodziców, którzy zawiadomili o rzekomych nieprawidłowościach, czynów tych miał dopuścić się jeden z nauczycieli. Według informacji policji, odszedł on już z tej szkoły.

## "Lewactwo chce usunąć pomnik żołnierza spod Monte Cassino"? Nieprawda
 - [https://konkret24.tvn24.pl/polska/lewactwo-chce-usunac-pomnik-zolnierza-spod-monte-cassino-nieprawda-st7750962?source=rss](https://konkret24.tvn24.pl/polska/lewactwo-chce-usunac-pomnik-zolnierza-spod-monte-cassino-nieprawda-st7750962?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T13:09:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cpn9qh-lewactwo-chce-usunac-pomnik-zolnierza-spod-monte-casino-wyjasniamy-7751286/alternates/LANDSCAPE_1280" />
    Grób weterana walk spod Monte Cassino rzekomo został przeznaczony we Wrocławiu do likwidacji. Zdjęcie o wytypowaniu tej mogiły do usunięcia wzburzyło wielu internautów, oburzyła się też młodzieżówka partii Konfederacja Korony Polskiej. Tylko że ta sprawa od dawna jest nieaktualna, miała pozytywny efekt, a grób obecnie wygląda zupełnie inaczej.

## Przekroczone normy jakości powietrza. Sprawdź, gdzie jest smog
 - [https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-czwartek-102-sprawdz-jakosc-powietrza-w-swoim-miescie-st7752432?source=rss](https://tvn24.pl/tvnmeteo/smog/smog-w-polsce-czwartek-102-sprawdz-jakosc-powietrza-w-swoim-miescie-st7752432?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T12:55:32+00:00

<img alt="Przekroczone normy jakości powietrza. Sprawdź, gdzie jest smog" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-aawu79-smog-w-polsce-5633608/alternates/LANDSCAPE_1280" />
    Smog w Polsce. W czwartek po południu odnotowana została średnia jakość powietrza w części kraju. Sprawdź, jakim powietrzem oddychasz.

## Śledztwo w sprawie naruszenia przestrzeni powietrznej Polski po zdarzeniu z rosyjską rakietą
 - [https://tvn24.pl/lublin/rosyjska-rakieta-nad-polska-sledztwo-w-sprawie-naruszenia-przestrzeni-powietrznej-7752422?source=rss](https://tvn24.pl/lublin/rosyjska-rakieta-nad-polska-sledztwo-w-sprawie-naruszenia-przestrzeni-powietrznej-7752422?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T12:49:48+00:00

<img alt="Śledztwo w sprawie naruszenia przestrzeni powietrznej Polski po zdarzeniu z rosyjską rakietą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a0a09h-poszukiwania-ewentualnych-elementow-obiektu-ktory-naruszyl-polska-przestrzen-powietrzna-w-okolicach-wozuczyna-7682632/alternates/LANDSCAPE_1280" />
    W związku z niepokojącym zdarzeniem, do którego doszło 29 grudnia 2023 roku, informuję, że Dział Wojskowy Prokuratury Rejonowej w Lublinie wszczął śledztwo w sprawie naruszenia przestrzeni powietrznej RP przez niezidentyfikowany obiekt latający - poinformował rzecznik Prokuratury Okręgowej w Warszawie prok. Szymon Banna.

## Andrzej Jaroch (PiS) odwołany, Jerzy Pokój (KO) nowym przewodniczącym sejmiku dolnośląskiego
 - [https://tvn24.pl/wroclaw/wroclaw-andrzej-jaroch-pis-odwolany-jerzy-pokoj-ko-nowym-przewodniczacym-sejmiku-dolnoslaskiego-7752423?source=rss](https://tvn24.pl/wroclaw/wroclaw-andrzej-jaroch-pis-odwolany-jerzy-pokoj-ko-nowym-przewodniczacym-sejmiku-dolnoslaskiego-7752423?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T12:32:20+00:00

<img alt="Andrzej Jaroch (PiS) odwołany, Jerzy Pokój (KO) nowym przewodniczącym sejmiku dolnośląskiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-viabbh-nowy-przewodniczacy-sejmiku-radny-ko-jerzy-pokoj-podczas-sesji-sejmiku-wojewodztwa-dolnoslaskiego-7752809/alternates/LANDSCAPE_1280" />
    Andrzej Jaroch (PiS) został w czwartek odwołany z funkcji przewodniczącego Sejmiku Województwa Dolnośląskiego. Wniosek o odwołanie Jaroch złożyli radni opozycji z KO, Nowej Pl oraz Koalicji Samorządowej. Zastąpił go Jerzy Pokój (KO).

## Kierowca rozbił się na drzewie, nie przeżył
 - [https://tvn24.pl/tvnwarszawa/ulice/kury-mazowsze-kierowca-uderzyl-w-drzewo-nie-przezyl-st7751755?source=rss](https://tvn24.pl/tvnwarszawa/ulice/kury-mazowsze-kierowca-uderzyl-w-drzewo-nie-przezyl-st7751755?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T06:23:24+00:00

<img alt="Kierowca rozbił się na drzewie, nie przeżył" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-a9llfw-wypadek-w-miejscowosci-kury-7751741/alternates/LANDSCAPE_1280" />
    Tragiczny wypadek w miejscowości Kury pod Wołominem. Kierowca auta osobowego uderzył w przydrożne drzewo. Mężczyzna nie przeżył.

## Zabił swojego ojca, później opublikował w internecie film
 - [https://tvn24.pl/swiat/pensylwania-bucks-ujeto-mezczyzne-ktory-brutalnie-zabil-swojego-ojca-w-filmie-na-youtube-nazwal-go-zdrajca-7751715?source=rss](https://tvn24.pl/swiat/pensylwania-bucks-ujeto-mezczyzne-ktory-brutalnie-zabil-swojego-ojca-w-filmie-na-youtube-nazwal-go-zdrajca-7751715?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T05:36:51+00:00

<img alt="Zabił swojego ojca, później opublikował w internecie film" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x9q1pi-policja-usa-7218140/alternates/LANDSCAPE_1280" />
    32-letni mężczyzna z hrabstwa Bucks w Pensylwanii miał obciąć głowę swojemu ojcu. Na portalu YouTube opublikował film, w którym oskarżał go o "zdradę" za to, że był pracownikiem administracji federalnej. Sprawca został zatrzymany przez policję i usłyszał zarzuty.

## W Płońsku urzędnicy będą pracować w nocy i w wolne dni. "Chodzi o to, aby szybko reagować"
 - [https://tvn24.pl/tvnwarszawa/okolice/plonsk-bedzie-nocny-burmistrz-urzednicy-beda-pracowac-w-nocy-i-w-wolne-dni-st7749282?source=rss](https://tvn24.pl/tvnwarszawa/okolice/plonsk-bedzie-nocny-burmistrz-urzednicy-beda-pracowac-w-nocy-i-w-wolne-dni-st7749282?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T05:36:31+00:00

<img alt="W Płońsku urzędnicy będą pracować w nocy i w wolne dni. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-l6d2wf-wydzial-utrzymania-miasta-w-plonsku-bedzie-pracowal-po-godzinach-pracy-urzedu-7749286/alternates/LANDSCAPE_1280" />
    Od 1 lutego w magistracie w Płońsku funkcjonuje nowa komórka - Wydział Utrzymania Miasta. Jej zadaniem będzie podejmowanie działań związanych z porządkiem, czystością i awariami - również w godzinach popołudniowych, nocą i w dni wolne od pracy.

## Alerty IMGW na dużym obszarze Polski
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-slisko-na-drogach-w-wielu-miejscach-st7751727?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-slisko-na-drogach-w-wielu-miejscach-st7751727?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T05:26:21+00:00

<img alt="Alerty IMGW na dużym obszarze Polski " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-mrpz5n-oblodzone-drogi-i-chodniki-5595086/alternates/LANDSCAPE_1280" />
    W znacznej części kraju w ciągu najbliższej nocy i w piątek rano będzie ślisko. Instytut Meteorologii i Gospodarki Wodnej wydał ostrzeżenia. Jeszcze w czwartek wieczorem miejscami na północy może niebezpiecznie silnie wiać, przed czym także ostrzega IMGW.

## Alerty IMGW. Pomarańczowe i żółte alarmy w części kraju
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-oblodzenie-alerty-pierwszego-i-drugiego-stopnia-w-tych-miejscach-bedzie-niebezpiecznie-st7751727?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-oblodzenie-alerty-pierwszego-i-drugiego-stopnia-w-tych-miejscach-bedzie-niebezpiecznie-st7751727?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T05:26:21+00:00

<img alt="Alerty IMGW. Pomarańczowe i żółte alarmy w części kraju" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-p8j1qf-silny-wiatr-6559607/alternates/LANDSCAPE_1280" />
    Synoptycy IMGW wydali alarmy pierwszego i drugiego stopnia. Ostrzegają przed silnym wiatrem, który w porywach może osiągać prędkość do 90 kilometrów na godzinę. W części kraju prognozuje się też oblodzenie. Sprawdź, gdzie aura będzie groźna.

## Sześć rzeczy, które warto wiedzieć 1 lutego
 - [https://tvn24.pl/polska/szesc-rzeczy-ktore-warto-wiedziec-1-lutego-2024-roku-7751717?source=rss](https://tvn24.pl/polska/szesc-rzeczy-ktore-warto-wiedziec-1-lutego-2024-roku-7751717?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T04:29:22+00:00

<img alt="Sześć rzeczy, które warto wiedzieć 1 lutego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6qky34-andrzej-duda-7748422/alternates/LANDSCAPE_1280" />
    Prezydent podpisuje i odsyła ustawę budżetową do Trybunału Konstytucyjnego. Ukraina otrzyma od USA broń, której nie ma żadna armia świata. Krzysztof Żabiński nie żyje. Oto sześć rzeczy, które warto wiedzieć 1 lutego.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-1-lutego-7751720?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-1-lutego-7751720?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T04:25:43+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4jscqi-rosyjska-bomba-spadla-na-szpital-w-obwodzie-charkowskim-7751719/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 708 dni. Na szpital w obwodzie charkowskim spadła rosyjska bomba. Doszło do ewakuacji pacjentów oraz personelu. Prokurator generalny Ukrainy Andrij Kostin przekazał, że Kijów prowadzi dochodzenia w sprawie 120 tysięcy rosyjskich zbrodni wojennych. Oto najważniejsze wydarzenia ostatnich godzin wojny w Ukrainie.

## Decyzja prezydenta w sprawie budżetu. Tomczyk: gdzie pan był w grudniu 2016 roku?
 - [https://tvn24.pl/polska/ustawa-budzetowa-2024-prezydent-andrzej-duda-podjal-decyzje-politycy-komentuja-7751716?source=rss](https://tvn24.pl/polska/ustawa-budzetowa-2024-prezydent-andrzej-duda-podjal-decyzje-politycy-komentuja-7751716?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T04:16:25+00:00

<img alt="Decyzja prezydenta w sprawie budżetu. Tomczyk: gdzie pan był w grudniu 2016 roku? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-phbpkb-budzet-na-2017-rok-przyjmowany-w-sali-kolumnowej-7751474/alternates/LANDSCAPE_1280" />
    W grudniu 2016 posłowie PiS w Sali Kolumnowej bezprawnie uniemożliwili udział w głosowaniu nad budżetem stu kilkudziesięciu posłom opozycji. Prezydentowi budżet bardzo się wtedy podobał - napisał w mediach społecznościowych  Jan Grabiec szef Kancelarii Premiera Rady Ministrów. Polityk skomentował podpisanie przez Andrzeja Dudę ustawy budżetowej na 2024 rok, ale jednocześnie skierowanie jej w trybie kontroli następczej do Trybunału Konstytucyjnego. "Jeszcze 15 miesięcy i skończy się ta farsa" - stwierdził poseł KO Sławomir Nitras, minister sportu i turystyki.

## Pogoda na dziś - czwartek 01.02. Deszcz, śnieg i silny wiatr
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-czwartek-0102-deszcz-snieg-i-silny-wiatr-st7751677?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-czwartek-0102-deszcz-snieg-i-silny-wiatr-st7751677?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2024-02-01T01:00:00+00:00

<img alt="Pogoda na dziś - czwartek 01.02. Deszcz, śnieg i silny wiatr" src="https://tvn24.pl/najnowsze/cdn-zdjecie-89u514-deszcz-ze-sniegiem-5059788/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. W czwartek 01.02 w całym kraju możliwe są opady, a do niektórych regionów wróci śnieg. Za sprawą silnego wiatru zrobi się zimno.

