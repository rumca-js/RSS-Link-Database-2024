# Source:Energetyka, URL:https://energia.rp.pl/rss/4351-energetyka, language:pl-PL

## Prezes Orlenu Daniel Obajtek odwołany ze stanowiska. "To jest sprawa honorowa"
 - [https://energia.rp.pl/energetyka-zawodowa/art39772561-prezes-orlenu-daniel-obajtek-odwolany-ze-stanowiska-to-jest-sprawa-honorowa](https://energia.rp.pl/energetyka-zawodowa/art39772561-prezes-orlenu-daniel-obajtek-odwolany-ze-stanowiska-to-jest-sprawa-honorowa)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-02-01T09:55:00+00:00

Rada nadzorcza Orlenu odwołała ze stanowiska prezesa koncernu Daniela Obajtka. Przestanie pełnić funkcję 5 lutego - dzień przed nadzwyczajnym walnym zgromadzeniem koncernu. Akcje koncernu na warszawskiej giełdzie zyskały po publikacji komunikatu o prawie 4 procent.

## Rusza kolejna runda pomocy dla branży energochłonnej. Do wzięcia miliard złotych
 - [https://energia.rp.pl/transformacja-energetyczna/art39772701-rusza-kolejna-runda-pomocy-dla-branzy-energochlonnej-do-wziecia-miliard-zlotych](https://energia.rp.pl/transformacja-energetyczna/art39772701-rusza-kolejna-runda-pomocy-dla-branzy-energochlonnej-do-wziecia-miliard-zlotych)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-02-01T09:51:48+00:00

Wraz z początkiem lutego firmy z branż, które szczególnie odczuły wzrost cen energii, mogą wnioskować o pomoc z rządowego programu wsparcia.

## Daniel Obajtek sam dziś odejdzie? Prezes Orlenu o swojej przyszłości
 - [https://energia.rp.pl/energetyka-zawodowa/art39771911-daniel-obajtek-sam-dzis-odejdzie-prezes-orlenu-o-swojej-przyszlosci](https://energia.rp.pl/energetyka-zawodowa/art39771911-daniel-obajtek-sam-dzis-odejdzie-prezes-orlenu-o-swojej-przyszlosci)
 - RSS feed: https://energia.rp.pl/rss/4351-energetyka
 - date published: 2024-02-01T07:08:00+00:00

Na wszystkie możliwości trzeba być przygotowanym - powiedział prezes Orlenu Daniel Obajtek w Radiu Zet na pytanie czy nie obawia się zatrzymania przez ABW. Prezes Orlenu powiedział, że dziś na posiedzeniu rady nadzorczej ma zapaść decyzja o jego przyszłości. - To jest sprawa honorowa - dodał.

