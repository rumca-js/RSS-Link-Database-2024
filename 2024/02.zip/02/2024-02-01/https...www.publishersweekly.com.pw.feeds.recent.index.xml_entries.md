# Source:Publisher weekly, URL:https://www.publishersweekly.com/pw/feeds/recent/index.xml, language:en-US

## 5 New Books to Read for Black History Month
 - [https://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/94219-5-new-books-to-read-for-black-history-month.html](https://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/94219-5-new-books-to-read-for-black-history-month.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## ABA Archives to Be Housed at Columbia University
 - [https://www.publishersweekly.com/pw/by-topic/industry-news/bookselling/article/94228-aba-archives-to-be-housed-at-columbia-university.html](https://www.publishersweekly.com/pw/by-topic/industry-news/bookselling/article/94228-aba-archives-to-be-housed-at-columbia-university.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## Black History Month 2024: Q&As with Picture Book Creators Honoring Influential Black Figures
 - [https://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94231-black-history-month-2024-q-as-with-picture-book-creators-honoring-influential-black-figures.html](https://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94231-black-history-month-2024-q-as-with-picture-book-creators-honoring-influential-black-figures.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## Children's Job Moves: January 2024
 - [https://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94237-children-s-job-moves-january-2024.html](https://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94237-children-s-job-moves-january-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## New Kids' and YA Books: Week of February 5, 2024
 - [https://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94233-new-kids-and-ya-books-week-of-february-5-2024.html](https://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94233-new-kids-and-ya-books-week-of-february-5-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## Obituary: Dinah Stevenson
 - [https://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94234-obituary-dinah-stevenson.html](https://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94234-obituary-dinah-stevenson.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## On Tour with Brad Meltzer and Christopher Eliopoulos
 - [https://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94221-on-tour-with-brad-meltzer-and-christopher-eliopoulos.html](https://www.publishersweekly.com/pw/by-topic/childrens/childrens-industry-news/article/94221-on-tour-with-brad-meltzer-and-christopher-eliopoulos.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## Q & A with Tony Keith Jr.
 - [https://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94232-q-a-with-tony-keith-jr.html](https://www.publishersweekly.com/pw/by-topic/childrens/childrens-authors/article/94232-q-a-with-tony-keith-jr.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## Resignations, Censures Follow in Wake of Hugo Awards Controversy
 - [https://www.publishersweekly.com/pw/by-topic/industry-news/awards-and-prizes/article/94229-resignations-censures-follow-in-wake-of-hugo-awards-controversy.html](https://www.publishersweekly.com/pw/by-topic/industry-news/awards-and-prizes/article/94229-resignations-censures-follow-in-wake-of-hugo-awards-controversy.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## Rights Report: Week of January 29, 2024
 - [https://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94235-rights-report-week-of-january-29-2024.html](https://www.publishersweekly.com/pw/by-topic/childrens/childrens-book-news/article/94235-rights-report-week-of-january-29-2024.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## The Books Behind the 2024 Academy Award Nominations, Reviewed
 - [https://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/94217-the-books-behind-the-2024-academy-award-nominations-reviewed.html](https://www.publishersweekly.com/pw/by-topic/industry-news/tip-sheet/article/94217-the-books-behind-the-2024-academy-award-nominations-reviewed.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## The Thrill of Self-Destruction: PW Talks With Daniel Lefferts
 - [https://www.publishersweekly.com/pw/by-topic///article/94236-the-thrill-of-self-destruction-pw-talks-with-daniel-lefferts.html](https://www.publishersweekly.com/pw/by-topic///article/94236-the-thrill-of-self-destruction-pw-talks-with-daniel-lefferts.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



## Tieshena Davis Named IBPA Board Chair
 - [https://www.publishersweekly.com/pw/by-topic/industry-news/people/article/94230-tieshena-davis-named-ibpa-board-chair.html](https://www.publishersweekly.com/pw/by-topic/industry-news/people/article/94230-tieshena-davis-named-ibpa-board-chair.html)
 - RSS feed: https://www.publishersweekly.com/pw/feeds/recent/index.xml
 - date published: 2024-02-01T05:00:00+00:00



