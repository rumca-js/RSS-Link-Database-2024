# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik/, language:pl-PL

## Musimy poważnie porozmawiać o Facebooku
 - [https://niebezpiecznik.pl/post/musimy-powaznie-porozmawiac-o-facebooku](https://niebezpiecznik.pl/post/musimy-powaznie-porozmawiac-o-facebooku)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2024-02-01T19:32:30+00:00

<a href="https://niebezpiecznik.pl/post/musimy-powaznie-porozmawiac-o-facebooku/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2024/02/facebook-piotr-konieczny-3-150x150.jpg" width="100" /></a>Dziś stała się rzecz smutna i zabawna jednocześnie. Facebook dał mi bana i usunął posta. Powód? Mój wpis miał promować &#8220;niebezpieczne organizacje&#8220;. Czy faktycznie promował? Sprawdźcie sami &#8212; oto oryginalna treść usuniętego wpisu, bo z usunęli go tylko na Facebooku, ale nie na Instagramie &#x1f926;&#x200d;&#x2642;&#xfe0f;: Ale w tej historii naprawdę smutne (i zabawne jednocześnie) jest [&#8230;]

## Jak zwiększyć bezpieczeństwo webaplikacji dzięki Cloudflare?
 - [https://niebezpiecznik.pl/post/jak-zwiekszyc-bezpieczenstwo-webaplikacji-dzieki-cloudflare](https://niebezpiecznik.pl/post/jak-zwiekszyc-bezpieczenstwo-webaplikacji-dzieki-cloudflare)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2024-02-01T12:07:48+00:00

<a href="https://niebezpiecznik.pl/post/jak-zwiekszyc-bezpieczenstwo-webaplikacji-dzieki-cloudflare/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2024/02/zabezpieczamy-150x150.png" width="100" /></a>W poprzednich artykułach z cyklu Poradnik Hackera Weaplikacji poruszyliśmy temat zabezpieczania aplikacji &#8220;od strony kodu&#8221;. Dziś na tapet weźmiemy inne podejście: dodatkowa ochrona webaplikacji poprzez usługę typu Web Firewall. Wykorzystamy do tego darmowe konto na Cloudflare. Aby nie przegapić kolejnych artykułów z serii &#8220;Poradnik Hackera Webaplikacji&#8221;, które są poświęcone narzędziom i technikom pomagającym w zabezpieczaniu [&#8230;]

