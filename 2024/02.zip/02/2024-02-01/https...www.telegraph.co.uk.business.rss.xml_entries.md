# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Wages still too high to hit inflation target, warns Bailey - latest updates
 - [https://www.telegraph.co.uk/business/2024/02/01/ftse-100-markets-latest-news-bank-interest-rates-shell](https://www.telegraph.co.uk/business/2024/02/01/ftse-100-markets-latest-news-bank-interest-rates-shell)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2024-02-01T13:55:53+00:00



