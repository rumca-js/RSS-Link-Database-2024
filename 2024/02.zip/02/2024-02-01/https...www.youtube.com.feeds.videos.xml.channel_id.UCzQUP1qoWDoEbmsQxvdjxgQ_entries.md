# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Sentenced to 50 Years Sheldon Johnson Decided to Turn His Life Around
 - [https://www.youtube.com/watch?v=4qrwmwfkWKo](https://www.youtube.com/watch?v=4qrwmwfkWKo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2024-02-01T18:17:23+00:00

Taken from JRE #2096 w/Josh Dubin and Sheldon Johnson:
https://open.spotify.com/episode/3nsOv2Bl6OVvTcjUrJ1GUa?si=e025da7c8faf49d8

