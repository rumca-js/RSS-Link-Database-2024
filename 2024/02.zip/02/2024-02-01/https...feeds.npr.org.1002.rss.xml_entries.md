# Source:NPR News, URL:https://feeds.npr.org/1002/rss.xml, language:en

## Lawmakers move to help veterans at risk of losing their homes
 - [https://www.npr.org/2024/02/01/1228328283/lawmakers-move-to-help-veterans-at-risk-of-losing-their-homes](https://www.npr.org/2024/02/01/1228328283/lawmakers-move-to-help-veterans-at-risk-of-losing-their-homes)
 - RSS feed: https://feeds.npr.org/1002/rss.xml
 - date published: 2024-02-01T23:15:30+00:00

Senators are introducing a new bill to help veterans who, through no fault of their own, were left facing foreclosure when a VA COVID-assistance program ended abruptly.

