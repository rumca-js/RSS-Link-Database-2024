# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en

## Haley: Taylor Swift is ‘the last thing I think we need to be worried about’
 - [https://www.politico.com/news/2024/02/01/nikki-haley-taylor-swift-00139196](https://www.politico.com/news/2024/02/01/nikki-haley-taylor-swift-00139196)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-02-01T18:32:38+00:00

Nikki Haley calls conspiracy theories around Taylor Swift "bizarre."

## Matt Gaetz deposed Kevin McCarthy and the donations came pouring in
 - [https://www.politico.com/news/2024/02/01/matt-gaetz-donations-00139182](https://www.politico.com/news/2024/02/01/matt-gaetz-donations-00139182)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-02-01T17:27:01+00:00

Most of the “Gaetz Eight” saw their small-dollar fundraising increase — but the Florida ringleader was the clear winner.

## RFK Jr. blames young campaign staffer for TikTok thirst trap comment
 - [https://www.politico.com/news/2024/02/01/rfk-jr-tiktok-thirst-trap-00139139](https://www.politico.com/news/2024/02/01/rfk-jr-tiktok-thirst-trap-00139139)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-02-01T16:05:50+00:00

“The TikTok comment in question was made in 2022 long before I ever had a TikTok account," the presidential hopeful posted on social media.

## Trump continues to bash border deal
 - [https://www.politico.com/video/2024/02/01/trump-continues-to-bash-border-deal-1206557](https://www.politico.com/video/2024/02/01/trump-continues-to-bash-border-deal-1206557)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-02-01T11:49:18+00:00



## What it's like to be endorsed by Taylor Swift
 - [https://www.politico.com/news/2024/02/01/taylor-swift-endorsement-00139033](https://www.politico.com/news/2024/02/01/taylor-swift-endorsement-00139033)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2024-02-01T10:26:44+00:00

Some of Phil Bredesen's relatives thought the endorsement from Taylor Swift was “cooler than being governor,” he told POLITICO.

