# Source:Brad Colbow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A, language:en-US

## Huion Kamvas Pro 27 Review
 - [https://www.youtube.com/watch?v=-NoCdSWq8AM](https://www.youtube.com/watch?v=-NoCdSWq8AM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UClozNP-QPyVatzpGKC25s0A
 - date published: 2024-02-01T14:00:00+00:00

NEW COURSES: http://bradsartschool.com

The Kamvas Pro 27 is HUGE but it's also very good with Huion's latest pen tech and all the bells and whistles you would expect in a Wacom tablet.

Join this channel to get access to perks:
https://www.youtube.com/channel/UClozNP-QPyVatzpGKC25s0A/join

Email Newsletter: http://brad.site/signup/

-----------------------------------------------------

Twitter: 
https://twitter.com/bradcolbow

Instagram:
https://www.instagram.com/brad.colbow/

Drawing Tech Top 10 lists:
http://brad.site/

My Drawing and video gear: 
http://brad.site/mygear/

