# Source:tyler fischer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3Y_HaUqzTYABL2whcwGOKA, language:en

## 1st guy to successfully get Elon's brain chip!!
 - [https://www.youtube.com/watch?v=IZzjM_BYgVY](https://www.youtube.com/watch?v=IZzjM_BYgVY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3Y_HaUqzTYABL2whcwGOKA
 - date published: 2024-02-01T02:21:25+00:00

See me on tour! Atlanta next week! https://www.tylerfischer.com
Join my channel to get access to perks:
https://www.youtube.com/channel/UC3Y_HaUqzTYABL2whcwGOKA/join

