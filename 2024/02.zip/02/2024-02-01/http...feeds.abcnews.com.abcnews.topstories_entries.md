# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Publicis Health agrees to $350M settlement over claims it helped fuel opioid crisis
 - [https://abcnews.go.com/US/publicis-health-agrees-350m-settlement-claims-helped-purdue/story?id=106880427](https://abcnews.go.com/US/publicis-health-agrees-350m-settlement-claims-helped-purdue/story?id=106880427)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T23:27:07+00:00

Publicis Groupe SA agreed Thursday to pay $350 million to settle claims it helped OxyContin maker Purdue Pharma fuel the opioids epidemic in the United States.

## Special counsel asked witnesses about 2 Mar-a-Lago rooms FBI didn't search: Sources
 - [https://abcnews.go.com/US/special-counsel-questioned-witnesses-2-rooms-fbi-search/story?id=106826552](https://abcnews.go.com/US/special-counsel-questioned-witnesses-2-rooms-fbi-search/story?id=106826552)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T23:13:23+00:00

The special counsel has questioned witnesses about a so-called "hidden room" inside Mar-a-Lago that wasn't searched by the FBI during their August 2022 raid, sources say.

## Ex-Trump Organization CFO Allen Weisselberg in perjury plea talks, sources say
 - [https://abcnews.go.com/US/trump-organization-cfo-allen-weisselberg-perjury-plea-talks/story?id=106879915](https://abcnews.go.com/US/trump-organization-cfo-allen-weisselberg-perjury-plea-talks/story?id=106879915)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T22:35:07+00:00

Former Trump Org. Chief Financial Officer Allen Weisselberg is in plea talks with the Manhattan district attorney's office to resolve a potential perjury charge.

## Small plane crashes in Pennsylvania neighborhood; injuries not clear
 - [https://abcnews.go.com/US/wireStory/small-plane-crashes-pennsylvania-neighborhood-clear-injuries-106878930](https://abcnews.go.com/US/wireStory/small-plane-crashes-pennsylvania-neighborhood-clear-injuries-106878930)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T22:14:03+00:00

Authorities say a small plane has crashed in a central Pennsylvania neighborhood

## Man convicted of largest leak in CIA history sentenced to 40 years in prison
 - [https://abcnews.go.com/US/joshua-schulte-largest-leaker-cia-material-history-sentenced/story?id=106878389](https://abcnews.go.com/US/joshua-schulte-largest-leaker-cia-material-history-sentenced/story?id=106878389)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T22:10:26+00:00

Joshua Schulte, who was convicted of orchestrating the largest leak of classified material in CIA history, was sentenced to 40 years in prison Thursday.

## WATCH:  2-year-old gives her dad a dancing lesson
 - [https://abcnews.go.com/GMA/Family/video/2-year-dad-dancing-lesson-106878838](https://abcnews.go.com/GMA/Family/video/2-year-dad-dancing-lesson-106878838)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T22:03:36+00:00

Mom and dad were both surprised at how much of a natural she is.

## 3 dead, 5 in critical condition in hangar collapse: 'Like a house of cards'
 - [https://abcnews.go.com/US/12-injured-boise-building-collapse-airport/story?id=106849154](https://abcnews.go.com/US/12-injured-boise-building-collapse-airport/story?id=106849154)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T20:54:16+00:00

Three people died and five were left in critical condition after a building under construction near the Boise, Idaho, airport collapsed Wednesday night, officials said.

## FDA warns consumers contaminated 'copycat' eye drops could cause infections
 - [https://abcnews.go.com/US/fda-warns-consumers-contaminated-copycat-eye-drops-cause/story?id=106866988](https://abcnews.go.com/US/fda-warns-consumers-contaminated-copycat-eye-drops-cause/story?id=106866988)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T20:16:17+00:00

The FDA is warning consumers about 'copycat' eye drop brands that could potentially cause infections.

## Some Gazans using bird feed as flour: 'Forced to eat it' to 'silence their hunger'
 - [https://abcnews.go.com/International/some-gazans-bird-feed-flour/story?id=106861383](https://abcnews.go.com/International/some-gazans-bird-feed-flour/story?id=106861383)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T19:20:57+00:00

The possibility of famine looms large across Gaza, humanitarian groups warn, especially in northern Gaza, where some there say they're using bird feed in place of flour.

## ICE arrests 171 noncitizens in latest enforcement push
 - [https://abcnews.go.com/Politics/ice-arrests-171-noncitizens-latest-enforcement-push/story?id=106868688](https://abcnews.go.com/Politics/ice-arrests-171-noncitizens-latest-enforcement-push/story?id=106868688)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T19:19:02+00:00

Officials say the agency needs more resources to expand its operations.

## Jennifer Crumbley takes the stand in manslaughter trial tied to son's school shooting
 - [https://abcnews.go.com/US/jennifer-crumbley-takes-stand-manslaughter-trial-tied-sons/story?id=106862961](https://abcnews.go.com/US/jennifer-crumbley-takes-stand-manslaughter-trial-tied-sons/story?id=106862961)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T19:09:51+00:00

Jennifer Crumbley took the stand in her manslaughter trial in connection with the 2021 Oxford High School shooting carried out by Ethan Crumbley.

## California teenager charged with swatting faces adult charges in Florida
 - [https://abcnews.go.com/Technology/wireStory/california-teenager-charged-swatting-faces-adult-charges-florida-106873390](https://abcnews.go.com/Technology/wireStory/california-teenager-charged-swatting-faces-adult-charges-florida-106873390)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T19:09:22+00:00

A California teenager accused of swatting a Florida mosque has been arrested and transported across the country to face felony charges

## Child's body found in storage unit. Investigators want to make sure 2 others are safe
 - [https://abcnews.go.com/US/wireStory/childs-body-found-colorado-storage-unit-investigators-make-106872084](https://abcnews.go.com/US/wireStory/childs-body-found-colorado-storage-unit-investigators-make-106872084)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T18:56:21+00:00

A child's body was found encased in concrete in a Colorado storage unit, and Pueblo officers announced this week they are searching for two other children to determine if they are safe

## WATCH:  Kangaroo swims across floodwaters
 - [https://abcnews.go.com/International/video/kangaroo-swims-floodwaters-106872082](https://abcnews.go.com/International/video/kangaroo-swims-floodwaters-106872082)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T18:55:46+00:00

A courageous kangaroo was spotted crossing floodwaters as heavy rainfall hit parts of Queensland, Australia.

## Newest COVID shots are 54% effective in preventing symptoms, CDC finds
 - [https://abcnews.go.com/Health/wireStory/newest-covid-shots-54-effective-preventing-symptoms-cdc-106871066](https://abcnews.go.com/Health/wireStory/newest-covid-shots-54-effective-preventing-symptoms-cdc-106871066)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T18:34:40+00:00

The latest COVID-19 vaccines are 54% effective at preventing symptomatic infection in adults

## Suspects sought after 11-year-old injured in shooting attack by 3 assailants
 - [https://abcnews.go.com/US/atlanta-11-year-old-shot-suspects-sought/story?id=106868230](https://abcnews.go.com/US/atlanta-11-year-old-shot-suspects-sought/story?id=106868230)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T18:22:08+00:00

Police in Atlanta said they are searching for three suspects who chased and opened fire on an 11-year-old boy, injuring him.

## Group of Kentucky educators won $1 million Powerball, hid ticket in math book
 - [https://abcnews.go.com/US/wireStory/group-kentucky-educators-won-1-million-powerball-hid-106870794](https://abcnews.go.com/US/wireStory/group-kentucky-educators-won-1-million-powerball-hid-106870794)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T18:03:06+00:00

A group of employees and teachers from a Kentucky middle school have won a $1 million Powerball prize

## Man who had affair with Jennifer Crumbley testifies about her son's school shooting
 - [https://abcnews.go.com/US/man-affair-jennifer-crumbley-testifies-sons-school-shooting/story?id=106839270](https://abcnews.go.com/US/man-affair-jennifer-crumbley-testifies-sons-school-shooting/story?id=106839270)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T17:23:51+00:00

A man who Jennifer Crumbley had an affair with leading up to the shooting was on the stand Wednesday.

## A UK lawmaker says he's quitting Parliament after death threats and an arson attack
 - [https://abcnews.go.com/International/wireStory/uk-lawmaker-quitting-parliament-after-death-threats-arson-106862154](https://abcnews.go.com/International/wireStory/uk-lawmaker-quitting-parliament-after-death-threats-arson-106862154)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T16:51:10+00:00

A Conservative lawmaker says he will step down when an election is called later this year because of abuse and death threats

## More Americans apply for unemployment benefits but layoffs still historically low
 - [https://abcnews.go.com/Business/wireStory/americans-apply-unemployment-benefits-layoffs-historically-low-106859648](https://abcnews.go.com/Business/wireStory/americans-apply-unemployment-benefits-layoffs-historically-low-106859648)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T15:42:29+00:00

The number of Americans filing for jobless benefits rose last week to the highest level in 11 weeks, though layoffs remain at historically low levels

## 3 teens shot, 1 fatally, in apparent targeted attack near their high school
 - [https://abcnews.go.com/US/3-teens-shot-1-fatally-apparent-targeted-attack/story?id=106859071](https://abcnews.go.com/US/3-teens-shot-1-fatally-apparent-targeted-attack/story?id=106859071)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T15:17:15+00:00

One teenager was killed and two were injured in an apparent targeted shooting in broad daylight a few blocks from their Chicago school, according to police.

## Home prices jumped by most in almost a year in November: Closely watched barometer
 - [https://abcnews.go.com/Business/wireStory/home-prices-jumped-year-november-closely-watched-barometer-106858658](https://abcnews.go.com/Business/wireStory/home-prices-jumped-year-november-closely-watched-barometer-106858658)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T14:23:22+00:00

A closely watched housing market barometer shows U.S. home prices in November posted their biggest annual gain in almost a year

## Defense Secretary Austin to face questions for 1st time since secret hospitalization
 - [https://abcnews.go.com/Politics/defense-secretary-austin-face-questions-1st-time-keeping/story?id=106859477](https://abcnews.go.com/Politics/defense-secretary-austin-face-questions-1st-time-keeping/story?id=106859477)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T14:10:50+00:00

He is holding a news conference at 10:30 a.m.

## European Union agrees on a new 50 billion-euro aid package for Ukraine
 - [https://abcnews.go.com/International/wireStory/eu-leaders-face-new-showdown-hungary-seek-unblock-106854311](https://abcnews.go.com/International/wireStory/eu-leaders-face-new-showdown-hungary-seek-unblock-106854311)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T14:06:30+00:00

A top European Union official says the 27 EU countries have sealed a deal to provide Ukraine with a new 50 billion-euro support package despite weeks of threats from Hungary to veto the move

## US hits Houthi UAVs, ground control station in Yemen
 - [https://abcnews.go.com/International/us-hits-houthi-uavs-ground-control-station-yemen/story?id=106853306](https://abcnews.go.com/International/us-hits-houthi-uavs-ground-control-station-yemen/story?id=106853306)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T14:03:24+00:00

U.S. military forces early Thursday morning conducted what Central Command called a “self-defense” strike against Houthi unmanned aerial vehicles.

## Climate activist Greta Thunberg on trial in London for blocking oil, gas conference
 - [https://abcnews.go.com/International/wireStory/greta-thunberg-trial-london-climate-protest-oil-gas-106857777](https://abcnews.go.com/International/wireStory/greta-thunberg-trial-london-climate-protest-oil-gas-106857777)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T13:42:38+00:00

Climate activist Greta Thunberg is on trial for protesting outside a major oil and gas industry conference in London last year

## NC governor hopes Medicaid expansion to 600K people can be example after long battle
 - [https://abcnews.go.com/Politics/north-carolina-governor-hopes-medicaid-expansion-600k-residents/story?id=105853956](https://abcnews.go.com/Politics/north-carolina-governor-hopes-medicaid-expansion-600k-residents/story?id=105853956)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T13:07:41+00:00

More than 600,000 adults in North Carolina are now eligible to receive benefits through an expansion of Medicaid that the state, like 10 others, long resisted

## UK judge dismisses Trump's lawsuit over dossier containing 'scandalous claims'
 - [https://abcnews.go.com/International/wireStory/uk-judge-dismisses-trumps-lawsuit-dossier-shocking-scandalous-106855353](https://abcnews.go.com/International/wireStory/uk-judge-dismisses-trumps-lawsuit-dossier-shocking-scandalous-106855353)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T12:22:31+00:00

A judge in London has thrown out a lawsuit by former U.S. President Donald Trump accusing a former British spy of making &ldquo;shocking and scandalous claims&rdquo; that were false and harmed his reputation

## WATCH:  Police rescue boy stuck inside 'Hello Kitty' claw machine
 - [https://abcnews.go.com/International/video/police-rescue-boy-stuck-inside-kitty-claw-machine-106856821](https://abcnews.go.com/International/video/police-rescue-boy-stuck-inside-kitty-claw-machine-106856821)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T12:15:52+00:00

Police officers in Australia help free a small boy who got stuck inside a "Hello Kitty" claw machine.

## Trump spent more than $50M of his PAC and super PAC money on legal bills in 2023
 - [https://abcnews.go.com/US/trump-spent-50m-pac-super-pac-money-legal/story?id=106843612](https://abcnews.go.com/US/trump-spent-50m-pac-super-pac-money-legal/story?id=106843612)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T04:43:15+00:00

Donald Trump's legal fees cost his political fundraising committees more than $50 million in 2023, leaving his PAC with just $5.1 million in the bank entering 2024.

## WATCH:  Drivers dodge tumbleweeds blowing across California highway
 - [https://abcnews.go.com/Travel/video/drivers-dodge-tumbleweeds-blowing-california-highway-106850634](https://abcnews.go.com/Travel/video/drivers-dodge-tumbleweeds-blowing-california-highway-106850634)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T03:12:03+00:00

Drivers dodged tumbleweeds Wednesday on Interstate 5 in Central California.

## House passes bipartisan tax bill that would expand child tax credit
 - [https://abcnews.go.com/Politics/house-vote-bipartisan-tax-bill-expand-child-tax/story?id=106826071](https://abcnews.go.com/Politics/house-vote-bipartisan-tax-bill-expand-child-tax/story?id=106826071)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T02:09:28+00:00

The House passed a bipartisan tax bill that would enhance the popular Child Tax Credit to benefit millions of American families.

## Could Louisiana soon resume death row executions?
 - [https://abcnews.go.com/US/wireStory/louisiana-resume-death-row-executions-106847523](https://abcnews.go.com/US/wireStory/louisiana-resume-death-row-executions-106847523)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T01:32:12+00:00

Louisiana Gov. Jeff Landry has hinted that the state may explore expanding its methods of executing people on death row

## Noem looking to bolster Texas security efforts at US-Mexico border
 - [https://abcnews.go.com/US/wireStory/noem-bolster-texas-security-efforts-us-mexico-border-106847797](https://abcnews.go.com/US/wireStory/noem-bolster-texas-security-efforts-us-mexico-border-106847797)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2024-02-01T01:30:21+00:00

South Dakota Gov. Kristi Noem says her administration is considering boosting its support for Texas&rsquo; efforts to deter immigration at the U.S.-Mexico border

