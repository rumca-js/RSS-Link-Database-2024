# Source:Joshua Fluke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA, language:en-US

## WORKER RECORDS BEING FIRED - "Poor Performance"
 - [https://www.youtube.com/watch?v=t6xt9u4uEfg](https://www.youtube.com/watch?v=t6xt9u4uEfg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-91UA-Xy2Cvb98deRXuggA
 - date published: 2024-02-01T00:06:55+00:00

🔥 Need a resume/cover letter? Head to Joshuafluke.store

❤️ Support my content because corporate sponsors rarely do! 
 https://www.patreon.com/joshuafluke

👊 Join the community! 
https://discord.gg/Joshuafluke

Socials🤳
https://www.tiktok.com/@joshua_fluke
https://www.instagram.com/joshuafluke/  📸
https://twitter.com/joshuafluke  🐦

📧 Email me directly!: grindreel@gmail.com
📧 Business inquiries: Joshuafluke@thoughtleaders.io  

My Gear ⚙️:  https://kit.co/JoshuaFluke


the modern workplace: being laid off over Zoom. Witness firsthand the stark reality as I navigate through a termination meeting with HR representatives I've never met before. The footage reveals the challenging dynamics of remote layoffs, highlighting the emotional toll and the starkness of corporate protocols.

If this video resonates with you or you find value in bringing these workplace practices to light, please consider supporting the channel by liking, commenting, and subscribing. Your engagement helps fu

