# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Meta Platforms z droższymi reklamami i pierwszą dywidendą. Inwestorzy w euforii
 - [https://www.wirtualnemedia.pl/artykul/facebook-ile-zarabia-zysk-meta-platforms](https://www.wirtualnemedia.pl/artykul/facebook-ile-zarabia-zysk-meta-platforms)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T23:34:28.721812+00:00

W zeszłym kwartale właściciel Facebooka, Instagrama i WhatsAppa zarobił na czysto 14 mld dolarów przy wzroście przychodów o 25 proc., dużo wyższym niż w poprzednich kwartałach. Koncern pierwszy raz podzieli się zyskiem z akcjonariuszami.

## Ruszył Kanał Zero. Jutro pokaże wywiad z Andrzejem Dudą
 - [https://www.wirtualnemedia.pl/artykul/kanal-zero-pierwszy-film-krzysztof-stanowski](https://www.wirtualnemedia.pl/artykul/kanal-zero-pierwszy-film-krzysztof-stanowski)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T20:19:18.012363+00:00

W pierwszym wideo na Kanale Zero Krzysztof Stanowski opowiedział o idei projektu, który ma stać się jakościową alternatywą dla mainstreamowych mediów. – Polskie media zabrnęły w ślepą uliczkę. Chcę być kamieniem w bucie dużych mediów – zapowiedział twórca Kanału Zero. W piątek na kanale ukaże się wywiad z prezydentem Andrzejem Dudą.

## Piotr Mieśnik dyrektorem wydawniczym Grupy PTWP
 - [https://www.wirtualnemedia.pl/artykul/piotr-miesnik-dyrektorem-wydawniczym-grupy-ptwp](https://www.wirtualnemedia.pl/artykul/piotr-miesnik-dyrektorem-wydawniczym-grupy-ptwp)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T17:04:13.621937+00:00

Do pracy w mediach wraca Piotr Mieśnik, został dyrektorem wydawniczym w Grupie PTWP wydającej magazyny specjalistyczne. Jego zastępczynią będzie Paulina Gumowska, która pozostanie naczelną „Rynku Zdrowia”.

## Stanowski ujawnił ostatnich autorów Kanału Zero. "Z tego ogłoszenia jestem najbardziej dumny"
 - [https://www.wirtualnemedia.pl/artykul/kanal-zero-krzysztof-stanowski-2](https://www.wirtualnemedia.pl/artykul/kanal-zero-krzysztof-stanowski-2)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T14:54:34.116240+00:00

Krzysztof Stanowski ogłosił dwa ostatnie nazwiska autorów Kanału Zero, który rusza dzisiaj. To Rajmund Andrzejczak, były szef sztabu generalnego Wojska Polskiego oraz Sławomir Dębski, historyk i politolog.

## Filmowcy oburzeni brakiem tantiem z internetu. Chcą śledztwa prokuratury
 - [https://www.wirtualnemedia.pl/artykul/dyrektywa-tantiemy-internet-netflix-stowarzyszenie-filmowcow-polskich](https://www.wirtualnemedia.pl/artykul/dyrektywa-tantiemy-internet-netflix-stowarzyszenie-filmowcow-polskich)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T14:54:31.030075+00:00

Stowarzyszenie Filmowców Polskich złożyło dziś zawiadomienie o podejrzeniu popełnienia przestępstwa, polegającego na zaniechaniu przez rząd Mateusza Morawieckiego przyjęcia dyrektywy unijnej wprowadzającej tantiemy z internetu. Zdaniem filmowców, brak jej wdrożenia to wina „licznych uchybień i zaniechań, jakich dopuściła się poprzednia ekipa rządząca”. Śledztwem może zostać objęte m.in. spotkanie Morawickiego z szefem Netfliksa.

## Netflix zapowiada nowe filmy i seriale. Będą kontynuacje „Squid Game” i „Rebel Moon”
 - [https://www.wirtualnemedia.pl/artykul/netflix-filmy-seriale-nowe-2024-rok-lista-premier](https://www.wirtualnemedia.pl/artykul/netflix-filmy-seriale-nowe-2024-rok-lista-premier)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T14:54:27.500760+00:00

Netflix zapowiada swoim subskrybentom czekającym na drugi sezon „Squid Game”, kolejną odsłonę „Rebel Moon” czy najnowszą produkcję „Problem trzech ciał”, że dostaną to, a nawet dużo więcej. W tym roku na posterunek wróci Eddie Murphy w czwartej części słynnej serii „Gliniarz z Beverly Hills: Axel F.”, w ofercie pojawi się też nowa ekranizacja „Awatar: Ostatni władca wiatru”, a Jennifer Lopez spróbuje ocalić ludzkość w filmie „Atlas”.

## Kanał Sportowy ma nową czołówkę. "Lekkie odświeżenie, stary fundament"
 - [https://www.wirtualnemedia.pl/artykul/kanal-sportowy-nowa-czolowka](https://www.wirtualnemedia.pl/artykul/kanal-sportowy-nowa-czolowka)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T05:53:26.191067+00:00

Kanał Sportowy pochwalił się, że od środy jego produkcje będzie poprzedzać nowa czołówka. - Lekkie odświeżenie, stary fundament - czytamy na profilu KS na X.

## Serial „W garniturach” największym hitem amerykańskiego streamingu
 - [https://www.wirtualnemedia.pl/artykul/serial-w-garniturach-najwiekszym-hitem-amerykanskiego-streamingu-wyniki-ogladalnosci-netflix](https://www.wirtualnemedia.pl/artykul/serial-w-garniturach-najwiekszym-hitem-amerykanskiego-streamingu-wyniki-ogladalnosci-netflix)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T05:53:23.211162+00:00

Po rekordowych wynikach oglądalności serialu „W garniturach” na Netfliksie latem i jesienią 2023 roku, obraz może poszczycić się kolejnym kamieniem milowym: jest to najczęściej odtwarzana przez amerykańskich subskrybentów produkcja w ciągu roku w historii rankingów Nielsena.

## Rusza Kanał Zero Krzysztofa Stanowskiego. W czwartek tylko jeden program
 - [https://www.wirtualnemedia.pl/artykul/kanal-zero-krzysztof-stanowski-start-gdzie-ogladac-youtube-wywiad-przemyslaw-rudzki](https://www.wirtualnemedia.pl/artykul/kanal-zero-krzysztof-stanowski-start-gdzie-ogladac-youtube-wywiad-przemyslaw-rudzki)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T05:53:20.142745+00:00

W czwartek startuje oficjalnie nowy projekt Krzysztofa Stanowskiego Kanał Zero. Ogłoszono już nazwiska pierwszych autorów, a kanał zadebiutuje o godzinie 20.00 rozmową Przemysława Rudzkiego z Krzysztofem Stanowskim.

## Borek, Pol, Wardęga, a może Janoszek? Kto dołączy do Stanowskiego w Kanale Zero?
 - [https://www.wirtualnemedia.pl/artykul/kanal-zero-krzysztof-stanowski-kto-dolaczy-michal-pol-mateusz-borek-sylwester-wardega-natalia-janoszek-marcin-najman-betclic-zaklady](https://www.wirtualnemedia.pl/artykul/kanal-zero-krzysztof-stanowski-kto-dolaczy-michal-pol-mateusz-borek-sylwester-wardega-natalia-janoszek-marcin-najman-betclic-zaklady)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T04:48:41.335842+00:00

1 lutego rozpoczyna oficjalnie nadawanie na YouTubie Kanał Zero Krzysztofa Stanowskiego. Wśród prowadzących znaleźli się Tomasz Raczek, Robert Mazurek, Marcin Meller, Robert Gwiazdowski i Tede. Analitycy Betclic oszacowali, kto jeszcze może pojawić się w tym roku w kanale.

## „Griselda” nowym hitem Netfliksa
 - [https://www.wirtualnemedia.pl/artykul/griselda-hit-netflix](https://www.wirtualnemedia.pl/artykul/griselda-hit-netflix)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T04:48:38.553246+00:00

Serial „Griselda” zadebiutował na Netfliksie 25 stycznia i od tego czasu króluje na czołowych pozycjach Top 10 w 89 krajach. Zainspirowany życiem kokainowej baronki Griseldy Blanco, w okresie od 25 do 28 stycznia uzyskał łącznie 20,6 mln wyświetleń.

## Gazeta.pl z wideopodcastem prowadzonym przez drag queen
 - [https://www.wirtualnemedia.pl/artykul/gazeta-pl-wideopocast-slay-show-shady-lady-jak-odbierac-kiedy-ogladac](https://www.wirtualnemedia.pl/artykul/gazeta-pl-wideopocast-slay-show-shady-lady-jak-odbierac-kiedy-ogladac)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T04:48:35.935173+00:00

W środę 31 stycznia na stronie głównej Gazeta.pl (Agora) zadebiutował wideopodcast pt. „Slay Show”. To rozmowy poświęcone równości i tolerancji, które prowadzi Shady Lady – znana polska drag queen. Ze swoimi gośćmi porozmawia m.in. o tym, jak wygląda życie społeczności osób LGBTQ+ w Polsce.

## Piosenki dziesiątek artystów znikną z TikToka. Konflikt z Universal Music Group
 - [https://www.wirtualnemedia.pl/artykul/koniec-tiktok-muzyka-universal-music-group-taylor-swift](https://www.wirtualnemedia.pl/artykul/koniec-tiktok-muzyka-universal-music-group-taylor-swift)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T04:48:32.478804+00:00

TikTok i Universal Music Group do końca stycznia nie osiągnęły porozumienia w sprawie wykorzystania muzyki w aplikacji. Oznacza to, że piosenki tego muzycznego giganta znikną z popularnej platformy. Nie usłyszymy na TikToku utworów Taylor Swift, Drake’a czy BTS. Osią sporu są pieniądze, ale i wykorzystanie sztucznej inteligencji.

## Ekipa chce mieć własne studia i magazyn. 6 mln zł za działkę
 - [https://www.wirtualnemedia.pl/artykul/ekipa-friz-youtube-siedziba-studio](https://www.wirtualnemedia.pl/artykul/ekipa-friz-youtube-siedziba-studio)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T04:48:29.352220+00:00

Influencerska Ekipa Holding za 6 mln zł kupi działkę o powierzchni 2,8 hektara. Chce tam mieć siedzibę z sześcioma studiami do produkcji treści wideo i zapleczem swoich platform e-commerce.

## Wirtualnemedia.pl w czołówce najbardziej opiniotwórczych mediów w Polsce w 2023 roku. Liderem „Rzeczpospolita”
 - [https://www.wirtualnemedia.pl/artykul/wirtualnemedia-pl-najbardziej-opiniotworcze-media-w-polsce-2023-roku-rzeczpospolita-wirtualna-polska](https://www.wirtualnemedia.pl/artykul/wirtualnemedia-pl-najbardziej-opiniotworcze-media-w-polsce-2023-roku-rzeczpospolita-wirtualna-polska)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2024-02-01T04:48:26.104988+00:00

Portal Wirtualnemedia.pl znalazł się w gronie piętnastu najbardziej opiniotwórczych mediów w Polsce w roku 2023 – wynika z rankingu Instytutu Monitorowania Mediów. Na nasze informacje inne redakcje powoływały się ponad 11 tys. razy. Liderem zestawienia jest „Rzeczpospolita”, która na podium wyprzedziła TVN24 i Wirtualną Polskę.

