# Source:UploadVR, URL:https://www.uploadvr.com/rss, language:en

## Vive Ultimate Trackers Now Have Beta Support For PC VR
 - [https://www.uploadvr.com/vive-ultimate-trackers-pc-support](https://www.uploadvr.com/vive-ultimate-trackers-pc-support)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T23:17:44+00:00

Vive Ultimate Trackers now work on PC, though this support is currently in beta.

## Quest 3 Launch Drove Highest Ever Meta Reality Labs Quarterly Revenue, Over $1 Billion
 - [https://www.uploadvr.com/meta-quest-3-launch-record-revenue-1-billion](https://www.uploadvr.com/meta-quest-3-launch-record-revenue-1-billion)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T22:14:44+00:00

BREAKING: Meta's AR/VR division achieved its highest quarterly revenue ever following Quest 3's launch, more than $1 billion for the first time.

## How Project Demigod Went From Early Access VR Superhero Sim To Full Release
 - [https://www.uploadvr.com/project-demigod-vr-superhero-sim-interview](https://www.uploadvr.com/project-demigod-vr-superhero-sim-interview)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T21:00:24+00:00

Project Demigod enters full release today on Quest and PC VR. We spoke with the developer to learn more. 

Our full interview:

## Quest v62 Adds iPhone Spatial Video Support, Improves Quest 3 Microphone, &amp; Much More
 - [https://www.uploadvr.com/meta-quest-v62-update](https://www.uploadvr.com/meta-quest-v62-update)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T18:05:17+00:00

The Quest v62 update adds support for easily viewing iPhone spatial videos, improves Quest 3's microphone quality, and much more.

See the full changes here:

## Walkabout Mini Golf: Pocket Edition iPhone - Beta Details And More From Mighty Coconut
 - [https://www.uploadvr.com/walkabout-mini-golf-pocket-edition-arrives-on-iphone-in-open-beta](https://www.uploadvr.com/walkabout-mini-golf-pocket-edition-arrives-on-iphone-in-open-beta)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T18:00:20+00:00

Walkabout Mini Golf Pocket Edition is now in open testing on iPhones.

## Stranger Things VR Visits The Upside Down On February 22
 - [https://www.uploadvr.com/stranger-things-vr-quest-release-date](https://www.uploadvr.com/stranger-things-vr-quest-release-date)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T17:03:37+00:00

Stranger Things VR has a new release date this month on Quest, three months after a previous delay.

## Here Are The Meta Quest+ Monthly Subscription Games For February 2024
 - [https://www.uploadvr.com/meta-quest-plus-february-2024](https://www.uploadvr.com/meta-quest-plus-february-2024)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T15:58:09+00:00

The Meta Quest+ games for February are now live – here's what's you can download.

## Tim Cook Finally Seen Wearing Apple Vision Pro, And Details His First Prototype Demo
 - [https://www.uploadvr.com/tim-cook-wearing-apple-vision-pro-vanity-fair](https://www.uploadvr.com/tim-cook-wearing-apple-vision-pro-vanity-fair)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T15:36:37+00:00

Tim Cook has finally been publicly seen wearing Apple Vision Pro, for a Vanity Fair piece describing his first demo with an early prototype.

## Synth Riders Rebuilt &#x27;From The Ground Up&#x27; For Apple Vision Pro
 - [https://www.uploadvr.com/synth-riders-apple-vision-pro](https://www.uploadvr.com/synth-riders-apple-vision-pro)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T14:00:14+00:00

Synth Riders was rebuilt &quot;from the ground up&quot; for Apple Vision Pro, and it joins the increasing list of launch games.

## Sony&#x27;s Mocopi Body Tracking System For VRChat Now Works On PC
 - [https://www.uploadvr.com/sonys-mocopi-for-vrchat-now-works-on-pc](https://www.uploadvr.com/sonys-mocopi-for-vrchat-now-works-on-pc)
 - RSS feed: https://www.uploadvr.com/rss
 - date published: 2024-02-01T11:00:00+00:00

Sony's Mocopi body tracking system for VRChat now works on PC.

Here's how:

