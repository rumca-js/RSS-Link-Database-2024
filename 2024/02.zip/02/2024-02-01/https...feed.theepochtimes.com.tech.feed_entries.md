# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Rights Group Doubts Neuralink’s Brain Chip Progress, Citing ‘Troubling History’ of Monkey Experiments
 - [https://www.theepochtimes.com/business/rights-group-doubts-neuralinks-brain-chip-progress-citing-troubling-history-of-monkey-experiments-5578463](https://www.theepochtimes.com/business/rights-group-doubts-neuralinks-brain-chip-progress-citing-troubling-history-of-monkey-experiments-5578463)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-02-01T19:08:08+00:00

Neuralink logo and Elon Musk photo in an illustration taken on Dec. 19, 2022. (Dado Ruvic/Illustration/Reuters)

## Supermicro Has Become One of the Best Performing AI Stocks in the Past Year
 - [https://www.theepochtimes.com/tech/supermicro-has-become-one-of-the-best-performing-ai-stocks-in-the-past-year-5576893](https://www.theepochtimes.com/tech/supermicro-has-become-one-of-the-best-performing-ai-stocks-in-the-past-year-5576893)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-02-01T18:03:51+00:00

Visitors are seen in front of a screen showing the images of Jensen Huang (R), CEO of NVIDIA, and Charles Liang, Founder and President of the Supermicro, at the Computex 2023 in Taipei on May 30, 2023. (Sam Yeh / AFP via Getty Images)

## Hulu Follows Netflix in Crackdown on Password, Account Sharing
 - [https://www.theepochtimes.com/business/hulu-follows-netflix-in-crackdown-on-password-account-sharing-5578172](https://www.theepochtimes.com/business/hulu-follows-netflix-in-crackdown-on-password-account-sharing-5578172)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2024-02-01T14:35:25+00:00

The logos for streaming services Netflix, Hulu, Disney+, and Sling TV on a remote control in Portland, Ore., on Aug. 13, 2020. (Jenny Kane/AP Photo)

