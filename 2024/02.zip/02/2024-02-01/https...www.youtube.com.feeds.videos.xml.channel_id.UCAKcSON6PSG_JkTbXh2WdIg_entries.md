# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Luke LeBlanc -- A Place (live for The Current)
 - [https://www.youtube.com/watch?v=ZlJSS9JonN0](https://www.youtube.com/watch?v=ZlJSS9JonN0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2024-02-01T03:00:29+00:00

Minneapolis singer-songwriter Luke LeBlanc recently released Places, his third full-length album in as many years, and his first on @ErikKoskinen's Real Phonic label. 

LeBlanc and his band visited The Current studio for Radio Heartland to play songs from the new album. Here is their performance of the track, "A Place." 

Musicians
Luke LeBlanc – vocals, guitar, harmonica
John Cleve Richardson – piano, vocals
Ben Lester – pedal steel
Caz Falen – bass, vocals
Lars-Erik Larsen – drums

Credits
Guest – @lukeleblanc 
Host & Producer – Mike Pengra
Video Director – Evan Clark 
Camera Operators – Evan Clark, Josh Sauvageau
Audio – Craig Thorson
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user

