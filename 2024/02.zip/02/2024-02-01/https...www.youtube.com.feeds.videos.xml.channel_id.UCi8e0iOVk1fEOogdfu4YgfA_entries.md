# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## The 10 Most Anticipated Black Led Shows & Movies of 2024 | What to Watch
 - [https://www.youtube.com/watch?v=qk5lkxyHnKk](https://www.youtube.com/watch?v=qk5lkxyHnKk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-02-01T22:53:27+00:00

Welcome back to this week's What to Watch! 2024 is an exciting year for entertainment and we're highlighting the most anticipated Black led movies and TV shows of 2024. What will you be watching?

► Learn more about Genius: MLK/X: https://www.rottentomatoes.com/tv/genius/s04?cmp=Trailers_YouTube_Desc 
► Learn more about Mr. & Mrs. Smith: https://www.rottentomatoes.com/tv/mr_and_mrs_smith_2024?cmp=Trailers_YouTube_Desc 
► Learn more about Bob Marley: One Love: https://www.rottentomatoes.com/m/bob_marley_one_love?cmp=Trailers_YouTube_Desc 
► Learn more about Shirley: https://www.rottentomatoes.com/m/shirley?cmp=Trailers_YouTube_Desc 
► Learn more about Challengers: https://www.rottentomatoes.com/m/challengers_2023?cmp=Trailers_YouTube_Desc 
► Learn more about Bad Boys 4: https://www.rottentomatoes.com/m/bad_boys_4?cmp=Trailers_YouTube_Desc 
► Learn more about Beverly Hills Cop: Axel F: https://www.rottentomatoes.com/m/beverly_hills_cop_axel_f_2024?cmp=Trailers_YouTube_Desc 
► L

## The Zone of Interest Exclusive Featurette - A Rare Perspective (2023)
 - [https://www.youtube.com/watch?v=dTh5Nui_jFg](https://www.youtube.com/watch?v=dTh5Nui_jFg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-02-01T17:00:24+00:00

Check out an Official Behind the Scenes for The Zone of Interest starring Christian Friedel! 

► Buy Tickets for The Zone of Interest: https://www.fandango.com/the-zone-of-interest-2023-231849/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: December 15, 2023
Starring: Christian Friedel, Medusa Knopf, Sandra Hüller
Director: Jonathan Glazer
Synopsis: The commandant of Auschwitz, Rudolf Höss, and his wife, Hedwig, strive to build a dream life for their family in a house and garden next to the camp.

► Learn more: https://www.rottentomatoes.com/m/the_zone_of_interest?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten T

## Dune: Part Two Featurette - Austin Butler is Feyd-Rautha (2024)
 - [https://www.youtube.com/watch?v=VFpf7Ax6tpw](https://www.youtube.com/watch?v=VFpf7Ax6tpw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2024-02-01T16:15:56+00:00

Check out an official behind the scenes featurette for Dune: Part Two starring Austin Butler! 

► Buy Tickets for Dune: Part Two: https://www.fandango.com/dune-part-two-2024-231634/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: March 1, 2024
Starring: Timothée Chalamet, Zendaya, Florence Pugh, Austin Butler
Director: Denis Villeneuve
Synopsis: Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family. Facing a choice between the love of his life and the fate of the universe, he must prevent a terrible future only he can foresee.

► Learn more: https://www.rottentomatoes.com/m/dune_part_two?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Tra

