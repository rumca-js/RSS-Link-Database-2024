# Source:BOOK RIOT, URL:https://bookriot.com/feed, language:en-US

## 100 of the Most Popular Romances of the Past 3 Years, According to Goodreads
 - [https://bookriot.com/100-of-the-most-popular-romances-of-the-past-3-years-according-to-goodreads](https://bookriot.com/100-of-the-most-popular-romances-of-the-past-3-years-according-to-goodreads)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-01T20:37:12+00:00

Romance readers, how many of these have you read, and which are you adding to the TBR?

## Book Riot’s Deals of the Day for February 1, 2024
 - [https://bookriot.com/book-riots-deals-of-the-day-for-february-1-2024](https://bookriot.com/book-riots-deals-of-the-day-for-february-1-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-01T16:05:59+00:00

A journey through the American South, braving a haunted house, a touch of plant magic, and more of today's best book deals.

## Social Scheduling Test
 - [https://bookriot.com/social-scheduling-test](https://bookriot.com/social-scheduling-test)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-01T14:00:00+00:00

Is the caption working?

## What are You Reading This Week — February 1, 2024
 - [https://bookriot.com/read-harder-updates-february-1-2024](https://bookriot.com/read-harder-updates-february-1-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-01T14:00:00+00:00

What's your favorite read of the year so far?

## The Most Underrated Sci-Fi Books on Goodreads
 - [https://bookriot.com/underrated-sci-fi-books](https://bookriot.com/underrated-sci-fi-books)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-01T12:00:00+00:00

Which sci-fi book do you think is criminally underrated?

## The Books Must Flow: 8 Rad New SFF Books Out February 2024
 - [https://bookriot.com/new-sci-fi-and-fantasy-books-february-2024](https://bookriot.com/new-sci-fi-and-fantasy-books-february-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-01T11:30:00+00:00

Curl up with the magic, robots, supernatural creatures, fantasy, and more in these new SFF books out this month!

## 12 New Mystery & Thriller Books Out February 2024
 - [https://bookriot.com/new-mystery-thriller-books-february-2024](https://bookriot.com/new-mystery-thriller-books-february-2024)
 - RSS feed: https://bookriot.com/feed
 - date published: 2024-02-01T11:00:00+00:00

Armchair sleuth and armchair travel with these new mystery and thriller books!

