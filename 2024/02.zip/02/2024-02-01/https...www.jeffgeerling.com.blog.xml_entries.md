# Source:Jeff Geerling's Blog, URL:https://www.jeffgeerling.com/blog.xml, language:en

## SimpliSafe Video Doorbell: Halt and Catch Fire
 - [https://www.jeffgeerling.com/blog/2024/simplisafe-video-doorbell-halt-and-catch-fire](https://www.jeffgeerling.com/blog/2024/simplisafe-video-doorbell-halt-and-catch-fire)
 - RSS feed: https://www.jeffgeerling.com/blog.xml
 - date published: 2024-02-01T15:00:55+00:00

<span class="field field--name-title field--type-string field--label-hidden">SimpliSafe Video Doorbell: Halt and Catch Fire</span>

            <div class="clearfix text-formatted field field--name-body field--type-text-with-summary field--label-hidden field__item"><p><img alt="SimpliSafe Video Doorbell Pro burnt wires" class="insert-image" height="auto" src="https://www.jeffgeerling.com/sites/default/files/images/simplisafe-video-doorbell-burnt-wires.jpg" width="700" /></p>

<p>This SimpliSafe doorbell burned up less than a week after I installed it. I never would've thought a doorbell would be the most dangerous thing I set up at my studio!</p>

<p>I learned a LOT about powering 'smart' doorbells, and talked directly to SimpliSafe about it. They did sent a replacement, but it has it's own problems.</p>

<p>I'm still happy with SimpliSafe overall, but I don't like how I've spent about 8 hours troubleshooting a 'smart' doorbell. The only thing that's been 100% reliable on thi

