# Source:3D Printing, URL:https://www.reddit.com/r/3Dprinting/.rss, language:en

## It's My Cake Day 🍰 - 30 Days Of Free OctoEverywhere Supporter Perks For Everyone!
 - [https://www.reddit.com/r/3Dprinting/comments/1agmkns/its_my_cake_day_30_days_of_free_octoeverywhere](https://www.reddit.com/r/3Dprinting/comments/1agmkns/its_my_cake_day_30_days_of_free_octoeverywhere)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T21:45:31+00:00

<!-- SC_OFF --><div class="md"><p>It's my Reddit cake day today... I would do something fun... so I'm giving away 30 days of free OctoEverywhere Supporter Perks for everyone! 🥳</p> <p>👉 <a href="https://octoeverywhere.com/welcome?id=reddit_cake_day">Use this special link to get your 30 days of free Supporter Perks now!</a> The free Supporter Perks will work for everyone, new and existing users!</p> <p><a href="https://octoeverywhere.com/welcome?id=reddit_cake_day">OctoEverywhere.com</a> is a maker community project that supports <strong>all Klipper and OctoPrint</strong> <strong>3D printers.</strong> We level-up the community with:</p> <ul> <li>Free &amp; Unlimited Full Website Remote Access </li> <li>Free &amp; Unlimited AI Print Failure Detection</li> <li>Full-Framerate Webcam Streaming</li> <li>Android and iOS 3rd-Party App Remote Access</li> <li>Real-Time Printer Notifications to Telegram, Discord, SMS, and more</li> <li>Android and iOS 3rd-Party App Remote Access</li> <l

## Sculpture I just finished printing. How would you clean it up?
 - [https://www.reddit.com/r/3Dprinting/comments/1aglk7h/sculpture_i_just_finished_printing_how_would_you](https://www.reddit.com/r/3Dprinting/comments/1aglk7h/sculpture_i_just_finished_printing_how_would_you)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T21:02:18+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1aglk7h/sculpture_i_just_finished_printing_how_would_you/"> <img alt="Sculpture I just finished printing. How would you clean it up?" src="https://preview.redd.it/h7wtk9f5g1gc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2661b1be0d17543a6626db21f814514fbf964535" title="Sculpture I just finished printing. How would you clean it up?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hey all! Super stoked to share this sculpture I just finished printing, all I feel like I need to do is some slight sanding on the stringing that occurred under the left arm, as I did not think to manually add supports to that part- any tips on post processing?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/icediosa"> /u/icediosa </a> <br /> <span><a href="https://i.redd.it/h7wtk9f5g1gc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1aglk7

## Skulls will always be fun to make from scratch and to 3D print 💀
 - [https://www.reddit.com/r/3Dprinting/comments/1agl49p/skulls_will_always_be_fun_to_make_from_scratch](https://www.reddit.com/r/3Dprinting/comments/1agl49p/skulls_will_always_be_fun_to_make_from_scratch)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T20:44:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agl49p/skulls_will_always_be_fun_to_make_from_scratch/"> <img alt="Skulls will always be fun to make from scratch and to 3D print 💀" src="https://preview.redd.it/8jichkxwc1gc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c99ca1e88c07066d8674cf0ee90f11eb6fb34ae5" title="Skulls will always be fun to make from scratch and to 3D print 💀" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Made in Zbrush and printed in resin, then casted in resin and painted with wood stain, my fav so far 😁</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/chazzdurden"> /u/chazzdurden </a> <br /> <span><a href="https://i.redd.it/8jichkxwc1gc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agl49p/skulls_will_always_be_fun_to_make_from_scratch/">[comments]</a></span> </td></tr></table>

## An attempt to keep the cat's water dish from tipping over
 - [https://www.reddit.com/r/3Dprinting/comments/1agkgms/an_attempt_to_keep_the_cats_water_dish_from](https://www.reddit.com/r/3Dprinting/comments/1agkgms/an_attempt_to_keep_the_cats_water_dish_from)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T20:16:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agkgms/an_attempt_to_keep_the_cats_water_dish_from/"> <img alt="An attempt to keep the cat's water dish from tipping over" src="https://preview.redd.it/t7qcmnj181gc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1cb357c6e06332e60903949414f4f5950ef574ed" title="An attempt to keep the cat's water dish from tipping over" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/stinkytootz"> /u/stinkytootz </a> <br /> <span><a href="https://i.redd.it/t7qcmnj181gc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agkgms/an_attempt_to_keep_the_cats_water_dish_from/">[comments]</a></span> </td></tr></table>

## If you're going to steal, don't be so lazy about it
 - [https://www.reddit.com/r/3Dprinting/comments/1agj9mu/if_youre_going_to_steal_dont_be_so_lazy_about_it](https://www.reddit.com/r/3Dprinting/comments/1agj9mu/if_youre_going_to_steal_dont_be_so_lazy_about_it)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T19:26:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agj9mu/if_youre_going_to_steal_dont_be_so_lazy_about_it/"> <img alt="If you're going to steal, don't be so lazy about it" src="https://b.thumbs.redditmedia.com/ZLDOZJywerBxhQei0DYvc59FVyPQDVCxYj4w24E6Vws.jpg" title="If you're going to steal, don't be so lazy about it" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jankmartofficial"> /u/jankmartofficial </a> <br /> <span><a href="https://www.reddit.com/gallery/1agj9mu">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agj9mu/if_youre_going_to_steal_dont_be_so_lazy_about_it/">[comments]</a></span> </td></tr></table>

## Johnny 5 on mp mini v2
 - [https://www.reddit.com/r/3Dprinting/comments/1agh8jd/johnny_5_on_mp_mini_v2](https://www.reddit.com/r/3Dprinting/comments/1agh8jd/johnny_5_on_mp_mini_v2)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T18:02:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agh8jd/johnny_5_on_mp_mini_v2/"> <img alt="Johnny 5 on mp mini v2" src="https://preview.redd.it/6isdjj83k0gc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=798ce06de4443077fef6e6cb0deba3a9709cc49f" title="Johnny 5 on mp mini v2" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CallIntelligent9274"> /u/CallIntelligent9274 </a> <br /> <span><a href="https://i.redd.it/6isdjj83k0gc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agh8jd/johnny_5_on_mp_mini_v2/">[comments]</a></span> </td></tr></table>

## Bionicle Stls?
 - [https://www.reddit.com/r/3Dprinting/comments/1agh1dz/bionicle_stls](https://www.reddit.com/r/3Dprinting/comments/1agh1dz/bionicle_stls)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T17:54:01+00:00

<!-- SC_OFF --><div class="md"><p>Anybody know where I can find most of the Lego Bionicle models to print?</p> <p>Saw them a while ago but forgot where they were from and can't seem to find them again for some reason</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SkysThLimit"> /u/SkysThLimit </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agh1dz/bionicle_stls/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agh1dz/bionicle_stls/">[comments]</a></span>

## Looking to get a dissolvable filament to use for supports, any suggestions/thoughts/things I should know going in?
 - [https://www.reddit.com/r/3Dprinting/comments/1aggfdw/looking_to_get_a_dissolvable_filament_to_use_for](https://www.reddit.com/r/3Dprinting/comments/1aggfdw/looking_to_get_a_dissolvable_filament_to_use_for)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T17:28:20+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Root720"> /u/Root720 </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1aggfdw/looking_to_get_a_dissolvable_filament_to_use_for/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1aggfdw/looking_to_get_a_dissolvable_filament_to_use_for/">[comments]</a></span>

## 3d Printed excavator WIP
 - [https://www.reddit.com/r/3Dprinting/comments/1agg5dz/3d_printed_excavator_wip](https://www.reddit.com/r/3Dprinting/comments/1agg5dz/3d_printed_excavator_wip)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T17:16:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agg5dz/3d_printed_excavator_wip/"> <img alt="3d Printed excavator WIP" src="https://external-preview.redd.it/ZTN0bHd1Y3diMGdjMR4aIXk7IIKzB8c-0hXvTn3AB3g-YY11mO7uQy2en604.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=e331ff2584d910df4a9ca69f049fe4fbf3aa7c55" title="3d Printed excavator WIP" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Bugilt"> /u/Bugilt </a> <br /> <span><a href="https://v.redd.it/mciwpvm7a0gc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agg5dz/3d_printed_excavator_wip/">[comments]</a></span> </td></tr></table>

## bottle cap tripod
 - [https://www.reddit.com/r/3Dprinting/comments/1ageqoj/bottle_cap_tripod](https://www.reddit.com/r/3Dprinting/comments/1ageqoj/bottle_cap_tripod)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T16:18:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ageqoj/bottle_cap_tripod/"> <img alt="bottle cap tripod" src="https://preview.redd.it/bt6bylk300gc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e8574f5f0f7c1a5c6363db72cf144452766e895b" title="bottle cap tripod" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/unwohlpol"> /u/unwohlpol </a> <br /> <span><a href="https://i.redd.it/bt6bylk300gc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ageqoj/bottle_cap_tripod/">[comments]</a></span> </td></tr></table>

## "Bite my shiny metal ass" I don't need supports!
 - [https://www.reddit.com/r/3Dprinting/comments/1agepz8/bite_my_shiny_metal_ass_i_dont_need_supports](https://www.reddit.com/r/3Dprinting/comments/1agepz8/bite_my_shiny_metal_ass_i_dont_need_supports)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T16:17:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agepz8/bite_my_shiny_metal_ass_i_dont_need_supports/"> <img alt="&quot;Bite my shiny metal ass&quot; I don't need supports!" src="https://b.thumbs.redditmedia.com/HLvjdJanfrqvbYhjk2odAw07n1-rhre0gq8gTZCjlZo.jpg" title="&quot;Bite my shiny metal ass&quot; I don't need supports!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WhoKnowsWho2"> /u/WhoKnowsWho2 </a> <br /> <span><a href="https://www.reddit.com/gallery/1agepz8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agepz8/bite_my_shiny_metal_ass_i_dont_need_supports/">[comments]</a></span> </td></tr></table>

## When you can't print faster... It was a little challenging to get TWO perfect first layers at the same time, but now it looks oddly satisfying.
 - [https://www.reddit.com/r/3Dprinting/comments/1agdqz4/when_you_cant_print_faster_it_was_a_little](https://www.reddit.com/r/3Dprinting/comments/1agdqz4/when_you_cant_print_faster_it_was_a_little)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T15:35:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agdqz4/when_you_cant_print_faster_it_was_a_little/"> <img alt="When you can't print faster... It was a little challenging to get TWO perfect first layers at the same time, but now it looks oddly satisfying." src="https://external-preview.redd.it/cXBpdnhpYnZ0emZjMX5rAcNrIwOvs966FdfNPH2Au8YB0gqvbQGVp4A3agFe.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=a57da24ce64c603fe77058c6f9d21beb0b64ada3" title="When you can't print faster... It was a little challenging to get TWO perfect first layers at the same time, but now it looks oddly satisfying." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/unique-constraint"> /u/unique-constraint </a> <br /> <span><a href="https://v.redd.it/83kdy79jtzfc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agdqz4/when_you_cant_print_faster_it_was_a_little/">[comments]</a></span> </td></tr></table>

## I made a giant banana costume for my giant Lego mini-me (details in comments)
 - [https://www.reddit.com/r/3Dprinting/comments/1agcw2t/i_made_a_giant_banana_costume_for_my_giant_lego](https://www.reddit.com/r/3Dprinting/comments/1agcw2t/i_made_a_giant_banana_costume_for_my_giant_lego)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T14:57:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agcw2t/i_made_a_giant_banana_costume_for_my_giant_lego/"> <img alt="I made a giant banana costume for my giant Lego mini-me (details in comments)" src="https://external-preview.redd.it/eWZ3M2QxNzRuemZjMYdhXTZ4Z0pD6socEFmopaduXbkFczw2IFh5jXeKw4Kk.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=aa2ae1f9d5d8ba800c5386a8d77d9e11392ffaf9" title="I made a giant banana costume for my giant Lego mini-me (details in comments)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FabienPohl"> /u/FabienPohl </a> <br /> <span><a href="https://v.redd.it/ugs77gaikzfc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agcw2t/i_made_a_giant_banana_costume_for_my_giant_lego/">[comments]</a></span> </td></tr></table>

## How large of an FDM printer is practically possible?
 - [https://www.reddit.com/r/3Dprinting/comments/1agcuy3/how_large_of_an_fdm_printer_is_practically](https://www.reddit.com/r/3Dprinting/comments/1agcuy3/how_large_of_an_fdm_printer_is_practically)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T14:56:18+00:00

<!-- SC_OFF --><div class="md"><p>Through chance encounter I've acquired a pallet of aluminum extrusions (mostly 100x100mm, but also some 50x50mm, up to 10ft long), as well as some 8ft long linear rails. I bought them just to be used as a racking/storage system in my shop, but the gears are turning...</p> <p>I'm thinking a bed size of 6ft x 3ft, and perhaps 2ft tall? I'm sure my print times will be massive, but I'm patient. </p> <p>Heating the bed will be a challenge. I suspect that with a 220v circuit it might be possible, but I'm thinking that circulating water through a big plate might be better as it could be powered by a natural gas burner and help maintain an even heat? Either way, I think this is a hurdle I can navigate.</p> <p>More practically, what are the limits of warping over a large area? The forces the bed must withstand will be huge! I see that a large number of commercial printers are in the 3ft x 3ft to 5ft x 5ft bed size range... Is this warp force the reaso

## Got back into magic the gathering! Went alittle to hard..
 - [https://www.reddit.com/r/3Dprinting/comments/1agc4ku/got_back_into_magic_the_gathering_went_alittle_to](https://www.reddit.com/r/3Dprinting/comments/1agc4ku/got_back_into_magic_the_gathering_went_alittle_to)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T14:22:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agc4ku/got_back_into_magic_the_gathering_went_alittle_to/"> <img alt="Got back into magic the gathering! Went alittle to hard.." src="https://a.thumbs.redditmedia.com/QHwuJzbsEOYoOeRENRrV0I_vL04WyxQHYGPUsBaYQe0.jpg" title="Got back into magic the gathering! Went alittle to hard.." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/omalike"> /u/omalike </a> <br /> <span><a href="https://www.reddit.com/gallery/1agc4ku">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agc4ku/got_back_into_magic_the_gathering_went_alittle_to/">[comments]</a></span> </td></tr></table>

## Update on my Diamondback Nozzle Experience
 - [https://www.reddit.com/r/3Dprinting/comments/1agaqgu/update_on_my_diamondback_nozzle_experience](https://www.reddit.com/r/3Dprinting/comments/1agaqgu/update_on_my_diamondback_nozzle_experience)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T13:15:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agaqgu/update_on_my_diamondback_nozzle_experience/"> <img alt="Update on my Diamondback Nozzle Experience" src="https://external-preview.redd.it/Lp3_H24jdxTLWU-Amz191e7bWJy3d_C2gRfHAIZ3YQI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3325430aaddf32407852588b4d9e94c27ab69dce" title="Update on my Diamondback Nozzle Experience" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><strong>The Short TLDR Version</strong></p> <p>I had responded to a post a while back here which gathered a lot of views and attention. I thought it only fair to US Synthetic (the makers of Diamondback nozzles) to provide an update.</p> <p>US Synthetic offered to replace my out-of-spec nozzle free of charge without me asking, and upon installation of the replacement nozzle, the printing results are essentially as good as I could have ever hoped for. I am incredibly thankful to US Synthetic for looking after me and they've earned 

## 3D printed bench ? - Qatar
 - [https://www.reddit.com/r/3Dprinting/comments/1agahlt/3d_printed_bench_qatar](https://www.reddit.com/r/3Dprinting/comments/1agahlt/3d_printed_bench_qatar)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T13:02:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1agahlt/3d_printed_bench_qatar/"> <img alt="3D printed bench ? - Qatar" src="https://a.thumbs.redditmedia.com/iup1nD3-wuVoSJ7nA_iczaDT2P7ymVY4KayaNLz4nM8.jpg" title="3D printed bench ? - Qatar" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Seen this at the Doha expo. Is this 3D printed ? If so, what type of monster use nozzle this big ?</p> <p>I would imagine that the layering is a feature that they were looking for. </p> <p>On a side note, very comfortable and pretty cool to shill with your neighbour. </p> <p>What do you think ?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Billourabbit"> /u/Billourabbit </a> <br /> <span><a href="https://www.reddit.com/gallery/1agahlt">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1agahlt/3d_printed_bench_qatar/">[comments]</a></span> </td></tr></table>

## Stormtrooper helmet
 - [https://www.reddit.com/r/3Dprinting/comments/1aga2ju/stormtrooper_helmet](https://www.reddit.com/r/3Dprinting/comments/1aga2ju/stormtrooper_helmet)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T12:40:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1aga2ju/stormtrooper_helmet/"> <img alt="Stormtrooper helmet" src="https://b.thumbs.redditmedia.com/wdS74LZfqm4ZA8HI_kmFeroFZAWLEgVsb0-jBv8Uzzc.jpg" title="Stormtrooper helmet" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LisaSithStudio"> /u/LisaSithStudio </a> <br /> <span><a href="https://www.reddit.com/gallery/1aga2ju">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1aga2ju/stormtrooper_helmet/">[comments]</a></span> </td></tr></table>

## Quick checking of different layer heights
 - [https://www.reddit.com/r/3Dprinting/comments/1aga2fx/quick_checking_of_different_layer_heights](https://www.reddit.com/r/3Dprinting/comments/1aga2fx/quick_checking_of_different_layer_heights)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T12:40:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1aga2fx/quick_checking_of_different_layer_heights/"> <img alt="Quick checking of different layer heights" src="https://b.thumbs.redditmedia.com/H3VnoK3d2kjz-Rt7JAy2ep9kFJWTBfuotmw-b57AyOA.jpg" title="Quick checking of different layer heights" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SoerenHaraldsson"> /u/SoerenHaraldsson </a> <br /> <span><a href="https://www.reddit.com/gallery/1aga2fx">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1aga2fx/quick_checking_of_different_layer_heights/">[comments]</a></span> </td></tr></table>

## Maybe 500mms was a bit too big. Any advice for this?
 - [https://www.reddit.com/r/3Dprinting/comments/1ag9p7p/maybe_500mms_was_a_bit_too_big_any_advice_for_this](https://www.reddit.com/r/3Dprinting/comments/1ag9p7p/maybe_500mms_was_a_bit_too_big_any_advice_for_this)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T12:19:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag9p7p/maybe_500mms_was_a_bit_too_big_any_advice_for_this/"> <img alt="Maybe 500mms was a bit too big. Any advice for this?" src="https://a.thumbs.redditmedia.com/9L9Glrgnd9Tr6IhVqYDTvLXbt4o6otrQYD3iiw3Trg8.jpg" title="Maybe 500mms was a bit too big. Any advice for this?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GayRacoon69"> /u/GayRacoon69 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ag9p7p">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag9p7p/maybe_500mms_was_a_bit_too_big_any_advice_for_this/">[comments]</a></span> </td></tr></table>

## First Print
 - [https://www.reddit.com/r/3Dprinting/comments/1ag8sqb/first_print](https://www.reddit.com/r/3Dprinting/comments/1ag8sqb/first_print)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T11:24:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag8sqb/first_print/"> <img alt="First Print" src="https://preview.redd.it/2f220ip0lyfc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=da17bb9466141db05eb72a24d8efe74cb79a6ea0" title="First Print" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Just got my first 3d printer (Prusa Mini+), and just printed benchy. Besides for the stringing I'm happy with it, especially for my first print. Although I can remove them, does anyone have any tips to reduce this? Thanks</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Tomb_747"> /u/Tomb_747 </a> <br /> <span><a href="https://i.redd.it/2f220ip0lyfc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag8sqb/first_print/">[comments]</a></span> </td></tr></table>

## Hey guys I’m trying to create a plug for a car. But something isn’t right
 - [https://www.reddit.com/r/3Dprinting/comments/1ag86xp/hey_guys_im_trying_to_create_a_plug_for_a_car_but](https://www.reddit.com/r/3Dprinting/comments/1ag86xp/hey_guys_im_trying_to_create_a_plug_for_a_car_but)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T10:44:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag86xp/hey_guys_im_trying_to_create_a_plug_for_a_car_but/"> <img alt="Hey guys I’m trying to create a plug for a car. But something isn’t right" src="https://a.thumbs.redditmedia.com/E1CnPl_gKI7JdCclePqRIrpVTAftfwZ1jpz9L0T6fZ0.jpg" title="Hey guys I’m trying to create a plug for a car. But something isn’t right" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Hey guys I’m trying to create a plug for a car. But the pins won’t fit inside the plug I made. Any ideas on what I’m doing wrong here</p> <p>First picture is the measurement of a pin. The second is the width of the hole in the plug.</p> <p>The white plug is what I’m trying to make and the black one is the one I have printed. The picture shows the pin not fitting in</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Few-Pie-8141"> /u/Few-Pie-8141 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ag86xp"

## Gfsarthklgcdghj!
 - [https://www.reddit.com/r/3Dprinting/comments/1ag836f/gfsarthklgcdghj](https://www.reddit.com/r/3Dprinting/comments/1ag836f/gfsarthklgcdghj)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T10:37:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag836f/gfsarthklgcdghj/"> <img alt="Gfsarthklgcdghj!" src="https://preview.redd.it/hujj1lspcyfc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0746f17af49b7580a2a33ffd2b39f36610861e36" title="Gfsarthklgcdghj!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>“Without disappointment you cannot appreciate victory” -Memphis Raines</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Remmandave"> /u/Remmandave </a> <br /> <span><a href="https://i.redd.it/hujj1lspcyfc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag836f/gfsarthklgcdghj/">[comments]</a></span> </td></tr></table>

## User sees someone else's camera.
 - [https://www.reddit.com/r/3Dprinting/comments/1ag77ks/user_sees_someone_elses_camera](https://www.reddit.com/r/3Dprinting/comments/1ag77ks/user_sees_someone_elses_camera)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T09:33:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag77ks/user_sees_someone_elses_camera/"> <img alt="User sees someone else's camera." src="https://preview.redd.it/d7y7eljb1yfc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=01c98a207b17e1d84eb32be20f52d5c90a48a007" title="User sees someone else's camera." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Saw this in a group on FB. User opens up A1 camera and sees someone else's printer. Lmaoo.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/allusernamearetaken3"> /u/allusernamearetaken3 </a> <br /> <span><a href="https://i.redd.it/d7y7eljb1yfc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag77ks/user_sees_someone_elses_camera/">[comments]</a></span> </td></tr></table>

## Non-planar Continous Fiber FFF 3D Printing
 - [https://www.reddit.com/r/3Dprinting/comments/1ag5xp2/nonplanar_continous_fiber_fff_3d_printing](https://www.reddit.com/r/3Dprinting/comments/1ag5xp2/nonplanar_continous_fiber_fff_3d_printing)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T08:02:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag5xp2/nonplanar_continous_fiber_fff_3d_printing/"> <img alt="Non-planar Continous Fiber FFF 3D Printing" src="https://external-preview.redd.it/cjY5dzE5endreGZjMdVMX79LKDIwU8p0ThbqKOLeYbezbWHaYCQsFGgqjB2X.png?width=140&amp;height=78&amp;crop=140:78,smart&amp;format=jpg&amp;v=enabled&amp;lthumb=true&amp;s=d32187d7899ffd707a14304348bc482dd0978d7a" title="Non-planar Continous Fiber FFF 3D Printing" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/3DPrintingBootcamp"> /u/3DPrintingBootcamp </a> <br /> <span><a href="https://v.redd.it/rncn6nrskxfc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag5xp2/nonplanar_continous_fiber_fff_3d_printing/">[comments]</a></span> </td></tr></table>

## Another boat WIP, that was pictured in my last post. The Flying Dutchman!
 - [https://www.reddit.com/r/3Dprinting/comments/1ag59zu/another_boat_wip_that_was_pictured_in_my_last](https://www.reddit.com/r/3Dprinting/comments/1ag59zu/another_boat_wip_that_was_pictured_in_my_last)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T07:17:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag59zu/another_boat_wip_that_was_pictured_in_my_last/"> <img alt="Another boat WIP, that was pictured in my last post. The Flying Dutchman!" src="https://external-preview.redd.it/OWt0dTUxZzJkeGZjMahKU3kSEBn1WxQltApxhpQRauojp2a6j1gHMjPIUxbt.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=26b0266e3b322d4c4c0a63e54861f4d774fd6255" title="Another boat WIP, that was pictured in my last post. The Flying Dutchman!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DiegoSwell"> /u/DiegoSwell </a> <br /> <span><a href="https://v.redd.it/2jx6ksyxcxfc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag59zu/another_boat_wip_that_was_pictured_in_my_last/">[comments]</a></span> </td></tr></table>

## Recreating classic Atari titles in 3D
 - [https://www.reddit.com/r/3Dprinting/comments/1ag55wg/recreating_classic_atari_titles_in_3d](https://www.reddit.com/r/3Dprinting/comments/1ag55wg/recreating_classic_atari_titles_in_3d)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T07:09:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag55wg/recreating_classic_atari_titles_in_3d/"> <img alt="Recreating classic Atari titles in 3D" src="https://b.thumbs.redditmedia.com/mjI_LBlECXss6R0IZrtgCWpOEHzOdlsP7eG4MXu2mBI.jpg" title="Recreating classic Atari titles in 3D" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DirectedEvolution"> /u/DirectedEvolution </a> <br /> <span><a href="https://www.reddit.com/gallery/1ag55wg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag55wg/recreating_classic_atari_titles_in_3d/">[comments]</a></span> </td></tr></table>

## Raspberry pi 4 Case
 - [https://www.reddit.com/r/3Dprinting/comments/1ag4rsk/raspberry_pi_4_case](https://www.reddit.com/r/3Dprinting/comments/1ag4rsk/raspberry_pi_4_case)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T06:43:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag4rsk/raspberry_pi_4_case/"> <img alt="Raspberry pi 4 Case" src="https://a.thumbs.redditmedia.com/hub9kYHQ7bHubQcfuoU908HpNBX1HBr21xcsIeCnhp4.jpg" title="Raspberry pi 4 Case" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><a href="https://www.printables.com/model/367187-raspberry-pi-4-case">https://www.printables.com/model/367187-raspberry-pi-4-case</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sandy_SN"> /u/Sandy_SN </a> <br /> <span><a href="https://www.reddit.com/gallery/1ag4rsk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag4rsk/raspberry_pi_4_case/">[comments]</a></span> </td></tr></table>

## The desiccant pouch is officially a pouch
 - [https://www.reddit.com/r/3Dprinting/comments/1ag4ogc/the_desiccant_pouch_is_officially_a_pouch](https://www.reddit.com/r/3Dprinting/comments/1ag4ogc/the_desiccant_pouch_is_officially_a_pouch)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T06:37:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag4ogc/the_desiccant_pouch_is_officially_a_pouch/"> <img alt="The desiccant pouch is officially a pouch" src="https://a.thumbs.redditmedia.com/8zS0V-Arvo_O7pJASS5c-lOepaXuzU4_8X8e9kvLAr0.jpg" title="The desiccant pouch is officially a pouch" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Airy, flexible, and surprisingly resilient. By leveraiging zero top and bottom layers, and using sparse infill for holes, optimized the print to 7g PLA, 17 minutes printing time. </p> <p>The updated zip-tie-like belt locks the lids securely to ensure no leaks. Reinforced lids provide just enough structural integrity. </p> <p>This is getting close to the most optimized form in my mind.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JuxQ20"> /u/JuxQ20 </a> <br /> <span><a href="https://www.reddit.com/gallery/1ag4ogc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r

## Actual, true pain.(left a print without setting up octoprint
 - [https://www.reddit.com/r/3Dprinting/comments/1ag3vh5/actual_true_painleft_a_print_without_setting_up](https://www.reddit.com/r/3Dprinting/comments/1ag3vh5/actual_true_painleft_a_print_without_setting_up)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T05:48:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag3vh5/actual_true_painleft_a_print_without_setting_up/"> <img alt="Actual, true pain.(left a print without setting up octoprint" src="https://preview.redd.it/kt5a0t15xwfc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=30870bfd78079d5c4b8c4e82db7ce218cffd0b8e" title="Actual, true pain.(left a print without setting up octoprint" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/freebird023"> /u/freebird023 </a> <br /> <span><a href="https://i.redd.it/kt5a0t15xwfc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag3vh5/actual_true_painleft_a_print_without_setting_up/">[comments]</a></span> </td></tr></table>

## I thought my 3d printers were breaking
 - [https://www.reddit.com/r/3Dprinting/comments/1ag35dk/i_thought_my_3d_printers_were_breaking](https://www.reddit.com/r/3Dprinting/comments/1ag35dk/i_thought_my_3d_printers_were_breaking)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T05:07:04+00:00

<!-- SC_OFF --><div class="md"><p>I’ve had so many failed prints from both my ended three and my maker select v2 that I was about to quit the hobby all together.</p> <p>-I’d leveled my bed after every failed print.</p> <p>-I would mess with cuts setting going slower and slower for more quality and trying to succeed.</p> <p>-I tried multiple different rolls thinking it’s the filament I bought were at fault fault.</p> <p>-tightened and loosened belt tensions</p> <p>-all my benchys would succeed would sit and watch them the whole time no problems. </p> <p>I felt comfortable after all that to leave a long print to run over night and, BOOM another failed print spaghetti pla everywhere.</p> <p>Until finally I was sitting in my room with the printer while trying to print another benchy test late at night when it happened both my cats get zoomies chase each other and the one being chased immediately jumps in between the printer not hitting them but shaking the table enough for the pr

## Purchase Advice Megathread - February 2024
 - [https://www.reddit.com/r/3Dprinting/comments/1ag31n4/purchase_advice_megathread_february_2024](https://www.reddit.com/r/3Dprinting/comments/1ag31n4/purchase_advice_megathread_february_2024)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T05:01:30+00:00

<!-- SC_OFF --><div class="md"><p>Welcome back to another purchase megathread!</p> <p>This thread is meant to conglomerate purchase advice for both newcomers and people looking for additional machines. Keeping this discussion to one thread means less searching should anyone have questions that may already have been answered here, as well as more visibility to inquiries in general, as comments made here will be visible for the entire month stuck to the top of the sub, and then added to the Purchase Advice Collection (Reddit Collections are still broken on mobile view, enable &quot;view in desktop mode&quot;).</p> <p><strong>Please be sure to skim through this thread</strong> for posts with similar requirements to your own first, as recommendations relevant to your situation may have already been posted, and may even include answers to follow up questions you might have wished to ask. </p> <p>If you are new to 3D printing, and are unsure of what to ask, try to include the follo

## Some of y’all requested the STL for this when I first shared it.
 - [https://www.reddit.com/r/3Dprinting/comments/1ag23mw/some_of_yall_requested_the_stl_for_this_when_i](https://www.reddit.com/r/3Dprinting/comments/1ag23mw/some_of_yall_requested_the_stl_for_this_when_i)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T04:10:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag23mw/some_of_yall_requested_the_stl_for_this_when_i/"> <img alt="Some of y’all requested the STL for this when I first shared it." src="https://external-preview.redd.it/M2Nqanh0bThmd2ZjMUsAalq_pNPDwAWX-vxH4TVjf32ot0ZOw8Qa6e3HD7Tg.png?width=140&amp;height=140&amp;crop=140:140,smart&amp;format=jpg&amp;v=enabled&amp;lthumb=true&amp;s=731e7dfbb7f1e91cf107e92b484eb390d8a9b85c" title="Some of y’all requested the STL for this when I first shared it." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/K_Prints3D"> /u/K_Prints3D </a> <br /> <span><a href="https://v.redd.it/w824dbo8fwfc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag23mw/some_of_yall_requested_the_stl_for_this_when_i/">[comments]</a></span> </td></tr></table>

## Lego inspired X-Wing
 - [https://www.reddit.com/r/3Dprinting/comments/1ag1aeh/lego_inspired_xwing](https://www.reddit.com/r/3Dprinting/comments/1ag1aeh/lego_inspired_xwing)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T03:29:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1ag1aeh/lego_inspired_xwing/"> <img alt="Lego inspired X-Wing" src="https://preview.redd.it/fhe7icc98wfc1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ee7a6ae22f9de4e3f4613c74cdfae55eed1d406a" title="Lego inspired X-Wing" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Original design. 20+ design hours and 200+ printing hours. Printed on an Ender 3v3. Lego X-Wing for scale.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jgarrison13"> /u/jgarrison13 </a> <br /> <span><a href="https://i.redd.it/fhe7icc98wfc1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag1aeh/lego_inspired_xwing/">[comments]</a></span> </td></tr></table>

## Genuinely curious, I see alot of people deal with all sorts of problems with their printers. I have a Creality CR-10S, I have used it for about 6 years, I think I have leveled my bed like twice ever, and have never had any problems. Am I wasting all my good karma or is this fairly normal?
 - [https://www.reddit.com/r/3Dprinting/comments/1ag19in/genuinely_curious_i_see_alot_of_people_deal_with](https://www.reddit.com/r/3Dprinting/comments/1ag19in/genuinely_curious_i_see_alot_of_people_deal_with)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T03:27:54+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/sybetrunner"> /u/sybetrunner </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag19in/genuinely_curious_i_see_alot_of_people_deal_with/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag19in/genuinely_curious_i_see_alot_of_people_deal_with/">[comments]</a></span>

## Anybody else tried to distract themselves from heartbreak with printing?
 - [https://www.reddit.com/r/3Dprinting/comments/1ag0lpd/anybody_else_tried_to_distract_themselves_from](https://www.reddit.com/r/3Dprinting/comments/1ag0lpd/anybody_else_tried_to_distract_themselves_from)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T02:55:04+00:00

<!-- SC_OFF --><div class="md"><p>Just got the printer, so its my exciting new hobby. also just got broken up with. Not as exciting. But I'm in the market for sad girl files, if anybody has some they can recommend. Or any other recommendations. Its a bambu A1 with ams. And I'm still very much learning, so beginner tips specifically for my printer/ software would be great. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Mardilove"> /u/Mardilove </a> <br /> <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag0lpd/anybody_else_tried_to_distract_themselves_from/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1ag0lpd/anybody_else_tried_to_distract_themselves_from/">[comments]</a></span>

## Anyone know if there is an open source file?
 - [https://www.reddit.com/r/3Dprinting/comments/1afy94s/anyone_know_if_there_is_an_open_source_file](https://www.reddit.com/r/3Dprinting/comments/1afy94s/anyone_know_if_there_is_an_open_source_file)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T01:02:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1afy94s/anyone_know_if_there_is_an_open_source_file/"> <img alt="Anyone know if there is an open source file?" src="https://external-preview.redd.it/eTZmcjl2NzlucmZjMZ01Rn4pImUPPcfuOgyG_eFG8BNU_uvnkmgEIqfwM_U3.png?width=140&amp;height=140&amp;crop=140:140,smart&amp;format=jpg&amp;v=enabled&amp;lthumb=true&amp;s=40e1abcfb37396d515cf77d7f5acf847efb0d2d1" title="Anyone know if there is an open source file?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ayla_Leren"> /u/Ayla_Leren </a> <br /> <span><a href="https://v.redd.it/rjq3qg0anrfc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1afy94s/anyone_know_if_there_is_an_open_source_file/">[comments]</a></span> </td></tr></table>

## TIL you can just write "gucci" on things.
 - [https://www.reddit.com/r/3Dprinting/comments/1afxo27/til_you_can_just_write_gucci_on_things](https://www.reddit.com/r/3Dprinting/comments/1afxo27/til_you_can_just_write_gucci_on_things)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T00:35:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1afxo27/til_you_can_just_write_gucci_on_things/"> <img alt="TIL you can just write &quot;gucci&quot; on things." src="https://external-preview.redd.it/G5J2iT_uYiupGm6X-ro3N_SPMSFKn2Xzls1dl_-OFrs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=091613880f3901367361b921a44b21bed94d53b4" title="TIL you can just write &quot;gucci&quot; on things." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NessLeonhart"> /u/NessLeonhart </a> <br /> <span><a href="https://imgur.com/a/7BNddPN">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1afxo27/til_you_can_just_write_gucci_on_things/">[comments]</a></span> </td></tr></table>

## Maybe i should have bought a 3d printer sooner
 - [https://www.reddit.com/r/3Dprinting/comments/1afwynt/maybe_i_should_have_bought_a_3d_printer_sooner](https://www.reddit.com/r/3Dprinting/comments/1afwynt/maybe_i_should_have_bought_a_3d_printer_sooner)
 - RSS feed: https://www.reddit.com/r/3Dprinting/.rss
 - date published: 2024-02-01T00:02:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/3Dprinting/comments/1afwynt/maybe_i_should_have_bought_a_3d_printer_sooner/"> <img alt="Maybe i should have bought a 3d printer sooner" src="https://external-preview.redd.it/b3V0NGczaGY3dmZjMc0FqYqU0_KoW52sjPgf3f_9d8-mqlYVqYwedG39OBKv.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=f8c9291c5d277e771f7b10d89b8768c3b823d9dd" title="Maybe i should have bought a 3d printer sooner" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MaybeAnHVACGuy"> /u/MaybeAnHVACGuy </a> <br /> <span><a href="https://v.redd.it/n8ll1rjf7vfc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/3Dprinting/comments/1afwynt/maybe_i_should_have_bought_a_3d_printer_sooner/">[comments]</a></span> </td></tr></table>

