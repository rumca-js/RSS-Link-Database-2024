# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Szarża morskich dronów. Zatopiły rosyjski statek wart miliony
 - [https://wydarzenia.interia.pl/zagranica/news-szarza-morskich-dronow-zatopily-rosyjski-statek-wart-miliony,nId,7305621](https://wydarzenia.interia.pl/zagranica/news-szarza-morskich-dronow-zatopily-rosyjski-statek-wart-miliony,nId,7305621)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-02-01T13:00:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szarza-morskich-dronow-zatopily-rosyjski-statek-wart-miliony,nId,7305621"><img align="left" alt="Szarża morskich dronów. Zatopiły rosyjski statek wart miliony" src="https://i.iplsc.com/szarza-morskich-dronow-zatopily-rosyjski-statek-wart-miliony/000IIJN3ODU58NNB-C321.jpg" /></a>Żołnierze specjalnej grupy Wywiadu Ministerstwa Obrony Ukrainy zniszczyli łódź rakietową Iwanowiec. Okręt należał do rosyjskiej Floty Czarnomorskiej. Została zaatakowany dronami, w wyniku ostrzału i poniesionych strat zatonął. Wartość zniszczonej łodzi waha się między 60 a 70 mln dolarów. Z wstępnych informacji wynika, że misja odnalezienia wraku zakończyła się niepowodzeniem. </p><br clear="all" />

## Dymisja gen. Wałerija Załużnego "na dniach". Nowe doniesienia mediów
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dymisja-gen-walerija-zaluznego-na-dniach-nowe-doniesienia-me,nId,7305599](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dymisja-gen-walerija-zaluznego-na-dniach-nowe-doniesienia-me,nId,7305599)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-02-01T12:43:44+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dymisja-gen-walerija-zaluznego-na-dniach-nowe-doniesienia-me,nId,7305599"><img align="left" alt="Dymisja gen. Wałerija Załużnego &quot;na dniach&quot;. Nowe doniesienia mediów" src="https://i.iplsc.com/dymisja-gen-walerija-zaluznego-na-dniach-nowe-doniesienia-me/000IIJCFC8658ORT-C321.jpg" /></a>Do końca tygodnia prezydent Ukrainy oficjalnie ogłosi dymisję gen. Wałerija Załużnego - donosi CNN, powołując się na anonimowe źródła. Pierwsze pogłoski o odwołaniu głównodowodzącego ukraińskiej armii wstrząsnęły mediami w poniedziałek, ale Wołodymyr Zełenski jeszcze nie wydał dekretu w tej sprawie. Stanowisko na pewno stracił jednak inny wysoki urzędnik - szef jednego z departamentu Służby Bezpieczeństwa Ukrainy.</p><br clear="all" />

## Nieoczekiwany zwrot. Bliski partner opuszcza Putina
 - [https://wydarzenia.interia.pl/zagranica/news-nieoczekiwany-zwrot-bliski-partner-opuszcza-putina,nId,7305614](https://wydarzenia.interia.pl/zagranica/news-nieoczekiwany-zwrot-bliski-partner-opuszcza-putina,nId,7305614)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-02-01T11:38:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nieoczekiwany-zwrot-bliski-partner-opuszcza-putina,nId,7305614"><img align="left" alt="Nieoczekiwany zwrot. Bliski partner opuszcza Putina" src="https://i.iplsc.com/nieoczekiwany-zwrot-bliski-partner-opuszcza-putina/000IIIMSHQA78HTN-C321.jpg" /></a>Armenia przystąpiła w czwartek do Międzynarodowego Trybunału Karnego. Oznacza to, że od teraz dotychczasowy bliski partner Rosji podlega jurysdykcji Trybunału, który w marcu 2023 roku wydał międzynarodowy nakaz aresztowania Władimira Putina. Jeśli rosyjski przywódca chce uniknąć zatrzymania, powinien zrezygnować z podróży do tego kraju.</p><br clear="all" />

## Ujawniono majątek Orbana. Pensja rośnie, a oszczędności topnieją
 - [https://wydarzenia.interia.pl/zagranica/news-ujawniono-majatek-orbana-pensja-rosnie-a-oszczednosci-topnie,nId,7305523](https://wydarzenia.interia.pl/zagranica/news-ujawniono-majatek-orbana-pensja-rosnie-a-oszczednosci-topnie,nId,7305523)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-02-01T11:06:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ujawniono-majatek-orbana-pensja-rosnie-a-oszczednosci-topnie,nId,7305523"><img align="left" alt="Ujawniono majątek Orbana. Pensja rośnie, a oszczędności topnieją" src="https://i.iplsc.com/ujawniono-majatek-orbana-pensja-rosnie-a-oszczednosci-topnie/000IIHX5S20SYJUK-C321.jpg" /></a>Opublikowano oświadczenie majątkowe Viktora Orbana. Premier Węgier wykazał, że w ciągu roku jego oszczędności znacznie zmalały. Mimo wyższej pensji Orban zadeklarował, że w 2023 roku jego oszczędności wyniosły 10 mln forintów (113 tys. zł), podczas gdy w 2022 roku było to 14 mln forintów (158 tyz. zł). Oznacza to, że oszczędności premiera są niższe od średnich oszczędności gospodarstwa domowego na Węgrzech. </p><br clear="all" />

## Nadzwyczajna kontrola w więzieniu. Piracki sprzęt w celach
 - [https://wydarzenia.interia.pl/zagranica/news-nadzwyczajna-kontrola-w-wiezieniu-piracki-sprzet-w-celach,nId,7305439](https://wydarzenia.interia.pl/zagranica/news-nadzwyczajna-kontrola-w-wiezieniu-piracki-sprzet-w-celach,nId,7305439)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-02-01T10:05:42+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nadzwyczajna-kontrola-w-wiezieniu-piracki-sprzet-w-celach,nId,7305439"><img align="left" alt="Nadzwyczajna kontrola w więzieniu. Piracki sprzęt w celach" src="https://i.iplsc.com/nadzwyczajna-kontrola-w-wiezieniu-piracki-sprzet-w-celach/000IIGS7KUJ67K9I-C321.jpg" /></a>We włoskim zakładzie karnym w Velletri niedaleko Rzymu służba więzienna odnalazła nielegalne dekodery do oglądania płatnych kanałów telewizyjnych. Wśród przemycanych rzeczy - poza standardowymi telefonami czy niedozwolone substancje - były także konsole PlayStation. Sprzęt odnaleziono podczas nadzwyczajnej kontroli przeprowadzonej przez ponad 100 strażników. 
</p><br clear="all" />

## Inwazja czy kampanijna histeria? Republikanie grzmią, Biden w tarapatach
 - [https://wydarzenia.interia.pl/zagranica/news-inwazja-czy-kampanijna-histeria-republikanie-grzmia-biden-w-,nId,7305391](https://wydarzenia.interia.pl/zagranica/news-inwazja-czy-kampanijna-histeria-republikanie-grzmia-biden-w-,nId,7305391)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2024-02-01T09:55:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-inwazja-czy-kampanijna-histeria-republikanie-grzmia-biden-w-,nId,7305391"><img align="left" alt="Inwazja czy kampanijna histeria? Republikanie grzmią, Biden w tarapatach" src="https://i.iplsc.com/inwazja-czy-kampanijna-histeria-republikanie-grzmia-biden-w/000IIHUUKVQ4B88G-C321.jpg" /></a>Wszyscy, bez względu na polityczne barwy, przyznają: mamy poważny problem. I na tym jedność się kończy. Republikanie twierdzą, że demokraci, na czele z prezydentem, celowo prowadzą łagodną politykę migracyjną. Demokraci, że republikanie tylko mówią o współpracy w sprawie reformy systemu imigracyjnego, a w rzeczywistości kryzys na granicy z Meksykiem wykorzystują w politycznej walce i nie chcą go rozwiązać. Prób nielegalnego przekroczenia południowej granicy USA jeszcze nigdy nie było tak wiele, jak ostatnio. </p><br clear="all" />

