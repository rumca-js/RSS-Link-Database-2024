# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Greta Thunberg stanęła przed sądem. Konsekwencje wydarzeń z Londynu
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/wielka-brytania-greta-thunberg-staje-przed-sadem-konsekwencje-wydarzen-z-londynu](https://www.polsatnews.pl/wiadomosc/2024-02-01/wielka-brytania-greta-thunberg-staje-przed-sadem-konsekwencje-wydarzen-z-londynu)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T21:22:00+00:00

Działaczka klimatyczna Greta Thunberg stanęła przed sądem w Londynie. Młoda aktywistka oskarżona jest, wraz z czterema innymi osobami, o utrudnianie dostępu do hotelu, w którym odbywała się konferencja przedstawicieli przemysłu naftowego i gazowego.

## Kanada. Niesamowity wyczyn 99-latki. Pobiła trzy rekordy świata w pływaniu
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/kanada-niesamowity-wyczyn-99-latki-pobila-trzy-rekordy-swiata-w-plywaniu](https://www.polsatnews.pl/wiadomosc/2024-02-01/kanada-niesamowity-wyczyn-99-latki-pobila-trzy-rekordy-swiata-w-plywaniu)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T19:05:00+00:00

99-letnia Kanadyjka Betty Brussel przejdzie do historii światowego pływania. Kobieta w trakcie zawodów w Saanich w Kolumbii Brytyjskiej ustanowiła trzy rekordy świata w swojej grupie wiekowej.

## Trenował do maratonu z lodówką na plecach. Został wzięty za złodzieja
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/trenowal-do-maratonu-z-lodowka-na-plecach-zostal-wziety-za-zlodzieja](https://www.polsatnews.pl/wiadomosc/2024-02-01/trenowal-do-maratonu-z-lodowka-na-plecach-zostal-wziety-za-zlodzieja)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T17:51:00+00:00

34-letni Daniel Fairbrother ze Stevenage przygotowuje się do przebiegnięcia maratonu w Londynie. Mężczyzna chce pokonać całą trasę biegu... z lodówką na plecach. W tym celu, w ramach treningu, biega po ulicach swojego miasta ze wspomnianym sprzętem AGD. Ostatnio wpadł przez to w tarapaty i został zatrzymany przez policję, która wzięła go za złodzieja.

## Wojna w Ukrainie. Ukraińskie siły zniszczyły łódź rakietową Iwanowiec
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/wojna-w-ukrainie-ukrainskie-sily-zniszczyly-lodz-rakietowa-iwanowiec](https://www.polsatnews.pl/wiadomosc/2024-02-01/wojna-w-ukrainie-ukrainskie-sily-zniszczyly-lodz-rakietowa-iwanowiec)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T17:47:00+00:00

Ukraińskie siły zniszczyły łódź rakietową Iwanowiec należącą do rosyjskiej Floty Czarnomorskiej. Wartość okrętu szacuje się na kilkadziesiąt milionów dolarów.

## Bruksela. Protesty rolników. Tysiące osób protestowały przeciwko regulacjom
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/bruksela-protesty-rolnikow-tysiace-osob-protestowaly-przeciwko-regulacjom](https://www.polsatnews.pl/wiadomosc/2024-02-01/bruksela-protesty-rolnikow-tysiace-osob-protestowaly-przeciwko-regulacjom)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T17:45:00+00:00

Tysiące rolników i setki ciągników zjechały do Brukseli w ramach protestów. Powodem demonstracji są unijne regulacje nakładające na nich restrykcyjne wymagania związane z transportem czy ochroną środowiska.

## Indie: Gołąb oskarżony o szpiegostwo uwolniony. Był zatrzymany przez 8 miesięcy
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/indie-golab-oskarzony-o-szpiegostwo-uwolniony-byl-zatrzymany-przez-8-miesiecy](https://www.polsatnews.pl/wiadomosc/2024-02-01/indie-golab-oskarzony-o-szpiegostwo-uwolniony-byl-zatrzymany-przez-8-miesiecy)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T17:41:00+00:00

Po blisko ośmiu miesiącach aresztu na wolność wypuszczony został gołąb oskarżony o szpiegostwo na rzecz Chin. Ptak był przetrzymywany przez indyjską policję, która nie była jednak w stanie udowodnić postawionych zwierzęciu zarzutów.

## Najlepsze miejsca na miłośników jedzenia. Poznaliśmy zwycięzców
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/najlepsze-miejsca-na-milosnikow-jedzenia-poznalismy-zwyciezcow](https://www.polsatnews.pl/wiadomosc/2024-02-01/najlepsze-miejsca-na-milosnikow-jedzenia-poznalismy-zwyciezcow)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T16:42:00+00:00

Hanoi, Rzym i Kreta - to zwycięzcy tegorocznego konkursu Travellers Choice Awards Best of the Best. Użytkownicy największej na świecie platformy dla podróżników wybrali najciekawsze miejsca dla fanów wycieczek w połączeniu z dobrym jedzeniem.

## Polska armatohaubica Krab vs rosyjski dron. Ekspert ocenił patent z siatką
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/ukraina-siatka-uratowala-armatohaubice-krab-przed-rosyjskim-dronem-lancet-3-ekspert-ma-watpliwosci](https://www.polsatnews.pl/wiadomosc/2024-02-01/ukraina-siatka-uratowala-armatohaubice-krab-przed-rosyjskim-dronem-lancet-3-ekspert-ma-watpliwosci)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T14:24:00+00:00

W ostatnich dniach w ukraińskich mediach społecznościowych pojawiają się zdjęcia polskiej armatohaubicy Krab, która miała zostać uratowana przed rosyjskim dronem Lancet. Ochronę miało zapewnić proste rozwiązanie - osłonięcie pojazdu siatką ogrodzeniową. Ekspert z AGH w Krakowie ma jednak wątpliwości, czy ten sposób jest w stanie uratować Kraby na polu walki.

## USA. Katastrofa budowlana na lotnisku. Są ofiary śmiertelne
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/usa-katastrofa-budowlana-na-lotnisku-sa-ofiary-smiertelne](https://www.polsatnews.pl/wiadomosc/2024-02-01/usa-katastrofa-budowlana-na-lotnisku-sa-ofiary-smiertelne)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T13:06:00+00:00

Trzy osoby zginęły w katastrofie budowlanej w amerykańskim stanie Idaho, gdzie na lotnisku zawalił się budowany hangar dla odrzutowców. Kolejnych dziewięć osób zostało rannych, w tym niektóre ciężko. Na razie nie wiadomo, co było przyczyną zdarzenia. Na miejscu pracuje policja.

## Niemcy. Paraliż na lotniskach. Przez strajk odwołano ponad 1000 lotów
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/niemcy-paraliz-na-lotniskach-przez-strajk-odwolano-ponad-1000-lotow](https://www.polsatnews.pl/wiadomosc/2024-02-01/niemcy-paraliz-na-lotniskach-przez-strajk-odwolano-ponad-1000-lotow)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T11:58:00+00:00

Ruch na największych lotniskach w Niemczech jest sparaliżowany z powodu strajku zorganizowanego przez związek zawodowy Verdi. Pracownicy portów domagają się podwyżek. Nie odbyło się ponad 1000 zaplanowanych na czwartek lotów, niekiedy możliwe są jednak przesiadki.

## Mark Zuckerberg przeprasza rodziny. "Nikt nie powinien przez to przechodzić"
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/mark-zuckerberg-przeprasza-rodziny-nikt-nie-powinien-przez-to-przechodzic](https://www.polsatnews.pl/wiadomosc/2024-02-01/mark-zuckerberg-przeprasza-rodziny-nikt-nie-powinien-przez-to-przechodzic)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T11:29:00+00:00

- Przepraszam za wszystko, przez co przeszliście - powiedział Mark Zuckerberg rodzicom dzieci skrzywdzonych w mediach społecznościowych. Szef Mety był przesłuchiwany w amerykańskim Kongresie razem z przedstawicielami TikToka, Snapchata i Discorda.

## Miliardy euro dla Ukrainy. Przywódcy krajów UE zdecydowali
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/miliardy-euro-dla-ukrainy-przywodcy-krajow-ue-zdecydowali](https://www.polsatnews.pl/wiadomosc/2024-02-01/miliardy-euro-dla-ukrainy-przywodcy-krajow-ue-zdecydowali)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T10:35:00+00:00

Wszystkich 27 przywódców zgodziło się na pakiet wsparcia dla Ukrainy w wysokości 50 mld euro w ramach budżetu Unii Europejskiej - przekazał szef Rady Europejskiej Charles Michel. Oznacza to, że Bruksela osiągnęła porozumienie w tej sprawie z premierem Węgier Viktorem Orbanem.

## Jemen. USA zestrzeliły drony Huti. Urządzenia były gotowe do ataku
 - [https://www.polsatnews.pl/wiadomosc/2024-02-01/jemen-usa-zestrzelily-drony-huti-urzadzenia-byly-gotowe-do-ataku](https://www.polsatnews.pl/wiadomosc/2024-02-01/jemen-usa-zestrzelily-drony-huti-urzadzenia-byly-gotowe-do-ataku)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2024-02-01T05:25:00+00:00

Stany Zjednoczone zniszczyły 10 bezzałogowych dronów w Jemenie należących do rebeliantów Huti, które przygotowywały się do oddania strzałów. Dodatkowo okręt wojenny USA zestrzelił trzy irańskie drony i rakietę. Konflikt w regionie trwa od 19 listopada. Od tego czasu rebelianci zaatakowali statki na Morzu Czerwonym ponad 35 razy.

