# Source:The Times of Israel, URL:https://www.timesofisrael.com/feed, language:en-US

## Biden visits Michigan as Arab-American anger over Gaza threatens to cost him state
 - [https://www.timesofisrael.com/biden-visits-michigan-as-arab-american-anger-over-gaza-threatens-to-cost-him-state](https://www.timesofisrael.com/biden-visits-michigan-as-arab-american-anger-over-gaza-threatens-to-cost-him-state)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T22:20:17+00:00

<p>Home to largest US Muslim community, the Midwestern state is crucial to the president, who won it with a margin of just 154,000 votes in 2020</p>
<p>The post <a href="https://www.timesofisrael.com/biden-visits-michigan-as-arab-american-anger-over-gaza-threatens-to-cost-him-state/">Biden visits Michigan as Arab-American anger over Gaza threatens to cost him state</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/AP24032700130547-1024x640.jpg" title="Biden visits Michigan as Arab-American anger over Gaza threatens to cost him state" width="160" /></figure>

## Defense minister vows army will push south to Rafah as Khan Younis offensive wraps up
 - [https://www.timesofisrael.com/defense-minister-vows-army-will-push-south-to-rafah-as-khan-younis-offensive-wraps-up](https://www.timesofisrael.com/defense-minister-vows-army-will-push-south-to-rafah-as-khan-younis-offensive-wraps-up)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T21:47:43+00:00

<p>Gallant tells troops operations are aiding cause of freeing hostages; IDF battles gunmen across enclave, strikes rocket launchers</p>
<p>The post <a href="https://www.timesofisrael.com/defense-minister-vows-army-will-push-south-to-rafah-as-khan-younis-offensive-wraps-up/">Defense minister vows army will push south to Rafah as Khan Younis offensive wraps up</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/whatsapp_image_2024-02-01_at_19.16.21-1024x640.jpeg" title="Defense minister vows army will push south to Rafah as Khan Younis offensive wraps up" width="160" /></figure>

## Video shows California imams voice hatred for Jews, praise or deny October 7
 - [https://www.timesofisrael.com/video-shows-california-imams-voice-hatred-for-jews-praise-or-deny-october-7](https://www.timesofisrael.com/video-shows-california-imams-voice-hatred-for-jews-praise-or-deny-october-7)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T21:47:41+00:00

<p>Compilation of religious leaders shows sermons steeped in hatred of West, 'colonizers' and 'Zionist dogs'; one says it's 'time to make Zionists feel very uncomfortable on campus'</p>
<p>The post <a href="https://www.timesofisrael.com/video-shows-california-imams-voice-hatred-for-jews-praise-or-deny-october-7/">Video shows California imams voice hatred for Jews, praise or deny October 7</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/imam-1024x640.jpg" title="Video shows California imams voice hatred for Jews, praise or deny October 7" width="160" /></figure>

## Emergency Aid: Israel’s Soldiers & Families Desperately Need You! - Sponsored Content
 - [https://donate.meirpanim.org/2023-emergency-campaign/?utm_campaign=emergency-campaign-2023_1_29_2024&utm_medium=banner&utm_source=toi](https://donate.meirpanim.org/2023-emergency-campaign/?utm_campaign=emergency-campaign-2023_1_29_2024&utm_medium=banner&utm_source=toi)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T21:11:23+00:00

<p>Meir Panim's work is critical now more than ever; from 1,000,000+ meals to vital aid for soldiers and families, we need YOUR help to restore hope and essential support in Israel.</p>
<p>The post <a href="https://www.timesofisrael.com/spotlight/emergency-aid-israels-soldiers-families-desperately-need-you/">Emergency Aid: Israel&#8217;s Soldiers &#038; Families Desperately Need You!</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/Frame-4-1024x640.png" title="Emergency Aid: Israel&#8217;s Soldiers &#038; Families Desperately Need You!" width="160" /></figure>

## Assailant takes hostages at factory near Istanbul in protest over Gaza War
 - [https://www.timesofisrael.com/assailant-takes-hostages-at-factory-near-istanbul-in-protest-over-gaza-war](https://www.timesofisrael.com/assailant-takes-hostages-at-factory-near-istanbul-in-protest-over-gaza-war)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T20:00:27+00:00

<p>Suspect said holding at least seven people inside production plant owned by US consumer goods giant Procter & Gamble; images depict alleged attacker apparently wearing suicide vest</p>
<p>The post <a href="https://www.timesofisrael.com/assailant-takes-hostages-at-factory-near-istanbul-in-protest-over-gaza-war/">Assailant takes hostages at factory near Istanbul in protest over Gaza War</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/AFP__20240201__34HF222__v1__HighRes__TurkeyUsIsraelPalestinianConflictAttack-1024x640.jpg" title="Assailant takes hostages at factory near Istanbul in protest over Gaza War" width="160" /></figure>

## With unprecedented executive order, US sanctions settlers behind ‘intolerable’ violence
 - [https://www.timesofisrael.com/with-unprecedented-executive-order-us-sanctions-settlers-behind-intolerable-violence](https://www.timesofisrael.com/with-unprecedented-executive-order-us-sanctions-settlers-behind-intolerable-violence)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T19:58:06+00:00

<p>First series of financial penalties, travel ban slapped on 4 violent Israeli extremists; move creates tool that could be used to cut off entire settler movement from US financing</p>
<p>The post <a href="https://www.timesofisrael.com/with-unprecedented-executive-order-us-sanctions-settlers-behind-intolerable-violence/">With unprecedented executive order, US sanctions settlers behind &#8216;intolerable&#8217; violence</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2022/10/000_32LC7Z4-1024x640.jpg" title="With unprecedented executive order, US sanctions settlers behind &#8216;intolerable&#8217; violence" width="160" /></figure>

## US defense chief Austin hints major strike on Iranian proxies imminent
 - [https://www.timesofisrael.com/us-defense-chief-austin-hints-major-strike-on-iranian-proxies-imminent](https://www.timesofisrael.com/us-defense-chief-austin-hints-major-strike-on-iranian-proxies-imminent)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T19:50:57+00:00

<p>US secretary of defense says time has come for unprecedented action against militias' capabilities after servicemen killed in Jordan, repeated Houthi attacks in Red Sea</p>
<p>The post <a href="https://www.timesofisrael.com/us-defense-chief-austin-hints-major-strike-on-iranian-proxies-imminent/">US defense chief Austin hints major strike on Iranian proxies imminent</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/AP24032612688109-1-1024x640.jpg" title="US defense chief Austin hints major strike on Iranian proxies imminent" width="160" /></figure>

## UK’s Sunak says attacks that led pro-Israel MP to step down ‘an attack on democracy’
 - [https://www.timesofisrael.com/uks-sunak-says-attacks-that-led-pro-israel-mp-to-step-down-an-attack-on-democracy](https://www.timesofisrael.com/uks-sunak-says-attacks-that-led-pro-israel-mp-to-step-down-an-attack-on-democracy)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T19:50:53+00:00

<p>Conservative MP for Finchley and Golders Green Mike Freer says he won't seek reelection after threats the prime minister has called 'deeply distressing'</p>
<p>The post <a href="https://www.timesofisrael.com/uks-sunak-says-attacks-that-led-pro-israel-mp-to-step-down-an-attack-on-democracy/">UK&#8217;s Sunak says attacks that led pro-Israel MP to step down &#8216;an attack on democracy&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/12/Screenshot-2023-12-26-151959-e1703599436332-1024x640.png" title="UK&#8217;s Sunak says attacks that led pro-Israel MP to step down &#8216;an attack on democracy&#8217;" width="160" /></figure>

## US cyber firm Proofpoint to lay off Israeli employees as part of global job cuts
 - [https://www.timesofisrael.com/us-cyber-firm-proofpoint-to-lay-off-israeli-employees-as-part-of-global-job-cuts](https://www.timesofisrael.com/us-cyber-firm-proofpoint-to-lay-off-israeli-employees-as-part-of-global-job-cuts)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T17:18:56+00:00

<p>The cybersecurity company, which has 300 employees in Israel after making four acquisitions in the country, is planning to slash 6% of its global workforce</p>
<p>The post <a href="https://www.timesofisrael.com/us-cyber-firm-proofpoint-to-lay-off-israeli-employees-as-part-of-global-job-cuts/">US cyber firm Proofpoint to lay off Israeli employees as part of global job cuts</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2022/07/iStock-1347040968-1024x640.jpg" title="US cyber firm Proofpoint to lay off Israeli employees as part of global job cuts" width="160" /></figure>

## Lindsey Graham grills TikTok CEO on resignation of Israel representative
 - [https://www.timesofisrael.com/lindsey-graham-grills-tiktok-ceo-on-resignation-of-israel-representative](https://www.timesofisrael.com/lindsey-graham-grills-tiktok-ceo-on-resignation-of-israel-representative)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T17:18:53+00:00

<p>At hearing with tech CEOs, US senator says TikTok 'being used to help people who want to destroy the Jewish state'</p>
<p>The post <a href="https://www.timesofisrael.com/lindsey-graham-grills-tiktok-ceo-on-resignation-of-israel-representative/">Lindsey Graham grills TikTok CEO on resignation of Israel representative</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/AP24031617266926-1024x640.jpg" title="Lindsey Graham grills TikTok CEO on resignation of Israel representative" width="160" /></figure>

## State attorney closes cases against Walla, Yedioth; Netanyahu trial not affected
 - [https://www.timesofisrael.com/state-attorney-closes-cases-against-walla-yedioth-netanyahu-trial-not-affected](https://www.timesofisrael.com/state-attorney-closes-cases-against-walla-yedioth-netanyahu-trial-not-affected)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T17:18:51+00:00

<p>In deal with state attorney, Bezeq firm, formerly controlled by Shaul Elovitch, to pay NIS 800,000 fine, admit to providing misleading information</p>
<p>The post <a href="https://www.timesofisrael.com/state-attorney-closes-cases-against-walla-yedioth-netanyahu-trial-not-affected/">State attorney closes cases against Walla, Yedioth; Netanyahu trial not affected</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2020/01/pjimage-1024x640.jpg" title="State attorney closes cases against Walla, Yedioth; Netanyahu trial not affected" width="160" /></figure>

## Efrat Katz, 68: Doting grandmother who loved the fields of Nir Oz
 - [https://www.timesofisrael.com/efrat-katz-68-doting-grandmother-who-loved-the-fields-of-nir-oz](https://www.timesofisrael.com/efrat-katz-68-doting-grandmother-who-loved-the-fields-of-nir-oz)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T16:53:27+00:00

<p>Slain while being kidnapped by Hamas terrorists from her home in Kibbutz Nir Oz on October 7</p>
<p>The post <a href="https://www.timesofisrael.com/efrat-katz-68-doting-grandmother-who-loved-the-fields-of-nir-oz/">Efrat Katz, 68: Doting grandmother who loved the fields of Nir Oz</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/Untitled-design-2024-02-01T165805.039-1024x640.jpg" title="Efrat Katz, 68: Doting grandmother who loved the fields of Nir Oz" width="160" /></figure>

## Rotem Neumann, 25: Her life was an ‘endless dance’
 - [https://www.timesofisrael.com/rotem-neumann-25-her-life-was-an-endless-dance](https://www.timesofisrael.com/rotem-neumann-25-her-life-was-an-endless-dance)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T16:41:05+00:00

<p>Murdered at the Supernova music festival on October 7</p>
<p>The post <a href="https://www.timesofisrael.com/rotem-neumann-25-her-life-was-an-endless-dance/">Rotem Neumann, 25: Her life was an &#8216;endless dance&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/cropped211-1024x640.jpg" title="Rotem Neumann, 25: Her life was an &#8216;endless dance&#8217;" width="160" /></figure>

## Chen Ben Avi, 23: Dreamed of traveling the world
 - [https://www.timesofisrael.com/chen-ben-avi-23-dreamt-of-traveling-the-world](https://www.timesofisrael.com/chen-ben-avi-23-dreamt-of-traveling-the-world)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T16:33:01+00:00

<p>Murdered while fleeing the Supernova music festival on October 7</p>
<p>The post <a href="https://www.timesofisrael.com/chen-ben-avi-23-dreamt-of-traveling-the-world/">Chen Ben Avi, 23: Dreamed of traveling the world</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/387790319_7115633295115629_5729686055549238286_n-e1706634851193-1024x640.jpg" title="Chen Ben Avi, 23: Dreamed of traveling the world" width="160" /></figure>

## Sgt. Adi Groman, 19: Music lover who was ‘the best warrior’
 - [https://www.timesofisrael.com/sgt-adi-groman-19-music-lover-who-was-the-best-warrior](https://www.timesofisrael.com/sgt-adi-groman-19-music-lover-who-was-the-best-warrior)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T16:28:49+00:00

<p>Killed battling Hamas terrorists at the Urim IDF base on October 7</p>
<p>The post <a href="https://www.timesofisrael.com/sgt-adi-groman-19-music-lover-who-was-the-best-warrior/">Sgt. Adi Groman, 19: Music lover who was &#8216;the best warrior&#8217;</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/Untitled-design-2024-01-29T151633.935-1024x640.jpg" title="Sgt. Adi Groman, 19: Music lover who was &#8216;the best warrior&#8217;" width="160" /></figure>

## In Cairo, senior Hamas officials discuss hostage deal with Egyptian intelligence chief
 - [https://www.timesofisrael.com/in-cairo-senior-hamas-officials-discuss-hostage-deal-with-egyptian-intelligence-chief](https://www.timesofisrael.com/in-cairo-senior-hamas-officials-discuss-hostage-deal-with-egyptian-intelligence-chief)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T15:56:21+00:00

<p>Delegation said led by terror group's Qatar-based political leader Ismail Haniyeh; Wall Street Journal reports Hamas demanding 150 security prisoners for each female soldier</p>
<p>The post <a href="https://www.timesofisrael.com/in-cairo-senior-hamas-officials-discuss-hostage-deal-with-egyptian-intelligence-chief/">In Cairo, senior Hamas officials discuss hostage deal with Egyptian intelligence chief</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/F240201MA07-1024x640.jpg" title="In Cairo, senior Hamas officials discuss hostage deal with Egyptian intelligence chief" width="160" /></figure>

## Israeli green thermal storage company signs 7-year deal with Wolfson Hospital
 - [https://www.timesofisrael.com/israeli-green-thermal-storage-company-signs-7-year-deal-with-wolfson-hospital](https://www.timesofisrael.com/israeli-green-thermal-storage-company-signs-7-year-deal-with-wolfson-hospital)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T15:56:11+00:00

<p>Brenmiller Energy tech will replace diesel boilers, is expected to help cut fuel oil use to 'nearly zero,' reduce pollution, and save up to $1.3 million annually</p>
<p>The post <a href="https://www.timesofisrael.com/israeli-green-thermal-storage-company-signs-7-year-deal-with-wolfson-hospital/">Israeli green thermal storage company signs 7-year deal with Wolfson Hospital</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/brenmiller-1024x640.jpg" title="Israeli green thermal storage company signs 7-year deal with Wolfson Hospital" width="160" /></figure>

## In Congress, Zuckerberg apologizes to parents for harm caused by social media
 - [https://www.timesofisrael.com/zuckerberg-apologizes-to-parents-in-congress-for-harm-caused-by-social-media](https://www.timesofisrael.com/zuckerberg-apologizes-to-parents-in-congress-for-harm-caused-by-social-media)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T15:01:22+00:00

<p>US senators grill tech CEOs over apparent failure to prevent online sexual exploitation of minors and self-harm; TikTok CEO vows funding for 'trust and safety'</p>
<p>The post <a href="https://www.timesofisrael.com/zuckerberg-apologizes-to-parents-in-congress-for-harm-caused-by-social-media/">In Congress, Zuckerberg apologizes to parents for harm caused by social media</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/AFP__20240131__34HC9D8__v5__HighRes__TopshotUsTechnologyInternetChildExploitation-e1706798399191-1024x640.jpg" title="In Congress, Zuckerberg apologizes to parents for harm caused by social media" width="160" /></figure>

## Reports say IDF soldiers have torched hundreds of buildings in Gaza
 - [https://www.timesofisrael.com/reports-say-idf-soldiers-have-torched-hundreds-of-buildings-in-gaza](https://www.timesofisrael.com/reports-say-idf-soldiers-have-torched-hundreds-of-buildings-in-gaza)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T14:58:40+00:00

<p>Soldiers say method utilized to destroy structures used by terrorists amid shortage of demolition charges, but some claim activity has become gratuitous</p>
<p>The post <a href="https://www.timesofisrael.com/reports-say-idf-soldiers-have-torched-hundreds-of-buildings-in-gaza/">Reports say IDF soldiers have torched hundreds of buildings in Gaza</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/Screenshot-2024-02-01-162251-1024x640.jpg" title="Reports say IDF soldiers have torched hundreds of buildings in Gaza" width="160" /></figure>

## 7 Best THCP Gummies – Top THCP Edibles in 2024 - Sponsored Content
 - [https://www.timesofisrael.com/spotlight/best-thcp-edibles](https://www.timesofisrael.com/spotlight/best-thcp-edibles)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T13:58:46+00:00

<p>Say goodbye to stress and uncover relaxation with the Best THCP Gummies of 2024! Explore a curated selection of top-tier brands delivering the purest THCP gummies on the market.</p>
<p>The post <a href="https://www.timesofisrael.com/spotlight/best-thcp-edibles/">7 Best THCP Gummies &#8211; Top THCP Edibles in 2024</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>

## Iran begins construction of four new nuclear plants
 - [https://www.timesofisrael.com/iran-begins-construction-of-four-new-nuclear-plants](https://www.timesofisrael.com/iran-begins-construction-of-four-new-nuclear-plants)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T13:27:37+00:00

<p>Islamic Republic denies that it seeks to acquire nuclear weapons, despite global suspicions </p>
<p>The post <a href="https://www.timesofisrael.com/iran-begins-construction-of-four-new-nuclear-plants/">Iran begins construction of four new nuclear plants</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/12/AP23191737631628-e1703606833545-1024x640.jpg" title="Iran begins construction of four new nuclear plants" width="160" /></figure>

## Explosion reported near ship in Red Sea as Houthi attacks from Yemen continue
 - [https://www.timesofisrael.com/explosion-reported-near-ship-in-red-sea-as-houthi-attacks-from-yemen-continue](https://www.timesofisrael.com/explosion-reported-near-ship-in-red-sea-as-houthi-attacks-from-yemen-continue)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T13:27:10+00:00

<p>UK maritime security agency says vessel, crew unharmed; in separate strike, missile reportedly fired from Yemen hits US merchant ship, with Iran-backed rebels claiming 'direct hit'</p>
<p>The post <a href="https://www.timesofisrael.com/explosion-reported-near-ship-in-red-sea-as-houthi-attacks-from-yemen-continue/">Explosion reported near ship in Red Sea as Houthi attacks from Yemen continue</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/AFP__20240201__34HE88J__v1__HighRes__YemenPalestinianIsraelConflictProtest-1024x640.jpg" title="Explosion reported near ship in Red Sea as Houthi attacks from Yemen continue" width="160" /></figure>

## Austrian literary festival drops Bosnian author who protested criticism of Oct. 7
 - [https://www.timesofisrael.com/austrian-literary-festival-drops-bosnian-author-who-protested-criticism-of-oct-7](https://www.timesofisrael.com/austrian-literary-festival-drops-bosnian-author-who-protested-criticism-of-oct-7)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T13:26:40+00:00

<p>Separately, a children's book fair in Italy indicates it will ignore a petition to boycott Israel signed by top artists</p>
<p>The post <a href="https://www.timesofisrael.com/austrian-literary-festival-drops-bosnian-author-who-protested-criticism-of-oct-7/">Austrian literary festival drops Bosnian author who protested criticism of Oct. 7</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/Lana_Bastasic_2023-1024x640.jpg" title="Austrian literary festival drops Bosnian author who protested criticism of Oct. 7" width="160" /></figure>

## At least 30 phones of journalists, activists hacked in Jordan with Israeli tech
 - [https://www.timesofisrael.com/at-least-30-phones-of-journalists-activists-hacked-in-jordan-with-israeli-tech](https://www.timesofisrael.com/at-least-30-phones-of-journalists-activists-hacked-in-jordan-with-israeli-tech)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T12:59:06+00:00

<p>Forensic probe finds infiltrations were done with NSO's Pegasus spyware; Jordanian government not named in report, but activists say Amman most likely culprit</p>
<p>The post <a href="https://www.timesofisrael.com/at-least-30-phones-of-journalists-activists-hacked-in-jordan-with-israeli-tech/">At least 30 phones of journalists, activists hacked in Jordan with Israeli tech</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/shutterstock_2019667148-1024x640.jpg" title="At least 30 phones of journalists, activists hacked in Jordan with Israeli tech" width="160" /></figure>

## Try The Best CBD Gummies of 2024 for Relaxation, Pain, and More - Sponsored Content
 - [https://www.timesofisrael.com/spotlight/best-cbd-edibles](https://www.timesofisrael.com/spotlight/best-cbd-edibles)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T12:49:15+00:00

<p> Discover the Ultimate CBD Adventure!  Let’s explore a delicious way to unwind with our guide to the Best CBD Gummies of 2024!</p>
<p>The post <a href="https://www.timesofisrael.com/spotlight/best-cbd-edibles/">Try The Best CBD Gummies of 2024 for Relaxation, Pain, and More</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>

## Daily Briefing Feb 1: Day 118 – US & UK seem to push for Palestinian state. Too soon?
 - [https://www.timesofisrael.com/daily-briefing-feb-1-day-118-us-uk-seem-to-push-for-palestinian-state-too-soon](https://www.timesofisrael.com/daily-briefing-feb-1-day-118-us-uk-seem-to-push-for-palestinian-state-too-soon)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T12:39:39+00:00

<p>Editor David Horovitz weighs in on the 'Biden Doctrine,' the contours of a potential hostage deal, and the resettlement of Gush Katif in the Gaza Strip</p>
<p>The post <a href="https://www.timesofisrael.com/daily-briefing-feb-1-day-118-us-uk-seem-to-push-for-palestinian-state-too-soon/">Daily Briefing Feb 1: Day 118 &#8211; US &#038; UK seem to push for Palestinian state. Too soon?</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/shutterstock_2373852943-1024x640.jpg" title="Daily Briefing Feb 1: Day 118 &#8211; US &#038; UK seem to push for Palestinian state. Too soon?" width="160" /></figure>

## US federal judge says Israel plausibly committing genocide, Biden must take note
 - [https://www.timesofisrael.com/us-federal-judge-says-israel-plausibly-committing-genocide-biden-must-take-note](https://www.timesofisrael.com/us-federal-judge-says-israel-plausibly-committing-genocide-biden-must-take-note)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T12:39:04+00:00

<p>California court says it does not have jurisdiction, dismisses petition accusing White House of genocide complicity, urges US government to examine support for Israel's war</p>
<p>The post <a href="https://www.timesofisrael.com/us-federal-judge-says-israel-plausibly-committing-genocide-biden-must-take-note/">US federal judge says Israel plausibly committing genocide, Biden must take note</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/AP24030582652791-1024x640.jpg" title="US federal judge says Israel plausibly committing genocide, Biden must take note" width="160" /></figure>

## 5 Best CBD Vape Pens For Maximum Relaxation - Sponsored Content
 - [https://www.timesofisrael.com/spotlight/best-cbd-vapes](https://www.timesofisrael.com/spotlight/best-cbd-vapes)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T11:58:10+00:00

<p>Experience relaxation with the best CBD vape pens of 2024! Uncover the top 5 brands delivering lab-tested, purest, and most convenient CBD vapes.</p>
<p>The post <a href="https://www.timesofisrael.com/spotlight/best-cbd-vapes/">5 Best CBD Vape Pens For Maximum Relaxation</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>

## Activists block Gaza aid trucks at Ashdod Port after being barred from border by IDF
 - [https://www.timesofisrael.com/activists-block-gaza-aid-trucks-at-ashdod-port-after-being-barred-from-border-by-idf](https://www.timesofisrael.com/activists-block-gaza-aid-trucks-at-ashdod-port-after-being-barred-from-border-by-idf)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T11:52:46+00:00

<p>Continuing game of cat and mouse with security forces, protesters including far-right MK attempt to block trucks carrying humanitarian supplies for Palestinians in Strip</p>
<p>The post <a href="https://www.timesofisrael.com/activists-block-gaza-aid-trucks-at-ashdod-port-after-being-barred-from-border-by-idf/">Activists block Gaza aid trucks at Ashdod Port after being barred from border by IDF</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/AP24032324356606-1024x640.jpg" title="Activists block Gaza aid trucks at Ashdod Port after being barred from border by IDF" width="160" /></figure>

## UN envoy meets freed hostages, families in probe of Hamas sexual violence on Oct. 7
 - [https://www.timesofisrael.com/un-envoy-meets-freed-hostages-families-in-probe-of-hamas-sexual-violence-on-oct-7](https://www.timesofisrael.com/un-envoy-meets-freed-hostages-families-in-probe-of-hamas-sexual-violence-on-oct-7)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T11:52:12+00:00

<p>Special representative on sexual violence in conflict vows to use all means at her disposal to free remaining captives, hears testimony of forensic evidence at IDF's Shura base</p>
<p>The post <a href="https://www.timesofisrael.com/un-envoy-meets-freed-hostages-families-in-probe-of-hamas-sexual-violence-on-oct-7/">UN envoy meets freed hostages, families in probe of Hamas sexual violence on Oct. 7</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/WhatsApp-Image-2024-01-29-at-20.19.43-1024x640.jpeg" title="UN envoy meets freed hostages, families in probe of Hamas sexual violence on Oct. 7" width="160" /></figure>

## What does Israel need to do to comply with the ICJ genocide decision?
 - [https://www.timesofisrael.com/what-does-israel-need-to-do-to-comply-with-the-icj-genocide-decision](https://www.timesofisrael.com/what-does-israel-need-to-do-to-comply-with-the-icj-genocide-decision)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T11:23:44+00:00

<p>Provisional measures ordered by the court that Israel alleviate the humanitarian situation in Gaza and prevent incitement to genocide will be key to demonstrating compliance</p>
<p>The post <a href="https://www.timesofisrael.com/what-does-israel-need-to-do-to-comply-with-the-icj-genocide-decision/">What does Israel need to do to comply with the ICJ genocide decision?</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/20240126-192-1-1024x640.jpg" title="What does Israel need to do to comply with the ICJ genocide decision?" width="160" /></figure>

## Iran’s Revolutionary Guards pull officers from Syria following alleged Israeli strikes
 - [https://www.timesofisrael.com/irans-revolutionary-guards-pull-officers-from-syria-following-alleged-israeli-strikes](https://www.timesofisrael.com/irans-revolutionary-guards-pull-officers-from-syria-following-alleged-israeli-strikes)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T11:10:12+00:00

<p>Iranian casualties in a string of recent attacks reportedly induce Tehran to rely more on local Shia groups to maintain country's influence; remaining officers keeping low profile</p>
<p>The post <a href="https://www.timesofisrael.com/irans-revolutionary-guards-pull-officers-from-syria-following-alleged-israeli-strikes/">Iran&#8217;s Revolutionary Guards pull officers from Syria following alleged Israeli strikes</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/status-6.jpg" title="Iran&#8217;s Revolutionary Guards pull officers from Syria following alleged Israeli strikes" width="160" /></figure>

## Biden said set to make push for demilitarized Palestinian state as part of new doctrine
 - [https://www.timesofisrael.com/biden-said-set-to-make-push-for-demilitarized-palestinian-state-as-part-of-new-doctrine](https://www.timesofisrael.com/biden-said-set-to-make-push-for-demilitarized-palestinian-state-as-part-of-new-doctrine)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T10:32:45+00:00

<p>New York Times' Thomas Friedman, who's close to the US administration, says emerging doctrine would include Saudi-Israeli normalization, 2-state solution, and campaign against Iran</p>
<p>The post <a href="https://www.timesofisrael.com/biden-said-set-to-make-push-for-demilitarized-palestinian-state-as-part-of-new-doctrine/">Biden said set to make push for demilitarized Palestinian state as part of new doctrine</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2022/10/AP22196377120988-1024x640.jpg" title="Biden said set to make push for demilitarized Palestinian state as part of new doctrine" width="160" /></figure>

## Gantz, Eisenkot said to mull limiting aid to Gaza as part of efforts to weaken Hamas
 - [https://www.timesofisrael.com/gantz-eisenkot-said-to-mull-limiting-aid-to-gaza-as-part-of-efforts-to-weaken-hamas](https://www.timesofisrael.com/gantz-eisenkot-said-to-mull-limiting-aid-to-gaza-as-part-of-efforts-to-weaken-hamas)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T04:44:46+00:00

<p>TV report says the National Unity ministers believe move could create pressure for an alternative body to take responsibility for distributing humanitarian assistance in the Strip</p>
<p>The post <a href="https://www.timesofisrael.com/gantz-eisenkot-said-to-mull-limiting-aid-to-gaza-as-part-of-efforts-to-weaken-hamas/">Gantz, Eisenkot said to mull limiting aid to Gaza as part of efforts to weaken Hamas</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/AFP__20240122__34GC962__v4__HighRes__IsraelPalestinianEgyptConflictAid-1024x640.jpg" title="Gantz, Eisenkot said to mull limiting aid to Gaza as part of efforts to weaken Hamas" width="160" /></figure>

## Pro-Israel MP in UK says he won’t seek reelection, notes ‘serious threats’ against him
 - [https://www.timesofisrael.com/pro-israel-mp-in-uk-says-he-wont-seek-reelection-notes-serious-threats-against-him](https://www.timesofisrael.com/pro-israel-mp-in-uk-says-he-wont-seek-reelection-notes-serious-threats-against-him)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T03:13:49+00:00

<p>Conservative Mike Freer, who represents London constituency with large Orthodox Jewish population, makes announcement weeks after suspected arson attack on his office</p>
<p>The post <a href="https://www.timesofisrael.com/pro-israel-mp-in-uk-says-he-wont-seek-reelection-notes-serious-threats-against-him/">Pro-Israel MP in UK says he won&#8217;t seek reelection, notes &#8216;serious threats&#8217; against him</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2023/12/Screenshot-2023-12-26-151959-e1703599436332-1024x640.png" title="Pro-Israel MP in UK says he won&#8217;t seek reelection, notes &#8216;serious threats&#8217; against him" width="160" /></figure>

## Chicago adopts Gaza ceasefire resolution after mayor casts tie-breaking vote
 - [https://www.timesofisrael.com/chicago-adopts-gaza-ceasefire-resolution-after-mayor-casts-tie-breaking-vote](https://www.timesofisrael.com/chicago-adopts-gaza-ceasefire-resolution-after-mayor-casts-tie-breaking-vote)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T02:20:16+00:00

<p>Democrat Brandon Johnson splits with party leader Biden, making Chicago the largest US city to pass symbolic measure that also calls for hostages' release but doesn't condemn Hamas</p>
<p>The post <a href="https://www.timesofisrael.com/chicago-adopts-gaza-ceasefire-resolution-after-mayor-casts-tie-breaking-vote/">Chicago adopts Gaza ceasefire resolution after mayor casts tie-breaking vote</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/IMG_5860-1024x640.jpg" title="Chicago adopts Gaza ceasefire resolution after mayor casts tie-breaking vote" width="160" /></figure>

## Exiled from greener pastures, southerners cram kibbutz life into two Tel Aviv towers
 - [https://www.timesofisrael.com/exiled-from-greener-pastures-southerners-cram-kibbutz-life-into-two-tel-aviv-towers](https://www.timesofisrael.com/exiled-from-greener-pastures-southerners-cram-kibbutz-life-into-two-tel-aviv-towers)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T01:01:12+00:00

<p>Evacuated Kibbutz Re’im residents work to acclimatize in two newly built high rises in a bid to reinvent the coziness of their former home</p>
<p>The post <a href="https://www.timesofisrael.com/exiled-from-greener-pastures-southerners-cram-kibbutz-life-into-two-tel-aviv-towers/">Exiled from greener pastures, southerners cram kibbutz life into two Tel Aviv towers</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/IMG_4955-1-1024x640.jpg" title="Exiled from greener pastures, southerners cram kibbutz life into two Tel Aviv towers" width="160" /></figure>

## Russia is intimidating its expat celebrities in an attempt to silence them
 - [https://www.timesofisrael.com/russia-is-intimidating-its-expat-celebrities-in-an-attempt-to-silence-them](https://www.timesofisrael.com/russia-is-intimidating-its-expat-celebrities-in-an-attempt-to-silence-them)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T01:00:23+00:00

<p>Alt-rock band Bi-2, which has Israeli-Russian members, was nearly deported to Thailand. After a week in detention, Israel's Foreign Ministry succeeds in flying group to Tel Aviv</p>
<p>The post <a href="https://www.timesofisrael.com/russia-is-intimidating-its-expat-celebrities-in-an-attempt-to-silence-them/">Russia is intimidating its expat celebrities in an attempt to silence them</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/01/AP24030531870075-1024x640.jpg" title="Russia is intimidating its expat celebrities in an attempt to silence them" width="160" /></figure>

## Georgia governor signs bill codifying IHRA definition of antisemitism in state law
 - [https://www.timesofisrael.com/georgia-governor-signs-bill-codifying-ihra-definition-of-antisemitism-in-state-law](https://www.timesofisrael.com/georgia-governor-signs-bill-codifying-ihra-definition-of-antisemitism-in-state-law)
 - RSS feed: https://www.timesofisrael.com/feed
 - date published: 2024-02-01T00:29:36+00:00

<p>Sponsor of law predicts it will withstand expected legal challenges, as opponents express concern it could hamper Israel criticism</p>
<p>The post <a href="https://www.timesofisrael.com/georgia-governor-signs-bill-codifying-ihra-definition-of-antisemitism-in-state-law/">Georgia governor signs bill codifying IHRA definition of antisemitism in state law</a> appeared first on <a href="https://www.timesofisrael.com">The Times of Israel</a>.</p>
<figure><img border="0" class="type:primaryImage" height="100" src="https://static.timesofisrael.com/www/uploads/2024/02/AP24031724832910-e1706742933754-1024x640.jpg" title="Georgia governor signs bill codifying IHRA definition of antisemitism in state law" width="160" /></figure>

