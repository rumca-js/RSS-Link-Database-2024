# Source:Colombia News | Colombia Reports, URL:https://colombiareports.com/feed/, language:en-US

## Colombia urges Israel to cease fire in Gaza
 - [https://colombiareports.com/colombia-urges-israel-to-cease-fire-in-gaza](https://colombiareports.com/colombia-urges-israel-to-cease-fire-in-gaza)
 - RSS feed: https://colombiareports.com/feed/
 - date published: 2024-02-01T15:54:37+00:00

<p>Colombia&#8217;s President Gustavo Petro urged Israel&#8217;s Prime Minister Benjamin Netanyahu to end attacks on occupied territories in Palestine. In a letter, the Colombian president also urged Netanyahu to create an&#8230;</p>
<p>The post <a href="https://colombiareports.com/colombia-urges-israel-to-cease-fire-in-gaza/" rel="nofollow">Colombia urges Israel to cease fire in Gaza</a> appeared first on <a href="https://colombiareports.com" rel="nofollow">Colombia News | Colombia Reports</a>.</p>

