# Source:CBC | Canada News, URL:https://www.cbc.ca/webfeed/rss/rss-canada, language:en

## Planned rollout of dental care will miss deadline in Liberals' deal with the NDP
 - [https://www.cbc.ca/news/politics/dental-care-liberals-deadline-1.7102324?cmp=rss](https://www.cbc.ca/news/politics/dental-care-liberals-deadline-1.7102324?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T17:29:15+00:00

<img alt="Health Minister Mark Holland is awaiting the Special Joint Committee on Medical Assistance in Dying&apos;s report before making a final decision." height="349" src="https://i.cbc.ca/1.7095695.1706282263!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/mark-holland.jpg" title="Health Minister Mark Holland has not ruled out another pause in opening medical assistance in dying for mental illness." width="620" /><p>The New Democrats and Liberals are at odds over the rollout of the new federal dental plan after the government announced it won't fully expand eligibility until 2025 — contrary to the pact it signed with the NDP.</p>

## Sammy Yatim's shooting death by former Toronto cop a homicide, coroner's inquest finds
 - [https://www.cbc.ca/news/canada/toronto/sammy-yatim-inquest-verdict-homicide-1.7102055?cmp=rss](https://www.cbc.ca/news/canada/toronto/sammy-yatim-inquest-verdict-homicide-1.7102055?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T16:17:49+00:00

<img alt="A headshot of Sammy Yatim" height="349" src="https://i.cbc.ca/1.2862856.1705025144!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/sammy-yatim-toronto-police-shooting.jpg" title="Sammy Yatim is shown in a photo from the Facebook page &quot;R.I.P Sammy Yatim.&quot; " width="620" /><p>Sammy Yatim's shooting death by a former Toronto police officer was a homicide, a coroner's inquest has found more than a decade after his death.</p>

## First Nations mull legal action, plan protests over Ontario's online mining claims system
 - [https://www.cbc.ca/news/indigenous/first-nations-online-mining-claims-concerns-1.7101467?cmp=rss](https://www.cbc.ca/news/indigenous/first-nations-online-mining-claims-concerns-1.7101467?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T13:43:28+00:00

<img alt="A group of people sit at a desk and take questions from reporters. " height="349" src="https://i.cbc.ca/1.6978586.1695749067!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/ont-ring-of-fire-20230926.jpg" title="Members of the Land Defence Alliance, left to right, Chief Rudy Turtle of Grassy Narrows First Nation, Sol Mamakwa MPP, Elder Alex Moonias from Neskantaga First Nation and Cecilia Begg from Kitchenuhmaykoosib Inninuwug First Nation hold a press conference at Queen&apos;s Park in Toronto on Tuesday, September 26, 2023. " width="620" /><p>First Nations leaders say they’ll up their protests and consider legal action if the Ontario government refuses to address their concerns with the province’s online system for staking mining claims.</p>

## Quebec's new furry forecaster to make his Groundhog Day debut
 - [https://www.cbc.ca/news/canada/montreal/quebec-s-new-furry-forecaster-to-make-his-groundhog-day-debut-1.7101228?cmp=rss](https://www.cbc.ca/news/canada/montreal/quebec-s-new-furry-forecaster-to-make-his-groundhog-day-debut-1.7101228?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T12:00:00+00:00

<img alt="" height="349" src="https://thumbnails.cbc.ca/maven_legacy/thumbnails/967/787/16x9_MPX_Thumbnail_(7).jpg" title="" width="620" /><p>Groundhog Fred Junior is set to predict whether winter will drag on Friday in Val D'Espoir. He's following in the footsteps of his father Fred, and his grandfather, Gros Fred.</p>

## Alberta premier to discuss changes to gender policies for children, youth
 - [https://www.cbc.ca/news/canada/edmonton/alberta-premier-to-discuss-changes-to-gender-policies-for-children-youth-1.7101595?cmp=rss](https://www.cbc.ca/news/canada/edmonton/alberta-premier-to-discuss-changes-to-gender-policies-for-children-youth-1.7101595?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T11:59:04+00:00

<img alt="A woman with brown hair stands in front of a blurred background of flags." height="349" src="https://i.cbc.ca/1.7067070.1703205282!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/alta-sovereignty-act-20231127.JPG" title="Alberta Premier Danielle Smith speaks on invoking her government’s sovereignty act over federal clean energy regulations, in Edmonton on Nov. 27." width="620" /><p>Alberta Premier Danielle Smith will hold a news conference today about the sweeping and controversial gender policies for children and youth she announced on social media Wednesday. Smith will speak to media at 1:30 p.m. MT in Calgary.</p>

## Court case for P.E.I. teacher's 1988 death adjourned until March
 - [https://www.cbc.ca/news/canada/prince-edward-island/court-case-for-p-e-i-teacher-s-1988-death-adjourned-until-march-1.7101593?cmp=rss](https://www.cbc.ca/news/canada/prince-edward-island/court-case-for-p-e-i-teacher-s-1988-death-adjourned-until-march-1.7101593?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T11:34:14+00:00

<img alt="A poster showing two photos depicting the same man with text underneath. " height="349" src="https://i.cbc.ca/1.7095828.1706286552!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/byron-carr-poster.jpg" title="Charlottetown police say there is a &apos;significant development&apos; in the 1988 killing of Byron Carr. Police Chief Brad MacConnell is holding a news conference on Friday to discuss the case. " width="620" /><p>The lawyer representing the man charged with killing P.E.I. school teacher Byron Carr 35 years ago appeared in a Charlottetown courtroom on his client’s behalf Thursday morning.</p>

## Court case involving P.E.I. teacher's 1988 death adjourned until March
 - [https://www.cbc.ca/news/canada/prince-edward-island/court-case-involving-p-e-i-teacher-s-1988-death-adjourned-until-march-1.7101593?cmp=rss](https://www.cbc.ca/news/canada/prince-edward-island/court-case-involving-p-e-i-teacher-s-1988-death-adjourned-until-march-1.7101593?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T11:34:14+00:00

<img alt="A poster showing two photos depicting the same man with text underneath. " height="349" src="https://i.cbc.ca/1.7095828.1706286552!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/byron-carr-poster.jpg" title="Charlottetown police say there is a &apos;significant development&apos; in the 1988 killing of Byron Carr. Police Chief Brad MacConnell is holding a news conference on Friday to discuss the case. " width="620" /><p>The lawyer representing the man charged with killing P.E.I. high school teacher Byron Carr 35 years ago appeared in a Charlottetown courtroom on his client’s behalf Thursday morning.</p>

## Inside the unique Africentric school that celebrates Black history all year
 - [https://www.cbc.ca/kidsnews/post/inside-the-unique-africentric-school-that-celebrates-black-history-all-year?cmp=rss](https://www.cbc.ca/kidsnews/post/inside-the-unique-africentric-school-that-celebrates-black-history-all-year?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T10:10:19+00:00

<img alt="A portrait image of a 13-year-old boy standing in the school library. " height="349" src="https://i.cbc.ca/1.7101439.1706796368!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/cbckidsnews-africentric-schools-amar.jpg" title="Amar Ford, 13, said the curriculum at the Africentric Alternative School in Toronto, Ontario, has boosted his confidence. " width="620" /><p></p>

## 'To me, it was a prison': Children held in Doukhobor camp in 1950s set to receive apology from B.C. government
 - [https://www.cbc.ca/news/canada/british-columbia/doukhobor-apology-new-westminster-1.7100982?cmp=rss](https://www.cbc.ca/news/canada/british-columbia/doukhobor-apology-new-westminster-1.7100982?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T09:00:00+00:00

<img alt="A black-and-white photo of children behind a fence with a sign reading &apos;Trespassers will be prosecuted.&apos;" height="349" src="https://i.cbc.ca/1.7101045.1706741506!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/doukhobors-new-denver.jpg" title="It is estimated 200 Doukhobor children were removed from their families, with many being placed at New Denver facility survivors describe as a &apos;prison.&apos;" width="620" /><p>Up to 200 children of members of the Sons of Freedom religious sect were forcibly taken by the province, with many held in a camp in the B.C. Interior in the 1950s.</p>

## Company that had 3 secret cryptocurrency mines must pay $400K, cease operations in Alberta
 - [https://www.cbc.ca/news/canada/edmonton/green-block-mining-settlement-utilities-commission-1.7099790?cmp=rss](https://www.cbc.ca/news/canada/edmonton/green-block-mining-settlement-utilities-commission-1.7099790?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T09:00:00+00:00

<img alt="Shipping containers are seen through a fence." height="349" src="https://i.cbc.ca/1.6142009.1706658315!/fileImage/httpImage/image.jpeg_gen/derivatives/16x9_620/link-global-bitcoin-mine-sturgeon-county.jpeg" title="Link Global&apos;s bitcoin mining operation in Sturgeon County consists of four shipping containers filled with computer servers, running the calculations to &apos;mine&apos; the digital currency. A fifth shipping container was set up on site for possible future expansion." width="620" /><p>A Vancouver company has been ordered to pay more than $400,000 in penalties and legal expenses for having multiple unsanctioned cryptocurrency mines in Alberta. </p>

## Mom angry it took 2 Ontario hospital ER waits and 19 hours before teen underwent appendicitis surgery
 - [https://www.cbc.ca/news/canada/kitchener-waterloo/st-mary-s-general-hospital-grand-river-hospital-1.7100867?cmp=rss](https://www.cbc.ca/news/canada/kitchener-waterloo/st-mary-s-general-hospital-grand-river-hospital-1.7100867?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T08:10:42+00:00

<img alt="A photo of Julia Malott and her 17-year old daughter Angelina." height="349" src="https://i.cbc.ca/1.7100895.1706736108!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/julia-malott-s-17-year-old-daughter-angelina.jpg" title="Julia Malott (left) and her 17-year old daughter Angelina (right) had waited about 19 hours at two Kitchener emergency rooms on Sunday and Monday." width="620" /><p>Julia Malott says she's angry it took 19 hours — including waiting in emergency rooms in two hospitals in Kitchener, Ont. — to get care for her teenage daughter, who ended up having surgery for appendicitis.</p>

## 49 homeless encampments dismantled in Edmonton since lawsuit scrapped
 - [https://www.cbc.ca/news/canada/edmonton/49-homeless-encampments-dismantled-in-edmonton-since-lawsuit-scrapped-1.7100396?cmp=rss](https://www.cbc.ca/news/canada/edmonton/49-homeless-encampments-dismantled-in-edmonton-since-lawsuit-scrapped-1.7100396?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T08:00:00+00:00

<img alt="People in white suits move among belongings." height="349" src="https://i.cbc.ca/1.7071222.1703879183!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/alta-edmonton-encampment-20231229.jpg" title="Cleanup crews tear down homeless encampments in Edmonton on Friday, Dec. 29, 2023." width="620" /><p>Two weeks since a lawsuit challenging Edmonton's practice of dismantling homeless encampments was scrapped by a judge, nearly 50 encampments around the city have been torn down.</p>

## 'A societal issue': Drought-plagued Alberta braces for even worse conditions
 - [https://www.cbc.ca/news/canada/calgary/drought-alberta-rebecca-schulz-pincher-creek-1.7101179?cmp=rss](https://www.cbc.ca/news/canada/calgary/drought-alberta-rebecca-schulz-pincher-creek-1.7101179?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T04:00:43+00:00

<img alt="cattle on a parched field" height="349" src="https://i.cbc.ca/1.7101192.1706747083!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/cattle-climate-20230220.jpg" title="Cattle roam in a field near Pigeon Lake in central Alberta in 2022. Experts and the provincial government fear this year&apos;s drought conditions could be historically bad, and require drastic conservation measures." width="620" /><p>Rivers and reservoirs are at low levels never recorded. Alberta is working on its emergency plan and "water sharing" deals. A disastrously dry 2024 is already bringing back the "we're all in this together" message we heard not long ago.</p>

## CSIS chief to face questions about sharing secret intelligence with foreign interference inquiry
 - [https://www.cbc.ca/news/politics/foreign-interference-inquiry-vigneault-cse-pco-1.7100577?cmp=rss](https://www.cbc.ca/news/politics/foreign-interference-inquiry-vigneault-cse-pco-1.7100577?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T04:00:00+00:00

<img alt="A man in a dark suit speaks into a microphone." height="349" src="https://i.cbc.ca/1.6661318.1677762855!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/david-vigneault-csis-emergencies-act.JPG" title="Canadian Security Intelligence Service (CSIS) Director David Vigneault has said a foreign agent registry would be a useful tool for combatting foreign election interference." width="620" /><p>The head of Canada's spy agency and other senior intelligence officials are set to testify today as the inquiry probing allegations of foreign election interference continues to wrestle with the question of how much sensitive information — if any — it can share with the public.</p>

## Canada's Greener Homes program is ending. Thousands of layoffs could follow
 - [https://www.cbc.ca/news/canada/calgary/bakx-canada-greener-homes-grant-retrofit-application-layoffs-1.7100748?cmp=rss](https://www.cbc.ca/news/canada/calgary/bakx-canada-greener-homes-grant-retrofit-application-layoffs-1.7100748?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T04:00:00+00:00

<img alt="An energy assessor looks at a furnace and writes down information on a piece of paper." height="349" src="https://i.cbc.ca/1.7100819.1706733637!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/energy-assessor.jpg" title="Thousands of energy assessors could lose their jobs when the federal government&apos;s Canada Greener Homes grant ends." width="620" /><p>As the federal government's popular Canada Greener Homes grant program comes to a close, the energy audit industry could crumble with businesses across the country warning of mass layoffs in the months ahead.</p>

## Consumers look to Value Village for a bargain. Many are finding 'ridiculous' markups
 - [https://www.cbc.ca/news/business/consumers-look-to-value-village-for-a-bargain-many-are-finding-ridiculous-markups-1.7101270?cmp=rss](https://www.cbc.ca/news/business/consumers-look-to-value-village-for-a-bargain-many-are-finding-ridiculous-markups-1.7101270?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T04:00:00+00:00

<img alt="A Value Village store in Toronto’s east end is pictured on Jan. 31, 2024." height="349" src="https://i.cbc.ca/1.7101278.1706752792!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/value-village-danforth.jpg" title="A Value Village store in Toronto’s east end is pictured on Jan. 31, 2024." width="620" /><p>For years, Canadians have relied on Value Village to buy used goods for cheaper than other retailers. It’s one of the biggest and most popular thrift store chains in the country. Now some customers are accusing the company of massive markups on their items.</p>

## National dental care plan registration expands today to cover seniors 72 and older
 - [https://www.cbc.ca/news/politics/dental-care-plan-expansion-72-to-76-years-1.7100722?cmp=rss](https://www.cbc.ca/news/politics/dental-care-plan-expansion-72-to-76-years-1.7100722?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T04:00:00+00:00

<img alt="close up of dental hygenist working on patient" height="349" src="https://i.cbc.ca/1.7071071.1703871963!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/dental-hygenist-closeup.jpg" title="" width="620" /><p>Seniors aged 72 and older are eligible as of today to register for Canada's national dental care plan, but dentists still can't sign up for the program — even though they're supposed to start taking patients in just a few months.</p>

## Stigma of mental illness clouds MAID expansion, patient and psychiatrist say
 - [https://www.cbc.ca/news/health/maid-mental-illness-health-1.7101021?cmp=rss](https://www.cbc.ca/news/health/maid-mental-illness-health-1.7101021?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T04:00:00+00:00

<img alt="A young woman with long hair, wearing jeans and sneakers, sits on a bench with her face in her hands, as if in despair. " height="349" src="https://i.cbc.ca/1.2701729.1706744309!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/anxious-teen.jpg" title="A new study from local researchers has found walk-in therapy clinics are more effective at helping people work through their problems than traditional sessions." width="620" /><p>Canadians suffering from debilitating mental illness cannot yet legally qualify for medical assistance in dying, unlike almost all others with severe illnesses — a restriction some advocates feel is rooted in stigma.</p>

## Task force rejects calls for special employment status for Jewish, Muslim public servants
 - [https://www.cbc.ca/news/politics/employment-equity-act-jews-muslims-1.7100784?cmp=rss](https://www.cbc.ca/news/politics/employment-equity-act-jews-muslims-1.7100784?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T04:00:00+00:00

<img alt="A white man points his finger while standing among a group of people." height="349" src="https://i.cbc.ca/1.6904182.1689129724!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/question-period-20230330.jpg" title="Minister of Labour Seamus O&apos;Regan rises during Question Period in the House of Commons on Parliament Hill in Ottawa on Thursday, March 30, 2023." width="620" /><p>Months before the eruption of the Israel-Hamas war ramped up ethic and religious tensions in many Canadian communities, a government task force rejected requests to recognize Muslim and Jewish public servants as separate groups facing systemic workplace barriers, CBC News has learned.</p>

## What we've learned about the PWHL's 6 teams over league's 1st month
 - [https://www.cbc.ca/sports/hockey/pwhl/pwhl-weekly-roundup-first-month-season-1.7101019?cmp=rss](https://www.cbc.ca/sports/hockey/pwhl/pwhl-weekly-roundup-first-month-season-1.7101019?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-canada
 - date published: 2024-02-01T04:00:00+00:00

<img alt="A hockey player in a white Boston jersey with green lettering skates along the boards and high fives her teammates after scoring a goal." height="349" src="https://i.cbc.ca/1.7101055.1706741952!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/pwhl-boston-vs-ottawa.jpg" title="PWHL - Boston vs Ottawa January 24, 2024 Photo by: Andrea Cardin/Freestyle Photography/PWHL" width="620" /><p>More than half of the PWHL’s first 22 games have been decided by just one goal, with overtime or a shootout needed in eight — a sign of parity across the league.</p>

