# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## Woman and 2 young daughters in a hospital after 'corrosive substance' attack in London
 - [https://japantoday.com/category/world/a-woman-and-her-2-young-daughters-are-in-a-hospital-after-a-%27corrosive-substance%27-attack-in-london](https://japantoday.com/category/world/a-woman-and-her-2-young-daughters-are-in-a-hospital-after-a-%27corrosive-substance%27-attack-in-london)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:43:00+00:00

A woman and her two young daughters had a corrosive substance thrown on them in London, where they were receiving treatment at a hospital Thursday, police said.
The…

## Climate activist Greta Thunberg goes on trial in London for blocking oil and gas conference
 - [https://japantoday.com/category/world/greta-thunberg-has-gone-on-trial-over-a-london-climate-protest-outside-an-oil-and-gas-conference](https://japantoday.com/category/world/greta-thunberg-has-gone-on-trial-over-a-london-climate-protest-outside-an-oil-and-gas-conference)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:42:52+00:00

Climate activist Greta Thunberg spoke defiantly about her mission outside court Thursday on the first day of her trial for refusing to leave a protest that blocked the…

## Northern Ireland to restore government after UK parliament approves deal
 - [https://japantoday.com/category/world/northern-ireland-to-restore-government-after-uk-parliament-approves-deal](https://japantoday.com/category/world/northern-ireland-to-restore-government-after-uk-parliament-approves-deal)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:42:44+00:00

Northern Ireland is set to elect a government on Saturday for the first time in two years after the British parliament agreed to revamp post-Brexit trade rules to…

## Disney appeals dismissal of free speech lawsuit as DeSantis says company should 'move on'
 - [https://japantoday.com/category/world/disney-appeals-dismissal-of-free-speech-lawsuit-as-desantis-says-company-should-%27move-on%27](https://japantoday.com/category/world/disney-appeals-dismissal-of-free-speech-lawsuit-as-desantis-says-company-should-%27move-on%27)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:42:37+00:00

Disney on Thursday appealed a judge's dismissal of its free speech lawsuit over what it described as Gov. Ron DeSantis' retaliatory takeover of Walt Disney World's governing district,…

## Biden imposes sanctions over 'intolerable' Israeli settler violence
 - [https://japantoday.com/category/world/biden-imposes-sanctions-over-%27intolerable%27-israeli-settler-violence](https://japantoday.com/category/world/biden-imposes-sanctions-over-%27intolerable%27-israeli-settler-violence)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:42:28+00:00

The United States on Thursday imposed sanctions on four Israeli settlers as President Joe Biden said violence against Palestinian civilians in the West Bank had reached intolerable levels.…

## Top UK diplomat says Britain could recognize a Palestinian state before a peace deal with Israel
 - [https://japantoday.com/category/world/top-uk-diplomat-says-britain-could-recognize-a-palestinian-state-before-a-peace-deal-with-israel](https://japantoday.com/category/world/top-uk-diplomat-says-britain-could-recognize-a-palestinian-state-before-a-peace-deal-with-israel)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:42:18+00:00

Britain’s top diplomat said Thursday that his country could officially recognize a Palestinian state after a cease-fire in Gaza without waiting for the outcome of what could be…

## Gunmen take hostages at U.S. company's Turkish factory in apparent protest of Gaza war
 - [https://japantoday.com/category/world/gunmen-take-hostages-at-us-company%27s-turkish-factory-in-apparent-protest-of-gaza-war](https://japantoday.com/category/world/gunmen-take-hostages-at-us-company%27s-turkish-factory-in-apparent-protest-of-gaza-war)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:42:10+00:00

Two gunmen took seven hostages at a factory owned by U.S. company Procter &amp; Gamble in northwest Turkey on Thursday, according to media reports, apparently in protest of…

## Farmers create chaos outside EU summit and wrest some promises of relief
 - [https://japantoday.com/category/world/horns-blaring-and-engines-roaring-100s-of-tractors-bring-farmers%27-plight-to-an-eu-summit](https://japantoday.com/category/world/horns-blaring-and-engines-roaring-100s-of-tractors-bring-farmers%27-plight-to-an-eu-summit)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:42:02+00:00

Farmers burned bales of hay, threw eggs and firecrackers at police — and wrested some promises of relief from European leaders on Thursday, the culmination of weeks of…

## U.S. hints large response to Iran-backed militias imminent as Houthi rebels target another ship
 - [https://japantoday.com/category/world/explosion-strikes-near-vessel-in-the-red-sea-off-yemen-as-houthi-rebel-attacks-continue](https://japantoday.com/category/world/explosion-strikes-near-vessel-in-the-red-sea-off-yemen-as-houthi-rebel-attacks-continue)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:41:49+00:00

U.S. Defense Secretary Lloyd Austin said Thursday it's time to further disable Iran-backed militias that have struck at U.S. forces and ships in the Middle East and the…

## Analysis shows destruction and possible buffer zone along Gaza Strip's border with Israel
 - [https://japantoday.com/category/world/analysis-shows-destruction-and-possible-buffer-zone-along-gaza-strip%27s-border-with-israel](https://japantoday.com/category/world/analysis-shows-destruction-and-possible-buffer-zone-along-gaza-strip%27s-border-with-israel)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:41:39+00:00

Satellite photos show new demolition along a 1-kilometer-deep path on the Gaza Strip’s border with Israel, according an analysis by The Associated Press and expert reports. The destruction…

## EU agrees on massive Ukraine aid deal in 'message' to Putin
 - [https://japantoday.com/category/world/eu-strikes-50-bn-euro-ukraine-aid-deal-as-orban-backs-down](https://japantoday.com/category/world/eu-strikes-50-bn-euro-ukraine-aid-deal-as-orban-backs-down)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:41:25+00:00

European Union leaders on Thursday overcame months of opposition from Hungarian leader Viktor Orban to agree 50 billion euros ($54 billion) of aid for Ukraine, in a move…

## Sebastian Korda gives U.S. a 1-0 lead over Ukraine in the Davis Cup
 - [https://japantoday.com/category/sports/chris-eubanks-is-replacing-an-injured-taylor-fritz-for-the-us-davis-cup-team-against-ukraine](https://japantoday.com/category/sports/chris-eubanks-is-replacing-an-injured-taylor-fritz-for-the-us-davis-cup-team-against-ukraine)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:40:58+00:00

Sebastian Korda gave the United States a 1-0 lead against Ukraine in Davis Cup qualifying by hitting six of his 16 aces in the last two games along…

## NBA hands out $75,000 fine to 76ers and $25,000 fine to Pelicans for injury reporting violations
 - [https://japantoday.com/category/sports/nba-hands-out-75-000-fine-to-76ers-and-25-000-fine-to-pelicans-for-injury-reporting-violations](https://japantoday.com/category/sports/nba-hands-out-75-000-fine-to-76ers-and-25-000-fine-to-pelicans-for-injury-reporting-violations)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:40:49+00:00

The Philadelphia 76ers were handed a $75,000 fine for failing to include Joel Embiid on their injury report “in an accurate and timely manner” before their Saturday game…

## World Aquatics Championships begin in Doha, but many top swimmers are staying home
 - [https://japantoday.com/category/sports/world-aquatics-championships-begin-in-doha-but-many-top-swimmers-are-staying-home](https://japantoday.com/category/sports/world-aquatics-championships-begin-in-doha-but-many-top-swimmers-are-staying-home)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:40:41+00:00

With all eyes on the Paris Olympics, the World Aquatics Championships feel more like a nuisance than the second-most important event on the swimming calendar.
Given the unusual…

## FIA-commissioned report takes aim at social media companies for not curbing online abuse in sports
 - [https://japantoday.com/category/sports/fia-commissioned-report-takes-aim-at-social-media-companies-for-not-curbing-online-abuse-in-sports](https://japantoday.com/category/sports/fia-commissioned-report-takes-aim-at-social-media-companies-for-not-curbing-online-abuse-in-sports)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:40:30+00:00

An FIA-commissioned report on online abuse in sports released Thursday suggests social media companies should do more to curb targeted attacks toward athletes, officials and even fans.
The…

## Patrick Mahomes and Brock Purdy are chasing greatness and the greatest in Tom Brady and Joe Montana
 - [https://japantoday.com/category/sports/patrick-mahomes-and-brock-purdy-are-chasing-greatness-and-the-greatest-in-tom-brady-and-joe-montana](https://japantoday.com/category/sports/patrick-mahomes-and-brock-purdy-are-chasing-greatness-and-the-greatest-in-tom-brady-and-joe-montana)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:40:08+00:00

Patrick Mahomes is chasing Tom Brady. Brock Purdy is playing in the shadow of Joe Montana.
Winning the Super Bowl would be another major step for either quarterback.…

## U.S., Japan conduct joint naval drills
 - [https://japantoday.com/category/national/us-japan-conduct-joint-naval-drills](https://japantoday.com/category/national/us-japan-conduct-joint-naval-drills)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:40:05+00:00

The U.S. and Japanese navies held joint exercises in the Philippine Sea this week, in a show of force as tensions with China and North Korea rise.
Washington…

## Lewis Hamilton leaving Mercedes for Ferrari in 2025
 - [https://japantoday.com/category/sports/lewis-hamilton-could-switch-to-ferrari-for-2025-season-reports](https://japantoday.com/category/sports/lewis-hamilton-could-switch-to-ferrari-for-2025-season-reports)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:39:41+00:00

Seven-time Formula One world champion Lewis Hamilton will make a surprise switch to Ferrari next year, after Mercedes announced Thursday he would leave the team at the end…

## Japan's Kagiyama, Chiba lead competition at Four Continents
 - [https://japantoday.com/category/sports/japan%27s-kagiyama-chiba-lead-competition-at-four-continents](https://japantoday.com/category/sports/japan%27s-kagiyama-chiba-lead-competition-at-four-continents)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:39:28+00:00

Japan's Yuma Kagiyama took a comfortable lead in the men's event at the Four Continents figure skating championship in Shanghai on Thursday, continuing his strong return from injury…

## Goalkeeping errors threaten Japan's Asian Cup hopes
 - [https://japantoday.com/category/sports/goalkeeping-woes-threaten-japan%27s-asian-cup-hopes](https://japantoday.com/category/sports/goalkeeping-woes-threaten-japan%27s-asian-cup-hopes)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:39:16+00:00

Japan's Asian Cup risks being fatally undermined by coach Hajime Moriyasu's reliance on an error-prone rookie goalkeeper and he has left himself with no convincing alternatives.
The pre-tournament…

## Japan, China, S Korea 3-way summit likely to be held in May or later
 - [https://japantoday.com/category/politics/japan-china-s.-korea-3-way-summit-likely-to-be-held-in-may-or-later](https://japantoday.com/category/politics/japan-china-s.-korea-3-way-summit-likely-to-be-held-in-may-or-later)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:38:25+00:00

Japan, China and South Korea are likely to hold their trilateral summit in May or later, with Beijing carefully watching the political situations in its two neighbors in…

## Annette Bening named Harvard's Hasty Pudding Woman of the Year
 - [https://japantoday.com/category/entertainment/annette-bening-named-harvard%27s-hasty-pudding-woman-of-the-year](https://japantoday.com/category/entertainment/annette-bening-named-harvard%27s-hasty-pudding-woman-of-the-year)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:37:53+00:00

Annette Bening, a two-time Golden Globe winner who recently received her fifth Oscar nomination, was named Thursday as the 2024 Woman of the Year by Harvard University’s Hasty…

## Netflix unveils 2024 slate led by sci-fi from 'Thrones' creators
 - [https://japantoday.com/category/entertainment/netflix-unveils-2024-slate-led-by-sci-fi-from-%27thrones%27-creators](https://japantoday.com/category/entertainment/netflix-unveils-2024-slate-led-by-sci-fi-from-%27thrones%27-creators)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:36:29+00:00

Netflix is betting on its ambitious new sci-fi series from the creators of &quot;Game of Thrones&quot; to help extend its streaming dominance in 2024, as the company unveiled…

## Lunar night puts Japan's lander back to sleep
 - [https://japantoday.com/category/national/lunar-night-puts-japan%27s-lander-back-to-sleep](https://japantoday.com/category/national/lunar-night-puts-japan%27s-lander-back-to-sleep)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:34:55+00:00

After a brief awakening, Japan's moon lander is out of action again but will resume its mission if it survives the two-week lunar night, the space agency said…

## Mount Fuji climbers from Yamanashi side to be charged ¥2,000 as tourism rises
 - [https://japantoday.com/category/national/mt.-fuji-climbers-to-face-2-000-yen-fees-from-summer-as-tourism-rises](https://japantoday.com/category/national/mt.-fuji-climbers-to-face-2-000-yen-fees-from-summer-as-tourism-rises)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:34:21+00:00

Climbers ascending Mount Fuji from the most commonly used trail in Yamanashi Prefecture will be charged 2,000 yen from this summer to ease congestion at the landmark mountain…

## Tokyo fish market opens seafood restaurants, spa complex to attract more visitors
 - [https://japantoday.com/category/national/Tokyo-fish-market-opens-seafood-restaurants-spa-complex-to-attract-more-visitors](https://japantoday.com/category/national/Tokyo-fish-market-opens-seafood-restaurants-spa-complex-to-attract-more-visitors)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:33:54+00:00

Tokyo's fish market on Thursday opened a long-awaited outer section with Japanese-style seafood restaurants and a spa for relaxation, as the wholesale venue that has struggled since relocating…

## Fatigue sets in for Japan earthquake survivors facing long road to recovery
 - [https://japantoday.com/category/national/fatigue-sets-in-for-japan-earthquake-survivors-facing-long-road-to-recovery](https://japantoday.com/category/national/fatigue-sets-in-for-japan-earthquake-survivors-facing-long-road-to-recovery)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:33:36+00:00

Moments after a magnitude 7.6 earthquake struck Ishikawa Prefecture on New Year's Day, Yoshimi Tomita was trapped in the dark under the roof of her collapsed house, feeling…

## Snowboard halfpipe
 - [https://japantoday.com/category/picture-of-the-day/snowboard-halfpipe](https://japantoday.com/category/picture-of-the-day/snowboard-halfpipe)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T21:04:06+00:00

In this photo provided by Olympic Information Services, Rise Kudo of Japan competes in the men's snowboard halfpipe qualification Run 2 at the Welli Hilli Park Ski Resort…

## One month on, Japan quake survivors, businesses struggle to rebuild
 - [https://japantoday.com/category/national/focus-one-month-on-japan-quake-survivors-businesses-struggle-to-rebuild](https://japantoday.com/category/national/focus-one-month-on-japan-quake-survivors-businesses-struggle-to-rebuild)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T10:22:36+00:00

Kenji Kusunoki still does not know how to go about rebuilding his life after his izakaya (pub) was completely destroyed in the powerful earthquake that hit central Japan…

## ANA planes collide at Osaka airport; no one hurt
 - [https://japantoday.com/category/national/urgent-ana-planes-collide-at-osaka-airport-no-one-hurt](https://japantoday.com/category/national/urgent-ana-planes-collide-at-osaka-airport-no-one-hurt)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T10:19:23+00:00

Two All Nippon Airways airplanes experienced a minor collision on Thursday at an airport straddling Osaka and Hyogo prefectures in western Japan, but none of the passengers or…

## Trump vows to block Nippon Steel's acquisition of U.S. Steel if he's elected
 - [https://japantoday.com/category/politics/trump-vows-to-block-nippon-steel%27s-acquisition-of-u.s.-steel](https://japantoday.com/category/politics/trump-vows-to-block-nippon-steel%27s-acquisition-of-u.s.-steel)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T07:41:39+00:00

Former U.S. President Donald Trump said Wednesday he will thwart Nippon Steel Corp's bid to acquire United States Steel Corp if he returns to the White House after…

## Japan soccer player Ito denies sexual assault allegation
 - [https://japantoday.com/category/crime/update1-football-japan-player-ito-denies-sexual-assault-allegation](https://japantoday.com/category/crime/update1-football-japan-player-ito-denies-sexual-assault-allegation)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T07:34:31+00:00

Japan soccer player Junya Ito has denied an accusation by two women that he sexually assaulted them last year and filed a criminal complaint for false allegations on…

## New Zealand strippers march on parliament for legal protections
 - [https://japantoday.com/category/world/new-zealand-strippers-march-on-parliament-for-legal-protections](https://japantoday.com/category/world/new-zealand-strippers-march-on-parliament-for-legal-protections)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T07:20:16+00:00

A group of New Zealand strippers took their fight for better employment rights to parliament on Thursday, demanding widespread reforms to the adult entertainment industry.
Brandishing placards that…

## Hong Kong convicts four over 2019 legislature storming
 - [https://japantoday.com/category/world/hong-kong-convicts-four-over-2019-legislature-storming](https://japantoday.com/category/world/hong-kong-convicts-four-over-2019-legislature-storming)
 - RSS feed: https://japantoday.com/feed
 - date published: 2024-02-01T04:07:48+00:00

Four Hong Kong men were convicted of rioting Thursday over the storming and ransacking of the city's legislature in 2019, part of a pro-democracy movement that posed an…

