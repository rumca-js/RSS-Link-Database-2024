# Source:Spikey Bits, URL:https://spikeybits.com/feed, language:en-US

## Dominate 40k With The Top Army Lists From Dark Sphere GT
 - [https://spikeybits.com/2024/02/dominate-40k-with-the-top-army-lists-from-dark-sphere-gt.html](https://spikeybits.com/2024/02/dominate-40k-with-the-top-army-lists-from-dark-sphere-gt.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T20:30:58+00:00

<p><p><a href="https://spikeybits.com/?p=454227&amp;preview=true"><img alt="Top-3-army-lists-40k-wal-hor-2" class="aligncenter wp-image-336328 size-full" height="451" src="https://spikeybits.com/wp-content/uploads/2020/09/88c11b51-top-3-army-lists-40k-wal-hor-2.jpg" width="740" /></a>Don&#8217;t miss the top army lists from the Dark Sphere GT; check out the highest-finishing Warhammer 40k armies from the event.</p>
<p><span id="more-454227"></span></p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p><span>The tournament</p>
<p><a href="https://spikeybits.com/2024/02/dominate-40k-with-the-top-army-lists-from-dark-sphere-gt.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/dominate-40k-with-the-top-army-lists-from-dark-sphere-gt.html">Dominate 40k With The Top Army Lists From Dark Sphere GT</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Professor X Powers Into MCP With New Awesome New Rules!
 - [https://spikeybits.com/2024/02/professor-x-powers-into-mcp-with-new-awesome-new-rules.html](https://spikeybits.com/2024/02/professor-x-powers-into-mcp-with-new-awesome-new-rules.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T19:30:45+00:00

<p><p><span><a href="https://spikeybits.com/wp-content/uploads/2024/02/Professor-X-MCP-rules.png"><img alt="Professor X MCP rules" class="aligncenter size-full wp-image-454566" height="616" src="https://spikeybits.com/wp-content/uploads/2024/02/Professor-X-MCP-rules.png" width="1057" /></a>You might want to put on Magneto&#8217;s helmet, as </span>Professor X is powering his way into MCP with new rules in the latest expansion pack alongside</p>
<p><a href="https://spikeybits.com/2024/02/professor-x-powers-into-mcp-with-new-awesome-new-rules.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/professor-x-powers-into-mcp-with-new-awesome-new-rules.html">Professor X Powers Into MCP With New Awesome New Rules!</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## A New Light Sentinel Sprints into Horus Heresy: Solar Auxilia Hermes
 - [https://spikeybits.com/2024/02/a-new-light-sentinel-sprints-into-horus-heresy-solar-auxilia-hermes.html](https://spikeybits.com/2024/02/a-new-light-sentinel-sprints-into-horus-heresy-solar-auxilia-hermes.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T18:30:11+00:00

<p><p><a href="https://spikeybits.com/?p=454576&amp;preview=true"><img alt="Solar Auxilia Light Sentinel 3" class="aligncenter wp-image-454587 size-full" height="825" src="https://spikeybits.com/wp-content/uploads/2024/02/Solar-Auxilia-Light-Sentinel-3.png" width="1488" /></a>The plastic Solar Auxilia are getting another reinforcement as GW just revealed the new Hermes Light Sentinel for Horus Heresy!</p>
<p><span id="more-454576"></span></p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p><p><a href="https://spikeybits.com/2024/02/a-new-light-sentinel-sprints-into-horus-heresy-solar-auxilia-hermes.html"></a></p><p><a href="https://spikeybits.com/2024/02/a-new-light-sentinel-sprints-into-horus-heresy-solar-auxilia-hermes.html"></a><a href="https://spikeybits.com"></a></p>

## Score $21,000 For Painting Miniatures At Adepticon 2024!
 - [https://spikeybits.com/2024/02/score-21000-for-painting-miniatures-at-adepticon-2024.html](https://spikeybits.com/2024/02/score-21000-for-painting-miniatures-at-adepticon-2024.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T17:30:04+00:00

<p><p><a href="https://spikeybits.com/?p=454379&amp;preview=true"><img alt="massive prize painting competition" class="aligncenter wp-image-454555 size-full" height="608" src="https://spikeybits.com/wp-content/uploads/2024/02/massive-prize-painting-competition.png" width="1101" /></a>Score a piece of the massive $21,000 prize pool for the 2024 Resin Beast painting competition at AdeptiCon 2024!</p>
<p><span id="more-454379"></span></p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
<p><span>Every</p>
<p><a href="https://spikeybits.com/2024/02/score-21000-for-painting-miniatures-at-adepticon-2024.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/score-21000-for-painting-miniatures-at-adepticon-2024.html">Score $21,000 For Painting Miniatures At Adepticon 2024!</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## 40k’s New Lion El’Jonson Dark Angels Primarch Model & Rules
 - [https://spikeybits.com/2024/02/40ks-new-lion-eljonson-dark-angels-primarch-model-rules.html](https://spikeybits.com/2024/02/40ks-new-lion-eljonson-dark-angels-primarch-model-rules.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T17:01:43+00:00

<p><p><a href="https://spikeybits.com/2023/12/rumors-lion-eljonson-in-40k-possible-rules.html"><img alt="Lion El&#x2019;Jonson model warhammer 40k returned lore lion eljonson lion eljonson primarch model 40k returns warhammer 40k title" class="aligncenter wp-image-453660 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2023/12/lion-eljonson-primarch-model-40k-returns-warhammer-40k-title.png" width="1280" /></a>After years of rumors, The Dark Angels got a Lion El&#x2019;Jonson Primarch</p>
<p><a href="https://spikeybits.com/2024/02/40ks-new-lion-eljonson-dark-angels-primarch-model-rules.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/40ks-new-lion-eljonson-dark-angels-primarch-model-rules.html">40k&#8217;s New Lion El’Jonson Dark Angels Primarch Model &#038; Rules</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Warhammer & 40k New Releases Roadmap For 2024 UPDATED
 - [https://spikeybits.com/2024/02/gw-new-releases-roadmap-for-september-beyond.html](https://spikeybits.com/2024/02/gw-new-releases-roadmap-for-september-beyond.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T17:01:28+00:00

<p><p><a href="https://spikeybits.com/wp-content/uploads/2023/12/gw-rumors-and-new-releases-warhammer-40k-age-of-sigmar-horus-heresy-the-old-world-necromunda.png"><img alt="gw rumors and new releases warhammer 40k age of sigmar horus heresy the old world necromunda notext games workshop new releases warhammer roadmap" class="aligncenter wp-image-451936 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2023/12/gw-rumors-and-new-releases-warhammer-40k-age-of-sigmar-horus-heresy-the-old-world-necromunda.png" width="1280" /></a>Here is the latest Games Workshop new</p>
<p><a href="https://spikeybits.com/2024/02/gw-new-releases-roadmap-for-september-beyond.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/gw-new-releases-roadmap-for-september-beyond.html">Warhammer &#038; 40k New Releases Roadmap For 2024 UPDATED</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## GW’s New CFO Job Requirements Are Just Wild
 - [https://spikeybits.com/2024/02/gws-new-cfo-job-requirements-are-just-wild.html](https://spikeybits.com/2024/02/gws-new-cfo-job-requirements-are-just-wild.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T17:01:09+00:00

<p><p><a href="https://spikeybits.com/?p=454200&amp;preview=true"><img alt="Games-Workshop-hiring-to-wants-you" class="aligncenter wp-image-342242 size-full" height="410" src="https://spikeybits.com/wp-content/uploads/2020/11/22a7ad3b-games-workshop-hiring-to-wants-you.jpg" width="740" /></a>Games Workshop is looking for a new CFO now; here are all the wild job requirements they are looking to hire for!</p>
<p><span id="more-454200"></span></p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></div>
</p>
<p>We</p>
<p><a href="https://spikeybits.com/2024/02/gws-new-cfo-job-requirements-are-just-wild.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/gws-new-cfo-job-requirements-are-just-wild.html">GW&#8217;s New CFO Job Requirements Are Just Wild</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## GW Announces Ban On Ordering Warhammer In America
 - [https://spikeybits.com/2024/02/gw-announces-a-ban-on-ordering-in-america.html](https://spikeybits.com/2024/02/gw-announces-a-ban-on-ordering-in-america.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T16:30:03+00:00

<p><p><a href="https://spikeybits.com/?p=454556&amp;preview=true"><img alt="Warhammer Old World gw orderd banned games workshop" class="aligncenter wp-image-454570 size-full" height="720" src="https://spikeybits.com/wp-content/uploads/2024/02/Warhammer-Old-World-gw-orderd-banned-games-workshop.png" width="1280" /></a><span>Get ready for a huge Warhammer product drought, as Games Workshop announced a ban on ordering to stores in North America amid</p>
<p><a href="https://spikeybits.com/2024/02/gw-announces-a-ban-on-ordering-in-america.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/gw-announces-a-ban-on-ordering-in-america.html">GW Announces Ban On Ordering Warhammer In America</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Last Day To Score 30% OFF Battle Foam Site Wide!
 - [https://spikeybits.com/2024/02/last-day-to-score-30-off-battle-foam-site-wide.html](https://spikeybits.com/2024/02/last-day-to-score-30-off-battle-foam-site-wide.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T15:30:16+00:00

<p><p><a href="https://spikeybits.com/?p=454498&amp;preview=true"><img alt="Battle foam Vip Sale" class="aligncenter wp-image-454510" height="729" src="https://spikeybits.com/wp-content/uploads/2024/02/Screenshot_70.png" width="1270" /></a>Battle Foam is having a huge sitewide sale, dishing out double discounts for all their VIP members, including new ones!</p>
<p><span id="more-454498"></span></p>
<p>Battle Foam is known for its high-quality</p>
<p><a href="https://spikeybits.com/2024/02/last-day-to-score-30-off-battle-foam-site-wide.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/last-day-to-score-30-off-battle-foam-site-wide.html">Last Day To Score 30% OFF Battle Foam Site Wide!</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Fearless Templar: Army of One
 - [https://spikeybits.com/2024/02/fearless-templar-army-of-one.html](https://spikeybits.com/2024/02/fearless-templar-army-of-one.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T14:30:07+00:00

<p><p><a href="https://spikeybits.com/?p=451672&amp;preview=true"><img alt="these boys will make sure to do all it takes" class="aligncenter wp-image-451673" height="704" src="https://spikeybits.com/wp-content/uploads/2023/12/these-boys-will-make-sure-to-do-all-it-takes-e1706110748810.png" width="1203" /></a>If you have just joined the Space Marines, prepare to get all the worst jobs, as that&#8217;s the way the grimdark</p>
<p><a href="https://spikeybits.com/2024/02/fearless-templar-army-of-one.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/fearless-templar-army-of-one.html">Fearless Templar: Army of One</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## “Big Things Happening” Henry Cavill Updates Warhammer 40k Fans
 - [https://spikeybits.com/2024/02/big-things-happening-henry-cavill-updates-warhammer-40k-fans.html](https://spikeybits.com/2024/02/big-things-happening-henry-cavill-updates-warhammer-40k-fans.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T13:05:53+00:00

<p><p><a href="https://spikeybits.com/?p=454369&amp;preview=true"><img alt="henry cavill warhammer movie amazon official games workshop director emperor show series title" class="aligncenter wp-image-454332 size-full" height="678" src="https://spikeybits.com/wp-content/uploads/2024/01/henry-cavill-warhammer-movie-amazon-official-games-workshop-director-emperor-show-series-title.png" width="1200" /></a>Henry Cavill updated Warhammer fans about the 40k TV show series for Amazon while doing press tours</p>
<p><a href="https://spikeybits.com/2024/02/big-things-happening-henry-cavill-updates-warhammer-40k-fans.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/big-things-happening-henry-cavill-updates-warhammer-40k-fans.html">&#8220;Big Things Happening&#8221; Henry Cavill Updates Warhammer 40k Fans</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## These Nostalgic Colors Are Perfect For Your Old World Minis!
 - [https://spikeybits.com/2024/02/these-nostalgic-colors-are-perfect-for-your-old-world-minis.html](https://spikeybits.com/2024/02/these-nostalgic-colors-are-perfect-for-your-old-world-minis.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T10:30:14+00:00

<p><p><span><a href="https://spikeybits.com/?p=453957&amp;preview=true"><img alt="Nostalgia '94 Glaze Set feature" class="aligncenter wp-image-431432" height="476" src="https://spikeybits.com/wp-content/uploads/2023/04/Nostalgia-94-Glaze-Set-feature.png" width="750" /></a>War Colours Nostalgia paints are perfect for any Warhammer The Old World minis as they match the old Citadel Paint line from the 80s and 90s!</span></p>
<p><span></p>
<p><a href="https://spikeybits.com/2024/02/these-nostalgic-colors-are-perfect-for-your-old-world-minis.html">Read More</a></p>
<p>The post <a href="https://spikeybits.com/2024/02/these-nostalgic-colors-are-perfect-for-your-old-world-minis.html">These Nostalgic Colors Are Perfect For Your Old World Minis!</a> appeared first on <a href="https://spikeybits.com">Spikey Bits</a>.</p>

## Crimson Squats: Armies on Parade
 - [https://spikeybits.com/2024/02/crimson-squats-armies-on-parade.html](https://spikeybits.com/2024/02/crimson-squats-armies-on-parade.html)
 - RSS feed: https://spikeybits.com/feed
 - date published: 2024-02-01T09:30:07+00:00

<p><p>&nbsp;</p>
<p><a href="https://spikeybits.com/?p=449244&amp;preview=true"><img alt="Votann Feature" class="aligncenter wp-image-453872 size-full" height="657" src="https://spikeybits.com/wp-content/uploads/2024/01/Votann-Feature.png" width="1020" /></a>The Space Marines once long ago had a cousin that was known as the squat; well, they have made a real BIG comeback!</p>
<p><span id="more-449244"></span></p>
<div id="humix-vid-ezAutoMatch" style="width: 640px; height: 360px;"></p><p><a href="https://spikeybits.com/2024/02/crimson-squats-armies-on-parade.html"></a></p><p><a href="https://spikeybits.com/2024/02/crimson-squats-armies-on-parade.html"></a><a href="https://spikeybits.com"></a></p>

