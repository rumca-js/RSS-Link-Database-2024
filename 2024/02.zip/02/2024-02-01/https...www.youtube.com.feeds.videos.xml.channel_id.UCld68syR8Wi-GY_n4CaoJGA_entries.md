# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Canonical's Abandoned Free Software Distro
 - [https://www.youtube.com/watch?v=4KLDtlED6ss](https://www.youtube.com/watch?v=4KLDtlED6ss)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2024-02-01T20:00:01+00:00

Nowadays Ubuntu isn't known as a free software distro but it's not like Canonical had always planned to only do this, there actually was a free software version of Ubuntu at one point

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
FSF Distros: https://www.gnu.org/distros/free-distros.en.html
Debian: https://www.debian.org/
Ubuntu: https://ubuntu.com/
Announcement: https://lists.ubuntu.com/archives/ubuntu-devel/2005-November/013261.html
WhoIs gnubuntu: https://who.is/whois/gnubuntu.org
Ubuntu Libre: https://wiki.ubuntu.com/Ubuntu-libre
Hardware Logic Interview: https://web.archive.org/web/20070620150238/http://hardwarelogic.com/news/143/ARTICLE/1410/2007-05-28.html
gnewsense: https://web.archive.org/web/20061103225831/http://www.gnewsense.org/
Gutsy Gibbon: htt

