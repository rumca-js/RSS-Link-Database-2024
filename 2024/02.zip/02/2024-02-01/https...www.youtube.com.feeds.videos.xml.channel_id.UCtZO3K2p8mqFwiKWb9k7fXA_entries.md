# Source:Techaltar, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA, language:en-US

## A new internet is forming (& Meta wants to control it)
 - [https://www.youtube.com/watch?v=R3ptZ1W-FRA](https://www.youtube.com/watch?v=R3ptZ1W-FRA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtZO3K2p8mqFwiKWb9k7fXA
 - date published: 2024-02-01T09:00:29+00:00

Get Nebula with a 40% discount using my link (sponsored): https://go.nebula.tv/techaltar

Interview - Eugen Rochko (Mastodon CEO): https://nebula.tv/videos/techaltar-the-future-of-mastodon-eugen-rochko-ceo
Interview - Matt Mullenweg (Automattic CEO, Tumblr, Wordpress, etc.): https://nebula.tv/videos/techaltar-tumblr-wordpress-embracing-activitypub-automattic-ceo-interview
Interview - Matej Svancer (OpenVibe CEO): https://nebula.tv/videos/techaltar-building-a-client-app-for-the-fediverse-openvibe-interview
Interview - John & Seb (SFBA.social Mastodon Instance operators): https://nebula.tv/videos/techaltar-running-a-mastodon-instance-with-38000-users-sfbasocial-interivew

This video on Nebula: https://nebula.tv/videos/techaltar-a-new-internet-is-forming-meta-wants-to-control-it

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  

►►► Video description ◄◄◄  

A federated internet is forming. It's built on open protocols like ActivityPub & connects services like Mastodon, Threads, Pixelfed, Tumblr, Word

