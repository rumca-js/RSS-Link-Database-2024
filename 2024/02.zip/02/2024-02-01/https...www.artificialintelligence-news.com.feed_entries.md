# Source:AI News, URL:https://www.artificialintelligence-news.com/feed, language:en-GB

## Experts from 30 nations will contribute to global AI safety report
 - [https://www.artificialintelligence-news.com/2024/02/01/experts-from-30-nations-contribute-global-ai-safety-report](https://www.artificialintelligence-news.com/2024/02/01/experts-from-30-nations-contribute-global-ai-safety-report)
 - RSS feed: https://www.artificialintelligence-news.com/feed
 - date published: 2024-02-01T17:00:29+00:00

<p>Leading experts from 30 nations across the globe will advise on a landmark report assessing the capabilities and risks of AI systems.  The International Scientific Report on Advanced AI Safety aims to bring together the best scientific research on AI safety to inform policymakers and future discussions on the safe development of AI technology. The<a class="excerpt-read-more" href="https://www.artificialintelligence-news.com/2024/02/01/experts-from-30-nations-contribute-global-ai-safety-report/" title="ReadExperts from 30 nations will contribute to global AI safety report">... Read more &#187;</a></p>
<p>The post <a href="https://www.artificialintelligence-news.com/2024/02/01/experts-from-30-nations-contribute-global-ai-safety-report/">Experts from 30 nations will contribute to global AI safety report</a> appeared first on <a href="https://www.artificialintelligence-news.com">AI News</a>.</p>

