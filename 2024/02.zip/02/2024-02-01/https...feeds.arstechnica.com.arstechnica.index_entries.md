# Source:ArsTechnica, URL:https://feeds.arstechnica.com/arstechnica/index, language:en-US

## Cops arrest 17-year-old suspected of hundreds of swattings nationwide
 - [https://arstechnica.com/?p=2000672](https://arstechnica.com/?p=2000672)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T21:32:41+00:00

Police traced swatting calls to teen’s home IP addresses.

## FCC to declare AI-generated voices in robocalls illegal under existing law
 - [https://arstechnica.com/?p=2000577](https://arstechnica.com/?p=2000577)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T20:20:01+00:00

Robocalls with AI voices to be regulated under Telephone Consumer Protection Act.

## Google’s Pixel storage issue fix requires developer tools and a terminal
 - [https://arstechnica.com/?p=2000532](https://arstechnica.com/?p=2000532)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T20:10:28+00:00

Automatic updates broke your phone; the fix is a highly technical manual process.

## Hulu, Disney+ password crackdown kills account sharing on March 14
 - [https://arstechnica.com/?p=2000510](https://arstechnica.com/?p=2000510)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T19:49:18+00:00

New subscribers are already banned from sharing logins outside their household.

## By launching on Starship, the Starlab station can get to orbit in one piece
 - [https://arstechnica.com/?p=2000537](https://arstechnica.com/?p=2000537)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T19:37:56+00:00

"Building and integrating in space is very expensive."

## Clownfish “count” white stripes to determine if an invader is friend or foe
 - [https://arstechnica.com/?p=2000427](https://arstechnica.com/?p=2000427)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T19:07:26+00:00

They attacked similar fish with three stripes more often than those with one or two stripes.

## Palworld has biggest 3rd-party Game Pass launch ever as players near 20 million
 - [https://arstechnica.com/?p=2000487](https://arstechnica.com/?p=2000487)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T17:43:54+00:00

To compare, <em>Pokémon Scarlet</em> and <em>Violet</em> have sold over 23 million copies each.

## Elon Musk proposes Tesla move to Texas after Delaware judge voids $56 billion pay
 - [https://arstechnica.com/?p=2000506](https://arstechnica.com/?p=2000506)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T17:30:44+00:00

Musk is sick of Delaware judges, says shareholders will vote on move to Texas.

## eBay to pay $59M after DOJ ties pill press sales to fentanyl drug rings
 - [https://arstechnica.com/?p=2000489](https://arstechnica.com/?p=2000489)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T16:42:43+00:00

It's DOJ’s first e-commerce settlement under the Controlled Substances Act.

## For the first time NASA has asked industry about private missions to Mars
 - [https://arstechnica.com/?p=2000209](https://arstechnica.com/?p=2000209)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T13:50:32+00:00

"I'm curious to see if this request brings many new players to the table."

## Exploring Reddit’s third-party app environment 7 months after the APIcalypse
 - [https://arstechnica.com/?p=1992717](https://arstechnica.com/?p=1992717)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T12:30:19+00:00

Apollo dev: "I don’t believe Reddit’s leadership... cares about developers anymore."

## The right bacteria turn farms into carbon sinks
 - [https://arstechnica.com/?p=2000444](https://arstechnica.com/?p=2000444)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T12:15:27+00:00

A company works with farmers to treat fields with bacteria that sequester carbon.

## Biogen dumps dubious Alzheimer’s drug after profit-killing FDA scandal
 - [https://arstechnica.com/?p=2000435](https://arstechnica.com/?p=2000435)
 - RSS feed: https://feeds.arstechnica.com/arstechnica/index
 - date published: 2024-02-01T00:17:13+00:00

The move ends a long saga that "ended up doing a lot of actual damage."

