# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## Can it run Doom?: Gut bacteria edition
 - [https://arstechnica.com/gaming/2024/01/can-it-run-doom-gut-bacteria-edition](https://arstechnica.com/gaming/2024/01/can-it-run-doom-gut-bacteria-edition)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

Sure, teach the bacteria to run and gun. What could go wrong?

## Companies put convenience and speed above security in app deployments
 - [https://betanews.com/2024/01/31/companies-put-convenience-and-speed-above-security-in-app-deployments](https://betanews.com/2024/01/31/companies-put-convenience-and-speed-above-security-in-app-deployments)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

Should I have warned you before posting this shocking news?

## Creating Dynamic Menus with Jetpack Compose
 - [https://dev.to/ardakazanci/creating-dynamic-menus-with-jetpack-compose-68a](https://dev.to/ardakazanci/creating-dynamic-menus-with-jetpack-compose-68a)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

Kotlin and Jetpack Compose stand at the forefront of modern Android application development.

## Google Project IDX adds Android emulators, iOS simulator
 - [https://www.infoworld.com/article/3712542/google-project-idx-adds-android-ios-simulators.html](https://www.infoworld.com/article/3712542/google-project-idx-adds-android-ios-simulators.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

Experimental AI-powered cloud-based development environment introduces previews on mobile platforms and templates for Astro, Go, Node.js, and Python.

## Introducing Xamarin.Forms Templates
 - [https://egvijayanand.in/2024/01/26/introducing-xamarin-forms-templates](https://egvijayanand.in/2024/01/26/introducing-xamarin-forms-templates)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

Project and Item templates in both CLI and Visual Studio IDE to finish your work in quick time.

## Microsoft Copilot on Android & iOS is now faster, gets GPTs and Pro subscription access
 - [https://www.windowslatest.com/2024/01/31/microsoft-copilot-on-android-ios-is-now-faster-gets-gpts-and-pro-subscription-access](https://www.windowslatest.com/2024/01/31/microsoft-copilot-on-android-ios-is-now-faster-gets-gpts-and-pro-subscription-access)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

Microsoft Copilot Pro has finally arrived for everyone on Android and iOS.

## Microsoft seeks Rust developers to rewrite core C# code
 - [https://www.theregister.com/2024/01/31/microsoft_seeks_rust_developers](https://www.theregister.com/2024/01/31/microsoft_seeks_rust_developers)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

If only they had R#

## Microsoft’s legal department allegedly silenced an engineer who raised concerns about DALL-E 3
 - [https://www.engadget.com/microsofts-legal-department-allegedly-silenced-an-engineer-who-raised-concerns-about-dall-e-3-215953212.html](https://www.engadget.com/microsofts-legal-department-allegedly-silenced-an-engineer-who-raised-concerns-about-dall-e-3-215953212.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

Ixnay onyay ethay aiyay apocalypseyay

## Prompt users to update to your latest app version
 - [https://android-developers.googleblog.com/2024/01/prompt-users-to-update-to-your-latest-app-version-google-play.html](https://android-developers.googleblog.com/2024/01/prompt-users-to-update-to-your-latest-app-version-google-play.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

We are introducing a new tool that will prompt these users to update, bringing them closer to the app experience you intended to deliver.

## Semron wants to replace chip transistors with ‘memcapacitors’
 - [https://techcrunch.com/2024/01/30/semron-wants-to-replace-chip-transistors-with-memcapacitors](https://techcrunch.com/2024/01/30/semron-wants-to-replace-chip-transistors-with-memcapacitors)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

The article doesn't answer the important question: can they run DOOM?

## Testing the MSVC compiler backend
 - [https://devblogs.microsoft.com/cppblog/testing-the-msvc-compiler-backend](https://devblogs.microsoft.com/cppblog/testing-the-msvc-compiler-backend)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

For those who doubted

## Uno Platform 5.1 : Live Wizard for Rider & VS Code users, New Controls, Perf improvements and more.
 - [https://platform.uno/blog/uno-platform-5-1](https://platform.uno/blog/uno-platform-5-1)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

"One love, we get to share it"

## iOS 17.4: Apple continues work on AI-powered Siri and Messages features, with help from ChatGPT
 - [https://9to5mac.com/2024/01/26/apple-siri-chatgpt-ios-18-development](https://9to5mac.com/2024/01/26/apple-siri-chatgpt-ios-18-development)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2024-02-01T05:00:00+00:00

Apple is widely expected to unveil major new artificial intelligence features with iOS 18 in June.

