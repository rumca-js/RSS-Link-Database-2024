# Source:Insight News Media, URL:https://insightnews.media/feed/, language:en-US

## EU agreed to allocate $50 billion for Ukraine, all members backed the deal
 - [https://insightnews.media/eu-agreed-to-allocate-50-billion-for-ukraine-all-members-backed-the-deal](https://insightnews.media/eu-agreed-to-allocate-50-billion-for-ukraine-all-members-backed-the-deal)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2024-02-01T21:13:44+00:00

<p>On February 1, EU leaders agreed to provide Ukraine with 50 billion euros in macrofinancial aid. Charles Michel, President of the European Council, stated that [&#8230;]</p>
<p>The post <a href="https://insightnews.media/eu-agreed-to-allocate-50-billion-for-ukraine-all-members-backed-the-deal/">EU agreed to allocate $50 billion for Ukraine, all members backed the deal</a> appeared first on <a href="https://insightnews.media">Insight News Media</a>.</p>

