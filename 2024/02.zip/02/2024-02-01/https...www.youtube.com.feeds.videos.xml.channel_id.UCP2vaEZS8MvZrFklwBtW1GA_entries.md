# Source:Home Repair Tutor, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA, language:en

## Tub Shower Valve MISTAKES and How You Can AVOID Them
 - [https://www.youtube.com/watch?v=kvtl6nZhLSI](https://www.youtube.com/watch?v=kvtl6nZhLSI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA
 - date published: 2024-02-01T12:00:45+00:00

This video shares tub shower valve mistakes and how you can avoid them. For more tips and tricks visit homerepairtutor.com

#howto #diy #bathroomremodel 

Tub Shower Valve Mistakes and How You Can Avoid Them
0:00 Tub shower valve mistakes
0:21 How to choose tub shower valve
1:56 Shower valve depth
3:55 Tub Shower height
4:47 Tub shower valve plumbing
5:43 PEX A for shower valves
6:18 How to install drop ear for shower head
7:08 How to secure copper tub spout 

These supplies were used in our video:
-Delta R10000-PFT-MF (PEX A)

Some product links may be Amazon affiliate links. As an Amazon Associate, we earn from qualifying purchases at no additional cost to you. 

Want our newest DIY videos? Subscribe to our channel and hit the notification bell to see every upload. We upload new videos every Saturday.

Disclaimer:
Videos produced by Home Repair Tutor are provided for informational, educational, & entertainment purposes only. Some of these projects, materials, and techniques

