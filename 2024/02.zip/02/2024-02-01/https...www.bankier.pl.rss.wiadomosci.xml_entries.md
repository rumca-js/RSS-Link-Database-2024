# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Wall Street udaje, że nic się nie stało
 - [https://www.bankier.pl/wiadomosc/Wall-Street-udaje-ze-nic-sie-nie-stalo-8689091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wall-Street-udaje-ze-nic-sie-nie-stalo-8689091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T21:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/a/d29d93a7d5f16e-948-568-150-179-2850-1709.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rynek jakby próbował przekazać wiadomość, że brak oczekiwanej
obniżki stóp procentowych już w marcu tak naprawdę niewiele zmienia.</p>

## Gaz-System rozbuduje terminal FSRU. Wybrano dostawcę gazowców
 - [https://www.bankier.pl/wiadomosc/Gaz-System-rozbuduje-terminal-FSRU-Wybrano-dostawce-gazowcow-8689067.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gaz-System-rozbuduje-terminal-FSRU-Wybrano-dostawce-gazowcow-8689067.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T19:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/885e576963662a-948-568-0-52-1156-693.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Gaz-System dokonał wyboru najkorzystniejszej oferty na dostarczenie i obsługę jednostki FSRU, która ma pełnić funkcję terminalu regazyfikacyjnego LNG w Zatoce Gdańskiej - podała spółka w czwartkowym komunikacie. Dodano, że kontynuowane będą rozmowy dot. warunków czarteru z Mitsui O.S.K. Lines.</p>

## Biały Dom ogłosił sankcje przeciwko 4 obywatelom Izraela
 - [https://www.bankier.pl/wiadomosc/Bialy-Dom-oglosil-sankcje-przeciwko-4-obywatelom-Izraela-8689059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bialy-Dom-oglosil-sankcje-przeciwko-4-obywatelom-Izraela-8689059.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T18:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/3abadb52a3efa8-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent USA Joe Biden podpisał w czwartek rozporządzenie wykonawcze nakładające sankcje finansowe na ekstremistycznych osadników żydowskich zaangażowanych w ataki na Palestyńczyków na Zachodnim Brzegu Jordanu. Jest to już drugi pakiet restrykcji przeciwko izraelskim ekstremistom.</p>

## Orban: Dostaliśmy gwarancje, że węgierskie pieniądze nie trafią na Ukrainę
 - [https://www.bankier.pl/wiadomosc/Orban-Dostalismy-gwarancje-ze-wegierskie-pieniadze-nie-trafia-na-Ukraine-8689033.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orban-Dostalismy-gwarancje-ze-wegierskie-pieniadze-nie-trafia-na-Ukraine-8689033.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T17:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/2/76cb1b569ece06-948-568-0-13-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W końcu wynegocjowaliśmy mechanizm kontroli gwarantujący, że środki zostaną rozsądnie wykorzystane i węgierskie pieniądze nie zostaną wysłane na Ukrainę – powiedział premier Węgier Viktor Orban po czwartkowym szczycie Rady Europejskiej ws. pomocy finansowej dla Kijowa.</p>

## Waszyngton zatwierdził plany odwetowych ataków na irańskie obiekty w Iraku i Syrii
 - [https://www.bankier.pl/wiadomosc/Waszyngton-zatwierdzil-plany-odwetowych-atakow-na-iranskie-obiekty-w-Iraku-i-Syrii-8688994.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Waszyngton-zatwierdzil-plany-odwetowych-atakow-na-iranskie-obiekty-w-Iraku-i-Syrii-8688994.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T16:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/81a3dd439e8e69-945-560-15-209-2985-1790.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Plany amerykańskich ataków na irańskie obiekty w Iraku i Syrii zostały zatwierdzone - potwierdzili anonimowo amerykańscy urzędnicy, cytowani w czwartek przez CBS News.</p>

## Wyrzutnie rakiet dla fregat Miecznik. Jest porozumienie z Lockheed Martin
 - [https://www.bankier.pl/wiadomosc/Wyrzutnie-rakiet-dla-fregat-Miecznik-Jest-porozumienie-z-Lockheed-Martin-8688977.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wyrzutnie-rakiet-dla-fregat-Miecznik-Jest-porozumienie-z-Lockheed-Martin-8688977.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T16:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/9/7e42621c963ee6-948-568-0-142-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zawarliśmy dziś porozumienie z koncernem Lockheed Martin, od którego pozyskaliśmy dla trzech budowanych fregat Miecznik system pionowego startu VLS Mk 41 dla rodziny pocisków CAMM - poinformowała Polska Grupa Zbrojeniowa w czwartek.</p>

## GPW znów wśród liderów, mWIG40 i banki z rekordami. Orlen droższy po dymisji Obajtka
 - [https://www.bankier.pl/wiadomosc/GPW-znow-wsrod-liderow-mWIG40-i-banki-z-rekordami-Orlen-drozszy-po-dymisji-Obajtka-8688968.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/GPW-znow-wsrod-liderow-mWIG40-i-banki-z-rekordami-Orlen-drozszy-po-dymisji-Obajtka-8688968.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T16:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/b86f474ab95658-948-568-0-99-4403-2642.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kolejny dzień GPW prezentuje się lepiej od rynków bazowych. Indeksy rosną napędzane mocniejszy złotym, wynikami spółek, a w czwartek także informacją o dymisji prezesa Orlenu. Jest popyt na banki, których indeks poprawił historyczny szczyt, a raportowa seria spółek portfelowych z mWIG40 także szybko zaprowadziła go na nowy rekord.</p>

## Tusk: Polska będzie domagała się kolejnych sankcji wobec Rosji
 - [https://www.bankier.pl/wiadomosc/Tusk-Polska-bedzie-domagala-sie-kolejnych-sankcji-wobec-Rosji-8688952.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tusk-Polska-bedzie-domagala-sie-kolejnych-sankcji-wobec-Rosji-8688952.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T16:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/f/7a62dc73c47ddf-948-568-0-82-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska na pewno będzie domagała się możliwie szerokiego zestawu w nowym pakiecie sankcji wobec Rosji - zapowiedział w czwartek w Brukseli premier Donald Tusk, pytany o rozpoczynające się konsultacje Komisji Europejskiej w sprawie 13. pakietu sankcji.</p>

## Rząd reaguje na protest rolników. Padł plan ustępstw
 - [https://www.bankier.pl/wiadomosc/Rzad-reaguje-na-protest-francuskich-rolnikow-Padl-plan-ustepstw-8688948.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-reaguje-na-protest-francuskich-rolnikow-Padl-plan-ustepstw-8688948.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T16:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/3e87d3ecd22440-948-568-0-129-3440-2063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wstrzymanie planu dotyczącego redukcji pestycydów, wzmocnienie kontroli żywności z importu i silniejsze egzekwowanie przepisów, chroniących producentów żywności przed zaniżaniem cen - takie środki zapowiedział w czwartek premier Francji Gabriel Attal w odpowiedzi na protesty rolników.</p>

## Skarb Państwa zgłosił Andrzeja Oślizło jako kandydata do składu RN PKO BP
 - [https://www.bankier.pl/wiadomosc/Skarb-Panstwa-zglosil-Andrzeja-Oslizlo-jako-kandydata-do-skladu-Rady-Nadzorczej-PKO-BP-8688933.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skarb-Panstwa-zglosil-Andrzeja-Oslizlo-jako-kandydata-do-skladu-Rady-Nadzorczej-PKO-BP-8688933.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T15:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/7/1bd0050844315c-948-568-13-192-2735-1641.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skarb Państwa, jako akcjonariusz, zgłosił Andrzeja Oślizło jako kandydata do składu Rady Nadzorczej PKO BP - poinformował bank w komunikacie. NWZ zwołane jest na 2 lutego 2024 r.</p>

## Iran rozpoczął budowę 4 elektrowni jądrowych
 - [https://www.bankier.pl/wiadomosc/Iran-rozpoczal-budowe-4-elektrowni-jadrowych-8688902.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Iran-rozpoczal-budowe-4-elektrowni-jadrowych-8688902.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T15:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/8/18777774ab3434-948-568-0-0-2784-1670.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Iran rozpoczął budowę czterech kolejnych elektrowni jądrowych na południu kraju, których łączna moc ma wynieść 5 tys. megawatów - podała w czwartek irańska rządowa agencja IRNA cytowana przez agencję Associated Press.</p>

## Tusk: UE jest zjednoczona w wysiłku na rzecz pomocy Ukrainie
 - [https://www.bankier.pl/wiadomosc/Tusk-UE-jest-zjednoczona-w-wysilku-na-rzecz-pomocy-Ukrainie-8688897.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tusk-UE-jest-zjednoczona-w-wysilku-na-rzecz-pomocy-Ukrainie-8688897.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T15:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/f/c8d0569f970e33-948-568-0-194-2987-1792.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nastrój stał się wreszcie klarowny, UE jest zjednoczona w wysiłku na rzecz pomocy Ukrainie; zadecydnowaon o pomocy finansowej dla Ukrainy o wartości 50 mld euro i to bez zbędnej dyskusji - powiedział w czwartek w Brukseli premier Donald Tusk po szczycie Rady Europejskiej.</p>

## Zawieszenie broni w Strefie Gazy coraz bliżej? "Hamas musi mieć pewność"
 - [https://www.bankier.pl/wiadomosc/Zawieszenie-broni-w-Strefie-Gazy-coraz-blizej-Hamas-musi-miec-pewnosc-8688874.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zawieszenie-broni-w-Strefie-Gazy-coraz-blizej-Hamas-musi-miec-pewnosc-8688874.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T14:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/720ef227288d93-948-568-19-254-3891-2334.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Za wypuszczenie każdej z uprowadzonych do Strefy Gazy żołnierek organizacja terrorystyczna Hamas chce uwolnienia 150 palestyńskich więźniów - powiadomił w czwartek amerykański dziennik "Wall Street Journal".</p>

## Konieczny: Resort zdrowia planuje wznowienie Planu dla Chorób Rzadkich
 - [https://www.bankier.pl/wiadomosc/Konieczny-Resort-zdrowia-planuje-wznowienie-Planu-dla-Chorob-Rzadkich-8688863.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Konieczny-Resort-zdrowia-planuje-wznowienie-Planu-dla-Chorob-Rzadkich-8688863.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T14:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/b/db3502de0d4521-888-532-136-0-888-532.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Zdrowia pracuje nad tym, aby Rada Ministrów mogła jak najszybciej przyjąć uchwałę o wznowieniu Planu dla Chorób Rzadkich - poinformował w czwartek w Sejmie wiceminister zdrowia Wojciech Konieczny.</p>

## Strajki na niemieckich lotniskach. Związki chcą jego przedłużenia
 - [https://www.bankier.pl/wiadomosc/Strajki-na-niemieckich-lotniskach-Zwiazki-chca-jego-przedluzenia-8688851.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Strajki-na-niemieckich-lotniskach-Zwiazki-chca-jego-przedluzenia-8688851.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T14:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/98444a207c61eb-945-567-56-22-1443-866.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W nocy ze środy na czwartek rozpoczął się strajk pracowników jedenastu największych niemieckich lotnisk. Akcja miała zakończyć się w czwartek wieczorem, ale związek zawodowy Verdi nawołuje pracowników z Hamburga do przedłużenia protestu o kolejną dobę – poinformowała dpa.</p>

## Polacy chętnie odwiedzali centra handlowe w 2023 roku
 - [https://www.bankier.pl/wiadomosc/Polacy-chetnie-odwiedzali-centra-handlowe-w-2023-roku-8688787.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-chetnie-odwiedzali-centra-handlowe-w-2023-roku-8688787.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T14:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/2f0247fbb763b0-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pomimo trudnej sytuacji gospodarczej Polacy chętniej odwiedzali centra handlowe - w 2023 r. odwiedzalność galerii handlowych wzrosła o 4,6 proc. wobec roku 2022, do 10,8 osób miesięcznie na metr kwadratowy - wynika z badania przeprowadzonego na zlecenie Polskiej Rady Centrów Handlowych.</p>

## Licznik prezesa Obajtka. Jest drugi, a z liderem odejdą tego samego dnia
 - [https://www.bankier.pl/wiadomosc/Licznik-prezesa-Obajtka-Jest-drugi-a-z-liderem-odejda-tego-samego-dnia-8688825.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Licznik-prezesa-Obajtka-Jest-drugi-a-z-liderem-odejda-tego-samego-dnia-8688825.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T14:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/234d5b95053f40-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Daniel Obajtek nie ma najdłuższego stażu z grona osób obecnie sprawujących funkcję prezesa giełdowej spółki pod kontrolą Skarbu Państwa. Wszystko na to wskazuje, że zarówno on, jak i lider zestawienia pożegnają się ze stanowiskiem tego samego dnia. Dla prezesa Obajtka będzie to równo 6 lat od momentu powołania.  </p>

## Chiny ostrzegają Ukrainę. Poszło o "sponsorów wojny"
 - [https://www.bankier.pl/wiadomosc/Chiny-ostrzegaja-Ukraine-Poszlo-o-sponsorow-wojny-8688820.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-ostrzegaja-Ukraine-Poszlo-o-sponsorow-wojny-8688820.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T13:59:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/ef423ef6a05251-948-568-0-269-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chińskie władze przestrzegły Ukrainę, że uznanie przez Kijów kilkunastu chińskich firm za "międzynarodowych sponsorów wojny" może mieć negatywny wpływ na stosunki między państwami – informuje w czwartek agencja Reutera, powołując się na dwa ukraińskie źródła wysokiego szczebla.</p>

## Podwyżki dla nauczycieli nie tak prędko? "Może się zdarzyć, że będą dopiero od kwietnia"
 - [https://www.bankier.pl/wiadomosc/Podwyzki-dla-nauczycieli-nie-tak-predko-Moze-sie-zdarzyc-ze-beda-dopiero-od-kwietnia-8688786.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podwyzki-dla-nauczycieli-nie-tak-predko-Moze-sie-zdarzyc-ze-beda-dopiero-od-kwietnia-8688786.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T13:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/292ef2d1cef627-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podwyżki wynagrodzeń dla nauczycieli prawdopodobnie nie przyjdą tak, jak zakładaliśmy, od marca z wyrównaniem od stycznia. Może się tak zdarzyć, że to będzie dopiero od kwietnia - powiedziała w czwartek minister edukacji Barbara Nowacka po spotkaniu ze związkami zawodowymi.</p>

## Ruch kontenerowców na Morzu Czerwonym spadł o 30 proc.
 - [https://www.bankier.pl/wiadomosc/Ruch-kontenerowcow-na-Morzu-Czerwonym-spadl-o-30-proc-8688772.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ruch-kontenerowcow-na-Morzu-Czerwonym-spadl-o-30-proc-8688772.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T13:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/f/395104edd92114-945-560-0-14-1737-1042.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ruch kontenerowców na Morzu Czerwonym zmniejszył się o 30 proc. w stosunku do listopada ubiegłego roku - poinformował szef wydziału Bliskiego Wschodu i Azji Centralnej Międzynarodowego Funduszu Walutowego (MFW), Jihad Azour, dodając, że liczba przewozów spadła szczególnie od początku stycznia.</p>

## Rolnicy protestują przed Parlamentem Europejskim. "Bronimy przyszłości europejskiego rolnictwa"
 - [https://www.bankier.pl/wiadomosc/Rolnicy-protestuja-przed-Parlamentem-Europejskim-Bronimy-przyszlosci-europejskiego-rolnictwa-8688759.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rolnicy-protestuja-przed-Parlamentem-Europejskim-Bronimy-przyszlosci-europejskiego-rolnictwa-8688759.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T12:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/22898951ea0067-948-568-15-239-2937-1762.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czasie gdy unijni przywódcy negocjowali rewizję wieloletnich ram unijnego budżetu, pod Parlamentem Europejskim w Brukseli trwał duży protest rolników. Do stolicy Belgii w czwartek wjechało co najmniej tysiąc ciągników, a pod PE zgromadziło się parę tysięcy osób. Rolnicy m.in. z Belgii i Włoch domagali się wyrzucenia do kosza unijnych regulacji nakładających restrykcyjne wymagania na ich gospodarstwa.</p>

## Kto zostanie nowym prezydentem? Trzaskowski, Morawiecki i Hołownia idą "łeb w łeb"
 - [https://www.bankier.pl/wiadomosc/Kto-zostanie-nowym-prezydentem-Trzaskowski-Morawiecki-i-Holownia-ida-leb-w-leb-8688746.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kto-zostanie-nowym-prezydentem-Trzaskowski-Morawiecki-i-Holownia-ida-leb-w-leb-8688746.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T12:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/b/e1fec779406b2d-948-568-30-0-1941-1165.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poparcie w wyborach prezydenckim dla Rafała Trzaskowskiego deklaruje 25,8 proc. badanych, Mateusz Morawiecki może liczyć na 24,9 proc. głosów, a Szymon Hołownia na 24,6 proc. - wynika z sondażu IBRIS dla Onetu. Portal podaje, że Trzaskowski stracił 8,8 proc., a Hołownia zyskał 12,9 proc.</p>

## Hołownia: Zaproponujemy rozwiązanie, które odpartyjni zarządy spółek
 - [https://www.bankier.pl/wiadomosc/Holownia-Zaproponujemy-rozwiazanie-ktore-odpartyjni-zarzady-spolek-8688745.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Holownia-Zaproponujemy-rozwiazanie-ktore-odpartyjni-zarzady-spolek-8688745.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T12:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/d72b0a6f94b990-948-568-0-0-3883-2330.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lider Polski 2050 Szymon Hołownia zapowiedział w czwartek, że jego formacja zaproponuje rozwiązanie ustawowe, które odpartyjni zarządy spółek. Według marszałka Sejmu "czas na konkursy i profesjonalne zarządzanie naszym majątkiem".</p>

## Filmowcy walczą o tantiemy z internetu. Składają zawiadomienie w prokuraturze
 - [https://www.bankier.pl/wiadomosc/Filmowcy-walcza-o-tantiemy-z-internetu-Skladaja-zawiadomienie-w-prokuraturze-8688718.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Filmowcy-walcza-o-tantiemy-z-internetu-Skladaja-zawiadomienie-w-prokuraturze-8688718.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T12:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/4/06759e2bfd05eb-945-560-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />SFP złożyło w czwartek do Prokuratury Okręgowej w Warszawie zawiadomienie o podejrzeniu popełnienia przestępstwa przez przedstawicieli rządu PiS. Filmowcy zarzucają im zaniechanie wdrożenia dyrektywy wprowadzającej tantiemy z internetu i lekceważenie polskiej racji stanu.</p>

## Była chętna do cięcia stóp w Anglii, ale większość jednak za brakiem zmian
 - [https://www.bankier.pl/wiadomosc/Bank-Anglii-znow-zostawia-stopy-procentowe-najwyzej-od-2008-r-8688709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bank-Anglii-znow-zostawia-stopy-procentowe-najwyzej-od-2008-r-8688709.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T12:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/d/0c7e79dbb61882-948-568-157-382-2587-1552.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kolejny bank centralny utrzymał stopy procentowe na niezmienionym poziomie. Bank Anglii po raz czwarty z rzędu uznał, że obecny poziom stóp jest odpowiedni do sytuacji rynkowej. Jednak obserwowany spadek inflacji sprawia, że eksperci i rynek wyceniają kilka obniżek już w tym roku.    </p>

## Rosyjska rakieta pod lupą prokuratury. Wleciała na kilkanaście sekund nad Polskę
 - [https://www.bankier.pl/wiadomosc/Rosyjska-rakieta-pod-lupa-prokuratury-Wleciala-na-kilkanascie-sekund-nad-Polske-8688706.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosyjska-rakieta-pod-lupa-prokuratury-Wleciala-na-kilkanascie-sekund-nad-Polske-8688706.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T11:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/62fe08323cd219-945-567-131-469-3330-1998.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W związku z niepokojącym zdarzeniem, do którego doszło 29 grudnia 2023 roku, informuję, że Dział Wojskowy Prokuratury Rejonowej w Lublinie wszczął śledztwo w sprawie naruszenia przestrzeni powietrznej RP przez niezidentyfikowany obiekt latający - poinformował rzecznik Prokuratury Okręgowej w Warszawie prok. Szymon Banna.</p>

## Nowy szef parlamentu w Tajwanie. Jest zwolennik zacieśniania współpracy z ChRL
 - [https://www.bankier.pl/wiadomosc/Nowy-szef-parlamentu-w-Tajwanie-Jest-zwolennik-zaciesniania-wspolpracy-z-ChRL-8688686.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowy-szef-parlamentu-w-Tajwanie-Jest-zwolennik-zaciesniania-wspolpracy-z-ChRL-8688686.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T11:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/0/2be06d7e00b368-948-568-397-305-2480-1488.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przewodniczącym Yuanu Legislacyjnego, parlamentu Tajwanu, został w czwartek kandydat Partii Nacjonalistycznej (KMT) Han Kuo-yu, który opowiada się za zacieśnianiem współpracy z ChRL. Zgodnie z prawem szef parlamentu ma wpływ na kluczowe obszary polityki, w tym budżet państwa.</p>

## Kosowo "wprowadziło" euro. To oficjalnie jedyna akceptowana waluta
 - [https://www.bankier.pl/wiadomosc/Kosowo-wprowadzilo-euro-To-oficjalnie-jedyna-akceptowana-waluta-8688667.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kosowo-wprowadzilo-euro-To-oficjalnie-jedyna-akceptowana-waluta-8688667.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T11:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/4/eab9e53d1606f9-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Euro jest od czwartku jedyną walutą oficjalnie akceptowaną w Kosowie. W okresie przejściowym w kraju będzie można jednak nadal płacić dinarami serbskimi, powszechnie używanymi w rejonach zamieszkiwanych przez Serbów.</p>

## Bomby GLSDB w drodze na front. Tak zapewnia dyplomacja USA
 - [https://www.bankier.pl/wiadomosc/Bomby-GLSDB-w-drodze-na-front-Tak-zapewnia-dyplomacja-USA-8688658.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bomby-GLSDB-w-drodze-na-front-Tak-zapewnia-dyplomacja-USA-8688658.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T11:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/7/1dca7020074239-948-568-975-112-1337-802.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wiceszefowa amerykańskiej dyplomacji Victoria Nuland oznajmiła w środę wieczorem w Kijowie, że pierwsza partia precyzyjnie naprowadzanych bomb Ground-Launched Small Diameter Bomb (GLSDB), przekazywanych Ukrainie przez USA, znajduje się już w drodze na front wojny z Rosją.</p>

## Prezydent o budżecie: Niedługo rząd będzie mógł realizować zobowiązania
 - [https://www.bankier.pl/wiadomosc/Prezydent-o-budzecie-Niedlugo-rzad-bedzie-mogl-realizowac-zobowiazania-8688653.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-o-budzecie-Niedlugo-rzad-bedzie-mogl-realizowac-zobowiazania-8688653.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T11:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/6deca95bb205e5-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Ustawa budżetowa niedługo wejdzie w życie. Chcę wyrazić satysfakcję, że rząd będzie mógł realizować zobowiązania, które podjął i wpisał do ustawy" - powiedział w czwartek prezydent Andrzej Duda. „To, co tu i teraz zostało zabezpieczone. To bardzo dobrze” – dodał.</p>

## CPK, armia i elektrownie jądrowe. Prezydent zwołuje radę gabinetową
 - [https://www.bankier.pl/wiadomosc/CPK-armia-i-elektrownie-jadrowe-Prezydent-zwoluje-rade-gabinetowa-8688650.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/CPK-armia-i-elektrownie-jadrowe-Prezydent-zwoluje-rade-gabinetowa-8688650.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T11:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/c/af13e6c58479b8-948-568-0-80-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"W czwartek wydam postanowienie o zwołaniu Rady Gabinetowej na 13 lutego na godz. 13" - poinformował prezydent Andrzej Duda. Chce omówić przyszłość planowanych przez poprzedni rząd inwestycji takich jak CPK i elektrownie atomowe oraz kontrakty wojskowe.</p>

## "Koniec ery Obajtka, ale początek jego problemów". Komentarze po odwołaniu prezesa Orlenu
 - [https://www.bankier.pl/wiadomosc/Koniec-ery-Obajtka-ale-poczatek-jego-problemow-Komentarze-po-odwolaniu-prezesa-Orlenu-8688645.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-ery-Obajtka-ale-poczatek-jego-problemow-Komentarze-po-odwolaniu-prezesa-Orlenu-8688645.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T11:05:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/ddc030d5fde0c5-948-568-0-0-1500-900.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dobry czwartek. Viktora Orbana dało się „przekonać”, Daniela Obajtka dało się odwołać. Jedziemy dalej - napisał premier Donald Tusk odnosząc sie do wydarzeń w Brukseli i w kraju.</p>

## Jest zgoda na unijny pakiet wsparcia dla Ukrainy. 27 przywódców zgodziło się 50 mld euro
 - [https://www.bankier.pl/wiadomosc/Jest-zgoda-na-unijny-pakiet-wsparcia-dla-Ukrainy-27-przywodcow-zgodzilo-sie-50-mld-eure-8688636.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jest-zgoda-na-unijny-pakiet-wsparcia-dla-Ukrainy-27-przywodcow-zgodzilo-sie-50-mld-eure-8688636.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T10:54:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/d/ca38a68d1aeab5-948-568-20-280-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Doszło do porozumienia na szczycie UE - wszystkich 27 przywódców zgodziło się na pakiet wsparcia dla Ukrainy w wysokości 50 miliardów euro w ramach budżetu UE - poinformował na platformie "X" szef Rady Europejskiej Charles Michel w czwartek.</p>

## Chile tnie ostro stopy procentowe
 - [https://www.bankier.pl/wiadomosc/Chile-tnie-ostro-stopy-procentowe-8688607.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chile-tnie-ostro-stopy-procentowe-8688607.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T10:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/ecbca8693dc076-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szybko spadająca inflacja pozwoliła chilijskiemu bankowi
centralnemu na kolejną ostrą redukcję stóp procentowych.</p>

## Rosja zamknęła ruch drogowy na przejściu granicznym do Estonii
 - [https://www.bankier.pl/wiadomosc/Rosja-zamknela-ruch-drogowy-na-przejsciu-granicznym-do-Estonii-8688594.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosja-zamknela-ruch-drogowy-na-przejsciu-granicznym-do-Estonii-8688594.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T10:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/bb937375654ddf-948-568-698-442-3237-1942.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosja zamknęła w nocy ze środy na czwartek ruch drogowy przez przejście graniczne w Iwangorodzie, po drugiej stronie granicy estońskiego przejścia w Narwie. Granicę w obu kierunkach będzie można przekraczać jedynie pieszo - podała telewizja ERR.</p>

## Kaufland zapowiada podwyżki. Tyle od stycznia wynosi pensja kasjerów
 - [https://www.bankier.pl/wiadomosc/Kaufland-zapowiada-podwyzki-Tyle-od-stycznia-wyniesie-pensja-kasjerow-8688578.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaufland-zapowiada-podwyzki-Tyle-od-stycznia-wyniesie-pensja-kasjerow-8688578.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T10:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/d/b9af1783b16954-948-569-31-13-1741-1045.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kaufland przeznaczy na podwyżki dla pracowników na stanowisku kasjer-sprzedawca ok. 110 mln zł - poinformował Kaufland w komunikacie prasowym. Od stycznia pensja kasjerów po podwyżkach wynosi od 4500 zł do 5500 zł brutto.
</p>

## Obajtek odwołany z funkcji prezesa Grupy Orlen. Rada Nadzorcza zdecydowała
 - [https://www.bankier.pl/wiadomosc/Obajtek-nie-jest-juz-prezesem-Grupy-Orlen-Rada-Nadzorcza-zdecydowala-8688556.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Obajtek-nie-jest-juz-prezesem-Grupy-Orlen-Rada-Nadzorcza-zdecydowala-8688556.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T09:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/22441deb6dec41-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Orlen poinformował o dymisji Daniela Obajtka z funkcji prezesa Grupy Orlen. W giełdowym komunikacie spółka wskazuje na decyzję rady nadzorczej, która miała w czwartek swoje zebranie. </p>

## Fundacja użytkująca dworek Daniela Obajtka miała starać się o darowiznę na remont od spółki skarbu państwa
 - [https://www.bankier.pl/wiadomosc/Luksus-w-dworku-Obajtka-Korty-basen-amfiteatr-8688528.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Luksus-w-dworku-Obajtka-Korty-basen-amfiteatr-8688528.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T09:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/a/06343b4a6b1c42-948-568-0-0-4475-2685.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fundacja użytkująca
zabytkowy dworek należący do Daniela Obajtka, prezesa PKN Orlen, zamierza wyremontować tę posiadłość. W
planach są m.in. korty tenisowe, basen, sala gimnastyczna oraz amfiteatr. Pieniądze
na ten cel miały pochodzić z darowizny ze środków spółki skarbu państwa – podało
Radio ZET.</p>

## Premier nie wyklucza wcześniejszych wyborów. "Jeśli prezydent będzie przeszkadzał"
 - [https://www.bankier.pl/wiadomosc/Premier-nie-wyklucza-wczesniejszych-wyborow-Jesli-prezydent-bedzie-przeszkadzal-8688533.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-nie-wyklucza-wczesniejszych-wyborow-Jesli-prezydent-bedzie-przeszkadzal-8688533.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T09:14:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/5/70c4c2876ea041-948-568-15-0-2985-1790.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Andrzej Duda co prawda podpisał ustawę budżetową, ale zapowiedział, że wszystkie ustawy uchwalone pod nieobecność w Sejmie Mariusza Kamińskiego i Macieja Wąsika będzie kierował do Trybunału Konstytucyjnego. Na odpowiedź premiera Donalda Tuska nie trzeba było długo czekać.</p>

## Złoty nadspodziewanie mocny. Kurs euro najniższy w tym roku
 - [https://www.bankier.pl/wiadomosc/Zloty-nadspodziewanie-mocny-Kurs-euro-najnizszy-w-tym-roku-8688525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zloty-nadspodziewanie-mocny-Kurs-euro-najnizszy-w-tym-roku-8688525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T09:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/1/3024705ee4ef4e-948-568-0-241-4592-2755.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro do złotego spadł do
najniższego poziomu od końcówki grudnia i to w dodatku na przekór niesprzyjającemu
otoczeniu globalnemu.</p>

## PKO BP i KNF reagują na wpis Oskara Szafarowicza. Młody działacz PiS ujawnił wrażliwe dane?
 - [https://www.bankier.pl/wiadomosc/PKO-BP-i-KNF-reaguja-na-wpis-Oskara-Szafarowicza-Mlody-dzialacz-PiS-ujawnil-wrazliwe-dane-8688500.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-BP-i-KNF-reaguja-na-wpis-Oskara-Szafarowicza-Mlody-dzialacz-PiS-ujawnil-wrazliwe-dane-8688500.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T08:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/f/ad46d30ccb19fc-948-568-0-10-3983-2390.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oskar Szafarowicz to młody działacz PiS-u, który za rządów Zjednoczonej 
Prawicy znalazł zatrudnienie w PKO BP. Co prawda z pracą w banku 
pożegnał się z końcem stycznia, alew jednym z ostatnich dni pracy 
poinformował na Twitterze, że "PKO BP osiągnął prawdopodobnie w minionym roku historyczny sukces finansowy (około 7 mld zł zysku)." W czym problem? W tym, że raport finansowy za cały ubiegły rok zostanie opublikowany dopiero w marcu.</p>

## Skarbówka zajęła pieniądze pięciolatki. Nie tyko świadczenie 500+
 - [https://www.bankier.pl/wiadomosc/Skarbowka-zajela-pieniadze-pieciolatki-Nie-tyko-swiadczenie-500-8688478.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skarbowka-zajela-pieniadze-pieciolatki-Nie-tyko-swiadczenie-500-8688478.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T07:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/871fb9109baffb-948-568-11-0-1488-893.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Arya Białek jest pięciolatką, która już zarabia 
pieniądze, pozując do zdjęć reklamowych. Jako dziecięca modelka była już twarzą wielu kampanii, m.in. 
Zalando, Nestle, Smyk czy Allegro. Teraz urząd skarbowy zajął jej 
świadczenie 500+.</p>

## Sąd uznał, że wynagrodzenie Muska to przesada. Miliarder chce przenieść spółkę
 - [https://www.bankier.pl/wiadomosc/Sad-uznal-ze-wynagrodzenie-Muska-to-przesada-Miliarder-zostal-bez-premii-8688475.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sad-uznal-ze-wynagrodzenie-Muska-to-przesada-Miliarder-zostal-bez-premii-8688475.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T07:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/4/09163179326026-948-568-0-89-2715-1628.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sędzia ze stanu Delaware unieważnił pakiet wynagrodzeń Elona Muska za pracę na stanowisku dyrektora generalnego Tesli wynoszący 56 miliardów dolarów, stając po stronie akcjonariusza spółki, który zgłosił, że wypłata miliardera była nieuczciwie wysoka.</p>

## Zysk netto grupy ING BSK w IV kw. wyniósł 1.270,8 mln zł, powyżej oczekiwań
 - [https://www.bankier.pl/wiadomosc/Zysk-netto-grupy-ING-BSK-w-IV-kw-wyniosl-1-270-8-mln-zl-powyzej-oczekiwan-8688457.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zysk-netto-grupy-ING-BSK-w-IV-kw-wyniosl-1-270-8-mln-zl-powyzej-oczekiwan-8688457.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T06:26:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/4472f5192a1f4e-915-548-85-82-915-548.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zysk netto grupy ING Banku Śląskiego w czwartym kwartale 2023 roku wzrósł do 1.270,8 mln zł z 665,9 mln zł rok wcześniej - poinformował bank we wstępnych danych. Wynik okazał się 27 proc. powyżej oczekiwań rynku na poziomie 999,3 mln zł.</p>

## Czy Polska będzie zestrzeliwać rosyjskie rakiety? Jest warunek
 - [https://www.bankier.pl/wiadomosc/Czy-Polska-bedzie-zestrzeliwac-rosyjskie-rakiety-Jest-warunek-8688428.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czy-Polska-bedzie-zestrzeliwac-rosyjskie-rakiety-Jest-warunek-8688428.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T05:37:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/e/6ed1a228aa97c0-948-568-56-0-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />69,3 proc. badanych uważa, że powinniśmy rozpocząć rozmowy z NATO i Ukrainą na temat objęcia obroną powietrzną przygranicznego terytorium Ukrainy, aby móc zestrzelić rosyjskie rakiety lecące w kierunku Polski – wynika z badania IBRiS dla "Rzeczpospolitej".</p>

## Szykowany dopalacz do e-aut. M.in. niższe podatki i inne ułatwienia
 - [https://www.bankier.pl/wiadomosc/Szykowany-dopalacz-do-e-aut-M-in-nizsze-podatki-i-inne-ulatwienia-8688422.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szykowany-dopalacz-do-e-aut-M-in-nizsze-podatki-i-inne-ulatwienia-8688422.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T05:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/7/7ea9fa26a40283-948-568-14-4-1963-1177.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Łącznie 120 zmian w przepisach ma spowodować, że Polacy chętniej przesiądą się do samochodów elektrycznych. Tak przynajmniej zakładają firmy i branżowe organizacje - pisze w czwartek "Rzeczpospolita", która dotarła do projektu w tej sprawie.</p>

## Obajtek dla "Pulsu Biznesu": Daję sobie miesiąc na zastanowienie, co będę robił
 - [https://www.bankier.pl/wiadomosc/Obajtek-dla-Pulsu-Biznesu-Daje-sobie-miesiac-na-zastanowienie-co-bede-robil-8688419.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Obajtek-dla-Pulsu-Biznesu-Daje-sobie-miesiac-na-zastanowienie-co-bede-robil-8688419.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T05:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/0ec22b06fd422e-948-568-0-39-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie podjąłem jeszcze wiążących decyzji. W spółce takiej jak Orlen musi być ciągłość, więc jestem do dyspozycji nowej rady nadzorczej, gdy dojdzie do zmian. Daję sobie mniej więcej miesiąc na to, by się zastanowić, co będę robił - mówi w wywiadzie dla czwartkowego "Pulsu Biznesu" prezes Orlenu Daniel Obajtek.</p>

## Kiepski czas dla IT? Kilkadziesiąt tysięcy pracowników straciło pracę
 - [https://www.bankier.pl/wiadomosc/Kiepski-czas-dla-IT-Kilkadziesiat-tysiecy-pracownikow-stracilo-prace-8688298.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kiepski-czas-dla-IT-Kilkadziesiat-tysiecy-pracownikow-stracilo-prace-8688298.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/b/45d0fe1b60ceda-948-568-90-0-3770-2261.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rok 2023 był czasem dużych zmian na rynku pracy w IT, zwłaszcza w
globalnych korporacjach. Pracę straciło ponad 262 tysiące zaskoczonych tym
specjalistów, o których jeszcze nie tak dawno firmy zaciekle walczyły,
prześcigając się w oferowanych zarobkach i benefitach. Co zmieniło się w ciągu
ostatnich miesięcy?</p>

## Od 1 lutego ZUS zacznie przyjmować wnioski o 800+ na nowy okres świadczeniowy
 - [https://www.bankier.pl/wiadomosc/Od-1-lutego-ZUS-zacznie-przyjmowac-wnioski-o-800-plus-na-nowy-okres-swiadczeniowy-8681096.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Od-1-lutego-ZUS-zacznie-przyjmowac-wnioski-o-800-plus-na-nowy-okres-swiadczeniowy-8681096.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/9f5e4e20748a20-948-568-0-44-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 1 lutego Zakład Ubezpieczeń Społecznych zacznie przyjmować wnioski o świadczenie wychowawcze 800 plus na nowy okres świadczeniowy. "Wnioski będzie można składać wyłącznie drogą elektroniczną" - podkreśla rzecznik ZUS Paweł Żebrowski.</p>

## To może być test polityki rządu wobec spółek Skarbu Państwa. Gorące walne GPW i maklerzy bez przedstawiciela
 - [https://www.bankier.pl/wiadomosc/To-moze-byc-test-polityki-rzadu-wobec-spolek-Skarbu-Panstwa-Gorace-walne-GPW-i-maklerzy-bez-przedstawiciela-8688097.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/To-moze-byc-test-polityki-rzadu-wobec-spolek-Skarbu-Panstwa-Gorace-walne-GPW-i-maklerzy-bez-przedstawiciela-8688097.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2024-02-01T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/fb8dc06642b68b-948-568-0-60-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />
Szczególnie ważne dla inwestorów walne zgromadzenie spółki Skarbu Państwa dotyczyć będzie GPW. Od razu może ono zmienić prezesa, ale także pokazać, jak nowa władza obchodzi się z rynkowymi postulatami i to zarówno podnoszonymi przez inwestorów indywidualnych jak i obsługujących ich brokerów. Jeśli można myśleć o poprawie czegokolwiek, to zmiany powinny zacząć się już na tym zebraniu, a póki co walne GPW budzi sporo kontrowersji.  

</p>

