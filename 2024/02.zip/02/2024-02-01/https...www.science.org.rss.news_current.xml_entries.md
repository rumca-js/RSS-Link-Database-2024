# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## Clownfish may be capable of simple math
 - [https://www.science.org/content/article/counting-nemo-clownfish-may-be-capable-simple-math](https://www.science.org/content/article/counting-nemo-clownfish-may-be-capable-simple-math)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-02-01T22:01:09.624940+00:00

Study suggests the animals can add up stripes on other fish, though some experts are skeptical

## On a remote Pacific island, clues to El Niño’s future are preserved in ancient reefs
 - [https://www.science.org/content/article/remote-pacific-island-clues-el-ninos-future-preserved-ancient-reefs](https://www.science.org/content/article/remote-pacific-island-clues-el-ninos-future-preserved-ancient-reefs)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-02-01T19:50:26.088253+00:00

Researchers exhume fossilized corals to predict the fate of a key climate pacemaker in a warmer world

## News at a glance: Mars helicopter’s final flight, grants for U.K. diversity, and a nonopioid pain drug
 - [https://www.science.org/content/article/news-glance-mars-helicopter-s-final-flight-grants-u-k-diversity-and-nonopioid-pain-drug](https://www.science.org/content/article/news-glance-mars-helicopter-s-final-flight-grants-u-k-diversity-and-nonopioid-pain-drug)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-02-01T19:50:24.088230+00:00

The latest in science and policy

## Pregnancy dramatically rewires every major organ, monkey study reveals
 - [https://www.science.org/content/article/pregnancy-dramatically-rewires-every-major-organ-monkey-study-reveals](https://www.science.org/content/article/pregnancy-dramatically-rewires-every-major-organ-monkey-study-reveals)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2024-02-01T19:50:22.093832+00:00

Vast atlas of chemical and hormonal changes could explain how humans adapt to pregnancy, offer clues for treating preeclampsia and other disorders

