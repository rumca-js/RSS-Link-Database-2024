# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Gaming Facts To Make You Feel Old
 - [https://www.youtube.com/watch?v=KwCi-pGWFbQ](https://www.youtube.com/watch?v=KwCi-pGWFbQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2024-02-01T18:58:06+00:00

Play War Thunder now with my link, and get a massive, free bonus pack including vehicles, boosters and more: https://playwt.link/whimsu

War Thunder is a highly detailed vehicle combat game containing over 2000 playable tanks, aircrafts and ships spanning over 100 years of development. Immerse yourself completely in dynamic battles with an unparalleled combination of realism and approachability.

Nintendo. Xbox. PlayStation. These things, seem immortal.

But alas, they are but new creations by man.

Except nintendo that stuffs pretty old.

Today I want to go over a bunch of things, listing games like halo, like the pokemons, the Marios, even a Fortnite, just to make you feel old.

Now obviously the effect of this will depend on your age.

If you’re just hitting 20, it probably isn’t gonna be nearly as surprising to hear some of this as somebody in their 30s. And so on and so forth.

This is just for fun. Or to make you feel old.

You decide.

