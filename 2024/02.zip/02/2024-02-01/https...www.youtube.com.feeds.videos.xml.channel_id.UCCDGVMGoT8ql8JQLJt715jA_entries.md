# Source:emzdanowicz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA, language:pl

## Kojima zapowiedział grę na PS6 - filmowe Phisynt
 - [https://www.youtube.com/watch?v=vRgi01vza58](https://www.youtube.com/watch?v=vRgi01vza58)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA
 - date published: 2024-02-01T10:21:59+00:00

Na Twitterze użył słów: It is a completely new “Action Espionage” for the next-generation. "For next-generation" raczej jasno sugeruje, o co chodzi.

#ps6 #kojima

