# Source:Energetyka, URL:https://energia.rp.pl/rss/4351-energetyka, language:pl-PL

## Polska zabiega o zmiany w podatku od ogrzewania. „Pierwszy krok należy od Brukseli”
 - [https://energia.rp.pl/transformacja-energetyczna/art41608151-polska-zabiega-o-zmiany-w-podatku-od-ogrzewania-pierwszy-krok-nalezy-od-brukseli](https://energia.rp.pl/transformacja-energetyczna/art41608151-polska-zabiega-o-zmiany-w-podatku-od-ogrzewania-pierwszy-krok-nalezy-od-brukseli)
 - RSS feed: $source
 - date published: 2024-12-21T08:25:37.501777+00:00

Jednym z priorytetów działań polskiego rządu podczas prezydencji w UE będzie zabieganie o złagodzenie unijnej dyrektywy ETS, wprowadzającej za trzy lata tzw. podatek od ogrzewania. Polska buduje koalicje, ale prace musi zainicjować najpierw Komisja Europejska.

