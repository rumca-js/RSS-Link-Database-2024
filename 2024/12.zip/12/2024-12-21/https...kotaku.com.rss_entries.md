# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## Pokémon TCG Pocket's Game-Changing Update And More Of The Week's Big News
 - [https://kotaku.com/black-myth-wukong-goty-game-awards-helldivers-killzone-1851726473](https://kotaku.com/black-myth-wukong-goty-game-awards-helldivers-killzone-1851726473)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,q_80,w_636/fdb70d7cfb168005ee05683ed38b56ba.jpg"/><p>The year is wrapping up but the gaming news keeps coming. This week, tales of hurt feelings and anger among some developers and fans of Black Myth: Wukong emerged after it failed to take home Game of the Year honors at this year’s Game Awards. Additionally, the announcement that pricey Killzone skins were coming toHel…</p><p><a href="https://kotaku.com/black-myth-wukong-goty-game-awards-helldivers-killzone-1851726473">Read more...</a></p>

