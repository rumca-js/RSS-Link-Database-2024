# Source:Hackers, URL:https://www.reddit.com/r/hackers/.rss, language:en

## Can someone do me a favor
 - [https://www.reddit.com/r/hackers/comments/1hjimgv/can_someone_do_me_a_favor](https://www.reddit.com/r/hackers/comments/1hjimgv/can_someone_do_me_a_favor)
 - RSS feed: $source
 - date published: 2024-12-21T20:38:56+00:00

<!-- SC_OFF --><div class="md"><p>I don’t how much yall can do with an ip but some Indian logged onto my account and stole my stuff so if one of yall was feeling generous could you make their life hell the ip is 136.158.37.194</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Alternative-Yak-9724"> /u/Alternative-Yak-9724 </a> <br/> <span><a href="https://www.reddit.com/r/hackers/comments/1hjimgv/can_someone_do_me_a_favor/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hackers/comments/1hjimgv/can_someone_do_me_a_favor/">[comments]</a></span>

## Rent-a-hacker?
 - [https://www.reddit.com/r/hackers/comments/1hji2w8/rentahacker](https://www.reddit.com/r/hackers/comments/1hji2w8/rentahacker)
 - RSS feed: $source
 - date published: 2024-12-21T20:12:02+00:00

<!-- SC_OFF --><div class="md"><p>Hey does anyone have any experience with rent a hacker on the hidden wiki. Is it legit? Has anyone used the service? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/13th-Hand"> /u/13th-Hand </a> <br/> <span><a href="https://www.reddit.com/r/hackers/comments/1hji2w8/rentahacker/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hackers/comments/1hji2w8/rentahacker/">[comments]</a></span>

## Would anyone maybe do a free hacking for me, or teach me how to hack snapchat? I’m desperate atp.
 - [https://www.reddit.com/r/hackers/comments/1hj1ime/would_anyone_maybe_do_a_free_hacking_for_me_or](https://www.reddit.com/r/hackers/comments/1hj1ime/would_anyone_maybe_do_a_free_hacking_for_me_or)
 - RSS feed: $source
 - date published: 2024-12-21T03:48:16+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/supernova2867"> /u/supernova2867 </a> <br/> <span><a href="https://www.reddit.com/r/hackers/comments/1hj1ime/would_anyone_maybe_do_a_free_hacking_for_me_or/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hackers/comments/1hj1ime/would_anyone_maybe_do_a_free_hacking_for_me_or/">[comments]</a></span>

## China-linked hackers spark global concern| Radio Free Asia (RFA)
 - [https://www.reddit.com/r/hackers/comments/1hiyn6q/chinalinked_hackers_spark_global_concern_radio](https://www.reddit.com/r/hackers/comments/1hiyn6q/chinalinked_hackers_spark_global_concern_radio)
 - RSS feed: $source
 - date published: 2024-12-21T01:05:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/hackers/comments/1hiyn6q/chinalinked_hackers_spark_global_concern_radio/"> <img src="https://external-preview.redd.it/a5o4JzieYeerse4N5-8fx4d4M7C2sCLwufOWdkRiGaE.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=21c88a985f50778113944402239aaf531396c1ed" alt="China-linked hackers spark global concern| Radio Free Asia (RFA)" title="China-linked hackers spark global concern| Radio Free Asia (RFA)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Right-Influence617"> /u/Right-Influence617 </a> <br/> <span><a href="https://youtu.be/jaUVNtTZJZo?si=yHBNZz_UEQ_Xf2FG">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hackers/comments/1hiyn6q/chinalinked_hackers_spark_global_concern_radio/">[comments]</a></span> </td></tr></table>

