# Source:The New Yorker, URL:https://www.newyorker.com/feed/rss, language:en-US

## The G.O.P.’s Elon Musk Problem
 - [https://www.newyorker.com/news/the-lede/the-gops-elon-musk-problem](https://www.newyorker.com/news/the-lede/the-gops-elon-musk-problem)
 - RSS feed: $source
 - date published: 2024-12-21T21:48:57+00:00

The tech billionaire derailed a government-funding deal and made a shutdown more likely. His intervention signals the growing sway of wealth in politics, and its risks.

## Audra McDonald Triumphs in “Gypsy” on Broadway
 - [https://www.newyorker.com/magazine/2024/12/30/gypsy-theatre-review-broadway](https://www.newyorker.com/magazine/2024/12/30/gypsy-theatre-review-broadway)
 - RSS feed: $source
 - date published: 2024-12-21T16:40:00+00:00

In the latest revival of Arthur Laurents, Stephen Sondheim, and Jule Styne’s iconic musical, George C. Wolfe humanizes a famously monstrous stage mother.

## “Babygirl” Never Really Makes a Mess
 - [https://www.newyorker.com/culture/critics-notebook/babygirl-never-really-makes-a-mess](https://www.newyorker.com/culture/critics-notebook/babygirl-never-really-makes-a-mess)
 - RSS feed: $source
 - date published: 2024-12-21T11:00:00+00:00

The relationship at the heart of a new erotic thriller, starring Nicole Kidman, doesn't explode power struggles; it exists within them.

## The Father of Chinese Authoritarianism Has a Message for America
 - [https://www.newyorker.com/news/the-weekend-essay/the-father-of-chinese-authoritarianism-has-a-message-for-america](https://www.newyorker.com/news/the-weekend-essay/the-father-of-chinese-authoritarianism-has-a-message-for-america)
 - RSS feed: $source
 - date published: 2024-12-21T11:00:00+00:00

Xiao Gongqin thought that, in moments of flux, a strongman could build a bridge to democracy. Now he’s not so sure.

