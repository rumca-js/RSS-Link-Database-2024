# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Despelote - Official Nintendo Switch Announcement Trailer
 - [https://www.youtube.com/watch?v=guM6fPAbzmM](https://www.youtube.com/watch?v=guM6fPAbzmM)
 - RSS feed: $source
 - date published: 2024-12-21T23:00:27+00:00

A slice-of-life adventure about childhood and the magical grip soccer held over the people of Quito, Ecuador in 2001.
Despelote is coming in early 2025 to Nintendo Switch, PlayStation, Xbox, and PC.

## Locomoto - Official Announcement Trailer
 - [https://www.youtube.com/watch?v=8VlSmBkcbcc](https://www.youtube.com/watch?v=8VlSmBkcbcc)
 - RSS feed: $source
 - date published: 2024-12-21T20:00:06+00:00

Board a train and embark on a journey to quaint locations in this Locomoto announcement trailer. The trailer showcases crafting gameplay elements and how you can help passengers as you dive into a cozy adventure in this upcoming game. Locomoto will be available on PC (Steam).

## Ballerina Team on Their New John Wick Movie
 - [https://www.youtube.com/watch?v=2heHVuw7F9w](https://www.youtube.com/watch?v=2heHVuw7F9w)
 - RSS feed: $source
 - date published: 2024-12-21T17:59:00+00:00

From the World of John Wick: Ballerina premieres next June. The cast and director of the upcoming movie discusses fight scenes, mythology, and Death Stranding in this exclusive interview.

## Fortnite OG - Official Renegade Raider Trailer
 - [https://www.youtube.com/watch?v=Y5sfbW4VMNw](https://www.youtube.com/watch?v=Y5sfbW4VMNw)
 - RSS feed: $source
 - date published: 2024-12-21T16:03:10+00:00

Watch the Renegade Raider Trailer for Fortnite, a free-to-play battle royale game developed by Epic Games. Players can now access iconic skins from the launch of Fortnite back in 2017 with the Renegade Raider skin and more available in the OG Season Shop.

#FortniteOG #RenegadeRaider #Gaming

## Game of the Year Watch 2024 - Best Nintendo Game of 2024
 - [https://www.youtube.com/watch?v=ZlPNCAwUh4w](https://www.youtube.com/watch?v=ZlPNCAwUh4w)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:26+00:00

Presented by EX Program: your go-to guide on your journey to quit nicotine. In this snippet from Game Scoop! Game of the Year Watch 2024, IGN’s very own Daemon Hatfield, Destin Legarie, Tom Marks, and Jada Griffin break down the Best Nintendo Game nominees and reveal the big winner. With The Legend of Zelda: Echoes of Wisdom, Lorelei and the Laser Eyes, Paper Mario: The Thousand-Year Door, and Super Mario Party Jamboree all coming out this year, did IGN make the right choice?

Check out the full show for even more IGN Awards reveals on IGN.com and youtube.com/igngames.

## Game of the Year Watch 2024 - Best Game of 2024
 - [https://www.youtube.com/watch?v=JzVA-fXrkGg](https://www.youtube.com/watch?v=JzVA-fXrkGg)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:15+00:00

Presented by EX Program: your go-to guide on your journey to quit nicotine. In this snippet from Game Scoop! Game of the Year Watch 2024, IGN’s very own Daemon Hatfield, Destin Legarie, Tom Marks, and Jada Griffin break down the GOTY nominees and reveal the big winner. With Balatro, Metaphor: ReFantazio, Astrobot, and Black Myth: Wukong all coming out this year, did IGN make the right choice?

Check out the full show for even more IGN Awards reveals on IGN.com and youtube.com/igngames.

## Helldivers 2: The 5 Biggest Changes in Omens of Tyranny
 - [https://www.youtube.com/watch?v=UfwdNx5Vut8](https://www.youtube.com/watch?v=UfwdNx5Vut8)
 - RSS feed: $source
 - date published: 2024-12-21T15:00:39+00:00

Once again, it’s time to spread managed democracy once again. Omens of Tyranny is the massive new update for Helldivers 2, and it brings with it a new enemy in need of freedom, and some new weapons to help you deliver it. These are the biggest changes in the Helldivers 2 Omens of Tyranny update.

## Zenless Zone Zero - Official PS5 Pro Ray Tracing Demo Trailer
 - [https://www.youtube.com/watch?v=-kEKyJSioKQ](https://www.youtube.com/watch?v=-kEKyJSioKQ)
 - RSS feed: $source
 - date published: 2024-12-21T14:30:00+00:00

Watch the PlayStation Ray Tracing Demo Trailer for Zenless Zone Zero, a free-to-play action RPG developed by HoYoverse. With Version 1.4, players on PlayStation 5 Pro will receive enhancements such as ray-traced reflections, improved resolution, improved lighting, better ambient occlusion, and more. Zenless Zone Zero is available now for PlayStation 5 (PS5), iOS, Android, and PC.

#ZenlessZoneZero #PS5Pro #Gaming

## The Biggest Game Releases of January 2025
 - [https://www.youtube.com/watch?v=ElSrLhh0MCw](https://www.youtube.com/watch?v=ElSrLhh0MCw)
 - RSS feed: $source
 - date published: 2024-12-21T14:15:00+00:00

Happy New Year everyone!  It’s that point in the month where we curate a list of some of the biggest games coming out in the next month.   January 2025 is incredibly light on games but that doesn’t mean there’s not any good options!  From Spider-Man 2 coming to PC, and both Donkey Kong Country Returns and Freedom Wars getting remastered, there’s still some awesome games to play this January.  

TIMECODES:
00:00 Intro, Ys Memoire: The Oath in Felghana, Gears & Goo, Human Within
00:59 Freedom Wars Remastered, Aloft, Donkey Kong Country Returns HD
01:27 Morkull Ragast’s Rage, Assetto Corsa EVO, Dynasty Warriors Origins
02:44 Tales of Graces f Remastered, The Dark Side of Ceclon
03:07 Ender Magnolia: Bloom in the Mist, Jedi Power Battles, 
04:38 Synduality: Echo of Ada, Guilty Gear Strive, Cuisineer, Phantom Brave: The Lost Hero
05:15 Marvel’s Spider-Man2, Sniper Elite Resistance

AFFILIATE LINKS: 
Donkey Kong Country Returns HD - January 16 - https://zdcs.link/MVAGq
Dynasty Warriors: Or

## 16 Indie Games You Should Play Now - December 2024
 - [https://www.youtube.com/watch?v=l_mUMyQpjHM](https://www.youtube.com/watch?v=l_mUMyQpjHM)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:44+00:00

We have a holiday present ready to open for everybody! Here are 16 indie games you can play now. 

The games included are; Songs of Silence, I am Future: Cozy Apocalypse Survival, Techtonica, Sengoku Dynasty, Mirthwood, Fruitbus, Ecosystem, Trash Goblin, Menance from the Deep, Unrailed 2: Back on Track, Is This Game Trying to Kill Me, Papa's Pizzeria Deluxe, Sorry We're Closed, Nine Sols, Mind over Magnet and a special surprise appearance of Indiana Jones and the Great Circle.
 
For all things gaming, both AAA games and independent games, keep it tuned to IGN.

## Wuthering Waves - Version 2.0: 10 Minutes of Exclusive Gameplay
 - [https://www.youtube.com/watch?v=8ok2pk0DA3s](https://www.youtube.com/watch?v=8ok2pk0DA3s)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:07+00:00

Check out 10 minutes of gameplay from the 2.0 update to Wuthering Waves, the free-to-play, open-world action-RPG for PC, PS5, and mobile. The 2.0 update introduces a brand-new explorable area, Rinascita, along with a new soaring mechanic that allows players to fly. The version 2.0 update is scheduled for release on January 2, 2025. Please note that the version shown is a test build, and the unlimited stamina feature is solely for testing purposes and does not represent the final release state.

## Justice League’s Dirty Secret (They Made It The Marvel Way) | Inside Stories
 - [https://www.youtube.com/watch?v=3Cm7cjbw1JA](https://www.youtube.com/watch?v=3Cm7cjbw1JA)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:02+00:00

In 2001, Justice League launched on Cartoon Network to almost universal acclaim. Building off of Batman and Superman solo animated series and spinning off into Justice League Unlimited, the creatives behind the show lead by Bruce Timm were also creating a blueprint that box-office busting superhero movies and TV universes are still using today. Over a decade before The Avengers officially took over the big screen, Timm and co. set a high bar for superhero team-ups.

But they also had a secret. 

Bruce Timm was a Marvel guy.

This is the Inside Story of DC’s flagship team revamping how superhero stories were told on screen, and doing it with the Marvel playbook.

This Inside Story was written by Charlie Lopresto and Evan Gaustad. Interviews conducted by Mike Avila. The video was produced by Clint Gage and Scott Collura, edited by Justin Donaldson with graphics by Kevin Cappiello.

Special thanks to Gary Miereanu

Featuring Stan Berkowitz, Maria Canals-Barrera, Kevin Conroy, Susan Eise

## Wuthering Waves - Official Version 2.0 'Carnevale's Prologue' Story Cinematic Trailer
 - [https://www.youtube.com/watch?v=hypfmWQDo4I](https://www.youtube.com/watch?v=hypfmWQDo4I)
 - RSS feed: $source
 - date published: 2024-12-21T13:30:23+00:00

Take a look at the Version 2.0 'Carnevale's Prologue' Story Cinematic Trailer for Wuthering Waves, a free-to-play story-rich open-world action RPG developed by Kuro Game Studio. Get a good glimpse at Carnevale's Prologue in Wuthering Waves Version 2.0 as a traveler from distant shores arrives leaving a role to be fulfilled by the player. Wuthering Waves Version 2.0 is launching on January 2, 2025 for PlayStation 5 (PS5), iOS, Android, and PC (Epic Games Store).

#WutheringWaves #Gaming #IGN

## Shadow or John Wick? Sonic 3 cast tries to guess who said what line! #sonicmovie3 #shadow #johnwick
 - [https://www.youtube.com/watch?v=hXVgGaCSgsQ](https://www.youtube.com/watch?v=hXVgGaCSgsQ)
 - RSS feed: $source
 - date published: 2024-12-21T02:34:35+00:00

None

## IGN's Game of the Year 2024 is... Metaphor: ReFantazio! #ign #goty #metaphor #metaphorrefantazio
 - [https://www.youtube.com/watch?v=YzK7xpLJVt0](https://www.youtube.com/watch?v=YzK7xpLJVt0)
 - RSS feed: $source
 - date published: 2024-12-21T01:57:52+00:00

None

## Ben Schwartz would play 2 Jean-Ralpios, like Jim Carrey playing 2 Robotniks. #sonicmovie3 #sonic
 - [https://www.youtube.com/watch?v=WKZZVAD4Gp4](https://www.youtube.com/watch?v=WKZZVAD4Gp4)
 - RSS feed: $source
 - date published: 2024-12-21T00:04:55+00:00

None

