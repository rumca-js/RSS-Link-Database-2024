# Source:ScreenGeek, URL:https://www.screengeek.net/feed, language:en-US

## Stephen King Praises “Beautiful” Horror Series On Netflix
 - [https://www.screengeek.net/2024/12/21/netflix-stephen-king-horror-series-praise](https://www.screengeek.net/2024/12/21/netflix-stephen-king-horror-series-praise)
 - RSS feed: $source
 - date published: 2024-12-21T19:23:05+00:00

<p>Author Stephen King is known for having crafted some of the biggest novels of our time. With stories like The Shining, Pet Sematary, and the Dark Tower series, it&#8217;s hard not to have an interest in his opinions. Now a tweet from Stephen King has resurfaced in which he calls a Netflix horror series &#8220;beautiful.&#8221; [...]</p>
<p>The post <a href="https://www.screengeek.net/2024/12/21/netflix-stephen-king-horror-series-praise/">Stephen King Praises &#8220;Beautiful&#8221; Horror Series On Netflix</a> appeared first on <a href="https://www.screengeek.net">ScreenGeek</a>.</p>

