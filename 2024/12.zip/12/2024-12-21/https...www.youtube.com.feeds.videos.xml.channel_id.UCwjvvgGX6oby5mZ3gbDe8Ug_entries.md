# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Celebrating Christmas Becomes Illegal in China!
 - [https://www.youtube.com/watch?v=mJdFwRrJGkg](https://www.youtube.com/watch?v=mJdFwRrJGkg)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:57+00:00

Our videos are hosted by real people with real China experience and access to real insights happening in China today. No bots here!


Copyright @ China Insights 2024. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

## Trump Hotpot? Hilarious Mimicry Goes Viral!
 - [https://www.youtube.com/watch?v=CZZQ1O1_CEI](https://www.youtube.com/watch?v=CZZQ1O1_CEI)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:06+00:00

Our videos are hosted by real people with real China experience and access to real insights happening in China today. No bots here!


Copyright @ China Insights 2024. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

