# Source:BBC Europe News, URL:https://feeds.bbci.co.uk/news/world/europe/rss.xml, language:en-gb

## Five unanswered questions from the Pelicot trial
 - [https://www.bbc.com/news/articles/cx2vlx20dm4o](https://www.bbc.com/news/articles/cx2vlx20dm4o)
 - RSS feed: $source
 - date published: 2024-12-21T01:49:14+00:00

Although the Pelicot trial is over, some questions remain over the case that shook France.

