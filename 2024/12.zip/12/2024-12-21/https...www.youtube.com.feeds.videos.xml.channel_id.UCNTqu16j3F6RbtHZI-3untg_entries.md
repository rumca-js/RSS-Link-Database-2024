# Source:Glink, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNTqu16j3F6RbtHZI-3untg, language:en-US

## The New Wave of Art: Techno-Tribalism | Carolina Kleine Samson
 - [https://www.youtube.com/watch?v=SWVJ1K4cxGs](https://www.youtube.com/watch?v=SWVJ1K4cxGs)
 - RSS feed: $source
 - date published: 2024-12-21T02:46:00+00:00

Check out our digital magazine that covers IRL artists and culture:
https://generationtelevision.com/

https://www.patreon.com/Glink
support my work on here and gain access to exclusive videos and bonus footage

https://twitter.com/GlinkLive
Keep up with me on Twitter for updates and memes

https://www.instagram.com/glink_between_worlds/
I share what I've been up to on Instagram

https://discord.gg/xtwYypf
Discord community

https://www.shopglink.com/
Merch designed from handrawn art

