# Source:Lost in Time, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCac6m8K3OGHUT4itHwpCAmw, language:en

## Do you recognize where in New York this is?🇺🇸
 - [https://www.youtube.com/watch?v=Z2gEJx3-xlA](https://www.youtube.com/watch?v=Z2gEJx3-xlA)
 - RSS feed: $source
 - date published: 2024-12-21T15:17:43+00:00

None

