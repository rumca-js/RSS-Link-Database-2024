# Source:Print Comics and Webcomics, URL:https://www.reddit.com/r/comics/.rss, language:en

## Rich Girl from Barcelona, strip #132 of 645 [OC]
 - [https://www.reddit.com/r/comics/comments/1hjk3j7/rich_girl_from_barcelona_strip_132_of_645_oc](https://www.reddit.com/r/comics/comments/1hjk3j7/rich_girl_from_barcelona_strip_132_of_645_oc)
 - RSS feed: $source
 - date published: 2024-12-21T21:51:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjk3j7/rich_girl_from_barcelona_strip_132_of_645_oc/"> <img src="https://b.thumbs.redditmedia.com/qMaEHYuPHiYJh_wGCV6ci4oeK9DPtouCmVlpRKiXLrg.jpg" alt="Rich Girl from Barcelona, strip #132 of 645 [OC]" title="Rich Girl from Barcelona, strip #132 of 645 [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/New-Committee-4902"> /u/New-Committee-4902 </a> <br/> <span><a href="https://www.reddit.com/gallery/1hjk3j7">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjk3j7/rich_girl_from_barcelona_strip_132_of_645_oc/">[comments]</a></span> </td></tr></table>

## Truth hurts [OC]
 - [https://www.reddit.com/r/comics/comments/1hjj974/truth_hurts_oc](https://www.reddit.com/r/comics/comments/1hjj974/truth_hurts_oc)
 - RSS feed: $source
 - date published: 2024-12-21T21:09:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjj974/truth_hurts_oc/"> <img src="https://preview.redd.it/uwiv6jyto98e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=8c0c85c1731bfe56d21f6302448bd737a0824260" alt="Truth hurts [OC]" title="Truth hurts [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rawdawgcomics"> /u/rawdawgcomics </a> <br/> <span><a href="https://i.redd.it/uwiv6jyto98e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjj974/truth_hurts_oc/">[comments]</a></span> </td></tr></table>

## This Is The End - Episode 43
 - [https://www.reddit.com/r/comics/comments/1hjijmn/this_is_the_end_episode_43](https://www.reddit.com/r/comics/comments/1hjijmn/this_is_the_end_episode_43)
 - RSS feed: $source
 - date published: 2024-12-21T20:35:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjijmn/this_is_the_end_episode_43/"> <img src="https://b.thumbs.redditmedia.com/YDeFmmkyeb1j65TG4r1YW70tdHPOOJIvf9NSQNjeRcw.jpg" alt="This Is The End - Episode 43" title="This Is The End - Episode 43" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/UgoYak"> /u/UgoYak </a> <br/> <span><a href="https://www.reddit.com/gallery/1hjijmn">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjijmn/this_is_the_end_episode_43/">[comments]</a></span> </td></tr></table>

## Daddy Daze - [OC] Fall is over. Winter is here.
 - [https://www.reddit.com/r/comics/comments/1hjgkmk/daddy_daze_oc_fall_is_over_winter_is_here](https://www.reddit.com/r/comics/comments/1hjgkmk/daddy_daze_oc_fall_is_over_winter_is_here)
 - RSS feed: $source
 - date published: 2024-12-21T19:00:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjgkmk/daddy_daze_oc_fall_is_over_winter_is_here/"> <img src="https://preview.redd.it/tyasnu2p198e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0955873c7b81634a0e9589ccad829ab491f83c4d" alt="Daddy Daze - [OC] Fall is over. Winter is here. " title="Daddy Daze - [OC] Fall is over. Winter is here. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Cokereal"> /u/Cokereal </a> <br/> <span><a href="https://i.redd.it/tyasnu2p198e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjgkmk/daddy_daze_oc_fall_is_over_winter_is_here/">[comments]</a></span> </td></tr></table>

## Edgy
 - [https://www.reddit.com/r/comics/comments/1hjgidk/edgy](https://www.reddit.com/r/comics/comments/1hjgidk/edgy)
 - RSS feed: $source
 - date published: 2024-12-21T18:57:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjgidk/edgy/"> <img src="https://b.thumbs.redditmedia.com/gz2i3-xXc8KMuLUMWQdukV_for7V2I9O1uDgDX2m8Ws.jpg" alt="Edgy" title="Edgy" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Fledered"> /u/Fledered </a> <br/> <span><a href="https://www.reddit.com/gallery/1hjgidk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjgidk/edgy/">[comments]</a></span> </td></tr></table>

## He's really high up there [OC]
 - [https://www.reddit.com/r/comics/comments/1hjfmmc/hes_really_high_up_there_oc](https://www.reddit.com/r/comics/comments/1hjfmmc/hes_really_high_up_there_oc)
 - RSS feed: $source
 - date published: 2024-12-21T18:15:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjfmmc/hes_really_high_up_there_oc/"> <img src="https://preview.redd.it/bmsp52pnt88e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a66a87ea3bc6c1205f662e2c9b784c38eb6bf593" alt="He's really high up there [OC]" title="He's really high up there [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HeyyEj"> /u/HeyyEj </a> <br/> <span><a href="https://i.redd.it/bmsp52pnt88e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjfmmc/hes_really_high_up_there_oc/">[comments]</a></span> </td></tr></table>

## (OC) The Immigration Deal
 - [https://www.reddit.com/r/comics/comments/1hjeucq/oc_the_immigration_deal](https://www.reddit.com/r/comics/comments/1hjeucq/oc_the_immigration_deal)
 - RSS feed: $source
 - date published: 2024-12-21T17:40:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjeucq/oc_the_immigration_deal/"> <img src="https://preview.redd.it/epqcmpeen88e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=aebb05af83d91f14dbffd464ebe3563790251925" alt="(OC) The Immigration Deal" title="(OC) The Immigration Deal" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/leftycartoons"> /u/leftycartoons </a> <br/> <span><a href="https://i.redd.it/epqcmpeen88e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjeucq/oc_the_immigration_deal/">[comments]</a></span> </td></tr></table>

## Yes, BUT (vol.24)
 - [https://www.reddit.com/r/comics/comments/1hje4x7/yes_but_vol24](https://www.reddit.com/r/comics/comments/1hje4x7/yes_but_vol24)
 - RSS feed: $source
 - date published: 2024-12-21T17:07:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hje4x7/yes_but_vol24/"> <img src="https://b.thumbs.redditmedia.com/Jst9rPQ-DoSWTytrDIpTCVI-yUU9C2-UXKx7iS8W33o.jpg" alt="Yes, BUT (vol.24)" title="Yes, BUT (vol.24)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/gudim_anton"> /u/gudim_anton </a> <br/> <span><a href="https://www.reddit.com/gallery/1hje4x7">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hje4x7/yes_but_vol24/">[comments]</a></span> </td></tr></table>

## Mage x Witch 1-4 [OC]
 - [https://www.reddit.com/r/comics/comments/1hjdrp8/mage_x_witch_14_oc](https://www.reddit.com/r/comics/comments/1hjdrp8/mage_x_witch_14_oc)
 - RSS feed: $source
 - date published: 2024-12-21T16:50:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjdrp8/mage_x_witch_14_oc/"> <img src="https://b.thumbs.redditmedia.com/rgGNK4BeyWwKwcFdDkp4XUOqeZEblFV92K3WfuMzsGU.jpg" alt="Mage x Witch 1-4 [OC]" title="Mage x Witch 1-4 [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Themeguy"> /u/Themeguy </a> <br/> <span><a href="https://www.reddit.com/gallery/1hjdrp8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjdrp8/mage_x_witch_14_oc/">[comments]</a></span> </td></tr></table>

## Teleportation
 - [https://www.reddit.com/r/comics/comments/1hjdonm/teleportation](https://www.reddit.com/r/comics/comments/1hjdonm/teleportation)
 - RSS feed: $source
 - date published: 2024-12-21T16:46:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjdonm/teleportation/"> <img src="https://b.thumbs.redditmedia.com/DBPM98uQEEfLuc3eQ5iJkjtYlHsMe4AVQbzFz9AKSMY.jpg" alt="Teleportation" title="Teleportation" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/afterdeathcomics"> /u/afterdeathcomics </a> <br/> <span><a href="https://www.reddit.com/gallery/1hjdonm">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjdonm/teleportation/">[comments]</a></span> </td></tr></table>

## [OC] Gabital 30: Production capacity
 - [https://www.reddit.com/r/comics/comments/1hjdfkm/oc_gabital_30_production_capacity](https://www.reddit.com/r/comics/comments/1hjdfkm/oc_gabital_30_production_capacity)
 - RSS feed: $source
 - date published: 2024-12-21T16:34:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjdfkm/oc_gabital_30_production_capacity/"> <img src="https://preview.redd.it/htkq5e8pb88e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=d4aa1968fa12fdc67bd14dbc492cfd169bf4418d" alt="[OC] Gabital 30: Production capacity" title="[OC] Gabital 30: Production capacity" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GabitalEN"> /u/GabitalEN </a> <br/> <span><a href="https://i.redd.it/htkq5e8pb88e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjdfkm/oc_gabital_30_production_capacity/">[comments]</a></span> </td></tr></table>

## A lot of the homes Santa visits are dark
 - [https://www.reddit.com/r/comics/comments/1hjcbay/a_lot_of_the_homes_santa_visits_are_dark](https://www.reddit.com/r/comics/comments/1hjcbay/a_lot_of_the_homes_santa_visits_are_dark)
 - RSS feed: $source
 - date published: 2024-12-21T15:40:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjcbay/a_lot_of_the_homes_santa_visits_are_dark/"> <img src="https://preview.redd.it/ybcax20z188e1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=e3836db1303a799c795ce3a09ea457be02b2a6ed" alt="A lot of the homes Santa visits are dark" title="A lot of the homes Santa visits are dark" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/luvs_animals"> /u/luvs_animals </a> <br/> <span><a href="https://i.redd.it/ybcax20z188e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjcbay/a_lot_of_the_homes_santa_visits_are_dark/">[comments]</a></span> </td></tr></table>

## nothing is inherently wrong [OC]
 - [https://www.reddit.com/r/comics/comments/1hjc4a4/nothing_is_inherently_wrong_oc](https://www.reddit.com/r/comics/comments/1hjc4a4/nothing_is_inherently_wrong_oc)
 - RSS feed: $source
 - date published: 2024-12-21T15:30:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjc4a4/nothing_is_inherently_wrong_oc/"> <img src="https://preview.redd.it/fsefzwza088e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=ba4b2952078cba060c2fd6140807d9b9334b7549" alt="nothing is inherently wrong [OC]" title="nothing is inherently wrong [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/endlesspartone"> /u/endlesspartone </a> <br/> <span><a href="https://i.redd.it/fsefzwza088e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjc4a4/nothing_is_inherently_wrong_oc/">[comments]</a></span> </td></tr></table>

## it could be anybody
 - [https://www.reddit.com/r/comics/comments/1hjbpr0/it_could_be_anybody](https://www.reddit.com/r/comics/comments/1hjbpr0/it_could_be_anybody)
 - RSS feed: $source
 - date published: 2024-12-21T15:10:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjbpr0/it_could_be_anybody/"> <img src="https://preview.redd.it/mb3cd0mow78e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=104f6a1cdc0dda87a0f89da8de91e3f9fe8df91e" alt="it could be anybody" title="it could be anybody" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JimKB"> /u/JimKB </a> <br/> <span><a href="https://i.redd.it/mb3cd0mow78e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjbpr0/it_could_be_anybody/">[comments]</a></span> </td></tr></table>

## gym guy
 - [https://www.reddit.com/r/comics/comments/1hjalvl/gym_guy](https://www.reddit.com/r/comics/comments/1hjalvl/gym_guy)
 - RSS feed: $source
 - date published: 2024-12-21T14:11:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjalvl/gym_guy/"> <img src="https://preview.redd.it/zip6ncsjl78e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=28af18ac7184490f997331452fd8d3b5eb7d5a0b" alt="gym guy" title="gym guy" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/sellyourcomputer"> /u/sellyourcomputer </a> <br/> <span><a href="https://i.redd.it/zip6ncsjl78e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjalvl/gym_guy/">[comments]</a></span> </td></tr></table>

## The Wound. [OC]
 - [https://www.reddit.com/r/comics/comments/1hjabt9/the_wound_oc](https://www.reddit.com/r/comics/comments/1hjabt9/the_wound_oc)
 - RSS feed: $source
 - date published: 2024-12-21T13:56:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hjabt9/the_wound_oc/"> <img src="https://a.thumbs.redditmedia.com/Y-weyWCV-y8SEErIo0FDW_6R5A3AviC_PzQfA7ZSel4.jpg" alt="The Wound. [OC]" title="The Wound. [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/shikiz_stupid_comics"> /u/shikiz_stupid_comics </a> <br/> <span><a href="https://www.reddit.com/gallery/1hjabt9">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hjabt9/the_wound_oc/">[comments]</a></span> </td></tr></table>

## My Dad is Dracula (and a Rattata Pokemon)
 - [https://www.reddit.com/r/comics/comments/1hj9d9n/my_dad_is_dracula_and_a_rattata_pokemon](https://www.reddit.com/r/comics/comments/1hj9d9n/my_dad_is_dracula_and_a_rattata_pokemon)
 - RSS feed: $source
 - date published: 2024-12-21T13:00:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hj9d9n/my_dad_is_dracula_and_a_rattata_pokemon/"> <img src="https://external-preview.redd.it/HPaGuig6sOXzcpJ87XifyLyjRZFg3C-L0hYABegpZgA.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=35ebb521f20b7bdbfe4164bd2813620478540588" alt="My Dad is Dracula (and a Rattata Pokemon)" title="My Dad is Dracula (and a Rattata Pokemon)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/jasonpoland"> /u/jasonpoland </a> <br/> <span><a href="https://i.imgur.com/HFBXlbp.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hj9d9n/my_dad_is_dracula_and_a_rattata_pokemon/">[comments]</a></span> </td></tr></table>

## But they’re so cute …
 - [https://www.reddit.com/r/comics/comments/1hj955r/but_theyre_so_cute](https://www.reddit.com/r/comics/comments/1hj955r/but_theyre_so_cute)
 - RSS feed: $source
 - date published: 2024-12-21T12:45:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hj955r/but_theyre_so_cute/"> <img src="https://preview.redd.it/dbdhhybw678e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=53682cbccb013eedb390afe09b9c2b016f506fff" alt="But they’re so cute …" title="But they’re so cute …" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Had this idea while I was in the shower and cracked myself up. Hoping the humour comes across in the strip. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/awcomix"> /u/awcomix </a> <br/> <span><a href="https://i.redd.it/dbdhhybw678e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hj955r/but_theyre_so_cute/">[comments]</a></span> </td></tr></table>

## Winter break is half over [OC]
 - [https://www.reddit.com/r/comics/comments/1hj8wja/winter_break_is_half_over_oc](https://www.reddit.com/r/comics/comments/1hj8wja/winter_break_is_half_over_oc)
 - RSS feed: $source
 - date published: 2024-12-21T12:29:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hj8wja/winter_break_is_half_over_oc/"> <img src="https://b.thumbs.redditmedia.com/7z4QLEa1q83nA1qzR3gPUVA_med2ms239i1_kELzIMI.jpg" alt="Winter break is half over [OC]" title="Winter break is half over [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/emmonster"> /u/emmonster </a> <br/> <span><a href="https://www.reddit.com/gallery/1hj8wja">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hj8wja/winter_break_is_half_over_oc/">[comments]</a></span> </td></tr></table>

## A Very Other Merry End Christmas - “Santa’s mistake”
 - [https://www.reddit.com/r/comics/comments/1hj8gc1/a_very_other_merry_end_christmas_santas_mistake](https://www.reddit.com/r/comics/comments/1hj8gc1/a_very_other_merry_end_christmas_santas_mistake)
 - RSS feed: $source
 - date published: 2024-12-21T11:59:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hj8gc1/a_very_other_merry_end_christmas_santas_mistake/"> <img src="https://b.thumbs.redditmedia.com/tfynE33tbeGzUIGjDqgT9d6OwFqf9SJS10Hp1ZQKkKs.jpg" alt="A Very Other Merry End Christmas - “Santa’s mistake”" title="A Very Other Merry End Christmas - “Santa’s mistake”" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/neilkohney"> /u/neilkohney </a> <br/> <span><a href="https://www.reddit.com/gallery/1hj8gc1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hj8gc1/a_very_other_merry_end_christmas_santas_mistake/">[comments]</a></span> </td></tr></table>

## That one guy every year
 - [https://www.reddit.com/r/comics/comments/1hj8cz1/that_one_guy_every_year](https://www.reddit.com/r/comics/comments/1hj8cz1/that_one_guy_every_year)
 - RSS feed: $source
 - date published: 2024-12-21T11:52:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hj8cz1/that_one_guy_every_year/"> <img src="https://preview.redd.it/2djly04hx68e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8f1bdd87c5501530a6e8bffbfbe40f6eaa128f82" alt="That one guy every year" title="That one guy every year" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/davidsk"> /u/davidsk </a> <br/> <span><a href="https://i.redd.it/2djly04hx68e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hj8cz1/that_one_guy_every_year/">[comments]</a></span> </td></tr></table>

## "Fairytale of r/comics" [OC]
 - [https://www.reddit.com/r/comics/comments/1hj864v/fairytale_of_rcomics_oc](https://www.reddit.com/r/comics/comments/1hj864v/fairytale_of_rcomics_oc)
 - RSS feed: $source
 - date published: 2024-12-21T11:39:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hj864v/fairytale_of_rcomics_oc/"> <img src="https://preview.redd.it/cgz19942v68e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=3e68b43c84876fd38c8925e0cde1aa83e7bc4210" alt="&quot;Fairytale of r/comics&quot; [OC]" title="&quot;Fairytale of r/comics&quot; [OC]" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>A little piece of festive fanart I made to celebrate my amazing fellow artists out here makin&#39; webcomics! Cheers and happy holidays!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/lucien_laval"> /u/lucien_laval </a> <br/> <span><a href="https://i.redd.it/cgz19942v68e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hj864v/fairytale_of_rcomics_oc/">[comments]</a></span> </td></tr></table>

## The comedian
 - [https://www.reddit.com/r/comics/comments/1hj7xmu/the_comedian](https://www.reddit.com/r/comics/comments/1hj7xmu/the_comedian)
 - RSS feed: $source
 - date published: 2024-12-21T11:22:12+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hj7xmu/the_comedian/"> <img src="https://preview.redd.it/8eabxetzr68e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=41ff99d524c385acefc1864cb27297d2d96123bd" alt="The comedian" title="The comedian" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/davidsk"> /u/davidsk </a> <br/> <span><a href="https://i.redd.it/8eabxetzr68e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hj7xmu/the_comedian/">[comments]</a></span> </td></tr></table>

## [oc] Christmas present
 - [https://www.reddit.com/r/comics/comments/1hj5i73/oc_christmas_present](https://www.reddit.com/r/comics/comments/1hj5i73/oc_christmas_present)
 - RSS feed: $source
 - date published: 2024-12-21T08:16:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hj5i73/oc_christmas_present/"> <img src="https://b.thumbs.redditmedia.com/7MJo6Xip7l8OLq00rE5b2RQZr24Gojw2352Tlk3qSVo.jpg" alt="[oc] Christmas present " title="[oc] Christmas present " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/puddleartstudio"> /u/puddleartstudio </a> <br/> <span><a href="https://www.reddit.com/gallery/1hj5i73">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hj5i73/oc_christmas_present/">[comments]</a></span> </td></tr></table>

## Starsposting
 - [https://www.reddit.com/r/comics/comments/1hj2gq0/starsposting](https://www.reddit.com/r/comics/comments/1hj2gq0/starsposting)
 - RSS feed: $source
 - date published: 2024-12-21T04:46:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hj2gq0/starsposting/"> <img src="https://b.thumbs.redditmedia.com/m298sZZzZ8P0gk9pJjR4LBrDr3dbyzUiligPmczu_Us.jpg" alt="Starsposting" title="Starsposting" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MurkyWay"> /u/MurkyWay </a> <br/> <span><a href="https://www.reddit.com/gallery/1hj2gq0">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hj2gq0/starsposting/">[comments]</a></span> </td></tr></table>

## The Rate Stand Off [OC]
 - [https://www.reddit.com/r/comics/comments/1hiy3s4/the_rate_stand_off_oc](https://www.reddit.com/r/comics/comments/1hiy3s4/the_rate_stand_off_oc)
 - RSS feed: $source
 - date published: 2024-12-21T00:37:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hiy3s4/the_rate_stand_off_oc/"> <img src="https://a.thumbs.redditmedia.com/ooVvj9cbjOFVbJpaacnEFssbQsllMKgkFdztG78Fak0.jpg" alt="The Rate Stand Off [OC]" title="The Rate Stand Off [OC]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HeyyEj"> /u/HeyyEj </a> <br/> <span><a href="https://www.reddit.com/gallery/1hiy3s4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hiy3s4/the_rate_stand_off_oc/">[comments]</a></span> </td></tr></table>

## puppy love [OC]
 - [https://www.reddit.com/r/comics/comments/1hixfg1/puppy_love_oc](https://www.reddit.com/r/comics/comments/1hixfg1/puppy_love_oc)
 - RSS feed: $source
 - date published: 2024-12-21T00:02:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/comics/comments/1hixfg1/puppy_love_oc/"> <img src="https://preview.redd.it/x1bvdmire38e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=875da54fe6c68a2a8ded3c220c2ca97621719d91" alt="puppy love [OC]" title="puppy love [OC]" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>From my new book “the Secret Lives of Candy Hearts” coming out in January!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TommySiegel"> /u/TommySiegel </a> <br/> <span><a href="https://i.redd.it/x1bvdmire38e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/comics/comments/1hixfg1/puppy_love_oc/">[comments]</a></span> </td></tr></table>

