# Source:Electronic Frontier Foundation, URL:https://www.eff.org/rss/updates.xml, language:en

## EFF Tells Appeals Court To Keep Copyright’s Fair Use Rules Broad And Flexible
 - [https://www.eff.org/deeplinks/2024/12/eff-tells-appeals-court-keep-copyrights-fair-use-rules-broad-and-flexible](https://www.eff.org/deeplinks/2024/12/eff-tells-appeals-court-keep-copyrights-fair-use-rules-broad-and-flexible)
 - RSS feed: $source
 - date published: 2024-12-21T17:05:25+00:00

<div class="field field--name-body field--type-text-with-summary field--label-hidden"><div class="field__items"><div class="field__item even"><p><span>It’s critical that copyright be balanced with limitations that support users’ rights, and perhaps no limitation is more important than </span><a href="https://www.eff.org/issues/intellectual-property"><span>fair use</span></a><span>. </span><a href="https://www.eff.org/deeplinks/2024/08/copyright-not-tool-silence-critics-religious-education"><span>Critics</span></a><span>, </span><a href="https://www.eff.org/deeplinks/2024/09/climate-has-posse-and-so-does-political-satire"><span>humorists</span></a><span>, </span><a href="https://www.eff.org/deeplinks/2024/05/podcast-episode-ai-artists-palette"><span>artists</span></a><span>, and </span><a href="https://www.eff.org/deeplinks/2024/08/eff-tells-yet-another-court-ensure-everyone-has-access-law-and-reject-private"><span>activists</span></a><span> all must have rights to re-use and re-purpo

