# Source:The Dark Depths of YouTube, URL:https://www.reddit.com/r/DeepIntoYouTube/.rss, language:en

## Massage train
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hjkq0t/massage_train](https://www.reddit.com/r/DeepIntoYouTube/comments/1hjkq0t/massage_train)
 - RSS feed: $source
 - date published: 2024-12-21T22:22:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjkq0t/massage_train/"> <img src="https://external-preview.redd.it/4tBE9Rs_J-ph3i_Z1lrZtJm0h-INiQwHAufbbz_7XQ4.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=4b685e8872f0f6216d0beec84344a1a6a5012d13" alt="Massage train" title="Massage train" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MattSuper13"> /u/MattSuper13 </a> <br/> <span><a href="https://www.youtube.com/watch?v=W3R3rdj2F_Y">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjkq0t/massage_train/">[comments]</a></span> </td></tr></table>

## Black or Pinto Beans (a song about the Chipotle ordering process)
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hjf8s7/black_or_pinto_beans_a_song_about_the_chipotle](https://www.reddit.com/r/DeepIntoYouTube/comments/1hjf8s7/black_or_pinto_beans_a_song_about_the_chipotle)
 - RSS feed: $source
 - date published: 2024-12-21T17:58:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjf8s7/black_or_pinto_beans_a_song_about_the_chipotle/"> <img src="https://external-preview.redd.it/H6hbX-kGN76PwOgQ6hqnZMJgZ_w_Vn5pe1x8h8Q0_8M.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=a252cabfeda973a985f773d28cecd64d8bd1ed17" alt="Black or Pinto Beans (a song about the Chipotle ordering process)" title="Black or Pinto Beans (a song about the Chipotle ordering process)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rodmans2"> /u/rodmans2 </a> <br/> <span><a href="https://youtu.be/BG5sGhyypW4?si=fEbLjXMCDXwRiYpD">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjf8s7/black_or_pinto_beans_a_song_about_the_chipotle/">[comments]</a></span> </td></tr></table>

## Found small channel (under 1000 subs) with high quality, funny, and interesting short films. Also would recommend their newest video, remote!
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hjf6m0/found_small_channel_under_1000_subs_with_high](https://www.reddit.com/r/DeepIntoYouTube/comments/1hjf6m0/found_small_channel_under_1000_subs_with_high)
 - RSS feed: $source
 - date published: 2024-12-21T17:55:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjf6m0/found_small_channel_under_1000_subs_with_high/"> <img src="https://external-preview.redd.it/ju65LQGsn7x3vLY2NGLxhmcNKS9CBGnIgeN85VSixAU.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=1f93c59b3a980ffaec54501e5c2162eeae7968e8" alt="Found small channel (under 1000 subs) with high quality, funny, and interesting short films. Also would recommend their newest video, remote!" title="Found small channel (under 1000 subs) with high quality, funny, and interesting short films. Also would recommend their newest video, remote!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheIsmizl"> /u/TheIsmizl </a> <br/> <span><a href="https://www.youtube.com/watch?v=Fa-cjYMIZfs&amp;t=14s">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjf6m0/found_small_channel_under_1000_subs_with_high/">[comments]</a></span> </td></tr></table>

## Mukbang Mermaid
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hjdzn1/mukbang_mermaid](https://www.reddit.com/r/DeepIntoYouTube/comments/1hjdzn1/mukbang_mermaid)
 - RSS feed: $source
 - date published: 2024-12-21T17:00:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjdzn1/mukbang_mermaid/"> <img src="https://external-preview.redd.it/jUSrdDdHnsxGRdLZCaIp7_N9aouOgV6be8j2DYCFfN4.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=c6a2e7625c410ef624585043995ec83c54d5e98a" alt="Mukbang Mermaid" title="Mukbang Mermaid" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/crazy_goat"> /u/crazy_goat </a> <br/> <span><a href="https://youtu.be/Wm3XCdsX7SY?t=80">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjdzn1/mukbang_mermaid/">[comments]</a></span> </td></tr></table>

## [Aratikaya Popu Recipe in Telugu]
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hjby7r/aratikaya_popu_recipe_in_telugu](https://www.reddit.com/r/DeepIntoYouTube/comments/1hjby7r/aratikaya_popu_recipe_in_telugu)
 - RSS feed: $source
 - date published: 2024-12-21T15:22:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjby7r/aratikaya_popu_recipe_in_telugu/"> <img src="https://external-preview.redd.it/zuOFcS3Roq1iexWtigPNJAjSk_vf0-U_oB26CA4zrpU.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=2c3b9e3e1f0d52641d630cbb2b8404c769cac351" alt="[Aratikaya Popu Recipe in Telugu]" title="[Aratikaya Popu Recipe in Telugu]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Rahul-Foodie993"> /u/Rahul-Foodie993 </a> <br/> <span><a href="https://youtu.be/a-5TePm7e4Y?si=pgePhu05siTMoFfZ">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hjby7r/aratikaya_popu_recipe_in_telugu/">[comments]</a></span> </td></tr></table>

## Found this weird-ass channel
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hj9r21/found_this_weirdass_channel](https://www.reddit.com/r/DeepIntoYouTube/comments/1hj9r21/found_this_weirdass_channel)
 - RSS feed: $source
 - date published: 2024-12-21T13:23:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj9r21/found_this_weirdass_channel/"> <img src="https://external-preview.redd.it/6xK7u3UDwNpfBJC5QlyF-VxI_nhSKuLvtCHnvHtqjKM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2588c2ae2a3486f1477dbd848008be2a86c27649" alt="Found this weird-ass channel" title="Found this weird-ass channel" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>does anyone know whats the meaning of its content?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Valdemar830"> /u/Valdemar830 </a> <br/> <span><a href="https://youtube.com/@exmathematician?si=yAtx1aPHdMY6z-6u">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj9r21/found_this_weirdass_channel/">[comments]</a></span> </td></tr></table>

## Channel only uploads distorted indie covers but they’re overlayed by photos from the 90s? Does anyone know what’s going here??
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hj9m5h/channel_only_uploads_distorted_indie_covers_but](https://www.reddit.com/r/DeepIntoYouTube/comments/1hj9m5h/channel_only_uploads_distorted_indie_covers_but)
 - RSS feed: $source
 - date published: 2024-12-21T13:15:15+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj9m5h/channel_only_uploads_distorted_indie_covers_but/"> <img src="https://external-preview.redd.it/xtWRMBVt-ozMFMF-ZnE4yI4UXVKAuPNG1OYFGO3ljpI.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=fd226812a2fa68d4334f0bb2025f2527dd04d560" alt="Channel only uploads distorted indie covers but they’re overlayed by photos from the 90s? Does anyone know what’s going here??" title="Channel only uploads distorted indie covers but they’re overlayed by photos from the 90s? Does anyone know what’s going here??" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/shMebil0CK"> /u/shMebil0CK </a> <br/> <span><a href="https://youtu.be/bP3cKr56Fwg?si=_7OU2boAA2fTopHp">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj9m5h/channel_only_uploads_distorted_indie_covers_but/">[comments]</a></span> </td></tr></table>

## Comment bar not showing on shorts
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hj6xnl/comment_bar_not_showing_on_shorts](https://www.reddit.com/r/DeepIntoYouTube/comments/1hj6xnl/comment_bar_not_showing_on_shorts)
 - RSS feed: $source
 - date published: 2024-12-21T10:07:39+00:00

<!-- SC_OFF --><div class="md"><p>(Before i start the link is just a random shorts link because i couldn&#39;t post this without a link so..)I can&#39;t comment on YouTube shorts only. I have multiple accounts with same settings i changed nothing but on one specific account I can&#39;t comment i don&#39;t even see the comment bar it&#39;s not there. And yes the comments are on i switched to different account and commented on the same shorts without an issues but on the other account i can&#39;t even see the comment bar i click everywhere look into settings i did everything i still can&#39;t see the comment bar on shorts. Yes i can reply but i don&#39;t want to reply i want to comment </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Natural_External_117"> /u/Natural_External_117 </a> <br/> <span><a href="https://youtube.com/shorts/k194wHZHjB0?si=7SBym_rMxNmk3bJd">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comm

## A very strange pokemon card pack opening video
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hj3g3c/a_very_strange_pokemon_card_pack_opening_video](https://www.reddit.com/r/DeepIntoYouTube/comments/1hj3g3c/a_very_strange_pokemon_card_pack_opening_video)
 - RSS feed: $source
 - date published: 2024-12-21T05:48:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj3g3c/a_very_strange_pokemon_card_pack_opening_video/"> <img src="https://external-preview.redd.it/_M-CxcnqPorPLf5YVhaC-6MBj9662NzQeRyEXx9SAAw.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=c521263c54834413b100cb084e08d4f477a14f08" alt="A very strange pokemon card pack opening video" title="A very strange pokemon card pack opening video" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/wakenmasturbate"> /u/wakenmasturbate </a> <br/> <span><a href="https://youtu.be/8buMswWPtAs?si=O_jMqgRxU6X8R0ii">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj3g3c/a_very_strange_pokemon_card_pack_opening_video/">[comments]</a></span> </td></tr></table>

## Channel that reads old texts & manuals to a backdrop of vintage footage from the early 20th century
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hj1pa8/channel_that_reads_old_texts_manuals_to_a](https://www.reddit.com/r/DeepIntoYouTube/comments/1hj1pa8/channel_that_reads_old_texts_manuals_to_a)
 - RSS feed: $source
 - date published: 2024-12-21T03:59:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj1pa8/channel_that_reads_old_texts_manuals_to_a/"> <img src="https://external-preview.redd.it/tm0VamjYvCbgmbFZw9jfAqIWEdKxEKayo1TO3rcbY0g.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9f0608e7ca6165034222924ce5aadc1d54aeafda" alt="Channel that reads old texts &amp; manuals to a backdrop of vintage footage from the early 20th century " title="Channel that reads old texts &amp; manuals to a backdrop of vintage footage from the early 20th century " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Bountybras"> /u/Bountybras </a> <br/> <span><a href="https://youtube.com/@thequietarchives?si=cLT0IJJ8X_UnZKt-">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj1pa8/channel_that_reads_old_texts_manuals_to_a/">[comments]</a></span> </td></tr></table>

## Full Metal Alchemist AMV - Animal I Have Become-TuckerxNina
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hj19n2/full_metal_alchemist_amv_animal_i_have](https://www.reddit.com/r/DeepIntoYouTube/comments/1hj19n2/full_metal_alchemist_amv_animal_i_have)
 - RSS feed: $source
 - date published: 2024-12-21T03:33:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj19n2/full_metal_alchemist_amv_animal_i_have/"> <img src="https://external-preview.redd.it/wctXNoIt33JPQ4X6YsSSA4GYZm0hkvuVQsX9XTJTweU.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=a89a30a265e4acb5154177197d20e7da2091d96d" alt="Full Metal Alchemist AMV - Animal I Have Become-TuckerxNina" title="Full Metal Alchemist AMV - Animal I Have Become-TuckerxNina" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I was told I should post another of the AMV list.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sure_Sea_8354"> /u/Sure_Sea_8354 </a> <br/> <span><a href="https://youtu.be/sGmO6NSSP7o?si=3kUwtbYoDcxQ1Nxu">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hj19n2/full_metal_alchemist_amv_animal_i_have/">[comments]</a></span> </td></tr></table>

## ishouldnthavefallenintothebutcherstrap
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hizx5a/ishouldnthavefallenintothebutcherstrap](https://www.reddit.com/r/DeepIntoYouTube/comments/1hizx5a/ishouldnthavefallenintothebutcherstrap)
 - RSS feed: $source
 - date published: 2024-12-21T02:15:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hizx5a/ishouldnthavefallenintothebutcherstrap/"> <img src="https://external-preview.redd.it/XnvDi66P5sqbZoI0V4_nVwxmFEQRY8ReTnvDVoODnpM.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=37bc5b5a77b14a37bda0782076ab00fb107da15c" alt="ishouldnthavefallenintothebutcherstrap" title="ishouldnthavefallenintothebutcherstrap" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/obungaofficial"> /u/obungaofficial </a> <br/> <span><a href="https://youtu.be/9rJaH3B2elI?si=S9f5ZY208mRaUjUI">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hizx5a/ishouldnthavefallenintothebutcherstrap/">[comments]</a></span> </td></tr></table>

## uploaded yesterday. Meth girl rapper needs a nap.
 - [https://www.reddit.com/r/DeepIntoYouTube/comments/1hiyysp/uploaded_yesterday_meth_girl_rapper_needs_a_nap](https://www.reddit.com/r/DeepIntoYouTube/comments/1hiyysp/uploaded_yesterday_meth_girl_rapper_needs_a_nap)
 - RSS feed: $source
 - date published: 2024-12-21T01:22:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hiyysp/uploaded_yesterday_meth_girl_rapper_needs_a_nap/"> <img src="https://external-preview.redd.it/tDoO7w5h3Cu8FROH3Yvm8UEzolMGkc7EMW2BM2rlekw.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=7c54a9aa62ff316557b74b71c8a7ca504b11ff75" alt="uploaded yesterday. Meth girl rapper needs a nap. " title="uploaded yesterday. Meth girl rapper needs a nap. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Drummcycle"> /u/Drummcycle </a> <br/> <span><a href="https://www.youtube.com/watch?v=_ZIK4ALRdTc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/DeepIntoYouTube/comments/1hiyysp/uploaded_yesterday_meth_girl_rapper_needs_a_nap/">[comments]</a></span> </td></tr></table>

