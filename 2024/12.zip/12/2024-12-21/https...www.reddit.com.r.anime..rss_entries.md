# Source:/r/Anime, URL:https://www.reddit.com/r/anime/.rss, language:en

## [Rewatch] Yuuki Yuuna ga Yuusha wa Aru Original Series Overall Discussion
 - [https://www.reddit.com/r/anime/comments/1hjk9g9/rewatch_yuuki_yuuna_ga_yuusha_wa_aru_original](https://www.reddit.com/r/anime/comments/1hjk9g9/rewatch_yuuki_yuuna_ga_yuusha_wa_aru_original)
 - RSS feed: $source
 - date published: 2024-12-21T22:00:08+00:00

<!-- SC_OFF --><div class="md"><h2><strong>Original Series Overall Discussion</strong></h2> <p><a href="https://old.reddit.com/r/anime/comments/1hiux0n/rewatch_yuuki_yuuna_ga_yuusha_wa_aru_episode_12/?limit=500">← Previous Episode</a> | <a href="https://old.reddit.com/r/anime/comments/1gugvfn/announcing_the_yuuki_yuuna_wa_yuusha_ga_aru_s1/">Index</a> | <a href="https://anidb.net/anime/12500">Next Episode?</a> →</p> <hr/> <h3>Show Information:</h3> <p><a href="https://myanimelist.net/anime/25519">MAL</a> | <a href="https://anilist.co/anime/20800/Yuuki-Yuuna-wa-Yuusha-de-Aru/">AniList</a> | <a href="https://www.animenewsnetwork.com/encyclopedia/anime.php?id=16171">ANN</a> | <a href="https://kitsu.app/anime/yuuki-yuuna-wa-yuusha-de-aru">Kitsu</a> | <a href="https://anidb.net/anime/10750">AniDB</a></p> <p><em><del>(First-timers are advised to stay out of Show Information until we are done, however. In particular, if you care about getting spoiled I would stay out of MAL (whose synopsis i

## Toradora! Christmas Club Rewatch (2024) Episode 16 Discussion
 - [https://www.reddit.com/r/anime/comments/1hjj0ke/toradora_christmas_club_rewatch_2024_episode_16](https://www.reddit.com/r/anime/comments/1hjj0ke/toradora_christmas_club_rewatch_2024_episode_16)
 - RSS feed: $source
 - date published: 2024-12-21T20:58:10+00:00

<!-- SC_OFF --><div class="md"><p>Episode 16 - One Step Forward</p> <hr/> <p>The Toradora! Christmas Club is finally here again! Together we&#39;re watching the original Toradora! series, one episode a day until December 30th.</p> <p>It&#39;s important to be courteous to first time watchers. Don&#39;t forget to keep discussions related to this episode. We&#39;ll have a new thread tomorrow and the day after (etc.), so there are plenty of opportunities to discuss new characters and moments. If you absolutely can&#39;t help yourself, just remember to add spoiler tags like so [Toradora!] <span class="md-spoiler-text">spoiler text</span></p> <hr/> <p>Threads will be posted daily at: 21:00 GMT</p> <hr/> <p><a href="http://www.crunchyroll.com/toradora">CR</a>, <a href="https://www.netflix.com/title/80049275">Netflix</a>, <a href="https://www.amazon.com/Toradora/dp/B07L7BYYXC">Amazon Prime</a>, <a href="https://www.funimation.com/shows/toradora/">Funimation</a></p> <hr/> <table><thead> <tr> 

## What is the most random anime that you have ever seen?
 - [https://www.reddit.com/r/anime/comments/1hji3pq/what_is_the_most_random_anime_that_you_have_ever](https://www.reddit.com/r/anime/comments/1hji3pq/what_is_the_most_random_anime_that_you_have_ever)
 - RSS feed: $source
 - date published: 2024-12-21T20:13:10+00:00

<!-- SC_OFF --><div class="md"><p>For me the one that is the most random is Mr.Osomatsu; Pop Team Epic! is another totally random one too.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Such_Crow8542"> /u/Such_Crow8542 </a> <br/> <span><a href="https://www.reddit.com/r/anime/comments/1hji3pq/what_is_the_most_random_anime_that_you_have_ever/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hji3pq/what_is_the_most_random_anime_that_you_have_ever/">[comments]</a></span>

## Party kara Tsuihou sareta Sono Chiyushi, Jitsu wa Saikyou ni Tsuki • The Healer Who Was Banished From His Party, Is, in Fact, the Strongest - Episode 12 discussion - FINAL
 - [https://www.reddit.com/r/anime/comments/1hjfdj2/party_kara_tsuihou_sareta_sono_chiyushi_jitsu_wa](https://www.reddit.com/r/anime/comments/1hjfdj2/party_kara_tsuihou_sareta_sono_chiyushi_jitsu_wa)
 - RSS feed: $source
 - date published: 2024-12-21T18:04:15+00:00

<!-- SC_OFF --><div class="md"><p><em>Party kara Tsuihou sareta Sono Chiyushi, Jitsu wa Saikyou ni Tsuki</em>, episode 12</p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <ul> <li><a href="http://crunchyroll.com/the-healer-who-was-banished-from-his-party-is-in-fact-the-strongest">Crunchyroll</a></li> </ul> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/57944/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/174043">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=18451">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/party-kara-tsuihou-sareta-sono-chiyushi-jitsu-wa-saikyou-nitsuki">Anime-Planet</a></li> <li><a href="https://sonochiyushi.com/">Official Website</a></li> </ul> <hr/> <p><strong>All discussions</strong></p> <table><thead> <

## Kimi wa Meido-sama. • You are Ms. Servant - Episode 12 discussion - FINAL
 - [https://www.reddit.com/r/anime/comments/1hjfdh6/kimi_wa_meidosama_you_are_ms_servant_episode_12](https://www.reddit.com/r/anime/comments/1hjfdh6/kimi_wa_meidosama_you_are_ms_servant_episode_12)
 - RSS feed: $source
 - date published: 2024-12-21T18:04:11+00:00

<!-- SC_OFF --><div class="md"><p><em>Kimi wa Meido-sama.</em>, episode 12</p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <ul> <li><a href="http://crunchyroll.com/you-are-ms-servant">Crunchyroll</a></li> </ul> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/57611/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/172190">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=18344">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/you-are-ms-servant">Anime-Planet</a></li> <li><a href="https://kimihameidosama-anime.com/">Official Website</a></li> <li><strong><a href="/r/kimiwameidosan">/r/kimiwameidosan</a></strong></li> </ul> <hr/> <p><strong>All discussions</strong></p> <table><thead> <tr> <th align="center">Episode</th> <th align="center">Li

## Ao no Exorcist Yuki no Hate-hen • Blue Exorcist: Beyond the Snow Saga - Episode 12 discussion - FINAL
 - [https://www.reddit.com/r/anime/comments/1hjfdcy/ao_no_exorcist_yuki_no_hatehen_blue_exorcist](https://www.reddit.com/r/anime/comments/1hjfdcy/ao_no_exorcist_yuki_no_hatehen_blue_exorcist)
 - RSS feed: $source
 - date published: 2024-12-21T18:04:03+00:00

<!-- SC_OFF --><div class="md"><p><em>Ao no Exorcist Yuki no Hate-hen</em>, episode 12</p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <ul> <li><a href="http://crunchyroll.com/blue-exorcist">Crunchyroll</a></li> </ul> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/58516/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/176311">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=18561">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/blue-exorcist-beyond-the-snow-saga">Anime-Planet</a></li> <li><a href="https://www.ao-ex.com/">Official Website</a></li> <li><strong><a href="/r/AoNoExorcist">/r/AoNoExorcist</a></strong></li> </ul> <hr/> <p><strong>All discussions</strong></p> <table><thead> <tr> <th align="center">Episode</th> <th align="cen

## (Saekano: How To Raise A Boring Girlfriend) The Morning After [NSFW] [Mild Spoilers]
 - [https://www.reddit.com/r/anime/comments/1hjfc2x/saekano_how_to_raise_a_boring_girlfriend_the](https://www.reddit.com/r/anime/comments/1hjfc2x/saekano_how_to_raise_a_boring_girlfriend_the)
 - RSS feed: $source
 - date published: 2024-12-21T18:02:22+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/OrneryMirror6072"> /u/OrneryMirror6072 </a> <br/> <span><a href="https://v.redd.it/kefm6wbdr88e1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hjfc2x/saekano_how_to_raise_a_boring_girlfriend_the/">[comments]</a></span>

## Bleach: Sennen Kessen-hen - Soukoku-tan • Bleach: Thousand-Year Blood War - The Conflict - Episode 12 discussion
 - [https://www.reddit.com/r/anime/comments/1hjei4y/bleach_sennen_kessenhen_soukokutan_bleach](https://www.reddit.com/r/anime/comments/1hjei4y/bleach_sennen_kessenhen_soukokutan_bleach)
 - RSS feed: $source
 - date published: 2024-12-21T17:24:23+00:00

<!-- SC_OFF --><div class="md"><p><em>Bleach: Sennen Kessen-hen - Soukoku-tan</em>, episode 12</p> <p>Alternative names: <em>Bleach: Thousand-Year Blood War</em></p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <ul> <li><a href="https://www.disneyplus.com/series/bleach-thousand-year-blood-war/4Afet1Q421gy">Disney</a></li> <li><a href="https://www.hulu.com/series/bleach-thousand-year-blood-war-span-sub-3efd0d2b-8d29-43fa-883e-d9b50cfb8cce">Hulu</a></li> </ul> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/56784/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/169755">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=18220">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/bleach-thousand-year-blood-war-part-iii-the-conflict">Anime-Planet<

## Ranma ½ (2024) - Episode 12 discussion
 - [https://www.reddit.com/r/anime/comments/1hje2d8/ranma_½_2024_episode_12_discussion](https://www.reddit.com/r/anime/comments/1hje2d8/ranma_½_2024_episode_12_discussion)
 - RSS feed: $source
 - date published: 2024-12-21T17:04:07+00:00

<!-- SC_OFF --><div class="md"><p><em>Ranma ½ (2024)</em>, episode 12</p> <p>Alternative names: <em>Ranma1/2</em></p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <p><em>None</em></p> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/59145/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/178533">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=18700">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/ranma-12-2024">Anime-Planet</a></li> <li><a href="https://ranma-pr.com/">Official Website</a></li> <li><strong><a href="/r/ranma">/r/ranma</a></strong></li> </ul> <hr/> <p><strong>All discussions</strong></p> <table><thead> <tr> <th align="center">Episode</th> <th align="center">Link</th> </tr> </thead><tbody> <tr> <td align="center">1</td> <td

## Maou 2099 • Demon Lord 2099 - Episode 11 discussion
 - [https://www.reddit.com/r/anime/comments/1hjdf8q/maou_2099_demon_lord_2099_episode_11_discussion](https://www.reddit.com/r/anime/comments/1hjdf8q/maou_2099_demon_lord_2099_episode_11_discussion)
 - RSS feed: $source
 - date published: 2024-12-21T16:34:09+00:00

<!-- SC_OFF --><div class="md"><p><em>Maou 2099</em>, episode 11</p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <ul> <li><a href="http://crunchyroll.com/demon-lord-2099">Crunchyroll</a></li> </ul> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/54853/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/163135">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=17943">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/demon-lord-2099">Anime-Planet</a></li> <li><a href="https://2099.world/">Official Website</a></li> </ul> <hr/> <p><strong>All discussions</strong></p> <table><thead> <tr> <th align="center">Episode</th> <th align="center">Link</th> </tr> </thead><tbody> <tr> <td align="center">1</td> <td align="center"><a href="https://redd.it/1g

## Ranma 1/2 (2024) Season 2 Announced
 - [https://www.reddit.com/r/anime/comments/1hjd7x4/ranma_12_2024_season_2_announced](https://www.reddit.com/r/anime/comments/1hjd7x4/ranma_12_2024_season_2_announced)
 - RSS feed: $source
 - date published: 2024-12-21T16:24:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hjd7x4/ranma_12_2024_season_2_announced/"> <img src="https://external-preview.redd.it/FFwk-MTzoUhmpFfqT6hnISiUCuv_xu-pwW-1kuXoZwI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=911354ccbf02a60761c27dfb4044b05eb33c085f" alt="Ranma 1/2 (2024) Season 2 Announced" title="Ranma 1/2 (2024) Season 2 Announced" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zenzen_0"> /u/zenzen_0 </a> <br/> <span><a href="https://x.com/ranma_pr/status/1870505509591331063?s=61&amp;t=BS-pAe_AQXrv2M2zuP9DWA">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hjd7x4/ranma_12_2024_season_2_announced/">[comments]</a></span> </td></tr></table>

## Blue Exorcist -The Blue Night Saga- Teaser Visual
 - [https://www.reddit.com/r/anime/comments/1hjcnm0/blue_exorcist_the_blue_night_saga_teaser_visual](https://www.reddit.com/r/anime/comments/1hjcnm0/blue_exorcist_the_blue_night_saga_teaser_visual)
 - RSS feed: $source
 - date published: 2024-12-21T15:57:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hjcnm0/blue_exorcist_the_blue_night_saga_teaser_visual/"> <img src="https://external-preview.redd.it/OPv7DkSt7zWsD22X4DdECAIahRaEntrc0CQ8KthobLE.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=968493814ee66756323747ca11849f0cae1684ed" alt="Blue Exorcist -The Blue Night Saga- Teaser Visual" title="Blue Exorcist -The Blue Night Saga- Teaser Visual" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://pbs.twimg.com/media/GfVYcV8asAAp6Bb.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hjcnm0/blue_exorcist_the_blue_night_saga_teaser_visual/">[comments]</a></span> </td></tr></table>

## [10 year anniversary] Interest thread for a rewatch of Saekano: How To Raise A Boring Girlfriend
 - [https://www.reddit.com/r/anime/comments/1hjci8m/10_year_anniversary_interest_thread_for_a_rewatch](https://www.reddit.com/r/anime/comments/1hjci8m/10_year_anniversary_interest_thread_for_a_rewatch)
 - RSS feed: $source
 - date published: 2024-12-21T15:49:59+00:00

<!-- SC_OFF --><div class="md"><p><a href="https://v.animethemes.moe/Saekano-OP1.webm">Hello Reddit</a></p> <p>This will be my first time to put together a rewatch, and it will be a solid one because it is (proudly and unironically) my favorite anime of all-time. Coincidentally it is also approaching its 10 year anniversary on January 9th 2025, which is the perfect time to rally a group of people to (re)experience this forgotten gem.</p> <p><em>Saenai Heroine no Sodatekata</em> also known as <em>Saekano: How To Raise a Boring Girlfriend</em> is a high-school themed romance comedy harem that showcases otaku culture and deep dives into ecchi while doing so. It is a stunningly self-aware piece of art that manages to subvert anime tropes and transcend. As the plot goes on, it evolves into a proper romance drama. Great writing meets impeccable comedic timing, brought together by beautifully executed voice acting, it is a well-rounded anime experience. Be warned, it does not hold back on t

## "TO BE HERO X" 2nd PV | Broadcast begins on Fuji TV at 9:30am on Sundays in April 2025!
 - [https://www.reddit.com/r/anime/comments/1hjc9bp/to_be_hero_x_2nd_pv_broadcast_begins_on_fuji_tv](https://www.reddit.com/r/anime/comments/1hjc9bp/to_be_hero_x_2nd_pv_broadcast_begins_on_fuji_tv)
 - RSS feed: $source
 - date published: 2024-12-21T15:37:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hjc9bp/to_be_hero_x_2nd_pv_broadcast_begins_on_fuji_tv/"> <img src="https://external-preview.redd.it/q3LP9xmJ1dUpPKbt2xhY6BhR8298nE0kE_Ps5XP3Q0c.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=13e1f9f9ee7e0332f39ae87210f2b081d835d765" alt="&quot;TO BE HERO X&quot; 2nd PV | Broadcast begins on Fuji TV at 9:30am on Sundays in April 2025!" title="&quot;TO BE HERO X&quot; 2nd PV | Broadcast begins on Fuji TV at 9:30am on Sundays in April 2025!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ToonAdventure"> /u/ToonAdventure </a> <br/> <span><a href="https://www.youtube.com/watch?v=ynd2-ZeiNoY">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hjc9bp/to_be_hero_x_2nd_pv_broadcast_begins_on_fuji_tv/">[comments]</a></span> </td></tr></table>

## Chi.: Chikyuu no Undou ni Tsuite • Orb: On the Movements of the Earth - Episode 13 discussion
 - [https://www.reddit.com/r/anime/comments/1hjc6ui/chi_chikyuu_no_undou_ni_tsuite_orb_on_the](https://www.reddit.com/r/anime/comments/1hjc6ui/chi_chikyuu_no_undou_ni_tsuite_orb_on_the)
 - RSS feed: $source
 - date published: 2024-12-21T15:34:09+00:00

<!-- SC_OFF --><div class="md"><p><em>Chi.: Chikyuu no Undou ni Tsuite</em>, episode 13</p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <p><em>None</em></p> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/52215/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/151514">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=17480">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/chi-chikyuu-no-undou-ni-tsuite">Anime-Planet</a></li> <li><a href="https://anime-chi.jp/">Official Website</a></li> </ul> <hr/> <p><strong>All discussions</strong></p> <table><thead> <tr> <th align="center">Episode</th> <th align="center">Link</th> </tr> </thead><tbody> <tr> <td align="center">1</td> <td align="center"><a href="https://redd.it/1fwtvez">Link</a></td> </t

## What's your most anticipated anime for 2025?
 - [https://www.reddit.com/r/anime/comments/1hjc543/whats_your_most_anticipated_anime_for_2025](https://www.reddit.com/r/anime/comments/1hjc543/whats_your_most_anticipated_anime_for_2025)
 - RSS feed: $source
 - date published: 2024-12-21T15:31:57+00:00

<!-- SC_OFF --><div class="md"><p>What anime are you most anticipating for next year? It&#39;s looking like a great year for anime. What shows are you looking forward to? Interested to look back at this in a year.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Kiryu-chan5545"> /u/Kiryu-chan5545 </a> <br/> <span><a href="https://www.reddit.com/r/anime/comments/1hjc543/whats_your_most_anticipated_anime_for_2025/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hjc543/whats_your_most_anticipated_anime_for_2025/">[comments]</a></span>

## Blue Lock vs. U-20 Japan • Blue Lock Season 2 - Episode 12 discussion
 - [https://www.reddit.com/r/anime/comments/1hjbl57/blue_lock_vs_u20_japan_blue_lock_season_2_episode](https://www.reddit.com/r/anime/comments/1hjbl57/blue_lock_vs_u20_japan_blue_lock_season_2_episode)
 - RSS feed: $source
 - date published: 2024-12-21T15:04:08+00:00

<!-- SC_OFF --><div class="md"><p><em>Blue Lock vs. U-20 Japan</em>, episode 12</p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <ul> <li><a href="http://crunchyroll.com/blue-lock">Crunchyroll</a></li> </ul> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/54865/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/163146">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=17954">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/blue-lock-2nd-season">Anime-Planet</a></li> <li><a href="https://tv.bluelock-pr.com/">Official Website</a></li> <li><strong><a href="/r/BlueLock">/r/BlueLock</a></strong></li> </ul> <hr/> <p><strong>All discussions</strong></p> <table><thead> <tr> <th align="center">Episode</th> <th align="center">Link</th> </tr> </thead

## Solo Leveling Season 2 -Arise from the Shadow- New Main PV
 - [https://www.reddit.com/r/anime/comments/1hjbi8h/solo_leveling_season_2_arise_from_the_shadow_new](https://www.reddit.com/r/anime/comments/1hjbi8h/solo_leveling_season_2_arise_from_the_shadow_new)
 - RSS feed: $source
 - date published: 2024-12-21T15:00:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hjbi8h/solo_leveling_season_2_arise_from_the_shadow_new/"> <img src="https://external-preview.redd.it/qfX3Ugzj7lvji9IYJYS3sNSe8NUQ-m63hEsOsblX9Is.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=d8c997eb29e9acd1e7d352704eba022ed0504da3" alt="Solo Leveling Season 2 -Arise from the Shadow- New Main PV" title="Solo Leveling Season 2 -Arise from the Shadow- New Main PV" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://www.youtube.com/watch?v=DYTZbJ2Y4Yk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hjbi8h/solo_leveling_season_2_arise_from_the_shadow_new/">[comments]</a></span> </td></tr></table>

## Are there any Japanese voice actors other than Sally Amaki that voice both the Japanese and English versions of characters?
 - [https://www.reddit.com/r/anime/comments/1hj9f64/are_there_any_japanese_voice_actors_other_than](https://www.reddit.com/r/anime/comments/1hj9f64/are_there_any_japanese_voice_actors_other_than)
 - RSS feed: $source
 - date published: 2024-12-21T13:02:59+00:00

<!-- SC_OFF --><div class="md"><p>Sally Amaki is the only one I&#39;m aware of, but I think it&#39;s really cool. I first found out about her when Tomo-chan Is A Girl came out almost 2 years ago, when she voiced the Japanese and English version of Carl Olston. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SaberLover1000"> /u/SaberLover1000 </a> <br/> <span><a href="https://www.reddit.com/r/anime/comments/1hj9f64/are_there_any_japanese_voice_actors_other_than/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj9f64/are_there_any_japanese_voice_actors_other_than/">[comments]</a></span>

## Tohai - Ura Rate Mahjong Tohai Roku - Episode 12 discussion
 - [https://www.reddit.com/r/anime/comments/1hj8sl9/tohai_ura_rate_mahjong_tohai_roku_episode_12](https://www.reddit.com/r/anime/comments/1hj8sl9/tohai_ura_rate_mahjong_tohai_roku_episode_12)
 - RSS feed: $source
 - date published: 2024-12-21T12:22:09+00:00

<!-- SC_OFF --><div class="md"><p><em>Tohai - Ura Rate Mahjong Tohai Roku</em>, episode 12</p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <p><em>None</em></p> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/57796/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/173263">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=18404">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/touhai-ura-rate-mahjong-touhai-roku">Anime-Planet</a></li> <li><a href="https://tohai-anime.com/">Official Website</a></li> </ul> <hr/> <p><strong>All discussions</strong></p> <table><thead> <tr> <th align="center">Episode</th> <th align="center">Link</th> </tr> </thead><tbody> <tr> <td align="center">1</td> <td align="center"><a href="https://redd.it/1g2ceb2">Link</

## In Japan, Netflix streaming of SAKAMOTO DAYS begins with a two-episode premiere on January 11 [Thu] (the same situation as "Blue Box").
 - [https://www.reddit.com/r/anime/comments/1hj7r5j/in_japan_netflix_streaming_of_sakamoto_days](https://www.reddit.com/r/anime/comments/1hj7r5j/in_japan_netflix_streaming_of_sakamoto_days)
 - RSS feed: $source
 - date published: 2024-12-21T11:08:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj7r5j/in_japan_netflix_streaming_of_sakamoto_days/"> <img src="https://external-preview.redd.it/f0SYhc-pAbkVqeBQIgVA8GsxUn-fk10vGrRMgDk3VoU.jpg?width=108&amp;crop=smart&amp;auto=webp&amp;s=49eaa8d66e483c4ff41bc932915bbe1dac1d461d" alt="In Japan, Netflix streaming of SAKAMOTO DAYS begins with a two-episode premiere on January 11 [Thu] (the same situation as &quot;Blue Box&quot;)." title="In Japan, Netflix streaming of SAKAMOTO DAYS begins with a two-episode premiere on January 11 [Thu] (the same situation as &quot;Blue Box&quot;)." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/tripleaamin"> /u/tripleaamin </a> <br/> <span><a href="https://twitter.com/air_news01/status/1870351753688014876?s=46&amp;t=x4SSZ8X-OwGJ7PEPhL-x3w">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj7r5j/in_japan_netflix_streaming_of_sakamoto_days/">[comments]</a></span> </td></tr>

## What's your top 10 anime?
 - [https://www.reddit.com/r/anime/comments/1hj7gnl/whats_your_top_10_anime](https://www.reddit.com/r/anime/comments/1hj7gnl/whats_your_top_10_anime)
 - RSS feed: $source
 - date published: 2024-12-21T10:47:41+00:00

<!-- SC_OFF --><div class="md"><p>This is always a difficult question for me to answer, and it gets harder as time goes on, mainly because I&#39;ve seen more anime than most anime fans, and the more I&#39;ve seen the harder it is to pin down 10. But here&#39;s what I got right now. </p> <p>10.Eureka 7</p> <p>9.Spice and Wolf</p> <ol> <li><p>Monster</p></li> <li><p>Psycho Pass</p></li> </ol> <p>6.Toradora</p> <p>5.Fullmetal Alchemist/Fullmetal Alchemist: Brotherhood</p> <p>4.Hunter X Hunter 2011</p> <p>3.Code Geass</p> <p>2.Fate/Zero</p> <p>1.Made In Abyss</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SaberLover1000"> /u/SaberLover1000 </a> <br/> <span><a href="https://www.reddit.com/r/anime/comments/1hj7gnl/whats_your_top_10_anime/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj7gnl/whats_your_top_10_anime/">[comments]</a></span>

## Durarara!! is my next love
 - [https://www.reddit.com/r/anime/comments/1hj75t7/durarara_is_my_next_love](https://www.reddit.com/r/anime/comments/1hj75t7/durarara_is_my_next_love)
 - RSS feed: $source
 - date published: 2024-12-21T10:25:01+00:00

<!-- SC_OFF --><div class="md"><p>I am watching it this weekend and loving every moment of it. Everything is different from what I have watched so far (in about 100+ anime) yet different in such an amazing way. It just sucks you in the world it presents and keeps you in there.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WhyAlwaysBored"> /u/WhyAlwaysBored </a> <br/> <span><a href="https://www.reddit.com/r/anime/comments/1hj75t7/durarara_is_my_next_love/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj75t7/durarara_is_my_next_love/">[comments]</a></span>

## Anime Questions, Recommendations, and Discussion - December 21, 2024
 - [https://www.reddit.com/r/anime/comments/1hj6uf8/anime_questions_recommendations_and_discussion](https://www.reddit.com/r/anime/comments/1hj6uf8/anime_questions_recommendations_and_discussion)
 - RSS feed: $source
 - date published: 2024-12-21T10:00:48+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj6uf8/anime_questions_recommendations_and_discussion/"> <img src="https://external-preview.redd.it/Z-cYo917BxHjlySpbnmstPc5N8kRDunO_6zskMmOY4E.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=73586a56618d181f2958ce536fcb2aee12826809" alt="Anime Questions, Recommendations, and Discussion - December 21, 2024" title="Anime Questions, Recommendations, and Discussion - December 21, 2024" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>This is a daily megathread for general chatter about anime. Have questions or need recommendations? Here to show off your merch? Want to talk about what you just watched?</p> <p><a href="https://preview.redd.it/aljh31dic48e1.png?width=1280&amp;format=png&amp;auto=webp&amp;s=e5cf0324063d037db809b3939882e9146605200a">This is the place!</a></p> <p><a href="/r/anime/wiki/rules#wiki_tagging_comments"><strong>All spoilers must be tagged.</strong></a> Use <code>[anime name]</code> to indicate t

## Look Back has been nominated at the Annie Awards
 - [https://www.reddit.com/r/anime/comments/1hj60cs/look_back_has_been_nominated_at_the_annie_awards](https://www.reddit.com/r/anime/comments/1hj60cs/look_back_has_been_nominated_at_the_annie_awards)
 - RSS feed: $source
 - date published: 2024-12-21T08:56:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj60cs/look_back_has_been_nominated_at_the_annie_awards/"> <img src="https://external-preview.redd.it/-7BWHn6tvZ37d1_7Jx8uY391p6qShCNTo8mUaXdBpoI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2aac24b3a9accca5157b1b274cfa6c17f1e09b73" alt="Look Back has been nominated at the Annie Awards" title="Look Back has been nominated at the Annie Awards" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ddiaconu21"> /u/ddiaconu21 </a> <br/> <span><a href="https://x.com/annieawards/status/1870169845657919668?s=46">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj60cs/look_back_has_been_nominated_at_the_annie_awards/">[comments]</a></span> </td></tr></table>

## TV anime "Dandadan" Season 2 teaser PV | Scheduled to be broadcast nationwide from July 2025
 - [https://www.reddit.com/r/anime/comments/1hj5qaq/tv_anime_dandadan_season_2_teaser_pv_scheduled_to](https://www.reddit.com/r/anime/comments/1hj5qaq/tv_anime_dandadan_season_2_teaser_pv_scheduled_to)
 - RSS feed: $source
 - date published: 2024-12-21T08:34:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj5qaq/tv_anime_dandadan_season_2_teaser_pv_scheduled_to/"> <img src="https://external-preview.redd.it/6mO58XpKi6SHpXnTW14nL07szld1zfIaINq5HJ1Y_V0.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=f32b1f3dd43bf5ebb5a624331342ee68649e0a36" alt="TV anime &quot;Dandadan&quot; Season 2 teaser PV | Scheduled to be broadcast nationwide from July 2025" title="TV anime &quot;Dandadan&quot; Season 2 teaser PV | Scheduled to be broadcast nationwide from July 2025" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ToonAdventure"> /u/ToonAdventure </a> <br/> <span><a href="https://www.youtube.com/watch?v=cXXRYlDcG-o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj5qaq/tv_anime_dandadan_season_2_teaser_pv_scheduled_to/">[comments]</a></span> </td></tr></table>

## Spy x Family Season 3 to air October 2025
 - [https://www.reddit.com/r/anime/comments/1hj4mnc/spy_x_family_season_3_to_air_october_2025](https://www.reddit.com/r/anime/comments/1hj4mnc/spy_x_family_season_3_to_air_october_2025)
 - RSS feed: $source
 - date published: 2024-12-21T07:10:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj4mnc/spy_x_family_season_3_to_air_october_2025/"> <img src="https://external-preview.redd.it/DXJQ263sfZufhz5U15lzLgurHKSJkjpVIsxs-ckv93Q.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e450e68af51bc5af199997369a862631877a91c3" alt="Spy x Family Season 3 to air October 2025" title="Spy x Family Season 3 to air October 2025" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://twitter.com/comic_natalie/status/1870366128712847680">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj4mnc/spy_x_family_season_3_to_air_october_2025/">[comments]</a></span> </td></tr></table>

## 3-Z Class's Ginpachi-sensei Anime New Trailer
 - [https://www.reddit.com/r/anime/comments/1hj4loz/3z_classs_ginpachisensei_anime_new_trailer](https://www.reddit.com/r/anime/comments/1hj4loz/3z_classs_ginpachisensei_anime_new_trailer)
 - RSS feed: $source
 - date published: 2024-12-21T07:08:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj4loz/3z_classs_ginpachisensei_anime_new_trailer/"> <img src="https://external-preview.redd.it/Mq20oQhjSlE8Bha9rc6yKljeiOPk2Y2hrZnMINhgQok.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=0159eb349bc29478c151a5ba33762a3765ea7fc8" alt="3-Z Class's Ginpachi-sensei Anime New Trailer" title="3-Z Class's Ginpachi-sensei Anime New Trailer" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MemoryNK"> /u/MemoryNK </a> <br/> <span><a href="https://www.youtube.com/watch?v=CL_qrNqvKHk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj4loz/3z_classs_ginpachisensei_anime_new_trailer/">[comments]</a></span> </td></tr></table>

## Sakamoto Days Anime New PV
 - [https://www.reddit.com/r/anime/comments/1hj3emn/sakamoto_days_anime_new_pv](https://www.reddit.com/r/anime/comments/1hj3emn/sakamoto_days_anime_new_pv)
 - RSS feed: $source
 - date published: 2024-12-21T05:45:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj3emn/sakamoto_days_anime_new_pv/"> <img src="https://external-preview.redd.it/0rK-KGyKhNZlumm8V1nXYR4BizE14ycwk8c7c16k8SU.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=8ba463e4b0f9e24e243574c01d823d7de6b765d7" alt="Sakamoto Days Anime New PV" title="Sakamoto Days Anime New PV" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://www.youtube.com/watch?v=CdnMoPIgC5s">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj3emn/sakamoto_days_anime_new_pv/">[comments]</a></span> </td></tr></table>

## Hell's Paradise Season 2 to air January 2026
 - [https://www.reddit.com/r/anime/comments/1hj35zw/hells_paradise_season_2_to_air_january_2026](https://www.reddit.com/r/anime/comments/1hj35zw/hells_paradise_season_2_to_air_january_2026)
 - RSS feed: $source
 - date published: 2024-12-21T05:30:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj35zw/hells_paradise_season_2_to_air_january_2026/"> <img src="https://external-preview.redd.it/iHjKlJSWppq0eUtWlp-5gbXxZNeaaKqu_wR9QOKMvWI.jpg?width=108&amp;crop=smart&amp;auto=webp&amp;s=5e2a7821004d80bbd355947ecc20d5d318432b03" alt="Hell's Paradise Season 2 to air January 2026" title="Hell's Paradise Season 2 to air January 2026" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://twitter.com/jplus_jigokurak/status/1870340924967928068">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj35zw/hells_paradise_season_2_to_air_january_2026/">[comments]</a></span> </td></tr></table>

## Undead Unluck New Anime Will Feature an Original Story With New UMA "Balance"
 - [https://www.reddit.com/r/anime/comments/1hj35uw/undead_unluck_new_anime_will_feature_an_original](https://www.reddit.com/r/anime/comments/1hj35uw/undead_unluck_new_anime_will_feature_an_original)
 - RSS feed: $source
 - date published: 2024-12-21T05:29:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj35uw/undead_unluck_new_anime_will_feature_an_original/"> <img src="https://external-preview.redd.it/J9UeIXiJlM7Pb4nvZ6R_spA2ZviDgmebLQdhxs8xRTU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=7e4828369bf867f616b2ac7fcd71fa72e3c390c4" alt="Undead Unluck New Anime Will Feature an Original Story With New UMA &quot;Balance&quot;" title="Undead Unluck New Anime Will Feature an Original Story With New UMA &quot;Balance&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Task_Force-191"> /u/Task_Force-191 </a> <br/> <span><a href="https://x.com/undeadunluck_an/status/1870335891308224892?t=oTn0l2zpsTZFSZRSWFRUCg&amp;s=19">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj35uw/undead_unluck_new_anime_will_feature_an_original/">[comments]</a></span> </td></tr></table>

## Pokémon Horizons: The Series - Episode 78 discussion
 - [https://www.reddit.com/r/anime/comments/1hj29hx/pokémon_horizons_the_series_episode_78_discussion](https://www.reddit.com/r/anime/comments/1hj29hx/pokémon_horizons_the_series_episode_78_discussion)
 - RSS feed: $source
 - date published: 2024-12-21T04:34:05+00:00

<!-- SC_OFF --><div class="md"><p><em>Pokémon Horizons: The Series</em>, episode 78</p> <p>Alternative names: <em>Pocket Monsters (2023)</em></p> <p><strong>Reminder:</strong> Please do not discuss plot points not yet seen or skipped in the show. Failing to follow the rules may result in a ban.</p> <hr/> <p><strong>Streams</strong></p> <p><em>None</em></p> <p><strong>Show information</strong></p> <ul> <li><a href="https://myanimelist.net/anime/53876/">MyAnimeList</a></li> <li><a href="https://anilist.co/anime/158871">AniList</a></li> <li><a href="https://anidb.net/perl-bin/animedb.pl?show=anime&amp;aid=17777">AniDB</a></li> <li><a href="https://www.anime-planet.com/anime/pokemon-2023">Anime-Planet</a></li> <li><a href="https://www.tv-tokyo.co.jp/anime/pocketmonster2023/">Official Website</a></li> <li><strong><a href="/r/pokemonanime">/r/pokemonanime</a></strong></li> </ul> <hr/> <p><strong>All discussions</strong></p> <table><thead> <tr> <th align="center">Episode</th> <th align="cen

## Witch Watch Anime New PV
 - [https://www.reddit.com/r/anime/comments/1hj27aw/witch_watch_anime_new_pv](https://www.reddit.com/r/anime/comments/1hj27aw/witch_watch_anime_new_pv)
 - RSS feed: $source
 - date published: 2024-12-21T04:30:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj27aw/witch_watch_anime_new_pv/"> <img src="https://external-preview.redd.it/gjuiEjKTg5ToddTsRhC7u6FDtuold0APsl4QLSY-7O8.jpg?width=108&amp;crop=smart&amp;auto=webp&amp;s=5afad97b140d7821c0e6cb248c22a630888218e6" alt="Witch Watch Anime New PV" title="Witch Watch Anime New PV" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://twitter.com/WITCHWATCHanime/status/1870325825851228207">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj27aw/witch_watch_anime_new_pv/">[comments]</a></span> </td></tr></table>

## [CV. Mayumi Tanaka] "Me and Roboco" Movie Multiverse Roboco PV①│Nationwide release on Friday, April 18, 2025!
 - [https://www.reddit.com/r/anime/comments/1hj1tu3/cv_mayumi_tanaka_me_and_roboco_movie_multiverse](https://www.reddit.com/r/anime/comments/1hj1tu3/cv_mayumi_tanaka_me_and_roboco_movie_multiverse)
 - RSS feed: $source
 - date published: 2024-12-21T04:06:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj1tu3/cv_mayumi_tanaka_me_and_roboco_movie_multiverse/"> <img src="https://external-preview.redd.it/A9Vxo14Iw26HQfZ-e1Mt2B4RiNmFsFKhq0gDNL-D9Qc.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=9d417126e3d0d0dd0626050b7b0fc59960e0df1f" alt="[CV. Mayumi Tanaka] &quot;Me and Roboco&quot; Movie Multiverse Roboco PV①│Nationwide release on Friday, April 18, 2025!" title="[CV. Mayumi Tanaka] &quot;Me and Roboco&quot; Movie Multiverse Roboco PV①│Nationwide release on Friday, April 18, 2025!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ToonAdventure"> /u/ToonAdventure </a> <br/> <span><a href="https://www.youtube.com/watch?v=UyebnzNYZQ8">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj1tu3/cv_mayumi_tanaka_me_and_roboco_movie_multiverse/">[comments]</a></span> </td></tr></table>

## Rurouni Kenshin -Kyoto Disturbance- New Story Visual
 - [https://www.reddit.com/r/anime/comments/1hj1q7q/rurouni_kenshin_kyoto_disturbance_new_story_visual](https://www.reddit.com/r/anime/comments/1hj1q7q/rurouni_kenshin_kyoto_disturbance_new_story_visual)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj1q7q/rurouni_kenshin_kyoto_disturbance_new_story_visual/"> <img src="https://external-preview.redd.it/GcP5B-bt5rAFiObOJIjp_VjGpQuFIXAcZSxyKktes88.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f19c462dd032f188e0de8a9e8127ee76587d54cb" alt="Rurouni Kenshin -Kyoto Disturbance- New Story Visual" title="Rurouni Kenshin -Kyoto Disturbance- New Story Visual" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://ogre.natalie.mu/media/news/comic/2024/1220/ruroken_story.jpg?imwidth=750&amp;imdensity=1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj1q7q/rurouni_kenshin_kyoto_disturbance_new_story_visual/">[comments]</a></span> </td></tr></table>

## TV anime "Rurouni Kenshin: Meiji Swordsman Romantic Story - Kyoto Disturbance" Season 2, 4th trailer
 - [https://www.reddit.com/r/anime/comments/1hj1jdx/tv_anime_rurouni_kenshin_meiji_swordsman_romantic](https://www.reddit.com/r/anime/comments/1hj1jdx/tv_anime_rurouni_kenshin_meiji_swordsman_romantic)
 - RSS feed: $source
 - date published: 2024-12-21T03:49:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj1jdx/tv_anime_rurouni_kenshin_meiji_swordsman_romantic/"> <img src="https://external-preview.redd.it/-I7qMYqDcR4uEtzKnQRgXp-GamiKOMmxyi4oK_04KCI.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=0d0c025d0392569c8ca2bd012029fb6d3f5d0f7b" alt="TV anime &quot;Rurouni Kenshin: Meiji Swordsman Romantic Story - Kyoto Disturbance&quot; Season 2, 4th trailer" title="TV anime &quot;Rurouni Kenshin: Meiji Swordsman Romantic Story - Kyoto Disturbance&quot; Season 2, 4th trailer" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Task_Force-191"> /u/Task_Force-191 </a> <br/> <span><a href="https://youtu.be/z2ZEyhDwQ6o?si=-VEdsINGvtQFmuA4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj1jdx/tv_anime_rurouni_kenshin_meiji_swordsman_romantic/">[comments]</a></span> </td></tr></table>

## Red Cat Ramen Season 2 Announced
 - [https://www.reddit.com/r/anime/comments/1hj0ois/red_cat_ramen_season_2_announced](https://www.reddit.com/r/anime/comments/1hj0ois/red_cat_ramen_season_2_announced)
 - RSS feed: $source
 - date published: 2024-12-21T02:59:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hj0ois/red_cat_ramen_season_2_announced/"> <img src="https://external-preview.redd.it/iIRbwCcqh8v9NA5xVgmInj2--WjVUB2aKs1a-1hon6s.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=55c4b194dd30146e425175cb23a8e521fe611f0d" alt="Red Cat Ramen Season 2 Announced" title="Red Cat Ramen Season 2 Announced" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Torque-A"> /u/Torque-A </a> <br/> <span><a href="https://twitter.com/ramenakaneko/status/1870302601344168409">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hj0ois/red_cat_ramen_season_2_announced/">[comments]</a></span> </td></tr></table>

## 'Jujutsu Kaisen: The Culling Game' Key Visual
 - [https://www.reddit.com/r/anime/comments/1hizsfw/jujutsu_kaisen_the_culling_game_key_visual](https://www.reddit.com/r/anime/comments/1hizsfw/jujutsu_kaisen_the_culling_game_key_visual)
 - RSS feed: $source
 - date published: 2024-12-21T02:08:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hizsfw/jujutsu_kaisen_the_culling_game_key_visual/"> <img src="https://external-preview.redd.it/AG-gmPtmH1REEJvOvU42huhlkB1aKaOGVqQM5ple2iQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d253688e86f382b63ab74583f55bdca84bc36615" alt="'Jujutsu Kaisen: The Culling Game' Key Visual" title="'Jujutsu Kaisen: The Culling Game' Key Visual" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MarvelsGrantMan136"> /u/MarvelsGrantMan136 </a> <br/> <span><a href="https://pbs.twimg.com/media/GfSa9_xasAAKIxZ.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hizsfw/jujutsu_kaisen_the_culling_game_key_visual/">[comments]</a></span> </td></tr></table>

## JUJUTSU KAISEN Movie: Hidden Inventory/Premature Death New Visual
 - [https://www.reddit.com/r/anime/comments/1hizqxg/jujutsu_kaisen_movie_hidden_inventorypremature](https://www.reddit.com/r/anime/comments/1hizqxg/jujutsu_kaisen_movie_hidden_inventorypremature)
 - RSS feed: $source
 - date published: 2024-12-21T02:06:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hizqxg/jujutsu_kaisen_movie_hidden_inventorypremature/"> <img src="https://external-preview.redd.it/Eh9dt2snNjfr0GiPweDLogLEn_np9JzN5k-qA6ImirI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0d9d6529e0868ef58782e0f18f9ecca89b9c01df" alt="JUJUTSU KAISEN Movie: Hidden Inventory/Premature Death New Visual" title="JUJUTSU KAISEN Movie: Hidden Inventory/Premature Death New Visual" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://pbs.twimg.com/media/GfSadvDasAAWzwr.jpg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hizqxg/jujutsu_kaisen_movie_hidden_inventorypremature/">[comments]</a></span> </td></tr></table>

## Yu-Gi-Oh! GX Remastered Key Visual
 - [https://www.reddit.com/r/anime/comments/1hizdte/yugioh_gx_remastered_key_visual](https://www.reddit.com/r/anime/comments/1hizdte/yugioh_gx_remastered_key_visual)
 - RSS feed: $source
 - date published: 2024-12-21T01:46:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hizdte/yugioh_gx_remastered_key_visual/"> <img src="https://external-preview.redd.it/1N-PDBlWMV6472fa4sufzILXl5DBRKy3Zldk1iMpp6w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e7bc6244bd1c396abf7a290057389dd1be88d985" alt="Yu-Gi-Oh! GX Remastered Key Visual" title="Yu-Gi-Oh! GX Remastered Key Visual" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Turbostrider27"> /u/Turbostrider27 </a> <br/> <span><a href="https://ogre.natalie.mu/media/news/comic/2024/1220/GX_remaster_KV.jpg?imwidth=750&amp;imdensity=1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hizdte/yugioh_gx_remastered_key_visual/">[comments]</a></span> </td></tr></table>

## Yugioh Card Game The Chronicles Anime Announced!
 - [https://www.reddit.com/r/anime/comments/1hiz9t8/yugioh_card_game_the_chronicles_anime_announced](https://www.reddit.com/r/anime/comments/1hiz9t8/yugioh_card_game_the_chronicles_anime_announced)
 - RSS feed: $source
 - date published: 2024-12-21T01:39:36+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/anime/comments/1hiz9t8/yugioh_card_game_the_chronicles_anime_announced/"> <img src="https://external-preview.redd.it/6CIl9nYmQTv1GcTkDXw0u_TmxauyHcUO6YHJLX5hTi0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=02a07de226cce4fe82103e7eb453701600942fc7" alt="Yugioh Card Game The Chronicles Anime Announced!" title="Yugioh Card Game The Chronicles Anime Announced!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/RinariTennoji"> /u/RinariTennoji </a> <br/> <span><a href="https://x.com/YuGiOh_OCG_INFO/status/1870281445060882899">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/anime/comments/1hiz9t8/yugioh_card_game_the_chronicles_anime_announced/">[comments]</a></span> </td></tr></table>

## Love Triangle sucks soo much
 - [https://www.reddit.com/r/anime/comments/1hiy0ev/love_triangle_sucks_soo_much](https://www.reddit.com/r/anime/comments/1hiy0ev/love_triangle_sucks_soo_much)
 - RSS feed: $source
 - date published: 2024-12-21T00:32:12+00:00

<!-- SC_OFF --><div class="md"><p>I&#39;ve noticed a trend in my viewing habits recently. Some of the best romance (IMHO) in recent times that I&#39;ve watched all basically doesnt depend on love triangle to create unnecessary drama. The Dangers in My Heart, Skip to Loafers, Kaguya-sama Love is War, My Dress Up Darling. i maybe kinda grew tired of the unnecessary drama that love triangles create. It feels cheap, it is annoying to see characters get hurt and it feels like a worn out trope. I recently felt all those things watching Blue Box and it genuinely made me drop the show. DanDaDan is also leaning on the same trope and it is starting to get on my nerves. </p> <p>Those shows that i listed proves that you can have great romance by just focusing on the characters, giving them moments to grow closer together daily instead of trying to push stupid drama to build engagement. All of those shows just focus on those 2 characters, giving them as much moment together, creating beautiful me

