# Source:Prime Video, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCQJWtTnAHhEG5w4uN0udnUQ, language:en

## Who knew Lucy Liu and Kiernan Shipka were such artists? | Red One
 - [https://www.youtube.com/watch?v=Boq1Z9Cl0W8](https://www.youtube.com/watch?v=Boq1Z9Cl0W8)
 - RSS feed: $source
 - date published: 2024-12-21T21:00:06+00:00

Kiernan Shipka and Lucy Liu? Say no more. Starring J.K Simmons, Lucy Liu, Bonnie Hunt, Dwayne Johnson, Kiernan Shipka, and Chris Evans, Red One is on Prime Video.
 
About Red One: After Santa Claus – Code Name: RED ONE – is kidnapped, the North Pole’s Head of Security (Dwayne Johnson) must team up with the world’s most infamous bounty hunter (Chris Evans) in a globe-trotting, action-packed mission to save Christmas.
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.

#RedOne #PrimeVideo #Shorts

## Face Time with the Cast | Cruel Intentions | Prime Video
 - [https://www.youtube.com/watch?v=XLDuXPNM-xI](https://www.youtube.com/watch?v=XLDuXPNM-xI)
 - RSS feed: $source
 - date published: 2024-12-21T20:00:11+00:00

Sarah Catherine Hook, Khobe Clarke, Sara Silva, and John Harlan Kim are here for a Cruel Intentions version of Face Off, an interview series in which casts ask questions while painting portraits. Cruel Intentions, starring Zac Burgess, Sarah Catherine Hook, Savannah Lee Smith, Sara Silva, and more, is out now on Prime Video.
 
» Watch Cruel Intentions on Prime Video: https://amzn.to/4hVffGJ
» SUBSCRIBE: http://bit.ly/PrimeVideoSubscribe
 
About Cruel Intentions: Cruel Intentions follows the elite students of Manchester College, where ruthless step-siblings, Caroline and Lucien, will do anything to stay on top of the cutthroat social hierarchy. After a brutal hazing incident threatens all of Greek Life, they’ll do whatever is necessary to preserve their power and reputation, even if that means seducing the daughter of the Vice President
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available t

## Kiernan Shipka and Lucy Liu Paint Each Other | Red One | Prime Video
 - [https://www.youtube.com/watch?v=lVqQwMlwH9s](https://www.youtube.com/watch?v=lVqQwMlwH9s)
 - RSS feed: $source
 - date published: 2024-12-21T19:00:32+00:00

Kiernan Shipka and Lucy Liu? Say no more. Starring J.K Simmons, Lucy Liu, Bonnie Hunt, Dwayne Johnson, Kiernan Shipka, and Chris Evans, Red One is on Prime Video.
 
» Watch Red One on Prime Video: https://amzn.to/41HLl2X
» SUBSCRIBE: http://bit.ly/PrimeVideoSubscribe
 
About Red One: After Santa Claus – Code Name: RED ONE – is kidnapped, the North Pole’s Head of Security (Dwayne Johnson) must team up with the world’s most infamous bounty hunter (Chris Evans) in a globe-trotting, action-packed mission to save Christmas.
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.
 
Get More Prime Video: 
Stream Now: http://bit.ly/WatchMorePrimeVideo

## The Deep? Sorry, we only know The Peak | The Boys
 - [https://www.youtube.com/watch?v=PfxP4c8mhks](https://www.youtube.com/watch?v=PfxP4c8mhks)
 - RSS feed: $source
 - date published: 2024-12-21T17:00:22+00:00

Antony Starr, Jack Quaid, and more star in The Boys, now streaming on Prime Video.

About The Boys: THE BOYS is an irreverent take on what happens when superheroes, who are as popular as celebrities, as influential as politicians and as revered as Gods, abuse their superpowers rather than use them for good. It's the powerless against the super powerful as The Boys embark on a heroic quest to expose the truth about “The Seven,” and their formidable Vought backing.
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.
 
#TheBoys #Shorts #PrimeVideo

## Guilty as charged. | Culpa Tuya
 - [https://www.youtube.com/watch?v=H_Q8HxF8C-o](https://www.youtube.com/watch?v=H_Q8HxF8C-o)
 - RSS feed: $source
 - date published: 2024-12-21T15:00:13+00:00

Culpa Tuya premieres December 27.
 
About Culpa Tuya: A sequel to the global hit My Fault; the love between Noah and Nick seems unwavering despite their parents’ attempts to separate them. But his job and her entry into college open up their lives to new relationships that will shake the foundations of both their relationship and the Leister family itself. When so many people are ready to destroy a relationship, can it really end well?
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.
 
#PrimeVideo #CulpaTuya #Shorts

## Tilda Swinton voiced The Deep's octopus lover —the more you (definitely needed to) know. | The Boys
 - [https://www.youtube.com/watch?v=VMCJ1myvU4Q](https://www.youtube.com/watch?v=VMCJ1myvU4Q)
 - RSS feed: $source
 - date published: 2024-12-21T02:00:16+00:00

Antony Starr, Jack Quaid, and more star in The Boys, now streaming on Prime Video.

About The Boys: THE BOYS is an irreverent take on what happens when superheroes, who are as popular as celebrities, as influential as politicians and as revered as Gods, abuse their superpowers rather than use them for good. It's the powerless against the super powerful as The Boys embark on a heroic quest to expose the truth about “The Seven,” and their formidable Vought backing.
 
About Prime Video:
Want to watch it now? We’ve got it. This week’s newest movies, last night’s TV shows, classic favorites, and more are available to stream instantly, plus all your videos are stored in Your Video Library. Prime Video offers a variety of unique and captivating entertainment, including original series “The Boys,” “Invincible,” “Hazbin Hotel,” “The Summer I Turned Pretty,” and more.
 
#TheBoys #Shorts #PrimeVideo

