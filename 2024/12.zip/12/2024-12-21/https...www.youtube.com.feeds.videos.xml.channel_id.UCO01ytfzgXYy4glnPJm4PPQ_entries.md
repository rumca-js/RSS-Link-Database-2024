# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## This must be the stupidest person in Congress
 - [https://www.youtube.com/watch?v=l99BXWJ9COc](https://www.youtube.com/watch?v=l99BXWJ9COc)
 - RSS feed: $source
 - date published: 2024-12-21T21:00:25+00:00

None

## Wives, listen to this before you buy your husband's gift
 - [https://www.youtube.com/watch?v=uPpx1mSAU_k](https://www.youtube.com/watch?v=uPpx1mSAU_k)
 - RSS feed: $source
 - date published: 2024-12-21T18:00:30+00:00

None

## I'm Canceling Christmas Trees
 - [https://www.youtube.com/watch?v=sLB5qxNNk2A](https://www.youtube.com/watch?v=sLB5qxNNk2A)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:44+00:00

ExpressVPN - Go to https://expressvpn.com/walshYT and find out how you can get 3 months of ExpressVPN free!

Matt has a very important message to share with you all today: we are done with Christmas trees.

Become a DailyWire+ member and watch the full show: https://bit.ly/4bEQDy6

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

