# Source:DER SPIEGEL - Schlagzeilen, URL:https://www.spiegel.de/schlagzeilen/index.rss, language:de

## Gaza: Letzte intakte Klinik in Nordgaza fordert internationale Hilfe
 - [https://www.spiegel.de/ausland/gaza-letzte-intakte-klinik-in-nordgaza-fordert-internationale-hilfe-a-47a24ede-8d7d-4af6-992e-461d7043ee01#ref=rss](https://www.spiegel.de/ausland/gaza-letzte-intakte-klinik-in-nordgaza-fordert-internationale-hilfe-a-47a24ede-8d7d-4af6-992e-461d7043ee01#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T23:24:12.481474+00:00

Im umkämpften Norden des Gazastreifens droht offenbar der medizinische Kollaps. Der Direktor des Kamal-Adwan-Krankenhauses drängt auf Hilfslieferungen. Die israelische Armee setzt ihre Angriffe in Gaza derweil fort.

## Blake Lively: Schauspielerin reicht Klage gegen Justin Baldoni wegen Rufschädigung ein
 - [https://www.spiegel.de/panorama/leute/blake-lively-schauspielerin-reicht-klage-gegen-justin-baldoni-wegen-rufschaedigung-ein-a-8857ac61-d658-424b-9f38-e9f6d87e3815#ref=rss](https://www.spiegel.de/panorama/leute/blake-lively-schauspielerin-reicht-klage-gegen-justin-baldoni-wegen-rufschaedigung-ein-a-8857ac61-d658-424b-9f38-e9f6d87e3815#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T23:21:00+00:00

Nach dem Kinostart von »Nur noch ein einziges Mal« brach viel Kritik über Blake Lively herein. Jetzt klagt sie: Ihre Rufschädigung sei systematisch von ihrem Mitschauspieler Justin Baldoni geplant worden.

## Bündnis Sahra Wagenknecht verwirrt in Hamburg mit zwei Verbänden
 - [https://www.spiegel.de/politik/deutschland/buendnis-sahra-wagenknecht-verwirrt-in-hamburg-mit-zwei-verbaenden-a-ef885b10-7c11-4322-af4e-b3f2a5aeff8d#ref=rss](https://www.spiegel.de/politik/deutschland/buendnis-sahra-wagenknecht-verwirrt-in-hamburg-mit-zwei-verbaenden-a-ef885b10-7c11-4322-af4e-b3f2a5aeff8d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T22:20:06.943317+00:00

Das BSW hat mit Hamburg offiziell seinen letzten Landesverband gegründet. Doch in der Hansestadt existiert schon ein Verband – mit einer angeblichen Trans-Muslima als Spitzenkandidatin. Am Ende könnten beide verlieren.

## Papst Franziskus leitet Seligsprechung von Belgiens König Baudouin ein
 - [https://www.spiegel.de/ausland/papst-franziskus-leitet-seligsprechung-von-belgiens-koenig-baudouin-ein-a-1bc38f4b-4420-41c3-ae5d-59467700f3e2#ref=rss](https://www.spiegel.de/ausland/papst-franziskus-leitet-seligsprechung-von-belgiens-koenig-baudouin-ein-a-1bc38f4b-4420-41c3-ae5d-59467700f3e2#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T21:14:57.967809+00:00

Baudouin dankte lieber für einen Tag ab, als eine Legalisierung der Abtreibung mitzutragen. Nun lässt der Papst den verstorbenen König zur Seligsprechung freigeben. Die belgischen Abtreibungsgesetze nannte er zuvor »mörderisch«.

## Amoktat von Magdeburg: Wer versucht, aus dem Grauen Profit zu schlagen, handelt schäbig
 - [https://www.spiegel.de/politik/deutschland/amoktat-von-magdeburg-wer-versucht-aus-dem-grauen-profit-zu-schlagen-handelt-schaebig-a-f69c3154-b582-4dfb-a4fe-40a809fd1393#ref=rss](https://www.spiegel.de/politik/deutschland/amoktat-von-magdeburg-wer-versucht-aus-dem-grauen-profit-zu-schlagen-handelt-schaebig-a-f69c3154-b582-4dfb-a4fe-40a809fd1393#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T21:14:57.714247+00:00

Die erschütternde Tat von Magdeburg wird den Wahlkampf verändern. Extreme Rechte versuchen bereits, sie auszuschlachten. Die Parteien der demokratischen Mitte sind gut beraten, sich zurückzuhalten.

## Premier League: Kai Havertz trifft für FC Arsenal und feiert mit Baby-Jubel
 - [https://www.spiegel.de/sport/fussball/premier-league-kai-havertz-trifft-fuer-fc-arsenal-und-feiert-mit-baby-jubel-a-b5edd946-4712-461f-8414-311390b80bfb#ref=rss](https://www.spiegel.de/sport/fussball/premier-league-kai-havertz-trifft-fuer-fc-arsenal-und-feiert-mit-baby-jubel-a-b5edd946-4712-461f-8414-311390b80bfb#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T21:12:00+00:00

Ende November gab Nationalspieler Kai Havertz bekannt, dass er bald erstmals Vater wird. Im Spiel gegen Crystal Palace trug der Stürmer mit einem Tor zu einem hohen Sieg bei – und sendete einen Gruß an den Nachwuchs.

## Bundesliga: Florian Wirtz und Patrick Schick überragen bei Sieg von Bayer Leverkusen über SC Freiburg
 - [https://www.spiegel.de/sport/fussball/bundesliga-florian-wirtz-und-patrick-schick-ueberragen-bei-sieg-von-bayer-leverkusen-ueber-sc-freiburg-a-2dcbdc39-4f58-48ca-a9e6-24d185774572#ref=rss](https://www.spiegel.de/sport/fussball/bundesliga-florian-wirtz-und-patrick-schick-ueberragen-bei-sieg-von-bayer-leverkusen-ueber-sc-freiburg-a-2dcbdc39-4f58-48ca-a9e6-24d185774572#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T20:10:29.896995+00:00

Erst eins, dann zwei, dann drei, dann vier: Bayer Leverkusens Patrik Schick trifft passend zum Advent. Möglich macht das auch die nächste Gala von Florian Wirtz, dessen Vertragsverlängerung noch auf sich warten lässt.

## Magdeburg - nach Todesfahrt auf Weihnachtsmarkt: Die wirre Welt des Taleb A.
 - [https://www.spiegel.de/panorama/justiz/magdeburg-nach-todesfahrt-auf-weihnachtsmarkt-die-wirre-welt-des-taleb-a-a-4b2fa873-1667-4bc7-b37a-ecf471ba4330#ref=rss](https://www.spiegel.de/panorama/justiz/magdeburg-nach-todesfahrt-auf-weihnachtsmarkt-die-wirre-welt-des-taleb-a-a-4b2fa873-1667-4bc7-b37a-ecf471ba4330#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:06:11.672347+00:00

Er wünschte Angela Merkel den Tod, sympathisierte mit der AfD und Elon Musk und drohte im Netz mit einer Gewalttat. Was trieb Taleb A. vor der Todesfahrt von Magdeburg um?

## Windpark Buckau: »Mit Ignoranz den Bürgern gegenüber« - SPIEGEL TV
 - [https://www.spiegel.de/politik/windpark-buckau-mit-ignoranz-den-buergern-gegenueber-spiegel-tv-a-c57b8a3b-af78-4773-82c9-1f36d8ff3280#ref=rss](https://www.spiegel.de/politik/windpark-buckau-mit-ignoranz-den-buergern-gegenueber-spiegel-tv-a-c57b8a3b-af78-4773-82c9-1f36d8ff3280#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:06:11.561223+00:00

Strom aus Windkraftanlagen ist umweltfreundlich. Wie Behörden einige riesige Anlagen genehmigen, wirkt jedoch höchst fragwürdig. Denn häufig achten sie dabei nicht auf die Sorgen der Menschen – so wie in Buckautal.

## TikTok: Albanien verhängt einjähriges Verbot nach tödlichem Onlinestreit
 - [https://www.spiegel.de/ausland/tiktok-albanien-verhaengt-einjaehriges-verbot-nach-toedlichem-onlinestreit-a-e333c94b-dfaa-4be4-9136-e3e4bc6444eb#ref=rss](https://www.spiegel.de/ausland/tiktok-albanien-verhaengt-einjaehriges-verbot-nach-toedlichem-onlinestreit-a-e333c94b-dfaa-4be4-9136-e3e4bc6444eb#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:06:11.449528+00:00

Bildungsprogramme statt Kurzvideos: Albaniens Regierung will TikTok ab kommendem Jahr komplett abstellen. Zuvor war ein Onlinestreit zwischen zwei Schülern tödlich geendet. Andere Länder ergreifen ähnliche Maßnahmen.

## Bundesliga: Mainz springt auf Platz fünf, Werder Bremen so gut wie seit 13 Jahren nicht mehr
 - [https://www.spiegel.de/sport/fussball/bundesliga-mainz-springt-auf-platz-fuenf-werder-bremen-so-gut-wie-seit-13-jahren-nicht-mehr-a-a60262be-417a-41e7-828d-cf36227b521e#ref=rss](https://www.spiegel.de/sport/fussball/bundesliga-mainz-springt-auf-platz-fuenf-werder-bremen-so-gut-wie-seit-13-jahren-nicht-mehr-a-a60262be-417a-41e7-828d-cf36227b521e#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:06:00+00:00

4:1 Werder, 5:1 Kiel, St. Pauli siegt in Stuttgart: Die Bundesliga-Nordlichter strahlen vor Weihnachten besonders hell. Dazu demontieren zehn Mainzer Eintracht Frankfurt.

## RB Leipzig: Benjamin Henrichs erleidet Achillessehnenriss
 - [https://www.spiegel.de/sport/fussball/rb-leipzig-benjamin-henrichs-erleidet-achillessehnenriss-a-cb55305c-c9cc-44e0-bd03-7076170109e8#ref=rss](https://www.spiegel.de/sport/fussball/rb-leipzig-benjamin-henrichs-erleidet-achillessehnenriss-a-cb55305c-c9cc-44e0-bd03-7076170109e8#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T18:01:52.612139+00:00

Es geschah in der Nachspielzeit: Benjamin Henrichs von RB Leipzig hat sich in München die rechte Achillessehne gerissen und fällt mehrere Monate aus. Sportchef Marcel Schäfer will nun auf dem Transfermarkt reagieren.

## Corendon Airlines: Döner im Flugzeug nach Antalya
 - [https://www.spiegel.de/panorama/corendon-airlines-doener-im-flugzeug-nach-antalya-a-fe7fe3f0-5838-496b-9258-45e23796266a#ref=rss](https://www.spiegel.de/panorama/corendon-airlines-doener-im-flugzeug-nach-antalya-a-fe7fe3f0-5838-496b-9258-45e23796266a#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T18:01:52.348149+00:00

Der Döner verbindet Deutschland und die Türkei – warum also nicht auch an Bord der Ferienflieger nach Antalya? Die türkische Fluggesellschaft Corendon hat ihr Menü um die beliebte Spezialität erweitert.

## Brasilien: Busunglück in Minas Gerais mit 30 Toten
 - [https://www.spiegel.de/panorama/brasilien-busunglueck-in-minas-gerais-mit-30-toten-a-f89b4cbb-27ef-43be-8562-04690b1025b8#ref=rss](https://www.spiegel.de/panorama/brasilien-busunglueck-in-minas-gerais-mit-30-toten-a-f89b4cbb-27ef-43be-8562-04690b1025b8#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T16:56:56.627362+00:00

Im brasilianischen Bundesstaat Minas Gerais ist ein voll besetzter Bus mit einem Lkw zusammengestoßen und ausgebrannt. Die Feuerwehr konnte nur wenige der Insassen retten.

## Weihnachten im Bavarian Village in London: Der Partysänger, der nicht singen kann
 - [https://www.spiegel.de/panorama/weihnachten-im-bavarian-village-in-london-der-partysaenger-der-nicht-singen-kann-a-c50855cd-b508-403f-943c-b28d1d2c1d1a#ref=rss](https://www.spiegel.de/panorama/weihnachten-im-bavarian-village-in-london-der-partysaenger-der-nicht-singen-kann-a-c50855cd-b508-403f-943c-b28d1d2c1d1a#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T16:56:55.861079+00:00

Jeden Abend tritt Joseph im Londoner Bavarian Village auf, schmettert Songs von Rihanna bis Udo Jürgens – und kurbelt den Bierabsatz an. Wie wurde ein 76-jähriger Tscheche zum heimlichen Star der englischen Weihnacht?

## Atomkraft: Frankreich schließt Reaktor Flamanville 3 ans Netz an
 - [https://www.spiegel.de/wissenschaft/technik/atomkraft-frankreich-schliesst-reaktor-flamanville-3-ans-netz-an-a-e54d845c-30d9-4e27-8504-b74757debfab#ref=rss](https://www.spiegel.de/wissenschaft/technik/atomkraft-frankreich-schliesst-reaktor-flamanville-3-ans-netz-an-a-e54d845c-30d9-4e27-8504-b74757debfab#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T16:56:00+00:00

Zum ersten Mal seit 25 Jahren nimmt Frankreich einen neuen Kernreaktor in Betrieb. Das Megaprojekt hat sich um etliche Milliarden Euro verteuert, Strom fließt mit zwölf Jahren Verspätung.

## Stonehenge: Tausende feiern Wintersonnenwende
 - [https://www.spiegel.de/panorama/stonehenge-tausende-feiern-wintersonnenwende-a-62588960-2f81-416b-8a10-e39361b7da98#ref=rss](https://www.spiegel.de/panorama/stonehenge-tausende-feiern-wintersonnenwende-a-62588960-2f81-416b-8a10-e39361b7da98#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:51:49.583013+00:00

Der jahrtausendealte Steinkreis Stonehenge ist eng mit dem Verlauf der Sonne im Jahreszyklus verbunden. Zahlreiche Menschen läuteten dort den kürzesten Tag des Jahres mit Musik und Tanz ein.

## Pkw-Maut: Bauindustrie fordert Pkw-Maut gegen den Verkehrskollaps
 - [https://www.spiegel.de/auto/pkw-maut-bauindustrie-fordert-pkw-maut-gegen-den-verkehrskollaps-a-65e3f100-23c2-4df0-88fa-c1d1d1895aad#ref=rss](https://www.spiegel.de/auto/pkw-maut-bauindustrie-fordert-pkw-maut-gegen-den-verkehrskollaps-a-65e3f100-23c2-4df0-88fa-c1d1d1895aad#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:51:49.469488+00:00

Autobahnen und Straßen lassen sich nur erhalten, wenn Autofahrer mehr zahlen, warnt der Hauptverband der Bauindustrie. Er fordert daher eine Benutzungsgebühr – und trifft umgehend auf Ablehnung.

## Premier League: Manchester City verliert auch bei Aston Villa
 - [https://www.spiegel.de/sport/fussball/premier-league-manchester-city-verliert-auch-bei-aston-villa-a-fabe4f44-27c9-4250-8641-fe9375d7c049#ref=rss](https://www.spiegel.de/sport/fussball/premier-league-manchester-city-verliert-auch-bei-aston-villa-a-fabe4f44-27c9-4250-8641-fe9375d7c049#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:51:49.351562+00:00

Neun Niederlagen in zwölf Spielen: Manchester City setzt seinen Negativtrend fort und unterliegt auch Aston Villa. Der frühere DFB-Kapitän İlkay Gündoğan enttäuschte.

## Magdeburg: Augenzeugen schildern die dramatischen Szenen auf dem Weihnachtsmarkt
 - [https://www.spiegel.de/panorama/magdeburg-augenzeugen-schildern-die-dramatischen-szenen-auf-dem-weihnachtsmarkt-a-8a162a94-1189-4178-a582-1ce407c3a87c#ref=rss](https://www.spiegel.de/panorama/magdeburg-augenzeugen-schildern-die-dramatischen-szenen-auf-dem-weihnachtsmarkt-a-8a162a94-1189-4178-a582-1ce407c3a87c#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:51:49.154156+00:00

Magdeburg am Tag danach. Augenzeugen erinnern sich an den Moment, als hier ein Auto durch die Menschenmenge auf dem Weihnachtsmarkt raste. Olaf Scholz mahnte vor Ort, gegen Hass zusammenzustehen.

## Island: Sozialdemokratin Kristrún Frostadóttir wird neue Ministerpräsidentin von Island
 - [https://www.spiegel.de/ausland/island-sozialdemokratin-kristrun-frostadottir-wird-neue-ministerpraesidentin-von-island-a-7a119016-3a62-44ac-966a-4d745f23e7bc#ref=rss](https://www.spiegel.de/ausland/island-sozialdemokratin-kristrun-frostadottir-wird-neue-ministerpraesidentin-von-island-a-7a119016-3a62-44ac-966a-4d745f23e7bc#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:51:48.895067+00:00

Sie ist Sozialdemokratin, Wahlsiegerin und erst 36 Jahre alt: Mit Kristrún Frostadóttir führt künftig die jüngste Regierungschefin in der Geschichte Islands das Land. Im neuen Kabinett sitzen erstmals mehr Frauen als Männer.

## Magdeburg: Aktueller Stand der Ermittlungen zur Todesfahrt im Livestream
 - [https://www.spiegel.de/panorama/magdeburg-aktueller-stand-der-ermittlungen-zur-todesfahrt-im-livestream-a-b81b1d7d-17e0-484d-b0d6-b3b5eccc9e8c#ref=rss](https://www.spiegel.de/panorama/magdeburg-aktueller-stand-der-ermittlungen-zur-todesfahrt-im-livestream-a-b81b1d7d-17e0-484d-b0d6-b3b5eccc9e8c#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:50:00+00:00

Weniger als 24 Stunden nach dem Anschlag dringen immer mehr Details an die Öffentlichkeit. Sehen Sie hier im Livestream, was Polizei und Staatsanwaltschaft in Magdeburg darüber sagen.

## 2. Bundesliga: Hamburger SV überrumpelt Greuther Fürth, Karlsruher SC übernimmt Tabellenführung
 - [https://www.spiegel.de/sport/fussball/2-bundesliga-hamburger-sv-ueberrollt-greuther-fuerth-karlsruher-sc-uebernimmt-tabellenfuehrung-a-76dfdfaf-d73a-4e52-8286-10a9de548106#ref=rss](https://www.spiegel.de/sport/fussball/2-bundesliga-hamburger-sv-ueberrollt-greuther-fuerth-karlsruher-sc-uebernimmt-tabellenfuehrung-a-76dfdfaf-d73a-4e52-8286-10a9de548106#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:48:00+00:00

Dem Hamburger SV gelingt ein Kantersieg, nun soll über den künftigen Trainer entschieden werden. Effiziente Karlsruher erobern vorerst die Tabellenführung.

## Gelassenheit: Wie werden wir geduldiger? - Best of »Smarter leben«-Podcast mit Leon Windscheid
 - [https://www.spiegel.de/familie/gelassenheit-wie-werden-wir-geduldiger-best-of-smarter-leben-podcast-mit-leon-windscheid-a-655bf60c-b3f6-4bce-81e6-6cb2f2cdb5b8#ref=rss](https://www.spiegel.de/familie/gelassenheit-wie-werden-wir-geduldiger-best-of-smarter-leben-podcast-mit-leon-windscheid-a-655bf60c-b3f6-4bce-81e6-6cb2f2cdb5b8#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:47:00+00:00

Verzögerungen nerven, Warten macht uns wahnsinnig. Psychologe Leon Windscheid erklärt, wie wir geduldiger werden. Mit anderen, uns selbst und in Krisen. Eine der meistgehörten Podcast-Episoden des Jahres.

## Games: Die 10 besten Indie-Spiele des Jahres 2024
 - [https://www.spiegel.de/netzwelt/games/games-die-10-besten-indie-spiele-des-jahres-2024-a-fbc6deb9-e504-45ba-8551-16ff119206c6#ref=rss](https://www.spiegel.de/netzwelt/games/games-die-10-besten-indie-spiele-des-jahres-2024-a-fbc6deb9-e504-45ba-8551-16ff119206c6#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:46:00+00:00

Unerklärliche Phänomene, griechische Sagen oder kreativ erweiterte Pokerregeln: Unabhängige Entwicklerstudios haben 2024 einige besondere Videospiele veröffentlicht. Dies sind unsere Top 10.

## Zemmi Fahrrad-Sattelzug im Test: Truck mit Tretantrieb
 - [https://www.spiegel.de/auto/zemmi-fahrrad-sattelzug-im-test-truck-mit-tretantrieb-a-c432b9c8-6420-4764-a719-913dff99eade#ref=rss](https://www.spiegel.de/auto/zemmi-fahrrad-sattelzug-im-test-truck-mit-tretantrieb-a-c432b9c8-6420-4764-a719-913dff99eade#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:46:00+00:00

Im Lichterglanz vor Weihnachten blinken Paketlieferwagen allgegenwärtig mit. Ein neuer XXL-Lastenrad-Sattelzug könnte für mehr Platz auf den Straßen sorgen. Unterwegs mit dem Zemmi.

## Luxusuhren von MB&F: Das Haus, in dem die verrücktesten Uhren der Welt gebaut werden
 - [https://www.spiegel.de/wirtschaft/unternehmen/luxusuhren-von-mb-f-das-haus-in-dem-die-verruecktesten-uhren-der-welt-gebaut-werden-a-a2b40f2e-93cb-4c44-ba15-fe1f30bbeb3e#ref=rss](https://www.spiegel.de/wirtschaft/unternehmen/luxusuhren-von-mb-f-das-haus-in-dem-die-verruecktesten-uhren-der-welt-gebaut-werden-a-a2b40f2e-93cb-4c44-ba15-fe1f30bbeb3e#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:45:00+00:00

Niemand produziert so extravagante Armbanduhren wie MB&F. Pro Tag stellt die kleine Schweizer Firma nur ein bis zwei Stück fertig, sie kosten oft sechsstellige Summen. Ist das noch ein Geschäft oder schon Kunst?

## Online-Shopping vor Weihnachten: Warum ist im Paket so viel Luft und so wenig Inhalt?
 - [https://www.spiegel.de/panorama/online-shopping-vor-weihnachten-warum-ist-im-paket-so-viel-luft-und-so-wenig-inhalt-a-f073890d-500d-4b11-8ae8-96864ddbdab5#ref=rss](https://www.spiegel.de/panorama/online-shopping-vor-weihnachten-warum-ist-im-paket-so-viel-luft-und-so-wenig-inhalt-a-f073890d-500d-4b11-8ae8-96864ddbdab5#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:43:00+00:00

Sie kennen das: Man bestellt ein kleines Geschenk im Internet und bekommt einen riesigen Karton. Logistikexperte Lukas Lehmann erklärt, was dahintersteckt – und warum immer noch Menschen statt Maschinen Ihre Pakete packen.

## Immo Tommy: Der gefährliche Vertrauensbonus für gehypte Influencer
 - [https://www.spiegel.de/wirtschaft/immo-tommy-der-gefaehrliche-vertrauensbonus-fuer-gehypte-influencer-a-20b57061-db51-4ba6-a872-c2b4dad65a61#ref=rss](https://www.spiegel.de/wirtschaft/immo-tommy-der-gefaehrliche-vertrauensbonus-fuer-gehypte-influencer-a-20b57061-db51-4ba6-a872-c2b4dad65a61#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:42:00+00:00

Bei den Recherchen über die Geschäfte des Immobilien-Influencers Immo Tommy trafen wir verzweifelte Kunden. Ihr gemeinsames Problem: Sie vertrauten blind, weil der Hype so groß war. Aus ihren Fehlern kann man lernen.

## Tischtennis: Annett Kaufmann distanziert sich von Vergleichen mit Timo Boll
 - [https://www.spiegel.de/sport/olympia/tischtennis-annett-kaufmann-distanziert-sich-von-vergleichen-mit-timo-boll-a-77d18737-9adb-46dd-bc2b-b901e178b428#ref=rss](https://www.spiegel.de/sport/olympia/tischtennis-annett-kaufmann-distanziert-sich-von-vergleichen-mit-timo-boll-a-77d18737-9adb-46dd-bc2b-b901e178b428#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:39.838280+00:00

Sie ist die große Hoffnung im Tischtennis und möchte die deutschen Spielerinnen bekannter machen. Von Vergleichen mit Superstar Timo Boll distanziert sich Annett Kaufmann aber.

## Alberne Partypiele: Miezekatze, Ich habe fertig, Beat that, Mafia Minze Molch, Flieg, Schweinchen, flieg
 - [https://www.spiegel.de/tests/brettspiele/alberne-partypiele-miezekatze-ich-habe-fertig-beat-that-mafia-minze-molch-flieg-schweinchen-flieg-a-315de7a2-36c5-4eec-a734-95e998aa3e74#ref=rss](https://www.spiegel.de/tests/brettspiele/alberne-partypiele-miezekatze-ich-habe-fertig-beat-that-mafia-minze-molch-flieg-schweinchen-flieg-a-315de7a2-36c5-4eec-a734-95e998aa3e74#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:39.662421+00:00

Manche Party lässt sich mit einem Spiel deutlich aufpeppen. Zur Ausstattung können fliegende Schweine, Gummischwerter oder Plüschmäuse gehören. Wir haben die besten getestet.

## Deutscher Wetterdienst warnt vor heftigem Sturm im Harz
 - [https://www.spiegel.de/panorama/deutscher-wetterdienst-warnt-vor-heftigem-sturm-im-harz-a-02341384-7108-4343-b268-f9e0a4da7ad4#ref=rss](https://www.spiegel.de/panorama/deutscher-wetterdienst-warnt-vor-heftigem-sturm-im-harz-a-02341384-7108-4343-b268-f9e0a4da7ad4#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:39.481333+00:00

Bis zu 110 Kilometer pro Stunde sollen Sturm- und Orkanböen am Wochenende vor allem in Sachsen-Anhalt erreichen. Der Deutsche Wetterdienst rät, unnötige Autofahrten und den Aufenthalt im Freien zu vermeiden.

## Kampf um die sorbische Kultur: Junge Sorben zwischen Trachten und Techno
 - [https://www.spiegel.de/start/kampf-um-die-sorbische-kultur-junge-sorben-zwischen-trachten-und-techno-a-905273b1-90c5-4c57-8551-4800e29ba3f4#ref=rss](https://www.spiegel.de/start/kampf-um-die-sorbische-kultur-junge-sorben-zwischen-trachten-und-techno-a-905273b1-90c5-4c57-8551-4800e29ba3f4#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:39.307027+00:00

Die Lausitzer Sorben kämpfen darum, ihre gefährdete Kultur zu erhalten. Dafür gibt es viele Ansätze, gerade unter jungen Menschen. Dabei sind sie sich nicht immer einig.

## Österreich: Täuschte ein Betrüger Heinz-Christian Strache?
 - [https://www.spiegel.de/ausland/oesterreich-taeuschte-ein-betrueger-heinz-christian-strache-a-abe6f411-f9fd-4f1b-982e-01d82c482d84#ref=rss](https://www.spiegel.de/ausland/oesterreich-taeuschte-ein-betrueger-heinz-christian-strache-a-abe6f411-f9fd-4f1b-982e-01d82c482d84#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:39.140464+00:00

Mehrere Unternehmer in Österreich erheben schwere Vorwürfe gegen einen Investor: Er soll sie mit nicht erfüllten Verträgen in Millionenhöhe betrogen haben. Unter den mutmaßlich Geschädigten ist auch ein Ex-Vizekanzler.

## »Die Saat des heiligen Feigenbaums« von Mohammad Rasoulof: Showdown im Widerstand
 - [https://www.spiegel.de/kultur/kino/die-saat-des-heiligen-feigenbaums-von-mohammad-rasoulof-showdown-im-widerstand-a-7b4a9a1b-c1fa-4e3e-9126-e8b63092cc62#ref=rss](https://www.spiegel.de/kultur/kino/die-saat-des-heiligen-feigenbaums-von-mohammad-rasoulof-showdown-im-widerstand-a-7b4a9a1b-c1fa-4e3e-9126-e8b63092cc62#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:38.984435+00:00

Seinen Film konnte Mohammad Rasoulof in Iran nur heimlich drehen, dann floh er nach Deutschland. Nun kommt »Die Saat des heiligen Feigenbaums« in die Kinos. Es ist ein furioser Politthriller entlang einer furchtbaren Realität.

## Künstliche Intelligenz: Folgt auf den KI-Hype nun ein KI-Herbst?
 - [https://www.spiegel.de/netzwelt/web/kuenstliche-intelligenz-folgt-auf-den-ki-hype-nun-ein-ki-herbst-a-08877d13-66a7-44d3-a0f3-0d9d1c5096f7#ref=rss](https://www.spiegel.de/netzwelt/web/kuenstliche-intelligenz-folgt-auf-den-ki-hype-nun-ein-ki-herbst-a-08877d13-66a7-44d3-a0f3-0d9d1c5096f7#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:38.720643+00:00

Zwei Nobelpreise gingen 2024 an Vorreiter der modernen KI. Beginnt nun endgültig das neue Zeitalter – oder ist das schon der vorläufige Höhepunkt? Einige Signale aus Branche und Forschung sind eher ernüchternd.

## Ukraine: Mit diesem Nachtzug fährt der Staatsbesuch aus dem Westen nach Kyjiw
 - [https://www.spiegel.de/auto/ukraine-mit-diesem-nachtzug-faehrt-der-staatsbesuch-aus-dem-westen-nach-kyjiw-a-48a5ec43-0405-4f35-9671-c86e907f6716#ref=rss](https://www.spiegel.de/auto/ukraine-mit-diesem-nachtzug-faehrt-der-staatsbesuch-aus-dem-westen-nach-kyjiw-a-48a5ec43-0405-4f35-9671-c86e907f6716#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:38.431778+00:00

Im Krieg lässt sich die Ukraine nicht per Flugzeug erreichen. Auch Staatsoberhäupter aus aller Welt nehmen daher den Zug. Sie fahren in Waggons mit besonderem Komfort. Wie es darin aussieht, zeigen diese Bilder.

## Magdeburg: Attentäter vom Weihnachtsmarkt wurde bereits 2013 verurteilt
 - [https://www.spiegel.de/panorama/magdeburg-attentaeter-vom-weihnachtsmarkt-wurde-bereits-2013-verurteilt-a-57963a33-3325-422a-8fd5-3cfc5248a00d#ref=rss](https://www.spiegel.de/panorama/magdeburg-attentaeter-vom-weihnachtsmarkt-wurde-bereits-2013-verurteilt-a-57963a33-3325-422a-8fd5-3cfc5248a00d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:38.158382+00:00

Nach SPIEGEL-Informationen wurde der mutmaßliche Attentäter von Magdeburg bereits 2013 wegen der Androhung von Straftaten verurteilt. Seinen Asylantrag stellte er dagegen erst 2016 – unter Verweis auf einen Vorfall in der saudischen Botschaft.

## Argentinien: Javier Milei setzt auf Atomkraft für künstliche Intelligenz
 - [https://www.spiegel.de/wirtschaft/argentinien-javier-milei-setzt-auf-atomkraft-fuer-kuenstliche-intelligenz-a-d534f13c-6a25-46c2-93b8-219dcf49a53b#ref=rss](https://www.spiegel.de/wirtschaft/argentinien-javier-milei-setzt-auf-atomkraft-fuer-kuenstliche-intelligenz-a-d534f13c-6a25-46c2-93b8-219dcf49a53b#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:44:00+00:00

Seit zehn Jahren baut Argentinien an einem kleinen modularen Atomreaktor, jetzt sieht der rechtslibertäre Präsident Javier Milei darin ein Fanal für die Zukunft: Künstliche Intelligenz mache die Technik notwendig.

## Weihnachten mit vier Generationen: Warum die ganze Familie meine Oma liebt
 - [https://www.spiegel.de/familie/weihnachten-mit-vier-generationen-warum-die-ganze-familie-meine-oma-liebt-a-584951d5-70ed-41e1-b162-4c816ef4d261#ref=rss](https://www.spiegel.de/familie/weihnachten-mit-vier-generationen-warum-die-ganze-familie-meine-oma-liebt-a-584951d5-70ed-41e1-b162-4c816ef4d261#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:41:30.808150+00:00

Gemeinsam mit Kindern, Eltern und Großeltern Weihnachten zu feiern, kann sehr erfüllend sein. Wie aber gelingt ein stressfreies Fest? Was sind gute Geschenke? Hier kommen nach Tannenzweigen duftende Tipps.

## Darts-WM: Ed Sheeran ext Bier – und reagiert auf Spott mit Mittelfinger
 - [https://www.spiegel.de/sport/darts-wm-ed-sheeran-ext-bier-und-reagiert-auf-spott-mit-mittelfinger-a-452f4c38-ead5-4bef-83b1-9c8a9f961791#ref=rss](https://www.spiegel.de/sport/darts-wm-ed-sheeran-ext-bier-und-reagiert-auf-spott-mit-mittelfinger-a-452f4c38-ead5-4bef-83b1-9c8a9f961791#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:41:30.700797+00:00

Sänger Ed Sheeran hat sich in London ein Darts-Match angeschaut. Auf Videos ist zu sehen, wie er ein Bier auf ex trinkt – und den Fans nach einem Schmähgesang ironisch den Mittelfinger zeigt.

## Gaza-Siedlungspläne in Israel beunruhigen Robert Habeck
 - [https://www.spiegel.de/ausland/gaza-siedlungsplaene-in-israel-sorgen-robert-habeck-a-cc0b25d5-9b97-45ca-b894-c3ea5cf8da58#ref=rss](https://www.spiegel.de/ausland/gaza-siedlungsplaene-in-israel-sorgen-robert-habeck-a-cc0b25d5-9b97-45ca-b894-c3ea5cf8da58#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:41:30.593754+00:00

»Unterschied zwischen der Bekämpfung von Terrorismus und der Besiedlung Gazas«: Der grüne Kanzlerkandidat Robert Habeck kritisiert die Pläne ultrarechter Israelis, die von einer Wiederbesiedlung der Palästinenserenklave träumen.

## Papst Franziskus prangert israelische »Grausamkeit« in Gaza an
 - [https://www.spiegel.de/ausland/papst-franziskus-prangert-israelische-grausamkeit-in-gaza-an-a-f50fcd32-0821-4dab-b8f2-96dc3e0415c2#ref=rss](https://www.spiegel.de/ausland/papst-franziskus-prangert-israelische-grausamkeit-in-gaza-an-a-f50fcd32-0821-4dab-b8f2-96dc3e0415c2#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:41:30.486272+00:00

Israel hat den Lateinischen Patriarch von Jerusalem nicht nach Gaza einreisen lassen. Nun reagiert der Pontifex – und greift die Netanyahu-Regierung an. Derweil gibt Schweden bekannt, die Palästinenser nicht mehr über die UNRWA zu unterstützen.

## Todesfahrt von Magdeburg: »Zehn Minuten, nachdem wir los sind, hat es geknallt«
 - [https://www.spiegel.de/panorama/zehn-minuten-nachdem-wir-los-sind-hat-es-geknallt-a-e191c022-f59f-4ae8-9ee4-a0a36eea46f0#ref=rss](https://www.spiegel.de/panorama/zehn-minuten-nachdem-wir-los-sind-hat-es-geknallt-a-e191c022-f59f-4ae8-9ee4-a0a36eea46f0#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:41:30.378931+00:00

Nach dem Anschlag auf den Weihnachtsmarkt trauert Magdeburg. Einige erzählen, sie seien dem Angreifer womöglich nur knapp entgangen. Szenen aus einer Stadt unter Schock.

## US-Arzneimittelbehörde FDA lässt Medikament Zepbound zur Behandlung bei Schlafapnoe zu
 - [https://www.spiegel.de/wissenschaft/us-arzneimittelbehoerde-fda-laesst-medikament-zepbound-zur-behandlung-bei-schlafapnoe-zu-a-fedf4f06-7829-4f73-9626-00a0a79a1859#ref=rss](https://www.spiegel.de/wissenschaft/us-arzneimittelbehoerde-fda-laesst-medikament-zepbound-zur-behandlung-bei-schlafapnoe-zu-a-fedf4f06-7829-4f73-9626-00a0a79a1859#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:41:30.268916+00:00

Menschen, deren Atmung im Schlaf aussetzt, müssen zur Behandlung bisher eine lästige Nasenmaske tragen. Nun lassen die USA ein Medikament dagegen zu. Übergewichtige Menschen nutzen es bereits zum Abnehmen.

## Lindsey Vonn: Skifahrerin rast bei Comeback auf Platz 14
 - [https://www.spiegel.de/sport/wintersport/lindsey-vonn-skifahrerin-rast-bei-comeback-auf-platz-14-a-9bdd5661-328e-453f-9b5f-32b85836c173#ref=rss](https://www.spiegel.de/sport/wintersport/lindsey-vonn-skifahrerin-rast-bei-comeback-auf-platz-14-a-9bdd5661-328e-453f-9b5f-32b85836c173#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:39:00+00:00

Fast sechs Jahre kein Rennen, ein neues Knie und trotzdem rast Lindsey Vonn direkt wieder in die Weltspitze. Platz 14 ist keine gute Nachricht für ihre Konkurrenz.

## Weihnachten und Hannah Arendt: Die Bedeutung der frohen Botschaft für unsere Zeit
 - [https://www.spiegel.de/politik/weihnachten-und-hannah-arendt-die-bedeutung-der-frohen-botschaft-fuer-unsere-zeit-a-5564d05a-6428-4bcd-be1e-8d520442b833#ref=rss](https://www.spiegel.de/politik/weihnachten-und-hannah-arendt-die-bedeutung-der-frohen-botschaft-fuer-unsere-zeit-a-5564d05a-6428-4bcd-be1e-8d520442b833#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:36:31.643554+00:00

Die große Denkerin Hannah Arendt schrieb einst, dass man für die Welt noch hoffen dürfe. Was hat die frohe Botschaft heute noch mit uns zu tun? Taugt das Christkind noch als Symbol?

## Magdeburg: So lief die Todesfahrt auf dem Weihnachtsmarkt
 - [https://www.spiegel.de/panorama/magdeburg-so-lief-die-todesfahrt-auf-dem-weihnachtsmarkt-a-024c32c6-1d95-4220-b5fd-a2bb4e08fd58#ref=rss](https://www.spiegel.de/panorama/magdeburg-so-lief-die-todesfahrt-auf-dem-weihnachtsmarkt-a-024c32c6-1d95-4220-b5fd-a2bb4e08fd58#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:36:31.526082+00:00

Mit einem Auto ist Taleb A. über den Magdeburger Weihnachtsmarkt gerast, mehrere Hunderte Meter weit. Mithilfe von Zeugenaussagen und Videos hat der SPIEGEL den Ablauf der Tat rekonstruiert.

## Bad Birnbach: Autonome Busse stellen Betrieb ein
 - [https://www.spiegel.de/auto/bad-birnbach-autonome-busse-stellen-betrieb-ein-a-9902ebde-bb1a-4646-b013-0c005ecb7013#ref=rss](https://www.spiegel.de/auto/bad-birnbach-autonome-busse-stellen-betrieb-ein-a-9902ebde-bb1a-4646-b013-0c005ecb7013#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:36:31.408343+00:00

Wo die Ära der selbstfahrenden Busse in Deutschland begann, ist bald schon wieder Schluss: Der niederbayerische Kurort Bad Birnbach verliert den Fahrzeuglieferanten für sein innovatives Nahverkehrsprojekt.

## Magdeburg: Bundeskanzler Olaf Scholz bezeichnet Anschlag als »wahnsinnige Tat«
 - [https://www.spiegel.de/politik/deutschland/magdeburg-bundeskanzler-olaf-scholz-bezeichnet-anschlag-als-wahnsinnige-tat-a-a294ba2c-3b8e-49e2-8bb1-49412f2ebf70#ref=rss](https://www.spiegel.de/politik/deutschland/magdeburg-bundeskanzler-olaf-scholz-bezeichnet-anschlag-als-wahnsinnige-tat-a-a294ba2c-3b8e-49e2-8bb1-49412f2ebf70#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:36:31.281707+00:00

Nach dem Attentat auf den Magdeburger Weihnachtsmarkt hat Bundeskanzler Olaf Scholz vor Ort der Opfer gedacht und Untersuchungen angekündigt. Gleichzeitig appellierte er an die Geschlossenheit in Deutschland.

## Russland-Ukraine-Krieg: Moskau meldet Drohnenangriff auf Kasan im Landesinneren
 - [https://www.spiegel.de/ausland/russland-ukraine-krieg-moskau-meldet-drohnenangriff-auf-kasan-im-landesinneren-a-5997a3b9-2bee-40b8-ba5f-6b5d0aad3f4b#ref=rss](https://www.spiegel.de/ausland/russland-ukraine-krieg-moskau-meldet-drohnenangriff-auf-kasan-im-landesinneren-a-5997a3b9-2bee-40b8-ba5f-6b5d0aad3f4b#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:31:20.305670+00:00

Mehrere ukrainische Drohnen sollen laut Berichten aus Moskau die Stadt Kasan angegriffen haben, tief im Landesinneren Russlands. Auch Wohnhäuser seien getroffen worden.

## Landkreis Ravensburg: Drei Auffahrunfälle auf 100 Metern auf der A 96
 - [https://www.spiegel.de/panorama/landkreis-ravensburg-drei-auffahrunfaelle-auf-100-metern-auf-der-a-96-a-809a11c0-0a24-411a-abca-087a5c80b0a1#ref=rss](https://www.spiegel.de/panorama/landkreis-ravensburg-drei-auffahrunfaelle-auf-100-metern-auf-der-a-96-a-809a11c0-0a24-411a-abca-087a5c80b0a1#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:31:20.191234+00:00

Am Freitagnachmittag herrschte dichter Verkehr auf der Autobahn 96 bei Leutkirch im Allgäu, die Folge waren Blechschäden: Auf kurzer Strecke fuhren gleich drei Autofahrer ihrem Vordermann auf.

## Fußball: FC Bayern schließt turbulentes Jahr gegen RB Leipzig erfolgreich ab
 - [https://www.spiegel.de/sport/fussball/fussball-fc-bayern-schliesst-turbulentes-jahr-gegen-rb-leipzig-erfolgreich-ab-a-68ed14f8-055d-429d-91d8-945d1cacaebc#ref=rss](https://www.spiegel.de/sport/fussball/fussball-fc-bayern-schliesst-turbulentes-jahr-gegen-rb-leipzig-erfolgreich-ab-a-68ed14f8-055d-429d-91d8-945d1cacaebc#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:31:20.071362+00:00

Nach dem Sieg über Leipzig gedenken die Spieler des FC Bayern der Opfer von Magdeburg. Es war ein Jahresausklang im Moll – dabei hätte der Verein Grund zum Feiern: Ein titelloses Kalenderjahr hat er versöhnlich zu Ende gebracht.

## Silvester: »Je knapper die Kassen sind, desto mehr Feuerwerk wird gekauft«
 - [https://www.spiegel.de/wirtschaft/service/silvester-je-knapper-die-kassen-sind-desto-mehr-feuerwerk-wird-gekauft-a-981656b6-930a-4e40-9622-bc804af629ae#ref=rss](https://www.spiegel.de/wirtschaft/service/silvester-je-knapper-die-kassen-sind-desto-mehr-feuerwerk-wird-gekauft-a-981656b6-930a-4e40-9622-bc804af629ae#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:35:00+00:00

In Erwartung einer gestiegenen Nachfrage deckt sich der Handel mit Feuerwerkskörpern ein. Böllerfreunde müssen sich aber auf höhere Preise gefasst machen.

## Saudi-Arabien verurteilt Todesfahrt auf Weihnachtsmarkt in Magdeburg
 - [https://www.spiegel.de/politik/saudi-arabien-verurteilt-todesfahrt-auf-weihnachtsmarkt-in-magdeburg-a-3bd65ea8-692e-4f78-a981-10e448b35a90#ref=rss](https://www.spiegel.de/politik/saudi-arabien-verurteilt-todesfahrt-auf-weihnachtsmarkt-in-magdeburg-a-3bd65ea8-692e-4f78-a981-10e448b35a90#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:26:19.018339+00:00

Nach ersten Erkenntnissen stammt der mutmaßliche Todesfahrer in Magdeburg aus Saudi-Arabien. Die Monarchie hat den Anschlag in einer Stellungnahme nun verurteilt.

## Vorbereitung auf Silvester: »Umso knapper die Kassen sind, desto mehr Feuerwerk wird gekauft«
 - [https://www.spiegel.de/wirtschaft/service/vorbereitung-auf-silvester-umso-knapper-die-kassen-sind-desto-mehr-feuerwerk-wird-gekauft-a-981656b6-930a-4e40-9622-bc804af629ae#ref=rss](https://www.spiegel.de/wirtschaft/service/vorbereitung-auf-silvester-umso-knapper-die-kassen-sind-desto-mehr-feuerwerk-wird-gekauft-a-981656b6-930a-4e40-9622-bc804af629ae#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:26:18.905697+00:00

In Erwartung einer gestiegenen Nachfrage deckt sich der Handel mit Feuerwerkskörpern ein. Böllerfreunde müssen sich aber auf höhere Preise gefasst machen.

## Party an Weihnachten und Silvester: »Ein guter Abend ist kein Zufall«
 - [https://www.spiegel.de/stil/party-an-weihnachten-und-silvester-ein-guter-abend-ist-kein-zufall-a-752ce124-6782-4f88-8b7b-40f846fe00b9#ref=rss](https://www.spiegel.de/stil/party-an-weihnachten-und-silvester-ein-guter-abend-ist-kein-zufall-a-752ce124-6782-4f88-8b7b-40f846fe00b9#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:26:18.793464+00:00

Wie werde ich zum perfekten Gastgeber? Charme ist wichtiger als Schampus und ein Dresscode unverzichtbar, sagen drei Eventprofis und verraten, wie sie ihre Gäste glücklich nach Hause schicken.

## Magdeburg News: Olaf Scholz im Livestream - Reaktion des Bundeskanzlers auf die Todesfahrt
 - [https://www.spiegel.de/panorama/magdeburg-news-olaf-scholz-im-livestream-reaktion-des-bundeskanzlers-auf-die-todesfahrt-a-2cfdedb5-dd30-4f2c-807f-1879fa11a246#ref=rss](https://www.spiegel.de/panorama/magdeburg-news-olaf-scholz-im-livestream-reaktion-des-bundeskanzlers-auf-die-todesfahrt-a-2cfdedb5-dd30-4f2c-807f-1879fa11a246#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:26:18.680724+00:00

Am Tag nach der Todesfahrt auf dem Weihnachtsmarkt in Magdeburg ist der Bundeskanzler vor Ort eingetroffen. In wenigen Minuten will der Kanzler vor die Presse treten. Sehen Sie hier das Statement von Olaf Scholz im Livestream.

## Iran, Afghanistan, Tadschikistan: Millionen feiern persische Jalda-Nacht
 - [https://www.spiegel.de/ausland/iran-afghanistan-tadschikistan-millionen-feiern-persische-jalda-nacht-a-147010d6-c48e-4f24-83b3-81b4c5adb276#ref=rss](https://www.spiegel.de/ausland/iran-afghanistan-tadschikistan-millionen-feiern-persische-jalda-nacht-a-147010d6-c48e-4f24-83b3-81b4c5adb276#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:26:18.562988+00:00

In der Nacht zum 21. Dezember, der längsten des Jahres, haben Menschen in Iran, in Afghanistan und Tadschikistan die persische Wintersonnenwende gefeiert. Das Fest steht für den Sieg des Lichts über die Dunkelheit.

## Syrien unter Baschar al-Assad: »Es war ein Mob. Eine Regierungsmafia«
 - [https://www.spiegel.de/ausland/syrien-unter-baschar-al-assad-es-war-ein-mob-eine-regierungsmafia-a-91565e8c-0161-44a4-9633-4291d9ab8154#ref=rss](https://www.spiegel.de/ausland/syrien-unter-baschar-al-assad-es-war-ein-mob-eine-regierungsmafia-a-91565e8c-0161-44a4-9633-4291d9ab8154#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:24:00+00:00

Die Assad-Familie und ihre Günstlinge haben die Wirtschaft kontrolliert und sich schamlos bereichert. Unternehmer berichten von horrenden Gebühren und Erpressungen. Sie hoffen, dass nun die Sanktionen aufgehoben werden.

## Russland: Tschetschenenführer Ramsan Kadyrow hat seinen militärischen und wirtschaftlichen Einfluss vergrößert
 - [https://www.spiegel.de/ausland/russland-tschetschenenfuehrer-ramsan-kadyrow-hat-seinen-militaerischen-und-wirtschaftlichen-einfluss-vergroessert-a-e92d7c7e-8be1-400d-9e37-ba87085700bd#ref=rss](https://www.spiegel.de/ausland/russland-tschetschenenfuehrer-ramsan-kadyrow-hat-seinen-militaerischen-und-wirtschaftlichen-einfluss-vergroessert-a-e92d7c7e-8be1-400d-9e37-ba87085700bd#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:21:07.970193+00:00

Wladimir Putin muss seine strategische Position in Syrien retten. Für den Dialog mit den neuen islamistischen Machthabern dort hat er ausgerechnet den tschetschenischen Diktator Ramsan Kadyrow abgestellt.

## »Last Christmas«: George Michael schafft es posthum auf Platz eins der Weihnachts-Charts
 - [https://www.spiegel.de/kultur/last-christmas-george-michael-schafft-es-posthum-auf-platz-eins-der-weihnachts-charts-a-f4b51ef1-0654-4d0d-9ebb-7b57aa099af8#ref=rss](https://www.spiegel.de/kultur/last-christmas-george-michael-schafft-es-posthum-auf-platz-eins-der-weihnachts-charts-a-f4b51ef1-0654-4d0d-9ebb-7b57aa099af8#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:21:07.806379+00:00

Last Christmas hat es »Last Christmas« zum ersten Mal an Weihnachten an die Spitze der britischen Charts geschafft. Und dieses Jahr schon wieder – damit hat der Wham!-Song etwas hinbekommen, was noch keinem Lied zuvor gelang.

## Holger Friedrich und »Berliner Zeitung«: Was seit dem SPIEGEL-Bericht geschah
 - [https://www.spiegel.de/kultur/holger-friedrich-und-berliner-zeitung-was-seit-dem-spiegel-bericht-geschah-a-8d05003c-d2fe-455e-baa1-2d115f41545f#ref=rss](https://www.spiegel.de/kultur/holger-friedrich-und-berliner-zeitung-was-seit-dem-spiegel-bericht-geschah-a-8d05003c-d2fe-455e-baa1-2d115f41545f#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:21:07.660834+00:00

Im September berichtete der SPIEGEL über den seltsamen Kurs der »Berliner Zeitung«. Seither arbeiten sich das Blatt und sein Verleger am SPIEGEL ab – auf durchaus kuriose Weise.

## Gute Nachrichten: Wie Überlebende des Tsunamis von 2004 Trost fanden - Alles Gute vom SPIEGEL
 - [https://www.spiegel.de/ausland/gute-nachrichten-wie-ueberlebende-des-tsunamis-von-2004-trost-fanden-alles-gute-vom-spiegel-a-10e63c9c-ce3a-4ab3-a1aa-31a6e0733e5d#ref=rss](https://www.spiegel.de/ausland/gute-nachrichten-wie-ueberlebende-des-tsunamis-von-2004-trost-fanden-alles-gute-vom-spiegel-a-10e63c9c-ce3a-4ab3-a1aa-31a6e0733e5d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:17:27.884041+00:00

Zwei Menschen zeigen, was Resilienz ausmacht. Das Bundesverfassungsgericht soll geschützt werden. Und: Wie Sie Ihre Erkältung noch bis Weihnachten loswerden. Der SPIEGEL-Newsletter mit ausschließlich guten Nachrichten.

## Viele Tafeln in Deutschland führen Wartelisten
 - [https://www.spiegel.de/panorama/viele-tafeln-in-deutschland-fuehren-wartelisten-a-94a79c1b-23f3-448c-94de-5b93a054fd90#ref=rss](https://www.spiegel.de/panorama/viele-tafeln-in-deutschland-fuehren-wartelisten-a-94a79c1b-23f3-448c-94de-5b93a054fd90#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:17:27.679397+00:00

Hohe Lebensmittelpreise, hohe Mieten: Die Tafeln sind im »anhaltenden Dauerkrisenmodus«. Laut dem Dachverband der Tafeln ist der Andrang an vielen Ausgabestellen größer als es deren Kapazitäten sind.

## Mercedes-Benz streicht Gehaltserhöhungen für Führungskräfte
 - [https://www.spiegel.de/wirtschaft/unternehmen/mercedes-benz-streicht-gehaltserhoehungen-fuer-fuehrungskraefte-a-acd1abef-8b78-4517-a0dc-8af6d42d6ade#ref=rss](https://www.spiegel.de/wirtschaft/unternehmen/mercedes-benz-streicht-gehaltserhoehungen-fuer-fuehrungskraefte-a-acd1abef-8b78-4517-a0dc-8af6d42d6ade#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:17:27.538634+00:00

Bevor es um einen möglichen Personalabbau geht, spart Mercedes-Benz am Führungspersonal. Zudem müssen die Manager auf das Homeoffice verzichten.

## Magdeburg: Die Pressestimmen zur Todesfahrt
 - [https://www.spiegel.de/panorama/justiz/magdeburg-die-pressestimmen-zur-todesfahrt-a-82e7b706-b960-4ce9-80dd-0b2249df8b91#ref=rss](https://www.spiegel.de/panorama/justiz/magdeburg-die-pressestimmen-zur-todesfahrt-a-82e7b706-b960-4ce9-80dd-0b2249df8b91#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:17:27.386386+00:00

»Mitten ins Herz getroffen«: Deutsche und internationale Medien blicken entsetzt auf die Todesfahrt von Magdeburg – und befürchten nun einen aufgewühlten Bundestagswahlkampf.

## Was auf dem Weihnachtsmarkt passiert ist
 - [https://www.spiegel.de/panorama/was-auf-dem-weihnachtsmarkt-passierte-a-2ea4e810-dbb9-44cb-805d-efa1a22e9e12#ref=rss](https://www.spiegel.de/panorama/was-auf-dem-weihnachtsmarkt-passierte-a-2ea4e810-dbb9-44cb-805d-efa1a22e9e12#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:17:27.161953+00:00

Zwei Tote, viele Verletzte: Amateurvideos vom Weihnachtsmarkt zeigen die Augenblicke nach der Tat und die Festnahme des mutmaßlichen Täters. Dessen Motiv bleibt unklar, die Politik ist entsetzt.

## USA versus China: Joe Biden genehmigt Militärhilfen für Taiwan
 - [https://www.spiegel.de/ausland/usa-versus-china-joe-biden-genehmigt-militaerhilfen-fuer-taiwan-a-2fe4d3ba-746a-4f4e-a73c-a21b22dbfb2d#ref=rss](https://www.spiegel.de/ausland/usa-versus-china-joe-biden-genehmigt-militaerhilfen-fuer-taiwan-a-2fe4d3ba-746a-4f4e-a73c-a21b22dbfb2d#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:11:00+00:00

»Standhaftes« Sicherheitsengagement: Die Vereinigten Staaten sichern den Inselstaat Taiwan mit Militärhilfe gegen die Bedrohung aus China ab. Unklar ist, wie es nach der Amtsübernahme von Donald Trump weitergeht.

## Syrien: US-Militär tötet IS-Anführer durch Luftangriff
 - [https://www.spiegel.de/ausland/syrien-us-militaer-toetet-is-anfuehrer-durch-luftangriff-a-5310a018-589d-4380-8243-900f9cfe9e3a#ref=rss](https://www.spiegel.de/ausland/syrien-us-militaer-toetet-is-anfuehrer-durch-luftangriff-a-5310a018-589d-4380-8243-900f9cfe9e3a#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:35.727276+00:00

Die Vereinigten Staaten kämpfen mit 2000 Soldaten in Syrien gegen die Terrormiliz »Islamischer Staat«, selbst B-52-Bomber sind im Einsatz. Nun haben die US-Truppen einen IS-Anführer gezielt getötet.

## Deutsches Rotes Kreuz verzeichnet massiven Spendeneinbruch
 - [https://www.spiegel.de/panorama/gesellschaft/deutsches-rotes-kreuz-verzeichnet-massiven-spendeneinbruch-a-9babff77-3bba-435d-b943-170fe3a1f088#ref=rss](https://www.spiegel.de/panorama/gesellschaft/deutsches-rotes-kreuz-verzeichnet-massiven-spendeneinbruch-a-9babff77-3bba-435d-b943-170fe3a1f088#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:34.958518+00:00

Weniger als die Hälfte der Spenden des Vorjahres ging beim Deutschen Roten Kreuz ein. Präsidentin Gerda Hasselfeldt hofft auf Besserung im kommenden Jahr.

## Magdeburg – News: Polizei geht von Einzeltäter aus, Hinweise auf zweites Auto nicht bestätigt
 - [https://www.spiegel.de/panorama/justiz/magdeburg-news-polizei-geht-von-einzeltaeter-aus-hinweise-auf-zweites-auto-nicht-bestaetigt-a-16214d4b-1014-4648-b32a-82d11b748364#ref=rss](https://www.spiegel.de/panorama/justiz/magdeburg-news-polizei-geht-von-einzeltaeter-aus-hinweise-auf-zweites-auto-nicht-bestaetigt-a-16214d4b-1014-4648-b32a-82d11b748364#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T07:10:00+00:00

Der Todesfahrer von Magdeburg wurde festgenommen. Die Polizei spricht von einem Einzeltäter. Und: Bundeskanzler Olaf Scholz will nach Magdeburg reisen. Die Entwicklungen im News-Blog.

## Donald Trump: Traum einer Präsidentschaft ohne Limit
 - [https://www.spiegel.de/ausland/donald-trump-traum-einer-praesidentschaft-ohne-limit-a-439ae03a-a0f6-449b-86e8-af16f2e80258#ref=rss](https://www.spiegel.de/ausland/donald-trump-traum-einer-praesidentschaft-ohne-limit-a-439ae03a-a0f6-449b-86e8-af16f2e80258#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T06:06:27.138839+00:00

Der Republikaner versucht schon vor seinem Einzug ins Weiße Haus, die Machtbalance in Washington radikal zu seinen Gunsten zu verschieben. Dafür war er bereit, das Land ins Chaos zu stürzen.

## Bahn: Verspätungen führen 2024 zu Umsatzverlust von 700 Millionen Euro
 - [https://www.spiegel.de/wirtschaft/bahn-verspaetungen-fuehren-2024-zu-umsatzverlust-von-700-millionen-euro-a-0c4691b1-cd77-4292-91c2-f8a98a0607a0#ref=rss](https://www.spiegel.de/wirtschaft/bahn-verspaetungen-fuehren-2024-zu-umsatzverlust-von-700-millionen-euro-a-0c4691b1-cd77-4292-91c2-f8a98a0607a0#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T06:06:26.781608+00:00

Verspätungen, Streiks und immer mehr Baustellen: Die Bahn kommt das alles teuer zu stehen. Besonders kostspieliger Posten: Entschädigungen für Kunden, deren Zug mehr als eine Stunde zu spät eintrudelte.

## Schöner schreiben: Marie-Luise Scherer und die kraftvolle Genauigkeit – die Deutschkolumne
 - [https://www.spiegel.de/kultur/schoener-schreiben-marie-luise-scherer-und-die-kraftvolle-genauigkeit-die-deutschkolumne-a-c0bdc9b0-254c-482e-be25-899958b6e995#ref=rss](https://www.spiegel.de/kultur/schoener-schreiben-marie-luise-scherer-und-die-kraftvolle-genauigkeit-die-deutschkolumne-a-c0bdc9b0-254c-482e-be25-899958b6e995#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T06:06:26.354908+00:00

Unser Kolumnist zeigt an Beispielen aus der Literatur, wie kraftvoll die deutsche Sprache sein kann. Folge 113: Marie-Luise Scherer sucht die »kräftige Genauigkeit«.

## Besuch in einer Geschenkpapierfabrik: Da kannst du einpacken
 - [https://www.spiegel.de/deinspiegel/besuch-in-einer-geschenkpapierfabrik-da-kannst-du-einpacken-a-3609d05d-0b96-43c5-987b-0a80f6ab90bb#ref=rss](https://www.spiegel.de/deinspiegel/besuch-in-einer-geschenkpapierfabrik-da-kannst-du-einpacken-a-3609d05d-0b96-43c5-987b-0a80f6ab90bb#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T06:06:25.974177+00:00

Die Firma Zöwie ist der größte Geschenkpapierhersteller Deutschlands. »Dein SPIEGEL« hat sich in einer der Fabriken umgeschaut.

## Festessen an Weihnachten: Einblicke in die »Küchenmeisterei«, Deutschlands ältestes Kochbuch
 - [https://www.spiegel.de/stil/festessen-an-weihnachten-einblicke-in-die-kuechenmeisterei-deutschlands-aeltestes-kochbuch-a-45046c8f-cd61-49f8-ab4b-bc407b75450f#ref=rss](https://www.spiegel.de/stil/festessen-an-weihnachten-einblicke-in-die-kuechenmeisterei-deutschlands-aeltestes-kochbuch-a-45046c8f-cd61-49f8-ab4b-bc407b75450f#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T06:06:25.578709+00:00

»Kalbslunge hackt man schön und klein«: Die »Küchenmeisterei« gilt als Deutschlands ältestes gedrucktes Kochbuch. Darin finden sich vergoldete Speisen und raffinierte Rezepte. Manches ist bis heute erhalten geblieben.

## Russland und Ukraine tauschen Weihnachtspakete und Briefe für Gefangene aus
 - [https://www.spiegel.de/ausland/russland-und-ukraine-tauschen-weihnachtspakete-und-briefe-fuer-gefangene-aus-a-e2ad4a3f-4d67-4dda-b132-d32a0f3fab3b#ref=rss](https://www.spiegel.de/ausland/russland-und-ukraine-tauschen-weihnachtspakete-und-briefe-fuer-gefangene-aus-a-e2ad4a3f-4d67-4dda-b132-d32a0f3fab3b#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:02:48.962990+00:00

Kontakte zwischen Kyjiw und Moskau laufen derzeit verdeckt ab. Nun aber treffen sich zwei ranghohe Vertreter in Belarus – in humanitärer Mission. Gleichzeitig gehen die Gefechte mit unverminderter Härte weiter.

## Sophia Thomalla: Die Frau, die Veganer, Radfahrer und Gender-Aktivistinnen aufregt
 - [https://www.spiegel.de/panorama/sophia-thomalla-die-frau-die-veganer-radfahrer-und-gender-aktivistinnen-aufregt-a-17b42302-1902-4b52-9ffa-51ed60211586#ref=rss](https://www.spiegel.de/panorama/sophia-thomalla-die-frau-die-veganer-radfahrer-und-gender-aktivistinnen-aufregt-a-17b42302-1902-4b52-9ffa-51ed60211586#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:02:48.702695+00:00

Sophia Thomalla hat keine Lust mehr auf Großstadt. Viel lieber steht sie im Wald herum, mit Kippe und Gewehr. Ein Porträt.

## Bad Segeberg und seine Autokennzeichen: Wie ich auf humorvolle Menschen traf, deren Autos das Kennzeichen SE-XY tragen
 - [https://www.spiegel.de/partnerschaft/bad-segeberg-und-seine-autokennzeichen-wie-ich-auf-humorvolle-menschen-traf-deren-autos-das-kennzeichen-se-xy-tragen-a-0b2e9e87-9a32-4ea9-8a14-b604510f751b#ref=rss](https://www.spiegel.de/partnerschaft/bad-segeberg-und-seine-autokennzeichen-wie-ich-auf-humorvolle-menschen-traf-deren-autos-das-kennzeichen-se-xy-tragen-a-0b2e9e87-9a32-4ea9-8a14-b604510f751b#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:02:48.438515+00:00

Seit meiner Kindheit frage ich mich, wer da mit »sexy« Nummernschild über Landstraßen und Autobahnen brettert. Mit einem mulmigen Gefühl fuhr ich nach Bad Segeberg und lernte dort lustige Menschen kennen.

## News: Tote und Verletzte in Magdeburg, Weihnachtsmarkt, Hamburger BSW, Elon Musk
 - [https://www.spiegel.de/politik/deutschland/news-tote-und-verletzte-in-magdeburg-weihnachtsmarkt-hamburger-bsw-elon-musk-a-6b1a4d4d-6ac2-4df7-9a3d-67e70441f8d4#ref=rss](https://www.spiegel.de/politik/deutschland/news-tote-und-verletzte-in-magdeburg-weihnachtsmarkt-hamburger-bsw-elon-musk-a-6b1a4d4d-6ac2-4df7-9a3d-67e70441f8d4#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:02:48.153035+00:00

Eine Todesfahrt auf dem Weihnachtsmarkt in Magdeburg erschüttert Deutschland. Das BSW hat ein echtes Problem, die Union ein empfundenes. Elon Musk greift in den deutschen Wahlkampf ein. Das ist die Lage am Samstagmorgen.

## Krieg in Nahost: Mehr als ein Dutzend Verletzte in Israel nach Einschlag von »Geschoss« aus dem Jemen
 - [https://www.spiegel.de/ausland/krieg-in-nahost-mehr-als-ein-dutzend-verletzte-in-israel-nach-einschlag-von-geschoss-aus-dem-jemen-a-2c9626ea-d6db-4ab3-8fee-f18f228207a5#ref=rss](https://www.spiegel.de/ausland/krieg-in-nahost-mehr-als-ein-dutzend-verletzte-in-israel-nach-einschlag-von-geschoss-aus-dem-jemen-a-2c9626ea-d6db-4ab3-8fee-f18f228207a5#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T04:59:00+00:00

Dieses Mal hat der Abwehrschirm die anfliegende Rakete aus dem Jemen nicht rechtzeitig erwischt. Bei Jaffa schlägt sie ein. Der medizinische Notfalldienst meldet Verletzte.

## Verteidigungsminister Boris Pistorius fordert mehr Geld für die Bundeswehr
 - [https://www.spiegel.de/politik/verteidigungsminister-boris-pistorius-fordert-mehr-geld-fuer-die-bundeswehr-a-a3ab35aa-526e-44a8-bae0-c4e5bc5e9f5f#ref=rss](https://www.spiegel.de/politik/verteidigungsminister-boris-pistorius-fordert-mehr-geld-fuer-die-bundeswehr-a-a3ab35aa-526e-44a8-bae0-c4e5bc5e9f5f#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T03:58:38.276506+00:00

»Kriegstüchtig« müsse die Bundeswehr sein, sagt Verteidigungsminister Pistorius immer. Um aber für den Ernstfall gerüstet zu sein, braucht die Truppe mehr Geld. Doch da steht vor allem ein Hindernis im Weg.

## Syrien: Annalena Baerbock fordert Entwaffnung von kurdischen Rebellen
 - [https://www.spiegel.de/ausland/syrien-annalena-baerbock-fordert-entwaffnung-von-kurdischen-rebellen-a-45283f3a-849f-4b6e-9b3a-118b4aabe0f0#ref=rss](https://www.spiegel.de/ausland/syrien-annalena-baerbock-fordert-entwaffnung-von-kurdischen-rebellen-a-45283f3a-849f-4b6e-9b3a-118b4aabe0f0#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T01:47:34.800721+00:00

Bei einem Treffen mit dem türkischen Außenminister kündigte Annalena Baerbock an, dass die kurdischen Anti-IS-Milizen ihre Waffen niederlegen sollen. Derweil greifen Berichten zufolge protürkische Milizen Kobanê an.

## Syrien: USA heben Kopfgeld auf Milizenführer Ahmed al-Sharaa auf
 - [https://www.spiegel.de/ausland/syrien-usa-heben-kopfgeld-auf-milizenfuehrer-ahmed-al-sharaa-auf-a-7e200d5f-65e3-47d3-820d-9168b2ff42f3#ref=rss](https://www.spiegel.de/ausland/syrien-usa-heben-kopfgeld-auf-milizenfuehrer-ahmed-al-sharaa-auf-a-7e200d5f-65e3-47d3-820d-9168b2ff42f3#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T01:47:34.483560+00:00

US-Diplomaten haben in Syrien den HTS-Anführer getroffen und danach von guten Gesprächen berichtet. Das Zehn-Millionen-Dollar-Kopfgeld ziehen die USA nun zurück. Aber sie knüpfen an die Entscheidung auch Erwartungen.

## Anschlag in Magdeburg: Immer wieder Weihnachtsmärkte
 - [https://www.spiegel.de/panorama/anschlag-in-magdeburg-immer-wieder-weihnachtsmaerkte-a-67b48535-860c-4813-8e44-3d573058c2d8#ref=rss](https://www.spiegel.de/panorama/anschlag-in-magdeburg-immer-wieder-weihnachtsmaerkte-a-67b48535-860c-4813-8e44-3d573058c2d8#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T00:28:08.209093+00:00

Die Todesfahrt von Magdeburg erinnert an den schrecklichen Angriff auf den Weihnachtsmarkt in Berlin, der sich gerade zum achten Mal jährte. Und auch das war nicht die erste Attacke dieser Art. Ein Überblick.

## Magdeburg: Mutmaßlicher Anschlag auf Weihnachtsmarkt – was über den Todesfahrer bekannt ist
 - [https://www.spiegel.de/panorama/justiz/magdeburg-mutmasslicher-anschlag-auf-weihnachtsmarkt-was-ueber-den-todesfahrer-bekannt-ist-a-ac3fd67b-d089-48b4-afbd-ca51e73e5637#ref=rss](https://www.spiegel.de/panorama/justiz/magdeburg-mutmasslicher-anschlag-auf-weihnachtsmarkt-was-ueber-den-todesfahrer-bekannt-ist-a-ac3fd67b-d089-48b4-afbd-ca51e73e5637#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T00:28:08.084935+00:00

Ein 50 Jahre alter Arzt aus Saudi-Arabien soll gezielt mit einem Auto über den Weihnachtsmarkt in Magdeburg gerast sein. Das Motiv ist rätselhaft, ein islamistischer Hintergrund so gut wie ausgeschlossen.

## Drohender »Shutdown« in den USA: Repräsentantenhaus beschließt kurz vor knapp einen Übergangshaushalt
 - [https://www.spiegel.de/ausland/drohender-shutdown-in-den-usa-repraesentantenhaus-beschliesst-kurz-vor-knapp-einen-uebergangshaushalt-a-0e8a78e6-cc2a-4a36-b52d-af6984d4c23c#ref=rss](https://www.spiegel.de/ausland/drohender-shutdown-in-den-usa-repraesentantenhaus-beschliesst-kurz-vor-knapp-einen-uebergangshaushalt-a-0e8a78e6-cc2a-4a36-b52d-af6984d4c23c#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T00:28:07.966375+00:00

Nur wenige Stunden vor Ablauf der letzten Frist: Republikaner und Demokraten einigen sich im Haushaltsstreit auf einen Kompromiss, um einen Stillstand der Regierung zu verhindern. Nur zwei Schritte fehlen noch.

## Magdeburg: Wie ein Polizist und ein freiwilliger Helfer die Todesfahrt erlebt haben
 - [https://www.spiegel.de/panorama/justiz/magdeburg-wie-ein-polizist-und-ein-freiwilliger-helfer-die-todesfahrt-erlebt-haben-a-3e7d0f33-f4cb-4e35-8440-e96a111498b0#ref=rss](https://www.spiegel.de/panorama/justiz/magdeburg-wie-ein-polizist-und-ein-freiwilliger-helfer-die-todesfahrt-erlebt-haben-a-3e7d0f33-f4cb-4e35-8440-e96a111498b0#ref=rss)
 - RSS feed: $source
 - date published: 2024-12-21T00:21:00+00:00

Ein Mann rast mit einem Auto über einen Magdeburger Weihnachtsmarkt, mindestens zwei Menschen sterben. Ein Polizist und ein freiwilliger Helfer erzählen, wie sie den Horror erlebt haben.

