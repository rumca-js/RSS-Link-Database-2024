# Source:AirPano VR, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCUSElbgKZpE4Xdh5aFWG-Ig, language:en

## Greenland, Land of Ice. Trailer.  6K aerial 360° video
 - [https://www.youtube.com/watch?v=Mc83fY0v3g8](https://www.youtube.com/watch?v=Mc83fY0v3g8)
 - RSS feed: $source
 - date published: 2024-12-21T11:37:52+00:00

Don't forget that this is 360° video: you can change the angle of view.

About 80% of the territory is covered by ice. Such large amounts of ice forced the lithosphere to sink, forming the terrain of Greenland. All the 250 kilometers of the coast are carved with deep and long fjords. Often they are blocked with huge icebergs.

360° panoramas of Greenland: http://www.airpano.com/360photo/Greenland-Ilulissat/

If you enjoyed this video please like, share, comment, favorite, subscribe: https://goo.gl/NZMdaz 
We regularly publish new 360° videos of the most beautiful places on our planet!

360° photos and videos, stories of our shootings, articles and FAQ you can find on our website: http://AirPano.com

#AirPano #AirPanoNature #aerial #drone #360video #virtualreality #vrvideo #vr #4kaerialvideo #greenland #ice #iceberg #whale

