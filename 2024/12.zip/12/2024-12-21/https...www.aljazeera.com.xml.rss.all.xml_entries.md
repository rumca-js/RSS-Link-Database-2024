# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Germans mourn five people killed, 200 injured in Christmas market attack
 - [https://www.aljazeera.com/news/2024/12/21/germans-mourn-the-5-killed-200-injured-in-christmas-market-attack?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/germans-mourn-the-5-killed-200-injured-in-christmas-market-attack?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T21:10:54+00:00

A memorial service takes place in the cathedral of Magdeburg, a city shaken by the deadly incident.

## Syrian authorities appoint HTS figures as foreign, defence ministers
 - [https://www.aljazeera.com/news/2024/12/21/syrias-new-rulers-appoint-hts-figures-as-foreign-defence-ministers?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/syrias-new-rulers-appoint-hts-figures-as-foreign-defence-ministers?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T20:18:48+00:00

Asaad Hassan al-Shibani appointed foreign minister, and Murhaf Abu Qasra named defence minister.

## ‘No concern for Palestinian suffering’: Ex-official slams US’s Gaza policy
 - [https://www.aljazeera.com/news/2024/12/21/no-concern-for-palestinian-suffering-ex-official-slams-uss-gaza-policy?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/no-concern-for-palestinian-suffering-ex-official-slams-uss-gaza-policy?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T20:01:25+00:00

Former State Department official Mike Casey says the US government is pursuing Israel&#039;s interests over its own.

## Is the US willing to take action against foreign powers fuelling Sudan war?
 - [https://www.aljazeera.com/program/inside-story/2024/12/21/is-the-us-willing-to-take-action-against-foreign-powers-fuelling-sudan-war?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2024/12/21/is-the-us-willing-to-take-action-against-foreign-powers-fuelling-sudan-war?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:32:45+00:00

President Joe Biden hopes to negotiate a ceasefire before leaving office in January.

## Albania bans TikTok for one year after school stabbing
 - [https://www.aljazeera.com/news/2024/12/21/albania-bans-tiktok-for-one-year-following-school-stabbing?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/albania-bans-tiktok-for-one-year-following-school-stabbing?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T18:35:31+00:00

The decision comes after a 14-year-old boy was stabbed to death by a classmate following a social media fight.

## At least 13 people killed in Nigeria stampedes at charity events
 - [https://www.aljazeera.com/news/2024/12/21/at-least-13-people-killed-in-nigeria-stampedes-at-charity-events?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/at-least-13-people-killed-in-nigeria-stampedes-at-charity-events?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T18:17:32+00:00

At least 10 killed in the capital, Abuja, and three killed in the town of Okija during charity distributions.

## Biden signs funding bill into law, averting US government shutdown
 - [https://www.aljazeera.com/news/2024/12/21/biden-signs-funding-bill-into-law-averting-us-government-shutdown?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/biden-signs-funding-bill-into-law-averting-us-government-shutdown?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T18:12:41+00:00

President hails the passage of the legislation after days of uncertainty and negotiations that went down to the wire.

## At least 32 people killed as bus and truck collide in Brazil
 - [https://www.aljazeera.com/news/2024/12/21/crash-between-passenger-bus-and-truck-kills-at-least-30-in-brazil?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/crash-between-passenger-bus-and-truck-kills-at-least-30-in-brazil?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T16:40:35+00:00

Passenger bus collides with truck near town of Lajinha in southeastern state of Minas Gerais, fire officials say.

## Syria and the stakes for regional powers
 - [https://www.aljazeera.com/program/the-listening-post/2024/12/21/syria-and-the-stakes-for-regional-powers?traffic_source=rss](https://www.aljazeera.com/program/the-listening-post/2024/12/21/syria-and-the-stakes-for-regional-powers?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:49:07+00:00

The fall of al-Assad has set off a new phase of jigsaw puzzling in the region.

## Eight sentenced in France in connection with murder of teacher Samuel Paty
 - [https://www.aljazeera.com/news/2024/12/21/french-court-jails-eight-people-involved-in-beheading-of-teacher?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/french-court-jails-eight-people-involved-in-beheading-of-teacher?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:07:01+00:00

Teacher was stabbed and beheaded outside his school in Paris in 2020 after an online hate campaign.

## Trump and the return of the National ‘Emergy’
 - [https://www.aljazeera.com/opinions/2024/12/21/trump-and-the-return-of-the-national?traffic_source=rss](https://www.aljazeera.com/opinions/2024/12/21/trump-and-the-return-of-the-national?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:13:28+00:00

A new war on migrants, aimed at distracting from actual problems, is about to begin in America.

## Governments and banks once mocked Bitcoin. Now they want in on it
 - [https://www.aljazeera.com/economy/2024/12/21/governments-and-banks-once-mocked-bitcoin-now-they-want-in-on-it?traffic_source=rss](https://www.aljazeera.com/economy/2024/12/21/governments-and-banks-once-mocked-bitcoin-now-they-want-in-on-it?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:05:33+00:00

After topping $100,000, Bitcoin supporters see the cryptocurrency soaring even higher.

## Pakistan jails 25 Imran Khan supporters over attacks on military sites
 - [https://www.aljazeera.com/news/2024/12/21/pakistan-jails-25-imran-khan-supporters-over-attacks-on-military-sites?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/pakistan-jails-25-imran-khan-supporters-over-attacks-on-military-sites?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:06:04+00:00

Military court convicts civilians involved in 2023 unrest, with rights groups slamming ruling as ‘intimidation tactic’.

## Ukrainian drones strike deep into Russia, Russia takes Donetsk town
 - [https://www.aljazeera.com/news/2024/12/21/ukrainian-drones-strike-deep-into-russia-russia-takes-donetsk-town?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/ukrainian-drones-strike-deep-into-russia-russia-takes-donetsk-town?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:42:08+00:00

Residential buildings have been hit in the Russian city of Kazan, causing no casualties.

## What are ‘non-crime hate incidents’ which have become so hated in the UK?
 - [https://www.aljazeera.com/news/2024/12/21/what-are-non-crime-hate-incidents-which-have-become-so-hated-in-the-uk?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/what-are-non-crime-hate-incidents-which-have-become-so-hated-in-the-uk?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:37:10+00:00

Children in England and Wales have been investigated by police for calling each other names, a study has found.

## Israel kills 7 children from one family in air strike on Gaza
 - [https://www.aljazeera.com/news/2024/12/21/israel-kills-7-children-from-one-family-in-air-strike-on-gaza?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/israel-kills-7-children-from-one-family-in-air-strike-on-gaza?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:01:57+00:00

UNRWA says Gaza has become a &#039;graveyard&#039; as Israel continues its bombing campaign amid worsening living conditions.

## Yemen’s Houthis hit Tel Aviv, Israel, with missile
 - [https://www.aljazeera.com/news/2024/12/21/yemens-houthis-hit-israels-tel-aviv-with-projectile?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/yemens-houthis-hit-israels-tel-aviv-with-projectile?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T07:44:27+00:00

Latest tit-for-tat attack follows Israeli air strikes on Sanaa and Hodeidah, which killed nine people earlier this week.

## Could mosquitoes deliver vaccines against malaria?
 - [https://www.aljazeera.com/news/2024/12/21/could-mosquitoes-deliver-vaccines-against-malaria?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/could-mosquitoes-deliver-vaccines-against-malaria?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T07:36:24+00:00

Scientists have engineered the pests to provide enhanced immunity to the disease they transmit, according to new study.

## Russia-Ukraine war: List of key events, day 1,031
 - [https://www.aljazeera.com/news/2024/12/21/russia-ukraine-war-list-of-key-events-day-1031?traffic_source=rss](https://www.aljazeera.com/news/2024/12/21/russia-ukraine-war-list-of-key-events-day-1031?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T06:55:59+00:00

Here are the key developments on the 1,031st day of Russia’s invasion of Ukraine.

## ‘Trapped inside’: The children suffocating in the smog of Lahore
 - [https://www.aljazeera.com/features/2024/12/21/trapped-inside-the-children-suffocating-in-the-smog-of-lahore?traffic_source=rss](https://www.aljazeera.com/features/2024/12/21/trapped-inside-the-children-suffocating-in-the-smog-of-lahore?traffic_source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:23:41+00:00

Air pollution has become a major problem in Pakistan and it is children who are paying the price.

