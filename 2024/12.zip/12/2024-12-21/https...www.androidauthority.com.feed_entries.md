# Source:Android Authority, URL:https://www.androidauthority.com/feed, language:en-US

## iPad apps being better than Android tablet apps is such a bad myth, if you ask me
 - [https://www.androidauthority.com/ipad-apps-vs-android-tablet-apps-3507701](https://www.androidauthority.com/ipad-apps-vs-android-tablet-apps-3507701)
 - RSS feed: $source
 - date published: 2024-12-21T17:00:39+00:00

Fully optimized iPad apps are excellent, but what about the rest?

## Qualcomm’s grip weakens as big players look elsewhere for 5G modems
 - [https://www.androidauthority.com/qualcomm-5g-modems-diversification-3509680](https://www.androidauthority.com/qualcomm-5g-modems-diversification-3509680)
 - RSS feed: $source
 - date published: 2024-12-21T15:00:03+00:00

Tough times ahead for the the long-time mobile modem master?

## If I were buying an older flagship phone, this is the one I’d get
 - [https://www.androidauthority.com/buying-old-flagship-phone-3510090](https://www.androidauthority.com/buying-old-flagship-phone-3510090)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:31+00:00

As if there was any doubt I'd pick a Pixel.

## Google puts the cherry on its year-end recaps with this Year in Search 2024 Doodle
 - [https://www.androidauthority.com/google-year-in-search-doodle-3510874](https://www.androidauthority.com/google-year-in-search-doodle-3510874)
 - RSS feed: $source
 - date published: 2024-12-21T04:15:10+00:00

From a chubby little hippo to celestial ballet, the year's top searches are now a Google Doodle.

