# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Mediocre tools
 - [https://seths.blog/2024/12/mediocre-tools](https://seths.blog/2024/12/mediocre-tools)
 - RSS feed: $source
 - date published: 2024-12-21T09:19:00+00:00

Lousy tools are dangerous. They endanger our safety (physical or emotional) and undermine our work. Lousy tools are pretty easy to avoid, because they reveal themselves whenever we use them. Great tools are magical. They multiply our effort, amplify the quality of our work and delight us, all at once. It&#8217;s mediocre tools that we [&#8230;]

