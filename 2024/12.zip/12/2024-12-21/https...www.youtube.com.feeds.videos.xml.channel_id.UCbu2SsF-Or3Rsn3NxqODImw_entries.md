# Source:GameSpot - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Gamespots Countdown to the Game Awards
 - [https://www.youtube.com/watch?v=iFzGa2BwQ54](https://www.youtube.com/watch?v=iFzGa2BwQ54)
 - RSS feed: $source
 - date published: 2024-12-21T00:46:17+00:00

GameSpot's Countdown To The Game Awards. Featuring GameSpot and Giant Bomb hosts, industry developers, and special guests.

