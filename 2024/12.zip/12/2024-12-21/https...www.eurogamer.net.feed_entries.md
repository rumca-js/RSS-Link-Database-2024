# Source:Eurogamer.net Latest Articles Feed, URL:https://www.eurogamer.net/feed, language:en-gb

## What we've been playing - Open-world dress up, plant puzzles, and festive levels
 - [https://www.eurogamer.net/what-weve-been-playing-christmas](https://www.eurogamer.net/what-weve-been-playing-christmas)
 - RSS feed: $source
 - date published: 2024-12-21T08:00:00+00:00

<img src="https://assetsio.gnwcdn.com/Astro-Bot-Winter-Wonder-update-level-showing-a-festive-area-covered-in-snow-with-a-large-christmas-tree-in-the-background.jpg?width=1920&height=1920&fit=bounds&quality=80&format=jpg&auto=webp" /> <p>Hello! Welcome back to our regular feature where we write a little bit about some of the games we've been playing over the past few days. This week, we love a nice festive level, tackle some plant-based puzzles, and explore a brilliant open world while wearing some tremendous outfits.</p> <p><a href="https://www.eurogamer.net/what-weve-been-playing-christmas">Read more</a></p>

