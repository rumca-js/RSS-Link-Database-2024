# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## PFRON: Dofinansowania do turnusów rehabilitacyjnych. 30% przeciętnego wynagrodzenia, 27%, 25% i 20% [Osoby niepełnosprawne. Opiekunowie]
 - [https://forsal.pl/finanse/artykuly/9699086,pfron-dofinansowania-do-turnusow-rehabilitacyjnych-30-przecietnego-wynagrodzenia-27-25-i-20-osoby-niepelnosprawne-opiekunowie.html](https://forsal.pl/finanse/artykuly/9699086,pfron-dofinansowania-do-turnusow-rehabilitacyjnych-30-przecietnego-wynagrodzenia-27-25-i-20-osoby-niepelnosprawne-opiekunowie.html)
 - RSS feed: $source
 - date published: 2024-12-21T23:51:00+00:00

None

## Brak kapitalizacji kwartalnej pokrzywdził emerytów. Dwa projekty ustaw naprawczych. Dwie filozofie [Projekt nowelizacji]
 - [https://forsal.pl/finanse/artykuly/9699085,brak-kapitalizacji-kwartalnej-pokrzywdzil-emerytow-dwa-projekty-ustaw-naprawczych-dwie-filozofie-projekt-nowelizacji.html](https://forsal.pl/finanse/artykuly/9699085,brak-kapitalizacji-kwartalnej-pokrzywdzil-emerytow-dwa-projekty-ustaw-naprawczych-dwie-filozofie-projekt-nowelizacji.html)
 - RSS feed: $source
 - date published: 2024-12-21T23:29:41+00:00

None

## Rząd a osoby niepełnosprawne: Trzy symbole w orzeczeniu o niepełnosprawności. Nawet gdy jest 7 defektów w niepełnosprawności
 - [https://forsal.pl/finanse/artykuly/9698821,0-rzad-a-osoby-niepelnosprawne-trzy-symbole-w-orzeczeniu-o-niepelnosprawnosci-nawet-gdy-jest-7-defektow-w-niepelnosprawnosci.html](https://forsal.pl/finanse/artykuly/9698821,0-rzad-a-osoby-niepelnosprawne-trzy-symbole-w-orzeczeniu-o-niepelnosprawnosci-nawet-gdy-jest-7-defektow-w-niepelnosprawnosci.html)
 - RSS feed: $source
 - date published: 2024-12-21T21:49:30+00:00

None

## Zasiłek stały z MOPS w 2025 r. to świadczenie widełkowe [od do]. Nie zawsze wyżej niż zasiłek pielęgnacyjny 215,84 zł [Przykład]
 - [https://forsal.pl/finanse/artykuly/9698808,zasilek-staly-z-mops-w-2025-r-to-swiadczenie-widelkowe-od-do-nie-zawsze-wyzej-niz-zasilek-pielegnacyjny-21584-zl-przyklad.html](https://forsal.pl/finanse/artykuly/9698808,zasilek-staly-z-mops-w-2025-r-to-swiadczenie-widelkowe-od-do-nie-zawsze-wyzej-niz-zasilek-pielegnacyjny-21584-zl-przyklad.html)
 - RSS feed: $source
 - date published: 2024-12-21T20:20:24+00:00

None

## Kariera w amerykańskim stylu w polskim markecie. Spółką o gigantycznej wartości będzie rządził… kasjer
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9698671,kariera-w-amerykanskim-stylu-w-polskim-markecie-spolka-o-gigantycznej.html](https://forsal.pl/biznes/aktualnosci/artykuly/9698671,kariera-w-amerykanskim-stylu-w-polskim-markecie-spolka-o-gigantycznej.html)
 - RSS feed: $source
 - date published: 2024-12-21T17:40:15+00:00

None

## MRPiPS i wyrok TK: Przeliczenie emerytur. I podwyżka. Bez rekompensaty za zaniżanie emerytur przez 5-15 lat [Projekt nowelizacji]
 - [https://forsal.pl/finanse/artykuly/9698669,mrpips-i-wyrok-tk-przeliczenie-emerytur-i-podwyzka-bez-rekompensaty-za-zanizanie-emerytur-przez-5-15-lat-projekt-nowelizacji.html](https://forsal.pl/finanse/artykuly/9698669,mrpips-i-wyrok-tk-przeliczenie-emerytur-i-podwyzka-bez-rekompensaty-za-zanizanie-emerytur-przez-5-15-lat-projekt-nowelizacji.html)
 - RSS feed: $source
 - date published: 2024-12-21T17:20:46+00:00

None

## MRPiPS: świadczenia MOPS z pomocy społecznej muszą być niższe niż ZUS [Interpretacja pisma Departamentu Pomocy Społecznej]
 - [https://forsal.pl/finanse/artykuly/9698661,mrpips-swiadczenia-mops-z-pomocy-spolecznej-musza-byc-nizsze-niz-zus-interpretacja-pisma-departamentu-pomocy-spolecznej.html](https://forsal.pl/finanse/artykuly/9698661,mrpips-swiadczenia-mops-z-pomocy-spolecznej-musza-byc-nizsze-niz-zus-interpretacja-pisma-departamentu-pomocy-spolecznej.html)
 - RSS feed: $source
 - date published: 2024-12-21T14:44:48+00:00

None

## MRPiPS: Zasiłek stały z MOPS kontra renta socjalna z ZUS [1229 zł dla niektórych a 1901,70 zł brutto dla wszystkich]
 - [https://forsal.pl/finanse/artykuly/9698533,mrpips-zasilek-staly-z-mops-kontra-renta-socjalna-z-zus-1229-zl-dla-niektorych-a-190170-zl-brutto-dla-wszystkich.html](https://forsal.pl/finanse/artykuly/9698533,mrpips-zasilek-staly-z-mops-kontra-renta-socjalna-z-zus-1229-zl-dla-niektorych-a-190170-zl-brutto-dla-wszystkich.html)
 - RSS feed: $source
 - date published: 2024-12-21T14:37:41+00:00

None

## Rewolucja na torach: Modernizacja linii Białystok-Ełk zapowiedziana na 2029 rok
 - [https://forsal.pl/transport/kolej/artykuly/9698655,rewolucja-na-torach-modernizacja-linii-bialystok-elk-zapowiedziana-na.html](https://forsal.pl/transport/kolej/artykuly/9698655,rewolucja-na-torach-modernizacja-linii-bialystok-elk-zapowiedziana-na.html)
 - RSS feed: $source
 - date published: 2024-12-21T14:10:59+00:00

None

## Astrologiczna zima 2024: Jak tegoroczny klimat wpisuje się w historyczne anomalie?
 - [https://forsal.pl/lifestyle/nauka/artykuly/9698652,astrologiczna-zima-2024-jak-tegoroczny-klimat-wpisuje-sie-w-historycz.html](https://forsal.pl/lifestyle/nauka/artykuly/9698652,astrologiczna-zima-2024-jak-tegoroczny-klimat-wpisuje-sie-w-historycz.html)
 - RSS feed: $source
 - date published: 2024-12-21T14:10:36+00:00

None

## Kolejne „Zośki” w rękach żołnierzy. Rosomaki z ZSSW-30 trafiły do wojska
 - [https://forsal.pl/kraj/bezpieczenstwo/artykuly/9698569,kolejne-zoski-w-rekach-zolnierzy-rosomaki-z-zssw-30-trafily-do-wojs.html](https://forsal.pl/kraj/bezpieczenstwo/artykuly/9698569,kolejne-zoski-w-rekach-zolnierzy-rosomaki-z-zssw-30-trafily-do-wojs.html)
 - RSS feed: $source
 - date published: 2024-12-21T13:00:00+00:00

None

## Europejski Nakaz Aresztowania dla Romana Romanowskiego. Poseł PiS oskarża rząd Tuska o prześladowania
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9698555,europejski-nakaz-aresztowania-dla-romana-romanowskiego-posel-pis-oska.html](https://forsal.pl/swiat/unia-europejska/artykuly/9698555,europejski-nakaz-aresztowania-dla-romana-romanowskiego-posel-pis-oska.html)
 - RSS feed: $source
 - date published: 2024-12-21T12:27:16+00:00

None

## Relacje Węgry-Polska na granicy kryzysu: Orban komentuje decyzję o azylu dla Romanowskiego
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9698554,relacje-wegry-polska-na-granicy-kryzysu-orban-komentuje-decyzje-o-azy.html](https://forsal.pl/swiat/unia-europejska/artykuly/9698554,relacje-wegry-polska-na-granicy-kryzysu-orban-komentuje-decyzje-o-azy.html)
 - RSS feed: $source
 - date published: 2024-12-21T12:27:08+00:00

None

## Dramatyczne wydarzenia na jarmarku w Magdeburgu. Ponad 200 rannych, pięć nie żyje
 - [https://forsal.pl/swiat/niemcy/artykuly/9698521,dramatyczne-wydarzenia-na-jarmarku-w-magdeburgu-ponad-200-rannych-pi.html](https://forsal.pl/swiat/niemcy/artykuly/9698521,dramatyczne-wydarzenia-na-jarmarku-w-magdeburgu-ponad-200-rannych-pi.html)
 - RSS feed: $source
 - date published: 2024-12-21T11:36:47+00:00

None

## Ukraińskie innowacje na froncie: Atak bezzaogowców na pozycje rosyjskie pod Charkowem
 - [https://forsal.pl/swiat/ukraina/artykuly/9698502,ukrainskie-innowacje-na-froncie-atak-bezzaogowcow-na-pozycje-rosyjski.html](https://forsal.pl/swiat/ukraina/artykuly/9698502,ukrainskie-innowacje-na-froncie-atak-bezzaogowcow-na-pozycje-rosyjski.html)
 - RSS feed: $source
 - date published: 2024-12-21T11:03:21+00:00

None

## Czołgi Abrams za miliardy dla Egiptu. Jak zmieni się relacja Waszyngton-Kair?
 - [https://forsal.pl/swiat/usa/artykuly/9698498,czolgi-abrams-za-miliardy-dla-egiptu-jak-zmieni-sie-relacja-waszyngto.html](https://forsal.pl/swiat/usa/artykuly/9698498,czolgi-abrams-za-miliardy-dla-egiptu-jak-zmieni-sie-relacja-waszyngto.html)
 - RSS feed: $source
 - date published: 2024-12-21T11:02:58+00:00

None

## afdTaleb Abdul Dżawad: aktywista czy ekstremista? Zaskakujące fakty z życia Saudyjczyka w Niemczech
 - [https://forsal.pl/swiat/niemcy/artykuly/9698499,afdtaleb-abdul-dzawad-aktywista-czy-ekstremista-zaskakujace-fakty-z.html](https://forsal.pl/swiat/niemcy/artykuly/9698499,afdtaleb-abdul-dzawad-aktywista-czy-ekstremista-zaskakujace-fakty-z.html)
 - RSS feed: $source
 - date published: 2024-12-21T11:02:54+00:00

None

## Taleb Abdul Dżawad: aktywista czy ekstremista? Zaskakujące fakty z życia Saudyjczyka w Niemczech
 - [https://forsal.pl/swiat/niemcy/artykuly/9698499,taleb-abdul-dzawad-aktywista-czy-ekstremista-zaskakujace-fakty-z-zyc.html](https://forsal.pl/swiat/niemcy/artykuly/9698499,taleb-abdul-dzawad-aktywista-czy-ekstremista-zaskakujace-fakty-z-zyc.html)
 - RSS feed: $source
 - date published: 2024-12-21T11:02:54+00:00

None

## Atak dronów na Kazań: nieznane szczegóły tajemniczego incydentu
 - [https://forsal.pl/swiat/rosja/artykuly/9698348,atak-dronow-na-kazan-nieznane-szczegoly-tajemniczego-incydentu.html](https://forsal.pl/swiat/rosja/artykuly/9698348,atak-dronow-na-kazan-nieznane-szczegoly-tajemniczego-incydentu.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:48:39+00:00

None

## Norweg ujawnia tajemnicę, dlaczego zdradził USA dla Rosji i Iranu?
 - [https://forsal.pl/swiat/rosja/artykuly/9698303,norweg-ujawnia-tajemnice-dlaczego-zdradzil-usa-dla-rosji-i-iranu.html](https://forsal.pl/swiat/rosja/artykuly/9698303,norweg-ujawnia-tajemnice-dlaczego-zdradzil-usa-dla-rosji-i-iranu.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:13:13+00:00

None

## Arabia Saudyjska odrzuca przemoc i wyraża solidarność z Niemcami po tragedii w Saksonii-Anhalt
 - [https://forsal.pl/swiat/niemcy/artykuly/9698299,arabia-saudyjska-odrzuca-przemoc-i-wyraza-solidarnosc-z-niemcami-po-tr.html](https://forsal.pl/swiat/niemcy/artykuly/9698299,arabia-saudyjska-odrzuca-przemoc-i-wyraza-solidarnosc-z-niemcami-po-tr.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:12:52+00:00

None

## Ostatnie miesiące prezydentury Dudy: Szczyt Inicjatywy Trójmorza i zaproszenie dla Trumpa
 - [https://forsal.pl/kraj/polityka/artykuly/9698290,ostatnie-miesiace-prezydentury-dudy-szczyt-inicjatywy-trojmorza-i-zap.html](https://forsal.pl/kraj/polityka/artykuly/9698290,ostatnie-miesiace-prezydentury-dudy-szczyt-inicjatywy-trojmorza-i-zap.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:50+00:00

None

## Świąteczne zakupy pod lupą ekspertów: co kryje się w suszonych owocach?
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9698286,swiateczne-zakupy-pod-lupa-ekspertow-co-kryje-sie-w-suszonych-owocach.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9698286,swiateczne-zakupy-pod-lupa-ekspertow-co-kryje-sie-w-suszonych-owocach.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:43+00:00

None

## Demografia zdefiniuje przyszłość polskiego rynku pracy. Czy kobiety nadal będą mogły wcześniej odchodzić na emeryturę?
 - [https://forsal.pl/gospodarka/demografia/artykuly/9698285,demografia-zdefiniuje-przyszlosc-polskiego-rynku-pracy-czy-kobiety-na.html](https://forsal.pl/gospodarka/demografia/artykuly/9698285,demografia-zdefiniuje-przyszlosc-polskiego-rynku-pracy-czy-kobiety-na.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:40+00:00

None

## Zaskakujące odkrycie naukowców: Jak szybki chód działa na zdrowie metaboliczne?
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9698284,zaskakujace-odkrycie-naukowcow-jak-szybki-chod-dziala-na-zdrowie-meta.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9698284,zaskakujace-odkrycie-naukowcow-jak-szybki-chod-dziala-na-zdrowie-meta.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:36+00:00

None

## Węgierski azyl dla posła PiS: Szokująca decyzja Viktor Orbana
 - [https://forsal.pl/kraj/polityka/artykuly/9698282,wegierski-azyl-dla-posla-pis-szokujaca-decyzja-viktor-orbana.html](https://forsal.pl/kraj/polityka/artykuly/9698282,wegierski-azyl-dla-posla-pis-szokujaca-decyzja-viktor-orbana.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:32+00:00

None

## Elon Musk i Donald Trump kontra Kongres: Jak najbogatszy człowiek świata wpłynął na decyzje polityczne?
 - [https://forsal.pl/swiat/usa/artykuly/9698280,elon-musk-i-donald-trump-kontra-kongres-jak-najbogatszy-czlowiek-swia.html](https://forsal.pl/swiat/usa/artykuly/9698280,elon-musk-i-donald-trump-kontra-kongres-jak-najbogatszy-czlowiek-swia.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:23+00:00

None

## Narkotyki i broń na polskim statku do Maroka. Czy to kolejne działanie kartelu?
 - [https://forsal.pl/transport/artykuly/9698275,narkotyki-i-bron-na-polskim-statku-do-maroka-czy-to-kolejne-dzialanie.html](https://forsal.pl/transport/artykuly/9698275,narkotyki-i-bron-na-polskim-statku-do-maroka-czy-to-kolejne-dzialanie.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:14+00:00

None

## Świąteczne wydatki Polaków 2024: Co wpłynęło na wzrost o 4. proc. w zakupach prezentów?
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9698272,swiateczne-wydatki-polakow-2024-co-wplynelo-na-wzrost-o-4-proc-w-za.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9698272,swiateczne-wydatki-polakow-2024-co-wplynelo-na-wzrost-o-4-proc-w-za.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:11:02+00:00

None

## Tajwan dziękuje USA za gwarancję bezpieczeństwa. Czy nowa transza uzbrojenia zmieni sytuację?
 - [https://forsal.pl/swiat/usa/artykuly/9698270,tajwan-dziekuje-usa-za-gwarancje-bezpieczenstwa-czy-nowa-transza-uzbr.html](https://forsal.pl/swiat/usa/artykuly/9698270,tajwan-dziekuje-usa-za-gwarancje-bezpieczenstwa-czy-nowa-transza-uzbr.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:10:48+00:00

None

## MFW przekazuje Ukrainie kolejne 1,1 mld dolarów. Jak wygląda przyszłość ukraińskiej gospodarki?
 - [https://forsal.pl/swiat/ukraina/artykuly/9698268,mfw-przekazuje-ukrainie-kolejne-11-mld-dolarow-jak-wyglada-przyszlos.html](https://forsal.pl/swiat/ukraina/artykuly/9698268,mfw-przekazuje-ukrainie-kolejne-11-mld-dolarow-jak-wyglada-przyszlos.html)
 - RSS feed: $source
 - date published: 2024-12-21T07:10:46+00:00

None

## Rewolucja w kodeksie pracy gwarantowana przez rząd: dłuższe urlopy dla pięciu milionów pracowników, wyższe dodatki do wynagrodzeń i nagrody. Już teraz?
 - [https://forsal.pl/praca/aktualnosci/artykuly/9698170,rewolucja-w-kodeksie-pracy-gwarantowana-przez-rzad-dluzsze-urlopy-dla.html](https://forsal.pl/praca/aktualnosci/artykuly/9698170,rewolucja-w-kodeksie-pracy-gwarantowana-przez-rzad-dluzsze-urlopy-dla.html)
 - RSS feed: $source
 - date published: 2024-12-21T06:29:43+00:00

None

## Tunele, estakada i trzy pasy ruchu. Nowa ekspresówka S7 już gotowa. Połączy Kraków, Świętokrzyskie i Warszawę. Podali termin oddania trasy
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9698113,tunele-estakada-i-trzy-pasy-ruchu-nowa-ekspresowka-s7-juz-gotowa-po.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9698113,tunele-estakada-i-trzy-pasy-ruchu-nowa-ekspresowka-s7-juz-gotowa-po.html)
 - RSS feed: $source
 - date published: 2024-12-21T05:31:10+00:00

None

