# Source:The home for developers., URL:https://www.reddit.com/r/developer/.rss, language:en

## Feedback on my repo
 - [https://www.reddit.com/r/developer/comments/1hjeutd/feedback_on_my_repo](https://www.reddit.com/r/developer/comments/1hjeutd/feedback_on_my_repo)
 - RSS feed: $source
 - date published: 2024-12-21T17:40:42+00:00

<!-- SC_OFF --><div class="md"><p>As the title suggests, I need feedback on the projects in my GitHub repo. I started to learn how to code a year ago and decided to go to school for computer science because I realized there is a very small chance of landing a tech job without an education. Any feedback from any of the projects on there would be greatly appreciated, thanks in advance! </p> <p>Here is my repo: <a href="https://GitHub.com/nexustech101/">https://GitHub.com/nexustech101/</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Icy_Presentation9229"> /u/Icy_Presentation9229 </a> <br/> <span><a href="https://www.reddit.com/r/developer/comments/1hjeutd/feedback_on_my_repo/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/developer/comments/1hjeutd/feedback_on_my_repo/">[comments]</a></span>

## Seeking Guidance!🙏 Hi, I'm a mid-level product designer, as a sidequest, trying to build this chrome extension. How complicated this would be to code, and is it possible to learn code & build this in a short time or help me assist in finding a roadmap to build this alone or with a coder! TQIA❤️
 - [https://www.reddit.com/r/developer/comments/1hjanj0/seeking_guidance_hi_im_a_midlevel_product](https://www.reddit.com/r/developer/comments/1hjanj0/seeking_guidance_hi_im_a_midlevel_product)
 - RSS feed: $source
 - date published: 2024-12-21T14:14:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/developer/comments/1hjanj0/seeking_guidance_hi_im_a_midlevel_product/"> <img src="https://b.thumbs.redditmedia.com/AdHvyeCe1ZUoV3drZeeOdAuVXY0cbfqyP-506wDkllE.jpg" alt="Seeking Guidance!🙏 Hi, I'm a mid-level product designer, as a sidequest, trying to build this chrome extension. How complicated this would be to code, and is it possible to learn code &amp; build this in a short time or help me assist in finding a roadmap to build this alone or with a coder! TQIA❤️" title="Seeking Guidance!🙏 Hi, I'm a mid-level product designer, as a sidequest, trying to build this chrome extension. How complicated this would be to code, and is it possible to learn code &amp; build this in a short time or help me assist in finding a roadmap to build this alone or with a coder! TQIA❤️" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Killerblack47"> /u/Killerblack47 </a> <br/> <span><a href="https://www.reddit.com/gallery

## [Giveaway] Cozy game of your choice for Christmas!
 - [https://www.reddit.com/r/developer/comments/1hjani5/giveaway_cozy_game_of_your_choice_for_christmas](https://www.reddit.com/r/developer/comments/1hjani5/giveaway_cozy_game_of_your_choice_for_christmas)
 - RSS feed: $source
 - date published: 2024-12-21T14:14:11+00:00

<!-- SC_OFF --><div class="md"><p>Some of us are old geezers and might not get anything special for Christmas. So we thought we would do something special on the subreddit.</p> <p>To celebrate Christmas, we&#39;re giving away seven cozy games as requested by this subreddit. </p> <ol> <li><strong>Comment a cozy game</strong></li> <li><strong>Vote for games you want (comments).</strong></li> </ol> <p>We&#39;ll be picking reasonably affordable cozy Steam PC games based on replies to this thread and a few like it. We need as many suggestions as possible so we might post a few times.</p> <p><a href="https://p1games.com/cozy-game-giveaway">Enter the giveaway here</a>.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AutoModerator"> /u/AutoModerator </a> <br/> <span><a href="https://www.reddit.com/r/developer/comments/1hjani5/giveaway_cozy_game_of_your_choice_for_christmas/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/developer/comme

