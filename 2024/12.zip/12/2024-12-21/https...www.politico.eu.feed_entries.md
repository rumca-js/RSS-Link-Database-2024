# Source:POLITICO, URL:https://www.politico.eu/feed, language:en-US

## Slovakia profiting from war with Russian gas transit gambit, Kyiv charges
 - [https://www.politico.eu/article/slovakia-profiting-from-war-with-russian-gas-transit-gambit-kyiv-blasts/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/slovakia-profiting-from-war-with-russian-gas-transit-gambit-kyiv-blasts/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: $source
 - date published: 2024-12-21T21:21:51+00:00

Slovakian Prime Minister Robert Fico's fears for energy security are unfounded, senior Ukrainian official tells POLITICO.

## Report ties Romanian liberals to TikTok campaign that fueled pro-Russia candidate
 - [https://www.politico.eu/article/investigation-ties-romanian-liberals-tiktok-campaign-pro-russia-candidate-calin-georgescu/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/investigation-ties-romanian-liberals-tiktok-campaign-pro-russia-candidate-calin-georgescu/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: $source
 - date published: 2024-12-21T16:36:06+00:00

A campaign from a governing center-right party may have been hijacked to benefit far-right candidate Călin Georgescu, snoop.ro report shows.

## ‘Insane’ Magdeburg Christmas market attack turns up heat on Germany’s politicians
 - [https://www.politico.eu/article/insane-magdeburg-christmas-market-attack-germany-politicians-islamophobia-far-right/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/insane-magdeburg-christmas-market-attack-germany-politicians-islamophobia-far-right/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: $source
 - date published: 2024-12-21T16:17:12+00:00

Reports that suspect was a refugee from Saudi Arabia who hated Muslims raises complicated questions during German election campaign.

## German troops must be ‘fit’ for war if Putin attacks, Defense Minister Pistorius says
 - [https://www.politico.eu/article/german-army-must-be-ready-for-war-if-putin-attacks-defense-pistorius-says-deficit-debt-brake-conflict/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/german-army-must-be-ready-for-war-if-putin-attacks-defense-pistorius-says-deficit-debt-brake-conflict/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: $source
 - date published: 2024-12-21T14:54:32+00:00

Pistorius wants a reform of Germany's debt brake to allow for more military spending.

## Trump reportedly wants NATO members to boost defense spending to 5 percent of GDP
 - [https://www.politico.eu/article/reports-donald-trump-nato-members-increase-defence-spending/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/reports-donald-trump-nato-members-increase-defence-spending/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: $source
 - date published: 2024-12-21T12:07:27+00:00

Trump's request would involve more than doubling NATO's current spending target.

## World’s cartoonists on this week’s events
 - [https://www.politico.eu/article/worlds-cartoonists-on-this-weeks-events-139/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication](https://www.politico.eu/article/worlds-cartoonists-on-this-weeks-events-139/?utm_source=RSS_Feed&utm_medium=RSS&utm_campaign=RSS_Syndication)
 - RSS feed: $source
 - date published: 2024-12-21T03:01:00+00:00

Drawing the top stories around the globe.

