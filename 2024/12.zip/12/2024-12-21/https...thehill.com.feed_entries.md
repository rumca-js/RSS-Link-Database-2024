# Source:The Hill News, URL:https://thehill.com/feed, language:en-US

## How AI can close America’s trillion dollar tax gap
 - [https://thehill.com/opinion/technology/5050637-tax-gap-iris-modernization](https://thehill.com/opinion/technology/5050637-tax-gap-iris-modernization)
 - RSS feed: $source
 - date published: 2024-12-21T18:00:00+00:00

Closing the tax gap requires a tech-first approach, with human intervention focused on the most complex cases.

