# Source:Daily sceptic, URL:https://dailysceptic.org/feed, language:en-US

## Former Mermaids Chief Vows to Defy Puberty Blocker Ban at New Trans Clinic
 - [https://dailysceptic.org/2024/12/21/former-mermaids-chief-vows-to-defy-puberty-blocker-ban-at-new-trans-clinic](https://dailysceptic.org/2024/12/21/former-mermaids-chief-vows-to-defy-puberty-blocker-ban-at-new-trans-clinic)
 - RSS feed: $source
 - date published: 2024-12-21T15:00:00+00:00

<p>A former Chief Executive of the charity Mermaids, Susie Green, has vowed to defy the nationwide ban on puberty blockers at her new trans clinic by importing the drugs via the EU.</p>
<p>The post <a href="https://dailysceptic.org/2024/12/21/former-mermaids-chief-vows-to-defy-puberty-blocker-ban-at-new-trans-clinic/">Former Mermaids Chief Vows to Defy Puberty Blocker Ban at New Trans Clinic</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Majority of Brits Receive More in Benefits Than They Pay in Taxes
 - [https://dailysceptic.org/2024/12/21/majority-of-brits-receive-more-in-benefits-than-they-pay-in-taxes](https://dailysceptic.org/2024/12/21/majority-of-brits-receive-more-in-benefits-than-they-pay-in-taxes)
 - RSS feed: $source
 - date published: 2024-12-21T13:00:00+00:00

<p>More than half of people in the U.K. receive more in benefits than they contribute in taxes, official figures show – and it's only going to get worse. No wonder we can't afford anything.</p>
<p>The post <a href="https://dailysceptic.org/2024/12/21/majority-of-brits-receive-more-in-benefits-than-they-pay-in-taxes/">Majority of Brits Receive More in Benefits Than They Pay in Taxes</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## In Latest Threat to German Democracy, Dangerous Fascist Elon Musk Tweets Six Words About Alternative für Deutschland
 - [https://dailysceptic.org/2024/12/21/in-latest-threat-to-german-democracy-dangerous-fascist-elon-musk-tweets-six-words-about-alternative-fur-deutschland](https://dailysceptic.org/2024/12/21/in-latest-threat-to-german-democracy-dangerous-fascist-elon-musk-tweets-six-words-about-alternative-fur-deutschland)
 - RSS feed: $source
 - date published: 2024-12-21T11:00:00+00:00

<p>German democracy, which is somehow shaken to its foundations whenever anybody holds a TV debate with the wrong person, is once again on life support after Elon Musk tweeted support for AfD, says Eugyppius.</p>
<p>The post <a href="https://dailysceptic.org/2024/12/21/in-latest-threat-to-german-democracy-dangerous-fascist-elon-musk-tweets-six-words-about-alternative-fur-deutschland/">In Latest Threat to German Democracy, Dangerous Fascist Elon Musk Tweets Six Words About Alternative für Deutschland</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## Minutes of Meetings Where Chris Whitty Overruled Government Vaccine Advisers to Force Through Covid Vaccination of Children Released
 - [https://dailysceptic.org/2024/12/21/minutes-of-meetings-where-chris-whitty-overruled-government-vaccine-advisers-to-force-through-covid-vaccination-of-children-released](https://dailysceptic.org/2024/12/21/minutes-of-meetings-where-chris-whitty-overruled-government-vaccine-advisers-to-force-through-covid-vaccination-of-children-released)
 - RSS feed: $source
 - date published: 2024-12-21T09:00:00+00:00

<p>Minutes of key meetings held in September 2021 in which Chris Whitty and the UK CMOs overruled the Government's vaccine advisers to push through Covid vaccination of children have been released – and they're damning.</p>
<p>The post <a href="https://dailysceptic.org/2024/12/21/minutes-of-meetings-where-chris-whitty-overruled-government-vaccine-advisers-to-force-through-covid-vaccination-of-children-released/">Minutes of Meetings Where Chris Whitty Overruled Government Vaccine Advisers to Force Through Covid Vaccination of Children Released</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## To Manifest a Crisis
 - [https://dailysceptic.org/2024/12/21/to-manifest-a-crisis](https://dailysceptic.org/2024/12/21/to-manifest-a-crisis)
 - RSS feed: $source
 - date published: 2024-12-21T07:00:00+00:00

<p>The word of the year is "Manifest", says the Cambridge Dictionary. What does it mean? Here's an example, says Prof James Alexander: public health busybodies were 'manifesting' when they confected the Covid 'pandemic'.</p>
<p>The post <a href="https://dailysceptic.org/2024/12/21/to-manifest-a-crisis/">To Manifest a Crisis</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

## News Round-Up
 - [https://dailysceptic.org/2024/12/21/news-round-up-1379](https://dailysceptic.org/2024/12/21/news-round-up-1379)
 - RSS feed: $source
 - date published: 2024-12-21T02:45:19+00:00

<p>A summary of the most interesting stories in the past 24 hours that challenge the prevailing orthodoxy about the ‘climate emergency’, public health ‘crises’ and the supposed moral defects of Western civilisation.</p>
<p>The post <a href="https://dailysceptic.org/2024/12/21/news-round-up-1379/">News Round-Up</a> appeared first on <a href="https://dailysceptic.org">The Daily Sceptic</a>.</p>

