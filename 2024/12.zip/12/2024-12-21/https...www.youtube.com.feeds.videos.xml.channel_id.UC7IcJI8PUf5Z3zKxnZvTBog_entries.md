# Source:The School of Life, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7IcJI8PUf5Z3zKxnZvTBog, language:en-US

## Automatic writing #theschooloflife #animation #writing
 - [https://www.youtube.com/watch?v=spXZ0RS38-4](https://www.youtube.com/watch?v=spXZ0RS38-4)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:49+00:00

In order to accurately reflect what we truly think we may have to not to agonise about every word, not to go back and correct anything - and instead, just to write down everything that comes into our minds the very moment it does so.
Enjoying our Youtube videos? Get full access to all our audio content, videos, and thousands of thought-provoking articles, conversation cards and more with The School of Life Subscription: https://www.theschooloflife.com/the-school-of-life-youtube/?utm_source=youtube&utm_medium=description&utm_campaign=A%20Writing%20Exercise%20to%20Help%20You%20Meet%20Yourself


Learn, heal and grow. Get the best of The School of Life delivered straight to your inbox: https://www.theschooloflife.com/signup/?utm_source=youtube&utm_medium=description&utm_campaign=A%20Writing%20Exercise%20to%20Help%20You%20Meet%20Yourself

FURTHER READING

You can read more on this and other subjects in our articles, here: https://www.theschooloflife.com/article/why-we-should-practice-auto

