# Source:Reverse Engineering, URL:https://www.reddit.com/r/ReverseEngineering/.rss, language:

## Rules to avoid common extended in-line assembly mistakes
 - [https://www.reddit.com/r/ReverseEngineering/comments/1hjamj7/rules_to_avoid_common_extended_inline_assembly](https://www.reddit.com/r/ReverseEngineering/comments/1hjamj7/rules_to_avoid_common_extended_inline_assembly)
 - RSS feed: $source
 - date published: 2024-12-21T14:12:42+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/tnavda"> /u/tnavda </a> <br/> <span><a href="https://nullprogram.com/blog/2024/12/20/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/ReverseEngineering/comments/1hjamj7/rules_to_avoid_common_extended_inline_assembly/">[comments]</a></span>

