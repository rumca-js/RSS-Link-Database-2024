# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 HARD Horror Games That Will Make You Beg for Mercy
 - [https://www.youtube.com/watch?v=41WsJOypJ8o](https://www.youtube.com/watch?v=41WsJOypJ8o)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:02+00:00

We've got some scary games that are surprisingly challenging. 
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1     

0:00 Intro 
0:22 Number 10
2:27 Number 9
5:11 Number 8
7:36 Number 7
9:16 Number 6
11:02 Number 5
12:59 Number 4
14:07 Number 3
15:20 Number 2
17:50 Number 1 
20:22 Bonus

