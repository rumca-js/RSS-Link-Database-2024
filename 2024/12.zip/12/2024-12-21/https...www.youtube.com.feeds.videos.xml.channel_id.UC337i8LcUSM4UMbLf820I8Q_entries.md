# Source:Just Some Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q, language:en-US

## Superman Teaser Trailer: Superman Returns
 - [https://www.youtube.com/watch?v=KlK16tr_P3w](https://www.youtube.com/watch?v=KlK16tr_P3w)
 - RSS feed: $source
 - date published: 2024-12-21T06:00:11+00:00

Superman Teaser Trailer: Superman Returns
----------------------------------------------------------------------------------------------
Art and Animation by Just Some Guy

Original trailer concept: FMA Brotherhood & Black Summoner

Music: "Enkon Hakuchuumu" by Sakagami Souichi - Copyright (C) 2015 Trial & Error/Sakagami Souichi All rights reserved.

Trial & Error: http://www.tandess.com/en/music/

