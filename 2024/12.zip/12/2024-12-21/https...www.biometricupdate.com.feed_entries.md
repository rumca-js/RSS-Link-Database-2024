# Source:Biometric Update, URL:https://www.biometricupdate.com/feed, language:en-US

## Biometric authentication, mDLs, digital wallets and passkeys on the cusp
 - [https://www.biometricupdate.com/202412/biometric-authentication-mdls-digital-wallets-and-passkeys-on-the-cusp](https://www.biometricupdate.com/202412/biometric-authentication-mdls-digital-wallets-and-passkeys-on-the-cusp)
 - RSS feed: $source
 - date published: 2024-12-21T14:49:02+00:00

<img width="1280" height="714" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2024/10/11120710/Apple-Wallet-mDL.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" decoding="async" fetchpriority="high" srcset="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2024/10/11120710/Apple-Wallet-mDL.jpg 1280w, https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2024/10/11120710/Apple-Wallet-mDL-300x167.jpg 300w, https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2024/10/11120710/Apple-Wallet-mDL-1024x571.jpg 1024w, https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2024/10/11120710/Apple-Wallet-mDL-150x84.jpg 150w, https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2024/10/11120710/Apple-Wallet-mDL-768x428.jpg 768w" sizes="(max-width: 1280px) 100vw, 1280px" />
		Biometric authentication is a common factor in the digital identity trends of the week, the past year and possibly the next, as seen in the most-read articles 

## Concerns over the security of electronic personal health information intensifies
 - [https://www.biometricupdate.com/202412/concerns-over-the-security-of-electronic-personal-health-information-intensifies](https://www.biometricupdate.com/202412/concerns-over-the-security-of-electronic-personal-health-information-intensifies)
 - RSS feed: $source
 - date published: 2024-12-21T14:35:29+00:00

<img width="2048" height="1367" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/09/19172639/patient-digital-identity-scaled.jpg" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt="" decoding="async" fetchpriority="high" srcset="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/09/19172639/patient-digital-identity-scaled.jpg 2048w, https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/09/19172639/patient-digital-identity-300x200.jpg 300w, https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/09/19172639/patient-digital-identity-1024x684.jpg 1024w, https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/09/19172639/patient-digital-identity-150x100.jpg 150w, https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/09/19172639/patient-digital-identity-768x513.jpg 768w, https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/09/19172639/patient-digital-identity-1536x1025.jpg 1536w" sizes="(max-width: 204

