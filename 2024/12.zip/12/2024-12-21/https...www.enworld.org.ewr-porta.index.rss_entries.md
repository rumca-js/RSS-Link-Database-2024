# Source:EN World Tabletop RPG News & Reviews, URL:https://www.enworld.org/ewr-porta/index.rss, language:en

## Podcast 329 | 2025 TTRPGs, D&D Artificer, Pathfinder's Necromancer & Runesmith, Baby Goblins, Vegan Shoes
 - [https://www.enworld.org/threads/podcast-329-2025-ttrpgs-d-d-artificer-pathfinders-necromancer-runesmith-baby-goblins-vegan-shoes.709203](https://www.enworld.org/threads/podcast-329-2025-ttrpgs-d-d-artificer-pathfinders-necromancer-runesmith-baby-goblins-vegan-shoes.709203)
 - RSS feed: $source
 - date published: 2024-12-21T17:23:00+00:00

None

## Fairy Makes Offer Adventurers Can't Refuse
 - [https://www.enworld.org/threads/fairy-makes-offer-adventurers-cant-refuse.709224](https://www.enworld.org/threads/fairy-makes-offer-adventurers-cant-refuse.709224)
 - RSS feed: $source
 - date published: 2024-12-21T15:27:00+00:00

None

## You’ll Love The Hated Pretender As A First OSR Adventure
 - [https://www.enworld.org/threads/you%E2%80%99ll-love-the-hated-pretender-as-a-first-osr-adventure.709099](https://www.enworld.org/threads/you%E2%80%99ll-love-the-hated-pretender-as-a-first-osr-adventure.709099)
 - RSS feed: $source
 - date published: 2024-12-21T11:42:00+00:00

None

