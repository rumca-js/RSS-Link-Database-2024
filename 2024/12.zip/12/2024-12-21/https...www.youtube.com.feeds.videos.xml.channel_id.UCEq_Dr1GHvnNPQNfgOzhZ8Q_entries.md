# Source:Solid jj, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q, language:en-US

## The Justice League Saves Christmas
 - [https://www.youtube.com/watch?v=VGDGTE9gIUg](https://www.youtube.com/watch?v=VGDGTE9gIUg)
 - RSS feed: $source
 - date published: 2024-12-21T20:00:20+00:00

The Justice League celebrate the Holiday Season at the Hall of Justice when suddenly Santa Claus appears! He needs there help or else there might not be a Christmas this year! Also a small minor plot point that is lightly touched upon!

10% Gamer Supps (Code: SOLID) ▼
https://gamersupps.gg/SOLID

Art by @TheFrenchPineapple 

Twitch: https://twitch.tv/solidjj
Podcast: @JoeSchmoesPodcast 

Second channel:​⁠ ​⁠@Solidusjj 
Patreon: https://patreon.com/solidjj

