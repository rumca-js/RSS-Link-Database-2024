# Source:Russell Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Who’s Really Behind The Russian General Assassination?
 - [https://www.youtube.com/watch?v=NKIxZEFA1aI](https://www.youtube.com/watch?v=NKIxZEFA1aI)
 - RSS feed: $source
 - date published: 2024-12-21T16:33:45+00:00

Order today at http://www.1775coffee.com/BRAND - code BRAND  to save 15% off your order

Watch my new Locals series 'The Oracles' here: https://russellbrand.locals.com/upost/6159441/the-last-pandemic-and-the-next-pandemic

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

Watch my exclusive LIVE weekly special, “Break Bread”, get access to all of my interviews a week early, send in questions for me to respond to with guests, and more HERE: https://bit.ly/joinlocals

All links: https://linktr.ee/RussellBrand

