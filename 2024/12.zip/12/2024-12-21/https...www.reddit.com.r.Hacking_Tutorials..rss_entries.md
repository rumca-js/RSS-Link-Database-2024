# Source:A forum for the security professionals and white hat hackers., URL:https://www.reddit.com/r/Hacking_Tutorials/.rss, language:en

## Slowing down home internet through mobile device?
 - [https://www.reddit.com/r/Hacking_Tutorials/comments/1hjltvw/slowing_down_home_internet_through_mobile_device](https://www.reddit.com/r/Hacking_Tutorials/comments/1hjltvw/slowing_down_home_internet_through_mobile_device)
 - RSS feed: $source
 - date published: 2024-12-21T23:18:38+00:00

<!-- SC_OFF --><div class="md"><p>I just want to slow the home internet down because my dad&#39;s drunk and being annoying by blaming me for the barely stable internet despite only listening to music - I just want him to feel barely functional internet. At literal single digit bytes if possible. All I want to do is slow the internet down until I manually toggle it off. Are there any ways to do this, without draining my phone battery? (Optional, I could just get my charger if need be) (P.S. I am not a scripter or anything, please explain in simple terms)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/No_Ticket886"> /u/No_Ticket886 </a> <br/> <span><a href="https://www.reddit.com/r/Hacking_Tutorials/comments/1hjltvw/slowing_down_home_internet_through_mobile_device/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Hacking_Tutorials/comments/1hjltvw/slowing_down_home_internet_through_mobile_device/">[comments]</a></span>

## How do I fix this, Zphisher after i tried cloudflared
 - [https://www.reddit.com/r/Hacking_Tutorials/comments/1hji4pp/how_do_i_fix_this_zphisher_after_i_tried](https://www.reddit.com/r/Hacking_Tutorials/comments/1hji4pp/how_do_i_fix_this_zphisher_after_i_tried)
 - RSS feed: $source
 - date published: 2024-12-21T20:14:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Hacking_Tutorials/comments/1hji4pp/how_do_i_fix_this_zphisher_after_i_tried/"> <img src="https://preview.redd.it/ngcvqjlue98e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=2e6f33eb387082ceb23b286d6640c05afa8b05b6" alt="How do I fix this, Zphisher after i tried cloudflared" title="How do I fix this, Zphisher after i tried cloudflared" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ComplaintKlutzy3497"> /u/ComplaintKlutzy3497 </a> <br/> <span><a href="https://i.redd.it/ngcvqjlue98e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Hacking_Tutorials/comments/1hji4pp/how_do_i_fix_this_zphisher_after_i_tried/">[comments]</a></span> </td></tr></table>

## Change IMEI of TP-Link MR600
 - [https://www.reddit.com/r/Hacking_Tutorials/comments/1hjfffs/change_imei_of_tplink_mr600](https://www.reddit.com/r/Hacking_Tutorials/comments/1hjfffs/change_imei_of_tplink_mr600)
 - RSS feed: $source
 - date published: 2024-12-21T18:06:41+00:00

<!-- SC_OFF --><div class="md"><p>Does anybody know how to change the IMEI of the device? </p> <p>Any help would be greatly appreciated.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/tnf02"> /u/tnf02 </a> <br/> <span><a href="https://www.reddit.com/r/Hacking_Tutorials/comments/1hjfffs/change_imei_of_tplink_mr600/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Hacking_Tutorials/comments/1hjfffs/change_imei_of_tplink_mr600/">[comments]</a></span>

## Saturday Hacker Day - What are you hacking this week?
 - [https://www.reddit.com/r/Hacking_Tutorials/comments/1hjaksr/saturday_hacker_day_what_are_you_hacking_this_week](https://www.reddit.com/r/Hacking_Tutorials/comments/1hjaksr/saturday_hacker_day_what_are_you_hacking_this_week)
 - RSS feed: $source
 - date published: 2024-12-21T14:10:09+00:00

<!-- SC_OFF --><div class="md"><p>Weekly forum post: Let&#39;s discuss current projects, concepts, questions and collaborations. In other words, what are you hacking this week?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/happytrailz1938"> /u/happytrailz1938 </a> <br/> <span><a href="https://www.reddit.com/r/Hacking_Tutorials/comments/1hjaksr/saturday_hacker_day_what_are_you_hacking_this_week/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Hacking_Tutorials/comments/1hjaksr/saturday_hacker_day_what_are_you_hacking_this_week/">[comments]</a></span>

