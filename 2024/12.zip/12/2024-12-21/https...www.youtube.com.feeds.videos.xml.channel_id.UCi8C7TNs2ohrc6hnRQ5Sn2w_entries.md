# Source:Programmers are also human, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8C7TNs2ohrc6hnRQ5Sn2w, language:en-US

## 80s Guy Roasting Computers
 - [https://www.youtube.com/watch?v=l-BhrRlT-0Q](https://www.youtube.com/watch?v=l-BhrRlT-0Q)
 - RSS feed: $source
 - date published: 2024-12-21T13:52:41+00:00

C64, Atari, Apple II, Sinclair, TRS-80

programming humor
programming memes
computer humor

