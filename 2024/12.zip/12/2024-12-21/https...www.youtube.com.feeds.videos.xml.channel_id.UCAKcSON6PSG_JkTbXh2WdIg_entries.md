# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Exene Cervenka gives a potted history of the band X #artistinterview #history
 - [https://www.youtube.com/watch?v=OCrMRdCPlKk](https://www.youtube.com/watch?v=OCrMRdCPlKk)
 - RSS feed: $source
 - date published: 2024-12-21T14:30:16+00:00

John Doe and Exene Cervenka are interviewed at The Current
Support The Current: https://support.mpr.org/youtube  

During a recent visit to The Current studio, Exene Cervenka of the legendary Los Angeles band X explained how the band got its start. 

Credits
Guests – John Doe and Exene Cervenka of @XthebandLosAngeles 
Host – Jessica Paxton
Producer – Derrick Stevens
Audio Engineer – Evan Clark
Video Director – Eric Xu Romani
Camera Operators – Eric Xu Romani, D’Vir Rudin
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://www.instagram.com/thecurrent/
https://www.threads.net/@thecurrent
https://www.tiktok.com/@thecurrent.org

@fat_possum Records

#interview #shorts

