# Source:BBC Latin America News, URL:https://feeds.bbci.co.uk/news/world/latin_america/rss.xml, language:en-gb

## Watch: Relatives of inmates attempt to break into Mexican prison
 - [https://www.bbc.com/news/videos/cgj6d89w0ndo](https://www.bbc.com/news/videos/cgj6d89w0ndo)
 - RSS feed: $source
 - date published: 2024-12-21T00:12:35+00:00

The BBC's Will Grant looks at unrest in which seven people died, leading to family members attempting to break inside to check on their relatives.

