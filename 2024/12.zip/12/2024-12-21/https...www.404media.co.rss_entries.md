# Source:404 Media, URL:https://www.404media.co/rss, language:en

## Disney Princesses Are at Risk of Rabies and Fatal Maulings
 - [https://www.404media.co/disney-princesses-are-at-risk-of-rabies-and-fatal-maulings-3](https://www.404media.co/disney-princesses-are-at-risk-of-rabies-and-fatal-maulings-3)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:38+00:00

This week, the creature from the Pangean lagoon, casket shopping for Disney princesses, a horror show in ancient Somerset, and “Martifacts.”

