# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Producenci leków pompują coraz więcej pieniędzy w organizacje pacjentów. To może mieć złe skutki
 - [https://fakty.tvn24.pl/zobacz-fakty/producenci-lekow-pompuja-coraz-wiecej-pieniedzy-w-organizacje-pacjentow-to-moze-miec-zle-skutki-st8232454?source=rss](https://fakty.tvn24.pl/zobacz-fakty/producenci-lekow-pompuja-coraz-wiecej-pieniedzy-w-organizacje-pacjentow-to-moze-miec-zle-skutki-st8232454?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T20:40:39+00:00

<img src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-7770901-apteka-004226-ph8232477/alternates/LANDSCAPE_1280" alt="Producenci leków pompują coraz więcej pieniędzy w organizacje pacjentów. To może mieć złe skutki" />
    Prawie 20 milionów euro w ciągu 10 lat przelały firmy farmaceutyczne na konta organizacji pacjentów w Polsce. Według ustaleń polskich naukowców sumy wciąż rosną - to potencjalnie groźne dla niezależności tych organizacji, bo czy te firmy płacą im bezinteresownie?

## Najkrótszy dzień roku. Tłumy zebrały się w Stonehenge
 - [https://tvn24.pl/tvnmeteo/ciekawostki/najkrotszy-dzien-roku-tlumy-zebraly-sie-w-stonehenge-st8232449?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/najkrotszy-dzien-roku-tlumy-zebraly-sie-w-stonehenge-st8232449?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T20:06:05+00:00

<img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8447312-tlumy-ludzi-swietowaly-przesilenie-zimowe-w-brytyjskim-stonehenge-ph8232463/alternates/LANDSCAPE_1280" alt="Najkrótszy dzień roku. Tłumy zebrały się w Stonehenge" />
    Tysiące osób świętowały w sobotę o świcie przesilenie zimowe, czyli moment rozpoczęcia astronomicznej zimy i zarazem najkrótszy dzień roku na półkuli północnej, na stanowisku archeologicznym Stonehenge w Wielkiej Brytanii.

## Kalisz o szefie PKW: nie ze mną te numery
 - [https://tvn24.pl/polska/kalisz-o-szefie-pkw-nie-ze-mna-te-numery-st8232398?source=rss](https://tvn24.pl/polska/kalisz-o-szefie-pkw-nie-ze-mna-te-numery-st8232398?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:35:50+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7615246-fpf-ph8232391/alternates/LANDSCAPE_1280" alt="Kalisz o szefie PKW: nie ze mną te numery" />
    Przewodniczący PKW sędzia Sylwester Marciniak uznaje Izbę Kontroli Nadzwyczajnej Sądu Najwyższego. To widać po jego głosowaniu. On nawet chce nas zmusić do tego, żebyśmy my ją uznali. Nie ze mną te numery - powiedział w "Faktach po Faktach" mecenas Ryszard Kalisz, członek Państwowej Komisji Wyborczej. Jak mówił, Marciniak chce, aby członkowie PKW podjęli uchwałę w sprawie sprawozdania komitetu wyborczego PiS, którą w poniedziałek odroczono. Kalisz ujawnił, że szef Komisji próbuje wprowadzać ją tylnymi drzwiami. - Ja się trzymam prawomocnej uchwały PKW z poniedziałku - oświadczył.

## Wleciała do domu i usiadła na choince. "Zobaczyłam wielką sowę"
 - [https://tvn24.pl/tvnmeteo/ciekawostki/wleciala-do-domu-i-usiadla-na-choince-zobaczylam-wielka-sowe-st8232425?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/wleciala-do-domu-i-usiadla-na-choince-zobaczylam-wielka-sowe-st8232425?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:23:40+00:00

<img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-595790-sowa-na-choince-ph8231974/alternates/LANDSCAPE_1280" alt="Wleciała do domu i usiadła na choince. "Zobaczyłam wielką sowę"" />
    Do pewnej rodziny z amerykańskiego stanu Wirginia zawitał niespodziewany gość. Do domu przez komin wleciała sowa, która usiadła na szczycie choinki. Jej przegonienie nie było łatwe.

## Na przejściu dla pieszych została potrącona 10-letnia dziewczynka. Trafiła do szpitala
 - [https://tvn24.pl/polska/na-przejsciu-dla-pieszych-zostala-potracona-10-letnia-dziewczynka-trafila-do-szpitala-st8232411?source=rss](https://tvn24.pl/polska/na-przejsciu-dla-pieszych-zostala-potracona-10-letnia-dziewczynka-trafila-do-szpitala-st8232411?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:19:24+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1839319-miejsce-potracenia-10-letniej-dziewczynki-brzesko-21-12-2024-r-ph8232421/alternates/LANDSCAPE_1280" alt="Na przejściu dla pieszych została potrącona 10-letnia dziewczynka. Trafiła do szpitala" />
    Jak informuje rzeczniczka prasowa policji w Brzesku asp. sztab. Ewelina Buda, w sobotę na oświetlonym przejściu dla pieszych została potrącona 10-letnia dziewczynka. Dziecko trafiło do szpitala, a razem z nim jego matka, która została zahaczona przez lusterko pojazdu.

## Objawy złamania kręgosłupa mogą nie być takie oczywiste. Jak dziecko mówi, że go bolą plecy, to warto to zbadać
 - [https://fakty.tvn24.pl/fakty-po-poludniu/objawy-zlamania-kregoslupa-moga-nie-byc-takie-oczywiste-jak-dziecko-mowi-ze-go-bola-plecy-to-warto-to-zbadac-st8232317?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/objawy-zlamania-kregoslupa-moga-nie-byc-takie-oczywiste-jak-dziecko-mowi-ze-go-bola-plecy-to-warto-to-zbadac-st8232317?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:00:44+00:00

<img src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-9755158-objawy-zlamania-kregoslupa-moga-nie-byc-takie-oczywiste-jak-dziecko-mowi-ze-go-bola-plecy-to-warto-to-zbadac-ph8232417/alternates/LANDSCAPE_1280" alt="Objawy złamania kręgosłupa mogą nie być takie oczywiste. Jak dziecko mówi, że go bolą plecy, to warto to zbadać" />
    Zbliża się koniec roku. Pora na podsumowanie najważniejszych, najbardziej interesujących tematów, którymi zajmowali się nasi reporterzy w "Faktach po Południu" TVN24. Wśród nich jest zdrowie, a dokładnie nasze kręgosłupy i ich złamania. Zdarza się, że objawy takiego urazu nie są oczywiste i nie zawsze do rozpoznania na pierwszy rzut oka. Kogo dotykają najczęściej i jak wygląda diagnostyka?

## Wielki mufti wzywa do walki z Rosjanami
 - [https://tvn24.pl/swiat/libia-wielki-mufti-wzywa-do-walki-z-rosjanami-st8232373?source=rss](https://tvn24.pl/swiat/libia-wielki-mufti-wzywa-do-walki-z-rosjanami-st8232373?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T18:49:51+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2599319-grupa-wagnera-ph8021150/alternates/LANDSCAPE_1280" alt="Wielki mufti wzywa do walki z Rosjanami    " />
    Wielki mufti Libii, szejk Sadik al-Ghariani wezwał w piątek wszystkich Libijczyków do zjednoczenia się i walki z Rosjanami, którzy przybyli do wschodniej części kraju z Syrii, skąd uciekli po obaleniu reżimu Baszara el-Asada.

## Udaremniono zamach na prezydenta. "Spisek obejmował użycie czarów"
 - [https://tvn24.pl/swiat/zambia-udaremniono-zamach-na-prezydenta-spisek-obejmowal-uzycie-czarow-st8232330?source=rss](https://tvn24.pl/swiat/zambia-udaremniono-zamach-na-prezydenta-spisek-obejmowal-uzycie-czarow-st8232330?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T18:11:12+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8161766-hakainde-hichilema-ph8232329/alternates/LANDSCAPE_1280" alt="Udaremniono zamach na prezydenta. "Spisek obejmował użycie czarów"" />
    W Zambii aresztowano dwóch mężczyzn oskarżonych o próbę rzucenia uroku na prezydenta. Przy podejrzanych znaleziono amulety oraz żywego kameleona. "Spisek obejmował użycie czarów w celu skrzywdzenia prezydenta" - poinformował rzecznik policji.

## Ponad trzydzieści osób zginęło w zderzeniu autobusu i ciężarówki w Brazylii
 - [https://tvn24.pl/swiat/ponad-trzydziesci-osob-zginelo-w-zderzeniu-autobusu-i-ciezarowki-w-brazylii-st8232372?source=rss](https://tvn24.pl/swiat/ponad-trzydziesci-osob-zginelo-w-zderzeniu-autobusu-i-ciezarowki-w-brazylii-st8232372?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T17:59:54+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6156343-strazacy-na-miejscu-wypadku-teofilo-otoni-w-stanie-minas-gerais-w-brazylii-21-12-2024-r-ph8232331/alternates/LANDSCAPE_1280" alt="Ponad trzydzieści osób zginęło w zderzeniu autobusu i ciężarówki w Brazylii" />
    Trzydzieści dwie osoby zginęły w sobotę na południowym wschodzie Brazylii w wyniku zderzenia autobusu pełnego pasażerów z ciężarówką - poinformowała straż pożarna. W autobusie wiozącym 45 pasażerów pękła opona i kierowca stracił panowanie nad pojazdem.

## Pogoda na jutro - niedziela 22.12. Deszczowo i wietrznie
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-niedziela-22-12-deszczowo-i-wietrznie-st8232345?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-niedziela-22-12-deszczowo-i-wietrznie-st8232345?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T17:58:35+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3vchax-deszcz-7781506/alternates/LANDSCAPE_1280" alt="Pogoda na jutro - niedziela 22.12. Deszczowo i wietrznie" />
    Pogoda w niedzielę będzie jesienna i nieprzyjemna. W wielu miejscach czekają nas opady deszczu, a dodatkowo wiatr w porywach mocno się rozpędzi. Termometry wskażą od 2 do 7 stopni Celsjusza.

## Dziesięć osób zginęło zadeptanych przez tłum na imprezie charytatywnej
 - [https://tvn24.pl/swiat/dziesiec-osob-zginelo-zadeptanych-przez-tlum-na-imprezie-charytatywnej-st8232313?source=rss](https://tvn24.pl/swiat/dziesiec-osob-zginelo-zadeptanych-przez-tlum-na-imprezie-charytatywnej-st8232313?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T17:11:48+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7362992-paczki-z-artykulami-pierwszej-potrzeby-sa-rozdawane-ubogim-w-lagos-nigeria-21-12-2024-r-ph8232302/alternates/LANDSCAPE_1280" alt="Dziesięć osób zginęło zadeptanych przez tłum na imprezie charytatywnej" />
    Dziesięć osób, w tym czworo dzieci, zginęło zadeptanych przez tłum w stolicy Nigerii Abudży na świątecznej imprezie charytatywnej w miejscowym kościele, gdzie rozdawano żywność - poinformowała w sobotę rzeczniczka policji Josephine Adeh w swoim oświadczeniu. To już kolejny podobny przypadek w Nigerii w ciągu tygodnia.

## Cała Polska na czerwono. "Jest tendencja"
 - [https://tvn24.pl/tvnmeteo/pogoda/cala-polska-na-czerwono-jest-tendencja-st8232288?source=rss](https://tvn24.pl/tvnmeteo/pogoda/cala-polska-na-czerwono-jest-tendencja-st8232288?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T16:39:14+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4372547-untitled-4-ph8232305/alternates/LANDSCAPE_1280" alt="Cała Polska na czerwono. "Jest tendencja"" />
    Pierwszy dzień astronomicznej zimy nie jest w tym roku rekordowo ciepły, ale jak zaznaczyła synoptyczka IMGW Ewa Łapińska, jest tendencja do tego, że temperatura w tym okresie jest coraz wyższa. Po odwilży w tym tygodniu śnieg w górach zdążył już spaść, ale i tak jest go mało. W Zakopanem w sobotę leżały cztery centymetry białego puchu.

## Pijani rodzice pogryźli interweniujących  policjantów
 - [https://tvn24.pl/lublin/lublin-pijane-malzenstwo-pogryzlo-policjantow-mieli-pod-opieka-troje-dzieci-st8232055?source=rss](https://tvn24.pl/lublin/lublin-pijane-malzenstwo-pogryzlo-policjantow-mieli-pod-opieka-troje-dzieci-st8232055?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:50:00+00:00

<img src="https://tvn24.pl/lublin/cdn-zdjecie-5702996-pijane-malzenstwo-pogryzlo-policjantow-mieli-pod-opieka-troje-dzieci-ph8232250/alternates/LANDSCAPE_1280" alt="Pijani rodzice pogryźli interweniujących  policjantów" />
    Pijani rodzice, którzy "opiekowali się" trójką dzieci, pogryźli interweniujących policjantów. Odpowiedzą za narażenie nieletnich na niebezpieczeństwo oraz za naruszenie nietykalności mundurowych.

## "Prosimy nie gubić choinek na drogach"
 - [https://tvn24.pl/lublin/lublin-s19-prosimy-nie-gubic-choinek-na-drogach-st8232201?source=rss](https://tvn24.pl/lublin/lublin-s19-prosimy-nie-gubic-choinek-na-drogach-st8232201?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:00:00+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-163413-na-eksprsowce-zgubil-choinke-ph8232143/alternates/LANDSCAPE_1280" alt=""Prosimy nie gubić choinek na drogach"" />
    Niebezpieczna sytuacja na drodze ekspresowej S19. Na pasie dla skręcających w prawo leżała choinka, która wypadła z samochodu przewożącego świąteczne drzewka. "Rozumiemy, że święta, pośpiech... Mimo to prosimy nie gubić choinek na drogach. To bardzo niebezpieczne" - skomentowała zdarzenie GDDKiA i pokazała nagranie.

## Musk ostro o Scholzu. "Niekompetentny głupiec"
 - [https://tvn24.pl/najnowsze/elon-musk-wzywa-olafa-scholza-do-dymisji-po-tragedii-w-magdeburgu-niekompetentny-glupiec-st8232231?source=rss](https://tvn24.pl/najnowsze/elon-musk-wzywa-olafa-scholza-do-dymisji-po-tragedii-w-magdeburgu-niekompetentny-glupiec-st8232231?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:55:42+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-mgqfrd-elon-musk-7883936/alternates/LANDSCAPE_1280" alt="Musk ostro o Scholzu. "Niekompetentny głupiec"" />
    Elon Musk wezwał w piątek kanclerza Niemiec Olafa Scholza do dymisji i nazwał go "niekompetentnym głupcem". Był to komentarz miliardera do wątku dotyczącego zamachu na jarmarku świątecznym w Magdeburgu.

## Branża zanika. "To wszystko jest już chińskie"
 - [https://tvn24.pl/biznes/z-kraju/boze-narodzenie-2024-branza-zanika-to-wszystko-jest-juz-chinskie-st8232044?source=rss](https://tvn24.pl/biznes/z-kraju/boze-narodzenie-2024-branza-zanika-to-wszystko-jest-juz-chinskie-st8232044?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:52:58+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8914600-shutterstock-2538076617-ph8232238/alternates/LANDSCAPE_1280" alt="Branża zanika. "To wszystko jest już chińskie"" />
    Sztuka ręcznej produkcji oraz zdobienia bombek powoli zanika - stwierdził Zbigniew Bartuzi, szef firmy produkującej bombki choinkowe Szkła-Dekor. Dodał, że "rynek i sieci handlowe zostały zdominowane przez ozdoby z Chin".

## W zemście za decyzję urzędników rozpylał gaz w starostwie
 - [https://tvn24.pl/opole/strzelce-opolskie-z-zemsty-rozpylal-gaz-w-budynku-starostwa-ewakuowano-70-osob-st8232202?source=rss](https://tvn24.pl/opole/strzelce-opolskie-z-zemsty-rozpylal-gaz-w-budynku-starostwa-ewakuowano-70-osob-st8232202?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:00+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3641575-rozpylal-gaz-w-budynku-starostwa-powiatoweg-w-strzelcach-opolskich-ph8232220/alternates/LANDSCAPE_1280" alt="W zemście za decyzję urzędników rozpylał gaz w starostwie" />
    Zatrzymano 49-latka, który w budynku Starostwa Powiatowego w Strzelcach Opolskich rozpylał gaz. Ewakuowano około 70 osób. Jedna z poparzeniami krtani i dróg oddechowych trafiła do szpitala.

## W Wigilię "warunki w tej części kraju będą bardzo trudne". Najnowsza prognoza na święta Bożego Narodzenia
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-boze-narodzenie-2024-w-wigilie-w-tej-czesci-kraju-warunki-beda-bardzo-trudne-najnowsza-prognoza-na-swieta-st8232059?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-boze-narodzenie-2024-w-wigilie-w-tej-czesci-kraju-warunki-beda-bardzo-trudne-najnowsza-prognoza-na-swieta-st8232059?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:27:19+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-244849-swieta-boze-narodzenie-snieg-pogoda-ph8232154/alternates/LANDSCAPE_1280" alt="W Wigilię "warunki w tej części kraju będą bardzo trudne". Najnowsza prognoza na święta Bożego Narodzenia" />
    Pogoda na Boże Narodzenie. W święta aurę w Polsce ma kształtować silny i stabilny wyż. Czeka nas ochłodzenie. Ale czy ośrodek wysokiego ciśnienia przyniesie nam białe święta? Sprawdź w naszej najnowszej prognozie, czy gdzie pojawi się szansa na śnieg.

## Policyjny śmigłowiec na "emeryturę" trafił do muzeum
 - [https://tvn24.pl/wroclaw/wroclaw-smiglowiec-mi-2-trafil-do-muzeum-st8232069?source=rss](https://tvn24.pl/wroclaw/wroclaw-smiglowiec-mi-2-trafil-do-muzeum-st8232069?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:45:56+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9344069-policyjny-smiglowiec-mi-2-trafil-do-muzeum-ph8232101/alternates/LANDSCAPE_1280" alt="Policyjny śmigłowiec na "emeryturę" trafił do muzeum" />
    Policyjny śmigłowiec Mi-2 przeszedł na "emeryturę" i trafił do Muzeum Lotnictwa Polskiego w Krakowie. W Komendzie Wojewódzkiej Policji we Wrocławiu służył od 2009 do sierpnia 2020 roku. W powietrzu spędził łącznie 4763 godziny.

## Zakończył się remont dwóch ulic w centrum Krakowa. Wróciły tramwaje i samochody
 - [https://tvn24.pl/krakow/krakow-zakonczyl-sie-remont-dwoch-ulic-w-centrum-wrocily-tramwaje-i-samochody-st8232098?source=rss](https://tvn24.pl/krakow/krakow-zakonczyl-sie-remont-dwoch-ulic-w-centrum-wrocily-tramwaje-i-samochody-st8232098?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:40:21+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2586097-ulica-kosciuszki-w-krakowie-ph8232093/alternates/LANDSCAPE_1280" alt="Zakończył się remont dwóch ulic w centrum Krakowa. Wróciły tramwaje i samochody" />
    Zakończył się remont ulic Kościuszki i Zwierzynieckiej w centrum Krakowa. W sobotę przywrócono na nich ruch tramwajowy i samochodowy. Remont trwał prawie 1,5 roku i kosztował 94 miliony złotych.

## W wypadku zginęła jedna kobieta, druga walczy o życie
 - [https://tvn24.pl/katowice/slask-w-wypadku-zginela-jedna-kobieta-druga-walczy-o-zycie-st8232088?source=rss](https://tvn24.pl/katowice/slask-w-wypadku-zginela-jedna-kobieta-druga-walczy-o-zycie-st8232088?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:30:44+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4559859-wypadek-na-wysokosci-miejscowosci-ladzyn-zdjecie-ilustracyjne-ph8214488/alternates/LANDSCAPE_1280" alt="W wypadku zginęła jedna kobieta, druga walczy o życie" />
    Jedna kobieta nie żyje, a druga walczy o życie po wypadku, do którego doszło w sobotę, przed godziną 11, w miejscowości Kobiór w powiecie pszczyńskim. Droga w kierunku Katowic jest zablokowana.

## "Pieką mnie oczy i ciągle kaszlę, brakuje mi tchu"
 - [https://tvn24.pl/tvnmeteo/swiat/pieka-mnie-oczy-i-ciagle-kaszle-brakuje-mi-tchu-st8232083?source=rss](https://tvn24.pl/tvnmeteo/swiat/pieka-mnie-oczy-i-ciagle-kaszle-brakuje-mi-tchu-st8232083?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:20:51+00:00

<img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-4274030-smog-w-indiach-ph8232074/alternates/LANDSCAPE_1280" alt=""Pieką mnie oczy i ciągle kaszlę, brakuje mi tchu"" />
    Smog spowił w sobotę Nowe Delhi, stolicę Indii. Spowodował, że widzialność była mocno ograniczona. Mieszkańcy skarżyli się na trudności z oddychaniem. Jakość powietrza była znacznie powyżej normy.

## Rozbierają kamienicę przy Łuckiej. Konserwator zabytków wezwał policję. "Nielegalne prace"
 - [https://tvn24.pl/tvnwarszawa/wola/warszawa-rozbiorka-kamienicy-przy-luckiej-konserwator-zabytkow-wezwal-policje-nielegalne-prace-st8232002?source=rss](https://tvn24.pl/tvnwarszawa/wola/warszawa-rozbiorka-kamienicy-przy-luckiej-konserwator-zabytkow-wezwal-policje-nielegalne-prace-st8232002?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:34:32+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9933946-rozbiorka-kamienicy-przy-luckiej-8-ph8232004/alternates/LANDSCAPE_1280" alt="Rozbierają kamienicę przy Łuckiej. Konserwator zabytków wezwał policję. "Nielegalne prace"" />
    Ruszyła rozbiórka kamienicy przy Łuckiej 8. Na miejsce wezwano policję, bo według konserwatora zabytków, prace odbywają się nielegalnie. Budynek został jesienią wykreślony z rejestru zabytków, ale trwa postępowanie o objęcie ochroną konserwatorską jego murów obwodowych.

## Zaatakowana nożem kobieta nie żyje, zarzuty dla jej partnera
 - [https://tvn24.pl/tvnwarszawa/praga-polnoc/warszawa-areszt-za-atak-z-nozem-na-partnerke-kobieta-zmarla-w-szpitalu-st8231815?source=rss](https://tvn24.pl/tvnwarszawa/praga-polnoc/warszawa-areszt-za-atak-z-nozem-na-partnerke-kobieta-zmarla-w-szpitalu-st8231815?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:21:03+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4437757-podejrzany-o-brutalny-atak-na-partnerke-ph8231814/alternates/LANDSCAPE_1280" alt="Zaatakowana nożem kobieta nie żyje, zarzuty dla jej partnera" />
    Policjanci z Pragi Północ zatrzymali mężczyznę podejrzanego o brutalny atak z użyciem noża na partnerkę. Kobieta trafiła do szpitala z licznymi obrażeniami, jej życia nie udało się uratować. Sąd zdecydował, że 50-latek trafi do tymczasowego aresztu. Grozi mu dożywocie.

## Jechał za szybko. Zapłaci osiem tysięcy złotych i stanie przed sądem
 - [https://tvn24.pl/katowice/czestochowa-przekroczyl-predkosc-o-59-kilometrow-na-godzine-prowadzil-po-pijanemu-st8231918?source=rss](https://tvn24.pl/katowice/czestochowa-przekroczyl-predkosc-o-59-kilometrow-na-godzine-prowadzil-po-pijanemu-st8231918?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:20:00+00:00

<img src="https://tvn24.pl/katowice/cdn-zdjecie-6032529-przekroczyl-predkosc-o-59-kilometrow-na-godzine-prowadzil-po-pijanemu-ph8231905/alternates/LANDSCAPE_1280" alt="Jechał za szybko. Zapłaci osiem tysięcy złotych i stanie przed sądem" />
    Policjanci z Częstochowy zatrzymali do kontroli kierowcę bmw, który jechał za szybko. Był pijany. Stracił prawo jazdy i został ukarany mandatami w sumie na osiem tysięcy złotych. Na jego konto trafiło też 28 punktów.

## Orban "prowadzi niebezpieczną grę". Zgoda na azyl dla Romanowskiego "wpisuje się w kontekst"
 - [https://tvn24.pl/polska/marcin-romanowski-na-wegrzech-zgoda-na-azyl-polityczny-wpisuje-sie-w-szerszy-kontekst-dzialan-viktora-orbana-st8231812?source=rss](https://tvn24.pl/polska/marcin-romanowski-na-wegrzech-zgoda-na-azyl-polityczny-wpisuje-sie-w-szerszy-kontekst-dzialan-viktora-orbana-st8231812?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:37:28+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2311197-marcin-romanowski-ph8229796/alternates/LANDSCAPE_1280" alt="Orban "prowadzi niebezpieczną grę". Zgoda na azyl dla Romanowskiego "wpisuje się w kontekst"" />
    Zgoda na azyl polityczny dla posła PiS, byłego wiceministra sprawiedliwości Marcina Romanowskiego wpisuje się w szerszy kontekst różnych działań premiera Węgier Viktora Orbana, których wspólnym mianownikiem jest gra na nosie Unii Europejskiej - mówiła w TVN24 Anna Gielewska z portali vsquare.org oraz Frontstory.pl.

## Padły strzały, ranny został mężczyzna. Trwa policyjna obława
 - [https://tvn24.pl/rzeszow/kniazyce-przemysl-padly-strzaly-ranny-zostal-mezczyzna-trwa-policyjna-oblawa-st8231953?source=rss](https://tvn24.pl/rzeszow/kniazyce-przemysl-padly-strzaly-ranny-zostal-mezczyzna-trwa-policyjna-oblawa-st8231953?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:23:31+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6558729-policyjny-radiowoz-rzeszow-ph8231973/alternates/LANDSCAPE_1280" alt="Padły strzały, ranny został mężczyzna. Trwa policyjna obława" />
    We wsi Kniażyce koło Przemyśla (Podkarpackie) padły strzały, ranny został mężczyzna. Trwa policyjna obława za napastnikami. Funkcjonariusze kontrolują wjeżdżające i wyjeżdżające samochody.

## Na lotnisku straciła pamiątki z egzotycznych wakacji
 - [https://tvn24.pl/wroclaw/wroclaw-przewozila-z-wakacji-cztery-muszle-ktore-sa-pod-ochrona-st8231895?source=rss](https://tvn24.pl/wroclaw/wroclaw-przewozila-z-wakacji-cztery-muszle-ktore-sa-pod-ochrona-st8231895?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:15:49+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9182741-turystka-z-wysp-karaibskich-przewiozla-cztery-muszli-ph8231922/alternates/LANDSCAPE_1280" alt="Na lotnisku straciła pamiątki z egzotycznych wakacji" />
    Funkcjonariusze Służby Celno-Skarbowej wrocławskiego lotniska znaleźli w bagażu turystki wracającej z Wysp Karaibskich cztery muszle. Zostały zatrzymane, ponieważ kobieta nie miała odpowiedniego zezwolenia.

## Niemieckie media: rośnie liczba ofiar śmiertelnych ataku na jarmark
 - [https://tvn24.pl/swiat/niemcy-atak-na-jarmark-bozonarodzeniowy-w-magdeburgu-bild-wzrosla-liczba-ofiar-st8231878?source=rss](https://tvn24.pl/swiat/niemcy-atak-na-jarmark-bozonarodzeniowy-w-magdeburgu-bild-wzrosla-liczba-ofiar-st8231878?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:36:06+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9456053-policja-w-miejscu-ataku-w-magdeburgu-ph8231887/alternates/LANDSCAPE_1280" alt="Niemieckie media: rośnie liczba ofiar śmiertelnych ataku na jarmark" />
    Liczba ofiar śmiertelnych ataku na jarmark bożonarodzeniowy w Magdeburgu w Niemczech wzrosła do czterech - poinformował w sobotę dziennik "Bild", powołując się na lokalną policję. Dodał, że 41 osób jest ciężko rannych.

## Bili, kopali i grozili bronią
 - [https://tvn24.pl/lodz/strykow-bili-i-kopali-po-calym-ciele-i-grozili-przedmiotem-przypominajacym-bron-st8231879?source=rss](https://tvn24.pl/lodz/strykow-bili-i-kopali-po-calym-ciele-i-grozili-przedmiotem-przypominajacym-bron-st8231879?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:32:55+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-281514-do-zdarzenia-doszlo-w-strykowie-ph8231884/alternates/LANDSCAPE_1280" alt="Bili, kopali i grozili bronią" />
    Policjanci ze Zgierza (Łódzkie) zatrzymali dwóch braci podejrzanych o pobicie mężczyzny w Strykowie. Napastnicy najpierw uszkodzili jego pojazd, a potem bili, kopali i grozili bronią. Obaj usłyszeli zarzuty.

## Poszukiwanego za oszustwo "na policjanta" zatrzymali na lotnisku
 - [https://tvn24.pl/krakow/krakow-straznicy-graniczni-udaremnili-pasazerowi-wylot-do-manchesteru-byl-poszukiwany-za-oszustwo-na-policjanta-st8231837?source=rss](https://tvn24.pl/krakow/krakow-straznicy-graniczni-udaremnili-pasazerowi-wylot-do-manchesteru-byl-poszukiwany-za-oszustwo-na-policjanta-st8231837?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:30:07+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1455630-straz-graniczna-ph5502381/alternates/LANDSCAPE_1280" alt="Poszukiwanego za oszustwo "na policjanta" zatrzymali na lotnisku" />
    Strażnicy graniczni na lotnisku w Krakowie-Balicach zatrzymali mężczyznę, który chciał lecieć do Manchesteru. Jak się okazało był poszukiwany za oszustwo metodą "na policjanta".

## Zaginął w czasie wojny, wrócił do Wrocławia
 - [https://tvn24.pl/wroclaw/wroclaw-obraz-antona-graffa-powrocil-do-zbiorow-muzeum-narodowego-st8231847?source=rss](https://tvn24.pl/wroclaw/wroclaw-obraz-antona-graffa-powrocil-do-zbiorow-muzeum-narodowego-st8231847?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:21:36+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4487511-do-muzeum-narodowego-powrocil-utracony-podczas-ii-wojny-swiatowej-xix-wieczny-obraz-antona-graffa-ph8231867/alternates/LANDSCAPE_1280" alt="Zaginął w czasie wojny, wrócił do Wrocławia" />
    Obraz Antona Graffa "Autoportret w wieku 72 lat" z 1808 roku, który zaginął w trakcie II wojny światowej, trafił do Muzeum Narodowego we Wrocławiu. Dzieło zostało przekazane Polsce przez władze szwajcarskiego Winterthur.

## "W koszu na śmieci ląduje około 4-5 tysięcy złotych"
 - [https://tvn24.pl/biznes/z-kraju/w-koszu-na-smieci-laduje-okolo-4-5-tysiecy-zlotych-st8231851?source=rss](https://tvn24.pl/biznes/z-kraju/w-koszu-na-smieci-laduje-okolo-4-5-tysiecy-zlotych-st8231851?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:14:53+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9910333-w-radomiu-dochodzilo-do-pozarow-wiat-smietnikowych-zdjecie-ilustracyjne-ph8216081/alternates/LANDSCAPE_1280" alt=""W koszu na śmieci ląduje około 4-5 tysięcy złotych"" />
    Ekonomia jest bolesnym nauczycielem i to widać w różnych naszych badaniach, w których Polacy deklarują kupowanie mniejszej ilości żywności - stwierdził na antenie TVN24 dyrektor biura Federacji Polskich Banków Żywności Norbert Konarzewski. Dodał, że wśród społeczeństwa rośnie świadomość w kwestii marnowania żywności.

## Ratusz i urząd wojewódzki w Wigilię pracują bez zmian
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-jak-w-wigilie-pracuje-urzad-miasta-i-urzad-wojewodzki-st8231790?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-jak-w-wigilie-pracuje-urzad-miasta-i-urzad-wojewodzki-st8231790?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:15:43+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9bkizu-stoleczny-ratusz-265455/alternates/LANDSCAPE_1280" alt="Ratusz i urząd wojewódzki w Wigilię pracują bez zmian" />
    W Wigilię urząd miasta oraz urząd wojewódzki będą pracowały w standardowych godzinach. Podobnie będzie 23 i 27 grudnia. Mieszkańcy będą mogli załatwiać sprawy w godzinach 8-18 w poniedziałek oraz od 8 do 16 we wtorek i piątek.

## Wzmożone kontrole na drogach. Apel policji
 - [https://tvn24.pl/biznes/z-kraju/swieta-bozego-narodzenia-2024-kontrole-na-drogach-apel-policji-st8231781?source=rss](https://tvn24.pl/biznes/z-kraju/swieta-bozego-narodzenia-2024-kontrole-na-drogach-apel-policji-st8231781?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:12:13+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-b40m79-warszawa-droga-samochody-7426617/alternates/LANDSCAPE_1280" alt="Wzmożone kontrole na drogach. Apel policji" />
    W weekend ruszają na terenie całego kraju wzmożone kontrole policji - przekazał komisarz Antoni Rzeczkowski z Biura Ruchu Drogowego Komendy Głównej Policji. Policjanci będą sprawdzać między innymi trzeźwość, prędkość, a także sposób przewożenia dzieci i stan techniczny pojazdów.

## 32 lata i koniec. Wzruszające gesty klientów w ostatnich dniach przed zamknięciem sklepu
 - [https://tvn24.pl/krakow/krakow-zamkniecie-sklepu-alti-przy-ul-strzelcow-wzruszajacy-gest-klientow-st8231536?source=rss](https://tvn24.pl/krakow/krakow-zamkniecie-sklepu-alti-przy-ul-strzelcow-wzruszajacy-gest-klientow-st8231536?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:07:37+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4738322-sklep-alti-przy-ul-strzelcow-w-krakowie-zostal-zamkniety-20-grudnia-ph8231474/alternates/LANDSCAPE_1280" alt="32 lata i koniec. Wzruszające gesty klientów w ostatnich dniach przed zamknięciem sklepu" />
    W Krakowie przy ulicy Strzelców 20 grudnia zamknął się istniejący od 32 lat sklep spożywczy Alti. Mimo upływu czasu jego wystrój się nie zmieniał, co dla niektórych było wadą. Starsi klienci doceniali jednak wygodne położenie sklepu blisko bloków i miłą obsługę, z którą spędzali czas na rozmowach. - Jedna z klientek przyniosła wczoraj sernik w ramach podziękowań. A dzisiaj starsze małżeństwo przyniosło czekoladki i kawę dla każdego - mówi nam jedna z pracownic.

## Ryby z "kluchowatymi głowami", pływające myszy
 - [https://tvn24.pl/tvnmeteo/nauka/ryby-z-kluchowatymi-glowami-plywajace-myszy-st8231741?source=rss](https://tvn24.pl/tvnmeteo/nauka/ryby-z-kluchowatymi-glowami-plywajace-myszy-st8231741?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T07:27:31+00:00

<img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8196090-w-amazonii-odkryto-27-nowych-gatunkow-ph8231749/alternates/LANDSCAPE_1280" alt="Ryby z "kluchowatymi głowami", pływające myszy" />
    Naukowcy z organizacji Conservation International odkryli w peruwiańskiej Amazonii 27 nieznanych dotąd gatunków zwierząt. Najbardziej dziwacznymi są ryby z głowami przypominającymi "wielki, napuchnięty nos", a także wodno-lądowe myszy.

## Nowe przepisy w sprawie egzaminów. Prezydent podpisał nowelizację
 - [https://tvn24.pl/polska/prezydent-andrzej-duda-podpisal-nowelizacje-ustawy-o-systemie-oswiaty-st8231711?source=rss](https://tvn24.pl/polska/prezydent-andrzej-duda-podpisal-nowelizacje-ustawy-o-systemie-oswiaty-st8231711?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T06:59:20+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-uq09pn-maturzystka-na-egzaminie-maturalnym-z-jezyka-polskiego-w-i-lo-im-marii-sklodowskiej-curie-w-szczecinie-7902045/alternates/LANDSCAPE_1280" alt="Nowe przepisy w sprawie egzaminów. Prezydent podpisał nowelizację" />
    Prezydent Andrzej Duda podpisał w piątek nowelizację ustawy o systemie oświaty. Przewiduje ona między innymi wydłużenie o kolejne trzy lata szkolne braku wymogu uzyskania 30 procent punktów z jednego wybranego przedmiotu dodatkowego na egzaminie maturalnym.

## "Brutalny i tchórzliwy akt", "koszmar". Reakcje światowych przywódców
 - [https://tvn24.pl/swiat/niemcy-atak-na-jarmark-bozonarodzeniowy-w-magdeburgu-reakcje-swiatowych-przywodcow-i-resortow-dyplomacji-st8231730?source=rss](https://tvn24.pl/swiat/niemcy-atak-na-jarmark-bozonarodzeniowy-w-magdeburgu-reakcje-swiatowych-przywodcow-i-resortow-dyplomacji-st8231730?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:53:35+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5848210-policjanci-na-miejscu-tragedii-w-magdeburgu-ph8231734/alternates/LANDSCAPE_1280" alt=""Brutalny i tchórzliwy akt", "koszmar". Reakcje światowych przywódców" />
    Po ataku na jarmark bożonarodzeniowy w Magdeburgu, na wschodzie Niemiec, zareagowali światowi przywódcy i resorty dyplomacji. Departament Stany USA oświadczył, że Stany Zjednoczone są "wstrząśnięte i zasmucone tragicznymi wiadomościami". Saudyjskie MSZ podkreśliło, że Arabia Saudyjska "odrzuca przemoc" i wyraziło "solidarność z narodem niemieckim i rodzinami ofiar". Zamach skomentował także między innymi prezydent Andrzej Duda i prezydent Francji Emmanuel Macron.

## Intensywne opady, zawieje i zamiecie. IMGW ostrzega
 - [https://tvn24.pl/tvnmeteo/prognoza/intensywne-opady-zawieje-i-zamiecie-imgw-ostrzega-st8231731?source=rss](https://tvn24.pl/tvnmeteo/prognoza/intensywne-opady-zawieje-i-zamiecie-imgw-ostrzega-st8231731?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:15:57+00:00

<img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-4627446-snieg-intensywne-opady-sniegu-ph8190343/alternates/LANDSCAPE_1280" alt="Intensywne opady, zawieje i zamiecie. IMGW ostrzega" />
    Uwaga na trudne warunki pogodowe na Dolnym Śląsku. Na obszarach górskich w nocy zacznie intensywnie padać śnieg, a do tego będzie mocno wiać. Instytut Meteorologii i Gospodarki Wodnej wydał ostrzeżenia.

## Lód na drogach i chodnikach. Żółte alarmy na południu kraju
 - [https://tvn24.pl/tvnmeteo/prognoza/lod-na-drogach-i-chodnikach-zolte-alarmy-na-poludniu-kraju-st8231731?source=rss](https://tvn24.pl/tvnmeteo/prognoza/lod-na-drogach-i-chodnikach-zolte-alarmy-na-poludniu-kraju-st8231731?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:15:57+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6201538-mroz-lod-oblodzenie-opady-marznace-slisko-ph8213527/alternates/LANDSCAPE_1280" alt="Lód na drogach i chodnikach. Żółte alarmy na południu kraju" />
    IMGW ostrzega przed oblodzonymi drogami i chodnikami. Alarmy pierwszego stopnia obowiązują w województwach położonych na południu Polski. Sprawdź, gdzie aura będzie groźna.

## Sypnie śniegiem i będzie mocno wiać. Ostrzeżenia
 - [https://tvn24.pl/tvnmeteo/prognoza/sypnie-sniegiem-i-bedzie-mocno-wiac-ostrzezenia-st8231731?source=rss](https://tvn24.pl/tvnmeteo/prognoza/sypnie-sniegiem-i-bedzie-mocno-wiac-ostrzezenia-st8231731?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:15:57+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7037151-noc-opady-sniegu-sniezyca-deszcz-ze-sniegiem-ph8222668/alternates/LANDSCAPE_1280" alt="Sypnie śniegiem i będzie mocno wiać. Ostrzeżenia" />
    Uwaga na trudne warunki pogodowe w południowej Polsce. Na obszarach podgórskich w nocy i w niedzielę będzie mocno wiać, a w rejonie Dolnego Śląska mają pojawić się też intensywne opady śniegu. Instytut Meteorologii i Gospodarki Wodnej wydał ostrzeżenia.

## Więzienie i dwa miliony euro grzywny. Były szef Międzynarodowego Funduszu Walutowego skazany
 - [https://tvn24.pl/swiat/hiszpania-byly-szef-mfw-skazany-na-prawie-piec-lat-wiezienia-za-oszustwa-podatkowe-st8231703?source=rss](https://tvn24.pl/swiat/hiszpania-byly-szef-mfw-skazany-na-prawie-piec-lat-wiezienia-za-oszustwa-podatkowe-st8231703?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:14:45+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8041289-byly-szef-miedzynarodowego-funduszu-walutowego-rodrigo-rato-ph8231702/alternates/LANDSCAPE_1280" alt="Więzienie i dwa miliony euro grzywny. Były szef Międzynarodowego Funduszu Walutowego skazany" />
    Sąd w Madrycie skazał byłego szefa Międzynarodowego Funduszu Walutowego Rodrigo Rato na blisko pięć lat więzienia za oszustwa podatkowe. Rato ocenił, że orzeczenie było niesprawiedliwe i zapowiedział złożenie apelacji.

## Ukraińscy szpiedzy "śmiercionośną bronią". Byli szkoleni przez CIA
 - [https://tvn24.pl/swiat/ukraina-w-ukrainie-najwazniejsze-wydarzenia-ostatnich-godzin-21-grudnia-st8231728?source=rss](https://tvn24.pl/swiat/ukraina-w-ukrainie-najwazniejsze-wydarzenia-ostatnich-godzin-21-grudnia-st8231728?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:05:02+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-649587-monument-matki-ojczyzny-w-kijowie-ph8186943/alternates/LANDSCAPE_1280" alt="Ukraińscy szpiedzy "śmiercionośną bronią". Byli szkoleni przez CIA" />
    1031 dni temu rozpoczęła się rosyjska inwazja na Ukrainę. Ukraińscy szpiedzy są śmiercionośną bronią - ocenia "Economist", komentując udany zamach na rosyjskiego generała Igora Kiriłłowa w Moskwie. W czwartek "New York Times" przypomniał, że ukraińscy agenci odpowiedzialni za takie operacje byli szkoleni przez CIA. Oto co wydarzyło się w Ukrainie i wokół niej w ciągu ostatniej doby.

## Zwężona jezdnia i jednokierunkowy ruch. Weekendowe prace na Bitwy Warszawskiej 1920 roku
 - [https://tvn24.pl/tvnwarszawa/ochota/warszawa-prace-na-bitwy-warszawskiej-1920-roku-ruch-jednokierunkowy-utrudnienia-objazdy-szczegoly-st8230890?source=rss](https://tvn24.pl/tvnwarszawa/ochota/warszawa-prace-na-bitwy-warszawskiej-1920-roku-ruch-jednokierunkowy-utrudnienia-objazdy-szczegoly-st8230890?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:00:00+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4235100-ulica-bitwy-warszawskiej-1920-roku-ph8226565/alternates/LANDSCAPE_1280" alt="Zwężona jezdnia i jednokierunkowy ruch. Weekendowe prace na Bitwy Warszawskiej 1920 roku" />
    W weekend ulica Bitwy Warszawskiej 1920 roku, między rondem Zesłańców Syberyjskich a Szczęśliwicką, jest jednokierunkowa. Jezdnia w kierunku Alej Jerozolimskich została zamknięta, a dostępna jest ta, prowadząca do Grójeckiej. Wyznaczono objazdy. Trasy zmieniły również autobusy komunikacji miejskiej.

## Trump "zrobi to, co konieczne, aby przywrócić pokój". Chce, by Europa płaciła więcej
 - [https://tvn24.pl/swiat/usa-rzeczniczka-donalda-trumpa-prezydent-elekt-chce-by-europa-wypelnila-zobowiazania-obronne-st8231696?source=rss](https://tvn24.pl/swiat/usa-rzeczniczka-donalda-trumpa-prezydent-elekt-chce-by-europa-wypelnila-zobowiazania-obronne-st8231696?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T04:49:01+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1431559-donald-trump-ph8182164/alternates/LANDSCAPE_1280" alt="Trump "zrobi to, co konieczne, aby przywrócić pokój". Chce, by Europa płaciła więcej" />
    Rzeczniczka Donalda Trumpa Karoline Leavitt powiedziała, że prezydent elekt chce, by Europa wypełniła swoje zobowiązania dotyczące wydatków obronnych i zwiększyła udział w pomocy Ukrainie. Przedstawiciele zespołu prasowego zaprzeczyli jednak, by Trump domagał się od państw NATO wydatków na obronność na poziomie 5 procent PKB, o czym donosił "Financial Times".

## Zamach w Magdeburgu, MSZ reaguje na ucieczkę Romanowskiego, zmiany w składce zdrowotnej
 - [https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-21-grudnia-2024-najwazniejsze-wydarzenia-st8231726?source=rss](https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-21-grudnia-2024-najwazniejsze-wydarzenia-st8231726?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T04:08:26+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-549811-samochod-ktorym-zamachowiec-zaatakowal-uczestnikow-jarmarku-w-magdeburgu-ph8231725/alternates/LANDSCAPE_1280" alt="Zamach w Magdeburgu, MSZ reaguje na ucieczkę Romanowskiego, zmiany w składce zdrowotnej" />
    Kierowca wjechał samochodem w ludzi na jarmarku bożonarodzeniowym w niemieckim Magdeburgu. Polski MSZ zareagował na przyznanie azylu Marcinowi Romanowskiemu przez węgierskie władze. Prezydent Andrzej Duda podpisał ustawę wnoszącą zmiany w składce zdrowotnej. Oto pięć rzeczy, które warto wiedzieć w sobotę 21 grudnia.

