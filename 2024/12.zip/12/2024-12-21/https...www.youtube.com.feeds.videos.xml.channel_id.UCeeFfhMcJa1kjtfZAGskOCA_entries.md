# Source:Techlinked, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCeeFfhMcJa1kjtfZAGskOCA, language:en-US

## Wait - What IS This Thing?
 - [https://www.youtube.com/watch?v=u-VxnCyT1qk](https://www.youtube.com/watch?v=u-VxnCyT1qk)
 - RSS feed: $source
 - date published: 2024-12-21T04:09:28+00:00

Get an exclusive 15% discount on Saily eSIM data plans! Download Saily app and use code TECHLINKED at checkout. Or go to https://saily.com/techlinked

► GET MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► GET A VPN: https://www.piavpn.com/TechLinked
► LISTEN TO THE TECH NEWS: https://lmg.gg/TechLinkedPodcast
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR PODCAST GEAR: https://lmg.gg/podcastgear

NEWS SOURCES: https://lmg.gg/bzBH5
---------------------------------------------------
Timestamps:
0:00 well, how did i get here?
0:11 Handheld from Lenovo, Valve, + Microsoft?
1:48 YouTube's clickbait crackdown
3:26 EU spells out iOS interoperability
5:22 QUICK BITS INTRO
5:31 Intel Arrow Lake update tests, x86s gone
6:05 Gemini 2.0 Flash Thinking, OpenAI o3 
6:39 Sandisk rebrand is hype
7:12 FAA bans drones in parts of NJ
7:43 Bitcoin creator scam goes too far

