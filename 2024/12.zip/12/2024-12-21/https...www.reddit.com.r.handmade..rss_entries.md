# Source:Handmade - Arts & Crafts Made by Hand, URL:https://www.reddit.com/r/handmade/.rss, language:

## "Dragons emerging from the inkwell", Rapidograph, paper size A4 format.
 - [https://www.reddit.com/r/handmade/comments/1hjibcj/dragons_emerging_from_the_inkwell_rapidograph](https://www.reddit.com/r/handmade/comments/1hjibcj/dragons_emerging_from_the_inkwell_rapidograph)
 - RSS feed: $source
 - date published: 2024-12-21T20:23:44+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1hjibcj/dragons_emerging_from_the_inkwell_rapidograph/"> <img src="https://preview.redd.it/7cy06nylg98e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=6afa9d297f673212fa0a5c78299c8d8e31d78605" alt="&quot;Dragons emerging from the inkwell&quot;, Rapidograph, paper size A4 format. " title="&quot;Dragons emerging from the inkwell&quot;, Rapidograph, paper size A4 format. " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PawelDraus"> /u/PawelDraus </a> <br/> <span><a href="https://i.redd.it/7cy06nylg98e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hjibcj/dragons_emerging_from_the_inkwell_rapidograph/">[comments]</a></span> </td></tr></table>

## Christmas vase decoration ideas 😲
 - [https://www.reddit.com/r/handmade/comments/1hjfu14/christmas_vase_decoration_ideas](https://www.reddit.com/r/handmade/comments/1hjfu14/christmas_vase_decoration_ideas)
 - RSS feed: $source
 - date published: 2024-12-21T18:25:38+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/SuperCredit7975"> /u/SuperCredit7975 </a> <br/> <span><a href="https://youtube.com/shorts/VBhPtFhddI4">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hjfu14/christmas_vase_decoration_ideas/">[comments]</a></span>

## This is a wallet I personally designed and made over five days as a gift for my daughter’s 10th birthday. She’s going to be so happy!
 - [https://www.reddit.com/r/handmade/comments/1hjd158/this_is_a_wallet_i_personally_designed_and_made](https://www.reddit.com/r/handmade/comments/1hjd158/this_is_a_wallet_i_personally_designed_and_made)
 - RSS feed: $source
 - date published: 2024-12-21T16:14:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1hjd158/this_is_a_wallet_i_personally_designed_and_made/"> <img src="https://b.thumbs.redditmedia.com/ZioDhzJt0w7kF4oJmitUhbE1gyr8H94u6tSzuittq3s.jpg" alt="This is a wallet I personally designed and made over five days as a gift for my daughter’s 10th birthday. She’s going to be so happy!" title="This is a wallet I personally designed and made over five days as a gift for my daughter’s 10th birthday. She’s going to be so happy!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Old-Dick"> /u/Old-Dick </a> <br/> <span><a href="https://www.reddit.com/gallery/1hjd158">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hjd158/this_is_a_wallet_i_personally_designed_and_made/">[comments]</a></span> </td></tr></table>

## Acadia National Park and Bass Harbor Lighthouse, watercolor painting, 15 x 22 inches
 - [https://www.reddit.com/r/handmade/comments/1hjba9l/acadia_national_park_and_bass_harbor_lighthouse](https://www.reddit.com/r/handmade/comments/1hjba9l/acadia_national_park_and_bass_harbor_lighthouse)
 - RSS feed: $source
 - date published: 2024-12-21T14:48:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1hjba9l/acadia_national_park_and_bass_harbor_lighthouse/"> <img src="https://external-preview.redd.it/cmxtejQ3Z3BwNzhlMc89FHDmC8Wx-wC5w6kj76WaCOtEuMREe43hqRXrAScj.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=d12681d3e28f9f9b44a931f3011b2e69a63f12cb" alt="Acadia National Park and Bass Harbor Lighthouse, watercolor painting, 15 x 22 inches" title="Acadia National Park and Bass Harbor Lighthouse, watercolor painting, 15 x 22 inches" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Tanbelia"> /u/Tanbelia </a> <br/> <span><a href="https://v.redd.it/frs7m8gpp78e1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hjba9l/acadia_national_park_and_bass_harbor_lighthouse/">[comments]</a></span> </td></tr></table>

## The Yule Cat and Baba Yaga's Hut gouache painting I recently made, hope you like it. :)
 - [https://www.reddit.com/r/handmade/comments/1hjaxaz/the_yule_cat_and_baba_yagas_hut_gouache_painting](https://www.reddit.com/r/handmade/comments/1hjaxaz/the_yule_cat_and_baba_yagas_hut_gouache_painting)
 - RSS feed: $source
 - date published: 2024-12-21T14:29:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1hjaxaz/the_yule_cat_and_baba_yagas_hut_gouache_painting/"> <img src="https://b.thumbs.redditmedia.com/YBpmSuigfulwGM5HBRS5RuUvOxTLzn31yFtxEynUbkM.jpg" alt="The Yule Cat and Baba Yaga's Hut gouache painting I recently made, hope you like it. :)" title="The Yule Cat and Baba Yaga's Hut gouache painting I recently made, hope you like it. :)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/demeternati_art"> /u/demeternati_art </a> <br/> <span><a href="https://www.reddit.com/gallery/1hjaxaz">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hjaxaz/the_yule_cat_and_baba_yagas_hut_gouache_painting/">[comments]</a></span> </td></tr></table>

## Pls check my new video - DIY light Decor Christmas Special- Like & Comment
 - [https://www.reddit.com/r/handmade/comments/1hj8pwk/pls_check_my_new_video_diy_light_decor_christmas](https://www.reddit.com/r/handmade/comments/1hj8pwk/pls_check_my_new_video_diy_light_decor_christmas)
 - RSS feed: $source
 - date published: 2024-12-21T12:17:13+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/SuperCredit7975"> /u/SuperCredit7975 </a> <br/> <span><a href="https://youtube.com/shorts/1Z5-0QUKskg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hj8pwk/pls_check_my_new_video_diy_light_decor_christmas/">[comments]</a></span>

## Custom & holographic glitter guitar and Ukulele Picks
 - [https://www.reddit.com/r/handmade/comments/1hj35xc/custom_holographic_glitter_guitar_and_ukulele](https://www.reddit.com/r/handmade/comments/1hj35xc/custom_holographic_glitter_guitar_and_ukulele)
 - RSS feed: $source
 - date published: 2024-12-21T05:30:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1hj35xc/custom_holographic_glitter_guitar_and_ukulele/"> <img src="https://a.thumbs.redditmedia.com/wTOzJFk0_okvLN5vSb1_MY6P-SYmBqzE-GUshX7RAM4.jpg" alt="Custom &amp; holographic glitter guitar and Ukulele Picks " title="Custom &amp; holographic glitter guitar and Ukulele Picks " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CoralJean13"> /u/CoralJean13 </a> <br/> <span><a href="https://www.reddit.com/gallery/1hj35xc">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hj35xc/custom_holographic_glitter_guitar_and_ukulele/">[comments]</a></span> </td></tr></table>

## Looking for someone specific
 - [https://www.reddit.com/r/handmade/comments/1hj2hgk/looking_for_someone_specific](https://www.reddit.com/r/handmade/comments/1hj2hgk/looking_for_someone_specific)
 - RSS feed: $source
 - date published: 2024-12-21T04:47:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1hj2hgk/looking_for_someone_specific/"> <img src="https://preview.redd.it/apg96mant48e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5692788172a21832e7d77477d49188b761518eee" alt="Looking for someone specific" title="Looking for someone specific" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I am looking for someone who posted about two months regarding miniatures they make. They had gone to a show and didn&#39;t have good luck and were looking for feedback. </p> <p>Well, I went to your website and bought something. And I LOVE it. Just know that your handiwork is exquisite and I could not be happier to add this owl to my owl collection. 😍😍</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/avsphan"> /u/avsphan </a> <br/> <span><a href="https://i.redd.it/apg96mant48e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hj2hgk/looking_

## Watercolor painting I'm working on
 - [https://www.reddit.com/r/handmade/comments/1hj0x42/watercolor_painting_im_working_on](https://www.reddit.com/r/handmade/comments/1hj0x42/watercolor_painting_im_working_on)
 - RSS feed: $source
 - date published: 2024-12-21T03:12:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1hj0x42/watercolor_painting_im_working_on/"> <img src="https://preview.redd.it/syu4pzxnc48e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b4ccb370f5fec58538d419720da05a2762016aba" alt="Watercolor painting I'm working on" title="Watercolor painting I'm working on" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mochimunn2000"> /u/mochimunn2000 </a> <br/> <span><a href="https://i.redd.it/syu4pzxnc48e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hj0x42/watercolor_painting_im_working_on/">[comments]</a></span> </td></tr></table>

## I made a craft utility vest so that I never have to stop crafting!
 - [https://www.reddit.com/r/handmade/comments/1hiyhdy/i_made_a_craft_utility_vest_so_that_i_never_have](https://www.reddit.com/r/handmade/comments/1hiyhdy/i_made_a_craft_utility_vest_so_that_i_never_have)
 - RSS feed: $source
 - date published: 2024-12-21T00:56:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1hiyhdy/i_made_a_craft_utility_vest_so_that_i_never_have/"> <img src="https://b.thumbs.redditmedia.com/i4I6g4t5KGB7eePybusMYzUkmAIp-9wQVYqzuckwA5Q.jpg" alt="I made a craft utility vest so that I never have to stop crafting!" title="I made a craft utility vest so that I never have to stop crafting!" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I made this for doing crochet and embroidery on the go. Includes a scissor holster, pin cushion, stitch marker holder, retractable tape measure, spool holder, crochet hook/pencil holders and lots of pockets!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GoblinGoil"> /u/GoblinGoil </a> <br/> <span><a href="https://www.reddit.com/gallery/1hiyhdy">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hiyhdy/i_made_a_craft_utility_vest_so_that_i_never_have/">[comments]</a></span> </td></tr></table>

## Santa ornaments
 - [https://www.reddit.com/r/handmade/comments/1hiybib/santa_ornaments](https://www.reddit.com/r/handmade/comments/1hiybib/santa_ornaments)
 - RSS feed: $source
 - date published: 2024-12-21T00:48:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/handmade/comments/1hiybib/santa_ornaments/"> <img src="https://b.thumbs.redditmedia.com/vdO2_gPfFQHt4b9XBA8jXpTUYWxmpTYE0HlOuIjZ_xo.jpg" alt="Santa ornaments" title="Santa ornaments" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>A few Santa ornaments carved out of basswood, waiting for some time at the painting station. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/greenislandercrafts"> /u/greenislandercrafts </a> <br/> <span><a href="https://www.reddit.com/gallery/1hiybib">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/handmade/comments/1hiybib/santa_ornaments/">[comments]</a></span> </td></tr></table>

