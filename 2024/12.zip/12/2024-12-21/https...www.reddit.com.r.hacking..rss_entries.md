# Source:hacking: security in practice, URL:https://www.reddit.com/r/hacking/.rss, language:en

## i have got a Toyota corolla 2024 and i'm really curious if there is a developer menu on the multimedia screen and see if it is android
 - [https://www.reddit.com/r/hacking/comments/1hjlloa/i_have_got_a_toyota_corolla_2024_and_im_really](https://www.reddit.com/r/hacking/comments/1hjlloa/i_have_got_a_toyota_corolla_2024_and_im_really)
 - RSS feed: $source
 - date published: 2024-12-21T23:06:39+00:00

<!-- SC_OFF --><div class="md"><p>i have a toyota corolla 2024 and i couldn&#39;t find any information if there is a developer menu on the multimedia if any of you know or has had success with getting a developer menu on the car then help me out please</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Byozde"> /u/Byozde </a> <br/> <span><a href="https://www.reddit.com/r/hacking/comments/1hjlloa/i_have_got_a_toyota_corolla_2024_and_im_really/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hjlloa/i_have_got_a_toyota_corolla_2024_and_im_really/">[comments]</a></span>

## GitHub - stanfrbd/cyberbro: A simple application that extracts your IP, domain, hash from garbage input and checks their footprint using multiple services.
 - [https://www.reddit.com/r/hacking/comments/1hjj74m/github_stanfrbdcyberbro_a_simple_application_that](https://www.reddit.com/r/hacking/comments/1hjj74m/github_stanfrbdcyberbro_a_simple_application_that)
 - RSS feed: $source
 - date published: 2024-12-21T21:07:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/hacking/comments/1hjj74m/github_stanfrbdcyberbro_a_simple_application_that/"> <img src="https://external-preview.redd.it/lswSOv67IDv3QC8-XBL9Db9Z9O3SW-nieSWSBVN4uVk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=360b041dd3374f389c66c6e36803a3757bf2848f" alt="GitHub - stanfrbd/cyberbro: A simple application that extracts your IP, domain, hash from garbage input and checks their footprint using multiple services." title="GitHub - stanfrbd/cyberbro: A simple application that extracts your IP, domain, hash from garbage input and checks their footprint using multiple services." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/stan_frbd"> /u/stan_frbd </a> <br/> <span><a href="https://github.com/stanfrbd/cyberbro">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hjj74m/github_stanfrbdcyberbro_a_simple_application_that/">[comments]</a></span> </td></tr></table>

## Is SlickStack a Malware?
 - [https://www.reddit.com/r/hacking/comments/1hjizj5/is_slickstack_a_malware](https://www.reddit.com/r/hacking/comments/1hjizj5/is_slickstack_a_malware)
 - RSS feed: $source
 - date published: 2024-12-21T20:56:40+00:00

<!-- SC_OFF --><div class="md"><p>As I don&#39;t typically audit Bash scripts, I&#39;m trying to understand if this is standard practice or if there are potential risks.</p> <p>Any insights would be appreciated!</p> <p>I&#39;m seeking honest feedback on whether this commit could be considered justified.</p> <p>It seems a maintainer has, for some reason, inserted a domain within the script when it was previously just using the direct github hosted files.</p> <p>Would you consider this harmless, or does it raise concerns?</p> <p>The code in question appears to copy/sync files from GitHub every 3 hours and 47 minutes. Additionally, the downloaded files are granted root permissions during the process.</p> <p>Here&#39;s the specific commit for reference:</p> <p><a href="https://github.com/littlebizzy/slickstack/commit/6b03c786c68c9e24f4a47ec2e6fad7dc719a633c#diff-fe4d72aff1e2514e39311cdf701e3251e48a89670b15f8ca3f6ebeb6ecef1582R80">https://github.com/littlebizzy/slickstack/commit/6b03c786c

## What’s the point of hacking into a Reddit account?????
 - [https://www.reddit.com/r/hacking/comments/1hjghak/whats_the_point_of_hacking_into_a_reddit_account](https://www.reddit.com/r/hacking/comments/1hjghak/whats_the_point_of_hacking_into_a_reddit_account)
 - RSS feed: $source
 - date published: 2024-12-21T18:55:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/hacking/comments/1hjghak/whats_the_point_of_hacking_into_a_reddit_account/"> <img src="https://preview.redd.it/bq4pksqw098e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=610aad9bed123f709b80da1f067318d49958705c" alt="What’s the point of hacking into a Reddit account?????" title="What’s the point of hacking into a Reddit account?????" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Genuinely why</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/lolClaire"> /u/lolClaire </a> <br/> <span><a href="https://i.redd.it/bq4pksqw098e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hjghak/whats_the_point_of_hacking_into_a_reddit_account/">[comments]</a></span> </td></tr></table>

## Virus works if programs are installed on C drive, is it right?
 - [https://www.reddit.com/r/hacking/comments/1hjcfm2/virus_works_if_programs_are_installed_on_c_drive](https://www.reddit.com/r/hacking/comments/1hjcfm2/virus_works_if_programs_are_installed_on_c_drive)
 - RSS feed: $source
 - date published: 2024-12-21T15:46:26+00:00

<!-- SC_OFF --><div class="md"><p>I am not a hacker, but like to learn it in the near future, if I get time. </p> <p>So, when I was in school, my friend told me that you can save your PC from virus attacks by installing all the programs by creating another drive e.g. D:, E:, etc. I still don&#39;t know, if it is true!</p> <p>Can you help me know? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Professor-Wynorrific"> /u/Professor-Wynorrific </a> <br/> <span><a href="https://www.reddit.com/r/hacking/comments/1hjcfm2/virus_works_if_programs_are_installed_on_c_drive/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hjcfm2/virus_works_if_programs_are_installed_on_c_drive/">[comments]</a></span>

## Browser in Use
 - [https://www.reddit.com/r/hacking/comments/1hjbbga/browser_in_use](https://www.reddit.com/r/hacking/comments/1hjbbga/browser_in_use)
 - RSS feed: $source
 - date published: 2024-12-21T14:50:12+00:00

<!-- SC_OFF --><div class="md"><p>Just curious, what browser do you guys prefer and why? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DENZADJ"> /u/DENZADJ </a> <br/> <span><a href="https://www.reddit.com/r/hacking/comments/1hjbbga/browser_in_use/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hjbbga/browser_in_use/">[comments]</a></span>

## LLM powered BurpSuite extension, AEye, is now on GitHub!
 - [https://www.reddit.com/r/hacking/comments/1hjb76f/llm_powered_burpsuite_extension_aeye_is_now_on](https://www.reddit.com/r/hacking/comments/1hjb76f/llm_powered_burpsuite_extension_aeye_is_now_on)
 - RSS feed: $source
 - date published: 2024-12-21T14:44:22+00:00

<!-- SC_OFF --><div class="md"><p>Got good feedback from you guys on my previous post: <a href="https://www.reddit.com/r/hacking/comments/1hiyb4o/im_drunk_so_i_wrote_a_burpsuite_extension_sneak/">https://www.reddit.com/r/hacking/comments/1hiyb4o/im_drunk_so_i_wrote_a_burpsuite_extension_sneak/</a></p> <p>tl;dr: I&#39;m a security researcher at Microsoft, last night got drunk while playing the PS5 and listening to a security podcast. Was bored, decided to build a ChatGPT-powered BurpSuite extension.</p> <p>I&#39;ve been working on this for the past couple of days, so there is still work to do and features to add, but it seems to be safely consistent for the time being. I decided to go with the iterative approach of pushing new updates every few days when I have some more time to work on this, instead of waiting in vain for it to be perfect.</p> <p>Clone this, add your OpenAI key, download Jython, configure Burp, and enjoy!</p> <p><a href="https://github.com/Trivulzianus/AEye">https://

## Someone trying to access my telegram acc?
 - [https://www.reddit.com/r/hacking/comments/1hja2as/someone_trying_to_access_my_telegram_acc](https://www.reddit.com/r/hacking/comments/1hja2as/someone_trying_to_access_my_telegram_acc)
 - RSS feed: $source
 - date published: 2024-12-21T13:41:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/hacking/comments/1hja2as/someone_trying_to_access_my_telegram_acc/"> <img src="https://preview.redd.it/x0wgndbwg78e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=e42a0a658b9a1326c05ef731ea210c5e272becfd" alt="Someone trying to access my telegram acc?" title="Someone trying to access my telegram acc?" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I got a login code and few seconds later a login was detected. Good thing i am a bit tech savvy and understood what was going on so i terminated this login from colombo, android x and turned on otp. Next minute i got another otp and stopped from there.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/No_Grass_3728"> /u/No_Grass_3728 </a> <br/> <span><a href="https://i.redd.it/x0wgndbwg78e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hja2as/someone_trying_to_access_my_telegram_acc/">[comments]</a></span>

## Finding a source for a leaked password list containing sentences as passwords
 - [https://www.reddit.com/r/hacking/comments/1hj91l1/finding_a_source_for_a_leaked_password_list](https://www.reddit.com/r/hacking/comments/1hj91l1/finding_a_source_for_a_leaked_password_list)
 - RSS feed: $source
 - date published: 2024-12-21T12:39:12+00:00

<!-- SC_OFF --><div class="md"><p>Hey, I am currently searching for a leaked list containing sentences or random words written together can anyone help me? This is for my bachelors degree. :) </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Scarecrow1604"> /u/Scarecrow1604 </a> <br/> <span><a href="https://www.reddit.com/r/hacking/comments/1hj91l1/finding_a_source_for_a_leaked_password_list/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hj91l1/finding_a_source_for_a_leaked_password_list/">[comments]</a></span>

## See you at the 38c3
 - [https://www.reddit.com/r/hacking/comments/1hj89oy/see_you_at_the_38c3](https://www.reddit.com/r/hacking/comments/1hj89oy/see_you_at_the_38c3)
 - RSS feed: $source
 - date published: 2024-12-21T11:46:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/hacking/comments/1hj89oy/see_you_at_the_38c3/"> <img src="https://preview.redd.it/wycp5jqaw68e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=33ee8163fe5bcc11a170529348fea1779a08e9e4" alt="See you at the 38c3 " title="See you at the 38c3 " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Linux-Operative"> /u/Linux-Operative </a> <br/> <span><a href="https://i.redd.it/wycp5jqaw68e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hj89oy/see_you_at_the_38c3/">[comments]</a></span> </td></tr></table>

## How to determine if a Linux group allows root access?
 - [https://www.reddit.com/r/hacking/comments/1hj5gka/how_to_determine_if_a_linux_group_allows_root](https://www.reddit.com/r/hacking/comments/1hj5gka/how_to_determine_if_a_linux_group_allows_root)
 - RSS feed: $source
 - date published: 2024-12-21T08:13:13+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/allexj"> /u/allexj </a> <br/> <span><a href="/r/linuxquestions/comments/1hj5f5r/how_to_determine_if_a_linux_group_allows_root/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hj5gka/how_to_determine_if_a_linux_group_allows_root/">[comments]</a></span>

## China-linked hackers spark global concern| Radio Free Asia (RFA)
 - [https://www.reddit.com/r/hacking/comments/1hiymwx/chinalinked_hackers_spark_global_concern_radio](https://www.reddit.com/r/hacking/comments/1hiymwx/chinalinked_hackers_spark_global_concern_radio)
 - RSS feed: $source
 - date published: 2024-12-21T01:05:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/hacking/comments/1hiymwx/chinalinked_hackers_spark_global_concern_radio/"> <img src="https://external-preview.redd.it/a5o4JzieYeerse4N5-8fx4d4M7C2sCLwufOWdkRiGaE.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=21c88a985f50778113944402239aaf531396c1ed" alt="China-linked hackers spark global concern| Radio Free Asia (RFA)" title="China-linked hackers spark global concern| Radio Free Asia (RFA)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Right-Influence617"> /u/Right-Influence617 </a> <br/> <span><a href="https://youtu.be/jaUVNtTZJZo?si=yHBNZz_UEQ_Xf2FG">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/hacking/comments/1hiymwx/chinalinked_hackers_spark_global_concern_radio/">[comments]</a></span> </td></tr></table>

## I'm drunk so I wrote a BurpSuite extension - sneak peek at AEye
 - [https://www.reddit.com/r/hacking/comments/1hiyb4o/im_drunk_so_i_wrote_a_burpsuite_extension_sneak](https://www.reddit.com/r/hacking/comments/1hiyb4o/im_drunk_so_i_wrote_a_burpsuite_extension_sneak)
 - RSS feed: $source
 - date published: 2024-12-21T00:47:41+00:00

<!-- SC_OFF --><div class="md"><p><a href="https://www.reddit.com/r/cybersecurity/?f=flair_name%3A%22FOSS%20Tool%22"></a></p> <p>Hi y&#39;all</p> <p>I&#39;m T, a security researcher at Microsoft. Drank a few beers, played on my PS5, listened to Critical Thinking - Bug Bounty Podcast.</p> <p>The podcast gave me an idea for integrating LLMs in BurpSuite Proxy and Repeater. Sadly, BurpGPT beat me to the punch. It seems like a good, polished solution.</p> <p>Alas, it&#39;s also expensive as fuck.</p> <p>However, security is a passion of mine, in addition to being my profession. As such, I decided there should be a good, free, tool, that can incorporate LLM&#39;s insights in real time while doing pentesting, bug bounty, and definitely not black hat hacking.</p> <p>So, a few hours in, here&#39;s a sneak peek at AEye - an extension that gives you another set of eyes on requests and responses that pass through your proxy and repeater tools:</p> <p><a href="https://imgur.com/a/YOY1C5j">https:

