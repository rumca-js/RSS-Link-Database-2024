# Source:Magia Natury, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCfDX69pxC4q6yKSaugs196g, language:pl

## Jak Polowano na MAMUTY - Nowa Teoria! - Atomowa Broń Paleolitu
 - [https://www.youtube.com/watch?v=l3AP_eDqhSc](https://www.youtube.com/watch?v=l3AP_eDqhSc)
 - RSS feed: $source
 - date published: 2024-12-21T10:00:45+00:00

To, że ludzie przed tysiącami lat polowali na mamuty nie ulega najmniejszej wątpliwości. Skamieniałe kości tych wielkich trąbowców noszą ślady obróbki, dowodząc, że ich mięso było ćwiartowane i porcjowane. Niektóre kości noszą także ślady wbitych w nie grotów, którymi najwyraźniej zabijano te zwierzęta. Ludzie w paleolicie byli blisko związani z mamutami. Wykorzystywali ich skóry, kości, budowano z nich domy, a także wyrabiano narzędzia i ozdoby. Czy jednak włócznie stanowiły główną broń w walce z mamutami, czy może tak jak widzimy to na tym filmie, mamuty były łapane np. w ogromne sieci, a dopiero potem dobijane włóczniami? A może istniały także inne rozwiązania, które do tej pory umykały naukowcom? 

👉 Patronite ► https://patronite.pl/magia_natury
__________
Autor kanału nie rości sobie praw do materiałów wykorzystanych w filmie. Materiały wykorzystane są w ramach prawa dozwolonego użytku w celu zobrazowania, edukowania i lepszego zrozumienia zagadnienia lub pochodzą z serwisów udo

