# Source:Linus Tech Tips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, language:en-US

## His Wife Threw his Gaming PC out the Window… Can I Fix It?
 - [https://www.youtube.com/watch?v=kjn79Cs5Hco](https://www.youtube.com/watch?v=kjn79Cs5Hco)
 - RSS feed: $source
 - date published: 2024-12-21T17:57:43+00:00

Go to https://bit.ly/LMGHOLIDAYXP and check out Green Man Gaming’s Holiday Sale to save big on some of the hottest titles out right now! You can even use code LMGHOLIDAYXP to instantly become a Gold XP member and unlock even more discounts and exclusive giveaways (Gold XP status may take up to 24 hours to apply).

Check out Jawa’s GPU/CPU Trade up program at https://jawa.link/LTTTRADEUP and use code TRADEUP10 for an additional $10 on top of your base offer

Marriage counseling isn’t our thing, so we’re gonna gloss over WHY this PC is in such a sorry state. We just want to see if we can salvage anything - and see if the story checks out!

Discuss on the forum: https://linustechtips.com/topic/1593240-his-wife-threw-his-gaming-pc-out-the-window/

► GET OUR MERCH: https://lttstore.com
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► GET A VPN: http://www.piavpn.com/linus
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners

Purchases made through some store 

