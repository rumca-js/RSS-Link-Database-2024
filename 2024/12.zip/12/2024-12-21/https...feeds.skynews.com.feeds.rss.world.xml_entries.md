# Source:Sky News, URL:https://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## 'Terrible tragedy': At least 38 killed in bus crash in Brazil
 - [https://news.sky.com/story/terrible-tragedy-at-least-38-killed-in-bus-crash-in-brazil-13278236](https://news.sky.com/story/terrible-tragedy-at-least-38-killed-in-bus-crash-in-brazil-13278236)
 - RSS feed: $source
 - date published: 2024-12-21T19:15:00+00:00

At least 38 people have been killed in a crash involving a bus and a lorry on a major road in southeastern Brazil, authorities have said.

## Hope returns to eastern Aleppo after devastating siege by Assad's forces
 - [https://news.sky.com/story/hope-returns-to-eastern-aleppo-which-assad-forces-all-but-extinguished-13277683](https://news.sky.com/story/hope-returns-to-eastern-aleppo-which-assad-forces-all-but-extinguished-13277683)
 - RSS feed: $source
 - date published: 2024-12-21T13:18:00+00:00

Syrian and Russian forces unleashed all they could on eastern Aleppo. For four years they battled to bring Syria's second city under Bashar al Assad's full control.

## Christmas market suspect may have been 'dissatisfied with treatment of Saudi refugees'
 - [https://news.sky.com/story/christmas-market-suspect-may-have-been-dissatisfied-with-treatment-of-saudi-refugees-in-germany-heres-what-we-know-13277523](https://news.sky.com/story/christmas-market-suspect-may-have-been-dissatisfied-with-treatment-of-saudi-refugees-in-germany-heres-what-we-know-13277523)
 - RSS feed: $source
 - date published: 2024-12-21T05:26:00+00:00

The suspect in the attack on the Christmas market in Magdeburg was Islamophobic, German interior minister Nancy Faeser has said.

