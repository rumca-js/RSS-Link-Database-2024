# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Awaria na budowie nowej stacji metra. "Zobaczyliśmy zapadlisko na trzy metry"
 - [https://tvn24.pl/polska/bemowo-awaria-na-budowie-nowej-stacji-metra-zapadlisko-w-ziemi-st8232511?source=rss](https://tvn24.pl/polska/bemowo-awaria-na-budowie-nowej-stacji-metra-zapadlisko-w-ziemi-st8232511?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T21:54:57+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7934326-awaria-na-bemowie-ph8232512/alternates/LANDSCAPE_1280" alt="Awaria na budowie nowej stacji metra. "Zobaczyliśmy zapadlisko na trzy metry"" />
    Wieczorem na placu budowy nowej stacji metra zapadła się ziemia. - Zobaczyliśmy zapadlisko w ziemi na około trzy metry - mówił redakcji Kontakt24 aspirant Mariusz Kapsa ze stołecznej straży pożarnej. Mieszkańcy trzech bloków nie mają dostępu do wody i prądu.

## Kalisz: czy ktokolwiek spodziewał się, że wyrok tej nieistniejącej izby będzie inny niż po myśli pisowskiej?
 - [https://tvn24.pl/polska/kalisz-czy-ktokolwiek-spodziewal-sie-ze-wyrok-tej-nieistniejacej-izby-bedzie-inny-niz-po-mysli-pisowskiej-st8232398?source=rss](https://tvn24.pl/polska/kalisz-czy-ktokolwiek-spodziewal-sie-ze-wyrok-tej-nieistniejacej-izby-bedzie-inny-niz-po-mysli-pisowskiej-st8232398?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T19:35:50+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3538361-fpf-ph8232391/alternates/LANDSCAPE_1280" alt="Kalisz: czy ktokolwiek spodziewał się, że wyrok tej nieistniejącej izby będzie inny niż po myśli pisowskiej?" />
    Czy ktokolwiek, nawet pisowcy, spodziewali się, że wyrok tej nieistniejącej izby, tych siedmiu neosędziów, będzie inny niż po myśli pisowskiej? - pytał w "Faktach po Faktach" mecenas Ryszard Kalisz, członek Państwowej Komisji Wyborczej. Odniósł się tym samym do decyzji nieuznawanej Izby Kontroli Nadzwyczajnej Sądu Najwyższego, która uwzględniła skargę PiS na odrzucenie przez PKW sprawozdania komitetu wyborczego tej partii.

## Marszałek wziął udział w wigilijnym spotkaniu z dziećmi
 - [https://tvn24.pl/polska/marszalek-wzial-udzial-w-wigilijnym-spotkaniu-z-dziecmi-st8232279?source=rss](https://tvn24.pl/polska/marszalek-wzial-udzial-w-wigilijnym-spotkaniu-z-dziecmi-st8232279?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T17:29:54+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9690036-marszalek-sejmu-szymon-holownia-i-jego-zona-urszula-brzezinska-holownia-podczas-spotkania-wigilijnego-dla-dzieci-w-sejmie-21-12-2024-r-ph8232260/alternates/LANDSCAPE_1280" alt="Marszałek wziął udział w wigilijnym spotkaniu z dziećmi" />
    Podziwiamy was, jesteście bohaterami tego spotkania, avengersami, jakich ze święcą szukać - powiedział w sobotę marszałek Sejmu i przewodniczący Polski 2050 Szymon Hołownia podczas spotkania wigilijnego z dziećmi i młodzieżą, które mierzą się w życiu ze szczególnymi wyzwaniami. W spotkaniu towarzyszyła mu żona Urszula Brzezińska-Hołownia.

## "Nikt nigdy nie zrozumie bólu tych ludzi". Jak wygląda życie we Lwowie w cieniu wojny?
 - [https://fakty.tvn24.pl/najnowsze/nikt-nigdy-nie-zrozumie-bolu-tych-ludzi-jak-wyglada-zycie-we-lwowie-w-cieniu-wojny-st8232239?source=rss](https://fakty.tvn24.pl/najnowsze/nikt-nigdy-nie-zrozumie-bolu-tych-ludzi-jak-wyglada-zycie-we-lwowie-w-cieniu-wojny-st8232239?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T17:18:28+00:00

<img src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-4123622-lwow-004527-ph8232270/alternates/LANDSCAPE_1280" alt=""Nikt nigdy nie zrozumie bólu tych ludzi". Jak wygląda życie we Lwowie w cieniu wojny? " />
    Dramatycznie przeplatana rzeczywistość - okrutna wojna zmieszana z prozą życia. Meldunki o kolejnych zabitych i kartki ze świątecznymi życzeniami. W Ukrainie to codzienność.

## Szukają mężczyzny z nagrania, może mieć związek z rozbojem
 - [https://tvn24.pl/tvnwarszawa/ochota/warszawa-ochota-szukaja-mezczyzny-z-nagrania-moze-miec-zwiazek-z-rozbojem-st8232237?source=rss](https://tvn24.pl/tvnwarszawa/ochota/warszawa-ochota-szukaja-mezczyzny-z-nagrania-moze-miec-zwiazek-z-rozbojem-st8232237?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:30:32+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9523467-poszukiwany-mezczyzna-ph8232236/alternates/LANDSCAPE_1280" alt="Szukają mężczyzny z nagrania, może mieć związek z rozbojem" />
    Zapytał o papierosa, po czym uderzył mężczyznę w twarz, a w trakcie szarpaniny zabrał mu torbę i uciekł. Do zdarzenia doszło 19 listopada około godziny 21 przy ulicy Rakietników w kierunku ulicy Bohaterów Września. Policja szuka do tej sprawy mężczyzny z nagrania.

## "Co wolelibyście zobaczyć?". Incydent w parku narodowym
 - [https://tvn24.pl/tvnmeteo/swiat/co-wolelibyscie-zobaczyc-incydent-w-parku-narodowym-st8232240?source=rss](https://tvn24.pl/tvnmeteo/swiat/co-wolelibyscie-zobaczyc-incydent-w-parku-narodowym-st8232240?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:28:09+00:00

<img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-7439116-utah-ph8232249/alternates/LANDSCAPE_1280" alt=""Co wolelibyście zobaczyć?". Incydent w parku narodowym" />
    W słynącym z charakterystycznych czerwonych skał parku stanowym w amerykańskim stanie Utah część z nich została zabarwiona na niebiesko. Według władz prawdopodobnie ktoś użył armaty prochowej. Żeby wyczyścić skały, trzeba było użyć 90 litrów wody.

## Zielone, estetyczne, ekologiczne. Ale karetki po nich nie pojadą
 - [https://tvn24.pl/tvnwarszawa/wola/warszawa-ile-jest-zielonych-torowisk-w-warszawie-karetki-a-zielone-torowiska-st8229995?source=rss](https://tvn24.pl/tvnwarszawa/wola/warszawa-ile-jest-zielonych-torowisk-w-warszawie-karetki-a-zielone-torowiska-st8229995?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:18:08+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-4470644-zielone-torowisko-na-placu-konstytucji-ph8230018/alternates/LANDSCAPE_1280" alt="Zielone, estetyczne, ekologiczne. Ale karetki po nich nie pojadą" />
    Coraz więcej torowisk tramwajowych w Warszawie obsadzonych jest rozchodnikiem. Dla nowych inwestycji to przyjęty standard, ale zieleń pojawia się także przy okazji remontów. Korzyść ekologiczna jest oczywista, a co z bezpieczeństwem?

## Pierwszy taki atak Ukraińców. Wykorzystali specjalne pojazdy i drony
 - [https://tvn24.pl/swiat/pierwszy-taki-atak-ukraincow-wykorzystali-specjalne-pojazdy-i-drony-st8232204?source=rss](https://tvn24.pl/swiat/pierwszy-taki-atak-ukraincow-wykorzystali-specjalne-pojazdy-i-drony-st8232204?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T15:08:22+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-791002-ukrainski-dron-fpv-uzywany-w-wojnie-z-rosja-ph8217291/alternates/LANDSCAPE_1280" alt="Pierwszy taki atak Ukraińców. Wykorzystali specjalne pojazdy i drony" />
    Siły ukraińskie dokonały pierwszego ataku z użyciem wyłącznie pojazdów bezzałogowych i dronów z poglądem na żywo, niszcząc przy tym rosyjskie pozycje w pobliżu Charkowa - przekazał Instytut Studiów nad Wojną.

## Pies przywiązany do bariery na autostradzie. Szukają świadków
 - [https://tvn24.pl/katowice/rudzieniec-ktos-przywiazal-psa-do-bariery-na-autostradzie-policja-poszukuje-swiadkow-zdarzenia-st8232223?source=rss](https://tvn24.pl/katowice/rudzieniec-ktos-przywiazal-psa-do-bariery-na-autostradzie-policja-poszukuje-swiadkow-zdarzenia-st8232223?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:19:06+00:00

<img src="https://tvn24.pl/katowice/cdn-zdjecie-9736907-ktos-przywiazal-psa-do-bariery-na-autostradzie-policja-poszukuje-swiadkow-zdarzenia-ph8232205/alternates/LANDSCAPE_1280" alt="Pies przywiązany do bariery na autostradzie. Szukają świadków" />
    Patrol obsługi autostrady A4 na wysokości gminy Rudzieniec (Śląskie) zauważył psa, przywiązanego do bariery. Policjanci z Gliwic poszukują osób, które mogły być świadkami porzucenia zwierzęcia lub są w stanie pomóc w ustaleniu jego właściciela.

## Media: Scholz "warknął" na Dudę. "Nawet nie używacie euro!"
 - [https://tvn24.pl/biznes/ze-swiata/financial-times-olaf-scholz-warknal-na-andrzeja-dude-nawet-nie-uzywacie-euro-st8232184?source=rss](https://tvn24.pl/biznes/ze-swiata/financial-times-olaf-scholz-warknal-na-andrzeja-dude-nawet-nie-uzywacie-euro-st8232184?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T14:03:07+00:00

<img src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-286339-olaf-scholz-ph8232169/alternates/LANDSCAPE_1280" alt="Media: Scholz "warknął" na Dudę. "Nawet nie używacie euro!"" />
    W trakcie spotkania unijnych przywódców kanclerz Niemiec Olaf Scholz z irytacją zareagował na propozycję prezydenta Andrzeja Dudy dotyczącą rosyjskich aktywów - podał "Financial Times". Według relacji dziennika niemiecki polityk "warknął" na polskiego prezydenta, zaskakując tym pozostałych przywódców.

## Turystyczna zapaść na popularnej wyspie
 - [https://tvn24.pl/biznes/ze-swiata/turystyczny-kryzys-na-kubie-st8232049?source=rss](https://tvn24.pl/biznes/ze-swiata/turystyczny-kryzys-na-kubie-st8232049?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:12:16+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-94qtwk-hawana-kuba-chrispictures-shutterstock1177255552s-5543225/alternates/LANDSCAPE_1280" alt="Turystyczna zapaść na popularnej wyspie" />
    2,2 miliona turystów przybyło na Kubę w 2024 roku. To o milion urlopowiczów mniej, niż spodziewał się rząd w Hawanie. Od kilku lat w kubańskiej turystyce widoczny jest kryzys.

## "Nie będę komentował, co myślę". Orban o Polsce
 - [https://tvn24.pl/swiat/nie-bede-komentowal-co-mysle-viktor-orban-o-polsce-i-marcinie-romanowskim-st8232019?source=rss](https://tvn24.pl/swiat/nie-bede-komentowal-co-mysle-viktor-orban-o-polsce-i-marcinie-romanowskim-st8232019?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T13:10:43+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6800129-viktor-orban-ph8232145/alternates/LANDSCAPE_1280" alt=""Nie będę komentował, co myślę". Orban o Polsce" />
    Celem jest utrzymanie konfliktów z Polską na rozsądnym poziomie. Dlatego nie będę komentował, co myślę o stanie praworządności w niej - powiedział w sobotę Viktor Orban. Stwierdził jednak, że strona węgierska przeanalizowała sytuację w Polsce i na jej podstawie wydała decyzję o przyznaniu azylu Marcinowi Romanowskiemu. - Myślę, że nie będzie to ostatnia taka decyzja - dodał.

## "Syn Balcerowicza jakąś figurą w Wodach Polskich?". To nie ten Balcerowicz
 - [https://konkret24.tvn24.pl/polska/syn-balcerowicza-jakas-figura-w-wodach-polskich-to-nie-ten-balcerowicz-st8229434?source=rss](https://konkret24.tvn24.pl/polska/syn-balcerowicza-jakas-figura-w-wodach-polskich-to-nie-ten-balcerowicz-st8229434?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:57:00+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7151827-syn-balcerowicza-falszywy-przekaz-o-wiceprezesie-wod-polskich-ph8229359/alternates/LANDSCAPE_1280" alt=""Syn Balcerowicza jakąś figurą w Wodach Polskich?". To nie ten Balcerowicz" />
    Coraz szersze kręgi w mediach społecznościowych zatacza informacja, jakoby wiceprezes Wód Polskich był synem słynnego ekonomisty prof. Leszka Balcerowicza. To fake news.

## Kolizja radiowozu na sygnale w Wilanowie, policjant pouczony
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-radiowozu-na-sygnale-w-wilanowie-st8232077?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-radiowozu-na-sygnale-w-wilanowie-st8232077?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:09:17+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5505886-policyjny-radiowoz-zdj-ilustracyjne-ph8155065/alternates/LANDSCAPE_1280" alt="Kolizja radiowozu na sygnale w Wilanowie, policjant pouczony" />
    Kolizja z udziałem radiowozu w Wilanowie. Podczas wyjazdu do pilnej interwencji funkcjonariusze zderzyli się z autem osobowym. Nikt nie ucierpiał.

## Policjant podejrzany o udział w podpaleniu na posesji swojego przełożonego
 - [https://tvn24.pl/szczecin/piaski-gmina-barwice-swidwin-policjant-podejrzany-o-podpalenie-posesji-swojego-szefa-st8232086?source=rss](https://tvn24.pl/szczecin/piaski-gmina-barwice-swidwin-policjant-podejrzany-o-podpalenie-posesji-swojego-szefa-st8232086?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:07:44+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4426743-policja-w-swidwinie-ph8232080/alternates/LANDSCAPE_1280" alt="Policjant podejrzany o udział w podpaleniu na posesji swojego przełożonego" />
    Do pięciu lat więzienia grozi dwóm mężczyznom, którzy są podejrzani o podpalenie budynku gospodarczego w Świdwinie (Zachodniopomorskie). Jak informuje prokuratura w Koszalinie, jednym z nich jest policjant. Posesja należy do jego przełożonego.

## Tyle wydamy na święta
 - [https://tvn24.pl/biznes/z-kraju/boze-narodzenie-2024-ile-srednio-kosztuja-swieta-st8231959?source=rss](https://tvn24.pl/biznes/z-kraju/boze-narodzenie-2024-ile-srednio-kosztuja-swieta-st8231959?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T12:02:55+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7022244-zakupy-handel-wydatki-centrum-handlowe-galeria-handlowa-arkadia-ph7522686/alternates/LANDSCAPE_1280" alt="Tyle wydamy na święta" />
    Średnie wydatki na święta Bożego Narodzenia w 2024 roku wyniosą 1460 złotych - wynika z badania BIG InfoMonitor. Dodano, że mimo inflacji 47 procent badanych nie zamierza rezygnować z żadnych wydatków świątecznych.

## Znamy "krótkie listy" pretendentów do Oscara, Tom Cruise ze specjalny wyróżnieniem
 - [https://tvn24.pl/kultura-i-styl/kadr-na-kino-program-eweliny-witenberg-nowosci-ze-swiata-filmow-seriali-i-muzyki-21-12-2024-st6430598?source=rss](https://tvn24.pl/kultura-i-styl/kadr-na-kino-program-eweliny-witenberg-nowosci-ze-swiata-filmow-seriali-i-muzyki-21-12-2024-st6430598?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:59:00+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-884334-kadr-na-kino-ph8232023/alternates/LANDSCAPE_1280" alt="Znamy "krótkie listy" pretendentów do Oscara, Tom Cruise ze specjalny wyróżnieniem" />
    W najnowszym "Kadrze na kino" Ewelina Witenberg opowiedziała o najważniejszych wydarzeniach ze świata filmu i muzyki. W programie między innymi o filmie "Saint-Exupery. Zanim powstał Mały książę", który można już oglądać na dużym ekranie, a także o tytułach z szansą na nominacje do Oscara, które znalazły się na "krótkiej liście". Wspomniano też o specjalnym wyróżnieniu dla Toma Cruise'a.

## Kanclerz przyjechał do Magdebruga. "Żeby okazać solidarność całego kraju" po zamachu
 - [https://tvn24.pl/swiat/zamach-na-jarmarku-w-magdeburgu-kanclerz-niemiec-olaf-scholz-przyjechal-na-miejsce-st8231911?source=rss](https://tvn24.pl/swiat/zamach-na-jarmarku-w-magdeburgu-kanclerz-niemiec-olaf-scholz-przyjechal-na-miejsce-st8231911?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:48:42+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-5107796-konfa-sholtz-ph8232048/alternates/LANDSCAPE_1280" alt="Kanclerz przyjechał do Magdebruga. "Żeby okazać solidarność całego kraju" po zamachu" />
    Kanclerz Niemiec Olaf Scholz przyjechał do Magdeburga, gdzie w piątek doszło do zamachu na jarmarku bożonarodzeniowym. - Nie ma bardziej pokojowego i piękniejszego miejsca niż jarmark świąteczny. Ludzie zbierają się na nim kilka dni przed świętami, żeby pobyć ze sobą i poświętować. Dlatego jest to straszliwy czyn - powiedział.

## "Nie ma prądu, dochodzi do kradzieży, słychać wystrzały z broni gazowej"
 - [https://tvn24.pl/tvnmeteo/swiat/nie-ma-pradu-dochodzi-do-kradziezy-slychac-wystrzaly-z-broni-gazowej-st8231950?source=rss](https://tvn24.pl/tvnmeteo/swiat/nie-ma-pradu-dochodzi-do-kradziezy-slychac-wystrzaly-z-broni-gazowej-st8231950?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T11:02:53+00:00

<img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8271910-majotta-ph8231948/alternates/LANDSCAPE_1280" alt=""Nie ma prądu, dochodzi do kradzieży, słychać wystrzały z broni gazowej"" />
    Tydzień temu w Majottę uderzył potężny cyklon Chido. Sytuacja we francuskim terytorium zamorskim jest trudna - wiele domów nie ma prądu, brakuje wody i jedzenia. - Wieczorami, po zachodzie słońca na ulicach robi się dość niebezpiecznie - powiedziała pani Anna, która wysłała nam swoją relację na Kontakt24. Polka mieszka tam od kilku lat.

## Polska w obliczu kryzysu. "Już naprawdę jesteśmy w ogonie Europy"
 - [https://tvn24.pl/biznes/z-kraju/wiek-emerytalny-w-polsce-to-absolutna-koniecznosc-st8231952?source=rss](https://tvn24.pl/biznes/z-kraju/wiek-emerytalny-w-polsce-to-absolutna-koniecznosc-st8231952?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:54:57+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-620402-ludzie-ulica-przechodnie-ph8186158/alternates/LANDSCAPE_1280" alt="Polska w obliczu kryzysu. "Już naprawdę jesteśmy w ogonie Europy"" />
    Podwyższenie wieku emerytalnego to jedno z podstawowych działań - uważa dyrektorka Instytutu Statystyki i Demografii Szkoły Głównej Handlowej (SGH) profesor Agnieszka Chłoń-Domińczak. Według niej niski wiek emerytalny jest dyskryminujący szczególnie dla kobiet, które ze względu na krótszy czas pracy, otrzymują później niższe świadczenia.

## Lot z Seulu do Warszawy odwołany. Z powodu "usterki technicznej"
 - [https://tvn24.pl/tvnwarszawa/wlochy/warszawa-odwolany-lot-z-seulu-do-warszawy-powodem-usterka-techniczna-st8231958?source=rss](https://tvn24.pl/tvnwarszawa/wlochy/warszawa-odwolany-lot-z-seulu-do-warszawy-powodem-usterka-techniczna-st8231958?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:45:56+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2074722-odwolany-lot-z-seulu-do-warszawy-ph8231970/alternates/LANDSCAPE_1280" alt="Lot z Seulu do Warszawy odwołany. Z powodu "usterki technicznej"" />
    Lot z Seulu do Warszawy został odwołany z powodu usterki. Przewoźnik przekazał, że konieczne jest dostarczenie części zamiennych do maszyny. Informację oraz zdjęcia otrzymaliśmy na Kontakt 24.

## "Po ataku w Magdeburgu już dziś oczekuję jasnej deklaracji pana prezydenta Dudy"
 - [https://tvn24.pl/polska/donald-tusk-apeluje-do-prezydenta-i-pis-po-ataku-w-magdeburgu-st8231975?source=rss](https://tvn24.pl/polska/donald-tusk-apeluje-do-prezydenta-i-pis-po-ataku-w-magdeburgu-st8231975?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:42:49+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-1471491-donald-tusk-ph8227812/alternates/LANDSCAPE_1280" alt=""Po ataku w Magdeburgu już dziś oczekuję jasnej deklaracji pana prezydenta Dudy"" />
    Premier Donald Tusk nawiązał do piątkowego zamachu na jarmarku świątecznym w Magdeburgu i zwrócił się z apelem do prezydenta oraz Prawa i Sprawiedliwości. Napisał, że oczekuje "poparcia rządowego pakietu zaostrzającego prawo wizowe i azylowe". "Państwo odzyskuje właśnie kontrolę nad granicami i migracją po latach chaosu i korupcji, więc chociaż nie przeszkadzajcie" - dodał.

## Na widok radiowozu przyspieszył i wpadł do rowu. Ma cztery dożywotnie zakazy prowadzenia aut
 - [https://tvn24.pl/tvnwarszawa/okolice/ciechanow-poscig-zakonczyl-sie-w-rowie-kierowca-mial-cztery-dozywotnie-zakazy-prowadzenia-i-byl-pijany-st8231898?source=rss](https://tvn24.pl/tvnwarszawa/okolice/ciechanow-poscig-zakonczyl-sie-w-rowie-kierowca-mial-cztery-dozywotnie-zakazy-prowadzenia-i-byl-pijany-st8231898?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T10:05:25+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-3530212-poscig-za-kierowca-seata-zakonczyl-sie-w-rowie-ph8231902/alternates/LANDSCAPE_1280" alt="Na widok radiowozu przyspieszył i wpadł do rowu. Ma cztery dożywotnie zakazy prowadzenia aut" />
    Policjanci z Ciechanowa zatrzymali po pościgu 29-letniego kierowcę seata. Podczas ucieczki mężczyzna wjechał do rowu. W trakcie kontroli okazało się, że był pijany i posiada cztery dożywotnie zakazy prowadzenia pojazdów.

## Jak kupić dobre produkty na Wigilię? "Dwutlenek siarki jest stosowany w celu zachowania jasnej barwy"
 - [https://tvn24.pl/biznes/z-kraju/jak-kupic-dobre-produkty-na-wigilie-dwutlenek-siarki-jest-stosowany-w-celu-zachowania-jasnej-barwy-st8231842?source=rss](https://tvn24.pl/biznes/z-kraju/jak-kupic-dobre-produkty-na-wigilie-dwutlenek-siarki-jest-stosowany-w-celu-zachowania-jasnej-barwy-st8231842?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:45:23+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7251500-shutterstock-2212991303-ph8231863/alternates/LANDSCAPE_1280" alt="Jak kupić dobre produkty na Wigilię? "Dwutlenek siarki jest stosowany w celu zachowania jasnej barwy"" />
    Kapusta kwaszona jest równie dobra co kiszona, a owoce na susz mogą zawierać konserwanty - ostrzegają eksperci. Radzą też klientom, by nie kupowali produktów na Wigilię w pośpiechu i starannie czytali etykiety na opakowaniach.

## Choinki bez dokumentów, właściciel bez prawa jazdy, auto bez przeglądu
 - [https://tvn24.pl/tvnwarszawa/ochota/warszawa-sprzedawal-choinki-bez-dokumentow-sam-nie-mial-uprawnien-do-kierowania-st8231848?source=rss](https://tvn24.pl/tvnwarszawa/ochota/warszawa-sprzedawal-choinki-bez-dokumentow-sam-nie-mial-uprawnien-do-kierowania-st8231848?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T09:39:32+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5053932-auto-sprzedawcy-choinek-zostalo-odholowane-ph8231850/alternates/LANDSCAPE_1280" alt="Choinki bez dokumentów, właściciel bez prawa jazdy, auto bez przeglądu" />
    Podczas kontroli stoiska z choinkami zatrzymany został jego właściciel. Mężczyzna przywiózł na miejsce dokumenty dotyczące oferowanych drzewek, ale nie wszystkich. Okazało się też, że nie posiada uprawnień do kierowania pojazdami, a jego auto aktualnych badań technicznych.

## Kołodziejczak o sporze w resorcie: Czekam na rozmowę z ministrem. Musimy dać z siebie 120 procent
 - [https://tvn24.pl/polska/michal-kolodziejczak-o-sporze-w-resorcie-rolnictwa-nie-mialem-okazji-do-rozmowy-z-czeslawem-siekierskim-czekam-jest-jeszcze-czas-st8231809?source=rss](https://tvn24.pl/polska/michal-kolodziejczak-o-sporze-w-resorcie-rolnictwa-nie-mialem-okazji-do-rozmowy-z-czeslawem-siekierskim-czekam-jest-jeszcze-czas-st8231809?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:57:38+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-6568343-1n1-ph8231804/alternates/LANDSCAPE_1280" alt="Kołodziejczak o sporze w resorcie: Czekam na rozmowę z ministrem. Musimy dać z siebie 120 procent" />
    W ministerstwie czuję się rzecznikiem polskich rolników. Nie wybaczę sobie, jeżeli dziś przy tych możliwościach, które mamy i przy tym dużym mandacie społecznym nie wyciśniemy z siebie 120 procent - mówił w "Jeden na jeden" wiceminister rolnictwa Michał Kołodziejczak. Odniósł się do wypowiadanych wcześniej krytycznych komentarzy wobec organizacji pracy w resorcie i ministra Czesława Siekierskiego. - Od czasu, kiedy wypowiedziałem te słowa, nie miałem okazji, możliwości rozmowy z ministrem - poinformował. Dodał, że prosił o spotkanie i na nie czeka.

## Pływające drony z "zębami". Nowy sposób walki z mikroplastikiem
 - [https://tvn24.pl/tvnmeteo/najnowsze/plywajace-drony-z-zebami-nowy-sposob-walki-z-mikroplastikiem-st8231822?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/plywajace-drony-z-zebami-nowy-sposob-walki-z-mikroplastikiem-st8231822?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:54:03+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-vxv8xo-mikroplastik-7129952/alternates/LANDSCAPE_1280" alt="Pływające drony z "zębami". Nowy sposób walki z mikroplastikiem" />
    Naukowcy z Koreańskiego Instytutu Nauki i Technologii opracowali pływające drony. Wyposażone są one w "hydrofilowe zęby", dzięki którym mogą wychwytywać unoszący się w wodzie mikroplastik.

## Ostrzegała przed policją "mrugając" światłami, trafiła na nieoznakowany radiowóz
 - [https://tvn24.pl/tvnwarszawa/okolice/piaseczno-mrugnela-swiatlami-policjantom-w-nieoznakowanym-radiowozie-dostala-mandat-st8231371?source=rss](https://tvn24.pl/tvnwarszawa/okolice/piaseczno-mrugnela-swiatlami-policjantom-w-nieoznakowanym-radiowozie-dostala-mandat-st8231371?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T08:36:37+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-3142791-mrugala-swiatlami-natrafila-na-nieoznakowany-radiowoz-ph8231374/alternates/LANDSCAPE_1280" alt="Ostrzegała przed policją "mrugając" światłami, trafiła na nieoznakowany radiowóz" />
    Funkcjonariusze z Wydziału Ruchu Drogowego Komendy Powiatowej Policji w Piasecznie zatrzymali kierującą, która używała świateł drogowych ostrzegając innych kierowców przed policyjną kontrolą. Kobieta nieświadomie w ten sposób ostrzegła także policjantów jadących nieoznakowanym radiowozem. Została ukarana mandatem.

## Uderzył w drzewo, zmarł w szpitalu
 - [https://tvn24.pl/tvnwarszawa/okolice/tragiczny-wypadek-w-miejscowosci-elzbietow-pod-sochaczewem-kierujacy-autem-osobowym-uderzyl-w-drzewo-mezczyzna-byl-reanimowany-na-miejscu-zdarzenia-i-trafil-do-szpitala-lecz-jego-zycia-nie-udalo-sie-uratowac-st8231764?source=rss](https://tvn24.pl/tvnwarszawa/okolice/tragiczny-wypadek-w-miejscowosci-elzbietow-pod-sochaczewem-kierujacy-autem-osobowym-uderzyl-w-drzewo-mezczyzna-byl-reanimowany-na-miejscu-zdarzenia-i-trafil-do-szpitala-lecz-jego-zycia-nie-udalo-sie-uratowac-st8231764?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T07:56:42+00:00

<img src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6180459-smiertelny-wypadek-w-elzbietowie-ph8231765/alternates/LANDSCAPE_1280" alt="Uderzył w drzewo, zmarł w szpitalu" />
    Tragiczny wypadek w miejscowości Elżbietów pod Sochaczewem (Mazowieckie). Kierujący autem osobowym uderzył w drzewo. Mężczyzna był reanimowany na miejscu zdarzenia i trafił do szpitala, lecz jego życia nie udało się uratować.

## Trump przyjedzie do Polski? Prezydencki minister: zaprosimy go na szczyt
 - [https://tvn24.pl/polska/donald-trump-przyjedzie-do-polski-prezydencki-minister-o-zaproszeniu-na-szczyt-inicjatywy-trojmorza-st8231747?source=rss](https://tvn24.pl/polska/donald-trump-przyjedzie-do-polski-prezydencki-minister-o-zaproszeniu-na-szczyt-inicjatywy-trojmorza-st8231747?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T07:40:49+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-7301897-donald-trump-ph8225082/alternates/LANDSCAPE_1280" alt="Trump przyjedzie do Polski? Prezydencki minister: zaprosimy go na szczyt" />
    Prezydent USA Donald Trump dostanie zaproszenie na szczyt Inicjatywy Trójmorza, który odbędzie się pod koniec kwietnia w Warszawie - przekazał szef prezydenckiego Biura Polityki Międzynarodowej Mieszko Pawlak. Jak powiedział, Trump w 2017 roku wziął udział w takim spotkaniu, więc jego obecność na szczycie w przyszłym roku stanowiłaby "pewnego rodzaju klamrę".

## Cyberatak na ukraińskie rejestry państwowe. Kopie zapasowe były na serwerach w Polsce
 - [https://tvn24.pl/swiat/ukraina-media-cyberatak-na-rejestry-panstwowe-ktorych-kopie-zapasowe-byly-na-serwerach-w-polsce-st8231666?source=rss](https://tvn24.pl/swiat/ukraina-media-cyberatak-na-rejestry-panstwowe-ktorych-kopie-zapasowe-byly-na-serwerach-w-polsce-st8231666?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T06:28:19+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-qhlr6-haker-cyberatak-cyberwojna-hacker-7921269/alternates/LANDSCAPE_1280" alt="Cyberatak na ukraińskie rejestry państwowe. Kopie zapasowe były na serwerach w Polsce" />
    Portal Ukrainska Prawda przekazał, że cyberatak, przeprowadzony przez rosyjskich hakerów, zawiesił funkcjonowanie kluczowych systemów z rejestrami państwowymi Ukrainy. Hakerzy twierdzą, że zniszczyli wszystkie dane, do których mieli dostęp, w tym kopie zapasowe, które znajdowały się na serwerach w Polsce.

## Kiedyś von Herbersteinowie, dziś powodzianie. O mapie wspomnień i bigosie w pałacu
 - [https://tvn24.pl/premium/gorzanow-powodz-palac-z-xvii-wieku-zamienil-sie-w-punkt-pomocy-st8228141?source=rss](https://tvn24.pl/premium/gorzanow-powodz-palac-z-xvii-wieku-zamienil-sie-w-punkt-pomocy-st8228141?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:30:39+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-4359775-mapa-wspomnien-pana-franka-ph8228139/alternates/LANDSCAPE_1280" alt="Kiedyś von Herbersteinowie, dziś powodzianie. O mapie wspomnień i bigosie w pałacu" />
    Pan Franek uciekł przed wodą na strych. Pan Grzegorz z żoną do altany na ogródkach działkowych. Kiedy fala opadła, nie mieli do czego wracać. Dziś jeden z nich ma ksywę "Księciunio", a drugi jest dobrym duchem barokowego zabytku - bo obaj żyją w pałacu. Od kiedy siedemnastowieczna siedziba austriackich arystokratów zamieniła się w hub pomocowy, przenocowała już ponad 1000 wolontariuszy.

## Adaptacja miast do zmian klimatu. Prezydent podpisał ustawę
 - [https://tvn24.pl/polska/prezydent-andrzej-duda-podpisal-nowele-dotyczaca-planow-adaptacji-do-zmian-klimatu-dla-mniejszych-miast-st8231706?source=rss](https://tvn24.pl/polska/prezydent-andrzej-duda-podpisal-nowele-dotyczaca-planow-adaptacji-do-zmian-klimatu-dla-mniejszych-miast-st8231706?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:27:12+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9897227-prezydent-andrzej-duda-ph8231704/alternates/LANDSCAPE_1280" alt="Adaptacja miast do zmian klimatu. Prezydent podpisał ustawę" />
    Prezydent Andrzej Duda podpisał nowelizację Prawa ochrony środowiska - poinformowała jego kancelaria. Nowe przepisy przewidują między innymi wprowadzenie obowiązku przygotowania planów adaptacji do zmian klimatu dla miast, które mają 20 tysięcy i więcej mieszkańców.

## Intensywny śnieg, lód i porywisty wiatr. Tu pogoda może stać się groźna
 - [https://tvn24.pl/tvnmeteo/prognoza/intensywny-snieg-lod-i-porywisty-wiatr-tu-pogoda-moze-stac-sie-grozna-st8231731?source=rss](https://tvn24.pl/tvnmeteo/prognoza/intensywny-snieg-lod-i-porywisty-wiatr-tu-pogoda-moze-stac-sie-grozna-st8231731?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T05:15:57+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-8161056-snieg-opady-sniegu-zima-pierwszy-snieg-zimno-ph8231931/alternates/LANDSCAPE_1280" alt="Intensywny śnieg, lód i porywisty wiatr. Tu pogoda może stać się groźna" />
    IMGW wydał prognozę zagrożeń. Wynika z niej, że w kolejnych dniach pojawią się obfite opady śniegu, a także oblodzenia. Na drogach i chodnikach zrobi się ślisko. Poza tym powieje silniejszy wiatr. Sprawdź, gdzie aura może być groźna.

## Tragedia na jarmarku. Kim jest podejrzany o przeprowadzenie zamachu
 - [https://tvn24.pl/swiat/niemcy-atak-na-jarmark-bozonarodzeniowy-w-magdeburgu-kim-jest-podejrzany-o-przeprowadzenie-zamachu-st8231719?source=rss](https://tvn24.pl/swiat/niemcy-atak-na-jarmark-bozonarodzeniowy-w-magdeburgu-kim-jest-podejrzany-o-przeprowadzenie-zamachu-st8231719?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T04:38:33+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-9826280-sluzby-ratunkowe-w-magdeburgu-ph8231710/alternates/LANDSCAPE_1280" alt="Tragedia na jarmarku. Kim jest podejrzany o przeprowadzenie zamachu" />
    Pojawiły się pierwsze szczegóły dotyczące tożsamości sprawcy, który wjechał samochodem w tłum ludzi na jarmarku bożonarodzeniowym w Magdeburgu. Jak podają niemieckie media, mężczyzna jest lekarzem mieszkającym w Bernburgu i pracującym w klinice. Pochodzi z Arabii Saudyjskiej.

## Zabójca dwóch nastolatek skazany na 130 lat więzienia
 - [https://tvn24.pl/swiat/usa-zabojca-dwoch-nastolatek-richard-allen-skazany-na-130-lat-wiezienia-st8231691?source=rss](https://tvn24.pl/swiat/usa-zabojca-dwoch-nastolatek-richard-allen-skazany-na-130-lat-wiezienia-st8231691?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T04:23:51+00:00

<img src="https://tvn24.pl/najnowsze/cdn-zdjecie-2325093-richard-allen-zostal-skazany-na-130-lat-wiezienia-ph8231677/alternates/LANDSCAPE_1280" alt="Zabójca dwóch nastolatek skazany na 130 lat więzienia" />
    Zabójca dwóch nastolatek Richard Allen został skazany w USA na 130 lat więzienia. Do podwójnego zabójstwa doszło w 2017 roku w małym miasteczku Delphi w stanie Indiana.

## Pogoda na dziś - sobota 21.12. Chłodno i pochmurno, miejscami silniej powieje
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-sobota-21-12-chlodno-i-pochmurno-miejscami-silniej-powieje-st8231453?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-sobota-21-12-chlodno-i-pochmurno-miejscami-silniej-powieje-st8231453?source=rss)
 - RSS feed: $source
 - date published: 2024-12-21T01:00:00+00:00

<img src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-70ps7d-wiatr-i-deszcz-5588038/alternates/LANDSCAPE_1280" alt="Pogoda na dziś - sobota 21.12. Chłodno i pochmurno, miejscami silniej powieje" />
    Pogoda na dziś. Sobota 21.12 okaże się chłodnym, raczej ponurym dniem. W większości regionów niepotrzebne będą nam parasole, ale we znaki może dać się silniejszy wiatr. Termometry pokażą od 2 do 6 stopni Celsjusza.

