# Source:pcgamer, URL:https://www.pcgamer.com/rss, language:en-US

## BioWare considered bringing the hero of Dragon Age: Origins back for Veilguard, but with a horrifying catch: 'Do not let her see me like this'
 - [https://www.pcgamer.com/games/dragon-age/bioware-considered-bringing-the-hero-of-dragon-age-origins-back-for-veilguard-but-with-a-horrifying-catch-do-not-let-her-see-me-like-this](https://www.pcgamer.com/games/dragon-age/bioware-considered-bringing-the-hero-of-dragon-age-origins-back-for-veilguard-but-with-a-horrifying-catch-do-not-let-her-see-me-like-this)
 - RSS feed: $source
 - date published: 2024-12-21T22:47:11+00:00

BioWare loves doing horrible things to old Dragon Age protagonists.

## Stardew Valley patch fixes swears but you still can't get divorced
 - [https://www.pcgamer.com/games/life-sim/stardew-valley-patch-fixes-swears-but-you-still-cant-get-divorced](https://www.pcgamer.com/games/life-sim/stardew-valley-patch-fixes-swears-but-you-still-cant-get-divorced)
 - RSS feed: $source
 - date published: 2024-12-21T22:24:29+00:00

Sometimes bugs mean we get to run weird headlines.

## Total War will ditch blood packs, early-adopter faction DLC, and its launcher
 - [https://www.pcgamer.com/games/strategy/total-war-will-ditch-blood-packs-early-adopter-faction-dlc-and-its-launcher](https://www.pcgamer.com/games/strategy/total-war-will-ditch-blood-packs-early-adopter-faction-dlc-and-its-launcher)
 - RSS feed: $source
 - date published: 2024-12-21T22:18:06+00:00

You've got red on you.

## Best Tactics 2024: Tactical Breach Wizards
 - [https://www.pcgamer.com/games/strategy/best-tactics-2024-tactical-breach-wizards](https://www.pcgamer.com/games/strategy/best-tactics-2024-tactical-breach-wizards)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:00+00:00

Wizard casts defenestrate.

## The Allmother is dead, long live the Allmother!: Why 1000XResist is the best sci-fi story I've experienced in years
 - [https://www.pcgamer.com/games/adventure/the-allmother-is-dead-long-live-the-allmother-why-1000xresist-is-the-best-sci-fi-story-ive-experienced-in-years](https://www.pcgamer.com/games/adventure/the-allmother-is-dead-long-live-the-allmother-why-1000xresist-is-the-best-sci-fi-story-ive-experienced-in-years)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:00+00:00

Like tears in rain.

## Voin has the power of a god, anime and black metal album cover art on its side
 - [https://www.pcgamer.com/games/action/voin-has-the-power-of-a-god-anime-and-black-metal-album-cover-art-on-its-side](https://www.pcgamer.com/games/action/voin-has-the-power-of-a-god-anime-and-black-metal-album-cover-art-on-its-side)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:00+00:00

The first-person action RPG makes a spectacularly metal early access debut.

## A part of my brain will always be dedicated to the time someone in the Vatican pirated Football Manager 2013
 - [https://www.pcgamer.com/games/sports/a-part-of-my-brain-will-always-be-dedicated-to-the-time-someone-in-the-vatican-pirated-football-manager-2013](https://www.pcgamer.com/games/sports/a-part-of-my-brain-will-always-be-dedicated-to-the-time-someone-in-the-vatican-pirated-football-manager-2013)
 - RSS feed: $source
 - date published: 2024-12-21T13:00:00+00:00

You know it’s not the Pope, but your head goes there all the same.

## Today's Wordle answer for Saturday, December 21
 - [https://www.pcgamer.com/games/puzzle/wordle-answer-today-december-21-2024](https://www.pcgamer.com/games/puzzle/wordle-answer-today-december-21-2024)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:36+00:00

Get all the help you need with today's Wordle.

## Even without Hollow Knight: Silksong, these 10 games prove that 2024 might just be the best Metroidvania year ever
 - [https://www.pcgamer.com/games/best-metroidvania-games-2024](https://www.pcgamer.com/games/best-metroidvania-games-2024)
 - RSS feed: $source
 - date published: 2024-12-21T01:52:35+00:00

Who needs Silksong anyways?

## Free games to grab over the holidays
 - [https://www.pcgamer.com/games/free-games-holidays-2024](https://www.pcgamer.com/games/free-games-holidays-2024)
 - RSS feed: $source
 - date published: 2024-12-21T00:18:21+00:00

New and old free and free-to-play games to pick up during the season of giving, for instance if you gave too much and now have no money.

## Mariah Carey was frozen in an ice block in Fortnite and then she thawed out and sang 'All I Want For Christmas Is You' and everyone went back to shooting each other
 - [https://www.pcgamer.com/games/fps/mariah-carey-fortnite-winterfest-christmas-event-start](https://www.pcgamer.com/games/fps/mariah-carey-fortnite-winterfest-christmas-event-start)
 - RSS feed: $source
 - date published: 2024-12-21T00:10:08+00:00

Fortnite's holiday event has begun.

