# Source:NBC tech, URL:https://feeds.nbcnews.com/nbcnews/public/tech, language:en-US

## Concerns grow in the US after attack on German Christmas market
 - [https://www.today.com/video/concerns-grow-in-the-us-after-attack-on-german-christmas-market-227656261878](https://www.today.com/video/concerns-grow-in-the-us-after-attack-on-german-christmas-market-227656261878)
 - RSS feed: $source
 - date published: 2024-12-21T12:45:50+00:00

Evy Poumpouras, a former Secret Service agent and current NBC News law enforcement analyst, joins TODAY to talk about rising concerns for safety in the U.S. after a vehicle plowed into a crowd at a German Christmas market.

## Biden expected to sign short-term funding bill to keep the government open
 - [https://www.today.com/video/biden-expected-to-sign-short-term-funding-bill-to-keep-the-government-open-227654213672](https://www.today.com/video/biden-expected-to-sign-short-term-funding-bill-to-keep-the-government-open-227654213672)
 - RSS feed: $source
 - date published: 2024-12-21T12:33:18+00:00

President Biden is expected to sign the revised funding bill that lawmakers in the House and Senate agreed would keep the government open even though it doesn’t include everything he wanted. NBC’s Aaron Gilchrist reports for TODAY.

## AI traffic cameras could be watching you on the road
 - [https://www.nbcnews.com/tech/security/ai-traffic-cameras-watching-road-rcna184169](https://www.nbcnews.com/tech/security/ai-traffic-cameras-watching-road-rcna184169)
 - RSS feed: $source
 - date published: 2024-12-21T12:00:00+00:00

Police around the world using AI-powered cameras to crack down on behavior like texting behind the wheel and driving without a seatbelt.

## How false claims that the Madison school shooter was transgender spread online
 - [https://www.nbcnews.com/tech/internet/madison-school-shooting-shooter-natalie-samantha-rupnow-female-trans-rcna184584](https://www.nbcnews.com/tech/internet/madison-school-shooting-shooter-natalie-samantha-rupnow-female-trans-rcna184584)
 - RSS feed: $source
 - date published: 2024-12-21T02:31:51+00:00

It’s become common for anti-trans social media users to quickly spread false or unverified claims about the gender identities of shooting suspects.

