# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## YouTube Channels Are Being Hacked…
 - [https://www.youtube.com/watch?v=zXWfpehUUqs](https://www.youtube.com/watch?v=zXWfpehUUqs)
 - RSS feed: $source
 - date published: 2024-12-21T00:36:53+00:00

Hello guys and gals, it's me Mutahar again! In the last few days I've been working behind the scenes trying to figure out a mass wave of YouTube hijacking from accounts of all sizes. This month is the period where tons of channels get hacked and it's time to figure out why but also how to avoid all these pitfalls in the future. Thanks for watching!
Like, Comment and Subscribe for more videos!

