# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## A Data Table Thousands of Years Old (2020)
 - [https://www.datafix.com.au/BASHing/2020-08-12.html](https://www.datafix.com.au/BASHing/2020-08-12.html)
 - RSS feed: $source
 - date published: 2024-12-21T22:25:37+00:00

<p>Article URL: <a href="https://www.datafix.com.au/BASHing/2020-08-12.html">https://www.datafix.com.au/BASHing/2020-08-12.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42482829">https://news.ycombinator.com/item?id=42482829</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Magical Thinking: Edward Bellamy's Looking Backward (2011)
 - [https://www.laphamsquarterly.org/future/magical-thinking](https://www.laphamsquarterly.org/future/magical-thinking)
 - RSS feed: $source
 - date published: 2024-12-21T21:54:01+00:00

<p>Article URL: <a href="https://www.laphamsquarterly.org/future/magical-thinking">https://www.laphamsquarterly.org/future/magical-thinking</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42482635">https://news.ycombinator.com/item?id=42482635</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Singlefile: A web extension to save a complete web page into a single HTML file
 - [https://github.com/gildas-lormeau/SingleFile](https://github.com/gildas-lormeau/SingleFile)
 - RSS feed: $source
 - date published: 2024-12-21T19:33:15+00:00

<p>Article URL: <a href="https://github.com/gildas-lormeau/SingleFile">https://github.com/gildas-lormeau/SingleFile</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42481659">https://news.ycombinator.com/item?id=42481659</a></p>
<p>Points: 49</p>
<p># Comments: 19</p>

## Dividing unsigned 8-bit numbers
 - [http://0x80.pl/notesen/2024-12-21-uint8-division.html](http://0x80.pl/notesen/2024-12-21-uint8-division.html)
 - RSS feed: $source
 - date published: 2024-12-21T19:25:13+00:00

<p>Article URL: <a href="http://0x80.pl/notesen/2024-12-21-uint8-division.html">http://0x80.pl/notesen/2024-12-21-uint8-division.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42481612">https://news.ycombinator.com/item?id=42481612</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Gazzetta, an RSS Reader for Mastodon
 - [https://primatology.xyz/blog/introducing-gazzetta](https://primatology.xyz/blog/introducing-gazzetta)
 - RSS feed: $source
 - date published: 2024-12-21T17:20:12+00:00

<p>Article URL: <a href="https://primatology.xyz/blog/introducing-gazzetta">https://primatology.xyz/blog/introducing-gazzetta</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42480885">https://news.ycombinator.com/item?id=42480885</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Show HN: Eonfall – A new third-person co-op action game built for the web
 - [https://eonfall.com](https://eonfall.com)
 - RSS feed: $source
 - date published: 2024-12-21T16:45:36+00:00

<p>Hi all, I'm excited to share Eonfall with Hacker News Community!<p>It's been 2-years in the making built by a 2 man team. Eonfall, is a new third-person co-op action game with rogue-lite elements built exclusively for the web! We've finally reached a release candidate state and set our official public release date for Jan 15th! The game's current version 5.0.0-beta is live and available to test play today!<p>Unity game engine was used to develop the game along with other services to handle the backend, and Nuxt 3 + Nuxt UI to handle the front-end.<p>We welcome any and all questions, feedback & suggestions!<p>Thanks all, Jon</p>
<hr>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42480624">https://news.ycombinator.com/item?id=42480624</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## The NBA's Problem Is Economics, Not Basketball
 - [https://www.bloomberg.com/opinion/articles/2024-12-18/nba-cup-the-league-s-problem-is-economics-not-basketball](https://www.bloomberg.com/opinion/articles/2024-12-18/nba-cup-the-league-s-problem-is-economics-not-basketball)
 - RSS feed: $source
 - date published: 2024-12-21T15:28:22+00:00

<p>Article URL: <a href="https://www.bloomberg.com/opinion/articles/2024-12-18/nba-cup-the-league-s-problem-is-economics-not-basketball">https://www.bloomberg.com/opinion/articles/2024-12-18/nba-cup-the-league-s-problem-is-economics-not-basketball</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42480176">https://news.ycombinator.com/item?id=42480176</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Introducing S2
 - [https://s2.dev/blog/intro](https://s2.dev/blog/intro)
 - RSS feed: $source
 - date published: 2024-12-21T15:11:19+00:00

<p>Article URL: <a href="https://s2.dev/blog/intro">https://s2.dev/blog/intro</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42480105">https://news.ycombinator.com/item?id=42480105</a></p>
<p>Points: 58</p>
<p># Comments: 11</p>

## An academic Great Gatsby Curve – How much academic success is inherited?
 - [https://blogs.lse.ac.uk/impactofsocialsciences/2024/10/21/an-academic-great-gatsby-curve-how-much-academic-success-inherited](https://blogs.lse.ac.uk/impactofsocialsciences/2024/10/21/an-academic-great-gatsby-curve-how-much-academic-success-inherited)
 - RSS feed: $source
 - date published: 2024-12-21T14:42:56+00:00

<p>Article URL: <a href="https://blogs.lse.ac.uk/impactofsocialsciences/2024/10/21/an-academic-great-gatsby-curve-how-much-academic-success-inherited/">https://blogs.lse.ac.uk/impactofsocialsciences/2024/10/21/an-academic-great-gatsby-curve-how-much-academic-success-inherited/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42479958">https://news.ycombinator.com/item?id=42479958</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Escaping Google's Manual Reputation Penalty and Resuming Business as Usual
 - [https://recleudo.com/under-googles-watchfull-eye-getting-out-of-a-manual-site-reputation-abuse-penalty-and-continuing-business-as-usual](https://recleudo.com/under-googles-watchfull-eye-getting-out-of-a-manual-site-reputation-abuse-penalty-and-continuing-business-as-usual)
 - RSS feed: $source
 - date published: 2024-12-21T14:24:53+00:00

<p>Article URL: <a href="https://recleudo.com/under-googles-watchfull-eye-getting-out-of-a-manual-site-reputation-abuse-penalty-and-continuing-business-as-usual/">https://recleudo.com/under-googles-watchfull-eye-getting-out-of-a-manual-site-reputation-abuse-penalty-and-continuing-business-as-usual/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42479866">https://news.ycombinator.com/item?id=42479866</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## Query Apple's FindMy Network with Python
 - [https://github.com/malmeloo/FindMy.py](https://github.com/malmeloo/FindMy.py)
 - RSS feed: $source
 - date published: 2024-12-21T12:14:55+00:00

<p>Article URL: <a href="https://github.com/malmeloo/FindMy.py">https://github.com/malmeloo/FindMy.py</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42479233">https://news.ycombinator.com/item?id=42479233</a></p>
<p>Points: 17</p>
<p># Comments: 14</p>

## Why eating less slows ageing: this molecule is key
 - [https://www.nature.com/articles/d41586-024-04220-5](https://www.nature.com/articles/d41586-024-04220-5)
 - RSS feed: $source
 - date published: 2024-12-21T11:10:59+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-024-04220-5">https://www.nature.com/articles/d41586-024-04220-5</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42478962">https://news.ycombinator.com/item?id=42478962</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Kannel: Open-Source WAP and SMS Gateway
 - [https://www.kannel.org/overview.shtml](https://www.kannel.org/overview.shtml)
 - RSS feed: $source
 - date published: 2024-12-21T10:15:11+00:00

<p>Article URL: <a href="https://www.kannel.org/overview.shtml">https://www.kannel.org/overview.shtml</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42478728">https://news.ycombinator.com/item?id=42478728</a></p>
<p>Points: 13</p>
<p># Comments: 4</p>

## UK Gov Open Consultation: Copyright and Artificial Intelligence
 - [https://www.gov.uk/government/consultations/copyright-and-artificial-intelligence](https://www.gov.uk/government/consultations/copyright-and-artificial-intelligence)
 - RSS feed: $source
 - date published: 2024-12-21T09:10:32+00:00

<p>Article URL: <a href="https://www.gov.uk/government/consultations/copyright-and-artificial-intelligence">https://www.gov.uk/government/consultations/copyright-and-artificial-intelligence</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42478430">https://news.ycombinator.com/item?id=42478430</a></p>
<p>Points: 13</p>
<p># Comments: 1</p>

## The Christmas story of one tube station's 'Mind the Gap' voice (2019)
 - [https://www.theguardian.com/cities/2019/dec/25/the-christmas-story-of-one-tube-stations-mind-the-gap-voice](https://www.theguardian.com/cities/2019/dec/25/the-christmas-story-of-one-tube-stations-mind-the-gap-voice)
 - RSS feed: $source
 - date published: 2024-12-21T09:07:45+00:00

<p>Article URL: <a href="https://www.theguardian.com/cities/2019/dec/25/the-christmas-story-of-one-tube-stations-mind-the-gap-voice">https://www.theguardian.com/cities/2019/dec/25/the-christmas-story-of-one-tube-stations-mind-the-gap-voice</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42478414">https://news.ycombinator.com/item?id=42478414</a></p>
<p>Points: 4</p>
<p># Comments: 2</p>

## The Ugly Truth About Spotify Is Finally Revealed
 - [https://www.honest-broker.com/p/the-ugly-truth-about-spotify-is-finally](https://www.honest-broker.com/p/the-ugly-truth-about-spotify-is-finally)
 - RSS feed: $source
 - date published: 2024-12-21T07:45:28+00:00

<p>Article URL: <a href="https://www.honest-broker.com/p/the-ugly-truth-about-spotify-is-finally">https://www.honest-broker.com/p/the-ugly-truth-about-spotify-is-finally</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42478107">https://news.ycombinator.com/item?id=42478107</a></p>
<p>Points: 40</p>
<p># Comments: 7</p>

## Show HN:Free Online Tool to Experience Microsoft's MarkItdown
 - [https://markitdown.pro](https://markitdown.pro)
 - RSS feed: $source
 - date published: 2024-12-21T05:13:33+00:00

<p>Article URL: <a href="https://markitdown.pro">https://markitdown.pro</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42477685">https://news.ycombinator.com/item?id=42477685</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Britannica Didn’t Just Survive. It’s an A.I. Company Now.
 - [https://www.nytimes.com/2024/12/20/business/dealbook/britannica-artificial-intelligence.html](https://www.nytimes.com/2024/12/20/business/dealbook/britannica-artificial-intelligence.html)
 - RSS feed: $source
 - date published: 2024-12-21T04:32:23+00:00

<p>Article URL: <a href="https://www.nytimes.com/2024/12/20/business/dealbook/britannica-artificial-intelligence.html">https://www.nytimes.com/2024/12/20/business/dealbook/britannica-artificial-intelligence.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42477564">https://news.ycombinator.com/item?id=42477564</a></p>
<p>Points: 4</p>
<p># Comments: 3</p>

## Enum of Arrays
 - [https://tigerbeetle.com/blog/2024-12-19-enum-of-arrays](https://tigerbeetle.com/blog/2024-12-19-enum-of-arrays)
 - RSS feed: $source
 - date published: 2024-12-21T01:49:25+00:00

<p>Article URL: <a href="https://tigerbeetle.com/blog/2024-12-19-enum-of-arrays/">https://tigerbeetle.com/blog/2024-12-19-enum-of-arrays/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=42476876">https://news.ycombinator.com/item?id=42476876</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

