# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Luke Littler vs Ryan Meikle: Latest updates from World Darts Championship
 - [https://www.telegraph.co.uk/darts/2024/12/21/luke-littler-vs-ryan-meikle-live-world-darts-championship](https://www.telegraph.co.uk/darts/2024/12/21/luke-littler-vs-ryan-meikle-live-world-darts-championship)
 - RSS feed: $source
 - date published: 2024-12-21T20:43:05+00:00

None

## Tyson Fury vs Oleksandr Usyk 2 live: Latest fight updates and undercard results
 - [https://www.telegraph.co.uk/boxing/2024/12/21/fury-vs-usyk-2-live-boxing-fight-updates-undercard-results](https://www.telegraph.co.uk/boxing/2024/12/21/fury-vs-usyk-2-live-boxing-fight-updates-undercard-results)
 - RSS feed: $source
 - date published: 2024-12-21T18:42:51+00:00

<![CDATA[<p><a class="ck-custom-link" href="https://www.telegraph.co.uk/tyson-fury/">Tyson Fury</a> seeks revenge against <a class="ck-custom-link" href="https://www.telegraph.co.uk/oleksandr-usyk/">Oleksandr Usyk</a> in Riyadh, Saudi Arabia, as the two heavyweight boxers <a class="ck-custom-link" href="https://www.telegraph.co.uk/boxing/2024/12/21/tyson-fury-vs-oleksandr-usyk-when-date-tv-undercard/">go toe-to-toe for the second time</a>.</p>]]>

## Crystal Palace vs Arsenal: Score and latest Premier League updates
 - [https://www.telegraph.co.uk/football/2024/12/21/crystal-palace-vs-arsenal-live-score-latest-premier-league](https://www.telegraph.co.uk/football/2024/12/21/crystal-palace-vs-arsenal-live-score-latest-premier-league)
 - RSS feed: $source
 - date published: 2024-12-21T16:26:35+00:00

None

## Leicester Tigers v Bristol Bears: Score and latest updates from the Premiership
 - [https://www.telegraph.co.uk/rugby-union/2024/12/21/leicester-tigers-v-bristol-live-score-latest-premiership](https://www.telegraph.co.uk/rugby-union/2024/12/21/leicester-tigers-v-bristol-live-score-latest-premiership)
 - RSS feed: $source
 - date published: 2024-12-21T14:18:52+00:00

None

## A military deployment gave me PTSD. My service dog saved me
 - [https://www.telegraph.co.uk/christmas/2024/12/21/ptsd-army-benevolent-fund-support-dog](https://www.telegraph.co.uk/christmas/2024/12/21/ptsd-army-benevolent-fund-support-dog)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:00+00:00

<![CDATA[I was proud to serve my country, but I didn&rsquo;t understand why my life was crumbling &ndash; that&rsquo;s where the Army Development Fund stepped in]]>

## Premier League latest: Lineups and news before 3pm kick-offs
 - [https://www.telegraph.co.uk/football/2024/12/21/premier-league-live-score-updates-newcastle-west-ham-forest](https://www.telegraph.co.uk/football/2024/12/21/premier-league-live-score-updates-newcastle-west-ham-forest)
 - RSS feed: $source
 - date published: 2024-12-21T13:51:00+00:00

None

## Aston Villa vs Manchester City: Latest Premier League news and lineups from Villa Park
 - [https://www.telegraph.co.uk/football/2024/12/21/aston-villa-vs-man-city-live-score-latest-premier-league](https://www.telegraph.co.uk/football/2024/12/21/aston-villa-vs-man-city-live-score-latest-premier-league)
 - RSS feed: $source
 - date published: 2024-12-21T11:59:33+00:00

None

## How to cheat at all your favourite board games
 - [https://www.telegraph.co.uk/christmas/2024/12/21/how-to-cheat-board-games](https://www.telegraph.co.uk/christmas/2024/12/21/how-to-cheat-board-games)
 - RSS feed: $source
 - date published: 2024-12-21T11:00:00+00:00

<![CDATA[With over three-quarters of Britons admitting to &lsquo;bending the rules&rsquo;, here&rsquo;s how to be victorious this Christmas &ndash; whatever it takes]]>

## Fury vs Usyk 2: What time is tonight’s fight, how to watch and who is on the undercard
 - [https://www.telegraph.co.uk/boxing/2024/12/21/tyson-fury-vs-oleksandr-usyk-when-date-tv-undercard](https://www.telegraph.co.uk/boxing/2024/12/21/tyson-fury-vs-oleksandr-usyk-when-date-tv-undercard)
 - RSS feed: $source
 - date published: 2024-12-21T10:15:16+00:00

<![CDATA[Plus: what the fighters are saying in the build-up to Saturday&rsquo;s fight, the clash of styles and their respective records]]>

## Rabid seas: South African beach goers warned to watch out for seals infected with deadly virus
 - [https://www.telegraph.co.uk/global-health/science-and-disease/rabid-seals-south-african-beach-goers-warned-disease](https://www.telegraph.co.uk/global-health/science-and-disease/rabid-seals-south-african-beach-goers-warned-disease)
 - RSS feed: $source
 - date published: 2024-12-21T08:00:00+00:00

<![CDATA[Long tormented by great white sharks, now surfers and swimmers in the Cape are being attacked by crazed seals carrying the deadly virus]]>

## Israel-Hamas war latest: Missile hits Tel Aviv
 - [https://www.telegraph.co.uk/world-news/2024/12/21/israel-hamas-gaza-war-iran-yemen-tel-aviv-latest](https://www.telegraph.co.uk/world-news/2024/12/21/israel-hamas-gaza-war-iran-yemen-tel-aviv-latest)
 - RSS feed: $source
 - date published: 2024-12-21T03:19:42+00:00

<![CDATA[<p>At least 14 people were injured in a missile strike on Tel Aviv, the economic centre of Israel, in the early hours of Saturday.</p>]]>

