# Source:Hackaday, URL:https://hackaday.com/feed, language:en-US

## The Bendix G-15 Runs 75,000 Lines of Code
 - [https://hackaday.com/2024/12/21/the-bendix-g-15-runs-75000-lines-of-code](https://hackaday.com/2024/12/21/the-bendix-g-15-runs-75000-lines-of-code)
 - RSS feed: $source
 - date published: 2024-12-21T21:00:10+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/12/maxresdefault.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/12/maxresdefault.jpg 1280w, https://hackaday.com/wp-content/uploads/2024/12/maxresdefault.jpg?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/12/maxresdefault.jpg?resize=400,225 400w, https://hackaday.com/wp-content/uploads/2024/12/maxresdefault.jpg?resize=800,450 800w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="737730" data-permalink="https://hackaday.com/2024/12/21/the-bendix-g-15-runs-75000-lines-of-code/maxresdefault-56/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/12/maxresdefault.jpg" data-orig-size="1280,720" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;ca

## Custom Firmware For Even Cheaper Bluetooth Thermometers
 - [https://hackaday.com/2024/12/21/custom-firmware-for-even-cheaper-bluetooth-thermometers](https://hackaday.com/2024/12/21/custom-firmware-for-even-cheaper-bluetooth-thermometers)
 - RSS feed: $source
 - date published: 2024-12-21T18:00:54+00:00

<div><img width="800" height="440" src="https://hackaday.com/wp-content/uploads/2024/12/tuyatemp_feat.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/12/tuyatemp_feat.jpg 1000w, https://hackaday.com/wp-content/uploads/2024/12/tuyatemp_feat.jpg?resize=250,138 250w, https://hackaday.com/wp-content/uploads/2024/12/tuyatemp_feat.jpg?resize=400,220 400w, https://hackaday.com/wp-content/uploads/2024/12/tuyatemp_feat.jpg?resize=800,440 800w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="739573" data-permalink="https://hackaday.com/2024/12/21/custom-firmware-for-even-cheaper-bluetooth-thermometers/tuyatemp_feat/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/12/tuyatemp_feat.jpg" data-orig-size="1000,550" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&qu

## Intel Terminates X86S Initiative After Formation of New Industry Group
 - [https://hackaday.com/2024/12/21/intel-terminates-x86s-initiative-after-formation-of-new-industry-group](https://hackaday.com/2024/12/21/intel-terminates-x86s-initiative-after-formation-of-new-industry-group)
 - RSS feed: $source
 - date published: 2024-12-21T15:00:00+00:00

<div><img width="800" height="484" src="https://hackaday.com/wp-content/uploads/2018/01/intel.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2018/01/intel.jpg 800w, https://hackaday.com/wp-content/uploads/2018/01/intel.jpg?resize=250,151 250w, https://hackaday.com/wp-content/uploads/2018/01/intel.jpg?resize=400,242 400w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="289159" data-permalink="https://hackaday.com/2018/01/05/lets-talk-intel-meltdown-and-spectre/intel-3/" data-orig-file="https://hackaday.com/wp-content/uploads/2018/01/intel.jpg" data-orig-size="800,484" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&quot;:&quot;&quot;,&quot;

## Building A Custom Swiss Army Knife
 - [https://hackaday.com/2024/12/21/building-a-custom-swiss-army-knife](https://hackaday.com/2024/12/21/building-a-custom-swiss-army-knife)
 - RSS feed: $source
 - date published: 2024-12-21T12:00:25+00:00

<div><img width="800" height="449" src="https://hackaday.com/wp-content/uploads/2024/12/edited-e1734590982109.jpg?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" data-attachment-id="739122" data-permalink="https://hackaday.com/2024/12/21/building-a-custom-swiss-army-knife/edited/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/12/edited-e1734590982109.jpg" data-orig-size="3075,1727" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;1.8&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;Galaxy Z Fold6&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;1734467471&quot;,&quot;copyright&quot;:&quot;&quot;,&quot;focal_length&quot;:&quot;5.4&quot;,&quot;iso&quot;:&quot;50&quot;,&quot;shutter_speed&quot;:&quot;0.0022522522522523&quot;,&quot;title&quot;:&quot;&quot;,&quot;orientation&quot;:&quot;1&quot;}" data-image-title="ed

## Training a Self-Driving Kart
 - [https://hackaday.com/2024/12/21/__trashed-11](https://hackaday.com/2024/12/21/__trashed-11)
 - RSS feed: $source
 - date published: 2024-12-21T09:00:03+00:00

<div><img width="800" height="607" src="https://hackaday.com/wp-content/uploads/2024/12/self-driving-main.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/12/self-driving-main.png 968w, https://hackaday.com/wp-content/uploads/2024/12/self-driving-main.png?resize=250,190 250w, https://hackaday.com/wp-content/uploads/2024/12/self-driving-main.png?resize=400,303 400w, https://hackaday.com/wp-content/uploads/2024/12/self-driving-main.png?resize=800,607 800w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="737155" data-permalink="https://hackaday.com/2024/12/21/__trashed-11/self-driving-main-2/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/12/self-driving-main.png" data-orig-size="968,734" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camer

## 3D Printing a Big LEGO Christmas Tree
 - [https://hackaday.com/2024/12/20/3d-printing-a-big-lego-christmas-tree](https://hackaday.com/2024/12/20/3d-printing-a-big-lego-christmas-tree)
 - RSS feed: $source
 - date published: 2024-12-21T06:00:24+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/12/Making-a-Giant-Lego-Inspired-Christmas-Tree-23-50-screenshot.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/12/Making-a-Giant-Lego-Inspired-Christmas-Tree-23-50-screenshot.png 1920w, https://hackaday.com/wp-content/uploads/2024/12/Making-a-Giant-Lego-Inspired-Christmas-Tree-23-50-screenshot.png?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/12/Making-a-Giant-Lego-Inspired-Christmas-Tree-23-50-screenshot.png?resize=400,225 400w, https://hackaday.com/wp-content/uploads/2024/12/Making-a-Giant-Lego-Inspired-Christmas-Tree-23-50-screenshot.png?resize=800,450 800w, https://hackaday.com/wp-content/uploads/2024/12/Making-a-Giant-Lego-Inspired-Christmas-Tree-23-50-screenshot.png?resize=1536,864 1536w" sizes="(max-width: 800px) 100vw,

## It’s Official: The North Pole is Moving
 - [https://hackaday.com/2024/12/20/its-official-the-north-pole-is-moving](https://hackaday.com/2024/12/20/its-official-the-north-pole-is-moving)
 - RSS feed: $source
 - date published: 2024-12-21T03:00:25+00:00

<div><img width="800" height="477" src="https://hackaday.com/wp-content/uploads/2024/12/wmm.png?w=800" class="attachment-large size-large wp-post-image" alt="" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/12/wmm.png 800w, https://hackaday.com/wp-content/uploads/2024/12/wmm.png?resize=250,149 250w, https://hackaday.com/wp-content/uploads/2024/12/wmm.png?resize=400,239 400w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="739593" data-permalink="https://hackaday.com/2024/12/20/its-official-the-north-pole-is-moving/wmm/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/12/wmm.png" data-orig-size="800,477" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&quot;:&quot;&quot;,&quot;focal_length&

## Rudolph’s Sleigh on a North Pole PCB
 - [https://hackaday.com/2024/12/20/rudolphs-sleigh-on-a-north-pole-pcb](https://hackaday.com/2024/12/20/rudolphs-sleigh-on-a-north-pole-pcb)
 - RSS feed: $source
 - date published: 2024-12-21T00:00:46+00:00

<div><img width="800" height="450" src="https://hackaday.com/wp-content/uploads/2024/12/santa-sleigh-pcb-1200.jpg?w=800" class="attachment-large size-large wp-post-image" alt="pcb with santa sleigh racing circuit" style="margin: 0 auto; margin-bottom: 15px;" decoding="async" fetchpriority="high" srcset="https://hackaday.com/wp-content/uploads/2024/12/santa-sleigh-pcb-1200.jpg 1200w, https://hackaday.com/wp-content/uploads/2024/12/santa-sleigh-pcb-1200.jpg?resize=250,141 250w, https://hackaday.com/wp-content/uploads/2024/12/santa-sleigh-pcb-1200.jpg?resize=400,225 400w, https://hackaday.com/wp-content/uploads/2024/12/santa-sleigh-pcb-1200.jpg?resize=800,450 800w" sizes="(max-width: 800px) 100vw, 800px" data-attachment-id="739503" data-permalink="https://hackaday.com/2024/12/20/rudolphs-sleigh-on-a-north-pole-pcb/santa-sleigh-pcb-1200/" data-orig-file="https://hackaday.com/wp-content/uploads/2024/12/santa-sleigh-pcb-1200.jpg" data-orig-size="1200,675" data-comments-opened="1" data-imag

