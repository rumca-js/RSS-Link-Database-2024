# Source:Amiga, URL:https://www.reddit.com/r/amiga/.rss, language:en

## Does your fave Amiga game make this list of the Top 10 Amiga Games Ever Made?! Any surprise choices, or is this a fair rundown of the best games?
 - [https://www.reddit.com/r/amiga/comments/1hjelpt/does_your_fave_amiga_game_make_this_list_of_the](https://www.reddit.com/r/amiga/comments/1hjelpt/does_your_fave_amiga_game_make_this_list_of_the)
 - RSS feed: $source
 - date published: 2024-12-21T17:29:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1hjelpt/does_your_fave_amiga_game_make_this_list_of_the/"> <img src="https://external-preview.redd.it/Rh2_BwpgNsbt4HUEJXTYd2jOTUtLf1FwyvD2bYFXc_g.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=5e92fc292175555b7f7c3b151b32333a016c62c0" alt="Does your fave Amiga game make this list of the Top 10 Amiga Games Ever Made?! Any surprise choices, or is this a fair rundown of the best games?" title="Does your fave Amiga game make this list of the Top 10 Amiga Games Ever Made?! Any surprise choices, or is this a fair rundown of the best games?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/adrianoarcade"> /u/adrianoarcade </a> <br/> <span><a href="https://www.youtube.com/watch?v=1yfL2Jh0UiY">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1hjelpt/does_your_fave_amiga_game_make_this_list_of_the/">[comments]</a></span> </td></tr></table>

## Have anyone here used an AI told (GPT etc) to create anything on their Amiga?
 - [https://www.reddit.com/r/amiga/comments/1hj7bzt/have_anyone_here_used_an_ai_told_gpt_etc_to](https://www.reddit.com/r/amiga/comments/1hj7bzt/have_anyone_here_used_an_ai_told_gpt_etc_to)
 - RSS feed: $source
 - date published: 2024-12-21T10:37:58+00:00

<!-- SC_OFF --><div class="md"><p>If so was it code in AmigaBasic, Assembly, C, Blitz, Amos or something else? Did it go well? What did you make? I&#39;d like to do it as I&#39;m not great at coding but, like all of you, I love my Amiga! It&#39;s probably the dream of all us who were more into games and just high level tinkering on DP and Octamed etc to make more and better things.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MultipleScoregasm"> /u/MultipleScoregasm </a> <br/> <span><a href="https://www.reddit.com/r/amiga/comments/1hj7bzt/have_anyone_here_used_an_ai_told_gpt_etc_to/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1hj7bzt/have_anyone_here_used_an_ai_told_gpt_etc_to/">[comments]</a></span>

## Who feels like playing Cannon Fodder again?
 - [https://www.reddit.com/r/amiga/comments/1hj6rrf/who_feels_like_playing_cannon_fodder_again](https://www.reddit.com/r/amiga/comments/1hj6rrf/who_feels_like_playing_cannon_fodder_again)
 - RSS feed: $source
 - date published: 2024-12-21T09:55:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1hj6rrf/who_feels_like_playing_cannon_fodder_again/"> <img src="https://external-preview.redd.it/mgqO-_dhOjXNha5KUHcBRqvJ6V6sjI_GSQActX99NDw.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=65f33a77f71914776d383e0f04f32137f557dfef" alt="Who feels like playing Cannon Fodder again?" title="Who feels like playing Cannon Fodder again?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Aletaletavernsim"> /u/Aletaletavernsim </a> <br/> <span><a href="https://www.youtube.com/watch?v=XdPpU6Nf1Jg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1hj6rrf/who_feels_like_playing_cannon_fodder_again/">[comments]</a></span> </td></tr></table>

## Hide Ownership Information screen on DPaint V
 - [https://www.reddit.com/r/amiga/comments/1hj64vh/hide_ownership_information_screen_on_dpaint_v](https://www.reddit.com/r/amiga/comments/1hj64vh/hide_ownership_information_screen_on_dpaint_v)
 - RSS feed: $source
 - date published: 2024-12-21T09:05:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1hj64vh/hide_ownership_information_screen_on_dpaint_v/"> <img src="https://b.thumbs.redditmedia.com/x0ncEXI0qomq9tM1uf6nJqqrnvY5wYqMhnFlc2X-lCM.jpg" alt="Hide Ownership Information screen on DPaint V" title="Hide Ownership Information screen on DPaint V" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Does anyone know how to hide this screen every time DPaint V starts up? I have look in tool types and settings, I even checked the manual but can find nothing about it anywhere.</p> <p><a href="https://preview.redd.it/xufz7ghi368e1.jpg?width=600&amp;format=pjpg&amp;auto=webp&amp;s=7eca77d9e088d3fbb35a94fe2c532e23de657d5a">https://preview.redd.it/xufz7ghi368e1.jpg?width=600&amp;format=pjpg&amp;auto=webp&amp;s=7eca77d9e088d3fbb35a94fe2c532e23de657d5a</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/manic232"> /u/manic232 </a> <br/> <span><a href="https://www.reddit.com/r/amiga/c

## Help me find the battleships type game
 - [https://www.reddit.com/r/amiga/comments/1hixhep/help_me_find_the_battleships_type_game](https://www.reddit.com/r/amiga/comments/1hixhep/help_me_find_the_battleships_type_game)
 - RSS feed: $source
 - date published: 2024-12-21T00:05:28+00:00

<!-- SC_OFF --><div class="md"><p>Hi all, back in the 90s I remember playing a battleships style game that had the traditional grid from this type of game, it featured bouncing bombs and Exocet missiles as some of your weapons. I think it was a magazine cover disk game in the UK but I may be wrong on that. Does anyone have any idea what it was called. I&#39;d love to play it again! It&#39;s not battleships or battleships II. I&#39;m really struggling to find any info</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/One-Experience-6663"> /u/One-Experience-6663 </a> <br/> <span><a href="https://www.reddit.com/r/amiga/comments/1hixhep/help_me_find_the_battleships_type_game/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1hixhep/help_me_find_the_battleships_type_game/">[comments]</a></span>

