# Source:Second Wind, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC1wZGocgLvopgOqBUFCyIJA, language:en

## The Price of Victory | Adventure Is Nigh! - The Platinum Heart
 - [https://www.youtube.com/watch?v=LkbdJEvZ3W0](https://www.youtube.com/watch?v=LkbdJEvZ3W0)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:16+00:00

The beast is... slain... and the day is... won? Nothing left but to reap the rewards. Glad we've reached the end of such a harrowing adventure.

Get your Adventure Is Nigh! merch at:
https://sharkrobot.com/collections/second-wind

Support us on Patreon: https://www.patreon.com/SecondWindGroup

