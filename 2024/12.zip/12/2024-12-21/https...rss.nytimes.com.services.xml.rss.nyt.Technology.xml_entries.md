# Source:NY times technology, URL:https://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Amazon Warehouse Workers in New York City Join Protest
 - [https://www.nytimes.com/2024/12/21/business/amazon-warehouse-staten-island-strike.html](https://www.nytimes.com/2024/12/21/business/amazon-warehouse-staten-island-strike.html)
 - RSS feed: $source
 - date published: 2024-12-21T16:15:19+00:00

The workers’ union hopes that adding employees at the Staten Island warehouse to a protest started by delivery drivers will increase pressure on Amazon.

## Google Antitrust Case: Why Chrome May Be Sold and What Happens Next
 - [https://www.nytimes.com/2024/12/20/technology/google-antitrust-case-chrome.html](https://www.nytimes.com/2024/12/20/technology/google-antitrust-case-chrome.html)
 - RSS feed: $source
 - date published: 2024-12-21T03:35:22+00:00

The federal judge who ruled Google was a monopolist in search is weighing his options to fix the monopoly. Here’s what happens now.

