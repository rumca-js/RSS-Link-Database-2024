# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## NPR Music's Sidney Madden says @temsbaby's 'Born in the Wild' is the 1️⃣ and not the 2️⃣
 - [https://www.youtube.com/watch?v=b28VcraZ6f0](https://www.youtube.com/watch?v=b28VcraZ6f0)
 - RSS feed: $source
 - date published: 2024-12-21T22:00:16+00:00

None

## @elmiene says you can add time traveller to his resume.
 - [https://www.youtube.com/watch?v=3-j-ESaA4hA](https://www.youtube.com/watch?v=3-j-ESaA4hA)
 - RSS feed: $source
 - date published: 2024-12-21T17:15:00+00:00

None

## #tinydesk •@wyattflores leads his band through their turn behind the Desk
 - [https://www.youtube.com/watch?v=FZVc6CiDCTU](https://www.youtube.com/watch?v=FZVc6CiDCTU)
 - RSS feed: $source
 - date published: 2024-12-21T13:00:17+00:00

None

## #tinydesk • The colorful @yogabbagabbacrew and their friend @thundercatmusic transform the Tiny Desk
 - [https://www.youtube.com/watch?v=K6aa6Oy0Oo0](https://www.youtube.com/watch?v=K6aa6Oy0Oo0)
 - RSS feed: $source
 - date published: 2024-12-21T01:00:12+00:00

None

