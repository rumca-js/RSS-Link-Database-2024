# Source:The Linux Experiment, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5UAwBUum7CPN5buc-_N1Fw, language:en-US

## Mozilla Ads and AI, EU investigates TikTok, Lenovo uses SteamOS: Linux & Open Source News
 - [https://www.youtube.com/watch?v=sIzz0l-6_Jk](https://www.youtube.com/watch?v=sIzz0l-6_Jk)
 - RSS feed: $source
 - date published: 2024-12-21T16:11:10+00:00

Check out TuxCare's partner Program to enrich your own Enterprise solutions: https://tuxcare.com/partners/?utm_campaign=The%20Linux%20Experiment&utm_source=youtube&utm_medium=social

Grab a brand new laptop or desktop running Linux: https://www.tuxedocomputers.com/en# 


👏 SUPPORT THE CHANNEL:
Get access to:
- a Daily Linux News show
- a weekly patroncast for more personal thoughts
- polls on the next topics I cover,
- your name in the credits

YouTube: https://www.youtube.com/@thelinuxexp/join
Patreon: https://www.patreon.com/thelinuxexperiment

Or, you can donate whatever you want:
https://paypal.me/thelinuxexp
Liberapay: https://liberapay.com/TheLinuxExperiment/

👕 GET TLE MERCH
Support the channel AND get cool new gear: https://the-linux-experiment.creator-spring.com/

🏆 FOLLOW ME ON THE FEDIVERSE:
Mastodon: https://mastodon.social/web/@thelinuxEXP
Pixelfed: https://pixelfed.social/TLENick
PeerTube: https://tilvids.com/c/thelinuxexperiment_channel/videos

🎙️ LINUX AND OPEN SOURCE

