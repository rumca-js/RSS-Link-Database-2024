# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Deion Sanders says he'll 'make sure' Travis Hunter plays offense and defense in NFL
 - [https://www.foxnews.com/sports/deion-sanders-says-hell-make-sure-travis-hunter-plays-offense-defense-nfl](https://www.foxnews.com/sports/deion-sanders-says-hell-make-sure-travis-hunter-plays-offense-defense-nfl)
 - RSS feed: $source
 - date published: 2024-12-21T17:55:25+00:00

Travis Hunter parlayed his offensive and defensive skill into winning the Heisman Trophy, and Deion Sanders said he&apos;ll &quot;make sure&quot; Hunter plays both sides of the ball in the NFL.

## Patrick Mahomes plays through ankle sprain to lead Chiefs to victory vs. Texans
 - [https://www.foxnews.com/sports/patrick-mahomes-chiefs-texans](https://www.foxnews.com/sports/patrick-mahomes-chiefs-texans)
 - RSS feed: $source
 - date published: 2024-12-21T16:42:32+00:00

Patrick Mahomes battled through an ankle sprain to deliver a 27-19 win over the Houston Texans and put the Chiefs one win away from a first-round bye.

## MSNBC hosts Ruhle and Reid taking pay cuts following major ratings slump: report
 - [https://www.foxnews.com/media/msnbc-hosts-ruhle-reid-taking-pay-cuts-following-major-ratings-slump-report](https://www.foxnews.com/media/msnbc-hosts-ruhle-reid-taking-pay-cuts-following-major-ratings-slump-report)
 - RSS feed: $source
 - date published: 2024-12-21T16:38:26+00:00

MSNBC hosts Stephanie Ruhle and Joy Reid are reportedly going to take pay cuts if they want to keep their anchor seats at the liberal news channel.

## Texans' Tank Dell suffers gruesome leg injury, leaving teammates in tears
 - [https://www.foxnews.com/sports/texans-tank-dell-suffers-gruesome-leg-injury-leaving-teammates-tears](https://www.foxnews.com/sports/texans-tank-dell-suffers-gruesome-leg-injury-leaving-teammates-tears)
 - RSS feed: $source
 - date published: 2024-12-21T15:27:34+00:00

Houston Texans wide receiver Tank Dell was taken off the field in an ambulance during Saturday’s game against the Kansas City Chiefs after suffering a gruesome leg injury while scoring a touchdown in the second half.

## Tom Cruise’s Christmas cakes gifted to ‘Top Gun: Maverick’ co-star, Hollywood friends on nice list
 - [https://www.foxnews.com/entertainment/tom-cruises-christmas-cakes-gifted-top-gun-maverick-hollywood](https://www.foxnews.com/entertainment/tom-cruises-christmas-cakes-gifted-top-gun-maverick-hollywood)
 - RSS feed: $source
 - date published: 2024-12-21T15:16:54+00:00

Hollywood actor Tom Cruise sent his annual holiday dessert, a coconut Christmas cake, to several of his A-list celebrity friends this season.

## Lawmakers react to stopgap funding and averting government shutdown
 - [https://www.foxnews.com/politics/lawmakers-react-stopgap-funding-averting-government-shutdown](https://www.foxnews.com/politics/lawmakers-react-stopgap-funding-averting-government-shutdown)
 - RSS feed: $source
 - date published: 2024-12-21T15:12:07+00:00

Lawmakers are having their say after President Biden signed a stopgap bill into law on Saturday, extending government funding into March and avoiding a shutdown.

## Trump nominates pair to help lead DOJ, announces Federal Railroad Administration pick
 - [https://www.foxnews.com/politics/trump-nominates-pair-help-lead-doj-announces-federal-railroad-administration-pick](https://www.foxnews.com/politics/trump-nominates-pair-help-lead-doj-announces-federal-railroad-administration-pick)
 - RSS feed: $source
 - date published: 2024-12-21T14:55:06+00:00

President-elect Trump announced Saturday Aaron Reitz, Chad Mizelle and David Fink will serve in various Department of Justice and Department of Transportation roles starting in January.

## Women's prayer group alleges harassment from pro-trans activists during 'Save Girls Sports' protests
 - [https://www.foxnews.com/sports/womens-prayer-group-alleges-harassment-from-pro-trans-activists-during-save-girls-sports-protests](https://www.foxnews.com/sports/womens-prayer-group-alleges-harassment-from-pro-trans-activists-during-save-girls-sports-protests)
 - RSS feed: $source
 - date published: 2024-12-21T14:54:30+00:00

A women&apos;s prayer group that attended the protests wearing &quot;Save Girls Sports&quot; shirts alleged the pro-transgender activists harassed them.

## Chiefs' Harrison Butker praises Trump pick for Vatican ambassador: 'A leading voice in the Catholic community'
 - [https://www.foxnews.com/sports/chiefs-harrison-butker-praises-trump-pick-vatican-ambassador-a-leading-voice-catholic-community](https://www.foxnews.com/sports/chiefs-harrison-butker-praises-trump-pick-vatican-ambassador-a-leading-voice-catholic-community)
 - RSS feed: $source
 - date published: 2024-12-21T14:33:07+00:00

Kansas City Chiefs kicker Harrison Butker voiced his support of CatholicVote President Brian Burch as the next U.S. ambassador to the Vatican in a post on social media Friday.

## 5 most surprising wedding stories of 2024: Which one takes top honors?
 - [https://www.foxnews.com/lifestyle/5-most-surprising-wedding-stories-2024-which-one-takes-top-honors](https://www.foxnews.com/lifestyle/5-most-surprising-wedding-stories-2024-which-one-takes-top-honors)
 - RSS feed: $source
 - date published: 2024-12-21T13:30:07+00:00

Here are five wild wedding stories from the past year that made people laugh, cry and even shake their heads in disbelief. Which of these is your favorite?

## GOP Rep-elect outlines how DOGE, Trump agenda will get country 'back on track': 'No more business as usual'
 - [https://www.foxnews.com/politics/gop-rep-elect-predicts-doge-trump-agenda-will-get-country-back-on-track-no-more-business-as-usual](https://www.foxnews.com/politics/gop-rep-elect-predicts-doge-trump-agenda-will-get-country-back-on-track-no-more-business-as-usual)
 - RSS feed: $source
 - date published: 2024-12-21T13:26:45+00:00

Fox News Digital spoke to GOP Rep-elect Derek Schmidt about what he expects to see from Republicans when they return to the House in January with a razor-thin majority.

## '007' series in turmoil as producers, Amazon can't agree on franchise: 'I don't think James Bond is a hero'
 - [https://www.foxnews.com/media/007-turmoil-producers-amazon-cant-agree-franchise-i-dont-think-james-bond-hero](https://www.foxnews.com/media/007-turmoil-producers-amazon-cant-agree-franchise-i-dont-think-james-bond-hero)
 - RSS feed: $source
 - date published: 2024-12-21T12:57:59+00:00

According to The Wall Street Journal, there is an &quot;ugly stalemate&quot; between Amazon and &quot;James Bond&quot; producer Barbara Broccoli over what to do with the franchise in the future.

## Fox News Entertainment Newsletter: Kai Trump shares celebrity crush, Jessica Simpson shows off new look
 - [https://www.foxnews.com/entertainment/fox-news-entertainment-newsletter-kai-trump-shares-celebrity-crush-jessica-simpson-shows-off-new-look](https://www.foxnews.com/entertainment/fox-news-entertainment-newsletter-kai-trump-shares-celebrity-crush-jessica-simpson-shows-off-new-look)
 - RSS feed: $source
 - date published: 2024-12-21T12:00:15+00:00

The Fox News Entertainment Newsletter brings you the latest Hollywood headlines, celebrity interviews and stories from Los Angeles and beyond.

## President Biden signs stopgap funding bill into law, narrowly averting shutdown
 - [https://www.foxnews.com/politics/president-biden-signs-stopgap-funding-bill-law-narrowly-averting-shutdown](https://www.foxnews.com/politics/president-biden-signs-stopgap-funding-bill-law-narrowly-averting-shutdown)
 - RSS feed: $source
 - date published: 2024-12-21T11:59:12+00:00

The White House has announced that President Biden signed a stopgap funding bill into law on Saturday, extending government funding into March and avoiding a shutdown.

## Easy recipe for doughnuts this Hanukkah
 - [https://www.foxnews.com/food-drink/easy-recipe-doughnuts-hanukkah](https://www.foxnews.com/food-drink/easy-recipe-doughnuts-hanukkah)
 - RSS feed: $source
 - date published: 2024-12-21T11:57:05+00:00

Cookbook author Jamie Geller tells Fox News Digital why sufganiyot, a version of jelly doughnuts, are eaten during Hanukkah. Plus, a recipe on how to make them at home.

## College offering 'White Supremacy in the Age of Trump' course as President-elect returns to White House
 - [https://www.foxnews.com/media/college-offering-white-supremacy-age-trump-course-president-elect-returns-white-house](https://www.foxnews.com/media/college-offering-white-supremacy-age-trump-course-president-elect-returns-white-house)
 - RSS feed: $source
 - date published: 2024-12-21T11:30:59+00:00

Smith College, a private college for women in Northampton Massachusetts, is offering a course in the spring semester entitled, &apos;White Supremacy in the Age of Trump.&apos;

## Sylvester Stallone axes $35 million mansion sea barrier plans after angering Palm Beach neighbors
 - [https://www.foxnews.com/entertainment/sylvester-stallone-axes-35-million-mansion-sea-barrier-plans-after-angering-palm-beach-neighbors](https://www.foxnews.com/entertainment/sylvester-stallone-axes-35-million-mansion-sea-barrier-plans-after-angering-palm-beach-neighbors)
 - RSS feed: $source
 - date published: 2024-12-21T11:30:15+00:00

Hollywood actor Sylvester Stallone made a plea during the Town Council meeting in Palm Beach as he fought to built an underwater barrier near his $35 million mansion.

## DAVID MARCUS: De facto President Trump's handling of shutdown threat was a masterclass
 - [https://www.foxnews.com/opinion/david-marcus-de-facto-president-trumps-handling-shutdown-threat-masterclass](https://www.foxnews.com/opinion/david-marcus-de-facto-president-trumps-handling-shutdown-threat-masterclass)
 - RSS feed: $source
 - date published: 2024-12-21T11:25:27+00:00

Columnist David Marcus credits incoming Presidetn Trump with averting a government shutdown - while shedding 1,400 pages of wasteful pork from Congress&apos;s budget proposal.

## Biden approves $571M in defense support for Taiwan
 - [https://www.foxnews.com/us/biden-approves-571m-defense-support-taiwan](https://www.foxnews.com/us/biden-approves-571m-defense-support-taiwan)
 - RSS feed: $source
 - date published: 2024-12-21T10:50:01+00:00

President Joe Biden agreed to provide $571.3 million in defense support for Taiwan, the White House said, following China&apos;s massing of naval forces around Taiwan last week.

## Controversy plagued UN agency that employed Oct. 7 terrorists facing new problems as country redirects funding
 - [https://www.foxnews.com/world/controversy-plagued-un-agency-employed-oct-7-terrorists-facing-new-problems-country-redirects-funding](https://www.foxnews.com/world/controversy-plagued-un-agency-employed-oct-7-terrorists-facing-new-problems-country-redirects-funding)
 - RSS feed: $source
 - date published: 2024-12-21T10:37:31+00:00

UN agencies are reportedly offering themselves as replacements to scandal hit UNRWA that&apos;s been riddled with accusations of terrorism since the Hamas terror massacre in southern Israel.

## Fauci holds 'distinguished professor' role at DC university but hasn't taught one class: Report
 - [https://www.foxnews.com/media/fauci-holds-distinguished-professor-role-dc-university-hasnt-taught-one-class-report](https://www.foxnews.com/media/fauci-holds-distinguished-professor-role-dc-university-hasnt-taught-one-class-report)
 - RSS feed: $source
 - date published: 2024-12-21T10:30:09+00:00

Dr. Anthony Fauci has taken several professor and scholar roles at Georgetown University since 2023 but doesn&apos;t appear to have taught a single course since then.

## Indiana’s Curt Cignetti explains head-scratching call to punt in loss to Notre Dame: ‘Didn’t want to do it’
 - [https://www.foxnews.com/sports/indianas-curt-cignetti-explains-head-scratching-call-punt-loss-notre-dame-didnt-want-do-it](https://www.foxnews.com/sports/indianas-curt-cignetti-explains-head-scratching-call-punt-loss-notre-dame-didnt-want-do-it)
 - RSS feed: $source
 - date published: 2024-12-21T10:21:42+00:00

Indiana head coach Curt Cignetti said he had gone for the controversial punt in the fourth quarter of Friday&apos;s loss to Notre Dame because &quot;we were doing nothing on offense.&quot;

## The Fani Willis Trump fiasco is far from over. In fact, it's just getting started
 - [https://www.foxnews.com/opinion/fani-willis-trump-fiasco-far-from-over-fact-its-just-getting-started](https://www.foxnews.com/opinion/fani-willis-trump-fiasco-far-from-over-fact-its-just-getting-started)
 - RSS feed: $source
 - date published: 2024-12-21T10:19:26+00:00

None

## 5 easy ways to stop this holiday criminal: The office refrigerator bandit
 - [https://www.foxnews.com/opinion/5-easy-ways-stop-holiday-criminal-office-refrigerator-bandit](https://www.foxnews.com/opinion/5-easy-ways-stop-holiday-criminal-office-refrigerator-bandit)
 - RSS feed: $source
 - date published: 2024-12-21T10:00:49+00:00

It happens almost every holiday season. This culprit, lurking in workplaces everywhere, has a knack for sending employees into a fury of frustration.

## Do you need a VPN at home? Here are 10 reasons you do
 - [https://www.foxnews.com/tech/do-you-need-vpn-home-here-10-reasons-you-do](https://www.foxnews.com/tech/do-you-need-vpn-home-here-10-reasons-you-do)
 - RSS feed: $source
 - date published: 2024-12-21T10:00:19+00:00

A virtual private network can help ensure your information remains security and your privacy remains intact. Kurt the CyberGuy explains.

## Woman celebrates 106th birthday with Fireball Whisky shot: 'A lot of fun'
 - [https://www.foxnews.com/food-drink/woman-celebrates-106th-birthday-fireball-whisky-shot-fun](https://www.foxnews.com/food-drink/woman-celebrates-106th-birthday-fireball-whisky-shot-fun)
 - RSS feed: $source
 - date published: 2024-12-21T09:32:30+00:00

An Ohio woman who recently turned 106 credits her long life to her positive attitude, willingness to have fun, and, perhaps, her favorite beverage: Fireball Whisky.

## New report warns of growing national security threat to U.S. as China builds AI: 'Significant and concerning'
 - [https://www.foxnews.com/politics/new-report-warns-of-growing-national-security-threat-to-u-s-as-china-builds-ai-significant-and-concerning](https://www.foxnews.com/politics/new-report-warns-of-growing-national-security-threat-to-u-s-as-china-builds-ai-significant-and-concerning)
 - RSS feed: $source
 - date published: 2024-12-21T09:09:02+00:00

A new report from a pro-tech advocacy group warns that China&apos;s advancements on artificial intelligence could pose both an economic and national security threat to the U.S.

## 'Everyday people,' hungry and hurting, receive free meals in Florida
 - [https://www.foxnews.com/food-drink/everyday-people-hungry-hurting-receive-free-meals-florida](https://www.foxnews.com/food-drink/everyday-people-hungry-hurting-receive-free-meals-florida)
 - RSS feed: $source
 - date published: 2024-12-21T09:00:46+00:00

A Florida faith-based organization is providing free meals to families every Saturday morning in the parking lot of a mall. Many of the recipients are working-class families.

## Fox News AI Newsletter: Cate Blanchett 'deeply concerned'
 - [https://www.foxnews.com/tech/ai-newsletter-cate-blanchett-deeply-concerned](https://www.foxnews.com/tech/ai-newsletter-cate-blanchett-deeply-concerned)
 - RSS feed: $source
 - date published: 2024-12-21T08:30:38+00:00

Stay up to date on the latest AI technology advancements and learn about the challenges and opportunities AI presents now and for the future.

## Biden to Trump: Is this the worst transition ever?
 - [https://www.foxnews.com/opinion/biden-to-trump-worst-transition-ever](https://www.foxnews.com/opinion/biden-to-trump-worst-transition-ever)
 - RSS feed: $source
 - date published: 2024-12-21T08:00:48+00:00

In the past few weeks, the cynicism meter has ticked up several notches because of the decisions made by President Biden and others in his administration.

## Flashback: San Francisco 'weight czar' declares that no one has to be healthy
 - [https://www.foxnews.com/media/flashback-san-francisco-weight-czar-declares-healthy](https://www.foxnews.com/media/flashback-san-francisco-weight-czar-declares-healthy)
 - RSS feed: $source
 - date published: 2024-12-21T08:00:43+00:00

San Francisco&apos;s new &quot;weight czar&quot; Virgie Tovar remarked that &quot;no one has to be healthy&quot; or owes being that to others in a resurfaced 2022 interview.

## Meaningful Hanukkah gifts for all 8 days
 - [https://www.foxnews.com/lifestyle/meaningful-hanukkah-gifts](https://www.foxnews.com/lifestyle/meaningful-hanukkah-gifts)
 - RSS feed: $source
 - date published: 2024-12-21T08:00:24+00:00

Create a yearly Hanukkah tradition by gifting these eight thoughtful gifts.

## Visitors flock to winter wonderland light display in honor of family's late son
 - [https://www.foxnews.com/travel/visitors-flock-winter-wonderland-light-display-honor-familys-late-son](https://www.foxnews.com/travel/visitors-flock-winter-wonderland-light-display-honor-familys-late-son)
 - RSS feed: $source
 - date published: 2024-12-21T08:00:17+00:00

In memory of their son who died 22 years ago, Ross and Michelle Clark have been turning their home into a winter wonderland light display for their entire community to enjoy.

## Chiefs are motivated by doubters who say record is a fluke, star says: 'We'll just keep showing up'
 - [https://www.foxnews.com/sports/chiefs-motivated-doubters-who-say-record-fluke-star-says-well-just-keep-showing-up](https://www.foxnews.com/sports/chiefs-motivated-doubters-who-say-record-fluke-star-says-well-just-keep-showing-up)
 - RSS feed: $source
 - date published: 2024-12-21T07:00:48+00:00

The Kansas City Chiefs have had lots of close calls en route to their 13-1 season, but Justin Reid likes the motivation the naysayers bring.

## Lions' Josh Paschal discusses why he feels like it's destiny to be playing in Detroit
 - [https://www.foxnews.com/sports/lions-josh-paschal-discusses-why-he-feels-like-its-destiny-playing-detroit](https://www.foxnews.com/sports/lions-josh-paschal-discusses-why-he-feels-like-its-destiny-playing-detroit)
 - RSS feed: $source
 - date published: 2024-12-21T07:00:29+00:00

Josh Paschal has found himself in a perfect situation – after battling cancer in college, he now plays in a city he says is the &quot;culture of grit.&quot;

## Kasparian of 'Young Turks' explodes at possibility of Harris becoming California governor: 'I'm gonna move!'
 - [https://www.foxnews.com/media/kasparian-young-turks-explodes-possibility-harris-becoming-california-governor-im-gonna-move](https://www.foxnews.com/media/kasparian-young-turks-explodes-possibility-harris-becoming-california-governor-im-gonna-move)
 - RSS feed: $source
 - date published: 2024-12-21T06:00:59+00:00

&quot;The Young Turks&quot; co-host Ana Kasparian yelled in dismay when she considered the possibility that California Democrats could elect Kamala Harris for governor.

## AI cameras are giving DC's air defense a major upgrade
 - [https://www.foxnews.com/tech/ai-cameras-giving-dcs-air-defense-major-upgrade](https://www.foxnews.com/tech/ai-cameras-giving-dcs-air-defense-major-upgrade)
 - RSS feed: $source
 - date published: 2024-12-21T06:00:06+00:00

Artificial intelligence-based cameras are giving air defense operators unprecedented capabilities in monitoring and protecting airspace.

## DC violent crime dips 35% in 2024, reaches 30-year low: US Attorney
 - [https://www.foxnews.com/us/dc-violent-crime-dips-35-2024-reaches-30-year-low-us-attorney](https://www.foxnews.com/us/dc-violent-crime-dips-35-2024-reaches-30-year-low-us-attorney)
 - RSS feed: $source
 - date published: 2024-12-21T05:12:23+00:00

Violent crime in Washington, D.C., has seen a 35% decline in 2024 compared to 2023, and violent crime in the district is now at a 30-year low.

## Moms call on government to reform the food industry: 'Poison is not partisan'
 - [https://www.foxnews.com/media/moms-call-government-reform-food-industry-poison-not-partisan](https://www.foxnews.com/media/moms-call-government-reform-food-industry-poison-not-partisan)
 - RSS feed: $source
 - date published: 2024-12-21T05:00:11+00:00

Zen Honeycutt and Kelly Ryerson, from Moms Across America, chat with &quot;The Story&quot; about the importance of getting toxic ingredients out of food.

## 'Pendulum lifestyle' could be key to juggling daily challenges
 - [https://www.foxnews.com/health/pendulum-lifestyle-could-key-juggling-daily-challenges](https://www.foxnews.com/health/pendulum-lifestyle-could-key-juggling-daily-challenges)
 - RSS feed: $source
 - date published: 2024-12-21T04:30:37+00:00

For those who are feeling “stuck&quot; or overwhelmed while striving for work-life balance, some experts recommend adopting a “pendulum lifestyle.&quot; Psychologists weigh in on the potential benefits.

## Bing Crosby struggled to sing 'White Christmas' to troops, ‘most difficult thing’ in his career
 - [https://www.foxnews.com/entertainment/bing-crosby-struggled-sing-white-christmas-troops-most-difficult-thing-his-career](https://www.foxnews.com/entertainment/bing-crosby-struggled-sing-white-christmas-troops-most-difficult-thing-his-career)
 - RSS feed: $source
 - date published: 2024-12-21T04:30:23+00:00

Bing Crosby once said the most difficult thing he ever did in his decades-long career was sing &quot;White Christmas&quot; to homesick troops in France in December 1944.

## Dad surprised by his 3 kids with final family carpool before retirement
 - [https://www.foxnews.com/travel/california-dad-surprised-his-3-kids-final-family-carpool-before-retirement](https://www.foxnews.com/travel/california-dad-surprised-his-3-kids-final-family-carpool-before-retirement)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:35+00:00

Three adult siblings from California came together to celebrate their dad&apos;s retirement after 41 years by paying tribute to all the time they spent carpooling to school.

## Judge dumbfounded by error at site of 'suicide' where teacher was found stabbed 20 times
 - [https://www.foxnews.com/us/judge-dumbfounded-error-suicide-scene-where-teacher-found-stabbed-20-times](https://www.foxnews.com/us/judge-dumbfounded-error-suicide-scene-where-teacher-found-stabbed-20-times)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:30+00:00

A judge told the parents of 27-year-old Ellen Greenberg, a Philadelphia teacher found dead with 20 stab wounds in 2011, that the city&apos;s declaration of suicide was &quot;puzzling.&quot;

## 2025 showdown: This Republican woman may become nation's first Black female governor
 - [https://www.foxnews.com/politics/2025-showdown-republican-woman-may-become-nations-first-black-female-governor](https://www.foxnews.com/politics/2025-showdown-republican-woman-may-become-nations-first-black-female-governor)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:26+00:00

Republican Lt. Gov. Winsome Sears of Virginia could make history next year as the nation&apos;s first Black woman to win election as a governor and as the state&apos;s first female governor.

## Daughter of notorious 'pom-pom mom' says cheerleading murder plot nearly destroyed her life
 - [https://www.foxnews.com/us/daughter-notorious-pom-pom-mom-cheerleading-murder-plot-nearly-destroyed-life](https://www.foxnews.com/us/daughter-notorious-pom-pom-mom-cheerleading-murder-plot-nearly-destroyed-life)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:22+00:00

In 1991, Wanda Holloway was charged with conspiring to kill the mother of her daughter’s rival. Holloway&apos;s daughter, Shanna, is speaking out in a new true crime docuseries.

## Christmas movies turn naughty this holiday season with stripped-down stars
 - [https://www.foxnews.com/entertainment/christmas-movies-turn-naughty-holiday-season-stripped-down-stars](https://www.foxnews.com/entertainment/christmas-movies-turn-naughty-holiday-season-stripped-down-stars)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:14+00:00

Hollywood takes a risqué turn this holiday season as films including &quot;Hot Frosty&quot; and &quot;The Merry Gentlemen&quot; sizzle on-screen this Christmas.

## UnitedHealthcare CEO murder suspect Luigi Mangione's looks captivate TikTok users after perp walk
 - [https://www.foxnews.com/us/tiktok-swoons-unitedhealthcare-ceo-murder-suspect-luigi-mangione-perp-walk-new-york](https://www.foxnews.com/us/tiktok-swoons-unitedhealthcare-ceo-murder-suspect-luigi-mangione-perp-walk-new-york)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:11+00:00

TikTok is swooning over Luigi Mangione, the accused killer of UnitedHealthcare CEO Brian Thompson, after his perp walk in New York City on Thursday.

## Were undercover sources from other DOJ agencies present on Jan. 6? Grassley, Johnson demand answers
 - [https://www.foxnews.com/politics/were-undercover-sources-from-other-doj-agencies-present-jan-6-grassley-johnson-demand-answers](https://www.foxnews.com/politics/were-undercover-sources-from-other-doj-agencies-present-jan-6-grassley-johnson-demand-answers)
 - RSS feed: $source
 - date published: 2024-12-21T04:00:02+00:00

EXCLUSIVE: Senate Republicans demand answers on whether confidential human sources from DOJ agencies beyond the FBI were used on Jan. 6, 2021, while also questioning IG Horowitz&apos;s review of records.

## Projectile from Yemen strikes near Tel Aviv, injuring more than a dozen: officials
 - [https://www.foxnews.com/world/projectile-from-yemen-strikes-near-tel-aviv-injuring-more-than-dozen-officials](https://www.foxnews.com/world/projectile-from-yemen-strikes-near-tel-aviv-injuring-more-than-dozen-officials)
 - RSS feed: $source
 - date published: 2024-12-21T01:00:56+00:00

A projectile launched into Israel from Yemen overnight struck Tel Aviv, leading to 14 people suffering mild injuries, according to Israeli officials.

## Senate passes bill to stop shutdown, sending it to President Biden's desk
 - [https://www.foxnews.com/politics/senate-passes-bill-stop-shutdown-sending-president-bidens-desk](https://www.foxnews.com/politics/senate-passes-bill-stop-shutdown-sending-president-bidens-desk)
 - RSS feed: $source
 - date published: 2024-12-21T00:38:20+00:00

Congress managed to pass a short-term spending bill through both chambers after going through three different versions of it.

## Brief government shutdown ushered in before Christmas as Senate works to advance House bill
 - [https://www.foxnews.com/politics/brief-government-shutdown-ushered-before-christmas-senate-works-advance-house-bill](https://www.foxnews.com/politics/brief-government-shutdown-ushered-before-christmas-senate-works-advance-house-bill)
 - RSS feed: $source
 - date published: 2024-12-21T00:01:03+00:00

Congress did not manage to send a spending bill to President Biden&apos;s desk before the pre-Christmas deadline.

