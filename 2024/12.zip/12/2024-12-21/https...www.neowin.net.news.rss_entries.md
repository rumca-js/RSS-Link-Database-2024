# Source:Neowin, URL:https://www.neowin.net/news/rss, language:en-us

## Save 20% on ASUS ZenWi-Fi BT10 Wi-Fi 7 routers
 - [https://www.neowin.net/deals/save-20-on-asus-zenwi-fi-bt10-wi-fi-7-routers](https://www.neowin.net/deals/save-20-on-asus-zenwi-fi-bt10-wi-fi-7-routers)
 - RSS feed: $source
 - date published: 2024-12-21T21:10:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/12/1734811610_asus_bt10_router_medium.jpg" alt="" /></div>The ASUS ZenWi-Fi BT10 router lineup with Wi-Fi 7 support is currently available with big discounts, saving you up to 22%. <a href="https://www.neowin.net/deals/save-20-on-asus-zenwi-fi-bt10-wi-fi-7-routers/">Read more...</a>

## Windows 11 Pro (2 devices) + Microsoft Office 2021 license drops to lowest price
 - [https://www.neowin.net/deals/windows-11-pro-2-devices--microsoft-office-2021-license-drops-to-lowest-price](https://www.neowin.net/deals/windows-11-pro-2-devices--microsoft-office-2021-license-drops-to-lowest-price)
 - RSS feed: $source
 - date published: 2024-12-21T18:20:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2023/06/1686736025_win11_office_medium.jpg" alt="" /></div>Upgrade your Windows for a more enhanced UI, improved security, and better multitasking, with classic Office apps that don&#039;t require a monthly subscription. <a href="https://www.neowin.net/deals/windows-11-pro-2-devices--microsoft-office-2021-license-drops-to-lowest-price/">Read more...</a>

## TerraTech is free to claim on the Epic Games Store today
 - [https://www.neowin.net/news/terratech-is-free-to-claim-on-the-epic-games-store-today](https://www.neowin.net/news/terratech-is-free-to-claim-on-the-epic-games-store-today)
 - RSS feed: $source
 - date published: 2024-12-21T16:22:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/12/1734795183_terra_medium.jpg" alt="" /></div>The third game of the Epic Games Store&#039;s daily freebie promotion is TerraTech, and it&#039;s free to claim for the next 24 hours. <a href="https://www.neowin.net/news/terratech-is-free-to-claim-on-the-epic-games-store-today/">Read more...</a>

## 25 small and useful iOS 18 features you should give a try
 - [https://www.neowin.net/guides/25-small-and-useful-ios-18-features-you-should-give-a-try](https://www.neowin.net/guides/25-small-and-useful-ios-18-features-you-should-give-a-try)
 - RSS feed: $source
 - date published: 2024-12-21T15:30:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/06/1718106318_apple_ios_18_medium.jpg" alt="" /></div>Apple&#039;s iOS 18 update is loaded with new features and changes which are still flowing in with the latest iOS 18.2 update. Here is a roundup of some small and useful iOS 18 features you should try. <a href="https://www.neowin.net/guides/25-small-and-useful-ios-18-features-you-should-give-a-try/">Read more...</a>

## TerraMaster T12-500 Pro review: An affordable NAS powerhouse for small to medium businesses
 - [https://www.neowin.net/reviews/terramaster-t12-500-pro-review-an-affordable-nas-powerhouse-for-small-to-medium-businesses](https://www.neowin.net/reviews/terramaster-t12-500-pro-review-an-affordable-nas-powerhouse-for-small-to-medium-businesses)
 - RSS feed: $source
 - date published: 2024-12-21T15:00:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/12/1734696274_20241215_192613_medium.jpg" alt="" /></div>TerraMaster sent us the F12-500 Pro to give a look over. It&#039;s targeted at small and medium-sized businesses but wouldn&#039;t look out of place in your home. <a href="https://www.neowin.net/reviews/terramaster-t12-500-pro-review-an-affordable-nas-powerhouse-for-small-to-medium-businesses/">Read more...</a>

## Microsoft lists a reason why TPM, Secure Boot are required on Windows 11 in 2024-2025
 - [https://www.neowin.net/news/microsoft-lists-a-reason-why-tpm-secure-boot-are-required-on-windows-11-in-2024-2025](https://www.neowin.net/news/microsoft-lists-a-reason-why-tpm-secure-boot-are-required-on-windows-11-in-2024-2025)
 - RSS feed: $source
 - date published: 2024-12-21T11:42:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2021/06/1624624440_windows_11_tpm_medium.jpg" alt="" /></div>Microsoft added a reason why features like TPM and Secure Boot are important on the latest version of Windows 11. <a href="https://www.neowin.net/news/microsoft-lists-a-reason-why-tpm-secure-boot-are-required-on-windows-11-in-2024-2025/">Read more...</a>

## AMD doesn't want you installing Windows 10 on these Ryzen PCs despite Microsoft's support
 - [https://www.neowin.net/news/amd-doesnt-want-you-installing-windows-10-on-these-ryzen-pcs-despite-microsofts-support](https://www.neowin.net/news/amd-doesnt-want-you-installing-windows-10-on-these-ryzen-pcs-despite-microsofts-support)
 - RSS feed: $source
 - date published: 2024-12-21T11:26:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/08/1723744143_amd_windows_11_bloom_red_medium.jpg" alt="" /></div>The popular Ryzen 7000 series APUs for the budget segment apparently does not support Windows 10 at all, which is rather surprising. <a href="https://www.neowin.net/news/amd-doesnt-want-you-installing-windows-10-on-these-ryzen-pcs-despite-microsofts-support/">Read more...</a>

## Microsoft removing My Day calendar and to-do list from Microsoft 365 app for Enterprise
 - [https://www.neowin.net/news/microsoft-removing-my-day-calendar-and-to-do-list-from-microsoft-365-app-for-enterprise](https://www.neowin.net/news/microsoft-removing-my-day-calendar-and-to-do-list-from-microsoft-365-app-for-enterprise)
 - RSS feed: $source
 - date published: 2024-12-21T11:10:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/12/1734778679_my-day_medium.jpg" alt="" /></div>Microsoft is removing the My Day feature for Enterprise customers of the Microsoft 365 app. The change will be made next month. <a href="https://www.neowin.net/news/microsoft-removing-my-day-calendar-and-to-do-list-from-microsoft-365-app-for-enterprise/">Read more...</a>

## SpaceX and Roscosmos will launch missions this week, even on Christmas Day - TWIRL #193
 - [https://www.neowin.net/news/spacex-and-roscosmos-will-launch-missions-this-week-even-on-christmas-day---twirl-193](https://www.neowin.net/news/spacex-and-roscosmos-will-launch-missions-this-week-even-on-christmas-day---twirl-193)
 - RSS feed: $source
 - date published: 2024-12-21T09:46:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2024/12/1734766195_twirl-193_medium.jpg" alt="" /></div>We have several rocket launches coming up this week. SpaceX will have three missions while Roscosmos has one on Christmas Day. <a href="https://www.neowin.net/news/spacex-and-roscosmos-will-launch-missions-this-week-even-on-christmas-day---twirl-193/">Read more...</a>

## Weekend PC Game Deals: Winter Sales 2024 Edition
 - [https://www.neowin.net/news/weekend-pc-game-deals-winter-sales-2024-edition](https://www.neowin.net/news/weekend-pc-game-deals-winter-sales-2024-edition)
 - RSS feed: $source
 - date published: 2024-12-21T09:30:01+00:00

<div style="float:left;margin-right:10px;"><img src="https://cdn.neowin.com/news/images/uploaded/2019/03/1551472873_3_medium.jpg" alt="" /></div>This weekend&#039;s PC game deals include the latest entry in the daily refreshing games offer from Epic, a DRM-free games bundle, and a whole lot of winter sales to go through. <a href="https://www.neowin.net/news/weekend-pc-game-deals-winter-sales-2024-edition/">Read more...</a>

