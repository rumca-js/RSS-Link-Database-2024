# Source:GNU/Linux Gaming on Reddit, URL:https://www.reddit.com/r/linux_gaming/.rss, language:

## why are the recently plagued ea games still listed as playable on proton db? and what does it take to change the rating to avoid misleading users??
 - [https://www.reddit.com/r/linux_gaming/comments/1hjlt5j/why_are_the_recently_plagued_ea_games_still](https://www.reddit.com/r/linux_gaming/comments/1hjlt5j/why_are_the_recently_plagued_ea_games_still)
 - RSS feed: $source
 - date published: 2024-12-21T23:17:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjlt5j/why_are_the_recently_plagued_ea_games_still/"> <img src="https://preview.redd.it/q5dz6mjmba8e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=5949b240820faa7f589f9a3ee9d3021eb7802ef7" alt="why are the recently plagued ea games still listed as playable on proton db? and what does it take to change the rating to avoid misleading users??" title="why are the recently plagued ea games still listed as playable on proton db? and what does it take to change the rating to avoid misleading users??" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Uaagh"> /u/Uaagh </a> <br/> <span><a href="https://i.redd.it/q5dz6mjmba8e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjlt5j/why_are_the_recently_plagued_ea_games_still/">[comments]</a></span> </td></tr></table>

## Nvidia GPU's actually work fine on Linux?
 - [https://www.reddit.com/r/linux_gaming/comments/1hjls26/nvidia_gpus_actually_work_fine_on_linux](https://www.reddit.com/r/linux_gaming/comments/1hjls26/nvidia_gpus_actually_work_fine_on_linux)
 - RSS feed: $source
 - date published: 2024-12-21T23:15:56+00:00

<!-- SC_OFF --><div class="md"><p>Hello guys. My current PC was assembled in 2020. Originally, it had an RTX 2060 with a Ryzen 5 2600, and it had Windows 10 installed. I switched to Linux (Ubuntu) somewhere in mid-2022.</p> <p>I have recently made the switch to an RTX 3070. The CPU has remained the same.</p> <p>A ton of people told me not to do it, because Nvidia works badly with Linux and whatnot, and that I have to go with AMD. I decided to go with an RTX 3070 either way, as I found it to be the best option for me price to performance wise.</p> <p>Honestly, I&#39;t working great? I have no complaints. The only thing that might be an issue is the fact that DLSS apparently doesn&#39;t work with some games? I am able to turn it on in the Witcher 3, RDR 2, and Shadow of the Tomb Raider, but it seems to be unavailable in Cyberpunk or Baldur&#39;s Gate 3.</p> <p>So honestly, I don&#39;t believe I have ever had an issue with either the 2060 or the 3070 as a Linux user?</p> <p>I was wonder

## 100% Linux Gaming this year as well..
 - [https://www.reddit.com/r/linux_gaming/comments/1hjlqef/100_linux_gaming_this_year_as_well](https://www.reddit.com/r/linux_gaming/comments/1hjlqef/100_linux_gaming_this_year_as_well)
 - RSS feed: $source
 - date published: 2024-12-21T23:13:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjlqef/100_linux_gaming_this_year_as_well/"> <img src="https://preview.redd.it/4sgr3n0vaa8e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=535a006d6ab3d71d1f0d22fe10fa41e8e4bfba02" alt="100% Linux Gaming this year as well.." title="100% Linux Gaming this year as well.." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ar99644"> /u/ar99644 </a> <br/> <span><a href="https://i.redd.it/4sgr3n0vaa8e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjlqef/100_linux_gaming_this_year_as_well/">[comments]</a></span> </td></tr></table>

## Audio devices get messed with when launching a game?
 - [https://www.reddit.com/r/linux_gaming/comments/1hjk9g8/audio_devices_get_messed_with_when_launching_a](https://www.reddit.com/r/linux_gaming/comments/1hjk9g8/audio_devices_get_messed_with_when_launching_a)
 - RSS feed: $source
 - date published: 2024-12-21T22:00:08+00:00

<!-- SC_OFF --><div class="md"><p>Whenever I launch a game (notably through steam but I recall it happening sometimes via lutris as well) my audio devices briefly get screwed up. It&#39;s hard to exactly describe, but generally what happens is that there is a brief 1-3 second drop in quality then they fix. Sometimes though they just don&#39;t fix and I need to manually fix them. </p> <p>The issue <em>seems</em> to be that whenever a new window is opened by Steam it tries to change the audio mode. For instance if I&#39;m using a bluetooth headset and it doesn&#39;t fix after a few second then when I go to my audio devices it&#39;ll be set to the bottommost option of &quot;HSP/HFP, Codec mSBC&quot; but then if I go back and select a good codec it goes back to normal. (note : I don&#39;t actually know what these different modes are. They&#39;re not codecs because my little usb DAC has the same options but instead it has different modes like &quot;Chat Input + Chat Output&quot; or &quot;

## VPC Configuration Tool + star citzen using wine?
 - [https://www.reddit.com/r/linux_gaming/comments/1hjjp0v/vpc_configuration_tool_star_citzen_using_wine](https://www.reddit.com/r/linux_gaming/comments/1hjjp0v/vpc_configuration_tool_star_citzen_using_wine)
 - RSS feed: $source
 - date published: 2024-12-21T21:31:47+00:00

<!-- SC_OFF --><div class="md"><p>Very new to linux, and have dedicate gaming pc running bazzite, i skimmed some things, it seemed like i could run it with wine, but nothing mentioned custom binding set ups. </p> <p>Example, My Virpil constellation alpha on windows, and have the flip trigger, inverted so fliping it down engages missle mode on star citizen(running through lutris), and pulling the trigger fires the missles like normal.</p> <p>Figured I ask while at work, before nuking something and crying</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/vipster19"> /u/vipster19 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjjp0v/vpc_configuration_tool_star_citzen_using_wine/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjjp0v/vpc_configuration_tool_star_citzen_using_wine/">[comments]</a></span>

## launching a game on steam will take an extremely long time
 - [https://www.reddit.com/r/linux_gaming/comments/1hjiwut/launching_a_game_on_steam_will_take_an_extremely](https://www.reddit.com/r/linux_gaming/comments/1hjiwut/launching_a_game_on_steam_will_take_an_extremely)
 - RSS feed: $source
 - date published: 2024-12-21T20:53:00+00:00

<!-- SC_OFF --><div class="md"><p>This is the most baffling issue i&#39;ve had and I can&#39;t find any information on it. What happens is </p> <p>-launch game<br/> -it doesn&#39;t launch<br/> -steam says the game is playing<br/> -click close game<br/> -it says stopping but never actually closes<br/> -shut down steam<br/> -the game will launch a minute later even though steam is shut down </p> <p>I don&#39;t know why it happens, it&#39;s very random. I&#39;m using the .deb of steam, I can&#39;t use the flatpak version because it doesn&#39;t recognize secondary drives for some reason. I tried installing the snap version but now I can&#39;t uninstall it, that&#39;s just permanently stuck on my computer. </p> <p>Ubuntu 24.04 </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/toddcoward6985"> /u/toddcoward6985 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjiwut/launching_a_game_on_steam_will_take_an_extremely/">[link]</a><

## GTA V w/ Proton Battleye
 - [https://www.reddit.com/r/linux_gaming/comments/1hjioqj/gta_v_w_proton_battleye](https://www.reddit.com/r/linux_gaming/comments/1hjioqj/gta_v_w_proton_battleye)
 - RSS feed: $source
 - date published: 2024-12-21T20:42:04+00:00

<!-- SC_OFF --><div class="md"><p>Does GTA V work with the Proton Battleye runtime? I&#39;ve tried running it with the launch command PROTON_BATTLEYE_RUNTIME and I just get kicked after 10 seconds or so, is there anything else I&#39;m missing?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/toadskids"> /u/toadskids </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjioqj/gta_v_w_proton_battleye/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjioqj/gta_v_w_proton_battleye/">[comments]</a></span>

## Is there a way to get Discord to show Steam activity?
 - [https://www.reddit.com/r/linux_gaming/comments/1hjio1p/is_there_a_way_to_get_discord_to_show_steam](https://www.reddit.com/r/linux_gaming/comments/1hjio1p/is_there_a_way_to_get_discord_to_show_steam)
 - RSS feed: $source
 - date published: 2024-12-21T20:41:06+00:00

<!-- SC_OFF --><div class="md"><p>All I could find was Registered Games- tab on settings but when I try to add a game the options read something like bash, bwrap, cat chrome_chasbad_handler.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JuhasReddit"> /u/JuhasReddit </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjio1p/is_there_a_way_to_get_discord_to_show_steam/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjio1p/is_there_a_way_to_get_discord_to_show_steam/">[comments]</a></span>

## Rockstar Games launcher says "Buy Now" for games I own on Epic Games. (RDR2)
 - [https://www.reddit.com/r/linux_gaming/comments/1hjh4ep/rockstar_games_launcher_says_buy_now_for_games_i](https://www.reddit.com/r/linux_gaming/comments/1hjh4ep/rockstar_games_launcher_says_buy_now_for_games_i)
 - RSS feed: $source
 - date published: 2024-12-21T19:25:53+00:00

<!-- SC_OFF --><div class="md"><p>On SteamOS (steamdeck) Ive tried both Heroic Launcher and Junk Store, same issue on both. The game worked fine for weeks and then one day it just stopped. If anyone knows any other forums or people to ask let me know. Kind of a niche issue so there isn&#39;t much documentation or instruction I can go off of. Ive contacted rockstar support but I doubt they will do much considering they&#39;ve dismissed the Steam Deck in the past.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/fukinuhhh"> /u/fukinuhhh </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjh4ep/rockstar_games_launcher_says_buy_now_for_games_i/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjh4ep/rockstar_games_launcher_says_buy_now_for_games_i/">[comments]</a></span>

## For Nvidia Users who experience freezes when using gamescope: Here's a patch!
 - [https://www.reddit.com/r/linux_gaming/comments/1hjgelu/for_nvidia_users_who_experience_freezes_when](https://www.reddit.com/r/linux_gaming/comments/1hjgelu/for_nvidia_users_who_experience_freezes_when)
 - RSS feed: $source
 - date published: 2024-12-21T18:52:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjgelu/for_nvidia_users_who_experience_freezes_when/"> <img src="https://external-preview.redd.it/EeCkhLZCvx0wiW3F1cXh79hf8XDoNeZNxlxEJ8RtZrc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2592c08cc2b700fcb21d190231a0298ea2a37d87" alt="For Nvidia Users who experience freezes when using gamescope: Here's a patch!" title="For Nvidia Users who experience freezes when using gamescope: Here's a patch!" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/taicy5623"> /u/taicy5623 </a> <br/> <span><a href="https://github.com/ValveSoftware/gamescope/pull/1671">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjgelu/for_nvidia_users_who_experience_freezes_when/">[comments]</a></span> </td></tr></table>

## Thinking about moving to Linux next year...
 - [https://www.reddit.com/r/linux_gaming/comments/1hjg8p8/thinking_about_moving_to_linux_next_year](https://www.reddit.com/r/linux_gaming/comments/1hjg8p8/thinking_about_moving_to_linux_next_year)
 - RSS feed: $source
 - date published: 2024-12-21T18:44:36+00:00

<!-- SC_OFF --><div class="md"><p>Hello guys! I love PC gaming, however, I am sick and tired of shader compilation stutter and, specially, Windows. Every new W11 update, every new garbage to take care of. I have been testing Bazzite on my ROG Ally, and I have found that most games I play run incredibly awesome there. No shader compilation stutter due to Fossilize and, even though mods are harder to apply, they are worth the extra effort and Valve is working to ease them too. Only bad stuff I have noticed: 1. Idk why but Shaders update every day. I just chose games to not update until start and it has work great. 2. Anti cheat stuff </p> <p>That being said, I have an XSS and the FIFAs, CoDs and Fortnites play great there.</p> <p>Another frustration I have had is Nvidia. I just don&#39;t have the money to buy a $900 dollar card to stop worrying about VRAM. I have a 3070 and it is a beasts stopped by the VRAM. Same will happen with 12gb in the next 2 years. Due to that and because Linux

## CS2 stuck on loading screen.
 - [https://www.reddit.com/r/linux_gaming/comments/1hjg6hp/cs2_stuck_on_loading_screen](https://www.reddit.com/r/linux_gaming/comments/1hjg6hp/cs2_stuck_on_loading_screen)
 - RSS feed: $source
 - date published: 2024-12-21T18:41:42+00:00

<!-- SC_OFF --><div class="md"><p>Hello, I downloaded CS2 recently but when I run it, it first pauses on the valve logo, then freezes halfway into the counter strike loading screen with the orange background. I&#39;ve tried some solutions but none of them work. so far, all i&#39;ve done is put </p> <p>gamemoderun %command% -sdlaudiodriver pipewire </p> <p>into the launch options and changfe the compatibility to steam linux runtime 3.0. </p> <p>I am on ubuntu 20.04. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Electrical-Lab-7317"> /u/Electrical-Lab-7317 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjg6hp/cs2_stuck_on_loading_screen/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjg6hp/cs2_stuck_on_loading_screen/">[comments]</a></span>

## Return To Moria Bug
 - [https://www.reddit.com/r/linux_gaming/comments/1hjg0tz/return_to_moria_bug](https://www.reddit.com/r/linux_gaming/comments/1hjg0tz/return_to_moria_bug)
 - RSS feed: $source
 - date published: 2024-12-21T18:34:13+00:00

<!-- SC_OFF --><div class="md"><p>Hello, </p> <p>I wannted to play Return to Moria with my friends, but i encounter the reported bug under windows with the white screen and no input being detected.</p> <p>I&#39;m using ubuntu 24.04 i couldnt find anything exept this <a href="https://steamcommunity.com/app/2933130/discussions/0/4423185135322946612/?l=english&amp;ctp=3">https://steamcommunity.com/app/2933130/discussions/0/4423185135322946612/?l=english&amp;ctp=3</a></p> <p>It is reported but there is only the a work around for windows.</p> <p>Has anyone an idea, i am completly new to linux and need help </p> <p>Thanks alout in advance :)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Hiruno186"> /u/Hiruno186 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjg0tz/return_to_moria_bug/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjg0tz/return_to_moria_bug/">[comments]</a></span>

## Wine 10.0-rc3 Released With A 16 Year Old Bug "Fixed"
 - [https://www.reddit.com/r/linux_gaming/comments/1hjfic3/wine_100rc3_released_with_a_16_year_old_bug_fixed](https://www.reddit.com/r/linux_gaming/comments/1hjfic3/wine_100rc3_released_with_a_16_year_old_bug_fixed)
 - RSS feed: $source
 - date published: 2024-12-21T18:10:25+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjfic3/wine_100rc3_released_with_a_16_year_old_bug_fixed/"> <img src="https://external-preview.redd.it/70jggMYIOrylde28EQtlL_gWp_h37ACSFi-Z2GCo0Pg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=96796b9b89114867d684b266dc35bd9e0c102e64" alt="Wine 10.0-rc3 Released With A 16 Year Old Bug &quot;Fixed&quot;" title="Wine 10.0-rc3 Released With A 16 Year Old Bug &quot;Fixed&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Doener23"> /u/Doener23 </a> <br/> <span><a href="https://www.phoronix.com/news/Wine-10.0-rc3-Released">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjfic3/wine_100rc3_released_with_a_16_year_old_bug_fixed/">[comments]</a></span> </td></tr></table>

## Issues with PowerA Switch controller (Endeavour OS)
 - [https://www.reddit.com/r/linux_gaming/comments/1hjf8cc/issues_with_powera_switch_controller_endeavour_os](https://www.reddit.com/r/linux_gaming/comments/1hjf8cc/issues_with_powera_switch_controller_endeavour_os)
 - RSS feed: $source
 - date published: 2024-12-21T17:57:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjf8cc/issues_with_powera_switch_controller_endeavour_os/"> <img src="https://b.thumbs.redditmedia.com/FbRa7TSyW6AlUhtzImqM7yHUJFcLNMIGlGhhtm1n9TA.jpg" alt="Issues with PowerA Switch controller (Endeavour OS)" title="Issues with PowerA Switch controller (Endeavour OS)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><a href="https://preview.redd.it/tx8v9z7gq88e1.png?width=1231&amp;format=png&amp;auto=webp&amp;s=ef1d52846b324dc6884d19ff073dd7fea5461b00">https://preview.redd.it/tx8v9z7gq88e1.png?width=1231&amp;format=png&amp;auto=webp&amp;s=ef1d52846b324dc6884d19ff073dd7fea5461b00</a></p> <p>I am experiencing issues where buttons like the Y button are being mapped as &quot;Button 2&quot; and the LB button is mapped as &quot;Button N&quot;. It&#39;s not an issue now as I can fix it for steam games and it just means that the binds look odd on Dolphin, however I do believe it may become a big issue in the future

## CS2 with gamescope?
 - [https://www.reddit.com/r/linux_gaming/comments/1hjexwa/cs2_with_gamescope](https://www.reddit.com/r/linux_gaming/comments/1hjexwa/cs2_with_gamescope)
 - RSS feed: $source
 - date published: 2024-12-21T17:44:36+00:00

<!-- SC_OFF --><div class="md"><p>Hello all,</p> <p>I&#39;ve been trying to migrate to Linux for gaming recently and I&#39;ve been having an issue where I can&#39;t seem to run games at 144hz at lower-than-native resolutions (particularly CS2 at 4:3 1024x768 on a 1440p monitor). I saw a thread on this sub from a few months ago where someone suggested using gamescope to achieve the desired effect but now I can&#39;t seem to run CS2 using gamescope at all.</p> <pre><code>[chase ~]: gamescope -w 1920 -h 1080 -W 1024 -H 768 -f -S stretch -- /home/chase/.local/share/Steam/steamapps/common/Counter-Strike\ Global\ Offensive/game/cs2.sh [gamescope] [Info] console: gamescope version 3.15.13.plus1 (gcc 14.2.1) No CAP_SYS_NICE, falling back to regular-priority compute and threads. Performance will be affected. [gamescope] [Info] scriptmgr: Loading scripts from: &#39;/usr/share/gamescope/scripts&#39; [gamescope] [Info] scriptmgr: Loading scripts from: &#39;/usr/share/gamescope/scripts/00-gamesco

## steam redownload the game every day
 - [https://www.reddit.com/r/linux_gaming/comments/1hjes52/steam_redownload_the_game_every_day](https://www.reddit.com/r/linux_gaming/comments/1hjes52/steam_redownload_the_game_every_day)
 - RSS feed: $source
 - date published: 2024-12-21T17:37:14+00:00

<!-- SC_OFF --><div class="md"><p>hi, i have steam on pop_os 22.04 i downloaded Warframe and played the game all day with no problems, the next day when i started my system and started steam the game started to download again and it happens every time I start steam and wanna play the game.</p> <p>so if someone can help resolve this problem and only download the update files.</p> <p>Thanks </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Pleasant-Wash6401"> /u/Pleasant-Wash6401 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjes52/steam_redownload_the_game_every_day/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjes52/steam_redownload_the_game_every_day/">[comments]</a></span>

## Which gamepad with thumb sticks do you recommend? How about 8Bitdo Pro 2?
 - [https://www.reddit.com/r/linux_gaming/comments/1hje381/which_gamepad_with_thumb_sticks_do_you_recommend](https://www.reddit.com/r/linux_gaming/comments/1hje381/which_gamepad_with_thumb_sticks_do_you_recommend)
 - RSS feed: $source
 - date published: 2024-12-21T17:05:10+00:00

<!-- SC_OFF --><div class="md"><p>Hello!</p> <p>My machine is a Thinkpad T14s running Linux Mint 21.3 (5.15.0-128-generic).</p> <p>I&#39;m mostly playing SuperTuxKart and am quite happy with my simple wireless-via-USB-dongle Miadore SNES gamepad.</p> <p>Some games require a few more buttens and thumb sticks which is why I eventually settled for the 8Bitdo Pro 2. This gamepad requires connection via Bluetooth which does work but SuperTuxKart doesn&#39;t recognize it. This led me to some initial research and it seems that despite it being advertised for RasPi it is rather finicky to get it running with Linux. Anybody got it working stably and without having to invest more than an hour into playing around with bluetooth settings, kernel versions and drivers?</p> <p>Hence my question is - should I invest more time into getting it set up or is my time wiser spent by sending it back and buying another model ... which would lead me to the first question in the title - any recommendations?</

## Arkane Linux Opinions
 - [https://www.reddit.com/r/linux_gaming/comments/1hjdo87/arkane_linux_opinions](https://www.reddit.com/r/linux_gaming/comments/1hjdo87/arkane_linux_opinions)
 - RSS feed: $source
 - date published: 2024-12-21T16:46:07+00:00

<!-- SC_OFF --><div class="md"><p>Thinking of distro hopping and trying an immutable distribution. My daily driver for the past year has been CachyOS (and the Steamdeck). Of all the immutable options Arkane stands out as its Arch based (like SteamOS) so it’s atop my list. The only thing is there’s virtually no information out there on its gaming performance etc. Anyone try it out? How was your experience?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Grease2310"> /u/Grease2310 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjdo87/arkane_linux_opinions/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjdo87/arkane_linux_opinions/">[comments]</a></span>

## Best lightweight gaming distro? (not beginner friendly needed)
 - [https://www.reddit.com/r/linux_gaming/comments/1hjdbna/best_lightweight_gaming_distro_not_beginner](https://www.reddit.com/r/linux_gaming/comments/1hjdbna/best_lightweight_gaming_distro_not_beginner)
 - RSS feed: $source
 - date published: 2024-12-21T16:29:21+00:00

<!-- SC_OFF --><div class="md"><p>Hello, I am here to seek for a lightweight gaming distro for an old laptop I have in my room.</p> <p>I am not a beginner in linux as I am very familiar with debian based and arch based distros, so any one of these would be redeemed.</p> <p>So far, i tried ubuntu, lubuntu and xubuntu (like 5 days trying to optimize enough), and for now i am seeking for XUbuntu. But recently i have found some distros which are &quot;game oriented&quot; and i have got somewhat confused, like Pop!_Os and Garuda Linux. I saw that Pop!_Os is ubuntu but better with beginners (which is not what I am seeking for), but I have also seen that people said that Garuda Linux boosts like 8 fps (which is a BIG of a difference in this laptop, but not sure if they are lying or not), but I am not sure and if you could give me some recommendations to test would be very welcomed.</p> <p>I didnt want really tried arch because i have seen that Valve supports better Ubuntu, but i will still 

## How to use Trainers, Cheat Engine and Mods with Faugus Launcher
 - [https://www.reddit.com/r/linux_gaming/comments/1hjd28i/how_to_use_trainers_cheat_engine_and_mods_with](https://www.reddit.com/r/linux_gaming/comments/1hjd28i/how_to_use_trainers_cheat_engine_and_mods_with)
 - RSS feed: $source
 - date published: 2024-12-21T16:16:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjd28i/how_to_use_trainers_cheat_engine_and_mods_with/"> <img src="https://external-preview.redd.it/KRsbYV6HdYS3CA1TwclLo1-szlJGNZdwbtetQPHhAcI.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=96f7480da1aac458f7b0fa372f59110f664aeae6" alt="How to use Trainers, Cheat Engine and Mods with Faugus Launcher" title="How to use Trainers, Cheat Engine and Mods with Faugus Launcher" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/felix_ribeiro"> /u/felix_ribeiro </a> <br/> <span><a href="https://www.youtube.com/watch?v=F8Xt99ZJfdg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjd28i/how_to_use_trainers_cheat_engine_and_mods_with/">[comments]</a></span> </td></tr></table>

## What is your favorite Open source games?
 - [https://www.reddit.com/r/linux_gaming/comments/1hjcxtn/what_is_your_favorite_open_source_games](https://www.reddit.com/r/linux_gaming/comments/1hjcxtn/what_is_your_favorite_open_source_games)
 - RSS feed: $source
 - date published: 2024-12-21T16:10:36+00:00

<!-- SC_OFF --><div class="md"><p>Mine is Widelands</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/beer120"> /u/beer120 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjcxtn/what_is_your_favorite_open_source_games/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjcxtn/what_is_your_favorite_open_source_games/">[comments]</a></span>

## Direct3D to Vulkan translation layer DXVK v2.5.2 brings fixes for Alpha Protocol, The Sims 2, Borderlands 2 and more
 - [https://www.reddit.com/r/linux_gaming/comments/1hjcrul/direct3d_to_vulkan_translation_layer_dxvk_v252](https://www.reddit.com/r/linux_gaming/comments/1hjcrul/direct3d_to_vulkan_translation_layer_dxvk_v252)
 - RSS feed: $source
 - date published: 2024-12-21T16:02:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjcrul/direct3d_to_vulkan_translation_layer_dxvk_v252/"> <img src="https://external-preview.redd.it/sTnoThLL_XLdde9NiyITD2Tuxg21-yDcmohSCZhwst0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8c8ec88fffe413f4420d033a96dd4efce42e466f" alt="Direct3D to Vulkan translation layer DXVK v2.5.2 brings fixes for Alpha Protocol, The Sims 2, Borderlands 2 and more" title="Direct3D to Vulkan translation layer DXVK v2.5.2 brings fixes for Alpha Protocol, The Sims 2, Borderlands 2 and more" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/beer120"> /u/beer120 </a> <br/> <span><a href="https://www.gamingonlinux.com/2024/12/direct3d-to-vulkan-translation-layer-dxvk-v2-5-2-brings-fixes-for-alpha-protocol-the-sims-2-borderlands-2-and-more/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjcrul/direct3d_to_vulkan_translation_layer_dxvk_v252/">[comments]</a></

## Windows compatibility layer Wine 10.0 third Release Candidate out now
 - [https://www.reddit.com/r/linux_gaming/comments/1hjcroe/windows_compatibility_layer_wine_100_third](https://www.reddit.com/r/linux_gaming/comments/1hjcroe/windows_compatibility_layer_wine_100_third)
 - RSS feed: $source
 - date published: 2024-12-21T16:02:23+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjcroe/windows_compatibility_layer_wine_100_third/"> <img src="https://external-preview.redd.it/SfFjXwf1wX5hU_oiEFlw4OsL9Ju0YdkDaMIGPSeQlv0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=04521d3a4bd3801e4c3fd61475614089e1e922ba" alt="Windows compatibility layer Wine 10.0 third Release Candidate out now" title="Windows compatibility layer Wine 10.0 third Release Candidate out now" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/beer120"> /u/beer120 </a> <br/> <span><a href="https://www.gamingonlinux.com/2024/12/windows-compatibility-layer-wine-100-third-release-candidate-out-now/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjcroe/windows_compatibility_layer_wine_100_third/">[comments]</a></span> </td></tr></table>

## Firaxis reveal Sid Meier's Civilization VII system requirements for Linux
 - [https://www.reddit.com/r/linux_gaming/comments/1hjcr6u/firaxis_reveal_sid_meiers_civilization_vii_system](https://www.reddit.com/r/linux_gaming/comments/1hjcr6u/firaxis_reveal_sid_meiers_civilization_vii_system)
 - RSS feed: $source
 - date published: 2024-12-21T16:01:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjcr6u/firaxis_reveal_sid_meiers_civilization_vii_system/"> <img src="https://external-preview.redd.it/b68_JHnsY6qyYhI7N7CADaBQXODvrSRYrxGm_1KyvQ4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d6f6ee4d4afee0f3230cdd8e5f10d92e85040b87" alt="Firaxis reveal Sid Meier's Civilization VII system requirements for Linux" title="Firaxis reveal Sid Meier's Civilization VII system requirements for Linux" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/beer120"> /u/beer120 </a> <br/> <span><a href="https://www.gamingonlinux.com/2024/12/firaxis-reveal-sid-meiers-civilization-vii-system-requirements-for-linux/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjcr6u/firaxis_reveal_sid_meiers_civilization_vii_system/">[comments]</a></span> </td></tr></table>

## Seperate PC (Windows) just for gaming?
 - [https://www.reddit.com/r/linux_gaming/comments/1hjcp7r/seperate_pc_windows_just_for_gaming](https://www.reddit.com/r/linux_gaming/comments/1hjcp7r/seperate_pc_windows_just_for_gaming)
 - RSS feed: $source
 - date published: 2024-12-21T15:59:31+00:00

<!-- SC_OFF --><div class="md"><p>I am currently using a Lenovo Thinkpad E14 with Linux (Ubuntu) on it. I love it and it works great and I don&#39;t even want to go back to windows. But recently I&#39;ve been getting back into gaming and honestly it&#39;s just a pain in the ass to set everything up. I did learn a bit how to operate Linux while setting up Virtual Boxes, Steam and Legendary (for Epic Games) and some games do run flawlessly now. But I just don&#39;t want to deal with the hassle anymore (plus my laptop is not exactly high end). I just want to buy a game, download it, and Lauch it without having to set up some weird obscure modules and files. Also it seems that playing games on Linux somehow requires way more disk space (??).</p> <p>So I&#39;m contemplating just building my own gaming PC using windows once I get out of college and start earning money. I would use it exclusively to play games and for everything else keep using a Linux laptop.</p> <p>Is that worth it? Am I 

## Gta SA Crash ON steam flat pak and Arch Linux witgh proton ge The latest
 - [https://www.reddit.com/r/linux_gaming/comments/1hjcb4y/gta_sa_crash_on_steam_flat_pak_and_arch_linux](https://www.reddit.com/r/linux_gaming/comments/1hjcb4y/gta_sa_crash_on_steam_flat_pak_and_arch_linux)
 - RSS feed: $source
 - date published: 2024-12-21T15:40:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjcb4y/gta_sa_crash_on_steam_flat_pak_and_arch_linux/"> <img src="https://external-preview.redd.it/MDRhbWEzbGsxODhlMQMGPg5oe-wMTwavkVKtQ4jM_Hjy9IL9Y5zv8MY6yPFk.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=9e779a2058cf6334ce8637d358906bee66d38cf5" alt="Gta SA Crash ON steam flat pak and Arch Linux witgh proton ge The latest " title="Gta SA Crash ON steam flat pak and Arch Linux witgh proton ge The latest " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Abdullah-ALSHRIQI"> /u/Abdullah-ALSHRIQI </a> <br/> <span><a href="https://v.redd.it/6x80z2lk188e1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjcb4y/gta_sa_crash_on_steam_flat_pak_and_arch_linux/">[comments]</a></span> </td></tr></table>

## I love that Linux allows me to still get enjoyment out of my aging rx 580
 - [https://www.reddit.com/r/linux_gaming/comments/1hjblim/i_love_that_linux_allows_me_to_still_get](https://www.reddit.com/r/linux_gaming/comments/1hjblim/i_love_that_linux_allows_me_to_still_get)
 - RSS feed: $source
 - date published: 2024-12-21T15:04:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjblim/i_love_that_linux_allows_me_to_still_get/"> <img src="https://external-preview.redd.it/amZtam45b252NzhlMahzNAa0uHVeDBuyQpwNgLH2HvxeJ3XikTk700_Nszm0.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=a2136406d82a082576d9bbae9111cbba3bd98dd2" alt="I love that Linux allows me to still get enjoyment out of my aging rx 580" title="I love that Linux allows me to still get enjoyment out of my aging rx 580" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/shiroininja"> /u/shiroininja </a> <br/> <span><a href="https://v.redd.it/35uwyttnv78e1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjblim/i_love_that_linux_allows_me_to_still_get/">[comments]</a></span> </td></tr></table>

## Anyone has tried running Quest 3 with link cable on Linux?
 - [https://www.reddit.com/r/linux_gaming/comments/1hjb831/anyone_has_tried_running_quest_3_with_link_cable](https://www.reddit.com/r/linux_gaming/comments/1hjb831/anyone_has_tried_running_quest_3_with_link_cable)
 - RSS feed: $source
 - date published: 2024-12-21T14:45:38+00:00

<!-- SC_OFF --><div class="md"><p>Hey, I&#39;ve ordered a Quest 3 and am planning to play some sim racing and flight sims on it using a link cable (low latency is vital). I want to know whether doing so is possible on Linux or whether I have to dual boot with Windows. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Red-Eye-Soul"> /u/Red-Eye-Soul </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjb831/anyone_has_tried_running_quest_3_with_link_cable/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjb831/anyone_has_tried_running_quest_3_with_link_cable/">[comments]</a></span>

## Square Deadzone in Rocket League
 - [https://www.reddit.com/r/linux_gaming/comments/1hjb3jb/square_deadzone_in_rocket_league](https://www.reddit.com/r/linux_gaming/comments/1hjb3jb/square_deadzone_in_rocket_league)
 - RSS feed: $source
 - date published: 2024-12-21T14:38:36+00:00

<!-- SC_OFF --><div class="md"><p>For specific cases you want to have a square deadzone shape / joystick layout in Rocket League. I have been looking into this problem for the last few days and cant get it to work so I ask the swarm intelligence.</p> <p>I have a PS4 Dual Shock controller. I use Heroic Games Launcher but am willing to try different launchers if they work. I am using EndeavourOS (arch) with KDE Plasma / Wayland</p> <p>The usual way to calibrate a square deadzone in Windows is to either use DS4Windows to emulate a virtual controller or run Epic Games Launcher through Steam with the controller layout configured in Steam.</p> <p>The game is running fine on Heroic Games Launcher but there are no options. From what I&#39;ve gathered the game uses SDL. Is there any way to calibrate the shape of the deadzone for PS4 Controller?</p> <p>I found <a href="https://wiki.archlinux.org/title/Gamepad">https://wiki.archlinux.org/title/Gamepad</a> and messed with jstest-gtk-git and evde

## I am scared...
 - [https://www.reddit.com/r/linux_gaming/comments/1hjay6o/i_am_scared](https://www.reddit.com/r/linux_gaming/comments/1hjay6o/i_am_scared)
 - RSS feed: $source
 - date published: 2024-12-21T14:30:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hjay6o/i_am_scared/"> <img src="https://preview.redd.it/zq9z47ajp78e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=196e0942c49f616182b6e9d471434adb2abc25fd" alt="I am scared..." title="I am scared..." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Smooth_Finance_1825"> /u/Smooth_Finance_1825 </a> <br/> <span><a href="https://i.redd.it/zq9z47ajp78e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hjay6o/i_am_scared/">[comments]</a></span> </td></tr></table>

## CachyOS vs Bazzite
 - [https://www.reddit.com/r/linux_gaming/comments/1hjaoa7/cachyos_vs_bazzite](https://www.reddit.com/r/linux_gaming/comments/1hjaoa7/cachyos_vs_bazzite)
 - RSS feed: $source
 - date published: 2024-12-21T14:15:23+00:00

<!-- SC_OFF --><div class="md"><p>Eyo pals, Quick question and bevor you answer: I know the answer is „it depends“.</p> <p>I am a fairly experienced Linux user, most experienced with Kali and other Debian based distros and I switched my gaming rig to bazzite few weeks ago. Never had much to do with rpm-ostree, fedora or flatpaks so was a bit of a learning curve how bazzite works under the hood, but I invested some time and now everything is running to my liking.</p> <p>Now I think about switching to cachyOS for gaming, cause of it being Arch based with an actually nice package manager included and all modular Linux benefits for when I might decide in the future to do anything other than gaming on this machine or for other gaming related tasks like modding, recording, etc. One more example provided would be, that I was not able to install VMWare Workstation Pro on bazzite cause the cli based installer failed. Might be relevant to me in the future sometime.</p> <p>So question for you i

## 30% performance hit in Path of Exile 2
 - [https://www.reddit.com/r/linux_gaming/comments/1hj9knn/30_performance_hit_in_path_of_exile_2](https://www.reddit.com/r/linux_gaming/comments/1hj9knn/30_performance_hit_in_path_of_exile_2)
 - RSS feed: $source
 - date published: 2024-12-21T13:12:36+00:00

<!-- SC_OFF --><div class="md"><p>Hey folks,</p> <p>I&#39;ve noticed that in POE2, I&#39;m seeing a ~30% performance hit when running Linux compared to Windows. In most other games, performance is on par or sometimes better in Linux.</p> <p>I&#39;m wondering:<br/> Are others experiencing similar issues with POE2 on Linux?<br/> Has anyone found a possible fix or workaround?</p> <p>It’s not unplayable by any means, but it does bug me that I might be missing out on performance.</p> <p>Here’s my setup:<br/> Distro: Fedora 41 (I&#39;ve also tried Nobara, CashyOS, PikaOS, and Bazzite—same results)<br/> GPU: Nvidia 2080 (with 565.77 drivers)<br/> Proton versions tried: Hotfix, Experimental, GE9-21 (no change across these)</p> <p>Any tips, advice, or shared experiences would be greatly appreciated!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MVindis"> /u/MVindis </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj9knn/30_perf

## RDR2 - Social Club code 17 - Steam on Linux
 - [https://www.reddit.com/r/linux_gaming/comments/1hj9gca/rdr2_social_club_code_17_steam_on_linux](https://www.reddit.com/r/linux_gaming/comments/1hj9gca/rdr2_social_club_code_17_steam_on_linux)
 - RSS feed: $source
 - date published: 2024-12-21T13:04:54+00:00

<!-- SC_OFF --><div class="md"><p>Hi everyone,</p> <p>I got the game Red Dead Redemption 2 on Steam. I have installed it and the Rockstar Launcher, but when the game loads I get the Social Club Error Code 17.</p> <p>I have tried to follow the official Rockstar guide for the error, but could not fix the issue. I have deleted steam and all steam files, reinstalled steam and the game, same issue.</p> <p>OS: Fedora Linux 41<br/> CPU: AMD Ryzen™ 5 1600 × 12<br/> GPU: NVIDIA GeForce GTX 1060 6GB<br/> RAM: 16 GB<br/> DE: GNOME 47<br/> WS: Wayland<br/> Kernel: Linux 6.12.5-200.fc41.x86_64<br/> Proton: 9.0-4</p> <p>I also got the Proton Log, but have no idea how to upload the .log file</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Toky92"> /u/Toky92 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj9gca/rdr2_social_club_code_17_steam_on_linux/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/commen

## Sober (roblox on linux) isn't opening im on Ubuntu 24.10
 - [https://www.reddit.com/r/linux_gaming/comments/1hj9bg9/sober_roblox_on_linux_isnt_opening_im_on_ubuntu](https://www.reddit.com/r/linux_gaming/comments/1hj9bg9/sober_roblox_on_linux_isnt_opening_im_on_ubuntu)
 - RSS feed: $source
 - date published: 2024-12-21T12:56:54+00:00

<!-- SC_OFF --><div class="md"><p>Log:<br/> Roblox installation is required, starting onboarding flow UI...</p> <p>MESA-INTEL: warning: ../src/intel/vulkan/anv_formats.c:782: FINISHME: support YUV colorspace with DRM format modifiers</p> <p>MESA-INTEL: warning: ../src/intel/vulkan/anv_formats.c:814: FINISHME: support more multi-planar formats with DRM modifiers</p> <p>Gdk-Message: 13:54:30.345: Error 71 (Protocol error) dispatching to Wayland display.</p> <p>Roblox installation was not completed. This may be an issue with the UI service.</p> <p>Roblox installation was not completed.</p> <p>FATAL: Could not set up application files.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GapCrafty431"> /u/GapCrafty431 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj9bg9/sober_roblox_on_linux_isnt_opening_im_on_ubuntu/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj9bg9/sober_roblox_on

## Anyone else encounter this? Only happening on my Asia Server, my other account works perfectly fine on American server. [Genshin Impact]
 - [https://www.reddit.com/r/linux_gaming/comments/1hj930m/anyone_else_encounter_this_only_happening_on_my](https://www.reddit.com/r/linux_gaming/comments/1hj930m/anyone_else_encounter_this_only_happening_on_my)
 - RSS feed: $source
 - date published: 2024-12-21T12:41:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hj930m/anyone_else_encounter_this_only_happening_on_my/"> <img src="https://preview.redd.it/42pxal2v578e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=4007b84516e2d1a5e750eba5c8ed847d41ba5776" alt="Anyone else encounter this? Only happening on my Asia Server, my other account works perfectly fine on American server. [Genshin Impact]" title="Anyone else encounter this? Only happening on my Asia Server, my other account works perfectly fine on American server. [Genshin Impact]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/fallen_Tarnished"> /u/fallen_Tarnished </a> <br/> <span><a href="https://i.redd.it/42pxal2v578e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj930m/anyone_else_encounter_this_only_happening_on_my/">[comments]</a></span> </td></tr></table>

## The game wouldn't even launch on Windows :D Lenovo T430
 - [https://www.reddit.com/r/linux_gaming/comments/1hj8uqh/the_game_wouldnt_even_launch_on_windows_d_lenovo](https://www.reddit.com/r/linux_gaming/comments/1hj8uqh/the_game_wouldnt_even_launch_on_windows_d_lenovo)
 - RSS feed: $source
 - date published: 2024-12-21T12:26:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hj8uqh/the_game_wouldnt_even_launch_on_windows_d_lenovo/"> <img src="https://b.thumbs.redditmedia.com/EltlRVU7Cb2m4zjnCkmnnEd2FfgJkPhy80cEoVzgg6Q.jpg" alt="The game wouldn't even launch on Windows :D Lenovo T430" title="The game wouldn't even launch on Windows :D Lenovo T430" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p><a href="https://preview.redd.it/4f901w0q278e1.png?width=561&amp;format=png&amp;auto=webp&amp;s=74b0f80a87c23a82836c5c952f52ad540fc8e838">https://preview.redd.it/4f901w0q278e1.png?width=561&amp;format=png&amp;auto=webp&amp;s=74b0f80a87c23a82836c5c952f52ad540fc8e838</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Intrepid_Refuse_332"> /u/Intrepid_Refuse_332 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj8uqh/the_game_wouldnt_even_launch_on_windows_d_lenovo/">[link]</a></span> &#32; <span><a href="https://www.reddit.com

## Crysis 2 - "running on" 4300U and HD 4400 Graphics
 - [https://www.reddit.com/r/linux_gaming/comments/1hj8ioi/crysis_2_running_on_4300u_and_hd_4400_graphics](https://www.reddit.com/r/linux_gaming/comments/1hj8ioi/crysis_2_running_on_4300u_and_hd_4400_graphics)
 - RSS feed: $source
 - date published: 2024-12-21T12:03:29+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hj8ioi/crysis_2_running_on_4300u_and_hd_4400_graphics/"> <img src="https://external-preview.redd.it/uQVhIIGscRmh_Xn2yToMwfFzLfpg9x9a8tTnXp0udCI.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=a801912e026abc16589aba05fb89fd8cbe5a6f3c" alt="Crysis 2 - &quot;running on&quot; 4300U and HD 4400 Graphics" title="Crysis 2 - &quot;running on&quot; 4300U and HD 4400 Graphics" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dreamnobe7"> /u/Dreamnobe7 </a> <br/> <span><a href="https://youtu.be/Y-t6NeXGH2w?si=H0VKUuWtKrP4YFed">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj8ioi/crysis_2_running_on_4300u_and_hd_4400_graphics/">[comments]</a></span> </td></tr></table>

## Playing competitive games in Windows under QEMU/KVM
 - [https://www.reddit.com/r/linux_gaming/comments/1hj8dz8/playing_competitive_games_in_windows_under_qemukvm](https://www.reddit.com/r/linux_gaming/comments/1hj8dz8/playing_competitive_games_in_windows_under_qemukvm)
 - RSS feed: $source
 - date published: 2024-12-21T11:54:49+00:00

<!-- SC_OFF --><div class="md"><p>My target is Apex Legends which as you know has been blocking Linux gamers&#39; access to it since 1st November if I remember correctly.</p> <p>I have my things already prepared: PCIe passthrough, Windows 11 installed with QEMU/KVM, and all that things are working with almost if not full bare metal performance (Tested with The Witcher 3, and Cyberpunk 2077 inside that VM), and my linux installation working in the background just fine.</p> <p>My biggest concern is the anti-cheat thing. It runs kernel-level if I&#39;m correct, and I&#39;ve found some answers already on the internet saying that this is not going to be a safe move as the anti-cheat is going to ban me sooner or later as well as I found info about it being no issue at all. </p> <p>So I know I can hide the fact that I&#39;m using a VM from everything I run in it, but is it still going to be safe to use? Is it safe at all to play competitive games like Apex Legends inside a VM?</p> <p>I real

## Wish controller style do you prefer for Linux?
 - [https://www.reddit.com/r/linux_gaming/comments/1hj6djk/wish_controller_style_do_you_prefer_for_linux](https://www.reddit.com/r/linux_gaming/comments/1hj6djk/wish_controller_style_do_you_prefer_for_linux)
 - RSS feed: $source
 - date published: 2024-12-21T09:24:28+00:00

<!-- SC_OFF --><div class="md"><p>I usually use keyboard and mouse but my favorite thing to do is local coop (Stardew valley in this specific case) with my sister, and that usually requires a controller. </p> <p>For Christmas I was thinking about getting a new controller for her as the PS4 one she has is quite old. Now in the past I&#39;ve had a few issues trying to get it connected (using bottles) and the game seems to be expecting Xbox controllers.</p> <p><strong>I do prefer the PS4 style of controller but will the Xbox controllers be less of a pain?</strong> </p> <p>(I was thinking about getting 2 is that a good idea for local coop ?)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Living-Cheek-2273"> /u/Living-Cheek-2273 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj6djk/wish_controller_style_do_you_prefer_for_linux/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj6djk/w

## System Froze and hard killed, BG3 & Skyrim no longer work, any ideas?
 - [https://www.reddit.com/r/linux_gaming/comments/1hj68sg/system_froze_and_hard_killed_bg3_skyrim_no_longer](https://www.reddit.com/r/linux_gaming/comments/1hj68sg/system_froze_and_hard_killed_bg3_skyrim_no_longer)
 - RSS feed: $source
 - date published: 2024-12-21T09:14:01+00:00

<!-- SC_OFF --><div class="md"><p>Ubuntu 24.04.1 LTS Anything else just ask</p> <p>I was happily playing Baluders Gate and my PC froze up. Had to hard kill it and went to bed. Opened it up the next day and the SSD it&#39;s on wasn&#39;t mounted, fixed that then Steam wouldnt work, restarted the PC again and then BG3 would go to load then just.... Not. Skyrim now does the same thing too</p> <p>Not a lot of help from Google, tried a few things but didn&#39;t work, not really a software person.</p> <p>Anyone have any idea how to fix it? Just want to play some sword &amp; board</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/LA1D3Z_M4N"> /u/LA1D3Z_M4N </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj68sg/system_froze_and_hard_killed_bg3_skyrim_no_longer/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj68sg/system_froze_and_hard_killed_bg3_skyrim_no_longer/">[comments]</a></span>

## Any way to launch a game I bought on a different account without switching accounts and launching from steam?
 - [https://www.reddit.com/r/linux_gaming/comments/1hj5gkt/any_way_to_launch_a_game_i_bought_on_a_different](https://www.reddit.com/r/linux_gaming/comments/1hj5gkt/any_way_to_launch_a_game_i_bought_on_a_different)
 - RSS feed: $source
 - date published: 2024-12-21T08:13:15+00:00

<!-- SC_OFF --><div class="md"><p>I&#39;ll spare you the details, but I thought the game was kind of dirty and I bought it on another account. Turns out it&#39;s great and not really dirty at all. So now I want to sink another 50-60 hours but am getting annoyed at constantly switching accounts. The game is Baldurs Gate 3</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SkinwalkerFanAccount"> /u/SkinwalkerFanAccount </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj5gkt/any_way_to_launch_a_game_i_bought_on_a_different/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj5gkt/any_way_to_launch_a_game_i_bought_on_a_different/">[comments]</a></span>

## Steam fails to run on OpenSuSE symlink on pulse error?
 - [https://www.reddit.com/r/linux_gaming/comments/1hj55bj/steam_fails_to_run_on_opensuse_symlink_on_pulse](https://www.reddit.com/r/linux_gaming/comments/1hj55bj/steam_fails_to_run_on_opensuse_symlink_on_pulse)
 - RSS feed: $source
 - date published: 2024-12-21T07:50:12+00:00

<!-- SC_OFF --><div class="md"><p>I installed Steam from rpm (OpenSuSE&#39;s Freeware 1.0.0.79). Ran it, it downloaded some updates into ~/.local/share/Steam then I get a dialog box <code>steamwebhelper, a critical Steam component, is not responding. The Steam UI will not be usable. Click here for more information.</code> I have tried all the different &quot;Restart&quot; options presented: <code>Restart Steam; Restart Steam with GPU Acceleration Disabled; Restart Steam with Browser Sandboxing Disabled; Restart Steamwebhelper</code> to no avail.</p> <p>The only error on the console is something with bwrap symlink (&quot;<code>bwrap: Can&#39;t make symlink at /run/user/1001/pulse: destination exists and is not a symlink</code>&quot;) on pulse (assuming pulse audio) and this keeps repeating:</p> <p><code>steamwebhelper.sh[14652]: Using supervisor /home/user1/.steam/root/ubuntu12_32/steam-runtime/amd64/usr/bin/steam-runtime-</code><br/> <code>supervisor</code><br/> <code>steamwebhelper.

## How do i create an Once Human Server?
 - [https://www.reddit.com/r/linux_gaming/comments/1hj53h3/how_do_i_create_an_once_human_server](https://www.reddit.com/r/linux_gaming/comments/1hj53h3/how_do_i_create_an_once_human_server)
 - RSS feed: $source
 - date published: 2024-12-21T07:46:17+00:00

<!-- SC_OFF --><div class="md"><p>Hi, </p> <p>i wanted to ask how to create a once human server on linux ubuntu server. I tryd finding a guide but i couldn&#39;t.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Last_Love_6702"> /u/Last_Love_6702 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj53h3/how_do_i_create_an_once_human_server/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj53h3/how_do_i_create_an_once_human_server/">[comments]</a></span>

## KDE Plasma w/Wayland - Games don't show my monitor's resolution (3440x1440)
 - [https://www.reddit.com/r/linux_gaming/comments/1hj1x2t/kde_plasma_wwayland_games_dont_show_my_monitors](https://www.reddit.com/r/linux_gaming/comments/1hj1x2t/kde_plasma_wwayland_games_dont_show_my_monitors)
 - RSS feed: $source
 - date published: 2024-12-21T04:12:28+00:00

<!-- SC_OFF --><div class="md"><p>So I am on a fresh install of Fedora 41, using KDE Plasma, and I verified Wayland is enabled. When I run a game, say Farming Simulator 25 for instance but really anything, and go to set the resolution, my monitor&#39;s resolution of 3440x1440p isn&#39;t there at all. What&#39;s even more strange is something that is close like 3840x1600 works if I set it to that, things look mostly right?</p> <p>I googled around but can&#39;t find a solution to this. KDE has 3440x1440 just fine and it is set to that. Can someone point me to a solution, or explanation please?</p> <p>(oh and I ran xrandr and it looks like the resolutions showing are exactly what I can choose from in games, but if that&#39;s the fix I don&#39;t understand why adding something into xrandr would make it work since I&#39;m using Wayland and not X11. Anyway, very confused!)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/diseasedyak"> /u/diseasedyak </

## Roblox Sober app not working with headphones on X11
 - [https://www.reddit.com/r/linux_gaming/comments/1hj1uq1/roblox_sober_app_not_working_with_headphones_on](https://www.reddit.com/r/linux_gaming/comments/1hj1uq1/roblox_sober_app_not_working_with_headphones_on)
 - RSS feed: $source
 - date published: 2024-12-21T04:08:24+00:00

<!-- SC_OFF --><div class="md"><p>Not sure what the problem is, but when I try to use bluetooth headphones with this specific Roblox client, my audio output RAPIDLY keeps switching from my monitor to my headphones. I have updated my system via command line, and use Manjaro KDE via X11.</p> <p>Do I need to be in Wayland to fix this? And if so, how in the hell do I set my EXTERNAL monitor to be the default one? I am on a laptop with Nvidia GPU. I&#39;m not sure on how to expand this any further, as everything seems to be in check and my bluetooth works fine using other apps.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/StrongAction9696"> /u/StrongAction9696 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj1uq1/roblox_sober_app_not_working_with_headphones_on/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj1uq1/roblox_sober_app_not_working_with_headphones_on/">[comments]</a></s

## Dude, it just fcking works.
 - [https://www.reddit.com/r/linux_gaming/comments/1hj1f2q/dude_it_just_fcking_works](https://www.reddit.com/r/linux_gaming/comments/1hj1f2q/dude_it_just_fcking_works)
 - RSS feed: $source
 - date published: 2024-12-21T03:42:22+00:00

<!-- SC_OFF --><div class="md"><p>Wtf, this is amazing! I really wanted to try linux gaming, and it just works IT JUST WORKS!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FunWithSkooma"> /u/FunWithSkooma </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj1f2q/dude_it_just_fcking_works/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hj1f2q/dude_it_just_fcking_works/">[comments]</a></span>

## Wine 10.0 RC3 - Run Windows Applications on Linux, BSD, Solaris and macOS
 - [https://www.reddit.com/r/linux_gaming/comments/1hizpca/wine_100_rc3_run_windows_applications_on_linux](https://www.reddit.com/r/linux_gaming/comments/1hizpca/wine_100_rc3_run_windows_applications_on_linux)
 - RSS feed: $source
 - date published: 2024-12-21T02:03:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hizpca/wine_100_rc3_run_windows_applications_on_linux/"> <img src="https://external-preview.redd.it/CzFADeLC0MsIfpQUdxqyEaoAqDonpDhDOVMHVOkcIjs.jpg?width=216&amp;crop=smart&amp;auto=webp&amp;s=fd2307fcf1565835bb47140415a76b93418bf9e9" alt="Wine 10.0 RC3 - Run Windows Applications on Linux, BSD, Solaris and macOS" title="Wine 10.0 RC3 - Run Windows Applications on Linux, BSD, Solaris and macOS" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Neustradamus"> /u/Neustradamus </a> <br/> <span><a href="https://www.winehq.org/announce/10.0-rc3">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hizpca/wine_100_rc3_run_windows_applications_on_linux/">[comments]</a></span> </td></tr></table>

## Experiencing lag spikes in Metal: Hellsinger despite none being present earlier?
 - [https://www.reddit.com/r/linux_gaming/comments/1hiz5lk/experiencing_lag_spikes_in_metal_hellsinger](https://www.reddit.com/r/linux_gaming/comments/1hiz5lk/experiencing_lag_spikes_in_metal_hellsinger)
 - RSS feed: $source
 - date published: 2024-12-21T01:33:09+00:00

<!-- SC_OFF --><div class="md"><p>Hi!</p> <p>I&#39;ve been playing and enjoying Metal: Hellsinger on Linux for a while now, and haven&#39;t had any particular issues with the game up until I started playing the game&#39;s horde mode known as Leviathan mode. During the mode, I seem to have a ton of frame drops at seemingly random - despite having the proper specs to run the game at minimum, and according to pcgamebenchmark at recommended (at least on windows) - and despite what I&#39;ve tried (setting the graphics to the minimum, adding gamemoderun %command% to the launch options), I can&#39;t seem to get them to stop. One thing I should note is that if I swap the game to any other version of Proton (with ProtonGE installed), I can&#39;t get it to launch at all.</p> <p>Help would be very appreciated, thank you!</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ISavage2007"> /u/ISavage2007 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gam

## Please help, Nvidia-smi shows fan at 0 fan won't start
 - [https://www.reddit.com/r/linux_gaming/comments/1hiy2k5/please_help_nvidiasmi_shows_fan_at_0_fan_wont](https://www.reddit.com/r/linux_gaming/comments/1hiy2k5/please_help_nvidiasmi_shows_fan_at_0_fan_wont)
 - RSS feed: $source
 - date published: 2024-12-21T00:35:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/linux_gaming/comments/1hiy2k5/please_help_nvidiasmi_shows_fan_at_0_fan_wont/"> <img src="https://b.thumbs.redditmedia.com/o6aF1pCn87R_SmRgrPbnRDLAicrFaz5CQWmGVha4v4I.jpg" alt="Please help, Nvidia-smi shows fan at 0 fan won't start" title="Please help, Nvidia-smi shows fan at 0 fan won't start" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I hope it&#39;s ok to post this here.<br/> I cleaned my GPU it was really dusty and added new thermal paste, putting everything back as it was, The GPU works but the fan won&#39;t start! Nvidia-smi shows fan at 0 even when temperature reaches 90! I totally didn&#39;t want to burn it so can someone help me? Is it the settings that it says fan at 0? I think I rewrote some xconif file trying to fix it reading other threads which didn&#39;t work for for me. I can&#39;t figure out what other posts are saying I might have screwed things up more. I&#39;m on POP os with an Nvidia 1650 560.35.03.<br/> 

## Elden ring crash and the log said: "radv/amdgpu: The CS has been cancelled because the context is lost. This context is innocent."
 - [https://www.reddit.com/r/linux_gaming/comments/1hixrrq/elden_ring_crash_and_the_log_said_radvamdgpu_the](https://www.reddit.com/r/linux_gaming/comments/1hixrrq/elden_ring_crash_and_the_log_said_radvamdgpu_the)
 - RSS feed: $source
 - date published: 2024-12-21T00:20:09+00:00

<!-- SC_OFF --><div class="md"><p>A few months ago, i can play Elden Ring flawlessly and never crash or any issues, but recently, i just came back to Elden Ring and it crashes in a first few minutes of gameplay( usually at loading screen). </p> <p>No other games has this crash( DS1, DS2, DS3, AC6, Remnant FTA, Remnant 2, Nioh 2 don&#39;t have any issue).</p> <p>I have tried various versions of proton and it doesnt help. Im using a laptop with integrated graphics( 7840HS with 780M) and using Arch Linux with the lastest version of vulkan radeon, mesa.</p> <p>This is the log from journalctl when the crash happens</p> <p>Thg 12 21 06:55:23 EvilBrewHausen pipewire[1433]: pw.node: (ELDEN RING™-81) xrun state:0x7de2aa463008 pending:0/1 s:1974868177415 a:1974865533980 f:1974865538388 waiting:18446744073706908181 process:4408 status:triggered</p> <p>Thg 12 21 06:55:43 EvilBrewHausen kernel: amdgpu 0000:63:00.0: amdgpu: Dumping IP State</p> <p>Thg 12 21 06:55:43 EvilBrewHausen kernel: amdgpu 0

## Lag spikes on Native and Wine games
 - [https://www.reddit.com/r/linux_gaming/comments/1hixp60/lag_spikes_on_native_and_wine_games](https://www.reddit.com/r/linux_gaming/comments/1hixp60/lag_spikes_on_native_and_wine_games)
 - RSS feed: $source
 - date published: 2024-12-21T00:16:26+00:00

<!-- SC_OFF --><div class="md"><p>CPU: AMD Ryzen 7 7730U (16) @ 4.55 </p> <p>GPU: AMD Barcelo [Integrated]</p> <p>OS: Arch Linux x86_64</p> <p>Kernel: Linux 6.12.4-zen1-1-zen</p> <p>Happens in both X11 and Wayland</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Cookie9666"> /u/Cookie9666 </a> <br/> <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hixp60/lag_spikes_on_native_and_wine_games/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/linux_gaming/comments/1hixp60/lag_spikes_on_native_and_wine_games/">[comments]</a></span>

