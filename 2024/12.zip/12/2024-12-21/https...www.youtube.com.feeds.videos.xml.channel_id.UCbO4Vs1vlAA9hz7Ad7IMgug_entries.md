# Source:Guerrilla Miniature Games, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbO4Vs1vlAA9hz7Ad7IMgug, language:en

## Tactical Awareness - N5 LAUNCH EPISODE 003 - Skillz to pay the Billz
 - [https://www.youtube.com/watch?v=0YO_FvcOwTQ](https://www.youtube.com/watch?v=0YO_FvcOwTQ)
 - RSS feed: $source
 - date published: 2024-12-21T14:30:02+00:00

Welcome back to TACTICAL AWARENESS - a Canadian Podcast about Corvus Belli’s landmark Sci-Fi Wargame; Infinity N5. Come along with our hosts Ash, Owen and Dan for a whole new ITS Edition of Infinity! 

It's Part Three of this week's infinity coverage as we give you the low-down on changes to Skills and Orders in N5!

Listener Mailbag: ⁠https://docs.google.com/document/d/1sZBGrL7XqK03lyU5bunLkIMDMPce4GnI0278hi3PeRI/edit⁠ 

Join us on Discord HERE: ⁠⁠https://discord.gg/5hndYxvpTu

Add us to your favourite Podcasting App using the RSS Feed: ⁠⁠https://anchor.fm/s/cfa52998/podcast/rss⁠⁠ 

Music "Built to Last" by NEFFEX used via Creative Commons

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.com/invite/XTqqxctryq

Want to challenge Ash to a game? Email him at GuerrillaMiniatureGames@gmail.com or message him through his Facebook Page!

Follow

## GMG Reviews - Heroquest: FIRST LIGHT by Avalon Hill and Hasbro
 - [https://www.youtube.com/watch?v=soAZbFPAbqA](https://www.youtube.com/watch?v=soAZbFPAbqA)
 - RSS feed: $source
 - date published: 2024-12-21T10:01:00+00:00

Hasbro was kind enough to send me an advance copy of their new HEROQUEST STARTER SET! Coming in at just $70 CAD, this is a complete Heroquest game with the same board and components, some in cardstock and some still in plastic. Let's check it out!

Big thanks to Hasbro for the complimentary copy of the box to review. 

You can pick up your own copy of HeroQuest: FIRST LIGHT here: https://www.hasbropulse.com/uk/product/heroquest-first-light-english-version/G0978UU00

GMG is publicly supported. Become a backer on Patreon to ensure new content and that the Studio can continue: https://www.patreon.com/guerrillaminiaturegames 

Join us on DISCORD: https://discord.com/invite/XTqqxctryq

Want to challenge Ash to a game? Email him at GuerrillaMiniatureGames@gmail.com or message him through his Facebook Page!

Follow Ash on Facebook: https://www.facebook.com/outofthebasementintothestreets

GMG Measuring Gauges and Tokens available HERE: http://deathraydesigns.com/product-category/accessories/

