# Source:Polski Subreddit, URL:https://www.reddit.com/r/Polska/.rss, language:pl

## Trzymajcie się tam w trakcie Świąt i wesołych.
 - [https://www.reddit.com/r/Polska/comments/1hjkk8z/trzymajcie_się_tam_w_trakcie_świąt_i_wesołych](https://www.reddit.com/r/Polska/comments/1hjkk8z/trzymajcie_się_tam_w_trakcie_świąt_i_wesołych)
 - RSS feed: $source
 - date published: 2024-12-21T22:14:50+00:00

<!-- SC_OFF --><div class="md"><p>Taka wiadomość (nie)parafialna bo nie dla wszystkich to dobry okres.</p> <p>Jedni nie zobaczą części rodziny bo odeszła w tym roku, z jednymi część tutaj zerwała kontakt (jak ja 1.5 roku temu z rodzicem klinicznym narcyzem), część będzie mieć pato w domu i nie ma gdzie uciec, a część nie ma nikogo blisko.</p> <p>Jeżeli nie masz gdzie się podziać i musisz tkwić w pato: współczuję Ci i życzę Ci chociaż chwili dla siebie w spokoju.</p> <p>Jeżeli jesteś sam i Cię na to stać: zrób coś samolubnego, dla jakiejś przyjemności.</p> <p>Ogólnie każdemu życzę by to były święta gdzie czujesz się dobrze </p> <p>Trochę mnie naszło. Smacznych pierogów.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Dave_The_Polak"> /u/Dave_The_Polak </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1hjkk8z/trzymajcie_się_tam_w_trakcie_świąt_i_wesołych/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comm

## tyle się mówi o polskiej polityce plemiennej, że "jesteśmy Tutsi i Hutu"...
 - [https://www.reddit.com/r/Polska/comments/1hjiivz/tyle_się_mówi_o_polskiej_polityce_plemiennej_że](https://www.reddit.com/r/Polska/comments/1hjiivz/tyle_się_mówi_o_polskiej_polityce_plemiennej_że)
 - RSS feed: $source
 - date published: 2024-12-21T20:34:05+00:00

<!-- SC_OFF --><div class="md"><p>... czyli że porównujemy się do Rwandy. A przecież jesteśmy na poziomie co najmniej Zambii!</p> <blockquote> <p>21.12.2024, Lusaka (PAP) - Policja Zambii udaremniła spisek przeciwko prezydentowi Hakaindemu Hichilemie. Zatrzymała dwóch podejrzanych, przy których znaleziono różne amulety oraz żywego kameleona - poinformował w piątek rzecznik komendy w stolicy kraju, Lusace, Rae Hamoonga.</p> <p>Według wstępnych dochodzeń ustalono, że podejrzani, z których jeden jest obywatelem Mozambiku, są praktykującymi czarownikami wynajętymi przez Nelsona Bandę, młodszego brata zbiegłego w październiku do Zimbabwe Emmanuela Jaya Bandy, polityka opozycyjnej wobec prezydenta partii i jego osobistego wroga.</p> <p>&quot;Podejrzani brali udział w nielegalnym i niebezpiecznym procederze mającym na celu skrzywdzenie naszej głowy państwa. Podchodzimy do tej sprawy z najwyższą powagą i jesteśmy zobowiązani do zapewnienia sprawiedliwości&quot; - oświadczył w imieniu policji

## Viktor Orbán oświadczył, że jest przeciwny zwiększaniu wydatków na obronność o więcej niż 2% PKB, gdyż zaszkodzi to węgierskiej gospodarce.
 - [https://www.reddit.com/r/Polska/comments/1hjh9h4/viktor_orbán_oświadczył_że_jest_przeciwny](https://www.reddit.com/r/Polska/comments/1hjh9h4/viktor_orbán_oświadczył_że_jest_przeciwny)
 - RSS feed: $source
 - date published: 2024-12-21T19:32:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hjh9h4/viktor_orbán_oświadczył_że_jest_przeciwny/"> <img src="https://preview.redd.it/0mwjmooi798e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=659160a50601cdcff8ec9bed897c3c879175465a" alt="Viktor Orbán oświadczył, że jest przeciwny zwiększaniu wydatków na obronność o więcej niż 2% PKB, gdyż zaszkodzi to węgierskiej gospodarce." title="Viktor Orbán oświadczył, że jest przeciwny zwiększaniu wydatków na obronność o więcej niż 2% PKB, gdyż zaszkodzi to węgierskiej gospodarce." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FrytkiFrytunie"> /u/FrytkiFrytunie </a> <br/> <span><a href="https://i.redd.it/0mwjmooi798e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hjh9h4/viktor_orbán_oświadczył_że_jest_przeciwny/">[comments]</a></span> </td></tr></table>

## Co ja właśnie przeczytałem?
 - [https://www.reddit.com/r/Polska/comments/1hjg72e/co_ja_właśnie_przeczytałem](https://www.reddit.com/r/Polska/comments/1hjg72e/co_ja_właśnie_przeczytałem)
 - RSS feed: $source
 - date published: 2024-12-21T18:42:30+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hjg72e/co_ja_właśnie_przeczytałem/"> <img src="https://preview.redd.it/616sddsgy88e1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=12f5fccd2a3a9a1262360bbec1f929235ed2b410" alt="Co ja właśnie przeczytałem?" title="Co ja właśnie przeczytałem?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FrytkiFrytunie"> /u/FrytkiFrytunie </a> <br/> <span><a href="https://i.redd.it/616sddsgy88e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hjg72e/co_ja_właśnie_przeczytałem/">[comments]</a></span> </td></tr></table>

## Jaki jest target docelowy Republiki? Ludzie o iq poniżej 80?
 - [https://www.reddit.com/r/Polska/comments/1hjfp92/jaki_jest_target_docelowy_republiki_ludzie_o_iq](https://www.reddit.com/r/Polska/comments/1hjfp92/jaki_jest_target_docelowy_republiki_ludzie_o_iq)
 - RSS feed: $source
 - date published: 2024-12-21T18:19:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hjfp92/jaki_jest_target_docelowy_republiki_ludzie_o_iq/"> <img src="https://preview.redd.it/j6vxanm5u88e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=0cf7845693ee50ce0c6a5138bfed1bf3c22a5e82" alt="Jaki jest target docelowy Republiki? Ludzie o iq poniżej 80?" title="Jaki jest target docelowy Republiki? Ludzie o iq poniżej 80?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Magnetic_Pole"> /u/Magnetic_Pole </a> <br/> <span><a href="https://i.redd.it/j6vxanm5u88e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hjfp92/jaki_jest_target_docelowy_republiki_ludzie_o_iq/">[comments]</a></span> </td></tr></table>

## Niemcy bardziej prorosyjskie od Węgier? Co uważacie?
 - [https://www.reddit.com/r/Polska/comments/1hjfob1/niemcy_bardziej_prorosyjskie_od_węgier_co_uważacie](https://www.reddit.com/r/Polska/comments/1hjfob1/niemcy_bardziej_prorosyjskie_od_węgier_co_uważacie)
 - RSS feed: $source
 - date published: 2024-12-21T18:18:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hjfob1/niemcy_bardziej_prorosyjskie_od_węgier_co_uważacie/"> <img src="https://preview.redd.it/90wknpc2u88e1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=9debc8b07800f3ff31785ab96f3d93e21608e2b4" alt="Niemcy bardziej prorosyjskie od Węgier? Co uważacie?" title="Niemcy bardziej prorosyjskie od Węgier? Co uważacie?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/FrytkiFrytunie"> /u/FrytkiFrytunie </a> <br/> <span><a href="https://i.redd.it/90wknpc2u88e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hjfob1/niemcy_bardziej_prorosyjskie_od_węgier_co_uważacie/">[comments]</a></span> </td></tr></table>

## Pomoc dla mojego Ojca
 - [https://www.reddit.com/r/Polska/comments/1hjfi58/pomoc_dla_mojego_ojca](https://www.reddit.com/r/Polska/comments/1hjfi58/pomoc_dla_mojego_ojca)
 - RSS feed: $source
 - date published: 2024-12-21T18:10:10+00:00

<!-- SC_OFF --><div class="md"><p>Cześć wszystkim! Nie sądziłem, że kiedyś będę musiał tworzyć taki post ale życie postanowiło napisać inny scenariusz...Z góry przepraszam jeśli post wyda się bez ładu...</p> <p>Sytuacja w jakiej znajduję się jest następująca - Mieszkam we Wrocławiu, mój Ojciec mieszka sam w Krakowie. Jego stan zdrowia od ponad pół roku pogarszał się z miesiąca na miesiąc. Miał zaplanowaną operację serca (wymiana zastawki) w połowie stycznia. Początkiem grudnia zemdlał w swoim mieszkaniu ale na szczęście sąsiadka usłyszała jego upadek i poinformowała jego brata, mego wujka, o tym zdarzeniu. Dzięki temu udało się szybko zareagować i go uratować. Jego stan oceniono na krytyczny...leżał na OIOMie przez tydzień a lekarze starali się ustabilizować jego stan. </p> <p>W trakcie tego leczenia podawano mu również mocne leki przeciwbólowe, ponieważ Ojciec ma też chore plecy i biodro i zanim trafił na OIOM, miał ogromne problemy z siedzeniem i leżeniem, więc jest faszerowany prz

## Jak mam niby zacząć pracować
 - [https://www.reddit.com/r/Polska/comments/1hjd83y/jak_mam_niby_zacząć_pracować](https://www.reddit.com/r/Polska/comments/1hjd83y/jak_mam_niby_zacząć_pracować)
 - RSS feed: $source
 - date published: 2024-12-21T16:24:27+00:00

<!-- SC_OFF --><div class="md"><p>Klasa maturalna, 18 skończona, nigdy wcześniej w żadnej robocie nie byłam. Z kasą cienko w domu cienko i musze powoli zacząć na siebie robić. Ale jak? 5 ważnych lat podczas dorastania spędziłam w domu, nie jestem najlepsza w komunikacji z ludźmi. Nie mam nic przeciwko temu ale czasem moje zachowania mogą wydawać się dziwne (tak mi mówią znajomi np). Więc obawiam się że jak pójdę gdzieś, gdzie będę musiała być w kontakcie z ludźmi to zaraz mnie wywalą przez to. Doświadczenia 0 bo tak jak mówię - wcześniej nie pracowałam. Po liceum mam to tylko maturę. Jakieś porady? Gdzie mam w ogóle aplikować? Z kąd mam wiedzieć gdzie jest jakaś otwarta pozycja? Nie wiem NIC. Pomocy</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/bread1salt2butter3"> /u/bread1salt2butter3 </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1hjd83y/jak_mam_niby_zacząć_pracować/">[link]</a></span> &#32; <span><a href="https://www.re

## Co czuliście po ostatniej części/odcinku gier, komiksów, książek, seriali itd.
 - [https://www.reddit.com/r/Polska/comments/1hjcaaa/co_czuliście_po_ostatniej_częściodcinku_gier](https://www.reddit.com/r/Polska/comments/1hjcaaa/co_czuliście_po_ostatniej_częściodcinku_gier)
 - RSS feed: $source
 - date published: 2024-12-21T15:39:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hjcaaa/co_czuliście_po_ostatniej_częściodcinku_gier/"> <img src="https://preview.redd.it/ka2k3mnt188e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9e0ad88c2599ddca7ac8401aa0ba86a34704e99e" alt="Co czuliście po ostatniej części/odcinku gier, komiksów, książek, seriali itd." title="Co czuliście po ostatniej części/odcinku gier, komiksów, książek, seriali itd." /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Czuliście taką wewnętrzną pustkę, ale jednocześnie radość i dumę? Obrazek powiązany z tematem.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HIGHGROUNDHUNTER"> /u/HIGHGROUNDHUNTER </a> <br/> <span><a href="https://i.redd.it/ka2k3mnt188e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hjcaaa/co_czuliście_po_ostatniej_częściodcinku_gier/">[comments]</a></span> </td></tr></table>

## Rodzice "pozbywają się" mnie z domu
 - [https://www.reddit.com/r/Polska/comments/1hjbgjr/rodzice_pozbywają_się_mnie_z_domu](https://www.reddit.com/r/Polska/comments/1hjbgjr/rodzice_pozbywają_się_mnie_z_domu)
 - RSS feed: $source
 - date published: 2024-12-21T14:57:50+00:00

<!-- SC_OFF --><div class="md"><p>Wpadłem się trochę wyżalić. Mam 25 lat (stary koń wiem) i wynajmuję mieszkanie z dziewczyną. Od kiedy się wyprowadziłem mój pokój stał się poniekąd pokojem mojej siostrzenicy, wszystkie jej zabawki tam są na wypadek kiedy przyjedzie odwiedzić dziadków i nie mam z tym problemu. Problem polega na tym że mimo iż rodzice mi ciągle mówią że &quot;to mój pokój&quot; i jak będę potrzebował to mogę wrócić to dają mi do zrozumienia że w sumie to fajnie by było jakby wszystko stamtąd zniknęło. Mieszkanie które wynajmujemy jest małe i większość rzeczy jest mojej dziewczyny ponieważ nie jest stąd tylko z drugiego końca Polski i na moje rzeczy jest mało miejsca (brak szaf czy możliwości ustawienia wszystkiego tak jak bym chciał). Na kupno mieszkania mnie nie stać. Za każdym razem gdy przyjeżdżam do rodziców to słyszę że mam tam posprzątać - ogarnąłem już swoje biurko szafę, regał i zostały tam już w zasadzie same rzeczy których nie chce się pozbywać. Dziś dowiedz

## Głosowanie w sprawie wsparcia protestujących w Gruzji i potępienia przemocy wobec nich
 - [https://www.reddit.com/r/Polska/comments/1hjb51z/głosowanie_w_sprawie_wsparcia_protestujących_w](https://www.reddit.com/r/Polska/comments/1hjb51z/głosowanie_w_sprawie_wsparcia_protestujących_w)
 - RSS feed: $source
 - date published: 2024-12-21T14:41:02+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hjb51z/głosowanie_w_sprawie_wsparcia_protestujących_w/"> <img src="https://preview.redd.it/n58w0g3sj78e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=757838a0c8036438822a3f6b9984f95e50748128" alt="Głosowanie w sprawie wsparcia protestujących w Gruzji i potępienia przemocy wobec nich" title="Głosowanie w sprawie wsparcia protestujących w Gruzji i potępienia przemocy wobec nich" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/wokolis"> /u/wokolis </a> <br/> <span><a href="https://i.redd.it/n58w0g3sj78e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hjb51z/głosowanie_w_sprawie_wsparcia_protestujących_w/">[comments]</a></span> </td></tr></table>

## Praca fizyczna po studiach
 - [https://www.reddit.com/r/Polska/comments/1hj9zo2/praca_fizyczna_po_studiach](https://www.reddit.com/r/Polska/comments/1hj9zo2/praca_fizyczna_po_studiach)
 - RSS feed: $source
 - date published: 2024-12-21T13:37:36+00:00

<!-- SC_OFF --><div class="md"><p>Kończę niedługo studia inżynierskie z informatyki i moje perspektywy zawodowe nie wyglądają zbyt kolorowo.<br/> Zacznę może od tego że nie jestem topowym studentem ani jednym z tych pasjonatów którzy od dziecka kodowali a pierwszą pracę dostali w wieku 16 lat.<br/> Studia były dla mnie trudne ale zawsze jakoś dawałem sobie radę, nauczyłem się na nich podstaw programowania i przede wszystkim rozwiązywania problemów poprzez samodzielne poszerzanie wiedzy.<br/> Mimo tego nie jestem w stanie znaleźć jakiejkolwiek pracy jako programista czy nawet tester. Udało mi się dzięki znajomością dostać bezpłatne praktyki w małej firmie IT gdzie całkiem sprawnie pracowałem nad backendem do aplikacji webowej w .NET ale firma nie zatrudniła mnie po zakończeniu praktyk.</p> <p>Składałem setki o ile nie tysiące CV na przestrzeni ostatnich miesięcy a odzew był dosłownie zerowy. Co gorsze to nie jest problem który tylko ja napotykam, większość moich znajomych nie jest w s

## Moja matula chleje
 - [https://www.reddit.com/r/Polska/comments/1hj9so9/moja_matula_chleje](https://www.reddit.com/r/Polska/comments/1hj9so9/moja_matula_chleje)
 - RSS feed: $source
 - date published: 2024-12-21T13:26:03+00:00

<!-- SC_OFF --><div class="md"><p>Problem jest już od lat ale dopiero niedawno stałem się widzem w pierwszym rzędzie tego melodramatu.</p> <p>Na codzień mieszkam z tata, za granicą. Będzie już dobre 10 lat od kiedy moi rodzice tak postanowili. Ja z tatą i siostrą za granicę, matula zostaje w Polsce bo [tu wstaw jakąkolwiek wymówkę].</p> <p>Od czasu do czasu kiedy matka nas odwiedzała to problem był widoczny, butelka czystej pod poduszką, widoczny wstyd i wyparcie, że jest problem. </p> <p>Od mojego wyjazdu nie miałem z matką dobrych relacji, losowe wyzwiska, porównywanie do najgorszych i namawianie, że już czas wyprowadzić się od ojca. Z naszej trójki to i tak było pobłażliwe traktowanie w porównaniu do niedorzecznych śmieci które potrafiła wyciągnąć ojcu albo epitety którymi obdarowywała moją siostrę zaczynając na idiotkach po dzi<em>kach kończąc. Takie epizody przeplatany się z moją próbą dyskusji z nią, że ma problem i powinna coś z tym zrobić. Po jednym z jej kontrataków postanow

## Banderowskie flagi na Rosomakach z Polski. Szef MON reaguje
 - [https://www.reddit.com/r/Polska/comments/1hj9q86/banderowskie_flagi_na_rosomakach_z_polski_szef](https://www.reddit.com/r/Polska/comments/1hj9q86/banderowskie_flagi_na_rosomakach_z_polski_szef)
 - RSS feed: $source
 - date published: 2024-12-21T13:21:59+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj9q86/banderowskie_flagi_na_rosomakach_z_polski_szef/"> <img src="https://external-preview.redd.it/RRL7yZaxT9eyKeCLIx-FlNoE-B1_F5drln4yL-wjzGs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=19b07359842fecfdd60c8d4ea9471e09f72cb5ea" alt="Banderowskie flagi na Rosomakach z Polski. Szef MON reaguje" title="Banderowskie flagi na Rosomakach z Polski. Szef MON reaguje" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Democracy2004"> /u/Democracy2004 </a> <br/> <span><a href="https://www.tvp.info/84143182/wojna-w-ukrainie-flagi-upa-na-rosomakach-z-polski-wladyslaw-kosiniak-kamysz-mowi-o-prowokacji">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj9q86/banderowskie_flagi_na_rosomakach_z_polski_szef/">[comments]</a></span> </td></tr></table>

## Największa wieś
 - [https://www.reddit.com/r/Polska/comments/1hj9iyk/największa_wieś](https://www.reddit.com/r/Polska/comments/1hj9iyk/największa_wieś)
 - RSS feed: $source
 - date published: 2024-12-21T13:09:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj9iyk/największa_wieś/"> <img src="https://preview.redd.it/defcx3s5b78e1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=36d00604a54a570af2126d8b5bdd1977595670f7" alt="Największa wieś" title="Największa wieś" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Taki żart. Proszę traktować z przymrużeniem oka 😉</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/rafal93"> /u/rafal93 </a> <br/> <span><a href="https://i.redd.it/defcx3s5b78e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj9iyk/największa_wieś/">[comments]</a></span> </td></tr></table>

## Przy tych cenach karpia to poważny zarzut
 - [https://www.reddit.com/r/Polska/comments/1hj96v2/przy_tych_cenach_karpia_to_poważny_zarzut](https://www.reddit.com/r/Polska/comments/1hj96v2/przy_tych_cenach_karpia_to_poważny_zarzut)
 - RSS feed: $source
 - date published: 2024-12-21T12:48:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj96v2/przy_tych_cenach_karpia_to_poważny_zarzut/"> <img src="https://preview.redd.it/e85qy6od778e1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=d65245c8794c7538ef732b4f55a091041b9fdf61" alt="Przy tych cenach karpia to poważny zarzut " title="Przy tych cenach karpia to poważny zarzut " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/starnak"> /u/starnak </a> <br/> <span><a href="https://i.redd.it/e85qy6od778e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj96v2/przy_tych_cenach_karpia_to_poważny_zarzut/">[comments]</a></span> </td></tr></table>

## Jestem starszym bratem z powołania
 - [https://www.reddit.com/r/Polska/comments/1hj96bi/jestem_starszym_bratem_z_powołania](https://www.reddit.com/r/Polska/comments/1hj96bi/jestem_starszym_bratem_z_powołania)
 - RSS feed: $source
 - date published: 2024-12-21T12:47:52+00:00

<!-- SC_OFF --><div class="md"><p>Nie tylko w rodzinie, robię za starszego brata. Choć tutaj jest to trochę bardziej skomplikowane, bo jako jedyny nie studiuje i nie mam dyplomu, więc to ja mam brać przykład. Jednakże poprzez dużą aktywność na facebooku spotkałem kilka w swoim życiu osób, które generalnie miały swoje większe i mniejsze problemy. I dla właśnie tych kilku osób stawałem się takim właśnie &quot;starszym bratem&quot;, który pomoże, wysłucha, doradzi przez messengera, zawsze odbierze albo oddzwoni czy coś. Nie powiem, odczuwam dumę, że ktoś dzięki mojemu wsparciu jakoś dalej tupta przez te życie, coraz pewniejszym krokiem. Ze wszystkimi tymi osobami utrzymuje dalej kontakt, w razie czego dając im pewność że nie znikam, że cały czas jakby się podwinęła noga to można się odezwać.</p> <p>Chciałbym się zapytać, czy ktoś z was był może takim starszym bratem albo starszą siostrą dla obcej osoby? Czy może wy mieliście takie wirtualne starsze rodzeństwo? Niezmiernie mnie to ciekaw

## Ten budżet pokazuje, że rząd woli głodzić budżetówkę, odebrać ludziom prawo do leczenia, niż opodatkować korporacje.
 - [https://www.reddit.com/r/Polska/comments/1hj8gx1/ten_budżet_pokazuje_że_rząd_woli_głodzić](https://www.reddit.com/r/Polska/comments/1hj8gx1/ten_budżet_pokazuje_że_rząd_woli_głodzić)
 - RSS feed: $source
 - date published: 2024-12-21T12:00:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj8gx1/ten_budżet_pokazuje_że_rząd_woli_głodzić/"> <img src="https://external-preview.redd.it/ODIzZGcwZnJ5NjhlMWDOSRry01LtfxB8ldkkDZ346jrw6TkAjXNievbVdiPi.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=a71555c8574742d30e1e2b2c31b3f9ae993fd718" alt="Ten budżet pokazuje, że rząd woli głodzić budżetówkę, odebrać ludziom prawo do leczenia, niż opodatkować korporacje." title="Ten budżet pokazuje, że rząd woli głodzić budżetówkę, odebrać ludziom prawo do leczenia, niż opodatkować korporacje." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DeszczJesienny"> /u/DeszczJesienny </a> <br/> <span><a href="https://v.redd.it/lm46b2fry68e1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj8gx1/ten_budżet_pokazuje_że_rząd_woli_głodzić/">[comments]</a></span> </td></tr></table>

## Fikołki kryptopisowca w sprawie Romanowskiego
 - [https://www.reddit.com/r/Polska/comments/1hj8cu0/fikołki_kryptopisowca_w_sprawie_romanowskiego](https://www.reddit.com/r/Polska/comments/1hj8cu0/fikołki_kryptopisowca_w_sprawie_romanowskiego)
 - RSS feed: $source
 - date published: 2024-12-21T11:52:39+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj8cu0/fikołki_kryptopisowca_w_sprawie_romanowskiego/"> <img src="https://preview.redd.it/7vwz3f56x68e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=116cd60cefa34d87af700ca15118434097bc6759" alt="Fikołki kryptopisowca w sprawie Romanowskiego" title="Fikołki kryptopisowca w sprawie Romanowskiego" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DeszczJesienny"> /u/DeszczJesienny </a> <br/> <span><a href="https://i.redd.it/7vwz3f56x68e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj8cu0/fikołki_kryptopisowca_w_sprawie_romanowskiego/">[comments]</a></span> </td></tr></table>

## Zwykły dzień na polskiej wsi w 1979 roku - Chełmno n/Nerem [HD/AI upscaled]
 - [https://www.reddit.com/r/Polska/comments/1hj844n/zwykły_dzień_na_polskiej_wsi_w_1979_roku_chełmno](https://www.reddit.com/r/Polska/comments/1hj844n/zwykły_dzień_na_polskiej_wsi_w_1979_roku_chełmno)
 - RSS feed: $source
 - date published: 2024-12-21T11:35:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj844n/zwykły_dzień_na_polskiej_wsi_w_1979_roku_chełmno/"> <img src="https://external-preview.redd.it/4PECDo6kRGudz73cIDvW5ntoHfbmcDJQPiAE4_aR3Gc.jpg?width=320&amp;crop=smart&amp;auto=webp&amp;s=68bb295a388e0d19c76517be8b4ce83dd6125785" alt="Zwykły dzień na polskiej wsi w 1979 roku - Chełmno n/Nerem [HD/AI upscaled]" title="Zwykły dzień na polskiej wsi w 1979 roku - Chełmno n/Nerem [HD/AI upscaled]" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/starnak"> /u/starnak </a> <br/> <span><a href="https://www.youtube.com/watch?v=5-xIBOhyG8Q&amp;ab_channel=WorldHistoryEpisodes">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj844n/zwykły_dzień_na_polskiej_wsi_w_1979_roku_chełmno/">[comments]</a></span> </td></tr></table>

## Viktor Orban zabrał głos w sprawie Marcina Romanowskiego. "Nie będzie ostatni"
 - [https://www.reddit.com/r/Polska/comments/1hj7u1j/viktor_orban_zabrał_głos_w_sprawie_marcina](https://www.reddit.com/r/Polska/comments/1hj7u1j/viktor_orban_zabrał_głos_w_sprawie_marcina)
 - RSS feed: $source
 - date published: 2024-12-21T11:14:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj7u1j/viktor_orban_zabrał_głos_w_sprawie_marcina/"> <img src="https://external-preview.redd.it/uyTUFbxUW7NR9TizHY2xYcXlaVW_fh-LTkdsZnz2uww.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=abfc6b209ce07f1fe6ba297481ad1f66471edbf3" alt="Viktor Orban zabrał głos w sprawie Marcina Romanowskiego. &quot;Nie będzie ostatni&quot;" title="Viktor Orban zabrał głos w sprawie Marcina Romanowskiego. &quot;Nie będzie ostatni&quot;" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/iceasteroid"> /u/iceasteroid </a> <br/> <span><a href="https://www.onet.pl/informacje/onetwiadomosci/viktor-orban-zabral-glos-w-sprawie-marcina-romanowskiego-nie-bedzie-ostatni/jz1j25p,79cfc278">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj7u1j/viktor_orban_zabrał_głos_w_sprawie_marcina/">[comments]</a></span> </td></tr></table>

## Dzisiejsza sekcja "Czy Wiesz" na polskojęzycznej Wikipedii
 - [https://www.reddit.com/r/Polska/comments/1hj7kxp/dzisiejsza_sekcja_czy_wiesz_na_polskojęzycznej](https://www.reddit.com/r/Polska/comments/1hj7kxp/dzisiejsza_sekcja_czy_wiesz_na_polskojęzycznej)
 - RSS feed: $source
 - date published: 2024-12-21T10:56:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj7kxp/dzisiejsza_sekcja_czy_wiesz_na_polskojęzycznej/"> <img src="https://preview.redd.it/l1z1p3xgn68e1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=299fbff806951970ba08984e20d3f9a92a7d6ef3" alt="Dzisiejsza sekcja &quot;Czy Wiesz&quot; na polskojęzycznej Wikipedii" title="Dzisiejsza sekcja &quot;Czy Wiesz&quot; na polskojęzycznej Wikipedii" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Zacny_Los"> /u/Zacny_Los </a> <br/> <span><a href="https://i.redd.it/l1z1p3xgn68e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj7kxp/dzisiejsza_sekcja_czy_wiesz_na_polskojęzycznej/">[comments]</a></span> </td></tr></table>

## Uszka (ft. Pierogi)
 - [https://www.reddit.com/r/Polska/comments/1hj79nq/uszka_ft_pierogi](https://www.reddit.com/r/Polska/comments/1hj79nq/uszka_ft_pierogi)
 - RSS feed: $source
 - date published: 2024-12-21T10:33:01+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj79nq/uszka_ft_pierogi/"> <img src="https://b.thumbs.redditmedia.com/7isMe1Zd1v6WntKeRwQzmf1OnASUbLjEkXcEhZP8--E.jpg" alt="Uszka (ft. Pierogi)" title="Uszka (ft. Pierogi)" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Robiłam z babcią, Wesołych:)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Veridan_"> /u/Veridan_ </a> <br/> <span><a href="https://www.reddit.com/gallery/1hj79nq">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj79nq/uszka_ft_pierogi/">[comments]</a></span> </td></tr></table>

## Cyberatak na ukraińskie rejestry państwowe. Kopie zapasowe były na serwerach w Polsce
 - [https://www.reddit.com/r/Polska/comments/1hj6wz6/cyberatak_na_ukraińskie_rejestry_państwowe_kopie](https://www.reddit.com/r/Polska/comments/1hj6wz6/cyberatak_na_ukraińskie_rejestry_państwowe_kopie)
 - RSS feed: $source
 - date published: 2024-12-21T10:06:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj6wz6/cyberatak_na_ukraińskie_rejestry_państwowe_kopie/"> <img src="https://external-preview.redd.it/bPZxQXUdZvgcdXgPeAveOwKr8f-ZVWCWhXyfVyLAAko.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4d52bdfbae454c9ada2559dc72866689314559da" alt="Cyberatak na ukraińskie rejestry państwowe. Kopie zapasowe były na serwerach w Polsce" title="Cyberatak na ukraińskie rejestry państwowe. Kopie zapasowe były na serwerach w Polsce" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/grot_13"> /u/grot_13 </a> <br/> <span><a href="https://tvn24.pl/swiat/ukraina-media-cyberatak-na-rejestry-panstwowe-ktorych-kopie-zapasowe-byly-na-serwerach-w-polsce-st8231666">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj6wz6/cyberatak_na_ukraińskie_rejestry_państwowe_kopie/">[comments]</a></span> </td></tr></table>

## Co zrobić z głośnym sąsiadem?
 - [https://www.reddit.com/r/Polska/comments/1hj6whl/co_zrobić_z_głośnym_sąsiadem](https://www.reddit.com/r/Polska/comments/1hj6whl/co_zrobić_z_głośnym_sąsiadem)
 - RSS feed: $source
 - date published: 2024-12-21T10:05:05+00:00

<!-- SC_OFF --><div class="md"><p>Część czy macie jakieś pomysły coś zrobić z sąsiadem który nawala muzyką po nocach? To już drugie mieszkanie gdzie mam problem z sąsiadami którzy nawalają muzyką po nocach. Na poprzednim mieszkaniu miałem nad sobą staruszkę która puszczała tak glośno tv że jak oglądała &quot;jaka to melodia&quot; to byłem w stanie słuchając przez strop zgadnąć &quot;po jednej&quot;. Inny sąsiad też nawalał muzyką że się spokojnie żyć nie dało bo musiałem razem z nim słuchać o ironio &quot;enjoy the silence&quot;. Policja była kilka razy u obu sąsiadów. Nie przyniosło to większych efektów a gnój jeszcze zaczął mi się odgrażać. Teraz jest w innym mieszkaniu w kamienicy tutaj to już sąsiad konkretny. Całe noce skrzypi, chodzi, tupie. A jak już się nachodził to puszcza muzykę wczoraj odpalił o 3 w nocy, już nawet spanie w stoperach nie pomaga. Mireczki czy macie jakiś pomysł jak sobie z tym poradzić?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.

## Dlaczego ludzie wierzą znachorom?
 - [https://www.reddit.com/r/Polska/comments/1hj6r4n/dlaczego_ludzie_wierzą_znachorom](https://www.reddit.com/r/Polska/comments/1hj6r4n/dlaczego_ludzie_wierzą_znachorom)
 - RSS feed: $source
 - date published: 2024-12-21T09:53:53+00:00

<!-- SC_OFF --><div class="md"><p>Jeśli nie żyjecie pod kamieniem, to pewnie kojarzycie taką osobę jak Jerzy Zięba. Jest to w dużym skrócie dość kontrowersyjny przedsiębiorca, którego opinia wynika z promowania pseudonauki. Otóż &quot;terapie&quot; które on promuje stoją w sprzeczności z badaniami naukowymi. Często stanowią również zagrożenie dla zdrowia, a nawet życia. Jednak nie tylko on umieszcza antynaukowe brednie. Jeśli bowiem będziesz odpowiednio szukał, to znajdziesz ludzi jeszcze bardziej odklejonych niż Zięba, bo dodających do swojego antynaukowego bełkotu elementy ezoteryki, na przykład reinkarnację, bądź karmę. Tu pojawia się pytanie-dlaczego ludzie wierzą ludziom, którzy gadają takie głupoty?<br/> PS: Jeśli jesteś zwolennikiem takich rzeczy, to proszę o nieodpowiadanie.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/PhilipB12"> /u/PhilipB12 </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1hj6r4n/dlaczego_ludzie_w

## JEDNO konto wielowalutowe (jeden numer konta)? Jaki bank?
 - [https://www.reddit.com/r/Polska/comments/1hj6pbh/jedno_konto_wielowalutowe_jeden_numer_konta_jaki](https://www.reddit.com/r/Polska/comments/1hj6pbh/jedno_konto_wielowalutowe_jeden_numer_konta_jaki)
 - RSS feed: $source
 - date published: 2024-12-21T09:49:59+00:00

<!-- SC_OFF --><div class="md"><p>Miałem kiedyś konto bankowe na Litwie - i tam było takie miłe udogodnienie dla klientów - możliwość prowadzenia konta w wielu walutach (co nie jest niczym specjalnym w Polsce), z jednym numerem konta (z czym się nie spotkałem w Polsce).</p> <p>W sensie - mając numer konta 1234 5678 - to nieważne, czy na ten numer konta nastąpiła wpłata USD, EUR, GBP czy PLN - to zostawało to zaksięgowane na konto USD, EUR, GBP, PLN bez żadnego przewalutowania.</p> <p>W Polsce - przynajmniej z tego, z czym się spotkałem - konta USD, EUR, GBP, PLN mają różne numery, a wpłata złotówek na konto EUR (lub na odwrót) poskutkuje bolesnym przewalutowaniem.</p> <p>Dla zobrazowania - jak poniżej:</p> <p>Stan konta USD 1234 5678: 1450 USD<br/> Stan konta EUR 1234 5678: 17 EUR<br/> Stan konta PLN 1234 5678: 6 PLN<br/> Stan konta GBP 1234 5678: 0 GBP</p> <p>Jest taki bank w Polsce?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Critical-Curr

## „Islamistyczny” zamach w Magdeburgu, dwie osoby nie żyją. Sprawca – wróg islamu, sympatyk AfD
 - [https://www.reddit.com/r/Polska/comments/1hj5x8t/islamistyczny_zamach_w_magdeburgu_dwie_osoby_nie](https://www.reddit.com/r/Polska/comments/1hj5x8t/islamistyczny_zamach_w_magdeburgu_dwie_osoby_nie)
 - RSS feed: $source
 - date published: 2024-12-21T08:49:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj5x8t/islamistyczny_zamach_w_magdeburgu_dwie_osoby_nie/"> <img src="https://external-preview.redd.it/sNsy2UTSoUI6IGS7ux_Bs6z8qzkRWCSx6fDWJWMyLOg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4c5c0776810b54d45bdb5892cc1e06bb6796e37b" alt="„Islamistyczny” zamach w Magdeburgu, dwie osoby nie żyją. Sprawca – wróg islamu, sympatyk AfD" title="„Islamistyczny” zamach w Magdeburgu, dwie osoby nie żyją. Sprawca – wróg islamu, sympatyk AfD" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/grot_13"> /u/grot_13 </a> <br/> <span><a href="https://oko.press/na-zywo/na-zywo-relacja/islamistyczny-zamach-w-magdeburgu-dwie-osoby-nie-zyja">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj5x8t/islamistyczny_zamach_w_magdeburgu_dwie_osoby_nie/">[comments]</a></span> </td></tr></table>

## Filiks: Polacy w Polsce też wjeżdżali w Jarmarki
 - [https://www.reddit.com/r/Polska/comments/1hj5ih3/filiks_polacy_w_polsce_też_wjeżdżali_w_jarmarki](https://www.reddit.com/r/Polska/comments/1hj5ih3/filiks_polacy_w_polsce_też_wjeżdżali_w_jarmarki)
 - RSS feed: $source
 - date published: 2024-12-21T08:17:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj5ih3/filiks_polacy_w_polsce_też_wjeżdżali_w_jarmarki/"> <img src="https://preview.redd.it/8ks4zox0v58e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=36f4ed7334f0d315c428aec37e61e0eb9ab2d4c5" alt="Filiks: Polacy w Polsce też wjeżdżali w Jarmarki" title="Filiks: Polacy w Polsce też wjeżdżali w Jarmarki" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Pijana albo niespełna rozumu.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DirtyJoe99"> /u/DirtyJoe99 </a> <br/> <span><a href="https://i.redd.it/8ks4zox0v58e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj5ih3/filiks_polacy_w_polsce_też_wjeżdżali_w_jarmarki/">[comments]</a></span> </td></tr></table>

## Kupiłem JEDNĄ rzecz w Biedronce.
 - [https://www.reddit.com/r/Polska/comments/1hj4mlf/kupiłem_jedną_rzecz_w_biedronce](https://www.reddit.com/r/Polska/comments/1hj4mlf/kupiłem_jedną_rzecz_w_biedronce)
 - RSS feed: $source
 - date published: 2024-12-21T07:10:09+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Polska/comments/1hj4mlf/kupiłem_jedną_rzecz_w_biedronce/"> <img src="https://preview.redd.it/pnop37m0j58e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2634d274ef90c8de793bdd983678ee35dc40240c" alt="Kupiłem JEDNĄ rzecz w Biedronce." title="Kupiłem JEDNĄ rzecz w Biedronce." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/I_suck_at_Blender"> /u/I_suck_at_Blender </a> <br/> <span><a href="https://i.redd.it/pnop37m0j58e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj4mlf/kupiłem_jedną_rzecz_w_biedronce/">[comments]</a></span> </td></tr></table>

## Głupie pytania w czasie wigilii, i jak na nie jeszcze głupiej odpowiedzieć. - Obrona przed czarną magią - edycja świąteczna
 - [https://www.reddit.com/r/Polska/comments/1hj2s5a/głupie_pytania_w_czasie_wigilii_i_jak_na_nie](https://www.reddit.com/r/Polska/comments/1hj2s5a/głupie_pytania_w_czasie_wigilii_i_jak_na_nie)
 - RSS feed: $source
 - date published: 2024-12-21T05:05:52+00:00

<!-- SC_OFF --><div class="md"><p>Czekam na Wasze propozycje głupich, niesmacznych pytań, które można usłyszeć podczas wigilii. Przy okazji dawajcie dobre riposty. Może komuś przyda się ;) </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/matsoj15"> /u/matsoj15 </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1hj2s5a/głupie_pytania_w_czasie_wigilii_i_jak_na_nie/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hj2s5a/głupie_pytania_w_czasie_wigilii_i_jak_na_nie/">[comments]</a></span>

