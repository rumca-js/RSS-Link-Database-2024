# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## Darktable 5.0 Open-Source RAW Image Editor Officially Released, Here’s What’s New
 - [https://9to5linux.com/darktable-5-0-open-source-raw-image-editor-officially-released-heres-whats-new](https://9to5linux.com/darktable-5-0-open-source-raw-image-editor-officially-released-heres-whats-new)
 - RSS feed: $source
 - date published: 2024-12-21T18:21:29+00:00

<p>Darktable 5.0 open-source raw image editor is now available for download with new features, improvements, and enhanced camera support. Here’s what’s new!</p>
<p>The post <a href="https://9to5linux.com/darktable-5-0-open-source-raw-image-editor-officially-released-heres-whats-new">Darktable 5.0 Open-Source RAW Image Editor Officially Released, Here’s What’s New</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## CachyOS Now Uses AutoFDO Kernel as Default Across All Supported Architectures
 - [https://9to5linux.com/cachyos-now-uses-autofdo-kernel-as-default-across-all-supported-architectures](https://9to5linux.com/cachyos-now-uses-autofdo-kernel-as-default-across-all-supported-architectures)
 - RSS feed: $source
 - date published: 2024-12-21T15:58:11+00:00

<p>CachyOS snapshot for December 2024 is now available for download with AutoFDO kernel as default across all supported architectures, as well as other improvements.</p>
<p>The post <a href="https://9to5linux.com/cachyos-now-uses-autofdo-kernel-as-default-across-all-supported-architectures">CachyOS Now Uses AutoFDO Kernel as Default Across All Supported Architectures</a> appeared first on <a href="https://9to5linux.com">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

