# Source:Standard C++ | News, URL:https://isocpp.org/blog/rss/category/news, language:en

## C++ Online 2025 Registration now Open
 - [https://isocpp.org//blog/2024/12/cpp-online-2025-registration-now-open](https://isocpp.org//blog/2024/12/cpp-online-2025-registration-now-open)
 - RSS feed: $source
 - date published: 2024-12-21T20:28:04+00:00

<p>
	C++ Online conference and workshop tickets are now available:</p>
<blockquote>
	<h3>
		<a href="https://cpponline.uk/cpponline-2025-registration-now-open/">C++ Online 2025 Registration Now Open!</a></h3>
	<p>
		by C++ Online</p>
</blockquote>
<p>
	From the article:</p>
<blockquote>
	<p>
		We&rsquo;re excited to announce that ticket sales for C++Online 2025 are officially open! Join us from 26th - 28th February for three days packed with expert talks, networking, and interactive virtual experiences&mdash;all from the comfort of your own home.</p>
</blockquote>

