# Source:emzdanowicz, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCCDGVMGoT8ql8JQLJt715jA, language:pl

## NAJLEPSZE GRY INDIE ROKU i MARVEL NA DOCZEPKĘ | GPJ #2
 - [https://www.youtube.com/watch?v=tQIs8qRlGqI](https://www.youtube.com/watch?v=tQIs8qRlGqI)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:51+00:00

Growy Podcast Jednoosobowy, odcinek drugi - ten, w którym prezentuję różnorodny zestaw najciekawszych gier niezależnych 2024 roku. Do tego krótkie wrażenia z Marvel Rivals.

0:00 Podcast indyczy
1:10 Animal Well
5:28 Balatro
9:41 Mouthwashing
13:19 Mullet Mad Jack
16:30 Arco
20:38 Crow Country
23:14 Thronefall
26:43 I Am Your Beast
31:46 Lorelei and the Laser Eyes
35:07 Shogun Showdown
39:03 Segment AAA | Marvel Rivals

GPJ na Spotify: https://open.spotify.com/show/5uZfMkkJrgIdjiAdMzH4s8

GPJ w Apple Podcasts: https://podcasts.apple.com/us/podcast...

Podcast GPJ to cotygodniowy program, w którym opowiadam o grach wideo, tych największych oraz mniejszych, a także komentuje najważniejsze bieżące newsy branżowe. Czasem w ramach tego podcastu otrzymacie recenzje gier (po przejściu ich w całości), czasem wrażenia po kilku/nastu godzinach. To po prostu podcast o grach, w którym każdy znajdzie coś dla siebie. No i w każdym odcinku polecajka gry niezależnej :)

#podcast #gaming

