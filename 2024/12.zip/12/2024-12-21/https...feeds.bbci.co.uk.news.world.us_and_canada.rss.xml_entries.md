# Source:BBC US Canada News, URL:https://feeds.bbci.co.uk/news/world/us_and_canada/rss.xml, language:en-gb

## Trump picks Apprentice producer Mark Burnett as UK envoy
 - [https://www.bbc.com/news/articles/c3rqj5z1e5vo](https://www.bbc.com/news/articles/c3rqj5z1e5vo)
 - RSS feed: $source
 - date published: 2024-12-21T22:52:18+00:00

The London-born TV mogul says he is "truly honored" to serve as Trump's special envoy to the UK.

## Blake Lively accuses co-star Justin Baldoni of smear campaign
 - [https://www.bbc.com/news/articles/ckgz1pp1ne8o](https://www.bbc.com/news/articles/ckgz1pp1ne8o)
 - RSS feed: $source
 - date published: 2024-12-21T20:35:29+00:00

Mr Baldoni's lawyer says the allegations are "categorically false" and a "desperate attempt to 'fix' her negative reputation".

## Google suggests fixes to its search monopoly
 - [https://www.bbc.com/news/articles/c2kxpn2k08do](https://www.bbc.com/news/articles/c2kxpn2k08do)
 - RSS feed: $source
 - date published: 2024-12-21T07:52:31+00:00

Google proposed new limits after a judge ruled Google illegally crushed competition in search.

## Faced with turmoil, a defiant Trudeau hangs on - for now
 - [https://www.bbc.com/news/articles/c5ydl008yxeo](https://www.bbc.com/news/articles/c5ydl008yxeo)
 - RSS feed: $source
 - date published: 2024-12-21T05:00:24+00:00

As the longest serving G7 leader, the Canadian prime minister has weathered many storms. But this time might be different.

## Nurse imposter sentenced to seven years
 - [https://www.bbc.com/news/articles/cnv3q9qrdd4o](https://www.bbc.com/news/articles/cnv3q9qrdd4o)
 - RSS feed: $source
 - date published: 2024-12-21T01:48:30+00:00

Brigitte Cleroux had pled guilty to assaulting patients by IV injection while pretending to be a nurse.

