# Source:BBC Africa News, URL:https://feeds.bbci.co.uk/news/world/africa/rss.xml, language:en-gb

## Jogging memories: Why some Nigerians in London set up their own running club
 - [https://www.bbc.com/news/articles/c98d4dre9ydo](https://www.bbc.com/news/articles/c98d4dre9ydo)
 - RSS feed: $source
 - date published: 2024-12-21T09:47:00+00:00

Young Igbos in the UK meet up weekly to reconnect with their roots.

