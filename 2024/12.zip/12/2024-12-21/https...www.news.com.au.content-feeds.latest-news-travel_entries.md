# Source:news.com.au - Australia, URL:https://www.news.com.au/content-feeds/latest-news-travel, language:en-au

## Qantas to pay hefty fee for illegal sackings
 - [https://www.news.com.au/travel/travel-updates/incidents/qantas-to-pay-hefty-200000-fee-to-three-illegal-sacked-workers/news-story/7b54dc1e33e6a060b81059dbed633abe?from=rss-basic](https://www.news.com.au/travel/travel-updates/incidents/qantas-to-pay-hefty-200000-fee-to-three-illegal-sacked-workers/news-story/7b54dc1e33e6a060b81059dbed633abe?from=rss-basic)
 - RSS feed: $source
 - date published: 2024-12-21T00:17:11.559265+00:00

Qantas has been ordered to pay an eye-watering amount to compensate three of the 1700 workers who were illegally fired during the Covid pandemic.

## Future of iconic Aussie event in doubt
 - [https://www.news.com.au/travel/travel-updates/the-future-of-one-of-australias-most-iconic-events-is-in-doubt-after-administrators-were-called-in/news-story/4a4a4fce69f45679052fc18d61686727?from=rss-basic](https://www.news.com.au/travel/travel-updates/the-future-of-one-of-australias-most-iconic-events-is-in-doubt-after-administrators-were-called-in/news-story/4a4a4fce69f45679052fc18d61686727?from=rss-basic)
 - RSS feed: $source
 - date published: 2024-12-21T00:17:11.347176+00:00

Financial pressures has seen one of Australia’s most iconic and longest running events enter voluntary administration.

## Tourist bitten by dingo at popular holiday spot
 - [https://www.news.com.au/travel/travel-updates/incidents/rangers-investigate-woman-bitten-by-dingo-on-kgari/news-story/2efa327d920cca06379e3f46946a9d1d?from=rss-basic](https://www.news.com.au/travel/travel-updates/incidents/rangers-investigate-woman-bitten-by-dingo-on-kgari/news-story/2efa327d920cca06379e3f46946a9d1d?from=rss-basic)
 - RSS feed: $source
 - date published: 2024-12-21T00:17:09.428778+00:00

The tourist was walking to the toilet when she was attacked by a dingo, prompting authorities to warn other visitors about the importance of safety.

