# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## This Ultra Compact 1L Mini Gaming PC Is FAST!
 - [https://www.youtube.com/watch?v=GDeJmR0SHHE](https://www.youtube.com/watch?v=GDeJmR0SHHE)
 - RSS feed: $source
 - date published: 2024-12-21T15:05:00+00:00

A super small form factor 1L Mini gaming PC that runs AAA games you love to play!
In this video we put together an awesome mini gaming pc using a Lenovo think center M90q Gen 3 powered by an i5 12500T and the YESTON low profile single slot RTX 3050! This would make a great living room gaming pc due to its form factor!

Yeston RTX 3050 Low Profile: https://amzn.to/4gOSYcq

Amazon Lenovo Thinkcenter M90Q Gen 3: https://amzn.to/3ZGdDYU
eBay: https://ebay.us/6TO7Sc
PCIE16 Tiny8 P3 M90q Gen 3: https://amzn.to/4gJSNim
230W Power supply: https://ebay.us/HGFgm5

ThinkCenter M90q Gen 2: https://ebay.us/KDld05
PCIE16 Tiny6 P3 M90q Gen 2: https://amzn.to/3P7XxCD

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

Vip-Urcdkey Sale Code for software: ETA
Windows 10 Pro OEM Key($17): https://biitt.ly/KpEmf
Windows 11 Pro Key($23):https://biitt.ly/RUZiX
Windows10 Home Key($16):https://biitt.ly/2tPi1
Office 2019 pro key($51):https://bii

