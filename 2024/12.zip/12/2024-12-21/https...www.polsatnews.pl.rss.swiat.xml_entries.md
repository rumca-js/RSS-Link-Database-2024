# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## "Chodzi o bezpieczeństwo UE". Jest decyzja ws. granicy fińsko-rosyjskiej
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/chodzi-o-bezpieczenstwo-ue-jest-decyzja-ws-granicy-finsko-rosyjskiej](https://www.polsatnews.pl/wiadomosc/2024-12-21/chodzi-o-bezpieczenstwo-ue-jest-decyzja-ws-granicy-finsko-rosyjskiej)
 - RSS feed: $source
 - date published: 2024-12-21T21:18:37.936717+00:00

Fińska granica wschodnia pozostanie zamknięta, ponieważ nie ma porozumienia z Rosją w kwestii kontroli migrantów nieposiadających odpowiednich dokumentów - oświadczył w sobotę szef rządu w Helsinkach Petteri Orpo. Dodał, że otwarcie przejścia oznaczałoby przepuszczanie przez stronę rosyjską azylantów.

## Biegnie z Kapsztadu do Londynu. Jego wyczyn ma zwrócić uwagę
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/biegnie-z-kapsztadu-do-londynu-jego-wyczyn-ma-zwrocic-uwage](https://www.polsatnews.pl/wiadomosc/2024-12-21/biegnie-z-kapsztadu-do-londynu-jego-wyczyn-ma-zwrocic-uwage)
 - RSS feed: $source
 - date published: 2024-12-21T20:13:00+00:00

Ugandyjczyk Deo Kato w niedzielę zakończy transkontynentalny bieg z Kapsztadu do Londynu. Sportowiec biegnie już ponad 500 dni, w trakcie których pokonał 12 440 km. Mężczyzna chce przez swój wyczyn zwrócić uwagę na temat rasizmu oraz losu migrantów, którzy pokonują podobną trasę.

## Autobus zderzył się z ciężarówką. Tragedia w Brazylii
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/autobus-zderzyl-sie-z-ciezarowka-kilkadziesiat-ofiar-w-brazylii](https://www.polsatnews.pl/wiadomosc/2024-12-21/autobus-zderzyl-sie-z-ciezarowka-kilkadziesiat-ofiar-w-brazylii)
 - RSS feed: $source
 - date published: 2024-12-21T18:05:20.456853+00:00

Co najmniej 32 osoby zginęły w zderzeniu autobusu z ciężarówką w brazylijskim stanie Minas Gerais. Jak przekazują służby po wypadku autobus stanął w płomieniach. Bilans ofiar może wzrosnąć.

## Atak na jarmarku w Magdeburgu. Nie żyje pięć osób, w tym dziewięcioletnie dziecko
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/niemcy-atak-na-jarmark-w-magdeburgu-nie-zyje-piec-osob-w-tym-9-letnie-dziecko](https://www.polsatnews.pl/wiadomosc/2024-12-21/niemcy-atak-na-jarmark-w-magdeburgu-nie-zyje-piec-osob-w-tym-9-letnie-dziecko)
 - RSS feed: $source
 - date published: 2024-12-21T18:05:20.315063+00:00

Wśród ofiar ataku na jarmark bożonarodzeniowy w Magdeburgu jest dziewięcioletnie dziecko i cztery osoby dorosłe - wynika z informacji przekazanych przez szefa prokuratury w tym mieście, Horsta Waltera Nopensa. 200 osób zostało rannych.

## Sebastian Walukiewicz zasłabł podczas meczu. Piłkarz Torino trafił do szpitala
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/sebastian-walukiewicz-zaslabl-podczas-meczu-pilkarz-torino-trafil-do-szpitala](https://www.polsatnews.pl/wiadomosc/2024-12-21/sebastian-walukiewicz-zaslabl-podczas-meczu-pilkarz-torino-trafil-do-szpitala)
 - RSS feed: $source
 - date published: 2024-12-21T18:05:20.049492+00:00

Sebastian Walukiewicz, polski obrońca grający we włoskim Torino trafił w sobotę do szpitala. Reprezentant Polski zasłabł podczas spotkania Serie A i opuścił boisko na noszach. Według mediów z Półwyspu Apenińskiego miał problemy z oddychaniem, ale cały czas był przytomny i świadomy.

## Zamach w Magdeburgu. "Szok powoli przeradza się w rozdrażnienie"
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/zamach-w-magdeburgu-narasta-rozdraznienie](https://www.polsatnews.pl/wiadomosc/2024-12-21/zamach-w-magdeburgu-narasta-rozdraznienie)
 - RSS feed: $source
 - date published: 2024-12-21T17:00:30.210297+00:00

- Mamy bardzo ekstremalną sytuację. Ludzie płaczą, są bezsilni - powiedział na antenie Polsat News Bartłomiej Bukowski, przewodniczący Związku Polaków w Magdeburgu. Dodał, że początkowa żałoba powoli przeradza się w rozdrażnienie faktem, że politycy i służby nie zapobiegają podobnym sytuacjom.

## "Stoimy w obliczu kryzysu". Nieoficjalnie: Robert Fico poleci do Moskwy
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/stoimy-w-obliczu-kryzysu-nieoficjalnie-robert-fico-poleci-do-moskwy](https://www.polsatnews.pl/wiadomosc/2024-12-21/stoimy-w-obliczu-kryzysu-nieoficjalnie-robert-fico-poleci-do-moskwy)
 - RSS feed: $source
 - date published: 2024-12-21T15:55:24.283960+00:00

- Premier Słowacji Robert Fico uda się do Moskwy na spotkanie z Władimirem Putinem - podają serbskie media, powołując się na słowa prezydenta tego państwa Aleksandara Vucicia. Powodem ma być odmowa Ukrainy na tranzyt rosyjskiego gazu przez swoje terytorium. - Dzięki prezydentowi Wołodymyrowi Zełenskiemu ewidentnie stoimy w obliczu kryzysu gazowego - stwierdził Fico.

## Viktor Orban o azylu dla Romanowskiego: To nie ostatnie takie wydarzenie
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/viktor-orban-o-azylu-dla-romanowskiego-to-nie-ostatnie-takie-wydarzenie](https://www.polsatnews.pl/wiadomosc/2024-12-21/viktor-orban-o-azylu-dla-romanowskiego-to-nie-ostatnie-takie-wydarzenie)
 - RSS feed: $source
 - date published: 2024-12-21T11:35:18.624390+00:00

- Nie chciałbym, żeby to eskalowało na poziom premierów. Zależy nam, aby ten spór z Polską był utrzymywany na takim możliwym do zarządzania poziomie, dlatego nie powiem co sądzę o praworządności w Polsce - przekazał Viktor Orban. Węgierski premier zasugerował, że w nadchodzącym czasie kolejni politycy z Polski mogą otrzymać ochronę. W czwartek poseł PiS Marcin Romanowski otrzymał na Węgrzech azyl.

## Lotnisko w Rosji zostało zamknięte. Efekt działań Ukrainy
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/lotnisko-w-rosji-zostalo-zamkniete-efekt-dzialan-ukrainy](https://www.polsatnews.pl/wiadomosc/2024-12-21/lotnisko-w-rosji-zostalo-zamkniete-efekt-dzialan-ukrainy)
 - RSS feed: $source
 - date published: 2024-12-21T10:46:00+00:00

Lotnisko w rosyjskim Kazaniu tymczasowo wstrzymało przyloty i odloty. To efekt ataku ukraińskich dronów. Jak przekazały państwowe agencje, nie ma doniesień o ofiarach, jednak w mediach społecznościowych pojawiły się informacje o uderzeniach dronów w wieżowce.

## Zamach w Magdeburgu. Wzrosła liczba ofiar śmiertelnych
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/zamach-w-magdeburgu-wzrosla-liczba-ofiar-smiertelnych](https://www.polsatnews.pl/wiadomosc/2024-12-21/zamach-w-magdeburgu-wzrosla-liczba-ofiar-smiertelnych)
 - RSS feed: $source
 - date published: 2024-12-21T09:25:10.637348+00:00

Liczba ofiar śmiertelnych piątkowego zamachu na jarmarku bożonarodzeniowym w Magdeburgu wzrosła do czterech - poinformował w sobotę dziennik Bild, opierając się na doniesieniach policji.

## Olaf Scholz miał nakrzyczeć na Andrzeja Dudę. "Nawet nie używacie euro"
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/olaf-scholz-mial-nakrzyczec-na-andrzeja-dude-nawet-nie-uzywacie-euro](https://www.polsatnews.pl/wiadomosc/2024-12-21/olaf-scholz-mial-nakrzyczec-na-andrzeja-dude-nawet-nie-uzywacie-euro)
 - RSS feed: $source
 - date published: 2024-12-21T09:22:00+00:00

Olaf Scholz warknął i krzyczał na Andrzeja Dudę, krytykując jego poparcie dla wydania zamrożonych w Europie rosyjskich aktywów państwowych - podaje Financial Times. Niemiecki kanclerz miał przestrzegać przed reakcją rynków finansowych na podjęcie takiej decyzji i wytykać, że w Polsce nawet nie używa się euro. Pozostali uczestnicy spotkania mieli być zaskoczeni zachowaniem Scholza.

## Akcja służb na polskim statku. Znaleźli nielegalne substancje
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/akcja-sluzb-na-polskim-statku-znalezli-nielegalne-substancje](https://www.polsatnews.pl/wiadomosc/2024-12-21/akcja-sluzb-na-polskim-statku-znalezli-nielegalne-substancje)
 - RSS feed: $source
 - date published: 2024-12-21T07:15:15.704645+00:00

134 kilogramy zabronionych środków przejęły brazylijskie służby. Odnaleziono je w kadłubie statku Polsteam Łebsko, którego armatorem jest Polska Żegluga Morska. Pływa on jednak pod banderą Liberii. Co więcej, na jednostce znajdowała się również broń. To kolejny taki przypadek w ostatnim czasie - wcześniej problemy związane z działalnością karteli miała załoga jednostki Jawor.

## Zamach na jarmarku świątecznym w Niemczech. Podano tożsamość sprawcy
 - [https://www.polsatnews.pl/wiadomosc/2024-12-21/zamach-na-jarmarku-swiatecznym-w-niemczech-podano-tozsamosc-sprawcy](https://www.polsatnews.pl/wiadomosc/2024-12-21/zamach-na-jarmarku-swiatecznym-w-niemczech-podano-tozsamosc-sprawcy)
 - RSS feed: $source
 - date published: 2024-12-21T06:09:58.675209+00:00

Kierowca samochodu, który w piątek wjechał w tłum ludzi na jarmarku bożonarodzeniowym w Magdeburgu, pochodzi z Arabii Saudyjskiej. Mężczyzna miał wynająć pojazd na krótko przed atakiem. Służby ratownicze potwierdziły, że w wyniku ataku zginęły dwie osoby, 15 jest ciężko rannych. Władze zakładają, że był to zamach. Podejrzany sprawca został zatrzymany.

