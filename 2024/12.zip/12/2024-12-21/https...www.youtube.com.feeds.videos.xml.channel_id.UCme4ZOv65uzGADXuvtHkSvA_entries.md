# Source:Langusta na palmie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCme4ZOv65uzGADXuvtHkSvA, language:pl-PL

## Księga Sędziów || Rozdział 03
 - [https://www.youtube.com/watch?v=xpeA3vImCTc](https://www.youtube.com/watch?v=xpeA3vImCTc)
 - RSS feed: $source
 - date published: 2024-12-21T23:00:40+00:00

Przeczytajmy razem całe Pismo Święte! 
Codziennie czytamy 1 rozdział życiodajnego SŁOWA BOGA.

Wykorzystano najnowszy przekład Pisma Świętego z komentarzem, opracowany przez Zespół Biblistów Polskich z inicjatywy Towarzystwa Świętego Pawła (Edycja Świętego Pawła). Pierwszy przekład w trzecim tysiącleciu.

________________________________________
ŁASKAWNIK, czyli langustowy modlitewnik można nabyć tutaj: 
→ https://langustanapalmie.pl/products/laskawnik
________________________________________
BILETY na wydarzenie UNIESIENI dostępne tu: 
→ https://ekobilet.pl/shop/uniesieni
________________________________________
PORADNIK ANTYZWIĄZKOWY
→ https://langustanapalmie.pl/produkt/poradnik-antyzwiazkowy/
________________________________________
Książkę "Jak się modlić?" znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książka jest cegiełką i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
_____________

## CNN [#425] Wypełniasz wolę Bożą?
 - [https://www.youtube.com/watch?v=bT1VfzsukII](https://www.youtube.com/watch?v=bT1VfzsukII)
 - RSS feed: $source
 - date published: 2024-12-21T23:00:25+00:00

#cnn #dobrewiadomości #kazankodookienka   @Langustanapalmie 

Kazanko do okienka, czyli komentarz do niedzielnych czytań.

CzwartaNiedziela Adwentu
Rok C, I

1. czytanie (Mi 5, 1-4a)

Tak mówi Pan:
A ty, Betlejem Efrata, najmniejsze jesteś wśród plemion judzkich! z ciebie wyjdzie dla mnie Ten, który będzie władał w Izraelu, a pochodzenie Jego od początku, od dni wieczności. Przeto Pan porzuci ich aż do czasu, kiedy porodzi mająca porodzić. Wtedy reszta braci Jego powróci do synów Izraela.
Powstanie on i paść będzie mocą Pańską, w majestacie imienia Pana, Boga swego. Osiądą wtedy, bo odtąd rozciągnie swą potęgę aż po krańce ziemi. A on będzie pokojem.

2. czytanie (Hbr 10, 5-10)

Bracia:
Chrystus, przychodząc na świat, mówi: «ofiary ani daru nie chciałeś, ale Mi utworzyłeś ciało; całopalenia i ofiary za grzech nie podobały się Tobie. Wtedy rzekłem: oto idę – w zwoju księgi napisano o Mnie – aby spełnić wolę Twoją, Boże».
Wyżej powiedział: «ofiar, darów, całopaleń i ofiar za grzech nie

## Zasypiaki || 21.12.2024 Sobota
 - [https://www.youtube.com/watch?v=jG6vovipVbw](https://www.youtube.com/watch?v=jG6vovipVbw)
 - RSS feed: $source
 - date published: 2024-12-21T19:00:22+00:00

Czy szukasz czegoś więcej niż zwykłej kołysanki na dobranoc? 
Oto "Zasypiaki" - wieczorne Langustowe spotkania z Bogiem. 🌙🙏

Bez względu na to, czy jesteś na początku swojej podróży, czy jesteś już w przyjaźni z Nim, znajdziesz tu coś dla siebie. 🛤️💖 
To więcej niż podcast, to społeczność ludzi, którzy, podobnie jak Ty, szukają prawdziwych odpowiedzi. 🎧💭

Działaj! 🚀 Dołącz do nas na "Zasypiakach" i daj szansę Bogu i sobie. 
Czekamy na Ciebie codziennie o 20:00. ⏰🌟

🔥 Działaj z nami! ☞
→ https://niezlafundacja.pl/#darowizna
→ https://langustanapalmie.pl/przekaz-darowizne/
→ https://patronite.pl/langustanapalmie

#Zasypiaki #Podcast #AdamSzustak #NocneSpotkania 💫🌌

  @Langustanapalmie 
________________________________________
ŁASKAWNIK, czyli langustowy modlitewnik można nabyć tutaj: 
→ https://langustanapalmie.pl/products/laskawnik
________________________________________
BILETY na wydarzenie UNIESIENI dostępne są tu: 
→ https://ekobilet.pl/shop/uniesieni
_____________________________

## Roraty [#18] Altitudo serena
 - [https://www.youtube.com/watch?v=yAjgck4Xut8](https://www.youtube.com/watch?v=yAjgck4Xut8)
 - RSS feed: $source
 - date published: 2024-12-21T03:30:25+00:00

#roraty #litaniadominikańska  @Langustanapalmie 

W tegorocznych Roratach przyjrzymy się wybranym wezwaniom z Litanii Dominikańskiej do Najświętszej Maryi Panny. 🙏🏻

Zapraszamy Was na nieco poważniejsze adwentowe Wstawaki. 🙃

________________________________________
Aby wesprzeć ɴɪᴇᴢŁᴀ̨ ғᴜɴᴅᴀᴄᴊᴇ̨ zajmującą się dziełami Langusty na Palmie,
kliknij tutaj: 
→ https://langustanapalmie.pl/przekaz-darowizne/
________________________________________
ᴜɴɪᴇsɪᴇɴɪ - prezero arena gliwice, 1lutego 2025
→ https://langustanapalmie.pl/pages/wydarzenia
Łᴀsᴋᴀᴡɴɪᴋ
→ https://langustanapalmie.pl/products/laskawnik
ᴘᴏʀᴀᴅɴɪᴋ ᴀɴᴛʏᴢᴡɪᴀ̨ᴢᴋᴏᴡʏ
→ https://langustanapalmie.pl/produkt/poradnik-antyzwiazkowy/
ᴊᴀᴋ sɪᴇ̨ ᴍᴏᴅʟɪᴄ́ znajdziecie tu:
→ https://langustanapalmie.pl/produkt/jaksiemodlic/

Książki są cegiełkami i cały dochód ze sprzedaży jest przeznaczony na działalność Niezłej Fundacji zajmującej się dziełami Langusty Na Palmie.
________________________________________
Audiobooka z Nowenną Pompejańską znajdzie

