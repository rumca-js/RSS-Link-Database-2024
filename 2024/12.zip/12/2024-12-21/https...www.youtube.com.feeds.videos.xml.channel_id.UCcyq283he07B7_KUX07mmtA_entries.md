# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## The Evolution Of Musk And Trump's 'Bromance' | Business Insider
 - [https://www.youtube.com/watch?v=YLu_MsWnGyM](https://www.youtube.com/watch?v=YLu_MsWnGyM)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:27+00:00

How did Elon Musk go from being an Obama supporter to a self-described "dark MAGA" Trump ally? Here's a look at the relationship between two billionaires ahead of the second Trump presidency.

0:00 - From Obama To Trump?
0:56 - The Similarities Between Musk And Trump
1:23 - How Musk And Trump Became Billionaires
3:21 - Musk's Shift From Democrats To Republicans
6:56 - Trump's To Appoint Musk In The White House 
7:29 - Elon Musk Spent Millions To Support Trump’s Presidential Bid 
8:23 - How X Amplified Republican Voices
9:06 - How Elon Musk Landed In Trump's Inner Circle
10:10 - Musk's Growing Influence In Politics
10:21 - Elon Musk And Vivek Ramaswamy As Heads Of DOGE
10:55 - How Silicon Valley Could Benefit From This Bond
12:27 - Can This Friendship Last?
13:52 - Credits

------------------------------------------------------
#elonmusk #donaldtrump #businessinsider 

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage 

