# Source:RSS - Really Simple Syndication, URL:https://www.reddit.com/r/rss/.rss, language:en

## Yearly reminder that RSS-Bridge exists
 - [https://www.reddit.com/r/rss/comments/1hj9ytj/yearly_reminder_that_rssbridge_exists](https://www.reddit.com/r/rss/comments/1hj9ytj/yearly_reminder_that_rssbridge_exists)
 - RSS feed: $source
 - date published: 2024-12-21T13:36:11+00:00

<!-- SC_OFF --><div class="md"><p>RSS-Bridge is a PHP web application.</p> <p>It generates web feeds for websites that don&#39;t have one.</p> <p>IRC channel #rssbridge at <a href="https://libera.chat/">https://libera.chat/</a></p> <p>Requires minimum PHP 7.4.</p> <p>[0] <a href="https://github.com/RSS-Bridge/rss-bridge">https://github.com/RSS-Bridge/rss-bridge</a></p> <p>[1] Officially hosted instance: <a href="https://rss-bridge.org/bridge01/">https://rss-bridge.org/bridge01/</a></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/thirdplace_"> /u/thirdplace_ </a> <br/> <span><a href="https://www.reddit.com/r/rss/comments/1hj9ytj/yearly_reminder_that_rssbridge_exists/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/rss/comments/1hj9ytj/yearly_reminder_that_rssbridge_exists/">[comments]</a></span>

## How did you get reddit rss feeds to work again?
 - [https://www.reddit.com/r/rss/comments/1hj7elt/how_did_you_get_reddit_rss_feeds_to_work_again](https://www.reddit.com/r/rss/comments/1hj7elt/how_did_you_get_reddit_rss_feeds_to_work_again)
 - RSS feed: $source
 - date published: 2024-12-21T10:43:24+00:00

<!-- SC_OFF --><div class="md"><p>I get conflicted info, I can&#39;t manage to make them work the old way but people online seem to refe to reddit rss feeds like if they still work. </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AstronomerArtistic16"> /u/AstronomerArtistic16 </a> <br/> <span><a href="https://www.reddit.com/r/rss/comments/1hj7elt/how_did_you_get_reddit_rss_feeds_to_work_again/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/rss/comments/1hj7elt/how_did_you_get_reddit_rss_feeds_to_work_again/">[comments]</a></span>

