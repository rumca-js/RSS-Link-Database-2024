# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Germany Christmas market attack latest: US 'shocked' by incident
 - [https://abcnews.go.com/International/germany-christmas-market-attack-latest-us-shocked-incident/story?id=117011586](https://abcnews.go.com/International/germany-christmas-market-attack-latest-us-shocked-incident/story?id=117011586)
 - RSS feed: $source
 - date published: 2024-12-21T02:08:59+00:00

The U.S. was "shocked and saddened" by Friday's deadly suspected terrorist attack at a Christmas market in the German city of Magdeburg, a U.S. spokesperson said.

