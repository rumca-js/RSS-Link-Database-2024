# Source:Observer, URL:http://www.observer.com/feed, language:en

## An Insider’s Guide to Boulder, Colorado
 - [https://observer.com/list/boulder-colorado-local-travel-guide](https://observer.com/list/boulder-colorado-local-travel-guide)
 - RSS feed: $source
 - date published: 2024-12-21T15:30:00+00:00

Home to the Flatirons and the University of Colorado, Boulder is a scenic gateway to hiking, mountain biking and skiing, although you don’t have to be adventurous to enjoy everything the Colorado destination has to offer.

## Building Blocks of Reality: A Walkthrough of Ai Weiwei’s ‘Child’s’ Play’ at Vito Schnabel Gallery
 - [https://observer.com/2024/12/review-childs-play-ai-weiwei-vito-schnabel-gallery](https://observer.com/2024/12/review-childs-play-ai-weiwei-vito-schnabel-gallery)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:59+00:00

Observer's Stephen Wozniak shares his impressions of the exhibition after touring it with the artist.

