# Source:UploadVR, URL:https://www.uploadvr.com/rss, language:en

## XR News Round-Up: By Grit Alone, VRider SBK, Undead Citadel &amp; More
 - [https://www.uploadvr.com/xr-news-round-up-by-grit-alone-vrider-sbk-undead-citadel-more](https://www.uploadvr.com/xr-news-round-up-by-grit-alone-vrider-sbk-undead-citadel-more)
 - RSS feed: $source
 - date published: 2024-12-21T06:00:03+00:00

In our last XR News Round-Up for 2024, we&#39;re taking a look at stories like By Grit Alone&#39;s Xmas update and Undead Citadel&#39;s Quest 3 update.

