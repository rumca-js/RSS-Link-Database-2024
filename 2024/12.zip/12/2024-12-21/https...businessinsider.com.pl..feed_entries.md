# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Syria chce odbudować relacje ze światem. Wybrała człowieka do tego zadania
 - [https://businessinsider.com.pl/polityka/syria-chce-odbudowac-relacje-ze-swiatem-on-bedzie-za-to-odpowiedzialny/bf3fy8k](https://businessinsider.com.pl/polityka/syria-chce-odbudowac-relacje-ze-swiatem-on-bedzie-za-to-odpowiedzialny/bf3fy8k)
 - RSS feed: $source
 - date published: 2024-12-21T20:42:27+00:00

Poznaliśmy nazwisko nowego ministra spraw zagranicznych Syrii. To Asaad Hassan al-Szibani. Nowe władze przekonują, że koncentrują się na odbudowie i rozwoju gospodarczym, a nie na angażowaniu się w nowe konflikty.

## Panattoni sprzedaje dwa parki przemysłowe za 70 mln euro
 - [https://businessinsider.com.pl/nieruchomosci/dwa-parki-przemyslowe-za-70-mln-euro-nowa-transakcja-lidera-rynku/b3n878n](https://businessinsider.com.pl/nieruchomosci/dwa-parki-przemyslowe-za-70-mln-euro-nowa-transakcja-lidera-rynku/b3n878n)
 - RSS feed: $source
 - date published: 2024-12-21T20:08:33+00:00

Panattoni, największy deweloper nieruchomości przemysłowych, zakończył sprzedaż dwóch parków przemysłowych. Nabywcą obiektów jest globalny inwestor specjalizujący się w nieruchomościach komercyjnych, który tym samym debiutuje na polskim rynku.

## Kultowy producent gier na krawędzi bankructwa. Ostatni czas to pasmo porażek
 - [https://businessinsider.com.pl/gielda/wiadomosci/ubisoft-na-krawedzi-bankructwa-kultowy-producent-gier-ma-za-soba-pasmo-porazek/b9yxl34](https://businessinsider.com.pl/gielda/wiadomosci/ubisoft-na-krawedzi-bankructwa-kultowy-producent-gier-ma-za-soba-pasmo-porazek/b9yxl34)
 - RSS feed: $source
 - date published: 2024-12-21T19:39:12+00:00

Uznana marka w świecie gier wideo stoi na krawędzi bankructwa. Branżowi eksperci wskazują, że obecna sytuacja finansowa Ubisoftu sugeruje możliwość plajty w 2025 r. Wartość rynkowa biznesu w pięć lat spadła o około 80 proc. Firma jest ogromnie zadłużona.

## Ta gospodarka żyje z dnia na dzień. Racjonowany chleb i mleko
 - [https://businessinsider.com.pl/gospodarka/ta-gospodarka-zyje-z-dnia-na-dzien-brakuje-dla-wszystkich-chleba-i-mleka/h2ssf6h](https://businessinsider.com.pl/gospodarka/ta-gospodarka-zyje-z-dnia-na-dzien-brakuje-dla-wszystkich-chleba-i-mleka/h2ssf6h)
 - RSS feed: $source
 - date published: 2024-12-21T19:10:21+00:00

Mieszkańcy Kuby doświadczają niedoborów paliw, częstych przerw w dostawach prądu i wody. Podstawowa żywność i leki są racjonowane. Na te trudności nałożyły się również katastrofy naturalne, w tym cyklony i trzęsienia ziemi.

## Na prezentację tylko prywatnym samolotem. Tak kupują mieszkania milionerzy
 - [https://businessinsider.com.pl/nieruchomosci/polski-rynek-nieruchomosci-ultra-luksusowych/helx2fv](https://businessinsider.com.pl/nieruchomosci/polski-rynek-nieruchomosci-ultra-luksusowych/helx2fv)
 - RSS feed: $source
 - date published: 2024-12-21T18:43:10+00:00

Nieruchomości ultra luksusowe to nie tylko Konstancin-Jeziorna i inne bogate okolice Warszawy. Rekordowa transakcja sprzedaży apartamentu za 25 mln zł odbyła się w Gdańsku. Za tym sukcesem stoi Tomasz Modzelewski, właściciel MO Real Estate, z którym rozmawialiśmy o rynku premium w Trójmieście — o tym, jak sprzedaje się te najdroższe nieruchomości i kto je kupuje.

## Chiński masowiec podejrzewany o sabotaż po miesiącu wznowił rejs. "Śledzimy statek"
 - [https://businessinsider.com.pl/wiadomosci/tajemniczy-chinski-statek-podejrzewany-o-sabotaz-wznowil-rejs-gdzie-plynie/ytqxsvr](https://businessinsider.com.pl/wiadomosci/tajemniczy-chinski-statek-podejrzewany-o-sabotaz-wznowil-rejs-gdzie-plynie/ytqxsvr)
 - RSS feed: $source
 - date published: 2024-12-21T18:21:11+00:00

"Zaczął się poruszać i powiedział, że płynie do portu Said w Egipcie" — informuje szwedzka straż przybrzeżna. Przyznała, że służby śledzą chiński statek, który jest podejrzewany o sabotaż na Bałtyku.

## Prezydent Serbii zdradził plany premiera Słowacji. Ma się spotkać z Władimirem Putinem
 - [https://businessinsider.com.pl/polityka/robert-fico-i-wladimir-putin-prezydent-serbii-zdradzil-plany-spotkania/jqjy5d0](https://businessinsider.com.pl/polityka/robert-fico-i-wladimir-putin-prezydent-serbii-zdradzil-plany-spotkania/jqjy5d0)
 - RSS feed: $source
 - date published: 2024-12-21T17:51:17+00:00

"Nie muszę mówić, jaką reakcję wywoła wśród innych europejskich przywódców z UE" — powiedział prezydent Serbii, zapowiadając spotkanie Roberta Fico z Władimirem Putinem. To na razie nieoficjalne doniesienia, ale premier Słowacji ma pretekst do takiego spotkania.

## Najwyższy autorytet religijny w Libii wzywa do walki z rosyjskimi bojownikami
 - [https://businessinsider.com.pl/wiadomosci/kolejny-kraj-przeciw-rosjanom-najwyzszy-autorytet-religijny-wzywa-do-walki/lmylnt5](https://businessinsider.com.pl/wiadomosci/kolejny-kraj-przeciw-rosjanom-najwyzszy-autorytet-religijny-wzywa-do-walki/lmylnt5)
 - RSS feed: $source
 - date published: 2024-12-21T17:22:12+00:00

Wielki mufti Libii, szejk Sadik al-Ghariani, zaapelował do wszystkich Libijczyków o zjednoczenie się i podjęcie walki przeciwko Rosjanom, którzy przybyli do wschodniej części kraju z Syrii po obaleniu reżimu Baszara el-Asada.

## Ostatnie bastiony rękodzieła. Polscy producenci bombek bronią się przed "chińszczyzną"
 - [https://businessinsider.com.pl/biznes/ozdoby-swiateczne-polscy-producenci-bombek-bronia-sie-przed-chinszczyzna/ldt8dg9](https://businessinsider.com.pl/biznes/ozdoby-swiateczne-polscy-producenci-bombek-bronia-sie-przed-chinszczyzna/ldt8dg9)
 - RSS feed: $source
 - date published: 2024-12-21T16:54:17+00:00

W Polsce działa zaledwie około 10 firm zatrudniających od 20 do 50 osób, które produkują ręcznie bombki choinkowe i mogą utrzymać się na rynku. Większość polskich bombek trafia na rynek amerykański, gdzie klienci gotowi są płacić wyższe ceny. W Europie polskie ozdoby znajdują się głównie w najdroższych domach towarowych.

## Elon Musk coraz bardziej ingeruje w niemiecką politykę. "Niekompetentny głupiec"
 - [https://businessinsider.com.pl/polityka/elon-musk-w-niemieckiej-polityce-atakuje-kanclerza-olafa-scholza/5wv7hc5](https://businessinsider.com.pl/polityka/elon-musk-w-niemieckiej-polityce-atakuje-kanclerza-olafa-scholza/5wv7hc5)
 - RSS feed: $source
 - date published: 2024-12-21T16:27:10+00:00

Najpierw było poparcie dla skrajnie prawicowej partii, a teraz atak na kanclerza Niemiec słowami "niekompetentny głupiec". Elon Musk, bliski współpracownik prezydenta elekta Donalda Trumpa, w kilku niewybrednych słowach odniósł się do tragedii na jarmarku.

## Dlaczego Izera musiała zniknąć? Prawdziwa gra dopiero się zaczyna [OPINIA]
 - [https://businessinsider.com.pl/technologie/motoryzacja/dlaczego-izera-musiala-zniknac-prawdziwa-gra-dopiero-sie-zaczyna-opinia/7z1gcsl](https://businessinsider.com.pl/technologie/motoryzacja/dlaczego-izera-musiala-zniknac-prawdziwa-gra-dopiero-sie-zaczyna-opinia/7z1gcsl)
 - RSS feed: $source
 - date published: 2024-12-21T15:58:10+00:00

Izera przestała istnieć, ale Electromobility Poland wciąż może dostać miliardy z KPO. Rząd zdecydował się zwinąć pomysł polskiej marki samochodów elektrycznych, ale jednocześnie chciałby zatrzymać to, co najcenniejsze w projekcie. Polska wcale nie odchodzi od stołu z Chińczykami. Gra o przyszłość spółki wkracza właśnie w decydującą fazę.

## Donald Tusk rozmawiał z Wiktorem Orbanem. "Polityka jest prostsza, niż się niektórym wydaje"
 - [https://businessinsider.com.pl/polityka/donald-tusk-rozmawial-z-wiktorem-orbanem-odpowiedz-byla-fajna/vt08e16](https://businessinsider.com.pl/polityka/donald-tusk-rozmawial-z-wiktorem-orbanem-odpowiedz-byla-fajna/vt08e16)
 - RSS feed: $source
 - date published: 2024-12-21T15:32:10+00:00

"Orban nie lubi rozliczeń. Powiedział mi to wprost" — przyznał polski premier. Zdradził, że zapytał Wiktora Orbana, czy serio takie rzeczy opowiada na temat azylu. Odpowiedź była "fajna".

## Prezes spółki-matki TVN spieniężył akcje i wzbogacił się o miliony dolarów
 - [https://businessinsider.com.pl/gielda/wiadomosci/szef-wlasciciela-tvn-sprzedal-swoje-akcje-za-30-mln-dol/bn785vl](https://businessinsider.com.pl/gielda/wiadomosci/szef-wlasciciela-tvn-sprzedal-swoje-akcje-za-30-mln-dol/bn785vl)
 - RSS feed: $source
 - date published: 2024-12-21T15:05:21+00:00

Warner Bros Discovery chce sprzedać telewizję TVN, ale na razie wiemy o sprzedaży akcji amerykańskiego giganta przez prezesa. David Zaslav spieniężył ponad 2,5 mln akcji po średniej cenie 11,73 dol. za sztukę.

## Szef MON zapowiada trzy ważne zmiany dla weteranów i ich rodzin. "Na finiszu"
 - [https://businessinsider.com.pl/polityka/szef-mon-wladyslaw-kosiniak-kamysz-zapowiada-trzy-wazne-zmiany-dla-weteranow-i-rodzin/9j6fnsl](https://businessinsider.com.pl/polityka/szef-mon-wladyslaw-kosiniak-kamysz-zapowiada-trzy-wazne-zmiany-dla-weteranow-i-rodzin/9j6fnsl)
 - RSS feed: $source
 - date published: 2024-12-21T14:36:04+00:00

Każdy uszczerbek na zdrowiu weterana ma podlegać rekompensacie, a rodziny zmarłego żołnierza dostaną większe odszkodowania. To dwie z trzech zmian, jakie są bliskie finalizacji — zgodnie z zapowiedziały szefa MON.

## "Cud bożonarodzeniowy" w Volkswagenie. Jest decyzja w sprawie fabryk i zwolnień
 - [https://businessinsider.com.pl/biznes/volkswagen-zdecydowal-fabryki-zostaja-ale-beda-duze-zwolnienia/7dnnsel](https://businessinsider.com.pl/biznes/volkswagen-zdecydowal-fabryki-zostaja-ale-beda-duze-zwolnienia/7dnnsel)
 - RSS feed: $source
 - date published: 2024-12-21T14:09:20+00:00

Volkswagen ogłosił szeroko zakrojone zmiany w swojej niemieckiej działalności. Związki zawodowe ogłosiły "cud bożonarodzeniowy". Nie będzie na razie zamykania fabryk, ale pracę stracić ma ostatecznie ponad 35 tys. pracowników.

## Kontrowersje wokół Dariusza Wieczorka. Zaszkodzi rządowi? [SONDAŻ]
 - [https://businessinsider.com.pl/polityka/dariusz-wieczorek-zaszkodzi-rzadowi-polacy-zabrali-glos-sondaz/gkyb4yj](https://businessinsider.com.pl/polityka/dariusz-wieczorek-zaszkodzi-rzadowi-polacy-zabrali-glos-sondaz/gkyb4yj)
 - RSS feed: $source
 - date published: 2024-12-21T13:37:02+00:00

Kontrowersje wokół ministra nauki Dariusza Wieczorka mogą zaszkodzić notowaniom rządu Donalda Tuska — wynika z sondażu dla rp.pl. Jednocześnie niemal co czwarty ankietowany nie wie o ostatnich głośnych problemach, które doprowadziły do rezygnacji ministra.

## W portfelach banków rośnie temperatura. Kredyty zaczynają się psuć
 - [https://businessinsider.com.pl/finanse/w-portfelach-bankow-robi-sie-goraco-kredyty-zaczynaja-sie-psuc/seyf11k](https://businessinsider.com.pl/finanse/w-portfelach-bankow-robi-sie-goraco-kredyty-zaczynaja-sie-psuc/seyf11k)
 - RSS feed: $source
 - date published: 2024-12-21T13:09:34+00:00

W 2024 r. dynamika polskiego PKB przyśpieszyła do niespełna 3 proc. z zaledwie 0,1 proc. w 2023 r. O ile w ubiegłym roku wskaźniki spłacalności kredytów poprawiały się, o tyle w bieżącym widać pogorszenie. Głównie dotyczy to kredytów dla przedsiębiorstw, bo te udzielane gospodarstwom domowym wciąż trzymają się bardzo dobrze.

## Apple w końcu to zrobi. Najnowszy iPhone będzie inny niż wszystkie
 - [https://businessinsider.com.pl/technologie/nowe-technologie/apple-w-koncu-to-zrobi-najnowszy-iphone-bedzie-inny-niz-wszystkie/ewlj90r](https://businessinsider.com.pl/technologie/nowe-technologie/apple-w-koncu-to-zrobi-najnowszy-iphone-bedzie-inny-niz-wszystkie/ewlj90r)
 - RSS feed: $source
 - date published: 2024-12-21T12:31:20+00:00

Sprzedaż najnowszych modeli z AI nie jest tak dobra, jak sugerowano, więc Apple w końcu wprowadzi na rynek nie tylko cieńsze, ale też składane telefony. Najnowszy iPhone ma być więc wyraźnie inny niż dotychczasowe. To powinno znacząco ożywić sprzedaż, choć łatwo nie będzie.

## Azyl dla Romanowskiego. Viktor Orban zabrał głos
 - [https://businessinsider.com.pl/wiadomosci/azyl-dla-romanowskiego-viktor-orban-zabral-glos/dzfy7n0](https://businessinsider.com.pl/wiadomosci/azyl-dla-romanowskiego-viktor-orban-zabral-glos/dzfy7n0)
 - RSS feed: $source
 - date published: 2024-12-21T11:16:01+00:00

Przypadek udzielenia azylu Marcinowi Romanowskiemu nie będzie zapewne ostatni – powiedział premier Węgier Viktor Orban na sobotniej konferencji prasowej w Budapeszcie.

## Donald Tusk zabrał głos po ataku w Niemczech. Apeluje do prezydenta i PiS
 - [https://businessinsider.com.pl/wiadomosci/donald-tusk-zabral-glos-po-ataku-w-niemczech-a/0xnr44v](https://businessinsider.com.pl/wiadomosci/donald-tusk-zabral-glos-po-ataku-w-niemczech-a/0xnr44v)
 - RSS feed: $source
 - date published: 2024-12-21T10:33:05+00:00

"Po ataku w Magdeburgu już dziś oczekuję jasnej deklaracji Pana Prezydenta Dudy i PiS o poparciu rządowego pakietu zaostrzającego prawo wizowe i azylowe" — napisał Donald Tusk.

## Mam córki w wieku 13 i 15 lat. Pozwalam im marnować pieniądze w Sephorze. Tak uczą się życia
 - [https://businessinsider.com.pl/lifestyle/mam-corki-w-wieku-13-i-15-lat-pozwalam-im-marnowac-pieniadze-w-sephorze-tak-ucza-sie/6gdp8qj](https://businessinsider.com.pl/lifestyle/mam-corki-w-wieku-13-i-15-lat-pozwalam-im-marnowac-pieniadze-w-sephorze-tak-ucza-sie/6gdp8qj)
 - RSS feed: $source
 - date published: 2024-12-21T10:11:00+00:00

Moje nastolatki za każdym razem chcą kupić każdy modny produkt, jaki zobaczą w mediach społecznościowych, np. tusz do rzęs za równowartość 200 zł. Nie mam nic przeciwko temu, żeby same sobie to kupowały, ale nie dokładam się do takich zakupów. W ten sposób uczą się, że niektóre rzeczy nie są warte swojej wysokiej ceny, a właśnie na tym mi zależy.

## Lekarz, przeciwnik islamu, w Niemczech od 2006 r. Oto zamachowiec z Magdeburga
 - [https://businessinsider.com.pl/polityka/kim-jest-zamachowiec-z-magdeburga/pcfmfc9](https://businessinsider.com.pl/polityka/kim-jest-zamachowiec-z-magdeburga/pcfmfc9)
 - RSS feed: $source
 - date published: 2024-12-21T09:48:57+00:00

Po ataku na jarmark bożonarodzeniowy w Magdeburgu wciąż pozostaje wiele pytań bez odpowiedzi. — Nie wiemy, co nim kierowało, poza tym, że nienawidził Niemiec — mówi prof. Susanne Schröter, specjalizująca się w tematyce islamu. Przestępstwo jest "niezwykle zagmatwane".

## Katastrofy nie będzie. USA podjęły ważną decyzję
 - [https://businessinsider.com.pl/finanse/katastrofy-nie-bedzie-usa-podjely-wazna-decyzje/1hqq6cy](https://businessinsider.com.pl/finanse/katastrofy-nie-bedzie-usa-podjely-wazna-decyzje/1hqq6cy)
 - RSS feed: $source
 - date published: 2024-12-21T09:03:19+00:00

Kongres USA przegłosował w piątek w nocy prowizorium budżetowe, przedłużające obecny budżet do marca przyszłego roku. Wbrew żądaniom i groźbom prezydenta elekta Donalda Trumpa w ustawie zabrakło zniesienia lub zawieszenia limitu długu.

## Kolejny lek na leczenie otyłości. Jest zgoda władz
 - [https://businessinsider.com.pl/wiadomosci/kolejny-lek-na-leczenie-otylosci-jest-zgoda-wladz/ypn8e55](https://businessinsider.com.pl/wiadomosci/kolejny-lek-na-leczenie-otylosci-jest-zgoda-wladz/ypn8e55)
 - RSS feed: $source
 - date published: 2024-12-21T07:53:55+00:00

Amerykańskie organy regulacyjne zatwierdziły specyfik Zepbound firmy Eli Lilly do leczenia otyłości. To zwycięstwo producenta leków, który stara się rozszerzyć swoją przebojową serię leków odchudzających — pisze "Financial Times".

## Szefowa TVN zabrała głos. Uspokaja
 - [https://businessinsider.com.pl/media/sprzedaz-tvn-jest-list-do-pracownikow/rzm1y6e](https://businessinsider.com.pl/media/sprzedaz-tvn-jest-list-do-pracownikow/rzm1y6e)
 - RSS feed: $source
 - date published: 2024-12-21T07:29:18+00:00

Szefowa TVN wysłała list do pracowników firmy w związku ze sprzedażą. Podkreśliła w nim, że nadal nie ma pewności, czy do sprzedaży dojdzie. Zapewniła też, że "TVN jest i będzie bezpieczny".

## Kim Dzong Un może być dumny. Jego ludzie nigdy nie ukradli tak dużo
 - [https://businessinsider.com.pl/wiadomosci/korea-polnocna-jeszcze-nigdy-nie-ukradla-tak-duzo/67jdnsf](https://businessinsider.com.pl/wiadomosci/korea-polnocna-jeszcze-nigdy-nie-ukradla-tak-duzo/67jdnsf)
 - RSS feed: $source
 - date published: 2024-12-21T06:37:48+00:00

Hakerzy powiązani z Koreą Północną ukradli w ostatnim roku ponad 1,3 mld dol. z platform kryptowalutowych. To największa w historii kwota, jaką uzyskali z działań hakerskich.

## 15 Polek, które trzeba znać. Będzie wstyd, ale polegniesz już na 5. pytaniu
 - [https://businessinsider.com.pl/wiadomosci/15-polek-ktore-trzeba-znac-polegniesz-juz-na-5-pytaniu/fvn2k7q](https://businessinsider.com.pl/wiadomosci/15-polek-ktore-trzeba-znac-polegniesz-juz-na-5-pytaniu/fvn2k7q)
 - RSS feed: $source
 - date published: 2024-12-21T06:00:36+00:00

Te Polki wbrew społecznym ograniczeniom realizowały swoje pasje, zmieniały dzieje świata i wywarły ogromny wpływ na rzeczywistość. Ich życiorysy i dokonania niejednokrotnie przyprawiają o zawrót głowy i budzą niedowierzanie. Na pewno warto je znać, dlatego dziś przygotowaliśmy 15 pytań, które zweryfikują twoją wiedzę. Trzymamy kciuki!

## Wiek emerytalny do zrównania. "To absolutna konieczność"
 - [https://businessinsider.com.pl/praca/wiek-emerytalny-do-zrownania-to-absolutna-koniecznosc/7s2z4ny](https://businessinsider.com.pl/praca/wiek-emerytalny-do-zrownania-to-absolutna-koniecznosc/7s2z4ny)
 - RSS feed: $source
 - date published: 2024-12-21T05:45:01+00:00

Czy wiek emerytalny kobiet i mężczyzn w Polsce zostanie zrównany? —To jest absolutna konieczność — uważa dyrektorka Instytutu Statystyki i Demografii SGH prof. Agnieszka Chłoń-Domińczak. Jak tłumaczy, dzisiejszy niski wiek emerytalny kobiet dyskryminuje właśnie kobiety.

## Zasiłki, aktywizacja i doradztwo: strategie walki z bezrobociem w Polsce
 - [https://businessinsider.com.pl/praca/zasilki-programy-aktywizacyjne-i-doradztwo-zawodowe-w-polsce/kmfbw5z](https://businessinsider.com.pl/praca/zasilki-programy-aktywizacyjne-i-doradztwo-zawodowe-w-polsce/kmfbw5z)
 - RSS feed: $source
 - date published: 2024-12-21T05:19:18+00:00

W Polsce osoby pozostające bez zatrudnienia mogą liczyć na wsparcie w postaci zasiłków, programów aktywizacyjnych oraz doradztwa zawodowego. Choć zasady przyznawania pomocy są jednakowe w całym kraju, skuteczność tych rozwiązań różni się w zależności od regionu.

## Tak poprawiają się faceci z korpo. "Sekret, o którym wiedzą wszyscy"
 - [https://businessinsider.com.pl/lifestyle/tak-poprawiaja-sie-faceci-z-korpo-sekret-o-ktorym-wiedza-wszyscy/exgp070](https://businessinsider.com.pl/lifestyle/tak-poprawiaja-sie-faceci-z-korpo-sekret-o-ktorym-wiedza-wszyscy/exgp070)
 - RSS feed: $source
 - date published: 2024-12-21T05:17:00+00:00

Zabiegi kosmetyczne, przeszczepy włosów, a nawet operacje chirurgiczne. Pracownicy umysłowi w USA wydają tysiące dolarów, aby dobrze wyglądać, ale nie chcą, żeby ktokolwiek się o tym dowiedział.

## Przyczajony CPN, ukryty Orlen. To jedyna taka stacja w Polsce
 - [https://businessinsider.com.pl/wiadomosci/przyczajony-cpn-ukryty-orlen-to-jedyna-taka-stacja-w-polsce/hy179cn](https://businessinsider.com.pl/wiadomosci/przyczajony-cpn-ukryty-orlen-to-jedyna-taka-stacja-w-polsce/hy179cn)
 - RSS feed: $source
 - date published: 2024-12-21T05:00:00+00:00

To była kiedyś najbardziej znana polska firma. CPN to dawniej wręcz synonim stacji benzynowej. Ale pomarańczowa marka musiała ustąpić miejsca biało-czerwonemu Orlenowi. Z tym że nie do końca — w Polsce działa ciągle jeden CPN. Pojechałem tam zatankować.

