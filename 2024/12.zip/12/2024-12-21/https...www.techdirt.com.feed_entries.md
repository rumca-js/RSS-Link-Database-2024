# Source:Techdirt, URL:https://www.techdirt.com/feed, language:en-US

## This Week In Techdirt History: December 15th – 21st
 - [https://www.techdirt.com/2024/12/21/this-week-in-techdirt-history-december-15th-21st](https://www.techdirt.com/2024/12/21/this-week-in-techdirt-history-december-15th-21st)
 - RSS feed: $source
 - date published: 2024-12-21T20:00:00+00:00

Five Years Ago This week in 2019, the biggest copyright trolls were facing some issues in court and trying new strategies, while the Sons of Confederate Veterans were sued over a bogus DMCA takedown and we analyzed the choice of venue. We also saw some particularly insane copyright damages against Cox. Avast was downplaying its [&#8230;]

## Bad Sign: Pocketpair Updates ‘Palworld’ By Nixxing Pal Spheres
 - [https://www.techdirt.com/2024/12/20/bad-sign-pocketpair-updates-palworld-by-nixxing-pal-spheres](https://www.techdirt.com/2024/12/20/bad-sign-pocketpair-updates-palworld-by-nixxing-pal-spheres)
 - RSS feed: $source
 - date published: 2024-12-21T03:39:00+00:00

We&#8217;re still waiting for the lawsuit in Japan between Nintendo, The Pokémon Co., and Pocketpair to get rolling, but that doesn&#8217;t keep the dispute out of the news. The patent lawsuit, itself a surprise as everyone thought it would be a copyright gambit that Nintendo would try, centers around several patents that all relate to [&#8230;]

