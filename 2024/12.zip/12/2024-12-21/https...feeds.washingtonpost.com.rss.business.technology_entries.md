# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Amazon protest expands to N.Y. as union hopes to disrupt holiday deliveries
 - [https://www.washingtonpost.com/business/2024/12/21/amazon-strike-expands-delivery-delays](https://www.washingtonpost.com/business/2024/12/21/amazon-strike-expands-delivery-delays)
 - RSS feed: $source
 - date published: 2024-12-21T19:33:40+00:00

Workers in Staten Island joined in a series of strikes led by the Teamsters that began on Thursday. Amazon said its operations won’t be significantly affected.

## Why some kids are getting Walkmen and CDs for Christmas
 - [https://www.washingtonpost.com/technology/2024/12/21/kids-music-devices](https://www.washingtonpost.com/technology/2024/12/21/kids-music-devices)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:00+00:00

How do you let kids to listen to music without staring at more screens? These parents are starting with their own retro cassette, CDs and MP3 players.

## Meta’s WhatsApp wins ruling holding spyware maker NSO liable for hacking
 - [https://www.washingtonpost.com/technology/2024/12/20/whatsapp-meta-nso-pegasus-hacking-spyware](https://www.washingtonpost.com/technology/2024/12/20/whatsapp-meta-nso-pegasus-hacking-spyware)
 - RSS feed: $source
 - date published: 2024-12-21T00:38:15+00:00

Israel-based maker of Pegasus program loses five-year-old landmark case.

