# Source:Goonhammer, URL:https://www.goonhammer.com/feed, language:en-GB

## Charlie’s 2024 Hobby Year in Review
 - [https://www.goonhammer.com/charlies-2024-hobby-year-in-review](https://www.goonhammer.com/charlies-2024-hobby-year-in-review)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:25+00:00

2024’s coming to a close, and so the Goonhammer goons are reflecting on their hobby progress and whether to give themselves a pat on the back, or a slice of humble pie. Today, it’s Charlie B’s turn.

## Hextech Terrain: Hills, Woods, and Sprawl – The Goonhammer Review
 - [https://www.goonhammer.com/hextech-terrain-hills-woods-and-sprawl-the-goonhammer-review](https://www.goonhammer.com/hextech-terrain-hills-woods-and-sprawl-the-goonhammer-review)
 - RSS feed: $source
 - date published: 2024-12-21T15:00:21+00:00

Another launch of Gale Force 9 Hextech pre-painted terrain brings autumn trees, more hills, and smaller buildings to your Battletech tables.

## The 25 Days of Grotmas Recap, Part II
 - [https://www.goonhammer.com/25-days-of-grotmas-recap-part-ii](https://www.goonhammer.com/25-days-of-grotmas-recap-part-ii)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:31+00:00

One more week of Grotmas in the books, packed with fresh updates for 40k and AoS. We recap everything released this past week so you can catch up on all of it.

## Detachment Focus: Auxiliary Cadre
 - [https://www.goonhammer.com/detachment-focus-auxiliary-cadre](https://www.goonhammer.com/detachment-focus-auxiliary-cadre)
 - RSS feed: $source
 - date published: 2024-12-21T12:01:53+00:00

The T'au are celebrating Grotmas with a Detachment that focuses on auxiliary and T'au units fighting side-by-side. We take a deep dive into the new rules and how to play with them.

## CYRAC: 64 Player Kill Team Tournament Report
 - [https://www.goonhammer.com/cyrac-64-player-kill-team-tournament-report](https://www.goonhammer.com/cyrac-64-player-kill-team-tournament-report)
 - RSS feed: $source
 - date published: 2024-12-21T11:00:47+00:00

John from Can You Roll a Crit? is back again with a tournament report for Kill Team!

