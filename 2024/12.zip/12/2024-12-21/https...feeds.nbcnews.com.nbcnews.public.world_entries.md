# Source:NBC world, URL:https://feeds.nbcnews.com/nbcnews/public/world, language:en-US

## Houthis fire a ballistic missile named 'Palestine 2' at Tel Aviv
 - [https://www.nbcnews.com/news/world/houthis-launch-ballistic-missile-named-palestine-2-tel-aviv-rcna185106](https://www.nbcnews.com/news/world/houthis-launch-ballistic-missile-named-palestine-2-tel-aviv-rcna185106)
 - RSS feed: $source
 - date published: 2024-12-21T09:16:50+00:00

A missile launched from Yemen struck the Israeli city of Tel Aviv early Saturday morning, marking a rare instance of a failed interception over the city, the Israel Defense Forces said.

