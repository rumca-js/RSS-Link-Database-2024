# Source:Deep Web, URL:https://www.reddit.com/r/deepweb/.rss, language:en

## Sites
 - [https://www.reddit.com/r/deepweb/comments/1hjil0k/sites](https://www.reddit.com/r/deepweb/comments/1hjil0k/sites)
 - RSS feed: $source
 - date published: 2024-12-21T20:36:55+00:00

<!-- SC_OFF --><div class="md"><p>Does anyone know of any sites on deepweb where I can find course logins? or course material?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Groundbreaking_Zone8"> /u/Groundbreaking_Zone8 </a> <br/> <span><a href="https://www.reddit.com/r/deepweb/comments/1hjil0k/sites/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/deepweb/comments/1hjil0k/sites/">[comments]</a></span>

## V2k mind reading device
 - [https://www.reddit.com/r/deepweb/comments/1hjctit/v2k_mind_reading_device](https://www.reddit.com/r/deepweb/comments/1hjctit/v2k_mind_reading_device)
 - RSS feed: $source
 - date published: 2024-12-21T16:04:46+00:00

<!-- SC_OFF --><div class="md"><p>Does anyone on dark web know where to find mind reading device or something from that kind of devices.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BoatZealousideal9909"> /u/BoatZealousideal9909 </a> <br/> <span><a href="https://www.reddit.com/r/deepweb/comments/1hjctit/v2k_mind_reading_device/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/deepweb/comments/1hjctit/v2k_mind_reading_device/">[comments]</a></span>

## Dark web sites
 - [https://www.reddit.com/r/deepweb/comments/1hjc9mz/dark_web_sites](https://www.reddit.com/r/deepweb/comments/1hjc9mz/dark_web_sites)
 - RSS feed: $source
 - date published: 2024-12-21T15:38:08+00:00

<!-- SC_OFF --><div class="md"><p>How can I get to surveillance device websites on dark web?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BoatZealousideal9909"> /u/BoatZealousideal9909 </a> <br/> <span><a href="https://www.reddit.com/r/deepweb/comments/1hjc9mz/dark_web_sites/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/deepweb/comments/1hjc9mz/dark_web_sites/">[comments]</a></span>

## Any opinions on Panda Wireless pau03
 - [https://www.reddit.com/r/deepweb/comments/1hj9ipk/any_opinions_on_panda_wireless_pau03](https://www.reddit.com/r/deepweb/comments/1hj9ipk/any_opinions_on_panda_wireless_pau03)
 - RSS feed: $source
 - date published: 2024-12-21T13:09:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/deepweb/comments/1hj9ipk/any_opinions_on_panda_wireless_pau03/"> <img src="https://preview.redd.it/wlvu4bx2b78e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=09056cf7df1d411e9d0b41bfbd0ad3746d5bb36f" alt="Any opinions on Panda Wireless pau03" title="Any opinions on Panda Wireless pau03" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IShowCodeine"> /u/IShowCodeine </a> <br/> <span><a href="https://i.redd.it/wlvu4bx2b78e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/deepweb/comments/1hj9ipk/any_opinions_on_panda_wireless_pau03/">[comments]</a></span> </td></tr></table>

## Do you know a website for wishlist ?
 - [https://www.reddit.com/r/deepweb/comments/1hj77e2/do_you_know_a_website_for_wishlist](https://www.reddit.com/r/deepweb/comments/1hj77e2/do_you_know_a_website_for_wishlist)
 - RSS feed: $source
 - date published: 2024-12-21T10:28:19+00:00

<!-- SC_OFF --><div class="md"><p>Recently I saw a video of a French guy on youtube who showed a site where you could put links and a cover letter and people would buy you the things you wanted. (The site interface is in French so if there are any French people who know). Oh and also I know that I shouldn&#39;t put my address but so how do I do it? Maybe a relay point but I don&#39;t know if it&#39;s possible. Thanks for tour help. You can watch the video in French. The website that I want to know about it is the first one. <a href="https://youtu.be/jY0DGM3Mm54?si=2PUQFG0tq4LqVPIP">https://youtu.be/jY0DGM3Mm54?si=2PUQFG0tq4LqVPIP</a> (link of the video in french)</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Lazyx_Nat18"> /u/Lazyx_Nat18 </a> <br/> <span><a href="https://www.reddit.com/r/deepweb/comments/1hj77e2/do_you_know_a_website_for_wishlist/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/deepweb/comments/1hj77e2/do_you_k

## Has anyone heard of the site "Forbiden.com"
 - [https://www.reddit.com/r/deepweb/comments/1hiyntb/has_anyone_heard_of_the_site_forbidencom](https://www.reddit.com/r/deepweb/comments/1hiyntb/has_anyone_heard_of_the_site_forbidencom)
 - RSS feed: $source
 - date published: 2024-12-21T01:06:18+00:00

<!-- SC_OFF --><div class="md"><p>I stumbled upon this weird site when I was typing in random website names. So I typed in this, purposely leaving out one of the D&#39;s. It led me to a blank white page with a search bar to the right and a little bit of text saying something like &quot;contact &#39;Forbiden.com&#39;&quot;.</p> <p>Despite what I type into the search bar, it only gives me the same result. &quot;No results found&quot;. I&#39;m curious as to any information about the site. It seems a bit... odd. </p> <p>Does anyone have information about this strange site?</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CAP0RKLIFF"> /u/CAP0RKLIFF </a> <br/> <span><a href="https://www.reddit.com/r/deepweb/comments/1hiyntb/has_anyone_heard_of_the_site_forbidencom/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/deepweb/comments/1hiyntb/has_anyone_heard_of_the_site_forbidencom/">[comments]</a></span>

