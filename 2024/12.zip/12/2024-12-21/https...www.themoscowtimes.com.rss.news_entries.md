# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Ukrainian Drones Crash Into High-Rise Apartment Buildings in Russia’s Kazan
 - [https://www.themoscowtimes.com/2024/12/21/ukrainian-drones-crash-into-high-rise-apartment-buildings-in-russias-kazan-a87420](https://www.themoscowtimes.com/2024/12/21/ukrainian-drones-crash-into-high-rise-apartment-buildings-in-russias-kazan-a87420)
 - RSS feed: $source
 - date published: 2024-12-21T11:36:11.486509+00:00

Regional authorities accused Kyiv of deliberately attacking civilians in the early morning strikes, which reportedly injured three people.

