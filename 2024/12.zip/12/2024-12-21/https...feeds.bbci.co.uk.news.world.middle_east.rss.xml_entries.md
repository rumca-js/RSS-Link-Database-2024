# Source:BBC Middle East News, URL:https://feeds.bbci.co.uk/news/world/middle_east/rss.xml, language:en-gb

## 'We have to be more bold': Syria's musicians await future under new Islamist leaders
 - [https://www.bbc.com/news/articles/c3we9p8gvy5o](https://www.bbc.com/news/articles/c3we9p8gvy5o)
 - RSS feed: $source
 - date published: 2024-12-21T06:53:30+00:00

A lively electronic music scene developed under the Assad regime. Now, it's unclear what comes next.

