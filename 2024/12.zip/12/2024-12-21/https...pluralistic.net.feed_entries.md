# Source:Pluralistic: Daily links from Cory Doctorow, URL:https://pluralistic.net/feed, language:en-US

## Pluralistic: Proud to be a blockhead (21 Dec 2024)
 - [https://pluralistic.net/2024/12/21/blockheads-r-us](https://pluralistic.net/2024/12/21/blockheads-r-us)
 - RSS feed: $source
 - date published: 2024-12-21T22:38:47+00:00

Today's links Proud to be a blockhead: The true economics of creativity and communication. Hey look at this: Delights to delectate. This day in history: 2009, 2014, 2019, 2023 Upcoming appearances: Where to find me. Recent appearances: Where I've been. Latest books: You keep readin' em, I'll keep writin' 'em. Upcoming books: Like I said, I'll keep writin' 'em. Colophon: All the rest. Proud to be a blockhead (permalink) This is my last Pluralistic post of the year, and rather than round up my most successful posts of the year, I figured I'd write a little about why it's impossible for me to do that, and why that is by design, and what that says about the arts, monopolies, and creative labor markets. I started Pluralistic nearly five years ago, and from the outset, I was adamant that I wouldn't measure my success through quantitative measures. The canonical version of Pluralistic &#8211; the one that lives at pluralistic.net &#8211; has no metrics, no analytics, no logs, and no trackin

