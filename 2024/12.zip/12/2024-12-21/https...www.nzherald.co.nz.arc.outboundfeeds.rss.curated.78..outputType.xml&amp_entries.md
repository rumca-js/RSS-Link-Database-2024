# Source:New Zealand Herald, URL:https://www.nzherald.co.nz/arc/outboundfeeds/rss/curated/78/?outputType=xml&amp, language:en

## Headquarters bar fight: Man arrested after woman allegedly punched in mouth during Christmas party
 - [https://www.nzherald.co.nz/nz/headquarters-bar-fight-man-arrested-after-woman-allegedly-punched-in-mouth-during-christmas-party/A6ASCZT55RB4LALPK3IU5CF7NA](https://www.nzherald.co.nz/nz/headquarters-bar-fight-man-arrested-after-woman-allegedly-punched-in-mouth-during-christmas-party/A6ASCZT55RB4LALPK3IU5CF7NA)
 - RSS feed: $source
 - date published: 2024-12-21T22:30:00+00:00

Headquarters owner Leo Molloy has offered to compensate the young victim and her father.

## Missing teen Maia Johnston: Upper Hutt community, desperate family search in pouring rain
 - [https://www.nzherald.co.nz/nz/missing-teen-maia-johnston-upper-hutt-community-desperate-family-search-in-pouring-rain/UPL26NZ5OJEB7HUZ3KWDOFUIIQ](https://www.nzherald.co.nz/nz/missing-teen-maia-johnston-upper-hutt-community-desperate-family-search-in-pouring-rain/UPL26NZ5OJEB7HUZ3KWDOFUIIQ)
 - RSS feed: $source
 - date published: 2024-12-21T20:05:33+00:00

Maia was last seen at 8pm when she left the house to go for a walk in an unfamiliar area.

## The mother of all budget requests: This Government needs to slash spending even more  - Heather du Plessis-Allan
 - [https://www.nzherald.co.nz/nz/the-mother-of-all-budget-requests-this-government-needs-to-slash-spending-even-more-heather-du-plessis-allan/HLLY674NBNBIPHZE3IIBPHVU7I](https://www.nzherald.co.nz/nz/the-mother-of-all-budget-requests-this-government-needs-to-slash-spending-even-more-heather-du-plessis-allan/HLLY674NBNBIPHZE3IIBPHVU7I)
 - RSS feed: $source
 - date published: 2024-12-21T17:00:00+00:00

OPINION: They need to rip, sh*t and bust.  Slash unnecessary spending.

## Baradene College of the Sacred Heart principal Sandy Pasley retires from school
 - [https://www.nzherald.co.nz/nz/baradene-college-of-the-sacred-heart-principal-sandy-pasley-retires-from-school/COBS4DG7P5B6VCSJ2G3P5RYYTU](https://www.nzherald.co.nz/nz/baradene-college-of-the-sacred-heart-principal-sandy-pasley-retires-from-school/COBS4DG7P5B6VCSJ2G3P5RYYTU)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:00+00:00

'When I started, teacher salaries were near to what backbench MPs were getting.'

## Helena Cribb, sentenced to home detention for drunken hit-and-run death, flaunts ankle bracelet and drink in private social media posts
 - [https://www.nzherald.co.nz/nz/helena-cribb-sentenced-to-home-detention-for-drunken-hit-and-run-death-flaunts-ankle-bracelet-and-drink-in-private-social-media-posts/TC6ZI5NRNRCHFJXV36FWI6NBHU](https://www.nzherald.co.nz/nz/helena-cribb-sentenced-to-home-detention-for-drunken-hit-and-run-death-flaunts-ankle-bracelet-and-drink-in-private-social-media-posts/TC6ZI5NRNRCHFJXV36FWI6NBHU)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:00+00:00

Helena Cribb told a probation officer she hadn't drunk alcohol in months.

## House-sitter Judith Webby has dog die in her care while owners watch on CCTV from overseas
 - [https://www.nzherald.co.nz/nz/house-sitter-judith-webby-has-dog-die-in-her-care-while-owners-watch-on-cctv-from-overseas/RLPO3ZBKSFGZFIYCIUPDSYE5EU](https://www.nzherald.co.nz/nz/house-sitter-judith-webby-has-dog-die-in-her-care-while-owners-watch-on-cctv-from-overseas/RLPO3ZBKSFGZFIYCIUPDSYE5EU)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:00+00:00

Judith Webby has a long history of upsetting flatmates, and home- and pet-owners.

## Inquiry into death in India of Navy cadet Sacha Piper says systems kept NZDF health experts out of reach
 - [https://www.nzherald.co.nz/nz/inquiry-into-death-in-india-of-navy-cadet-sacha-piper-says-systems-kept-nzdf-health-experts-out-of-reach/MA2FP3PMMJBFXK63WSRKXZQ5TY](https://www.nzherald.co.nz/nz/inquiry-into-death-in-india-of-navy-cadet-sacha-piper-says-systems-kept-nzdf-health-experts-out-of-reach/MA2FP3PMMJBFXK63WSRKXZQ5TY)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:00+00:00

Inquiry released into the death of Navy cadet Sacha Piper in India.

## Liam Dann: The only way is up for the economy in 2025 (surely)
 - [https://www.nzherald.co.nz/business/liam-dann-the-only-way-is-up-in-2025-surely/HKWWF75M2NB3TFFKDJGDVXQI6E](https://www.nzherald.co.nz/business/liam-dann-the-only-way-is-up-in-2025-surely/HKWWF75M2NB3TFFKDJGDVXQI6E)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:00+00:00

OPINION: Last week's GDP shocker took the edge off the Christmas cheer,

## Spurned lover’s revenge on cheating husband and his wife ends in home detention for false allegations
 - [https://www.nzherald.co.nz/nz/spurned-lovers-revenge-on-cheating-husband-and-his-wife-ends-in-home-detention-for-false-allegations/JAYNHBJX3BFC7AA7TT7WUTC63Q](https://www.nzherald.co.nz/nz/spurned-lovers-revenge-on-cheating-husband-and-his-wife-ends-in-home-detention-for-false-allegations/JAYNHBJX3BFC7AA7TT7WUTC63Q)
 - RSS feed: $source
 - date published: 2024-12-21T16:00:00+00:00

He ended a 15-month affair - and then his lover told police he threatened to kill her.

## Auckland’s ‘Pink Porsche’ MDMA kingpin Shuchen Liu gets lengthy jail term, wife Xiuxiu Hao spared
 - [https://www.nzherald.co.nz/nz/crime/aucklands-pink-porsche-mdma-kingpin-shuchen-liu-gets-lengthy-jail-term-wife-xiuxiu-hao-spared/S4H3375ZIZD6DDGUL6SMOMYPSI](https://www.nzherald.co.nz/nz/crime/aucklands-pink-porsche-mdma-kingpin-shuchen-liu-gets-lengthy-jail-term-wife-xiuxiu-hao-spared/S4H3375ZIZD6DDGUL6SMOMYPSI)
 - RSS feed: $source
 - date published: 2024-12-21T06:00:00+00:00

The couple were respected Auckland entrepreneurs, but the drug trade fuelled their wealth.

## Huge outage: Lightning strike cuts power to thousands in the central North Island
 - [https://www.nzherald.co.nz/nz/huge-outage-lightning-strike-cuts-power-to-thousands-in-lower-north-island/6Y2OEC737NEZLEELSDDILDTFRY](https://www.nzherald.co.nz/nz/huge-outage-lightning-strike-cuts-power-to-thousands-in-lower-north-island/6Y2OEC737NEZLEELSDDILDTFRY)
 - RSS feed: $source
 - date published: 2024-12-21T02:50:00+00:00

The outages are possibly due to lightning strikes.

