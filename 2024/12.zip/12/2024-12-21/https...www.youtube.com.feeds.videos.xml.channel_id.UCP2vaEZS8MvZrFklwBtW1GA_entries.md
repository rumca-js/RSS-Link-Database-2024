# Source:Home Repair Tutor, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCP2vaEZS8MvZrFklwBtW1GA, language:en

## Schluter Drain Grate Kit Tips - #shorts #homerepairtutor
 - [https://www.youtube.com/watch?v=rXKFPft6LXM](https://www.youtube.com/watch?v=rXKFPft6LXM)
 - RSS feed: $source
 - date published: 2024-12-21T12:01:09+00:00

Schluter KERDI-DRAIN grate kit tips…I adjust the height and add mortar to the corners before installation. Mortar mechanically bonds the grate to the drain. I ensure the drain is equidistant from the walls so the tile work looks symmetrical. Remember, if you need help designing and tiling a shower, join our Video Library at homerepairtutor.com 🔥#tile #tileshower #schluter #brandpartner

