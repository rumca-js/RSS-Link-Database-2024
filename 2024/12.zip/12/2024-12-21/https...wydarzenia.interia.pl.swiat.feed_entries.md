# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Wielki mufti wzywa do walki z Rosjanami. "Chwycić za broń"
 - [https://wydarzenia.interia.pl/bliski-wschod/news-wielki-mufti-wzywa-do-walki-z-rosjanami-chwycic-za-bron,nId,7880369](https://wydarzenia.interia.pl/bliski-wschod/news-wielki-mufti-wzywa-do-walki-z-rosjanami-chwycic-za-bron,nId,7880369)
 - RSS feed: $source
 - date published: 2024-12-21T21:15:07.713811+00:00

<p><a href="https://wydarzenia.interia.pl/bliski-wschod/news-wielki-mufti-wzywa-do-walki-z-rosjanami-chwycic-za-bron,nId,7880369"><img src="https://i.iplsc.com/wielki-mufti-wzywa-do-walki-z-rosjanami-chwycic-za-bron/000KC84HGLK51QKN-C321.jpg" alt="Wielki mufti wzywa do walki z Rosjanami. &quot;Chwycić za broń&quot;" align="left" /></a>Wielki mufti Libii, szejk Sadik al-Ghariani, wezwał wszystkich obywateli do walki z Rosjanami, którzy pojawili się we wschodnich regionach kraju po obaleniu reżimu Baszara al-Asada w Syrii. Rosyjscy żołnierze zostali przyjęci do kraju bez zgody władz przez generała Chalifę Haftara, gdzie dołączyli do najemników z byłej Grupy Wagnera.</p><br clear="all" />

## Problemy zdrowotne papieża Franciszka. Watykan wydał komunikat
 - [https://wydarzenia.interia.pl/zagranica/news-problemy-zdrowotne-papieza-franciszka-watykan-wydal-komunika,nId,7880362](https://wydarzenia.interia.pl/zagranica/news-problemy-zdrowotne-papieza-franciszka-watykan-wydal-komunika,nId,7880362)
 - RSS feed: $source
 - date published: 2024-12-21T20:10:37.408721+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-problemy-zdrowotne-papieza-franciszka-watykan-wydal-komunika,nId,7880362"><img src="https://i.iplsc.com/problemy-zdrowotne-papieza-franciszka-watykan-wydal-komunika/000KC82Y9BT6GP82-C321.jpg" alt="Problemy zdrowotne papieża Franciszka. Watykan wydał komunikat" align="left" /></a>Papież przechodzi przeziębienie, przez co nie spotka się w niedzielę z wiernymi przybyłymi na plac Świętego Piotra na modlitwę Anioł Pański. Zamiast tego Franciszek odmówi ją w kaplicy Domu Świętej Marty - przekazał Watykan, przypominając, że papieża czeka w najbliższym czasie dużo obowiązków związanych z nadchodzącym Rokiem Świętym. </p><br clear="all" />

## Poważne problemy Słowacji po decyzji Ukrainy. Media: Fico pojedzie do Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-powazne-problemy-slowacji-po-decyzji-ukrainy-media-fico-poje,nId,7880340](https://wydarzenia.interia.pl/zagranica/news-powazne-problemy-slowacji-po-decyzji-ukrainy-media-fico-poje,nId,7880340)
 - RSS feed: $source
 - date published: 2024-12-21T18:01:59.205541+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-powazne-problemy-slowacji-po-decyzji-ukrainy-media-fico-poje,nId,7880340"><img src="https://i.iplsc.com/powazne-problemy-slowacji-po-decyzji-ukrainy-media-fico-poje/000KC7RJB72OAFA5-C321.jpg" alt="Poważne problemy Słowacji po decyzji Ukrainy. Media: Fico pojedzie do Rosji" align="left" /></a>Robert Fico uda się do Moskwy na spotkanie z Władimirem Putinem - podały serbskie media, powołując się na słowa tamtejszego prezydenta. Powodem wizyty mają być problemy Słowacji w pozyskaniu rosyjskiego gazu. To pokłosie decyzji Ukrainy, która definitywnie nie zgadza się na kontynuację tranzytu przez swoje terytorium. Słowackie media nie były jednak w stanie potwierdzić doniesień o podróży premiera w kancelarii szefa rządu. </p><br clear="all" />

## Tusk o kulisach rozmowy z Orbanem. "Powiedział mi to wprost"
 - [https://wydarzenia.interia.pl/zagranica/news-tusk-o-kulisach-rozmowy-z-orbanem-powiedzial-mi-to-wprost,nId,7880312](https://wydarzenia.interia.pl/zagranica/news-tusk-o-kulisach-rozmowy-z-orbanem-powiedzial-mi-to-wprost,nId,7880312)
 - RSS feed: $source
 - date published: 2024-12-21T14:46:46.987458+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tusk-o-kulisach-rozmowy-z-orbanem-powiedzial-mi-to-wprost,nId,7880312"><img src="https://i.iplsc.com/tusk-o-kulisach-rozmowy-z-orbanem-powiedzial-mi-to-wprost/000KC6PY8IY8BUEE-C321.jpg" alt="Tusk o kulisach rozmowy z Orbanem. &quot;Powiedział mi to wprost&quot; " align="left" /></a>&quot;Premier Orban nie lubi rozliczeń. Powiedział mi to wprost, tłumacząc decyzję o azylu&quot; - napisał premier Donald Tusk, odnosząc się do decyzji przyznania przez Węgry azylu politycznego dla posła Marcina Romanowskiego. Szef rządu rozmawiał w tej sprawie bezpośrednio z premierem Węgier.</p><br clear="all" />

## Scholz miał "warknąć" i krzyczeć na Dudę. "Nie rozumiecie"
 - [https://wydarzenia.interia.pl/zagranica/news-scholz-mial-warknac-i-krzyczec-na-dude-nie-rozumiecie,nId,7880279](https://wydarzenia.interia.pl/zagranica/news-scholz-mial-warknac-i-krzyczec-na-dude-nie-rozumiecie,nId,7880279)
 - RSS feed: $source
 - date published: 2024-12-21T12:36:38.901854+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-scholz-mial-warknac-i-krzyczec-na-dude-nie-rozumiecie,nId,7880279"><img src="https://i.iplsc.com/scholz-mial-warknac-i-krzyczec-na-dude-nie-rozumiecie/000KC6EDQSSLME12-C321.jpg" alt="Scholz miał &quot;warknąć&quot; i krzyczeć na Dudę. &quot;Nie rozumiecie&quot;" align="left" /></a>- Nie rozumiecie, jaki to będzie miało wpływ na stabilność naszych rynków finansowych - tak według &quot;Financial Times&quot; miał krzyczeć Olaf Scholz do Andrzeja Dudy podczas spotkania w Brukseli. Kanclerz Niemiec miał emocjonalnie zareagować na pomysł polskiego prezydenta, dotyczący wydania Kijowowi zamrożonych w Europie rosyjskich aktywów państwowych. - Nawet nie używacie euro - burzył się kanclerz.</p><br clear="all" />

## Wzrasta liczba ofiar w Magdeburgu. Na miejsce przyjechał Olaf Scholz
 - [https://wydarzenia.interia.pl/zagranica/news-wzrasta-liczba-ofiar-w-magdeburgu-na-miejsce-przyjechal-olaf,nId,7880241](https://wydarzenia.interia.pl/zagranica/news-wzrasta-liczba-ofiar-w-magdeburgu-na-miejsce-przyjechal-olaf,nId,7880241)
 - RSS feed: $source
 - date published: 2024-12-21T10:38:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wzrasta-liczba-ofiar-w-magdeburgu-na-miejsce-przyjechal-olaf,nId,7880241"><img src="https://i.iplsc.com/wzrasta-liczba-ofiar-w-magdeburgu-na-miejsce-przyjechal-olaf/000KC61IFLR0QPDN-C321.jpg" alt="Wzrasta liczba ofiar w Magdeburgu. Na miejsce przyjechał Olaf Scholz" align="left" /></a>Kanclerz Niemiec Olaf Scholz i minister spraw wewnętrznych Niemiec Nancy Feaser przyjechali do Magdeburga. W piątek doszło tam do zamachu na osoby przebywające na jarmarku świątecznym. W wyniku działań napastnika zginęło pięć osób, a ponad 200 zostało rannych.</p><br clear="all" />

