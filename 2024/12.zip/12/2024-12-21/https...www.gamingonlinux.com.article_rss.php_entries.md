# Source:GamingOnLinux Latest Articles, URL:https://www.gamingonlinux.com/article_rss.php, language:en-us

## Merry Christmas and Happy New Year from GamingOnLinux
 - [https://www.gamingonlinux.com/2024/12/merry-christmas-and-happy-new-year-from-gamingonlinux-24](https://www.gamingonlinux.com/2024/12/merry-christmas-and-happy-new-year-from-gamingonlinux-24)
 - RSS feed: $source
 - date published: 2024-12-21T23:28:23+00:00

Hello there! It's coming up on Christmas now, and so GamingOnLinux will be starting to go into it's usual mostly hibernating state to take a little break.<p><img src="https://www.gamingonlinux.com/uploads/articles/tagline_images/1962920059id25895gol.jpg" alt />.</p><p>Read the full article on <a href="https://www.gamingonlinux.com/2024/12/merry-christmas-and-happy-new-year-from-gamingonlinux-24/">GamingOnLinux</a>.</p>

## For fans of Advance Wars there's a new demo up for Warside and new release window
 - [https://www.gamingonlinux.com/2024/12/for-fans-of-advance-wars-theres-a-new-demo-up-for-warside-and-new-release-window](https://www.gamingonlinux.com/2024/12/for-fans-of-advance-wars-theres-a-new-demo-up-for-warside-and-new-release-window)
 - RSS feed: $source
 - date published: 2024-12-21T19:02:38+00:00

Something for the weekend: you can now try out a brand new demo of Warside, a game very much inspired by the classic Advance Wars and it does look good.<p><img src="https://www.gamingonlinux.com/uploads/articles/tagline_images/42118499id25894gol.jpg" alt />.</p><p>Read the full article on <a href="https://www.gamingonlinux.com/2024/12/for-fans-of-advance-wars-theres-a-new-demo-up-for-warside-and-new-release-window/">GamingOnLinux</a>.</p>

## Windows compatibility layer Wine 10.0 third Release Candidate out now
 - [https://www.gamingonlinux.com/2024/12/windows-compatibility-layer-wine-100-third-release-candidate-out-now](https://www.gamingonlinux.com/2024/12/windows-compatibility-layer-wine-100-third-release-candidate-out-now)
 - RSS feed: $source
 - date published: 2024-12-21T12:18:34+00:00

With the feature code freeze continuing, the Wine team had put up a third Release Candidate for the upcoming stable main release of Wine 10.0 coming in early 2025.<p><img src="https://www.gamingonlinux.com/uploads/tagline_gallery/wine-generic.jpg" alt />.</p><p>Read the full article on <a href="https://www.gamingonlinux.com/2024/12/windows-compatibility-layer-wine-100-third-release-candidate-out-now/">GamingOnLinux</a>.</p>

## Firaxis reveal Sid Meier's Civilization VII system requirements for Linux
 - [https://www.gamingonlinux.com/2024/12/firaxis-reveal-sid-meiers-civilization-vii-system-requirements-for-linux](https://www.gamingonlinux.com/2024/12/firaxis-reveal-sid-meiers-civilization-vii-system-requirements-for-linux)
 - RSS feed: $source
 - date published: 2024-12-21T11:20:10+00:00

Firaxis Games and 2K are releasing Sid Meier's Civilization VII on February 11, 2025 and now we know what power you're going to need to run it on Linux Desktop systems.<p><img src="https://www.gamingonlinux.com/uploads/articles/tagline_images/1269205194id25892gol.jpg" alt />.</p><p>Read the full article on <a href="https://www.gamingonlinux.com/2024/12/firaxis-reveal-sid-meiers-civilization-vii-system-requirements-for-linux/">GamingOnLinux</a>.</p>

## Mesa 24.3.2 released with more graphics driver bug fixes for Linux
 - [https://www.gamingonlinux.com/2024/12/mesa-24-3-2-released-with-more-graphics-driver-bug-fixes-for-linux](https://www.gamingonlinux.com/2024/12/mesa-24-3-2-released-with-more-graphics-driver-bug-fixes-for-linux)
 - RSS feed: $source
 - date published: 2024-12-21T11:08:49+00:00

The last open source graphics driver update before the holidays is here, with Mesa 24.3.2 now available for you to upgrade.<p><img src="https://www.gamingonlinux.com/uploads/tagline_gallery/mesa.png" alt />.</p><p>Read the full article on <a href="https://www.gamingonlinux.com/2024/12/mesa-24-3-2-released-with-more-graphics-driver-bug-fixes-for-linux/">GamingOnLinux</a>.</p>

