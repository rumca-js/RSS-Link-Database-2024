# Source:Academy of Ideas, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCiRiQGCHGjDLT9FQXFW0I3A, language:en-US

## Fyodor Dostoevsky – How Prison Sculpted a Genius
 - [https://www.youtube.com/watch?v=W49TbBZUaEQ](https://www.youtube.com/watch?v=W49TbBZUaEQ)
 - RSS feed: $source
 - date published: 2024-12-21T16:56:53+00:00

Become a Supporting Member! ► http://academyofideas.com/members/

Access the transcript and art used in this video - https://academyofideas.com/2024/12/fyodor-dostoevsky-how-prison-sculpted-a-genius/

Substack - https://theacademyofideas.substack.com/
Twitter - https://twitter.com/academyofideas
Instagram - https://www.instagram.com/academyofideas/
Spotify - https://open.spotify.com/show/2dio7KUNuDHErlMumZtNt6
iTunes - https://podcasts.apple.com/ca/podcast/academy-of-ideas/id1364706343
Rumble - https://rumble.com/c/academyofideas
Odysee - https://odysee.com/@academyofideas:3

Prefer to Support us with a One-Time Donation?
Paypal  ► https://www.paypal.me/academyofideas
Bitcoin: 1P6ntukFENP1nvEf4bJNj3tsDEuiSyUFW6

Visit academyofideas.com for all our content.

