# Source:The Wall Street Journal, URL:https://feeds.a.dj.com/rss/RSSWorldNews.xml, language:en-US

## Rickey Henderson, Baseball's All-Time Stolen Base Leader, Dies at Age 65
 - [https://www.wsj.com/articles/rickey-henderson-stolen-base-leader-dies-at-age-65-734d7e8a](https://www.wsj.com/articles/rickey-henderson-stolen-base-leader-dies-at-age-65-734d7e8a)
 - RSS feed: $source
 - date published: 2024-12-21T18:19:00+00:00

The Hall-of-Fame outfielder stole 1,406 bases in his 25-year major league career and was one of the most colorful characters ever to play the game.

## Suspect in Christmas Market Ramming Had One Main Enemy: Islam
 - [https://www.wsj.com/articles/suspect-in-christmas-market-ramming-had-one-main-enemy-islam-6363d708](https://www.wsj.com/articles/suspect-in-christmas-market-ramming-had-one-main-enemy-islam-6363d708)
 - RSS feed: $source
 - date published: 2024-12-21T05:18:00+00:00

The 50-year-old psychiatrist is a well-known anti-Islam activist who seems to have felt increasingly persecuted by Germany.

