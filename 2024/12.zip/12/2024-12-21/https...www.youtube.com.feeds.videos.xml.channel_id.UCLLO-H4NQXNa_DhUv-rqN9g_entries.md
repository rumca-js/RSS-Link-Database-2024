# Source:CD-Action - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g, language:pl

## ZMUSZAMY SIĘ do grania w gry dzieciństwa
 - [https://www.youtube.com/watch?v=LGEk1dwilRI](https://www.youtube.com/watch?v=LGEk1dwilRI)
 - RSS feed: $source
 - date published: 2024-12-21T20:07:58+00:00

Naszą książkę znajdziesz na sklep.cdaction.pl

Są święta, więc znów cofnęliśmy się do czasów, gdy byliśmy młodsi (tylko młodsi) i zagraliśmy sobie w nasze gry dzieciństwa: Dragon Ball: Final Bout oraz yyy, czekajcie, jak to się nazywa? A, Shin Chan: Arashi o Yobu Cinema-Land no Daibouken.

Prowadzenie i scenariusz: Krzysztof „Bastian” Freudenberger (http://twitter.com/BastianCDA)
Dawid „spikain" Bojarski (http://twitter.com/spikain)

Montaż: Mateusz Pietrasiak

