# Source:Reddit - Front Page, URL:https://www.reddit.com/.rss, language:en-US

## Post-Match Thread: FC Barcelona 1-2 Atlético Madrid | LA LIGA
 - [https://www.reddit.com/r/Barca/comments/1hjk7m3/postmatch_thread_fc_barcelona_12_atlético_madrid](https://www.reddit.com/r/Barca/comments/1hjk7m3/postmatch_thread_fc_barcelona_12_atlético_madrid)
 - RSS feed: $source
 - date published: 2024-12-21T21:57:34+00:00

<!-- SC_OFF --><div class="md"><h1><strong>FT: Barcelona 1-2 Atlético Madrid</strong></h1> <hr/> <p><strong>Venue:</strong> Estadi Olímpic Lluís Companys</p> <p><a href="http://www.reddit-stream.com/comments/1hjhsli">Auto-refreshing reddit comments link</a></p> <hr/> <p><a href="#icon-notes-big"></a> <strong>LINE-UPS</strong></p> <p><strong>Barcelona</strong></p> <p>Iñaki Peña, Iñigo Martínez, Pau Cubarsí, Alejandro Balde, Jules Koundé, Fermín López, Pedri , Marc Casadó, Robert Lewandowski, Gavi , Raphinha .</p> <p><strong>Subs:</strong> Dani Olmo, Ferran Torres, Ander Astralaga, Eric García, Wojciech Szczesny, Sergi Domínguez, Gerard Martín, Frenkie de Jong, Pablo Torre, Pau Víctor, Ronald Araújo, Ansu Fati.</p> <p><sup>____________________________</sup></p> <p><strong>Atlético Madrid</strong></p> <p>Jan Oblak, Clément Lenglet, José María Giménez, Javi Galán, Marcos Llorente, Pablo Barrios, Rodrigo De Paul, Conor Gallagher, Giuliano Simeone, Julián Álvarez, Antoine Griezmann.</p> <p

## Match Thread: Barcelona vs Atlético Madrid | LA LIGA
 - [https://www.reddit.com/r/Barca/comments/1hjhuwn/match_thread_barcelona_vs_atlético_madrid_la_liga](https://www.reddit.com/r/Barca/comments/1hjhuwn/match_thread_barcelona_vs_atlético_madrid_la_liga)
 - RSS feed: $source
 - date published: 2024-12-21T20:01:25+00:00

<!-- SC_OFF --><div class="md"><h1><strong>65&#39;: Barcelona <a href="#bar-3-white">1-1</a> Atlético Madrid</strong></h1> <hr/> <p><strong>Venue:</strong> Estadi Olímpic Lluís Companys</p> <p><a href="http://www.reddit-stream.com/comments/1hjhsli">Auto-refreshing reddit comments link</a></p> <hr/> <p><a href="#icon-notes-big"></a> <strong>LINE-UPS</strong></p> <p><strong>Barcelona</strong></p> <p>Iñaki Peña, Iñigo Martínez, Pau Cubarsí, Alejandro Balde, Jules Koundé, Fermín López, Pedri , Marc Casadó, Robert Lewandowski, Gavi , Raphinha .</p> <p><strong>Subs:</strong> Dani Olmo, Ferran Torres, Ander Astralaga, Eric García, Wojciech Szczesny, Sergi Domínguez, Gerard Martín, Frenkie de Jong, Pablo Torre, Pau Víctor, Ronald Araújo, Ansu Fati.</p> <p><sup>____________________________</sup></p> <p><strong>Atlético Madrid</strong></p> <p>Jan Oblak, Clément Lenglet, José María Giménez, Javi Galán, Marcos Llorente, Pablo Barrios, Rodrigo De Paul, Conor Gallagher, Giuliano Simeone, Julián Ál

## Czy myślicie że to codzienność w tczewie?
 - [https://www.reddit.com/r/okkolegauposledzony/comments/1hjh8k9/czy_myślicie_że_to_codzienność_w_tczewie](https://www.reddit.com/r/okkolegauposledzony/comments/1hjh8k9/czy_myślicie_że_to_codzienność_w_tczewie)
 - RSS feed: $source
 - date published: 2024-12-21T19:31:28+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/okkolegauposledzony/comments/1hjh8k9/czy_myślicie_że_to_codzienność_w_tczewie/"> <img src="https://preview.redd.it/u3fqfo68798e1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=b3c87d4c1b6825e6b781e88b13f9695ad8ddcce7" alt="Czy myślicie że to codzienność w tczewie?" title="Czy myślicie że to codzienność w tczewie?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/HSVMalooGTS"> /u/HSVMalooGTS </a> &#32; to &#32; <a href="https://www.reddit.com/r/okkolegauposledzony/"> r/okkolegauposledzony </a> <br/> <span><a href="https://i.redd.it/u3fqfo68798e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/okkolegauposledzony/comments/1hjh8k9/czy_myślicie_że_to_codzienność_w_tczewie/">[comments]</a></span> </td></tr></table>

## V4 together against everyone ❤️‍🩹
 - [https://www.reddit.com/r/2visegrad4you/comments/1hjgg7c/v4_together_against_everyone](https://www.reddit.com/r/2visegrad4you/comments/1hjgg7c/v4_together_against_everyone)
 - RSS feed: $source
 - date published: 2024-12-21T18:54:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/2visegrad4you/comments/1hjgg7c/v4_together_against_everyone/"> <img src="https://preview.redd.it/r6x8ht7n098e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4c6c31b914ea691e55bc5291246c9d7cd64710d6" alt="V4 together against everyone ❤️‍🩹" title="V4 together against everyone ❤️‍🩹" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I would credit the guy who posted it here first, but he, well, disappeared.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/ten_z_prahy"> /u/ten_z_prahy </a> &#32; to &#32; <a href="https://www.reddit.com/r/2visegrad4you/"> r/2visegrad4you </a> <br/> <span><a href="https://i.redd.it/r6x8ht7n098e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/2visegrad4you/comments/1hjgg7c/v4_together_against_everyone/">[comments]</a></span> </td></tr></table>

## Nudzi mi się. Pogada ktoś?
 - [https://www.reddit.com/r/Polska/comments/1hjfzwi/nudzi_mi_się_pogada_ktoś](https://www.reddit.com/r/Polska/comments/1hjfzwi/nudzi_mi_się_pogada_ktoś)
 - RSS feed: $source
 - date published: 2024-12-21T18:33:03+00:00

<!-- SC_OFF --><div class="md"><p>Mam 36 lat (baba). Lubię grać w gry na Switch (ale raczej takie spokojne, Animal Crossing, Stardew Valley, My Time at Portia/Sandrock), interesuje się Koreą Północną. Mam ADHD I agorafobie, prawie nie wychodzę z domu. Chce ktoś pogadać o pierdolach typu &quot;co kupiłem rodzicom pod choinkę&quot;? W prywatnej wiadomości mogę podać numer telefonu, nie lubię za dużo stukac w ekran telefonu</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/agatkaPoland"> /u/agatkaPoland </a> &#32; to &#32; <a href="https://www.reddit.com/r/Polska/"> r/Polska </a> <br/> <span><a href="https://www.reddit.com/r/Polska/comments/1hjfzwi/nudzi_mi_się_pogada_ktoś/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Polska/comments/1hjfzwi/nudzi_mi_się_pogada_ktoś/">[comments]</a></span>

## Who has seen these kids?
 - [https://www.reddit.com/r/2visegrad4you/comments/1hjfje6/who_has_seen_these_kids](https://www.reddit.com/r/2visegrad4you/comments/1hjfje6/who_has_seen_these_kids)
 - RSS feed: $source
 - date published: 2024-12-21T18:11:47+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/2visegrad4you/comments/1hjfje6/who_has_seen_these_kids/"> <img src="https://preview.redd.it/j2y83cl2t88e1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=7aa9df3de1bd0e91ff0f6c757425cbb5dcd21dc6" alt="Who has seen these kids?" title="Who has seen these kids?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GoodUnlucky1430"> /u/GoodUnlucky1430 </a> &#32; to &#32; <a href="https://www.reddit.com/r/2visegrad4you/"> r/2visegrad4you </a> <br/> <span><a href="https://i.redd.it/j2y83cl2t88e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/2visegrad4you/comments/1hjfje6/who_has_seen_these_kids/">[comments]</a></span> </td></tr></table>

## Real and gay 😬
 - [https://www.reddit.com/r/shitposting/comments/1hjfcfo/real_and_gay](https://www.reddit.com/r/shitposting/comments/1hjfcfo/real_and_gay)
 - RSS feed: $source
 - date published: 2024-12-21T18:02:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/shitposting/comments/1hjfcfo/real_and_gay/"> <img src="https://preview.redd.it/jomqw1vgr88e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=13ae671cad1c6e952c904fc55ef150d915d93c52" alt="Real and gay 😬" title="Real and gay 😬" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/itzTanmayhere"> /u/itzTanmayhere </a> &#32; to &#32; <a href="https://www.reddit.com/r/shitposting/"> r/shitposting </a> <br/> <span><a href="https://i.redd.it/jomqw1vgr88e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/shitposting/comments/1hjfcfo/real_and_gay/">[comments]</a></span> </td></tr></table>

## What was your reaction to this scene.
 - [https://www.reddit.com/r/HelluvaBoss/comments/1hjes2k/what_was_your_reaction_to_this_scene](https://www.reddit.com/r/HelluvaBoss/comments/1hjes2k/what_was_your_reaction_to_this_scene)
 - RSS feed: $source
 - date published: 2024-12-21T17:37:09+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Solid_Inspector649"> /u/Solid_Inspector649 </a> &#32; to &#32; <a href="https://www.reddit.com/r/HelluvaBoss/"> r/HelluvaBoss </a> <br/> <span><a href="https://i.redd.it/4ef5m65wm88e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HelluvaBoss/comments/1hjes2k/what_was_your_reaction_to_this_scene/">[comments]</a></span>

## Czat czy to prawda?
 - [https://www.reddit.com/r/okkolegauposledzony/comments/1hje5mb/czat_czy_to_prawda](https://www.reddit.com/r/okkolegauposledzony/comments/1hje5mb/czat_czy_to_prawda)
 - RSS feed: $source
 - date published: 2024-12-21T17:08:13+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/okkolegauposledzony/comments/1hje5mb/czat_czy_to_prawda/"> <img src="https://preview.redd.it/oycnprkmh88e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=83dd3b879aa61c545cddf75298901f04ebd5d3c6" alt="Czat czy to prawda?" title="Czat czy to prawda?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/golonix87"> /u/golonix87 </a> &#32; to &#32; <a href="https://www.reddit.com/r/okkolegauposledzony/"> r/okkolegauposledzony </a> <br/> <span><a href="https://i.redd.it/oycnprkmh88e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/okkolegauposledzony/comments/1hje5mb/czat_czy_to_prawda/">[comments]</a></span> </td></tr></table>

## They are just chill guys
 - [https://www.reddit.com/r/whenthe/comments/1hjdk9s/they_are_just_chill_guys](https://www.reddit.com/r/whenthe/comments/1hjdk9s/they_are_just_chill_guys)
 - RSS feed: $source
 - date published: 2024-12-21T16:40:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1hjdk9s/they_are_just_chill_guys/"> <img src="https://preview.redd.it/ux9doxnoc88e1.gif?width=320&amp;crop=smart&amp;s=f49d957df631958e85918991f4f36c4e15c86636" alt="They are just chill guys" title="They are just chill guys" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Zyvred"> /u/Zyvred </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br/> <span><a href="https://i.redd.it/ux9doxnoc88e1.gif">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1hjdk9s/they_are_just_chill_guys/">[comments]</a></span> </td></tr></table>

## Mugshot of CEO of United Healthcare Brian Thompson for his DUI arrest in 2017
 - [https://www.reddit.com/r/pics/comments/1hjcl93/mugshot_of_ceo_of_united_healthcare_brian](https://www.reddit.com/r/pics/comments/1hjcl93/mugshot_of_ceo_of_united_healthcare_brian)
 - RSS feed: $source
 - date published: 2024-12-21T15:54:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/pics/comments/1hjcl93/mugshot_of_ceo_of_united_healthcare_brian/"> <img src="https://preview.redd.it/hddbbjnh488e1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=72a09918a3bb906225e929dd5aa29601a39b5811" alt="Mugshot of CEO of United Healthcare Brian Thompson for his DUI arrest in 2017" title="Mugshot of CEO of United Healthcare Brian Thompson for his DUI arrest in 2017" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/thedude213"> /u/thedude213 </a> &#32; to &#32; <a href="https://www.reddit.com/r/pics/"> r/pics </a> <br/> <span><a href="https://i.redd.it/hddbbjnh488e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pics/comments/1hjcl93/mugshot_of_ceo_of_united_healthcare_brian/">[comments]</a></span> </td></tr></table>

## Thank you Let Me Solo Him
 - [https://www.reddit.com/r/Eldenring/comments/1hjbyap/thank_you_let_me_solo_him](https://www.reddit.com/r/Eldenring/comments/1hjbyap/thank_you_let_me_solo_him)
 - RSS feed: $source
 - date published: 2024-12-21T15:22:40+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Eldenring/comments/1hjbyap/thank_you_let_me_solo_him/"> <img src="https://preview.redd.it/bqexeibwy78e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=08b82168d6fc9f2dcef1135b2666cc3c070cbe95" alt="Thank you Let Me Solo Him" title="Thank you Let Me Solo Him" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>I don&#39;t know who you are or where you&#39;re from, but this is your Zabito Boga, if you ever see this.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Iluvtatas-69"> /u/Iluvtatas-69 </a> &#32; to &#32; <a href="https://www.reddit.com/r/Eldenring/"> r/Eldenring </a> <br/> <span><a href="https://i.redd.it/bqexeibwy78e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/Eldenring/comments/1hjbyap/thank_you_let_me_solo_him/">[comments]</a></span> </td></tr></table>

## sibling just sold off my 5 year old ps4 and my ps4 games without my knowledge
 - [https://www.reddit.com/r/mildlyinfuriating/comments/1hjbx0c/sibling_just_sold_off_my_5_year_old_ps4_and_my](https://www.reddit.com/r/mildlyinfuriating/comments/1hjbx0c/sibling_just_sold_off_my_5_year_old_ps4_and_my)
 - RSS feed: $source
 - date published: 2024-12-21T15:20:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/mildlyinfuriating/comments/1hjbx0c/sibling_just_sold_off_my_5_year_old_ps4_and_my/"> <img src="https://b.thumbs.redditmedia.com/onBjktAAKP3Em-dNTKz2L4DLqnWOilrHWRnFI8QE5_s.jpg" alt="sibling just sold off my 5 year old ps4 and my ps4 games without my knowledge" title="sibling just sold off my 5 year old ps4 and my ps4 games without my knowledge" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>The audacity to leave me on delivered + give me like only 40% of the money too.</p> <p>My brother (19M) decided that itd be cool to sell off both ps4 and my games for some cash he could use to party off on christmas eve. The ps4 was a hand-me-down gift from my closest cousin.</p> <p>I havent been able to get on my ps4 because im living on a dorm for college ( 18F and on my first year studying computer science ) and cant exactly bring it over. I still had plans to finish persona 5 and some of my games but i guess i wont be able to lol. i just 

## Kolegowie, jadł ktoś?
 - [https://www.reddit.com/r/okkolegauposledzony/comments/1hjbr22/kolegowie_jadł_ktoś](https://www.reddit.com/r/okkolegauposledzony/comments/1hjbr22/kolegowie_jadł_ktoś)
 - RSS feed: $source
 - date published: 2024-12-21T15:12:21+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/okkolegauposledzony/comments/1hjbr22/kolegowie_jadł_ktoś/"> <img src="https://preview.redd.it/7442ej32x78e1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=01e8e86092b73ae1bf5a0c6b3df25785e4adb893" alt="Kolegowie, jadł ktoś?" title="Kolegowie, jadł ktoś?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ancaloth_03"> /u/Ancaloth_03 </a> &#32; to &#32; <a href="https://www.reddit.com/r/okkolegauposledzony/"> r/okkolegauposledzony </a> <br/> <span><a href="https://i.redd.it/7442ej32x78e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/okkolegauposledzony/comments/1hjbr22/kolegowie_jadł_ktoś/">[comments]</a></span> </td></tr></table>

## Interesting
 - [https://www.reddit.com/r/2visegrad4you/comments/1hjbdgh/interesting](https://www.reddit.com/r/2visegrad4you/comments/1hjbdgh/interesting)
 - RSS feed: $source
 - date published: 2024-12-21T14:53:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/2visegrad4you/comments/1hjbdgh/interesting/"> <img src="https://preview.redd.it/axieab8mt78e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=e95f236cdea869582bd17e2a8968b6fcb4354230" alt="Interesting " title="Interesting " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Nyayman"> /u/Nyayman </a> &#32; to &#32; <a href="https://www.reddit.com/r/2visegrad4you/"> r/2visegrad4you </a> <br/> <span><a href="https://i.redd.it/axieab8mt78e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/2visegrad4you/comments/1hjbdgh/interesting/">[comments]</a></span> </td></tr></table>

## A girl reported to the German police in September 2023 about the danger of a man called Talib Abd AlMohsen, who was planning to run people over with his car. The German police ignored the report
 - [https://www.reddit.com/r/europe/comments/1hja3n3/a_girl_reported_to_the_german_police_in_september](https://www.reddit.com/r/europe/comments/1hja3n3/a_girl_reported_to_the_german_police_in_september)
 - RSS feed: $source
 - date published: 2024-12-21T13:43:57+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1hja3n3/a_girl_reported_to_the_german_police_in_september/"> <img src="https://b.thumbs.redditmedia.com/L5Z2yXtq2tUua_lnUB8EiIBq88o74W7CCCW80f-wCVI.jpg" alt="A girl reported to the German police in September 2023 about the danger of a man called Talib Abd AlMohsen, who was planning to run people over with his car. The German police ignored the report" title="A girl reported to the German police in September 2023 about the danger of a man called Talib Abd AlMohsen, who was planning to run people over with his car. The German police ignored the report" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ok_Somewhere9687"> /u/Ok_Somewhere9687 </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br/> <span><a href="https://www.reddit.com/gallery/1hja3n3">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1hja3n3/a_girl_reported_to_the_germa

## Look I like the guy but I definitely think he's had a negative impact on internet vexillology
 - [https://www.reddit.com/r/whenthe/comments/1hj9yl9/look_i_like_the_guy_but_i_definitely_think_hes](https://www.reddit.com/r/whenthe/comments/1hj9yl9/look_i_like_the_guy_but_i_definitely_think_hes)
 - RSS feed: $source
 - date published: 2024-12-21T13:35:45+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1hj9yl9/look_i_like_the_guy_but_i_definitely_think_hes/"> <img src="https://preview.redd.it/bs1vulitf78e1.gif?width=320&amp;crop=smart&amp;s=852eab8e6f34ceb2afafbe94961314b82b0b971f" alt="Look I like the guy but I definitely think he's had a negative impact on internet vexillology" title="Look I like the guy but I definitely think he's had a negative impact on internet vexillology" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CluckBucketz"> /u/CluckBucketz </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br/> <span><a href="https://i.redd.it/bs1vulitf78e1.gif">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1hj9yl9/look_i_like_the_guy_but_i_definitely_think_hes/">[comments]</a></span> </td></tr></table>

## It's fucking dumb
 - [https://www.reddit.com/r/CuratedTumblr/comments/1hj9dta/its_fucking_dumb](https://www.reddit.com/r/CuratedTumblr/comments/1hj9dta/its_fucking_dumb)
 - RSS feed: $source
 - date published: 2024-12-21T13:00:58+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/CuratedTumblr/comments/1hj9dta/its_fucking_dumb/"> <img src="https://preview.redd.it/klnsj5am978e1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=a1617082401f96431ef04bcb72bfbc1484a6c3d2" alt="It's fucking dumb" title="It's fucking dumb" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Justthisdudeyaknow"> /u/Justthisdudeyaknow </a> &#32; to &#32; <a href="https://www.reddit.com/r/CuratedTumblr/"> r/CuratedTumblr </a> <br/> <span><a href="https://i.redd.it/klnsj5am978e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/CuratedTumblr/comments/1hj9dta/its_fucking_dumb/">[comments]</a></span> </td></tr></table>

## PL Rival Watch Thread MD17 (December 21st, 2024)
 - [https://www.reddit.com/r/LiverpoolFC/comments/1hj8otn/pl_rival_watch_thread_md17_december_21st_2024](https://www.reddit.com/r/LiverpoolFC/comments/1hj8otn/pl_rival_watch_thread_md17_december_21st_2024)
 - RSS feed: $source
 - date published: 2024-12-21T12:15:15+00:00

<!-- SC_OFF --><div class="md"><p>Ladies and gents, is this the moment Pep&#39;s waited for?<br/> A trip to Villa Park, his sweat soakin&#39; through the floor<br/> And burying his hopes, there&#39;s a league that he can&#39;t ignore<br/> Takin&#39; his points, beating Unai, and all City steals is left behind...</p> <p><strong><em>12:30 PM</em></strong><br/> Aston Villa vs Manchester City</p> <p><strong><em>3:00 PM</em></strong><br/> Brentford vs Nottingham Forest<br/> Ipswich Town vs Newcastle United<br/> West Ham United vs Brighton &amp; Hove Albion</p> <p><strong><em>5:30 PM</em></strong><br/> Crystal Palace vs Arsenal</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DragonSlayer271"> /u/DragonSlayer271 </a> &#32; to &#32; <a href="https://www.reddit.com/r/LiverpoolFC/"> r/LiverpoolFC </a> <br/> <span><a href="https://www.reddit.com/r/LiverpoolFC/comments/1hj8otn/pl_rival_watch_thread_md17_december_21st_2024/">[link]</a></span> &#32; <span><a 

## about genshin's current situation in cn
 - [https://www.reddit.com/r/NeuvilletteMains_/comments/1hj86x8/about_genshins_current_situation_in_cn](https://www.reddit.com/r/NeuvilletteMains_/comments/1hj86x8/about_genshins_current_situation_in_cn)
 - RSS feed: $source
 - date published: 2024-12-21T11:40:54+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/NeuvilletteMains_/comments/1hj86x8/about_genshins_current_situation_in_cn/"> <img src="https://preview.redd.it/tqmvfevbv68e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1616938faee98f4af94dd42f0ff6ab6dbb22c89c" alt="about genshin's current situation in cn" title="about genshin's current situation in cn" /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>hi I&#39;m a player from cn, saw some discussion about recent drama on this sub, so I want to share genshin&#39;s current situation in CN with you. I started this game since 1.0 era and have been active for over 1000+ days. l stopped pay to this game 4 months ago.there&#39;s lots of my kind who totally quit this game or just stopped paying these days in cn. genshin&#39;s revenue dropped largely(around -60%) in CN since 4.8,and Natlan is a huge flop since the opening.Why? reasons are below. 1.cn genshin communities have become increasingly toxic, male chars and female players co

## Petah?
 - [https://www.reddit.com/r/PeterExplainsTheJoke/comments/1hj7smp/petah](https://www.reddit.com/r/PeterExplainsTheJoke/comments/1hj7smp/petah)
 - RSS feed: $source
 - date published: 2024-12-21T11:11:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/PeterExplainsTheJoke/comments/1hj7smp/petah/"> <img src="https://preview.redd.it/opi3dst4q68e1.jpeg?width=320&amp;crop=smart&amp;auto=webp&amp;s=736e35c661de4b12517b01ebc356a0b2a4c21d97" alt="Petah?" title="Petah?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Famous_Result_2533"> /u/Famous_Result_2533 </a> &#32; to &#32; <a href="https://www.reddit.com/r/PeterExplainsTheJoke/"> r/PeterExplainsTheJoke </a> <br/> <span><a href="https://i.redd.it/opi3dst4q68e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/PeterExplainsTheJoke/comments/1hj7smp/petah/">[comments]</a></span> </td></tr></table>

## Saudi Islam critic, fan of AfD and Elon Musk: Disturbing details about the perpetrator of Magdeburg The driver who caused the death of the Magdeburg victim - Taleb Jawad Al Abdulmohsen, came to Germany in 2006. But he is not an Islamist - on the contrary. He accused Germany of Islamizing Europe.
 - [https://www.reddit.com/r/europe/comments/1hj6tp2/saudi_islam_critic_fan_of_afd_and_elon_musk](https://www.reddit.com/r/europe/comments/1hj6tp2/saudi_islam_critic_fan_of_afd_and_elon_musk)
 - RSS feed: $source
 - date published: 2024-12-21T09:59:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1hj6tp2/saudi_islam_critic_fan_of_afd_and_elon_musk/"> <img src="https://external-preview.redd.it/zWaqlPFLD8B3akEydo4FXJqPcGSlf47GqmePe0P--_E.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=dfc77db5cd457896acac241c5416b0c5999783ec" alt="Saudi Islam critic, fan of AfD and Elon Musk: Disturbing details about the perpetrator of Magdeburg The driver who caused the death of the Magdeburg victim - Taleb Jawad Al Abdulmohsen, came to Germany in 2006. But he is not an Islamist - on the contrary. He accused Germany of Islamizing Europe." title="Saudi Islam critic, fan of AfD and Elon Musk: Disturbing details about the perpetrator of Magdeburg The driver who caused the death of the Magdeburg victim - Taleb Jawad Al Abdulmohsen, came to Germany in 2006. But he is not an Islamist - on the contrary. He accused Germany of Islamizing Europe." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/polymute">

## Telefony be nie fajne
 - [https://www.reddit.com/r/okkolegauposledzony/comments/1hj65a0/telefony_be_nie_fajne](https://www.reddit.com/r/okkolegauposledzony/comments/1hj65a0/telefony_be_nie_fajne)
 - RSS feed: $source
 - date published: 2024-12-21T09:06:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/okkolegauposledzony/comments/1hj65a0/telefony_be_nie_fajne/"> <img src="https://preview.redd.it/nl2qmq5r368e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=70980eebfbcdc32404aebf91b48f63a98c16f402" alt="Telefony be nie fajne " title="Telefony be nie fajne " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AppleCat67"> /u/AppleCat67 </a> &#32; to &#32; <a href="https://www.reddit.com/r/okkolegauposledzony/"> r/okkolegauposledzony </a> <br/> <span><a href="https://i.redd.it/nl2qmq5r368e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/okkolegauposledzony/comments/1hj65a0/telefony_be_nie_fajne/">[comments]</a></span> </td></tr></table>

## Why does everyone seem to think that Viktor and Jayce are gay?
 - [https://www.reddit.com/r/arcane/comments/1hj5wyz/why_does_everyone_seem_to_think_that_viktor_and](https://www.reddit.com/r/arcane/comments/1hj5wyz/why_does_everyone_seem_to_think_that_viktor_and)
 - RSS feed: $source
 - date published: 2024-12-21T08:49:06+00:00

<!-- SC_OFF --><div class="md"><p>To me their relationship seemed like a very close friendship. They have known each other forever, went through a lot, and then Jayce lived through who knows how many timelines just to see his friend&#39;s work falling apart in every single on of them, so he had to make the most difficult choice - and Viktor understood. </p> <p>Other than that, Jayce had Mel as his girlfriend, and Viktor had a somewhat romantic relationship going on with Sky. You are all telling me, that in their last scene they just randomly turned gay, because they dared to show some emotions? Are men not allowed to show emotions towards their dearest friends, because that makes them gay?</p> <p>What am I missing? </p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Intelligent_Rock5978"> /u/Intelligent_Rock5978 </a> &#32; to &#32; <a href="https://www.reddit.com/r/arcane/"> r/arcane </a> <br/> <span><a href="https://www.reddit.com/r/arcane/comment

## What were the changes that Elio was talking about?
 - [https://www.reddit.com/r/HonkaiStarRail/comments/1hj5q99/what_were_the_changes_that_elio_was_talking_about](https://www.reddit.com/r/HonkaiStarRail/comments/1hj5q99/what_were_the_changes_that_elio_was_talking_about)
 - RSS feed: $source
 - date published: 2024-12-21T08:34:20+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/HonkaiStarRail/comments/1hj5q99/what_were_the_changes_that_elio_was_talking_about/"> <img src="https://preview.redd.it/pzwns9ftx58e1.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=8408ccc0a2afe3040585e8d71a30b1b9b438692a" alt="What were the changes that Elio was talking about?" title="What were the changes that Elio was talking about?" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Invictus875"> /u/Invictus875 </a> &#32; to &#32; <a href="https://www.reddit.com/r/HonkaiStarRail/"> r/HonkaiStarRail </a> <br/> <span><a href="https://i.redd.it/pzwns9ftx58e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/HonkaiStarRail/comments/1hj5q99/what_were_the_changes_that_elio_was_talking_about/">[comments]</a></span> </td></tr></table>

## How Safe Do People Feel to Walk Alone at Night in Europe (2024)
 - [https://www.reddit.com/r/europe/comments/1hj5cyf/how_safe_do_people_feel_to_walk_alone_at_night_in](https://www.reddit.com/r/europe/comments/1hj5cyf/how_safe_do_people_feel_to_walk_alone_at_night_in)
 - RSS feed: $source
 - date published: 2024-12-21T08:05:41+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1hj5cyf/how_safe_do_people_feel_to_walk_alone_at_night_in/"> <img src="https://preview.redd.it/c5p00ptvs58e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=41a33b1647f49e17de75562b2dfba084c863fabc" alt="How Safe Do People Feel to Walk Alone at Night in Europe (2024)" title="How Safe Do People Feel to Walk Alone at Night in Europe (2024)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TAA_verymuch"> /u/TAA_verymuch </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br/> <span><a href="https://i.redd.it/c5p00ptvs58e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1hj5cyf/how_safe_do_people_feel_to_walk_alone_at_night_in/">[comments]</a></span> </td></tr></table>

## I think it's sad to see that player progression loop didn't improve in PoE 2
 - [https://www.reddit.com/r/pathofexile/comments/1hj4vfn/i_think_its_sad_to_see_that_player_progression](https://www.reddit.com/r/pathofexile/comments/1hj4vfn/i_think_its_sad_to_see_that_player_progression)
 - RSS feed: $source
 - date published: 2024-12-21T07:28:37+00:00

<!-- SC_OFF --><div class="md"><p>I want to obtain most of my player power without trading. Trading is lame. I want to trade for niche things or penultimate things when I find something omega rare. </p> <p>The gameplay loop we&#39;ve seen repeatedly in PoE 1 of - Farm for currency &gt; Buy Item for almost every upgrade - isn&#39;t fun. That&#39;s the current state of the PoE 2 after the campaign. </p> <p>The combination of scarcity, difficulty and a very RNG crafting system basically makes trading a must and it&#39;s not only unfun, its&#39; boring.</p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheWealthyExile"> /u/TheWealthyExile </a> &#32; to &#32; <a href="https://www.reddit.com/r/pathofexile/"> r/pathofexile </a> <br/> <span><a href="https://www.reddit.com/r/pathofexile/comments/1hj4vfn/i_think_its_sad_to_see_that_player_progression/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/pathofexile/comments/1hj4vfn/i_think_its_s

## A lesson in waiting at least a day to politicize terrorist attacks. AFD head: „When will this madness end?“ Alleged attacker: is an AFD supporter.
 - [https://www.reddit.com/r/europe/comments/1hj4jz8/a_lesson_in_waiting_at_least_a_day_to_politicize](https://www.reddit.com/r/europe/comments/1hj4jz8/a_lesson_in_waiting_at_least_a_day_to_politicize)
 - RSS feed: $source
 - date published: 2024-12-21T07:04:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1hj4jz8/a_lesson_in_waiting_at_least_a_day_to_politicize/"> <img src="https://preview.redd.it/5wnpd971i58e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9d19fc8b8b2bf74785e4b96b140248d43bb3abc9" alt="A lesson in waiting at least a day to politicize terrorist attacks. AFD head: „When will this madness end?“ Alleged attacker: is an AFD supporter." title="A lesson in waiting at least a day to politicize terrorist attacks. AFD head: „When will this madness end?“ Alleged attacker: is an AFD supporter." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/AmerikanischerTopfen"> /u/AmerikanischerTopfen </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br/> <span><a href="https://i.redd.it/5wnpd971i58e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1hj4jz8/a_lesson_in_waiting_at_least_a_day_to_politicize/">[comments]</a></span

## Poland Threatens to Arrest Netanyahu for War Crimes If He Attends Holocaust Memorial Ceremony
 - [https://www.reddit.com/r/poland/comments/1hj4aqh/poland_threatens_to_arrest_netanyahu_for_war](https://www.reddit.com/r/poland/comments/1hj4aqh/poland_threatens_to_arrest_netanyahu_for_war)
 - RSS feed: $source
 - date published: 2024-12-21T06:46:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/poland/comments/1hj4aqh/poland_threatens_to_arrest_netanyahu_for_war/"> <img src="https://external-preview.redd.it/h0mozNt2493SQVOeoegk0XHoqd0647yIXcFHB3zQaB8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3ea4952307f9340bd47eeebadd79dd50e55f0e78" alt="Poland Threatens to Arrest Netanyahu for War Crimes If He Attends Holocaust Memorial Ceremony" title="Poland Threatens to Arrest Netanyahu for War Crimes If He Attends Holocaust Memorial Ceremony" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/mynameisatari"> /u/mynameisatari </a> &#32; to &#32; <a href="https://www.reddit.com/r/poland/"> r/poland </a> <br/> <span><a href="https://www.latintimes.com/poland-threatens-arrest-netanyahu-war-crimes-if-he-attends-holocaust-memorial-ceremony-569968">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/poland/comments/1hj4aqh/poland_threatens_to_arrest_netanyahu_for_war/">[comments]</a></span> </td

## Meet Irena Sendler – The Woman Who Saved 2,500 Children During WWII, Irena Sendler smuggled Jewish children out of the Warsaw Ghetto, hiding them in suitcases, toolboxes, and ambulances. She kept their identities in jars buried under a tree, hoping to reunite them with their families after the war.
 - [https://www.reddit.com/r/Damnthatsinteresting/comments/1hj3xty/meet_irena_sendler_the_woman_who_saved_2500](https://www.reddit.com/r/Damnthatsinteresting/comments/1hj3xty/meet_irena_sendler_the_woman_who_saved_2500)
 - RSS feed: $source
 - date published: 2024-12-21T06:21:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Damnthatsinteresting/comments/1hj3xty/meet_irena_sendler_the_woman_who_saved_2500/"> <img src="https://preview.redd.it/i4moj5v7a58e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3037010f8e15128113e162f0611e7a2fc7421827" alt="Meet Irena Sendler – The Woman Who Saved 2,500 Children During WWII, Irena Sendler smuggled Jewish children out of the Warsaw Ghetto, hiding them in suitcases, toolboxes, and ambulances. She kept their identities in jars buried under a tree, hoping to reunite them with their families after the war." title="Meet Irena Sendler – The Woman Who Saved 2,500 Children During WWII, Irena Sendler smuggled Jewish children out of the Warsaw Ghetto, hiding them in suitcases, toolboxes, and ambulances. She kept their identities in jars buried under a tree, hoping to reunite them with their families after the war." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DIO-2350"> /u/DIO-2350 </a> 

## Breaking News: Cryo Sisters finally out of prison
 - [https://www.reddit.com/r/Genshin_Impact/comments/1hj3lyd/breaking_news_cryo_sisters_finally_out_of_prison](https://www.reddit.com/r/Genshin_Impact/comments/1hj3lyd/breaking_news_cryo_sisters_finally_out_of_prison)
 - RSS feed: $source
 - date published: 2024-12-21T05:58:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/Genshin_Impact/comments/1hj3lyd/breaking_news_cryo_sisters_finally_out_of_prison/"> <img src="https://preview.redd.it/zogoa52b658e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=53937d5c221ff00a1a9b2b1a44ac476729707bdb" alt="Breaking News: Cryo Sisters finally out of prison " title="Breaking News: Cryo Sisters finally out of prison " /> </a> </td><td> <!-- SC_OFF --><div class="md"><p>Cloud Retainer finally frees her daughters from prison after more than a year and half. </p> <p>It was a lengthy legal battle against Hoyo HQ but advocate Yan Fei, representing the petitioners, along with the support of Genshin Community finally managed to exonerate the sisters, says her next client is Wriothesley.</p> <p>Next up, Pyro Archon and her adventures with the <span class="md-spoiler-text">fourth descender</span></p> </div><!-- SC_ON --> &#32; submitted by &#32; <a href="https://www.reddit.com/user/CreamOk2519"> /u/CreamOk2519 </a> &#32; t

## Polsko-magyar relationship in shatter
 - [https://www.reddit.com/r/2visegrad4you/comments/1hj3gfk/polskomagyar_relationship_in_shatter](https://www.reddit.com/r/2visegrad4you/comments/1hj3gfk/polskomagyar_relationship_in_shatter)
 - RSS feed: $source
 - date published: 2024-12-21T05:48:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/2visegrad4you/comments/1hj3gfk/polskomagyar_relationship_in_shatter/"> <img src="https://preview.redd.it/q51wm24h458e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=4dcbc9130306fe4ba50cc39fc90e06f4c9589923" alt="Polsko-magyar relationship in shatter" title="Polsko-magyar relationship in shatter" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DrunkenMode"> /u/DrunkenMode </a> &#32; to &#32; <a href="https://www.reddit.com/r/2visegrad4you/"> r/2visegrad4you </a> <br/> <span><a href="https://i.redd.it/q51wm24h458e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/2visegrad4you/comments/1hj3gfk/polskomagyar_relationship_in_shatter/">[comments]</a></span> </td></tr></table>

## Tesla Sales Are Tanking In Europe
 - [https://www.reddit.com/r/europe/comments/1hj1g2z/tesla_sales_are_tanking_in_europe](https://www.reddit.com/r/europe/comments/1hj1g2z/tesla_sales_are_tanking_in_europe)
 - RSS feed: $source
 - date published: 2024-12-21T03:44:04+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/europe/comments/1hj1g2z/tesla_sales_are_tanking_in_europe/"> <img src="https://external-preview.redd.it/dx-jJ_u4599EHYzsAFzcXxsoWgUJhbI6FvZWl20YDhc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f92f55c810cd1afad79068ec6423c6def5cc1661" alt="Tesla Sales Are Tanking In Europe" title="Tesla Sales Are Tanking In Europe" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/RGV_KJ"> /u/RGV_KJ </a> &#32; to &#32; <a href="https://www.reddit.com/r/europe/"> r/europe </a> <br/> <span><a href="https://insideevs.com/news/745119/tesla-sales-europe-2024/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/europe/comments/1hj1g2z/tesla_sales_are_tanking_in_europe/">[comments]</a></span> </td></tr></table>

## Killing is a Cycle has officially dropped below a 9 on IMDB. Arcane no longer holds the title of only show with an entire season rated higher than a 9.
 - [https://www.reddit.com/r/arcane/comments/1hj196q/killing_is_a_cycle_has_officially_dropped_below_a](https://www.reddit.com/r/arcane/comments/1hj196q/killing_is_a_cycle_has_officially_dropped_below_a)
 - RSS feed: $source
 - date published: 2024-12-21T03:32:37+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/arcane/comments/1hj196q/killing_is_a_cycle_has_officially_dropped_below_a/"> <img src="https://preview.redd.it/rg8h8bt7g48e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=b74c79a5b6d39f86777b4b839e923f9f32244bcc" alt="Killing is a Cycle has officially dropped below a 9 on IMDB. Arcane no longer holds the title of only show with an entire season rated higher than a 9." title="Killing is a Cycle has officially dropped below a 9 on IMDB. Arcane no longer holds the title of only show with an entire season rated higher than a 9." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MF_BENDA"> /u/MF_BENDA </a> &#32; to &#32; <a href="https://www.reddit.com/r/arcane/"> r/arcane </a> <br/> <span><a href="https://i.redd.it/rg8h8bt7g48e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/arcane/comments/1hj196q/killing_is_a_cycle_has_officially_dropped_below_a/">[comments]</a></span> </td></tr>

## How do I re-adjust to Polish culture
 - [https://www.reddit.com/r/poland/comments/1hiz521/how_do_i_readjust_to_polish_culture](https://www.reddit.com/r/poland/comments/1hiz521/how_do_i_readjust_to_polish_culture)
 - RSS feed: $source
 - date published: 2024-12-21T01:32:19+00:00

<!-- SC_OFF --><div class="md"><p>I myself am Polish (Urodziłem się w Łodzi i żyłem z matką w Polsce przez pierwsze 6/5 lat) however I and my mother immigrated to the UK, where I have spent all of my life and spent all my years in school there as well from primary school to university and from time to time coming back to Poland for long trips staying with my family (each year I would spend about 1-2 months in Poland straight during the summer). However each time I am faced with the same culture shock as always…</p> <p>(No offence)</p> <p>…People seem to be rude.</p> <p>Again I know this is because I am used to the British environment but every single time I come back to Poland I am shocked and offended by someone (unintentionally) being rude to me, I’m coming back to Poland for January and I don’t want to repeat the whole process again of me getting shocked, offended, then miserable and becoming a dick myself because I have a feeling everyone is being rude etc etc. How can I fix this

## This is not a drill. I repeat, this is not a drill.
 - [https://www.reddit.com/r/whenthe/comments/1hiyxs7/this_is_not_a_drill_i_repeat_this_is_not_a_drill](https://www.reddit.com/r/whenthe/comments/1hiyxs7/this_is_not_a_drill_i_repeat_this_is_not_a_drill)
 - RSS feed: $source
 - date published: 2024-12-21T01:21:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/whenthe/comments/1hiyxs7/this_is_not_a_drill_i_repeat_this_is_not_a_drill/"> <img src="https://external-preview.redd.it/NjZpOXRtaWxzMzhlMc9VrHIFhJG_WpBiVuRb7Rv-qiYdhpzjaRB8Wjs5gT-C.png?width=640&amp;crop=smart&amp;auto=webp&amp;s=38bf92bf26ffbccc122ef3075373040f6a920a92" alt="This is not a drill. I repeat, this is not a drill." title="This is not a drill. I repeat, this is not a drill." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BBunny821"> /u/BBunny821 </a> &#32; to &#32; <a href="https://www.reddit.com/r/whenthe/"> r/whenthe </a> <br/> <span><a href="https://v.redd.it/5n6fucils38e1">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/whenthe/comments/1hiyxs7/this_is_not_a_drill_i_repeat_this_is_not_a_drill/">[comments]</a></span> </td></tr></table>

## Poland Gdynia
 - [https://www.reddit.com/r/poland/comments/1hixn8n/poland_gdynia](https://www.reddit.com/r/poland/comments/1hixn8n/poland_gdynia)
 - RSS feed: $source
 - date published: 2024-12-21T00:13:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/poland/comments/1hixn8n/poland_gdynia/"> <img src="https://preview.redd.it/og3bfjoog38e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=758bb78d16b6bc1cef2322015beb8d506169b091" alt="Poland Gdynia" title="Poland Gdynia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/natenczas"> /u/natenczas </a> &#32; to &#32; <a href="https://www.reddit.com/r/poland/"> r/poland </a> <br/> <span><a href="https://i.redd.it/og3bfjoog38e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/poland/comments/1hixn8n/poland_gdynia/">[comments]</a></span> </td></tr></table>

