# Source:Tale of Painters, URL:https://taleofpainters.com/feed, language:en-GB

## Review: Citadel Servo-skull palette
 - [https://taleofpainters.com/2024/12/review-citadel-servo-skull-palette](https://taleofpainters.com/2024/12/review-citadel-servo-skull-palette)
 - RSS feed: $source
 - date published: 2024-12-21T14:00:00+00:00

<p>Games Workshop's product design team often comes up with hobby accessories that make you wonder what they've been smoking. The Servo Skull palette combines a reusable silicone palette with a quirky grimdark design. In this review, we'll take a closer look at this odd creation. I really wanted to love it, but...</p>
<p>The post <a href="https://taleofpainters.com/2024/12/review-citadel-servo-skull-palette/">Review: Citadel Servo-skull palette</a> appeared first on <a href="https://taleofpainters.com">Tale of Painters</a>.</p>

