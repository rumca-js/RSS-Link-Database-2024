# Source:Jordan B Peterson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL_f53ZEJxp8TtlOkHwMV9Q, language:en-US

## The Last Shall Be First | The Gospels
 - [https://www.youtube.com/watch?v=R-kYgxPdjYg](https://www.youtube.com/watch?v=R-kYgxPdjYg)
 - RSS feed: $source
 - date published: 2024-12-21T19:00:13+00:00

None

