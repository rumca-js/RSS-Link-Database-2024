# Source:Lindsey Stirling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g, language:en-US

## Here is another little clip from our halftime pertormance at the #packers game. #halftime #liveshow
 - [https://www.youtube.com/watch?v=q_vaHJY4uww](https://www.youtube.com/watch?v=q_vaHJY4uww)
 - RSS feed: $source
 - date published: 2024-12-04T21:45:05+00:00

None

## How many spins did I do in the intro? #liveshow #ontour
 - [https://www.youtube.com/watch?v=ViLKD0xkWrU](https://www.youtube.com/watch?v=ViLKD0xkWrU)
 - RSS feed: $source
 - date published: 2024-12-04T21:43:26+00:00

None

## This tour has been so fun! Thank you for everyone who has come #snowwaltz #violin #liveshow
 - [https://www.youtube.com/watch?v=QOyHbiUpki8](https://www.youtube.com/watch?v=QOyHbiUpki8)
 - RSS feed: $source
 - date published: 2024-12-04T21:42:28+00:00

None

