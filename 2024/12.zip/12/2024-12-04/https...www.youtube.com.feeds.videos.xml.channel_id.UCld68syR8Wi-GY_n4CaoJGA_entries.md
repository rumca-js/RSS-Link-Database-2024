# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## I Was Right About KDE
 - [https://www.youtube.com/watch?v=5vivHquoiAc](https://www.youtube.com/watch?v=5vivHquoiAc)
 - RSS feed: $source
 - date published: 2024-12-04T20:00:03+00:00

I said it before and I'll keep saying that the FOSS world has a lot of money in it, the issue is people have absolutely no idea how to ask for money relying on social media campaigns, not reaching out to people with audiences, and not doing direct calls to action where the users are.

==========Support The Channel==========
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Thunderbird Report: https://blog.thunderbird.net/2023/05/thunderbird-is-thriving-our-2022-financial-report/
Thunderbird Financials: https://stats.thunderbird.net/#financials
KDE MR: https://invent.kde.org/plasma/plasma-workspace/-/merge_requests/4490
KDE Donations: https://kde.org/community/donations/previousdonations/

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮

