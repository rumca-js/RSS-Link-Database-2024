# Source:Amiga, URL:https://www.reddit.com/r/amiga/.rss, language:en

## If you'd been with me, you would've laughed when my eyes bugged out after I spotted this in the "random parts bin" at my local junk store today
 - [https://www.reddit.com/r/amiga/comments/1h6r2gd/if_youd_been_with_me_you_wouldve_laughed_when_my](https://www.reddit.com/r/amiga/comments/1h6r2gd/if_youd_been_with_me_you_wouldve_laughed_when_my)
 - RSS feed: $source
 - date published: 2024-12-04T21:01:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1h6r2gd/if_youd_been_with_me_you_wouldve_laughed_when_my/"> <img src="https://preview.redd.it/tf14l4fobw4e1.jpeg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3da6ecd0e3272e95cce87af1c4482178a9e9a5ce" alt="If you'd been with me, you would've laughed when my eyes bugged out after I spotted this in the &quot;random parts bin&quot; at my local junk store today" title="If you'd been with me, you would've laughed when my eyes bugged out after I spotted this in the &quot;random parts bin&quot; at my local junk store today" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/wowbobwow"> /u/wowbobwow </a> <br/> <span><a href="https://i.redd.it/tf14l4fobw4e1.jpeg">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1h6r2gd/if_youd_been_with_me_you_wouldve_laughed_when_my/">[comments]</a></span> </td></tr></table>

## Selling Amiga OS 3, OS4 etc. stuff
 - [https://www.reddit.com/r/amiga/comments/1h6p7ao/selling_amiga_os_3_os4_etc_stuff](https://www.reddit.com/r/amiga/comments/1h6p7ao/selling_amiga_os_3_os4_etc_stuff)
 - RSS feed: $source
 - date published: 2024-12-04T19:45:49+00:00

<!-- SC_OFF --><div class="md"><p>Prices are negotiable, but auctioned in case of multiple interest<br/> Note that prices in Serbia are inflated by P&amp;P and custom fees since we are non EU<br/> Pictures (KP advert with pics on request)<br/> jahdeliverus at <a href="http://gmail.com">gmail.com</a> </p> <p>AMIGA RELATED<br/> Wizard Developments 9 pin mouse Model AD-T36 Amiga Atari 49e USED<br/> Vampire V4 Standalone Crystal Case Kit 75e UNUSED<br/> RadeonHD.chip Driver Version 10 RC2 2D x1000 CD Plus Digital 5e<br/> RETKO A-EON Enhancer software 1.x 2016 15e<br/> Amiga Format CD 11 Alien Breed Turbo Calc Amiga sw games AD 25e<br/> Amiga Format 33 games PD Software CD 25e<br/> AF132 Jan 2000 AFCD48 AMIGA GAMES SW CD 20e<br/> Amiga Format Disc 14 CD Amiga games PD SW June 97 IssueAF 98 20e<br/> Manuals AmigaOS 4.1 3 pieces, one is in bad shame, 2 mint (Classic, SAM440, x1000)<br/> Vampire Amiga stickers V2 10e<br/> The Best of AMIGA Scene Archives 88 - 98 15e<br/> BITPLANE Amiga magaz

## Install and run AROS, MorphOS 3.18, and AmigaOS 4.1 Final Edition PPC in qemu
 - [https://www.reddit.com/r/amiga/comments/1h6k9be/install_and_run_aros_morphos_318_and_amigaos_41](https://www.reddit.com/r/amiga/comments/1h6k9be/install_and_run_aros_morphos_318_and_amigaos_41)
 - RSS feed: $source
 - date published: 2024-12-04T16:30:07+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/JTHonn"> /u/JTHonn </a> <br/> <span><a href="/r/qemu_kvm/comments/1h6k90n/install_and_run_aros_morphos_318_and_amigaos_41/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1h6k9be/install_and_run_aros_morphos_318_and_amigaos_41/">[comments]</a></span>

## From an email advert earlier, I feel targeted.
 - [https://www.reddit.com/r/amiga/comments/1h6cpru/from_an_email_advert_earlier_i_feel_targeted](https://www.reddit.com/r/amiga/comments/1h6cpru/from_an_email_advert_earlier_i_feel_targeted)
 - RSS feed: $source
 - date published: 2024-12-04T10:07:56+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/amiga/comments/1h6cpru/from_an_email_advert_earlier_i_feel_targeted/"> <img src="https://preview.redd.it/fld27z6y2t4e1.png?width=320&amp;crop=smart&amp;auto=webp&amp;s=5ace780c98f2352bce5676ea7ed04e9f906702fe" alt="From an email advert earlier, I feel targeted." title="From an email advert earlier, I feel targeted." /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/SeaElephant8890"> /u/SeaElephant8890 </a> <br/> <span><a href="https://i.redd.it/fld27z6y2t4e1.png">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/amiga/comments/1h6cpru/from_an_email_advert_earlier_i_feel_targeted/">[comments]</a></span> </td></tr></table>

## A500 OCS Rev5 and trapdoor CHIP/SLOW RAM
 - [https://www.reddit.com/r/amiga/comments/1h6aw4o/a500_ocs_rev5_and_trapdoor_chipslow_ram](https://www.reddit.com/r/amiga/comments/1h6aw4o/a500_ocs_rev5_and_trapdoor_chipslow_ram)
 - RSS feed: $source
 - date published: 2024-12-04T07:48:58+00:00

<!-- SC_OFF --><div class="md"><p>I&#39;d like to confirm that getting Trapdoor SLOW RAM to work as CHIP RAM in this machine I need to:</p> <ol> <li><p>Have at least an ECS Agnus</p></li> <li><p>Have to cut a JP2 pad and bridge it the other way</p></li> <li><p>Have to cut a trace on the motherboard</p></li> </ol> <p>Regarding JP2 and/or trace cutting, is it true that these <em>really</em> do not need it:</p> <p>- ACA500+ doesn&#39;t mention JP2 nor trace cutting, but does need at least an ECS Agnus</p> <p>- &quot;Amiga 500 512KB/2MB Memory Expansion + RTC&quot; also doesn&#39;t mention JPS2 nor trace cutting and needs ECS Agnus</p> <p>Is it worth getting the 2MB Memory Expansion just for the 1.5MB of SLOW RAM if I don&#39;t want to mess with CHIP RAM?<br/> Does it break any compatibility (any games that expect exactly 0.5MB SLOW RAM)?</p> <p>Regarding ACA500+, it&#39;s stated that it can emulate Trapdoor RAM even if it&#39;s not present - does that mean it dedicates 512k from it&#39;

