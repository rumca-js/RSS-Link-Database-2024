# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Call of Duty generuje krocie. Nowe dane potwierdzają dominację serii
 - [https://ithardware.pl/aktualnosci/call_of_duty_black_ops_6-37058.html](https://ithardware.pl/aktualnosci/call_of_duty_black_ops_6-37058.html)
 - RSS feed: $source
 - date published: 2024-12-04T22:17:58.669744+00:00

 <img src="https://ithardware.pl/artykuly/min/37058_1.jpg">            Call of Duty to franczyza generująca Activision Blizzard krocie, co potwierdzają najnowsze dane Newzoo. Przyczyniło się do tego nie tylko Black Ops 6, ale r&oacute;wnież starsze odsłony serii.

Call of Duty najbardziej dochodową serią...
            

## Kreator postaci Dragon Age: The Veilguard to teraz samodzielna gra
 - [https://ithardware.pl/aktualnosci/dragon_age_the_veilguard_kreator_postaci-37055.html](https://ithardware.pl/aktualnosci/dragon_age_the_veilguard_kreator_postaci-37055.html)
 - RSS feed: $source
 - date published: 2024-12-04T22:17:58.585795+00:00

 <img src="https://ithardware.pl/artykuly/min/37055_1.jpg">            Środa okazała się wyjątkowym dniem dla fan&oacute;w serii&nbsp;Dragon Age. Z okazji obchod&oacute;w corocznego Dnia Dragon Age studio BioWare przygotowało szereg niespodzianek zar&oacute;wno dla&nbsp;nowych graczy, jak i weteran&oacute;w serii....
            

## Kingdom Come: Deliverance 2 zadebiutuje wcześniej. Warhorse Studios ujawnia nowy termin
 - [https://ithardware.pl/aktualnosci/kingdom_come_deliverance_2_premiera_kiedy-37056.html](https://ithardware.pl/aktualnosci/kingdom_come_deliverance_2_premiera_kiedy-37056.html)
 - RSS feed: $source
 - date published: 2024-12-04T21:13:07.632841+00:00

 <img src="https://ithardware.pl/artykuly/min/37056_1.jpg">                                                    
                                        Deweloperzy gier zazwyczaj opóźniają premiery swoich gier, ale w przypadku Kingdom Come: Deliverance 2 mowa o przyspieszeniu wydania. Tytuł trafi do graczy nieco...
            

## Unia podłącza kroplówkę producentom akumulatorów. Miliard euro, ale jest warunek
 - [https://ithardware.pl/aktualnosci/unia_producenci_akumulatory_elektryki_dotacja-37057.html](https://ithardware.pl/aktualnosci/unia_producenci_akumulatory_elektryki_dotacja-37057.html)
 - RSS feed: $source
 - date published: 2024-12-04T20:07:52.392432+00:00

 <img src="https://ithardware.pl/artykuly/min/37057_1.jpg">                                                    
                                        W obliczu rosnącej konkurencji na globalnym rynku akumulatorów do pojazdów elektrycznych (EV) i dominacji Chin, Komisja Europejska ogłosiła wsparcie finansowe w...
            

## Windows zmusi, by wyrzucić miliony komputerów? "To nie podlega negocjacjom"
 - [https://ithardware.pl/aktualnosci/microsoft_windows_starsze_procesory_wymagania-37052.html](https://ithardware.pl/aktualnosci/microsoft_windows_starsze_procesory_wymagania-37052.html)
 - RSS feed: $source
 - date published: 2024-12-04T20:07:52.015161+00:00

 <img src="https://ithardware.pl/artykuly/min/37052_1.jpg">            Za niespełna rok system operacyjny&nbsp;Windows 10&nbsp;przestanie być wspierany przez Microsoft, co zmusi miliony użytkownik&oacute;w do podjęcia decyzji dotyczącej przyszłości ich komputer&oacute;w. Wraz z zakończeniem wsparcia użytkownicy...
            

## NVIDIA pokazuje spektakularne narzędzie. Każdy może być teraz mistrzem edycji
 - [https://ithardware.pl/aktualnosci/nvidia_edycja_zdjec_przesuwanie_elementow-37053.html](https://ithardware.pl/aktualnosci/nvidia_edycja_zdjec_przesuwanie_elementow-37053.html)
 - RSS feed: $source
 - date published: 2024-12-04T20:07:51.636298+00:00

 <img src="https://ithardware.pl/artykuly/min/37053_1.jpg">                                                    
                                        Podczas konferencji SIGGRAPH Asia 2024, Nvidia zaprezentowała nowatorski model sztucznej inteligencji o nazwie DiffUHaul, który pozwala na przenoszenie obiektów na...
            

## Legendarny producent zmienia kurs. Produkowali wyłącznie Radeony, teraz zajmą się Intelem
 - [https://ithardware.pl/aktualnosci/onix_sapphire_radeon_intel_produkcja_kart-37050.html](https://ithardware.pl/aktualnosci/onix_sapphire_radeon_intel_produkcja_kart-37050.html)
 - RSS feed: $source
 - date published: 2024-12-04T20:07:51.282368+00:00

 <img src="https://ithardware.pl/artykuly/min/37050_1.jpg">            W świecie sprzętu komputerowego niespodzianki zdarzają się rzadko, ale debiut nowej marki kart rozszerzeń (AIB) &ndash;&nbsp;Onix&nbsp;&ndash; przy okazji premiery kart graficznych&nbsp;Intel Arc B580 i Arc B570&nbsp;to spore zaskoczenie. Onix nie...
            

## Elon Musk wstrzymuje produkcję. Jego hit przestał się sprzedawać
 - [https://ithardware.pl/aktualnosci/elon_musk_tesla_cybertruck_wstrzymany-37054.html](https://ithardware.pl/aktualnosci/elon_musk_tesla_cybertruck_wstrzymany-37054.html)
 - RSS feed: $source
 - date published: 2024-12-04T19:02:53.152001+00:00

 <img src="https://ithardware.pl/artykuly/min/37054_1.jpg">            Tesla, lider wśr&oacute;d producent&oacute;w pojazd&oacute;w elektrycznych, zmaga się ze spowolnieniem popytu na sw&oacute;j futurystyczny model&nbsp;Cybertruck. Jak ujawniły wewnętrzne informacje, firma zarządziła trzydniową przerwę produkcyjną...
            

## Schneider Electric - nowe rozwiązania na wyzwania związane z AI i zasilacz UPS
 - [https://ithardware.pl/aktualnosci/schneider_electric_zasilacz_ups_ai-37051.html](https://ithardware.pl/aktualnosci/schneider_electric_zasilacz_ups_ai-37051.html)
 - RSS feed: $source
 - date published: 2024-12-04T19:02:52.916429+00:00

 <img src="https://ithardware.pl/artykuly/min/37051_1.jpg">            Schneider Electric&nbsp;wprowadza na rynek nowy tr&oacute;jfazowy zasilacz UPS Galaxy VXL &ndash; kompaktowy, modułowy, skalowalny i redundantny, dostępny w zakresie mocy od 500 do 1250 kW (400 V). Galaxy VXL charakteryzuje się zwiększonym poziomem...
            

## Jeśli to jest nowy iPhone, to Apple ma nowy hit. Tylko cena pewnie wyrwie z butów
 - [https://ithardware.pl/aktualnosci/apple_iphone_skladany_wyglad_przecieki-37044.html](https://ithardware.pl/aktualnosci/apple_iphone_skladany_wyglad_przecieki-37044.html)
 - RSS feed: $source
 - date published: 2024-12-04T17:57:55.060710+00:00

 <img src="https://ithardware.pl/artykuly/min/37044_1.jpg">            Rynek składanych smartfon&oacute;w rozwija się, a Samsung i inni producenci oferują kolejne składane modele. W tym segmencie brakuje jednak Apple. Firma z Cupertino zamierza w przyszłości zaoferować składany telefon. Jaką formę...
            

## Apple wywalił, inni podchwycili i będą produkować. Cena kosmiczna, ale chociaż działa z Windows
 - [https://ithardware.pl/aktualnosci/apple_macbook_touchbar_premira_cena-37049.html](https://ithardware.pl/aktualnosci/apple_macbook_touchbar_premira_cena-37049.html)
 - RSS feed: $source
 - date published: 2024-12-04T17:57:54.962865+00:00

 <img src="https://ithardware.pl/artykuly/min/37049_1.jpg">            Oto Flexbar, czyli dodatkowy ekran, kt&oacute;ry można wykorzystać w wielu aplikacjach kreatywnych, a nawet grach. W przeciwieństwie do touch bara od Apple jest on kompatybilny r&oacute;wnież z komputerami PC.



Touch bar w MacBookach odszedł...
            

## Max niczym Netflix. Rozpoczyna walkę z udostępnianiem haseł
 - [https://ithardware.pl/aktualnosci/hbo_max_platforma_udostepnianie_hasel-37042.html](https://ithardware.pl/aktualnosci/hbo_max_platforma_udostepnianie_hasel-37042.html)
 - RSS feed: $source
 - date published: 2024-12-04T16:53:01.869563+00:00

 <img src="https://ithardware.pl/artykuly/min/37042_1.jpg">            Platformy streamingowe takie jak Netflix czy Disney+ walczą z udostępnianiem haseł i ograniczają dzielenie się kontami. Max zamierza od przyszłego tygodnia wyciągać konsekwencje wobec os&oacute;b udostępniających hasła.

Max rozpocznie...
            

## Kup monitor MSI QD-OLED i odbierz epickie nagrody. Darmowa gra S.T.A.L.K.E.R. 2 i voucher Steam
 - [https://ithardware.pl/aktualnosci/kup_monitor_msi_qd_oled_i_odbierz_epickie_nagrody_darmowa_gra_s_t_a_l_k_e_r_2_i_voucher_steam-37048.html](https://ithardware.pl/aktualnosci/kup_monitor_msi_qd_oled_i_odbierz_epickie_nagrody_darmowa_gra_s_t_a_l_k_e_r_2_i_voucher_steam-37048.html)
 - RSS feed: $source
 - date published: 2024-12-04T15:47:54.994181+00:00

 <img src="https://ithardware.pl/artykuly/min/37048_1.jpg">            MSI rozpoczyna specjalną promocję dla zapalonych graczy. Osoby, kt&oacute;re zakupią w grudniu kwalifikujący się produkt MSI i podzielą się swoimi wrażeniami na platformach zakupowych, otrzymają darmowy klucz do gry S.T.A.L.K.E.R. 2 na PC (o...
            

## Skaner dentystyczny jako pecet do gier? W latach świetności to był przepotężny sprzęt
 - [https://ithardware.pl/aktualnosci/skander_denstystyczny_gaming_reddit-37047.html](https://ithardware.pl/aktualnosci/skander_denstystyczny_gaming_reddit-37047.html)
 - RSS feed: $source
 - date published: 2024-12-04T15:47:54.909955+00:00

 <img src="https://ithardware.pl/artykuly/min/37047_1.jpg">                                                    
                                        Skaner 3D w gabinecie dentystycznym skrywa zaskakująco mocne podzespoły. Są na tyle wydajne, że bez kłopotu można uruchamiać na nich gry. W specyfikacji znalazł...
            

## Samsung po latach ubija ikoniczną funkcję. Klientom zaleca konkurencyjne rozwiązanie
 - [https://ithardware.pl/aktualnosci/samsung_dex_laczenie_windows-37046.html](https://ithardware.pl/aktualnosci/samsung_dex_laczenie_windows-37046.html)
 - RSS feed: $source
 - date published: 2024-12-04T14:42:57.308622+00:00

 <img src="https://ithardware.pl/artykuly/min/37046_1.jpg">            Samsung rekomenduje teraz przejście na podobną aplikację Microsoftu. Wraz z kolejną dużą aktualizacją systemu urządzenia koreańskiego giganta stracą dostęp do ciekawej funkcji łączącej sprzęt na Androidzie z Windowsem.



Aktualizacja...
            

## Test S.T.A.L.K.E.R. 2 na laptopie z GeForce RTX 4090. Czy DLSS uratuje sytuację?
 - [https://ithardware.pl/testyirecenzje/stalker_2_dlss_test_na_laptopie-37043.html](https://ithardware.pl/testyirecenzje/stalker_2_dlss_test_na_laptopie-37043.html)
 - RSS feed: $source
 - date published: 2024-12-04T14:42:57.224588+00:00

 <img src="https://ithardware.pl/artykuly/min/37043_1.jpg">            Gra S.T.A.L.K.E.R. 2: Serce Czarnobyla to niewątpliwie jedna z najważniejszych premier tego roku. W ramach niniejszego testu sprawdzimy, jak produkcja studia GSC Game World wygląda od strony technicznej, zar&oacute;wno jeśli chodzi o wydajność, jak...
            

## Nie Intel ani AMD, lecz Qualcomm. Oto mini-PC z innej parafii
 - [https://ithardware.pl/aktualnosci/snapdragon_x_elite_mini_pc_geekom_premiera-37045.html](https://ithardware.pl/aktualnosci/snapdragon_x_elite_mini_pc_geekom_premiera-37045.html)
 - RSS feed: $source
 - date published: 2024-12-04T13:37:53.177426+00:00

 <img src="https://ithardware.pl/artykuly/min/37045_1.jpg">            Oto miniaturowy komputer wykorzystujący procesor Snapdragon X Elite. Przeciek sugeruje, że Geekom może niedługo wprowadzić go do swojej oferty. Urządzenie nie ma jeszcze podaje daty premiery.



Snapdragon X Elite już nie tylko dla...
            

## Facebook w końcu się przyznaje. "Wiemy, że istnieje problem"
 - [https://ithardware.pl/aktualnosci/facebook_instagram_meta_moderacja_tresci-37040.html](https://ithardware.pl/aktualnosci/facebook_instagram_meta_moderacja_tresci-37040.html)
 - RSS feed: $source
 - date published: 2024-12-04T13:36:20+00:00

 <img src="https://ithardware.pl/artykuly/min/37040_1.jpg">            Moderacja treści na Facebooku od zawsze wzbudza kontrowersje. Nawet Meta, właściciel serwisu przyznaje, iż istnieje problem z moderacją treści na Facebooku oraz Instagramie.

Meta przyznaje, że ma problem z moderowaniem treści na Instagramie i...
            

## AMD przypadkiem ujawniło część serii Radeon RX 8000. Wiemy o trzech modelach
 - [https://ithardware.pl/aktualnosci/amd_radeon_rx_8000_karty_graficzne_modele-37041.html](https://ithardware.pl/aktualnosci/amd_radeon_rx_8000_karty_graficzne_modele-37041.html)
 - RSS feed: $source
 - date published: 2024-12-04T12:33:09.423144+00:00

 <img src="https://ithardware.pl/artykuly/min/37041_1.jpg">                                                    
                                        Premiera Radeon RX 8000 jest już całkiem blisko. O nowych kartach graficznych wspomina teraz nawet oprogramowanie AMD. W kodzie nowej wersji ROCm znalazły się wzmianki...
            

## TSMC poprawia uzysk 2 nm litografii. To miliardy oszczędności dla klientów
 - [https://ithardware.pl/aktualnosci/tsmc_uzysk_technologia_2_nm-37036.html](https://ithardware.pl/aktualnosci/tsmc_uzysk_technologia_2_nm-37036.html)
 - RSS feed: $source
 - date published: 2024-12-04T11:27:50.241555+00:00

 <img src="https://ithardware.pl/artykuly/min/37036_1.jpg">                                                    
                                        TSMC ogłosiło, że w drugiej połowie 2025 roku rozpocznie masową produkcję półprzewodników przy użyciu procesu technologicznego N2 (klasy 2 nm). Obecnie firma...
            

## Nowy rekord w podkręcaniu DDR5. Kości G.Skill osiągnęły ponad 12 tys. MT/s
 - [https://ithardware.pl/aktualnosci/g_skill_ddr5_podkrecanie_rekord_6333-37039.html](https://ithardware.pl/aktualnosci/g_skill_ddr5_podkrecanie_rekord_6333-37039.html)
 - RSS feed: $source
 - date published: 2024-12-04T11:27:50.004982+00:00

 <img src="https://ithardware.pl/artykuly/min/37039_1.jpg">            Mamy nowy rekord w ekstremalnym podkręcaniu pamięci DDR5. Dwukrotny zwycięzca G.Skill OC World Cup razem z ASRockiem i G.Skill uzyskał wynik przekraczający 12 tysięcy MT/s.



G.Skill zajął się ekstremalnym overclockingiem swoich pamięci...
            

## Takiego GeForce'a RTX 4060 Ti nie ma w sklepach, więc zrobił go sam. Jest w pełni pasywny
 - [https://ithardware.pl/aktualnosci/nvidia_geforce_rtx_4060_ti_pasywny_modyfikacja-37034.html](https://ithardware.pl/aktualnosci/nvidia_geforce_rtx_4060_ti_pasywny_modyfikacja-37034.html)
 - RSS feed: $source
 - date published: 2024-12-04T10:22:49.649737+00:00

 <img src="https://ithardware.pl/artykuly/min/37034_1.jpg">                                                    
                                                                                
                                        Entuzjasta komputerów typu SFF (Small Form Factor) znany na Reddicie jako a0910115172...
            

## Unii nie podoba się anonimowość. Od 30 grudnia czekają nas znaczące zmiany
 - [https://ithardware.pl/aktualnosci/unia_europejska_kryptowaluty_anonimowosc_zmiany-37038.html](https://ithardware.pl/aktualnosci/unia_europejska_kryptowaluty_anonimowosc_zmiany-37038.html)
 - RSS feed: $source
 - date published: 2024-12-04T10:22:49.561752+00:00

 <img src="https://ithardware.pl/artykuly/min/37038_1.jpg">            Od 30 grudnia 2024 roku obr&oacute;t kryptowalutami w Unii Europejskiej, czekają znaczące zmiany. W ramach unijnego rozporządzenia 2023/1113, znanego jako TFR (Transfer of Funds Regulation), wszystkie giełdy, kantory i inne podmioty pośredniczące w...
            

## ChatGPT każdy może zepsuć. Wystarczy wpisać odpowiednie frazy. Tłumaczymy, o co chodzi
 - [https://ithardware.pl/aktualnosci/chatgpt_halucynacje_sztuczna_inteligencja-37033.html](https://ithardware.pl/aktualnosci/chatgpt_halucynacje_sztuczna_inteligencja-37033.html)
 - RSS feed: $source
 - date published: 2024-12-04T09:17:43.528481+00:00

 <img src="https://ithardware.pl/artykuly/min/37033_1.jpg">                                                    
                                                                                
                                        ChatGPT to narzędzie AI, które potrafi odpowiedzieć na niemal każde pytanie. Jednak...
            

## Meta buduje najdłuższy kabel podmorski świata. Firma inwestuje potężną kwotę
 - [https://ithardware.pl/aktualnosci/meta_buduje_najdluzszy_kabel_podmorski_swiata_firma_inwestuje_potezna_kwote-36975.html](https://ithardware.pl/aktualnosci/meta_buduje_najdluzszy_kabel_podmorski_swiata_firma_inwestuje_potezna_kwote-36975.html)
 - RSS feed: $source
 - date published: 2024-12-04T09:17:43.445556+00:00

 <img src="https://ithardware.pl/artykuly/min/36975_1.jpg">            W dobie rosnących zagrożeń związanych z sabotażem podmorskich kabli, technologiczni giganci nie tylko nie rezygnują z ich budowy, ale wręcz zwiększają inwestycje w tę krytyczną infrastrukturę. Meta, właściciel takich platform jak Facebook,...
            

## Chcecie grać na maksymalnych ustawieniach w Indiana Jones i Wielki Krąg? Potrzebujecie RTX 4090
 - [https://ithardware.pl/aktualnosci/chcecie_grac_na_maksymalnych_ustawieniach_w_indiana_jones_i_wielki_krag_potrzebujecie_rtx_4090-37032.html](https://ithardware.pl/aktualnosci/chcecie_grac_na_maksymalnych_ustawieniach_w_indiana_jones_i_wielki_krag_potrzebujecie_rtx_4090-37032.html)
 - RSS feed: $source
 - date published: 2024-12-04T08:12:40.288022+00:00

 <img src="https://ithardware.pl/artykuly/min/37032_1.jpg">            Zbliżająca się premiera gry Indiana Jones i Wielki Krąg zaplanowana na 9 grudnia budzi duże emocje i jeśli planujecie grać w ten tytuł na PC, to potrzebować będzie naprawdę mocnego sprzętu. Bethesda i Machine Games ogłosiły właśnie...
            

## Chiny odpowiadają na sankcje USA. Zakazały eksportu niektórych metali
 - [https://ithardware.pl/aktualnosci/chiny_odpowiadaja_na_sankcje_usa_zakazaly_eksportu_niektorych_metali-37030.html](https://ithardware.pl/aktualnosci/chiny_odpowiadaja_na_sankcje_usa_zakazaly_eksportu_niektorych_metali-37030.html)
 - RSS feed: $source
 - date published: 2024-12-04T07:07:39.180100+00:00

 <img src="https://ithardware.pl/artykuly/min/37030_1.jpg">            Chiny oficjalnie wstrzymały eksport galu, germanu i antymonu do Stan&oacute;w Zjednoczonych. W rzeczywistości eksport galu i germanu został zatrzymany już w październiku, a dostawy antymonu spadły o 97% od września. Decyzja Pekinu zapadła dzień...
            

## Miał być hit na miarę Call of Duty, tymczasem Ubisoft zamyka XDefiant pół roku po premierze
 - [https://ithardware.pl/aktualnosci/mial_byc_hit_na_miare_call_of_duty_tymczasem_ubisoft_zamyka_xdefiant_pol_roku_po_premierze-37031.html](https://ithardware.pl/aktualnosci/mial_byc_hit_na_miare_call_of_duty_tymczasem_ubisoft_zamyka_xdefiant_pol_roku_po_premierze-37031.html)
 - RSS feed: $source
 - date published: 2024-12-04T07:07:38.891645+00:00

 <img src="https://ithardware.pl/artykuly/min/37031_1.jpg">            W 2021 roku Ubisoft zapowiedział XDefiant, darmową grę inspirowaną klasycznymi strzelankami. Po licznych op&oacute;źnieniach tytuł trafił na rynek w maju tego roku, zdobywając na starcie spore grono graczy, zapewniając firmie udany początek...
            

