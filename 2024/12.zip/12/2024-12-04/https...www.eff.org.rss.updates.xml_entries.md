# Source:Electronic Frontier Foundation, URL:https://www.eff.org/rss/updates.xml, language:en

## Location Tracking Tools Endanger Abortion Access. Lawmakers Must Act Now. 
 - [https://www.eff.org/deeplinks/2024/12/location-tracking-tools-endanger-abortion-access-lawmakers-must-act-now](https://www.eff.org/deeplinks/2024/12/location-tracking-tools-endanger-abortion-access-lawmakers-must-act-now)
 - RSS feed: $source
 - date published: 2024-12-04T22:06:38+00:00

<div class="field field--name-body field--type-text-with-summary field--label-hidden"><div class="field__items"><div class="field__item even"><p><span>EFF wrote recently </span><a href="https://www.eff.org/deeplinks/2024/11/creators-police-location-tracking-tool-arent-vetting-buyers-heres-how-protect"><span>about Locate X</span></a><span>, a deeply troubling location tracking tool that allows users to see the precise whereabouts of individuals based on the locations of their smartphone devices. Developed and sold by the data surveillance company Babel Street, Locate X collects smartphone location data from a variety of sources and collates that data into an easy-to-use tool to track devices. The tool features a navigable map with red dots, each representing an individual device. Users can then follow the location of specific devices as they move about the map.</span></p>
<p><span>Locate X–and </span><a href="https://www.eff.org/press/releases/data-broker-helps-police-see-everywhere-y

