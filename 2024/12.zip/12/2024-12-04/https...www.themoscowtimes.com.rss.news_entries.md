# Source:The Moscow Times, URL:https://www.themoscowtimes.com/rss/news, language:en-us

## Russia Arrests 4 Over Deadly Crocus City Hall Attack – Reports
 - [https://www.themoscowtimes.com/2024/12/05/russia-arrests-4-over-deadly-crocus-city-hall-attack-reports-a87230](https://www.themoscowtimes.com/2024/12/05/russia-arrests-4-over-deadly-crocus-city-hall-attack-reports-a87230)
 - RSS feed: $source
 - date published: 2024-12-04T22:18:54.676604+00:00


								The men were accused of helping Batyr Kulayev, who allegedly provided weapons to the gunmen, flee.			

## Russian FM Lavrov to Visit Malta in First EU Trip Since 2021
 - [https://www.themoscowtimes.com/2024/12/04/russian-fm-lavrov-to-visit-malta-in-first-eu-trip-since-2021-a87231](https://www.themoscowtimes.com/2024/12/04/russian-fm-lavrov-to-visit-malta-in-first-eu-trip-since-2021-a87231)
 - RSS feed: $source
 - date published: 2024-12-04T16:53:47.655333+00:00


								Lavrov will visit Malta for an OSCE summit, but MFA spokeswoman Maria Zakharova had her own visa to attend “annulled.” 			

## Anti-War Russians Targeted by FSB’s Spy Software – NGO
 - [https://www.themoscowtimes.com/2024/12/04/anti-war-russians-targeted-by-fsbs-spy-software-ngo-a87228](https://www.themoscowtimes.com/2024/12/04/anti-war-russians-targeted-by-fsbs-spy-software-ngo-a87228)
 - RSS feed: $source
 - date published: 2024-12-04T15:48:49.814332+00:00


								The program allows the FSB to record a device’s screen and steal data from third-party apps, among other things.			

## Russians’ Cash Savings Reach All-Time Low – VTB
 - [https://www.themoscowtimes.com/2024/12/04/russians-cash-savings-reach-all-time-low-vtb-a87227](https://www.themoscowtimes.com/2024/12/04/russians-cash-savings-reach-all-time-low-vtb-a87227)
 - RSS feed: $source
 - date published: 2024-12-04T13:39:00.957355+00:00


								Gorshkov also said that high interest rates would result in Russians transferring around 350 billion rubles of their cash savings into banks this year. 			

## Ukraine Says Mayor Jailed by Russia Died by Torture

 - [https://www.themoscowtimes.com/2024/12/04/ukraine-says-mayor-jailed-by-russia-died-by-torture-a87226](https://www.themoscowtimes.com/2024/12/04/ukraine-says-mayor-jailed-by-russia-died-by-torture-a87226)
 - RSS feed: $source
 - date published: 2024-12-04T12:33:58.243794+00:00


								Zaporizhzhia governor Ivan Federov called Matveyev a “true patriot,” who, “did not leave the city or the people, and did everything to ensure the life of the community.”			

## Caught in Riots, Georgia’s Protesters Say They Must Choose Between Europe and Russia
 - [https://www.themoscowtimes.com/2024/12/04/caught-in-riots-georgias-protesters-say-they-must-choose-between-europe-and-russia-a87221](https://www.themoscowtimes.com/2024/12/04/caught-in-riots-georgias-protesters-say-they-must-choose-between-europe-and-russia-a87221)
 - RSS feed: $source
 - date published: 2024-12-04T12:33:58.085952+00:00


								For pro-EU Georgians — including those who left Russia after the invasion of Ukraine — the prospect of creeping Kremlin influence is a serious concern.			

## Ukraine’s Kherson Targeted in Months-Long Russian Drone Campaign – FT
 - [https://www.themoscowtimes.com/2024/12/04/ukraines-kherson-targeted-in-months-long-russian-drone-campaign-ft-a87223](https://www.themoscowtimes.com/2024/12/04/ukraines-kherson-targeted-in-months-long-russian-drone-campaign-ft-a87223)
 - RSS feed: $source
 - date published: 2024-12-04T11:28:47.582459+00:00


								Ukrainian officials believe the drone attacks are part of Russia’s pressure campaign ahead of Donald Trump’s inauguration and preparations for a potential push across the Dnipro river.			

## Moscow Says Russia, Iran, Turkey in ‘Close Contact’ Over Syria Conflict
 - [https://www.themoscowtimes.com/2024/12/04/moscow-says-russia-iran-turkey-in-close-contact-over-syria-conflict-a87225](https://www.themoscowtimes.com/2024/12/04/moscow-says-russia-iran-turkey-in-close-contact-over-syria-conflict-a87225)
 - RSS feed: $source
 - date published: 2024-12-04T11:28:46.867744+00:00


								The Foreign Ministry's spokeswoman said Russia was "actively working with international partners to ensure the rapid stabilization of the situation in Syria."			

## Russia’s Central Bank Governor Says Likely Rate Hike ’Not Predetermined’
 - [https://www.themoscowtimes.com/2024/12/04/russias-central-bank-governor-says-likely-rate-hike-not-predetermined-a87224](https://www.themoscowtimes.com/2024/12/04/russias-central-bank-governor-says-likely-rate-hike-not-predetermined-a87224)
 - RSS feed: $source
 - date published: 2024-12-04T11:28:46.091012+00:00


								The statement comes amid rumors that the bank could raise the key rate to 22-23% at its Dec. 20 meeting.			

## Tucker Carlson Interviews Russian FM Lavrov in Moscow
 - [https://www.themoscowtimes.com/2024/12/04/tucker-carlson-interviews-russian-fm-lavrov-in-moscow-a87222](https://www.themoscowtimes.com/2024/12/04/tucker-carlson-interviews-russian-fm-lavrov-in-moscow-a87222)
 - RSS feed: $source
 - date published: 2024-12-04T10:23:32.863548+00:00


								Carlson said in a video on X that the U.S. was already in a “hot war” with Russia, and “closer to nuclear war than any time in history.”			

