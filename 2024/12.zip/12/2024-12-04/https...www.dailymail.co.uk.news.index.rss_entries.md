# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Ally Langdon exposes major problem with Commonwealth Bank's backflip - and why millions will still be charged for cash
 - [https://www.dailymail.co.uk/news/article-14158773/Ally-Langdon-Commonwealth-Bank-cash-fee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158773/Ally-Langdon-Commonwealth-Bank-cash-fee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T23:22:12+00:00

Ally Langdon has refused to back down on criticising the Commonwealth Bank's cash withdrawal fee.

## United Airlines 'racist Karen' tells her side of the story as she's unmasked as California real estate agent
 - [https://www.dailymail.co.uk/news/article-14157297/united-airlines-arlene-bunch-racist-comments-Pervez-Taufiq.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157297/united-airlines-arlene-bunch-racist-comments-Pervez-Taufiq.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T23:21:27+00:00

Arlene Bunch, 64, has been unmasked after being filmed unleashing a hateful tirade against photographer Pervez Taufiq, his wife, and their three children in Los Angeles last week.

## The cauldron of the Middle East is roiling with a fury unseen in years. Left unchecked, it spells chaos for us all, writes MARK ALMOND
 - [https://www.dailymail.co.uk/news/article-14159283/Middle-East-unchecked-spells-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14159283/Middle-East-unchecked-spells-chaos.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T23:16:43+00:00

MARK ALMOND: Amid the chaos of Syria 's civil war, which has exploded back on to the global stage in the past week, there remains a chilling truth.

## Biden aides mulling preemptive pardons for Dr. Fauci, Liz Cheney and host of Trump critics in his line of fire
 - [https://www.dailymail.co.uk/news/article-14159181/biden-aides-mulling-preemptive-pardons-anthony-fauci-liz-cheney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14159181/biden-aides-mulling-preemptive-pardons-anthony-fauci-liz-cheney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T23:15:49+00:00

Aides of President Joe Biden are debating whether the president should issue preemptive pardons for figures President-elect Donald Trump has named as his political enemies.

## RUSSELL FINDLAY: Scotland can't afford another 'pay more, get less' Budget that punishes aspiration
 - [https://www.dailymail.co.uk/news/article-14158727/RUSSELL-FINDLAY-Scotland-afford-pay-Budget-punishes-aspiration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158727/RUSSELL-FINDLAY-Scotland-afford-pay-Budget-punishes-aspiration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T23:15:00+00:00

Taxpayers are yet again picking up the bill for the SNP's mistakes after another Budget where the Nationalists will continue to make workers and businesses in Scotland pay more and get less.

## More broken promises on the NHS, more cash on benefits, more council tax rises - and a risible 'tax cut' worth 30p a WEEK. Swinney's Christmas present to Scotland?
 - [https://www.dailymail.co.uk/news/article-14158897/More-broken-promises-NHS-cash-benefits-council-tax-rises-risible-tax-cut-worth-30p-WEEK-Swinneys-Christmas-present-Scotland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158897/More-broken-promises-NHS-cash-benefits-council-tax-rises-risible-tax-cut-worth-30p-WEEK-Swinneys-Christmas-present-Scotland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T23:14:20+00:00

The SNP's Budget has been slammed as it emerged tens of thousands of Scots will be dragged into paying higher rates of income tax, while the benefits bill will soar by £800million.

## Foreign nationals are told to use expired documents to prove their right to live and work in Britain amid another Home Office IT fiasco
 - [https://www.dailymail.co.uk/news/article-14159259/foreign-nationals-use-expired-documents-prove-right-work-britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14159259/foreign-nationals-use-expired-documents-prove-right-work-britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T23:02:10+00:00

Foreign nationals have been told to use expired documents to prove their right to live and work in Britain, in yet another Home Office IT fiasco.

## Trump's FBI pick Kash Patel goes scorched earth on MSNBC guest in wild letter
 - [https://www.dailymail.co.uk/news/article-14158977/trump-fbi-kash-patel-legal-threat-msnbc-olivia-troye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158977/trump-fbi-kash-patel-legal-threat-msnbc-olivia-troye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:52:21+00:00

Donald Trump's pick for FBI Director Kash Patel threatened legal action against MSNBC commentator Olivia Troye after she accused him of lying about intelligence and operations.

## SCOTS BUDGET: At a glance
 - [https://www.dailymail.co.uk/news/article-14158911/SCOTS-BUDGET-glance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158911/SCOTS-BUDGET-glance.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:50:52+00:00

The thresholds for the 42p higher rate of income tax, the 45p advanced rate and the 48p top rate will all be frozen, which will draw tens of thousands more workers into paying them.

## Mexico announces record fentanyl bust days after Trump threatened tariffs over drugs crossing border
 - [https://www.dailymail.co.uk/news/article-14158833/mexico-fentanyl-seizure-trump-tariffs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158833/mexico-fentanyl-seizure-trump-tariffs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:39:09+00:00

Mexico seized the largest shipments of fentanyl in history, just days after President-elect Trump a 25 percent tax on products from Mexico due in part to the deadly drug crossing the border.

## Josh Hawley scolds Spirit Airlines chief in blistering rant about company's hidden fees targeting 'suckers'
 - [https://www.dailymail.co.uk/news/article-14158893/josh-hawley-spirit-airlines-baggage-fees-senate-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158893/josh-hawley-spirit-airlines-baggage-fees-senate-hearing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:34:09+00:00

Missouri Republican Sen. Josh Hawley unleashed on major airline CEOs at a hearing regarding hidden fees on Wednesday, ripping them to shreds for unfairly charging customers.

## 'If we fail to act, we risk falling further behind': Veterans minister who warned British Army will be wiped out in 'six months to a year' if drawn into a large scale war is backed by top generals who pile pressure on PM over defence spending
 - [https://www.dailymail.co.uk/news/article-14159047/Veterans-minister-British-Army-wiped-six-months-PM-defence-spending.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14159047/Veterans-minister-British-Army-wiped-six-months-PM-defence-spending.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:13:42+00:00

Al Carns' admission about the country's lack of readiness for war piled pressure onto Sir Keir Starmer over defence spending.

## Chicago residents unload on 'most hated' mayor Brandon Johnson for crazy migrant spending
 - [https://www.dailymail.co.uk/news/article-14157225/Chicago-Mayor-Brandon-Johnson-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157225/Chicago-Mayor-Brandon-Johnson-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:12:55+00:00

Embattled Chicago Mayor Brandon Johnson faced furious residents at a town hall meeting over the migrant crisis as they called for Donald Trump to 'make an example' out of him.

## Oroville shooting: Police swoop on gunman at school in California
 - [https://www.dailymail.co.uk/news/article-14159139/police-active-shooter-feather-river-school-california.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14159139/police-active-shooter-feather-river-school-california.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:12:42+00:00

Feather River School of Seventh-Day Adventists was put on lockdown on Wednesday afternoon.

## The simple reason why Guinness is surging in popularity across America
 - [https://www.dailymail.co.uk/news/article-14157277/reason-guinness-surge-popularity-america-bars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157277/reason-guinness-surge-popularity-america-bars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:10:35+00:00

Guinness has significantly increased its popularity in the US over the past few years.

## Man driving a white van is hunted by police after a string of attempted child abductions in Melbourne
 - [https://www.dailymail.co.uk/news/article-14158979/kidnap-abduction-melbourne-man-white-van.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158979/kidnap-abduction-melbourne-man-white-van.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:09:14+00:00

Victoria Police have released a computer-generated image of a man they wish to speak to after an 11-year-old boy was approached by a stranger in a white van while walking home from school.

## Trump hasn't even started yet and his new cabinet is fast collapsing. But, warns ANDREW NEIL, the biggest (and inevitable) resignations are still to come...
 - [https://www.dailymail.co.uk/news/article-14158831/Hegseth-Trump-DeSantis-cabinet-ANDREW-NEIL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158831/Hegseth-Trump-DeSantis-cabinet-ANDREW-NEIL.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:05:27+00:00

It isn't even day one of the new administration, Donald Trump has yet to get back behind the Oval Office desk - but the revolving door is already working overtime.

## Inside the factions jostling for Donald Trump's ear at Mar-a-Lago
 - [https://www.dailymail.co.uk/news/article-14133315/factions-donald-trump-mar-lago-influence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14133315/factions-donald-trump-mar-lago-influence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:05:22+00:00

Donald Trump 's campaign team showed few signs of fracturing in the months ahead of Election Day. But since then tensions between competing factions have sometimes blown up in public.

## Holyrood, we have a problem - backlash as Highland spaceport is 'mothballed' after £15m public cash injection
 - [https://www.dailymail.co.uk/news/article-14158815/Holyrood-problem-Highland-spaceport-15m-public-cash-injection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158815/Holyrood-problem-Highland-spaceport-15m-public-cash-injection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:05:01+00:00

The future of a Scottish spaceport was in doubt last night after the firm behind it halted plans to launch rockets from the mainland.

## James Carville reveals who he really thinks is behind Trump's Cabinet picks: 'One person is driving this'
 - [https://www.dailymail.co.uk/news/article-14158469/james-carville-tucker-carlson-donald-trump-cabinet-picks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158469/james-carville-tucker-carlson-donald-trump-cabinet-picks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:04:29+00:00

Democratic strategist James Carville has a sneaking suspicion that his former colleague is behind President-elect Donald Trump's most audacious nominations.

## Target sends out terrifying robo-calls to warn customers who purchased recalled item
 - [https://www.dailymail.co.uk/news/article-14158823/target-recall-cucumbers-fda-salmonella.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158823/target-recall-cucumbers-fda-salmonella.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:04:05+00:00

A voicemail left by the company to one such buyer - obtained by DailyMail.com - offered a disclaimer about salmonella poisoning on Wednesday.

## Outback Wrangler Matt Wright banned from flying helicopters
 - [https://www.dailymail.co.uk/news/article-14159031/Outback-Wrangler-Matt-Wright-banned-flying-helicopters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14159031/Outback-Wrangler-Matt-Wright-banned-flying-helicopters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T22:01:38+00:00

Outback Wrangler Matt Wright has been banned from flying helicopters after The Civil Aviation Safety Authority cancelled his commercial pilot's licence.

## Drunk Tennessee Senator Ken Yager seen failing field sobriety test after hit-and-run crash
 - [https://www.dailymail.co.uk/news/article-14158599/drunk-tennessee-senator-ken-yager-hit-run-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158599/drunk-tennessee-senator-ken-yager-hit-run-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:52:08+00:00

Ken Yager, 77, was arrested on Tuesday after state troopers spotted his Ford Edge following a report that it had been involved in a hit-and-run with another vehicle on Georgia's Jekyll Island.

## Teenage passenger, 18, dead after 'stolen Toyota crashed into another car a during police chase': Two arrested over Rochdale smash
 - [https://www.dailymail.co.uk/news/article-14158983/Teenage-dead-stolen-Toyota-crashed-car-police-chase-arrested-Rochdale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158983/Teenage-dead-stolen-Toyota-crashed-car-police-chase-arrested-Rochdale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:50:52+00:00

The 18-year-old was tragically pronounced dead at the scene of the crash on Manchester Road, Rochdale, yesterday evening.

## Florida town divided after man shoots his neighbor's 'aggressive' Goldendoodle puppy
 - [https://www.dailymail.co.uk/news/article-14158777/florida-man-shoots-neighbor-goldendoodle-puppy-christopher-toledo-morales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158777/florida-man-shoots-neighbor-goldendoodle-puppy-christopher-toledo-morales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:45:40+00:00

A Florida community is left in outrage after one of their own 'senselessly and intentionally' shot a one-year-old Goldendoodle puppy, named Maui, leaving the animal in critical condition.

## Need for the High Court to sign off on every assisted death 'could be dropped amid fears of lengthy court backlogs'
 - [https://www.dailymail.co.uk/news/article-14158955/High-Court-sign-assisted-death-dropped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158955/High-Court-sign-assisted-death-dropped.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:44:06+00:00

The need for the High Court to sign off on every assisted death could be dropped amid fears of lengthy court backlogs, it has been suggested.

## America's Worst Mayor Tiffany Henyard has a MELTDOWN as entire town votes her out of one of her jobs
 - [https://www.dailymail.co.uk/news/article-14158713/tiffany-henyard-america-worst-mayor-town-vote-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158713/tiffany-henyard-america-worst-mayor-town-vote-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:43:29+00:00

Illinois Mayor Tiffany Henyard threw a massive fit on Tuesday night after she was voted out of one of her positions during an intense caucus meeting, after claiming she would be 'victorious'.

## Just Stop Oil vows to 'blockade' Parliament for weeks in major wave of protests this spring
 - [https://www.dailymail.co.uk/news/article-14158937/Just-Stop-Oil-block-Parliament-spring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158937/Just-Stop-Oil-block-Parliament-spring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:42:00+00:00

EXCLUSIVE: The eco-group, which has been less active in recent times after many of its leading members were jailed, claimed 'thousands and thousands' of activists would take part.

## Fury as DOZENS more reviews set to be launched by Labour next year as Ministers come under fire for setting up at least 67 since coming into office
 - [https://www.dailymail.co.uk/news/article-14158981/Fury-DOZENS-reviews-set-launched-Labour-year-Ministers-come-fire-setting-67-coming-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158981/Fury-DOZENS-reviews-set-launched-Labour-year-Ministers-come-fire-setting-67-coming-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:41:25+00:00

Ministers have come under fire this week for setting up at least 67 reviews, consultations and taskforces since coming into office.

## SCOTTISH DAILY MAIL COMMENT: A basket case of tax and spend profligacy, this woeful SNP Budget is a sure-fire blueprint for failure
 - [https://www.dailymail.co.uk/news/article-14158837/SCOTTISH-DAILY-MAIL-COMMENT-basket-case-tax-spend-profligacy-woeful-SNP-Budget-sure-fire-blueprint-failure.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158837/SCOTTISH-DAILY-MAIL-COMMENT-basket-case-tax-spend-profligacy-woeful-SNP-Budget-sure-fire-blueprint-failure.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:37:46+00:00

It promised the earth but Shona Robison's threadbare Budget delivered nothing of substance.

## JOHN MACLEOD: When it comes to modern art, I'm with Miss Jean Brodie: 'For those who like that sort of thing, that is the sort of thing they like'
 - [https://www.dailymail.co.uk/news/article-14158787/JOHN-MACLEOD-comes-modern-art-Im-Miss-Jean-Brodie-like-sort-thing-sort-thing-like.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158787/JOHN-MACLEOD-comes-modern-art-Im-Miss-Jean-Brodie-like-sort-thing-sort-thing-like.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:36:58+00:00

Jasleen Kaur, a 38 year-old Glaswegian, is this year's winner of the Turner Prize, Britain's foremost - and absurdly hyped - prize for modern art. It's difficult to do justice to Kaur's creation.

## Now Poundland's selling flats... but you'll need 85,000 £1s to buy one
 - [https://www.dailymail.co.uk/news/article-14158849/Now-Poundlands-selling-flats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158849/Now-Poundlands-selling-flats.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:36:32+00:00

It has long been beloved by bargain hunters for its slogan 'Everything's a pound'. Now Poundland is hoping to attract shoppers of a different kind after putting its first-ever apartments up for sale.

## Richard Osman, his Thursday Murder Club... and an eight-year war of words between Scots librarians!
 - [https://www.dailymail.co.uk/news/article-14158871/Richard-Osman-Thursday-Murder-Club-eight-year-war-words-Scots-librarians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158871/Richard-Osman-Thursday-Murder-Club-eight-year-war-words-Scots-librarians.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:27:23+00:00

It is a spat that has seen two of Scotland's most remote libraries rib each other over their services for eight years.

## Rural Labour MPs face furious backlash after supporting inheritance tax raid labelled 'the death of family farms'
 - [https://www.dailymail.co.uk/news/article-14158895/Rural-Labour-MPs-face-furious-backlash-supporting-inheritance-tax-raid-labelled-death-family-farms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158895/Rural-Labour-MPs-face-furious-backlash-supporting-inheritance-tax-raid-labelled-death-family-farms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:26:54+00:00

In a blow to thousands of countryside voters, Sir Keir Starmer's party backed the so-called 'family farm tax' - which will hammer those who want to pass on their businesses to future generations.

## It sounds like a movie script: The Ukrainian orphan stolen away by Russian troops and fostered by a woman with close ties to the Kremlin. Miraculously, he got away - 24 hours before being conscripted to fight AGAINST his own people, writes IAN BIRRELL
 - [https://www.dailymail.co.uk/news/article-14158931/Ukrainian-orphan-stolen-Russian-troops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158931/Ukrainian-orphan-stolen-Russian-troops.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:21:21+00:00

His story sounds like a film script: a child who ends up in an orphanage after losing his sickly mother and gangster father when barely out of infancy.

## Vancouver stabbing leaves 'multiple' injured in city's downtown
 - [https://www.dailymail.co.uk/news/article-14158839/Vancouver-stabbings-Multiple-people-injured-citys-downtown-say-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158839/Vancouver-stabbings-Multiple-people-injured-citys-downtown-say-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:10:31+00:00

Vancouver Police said officers were responding to a 'violent incident' near Robson and Hamilton Streets in the city's downtown just after 3pm on Wednesday.

## Trump reveals HE forced Cabinet nominee out in scorched earth attack on the media and critics
 - [https://www.dailymail.co.uk/news/article-14158623/trump-forced-dea-nominee-chad-chronister-withdrawal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158623/trump-forced-dea-nominee-chad-chronister-withdrawal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:10:28+00:00

Hours after his pick to run the D.E.A. Chad Chronister announced his withdrawal without explanation, Trump wrote that 'I pulled him out' and referenced his arrest of a paster during COVID.

## AOC eyes powerful Democratic role as speculation swirls she will run for president in 2028
 - [https://www.dailymail.co.uk/news/article-14158049/aoc-house-oversight-committee-2028-speculation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158049/aoc-house-oversight-committee-2028-speculation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:07:30+00:00

AOC said she is interested in becoming the top Democrat on the powerful House Oversight Committee amid speculation over her 2028 plans.

## Pamela Anderson's bare-faced shtick is an ugly lie... I know this desperate Double D-lister's real beauty secrets, writes PAULA FROELICH
 - [https://www.dailymail.co.uk/news/article-14158575/pamela-anderson-makeup-PAULA-FROELICH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158575/pamela-anderson-makeup-PAULA-FROELICH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:07:17+00:00

A cooing chorus of oohs and ahhs wafted up from a gawking crowd in lower Manhattan on Monday as former Baywatch babe Pamela Anderson strutted onto the red carpet.

## Whoopi Goldberg and Charlamagne Tha God clash on air in heated disagreement over Democrat hypocrisy
 - [https://www.dailymail.co.uk/news/article-14158657/whoopi-goldberg-charlamagne-god-clash-air-democrat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158657/whoopi-goldberg-charlamagne-god-clash-air-democrat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:06:32+00:00

Tensions flared between The View 's Whoopi Goldberg and guest Charlamagne tha God about President Joe Biden's decision to pardon his son, Hunter Biden .

## Perth, Adelaide and Brisbane house prices expected to soar in 2025
 - [https://www.dailymail.co.uk/news/article-14158643/Perth-Adelaide-Brisbane-house-prices-expected-soar-2025.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158643/Perth-Adelaide-Brisbane-house-prices-expected-soar-2025.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:04:56+00:00

Perth, Adelaide and Brisbane are predicted to experience the biggest property price rises in 2025.

## Which food apps have the lowest and highest fees? Takeout delivery charges compared
 - [https://www.dailymail.co.uk/news/article-14158125/food-apps-cheapest-lowest-fees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158125/food-apps-cheapest-lowest-fees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:04:44+00:00

Millions of fast-food restaurant customers nationwide may be unaware of how much food delivery apps are marking up the cost of their dinner.

## None for the road: Record number of low and no-alcohol pints will be sold in the UK this year, figures suggest
 - [https://www.dailymail.co.uk/news/article-14158853/Record-low-alcohol-pints-sold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158853/Record-low-alcohol-pints-sold.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T21:04:16+00:00

A record number of low and no-alcohol pints will be sold in the UK this year, new figures suggest.

## Pete Hegseth promises to give up alcohol as defense secretary as binge drinking claims threaten nomination
 - [https://www.dailymail.co.uk/news/article-14158473/pete-hegseth-binge-drinking-claims-threaten-defense-nomination.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158473/pete-hegseth-binge-drinking-claims-threaten-defense-nomination.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:56:46+00:00

Defense Secretary nominee Pete Hegseth vowed not to drink if he is confirmed to the Pentagon's top job after a deluge of negative stories highlighting his binging threaten to tank his bid.

## STEPHEN DAISLEY: It'll be a new Christmas miracle if they keep NHS promise
 - [https://www.dailymail.co.uk/news/article-14158693/STEPHEN-DAISLEY-Itll-new-Christmas-miracle-NHS-promise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158693/STEPHEN-DAISLEY-Itll-new-Christmas-miracle-NHS-promise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:50:51+00:00

The Finance Secretary had made a list and checked it twice before ploughing money into those things her party's voters consider nice. Shona Robison was going to town.

## A budget utterly devoid of economic ambition
 - [https://www.dailymail.co.uk/news/article-14158703/A-budget-utterly-devoid-economic-ambition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158703/A-budget-utterly-devoid-economic-ambition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:49:40+00:00

Budget of Hope? This is simply another tax and spend jamboree from the SNP. The only difference between Robison's budget and that of Chancellor Rachel Reeves' is that the SNP lacks ambition.

## The Balmoral baby box, yours for £186 (silver spoon not included)
 - [https://www.dailymail.co.uk/news/article-14158797/The-Balmoral-baby-box-186-silver-spoon-not-included.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158797/The-Balmoral-baby-box-186-silver-spoon-not-included.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:44:17+00:00

Parents are being given the chance to buy quality cashmere bonnets and booties for newborn babies from the King's royal retreat in Aberdeenshire.

## Catholic school principal's disgusting behavior after boy was raped by priest during wrestling practice
 - [https://www.dailymail.co.uk/news/article-14158207/catholic-school-principal-lawrence-hecker-rape-louisiana.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158207/catholic-school-principal-lawrence-hecker-rape-louisiana.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:38:32+00:00

The anonymous former student at St John Vianney Prep in New Orleans said he was 16 when he was raped in 1975 by Lawrence Hecker, who was around 44 at the time.

## Trans row Children in Need boss lashes out at LGBT charity
 - [https://www.dailymail.co.uk/news/article-14158753/Trans-row-Children-Need-boss-LGBT-charity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158753/Trans-row-Children-Need-boss-LGBT-charity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:30:47+00:00

The former chair of BBC Children in Need has claimed she was 'thrown under the bus' for being a 'whistleblower' on grants given to a transgender youth charity.

## Supreme Court justices hint at where they stand on ban for transgender medical care for children
 - [https://www.dailymail.co.uk/news/article-14158689/supreme-court-transgender-child-care-tennessee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158689/supreme-court-transgender-child-care-tennessee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:30:45+00:00

Supreme Court justices on Wednesday indicated they are leaning toward upholding a controversial Tennessee law denying transgender children medical treatment. 

## Horrifying update in hunt for grandma, 64, who fell through sinkhole while searching for cat
 - [https://www.dailymail.co.uk/news/article-14158511/Horrifying-update-hunt-grandma-fell-sinkhole-searching-cat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158511/Horrifying-update-hunt-grandma-fell-sinkhole-searching-cat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:28:49+00:00

Police have issued a horrifying update in the hunt for the missing Pennsylvania grandmother, Elizabeth Pollard, 64, who fell into a massive sinkhole on Tuesday.

## Neo-Nazi killer Anders Breivik who applied for parole just 13 years after island massacre left 77 dead WILL remain behind bars - despite court noting 'positive' changes
 - [https://www.dailymail.co.uk/news/article-14158651/Neo-Nazi-killer-Anders-Breivik-applied-parole-just-13-years-island-massacre-left-77-dead-remain-bars-despite-court-noting-positive-changes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158651/Neo-Nazi-killer-Anders-Breivik-applied-parole-just-13-years-island-massacre-left-77-dead-remain-bars-despite-court-noting-positive-changes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:02:51+00:00

A Norwegian court Wednesday rejected parole for the right-wing extremist Anders Behring Breivik, 45, with his lawyer claiming it was 'not a surprise'.

## Building firm giving ex-cons a second chance: Construction company teams with probation service to give former prisoners jobs on their release from jail
 - [https://www.dailymail.co.uk/news/article-14158453/Building-firm-giving-ex-cons-second-chance-Construction-company-teams-probation-service-former-prisoners-jobs-release-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158453/Building-firm-giving-ex-cons-second-chance-Construction-company-teams-probation-service-former-prisoners-jobs-release-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T20:00:46+00:00

The Second Chance Scheme was launched by property developer Legacie and is aimed at helping inmates rebuild their lives after serving their sentences.

## Chilling actions of UnitedHealthcare CEO gunman revealed by witness who 'saw the whole thing'
 - [https://www.dailymail.co.uk/news/article-14158519/Brian-Thompson-witness-shooting-unitedhealthcare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158519/Brian-Thompson-witness-shooting-unitedhealthcare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:59:39+00:00

A bystander to the early morning assassination of UnitedHealthcare CEO Brian Thompson said he feared he would also be shot as he witnessed the shooter and 'saw the whole thing.'

## Shocking moment police officer throws delivery worker off BRIDGE in Brazil during traffic stop
 - [https://www.dailymail.co.uk/news/article-14157533/brazil-police-officer-throws-worker-sao-paulo-bridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157533/brazil-police-officer-throws-worker-sao-paulo-bridge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:55:03+00:00

Footage of the encounter, which was leaked on social media, captured the shocking act in São Paulo, sending shockwaves through the nation.

## UnitedHealthcare employees rocked by assassination of CEO Brian Thompson at investor conference
 - [https://www.dailymail.co.uk/news/article-14158493/unitedhealthcare-employees-react-shot-dead-ceo-brian-thompson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158493/unitedhealthcare-employees-react-shot-dead-ceo-brian-thompson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:52:42+00:00

UnitedHealthcare employees are shaken after CEO Brian Thompson was shot dead outside Manhattan's Hilton Hotel.

## Former Children In Need chairwoman Rosie Millard says she was 'thrown under the bus' for blowing whistle on £460,000 grants to scandal-hit trans charity
 - [https://www.dailymail.co.uk/news/article-14157895/Former-Children-Need-chairwoman-Rosie-Millard-says-thrown-bus-blowing-whistle-460-000-grants-scandal-hit-trans-charity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157895/Former-Children-Need-chairwoman-Rosie-Millard-says-thrown-bus-blowing-whistle-460-000-grants-scandal-hit-trans-charity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:48:50+00:00

Rosie Millard stepped down from her role in November, saying she did not feel she had the full support of her board after she demanded Children in Need stopped funding LGBT Youth Scotland.

## Liberal lawyer's wild claims about transgender toddlers leave CNN's Jake Tapper shocked
 - [https://www.dailymail.co.uk/news/article-14158439/liberal-lawyer-transgender-toddlers-cnn-jake-tapper.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158439/liberal-lawyer-transgender-toddlers-cnn-jake-tapper.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:48:03+00:00

Chase Strangio, 42, a transgender American Civil Liberties Union attorney shocked CNN 's Jake Tapper with his wild claim as he appeared on the popular network on Tuesday.

## South Carolina students who 'bullied teen Kelaia Turner into a suicide bid' accused of visiting her hospital for vile reason
 - [https://www.dailymail.co.uk/news/article-14158135/South-Carolina-Kelaia-Turner-suicide-bully-hospital-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158135/South-Carolina-Kelaia-Turner-suicide-bully-hospital-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:37:48+00:00

Two school bullies visited a South Carolina schoolgirl in hospital where she was recovering from a suicide attempt, her family claim.

## Hannah Kobayashi's Venmo inundated with donations from strangers telling her to 'enjoy Mexico'
 - [https://www.dailymail.co.uk/news/article-14158221/hannah-kobayashi-venmo-donation-mexico-missing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158221/hannah-kobayashi-venmo-donation-mexico-missing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:37:28+00:00

Hawaiian woman Hannah Kobayashi's Venmo has been inundated with donations from strangers telling her to 'enjoy Mexico' after she was declared 'voluntarily missing.'

## Hannah Kobayashi twist as family and cops address 'deeply concerning' border crossing
 - [https://www.dailymail.co.uk/news/article-14154407/hannah-kobayashi-seen-missing-mexico-tijuana.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154407/hannah-kobayashi-seen-missing-mexico-tijuana.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:32:39+00:00

The 30-year-old was last seen crossing the United States-Mexico border into Tijuana, where hundreds of people have been murdered this year and Americans are at risk of being kidnapped.

## Conman who raked in thousands helping speeding drivers dodge fines by framing innocent people is jailed for more than three years
 - [https://www.dailymail.co.uk/news/article-14158311/Conman-raked-thousands-helping-speeding-drivers-dodge-fines-framing-innocent-people-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158311/Conman-raked-thousands-helping-speeding-drivers-dodge-fines-framing-innocent-people-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:22:16+00:00

Khuram Yaqoob, 35, was jailed alongside 18 drivers who paid him hundreds of pounds to avoid prosecution, including a secondary school teacher.

## Grim discovery made in hunt for missing Wisconsin woman four years after she vanished
 - [https://www.dailymail.co.uk/news/article-14158077/grim-discovery-wisconsin-cassandra-ayon-missing-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158077/grim-discovery-wisconsin-cassandra-ayon-missing-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:09:54+00:00

Cassandra Ayon, 27, went missing on October 3, 2020, in Unity after hanging out with friends following a late shift at work.

## The glamorous Russian socialite and influencer who led double life as crypto laundering kingpin before multi-billion-pound network was brought down following arrest of courier on the M1 with £250K in cash
 - [https://www.dailymail.co.uk/news/article-14158197/The-glamorous-Russian-socialite-influencer-crypto-laundering-kingpin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158197/The-glamorous-Russian-socialite-influencer-crypto-laundering-kingpin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T19:00:07+00:00

Zhdanova's double life, seemingly thriving as an entrepreneur opening hotels across Moscow while running a multi-billion-pound Russian network, was exposed today.

## Flogged for refusing to wear hijab: Iranian woman who defied strict Islamic dress code shows off horrifying injuries after being lashed by Iranian guards
 - [https://www.dailymail.co.uk/news/article-14158337/Flogged-hijab-Iranian-woman-defied-strict-Islamic-dress-code.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158337/Flogged-hijab-Iranian-woman-defied-strict-Islamic-dress-code.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:59:53+00:00

The harrowing clip, which was shared on X by Iranian journalist and activist Masih Alinejad, shows an unnamed Tehran woman in her underwear showing her injuries.

## Sweaty sugar heir slurs as he's arrested for 'beating up girlfriend because of his hatred for gays'
 - [https://www.dailymail.co.uk/news/article-14158171/alexander-nicholas-fanjul-sugar-heir-arrested-beating-gay-couple.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158171/alexander-nicholas-fanjul-sugar-heir-arrested-beating-gay-couple.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:57:39+00:00

An heir to a sugar company was arrested and later sentenced for beating and choking his girlfriend. For the first time, body camera footage of the dramatic showdown is publicly available.

## See inside Robert Redford's breathtaking coastal California home movie icon has just listed for $4.15m
 - [https://www.dailymail.co.uk/news/article-14157257/inside-robert-redford-california-coastal-home-listed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157257/inside-robert-redford-california-coastal-home-listed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:55:13+00:00

See inside actor and filmmaker Robert Redford's $4.5 million coastal home in San Francisco - with breathtaking views it's described as a 'private coastal heaven'.

## Pete Hegseth reveals Trump's message to him on Megyn Kelly and claims he'll 'never back down'
 - [https://www.dailymail.co.uk/news/article-14158401/Pete-Hegseth-Trump-allegations-Megyn-Kelly-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158401/Pete-Hegseth-Trump-allegations-Megyn-Kelly-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:53:35+00:00

Pete Hegseth admitted that there is some truth to the damning reports that have cast doubts over whether he will remain Donald Trump's pick to lead the Defense Department.

## Prince Harry secures popstar headliner for the Invictus Games opening night - and it's his A-list neighbour 
 - [https://www.dailymail.co.uk/news/article-14158433/prince-harry-popstar-headliner-invictus-games-opening-night.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158433/prince-harry-popstar-headliner-invictus-games-opening-night.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:52:19+00:00

Prince Harry has secured the services of his neighbour to sing at the opening night of his Invictus Games

## Bull laid out farmer when it escaped and went on the rampage on its way to the abattoir before being shot dead
 - [https://www.dailymail.co.uk/news/article-14158325/Bull-farmer-escaped-rampage-abattoir-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158325/Bull-farmer-escaped-rampage-abattoir-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:49:30+00:00

Dennis Whitmore, 76, had been attempting to stop the 800kg (126st) beast when it sent him flying in a farmyard and ran off down a country road.

## Tesco issues urgent recall for chicken party food favourite because it is unsafe to eat and could lead to risk to health
 - [https://www.dailymail.co.uk/news/article-14158265/Tesco-urgent-recall-chicken-party-food-favourite-unsafe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158265/Tesco-urgent-recall-chicken-party-food-favourite-unsafe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:48:52+00:00

Tesco has issued an urgent recall on its 280g eight-pack of Chicken Tsukune Skewers, which have been deemed 'unsafe to eat' after a batch of packages were incorrectly dated.

## Woman raped after complete stranger forces his way into her home in horrifying attack - as police release e-fit and CCTV of man
 - [https://www.dailymail.co.uk/news/article-14157963/Woman-raped-stranger-forces-home-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157963/Woman-raped-stranger-forces-home-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:29:03+00:00

The incident happened at an address in Milward Crescent, in Hastings, shortly before 7pm on Saturday when the man - who was not known to the victim - called at the house.

## What 'Top Gun' Gov. Ron DeSantis would target first in the military if he replaces Pete Hegseth... as surprise Democrat offers their support
 - [https://www.dailymail.co.uk/news/article-14158185/ron-desantis-pentagon-chief-pete-hegseth-john-fetterman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158185/ron-desantis-pentagon-chief-pete-hegseth-john-fetterman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:26:31+00:00

Florida Gov. Ron DeSantis is reportedly under consideration for the secretary of Defense gig now that Fox News host Pete Hegseth's nomination is under fire.

## Glamorous Florida woman sentenced to 20 years in prison for running $200M animal rescue Ponzi scheme
 - [https://www.dailymail.co.uk/news/article-14157695/florida-mj-capital-johanna-garcia-ponzi-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157695/florida-mj-capital-johanna-garcia-ponzi-scheme.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:21:45+00:00

South Florida's glamorous 'Mother Theresa', Johanna Garcia, has been sentenced to 20 years in prison after leading a nearly $200 million Ponzi scheme that defrauded several investors.

## Minister admits there is 'clearly a problem' with Britain's benefits system amid 'incentives' that mean claimants can be better off on sickness handouts than employment support
 - [https://www.dailymail.co.uk/news/article-14158363/Minister-admits-clearly-problem-Britains-benefits-amid-incentives-mean-claimants-better-sickness-handouts-employment-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158363/Minister-admits-clearly-problem-Britains-benefits-amid-incentives-mean-claimants-better-sickness-handouts-employment-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:18:29+00:00

Alison McGovern, the employment minister, told a parliamentary committee the 'current system doesn't work' as she was quizzed about Britain's incapacity crisis.

## Trump welcomes Peter Navarro back to the White House with top role after his prison stint for defying January 6 subpoena
 - [https://www.dailymail.co.uk/news/article-14158237/donald-trump-peter-navarro-trade-white-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14158237/donald-trump-peter-navarro-trade-white-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:13:54+00:00

Donald Trump announced Wednesday that he was appointing Peter Navarro, a former adviser who spent time in prison after the Jan. 6 attack on the U.S. Capitol , to a senior White House role.

## CNN stars at war with each other over how far the failing news network has fallen
 - [https://www.dailymail.co.uk/news/article-14149789/cnn-anderson-cooper-colleagues-coverage-donald-trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14149789/cnn-anderson-cooper-colleagues-coverage-donald-trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T18:10:34+00:00

As CNN continues to flounder with viewership and impending layoffs, the outlet's alumni are pointing fingers on what exactly is wrong through explosive exchanges on a private Facebook group.

## Update on Piedmont Tesla Cybertruck crash survivor Jordan Miller
 - [https://www.dailymail.co.uk/news/article-14157901/Update-Tesla-Cybertruck-crash-survivor-piedmont.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157901/Update-Tesla-Cybertruck-crash-survivor-piedmont.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T17:55:42+00:00

Jordan Miller, a 20-year-old business student at the University of Wisconsin, had been in town to visit family, relatives revealed after he underwent what they hope was life-saving surgery this week.

## Outrage as social media users gloat over assassination of UnitedHealthcare CEO Brian Thompson
 - [https://www.dailymail.co.uk/news/article-14157739/brian-thompson-unitedhealthcare-gloating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157739/brian-thompson-unitedhealthcare-gloating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T17:51:48+00:00

Thompson's former congressman condemned tasteless digs at Brian Thompson after his murder Wednesday morning.

## Fox News host Jesse Watters sparks fury after very suggestive joke about female Trump staff
 - [https://www.dailymail.co.uk/news/article-14157993/jesse-watters-fox-news-suggestive-joke-trump-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157993/jesse-watters-fox-news-suggestive-joke-trump-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T17:50:58+00:00

Fox News host Jesse Watters sparks outrage with suggestive joke about Donald Trump's women Cabinet nominees in show segment.

## Woman reveals what it's like living on the remotest island on earth after falling in love with a local and having two children
 - [https://www.dailymail.co.uk/news/article-14157831/woman-reveal-living-remote-island-children-tristan-da-cunha.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157831/woman-reveal-living-remote-island-children-tristan-da-cunha.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T17:47:41+00:00

Kelly Green, 34, of Eastbourne, England, decided to move to the remotest island on the planet - Tristan Da Cunha - in 2013. There, she met her husband who she shares two children with.

## California national parks rocked by murder of glamorous Sonoma ranger found dead in mountain home
 - [https://www.dailymail.co.uk/news/article-14157439/bay-area-sonoma-county-park-ranger-death-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157439/bay-area-sonoma-county-park-ranger-death-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T17:45:33+00:00

A glamorous park ranger from the Bay Area has been killed in a murder-suicide over the Thanksgiving holiday.

## Mother of three young children reveals how rental house 'bargain' left her homeless
 - [https://www.dailymail.co.uk/news/article-14157633/mother-children-rental-house-bargain-homeless.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157633/mother-children-rental-house-bargain-homeless.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T17:45:24+00:00

A Texas mother of three children explained how she was lured into a rental scam and made homeless by trusting a too good to be true listing. She created a GoFundMe as a last resort.

## Moment female stranger is arrested 'after trying to snatch toddler who was playing in his garden'
 - [https://www.dailymail.co.uk/news/article-14157727/Florida-Pamela-Monsalve-kidnap-boy-neighbors-rescue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157727/Florida-Pamela-Monsalve-kidnap-boy-neighbors-rescue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T17:36:27+00:00

Pamela Monsalve, 39, was arrested on a kidnapping charge after being accused of reaching over a fence and scooping up the child while he was playing outside in Hallandale Beach

## Small town Oregon school worker fired after shooting deer dead during break to 'let off steam'
 - [https://www.dailymail.co.uk/news/article-14157733/oregon-clatskanie-school-worker-fired-shooting-deer-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157733/oregon-clatskanie-school-worker-fired-shooting-deer-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T17:27:42+00:00

Paul Simmons, 55, a former employee at Clatskanie School District in Oregon was fired after he was caught 'blowing off steam' as he left work for a hunting expedition where he shot and killed a deer.

## Clarifications and corrections
 - [https://www.dailymail.co.uk/home/article-14158131/Clarifications-corrections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/home/article-14158131/Clarifications-corrections.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T17:03:11+00:00

In an article published on 4 December, since deleted from MailOnline, we stated that Kim Jong Un had 'sent Korean women to fight as cannon fodder for Putin in Ukraine'.

## Stanford 'misinformation' expert hit by humiliating AI blunder
 - [https://www.dailymail.co.uk/news/article-14157561/stanford-misinformation-expert-ai-blunder-false-studies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157561/stanford-misinformation-expert-ai-blunder-false-studies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T16:53:25+00:00

A Stanford expert on misinformation has admitted to using AI to fabricate evidence in a federal court case.

## Sleepy Joe? Watch Biden, 82, close his eyes for 80 SECONDS at Africa summit on his favorite subject trains
 - [https://www.dailymail.co.uk/news/article-14157877/sleepy-joe-biden-africa-trains.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157877/sleepy-joe-biden-africa-trains.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T16:44:57+00:00

President Joe Biden appeared to doze off in Africa during a discussion of his favorite subject: trains.

## UnitedHealthcare CEO Brian Thompson was facing a DoJ investigation and lawsuit when he was shot dead at investor conference
 - [https://www.dailymail.co.uk/news/article-14157793/unitedhealthcare-ceo-brian-thompson-doj-investigation-shot-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157793/unitedhealthcare-ceo-brian-thompson-doj-investigation-shot-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T16:44:12+00:00

Thompson, 50, was shot dead in what NYPD officials believe was a targeted attack as he exited the Hilton hotel on his way to an investor conference.

## Dramatic moment screaming drug dealer leaps at police as they chainsaw through his front door in desperate escape bid
 - [https://www.dailymail.co.uk/news/article-14157701/drug-dealer-leaps-police-chainsaw-door-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157701/drug-dealer-leaps-police-chainsaw-door-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T16:41:26+00:00

Shocking footage shows Abdulaziz Haruna - dressed in just his underwear and a purple balaclava - jumping above a police officer using the chainsaw.

## United Healthcare's disturbing track record of rejecting claims as CEO Brian Thompson is shot dead in New York
 - [https://www.dailymail.co.uk/news/article-14157577/unitedhealthcare-united-healthcare-rejecting-claims-ceo-brian-thompson-shot-protests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157577/unitedhealthcare-united-healthcare-rejecting-claims-ceo-brian-thompson-shot-protests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T16:36:57+00:00

UnitedHealthcare's disturbing track record of rejecting claims has come under the microscope after the insurance giant's CEO was shot dead in a targeted attack in the heart of Manhattan.

## The election FINALLY ends after last race results in shock outcome… and Mike Johnson faces grim new reality
 - [https://www.dailymail.co.uk/news/article-14157539/mike-johnson-house-majority-adam-gray.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157539/mike-johnson-house-majority-adam-gray.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T16:34:03+00:00

The final House race was officially called setting the tables for the new Congress come January.

## Police launch urgent appeal to find teenage boy last seen riding bicycle towards Severn Bridge as devastated mother begs for him to 'please come home'
 - [https://www.dailymail.co.uk/news/article-14157779/Police-urgent-appeal-teenage-boy-seen-riding-bicycle-Severn-bridge-devastated-mother-begs-come-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157779/Police-urgent-appeal-teenage-boy-seen-riding-bicycle-Severn-bridge-devastated-mother-begs-come-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T16:23:25+00:00

Joseph Bellamy, 18, was last seen leaving his home in Caldicot, Gwent, between midnight and 1am on Tuesday, riding a pushbike in the direction of the M48 bridge.

## Daniel Penny jury requests key trial evidence as they inch towards verdict in famous subway chokehold case
 - [https://www.dailymail.co.uk/news/article-14157905/daniel-penny-verdict-trial-case-jury-updates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157905/daniel-penny-verdict-trial-case-jury-updates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T16:18:13+00:00

The jury asked for the police bodycam footage from the moment cops confronted Penny and Jordan Neely on the train, along with the original video of the incident.

## New York City Mayor Eric Adams makes shock intervention in Daniel Penny case
 - [https://www.dailymail.co.uk/news/article-14157161/new-york-city-mayor-eric-adams-daniel-penny-case-trial-verdict.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157161/new-york-city-mayor-eric-adams-daniel-penny-case-trial-verdict.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T16:16:11+00:00

New York City Mayor Eric Adams defended the actions of Daniel Penny, whose trial over the use of a fatal chokehold on homeless man Jordan Neely is now in the hands of a jury.

## Bargain desert properties snapped up because ground underneath contains 'billions' in untapped gold
 - [https://www.dailymail.co.uk/news/article-14157279/mojave-desert-properties-california-gold-rush-underground.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157279/mojave-desert-properties-california-gold-rush-underground.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:56:18+00:00

A tiny mining town in the Rand Mountains, located in California 's Mojave Desert, has become the newest hot spot for real estate as the ground contains 'billions' in untapped gold.

## Multi-billion-pound Russian money laundering network is smashed by UK police: Crime syndicate run by glamorous millionaire and on-the-run businessman was used by oligarchs, drug dealers, the Kinahans gang and Kremlin to transfer cash
 - [https://www.dailymail.co.uk/news/article-14157465/Multi-billion-pound-Russian-money-laundering-network-smashed-UK-police-Crime-syndicate-run-glamorous-millionaire-run-businessman-used-oligarchs-drug-dealers-Kinahans-gang-Kremlin-transfer-cash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157465/Multi-billion-pound-Russian-money-laundering-network-smashed-UK-police-Crime-syndicate-run-glamorous-millionaire-run-businessman-used-oligarchs-drug-dealers-Kinahans-gang-Kremlin-transfer-cash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:41:26+00:00

The sophisticated network used by drug dealers, gangsters, cyber criminals, oligarchs and even Kremlin-controlled broadcaster Russia Today was smashed in the National Crime Agency.

## Tim Walz reacts to UnitedHealthcare CEO Brian Thompson's murder
 - [https://www.dailymail.co.uk/news/article-14157645/tim-walz-reacts-unitedhealthcare-ceo-brian-thompson-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157645/tim-walz-reacts-unitedhealthcare-ceo-brian-thompson-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:38:36+00:00

Minnesota Governor Tim Walz reacts to the death of UnitedHealthcare CEO Brian Thompson's murder.

## Who are UnitedHealthcare CEO Brian Thompson's wife and children? Family of tycoon who was shot dead outside Manhattan hotel
 - [https://www.dailymail.co.uk/news/article-14157489/unitedhealthcare-ceo-brian-thompson-wife-kids-family-dead-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157489/unitedhealthcare-ceo-brian-thompson-wife-kids-family-dead-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:36:35+00:00

UnitedHealthcare CEO Brian Thompson is survived by his wife Paulette 'Pauley' Thompson, 51, and their two children.

## Illegal immigrant is jailed after being found in the UK despite being deported FIVE times (and he'll be kicked out again when he's served his time)
 - [https://www.dailymail.co.uk/news/article-14157641/Illegal-immigrant-jailed-UK-deported.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157641/Illegal-immigrant-jailed-UK-deported.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:34:30+00:00

Lithuanian national Audrius Verkauskas, 44, signed a deportation order in March 2015 and was first removed in November of the same year.

## Terrified residents of Colorado Tren de Aragua apartment complex hit landlord where it hurts
 - [https://www.dailymail.co.uk/news/article-14157187/Colorado-whispering-pines-apartment-Aurora-gang-rent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157187/Colorado-whispering-pines-apartment-Aurora-gang-rent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:33:49+00:00

In court documents, Whispering Pines apartments' new, court-appointed landlord claimed that 'one or more tenant advocacy organizations...advised [residents] not to' pay.

## Vice chancellor of loss-making university 'claimed £17,000 expenses for three long-haul business class flights' after forcing students to attend climate change lectures
 - [https://www.dailymail.co.uk/news/article-14157265/Vice-chancellor-loss-making-university-claimed-17-000-expenses-three-long-haul-business-class-flights-forcing-students-attend-climate-change-lectures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157265/Vice-chancellor-loss-making-university-claimed-17-000-expenses-three-long-haul-business-class-flights-forcing-students-attend-climate-change-lectures.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:29:25+00:00

Professor Koen Lamberts, president and vice-chancellor of the University of Sheffield, reportedly claimed £17,598 for upgraded travel in his annual expenses this year.

## Suzanne Simpson's property tycoon husband charged with her murder two months after she vanished from mansion
 - [https://www.dailymail.co.uk/news/article-14157233/Suzanne-Simpson-brad-wife-murder-missing-indicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157233/Suzanne-Simpson-brad-wife-murder-missing-indicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:28:56+00:00

Brad Simpson, 53, husband of missing Texas realtor Suzanne Simpson has been indicted by a grand jury for first-degree murder two months after she went missing.

## Cathay Pacific is forced to apologise for playing Family Guy during flight
 - [https://www.dailymail.co.uk/news/article-14157463/Cathay-Pacific-apologise-Family-Guy-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157463/Cathay-Pacific-apologise-Family-Guy-flight.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:24:11+00:00

The airline, which is Hong Kong's flagship carrier, rushed to remove the episode from its inflight entertainment following a complaint from a customer.

## England rugby star Lawrence Dallaglio has failed to answer demands for cash to pay £354,000 tax bill, documents say
 - [https://www.dailymail.co.uk/news/article-14157337/England-rugby-Lawrence-Dallaglio-cash-tax-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157337/England-rugby-Lawrence-Dallaglio-cash-tax-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:17:10+00:00

Former England rugby captain Lawrence Dallaglio is being pursued liquidators who are trying to recover money he had loaned himself from his company.

## Boston judge who blocked migrant's ICE arrest and let him slip out the back door is hit with new charges
 - [https://www.dailymail.co.uk/news/article-14157243/boston-judge-migrant-ice-arrest-new-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157243/boston-judge-migrant-ice-arrest-new-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:04:38+00:00

A Boston judge is facing new charges from an ethics body years after she allegedly helped a twice-deported illegal immigrant evade arrest. She could be removed from the bench if she's found liable.

## Good Morning America staffers 'forced to work in stinking building with no heat or wifi'
 - [https://www.dailymail.co.uk/news/article-14157185/good-morning-america-staff-work-building-wifi-heat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157185/good-morning-america-staff-work-building-wifi-heat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T15:01:15+00:00

Good Morning America staffers have been forced to work in squalid conditions at the show's former Upper West Side HQ, according to reports.

## Melbourne school reverses its decision to BAN Christmas gifts because it might offend non-Christian students
 - [https://www.dailymail.co.uk/news/article-14157029/Eltham-east-Christmas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157029/Eltham-east-Christmas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:51:16+00:00

Parents and guardians at Eltham East Primary School in north-west Melbourne , were sent a letter earlier this week declaring a ban on the exchange of 'food or Christmas-themed items'.

## Tragic mystery as adorable boy, 3, is shot dead while mom played Uno in the next room
 - [https://www.dailymail.co.uk/news/article-14157231/mystery-new-orleans-boy-dead-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157231/mystery-new-orleans-boy-dead-shooting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:48:21+00:00

A Texas mother's worst nightmare became reality when her three-year-old son was accidentally shot and killed inside a friend's home while she played Uno in the next room.

## UnitedHealthcare CEO Brian Thompson shot and killed outside Manhattan Hilton hotel
 - [https://www.dailymail.co.uk/news/article-14157375/United-Health-Brian-Thompson-Hilton-Manhattan-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157375/United-Health-Brian-Thompson-Hilton-Manhattan-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:41:09+00:00

The shooting unfolded around 6:45am in Midtown, just hours before New Yorkers gather in the neighborhood for the annual Christmas tree lighting at Rockefeller Center.

## Supreme Court set for bombshell oral arguments on denying transgender children medical treatment
 - [https://www.dailymail.co.uk/news/article-14157419/supreme-court-transgender-children-medical-care.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157419/supreme-court-transgender-children-medical-care.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:34:41+00:00

The Supreme Court is hearing arguments Wednesday on a controversial Tennessee law denying transgender children medical treatment. 

## Pete Hegseth's mom Penelope rips media for publishing email calling him an 'abuser' and issues plea to Trump
 - [https://www.dailymail.co.uk/news/article-14157309/pete-hegseth-mom-plea-trump-nyt-email-abuser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157309/pete-hegseth-mom-plea-trump-nyt-email-abuser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:31:20+00:00

Pete Hegseth's mother accused the New York Times of criminal activity as she vehemently denied claims Donald Trump's pick for Defense Secretary is an 'abuser of women.'

## Horrifying video shows border patrol cops running over migrant at California wall
 - [https://www.dailymail.co.uk/news/article-14157191/video-border-patrol-cops-migrant-san-ysidro.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157191/video-border-patrol-cops-migrant-san-ysidro.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:27:22+00:00

Horrifying footage captured the moment a border patrol vehicle ran over a migrant who had apparently crossed from Tijuana to San Ysidro, California .

## INSIDE MAIL: Secret talent survey that will end careers at Seven and Nine, a TV star spent $50k on a makeover but looks the same - and who's burying bad news with the oldest trick in the book
 - [https://www.dailymail.co.uk/news/article-14152033/inside-mail-steve-jackson-peter-van-onselen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14152033/inside-mail-steve-jackson-peter-van-onselen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:27:21+00:00

The must-read Mail+ column with Steve Jackson and Peter van Onselen lifts the lid on Seven and Nine's secret research into their biggest stars as the networks face drastic cost cutting.

## Man is arrested over claims of fraud in campaign to bring WPC Yvonne Fletcher's killer to justice
 - [https://www.dailymail.co.uk/news/article-14157193/Man-arrested-claims-fraud-campaign-bring-WPC-Yvonne-Fletchers-killer-justice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157193/Man-arrested-claims-fraud-campaign-bring-WPC-Yvonne-Fletchers-killer-justice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:19:23+00:00

A man in his sixties was arrested in north London on Tuesday over shock allegations of fraud linked to the campaign for the killer of WPC Yvonne Fletcher to be brought to justice.

## Who is Steve McMahon, the racing official at the centre of the Chris Minns ICAC scandal?
 - [https://www.dailymail.co.uk/news/article-14156611/Steve-McMahon-Chris-Minns-ICAC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156611/Steve-McMahon-Chris-Minns-ICAC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:16:37+00:00

It's understood NSW Premier Chris Minns and Steve McMahon have known each other for more than 20 years through their Labor connections in Sydney's south.

## Dan Andrews' life in Melbourne turns into a nightmare as he is hit with fresh ban
 - [https://www.dailymail.co.uk/news/article-14155053/dan-andrews-ban-melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155053/dan-andrews-ban-melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T14:06:36+00:00

A former AFL star said Daniel Andrews left a 'trail of destruction' and he's not welcome in Victoria.

## Russian warship 'fires at' German helicopter: NATO reconnaissance aircraft incident over Baltic Sea sparks new conflict escalation fears
 - [https://www.dailymail.co.uk/news/article-14157167/Russian-warship-fires-German-helicopter-WW3.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157167/Russian-warship-fires-German-helicopter-WW3.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:35:32+00:00

The crew of the Russian ship fired signal ammunition, the German Press Agency in Brussels has learned.

## Sadiq Khan launches drive to stamp out misogyny in schools as he condemns 'epidemic' of abuse and violence against women
 - [https://www.dailymail.co.uk/news/article-14156495/Sadiq-Khan-1million-sexist-misogynistic-behaviour-SCHOOLS-abuse-violence-women-rife-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156495/Sadiq-Khan-1million-sexist-misogynistic-behaviour-SCHOOLS-abuse-violence-women-rife-London.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:35:11+00:00

The Mayor of London has launched a new project which aims to teach primary school boys about 'healthy relationships'.

## 'She's been through worse!': Woman, 95, left by NHS on freezing pavement with broken hip also survived Hitler's Blitz, husband reveals as he blasts her five-hour wait as a 'disgrace'
 - [https://www.dailymail.co.uk/news/article-14157069/Elderly-woman-waits-five-hours-ambulance-Dorset.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157069/Elderly-woman-waits-five-hours-ambulance-Dorset.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:33:49+00:00

The husband of a 95-year-old woman who was left waiting five hours on a pavement for an ambulance after breaking her hip has slammed the NHS over its 'disgraceful' prioritising of other calls.

## BBC star apologises after failing to properly declare nearly 30 speaking engagements that fetched him over £150,000
 - [https://www.dailymail.co.uk/news/article-14157255/bbc-star-apologises-failing-declare-external-engagements.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157255/bbc-star-apologises-failing-declare-external-engagements.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:33:16+00:00

The true figure could be more like £250,000 as the corporation only reveals the amount of money earnt in pay bands.

## Daniel Penny prosecutor Dafna Yoran's breathtaking 'hypocrisy' revealed as she demands manslaughter conviction
 - [https://www.dailymail.co.uk/news/article-14156999/Daniel-Penny-prosecutor-Dafna-Yoran-hypocrisy-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156999/Daniel-Penny-prosecutor-Dafna-Yoran-hypocrisy-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:32:59+00:00

Dafna Yoran has asked jurors to convict the marine veteran of manslaughter, but she has long pushed for 'restorative justice' for criminals.

## Trump Cabinet pick Dr. Janette Nesheiwat faces MAGA fury after COVID videos resurface
 - [https://www.dailymail.co.uk/news/article-14154833/donald-trump-surgeon-general-dr-janette-nesheiwat-maga-fury-covid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154833/donald-trump-surgeon-general-dr-janette-nesheiwat-maga-fury-covid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:31:55+00:00

Trump's announcement of his choice of Fox News contributor Dr. Janette Nesheiwat as his pick for Surgeon General last week sparked immediate skepticism.

## Pete Hegseth tears into 'smears' and 'BS stories' as he breaks silence on reports Trump is considering replacing him
 - [https://www.dailymail.co.uk/news/article-14157085/pete-hegseth-breaks-silence-allegations-trump-defense-pick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157085/pete-hegseth-breaks-silence-allegations-trump-defense-pick.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:28:18+00:00

Pete Hegseth insisted Wednesday morning that he will not drop out of consideration to be the next Secretary of Defense. 'Our warriors never back down, & neither will I,' he wrote on X.

## Hilarious moment Ant and Dec doorbell scares off masked burglar as he tries to break into home
 - [https://www.dailymail.co.uk/news/article-14156737/Ant-Dec-doorbell-scares-masked-burglar-tries-break-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156737/Ant-Dec-doorbell-scares-masked-burglar-tries-break-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:26:05+00:00

Mo Zeb was out for dinner with his wife when he received a notification from his Ring doorbell saying that someone was outside their home.

## Metropolitan Police officer killed moped rider after speeding through red light on way to a 999 call
 - [https://www.dailymail.co.uk/news/article-14157139/metropolitan-police-officer-killed-moped-rider-red-light.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157139/metropolitan-police-officer-killed-moped-rider-red-light.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:24:39+00:00

PC Ian Brotherton, 32, was driving a police van with blue lights flashing and sirens on when he ploughed into Cristopher De Carvalho Guedes at a junction in Enfield, north London , last October.

## Tucker Carlson heads back to Moscow to interview Putin's foreign minister Sergei Lavrov
 - [https://www.dailymail.co.uk/news/article-14157049/tucker-carlson-moscow-putin-foreign-minister-sergei-lavrov.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157049/tucker-carlson-moscow-putin-foreign-minister-sergei-lavrov.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:21:54+00:00

Carlson posted a video from the Red Square in Moscow lambasting the Biden administration, which he said had 'driven the US ever-closer to a nuclear conflict'

## Squirming Keir Starmer dodges at PMQs over ex-minister Louise Haigh's fraud row as Tory leader Kemi Badenoch tells him: 'We need conviction politicians, not politicians with convictions'
 - [https://www.dailymail.co.uk/news/article-14157163/Squirming-Keir-Starmer-dodges-PMQs-ex-minister-Louise-Haighs-fraud-row-Tory-leader-Kemi-Badenoch-tells-need-conviction-politicians-not-politicians-convictions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157163/Squirming-Keir-Starmer-dodges-PMQs-ex-minister-Louise-Haighs-fraud-row-Tory-leader-Kemi-Badenoch-tells-need-conviction-politicians-not-politicians-convictions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:16:45+00:00

The Prime Minister refused to reveal what he did or didn't know about the former transport secretary pleading guilty to a criminal offence a decade ago.

## Keir Starmer refuses to repeat vow for UK to have fastest growth in the G7 as Tories warn he will be 'back for more taxes' despite record Budget raid
 - [https://www.dailymail.co.uk/news/article-14157165/Keir-Starmer-UK-fastest-growth-G7-Tories-tax-Budget-raid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157165/Keir-Starmer-UK-fastest-growth-G7-Tories-tax-Budget-raid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:14:24+00:00

Keir Starmer was challenged over the pledge by Kemi Badenoch as they faced off in the Commons this lunchtime.

## Lee Lovell issues a desperate plea after a teenage thug who broke into his North Lakes home on the night his wife was stabbed to death WALKS FREE - despite more than 100 prior criminal offences
 - [https://www.dailymail.co.uk/news/article-14156603/Emma-Lovell-home-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156603/Emma-Lovell-home-invasion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:13:35+00:00

A shattered dad whose wife was murdered during a Boxing Day home invasion says that 'justice had not been done' after one of the two intruders walked free from court.

## Incredible secret of Rothschild 'heir', 87, who died in fire at his $1m LA home
 - [https://www.dailymail.co.uk/news/article-14157001/secret-rothschild-heir-died-fire-la-home-william-alexander-derothschild.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14157001/secret-rothschild-heir-died-fire-la-home-william-alexander-derothschild.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T13:11:13+00:00

William Alexander de Rothschild, 87, perished in the blaze at his $1 million Laurel Canyon home on November 27.

## Fashion chain owned by H&M is to close all of its stores in fresh blow to the British high street
 - [https://www.dailymail.co.uk/news/article-14156993/Fashion-chain-Monki-close-stores-British-high-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156993/Fashion-chain-Monki-close-stores-British-high-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T12:32:34+00:00

Monki, which targets younger shoppers, will close the seven stores it has across the UK including a site on London 's Carnaby Street and Manchester's Arandale Centre.

## Kim Jong Un sends North Korean women to fight as cannon fodder for Putin in Ukraine
 - [https://www.dailymail.co.uk/news/article-14156683/Kim-Jong-North-Korean-women-fight-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156683/Kim-Jong-North-Korean-women-fight-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T12:32:18+00:00

Two of the female soldiers from North Korea were allegedly pictured in Zheleznogorsk in Kursk region, which is partially occupied by Ukraine

## Duchess of Edinburgh's Met Police motorcyclist will stand trial for careless driving after hitting and killing 'vulnerable' great-grandmother, 81
 - [https://www.dailymail.co.uk/news/article-14156781/Duchess-Edinburghs-Met-motorcyclist-careless-driving-killing-great-gran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156781/Duchess-Edinburghs-Met-motorcyclist-careless-driving-killing-great-gran.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T12:31:42+00:00

Met Police motorcyclist Christopher Harrison, 67,  will stand trial after denying driving carelessly when he hit and killed a great-grandmother while escorting the Duchess of Edinburgh in May 2023.

## Mother of three-year-old girl killed after being hit by Porsche deliberately driven the wrong way down the M6 finds it 'impossible to grieve' as no-one knows why driver performed 'unfathomable' U-turn
 - [https://www.dailymail.co.uk/news/article-14156893/Mother-killed-Porsche-wrong-way-M6-grieve-driver-U-turn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156893/Mother-killed-Porsche-wrong-way-M6-grieve-driver-U-turn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T12:30:42+00:00

Faye Dawson, from Wallasey, died after driver Terence Unsworth, 79, deliberately swerved into oncoming traffic on the M6, near Leyland, on November 19, 2022.

## Wealthy Boomer couple spark bitter online debate after complaining about their $900,000 dilemma
 - [https://www.dailymail.co.uk/news/article-14155897/Aussie-Boomers-pension-debate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155897/Aussie-Boomers-pension-debate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T12:23:59+00:00

An elderly Boomer couple have sparked online fury from Aussies after a family member sought advice from a finance expert on their behalf.

## WFH is A-OK at the MoJ? Civil servants' office attendance at the Ministry of Justice plummets after Labour's election win... despite officials grappling with prisons crisis
 - [https://www.dailymail.co.uk/news/article-14156997/WFH-civil-servants-office-attendance-Ministry-Justice-plummets-Labours-election-win-despite-officials-grappling-prisons-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156997/WFH-civil-servants-office-attendance-Ministry-Justice-plummets-Labours-election-win-despite-officials-grappling-prisons-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T12:20:10+00:00

Civil servants are supposed to spend at least days a week in the office under Whitehall rules on working from home.

## Met Office issues yellow wind warning: Map reveals where 80mph gusts and torrential rain are set to hit this weekend - as next storm heads towards Britain
 - [https://www.dailymail.co.uk/news/article-14156983/Met-Office-issues-yellow-wind-warning-Map-reveals-80mph-gusts-torrential-rain-set-hit-weekend-storm-heads-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156983/Met-Office-issues-yellow-wind-warning-Map-reveals-80mph-gusts-torrential-rain-set-hit-weekend-storm-heads-Britain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T12:18:02+00:00

A Met Office yellow warning for rain and wind has been issued for the whole of England, Wales and Northern Ireland - running from Friday at 3pm until Sunday at 6am.

## Away in a manger, dough crib for a bed! Bakery creates Christmas nativity display out of bread - starring a BAGUETTE as the baby Jesus
 - [https://www.dailymail.co.uk/news/article-14156487/bakery-christmas-nativity-display-bread.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156487/bakery-christmas-nativity-display-bread.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T11:22:32+00:00

One bakery in Gloucestershire has gone against the grain this year using their very own bread loaves as a nativity display - and customers believe its butter than usual. 

## The world's best destinations for expats are revealed - with a very surprising city awarded the top spot
 - [https://www.dailymail.co.uk/news/article-14156517/worlds-best-destinations-expats-city.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156517/worlds-best-destinations-expats-city.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T11:20:31+00:00

Factors such as cost of living, safety, healthcare, education and lifestyle are all crucial to consider, and now new analysis has ranked potential destinations according to these criteria.

## Emotional scenes as Aussie grandmother accused of smuggling 2kg of meth in Japan is dealt a devastating blow
 - [https://www.dailymail.co.uk/news/article-14156273/Donna-Nelson-drug-smuggling-guilty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156273/Donna-Nelson-drug-smuggling-guilty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T11:06:50+00:00

The Perth grandmother has already served 430 days behind bars since she was arrested by customs officials at Narita Airport in January 2023

## BBC star who solved one of the biggest mysteries of the 1960s dies aged 86 as family pay tribute to 'amazing life'
 - [https://www.dailymail.co.uk/news/article-14156433/BBC-star-solved-biggest-mysteries-1960s-dies-86.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156433/BBC-star-solved-biggest-mysteries-1960s-dies-86.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T11:04:56+00:00

Craig Rich, the BBC's first regional weather forecaster, who helped solve the mystery behind the 1968 disappearance of yachtsman Donald Crowhurst, has died aged 86.

## Horse racing industry is rocked by shock news just days out from Christmas
 - [https://www.dailymail.co.uk/news/article-14155925/VRC-job-cuts-racing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155925/VRC-job-cuts-racing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T10:23:16+00:00

The Victoria Racing Club, which runs Australia's biggest race is trying to dig itself out of a deep financial hole.

## Body is pulled from river in the hunt for missing 18-year-old student who had not been seen for a week
 - [https://www.dailymail.co.uk/news/article-14156553/Body-pulled-river-missing-student.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156553/Body-pulled-river-missing-student.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T10:18:13+00:00

University of Reading student Fintan was first reported missing in Oxford in the early hours of Wednesday last week.

## MPs' outrage at 'bonkers' Labour junk food crackdown that will see porridge, crumpet and even muesli ads banned before the 9pm watershed (and you'll need a PhD to work out what's covered)
 - [https://www.dailymail.co.uk/news/article-14156593/Outrage-bonkers-Labour-junk-food-porridge-crumpet-muesli-ads-banned-9pm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156593/Outrage-bonkers-Labour-junk-food-porridge-crumpet-muesli-ads-banned-9pm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T10:18:00+00:00

The popular staples are among a bewildering array of products set to fall foul of the new rules on promotions before the watershed.

## Psychic night is postponed due to 'unforeseen circumstances' as ticketholders fume 'thought they would have seen that coming'
 - [https://www.dailymail.co.uk/news/article-14156267/psychic-night-postponed-unforeseen-circumstances-ticketholders-fume.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156267/psychic-night-postponed-unforeseen-circumstances-ticketholders-fume.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T10:15:58+00:00

The power of hindsight may have gone amiss as one pub called the Novar Arms in Dingwall Scotland, had their psychic night postponed due to 'unforeseen circumstances'. 

## Horrifying moment innocent stranger is floored by violent sucker punch in completely unprovoked Vancouver attack
 - [https://www.dailymail.co.uk/news/article-14156373/moment-innocent-stranger-vancouver-attack-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156373/moment-innocent-stranger-vancouver-attack-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T10:15:51+00:00

Harrowing video shows how the victim was attacked while walking down a busy street near the Hudson's Bay department store in Vancouver last Thursday

## More criminals will be spared jail to cope with shortfall of 12,400 prison spaces: Offenders will live under house arrest and wear tags - with Labour's early release scheme set to continues for years
 - [https://www.dailymail.co.uk/news/article-14156543/More-criminals-spared-jail-cope-shortfall-12-400-prison-spaces.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156543/More-criminals-spared-jail-cope-shortfall-12-400-prison-spaces.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T10:15:02+00:00

Delays in building new prisons means there will be a shortage of more than 12,000 places in England and Wales - and possibly as high as 21,200 - within three years.

## End of paper exam looming: Most GCSEs and A-Levels test subjects to go digital by 2030
 - [https://www.dailymail.co.uk/news/article-14156303/GCSEs-Levels-test-subjects-digital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156303/GCSEs-Levels-test-subjects-digital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T10:13:35+00:00

Pearson will first test the waters by providing digital versions of the most popular Edexcel GCSEs, History and Business Studies, from 2027.

## Warning over cocktail of prescribed drugs taken by Thomas Kingston before he took his own life: Anti-depressants taken by Lady Gabriella Windsor's husband are linked to suicidal side effects, doctors tell inquest
 - [https://www.dailymail.co.uk/news/article-14156251/Warning-cocktail-prescribed-drugs-Thomas-Kingston.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156251/Warning-cocktail-prescribed-drugs-Thomas-Kingston.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T10:06:51+00:00

Lady Gabriella Windsor's husband Thomas Windsor, 45, had suffered an adverse reaction to prescribed medication, an inquest heard.

## Fugitive who killed off-duty paramedic in horror crash and went on the run learns his fate in court
 - [https://www.dailymail.co.uk/news/article-14156189/Mingen-paramedic-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156189/Mingen-paramedic-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T09:54:44+00:00

Mingen He, 25, had pleaded guilty to one count of dangerous driving causing the death of Pauline Smith (pictured) in a crash in 2022.

## Teenager involved in burglary that saw British mother Emma Lovell stabbed to death in front of her husband walks FREE despite being convicted
 - [https://www.dailymail.co.uk/news/article-14156197/Teenager-involved-burglary-British-mother-Emma-Lovell-stabbed-death-husband-FREE-convicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156197/Teenager-involved-burglary-British-mother-Emma-Lovell-stabbed-death-husband-FREE-convicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T09:13:56+00:00

Emma Lovell, 41, was knifed down outside her property near Brisbane on the night of December 26 2022, during a home invasion carried out by two 17-year-old boys.

## Moment Brit, 30, is arrested in Thailand 'for raping six-year-old girl he knew through a friend'
 - [https://www.dailymail.co.uk/news/article-14156269/Moment-Brit-30-arrested-Thailand-raping-six-year-old-girl-knew-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156269/Moment-Brit-30-arrested-Thailand-raping-six-year-old-girl-knew-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T09:12:32+00:00

Luke Adam Lawrence, 30, from Leeds, West Yorkshire, was identified by sleuths at the National Crime Agency (NCA) in London over an alleged video of a schoolgirl being abused

## Man 'who stabbed eight-year-old girl to death had attacked the child's mother after arguing about a phone'
 - [https://www.dailymail.co.uk/news/article-14156245/Man-stabbed-girl-death-attacked-mother-phone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156245/Man-stabbed-girl-death-attacked-mother-phone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T09:07:50+00:00

Malika Noor Al Katib, 8, died after she was stabbed in the neck at her home in County Wexford, Ireland on Sunday evening.

## Interest rates will stay higher for longer because of Labour's monster tax and spend Budget, OECD warns
 - [https://www.dailymail.co.uk/news/article-14156255/Interest-rates-higher-Labour-tax-spend-Budget-OECD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156255/Interest-rates-higher-Labour-tax-spend-Budget-OECD.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T09:03:01+00:00

In its annual economic survey, the OECD predicted that both interest rates and inflation will be above previous expectations.

## Winter Plunderland! Thieves snatch £500 of gadgets off couple at Hyde Park's festive event after targeting them as they left ride
 - [https://www.dailymail.co.uk/news/article-14156257/Winter-Wonderland-Thieves-Hyde-Park-targeting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156257/Winter-Wonderland-Thieves-Hyde-Park-targeting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T08:57:09+00:00

The festive funfair in central London opened less than two weeks ago, but already there have been 12 thefts reported to the Met Police , Metro reports.

## Air fryers and slow cookers to be given to pensioners to help reduce bills after winter fuel payments cuts
 - [https://www.dailymail.co.uk/news/article-14156091/Air-fryers-slow-cookers-pensioners-bills-winter-fuel-payments-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156091/Air-fryers-slow-cookers-pensioners-bills-winter-fuel-payments-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T08:09:51+00:00

Conservative-run local authority, North Lincolnshire council revealed the energy-efficient appliances would be handed out in the new year.

## Premier Chris Minns to be referred to corruption watchdog as major scandal engulfs the NSW Government
 - [https://www.dailymail.co.uk/news/article-14156051/Chris-Minns-ICAC-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156051/Chris-Minns-ICAC-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T07:58:52+00:00

NSW Premier Chris Minns will be referred to the Independent Commission Against Corruption over a $5billion deal to turn Rosehill Gardens Racecourse into a housing development.

## Grandma, 64, searching for her missing cat falls down massive sinkhole sparking major rescue operation
 - [https://www.dailymail.co.uk/news/article-14155909/pennsylvania-grandmother-falls-sinkhole-searching-missing-cat-rescue-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155909/pennsylvania-grandmother-falls-sinkhole-searching-missing-cat-rescue-operation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T07:12:14+00:00

Major search efforts are underway for a 64-year-old Pennsylvania grandmother who fell into a massive sinkhole while searching for her missing cat.

## Mom-of-two unlocks new fear of Target's shopping trolley as toddler gets fingers stuck in cart's holes
 - [https://www.dailymail.co.uk/news/article-14155717/mom-problem-Target-shopping-cart-fingers-stuck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155717/mom-problem-Target-shopping-cart-fingers-stuck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T06:57:49+00:00

Emily McMaugh shared a new parenting fear after going shopping with her two young children at Target.

## Motion is launched to IMPEACH South Korean President Yoon Suk Yeol after martial law debacle
 - [https://www.dailymail.co.uk/news/article-14156001/Motion-launched-IMPEACH-South-Korean-President-Yoon-Suk-Yeol-martial-law-debacle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14156001/Motion-launched-IMPEACH-South-Korean-President-Yoon-Suk-Yeol-martial-law-debacle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T06:50:44+00:00

South Korean opposition parties have submitted a motion to impeach President Yoon Suk Yeol over his short-lived declaration of martial law.

## Tucker Carlson makes chilling discovery in Moscow as he warns Biden is driving America to 'nuclear holocaust'
 - [https://www.dailymail.co.uk/news/article-14155689/tucker-carlson-chilling-discovery-moscow-biden-america-nuclear-holocaust.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155689/tucker-carlson-chilling-discovery-moscow-biden-america-nuclear-holocaust.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T06:49:27+00:00

Appearing outside of the Kremlin in a video shared to his social media, Carlson said he was back in the country ten months after he interviewed Russian President Vladimir Putin.

## Sleepy Maine elementary school becomes hotbed of violence and bullying after influx of migrants
 - [https://www.dailymail.co.uk/news/article-14155667/Montello-Elementary-Lewiston-Maine-bullying-violence-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155667/Montello-Elementary-Lewiston-Maine-bullying-violence-migrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T06:48:35+00:00

Teachers and staff members at Montello Elementary School in Lewiston claim it has been plagued by violence and bullying amid an influx of migrants to the community.

## Judge in Hunter Biden tax case blasts Joe for 'rewriting history' as he slams son's pardon
 - [https://www.dailymail.co.uk/news/article-14155827/Judge-Hunter-Biden-tax-case-blasts-Joe-pardon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155827/Judge-Hunter-Biden-tax-case-blasts-Joe-pardon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T06:37:35+00:00

The presiding judge in Hunter Biden 's tax fraud case said he would accept the pardon issued by his father but slammed President Joe Biden for trying to 'rewrite history' in his reasoning.

## Sean Hannity's new $23.5M mansion revealed after Fox News star fled New York for the 'free state of Florida'
 - [https://www.dailymail.co.uk/news/article-14155565/Sean-Hannity-Florida-mansion-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155565/Sean-Hannity-Florida-mansion-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T06:33:34+00:00

The 62-year-old has ditched The Empire State and moved into his new home located in Manalapan, an affluent town within Palm Beach County.

## Billionaire Harvey Norman boss's brutal blast at Anthony Albanese and nation's top politicians: 'Get a REAL job!'
 - [https://www.dailymail.co.uk/news/article-14155831/gerry-harvey-anthony-albanese-harvey-norman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155831/gerry-harvey-anthony-albanese-harvey-norman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T06:25:22+00:00

Billionaire business Gerry Harvey has blasted the nation's politicians saying they are ill-equipped to deal with the country's spiralling cost-of-living crisis because they've never had a real job.

## Cyclist narrowly escapes being dragged under a truck after his bike wheels are crushed - but who is to blame?
 - [https://www.dailymail.co.uk/news/article-14155603/cyclist-truck-dashcam-video-melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155603/cyclist-truck-dashcam-video-melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T06:08:57+00:00

A cyclist who narrowly escaped being dragged underneath a semi-trailer has left Aussies divided over who is to blame for the close call.

## School principal accused of stealing $1.4million from the Department of Education in elaborate fraud scheme
 - [https://www.dailymail.co.uk/news/article-14155749/rabieh-gharibeh-ahmed-charchouh-sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155749/rabieh-gharibeh-ahmed-charchouh-sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T05:57:41+00:00

School principal Rabieh Gharibeh, 37, and his brother-in-law Ahmed Charchouh, 38, were arrested over their alleged role in the fraud scheme during dramatic raids on Wednesday morning.

## How 'greedy' Commonwealth Bank has already been charging Australians for cash withdrawals - and has no plans of stopping despite major backlash
 - [https://www.dailymail.co.uk/news/article-14155655/Commonwealth-Bank-3-fee-withdraw-smart-access.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155655/Commonwealth-Bank-3-fee-withdraw-smart-access.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T05:52:09+00:00

Australia's largest bank was hit with outrage this week after announcing customers on its Complete Access accounts would be moved to Smart Access accounts with the new fee.

## Jackass row rocks Sydney's ritzy Double Bay - as furious local leaves a VERY rude message on parked car's windscreen
 - [https://www.dailymail.co.uk/news/article-14154989/double-bay-parking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154989/double-bay-parking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T05:44:02+00:00

A row over a 'jackass' parking manoeuvre has erupted in one of the country's most genteel neighbourhoods, with an outraged local resident taping furious feedback onto a selfish driver's car.

## Andrew Bolt's brutal three-word takedown after university academic allegedly sent him threatening messages
 - [https://www.dailymail.co.uk/news/article-14154993/Andrew-Bolt-university-academic-threat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154993/Andrew-Bolt-university-academic-threat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T04:49:07+00:00

Andrew Bolt has ridiculed a Sydney University academic who allegedly sent him threatening and abusive messages.

## Chilling phrase caught on camera before Emma Lovell was killed during fatal break-in after two teens barged into her house - as final accomplice prepares to learn his fate
 - [https://www.dailymail.co.uk/news/article-14155755/Chilling-phrase-caught-camera-Emma-Lovell-killed-fatal-break-two-teens-barged-house-final-accomplice-prepares-learn-fate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155755/Chilling-phrase-caught-camera-Emma-Lovell-killed-fatal-break-two-teens-barged-house-final-accomplice-prepares-learn-fate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T04:44:35+00:00

Haunting CCTV captured screams of 'I'll kill you' and 'stop' moments before a mother-of-two was stabbed to death on her doorstep on Boxing Day.

## Nissan could face collapse within the next 12 months
 - [https://www.dailymail.co.uk/news/article-14155149/Nissan-Australia-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155149/Nissan-Australia-collapse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T04:39:29+00:00

A major Japanese car company sold in Australia is on the brink of collapse.

## Alicia Schiller: Shock twist after killer was approved for IVF treatment so she can give birth behind bars
 - [https://www.dailymail.co.uk/news/article-14155097/alicia-schiller-murderer-IVF-baby-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155097/alicia-schiller-murderer-IVF-baby-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T04:34:28+00:00

Alicia Schiller, then 26, brutally killed mother-of-three Tyrelle Evertson-Mostert, 31, in a drug-fuelled row over $50 in Geelong in 2014.

## 'Missing' Hawaii woman Hannah Kobayashi is seen in new surveillance footage buying bus ticket to Mexico
 - [https://www.dailymail.co.uk/news/article-14155545/Hannah-Kobayashi-seen-ticket-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155545/Hannah-Kobayashi-seen-ticket-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T04:27:13+00:00

Hannah Kobayashi, 30, was seen in new surveillance footage buying a bus ticket to Mexico on November 11 - the day she stopped replying to messages from her family and friends.

## The VERY telling question Daniel Penny jury asked within an hour of deliberations that may hint at verdict
 - [https://www.dailymail.co.uk/news/article-14155297/daniel-penny-jury-telling-question-hint-verdict-jordan-neely-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155297/daniel-penny-jury-telling-question-hint-verdict-jordan-neely-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T03:48:17+00:00

The jury are weighing manslaughter and criminally negligent homicide charges against Daniel Penny who used a fatal chokehold to subdue Jordan Neely on the New York City subway.

## Missouri death row inmate's final words as he is executed for raping and killing nine-year-old girl found dumped in sinkhole
 - [https://www.dailymail.co.uk/news/article-14155407/Christopher-Colling-Missouri-death-row-murder-sinkhole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155407/Christopher-Colling-Missouri-death-row-murder-sinkhole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T03:47:55+00:00

Christopher Colling, 49, shared a final statement before he was put to death on Tuesday evening in Bonne Terre, Missouri.

## Trump considers former nemesis as shock replacement for scandal-plagued Secretary of Defense pick Pete Hegseth
 - [https://www.dailymail.co.uk/news/article-14155553/trump-former-nemesis-pete-hegseth-replacement-secretary-defense.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155553/trump-former-nemesis-pete-hegseth-replacement-secretary-defense.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T03:45:51+00:00

Donald Trump is reportedly considering an 11th hour move to remove controversial Secretary of Defense nominee Pete Hegseth.

## AOC's ally who helped her rise to power accuses her of huge 'betrayal'
 - [https://www.dailymail.co.uk/news/article-14155349/AOC-ally-accuses-huge-betrayal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155349/AOC-ally-accuses-huge-betrayal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T03:45:42+00:00

A man who claims he spent money to fund Alexandria Ocasio-Cortez 's shock rise to Congress says the 'Squad' Democrat has 'betrayed' her district.

## Channel Nine star gets some VERY public words of support from an unexpected place as she sues her own TV network for discrimination
 - [https://www.dailymail.co.uk/news/article-14155213/nine-ben-fordham-airlie-walsh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155213/nine-ben-fordham-airlie-walsh.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T03:45:36+00:00

Loyal Nine staffers are rallying around Airlie Walsh and offering her their full support following shock revelations she is suing the network for discrimination.

## Trump prosecutor Fani Willis suffers new blow as judge orders her to turn over communications with Special Counsel Jack Smith to conservative watchdog group
 - [https://www.dailymail.co.uk/news/article-14155601/fani-willis-trump-election-interference-judicial-watch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155601/fani-willis-trump-election-interference-judicial-watch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T03:44:45+00:00

A judge ordered Fulton County DA Fani Willis to turn over communications in the election interference case to Judicial Watch, a conservative watchdog group.

## Grant Thornton Australia CEO Greg Keith unleashes about workers' bad habit
 - [https://www.dailymail.co.uk/news/article-14155043/Australia-work-boss-coffee-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155043/Australia-work-boss-coffee-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T03:40:40+00:00

The boss of a large accounting firm revealed his 'pet hate' about workers.

## Bizarre place $18million worth of meth and cocaine bricks covered in photos of Vladimir Putin were discovered by cops
 - [https://www.dailymail.co.uk/news/article-14155229/meth-cocaine-bricks-hume-highway-nsw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155229/meth-cocaine-bricks-hume-highway-nsw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T03:39:50+00:00

Police made the surprising discovery after pulling over a 26-year-old man attempting to cross the border from Sydney to Melbourne on Tuesday.

## Passed out bikini-clad Aussie filmed being wheeled in a trolley through the backstreets of Thailand by a kind-hearted cop is identified
 - [https://www.dailymail.co.uk/news/article-14155153/tahli-benson-thailand-trolley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155153/tahli-benson-thailand-trolley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T03:26:25+00:00

Authorities stepped in after partygoers failed to rouse the women, with footage showing Thai police officer wheeling the pair back to their hostel in a pushcart he borrowed from a nearby shop.

## Texas nuns are expelled by the Vatican for breaking chastity vows with online love affairs
 - [https://www.dailymail.co.uk/news/article-14155155/Texas-nuns-Arlington-expelled-Vatican.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155155/Texas-nuns-Arlington-expelled-Vatican.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T02:42:40+00:00

The Vatican has expelled a group of Texas nuns amid a yearlong dispute between the sisters and Fort Worth Bishop Michael Olson after he accused their Reverend Mother of breaking her vows.

## Trump FBI director pick Kash Patel targeted by Iranian hackers, according to report
 - [https://www.dailymail.co.uk/news/article-14155259/Trump-FBI-director-pick-Kash-Patel-targeted-Iranian-hackers-according-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155259/Trump-FBI-director-pick-Kash-Patel-targeted-Iranian-hackers-according-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T02:38:50+00:00

Donald Trump's pick for FBI director Kash Patel was informed by the bureau that he was targeted by Iranian hackers, according to a new report.

## Peter Dutton cops backlash over push to build seven nuclear power stations in Australia
 - [https://www.dailymail.co.uk/news/article-14154479/Australia-nuclear-power-plant-locations-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154479/Australia-nuclear-power-plant-locations-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T02:20:20+00:00

Locals have blasted plans to build nuclear stations in Australia as the Coalition pushes ahead with its proposal to establish seven sites.

## Utah tourist caught defacing ancient petroglyphs is unmasked
 - [https://www.dailymail.co.uk/news/article-14155087/Utah-tourists-defacing-ancient-petroglyphs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155087/Utah-tourists-defacing-ancient-petroglyphs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T02:17:11+00:00

The woman and a man, who is yet to be identified, are accused of causing about $7,000 in damage between the Wire Pass and Buckskin Gulch trail heads on the Utah- Arizona border.

## Gavin Newsom tears into Biden for pardoning son Hunter: 'I took the president at his word'
 - [https://www.dailymail.co.uk/news/article-14155185/Gavin-Newsom-tears-Biden-pardon-son-Hunter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155185/Gavin-Newsom-tears-Biden-pardon-son-Hunter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:48:00+00:00

Gavin Newsom says he's 'disappointed' in Joe Biden after the president announced a shock lame duck pardon for his son Hunter.

## Scottish artist Jasleen Kaur wins Turner Prize 2024 - after putting giant doily on a Ford Escort
 - [https://www.dailymail.co.uk/news/article-14155193/Scottish-artist-Jasleen-Kaur-wins-Turner-Prize-2024-putting-giant-doily-Ford-Escort.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155193/Scottish-artist-Jasleen-Kaur-wins-Turner-Prize-2024-putting-giant-doily-Ford-Escort.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:44:12+00:00

Kaur, 36, the youngest artist on this year's shortlist, was nominated for her work titled Altar Altar, which was displayed at the Tramway in Glasgow along with several other sculptures.

## Commonwealth Bank backs down on $3 cash withdrawal fee after major backlash
 - [https://www.dailymail.co.uk/news/article-14155209/Commonwealth-Bank-set-axe-3-cash-withdrawal-fee-major-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155209/Commonwealth-Bank-set-axe-3-cash-withdrawal-fee-major-backlash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:44:11+00:00

The fee was to apply from January 6 for customers when they withdraw cash from tellers in bank branches, post offices or over the phone.

## Liam Payne's grief-stricken girlfriend Kate Cassidy packs up what remains of their life together and leaves their home as she faces life without the love of her life
 - [https://www.dailymail.co.uk/news/article-14154275/liam-payne-girlfriend-kate-cassidy-moves-london-flat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154275/liam-payne-girlfriend-kate-cassidy-moves-london-flat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:43:36+00:00

EXC: Heartbroken Kate Cassidy, 25, appeared close to tears after gathering together her belongings as she moved out of the property where she had been living in the aftermath of the tragedy.

## Our beautiful two-year-old son went into hospital where doctors diagnosed him 'constipation' - but just four days later he was dead
 - [https://www.dailymail.co.uk/news/article-14152279/toddler-hospital-diagnosed-constipation-dead-inquest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14152279/toddler-hospital-diagnosed-constipation-dead-inquest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:42:58+00:00

EXCLUSIVE: Hudson Cole Perrins died on June 27 this year - four days after his worried father, Greg, first took him to New Cross Hospital in Wolverhampton with stomach pain.

## Israel threatens to return to war in Lebanon and target the state itself if its truce with Hezbollah collapses
 - [https://www.dailymail.co.uk/news/article-14155307/Israel-war-Lebanon-Hezbollah-truce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155307/Israel-war-Lebanon-Hezbollah-truce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:42:35+00:00

In its strongest threat since last week's deal to end 14 months of conflict, Israel said it would hold Lebanon responsible for failing to disarm militants who violate the ceasefire.

## The people of Grimsby have spoken! Locals reveal what they really think of being named the 'most work-shy place in Britain' where benefits claimants outnumber grafters
 - [https://www.dailymail.co.uk/news/article-14151791/Grimsby-spoken-Locals-reveal-think-named-work-shy-place-Britain-benefits-grafters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14151791/Grimsby-spoken-Locals-reveal-think-named-work-shy-place-Britain-benefits-grafters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:42:10+00:00

EXCLUSIVE: The people of Grimsby have revealed what they really think about being named the 'most work-shy place in Britain', with one saying they are 'desperate to get out',

## Kate Garraway's TV firm plunges £165,000 into the red after three other companies she held with late husband Derek Draper ran up debts of £2million
 - [https://www.dailymail.co.uk/news/article-14152253/kate-garraway-tv-firm-debt-derek-draper.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14152253/kate-garraway-tv-firm-debt-derek-draper.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:41:16+00:00

EXCLUSIVE: Kate Garraway 's TV firm has plunged £165,000 into debt - after three other firms she held with late husband Derek Draper ran up debts of £2million

## Same old story! Half of BBC festive shows are repeats, final schedules reveal
 - [https://www.dailymail.co.uk/news/article-14155313/Half-BBC-festive-repeats-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155313/Half-BBC-festive-repeats-final.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:39:11+00:00

But TV viewers may be surprised to learn more than half the shows aired across BBC1 and BBC2 over the festive period will be repeats.

## Choc horror! Celebrations lovers are fuming after getting the same treat in their advent calendars for three days in a row - and it's 'the one children hate'
 - [https://www.dailymail.co.uk/news/article-14155183/Celebrations-fuming-treat-advent-calendars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155183/Celebrations-fuming-treat-advent-calendars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:39:06+00:00

Chocolate fans have been left furious after an unpopular chocolate has appeared in their advent calendar for three days in a row.

## The brutal reality of life under Anthony Albanese as economy grows at weakest pace in more than three decades
 - [https://www.dailymail.co.uk/news/article-14155161/The-brutal-reality-life-Anthony-Albanese-economy-grows-weakest-pace-three-decades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155161/The-brutal-reality-life-Anthony-Albanese-economy-grows-weakest-pace-three-decades.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:37:29+00:00

Australia's economy is now growing at the slowest pace since the early 1990s recession outside of a pandemic - despite record-high immigration.

## Claudia Lawrence's mother opens up about how the missing chef's childhood best friend was murdered and says 'they will be together now'
 - [https://www.dailymail.co.uk/news/article-14154447/Claudia-Lawrences-mother-opens-missing-chefs-childhood-best-friend-murdered-says-now.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154447/Claudia-Lawrences-mother-opens-missing-chefs-childhood-best-friend-murdered-says-now.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:34:11+00:00

Ms Lawrence was 35 when she was reported missing after failing to turn up for work at York University on March 18 2009.

## Buried in the classified section of a newspaper is a hastily written plea for help from older Australians, as a government decision threatens to upend their entire lives
 - [https://www.dailymail.co.uk/news/article-14154717/cheque-older-australians-online-banking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154717/cheque-older-australians-online-banking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:32:14+00:00

Older Australians have issued a desperate plea to stop the government from banning cheques with the once popular payment system set to be phased out by 2030.

## 'Drunk' mother, 44, who was escorted off a flight from Gran Canaria by police for hurling abuse at cabin crew just weeks after being caught drink driving avoids jail
 - [https://www.dailymail.co.uk/news/article-14155147/Drunk-mother-escorted-flight-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155147/Drunk-mother-escorted-flight-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:30:56+00:00

Shirley Devine, 44, launched into a foul-mouthed tirade whilst on a flight back to Manchester Airport after a family holiday on the Spanish island.

## 'Female' penguin is renamed after being misgendered for nearly a decade
 - [https://www.dailymail.co.uk/news/article-14155281/Female-penguin-renamed-misgendered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155281/Female-penguin-renamed-misgendered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:26:49+00:00

After Maggie the king penguin was brought in to help boost numbers at a Cotswolds wildlife park, keepers were left puzzled by the lack of success.

## 'Tis the season to be jolly cross playing family board games: Festive activity can lead to arguments and full-on relationship breakdowns
 - [https://www.dailymail.co.uk/news/article-14155279/family-board-games-arguments-relationship-breakdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155279/family-board-games-arguments-relationship-breakdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:26:31+00:00

Most Britons are prepared for conflict this Christmas - as family board games d escend into cheating, arguments and full-on relationship breakdowns.

## Why exhausted new mothers need not worry about their looks
 - [https://www.dailymail.co.uk/news/article-14155283/exhausted-new-mothers-need-not-worry-looks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155283/exhausted-new-mothers-need-not-worry-looks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:25:24+00:00

New parents - exhausted and preoccupied - are unlikely to feel at their most attractive

## DAILY MAIL COMMENT: Junk food ad ban is very hard to swallow
 - [https://www.dailymail.co.uk/news/article-14155253/DAILY-MAIL-COMMENT-Junk-food-ad-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155253/DAILY-MAIL-COMMENT-Junk-food-ad-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:24:05+00:00

DAILY MAIL COMMENT: It's true, of course, that too much sugar, fat, salt and ultra-processed food are not conducive to good health.

## Rye shooting victim's intimate prison chats with her jailbird lover just days before she was gunned down in botched armed raid on a home that left two dead
 - [https://www.dailymail.co.uk/news/melbourne/article-14154973/Rye-shooting-charli-hayter-jack-gilmour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/melbourne/article-14154973/Rye-shooting-charli-hayter-jack-gilmour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:19:13+00:00

Charlyze Hayter, 19, was killed when she and an unknown man armed with a rifle broke into the Rye home of tradie Jackson Gilmour, 29, on Victoria's Mornington Peninsula in the early hours of Monday.

## CNN correspondent says South Korea imposing martial law reminds her of Trump
 - [https://www.dailymail.co.uk/news/article-14154779/CNN-South-Korea-martial-law-Trump-MJ-Lee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154779/CNN-South-Korea-martial-law-Trump-MJ-Lee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:10:55+00:00

CNN correspondent MJ Lee compared South Korea under martial law to chaos under Donald Trump's presidency.

## Labour's prison release scheme could see criminals let out early for YEARS to come amid five-year jail-building delay
 - [https://www.dailymail.co.uk/news/article-14155239/Labours-prison-criminals-early-YEARS-jail-building-delay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155239/Labours-prison-criminals-early-YEARS-jail-building-delay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:02:05+00:00

The taxpayer will also be hit with an additional bill of at least £4.2billion to pay for an extra 21,000 prison places planned by the Ministry of Justice.

## EPHRAIM HARDCASTLE: Queen Camilla's health has been a concern since she returned from Australia and Samoa tour and led to her missing start of Qatari state visit
 - [https://www.dailymail.co.uk/news/article-14155237/EPHRAIM-HARDCASTLE-Queen-Camillas-health-Australia-Samoa-tour-missing-Qatari-state-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155237/EPHRAIM-HARDCASTLE-Queen-Camillas-health-Australia-Samoa-tour-missing-Qatari-state-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T01:00:49+00:00

EPHRAIM HARDCASTLE: Her Majesty suffers with long-distance travel. The journey home from the Pacific in October included a stopover in India for a restorative stay at a spa.

## Celebrity chef who endorsed Labour at the General Election warns Rachel Reeves's Budget will have a 'catastrophic effect' on his industry
 - [https://www.dailymail.co.uk/news/article-14155231/Tom-Kerridge-Labour-warns-Budget-catastrophic-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155231/Tom-Kerridge-Labour-warns-Budget-catastrophic-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:59:02+00:00

Tom Kerridge was one of 120 business figures who signed an open letter in May, saying it was time to 'give Labour a chance'.

## Pub giant that banned Australia Day celebrations still planning to slug customers with a public holiday surcharge
 - [https://www.dailymail.co.uk/news/article-14154683/australia-day-pub-ban-holiday-surcharge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154683/australia-day-pub-ban-holiday-surcharge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:40:55+00:00

Australian Venue Co won't commit to scrapping a 15 per cent public holiday surcharge despite initially banning Australia Day celebrations at more than 200 of its bar and pubs across the country.

## Violence in South Korea prompts UK Government to issue urgent warning to Brits as President Yoon is forced to backtrack on martial law
 - [https://www.dailymail.co.uk/news/article-14155089/violence-south-korea-urgent-warning-uk-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155089/violence-south-korea-urgent-warning-uk-government.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:34:36+00:00

Following the outburst of protests in Seoul last night, the Gov.uk website has stated: 'We are aware of the developing situation following a declaration of martial law in South Korea.

## Bernie Sanders says he supports Trump making Canada the 51st state... with a simple caveat
 - [https://www.dailymail.co.uk/news/article-14155021/bernie-sanders-canada-state-trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155021/bernie-sanders-canada-state-trump.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:29:39+00:00

Senator Bernie Sanders says he is 'all for it' for Canada joining the U.S. as  the 51st state, but he has one caveat for supporting Donald Trump in the move.

## ANSWERS TO CORRESPONDENTS: Do any other animals, apart from humans, use facial expressions to communicate?
 - [https://www.dailymail.co.uk/news/article-14155075/ANSWERS-CORRESPONDENTS-animals-humans-facial-expressions-communicate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155075/ANSWERS-CORRESPONDENTS-animals-humans-facial-expressions-communicate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:27:20+00:00

Many animals use facial expressions to communicate, although the complexity and nuances vary across groups and species.

## Christmas comes early for rail unions as South Western Railway is nationalised
 - [https://www.dailymail.co.uk/news/article-14155159/rail-unions-South-Western-Railway-nationalised.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155159/rail-unions-South-Western-Railway-nationalised.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:27:13+00:00

The SWR network, which connects Surrey, Hampshire, Berkshire and Dorset with London, will be renationalised in May 2025, the new Transport Secretary will announce today.

## Queen Camilla's son Tom Parker Bowles fumes at 'whiners and bleaters' at Santa Rita Cigar Smoker of The Year Dinner and Awards
 - [https://www.dailymail.co.uk/news/article-14155085/Queen-son-Tom-Parker-Bowles-whiners-bleaters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155085/Queen-son-Tom-Parker-Bowles-whiners-bleaters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:26:33+00:00

Tom Parker Bowles was in pugnacious mood at the Santa Rita Cigar Smoker of The Year Dinner and Awards in Canary Wharf, east London.

## The bizarre list of 'vital' workers the government says we need to import - but one key group doesn't make the cut
 - [https://www.dailymail.co.uk/news/article-14155055/New-Core-Skills-Occupation-List-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155055/New-Core-Skills-Occupation-List-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:22:06+00:00

The Australian government has listed yoga instructors, flower growers and beauty therapists as key workers the country needs to import but has left off certain key construction workers.

## Radical new plan proposed to solve Australia's drug problem
 - [https://www.dailymail.co.uk/news/article-14155139/Radical-new-plan-proposed-solve-Australias-drug-problem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14155139/Radical-new-plan-proposed-solve-Australias-drug-problem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:19:31+00:00

The mayor of a major American city has issued a warning in response to a radical proposal aimed at addressing the nation's drug problem.

## Fierce debate erupts over major Aussie expression: 'Tone deaf'
 - [https://www.dailymail.co.uk/news/article-14151457/Australia-lucky-country-divided-opinion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14151457/Australia-lucky-country-divided-opinion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:16:53+00:00

The local revealed how Australia had provided them and their friends a better life after moving from overseas.

## Megyn Kelly reveals how her drug addict sister was swept up in opioid crisis unlike 'spoiled brat' Hunter Biden
 - [https://www.dailymail.co.uk/news/article-14154799/Megyn-Kelly-drug-addict-sister-spoiled-brat-Hunter-Biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154799/Megyn-Kelly-drug-addict-sister-spoiled-brat-Hunter-Biden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:12:36+00:00

Megyn Kelly cited her late sister's loss to the opioid crisis in slamming 'spoiled f***ing brat' Hunter Biden after his father Joe gave him a shock presidential pardon .

## Influencer is arrested AGAIN for fleecing Target with sneaky checkout barcode hack as damning footage emerges
 - [https://www.dailymail.co.uk/news/article-14154987/Marlena-Velez-TikTok-influencer-arrested-fake-barcode-Target.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154987/Marlena-Velez-TikTok-influencer-arrested-fake-barcode-Target.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:08:56+00:00

Marlena Velez, 22, has been arrested a second time for stealing from her local Target in Cape Coral,  Florida - just 10 days after her arrest for stealing from the same store.

## Man, 21, wanted over 'murder' of Lancashire teenager arrested in Greece more than a year after youth's death
 - [https://www.dailymail.co.uk/news/article-14154975/Man-wanted-murder-Lancashire-teenager-arrested-Greece.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-14154975/Man-wanted-murder-Lancashire-teenager-arrested-Greece.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: $source
 - date published: 2024-12-04T00:01:11+00:00

Matthew Daulby, 19, from Liverpool, was killed in a double stabbing during a mass brawl in Ormskirk in 2023 and police have caught a man wanted over his death.

