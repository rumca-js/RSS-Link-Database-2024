# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Constitutional crisis: How do you vote out administrative bureaucracies?
 - [https://www.youtube.com/watch?v=Mcm1o8Ykq40](https://www.youtube.com/watch?v=Mcm1o8Ykq40)
 - RSS feed: $source
 - date published: 2024-12-04T22:30:04+00:00

#benshapiro #news #southkorea

## The Destruction of Norms and Institutions
 - [https://www.youtube.com/watch?v=7e-XCxFQuJY](https://www.youtube.com/watch?v=7e-XCxFQuJY)
 - RSS feed: $source
 - date published: 2024-12-04T22:30:01+00:00

PureTalk - Exclusive discount for our listeners at: https://www.PureTalk.com/Shapiro

Ben discusses the distrust of American institutions, such as the weaponization of the FBI, and how this helped Trump win the election. Ben goes on to mention the full-scale weaponization of law happening by one particular party in South Korea. He also talks about something good happening and something not-so-good happening. The good thing is President Trump is planning to attend the reopening of Notre Dame in Paris, but the no-so-good thing is the rare mineral export ban from China to the US. China is creating supply chain warfare by cutting down the ability of the US to obtain manufacturing materials. 

1️⃣ Click here to join the member-exclusive portion of my show: https://bit.ly/3WDjgHE

2️⃣ Our largest sale of the year is live NOW! Get 50% off New Annual Memberships this Cyber Week! https://dailywire.com/cyberweek

3️⃣ Matt Walsh’s hit documentary “Am I Racist?” is NOW AVAILABLE on DailyWire+! H

## For men to flourish, Socialism MUST be destroyed
 - [https://www.youtube.com/watch?v=AQNctxi8byU](https://www.youtube.com/watch?v=AQNctxi8byU)
 - RSS feed: $source
 - date published: 2024-12-04T22:15:00+00:00

#benshapiro #socialism #flourish

## We should all have the same right to take advantage of our OWN natural abilities
 - [https://www.youtube.com/watch?v=dL97Yb8t__Q](https://www.youtube.com/watch?v=dL97Yb8t__Q)
 - RSS feed: $source
 - date published: 2024-12-04T21:45:02+00:00

#benshapiro #lebronjames #rights

## The meaning behind the theory of socialism
 - [https://www.youtube.com/watch?v=lODU9_saB1w](https://www.youtube.com/watch?v=lODU9_saB1w)
 - RSS feed: $source
 - date published: 2024-12-04T21:00:38+00:00

#benshapiro #speech #socialism

## The President of South Korea is basically declaring dictatorial control
 - [https://www.youtube.com/watch?v=Ao387q2jCPk](https://www.youtube.com/watch?v=Ao387q2jCPk)
 - RSS feed: $source
 - date published: 2024-12-04T20:00:07+00:00

#benshapiro #southkorea #government

## WTF Just Happened In SOUTH KOREA?
 - [https://www.youtube.com/watch?v=Bo1vFSTpjLg](https://www.youtube.com/watch?v=Bo1vFSTpjLg)
 - RSS feed: $source
 - date published: 2024-12-04T18:00:06+00:00

The South Korean president briefly declares martial law as all hell breaks loose; President Trump says he’ll move to block the sale of US Steel to Nippon Steel; and China gets aggressive.

Ep.2097

- - -

1️⃣ Click here to join the member-exclusive portion of my show: https://bit.ly/3WDjgHE

2️⃣ Our largest sale of the year is live NOW! Get 50% off New Annual Memberships this Cyber Week! https://dailywire.com/cyberweek

3️⃣ Matt Walsh’s hit documentary “Am I Racist?” is NOW AVAILABLE on DailyWire+! Head to https://amiracist.com to become a member today!

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

Today's Sponsors:

PureTalk - Exclusive discount for our listeners at: https://www.PureTalk.com/Shapiro

Helix Sleep - Get an exclusive discount at https://helixsleep.com/Ben

NetSuite - Make better business decisions with NetSuite https://www.NetSuite.com/Shapiro

Legacybox - Shop Legacybox with my exclusive discount: https://www.legacybox.com/shapiro

Policygenius - Get you

## Limited-time offer: 50% off DailyWire+ annual plans. Hurry while the deal lasts.
 - [https://www.youtube.com/watch?v=mpeY2YisVbY](https://www.youtube.com/watch?v=mpeY2YisVbY)
 - RSS feed: $source
 - date published: 2024-12-04T17:00:49+00:00

#benshapiro #dailywireplus #cyberweek

## Hunter's pardon has given Trump POWERFUL ammunition
 - [https://www.youtube.com/watch?v=It-Ahr5qwc8](https://www.youtube.com/watch?v=It-Ahr5qwc8)
 - RSS feed: $source
 - date published: 2024-12-04T16:00:14+00:00

None

## Hunter Biden can't plead the Fifth!
 - [https://www.youtube.com/watch?v=J2ba9PypZmU](https://www.youtube.com/watch?v=J2ba9PypZmU)
 - RSS feed: $source
 - date published: 2024-12-04T04:00:09+00:00

None

## Whoopi Goldberg DEFENDS Joe Biden
 - [https://www.youtube.com/watch?v=m9M-Brcp9LM](https://www.youtube.com/watch?v=m9M-Brcp9LM)
 - RSS feed: $source
 - date published: 2024-12-04T02:00:32+00:00

None

## Charlamagne tha God says Democrats are ALSO breaking the systems
 - [https://www.youtube.com/watch?v=CBivmdSh2Z4](https://www.youtube.com/watch?v=CBivmdSh2Z4)
 - RSS feed: $source
 - date published: 2024-12-04T00:30:11+00:00

Democrats aren't the pure party they think they are

## Trump's Stance Against Hamas
 - [https://www.youtube.com/watch?v=uN0g2KAG838](https://www.youtube.com/watch?v=uN0g2KAG838)
 - RSS feed: $source
 - date published: 2024-12-04T00:00:37+00:00

Ben discusses how Trump’s foreign policy will be different from Biden’s and the recent stance Trump has already taken against Hamas holding hostages. Since Hamas cares most about grabbing more territory, a proposal was put forward to suggest recognizing parts of Gaza as a permanent Israeli buffer zone if Hamas does not give up the hostages. He also talks about the ceasefire that was violated by Hezbollah when they fired at Israeli-controlled territory this week.

1️⃣ Click here to join the member-exclusive portion of my show: https://bit.ly/3WDjgHE

2️⃣ Our largest sale of the year is live NOW! Get 50% off New Annual Memberships this Cyber Week! https://dailywire.com/cyberweek

3️⃣ Matt Walsh’s hit documentary “Am I Racist?” is NOW AVAILABLE on DailyWire+! Head to https://amiracist.com to become a member today!

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

## Dems keep breaking the norms for THEIR OWN benefit
 - [https://www.youtube.com/watch?v=KxX1totBEm0](https://www.youtube.com/watch?v=KxX1totBEm0)
 - RSS feed: $source
 - date published: 2024-12-04T00:00:12+00:00

None

