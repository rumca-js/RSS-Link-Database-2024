# Source:Reddit - World News, URL:https://www.reddit.com/r/worldnews/.rss, language:en

## South Korea's Parliament introduces bill to impeach President
 - [https://www.reddit.com/r/worldnews/comments/1h6rrbd/south_koreas_parliament_introduces_bill_to](https://www.reddit.com/r/worldnews/comments/1h6rrbd/south_koreas_parliament_introduces_bill_to)
 - RSS feed: $source
 - date published: 2024-12-04T21:29:34+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6rrbd/south_koreas_parliament_introduces_bill_to/"> <img src="https://external-preview.redd.it/ljuVCweBF3KFywUlwB-Fb-mjllR_czVVN_0QSrJPhQU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a188834ede707265a16fcc479df0aedec287e055" alt="South Korea's Parliament introduces bill to impeach President" title="South Korea's Parliament introduces bill to impeach President" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/alabasterheart"> /u/alabasterheart </a> <br/> <span><a href="https://newsukraine.rbc.ua/news/south-korea-s-parliament-introduces-bill-1733338298.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6rrbd/south_koreas_parliament_introduces_bill_to/">[comments]</a></span> </td></tr></table>

## U.S. acts against financial network enabling Russian elites to avoid sanctions - UPI.com
 - [https://www.reddit.com/r/worldnews/comments/1h6quud/us_acts_against_financial_network_enabling](https://www.reddit.com/r/worldnews/comments/1h6quud/us_acts_against_financial_network_enabling)
 - RSS feed: $source
 - date published: 2024-12-04T20:52:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6quud/us_acts_against_financial_network_enabling/"> <img src="https://external-preview.redd.it/uoQeB8D7LVBiwgP2bAvEcg-h7cm2maa7IEU9OK_fPKM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f5885dc5e17157d3c414b1c41bbf85100b6963f9" alt="U.S. acts against financial network enabling Russian elites to avoid sanctions - UPI.com" title="U.S. acts against financial network enabling Russian elites to avoid sanctions - UPI.com" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Jake1125"> /u/Jake1125 </a> <br/> <span><a href="https://www.upi.com/Top_News/World-News/2024/12/04/Russia-sanctions-Treasury-TGR/2661733330602/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6quud/us_acts_against_financial_network_enabling/">[comments]</a></span> </td></tr></table>

## French government toppled in historic no-confidence vote
 - [https://www.reddit.com/r/worldnews/comments/1h6ov0y/french_government_toppled_in_historic](https://www.reddit.com/r/worldnews/comments/1h6ov0y/french_government_toppled_in_historic)
 - RSS feed: $source
 - date published: 2024-12-04T19:31:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6ov0y/french_government_toppled_in_historic/"> <img src="https://external-preview.redd.it/ykUY_mic1lrUrkLhzTBoEoqHyAkk6ZVejPAz68eFqho.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ff7c2cb42be8f156efc431873ba7202eaf099c2a" alt="French government toppled in historic no-confidence vote" title="French government toppled in historic no-confidence vote" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Lanathell"> /u/Lanathell </a> <br/> <span><a href="https://www.lemonde.fr/en/france/article/2024/12/04/french-government-toppled-in-historic-no-confidence-vote_6735189_7.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6ov0y/french_government_toppled_in_historic/">[comments]</a></span> </td></tr></table>

## Romania was target of 'aggressive hybrid Russian attacks' during elections, security council says
 - [https://www.reddit.com/r/worldnews/comments/1h6o4rg/romania_was_target_of_aggressive_hybrid_russian](https://www.reddit.com/r/worldnews/comments/1h6o4rg/romania_was_target_of_aggressive_hybrid_russian)
 - RSS feed: $source
 - date published: 2024-12-04T19:02:58+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/notaromanian"> /u/notaromanian </a> <br/> <span><a href="https://www.reuters.com/world/europe/romania-was-target-aggressive-hybrid-russian-attacks-during-elections-security-2024-12-04/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6o4rg/romania_was_target_of_aggressive_hybrid_russian/">[comments]</a></span>

## EU moves to ban smoking and vaping in outdoor spaces
 - [https://www.reddit.com/r/worldnews/comments/1h6nxe0/eu_moves_to_ban_smoking_and_vaping_in_outdoor](https://www.reddit.com/r/worldnews/comments/1h6nxe0/eu_moves_to_ban_smoking_and_vaping_in_outdoor)
 - RSS feed: $source
 - date published: 2024-12-04T18:55:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6nxe0/eu_moves_to_ban_smoking_and_vaping_in_outdoor/"> <img src="https://external-preview.redd.it/Bf_kVZyKaQiEeyCnPgj9ThaokyWu0jj8NohY9oylWNA.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8f9c0a3f919359a2706e5eaac3d01827eef931fd" alt="EU moves to ban smoking and vaping in outdoor spaces" title="EU moves to ban smoking and vaping in outdoor spaces" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DoremusJessup"> /u/DoremusJessup </a> <br/> <span><a href="https://www.rfi.fr/en/international-news/20241203-eu-countries-to-push-for-outdoor-smoking-and-vaping-bans">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6nxe0/eu_moves_to_ban_smoking_and_vaping_in_outdoor/">[comments]</a></span> </td></tr></table>

## Mexico says Canada wishes it had its ‘cultural riches’ amid tariffs feud
 - [https://www.reddit.com/r/worldnews/comments/1h6nwyh/mexico_says_canada_wishes_it_had_its_cultural](https://www.reddit.com/r/worldnews/comments/1h6nwyh/mexico_says_canada_wishes_it_had_its_cultural)
 - RSS feed: $source
 - date published: 2024-12-04T18:54:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6nwyh/mexico_says_canada_wishes_it_had_its_cultural/"> <img src="https://external-preview.redd.it/pPK6dmy8W0n8my94MLiWrfEwIaTeUDFP2b2To06xG_8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=5ff860cd00d9c9f249837e1b678da99017f28aa7" alt="Mexico says Canada wishes it had its ‘cultural riches’ amid tariffs feud" title="Mexico says Canada wishes it had its ‘cultural riches’ amid tariffs feud" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DomesticErrorist22"> /u/DomesticErrorist22 </a> <br/> <span><a href="https://www.theguardian.com/world/2024/dec/04/mexico-canada-trump-tariffs-feud?CMP=Share_AndroidApp_Other">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6nwyh/mexico_says_canada_wishes_it_had_its_cultural/">[comments]</a></span> </td></tr></table>

## Biden administration announces additional $725m in military assistance to Ukraine
 - [https://www.reddit.com/r/worldnews/comments/1h6n1cz/biden_administration_announces_additional_725m_in](https://www.reddit.com/r/worldnews/comments/1h6n1cz/biden_administration_announces_additional_725m_in)
 - RSS feed: $source
 - date published: 2024-12-04T18:19:24+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6n1cz/biden_administration_announces_additional_725m_in/"> <img src="https://external-preview.redd.it/55ia89eHZu9BQL1_vbZyPdvac0K-e4acf0-udbCGRbc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=024ef489f7f0d6b7cdc3cd9c27e8f44b3d9d71a6" alt="Biden administration announces additional $725m in military assistance to Ukraine" title="Biden administration announces additional $725m in military assistance to Ukraine" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Yveliad"> /u/Yveliad </a> <br/> <span><a href="https://www.theguardian.com/world/2024/dec/03/biden-ukraine-russia-trump-military-assistance">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6n1cz/biden_administration_announces_additional_725m_in/">[comments]</a></span> </td></tr></table>

## NATO ally vows to put Ukraine in 'strongest position for peace talks'
 - [https://www.reddit.com/r/worldnews/comments/1h6mn1u/nato_ally_vows_to_put_ukraine_in_strongest](https://www.reddit.com/r/worldnews/comments/1h6mn1u/nato_ally_vows_to_put_ukraine_in_strongest)
 - RSS feed: $source
 - date published: 2024-12-04T18:03:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6mn1u/nato_ally_vows_to_put_ukraine_in_strongest/"> <img src="https://external-preview.redd.it/_xQ2KvhL7SSOBA8XBpcdxXIVbfd_X4qpcE_8bcNtG_4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=67cd1b6bd0c4a46b30017694493387c90244602c" alt="NATO ally vows to put Ukraine in 'strongest position for peace talks'" title="NATO ally vows to put Ukraine in 'strongest position for peace talks'" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/newsweek"> /u/newsweek </a> <br/> <span><a href="https://www.newsweek.com/nato-starmer-uk-ukraine-strongest-position-peace-talks-1995423">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6mn1u/nato_ally_vows_to_put_ukraine_in_strongest/">[comments]</a></span> </td></tr></table>

## Frontline report: Russian soldiers' life expectancy near Myrnohrad in Donetsk Oblast plummets to two weeks amid failed assaults - Euromaidan Press
 - [https://www.reddit.com/r/worldnews/comments/1h6m2x8/frontline_report_russian_soldiers_life_expectancy](https://www.reddit.com/r/worldnews/comments/1h6m2x8/frontline_report_russian_soldiers_life_expectancy)
 - RSS feed: $source
 - date published: 2024-12-04T17:42:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6m2x8/frontline_report_russian_soldiers_life_expectancy/"> <img src="https://external-preview.redd.it/Dd_ekUjKVxHsyUP1vFQWthJ4lJj5O-S7ePnpVJ7yn-o.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2c08b476007641ce756216c13a28991640192fbf" alt="Frontline report: Russian soldiers' life expectancy near Myrnohrad in Donetsk Oblast plummets to two weeks amid failed assaults - Euromaidan Press" title="Frontline report: Russian soldiers' life expectancy near Myrnohrad in Donetsk Oblast plummets to two weeks amid failed assaults - Euromaidan Press" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Silly-avocatoe"> /u/Silly-avocatoe </a> <br/> <span><a href="https://euromaidanpress.com/2024/12/04/frontline-report-russian-soldiers-life-expectancy-near-myrnohrad-in-donetsk-oblast-plummets-to-two-weeks-amid-failed-assaults/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews

## South Korean Protesters Thwarted More than Just a Coup Attempt
 - [https://www.reddit.com/r/worldnews/comments/1h6m1sj/south_korean_protesters_thwarted_more_than_just_a](https://www.reddit.com/r/worldnews/comments/1h6m1sj/south_korean_protesters_thwarted_more_than_just_a)
 - RSS feed: $source
 - date published: 2024-12-04T17:40:51+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6m1sj/south_korean_protesters_thwarted_more_than_just_a/"> <img src="https://external-preview.redd.it/lOBak364mcrsey8Xoz1X802d4zz6juX2Da2L5DkjZvo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ae85bd59ae08550319b3ef0afc1da7570cddbddb" alt="South Korean Protesters Thwarted More than Just a Coup Attempt" title="South Korean Protesters Thwarted More than Just a Coup Attempt" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/thenationmagazine"> /u/thenationmagazine </a> <br/> <span><a href="https://www.thenation.com/article/world/south-korea-yoon-suk-yeol-coup-impeachment-protests/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6m1sj/south_korean_protesters_thwarted_more_than_just_a/">[comments]</a></span> </td></tr></table>

## Ceo of United Healthcare fatally shot, motive is still unknown as suspect is at large
 - [https://www.reddit.com/r/worldnews/comments/1h6lyef/ceo_of_united_healthcare_fatally_shot_motive_is](https://www.reddit.com/r/worldnews/comments/1h6lyef/ceo_of_united_healthcare_fatally_shot_motive_is)
 - RSS feed: $source
 - date published: 2024-12-04T17:37:10+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6lyef/ceo_of_united_healthcare_fatally_shot_motive_is/"> <img src="https://external-preview.redd.it/WT4gL5v7gUrwac0KV-x_hQN-gwrTklJH17KyovEYmE4.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d4839540c7bf2e504d76b9d9f07e244ea8a7f854" alt="Ceo of United Healthcare fatally shot, motive is still unknown as suspect is at large" title="Ceo of United Healthcare fatally shot, motive is still unknown as suspect is at large" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/redfalcon1000"> /u/redfalcon1000 </a> <br/> <span><a href="https://edition.cnn.com/2024/12/04/us/brian-thompson-united-healthcare-death/index.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6lyef/ceo_of_united_healthcare_fatally_shot_motive_is/">[comments]</a></span> </td></tr></table>

## Germany’s cybersecurity and infrastructure under attack by Russia, attacks “also come from China from time to time,” Olaf Scholz told lawmakers in parliament
 - [https://www.reddit.com/r/worldnews/comments/1h6l4jt/germanys_cybersecurity_and_infrastructure_under](https://www.reddit.com/r/worldnews/comments/1h6l4jt/germanys_cybersecurity_and_infrastructure_under)
 - RSS feed: $source
 - date published: 2024-12-04T17:04:31+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6l4jt/germanys_cybersecurity_and_infrastructure_under/"> <img src="https://external-preview.redd.it/qc3vt1t4MZryYvh6veIVJ4Wygn3OZWAMyON9GDcrZLM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3ee0ec94b684c63eb38860a46cf6c978395d3e4d" alt="Germany’s cybersecurity and infrastructure under attack by Russia, attacks “also come from China from time to time,” Olaf Scholz told lawmakers in parliament" title="Germany’s cybersecurity and infrastructure under attack by Russia, attacks “also come from China from time to time,” Olaf Scholz told lawmakers in parliament" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/giuliomagnifico"> /u/giuliomagnifico </a> <br/> <span><a href="https://www.politico.eu/article/olaf-scholz-germany-cyber-security-infrastructure-under-severe-threat-russia-china/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6l4jt/germanys_c

## British army could be wiped out within six months of Ukraine-scale war, British minister warns
 - [https://www.reddit.com/r/worldnews/comments/1h6kp5g/british_army_could_be_wiped_out_within_six_months](https://www.reddit.com/r/worldnews/comments/1h6kp5g/british_army_could_be_wiped_out_within_six_months)
 - RSS feed: $source
 - date published: 2024-12-04T16:47:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6kp5g/british_army_could_be_wiped_out_within_six_months/"> <img src="https://external-preview.redd.it/EEdtopwn_F8s1Ia0iL1QpJPy6pLlkDpJQtu5gO_pj1w.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2501efbbf6021b2e230f2073f665c9869f566b44" alt="British army could be wiped out within six months of Ukraine-scale war, British minister warns" title="British army could be wiped out within six months of Ukraine-scale war, British minister warns" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/blllrrrrr"> /u/blllrrrrr </a> <br/> <span><a href="https://www.theguardian.com/uk-news/2024/dec/04/british-army-could-be-wiped-out-within-six-months-of-ukraine-scale-war-minister-warns">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6kp5g/british_army_could_be_wiped_out_within_six_months/">[comments]</a></span> </td></tr></table>

## Canadian miners use China's rare metals ban to push back on Trump tariffs
 - [https://www.reddit.com/r/worldnews/comments/1h6kork/canadian_miners_use_chinas_rare_metals_ban_to](https://www.reddit.com/r/worldnews/comments/1h6kork/canadian_miners_use_chinas_rare_metals_ban_to)
 - RSS feed: $source
 - date published: 2024-12-04T16:47:19+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6kork/canadian_miners_use_chinas_rare_metals_ban_to/"> <img src="https://external-preview.redd.it/ZFeNtwcJfLAPe2pitxImEMDp7tqcla0uf4xl00q4tLs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=01a3780b67e01bb173e646325912a6bcffaed979" alt="Canadian miners use China's rare metals ban to push back on Trump tariffs" title="Canadian miners use China's rare metals ban to push back on Trump tariffs" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/joe4942"> /u/joe4942 </a> <br/> <span><a href="https://financialpost.com/commodities/mining/canada-miners-china-metals-ban-push-back-trump-tariffs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6kork/canadian_miners_use_chinas_rare_metals_ban_to/">[comments]</a></span> </td></tr></table>

## Putin-controlled aircraft deported Ukrainian children, US-backed research alleges
 - [https://www.reddit.com/r/worldnews/comments/1h6k7vr/putincontrolled_aircraft_deported_ukrainian](https://www.reddit.com/r/worldnews/comments/1h6k7vr/putincontrolled_aircraft_deported_ukrainian)
 - RSS feed: $source
 - date published: 2024-12-04T16:28:36+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/IntlDogOfMystery"> /u/IntlDogOfMystery </a> <br/> <span><a href="https://www.reuters.com/world/europe/putin-controlled-aircraft-deported-ukrainian-children-us-backed-research-alleges-2024-12-03/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6k7vr/putincontrolled_aircraft_deported_ukrainian/">[comments]</a></span>

## Taliban bans women from training as nurses and midwives
 - [https://www.reddit.com/r/worldnews/comments/1h6jlln/taliban_bans_women_from_training_as_nurses_and](https://www.reddit.com/r/worldnews/comments/1h6jlln/taliban_bans_women_from_training_as_nurses_and)
 - RSS feed: $source
 - date published: 2024-12-04T16:03:46+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6jlln/taliban_bans_women_from_training_as_nurses_and/"> <img src="https://external-preview.redd.it/0qpvoHPCuFOx1ahTpCHo878J_GjNwRqQcR6EL_ZCy1I.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=caa0e574bc517a877c38792643513aac86ba2092" alt="Taliban bans women from training as nurses and midwives" title="Taliban bans women from training as nurses and midwives" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/TheTelegraph"> /u/TheTelegraph </a> <br/> <span><a href="https://www.telegraph.co.uk/world-news/2024/12/04/taliban-bans-women-from-training-as-nurses-and-midwives/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6jlln/taliban_bans_women_from_training_as_nurses_and/">[comments]</a></span> </td></tr></table>

## Hamas threatens to 'neutralize' hostages if Israel launches rescue operation
 - [https://www.reddit.com/r/worldnews/comments/1h6ibbw/hamas_threatens_to_neutralize_hostages_if_israel](https://www.reddit.com/r/worldnews/comments/1h6ibbw/hamas_threatens_to_neutralize_hostages_if_israel)
 - RSS feed: $source
 - date published: 2024-12-04T15:11:42+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/xKyoshirax"> /u/xKyoshirax </a> <br/> <span><a href="https://www.reuters.com/world/middle-east/hamas-threatens-neutralize-hostages-if-israel-launches-rescue-hamas-internal-2024-12-04/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6ibbw/hamas_threatens_to_neutralize_hostages_if_israel/">[comments]</a></span>

## IDF: Hamas likely executed six hostages in Khan Yunis as soldiers drew near
 - [https://www.reddit.com/r/worldnews/comments/1h6i57g/idf_hamas_likely_executed_six_hostages_in_khan](https://www.reddit.com/r/worldnews/comments/1h6i57g/idf_hamas_likely_executed_six_hostages_in_khan)
 - RSS feed: $source
 - date published: 2024-12-04T15:04:35+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6i57g/idf_hamas_likely_executed_six_hostages_in_khan/"> <img src="https://external-preview.redd.it/UHPnwwzNwTGjFLfzqgp4OLbYWQdJeRBCDFgcQKmXMDo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=13a253874aab444fe7629d5a5243e09f431fe92b" alt="IDF: Hamas likely executed six hostages in Khan Yunis as soldiers drew near" title="IDF: Hamas likely executed six hostages in Khan Yunis as soldiers drew near" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Red_Franklin"> /u/Red_Franklin </a> <br/> <span><a href="https://www.jpost.com/israel-news/article-831960">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6i57g/idf_hamas_likely_executed_six_hostages_in_khan/">[comments]</a></span> </td></tr></table>

## South Korea opposition files motion to impeach President Yoon
 - [https://www.reddit.com/r/worldnews/comments/1h6i52v/south_korea_opposition_files_motion_to_impeach](https://www.reddit.com/r/worldnews/comments/1h6i52v/south_korea_opposition_files_motion_to_impeach)
 - RSS feed: $source
 - date published: 2024-12-04T15:04:26+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6i52v/south_korea_opposition_files_motion_to_impeach/"> <img src="https://external-preview.redd.it/i2A3_WEpSOX5eRUGPC06OYxi8G7Xy2d1rOb-a9I7ZOM.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=49e6043859f424e0ef2e9f8b136a6e3eb2ca4940" alt="South Korea opposition files motion to impeach President Yoon" title="South Korea opposition files motion to impeach President Yoon" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/GeoWa"> /u/GeoWa </a> <br/> <span><a href="https://www.bbc.com/news/articles/c8rjd064012o">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6i52v/south_korea_opposition_files_motion_to_impeach/">[comments]</a></span> </td></tr></table>

## Georgia protests gather momentum after pro-Russia party suspends E.U. bid
 - [https://www.reddit.com/r/worldnews/comments/1h6hi0l/georgia_protests_gather_momentum_after_prorussia](https://www.reddit.com/r/worldnews/comments/1h6hi0l/georgia_protests_gather_momentum_after_prorussia)
 - RSS feed: $source
 - date published: 2024-12-04T14:37:08+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6hi0l/georgia_protests_gather_momentum_after_prorussia/"> <img src="https://external-preview.redd.it/VCdEXSNtKsP3_82-KxQ-sfHLxf9f9qlkYj3Tuv6j6YU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=a1a36db1c818384d6e98c5c762b105a0fc19fe8f" alt="Georgia protests gather momentum after pro-Russia party suspends E.U. bid " title="Georgia protests gather momentum after pro-Russia party suspends E.U. bid " /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/washingtonpost"> /u/washingtonpost </a> <br/> <span><a href="https://www.washingtonpost.com/world/2024/12/04/georgia-european-union-protests-russia/?utm_campaign=wp_main&amp;utm_medium=social&amp;utm_source=reddit.com">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6hi0l/georgia_protests_gather_momentum_after_prorussia/">[comments]</a></span> </td></tr></table>

## Putin's cousin scolded for Revealing classified war casualty figures
 - [https://www.reddit.com/r/worldnews/comments/1h6h1fn/putins_cousin_scolded_for_revealing_classified](https://www.reddit.com/r/worldnews/comments/1h6h1fn/putins_cousin_scolded_for_revealing_classified)
 - RSS feed: $source
 - date published: 2024-12-04T14:16:52+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6h1fn/putins_cousin_scolded_for_revealing_classified/"> <img src="https://external-preview.redd.it/1l1uRG-9CC9BvObH3D5OmjOi9Y9KO4mjaD0wn7xQ-os.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3c7eced23ab5d7216c03f45ad51cb6353d624c0f" alt="Putin's cousin scolded for Revealing classified war casualty figures" title="Putin's cousin scolded for Revealing classified war casualty figures" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/NaiE007"> /u/NaiE007 </a> <br/> <span><a href="https://www.newsweek.com/putin-cousin-classified-mistake-1995360">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6h1fn/putins_cousin_scolded_for_revealing_classified/">[comments]</a></span> </td></tr></table>

## Anti-authoritarian group The Satanic Temple deemed ‘undesirable’ in Russia
 - [https://www.reddit.com/r/worldnews/comments/1h6gnbs/antiauthoritarian_group_the_satanic_temple_deemed](https://www.reddit.com/r/worldnews/comments/1h6gnbs/antiauthoritarian_group_the_satanic_temple_deemed)
 - RSS feed: $source
 - date published: 2024-12-04T14:00:03+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6gnbs/antiauthoritarian_group_the_satanic_temple_deemed/"> <img src="https://external-preview.redd.it/5OR_n_1hJBRuHvZs6CumTfBVd1kKS9h8BfhVCgHeqPg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f5258cd87016b71909ecd0f22ffa2bd2f0be62a1" alt="Anti-authoritarian group The Satanic Temple deemed ‘undesirable’ in Russia" title="Anti-authoritarian group The Satanic Temple deemed ‘undesirable’ in Russia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/shellfishb"> /u/shellfishb </a> <br/> <span><a href="https://novayagazeta.eu/articles/2024/12/04/anti-authoritarian-group-the-satanic-temple-deemed-undesirable-in-russia-en-news">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6gnbs/antiauthoritarian_group_the_satanic_temple_deemed/">[comments]</a></span> </td></tr></table>

## Ukraine Scales Up Domestic Production of Neptune Missiles and Palianytsia Rocket Drones
 - [https://www.reddit.com/r/worldnews/comments/1h6gdix/ukraine_scales_up_domestic_production_of_neptune](https://www.reddit.com/r/worldnews/comments/1h6gdix/ukraine_scales_up_domestic_production_of_neptune)
 - RSS feed: $source
 - date published: 2024-12-04T13:47:07+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6gdix/ukraine_scales_up_domestic_production_of_neptune/"> <img src="https://external-preview.redd.it/uZt2P4LqUiaNEhsmGMvuOdLFStXFBQ7kV6v0nZLTuiQ.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0bad87be917d89dda777805ceaddc7843645fc9e" alt="Ukraine Scales Up Domestic Production of Neptune Missiles and Palianytsia Rocket Drones" title="Ukraine Scales Up Domestic Production of Neptune Missiles and Palianytsia Rocket Drones" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Beautiful-Hat-8625"> /u/Beautiful-Hat-8625 </a> <br/> <span><a href="https://united24media.com/latest-news/ukraine-scales-up-domestic-production-of-neptune-missiles-and-palyanytsya-rocket-drones-4216">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6gdix/ukraine_scales_up_domestic_production_of_neptune/">[comments]</a></span> </td></tr></table>

## Russia’s Hand Is Seen in Multiple Global Conflicts, Says UK Foreign Secretary Lammy
 - [https://www.reddit.com/r/worldnews/comments/1h6gbui/russias_hand_is_seen_in_multiple_global_conflicts](https://www.reddit.com/r/worldnews/comments/1h6gbui/russias_hand_is_seen_in_multiple_global_conflicts)
 - RSS feed: $source
 - date published: 2024-12-04T13:44:53+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6gbui/russias_hand_is_seen_in_multiple_global_conflicts/"> <img src="https://external-preview.redd.it/eT_zwwKk-2wFWa8Tw6GDkCyev7O-M3fSVSGJ4mSV7Kg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8acc8b6290fde81c5e7002d538341ee37b4b1bce" alt="Russia’s Hand Is Seen in Multiple Global Conflicts, Says UK Foreign Secretary Lammy" title="Russia’s Hand Is Seen in Multiple Global Conflicts, Says UK Foreign Secretary Lammy" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Desperate-Boss5152"> /u/Desperate-Boss5152 </a> <br/> <span><a href="https://united24media.com/latest-news/russias-hand-is-seen-in-multiple-global-conflicts-says-uk-foreign-secretary-lammy-4218">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6gbui/russias_hand_is_seen_in_multiple_global_conflicts/">[comments]</a></span> </td></tr></table>

## Cuba's electric grid collapses after power plant failure, millions without light
 - [https://www.reddit.com/r/worldnews/comments/1h6g5u9/cubas_electric_grid_collapses_after_power_plant](https://www.reddit.com/r/worldnews/comments/1h6g5u9/cubas_electric_grid_collapses_after_power_plant)
 - RSS feed: $source
 - date published: 2024-12-04T13:36:52+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/trevor25"> /u/trevor25 </a> <br/> <span><a href="https://www.reuters.com/world/americas/cubas-electric-grid-collapses-after-power-plant-failure-2024-12-04/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6g5u9/cubas_electric_grid_collapses_after_power_plant/">[comments]</a></span>

## Russian warship 'fires flares" at German helicopter: NATO reconnaissance aircraft incident over Baltic Sea sparks new conflict escalation fears
 - [https://www.reddit.com/r/worldnews/comments/1h6fxnk/russian_warship_fires_flares_at_german_helicopter](https://www.reddit.com/r/worldnews/comments/1h6fxnk/russian_warship_fires_flares_at_german_helicopter)
 - RSS feed: $source
 - date published: 2024-12-04T13:26:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6fxnk/russian_warship_fires_flares_at_german_helicopter/"> <img src="https://external-preview.redd.it/QaKH-eac9ALmAVVyH7eIFdZ4qXPzOyYY09rgkxwJxVs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=f00fa3b016301eac26d685e0358eecba4cc3117b" alt="Russian warship 'fires flares&quot; at German helicopter: NATO reconnaissance aircraft incident over Baltic Sea sparks new conflict escalation fears" title="Russian warship 'fires flares&quot; at German helicopter: NATO reconnaissance aircraft incident over Baltic Sea sparks new conflict escalation fears" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BringbackDreamBars"> /u/BringbackDreamBars </a> <br/> <span><a href="https://www.dailymail.co.uk/news/article-14157167/Russian-warship-fires-German-helicopter-WW3.html">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6fxnk/russian_warship_fires_flares_at_germa

## NATO Ordnance Factory to be Built on Russia's Doorstep
 - [https://www.reddit.com/r/worldnews/comments/1h6fivy/nato_ordnance_factory_to_be_built_on_russias](https://www.reddit.com/r/worldnews/comments/1h6fivy/nato_ordnance_factory_to_be_built_on_russias)
 - RSS feed: $source
 - date published: 2024-12-04T13:06:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6fivy/nato_ordnance_factory_to_be_built_on_russias/"> <img src="https://external-preview.redd.it/o7b31uW9EkKy47tXZvfcXDZw72GLPIE0JblbUPqjvpk.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=8535b903fd91dd323d74c376e792326435a6fec7" alt="NATO Ordnance Factory to be Built on Russia's Doorstep" title="NATO Ordnance Factory to be Built on Russia's Doorstep" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/IntlDogOfMystery"> /u/IntlDogOfMystery </a> <br/> <span><a href="https://nationalinterest.org/blog/buzz/nato-ordnance-factory-be-built-russias-doorstep-213978">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6fivy/nato_ordnance_factory_to_be_built_on_russias/">[comments]</a></span> </td></tr></table>

## Police illegally sell restricted weapons supplying crime
 - [https://www.reddit.com/r/worldnews/comments/1h6fhox/police_illegally_sell_restricted_weapons](https://www.reddit.com/r/worldnews/comments/1h6fhox/police_illegally_sell_restricted_weapons)
 - RSS feed: $source
 - date published: 2024-12-04T13:04:22+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6fhox/police_illegally_sell_restricted_weapons/"> <img src="https://external-preview.redd.it/PpTN_l3LrHdHXQz4ghJNszw0-emAXn1EsLXlAlLiuNs.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=9c0c53a58a612e951d5ef5a045d961c10dfff2d2" alt="Police illegally sell restricted weapons supplying crime" title="Police illegally sell restricted weapons supplying crime" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Ok_Jicama_4079"> /u/Ok_Jicama_4079 </a> <br/> <span><a href="https://www.cbsnews.com/news/police-selling-restricted-guns-posties/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6fhox/police_illegally_sell_restricted_weapons/">[comments]</a></span> </td></tr></table>

## Mayor of town in Zaporizhzhia Oblast abducted by Russians in March 2022 dies in captivity
 - [https://www.reddit.com/r/worldnews/comments/1h6exg3/mayor_of_town_in_zaporizhzhia_oblast_abducted_by](https://www.reddit.com/r/worldnews/comments/1h6exg3/mayor_of_town_in_zaporizhzhia_oblast_abducted_by)
 - RSS feed: $source
 - date published: 2024-12-04T12:34:06+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6exg3/mayor_of_town_in_zaporizhzhia_oblast_abducted_by/"> <img src="https://external-preview.redd.it/AbNCpD1QsUMdorcrGO3pa9UbJb0Vn_y-JTqPfftR2iU.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=3a59ed5d22c2c7a458b80ea40dece7b34cdbf738" alt="Mayor of town in Zaporizhzhia Oblast abducted by Russians in March 2022 dies in captivity" title="Mayor of town in Zaporizhzhia Oblast abducted by Russians in March 2022 dies in captivity" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/BigDaddy0790"> /u/BigDaddy0790 </a> <br/> <span><a href="https://www.pravda.com.ua/eng/news/2024/12/4/7487574/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6exg3/mayor_of_town_in_zaporizhzhia_oblast_abducted_by/">[comments]</a></span> </td></tr></table>

## Up to 100 ‘suspicious incidents’ in Europe can be attributed to Russia, Czech minister says
 - [https://www.reddit.com/r/worldnews/comments/1h6e7qg/up_to_100_suspicious_incidents_in_europe_can_be](https://www.reddit.com/r/worldnews/comments/1h6e7qg/up_to_100_suspicious_incidents_in_europe_can_be)
 - RSS feed: $source
 - date published: 2024-12-04T11:51:11+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6e7qg/up_to_100_suspicious_incidents_in_europe_can_be/"> <img src="https://external-preview.redd.it/8O0qXY4gOp6QrQhA7pug7aT755C350ddZbbqVkK4ZDE.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=01c70646c31b668c50a7d42bb151cfd1d5ce2015" alt="Up to 100 ‘suspicious incidents’ in Europe can be attributed to Russia, Czech minister says" title="Up to 100 ‘suspicious incidents’ in Europe can be attributed to Russia, Czech minister says" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/zsreport"> /u/zsreport </a> <br/> <span><a href="https://www.theguardian.com/world/2024/dec/04/up-to-100-suspicious-incidents-in-europe-can-be-attributed-to-russia-czech-minister-says">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6e7qg/up_to_100_suspicious_incidents_in_europe_can_be/">[comments]</a></span> </td></tr></table>

## Protests explode in Georgia over paused bid for EU membership. President accuses Russia
 - [https://www.reddit.com/r/worldnews/comments/1h6e4fg/protests_explode_in_georgia_over_paused_bid_for](https://www.reddit.com/r/worldnews/comments/1h6e4fg/protests_explode_in_georgia_over_paused_bid_for)
 - RSS feed: $source
 - date published: 2024-12-04T11:45:17+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6e4fg/protests_explode_in_georgia_over_paused_bid_for/"> <img src="https://external-preview.redd.it/EtcJMcBFJ6VCKB1F-SBexEDpBzeLoV-9RZoAfhK0kUw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=231a1659e2fcd56e18ca87f9219c238651e4e3ee" alt="Protests explode in Georgia over paused bid for EU membership. President accuses Russia" title="Protests explode in Georgia over paused bid for EU membership. President accuses Russia" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MothersMiIk"> /u/MothersMiIk </a> <br/> <span><a href="https://www.usatoday.com/story/news/world/2024/12/02/georgia-protests-european-union-russia/76698797007/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6e4fg/protests_explode_in_georgia_over_paused_bid_for/">[comments]</a></span> </td></tr></table>

## Production of 4,000 AI-Enabled German Kamikaze Drones for Ukraine Underway
 - [https://www.reddit.com/r/worldnews/comments/1h6d6xr/production_of_4000_aienabled_german_kamikaze](https://www.reddit.com/r/worldnews/comments/1h6d6xr/production_of_4000_aienabled_german_kamikaze)
 - RSS feed: $source
 - date published: 2024-12-04T10:42:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6d6xr/production_of_4000_aienabled_german_kamikaze/"> <img src="https://external-preview.redd.it/DDOfWQ6RZk5td-Kf_aAPZpdlb3G82JzZ7d_QtOPH1Ug.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=affc8854586cd3e71864bac7129f015283cfddba" alt="Production of 4,000 AI-Enabled German Kamikaze Drones for Ukraine Underway" title="Production of 4,000 AI-Enabled German Kamikaze Drones for Ukraine Underway" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Silly-avocatoe"> /u/Silly-avocatoe </a> <br/> <span><a href="https://www.kyivpost.com/post/43262">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6d6xr/production_of_4000_aienabled_german_kamikaze/">[comments]</a></span> </td></tr></table>

## Meta Uncovers 20 Covert Operations, Naming Russia as the Leading Source
 - [https://www.reddit.com/r/worldnews/comments/1h6cjeh/meta_uncovers_20_covert_operations_naming_russia](https://www.reddit.com/r/worldnews/comments/1h6cjeh/meta_uncovers_20_covert_operations_naming_russia)
 - RSS feed: $source
 - date published: 2024-12-04T09:55:05+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6cjeh/meta_uncovers_20_covert_operations_naming_russia/"> <img src="https://external-preview.redd.it/OrSqKlceL7ef230YNKx2coPQw5sQC1ooRqSDLah2ihc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ddcfc4bcab9a877be0522a72f26a3f9dffa61d30" alt="Meta Uncovers 20 Covert Operations, Naming Russia as the Leading Source" title="Meta Uncovers 20 Covert Operations, Naming Russia as the Leading Source" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Desperate-Boss5152"> /u/Desperate-Boss5152 </a> <br/> <span><a href="https://united24media.com/latest-news/meta-uncovers-20-covert-operations-naming-russia-as-the-leading-source-4215">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6cjeh/meta_uncovers_20_covert_operations_naming_russia/">[comments]</a></span> </td></tr></table>

## Germany Open to Deploying Troops in Ukraine for Peacekeeping, Says FM Baerbock
 - [https://www.reddit.com/r/worldnews/comments/1h6ch8h/germany_open_to_deploying_troops_in_ukraine_for](https://www.reddit.com/r/worldnews/comments/1h6ch8h/germany_open_to_deploying_troops_in_ukraine_for)
 - RSS feed: $source
 - date published: 2024-12-04T09:50:27+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6ch8h/germany_open_to_deploying_troops_in_ukraine_for/"> <img src="https://external-preview.redd.it/61M8sx4g2lp7Wq7_mEmQlxqntV6g5G8ZC3e10C-6FDY.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=0f467c43bd685f818b64cc70810aa2d78bb032e6" alt="Germany Open to Deploying Troops in Ukraine for Peacekeeping, Says FM Baerbock" title="Germany Open to Deploying Troops in Ukraine for Peacekeeping, Says FM Baerbock" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Beautiful-Hat-8625"> /u/Beautiful-Hat-8625 </a> <br/> <span><a href="https://united24media.com/latest-news/germany-open-to-deploying-troops-in-ukraine-for-peacekeeping-says-fm-baerbock-4212">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6ch8h/germany_open_to_deploying_troops_in_ukraine_for/">[comments]</a></span> </td></tr></table>

## Trump's plan for Ukraine comes into focus: Territorial concessions but NATO off the table
 - [https://www.reddit.com/r/worldnews/comments/1h6c5dd/trumps_plan_for_ukraine_comes_into_focus](https://www.reddit.com/r/worldnews/comments/1h6c5dd/trumps_plan_for_ukraine_comes_into_focus)
 - RSS feed: $source
 - date published: 2024-12-04T09:25:38+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/Advanced_Drink_8536"> /u/Advanced_Drink_8536 </a> <br/> <span><a href="https://www.reuters.com/world/trumps-plan-ukraine-comes-into-focus-territorial-concessions-nato-off-table-2024-12-04/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6c5dd/trumps_plan_for_ukraine_comes_into_focus/">[comments]</a></span>

## North Korea, Russia and China watch on as crisis unfolds in key US ally South Korea
 - [https://www.reddit.com/r/worldnews/comments/1h6alks/north_korea_russia_and_china_watch_on_as_crisis](https://www.reddit.com/r/worldnews/comments/1h6alks/north_korea_russia_and_china_watch_on_as_crisis)
 - RSS feed: $source
 - date published: 2024-12-04T07:27:14+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h6alks/north_korea_russia_and_china_watch_on_as_crisis/"> <img src="https://external-preview.redd.it/GmIAERcmWbnLgJXiE7rlYheLBrSJhCm30oA1Qfw0lvc.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=d9334b3da1b2adb8dd7ddb72099a9ee63f07ca39" alt="North Korea, Russia and China watch on as crisis unfolds in key US ally South Korea" title="North Korea, Russia and China watch on as crisis unfolds in key US ally South Korea" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/MothersMiIk"> /u/MothersMiIk </a> <br/> <span><a href="https://amp.cnn.com/cnn/2024/12/04/asia/south-korea-martial-law-north-korea-russia-china-intl-hnk">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h6alks/north_korea_russia_and_china_watch_on_as_crisis/">[comments]</a></span> </td></tr></table>

## Tesla Cybertruck Immediately Dies in Canadian Winter – Owner Bricks the Truck Trying to Use the Defroster, Says “In Love to Heartbroken on the Same Day”
 - [https://www.reddit.com/r/worldnews/comments/1h69sxn/tesla_cybertruck_immediately_dies_in_canadian](https://www.reddit.com/r/worldnews/comments/1h69sxn/tesla_cybertruck_immediately_dies_in_canadian)
 - RSS feed: $source
 - date published: 2024-12-04T06:31:55+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h69sxn/tesla_cybertruck_immediately_dies_in_canadian/"> <img src="https://external-preview.redd.it/AF1ezUAdtu4HdAEq-SNy3Sb_dLOuomydir2S1D18K7M.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=1bc39df064cd39e56c308885e8405fefc1238087" alt="Tesla Cybertruck Immediately Dies in Canadian Winter – Owner Bricks the Truck Trying to Use the Defroster, Says “In Love to Heartbroken on the Same Day”" title="Tesla Cybertruck Immediately Dies in Canadian Winter – Owner Bricks the Truck Trying to Use the Defroster, Says “In Love to Heartbroken on the Same Day”" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/cryoK"> /u/cryoK </a> <br/> <span><a href="https://www.torquenews.com/11826/tesla-cybertruck-immediately-dies-canadian-winter-owner-bricks-truck-trying-use-defroster/amp">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h69sxn/tesla_cybertruck_immediately_di

## US sanctions 35 entities tied to Iranian oil trade
 - [https://www.reddit.com/r/worldnews/comments/1h68qqn/us_sanctions_35_entities_tied_to_iranian_oil_trade](https://www.reddit.com/r/worldnews/comments/1h68qqn/us_sanctions_35_entities_tied_to_iranian_oil_trade)
 - RSS feed: $source
 - date published: 2024-12-04T05:26:28+00:00

&#32; submitted by &#32; <a href="https://www.reddit.com/user/limsus"> /u/limsus </a> <br/> <span><a href="https://in.investing.com/news/stock-market-news/us-sanctions-35-entities-tied-to-iranian-oil-trade-93CH-4555114">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h68qqn/us_sanctions_35_entities_tied_to_iranian_oil_trade/">[comments]</a></span>

## World War III has begun, West not prepared for it, says Ukraine’s former military commander
 - [https://www.reddit.com/r/worldnews/comments/1h68l73/world_war_iii_has_begun_west_not_prepared_for_it](https://www.reddit.com/r/worldnews/comments/1h68l73/world_war_iii_has_begun_west_not_prepared_for_it)
 - RSS feed: $source
 - date published: 2024-12-04T05:17:33+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h68l73/world_war_iii_has_begun_west_not_prepared_for_it/"> <img src="https://external-preview.redd.it/O4h7YEL7lgFAmgWrEc6C4wuCp7BZN2ukFBlsnm-N9xg.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=cd43304b28d2851e20c3f63a828bd43e0c82fc18" alt="World War III has begun, West not prepared for it, says Ukraine’s former military commander" title="World War III has begun, West not prepared for it, says Ukraine’s former military commander" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DioriteLover"> /u/DioriteLover </a> <br/> <span><a href="https://www.ukrainianworldcongress.org/world-war-iii-has-begun-west-not-prepared-for-it-says-ukraines-former-military-commander/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h68l73/world_war_iii_has_begun_west_not_prepared_for_it/">[comments]</a></span> </td></tr></table>

## Demonstrators again converge on Georgia's parliament after the country's EU bid was suspended
 - [https://www.reddit.com/r/worldnews/comments/1h683sf/demonstrators_again_converge_on_georgias](https://www.reddit.com/r/worldnews/comments/1h683sf/demonstrators_again_converge_on_georgias)
 - RSS feed: $source
 - date published: 2024-12-04T04:50:38+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h683sf/demonstrators_again_converge_on_georgias/"> <img src="https://external-preview.redd.it/JwRVrd4X6xmbBha5N8sVxndYLbZP7nHYV6knPS6_d5M.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2464072d145370993476353e22ba3655fc3bef45" alt="Demonstrators again converge on Georgia's parliament after the country's EU bid was suspended" title="Demonstrators again converge on Georgia's parliament after the country's EU bid was suspended" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/DoremusJessup"> /u/DoremusJessup </a> <br/> <span><a href="https://apnews.com/article/georgia-protest-opposition-election-russia-european-union-16efe0ee5041dfd6847d22c64f084674">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h683sf/demonstrators_again_converge_on_georgias/">[comments]</a></span> </td></tr></table>

## India abandons Russian weapons in favour of American ones – Bloomberg
 - [https://www.reddit.com/r/worldnews/comments/1h67abz/india_abandons_russian_weapons_in_favour_of](https://www.reddit.com/r/worldnews/comments/1h67abz/india_abandons_russian_weapons_in_favour_of)
 - RSS feed: $source
 - date published: 2024-12-04T04:04:50+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h67abz/india_abandons_russian_weapons_in_favour_of/"> <img src="https://external-preview.redd.it/zl3_pgXaapGIMkuH2RgjkdLdpRy_J0MDOTsiVVBosZ0.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=c6408904350d29d97d583ea3170805d7dccdba79" alt="India abandons Russian weapons in favour of American ones – Bloomberg" title="India abandons Russian weapons in favour of American ones – Bloomberg" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/JKKIDD231"> /u/JKKIDD231 </a> <br/> <span><a href="https://www.pravda.com.ua/eng/news/2024/12/3/7487515/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h67abz/india_abandons_russian_weapons_in_favour_of/">[comments]</a></span> </td></tr></table>

## /r/WorldNews Live Thread: Russian Invasion of Ukraine Day 1014, Part 1 (Thread #1161)
 - [https://www.reddit.com/r/worldnews/comments/1h678ms/rworldnews_live_thread_russian_invasion_of](https://www.reddit.com/r/worldnews/comments/1h678ms/rworldnews_live_thread_russian_invasion_of)
 - RSS feed: $source
 - date published: 2024-12-04T04:02:16+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h678ms/rworldnews_live_thread_russian_invasion_of/"> <img src="https://a.thumbs.redditmedia.com/jWqSTFxxKuo9aDK8JeM4yZL4Nb_RTA85H45u1-h63L8.jpg" alt="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 1014, Part 1 (Thread #1161)" title="/r/WorldNews Live Thread: Russian Invasion of Ukraine Day 1014, Part 1 (Thread #1161)" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/WorldNewsMods"> /u/WorldNewsMods </a> <br/> <span><a href="https://www.reddit.com/live/18hnzysb1elcs">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h678ms/rworldnews_live_thread_russian_invasion_of/">[comments]</a></span> </td></tr></table>

## Afghanistan: Women suspended from midwife and nurse training
 - [https://www.reddit.com/r/worldnews/comments/1h672yc/afghanistan_women_suspended_from_midwife_and](https://www.reddit.com/r/worldnews/comments/1h672yc/afghanistan_women_suspended_from_midwife_and)
 - RSS feed: $source
 - date published: 2024-12-04T03:53:43+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h672yc/afghanistan_women_suspended_from_midwife_and/"> <img src="https://external-preview.redd.it/uSBsDCacbEPkDcyYjvGUnzWM-COYoL1tcfHiGnn0ykw.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=abc5e3fee027f39a618683fa25519ff4ea89fbbd" alt="Afghanistan: Women suspended from midwife and nurse training" title="Afghanistan: Women suspended from midwife and nurse training" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Unhappy-Apple222"> /u/Unhappy-Apple222 </a> <br/> <span><a href="https://www.bbc.com/news/articles/cwy3l1035nlo">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h672yc/afghanistan_women_suspended_from_midwife_and/">[comments]</a></span> </td></tr></table>

## Europe Quietly Prepares for World War III
 - [https://www.reddit.com/r/worldnews/comments/1h661s0/europe_quietly_prepares_for_world_war_iii](https://www.reddit.com/r/worldnews/comments/1h661s0/europe_quietly_prepares_for_world_war_iii)
 - RSS feed: $source
 - date published: 2024-12-04T03:01:00+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h661s0/europe_quietly_prepares_for_world_war_iii/"> <img src="https://external-preview.redd.it/VbqTmEVtac8cq8BcnwHctXuavhF2RNU3UXhHNkT4yxo.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=2ab4637a3350aff47977fbc365bdc58bc64cb9ac" alt="Europe Quietly Prepares for World War III" title="Europe Quietly Prepares for World War III" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/cuspofgreatness"> /u/cuspofgreatness </a> <br/> <span><a href="https://www.newsweek.com/europe-preparations-world-war-3-baltic-states-dragons-teeth-air-defenses-1993930">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h661s0/europe_quietly_prepares_for_world_war_iii/">[comments]</a></span> </td></tr></table>

## Namibia elects first female president, Netumbo Nandi-Ndaitwah - Times of India
 - [https://www.reddit.com/r/worldnews/comments/1h65kn9/namibia_elects_first_female_president_netumbo](https://www.reddit.com/r/worldnews/comments/1h65kn9/namibia_elects_first_female_president_netumbo)
 - RSS feed: $source
 - date published: 2024-12-04T02:36:42+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h65kn9/namibia_elects_first_female_president_netumbo/"> <img src="https://external-preview.redd.it/00FpoVCP6WJL1LD6HsdnHixpDNH130eDl7nB2wt58AI.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=ac670788d70e46d6de4a9d43eaad3a1fe493dc8f" alt="Namibia elects first female president, Netumbo Nandi-Ndaitwah - Times of India" title="Namibia elects first female president, Netumbo Nandi-Ndaitwah - Times of India" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Sea-Sound-3040"> /u/Sea-Sound-3040 </a> <br/> <span><a href="https://timesofindia.indiatimes.com/world/rest-of-world/namibia-elects-first-female-president-netumbo-nandi-ndaitwah/articleshow/115948095.cms">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h65kn9/namibia_elects_first_female_president_netumbo/">[comments]</a></span> </td></tr></table>

## Death sentence upheld for property tycoon in Vietnam — unless she pays $9 billion before execution
 - [https://www.reddit.com/r/worldnews/comments/1h638tm/death_sentence_upheld_for_property_tycoon_in](https://www.reddit.com/r/worldnews/comments/1h638tm/death_sentence_upheld_for_property_tycoon_in)
 - RSS feed: $source
 - date published: 2024-12-04T00:43:49+00:00

<table> <tr><td> <a href="https://www.reddit.com/r/worldnews/comments/1h638tm/death_sentence_upheld_for_property_tycoon_in/"> <img src="https://external-preview.redd.it/sTkkNN7604jLmcsyrvC3CFBoDe9o2yt9zFt3wplpSc8.jpg?width=640&amp;crop=smart&amp;auto=webp&amp;s=710ff492d123f47f4345888d7bdf4f7873205b50" alt="Death sentence upheld for property tycoon in Vietnam — unless she pays $9 billion before execution" title="Death sentence upheld for property tycoon in Vietnam — unless she pays $9 billion before execution" /> </a> </td><td> &#32; submitted by &#32; <a href="https://www.reddit.com/user/Just-Sale-7015"> /u/Just-Sale-7015 </a> <br/> <span><a href="https://www.cbsnews.com/news/vietnam-death-sentence-tycoon-truong-my-lan-upheld-unless-pays-9-billion/">[link]</a></span> &#32; <span><a href="https://www.reddit.com/r/worldnews/comments/1h638tm/death_sentence_upheld_for_property_tycoon_in/">[comments]</a></span> </td></tr></table>

