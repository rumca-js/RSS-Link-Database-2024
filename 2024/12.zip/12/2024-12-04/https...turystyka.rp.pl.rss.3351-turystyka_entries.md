# Source:Turystyka, URL:https://turystyka.rp.pl/rss/3351-turystyka, language:pl-PL

## Mieszkanie wakacyjne bez spotkania z gospodarzem? We Włoszech z tym kończą
 - [https://turystyka.rp.pl/apartamenty/art41537431-mieszkanie-wakacyjne-bez-spotkania-z-gospodarzem-we-wloszech-z-tym-koncza](https://turystyka.rp.pl/apartamenty/art41537431-mieszkanie-wakacyjne-bez-spotkania-z-gospodarzem-we-wloszech-z-tym-koncza)
 - RSS feed: $source
 - date published: 2024-12-04T12:24:05.429807+00:00

Turyści we Włoszech nie będą już mogli korzystać z mieszkań wynajmowanych zdalnie. Szef policji tego kraju domaga się, by właściciele osobiście weryfikowali tożsamość gości.

