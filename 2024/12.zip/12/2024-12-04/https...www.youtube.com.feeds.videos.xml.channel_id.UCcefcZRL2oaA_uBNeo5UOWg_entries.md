# Source:Y Combinator, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcefcZRL2oaA_uBNeo5UOWg, language:en

## How To Make The Most Out of Your 20s
 - [https://www.youtube.com/watch?v=H_XMqRhLhic](https://www.youtube.com/watch?v=H_XMqRhLhic)
 - RSS feed: $source
 - date published: 2024-12-04T15:00:19+00:00

How should you navigate your 20s - the most important decade in your life? For many people, it’s an age with fewer responsibilities: no kids, no mortgage, no restrictions. And so it’s actually the best possible time to go hardcore: to take risks, invest in yourself, and surround yourself with like-minded people. In this episode, Dalton & Michael share their thoughts on how to live your 20s - founder or not.
Chapters (Powered by https://bit.ly/chapterme-yc) - 
00:00 - Intro
00:45 - Treadmill
02:55 - No Speed Run
03:51 - Hardcore Early On
05:54 - Risks
08:35 - Family
09:54 - Friends
12:45 - Relation
14:26 - General Public
15:45 - Limits
17:05 - Good School
18:56 - The Game
20:50 - Wrap Up

