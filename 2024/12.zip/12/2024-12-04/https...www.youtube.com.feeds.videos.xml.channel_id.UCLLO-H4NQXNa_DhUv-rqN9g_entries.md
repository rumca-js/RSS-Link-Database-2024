# Source:CD-Action - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g, language:pl

## 30 LAT PLAYSTATION! Co zawdzięczamy konsolom Sony?
 - [https://www.youtube.com/watch?v=R4dcvAca0DM](https://www.youtube.com/watch?v=R4dcvAca0DM)
 - RSS feed: $source
 - date published: 2024-12-04T18:35:52+00:00

PlayStation świętuje 30-lecie – od debiutu w 1994 roku w Japonii po kolejne generacje, które wprowadzały innowacje, jak płyty CD czy Blu-ray. A Wy, od której konsoli zaczęliście swoją przygodę z marką?

Prowadzenie, scenariusz i montaż:
Kacper Grela (https://x.com/kgrelaa)

#cdaction #gaming #playstation

