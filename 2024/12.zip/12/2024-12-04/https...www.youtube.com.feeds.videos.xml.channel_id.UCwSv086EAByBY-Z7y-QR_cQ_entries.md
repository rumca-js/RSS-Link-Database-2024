# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Co kolekcjonuje JOSE Kolekcjoner? Dekonstrukcja mitu założycielskiego!
 - [https://www.youtube.com/watch?v=VCuEueOKtaM](https://www.youtube.com/watch?v=VCuEueOKtaM)
 - RSS feed: $source
 - date published: 2024-12-04T20:50:46+00:00

📺 Zapraszam do oglądania

⬇️Rozwiń opis⬇️
------------------------------------------------------------
🎮 Tatusiek - https://bit.ly/3CTyeOG
------------------------------------------------------------
✉️ Ludzie listy piszą 
🖊️ uszi@uszi.pl
------------------------------------------------------------
💝 Apeluję o kulturę w komentarzach
------------------------------------------------------------
💲 Donate/ Darowizna
PLN / SMS / Blik: http://bit.ly/3bsXtJj
-------------------------------------------------------------
✅ Źródła:
1. https://tinyurl.com/4k7trpbm
2. https://tinyurl.com/38c4akp6
3. https://tinyurl.com/wzbn592k
4. https://tinyurl.com/39vanrwe
5. https://tinyurl.com/3za9nd2a
6. https://tinyurl.com/mr296zwr
7. https://tinyurl.com/333szw7x
8. https://tinyurl.com/mr2xt5t9
9. https://tinyurl.com/yfc7mbnh
10. https://tinyurl.com/4p22rfw8
11. https://tinyurl.com/bdemskzc
12. https://tinyurl.com/2hj2nhh5
13. https://tinyurl.com/e4z2z3xj
14. https://tinyurl.com/3xdvx9pf
-----------------

