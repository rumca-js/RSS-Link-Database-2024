# Source:Marc Brunet, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg, language:en-US

## 🤸‍♀️ how to draw ANY pose
 - [https://www.youtube.com/watch?v=5qS7bz4cAEQ](https://www.youtube.com/watch?v=5qS7bz4cAEQ)
 - RSS feed: $source
 - date published: 2024-12-04T18:53:23+00:00

🎅 CHRISTMAS SALE!! Get a MASSIVE $45% OFF (what!?!) the ART School: Digital Artists program 🎓 https://cubebrush.co/mb/products/0dpz... until December 31st 2024 ONLY!

Join the program and access our private art community on Discord! WE JUST PASSED 26,000 ENROLLED STUDENTS! 💥 Nani?! What are you waiting for!

🖌 Get my brushes for FREE here: http://cbr.sh/befto
💻 HOW TO USE THE FREE BRUSHES: https://youtu.be/8EC1Ibda3BI
🖌 Clip Studio Paint MB LENGENDARY Lineart Brush: http://cbr.sh/vb2lt6
🖌 Get my advanced brush set here: http://cbr.sh/btml0

🚀 My Store: https://cubebrush.co/mb
🎨 Practice files download: http://cbr.sh/xsqi64

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

FOLLOW ME ON SOCIAL MEDIA:
✖️ X: https://x.com/ytartschool
🦋 Bluesky: https://bsky.app/profile/marcbrunet.bsky.social
📷 Instagram: https://www.instagram.com/bluefley

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬ 

#artschool #trendingnow #learntodraw

