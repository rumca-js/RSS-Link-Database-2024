# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## Top US Official, Senators Warn Americans to Use Encrypted Apps Amid Chinese Threats
 - [https://www.theepochtimes.com/us/top-us-official-senators-warn-americans-to-use-encrypted-apps-amid-chinese-threats-5770824](https://www.theepochtimes.com/us/top-us-official-senators-warn-americans-to-use-encrypted-apps-amid-chinese-threats-5770824)
 - RSS feed: $source
 - date published: 2024-12-04T19:47:40+00:00

'Encryption is your friend,' CISA official Jeff Greene says.

## Meta Says Harmless Content Removed Too Often, Vows to Improve Moderation
 - [https://www.theepochtimes.com/us/meta-says-harmless-content-removed-too-often-vows-to-improve-moderation-5770419](https://www.theepochtimes.com/us/meta-says-harmless-content-removed-too-often-vows-to-improve-moderation-5770419)
 - RSS feed: $source
 - date published: 2024-12-04T11:28:03+00:00

Meta says it has given users options for more political content recommendations, and limited penalties for content violations to persistent offenders only.

